module
public import NumericalBound
public import Boot185

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM PA192.PhysicalModel PA192.BusyBeaver

namespace NF185PA

/-- First-order PA formula over the literal 370 rows and the blank initial state. -/
def H185 : ArithmeticSentence := traceF CS185.Table.machine CS185.Table.start

/-- First-order PA formula for halting within a given standard number of steps. -/
def byStep (k : Nat) : ArithmeticSentence := beforeF CS185.Table.machine CS185.Table.start k

/-- Semantics of the sentence for every PA model, including nonstandard times. -/
theorem H185_eval {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    (V ⊧/![] H185) ↔ ∃ t : V, state (rawRun CS185.Table.machine CS185.Table.start t) = (185 : V) :=
  traceF_iff_model_run _ _

theorem H185_standard :
    (Nat ⊧/![] H185) ↔ Halts CS185.Table.machine CS185.Table.start :=
  traceF_standard _ _

end NF185PA
