import NF182PATapeCompiler
import NF182PATapeAll

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch.RegisterSource (address)

namespace NF182PA.Symbolic

/-- In every model of PA, a terminal register computation from the signed
margin gives a halting time on the literal blank 182-state tape. -/
theorem tape_of_register_halt {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
    (stop : ∃ j : V, address (Registers.run j) = 4095) : V ⊧/![] H182 :=
  tape_of_coverage literal_table_coverage stop

end NF182PA.Symbolic
#print axioms NF182PA.Symbolic.tape_of_register_halt
