import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w128_0 : checkWitness 128 false false 8892 = true := by decide +kernel
private theorem w128_2 : checkWitness 128 true false 8888 = true := by decide +kernel
private theorem cases128 : checkFour 128 (8892,0,8888,0) = true := by
  simp only [checkFour, w128_0, w128_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one128 : Coverage 128 129 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases128)
private theorem w129_0 : checkWitness 129 false false 8888 = true := by decide +kernel
private theorem w129_2 : checkWitness 129 true false 8884 = true := by decide +kernel
private theorem cases129 : checkFour 129 (8888,0,8884,0) = true := by
  simp only [checkFour, w129_0, w129_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one129 : Coverage 129 130 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases129)
private theorem w130_0 : checkWitness 130 false false 66 = true := by decide +kernel
private theorem w130_2 : checkWitness 130 true false 66 = true := by decide +kernel
private theorem cases130 : checkFour 130 (66,0,66,0) = true := by
  simp only [checkFour, w130_0, w130_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one130 : Coverage 130 131 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases130)
private theorem w131_0 : checkWitness 131 false false 503 = true := by decide +kernel
private theorem w131_1 : checkWitness 131 false true 4599 = true := by decide +kernel
private theorem w131_2 : checkWitness 131 true false 503 = true := by decide +kernel
private theorem w131_3 : checkWitness 131 true true 4599 = true := by decide +kernel
private theorem cases131 : checkFour 131 (503,4599,503,4599) = true := by
  simp only [checkFour, w131_0, w131_1, w131_2, w131_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one131 : Coverage 131 132 := checkList_sound (ws:=[(503,4599,503,4599)]) (by simpa only [checkList, Bool.and_true] using cases131)
private theorem w132_0 : checkWitness 132 false false 8907 = true := by decide +kernel
private theorem w132_2 : checkWitness 132 true false 8903 = true := by decide +kernel
private theorem cases132 : checkFour 132 (8907,0,8903,0) = true := by
  simp only [checkFour, w132_0, w132_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one132 : Coverage 132 133 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases132)
private theorem w133_0 : checkWitness 133 false false 638 = true := by decide +kernel
private theorem w133_1 : checkWitness 133 false true 4734 = true := by decide +kernel
private theorem w133_2 : checkWitness 133 true false 629 = true := by decide +kernel
private theorem w133_3 : checkWitness 133 true true 4725 = true := by decide +kernel
private theorem cases133 : checkFour 133 (638,4734,629,4725) = true := by
  simp only [checkFour, w133_0, w133_1, w133_2, w133_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one133 : Coverage 133 134 := checkList_sound (ws:=[(638,4734,629,4725)]) (by simpa only [checkList, Bool.and_true] using cases133)
private theorem w134_0 : checkWitness 134 false false 188 = true := by decide +kernel
private theorem w134_2 : checkWitness 134 true false 188 = true := by decide +kernel
private theorem cases134 : checkFour 134 (188,0,188,0) = true := by
  simp only [checkFour, w134_0, w134_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one134 : Coverage 134 135 := checkList_sound (ws:=[(188,0,188,0)]) (by simpa only [checkList, Bool.and_true] using cases134)
private theorem w135_0 : checkWitness 135 false false 593 = true := by decide +kernel
private theorem w135_1 : checkWitness 135 false true 4681 = true := by decide +kernel
private theorem w135_2 : checkWitness 135 true false 593 = true := by decide +kernel
private theorem w135_3 : checkWitness 135 true true 4681 = true := by decide +kernel
private theorem cases135 : checkFour 135 (593,4681,593,4681) = true := by
  simp only [checkFour, w135_0, w135_1, w135_2, w135_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one135 : Coverage 135 136 := checkList_sound (ws:=[(593,4681,593,4681)]) (by simpa only [checkList, Bool.and_true] using cases135)
private theorem w136_0 : checkWitness 136 false false 8922 = true := by decide +kernel
private theorem w136_2 : checkWitness 136 true false 8913 = true := by decide +kernel
private theorem cases136 : checkFour 136 (8922,0,8913,0) = true := by
  simp only [checkFour, w136_0, w136_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one136 : Coverage 136 137 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases136)
private theorem w137_0 : checkWitness 137 false false 60 = true := by decide +kernel
private theorem w137_2 : checkWitness 137 true false 60 = true := by decide +kernel
private theorem cases137 : checkFour 137 (60,0,60,0) = true := by
  simp only [checkFour, w137_0, w137_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one137 : Coverage 137 138 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases137)
private theorem w138_0 : checkWitness 138 false false 52 = true := by decide +kernel
private theorem w138_2 : checkWitness 138 true false 52 = true := by decide +kernel
private theorem cases138 : checkFour 138 (52,0,52,0) = true := by
  simp only [checkFour, w138_0, w138_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one138 : Coverage 138 139 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases138)
private theorem w139_0 : checkWitness 139 false false 605 = true := by decide +kernel
private theorem w139_1 : checkWitness 139 false true 4697 = true := by decide +kernel
private theorem w139_2 : checkWitness 139 true false 605 = true := by decide +kernel
private theorem w139_3 : checkWitness 139 true true 4697 = true := by decide +kernel
private theorem cases139 : checkFour 139 (605,4697,605,4697) = true := by
  simp only [checkFour, w139_0, w139_1, w139_2, w139_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one139 : Coverage 139 140 := checkList_sound (ws:=[(605,4697,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases139)
private theorem w140_0 : checkWitness 140 false false 8883 = true := by decide +kernel
private theorem w140_2 : checkWitness 140 true false 8879 = true := by decide +kernel
private theorem cases140 : checkFour 140 (8883,0,8879,0) = true := by
  simp only [checkFour, w140_0, w140_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one140 : Coverage 140 141 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases140)
private theorem w141_0 : checkWitness 141 false false 52 = true := by decide +kernel
private theorem w141_2 : checkWitness 141 true false 52 = true := by decide +kernel
private theorem cases141 : checkFour 141 (52,0,52,0) = true := by
  simp only [checkFour, w141_0, w141_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one141 : Coverage 141 142 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases141)
private theorem w142_0 : checkWitness 142 false false 662 = true := by decide +kernel
private theorem w142_1 : checkWitness 142 false true 4754 = true := by decide +kernel
private theorem w142_2 : checkWitness 142 true false 653 = true := by decide +kernel
private theorem w142_3 : checkWitness 142 true true 4745 = true := by decide +kernel
private theorem cases142 : checkFour 142 (662,4754,653,4745) = true := by
  simp only [checkFour, w142_0, w142_1, w142_2, w142_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one142 : Coverage 142 143 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases142)
private theorem w143_0 : checkWitness 143 false false 8901 = true := by decide +kernel
private theorem w143_2 : checkWitness 143 true false 8897 = true := by decide +kernel
private theorem cases143 : checkFour 143 (8901,0,8897,0) = true := by
  simp only [checkFour, w143_0, w143_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one143 : Coverage 143 144 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases143)
private theorem w144_0 : checkWitness 144 false false 56 = true := by decide +kernel
private theorem w144_2 : checkWitness 144 true false 56 = true := by decide +kernel
private theorem cases144 : checkFour 144 (56,0,56,0) = true := by
  simp only [checkFour, w144_0, w144_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one144 : Coverage 144 145 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases144)
private theorem w145_0 : checkWitness 145 false false 536 = true := by decide +kernel
private theorem w145_1 : checkWitness 145 false true 4632 = true := by decide +kernel
private theorem w145_2 : checkWitness 145 true false 536 = true := by decide +kernel
private theorem w145_3 : checkWitness 145 true true 4632 = true := by decide +kernel
private theorem cases145 : checkFour 145 (536,4632,536,4632) = true := by
  simp only [checkFour, w145_0, w145_1, w145_2, w145_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one145 : Coverage 145 146 := checkList_sound (ws:=[(536,4632,536,4632)]) (by simpa only [checkList, Bool.and_true] using cases145)
private theorem w146_0 : checkWitness 146 false false 8948 = true := by decide +kernel
private theorem w146_2 : checkWitness 146 true false 8939 = true := by decide +kernel
private theorem cases146 : checkFour 146 (8948,0,8939,0) = true := by
  simp only [checkFour, w146_0, w146_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one146 : Coverage 146 147 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases146)
private theorem w147_0 : checkWitness 147 false false 62 = true := by decide +kernel
private theorem w147_2 : checkWitness 147 true false 62 = true := by decide +kernel
private theorem cases147 : checkFour 147 (62,0,62,0) = true := by
  simp only [checkFour, w147_0, w147_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one147 : Coverage 147 148 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases147)
private theorem w148_0 : checkWitness 148 false false 530 = true := by decide +kernel
private theorem w148_1 : checkWitness 148 false true 4626 = true := by decide +kernel
private theorem w148_2 : checkWitness 148 true false 530 = true := by decide +kernel
private theorem w148_3 : checkWitness 148 true true 4626 = true := by decide +kernel
private theorem cases148 : checkFour 148 (530,4626,530,4626) = true := by
  simp only [checkFour, w148_0, w148_1, w148_2, w148_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one148 : Coverage 148 149 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases148)
private theorem w149_0 : checkWitness 149 false false 8888 = true := by decide +kernel
private theorem w149_2 : checkWitness 149 true false 8884 = true := by decide +kernel
private theorem cases149 : checkFour 149 (8888,0,8884,0) = true := by
  simp only [checkFour, w149_0, w149_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one149 : Coverage 149 150 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases149)
private theorem w150_0 : checkWitness 150 false false 64 = true := by decide +kernel
private theorem w150_2 : checkWitness 150 true false 64 = true := by decide +kernel
private theorem cases150 : checkFour 150 (64,0,64,0) = true := by
  simp only [checkFour, w150_0, w150_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one150 : Coverage 150 151 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases150)
private theorem w151_0 : checkWitness 151 false false 574 = true := by decide +kernel
private theorem w151_1 : checkWitness 151 false true 4670 = true := by decide +kernel
private theorem w151_2 : checkWitness 151 true false 574 = true := by decide +kernel
private theorem w151_3 : checkWitness 151 true true 4670 = true := by decide +kernel
private theorem cases151 : checkFour 151 (574,4670,574,4670) = true := by
  simp only [checkFour, w151_0, w151_1, w151_2, w151_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one151 : Coverage 151 152 := checkList_sound (ws:=[(574,4670,574,4670)]) (by simpa only [checkList, Bool.and_true] using cases151)
private theorem w152_0 : checkWitness 152 false false 8909 = true := by decide +kernel
private theorem w152_2 : checkWitness 152 true false 8905 = true := by decide +kernel
private theorem cases152 : checkFour 152 (8909,0,8905,0) = true := by
  simp only [checkFour, w152_0, w152_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one152 : Coverage 152 153 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases152)
private theorem w153_0 : checkWitness 153 false false 8944 = true := by decide +kernel
private theorem w153_2 : checkWitness 153 true false 8935 = true := by decide +kernel
private theorem cases153 : checkFour 153 (8944,0,8935,0) = true := by
  simp only [checkFour, w153_0, w153_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one153 : Coverage 153 154 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases153)
private theorem w154_0 : checkWitness 154 false false 88 = true := by decide +kernel
private theorem w154_2 : checkWitness 154 true false 88 = true := by decide +kernel
private theorem cases154 : checkFour 154 (88,0,88,0) = true := by
  simp only [checkFour, w154_0, w154_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one154 : Coverage 154 155 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases154)
private theorem w155_0 : checkWitness 155 false false 656 = true := by decide +kernel
private theorem w155_1 : checkWitness 155 false true 4748 = true := by decide +kernel
private theorem w155_2 : checkWitness 155 true false 647 = true := by decide +kernel
private theorem w155_3 : checkWitness 155 true true 4739 = true := by decide +kernel
private theorem cases155 : checkFour 155 (656,4748,647,4739) = true := by
  simp only [checkFour, w155_0, w155_1, w155_2, w155_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one155 : Coverage 155 156 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases155)
private theorem w156_0 : checkWitness 156 false false 8905 = true := by decide +kernel
private theorem w156_2 : checkWitness 156 true false 8901 = true := by decide +kernel
private theorem cases156 : checkFour 156 (8905,0,8901,0) = true := by
  simp only [checkFour, w156_0, w156_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one156 : Coverage 156 157 := checkList_sound (ws:=[(8905,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases156)
private theorem w157_0 : checkWitness 157 false false 650 = true := by decide +kernel
private theorem w157_1 : checkWitness 157 false true 4742 = true := by decide +kernel
private theorem w157_2 : checkWitness 157 true false 641 = true := by decide +kernel
private theorem w157_3 : checkWitness 157 true true 4733 = true := by decide +kernel
private theorem cases157 : checkFour 157 (650,4742,641,4733) = true := by
  simp only [checkFour, w157_0, w157_1, w157_2, w157_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one157 : Coverage 157 158 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases157)
private theorem w158_0 : checkWitness 158 false false 8874 = true := by decide +kernel
private theorem w158_2 : checkWitness 158 true false 8870 = true := by decide +kernel
private theorem cases158 : checkFour 158 (8874,0,8870,0) = true := by
  simp only [checkFour, w158_0, w158_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one158 : Coverage 158 159 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases158)
private theorem w159_0 : checkWitness 159 false false 76 = true := by decide +kernel
private theorem w159_2 : checkWitness 159 true false 76 = true := by decide +kernel
private theorem cases159 : checkFour 159 (76,0,76,0) = true := by
  simp only [checkFour, w159_0, w159_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one159 : Coverage 159 160 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases159)
theorem cover0128 : Coverage 128 160 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one128 one129) (Coverage.join one130 one131)) (Coverage.join (Coverage.join one132 one133) (Coverage.join one134 one135))) (Coverage.join (Coverage.join (Coverage.join one136 one137) (Coverage.join one138 one139)) (Coverage.join (Coverage.join one140 one141) (Coverage.join one142 one143)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one144 one145) (Coverage.join one146 one147)) (Coverage.join (Coverage.join one148 one149) (Coverage.join one150 one151))) (Coverage.join (Coverage.join (Coverage.join one152 one153) (Coverage.join one154 one155)) (Coverage.join (Coverage.join one156 one157) (Coverage.join one158 one159)))))
end NF182PA.Symbolic
