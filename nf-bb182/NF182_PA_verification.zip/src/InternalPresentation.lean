import InternalChoice
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Direct
namespace NF192.Internal
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- All objects are represented by old-arithmetic codes. Different codes
may denote the same object and all semantic formulas use the decoded equality. -/
structure Presentation (V X : Type) [ORingStructure V] (mem : X → X → Prop) where
  dec : V → X
  onto : Function.Surjective dec
  eqDef : Language.DefinableRel ℒₒᵣ (fun a b => dec a=dec b)
  memDef : Language.DefinableRel ℒₒᵣ (fun a b => mem (dec a) (dec b))

variable {m : X → X → Prop} (d : Presentation V X m)

theorem Presentation.formDef (φ : SetForm n) : Language.Definable ℒₒᵣ (fun e : Fin n → V => φ.truth m (d.dec ∘ e)) := by
  letI := d.eqDef;letI := d.memDef
  apply Language.Definable.of_iff (fixedSetDef (r:=fun a b => d.dec a=d.dec b) (m:=fun a b => m (d.dec a) (d.dec b)) φ)
  intro e;exact (pull_set_formula d.dec d.onto _ _ _ (fun _ _=>Iff.rfl) (fun _ _=>Iff.rfl) φ e).symm

/-- Arbitrary parameter placement for fixed comprehension/search obligations.
Only the object formula is standard; both the parameter values and the least
selected representative can be nonstandard numbers of V. -/
theorem Presentation.select (φ : SetForm (n+1)) (g : Fin n → (Fin k → V) → V)
    (dg : ∀ i,Language.DefinableFunction ℒₒᵣ (g i))
    (existence : ∀e : Fin k → V, ∃C,φ.truth m (Fin.cases C (fun i => d.dec (g i e)))) :
    ∃op : (Fin k → V) → V, Language.DefinableFunction ℒₒᵣ op ∧
      ∀e,φ.truth m (Fin.cases (d.dec (op e)) (fun i => d.dec (g i e))) := by
  let R (v : Fin (k+1) → V) := φ.truth m (Fin.cases (d.dec (v 0)) (fun i => d.dec (g i (fun j => v j.succ))))
  let F : Fin (n+1) → (Fin (k+1) → V) → V := Fin.cases (fun v => v 0) (fun i v => g i (fun j => v j.succ))
  have hf : ∀i,Language.DefinableFunction ℒₒᵣ (F i) := by
    intro i;cases i using Fin.cases with
    | zero => exact Language.DefinableFunction.projection _
    | succ i =>
      change Language.DefinableFunction ℒₒᵣ (fun v : Fin (k+1)→V => g i (fun j => v j.succ))
      exact Language.DefinableFunction.substitution (dg i) (fun _ => Language.DefinableFunction.projection _)
  have dr : Language.Definable ℒₒᵣ R := by
    apply Language.Definable.of_iff (Language.Definable.substitution (d.formDef φ) hf)
    intro e;unfold R;apply Iff.of_eq;congr 1;funext i;cases i using Fin.cases <;> rfl
  apply minChoice (R:=R) dr
  intro e;obtain ⟨C,hC⟩ := existence e;obtain ⟨x,rfl⟩ := d.onto C
  exact ⟨x,hC⟩

#print axioms Presentation.select
end NF192.Internal
