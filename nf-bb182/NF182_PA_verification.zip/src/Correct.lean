import InternalPresentation
import InternalRepresent
import ExtraFacts
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Direct
namespace NF192.Internal
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {m : X→X→Prop}
structure Correct (d : Presentation V X m) (D z S A B P : X) (o : Operations V) : Prop where
  head : HasR m D P (d.dec o.head) (HeadP m D z P)
  tail : HasR m D P (d.dec o.tail) (TailP m D z P)
  zero : HasR m D P (d.dec o.zero) (fun _ v => v=z)
  succ : HasR m D P (d.dec o.succ) (Edge m S)
  add : HasR m D P (d.dec o.add) (fun h v => ∃x y,m x D ∧ m y D ∧ Tri m P x y h ∧ Tri m A x y v)
  mul : HasR m D P (d.dec o.mul) (fun h v => ∃x y,m x D ∧ m y D ∧ Tri m P x y h ∧ Tri m B x y v)
  less : HasR m D P (d.dec o.less) (OrderP m D S A)
  invTail : HasR m D P (d.dec o.invTail) (InvTailP m D P)
  comp : ∀a b,HasR m D P (d.dec (o.comp a b)) (fun h v => ∃u,m u D ∧ RelObj m D P (d.dec a) h u ∧ RelObj m D P (d.dec b) u v)
  fork : ∀a b,HasR m D P (d.dec (o.fork a b)) (fun h t => ∃x y,m x D ∧ m y D ∧ Tri m P x y t ∧ RelObj m D P (d.dec a) h x ∧ RelObj m D P (d.dec b) h y)
  common : ∀a b, HasU m D (d.dec (o.common a b)) (fun h => ∃x,m x D ∧ RelObj m D P (d.dec a) h x ∧ RelObj m D P (d.dec b) h x)
  cap : ∀a b,HasU m D (d.dec (o.cap a b)) (fun h => m h (d.dec a) ∧ m h (d.dec b))
  neg : ∀a,HasU m D (d.dec (o.neg a)) (fun h => ¬m h (d.dec a))

end NF192.Internal
