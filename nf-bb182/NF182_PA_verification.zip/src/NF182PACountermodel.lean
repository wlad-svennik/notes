import NF182PAProofRows
import NF182PAChartTruth

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal

namespace NF182PA.Pool
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem truth_of_no_refutation (hd : ¬Pr (∅ : V) goal) :
    Nonempty (PA192.NativeTruth.Truth 𝗣𝗔 V) := by
  obtain ⟨rows,ne⟩ := definable_countermodel hd
  let S : NF192.Ground.Signature V := ⟨q,app,witness⟩
  letI : Language.DefinableFunction₂ ℒₒᵣ S.app := PA192.Literal.defApp
  exact Chart.truth_of_rows (S:=S) rows ne

/-- Covers arbitrary internal proof codes, including nonstandard codes. -/
theorem no_refutation_implies_pa_consistency (hd : ¬Pr (∅ : V) goal) :
    ¬Provable 𝗣𝗔 (qqFalsum : V) :=
  fun h => (truth_of_no_refutation hd).elim fun tr => tr.no_refutation h

end NF182PA.Pool
#print axioms NF182PA.Pool.no_refutation_implies_pa_consistency
