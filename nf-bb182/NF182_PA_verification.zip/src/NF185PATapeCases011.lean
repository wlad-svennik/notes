import NF185PATapeBatchCheck
namespace NF185PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w352_0 : checkWitness 352 false false 668 = true := by decide +kernel
private theorem w352_1 : checkWitness 352 false true 4764 = true := by decide +kernel
private theorem w352_2 : checkWitness 352 true false 659 = true := by decide +kernel
private theorem w352_3 : checkWitness 352 true true 4755 = true := by decide +kernel
private theorem cases352 : checkFour 352 (668,4764,659,4755) = true := by
  simp only [checkFour, w352_0, w352_1, w352_2, w352_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one352 : Coverage 352 353 := checkList_sound (ws:=[(668,4764,659,4755)]) (by simpa only [checkList, Bool.and_true] using cases352)
private theorem w353_0 : checkWitness 353 false false 198 = true := by decide +kernel
private theorem w353_2 : checkWitness 353 true false 198 = true := by decide +kernel
private theorem cases353 : checkFour 353 (198,0,198,0) = true := by
  simp only [checkFour, w353_0, w353_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one353 : Coverage 353 354 := checkList_sound (ws:=[(198,0,198,0)]) (by simpa only [checkList, Bool.and_true] using cases353)
private theorem w354_0 : checkWitness 354 false false 613 = true := by decide +kernel
private theorem w354_1 : checkWitness 354 false true 4701 = true := by decide +kernel
private theorem w354_2 : checkWitness 354 true false 613 = true := by decide +kernel
private theorem w354_3 : checkWitness 354 true true 4701 = true := by decide +kernel
private theorem cases354 : checkFour 354 (613,4701,613,4701) = true := by
  simp only [checkFour, w354_0, w354_1, w354_2, w354_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one354 : Coverage 354 355 := checkList_sound (ws:=[(613,4701,613,4701)]) (by simpa only [checkList, Bool.and_true] using cases354)
private theorem w355_0 : checkWitness 355 false false 8954 = true := by decide +kernel
private theorem w355_2 : checkWitness 355 true false 8945 = true := by decide +kernel
private theorem cases355 : checkFour 355 (8954,0,8945,0) = true := by
  simp only [checkFour, w355_0, w355_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one355 : Coverage 355 356 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases355)
private theorem w356_0 : checkWitness 356 false false 70 = true := by decide +kernel
private theorem w356_2 : checkWitness 356 true false 70 = true := by decide +kernel
private theorem cases356 : checkFour 356 (70,0,70,0) = true := by
  simp only [checkFour, w356_0, w356_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one356 : Coverage 356 357 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases356)
private theorem w357_0 : checkWitness 357 false false 62 = true := by decide +kernel
private theorem w357_2 : checkWitness 357 true false 62 = true := by decide +kernel
private theorem cases357 : checkFour 357 (62,0,62,0) = true := by
  simp only [checkFour, w357_0, w357_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one357 : Coverage 357 358 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases357)
private theorem w358_0 : checkWitness 358 false false 619 = true := by decide +kernel
private theorem w358_1 : checkWitness 358 false true 4711 = true := by decide +kernel
private theorem w358_2 : checkWitness 358 true false 619 = true := by decide +kernel
private theorem w358_3 : checkWitness 358 true true 4711 = true := by decide +kernel
private theorem cases358 : checkFour 358 (619,4711,619,4711) = true := by
  simp only [checkFour, w358_0, w358_1, w358_2, w358_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one358 : Coverage 358 359 := checkList_sound (ws:=[(619,4711,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases358)
private theorem w359_0 : checkWitness 359 false false 8896 = true := by decide +kernel
private theorem w359_2 : checkWitness 359 true false 8892 = true := by decide +kernel
private theorem cases359 : checkFour 359 (8896,0,8892,0) = true := by
  simp only [checkFour, w359_0, w359_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one359 : Coverage 359 360 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases359)
private theorem w360_0 : checkWitness 360 false false 62 = true := by decide +kernel
private theorem w360_2 : checkWitness 360 true false 62 = true := by decide +kernel
private theorem cases360 : checkFour 360 (62,0,62,0) = true := by
  simp only [checkFour, w360_0, w360_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one360 : Coverage 360 361 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases360)
private theorem w361_0 : checkWitness 361 false false 584 = true := by decide +kernel
private theorem w361_1 : checkWitness 361 false true 4680 = true := by decide +kernel
private theorem w361_2 : checkWitness 361 true false 584 = true := by decide +kernel
private theorem w361_3 : checkWitness 361 true true 4680 = true := by decide +kernel
private theorem cases361 : checkFour 361 (584,4680,584,4680) = true := by
  simp only [checkFour, w361_0, w361_1, w361_2, w361_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one361 : Coverage 361 362 := checkList_sound (ws:=[(584,4680,584,4680)]) (by simpa only [checkList, Bool.and_true] using cases361)
private theorem w362_0 : checkWitness 362 false false 8927 = true := by decide +kernel
private theorem w362_2 : checkWitness 362 true false 8923 = true := by decide +kernel
private theorem cases362 : checkFour 362 (8927,0,8923,0) = true := by
  simp only [checkFour, w362_0, w362_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one362 : Coverage 362 363 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases362)
private theorem w363_0 : checkWitness 363 false false 8968 = true := by decide +kernel
private theorem w363_2 : checkWitness 363 true false 8959 = true := by decide +kernel
private theorem cases363 : checkFour 363 (8968,0,8959,0) = true := by
  simp only [checkFour, w363_0, w363_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one363 : Coverage 363 364 := checkList_sound (ws:=[(8968,0,8959,0)]) (by simpa only [checkList, Bool.and_true] using cases363)
private theorem w364_0 : checkWitness 364 false false 68 = true := by decide +kernel
private theorem w364_2 : checkWitness 364 true false 68 = true := by decide +kernel
private theorem cases364 : checkFour 364 (68,0,68,0) = true := by
  simp only [checkFour, w364_0, w364_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one364 : Coverage 364 365 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases364)
private theorem w365_0 : checkWitness 365 false false 672 = true := by decide +kernel
private theorem w365_1 : checkWitness 365 false true 4764 = true := by decide +kernel
private theorem w365_2 : checkWitness 365 true false 663 = true := by decide +kernel
private theorem w365_3 : checkWitness 365 true true 4755 = true := by decide +kernel
private theorem cases365 : checkFour 365 (672,4764,663,4755) = true := by
  simp only [checkFour, w365_0, w365_1, w365_2, w365_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one365 : Coverage 365 366 := checkList_sound (ws:=[(672,4764,663,4755)]) (by simpa only [checkList, Bool.and_true] using cases365)
private theorem w366_0 : checkWitness 366 false false 8923 = true := by decide +kernel
private theorem w366_2 : checkWitness 366 true false 8919 = true := by decide +kernel
private theorem cases366 : checkFour 366 (8923,0,8919,0) = true := by
  simp only [checkFour, w366_0, w366_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one366 : Coverage 366 367 := checkList_sound (ws:=[(8923,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases366)
private theorem w367_0 : checkWitness 367 false false 660 = true := by decide +kernel
private theorem w367_1 : checkWitness 367 false true 4752 = true := by decide +kernel
private theorem w367_2 : checkWitness 367 true false 651 = true := by decide +kernel
private theorem w367_3 : checkWitness 367 true true 4743 = true := by decide +kernel
private theorem cases367 : checkFour 367 (660,4752,651,4743) = true := by
  simp only [checkFour, w367_0, w367_1, w367_2, w367_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one367 : Coverage 367 368 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases367)
private theorem w368_0 : checkWitness 368 false false 8890 = true := by decide +kernel
private theorem w368_2 : checkWitness 368 true false 8886 = true := by decide +kernel
private theorem cases368 : checkFour 368 (8890,0,8886,0) = true := by
  simp only [checkFour, w368_0, w368_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one368 : Coverage 368 369 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases368)
private theorem w369_0 : checkWitness 369 false false 68 = true := by decide +kernel
private theorem w369_2 : checkWitness 369 true false 68 = true := by decide +kernel
private theorem cases369 : checkFour 369 (68,0,68,0) = true := by
  simp only [checkFour, w369_0, w369_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one369 : Coverage 369 370 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases369)
private theorem w370_0 : checkWitness 370 false false 62 = true := by decide +kernel
private theorem w370_2 : checkWitness 370 true false 62 = true := by decide +kernel
private theorem cases370 : checkFour 370 (62,0,62,0) = true := by
  simp only [checkFour, w370_0, w370_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one370 : Coverage 370 371 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases370)
private theorem w371_0 : checkWitness 371 false false 623 = true := by decide +kernel
private theorem w371_1 : checkWitness 371 false true 4711 = true := by decide +kernel
private theorem w371_2 : checkWitness 371 true false 623 = true := by decide +kernel
private theorem w371_3 : checkWitness 371 true true 4711 = true := by decide +kernel
private theorem cases371 : checkFour 371 (623,4711,623,4711) = true := by
  simp only [checkFour, w371_0, w371_1, w371_2, w371_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one371 : Coverage 371 372 := checkList_sound (ws:=[(623,4711,623,4711)]) (by simpa only [checkList, Bool.and_true] using cases371)
private theorem w372_0 : checkWitness 372 false false 8906 = true := by decide +kernel
private theorem w372_2 : checkWitness 372 true false 8902 = true := by decide +kernel
private theorem cases372 : checkFour 372 (8906,0,8902,0) = true := by
  simp only [checkFour, w372_0, w372_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one372 : Coverage 372 373 := checkList_sound (ws:=[(8906,0,8902,0)]) (by simpa only [checkList, Bool.and_true] using cases372)
private theorem w373_0 : checkWitness 373 false false 8902 = true := by decide +kernel
private theorem w373_2 : checkWitness 373 true false 8898 = true := by decide +kernel
private theorem cases373 : checkFour 373 (8902,0,8898,0) = true := by
  simp only [checkFour, w373_0, w373_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one373 : Coverage 373 374 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases373)
private theorem w374_0 : checkWitness 374 false false 64 = true := by decide +kernel
private theorem w374_2 : checkWitness 374 true false 64 = true := by decide +kernel
private theorem cases374 : checkFour 374 (64,0,64,0) = true := by
  simp only [checkFour, w374_0, w374_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one374 : Coverage 374 375 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases374)
private theorem w375_0 : checkWitness 375 false false 530 = true := by decide +kernel
private theorem w375_1 : checkWitness 375 false true 4626 = true := by decide +kernel
private theorem w375_2 : checkWitness 375 true false 530 = true := by decide +kernel
private theorem w375_3 : checkWitness 375 true true 4626 = true := by decide +kernel
private theorem cases375 : checkFour 375 (530,4626,530,4626) = true := by
  simp only [checkFour, w375_0, w375_1, w375_2, w375_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one375 : Coverage 375 376 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases375)
private theorem w376_0 : checkWitness 376 false false 8933 = true := by decide +kernel
private theorem w376_2 : checkWitness 376 true false 8929 = true := by decide +kernel
private theorem cases376 : checkFour 376 (8933,0,8929,0) = true := by
  simp only [checkFour, w376_0, w376_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one376 : Coverage 376 377 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases376)
private theorem w377_0 : checkWitness 377 false false 662 = true := by decide +kernel
private theorem w377_1 : checkWitness 377 false true 4758 = true := by decide +kernel
private theorem w377_2 : checkWitness 377 true false 653 = true := by decide +kernel
private theorem w377_3 : checkWitness 377 true true 4749 = true := by decide +kernel
private theorem cases377 : checkFour 377 (662,4758,653,4749) = true := by
  simp only [checkFour, w377_0, w377_1, w377_2, w377_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one377 : Coverage 377 378 := checkList_sound (ws:=[(662,4758,653,4749)]) (by simpa only [checkList, Bool.and_true] using cases377)
private theorem w378_0 : checkWitness 378 false false 196 = true := by decide +kernel
private theorem w378_2 : checkWitness 378 true false 196 = true := by decide +kernel
private theorem cases378 : checkFour 378 (196,0,196,0) = true := by
  simp only [checkFour, w378_0, w378_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one378 : Coverage 378 379 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases378)
private theorem w379_0 : checkWitness 379 false false 607 = true := by decide +kernel
private theorem w379_1 : checkWitness 379 false true 4695 = true := by decide +kernel
private theorem w379_2 : checkWitness 379 true false 607 = true := by decide +kernel
private theorem w379_3 : checkWitness 379 true true 4695 = true := by decide +kernel
private theorem cases379 : checkFour 379 (607,4695,607,4695) = true := by
  simp only [checkFour, w379_0, w379_1, w379_2, w379_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one379 : Coverage 379 380 := checkList_sound (ws:=[(607,4695,607,4695)]) (by simpa only [checkList, Bool.and_true] using cases379)
private theorem w380_0 : checkWitness 380 false false 8948 = true := by decide +kernel
private theorem w380_2 : checkWitness 380 true false 8939 = true := by decide +kernel
private theorem cases380 : checkFour 380 (8948,0,8939,0) = true := by
  simp only [checkFour, w380_0, w380_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one380 : Coverage 380 381 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases380)
private theorem w381_0 : checkWitness 381 false false 68 = true := by decide +kernel
private theorem w381_2 : checkWitness 381 true false 68 = true := by decide +kernel
private theorem cases381 : checkFour 381 (68,0,68,0) = true := by
  simp only [checkFour, w381_0, w381_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one381 : Coverage 381 382 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases381)
private theorem w382_0 : checkWitness 382 false false 60 = true := by decide +kernel
private theorem w382_2 : checkWitness 382 true false 60 = true := by decide +kernel
private theorem cases382 : checkFour 382 (60,0,60,0) = true := by
  simp only [checkFour, w382_0, w382_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one382 : Coverage 382 383 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases382)
private theorem w383_0 : checkWitness 383 false false 613 = true := by decide +kernel
private theorem w383_1 : checkWitness 383 false true 4705 = true := by decide +kernel
private theorem w383_2 : checkWitness 383 true false 613 = true := by decide +kernel
private theorem w383_3 : checkWitness 383 true true 4705 = true := by decide +kernel
private theorem cases383 : checkFour 383 (613,4705,613,4705) = true := by
  simp only [checkFour, w383_0, w383_1, w383_2, w383_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one383 : Coverage 383 384 := checkList_sound (ws:=[(613,4705,613,4705)]) (by simpa only [checkList, Bool.and_true] using cases383)
theorem cover0352 : Coverage 352 384 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one352 one353) (Coverage.join one354 one355)) (Coverage.join (Coverage.join one356 one357) (Coverage.join one358 one359))) (Coverage.join (Coverage.join (Coverage.join one360 one361) (Coverage.join one362 one363)) (Coverage.join (Coverage.join one364 one365) (Coverage.join one366 one367)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one368 one369) (Coverage.join one370 one371)) (Coverage.join (Coverage.join one372 one373) (Coverage.join one374 one375))) (Coverage.join (Coverage.join (Coverage.join one376 one377) (Coverage.join one378 one379)) (Coverage.join (Coverage.join one380 one381) (Coverage.join one382 one383)))))
end NF185PA.Symbolic
