import NF182PA
import NumericalBound


open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.LiteralTM PA192.BusyBeaver

namespace NF182PA

/-- Halting within a fixed standard number of steps. -/
def byStep (k : Nat) : ArithmeticSentence := beforeF Reduced182.Table.machine Reduced182.Table.start k

/-- A finite live prefix yields a proof in object PA that the selected
182-state table did not halt within that many ticks. -/
theorem pa_no_halt_through (k : Nat)
    (live : (run Reduced182.Table.machine k (blank Reduced182.Table.start)).state ≠ none) :
    M6.PA.theory ⊢ ∼(byStep k) := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff, LogicalConnective.HomClass.map_neg]
  intro h
  obtain ⟨j,hj,stop⟩ := before_implies_halts _ _ k (V:=V) h
  obtain ⟨d,rfl⟩ := Nat.exists_eq_add_of_le hj
  exact live (halting_persists _ _ j d stop)

/-- A proposed standard time bound for the whole class, together with the
literal k-step live replay, would allow PA to prove nonhalting. -/
theorem pa_bound_implies_nonhalting (k : Nat)
    (live : (run Reduced182.Table.machine k (blank Reduced182.Table.start)).state ≠ none) :
    M6.PA.theory ⊢ upper 182 k 🡒 ∼H182 := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff, LogicalConnective.HomClass.map_imply, LogicalConnective.HomClass.map_neg]
  intro bound eventual
  have early := (upper_eval 182 k).mp bound Reduced182.Table.machine Reduced182.Table.start eventual
  obtain ⟨j,hj,stop⟩ := before_implies_halts _ _ k (V:=V) early
  obtain ⟨d,rfl⟩ := Nat.exists_eq_add_of_le hj
  exact live (halting_persists _ _ j d stop)

theorem pa_live_51157 : M6.PA.theory ⊢ ∼(byStep 51157) := by
  apply pa_no_halt_through
  rw [Reduced182.Boot.blank_safe_gap]
  exact Option.some_ne_none _

end NF182PA
#print axioms NF182PA.pa_bound_implies_nonhalting
#print axioms NF182PA.pa_live_51157
