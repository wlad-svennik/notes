module
public import DefinableIteration
public import ProofSupport

/-! A definable numerical maximal consistent theory inside an arbitrary PA model.
The input calculus is supplied with its finite-context proof checker and its
internal Hilbert proof operations. No second-order comprehension on V is used. -/
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace PA192.Numerals.FoundationRoute.Lindenbaum

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

structure Hilbert (V : Type) [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] where
  imp : V → V → V
  goal : V
  prov : V → V → Prop
  defined : Language.DefinableRel ℒₒᵣ prov
  assumption : ∀ s p, p ∈ s → prov s p
  monotone : ∀ s t, s ⊆ t → ∀ p, prov s p → prov t p
  mp : ∀ s a b, prov s (imp a b) → prov s a → prov s b
  weaken : ∀ s a b, prov s b → prov s (imp a b)
  deduction : ∀ s a b, prov (insert a s) b → prov s (imp a b)
  composition : ∀ s a b c, prov s (imp a b) → prov s (imp b c) → prov s (imp a c)
  peirce : ∀ s a b, prov s (imp (imp (imp a b) a) a)

namespace Hilbert
variable (D : Hilbert V)

noncomputable def advance (z : V) : V := open Classical in
  if D.prov (insert (π₁ z) (π₂ z)) D.goal
  then ⟪π₁ z+1, π₂ z⟫
  else ⟪π₁ z+1, insert (π₁ z) (π₂ z)⟫

instance advanceDef : Language.DefinableFunction₁ ℒₒᵣ D.advance := by
  classical
  let _ := D.defined
  apply Language.Definable.of_iff (Q := fun v : Fin 2 → V =>
    (D.prov (insert (π₁(v 1)) (π₂(v 1))) D.goal ∧ v 0=⟪π₁(v 1)+1, π₂(v 1)⟫) ∨
    (¬D.prov (insert (π₁(v 1)) (π₂(v 1))) D.goal ∧
      v 0=⟪π₁(v 1)+1, insert (π₁(v 1)) (π₂(v 1))⟫)) (by definability)
  intro v
  dsimp [advance]
  split <;> simp_all

noncomputable def state (n : V) := Iteration.value ⟪0,(∅ : V)⟫ D.advance n
noncomputable def stage (n : V) := π₂ (D.state n)

instance stateDef : Language.DefinableFunction₁ ℒₒᵣ D.state :=
  Iteration.valueDef _ _
instance stageDef : Language.DefinableFunction₁ ℒₒᵣ D.stage := by
  unfold stage
  definability

theorem clock (n : V) : π₁(D.state n)=n := by
  apply induction_of_arith (P:=fun t=>π₁(D.state t)=t)
  · apply arithPred_of_definable
    definability
  · change π₁(D.state 0) = (0:V)
    simp [state]
  · intro k ih
    change π₁(Iteration.value _ _ (k+1)) = k+1
    rw [Iteration.value_succ]
    change π₁(D.advance (D.state k)) = k+1
    unfold advance
    split <;> simp [ih]

@[simp] theorem stage_zero : D.stage 0 = ∅ := by simp [stage,state]

open Classical in
theorem stage_succ (n : V) : D.stage (n+1) =
    if D.prov (insert n (D.stage n)) D.goal then D.stage n else insert n (D.stage n) := by
  classical
  change π₂(Iteration.value _ _ (n+1)) = _
  rw [Iteration.value_succ]
  change π₂(D.advance (D.state n)) = _
  unfold advance
  rw [D.clock]
  change π₂(if D.prov (insert n (D.stage n)) D.goal then ⟪n+1,D.stage n⟫
       else ⟪n+1,insert n (D.stage n)⟫) = _
  split <;> simp

theorem stage_grows (n : V) : D.stage n ⊆ D.stage (n+1) := by
  classical
  rw [D.stage_succ]
  split
  · exact fun _ h => h
  · intro p hp
    simp [hp]

theorem stage_mono {n m : V} (hnm : n≤m) : D.stage n ⊆ D.stage m := by
  have grow : ∀ m : V, ¬m<n → ∀ p, p∈D.stage n → p∈D.stage m := by
    apply induction_of_arith
    · apply arithPred_of_definable
      definability
    · intro h p hp
      have hn : n=0 := le_zero_iff.mp (le_of_not_gt h)
      simpa only [hn,rob] using hp
    · intro m ih h p hp
      rcases lt_or_eq_of_le (le_of_not_gt h) with hl | he
      · exact D.stage_grows m (ih (not_lt_of_ge (lt_succ_iff_le.mp hl)) p hp)
      · simpa only [he] using hp
  exact grow m (not_lt_of_ge hnm)

theorem stages_consistent (hd : ¬D.prov ∅ D.goal) (n : V) : ¬D.prov (D.stage n) D.goal := by
  classical
  let _ := D.defined
  apply induction_of_arith (P := fun x => ¬D.prov (D.stage x) D.goal)
  · apply arithPred_of_definable
    definability
  · simpa only [rob,stage_zero] using hd
  · intro x ih
    change ¬D.prov (D.stage (x+1)) D.goal
    rw [D.stage_succ]
    split <;> assumption

def Holds (x : V) := ∃ n, D.prov (D.stage n) x

instance holdsDef : Language.DefinablePred ℒₒᵣ D.Holds := by
  let _ := D.defined
  unfold Holds
  definability

theorem goal_false (hd : ¬D.prov ∅ D.goal) : ¬D.Holds D.goal := by
  rintro ⟨n,h⟩
  exact D.stages_consistent hd n h

theorem sound {p : V} (h : D.prov ∅ p) : D.Holds p :=
  ⟨0, by simpa only [D.stage_zero] using h⟩

theorem holds_mp {a b : V} (h : D.Holds (D.imp a b)) (ha : D.Holds a) : D.Holds b := by
  obtain ⟨m,hm⟩ := h
  obtain ⟨n,hn⟩ := ha
  exact ⟨max m n,D.mp _ _ _ (D.monotone _ _ (D.stage_mono (le_max_left m n)) _ hm)
                           (D.monotone _ _ (D.stage_mono (le_max_right m n)) _ hn)⟩

theorem rejection {a : V} (ha : ¬D.Holds a) : D.Holds (D.imp a D.goal) := by
  classical
  by_cases bad : D.prov (insert a (D.stage a)) D.goal
  · exact ⟨a,D.deduction _ _ _ bad⟩
  · have ins : a∈D.stage (a+1) := by simp [D.stage_succ,bad]
    exact False.elim (ha ⟨a+1,D.assumption _ _ ins⟩)

theorem explosion (hd : ¬D.prov ∅ D.goal) (q : V) : D.Holds (D.imp D.goal q) := by
  classical
  by_contra no
  exact D.goal_false hd (D.holds_mp (D.sound (D.peirce _ D.goal q)) (D.rejection no))

theorem imp_iff (hd : ¬D.prov ∅ D.goal) (a b : V) :
    D.Holds (D.imp a b) ↔ (D.Holds a → D.Holds b) := by
  classical
  constructor
  · intro h ha
    exact D.holds_mp h ha
  · intro ab
    by_cases ha : D.Holds a
    · obtain ⟨n,hn⟩ := ab ha
      exact ⟨n,D.weaken _ _ _ hn⟩
    · obtain ⟨m,hm⟩ := D.rejection ha
      obtain ⟨n,hn⟩ := D.explosion hd b
      exact ⟨max m n,D.composition _ a D.goal b
        (D.monotone _ _ (D.stage_mono (le_max_left m n)) _ hm)
        (D.monotone _ _ (D.stage_mono (le_max_right m n)) _ hn)⟩

end Hilbert
end PA192.Numerals.FoundationRoute.Lindenbaum

#print axioms PA192.Numerals.FoundationRoute.Lindenbaum.Hilbert.imp_iff
