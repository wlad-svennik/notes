module
public import NF185OldEvaluation
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
namespace NF185PA.Old
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
variable (S : NF192.Ground.Signature V) (E : V → V → Prop)
variable [Language.DefinableFunction₂ ℒₒᵣ S.app] [Language.DefinableFunction₂ ℒₒᵣ S.h]
variable [Language.DefinableRel ℒₒᵣ E]
set_option maxHeartbeats 2500000

theorem goal_iff : holds S E goal ↔ E S.s S.q := by
  simp only [goal,s,holds_eq,obj_app,obj_q,NF192.Ground.Signature.s]

theorem ax_true (r : NF192.Ground.Rows S E) {p : V} (hp : Ax p) :
    holds S E p := by
  rcases hp with h|h|h|h|h|h|h|h|h
  · obtain ⟨a,b,c,u,_,rfl⟩ := h
    simp only [row0,holds_imp]
    tauto
  · obtain ⟨a,b,rfl⟩ := h
    simpa only [row1,holds_imp,holds_eq,s,obj_app,obj_q,NF192.Ground.Signature.s] using r.positive (obj S a) (obj S b)
  · obtain ⟨a,b,c,rfl⟩ := h
    simpa only [row2,holds_imp,holds_eq,obj_app] using r.argCongr (obj S a) (obj S b) (obj S c)
  · obtain ⟨a,b,rfl⟩ := h
    simpa only [row3,holds_eq,konst,obj_app,obj_h,NF192.Ground.Signature.k] using r.kLaw (obj S a) (obj S b)
  · obtain ⟨a,b,c,rfl⟩ := h
    simpa only [row4,holds_imp,holds_eq,obj_app] using r.funCongr (obj S a) (obj S b) (obj S c)
  · obtain ⟨a,b,c,rfl⟩ := h
    simpa only [row5,holds_eq,bcomb,s,konst,obj_app,obj_h,obj_q,NF192.Ground.Signature.s,
      NF192.Ground.Signature.k,NF192.Ground.Signature.b] using r.bLaw (obj S a) (obj S b) (obj S c)
  · obtain ⟨a,b,c,rfl⟩ := h
    simpa only [row6,holds_imp,holds_eq] using r.euclid (obj S a) (obj S b) (obj S c)
  · obtain ⟨a,b,rfl⟩ := h
    simpa only [row7,holds_imp,holds_eq,goal,bcomb,s,obj_app,obj_q,NF192.Ground.Signature.s,
      NF192.Ground.Signature.b] using r.negative (obj S a) (obj S b)
  · obtain ⟨a,b,rfl⟩ := h
    simpa only [row8,holds_imp,holds_eq,obj_app,obj_h] using r.ext (obj S a) (obj S b)

theorem model_excludes_old_proof (r : NF192.Ground.Rows S E) (no : ¬ E S.s S.q) :
    ¬ProofPool.Pr (∅ : V) goal := by
  intro h
  apply no
  apply (goal_iff S E).mp
  exact ProofPool.realize (R:=holds S E) (fun _ => ax_true S E r)
    (fun _ h => False.elim (by simp at h))
    (fun a b maj min => (holds_imp S E a b).mp maj min) h
end NF185PA.Old
#print axioms NF185PA.Old.model_excludes_old_proof
