import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2816_0 : checkWitness 2816 false false 8892 = true := by decide +kernel
private theorem w2816_2 : checkWitness 2816 true false 8888 = true := by decide +kernel
private theorem cases2816 : checkFour 2816 (8892,0,8888,0) = true := by
  simp only [checkFour, w2816_0, w2816_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2816 : Coverage 2816 2817 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2816)
private theorem w2817_0 : checkWitness 2817 false false 62 = true := by decide +kernel
private theorem w2817_2 : checkWitness 2817 true false 62 = true := by decide +kernel
private theorem cases2817 : checkFour 2817 (62,0,62,0) = true := by
  simp only [checkFour, w2817_0, w2817_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2817 : Coverage 2817 2818 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2817)
private theorem w2818_0 : checkWitness 2818 false false 54 = true := by decide +kernel
private theorem w2818_2 : checkWitness 2818 true false 54 = true := by decide +kernel
private theorem cases2818 : checkFour 2818 (54,0,54,0) = true := by
  simp only [checkFour, w2818_0, w2818_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2818 : Coverage 2818 2819 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases2818)
private theorem w2819_0 : checkWitness 2819 false false 635 = true := by decide +kernel
private theorem w2819_1 : checkWitness 2819 false true 4723 = true := by decide +kernel
private theorem w2819_2 : checkWitness 2819 true false 635 = true := by decide +kernel
private theorem w2819_3 : checkWitness 2819 true true 4723 = true := by decide +kernel
private theorem cases2819 : checkFour 2819 (635,4723,635,4723) = true := by
  simp only [checkFour, w2819_0, w2819_1, w2819_2, w2819_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2819 : Coverage 2819 2820 := checkList_sound (ws:=[(635,4723,635,4723)]) (by simpa only [checkList, Bool.and_true] using cases2819)
private theorem w2820_0 : checkWitness 2820 false false 8908 = true := by decide +kernel
private theorem w2820_2 : checkWitness 2820 true false 8904 = true := by decide +kernel
private theorem cases2820 : checkFour 2820 (8908,0,8904,0) = true := by
  simp only [checkFour, w2820_0, w2820_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2820 : Coverage 2820 2821 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases2820)
private theorem w2821_0 : checkWitness 2821 false false 8904 = true := by decide +kernel
private theorem w2821_2 : checkWitness 2821 true false 8900 = true := by decide +kernel
private theorem cases2821 : checkFour 2821 (8904,0,8900,0) = true := by
  simp only [checkFour, w2821_0, w2821_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2821 : Coverage 2821 2822 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2821)
private theorem w2822_0 : checkWitness 2822 false false 68 = true := by decide +kernel
private theorem w2822_2 : checkWitness 2822 true false 68 = true := by decide +kernel
private theorem cases2822 : checkFour 2822 (68,0,68,0) = true := by
  simp only [checkFour, w2822_0, w2822_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2822 : Coverage 2822 2823 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2822)
private theorem w2823_0 : checkWitness 2823 false false 8924 = true := by decide +kernel
private theorem w2823_2 : checkWitness 2823 true false 8920 = true := by decide +kernel
private theorem cases2823 : checkFour 2823 (8924,0,8920,0) = true := by
  simp only [checkFour, w2823_0, w2823_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2823 : Coverage 2823 2824 := checkList_sound (ws:=[(8924,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases2823)
private theorem w2824_0 : checkWitness 2824 false false 544 = true := by decide +kernel
private theorem w2824_1 : checkWitness 2824 false true 4640 = true := by decide +kernel
private theorem w2824_2 : checkWitness 2824 true false 544 = true := by decide +kernel
private theorem w2824_3 : checkWitness 2824 true true 4640 = true := by decide +kernel
private theorem cases2824 : checkFour 2824 (544,4640,544,4640) = true := by
  simp only [checkFour, w2824_0, w2824_1, w2824_2, w2824_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2824 : Coverage 2824 2825 := checkList_sound (ws:=[(544,4640,544,4640)]) (by simpa only [checkList, Bool.and_true] using cases2824)
private theorem w2825_0 : checkWitness 2825 false false 8939 = true := by decide +kernel
private theorem w2825_2 : checkWitness 2825 true false 8935 = true := by decide +kernel
private theorem cases2825 : checkFour 2825 (8939,0,8935,0) = true := by
  simp only [checkFour, w2825_0, w2825_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2825 : Coverage 2825 2826 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2825)
private theorem w2826_0 : checkWitness 2826 false false 670 = true := by decide +kernel
private theorem w2826_1 : checkWitness 2826 false true 4766 = true := by decide +kernel
private theorem w2826_2 : checkWitness 2826 true false 661 = true := by decide +kernel
private theorem w2826_3 : checkWitness 2826 true true 4757 = true := by decide +kernel
private theorem cases2826 : checkFour 2826 (670,4766,661,4757) = true := by
  simp only [checkFour, w2826_0, w2826_1, w2826_2, w2826_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2826 : Coverage 2826 2827 := checkList_sound (ws:=[(670,4766,661,4757)]) (by simpa only [checkList, Bool.and_true] using cases2826)
private theorem w2827_0 : checkWitness 2827 false false 202 = true := by decide +kernel
private theorem w2827_2 : checkWitness 2827 true false 202 = true := by decide +kernel
private theorem cases2827 : checkFour 2827 (202,0,202,0) = true := by
  simp only [checkFour, w2827_0, w2827_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2827 : Coverage 2827 2828 := checkList_sound (ws:=[(202,0,202,0)]) (by simpa only [checkList, Bool.and_true] using cases2827)
private theorem w2828_0 : checkWitness 2828 false false 625 = true := by decide +kernel
private theorem w2828_1 : checkWitness 2828 false true 4713 = true := by decide +kernel
private theorem w2828_2 : checkWitness 2828 true false 625 = true := by decide +kernel
private theorem w2828_3 : checkWitness 2828 true true 4713 = true := by decide +kernel
private theorem cases2828 : checkFour 2828 (625,4713,625,4713) = true := by
  simp only [checkFour, w2828_0, w2828_1, w2828_2, w2828_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2828 : Coverage 2828 2829 := checkList_sound (ws:=[(625,4713,625,4713)]) (by simpa only [checkList, Bool.and_true] using cases2828)
private theorem w2829_0 : checkWitness 2829 false false 8954 = true := by decide +kernel
private theorem w2829_2 : checkWitness 2829 true false 8945 = true := by decide +kernel
private theorem cases2829 : checkFour 2829 (8954,0,8945,0) = true := by
  simp only [checkFour, w2829_0, w2829_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2829 : Coverage 2829 2830 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2829)
private theorem w2830_0 : checkWitness 2830 false false 54 = true := by decide +kernel
private theorem w2830_2 : checkWitness 2830 true false 54 = true := by decide +kernel
private theorem cases2830 : checkFour 2830 (54,0,54,0) = true := by
  simp only [checkFour, w2830_0, w2830_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2830 : Coverage 2830 2831 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases2830)
private theorem w2831_0 : checkWitness 2831 false false 46 = true := by decide +kernel
private theorem w2831_2 : checkWitness 2831 true false 46 = true := by decide +kernel
private theorem cases2831 : checkFour 2831 (46,0,46,0) = true := by
  simp only [checkFour, w2831_0, w2831_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2831 : Coverage 2831 2832 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2831)
private theorem w2832_0 : checkWitness 2832 false false 631 = true := by decide +kernel
private theorem w2832_1 : checkWitness 2832 false true 4723 = true := by decide +kernel
private theorem w2832_2 : checkWitness 2832 true false 631 = true := by decide +kernel
private theorem w2832_3 : checkWitness 2832 true true 4723 = true := by decide +kernel
private theorem cases2832 : checkFour 2832 (631,4723,631,4723) = true := by
  simp only [checkFour, w2832_0, w2832_1, w2832_2, w2832_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2832 : Coverage 2832 2833 := checkList_sound (ws:=[(631,4723,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases2832)
private theorem w2833_0 : checkWitness 2833 false false 8892 = true := by decide +kernel
private theorem w2833_2 : checkWitness 2833 true false 8888 = true := by decide +kernel
private theorem cases2833 : checkFour 2833 (8892,0,8888,0) = true := by
  simp only [checkFour, w2833_0, w2833_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2833 : Coverage 2833 2834 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2833)
private theorem w2834_0 : checkWitness 2834 false false 46 = true := by decide +kernel
private theorem w2834_2 : checkWitness 2834 true false 46 = true := by decide +kernel
private theorem cases2834 : checkFour 2834 (46,0,46,0) = true := by
  simp only [checkFour, w2834_0, w2834_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2834 : Coverage 2834 2835 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2834)
private theorem w2835_0 : checkWitness 2835 false false 592 = true := by decide +kernel
private theorem w2835_1 : checkWitness 2835 false true 4688 = true := by decide +kernel
private theorem w2835_2 : checkWitness 2835 true false 592 = true := by decide +kernel
private theorem w2835_3 : checkWitness 2835 true true 4688 = true := by decide +kernel
private theorem cases2835 : checkFour 2835 (592,4688,592,4688) = true := by
  simp only [checkFour, w2835_0, w2835_1, w2835_2, w2835_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2835 : Coverage 2835 2836 := checkList_sound (ws:=[(592,4688,592,4688)]) (by simpa only [checkList, Bool.and_true] using cases2835)
private theorem w2836_0 : checkWitness 2836 false false 8927 = true := by decide +kernel
private theorem w2836_2 : checkWitness 2836 true false 8923 = true := by decide +kernel
private theorem cases2836 : checkFour 2836 (8927,0,8923,0) = true := by
  simp only [checkFour, w2836_0, w2836_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2836 : Coverage 2836 2837 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases2836)
private theorem w2837_0 : checkWitness 2837 false false 8962 = true := by decide +kernel
private theorem w2837_2 : checkWitness 2837 true false 8953 = true := by decide +kernel
private theorem cases2837 : checkFour 2837 (8962,0,8953,0) = true := by
  simp only [checkFour, w2837_0, w2837_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2837 : Coverage 2837 2838 := checkList_sound (ws:=[(8962,0,8953,0)]) (by simpa only [checkList, Bool.and_true] using cases2837)
private theorem w2838_0 : checkWitness 2838 false false 64 = true := by decide +kernel
private theorem w2838_2 : checkWitness 2838 true false 64 = true := by decide +kernel
private theorem cases2838 : checkFour 2838 (64,0,64,0) = true := by
  simp only [checkFour, w2838_0, w2838_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2838 : Coverage 2838 2839 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2838)
private theorem w2839_0 : checkWitness 2839 false false 674 = true := by decide +kernel
private theorem w2839_1 : checkWitness 2839 false true 4766 = true := by decide +kernel
private theorem w2839_2 : checkWitness 2839 true false 665 = true := by decide +kernel
private theorem w2839_3 : checkWitness 2839 true true 4757 = true := by decide +kernel
private theorem cases2839 : checkFour 2839 (674,4766,665,4757) = true := by
  simp only [checkFour, w2839_0, w2839_1, w2839_2, w2839_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2839 : Coverage 2839 2840 := checkList_sound (ws:=[(674,4766,665,4757)]) (by simpa only [checkList, Bool.and_true] using cases2839)
private theorem w2840_0 : checkWitness 2840 false false 8923 = true := by decide +kernel
private theorem w2840_2 : checkWitness 2840 true false 8919 = true := by decide +kernel
private theorem cases2840 : checkFour 2840 (8923,0,8919,0) = true := by
  simp only [checkFour, w2840_0, w2840_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2840 : Coverage 2840 2841 := checkList_sound (ws:=[(8923,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases2840)
private theorem w2841_0 : checkWitness 2841 false false 668 = true := by decide +kernel
private theorem w2841_1 : checkWitness 2841 false true 4760 = true := by decide +kernel
private theorem w2841_2 : checkWitness 2841 true false 659 = true := by decide +kernel
private theorem w2841_3 : checkWitness 2841 true true 4751 = true := by decide +kernel
private theorem cases2841 : checkFour 2841 (668,4760,659,4751) = true := by
  simp only [checkFour, w2841_0, w2841_1, w2841_2, w2841_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2841 : Coverage 2841 2842 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases2841)
private theorem w2842_0 : checkWitness 2842 false false 8892 = true := by decide +kernel
private theorem w2842_2 : checkWitness 2842 true false 8888 = true := by decide +kernel
private theorem cases2842 : checkFour 2842 (8892,0,8888,0) = true := by
  simp only [checkFour, w2842_0, w2842_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2842 : Coverage 2842 2843 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2842)
private theorem w2843_0 : checkWitness 2843 false false 52 = true := by decide +kernel
private theorem w2843_2 : checkWitness 2843 true false 52 = true := by decide +kernel
private theorem cases2843 : checkFour 2843 (52,0,52,0) = true := by
  simp only [checkFour, w2843_0, w2843_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2843 : Coverage 2843 2844 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2843)
private theorem w2844_0 : checkWitness 2844 false false 44 = true := by decide +kernel
private theorem w2844_2 : checkWitness 2844 true false 44 = true := by decide +kernel
private theorem cases2844 : checkFour 2844 (44,0,44,0) = true := by
  simp only [checkFour, w2844_0, w2844_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2844 : Coverage 2844 2845 := checkList_sound (ws:=[(44,0,44,0)]) (by simpa only [checkList, Bool.and_true] using cases2844)
private theorem w2845_0 : checkWitness 2845 false false 651 = true := by decide +kernel
private theorem w2845_1 : checkWitness 2845 false true 4723 = true := by decide +kernel
private theorem w2845_2 : checkWitness 2845 true false 651 = true := by decide +kernel
private theorem w2845_3 : checkWitness 2845 true true 4723 = true := by decide +kernel
private theorem cases2845 : checkFour 2845 (651,4723,651,4723) = true := by
  simp only [checkFour, w2845_0, w2845_1, w2845_2, w2845_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2845 : Coverage 2845 2846 := checkList_sound (ws:=[(651,4723,651,4723)]) (by simpa only [checkList, Bool.and_true] using cases2845)
private theorem w2846_0 : checkWitness 2846 false false 8908 = true := by decide +kernel
private theorem w2846_2 : checkWitness 2846 true false 8904 = true := by decide +kernel
private theorem cases2846 : checkFour 2846 (8908,0,8904,0) = true := by
  simp only [checkFour, w2846_0, w2846_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2846 : Coverage 2846 2847 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases2846)
private theorem w2847_0 : checkWitness 2847 false false 8904 = true := by decide +kernel
private theorem w2847_2 : checkWitness 2847 true false 8900 = true := by decide +kernel
private theorem cases2847 : checkFour 2847 (8904,0,8900,0) = true := by
  simp only [checkFour, w2847_0, w2847_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2847 : Coverage 2847 2848 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2847)
theorem cover2816 : Coverage 2816 2848 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2816 one2817) (Coverage.join one2818 one2819)) (Coverage.join (Coverage.join one2820 one2821) (Coverage.join one2822 one2823))) (Coverage.join (Coverage.join (Coverage.join one2824 one2825) (Coverage.join one2826 one2827)) (Coverage.join (Coverage.join one2828 one2829) (Coverage.join one2830 one2831)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2832 one2833) (Coverage.join one2834 one2835)) (Coverage.join (Coverage.join one2836 one2837) (Coverage.join one2838 one2839))) (Coverage.join (Coverage.join (Coverage.join one2840 one2841) (Coverage.join one2842 one2843)) (Coverage.join (Coverage.join one2844 one2845) (Coverage.join one2846 one2847)))))
end NF182PA.Symbolic
