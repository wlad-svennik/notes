import InternalFold
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Numerals.FoundationRoute
namespace NF192.Internal
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

instance plainTag : Language.DefinableFunction₁ ℒₒᵣ (fstIdx : V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := fstIdxDef.val) ⟨(fstIdx_defined (V := V)).df⟩
instance plainPayload : Language.DefinableFunction₁ ℒₒᵣ (sndIdx : V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := sndIdxDef.val) ⟨(sndIdx_defined (V := V)).df⟩

noncomputable def pick (tag i a b : V) : V := open Classical in if i=tag then a else b
instance pickDef (tag : V) : Language.DefinableFunction₃ ℒₒᵣ (pick tag) := by
  classical
  apply Language.Definable.of_iff (Q:=fun v : Fin 4 → V =>
    (v 1=tag ∧ v 0=v 2) ∨ (v 1≠tag ∧ v 0=v 3)) (by definability)
  intro v;dsimp [pick];split <;> simp_all

/-- Representatives of the fixed closure operations. The functions select
a witness; their correctness on numbers is expressed separately. -/
structure Operations (V : Type) where
  head : V
  tail : V
  zero : V
  succ : V
  add : V
  mul : V
  less : V
  invTail : V
  comp : V → V → V
  fork : V → V → V
  common : V → V → V
  cap : V → V → V
  neg : V → V
class DefinedOps (o : Operations V) : Prop where
  comp : Language.DefinableFunction₂ ℒₒᵣ o.comp
  fork : Language.DefinableFunction₂ ℒₒᵣ o.fork
  common : Language.DefinableFunction₂ ℒₒᵣ o.common
  cap : Language.DefinableFunction₂ ℒₒᵣ o.cap
  neg : Language.DefinableFunction₁ ℒₒᵣ o.neg

attribute [instance] DefinedOps.comp DefinedOps.fork DefinedOps.common DefinedOps.cap DefinedOps.neg
namespace Operations
variable (o : Operations V) [DefinedOps o]

private instance boundStep : Language.DefinableFunction₁ ℒₒᵣ (o.comp o.tail) := by
  change Language.DefinableFunction₁ ℒₒᵣ (fun r => o.comp o.tail r)
  definability
noncomputable def getter (i : V) := Iteration.value o.head (o.comp o.tail) i
instance getterDef : Language.DefinableFunction₁ ℒₒᵣ o.getter := Iteration.valueDef _ _
@[simp] theorem getter_zero : o.getter 0=o.head := Iteration.value_zero _ _
theorem getter_succ (i : V) : o.getter (i+1)=o.comp o.tail (o.getter i) := Iteration.value_succ _ _ i

noncomputable def termStep (c t : V) : V :=
  let tag := fstIdx c; let payload := sndIdx c
  let arity := π₁ payload;let arg := π₂ payload;let symbol := π₁ arg;let args := π₂ arg
  let left := t.[args.[0]];let right := t.[args.[1]]
  pick 0 tag (o.comp o.head (o.getter payload)) (pick 1 tag (o.comp o.tail (o.getter payload))
    (pick 0 arity (pick 0 symbol o.zero (o.comp o.zero o.succ))
      (o.comp (o.fork left right) (pick 0 symbol o.add o.mul))))
instance termStepDef : Language.DefinableFunction₂ ℒₒᵣ o.termStep := by
  unfold termStep;definability
noncomputable def termRep (c : V) : V := fold o.termStep c
instance termRepDef : Language.DefinableFunction₁ ℒₒᵣ o.termRep := foldDef o.termStep

noncomputable def formulaStep (c t : V) : V :=
  let tag := fstIdx c;let arg := sndIdx c;let left := π₁ arg;let right := π₂ arg
  let symbol := π₁ right;let args := π₂ right
  let lterm := o.termRep args.[0];let rterm := o.termRep args.[1]
  let atom := o.common (pick 0 symbol lterm (o.comp lterm o.less)) rterm
  let top := o.common o.zero o.zero
  pick 0 tag atom (pick 1 tag (o.neg atom) (pick 2 tag top (pick 3 tag (o.neg top)
    (pick 4 tag (o.cap t.[left] t.[right]) (pick 5 tag (o.neg (o.cap (o.neg t.[left]) (o.neg t.[right])))
      (pick 6 tag (o.neg (o.comp o.invTail (o.neg t.[arg]))) (o.comp o.invTail t.[arg])))))))
instance formulaStepDef : Language.DefinableFunction₂ ℒₒᵣ o.formulaStep := by
  unfold formulaStep;definability
noncomputable def formulaRep (c : V) : V := fold o.formulaStep c
instance formulaRepDef : Language.DefinableFunction₁ ℒₒᵣ o.formulaRep := foldDef o.formulaStep

end Operations
#print axioms Operations.formulaRepDef
end NF192.Internal
