module
public import RewriteData

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding FFL.FirstOrder.Arithmetic.Bootstrapping

namespace PA192.SyntaxTruth
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

structure FormulaMap (V : Type) [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] where
  fm : V → V → V
  tm : V → TermMap V
  lift : V → V
  df : Language.DefinableFunction₂ ℒₒᵣ fm
  atRel : ∀ w {k r v}, (ℒₒᵣ).IsRel k r → IsUTermVec ℒₒᵣ k v →
    fm w (qqRel k r v)=qqRel k r ((tm w).vec k v)
  atNRel : ∀ w {k r v}, (ℒₒᵣ).IsRel k r → IsUTermVec ℒₒᵣ k v →
    fm w (qqNRel k r v)=qqNRel k r ((tm w).vec k v)
  atTop : ∀w, fm w qqVerum=qqVerum
  atBot : ∀w, fm w qqFalsum=qqFalsum
  atAnd : ∀ w {p q}, IsUFormula ℒₒᵣ p → IsUFormula ℒₒᵣ q →
    fm w (qqAnd p q)=qqAnd (fm w p) (fm w q)
  atOr : ∀ w {p q}, IsUFormula ℒₒᵣ p → IsUFormula ℒₒᵣ q →
    fm w (qqOr p q)=qqOr (fm w p) (fm w q)
  atAll : ∀ w {p}, IsUFormula ℒₒᵣ p → fm w (qqAll p)=qqAll (fm (lift w) p)
  atExs : ∀ w {p}, IsUFormula ℒₒᵣ p → fm w (qqExs p)=qqExs (fm (lift w) p)
attribute [instance] FormulaMap.df

namespace Semantics
variable (S : Semantics V) (r : FormulaMap V)

/-- A numerical parameter for the side conditions lets one transport a legal
substitution vector under repeated binding, to nonstandard depth. All six
arguments to a match are numbers in the ambient arithmetic. -/
structure Matching where
  M : V → V → V → V → V → V → Prop
  defined : Language.Definable ℒₒᵣ (fun v : Fin 6 → V => M (v 0) (v 1) (v 2) (v 3) (v 4) (v 5))
  bv : ∀{n w b f c g}, M n w b f c g → ∀i<n, S.ev ((r.tm w).t (qqBvar i)) b f=S.get c i
  fv : ∀{n w b f c g}, M n w b f c g → ∀i, S.ev ((r.tm w).t (qqFvar i)) b f=S.get g i
  up : ∀{n w b f c g x}, S.D b → S.D f → S.D c → S.D g → S.D x →
    M n w b f c g → M (n+1) (r.lift w) (S.push x b) f (S.push x c) g

variable (a : Matching S r)

@[aesop 3 (rule_sets := [Definability]) safe apply]
theorem matchingDef {d} (n w b f c g : (Fin d → V) → V)
    (hn : Language.DefinableFunction ℒₒᵣ n) (hw : Language.DefinableFunction ℒₒᵣ w)
    (hb : Language.DefinableFunction ℒₒᵣ b) (hf : Language.DefinableFunction ℒₒᵣ f)
    (hc : Language.DefinableFunction ℒₒᵣ c) (hg : Language.DefinableFunction ℒₒᵣ g) :
    Language.Definable ℒₒᵣ (fun z => a.M (n z) (w z) (b z) (f z) (c z) (g z)) := by
  exact Language.Definable.substitution (P:=fun v : Fin 6 → V => a.M (v 0) (v 1) (v 2) (v 3) (v 4) (v 5))
    (f:=![n,w,b,f,c,g]) a.defined (by simp [Fin.forall_fin_iff_zero_and_forall_succ, *])

theorem formula_transport {p n w b f c g : V} (hp : IsSemiformula ℒₒᵣ n p)
    (hb : S.D b) (hf : S.D f) (hc : S.D c) (hg : S.D g) (ok : a.M n w b f c g) :
    S.tr (r.fm w p) b f ↔ S.tr p c g := by
  let P := fun p => ∀ n w b f c g, IsSemiformula ℒₒᵣ n p →
    S.D b → S.D f → S.D c → S.D g → a.M n w b f c g → (S.tr (r.fm w p) b f ↔ S.tr p c g)
  apply strongInd P (by dsimp [P]; definability) _ p n w b f c g hp hb hf hc hg ok
  intro p ih n w b f c g hp hb hf hc hg ok
  have atoms {k h v : V} (legal : (ℒₒᵣ).IsRel k h) (hv : IsSemitermVec ℒₒᵣ k n v) :
      S.tr (qqRel k h ((r.tm w).vec k v)) b f ↔ S.tr (qqRel k h v) c g := by
    apply S.rel legal ((r.tm w).length hv.isUTerm) hv.lh hb hf hc hg
    intro i hi
    rw [(r.tm w).nth hv.isUTerm hi]
    exact S.term_transport (r.tm w) hb hf hc hg (a.bv ok) (a.fv ok) (hv.nth hi)
  rcases IsSemiformula.case_iff.mp hp with ⟨k,h,v,legal,hv,rfl⟩|⟨k,h,v,legal,hv,rfl⟩|rfl|rfl|
    ⟨u,v,hu,hv,rfl⟩|⟨u,v,hu,hv,rfl⟩|⟨u,hu,rfl⟩|⟨u,hu,rfl⟩
  · rw [r.atRel _ legal hv.isUTerm]; exact atoms legal hv
  · rw [r.atNRel _ legal hv.isUTerm,S.nrel legal ((r.tm w).length hv.isUTerm) hb hf,S.nrel legal hv.lh hc hg]
    exact not_congr (atoms legal hv)
  · rw [r.atTop]; exact iff_of_true (S.top hb hf) (S.top hc hg)
  · rw [r.atBot]; exact iff_of_false (S.bot hb hf) (S.bot hc hg)
  · rw [r.atAnd _ hu.isUFormula hv.isUFormula,S.and _ _ hb hf,S.and _ _ hc hg]
    exact and_congr (ih _ (by simp) _ _ _ _ _ _ hu hb hf hc hg ok)
      (ih _ (by simp) _ _ _ _ _ _ hv hb hf hc hg ok)
  · rw [r.atOr _ hu.isUFormula hv.isUFormula,S.or _ _ hb hf,S.or _ _ hc hg]
    exact or_congr (ih _ (by simp) _ _ _ _ _ _ hu hb hf hc hg ok)
      (ih _ (by simp) _ _ _ _ _ _ hv hb hf hc hg ok)
  · rw [r.atAll _ hu.isUFormula,S.all _ hb hf,S.all _ hc hg]
    apply forall_congr'; intro x
    exact forall_congr' (fun hx => ih u (by simp) _ _ _ _ _ _ hu (S.pushOK hx hb) hf (S.pushOK hx hc) hg (a.up hb hf hc hg hx ok))
  · rw [r.atExs _ hu.isUFormula,S.exs _ hb hf,S.exs _ hc hg]
    apply exists_congr; intro x
    exact and_congr_right (fun hx => ih u (by simp) _ _ _ _ _ _ hu (S.pushOK hx hb) hf (S.pushOK hx hc) hg (a.up hb hf hc hg hx ok))

end Semantics
end PA192.SyntaxTruth
#print axioms PA192.SyntaxTruth.Semantics.formula_transport
