import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w0_0 : checkWitness 0 false false 581 = true := by decide +kernel
private theorem w0_1 : checkWitness 0 false true 4677 = true := by decide +kernel
private theorem w0_2 : checkWitness 0 true false 581 = true := by decide +kernel
private theorem w0_3 : checkWitness 0 true true 4677 = true := by decide +kernel
private theorem cases0 : checkFour 0 (581,4677,581,4677) = true := by
  simp only [checkFour, w0_0, w0_1, w0_2, w0_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one0 : Coverage 0 1 := checkList_sound (ws:=[(581,4677,581,4677)]) (by simpa only [checkList, Bool.and_true] using cases0)
private theorem w1_0 : checkWitness 1 false false 222 = true := by decide +kernel
private theorem w1_2 : checkWitness 1 true false 222 = true := by decide +kernel
private theorem cases1 : checkFour 1 (222,0,222,0) = true := by
  simp only [checkFour, w1_0, w1_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1 : Coverage 1 2 := checkList_sound (ws:=[(222,0,222,0)]) (by simpa only [checkList, Bool.and_true] using cases1)
private theorem w2_0 : checkWitness 2 false false 8992 = true := by decide +kernel
private theorem w2_2 : checkWitness 2 true false 8988 = true := by decide +kernel
private theorem cases2 : checkFour 2 (8992,0,8988,0) = true := by
  simp only [checkFour, w2_0, w2_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2 : Coverage 2 3 := checkList_sound (ws:=[(8992,0,8988,0)]) (by simpa only [checkList, Bool.and_true] using cases2)
private theorem w3_0 : checkWitness 3 false false 682 = true := by decide +kernel
private theorem w3_1 : checkWitness 3 false true 4778 = true := by decide +kernel
private theorem cases3 : checkFour 3 (682,4778,0,0) = true := by
  simp only [checkFour, w3_0, w3_1, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one3 : Coverage 3 4 := checkList_sound (ws:=[(682,4778,0,0)]) (by simpa only [checkList, Bool.and_true] using cases3)
private theorem w4_0 : checkWitness 4 false false 8927 = true := by decide +kernel
private theorem w4_2 : checkWitness 4 true false 8923 = true := by decide +kernel
private theorem cases4 : checkFour 4 (8927,0,8923,0) = true := by
  simp only [checkFour, w4_0, w4_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one4 : Coverage 4 5 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases4)
private theorem w5_0 : checkWitness 5 false false 8990 = true := by decide +kernel
private theorem w5_2 : checkWitness 5 true false 8981 = true := by decide +kernel
private theorem cases5 : checkFour 5 (8990,0,8981,0) = true := by
  simp only [checkFour, w5_0, w5_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one5 : Coverage 5 6 := checkList_sound (ws:=[(8990,0,8981,0)]) (by simpa only [checkList, Bool.and_true] using cases5)
private theorem w6_0 : checkWitness 6 false false 48 = true := by decide +kernel
private theorem w6_2 : checkWitness 6 true false 48 = true := by decide +kernel
private theorem cases6 : checkFour 6 (48,0,48,0) = true := by
  simp only [checkFour, w6_0, w6_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one6 : Coverage 6 7 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases6)
private theorem w7_0 : checkWitness 7 false false 710 = true := by decide +kernel
private theorem w7_1 : checkWitness 7 false true 4794 = true := by decide +kernel
private theorem w7_2 : checkWitness 7 true false 701 = true := by decide +kernel
private theorem w7_3 : checkWitness 7 true true 4785 = true := by decide +kernel
private theorem cases7 : checkFour 7 (710,4794,701,4785) = true := by
  simp only [checkFour, w7_0, w7_1, w7_2, w7_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one7 : Coverage 7 8 := checkList_sound (ws:=[(710,4794,701,4785)]) (by simpa only [checkList, Bool.and_true] using cases7)
private theorem w8_0 : checkWitness 8 false false 8980 = true := by decide +kernel
private theorem w8_2 : checkWitness 8 true false 8976 = true := by decide +kernel
private theorem cases8 : checkFour 8 (8980,0,8976,0) = true := by
  simp only [checkFour, w8_0, w8_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one8 : Coverage 8 9 := checkList_sound (ws:=[(8980,0,8976,0)]) (by simpa only [checkList, Bool.and_true] using cases8)
private theorem w9_0 : checkWitness 9 false false 30 = true := by decide +kernel
private theorem w9_2 : checkWitness 9 true false 30 = true := by decide +kernel
private theorem cases9 : checkFour 9 (30,0,30,0) = true := by
  simp only [checkFour, w9_0, w9_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one9 : Coverage 9 10 := checkList_sound (ws:=[(30,0,30,0)]) (by simpa only [checkList, Bool.and_true] using cases9)
private theorem w10_0 : checkWitness 10 false false 595 = true := by decide +kernel
private theorem w10_1 : checkWitness 10 false true 4691 = true := by decide +kernel
private theorem w10_2 : checkWitness 10 true false 595 = true := by decide +kernel
private theorem w10_3 : checkWitness 10 true true 4691 = true := by decide +kernel
private theorem cases10 : checkFour 10 (595,4691,595,4691) = true := by
  simp only [checkFour, w10_0, w10_1, w10_2, w10_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one10 : Coverage 10 11 := checkList_sound (ws:=[(595,4691,595,4691)]) (by simpa only [checkList, Bool.and_true] using cases10)
private theorem w11_0 : checkWitness 11 false false 8959 = true := by decide +kernel
private theorem w11_2 : checkWitness 11 true false 8955 = true := by decide +kernel
private theorem cases11 : checkFour 11 (8959,0,8955,0) = true := by
  simp only [checkFour, w11_0, w11_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one11 : Coverage 11 12 := checkList_sound (ws:=[(8959,0,8955,0)]) (by simpa only [checkList, Bool.and_true] using cases11)
private theorem w12_0 : checkWitness 12 false false 690 = true := by decide +kernel
private theorem w12_1 : checkWitness 12 false true 4786 = true := by decide +kernel
private theorem w12_2 : checkWitness 12 true false 681 = true := by decide +kernel
private theorem w12_3 : checkWitness 12 true true 4777 = true := by decide +kernel
private theorem cases12 : checkFour 12 (690,4786,681,4777) = true := by
  simp only [checkFour, w12_0, w12_1, w12_2, w12_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one12 : Coverage 12 13 := checkList_sound (ws:=[(690,4786,681,4777)]) (by simpa only [checkList, Bool.and_true] using cases12)
private theorem w13_0 : checkWitness 13 false false 214 = true := by decide +kernel
private theorem w13_2 : checkWitness 13 true false 214 = true := by decide +kernel
private theorem cases13 : checkFour 13 (214,0,214,0) = true := by
  simp only [checkFour, w13_0, w13_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one13 : Coverage 13 14 := checkList_sound (ws:=[(214,0,214,0)]) (by simpa only [checkList, Bool.and_true] using cases13)
private theorem w14_0 : checkWitness 14 false false 645 = true := by decide +kernel
private theorem w14_1 : checkWitness 14 false true 4733 = true := by decide +kernel
private theorem w14_2 : checkWitness 14 true false 645 = true := by decide +kernel
private theorem w14_3 : checkWitness 14 true true 4733 = true := by decide +kernel
private theorem cases14 : checkFour 14 (645,4733,645,4733) = true := by
  simp only [checkFour, w14_0, w14_1, w14_2, w14_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one14 : Coverage 14 15 := checkList_sound (ws:=[(645,4733,645,4733)]) (by simpa only [checkList, Bool.and_true] using cases14)
private theorem w15_0 : checkWitness 15 false false 8974 = true := by decide +kernel
private theorem w15_2 : checkWitness 15 true false 8965 = true := by decide +kernel
private theorem cases15 : checkFour 15 (8974,0,8965,0) = true := by
  simp only [checkFour, w15_0, w15_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one15 : Coverage 15 16 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases15)
private theorem w16_0 : checkWitness 16 false false 34 = true := by decide +kernel
private theorem w16_2 : checkWitness 16 true false 34 = true := by decide +kernel
private theorem cases16 : checkFour 16 (34,0,34,0) = true := by
  simp only [checkFour, w16_0, w16_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one16 : Coverage 16 17 := checkList_sound (ws:=[(34,0,34,0)]) (by simpa only [checkList, Bool.and_true] using cases16)
private theorem w17_0 : checkWitness 17 false false 26 = true := by decide +kernel
private theorem w17_2 : checkWitness 17 true false 26 = true := by decide +kernel
private theorem cases17 : checkFour 17 (26,0,26,0) = true := by
  simp only [checkFour, w17_0, w17_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one17 : Coverage 17 18 := checkList_sound (ws:=[(26,0,26,0)]) (by simpa only [checkList, Bool.and_true] using cases17)
private theorem w18_0 : checkWitness 18 false false 661 = true := by decide +kernel
private theorem w18_1 : checkWitness 18 false true 4749 = true := by decide +kernel
private theorem w18_2 : checkWitness 18 true false 661 = true := by decide +kernel
private theorem w18_3 : checkWitness 18 true true 4749 = true := by decide +kernel
private theorem cases18 : checkFour 18 (661,4749,661,4749) = true := by
  simp only [checkFour, w18_0, w18_1, w18_2, w18_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one18 : Coverage 18 19 := checkList_sound (ws:=[(661,4749,661,4749)]) (by simpa only [checkList, Bool.and_true] using cases18)
private theorem w19_0 : checkWitness 19 false false 8935 = true := by decide +kernel
private theorem w19_2 : checkWitness 19 true false 8931 = true := by decide +kernel
private theorem cases19 : checkFour 19 (8935,0,8931,0) = true := by
  simp only [checkFour, w19_0, w19_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one19 : Coverage 19 20 := checkList_sound (ws:=[(8935,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases19)
private theorem w20_0 : checkWitness 20 false false 26 = true := by decide +kernel
private theorem w20_2 : checkWitness 20 true false 26 = true := by decide +kernel
private theorem cases20 : checkFour 20 (26,0,26,0) = true := by
  simp only [checkFour, w20_0, w20_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one20 : Coverage 20 21 := checkList_sound (ws:=[(26,0,26,0)]) (by simpa only [checkList, Bool.and_true] using cases20)
private theorem w21_0 : checkWitness 21 false false 710 = true := by decide +kernel
private theorem w21_1 : checkWitness 21 false true 4806 = true := by decide +kernel
private theorem w21_2 : checkWitness 21 true false 701 = true := by decide +kernel
private theorem w21_3 : checkWitness 21 true true 4797 = true := by decide +kernel
private theorem cases21 : checkFour 21 (710,4806,701,4797) = true := by
  simp only [checkFour, w21_0, w21_1, w21_2, w21_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one21 : Coverage 21 22 := checkList_sound (ws:=[(710,4806,701,4797)]) (by simpa only [checkList, Bool.and_true] using cases21)
private theorem w22_0 : checkWitness 22 false false 8976 = true := by decide +kernel
private theorem w22_2 : checkWitness 22 true false 8972 = true := by decide +kernel
private theorem cases22 : checkFour 22 (8976,0,8972,0) = true := by
  simp only [checkFour, w22_0, w22_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one22 : Coverage 22 23 := checkList_sound (ws:=[(8976,0,8972,0)]) (by simpa only [checkList, Bool.and_true] using cases22)
private theorem w23_0 : checkWitness 23 false false 32 = true := by decide +kernel
private theorem w23_2 : checkWitness 23 true false 32 = true := by decide +kernel
private theorem cases23 : checkFour 23 (32,0,32,0) = true := by
  simp only [checkFour, w23_0, w23_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one23 : Coverage 23 24 := checkList_sound (ws:=[(32,0,32,0)]) (by simpa only [checkList, Bool.and_true] using cases23)
private theorem w24_0 : checkWitness 24 false false 591 = true := by decide +kernel
private theorem w24_1 : checkWitness 24 false true 4687 = true := by decide +kernel
private theorem w24_2 : checkWitness 24 true false 591 = true := by decide +kernel
private theorem w24_3 : checkWitness 24 true true 4687 = true := by decide +kernel
private theorem cases24 : checkFour 24 (591,4687,591,4687) = true := by
  simp only [checkFour, w24_0, w24_1, w24_2, w24_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one24 : Coverage 24 25 := checkList_sound (ws:=[(591,4687,591,4687)]) (by simpa only [checkList, Bool.and_true] using cases24)
private theorem w25_0 : checkWitness 25 false false 8955 = true := by decide +kernel
private theorem w25_2 : checkWitness 25 true false 8951 = true := by decide +kernel
private theorem cases25 : checkFour 25 (8955,0,8951,0) = true := by
  simp only [checkFour, w25_0, w25_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one25 : Coverage 25 26 := checkList_sound (ws:=[(8955,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases25)
private theorem w26_0 : checkWitness 26 false false 686 = true := by decide +kernel
private theorem w26_1 : checkWitness 26 false true 4782 = true := by decide +kernel
private theorem w26_2 : checkWitness 26 true false 677 = true := by decide +kernel
private theorem w26_3 : checkWitness 26 true true 4773 = true := by decide +kernel
private theorem cases26 : checkFour 26 (686,4782,677,4773) = true := by
  simp only [checkFour, w26_0, w26_1, w26_2, w26_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one26 : Coverage 26 27 := checkList_sound (ws:=[(686,4782,677,4773)]) (by simpa only [checkList, Bool.and_true] using cases26)
private theorem w27_0 : checkWitness 27 false false 212 = true := by decide +kernel
private theorem w27_2 : checkWitness 27 true false 212 = true := by decide +kernel
private theorem cases27 : checkFour 27 (212,0,212,0) = true := by
  simp only [checkFour, w27_0, w27_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one27 : Coverage 27 28 := checkList_sound (ws:=[(212,0,212,0)]) (by simpa only [checkList, Bool.and_true] using cases27)
private theorem w28_0 : checkWitness 28 false false 641 = true := by decide +kernel
private theorem w28_1 : checkWitness 28 false true 4729 = true := by decide +kernel
private theorem w28_2 : checkWitness 28 true false 641 = true := by decide +kernel
private theorem w28_3 : checkWitness 28 true true 4729 = true := by decide +kernel
private theorem cases28 : checkFour 28 (641,4729,641,4729) = true := by
  simp only [checkFour, w28_0, w28_1, w28_2, w28_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one28 : Coverage 28 29 := checkList_sound (ws:=[(641,4729,641,4729)]) (by simpa only [checkList, Bool.and_true] using cases28)
private theorem w29_0 : checkWitness 29 false false 8970 = true := by decide +kernel
private theorem w29_2 : checkWitness 29 true false 8961 = true := by decide +kernel
private theorem cases29 : checkFour 29 (8970,0,8961,0) = true := by
  simp only [checkFour, w29_0, w29_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one29 : Coverage 29 30 := checkList_sound (ws:=[(8970,0,8961,0)]) (by simpa only [checkList, Bool.and_true] using cases29)
private theorem w30_0 : checkWitness 30 false false 36 = true := by decide +kernel
private theorem w30_2 : checkWitness 30 true false 36 = true := by decide +kernel
private theorem cases30 : checkFour 30 (36,0,36,0) = true := by
  simp only [checkFour, w30_0, w30_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one30 : Coverage 30 31 := checkList_sound (ws:=[(36,0,36,0)]) (by simpa only [checkList, Bool.and_true] using cases30)
private theorem w31_0 : checkWitness 31 false false 28 = true := by decide +kernel
private theorem w31_2 : checkWitness 31 true false 28 = true := by decide +kernel
private theorem cases31 : checkFour 31 (28,0,28,0) = true := by
  simp only [checkFour, w31_0, w31_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one31 : Coverage 31 32 := checkList_sound (ws:=[(28,0,28,0)]) (by simpa only [checkList, Bool.and_true] using cases31)
theorem cover0000 : Coverage 0 32 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one0 one1) (Coverage.join one2 one3)) (Coverage.join (Coverage.join one4 one5) (Coverage.join one6 one7))) (Coverage.join (Coverage.join (Coverage.join one8 one9) (Coverage.join one10 one11)) (Coverage.join (Coverage.join one12 one13) (Coverage.join one14 one15)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one16 one17) (Coverage.join one18 one19)) (Coverage.join (Coverage.join one20 one21) (Coverage.join one22 one23))) (Coverage.join (Coverage.join (Coverage.join one24 one25) (Coverage.join one26 one27)) (Coverage.join (Coverage.join one28 one29) (Coverage.join one30 one31)))))
end NF182PA.Symbolic
