import CoreFacts
namespace NF192.Direct
universe u
variable {V : Type u}

def RelObj (mem : V → V → Prop) (D P C a b : V) :=
  ∃ k,mem k D ∧ Tri mem P a b k ∧ mem k C

def PairInj (N : V → Prop) (p : V → V → V → Prop) :=
  ∀x y v w t, N x ∧ N y ∧ N v ∧ N w ∧ N t → p x y t ∧ p v w t → x=v ∧ y=w

theorem corePairFn {mem : V → V → Prop} {D z S A M P : V} (h : CoreAt mem D z S A M P) :
    Fn2 (fun x=>mem x D) (Tri mem P) := h.2.2.2.2.1
theorem corePairInj {mem : V → V → Prop} {D z S A M P : V} (h : CoreAt mem D z S A M P) :
    PairInj (fun x=>mem x D) (Tri mem P) := h.2.2.2.2.2.1

theorem fromUnary {mem : V → V → Prop} {D : V} {f : V → Prop}
    (given : ∃ C,∀x,mem x C ↔ mem x D ∧ f x) :
    ∃ C,∀x,mem x D → (mem x C ↔ f x) := by
  obtain ⟨C,hC⟩ := given
  exact ⟨C,fun x hx => (hC x).trans ⟨And.right,fun h => ⟨hx,h⟩⟩⟩

theorem fromBinary {mem : V → V → Prop} {D P : V} {f : V → V → Prop}
    (hf : Fn2 (fun x=>mem x D) (Tri mem P)) (hi : PairInj (fun x=>mem x D) (Tri mem P))
    (given : ∃ C,∀k,mem k C ↔ ∃ u w, mem u D ∧ mem w D ∧ Tri mem P u w k ∧ f u w) :
    ∃ C,∀x y,mem x D ∧ mem y D → (RelObj mem D P C x y ↔ f x y) := by
  obtain ⟨C,hC⟩ := given
  refine ⟨C,fun x y n => ?_⟩
  constructor
  · rintro ⟨k,hk,p,h⟩
    obtain ⟨u,w,hu,hw,q,g⟩ := (hC k).mp h
    obtain ⟨rfl,rfl⟩ := hi _ _ _ _ _ ⟨n.1,n.2,hu,hw,hk⟩ ⟨p,q⟩
    exact g
  · intro h;obtain ⟨k,hk,p,_⟩ := hf x y n
    exact ⟨k,hk,p,(hC k).mpr ⟨x,y,n.1,n.2,p,h⟩⟩
end NF192.Direct
