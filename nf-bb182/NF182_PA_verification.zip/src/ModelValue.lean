module
public import ModelFold

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Numerals.FoundationRoute PA192.Literal
set_option maxHeartbeats 2200000
set_option maxRecDepth 6500
namespace PA192.ModelSearch

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

noncomputable def eqTest (a b : V) : V := if a=b then 0 else 1
instance eqTestDef : Language.DefinableFunction₂ ℒₒᵣ (eqTest (V:=V)) := by
  apply Language.Definable.of_iff (Q:=fun v : Fin 3→V =>
    (v 1=v 2 ∧ v 0=0) ∨ (v 1≠v 2 ∧ v 0=1)) (by definability)
  intro v
  by_cases h : v 1=v 2 <;> simp [eqTest,h]

noncomputable def selectValue (i a b c u : V) : V :=
  chooseZero (eqTest i 0) (row0 a b c u)
   (chooseZero (eqTest i 1) (row1 a b)
    (chooseZero (eqTest i 2) (row2 a b c)
     (chooseZero (eqTest i 3) (row3 a b)
      (chooseZero (eqTest i 4) (row4 a b c)
       (chooseZero (eqTest i 5) (row5 a b c)
        (chooseZero (eqTest i 6) (row6 a b c)
         (chooseZero (eqTest i 7) (row7 a b) (row8 a b))))))))

noncomputable def leafValue (w : V) : V :=
  let fields := right w
  let u := left fields
  let b := left (right fields)
  let c := left (right (right fields))
  let d := right (right (right fields))
  selectValue (left w) (u+d) b c u

instance leafValueDef : Language.DefinableFunction₁ ℒₒᵣ (leafValue (V:=V)) := by
  unfold leafValue selectValue row0 row1 row2 row3 row4 row5 row6 row7 row8
  aesop (config := {terminal := true,maxRuleApplications := 3800,maxRuleApplicationDepth := 100})
    (rule_sets := [Definability])

noncomputable def detachValue (minor major b : V) : V := chooseZero (eqTest major (imp minor b)) b 0
instance detachValueDef : Language.DefinableFunction₃ ℒₒᵣ (detachValue (V:=V)) := by
  unfold detachValue; definability

noncomputable def evalCode (n : V) := foldCode 0 leafValue detachValue n
instance evalDef : Language.DefinableFunction₁ ℒₒᵣ (evalCode (V:=V)) := by unfold evalCode; infer_instance

theorem meaning_select {i a b c u p : V} (h : rowMeaning i a b c u p) :
    selectValue i a b c u = p := by
  rcases h with h|h|h|h|h|h|h|h|h
  all_goals rcases h with ⟨rfl,rfl⟩
  all_goals norm_num [selectValue,eqTest,chooseZero]

theorem eval_leaf {n p : V} (h : Leaf n p) : evalCode n=p := by
  obtain ⟨u,b,c,d,i,rfl,hr⟩ := h
  unfold evalCode
  rw [fold_row]
  simpa only [leafValue,leafData,left_cantor,right_cantor] using meaning_select hr

theorem eval_detach (l r b : V) :
    evalCode (detachCode l r b) = if evalCode r = imp (evalCode l) b then b else 0 := by
  rw [evalCode,fold_detach]
  change detachValue (evalCode l) (evalCode r) b = _
  by_cases h : evalCode r = imp (evalCode l) b <;> simp [detachValue,chooseZero,eqTest,h]

theorem valid_code_evaluates {n p : V} (h : TreeProof n p) : evalCode n=p := by
  obtain ⟨t,vt,hr⟩ := h
  have all : ∀ rank : V, ∀ k q, k<rank → ⟪k,q⟫∈t → evalCode k=q := by
    apply modelInduct
    · definability
    · intro k q hk; exact False.elim ((not_lt_of_ge (show (0:V)≤k from zero_le)) hk)
    · intro rank ih k q hk mem
      rcases lt_or_eq_of_le (lt_succ_iff_le.mp hk) with less|same
      · exact ih k q less mem
      · subst k
        rcases vt rank q mem with leaf|⟨l,r,a,eq,hm,hM⟩
        · exact eval_leaf leaf
        · subst rank
          rw [eval_detach,ih r _ (major_lower ..) hM,ih l _ (minor_lower ..) hm]
          simp
  exact all (n+1) n p (by simp) hr

theorem pool_gives_numerical_code {p : V} (h : ProofPool.Pr (∅ : V) p) :
    ∃ n : V, evalCode n=p := by
  obtain ⟨n,hn⟩ := pool_to_tree h
  exact ⟨n,valid_code_evaluates hn⟩

end PA192.ModelSearch
#print axioms PA192.ModelSearch.pool_gives_numerical_code
