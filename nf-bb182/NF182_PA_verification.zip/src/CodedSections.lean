import NumericTruth
import ConcreteCoding
import InductionTruth
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding FFL.FirstOrder.Arithmetic.Bootstrapping
open NF192.Direct PA192.SyntaxTruth
namespace NF192.Internal
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {m : X→X→Prop}
variable {d : Presentation V X m} {D z S A B P : X} {o : Operations V} [DefinedOps o] {n : NumOps (Dom m D)}
variable (L : OpsLaws m D z S A B P n) (C : Correct d D z S A B P o)

theorem twoSlices (cl : ClosureAt m D z S A B P) (K b f : V) : ∃u:V,∀x:V,
    ((codingOf L C).sat u x ↔ (codingOf L C).tr K ((codingOf L C).push x b) f) := by
  let F := (codingOf L C).dec f;let B0 := (codingOf L C).dec b
  have slice := cl.2.2.2.2.2.2.2.2.2.2.2.2
  obtain ⟨q,hq⟩ := slice (d.dec (o.formulaRep K)) F.val F.2
  obtain ⟨r,hr⟩ := slice q B0.val B0.2
  obtain ⟨rc,rfl⟩ := d.onto r
  refine ⟨rc,?_⟩;intro x
  rw [(codingOf L C).tr_val,(codingOf L C).decPush]
  let v := (codingOf L C).dec x
  exact (hr v.val v.2).trans ((pair_test L _ v B0).trans
    ((hq (n.pair v B0).val (n.pair v B0).2).trans (pair_test L _ (n.pair v B0) F)))

theorem setsInd (ind : ∀Q,RepOne m D Q→InductiveOn n.z n.s Q→∀v,Q v) (u : V)
    (base : (codingOf L C).sat u ((codingOf L C).enc n.z))
    (step : ∀x,(codingOf L C).good x → (codingOf L C).sat u x → (codingOf L C).sat u ((codingOf L C).enc (n.s ((codingOf L C).dec x)))) :
    ∀x,(codingOf L C).good x → (codingOf L C).sat u x := by
  let P' := fun v : Dom m D=>m v.val (d.dec u)
  have s (v : Dom m D) : (codingOf L C).sat u ((codingOf L C).enc v) ↔ P' v := by
    change (algebraOf L C).sat u ((codingOf L C).dec ((codingOf L C).enc v))↔P' v
    rw [(codingOf L C).inv];rfl
  have h := ind P' ⟨d.dec u,fun _=>Iff.rfl⟩
    ⟨(s _).mp base,fun v hv=>(s _).mp (by simpa only [(codingOf L C).inv] using step ((codingOf L C).enc v) ((codingOf L C).goodEnc v) ((s v).mpr hv))⟩
  intro x _;exact h ((codingOf L C).dec x)

theorem quote_zeroTerm : (⌜zeroTerm⌝:V)=qqFunc 0 0 0 := by rfl
theorem quote_nextTerm : (⌜nextTerm⌝:V)=qqFunc 2 0 ?[qqBvar 0,qqFunc 0 1 0] := by
  change qqFunc ((2:Nat):V) 0 ?[qqBvar ((0:Nat):V),qqFunc 0 ((1:Nat):V) 0]=_
  simp

noncomputable def inductionSets (cl : ClosureAt m D z S A B P) (q : n.SatisfiesQ)
    (ind : ∀Q,RepOne m D Q→InductiveOn n.z n.s Q→∀v,Q v) : (codingOf L C).semantics.InductionSets where
  z:=(codingOf L C).enc n.z
  succ:=fun x=>(codingOf L C).enc (n.s ((codingOf L C).dec x))
  dz:=(codingOf L C).goodEnc _
  ds:=fun _=>(codingOf L C).goodEnc _
  zero:=by
    intro b f _ _;change (codingOf L C).ev (⌜zeroTerm⌝:V) b f=_
    rw [quote_zeroTerm,(codingOf L C).ev_val,(codingOf L C).termVal_zero]
  next:=by
    intro x b f hx _ _;change (codingOf L C).ev (⌜nextTerm⌝:V) ((codingOf L C).push x b) f=_
    rw [quote_nextTerm,(codingOf L C).ev_val,(codingOf L C).termVal_add,(codingOf L C).termVal_one,(codingOf L C).termVal_bvar,
      (algebraOf L C).headPair,(codingOf L C).getterVal_zero,(codingOf L C).decPush,(algebraOf L C).headPair,q.addS,q.add0]
  mem:=fun x u=>(codingOf L C).sat u x
  reps:=by
    intro K f _ _
    obtain ⟨u,h⟩ := twoSlices L C cl K ((codingOf L C).enc n.z) f
    exact ⟨u,fun x _=>h x⟩
  ind:=fun {u}=>setsInd L C ind u

#print axioms inductionSets
end NF192.Internal
