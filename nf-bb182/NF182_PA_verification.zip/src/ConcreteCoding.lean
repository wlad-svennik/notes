import AlgebraCoding
import ConcreteAlgebra
import GraphDef
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Direct
namespace NF192.Internal
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {m : X→X→Prop}
variable {d : Presentation V X m} {D z S A B P : X} {o : Operations V} {n : NumOps (Dom m D)}
noncomputable def codingOf (L : OpsLaws m D z S A B P n) (C : Correct d D z S A B P o) :
    Coding (algebraOf L C) where
  enc := fun v=>d.enc v.val
  dec := d.value n.z
  inv := d.valueEnc _
  normDef := d.cleanDef _
  pushDef := d.binaryDef n.z P n.pair L.pv
  satDef := by
    letI := d.memDef;letI := d.cleanDef n.z
    have h : Language.DefinableRel ℒₒᵣ (fun r v=>m (d.dec (d.clean n.z v)) (d.dec r)) :=
      Language.DefinableRel.comp (P:=fun x y=>m (d.dec x) (d.dec y))
        (f:=fun v:Fin 2→V=>d.clean n.z (v 1)) (g:=fun v=>v 0) (by definability) (by definability)
    apply h.of_iff
    intro e;change m (d.value n.z (e 1)).val (d.dec (e 0)) ↔ m (d.dec (d.enc (d.value n.z (e 1)).val)) (d.dec (e 0))
    rw [d.decEnc]
#print axioms codingOf
end NF192.Internal
