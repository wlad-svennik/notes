module
public import NumericalRows
public import ModelSourceFields

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM
namespace PA192.PhysicalModel

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 2500000

instance plainMod : Language.DefinableFunction₂ ℒₒᵣ ((· % ·) : V → V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := remDef.val) ⟨(rem_defined (V := V)).df⟩
instance plainDiv : Language.DefinableFunction₂ ℒₒᵣ ((· / ·) : V → V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := divDef.val) ⟨(div_defined (V := V)).df⟩

noncomputable def pack (s l r : V) : V := ⟪s,⟪l,r⟫⟫
noncomputable def state (c : V) := π₁ c
noncomputable def leftRay (c : V) := π₁ (π₂ c)
noncomputable def rightRay (c : V) := π₂ (π₂ c)

@[simp] theorem state_pack (s l r : V) : state (pack s l r)=s := by simp [pack,state]
@[simp] theorem left_pack (s l r : V) : leftRay (pack s l r)=l := by simp [pack,leftRay]
@[simp] theorem right_pack (s l r : V) : rightRay (pack s l r)=r := by simp [pack,rightRay]
@[simp] theorem pack_fields (c : V) : pack (state c) (leftRay c) (rightRay c)=c := by
  simp [pack,state,leftRay,rightRay]

instance packDef : Language.DefinableFunction₃ ℒₒᵣ (pack : V → V → V → V) := by
  unfold pack; definability
instance stateDef : Language.DefinableFunction₁ ℒₒᵣ (state : V → V) := by unfold state; definability
instance leftDef : Language.DefinableFunction₁ ℒₒᵣ (leftRay : V → V) := by unfold leftRay; definability
instance rightDef : Language.DefinableFunction₁ ℒₒᵣ (rightRay : V → V) := by unfold rightRay; definability

theorem unary_ite (p : V → Prop) [DecidablePred p] (f g : V → V)
    (hp : Language.DefinablePred ℒₒᵣ p) (hf : Language.DefinableFunction₁ ℒₒᵣ f)
    (hg : Language.DefinableFunction₁ ℒₒᵣ g) :
    Language.DefinableFunction₁ ℒₒᵣ (fun x => if p x then f x else g x) := by
  apply Language.Definable.of_iff (Q := fun v : Fin 2 → V =>
    (p (v 1) ∧ v 0=f (v 1)) ∨ (¬p (v 1) ∧ v 0=g (v 1)))
  · definability
  · intro v; by_cases h : p (v 1) <;> simp [h]

/-- Finite external table lookup with a definable internal control test. -/
noncomputable def pick : List (Fin n) → V → V → (Fin n → V) → V
  | [],_,default,_ => default
  | q::qs,key,default,f => if key=(q.val : V) then f q else pick qs key default f

theorem pick_def (qs : List (Fin n)) (key df : V → V) (fs : Fin n → V → V)
    (hk : Language.DefinableFunction₁ ℒₒᵣ key) (hd : Language.DefinableFunction₁ ℒₒᵣ df)
    (hf : ∀ q, Language.DefinableFunction₁ ℒₒᵣ (fs q)) :
    Language.DefinableFunction₁ ℒₒᵣ (fun c => pick qs (key c) (df c) (fun q => fs q c)) := by
  induction qs with
  | nil => exact hd
  | cons q qs ih =>
    let _ := hf q
    change Language.DefinableFunction₁ ℒₒᵣ (fun c => if key c=(q.val : V) then fs q c else _)
    exact unary_ite _ _ _ (by definability) (hf q) ih

theorem pick_mem (qs : List (Fin n)) (q : Fin n) (h : q ∈ qs) (df : V) (f : Fin n → V) :
    pick qs (q.val : V) df f = f q := by
  induction qs with
  | nil => simp at h
  | cons a l ih =>
    by_cases eq : q=a
    · subst q; simp [pick]
    · have hq : (q.val : V) ≠ (a.val : V) := by
        intro eqv
        apply eq; apply Fin.ext; exact_mod_cast eqv
      simp [pick,hq,ih ((List.mem_cons.mp h).resolve_left eq)]

theorem pick_none (qs : List (Fin n)) (key df : V) (f : Fin n → V)
    (h : ∀ q ∈ qs, key ≠ (q.val : V)) : pick qs key df f = df := by
  induction qs with
  | nil => rfl
  | cons q qs ih =>
    simp only [pick,if_neg (h q (by simp))]
    exact ih (fun a ha => h a (by simp [ha]))

theorem below_standard {x : V} {n : Nat} (h : x < (n : V)) : ∃ q : Fin n, x = (q.val : V) := by
  induction n with
  | zero => simp at h
  | succ k ih =>
    rw [Nat.cast_succ,lt_succ_iff_le] at h
    rcases lt_or_eq_of_le h with hk | he
    · obtain ⟨q,hq⟩ := ih hk
      exact ⟨q.castSucc,hq⟩
    · exact ⟨Fin.last k,he⟩

noncomputable def action (a : Instruction n) (c : V) : V :=
  pack (control a.next : V) (nextL a (leftRay c)) (nextR a (leftRay c) (rightRay c))

instance actionDef (a : Instruction n) : Language.DefinableFunction₁ ℒₒᵣ (action a : V → V) := by
  rcases a with ⟨w,d,q⟩
  cases d <;> unfold action nextL nextR <;> definability

noncomputable def switch (m : Machine n) (q : Fin n) (c : V) :=
  if rightRay c % 2 = 1 then action (m q true) c else action (m q false) c

noncomputable def rawStep (m : Machine n) (c : V) : V :=
  pick (List.finRange n) (state c) c (fun q => switch m q c)

instance rawStepDef (m : Machine n) : Language.DefinableFunction₁ ℒₒᵣ (rawStep m : V → V) := by
  apply pick_def
  · infer_instance
  · definability
  · intro q; exact unary_ite _ _ _ (by definability) (actionDef _) (actionDef _)

theorem switch_bit (m : Machine n) (q : Fin n) (b : Bool) (c : V)
    (hb : rightRay c % 2=(b.toNat : V)) : switch m q c=action (m q b) c := by
  cases b <;> simp [switch,hb]

theorem step_to_raw (m : Machine n) (c o : V)
    (h : Step m (state c) (leftRay c) (rightRay c) (state o) (leftRay o) (rightRay o)) :
    rawStep m c = o := by
  obtain ⟨q,b,row⟩ := h
  obtain ⟨hs,ht,hr,hl,he⟩ := (local_iff_quotient ..).mp row
  rw [rawStep,hs,pick_mem _ q (by simp),switch_bit m q b c hr]
  rw [action,←ht,←hl,←he,pack_fields]

theorem step_from_raw (m : Machine n) (c : V) (h : state c < (n : V)) :
    Step m (state c) (leftRay c) (rightRay c) (state (rawStep m c))
      (leftRay (rawStep m c)) (rightRay (rawStep m c)) := by
  obtain ⟨q,hq⟩ := below_standard h
  obtain eq | eq := mod_two (rightRay c)
  all_goals
    first
    | refine ⟨q,false,(local_iff_quotient m q false ..).mpr ?_⟩
      have raw : rawStep m c=action (m q false) c := by
        rw [rawStep,hq,pick_mem _ q (by simp),switch_bit m q false c (by simpa using eq)]
      simp [raw,action,hq,eq]
    | refine ⟨q,true,(local_iff_quotient m q true ..).mpr ?_⟩
      have raw : rawStep m c=action (m q true) c := by
        rw [rawStep,hq,pick_mem _ q (by simp),switch_bit m q true c (by simpa using eq)]
      simp [raw,action,hq,eq]

theorem step_code_le (m : Machine n) (c : V) (h : state c ≤ (n : V)) :
    state (rawStep m c) ≤ (n : V) := by
  rcases lt_or_eq_of_le h with lt | eq
  · obtain ⟨q,b,row⟩ := step_from_raw m c lt
    obtain ⟨_,ht,_⟩ := (local_iff_quotient ..).mp row
    rw [ht]
    cases e : (m q b).next with
    | none => simp [PA192.LiteralTM.control]
    | some p =>
      simp only [PA192.LiteralTM.control,Option.elim_some]
      exact_mod_cast Nat.le_of_lt p.isLt
  · have fixed : rawStep m c = c := by
      apply pick_none
      intro q _ hq
      have ne : ((n : Nat) : V) ≠ (q.val : V) := by exact_mod_cast (Nat.ne_of_lt q.isLt).symm
      exact ne (eq.symm.trans hq)
    rw [fixed,eq]

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.step_from_raw
#print axioms PA192.PhysicalModel.step_to_raw
