import ArithmeticSeed
import JensenCompleteness

open FFL FFL.FirstOrder NF192.Direct.Baseline
namespace FFL.FirstOrder.NF192Rows

theorem jensen_arithmeticSeed : 𝗡𝗙𝗨𝗜 ⊢ nativeFFL arithmeticSeed :=
  jensen_proves_set arithmeticSeed (fun _ _ M _=>native_seed M)

end FFL.FirstOrder.NF192Rows
#print axioms FFL.FirstOrder.NF192Rows.jensen_arithmeticSeed
