module
public import ModelSearchCodes
public import ModelCompiler

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
set_option maxHeartbeats 3500000
set_option maxRecDepth 8500
namespace PA192.ModelSearch.Enumeration
open RegisterFields RegisterCommands Words Compiler
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

noncomputable def assemble (cmd t : V) : V :=
  let i:=pi₁ cmd
  let a:=pi₂ cmd
  chooseZero i (cantor 0 (cantor a t)) (chooseZero (i-1) (cantor 1 (cantor a t))
    (literalAXInput (pi₁ a) (pi₁ (pi₂ a)) (pi₁ (pi₂ (pi₂ a))) (pi₂ (pi₂ (pi₂ a))) t))
instance assembleDef : Language.DefinableFunction₂ ℒₒᵣ (assemble (V:=V)) := by
  unfold assemble literalAXInput; definability

theorem tag_succ_sub_one (c : V) : c+2-1=c+1 := by
  have two : (2:V)=1+1 := by norm_num
  rw [two,←add_assoc]; simp

theorem parse_ax (u b d c t : V) : tail (literalAXInput u b d c t)=t := by
  have hp : c+2≠0 := by simp
  have hp' : c+2-1≠0 := by rw [tag_succ_sub_one]; simp
  simp [tail,literalAXInput,chooseZero,hp,hp',unread_zeroBatches]

theorem restore_tail (cmd t : V) : tail (assemble cmd t) = t := by
  dsimp only [assemble,chooseZero]
  split
  · simp [tail,chooseZero]
  · split
    · simp [tail,chooseZero]
    · exact parse_ax .. 

theorem tail_le_assemble (cmd t : V) : t≤assemble cmd t := by
  have h := tail_bounded (assemble cmd t)
  rwa [restore_tail] at h

noncomputable def addCommand (cmd t : V) := assemble cmd (t+1)
instance addCommandDef : Language.DefinableFunction₂ ℒₒᵣ (addCommand (V:=V)) := by
  unfold addCommand; definability

theorem run_reverse (f : V→V→V) [Language.DefinableFunction₂ ℒₒᵣ f] (w : V) :
    ∀ s t, run f (reverseOnto w s) t=run f s (run f (reverseOnto w 0) t) := by
  induction w using wordInduct with
  | dp => definability
  | z => simp
  | s c w ih =>
    intro s t
    simp only [rev_cons]
    rw [ih (cons c s) t,ih (cons c 0) t]
    simp

noncomputable def encode (w t : V) := run addCommand (reverseOnto w 0) t
instance encodeDef : Language.DefinableFunction₂ ℒₒᵣ (encode (V:=V)) := by unfold encode; definability
@[simp] theorem encode_zero (t : V) : encode 0 t=t := by simp [encode]
@[simp] theorem encode_cons (c w t : V) : encode (cons c w) t = assemble c (encode w t+1) := by
  simp only [encode,rev_cons,run_reverse addCommand w (cons c 0) t,run_cons,run_zero,addCommand]

theorem encode_lower (w : V) : ∀ t, t≤encode w t := by
  induction w using wordInduct with
  | dp => definability
  | z => simp
  | s c w ih =>
    intro t
    rw [encode_cons]
    exact le_trans (ih t) (le_trans (le_self_add) (tail_le_assemble ..))

theorem cursor_at_command (c w t k : V) :
    cursor ⟪k,encode (cons c w) t⟫ = ⟪k,encode w t⟫ := by
  rw [encode_cons]
  have h := restore_tail c (encode w t+1)
  have hp : tail (assemble c (encode w t+1))≠0 := by rw [h]; simp
  rw [cursor_pos hp,h]; simp

theorem encoded_prefix (w : V) : ∀ t k,
    iterate cursor (length w) ⟪k,encode w t⟫=⟪k,t⟫ := by
  induction w using wordInduct with
  | dp => definability
  | z => simp
  | s c w ih =>
    intro t k
    rw [length_cons,iterate_succ_left,cursor_at_command,ih]

theorem candidate_for_every_word (w start : V) : ∃ j : V,
    iterate cursor j ⟪start,start⟫=⟪encode w (start+1),encode w (start+1)⟫ ∧
    iterate cursor (j+length w) ⟪start,start⟫=⟪encode w (start+1),start+1⟫ := by
  let k := encode w (start+1)
  have le : start≤k := le_trans (show start≤start+1 from le_self_add) (encode_lower w _)
  have restore : start+(k-start)=k := by rw [add_comm,sub_add_self_of_le le]
  obtain ⟨j,h⟩ := reaches start (k-start)
  rw [restore] at h
  exact ⟨j,h,by rw [iterate_add,h]; exact encoded_prefix w _ _⟩

end PA192.ModelSearch.Enumeration
#print axioms PA192.ModelSearch.Enumeration.candidate_for_every_word
