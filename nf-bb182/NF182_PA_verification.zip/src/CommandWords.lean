module
public import ModelSourceFields

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
set_option maxHeartbeats 2500000
namespace PA192.ModelSearch.Words
open RegisterFields
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

noncomputable def cons (x xs : V) := cantor x xs + 1
noncomputable def hd (w : V) := left (w-1)
noncomputable def tl (w : V) := right (w-1)
instance consDef : Language.DefinableFunction₂ ℒₒᵣ (cons (V:=V)) := by unfold cons; definability
instance hdDef : Language.DefinableFunction₁ ℒₒᵣ (hd (V:=V)) := by unfold hd; definability
instance tlDef : Language.DefinableFunction₁ ℒₒᵣ (tl (V:=V)) := by unfold tl; definability

@[simp] theorem hd_cons (a b : V) : hd (cons a b)=a := by simp [hd,cons]
@[simp] theorem tl_cons (a b : V) : tl (cons a b)=b := by simp [tl,cons]
@[simp] theorem cons_ne_zero (a b : V) : cons a b ≠ 0 := by simp [cons]
theorem tl_smaller (a b : V) : b < cons a b := lt_succ_iff_le.mpr (cantor_ge_right _ _)
theorem canonical_succ (n : V) : cons (left n) (right n)=n+1 :=
  congrArg (·+1) (inversePair_correct n)

theorem wordInduct {P : V → Prop} (dp : Language.DefinablePred ℒₒᵣ P)
    (z : P 0) (s : ∀ a w, P w → P (cons a w)) : ∀ w, P w := by
  have all : ∀ n : V, ∀ k, k<n → P k := by
    apply modelInduct
    · letI := dp; definability
    · intro k hk; exact False.elim ((not_lt_of_ge (show (0:V)≤k from zero_le)) hk)
    · intro n ih k hk
      rcases lt_or_eq_of_le (lt_succ_iff_le.mp hk) with hl|e
      · exact ih _ hl
      · subst k
        by_cases atZero : n=0
        · simpa [atZero] using z
        · have pos : 0<n := lt_of_le_of_ne zero_le (Ne.symm atZero)
          have ge : 1≤n := by simpa using (succ_le_iff_lt.mpr pos)
          have shape : cons (left (n-1)) (right (n-1)) = n :=
            (canonical_succ (n-1)).trans (sub_add_self_of_le ge)
          exact Eq.mp (congrArg P shape) (s _ _ (ih _ (lt_of_lt_of_eq (tl_smaller _ _) shape)))
  exact fun n=>all (n+1) n (by simp)

noncomputable def lenStep (n hist : V) := chooseZero n 0 (znth hist (tl n)+1)
instance lenStepDef : Language.DefinableFunction₂ ℒₒᵣ (lenStep (V:=V)) := by unfold lenStep; definability
noncomputable def length (n : V) := entry lenStep n
instance lengthDef : Language.DefinableFunction₁ ℒₒᵣ (length (V:=V)) := by unfold length; infer_instance
@[simp] theorem length_zero : length (0:V)=0 := by change chooseZero 0 0 _ = _; simp [chooseZero]
@[simp] theorem length_cons (a b : V) : length (cons a b)=length b+1 := by
  unfold length entry lenStep
  simp only [chooseZero,cons_ne_zero,↓reduceIte,tl_cons]
  exact congrArg (·+1) (table_lookup lenStep (cons a b) b (tl_smaller a b))

section Runner
variable (f : V → V → V) [Language.DefinableFunction₂ ℒₒᵣ f]
noncomputable def cursorStep (s : V) : V :=
  let w:=pi₁ s
  chooseZero w s ⟪tl w,f (hd w) (pi₂ s)⟫
instance cursorStepDef : Language.DefinableFunction₁ ℒₒᵣ (cursorStep f) := by unfold cursorStep; definability

noncomputable def run (w s : V) : V := pi₂ (iterate (cursorStep f) (length w) ⟪w,s⟫)
instance runDef : Language.DefinableFunction₂ ℒₒᵣ (run f) := by unfold run; definability
@[simp] theorem run_zero (s : V) : run f 0 s=s := by simp [run]
@[simp] theorem run_cons (c w s : V) : run f (cons c w) s=run f w (f c s) := by
  unfold run
  rw [length_cons,iterate_succ_left]
  simp only [cursorStep,pi₁_pair,pi₂_pair,chooseZero,cons_ne_zero,↓reduceIte,hd_cons,tl_cons]
end Runner

noncomputable def reverseOnto (w s : V) := run cons w s
instance revDef : Language.DefinableFunction₂ ℒₒᵣ (reverseOnto (V:=V)) := by unfold reverseOnto; infer_instance
@[simp] theorem rev_zero (s : V) : reverseOnto 0 s=s := run_zero ..
@[simp] theorem rev_cons (c w s : V) : reverseOnto (cons c w) s=reverseOnto w (cons c s) := run_cons ..

theorem rev_comp (w : V) : ∀ s t, reverseOnto (reverseOnto w s) t =
    reverseOnto s (reverseOnto (reverseOnto w 0) t) := by
  induction w using wordInduct with
  | dp => definability
  | z => simp
  | s c w ih =>
    intro s t
    simp only [rev_cons]
    rw [ih (cons c s) t,ih (cons c 0) t,rev_cons,rev_cons,rev_zero]

noncomputable def append (w t : V) := reverseOnto (reverseOnto w 0) t
instance appendDef : Language.DefinableFunction₂ ℒₒᵣ (append (V:=V)) := by unfold append; definability
@[simp] theorem append_zero (t : V) : append 0 t=t := by simp [append]
@[simp] theorem append_cons (c w t : V) : append (cons c w) t = cons c (append w t) := by
  simp only [append,rev_cons,rev_comp w (cons c 0) t,rev_zero]

theorem append_assoc (w t u : V) : append (append w t) u = append w (append t u) := by
  induction w using wordInduct with
  | dp => definability
  | z => simp
  | s x w ih => simp [ih]

theorem run_append (f : V→V→V) [Language.DefinableFunction₂ ℒₒᵣ f] (w t : V) :
    ∀ s, run f (append w t) s = run f t (run f w s) := by
  induction w using wordInduct with
  | dp => definability
  | z => simp
  | s x w ih => intro s; simp [ih]

end PA192.ModelSearch.Words
#print axioms PA192.ModelSearch.Words.run_append
