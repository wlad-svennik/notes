import Canonical
import Mathlib.Tactic.FinCases
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Direct
namespace NF192.Internal.Presentation
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {m : X→X→Prop} (d : Presentation V X m)
private def triF : SetForm 4 := (.ex (.ex (.ex (.and (.ex (.ex (.and (.all (.iff (.mem 0 2) (.or (.eq 0 7) (.eq 0 7)))) (.and (.all (.iff (.mem 0 1) (.or (.eq 0 7) (.eq 0 8)))) (.all (.iff (.mem 0 5) (.or (.eq 0 2) (.eq 0 1)))))))) (.and (.ex (.ex (.and (.all (.iff (.mem 0 2) (.or (.eq 0 9) (.eq 0 9)))) (.and (.all (.iff (.mem 0 1) (.or (.eq 0 9) (.eq 0 9)))) (.all (.iff (.mem 0 4) (.or (.eq 0 2) (.eq 0 1)))))))) (.and (.ex (.ex (.and (.all (.iff (.mem 0 2) (.or (.eq 0 5) (.eq 0 5)))) (.and (.all (.iff (.mem 0 1) (.or (.eq 0 5) (.eq 0 4)))) (.all (.iff (.mem 0 3) (.or (.eq 0 2) (.eq 0 1)))))))) (.mem 0 3)))))))
private def edgeF : SetForm 3 := (.ex (.and (.mem 0 1) (.ex (.ex (.and (.all (.iff (.mem 0 2) (.or (.eq 0 5) (.eq 0 5)))) (.and (.all (.iff (.mem 0 1) (.or (.eq 0 5) (.eq 0 6)))) (.all (.iff (.mem 0 3) (.or (.eq 0 2) (.eq 0 1))))))))))
theorem triDef : Language.Definable ℒₒᵣ (fun v :Fin 4→V=>Tri m (d.dec (v 0)) (d.dec (v 1)) (d.dec (v 2)) (d.dec (v 3))) := d.formDef triF
theorem edgeDef : Language.DefinableRel₃ ℒₒᵣ (fun g x y=>Edge m (d.dec g) (d.dec x) (d.dec y)) := d.formDef edgeF

theorem triAtDef (P : X) : Language.DefinableRel₃ ℒₒᵣ (fun x y z=>Tri m P (d.dec x) (d.dec y) (d.dec z)) := by
  obtain ⟨p,rfl⟩ := d.onto P
  apply Language.Definable.of_iff (Language.Definable.substitution d.triDef (f:= ![(fun _ : Fin 3→V=>p),(fun v=>v 0),(fun v=>v 1),(fun v=>v 2)]) (by intro i;fin_cases i <;> simp <;> definability))
  intro v;rfl

theorem edgeAtDef (S : X) : Language.DefinableRel ℒₒᵣ (fun x y=>Edge m S (d.dec x) (d.dec y)) := by
  obtain ⟨s,rfl⟩ := d.onto S
  apply Language.Definable.of_iff (Language.Definable.substitution d.edgeDef (f:= ![(fun _ : Fin 2→V=>s),(fun v=>v 0),(fun v=>v 1)]) (by intro i;fin_cases i <;> simp <;> definability))
  intro v;rfl

/-- A decoded binary graph, functional on numbers, defines a total operation on
canonical numerical codes in every (possibly nonstandard) ambient PA model. -/
theorem binaryDef {D : X} (z : Dom m D) (G : X) (f : Dom m D → Dom m D → Dom m D)
    (graph : ∀ x y t : Dom m D, Tri m G x.val y.val t.val ↔ f x y=t) :
    Language.DefinableFunction₂ ℒₒᵣ (fun x y => d.enc (f (d.value z x) (d.value z y)).val) := by
  letI := d.goodDef D;letI := d.triAtDef G;letI := d.cleanDef z
  let fs : Fin 3 → (Fin 3→V) → V := ![(fun v=>d.clean z (v 1)),(fun v=>d.clean z (v 2)),(fun v=>v 0)]
  have ff : ∀i,Language.DefinableFunction ℒₒᵣ (fs i) := by intro i;fin_cases i <;> simp [fs] <;> definability
  apply Language.Definable.of_iff (Q:=fun v : Fin 3→V => d.Good D (v 0) ∧
    Tri m G (d.dec (d.clean z (v 1))) (d.dec (d.clean z (v 2))) (d.dec (v 0))) ((Language.Definable.retraction (d.goodDef D) (fun _=>0)).and (Language.Definable.substitution (d.triAtDef G) ff))
  intro v
  change v 0=d.enc (f (d.value z (v 1)) (d.value z (v 2))).val ↔ _
  simp only [clean,decEnc]
  constructor
  · intro e;rw [e,d.decEnc];exact ⟨d.encGood _,(graph _ _ _).mpr rfl⟩
  · rintro ⟨good,tri⟩
    let t : Dom m D := ⟨d.dec (v 0),good.2⟩
    have eq := (graph _ _ t).mp tri
    rw [eq];exact (d.enc_iff _ _).mpr ⟨good.1,rfl⟩

#print axioms binaryDef
end NF192.Internal.Presentation
