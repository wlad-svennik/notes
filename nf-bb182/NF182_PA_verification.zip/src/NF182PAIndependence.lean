import NF182PAInternalConsistency
import NF182PABounds

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open PA192.BusyBeaver

namespace NF182PA

/-- Explicit metatheoretic consistency assumption for the negative half. -/
theorem pa_cannot_prove_nonhalting_of_consistent (h : M6.PA.Consistent) :
    M6.PA.theory ⊬ ∼H182 :=
  M6.PA.unprovable_of_internal_consistency_implication _ h internal_consistency

/-- The standard model supplies the same external consistency assumption. -/
theorem pa_cannot_prove_nonhalting : M6.PA.theory ⊬ ∼H182 :=
  pa_cannot_prove_nonhalting_of_consistent inferInstance

/-- An individual live prefix and PA consistency suffice to exclude a proof
of that numeral as an upper bound. -/
theorem pa_no_upper_of_live (h : M6.PA.Consistent) (k : Nat)
    (live : (NF210.TM.run Reduced182.Table.machine k (NF210.TM.blank Reduced182.Table.start)).state ≠ none) :
    M6.PA.theory ⊬ upper 182 k := fun bound =>
  pa_cannot_prove_nonhalting_of_consistent h (pa_bound_implies_nonhalting k live ⨀ bound)

/-- Assuming NF consistency, PA settles neither sign of the literal halting
sentence and proves no individual numerical upper bound or exact value. -/
theorem pa_independence (nf : Consistent 𝗡𝗙) :
    (M6.PA.theory ⊬ ∼H182) ∧ (M6.PA.theory ⊬ H182) ∧
    ∀ k : Nat, (M6.PA.theory ⊬ upper 182 k) ∧
      (M6.PA.theory ⊬ fixedUpper (0 : Fin 182) k) ∧ (M6.PA.theory ⊬ value 182 k) :=
  independence_of_transfer internal_consistency nf

/-- The actual standard runtime Busy Beaver value exists; the equality to that
specific numeral and its negation are both unprovable in PA. -/
theorem true_value_independent (nf : Consistent 𝗡𝗙) :
    ∃ k : Nat, (Nat ⊧/![] (value 182 k)) ∧
      (M6.PA.theory ⊬ value 182 k) ∧ (M6.PA.theory ⊬ ∼(value 182 k)) :=
  true_value_of_transfer internal_consistency nf

end NF182PA

set_option pp.privateNames true
set_option pp.fullNames true
#print axioms NF182PA.pa_cannot_prove_nonhalting_of_consistent
#print axioms NF182PA.pa_cannot_prove_nonhalting
#print axioms NF182PA.pa_no_upper_of_live
#print axioms NF182PA.pa_independence
#print axioms NF182PA.true_value_independent
