module
public import Src182Run
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch PA192.ModelSearch.RegisterFields PA192.ModelSearch.Register182
namespace NF182PA.Boot
variable {V:Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
theorem step_eq (x:V) : step x = Registers.next x := rfl
theorem run_eq (t x : V) : run t x = iterate Registers.next t x := by
  induction t using modelInduct
  case defP => definability
  case zero => rw [run_zero,iterate_zero]
  case step t ih => rw [run_succ,iterate_succ,ih,step_eq]
end NF182PA.Boot
