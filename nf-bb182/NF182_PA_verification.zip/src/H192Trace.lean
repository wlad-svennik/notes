module
public import H192Rows
public import Foundation.FirstOrder.Arithmetic.HFS.Vec

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM

namespace PA192.LiteralTM

/-- The three Foundation HFS vectors store control, left ray and right ray;
right includes the scanned bit at its least significant position. -/
def traceF (machine : Machine n) (start : Fin n) : ArithmeticSentence :=
  “∃ ticks cs ls rs,
     !nthDef ↑start.val cs 0 ∧ !nthDef 0 ls 0 ∧ !nthDef 0 rs 0 ∧ !nthDef ↑n cs ticks ∧
     ∀ i < ticks, ∃ a b c d e f,
        !nthDef a cs i ∧ !nthDef b ls i ∧ !nthDef c rs i ∧
        !nthDef d cs (i + 1) ∧ !nthDef e ls (i + 1) ∧ !nthDef f rs (i + 1) ∧
        !(stepF machine) a b c d e f”

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

def Trace (machine : Machine n) (start : Fin n) (ticks cs ls rs : V) : Prop :=
  cs.[0]=(start.val : V) ∧ ls.[0]=0 ∧ rs.[0]=0 ∧ cs.[ticks]=(n : V) ∧
  ∀ i<ticks, Step machine cs.[i] ls.[i] rs.[i] cs.[i+1] ls.[i+1] rs.[i+1]

theorem traceF_eval (machine : Machine n) (start : Fin n) :
    (V ⊧/![] (traceF machine start)) ↔ ∃ ticks cs ls rs : V, Trace machine start ticks cs ls rs := by
  simp [traceF,Trace,nth_defined.df,stepF_eval,numeral_eq_natCast,eq_comm]

def H192 : ArithmeticSentence := traceF NF192.Selected.machine NF192.Selected.start

theorem H192_eval :
    (V ⊧/![] H192) ↔ ∃ ticks cs ls rs : V, Trace NF192.Selected.machine NF192.Selected.start ticks cs ls rs :=
  traceF_eval _ _

end PA192.LiteralTM

#print axioms PA192.LiteralTM.H192_eval
