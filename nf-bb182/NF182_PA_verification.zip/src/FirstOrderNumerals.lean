module
public import Init

/-!
The algebraic part of the numeral-embedding argument in any model of PA.
`IndOn` is needed only at the four listed first-order predicates. There is
no hypothesis of induction for arbitrary predicates on a nonstandard model.
-/
@[expose] public section

namespace PA192.Numerals

structure Robinson (A : Type u) where
  zero : A
  next : A → A
  add : A → A → A
  mul : A → A → A
  next_ne_zero : ∀ x, next x ≠ zero
  next_inj : ∀ {x y}, next x = next y → x = y
  zero_or_next : ∀ x, x = zero ∨ ∃ y, x = next y
  add_zero : ∀ x, add x zero = x
  add_next : ∀ x y, add x (next y) = next (add x y)
  mul_zero : ∀ x, mul x zero = zero
  mul_next : ∀ x y, mul x (next y) = add (mul x y) x

namespace Robinson

variable {V : Type u} {A : Type v}
variable (s : Robinson V) (t : Robinson A)

def le (a b : V) : Prop := ∃ z, s.add z a = b

def IndOn (P : V → Prop) : Prop :=
  P s.zero → (∀ n, P n → P (s.next n)) → ∀ n, P n

def AddAt (i : V → A) (n : V) : Prop :=
  ∀ x, i (s.add x n) = t.add (i x) (i n)

def MulAt (i : V → A) (n : V) : Prop :=
  ∀ x, i (s.mul x n) = t.mul (i x) (i n)

def InjAt (i : V → A) (n : V) : Prop :=
  ∀ x, i x = i n → x = n

def InitialAt (i : V → A) (n : V) : Prop :=
  ∀ a, t.le a (i n) → ∃ m, s.le m n ∧ i m = a

structure NumeralMap (i : V → A) : Prop where
  zero : i s.zero = t.zero
  next : ∀ n, i (s.next n) = t.next (i n)

structure InductionFor (i : V → A) : Prop where
  addition : s.IndOn (s.AddAt t i)
  multiplication : s.IndOn (s.MulAt t i)
  injectivity : s.IndOn (InjAt i)
  initiality : s.IndOn (s.InitialAt t i)

variable {s t} {i : V → A}

structure InitialEmbedding (s : Robinson V) (t : Robinson A) (i : V → A) : Prop where
  injective : ∀ {x y}, i x = i y → x = y
  zero : i s.zero = t.zero
  next : ∀ n, i (s.next n) = t.next (i n)
  add : ∀ a b, i (s.add a b) = t.add (i a) (i b)
  mul : ∀ a b, i (s.mul a b) = t.mul (i a) (i b)
  le_iff : ∀ a b, s.le a b ↔ t.le (i a) (i b)
  initial : ∀ b a, t.le a (i b) → ∃ m, s.le m b ∧ i m = a

theorem initialEmbedding (hi : s.NumeralMap t i) (ind : s.InductionFor t i) :
    InitialEmbedding s t i := by
  have addAt : ∀ n, s.AddAt t i n := by
    apply ind.addition
    · intro a
      rw [s.add_zero, hi.zero, t.add_zero]
    · intro n ih a
      rw [s.add_next, hi.next, ih, hi.next, t.add_next]
  have mulAt : ∀ n, s.MulAt t i n := by
    apply ind.multiplication
    · intro a
      rw [s.mul_zero, hi.zero, t.mul_zero]
    · intro n ih a
      rw [s.mul_next, addAt, ih, hi.next, t.mul_next]
  have injAt : ∀ n, InjAt i n := by
    apply ind.injectivity
    · intro a eq
      rcases s.zero_or_next a with hz | ⟨b,rfl⟩
      · exact hz
      · exact False.elim <| t.next_ne_zero (i b) <| (hi.next b).symm.trans (eq.trans hi.zero)
    · intro n ih a eq
      rcases s.zero_or_next a with rfl | ⟨b,rfl⟩
      · exact False.elim <| t.next_ne_zero (i n) <| (hi.next n).symm.trans (eq.symm.trans hi.zero)
      · exact congrArg s.next <| ih b <| t.next_inj <|
          (hi.next b).symm.trans (eq.trans (hi.next n))
  have initialAt : ∀ n, s.InitialAt t i n := by
    apply ind.initiality
    · intro a ⟨z,hz⟩
      rcases t.zero_or_next a with rfl | ⟨b,rfl⟩
      · exact ⟨s.zero, ⟨s.zero, s.add_zero s.zero⟩, hi.zero⟩
      · exact False.elim <| t.next_ne_zero (t.add z b) <|
          (t.add_next z b).symm.trans (hz.trans hi.zero)
    · intro n ih a ⟨z,hz⟩
      rcases t.zero_or_next a with rfl | ⟨b,rfl⟩
      · exact ⟨s.zero, ⟨s.next n, s.add_zero (s.next n)⟩, hi.zero⟩
      · have hb : t.add z b = i n :=
          t.next_inj <| (t.add_next z b).symm.trans (hz.trans (hi.next n))
        obtain ⟨m, ⟨w, hw⟩, hmb⟩ := ih b ⟨z,hb⟩
        exact ⟨s.next m, ⟨w, (s.add_next w m).trans (congrArg s.next hw)⟩,
          (hi.next m).trans (congrArg t.next hmb)⟩
  refine ⟨fun {x y} h => injAt y x h, hi.zero, hi.next,
    fun x y => addAt y x, fun x y => mulAt y x, ?_, initialAt⟩
  intro a b
  constructor
  · rintro ⟨z,h⟩
    exact ⟨i z, (addAt a z).symm.trans (congrArg i h)⟩
  · intro h
    obtain ⟨m, hm, hma⟩ := initialAt b (i a) h
    exact injAt a m hma ▸ hm

end Robinson
end PA192.Numerals

#print axioms PA192.Numerals.Robinson.initialEmbedding
