import NF182PADirect
import NF182PATapeAll
open FFL FFL.FirstOrder
namespace NF182PA
/-- First-order PA proves that the literal table's blank-tape nonhalting
implies the consistency of PA. Finite coverage is checked in the Lean kernel. -/
theorem internal_consistency :
    M6.PA.theory ⊢ (∼H182) 🡒 M6.PA.consistencySentence :=
  internal_consistency_of_coverage Symbolic.literal_table_coverage
end NF182PA
#print axioms NF182PA.internal_consistency
