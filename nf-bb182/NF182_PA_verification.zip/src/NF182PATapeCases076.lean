import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2432_0 : checkWitness 2432 false false 8912 = true := by decide +kernel
private theorem w2432_2 : checkWitness 2432 true false 8908 = true := by decide +kernel
private theorem cases2432 : checkFour 2432 (8912,0,8908,0) = true := by
  simp only [checkFour, w2432_0, w2432_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2432 : Coverage 2432 2433 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases2432)
private theorem w2433_0 : checkWitness 2433 false false 532 = true := by decide +kernel
private theorem w2433_1 : checkWitness 2433 false true 4628 = true := by decide +kernel
private theorem w2433_2 : checkWitness 2433 true false 532 = true := by decide +kernel
private theorem w2433_3 : checkWitness 2433 true true 4628 = true := by decide +kernel
private theorem cases2433 : checkFour 2433 (532,4628,532,4628) = true := by
  simp only [checkFour, w2433_0, w2433_1, w2433_2, w2433_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2433 : Coverage 2433 2434 := checkList_sound (ws:=[(532,4628,532,4628)]) (by simpa only [checkList, Bool.and_true] using cases2433)
private theorem w2434_0 : checkWitness 2434 false false 8927 = true := by decide +kernel
private theorem w2434_2 : checkWitness 2434 true false 8923 = true := by decide +kernel
private theorem cases2434 : checkFour 2434 (8927,0,8923,0) = true := by
  simp only [checkFour, w2434_0, w2434_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2434 : Coverage 2434 2435 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases2434)
private theorem w2435_0 : checkWitness 2435 false false 658 = true := by decide +kernel
private theorem w2435_1 : checkWitness 2435 false true 4754 = true := by decide +kernel
private theorem w2435_2 : checkWitness 2435 true false 649 = true := by decide +kernel
private theorem w2435_3 : checkWitness 2435 true true 4745 = true := by decide +kernel
private theorem cases2435 : checkFour 2435 (658,4754,649,4745) = true := by
  simp only [checkFour, w2435_0, w2435_1, w2435_2, w2435_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2435 : Coverage 2435 2436 := checkList_sound (ws:=[(658,4754,649,4745)]) (by simpa only [checkList, Bool.and_true] using cases2435)
private theorem w2436_0 : checkWitness 2436 false false 196 = true := by decide +kernel
private theorem w2436_2 : checkWitness 2436 true false 196 = true := by decide +kernel
private theorem cases2436 : checkFour 2436 (196,0,196,0) = true := by
  simp only [checkFour, w2436_0, w2436_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2436 : Coverage 2436 2437 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases2436)
private theorem w2437_0 : checkWitness 2437 false false 613 = true := by decide +kernel
private theorem w2437_1 : checkWitness 2437 false true 4701 = true := by decide +kernel
private theorem w2437_2 : checkWitness 2437 true false 613 = true := by decide +kernel
private theorem w2437_3 : checkWitness 2437 true true 4701 = true := by decide +kernel
private theorem cases2437 : checkFour 2437 (613,4701,613,4701) = true := by
  simp only [checkFour, w2437_0, w2437_1, w2437_2, w2437_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2437 : Coverage 2437 2438 := checkList_sound (ws:=[(613,4701,613,4701)]) (by simpa only [checkList, Bool.and_true] using cases2437)
private theorem w2438_0 : checkWitness 2438 false false 8942 = true := by decide +kernel
private theorem w2438_2 : checkWitness 2438 true false 8933 = true := by decide +kernel
private theorem cases2438 : checkFour 2438 (8942,0,8933,0) = true := by
  simp only [checkFour, w2438_0, w2438_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2438 : Coverage 2438 2439 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases2438)
private theorem w2439_0 : checkWitness 2439 false false 60 = true := by decide +kernel
private theorem w2439_2 : checkWitness 2439 true false 60 = true := by decide +kernel
private theorem cases2439 : checkFour 2439 (60,0,60,0) = true := by
  simp only [checkFour, w2439_0, w2439_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2439 : Coverage 2439 2440 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2439)
private theorem w2440_0 : checkWitness 2440 false false 52 = true := by decide +kernel
private theorem w2440_2 : checkWitness 2440 true false 52 = true := by decide +kernel
private theorem cases2440 : checkFour 2440 (52,0,52,0) = true := by
  simp only [checkFour, w2440_0, w2440_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2440 : Coverage 2440 2441 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2440)
private theorem w2441_0 : checkWitness 2441 false false 619 = true := by decide +kernel
private theorem w2441_1 : checkWitness 2441 false true 4711 = true := by decide +kernel
private theorem w2441_2 : checkWitness 2441 true false 619 = true := by decide +kernel
private theorem w2441_3 : checkWitness 2441 true true 4711 = true := by decide +kernel
private theorem cases2441 : checkFour 2441 (619,4711,619,4711) = true := by
  simp only [checkFour, w2441_0, w2441_1, w2441_2, w2441_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2441 : Coverage 2441 2442 := checkList_sound (ws:=[(619,4711,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases2441)
private theorem w2442_0 : checkWitness 2442 false false 8880 = true := by decide +kernel
private theorem w2442_2 : checkWitness 2442 true false 8876 = true := by decide +kernel
private theorem cases2442 : checkFour 2442 (8880,0,8876,0) = true := by
  simp only [checkFour, w2442_0, w2442_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2442 : Coverage 2442 2443 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases2442)
private theorem w2443_0 : checkWitness 2443 false false 52 = true := by decide +kernel
private theorem w2443_2 : checkWitness 2443 true false 52 = true := by decide +kernel
private theorem cases2443 : checkFour 2443 (52,0,52,0) = true := by
  simp only [checkFour, w2443_0, w2443_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2443 : Coverage 2443 2444 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2443)
private theorem w2444_0 : checkWitness 2444 false false 580 = true := by decide +kernel
private theorem w2444_1 : checkWitness 2444 false true 4676 = true := by decide +kernel
private theorem w2444_2 : checkWitness 2444 true false 580 = true := by decide +kernel
private theorem w2444_3 : checkWitness 2444 true true 4676 = true := by decide +kernel
private theorem cases2444 : checkFour 2444 (580,4676,580,4676) = true := by
  simp only [checkFour, w2444_0, w2444_1, w2444_2, w2444_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2444 : Coverage 2444 2445 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases2444)
private theorem w2445_0 : checkWitness 2445 false false 8915 = true := by decide +kernel
private theorem w2445_2 : checkWitness 2445 true false 8911 = true := by decide +kernel
private theorem cases2445 : checkFour 2445 (8915,0,8911,0) = true := by
  simp only [checkFour, w2445_0, w2445_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2445 : Coverage 2445 2446 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2445)
private theorem w2446_0 : checkWitness 2446 false false 8950 = true := by decide +kernel
private theorem w2446_2 : checkWitness 2446 true false 8941 = true := by decide +kernel
private theorem cases2446 : checkFour 2446 (8950,0,8941,0) = true := by
  simp only [checkFour, w2446_0, w2446_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2446 : Coverage 2446 2447 := checkList_sound (ws:=[(8950,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2446)
private theorem w2447_0 : checkWitness 2447 false false 70 = true := by decide +kernel
private theorem w2447_2 : checkWitness 2447 true false 70 = true := by decide +kernel
private theorem cases2447 : checkFour 2447 (70,0,70,0) = true := by
  simp only [checkFour, w2447_0, w2447_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2447 : Coverage 2447 2448 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2447)
private theorem w2448_0 : checkWitness 2448 false false 662 = true := by decide +kernel
private theorem w2448_1 : checkWitness 2448 false true 4754 = true := by decide +kernel
private theorem w2448_2 : checkWitness 2448 true false 653 = true := by decide +kernel
private theorem w2448_3 : checkWitness 2448 true true 4745 = true := by decide +kernel
private theorem cases2448 : checkFour 2448 (662,4754,653,4745) = true := by
  simp only [checkFour, w2448_0, w2448_1, w2448_2, w2448_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2448 : Coverage 2448 2449 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases2448)
private theorem w2449_0 : checkWitness 2449 false false 8911 = true := by decide +kernel
private theorem w2449_2 : checkWitness 2449 true false 8907 = true := by decide +kernel
private theorem cases2449 : checkFour 2449 (8911,0,8907,0) = true := by
  simp only [checkFour, w2449_0, w2449_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2449 : Coverage 2449 2450 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases2449)
private theorem w2450_0 : checkWitness 2450 false false 656 = true := by decide +kernel
private theorem w2450_1 : checkWitness 2450 false true 4748 = true := by decide +kernel
private theorem w2450_2 : checkWitness 2450 true false 647 = true := by decide +kernel
private theorem w2450_3 : checkWitness 2450 true true 4739 = true := by decide +kernel
private theorem cases2450 : checkFour 2450 (656,4748,647,4739) = true := by
  simp only [checkFour, w2450_0, w2450_1, w2450_2, w2450_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2450 : Coverage 2450 2451 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases2450)
private theorem w2451_0 : checkWitness 2451 false false 8880 = true := by decide +kernel
private theorem w2451_2 : checkWitness 2451 true false 8876 = true := by decide +kernel
private theorem cases2451 : checkFour 2451 (8880,0,8876,0) = true := by
  simp only [checkFour, w2451_0, w2451_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2451 : Coverage 2451 2452 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases2451)
private theorem w2452_0 : checkWitness 2452 false false 58 = true := by decide +kernel
private theorem w2452_2 : checkWitness 2452 true false 58 = true := by decide +kernel
private theorem cases2452 : checkFour 2452 (58,0,58,0) = true := by
  simp only [checkFour, w2452_0, w2452_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2452 : Coverage 2452 2453 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2452)
private theorem w2453_0 : checkWitness 2453 false false 50 = true := by decide +kernel
private theorem w2453_2 : checkWitness 2453 true false 50 = true := by decide +kernel
private theorem cases2453 : checkFour 2453 (50,0,50,0) = true := by
  simp only [checkFour, w2453_0, w2453_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2453 : Coverage 2453 2454 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2453)
private theorem w2454_0 : checkWitness 2454 false false 639 = true := by decide +kernel
private theorem w2454_1 : checkWitness 2454 false true 4711 = true := by decide +kernel
private theorem w2454_2 : checkWitness 2454 true false 639 = true := by decide +kernel
private theorem w2454_3 : checkWitness 2454 true true 4711 = true := by decide +kernel
private theorem cases2454 : checkFour 2454 (639,4711,639,4711) = true := by
  simp only [checkFour, w2454_0, w2454_1, w2454_2, w2454_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2454 : Coverage 2454 2455 := checkList_sound (ws:=[(639,4711,639,4711)]) (by simpa only [checkList, Bool.and_true] using cases2454)
private theorem w2455_0 : checkWitness 2455 false false 8896 = true := by decide +kernel
private theorem w2455_2 : checkWitness 2455 true false 8892 = true := by decide +kernel
private theorem cases2455 : checkFour 2455 (8896,0,8892,0) = true := by
  simp only [checkFour, w2455_0, w2455_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2455 : Coverage 2455 2456 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases2455)
private theorem w2456_0 : checkWitness 2456 false false 8892 = true := by decide +kernel
private theorem w2456_2 : checkWitness 2456 true false 8888 = true := by decide +kernel
private theorem cases2456 : checkFour 2456 (8892,0,8888,0) = true := by
  simp only [checkFour, w2456_0, w2456_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2456 : Coverage 2456 2457 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2456)
private theorem w2457_0 : checkWitness 2457 false false 64 = true := by decide +kernel
private theorem w2457_2 : checkWitness 2457 true false 64 = true := by decide +kernel
private theorem cases2457 : checkFour 2457 (64,0,64,0) = true := by
  simp only [checkFour, w2457_0, w2457_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2457 : Coverage 2457 2458 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2457)
private theorem w2458_0 : checkWitness 2458 false false 596 = true := by decide +kernel
private theorem w2458_1 : checkWitness 2458 false true 4692 = true := by decide +kernel
private theorem w2458_2 : checkWitness 2458 true false 596 = true := by decide +kernel
private theorem w2458_3 : checkWitness 2458 true true 4692 = true := by decide +kernel
private theorem cases2458 : checkFour 2458 (596,4692,596,4692) = true := by
  simp only [checkFour, w2458_0, w2458_1, w2458_2, w2458_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2458 : Coverage 2458 2459 := checkList_sound (ws:=[(596,4692,596,4692)]) (by simpa only [checkList, Bool.and_true] using cases2458)
private theorem w2459_0 : checkWitness 2459 false false 9008 = true := by decide +kernel
private theorem w2459_2 : checkWitness 2459 true false 8999 = true := by decide +kernel
private theorem cases2459 : checkFour 2459 (9008,0,8999,0) = true := by
  simp only [checkFour, w2459_0, w2459_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2459 : Coverage 2459 2460 := checkList_sound (ws:=[(9008,0,8999,0)]) (by simpa only [checkList, Bool.and_true] using cases2459)
private theorem w2460_0 : checkWitness 2460 false false 62 = true := by decide +kernel
private theorem w2460_2 : checkWitness 2460 true false 62 = true := by decide +kernel
private theorem cases2460 : checkFour 2460 (62,0,62,0) = true := by
  simp only [checkFour, w2460_0, w2460_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2460 : Coverage 2460 2461 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2460)
private theorem w2461_0 : checkWitness 2461 false false 590 = true := by decide +kernel
private theorem w2461_1 : checkWitness 2461 false true 4686 = true := by decide +kernel
private theorem w2461_2 : checkWitness 2461 true false 590 = true := by decide +kernel
private theorem w2461_3 : checkWitness 2461 true true 4686 = true := by decide +kernel
private theorem cases2461 : checkFour 2461 (590,4686,590,4686) = true := by
  simp only [checkFour, w2461_0, w2461_1, w2461_2, w2461_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2461 : Coverage 2461 2462 := checkList_sound (ws:=[(590,4686,590,4686)]) (by simpa only [checkList, Bool.and_true] using cases2461)
private theorem w2462_0 : checkWitness 2462 false false 8948 = true := by decide +kernel
private theorem w2462_2 : checkWitness 2462 true false 8944 = true := by decide +kernel
private theorem cases2462 : checkFour 2462 (8948,0,8944,0) = true := by
  simp only [checkFour, w2462_0, w2462_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2462 : Coverage 2462 2463 := checkList_sound (ws:=[(8948,0,8944,0)]) (by simpa only [checkList, Bool.and_true] using cases2462)
private theorem w2463_0 : checkWitness 2463 false false 64 = true := by decide +kernel
private theorem w2463_2 : checkWitness 2463 true false 64 = true := by decide +kernel
private theorem cases2463 : checkFour 2463 (64,0,64,0) = true := by
  simp only [checkFour, w2463_0, w2463_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2463 : Coverage 2463 2464 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2463)
theorem cover2432 : Coverage 2432 2464 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2432 one2433) (Coverage.join one2434 one2435)) (Coverage.join (Coverage.join one2436 one2437) (Coverage.join one2438 one2439))) (Coverage.join (Coverage.join (Coverage.join one2440 one2441) (Coverage.join one2442 one2443)) (Coverage.join (Coverage.join one2444 one2445) (Coverage.join one2446 one2447)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2448 one2449) (Coverage.join one2450 one2451)) (Coverage.join (Coverage.join one2452 one2453) (Coverage.join one2454 one2455))) (Coverage.join (Coverage.join (Coverage.join one2456 one2457) (Coverage.join one2458 one2459)) (Coverage.join (Coverage.join one2460 one2461) (Coverage.join one2462 one2463)))))
end NF182PA.Symbolic
