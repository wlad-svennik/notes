module
public import FiniteNumericalProof
public import DefinableIteration
import Mathlib.Tactic.Ring

@[expose] public section
set_option maxHeartbeats 1700000
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

open PA192.Numerals.FoundationRoute

namespace PA192.ModelSearch

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem modelInduct {P : V → Prop} (defP : Language.DefinablePred ℒₒᵣ P)
    (zero : P 0) (step : ∀ n, P n → P (n+1)) : ∀ n, P n :=
  induction_of_arith (arithPred_of_definable defP) zero step

noncomputable def triangle (n : V) : V := n*(n+1)/2
noncomputable def cantor (a b : V) : V := triangle (a+b) + b

instance plainDiv : Language.DefinableFunction₂ ℒₒᵣ ((· / ·) : V → V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := divDef.val) ⟨(div_defined (V:=V)).df⟩
instance plainSub : Language.DefinableFunction₂ ℒₒᵣ ((· - ·) : V → V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := subDef.val) ⟨(sub_defined (V:=V)).df⟩

instance triangleDef : Language.DefinableFunction₁ ℒₒᵣ (triangle (V:=V)) := by
  unfold triangle; definability
instance cantorDef : Language.DefinableFunction₂ ℒₒᵣ (cantor (V:=V)) := by
  unfold cantor; definability

@[simp] theorem triangle_zero : triangle (0 : V) = 0 := by simp [triangle]
theorem triangle_succ (n : V) : triangle (n+1) = triangle n+n+1 := by
  have h : (n+1)*(n+1+1)=n*(n+1)+2*(n+1) := by ring
  unfold triangle
  rw [h,div_add_mul_self' _ _ (by simp : (0:V)<2),add_assoc]

theorem triangle_double : ∀ n : V, 2*triangle n = n*(n+1) := by
  apply modelInduct
  · definability
  · simp
  · intro n ih
    rw [triangle_succ]
    calc
      _ = 2*triangle n + 2*n + 2 := by ring
      _ = _ := by rw [ih]; ring

theorem twice_cantor (a b : V) : 2*cantor a b = PA192.Literal.imp a b := by
  rw [cantor,mul_add,triangle_double]; rfl

theorem triangle_le_succ (n : V) : triangle n ≤ triangle (n+1) := by
  rw [triangle_succ,add_assoc]; exact le_self_add

theorem triangle_mono : ∀ b : V, ∀ a, a≤b → triangle a ≤ triangle b := by
  apply modelInduct
  · definability
  · intro a h
    have : a=0 := le_antisymm h zero_le
    simp [this]
  · intro b ih a h
    rcases lt_or_eq_of_le h with less | rfl
    · exact le_trans (ih a (lt_succ_iff_le.mp less)) (triangle_le_succ b)
    · rfl

theorem triangle_ge : ∀ n : V, n ≤ triangle n := by
  apply modelInduct
  · definability
  · simp
  · intro n _
    rw [triangle_succ,add_assoc]
    exact le_add_self

theorem cantor_ge_left (a b : V) : a ≤ cantor a b :=
  le_trans (show a≤a+b from le_self_add) (le_trans (triangle_ge _) le_self_add)
theorem cantor_ge_right (a b : V) : b ≤ cantor a b := le_add_self

theorem cantor_lower (a b : V) : triangle (a+b) ≤ cantor a b := le_self_add
theorem cantor_upper (a b : V) : cantor a b < triangle (a+b+1) := by
  rw [triangle_succ,cantor]
  exact lt_succ_iff_le.mpr (add_le_add (le_refl _) (show b ≤ a+b from le_add_self))

theorem cantor_ext {a b x y : V} (h : cantor a b = cantor x y) : a=x ∧ b=y := by
  have bound {p q i j : V} (eq : cantor p q = cantor i j) : p+q ≤ i+j := by
    by_contra bad
    have step : i+j+1 ≤ p+q := succ_le_iff_lt.mpr (lt_of_not_ge bad)
    have lt := lt_of_lt_of_le (cantor_upper i j) (triangle_mono _ _ step)
    rw [←eq] at lt
    exact (not_lt_of_ge (cantor_lower p q)) lt
  have sum := le_antisymm (bound h) (bound h.symm)
  unfold cantor at h
  rw [sum] at h
  have byy : b=y := add_left_cancel h
  subst y
  exact ⟨add_right_cancel sum,rfl⟩

noncomputable def diagonalNext (z : V) : V :=
  let a := pi₁ z
  let b := pi₂ z
  if a=0 then ⟪b+1,(0:V)⟫ else ⟪a-1,b+1⟫

instance nextDef : Language.DefinableFunction₁ ℒₒᵣ (diagonalNext (V:=V)) := by
  apply Language.Definable.of_iff (Q := fun v : Fin 2 → V =>
    (pi₁ (v 1) = 0 ∧ v 0 = ⟪pi₂ (v 1)+1,(0:V)⟫) ∨
    (pi₁ (v 1) ≠ 0 ∧ v 0 = ⟪pi₁ (v 1)-1,pi₂ (v 1)+1⟫)) (by definability)
  intro v
  by_cases h : pi₁ (v 1)=0 <;> simp [diagonalNext,h]

noncomputable def inversePair (n : V) : V :=
  PA192.Numerals.FoundationRoute.Iteration.value ⟪(0:V),(0:V)⟫ diagonalNext n

instance inversePairDef : Language.DefinableFunction₁ ℒₒᵣ (inversePair (V:=V)) := by
  unfold inversePair; infer_instance

theorem diagonalNext_code (z : V) :
    cantor (pi₁ (diagonalNext z)) (pi₂ (diagonalNext z)) = cantor (pi₁ z) (pi₂ z) + 1 := by
  let a := pi₁ z
  let b := pi₂ z
  by_cases eq : a=0
  · simp [diagonalNext,show pi₁ z=0 from eq,cantor,triangle_succ,add_assoc]
  · have pos : 0<a := lt_of_le_of_ne zero_le (Ne.symm eq)
    have ge : 1≤a := by simpa using (succ_le_iff_lt.mpr pos)
    have p : a-1+1=a := by simpa using sub_add_self_of_le ge
    have sum : (a-1)+(b+1)=a+b := by rw [add_comm b 1,←add_assoc,p]
    simp [diagonalNext,show pi₁ z≠0 from eq,cantor,show pi₁ z-1+(pi₂ z+1)=pi₁ z+pi₂ z from sum,add_assoc]

@[simp] theorem inverse_zero : inversePair (0:V) = ⟪(0:V),(0:V)⟫ :=
  Iteration.value_zero _ _

theorem inverse_succ (n : V) : inversePair (n+1) = diagonalNext (inversePair n) :=
  Iteration.value_succ _ _ n

theorem inversePair_correct : ∀ n : V, cantor (pi₁ (inversePair n)) (pi₂ (inversePair n)) = n := by
  apply modelInduct
  · definability
  · simp [cantor]
  · intro n ih
    rw [inverse_succ,diagonalNext_code,ih]

theorem inversePair_cantor (a b : V) : inversePair (cantor a b) = ⟪a,b⟫ := by
  have h := cantor_ext (inversePair_correct (cantor a b))
  exact (pair_unpair _).symm.trans (by rw [h.1,h.2])

end PA192.ModelSearch
#print axioms PA192.ModelSearch.inversePair_cantor
