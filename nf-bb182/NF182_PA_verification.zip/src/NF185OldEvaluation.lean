module
public import GroundRows
public import ModelFold
public import NumericalProofPool
import Mathlib.Tactic.Ring
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch PA192.Literal
namespace NF185PA.Old
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3500000
set_option maxRecDepth 9000

private theorem pos2 : (0:V)<2 := by simp
private theorem lt2 : (1:V)<2 := by simp
private theorem half0 (p : V) : (2*p)/2=p := by
  simpa using div_mul_add' p (2:V) (r:=0) pos2
private theorem half1 (p : V) : (2*p+1)/2=p := div_mul_add' p 2 lt2
private theorem half2 (p : V) : (2*p+2)/2=p+1 := by
  rw [show 2*p+2=2*(p+1) by ring,half0]
noncomputable def bit (n : V) := n-2*(n/2)
instance bitDef : Language.DefinableFunction₁ ℒₒᵣ (bit (V:=V)) := by unfold bit; definability
private theorem bit0 (p : V) : bit (2*p)=0 := by simp [bit,half0]
private theorem bit1 (p : V) : bit (2*p+1)=1 := by simp [bit,half1]
private theorem bit2 (p : V) : bit (2*p+2)=0 := by rw [show 2*p+2=2*(p+1) by ring,bit0]
private theorem a_pos (p : V) : 0 < 2*p+1 := by simp
private theorem h_pos (p : V) : 0 < 2*p+2 := by rw [show 2*p+2=2*p+1+1 by ring]; simp
private theorem left_bound (a b : V) : a ≤ 2*cantor a b :=
  (cantor_ge_left a b).trans (by rw [two_mul]; exact le_self_add)
private theorem right_bound (a b : V) : b ≤ 2*cantor a b :=
  (cantor_ge_right a b).trans (by rw [two_mul]; exact le_self_add)

variable (S : NF192.Ground.Signature V)
variable [Language.DefinableFunction₂ ℒₒᵣ S.app] [Language.DefinableFunction₂ ℒₒᵣ S.h]

noncomputable def objectStep (i hist : V) :=
  let payload := (i-1)/2
  let a := znth hist (left payload)
  let b := znth hist (right payload)
  chooseZero i S.q (chooseZero (bit i) (S.h a b) (S.app a b))
instance objectStepDef : Language.DefinableFunction₂ ℒₒᵣ (objectStep S) := by
  unfold objectStep; definability
noncomputable def obj (i : V) := entry (objectStep S) i
instance objDef : Language.DefinableFunction₁ ℒₒᵣ (obj S) := by unfold obj; infer_instance
theorem obj_q : obj S q = S.q := by change objectStep S 0 _ = _; simp [objectStep,chooseZero]
theorem obj_app (a b : V) : obj S (app a b)=S.app (obj S a) (obj S b) := by
  change objectStep S (app a b) _ = _
  simp only [app,←twice_cantor]
  let p := cantor a b
  have hl : a<2*p+1 := lt_succ_iff_le.mpr (left_bound a b)
  have hr : b<2*p+1 := lt_succ_iff_le.mpr (right_bound a b)
  dsimp only [p] at hl hr
  simp only [objectStep,bit1,chooseZero,(a_pos (cantor a b)).ne',Arithmetic.one_ne_zero,ite_false,
    add_tsub_cancel_right,half0,left_cantor,right_cantor,table_lookup (objectStep S) _ a hl,table_lookup (objectStep S) _ b hr]
  rfl
theorem obj_h (a b : V) : obj S (witness a b)=S.h (obj S a) (obj S b) := by
  change objectStep S (witness a b) _ = _
  simp only [witness,←twice_cantor]
  let p := cantor a b
  have hl : a<2*p+2 := lt_of_lt_of_le (lt_succ_iff_le.mpr (left_bound a b)) (by rw [show 2*p+2=2*p+1+1 by ring]; exact le_self_add)
  have hr : b<2*p+2 := lt_of_lt_of_le (lt_succ_iff_le.mpr (right_bound a b)) (by rw [show 2*p+2=2*p+1+1 by ring]; exact le_self_add)
  have pred (n : V) : n+2-1=n+1 := by rw [show n+2=n+1+1 by ring,add_tsub_cancel_right]
  dsimp only [p] at hl hr
  simp only [objectStep,bit2,chooseZero,(h_pos (cantor a b)).ne',ite_false,ite_true,pred,half1,
    left_cantor,right_cantor,table_lookup (objectStep S) _ a hl,table_lookup (objectStep S) _ b hr]
  rfl

variable (E : V → V → Prop) [Language.DefinableRel ℒₒᵣ E]
noncomputable def checkEq (a b : V) : V := by classical exact if E a b then 0 else 1
instance checkEqDef : Language.DefinableFunction₂ ℒₒᵣ (checkEq E) := by
  apply Language.Definable.of_iff (Q:=fun v : Fin 3→V =>
    (E (v 1) (v 2) ∧ v 0=0) ∨ (¬E (v 1) (v 2) ∧ v 0=1)) (by definability)
  intro v
  by_cases yes : E (v 1) (v 2) <;> simp [checkEq,yes]
noncomputable def formulaStep (n hist : V) :=
  let p := n/2
  let a := left p
  let b := right p
  chooseZero n 0 (chooseZero (bit n)
    (chooseZero (znth hist a) (znth hist b) 0)
    (checkEq E (obj S a) (obj S b)))
instance formulaStepDef : Language.DefinableFunction₂ ℒₒᵣ (formulaStep S E) := by
  unfold formulaStep; definability
def holds (n : V) := entry (formulaStep S E) n=0
instance holdsDef : Language.DefinablePred ℒₒᵣ (holds S E) := by unfold holds; definability
theorem holds_zero : holds S E 0 := by change formulaStep S E 0 _ = 0; simp [formulaStep,chooseZero]
theorem holds_eq (a b : V) : holds S E (eqn a b) ↔ E (obj S a) (obj S b) := by
  change formulaStep S E (eqn a b) _ = 0 ↔ _
  simp only [eqn,←twice_cantor,formulaStep,half1,bit1,chooseZero,(a_pos (cantor a b)).ne',Arithmetic.one_ne_zero,ite_false,left_cantor,right_cantor]
  by_cases h : E (obj S a) (obj S b) <;> simp [checkEq,h]
theorem holds_imp (a b : V) : holds S E (imp a b) ↔ (holds S E a → holds S E b) := by
  by_cases z : cantor a b=0
  · have x : a=0 := nonpos_iff_eq_zero.mp (z ▸ cantor_ge_left a b)
    have y : b=0 := nonpos_iff_eq_zero.mp (z ▸ cantor_ge_right a b)
    subst a; subst b
    simpa [imp] using (iff_true_intro (holds_zero S E))
  · let p := cantor a b
    have pp : 0<p := lt_of_le_of_ne zero_le (Ne.symm z)
    have grow : p<2*p := by rw [two_mul]; exact lt_add_of_pos_right _ pp
    have hl : a<2*p := lt_of_le_of_lt (cantor_ge_left a b) grow
    have hr : b<2*p := lt_of_le_of_lt (cantor_ge_right a b) grow
    change formulaStep S E (imp a b) _ = 0 ↔ _
    dsimp only [p] at hl hr pp grow
    simp only [←twice_cantor,formulaStep,half0,bit0,left_cantor,right_cantor,chooseZero,
      ne_of_gt (lt_trans pp grow),ite_false,ite_true,table_lookup (formulaStep S E) _ a hl,table_lookup (formulaStep S E) _ b hr,holds]
    split <;> simp_all
end NF185PA.Old
#print axioms NF185PA.Old.holds_imp
