import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w512_0 : checkWitness 512 false false 62 = true := by decide +kernel
private theorem w512_2 : checkWitness 512 true false 62 = true := by decide +kernel
private theorem cases512 : checkFour 512 (62,0,62,0) = true := by
  simp only [checkFour, w512_0, w512_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one512 : Coverage 512 513 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases512)
private theorem w513_0 : checkWitness 513 false false 599 = true := by decide +kernel
private theorem w513_1 : checkWitness 513 false true 4691 = true := by decide +kernel
private theorem w513_2 : checkWitness 513 true false 599 = true := by decide +kernel
private theorem w513_3 : checkWitness 513 true true 4691 = true := by decide +kernel
private theorem cases513 : checkFour 513 (599,4691,599,4691) = true := by
  simp only [checkFour, w513_0, w513_1, w513_2, w513_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one513 : Coverage 513 514 := checkList_sound (ws:=[(599,4691,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases513)
private theorem w514_0 : checkWitness 514 false false 8860 = true := by decide +kernel
private theorem w514_2 : checkWitness 514 true false 8856 = true := by decide +kernel
private theorem cases514 : checkFour 514 (8860,0,8856,0) = true := by
  simp only [checkFour, w514_0, w514_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one514 : Coverage 514 515 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases514)
private theorem w515_0 : checkWitness 515 false false 62 = true := by decide +kernel
private theorem w515_2 : checkWitness 515 true false 62 = true := by decide +kernel
private theorem cases515 : checkFour 515 (62,0,62,0) = true := by
  simp only [checkFour, w515_0, w515_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one515 : Coverage 515 516 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases515)
private theorem w516_0 : checkWitness 516 false false 560 = true := by decide +kernel
private theorem w516_1 : checkWitness 516 false true 4656 = true := by decide +kernel
private theorem w516_2 : checkWitness 516 true false 560 = true := by decide +kernel
private theorem w516_3 : checkWitness 516 true true 4656 = true := by decide +kernel
private theorem cases516 : checkFour 516 (560,4656,560,4656) = true := by
  simp only [checkFour, w516_0, w516_1, w516_2, w516_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one516 : Coverage 516 517 := checkList_sound (ws:=[(560,4656,560,4656)]) (by simpa only [checkList, Bool.and_true] using cases516)
private theorem w517_0 : checkWitness 517 false false 8895 = true := by decide +kernel
private theorem w517_2 : checkWitness 517 true false 8891 = true := by decide +kernel
private theorem cases517 : checkFour 517 (8895,0,8891,0) = true := by
  simp only [checkFour, w517_0, w517_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one517 : Coverage 517 518 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases517)
private theorem w518_0 : checkWitness 518 false false 8930 = true := by decide +kernel
private theorem w518_2 : checkWitness 518 true false 8921 = true := by decide +kernel
private theorem cases518 : checkFour 518 (8930,0,8921,0) = true := by
  simp only [checkFour, w518_0, w518_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one518 : Coverage 518 519 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases518)
private theorem w519_0 : checkWitness 519 false false 80 = true := by decide +kernel
private theorem w519_2 : checkWitness 519 true false 80 = true := by decide +kernel
private theorem cases519 : checkFour 519 (80,0,80,0) = true := by
  simp only [checkFour, w519_0, w519_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one519 : Coverage 519 520 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases519)
private theorem w520_0 : checkWitness 520 false false 642 = true := by decide +kernel
private theorem w520_1 : checkWitness 520 false true 4734 = true := by decide +kernel
private theorem w520_2 : checkWitness 520 true false 633 = true := by decide +kernel
private theorem w520_3 : checkWitness 520 true true 4725 = true := by decide +kernel
private theorem cases520 : checkFour 520 (642,4734,633,4725) = true := by
  simp only [checkFour, w520_0, w520_1, w520_2, w520_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one520 : Coverage 520 521 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases520)
private theorem w521_0 : checkWitness 521 false false 8891 = true := by decide +kernel
private theorem w521_2 : checkWitness 521 true false 8887 = true := by decide +kernel
private theorem cases521 : checkFour 521 (8891,0,8887,0) = true := by
  simp only [checkFour, w521_0, w521_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one521 : Coverage 521 522 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases521)
private theorem w522_0 : checkWitness 522 false false 636 = true := by decide +kernel
private theorem w522_1 : checkWitness 522 false true 4728 = true := by decide +kernel
private theorem w522_2 : checkWitness 522 true false 627 = true := by decide +kernel
private theorem w522_3 : checkWitness 522 true true 4719 = true := by decide +kernel
private theorem cases522 : checkFour 522 (636,4728,627,4719) = true := by
  simp only [checkFour, w522_0, w522_1, w522_2, w522_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one522 : Coverage 522 523 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases522)
private theorem w523_0 : checkWitness 523 false false 8860 = true := by decide +kernel
private theorem w523_2 : checkWitness 523 true false 8856 = true := by decide +kernel
private theorem cases523 : checkFour 523 (8860,0,8856,0) = true := by
  simp only [checkFour, w523_0, w523_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one523 : Coverage 523 524 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases523)
private theorem w524_0 : checkWitness 524 false false 68 = true := by decide +kernel
private theorem w524_2 : checkWitness 524 true false 68 = true := by decide +kernel
private theorem cases524 : checkFour 524 (68,0,68,0) = true := by
  simp only [checkFour, w524_0, w524_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one524 : Coverage 524 525 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases524)
private theorem w525_0 : checkWitness 525 false false 60 = true := by decide +kernel
private theorem w525_2 : checkWitness 525 true false 60 = true := by decide +kernel
private theorem cases525 : checkFour 525 (60,0,60,0) = true := by
  simp only [checkFour, w525_0, w525_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one525 : Coverage 525 526 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases525)
private theorem w526_0 : checkWitness 526 false false 603 = true := by decide +kernel
private theorem w526_1 : checkWitness 526 false true 4691 = true := by decide +kernel
private theorem w526_2 : checkWitness 526 true false 603 = true := by decide +kernel
private theorem w526_3 : checkWitness 526 true true 4691 = true := by decide +kernel
private theorem cases526 : checkFour 526 (603,4691,603,4691) = true := by
  simp only [checkFour, w526_0, w526_1, w526_2, w526_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one526 : Coverage 526 527 := checkList_sound (ws:=[(603,4691,603,4691)]) (by simpa only [checkList, Bool.and_true] using cases526)
private theorem w527_0 : checkWitness 527 false false 8876 = true := by decide +kernel
private theorem w527_2 : checkWitness 527 true false 8872 = true := by decide +kernel
private theorem cases527 : checkFour 527 (8876,0,8872,0) = true := by
  simp only [checkFour, w527_0, w527_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one527 : Coverage 527 528 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases527)
private theorem w528_0 : checkWitness 528 false false 8872 = true := by decide +kernel
private theorem w528_2 : checkWitness 528 true false 8868 = true := by decide +kernel
private theorem cases528 : checkFour 528 (8872,0,8868,0) = true := by
  simp only [checkFour, w528_0, w528_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one528 : Coverage 528 529 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases528)
private theorem w529_0 : checkWitness 529 false false 74 = true := by decide +kernel
private theorem w529_2 : checkWitness 529 true false 74 = true := by decide +kernel
private theorem cases529 : checkFour 529 (74,0,74,0) = true := by
  simp only [checkFour, w529_0, w529_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one529 : Coverage 529 530 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases529)
private theorem w530_0 : checkWitness 530 false false 8888 = true := by decide +kernel
private theorem w530_2 : checkWitness 530 true false 8884 = true := by decide +kernel
private theorem cases530 : checkFour 530 (8888,0,8884,0) = true := by
  simp only [checkFour, w530_0, w530_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one530 : Coverage 530 531 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases530)
private theorem w531_0 : checkWitness 531 false false 550 = true := by decide +kernel
private theorem w531_1 : checkWitness 531 false true 4646 = true := by decide +kernel
private theorem w531_2 : checkWitness 531 true false 550 = true := by decide +kernel
private theorem w531_3 : checkWitness 531 true true 4646 = true := by decide +kernel
private theorem cases531 : checkFour 531 (550,4646,550,4646) = true := by
  simp only [checkFour, w531_0, w531_1, w531_2, w531_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one531 : Coverage 531 532 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases531)
private theorem w532_0 : checkWitness 532 false false 8974 = true := by decide +kernel
private theorem w532_2 : checkWitness 532 true false 8965 = true := by decide +kernel
private theorem cases532 : checkFour 532 (8974,0,8965,0) = true := by
  simp only [checkFour, w532_0, w532_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one532 : Coverage 532 533 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases532)
private theorem w533_0 : checkWitness 533 false false 74 = true := by decide +kernel
private theorem w533_2 : checkWitness 533 true false 74 = true := by decide +kernel
private theorem cases533 : checkFour 533 (74,0,74,0) = true := by
  simp only [checkFour, w533_0, w533_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one533 : Coverage 533 534 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases533)
private theorem w534_0 : checkWitness 534 false false 556 = true := by decide +kernel
private theorem w534_1 : checkWitness 534 false true 4652 = true := by decide +kernel
private theorem w534_2 : checkWitness 534 true false 556 = true := by decide +kernel
private theorem w534_3 : checkWitness 534 true true 4652 = true := by decide +kernel
private theorem cases534 : checkFour 534 (556,4652,556,4652) = true := by
  simp only [checkFour, w534_0, w534_1, w534_2, w534_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one534 : Coverage 534 535 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases534)
private theorem w535_0 : checkWitness 535 false false 8914 = true := by decide +kernel
private theorem w535_2 : checkWitness 535 true false 8910 = true := by decide +kernel
private theorem cases535 : checkFour 535 (8914,0,8910,0) = true := by
  simp only [checkFour, w535_0, w535_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one535 : Coverage 535 536 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases535)
private theorem w536_0 : checkWitness 536 false false 76 = true := by decide +kernel
private theorem w536_2 : checkWitness 536 true false 76 = true := by decide +kernel
private theorem cases536 : checkFour 536 (76,0,76,0) = true := by
  simp only [checkFour, w536_0, w536_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one536 : Coverage 536 537 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases536)
private theorem w537_0 : checkWitness 537 false false 600 = true := by decide +kernel
private theorem w537_1 : checkWitness 537 false true 4696 = true := by decide +kernel
private theorem w537_2 : checkWitness 537 true false 600 = true := by decide +kernel
private theorem w537_3 : checkWitness 537 true true 4696 = true := by decide +kernel
private theorem cases537 : checkFour 537 (600,4696,600,4696) = true := by
  simp only [checkFour, w537_0, w537_1, w537_2, w537_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one537 : Coverage 537 538 := checkList_sound (ws:=[(600,4696,600,4696)]) (by simpa only [checkList, Bool.and_true] using cases537)
private theorem w538_0 : checkWitness 538 false false 8935 = true := by decide +kernel
private theorem w538_2 : checkWitness 538 true false 8931 = true := by decide +kernel
private theorem cases538 : checkFour 538 (8935,0,8931,0) = true := by
  simp only [checkFour, w538_0, w538_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one538 : Coverage 538 539 := checkList_sound (ws:=[(8935,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases538)
private theorem w539_0 : checkWitness 539 false false 8970 = true := by decide +kernel
private theorem w539_2 : checkWitness 539 true false 8961 = true := by decide +kernel
private theorem cases539 : checkFour 539 (8970,0,8961,0) = true := by
  simp only [checkFour, w539_0, w539_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one539 : Coverage 539 540 := checkList_sound (ws:=[(8970,0,8961,0)]) (by simpa only [checkList, Bool.and_true] using cases539)
private theorem w540_0 : checkWitness 540 false false 100 = true := by decide +kernel
private theorem w540_2 : checkWitness 540 true false 100 = true := by decide +kernel
private theorem cases540 : checkFour 540 (100,0,100,0) = true := by
  simp only [checkFour, w540_0, w540_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one540 : Coverage 540 541 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases540)
private theorem w541_0 : checkWitness 541 false false 682 = true := by decide +kernel
private theorem w541_1 : checkWitness 541 false true 4774 = true := by decide +kernel
private theorem w541_2 : checkWitness 541 true false 673 = true := by decide +kernel
private theorem w541_3 : checkWitness 541 true true 4765 = true := by decide +kernel
private theorem cases541 : checkFour 541 (682,4774,673,4765) = true := by
  simp only [checkFour, w541_0, w541_1, w541_2, w541_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one541 : Coverage 541 542 := checkList_sound (ws:=[(682,4774,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases541)
private theorem w542_0 : checkWitness 542 false false 8931 = true := by decide +kernel
private theorem w542_2 : checkWitness 542 true false 8927 = true := by decide +kernel
private theorem cases542 : checkFour 542 (8931,0,8927,0) = true := by
  simp only [checkFour, w542_0, w542_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one542 : Coverage 542 543 := checkList_sound (ws:=[(8931,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases542)
private theorem w543_0 : checkWitness 543 false false 676 = true := by decide +kernel
private theorem w543_1 : checkWitness 543 false true 4768 = true := by decide +kernel
private theorem w543_2 : checkWitness 543 true false 667 = true := by decide +kernel
private theorem w543_3 : checkWitness 543 true true 4759 = true := by decide +kernel
private theorem cases543 : checkFour 543 (676,4768,667,4759) = true := by
  simp only [checkFour, w543_0, w543_1, w543_2, w543_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one543 : Coverage 543 544 := checkList_sound (ws:=[(676,4768,667,4759)]) (by simpa only [checkList, Bool.and_true] using cases543)
theorem cover0512 : Coverage 512 544 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one512 one513) (Coverage.join one514 one515)) (Coverage.join (Coverage.join one516 one517) (Coverage.join one518 one519))) (Coverage.join (Coverage.join (Coverage.join one520 one521) (Coverage.join one522 one523)) (Coverage.join (Coverage.join one524 one525) (Coverage.join one526 one527)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one528 one529) (Coverage.join one530 one531)) (Coverage.join (Coverage.join one532 one533) (Coverage.join one534 one535))) (Coverage.join (Coverage.join (Coverage.join one536 one537) (Coverage.join one538 one539)) (Coverage.join (Coverage.join one540 one541) (Coverage.join one542 one543)))))
end NF182PA.Symbolic
