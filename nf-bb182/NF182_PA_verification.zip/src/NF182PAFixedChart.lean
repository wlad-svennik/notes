import CompactNF

open FFL FFL.FirstOrder FFL.FirstOrder.SetTheory
open NFFn NFFn.NF188Finite NF196.Compact
open Classical
namespace NF182PA.Fixed

/- The construction of Compact.in_model, retaining the application graph
needed when pulling the chart back to a nonstandard model of PA. -/
private theorem identity {V : Type} (A : NF188.Relabel.Basis V) : ∃ i, ∀ x : V, A.app i x=x := by
  open NF188.Relabel.Syntax in
    exact ⟨val A A.B (fun _=>A.B) idT, fun x => by simp only [idT,con,val,kpow,valAtom,A.b_app,A.k_app]⟩

theorem chart_with_old_application (V : Type) [SetStructure V] [Nonempty V] [hT : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙] :
    ∃ C : Chart V, C.app = oldApp := by
  let A : NF188.Relabel.Basis V := oldBasis
  let B := A.B
  obtain ⟨d,hd⟩ := NF188.Pure.four_labels V
  have ds : d 0≠d 1 := fun e => (by decide : (0 : Fin 4)≠1) (hd e)
  obtain ⟨yes,yes_ne⟩ : ∃ x : V, x≠B := by
    by_cases e : d 0=B
    · exact ⟨d 1,fun k=>ds (e.trans k.symm)⟩
    · exact ⟨d 0,e⟩
  obtain ⟨U,hU⟩ := TaggedFixedPoint.exists_tester yes B
  obtain ⟨j,hj⟩ := selector U B
  have tested (x y : V) := ((hU (A.K x) _).mp (oldApp_spec U _) y _).mp (oldApp_spec (oldApp U (A.K x)) y)
  have ka (x y : V) : AppR (A.K x) y y ↔ x=y := by
    rw [oldApp_iff]; change A.app (A.K x) y=y ↔ x=y; rw [A.k_app]
  have chooses (x : V) : A.app j (A.K x) = oldApp U (A.K x) := by
    apply (oldApp_iff _ _ _).mp
    exact (hj _ _).mpr (Or.inl ⟨⟨x,oldK_spec x⟩,oldApp_spec _ _⟩)
  have on (x : V) : A.app (A.app j (A.K x)) x=yes := by
    rw [chooses]; exact ((tested x x).resolve_right (fun z=>z.1 ((ka x x).mpr rfl))).2
  have off (x y : V) (ne : x≠y) : A.app (A.app j (A.K x)) y=B := by
    rw [chooses]; exact ((tested x y).resolve_left (fun z=>ne ((ka x y).mp z.1))).2
  have j_nc : ¬ IsConstant j := by
    rintro ⟨v,h⟩
    have hjK (x : V) : A.app j (A.K x)=v := (h _ _).mp (oldApp_spec j _)
    apply yes_ne
    have p := on (d 0)
    have n := off (d 1) (d 0) ds.symm
    rw [hjK] at p n
    exact p.symm.trans n
  have fallback (f : V) (n : ¬IsConstant f) : A.app j f=B :=
    (oldApp_iff _ _ _).mp ((hj f B).mpr (Or.inr ⟨n,rfl⟩))
  obtain ⟨i,idlaw⟩ := identity A
  have i_nc : ¬IsConstant i := by
    rintro ⟨v,h⟩
    have k (x : V) : x=v := (idlaw x).symm.trans ((h _ _).mp (oldApp_spec i x))
    exact ds ((k _).trans (k _).symm)
  have bi : A.app B i=A.K i := by
    apply A.ext; intro f; rw [A.k_app]
    apply A.ext; intro x
    simp only [B,A.b_app,idlaw,A.k_app]
  have b_nonconst (v : V) : B≠A.K v := by
    intro e
    have fix (x : V) : A.app B (A.K (A.K x))=A.K (A.K x) := by
      apply A.ext; intro y; apply A.ext; intro z
      simp only [B,A.b_app,A.k_app]
    have same (x : V) : v=A.K (A.K x) := by simpa only [e,A.k_app] using fix x
    have both := congrArg (fun z => A.app (A.app z B) B) ((same (d 0)).symm.trans (same (d 1)))
    exact ds (by simpa only [A.k_app] using both)
  have bj : B≠j := by
    intro e
    apply b_nonconst i
    exact (fallback i i_nc).symm.trans (by rw [← e]; exact bi)
  refine ⟨{
    toBasis := A
    J := j
    letter := fallback j j_nc
    proper := bj
    off := off
    on := fun x => by rw [on]; exact yes_ne }, rfl⟩

end NF182PA.Fixed
#print axioms NF182PA.Fixed.chart_with_old_application
