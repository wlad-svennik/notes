module
public import NF185PAGate

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM PA192.PhysicalModel NF192.KernelBits

namespace NF185PA.Gate
set_option maxHeartbeats 2400000
set_option maxRecDepth 12000

def bootRight : Nat := 121791803110908576516981030204446497794741581141
private abbrev endpoint := embed CS185.Boot.width (-10) (fun _ => false) CS185.Boot.snap59905

private theorem boot_rep : (Rays.mk (some (13 : Fin 185)) 1 bootRight).Rep endpoint := by
  refine ⟨rfl, ?_, ?_⟩
  · intro i
    by_cases small : i<256
    · have checked : ∀ j : Fin 256,
          endpoint.tape (endpoint.head + (j.val : Int)) = bootRight.testBit j.val := by decide +kernel
      exact checked ⟨i,small⟩
    · have headEq : endpoint.head = -1 := by decide
      rw [headEq]
      change tape 256 (-10) (fun _ => false) CS185.Boot.snap59905.bits ((-1) + (i : Int)) = bootRight.testBit i
      have outside : ¬(0 ≤ -1 + (i : Int) - -10 ∧ -1 + (i : Int) - -10 < ((256:Nat):Int)) := by omega
      have below : bootRight < 2^256 := by decide +kernel
      have bigger : (2:Nat)^256 ≤ 2^i := Nat.pow_le_pow_right (by decide) (by omega)
      simp only [tape,outside,ite_false,Nat.testBit_lt_two_pow (below.trans_le bigger)]
  · intro i
    by_cases small : i<256
    · have checked : ∀ j : Fin 256,
          endpoint.tape (endpoint.head - ((j.val : Int) + 1)) = (1:Nat).testBit j.val := by decide +kernel
      exact checked ⟨i,small⟩
    · have headEq : endpoint.head = -1 := by decide
      rw [headEq]
      change tape 256 (-10) (fun _ => false) CS185.Boot.snap59905.bits ((-1) - ((i : Int)+1)) = (1:Nat).testBit i
      have outside : ¬(0 ≤ -1 - ((i : Int)+1) - -10 ∧ -1 - ((i : Int)+1) - -10 < ((256:Nat):Int)) := by omega
      have below : (1 : Nat) < 2^i := Nat.one_lt_two_pow (by omega)
      simp only [tape,outside,ite_false,Nat.testBit_lt_two_pow below]

private theorem rep_unique {c : NF210.TM.Configuration 185} {a b : Rays 185}
    (ha : a.Rep c) (hb : b.Rep c) : a=b := by
  cases a with
  | mk q l p =>
    cases b with
    | mk r ll pp =>
      congr 1
      · exact ha.1.symm.trans hb.1
      · exact Nat.eq_of_testBit_eq fun i => (ha.2.2 i).symm.trans (hb.2.2 i)
      · exact Nat.eq_of_testBit_eq fun i => (ha.2.1 i).symm.trans (hb.2.1 i)

/-- The complete packed frame at the end of the original 48,867-step blank-tape startup. -/
theorem boot_rays : Rays.run machine start 59905 = ⟨some 13,1,bootRight⟩ := by
  apply rep_unique (c:=endpoint) _ boot_rep
  unfold endpoint
  rw [← CS185.Boot.blank_safe_gap]
  exact Rays.rep_run machine start 59905

/-- The literal table starts its post-boot simulation with these exact tape
rays in every PA model. -/
theorem model_boot {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    rawRun machine start (59905 : V) = pack 13 1 (bootRight : V) := by
  rw [show (59905:V)=((59905:Nat):V) by norm_num,run_standard,boot_rays]
  simp [stdPack,PA192.LiteralTM.control]
end NF185PA.Gate
#print axioms NF185PA.Gate.model_boot
