import SeedSyntax
import ExtractOps
import Foundation.FirstOrder.Arithmetic.PeanoMinus.Basic

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
namespace NF192.Direct.Baseline

structure Ctx (n : Nat) where
  D : Fin n
  z : Fin n
  s : Fin n
  a : Fin n
  m : Fin n
def Ctx.up (p : Ctx n) : Ctx (n+1) := ⟨p.D.succ,p.z.succ,p.s.succ,p.a.succ,p.m.succ⟩

def unordered (a b v : Fin n) : SetForm n :=
  .all (.iff (.mem 0 v.succ) (.or (.eq 0 a.succ) (.eq 0 b.succ)))
def ordered (a b v : Fin n) : SetForm n :=
  .ex (.ex (.and (unordered a.succ.succ a.succ.succ 1)
    (.and (unordered a.succ.succ b.succ.succ 0) (unordered 1 0 v.succ.succ))))
def edge (g x y : Fin n) : SetForm n := .ex (.and (.mem 0 g.succ) (ordered x.succ y.succ 0))
def tri (g x y z : Fin n) : SetForm n :=
  .ex (.ex (.ex (.and (ordered x.succ.succ.succ y.succ.succ.succ 2)
    (.and (ordered z.succ.succ.succ z.succ.succ.succ 1)
      (.and (ordered 2 1 0) (.mem 0 g.succ.succ.succ))))))
def less (p : Ctx n) (x y : Fin n) : SetForm n :=
  .ex (.ex (.and (.mem 1 p.D.succ.succ) (.and (.mem 0 p.D.succ.succ)
    (.and (edge p.s.succ.succ 1 0) (tri p.a.succ.succ x.succ.succ 0 y.succ.succ)))))

variable {X : Type u} (m : X→X→Prop) (e : Fin n→X)
@[simp] theorem unordered_sat (a b v : Fin n) : (unordered a b v).truth m e ↔ Unordered m (e a) (e b) (e v) := Iff.rfl
@[simp] theorem ordered_sat (a b v : Fin n) : (ordered a b v).truth m e ↔ Ordered m (e a) (e b) (e v) := Iff.rfl
@[simp] theorem edge_sat (g x y : Fin n) : (edge g x y).truth m e ↔ Edge m (e g) (e x) (e y) := Iff.rfl
@[simp] theorem tri_sat (g x y z : Fin n) : (tri g x y z).truth m e ↔ Tri m (e g) (e x) (e y) (e z) := Iff.rfl
@[simp] theorem less_sat (p : Ctx n) (x y : Fin n) : (less p x y).truth m e ↔
    ∃ a b, m a (e p.D) ∧ m b (e p.D) ∧ Edge m (e p.s) a b ∧ Tri m (e p.a) (e x) b (e y) := Iff.rfl

/-- Lift two graph subterms into a common two-witness number context. -/
def binTerm (p : Ctx k) (g out : Fin k) (L R : (h : Nat) → (Fin k → Fin h) → Fin h → SetForm h) : SetForm k :=
  .ex (.ex (.and (.mem 1 p.D.succ.succ) (.and (.mem 0 p.D.succ.succ)
    (.and (L _ (fun i=>i.succ.succ) 1) (.and (R _ (fun i=>i.succ.succ) 0)
      (tri g.succ.succ 1 0 out.succ.succ))))))

def Ctx.map (p : Ctx n) (r : Fin n → Fin k) : Ctx k := ⟨r p.D,r p.z,r p.s,r p.a,r p.m⟩

def term : (t : ClosedSemiterm ℒₒᵣ n) → {k : Nat} → Ctx k → (Fin n → Fin k) → Fin k → SetForm k
  | .bvar i,_,_,v,o => .eq (v i) o
  | .fvar i,_,_,_,_ => nomatch i
  | .func .zero _,_,p,_,o => .eq p.z o
  | .func .one _,_,p,_,o => edge p.s p.z o
  | .func .add ts,_,p,v,o => binTerm p p.a o (fun _ r i=>term (ts 0) (p.map r) (r ∘ v) i)
    (fun _ r i=>term (ts 1) (p.map r) (r ∘ v) i)
  | .func .mul ts,_,p,v,o => binTerm p p.m o (fun _ r i=>term (ts 0) (p.map r) (r ∘ v) i)
    (fun _ r i=>term (ts 1) (p.map r) (r ∘ v) i)

def atom (p : Ctx k) (v : Fin n → Fin k) (q : (ℒₒᵣ).Rel l) (ts : Fin l → ClosedSemiterm ℒₒᵣ n) : SetForm k :=
  match q with
  | .eq => .ex (.ex (.and (.mem 1 p.D.succ.succ) (.and (.mem 0 p.D.succ.succ)
    (.and (term (ts 0) p.up.up (fun i=>(v i).succ.succ) 1)
    (.and (term (ts 1) p.up.up (fun i=>(v i).succ.succ) 0) (.eq 1 0))))))
  | .lt => .ex (.ex (.and (.mem 1 p.D.succ.succ) (.and (.mem 0 p.D.succ.succ)
    (.and (term (ts 0) p.up.up (fun i=>(v i).succ.succ) 1)
    (.and (term (ts 1) p.up.up (fun i=>(v i).succ.succ) 0) (less p.up.up 1 0))))))

def formula : {n : Nat} → ArithmeticSemisentence n → {k : Nat} → Ctx k → (Fin n → Fin k) → SetForm k
  | _, .rel h t,_,p,v => atom p v h t
  | _, .nrel h t,_,p,v => .not (atom p v h t)
  | _, ⊤,_,p,_ => .eq p.z p.z
  | _, ⊥,_,p,_ => .not (.eq p.z p.z)
  | _, a ⋏ b,_,p,v => .and (formula a p v) (formula b p v)
  | _, a ⋎ b,_,p,v => .or (formula a p v) (formula b p v)
  | _, ∀¹ a,_,p,v => .all (.imp (.mem 0 p.D.succ) (formula a p.up (Fin.cases 0 (fun i=>(v i).succ))))
  | _, ∃¹ a,_,p,v => .ex (.and (.mem 0 p.D.succ) (formula a p.up (Fin.cases 0 (fun i=>(v i).succ))))

open PeanoMinus.Axiom in
def axioms : List ArithmeticSentence := [addZero,addAssoc,addComm,addEqOfLt,zeroLe,zeroLtOne,oneLeOfZeroLt,addLtAdd,
  mulZero,mulOne,mulAssoc,mulComm,mulLtMul,distr,ltIrrefl,ltTrans,ltTri]

def conjunction (d : Fin k) : List (SetForm k) → SetForm k
  | [] => .eq d d
  | x::xs => .and x (conjunction d xs)

def six : Ctx 6 := ⟨5,4,3,2,1⟩
def peanoMinusBody : SetForm 6 := conjunction six.z (axioms.map (fun s=>formula s six Fin.elim0))

end NF192.Direct.Baseline
