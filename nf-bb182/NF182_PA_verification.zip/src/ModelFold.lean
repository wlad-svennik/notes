module
public import ModelTrees
public import Foundation.FirstOrder.Arithmetic.HFS.Seq

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Numerals.FoundationRoute
set_option maxHeartbeats 2000000
set_option maxRecDepth 6000
namespace PA192.ModelSearch

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

instance plainSeq : Language.DefinablePred ℒₒᵣ (Seq (V:=V)) :=
  FFL.FirstOrder.Defined.to_definable (φ:=seqDef.val) ⟨(seq_defined (V:=V)).df⟩
instance plainLh : Language.DefinableFunction₁ ℒₒᵣ (lh (V:=V)) :=
  FFL.FirstOrder.Defined.to_definable (φ:=lhDef.val) ⟨(lh_defined (V:=V)).df⟩
instance plainZnth : Language.DefinableFunction₂ ℒₒᵣ (znth (V:=V)) :=
  FFL.FirstOrder.Defined.to_definable (φ:=znthDef.val) ⟨(znth_defined (V:=V)).df⟩
instance plainCons : Language.DefinableFunction₂ ℒₒᵣ (seqCons (V:=V)) :=
  FFL.FirstOrder.Defined.to_definable (φ:=seqConsDef.val) ⟨(seqCons_defined (V:=V)).df⟩

section Tables
variable (f : V → V → V) [Language.DefinableFunction₂ ℒₒᵣ f]

noncomputable def pushResult (s : V) := seqCons s (f (lh s) s)
instance pushDef : Language.DefinableFunction₁ ℒₒᵣ (pushResult f) := by unfold pushResult; definability

noncomputable def table (n : V) := Iteration.value (∅ : V) (pushResult f) n
instance tableDef : Language.DefinableFunction₁ ℒₒᵣ (table f) := by unfold table; infer_instance

@[simp] theorem table_zero : table f (0:V) = ∅ := Iteration.value_zero _ _
theorem table_succ (n : V) : table f (n+1) = seqCons (table f n) (f (lh (table f n)) (table f n)) :=
  Iteration.value_succ _ _ n

theorem table_spec : ∀ n : V, Seq (table f n) ∧ lh (table f n)=n := by
  apply modelInduct
  · definability
  · simp
  · intro n ih
    rw [table_succ]
    exact ⟨ih.1.seqCons _,(Seq.lh_seqCons _ ih.1).trans (congrArg (·+1) ih.2)⟩

noncomputable def entry (n : V) := f n (table f n)
instance entryDef : Language.DefinableFunction₁ ℒₒᵣ (entry f) := by unfold entry; definability

theorem table_lookup : ∀ n : V, ∀ k, k<n → znth (table f n) k = entry f k := by
  apply modelInduct
  · definability
  · intro k hk; exact False.elim ((not_lt_of_ge (show (0:V)≤k from zero_le)) hk)
  · intro n ih k hk
    obtain ⟨hs,hl⟩ := table_spec f n
    rw [table_succ,hl]
    rcases lt_or_eq_of_le (lt_succ_iff_le.mp hk) with before|same
    · have prev : ⟪k,znth (table f n) k⟫∈table f n := hs.znth (by rw [hl]; exact before)
      have new := (Seq.subset_seqCons (table f n) (entry f n)) prev
      exact ((hs.seqCons _).znth_eq_of_mem new).trans (ih k before)
    · subst k
      apply (hs.seqCons _).znth_eq_of_mem
      simpa only [entry,hl] using Seq.mem_seqCons (table f n) (f n (table f n))
end Tables

noncomputable def left (x : V) := pi₁ (inversePair x)
noncomputable def right (x : V) := pi₂ (inversePair x)
instance leftDef : Language.DefinableFunction₁ ℒₒᵣ (left (V:=V)) := by unfold left; definability
instance rightDef : Language.DefinableFunction₁ ℒₒᵣ (right (V:=V)) := by unfold right; definability

@[simp] theorem left_cantor (a b : V) : left (cantor a b)=a := by simp [left,inversePair_cantor]
@[simp] theorem right_cantor (a b : V) : right (cantor a b)=b := by simp [right,inversePair_cantor]

noncomputable def chooseZero (n yes no : V) := if n=0 then yes else no

instance chooseZeroDef : Language.DefinableFunction₃ ℒₒᵣ (chooseZero (V:=V)) := by
  apply Language.Definable.of_iff (Q:=fun v : Fin 4→V =>
    (v 1=0 ∧ v 0=v 2) ∨ (v 1≠0 ∧ v 0=v 3)) (by definability)
  intro v
  by_cases h : v 1=0 <;> simp [chooseZero,h]

noncomputable def leafData (i u b c d : V) :=
  cantor i (cantor u (cantor b (cantor c d)))

section Fold
variable (zero : V) (leaf : V → V) (join : V → V → V → V)
  [Language.DefinableFunction₁ ℒₒᵣ leaf] [Language.DefinableFunction₃ ℒₒᵣ join]

/-- Complete one numerical table row. Every lookup of a genuine child has smaller index. -/
noncomputable def nodeStep (n t : V) : V :=
  let z := n-1
  let payload := right z
  chooseZero n zero (chooseZero (left z) (leaf payload)
    (join (znth t (left payload)) (znth t (left (right payload))) (right (right payload))))

instance nodeStepDef : Language.DefinableFunction₂ ℒₒᵣ (nodeStep zero leaf join) := by
  unfold nodeStep; definability

noncomputable def foldCode (n : V) : V := entry (nodeStep zero leaf join) n

instance foldDef : Language.DefinableFunction₁ ℒₒᵣ (foldCode zero leaf join) := by
  unfold foldCode; infer_instance

theorem fold_zero : foldCode zero leaf join 0 = zero := by
  change nodeStep zero leaf join 0 _ = _
  simp [nodeStep,chooseZero]

theorem fold_row (i u b c d : V) : foldCode zero leaf join (rowCode i u b c d) = leaf (leafData i u b c d) := by
  change nodeStep zero leaf join (rowCode i u b c d) _ = _
  simp [nodeStep,chooseZero,rowCode,leafData]

theorem fold_detach (l r b : V) :
    foldCode zero leaf join (detachCode l r b) = join (foldCode zero leaf join l) (foldCode zero leaf join r) b := by
  let f := nodeStep zero leaf join
  let n := detachCode l r b
  have h : nodeStep zero leaf join n (table f n) =
      join (znth (table f n) l) (znth (table f n) r) b := by
    simp [nodeStep,chooseZero,n,detachCode]
  exact h.trans (by rw [table_lookup f n l (minor_lower ..),table_lookup f n r (major_lower ..)]
                    ; rfl)
end Fold

end PA192.ModelSearch
#print axioms PA192.ModelSearch.fold_detach
