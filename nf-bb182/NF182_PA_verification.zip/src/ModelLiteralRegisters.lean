module
public import ModelSourceFields
public import LiteralRegisterProgram

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterFields
set_option maxHeartbeats 3000000
set_option maxRecDepth 10000
namespace PA192.ModelSearch.RegisterSource

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- Numerical source configuration. The cold flag occupies a distinct word. -/
noncomputable def config (pc flag regs : V) : V := ⟪pc,⟪flag,regs⟫⟫
noncomputable def address (e : V) := pi₁ e
noncomputable def cold (e : V) := pi₁ (pi₂ e)
noncomputable def registers (e : V) := pi₂ (pi₂ e)
instance configDef : Language.DefinableFunction₃ ℒₒᵣ (config (V:=V)) := by unfold config; definability
instance addressDef : Language.DefinableFunction₁ ℒₒᵣ (address (V:=V)) := by unfold address; definability
instance coldDef : Language.DefinableFunction₁ ℒₒᵣ (cold (V:=V)) := by unfold cold; definability
instance registersDef : Language.DefinableFunction₁ ℒₒᵣ (registers (V:=V)) := by unfold registers; definability

@[simp] theorem address_config (pc f r : V) : address (config pc f r)=pc := by simp [address,config]
@[simp] theorem cold_config (pc f r : V) : cold (config pc f r)=f := by simp [cold,config]
@[simp] theorem registers_config (pc f r : V) : registers (config pc f r)=r := by simp [registers,config]

/-- Nine register words, in numerical R0,...,R8 order, with a zero terminator. -/
noncomputable def vector (a b c d e f g h i : V) : V :=
  ⟪a,⟪b,⟪c,⟪d,⟪e,⟪f,⟪g,⟪h,⟪i,0⟫⟫⟫⟫⟫⟫⟫⟫⟫

noncomputable def readReg : Nat → V → V
  | 0, r => pi₁ r
  | i+1, r => readReg i (pi₂ r)

noncomputable def writeReg : Nat → V → V → V
  | 0, r, a => ⟪a,pi₂ r⟫
  | i+1, r, a => ⟪pi₁ r,writeReg i (pi₂ r) a⟫

instance readRegDef (i : Nat) : Language.DefinableFunction₁ ℒₒᵣ (readReg (V:=V) i) := by
  induction i with
  | zero => change Language.DefinableFunction₁ ℒₒᵣ (pi₁ (V:=V)); infer_instance
  | succ i ih => change Language.DefinableFunction₁ ℒₒᵣ (fun r : V => readReg i (pi₂ r)); definability

instance writeRegDef (i : Nat) : Language.DefinableFunction₂ ℒₒᵣ (writeReg (V:=V) i) := by
  induction i with
  | zero => change Language.DefinableFunction₂ ℒₒᵣ (fun r a : V => ⟪a,pi₂ r⟫); definability
  | succ i ih => change Language.DefinableFunction₂ ℒₒᵣ (fun r a : V => ⟪pi₁ r,writeReg i (pi₂ r) a⟫); definability

@[simp] theorem readReg_write (i : Nat) (r v : V) : readReg i (writeReg i r v)=v := by
  induction i generalizing r with
  | zero => simp [writeReg,readReg]
  | succ i ih => simp [writeReg,readReg,ih]

theorem readReg_other (i j : Nat) (ne : i ≠ j) (r v : V) : readReg i (writeReg j r v)=readReg i r := by
  induction i generalizing j r with
  | zero => cases j <;> simp_all [readReg,writeReg]
  | succ i ih => cases j <;> simp_all [readReg,writeReg]

/-- The first R0 increment clears the signed startup debt.
All other instructions have their literal register effects. -/
noncomputable def perform (ins : Instr) (f r : V) : V :=
  match ins with
  | .jump target => config (target:V) f r
  | .inc 0 target => config (target:V) 0 (writeReg 0 r (chooseZero f (readReg 0 r+1) 0))
  | .inc (i+1) target => config (target:V) f (writeReg (i+1) r (readReg (i+1) r+1))
  | .dec i zer pos => chooseZero (readReg i r)
      (config (zer:V) f (writeReg i r 0)) (config (pos:V) f (writeReg i r (readReg i r-1)))

instance performDef (ins : Instr) : Language.DefinableFunction₂ ℒₒᵣ (perform (V:=V) ins) := by
  cases ins with
  | jump target => unfold perform; definability
  | inc reg target => cases reg <;> unfold perform <;> definability
  | dec reg z p => unfold perform; definability

/-- Frozen indexed dispatch. Falling off the listed instructions gives the literal halt record. -/
noncomputable def dispatch : List Instr → V → V → V → V
  | [], _, f, r => config 4095 f r
  | op::rest, pc, f, r => chooseZero pc (perform op f r) (dispatch rest (pc-1) f r)

instance dispatchDef (ops : List Instr) : Language.DefinableFunction₃ ℒₒᵣ (dispatch (V:=V) ops) := by
  induction ops with
  | nil => change Language.DefinableFunction₃ ℒₒᵣ (fun _ f r : V => config 4095 f r); definability
  | cons op rest ih =>
    change Language.DefinableFunction₃ ℒₒᵣ (fun pc f r : V => chooseZero pc (perform op f r) (dispatch rest (pc-1) f r))
    definability

/-- This theorem recovers an exact instruction from the literal table at each standard location.
All register and flag values are arbitrary elements of the PA model. -/
theorem dispatch_get (ops : List Instr) (i : Nat) (op : Instr) (h : ops[i]?=some op) (f r : V) :
    dispatch ops (i:V) f r=perform op f r := by
  induction ops generalizing i with
  | nil => simp at h
  | cons hd tl ih =>
    cases i with
    | zero => simp at h; subst op; simp [dispatch,chooseZero]
    | succ i =>
      simp at h
      simpa [dispatch,chooseZero,Nat.cast_succ] using ih i h

theorem dispatch_falloff (ops : List Instr) (pc f r : V) (h : (ops.length:V) ≤ pc) :
    dispatch ops pc f r=config 4095 f r := by
  induction ops generalizing pc with
  | nil => rfl
  | cons hd tl ih =>
    have bound : (tl.length:V)+1 ≤ pc := by simpa [Nat.cast_succ] using h
    have pos : 0<pc := lt_of_lt_of_le (by simp) bound
    have sub : (tl.length:V) ≤ pc-1 := le_sub_one_of_lt (lt_of_lt_of_le (by simp) bound)
    simp [dispatch,chooseZero,pos.ne',ih (pc-1) sub]

noncomputable def step (e : V) : V := dispatch program (address e) (cold e) (registers e)
instance stepDef : Language.DefinableFunction₁ ℒₒᵣ (step (V:=V)) := by
  unfold step; definability

theorem step_at (i : Nat) (op : Instr) (h : program[i]?=some op) (f r : V) :
    step (config (i:V) f r)=perform op f r := by
  simpa [step] using dispatch_get program i op h f r

@[simp] theorem step_terminal (f r : V) : step (config 4095 f r)=config 4095 f r := by
  simp only [step,address_config,cold_config,registers_config]
  apply dispatch_falloff
  rw [program_length]
  have h : (3089 : Nat) ≤ 4095 := by decide
  exact_mod_cast h

/-- Internal source clock and exact literal source execution, including nonstandard times. -/
noncomputable def run (time initial : V) : V := iterate step time initial
instance runDef : Language.DefinableFunction₂ ℒₒᵣ (run (V:=V)) := by unfold run; infer_instance
@[simp] theorem run_zero (e : V) : run 0 e=e := iterate_zero step e
theorem run_succ (t e : V) : run (t+1) e=step (run t e) := iterate_succ step t e
theorem run_succ_left (t e : V) : run (t+1) e=run t (step e) := iterate_succ_left step t e
theorem run_add (a b e : V) : run (a+b) e=run b (run a e) := iterate_add step a e b

theorem run_terminal (f r : V) (t : V) : run t (config 4095 f r)=config 4095 f r := by
  induction t using modelInduct
  case defP => definability
  case zero => simp
  case step t ih => rw [run_succ,ih,step_terminal]

noncomputable def coldMargin : V := config 91 1 (vector 0 0 0 2 0 0 0 2 0)
noncomputable def warmBoundary (n t s p h z : V) : V := config 0 0 (vector n t s 0 p h 0 0 z)
def sourceHalts (x : V) : Prop := ∃ t : V, address (run t x)=4095

end PA192.ModelSearch.RegisterSource
#print axioms PA192.ModelSearch.RegisterSource.step_at
#print axioms PA192.ModelSearch.RegisterSource.run_terminal
