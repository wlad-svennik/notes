import NativeCoreGraphs
import EnhancedSeed
namespace NF192.Direct
set_option maxRecDepth 30000
set_option maxHeartbeats 3000000
def enhancedBody : SetForm 6 := .and arithmeticBody
  (.and aux_totalHead (.and aux_totalTail (.and aux_inverseTail aux_orderGraph)))
def strengthen (χ : SetForm 6) : SetForm 0 := .ex (.ex (.ex (.ex (.ex (.ex (.and enhancedBody χ))))))
theorem nativeClosureAt {X : Type} [Nonempty X] (M : NFUCut.Model X) (D z S A B P : X)
    (h : CoreAt M.mem D z S A B P) : ClosureAt M.mem D z S A B P := by
  exact ⟨close_head_graph M _ _ _ _ _ _ h,close_tail_graph M _ _ _ _ _ _ h,
    close_zero_graph M _ _ _ _ _ _ h,close_successor_graph M _ _ _ _ _ _ h,
    close_addition_graph M _ _ _ _ _ _ h,close_multiplication_graph M _ _ _ _ _ _ h,
    close_compose M _ _ _ _ _ _ h,close_fork M _ _ _ _ _ _ h,close_common_value M _ _ _ _ _ _ h,
    close_complement M _ _ _ _ _ _ h,close_intersection M _ _ _ _ _ _ h,
    close_exists_head M _ _ _ _ _ _ h,close_parameter_slice M _ _ _ _ _ _ h⟩

theorem enhancedBody_iff {X : Type u} (m : X→X→Prop) (D z S A B P : X) :
    enhancedBody.truth m ![P,B,A,S,z,D] ↔ CoreAt m D z S A B P ∧ ClosureAt m D z S A B P ∧ ExtraAt m D z S A P := by
  constructor
  · rintro ⟨h,ex⟩;exact ⟨⟨h.1,h.2.1,h.2.2.1,h.2.2.2.1,h.2.2.2.2.1,h.2.2.2.2.2.1,h.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.2.2.2.2.1⟩,h.2.2.2.2.2.2.2.2.2.2.2.2.2.2,ex⟩
  · rintro ⟨h,c,ex⟩;exact ⟨⟨h.1,h.2.1,h.2.2.1,h.2.2.2.1,h.2.2.2.2.1,h.2.2.2.2.2.1,h.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.2.2.2.1,h.2.2.2.2.2.2.2.2.2.2.2.2.2,c⟩,ex⟩
theorem strengthen_iff {X : Type u} (m : X→X→Prop) (χ : SetForm 6) :
    (strengthen χ).truth m Fin.elim0 ↔ ∃D z S A B P,CoreAt m D z S A B P ∧ ClosureAt m D z S A B P ∧ ExtraAt m D z S A P ∧ χ.truth m ![P,B,A,S,z,D] := by
  constructor
  · rintro ⟨D,z,S,A,B,P,h,hχ⟩
    obtain ⟨hc,cl,aux⟩ := (enhancedBody_iff m D z S A B P).mp h
    exact ⟨D,z,S,A,B,P,hc,cl,aux,hχ⟩
  · rintro ⟨D,z,S,A,B,P,hc,cl,aux,hχ⟩
    exact ⟨D,z,S,A,B,P,(enhancedBody_iff m D z S A B P).mpr ⟨hc,cl,aux⟩,hχ⟩
theorem strengthenNative (χ : SetForm 6) {X : Type} [Nonempty X] (M : NFUCut.Model X) [Fact M.Infinity]
    (valid : ∀S A B P,OpsLaws M.mem M.nat M.zero S A B P (nativeNumbers M) → χ.truth M.mem ![P,B,A,S,M.zero,M.nat]) :
    (strengthen χ).truth M.mem Fin.elim0 := by
  obtain ⟨S,A,B,P,h,L⟩ := nativeCoreGraphs M
  exact (strengthen_iff _ _).mpr ⟨_,_,_,_,_,_,h,nativeClosureAt M _ _ _ _ _ _ h,
    ⟨get_totalHead M _ _ _ _ _ _ h,get_totalTail M _ _ _ _ _ _ h,get_inverseTail M _ _ _ _ _ _ h,
      get_orderGraph M _ _ _ _ _ _ h⟩,valid _ _ _ _ L⟩
#print axioms strengthenNative
end NF192.Direct
