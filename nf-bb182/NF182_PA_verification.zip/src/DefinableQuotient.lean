module
public import DefinableIteration

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace PA192.Numerals.FoundationRoute

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- Least-number principle for unconstrained arithmetical formulas with parameters. -/
theorem least_plain (P : V → Prop) [d : Language.DefinablePred ℒₒᵣ P] {x : V} (hx : P x) :
    ∃ y, P y ∧ ∀ z<y, ¬P z := by
  classical
  by_contra h
  have lower (w : V) (hw : P w) : ∃ z, z<w ∧ P z := by
    by_contra no
    exact h ⟨w,hw,fun z hz hp => no ⟨z,hz,hp⟩⟩
  have empty : ∀ w:V, ∀ z<w, ¬P z := by
    apply induction_of_arith
    · apply arithPred_of_definable
      definability
    · intro z hz
      change z<0 at hz
      exact False.elim ((not_lt_of_ge (show (0:V)≤z from zero_le)) hz)
    · intro w ih z hz hp
      obtain ⟨z',hz',hp'⟩ := lower z hp
      exact ih _ (lt_of_lt_of_le hz' (lt_succ_iff_le.mp hz)) hp'
  exact empty (x+1) x (by simp) hx

variable {A : Type} [ORingStructure A]

/-- A total decoding of arithmetic objects. The equivalence relation and both
operation graphs are arithmetic in V. Non-domain inputs can share a chosen
default object. No choice of canonical encodings is part of these data. -/
structure QuotientGraphs (decode : V → A) : Prop where
  onto : Function.Surjective decode
  eqv : Language.DefinableRel ℒₒᵣ (fun x y => decode x=decode y)
  plus : Language.DefinableRel₃ ℒₒᵣ (fun z x y => decode z=decode x+decode y)
  times : Language.DefinableRel₃ ℒₒᵣ (fun z x y => decode z=decode x*decode y)

namespace QuotientGraphs
variable {decode : V → A} (d : QuotientGraphs decode)

def MinRep (z : V) : Prop := ∀ w<z, decode w≠decode z

include d in
private theorem minDef : Language.DefinablePred ℒₒᵣ (MinRep (decode:=decode)) := by
  let _ := d.eqv
  unfold MinRep
  definability

include d in
theorem rep_exists (a : A) : ∃ z, decode z=a ∧ MinRep (decode:=decode) z := by
  obtain ⟨x,hx⟩ := d.onto a
  let _ := d.eqv
  let : Language.DefinablePred ℒₒᵣ (fun z => decode z=decode x) :=
    Language.DefinableRel.comp (P:=fun x y:V => decode x=decode y)
      (f:=fun v:Fin 1→V => v 0) (g:=fun _ => x) (by definability) (by definability)
  obtain ⟨z,hz,least⟩ := least_plain (fun z => decode z=decode x) (x:=x) rfl
  exact ⟨z,hz.trans hx,fun w hw eq => least w hw (eq.trans hz)⟩

noncomputable def enc (a : A) : V := (d.rep_exists a).choose
theorem enc_spec (a : A) : decode (d.enc a)=a ∧ MinRep (decode:=decode) (d.enc a) :=
  (d.rep_exists a).choose_spec

omit [ORingStructure A] in
theorem equal_rep {x y : V} (ex : MinRep (decode:=decode) x) (ey : MinRep (decode:=decode) y)
    (e : decode x=decode y) : x=y := by
  rcases lt_trichotomy x y with l | m | r
  · exact False.elim (ey x l e)
  · exact m
  · exact False.elim (ex y r e.symm)

theorem enc_iff (z : V) (a : A) : z=d.enc a ↔ MinRep (decode:=decode) z ∧ decode z=a := by
  constructor
  · rintro rfl
    exact ⟨(d.enc_spec _).2,(d.enc_spec _).1⟩
  · rintro ⟨m,e⟩
    exact equal_rep m (d.enc_spec _).2 (e.trans (d.enc_spec _).1.symm)

noncomputable def codes : Codes V A := ⟨d.enc,decode,fun a => (d.enc_spec a).1⟩

theorem operations [A↓[ℒₒᵣ] ⊧* 𝗤] : OperationGraphs d.codes := by
  let _ := d.eqv
  let _ := d.plus
  let _ := d.times
  let _ := d.minDef
  constructor
  · apply Language.Definable.of_iff (Q:=fun v : Fin 2 → V => MinRep (decode:=decode) (v 0) ∧ decode (v 0)=decode (v 1)) (by definability)
    exact fun _ => d.enc_iff _ _
  · apply Language.Definable.of_iff (Q:=fun v : Fin 3 → V => MinRep (decode:=decode) (v 0) ∧ decode (v 0)=decode (v 1)+decode (v 2)) (by definability)
    exact fun _ => d.enc_iff _ _
  · apply Language.Definable.of_iff (Q:=fun v : Fin 3 → V => MinRep (decode:=decode) (v 0) ∧ decode (v 0)=decode (v 1)*decode (v 2)) (by definability)
    exact fun _ => d.enc_iff _ _

end QuotientGraphs

theorem quotient_Q_sigma_one [A↓[ℒₒᵣ] ⊧* 𝗤] {decode : V → A} (d : QuotientGraphs decode)
    (φ : 𝚺ᴬ₁.Sentence) (h : V ⊧/![] φ.val) : A ⊧/![] φ.val :=
  coded_Q_sigma_one d.codes d.operations φ h

end PA192.Numerals.FoundationRoute

#print axioms PA192.Numerals.FoundationRoute.quotient_Q_sigma_one
