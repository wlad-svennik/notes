import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2176_0 : checkWitness 2176 false false 182 = true := by decide +kernel
private theorem w2176_2 : checkWitness 2176 true false 182 = true := by decide +kernel
private theorem cases2176 : checkFour 2176 (182,0,182,0) = true := by
  simp only [checkFour, w2176_0, w2176_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2176 : Coverage 2176 2177 := checkList_sound (ws:=[(182,0,182,0)]) (by simpa only [checkList, Bool.and_true] using cases2176)
private theorem w2177_0 : checkWitness 2177 false false 589 = true := by decide +kernel
private theorem w2177_1 : checkWitness 2177 false true 4677 = true := by decide +kernel
private theorem w2177_2 : checkWitness 2177 true false 589 = true := by decide +kernel
private theorem w2177_3 : checkWitness 2177 true true 4677 = true := by decide +kernel
private theorem cases2177 : checkFour 2177 (589,4677,589,4677) = true := by
  simp only [checkFour, w2177_0, w2177_1, w2177_2, w2177_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2177 : Coverage 2177 2178 := checkList_sound (ws:=[(589,4677,589,4677)]) (by simpa only [checkList, Bool.and_true] using cases2177)
private theorem w2178_0 : checkWitness 2178 false false 8918 = true := by decide +kernel
private theorem w2178_2 : checkWitness 2178 true false 8909 = true := by decide +kernel
private theorem cases2178 : checkFour 2178 (8918,0,8909,0) = true := by
  simp only [checkFour, w2178_0, w2178_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2178 : Coverage 2178 2179 := checkList_sound (ws:=[(8918,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases2178)
private theorem w2179_0 : checkWitness 2179 false false 82 = true := by decide +kernel
private theorem w2179_2 : checkWitness 2179 true false 82 = true := by decide +kernel
private theorem cases2179 : checkFour 2179 (82,0,82,0) = true := by
  simp only [checkFour, w2179_0, w2179_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2179 : Coverage 2179 2180 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2179)
private theorem w2180_0 : checkWitness 2180 false false 74 = true := by decide +kernel
private theorem w2180_2 : checkWitness 2180 true false 74 = true := by decide +kernel
private theorem cases2180 : checkFour 2180 (74,0,74,0) = true := by
  simp only [checkFour, w2180_0, w2180_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2180 : Coverage 2180 2181 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2180)
private theorem w2181_0 : checkWitness 2181 false false 595 = true := by decide +kernel
private theorem w2181_1 : checkWitness 2181 false true 4687 = true := by decide +kernel
private theorem w2181_2 : checkWitness 2181 true false 595 = true := by decide +kernel
private theorem w2181_3 : checkWitness 2181 true true 4687 = true := by decide +kernel
private theorem cases2181 : checkFour 2181 (595,4687,595,4687) = true := by
  simp only [checkFour, w2181_0, w2181_1, w2181_2, w2181_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2181 : Coverage 2181 2182 := checkList_sound (ws:=[(595,4687,595,4687)]) (by simpa only [checkList, Bool.and_true] using cases2181)
private theorem w2182_0 : checkWitness 2182 false false 8856 = true := by decide +kernel
private theorem w2182_2 : checkWitness 2182 true false 8852 = true := by decide +kernel
private theorem cases2182 : checkFour 2182 (8856,0,8852,0) = true := by
  simp only [checkFour, w2182_0, w2182_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2182 : Coverage 2182 2183 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases2182)
private theorem w2183_0 : checkWitness 2183 false false 74 = true := by decide +kernel
private theorem w2183_2 : checkWitness 2183 true false 74 = true := by decide +kernel
private theorem cases2183 : checkFour 2183 (74,0,74,0) = true := by
  simp only [checkFour, w2183_0, w2183_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2183 : Coverage 2183 2184 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2183)
private theorem w2184_0 : checkWitness 2184 false false 556 = true := by decide +kernel
private theorem w2184_1 : checkWitness 2184 false true 4652 = true := by decide +kernel
private theorem w2184_2 : checkWitness 2184 true false 556 = true := by decide +kernel
private theorem w2184_3 : checkWitness 2184 true true 4652 = true := by decide +kernel
private theorem cases2184 : checkFour 2184 (556,4652,556,4652) = true := by
  simp only [checkFour, w2184_0, w2184_1, w2184_2, w2184_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2184 : Coverage 2184 2185 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases2184)
private theorem w2185_0 : checkWitness 2185 false false 8891 = true := by decide +kernel
private theorem w2185_2 : checkWitness 2185 true false 8887 = true := by decide +kernel
private theorem cases2185 : checkFour 2185 (8891,0,8887,0) = true := by
  simp only [checkFour, w2185_0, w2185_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2185 : Coverage 2185 2186 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases2185)
private theorem w2186_0 : checkWitness 2186 false false 8926 = true := by decide +kernel
private theorem w2186_2 : checkWitness 2186 true false 8917 = true := by decide +kernel
private theorem cases2186 : checkFour 2186 (8926,0,8917,0) = true := by
  simp only [checkFour, w2186_0, w2186_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2186 : Coverage 2186 2187 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases2186)
private theorem w2187_0 : checkWitness 2187 false false 92 = true := by decide +kernel
private theorem w2187_2 : checkWitness 2187 true false 92 = true := by decide +kernel
private theorem cases2187 : checkFour 2187 (92,0,92,0) = true := by
  simp only [checkFour, w2187_0, w2187_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2187 : Coverage 2187 2188 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases2187)
private theorem w2188_0 : checkWitness 2188 false false 638 = true := by decide +kernel
private theorem w2188_1 : checkWitness 2188 false true 4730 = true := by decide +kernel
private theorem w2188_2 : checkWitness 2188 true false 629 = true := by decide +kernel
private theorem w2188_3 : checkWitness 2188 true true 4721 = true := by decide +kernel
private theorem cases2188 : checkFour 2188 (638,4730,629,4721) = true := by
  simp only [checkFour, w2188_0, w2188_1, w2188_2, w2188_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2188 : Coverage 2188 2189 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases2188)
private theorem w2189_0 : checkWitness 2189 false false 8887 = true := by decide +kernel
private theorem w2189_2 : checkWitness 2189 true false 8883 = true := by decide +kernel
private theorem cases2189 : checkFour 2189 (8887,0,8883,0) = true := by
  simp only [checkFour, w2189_0, w2189_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2189 : Coverage 2189 2190 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases2189)
private theorem w2190_0 : checkWitness 2190 false false 632 = true := by decide +kernel
private theorem w2190_1 : checkWitness 2190 false true 4724 = true := by decide +kernel
private theorem w2190_2 : checkWitness 2190 true false 623 = true := by decide +kernel
private theorem w2190_3 : checkWitness 2190 true true 4715 = true := by decide +kernel
private theorem cases2190 : checkFour 2190 (632,4724,623,4715) = true := by
  simp only [checkFour, w2190_0, w2190_1, w2190_2, w2190_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2190 : Coverage 2190 2191 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases2190)
private theorem w2191_0 : checkWitness 2191 false false 8856 = true := by decide +kernel
private theorem w2191_2 : checkWitness 2191 true false 8852 = true := by decide +kernel
private theorem cases2191 : checkFour 2191 (8856,0,8852,0) = true := by
  simp only [checkFour, w2191_0, w2191_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2191 : Coverage 2191 2192 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases2191)
private theorem w2192_0 : checkWitness 2192 false false 80 = true := by decide +kernel
private theorem w2192_2 : checkWitness 2192 true false 80 = true := by decide +kernel
private theorem cases2192 : checkFour 2192 (80,0,80,0) = true := by
  simp only [checkFour, w2192_0, w2192_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2192 : Coverage 2192 2193 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2192)
private theorem w2193_0 : checkWitness 2193 false false 72 = true := by decide +kernel
private theorem w2193_2 : checkWitness 2193 true false 72 = true := by decide +kernel
private theorem cases2193 : checkFour 2193 (72,0,72,0) = true := by
  simp only [checkFour, w2193_0, w2193_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2193 : Coverage 2193 2194 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2193)
private theorem w2194_0 : checkWitness 2194 false false 599 = true := by decide +kernel
private theorem w2194_1 : checkWitness 2194 false true 4687 = true := by decide +kernel
private theorem w2194_2 : checkWitness 2194 true false 599 = true := by decide +kernel
private theorem w2194_3 : checkWitness 2194 true true 4687 = true := by decide +kernel
private theorem cases2194 : checkFour 2194 (599,4687,599,4687) = true := by
  simp only [checkFour, w2194_0, w2194_1, w2194_2, w2194_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2194 : Coverage 2194 2195 := checkList_sound (ws:=[(599,4687,599,4687)]) (by simpa only [checkList, Bool.and_true] using cases2194)
private theorem w2195_0 : checkWitness 2195 false false 8872 = true := by decide +kernel
private theorem w2195_2 : checkWitness 2195 true false 8868 = true := by decide +kernel
private theorem cases2195 : checkFour 2195 (8872,0,8868,0) = true := by
  simp only [checkFour, w2195_0, w2195_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2195 : Coverage 2195 2196 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases2195)
private theorem w2196_0 : checkWitness 2196 false false 8868 = true := by decide +kernel
private theorem w2196_2 : checkWitness 2196 true false 8864 = true := by decide +kernel
private theorem cases2196 : checkFour 2196 (8868,0,8864,0) = true := by
  simp only [checkFour, w2196_0, w2196_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2196 : Coverage 2196 2197 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases2196)
private theorem w2197_0 : checkWitness 2197 false false 86 = true := by decide +kernel
private theorem w2197_2 : checkWitness 2197 true false 86 = true := by decide +kernel
private theorem cases2197 : checkFour 2197 (86,0,86,0) = true := by
  simp only [checkFour, w2197_0, w2197_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2197 : Coverage 2197 2198 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases2197)
private theorem w2198_0 : checkWitness 2198 false false 8892 = true := by decide +kernel
private theorem w2198_2 : checkWitness 2198 true false 8888 = true := by decide +kernel
private theorem cases2198 : checkFour 2198 (8892,0,8888,0) = true := by
  simp only [checkFour, w2198_0, w2198_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2198 : Coverage 2198 2199 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2198)
private theorem w2199_0 : checkWitness 2199 false false 8876 = true := by decide +kernel
private theorem w2199_2 : checkWitness 2199 true false 8872 = true := by decide +kernel
private theorem cases2199 : checkFour 2199 (8876,0,8872,0) = true := by
  simp only [checkFour, w2199_0, w2199_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2199 : Coverage 2199 2200 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases2199)
private theorem w2200_0 : checkWitness 2200 false false 504 = true := by decide +kernel
private theorem w2200_1 : checkWitness 2200 false true 4600 = true := by decide +kernel
private theorem w2200_2 : checkWitness 2200 true false 504 = true := by decide +kernel
private theorem w2200_3 : checkWitness 2200 true true 4600 = true := by decide +kernel
private theorem cases2200 : checkFour 2200 (504,4600,504,4600) = true := by
  simp only [checkFour, w2200_0, w2200_1, w2200_2, w2200_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2200 : Coverage 2200 2201 := checkList_sound (ws:=[(504,4600,504,4600)]) (by simpa only [checkList, Bool.and_true] using cases2200)
private theorem w2201_0 : checkWitness 2201 false false 8899 = true := by decide +kernel
private theorem w2201_2 : checkWitness 2201 true false 8895 = true := by decide +kernel
private theorem cases2201 : checkFour 2201 (8899,0,8895,0) = true := by
  simp only [checkFour, w2201_0, w2201_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2201 : Coverage 2201 2202 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases2201)
private theorem w2202_0 : checkWitness 2202 false false 630 = true := by decide +kernel
private theorem w2202_1 : checkWitness 2202 false true 4726 = true := by decide +kernel
private theorem w2202_2 : checkWitness 2202 true false 621 = true := by decide +kernel
private theorem w2202_3 : checkWitness 2202 true true 4717 = true := by decide +kernel
private theorem cases2202 : checkFour 2202 (630,4726,621,4717) = true := by
  simp only [checkFour, w2202_0, w2202_1, w2202_2, w2202_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2202 : Coverage 2202 2203 := checkList_sound (ws:=[(630,4726,621,4717)]) (by simpa only [checkList, Bool.and_true] using cases2202)
private theorem w2203_0 : checkWitness 2203 false false 182 = true := by decide +kernel
private theorem w2203_2 : checkWitness 2203 true false 182 = true := by decide +kernel
private theorem cases2203 : checkFour 2203 (182,0,182,0) = true := by
  simp only [checkFour, w2203_0, w2203_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2203 : Coverage 2203 2204 := checkList_sound (ws:=[(182,0,182,0)]) (by simpa only [checkList, Bool.and_true] using cases2203)
private theorem w2204_0 : checkWitness 2204 false false 585 = true := by decide +kernel
private theorem w2204_1 : checkWitness 2204 false true 4673 = true := by decide +kernel
private theorem w2204_2 : checkWitness 2204 true false 585 = true := by decide +kernel
private theorem w2204_3 : checkWitness 2204 true true 4673 = true := by decide +kernel
private theorem cases2204 : checkFour 2204 (585,4673,585,4673) = true := by
  simp only [checkFour, w2204_0, w2204_1, w2204_2, w2204_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2204 : Coverage 2204 2205 := checkList_sound (ws:=[(585,4673,585,4673)]) (by simpa only [checkList, Bool.and_true] using cases2204)
private theorem w2205_0 : checkWitness 2205 false false 8914 = true := by decide +kernel
private theorem w2205_2 : checkWitness 2205 true false 8905 = true := by decide +kernel
private theorem cases2205 : checkFour 2205 (8914,0,8905,0) = true := by
  simp only [checkFour, w2205_0, w2205_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2205 : Coverage 2205 2206 := checkList_sound (ws:=[(8914,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases2205)
private theorem w2206_0 : checkWitness 2206 false false 74 = true := by decide +kernel
private theorem w2206_2 : checkWitness 2206 true false 74 = true := by decide +kernel
private theorem cases2206 : checkFour 2206 (74,0,74,0) = true := by
  simp only [checkFour, w2206_0, w2206_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2206 : Coverage 2206 2207 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2206)
private theorem w2207_0 : checkWitness 2207 false false 66 = true := by decide +kernel
private theorem w2207_2 : checkWitness 2207 true false 66 = true := by decide +kernel
private theorem cases2207 : checkFour 2207 (66,0,66,0) = true := by
  simp only [checkFour, w2207_0, w2207_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2207 : Coverage 2207 2208 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2207)
theorem cover2176 : Coverage 2176 2208 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2176 one2177) (Coverage.join one2178 one2179)) (Coverage.join (Coverage.join one2180 one2181) (Coverage.join one2182 one2183))) (Coverage.join (Coverage.join (Coverage.join one2184 one2185) (Coverage.join one2186 one2187)) (Coverage.join (Coverage.join one2188 one2189) (Coverage.join one2190 one2191)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2192 one2193) (Coverage.join one2194 one2195)) (Coverage.join (Coverage.join one2196 one2197) (Coverage.join one2198 one2199))) (Coverage.join (Coverage.join (Coverage.join one2200 one2201) (Coverage.join one2202 one2203)) (Coverage.join (Coverage.join one2204 one2205) (Coverage.join one2206 one2207)))))
end NF182PA.Symbolic
