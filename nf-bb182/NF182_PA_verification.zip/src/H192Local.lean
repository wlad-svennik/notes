module
public import H192Rays

@[expose] public section
open NF210.TM

namespace PA192.LiteralTM

theorem Rays.step_of_working (machine : Machine n) (a : Rays n) (active : a.status ≠ none) :
    Step machine (control a.status) a.left a.right (control (a.advance machine).status)
      (a.advance machine).left (a.advance machine).right := by
  rcases a with ⟨o,l,r⟩
  cases o with
  | none => exact False.elim (active rfl)
  | some q =>
    refine ⟨q,r.testBit 0,?_⟩
    cases mv : (machine q (r.testBit 0)).move with
    | right =>
      simp only [Local,advance,mv,control,Option.elim_some,FFL.FirstOrder.Arithmetic.natCast_nat]
      exact ⟨True.intro,True.intro,r/2,bit_split r,rfl,rfl⟩
    | left =>
      simp only [Local,advance,mv,control,Option.elim_some,FFL.FirstOrder.Arithmetic.natCast_nat]
      refine ⟨True.intro,True.intro,r/2,l/2,(l.testBit 0).toNat,?_,bit_split l,bit_split r,rfl,rfl⟩
      cases l.testBit 0 <;> simp

theorem Rays.step_determines (m : Machine n) (a : Rays n) {s l r : Nat}
    (h : Step m (control a.status) a.left a.right s l r) :
    s=control (a.advance m).status ∧ l=(a.advance m).left ∧ r=(a.advance m).right := by
  rcases a with ⟨o,L,R⟩
  obtain ⟨q,b,src,tgt,h⟩ := h
  simp only [FFL.FirstOrder.Arithmetic.natCast_nat] at src tgt h
  have sq : o=some q := control_inj (by exact src)
  subst o
  cases mv : (m q b).move with
  | right =>
    simp only [mv] at h
    obtain ⟨x,hR,hl,hr⟩ := h
    have hR' : R=push b x := hR
    rw [hR']
    simp only [advance,push_head,mv,push_tail,hl,hr,tgt]
    exact ⟨True.intro,rfl,True.intro⟩
  | left =>
    simp only [mv] at h
    obtain ⟨x,y,e,he,hL,hR,hl,hr⟩ := h
    have hR' : R=push b x := hR
    rw [hR']
    rcases he with he | he
    · subst e
      have hL' : L=push false y := hL
      rw [hL']
      simp only [advance,push_head,mv,push_tail,tgt,hl,hr]
      exact ⟨True.intro,True.intro,rfl⟩
    · subst e
      have hL' : L=push true y := hL
      rw [hL']
      simp only [advance,push_head,mv,push_tail,tgt,hl,hr]
      exact ⟨True.intro,True.intro,rfl⟩

end PA192.LiteralTM

#print axioms PA192.LiteralTM.Rays.step_determines
