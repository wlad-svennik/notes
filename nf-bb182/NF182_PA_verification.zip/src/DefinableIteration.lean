module
public import CodedNumerals
public import ProofSupport

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace PA192.Numerals.FoundationRoute

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

namespace Iteration
variable (a : V) (f : V → V)

/-- A coded finite graph of a deterministic computation, indexed by an initial interval. -/
def History (n h : V) : Prop :=
  (∀ k x y, ⟪k,x⟫∈h → ⟪k,y⟫∈h → x=y) ∧
  (∀ k x, ⟪k,x⟫∈h → ¬ n<k) ∧ ⟪0,a⟫∈h ∧
  ∀ k<n, ∀ x, ⟪k,x⟫∈h → ⟪k+1,f x⟫∈h

private instance historyDef [Language.DefinableFunction₁ ℒₒᵣ f] :
    Language.DefinableRel ℒₒᵣ (History a f) := by unfold History; definability

def Graph (y n : V) : Prop := ∃ h, History a f n h ∧ ⟪n,y⟫∈h

private instance graphDef [Language.DefinableFunction₁ ℒₒᵣ f] :
    Language.DefinableRel ℒₒᵣ (Graph a f) := by unfold Graph; definability

theorem base : Graph a f a 0 := by
  refine ⟨{⟪0,a⟫},⟨?_,?_,by simp,?_⟩,by simp⟩
  · intro k x y hx hy
    simp only [mem_singleton_iff,pair_ext_iff] at hx hy
    exact hx.2.trans hy.2.symm
  · intro k x hx
    simp only [mem_singleton_iff,pair_ext_iff] at hx
    simp [hx.1]
  · intro k hk
    exact False.elim ((not_lt_of_ge (show (0:V)≤k from zero_le)) hk)

theorem extend {n u : V} (g : Graph a f u n) : Graph a f (f u) (n+1) := by
  obtain ⟨h,⟨funct,bound,init,next⟩,last⟩ := g
  let H : V := insert ⟪n+1,f u⟫ h
  have old {z : V} (m : z∈h) : z∈H := mem_bitInsert_iff.mpr (Or.inr m)
  have ne {k x : V} (m : ⟪k,x⟫∈h) : k≠n+1 := by
    rintro rfl
    exact bound _ _ m (by simp)
  refine ⟨H,⟨?_,?_,old init,?_⟩,by simp [H]⟩
  · intro k x y hx hy
    rcases mem_bitInsert_iff.mp hx with hx | hx <;> rcases mem_bitInsert_iff.mp hy with hy | hy
    · exact (pair_ext_iff.mp hx).2.trans (pair_ext_iff.mp hy).2.symm
    · exact False.elim (ne hy (pair_ext_iff.mp hx).1)
    · exact False.elim (ne hx (pair_ext_iff.mp hy).1)
    · exact funct _ _ _ hx hy
  · intro k x hx
    rcases mem_bitInsert_iff.mp hx with hx | hx
    · simp [(pair_ext_iff.mp hx).1]
    · exact not_lt_of_ge (le_trans (le_of_not_gt (bound _ _ hx)) (by simp))
  · intro k hk x hx
    have was : ⟪k,x⟫∈h := by
      rcases mem_bitInsert_iff.mp hx with hx | hx
      · exact False.elim ((ne_of_lt hk) (pair_ext_iff.mp hx).1)
      · exact hx
    rcases lt_or_eq_of_le (lt_succ_iff_le.mp hk) with kl | rfl
    · exact old (next _ kl _ was)
    · rw [funct _ _ _ was last]
      simp [H]

theorem exists_graph [Language.DefinableFunction₁ ℒₒᵣ f] : ∀ n : V, ∃ y, Graph a f y n := by
  apply induction_of_arith
  · apply arithPred_of_definable
    definability
  · exact ⟨a,base a f⟩
  · rintro n ⟨y,g⟩
    exact ⟨f y,extend a f g⟩

def Joined (h t n k : V) : Prop := ¬n<k → ∃ v, ⟪k,v⟫∈h ∧ ⟪k,v⟫∈t

private theorem joinedArith (h t n : V) : ArithPred (Joined h t n) := by
  apply arithPred_of_definable
  unfold Joined
  definability

theorem agree {n x y : V} (gx : Graph a f x n) (gy : Graph a f y n) : x=y := by
  obtain ⟨h,⟨fh,_,zh,sh⟩,xh⟩ := gx
  obtain ⟨t,⟨ft,_,zt,st⟩,yt⟩ := gy
  have both : ∀ k:V, Joined h t n k := by
    apply induction_of_arith (joinedArith h t n)
    · intro _
      exact ⟨a,zh,zt⟩
    · intro k ih hk
      have kn : k<n := lt_iff_succ_le.mpr (le_of_not_gt hk)
      obtain ⟨v,vh,vt⟩ := ih (not_lt_of_ge (le_of_lt kn))
      exact ⟨f v,sh k kn v vh,st k kn v vt⟩
  obtain ⟨v,vh,vt⟩ := both n (_root_.lt_irrefl n)
  exact (fh _ _ _ xh vh).trans (ft _ _ _ vt yt)

theorem graph_existsUnique [Language.DefinableFunction₁ ℒₒᵣ f] (n : V) : ∃! y, Graph a f y n := by
  obtain ⟨y,h⟩ := exists_graph a f n
  exact ⟨y,h,fun _ g => agree a f g h⟩

noncomputable def value [Language.DefinableFunction₁ ℒₒᵣ f] (n : V) : V :=
  Classical.choose (graph_existsUnique a f n).exists

theorem value_spec [Language.DefinableFunction₁ ℒₒᵣ f] (n : V) : Graph a f (value a f n) n :=
  Classical.choose_spec (graph_existsUnique a f n).exists

theorem graph_iff [Language.DefinableFunction₁ ℒₒᵣ f] {n y : V} : Graph a f y n ↔ y = value a f n := by
  constructor
  · intro h
    exact (graph_existsUnique a f n).unique h (value_spec a f n)
  · rintro rfl
    exact value_spec a f n

instance valueDef [Language.DefinableFunction₁ ℒₒᵣ f] : Language.DefinableFunction₁ ℒₒᵣ (value a f) := by
  apply Language.Definable.of_iff (Q := fun v : Fin 2 → V => Graph a f (v 0) (v 1))
    (graphDef a f)
  intro v
  exact (graph_iff a f).symm

@[simp] theorem value_zero [Language.DefinableFunction₁ ℒₒᵣ f] : value a f 0 = a := by
  apply Eq.symm
  apply (graph_iff a f).mp
  exact base a f

theorem value_succ [Language.DefinableFunction₁ ℒₒᵣ f] (n : V) :
    value a f (n+1) = f (value a f n) := by
  exact ((graph_iff a f).mp (extend a f (value_spec a f n))).symm

end Iteration

variable {A : Type} [ORingStructure A] [A↓[ℒₒᵣ] ⊧* 𝗤]

structure OperationGraphs (c : Codes V A) : Prop where
  norm : Language.DefinableFunction₁ ℒₒᵣ c.norm
  add : Language.DefinableFunction₂ ℒₒᵣ c.add
  mul : Language.DefinableFunction₂ ℒₒᵣ c.mul

/-- An arithmetically presented model of Q inside V has an initial arithmetic
embedding of V. The interpretation can have several codes for the same object. -/
theorem coded_Q_sigma_one (c : Codes V A) (d : OperationGraphs c)
    (φ : 𝚺ᴬ₁.Semisentence 0) (h : φ.val.Evalb (M:=V) ![]) : φ.val.Evalb (M:=A) ![] := by
  let := d.norm
  let := d.add
  let := d.mul
  let f : V → V := fun x => c.add x (c.enc 1)
  let : Language.DefinableFunction₁ ℒₒᵣ f := by dsimp [f]; definability
  let u := Iteration.value (c.enc 0) f
  let i : V → A := fun n => c.dec (u n)
  have hi : (rob V).NumeralMap (rob A) i := by
    constructor
    · simp only [i,u,rob,Iteration.value_zero,c.dec_enc]
    · intro n
      change c.dec (u (n+1)) = c.dec (u n)+1
      simp only [u,Iteration.value_succ,f,Codes.add,c.dec_enc]
  have di : c.Definable i := by
    refine ⟨d.norm, ?_, d.add, d.mul⟩
    change Language.DefinableFunction₁ ℒₒᵣ (fun n => c.norm (Iteration.value (c.enc 0) f n))
    definability
  simpa [Matrix.empty_eq] using coded_sigma_one_up i hi c di φ ![] h

end PA192.Numerals.FoundationRoute

#print axioms PA192.Numerals.FoundationRoute.coded_Q_sigma_one
