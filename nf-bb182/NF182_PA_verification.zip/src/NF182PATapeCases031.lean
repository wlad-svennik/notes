import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w992_0 : checkWitness 992 false false 8960 = true := by decide +kernel
private theorem w992_2 : checkWitness 992 true false 8951 = true := by decide +kernel
private theorem cases992 : checkFour 992 (8960,0,8951,0) = true := by
  simp only [checkFour, w992_0, w992_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one992 : Coverage 992 993 := checkList_sound (ws:=[(8960,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases992)
private theorem w993_0 : checkWitness 993 false false 86 = true := by decide +kernel
private theorem w993_2 : checkWitness 993 true false 86 = true := by decide +kernel
private theorem cases993 : checkFour 993 (86,0,86,0) = true := by
  simp only [checkFour, w993_0, w993_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one993 : Coverage 993 994 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases993)
private theorem w994_0 : checkWitness 994 false false 542 = true := by decide +kernel
private theorem w994_1 : checkWitness 994 false true 4638 = true := by decide +kernel
private theorem w994_2 : checkWitness 994 true false 542 = true := by decide +kernel
private theorem w994_3 : checkWitness 994 true true 4638 = true := by decide +kernel
private theorem cases994 : checkFour 994 (542,4638,542,4638) = true := by
  simp only [checkFour, w994_0, w994_1, w994_2, w994_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one994 : Coverage 994 995 := checkList_sound (ws:=[(542,4638,542,4638)]) (by simpa only [checkList, Bool.and_true] using cases994)
private theorem w995_0 : checkWitness 995 false false 8900 = true := by decide +kernel
private theorem w995_2 : checkWitness 995 true false 8896 = true := by decide +kernel
private theorem cases995 : checkFour 995 (8900,0,8896,0) = true := by
  simp only [checkFour, w995_0, w995_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one995 : Coverage 995 996 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases995)
private theorem w996_0 : checkWitness 996 false false 88 = true := by decide +kernel
private theorem w996_2 : checkWitness 996 true false 88 = true := by decide +kernel
private theorem cases996 : checkFour 996 (88,0,88,0) = true := by
  simp only [checkFour, w996_0, w996_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one996 : Coverage 996 997 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases996)
private theorem w997_0 : checkWitness 997 false false 586 = true := by decide +kernel
private theorem w997_1 : checkWitness 997 false true 4682 = true := by decide +kernel
private theorem w997_2 : checkWitness 997 true false 586 = true := by decide +kernel
private theorem w997_3 : checkWitness 997 true true 4682 = true := by decide +kernel
private theorem cases997 : checkFour 997 (586,4682,586,4682) = true := by
  simp only [checkFour, w997_0, w997_1, w997_2, w997_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one997 : Coverage 997 998 := checkList_sound (ws:=[(586,4682,586,4682)]) (by simpa only [checkList, Bool.and_true] using cases997)
private theorem w998_0 : checkWitness 998 false false 8921 = true := by decide +kernel
private theorem w998_2 : checkWitness 998 true false 8917 = true := by decide +kernel
private theorem cases998 : checkFour 998 (8921,0,8917,0) = true := by
  simp only [checkFour, w998_0, w998_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one998 : Coverage 998 999 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases998)
private theorem w999_0 : checkWitness 999 false false 8956 = true := by decide +kernel
private theorem w999_2 : checkWitness 999 true false 8947 = true := by decide +kernel
private theorem cases999 : checkFour 999 (8956,0,8947,0) = true := by
  simp only [checkFour, w999_0, w999_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one999 : Coverage 999 1000 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases999)
private theorem w1000_0 : checkWitness 1000 false false 112 = true := by decide +kernel
private theorem w1000_2 : checkWitness 1000 true false 112 = true := by decide +kernel
private theorem cases1000 : checkFour 1000 (112,0,112,0) = true := by
  simp only [checkFour, w1000_0, w1000_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1000 : Coverage 1000 1001 := checkList_sound (ws:=[(112,0,112,0)]) (by simpa only [checkList, Bool.and_true] using cases1000)
private theorem w1001_0 : checkWitness 1001 false false 668 = true := by decide +kernel
private theorem w1001_1 : checkWitness 1001 false true 4760 = true := by decide +kernel
private theorem w1001_2 : checkWitness 1001 true false 659 = true := by decide +kernel
private theorem w1001_3 : checkWitness 1001 true true 4751 = true := by decide +kernel
private theorem cases1001 : checkFour 1001 (668,4760,659,4751) = true := by
  simp only [checkFour, w1001_0, w1001_1, w1001_2, w1001_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1001 : Coverage 1001 1002 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases1001)
private theorem w1002_0 : checkWitness 1002 false false 8917 = true := by decide +kernel
private theorem w1002_2 : checkWitness 1002 true false 8913 = true := by decide +kernel
private theorem cases1002 : checkFour 1002 (8917,0,8913,0) = true := by
  simp only [checkFour, w1002_0, w1002_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1002 : Coverage 1002 1003 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases1002)
private theorem w1003_0 : checkWitness 1003 false false 662 = true := by decide +kernel
private theorem w1003_1 : checkWitness 1003 false true 4754 = true := by decide +kernel
private theorem w1003_2 : checkWitness 1003 true false 653 = true := by decide +kernel
private theorem w1003_3 : checkWitness 1003 true true 4745 = true := by decide +kernel
private theorem cases1003 : checkFour 1003 (662,4754,653,4745) = true := by
  simp only [checkFour, w1003_0, w1003_1, w1003_2, w1003_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1003 : Coverage 1003 1004 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases1003)
private theorem w1004_0 : checkWitness 1004 false false 8886 = true := by decide +kernel
private theorem w1004_2 : checkWitness 1004 true false 8882 = true := by decide +kernel
private theorem cases1004 : checkFour 1004 (8886,0,8882,0) = true := by
  simp only [checkFour, w1004_0, w1004_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1004 : Coverage 1004 1005 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases1004)
private theorem w1005_0 : checkWitness 1005 false false 100 = true := by decide +kernel
private theorem w1005_2 : checkWitness 1005 true false 100 = true := by decide +kernel
private theorem cases1005 : checkFour 1005 (100,0,100,0) = true := by
  simp only [checkFour, w1005_0, w1005_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1005 : Coverage 1005 1006 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1005)
private theorem w1006_0 : checkWitness 1006 false false 92 = true := by decide +kernel
private theorem w1006_2 : checkWitness 1006 true false 92 = true := by decide +kernel
private theorem cases1006 : checkFour 1006 (92,0,92,0) = true := by
  simp only [checkFour, w1006_0, w1006_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1006 : Coverage 1006 1007 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1006)
private theorem w1007_0 : checkWitness 1007 false false 627 = true := by decide +kernel
private theorem w1007_1 : checkWitness 1007 false true 4711 = true := by decide +kernel
private theorem w1007_2 : checkWitness 1007 true false 627 = true := by decide +kernel
private theorem w1007_3 : checkWitness 1007 true true 4711 = true := by decide +kernel
private theorem cases1007 : checkFour 1007 (627,4711,627,4711) = true := by
  simp only [checkFour, w1007_0, w1007_1, w1007_2, w1007_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1007 : Coverage 1007 1008 := checkList_sound (ws:=[(627,4711,627,4711)]) (by simpa only [checkList, Bool.and_true] using cases1007)
private theorem w1008_0 : checkWitness 1008 false false 8880 = true := by decide +kernel
private theorem w1008_2 : checkWitness 1008 true false 8876 = true := by decide +kernel
private theorem cases1008 : checkFour 1008 (8880,0,8876,0) = true := by
  simp only [checkFour, w1008_0, w1008_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1008 : Coverage 1008 1009 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases1008)
private theorem w1009_0 : checkWitness 1009 false false 92 = true := by decide +kernel
private theorem w1009_2 : checkWitness 1009 true false 92 = true := by decide +kernel
private theorem cases1009 : checkFour 1009 (92,0,92,0) = true := by
  simp only [checkFour, w1009_0, w1009_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1009 : Coverage 1009 1010 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1009)
private theorem w1010_0 : checkWitness 1010 false false 625 = true := by decide +kernel
private theorem w1010_1 : checkWitness 1010 false true 4717 = true := by decide +kernel
private theorem w1010_2 : checkWitness 1010 true false 616 = true := by decide +kernel
private theorem w1010_3 : checkWitness 1010 true true 4708 = true := by decide +kernel
private theorem cases1010 : checkFour 1010 (625,4717,616,4708) = true := by
  simp only [checkFour, w1010_0, w1010_1, w1010_2, w1010_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1010 : Coverage 1010 1011 := checkList_sound (ws:=[(625,4717,616,4708)]) (by simpa only [checkList, Bool.and_true] using cases1010)
private theorem w1011_0 : checkWitness 1011 false false 8922 = true := by decide +kernel
private theorem w1011_2 : checkWitness 1011 true false 8913 = true := by decide +kernel
private theorem cases1011 : checkFour 1011 (8922,0,8913,0) = true := by
  simp only [checkFour, w1011_0, w1011_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1011 : Coverage 1011 1012 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases1011)
private theorem w1012_0 : checkWitness 1012 false false 8868 = true := by decide +kernel
private theorem w1012_2 : checkWitness 1012 true false 8864 = true := by decide +kernel
private theorem cases1012 : checkFour 1012 (8868,0,8864,0) = true := by
  simp only [checkFour, w1012_0, w1012_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1012 : Coverage 1012 1013 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases1012)
private theorem w1013_0 : checkWitness 1013 false false 86 = true := by decide +kernel
private theorem w1013_2 : checkWitness 1013 true false 86 = true := by decide +kernel
private theorem cases1013 : checkFour 1013 (86,0,86,0) = true := by
  simp only [checkFour, w1013_0, w1013_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1013 : Coverage 1013 1014 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1013)
private theorem w1014_0 : checkWitness 1014 false false 652 = true := by decide +kernel
private theorem w1014_1 : checkWitness 1014 false true 4744 = true := by decide +kernel
private theorem w1014_2 : checkWitness 1014 true false 643 = true := by decide +kernel
private theorem w1014_3 : checkWitness 1014 true true 4735 = true := by decide +kernel
private theorem cases1014 : checkFour 1014 (652,4744,643,4735) = true := by
  simp only [checkFour, w1014_0, w1014_1, w1014_2, w1014_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1014 : Coverage 1014 1015 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases1014)
private theorem w1015_0 : checkWitness 1015 false false 8929 = true := by decide +kernel
private theorem w1015_2 : checkWitness 1015 true false 8920 = true := by decide +kernel
private theorem cases1015 : checkFour 1015 (8929,0,8920,0) = true := by
  simp only [checkFour, w1015_0, w1015_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1015 : Coverage 1015 1016 := checkList_sound (ws:=[(8929,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases1015)
private theorem w1016_0 : checkWitness 1016 false false 70 = true := by decide +kernel
private theorem w1016_2 : checkWitness 1016 true false 70 = true := by decide +kernel
private theorem cases1016 : checkFour 1016 (70,0,70,0) = true := by
  simp only [checkFour, w1016_0, w1016_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1016 : Coverage 1016 1017 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases1016)
private theorem w1017_0 : checkWitness 1017 false false 516 = true := by decide +kernel
private theorem w1017_1 : checkWitness 1017 false true 4612 = true := by decide +kernel
private theorem w1017_2 : checkWitness 1017 true false 516 = true := by decide +kernel
private theorem w1017_3 : checkWitness 1017 true true 4612 = true := by decide +kernel
private theorem cases1017 : checkFour 1017 (516,4612,516,4612) = true := by
  simp only [checkFour, w1017_0, w1017_1, w1017_2, w1017_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1017 : Coverage 1017 1018 := checkList_sound (ws:=[(516,4612,516,4612)]) (by simpa only [checkList, Bool.and_true] using cases1017)
private theorem w1018_0 : checkWitness 1018 false false 8911 = true := by decide +kernel
private theorem w1018_2 : checkWitness 1018 true false 8907 = true := by decide +kernel
private theorem cases1018 : checkFour 1018 (8911,0,8907,0) = true := by
  simp only [checkFour, w1018_0, w1018_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1018 : Coverage 1018 1019 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases1018)
private theorem w1019_0 : checkWitness 1019 false false 642 = true := by decide +kernel
private theorem w1019_1 : checkWitness 1019 false true 4738 = true := by decide +kernel
private theorem w1019_2 : checkWitness 1019 true false 633 = true := by decide +kernel
private theorem w1019_3 : checkWitness 1019 true true 4729 = true := by decide +kernel
private theorem cases1019 : checkFour 1019 (642,4738,633,4729) = true := by
  simp only [checkFour, w1019_0, w1019_1, w1019_2, w1019_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1019 : Coverage 1019 1020 := checkList_sound (ws:=[(642,4738,633,4729)]) (by simpa only [checkList, Bool.and_true] using cases1019)
private theorem w1020_0 : checkWitness 1020 false false 184 = true := by decide +kernel
private theorem w1020_2 : checkWitness 1020 true false 184 = true := by decide +kernel
private theorem cases1020 : checkFour 1020 (184,0,184,0) = true := by
  simp only [checkFour, w1020_0, w1020_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1020 : Coverage 1020 1021 := checkList_sound (ws:=[(184,0,184,0)]) (by simpa only [checkList, Bool.and_true] using cases1020)
private theorem w1021_0 : checkWitness 1021 false false 597 = true := by decide +kernel
private theorem w1021_1 : checkWitness 1021 false true 4685 = true := by decide +kernel
private theorem w1021_2 : checkWitness 1021 true false 597 = true := by decide +kernel
private theorem w1021_3 : checkWitness 1021 true true 4685 = true := by decide +kernel
private theorem cases1021 : checkFour 1021 (597,4685,597,4685) = true := by
  simp only [checkFour, w1021_0, w1021_1, w1021_2, w1021_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1021 : Coverage 1021 1022 := checkList_sound (ws:=[(597,4685,597,4685)]) (by simpa only [checkList, Bool.and_true] using cases1021)
private theorem w1022_0 : checkWitness 1022 false false 8926 = true := by decide +kernel
private theorem w1022_2 : checkWitness 1022 true false 8917 = true := by decide +kernel
private theorem cases1022 : checkFour 1022 (8926,0,8917,0) = true := by
  simp only [checkFour, w1022_0, w1022_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1022 : Coverage 1022 1023 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases1022)
private theorem w1023_0 : checkWitness 1023 false false 88 = true := by decide +kernel
private theorem w1023_2 : checkWitness 1023 true false 88 = true := by decide +kernel
private theorem cases1023 : checkFour 1023 (88,0,88,0) = true := by
  simp only [checkFour, w1023_0, w1023_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1023 : Coverage 1023 1024 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1023)
theorem cover0992 : Coverage 992 1024 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one992 one993) (Coverage.join one994 one995)) (Coverage.join (Coverage.join one996 one997) (Coverage.join one998 one999))) (Coverage.join (Coverage.join (Coverage.join one1000 one1001) (Coverage.join one1002 one1003)) (Coverage.join (Coverage.join one1004 one1005) (Coverage.join one1006 one1007)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1008 one1009) (Coverage.join one1010 one1011)) (Coverage.join (Coverage.join one1012 one1013) (Coverage.join one1014 one1015))) (Coverage.join (Coverage.join (Coverage.join one1016 one1017) (Coverage.join one1018 one1019)) (Coverage.join (Coverage.join one1020 one1021) (Coverage.join one1022 one1023)))))
end NF182PA.Symbolic
