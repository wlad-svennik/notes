import SelectedOps
import InternalRepresent
import Correct
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Direct
namespace NF192.Internal
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {m : X→X→Prop}
/-- Every operation used in the representative computation can be selected
    arithmetically in the ambient PA model from the fixed ordinary sentence. -/
theorem concreteOps (d : Presentation V X m) (D z S A B P : X)
    (c : ClosureAt m D z S A B P) (e : ExtraAt m D z S A P) :
    ∃ o : Operations V, DefinedOps o ∧ Correct d D z S A B P o := by
  obtain ⟨v0,rfl⟩ := d.onto D;obtain ⟨v1,rfl⟩ := d.onto z;obtain ⟨v2,rfl⟩ := d.onto S
  obtain ⟨v3,rfl⟩ := d.onto A;obtain ⟨v4,rfl⟩ := d.onto B;obtain ⟨v5,rfl⟩ := d.onto P
  obtain ⟨comp,dc,hc⟩ := select_compose d v0 v1 v2 v3 v4 v5 c
  obtain ⟨fork,df,hf⟩ := select_fork d v0 v1 v2 v3 v4 v5 c
  obtain ⟨common,dm,hm⟩ := select_common_value d v0 v1 v2 v3 v4 v5 c
  obtain ⟨cap,di,hi⟩ := select_intersection d v0 v1 v2 v3 v4 v5 c
  obtain ⟨neg,dn,hn⟩ := select_complement d v0 v1 v2 v3 v4 v5 c
  obtain ⟨h,hh⟩ := e.1;obtain ⟨hc0,rfl⟩ := d.onto h
  obtain ⟨t,ht⟩ := e.2.1;obtain ⟨tc0,rfl⟩ := d.onto t
  obtain ⟨i,ih⟩ := e.2.2.1;obtain ⟨ic0,rfl⟩ := d.onto i
  obtain ⟨l,lh⟩ := e.2.2.2;obtain ⟨lc0,rfl⟩ := d.onto l
  obtain ⟨zero,hz⟩ := c.2.2.1;obtain ⟨zc,rfl⟩ := d.onto zero
  obtain ⟨succ,hs⟩ := c.2.2.2.1;obtain ⟨sc,rfl⟩ := d.onto succ
  obtain ⟨add,ha⟩ := c.2.2.2.2.1;obtain ⟨ac,rfl⟩ := d.onto add
  obtain ⟨mul,hu⟩ := c.2.2.2.2.2.1;obtain ⟨uc,rfl⟩ := d.onto mul
  let o : Operations V := ⟨hc0,tc0,zc,sc,ac,uc,lc0,ic0,comp,fork,common,cap,neg⟩
  exact ⟨o,⟨dc,df,dm,di,dn⟩,⟨hh,ht,hz,hs,ha,hu,lh,ih,hc,hf,hm,hi,hn⟩⟩
#print axioms concreteOps
end NF192.Internal
