import InternalChoice
import SemanticAlgebra
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Direct
namespace NF192.Internal
variable {V N : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {o : Operations V} {n : NumOps N}

structure Coding (a : Algebra o n) where
  enc : N→V
  dec : V→N
  inv : ∀x,dec (enc x)=x
  normDef : Language.DefinableFunction₁ ℒₒᵣ (fun v=>enc (dec v))
  pushDef : Language.DefinableFunction₂ ℒₒᵣ (fun x y=>enc (n.pair (dec x) (dec y)))
  satDef : Language.DefinableRel ℒₒᵣ (fun r v=>a.sat r (dec v))

namespace Coding
variable {a : Algebra o n} (c : Coding a)
def norm (v : V) := c.enc (c.dec v)
def good (v : V) : Prop := v=c.norm v
def push (v w : V) := c.enc (n.pair (c.dec v) (c.dec w))
def sat (r v : V) : Prop := a.sat r (c.dec v)
def rel (r v w : V) : Prop := c.sat r (c.push v w)
instance normD : Language.DefinableFunction₁ ℒₒᵣ c.norm := c.normDef
instance goodD : Language.DefinablePred ℒₒᵣ c.good := by unfold good;definability
instance pushD : Language.DefinableFunction₂ ℒₒᵣ c.push := c.pushDef
instance satD : Language.DefinableRel ℒₒᵣ c.sat := c.satDef
instance relD : Language.DefinableRel₃ ℒₒᵣ c.rel := by unfold rel;definability
@[simp] theorem goodEnc (v : N) : c.good (c.enc v) := by simp [good,norm,c.inv]
@[simp] theorem decPush (v w : V) : c.dec (c.push v w)=n.pair (c.dec v) (c.dec w) := c.inv _
theorem rel_iff (r v w : V) : c.rel r v w ↔ a.sat r (n.pair (c.dec v) (c.dec w)) := by simp [rel,sat]
theorem inj {x y : N} (e:c.enc x=c.enc y) : x=y := by simpa only [c.inv] using congrArg c.dec e

include c in
/-- Totality and uniqueness on the interpreted domain form one old-arithmetic
predicate on a representative code, even in a nonstandard ambient PA model. -/
theorem totalD : Language.DefinablePred ℒₒᵣ a.Total := by
  apply Language.Definable.of_iff (Q:=fun e:Fin 1→V=>∀x:V,∃u:V,c.rel (e 0) x u ∧
    ∀v:V,c.rel (e 0) x v → c.norm v=c.norm u) (by definability)
  intro e;constructor
  · intro ht x;obtain ⟨u,hu,huniq⟩ := ht (c.dec x)
    refine ⟨c.enc u,?_,?_⟩
    · simpa only [c.rel_iff,c.inv] using hu
    · intro v hv;unfold norm;rw [c.inv,huniq (c.dec v) ((c.rel_iff _ _ _).mp hv)]
  · intro ht x;obtain ⟨u,hu,huniq⟩ := ht (c.enc x)
    refine ⟨c.dec u,?_,?_⟩
    · simpa only [c.rel_iff,c.inv] using hu
    · intro y hy
      have h := huniq (c.enc y) (by simpa only [c.rel_iff,c.inv] using hy)
      exact c.inj (by simpa [norm,c.inv] using h)

/-- Choose a definable output for every possible graph, with numerical zero
when the graph has no output. Functional graphs have their unique output. -/
theorem read_exists : ∃f: V→V→V, Language.DefinableFunction₂ ℒₒᵣ f ∧
    ∀r v,c.good (f r v) ∧ ((∃w,c.rel r v w) → c.rel r v (f r v)) := by
  classical
  let R := fun e : Fin 3→V=>c.good (e 0) ∧ ((∃w,c.rel (e 1) (e 2) w) → c.rel (e 1) (e 2) (e 0))
  have dr : Language.Definable ℒₒᵣ R := by dsimp [R];definability
  have ex (e:Fin 2→V) : ∃u,R (u :> e) := by
    change ∃u,c.good u ∧ ((∃w,c.rel (e 0) (e 1) w) → c.rel (e 0) (e 1) u)
    by_cases h : ∃w,c.rel (e 0) (e 1) w
    · obtain ⟨w,hw⟩ := h
      exact ⟨c.enc (c.dec w),c.goodEnc _,fun _=>by simpa only [c.rel_iff,c.inv] using hw⟩
    · exact ⟨c.enc n.z,c.goodEnc _,fun e=>False.elim (h e)⟩
  obtain ⟨f,df,hf⟩ := minChoice dr ex
  refine ⟨fun r v=>f ![r,v],?_,fun r v=>hf ![r,v]⟩
  change Language.DefinableFunction ℒₒᵣ (fun e :Fin 2→V=>f ![e 0,e 1])
  simpa only [←Matrix.fun_eq_vec_two] using df

noncomputable def read := (c.read_exists).choose
instance readD : Language.DefinableFunction₂ ℒₒᵣ c.read := (c.read_exists).choose_spec.1
theorem readGood (r v : V) : c.good (c.read r v) := ((c.read_exists).choose_spec.2 r v).1
theorem read_graph {r f} (h : a.Graph r f) (v : V) : c.read r v=c.enc (f (c.dec v)) := by
  have hr := ((c.read_exists).choose_spec.2 r v).2 (show ∃w,c.rel r v w from
    ⟨c.enc (f (c.dec v)),by simpa only [c.rel_iff,c.inv] using (h (c.dec v) _).mpr rfl⟩)
  have hv := (h (c.dec v) _).mp ((c.rel_iff _ _ _).mp hr)
  calc c.read r v=c.enc (c.dec (c.read r v)) := c.readGood _ _
       _=c.enc (f (c.dec v)) := congrArg c.enc hv.symm
end Coding
#print axioms Coding.read_graph
end NF192.Internal
