import NF185PATapeBatchCheck
namespace NF185PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w512_0 : checkWitness 512 false false 60 = true := by decide +kernel
private theorem w512_2 : checkWitness 512 true false 60 = true := by decide +kernel
private theorem cases512 : checkFour 512 (60,0,60,0) = true := by
  simp only [checkFour, w512_0, w512_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one512 : Coverage 512 513 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases512)
private theorem w513_0 : checkWitness 513 false false 593 = true := by decide +kernel
private theorem w513_1 : checkWitness 513 false true 4685 = true := by decide +kernel
private theorem w513_2 : checkWitness 513 true false 593 = true := by decide +kernel
private theorem w513_3 : checkWitness 513 true true 4685 = true := by decide +kernel
private theorem cases513 : checkFour 513 (593,4685,593,4685) = true := by
  simp only [checkFour, w513_0, w513_1, w513_2, w513_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one513 : Coverage 513 514 := checkList_sound (ws:=[(593,4685,593,4685)]) (by simpa only [checkList, Bool.and_true] using cases513)
private theorem w514_0 : checkWitness 514 false false 8870 = true := by decide +kernel
private theorem w514_2 : checkWitness 514 true false 8866 = true := by decide +kernel
private theorem cases514 : checkFour 514 (8870,0,8866,0) = true := by
  simp only [checkFour, w514_0, w514_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one514 : Coverage 514 515 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases514)
private theorem w515_0 : checkWitness 515 false false 60 = true := by decide +kernel
private theorem w515_2 : checkWitness 515 true false 60 = true := by decide +kernel
private theorem cases515 : checkFour 515 (60,0,60,0) = true := by
  simp only [checkFour, w515_0, w515_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one515 : Coverage 515 516 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases515)
private theorem w516_0 : checkWitness 516 false false 558 = true := by decide +kernel
private theorem w516_1 : checkWitness 516 false true 4654 = true := by decide +kernel
private theorem w516_2 : checkWitness 516 true false 558 = true := by decide +kernel
private theorem w516_3 : checkWitness 516 true true 4654 = true := by decide +kernel
private theorem cases516 : checkFour 516 (558,4654,558,4654) = true := by
  simp only [checkFour, w516_0, w516_1, w516_2, w516_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one516 : Coverage 516 517 := checkList_sound (ws:=[(558,4654,558,4654)]) (by simpa only [checkList, Bool.and_true] using cases516)
private theorem w517_0 : checkWitness 517 false false 8901 = true := by decide +kernel
private theorem w517_2 : checkWitness 517 true false 8897 = true := by decide +kernel
private theorem cases517 : checkFour 517 (8901,0,8897,0) = true := by
  simp only [checkFour, w517_0, w517_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one517 : Coverage 517 518 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases517)
private theorem w518_0 : checkWitness 518 false false 8942 = true := by decide +kernel
private theorem w518_2 : checkWitness 518 true false 8933 = true := by decide +kernel
private theorem cases518 : checkFour 518 (8942,0,8933,0) = true := by
  simp only [checkFour, w518_0, w518_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one518 : Coverage 518 519 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases518)
private theorem w519_0 : checkWitness 519 false false 66 = true := by decide +kernel
private theorem w519_2 : checkWitness 519 true false 66 = true := by decide +kernel
private theorem cases519 : checkFour 519 (66,0,66,0) = true := by
  simp only [checkFour, w519_0, w519_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one519 : Coverage 519 520 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases519)
private theorem w520_0 : checkWitness 520 false false 646 = true := by decide +kernel
private theorem w520_1 : checkWitness 520 false true 4738 = true := by decide +kernel
private theorem w520_2 : checkWitness 520 true false 637 = true := by decide +kernel
private theorem w520_3 : checkWitness 520 true true 4729 = true := by decide +kernel
private theorem cases520 : checkFour 520 (646,4738,637,4729) = true := by
  simp only [checkFour, w520_0, w520_1, w520_2, w520_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one520 : Coverage 520 521 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases520)
private theorem w521_0 : checkWitness 521 false false 8897 = true := by decide +kernel
private theorem w521_2 : checkWitness 521 true false 8893 = true := by decide +kernel
private theorem cases521 : checkFour 521 (8897,0,8893,0) = true := by
  simp only [checkFour, w521_0, w521_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one521 : Coverage 521 522 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases521)
private theorem w522_0 : checkWitness 522 false false 634 = true := by decide +kernel
private theorem w522_1 : checkWitness 522 false true 4726 = true := by decide +kernel
private theorem w522_2 : checkWitness 522 true false 625 = true := by decide +kernel
private theorem w522_3 : checkWitness 522 true true 4717 = true := by decide +kernel
private theorem cases522 : checkFour 522 (634,4726,625,4717) = true := by
  simp only [checkFour, w522_0, w522_1, w522_2, w522_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one522 : Coverage 522 523 := checkList_sound (ws:=[(634,4726,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases522)
private theorem w523_0 : checkWitness 523 false false 8864 = true := by decide +kernel
private theorem w523_2 : checkWitness 523 true false 8860 = true := by decide +kernel
private theorem cases523 : checkFour 523 (8864,0,8860,0) = true := by
  simp only [checkFour, w523_0, w523_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one523 : Coverage 523 524 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases523)
private theorem w524_0 : checkWitness 524 false false 66 = true := by decide +kernel
private theorem w524_2 : checkWitness 524 true false 66 = true := by decide +kernel
private theorem cases524 : checkFour 524 (66,0,66,0) = true := by
  simp only [checkFour, w524_0, w524_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one524 : Coverage 524 525 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases524)
private theorem w525_0 : checkWitness 525 false false 60 = true := by decide +kernel
private theorem w525_2 : checkWitness 525 true false 60 = true := by decide +kernel
private theorem cases525 : checkFour 525 (60,0,60,0) = true := by
  simp only [checkFour, w525_0, w525_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one525 : Coverage 525 526 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases525)
private theorem w526_0 : checkWitness 526 false false 597 = true := by decide +kernel
private theorem w526_1 : checkWitness 526 false true 4685 = true := by decide +kernel
private theorem w526_2 : checkWitness 526 true false 597 = true := by decide +kernel
private theorem w526_3 : checkWitness 526 true true 4685 = true := by decide +kernel
private theorem cases526 : checkFour 526 (597,4685,597,4685) = true := by
  simp only [checkFour, w526_0, w526_1, w526_2, w526_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one526 : Coverage 526 527 := checkList_sound (ws:=[(597,4685,597,4685)]) (by simpa only [checkList, Bool.and_true] using cases526)
private theorem w527_0 : checkWitness 527 false false 8880 = true := by decide +kernel
private theorem w527_2 : checkWitness 527 true false 8876 = true := by decide +kernel
private theorem cases527 : checkFour 527 (8880,0,8876,0) = true := by
  simp only [checkFour, w527_0, w527_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one527 : Coverage 527 528 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases527)
private theorem w528_0 : checkWitness 528 false false 8876 = true := by decide +kernel
private theorem w528_2 : checkWitness 528 true false 8872 = true := by decide +kernel
private theorem cases528 : checkFour 528 (8876,0,8872,0) = true := by
  simp only [checkFour, w528_0, w528_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one528 : Coverage 528 529 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases528)
private theorem w529_0 : checkWitness 529 false false 62 = true := by decide +kernel
private theorem w529_2 : checkWitness 529 true false 62 = true := by decide +kernel
private theorem cases529 : checkFour 529 (62,0,62,0) = true := by
  simp only [checkFour, w529_0, w529_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one529 : Coverage 529 530 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases529)
private theorem w530_0 : checkWitness 530 false false 8892 = true := by decide +kernel
private theorem w530_2 : checkWitness 530 true false 8888 = true := by decide +kernel
private theorem cases530 : checkFour 530 (8892,0,8888,0) = true := by
  simp only [checkFour, w530_0, w530_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one530 : Coverage 530 531 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases530)
private theorem w531_0 : checkWitness 531 false false 502 = true := by decide +kernel
private theorem w531_1 : checkWitness 531 false true 4598 = true := by decide +kernel
private theorem w531_2 : checkWitness 531 true false 502 = true := by decide +kernel
private theorem w531_3 : checkWitness 531 true true 4598 = true := by decide +kernel
private theorem cases531 : checkFour 531 (502,4598,502,4598) = true := by
  simp only [checkFour, w531_0, w531_1, w531_2, w531_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one531 : Coverage 531 532 := checkList_sound (ws:=[(502,4598,502,4598)]) (by simpa only [checkList, Bool.and_true] using cases531)
private theorem w532_0 : checkWitness 532 false false 8932 = true := by decide +kernel
private theorem w532_2 : checkWitness 532 true false 8923 = true := by decide +kernel
private theorem cases532 : checkFour 532 (8932,0,8923,0) = true := by
  simp only [checkFour, w532_0, w532_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one532 : Coverage 532 533 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases532)
private theorem w533_0 : checkWitness 533 false false 56 = true := by decide +kernel
private theorem w533_2 : checkWitness 533 true false 56 = true := by decide +kernel
private theorem cases533 : checkFour 533 (56,0,56,0) = true := by
  simp only [checkFour, w533_0, w533_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one533 : Coverage 533 534 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases533)
private theorem w534_0 : checkWitness 534 false false 512 = true := by decide +kernel
private theorem w534_1 : checkWitness 534 false true 4608 = true := by decide +kernel
private theorem w534_2 : checkWitness 534 true false 512 = true := by decide +kernel
private theorem w534_3 : checkWitness 534 true true 4608 = true := by decide +kernel
private theorem cases534 : checkFour 534 (512,4608,512,4608) = true := by
  simp only [checkFour, w534_0, w534_1, w534_2, w534_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one534 : Coverage 534 535 := checkList_sound (ws:=[(512,4608,512,4608)]) (by simpa only [checkList, Bool.and_true] using cases534)
private theorem w535_0 : checkWitness 535 false false 8876 = true := by decide +kernel
private theorem w535_2 : checkWitness 535 true false 8872 = true := by decide +kernel
private theorem cases535 : checkFour 535 (8876,0,8872,0) = true := by
  simp only [checkFour, w535_0, w535_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one535 : Coverage 535 536 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases535)
private theorem w536_0 : checkWitness 536 false false 60 = true := by decide +kernel
private theorem w536_2 : checkWitness 536 true false 60 = true := by decide +kernel
private theorem cases536 : checkFour 536 (60,0,60,0) = true := by
  simp only [checkFour, w536_0, w536_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one536 : Coverage 536 537 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases536)
private theorem w537_0 : checkWitness 537 false false 556 = true := by decide +kernel
private theorem w537_1 : checkWitness 537 false true 4652 = true := by decide +kernel
private theorem w537_2 : checkWitness 537 true false 556 = true := by decide +kernel
private theorem w537_3 : checkWitness 537 true true 4652 = true := by decide +kernel
private theorem cases537 : checkFour 537 (556,4652,556,4652) = true := by
  simp only [checkFour, w537_0, w537_1, w537_2, w537_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one537 : Coverage 537 538 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases537)
private theorem w538_0 : checkWitness 538 false false 8899 = true := by decide +kernel
private theorem w538_2 : checkWitness 538 true false 8895 = true := by decide +kernel
private theorem cases538 : checkFour 538 (8899,0,8895,0) = true := by
  simp only [checkFour, w538_0, w538_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one538 : Coverage 538 539 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases538)
private theorem w539_0 : checkWitness 539 false false 8940 = true := by decide +kernel
private theorem w539_2 : checkWitness 539 true false 8931 = true := by decide +kernel
private theorem cases539 : checkFour 539 (8940,0,8931,0) = true := by
  simp only [checkFour, w539_0, w539_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one539 : Coverage 539 540 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases539)
private theorem w540_0 : checkWitness 540 false false 72 = true := by decide +kernel
private theorem w540_2 : checkWitness 540 true false 72 = true := by decide +kernel
private theorem cases540 : checkFour 540 (72,0,72,0) = true := by
  simp only [checkFour, w540_0, w540_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one540 : Coverage 540 541 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases540)
private theorem w541_0 : checkWitness 541 false false 644 = true := by decide +kernel
private theorem w541_1 : checkWitness 541 false true 4736 = true := by decide +kernel
private theorem w541_2 : checkWitness 541 true false 635 = true := by decide +kernel
private theorem w541_3 : checkWitness 541 true true 4727 = true := by decide +kernel
private theorem cases541 : checkFour 541 (644,4736,635,4727) = true := by
  simp only [checkFour, w541_0, w541_1, w541_2, w541_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one541 : Coverage 541 542 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases541)
private theorem w542_0 : checkWitness 542 false false 8895 = true := by decide +kernel
private theorem w542_2 : checkWitness 542 true false 8891 = true := by decide +kernel
private theorem cases542 : checkFour 542 (8895,0,8891,0) = true := by
  simp only [checkFour, w542_0, w542_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one542 : Coverage 542 543 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases542)
private theorem w543_0 : checkWitness 543 false false 632 = true := by decide +kernel
private theorem w543_1 : checkWitness 543 false true 4724 = true := by decide +kernel
private theorem w543_2 : checkWitness 543 true false 623 = true := by decide +kernel
private theorem w543_3 : checkWitness 543 true true 4715 = true := by decide +kernel
private theorem cases543 : checkFour 543 (632,4724,623,4715) = true := by
  simp only [checkFour, w543_0, w543_1, w543_2, w543_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one543 : Coverage 543 544 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases543)
theorem cover0512 : Coverage 512 544 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one512 one513) (Coverage.join one514 one515)) (Coverage.join (Coverage.join one516 one517) (Coverage.join one518 one519))) (Coverage.join (Coverage.join (Coverage.join one520 one521) (Coverage.join one522 one523)) (Coverage.join (Coverage.join one524 one525) (Coverage.join one526 one527)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one528 one529) (Coverage.join one530 one531)) (Coverage.join (Coverage.join one532 one533) (Coverage.join one534 one535))) (Coverage.join (Coverage.join (Coverage.join one536 one537) (Coverage.join one538 one539)) (Coverage.join (Coverage.join one540 one541) (Coverage.join one542 one543)))))
end NF185PA.Symbolic
