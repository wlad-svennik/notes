import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1856_0 : checkWitness 1856 false false 76 = true := by decide +kernel
private theorem w1856_2 : checkWitness 1856 true false 76 = true := by decide +kernel
private theorem cases1856 : checkFour 1856 (76,0,76,0) = true := by
  simp only [checkFour, w1856_0, w1856_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1856 : Coverage 1856 1857 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1856)
private theorem w1857_0 : checkWitness 1857 false false 591 = true := by decide +kernel
private theorem w1857_1 : checkWitness 1857 false true 4683 = true := by decide +kernel
private theorem w1857_2 : checkWitness 1857 true false 591 = true := by decide +kernel
private theorem w1857_3 : checkWitness 1857 true true 4683 = true := by decide +kernel
private theorem cases1857 : checkFour 1857 (591,4683,591,4683) = true := by
  simp only [checkFour, w1857_0, w1857_1, w1857_2, w1857_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1857 : Coverage 1857 1858 := checkList_sound (ws:=[(591,4683,591,4683)]) (by simpa only [checkList, Bool.and_true] using cases1857)
private theorem w1858_0 : checkWitness 1858 false false 8852 = true := by decide +kernel
private theorem w1858_2 : checkWitness 1858 true false 8848 = true := by decide +kernel
private theorem cases1858 : checkFour 1858 (8852,0,8848,0) = true := by
  simp only [checkFour, w1858_0, w1858_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1858 : Coverage 1858 1859 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1858)
private theorem w1859_0 : checkWitness 1859 false false 76 = true := by decide +kernel
private theorem w1859_2 : checkWitness 1859 true false 76 = true := by decide +kernel
private theorem cases1859 : checkFour 1859 (76,0,76,0) = true := by
  simp only [checkFour, w1859_0, w1859_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1859 : Coverage 1859 1860 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1859)
private theorem w1860_0 : checkWitness 1860 false false 552 = true := by decide +kernel
private theorem w1860_1 : checkWitness 1860 false true 4648 = true := by decide +kernel
private theorem w1860_2 : checkWitness 1860 true false 552 = true := by decide +kernel
private theorem w1860_3 : checkWitness 1860 true true 4648 = true := by decide +kernel
private theorem cases1860 : checkFour 1860 (552,4648,552,4648) = true := by
  simp only [checkFour, w1860_0, w1860_1, w1860_2, w1860_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1860 : Coverage 1860 1861 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases1860)
private theorem w1861_0 : checkWitness 1861 false false 8887 = true := by decide +kernel
private theorem w1861_2 : checkWitness 1861 true false 8883 = true := by decide +kernel
private theorem cases1861 : checkFour 1861 (8887,0,8883,0) = true := by
  simp only [checkFour, w1861_0, w1861_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1861 : Coverage 1861 1862 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1861)
private theorem w1862_0 : checkWitness 1862 false false 8922 = true := by decide +kernel
private theorem w1862_2 : checkWitness 1862 true false 8913 = true := by decide +kernel
private theorem cases1862 : checkFour 1862 (8922,0,8913,0) = true := by
  simp only [checkFour, w1862_0, w1862_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1862 : Coverage 1862 1863 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases1862)
private theorem w1863_0 : checkWitness 1863 false false 94 = true := by decide +kernel
private theorem w1863_2 : checkWitness 1863 true false 94 = true := by decide +kernel
private theorem cases1863 : checkFour 1863 (94,0,94,0) = true := by
  simp only [checkFour, w1863_0, w1863_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1863 : Coverage 1863 1864 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1863)
private theorem w1864_0 : checkWitness 1864 false false 634 = true := by decide +kernel
private theorem w1864_1 : checkWitness 1864 false true 4726 = true := by decide +kernel
private theorem w1864_2 : checkWitness 1864 true false 625 = true := by decide +kernel
private theorem w1864_3 : checkWitness 1864 true true 4717 = true := by decide +kernel
private theorem cases1864 : checkFour 1864 (634,4726,625,4717) = true := by
  simp only [checkFour, w1864_0, w1864_1, w1864_2, w1864_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1864 : Coverage 1864 1865 := checkList_sound (ws:=[(634,4726,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases1864)
private theorem w1865_0 : checkWitness 1865 false false 8883 = true := by decide +kernel
private theorem w1865_2 : checkWitness 1865 true false 8879 = true := by decide +kernel
private theorem cases1865 : checkFour 1865 (8883,0,8879,0) = true := by
  simp only [checkFour, w1865_0, w1865_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1865 : Coverage 1865 1866 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1865)
private theorem w1866_0 : checkWitness 1866 false false 628 = true := by decide +kernel
private theorem w1866_1 : checkWitness 1866 false true 4720 = true := by decide +kernel
private theorem w1866_2 : checkWitness 1866 true false 619 = true := by decide +kernel
private theorem w1866_3 : checkWitness 1866 true true 4711 = true := by decide +kernel
private theorem cases1866 : checkFour 1866 (628,4720,619,4711) = true := by
  simp only [checkFour, w1866_0, w1866_1, w1866_2, w1866_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1866 : Coverage 1866 1867 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases1866)
private theorem w1867_0 : checkWitness 1867 false false 8852 = true := by decide +kernel
private theorem w1867_2 : checkWitness 1867 true false 8848 = true := by decide +kernel
private theorem cases1867 : checkFour 1867 (8852,0,8848,0) = true := by
  simp only [checkFour, w1867_0, w1867_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1867 : Coverage 1867 1868 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1867)
private theorem w1868_0 : checkWitness 1868 false false 82 = true := by decide +kernel
private theorem w1868_2 : checkWitness 1868 true false 82 = true := by decide +kernel
private theorem cases1868 : checkFour 1868 (82,0,82,0) = true := by
  simp only [checkFour, w1868_0, w1868_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1868 : Coverage 1868 1869 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1868)
private theorem w1869_0 : checkWitness 1869 false false 74 = true := by decide +kernel
private theorem w1869_2 : checkWitness 1869 true false 74 = true := by decide +kernel
private theorem cases1869 : checkFour 1869 (74,0,74,0) = true := by
  simp only [checkFour, w1869_0, w1869_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1869 : Coverage 1869 1870 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1869)
private theorem w1870_0 : checkWitness 1870 false false 615 = true := by decide +kernel
private theorem w1870_1 : checkWitness 1870 false true 4683 = true := by decide +kernel
private theorem w1870_2 : checkWitness 1870 true false 615 = true := by decide +kernel
private theorem w1870_3 : checkWitness 1870 true true 4683 = true := by decide +kernel
private theorem cases1870 : checkFour 1870 (615,4683,615,4683) = true := by
  simp only [checkFour, w1870_0, w1870_1, w1870_2, w1870_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1870 : Coverage 1870 1871 := checkList_sound (ws:=[(615,4683,615,4683)]) (by simpa only [checkList, Bool.and_true] using cases1870)
private theorem w1871_0 : checkWitness 1871 false false 8868 = true := by decide +kernel
private theorem w1871_2 : checkWitness 1871 true false 8864 = true := by decide +kernel
private theorem cases1871 : checkFour 1871 (8868,0,8864,0) = true := by
  simp only [checkFour, w1871_0, w1871_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1871 : Coverage 1871 1872 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases1871)
private theorem w1872_0 : checkWitness 1872 false false 8864 = true := by decide +kernel
private theorem w1872_2 : checkWitness 1872 true false 8860 = true := by decide +kernel
private theorem cases1872 : checkFour 1872 (8864,0,8860,0) = true := by
  simp only [checkFour, w1872_0, w1872_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1872 : Coverage 1872 1873 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases1872)
private theorem w1873_0 : checkWitness 1873 false false 88 = true := by decide +kernel
private theorem w1873_2 : checkWitness 1873 true false 88 = true := by decide +kernel
private theorem cases1873 : checkFour 1873 (88,0,88,0) = true := by
  simp only [checkFour, w1873_0, w1873_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1873 : Coverage 1873 1874 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1873)
private theorem w1874_0 : checkWitness 1874 false false 538 = true := by decide +kernel
private theorem w1874_1 : checkWitness 1874 false true 4634 = true := by decide +kernel
private theorem w1874_2 : checkWitness 1874 true false 538 = true := by decide +kernel
private theorem w1874_3 : checkWitness 1874 true true 4634 = true := by decide +kernel
private theorem cases1874 : checkFour 1874 (538,4634,538,4634) = true := by
  simp only [checkFour, w1874_0, w1874_1, w1874_2, w1874_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1874 : Coverage 1874 1875 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases1874)
private theorem w1875_0 : checkWitness 1875 false false 8966 = true := by decide +kernel
private theorem w1875_2 : checkWitness 1875 true false 8957 = true := by decide +kernel
private theorem cases1875 : checkFour 1875 (8966,0,8957,0) = true := by
  simp only [checkFour, w1875_0, w1875_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1875 : Coverage 1875 1876 := checkList_sound (ws:=[(8966,0,8957,0)]) (by simpa only [checkList, Bool.and_true] using cases1875)
private theorem w1876_0 : checkWitness 1876 false false 78 = true := by decide +kernel
private theorem w1876_2 : checkWitness 1876 true false 78 = true := by decide +kernel
private theorem cases1876 : checkFour 1876 (78,0,78,0) = true := by
  simp only [checkFour, w1876_0, w1876_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1876 : Coverage 1876 1877 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1876)
private theorem w1877_0 : checkWitness 1877 false false 548 = true := by decide +kernel
private theorem w1877_1 : checkWitness 1877 false true 4644 = true := by decide +kernel
private theorem w1877_2 : checkWitness 1877 true false 548 = true := by decide +kernel
private theorem w1877_3 : checkWitness 1877 true true 4644 = true := by decide +kernel
private theorem cases1877 : checkFour 1877 (548,4644,548,4644) = true := by
  simp only [checkFour, w1877_0, w1877_1, w1877_2, w1877_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1877 : Coverage 1877 1878 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases1877)
private theorem w1878_0 : checkWitness 1878 false false 8906 = true := by decide +kernel
private theorem w1878_2 : checkWitness 1878 true false 8902 = true := by decide +kernel
private theorem cases1878 : checkFour 1878 (8906,0,8902,0) = true := by
  simp only [checkFour, w1878_0, w1878_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1878 : Coverage 1878 1879 := checkList_sound (ws:=[(8906,0,8902,0)]) (by simpa only [checkList, Bool.and_true] using cases1878)
private theorem w1879_0 : checkWitness 1879 false false 80 = true := by decide +kernel
private theorem w1879_2 : checkWitness 1879 true false 80 = true := by decide +kernel
private theorem cases1879 : checkFour 1879 (80,0,80,0) = true := by
  simp only [checkFour, w1879_0, w1879_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1879 : Coverage 1879 1880 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1879)
private theorem w1880_0 : checkWitness 1880 false false 592 = true := by decide +kernel
private theorem w1880_1 : checkWitness 1880 false true 4688 = true := by decide +kernel
private theorem w1880_2 : checkWitness 1880 true false 592 = true := by decide +kernel
private theorem w1880_3 : checkWitness 1880 true true 4688 = true := by decide +kernel
private theorem cases1880 : checkFour 1880 (592,4688,592,4688) = true := by
  simp only [checkFour, w1880_0, w1880_1, w1880_2, w1880_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1880 : Coverage 1880 1881 := checkList_sound (ws:=[(592,4688,592,4688)]) (by simpa only [checkList, Bool.and_true] using cases1880)
private theorem w1881_0 : checkWitness 1881 false false 8927 = true := by decide +kernel
private theorem w1881_2 : checkWitness 1881 true false 8923 = true := by decide +kernel
private theorem cases1881 : checkFour 1881 (8927,0,8923,0) = true := by
  simp only [checkFour, w1881_0, w1881_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1881 : Coverage 1881 1882 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases1881)
private theorem w1882_0 : checkWitness 1882 false false 8962 = true := by decide +kernel
private theorem w1882_2 : checkWitness 1882 true false 8953 = true := by decide +kernel
private theorem cases1882 : checkFour 1882 (8962,0,8953,0) = true := by
  simp only [checkFour, w1882_0, w1882_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1882 : Coverage 1882 1883 := checkList_sound (ws:=[(8962,0,8953,0)]) (by simpa only [checkList, Bool.and_true] using cases1882)
private theorem w1883_0 : checkWitness 1883 false false 104 = true := by decide +kernel
private theorem w1883_2 : checkWitness 1883 true false 104 = true := by decide +kernel
private theorem cases1883 : checkFour 1883 (104,0,104,0) = true := by
  simp only [checkFour, w1883_0, w1883_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1883 : Coverage 1883 1884 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases1883)
private theorem w1884_0 : checkWitness 1884 false false 674 = true := by decide +kernel
private theorem w1884_1 : checkWitness 1884 false true 4766 = true := by decide +kernel
private theorem w1884_2 : checkWitness 1884 true false 665 = true := by decide +kernel
private theorem w1884_3 : checkWitness 1884 true true 4757 = true := by decide +kernel
private theorem cases1884 : checkFour 1884 (674,4766,665,4757) = true := by
  simp only [checkFour, w1884_0, w1884_1, w1884_2, w1884_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1884 : Coverage 1884 1885 := checkList_sound (ws:=[(674,4766,665,4757)]) (by simpa only [checkList, Bool.and_true] using cases1884)
private theorem w1885_0 : checkWitness 1885 false false 8923 = true := by decide +kernel
private theorem w1885_2 : checkWitness 1885 true false 8919 = true := by decide +kernel
private theorem cases1885 : checkFour 1885 (8923,0,8919,0) = true := by
  simp only [checkFour, w1885_0, w1885_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1885 : Coverage 1885 1886 := checkList_sound (ws:=[(8923,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases1885)
private theorem w1886_0 : checkWitness 1886 false false 668 = true := by decide +kernel
private theorem w1886_1 : checkWitness 1886 false true 4760 = true := by decide +kernel
private theorem w1886_2 : checkWitness 1886 true false 659 = true := by decide +kernel
private theorem w1886_3 : checkWitness 1886 true true 4751 = true := by decide +kernel
private theorem cases1886 : checkFour 1886 (668,4760,659,4751) = true := by
  simp only [checkFour, w1886_0, w1886_1, w1886_2, w1886_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1886 : Coverage 1886 1887 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases1886)
private theorem w1887_0 : checkWitness 1887 false false 8892 = true := by decide +kernel
private theorem w1887_2 : checkWitness 1887 true false 8888 = true := by decide +kernel
private theorem cases1887 : checkFour 1887 (8892,0,8888,0) = true := by
  simp only [checkFour, w1887_0, w1887_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1887 : Coverage 1887 1888 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases1887)
theorem cover1856 : Coverage 1856 1888 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1856 one1857) (Coverage.join one1858 one1859)) (Coverage.join (Coverage.join one1860 one1861) (Coverage.join one1862 one1863))) (Coverage.join (Coverage.join (Coverage.join one1864 one1865) (Coverage.join one1866 one1867)) (Coverage.join (Coverage.join one1868 one1869) (Coverage.join one1870 one1871)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1872 one1873) (Coverage.join one1874 one1875)) (Coverage.join (Coverage.join one1876 one1877) (Coverage.join one1878 one1879))) (Coverage.join (Coverage.join (Coverage.join one1880 one1881) (Coverage.join one1882 one1883)) (Coverage.join (Coverage.join one1884 one1885) (Coverage.join one1886 one1887)))))
end NF182PA.Symbolic
