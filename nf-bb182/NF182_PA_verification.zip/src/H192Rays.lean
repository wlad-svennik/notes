module
public import H192Rows

@[expose] public section
open NF210.TM

namespace PA192.LiteralTM

def push (b : Bool) (s : Nat) := 2*s+b.toNat

theorem bit_split (x : Nat) : x=push (x.testBit 0) (x/2) := by
  by_cases h : x%2=1 <;> simp [push,Nat.testBit_zero,h] <;> omega

@[simp] theorem push_head (b : Bool) (s : Nat) : (push b s).testBit 0=b := by
  cases b <;> simp [push,Nat.testBit_eq_decide_div_mod_eq,Nat.add_mod]

@[simp] theorem push_tail (b : Bool) (s : Nat) : push b s/2=s := by cases b <;> simp [push] <;> omega

@[simp] theorem push_bit (b : Bool) (s k : Nat) : (push b s).testBit (k+1)=s.testBit k := by
  rw [Nat.testBit_add_one,push_tail]

structure Rays (n : Nat) where
  status : Option (Fin n)
  left : Nat
  right : Nat
  deriving DecidableEq

def Rays.advance (machine : Machine n) (a : Rays n) : Rays n :=
  match a.status with
  | none => a
  | some q =>
    let i := machine q (a.right.testBit 0)
    match i.move with
    | .right => ⟨i.next,push i.write a.left,a.right/2⟩
    | .left => ⟨i.next,a.left/2,push (a.left.testBit 0) (push i.write (a.right/2))⟩

def Rays.blank (start : Fin n) : Rays n := ⟨some start,0,0⟩
def Rays.run (machine : Machine n) (start : Fin n) : Nat → Rays n
  | 0 => blank start
  | k+1 => (run machine start k).advance machine

/-- At offset zero the positive ray has the presently scanned bit. -/
def Rays.Rep (a : Rays n) (c : Configuration n) : Prop :=
  c.state=a.status ∧ (∀i:Nat, c.tape (c.head+i)=a.right.testBit i) ∧
  ∀i:Nat, c.tape (c.head-(i+1))=a.left.testBit i

theorem Rays.rep_blank (start : Fin n) : (blank start).Rep (NF210.TM.blank start) := by
  simp [Rep,blank,NF210.TM.blank]

theorem Rays.rep_step {machine : Machine n} {a : Rays n} {c : Configuration n}
    (h : a.Rep c) : (a.advance machine).Rep (step machine c) := by
  rcases a with ⟨q,l,r⟩
  rcases h with ⟨state,pos,neg⟩
  cases q with
  | none =>
    simpa [Rep,advance,step,state] using
      (show c.state=none ∧ (∀i:Nat,c.tape (c.head+i)=r.testBit i) ∧
       ∀i:Nat,c.tape (c.head-(i+1))=l.testBit i from ⟨state,pos,neg⟩)
  | some q =>
    have read : c.tape c.head=r.testBit 0 := by simpa using pos 0
    let i := machine q (r.testBit 0)
    have hi : machine q (r.testBit 0)=i := rfl
    cases mv : i.move with
    | right =>
      simp only [advance,step,state,read,hi,mv,moveHead]
      change (Rays.mk i.next (push i.write l) (r/2)).Rep
        ⟨i.next,c.head+1,writeTape c.tape c.head i.write⟩
      · refine ⟨rfl,?_,?_⟩
        · intro k
          have ne : c.head+1+(k:Int) ≠ c.head := by omega
          have ep : c.head+1+(k:Int)=c.head+((k+1:Nat):Int) := by omega
          have ne' : c.head+((k+1:Nat):Int) ≠ c.head := by omega
          simpa only [writeTape,ne,ite_false,ep,ne',Nat.testBit_div_two] using pos (k+1)
        · intro k
          cases k with
          | zero => change writeTape c.tape c.head i.write (c.head+1-(0+1))=(push i.write l).testBit 0
                    rw [push_head]; simp [writeTape]
          | succ k =>
            have en : c.head+1-((k: Int)+1+1)=c.head-((k:Int)+1) := by omega
            have ne : c.head+1-((k: Int)+1+1)≠c.head := by omega
            have ne' : c.head-((k:Int)+1)≠c.head := by omega
            simpa only [Nat.cast_add,Nat.cast_one,en,writeTape,ne,ne',ite_false,push_bit] using neg k
    | left =>
      simp only [advance,step,state,read,hi,mv,moveHead]
      change (Rays.mk i.next (l/2) (push (l.testBit 0) (push i.write (r/2)))).Rep
        ⟨i.next,c.head-1,writeTape c.tape c.head i.write⟩
      · refine ⟨rfl,?_,?_⟩
        · intro k
          cases k with
          | zero =>
            change writeTape c.tape c.head i.write (c.head-1+0)=(push (l.testBit 0) (push i.write (r/2))).testBit 0
            rw [push_head]; simpa [writeTape] using neg 0
          | succ k =>
            cases k with
            | zero =>
              change writeTape c.tape c.head i.write (c.head-1+1)=(push (l.testBit 0) (push i.write (r/2))).testBit (0+1)
              rw [push_bit,push_head]; simp [writeTape]
            | succ k =>
              have ep : c.head-1+((k:Int)+1+1)=c.head+((k+1:Nat):Int) := by omega
              have ne : c.head-1+((k:Int)+1+1)≠c.head := by omega
              have ne' : c.head+((k:Int)+1)≠c.head := by omega
              simpa only [Nat.cast_add,Nat.cast_one,writeTape,ne,ne',ite_false,ep,push_bit,
                Nat.testBit_div_two] using pos (k+1)
        · intro k
          have ep : c.head-1-((k:Int)+1)=c.head-(((k+1:Nat):Int)+1) := by omega
          have ne : c.head-1-((k:Int)+1)≠c.head := by omega
          have ne' : c.head-(((k+1:Nat):Int)+1)≠c.head := by omega
          simpa only [writeTape,ne,ne',ite_false,ep,Nat.testBit_div_two] using neg (k+1)

theorem Rays.rep_run (machine : Machine n) (start : Fin n) (k : Nat) :
    (run machine start k).Rep (NF210.TM.run machine k (NF210.TM.blank start)) := by
  induction k with
  | zero => exact rep_blank _
  | succ k ih => exact rep_step ih

theorem control_inj {a b : Option (Fin n)} (h : control a=control b) : a=b := by
  cases a <;> cases b <;> simp [control] at h ⊢
  · omega
  · omega
  · exact Fin.ext h

end PA192.LiteralTM

#print axioms PA192.LiteralTM.Rays.rep_run
