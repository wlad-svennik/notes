import InternalPresentation
import ExtractOps
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Direct PA192.Numerals.FoundationRoute
namespace NF192.Internal.Presentation
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {m : X→X→Prop} (d : Presentation V X m)
def Min (v : V) : Prop := ∀w<v,d.dec w≠d.dec v
theorem minDef : Language.DefinablePred ℒₒᵣ d.Min := by
  letI := d.eqDef
  unfold Min;definability

theorem rep (u : X) : ∃v,d.dec v=u ∧ d.Min v := by
  obtain ⟨a,rfl⟩ := d.onto u
  letI := d.eqDef
  letI : Language.DefinablePred ℒₒᵣ (fun t => d.dec t=d.dec a) :=
    Language.DefinableRel.comp (P:=fun x y:V=>d.dec x=d.dec y)
      (f:=fun v:Fin 1→V=>v 0) (g:=fun _=>a) (by definability) (by definability)
  obtain ⟨v,hv,hmin⟩ := least_plain (fun t=>d.dec t=d.dec a) (x:=a) rfl
  exact ⟨v,hv,fun w hw e => hmin w hw (e.trans hv)⟩
noncomputable def enc (x : X) := (d.rep x).choose
@[simp] theorem decEnc (x : X) : d.dec (d.enc x)=x := (d.rep x).choose_spec.1
theorem minEnc (x : X) : d.Min (d.enc x) := (d.rep x).choose_spec.2
theorem enc_iff (t : V) (x : X) : t=d.enc x ↔ d.Min t ∧ d.dec t=x := by
  constructor
  · rintro rfl;exact ⟨d.minEnc _,d.decEnc _⟩
  · rintro ⟨h,e⟩
    rcases lt_trichotomy t (d.enc x) with l|q|r
    · exact False.elim (d.minEnc _ _ l (e.trans (d.decEnc _).symm))
    · exact q
    · exact False.elim (h _ r ((d.decEnc _).trans e.symm))
theorem numDef (D : X) : Language.DefinablePred ℒₒᵣ (fun v => m (d.dec v) D) := by
  obtain ⟨k,rfl⟩ := d.onto D
  letI := d.memDef
  exact Language.DefinableRel.comp (P:=fun x y:V=>m (d.dec x) (d.dec y))
    (f:=fun v:Fin 1→V=>v 0) (g:=fun _=>k) (by definability) (by definability)
def Good (D : X) (v : V) : Prop := d.Min v ∧ m (d.dec v) D
theorem goodDef (D : X) : Language.DefinablePred ℒₒᵣ (d.Good D) := (d.minDef).and (d.numDef D)
noncomputable def value {D : X} (z : Dom m D) (v : V) : Dom m D := open Classical in
  if h : m (d.dec v) D then ⟨d.dec v,h⟩ else z
@[simp] theorem valueEnc {D : X} (z v : Dom m D) : d.value z (d.enc v.val)=v := by
  apply Subtype.ext;simp [value,v.2]
theorem encGood {D : X} (n : Dom m D) : d.Good D (d.enc n.val) := ⟨d.minEnc _,by simpa using n.2⟩
theorem encValue {D : X} (z : Dom m D) {v : V} (h : d.Good D v) : d.enc (d.value z v).val=v := by
  apply ((d.enc_iff _ _).mpr ⟨h.1,?_⟩).symm
  simp [value,h.2]

/-- Total coding sends arbitrary raw inputs outside the numerical domain to zero. -/
noncomputable def clean {D : X} (z : Dom m D) (v : V) := d.enc (d.value z v).val
theorem cleanDef {D : X} (z : Dom m D) : Language.DefinableFunction₁ ℒₒᵣ (d.clean z) := by
  letI := d.minDef;letI := d.numDef D;letI := d.eqDef
  obtain ⟨zc,hz⟩ := d.onto z.val
  have hnum : Language.Definable ℒₒᵣ (fun v : Fin 2→V => m (d.dec (v 1)) D) := Language.Definable.retraction (d.numDef D) (fun _=>1)
  have heq : Language.Definable ℒₒᵣ (fun v : Fin 2→V => d.dec (v 0)=d.dec zc) := Language.DefinableRel.comp (P:=fun x y:V=>d.dec x=d.dec y) (f:=fun v:Fin 2→V=>v 0) (g:=fun _=>zc) (by definability) (by definability)
  apply Language.Definable.of_iff (Q:=fun v : Fin 2→V => d.Min (v 0) ∧
    ((m (d.dec (v 1)) D ∧ d.dec (v 0)=d.dec (v 1)) ∨ (¬m (d.dec (v 1)) D ∧ d.dec (v 0)=d.dec zc))) ((Language.Definable.retraction d.minDef (fun _=>0)).and ((hnum.and (by exact d.eqDef)).or (hnum.not.and heq)))
  intro e;change e 0=d.enc (d.value z (e 1)).val ↔ _
  rw [d.enc_iff,hz]
  by_cases h : m (d.dec (e 1)) D <;> simp [value,h]

#print axioms cleanDef
end NF192.Internal.Presentation
