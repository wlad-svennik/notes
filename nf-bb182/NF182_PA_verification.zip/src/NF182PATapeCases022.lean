import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w704_0 : checkWitness 704 false false 8870 = true := by decide +kernel
private theorem w704_2 : checkWitness 704 true false 8866 = true := by decide +kernel
private theorem cases704 : checkFour 704 (8870,0,8866,0) = true := by
  simp only [checkFour, w704_0, w704_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one704 : Coverage 704 705 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases704)
private theorem w705_0 : checkWitness 705 false false 72 = true := by decide +kernel
private theorem w705_2 : checkWitness 705 true false 72 = true := by decide +kernel
private theorem cases705 : checkFour 705 (72,0,72,0) = true := by
  simp only [checkFour, w705_0, w705_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one705 : Coverage 705 706 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases705)
private theorem w706_0 : checkWitness 706 false false 622 = true := by decide +kernel
private theorem w706_1 : checkWitness 706 false true 4718 = true := by decide +kernel
private theorem w706_2 : checkWitness 706 true false 622 = true := by decide +kernel
private theorem w706_3 : checkWitness 706 true true 4718 = true := by decide +kernel
private theorem cases706 : checkFour 706 (622,4718,622,4718) = true := by
  simp only [checkFour, w706_0, w706_1, w706_2, w706_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one706 : Coverage 706 707 := checkList_sound (ws:=[(622,4718,622,4718)]) (by simpa only [checkList, Bool.and_true] using cases706)
private theorem w707_0 : checkWitness 707 false false 8938 = true := by decide +kernel
private theorem w707_2 : checkWitness 707 true false 8929 = true := by decide +kernel
private theorem cases707 : checkFour 707 (8938,0,8929,0) = true := by
  simp only [checkFour, w707_0, w707_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one707 : Coverage 707 708 := checkList_sound (ws:=[(8938,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases707)
private theorem w708_0 : checkWitness 708 false false 8884 = true := by decide +kernel
private theorem w708_2 : checkWitness 708 true false 8880 = true := by decide +kernel
private theorem cases708 : checkFour 708 (8884,0,8880,0) = true := by
  simp only [checkFour, w708_0, w708_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one708 : Coverage 708 709 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases708)
private theorem w709_0 : checkWitness 709 false false 80 = true := by decide +kernel
private theorem w709_2 : checkWitness 709 true false 80 = true := by decide +kernel
private theorem cases709 : checkFour 709 (80,0,80,0) = true := by
  simp only [checkFour, w709_0, w709_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one709 : Coverage 709 710 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases709)
private theorem w710_0 : checkWitness 710 false false 668 = true := by decide +kernel
private theorem w710_1 : checkWitness 710 false true 4756 = true := by decide +kernel
private theorem w710_2 : checkWitness 710 true false 659 = true := by decide +kernel
private theorem w710_3 : checkWitness 710 true true 4747 = true := by decide +kernel
private theorem cases710 : checkFour 710 (668,4756,659,4747) = true := by
  simp only [checkFour, w710_0, w710_1, w710_2, w710_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one710 : Coverage 710 711 := checkList_sound (ws:=[(668,4756,659,4747)]) (by simpa only [checkList, Bool.and_true] using cases710)
private theorem w711_0 : checkWitness 711 false false 8926 = true := by decide +kernel
private theorem w711_2 : checkWitness 711 true false 8922 = true := by decide +kernel
private theorem cases711 : checkFour 711 (8926,0,8922,0) = true := by
  simp only [checkFour, w711_0, w711_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one711 : Coverage 711 712 := checkList_sound (ws:=[(8926,0,8922,0)]) (by simpa only [checkList, Bool.and_true] using cases711)
private theorem w712_0 : checkWitness 712 false false 70 = true := by decide +kernel
private theorem w712_2 : checkWitness 712 true false 70 = true := by decide +kernel
private theorem cases712 : checkFour 712 (70,0,70,0) = true := by
  simp only [checkFour, w712_0, w712_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one712 : Coverage 712 713 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases712)
private theorem w713_0 : checkWitness 713 false false 514 = true := by decide +kernel
private theorem w713_1 : checkWitness 713 false true 4610 = true := by decide +kernel
private theorem w713_2 : checkWitness 713 true false 514 = true := by decide +kernel
private theorem w713_3 : checkWitness 713 true true 4610 = true := by decide +kernel
private theorem cases713 : checkFour 713 (514,4610,514,4610) = true := by
  simp only [checkFour, w713_0, w713_1, w713_2, w713_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one713 : Coverage 713 714 := checkList_sound (ws:=[(514,4610,514,4610)]) (by simpa only [checkList, Bool.and_true] using cases713)
private theorem w714_0 : checkWitness 714 false false 8909 = true := by decide +kernel
private theorem w714_2 : checkWitness 714 true false 8905 = true := by decide +kernel
private theorem cases714 : checkFour 714 (8909,0,8905,0) = true := by
  simp only [checkFour, w714_0, w714_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one714 : Coverage 714 715 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases714)
private theorem w715_0 : checkWitness 715 false false 640 = true := by decide +kernel
private theorem w715_1 : checkWitness 715 false true 4736 = true := by decide +kernel
private theorem w715_2 : checkWitness 715 true false 631 = true := by decide +kernel
private theorem w715_3 : checkWitness 715 true true 4727 = true := by decide +kernel
private theorem cases715 : checkFour 715 (640,4736,631,4727) = true := by
  simp only [checkFour, w715_0, w715_1, w715_2, w715_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one715 : Coverage 715 716 := checkList_sound (ws:=[(640,4736,631,4727)]) (by simpa only [checkList, Bool.and_true] using cases715)
private theorem w716_0 : checkWitness 716 false false 186 = true := by decide +kernel
private theorem w716_2 : checkWitness 716 true false 186 = true := by decide +kernel
private theorem cases716 : checkFour 716 (186,0,186,0) = true := by
  simp only [checkFour, w716_0, w716_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one716 : Coverage 716 717 := checkList_sound (ws:=[(186,0,186,0)]) (by simpa only [checkList, Bool.and_true] using cases716)
private theorem w717_0 : checkWitness 717 false false 595 = true := by decide +kernel
private theorem w717_1 : checkWitness 717 false true 4683 = true := by decide +kernel
private theorem w717_2 : checkWitness 717 true false 595 = true := by decide +kernel
private theorem w717_3 : checkWitness 717 true true 4683 = true := by decide +kernel
private theorem cases717 : checkFour 717 (595,4683,595,4683) = true := by
  simp only [checkFour, w717_0, w717_1, w717_2, w717_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one717 : Coverage 717 718 := checkList_sound (ws:=[(595,4683,595,4683)]) (by simpa only [checkList, Bool.and_true] using cases717)
private theorem w718_0 : checkWitness 718 false false 8924 = true := by decide +kernel
private theorem w718_2 : checkWitness 718 true false 8915 = true := by decide +kernel
private theorem cases718 : checkFour 718 (8924,0,8915,0) = true := by
  simp only [checkFour, w718_0, w718_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one718 : Coverage 718 719 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases718)
private theorem w719_0 : checkWitness 719 false false 74 = true := by decide +kernel
private theorem w719_2 : checkWitness 719 true false 74 = true := by decide +kernel
private theorem cases719 : checkFour 719 (74,0,74,0) = true := by
  simp only [checkFour, w719_0, w719_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one719 : Coverage 719 720 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases719)
private theorem w720_0 : checkWitness 720 false false 66 = true := by decide +kernel
private theorem w720_2 : checkWitness 720 true false 66 = true := by decide +kernel
private theorem cases720 : checkFour 720 (66,0,66,0) = true := by
  simp only [checkFour, w720_0, w720_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one720 : Coverage 720 721 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases720)
private theorem w721_0 : checkWitness 721 false false 601 = true := by decide +kernel
private theorem w721_1 : checkWitness 721 false true 4693 = true := by decide +kernel
private theorem w721_2 : checkWitness 721 true false 601 = true := by decide +kernel
private theorem w721_3 : checkWitness 721 true true 4693 = true := by decide +kernel
private theorem cases721 : checkFour 721 (601,4693,601,4693) = true := by
  simp only [checkFour, w721_0, w721_1, w721_2, w721_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one721 : Coverage 721 722 := checkList_sound (ws:=[(601,4693,601,4693)]) (by simpa only [checkList, Bool.and_true] using cases721)
private theorem w722_0 : checkWitness 722 false false 8862 = true := by decide +kernel
private theorem w722_2 : checkWitness 722 true false 8858 = true := by decide +kernel
private theorem cases722 : checkFour 722 (8862,0,8858,0) = true := by
  simp only [checkFour, w722_0, w722_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one722 : Coverage 722 723 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases722)
private theorem w723_0 : checkWitness 723 false false 66 = true := by decide +kernel
private theorem w723_2 : checkWitness 723 true false 66 = true := by decide +kernel
private theorem cases723 : checkFour 723 (66,0,66,0) = true := by
  simp only [checkFour, w723_0, w723_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one723 : Coverage 723 724 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases723)
private theorem w724_0 : checkWitness 724 false false 562 = true := by decide +kernel
private theorem w724_1 : checkWitness 724 false true 4658 = true := by decide +kernel
private theorem w724_2 : checkWitness 724 true false 562 = true := by decide +kernel
private theorem w724_3 : checkWitness 724 true true 4658 = true := by decide +kernel
private theorem cases724 : checkFour 724 (562,4658,562,4658) = true := by
  simp only [checkFour, w724_0, w724_1, w724_2, w724_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one724 : Coverage 724 725 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases724)
private theorem w725_0 : checkWitness 725 false false 8897 = true := by decide +kernel
private theorem w725_2 : checkWitness 725 true false 8893 = true := by decide +kernel
private theorem cases725 : checkFour 725 (8897,0,8893,0) = true := by
  simp only [checkFour, w725_0, w725_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one725 : Coverage 725 726 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases725)
private theorem w726_0 : checkWitness 726 false false 8932 = true := by decide +kernel
private theorem w726_2 : checkWitness 726 true false 8923 = true := by decide +kernel
private theorem cases726 : checkFour 726 (8932,0,8923,0) = true := by
  simp only [checkFour, w726_0, w726_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one726 : Coverage 726 727 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases726)
private theorem w727_0 : checkWitness 727 false false 84 = true := by decide +kernel
private theorem w727_2 : checkWitness 727 true false 84 = true := by decide +kernel
private theorem cases727 : checkFour 727 (84,0,84,0) = true := by
  simp only [checkFour, w727_0, w727_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one727 : Coverage 727 728 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases727)
private theorem w728_0 : checkWitness 728 false false 644 = true := by decide +kernel
private theorem w728_1 : checkWitness 728 false true 4736 = true := by decide +kernel
private theorem w728_2 : checkWitness 728 true false 635 = true := by decide +kernel
private theorem w728_3 : checkWitness 728 true true 4727 = true := by decide +kernel
private theorem cases728 : checkFour 728 (644,4736,635,4727) = true := by
  simp only [checkFour, w728_0, w728_1, w728_2, w728_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one728 : Coverage 728 729 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases728)
private theorem w729_0 : checkWitness 729 false false 8893 = true := by decide +kernel
private theorem w729_2 : checkWitness 729 true false 8889 = true := by decide +kernel
private theorem cases729 : checkFour 729 (8893,0,8889,0) = true := by
  simp only [checkFour, w729_0, w729_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one729 : Coverage 729 730 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases729)
private theorem w730_0 : checkWitness 730 false false 638 = true := by decide +kernel
private theorem w730_1 : checkWitness 730 false true 4730 = true := by decide +kernel
private theorem w730_2 : checkWitness 730 true false 629 = true := by decide +kernel
private theorem w730_3 : checkWitness 730 true true 4721 = true := by decide +kernel
private theorem cases730 : checkFour 730 (638,4730,629,4721) = true := by
  simp only [checkFour, w730_0, w730_1, w730_2, w730_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one730 : Coverage 730 731 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases730)
private theorem w731_0 : checkWitness 731 false false 8862 = true := by decide +kernel
private theorem w731_2 : checkWitness 731 true false 8858 = true := by decide +kernel
private theorem cases731 : checkFour 731 (8862,0,8858,0) = true := by
  simp only [checkFour, w731_0, w731_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one731 : Coverage 731 732 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases731)
private theorem w732_0 : checkWitness 732 false false 72 = true := by decide +kernel
private theorem w732_2 : checkWitness 732 true false 72 = true := by decide +kernel
private theorem cases732 : checkFour 732 (72,0,72,0) = true := by
  simp only [checkFour, w732_0, w732_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one732 : Coverage 732 733 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases732)
private theorem w733_0 : checkWitness 733 false false 64 = true := by decide +kernel
private theorem w733_2 : checkWitness 733 true false 64 = true := by decide +kernel
private theorem cases733 : checkFour 733 (64,0,64,0) = true := by
  simp only [checkFour, w733_0, w733_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one733 : Coverage 733 734 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases733)
private theorem w734_0 : checkWitness 734 false false 605 = true := by decide +kernel
private theorem w734_1 : checkWitness 734 false true 4693 = true := by decide +kernel
private theorem w734_2 : checkWitness 734 true false 605 = true := by decide +kernel
private theorem w734_3 : checkWitness 734 true true 4693 = true := by decide +kernel
private theorem cases734 : checkFour 734 (605,4693,605,4693) = true := by
  simp only [checkFour, w734_0, w734_1, w734_2, w734_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one734 : Coverage 734 735 := checkList_sound (ws:=[(605,4693,605,4693)]) (by simpa only [checkList, Bool.and_true] using cases734)
private theorem w735_0 : checkWitness 735 false false 8878 = true := by decide +kernel
private theorem w735_2 : checkWitness 735 true false 8874 = true := by decide +kernel
private theorem cases735 : checkFour 735 (8878,0,8874,0) = true := by
  simp only [checkFour, w735_0, w735_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one735 : Coverage 735 736 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases735)
theorem cover0704 : Coverage 704 736 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one704 one705) (Coverage.join one706 one707)) (Coverage.join (Coverage.join one708 one709) (Coverage.join one710 one711))) (Coverage.join (Coverage.join (Coverage.join one712 one713) (Coverage.join one714 one715)) (Coverage.join (Coverage.join one716 one717) (Coverage.join one718 one719)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one720 one721) (Coverage.join one722 one723)) (Coverage.join (Coverage.join one724 one725) (Coverage.join one726 one727))) (Coverage.join (Coverage.join (Coverage.join one728 one729) (Coverage.join one730 one731)) (Coverage.join (Coverage.join one732 one733) (Coverage.join one734 one735)))))
end NF182PA.Symbolic
