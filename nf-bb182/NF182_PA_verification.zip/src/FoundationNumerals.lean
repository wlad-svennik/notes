module
public import SummandLifting
public import Foundation.FirstOrder.Arithmetic.Schemata
public import Foundation.FirstOrder.Arithmetic.Definability.Absoluteness

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace PA192.Numerals.FoundationRoute

noncomputable def rob (M : Type) [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗤] : Robinson M where
  zero := 0
  next := fun x => x + 1
  add := (· + ·)
  mul := (· * ·)
  next_ne_zero := Arithmetic.succ_ne_zero
  next_inj := Arithmetic.succ_inj
  zero_or_next := Arithmetic.zero_or_succ
  add_zero := fun _ => Arithmetic.add_zero
  add_next := Arithmetic.add_succ
  mul_zero := Arithmetic.mul_zero
  mul_next := Arithmetic.mul_succ

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- Parameter definability, phrased to match Foundation's actual PA scheme. -/
def ArithPred (P : V → Prop) : Prop :=
  ∃ e : ℕ → V, ∃ φ : ArithmeticSemiformula ℕ 1, ∀ x, P x ↔ φ.Eval ![x] e

theorem induction_of_arith {P : V → Prop} (h : ArithPred P) : (rob V).IndOn P := by
  let _ : V↓[ℒₒᵣ] ⊧* InductionScheme ℒₒᵣ Set.univ :=
    models_of_subtheory (inferInstance : V↓[ℒₒᵣ] ⊧* 𝗣𝗔)
  obtain ⟨e,φ,hφ⟩ := h
  exact InductionScheme.succ_induction (V := V) (P := P) (C := Set.univ)
    ⟨e,φ,Set.mem_univ φ,hφ⟩

variable {A : Type} [ORingStructure A] [A↓[ℒₒᵣ] ⊧* 𝗤]

structure DefinableInductions (i : V → A) : Prop where
  addition : ArithPred ((rob V).AddAt (rob A) i)
  multiplication : ArithPred ((rob V).MulAt (rob A) i)
  injectivity : ArithPred (Robinson.InjAt i)
  initiality : ArithPred ((rob V).InitialAt (rob A) i)
  summands : ArithPred ((rob V).SummandsAt (rob A) i)

theorem initial_map (i : V → A) (hi : (rob V).NumeralMap (rob A) i)
    (d : DefinableInductions i) :
    (rob V).InitialEmbedding (rob A) i :=
  Robinson.initialEmbedding hi ⟨induction_of_arith d.addition,
    induction_of_arith d.multiplication, induction_of_arith d.injectivity,
    induction_of_arith d.initiality⟩

theorem rob_strict (M : Type) [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗤] (a b : M) :
    (rob M).strict a b ↔ a < b :=
  Arithmetic.lt_def.symm

noncomputable def structureEmbedding (i : V → A) (hi : (rob V).NumeralMap (rob A) i)
    (d : DefinableInductions i) : V ↪ₛ[ℒₒᵣ] A := by
  have j := initial_map i hi d
  have summed := Robinson.summands hi (induction_of_arith d.summands)
  have one : i 1 = (1 : A) := by
    have h := j.next 0
    change i (0 + 1) = i 0 + 1 at h
    have hz : i 0 = 0 := j.zero
    simpa only [Arithmetic.zero_add_one, hz] using h
  have ltiff (a b : V) : a < b ↔ i a < i b :=
    (rob_strict V a b).symm.trans ((Robinson.strict_iff j summed a b).trans (rob_strict A _ _))
  exact {
    toFun := i
    toFun_inj := @j.injective
    func' := by
      intro k f v
      cases f with
      | zero => exact j.zero
      | one => exact one
      | add => exact j.add _ _
      | mul => exact j.mul _ _
    rel' := by
      intro k r v
      cases r with
      | eq => exact congrArg i
      | lt => exact (ltiff _ _).mp
    rel_inv' := by
      intro k r v
      cases r with
      | eq => exact j.injective
      | lt => exact (ltiff _ _).mpr }

@[simp] theorem structureEmbedding_apply (i : V → A) (hi : (rob V).NumeralMap (rob A) i)
    (d : DefinableInductions i) (n : V) : (structureEmbedding i hi d) n = i n := rfl

instance (i : V → A) (hi : (rob V).NumeralMap (rob A) i)
    (d : DefinableInductions i) : ℬ[<, ℒₒᵣ].IsInitial (structureEmbedding i hi d) where
  operator_iff := by
    intro R mem a b
    obtain rfl := Set.mem_singleton_iff.mp mem
    have j := initial_map i hi d
    have summed := Robinson.summands hi (induction_of_arith d.summands)
    simp
    exact (rob_strict V a b).symm.trans ((Robinson.strict_iff j summed a b).trans (rob_strict A _ _))
  initial := by
    intro R mem n a ha
    obtain rfl := Set.mem_singleton_iff.mp mem
    have ha' : a < i n := by simpa using ha
    have j := initial_map i hi d
    have summed := Robinson.summands hi (induction_of_arith d.summands)
    obtain ⟨m,_,hm⟩ := Robinson.strict_initial j summed n a ((rob_strict A _ _).mpr ha')
    exact ⟨m,hm⟩

/-- This is the Foundation Σ₁ formula, with no assumption that the interpreted
Q model is a model of IΣ₁. Its parameter-definable numeral map is the interface. -/
theorem sigma_one_up (i : V → A) (hi : (rob V).NumeralMap (rob A) i)
    (d : DefinableInductions i) (φ : 𝚺ᴬ₁.Semisentence k) (v : Fin k → V) :
    φ.val.Evalb v → φ.val.Evalb (M := A) (i ∘ v) :=
  Bounding.sigmaOne_upward_absolute (structureEmbedding i hi d) φ v

end PA192.Numerals.FoundationRoute

#print axioms PA192.Numerals.FoundationRoute.sigma_one_up
