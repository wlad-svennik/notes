module
public import ModelSourceFields

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterFields
set_option maxHeartbeats 3000000
set_option maxRecDepth 8000

namespace PA192.ModelSearch.RegisterCommands


variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

noncomputable def state (t s h p : V) : V := ⟪t,⟪s,⟪h,p⟫⟫⟫
noncomputable def top (e : V) := pi₁ e
noncomputable def stack (e : V) := pi₁ (pi₂ e)
noncomputable def cache (e : V) := pi₁ (pi₂ (pi₂ e))
noncomputable def param (e : V) := pi₂ (pi₂ (pi₂ e))

noncomputable def mp (d e : V) : V :=
  let b := param e+d
  state (if cache e=imp (top e) b then b else 0) (stack e) 0 b

noncomputable def mode (d e : V) : V :=
  let u := param e+d
  if u=0 then state (top e) (right (stack e)) (left (stack e)) 0
  else state (cache e) (stack e) (top e) (u-1)

def observes (e : V) : Prop := cache e=3

theorem mp_state (d t s h p : V) : mp d (state t s h p) =
    state (if h=imp t (p+d) then p+d else 0) s 0 (p+d) := by simp [mp,state,top,cache,stack,param]

theorem nip_state (t s h : V) : mode 0 (state t s h 0) = state t (right s) (left s) 0 := by
  simp [mode,state,top,stack,param]

theorem swap_state (t s h : V) : mode 1 (state t s h 0) = state h s t 0 := by
  simp [mode,state,top,cache,stack,param]

theorem mode_state_succ (d t s h p j : V) (w : p+d=j+1) :
    mode d (state t s h p) = state h s t j := by simp [mode,state,top,cache,stack,param,w]

@[simp] theorem observes_state (t s h p : V) : observes (state t s h p) ↔ h=3 := by
  simp [observes,state,cache]

/-- Seven earliest emitted rows, most recent first, on any packed tail. -/
noncomputable def front7 (a b c u bottom : V) : V :=
  cantor (row6 a b c) (cantor (row5 a b c) (cantor (row4 a b c) (cantor (row3 a b)
    (cantor (row2 a b c) (cantor (row1 a b) (cantor (row0 a b c u) bottom))))))

/-- All nine emitted values, most recent first, before the automatic MODE. -/
noncomputable def front9 (a b c u bottom : V) : V :=
  cantor (row8 a b) (cantor (row7 a b) (front7 a b c u bottom))

instance front7Def : Language.DefinableFunction₅ ℒₒᵣ (front7 (V:=V)) := by
  unfold front7 row0 row1 row2 row3 row4 row5 row6
  definability
instance front9Def : Language.DefinableFunction₅ ℒₒᵣ (front9 (V:=V)) := by
  unfold front9 front7 row0 row1 row2 row3 row4 row5 row6 row7 row8
  definability

noncomputable def batch (rank body fields : V) : V := ⟪rank,⟪body,fields⟫⟫
noncomputable def batchRank (v : V) := pi₁ v
noncomputable def batchBody (v : V) := pi₁ (pi₂ v)
noncomputable def batchFields (v : V) := pi₂ (pi₂ v)

noncomputable def nextBody (v : V) := front9 (left (right (batchFields v))) (left (batchFields v)) (batchRank v-1) 0 (batchBody v)

instance nextBodyDef : Language.DefinableFunction₁ ℒₒᵣ (nextBody (V:=V)) := by
  unfold nextBody batchFields batchRank batchBody
  apply Language.DefinableFunction₅.comp (F:=front9) <;> definability

/-- One additional AX iteration at source PC39 after parameter and cache have been cleared. -/
noncomputable def nextBatch (v : V) : V :=
  chooseZero (batchRank v) v (batch (batchRank v-1) (nextBody v) (right (right (batchFields v))))

instance nextBatchDef : Language.DefinableFunction₁ ℒₒᵣ (nextBatch (V:=V)) := by
  unfold nextBatch batchRank batchFields batch
  definability

theorem next_literal (j body y d w : V) :
    nextBatch (batch (j+1) body (cantor y (cantor d w))) = batch j (front9 d y j 0 body) w := by
  simp [nextBatch,nextBody,chooseZero,batch,batchRank,batchBody,batchFields]

/-- This fold records just the complete rank-j,...,1 batches above the old packed stack. -/
noncomputable def pushRemaining (v : V) : V :=
  let rank := pi₁ v
  if rank=0 then v else ⟪rank-1,front9 0 0 rank 0 (pi₂ v)⟫

instance pushRemainingDef : Language.DefinableFunction₁ ℒₒᵣ (pushRemaining (V:=V)) := by
  apply Language.Definable.of_iff (Q := fun v : Fin 2 → V =>
    (pi₁ (v 1)=0 ∧ v 0=v 1) ∨ (pi₁ (v 1)≠0 ∧ v 0=⟪pi₁ (v 1)-1,front9 0 0 (pi₁ (v 1)) 0 (pi₂ (v 1))⟫))
  · unfold front9 front7 row0 row1 row2 row3 row4 row5 row6 row7 row8
    definability
  · intro v
    by_cases h : pi₁ (v 1)=0 <;> simp [pushRemaining,h]

noncomputable def higher (n bottom : V) : V := pi₂ (iterate pushRemaining n ⟪n,bottom⟫)
instance higherDef : Language.DefinableFunction₂ ℒₒᵣ (higher (V:=V)) := by unfold higher; definability

@[simp] theorem higher_zero (bottom : V) : higher 0 bottom = bottom := by simp [higher]
theorem higher_succ (j bottom : V) : higher (j+1) bottom = higher j (front9 0 0 (j+1) 0 bottom) := by
  rw [higher,iterate_succ_left]
  simp [pushRemaining,higher]

noncomputable def extraFront (j bottom : V) := front7 0 0 0 0 (higher j bottom)

@[simp] theorem extraFront_zero (bottom : V) : extraFront 0 bottom = front7 0 0 0 0 bottom := by simp [extraFront]
theorem extraFront_succ (j bottom : V) : extraFront (j+1) bottom = extraFront j (front9 0 0 (j+1) 0 bottom) := by
  rw [extraFront,higher_succ]; rfl

/-- The raw counted loop reads exactly the zero fields, including nonstandard counts. -/
theorem zero_batches_run : ∀ j : V, ∀ bottom w,
    iterate nextBatch (j+1) (batch (j+1) bottom (zeroBatches (j+1) w)) =
      batch 0 (front9 0 0 0 0 (higher j bottom)) w := by
  apply modelInduct
  · unfold batch front9 front7 row0 row1 row2 row3 row4 row5 row6 row7 row8
    definability
  · intro bottom w
    rw [iterate_succ_left,zeroBatches_succ]
    simpa using (next_literal (0:V) bottom 0 0 w)
  · intro j ih bottom w
    rw [iterate_succ_left,zeroBatches_succ,next_literal]
    exact (ih _ _).trans (by rw [higher_succ])

noncomputable def popAfterAX (body : V) := state (left body) (right (right body)) (left (right body)) 0

/-- Literal packed source protocol. Its result pairs the proof state with its unread input. -/
noncomputable def axRaw (outer b delta count rawTail e : V) : V :=
  let p := param e+outer
  let first := front9 (p+delta) (cache e+b) count p (cantor (top e) (stack e))
  let out := iterate nextBatch count (batch count first rawTail)
  ⟪popAfterAX (batchBody out),batchFields out⟫

theorem ax_zero (outer b delta tail t s h p : V) :
    axRaw outer b delta 0 tail (state t s h p) =
    ⟪state (row8 ((p+outer)+delta) (h+b))
      (front7 ((p+outer)+delta) (h+b) 0 (p+outer) (cantor t s))
      (row7 ((p+outer)+delta) (h+b)) 0,tail⟫ := by
  simp [axRaw,popAfterAX,batchBody,batchFields,batch,state,param,top,stack,cache,front9]

theorem ax_positive (outer b delta j tail t s h p : V) :
    axRaw outer b delta (j+1) (zeroBatches (j+1) tail) (state t s h p) =
    ⟪state (row8 (0:V) 0)
      (extraFront j (front9 ((p+outer)+delta) (h+b) (j+1) (p+outer) (cantor t s)))
      (row7 (0:V) 0) 0,tail⟫ := by
  simp only [axRaw,top,stack,cache,param,state,pi₁_pair,pi₂_pair]
  rw [zero_batches_run]
  simp [popAfterAX,batchBody,batchFields,batch,front9,extraFront,state]

end PA192.ModelSearch.RegisterCommands
#print axioms PA192.ModelSearch.RegisterCommands.ax_positive
