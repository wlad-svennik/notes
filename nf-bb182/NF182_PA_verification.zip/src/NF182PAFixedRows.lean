import NF182PAFixedChart
import CompactRows
import NF185PASetSyntax
import NF185PARepresented
import NF185PAInterpreted

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Ground NF185PA.Comparison
namespace NF182PA.Fixed
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

def HasFixedRows (V : Type) [ORingStructure V] : Prop :=
  ∃ (S : Signature V) (E : V → V → Prop), Language.DefinableFunction₂ ℒₒᵣ S.app ∧
    Language.DefinableFunction₂ ℒₒᵣ S.h ∧ Language.DefinableRel ℒₒᵣ E ∧
    NF196.Compact.Rows S E ∧ ¬E S.s S.q

private theorem witnessRel_def (E : V → V → Prop) (ap : V → V → V)
    [Language.DefinableRel ℒₒᵣ E] [Language.DefinableFunction₂ ℒₒᵣ ap] :
    Language.DefinableRel₃ ℒₒᵣ (fun y a b =>
      (E a b ∧ ∀ c, E (ap y c) a) ∨ (¬E a b ∧ ¬E (ap a y) (ap b y))) := by
  definability

theorem fixedRows_of_graph (N : NF196.Compact.Chart X) (π : V → X) (sur : Function.Surjective π)
    (dEq : Language.DefinableRel ℒₒᵣ (fun a b => π a=π b))
    (dApp : Language.DefinableRel₃ ℒₒᵣ (fun y a b => π y=N.app (π a) (π b))) :
    HasFixedRows V := by
  let E := fun a b => π a=π b
  letI : Language.DefinableRel ℒₒᵣ E := dEq
  letI := dApp
  obtain ⟨ap,da,A⟩ := pick₂ (fun y a b => π y=N.app (π a) (π b)) (fun a b => sur _)
  letI := da
  let W (y a b : V) := (E a b ∧ ∀ c, E (ap y c) a) ∨ (¬E a b ∧ ¬E (ap a y) (ap b y))
  have dW : Language.DefinableRel₃ ℒₒᵣ W := witnessRel_def E ap
  letI := dW
  have exW (a b : V) : ∃ y, W y a b := by
    by_cases e : E a b
    · obtain ⟨y,hy⟩ := sur (N.K (π a))
      exact ⟨y,Or.inl ⟨e,fun c => (A y c).trans (by rw [hy,N.k_app])⟩⟩
    · have sep : ∃ x, N.app (π a) x≠N.app (π b) x := by
        by_contra! bad
        exact e (N.ext bad)
      obtain ⟨x,hx⟩ := sep
      obtain ⟨y,rfl⟩ := sur x
      exact ⟨y,Or.inr ⟨e,fun h => hx ((A a y).symm.trans (h.trans (A b y)))⟩⟩
  obtain ⟨h,dh,H⟩ := pick₂ W exW
  obtain ⟨q,hq⟩ := sur N.J
  let S : Signature V := ⟨q,ap,h⟩
  have hk (a : V) : π (S.k a)=N.K (π a) := by
    apply N.ext
    intro x
    obtain ⟨c,rfl⟩ := sur x
    have g := H a a
    have p : ∀ c, E (ap (h a a) c) a := g.elim And.right (fun no => (no.1 rfl).elim)
    exact (A _ _).symm.trans ((p c).trans (N.k_app _ _).symm)

  have qs : π S.s=N.B := by
    change π (ap q q)=_
    rw [A,hq,N.letter]
  have neq : ¬E S.s S.q := fun e => N.proper (qs.symm.trans (e.trans hq))
  refine ⟨S,E,da,dh,dEq,?_,neq⟩
  constructor
  · intro a b c e
    exact (A _ _).trans ((congrArg (N.app (π a)) e).trans (A _ _).symm)
  · intro a b
    change π (ap (S.k b) a)=_
    rw [A,hk,N.k_app]
  · intro a b c e
    exact (A _ _).trans ((congrArg (fun v => N.app v (π b)) e.symm).trans (A _ _).symm)
  · intro a b c
    change π (ap (ap (ap S.s c) a) b)=π (ap (ap c (S.k b)) (ap a b))
    simp only [A,qs,hk,N.b_app]
  · exact fun _ _ _ ab ac => ac.symm.trans ab
  · intro x y cond
    change (π (ap (ap q (S.k x)) y) = π S.s → π (ap (ap q (S.k x)) x) = π S.s) at cond
    have cond' : (N.app (N.app N.J (N.K (π x))) (π y) = N.B) →
        N.app (N.app N.J (N.K (π x))) (π x) = N.B := by
      simpa only [A,qs,hq,hk,N.letter] using cond
    exact (NF196.Compact.partial_iff _ _ _ N.proper.symm).mpr
      ⟨N.off,N.on⟩ (π x) (π y) cond'
  · intro a b w
    rcases H a b with ⟨e,_⟩|⟨_,ne⟩
    · exact e
    · exact (ne w.symm).elim

/-- The chart's application graph is given by a fixed set-theoretic formula.
Representatives and witnesses can therefore be chosen arithmetically. -/
theorem rows_of_presentation (hnf : Presented 𝗡𝗙 V) : HasFixedRows V := by
  obtain ⟨X,m,nd,hm,⟨p⟩⟩ := hnf
  letI := m
  letI := nd
  letI := hm
  obtain ⟨N,app_eq⟩ := chart_with_old_application X
  have graph : Language.DefinableRel₃ ℒₒᵣ (fun y a b => p.dec y = N.app (p.dec a) (p.dec b)) := by
    have d := definable_set_eval p SetTheory.NFFn.appD.φ
    apply (Language.Definable.retraction d (fun i => ![(1:Fin 3),2,0] i)).of_iff
    intro v
    have eh : (p.dec ∘ (fun i => v (![1,2,0] i))) = ![p.dec (v 1),p.dec (v 2),p.dec (v 0)] := by
      funext i;fin_cases i <;> rfl
    rw [eh,app_eq]
    exact (eq_comm.trans (SetTheory.NFFn.NF188Finite.oldApp_iff _ _ _).symm).trans
      (SetTheory.NFFn.appD.eval X ![p.dec (v 1),p.dec (v 2),p.dec (v 0)]).symm
  exact fixedRows_of_graph N p.dec p.onto p.eqDef graph
end NF182PA.Fixed
#print axioms NF182PA.Fixed.rows_of_presentation
