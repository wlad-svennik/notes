module
public import ModelCantor

@[expose] public section
set_option maxHeartbeats 3500000
set_option maxRecDepth 6000
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Numerals.FoundationRoute PA192.Literal

namespace PA192.ModelSearch

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

noncomputable def rowCode (i u b c d : V) :=
  cantor 0 (cantor i (cantor u (cantor b (cantor c d))))+1
noncomputable def detachCode (minor major b : V) := cantor 1 (cantor minor (cantor major b))+1

def rowMeaning (i a b c u p : V) : Prop :=
  (i=0 ∧ p=row0 a b c u) ∨ (i=1 ∧ p=row1 a b) ∨ (i=2 ∧ p=row2 a b c) ∨
  (i=3 ∧ p=row3 a b) ∨ (i=4 ∧ p=row4 a b c) ∨ (i=5 ∧ p=row5 a b c) ∨
  (i=6 ∧ p=row6 a b c) ∨ (i=7 ∧ p=row7 a b) ∨ (i=8 ∧ p=row8 a b)

def Leaf (root p : V) : Prop :=
  ∃ u b c d i, root=rowCode i u b c d ∧ rowMeaning i (u+d) b c u p

def TreeLine (t root p : V) : Prop :=
  Leaf root p ∨ ∃ l r a, root=detachCode l r p ∧ ⟪l,a⟫∈t ∧ ⟪r,imp a p⟫∈t
def ValidTree (t : V) : Prop := ∀ r p, ⟪r,p⟫∈t → TreeLine t r p
def TreeProof (r p : V) : Prop := ∃ t : V, ValidTree t ∧ ⟪r,p⟫∈t
def TreeProv (p : V) : Prop := ∃ r, TreeProof r p

instance detachDef : Language.DefinableFunction₃ ℒₒᵣ (detachCode (V:=V)) := by
  unfold detachCode; definability
instance leafDef : Language.DefinableRel ℒₒᵣ (Leaf (V:=V)) := by
  unfold Leaf rowCode rowMeaning row0 row1 row2 row3 row4 row5 row6 row7 row8
  aesop (config := {terminal := true, maxRuleApplications := 1600, maxRuleApplicationDepth := 90}) (rule_sets := [Definability])
instance treeLineDef : Language.DefinableRel₃ ℒₒᵣ (TreeLine (V:=V)) := by unfold TreeLine; definability
instance validDef : Language.DefinablePred ℒₒᵣ (ValidTree (V:=V)) := by unfold ValidTree; definability
instance treeProofDef : Language.DefinableRel ℒₒᵣ (TreeProof (V:=V)) := by unfold TreeProof; definability
instance treeProvDef : Language.DefinablePred ℒₒᵣ (TreeProv (V:=V)) := by unfold TreeProv; definability

theorem leaf_is_axiom {n p : V} (h : Leaf n p) : Ax p := by
  obtain ⟨u,b,c,d,i,_,hr⟩ := h
  rcases hr with h|h|h|h|h|h|h|h|h
  all_goals rcases h with ⟨_,rfl⟩
  · exact Or.inl ⟨_,_,_,_,not_lt_of_ge (show u≤u+d from le_self_add),rfl⟩
  · exact Or.inr (Or.inl ⟨_,_,rfl⟩)
  · exact Or.inr (Or.inr (Or.inl ⟨_,_,_,rfl⟩))
  · exact Or.inr (Or.inr (Or.inr (Or.inl ⟨_,_,rfl⟩)))
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨_,_,_,rfl⟩))))
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨_,_,_,rfl⟩)))))
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨_,_,_,rfl⟩))))))
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨_,_,rfl⟩)))))))
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨_,_,rfl⟩)))))))

theorem ax_has_leaf {p : V} (h : Ax p) : ∃ n, Leaf n p := by
  rcases h with h|h|h|h|h|h|h|h|h
  · obtain ⟨a,b,c,u,hu,rfl⟩ := h
    have hu' : u+(a-u) = a := by rw [add_comm,sub_add_self_of_le (le_of_not_gt hu)]
    refine ⟨_,u,b,c,a-u,0,rfl,Or.inl ⟨rfl,?_⟩⟩
    rw [hu']
  · obtain ⟨a,b,rfl⟩ := h
    exact ⟨_,0,b,0,a,1,rfl,Or.inr (Or.inl ⟨rfl,by simp⟩)⟩
  · obtain ⟨a,b,c,rfl⟩ := h
    exact ⟨_,0,b,c,a,2,rfl,Or.inr (Or.inr (Or.inl ⟨rfl,by simp⟩))⟩
  · obtain ⟨a,b,rfl⟩ := h
    exact ⟨_,0,b,0,a,3,rfl,Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl,by simp⟩)))⟩
  · obtain ⟨a,b,c,rfl⟩ := h
    exact ⟨_,0,b,c,a,4,rfl,Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl,by simp⟩))))⟩
  · obtain ⟨a,b,c,rfl⟩ := h
    exact ⟨_,0,b,c,a,5,rfl,Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl,by simp⟩)))))⟩
  · obtain ⟨a,b,c,rfl⟩ := h
    exact ⟨_,0,b,c,a,6,rfl,Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl,by simp⟩))))))⟩
  · obtain ⟨a,b,rfl⟩ := h
    exact ⟨_,0,b,0,a,7,rfl,Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl,by simp⟩)))))))⟩
  · obtain ⟨a,b,rfl⟩ := h
    exact ⟨_,0,b,0,a,8,rfl,Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨rfl,by simp⟩)))))))⟩

theorem singleton_leaf {n p : V} (h : Leaf n p) : TreeProof n p := by
  refine ⟨{⟪n,p⟫},?_,by simp⟩
  intro r q mem
  obtain ⟨rfl,rfl⟩ : r=n ∧ q=p := by simpa using mem
  exact Or.inl h

theorem line_mono {s t n p : V} (sub : s⊆t) (h : TreeLine s n p) : TreeLine t n p := by
  rcases h with h|⟨l,r,a,e,hm,hM⟩
  · exact Or.inl h
  · exact Or.inr ⟨l,r,a,e,sub hm,sub hM⟩

theorem join_trees {l r a b : V} (m : TreeProof l a) (M : TreeProof r (imp a b)) :
    TreeProof (detachCode l r b) b := by
  obtain ⟨s,sv,hm⟩ := m
  obtain ⟨t,tv,hM⟩ := M
  let v := detachCode l r b
  let joint : V := insert ⟪v,b⟫ (s∪t)
  have si : s⊆joint := by intro x hx; simp [joint,hx]
  have ti : t⊆joint := by intro x hx; simp [joint,hx]
  refine ⟨joint,?_,by simp [joint,v]⟩
  intro k y mem
  rcases mem_bitInsert_iff.mp mem with e|old
  · obtain ⟨rfl,rfl⟩ := pair_ext_iff.mp e
    exact Or.inr ⟨l,r,a,rfl,si hm,ti hM⟩
  · rcases mem_cup_iff.mp old with h|h
    · exact line_mono si (sv k y h)
    · exact line_mono ti (tv k y h)

theorem pool_to_tree {p : V} (h : ProofPool.Pr (∅ : V) p) : TreeProv p := by
  apply ProofPool.realize (R:=TreeProv) (h:=h)
  · intro q ax
    obtain ⟨n,leaf⟩ := ax_has_leaf ax
    exact ⟨n,singleton_leaf leaf⟩
  · intro a e; simp at e
  · rintro a b ⟨r,hmj⟩ ⟨l,hmn⟩
    exact ⟨_,join_trees hmn hmj⟩

theorem minor_lower (l r b : V) : l < detachCode l r b := by
  apply lt_succ_iff_le.mpr
  exact le_trans (cantor_ge_left _ _) (cantor_ge_right _ _)

theorem major_lower (l r b : V) : r < detachCode l r b := by
  apply lt_succ_iff_le.mpr
  exact le_trans (cantor_ge_left _ _) (le_trans (cantor_ge_right _ _) (cantor_ge_right _ _))

theorem tree_to_pool {p : V} (h : TreeProv p) : ProofPool.Pr (∅ : V) p := by
  obtain ⟨r,t,vt,hr⟩ := h
  have all : ∀ n : V, ∀ k q, k<n → ⟪k,q⟫∈t → ProofPool.Pr (∅ : V) q := by
    apply modelInduct
    · definability
    · intro k q hk
      exact False.elim ((not_lt_of_ge (show (0:V)≤k from zero_le)) hk)
    · intro n ih k q hk mem
      rcases lt_or_eq_of_le (lt_succ_iff_le.mp hk) with less|eq
      · exact ih k q less mem
      · subst k
        rcases vt n q mem with leaf|⟨l,r,a,e,hm,hM⟩
        · exact ProofPool.leaf (Or.inl (leaf_is_axiom leaf))
        · subst n
          exact ProofPool.mp (ih _ _ (major_lower ..) hM) (ih _ _ (minor_lower ..) hm)
  exact all (r+1) r p (by simp) hr

theorem pool_iff_explicit_tree (p : V) : ProofPool.Pr (∅:V) p ↔ TreeProv p :=
  ⟨pool_to_tree,tree_to_pool⟩

end PA192.ModelSearch
#print axioms PA192.ModelSearch.pool_iff_explicit_tree
