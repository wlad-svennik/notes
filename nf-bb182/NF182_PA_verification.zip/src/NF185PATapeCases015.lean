import NF185PATapeBatchCheck
namespace NF185PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w480_0 : checkWitness 480 false false 8972 = true := by decide +kernel
private theorem w480_2 : checkWitness 480 true false 8963 = true := by decide +kernel
private theorem cases480 : checkFour 480 (8972,0,8963,0) = true := by
  simp only [checkFour, w480_0, w480_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one480 : Coverage 480 481 := checkList_sound (ws:=[(8972,0,8963,0)]) (by simpa only [checkList, Bool.and_true] using cases480)
private theorem w481_0 : checkWitness 481 false false 66 = true := by decide +kernel
private theorem w481_2 : checkWitness 481 true false 66 = true := by decide +kernel
private theorem cases481 : checkFour 481 (66,0,66,0) = true := by
  simp only [checkFour, w481_0, w481_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one481 : Coverage 481 482 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases481)
private theorem w482_0 : checkWitness 482 false false 552 = true := by decide +kernel
private theorem w482_1 : checkWitness 482 false true 4648 = true := by decide +kernel
private theorem w482_2 : checkWitness 482 true false 552 = true := by decide +kernel
private theorem w482_3 : checkWitness 482 true true 4648 = true := by decide +kernel
private theorem cases482 : checkFour 482 (552,4648,552,4648) = true := by
  simp only [checkFour, w482_0, w482_1, w482_2, w482_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one482 : Coverage 482 483 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases482)
private theorem w483_0 : checkWitness 483 false false 8916 = true := by decide +kernel
private theorem w483_2 : checkWitness 483 true false 8912 = true := by decide +kernel
private theorem cases483 : checkFour 483 (8916,0,8912,0) = true := by
  simp only [checkFour, w483_0, w483_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one483 : Coverage 483 484 := checkList_sound (ws:=[(8916,0,8912,0)]) (by simpa only [checkList, Bool.and_true] using cases483)
private theorem w484_0 : checkWitness 484 false false 70 = true := by decide +kernel
private theorem w484_2 : checkWitness 484 true false 70 = true := by decide +kernel
private theorem cases484 : checkFour 484 (70,0,70,0) = true := by
  simp only [checkFour, w484_0, w484_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one484 : Coverage 484 485 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases484)
private theorem w485_0 : checkWitness 485 false false 596 = true := by decide +kernel
private theorem w485_1 : checkWitness 485 false true 4692 = true := by decide +kernel
private theorem w485_2 : checkWitness 485 true false 596 = true := by decide +kernel
private theorem w485_3 : checkWitness 485 true true 4692 = true := by decide +kernel
private theorem cases485 : checkFour 485 (596,4692,596,4692) = true := by
  simp only [checkFour, w485_0, w485_1, w485_2, w485_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one485 : Coverage 485 486 := checkList_sound (ws:=[(596,4692,596,4692)]) (by simpa only [checkList, Bool.and_true] using cases485)
private theorem w486_0 : checkWitness 486 false false 8939 = true := by decide +kernel
private theorem w486_2 : checkWitness 486 true false 8935 = true := by decide +kernel
private theorem cases486 : checkFour 486 (8939,0,8935,0) = true := by
  simp only [checkFour, w486_0, w486_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one486 : Coverage 486 487 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases486)
private theorem w487_0 : checkWitness 487 false false 8980 = true := by decide +kernel
private theorem w487_2 : checkWitness 487 true false 8971 = true := by decide +kernel
private theorem cases487 : checkFour 487 (8980,0,8971,0) = true := by
  simp only [checkFour, w487_0, w487_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one487 : Coverage 487 488 := checkList_sound (ws:=[(8980,0,8971,0)]) (by simpa only [checkList, Bool.and_true] using cases487)
private theorem w488_0 : checkWitness 488 false false 82 = true := by decide +kernel
private theorem w488_2 : checkWitness 488 true false 82 = true := by decide +kernel
private theorem cases488 : checkFour 488 (82,0,82,0) = true := by
  simp only [checkFour, w488_0, w488_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one488 : Coverage 488 489 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases488)
private theorem w489_0 : checkWitness 489 false false 684 = true := by decide +kernel
private theorem w489_1 : checkWitness 489 false true 4776 = true := by decide +kernel
private theorem w489_2 : checkWitness 489 true false 675 = true := by decide +kernel
private theorem w489_3 : checkWitness 489 true true 4767 = true := by decide +kernel
private theorem cases489 : checkFour 489 (684,4776,675,4767) = true := by
  simp only [checkFour, w489_0, w489_1, w489_2, w489_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one489 : Coverage 489 490 := checkList_sound (ws:=[(684,4776,675,4767)]) (by simpa only [checkList, Bool.and_true] using cases489)
private theorem w490_0 : checkWitness 490 false false 8935 = true := by decide +kernel
private theorem w490_2 : checkWitness 490 true false 8931 = true := by decide +kernel
private theorem cases490 : checkFour 490 (8935,0,8931,0) = true := by
  simp only [checkFour, w490_0, w490_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one490 : Coverage 490 491 := checkList_sound (ws:=[(8935,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases490)
private theorem w491_0 : checkWitness 491 false false 672 = true := by decide +kernel
private theorem w491_1 : checkWitness 491 false true 4764 = true := by decide +kernel
private theorem w491_2 : checkWitness 491 true false 663 = true := by decide +kernel
private theorem w491_3 : checkWitness 491 true true 4755 = true := by decide +kernel
private theorem cases491 : checkFour 491 (672,4764,663,4755) = true := by
  simp only [checkFour, w491_0, w491_1, w491_2, w491_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one491 : Coverage 491 492 := checkList_sound (ws:=[(672,4764,663,4755)]) (by simpa only [checkList, Bool.and_true] using cases491)
private theorem w492_0 : checkWitness 492 false false 8902 = true := by decide +kernel
private theorem w492_2 : checkWitness 492 true false 8898 = true := by decide +kernel
private theorem cases492 : checkFour 492 (8902,0,8898,0) = true := by
  simp only [checkFour, w492_0, w492_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one492 : Coverage 492 493 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases492)
private theorem w493_0 : checkWitness 493 false false 82 = true := by decide +kernel
private theorem w493_2 : checkWitness 493 true false 82 = true := by decide +kernel
private theorem cases493 : checkFour 493 (82,0,82,0) = true := by
  simp only [checkFour, w493_0, w493_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one493 : Coverage 493 494 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases493)
private theorem w494_0 : checkWitness 494 false false 76 = true := by decide +kernel
private theorem w494_2 : checkWitness 494 true false 76 = true := by decide +kernel
private theorem cases494 : checkFour 494 (76,0,76,0) = true := by
  simp only [checkFour, w494_0, w494_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one494 : Coverage 494 495 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases494)
private theorem w495_0 : checkWitness 495 false false 633 = true := by decide +kernel
private theorem w495_1 : checkWitness 495 false true 4717 = true := by decide +kernel
private theorem w495_2 : checkWitness 495 true false 633 = true := by decide +kernel
private theorem w495_3 : checkWitness 495 true true 4717 = true := by decide +kernel
private theorem cases495 : checkFour 495 (633,4717,633,4717) = true := by
  simp only [checkFour, w495_0, w495_1, w495_2, w495_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one495 : Coverage 495 496 := checkList_sound (ws:=[(633,4717,633,4717)]) (by simpa only [checkList, Bool.and_true] using cases495)
private theorem w496_0 : checkWitness 496 false false 8902 = true := by decide +kernel
private theorem w496_2 : checkWitness 496 true false 8898 = true := by decide +kernel
private theorem cases496 : checkFour 496 (8902,0,8898,0) = true := by
  simp only [checkFour, w496_0, w496_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one496 : Coverage 496 497 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases496)
private theorem w497_0 : checkWitness 497 false false 74 = true := by decide +kernel
private theorem w497_2 : checkWitness 497 true false 74 = true := by decide +kernel
private theorem cases497 : checkFour 497 (74,0,74,0) = true := by
  simp only [checkFour, w497_0, w497_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one497 : Coverage 497 498 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases497)
private theorem w498_0 : checkWitness 498 false false 603 = true := by decide +kernel
private theorem w498_1 : checkWitness 498 false true 4699 = true := by decide +kernel
private theorem w498_2 : checkWitness 498 true false 603 = true := by decide +kernel
private theorem w498_3 : checkWitness 498 true true 4699 = true := by decide +kernel
private theorem cases498 : checkFour 498 (603,4699,603,4699) = true := by
  simp only [checkFour, w498_0, w498_1, w498_2, w498_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one498 : Coverage 498 499 := checkList_sound (ws:=[(603,4699,603,4699)]) (by simpa only [checkList, Bool.and_true] using cases498)
private theorem w499_0 : checkWitness 499 false false 8954 = true := by decide +kernel
private theorem w499_2 : checkWitness 499 true false 8945 = true := by decide +kernel
private theorem cases499 : checkFour 499 (8954,0,8945,0) = true := by
  simp only [checkFour, w499_0, w499_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one499 : Coverage 499 500 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases499)
private theorem w500_0 : checkWitness 500 false false 8898 = true := by decide +kernel
private theorem w500_2 : checkWitness 500 true false 8894 = true := by decide +kernel
private theorem cases500 : checkFour 500 (8898,0,8894,0) = true := by
  simp only [checkFour, w500_0, w500_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one500 : Coverage 500 501 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases500)
private theorem w501_0 : checkWitness 501 false false 66 = true := by decide +kernel
private theorem w501_2 : checkWitness 501 true false 66 = true := by decide +kernel
private theorem cases501 : checkFour 501 (66,0,66,0) = true := by
  simp only [checkFour, w501_0, w501_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one501 : Coverage 501 502 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases501)
private theorem w502_0 : checkWitness 502 false false 682 = true := by decide +kernel
private theorem w502_1 : checkWitness 502 false true 4770 = true := by decide +kernel
private theorem w502_2 : checkWitness 502 true false 673 = true := by decide +kernel
private theorem w502_3 : checkWitness 502 true true 4761 = true := by decide +kernel
private theorem cases502 : checkFour 502 (682,4770,673,4761) = true := by
  simp only [checkFour, w502_0, w502_1, w502_2, w502_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one502 : Coverage 502 503 := checkList_sound (ws:=[(682,4770,673,4761)]) (by simpa only [checkList, Bool.and_true] using cases502)
private theorem w503_0 : checkWitness 503 false false 8939 = true := by decide +kernel
private theorem w503_2 : checkWitness 503 true false 8935 = true := by decide +kernel
private theorem cases503 : checkFour 503 (8939,0,8935,0) = true := by
  simp only [checkFour, w503_0, w503_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one503 : Coverage 503 504 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases503)
private theorem w504_0 : checkWitness 504 false false 70 = true := by decide +kernel
private theorem w504_2 : checkWitness 504 true false 70 = true := by decide +kernel
private theorem cases504 : checkFour 504 (70,0,70,0) = true := by
  simp only [checkFour, w504_0, w504_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one504 : Coverage 504 505 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases504)
private theorem w505_0 : checkWitness 505 false false 510 = true := by decide +kernel
private theorem w505_1 : checkWitness 505 false true 4606 = true := by decide +kernel
private theorem w505_2 : checkWitness 505 true false 510 = true := by decide +kernel
private theorem w505_3 : checkWitness 505 true true 4606 = true := by decide +kernel
private theorem cases505 : checkFour 505 (510,4606,510,4606) = true := by
  simp only [checkFour, w505_0, w505_1, w505_2, w505_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one505 : Coverage 505 506 := checkList_sound (ws:=[(510,4606,510,4606)]) (by simpa only [checkList, Bool.and_true] using cases505)
private theorem w506_0 : checkWitness 506 false false 8913 = true := by decide +kernel
private theorem w506_2 : checkWitness 506 true false 8909 = true := by decide +kernel
private theorem cases506 : checkFour 506 (8913,0,8909,0) = true := by
  simp only [checkFour, w506_0, w506_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one506 : Coverage 506 507 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases506)
private theorem w507_0 : checkWitness 507 false false 642 = true := by decide +kernel
private theorem w507_1 : checkWitness 507 false true 4738 = true := by decide +kernel
private theorem w507_2 : checkWitness 507 true false 633 = true := by decide +kernel
private theorem w507_3 : checkWitness 507 true true 4729 = true := by decide +kernel
private theorem cases507 : checkFour 507 (642,4738,633,4729) = true := by
  simp only [checkFour, w507_0, w507_1, w507_2, w507_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one507 : Coverage 507 508 := checkList_sound (ws:=[(642,4738,633,4729)]) (by simpa only [checkList, Bool.and_true] using cases507)
private theorem w508_0 : checkWitness 508 false false 188 = true := by decide +kernel
private theorem w508_2 : checkWitness 508 true false 188 = true := by decide +kernel
private theorem cases508 : checkFour 508 (188,0,188,0) = true := by
  simp only [checkFour, w508_0, w508_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one508 : Coverage 508 509 := checkList_sound (ws:=[(188,0,188,0)]) (by simpa only [checkList, Bool.and_true] using cases508)
private theorem w509_0 : checkWitness 509 false false 587 = true := by decide +kernel
private theorem w509_1 : checkWitness 509 false true 4675 = true := by decide +kernel
private theorem w509_2 : checkWitness 509 true false 587 = true := by decide +kernel
private theorem w509_3 : checkWitness 509 true true 4675 = true := by decide +kernel
private theorem cases509 : checkFour 509 (587,4675,587,4675) = true := by
  simp only [checkFour, w509_0, w509_1, w509_2, w509_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one509 : Coverage 509 510 := checkList_sound (ws:=[(587,4675,587,4675)]) (by simpa only [checkList, Bool.and_true] using cases509)
private theorem w510_0 : checkWitness 510 false false 8928 = true := by decide +kernel
private theorem w510_2 : checkWitness 510 true false 8919 = true := by decide +kernel
private theorem cases510 : checkFour 510 (8928,0,8919,0) = true := by
  simp only [checkFour, w510_0, w510_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one510 : Coverage 510 511 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases510)
private theorem w511_0 : checkWitness 511 false false 68 = true := by decide +kernel
private theorem w511_2 : checkWitness 511 true false 68 = true := by decide +kernel
private theorem cases511 : checkFour 511 (68,0,68,0) = true := by
  simp only [checkFour, w511_0, w511_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one511 : Coverage 511 512 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases511)
theorem cover0480 : Coverage 480 512 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one480 one481) (Coverage.join one482 one483)) (Coverage.join (Coverage.join one484 one485) (Coverage.join one486 one487))) (Coverage.join (Coverage.join (Coverage.join one488 one489) (Coverage.join one490 one491)) (Coverage.join (Coverage.join one492 one493) (Coverage.join one494 one495)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one496 one497) (Coverage.join one498 one499)) (Coverage.join (Coverage.join one500 one501) (Coverage.join one502 one503))) (Coverage.join (Coverage.join (Coverage.join one504 one505) (Coverage.join one506 one507)) (Coverage.join (Coverage.join one508 one509) (Coverage.join one510 one511)))))
end NF185PA.Symbolic
