import Correct
import SemanticAlgebra
import StackHalves
import ExtractClosures
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Direct
namespace NF192.Internal
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {m : X→X→Prop}
variable {d : Presentation V X m} {D z S A B P : X} {o : Operations V} {n : NumOps (Dom m D)}

theorem pair_test (L : OpsLaws m D z S A B P n) (C : X) (u v : Dom m D) :
    RelObj m D P C u.val v.val ↔ m (n.pair u v).val C := by
  unfold RelObj;rw [exDom];constructor
  · rintro ⟨k,hk,h⟩;rw [(L.pv _ _ k).mp hk];exact h
  · exact fun h=>⟨_,(L.pv _ _ _).mpr rfl,h⟩

noncomputable def algebraOf (L : OpsLaws m D z S A B P n) (C : Correct d D z S A B P o) : Algebra o n := by
  let N := Dom m D
  have w (r : V) (u v : N) := pair_test L (d.dec r) u v
  have p (u v h : N) := L.pv u v h
  have bin (r : V) (G : X) (f : N→N→N) (law : ∀x y t : N,Tri m G x.val y.val t.val ↔ f x y=t)
      (ok : HasR m D P (d.dec r) (fun h v=>∃x y,m x D ∧ m y D ∧ Tri m P x y h ∧ Tri m G x y v)) (x y t : N) :
      m (n.pair (n.pair x y) t).val (d.dec r) ↔ f x y=t := by
    rw [←w,ok _ _ ⟨(n.pair x y).2,t.2⟩];dsimp only;rw [exDom2];constructor
    · rintro ⟨a,b,h1,h2⟩;obtain ⟨rfl,rfl⟩ := n.pair_inj _ _ _ _ ((p _ _ _).mp h1)
      exact (law _ _ _).mp h2
    · exact fun h=>⟨x,y,(p _ _ _).mpr rfl,(law _ _ _).mpr h⟩
  refine ⟨fun r u=>m u.val (d.dec r),fun h=>(n.halves h).1,fun h=>(n.halves h).2,
    (fun x y=>congrArg Prod.fst (n.halves_of x y)),(fun x y=>congrArg Prod.snd (n.halves_of x y)),
    ?_,?_,?_,?_,bin _ _ _ L.av C.add,bin _ _ _ L.mv C.mul,?_,?_,?_,?_,?_,?_,?_⟩
  · intro h v;rw [←w,C.head _ _ ⟨h.2,v.2⟩];unfold HeadP;rw [exDom,exDom2]
    simpa only [L.pv,←L.zv,Subtype.coe_inj] using n.halves_head h v
  · intro h v;rw [←w,C.tail _ _ ⟨h.2,v.2⟩];unfold TailP;rw [exDom,exDom2]
    simpa only [L.pv,←L.zv,Subtype.coe_inj] using n.halves_tail h v
  · intro h v;rw [←w,C.zero _ _ ⟨h.2,v.2⟩];dsimp only;rw [←L.zv,Subtype.coe_inj,eq_comm]
  · intro h v;rw [←w,C.succ _ _ ⟨h.2,v.2⟩,L.sv]
  · intro x y;rw [←w,C.less _ _ ⟨x.2,y.2⟩];unfold OrderP;rw [exDom2]
    constructor
    · rintro ⟨k,t,ht,hh⟩;exact ⟨k,(L.sv _ _).mp ht ▸ (L.av _ _ _).mp hh⟩
    · rintro ⟨k,h⟩;exact ⟨k,n.s k,(L.sv _ _).mpr rfl,(L.av _ _ _).mpr h⟩
  · intro b u;rw [←w,C.invTail _ _ ⟨b.2,u.2⟩];unfold InvTailP;rw [exDom]
    exact exists_congr fun x=>p x b u
  · intro a b h v;rw [←w,C.comp _ _ _ _ ⟨h.2,v.2⟩];dsimp only;rw [exDom]
    exact exists_congr fun u => and_congr (w a h u) (w b u v)
  · intro a b h t;rw [←w,C.fork _ _ _ _ ⟨h.2,t.2⟩];dsimp only;rw [exDom2]
    exact exists_congr fun x=>exists_congr fun y=>and_congr (p x y t) (and_congr (w a h x) (w b h y))
  · intro a b h;rw [C.common _ _ _ h.2];dsimp only;rw [exDom]
    exact exists_congr fun u=>and_congr (w a h u) (w b h u)
  · intro a b h;exact C.cap _ _ _ h.2
  · intro a h;exact C.neg _ _ h.2

@[simp] theorem algebraOf_sat (L : OpsLaws m D z S A B P n) (C : Correct d D z S A B P o) (r : V) (t : Dom m D) :
    (algebraOf L C).sat r t ↔ m t.val (d.dec r) := Iff.rfl
#print axioms algebraOf
end NF192.Internal
