import BaseSetSyntax

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
namespace NF192.Direct.Baseline
variable {X : Type u} {A : Type w} [ORingStructure A] {m : X→X→Prop} {j : A→X}

structure GraphMath (m : X→X→Prop) (j : A→X) (D z s a b : X) : Prop where
  inj : Function.Injective j
  domain : ∀x, m x D ↔ ∃v, j v=x
  zero : j 0=z
  one : ∀y, Edge m s z (j y) ↔ 1=y
  add : ∀x y v, Tri m a (j x) (j y) (j v) ↔ x+y=v
  mul : ∀x y v, Tri m b (j x) (j y) (j v) ↔ x*y=v
  less : ∀x y, (∃a' b',m a' D ∧ m b' D ∧ Edge m s a' b' ∧ Tri m a (j x) b' (j y)) ↔ x<y

abbrev GraphAt (m : X→X→Prop) (j : A→X) (p : Ctx k) (e : Fin k→X) :=
  GraphMath m j (e p.D) (e p.z) (e p.s) (e p.a) (e p.m)

def extE (e : Fin k→X) (a b : X) : Fin (k+1+1)→X := Fin.cases b (Fin.cases a e)
private abbrev twice (i : Fin k) := i.succ.succ

theorem binary_meaning {k} (p : Ctx k) (e : Fin k→X) (A0 : GraphAt m j p e)
    (g out : Fin k) (L R : (h : Nat)→(Fin k→Fin h)→Fin h→ SetForm h)
    (u v y : A) (oy : e out=j y) (op : A→A→A)
    (gr : ∀ i l w, Tri m (e g) (j i) (j l) (j w) ↔ op i l=w)
    (lt : ∀ x z, (L _ twice 1).truth m (extE e (j x) (j z)) ↔ u=x)
    (rt : ∀ x z, (R _ twice 0).truth m (extE e (j x) (j z)) ↔ v=z) :
    (binTerm p g out L R).truth m e ↔ op u v=y := by
  change (∃ x z, m x (e p.D) ∧ m z (e p.D) ∧ (L _ twice 1).truth m (extE e x z) ∧
    (R _ twice 0).truth m (extE e x z) ∧ Tri m (e g) x z (e out)) ↔ _
  rw [oy]
  constructor
  · rintro ⟨x,z,hx,hz,hl,hr,hval⟩
    obtain ⟨i,rfl⟩ := (A0.domain _).mp hx
    obtain ⟨l,rfl⟩ := (A0.domain _).mp hz
    obtain rfl := (lt _ _).mp hl
    obtain rfl := (rt _ _).mp hr
    exact (gr _ _ _).mp hval
  · intro h
    exact ⟨j u,j v,(A0.domain _).mpr ⟨u,rfl⟩,(A0.domain _).mpr ⟨v,rfl⟩,
      (lt _ _).mpr rfl,(rt _ _).mpr rfl,(gr _ _ _).mpr h⟩

theorem term_meaning (t : ClosedSemiterm ℒₒᵣ n) (a : Fin n→A) : ∀ {k} (p : Ctx k) (e : Fin k→X),
    GraphAt m j p e → ∀ (v : Fin n→Fin k), (∀i,e (v i)=j (a i)) →
    ∀ (out : Fin k) (y : A), e out=j y →
      ((term t p v out).truth m e ↔ FFL.FirstOrder.Semiterm.val a Empty.elim t=y) := by
  induction t with
  | bvar i =>
    intro k p e gr v ev out y oy
    change e (v i)=e out ↔ _
    rw [ev,oy]; exact gr.inj.eq_iff
  | fvar i => exact i.elim
  | func h ts ih =>
    intro k p e gr v ev out y oy
    cases h with
    | zero =>
      change e p.z=e out ↔ (0:A)=y
      rw [←gr.zero,oy];exact gr.inj.eq_iff
    | one =>
      change Edge m (e p.s) (e p.z) (e out) ↔ (1:A)=y
      rw [oy]; exact gr.one y
    | add =>
      apply binary_meaning p e gr _ out _ _ _ _ y oy HAdd.hAdd gr.add
      · intro x z;exact ih 0 (p.map twice) (extE e (j x) (j z)) gr (twice ∘ v) ev 1 x rfl
      · intro x z;exact ih 1 (p.map twice) (extE e (j x) (j z)) gr (twice ∘ v) ev 0 z rfl
    | mul =>
      apply binary_meaning p e gr _ out _ _ _ _ y oy HMul.hMul gr.mul
      · intro x z;exact ih 0 (p.map twice) (extE e (j x) (j z)) gr (twice ∘ v) ev 1 x rfl
      · intro x z;exact ih 1 (p.map twice) (extE e (j x) (j z)) gr (twice ∘ v) ev 0 z rfl

theorem atom_meaning {k l n} (p : Ctx k) (e : Fin k→X) (gr : GraphAt m j p e)
    (v : Fin n→Fin k) (a : Fin n→A) (ev : ∀i,e (v i)=j (a i)) (h : (ℒₒᵣ).Rel l)
    (ts : Fin l→ClosedSemiterm ℒₒᵣ n) : (atom p v h ts).truth m e ↔
      (standardModel A).rel h (fun i=>(ts i).val a Empty.elim) := by
  have left (t : ClosedSemiterm ℒₒᵣ n) (x z : A) :=
    term_meaning t a p.up.up (extE e (j x) (j z)) gr (twice ∘ v) ev 1 x rfl
  have right (t : ClosedSemiterm ℒₒᵣ n) (x z : A) :=
    term_meaning t a p.up.up (extE e (j x) (j z)) gr (twice ∘ v) ev 0 z rfl
  cases h with
  | eq =>
    change (∃ x z, m x (e p.D) ∧ m z (e p.D) ∧ (term (ts 0) p.up.up _ 1).truth m (extE e x z) ∧
      (term (ts 1) p.up.up _ 0).truth m (extE e x z) ∧ x=z) ↔ _
    constructor
    · rintro ⟨x,z,hx,hz,ht,hu,rfl⟩
      obtain ⟨a0,rfl⟩ := (gr.domain _).mp hx
      exact ((left (ts 0) a0 a0).mp ht).trans
        ((right (ts 1) a0 a0).mp hu).symm
    · intro h; let v0 := (ts 0).val a Empty.elim; let v1 := (ts 1).val a Empty.elim
      exact ⟨j v0,j v1,(gr.domain _).mpr ⟨_,rfl⟩,(gr.domain _).mpr ⟨_,rfl⟩,
        (left (ts 0) v0 v1).mpr rfl,
        (right (ts 1) v0 v1).mpr rfl,congrArg j h⟩
  | lt =>
    change (∃ x z, m x (e p.D) ∧ m z (e p.D) ∧ (term (ts 0) p.up.up _ 1).truth m (extE e x z) ∧
      (term (ts 1) p.up.up _ 0).truth m (extE e x z) ∧ (less p.up.up 1 0).truth m (extE e x z)) ↔ _
    constructor
    · rintro ⟨x,z,hx,hz,ht,hu,hlt⟩
      obtain ⟨i,rfl⟩ := (gr.domain _).mp hx
      obtain ⟨l,rfl⟩ := (gr.domain _).mp hz
      have lt := (gr.less i l).mp ((less_sat ..).mp hlt)
      rwa [←((left (ts 0) i l).mp ht),
        ←((right (ts 1) i l).mp hu)] at lt
    · intro h; let v0 := (ts 0).val a Empty.elim; let v1 := (ts 1).val a Empty.elim
      exact ⟨j v0,j v1,(gr.domain _).mpr ⟨_,rfl⟩,(gr.domain _).mpr ⟨_,rfl⟩,
        (left (ts 0) v0 v1).mpr rfl,
        (right (ts 1) v0 v1).mpr rfl,(less_sat ..).mpr ((gr.less _ _).mpr h)⟩

end NF192.Direct.Baseline
