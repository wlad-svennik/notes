module
public import Foundation.FirstOrder.Arithmetic.Bootstrapping.Syntax.Theory

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace PA192.NativeTruth

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
variable {L : Language} [L.Encodable] [L.LORDefinable]

theorem list_axiom_codes (xs : List (Sentence L)) (p : V) :
    ((Theory.Δ₁.ofList xs).ch.val.Evalb (M:=V) ![p]) ↔ ∃ φ ∈ xs, p=(⌜φ⌝:V) := by
  induction xs with
  | nil =>
    change (V ⊧/![p] (⊥ : ArithmeticSemisentence 1)) ↔ _
    simp
  | cons a xs ih =>
    change ((Semiformula.Evalb ![p]) ((Theory.Δ₁.singleton a).ch ⋎ (Theory.Δ₁.ofList xs).ch).val) ↔ _
    rw [Bounding.HierarchySymbol.Semiformula.val_or,LogicalConnective.HomClass.map_or,ih]
    have left : (V ⊧/![p] (Theory.Δ₁.singleton a).ch.val) ↔ p=(⌜a⌝:V) := by
      simp [Theory.Δ₁.singleton,numeral_eq_natCast,Sentence.quote_eq_encode]
    rw [left]
    constructor
    · rintro (e|⟨φ,h,e⟩)
      · exact ⟨a,List.mem_cons_self,e⟩
      · exact ⟨φ,List.mem_cons_of_mem _ h,e⟩
    · rintro ⟨φ,h,e⟩
      rcases List.mem_cons.mp h with rfl|h
      · exact Or.inl e
      · exact Or.inr ⟨φ,h,e⟩

/-- Nonstandard inputs in the specific Foundation `ofFinite` axiom presentation
can only be quotations of actual standard members. This conclusion uses that
presentation's explicit finite disjunction. -/
theorem finite_axiom_codes (T : Theory L) (h : Set.Finite T) (p : V) :
    (letI := Theory.Δ₁.ofFinite T h; p∈T.Δ₁Class) ↔ ∃ φ∈T, p=(⌜φ⌝:V) := by
  classical
  change ((Theory.Δ₁.ofList h.toFinset.toList).ch.val.Evalb (M:=V) ![p]) ↔ _
  simpa only [Finset.mem_toList,Set.Finite.mem_toFinset] using list_axiom_codes h.toFinset.toList p

end PA192.NativeTruth

#print axioms PA192.NativeTruth.finite_axiom_codes
