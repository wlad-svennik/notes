import InternalRepresent
import Foundation.FirstOrder.Arithmetic.Bootstrapping.Syntax.Formula.Basic
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding FFL.FirstOrder.Arithmetic.Bootstrapping
namespace NF192.Internal.Operations
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
variable (o : Operations V) [DefinedOps o]

@[simp] lemma tag_of (i d : V) : fstIdx (⟪i,d⟫+1)=i := by simp [fstIdx]
@[simp] lemma payload_of (i d : V) : sndIdx (⟪i,d⟫+1)=d := by simp [sndIdx]
@[simp] lemma pick_same (i a b : V) : pick i i a b=a := by simp [pick]
lemma pick_ne {i j : V} (h:i≠j) (a b : V) : pick j i a b=b := by simp [pick,h]

theorem term_bvar (i : V) : o.termRep (qqBvar i)=o.comp o.head (o.getter i) := by
  rw [termRep,fold_rule];simp [termStep,qqBvar,pick]
theorem term_fvar (i : V) : o.termRep (qqFvar i)=o.comp o.tail (o.getter i) := by
  rw [termRep,fold_rule];simp [termStep,qqFvar,pick]
theorem term_nullary (f : V) : o.termRep (qqFunc 0 f 0)=pick 0 f o.zero (o.comp o.zero o.succ) := by
  rw [termRep,fold_rule];simp [termStep,qqFunc,pick]
theorem term_binary (f a b : V) :
    o.termRep (qqFunc 2 f ?[a,b])=o.comp (o.fork (o.termRep a) (o.termRep b)) (pick 0 f o.add o.mul) := by
  let c := qqFunc 2 f ?[a,b]
  have hl : a<c := by simpa [c] using (nth_lt_qqFunc_of_lt (i:=0) (k:=(2:V)) (f:=f) (v:=?[a,b]) (by simp))
  have hr : b<c := by simpa [c] using (nth_lt_qqFunc_of_lt (i:=1) (k:=(2:V)) (f:=f) (v:=?[a,b]) (by simp))
  change fold o.termStep c=_
  rw [fold_rule]
  have h1 := read_child o.termStep a c hl
  have h2 := read_child o.termStep b c hr
  simp only [c,qqFunc,tag_of,payload_of,pi₁_pair,pi₂_pair] at *
  simp [termStep,termRep,pick,h1,h2]

theorem formula_rel (k r v : V) : o.formulaRep (qqRel k r v)=
    o.common (pick 0 r (o.termRep v.[0]) (o.comp (o.termRep v.[0]) o.less)) (o.termRep v.[1]) := by
  rw [formulaRep,fold_rule];simp [formulaStep,qqRel,pick]

theorem formula_nrel (k r v : V) : o.formulaRep (qqNRel k r v)=
    o.neg (o.common (pick 0 r (o.termRep v.[0]) (o.comp (o.termRep v.[0]) o.less)) (o.termRep v.[1])) := by
  rw [formulaRep,fold_rule];simp [formulaStep,qqNRel,pick]

theorem formula_verum : o.formulaRep (qqVerum : V)=o.common o.zero o.zero := by
  rw [formulaRep,fold_rule];norm_num [formulaStep,qqVerum,pick]

theorem formula_falsum : o.formulaRep (qqFalsum : V)=o.neg (o.common o.zero o.zero) := by
  rw [formulaRep,fold_rule];norm_num [formulaStep,qqFalsum,pick]

theorem formula_and (p q : V) : o.formulaRep (qqAnd p q)=o.cap (o.formulaRep p) (o.formulaRep q) := by
  rw [formulaRep,fold_rule]
  have hp := read_child o.formulaStep p (qqAnd p q) (lt_K!_left _ _)
  have hq := read_child o.formulaStep q (qqAnd p q) (lt_K!_right _ _)
  simp only [qqAnd] at hp hq ⊢
  norm_num [formulaStep,formulaRep,pick,hp,hq]

theorem formula_or (p q : V) : o.formulaRep (qqOr p q)=o.neg (o.cap (o.neg (o.formulaRep p)) (o.neg (o.formulaRep q))) := by
  rw [formulaRep,fold_rule]
  have hp := read_child o.formulaStep p (qqOr p q) (lt_or_left _ _)
  have hq := read_child o.formulaStep q (qqOr p q) (lt_or_right _ _)
  simp only [qqOr] at hp hq ⊢
  norm_num [formulaStep,formulaRep,pick,hp,hq]

theorem formula_all (p : V) : o.formulaRep (qqAll p)=o.neg (o.comp o.invTail (o.neg (o.formulaRep p))) := by
  rw [formulaRep,fold_rule]
  have hp := read_child o.formulaStep p (qqAll p) (lt_forall _)
  simp only [qqAll] at hp ⊢
  norm_num [formulaStep,formulaRep,pick,hp]

theorem formula_ex (p : V) : o.formulaRep (qqExs p)=o.comp o.invTail (o.formulaRep p) := by
  rw [formulaRep,fold_rule]
  have hp := read_child o.formulaStep p (qqExs p) (lt_exists _)
  simp only [qqExs] at hp ⊢
  norm_num [formulaStep,formulaRep,pick,hp]

#print axioms term_binary
#print axioms formula_ex
end NF192.Internal.Operations
