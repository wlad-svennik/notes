module
public import Src185Reach
public import Src185Data
import Mathlib.Tactic.Ring
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields PA192.ModelSearch.Register185
namespace NF185PA.Boot
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 2000000
set_option maxRecDepth 6500
private theorem run_step {i j a b c : V} (eq : j=i+1) (h : run i a=b) (k : step b=c) : run j a=c := by
  rw [eq,run_succ,h,k]
theorem rawPrefix98 : run (98:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((118:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := by
  have step0 : step (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((48:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := by
    rw [step_at 40 _ (row_of_literal 40 _ (by decide) RawRows.raw0040)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run1 : run (1:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((48:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := run_step (i:=(0:V)) (by norm_num) (run_zero _) step0
  have step1 : step (config ((48:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((51:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := by
    rw [step_at 48 _ (row_of_literal 48 _ (by decide) RawRows.raw0048)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run2 : run (2:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((51:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := run_step (i:=(1:V)) (by norm_num) run1 step1
  have step2 : step (config ((51:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((54:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := by
    rw [step_at 51 _ (row_of_literal 51 _ (by decide) RawRows.raw0051)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run3 : run (3:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((54:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := run_step (i:=(2:V)) (by norm_num) run2 step2
  have step3 : step (config ((54:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((57:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := by
    rw [step_at 54 _ (row_of_literal 54 _ (by decide) RawRows.raw0054)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run4 : run (4:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((57:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := run_step (i:=(3:V)) (by norm_num) run3 step3
  have step4 : step (config ((57:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((60:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := by
    rw [step_at 57 _ (row_of_literal 57 _ (by decide) RawRows.raw0057)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run5 : run (5:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((60:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := run_step (i:=(4:V)) (by norm_num) run4 step4
  have step5 : step (config ((60:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((64:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := by
    rw [step_at 60 _ (row_of_literal 60 _ (by decide) RawRows.raw0060)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run6 : run (6:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((64:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := run_step (i:=(5:V)) (by norm_num) run5 step5
  have step6 : step (config ((64:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((70:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := by
    rw [step_at 64 _ (row_of_literal 64 _ (by decide) RawRows.raw0064)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run7 : run (7:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((70:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := run_step (i:=(6:V)) (by norm_num) run6 step6
  have step7 : step (config ((70:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((73:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := by
    rw [step_at 70 _ (row_of_literal 70 _ (by decide) RawRows.raw0070)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run8 : run (8:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((73:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0) := run_step (i:=(7:V)) (by norm_num) run7 step7
  have step8 : step (config ((73:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((74:Nat):V) 1 (vector 0 0 0 1 0 0 0 0 0) := by
    rw [step_at 73 _ (row_of_literal 73 _ (by decide) RawRows.raw0073)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run9 : run (9:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((74:Nat):V) 1 (vector 0 0 0 1 0 0 0 0 0) := run_step (i:=(8:V)) (by norm_num) run8 step8
  have step9 : step (config ((74:Nat):V) 1 (vector 0 0 0 1 0 0 0 0 0)) = config ((75:Nat):V) 1 (vector 0 0 0 1 0 0 1 0 0) := by
    rw [step_at 74 _ (row_of_literal 74 _ (by decide) RawRows.raw0074)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run10 : run (10:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((75:Nat):V) 1 (vector 0 0 0 1 0 0 1 0 0) := run_step (i:=(9:V)) (by norm_num) run9 step9
  have step10 : step (config ((75:Nat):V) 1 (vector 0 0 0 1 0 0 1 0 0)) = config ((76:Nat):V) 1 (vector 0 1 0 1 0 0 1 0 0) := by
    rw [step_at 75 _ (row_of_literal 75 _ (by decide) RawRows.raw0075)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run11 : run (11:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((76:Nat):V) 1 (vector 0 1 0 1 0 0 1 0 0) := run_step (i:=(10:V)) (by norm_num) run10 step10
  have step11 : step (config ((76:Nat):V) 1 (vector 0 1 0 1 0 0 1 0 0)) = config ((73:Nat):V) 1 (vector 0 1 0 1 0 0 1 0 0) := by
    rw [step_at 76 _ (row_of_literal 76 _ (by decide) RawRows.raw0076)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run12 : run (12:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((73:Nat):V) 1 (vector 0 1 0 1 0 0 1 0 0) := run_step (i:=(11:V)) (by norm_num) run11 step11
  have step12 : step (config ((73:Nat):V) 1 (vector 0 1 0 1 0 0 1 0 0)) = config ((74:Nat):V) 1 (vector 0 1 0 0 0 0 1 0 0) := by
    rw [step_at 73 _ (row_of_literal 73 _ (by decide) RawRows.raw0073)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run13 : run (13:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((74:Nat):V) 1 (vector 0 1 0 0 0 0 1 0 0) := run_step (i:=(12:V)) (by norm_num) run12 step12
  have step13 : step (config ((74:Nat):V) 1 (vector 0 1 0 0 0 0 1 0 0)) = config ((75:Nat):V) 1 (vector 0 1 0 0 0 0 2 0 0) := by
    rw [step_at 74 _ (row_of_literal 74 _ (by decide) RawRows.raw0074)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run14 : run (14:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((75:Nat):V) 1 (vector 0 1 0 0 0 0 2 0 0) := run_step (i:=(13:V)) (by norm_num) run13 step13
  have step14 : step (config ((75:Nat):V) 1 (vector 0 1 0 0 0 0 2 0 0)) = config ((76:Nat):V) 1 (vector 0 2 0 0 0 0 2 0 0) := by
    rw [step_at 75 _ (row_of_literal 75 _ (by decide) RawRows.raw0075)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run15 : run (15:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((76:Nat):V) 1 (vector 0 2 0 0 0 0 2 0 0) := run_step (i:=(14:V)) (by norm_num) run14 step14
  have step15 : step (config ((76:Nat):V) 1 (vector 0 2 0 0 0 0 2 0 0)) = config ((73:Nat):V) 1 (vector 0 2 0 0 0 0 2 0 0) := by
    rw [step_at 76 _ (row_of_literal 76 _ (by decide) RawRows.raw0076)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run16 : run (16:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((73:Nat):V) 1 (vector 0 2 0 0 0 0 2 0 0) := run_step (i:=(15:V)) (by norm_num) run15 step15
  have step16 : step (config ((73:Nat):V) 1 (vector 0 2 0 0 0 0 2 0 0)) = config ((77:Nat):V) 1 (vector 0 2 0 0 0 0 2 0 0) := by
    rw [step_at 73 _ (row_of_literal 73 _ (by decide) RawRows.raw0073)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run17 : run (17:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((77:Nat):V) 1 (vector 0 2 0 0 0 0 2 0 0) := run_step (i:=(16:V)) (by norm_num) run16 step16
  have step17 : step (config ((77:Nat):V) 1 (vector 0 2 0 0 0 0 2 0 0)) = config ((78:Nat):V) 1 (vector 0 2 0 0 0 0 1 0 0) := by
    rw [step_at 77 _ (row_of_literal 77 _ (by decide) RawRows.raw0077)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run18 : run (18:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((78:Nat):V) 1 (vector 0 2 0 0 0 0 1 0 0) := run_step (i:=(17:V)) (by norm_num) run17 step17
  have step18 : step (config ((78:Nat):V) 1 (vector 0 2 0 0 0 0 1 0 0)) = config ((79:Nat):V) 1 (vector 0 2 0 1 0 0 1 0 0) := by
    rw [step_at 78 _ (row_of_literal 78 _ (by decide) RawRows.raw0078)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run19 : run (19:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((79:Nat):V) 1 (vector 0 2 0 1 0 0 1 0 0) := run_step (i:=(18:V)) (by norm_num) run18 step18
  have step19 : step (config ((79:Nat):V) 1 (vector 0 2 0 1 0 0 1 0 0)) = config ((77:Nat):V) 1 (vector 0 2 0 1 0 0 1 0 0) := by
    rw [step_at 79 _ (row_of_literal 79 _ (by decide) RawRows.raw0079)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run20 : run (20:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((77:Nat):V) 1 (vector 0 2 0 1 0 0 1 0 0) := run_step (i:=(19:V)) (by norm_num) run19 step19
  have step20 : step (config ((77:Nat):V) 1 (vector 0 2 0 1 0 0 1 0 0)) = config ((78:Nat):V) 1 (vector 0 2 0 1 0 0 0 0 0) := by
    rw [step_at 77 _ (row_of_literal 77 _ (by decide) RawRows.raw0077)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run21 : run (21:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((78:Nat):V) 1 (vector 0 2 0 1 0 0 0 0 0) := run_step (i:=(20:V)) (by norm_num) run20 step20
  have step21 : step (config ((78:Nat):V) 1 (vector 0 2 0 1 0 0 0 0 0)) = config ((79:Nat):V) 1 (vector 0 2 0 2 0 0 0 0 0) := by
    rw [step_at 78 _ (row_of_literal 78 _ (by decide) RawRows.raw0078)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run22 : run (22:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((79:Nat):V) 1 (vector 0 2 0 2 0 0 0 0 0) := run_step (i:=(21:V)) (by norm_num) run21 step21
  have step22 : step (config ((79:Nat):V) 1 (vector 0 2 0 2 0 0 0 0 0)) = config ((77:Nat):V) 1 (vector 0 2 0 2 0 0 0 0 0) := by
    rw [step_at 79 _ (row_of_literal 79 _ (by decide) RawRows.raw0079)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run23 : run (23:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((77:Nat):V) 1 (vector 0 2 0 2 0 0 0 0 0) := run_step (i:=(22:V)) (by norm_num) run22 step22
  have step23 : step (config ((77:Nat):V) 1 (vector 0 2 0 2 0 0 0 0 0)) = config ((80:Nat):V) 1 (vector 0 2 0 2 0 0 0 0 0) := by
    rw [step_at 77 _ (row_of_literal 77 _ (by decide) RawRows.raw0077)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run24 : run (24:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((80:Nat):V) 1 (vector 0 2 0 2 0 0 0 0 0) := run_step (i:=(23:V)) (by norm_num) run23 step23
  have step24 : step (config ((80:Nat):V) 1 (vector 0 2 0 2 0 0 0 0 0)) = config ((81:Nat):V) 1 (vector 0 1 0 2 0 0 0 0 0) := by
    rw [step_at 80 _ (row_of_literal 80 _ (by decide) RawRows.raw0080)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run25 : run (25:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((81:Nat):V) 1 (vector 0 1 0 2 0 0 0 0 0) := run_step (i:=(24:V)) (by norm_num) run24 step24
  have step25 : step (config ((81:Nat):V) 1 (vector 0 1 0 2 0 0 0 0 0)) = config ((82:Nat):V) 1 (vector 0 1 0 2 0 0 1 0 0) := by
    rw [step_at 81 _ (row_of_literal 81 _ (by decide) RawRows.raw0081)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run26 : run (26:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((82:Nat):V) 1 (vector 0 1 0 2 0 0 1 0 0) := run_step (i:=(25:V)) (by norm_num) run25 step25
  have step26 : step (config ((82:Nat):V) 1 (vector 0 1 0 2 0 0 1 0 0)) = config ((80:Nat):V) 1 (vector 0 1 0 2 0 0 1 0 0) := by
    rw [step_at 82 _ (row_of_literal 82 _ (by decide) RawRows.raw0082)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run27 : run (27:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((80:Nat):V) 1 (vector 0 1 0 2 0 0 1 0 0) := run_step (i:=(26:V)) (by norm_num) run26 step26
  have step27 : step (config ((80:Nat):V) 1 (vector 0 1 0 2 0 0 1 0 0)) = config ((81:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0) := by
    rw [step_at 80 _ (row_of_literal 80 _ (by decide) RawRows.raw0080)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run28 : run (28:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((81:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0) := run_step (i:=(27:V)) (by norm_num) run27 step27
  have step28 : step (config ((81:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0)) = config ((82:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 81 _ (row_of_literal 81 _ (by decide) RawRows.raw0081)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run29 : run (29:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((82:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(28:V)) (by norm_num) run28 step28
  have step29 : step (config ((82:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((80:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 82 _ (row_of_literal 82 _ (by decide) RawRows.raw0082)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run30 : run (30:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((80:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(29:V)) (by norm_num) run29 step29
  have step30 : step (config ((80:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((83:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 80 _ (row_of_literal 80 _ (by decide) RawRows.raw0080)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run31 : run (31:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((83:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(30:V)) (by norm_num) run30 step30
  have step31 : step (config ((83:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((86:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 83 _ (row_of_literal 83 _ (by decide) RawRows.raw0083)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run32 : run (32:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((86:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(31:V)) (by norm_num) run31 step31
  have step32 : step (config ((86:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((90:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 86 _ (row_of_literal 86 _ (by decide) RawRows.raw0086)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run33 : run (33:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((90:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(32:V)) (by norm_num) run32 step32
  have step33 : step (config ((90:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((91:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0) := by
    rw [step_at 90 _ (row_of_literal 90 _ (by decide) RawRows.raw0090)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run34 : run (34:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((91:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0) := run_step (i:=(33:V)) (by norm_num) run33 step33
  have step34 : step (config ((91:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0)) = config ((92:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0) := by
    rw [step_at 91 _ (row_of_literal 91 _ (by decide) RawRows.raw0091)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run35 : run (35:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((92:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0) := run_step (i:=(34:V)) (by norm_num) run34 step34
  have step35 : step (config ((92:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0)) = config ((93:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := by
    rw [step_at 92 _ (row_of_literal 92 _ (by decide) RawRows.raw0092)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run36 : run (36:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((93:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := run_step (i:=(35:V)) (by norm_num) run35 step35
  have step36 : step (config ((93:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0)) = config ((94:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := by
    rw [step_at 93 _ (row_of_literal 93 _ (by decide) RawRows.raw0093)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run37 : run (37:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((94:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := run_step (i:=(36:V)) (by norm_num) run36 step36
  have step37 : step (config ((94:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0)) = config ((92:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := by
    rw [step_at 94 _ (row_of_literal 94 _ (by decide) RawRows.raw0094)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run38 : run (38:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((92:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := run_step (i:=(37:V)) (by norm_num) run37 step37
  have step38 : step (config ((92:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0)) = config ((95:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := by
    rw [step_at 92 _ (row_of_literal 92 _ (by decide) RawRows.raw0092)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run39 : run (39:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((95:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := run_step (i:=(38:V)) (by norm_num) run38 step38
  have step39 : step (config ((95:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0)) = config ((86:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := by
    rw [step_at 95 _ (row_of_literal 95 _ (by decide) RawRows.raw0095)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run40 : run (40:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((86:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := run_step (i:=(39:V)) (by norm_num) run39 step39
  have step40 : step (config ((86:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0)) = config ((87:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := by
    rw [step_at 86 _ (row_of_literal 86 _ (by decide) RawRows.raw0086)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run41 : run (41:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((87:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := run_step (i:=(40:V)) (by norm_num) run40 step40
  have step41 : step (config ((87:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0)) = config ((88:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := by
    rw [step_at 87 _ (row_of_literal 87 _ (by decide) RawRows.raw0087)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run42 : run (42:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((88:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := run_step (i:=(41:V)) (by norm_num) run41 step41
  have step42 : step (config ((88:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0)) = config ((89:Nat):V) 1 (vector 0 0 0 2 0 0 1 2 0) := by
    rw [step_at 88 _ (row_of_literal 88 _ (by decide) RawRows.raw0088)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run43 : run (43:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((89:Nat):V) 1 (vector 0 0 0 2 0 0 1 2 0) := run_step (i:=(42:V)) (by norm_num) run42 step42
  have step43 : step (config ((89:Nat):V) 1 (vector 0 0 0 2 0 0 1 2 0)) = config ((86:Nat):V) 1 (vector 0 0 0 2 0 0 1 2 0) := by
    rw [step_at 89 _ (row_of_literal 89 _ (by decide) RawRows.raw0089)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run44 : run (44:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((86:Nat):V) 1 (vector 0 0 0 2 0 0 1 2 0) := run_step (i:=(43:V)) (by norm_num) run43 step43
  have step44 : step (config ((86:Nat):V) 1 (vector 0 0 0 2 0 0 1 2 0)) = config ((90:Nat):V) 1 (vector 0 0 0 2 0 0 1 2 0) := by
    rw [step_at 86 _ (row_of_literal 86 _ (by decide) RawRows.raw0086)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run45 : run (45:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((90:Nat):V) 1 (vector 0 0 0 2 0 0 1 2 0) := run_step (i:=(44:V)) (by norm_num) run44 step44
  have step45 : step (config ((90:Nat):V) 1 (vector 0 0 0 2 0 0 1 2 0)) = config ((91:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := by
    rw [step_at 90 _ (row_of_literal 90 _ (by decide) RawRows.raw0090)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run46 : run (46:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((91:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := run_step (i:=(45:V)) (by norm_num) run45 step45
  have step46 : step (config ((91:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0)) = config ((92:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := by
    rw [step_at 91 _ (row_of_literal 91 _ (by decide) RawRows.raw0091)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run47 : run (47:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((92:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := run_step (i:=(46:V)) (by norm_num) run46 step46
  have step47 : step (config ((92:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0)) = config ((95:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := by
    rw [step_at 92 _ (row_of_literal 92 _ (by decide) RawRows.raw0092)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run48 : run (48:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((95:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := run_step (i:=(47:V)) (by norm_num) run47 step47
  have step48 : step (config ((95:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0)) = config ((86:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := by
    rw [step_at 95 _ (row_of_literal 95 _ (by decide) RawRows.raw0095)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run49 : run (49:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((86:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := run_step (i:=(48:V)) (by norm_num) run48 step48
  have step49 : step (config ((86:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0)) = config ((90:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := by
    rw [step_at 86 _ (row_of_literal 86 _ (by decide) RawRows.raw0086)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run50 : run (50:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((90:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := run_step (i:=(49:V)) (by norm_num) run49 step49
  have step50 : step (config ((90:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0)) = config ((96:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := by
    rw [step_at 90 _ (row_of_literal 90 _ (by decide) RawRows.raw0090)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run51 : run (51:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((96:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0) := run_step (i:=(50:V)) (by norm_num) run50 step50
  have step51 : step (config ((96:Nat):V) 1 (vector 0 0 0 2 0 0 0 3 0)) = config ((97:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := by
    rw [step_at 96 _ (row_of_literal 96 _ (by decide) RawRows.raw0096)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run52 : run (52:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((97:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := run_step (i:=(51:V)) (by norm_num) run51 step51
  have step52 : step (config ((97:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0)) = config ((98:Nat):V) 1 (vector 0 0 1 2 0 0 0 2 0) := by
    rw [step_at 97 _ (row_of_literal 97 _ (by decide) RawRows.raw0097)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run53 : run (53:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((98:Nat):V) 1 (vector 0 0 1 2 0 0 0 2 0) := run_step (i:=(52:V)) (by norm_num) run52 step52
  have step53 : step (config ((98:Nat):V) 1 (vector 0 0 1 2 0 0 0 2 0)) = config ((96:Nat):V) 1 (vector 0 0 1 2 0 0 0 2 0) := by
    rw [step_at 98 _ (row_of_literal 98 _ (by decide) RawRows.raw0098)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run54 : run (54:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((96:Nat):V) 1 (vector 0 0 1 2 0 0 0 2 0) := run_step (i:=(53:V)) (by norm_num) run53 step53
  have step54 : step (config ((96:Nat):V) 1 (vector 0 0 1 2 0 0 0 2 0)) = config ((97:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0) := by
    rw [step_at 96 _ (row_of_literal 96 _ (by decide) RawRows.raw0096)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run55 : run (55:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((97:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0) := run_step (i:=(54:V)) (by norm_num) run54 step54
  have step55 : step (config ((97:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0)) = config ((98:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0) := by
    rw [step_at 97 _ (row_of_literal 97 _ (by decide) RawRows.raw0097)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run56 : run (56:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((98:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0) := run_step (i:=(55:V)) (by norm_num) run55 step55
  have step56 : step (config ((98:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0)) = config ((96:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0) := by
    rw [step_at 98 _ (row_of_literal 98 _ (by decide) RawRows.raw0098)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run57 : run (57:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((96:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0) := run_step (i:=(56:V)) (by norm_num) run56 step56
  have step57 : step (config ((96:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0)) = config ((97:Nat):V) 1 (vector 0 0 2 2 0 0 0 0 0) := by
    rw [step_at 96 _ (row_of_literal 96 _ (by decide) RawRows.raw0096)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run58 : run (58:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((97:Nat):V) 1 (vector 0 0 2 2 0 0 0 0 0) := run_step (i:=(57:V)) (by norm_num) run57 step57
  have step58 : step (config ((97:Nat):V) 1 (vector 0 0 2 2 0 0 0 0 0)) = config ((98:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := by
    rw [step_at 97 _ (row_of_literal 97 _ (by decide) RawRows.raw0097)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run59 : run (59:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((98:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := run_step (i:=(58:V)) (by norm_num) run58 step58
  have step59 : step (config ((98:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0)) = config ((96:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := by
    rw [step_at 98 _ (row_of_literal 98 _ (by decide) RawRows.raw0098)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run60 : run (60:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((96:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := run_step (i:=(59:V)) (by norm_num) run59 step59
  have step60 : step (config ((96:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0)) = config ((99:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := by
    rw [step_at 96 _ (row_of_literal 96 _ (by decide) RawRows.raw0096)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run61 : run (61:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((99:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := run_step (i:=(60:V)) (by norm_num) run60 step60
  have step61 : step (config ((99:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0)) = config ((103:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := by
    rw [step_at 99 _ (row_of_literal 99 _ (by decide) RawRows.raw0099)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run62 : run (62:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((103:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := run_step (i:=(61:V)) (by norm_num) run61 step61
  have step62 : step (config ((103:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0)) = config ((106:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := by
    rw [step_at 103 _ (row_of_literal 103 _ (by decide) RawRows.raw0103)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run63 : run (63:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((106:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0) := run_step (i:=(62:V)) (by norm_num) run62 step62
  have step63 : step (config ((106:Nat):V) 1 (vector 0 0 3 2 0 0 0 0 0)) = config ((107:Nat):V) 1 (vector 0 0 2 2 0 0 0 0 0) := by
    rw [step_at 106 _ (row_of_literal 106 _ (by decide) RawRows.raw0106)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run64 : run (64:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((107:Nat):V) 1 (vector 0 0 2 2 0 0 0 0 0) := run_step (i:=(63:V)) (by norm_num) run63 step63
  have step64 : step (config ((107:Nat):V) 1 (vector 0 0 2 2 0 0 0 0 0)) = config ((108:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0) := by
    rw [step_at 107 _ (row_of_literal 107 _ (by decide) RawRows.raw0107)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run65 : run (65:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((108:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0) := run_step (i:=(64:V)) (by norm_num) run64 step64
  have step65 : step (config ((108:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0)) = config ((110:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0) := by
    rw [step_at 108 _ (row_of_literal 108 _ (by decide) RawRows.raw0108)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run66 : run (66:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((110:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0) := run_step (i:=(65:V)) (by norm_num) run65 step65
  have step66 : step (config ((110:Nat):V) 1 (vector 0 0 2 2 0 0 0 1 0)) = config ((111:Nat):V) 1 (vector 0 0 2 2 0 0 0 0 0) := by
    rw [step_at 110 _ (row_of_literal 110 _ (by decide) RawRows.raw0110)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run67 : run (67:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((111:Nat):V) 1 (vector 0 0 2 2 0 0 0 0 0) := run_step (i:=(66:V)) (by norm_num) run66 step66
  have step67 : step (config ((111:Nat):V) 1 (vector 0 0 2 2 0 0 0 0 0)) = config ((112:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0) := by
    rw [step_at 111 _ (row_of_literal 111 _ (by decide) RawRows.raw0111)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run68 : run (68:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((112:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0) := run_step (i:=(67:V)) (by norm_num) run67 step67
  have step68 : step (config ((112:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0)) = config ((110:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0) := by
    rw [step_at 112 _ (row_of_literal 112 _ (by decide) RawRows.raw0112)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run69 : run (69:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((110:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0) := run_step (i:=(68:V)) (by norm_num) run68 step68
  have step69 : step (config ((110:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0)) = config ((113:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0) := by
    rw [step_at 110 _ (row_of_literal 110 _ (by decide) RawRows.raw0110)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run70 : run (70:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((113:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0) := run_step (i:=(69:V)) (by norm_num) run69 step69
  have step70 : step (config ((113:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0)) = config ((106:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0) := by
    rw [step_at 113 _ (row_of_literal 113 _ (by decide) RawRows.raw0113)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run71 : run (71:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((106:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0) := run_step (i:=(70:V)) (by norm_num) run70 step70
  have step71 : step (config ((106:Nat):V) 1 (vector 0 0 2 2 0 0 1 0 0)) = config ((107:Nat):V) 1 (vector 0 0 1 2 0 0 1 0 0) := by
    rw [step_at 106 _ (row_of_literal 106 _ (by decide) RawRows.raw0106)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run72 : run (72:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((107:Nat):V) 1 (vector 0 0 1 2 0 0 1 0 0) := run_step (i:=(71:V)) (by norm_num) run71 step71
  have step72 : step (config ((107:Nat):V) 1 (vector 0 0 1 2 0 0 1 0 0)) = config ((108:Nat):V) 1 (vector 0 0 1 2 0 0 1 1 0) := by
    rw [step_at 107 _ (row_of_literal 107 _ (by decide) RawRows.raw0107)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run73 : run (73:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((108:Nat):V) 1 (vector 0 0 1 2 0 0 1 1 0) := run_step (i:=(72:V)) (by norm_num) run72 step72
  have step73 : step (config ((108:Nat):V) 1 (vector 0 0 1 2 0 0 1 1 0)) = config ((109:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0) := by
    rw [step_at 108 _ (row_of_literal 108 _ (by decide) RawRows.raw0108)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run74 : run (74:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((109:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0) := run_step (i:=(73:V)) (by norm_num) run73 step73
  have step74 : step (config ((109:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0)) = config ((113:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0) := by
    rw [step_at 109 _ (row_of_literal 109 _ (by decide) RawRows.raw0109)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run75 : run (75:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((113:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0) := run_step (i:=(74:V)) (by norm_num) run74 step74
  have step75 : step (config ((113:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0)) = config ((106:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0) := by
    rw [step_at 113 _ (row_of_literal 113 _ (by decide) RawRows.raw0113)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run76 : run (76:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((106:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0) := run_step (i:=(75:V)) (by norm_num) run75 step75
  have step76 : step (config ((106:Nat):V) 1 (vector 0 0 1 2 0 0 0 1 0)) = config ((107:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := by
    rw [step_at 106 _ (row_of_literal 106 _ (by decide) RawRows.raw0106)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run77 : run (77:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((107:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := run_step (i:=(76:V)) (by norm_num) run76 step76
  have step77 : step (config ((107:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0)) = config ((108:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := by
    rw [step_at 107 _ (row_of_literal 107 _ (by decide) RawRows.raw0107)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run78 : run (78:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((108:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := run_step (i:=(77:V)) (by norm_num) run77 step77
  have step78 : step (config ((108:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0)) = config ((110:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := by
    rw [step_at 108 _ (row_of_literal 108 _ (by decide) RawRows.raw0108)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run79 : run (79:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((110:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0) := run_step (i:=(78:V)) (by norm_num) run78 step78
  have step79 : step (config ((110:Nat):V) 1 (vector 0 0 0 2 0 0 0 2 0)) = config ((111:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := by
    rw [step_at 110 _ (row_of_literal 110 _ (by decide) RawRows.raw0110)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run80 : run (80:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((111:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := run_step (i:=(79:V)) (by norm_num) run79 step79
  have step80 : step (config ((111:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0)) = config ((112:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0) := by
    rw [step_at 111 _ (row_of_literal 111 _ (by decide) RawRows.raw0111)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run81 : run (81:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((112:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0) := run_step (i:=(80:V)) (by norm_num) run80 step80
  have step81 : step (config ((112:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0)) = config ((110:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0) := by
    rw [step_at 112 _ (row_of_literal 112 _ (by decide) RawRows.raw0112)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run82 : run (82:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((110:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0) := run_step (i:=(81:V)) (by norm_num) run81 step81
  have step82 : step (config ((110:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0)) = config ((111:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0) := by
    rw [step_at 110 _ (row_of_literal 110 _ (by decide) RawRows.raw0110)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run83 : run (83:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((111:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0) := run_step (i:=(82:V)) (by norm_num) run82 step82
  have step83 : step (config ((111:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0)) = config ((112:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 111 _ (row_of_literal 111 _ (by decide) RawRows.raw0111)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run84 : run (84:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((112:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(83:V)) (by norm_num) run83 step83
  have step84 : step (config ((112:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((110:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 112 _ (row_of_literal 112 _ (by decide) RawRows.raw0112)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run85 : run (85:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((110:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(84:V)) (by norm_num) run84 step84
  have step85 : step (config ((110:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((113:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 110 _ (row_of_literal 110 _ (by decide) RawRows.raw0110)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run86 : run (86:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((113:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(85:V)) (by norm_num) run85 step85
  have step86 : step (config ((113:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((106:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 113 _ (row_of_literal 113 _ (by decide) RawRows.raw0113)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run87 : run (87:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((106:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(86:V)) (by norm_num) run86 step86
  have step87 : step (config ((106:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((114:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 106 _ (row_of_literal 106 _ (by decide) RawRows.raw0106)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run88 : run (88:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((114:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(87:V)) (by norm_num) run87 step87
  have step88 : step (config ((114:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((117:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 114 _ (row_of_literal 114 _ (by decide) RawRows.raw0114)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run89 : run (89:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((117:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(88:V)) (by norm_num) run88 step88
  have step89 : step (config ((117:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((121:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := by
    rw [step_at 117 _ (row_of_literal 117 _ (by decide) RawRows.raw0117)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run90 : run (90:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((121:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0) := run_step (i:=(89:V)) (by norm_num) run89 step89
  have step90 : step (config ((121:Nat):V) 1 (vector 0 0 0 2 0 0 2 0 0)) = config ((122:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0) := by
    rw [step_at 121 _ (row_of_literal 121 _ (by decide) RawRows.raw0121)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run91 : run (91:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((122:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0) := run_step (i:=(90:V)) (by norm_num) run90 step90
  have step91 : step (config ((122:Nat):V) 1 (vector 0 0 0 2 0 0 1 0 0)) = config ((123:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0) := by
    rw [step_at 122 _ (row_of_literal 122 _ (by decide) RawRows.raw0122)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run92 : run (92:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((123:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0) := run_step (i:=(91:V)) (by norm_num) run91 step91
  have step92 : step (config ((123:Nat):V) 1 (vector 0 0 0 2 0 0 1 1 0)) = config ((124:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := by
    rw [step_at 123 _ (row_of_literal 123 _ (by decide) RawRows.raw0123)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run93 : run (93:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((124:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := run_step (i:=(92:V)) (by norm_num) run92 step92
  have step93 : step (config ((124:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0)) = config ((125:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := by
    rw [step_at 124 _ (row_of_literal 124 _ (by decide) RawRows.raw0124)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run94 : run (94:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((125:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := run_step (i:=(93:V)) (by norm_num) run93 step93
  have step94 : step (config ((125:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0)) = config ((123:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := by
    rw [step_at 125 _ (row_of_literal 125 _ (by decide) RawRows.raw0125)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run95 : run (95:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((123:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := run_step (i:=(94:V)) (by norm_num) run94 step94
  have step95 : step (config ((123:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0)) = config ((126:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := by
    rw [step_at 123 _ (row_of_literal 123 _ (by decide) RawRows.raw0123)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run96 : run (96:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((126:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := run_step (i:=(95:V)) (by norm_num) run95 step95
  have step96 : step (config ((126:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0)) = config ((117:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := by
    rw [step_at 126 _ (row_of_literal 126 _ (by decide) RawRows.raw0126)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run97 : run (97:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((117:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0) := run_step (i:=(96:V)) (by norm_num) run96 step96
  have step97 : step (config ((117:Nat):V) 1 (vector 0 1 0 2 0 0 0 1 0)) = config ((118:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := by
    rw [step_at 117 _ (row_of_literal 117 _ (by decide) RawRows.raw0117)]
    norm_num [decoded,perform,vector,readReg,writeReg,chooseZero, show (2:V)-1=1 by rw [show (2:V) = 1+1 by ring,add_tsub_cancel_right], show (3:V)-1=2 by rw [show (3:V) = 2+1 by ring,add_tsub_cancel_right], show (4:V)-1=3 by rw [show (4:V) = 3+1 by ring,add_tsub_cancel_right]]
  have run98 : run (98:V) (config ((40:Nat):V) 1 (vector 0 0 0 2 0 0 0 0 0)) = config ((118:Nat):V) 1 (vector 0 0 0 2 0 0 0 1 0) := run_step (i:=(97:V)) (by norm_num) run97 step97
  exact run98
end NF185PA.Boot
#print axioms NF185PA.Boot.rawPrefix98
