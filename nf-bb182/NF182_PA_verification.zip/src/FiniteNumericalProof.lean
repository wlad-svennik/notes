module
public import LiteralArithmetic
public import ProofSupport
public import CodedNumerals

/-! A finite internally ranked proof certificate for the actual nine numerical
axiom families and MP. Each node has a rank; both premises of an MP node have
smaller ranks. Pools and ranks are elements of the arithmetic model. -/
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Numerals.FoundationRoute
open SetTheory.BusyBeaver.ZFC

namespace PA192.Literal.ProofPool

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

def Line (ctx pool k p : V) : Prop :=
  Ax p ∨ p∈ctx ∨ ∃ a j l, j<k ∧ l<k ∧ ⟪j,imp a p⟫∈pool ∧ ⟪l,a⟫∈pool

def Valid (ctx pool : V) : Prop := ∀ k p, ⟪k,p⟫∈pool → Line ctx pool k p
def Pr (ctx p : V) : Prop := ∃ pool k, Valid ctx pool ∧ ⟪k,p⟫∈pool

instance lineDef : Language.DefinableRel₄ ℒₒᵣ (Line (V:=V)) := by unfold Line; definability
instance validDef : Language.DefinableRel ℒₒᵣ (Valid (V:=V)) := by unfold Valid; definability
instance provDef : Language.DefinableRel ℒₒᵣ (Pr (V:=V)) := by unfold Pr; definability

theorem line_mono {s t p q k a : V} (st : s⊆t) (pq : p⊆q)
    (h : Line s p k a) : Line t q k a := by
  rcases h with ax | hh | ⟨b,j,l,hj,hl,hm,ha⟩
  · exact Or.inl ax
  · exact Or.inr (Or.inl (st hh))
  · exact Or.inr (Or.inr ⟨b,j,l,hj,hl,pq hm,pq ha⟩)

theorem mono {s t a : V} (st : s⊆t) (h : Pr s a) : Pr t a := by
  obtain ⟨pool,k,hp,hk⟩ := h
  exact ⟨pool,k,fun j f hf => line_mono st (fun _ hx => hx) (hp j f hf),hk⟩

theorem leaf {s a : V} (h : Ax a ∨ a∈s) : Pr s a := by
  refine ⟨{⟪0,a⟫},0,?_,by simp⟩
  intro j p hp
  have he : j=0 ∧ p=a := by simpa using hp
  rw [he.2]
  rcases h with h | h
  · exact Or.inl h
  · exact Or.inr (Or.inl h)

theorem mp {s a b : V} (hmaj : Pr s (imp a b)) (hmin : Pr s a) : Pr s b := by
  obtain ⟨pool,j,hp,hj⟩ := hmaj
  obtain ⟨other,l,ho,hl⟩ := hmin
  let r := max j l+1
  let united : V := insert ⟪r,b⟫ (pool ∪ other)
  have ps : pool⊆united := by intro x hx; simp [united,hx]
  have os : other⊆united := by intro x hx; simp [united,hx]
  refine ⟨united,r,?_,by simp [united]⟩
  intro k p h
  rcases mem_bitInsert_iff.mp h with e | old
  · obtain ⟨rfl,rfl⟩ := pair_ext_iff.mp e
    exact Or.inr (Or.inr ⟨a,j,l,lt_succ_iff_le.mpr (le_max_left j l),
      lt_succ_iff_le.mpr (le_max_right j l),ps hj,os hl⟩)
  · rcases mem_cup_iff.mp old with h₁ | h₂
    · exact line_mono (fun _ hx => hx) ps (hp k p h₁)
    · exact line_mono (fun _ hx => hx) os (ho k p h₂)

theorem restrictedPr (s : V) : DominatedImplication.Restricted domin (Pr s) :=
  restricted (fun _ h => leaf (Or.inl h)) mp

theorem weaken {s a : V} (q : V) (ha : Pr s a) : Pr s (imp q a) :=
  mp (DominatedImplication.k (restrictedPr s) a q) ha

theorem refl (s a : V) : Pr s (imp a a) :=
  mp (mp (DominatedImplication.s (restrictedPr s) a (imp a a) a)
       (DominatedImplication.k (restrictedPr s) a (imp a a))) (DominatedImplication.k (restrictedPr s) a a)

theorem deduction {s a b : V} (h : Pr (insert a s) b) : Pr s (imp a b) := by
  obtain ⟨pool,k,hp,hk⟩ := h
  have trans : ∀ n : V, ∀ j<n, ∀ p, ⟪j,p⟫∈pool → Pr s (imp a p) := by
    apply induction_of_arith
    · apply arithPred_of_definable
      definability
    · intro j hj
      change j<0 at hj
      exact False.elim ((not_lt_of_ge (show (0:V)≤j from zero_le)) hj)
    · intro n ih j hj p elem
      rcases lt_or_eq_of_le (lt_succ_iff_le.mp hj) with jl | rfl
      · exact ih _ jl _ elem
      · rcases hp j p elem with ax | hh | ⟨c,k,l,hk,hl,h1,h2⟩
        · exact weaken _ (leaf (Or.inl ax))
        · rcases mem_bitInsert_iff.mp hh with rfl | hh
          · exact refl _ _
          · exact weaken _ (leaf (Or.inr hh))
        · exact mp (mp (DominatedImplication.s (restrictedPr s) a c p) (ih k hk _ h1))
            (ih l hl _ h2)
  exact trans (k+1) k (by simp) b hk

/-- The conclusion of every internally coded finite proof satisfies any
definable predicate closed under its local rules. This can connect the ranked
format directly to a tree-proof checker or a coded successful command word. -/
theorem realize {s b : V} {R : V → Prop} [Language.DefinablePred ℒₒᵣ R]
    (ha : ∀ p, Ax p → R p) (hh : ∀ p, p∈s → R p)
    (hmp : ∀ a p, R (imp a p) → R a → R p) (h : Pr s b) : R b := by
  obtain ⟨pool,k,hp,hk⟩ := h
  have trans : ∀ n : V, ∀ j<n, ∀ p, ⟪j,p⟫∈pool → R p := by
    apply induction_of_arith
    · apply arithPred_of_definable
      definability
    · intro j hj
      change j<0 at hj
      exact False.elim ((not_lt_of_ge (show (0:V)≤j from zero_le)) hj)
    · intro n ih j hj p elem
      rcases lt_or_eq_of_le (lt_succ_iff_le.mp hj) with jl | rfl
      · exact ih _ jl _ elem
      · rcases hp j p elem with ax | hyp | ⟨a,k,l,hk,hl,h1,h2⟩
        · exact ha _ ax
        · exact hh _ hyp
        · exact hmp _ _ (ih k hk _ h1) (ih l hl _ h2)
  exact trans (k+1) k (by simp) b hk

end PA192.Literal.ProofPool

#print axioms PA192.Literal.ProofPool.deduction
#print axioms PA192.Literal.ProofPool.realize
