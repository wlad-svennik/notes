module
public import FoundationNumerals
import Mathlib.Tactic.Ring
public import NumericalCodes
public import DominatedImplication
public import GroundRows

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace PA192.Literal

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- Twice the Cantor pairing needs no division: n(n+1) is always even. -/
def imp (a b : V) : V := (a+b)*(a+b+1)+2*b
def eqn (a b : V) : V := imp a b+1
def app (a b : V) : V := imp a b+1
def witness (a b : V) : V := imp a b+2
def q : V := 0
def s : V := app q q
def bcomb : V := app s q
def goal : V := eqn s q
def konst (x : V) : V := witness x x

@[simp] theorem s_one : (s : V)=1 := by simp [s,app,imp,q]
@[simp] theorem b_three : (bcomb : V)=3 := by simp [bcomb,app,imp,q]; norm_num
@[simp] theorem goal_three : (goal : V)=3 := by simp [goal,eqn,imp,q]; norm_num

theorem imp_ge_left (a b : V) : a≤imp a b := by
  unfold imp
  rw [mul_add,mul_one]
  calc
    a ≤ a+b := by simp
    _ ≤ (a+b)*(a+b)+(a+b) := by simp
    _ ≤ _ := by simp
theorem imp_ge_right (a b : V) : b≤imp a b := by
  unfold imp
  rw [mul_add,mul_one]
  calc
    b ≤ a+b := by simp
    _ ≤ (a+b)*(a+b)+(a+b) := by simp
    _ ≤ _ := by simp

instance defImp : Language.DefinableFunction₂ ℒₒᵣ (imp : V → V → V) := by
  unfold imp; definability
instance defEqn : Language.DefinableFunction₂ ℒₒᵣ (eqn : V → V → V) := by
  unfold eqn; definability
instance defApp : Language.DefinableFunction₂ ℒₒᵣ (app : V → V → V) := by
  unfold app; definability
instance defWitness : Language.DefinableFunction₂ ℒₒᵣ (witness : V → V → V) := by
  unfold witness; definability
instance defKonst : Language.DefinableFunction₁ ℒₒᵣ (konst : V → V) := by
  unfold konst; definability

def row0 (a b c u : V) := imp (imp (imp c u) a) (imp (imp a c) (imp b c))
def row1 (a b : V) := imp (eqn (app a b) b) (eqn s (app (app q a) b))
def row2 (a b c : V) := imp (eqn c b) (eqn (app a c) (app a b))
def row3 (a b : V) := eqn (app (konst b) a) b
def row4 (a b c : V) := imp (eqn a c) (eqn (app c b) (app a b))
def row5 (a b c : V) := eqn (app (app (app bcomb c) a) b) (app (app c (konst b)) (app a b))
def row6 (a b c : V) := imp (eqn a b) (imp (eqn a c) (eqn c b))
def row7 (a b : V) := imp (imp (eqn (app a b) b) goal) (eqn bcomb (app (app q a) b))
def row8 (a b : V) := imp (eqn (app b (witness a b)) (app a (witness a b))) (eqn a b)

def Ax (p : V) : Prop :=
  (∃ a b c u, ¬a<u ∧ p=row0 a b c u) ∨
  (∃ a b, p=row1 a b) ∨ (∃ a b c,p=row2 a b c) ∨ (∃ a b,p=row3 a b) ∨
  (∃ a b c,p=row4 a b c) ∨ (∃ a b c,p=row5 a b c) ∨ (∃ a b c,p=row6 a b c) ∨
  (∃ a b,p=row7 a b) ∨ (∃ a b,p=row8 a b)

instance defAx : Language.DefinablePred ℒₒᵣ (Ax (V:=V)) := by
  unfold Ax row0 row1 row2 row3 row4 row5 row6 row7 row8
  definability

open SetTheory.BusyBeaver.ZFC
def domin : DominatedImplication.Language V where
  imp := imp
  below := (· ≤ ·)
  refl := le_refl
  grow_left := fun y h => le_trans h (imp_ge_left _ y)
  grow_right := fun x h => le_trans h (imp_ge_right x _)

theorem restricted {P : V → Prop} (ax : ∀ p, Ax p → P p)
    (mp : ∀ {a b}, P (imp a b) → P a → P b) :
    DominatedImplication.Restricted domin P where
  mp := mp
  rho8 := fun a b c u hu => ax _ (Or.inl ⟨a,b,c,u,not_lt_of_ge hu,rfl⟩)

theorem rows_of_valuation (H : V → Prop) (impIff : ∀ a b,H (imp a b) ↔ (H a → H b))
    (valid : ∀ p, Ax p → H p) :
    NF192.Ground.Rows (X:=V) ⟨q,app,witness⟩ (fun x y => H (eqn x y)) := by
  constructor
  · intro a b; apply (impIff _ _).mp
    exact valid _ (Or.inr (Or.inl ⟨a,b,rfl⟩))
  · intro a b c; apply (impIff _ _).mp
    exact valid _ (Or.inr (Or.inr (Or.inl ⟨a,b,c,rfl⟩)))
  · intro a b; exact valid _ (Or.inr (Or.inr (Or.inr (Or.inl ⟨a,b,rfl⟩))))
  · intro a b c; apply (impIff _ _).mp
    exact valid _ (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨a,b,c,rfl⟩)))))
  · intro a b c
    exact valid _ (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨a,b,c,rfl⟩))))))
  · intro a b c h1 h2
    have h : H (row6 a b c) :=
      valid _ (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨a,b,c,rfl⟩)))))))
    exact (impIff _ _).mp ((impIff _ _).mp h h1) h2
  · intro a b h
    have hh : H (row7 a b) :=
      valid _ (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨a,b,rfl⟩))))))))
    exact (impIff _ _).mp hh ((impIff _ _).mpr h)
  · intro a b; apply (impIff _ _).mp
    exact valid _ (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨a,b,rfl⟩))))))))

theorem double_triangle (n : Nat) : 2 * NF192.Numerical.Cantor.triangle n = n*(n+1) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [NF192.Numerical.Cantor.triangle_succ]
    calc
      _ = 2 * NF192.Numerical.Cantor.triangle n + 2*n+2 := by ring
      _ = _ := by rw [ih]; ring

theorem literal_imp (a b : Nat) : imp a b = NF192.Numerical.imp a b := by
  unfold imp NF192.Numerical.imp
  rw [NF192.Numerical.Cantor.pair_eq,
    Nat.mul_add 2 (NF192.Numerical.Cantor.triangle (a+b)) b,double_triangle]
  rfl

theorem literal_eqn (a b : Nat) : eqn a b = NF192.Numerical.eqn a b :=
  congrArg (·+1) (literal_imp a b)
theorem literal_app (a b : Nat) : app a b = NF192.Numerical.app a b :=
  congrArg (·+1) (literal_imp a b)
theorem literal_witness (a b : Nat) : witness a b = NF192.Numerical.witness a b :=
  congrArg (·+2) (literal_imp a b)

end PA192.Literal

#print axioms PA192.Literal.rows_of_valuation
#print axioms PA192.Literal.literal_imp
