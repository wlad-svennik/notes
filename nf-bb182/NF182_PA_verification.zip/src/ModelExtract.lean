module
public import ModelCompiler

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxHeartbeats 3000000
set_option maxRecDepth 32000
namespace PA192.ModelSearch.Compiler
open RegisterFields RegisterCommands Words
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

noncomputable def literal (xs : List V) : V := xs.foldr cons 0
@[simp] theorem lit_nil : literal ([] : List V)=0 := rfl
@[simp] theorem lit_cons (x : V) (xs : List V) : literal (x :: xs)=cons x (literal xs) := rfl

/-- Standard finite macros are interpreted in every arithmetic model. -/
theorem unfold_nips (m : Nat) (s : V) : run exec (nips (m:V)) s =
    run exec (literal (List.replicate m nip)) s := by
  induction m generalizing s with
  | zero => simp
  | succ n ih => simp [Nat.cast_succ,nips_succ,List.replicate_succ,ih]

theorem strip_seven (a b c u t bottom h : V) : run exec (nips 7)
    (state t (front7 a b c u bottom) h 0) = state t bottom (row0 a b c u) 0 := by
  rw [show nips (7:V) = nips ((7:Nat):V) from rfl,unfold_nips]
  simp [List.replicate_succ,front7]

theorem strip_nine (a b c u t bottom h : V) : run exec (nips 9)
    (state t (front9 a b c u bottom) h 0) = state t bottom (row0 a b c u) 0 := by
  rw [show nips (9:V) = nips ((9:Nat):V) from rfl,unfold_nips]
  simp [List.replicate_succ,front9,front7]

theorem strip_higher : ∀ j : V, ∀ bottom t h, ∃ x,
    run exec (nips (9*j)) (state t (higher j bottom) h 0) = state t bottom x 0 := by
  apply modelInduct
  · unfold state; definability
  · intro bottom t h; exact ⟨h,by simp⟩
  · intro j ih bottom t h
    rw [mul_add,mul_one,nip_add,higher_succ]
    obtain ⟨x,hx⟩ := ih (front9 0 0 (j+1) 0 bottom) t h
    rw [hx,strip_nine]
    exact ⟨_,rfl⟩

theorem strip_extra (j bottom t h : V) : ∃ x, run exec (nips (7+9*j))
    (state t (extraFront j bottom) h 0) = state t bottom x 0 := by
  rw [nip_add,extraFront,strip_seven]
  exact strip_higher .. 

noncomputable def reset : V := literal [blank,nip,nip,nip,nip,nip,nip,nip,cmdMP 0]
noncomputable def recover : V := literal [blank,nip,nip,nip,nip,nip,nip,nip,nip,swap]

@[simp] theorem reset_run (t s h p : V) : run exec reset (state t s h p) = state 0 (cantor t s) 0 0 := by
  simp [reset,front7,mp_state]
@[simp] theorem recover_run (t s h p : V) : run exec recover (state t s h p) =
    state t s (row8 p h) 0 := by simp [recover,front7]

def Produces (w x : V) : Prop := ∀ t s h p, ∃ z, run exec w (state t s h p) = state x (cantor t s) z 0
instance producesDef : Language.DefinableRel ℒₒᵣ (Produces (V:=V)) := by unfold Produces state; definability
def Obtainable (x : V) : Prop := ∃ w : V, Produces w x
instance obtainableDef : Language.DefinablePred ℒₒᵣ (Obtainable (V:=V)) := by unfold Obtainable; definability

theorem produces_mp {a b m M : V} (hm : Produces m a) (hM : Produces M (imp a b)) :
    Produces (append m (append M (append (literal [nip,swap,cmdMP b]) recover))) b := by
  intro t s h p
  obtain ⟨z,hz⟩ := hm t s h p
  obtain ⟨Z,hZ⟩ := hM a (cantor t s) z 0
  simp only [run_append,hz,hZ,lit_nil,lit_cons,run_cons,run_zero,nip_packed,swap_packed,
    left_cantor,right_cantor,exec_mp,mp_state,zero_add,if_true,recover_run]
  exact ⟨_,rfl⟩


theorem get_0_zero (u b d : V) : Obtainable (row0 (u+d) b 0 u) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,nip,nip,nip,nip,swap,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_0_pos (u b d j : V) : Obtainable (row0 (u+d) b (j+1) u) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (7+9*j)) (literal [nip,nip,nip,nip,nip,nip,nip,nip,nip,swap,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]

  obtain ⟨x,hx⟩ := strip_extra j _ _ _
  rw [hx]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_1_zero (u b d : V) : Obtainable (row1 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,nip,nip,nip,swap,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_1_pos (u b d j : V) : Obtainable (row1 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (7+9*j)) (literal [nip,nip,nip,nip,nip,nip,nip,nip,swap,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]

  obtain ⟨x,hx⟩ := strip_extra j _ _ _
  rw [hx]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_2_zero (u b d : V) : Obtainable (row2 (u+d) b 0) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,nip,nip,swap,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_2_pos (u b d j : V) : Obtainable (row2 (u+d) b (j+1)) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (7+9*j)) (literal [nip,nip,nip,nip,nip,nip,nip,swap,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]

  obtain ⟨x,hx⟩ := strip_extra j _ _ _
  rw [hx]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_3_zero (u b d : V) : Obtainable (row3 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,nip,swap,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_3_pos (u b d j : V) : Obtainable (row3 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (7+9*j)) (literal [nip,nip,nip,nip,nip,nip,swap,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]

  obtain ⟨x,hx⟩ := strip_extra j _ _ _
  rw [hx]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_4_zero (u b d : V) : Obtainable (row4 (u+d) b 0) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,swap,nip,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_4_pos (u b d j : V) : Obtainable (row4 (u+d) b (j+1)) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (7+9*j)) (literal [nip,nip,nip,nip,nip,swap,nip,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]

  obtain ⟨x,hx⟩ := strip_extra j _ _ _
  rw [hx]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_5_zero (u b d : V) : Obtainable (row5 (u+d) b 0) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,swap,nip,nip,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_5_pos (u b d j : V) : Obtainable (row5 (u+d) b (j+1)) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (7+9*j)) (literal [nip,nip,nip,nip,swap,nip,nip,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]

  obtain ⟨x,hx⟩ := strip_extra j _ _ _
  rw [hx]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_6_zero (u b d : V) : Obtainable (row6 (u+d) b 0) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,swap,nip,nip,nip,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_6_pos (u b d j : V) : Obtainable (row6 (u+d) b (j+1)) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (7+9*j)) (literal [nip,nip,nip,swap,nip,nip,nip,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]

  obtain ⟨x,hx⟩ := strip_extra j _ _ _
  rw [hx]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_7_zero (u b d : V) : Obtainable (row7 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [swap,nip,nip,nip,nip,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_7_pos (u b d j : V) : Obtainable (row7 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (7+9*j)) (literal [nip,nip,swap,nip,nip,nip,nip,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]

  obtain ⟨x,hx⟩ := strip_extra j _ _ _
  rw [hx]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_8_zero (u b d : V) : Obtainable (row8 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,nip,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front9,front7]⟩

theorem get_8_pos (u b d j : V) : Obtainable (row8 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (7+9*j)) (literal [nip,swap,nip,nip,nip,nip,nip,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]

  obtain ⟨x,hx⟩ := strip_extra j _ _ _
  rw [hx]
  exact ⟨0,by simp [front9,front7]⟩

end PA192.ModelSearch.Compiler
#print axioms PA192.ModelSearch.Compiler.get_8_pos
