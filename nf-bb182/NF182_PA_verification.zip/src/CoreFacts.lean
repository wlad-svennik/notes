import NativeFacts
namespace NF192.Direct
universe u
variable {V : Type u}

def Tri (mem : V → V → Prop) (G x y z : V) :=
  ∃ l r t, Ordered mem x y l ∧ Ordered mem z z r ∧ Ordered mem l r t ∧ mem t G

def Fn1 (N : V → Prop) (f : V → V → Prop) :=
  ∀ x, N x → ∃ y,N y ∧ f x y ∧ ∀ w,N w → f x w → w=y
def Fn2 (N : V → Prop) (f : V → V → V → Prop) :=
  ∀ x y, N x ∧ N y → ∃ z,N z ∧ f x y z ∧ ∀ w,N w → f x y w → w=z

def CoreAt (mem : V → V → Prop) (D z S A M P : V) : Prop :=
  let N := fun x => mem x D
  let s := Edge mem S; let a := Tri mem A; let m := Tri mem M; let p := Tri mem P
  N z ∧ Fn1 N s ∧ Fn2 N a ∧ Fn2 N m ∧ Fn2 N p ∧
  (∀x y v w t, N x ∧ N y ∧ N v ∧ N w ∧ N t → p x y t ∧ p v w t → x=v ∧ y=w) ∧
  (∀x, N x → ¬ s x z) ∧
  (∀x y t, N x ∧ N y ∧ N t → s x t ∧ s y t → x=y) ∧
  (∀x, N x → x=z ∨ ∃y,N y ∧ s y x) ∧
  (∀x, N x → a x z x) ∧
  (∀x y sy v sv, N x ∧ N y ∧ N sy ∧ N v ∧ N sv → s y sy ∧ a x y v ∧ s v sv → a x sy sv) ∧
  (∀x, N x → m x z z) ∧
  (∀x y sy t b, N x ∧ N y ∧ N sy ∧ N t ∧ N b → s y sy ∧ m x y t ∧ a t x b → m x sy b) ∧
  (∀ X, mem z X ∧ (∀x y,N x ∧ N y → s x y ∧ mem x X → mem y X) → ∀x,N x → mem x X)

def Core (mem : V → V → Prop) := ∃ D z S A M P, CoreAt mem D z S A M P

theorem func1_of_subtype {N : V → Prop} (f : {n // N n} → {n // N n}) (rel : V → V → Prop)
    (h : ∀ n w, rel n.val w ↔ (f n).val=w) : Fn1 N rel := by
  intro x hx
  let n : {n // N n} := ⟨x,hx⟩
  exact ⟨(f n).val,(f n).property,(h n _).mpr rfl,fun _ _ hw => ((h n _).mp hw).symm⟩

theorem func2_of_subtype {N : V → Prop} (f : {n // N n} → {n // N n} → {n // N n}) (rel : V → V → V → Prop)
    (h : ∀ n m w, rel n.val m.val w ↔ (f n m).val=w) : Fn2 N rel := by
  intro x y ⟨hx,hy⟩
  let n : {n // N n} := ⟨x,hx⟩;let m : {n // N n} := ⟨y,hy⟩
  exact ⟨(f n m).val,(f n m).property,(h n m _).mpr rfl,fun _ _ hw => ((h n m _).mp hw).symm⟩
end NF192.Direct
