module
public import NumericalBound

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM

namespace PA192.BusyBeaver

/-- Each exact-value sentence says that this numeral is the least upper bound. -/
noncomputable def value (n : Nat) : Nat → ArithmeticSentence
  | 0 => upper n 0
  | k+1 => (upper n (k+1)) ⋏ ∼(upper n k)

def StdBound (n k : Nat) : Prop := ∀ (m : Machine n) (q : Fin n), Halts m q →
  ∃ j≤k, (NF210.TM.run m j (NF210.TM.blank q)).state=none

theorem bound_mono {n a b : Nat} (ab : a≤b) (ha : StdBound n a) : StdBound n b := by
  intro m q h
  obtain ⟨j,ja,hj⟩ := ha m q h
  exact ⟨j,ja.trans ab,hj⟩

theorem value_standard (n k : Nat) : (Nat ⊧/![] (value n k)) ↔
    StdBound n k ∧ ∀ j<k, ¬StdBound n j := by
  cases k with
  | zero =>
    simp only [value,busy_beaver_standard]
    exact ⟨fun h => ⟨h,fun _ less => (Nat.not_lt_zero _ less).elim⟩,fun h => h.1⟩
  | succ k =>
    simp only [value,LogicalConnective.HomClass.map_and,LogicalConnective.HomClass.map_neg,busy_beaver_standard]
    change StdBound n (k+1) ∧ ¬StdBound n k ↔ _
    exact ⟨fun ⟨b,h⟩ => ⟨b,fun _ lt b' => h (bound_mono (Nat.le_of_lt_succ lt) b')⟩,
      fun ⟨b,h⟩ => ⟨b,h k (Nat.lt_succ_self k)⟩⟩

theorem value_implies_upper (n k : Nat) : M6.PA.theory ⊢ (value n k) 🡒 upper n k := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  cases k <;> simp [value,models_iff,LogicalConnective.HomClass.map_imply,LogicalConnective.HomClass.map_and] <;> tauto

theorem no_value_of_no_upper {n k : Nat} (noBound : M6.PA.theory ⊬ upper n k) :
    M6.PA.theory ⊬ value n k := fun hp => noBound (value_implies_upper n k ⨀ hp)

end PA192.BusyBeaver
#print axioms PA192.BusyBeaver.value_standard
#print axioms PA192.BusyBeaver.no_value_of_no_upper
