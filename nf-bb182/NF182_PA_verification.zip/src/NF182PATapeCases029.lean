import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w928_0 : checkWitness 928 false false 628 = true := by decide +kernel
private theorem w928_1 : checkWitness 928 false true 4720 = true := by decide +kernel
private theorem w928_2 : checkWitness 928 true false 619 = true := by decide +kernel
private theorem w928_3 : checkWitness 928 true true 4711 = true := by decide +kernel
private theorem cases928 : checkFour 928 (628,4720,619,4711) = true := by
  simp only [checkFour, w928_0, w928_1, w928_2, w928_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one928 : Coverage 928 929 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases928)
private theorem w929_0 : checkWitness 929 false false 8877 = true := by decide +kernel
private theorem w929_2 : checkWitness 929 true false 8873 = true := by decide +kernel
private theorem cases929 : checkFour 929 (8877,0,8873,0) = true := by
  simp only [checkFour, w929_0, w929_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one929 : Coverage 929 930 := checkList_sound (ws:=[(8877,0,8873,0)]) (by simpa only [checkList, Bool.and_true] using cases929)
private theorem w930_0 : checkWitness 930 false false 622 = true := by decide +kernel
private theorem w930_1 : checkWitness 930 false true 4714 = true := by decide +kernel
private theorem w930_2 : checkWitness 930 true false 613 = true := by decide +kernel
private theorem w930_3 : checkWitness 930 true true 4705 = true := by decide +kernel
private theorem cases930 : checkFour 930 (622,4714,613,4705) = true := by
  simp only [checkFour, w930_0, w930_1, w930_2, w930_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one930 : Coverage 930 931 := checkList_sound (ws:=[(622,4714,613,4705)]) (by simpa only [checkList, Bool.and_true] using cases930)
private theorem w931_0 : checkWitness 931 false false 8846 = true := by decide +kernel
private theorem w931_2 : checkWitness 931 true false 8842 = true := by decide +kernel
private theorem cases931 : checkFour 931 (8846,0,8842,0) = true := by
  simp only [checkFour, w931_0, w931_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one931 : Coverage 931 932 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases931)
private theorem w932_0 : checkWitness 932 false false 80 = true := by decide +kernel
private theorem w932_2 : checkWitness 932 true false 80 = true := by decide +kernel
private theorem cases932 : checkFour 932 (80,0,80,0) = true := by
  simp only [checkFour, w932_0, w932_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one932 : Coverage 932 933 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases932)
private theorem w933_0 : checkWitness 933 false false 72 = true := by decide +kernel
private theorem w933_2 : checkWitness 933 true false 72 = true := by decide +kernel
private theorem cases933 : checkFour 933 (72,0,72,0) = true := by
  simp only [checkFour, w933_0, w933_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one933 : Coverage 933 934 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases933)
private theorem w934_0 : checkWitness 934 false false 589 = true := by decide +kernel
private theorem w934_1 : checkWitness 934 false true 4677 = true := by decide +kernel
private theorem w934_2 : checkWitness 934 true false 589 = true := by decide +kernel
private theorem w934_3 : checkWitness 934 true true 4677 = true := by decide +kernel
private theorem cases934 : checkFour 934 (589,4677,589,4677) = true := by
  simp only [checkFour, w934_0, w934_1, w934_2, w934_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one934 : Coverage 934 935 := checkList_sound (ws:=[(589,4677,589,4677)]) (by simpa only [checkList, Bool.and_true] using cases934)
private theorem w935_0 : checkWitness 935 false false 8862 = true := by decide +kernel
private theorem w935_2 : checkWitness 935 true false 8858 = true := by decide +kernel
private theorem cases935 : checkFour 935 (8862,0,8858,0) = true := by
  simp only [checkFour, w935_0, w935_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one935 : Coverage 935 936 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases935)
private theorem w936_0 : checkWitness 936 false false 8858 = true := by decide +kernel
private theorem w936_2 : checkWitness 936 true false 8854 = true := by decide +kernel
private theorem cases936 : checkFour 936 (8858,0,8854,0) = true := by
  simp only [checkFour, w936_0, w936_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one936 : Coverage 936 937 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases936)
private theorem w937_0 : checkWitness 937 false false 86 = true := by decide +kernel
private theorem w937_2 : checkWitness 937 true false 86 = true := by decide +kernel
private theorem cases937 : checkFour 937 (86,0,86,0) = true := by
  simp only [checkFour, w937_0, w937_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one937 : Coverage 937 938 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases937)
private theorem w938_0 : checkWitness 938 false false 8878 = true := by decide +kernel
private theorem w938_2 : checkWitness 938 true false 8874 = true := by decide +kernel
private theorem cases938 : checkFour 938 (8878,0,8874,0) = true := by
  simp only [checkFour, w938_0, w938_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one938 : Coverage 938 939 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases938)
private theorem w939_0 : checkWitness 939 false false 506 = true := by decide +kernel
private theorem w939_1 : checkWitness 939 false true 4602 = true := by decide +kernel
private theorem w939_2 : checkWitness 939 true false 506 = true := by decide +kernel
private theorem w939_3 : checkWitness 939 true true 4602 = true := by decide +kernel
private theorem cases939 : checkFour 939 (506,4602,506,4602) = true := by
  simp only [checkFour, w939_0, w939_1, w939_2, w939_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one939 : Coverage 939 940 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases939)
private theorem w940_0 : checkWitness 940 false false 8928 = true := by decide +kernel
private theorem w940_2 : checkWitness 940 true false 8919 = true := by decide +kernel
private theorem cases940 : checkFour 940 (8928,0,8919,0) = true := by
  simp only [checkFour, w940_0, w940_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one940 : Coverage 940 941 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases940)
private theorem w941_0 : checkWitness 941 false false 72 = true := by decide +kernel
private theorem w941_2 : checkWitness 941 true false 72 = true := by decide +kernel
private theorem cases941 : checkFour 941 (72,0,72,0) = true := by
  simp only [checkFour, w941_0, w941_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one941 : Coverage 941 942 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases941)
private theorem w942_0 : checkWitness 942 false false 510 = true := by decide +kernel
private theorem w942_1 : checkWitness 942 false true 4606 = true := by decide +kernel
private theorem w942_2 : checkWitness 942 true false 510 = true := by decide +kernel
private theorem w942_3 : checkWitness 942 true true 4606 = true := by decide +kernel
private theorem cases942 : checkFour 942 (510,4606,510,4606) = true := by
  simp only [checkFour, w942_0, w942_1, w942_2, w942_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one942 : Coverage 942 943 := checkList_sound (ws:=[(510,4606,510,4606)]) (by simpa only [checkList, Bool.and_true] using cases942)
private theorem w943_0 : checkWitness 943 false false 8868 = true := by decide +kernel
private theorem w943_2 : checkWitness 943 true false 8864 = true := by decide +kernel
private theorem cases943 : checkFour 943 (8868,0,8864,0) = true := by
  simp only [checkFour, w943_0, w943_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one943 : Coverage 943 944 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases943)
private theorem w944_0 : checkWitness 944 false false 74 = true := by decide +kernel
private theorem w944_2 : checkWitness 944 true false 74 = true := by decide +kernel
private theorem cases944 : checkFour 944 (74,0,74,0) = true := by
  simp only [checkFour, w944_0, w944_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one944 : Coverage 944 945 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases944)
private theorem w945_0 : checkWitness 945 false false 554 = true := by decide +kernel
private theorem w945_1 : checkWitness 945 false true 4650 = true := by decide +kernel
private theorem w945_2 : checkWitness 945 true false 554 = true := by decide +kernel
private theorem w945_3 : checkWitness 945 true true 4650 = true := by decide +kernel
private theorem cases945 : checkFour 945 (554,4650,554,4650) = true := by
  simp only [checkFour, w945_0, w945_1, w945_2, w945_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one945 : Coverage 945 946 := checkList_sound (ws:=[(554,4650,554,4650)]) (by simpa only [checkList, Bool.and_true] using cases945)
private theorem w946_0 : checkWitness 946 false false 8889 = true := by decide +kernel
private theorem w946_2 : checkWitness 946 true false 8885 = true := by decide +kernel
private theorem cases946 : checkFour 946 (8889,0,8885,0) = true := by
  simp only [checkFour, w946_0, w946_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one946 : Coverage 946 947 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases946)
private theorem w947_0 : checkWitness 947 false false 8924 = true := by decide +kernel
private theorem w947_2 : checkWitness 947 true false 8915 = true := by decide +kernel
private theorem cases947 : checkFour 947 (8924,0,8915,0) = true := by
  simp only [checkFour, w947_0, w947_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one947 : Coverage 947 948 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases947)
private theorem w948_0 : checkWitness 948 false false 98 = true := by decide +kernel
private theorem w948_2 : checkWitness 948 true false 98 = true := by decide +kernel
private theorem cases948 : checkFour 948 (98,0,98,0) = true := by
  simp only [checkFour, w948_0, w948_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one948 : Coverage 948 949 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases948)
private theorem w949_0 : checkWitness 949 false false 636 = true := by decide +kernel
private theorem w949_1 : checkWitness 949 false true 4728 = true := by decide +kernel
private theorem w949_2 : checkWitness 949 true false 627 = true := by decide +kernel
private theorem w949_3 : checkWitness 949 true true 4719 = true := by decide +kernel
private theorem cases949 : checkFour 949 (636,4728,627,4719) = true := by
  simp only [checkFour, w949_0, w949_1, w949_2, w949_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one949 : Coverage 949 950 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases949)
private theorem w950_0 : checkWitness 950 false false 8885 = true := by decide +kernel
private theorem w950_2 : checkWitness 950 true false 8881 = true := by decide +kernel
private theorem cases950 : checkFour 950 (8885,0,8881,0) = true := by
  simp only [checkFour, w950_0, w950_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one950 : Coverage 950 951 := checkList_sound (ws:=[(8885,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases950)
private theorem w951_0 : checkWitness 951 false false 630 = true := by decide +kernel
private theorem w951_1 : checkWitness 951 false true 4722 = true := by decide +kernel
private theorem w951_2 : checkWitness 951 true false 621 = true := by decide +kernel
private theorem w951_3 : checkWitness 951 true true 4713 = true := by decide +kernel
private theorem cases951 : checkFour 951 (630,4722,621,4713) = true := by
  simp only [checkFour, w951_0, w951_1, w951_2, w951_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one951 : Coverage 951 952 := checkList_sound (ws:=[(630,4722,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases951)
private theorem w952_0 : checkWitness 952 false false 8854 = true := by decide +kernel
private theorem w952_2 : checkWitness 952 true false 8850 = true := by decide +kernel
private theorem cases952 : checkFour 952 (8854,0,8850,0) = true := by
  simp only [checkFour, w952_0, w952_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one952 : Coverage 952 953 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases952)
private theorem w953_0 : checkWitness 953 false false 86 = true := by decide +kernel
private theorem w953_2 : checkWitness 953 true false 86 = true := by decide +kernel
private theorem cases953 : checkFour 953 (86,0,86,0) = true := by
  simp only [checkFour, w953_0, w953_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one953 : Coverage 953 954 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases953)
private theorem w954_0 : checkWitness 954 false false 78 = true := by decide +kernel
private theorem w954_2 : checkWitness 954 true false 78 = true := by decide +kernel
private theorem cases954 : checkFour 954 (78,0,78,0) = true := by
  simp only [checkFour, w954_0, w954_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one954 : Coverage 954 955 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases954)
private theorem w955_0 : checkWitness 955 false false 595 = true := by decide +kernel
private theorem w955_1 : checkWitness 955 false true 4679 = true := by decide +kernel
private theorem w955_2 : checkWitness 955 true false 595 = true := by decide +kernel
private theorem w955_3 : checkWitness 955 true true 4679 = true := by decide +kernel
private theorem cases955 : checkFour 955 (595,4679,595,4679) = true := by
  simp only [checkFour, w955_0, w955_1, w955_2, w955_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one955 : Coverage 955 956 := checkList_sound (ws:=[(595,4679,595,4679)]) (by simpa only [checkList, Bool.and_true] using cases955)
private theorem w956_0 : checkWitness 956 false false 8848 = true := by decide +kernel
private theorem w956_2 : checkWitness 956 true false 8844 = true := by decide +kernel
private theorem cases956 : checkFour 956 (8848,0,8844,0) = true := by
  simp only [checkFour, w956_0, w956_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one956 : Coverage 956 957 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases956)
private theorem w957_0 : checkWitness 957 false false 78 = true := by decide +kernel
private theorem w957_2 : checkWitness 957 true false 78 = true := by decide +kernel
private theorem cases957 : checkFour 957 (78,0,78,0) = true := by
  simp only [checkFour, w957_0, w957_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one957 : Coverage 957 958 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases957)
private theorem w958_0 : checkWitness 958 false false 563 = true := by decide +kernel
private theorem w958_1 : checkWitness 958 false true 4659 = true := by decide +kernel
private theorem w958_2 : checkWitness 958 true false 563 = true := by decide +kernel
private theorem w958_3 : checkWitness 958 true true 4659 = true := by decide +kernel
private theorem cases958 : checkFour 958 (563,4659,563,4659) = true := by
  simp only [checkFour, w958_0, w958_1, w958_2, w958_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one958 : Coverage 958 959 := checkList_sound (ws:=[(563,4659,563,4659)]) (by simpa only [checkList, Bool.and_true] using cases958)
private theorem w959_0 : checkWitness 959 false false 8916 = true := by decide +kernel
private theorem w959_2 : checkWitness 959 true false 8907 = true := by decide +kernel
private theorem cases959 : checkFour 959 (8916,0,8907,0) = true := by
  simp only [checkFour, w959_0, w959_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one959 : Coverage 959 960 := checkList_sound (ws:=[(8916,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases959)
theorem cover0928 : Coverage 928 960 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one928 one929) (Coverage.join one930 one931)) (Coverage.join (Coverage.join one932 one933) (Coverage.join one934 one935))) (Coverage.join (Coverage.join (Coverage.join one936 one937) (Coverage.join one938 one939)) (Coverage.join (Coverage.join one940 one941) (Coverage.join one942 one943)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one944 one945) (Coverage.join one946 one947)) (Coverage.join (Coverage.join one948 one949) (Coverage.join one950 one951))) (Coverage.join (Coverage.join (Coverage.join one952 one953) (Coverage.join one954 one955)) (Coverage.join (Coverage.join one956 one957) (Coverage.join one958 one959)))))
end NF182PA.Symbolic
