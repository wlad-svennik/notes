import NF182PAPresentation
import JensenArithmeticSeed
import BridgeSemantics

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Ground NF192.Direct NF192.Direct.Baseline
open FFL.FirstOrder.NF192Rows

namespace NF182PA.Chart

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
variable {S : Signature V} {E : V → V → Prop}

/-- The presentation supplies truth for the ambient model's own arithmetic
proof predicate. Jensen's theorem is used on the fixed arithmetic seed. -/
theorem truth_of_rows [Language.DefinableRel ℒₒᵣ E]
    [Language.DefinableFunction₂ ℒₒᵣ S.app]
    (R : VariableMarkerNF.Rows S E) (ne : ¬E S.s S.q) :
    Nonempty (PA192.NativeTruth.Truth 𝗣𝗔 V) := by
  obtain ⟨X,mem,n,hT,⟨P⟩⟩ := presented_rows R ne
  letI := mem
  letI := n
  have seed := models_of_provable hT jensen_arithmeticSeed
  exact NF192.Internal.truthOfPresentation P
    ((seed_iff _).mp ((nativeFFL_eval arithmeticSeed Fin.elim0).mp (models_iff.mp seed)))

end NF182PA.Chart
#print axioms NF182PA.Chart.truth_of_rows
