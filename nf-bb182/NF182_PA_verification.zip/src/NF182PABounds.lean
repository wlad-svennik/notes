import NF182PAReplay
import M6PA.Calibration.Foundation
import TrueValue
import ModelStartBound
import NF182Exact

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.LiteralTM PA192.BusyBeaver

namespace NF182PA

/-- The standard direction uses the literal release's external NF calibration. -/
theorem runs_forever_of_con_nf (nf : Consistent 𝗡𝗙) :
    ¬Halts Reduced182.Table.machine Reduced182.Table.start :=
  fun stop => (consistent_iff_unprovable_bot.mp nf) (NFMachine182.halts_iff_nf_refutation.mp stop)

/-- Separately interface to the G2 premise. Its quantifier is object provability. -/
theorem no_negative_of_transfer (transfer : M6.PA.theory ⊢ (∼H182) 🡒 M6.PA.consistencySentence) :
    M6.PA.theory ⊬ ∼H182 :=
  M6.PA.unprovable_of_internal_consistency_implication _ inferInstance transfer

theorem independence_of_transfer (transfer : M6.PA.theory ⊢ (∼H182) 🡒 M6.PA.consistencySentence)
    (nf : Consistent 𝗡𝗙) :
    (M6.PA.theory ⊬ ∼H182) ∧ (M6.PA.theory ⊬ H182) ∧
    ∀ k : Nat, (M6.PA.theory ⊬ upper 182 k) ∧
       (M6.PA.theory ⊬ fixedUpper (0 : Fin 182) k) ∧ (M6.PA.theory ⊬ value 182 k) := by
  have nonhalt := runs_forever_of_con_nf nf
  have neg := no_negative_of_transfer transfer
  refine ⟨neg, ?_, ?_⟩
  · intro proof
    exact nonhalt (H182_standard.mp (models_iff.mp (models_of_provable (M:=Nat) inferInstance proof)))
  · intro k
    have noUpper : M6.PA.theory ⊬ upper 182 k := fun proof =>
      neg (pa_bound_implies_nonhalting k (fun stop => nonhalt ⟨k,stop⟩) ⨀ proof)
    exact ⟨noUpper,fun proof => noUpper (fixed_upper_implies_upper (0 : Fin 182) k ⨀ proof),
      no_value_of_no_upper noUpper⟩

theorem true_value_of_transfer (transfer : M6.PA.theory ⊢ (∼H182) 🡒 M6.PA.consistencySentence)
    (nf : Consistent 𝗡𝗙) :
    ∃ k : Nat, (Nat ⊧/![] (value 182 k)) ∧
      (M6.PA.theory ⊬ value 182 k) ∧ (M6.PA.theory ⊬ ∼(value 182 k)) := by
  obtain ⟨k,actual⟩ := exists_true_value 182
  exact ⟨k,actual,((independence_of_transfer transfer nf).2.2 k).2.2,
    true_value_unrefutable actual⟩

end NF182PA

#print axioms NF182PA.pa_no_halt_through
#print axioms NF182PA.pa_bound_implies_nonhalting
#print axioms NF182PA.pa_live_51157
#print axioms NF182PA.no_negative_of_transfer
#print axioms NF182PA.runs_forever_of_con_nf
#print axioms NF182PA.true_value_of_transfer
