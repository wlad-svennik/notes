import InternalPresentation
import SeedFoundation

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic NF192.Direct
open scoped FFL.FirstOrder.Arithmetic
namespace NF185PA.Comparison
private def idx : Semiterm ℒₛₑₜ Empty n → Fin n
  | #x => x

private theorem idx_val {X : Type} [SetStructure X] (e : Fin n → X)
    (t : Semiterm ℒₛₑₜ Empty n) : t.val e Empty.elim = e (idx t) := by
  cases t with
  | bvar i => rfl
  | fvar i => exact Empty.elim i
  | func f v => exact Empty.elim f

private def atomShape : {k : Nat} → (ℒₛₑₜ).Rel k → (Fin k → Semiterm ℒₛₑₜ Empty n) → SetForm n
  | _, Language.Set.Rel.eq, v => .eq (idx (v 0)) (idx (v 1))
  | _, Language.Set.Rel.mem,v => .mem (idx (v 0)) (idx (v 1))

private def shape : {n : Nat} → Semisentence ℒₛₑₜ n → SetForm n
  | _, ⊤ => .all (.eq 0 0)
  | _, ⊥ => .not (.all (.eq 0 0))
  | _, .rel r v => atomShape r v
  | _, .nrel r v => .not (atomShape r v)
  | _, p ⋏ q => .and (shape p) (shape q)
  | _, p ⋎ q => .or (shape p) (shape q)
  | _, ∀¹ p => .all (shape p)
  | _, ∃¹ p => .ex (shape p)

private theorem shape_iff {X : Type} [SetStructure X] (φ : Semisentence ℒₛₑₜ n) (e : Fin n → X) :
    (X ⊧/e φ) ↔ (shape φ).truth (·∈·) e := by
  induction φ with
  | verum => change True ↔ ∀ x : X, x=x; simp
  | falsum => change False ↔ ¬∀ x : X, x=x; simp
  | rel r v =>
    cases r with
    | eq =>
      change ((v 0).val e Empty.elim = (v 1).val e Empty.elim) ↔ _
      simp only [idx_val,shape,atomShape,SetForm.truth]
    | mem =>
      change ((v 0).val e Empty.elim ∈ (v 1).val e Empty.elim) ↔ _
      simp only [idx_val,shape,atomShape,SetForm.truth]
  | nrel r v =>
    cases r with
    | eq =>
      change (¬ (v 0).val e Empty.elim = (v 1).val e Empty.elim) ↔ _
      simp only [idx_val,shape,atomShape,SetForm.truth]
    | mem =>
      change (¬ (v 0).val e Empty.elim ∈ (v 1).val e Empty.elim) ↔ _
      simp only [idx_val,shape,atomShape,SetForm.truth]
  | and p q hp hq => exact and_congr (hp e) (hq e)
  | or p q hp hq => exact or_congr (hp e) (hq e)
  | all p ih =>
    simp only [Semiformula.Evalb,Semiformula.eval_all,shape,SetForm.truth]
    apply forall_congr';intro x
    have eq : (x :> e) = Fin.cases x e := by funext i;cases i using Fin.cases <;> rfl
    rw [←eq]; exact ih _
  | exs p ih =>
    simp only [Semiformula.Evalb,Semiformula.eval_ex,shape,SetForm.truth]
    apply exists_congr;intro x
    have eq : (x :> e) = Fin.cases x e := by funext i;cases i using Fin.cases <;> rfl
    rw [←eq]; exact ih _

theorem definable_set_eval {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] [SetStructure X]
    (d : NF192.Internal.Presentation V X (·∈·)) (φ : Semisentence ℒₛₑₜ n) :
    Language.Definable ℒₒᵣ (fun e : Fin n → V => X ⊧/(d.dec ∘ e) φ) :=
  (d.formDef (shape φ)).of_iff fun e => shape_iff φ _
end NF185PA.Comparison
#print axioms NF185PA.Comparison.definable_set_eval
