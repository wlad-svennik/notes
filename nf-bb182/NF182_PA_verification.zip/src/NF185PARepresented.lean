import Mathlib.Tactic.FinCases
import InternalChoice
import GroundRows
import NormalizedBasis
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192 NF192.Ground
namespace NF185PA.Comparison
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

def HasOldRows (V : Type) [ORingStructure V] : Prop :=
  ∃ (S : Signature V) (E : V → V → Prop), Language.DefinableFunction₂ ℒₒᵣ S.app ∧
    Language.DefinableFunction₂ ℒₒᵣ S.h ∧ Language.DefinableRel ℒₒᵣ E ∧ Rows S E ∧ ¬ E S.s S.q

theorem pick₂ (C : V → V → V → Prop) [Language.DefinableRel₃ ℒₒᵣ C]
    (existsC : ∀ a b, ∃ y, C y a b) :
    ∃ f : V → V → V, Language.DefinableFunction₂ ℒₒᵣ f ∧ ∀ a b, C (f a b) a b := by
  let R := fun v : Fin (2+1) → V => C (v 0) (v 1) (v 2)
  have df : Language.Definable ℒₒᵣ R := by unfold R; definability
  have ex (v : Fin 2 → V) : ∃ x, R (x :> v) := existsC _ _
  obtain ⟨F,dF,ok⟩ := NF192.Internal.minChoice df ex
  refine ⟨fun a b => F ![a,b],?_,fun a b => ok ![a,b]⟩
  apply Language.Definable.of_iff dF
  intro e
  have he : (fun i : Fin 2 => e i.succ) = ![e 1,e 2] := by funext i;fin_cases i <;> rfl
  change (e 0 = F ![e 1,e 2]) ↔ e 0=F (fun i => e i.succ)
  rw [he]

private theorem witnessRel_def (E : V → V → Prop) (ap : V → V → V)
    [Language.DefinableRel ℒₒᵣ E] [Language.DefinableFunction₂ ℒₒᵣ ap] :
    Language.DefinableRel₃ ℒₒᵣ (fun y a b =>
      (E a b ∧ ∀ c, E (ap y c) a) ∨ (¬E a b ∧ ¬E (ap a y) (ap b y))) := by
  definability

theorem oldRows_of_graph (N : NormalizedBasis X) (π : V → X) (sur : Function.Surjective π)
    (dEq : Language.DefinableRel ℒₒᵣ (fun a b => π a=π b))
    (dApp : Language.DefinableRel₃ ℒₒᵣ (fun y a b => π y=N.app (π a) (π b))) :
    HasOldRows V := by
  let E := fun a b => π a=π b
  letI : Language.DefinableRel ℒₒᵣ E := dEq
  letI := dApp
  obtain ⟨ap,da,A⟩ := pick₂ (fun y a b => π y=N.app (π a) (π b)) (fun a b => sur _)
  letI := da
  let W (y a b : V) := (E a b ∧ ∀ c, E (ap y c) a) ∨ (¬E a b ∧ ¬E (ap a y) (ap b y))
  have dW : Language.DefinableRel₃ ℒₒᵣ W := witnessRel_def E ap
  letI := dW
  have exW (a b : V) : ∃ y, W y a b := by
    by_cases e : E a b
    · obtain ⟨y,hy⟩ := sur (N.K (π a))
      exact ⟨y,Or.inl ⟨e,fun c => (A y c).trans (by rw [hy,N.k_app])⟩⟩
    · have sep : ∃ x, N.app (π a) x≠N.app (π b) x := by
        by_contra! bad
        exact e (N.ext bad)
      obtain ⟨x,hx⟩ := sep
      obtain ⟨y,rfl⟩ := sur x
      exact ⟨y,Or.inr ⟨e,fun h => hx ((A a y).symm.trans (h.trans (A b y)))⟩⟩
  obtain ⟨h,dh,H⟩ := pick₂ W exW
  obtain ⟨q,hq⟩ := sur N.q
  let S : Signature V := ⟨q,ap,h⟩
  have hk (a : V) : π (S.k a)=N.K (π a) := by
    apply N.ext
    intro x
    obtain ⟨c,rfl⟩ := sur x
    have g := H a a
    have p : ∀ c, E (ap (h a a) c) a := g.elim And.right (fun no => (no.1 rfl).elim)
    exact (A _ _).symm.trans ((p c).trans (N.k_app _ _).symm)
  have qs : π S.s=N.K N.B := by
    change π (ap q q)=_
    rw [A,hq,N.qq_eq_kb]
  have qb : π S.b=N.B := by
    change π (ap S.s q)=_
    rw [A,qs,N.k_app]
  have neq : ¬ E S.s S.q := fun he => N.qq_ne_q (N.qq_eq_kb.trans (qs.symm.trans (he.trans hq)))
  refine ⟨S,E,da,dh,dEq,?_,neq⟩
  constructor
  · intro a b fixed
    change π S.s=π (ap (ap q a) b)
    rw [qs,A,A,hq,N.q_true _ _ ((A a b).symm.trans fixed)]
  · intro a b c e
    exact (A _ _).trans ((congrArg (N.app (π a)) e).trans (A _ _).symm)
  · intro a b
    change π (ap (S.k b) a)=_
    rw [A,hk,N.k_app]
  · intro a b c e
    exact (A _ _).trans ((congrArg (fun v => N.app v (π b)) e.symm).trans (A _ _).symm)
  · intro a b c
    change π (ap (ap (ap S.b c) a) b)=π (ap (ap c (S.k b)) (ap a b))
    simp only [A,qb,hk,N.b_app]
  · exact fun _ _ _ ab ac => ac.symm.trans ab
  · intro a b neg
    have nonfix : N.app (π a) (π b)≠π b := fun e => neq (neg ((A _ _).trans e))
    change π S.b=π (ap (ap q a) b)
    rw [qb,A,A,hq,N.q_false _ _ nonfix]
  · intro a b w
    rcases H a b with ⟨e,_⟩|⟨_,ne⟩
    · exact e
    · exact (ne w.symm).elim
end NF185PA.Comparison
#print axioms NF185PA.Comparison.oldRows_of_graph
