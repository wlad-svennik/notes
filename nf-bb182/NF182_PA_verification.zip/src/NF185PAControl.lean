module
public import NF185PAControlCore
public import NF185PACommands
public import Src185CmdRead00
public import Src185CmdRefill00
public import Src185CmdRefillCold00
public import Src185CmdPremise00
public import Src185CmdTake00
public import Src185CmdSave00
public import Src185CmdClear00
public import Src185CmdPop00
public import Src185Loops00
public import Src185Loops11
public import Mathlib.Tactic.Ring
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch.Register185.Certified
open PA192.Literal PA192.ModelSearch.RegisterFields NF185PA.Packed
set_option maxRecDepth 10000
set_option maxHeartbeats 3500000
namespace PA192.ModelSearch.Register185.Commands
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
theorem readFields (f n t s c p h y d w : V) :
    Reach (atS 10 f n t s c p h (cantor y (cantor d w))) (atS 38 f n t s (c+y) (p+d) h w) := by
  simpa only [atS,atom0,atom1,add_comm d p] using commandRead f n t s c p h y d w

/-- The zero and positive buffer guards are the actual instructions at 0 and 1. -/
theorem warmRefill (n e : V) : Reach (vm 0 0 n e 0) (vm 10 0 (n+1) e (n+1)) := by
  have a := site0000Zero (0:V) n (top e) (stack e) 0 (param e) (cache e) 0 0 0
  have b := commandRefill n (top e) (stack e) 0 (param e) (cache e) 0 0 0
  simpa [vm,atS,add_comm (1:V) n] using a.trans b

theorem warmPositive (n e j : V) : Reach (vm 0 0 n e (j+1)) (vm 10 0 n e j) :=
  (site0000Positive 0 n (top e) (stack e) 0 (param e) (cache e) 0 0 j).trans
    (site0001 0 n (top e) (stack e) 0 (param e) (cache e) 0 0 j)

theorem modeRight (f n t s p h w : V) (live : h≠3) :
    Reach (atS 2939 f n t s 0 p h w) (atS 0 f n t (right s) 0 p (left s) w) := by
  have g := site2939 f n t s 0 p h 0 0 w
  simp only [live,ite_false] at g
  have p0 := commandPop f n t s 0 p 0 0 0 w
  exact g.trans p0

theorem modeGuard (f n t s p w : V) :
    sourceHalts (atS 2939 f n t s 0 p 3 w) := by
  have g := site2939 f n t s 0 p 3 0 0 w
  simp only [ite_true] at g
  obtain ⟨k,h⟩ := g
  refine ⟨k,?_⟩
  rw [show run k (atS 2939 f n t s 0 p 3 w) = _ from h,address_config]
  simp

theorem carryHalt {a b : V} (hop : Reach a b) (hit : sourceHalts b) : sourceHalts a := by
  obtain ⟨j,h⟩ := hop; obtain ⟨k,g⟩ := hit
  exact ⟨j+k,by rw [run_add,h,g]⟩

theorem modePrepareZero (f n t s h w : V) :
    Reach (atS 2912 f n t s 0 0 h w) (atS 2939 f n t s 0 0 h w) :=
  site2912Zero f n t s 0 0 h 0 0 w

theorem modePreparePos (f n t s p h w : V) :
    Reach (atS 2912 f n t s 0 (p+1) h w) (atS 2939 f n h (cantor t s) 0 p h w) := by
  exact (site2912Positive f n t s 0 p h 0 0 w).trans (commandSave f n t s 0 p h 0 0 w)

theorem modeHalt (f n t s p w : V) : sourceHalts (atS 2912 f n t s 0 p 3 w) := by
  rcases zeroOrSuccessor p with rfl|⟨j,rfl⟩
  · exact carryHalt (modePrepareZero ..) (modeGuard ..)
  · exact carryHalt (modePreparePos ..) (modeGuard ..)

theorem modeLive (f n t s p h w : V) (live : h≠3) :
    Reach (atS 2912 f n t s 0 p h w)
      (if p=0 then atS 0 f n t (right s) 0 0 (left s) w else atS 0 f n h s 0 (p-1) t w) := by
  rcases zeroOrSuccessor p with rfl|⟨j,rfl⟩
  · simpa using (modePrepareZero f n t s h w).trans (modeRight f n t s 0 h w live)
  · simpa using (modePreparePos f n t s j h w).trans (modeRight f n h (cantor t s) j h w live)

theorem mpTrue (f n s p w : V) : Reach (atS 2899 f n 0 s 0 p 0 w) (atS 2912 f n p s 0 0 0 w) :=
  ((site2899Zero f n 0 s 0 p 0 0 0 w).trans (commandTake f n 0 s 0 p 0 0 0 w)).trans
    (commandClear f n p s 0 p 0 0 0 w)

theorem mpFalse (f n s p j w : V) : Reach (atS 2899 f n 0 s 0 p (j+1) w) (atS 2912 f n 0 s 0 0 0 w) :=
  ((site2899Positive f n 0 s 0 p j 0 0 w).trans (site2900 f n 0 s 0 p j 0 0 w)).trans
    (commandClear f n 0 s 0 p j 0 0 w)

theorem distance_zero_iff (a b : V) : (a-b)+(b-a)=0 ↔ a=b := by
  constructor
  · intro h
    have ll : a-b ≤ (a-b)+(b-a) := le_self_add
    have rr : b-a ≤ (a-b)+(b-a) := le_add_self
    rw [h] at ll rr
    exact le_antisymm (sub_eq_zero_iff_le.mp (le_antisymm ll zero_le)) (sub_eq_zero_iff_le.mp (le_antisymm rr zero_le))
  · rintro rfl; simp

theorem mpBody (f n t s p h w : V) :
    Reach (atS 2838 f n t s 0 p h w) (atS 2912 f n (if h=imp t p then p else 0) s 0 0 0 w) := by
  have ix : cantor t p+cantor t p=imp t p := by rw [←two_mul,twice_cantor]
  have b := commandPremise f n t s 0 p h 0 0 w
  simp only [atom94,ix] at b
  have check := b.trans (site2892 f n 0 s 0 p h (imp t p) 0 w)
  rcases zeroOrSuccessor ((imp t p-h)+(h-imp t p)) with zero|⟨j,positive⟩
  · have eq := (distance_zero_iff _ _).mp zero
    rw [zero] at check
    simpa [eq,atS] using check.trans (mpTrue f n s p w)
  · have ne : h≠imp t p := by
      intro eq
      have zz := (distance_zero_iff (imp t p) h).mpr eq.symm
      rw [zz] at positive
      simpa using positive
    rw [positive] at check
    simpa [ne,atS] using check.trans (mpFalse f n s p j w)

theorem mpAndPop (f n t sp p h w : V) :
    Reach (atS 2838 f n t sp 0 p h w)
      (atS 0 f n (if h=imp t p then p else 0) (right sp) 0 0 (left sp) w) :=
  ((mpBody ..).trans (modePrepareZero ..)).trans (modeRight _ _ _ _ _ _ _ (by simp))

theorem modeTaggedHead (f n t sp p h d w : V) :
    Reach (atS 10 f n t sp 0 p h (cantor 0 (cantor d w))) (atS 2912 f n t sp 0 (p+d) h w) := by
  have r := readFields f n t sp 0 p h 0 d w
  simp only [zero_add] at r
  exact r.trans (site0038Zero f n t sp 0 (p+d) h 0 0 w)

theorem mpTagged (f n t sp p h d w : V) :
    Reach (atS 10 f n t sp 0 p h (cantor 1 (cantor d w)))
      (vm 0 f n (NF185PA.Commands.deduction d (state t sp h p)) w) := by
  have r := readFields f n t sp 0 p h 1 d w
  have first := site0038Positive f n t sp 0 (p+d) h 0 0 w
  have next := site0039Zero f n t sp 0 (p+d) h 0 0 w
  have dest := ((r.trans (by simpa [atS] using first)).trans next).trans (mpAndPop f n t sp (p+d) h w)
  simpa only [NF185PA.Commands.deduction_state,vm_state] using dest

theorem modeTagged (f n t s p h d w : V) (live : h≠3) :
    Reach (atS 10 f n t s 0 p h (cantor 0 (cantor d w))) (vm 0 f n (mode d (state t s h p)) w) := by
  have b := (modeTaggedHead f n t s p h d w).trans (modeLive f n t s (p+d) h w live)
  by_cases he : p+d=0
  · simpa [mode,state,top,stack,cache,param,vm,he] using b
  · simpa [mode,state,top,stack,cache,param,vm,he] using b


end PA192.ModelSearch.Register185.Commands
#print axioms PA192.ModelSearch.Register185.Commands.mpTagged
