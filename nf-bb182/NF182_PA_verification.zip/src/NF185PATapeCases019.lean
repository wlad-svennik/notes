import NF185PATapeBatchCheck
namespace NF185PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w608_0 : checkWitness 608 false false 72 = true := by decide +kernel
private theorem w608_2 : checkWitness 608 true false 72 = true := by decide +kernel
private theorem cases608 : checkFour 608 (72,0,72,0) = true := by
  simp only [checkFour, w608_0, w608_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one608 : Coverage 608 609 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases608)
private theorem w609_0 : checkWitness 609 false false 552 = true := by decide +kernel
private theorem w609_1 : checkWitness 609 false true 4648 = true := by decide +kernel
private theorem w609_2 : checkWitness 609 true false 552 = true := by decide +kernel
private theorem w609_3 : checkWitness 609 true true 4648 = true := by decide +kernel
private theorem cases609 : checkFour 609 (552,4648,552,4648) = true := by
  simp only [checkFour, w609_0, w609_1, w609_2, w609_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one609 : Coverage 609 610 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases609)
private theorem w610_0 : checkWitness 610 false false 8895 = true := by decide +kernel
private theorem w610_2 : checkWitness 610 true false 8891 = true := by decide +kernel
private theorem cases610 : checkFour 610 (8895,0,8891,0) = true := by
  simp only [checkFour, w610_0, w610_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one610 : Coverage 610 611 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases610)
private theorem w611_0 : checkWitness 611 false false 8936 = true := by decide +kernel
private theorem w611_2 : checkWitness 611 true false 8927 = true := by decide +kernel
private theorem cases611 : checkFour 611 (8936,0,8927,0) = true := by
  simp only [checkFour, w611_0, w611_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one611 : Coverage 611 612 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases611)
private theorem w612_0 : checkWitness 612 false false 84 = true := by decide +kernel
private theorem w612_2 : checkWitness 612 true false 84 = true := by decide +kernel
private theorem cases612 : checkFour 612 (84,0,84,0) = true := by
  simp only [checkFour, w612_0, w612_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one612 : Coverage 612 613 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases612)
private theorem w613_0 : checkWitness 613 false false 640 = true := by decide +kernel
private theorem w613_1 : checkWitness 613 false true 4732 = true := by decide +kernel
private theorem w613_2 : checkWitness 613 true false 631 = true := by decide +kernel
private theorem w613_3 : checkWitness 613 true true 4723 = true := by decide +kernel
private theorem cases613 : checkFour 613 (640,4732,631,4723) = true := by
  simp only [checkFour, w613_0, w613_1, w613_2, w613_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one613 : Coverage 613 614 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases613)
private theorem w614_0 : checkWitness 614 false false 8891 = true := by decide +kernel
private theorem w614_2 : checkWitness 614 true false 8887 = true := by decide +kernel
private theorem cases614 : checkFour 614 (8891,0,8887,0) = true := by
  simp only [checkFour, w614_0, w614_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one614 : Coverage 614 615 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases614)
private theorem w615_0 : checkWitness 615 false false 628 = true := by decide +kernel
private theorem w615_1 : checkWitness 615 false true 4720 = true := by decide +kernel
private theorem w615_2 : checkWitness 615 true false 619 = true := by decide +kernel
private theorem w615_3 : checkWitness 615 true true 4711 = true := by decide +kernel
private theorem cases615 : checkFour 615 (628,4720,619,4711) = true := by
  simp only [checkFour, w615_0, w615_1, w615_2, w615_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one615 : Coverage 615 616 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases615)
private theorem w616_0 : checkWitness 616 false false 8858 = true := by decide +kernel
private theorem w616_2 : checkWitness 616 true false 8854 = true := by decide +kernel
private theorem cases616 : checkFour 616 (8858,0,8854,0) = true := by
  simp only [checkFour, w616_0, w616_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one616 : Coverage 616 617 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases616)
private theorem w617_0 : checkWitness 617 false false 84 = true := by decide +kernel
private theorem w617_2 : checkWitness 617 true false 84 = true := by decide +kernel
private theorem cases617 : checkFour 617 (84,0,84,0) = true := by
  simp only [checkFour, w617_0, w617_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one617 : Coverage 617 618 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases617)
private theorem w618_0 : checkWitness 618 false false 78 = true := by decide +kernel
private theorem w618_2 : checkWitness 618 true false 78 = true := by decide +kernel
private theorem cases618 : checkFour 618 (78,0,78,0) = true := by
  simp only [checkFour, w618_0, w618_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one618 : Coverage 618 619 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases618)
private theorem w619_0 : checkWitness 619 false false 589 = true := by decide +kernel
private theorem w619_1 : checkWitness 619 false true 4673 = true := by decide +kernel
private theorem w619_2 : checkWitness 619 true false 589 = true := by decide +kernel
private theorem w619_3 : checkWitness 619 true true 4673 = true := by decide +kernel
private theorem cases619 : checkFour 619 (589,4673,589,4673) = true := by
  simp only [checkFour, w619_0, w619_1, w619_2, w619_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one619 : Coverage 619 620 := checkList_sound (ws:=[(589,4673,589,4673)]) (by simpa only [checkList, Bool.and_true] using cases619)
private theorem w620_0 : checkWitness 620 false false 8858 = true := by decide +kernel
private theorem w620_2 : checkWitness 620 true false 8854 = true := by decide +kernel
private theorem cases620 : checkFour 620 (8858,0,8854,0) = true := by
  simp only [checkFour, w620_0, w620_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one620 : Coverage 620 621 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases620)
private theorem w621_0 : checkWitness 621 false false 76 = true := by decide +kernel
private theorem w621_2 : checkWitness 621 true false 76 = true := by decide +kernel
private theorem cases621 : checkFour 621 (76,0,76,0) = true := by
  simp only [checkFour, w621_0, w621_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one621 : Coverage 621 622 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases621)
private theorem w622_0 : checkWitness 622 false false 586 = true := by decide +kernel
private theorem w622_1 : checkWitness 622 false true 4682 = true := by decide +kernel
private theorem w622_2 : checkWitness 622 true false 586 = true := by decide +kernel
private theorem w622_3 : checkWitness 622 true true 4682 = true := by decide +kernel
private theorem cases622 : checkFour 622 (586,4682,586,4682) = true := by
  simp only [checkFour, w622_0, w622_1, w622_2, w622_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one622 : Coverage 622 623 := checkList_sound (ws:=[(586,4682,586,4682)]) (by simpa only [checkList, Bool.and_true] using cases622)
private theorem w623_0 : checkWitness 623 false false 8922 = true := by decide +kernel
private theorem w623_2 : checkWitness 623 true false 8913 = true := by decide +kernel
private theorem cases623 : checkFour 623 (8922,0,8913,0) = true := by
  simp only [checkFour, w623_0, w623_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one623 : Coverage 623 624 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases623)
private theorem w624_0 : checkWitness 624 false false 8866 = true := by decide +kernel
private theorem w624_2 : checkWitness 624 true false 8862 = true := by decide +kernel
private theorem cases624 : checkFour 624 (8866,0,8862,0) = true := by
  simp only [checkFour, w624_0, w624_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one624 : Coverage 624 625 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases624)
private theorem w625_0 : checkWitness 625 false false 72 = true := by decide +kernel
private theorem w625_2 : checkWitness 625 true false 72 = true := by decide +kernel
private theorem cases625 : checkFour 625 (72,0,72,0) = true := by
  simp only [checkFour, w625_0, w625_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one625 : Coverage 625 626 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases625)
private theorem w626_0 : checkWitness 626 false false 644 = true := by decide +kernel
private theorem w626_1 : checkWitness 626 false true 4732 = true := by decide +kernel
private theorem w626_2 : checkWitness 626 true false 635 = true := by decide +kernel
private theorem w626_3 : checkWitness 626 true true 4723 = true := by decide +kernel
private theorem cases626 : checkFour 626 (644,4732,635,4723) = true := by
  simp only [checkFour, w626_0, w626_1, w626_2, w626_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one626 : Coverage 626 627 := checkList_sound (ws:=[(644,4732,635,4723)]) (by simpa only [checkList, Bool.and_true] using cases626)
private theorem w627_0 : checkWitness 627 false false 8908 = true := by decide +kernel
private theorem w627_2 : checkWitness 627 true false 8904 = true := by decide +kernel
private theorem cases627 : checkFour 627 (8908,0,8904,0) = true := by
  simp only [checkFour, w627_0, w627_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one627 : Coverage 627 628 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases627)
private theorem w628_0 : checkWitness 628 false false 70 = true := by decide +kernel
private theorem w628_2 : checkWitness 628 true false 70 = true := by decide +kernel
private theorem cases628 : checkFour 628 (70,0,70,0) = true := by
  simp only [checkFour, w628_0, w628_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one628 : Coverage 628 629 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases628)
private theorem w629_0 : checkWitness 629 false false 496 = true := by decide +kernel
private theorem w629_1 : checkWitness 629 false true 4592 = true := by decide +kernel
private theorem w629_2 : checkWitness 629 true false 496 = true := by decide +kernel
private theorem w629_3 : checkWitness 629 true true 4592 = true := by decide +kernel
private theorem cases629 : checkFour 629 (496,4592,496,4592) = true := by
  simp only [checkFour, w629_0, w629_1, w629_2, w629_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one629 : Coverage 629 630 := checkList_sound (ws:=[(496,4592,496,4592)]) (by simpa only [checkList, Bool.and_true] using cases629)
private theorem w630_0 : checkWitness 630 false false 8899 = true := by decide +kernel
private theorem w630_2 : checkWitness 630 true false 8895 = true := by decide +kernel
private theorem cases630 : checkFour 630 (8899,0,8895,0) = true := by
  simp only [checkFour, w630_0, w630_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one630 : Coverage 630 631 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases630)
private theorem w631_0 : checkWitness 631 false false 628 = true := by decide +kernel
private theorem w631_1 : checkWitness 631 false true 4724 = true := by decide +kernel
private theorem w631_2 : checkWitness 631 true false 619 = true := by decide +kernel
private theorem w631_3 : checkWitness 631 true true 4715 = true := by decide +kernel
private theorem cases631 : checkFour 631 (628,4724,619,4715) = true := by
  simp only [checkFour, w631_0, w631_1, w631_2, w631_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one631 : Coverage 631 632 := checkList_sound (ws:=[(628,4724,619,4715)]) (by simpa only [checkList, Bool.and_true] using cases631)
private theorem w632_0 : checkWitness 632 false false 180 = true := by decide +kernel
private theorem w632_2 : checkWitness 632 true false 180 = true := by decide +kernel
private theorem cases632 : checkFour 632 (180,0,180,0) = true := by
  simp only [checkFour, w632_0, w632_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one632 : Coverage 632 633 := checkList_sound (ws:=[(180,0,180,0)]) (by simpa only [checkList, Bool.and_true] using cases632)
private theorem w633_0 : checkWitness 633 false false 573 = true := by decide +kernel
private theorem w633_1 : checkWitness 633 false true 4661 = true := by decide +kernel
private theorem w633_2 : checkWitness 633 true false 573 = true := by decide +kernel
private theorem w633_3 : checkWitness 633 true true 4661 = true := by decide +kernel
private theorem cases633 : checkFour 633 (573,4661,573,4661) = true := by
  simp only [checkFour, w633_0, w633_1, w633_2, w633_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one633 : Coverage 633 634 := checkList_sound (ws:=[(573,4661,573,4661)]) (by simpa only [checkList, Bool.and_true] using cases633)
private theorem w634_0 : checkWitness 634 false false 8914 = true := by decide +kernel
private theorem w634_2 : checkWitness 634 true false 8905 = true := by decide +kernel
private theorem cases634 : checkFour 634 (8914,0,8905,0) = true := by
  simp only [checkFour, w634_0, w634_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one634 : Coverage 634 635 := checkList_sound (ws:=[(8914,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases634)
private theorem w635_0 : checkWitness 635 false false 80 = true := by decide +kernel
private theorem w635_2 : checkWitness 635 true false 80 = true := by decide +kernel
private theorem cases635 : checkFour 635 (80,0,80,0) = true := by
  simp only [checkFour, w635_0, w635_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one635 : Coverage 635 636 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases635)
private theorem w636_0 : checkWitness 636 false false 72 = true := by decide +kernel
private theorem w636_2 : checkWitness 636 true false 72 = true := by decide +kernel
private theorem cases636 : checkFour 636 (72,0,72,0) = true := by
  simp only [checkFour, w636_0, w636_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one636 : Coverage 636 637 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases636)
private theorem w637_0 : checkWitness 637 false false 579 = true := by decide +kernel
private theorem w637_1 : checkWitness 637 false true 4671 = true := by decide +kernel
private theorem w637_2 : checkWitness 637 true false 579 = true := by decide +kernel
private theorem w637_3 : checkWitness 637 true true 4671 = true := by decide +kernel
private theorem cases637 : checkFour 637 (579,4671,579,4671) = true := by
  simp only [checkFour, w637_0, w637_1, w637_2, w637_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one637 : Coverage 637 638 := checkList_sound (ws:=[(579,4671,579,4671)]) (by simpa only [checkList, Bool.and_true] using cases637)
private theorem w638_0 : checkWitness 638 false false 8856 = true := by decide +kernel
private theorem w638_2 : checkWitness 638 true false 8852 = true := by decide +kernel
private theorem cases638 : checkFour 638 (8856,0,8852,0) = true := by
  simp only [checkFour, w638_0, w638_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one638 : Coverage 638 639 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases638)
private theorem w639_0 : checkWitness 639 false false 72 = true := by decide +kernel
private theorem w639_2 : checkWitness 639 true false 72 = true := by decide +kernel
private theorem cases639 : checkFour 639 (72,0,72,0) = true := by
  simp only [checkFour, w639_0, w639_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one639 : Coverage 639 640 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases639)
theorem cover0608 : Coverage 608 640 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one608 one609) (Coverage.join one610 one611)) (Coverage.join (Coverage.join one612 one613) (Coverage.join one614 one615))) (Coverage.join (Coverage.join (Coverage.join one616 one617) (Coverage.join one618 one619)) (Coverage.join (Coverage.join one620 one621) (Coverage.join one622 one623)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one624 one625) (Coverage.join one626 one627)) (Coverage.join (Coverage.join one628 one629) (Coverage.join one630 one631))) (Coverage.join (Coverage.join (Coverage.join one632 one633) (Coverage.join one634 one635)) (Coverage.join (Coverage.join one636 one637) (Coverage.join one638 one639)))))
end NF185PA.Symbolic
