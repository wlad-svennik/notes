import NF182PAFixedRows
import NF185PAPool
import NF185OldRowsSound

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Ground PA192.Literal NF185PA.Old
namespace NF182PA.Fixed
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
variable (S : Signature V) (E : V → V → Prop)
variable [Language.DefinableFunction₂ ℒₒᵣ S.app] [Language.DefinableFunction₂ ℒₒᵣ S.h]
variable [Language.DefinableRel ℒₒᵣ E]

set_option maxHeartbeats 2500000 in
theorem fixed_ax_true (r : NF196.Compact.Rows S E) {p : V} (hp : NF185PA.Pool.axiom185 p) :
    holds S E p := by
  obtain ⟨a,b,c,u,_,h⟩ := hp
  simp only [NF185PA.Pool.batch,List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · simp only [row0,holds_imp]
    tauto
  · simpa only [row3,holds_eq,konst,obj_app,obj_h,Signature.k] using r.kLaw (obj S a) (obj S b)
  · simpa only [NF185PA.Pool.nativeB,holds_eq,s,konst,obj_app,obj_h,obj_q,Signature.s,Signature.k]
      using r.bLaw (obj S a) (obj S b) (obj S c)
  · simpa only [row2,holds_imp,holds_eq,obj_app] using r.argCongr (obj S a) (obj S b) (obj S c)
  · simpa only [row4,holds_imp,holds_eq,obj_app] using r.funCongr (obj S a) (obj S b) (obj S c)
  · simpa only [row6,holds_imp,holds_eq] using r.euclid (obj S a) (obj S b) (obj S c)
  · simp only [NF185PA.Pool.test,NF185PA.Pool.single,holds_imp,holds_eq,s,konst,obj_app,obj_h,obj_q]
    intro cond
    exact r.rel_symm (r.test _ _ (fun h => r.rel_symm (cond (r.rel_symm h))))
  · simpa only [row8,holds_imp,holds_eq,obj_app,obj_h] using r.ext (obj S a) (obj S b)

/-- Arithmetic induction handles even nonstandard ranked proofs accepted by the 185 pool. -/
theorem excludes_proof (r : NF196.Compact.Rows S E) (no : ¬ E S.s S.q) :
    ¬NF185PA.Pool.Pr (∅ : V) goal := by
  intro h
  apply no
  apply (goal_iff S E).mp
  exact NF185PA.Pool.realize (R:=holds S E) (fun _ => fixed_ax_true S E r)
    (fun _ h => False.elim (by simp at h))
    (fun a b maj min => (holds_imp S E a b).mp maj min) h

end NF182PA.Fixed
#print axioms NF182PA.Fixed.excludes_proof
