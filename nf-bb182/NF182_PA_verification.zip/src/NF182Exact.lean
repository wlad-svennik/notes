import NF182ExactCore
import NF182PATapeAll
namespace NFMachine182
open FFL FFL.FirstOrder NF210 NF182PA
/-- The released 182-state table halts on blank tape iff pure NF proves falsum. -/
theorem halts_iff_nf_refutation : TM.Halts Reduced182.Table.machine Reduced182.Table.start ↔ (𝗡𝗙 ⊢ ⊥) :=
  halts_iff_nf_refutation_of_coverage Symbolic.literal_table_coverage
end NFMachine182
#print axioms NFMachine182.halts_iff_nf_refutation
