module
public import NF182PASigned
public import NF182PABoot
public import NF182PABootPrefix

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch
open PA192.ModelSearch.RegisterSource (address config vector)
namespace NF182PA
/-- A refutation may have nonstandard length in the ambient model of PA. -/
theorem refutation_reaches_register_halt {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
    (h : Pool.Pr (∅ : V) goal) : ∃ t : V, address (Registers.run t) = 4095 := by
  apply Boot.halts_after_prefix (origin:=ScannerSource.origin V) (margin:=Registers.margin V)
  · exact ⟨80, Boot.prefix80⟩
  · obtain ⟨t,ht⟩ := ScannerSource.proof_halts_origin h
    refine ⟨t,?_⟩
    rw [←Boot.run_eq]
    exact ht
end NF182PA
#print axioms NF182PA.refutation_reaches_register_halt
