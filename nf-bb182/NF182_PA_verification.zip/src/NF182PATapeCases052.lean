import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1664_0 : checkWitness 1664 false false 8836 = true := by decide +kernel
private theorem w1664_2 : checkWitness 1664 true false 8832 = true := by decide +kernel
private theorem cases1664 : checkFour 1664 (8836,0,8832,0) = true := by
  simp only [checkFour, w1664_0, w1664_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1664 : Coverage 1664 1665 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1664)
private theorem w1665_0 : checkWitness 1665 false false 92 = true := by decide +kernel
private theorem w1665_2 : checkWitness 1665 true false 92 = true := by decide +kernel
private theorem cases1665 : checkFour 1665 (92,0,92,0) = true := by
  simp only [checkFour, w1665_0, w1665_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1665 : Coverage 1665 1666 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1665)
private theorem w1666_0 : checkWitness 1666 false false 8856 = true := by decide +kernel
private theorem w1666_2 : checkWitness 1666 true false 8852 = true := by decide +kernel
private theorem cases1666 : checkFour 1666 (8856,0,8852,0) = true := by
  simp only [checkFour, w1666_0, w1666_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1666 : Coverage 1666 1667 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases1666)
private theorem w1667_0 : checkWitness 1667 false false 554 = true := by decide +kernel
private theorem w1667_1 : checkWitness 1667 false true 4650 = true := by decide +kernel
private theorem w1667_2 : checkWitness 1667 true false 554 = true := by decide +kernel
private theorem w1667_3 : checkWitness 1667 true true 4650 = true := by decide +kernel
private theorem cases1667 : checkFour 1667 (554,4650,554,4650) = true := by
  simp only [checkFour, w1667_0, w1667_1, w1667_2, w1667_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1667 : Coverage 1667 1668 := checkList_sound (ws:=[(554,4650,554,4650)]) (by simpa only [checkList, Bool.and_true] using cases1667)
private theorem w1668_0 : checkWitness 1668 false false 8910 = true := by decide +kernel
private theorem w1668_2 : checkWitness 1668 true false 8901 = true := by decide +kernel
private theorem cases1668 : checkFour 1668 (8910,0,8901,0) = true := by
  simp only [checkFour, w1668_0, w1668_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1668 : Coverage 1668 1669 := checkList_sound (ws:=[(8910,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases1668)
private theorem w1669_0 : checkWitness 1669 false false 76 = true := by decide +kernel
private theorem w1669_2 : checkWitness 1669 true false 76 = true := by decide +kernel
private theorem cases1669 : checkFour 1669 (76,0,76,0) = true := by
  simp only [checkFour, w1669_0, w1669_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1669 : Coverage 1669 1670 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1669)
private theorem w1670_0 : checkWitness 1670 false false 492 = true := by decide +kernel
private theorem w1670_1 : checkWitness 1670 false true 4588 = true := by decide +kernel
private theorem w1670_2 : checkWitness 1670 true false 492 = true := by decide +kernel
private theorem w1670_3 : checkWitness 1670 true true 4588 = true := by decide +kernel
private theorem cases1670 : checkFour 1670 (492,4588,492,4588) = true := by
  simp only [checkFour, w1670_0, w1670_1, w1670_2, w1670_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1670 : Coverage 1670 1671 := checkList_sound (ws:=[(492,4588,492,4588)]) (by simpa only [checkList, Bool.and_true] using cases1670)
private theorem w1671_0 : checkWitness 1671 false false 8850 = true := by decide +kernel
private theorem w1671_2 : checkWitness 1671 true false 8846 = true := by decide +kernel
private theorem cases1671 : checkFour 1671 (8850,0,8846,0) = true := by
  simp only [checkFour, w1671_0, w1671_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1671 : Coverage 1671 1672 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases1671)
private theorem w1672_0 : checkWitness 1672 false false 78 = true := by decide +kernel
private theorem w1672_2 : checkWitness 1672 true false 78 = true := by decide +kernel
private theorem cases1672 : checkFour 1672 (78,0,78,0) = true := by
  simp only [checkFour, w1672_0, w1672_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1672 : Coverage 1672 1673 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1672)
private theorem w1673_0 : checkWitness 1673 false false 536 = true := by decide +kernel
private theorem w1673_1 : checkWitness 1673 false true 4632 = true := by decide +kernel
private theorem w1673_2 : checkWitness 1673 true false 536 = true := by decide +kernel
private theorem w1673_3 : checkWitness 1673 true true 4632 = true := by decide +kernel
private theorem cases1673 : checkFour 1673 (536,4632,536,4632) = true := by
  simp only [checkFour, w1673_0, w1673_1, w1673_2, w1673_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1673 : Coverage 1673 1674 := checkList_sound (ws:=[(536,4632,536,4632)]) (by simpa only [checkList, Bool.and_true] using cases1673)
private theorem w1674_0 : checkWitness 1674 false false 8871 = true := by decide +kernel
private theorem w1674_2 : checkWitness 1674 true false 8867 = true := by decide +kernel
private theorem cases1674 : checkFour 1674 (8871,0,8867,0) = true := by
  simp only [checkFour, w1674_0, w1674_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1674 : Coverage 1674 1675 := checkList_sound (ws:=[(8871,0,8867,0)]) (by simpa only [checkList, Bool.and_true] using cases1674)
private theorem w1675_0 : checkWitness 1675 false false 8906 = true := by decide +kernel
private theorem w1675_2 : checkWitness 1675 true false 8897 = true := by decide +kernel
private theorem cases1675 : checkFour 1675 (8906,0,8897,0) = true := by
  simp only [checkFour, w1675_0, w1675_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1675 : Coverage 1675 1676 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1675)
private theorem w1676_0 : checkWitness 1676 false false 102 = true := by decide +kernel
private theorem w1676_2 : checkWitness 1676 true false 102 = true := by decide +kernel
private theorem cases1676 : checkFour 1676 (102,0,102,0) = true := by
  simp only [checkFour, w1676_0, w1676_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1676 : Coverage 1676 1677 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1676)
private theorem w1677_0 : checkWitness 1677 false false 618 = true := by decide +kernel
private theorem w1677_1 : checkWitness 1677 false true 4710 = true := by decide +kernel
private theorem w1677_2 : checkWitness 1677 true false 609 = true := by decide +kernel
private theorem w1677_3 : checkWitness 1677 true true 4701 = true := by decide +kernel
private theorem cases1677 : checkFour 1677 (618,4710,609,4701) = true := by
  simp only [checkFour, w1677_0, w1677_1, w1677_2, w1677_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1677 : Coverage 1677 1678 := checkList_sound (ws:=[(618,4710,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases1677)
private theorem w1678_0 : checkWitness 1678 false false 8867 = true := by decide +kernel
private theorem w1678_2 : checkWitness 1678 true false 8863 = true := by decide +kernel
private theorem cases1678 : checkFour 1678 (8867,0,8863,0) = true := by
  simp only [checkFour, w1678_0, w1678_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1678 : Coverage 1678 1679 := checkList_sound (ws:=[(8867,0,8863,0)]) (by simpa only [checkList, Bool.and_true] using cases1678)
private theorem w1679_0 : checkWitness 1679 false false 612 = true := by decide +kernel
private theorem w1679_1 : checkWitness 1679 false true 4704 = true := by decide +kernel
private theorem w1679_2 : checkWitness 1679 true false 603 = true := by decide +kernel
private theorem w1679_3 : checkWitness 1679 true true 4695 = true := by decide +kernel
private theorem cases1679 : checkFour 1679 (612,4704,603,4695) = true := by
  simp only [checkFour, w1679_0, w1679_1, w1679_2, w1679_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1679 : Coverage 1679 1680 := checkList_sound (ws:=[(612,4704,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases1679)
private theorem w1680_0 : checkWitness 1680 false false 8836 = true := by decide +kernel
private theorem w1680_2 : checkWitness 1680 true false 8832 = true := by decide +kernel
private theorem cases1680 : checkFour 1680 (8836,0,8832,0) = true := by
  simp only [checkFour, w1680_0, w1680_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1680 : Coverage 1680 1681 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1680)
private theorem w1681_0 : checkWitness 1681 false false 90 = true := by decide +kernel
private theorem w1681_2 : checkWitness 1681 true false 90 = true := by decide +kernel
private theorem cases1681 : checkFour 1681 (90,0,90,0) = true := by
  simp only [checkFour, w1681_0, w1681_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1681 : Coverage 1681 1682 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1681)
private theorem w1682_0 : checkWitness 1682 false false 82 = true := by decide +kernel
private theorem w1682_2 : checkWitness 1682 true false 82 = true := by decide +kernel
private theorem cases1682 : checkFour 1682 (82,0,82,0) = true := by
  simp only [checkFour, w1682_0, w1682_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1682 : Coverage 1682 1683 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1682)
private theorem w1683_0 : checkWitness 1683 false false 577 = true := by decide +kernel
private theorem w1683_1 : checkWitness 1683 false true 4661 = true := by decide +kernel
private theorem w1683_2 : checkWitness 1683 true false 577 = true := by decide +kernel
private theorem w1683_3 : checkWitness 1683 true true 4661 = true := by decide +kernel
private theorem cases1683 : checkFour 1683 (577,4661,577,4661) = true := by
  simp only [checkFour, w1683_0, w1683_1, w1683_2, w1683_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1683 : Coverage 1683 1684 := checkList_sound (ws:=[(577,4661,577,4661)]) (by simpa only [checkList, Bool.and_true] using cases1683)
private theorem w1684_0 : checkWitness 1684 false false 8830 = true := by decide +kernel
private theorem w1684_2 : checkWitness 1684 true false 8826 = true := by decide +kernel
private theorem cases1684 : checkFour 1684 (8830,0,8826,0) = true := by
  simp only [checkFour, w1684_0, w1684_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1684 : Coverage 1684 1685 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1684)
private theorem w1685_0 : checkWitness 1685 false false 82 = true := by decide +kernel
private theorem w1685_2 : checkWitness 1685 true false 82 = true := by decide +kernel
private theorem cases1685 : checkFour 1685 (82,0,82,0) = true := by
  simp only [checkFour, w1685_0, w1685_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1685 : Coverage 1685 1686 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1685)
private theorem w1686_0 : checkWitness 1686 false false 582 = true := by decide +kernel
private theorem w1686_1 : checkWitness 1686 false true 4678 = true := by decide +kernel
private theorem w1686_2 : checkWitness 1686 true false 582 = true := by decide +kernel
private theorem w1686_3 : checkWitness 1686 true true 4678 = true := by decide +kernel
private theorem cases1686 : checkFour 1686 (582,4678,582,4678) = true := by
  simp only [checkFour, w1686_0, w1686_1, w1686_2, w1686_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1686 : Coverage 1686 1687 := checkList_sound (ws:=[(582,4678,582,4678)]) (by simpa only [checkList, Bool.and_true] using cases1686)
private theorem w1687_0 : checkWitness 1687 false false 8898 = true := by decide +kernel
private theorem w1687_2 : checkWitness 1687 true false 8889 = true := by decide +kernel
private theorem cases1687 : checkFour 1687 (8898,0,8889,0) = true := by
  simp only [checkFour, w1687_0, w1687_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1687 : Coverage 1687 1688 := checkList_sound (ws:=[(8898,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1687)
private theorem w1688_0 : checkWitness 1688 false false 8844 = true := by decide +kernel
private theorem w1688_2 : checkWitness 1688 true false 8840 = true := by decide +kernel
private theorem cases1688 : checkFour 1688 (8844,0,8840,0) = true := by
  simp only [checkFour, w1688_0, w1688_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1688 : Coverage 1688 1689 := checkList_sound (ws:=[(8844,0,8840,0)]) (by simpa only [checkList, Bool.and_true] using cases1688)
private theorem w1689_0 : checkWitness 1689 false false 90 = true := by decide +kernel
private theorem w1689_2 : checkWitness 1689 true false 90 = true := by decide +kernel
private theorem cases1689 : checkFour 1689 (90,0,90,0) = true := by
  simp only [checkFour, w1689_0, w1689_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1689 : Coverage 1689 1690 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1689)
private theorem w1690_0 : checkWitness 1690 false false 628 = true := by decide +kernel
private theorem w1690_1 : checkWitness 1690 false true 4716 = true := by decide +kernel
private theorem w1690_2 : checkWitness 1690 true false 619 = true := by decide +kernel
private theorem w1690_3 : checkWitness 1690 true true 4707 = true := by decide +kernel
private theorem cases1690 : checkFour 1690 (628,4716,619,4707) = true := by
  simp only [checkFour, w1690_0, w1690_1, w1690_2, w1690_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1690 : Coverage 1690 1691 := checkList_sound (ws:=[(628,4716,619,4707)]) (by simpa only [checkList, Bool.and_true] using cases1690)
private theorem w1691_0 : checkWitness 1691 false false 8886 = true := by decide +kernel
private theorem w1691_2 : checkWitness 1691 true false 8882 = true := by decide +kernel
private theorem cases1691 : checkFour 1691 (8886,0,8882,0) = true := by
  simp only [checkFour, w1691_0, w1691_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1691 : Coverage 1691 1692 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases1691)
private theorem w1692_0 : checkWitness 1692 false false 80 = true := by decide +kernel
private theorem w1692_2 : checkWitness 1692 true false 80 = true := by decide +kernel
private theorem cases1692 : checkFour 1692 (80,0,80,0) = true := by
  simp only [checkFour, w1692_0, w1692_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1692 : Coverage 1692 1693 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1692)
private theorem w1693_0 : checkWitness 1693 false false 488 = true := by decide +kernel
private theorem w1693_1 : checkWitness 1693 false true 4584 = true := by decide +kernel
private theorem w1693_2 : checkWitness 1693 true false 488 = true := by decide +kernel
private theorem w1693_3 : checkWitness 1693 true true 4584 = true := by decide +kernel
private theorem cases1693 : checkFour 1693 (488,4584,488,4584) = true := by
  simp only [checkFour, w1693_0, w1693_1, w1693_2, w1693_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1693 : Coverage 1693 1694 := checkList_sound (ws:=[(488,4584,488,4584)]) (by simpa only [checkList, Bool.and_true] using cases1693)
private theorem w1694_0 : checkWitness 1694 false false 8926 = true := by decide +kernel
private theorem w1694_2 : checkWitness 1694 true false 8917 = true := by decide +kernel
private theorem cases1694 : checkFour 1694 (8926,0,8917,0) = true := by
  simp only [checkFour, w1694_0, w1694_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1694 : Coverage 1694 1695 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases1694)
private theorem w1695_0 : checkWitness 1695 false false 88 = true := by decide +kernel
private theorem w1695_2 : checkWitness 1695 true false 88 = true := by decide +kernel
private theorem cases1695 : checkFour 1695 (88,0,88,0) = true := by
  simp only [checkFour, w1695_0, w1695_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1695 : Coverage 1695 1696 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1695)
theorem cover1664 : Coverage 1664 1696 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1664 one1665) (Coverage.join one1666 one1667)) (Coverage.join (Coverage.join one1668 one1669) (Coverage.join one1670 one1671))) (Coverage.join (Coverage.join (Coverage.join one1672 one1673) (Coverage.join one1674 one1675)) (Coverage.join (Coverage.join one1676 one1677) (Coverage.join one1678 one1679)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1680 one1681) (Coverage.join one1682 one1683)) (Coverage.join (Coverage.join one1684 one1685) (Coverage.join one1686 one1687))) (Coverage.join (Coverage.join (Coverage.join one1688 one1689) (Coverage.join one1690 one1691)) (Coverage.join (Coverage.join one1692 one1693) (Coverage.join one1694 one1695)))))
end NF182PA.Symbolic
