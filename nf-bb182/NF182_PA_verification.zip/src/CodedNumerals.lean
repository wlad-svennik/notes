module
public import FoundationNumerals

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace PA192.Numerals.FoundationRoute

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
variable {A : Type} [ORingStructure A] [A↓[ℒₒᵣ] ⊧* 𝗤]

/-- Every element of the interpreted domain has a canonical numeric code;
ill-formed codes may decode to a fixed default inhabitant. -/
structure Codes (V A : Type) where
  enc : A → V
  dec : V → A
  dec_enc : ∀ a, dec (enc a) = a

namespace Codes
variable (c : Codes V A)
def norm (v : V) := c.enc (c.dec v)
def num (i : V → A) (v : V) := c.enc (i v)
def add (u v : V) := c.enc (c.dec u + c.dec v)
def mul (u v : V) := c.enc (c.dec u * c.dec v)

protected lemma inj {a b : A} (h : c.enc a = c.enc b) : a=b := by
  simpa only [c.dec_enc] using congrArg c.dec h

@[simp] theorem eq_iff {a b : A} : c.enc a = c.enc b ↔ a=b := ⟨c.inj,congrArg c.enc⟩

/-- All four graphs are fixed first-order definitions in the number model,
with parameters allowed. -/
structure Definable (i : V → A) : Prop where
  norm : Language.DefinableFunction₁ ℒₒᵣ c.norm
  num : Language.DefinableFunction₁ ℒₒᵣ (c.num i)
  add : Language.DefinableFunction₂ ℒₒᵣ c.add
  mul : Language.DefinableFunction₂ ℒₒᵣ c.mul
end Codes

theorem arithPred_of_definable {P : V → Prop} (h : Language.DefinablePred ℒₒᵣ P) : ArithPred P := by
  classical
  obtain ⟨φ,hφ⟩ := h
  let _ : Inhabited V := Classical.inhabited_of_nonempty'
  refine ⟨φ.enumerateFVar, (Rew.rewriteMap φ.idxOfFVar) ▹ φ, ?_⟩
  intro x
  simpa [Semiformula.eval_rewriteMap] using (hφ ![x]).symm

private theorem arithPred_of_iff {P Q : V → Prop} (h : Language.DefinablePred ℒₒᵣ Q)
    (eq : ∀ n, P n ↔ Q n) : ArithPred P := by
  obtain ⟨e,φ,hφ⟩ := arithPred_of_definable h
  exact ⟨e,φ,fun n => (eq n).trans (hφ n)⟩

theorem coded_inductions (i : V → A) (c : Codes V A) (d : c.Definable i) :
    DefinableInductions i := by
  let _ := d.norm
  let _ := d.num
  let _ := d.add
  let _ := d.mul
  constructor
  · apply arithPred_of_iff (Q := fun n => ∀ x, c.num i (x+n) = c.add (c.num i x) (c.num i n))
    · definability
    · intro n
      simp only [Robinson.AddAt, rob, Codes.num, Codes.add, c.dec_enc, c.eq_iff]
  · apply arithPred_of_iff (Q := fun n => ∀ x, c.num i (x*n) = c.mul (c.num i x) (c.num i n))
    · definability
    · intro n
      simp only [Robinson.MulAt, rob, Codes.num, Codes.mul, c.dec_enc, c.eq_iff]
  · apply arithPred_of_iff (Q := fun n => ∀ x, c.num i x = c.num i n → x=n)
    · definability
    · intro n
      simp only [Robinson.InjAt, Codes.num, c.eq_iff]
  · apply arithPred_of_iff (Q := fun n => ∀ a, (∃ z, c.add z a = c.num i n) →
      ∃ m, (∃ w, w+m=n) ∧ c.num i m = c.norm a)
    · definability
    · intro n
      constructor
      · intro h a ⟨z,hz⟩
        obtain ⟨m,hw,hm⟩ := h (c.dec a) ⟨c.dec z,c.inj hz⟩
        exact ⟨m,hw,congrArg c.enc hm⟩
      · intro h a ⟨z,hz⟩
        have hz' : c.add (c.enc z) (c.enc a) = c.num i n := by
          simpa only [Codes.add, Codes.num, c.dec_enc, c.eq_iff, rob] using hz
        obtain ⟨m,hw,hm⟩ := h (c.enc a) ⟨c.enc z,hz'⟩
        exact ⟨m,hw,by simpa only [Codes.num, Codes.norm, c.dec_enc, c.eq_iff] using hm⟩
  · apply arithPred_of_iff (Q := fun n => ∀ a b, c.add a b = c.num i n →
      ∃ x y, c.num i x = c.norm a ∧ c.num i y = c.norm b ∧ x+y=n)
    · definability
    · intro n
      constructor
      · intro h a b hab
        obtain ⟨x,y,hx,hy,hxy⟩ := h (c.dec a) (c.dec b) (c.inj hab)
        exact ⟨x,y,congrArg c.enc hx,congrArg c.enc hy,hxy⟩
      · intro h a b hab
        have hab' : c.add (c.enc a) (c.enc b) = c.num i n := by
          simpa only [Codes.add,Codes.num,c.dec_enc,c.eq_iff,rob] using hab
        obtain ⟨x,y,hx,hy,hxy⟩ := h (c.enc a) (c.enc b) hab'
        exact ⟨x,y,by simpa only [Codes.num,Codes.norm,c.dec_enc,c.eq_iff] using hx,
                   by simpa only [Codes.num,Codes.norm,c.dec_enc,c.eq_iff] using hy,hxy⟩

theorem coded_sigma_one_up (i : V → A) (hi : (rob V).NumeralMap (rob A) i)
    (c : Codes V A) (d : c.Definable i) (φ : 𝚺ᴬ₁.Semisentence k) (v : Fin k → V) :
    φ.val.Evalb v → φ.val.Evalb (M := A) (i ∘ v) :=
  sigma_one_up i hi (coded_inductions i c d) φ v

end PA192.Numerals.FoundationRoute

#print axioms PA192.Numerals.FoundationRoute.coded_sigma_one_up
