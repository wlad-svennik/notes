import MovingRows
import VariableDetector
import NF185PAInterpreted

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Ground

namespace NF182PA.Chart

/-- Recover a Boolean function basis on exactly the original quotient and with
its original application. The four extensionality witnesses are only used
to select two fixed, distinguishable outputs. -/
theorem boolean_basis {X : Type} (A : VariableMarkerNF.Marked X) :
    ∃ B : ArbitraryBoolean.Basis X, B.app = A.app := by
  let S := A.toBasis
  let J := A.J
  let r := VariableMarker.reference S J
  let s := VariableMarker.diag S J r r
  have off (x y : X) : x ≠ y → VariableMarker.diag S J x y = x := A.off x y
  have on (x : X) : VariableMarker.diag S J x x ≠ x := A.on x
  have n : s ≠ r := A.on r
  obtain ⟨a,na⟩ := A.exists_sep n
  obtain ⟨b,nb⟩ := A.exists_sep na
  obtain ⟨c,nc⟩ := A.exists_sep nb
  obtain ⟨d,nd⟩ := A.exists_sep nc
  let W := VariableMarker.weak S J a b c d
  let yes := S.app (S.app (S.app (S.app s a) b) c) d
  have fixedOff (x y : X) (h : x ≠ y) : NF196.Weak.diag S W x y = yes := by
    change S.app (S.app (VariableMarker.weak S J a b c d) (S.K x)) y = _
    rw [VariableMarker.weak_apply, VariableMarker.probe_eq S J off h]
  have fixedOn (x : X) : NF196.Weak.diag S W x x ≠ yes := by
    change S.app (S.app (VariableMarker.weak S J a b c d) (S.K x)) x ≠ _
    rw [VariableMarker.weak_apply, off _ _ (Ne.symm (VariableMarker.probe_ne S J on x))]
    exact nd.symm
  exact ⟨NF196.Weak.weakBasis S W yes fixedOff fixedOn, rfl⟩

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
variable {S : Signature V} {E : V → V → Prop}

/-- The codes of the two Boolean classes can be arbitrary representatives.
Only these two parameters are used in the membership formula. -/
def rawMem (S : Signature V) (E : V → V → Prop) (t f x y : V) : Prop :=
  (∀ u, E (S.app y u) t ∨ E (S.app y u) f) ∧ E (S.app y x) t

theorem rawMem_def (t f : V) [Language.DefinableRel ℒₒᵣ E]
    [Language.DefinableFunction₂ ℒₒᵣ S.app] :
    Language.DefinableRel ℒₒᵣ (rawMem S E t f) := by
  unfold rawMem
  definability

/-- The Boolean construction presents an NFUI model over the ambient PA model. -/
theorem presented_rows [Language.DefinableRel ℒₒᵣ E]
    [Language.DefinableFunction₂ ℒₒᵣ S.app]
    (R : VariableMarkerNF.Rows S E) (ne : ¬E S.s S.q) :
    NF185PA.Comparison.Presented 𝗡𝗙𝗨𝗜 V := by
  obtain ⟨B, ap⟩ := boolean_basis (R.toMarked ne)
  have appLift (x y : V) : B.app (R.obj x) (R.obj y) = R.obj (S.app x y) := by
    rw [ap] <;> rfl
  obtain ⟨t, ht⟩ : ∃ v, R.obj v = B.yes := Quotient.exists_rep _
  obtain ⟨f, hf⟩ : ∃ v, R.obj v = B.no := Quotient.exists_rep _
  letI : ArbitraryBoolean.Basis R.Carrier := B
  letI : Nonempty R.Carrier := ⟨R.obj S.q⟩
  letI : Tarski.Structure ℒλ R.Carrier := ArbitraryBoolean.fnStructure
  letI : Tarski.Structure.Eq ℒλ R.Carrier := ⟨fun _ _ => Iff.rfl⟩
  letI : R.Carrier↓[ℒλ] ⊧* 𝗙𝗡𝗙 := ArbitraryBoolean.fnModel_models
  have membership (x y : V) : FNF.Mem (R.obj x) (R.obj y) ↔ rawMem S E t f x y := by
    change ((∀ u, B.app (R.obj y) u = B.yes ∨ B.app (R.obj y) u = B.no) ∧
      B.app (R.obj y) (R.obj x) = B.yes) ↔ _
    rw [← ht, ← hf]
    constructor
    · rintro ⟨h,hx⟩
      refine ⟨fun u => ?_,R.obj_eq_iff.mp ((appLift y x).symm.trans hx)⟩
      simpa only [appLift,R.obj_eq_iff] using h (R.obj u)
    · rintro ⟨h,hx⟩
      refine ⟨?_, (appLift y x).trans (R.obj_eq_iff.mpr hx)⟩
      intro u
      obtain ⟨c,rfl⟩ := Quotient.exists_rep u
      exact (h c).imp (fun e => (appLift y c).trans (R.obj_eq_iff.mpr e))
        (fun e => (appLift y c).trans (R.obj_eq_iff.mpr e))
  let P : NF192.Internal.Presentation V R.Carrier (FNF.Mem (M:=R.Carrier)) := {
    dec := R.obj
    onto := Quotient.exists_rep
    eqDef := Language.Definable.of_iff (by assumption : Language.DefinableRel ℒₒᵣ E)
      (fun _ => R.obj_eq_iff)
    memDef := Language.Definable.of_iff (rawMem_def t f) (fun _ => membership _ _) }
  letI : SetStructure R.Carrier := ⟨fun y x => FNF.Mem x y⟩
  have hT : R.Carrier↓[ℒₛₑₜ] ⊧* 𝗡𝗙𝗨𝗜 :=
    SetTheory.Jensen.models_nfui_of_isNFU FNF.isNFU FNF.univInfinite
  exact ⟨R.Carrier,inferInstance,inferInstance,hT,⟨P⟩⟩

end NF182PA.Chart
#print axioms NF182PA.Chart.presented_rows
