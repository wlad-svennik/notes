module
public import H192Standard
public import ModelTrace
public import Reduced182Safe
public import NF182TapeData

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM PA192.PhysicalModel

namespace NF182PA

/-- First-order PA formula over the literal 364 rows and the blank initial state. -/
def H182 : ArithmeticSentence := traceF Reduced182.Table.machine Reduced182.Table.start

/-- Semantics of the sentence for every PA model, including nonstandard times. -/
theorem H182_eval {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    (V ⊧/![] H182) ↔ ∃ t : V, state (rawRun Reduced182.Table.machine Reduced182.Table.start t) = (182 : V) :=
  traceF_iff_model_run _ _

theorem H182_standard :
    (Nat ⊧/![] H182) ↔ Halts Reduced182.Table.machine Reduced182.Table.start :=
  traceF_standard _ _

end NF182PA
