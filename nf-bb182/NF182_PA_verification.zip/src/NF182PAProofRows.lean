import NF182PAPool
import MovingRows

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal

namespace NF182PA.Pool
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- The literal eight-row arithmetic pool, including its printed tester orientation,
produces a definable equality relation on all of the ambient PA model. -/
theorem definable_countermodel (hd : ¬Pr (∅ : V) goal) :
    VariableMarkerNF.Rows (X:=V) ⟨q,app,witness⟩ E ∧ ¬E (s : V) q := by
  let D := calculus V
  have hd' : ¬D.prov ∅ D.goal := hd
  have holds {p a b c : V} (hp : p ∈ batch a b c 0) : D.Holds p :=
    D.sound (leaf (Or.inl (ax_of_mem (not_lt_of_ge zero_le) hp)))
  have arrow := D.imp_iff hd'
  have k (a b : V) : E (app (konst b) a) b :=
    holds (p:=row3 a b) (a:=a) (b:=b) (c:=0) (by simp [batch])
  have eu (a b c : V) (ab : E a b) (ac : E a c) : E c b := by
    have r : D.Holds (row6 a b c) := holds (a:=a) (b:=b) (c:=c) (by simp [batch])
    exact (arrow _ _).mp ((arrow _ _).mp r ab) ac
  refine ⟨?_,D.goal_false hd'⟩
  constructor
  · intro a b c
    apply (arrow _ _).mp
    exact holds (p:=row2 a b c) (a:=a) (b:=b) (c:=c) (by simp [batch])
  · exact k
  · intro a b c
    apply (arrow _ _).mp
    exact holds (p:=row4 a b c) (a:=a) (b:=b) (c:=c) (by simp [batch])
  · intro a b c
    exact holds (p:=nativeB a b c) (a:=a) (b:=b) (c:=c) (by simp [batch])
  · exact eu
  · intro x y h
    have t : D.Holds (test x y) := holds (a:=y) (b:=x) (c:=0) (by simp [batch])
    exact (arrow _ _).mp t ((arrow _ _).mpr h)
  · intro a b
    apply (arrow _ _).mp
    exact holds (p:=row8 a b) (a:=a) (b:=b) (c:=0) (by simp [batch])

end NF182PA.Pool
#print axioms NF182PA.Pool.definable_countermodel
