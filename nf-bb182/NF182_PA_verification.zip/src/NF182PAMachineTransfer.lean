import NF182PAMachineTransferCore
import NF182PATapeAll
import NF185PATapeAll
open FFL FFL.FirstOrder
namespace NF182PA
/-- PA proves literal blank-tape halting transfers from 185 to 182 states. -/
theorem machine_transfer : M6.PA.theory ⊢ NF185PA.H185 🡒 H182 :=
  machine_transfer_of_coverage NF185PA.Symbolic.literal_table_coverage Symbolic.literal_table_coverage
end NF182PA
#print axioms NF182PA.machine_transfer
