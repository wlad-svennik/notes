module
public import NF182PABatches
public import NF182PAScanner
@[expose] public section
section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterFields NF182PA.Packed PA192.ModelSearch.Register182
open PA192.ModelSearch.Register182.Commands NF182PA.Scanner PA192.ModelSearch.Enumeration
set_option maxRecDepth 8500
set_option maxHeartbeats 4200000
namespace NF182PA.ScannerSource
open PA192.ModelSearch

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- Warm PC10 register boundary. The physical source has the two scratch zeros R6, R7 and the zero R3. -/
noncomputable def view (a : V) := config 10 0 (vector (index a) (top (dataState a))
  (stack (dataState a)) 0 (param (dataState a)) (cache (dataState a)) 0 0 (input a))
instance viewDef : Language.DefinableFunction₁ ℒₒᵣ (view (V:=V)) := by
  unfold view vector index top dataState stack param cache input; definability

theorem terminal_of_reach {x y : V} (h : Reach x y) (fin : sourceHalts y) : sourceHalts x := by
  obtain ⟨i,hi⟩ := h
  obtain ⟨j,hj⟩ := fin
  exact ⟨i+j,by rw [PA192.ModelSearch.Register182.run_add,hi,hj]⟩

/-- With the concrete PC10 view, the only local requirements are entry, the observed
MODE halt and one nonobserving command, including a possible candidate refill. -/
theorem from_source (start e origin : V) (entry : Reach origin (view (fresh start start e)))
    (onHit : ∀ a : V, observed a → sourceHalts (view a))
    (onLive : ∀ a : V, ¬observed a → Reach (view a) (view (next a)))
    (proof : NF182PA.Pool.Pr (∅ : V) goal) : sourceHalts origin := by
  by_contra impossible
  let begin := fresh start start e
  have all : ∀ t : V, Reach origin (view (iterate next t begin)) := by
    apply modelInduct
    · definability
    · simpa [begin] using entry
    · intro t h
      have live : ¬ observed (iterate next t begin) := fun stop =>
        impossible (terminal_of_reach h (onHit _ stop))
      simpa only [iterate_succ] using h.trans (onLive _ live)
  obtain ⟨t,hit⟩ := pool_forces_observation proof start e
  exact impossible (terminal_of_reach (all t) (onHit _ hit))


theorem view_fresh (k raw e : V) : view (fresh k raw e)=vm 10 0 k e raw := by
  simp [view,vm,atS,fresh,index,input,dataState]

theorem view_unpack (a : V) : view a=vm 10 0 (index a) (dataState a) (input a) := by
  simp [view,vm,atS]

theorem axTail (u y d c w e : V) : pi₂ (axRaw u y d c w e) = unread c w := by
  simp [axRaw,ax_ends]

theorem liveFields (k t s h p tag d w : V) (live : ¬(tag=0 ∧ h=3)) :
    let raw := cantor tag (cantor d w)
    let e := state t s h p
    Reach (vm 10 0 k e raw) (vm 0 0 k (rawAction raw e) (tail raw)) := by
  dsimp only
  rcases zeroOrSuccessor tag with rfl|⟨i,rfl⟩
  · have neq : h≠3 := fun hh=>live ⟨rfl,hh⟩
    simpa [rawAction,tail,chooseZero] using modeTagged 0 k t s p h d w neq
  rcases zeroOrSuccessor i with rfl|⟨c,rfl⟩
  · simpa [rawAction,tail,chooseZero] using mpTagged 0 k t s p h d w
  · have step := axTagged 0 k t s p h d (left w) (left (right w)) c (right (right w))
    dsimp only at step
    rw [pairUnpackTwo] at step
    have tag : c+1+1=c+2 := by ring
    have zz : c+2≠0 := by simp
    have zs : c+2-1≠0 := by rw [Enumeration.tag_succ_sub_one]; simp
    simpa only [tag,rawAction,rawAX,tail,left_cantor,right_cantor,chooseZero,zz,zs,ite_false,
      add_sub_self,vm_state,axTail] using step

theorem actualCommand {k raw e : V} (live : ¬(left raw=0 ∧ cache e=3)) :
    Reach (vm 10 0 k e raw) (vm 0 0 k (rawAction raw e) (tail raw)) := by
  have h := liveFields k (top e) (stack e) (cache e) (param e) (left raw) (left (right raw)) (right (right raw)) live
  rwa [pairUnpackTwo,state_eta] at h

theorem actualRefill (k raw result : V) :
    let c := cursor ⟪k,raw⟫
    Reach (vm 0 0 k result (tail raw)) (vm 10 0 (pi₁ c) result (pi₂ c)) := by
  dsimp only
  rcases zeroOrSuccessor (tail raw) with zero|⟨j,positive⟩
  · rw [cursor_zero zero,zero,pi₁_pair,pi₂_pair]
    exact warmRefill k result
  · have neq : tail raw≠0 := by simp [positive]
    rw [cursor_pos neq,positive,pi₁_pair,pi₂_pair]
    simpa using warmPositive k result j

/-- Every live scanner step is witnessed by an actual run on the 2,959-address source, in any PA model. -/
theorem onLive (a : V) (ok : ¬ observed a) : Reach (view a) (view (next a)) := by
  let k := index a
  let raw := input a
  let e := dataState a
  have h := actualCommand (k:=k) (raw:=raw) (e:=e) ok
  rw [view_unpack,next,view_fresh]
  exact h.trans (actualRefill k raw (rawAction raw e))

/-- An observed command reaches the authentic 4095 source halt. -/
theorem onHit (a : V) (ok : observed a) : sourceHalts (view a) := by
  obtain ⟨tag,old⟩ := ok
  let k := index a
  let raw := input a
  let e := dataState a
  let p := param e
  let t := top e
  let s := stack e
  let d := left (right raw)
  let w := right (right raw)
  have code : cantor 0 (cantor d w)=raw := by
    have eq := pairUnpackTwo raw
    rw [show left raw=0 from tag] at eq
    exact eq
  have tr := modeTaggedHead 0 k t s p 3 d w
  rw [code] at tr
  have done := carryHalt tr (modeHalt 0 k t s (p+d) w)
  rw [view_unpack]
  simpa only [vm,show cache (dataState a)=3 from old,k,raw,t,s,p,e] using done

/-- The entire scanner-to-source implication now only takes its initial source-entry witness. -/
theorem halts_of_entry (start e origin : V) (entry : Reach origin (view (fresh start start e)))
    (h : NF182PA.Pool.Pr (∅ : V) goal) : sourceHalts origin :=
  from_source start e origin entry onHit onLive h

end NF182PA.ScannerSource
#print axioms NF182PA.ScannerSource.onLive
#print axioms NF182PA.ScannerSource.onHit
#print axioms NF182PA.ScannerSource.halts_of_entry

end
