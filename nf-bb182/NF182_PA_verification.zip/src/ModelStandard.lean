module
public import ModelTrace
public import H192Local

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 2000000

noncomputable def stdPack (a : Rays n) : V := pack (control a.status : V) (a.left:V) (a.right:V)

theorem cast_local (m : Machine n) (q : Fin n) (b : Bool) {s l r t u v : Nat}
    (h : Local m q b s l r t u v) :
    Local m q b (s:V) (l:V) (r:V) (t:V) (u:V) (v:V) := by
  obtain ⟨hs,ht,h⟩ := h
  simp only [natCast_nat] at hs ht h
  refine ⟨by exact_mod_cast hs,by exact_mod_cast ht,?_⟩
  cases move : (m q b).move with
  | right =>
    simp only [move] at h ⊢
    obtain ⟨x,hr,hu,hv⟩ := h
    exact ⟨(x:V), by exact_mod_cast hr, by exact_mod_cast hu, by exact_mod_cast hv⟩
  | left =>
    simp only [move] at h ⊢
    obtain ⟨x,y,e,he,hl,hr,hu,hv⟩ := h
    refine ⟨(x:V),(y:V),(e:V),?_,by exact_mod_cast hl,by exact_mod_cast hr,
      by exact_mod_cast hu, by exact_mod_cast hv⟩
    rcases he with he|he
    · exact Or.inl (by exact_mod_cast he)
    · exact Or.inr (by exact_mod_cast he)

theorem raw_standard (m : Machine n) (a : Rays n) :
    rawStep m (stdPack (V:=V) a)=stdPack (a.advance m) := by
  by_cases active : a.status=none
  · simp [Rays.advance,active,stdPack,rawStep,LiteralTM.control]
    apply pick_none
    intro q _; exact_mod_cast (Nat.ne_of_lt q.isLt).symm
  · apply step_to_raw
    obtain ⟨q,b,h⟩ := a.step_of_working m active
    exact ⟨q,b,by simpa [stdPack] using (cast_local (V:=V) m q b h)⟩

theorem run_standard (m : Machine n) (q : Fin n) (t : Nat) :
    rawRun m q (t:V) = stdPack (Rays.run m q t) := by
  induction t with
  | zero => simp [stdPack,Rays.run,Rays.blank,LiteralTM.control]
  | succ j ih => rw [Nat.cast_succ,run_succ,ih,Rays.run,raw_standard]

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.run_standard
