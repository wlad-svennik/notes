import ExtractOps
namespace NF192.Direct
universe u
variable {V : Type u}

theorem exDom {m : V → V → Prop} {D : V} {F : V → Prop} :
    (∃x,m x D ∧ F x) ↔ ∃x : Dom m D,F x.val :=
  ⟨fun ⟨x,hx,h⟩ => ⟨⟨x,hx⟩,h⟩,fun ⟨x,h⟩ => ⟨x.val,x.2,h⟩⟩
theorem exDom2 {m : V → V → Prop} {D : V} {F : V → V → Prop} :
    (∃x y,m x D ∧ m y D ∧ F x y) ↔ ∃x y : Dom m D,F x.val y.val :=
  ⟨fun ⟨x,y,hx,hy,h⟩ => ⟨⟨x,hx⟩,⟨y,hy⟩,h⟩,fun ⟨x,y,h⟩ => ⟨x.val,y.val,x.2,y.2,h⟩⟩

theorem fromO1 {m : V → V → Prop} {D : V} {F : V → Prop} {Y : One (Dom m D)}
    (given : UnaryObject m D F) (agree : ∀x : Dom m D,F x.val ↔ Y x) : RepOne m D Y := by
  obtain ⟨C,hC⟩ := given;exact ⟨C,fun x => (hC x x.2).trans (agree x)⟩
theorem fromO2 {m : V → V → Prop} {D P : V} {F : V → V → Prop} {Y : Two (Dom m D)}
    (given : BinaryObject m D P F) (agree : ∀x y : Dom m D,F x.val y.val ↔ Y x y) : RepTwo m D P Y := by
  obtain ⟨C,hC⟩ := given;exact ⟨C,fun x y => (hC x y ⟨x.2,y.2⟩).trans (agree x y)⟩

theorem extractClosures {m : V → V → Prop} {D z S A B P : V} {o : NumOps (Dom m D)}
    (L : OpsLaws m D z S A B P o) (C : ClosureAt m D z S A B P) :
    o.ClosedFamilies (RepOne m D) (RepTwo m D P) := by
  obtain ⟨head,tail,zero,succ,add,mul,comp,fork,common,neg,cap,project,slice⟩ := C
  have test (Y : V) (x y : Dom m D) : RelObj m D P Y x.val y.val ↔ m (o.pair x y).val Y := by
    change (∃k,m k D ∧ Tri m P x.val y.val k ∧ m k Y) ↔ _
    rw [exDom];constructor
    · rintro ⟨k,hk,h⟩;rw [(L.pv x y k).mp hk];exact h
    · exact fun h => ⟨o.pair x y,(L.pv _ _ _).mpr rfl,h⟩
  constructor
  · apply fromO2 head;intro h x;rw [exDom]; exact exists_congr fun t => L.pv x t h
  · apply fromO2 tail;intro h t;rw [exDom]; exact exists_congr fun x => L.pv x t h
  · apply fromO2 zero;intro _ x;rw [←L.zv]; exact ⟨Subtype.ext,congrArg Subtype.val⟩
  · exact fromO2 succ L.sv
  · apply fromO2 add;intro h v;rw [exDom2]
    exact exists_congr fun x => exists_congr fun y => and_congr (L.pv x y h) (L.av x y v)
  · apply fromO2 mul;intro h v;rw [exDom2]
    exact exists_congr fun x => exists_congr fun y => and_congr (L.pv x y h) (L.mv x y v)
  · intro R S ⟨X,hX⟩ ⟨Y,hY⟩;apply fromO2 (comp X Y);intro h v;rw [exDom]
    exact exists_congr fun u => and_congr (hX h u) (hY u v)
  · intro R S ⟨X,hX⟩ ⟨Y,hY⟩;apply fromO2 (fork X Y);intro h t;rw [exDom2]
    exact exists_congr fun x => exists_congr fun y => and_congr (L.pv x y t) (and_congr (hX h x) (hY h y))
  · intro R S ⟨X,hX⟩ ⟨Y,hY⟩;apply fromO1 (common X Y);intro h;rw [exDom]
    exact exists_congr fun x => and_congr (hX h x) (hY h x)
  · intro R ⟨X,hX⟩;apply fromO1 (neg X);exact fun x => not_congr (hX x)
  · intro R S ⟨X,hX⟩ ⟨Y,hY⟩;apply fromO1 (cap X Y);exact fun x => and_congr (hX x) (hY x)
  · intro R ⟨X,hX⟩;apply fromO1 (project X);intro h;rw [exDom]
    exact exists_congr fun x => (test X x h).trans (hX (o.pair x h))
  · intro R ⟨X,hX⟩ h;apply fromO1 (slice X h h.2)
    exact fun x => (test X x h).trans (hX (o.pair x h))

#print axioms extractClosures
end NF192.Direct
