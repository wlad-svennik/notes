module
public import NF185PARawPrefix
public import NF185PAStepTransport
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch.RegisterFields PA192.ModelSearch.Register185
namespace NF185PA.Boot
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
theorem prefix98 : iterate Registers.next (98:V) (config 40 1 (vector 0 0 0 2 0 0 0 0 0)) = Registers.margin V := by
  have h := rawPrefix98 (V:=V)
  rw [run_eq] at h
  simpa only [Registers.margin,Nat.cast_ofNat] using h
end NF185PA.Boot
#print axioms NF185PA.Boot.prefix98
