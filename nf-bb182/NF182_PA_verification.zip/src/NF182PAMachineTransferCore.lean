import NF182PARegisterHalting
import NF182PAComparison
import NF182PATapeCompiler
import NF185PAEightReverse
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
namespace NF182PA

/-- Object-level PA transfers literal blank-tape halting from 185 states to 182. -/
theorem machine_transfer_of_coverage (old : NF185PA.Symbolic.Coverage 0 2959)
    (new : Symbolic.Coverage 0 2971) : M6.PA.theory ⊢ NF185PA.H185 🡒 H182 := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff,LogicalConnective.HomClass.map_imply]
  intro h
  exact Symbolic.tape_of_coverage new
    (refutation_reaches_register_halt (fixed_goal_entails_new_goal
      (NF185PA.Reverse.halting_implies_pool old h)))

end NF182PA
#print axioms NF182PA.machine_transfer_of_coverage
