import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1920_0 : checkWitness 1920 false false 8950 = true := by decide +kernel
private theorem w1920_2 : checkWitness 1920 true false 8941 = true := by decide +kernel
private theorem cases1920 : checkFour 1920 (8950,0,8941,0) = true := by
  simp only [checkFour, w1920_0, w1920_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1920 : Coverage 1920 1921 := checkList_sound (ws:=[(8950,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases1920)
private theorem w1921_0 : checkWitness 1921 false false 86 = true := by decide +kernel
private theorem w1921_2 : checkWitness 1921 true false 86 = true := by decide +kernel
private theorem cases1921 : checkFour 1921 (86,0,86,0) = true := by
  simp only [checkFour, w1921_0, w1921_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1921 : Coverage 1921 1922 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1921)
private theorem w1922_0 : checkWitness 1922 false false 532 = true := by decide +kernel
private theorem w1922_1 : checkWitness 1922 false true 4628 = true := by decide +kernel
private theorem w1922_2 : checkWitness 1922 true false 532 = true := by decide +kernel
private theorem w1922_3 : checkWitness 1922 true true 4628 = true := by decide +kernel
private theorem cases1922 : checkFour 1922 (532,4628,532,4628) = true := by
  simp only [checkFour, w1922_0, w1922_1, w1922_2, w1922_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1922 : Coverage 1922 1923 := checkList_sound (ws:=[(532,4628,532,4628)]) (by simpa only [checkList, Bool.and_true] using cases1922)
private theorem w1923_0 : checkWitness 1923 false false 8890 = true := by decide +kernel
private theorem w1923_2 : checkWitness 1923 true false 8886 = true := by decide +kernel
private theorem cases1923 : checkFour 1923 (8890,0,8886,0) = true := by
  simp only [checkFour, w1923_0, w1923_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1923 : Coverage 1923 1924 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases1923)
private theorem w1924_0 : checkWitness 1924 false false 88 = true := by decide +kernel
private theorem w1924_2 : checkWitness 1924 true false 88 = true := by decide +kernel
private theorem cases1924 : checkFour 1924 (88,0,88,0) = true := by
  simp only [checkFour, w1924_0, w1924_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1924 : Coverage 1924 1925 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1924)
private theorem w1925_0 : checkWitness 1925 false false 576 = true := by decide +kernel
private theorem w1925_1 : checkWitness 1925 false true 4672 = true := by decide +kernel
private theorem w1925_2 : checkWitness 1925 true false 576 = true := by decide +kernel
private theorem w1925_3 : checkWitness 1925 true true 4672 = true := by decide +kernel
private theorem cases1925 : checkFour 1925 (576,4672,576,4672) = true := by
  simp only [checkFour, w1925_0, w1925_1, w1925_2, w1925_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1925 : Coverage 1925 1926 := checkList_sound (ws:=[(576,4672,576,4672)]) (by simpa only [checkList, Bool.and_true] using cases1925)
private theorem w1926_0 : checkWitness 1926 false false 8911 = true := by decide +kernel
private theorem w1926_2 : checkWitness 1926 true false 8907 = true := by decide +kernel
private theorem cases1926 : checkFour 1926 (8911,0,8907,0) = true := by
  simp only [checkFour, w1926_0, w1926_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1926 : Coverage 1926 1927 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases1926)
private theorem w1927_0 : checkWitness 1927 false false 8946 = true := by decide +kernel
private theorem w1927_2 : checkWitness 1927 true false 8937 = true := by decide +kernel
private theorem cases1927 : checkFour 1927 (8946,0,8937,0) = true := by
  simp only [checkFour, w1927_0, w1927_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1927 : Coverage 1927 1928 := checkList_sound (ws:=[(8946,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases1927)
private theorem w1928_0 : checkWitness 1928 false false 112 = true := by decide +kernel
private theorem w1928_2 : checkWitness 1928 true false 112 = true := by decide +kernel
private theorem cases1928 : checkFour 1928 (112,0,112,0) = true := by
  simp only [checkFour, w1928_0, w1928_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1928 : Coverage 1928 1929 := checkList_sound (ws:=[(112,0,112,0)]) (by simpa only [checkList, Bool.and_true] using cases1928)
private theorem w1929_0 : checkWitness 1929 false false 658 = true := by decide +kernel
private theorem w1929_1 : checkWitness 1929 false true 4750 = true := by decide +kernel
private theorem w1929_2 : checkWitness 1929 true false 649 = true := by decide +kernel
private theorem w1929_3 : checkWitness 1929 true true 4741 = true := by decide +kernel
private theorem cases1929 : checkFour 1929 (658,4750,649,4741) = true := by
  simp only [checkFour, w1929_0, w1929_1, w1929_2, w1929_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1929 : Coverage 1929 1930 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases1929)
private theorem w1930_0 : checkWitness 1930 false false 8907 = true := by decide +kernel
private theorem w1930_2 : checkWitness 1930 true false 8903 = true := by decide +kernel
private theorem cases1930 : checkFour 1930 (8907,0,8903,0) = true := by
  simp only [checkFour, w1930_0, w1930_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1930 : Coverage 1930 1931 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases1930)
private theorem w1931_0 : checkWitness 1931 false false 652 = true := by decide +kernel
private theorem w1931_1 : checkWitness 1931 false true 4744 = true := by decide +kernel
private theorem w1931_2 : checkWitness 1931 true false 643 = true := by decide +kernel
private theorem w1931_3 : checkWitness 1931 true true 4735 = true := by decide +kernel
private theorem cases1931 : checkFour 1931 (652,4744,643,4735) = true := by
  simp only [checkFour, w1931_0, w1931_1, w1931_2, w1931_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1931 : Coverage 1931 1932 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases1931)
private theorem w1932_0 : checkWitness 1932 false false 8876 = true := by decide +kernel
private theorem w1932_2 : checkWitness 1932 true false 8872 = true := by decide +kernel
private theorem cases1932 : checkFour 1932 (8876,0,8872,0) = true := by
  simp only [checkFour, w1932_0, w1932_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1932 : Coverage 1932 1933 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases1932)
private theorem w1933_0 : checkWitness 1933 false false 100 = true := by decide +kernel
private theorem w1933_2 : checkWitness 1933 true false 100 = true := by decide +kernel
private theorem cases1933 : checkFour 1933 (100,0,100,0) = true := by
  simp only [checkFour, w1933_0, w1933_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1933 : Coverage 1933 1934 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1933)
private theorem w1934_0 : checkWitness 1934 false false 92 = true := by decide +kernel
private theorem w1934_2 : checkWitness 1934 true false 92 = true := by decide +kernel
private theorem cases1934 : checkFour 1934 (92,0,92,0) = true := by
  simp only [checkFour, w1934_0, w1934_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1934 : Coverage 1934 1935 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1934)
private theorem w1935_0 : checkWitness 1935 false false 617 = true := by decide +kernel
private theorem w1935_1 : checkWitness 1935 false true 4701 = true := by decide +kernel
private theorem w1935_2 : checkWitness 1935 true false 617 = true := by decide +kernel
private theorem w1935_3 : checkWitness 1935 true true 4701 = true := by decide +kernel
private theorem cases1935 : checkFour 1935 (617,4701,617,4701) = true := by
  simp only [checkFour, w1935_0, w1935_1, w1935_2, w1935_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1935 : Coverage 1935 1936 := checkList_sound (ws:=[(617,4701,617,4701)]) (by simpa only [checkList, Bool.and_true] using cases1935)
private theorem w1936_0 : checkWitness 1936 false false 8870 = true := by decide +kernel
private theorem w1936_2 : checkWitness 1936 true false 8866 = true := by decide +kernel
private theorem cases1936 : checkFour 1936 (8870,0,8866,0) = true := by
  simp only [checkFour, w1936_0, w1936_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1936 : Coverage 1936 1937 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases1936)
private theorem w1937_0 : checkWitness 1937 false false 92 = true := by decide +kernel
private theorem w1937_2 : checkWitness 1937 true false 92 = true := by decide +kernel
private theorem cases1937 : checkFour 1937 (92,0,92,0) = true := by
  simp only [checkFour, w1937_0, w1937_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1937 : Coverage 1937 1938 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1937)
private theorem w1938_0 : checkWitness 1938 false false 615 = true := by decide +kernel
private theorem w1938_1 : checkWitness 1938 false true 4707 = true := by decide +kernel
private theorem w1938_2 : checkWitness 1938 true false 606 = true := by decide +kernel
private theorem w1938_3 : checkWitness 1938 true true 4698 = true := by decide +kernel
private theorem cases1938 : checkFour 1938 (615,4707,606,4698) = true := by
  simp only [checkFour, w1938_0, w1938_1, w1938_2, w1938_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1938 : Coverage 1938 1939 := checkList_sound (ws:=[(615,4707,606,4698)]) (by simpa only [checkList, Bool.and_true] using cases1938)
private theorem w1939_0 : checkWitness 1939 false false 8912 = true := by decide +kernel
private theorem w1939_2 : checkWitness 1939 true false 8903 = true := by decide +kernel
private theorem cases1939 : checkFour 1939 (8912,0,8903,0) = true := by
  simp only [checkFour, w1939_0, w1939_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1939 : Coverage 1939 1940 := checkList_sound (ws:=[(8912,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases1939)
private theorem w1940_0 : checkWitness 1940 false false 8858 = true := by decide +kernel
private theorem w1940_2 : checkWitness 1940 true false 8854 = true := by decide +kernel
private theorem cases1940 : checkFour 1940 (8858,0,8854,0) = true := by
  simp only [checkFour, w1940_0, w1940_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1940 : Coverage 1940 1941 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1940)
private theorem w1941_0 : checkWitness 1941 false false 86 = true := by decide +kernel
private theorem w1941_2 : checkWitness 1941 true false 86 = true := by decide +kernel
private theorem cases1941 : checkFour 1941 (86,0,86,0) = true := by
  simp only [checkFour, w1941_0, w1941_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1941 : Coverage 1941 1942 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1941)
private theorem w1942_0 : checkWitness 1942 false false 642 = true := by decide +kernel
private theorem w1942_1 : checkWitness 1942 false true 4734 = true := by decide +kernel
private theorem w1942_2 : checkWitness 1942 true false 633 = true := by decide +kernel
private theorem w1942_3 : checkWitness 1942 true true 4725 = true := by decide +kernel
private theorem cases1942 : checkFour 1942 (642,4734,633,4725) = true := by
  simp only [checkFour, w1942_0, w1942_1, w1942_2, w1942_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1942 : Coverage 1942 1943 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases1942)
private theorem w1943_0 : checkWitness 1943 false false 8919 = true := by decide +kernel
private theorem w1943_2 : checkWitness 1943 true false 8910 = true := by decide +kernel
private theorem cases1943 : checkFour 1943 (8919,0,8910,0) = true := by
  simp only [checkFour, w1943_0, w1943_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1943 : Coverage 1943 1944 := checkList_sound (ws:=[(8919,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases1943)
private theorem w1944_0 : checkWitness 1944 false false 70 = true := by decide +kernel
private theorem w1944_2 : checkWitness 1944 true false 70 = true := by decide +kernel
private theorem cases1944 : checkFour 1944 (70,0,70,0) = true := by
  simp only [checkFour, w1944_0, w1944_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1944 : Coverage 1944 1945 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases1944)
private theorem w1945_0 : checkWitness 1945 false false 506 = true := by decide +kernel
private theorem w1945_1 : checkWitness 1945 false true 4602 = true := by decide +kernel
private theorem w1945_2 : checkWitness 1945 true false 506 = true := by decide +kernel
private theorem w1945_3 : checkWitness 1945 true true 4602 = true := by decide +kernel
private theorem cases1945 : checkFour 1945 (506,4602,506,4602) = true := by
  simp only [checkFour, w1945_0, w1945_1, w1945_2, w1945_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1945 : Coverage 1945 1946 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases1945)
private theorem w1946_0 : checkWitness 1946 false false 8901 = true := by decide +kernel
private theorem w1946_2 : checkWitness 1946 true false 8897 = true := by decide +kernel
private theorem cases1946 : checkFour 1946 (8901,0,8897,0) = true := by
  simp only [checkFour, w1946_0, w1946_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1946 : Coverage 1946 1947 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1946)
private theorem w1947_0 : checkWitness 1947 false false 632 = true := by decide +kernel
private theorem w1947_1 : checkWitness 1947 false true 4728 = true := by decide +kernel
private theorem w1947_2 : checkWitness 1947 true false 623 = true := by decide +kernel
private theorem w1947_3 : checkWitness 1947 true true 4719 = true := by decide +kernel
private theorem cases1947 : checkFour 1947 (632,4728,623,4719) = true := by
  simp only [checkFour, w1947_0, w1947_1, w1947_2, w1947_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1947 : Coverage 1947 1948 := checkList_sound (ws:=[(632,4728,623,4719)]) (by simpa only [checkList, Bool.and_true] using cases1947)
private theorem w1948_0 : checkWitness 1948 false false 180 = true := by decide +kernel
private theorem w1948_2 : checkWitness 1948 true false 180 = true := by decide +kernel
private theorem cases1948 : checkFour 1948 (180,0,180,0) = true := by
  simp only [checkFour, w1948_0, w1948_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1948 : Coverage 1948 1949 := checkList_sound (ws:=[(180,0,180,0)]) (by simpa only [checkList, Bool.and_true] using cases1948)
private theorem w1949_0 : checkWitness 1949 false false 587 = true := by decide +kernel
private theorem w1949_1 : checkWitness 1949 false true 4675 = true := by decide +kernel
private theorem w1949_2 : checkWitness 1949 true false 587 = true := by decide +kernel
private theorem w1949_3 : checkWitness 1949 true true 4675 = true := by decide +kernel
private theorem cases1949 : checkFour 1949 (587,4675,587,4675) = true := by
  simp only [checkFour, w1949_0, w1949_1, w1949_2, w1949_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1949 : Coverage 1949 1950 := checkList_sound (ws:=[(587,4675,587,4675)]) (by simpa only [checkList, Bool.and_true] using cases1949)
private theorem w1950_0 : checkWitness 1950 false false 8916 = true := by decide +kernel
private theorem w1950_2 : checkWitness 1950 true false 8907 = true := by decide +kernel
private theorem cases1950 : checkFour 1950 (8916,0,8907,0) = true := by
  simp only [checkFour, w1950_0, w1950_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1950 : Coverage 1950 1951 := checkList_sound (ws:=[(8916,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases1950)
private theorem w1951_0 : checkWitness 1951 false false 88 = true := by decide +kernel
private theorem w1951_2 : checkWitness 1951 true false 88 = true := by decide +kernel
private theorem cases1951 : checkFour 1951 (88,0,88,0) = true := by
  simp only [checkFour, w1951_0, w1951_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1951 : Coverage 1951 1952 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1951)
theorem cover1920 : Coverage 1920 1952 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1920 one1921) (Coverage.join one1922 one1923)) (Coverage.join (Coverage.join one1924 one1925) (Coverage.join one1926 one1927))) (Coverage.join (Coverage.join (Coverage.join one1928 one1929) (Coverage.join one1930 one1931)) (Coverage.join (Coverage.join one1932 one1933) (Coverage.join one1934 one1935)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1936 one1937) (Coverage.join one1938 one1939)) (Coverage.join (Coverage.join one1940 one1941) (Coverage.join one1942 one1943))) (Coverage.join (Coverage.join (Coverage.join one1944 one1945) (Coverage.join one1946 one1947)) (Coverage.join (Coverage.join one1948 one1949) (Coverage.join one1950 one1951)))))
end NF182PA.Symbolic
