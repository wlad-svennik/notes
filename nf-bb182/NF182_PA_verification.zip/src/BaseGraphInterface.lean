import PeanoMinusSeed

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
namespace NF192.Direct.Baseline
variable {X : Type u} {mem : X→X→Prop} {D z S A B P : X}

/-- The reduct of the six set-valued witnesses uses the order already
employed by the represented order graph. -/
@[reducible] def numORing {N : Type u} (o : NumOps N) : ORingStructure N where
  zero := o.z
  one := o.s o.z
  add := o.add
  mul := o.mul
  lt x y := ∃k, o.add x (o.s k)=y

theorem graph_of_operations {o : NumOps (Dom mem D)} (L : OpsLaws mem D z S A B P o)
    [ORingStructure (Dom mem D)] (oz : o.z=0) (one : o.s o.z=1)
    (add : ∀x y,o.add x y=x+y) (mul : ∀x y,o.mul x y=x*y)
    (ord : ∀x y,(∃k,o.add x (o.s k)=y)↔x<y) :
    GraphMath mem (Subtype.val : Dom mem D → X) D z S A B := by
  constructor
  · exact Subtype.val_injective
  · intro x;exact ⟨fun hx=>⟨⟨x,hx⟩,rfl⟩,fun ⟨a,eq⟩=>eq ▸ a.2⟩
  · rw [←oz,L.zv]
  · intro y;rw [←L.zv,L.sv,one]
  · intro x y v;rw [L.av,add]
  · intro x y v;rw [L.mv,mul]
  · intro x y
    rw [←ord]
    constructor
    · rintro ⟨k,t,hk,ht,es,ea⟩
      let K : Dom mem D := ⟨k,hk⟩; let T : Dom mem D := ⟨t,ht⟩
      exact ⟨K,((L.sv K T).mp es).symm ▸ (L.av x T y).mp ea⟩
    · rintro ⟨k,eq⟩
      exact ⟨k.val,(o.s k).val,k.2,(o.s k).2,(L.sv _ _).mpr rfl,(L.av _ _ _).mpr eq⟩

def params (D z S A B P : X) : Fin 6 → X := ![P,B,A,S,z,D]

theorem body_of_ops {o : NumOps (Dom mem D)} (L : OpsLaws mem D z S A B P o) :
    letI := numORing o
    peanoMinusBody.truth mem (params D z S A B P) ↔ (Dom mem D)↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻ := by
  letI := numORing o
  exact baseBody_iff _ (graph_of_operations L rfl rfl (fun _ _=>rfl) (fun _ _=>rfl) (fun _ _=>Iff.rfl))

theorem native_body {Y : Type} [Nonempty Y] (M : NFUCut.Model Y) [Fact M.Infinity]
    {s a b p : Y} (L : OpsLaws M.mem M.nat M.zero s a b p (nativeNumbers M)) :
    peanoMinusBody.truth M.mem (params M.nat M.zero s a b p) := by
  have z : (nativeNumbers M).z = (0:M.Num) := rfl
  have one : (nativeNumbers M).s (nativeNumbers M).z=(1:M.Num) := by
    change M.nsucc (0:M.Num)=1
    simp [M.nsucc_eq_add_one]
  have add (x y : M.Num) : (nativeNumbers M).add x y=x+y := rfl
  have mul (x y : M.Num) : (nativeNumbers M).mul x y=x*y := rfl
  have less (x y : M.Num) : (∃ k,(nativeNumbers M).add x ((nativeNumbers M).s k)=y) ↔ x<y := by
    rw [PA192.NFUArithmetic.native_lt]
    change (∃k,x + M.nsucc k=y) ↔ _
    simp only [M.nsucc_eq_add_one]
  exact (baseBody_iff _ (graph_of_operations L z one add mul less)).mpr (PA192.NFUArithmetic.foundationBase M)

end NF192.Direct.Baseline
#print axioms NF192.Direct.Baseline.native_body
#print axioms NF192.Direct.Baseline.body_of_ops
