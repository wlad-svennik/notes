import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w896_0 : checkWitness 896 false false 100 = true := by decide +kernel
private theorem w896_2 : checkWitness 896 true false 100 = true := by decide +kernel
private theorem cases896 : checkFour 896 (100,0,100,0) = true := by
  simp only [checkFour, w896_0, w896_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one896 : Coverage 896 897 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases896)
private theorem w897_0 : checkWitness 897 false false 642 = true := by decide +kernel
private theorem w897_1 : checkWitness 897 false true 4734 = true := by decide +kernel
private theorem w897_2 : checkWitness 897 true false 633 = true := by decide +kernel
private theorem w897_3 : checkWitness 897 true true 4725 = true := by decide +kernel
private theorem cases897 : checkFour 897 (642,4734,633,4725) = true := by
  simp only [checkFour, w897_0, w897_1, w897_2, w897_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one897 : Coverage 897 898 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases897)
private theorem w898_0 : checkWitness 898 false false 8891 = true := by decide +kernel
private theorem w898_2 : checkWitness 898 true false 8887 = true := by decide +kernel
private theorem cases898 : checkFour 898 (8891,0,8887,0) = true := by
  simp only [checkFour, w898_0, w898_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one898 : Coverage 898 899 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases898)
private theorem w899_0 : checkWitness 899 false false 636 = true := by decide +kernel
private theorem w899_1 : checkWitness 899 false true 4728 = true := by decide +kernel
private theorem w899_2 : checkWitness 899 true false 627 = true := by decide +kernel
private theorem w899_3 : checkWitness 899 true true 4719 = true := by decide +kernel
private theorem cases899 : checkFour 899 (636,4728,627,4719) = true := by
  simp only [checkFour, w899_0, w899_1, w899_2, w899_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one899 : Coverage 899 900 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases899)
private theorem w900_0 : checkWitness 900 false false 8860 = true := by decide +kernel
private theorem w900_2 : checkWitness 900 true false 8856 = true := by decide +kernel
private theorem cases900 : checkFour 900 (8860,0,8856,0) = true := by
  simp only [checkFour, w900_0, w900_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one900 : Coverage 900 901 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases900)
private theorem w901_0 : checkWitness 901 false false 88 = true := by decide +kernel
private theorem w901_2 : checkWitness 901 true false 88 = true := by decide +kernel
private theorem cases901 : checkFour 901 (88,0,88,0) = true := by
  simp only [checkFour, w901_0, w901_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one901 : Coverage 901 902 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases901)
private theorem w902_0 : checkWitness 902 false false 80 = true := by decide +kernel
private theorem w902_2 : checkWitness 902 true false 80 = true := by decide +kernel
private theorem cases902 : checkFour 902 (80,0,80,0) = true := by
  simp only [checkFour, w902_0, w902_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one902 : Coverage 902 903 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases902)
private theorem w903_0 : checkWitness 903 false false 601 = true := by decide +kernel
private theorem w903_1 : checkWitness 903 false true 4685 = true := by decide +kernel
private theorem w903_2 : checkWitness 903 true false 601 = true := by decide +kernel
private theorem w903_3 : checkWitness 903 true true 4685 = true := by decide +kernel
private theorem cases903 : checkFour 903 (601,4685,601,4685) = true := by
  simp only [checkFour, w903_0, w903_1, w903_2, w903_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one903 : Coverage 903 904 := checkList_sound (ws:=[(601,4685,601,4685)]) (by simpa only [checkList, Bool.and_true] using cases903)
private theorem w904_0 : checkWitness 904 false false 8854 = true := by decide +kernel
private theorem w904_2 : checkWitness 904 true false 8850 = true := by decide +kernel
private theorem cases904 : checkFour 904 (8854,0,8850,0) = true := by
  simp only [checkFour, w904_0, w904_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one904 : Coverage 904 905 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases904)
private theorem w905_0 : checkWitness 905 false false 80 = true := by decide +kernel
private theorem w905_2 : checkWitness 905 true false 80 = true := by decide +kernel
private theorem cases905 : checkFour 905 (80,0,80,0) = true := by
  simp only [checkFour, w905_0, w905_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one905 : Coverage 905 906 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases905)
private theorem w906_0 : checkWitness 906 false false 606 = true := by decide +kernel
private theorem w906_1 : checkWitness 906 false true 4702 = true := by decide +kernel
private theorem w906_2 : checkWitness 906 true false 606 = true := by decide +kernel
private theorem w906_3 : checkWitness 906 true true 4702 = true := by decide +kernel
private theorem cases906 : checkFour 906 (606,4702,606,4702) = true := by
  simp only [checkFour, w906_0, w906_1, w906_2, w906_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one906 : Coverage 906 907 := checkList_sound (ws:=[(606,4702,606,4702)]) (by simpa only [checkList, Bool.and_true] using cases906)
private theorem w907_0 : checkWitness 907 false false 8922 = true := by decide +kernel
private theorem w907_2 : checkWitness 907 true false 8913 = true := by decide +kernel
private theorem cases907 : checkFour 907 (8922,0,8913,0) = true := by
  simp only [checkFour, w907_0, w907_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one907 : Coverage 907 908 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases907)
private theorem w908_0 : checkWitness 908 false false 8868 = true := by decide +kernel
private theorem w908_2 : checkWitness 908 true false 8864 = true := by decide +kernel
private theorem cases908 : checkFour 908 (8868,0,8864,0) = true := by
  simp only [checkFour, w908_0, w908_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one908 : Coverage 908 909 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases908)
private theorem w909_0 : checkWitness 909 false false 88 = true := by decide +kernel
private theorem w909_2 : checkWitness 909 true false 88 = true := by decide +kernel
private theorem cases909 : checkFour 909 (88,0,88,0) = true := by
  simp only [checkFour, w909_0, w909_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one909 : Coverage 909 910 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases909)
private theorem w910_0 : checkWitness 910 false false 652 = true := by decide +kernel
private theorem w910_1 : checkWitness 910 false true 4740 = true := by decide +kernel
private theorem w910_2 : checkWitness 910 true false 643 = true := by decide +kernel
private theorem w910_3 : checkWitness 910 true true 4731 = true := by decide +kernel
private theorem cases910 : checkFour 910 (652,4740,643,4731) = true := by
  simp only [checkFour, w910_0, w910_1, w910_2, w910_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one910 : Coverage 910 911 := checkList_sound (ws:=[(652,4740,643,4731)]) (by simpa only [checkList, Bool.and_true] using cases910)
private theorem w911_0 : checkWitness 911 false false 8910 = true := by decide +kernel
private theorem w911_2 : checkWitness 911 true false 8906 = true := by decide +kernel
private theorem cases911 : checkFour 911 (8910,0,8906,0) = true := by
  simp only [checkFour, w911_0, w911_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one911 : Coverage 911 912 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases911)
private theorem w912_0 : checkWitness 912 false false 78 = true := by decide +kernel
private theorem w912_2 : checkWitness 912 true false 78 = true := by decide +kernel
private theorem cases912 : checkFour 912 (78,0,78,0) = true := by
  simp only [checkFour, w912_0, w912_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one912 : Coverage 912 913 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases912)
private theorem w913_0 : checkWitness 913 false false 498 = true := by decide +kernel
private theorem w913_1 : checkWitness 913 false true 4594 = true := by decide +kernel
private theorem w913_2 : checkWitness 913 true false 498 = true := by decide +kernel
private theorem w913_3 : checkWitness 913 true true 4594 = true := by decide +kernel
private theorem cases913 : checkFour 913 (498,4594,498,4594) = true := by
  simp only [checkFour, w913_0, w913_1, w913_2, w913_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one913 : Coverage 913 914 := checkList_sound (ws:=[(498,4594,498,4594)]) (by simpa only [checkList, Bool.and_true] using cases913)
private theorem w914_0 : checkWitness 914 false false 8893 = true := by decide +kernel
private theorem w914_2 : checkWitness 914 true false 8889 = true := by decide +kernel
private theorem cases914 : checkFour 914 (8893,0,8889,0) = true := by
  simp only [checkFour, w914_0, w914_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one914 : Coverage 914 915 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases914)
private theorem w915_0 : checkWitness 915 false false 624 = true := by decide +kernel
private theorem w915_1 : checkWitness 915 false true 4720 = true := by decide +kernel
private theorem w915_2 : checkWitness 915 true false 615 = true := by decide +kernel
private theorem w915_3 : checkWitness 915 true true 4711 = true := by decide +kernel
private theorem cases915 : checkFour 915 (624,4720,615,4711) = true := by
  simp only [checkFour, w915_0, w915_1, w915_2, w915_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one915 : Coverage 915 916 := checkList_sound (ws:=[(624,4720,615,4711)]) (by simpa only [checkList, Bool.and_true] using cases915)
private theorem w916_0 : checkWitness 916 false false 178 = true := by decide +kernel
private theorem w916_2 : checkWitness 916 true false 178 = true := by decide +kernel
private theorem cases916 : checkFour 916 (178,0,178,0) = true := by
  simp only [checkFour, w916_0, w916_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one916 : Coverage 916 917 := checkList_sound (ws:=[(178,0,178,0)]) (by simpa only [checkList, Bool.and_true] using cases916)
private theorem w917_0 : checkWitness 917 false false 579 = true := by decide +kernel
private theorem w917_1 : checkWitness 917 false true 4667 = true := by decide +kernel
private theorem w917_2 : checkWitness 917 true false 579 = true := by decide +kernel
private theorem w917_3 : checkWitness 917 true true 4667 = true := by decide +kernel
private theorem cases917 : checkFour 917 (579,4667,579,4667) = true := by
  simp only [checkFour, w917_0, w917_1, w917_2, w917_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one917 : Coverage 917 918 := checkList_sound (ws:=[(579,4667,579,4667)]) (by simpa only [checkList, Bool.and_true] using cases917)
private theorem w918_0 : checkWitness 918 false false 8908 = true := by decide +kernel
private theorem w918_2 : checkWitness 918 true false 8899 = true := by decide +kernel
private theorem cases918 : checkFour 918 (8908,0,8899,0) = true := by
  simp only [checkFour, w918_0, w918_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one918 : Coverage 918 919 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases918)
private theorem w919_0 : checkWitness 919 false false 82 = true := by decide +kernel
private theorem w919_2 : checkWitness 919 true false 82 = true := by decide +kernel
private theorem cases919 : checkFour 919 (82,0,82,0) = true := by
  simp only [checkFour, w919_0, w919_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one919 : Coverage 919 920 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases919)
private theorem w920_0 : checkWitness 920 false false 74 = true := by decide +kernel
private theorem w920_2 : checkWitness 920 true false 74 = true := by decide +kernel
private theorem cases920 : checkFour 920 (74,0,74,0) = true := by
  simp only [checkFour, w920_0, w920_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one920 : Coverage 920 921 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases920)
private theorem w921_0 : checkWitness 921 false false 585 = true := by decide +kernel
private theorem w921_1 : checkWitness 921 false true 4677 = true := by decide +kernel
private theorem w921_2 : checkWitness 921 true false 585 = true := by decide +kernel
private theorem w921_3 : checkWitness 921 true true 4677 = true := by decide +kernel
private theorem cases921 : checkFour 921 (585,4677,585,4677) = true := by
  simp only [checkFour, w921_0, w921_1, w921_2, w921_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one921 : Coverage 921 922 := checkList_sound (ws:=[(585,4677,585,4677)]) (by simpa only [checkList, Bool.and_true] using cases921)
private theorem w922_0 : checkWitness 922 false false 8846 = true := by decide +kernel
private theorem w922_2 : checkWitness 922 true false 8842 = true := by decide +kernel
private theorem cases922 : checkFour 922 (8846,0,8842,0) = true := by
  simp only [checkFour, w922_0, w922_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one922 : Coverage 922 923 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases922)
private theorem w923_0 : checkWitness 923 false false 74 = true := by decide +kernel
private theorem w923_2 : checkWitness 923 true false 74 = true := by decide +kernel
private theorem cases923 : checkFour 923 (74,0,74,0) = true := by
  simp only [checkFour, w923_0, w923_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one923 : Coverage 923 924 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases923)
private theorem w924_0 : checkWitness 924 false false 546 = true := by decide +kernel
private theorem w924_1 : checkWitness 924 false true 4642 = true := by decide +kernel
private theorem w924_2 : checkWitness 924 true false 546 = true := by decide +kernel
private theorem w924_3 : checkWitness 924 true true 4642 = true := by decide +kernel
private theorem cases924 : checkFour 924 (546,4642,546,4642) = true := by
  simp only [checkFour, w924_0, w924_1, w924_2, w924_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one924 : Coverage 924 925 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases924)
private theorem w925_0 : checkWitness 925 false false 8881 = true := by decide +kernel
private theorem w925_2 : checkWitness 925 true false 8877 = true := by decide +kernel
private theorem cases925 : checkFour 925 (8881,0,8877,0) = true := by
  simp only [checkFour, w925_0, w925_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one925 : Coverage 925 926 := checkList_sound (ws:=[(8881,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases925)
private theorem w926_0 : checkWitness 926 false false 8916 = true := by decide +kernel
private theorem w926_2 : checkWitness 926 true false 8907 = true := by decide +kernel
private theorem cases926 : checkFour 926 (8916,0,8907,0) = true := by
  simp only [checkFour, w926_0, w926_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one926 : Coverage 926 927 := checkList_sound (ws:=[(8916,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases926)
private theorem w927_0 : checkWitness 927 false false 92 = true := by decide +kernel
private theorem w927_2 : checkWitness 927 true false 92 = true := by decide +kernel
private theorem cases927 : checkFour 927 (92,0,92,0) = true := by
  simp only [checkFour, w927_0, w927_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one927 : Coverage 927 928 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases927)
theorem cover0896 : Coverage 896 928 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one896 one897) (Coverage.join one898 one899)) (Coverage.join (Coverage.join one900 one901) (Coverage.join one902 one903))) (Coverage.join (Coverage.join (Coverage.join one904 one905) (Coverage.join one906 one907)) (Coverage.join (Coverage.join one908 one909) (Coverage.join one910 one911)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one912 one913) (Coverage.join one914 one915)) (Coverage.join (Coverage.join one916 one917) (Coverage.join one918 one919))) (Coverage.join (Coverage.join (Coverage.join one920 one921) (Coverage.join one922 one923)) (Coverage.join (Coverage.join one924 one925) (Coverage.join one926 one927)))))
end NF182PA.Symbolic
