import NF182PAProofRows
import NF182PAPresentation
import NF182PAFixedSound

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Ground PA192.Literal
open NF185PA.Comparison

namespace NF182PA
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- A represented model of pure NF in the ambient model of PA. -/
theorem represented_nf_of_no_refutation (hd : ¬Pool.Pr (∅ : V) goal) : Presented 𝗡𝗙 V := by
  obtain ⟨r,ne⟩ := Pool.definable_countermodel hd
  let S : Signature V := ⟨q,app,witness⟩
  letI : Language.DefinableFunction₂ ℒₒᵣ S.app := PA192.Literal.defApp
  obtain ⟨X,mem,n,h,⟨p⟩⟩ := Chart.presented_rows (S:=S) r ne
  letI := mem
  letI := n
  letI := h
  exact represented_interpretation SetTheory.nfuInterpretsNF p (definable_set_eval p)

/-- Every internal refutation in the 185 pool yields a refutation in the 182 pool. -/
theorem fixed_goal_entails_new_goal (old : NF185PA.Pool.Pr (∅ : V) goal) :
    Pool.Pr (∅ : V) goal := by
  classical
  by_contra no
  obtain ⟨S,E,ap,h,rel,rows,sep⟩ := Fixed.rows_of_presentation (represented_nf_of_no_refutation no)
  letI := ap
  letI := h
  letI := rel
  exact Fixed.excludes_proof S E rows sep old

end NF182PA
#print axioms NF182PA.fixed_goal_entails_new_goal
