import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2272_0 : checkWitness 2272 false false 64 = true := by decide +kernel
private theorem w2272_2 : checkWitness 2272 true false 64 = true := by decide +kernel
private theorem cases2272 : checkFour 2272 (64,0,64,0) = true := by
  simp only [checkFour, w2272_0, w2272_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2272 : Coverage 2272 2273 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2272)
private theorem w2273_0 : checkWitness 2273 false false 605 = true := by decide +kernel
private theorem w2273_1 : checkWitness 2273 false true 4693 = true := by decide +kernel
private theorem w2273_2 : checkWitness 2273 true false 605 = true := by decide +kernel
private theorem w2273_3 : checkWitness 2273 true true 4693 = true := by decide +kernel
private theorem cases2273 : checkFour 2273 (605,4693,605,4693) = true := by
  simp only [checkFour, w2273_0, w2273_1, w2273_2, w2273_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2273 : Coverage 2273 2274 := checkList_sound (ws:=[(605,4693,605,4693)]) (by simpa only [checkList, Bool.and_true] using cases2273)
private theorem w2274_0 : checkWitness 2274 false false 8878 = true := by decide +kernel
private theorem w2274_2 : checkWitness 2274 true false 8874 = true := by decide +kernel
private theorem cases2274 : checkFour 2274 (8878,0,8874,0) = true := by
  simp only [checkFour, w2274_0, w2274_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2274 : Coverage 2274 2275 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases2274)
private theorem w2275_0 : checkWitness 2275 false false 8874 = true := by decide +kernel
private theorem w2275_2 : checkWitness 2275 true false 8870 = true := by decide +kernel
private theorem cases2275 : checkFour 2275 (8874,0,8870,0) = true := by
  simp only [checkFour, w2275_0, w2275_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2275 : Coverage 2275 2276 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases2275)
private theorem w2276_0 : checkWitness 2276 false false 78 = true := by decide +kernel
private theorem w2276_2 : checkWitness 2276 true false 78 = true := by decide +kernel
private theorem cases2276 : checkFour 2276 (78,0,78,0) = true := by
  simp only [checkFour, w2276_0, w2276_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2276 : Coverage 2276 2277 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2276)
private theorem w2277_0 : checkWitness 2277 false false 8898 = true := by decide +kernel
private theorem w2277_2 : checkWitness 2277 true false 8894 = true := by decide +kernel
private theorem cases2277 : checkFour 2277 (8898,0,8894,0) = true := by
  simp only [checkFour, w2277_0, w2277_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2277 : Coverage 2277 2278 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2277)
private theorem w2278_0 : checkWitness 2278 false false 564 = true := by decide +kernel
private theorem w2278_1 : checkWitness 2278 false true 4660 = true := by decide +kernel
private theorem w2278_2 : checkWitness 2278 true false 564 = true := by decide +kernel
private theorem w2278_3 : checkWitness 2278 true true 4660 = true := by decide +kernel
private theorem cases2278 : checkFour 2278 (564,4660,564,4660) = true := by
  simp only [checkFour, w2278_0, w2278_1, w2278_2, w2278_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2278 : Coverage 2278 2279 := checkList_sound (ws:=[(564,4660,564,4660)]) (by simpa only [checkList, Bool.and_true] using cases2278)
private theorem w2279_0 : checkWitness 2279 false false 8990 = true := by decide +kernel
private theorem w2279_2 : checkWitness 2279 true false 8981 = true := by decide +kernel
private theorem cases2279 : checkFour 2279 (8990,0,8981,0) = true := by
  simp only [checkFour, w2279_0, w2279_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2279 : Coverage 2279 2280 := checkList_sound (ws:=[(8990,0,8981,0)]) (by simpa only [checkList, Bool.and_true] using cases2279)
private theorem w2280_0 : checkWitness 2280 false false 76 = true := by decide +kernel
private theorem w2280_2 : checkWitness 2280 true false 76 = true := by decide +kernel
private theorem cases2280 : checkFour 2280 (76,0,76,0) = true := by
  simp only [checkFour, w2280_0, w2280_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2280 : Coverage 2280 2281 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2280)
private theorem w2281_0 : checkWitness 2281 false false 572 = true := by decide +kernel
private theorem w2281_1 : checkWitness 2281 false true 4668 = true := by decide +kernel
private theorem w2281_2 : checkWitness 2281 true false 572 = true := by decide +kernel
private theorem w2281_3 : checkWitness 2281 true true 4668 = true := by decide +kernel
private theorem cases2281 : checkFour 2281 (572,4668,572,4668) = true := by
  simp only [checkFour, w2281_0, w2281_1, w2281_2, w2281_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2281 : Coverage 2281 2282 := checkList_sound (ws:=[(572,4668,572,4668)]) (by simpa only [checkList, Bool.and_true] using cases2281)
private theorem w2282_0 : checkWitness 2282 false false 8930 = true := by decide +kernel
private theorem w2282_2 : checkWitness 2282 true false 8926 = true := by decide +kernel
private theorem cases2282 : checkFour 2282 (8930,0,8926,0) = true := by
  simp only [checkFour, w2282_0, w2282_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2282 : Coverage 2282 2283 := checkList_sound (ws:=[(8930,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases2282)
private theorem w2283_0 : checkWitness 2283 false false 78 = true := by decide +kernel
private theorem w2283_2 : checkWitness 2283 true false 78 = true := by decide +kernel
private theorem cases2283 : checkFour 2283 (78,0,78,0) = true := by
  simp only [checkFour, w2283_0, w2283_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2283 : Coverage 2283 2284 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2283)
private theorem w2284_0 : checkWitness 2284 false false 616 = true := by decide +kernel
private theorem w2284_1 : checkWitness 2284 false true 4712 = true := by decide +kernel
private theorem w2284_2 : checkWitness 2284 true false 616 = true := by decide +kernel
private theorem w2284_3 : checkWitness 2284 true true 4712 = true := by decide +kernel
private theorem cases2284 : checkFour 2284 (616,4712,616,4712) = true := by
  simp only [checkFour, w2284_0, w2284_1, w2284_2, w2284_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2284 : Coverage 2284 2285 := checkList_sound (ws:=[(616,4712,616,4712)]) (by simpa only [checkList, Bool.and_true] using cases2284)
private theorem w2285_0 : checkWitness 2285 false false 8951 = true := by decide +kernel
private theorem w2285_2 : checkWitness 2285 true false 8947 = true := by decide +kernel
private theorem cases2285 : checkFour 2285 (8951,0,8947,0) = true := by
  simp only [checkFour, w2285_0, w2285_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2285 : Coverage 2285 2286 := checkList_sound (ws:=[(8951,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2285)
private theorem w2286_0 : checkWitness 2286 false false 8986 = true := by decide +kernel
private theorem w2286_2 : checkWitness 2286 true false 8977 = true := by decide +kernel
private theorem cases2286 : checkFour 2286 (8986,0,8977,0) = true := by
  simp only [checkFour, w2286_0, w2286_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2286 : Coverage 2286 2287 := checkList_sound (ws:=[(8986,0,8977,0)]) (by simpa only [checkList, Bool.and_true] using cases2286)
private theorem w2287_0 : checkWitness 2287 false false 102 = true := by decide +kernel
private theorem w2287_2 : checkWitness 2287 true false 102 = true := by decide +kernel
private theorem cases2287 : checkFour 2287 (102,0,102,0) = true := by
  simp only [checkFour, w2287_0, w2287_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2287 : Coverage 2287 2288 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases2287)
private theorem w2288_0 : checkWitness 2288 false false 698 = true := by decide +kernel
private theorem w2288_1 : checkWitness 2288 false true 4790 = true := by decide +kernel
private theorem w2288_2 : checkWitness 2288 true false 689 = true := by decide +kernel
private theorem w2288_3 : checkWitness 2288 true true 4781 = true := by decide +kernel
private theorem cases2288 : checkFour 2288 (698,4790,689,4781) = true := by
  simp only [checkFour, w2288_0, w2288_1, w2288_2, w2288_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2288 : Coverage 2288 2289 := checkList_sound (ws:=[(698,4790,689,4781)]) (by simpa only [checkList, Bool.and_true] using cases2288)
private theorem w2289_0 : checkWitness 2289 false false 8947 = true := by decide +kernel
private theorem w2289_2 : checkWitness 2289 true false 8943 = true := by decide +kernel
private theorem cases2289 : checkFour 2289 (8947,0,8943,0) = true := by
  simp only [checkFour, w2289_0, w2289_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2289 : Coverage 2289 2290 := checkList_sound (ws:=[(8947,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases2289)
private theorem w2290_0 : checkWitness 2290 false false 692 = true := by decide +kernel
private theorem w2290_1 : checkWitness 2290 false true 4784 = true := by decide +kernel
private theorem w2290_2 : checkWitness 2290 true false 683 = true := by decide +kernel
private theorem w2290_3 : checkWitness 2290 true true 4775 = true := by decide +kernel
private theorem cases2290 : checkFour 2290 (692,4784,683,4775) = true := by
  simp only [checkFour, w2290_0, w2290_1, w2290_2, w2290_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2290 : Coverage 2290 2291 := checkList_sound (ws:=[(692,4784,683,4775)]) (by simpa only [checkList, Bool.and_true] using cases2290)
private theorem w2291_0 : checkWitness 2291 false false 8916 = true := by decide +kernel
private theorem w2291_2 : checkWitness 2291 true false 8912 = true := by decide +kernel
private theorem cases2291 : checkFour 2291 (8916,0,8912,0) = true := by
  simp only [checkFour, w2291_0, w2291_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2291 : Coverage 2291 2292 := checkList_sound (ws:=[(8916,0,8912,0)]) (by simpa only [checkList, Bool.and_true] using cases2291)
private theorem w2292_0 : checkWitness 2292 false false 90 = true := by decide +kernel
private theorem w2292_2 : checkWitness 2292 true false 90 = true := by decide +kernel
private theorem cases2292 : checkFour 2292 (90,0,90,0) = true := by
  simp only [checkFour, w2292_0, w2292_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2292 : Coverage 2292 2293 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases2292)
private theorem w2293_0 : checkWitness 2293 false false 82 = true := by decide +kernel
private theorem w2293_2 : checkWitness 2293 true false 82 = true := by decide +kernel
private theorem cases2293 : checkFour 2293 (82,0,82,0) = true := by
  simp only [checkFour, w2293_0, w2293_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2293 : Coverage 2293 2294 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2293)
private theorem w2294_0 : checkWitness 2294 false false 657 = true := by decide +kernel
private theorem w2294_1 : checkWitness 2294 false true 4741 = true := by decide +kernel
private theorem w2294_2 : checkWitness 2294 true false 657 = true := by decide +kernel
private theorem w2294_3 : checkWitness 2294 true true 4741 = true := by decide +kernel
private theorem cases2294 : checkFour 2294 (657,4741,657,4741) = true := by
  simp only [checkFour, w2294_0, w2294_1, w2294_2, w2294_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2294 : Coverage 2294 2295 := checkList_sound (ws:=[(657,4741,657,4741)]) (by simpa only [checkList, Bool.and_true] using cases2294)
private theorem w2295_0 : checkWitness 2295 false false 8910 = true := by decide +kernel
private theorem w2295_2 : checkWitness 2295 true false 8906 = true := by decide +kernel
private theorem cases2295 : checkFour 2295 (8910,0,8906,0) = true := by
  simp only [checkFour, w2295_0, w2295_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2295 : Coverage 2295 2296 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2295)
private theorem w2296_0 : checkWitness 2296 false false 82 = true := by decide +kernel
private theorem w2296_2 : checkWitness 2296 true false 82 = true := by decide +kernel
private theorem cases2296 : checkFour 2296 (82,0,82,0) = true := by
  simp only [checkFour, w2296_0, w2296_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2296 : Coverage 2296 2297 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2296)
private theorem w2297_0 : checkWitness 2297 false false 655 = true := by decide +kernel
private theorem w2297_1 : checkWitness 2297 false true 4747 = true := by decide +kernel
private theorem w2297_2 : checkWitness 2297 true false 646 = true := by decide +kernel
private theorem w2297_3 : checkWitness 2297 true true 4738 = true := by decide +kernel
private theorem cases2297 : checkFour 2297 (655,4747,646,4738) = true := by
  simp only [checkFour, w2297_0, w2297_1, w2297_2, w2297_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2297 : Coverage 2297 2298 := checkList_sound (ws:=[(655,4747,646,4738)]) (by simpa only [checkList, Bool.and_true] using cases2297)
private theorem w2298_0 : checkWitness 2298 false false 8952 = true := by decide +kernel
private theorem w2298_2 : checkWitness 2298 true false 8943 = true := by decide +kernel
private theorem cases2298 : checkFour 2298 (8952,0,8943,0) = true := by
  simp only [checkFour, w2298_0, w2298_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2298 : Coverage 2298 2299 := checkList_sound (ws:=[(8952,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases2298)
private theorem w2299_0 : checkWitness 2299 false false 8898 = true := by decide +kernel
private theorem w2299_2 : checkWitness 2299 true false 8894 = true := by decide +kernel
private theorem cases2299 : checkFour 2299 (8898,0,8894,0) = true := by
  simp only [checkFour, w2299_0, w2299_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2299 : Coverage 2299 2300 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2299)
private theorem w2300_0 : checkWitness 2300 false false 76 = true := by decide +kernel
private theorem w2300_2 : checkWitness 2300 true false 76 = true := by decide +kernel
private theorem cases2300 : checkFour 2300 (76,0,76,0) = true := by
  simp only [checkFour, w2300_0, w2300_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2300 : Coverage 2300 2301 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2300)
private theorem w2301_0 : checkWitness 2301 false false 682 = true := by decide +kernel
private theorem w2301_1 : checkWitness 2301 false true 4774 = true := by decide +kernel
private theorem w2301_2 : checkWitness 2301 true false 673 = true := by decide +kernel
private theorem w2301_3 : checkWitness 2301 true true 4765 = true := by decide +kernel
private theorem cases2301 : checkFour 2301 (682,4774,673,4765) = true := by
  simp only [checkFour, w2301_0, w2301_1, w2301_2, w2301_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2301 : Coverage 2301 2302 := checkList_sound (ws:=[(682,4774,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases2301)
private theorem w2302_0 : checkWitness 2302 false false 8959 = true := by decide +kernel
private theorem w2302_2 : checkWitness 2302 true false 8950 = true := by decide +kernel
private theorem cases2302 : checkFour 2302 (8959,0,8950,0) = true := by
  simp only [checkFour, w2302_0, w2302_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2302 : Coverage 2302 2303 := checkList_sound (ws:=[(8959,0,8950,0)]) (by simpa only [checkList, Bool.and_true] using cases2302)
private theorem w2303_0 : checkWitness 2303 false false 60 = true := by decide +kernel
private theorem w2303_2 : checkWitness 2303 true false 60 = true := by decide +kernel
private theorem cases2303 : checkFour 2303 (60,0,60,0) = true := by
  simp only [checkFour, w2303_0, w2303_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2303 : Coverage 2303 2304 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2303)
theorem cover2272 : Coverage 2272 2304 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2272 one2273) (Coverage.join one2274 one2275)) (Coverage.join (Coverage.join one2276 one2277) (Coverage.join one2278 one2279))) (Coverage.join (Coverage.join (Coverage.join one2280 one2281) (Coverage.join one2282 one2283)) (Coverage.join (Coverage.join one2284 one2285) (Coverage.join one2286 one2287)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2288 one2289) (Coverage.join one2290 one2291)) (Coverage.join (Coverage.join one2292 one2293) (Coverage.join one2294 one2295))) (Coverage.join (Coverage.join (Coverage.join one2296 one2297) (Coverage.join one2298 one2299)) (Coverage.join (Coverage.join one2300 one2301) (Coverage.join one2302 one2303)))))
end NF182PA.Symbolic
