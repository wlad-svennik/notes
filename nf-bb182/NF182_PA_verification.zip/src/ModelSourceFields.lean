module
public import ModelFold

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Numerals.FoundationRoute
set_option maxHeartbeats 2500000
set_option maxRecDepth 8000

namespace PA192.ModelSearch.RegisterFields

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

section Unary
variable (f : V → V) [Language.DefinableFunction₁ ℒₒᵣ f]

/-- A single internal iteration, jointly definable in the length and initial argument. -/
noncomputable def iterate (n x : V) : V := Iteration.value x f n

instance iterateDef : Language.DefinableFunction₂ ℒₒᵣ (iterate f) := by
  apply Language.Definable.of_iff (Q := fun v : Fin 3 → V => Iteration.Graph (v 2) f (v 0) (v 1))
  · unfold Iteration.Graph Iteration.History
    definability
  · intro v
    exact (Iteration.graph_iff (v 2) f).symm

@[simp] theorem iterate_zero (x : V) : iterate f 0 x = x := Iteration.value_zero x f

theorem iterate_succ (n x : V) : iterate f (n+1) x = f (iterate f n x) := Iteration.value_succ x f n

/-- Concatenation is valid also at nonstandard lengths. -/
theorem iterate_add (a x : V) : ∀ b : V, iterate f (a+b) x = iterate f b (iterate f a x) := by
  apply modelInduct
  · definability
  · simp
  · intro b ih
    rw [←add_assoc,iterate_succ,iterate_succ,ih]

theorem iterate_succ_left (n x : V) : iterate f (n+1) x = iterate f n (f x) := by
  have h := iterate_add f 1 x n
  rw [add_comm (1 : V) n] at h
  have one : iterate f 1 x = f x := by simpa using iterate_succ f (0 : V) x
  simpa [one] using h

end Unary


theorem iterate_cancel (f g : V → V) [Language.DefinableFunction₁ ℒₒᵣ f]
    [Language.DefinableFunction₁ ℒₒᵣ g] (inverse : ∀ x, g (f x) = x) (x : V) :
    ∀ n : V, iterate g n (iterate f n x) = x := by
  apply modelInduct
  · definability
  · simp
  · intro n ih
    rw [iterate_succ_left g,iterate_succ,inverse,ih]

noncomputable def zeroPair (w : V) : V := cantor 0 (cantor 0 w)
noncomputable def consumePair (z : V) : V := right (right z)
instance zeroPairDef : Language.DefinableFunction₁ ℒₒᵣ (zeroPair (V:=V)) := by unfold zeroPair; definability
instance consumePairDef : Language.DefinableFunction₁ ℒₒᵣ (consumePair (V:=V)) := by unfold consumePair; definability

noncomputable def zeroBatches (n tail : V) : V := iterate zeroPair n tail
noncomputable def unread (n code : V) : V := iterate consumePair n code
instance zeroBatchesDef : Language.DefinableFunction₂ ℒₒᵣ (zeroBatches (V:=V)) := by unfold zeroBatches; infer_instance
instance unreadDef : Language.DefinableFunction₂ ℒₒᵣ (unread (V:=V)) := by unfold unread; infer_instance

@[simp] theorem consume_zeroPair (w : V) : consumePair (zeroPair w) = w := by simp [consumePair,zeroPair]
@[simp] theorem zeroBatches_zero (w : V) : zeroBatches 0 w = w := iterate_zero _ _
theorem zeroBatches_succ (n w : V) : zeroBatches (n+1) w = cantor 0 (cantor 0 (zeroBatches n w)) := iterate_succ _ _ _

theorem unread_zeroBatches (n w : V) : unread n (zeroBatches n w) = w :=
  iterate_cancel zeroPair consumePair consume_zeroPair w n

theorem zeroBatches_bound (w : V) : ∀ n : V, w ≤ zeroBatches n w := by
  apply modelInduct
  · definability
  · simp
  · intro n ih
    rw [zeroBatches_succ]
    exact le_trans ih (le_trans (cantor_ge_right _ _) (cantor_ge_right _ _))

/-- The finite tree compiler uses `c` pairs of zero fields and arbitrary continuation `w`. -/
noncomputable def literalAXInput (outer b delta c w : V) : V :=
  cantor (c+2) (cantor outer (cantor b (cantor delta (zeroBatches c w))))

theorem literalAX_parse (outer b delta c w : V) :
    let code := literalAXInput outer b delta c w
    left code = c+2 ∧ left (right code) = outer ∧
    left (right (right code)) = b ∧ left (right (right (right code))) = delta ∧
    unread c (right (right (right (right code)))) = w := by
  simp [literalAXInput,unread_zeroBatches]

end PA192.ModelSearch.RegisterFields
#print axioms PA192.ModelSearch.RegisterFields.iterateDef
#print axioms PA192.ModelSearch.RegisterFields.literalAX_parse
