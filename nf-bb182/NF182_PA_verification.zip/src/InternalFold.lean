import DefinableIteration
import Foundation.FirstOrder.Arithmetic.HFS.Vec

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Numerals.FoundationRoute
namespace NF192.Internal
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

instance plainNth : Language.DefinableFunction₂ ℒₒᵣ (nth : V → V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := nthDef.val) ⟨(nth_defined (V := V)).df⟩
instance plainLen : Language.DefinableFunction₁ ℒₒᵣ (len : V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := lenDef.val) ⟨(len_defined (V := V)).df⟩
instance plainConcat : Language.DefinableFunction₂ ℒₒᵣ (concat : V → V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := concatDef.val) ⟨(concat_defined (V := V)).df⟩

variable (step : V → V → V) [Language.DefinableFunction₂ ℒₒᵣ step]
noncomputable def advance (t : V) := concat t (step (len t) t)
instance advanceDef : Language.DefinableFunction₁ ℒₒᵣ (advance step) := by
  unfold advance;definability

noncomputable def table (n : V) := Iteration.value 0 (advance step) n
instance tableDef : Language.DefinableFunction₁ ℒₒᵣ (table step) := Iteration.valueDef 0 _
@[simp] theorem table_zero : table step 0 = 0 := Iteration.value_zero 0 _
theorem table_succ (n : V) : table step (n+1) = concat (table step n) (step (len (table step n)) (table step n)) :=
  Iteration.value_succ 0 _ n

theorem table_length (n : V) : len (table step n)=n := by
  apply induction_of_arith (P:=fun k => len (table step k)=k)
  · apply arithPred_of_definable;definability
  · simp only [rob,table_zero];simp
  · intro k ih
    change len (table step (k+1))=k+1
    rw [table_succ];simp [ih]

noncomputable def fold (n : V) := (table step (n+1)).[n]
instance foldDef : Language.DefinableFunction₁ ℒₒᵣ (fold step) := by
  unfold fold;definability

theorem fold_rule (n : V) : fold step n=step n (table step n) := by
  unfold fold;rw [table_succ,concat_nth_len' _ _ (table_length step n),table_length]

/-- A nonstandard syntax code can read every already-computed child in the same table. -/
theorem read_child (i n : V) (hi : i<n) : (table step n).[i]=fold step i := by
  have allk : ∀ k:V,i<k → (table step k).[i]=fold step i := by
    apply induction_of_arith
    · apply arithPred_of_definable;definability
    · intro h;exact False.elim ((not_lt_of_ge (show (0:V)≤i from zero_le)) h)
    · intro k ih h
      change (table step (k+1)).[i]=fold step i
      rcases lt_or_eq_of_le (lt_succ_iff_le.mp h) with lt | rfl
      · rw [table_succ,concat_nth_lt _ _ (by simpa only [table_length] using lt)]
        exact ih lt
      · rfl
  exact allk n hi

#print axioms fold_rule
#print axioms read_child
end NF192.Internal
