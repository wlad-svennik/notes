import NativeArchive
import SeedFoundation
import NFUJensen

namespace FFL.FirstOrder
open NF192.Direct
open SetTheory

theorem jensen_proves_set (φ : SetForm 0)
    (hn : ∀ (V : Type) [Nonempty V] (M : NFUCut.Model V) [Fact M.Infinity],
      φ.truth M.mem Fin.elim0) : 𝗡𝗙𝗨𝗜 ⊢ nativeFFL φ := by
  apply Theory.Proof.complete_on_eq_models.{_,0}
  intro V _ s _ hT
  have hU : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙𝗨 := models_of_ss hT Set.subset_union_left
  obtain ⟨e,he⟩ := exists_empty hU
  let M := modelOfJensenNFU hU e he
  letI : Fact M.Infinity := ⟨modelOfJensenNFU_infinity hU e he (models_theory_iff.mp hT _ (Or.inr rfl))⟩
  apply models_iff.mpr
  exact (nativeFFL_eval φ _).mpr (hn V M)

/-- A syntactic Jensen-NFU+Infinity proof of the finite represented injection. -/
theorem jensen_proves_nativeDedekind : 𝗡𝗙𝗨𝗜 ⊢ nativeDedekindSentence :=
  jensen_proves_set nativeSeed fun _ _ M _ => (nativeSeed_iff _ _).mpr (nativeDedekind M)

#print axioms jensen_proves_nativeDedekind
end FFL.FirstOrder
