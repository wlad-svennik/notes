import NumericTruth
import StandardArithmeticTruth
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding FFL.FirstOrder.Arithmetic.Bootstrapping
open NF192.Direct PA192.SyntaxTruth
namespace NF192.Internal.Coding
variable {V N : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {o : Operations V} [DefinedOps o] {n : NumOps N}
variable {a : Algebra o n} (c : Coding a)
theorem vecTwo (v : Fin 2→V) : matrixToVec v=?[v 0,v 1] := rfl

noncomputable def agreement [ORingStructure N] (z : n.z=0) (uno : n.s n.z=1)
    (add : ∀x y,n.add x y=x+y) (mul : ∀x y,n.mul x y=x*y)
    (ltN : ∀x y,(∃k,n.add x (n.s k)=y) ↔ x<y) : c.semantics.ArithmeticAgreement N where
  dec:=c.dec
  onto:=fun x=>⟨c.enc x,c.goodEnc _,c.inv x⟩
  func:=by
    intro k h ts b f _ _
    cases h with
    | zero =>
      change c.dec (c.ev (qqFunc 0 0 0) b f)=0
      rw [c.ev_val,c.termVal_zero,c.inv,z]
    | one =>
      change c.dec (c.ev (qqFunc 0 (⌜(Language.One.one : (ℒₒᵣ).Func 0)⌝:V) 0) b f)=1
      rw [quote_one,c.ev_val,c.termVal_one,c.inv,uno]
    | add =>
      change c.dec (c.ev (qqFunc ((2:Nat):V) 0 (matrixToVec ts)) b f)=c.dec (c.ev (ts 0) b f)+c.dec (c.ev (ts 1) b f)
      simp only [Nat.cast_ofNat,vecTwo,c.ev_val,c.termVal_add,c.inv,add]
    | mul =>
      change c.dec (c.ev (qqFunc ((2:Nat):V) (⌜(Language.Mul.mul : (ℒₒᵣ).Func 2)⌝:V) (matrixToVec ts)) b f)=
        c.dec (c.ev (ts 0) b f)*c.dec (c.ev (ts 1) b f)
      rw [quote_mul]
      simp only [Nat.cast_ofNat,vecTwo,c.ev_val,c.termVal_mul,c.inv,mul]
  rel:=by
    intro k h ts b f _ _
    cases h with
    | eq =>
      change c.tr (qqRel ((2:Nat):V) 0 (matrixToVec ts)) b f ↔ c.dec (c.ev (ts 0) b f)=c.dec (c.ev (ts 1) b f)
      simp only [Nat.cast_ofNat,vecTwo,c.tr_eq,nth_adjoin_zero,nth_adjoin_succ,nth_adjoin_one,c.ev_val,c.inv]
      exact ⟨c.inj,congrArg c.enc⟩
    | lt =>
      change c.tr (qqRel ((2:Nat):V) (⌜(Language.LT.lt : (ℒₒᵣ).Rel 2)⌝:V) (matrixToVec ts)) b f ↔
        c.dec (c.ev (ts 0) b f)<c.dec (c.ev (ts 1) b f)
      rw [quote_lt]
      simp only [Nat.cast_ofNat,vecTwo,c.tr_lt,nth_adjoin_zero,nth_adjoin_one,ltN]
#print axioms agreement
end NF192.Internal.Coding
