module
public import LogicalTruth
public import UniversalTruth

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding FFL.FirstOrder.Arithmetic.Bootstrapping

namespace PA192.SyntaxTruth
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem substCode_single (t : ArithmeticSemiterm ℕ k) :
    (substCode t : V)=((⌜t⌝:V) ∷ 0) := by
  unfold substCode
  rw [← FFL.FirstOrder.Semiterm.quote_eq_encode' (V:=V) (![t])]
  simp [Matrix.constant_eq_singleton]
  rfl

abbrev zeroTerm : ArithmeticSemiterm ℕ 0 := ‘0’
abbrev nextTerm : ArithmeticSemiterm ℕ 1 := ‘#0 + 1’

theorem quotedTerm_wf (t : ArithmeticSemiterm ℕ k) : IsSemiterm ℒₒᵣ (k:V) (⌜t⌝ : V) :=
  (⌜t⌝ : Bootstrapping.Semiterm V ℒₒᵣ k).isSemiterm

namespace Semantics
variable (S : Semantics V)

/-- A one-variable matrix only reads the head of its bound assignment. -/
theorem same_head {p x b c f : V} (hp : IsSemiformula ℒₒᵣ 1 p) (hx : S.D x) (hb : S.D b)
    (hc : S.D c) (hf : S.D f) : S.tr p (S.push x b) f ↔ S.tr p (S.push x c) f := by
  have w : IsUTermVec ℒₒᵣ (1:V) ?[qqBvar 0] := (IsSemitermVec.singleton.mpr
    (show IsSemiterm ℒₒᵣ (1:V) (qqBvar 0) by simp)).isUTerm
  have h := S.subst_eval hp (S.pushOK hx hb) hf (S.pushOK hx hc) hf w
    (show ∀ i<(1:V), S.ev (?[qqBvar 0] : V).[i] (S.push x b) f=S.get (S.push x c) i by
      intro i hi
      obtain rfl : i=0 := by simpa using hi
      simp only [nth_adjoin_zero,S.bvar _ (S.pushOK hx hb) hf,S.getZero hx hb,S.getZero hx hc])
    (fun i=>rfl)
  have idsub : subst ℒₒᵣ (qqBvar 0 ∷ (0:V)) p=p :=
    subst_eq_self hp (by simp) (by
      intro i hi
      have iz : i=0 := by simpa using hi
      rw [iz,nth_adjoin_zero])
  rw [idsub] at h
  exact h

/-- The two term equations name the exact standard induction-term quotations,
the set section can vary with each internal matrix and its free assignment. -/
structure InductionSets where
  z : V
  succ : V → V
  dz : S.D z
  ds : ∀{x}, S.D x → S.D (succ x)
  zero : ∀{b f}, S.D b → S.D f → S.ev (⌜zeroTerm⌝:V) b f=z
  next : ∀{x b f}, S.D x → S.D b → S.D f → S.ev (⌜nextTerm⌝:V) (S.push x b) f=succ x
  mem : V → V → Prop
  reps : ∀{K f}, IsSemiformula ℒₒᵣ 1 K → S.D f →
    ∃ u, ∀ x, S.D x → (mem x u ↔ S.tr K (S.push x S.base) f)
  ind : ∀{u}, mem z u → (∀ x, S.D x → mem x u → mem (succ x) u) →
    ∀ x, S.D x → mem x u

variable (I : S.InductionSets)

include I in
theorem induction_eval {K f : V} (hK : IsSemiformula ℒₒᵣ 1 K) (hf : S.D f) :
    S.tr (indBodyVal K) S.base f := by
  have wz : IsSemiterm ℒₒᵣ (0:V) (⌜zeroTerm⌝:V) := by simpa only [Nat.cast_zero] using (quotedTerm_wf (V:=V) zeroTerm)
  have ws : IsSemiterm ℒₒᵣ (1:V) (⌜nextTerm⌝:V) := by simpa only [Nat.cast_one] using (quotedTerm_wf (V:=V) nextTerm)
  have ax0 := IsSemiformula.substs1 wz hK
  have ax1 := IsSemiformula.substs1 ws hK
  have hyp : IsSemiformula ℒₒᵣ (0:V) (qqAll (imp ℒₒᵣ K (substs1 ℒₒᵣ (⌜nextTerm⌝:V) K))) := by
    simp [hK,ax1]
  unfold indBodyVal
  rw [substCode_single zeroTerm,substCode_single nextTerm]
  change S.tr (imp ℒₒᵣ (substs1 ℒₒᵣ (⌜zeroTerm⌝:V) K)
    (imp ℒₒᵣ (qqAll (imp ℒₒᵣ K (substs1 ℒₒᵣ (⌜nextTerm⌝:V) K))) (qqAll K))) S.base f
  rw [S.imp_eval ax0 _ S.baseOK hf,S.imp_eval hyp _ S.baseOK hf,S.single_eval hK wz S.baseOK hf,
    I.zero S.baseOK hf,S.all _ S.baseOK hf,S.all _ S.baseOK hf]
  intro base step x hx
  obtain ⟨u,au⟩ := I.reps hK hf
  apply (au x hx).mp
  apply I.ind ((au _ I.dz).mpr base) _ x hx
  intro v hv mv
  have stepv := (S.imp_eval hK _ (S.pushOK hv S.baseOK) hf).mp (step v hv) ((au v hv).mp mv)
  have st := (S.single_eval hK ws (S.pushOK hv S.baseOK) hf).mp stepv
  rw [I.next hv S.baseOK hf] at st
  exact (au _ (I.ds hv)).mpr ((S.same_head hK (I.ds hv) (S.pushOK hv S.baseOK) S.baseOK hf).mp st)

include I in
theorem all_axioms (standard : ∀ φ ∈ 𝗣𝗔⁻, ∀ f, S.D f → S.tr (⌜φ⌝:V) S.base f)
    {p f : V} (hp : p∈𝗣𝗔.Δ₁Class) (hf : S.D f) : S.tr p S.base f := by
  rcases Peano.mem_Δ₁Class_iff.mp hp with base|scheme
  · obtain ⟨φ,hφ,rfl⟩ := (PA192.NativeTruth.finite_axiom_codes 𝗣𝗔⁻ PeanoMinus.finite p).mp base
    exact standard φ hφ f hf
  · obtain ⟨m,_,b,_,rfl,hb,hs,hbv,K,_,hK,_,hk⟩ := scheme
    apply S.universal_close hb hs hbv _ hf
    intro g hg
    rw [hk]
    exact S.induction_eval I hK hg

noncomputable def truthOfSets (standard : ∀ φ ∈ 𝗣𝗔⁻, ∀ f, S.D f → S.tr (⌜φ⌝:V) S.base f) :
    PA192.NativeTruth.Truth 𝗣𝗔 V := S.nativeTruth (fun hf hp=>S.all_axioms I standard hp hf)

end Semantics
end PA192.SyntaxTruth
#print axioms PA192.SyntaxTruth.Semantics.truthOfSets
