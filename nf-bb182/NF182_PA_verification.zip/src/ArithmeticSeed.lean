import BaseGraphInterface
import EnhancedBody

namespace NF192.Direct.Baseline

def arithmeticSeed : SetForm 0 := strengthen peanoMinusBody

/-- The 6 witnesses come from the released cardinal arithmetic; every clause
of the augmented first-order sentence is verified on these same objects. -/
theorem native_seed {X : Type} [Nonempty X] (M : NFUCut.Model X) [Fact M.Infinity] :
    arithmeticSeed.truth M.mem Fin.elim0 :=
  strengthenNative peanoMinusBody M (fun _ _ _ _ L=>native_body M L)

theorem seed_iff {X : Type} (m : X→X→Prop) : arithmeticSeed.truth m Fin.elim0 ↔
    ∃D z S A B P,CoreAt m D z S A B P ∧ ClosureAt m D z S A B P ∧ ExtraAt m D z S A P ∧
      peanoMinusBody.truth m (params D z S A B P) := strengthen_iff _ _

end NF192.Direct.Baseline
#print axioms NF192.Direct.Baseline.native_seed
