module
public import ModelPackedCommands
public import ModelValue

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterFields
set_option maxHeartbeats 3500000
set_option maxRecDepth 8000
namespace PA192.ModelSearch.RegisterCommands
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

instance mpDef : Language.DefinableFunction₂ ℒₒᵣ (mp (V:=V)) := by
  let alt (d e : V) := state (chooseZero (eqTest (cache e) (imp (top e) (param e+d))) (param e+d) 0) (stack e) 0 (param e+d)
  have ex : ∀ d e, mp d e=alt d e := by intro d e; simp [mp,alt,eqTest,chooseZero]
  have same : mp (V:=V)=alt := funext (fun d=>funext (ex d))
  rw [same]
  dsimp only [alt,state,cache,top,stack,param]
  definability

instance modeDef : Language.DefinableFunction₂ ℒₒᵣ (mode (V:=V)) := by
  let alt (d e : V) := chooseZero (param e+d)
    (state (top e) (right (stack e)) (left (stack e)) 0)
    (state (cache e) (stack e) (top e) ((param e+d)-1))
  have same : mode (V:=V)=alt := rfl
  rw [same]
  dsimp only [alt,state,cache,top,stack,param]
  definability

instance popAfterAXDef : Language.DefinableFunction₁ ℒₒᵣ (popAfterAX (V:=V)) := by unfold popAfterAX state; definability

/-- The external arity six is presented to Foundation as a single indexed tuple. -/
instance axRawDef : Language.DefinableFunction ℒₒᵣ
    (fun v : Fin 6 → V => axRaw (v 0) (v 1) (v 2) (v 3) (v 4) (v 5)) := by
  let first (v : Fin 6 → V) := front9 ((param (v 5)+v 0)+v 2) (cache (v 5)+v 1) (v 3)
    (param (v 5)+v 0) (cantor (top (v 5)) (stack (v 5)))
  have fdef : Language.DefinableFunction ℒₒᵣ first := by
    dsimp only [first,param,cache,top,stack]
    apply Language.DefinableFunction₅.comp (F:=front9) <;> definability
  let out (v : Fin 6 → V) := iterate nextBatch (v 3) (batch (v 3) (first v) (v 4))
  have odef : Language.DefinableFunction ℒₒᵣ out := by
    dsimp only [out,batch]
    apply Language.DefinableFunction₂.comp (F:=iterate nextBatch) (by definability)
    apply Language.DefinableFunction₂.comp (F:=pair) (by definability)
    exact Language.DefinableFunction₂.comp (F:=pair) fdef (by definability)
  change Language.DefinableFunction ℒₒᵣ (fun v : Fin 6 → V => ⟪popAfterAX (batchBody (out v)),batchFields (out v)⟫)
  unfold batchBody batchFields
  apply Language.DefinableFunction₂.comp (F:=pair)
  · apply Language.DefinableFunction₁.comp (F:=popAfterAX)
    apply Language.DefinableFunction₁.comp (F:=pi₁)
    exact Language.DefinableFunction₁.comp (F:=pi₂) odef
  · apply Language.DefinableFunction₁.comp (F:=pi₂)
    exact Language.DefinableFunction₁.comp (F:=pi₂) odef
end PA192.ModelSearch.RegisterCommands
#print axioms PA192.ModelSearch.RegisterCommands.axRawDef
