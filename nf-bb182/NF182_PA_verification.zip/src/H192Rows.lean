module
public import MachineTable
public import Foundation.FirstOrder.Arithmetic.Schemata

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM

namespace PA192.LiteralTM

/-- The first unused control code is the sink; working controls retain their literal indices. -/
def control (q : Option (Fin n)) : Nat := q.elim n Fin.val

def rowF (machine : Machine n) (q : Fin n) (b : Bool) : ArithmeticSemisentence 6 :=
  let a := machine q b
  match a.move with
  | .right => “s l r s' l' r'. s = ↑q.val ∧ s' = ↑(control a.next) ∧
      ∃ t, r = (1 + 1) * t + ↑b.toNat ∧ l' = (1 + 1) * l + ↑a.write.toNat ∧ r' = t”
  | .left => “s l r s' l' r'. s = ↑q.val ∧ s' = ↑(control a.next) ∧
      ∃ t u e, (e = 0 ∨ e = 1) ∧ l = (1 + 1) * u + e ∧
      r = (1 + 1) * t + ↑b.toNat ∧ l' = u ∧ r' = (1 + 1) * ((1 + 1) * t + ↑a.write.toNat) + e”

def allRows (n : Nat) : List (Fin n × Bool) :=
  (List.finRange n).flatMap fun q => [(q,false),(q,true)]

def tableF (machine : Machine n) : List (Fin n × Bool) → ArithmeticSemisentence 6
  | [] => ⊥
  | (q,b)::rest => rowF machine q b ⋎ tableF machine rest

def stepF (machine : Machine n) := tableF machine (allRows n)

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

def Local (machine : Machine n) (q : Fin n) (b : Bool) (s l r t u v : V) : Prop :=
  let a := machine q b
  s=(q.val : V) ∧ t=(control a.next : V) ∧
  match a.move with
  | .right => ∃ x, r=2*x+(b.toNat : V) ∧ u=2*l+(a.write.toNat : V) ∧ v=x
  | .left => ∃ x y e:V, (e=0 ∨ e=1) ∧ l=2*y+e ∧ r=2*x+(b.toNat : V) ∧
      u=y ∧ v=2*(2*x+(a.write.toNat : V))+e

def Step (machine : Machine n) (s l r t u v : V) : Prop :=
  ∃ q b, Local machine q b s l r t u v

theorem rowF_eval (machine : Machine n) (q : Fin n) (b : Bool) (v : Fin 6 → V) :
    (V ⊧/v (rowF machine q b)) ↔ Local machine q b (v 0) (v 1) (v 2) (v 3) (v 4) (v 5) := by
  have hv : v = ![v 0,v 1,v 2,v 3,v 4,v 5] := by simp [funext_iff,Fin.forall_fin_succ]
  conv_lhs => rw [hv]
  cases h : (machine q b).move <;>
    simp [rowF,Local,h,numeral_eq_natCast,show (1:V)+1=2 from by norm_num]
  intro _ _
  constructor
  · rintro ⟨x,y,h|h⟩
    · obtain ⟨hl,hr,hy,hv⟩ := h
      exact ⟨x,Or.inl ⟨hy.symm ▸ hl,hr,hv⟩⟩
    · obtain ⟨hl,hr,hy,hv⟩ := h
      exact ⟨x,Or.inr ⟨hy.symm ▸ hl,hr,hv⟩⟩
  · rintro ⟨x,h|h⟩
    · exact ⟨x,v 4,Or.inl ⟨h.1,h.2.1,rfl,h.2.2⟩⟩
    · exact ⟨x,v 4,Or.inr ⟨h.1,h.2.1,rfl,h.2.2⟩⟩

theorem tableF_eval (machine : Machine n) (rows : List (Fin n × Bool)) (v : Fin 6 → V) :
    (V ⊧/v (tableF machine rows)) ↔
    ∃ qb ∈ rows, Local machine qb.1 qb.2 (v 0) (v 1) (v 2) (v 3) (v 4) (v 5) := by
  induction rows with
  | nil => simp [tableF]
  | cons qb rs ih =>
    rcases qb with ⟨q,b⟩
    rw [tableF,LogicalConnective.HomClass.map_or,rowF_eval,ih]
    exact ⟨fun h => h.elim (fun hq=>⟨(q,b),List.mem_cons_self,hq⟩) (fun ⟨a,ha,hp⟩=>⟨a,List.mem_cons_of_mem _ ha,hp⟩),
      fun ⟨a,hm,hp⟩ => (List.mem_cons.mp hm).elim (fun e=>Or.inl (by subst a; exact hp)) (fun aMem=>Or.inr ⟨a,aMem,hp⟩)⟩

theorem row_present (q : Fin n) (b : Bool) : (q,b)∈allRows n := by
  cases b <;> simp [allRows]

theorem stepF_eval (machine : Machine n) (v : Fin 6 → V) :
    (V ⊧/v (stepF machine)) ↔ Step machine (v 0) (v 1) (v 2) (v 3) (v 4) (v 5) := by
  rw [stepF,tableF_eval]
  exact ⟨fun ⟨⟨q,b⟩,_,h⟩ => ⟨q,b,h⟩,fun ⟨q,b,h⟩ => ⟨(q,b),row_present q b,h⟩⟩

theorem selected_row_count : (allRows 192).length=384 := by decide +kernel

end PA192.LiteralTM

#print axioms PA192.LiteralTM.stepF_eval
