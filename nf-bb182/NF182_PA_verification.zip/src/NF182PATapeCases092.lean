import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2944_0 : checkWitness 2944 false false 679 = true := by decide +kernel
private theorem w2944_1 : checkWitness 2944 false true 4771 = true := by decide +kernel
private theorem w2944_2 : checkWitness 2944 true false 670 = true := by decide +kernel
private theorem w2944_3 : checkWitness 2944 true true 4762 = true := by decide +kernel
private theorem cases2944 : checkFour 2944 (679,4771,670,4762) = true := by
  simp only [checkFour, w2944_0, w2944_1, w2944_2, w2944_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2944 : Coverage 2944 2945 := checkList_sound (ws:=[(679,4771,670,4762)]) (by simpa only [checkList, Bool.and_true] using cases2944)
private theorem w2945_0 : checkWitness 2945 false false 8976 = true := by decide +kernel
private theorem w2945_2 : checkWitness 2945 true false 8967 = true := by decide +kernel
private theorem cases2945 : checkFour 2945 (8976,0,8967,0) = true := by
  simp only [checkFour, w2945_0, w2945_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2945 : Coverage 2945 2946 := checkList_sound (ws:=[(8976,0,8967,0)]) (by simpa only [checkList, Bool.and_true] using cases2945)
private theorem w2946_0 : checkWitness 2946 false false 8922 = true := by decide +kernel
private theorem w2946_2 : checkWitness 2946 true false 8918 = true := by decide +kernel
private theorem cases2946 : checkFour 2946 (8922,0,8918,0) = true := by
  simp only [checkFour, w2946_0, w2946_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2946 : Coverage 2946 2947 := checkList_sound (ws:=[(8922,0,8918,0)]) (by simpa only [checkList, Bool.and_true] using cases2946)
private theorem w2947_0 : checkWitness 2947 false false 44 = true := by decide +kernel
private theorem w2947_2 : checkWitness 2947 true false 44 = true := by decide +kernel
private theorem cases2947 : checkFour 2947 (44,0,44,0) = true := by
  simp only [checkFour, w2947_0, w2947_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2947 : Coverage 2947 2948 := checkList_sound (ws:=[(44,0,44,0)]) (by simpa only [checkList, Bool.and_true] using cases2947)
private theorem w2948_0 : checkWitness 2948 false false 710 = true := by decide +kernel
private theorem w2948_1 : checkWitness 2948 false true 4798 = true := by decide +kernel
private theorem w2948_2 : checkWitness 2948 true false 701 = true := by decide +kernel
private theorem w2948_3 : checkWitness 2948 true true 4789 = true := by decide +kernel
private theorem cases2948 : checkFour 2948 (710,4798,701,4789) = true := by
  simp only [checkFour, w2948_0, w2948_1, w2948_2, w2948_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2948 : Coverage 2948 2949 := checkList_sound (ws:=[(710,4798,701,4789)]) (by simpa only [checkList, Bool.and_true] using cases2948)
private theorem w2949_0 : checkWitness 2949 false false 8983 = true := by decide +kernel
private theorem w2949_2 : checkWitness 2949 true false 8974 = true := by decide +kernel
private theorem cases2949 : checkFour 2949 (8983,0,8974,0) = true := by
  simp only [checkFour, w2949_0, w2949_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2949 : Coverage 2949 2950 := checkList_sound (ws:=[(8983,0,8974,0)]) (by simpa only [checkList, Bool.and_true] using cases2949)
private theorem w2950_0 : checkWitness 2950 false false 28 = true := by decide +kernel
private theorem w2950_2 : checkWitness 2950 true false 28 = true := by decide +kernel
private theorem cases2950 : checkFour 2950 (28,0,28,0) = true := by
  simp only [checkFour, w2950_0, w2950_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2950 : Coverage 2950 2951 := checkList_sound (ws:=[(28,0,28,0)]) (by simpa only [checkList, Bool.and_true] using cases2950)
private theorem w2951_0 : checkWitness 2951 false false 673 = true := by decide +kernel
private theorem w2951_1 : checkWitness 2951 false true 4769 = true := by decide +kernel
private theorem w2951_2 : checkWitness 2951 true false 664 = true := by decide +kernel
private theorem w2951_3 : checkWitness 2951 true true 4760 = true := by decide +kernel
private theorem cases2951 : checkFour 2951 (673,4769,664,4760) = true := by
  simp only [checkFour, w2951_0, w2951_1, w2951_2, w2951_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2951 : Coverage 2951 2952 := checkList_sound (ws:=[(673,4769,664,4760)]) (by simpa only [checkList, Bool.and_true] using cases2951)
private theorem w2952_0 : checkWitness 2952 false false 679 = true := by decide +kernel
private theorem w2952_1 : checkWitness 2952 false true 4771 = true := by decide +kernel
private theorem w2952_2 : checkWitness 2952 true false 670 = true := by decide +kernel
private theorem w2952_3 : checkWitness 2952 true true 4762 = true := by decide +kernel
private theorem cases2952 : checkFour 2952 (679,4771,670,4762) = true := by
  simp only [checkFour, w2952_0, w2952_1, w2952_2, w2952_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2952 : Coverage 2952 2953 := checkList_sound (ws:=[(679,4771,670,4762)]) (by simpa only [checkList, Bool.and_true] using cases2952)
private theorem w2953_0 : checkWitness 2953 false false 679 = true := by decide +kernel
private theorem w2953_1 : checkWitness 2953 false true 4767 = true := by decide +kernel
private theorem w2953_2 : checkWitness 2953 true false 670 = true := by decide +kernel
private theorem w2953_3 : checkWitness 2953 true true 4758 = true := by decide +kernel
private theorem cases2953 : checkFour 2953 (679,4767,670,4758) = true := by
  simp only [checkFour, w2953_0, w2953_1, w2953_2, w2953_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2953 : Coverage 2953 2954 := checkList_sound (ws:=[(679,4767,670,4758)]) (by simpa only [checkList, Bool.and_true] using cases2953)
private theorem w2954_0 : checkWitness 2954 false false 464 = true := by decide +kernel
private theorem w2954_1 : checkWitness 2954 false true 4773 = true := by decide +kernel
private theorem w2954_2 : checkWitness 2954 true false 455 = true := by decide +kernel
private theorem w2954_3 : checkWitness 2954 true true 4764 = true := by decide +kernel
private theorem cases2954 : checkFour 2954 (464,4773,455,4764) = true := by
  simp only [checkFour, w2954_0, w2954_1, w2954_2, w2954_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2954 : Coverage 2954 2955 := checkList_sound (ws:=[(464,4773,455,4764)]) (by simpa only [checkList, Bool.and_true] using cases2954)
private theorem w2955_0 : checkWitness 2955 false false 677 = true := by decide +kernel
private theorem w2955_1 : checkWitness 2955 false true 4769 = true := by decide +kernel
private theorem w2955_2 : checkWitness 2955 true false 668 = true := by decide +kernel
private theorem w2955_3 : checkWitness 2955 true true 4760 = true := by decide +kernel
private theorem cases2955 : checkFour 2955 (677,4769,668,4760) = true := by
  simp only [checkFour, w2955_0, w2955_1, w2955_2, w2955_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2955 : Coverage 2955 2956 := checkList_sound (ws:=[(677,4769,668,4760)]) (by simpa only [checkList, Bool.and_true] using cases2955)
private theorem w2956_0 : checkWitness 2956 false false 26 = true := by decide +kernel
private theorem w2956_2 : checkWitness 2956 true false 26 = true := by decide +kernel
private theorem cases2956 : checkFour 2956 (26,0,26,0) = true := by
  simp only [checkFour, w2956_0, w2956_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2956 : Coverage 2956 2957 := checkList_sound (ws:=[(26,0,26,0)]) (by simpa only [checkList, Bool.and_true] using cases2956)
private theorem w2957_0 : checkWitness 2957 false false 580 = true := by decide +kernel
private theorem w2957_1 : checkWitness 2957 false true 4676 = true := by decide +kernel
private theorem w2957_2 : checkWitness 2957 true false 580 = true := by decide +kernel
private theorem w2957_3 : checkWitness 2957 true true 4676 = true := by decide +kernel
private theorem cases2957 : checkFour 2957 (580,4676,580,4676) = true := by
  simp only [checkFour, w2957_0, w2957_1, w2957_2, w2957_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2957 : Coverage 2957 2958 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases2957)
private theorem w2958_0 : checkWitness 2958 false false 8975 = true := by decide +kernel
private theorem w2958_2 : checkWitness 2958 true false 8971 = true := by decide +kernel
private theorem cases2958 : checkFour 2958 (8975,0,8971,0) = true := by
  simp only [checkFour, w2958_0, w2958_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2958 : Coverage 2958 2959 := checkList_sound (ws:=[(8975,0,8971,0)]) (by simpa only [checkList, Bool.and_true] using cases2958)
private theorem w2959_0 : checkWitness 2959 false false 706 = true := by decide +kernel
private theorem w2959_1 : checkWitness 2959 false true 4802 = true := by decide +kernel
private theorem w2959_2 : checkWitness 2959 true false 697 = true := by decide +kernel
private theorem w2959_3 : checkWitness 2959 true true 4793 = true := by decide +kernel
private theorem cases2959 : checkFour 2959 (706,4802,697,4793) = true := by
  simp only [checkFour, w2959_0, w2959_1, w2959_2, w2959_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2959 : Coverage 2959 2960 := checkList_sound (ws:=[(706,4802,697,4793)]) (by simpa only [checkList, Bool.and_true] using cases2959)
private theorem w2960_0 : checkWitness 2960 false false 218 = true := by decide +kernel
private theorem w2960_2 : checkWitness 2960 true false 218 = true := by decide +kernel
private theorem cases2960 : checkFour 2960 (218,0,218,0) = true := by
  simp only [checkFour, w2960_0, w2960_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2960 : Coverage 2960 2961 := checkList_sound (ws:=[(218,0,218,0)]) (by simpa only [checkList, Bool.and_true] using cases2960)
private theorem w2961_0 : checkWitness 2961 false false 661 = true := by decide +kernel
private theorem w2961_1 : checkWitness 2961 false true 4749 = true := by decide +kernel
private theorem w2961_2 : checkWitness 2961 true false 661 = true := by decide +kernel
private theorem w2961_3 : checkWitness 2961 true true 4749 = true := by decide +kernel
private theorem cases2961 : checkFour 2961 (661,4749,661,4749) = true := by
  simp only [checkFour, w2961_0, w2961_1, w2961_2, w2961_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2961 : Coverage 2961 2962 := checkList_sound (ws:=[(661,4749,661,4749)]) (by simpa only [checkList, Bool.and_true] using cases2961)
private theorem w2962_0 : checkWitness 2962 false false 8990 = true := by decide +kernel
private theorem w2962_2 : checkWitness 2962 true false 8981 = true := by decide +kernel
private theorem cases2962 : checkFour 2962 (8990,0,8981,0) = true := by
  simp only [checkFour, w2962_0, w2962_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2962 : Coverage 2962 2963 := checkList_sound (ws:=[(8990,0,8981,0)]) (by simpa only [checkList, Bool.and_true] using cases2962)
private theorem w2963_0 : checkWitness 2963 false false 46 = true := by decide +kernel
private theorem w2963_2 : checkWitness 2963 true false 46 = true := by decide +kernel
private theorem cases2963 : checkFour 2963 (46,0,46,0) = true := by
  simp only [checkFour, w2963_0, w2963_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2963 : Coverage 2963 2964 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2963)
private theorem w2964_0 : checkWitness 2964 false false 38 = true := by decide +kernel
private theorem w2964_2 : checkWitness 2964 true false 38 = true := by decide +kernel
private theorem cases2964 : checkFour 2964 (38,0,38,0) = true := by
  simp only [checkFour, w2964_0, w2964_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2964 : Coverage 2964 2965 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases2964)
private theorem w2965_0 : checkWitness 2965 false false 667 = true := by decide +kernel
private theorem w2965_1 : checkWitness 2965 false true 4759 = true := by decide +kernel
private theorem w2965_2 : checkWitness 2965 true false 667 = true := by decide +kernel
private theorem w2965_3 : checkWitness 2965 true true 4759 = true := by decide +kernel
private theorem cases2965 : checkFour 2965 (667,4759,667,4759) = true := by
  simp only [checkFour, w2965_0, w2965_1, w2965_2, w2965_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2965 : Coverage 2965 2966 := checkList_sound (ws:=[(667,4759,667,4759)]) (by simpa only [checkList, Bool.and_true] using cases2965)
private theorem w2966_0 : checkWitness 2966 false false 8928 = true := by decide +kernel
private theorem w2966_2 : checkWitness 2966 true false 8924 = true := by decide +kernel
private theorem cases2966 : checkFour 2966 (8928,0,8924,0) = true := by
  simp only [checkFour, w2966_0, w2966_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2966 : Coverage 2966 2967 := checkList_sound (ws:=[(8928,0,8924,0)]) (by simpa only [checkList, Bool.and_true] using cases2966)
private theorem w2967_0 : checkWitness 2967 false false 38 = true := by decide +kernel
private theorem w2967_2 : checkWitness 2967 true false 38 = true := by decide +kernel
private theorem cases2967 : checkFour 2967 (38,0,38,0) = true := by
  simp only [checkFour, w2967_0, w2967_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2967 : Coverage 2967 2968 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases2967)
private theorem w2968_0 : checkWitness 2968 false false 4829 = true := by decide +kernel
private theorem w2968_1 : checkWitness 2968 false true 4804 = true := by decide +kernel
private theorem w2968_2 : checkWitness 2968 true false 4820 = true := by decide +kernel
private theorem w2968_3 : checkWitness 2968 true true 4795 = true := by decide +kernel
private theorem cases2968 : checkFour 2968 (4829,4804,4820,4795) = true := by
  simp only [checkFour, w2968_0, w2968_1, w2968_2, w2968_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2968 : Coverage 2968 2969 := checkList_sound (ws:=[(4829,4804,4820,4795)]) (by simpa only [checkList, Bool.and_true] using cases2968)
private theorem w2969_0 : checkWitness 2969 false false 8989 = true := by decide +kernel
private theorem w2969_2 : checkWitness 2969 true false 8980 = true := by decide +kernel
private theorem cases2969 : checkFour 2969 (8989,0,8980,0) = true := by
  simp only [checkFour, w2969_0, w2969_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2969 : Coverage 2969 2970 := checkList_sound (ws:=[(8989,0,8980,0)]) (by simpa only [checkList, Bool.and_true] using cases2969)
private theorem w2970_0 : checkWitness 2970 false false 30 = true := by decide +kernel
private theorem w2970_2 : checkWitness 2970 true false 30 = true := by decide +kernel
private theorem cases2970 : checkFour 2970 (30,0,30,0) = true := by
  simp only [checkFour, w2970_0, w2970_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2970 : Coverage 2970 2971 := checkList_sound (ws:=[(30,0,30,0)]) (by simpa only [checkList, Bool.and_true] using cases2970)
theorem cover2944 : Coverage 2944 2971 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2944 (Coverage.join one2945 one2946)) (Coverage.join one2947 (Coverage.join one2948 one2949))) (Coverage.join (Coverage.join one2950 (Coverage.join one2951 one2952)) (Coverage.join (Coverage.join one2953 one2954) (Coverage.join one2955 one2956)))) (Coverage.join (Coverage.join (Coverage.join one2957 (Coverage.join one2958 one2959)) (Coverage.join (Coverage.join one2960 one2961) (Coverage.join one2962 one2963))) (Coverage.join (Coverage.join one2964 (Coverage.join one2965 one2966)) (Coverage.join (Coverage.join one2967 one2968) (Coverage.join one2969 one2970)))))
end NF182PA.Symbolic
