import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2560_0 : checkWitness 2560 false false 70 = true := by decide +kernel
private theorem w2560_2 : checkWitness 2560 true false 70 = true := by decide +kernel
private theorem cases2560 : checkFour 2560 (70,0,70,0) = true := by
  simp only [checkFour, w2560_0, w2560_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2560 : Coverage 2560 2561 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2560)
private theorem w2561_0 : checkWitness 2561 false false 8920 = true := by decide +kernel
private theorem w2561_2 : checkWitness 2561 true false 8916 = true := by decide +kernel
private theorem cases2561 : checkFour 2561 (8920,0,8916,0) = true := by
  simp only [checkFour, w2561_0, w2561_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2561 : Coverage 2561 2562 := checkList_sound (ws:=[(8920,0,8916,0)]) (by simpa only [checkList, Bool.and_true] using cases2561)
private theorem w2562_0 : checkWitness 2562 false false 8904 = true := by decide +kernel
private theorem w2562_2 : checkWitness 2562 true false 8900 = true := by decide +kernel
private theorem cases2562 : checkFour 2562 (8904,0,8900,0) = true := by
  simp only [checkFour, w2562_0, w2562_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2562 : Coverage 2562 2563 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2562)
private theorem w2563_0 : checkWitness 2563 false false 532 = true := by decide +kernel
private theorem w2563_1 : checkWitness 2563 false true 4628 = true := by decide +kernel
private theorem w2563_2 : checkWitness 2563 true false 532 = true := by decide +kernel
private theorem w2563_3 : checkWitness 2563 true true 4628 = true := by decide +kernel
private theorem cases2563 : checkFour 2563 (532,4628,532,4628) = true := by
  simp only [checkFour, w2563_0, w2563_1, w2563_2, w2563_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2563 : Coverage 2563 2564 := checkList_sound (ws:=[(532,4628,532,4628)]) (by simpa only [checkList, Bool.and_true] using cases2563)
private theorem w2564_0 : checkWitness 2564 false false 8927 = true := by decide +kernel
private theorem w2564_2 : checkWitness 2564 true false 8923 = true := by decide +kernel
private theorem cases2564 : checkFour 2564 (8927,0,8923,0) = true := by
  simp only [checkFour, w2564_0, w2564_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2564 : Coverage 2564 2565 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases2564)
private theorem w2565_0 : checkWitness 2565 false false 658 = true := by decide +kernel
private theorem w2565_1 : checkWitness 2565 false true 4754 = true := by decide +kernel
private theorem w2565_2 : checkWitness 2565 true false 649 = true := by decide +kernel
private theorem w2565_3 : checkWitness 2565 true true 4745 = true := by decide +kernel
private theorem cases2565 : checkFour 2565 (658,4754,649,4745) = true := by
  simp only [checkFour, w2565_0, w2565_1, w2565_2, w2565_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2565 : Coverage 2565 2566 := checkList_sound (ws:=[(658,4754,649,4745)]) (by simpa only [checkList, Bool.and_true] using cases2565)
private theorem w2566_0 : checkWitness 2566 false false 196 = true := by decide +kernel
private theorem w2566_2 : checkWitness 2566 true false 196 = true := by decide +kernel
private theorem cases2566 : checkFour 2566 (196,0,196,0) = true := by
  simp only [checkFour, w2566_0, w2566_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2566 : Coverage 2566 2567 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases2566)
private theorem w2567_0 : checkWitness 2567 false false 613 = true := by decide +kernel
private theorem w2567_1 : checkWitness 2567 false true 4701 = true := by decide +kernel
private theorem w2567_2 : checkWitness 2567 true false 613 = true := by decide +kernel
private theorem w2567_3 : checkWitness 2567 true true 4701 = true := by decide +kernel
private theorem cases2567 : checkFour 2567 (613,4701,613,4701) = true := by
  simp only [checkFour, w2567_0, w2567_1, w2567_2, w2567_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2567 : Coverage 2567 2568 := checkList_sound (ws:=[(613,4701,613,4701)]) (by simpa only [checkList, Bool.and_true] using cases2567)
private theorem w2568_0 : checkWitness 2568 false false 8942 = true := by decide +kernel
private theorem w2568_2 : checkWitness 2568 true false 8933 = true := by decide +kernel
private theorem cases2568 : checkFour 2568 (8942,0,8933,0) = true := by
  simp only [checkFour, w2568_0, w2568_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2568 : Coverage 2568 2569 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases2568)
private theorem w2569_0 : checkWitness 2569 false false 60 = true := by decide +kernel
private theorem w2569_2 : checkWitness 2569 true false 60 = true := by decide +kernel
private theorem cases2569 : checkFour 2569 (60,0,60,0) = true := by
  simp only [checkFour, w2569_0, w2569_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2569 : Coverage 2569 2570 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2569)
private theorem w2570_0 : checkWitness 2570 false false 52 = true := by decide +kernel
private theorem w2570_2 : checkWitness 2570 true false 52 = true := by decide +kernel
private theorem cases2570 : checkFour 2570 (52,0,52,0) = true := by
  simp only [checkFour, w2570_0, w2570_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2570 : Coverage 2570 2571 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2570)
private theorem w2571_0 : checkWitness 2571 false false 619 = true := by decide +kernel
private theorem w2571_1 : checkWitness 2571 false true 4711 = true := by decide +kernel
private theorem w2571_2 : checkWitness 2571 true false 619 = true := by decide +kernel
private theorem w2571_3 : checkWitness 2571 true true 4711 = true := by decide +kernel
private theorem cases2571 : checkFour 2571 (619,4711,619,4711) = true := by
  simp only [checkFour, w2571_0, w2571_1, w2571_2, w2571_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2571 : Coverage 2571 2572 := checkList_sound (ws:=[(619,4711,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases2571)
private theorem w2572_0 : checkWitness 2572 false false 8880 = true := by decide +kernel
private theorem w2572_2 : checkWitness 2572 true false 8876 = true := by decide +kernel
private theorem cases2572 : checkFour 2572 (8880,0,8876,0) = true := by
  simp only [checkFour, w2572_0, w2572_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2572 : Coverage 2572 2573 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases2572)
private theorem w2573_0 : checkWitness 2573 false false 52 = true := by decide +kernel
private theorem w2573_2 : checkWitness 2573 true false 52 = true := by decide +kernel
private theorem cases2573 : checkFour 2573 (52,0,52,0) = true := by
  simp only [checkFour, w2573_0, w2573_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2573 : Coverage 2573 2574 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2573)
private theorem w2574_0 : checkWitness 2574 false false 580 = true := by decide +kernel
private theorem w2574_1 : checkWitness 2574 false true 4676 = true := by decide +kernel
private theorem w2574_2 : checkWitness 2574 true false 580 = true := by decide +kernel
private theorem w2574_3 : checkWitness 2574 true true 4676 = true := by decide +kernel
private theorem cases2574 : checkFour 2574 (580,4676,580,4676) = true := by
  simp only [checkFour, w2574_0, w2574_1, w2574_2, w2574_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2574 : Coverage 2574 2575 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases2574)
private theorem w2575_0 : checkWitness 2575 false false 8915 = true := by decide +kernel
private theorem w2575_2 : checkWitness 2575 true false 8911 = true := by decide +kernel
private theorem cases2575 : checkFour 2575 (8915,0,8911,0) = true := by
  simp only [checkFour, w2575_0, w2575_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2575 : Coverage 2575 2576 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2575)
private theorem w2576_0 : checkWitness 2576 false false 8950 = true := by decide +kernel
private theorem w2576_2 : checkWitness 2576 true false 8941 = true := by decide +kernel
private theorem cases2576 : checkFour 2576 (8950,0,8941,0) = true := by
  simp only [checkFour, w2576_0, w2576_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2576 : Coverage 2576 2577 := checkList_sound (ws:=[(8950,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2576)
private theorem w2577_0 : checkWitness 2577 false false 70 = true := by decide +kernel
private theorem w2577_2 : checkWitness 2577 true false 70 = true := by decide +kernel
private theorem cases2577 : checkFour 2577 (70,0,70,0) = true := by
  simp only [checkFour, w2577_0, w2577_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2577 : Coverage 2577 2578 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2577)
private theorem w2578_0 : checkWitness 2578 false false 662 = true := by decide +kernel
private theorem w2578_1 : checkWitness 2578 false true 4754 = true := by decide +kernel
private theorem w2578_2 : checkWitness 2578 true false 653 = true := by decide +kernel
private theorem w2578_3 : checkWitness 2578 true true 4745 = true := by decide +kernel
private theorem cases2578 : checkFour 2578 (662,4754,653,4745) = true := by
  simp only [checkFour, w2578_0, w2578_1, w2578_2, w2578_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2578 : Coverage 2578 2579 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases2578)
private theorem w2579_0 : checkWitness 2579 false false 8911 = true := by decide +kernel
private theorem w2579_2 : checkWitness 2579 true false 8907 = true := by decide +kernel
private theorem cases2579 : checkFour 2579 (8911,0,8907,0) = true := by
  simp only [checkFour, w2579_0, w2579_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2579 : Coverage 2579 2580 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases2579)
private theorem w2580_0 : checkWitness 2580 false false 656 = true := by decide +kernel
private theorem w2580_1 : checkWitness 2580 false true 4748 = true := by decide +kernel
private theorem w2580_2 : checkWitness 2580 true false 647 = true := by decide +kernel
private theorem w2580_3 : checkWitness 2580 true true 4739 = true := by decide +kernel
private theorem cases2580 : checkFour 2580 (656,4748,647,4739) = true := by
  simp only [checkFour, w2580_0, w2580_1, w2580_2, w2580_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2580 : Coverage 2580 2581 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases2580)
private theorem w2581_0 : checkWitness 2581 false false 8880 = true := by decide +kernel
private theorem w2581_2 : checkWitness 2581 true false 8876 = true := by decide +kernel
private theorem cases2581 : checkFour 2581 (8880,0,8876,0) = true := by
  simp only [checkFour, w2581_0, w2581_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2581 : Coverage 2581 2582 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases2581)
private theorem w2582_0 : checkWitness 2582 false false 58 = true := by decide +kernel
private theorem w2582_2 : checkWitness 2582 true false 58 = true := by decide +kernel
private theorem cases2582 : checkFour 2582 (58,0,58,0) = true := by
  simp only [checkFour, w2582_0, w2582_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2582 : Coverage 2582 2583 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2582)
private theorem w2583_0 : checkWitness 2583 false false 50 = true := by decide +kernel
private theorem w2583_2 : checkWitness 2583 true false 50 = true := by decide +kernel
private theorem cases2583 : checkFour 2583 (50,0,50,0) = true := by
  simp only [checkFour, w2583_0, w2583_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2583 : Coverage 2583 2584 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2583)
private theorem w2584_0 : checkWitness 2584 false false 623 = true := by decide +kernel
private theorem w2584_1 : checkWitness 2584 false true 4711 = true := by decide +kernel
private theorem w2584_2 : checkWitness 2584 true false 623 = true := by decide +kernel
private theorem w2584_3 : checkWitness 2584 true true 4711 = true := by decide +kernel
private theorem cases2584 : checkFour 2584 (623,4711,623,4711) = true := by
  simp only [checkFour, w2584_0, w2584_1, w2584_2, w2584_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2584 : Coverage 2584 2585 := checkList_sound (ws:=[(623,4711,623,4711)]) (by simpa only [checkList, Bool.and_true] using cases2584)
private theorem w2585_0 : checkWitness 2585 false false 8896 = true := by decide +kernel
private theorem w2585_2 : checkWitness 2585 true false 8892 = true := by decide +kernel
private theorem cases2585 : checkFour 2585 (8896,0,8892,0) = true := by
  simp only [checkFour, w2585_0, w2585_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2585 : Coverage 2585 2586 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases2585)
private theorem w2586_0 : checkWitness 2586 false false 8892 = true := by decide +kernel
private theorem w2586_2 : checkWitness 2586 true false 8888 = true := by decide +kernel
private theorem cases2586 : checkFour 2586 (8892,0,8888,0) = true := by
  simp only [checkFour, w2586_0, w2586_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2586 : Coverage 2586 2587 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2586)
private theorem w2587_0 : checkWitness 2587 false false 64 = true := by decide +kernel
private theorem w2587_2 : checkWitness 2587 true false 64 = true := by decide +kernel
private theorem cases2587 : checkFour 2587 (64,0,64,0) = true := by
  simp only [checkFour, w2587_0, w2587_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2587 : Coverage 2587 2588 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2587)
private theorem w2588_0 : checkWitness 2588 false false 8924 = true := by decide +kernel
private theorem w2588_2 : checkWitness 2588 true false 8920 = true := by decide +kernel
private theorem cases2588 : checkFour 2588 (8924,0,8920,0) = true := by
  simp only [checkFour, w2588_0, w2588_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2588 : Coverage 2588 2589 := checkList_sound (ws:=[(8924,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases2588)
private theorem w2589_0 : checkWitness 2589 false false 584 = true := by decide +kernel
private theorem w2589_1 : checkWitness 2589 false true 4680 = true := by decide +kernel
private theorem w2589_2 : checkWitness 2589 true false 584 = true := by decide +kernel
private theorem w2589_3 : checkWitness 2589 true true 4680 = true := by decide +kernel
private theorem cases2589 : checkFour 2589 (584,4680,584,4680) = true := by
  simp only [checkFour, w2589_0, w2589_1, w2589_2, w2589_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2589 : Coverage 2589 2590 := checkList_sound (ws:=[(584,4680,584,4680)]) (by simpa only [checkList, Bool.and_true] using cases2589)
private theorem w2590_0 : checkWitness 2590 false false 8980 = true := by decide +kernel
private theorem w2590_2 : checkWitness 2590 true false 8971 = true := by decide +kernel
private theorem cases2590 : checkFour 2590 (8980,0,8971,0) = true := by
  simp only [checkFour, w2590_0, w2590_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2590 : Coverage 2590 2591 := checkList_sound (ws:=[(8980,0,8971,0)]) (by simpa only [checkList, Bool.and_true] using cases2590)
private theorem w2591_0 : checkWitness 2591 false false 46 = true := by decide +kernel
private theorem w2591_2 : checkWitness 2591 true false 46 = true := by decide +kernel
private theorem cases2591 : checkFour 2591 (46,0,46,0) = true := by
  simp only [checkFour, w2591_0, w2591_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2591 : Coverage 2591 2592 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2591)
theorem cover2560 : Coverage 2560 2592 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2560 one2561) (Coverage.join one2562 one2563)) (Coverage.join (Coverage.join one2564 one2565) (Coverage.join one2566 one2567))) (Coverage.join (Coverage.join (Coverage.join one2568 one2569) (Coverage.join one2570 one2571)) (Coverage.join (Coverage.join one2572 one2573) (Coverage.join one2574 one2575)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2576 one2577) (Coverage.join one2578 one2579)) (Coverage.join (Coverage.join one2580 one2581) (Coverage.join one2582 one2583))) (Coverage.join (Coverage.join (Coverage.join one2584 one2585) (Coverage.join one2586 one2587)) (Coverage.join (Coverage.join one2588 one2589) (Coverage.join one2590 one2591)))))
end NF182PA.Symbolic
