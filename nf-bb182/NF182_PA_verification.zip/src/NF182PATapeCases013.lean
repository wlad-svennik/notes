import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w416_0 : checkWitness 416 false false 639 = true := by decide +kernel
private theorem w416_1 : checkWitness 416 false true 4723 = true := by decide +kernel
private theorem w416_2 : checkWitness 416 true false 639 = true := by decide +kernel
private theorem w416_3 : checkWitness 416 true true 4723 = true := by decide +kernel
private theorem cases416 : checkFour 416 (639,4723,639,4723) = true := by
  simp only [checkFour, w416_0, w416_1, w416_2, w416_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one416 : Coverage 416 417 := checkList_sound (ws:=[(639,4723,639,4723)]) (by simpa only [checkList, Bool.and_true] using cases416)
private theorem w417_0 : checkWitness 417 false false 8892 = true := by decide +kernel
private theorem w417_2 : checkWitness 417 true false 8888 = true := by decide +kernel
private theorem cases417 : checkFour 417 (8892,0,8888,0) = true := by
  simp only [checkFour, w417_0, w417_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one417 : Coverage 417 418 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases417)
private theorem w418_0 : checkWitness 418 false false 76 = true := by decide +kernel
private theorem w418_2 : checkWitness 418 true false 76 = true := by decide +kernel
private theorem cases418 : checkFour 418 (76,0,76,0) = true := by
  simp only [checkFour, w418_0, w418_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one418 : Coverage 418 419 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases418)
private theorem w419_0 : checkWitness 419 false false 637 = true := by decide +kernel
private theorem w419_1 : checkWitness 419 false true 4729 = true := by decide +kernel
private theorem w419_2 : checkWitness 419 true false 628 = true := by decide +kernel
private theorem w419_3 : checkWitness 419 true true 4720 = true := by decide +kernel
private theorem cases419 : checkFour 419 (637,4729,628,4720) = true := by
  simp only [checkFour, w419_0, w419_1, w419_2, w419_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one419 : Coverage 419 420 := checkList_sound (ws:=[(637,4729,628,4720)]) (by simpa only [checkList, Bool.and_true] using cases419)
private theorem w420_0 : checkWitness 420 false false 8934 = true := by decide +kernel
private theorem w420_2 : checkWitness 420 true false 8925 = true := by decide +kernel
private theorem cases420 : checkFour 420 (8934,0,8925,0) = true := by
  simp only [checkFour, w420_0, w420_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one420 : Coverage 420 421 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases420)
private theorem w421_0 : checkWitness 421 false false 8880 = true := by decide +kernel
private theorem w421_2 : checkWitness 421 true false 8876 = true := by decide +kernel
private theorem cases421 : checkFour 421 (8880,0,8876,0) = true := by
  simp only [checkFour, w421_0, w421_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one421 : Coverage 421 422 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases421)
private theorem w422_0 : checkWitness 422 false false 70 = true := by decide +kernel
private theorem w422_2 : checkWitness 422 true false 70 = true := by decide +kernel
private theorem cases422 : checkFour 422 (70,0,70,0) = true := by
  simp only [checkFour, w422_0, w422_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one422 : Coverage 422 423 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases422)
private theorem w423_0 : checkWitness 423 false false 664 = true := by decide +kernel
private theorem w423_1 : checkWitness 423 false true 4756 = true := by decide +kernel
private theorem w423_2 : checkWitness 423 true false 655 = true := by decide +kernel
private theorem w423_3 : checkWitness 423 true true 4747 = true := by decide +kernel
private theorem cases423 : checkFour 423 (664,4756,655,4747) = true := by
  simp only [checkFour, w423_0, w423_1, w423_2, w423_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one423 : Coverage 423 424 := checkList_sound (ws:=[(664,4756,655,4747)]) (by simpa only [checkList, Bool.and_true] using cases423)
private theorem w424_0 : checkWitness 424 false false 8941 = true := by decide +kernel
private theorem w424_2 : checkWitness 424 true false 8932 = true := by decide +kernel
private theorem cases424 : checkFour 424 (8941,0,8932,0) = true := by
  simp only [checkFour, w424_0, w424_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one424 : Coverage 424 425 := checkList_sound (ws:=[(8941,0,8932,0)]) (by simpa only [checkList, Bool.and_true] using cases424)
private theorem w425_0 : checkWitness 425 false false 54 = true := by decide +kernel
private theorem w425_2 : checkWitness 425 true false 54 = true := by decide +kernel
private theorem cases425 : checkFour 425 (54,0,54,0) = true := by
  simp only [checkFour, w425_0, w425_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one425 : Coverage 425 426 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases425)
private theorem w426_0 : checkWitness 426 false false 546 = true := by decide +kernel
private theorem w426_1 : checkWitness 426 false true 4642 = true := by decide +kernel
private theorem w426_2 : checkWitness 426 true false 546 = true := by decide +kernel
private theorem w426_3 : checkWitness 426 true true 4642 = true := by decide +kernel
private theorem cases426 : checkFour 426 (546,4642,546,4642) = true := by
  simp only [checkFour, w426_0, w426_1, w426_2, w426_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one426 : Coverage 426 427 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases426)
private theorem w427_0 : checkWitness 427 false false 8968 = true := by decide +kernel
private theorem w427_2 : checkWitness 427 true false 8959 = true := by decide +kernel
private theorem cases427 : checkFour 427 (8968,0,8959,0) = true := by
  simp only [checkFour, w427_0, w427_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one427 : Coverage 427 428 := checkList_sound (ws:=[(8968,0,8959,0)]) (by simpa only [checkList, Bool.and_true] using cases427)
private theorem w428_0 : checkWitness 428 false false 72 = true := by decide +kernel
private theorem w428_2 : checkWitness 428 true false 72 = true := by decide +kernel
private theorem cases428 : checkFour 428 (72,0,72,0) = true := by
  simp only [checkFour, w428_0, w428_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one428 : Coverage 428 429 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases428)
private theorem w429_0 : checkWitness 429 false false 550 = true := by decide +kernel
private theorem w429_1 : checkWitness 429 false true 4646 = true := by decide +kernel
private theorem w429_2 : checkWitness 429 true false 550 = true := by decide +kernel
private theorem w429_3 : checkWitness 429 true true 4646 = true := by decide +kernel
private theorem cases429 : checkFour 429 (550,4646,550,4646) = true := by
  simp only [checkFour, w429_0, w429_1, w429_2, w429_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one429 : Coverage 429 430 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases429)
private theorem w430_0 : checkWitness 430 false false 8908 = true := by decide +kernel
private theorem w430_2 : checkWitness 430 true false 8904 = true := by decide +kernel
private theorem cases430 : checkFour 430 (8908,0,8904,0) = true := by
  simp only [checkFour, w430_0, w430_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one430 : Coverage 430 431 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases430)
private theorem w431_0 : checkWitness 431 false false 74 = true := by decide +kernel
private theorem w431_2 : checkWitness 431 true false 74 = true := by decide +kernel
private theorem cases431 : checkFour 431 (74,0,74,0) = true := by
  simp only [checkFour, w431_0, w431_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one431 : Coverage 431 432 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases431)
private theorem w432_0 : checkWitness 432 false false 594 = true := by decide +kernel
private theorem w432_1 : checkWitness 432 false true 4690 = true := by decide +kernel
private theorem w432_2 : checkWitness 432 true false 594 = true := by decide +kernel
private theorem w432_3 : checkWitness 432 true true 4690 = true := by decide +kernel
private theorem cases432 : checkFour 432 (594,4690,594,4690) = true := by
  simp only [checkFour, w432_0, w432_1, w432_2, w432_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one432 : Coverage 432 433 := checkList_sound (ws:=[(594,4690,594,4690)]) (by simpa only [checkList, Bool.and_true] using cases432)
private theorem w433_0 : checkWitness 433 false false 8929 = true := by decide +kernel
private theorem w433_2 : checkWitness 433 true false 8925 = true := by decide +kernel
private theorem cases433 : checkFour 433 (8929,0,8925,0) = true := by
  simp only [checkFour, w433_0, w433_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one433 : Coverage 433 434 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases433)
private theorem w434_0 : checkWitness 434 false false 8964 = true := by decide +kernel
private theorem w434_2 : checkWitness 434 true false 8955 = true := by decide +kernel
private theorem cases434 : checkFour 434 (8964,0,8955,0) = true := by
  simp only [checkFour, w434_0, w434_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one434 : Coverage 434 435 := checkList_sound (ws:=[(8964,0,8955,0)]) (by simpa only [checkList, Bool.and_true] using cases434)
private theorem w435_0 : checkWitness 435 false false 98 = true := by decide +kernel
private theorem w435_2 : checkWitness 435 true false 98 = true := by decide +kernel
private theorem cases435 : checkFour 435 (98,0,98,0) = true := by
  simp only [checkFour, w435_0, w435_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one435 : Coverage 435 436 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases435)
private theorem w436_0 : checkWitness 436 false false 676 = true := by decide +kernel
private theorem w436_1 : checkWitness 436 false true 4768 = true := by decide +kernel
private theorem w436_2 : checkWitness 436 true false 667 = true := by decide +kernel
private theorem w436_3 : checkWitness 436 true true 4759 = true := by decide +kernel
private theorem cases436 : checkFour 436 (676,4768,667,4759) = true := by
  simp only [checkFour, w436_0, w436_1, w436_2, w436_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one436 : Coverage 436 437 := checkList_sound (ws:=[(676,4768,667,4759)]) (by simpa only [checkList, Bool.and_true] using cases436)
private theorem w437_0 : checkWitness 437 false false 8925 = true := by decide +kernel
private theorem w437_2 : checkWitness 437 true false 8921 = true := by decide +kernel
private theorem cases437 : checkFour 437 (8925,0,8921,0) = true := by
  simp only [checkFour, w437_0, w437_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one437 : Coverage 437 438 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases437)
private theorem w438_0 : checkWitness 438 false false 670 = true := by decide +kernel
private theorem w438_1 : checkWitness 438 false true 4762 = true := by decide +kernel
private theorem w438_2 : checkWitness 438 true false 661 = true := by decide +kernel
private theorem w438_3 : checkWitness 438 true true 4753 = true := by decide +kernel
private theorem cases438 : checkFour 438 (670,4762,661,4753) = true := by
  simp only [checkFour, w438_0, w438_1, w438_2, w438_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one438 : Coverage 438 439 := checkList_sound (ws:=[(670,4762,661,4753)]) (by simpa only [checkList, Bool.and_true] using cases438)
private theorem w439_0 : checkWitness 439 false false 8894 = true := by decide +kernel
private theorem w439_2 : checkWitness 439 true false 8890 = true := by decide +kernel
private theorem cases439 : checkFour 439 (8894,0,8890,0) = true := by
  simp only [checkFour, w439_0, w439_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one439 : Coverage 439 440 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases439)
private theorem w440_0 : checkWitness 440 false false 86 = true := by decide +kernel
private theorem w440_2 : checkWitness 440 true false 86 = true := by decide +kernel
private theorem cases440 : checkFour 440 (86,0,86,0) = true := by
  simp only [checkFour, w440_0, w440_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one440 : Coverage 440 441 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases440)
private theorem w441_0 : checkWitness 441 false false 78 = true := by decide +kernel
private theorem w441_2 : checkWitness 441 true false 78 = true := by decide +kernel
private theorem cases441 : checkFour 441 (78,0,78,0) = true := by
  simp only [checkFour, w441_0, w441_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one441 : Coverage 441 442 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases441)
private theorem w442_0 : checkWitness 442 false false 635 = true := by decide +kernel
private theorem w442_1 : checkWitness 442 false true 4719 = true := by decide +kernel
private theorem w442_2 : checkWitness 442 true false 635 = true := by decide +kernel
private theorem w442_3 : checkWitness 442 true true 4719 = true := by decide +kernel
private theorem cases442 : checkFour 442 (635,4719,635,4719) = true := by
  simp only [checkFour, w442_0, w442_1, w442_2, w442_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one442 : Coverage 442 443 := checkList_sound (ws:=[(635,4719,635,4719)]) (by simpa only [checkList, Bool.and_true] using cases442)
private theorem w443_0 : checkWitness 443 false false 8888 = true := by decide +kernel
private theorem w443_2 : checkWitness 443 true false 8884 = true := by decide +kernel
private theorem cases443 : checkFour 443 (8888,0,8884,0) = true := by
  simp only [checkFour, w443_0, w443_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one443 : Coverage 443 444 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases443)
private theorem w444_0 : checkWitness 444 false false 78 = true := by decide +kernel
private theorem w444_2 : checkWitness 444 true false 78 = true := by decide +kernel
private theorem cases444 : checkFour 444 (78,0,78,0) = true := by
  simp only [checkFour, w444_0, w444_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one444 : Coverage 444 445 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases444)
private theorem w445_0 : checkWitness 445 false false 633 = true := by decide +kernel
private theorem w445_1 : checkWitness 445 false true 4725 = true := by decide +kernel
private theorem w445_2 : checkWitness 445 true false 624 = true := by decide +kernel
private theorem w445_3 : checkWitness 445 true true 4716 = true := by decide +kernel
private theorem cases445 : checkFour 445 (633,4725,624,4716) = true := by
  simp only [checkFour, w445_0, w445_1, w445_2, w445_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one445 : Coverage 445 446 := checkList_sound (ws:=[(633,4725,624,4716)]) (by simpa only [checkList, Bool.and_true] using cases445)
private theorem w446_0 : checkWitness 446 false false 8930 = true := by decide +kernel
private theorem w446_2 : checkWitness 446 true false 8921 = true := by decide +kernel
private theorem cases446 : checkFour 446 (8930,0,8921,0) = true := by
  simp only [checkFour, w446_0, w446_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one446 : Coverage 446 447 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases446)
private theorem w447_0 : checkWitness 447 false false 8876 = true := by decide +kernel
private theorem w447_2 : checkWitness 447 true false 8872 = true := by decide +kernel
private theorem cases447 : checkFour 447 (8876,0,8872,0) = true := by
  simp only [checkFour, w447_0, w447_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one447 : Coverage 447 448 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases447)
theorem cover0416 : Coverage 416 448 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one416 one417) (Coverage.join one418 one419)) (Coverage.join (Coverage.join one420 one421) (Coverage.join one422 one423))) (Coverage.join (Coverage.join (Coverage.join one424 one425) (Coverage.join one426 one427)) (Coverage.join (Coverage.join one428 one429) (Coverage.join one430 one431)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one432 one433) (Coverage.join one434 one435)) (Coverage.join (Coverage.join one436 one437) (Coverage.join one438 one439))) (Coverage.join (Coverage.join (Coverage.join one440 one441) (Coverage.join one442 one443)) (Coverage.join (Coverage.join one444 one445) (Coverage.join one446 one447)))))
end NF182PA.Symbolic
