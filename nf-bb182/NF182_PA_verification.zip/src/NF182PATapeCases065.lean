import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2080_0 : checkWitness 2080 false false 595 = true := by decide +kernel
private theorem w2080_1 : checkWitness 2080 false true 4683 = true := by decide +kernel
private theorem w2080_2 : checkWitness 2080 true false 595 = true := by decide +kernel
private theorem w2080_3 : checkWitness 2080 true true 4683 = true := by decide +kernel
private theorem cases2080 : checkFour 2080 (595,4683,595,4683) = true := by
  simp only [checkFour, w2080_0, w2080_1, w2080_2, w2080_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2080 : Coverage 2080 2081 := checkList_sound (ws:=[(595,4683,595,4683)]) (by simpa only [checkList, Bool.and_true] using cases2080)
private theorem w2081_0 : checkWitness 2081 false false 8924 = true := by decide +kernel
private theorem w2081_2 : checkWitness 2081 true false 8915 = true := by decide +kernel
private theorem cases2081 : checkFour 2081 (8924,0,8915,0) = true := by
  simp only [checkFour, w2081_0, w2081_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2081 : Coverage 2081 2082 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases2081)
private theorem w2082_0 : checkWitness 2082 false false 84 = true := by decide +kernel
private theorem w2082_2 : checkWitness 2082 true false 84 = true := by decide +kernel
private theorem cases2082 : checkFour 2082 (84,0,84,0) = true := by
  simp only [checkFour, w2082_0, w2082_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2082 : Coverage 2082 2083 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2082)
private theorem w2083_0 : checkWitness 2083 false false 76 = true := by decide +kernel
private theorem w2083_2 : checkWitness 2083 true false 76 = true := by decide +kernel
private theorem cases2083 : checkFour 2083 (76,0,76,0) = true := by
  simp only [checkFour, w2083_0, w2083_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2083 : Coverage 2083 2084 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2083)
private theorem w2084_0 : checkWitness 2084 false false 601 = true := by decide +kernel
private theorem w2084_1 : checkWitness 2084 false true 4693 = true := by decide +kernel
private theorem w2084_2 : checkWitness 2084 true false 601 = true := by decide +kernel
private theorem w2084_3 : checkWitness 2084 true true 4693 = true := by decide +kernel
private theorem cases2084 : checkFour 2084 (601,4693,601,4693) = true := by
  simp only [checkFour, w2084_0, w2084_1, w2084_2, w2084_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2084 : Coverage 2084 2085 := checkList_sound (ws:=[(601,4693,601,4693)]) (by simpa only [checkList, Bool.and_true] using cases2084)
private theorem w2085_0 : checkWitness 2085 false false 8862 = true := by decide +kernel
private theorem w2085_2 : checkWitness 2085 true false 8858 = true := by decide +kernel
private theorem cases2085 : checkFour 2085 (8862,0,8858,0) = true := by
  simp only [checkFour, w2085_0, w2085_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2085 : Coverage 2085 2086 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases2085)
private theorem w2086_0 : checkWitness 2086 false false 76 = true := by decide +kernel
private theorem w2086_2 : checkWitness 2086 true false 76 = true := by decide +kernel
private theorem cases2086 : checkFour 2086 (76,0,76,0) = true := by
  simp only [checkFour, w2086_0, w2086_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2086 : Coverage 2086 2087 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2086)
private theorem w2087_0 : checkWitness 2087 false false 562 = true := by decide +kernel
private theorem w2087_1 : checkWitness 2087 false true 4658 = true := by decide +kernel
private theorem w2087_2 : checkWitness 2087 true false 562 = true := by decide +kernel
private theorem w2087_3 : checkWitness 2087 true true 4658 = true := by decide +kernel
private theorem cases2087 : checkFour 2087 (562,4658,562,4658) = true := by
  simp only [checkFour, w2087_0, w2087_1, w2087_2, w2087_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2087 : Coverage 2087 2088 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases2087)
private theorem w2088_0 : checkWitness 2088 false false 8897 = true := by decide +kernel
private theorem w2088_2 : checkWitness 2088 true false 8893 = true := by decide +kernel
private theorem cases2088 : checkFour 2088 (8897,0,8893,0) = true := by
  simp only [checkFour, w2088_0, w2088_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2088 : Coverage 2088 2089 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases2088)
private theorem w2089_0 : checkWitness 2089 false false 8932 = true := by decide +kernel
private theorem w2089_2 : checkWitness 2089 true false 8923 = true := by decide +kernel
private theorem cases2089 : checkFour 2089 (8932,0,8923,0) = true := by
  simp only [checkFour, w2089_0, w2089_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2089 : Coverage 2089 2090 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases2089)
private theorem w2090_0 : checkWitness 2090 false false 94 = true := by decide +kernel
private theorem w2090_2 : checkWitness 2090 true false 94 = true := by decide +kernel
private theorem cases2090 : checkFour 2090 (94,0,94,0) = true := by
  simp only [checkFour, w2090_0, w2090_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2090 : Coverage 2090 2091 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases2090)
private theorem w2091_0 : checkWitness 2091 false false 644 = true := by decide +kernel
private theorem w2091_1 : checkWitness 2091 false true 4736 = true := by decide +kernel
private theorem w2091_2 : checkWitness 2091 true false 635 = true := by decide +kernel
private theorem w2091_3 : checkWitness 2091 true true 4727 = true := by decide +kernel
private theorem cases2091 : checkFour 2091 (644,4736,635,4727) = true := by
  simp only [checkFour, w2091_0, w2091_1, w2091_2, w2091_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2091 : Coverage 2091 2092 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases2091)
private theorem w2092_0 : checkWitness 2092 false false 8893 = true := by decide +kernel
private theorem w2092_2 : checkWitness 2092 true false 8889 = true := by decide +kernel
private theorem cases2092 : checkFour 2092 (8893,0,8889,0) = true := by
  simp only [checkFour, w2092_0, w2092_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2092 : Coverage 2092 2093 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases2092)
private theorem w2093_0 : checkWitness 2093 false false 638 = true := by decide +kernel
private theorem w2093_1 : checkWitness 2093 false true 4730 = true := by decide +kernel
private theorem w2093_2 : checkWitness 2093 true false 629 = true := by decide +kernel
private theorem w2093_3 : checkWitness 2093 true true 4721 = true := by decide +kernel
private theorem cases2093 : checkFour 2093 (638,4730,629,4721) = true := by
  simp only [checkFour, w2093_0, w2093_1, w2093_2, w2093_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2093 : Coverage 2093 2094 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases2093)
private theorem w2094_0 : checkWitness 2094 false false 8862 = true := by decide +kernel
private theorem w2094_2 : checkWitness 2094 true false 8858 = true := by decide +kernel
private theorem cases2094 : checkFour 2094 (8862,0,8858,0) = true := by
  simp only [checkFour, w2094_0, w2094_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2094 : Coverage 2094 2095 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases2094)
private theorem w2095_0 : checkWitness 2095 false false 82 = true := by decide +kernel
private theorem w2095_2 : checkWitness 2095 true false 82 = true := by decide +kernel
private theorem cases2095 : checkFour 2095 (82,0,82,0) = true := by
  simp only [checkFour, w2095_0, w2095_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2095 : Coverage 2095 2096 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2095)
private theorem w2096_0 : checkWitness 2096 false false 74 = true := by decide +kernel
private theorem w2096_2 : checkWitness 2096 true false 74 = true := by decide +kernel
private theorem cases2096 : checkFour 2096 (74,0,74,0) = true := by
  simp only [checkFour, w2096_0, w2096_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2096 : Coverage 2096 2097 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2096)
private theorem w2097_0 : checkWitness 2097 false false 605 = true := by decide +kernel
private theorem w2097_1 : checkWitness 2097 false true 4693 = true := by decide +kernel
private theorem w2097_2 : checkWitness 2097 true false 605 = true := by decide +kernel
private theorem w2097_3 : checkWitness 2097 true true 4693 = true := by decide +kernel
private theorem cases2097 : checkFour 2097 (605,4693,605,4693) = true := by
  simp only [checkFour, w2097_0, w2097_1, w2097_2, w2097_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2097 : Coverage 2097 2098 := checkList_sound (ws:=[(605,4693,605,4693)]) (by simpa only [checkList, Bool.and_true] using cases2097)
private theorem w2098_0 : checkWitness 2098 false false 8878 = true := by decide +kernel
private theorem w2098_2 : checkWitness 2098 true false 8874 = true := by decide +kernel
private theorem cases2098 : checkFour 2098 (8878,0,8874,0) = true := by
  simp only [checkFour, w2098_0, w2098_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2098 : Coverage 2098 2099 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases2098)
private theorem w2099_0 : checkWitness 2099 false false 8874 = true := by decide +kernel
private theorem w2099_2 : checkWitness 2099 true false 8870 = true := by decide +kernel
private theorem cases2099 : checkFour 2099 (8874,0,8870,0) = true := by
  simp only [checkFour, w2099_0, w2099_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2099 : Coverage 2099 2100 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases2099)
private theorem w2100_0 : checkWitness 2100 false false 88 = true := by decide +kernel
private theorem w2100_2 : checkWitness 2100 true false 88 = true := by decide +kernel
private theorem cases2100 : checkFour 2100 (88,0,88,0) = true := by
  simp only [checkFour, w2100_0, w2100_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2100 : Coverage 2100 2101 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases2100)
private theorem w2101_0 : checkWitness 2101 false false 8906 = true := by decide +kernel
private theorem w2101_2 : checkWitness 2101 true false 8902 = true := by decide +kernel
private theorem cases2101 : checkFour 2101 (8906,0,8902,0) = true := by
  simp only [checkFour, w2101_0, w2101_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2101 : Coverage 2101 2102 := checkList_sound (ws:=[(8906,0,8902,0)]) (by simpa only [checkList, Bool.and_true] using cases2101)
private theorem w2102_0 : checkWitness 2102 false false 546 = true := by decide +kernel
private theorem w2102_1 : checkWitness 2102 false true 4642 = true := by decide +kernel
private theorem w2102_2 : checkWitness 2102 true false 546 = true := by decide +kernel
private theorem w2102_3 : checkWitness 2102 true true 4642 = true := by decide +kernel
private theorem cases2102 : checkFour 2102 (546,4642,546,4642) = true := by
  simp only [checkFour, w2102_0, w2102_1, w2102_2, w2102_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2102 : Coverage 2102 2103 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases2102)
private theorem w2103_0 : checkWitness 2103 false false 8968 = true := by decide +kernel
private theorem w2103_2 : checkWitness 2103 true false 8959 = true := by decide +kernel
private theorem cases2103 : checkFour 2103 (8968,0,8959,0) = true := by
  simp only [checkFour, w2103_0, w2103_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2103 : Coverage 2103 2104 := checkList_sound (ws:=[(8968,0,8959,0)]) (by simpa only [checkList, Bool.and_true] using cases2103)
private theorem w2104_0 : checkWitness 2104 false false 72 = true := by decide +kernel
private theorem w2104_2 : checkWitness 2104 true false 72 = true := by decide +kernel
private theorem cases2104 : checkFour 2104 (72,0,72,0) = true := by
  simp only [checkFour, w2104_0, w2104_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2104 : Coverage 2104 2105 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2104)
private theorem w2105_0 : checkWitness 2105 false false 550 = true := by decide +kernel
private theorem w2105_1 : checkWitness 2105 false true 4646 = true := by decide +kernel
private theorem w2105_2 : checkWitness 2105 true false 550 = true := by decide +kernel
private theorem w2105_3 : checkWitness 2105 true true 4646 = true := by decide +kernel
private theorem cases2105 : checkFour 2105 (550,4646,550,4646) = true := by
  simp only [checkFour, w2105_0, w2105_1, w2105_2, w2105_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2105 : Coverage 2105 2106 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases2105)
private theorem w2106_0 : checkWitness 2106 false false 8908 = true := by decide +kernel
private theorem w2106_2 : checkWitness 2106 true false 8904 = true := by decide +kernel
private theorem cases2106 : checkFour 2106 (8908,0,8904,0) = true := by
  simp only [checkFour, w2106_0, w2106_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2106 : Coverage 2106 2107 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases2106)
private theorem w2107_0 : checkWitness 2107 false false 74 = true := by decide +kernel
private theorem w2107_2 : checkWitness 2107 true false 74 = true := by decide +kernel
private theorem cases2107 : checkFour 2107 (74,0,74,0) = true := by
  simp only [checkFour, w2107_0, w2107_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2107 : Coverage 2107 2108 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2107)
private theorem w2108_0 : checkWitness 2108 false false 594 = true := by decide +kernel
private theorem w2108_1 : checkWitness 2108 false true 4690 = true := by decide +kernel
private theorem w2108_2 : checkWitness 2108 true false 594 = true := by decide +kernel
private theorem w2108_3 : checkWitness 2108 true true 4690 = true := by decide +kernel
private theorem cases2108 : checkFour 2108 (594,4690,594,4690) = true := by
  simp only [checkFour, w2108_0, w2108_1, w2108_2, w2108_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2108 : Coverage 2108 2109 := checkList_sound (ws:=[(594,4690,594,4690)]) (by simpa only [checkList, Bool.and_true] using cases2108)
private theorem w2109_0 : checkWitness 2109 false false 8929 = true := by decide +kernel
private theorem w2109_2 : checkWitness 2109 true false 8925 = true := by decide +kernel
private theorem cases2109 : checkFour 2109 (8929,0,8925,0) = true := by
  simp only [checkFour, w2109_0, w2109_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2109 : Coverage 2109 2110 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases2109)
private theorem w2110_0 : checkWitness 2110 false false 8964 = true := by decide +kernel
private theorem w2110_2 : checkWitness 2110 true false 8955 = true := by decide +kernel
private theorem cases2110 : checkFour 2110 (8964,0,8955,0) = true := by
  simp only [checkFour, w2110_0, w2110_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2110 : Coverage 2110 2111 := checkList_sound (ws:=[(8964,0,8955,0)]) (by simpa only [checkList, Bool.and_true] using cases2110)
private theorem w2111_0 : checkWitness 2111 false false 98 = true := by decide +kernel
private theorem w2111_2 : checkWitness 2111 true false 98 = true := by decide +kernel
private theorem cases2111 : checkFour 2111 (98,0,98,0) = true := by
  simp only [checkFour, w2111_0, w2111_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2111 : Coverage 2111 2112 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases2111)
theorem cover2080 : Coverage 2080 2112 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2080 one2081) (Coverage.join one2082 one2083)) (Coverage.join (Coverage.join one2084 one2085) (Coverage.join one2086 one2087))) (Coverage.join (Coverage.join (Coverage.join one2088 one2089) (Coverage.join one2090 one2091)) (Coverage.join (Coverage.join one2092 one2093) (Coverage.join one2094 one2095)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2096 one2097) (Coverage.join one2098 one2099)) (Coverage.join (Coverage.join one2100 one2101) (Coverage.join one2102 one2103))) (Coverage.join (Coverage.join (Coverage.join one2104 one2105) (Coverage.join one2106 one2107)) (Coverage.join (Coverage.join one2108 one2109) (Coverage.join one2110 one2111)))))
end NF182PA.Symbolic
