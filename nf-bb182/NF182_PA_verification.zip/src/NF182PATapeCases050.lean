import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1600_0 : checkWitness 1600 false false 8861 = true := by decide +kernel
private theorem w1600_2 : checkWitness 1600 true false 8857 = true := by decide +kernel
private theorem cases1600 : checkFour 1600 (8861,0,8857,0) = true := by
  simp only [checkFour, w1600_0, w1600_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1600 : Coverage 1600 1601 := checkList_sound (ws:=[(8861,0,8857,0)]) (by simpa only [checkList, Bool.and_true] using cases1600)
private theorem w1601_0 : checkWitness 1601 false false 606 = true := by decide +kernel
private theorem w1601_1 : checkWitness 1601 false true 4698 = true := by decide +kernel
private theorem w1601_2 : checkWitness 1601 true false 597 = true := by decide +kernel
private theorem w1601_3 : checkWitness 1601 true true 4689 = true := by decide +kernel
private theorem cases1601 : checkFour 1601 (606,4698,597,4689) = true := by
  simp only [checkFour, w1601_0, w1601_1, w1601_2, w1601_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1601 : Coverage 1601 1602 := checkList_sound (ws:=[(606,4698,597,4689)]) (by simpa only [checkList, Bool.and_true] using cases1601)
private theorem w1602_0 : checkWitness 1602 false false 8830 = true := by decide +kernel
private theorem w1602_2 : checkWitness 1602 true false 8826 = true := by decide +kernel
private theorem cases1602 : checkFour 1602 (8830,0,8826,0) = true := by
  simp only [checkFour, w1602_0, w1602_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1602 : Coverage 1602 1603 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1602)
private theorem w1603_0 : checkWitness 1603 false false 88 = true := by decide +kernel
private theorem w1603_2 : checkWitness 1603 true false 88 = true := by decide +kernel
private theorem cases1603 : checkFour 1603 (88,0,88,0) = true := by
  simp only [checkFour, w1603_0, w1603_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1603 : Coverage 1603 1604 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1603)
private theorem w1604_0 : checkWitness 1604 false false 80 = true := by decide +kernel
private theorem w1604_2 : checkWitness 1604 true false 80 = true := by decide +kernel
private theorem cases1604 : checkFour 1604 (80,0,80,0) = true := by
  simp only [checkFour, w1604_0, w1604_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1604 : Coverage 1604 1605 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1604)
private theorem w1605_0 : checkWitness 1605 false false 571 = true := by decide +kernel
private theorem w1605_1 : checkWitness 1605 false true 4655 = true := by decide +kernel
private theorem w1605_2 : checkWitness 1605 true false 571 = true := by decide +kernel
private theorem w1605_3 : checkWitness 1605 true true 4655 = true := by decide +kernel
private theorem cases1605 : checkFour 1605 (571,4655,571,4655) = true := by
  simp only [checkFour, w1605_0, w1605_1, w1605_2, w1605_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1605 : Coverage 1605 1606 := checkList_sound (ws:=[(571,4655,571,4655)]) (by simpa only [checkList, Bool.and_true] using cases1605)
private theorem w1606_0 : checkWitness 1606 false false 8824 = true := by decide +kernel
private theorem w1606_2 : checkWitness 1606 true false 8820 = true := by decide +kernel
private theorem cases1606 : checkFour 1606 (8824,0,8820,0) = true := by
  simp only [checkFour, w1606_0, w1606_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1606 : Coverage 1606 1607 := checkList_sound (ws:=[(8824,0,8820,0)]) (by simpa only [checkList, Bool.and_true] using cases1606)
private theorem w1607_0 : checkWitness 1607 false false 80 = true := by decide +kernel
private theorem w1607_2 : checkWitness 1607 true false 80 = true := by decide +kernel
private theorem cases1607 : checkFour 1607 (80,0,80,0) = true := by
  simp only [checkFour, w1607_0, w1607_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1607 : Coverage 1607 1608 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1607)
private theorem w1608_0 : checkWitness 1608 false false 539 = true := by decide +kernel
private theorem w1608_1 : checkWitness 1608 false true 4635 = true := by decide +kernel
private theorem w1608_2 : checkWitness 1608 true false 539 = true := by decide +kernel
private theorem w1608_3 : checkWitness 1608 true true 4635 = true := by decide +kernel
private theorem cases1608 : checkFour 1608 (539,4635,539,4635) = true := by
  simp only [checkFour, w1608_0, w1608_1, w1608_2, w1608_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1608 : Coverage 1608 1609 := checkList_sound (ws:=[(539,4635,539,4635)]) (by simpa only [checkList, Bool.and_true] using cases1608)
private theorem w1609_0 : checkWitness 1609 false false 8892 = true := by decide +kernel
private theorem w1609_2 : checkWitness 1609 true false 8883 = true := by decide +kernel
private theorem cases1609 : checkFour 1609 (8892,0,8883,0) = true := by
  simp only [checkFour, w1609_0, w1609_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1609 : Coverage 1609 1610 := checkList_sound (ws:=[(8892,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1609)
private theorem w1610_0 : checkWitness 1610 false false 8838 = true := by decide +kernel
private theorem w1610_2 : checkWitness 1610 true false 8834 = true := by decide +kernel
private theorem cases1610 : checkFour 1610 (8838,0,8834,0) = true := by
  simp only [checkFour, w1610_0, w1610_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1610 : Coverage 1610 1611 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1610)
private theorem w1611_0 : checkWitness 1611 false false 88 = true := by decide +kernel
private theorem w1611_2 : checkWitness 1611 true false 88 = true := by decide +kernel
private theorem cases1611 : checkFour 1611 (88,0,88,0) = true := by
  simp only [checkFour, w1611_0, w1611_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1611 : Coverage 1611 1612 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1611)
private theorem w1612_0 : checkWitness 1612 false false 622 = true := by decide +kernel
private theorem w1612_1 : checkWitness 1612 false true 4710 = true := by decide +kernel
private theorem w1612_2 : checkWitness 1612 true false 613 = true := by decide +kernel
private theorem w1612_3 : checkWitness 1612 true true 4701 = true := by decide +kernel
private theorem cases1612 : checkFour 1612 (622,4710,613,4701) = true := by
  simp only [checkFour, w1612_0, w1612_1, w1612_2, w1612_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1612 : Coverage 1612 1613 := checkList_sound (ws:=[(622,4710,613,4701)]) (by simpa only [checkList, Bool.and_true] using cases1612)
private theorem w1613_0 : checkWitness 1613 false false 8857 = true := by decide +kernel
private theorem w1613_2 : checkWitness 1613 true false 8853 = true := by decide +kernel
private theorem cases1613 : checkFour 1613 (8857,0,8853,0) = true := by
  simp only [checkFour, w1613_0, w1613_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1613 : Coverage 1613 1614 := checkList_sound (ws:=[(8857,0,8853,0)]) (by simpa only [checkList, Bool.and_true] using cases1613)
private theorem w1614_0 : checkWitness 1614 false false 78 = true := by decide +kernel
private theorem w1614_2 : checkWitness 1614 true false 78 = true := by decide +kernel
private theorem cases1614 : checkFour 1614 (78,0,78,0) = true := by
  simp only [checkFour, w1614_0, w1614_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1614 : Coverage 1614 1615 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1614)
private theorem w1615_0 : checkWitness 1615 false false 556 = true := by decide +kernel
private theorem w1615_1 : checkWitness 1615 false true 4652 = true := by decide +kernel
private theorem w1615_2 : checkWitness 1615 true false 556 = true := by decide +kernel
private theorem w1615_3 : checkWitness 1615 true true 4652 = true := by decide +kernel
private theorem cases1615 : checkFour 1615 (556,4652,556,4652) = true := by
  simp only [checkFour, w1615_0, w1615_1, w1615_2, w1615_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1615 : Coverage 1615 1616 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases1615)
private theorem w1616_0 : checkWitness 1616 false false 8912 = true := by decide +kernel
private theorem w1616_2 : checkWitness 1616 true false 8903 = true := by decide +kernel
private theorem cases1616 : checkFour 1616 (8912,0,8903,0) = true := by
  simp only [checkFour, w1616_0, w1616_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1616 : Coverage 1616 1617 := checkList_sound (ws:=[(8912,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases1616)
private theorem w1617_0 : checkWitness 1617 false false 80 = true := by decide +kernel
private theorem w1617_2 : checkWitness 1617 true false 80 = true := by decide +kernel
private theorem cases1617 : checkFour 1617 (80,0,80,0) = true := by
  simp only [checkFour, w1617_0, w1617_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1617 : Coverage 1617 1618 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1617)
private theorem w1618_0 : checkWitness 1618 false false 494 = true := by decide +kernel
private theorem w1618_1 : checkWitness 1618 false true 4590 = true := by decide +kernel
private theorem w1618_2 : checkWitness 1618 true false 494 = true := by decide +kernel
private theorem w1618_3 : checkWitness 1618 true true 4590 = true := by decide +kernel
private theorem cases1618 : checkFour 1618 (494,4590,494,4590) = true := by
  simp only [checkFour, w1618_0, w1618_1, w1618_2, w1618_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1618 : Coverage 1618 1619 := checkList_sound (ws:=[(494,4590,494,4590)]) (by simpa only [checkList, Bool.and_true] using cases1618)
private theorem w1619_0 : checkWitness 1619 false false 8852 = true := by decide +kernel
private theorem w1619_2 : checkWitness 1619 true false 8848 = true := by decide +kernel
private theorem cases1619 : checkFour 1619 (8852,0,8848,0) = true := by
  simp only [checkFour, w1619_0, w1619_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1619 : Coverage 1619 1620 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1619)
private theorem w1620_0 : checkWitness 1620 false false 82 = true := by decide +kernel
private theorem w1620_2 : checkWitness 1620 true false 82 = true := by decide +kernel
private theorem cases1620 : checkFour 1620 (82,0,82,0) = true := by
  simp only [checkFour, w1620_0, w1620_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1620 : Coverage 1620 1621 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1620)
private theorem w1621_0 : checkWitness 1621 false false 538 = true := by decide +kernel
private theorem w1621_1 : checkWitness 1621 false true 4634 = true := by decide +kernel
private theorem w1621_2 : checkWitness 1621 true false 538 = true := by decide +kernel
private theorem w1621_3 : checkWitness 1621 true true 4634 = true := by decide +kernel
private theorem cases1621 : checkFour 1621 (538,4634,538,4634) = true := by
  simp only [checkFour, w1621_0, w1621_1, w1621_2, w1621_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1621 : Coverage 1621 1622 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases1621)
private theorem w1622_0 : checkWitness 1622 false false 8873 = true := by decide +kernel
private theorem w1622_2 : checkWitness 1622 true false 8869 = true := by decide +kernel
private theorem cases1622 : checkFour 1622 (8873,0,8869,0) = true := by
  simp only [checkFour, w1622_0, w1622_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1622 : Coverage 1622 1623 := checkList_sound (ws:=[(8873,0,8869,0)]) (by simpa only [checkList, Bool.and_true] using cases1622)
private theorem w1623_0 : checkWitness 1623 false false 8908 = true := by decide +kernel
private theorem w1623_2 : checkWitness 1623 true false 8899 = true := by decide +kernel
private theorem cases1623 : checkFour 1623 (8908,0,8899,0) = true := by
  simp only [checkFour, w1623_0, w1623_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1623 : Coverage 1623 1624 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases1623)
private theorem w1624_0 : checkWitness 1624 false false 106 = true := by decide +kernel
private theorem w1624_2 : checkWitness 1624 true false 106 = true := by decide +kernel
private theorem cases1624 : checkFour 1624 (106,0,106,0) = true := by
  simp only [checkFour, w1624_0, w1624_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1624 : Coverage 1624 1625 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1624)
private theorem w1625_0 : checkWitness 1625 false false 620 = true := by decide +kernel
private theorem w1625_1 : checkWitness 1625 false true 4712 = true := by decide +kernel
private theorem w1625_2 : checkWitness 1625 true false 611 = true := by decide +kernel
private theorem w1625_3 : checkWitness 1625 true true 4703 = true := by decide +kernel
private theorem cases1625 : checkFour 1625 (620,4712,611,4703) = true := by
  simp only [checkFour, w1625_0, w1625_1, w1625_2, w1625_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1625 : Coverage 1625 1626 := checkList_sound (ws:=[(620,4712,611,4703)]) (by simpa only [checkList, Bool.and_true] using cases1625)
private theorem w1626_0 : checkWitness 1626 false false 8869 = true := by decide +kernel
private theorem w1626_2 : checkWitness 1626 true false 8865 = true := by decide +kernel
private theorem cases1626 : checkFour 1626 (8869,0,8865,0) = true := by
  simp only [checkFour, w1626_0, w1626_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1626 : Coverage 1626 1627 := checkList_sound (ws:=[(8869,0,8865,0)]) (by simpa only [checkList, Bool.and_true] using cases1626)
private theorem w1627_0 : checkWitness 1627 false false 614 = true := by decide +kernel
private theorem w1627_1 : checkWitness 1627 false true 4706 = true := by decide +kernel
private theorem w1627_2 : checkWitness 1627 true false 605 = true := by decide +kernel
private theorem w1627_3 : checkWitness 1627 true true 4697 = true := by decide +kernel
private theorem cases1627 : checkFour 1627 (614,4706,605,4697) = true := by
  simp only [checkFour, w1627_0, w1627_1, w1627_2, w1627_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1627 : Coverage 1627 1628 := checkList_sound (ws:=[(614,4706,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases1627)
private theorem w1628_0 : checkWitness 1628 false false 8838 = true := by decide +kernel
private theorem w1628_2 : checkWitness 1628 true false 8834 = true := by decide +kernel
private theorem cases1628 : checkFour 1628 (8838,0,8834,0) = true := by
  simp only [checkFour, w1628_0, w1628_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1628 : Coverage 1628 1629 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1628)
private theorem w1629_0 : checkWitness 1629 false false 94 = true := by decide +kernel
private theorem w1629_2 : checkWitness 1629 true false 94 = true := by decide +kernel
private theorem cases1629 : checkFour 1629 (94,0,94,0) = true := by
  simp only [checkFour, w1629_0, w1629_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1629 : Coverage 1629 1630 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1629)
private theorem w1630_0 : checkWitness 1630 false false 86 = true := by decide +kernel
private theorem w1630_2 : checkWitness 1630 true false 86 = true := by decide +kernel
private theorem cases1630 : checkFour 1630 (86,0,86,0) = true := by
  simp only [checkFour, w1630_0, w1630_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1630 : Coverage 1630 1631 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1630)
private theorem w1631_0 : checkWitness 1631 false false 579 = true := by decide +kernel
private theorem w1631_1 : checkWitness 1631 false true 4663 = true := by decide +kernel
private theorem w1631_2 : checkWitness 1631 true false 579 = true := by decide +kernel
private theorem w1631_3 : checkWitness 1631 true true 4663 = true := by decide +kernel
private theorem cases1631 : checkFour 1631 (579,4663,579,4663) = true := by
  simp only [checkFour, w1631_0, w1631_1, w1631_2, w1631_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1631 : Coverage 1631 1632 := checkList_sound (ws:=[(579,4663,579,4663)]) (by simpa only [checkList, Bool.and_true] using cases1631)
theorem cover1600 : Coverage 1600 1632 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1600 one1601) (Coverage.join one1602 one1603)) (Coverage.join (Coverage.join one1604 one1605) (Coverage.join one1606 one1607))) (Coverage.join (Coverage.join (Coverage.join one1608 one1609) (Coverage.join one1610 one1611)) (Coverage.join (Coverage.join one1612 one1613) (Coverage.join one1614 one1615)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1616 one1617) (Coverage.join one1618 one1619)) (Coverage.join (Coverage.join one1620 one1621) (Coverage.join one1622 one1623))) (Coverage.join (Coverage.join (Coverage.join one1624 one1625) (Coverage.join one1626 one1627)) (Coverage.join (Coverage.join one1628 one1629) (Coverage.join one1630 one1631)))))
end NF182PA.Symbolic
