module
public import ModelDispatch

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000

private instance plainNth : Language.DefinableFunction₂ ℒₒᵣ (nth : V→V→V) :=
  FFL.FirstOrder.Defined.to_definable (φ := nthDef.val) ⟨(nth_defined (V:=V)).df⟩
private instance plainLen : Language.DefinableFunction₁ ℒₒᵣ (len : V→V) :=
  FFL.FirstOrder.Defined.to_definable (φ := lenDef.val) ⟨(len_defined (V:=V)).df⟩

noncomputable def rawRun (m : Machine n) (q : Fin n) (t : V) :=
  iterate (rawStep m) t (pack (q.val : V) 0 0)

instance runDef (m : Machine n) (q : Fin n) :
    Language.DefinableFunction₁ ℒₒᵣ (rawRun m q : V → V) := by unfold rawRun; definability

@[simp] theorem run_zero (m : Machine n) (q : Fin n) :
    rawRun m q (0 : V) = pack (q.val : V) 0 0 := by simp [rawRun]

theorem run_succ (m : Machine n) (q : Fin n) (t : V) :
    rawRun m q (t+1)=rawStep m (rawRun m q t) := iterate_succ _ _ _

theorem runs_bounded (m : Machine n) (q : Fin n) : ∀ t : V, state (rawRun m q t) ≤ (n : V) := by
  apply modelInduct
  · definability
  · simp only [run_zero,state_pack]
    exact_mod_cast Nat.le_of_lt q.isLt
  · intro x ih; rw [run_succ]; exact step_code_le m _ ih

theorem trace_implies_run (m : Machine n) (q : Fin n) {t cs ls rs : V}
    (trace : Trace m q t cs ls rs) : state (rawRun m q t)=(n : V) := by
  obtain ⟨c0,l0,r0,last,steps⟩ := trace
  have compare : ∀ j : V, j ≤ t → rawRun m q j = pack cs.[j] ls.[j] rs.[j] := by
    apply modelInduct
    · definability
    · intro _; rw [run_zero,c0,l0,r0]
    · intro j ih js
      have jt : j<t := lt_iff_succ_le.mpr js
      rw [run_succ,ih (le_of_lt jt)]
      apply step_to_raw
      simpa using steps j jt
  rw [compare t (le_refl t),state_pack,last]

/-- Code an arbitrary definable segment, including every internal index.
The invocation of PA induction is on its first-order graph formula. -/
theorem vector_segment (f : V → V) [Language.DefinableFunction₁ ℒₒᵣ f] :
    ∀ t : V, ∃ a : V, len a=t+1 ∧ ∀ j≤t, a.[j]=f j := by
  apply modelInduct
  · definability
  · refine ⟨f 0 ∷ 0,by simp,?_⟩
    intro j hj; have h : j=0 := le_antisymm hj zero_le; subst j; simp
  · rintro t ⟨a,hl,points⟩
    refine ⟨concat a (f (t+1)),by simp [hl],?_⟩
    intro j hj
    rcases lt_or_eq_of_le hj with before | rfl
    · rw [concat_nth_lt _ _ (by simpa only [hl] using before)]
      exact points _ (lt_succ_iff_le.mp before)
    · exact concat_nth_len' _ _ hl

theorem first_model (P : V → Prop) (dp : Language.DefinablePred ℒₒᵣ P)
    {j : V} (hit : P j) : ∃ t, P t ∧ ∀ i<t, ¬P i := by
  classical
  by_contra fail
  have nohit : ∀ t : V, ∀ i≤t, ¬P i := by
    apply modelInduct
    · definability
    · intro i iz yes
      have e : i=0 := le_antisymm iz zero_le
      subst i
      exact fail ⟨0,yes,fun y h => False.elim ((not_lt_of_ge (show (0:V)≤y from zero_le)) h)⟩
    · intro x ih i hi yes
      rcases lt_or_eq_of_le hi with lt | rfl
      · exact ih _ (lt_succ_iff_le.mp lt) yes
      · exact fail ⟨x+1,yes,fun z h => ih _ (lt_succ_iff_le.mp h)⟩
  exact nohit j j (le_refl _) hit

theorem run_implies_trace (m : Machine n) (q : Fin n) {j : V}
    (h : state (rawRun m q j)=(n : V)) : ∃ t cs ls rs : V, Trace m q t cs ls rs := by
  obtain ⟨t,hit,least⟩ := first_model (fun x : V => state (rawRun m q x)=(n : V)) (by definability) h
  let c : V → V := fun i => state (rawRun m q i)
  let l : V → V := fun i => leftRay (rawRun m q i)
  let r : V → V := fun i => rightRay (rawRun m q i)
  let _ : Language.DefinableFunction₁ ℒₒᵣ c := by dsimp [c]; definability
  let _ : Language.DefinableFunction₁ ℒₒᵣ l := by dsimp [l]; definability
  let _ : Language.DefinableFunction₁ ℒₒᵣ r := by dsimp [r]; definability
  obtain ⟨cs,_,ac⟩ := vector_segment c t
  obtain ⟨ls,_,al⟩ := vector_segment l t
  obtain ⟨rs,_,ar⟩ := vector_segment r t
  refine ⟨t,cs,ls,rs,?_,?_,?_,?_,?_⟩
  · simpa [c] using ac 0 zero_le
  · simpa [l] using al 0 zero_le
  · simpa [r] using ar 0 zero_le
  · exact (ac t (le_refl _)).trans hit
  · intro i it
    have w : state (rawRun m q i) < (n : V) :=
      lt_of_le_of_ne (runs_bounded m q i) (least i it)
    have hi := le_of_lt it
    have hs := lt_iff_succ_le.mp it
    rw [ac i hi,al i hi,ar i hi,ac (i+1) hs,al (i+1) hs,ar (i+1) hs]
    simpa [c,l,r,run_succ] using step_from_raw m (rawRun m q i) w

theorem traceF_iff_model_run (m : Machine n) (q : Fin n) :
    (V ⊧/![] (traceF m q)) ↔ ∃ t : V, state (rawRun m q t)=(n : V) := by
  rw [traceF_eval]
  constructor
  · rintro ⟨t,cs,ls,rs,h⟩; exact ⟨t,trace_implies_run m q h⟩
  · rintro ⟨t,h⟩; exact run_implies_trace m q h

theorem h192_iff_model_run :
    (V ⊧/![] H192) ↔ ∃ t : V, state (rawRun NF192.Selected.machine NF192.Selected.start t)=(192 : V) :=
  traceF_iff_model_run _ _

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.h192_iff_model_run
