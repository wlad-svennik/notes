import InternalPresentation
import Foundation.FirstOrder.LK.Interpretation
import Foundation.FirstOrder.SetTheory.Basic.Misc
import Mathlib.Tactic.FinCases
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
namespace NF185PA.Comparison
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] [SetStructure X] [Nonempty X]

def Presented (T : SetTheory) (V : Type) [ORingStructure V] : Prop :=
  ∃ (N : Type) (mem : SetStructure N) (nd : Nonempty N), letI := mem; letI := nd
    N↓[ℒₛₑₜ] ⊧* T ∧ Nonempty (NF192.Internal.Presentation V N (·∈·))

private theorem guardGraph (D : V → Prop) [Language.DefinablePred ℒₒᵣ D] (a0 : V) :
    Language.Definable ℒₒᵣ (fun v : Fin 2 → V => (D (v 1) ∧ v 0=v 1) ∨ (¬D (v 1) ∧ v 0=a0)) := by
  definability

set_option maxHeartbeats 800000 in
theorem represented_interpretation {T U : SetTheory} [𝗘𝗤 _ ⪯ T] [ht : X↓[ℒₛₑₜ] ⊧* T]
    (I : T ⊳ U) (p : NF192.Internal.Presentation V X (·∈·))
    (fixed : ∀ {n} (φ : Semisentence ℒₛₑₜ n), Language.Definable ℒₒᵣ (fun e : Fin n → V => X ⊧/(p.dec ∘ e) φ)) : Presented U V := by
  classical
  let N := I.Model X
  let sN : Tarski.Structure ℒₛₑₜ N := inferInstanceAs (Tarski.Structure ℒₛₑₜ (I.Model X))
  let M : SetStructure N := ⟨fun y x => sN.rel Language.Set.Rel.mem ![x,y]⟩
  letI := M
  have same : sN=SetTheory.standardStructure N := by
    apply SetTheory.standardStructure_unique' N sN
    · exact inferInstanceAs (Tarski.Structure.Eq ℒₛₑₜ (I.Model X))
    · constructor; intro a b; rfl
  let D (a : V) := I.trln.Dom (p.dec a)
  have dD : Language.DefinablePred ℒₒᵣ D := by
    apply (fixed I.trln.domain.sentence).of_iff
    intro v
    have he : (p.dec ∘ v) = ![p.dec (v 0)] := by funext i;fin_cases i <;> rfl
    rw [he];rfl
  letI := dD
  obtain ⟨x,hx⟩ := I.trln.domain_exists (M:=X)
  obtain ⟨a0,rfl⟩ := p.onto x
  let safe (a : V) := if D a then a else a0
  have dsafe : Language.DefinableFunction₁ ℒₒᵣ safe := by
    let P (v : Fin 2 → V) := (D (v 1) ∧ v 0=v 1) ∨ (¬D (v 1) ∧ v 0=a0)
    have dP : Language.Definable ℒₒᵣ P := guardGraph D a0
    apply dP.of_iff; intro v
    change (v 0 = safe (v 1)) ↔ P v
    by_cases a : D (v 1) <;> simp [safe,P,a]
  letI := dsafe
  have safeDom (a : V) : D (safe a) := by
    by_cases h : D a <;> simp [safe,h,show D a0 from hx]
  let δ (a : V) : N := ⟨p.dec (safe a), safeDom a⟩
  have sur : Function.Surjective δ := by
    intro z
    obtain ⟨a,ha⟩ := p.onto z.val
    have d : D a := by
      change I.trln.Dom (p.dec a)
      rw [ha]
      exact z.dom
    refine ⟨a,DirectTranslation.Model.val_inj_iff.mp ?_⟩
    change p.dec (safe a)=z.val
    simpa [safe,d] using ha
  have safeArg (i : Fin 2) : Language.DefinableFunction ℒₒᵣ (fun e : Fin 2 → V => safe (e i)) :=
    Language.DefinableFunction₁.comp (F:=safe) (Language.DefinableFunction.projection i)
  have dEq : Language.DefinableRel ℒₒᵣ (fun a b => δ a=δ b) := by
    letI := p.eqDef
    apply (Language.DefinableRel.comp (P:=fun a b => p.dec a=p.dec b) (safeArg 0) (safeArg 1)).of_iff
    exact fun _ => DirectTranslation.Model.val_inj_iff.symm
  have dMem : Language.DefinableRel ℒₒᵣ (fun a b => δ a∈δ b) := by
    let φ := (I.trln.rel Language.Set.Rel.mem).sentence
    have d := Language.Definable.substitution (fixed φ)
      (f:=fun i (e : Fin 2 → V) => safe (e i)) safeArg
    apply d.of_iff
    intro v
    change (I.trln.rel Language.Set.Rel.mem).val (fun i => (![δ (v 0),δ (v 1)] i).val) ↔ _
    have he : (fun i => (![δ (v 0),δ (v 1)] i).val) = (fun i => p.dec (safe (v i))) := by
      funext i;fin_cases i <;> rfl
    rw [he];rfl
  refine ⟨N,M,inferInstanceAs (Nonempty (I.Model X)),?_,⟨⟨δ,sur,dEq,dMem⟩⟩⟩
  have hN : (letI : Tarski.Structure ℒₛₑₜ N := sN; N↓[ℒₛₑₜ] ⊧* U) := I.model_models_theory ht
  rwa [same] at hN
end NF185PA.Comparison
#print axioms NF185PA.Comparison.represented_interpretation
