import NF185PATapeBatchCheck
namespace NF185PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w544_0 : checkWitness 544 false false 8862 = true := by decide +kernel
private theorem w544_2 : checkWitness 544 true false 8858 = true := by decide +kernel
private theorem cases544 : checkFour 544 (8862,0,8858,0) = true := by
  simp only [checkFour, w544_0, w544_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one544 : Coverage 544 545 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases544)
private theorem w545_0 : checkWitness 545 false false 72 = true := by decide +kernel
private theorem w545_2 : checkWitness 545 true false 72 = true := by decide +kernel
private theorem cases545 : checkFour 545 (72,0,72,0) = true := by
  simp only [checkFour, w545_0, w545_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one545 : Coverage 545 546 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases545)
private theorem w546_0 : checkWitness 546 false false 66 = true := by decide +kernel
private theorem w546_2 : checkWitness 546 true false 66 = true := by decide +kernel
private theorem cases546 : checkFour 546 (66,0,66,0) = true := by
  simp only [checkFour, w546_0, w546_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one546 : Coverage 546 547 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases546)
private theorem w547_0 : checkWitness 547 false false 593 = true := by decide +kernel
private theorem w547_1 : checkWitness 547 false true 4677 = true := by decide +kernel
private theorem w547_2 : checkWitness 547 true false 593 = true := by decide +kernel
private theorem w547_3 : checkWitness 547 true true 4677 = true := by decide +kernel
private theorem cases547 : checkFour 547 (593,4677,593,4677) = true := by
  simp only [checkFour, w547_0, w547_1, w547_2, w547_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one547 : Coverage 547 548 := checkList_sound (ws:=[(593,4677,593,4677)]) (by simpa only [checkList, Bool.and_true] using cases547)
private theorem w548_0 : checkWitness 548 false false 8862 = true := by decide +kernel
private theorem w548_2 : checkWitness 548 true false 8858 = true := by decide +kernel
private theorem cases548 : checkFour 548 (8862,0,8858,0) = true := by
  simp only [checkFour, w548_0, w548_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one548 : Coverage 548 549 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases548)
private theorem w549_0 : checkWitness 549 false false 64 = true := by decide +kernel
private theorem w549_2 : checkWitness 549 true false 64 = true := by decide +kernel
private theorem cases549 : checkFour 549 (64,0,64,0) = true := by
  simp only [checkFour, w549_0, w549_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one549 : Coverage 549 550 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases549)
private theorem w550_0 : checkWitness 550 false false 631 = true := by decide +kernel
private theorem w550_1 : checkWitness 550 false true 4723 = true := by decide +kernel
private theorem w550_2 : checkWitness 550 true false 622 = true := by decide +kernel
private theorem w550_3 : checkWitness 550 true true 4714 = true := by decide +kernel
private theorem cases550 : checkFour 550 (631,4723,622,4714) = true := by
  simp only [checkFour, w550_0, w550_1, w550_2, w550_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one550 : Coverage 550 551 := checkList_sound (ws:=[(631,4723,622,4714)]) (by simpa only [checkList, Bool.and_true] using cases550)
private theorem w551_0 : checkWitness 551 false false 8930 = true := by decide +kernel
private theorem w551_2 : checkWitness 551 true false 8921 = true := by decide +kernel
private theorem cases551 : checkFour 551 (8930,0,8921,0) = true := by
  simp only [checkFour, w551_0, w551_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one551 : Coverage 551 552 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases551)
private theorem w552_0 : checkWitness 552 false false 8874 = true := by decide +kernel
private theorem w552_2 : checkWitness 552 true false 8870 = true := by decide +kernel
private theorem cases552 : checkFour 552 (8874,0,8870,0) = true := by
  simp only [checkFour, w552_0, w552_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one552 : Coverage 552 553 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases552)
private theorem w553_0 : checkWitness 553 false false 58 = true := by decide +kernel
private theorem w553_2 : checkWitness 553 true false 58 = true := by decide +kernel
private theorem cases553 : checkFour 553 (58,0,58,0) = true := by
  simp only [checkFour, w553_0, w553_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one553 : Coverage 553 554 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases553)
private theorem w554_0 : checkWitness 554 false false 652 = true := by decide +kernel
private theorem w554_1 : checkWitness 554 false true 4744 = true := by decide +kernel
private theorem w554_2 : checkWitness 554 true false 643 = true := by decide +kernel
private theorem w554_3 : checkWitness 554 true true 4735 = true := by decide +kernel
private theorem cases554 : checkFour 554 (652,4744,643,4735) = true := by
  simp only [checkFour, w554_0, w554_1, w554_2, w554_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one554 : Coverage 554 555 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases554)
private theorem w555_0 : checkWitness 555 false false 8939 = true := by decide +kernel
private theorem w555_2 : checkWitness 555 true false 8930 = true := by decide +kernel
private theorem cases555 : checkFour 555 (8939,0,8930,0) = true := by
  simp only [checkFour, w555_0, w555_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one555 : Coverage 555 556 := checkList_sound (ws:=[(8939,0,8930,0)]) (by simpa only [checkList, Bool.and_true] using cases555)
private theorem w556_0 : checkWitness 556 false false 52 = true := by decide +kernel
private theorem w556_2 : checkWitness 556 true false 52 = true := by decide +kernel
private theorem cases556 : checkFour 556 (52,0,52,0) = true := by
  simp only [checkFour, w556_0, w556_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one556 : Coverage 556 557 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases556)
private theorem w557_0 : checkWitness 557 false false 516 = true := by decide +kernel
private theorem w557_1 : checkWitness 557 false true 4612 = true := by decide +kernel
private theorem w557_2 : checkWitness 557 true false 516 = true := by decide +kernel
private theorem w557_3 : checkWitness 557 true true 4612 = true := by decide +kernel
private theorem cases557 : checkFour 557 (516,4612,516,4612) = true := by
  simp only [checkFour, w557_0, w557_1, w557_2, w557_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one557 : Coverage 557 558 := checkList_sound (ws:=[(516,4612,516,4612)]) (by simpa only [checkList, Bool.and_true] using cases557)
private theorem w558_0 : checkWitness 558 false false 8919 = true := by decide +kernel
private theorem w558_2 : checkWitness 558 true false 8915 = true := by decide +kernel
private theorem cases558 : checkFour 558 (8919,0,8915,0) = true := by
  simp only [checkFour, w558_0, w558_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one558 : Coverage 558 559 := checkList_sound (ws:=[(8919,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases558)
private theorem w559_0 : checkWitness 559 false false 648 = true := by decide +kernel
private theorem w559_1 : checkWitness 559 false true 4744 = true := by decide +kernel
private theorem w559_2 : checkWitness 559 true false 639 = true := by decide +kernel
private theorem w559_3 : checkWitness 559 true true 4735 = true := by decide +kernel
private theorem cases559 : checkFour 559 (648,4744,639,4735) = true := by
  simp only [checkFour, w559_0, w559_1, w559_2, w559_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one559 : Coverage 559 560 := checkList_sound (ws:=[(648,4744,639,4735)]) (by simpa only [checkList, Bool.and_true] using cases559)
private theorem w560_0 : checkWitness 560 false false 190 = true := by decide +kernel
private theorem w560_2 : checkWitness 560 true false 190 = true := by decide +kernel
private theorem cases560 : checkFour 560 (190,0,190,0) = true := by
  simp only [checkFour, w560_0, w560_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one560 : Coverage 560 561 := checkList_sound (ws:=[(190,0,190,0)]) (by simpa only [checkList, Bool.and_true] using cases560)
private theorem w561_0 : checkWitness 561 false false 593 = true := by decide +kernel
private theorem w561_1 : checkWitness 561 false true 4681 = true := by decide +kernel
private theorem w561_2 : checkWitness 561 true false 593 = true := by decide +kernel
private theorem w561_3 : checkWitness 561 true true 4681 = true := by decide +kernel
private theorem cases561 : checkFour 561 (593,4681,593,4681) = true := by
  simp only [checkFour, w561_0, w561_1, w561_2, w561_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one561 : Coverage 561 562 := checkList_sound (ws:=[(593,4681,593,4681)]) (by simpa only [checkList, Bool.and_true] using cases561)
private theorem w562_0 : checkWitness 562 false false 8934 = true := by decide +kernel
private theorem w562_2 : checkWitness 562 true false 8925 = true := by decide +kernel
private theorem cases562 : checkFour 562 (8934,0,8925,0) = true := by
  simp only [checkFour, w562_0, w562_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one562 : Coverage 562 563 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases562)
private theorem w563_0 : checkWitness 563 false false 70 = true := by decide +kernel
private theorem w563_2 : checkWitness 563 true false 70 = true := by decide +kernel
private theorem cases563 : checkFour 563 (70,0,70,0) = true := by
  simp only [checkFour, w563_0, w563_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one563 : Coverage 563 564 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases563)
private theorem w564_0 : checkWitness 564 false false 62 = true := by decide +kernel
private theorem w564_2 : checkWitness 564 true false 62 = true := by decide +kernel
private theorem cases564 : checkFour 564 (62,0,62,0) = true := by
  simp only [checkFour, w564_0, w564_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one564 : Coverage 564 565 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases564)
private theorem w565_0 : checkWitness 565 false false 599 = true := by decide +kernel
private theorem w565_1 : checkWitness 565 false true 4691 = true := by decide +kernel
private theorem w565_2 : checkWitness 565 true false 599 = true := by decide +kernel
private theorem w565_3 : checkWitness 565 true true 4691 = true := by decide +kernel
private theorem cases565 : checkFour 565 (599,4691,599,4691) = true := by
  simp only [checkFour, w565_0, w565_1, w565_2, w565_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one565 : Coverage 565 566 := checkList_sound (ws:=[(599,4691,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases565)
private theorem w566_0 : checkWitness 566 false false 8876 = true := by decide +kernel
private theorem w566_2 : checkWitness 566 true false 8872 = true := by decide +kernel
private theorem cases566 : checkFour 566 (8876,0,8872,0) = true := by
  simp only [checkFour, w566_0, w566_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one566 : Coverage 566 567 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases566)
private theorem w567_0 : checkWitness 567 false false 62 = true := by decide +kernel
private theorem w567_2 : checkWitness 567 true false 62 = true := by decide +kernel
private theorem cases567 : checkFour 567 (62,0,62,0) = true := by
  simp only [checkFour, w567_0, w567_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one567 : Coverage 567 568 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases567)
private theorem w568_0 : checkWitness 568 false false 564 = true := by decide +kernel
private theorem w568_1 : checkWitness 568 false true 4660 = true := by decide +kernel
private theorem w568_2 : checkWitness 568 true false 564 = true := by decide +kernel
private theorem w568_3 : checkWitness 568 true true 4660 = true := by decide +kernel
private theorem cases568 : checkFour 568 (564,4660,564,4660) = true := by
  simp only [checkFour, w568_0, w568_1, w568_2, w568_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one568 : Coverage 568 569 := checkList_sound (ws:=[(564,4660,564,4660)]) (by simpa only [checkList, Bool.and_true] using cases568)
private theorem w569_0 : checkWitness 569 false false 8907 = true := by decide +kernel
private theorem w569_2 : checkWitness 569 true false 8903 = true := by decide +kernel
private theorem cases569 : checkFour 569 (8907,0,8903,0) = true := by
  simp only [checkFour, w569_0, w569_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one569 : Coverage 569 570 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases569)
private theorem w570_0 : checkWitness 570 false false 8948 = true := by decide +kernel
private theorem w570_2 : checkWitness 570 true false 8939 = true := by decide +kernel
private theorem cases570 : checkFour 570 (8948,0,8939,0) = true := by
  simp only [checkFour, w570_0, w570_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one570 : Coverage 570 571 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases570)
private theorem w571_0 : checkWitness 571 false false 68 = true := by decide +kernel
private theorem w571_2 : checkWitness 571 true false 68 = true := by decide +kernel
private theorem cases571 : checkFour 571 (68,0,68,0) = true := by
  simp only [checkFour, w571_0, w571_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one571 : Coverage 571 572 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases571)
private theorem w572_0 : checkWitness 572 false false 652 = true := by decide +kernel
private theorem w572_1 : checkWitness 572 false true 4744 = true := by decide +kernel
private theorem w572_2 : checkWitness 572 true false 643 = true := by decide +kernel
private theorem w572_3 : checkWitness 572 true true 4735 = true := by decide +kernel
private theorem cases572 : checkFour 572 (652,4744,643,4735) = true := by
  simp only [checkFour, w572_0, w572_1, w572_2, w572_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one572 : Coverage 572 573 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases572)
private theorem w573_0 : checkWitness 573 false false 8903 = true := by decide +kernel
private theorem w573_2 : checkWitness 573 true false 8899 = true := by decide +kernel
private theorem cases573 : checkFour 573 (8903,0,8899,0) = true := by
  simp only [checkFour, w573_0, w573_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one573 : Coverage 573 574 := checkList_sound (ws:=[(8903,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases573)
private theorem w574_0 : checkWitness 574 false false 640 = true := by decide +kernel
private theorem w574_1 : checkWitness 574 false true 4732 = true := by decide +kernel
private theorem w574_2 : checkWitness 574 true false 631 = true := by decide +kernel
private theorem w574_3 : checkWitness 574 true true 4723 = true := by decide +kernel
private theorem cases574 : checkFour 574 (640,4732,631,4723) = true := by
  simp only [checkFour, w574_0, w574_1, w574_2, w574_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one574 : Coverage 574 575 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases574)
private theorem w575_0 : checkWitness 575 false false 8870 = true := by decide +kernel
private theorem w575_2 : checkWitness 575 true false 8866 = true := by decide +kernel
private theorem cases575 : checkFour 575 (8870,0,8866,0) = true := by
  simp only [checkFour, w575_0, w575_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one575 : Coverage 575 576 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases575)
theorem cover0544 : Coverage 544 576 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one544 one545) (Coverage.join one546 one547)) (Coverage.join (Coverage.join one548 one549) (Coverage.join one550 one551))) (Coverage.join (Coverage.join (Coverage.join one552 one553) (Coverage.join one554 one555)) (Coverage.join (Coverage.join one556 one557) (Coverage.join one558 one559)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one560 one561) (Coverage.join one562 one563)) (Coverage.join (Coverage.join one564 one565) (Coverage.join one566 one567))) (Coverage.join (Coverage.join (Coverage.join one568 one569) (Coverage.join one570 one571)) (Coverage.join (Coverage.join one572 one573) (Coverage.join one574 one575)))))
end NF185PA.Symbolic
