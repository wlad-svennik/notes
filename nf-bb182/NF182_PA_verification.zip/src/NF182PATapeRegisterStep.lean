import NF182PATapeBoundary
import NF182PATapeBatchCheck
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.PhysicalModel PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.RegisterSource (readReg writeReg registers address cold config perform)
namespace NF182PA.Symbolic
open Gate (machine)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000
set_option maxRecDepth 12000
set_option linter.unusedSimpArgs false
set_option linter.unusedTactic false

noncomputable def positive (p : Nat) (r : V) : Bool :=
  match Moving184.Raw.program p with
  | .inr (.inl (i,_,_,_)) => decide (readReg i r≠0)
  | _ => false

noncomputable def parameter (p : Nat) (r g k : V) (i : Nat) : V :=
  if i<9 then if isDecReg p i then readReg i r - 1 else readReg i r
  else if i=9 then g else k

private theorem back {a : V} (nz : a ≠ 0) : a-1+1=a := by
  exact sub_add_self_of_le (by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne zero_le (Ne.symm nz)))

theorem params_input (p : Nat) (c : Bool) (r g k : V) (debt : c=true → readReg 0 r=0) :
    ∀ i < 9, regsFor p c (positive p r) false (parameter p r g k) i=readReg i r := by
  intro i hi
  cases e : Moving184.Raw.program p with
  | inl ins =>
    rcases ins with ⟨j,n⟩
    by_cases zi : i=0
    all_goals cases c <;> simp_all [regsFor,positive,parameter,isDecReg,isIncReg,e]
  | inr ins =>
    cases ins with
    | inr n =>
      by_cases zi : i=0
      all_goals cases c <;> simp_all [regsFor,positive,parameter,isDecReg,isIncReg,e]
    | inl ins =>
      rcases ins with ⟨j,n,m,b⟩
      by_cases ji : j=i <;> by_cases zi : i=0 <;> by_cases nz : readReg j r=0
      all_goals try subst_vars
      all_goals cases c <;> simp_all [regsFor,positive,parameter,isDecReg,isIncReg,e,back]

theorem params_admissible (p : Nat) (c : Bool) (r : V) (ok : c=true → isDecReg p 0=false) :
    admissible p c (positive p r) = true := by
  cases e : Moving184.Raw.program p with
  | inl ins => rcases ins with ⟨j,n⟩; simp [positive,admissible,e]
  | inr ins =>
    cases ins with
    | inr n => simp [positive,admissible,e]
    | inl ins =>
      rcases ins with ⟨j,n,m,b⟩
      cases c <;> simp_all [admissible,e,isDecReg]

def outAddress (p : Nat) (z : Bool) := if expectedHalt p z then 4095 else nextPc p z

theorem source_fields (p : Nat) (c : Bool) (r g k : V) (debt : c=true → readReg 0 r=0) :
    let z := positive p r
    let s := perform (Registers.instruction p) (c.toNat:V) r
    address s = (outAddress p z:V) ∧ cold s=((coldFor p c true).toNat:V) ∧
    (coldFor p c true=true → readReg 0 (registers s)=0) ∧
    ∀ i < 9, regsFor p c z true (parameter p r g k) i=readReg i (registers s) := by
  dsimp only
  cases e : Moving184.Raw.program p with
  | inl ins =>
    rcases ins with ⟨j,n⟩
    cases j with
    | zero =>
      cases c <;> simp [Registers.instruction,e,perform,chooseZero,positive,outAddress,
        expectedHalt,nextPc,coldFor,isIncReg]
      all_goals intro i hi
      all_goals by_cases zi : i=0
      all_goals try subst i
      all_goals simp_all [regsFor,isDecReg,isIncReg,e,parameter,RegisterSource.readReg_other,Ne.symm]
    | succ j =>
      cases c <;> simp [Registers.instruction,e,perform,positive,outAddress,expectedHalt,nextPc,coldFor,isIncReg,
        RegisterSource.readReg_other, debt]
      all_goals intro i hi
      all_goals by_cases eq : j+1=i <;> by_cases zi : i=0
      all_goals try subst_vars
      all_goals simp_all [regsFor,isDecReg,isIncReg,e,parameter,RegisterSource.readReg_other,Ne.symm]
  | inr ins =>
    cases ins with
    | inr n =>
      cases c <;> simp [Registers.instruction,e,perform,positive,outAddress,expectedHalt,nextPc,coldFor,isIncReg,debt]
      all_goals intro i hi
      all_goals by_cases zi : i=0
      all_goals simp_all [regsFor,isDecReg,isIncReg,e,parameter]
    | inl ins =>
      rcases ins with ⟨j,n,m,b⟩
      by_cases zr : readReg j r=0 <;> cases c <;> cases b
      all_goals simp [Registers.instruction,e,perform,chooseZero,zr,positive,outAddress,
        expectedHalt,nextPc,coldFor,isIncReg]
      all_goals try constructor
      all_goals first
        | (by_cases zj : j=0 <;> try subst_vars <;>
             solve | simp_all [RegisterSource.readReg_other,Ne.symm] )
        | (intro i hi; by_cases eq : j=i <;> by_cases zi : i=0 <;> try subst_vars <;>
             simp_all [regsFor,isDecReg,isIncReg,e,parameter,RegisterSource.readReg_other,Ne.symm])
      all_goals intro i hi
      all_goals by_cases eq : j=i <;> by_cases zi : i=0 <;> try subst_vars <;>
        simp_all [regsFor,isDecReg,isIncReg,e,parameter,RegisterSource.readReg_other,Ne.symm]

#print axioms params_input
#print axioms source_fields
end NF182PA.Symbolic
