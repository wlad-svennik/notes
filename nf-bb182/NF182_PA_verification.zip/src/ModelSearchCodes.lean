module
public import CommandWords

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
set_option maxHeartbeats 2500000
set_option maxRecDepth 6500
namespace PA192.ModelSearch.Enumeration
open RegisterFields Words
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem right_bounded (n : V) : right n ≤ n := by
  exact le_of_le_of_eq (cantor_ge_right (left n) (right n)) (inversePair_correct n)

theorem unread_bounded (w : V) : ∀ c : V, unread c w ≤ w := by
  apply modelInduct
  · definability
  · simp [unread]
  · intro c ih
    rw [unread,iterate_succ]
    exact le_trans (le_trans (right_bounded _) (right_bounded _)) ih

noncomputable def tail (n : V) : V :=
  let tag := left n
  let rest := right n
  chooseZero tag (right rest) (chooseZero (tag-1) (right rest)
    (unread (tag-2) (right (right (right rest)))))

instance tailDef : Language.DefinableFunction₁ ℒₒᵣ (tail (V:=V)) := by unfold tail; definability

theorem tail_bounded (n : V) : tail n ≤ n := by
  have h₁ : right (right n) ≤ n := le_trans (right_bounded _) (right_bounded _)
  have h₂ : right (right (right (right n))) ≤ n :=
    le_trans (right_bounded _) (le_trans (right_bounded _) h₁)
  dsimp only [tail,chooseZero]
  split
  · exact h₁
  · split
    · exact h₁
    · exact le_trans (unread_bounded ..) h₂

noncomputable def cursor (s : V) : V :=
  let k := pi₁ s
  let t := tail (pi₂ s)
  chooseZero t ⟪k+1,k+1⟫ ⟪k,t-1⟫
instance cursorDef : Language.DefinableFunction₁ ℒₒᵣ (cursor (V:=V)) := by unfold cursor; definability

theorem cursor_zero {k n : V} (h : tail n=0) : cursor ⟪k,n⟫=⟪k+1,k+1⟫ := by simp [cursor,h,chooseZero]
theorem cursor_pos {k n : V} (h : tail n≠0) : cursor ⟪k,n⟫=⟪k,tail n-1⟫ := by simp [cursor,h,chooseZero]

theorem strongModel {P : V→Prop} (d : Language.DefinablePred ℒₒᵣ P)
    (step : ∀ n, (∀ k, k<n → P k) → P n) (n : V) : P n := by
  have all : ∀ v : V, ∀ k, k<v → P k := by
    apply modelInduct
    · letI := d; definability
    · intro k h; exact False.elim ((not_lt_of_ge (show (0:V)≤k from zero_le)) h)
    · intro v ih k hk
      rcases lt_or_eq_of_le (lt_succ_iff_le.mp hk) with h|e
      · exact ih _ h
      · exact e.symm ▸ step v ih
  exact all (n+1) n (by simp)

/-- Every candidate, of arbitrary internal size and with arbitrary command fields, exhausts. -/
theorem refill (n : V) : ∀ k, ∃ j, j≤n+1 ∧ iterate cursor j ⟪k,n⟫=⟪k+1,k+1⟫ := by
  induction n using strongModel with
  | d => definability
  | step n ih =>
    intro k
    by_cases h : tail n=0
    · refine ⟨1,?_,?_⟩
      · simpa using add_le_add_right (show (0:V)≤n from zero_le) 1
      · rw [show (1:V)=0+1 by simp,iterate_succ_left,iterate_zero,cursor_zero h,zero_add]
    · have hp : 0<tail n := lt_of_le_of_ne zero_le (Ne.symm h)
      have hg : 1≤tail n := by simpa using succ_le_iff_lt.mpr hp
      have rep := sub_add_self_of_le hg
      have lt : tail n-1<n := lt_of_lt_of_le (lt_of_lt_of_eq (show tail n-1<(tail n-1)+1 from by simp) rep) (tail_bounded n)
      obtain ⟨j,hj,endp⟩ := ih (tail n-1) lt k
      refine ⟨j+1,add_le_add (le_trans hj (le_of_eq_of_le rep (tail_bounded n))) (le_refl 1),?_⟩
      rw [iterate_succ_left,cursor_pos h,endp]

/-- Consecutive enumeration visits each candidate above the current one, also in a nonstandard model. -/
theorem reaches (start : V) : ∀ d : V, ∃ j, iterate cursor j ⟪start,start⟫=⟪start+d,start+d⟫ := by
  apply modelInduct
  · definability
  · exact ⟨0,by simp⟩
  · intro d ih
    obtain ⟨j,h⟩ := ih
    obtain ⟨k,_,hk⟩ := refill (start+d) (start+d)
    exact ⟨j+k,by rw [iterate_add,h,hk,add_assoc]⟩

end PA192.ModelSearch.Enumeration
#print axioms PA192.ModelSearch.Enumeration.reaches
