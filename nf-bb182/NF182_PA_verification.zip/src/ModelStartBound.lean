module
public import StandardStartBound
public import ExactValue
public import ModelTrace

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment NF210.TM
open PA192.BusyBeaver.StartConvention PA192.PhysicalModel PA192.LiteralTM
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
namespace PA192.BusyBeaver
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- The arithmetic control permutation changes the two working numerals and fixes halt. -/
noncomputable def labelSwap (a b : Fin n) (x : V) : V :=
  if x=(a.val : V) then (b.val : V) else if x=(b.val : V) then (a.val : V) else x

theorem labelSwap_num (a b q : Fin n) :
    labelSwap a b (q.val : V)=((exchange a b q).val : V) := by
  have sep {u v : Fin n} (h : u≠v) : (u.val : V)≠(v.val : V) := by
    intro eq; apply h; apply Fin.ext; exact_mod_cast eq
  by_cases eq : q=a
  · subst q; simp [labelSwap]
  by_cases eq' : q=b
  · subst q; simp [labelSwap,sep eq]
  · simp [labelSwap,exchange,eq,eq',sep eq,sep eq']

theorem labelSwap_halt (a b : Fin n) : labelSwap a b (n : V)=(n : V) := by
  have ha : (n:V)≠(a.val:V) := by exact_mod_cast (Nat.ne_of_gt a.isLt)
  have hb : (n:V)≠(b.val:V) := by exact_mod_cast (Nat.ne_of_gt b.isLt)
  simp [labelSwap,ha,hb]

theorem labelSwap_control (a b : Fin n) (o : Option (Fin n)) :
    labelSwap a b (control o : V)=(control (o.map (exchange a b)) : V) := by
  cases o with
  | none => exact labelSwap_halt a b
  | some q => exact labelSwap_num a b q

theorem relabel_local (a b : Fin n) (m : Machine n) {s l r t u v : V}
    (h : Step m s l r t u v) : Step (relabel a b m) (labelSwap a b s) l r (labelSwap a b t) u v := by
  obtain ⟨q,d,hs,ht,move⟩ := h
  refine ⟨exchange a b q,d,?_⟩
  unfold Local
  simp only [relabel,exchange_twice,hs,ht,labelSwap_num,labelSwap_control]
  exact ⟨True.intro,True.intro,move⟩

private instance plainIndex : Language.DefinableFunction₂ ℒₒᵣ (nth : V→V→V) :=
  FFL.FirstOrder.Defined.to_definable (φ := nthDef.val) ⟨(nth_defined (V:=V)).df⟩

noncomputable instance swapDef (a b : Fin n) : Language.DefinableFunction₁ ℒₒᵣ (labelSwap a b : V→V) := by
  unfold labelSwap
  apply unary_ite _ _ _ (by definability) (by definability)
  apply unary_ite _ _ _ <;> definability

/-- The duration may be nonstandard. The new control vector exists by definable induction
in V, and both tape-ray vectors are reused verbatim. -/
theorem relabel_trace (a b q : Fin n) (m : Machine n) {t cs ls rs : V}
    (h : Trace m q t cs ls rs) : ∃ cs' : V, Trace (relabel a b m) (exchange a b q) t cs' ls rs := by
  let f := fun i : V => labelSwap a b cs.[i]
  have : Language.DefinableFunction₁ ℒₒᵣ f := by dsimp [f]; definability
  obtain ⟨cs',_,index⟩ := vector_segment f t
  obtain ⟨h0,l0,r0,ht,steps⟩ := h
  refine ⟨cs',?_,l0,r0,?_,?_⟩
  · rw [index 0 zero_le]; dsimp [f]; rw [h0,labelSwap_num]
  · rw [index t (le_refl _)]; dsimp [f]; rw [ht,labelSwap_halt]
  · intro j hj
    rw [index j (le_of_lt hj),index (j+1) (succ_le_iff_lt.mpr hj)]
    exact relabel_local a b m (steps j hj)

theorem relabel_twice (a b : Fin n) (m : Machine n) : relabel a b (relabel a b m)=m := by
  funext q d
  simp only [relabel,exchange_twice]
  rcases h : m q d with ⟨w,d,o⟩
  cases o <;> simp


/-- The upper-bound sentence retains the tables having the designated fixed start. -/
noncomputable def fixedUpper (b : Fin n) (k : Nat) : ArithmeticSentence :=
  conjunction k ((tables n).filter (fun entry => decide (entry.2 = b)))

theorem fixedUpper_eval (b : Fin n) (k : Nat) : (V ⊧/![] (fixedUpper b k)) ↔
    ∀ m : Machine n, (V ⊧/![] (traceF m b)) → (V ⊧/![] (beforeF m b k)) := by
  rw [fixedUpper,conjunction_eval]
  constructor
  · intro h m; exact h (m,b) (by simp [mem_tables])
  · intro h x hx
    rcases x with ⟨m,q⟩
    have e : q=b := of_decide_eq_true (List.mem_filter.mp hx).2
    subst q; exact h m

theorem trace_transport (a b q : Fin n) (m : Machine n) (h : V ⊧/![] (traceF m q)) :
    V ⊧/![] (traceF (relabel a b m) (exchange a b q)) := by
  obtain ⟨t,cs,ls,rs,tr⟩ := (traceF_eval m q).mp h
  obtain ⟨cs',tr'⟩ := relabel_trace a b q m tr
  exact (traceF_eval ..).mpr ⟨t,cs',ls,rs,tr'⟩

theorem before_transport (a b q : Fin n) (m : Machine n) (k : Nat) (h : V ⊧/![] (beforeF m q k)) :
    V ⊧/![] (beforeF (relabel a b m) (exchange a b q) k) := by
  obtain ⟨t,cs,ls,rs,lt,tr⟩ := (before_eval m q k).mp h
  obtain ⟨cs',tr'⟩ := relabel_trace a b q m tr
  exact (before_eval ..).mpr ⟨t,cs',ls,rs,lt,tr'⟩

theorem model_start_convention (b : Fin n) (k : Nat) :
    (V ⊧/![] (upper n k)) ↔ (V ⊧/![] (fixedUpper b k)) := by
  rw [upper_eval,fixedUpper_eval]
  constructor
  · intro h m; exact h m b
  · intro h m q hit
    have h' := trace_transport q b q m hit
    rw [exchange_left] at h'
    have h'' := before_transport q b b (relabel q b m) k (h _ h')
    simpa only [exchange_right,relabel_twice] using h''

theorem pa_start_convention (b : Fin n) (k : Nat) :
    M6.PA.theory ⊢ ((upper n k 🡒 fixedUpper b k) ⋏ (fixedUpper b k 🡒 upper n k)) := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff,LogicalConnective.HomClass.map_and,LogicalConnective.HomClass.map_imply]
  exact ⟨(model_start_convention b k).mp,(model_start_convention b k).mpr⟩

/-- The single implication needed to transfer any upper-bound nonproof. -/
theorem fixed_upper_implies_upper (b : Fin n) (k : Nat) :
    M6.PA.theory ⊢ (fixedUpper b k 🡒 upper n k) := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff,LogicalConnective.HomClass.map_imply]
  exact (model_start_convention b k).mpr

theorem no_pa_fixed_upper (b : Fin n) (k : Nat) (h : M6.PA.theory ⊬ upper n k) :
    M6.PA.theory ⊬ fixedUpper b k := fun p => h (fixed_upper_implies_upper b k ⨀ p)

noncomputable def fixedValue (b : Fin n) : Nat → ArithmeticSentence
  | 0 => fixedUpper b 0
  | k+1 => fixedUpper b (k+1) ⋏ ∼(fixedUpper b k)

/-- The corresponding least-upper-bound formulas are also equivalent in PA. -/
theorem pa_value_start_convention (b : Fin n) (k : Nat) :
    M6.PA.theory ⊢ ((value n k 🡒 fixedValue b k) ⋏ (fixedValue b k 🡒 value n k)) := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  cases k with
  | zero =>
    simp only [value,fixedValue,models_iff,LogicalConnective.HomClass.map_and,
      LogicalConnective.HomClass.map_imply]
    exact ⟨(model_start_convention b 0).mp,(model_start_convention b 0).mpr⟩
  | succ k =>
    simp only [value,fixedValue,models_iff,LogicalConnective.HomClass.map_and,
      LogicalConnective.HomClass.map_imply,LogicalConnective.HomClass.map_neg]
    rw [model_start_convention (V:=V) b k,model_start_convention (V:=V) b (k+1)]
    exact ⟨id,id⟩

end PA192.BusyBeaver
#print axioms PA192.BusyBeaver.relabel_trace
#print axioms PA192.BusyBeaver.pa_start_convention

#print axioms PA192.BusyBeaver.no_pa_fixed_upper
#print axioms PA192.BusyBeaver.pa_value_start_convention
