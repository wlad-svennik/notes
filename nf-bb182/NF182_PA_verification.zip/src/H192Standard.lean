module
public import H192Local
public import H192Trace

@[expose] public section
open NF210.TM
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic

namespace PA192.LiteralTM

noncomputable def segment (f : Nat → Nat) : Nat → Nat
  | 0 => 0
  | k+1 => concat (segment f k) (f k)

theorem segment_len (f : Nat → Nat) (k : Nat) : len (segment f k)=k := by
  induction k <;> simp [segment, *]

theorem segment_at (f : Nat → Nat) {j k : Nat} (h : j<k) : (segment f k).[j]=f j := by
  induction k with
  | zero => omega
  | succ k ih =>
    rcases Nat.lt_or_eq_of_le (Nat.le_of_lt_succ h) with h | rfl
    · rw [segment,concat_nth_lt _ _ (by simpa only [segment_len] using h),ih h]
    · exact concat_nth_len' _ _ (segment_len _ _)

theorem trace_to_halt (m : Machine n) (start : Fin n) {k cs ls rs : Nat}
    (t : Trace m start k cs ls rs) : Halts m start := by
  obtain ⟨c₀,l₀,r₀,terminal,steps⟩ := t
  simp only [natCast_nat] at c₀ terminal
  let runs := Rays.run m start
  have agrees (i : Nat) (hi : i≤k) :
      cs.[i]=control (runs i).status ∧ ls.[i]=(runs i).left ∧ rs.[i]=(runs i).right := by
    induction i with
    | zero => exact ⟨c₀,l₀,r₀⟩
    | succ i ih =>
      have ik : i<k := Nat.lt_of_succ_le hi
      obtain ⟨ec,el,er⟩ := ih (Nat.le_of_lt ik)
      have st := steps i ik
      rw [ec,el,er] at st
      exact (runs i).step_determines m st
  have ec := (agrees k (Nat.le_refl k)).1
  have endstate : (runs k).status=none :=
    control_inj (b:=none) (ec.symm.trans terminal)
  exact ⟨k,(Rays.rep_run m start k).1.trans endstate⟩

theorem trace_of_halt (m : Machine n) (start : Fin n) (halt : Halts m start) :
    ∃ k cs ls rs:Nat, Trace m start k cs ls rs := by
  classical
  let runs := Rays.run m start
  have hb : ∃ k, (runs k).status=none := by
    obtain ⟨k,h⟩ := halt
    exact ⟨k,(Rays.rep_run m start k).1.symm.trans h⟩
  let k := Nat.find hb
  have endstate : (runs k).status=none := Nat.find_spec hb
  let cs := segment (fun j=>control (runs j).status) (k+1)
  let ls := segment (fun j=>(runs j).left) (k+1)
  let rs := segment (fun j=>(runs j).right) (k+1)
  have atC (j : Nat) (h:j≤k) : cs.[j]=control (runs j).status := segment_at _ (Nat.lt_succ_of_le h)
  have atL (j : Nat) (h:j≤k) : ls.[j]=(runs j).left := segment_at _ (Nat.lt_succ_of_le h)
  have atR (j : Nat) (h:j≤k) : rs.[j]=(runs j).right := segment_at _ (Nat.lt_succ_of_le h)
  refine ⟨k,cs,ls,rs,?_,atL 0 (Nat.zero_le _),atR 0 (Nat.zero_le _),?_,?_⟩
  · simpa only [natCast_nat,runs,Rays.run,Rays.blank,control,Option.elim_some] using atC 0 (Nat.zero_le k)
  · rw [atC k (Nat.le_refl k),endstate,natCast_nat]; rfl
  · intro j hj
    have le0 := Nat.le_of_lt hj
    have le1 := Nat.succ_le_of_lt hj
    rw [atC j le0,atL j le0,atR j le0,atC (j+1) le1,atL (j+1) le1,atR (j+1) le1]
    exact (runs j).step_of_working m (Nat.find_min hb hj)

theorem traceF_standard (m : Machine n) (start : Fin n) :
    (Nat ⊧/![] (traceF m start)) ↔ Halts m start :=
  (traceF_eval _ _).trans ⟨fun ⟨_,_,_,_,t⟩=>trace_to_halt m start t,trace_of_halt m start⟩

theorem H192_standard :
    (Nat ⊧/![] H192) ↔ NF210.TM.Halts NF192.Selected.machine NF192.Selected.start :=
  traceF_standard _ _

end PA192.LiteralTM

#print axioms PA192.LiteralTM.H192_standard
