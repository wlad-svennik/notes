import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2720_0 : checkWitness 2720 false false 524 = true := by decide +kernel
private theorem w2720_1 : checkWitness 2720 false true 4620 = true := by decide +kernel
private theorem w2720_2 : checkWitness 2720 true false 524 = true := by decide +kernel
private theorem w2720_3 : checkWitness 2720 true true 4620 = true := by decide +kernel
private theorem cases2720 : checkFour 2720 (524,4620,524,4620) = true := by
  simp only [checkFour, w2720_0, w2720_1, w2720_2, w2720_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2720 : Coverage 2720 2721 := checkList_sound (ws:=[(524,4620,524,4620)]) (by simpa only [checkList, Bool.and_true] using cases2720)
private theorem w2721_0 : checkWitness 2721 false false 8951 = true := by decide +kernel
private theorem w2721_2 : checkWitness 2721 true false 8947 = true := by decide +kernel
private theorem cases2721 : checkFour 2721 (8951,0,8947,0) = true := by
  simp only [checkFour, w2721_0, w2721_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2721 : Coverage 2721 2722 := checkList_sound (ws:=[(8951,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2721)
private theorem w2722_0 : checkWitness 2722 false false 682 = true := by decide +kernel
private theorem w2722_1 : checkWitness 2722 false true 4778 = true := by decide +kernel
private theorem w2722_2 : checkWitness 2722 true false 673 = true := by decide +kernel
private theorem w2722_3 : checkWitness 2722 true true 4769 = true := by decide +kernel
private theorem cases2722 : checkFour 2722 (682,4778,673,4769) = true := by
  simp only [checkFour, w2722_0, w2722_1, w2722_2, w2722_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2722 : Coverage 2722 2723 := checkList_sound (ws:=[(682,4778,673,4769)]) (by simpa only [checkList, Bool.and_true] using cases2722)
private theorem w2723_0 : checkWitness 2723 false false 206 = true := by decide +kernel
private theorem w2723_2 : checkWitness 2723 true false 206 = true := by decide +kernel
private theorem cases2723 : checkFour 2723 (206,0,206,0) = true := by
  simp only [checkFour, w2723_0, w2723_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2723 : Coverage 2723 2724 := checkList_sound (ws:=[(206,0,206,0)]) (by simpa only [checkList, Bool.and_true] using cases2723)
private theorem w2724_0 : checkWitness 2724 false false 637 = true := by decide +kernel
private theorem w2724_1 : checkWitness 2724 false true 4725 = true := by decide +kernel
private theorem w2724_2 : checkWitness 2724 true false 637 = true := by decide +kernel
private theorem w2724_3 : checkWitness 2724 true true 4725 = true := by decide +kernel
private theorem cases2724 : checkFour 2724 (637,4725,637,4725) = true := by
  simp only [checkFour, w2724_0, w2724_1, w2724_2, w2724_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2724 : Coverage 2724 2725 := checkList_sound (ws:=[(637,4725,637,4725)]) (by simpa only [checkList, Bool.and_true] using cases2724)
private theorem w2725_0 : checkWitness 2725 false false 8966 = true := by decide +kernel
private theorem w2725_2 : checkWitness 2725 true false 8957 = true := by decide +kernel
private theorem cases2725 : checkFour 2725 (8966,0,8957,0) = true := by
  simp only [checkFour, w2725_0, w2725_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2725 : Coverage 2725 2726 := checkList_sound (ws:=[(8966,0,8957,0)]) (by simpa only [checkList, Bool.and_true] using cases2725)
private theorem w2726_0 : checkWitness 2726 false false 58 = true := by decide +kernel
private theorem w2726_2 : checkWitness 2726 true false 58 = true := by decide +kernel
private theorem cases2726 : checkFour 2726 (58,0,58,0) = true := by
  simp only [checkFour, w2726_0, w2726_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2726 : Coverage 2726 2727 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2726)
private theorem w2727_0 : checkWitness 2727 false false 50 = true := by decide +kernel
private theorem w2727_2 : checkWitness 2727 true false 50 = true := by decide +kernel
private theorem cases2727 : checkFour 2727 (50,0,50,0) = true := by
  simp only [checkFour, w2727_0, w2727_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2727 : Coverage 2727 2728 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2727)
private theorem w2728_0 : checkWitness 2728 false false 643 = true := by decide +kernel
private theorem w2728_1 : checkWitness 2728 false true 4735 = true := by decide +kernel
private theorem w2728_2 : checkWitness 2728 true false 643 = true := by decide +kernel
private theorem w2728_3 : checkWitness 2728 true true 4735 = true := by decide +kernel
private theorem cases2728 : checkFour 2728 (643,4735,643,4735) = true := by
  simp only [checkFour, w2728_0, w2728_1, w2728_2, w2728_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2728 : Coverage 2728 2729 := checkList_sound (ws:=[(643,4735,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases2728)
private theorem w2729_0 : checkWitness 2729 false false 8904 = true := by decide +kernel
private theorem w2729_2 : checkWitness 2729 true false 8900 = true := by decide +kernel
private theorem cases2729 : checkFour 2729 (8904,0,8900,0) = true := by
  simp only [checkFour, w2729_0, w2729_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2729 : Coverage 2729 2730 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2729)
private theorem w2730_0 : checkWitness 2730 false false 50 = true := by decide +kernel
private theorem w2730_2 : checkWitness 2730 true false 50 = true := by decide +kernel
private theorem cases2730 : checkFour 2730 (50,0,50,0) = true := by
  simp only [checkFour, w2730_0, w2730_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2730 : Coverage 2730 2731 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2730)
private theorem w2731_0 : checkWitness 2731 false false 604 = true := by decide +kernel
private theorem w2731_1 : checkWitness 2731 false true 4700 = true := by decide +kernel
private theorem w2731_2 : checkWitness 2731 true false 604 = true := by decide +kernel
private theorem w2731_3 : checkWitness 2731 true true 4700 = true := by decide +kernel
private theorem cases2731 : checkFour 2731 (604,4700,604,4700) = true := by
  simp only [checkFour, w2731_0, w2731_1, w2731_2, w2731_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2731 : Coverage 2731 2732 := checkList_sound (ws:=[(604,4700,604,4700)]) (by simpa only [checkList, Bool.and_true] using cases2731)
private theorem w2732_0 : checkWitness 2732 false false 8939 = true := by decide +kernel
private theorem w2732_2 : checkWitness 2732 true false 8935 = true := by decide +kernel
private theorem cases2732 : checkFour 2732 (8939,0,8935,0) = true := by
  simp only [checkFour, w2732_0, w2732_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2732 : Coverage 2732 2733 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2732)
private theorem w2733_0 : checkWitness 2733 false false 8974 = true := by decide +kernel
private theorem w2733_2 : checkWitness 2733 true false 8965 = true := by decide +kernel
private theorem cases2733 : checkFour 2733 (8974,0,8965,0) = true := by
  simp only [checkFour, w2733_0, w2733_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2733 : Coverage 2733 2734 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases2733)
private theorem w2734_0 : checkWitness 2734 false false 68 = true := by decide +kernel
private theorem w2734_2 : checkWitness 2734 true false 68 = true := by decide +kernel
private theorem cases2734 : checkFour 2734 (68,0,68,0) = true := by
  simp only [checkFour, w2734_0, w2734_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2734 : Coverage 2734 2735 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2734)
private theorem w2735_0 : checkWitness 2735 false false 686 = true := by decide +kernel
private theorem w2735_1 : checkWitness 2735 false true 4778 = true := by decide +kernel
private theorem w2735_2 : checkWitness 2735 true false 677 = true := by decide +kernel
private theorem w2735_3 : checkWitness 2735 true true 4769 = true := by decide +kernel
private theorem cases2735 : checkFour 2735 (686,4778,677,4769) = true := by
  simp only [checkFour, w2735_0, w2735_1, w2735_2, w2735_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2735 : Coverage 2735 2736 := checkList_sound (ws:=[(686,4778,677,4769)]) (by simpa only [checkList, Bool.and_true] using cases2735)
private theorem w2736_0 : checkWitness 2736 false false 8935 = true := by decide +kernel
private theorem w2736_2 : checkWitness 2736 true false 8931 = true := by decide +kernel
private theorem cases2736 : checkFour 2736 (8935,0,8931,0) = true := by
  simp only [checkFour, w2736_0, w2736_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2736 : Coverage 2736 2737 := checkList_sound (ws:=[(8935,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases2736)
private theorem w2737_0 : checkWitness 2737 false false 680 = true := by decide +kernel
private theorem w2737_1 : checkWitness 2737 false true 4772 = true := by decide +kernel
private theorem w2737_2 : checkWitness 2737 true false 671 = true := by decide +kernel
private theorem w2737_3 : checkWitness 2737 true true 4763 = true := by decide +kernel
private theorem cases2737 : checkFour 2737 (680,4772,671,4763) = true := by
  simp only [checkFour, w2737_0, w2737_1, w2737_2, w2737_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2737 : Coverage 2737 2738 := checkList_sound (ws:=[(680,4772,671,4763)]) (by simpa only [checkList, Bool.and_true] using cases2737)
private theorem w2738_0 : checkWitness 2738 false false 8904 = true := by decide +kernel
private theorem w2738_2 : checkWitness 2738 true false 8900 = true := by decide +kernel
private theorem cases2738 : checkFour 2738 (8904,0,8900,0) = true := by
  simp only [checkFour, w2738_0, w2738_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2738 : Coverage 2738 2739 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2738)
private theorem w2739_0 : checkWitness 2739 false false 56 = true := by decide +kernel
private theorem w2739_2 : checkWitness 2739 true false 56 = true := by decide +kernel
private theorem cases2739 : checkFour 2739 (56,0,56,0) = true := by
  simp only [checkFour, w2739_0, w2739_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2739 : Coverage 2739 2740 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2739)
private theorem w2740_0 : checkWitness 2740 false false 48 = true := by decide +kernel
private theorem w2740_2 : checkWitness 2740 true false 48 = true := by decide +kernel
private theorem cases2740 : checkFour 2740 (48,0,48,0) = true := by
  simp only [checkFour, w2740_0, w2740_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2740 : Coverage 2740 2741 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2740)
private theorem w2741_0 : checkWitness 2741 false false 647 = true := by decide +kernel
private theorem w2741_1 : checkWitness 2741 false true 4735 = true := by decide +kernel
private theorem w2741_2 : checkWitness 2741 true false 647 = true := by decide +kernel
private theorem w2741_3 : checkWitness 2741 true true 4735 = true := by decide +kernel
private theorem cases2741 : checkFour 2741 (647,4735,647,4735) = true := by
  simp only [checkFour, w2741_0, w2741_1, w2741_2, w2741_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2741 : Coverage 2741 2742 := checkList_sound (ws:=[(647,4735,647,4735)]) (by simpa only [checkList, Bool.and_true] using cases2741)
private theorem w2742_0 : checkWitness 2742 false false 8920 = true := by decide +kernel
private theorem w2742_2 : checkWitness 2742 true false 8916 = true := by decide +kernel
private theorem cases2742 : checkFour 2742 (8920,0,8916,0) = true := by
  simp only [checkFour, w2742_0, w2742_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2742 : Coverage 2742 2743 := checkList_sound (ws:=[(8920,0,8916,0)]) (by simpa only [checkList, Bool.and_true] using cases2742)
private theorem w2743_0 : checkWitness 2743 false false 8916 = true := by decide +kernel
private theorem w2743_2 : checkWitness 2743 true false 8912 = true := by decide +kernel
private theorem cases2743 : checkFour 2743 (8916,0,8912,0) = true := by
  simp only [checkFour, w2743_0, w2743_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2743 : Coverage 2743 2744 := checkList_sound (ws:=[(8916,0,8912,0)]) (by simpa only [checkList, Bool.and_true] using cases2743)
private theorem w2744_0 : checkWitness 2744 false false 62 = true := by decide +kernel
private theorem w2744_2 : checkWitness 2744 true false 62 = true := by decide +kernel
private theorem cases2744 : checkFour 2744 (62,0,62,0) = true := by
  simp only [checkFour, w2744_0, w2744_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2744 : Coverage 2744 2745 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2744)
private theorem w2745_0 : checkWitness 2745 false false 8928 = true := by decide +kernel
private theorem w2745_2 : checkWitness 2745 true false 8924 = true := by decide +kernel
private theorem cases2745 : checkFour 2745 (8928,0,8924,0) = true := by
  simp only [checkFour, w2745_0, w2745_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2745 : Coverage 2745 2746 := checkList_sound (ws:=[(8928,0,8924,0)]) (by simpa only [checkList, Bool.and_true] using cases2745)
private theorem w2746_0 : checkWitness 2746 false false 584 = true := by decide +kernel
private theorem w2746_1 : checkWitness 2746 false true 4680 = true := by decide +kernel
private theorem w2746_2 : checkWitness 2746 true false 584 = true := by decide +kernel
private theorem w2746_3 : checkWitness 2746 true true 4680 = true := by decide +kernel
private theorem cases2746 : checkFour 2746 (584,4680,584,4680) = true := by
  simp only [checkFour, w2746_0, w2746_1, w2746_2, w2746_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2746 : Coverage 2746 2747 := checkList_sound (ws:=[(584,4680,584,4680)]) (by simpa only [checkList, Bool.and_true] using cases2746)
private theorem w2747_0 : checkWitness 2747 false false 8990 = true := by decide +kernel
private theorem w2747_2 : checkWitness 2747 true false 8981 = true := by decide +kernel
private theorem cases2747 : checkFour 2747 (8990,0,8981,0) = true := by
  simp only [checkFour, w2747_0, w2747_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2747 : Coverage 2747 2748 := checkList_sound (ws:=[(8990,0,8981,0)]) (by simpa only [checkList, Bool.and_true] using cases2747)
private theorem w2748_0 : checkWitness 2748 false false 56 = true := by decide +kernel
private theorem w2748_2 : checkWitness 2748 true false 56 = true := by decide +kernel
private theorem cases2748 : checkFour 2748 (56,0,56,0) = true := by
  simp only [checkFour, w2748_0, w2748_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2748 : Coverage 2748 2749 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2748)
private theorem w2749_0 : checkWitness 2749 false false 572 = true := by decide +kernel
private theorem w2749_1 : checkWitness 2749 false true 4668 = true := by decide +kernel
private theorem w2749_2 : checkWitness 2749 true false 572 = true := by decide +kernel
private theorem w2749_3 : checkWitness 2749 true true 4668 = true := by decide +kernel
private theorem cases2749 : checkFour 2749 (572,4668,572,4668) = true := by
  simp only [checkFour, w2749_0, w2749_1, w2749_2, w2749_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2749 : Coverage 2749 2750 := checkList_sound (ws:=[(572,4668,572,4668)]) (by simpa only [checkList, Bool.and_true] using cases2749)
private theorem w2750_0 : checkWitness 2750 false false 8930 = true := by decide +kernel
private theorem w2750_2 : checkWitness 2750 true false 8926 = true := by decide +kernel
private theorem cases2750 : checkFour 2750 (8930,0,8926,0) = true := by
  simp only [checkFour, w2750_0, w2750_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2750 : Coverage 2750 2751 := checkList_sound (ws:=[(8930,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases2750)
private theorem w2751_0 : checkWitness 2751 false false 58 = true := by decide +kernel
private theorem w2751_2 : checkWitness 2751 true false 58 = true := by decide +kernel
private theorem cases2751 : checkFour 2751 (58,0,58,0) = true := by
  simp only [checkFour, w2751_0, w2751_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2751 : Coverage 2751 2752 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2751)
theorem cover2720 : Coverage 2720 2752 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2720 one2721) (Coverage.join one2722 one2723)) (Coverage.join (Coverage.join one2724 one2725) (Coverage.join one2726 one2727))) (Coverage.join (Coverage.join (Coverage.join one2728 one2729) (Coverage.join one2730 one2731)) (Coverage.join (Coverage.join one2732 one2733) (Coverage.join one2734 one2735)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2736 one2737) (Coverage.join one2738 one2739)) (Coverage.join (Coverage.join one2740 one2741) (Coverage.join one2742 one2743))) (Coverage.join (Coverage.join (Coverage.join one2744 one2745) (Coverage.join one2746 one2747)) (Coverage.join (Coverage.join one2748 one2749) (Coverage.join one2750 one2751)))))
end NF182PA.Symbolic
