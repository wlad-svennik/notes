module
public import CommandWords
public import ModelPackedCommands
public import ModelValue

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxHeartbeats 3000000
set_option maxRecDepth 32000
namespace PA192.ModelSearch.Compiler
open RegisterFields RegisterCommands Words
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- The three auxiliary command records. The AX record requests all-zero additional fields. -/
noncomputable def cmdMP (d : V) : V := ⟪0,d⟫
noncomputable def cmdMode (d : V) : V := ⟪1,d⟫
noncomputable def cmdAX (u b d c : V) : V := ⟪2,⟪u,b,d,c⟫⟫
noncomputable def nip : V := cmdMode 0
noncomputable def swap : V := cmdMode 1
noncomputable def blank : V := cmdAX 0 0 0 0

noncomputable def argBody (a e : V) : V :=
  let p := param e+pi₁ a
  front9 (p+pi₁ (pi₂ (pi₂ a))) (cache e+pi₁ (pi₂ a)) (pi₂ (pi₂ (pi₂ a))) p (cantor (top e) (stack e))
instance argBodyDef : Language.DefinableFunction₂ ℒₒᵣ (argBody (V:=V)) := by
  unfold argBody param cache top stack
  apply Language.DefinableFunction₅.comp (F:=front9) <;> definability

noncomputable def axOn (a e : V) : V :=
  let c:=pi₂ (pi₂ (pi₂ a))
  popAfterAX (batchBody (iterate nextBatch c (batch c (argBody a e) (zeroBatches c 0))))
instance axOnDef : Language.DefinableFunction₂ ℒₒᵣ (axOn (V:=V)) := by
  unfold axOn popAfterAX batchBody batch state; definability

noncomputable def exec (cmd e : V) : V :=
  let tag := pi₁ cmd
  let a := pi₂ cmd
  chooseZero tag (mp a e) (chooseZero (tag-1) (mode a e) (axOn a e))

instance execDef : Language.DefinableFunction₂ ℒₒᵣ (exec (V:=V)) := by
  have hmp : Language.DefinableFunction₂ ℒₒᵣ (mp (V:=V)) := by
    change Language.Definable _ _
    apply Language.Definable.of_iff (Q:=fun v : Fin 3 → V =>
      let t:=top (v 2); let s:=stack (v 2); let h:=cache (v 2); let b:=param (v 2)+v 1
      (h=imp t b ∧ v 0=state b s 0 b) ∨ (h≠imp t b ∧ v 0=state 0 s 0 b))
    · dsimp [top,stack,cache,param,state,imp]; definability
    · intro v; by_cases H : cache (v 2)=imp (top (v 2)) (param (v 2)+v 1) <;> simp [mp,H]
  have hm : Language.DefinableFunction₂ ℒₒᵣ (mode (V:=V)) := by
    apply Language.Definable.of_iff (Q:=fun v : Fin 3 → V =>
      let t:=top (v 2); let s:=stack (v 2); let h:=cache (v 2); let b:=param (v 2)+v 1
      (b=0 ∧ v 0=state t (right s) (left s) 0) ∨ (b≠0 ∧ v 0=state h s t (b-1)))
    · dsimp [top,stack,cache,param,state]; definability
    · intro v; by_cases H : param (v 2)+v 1=0 <;> simp [mode,H]
  letI := hmp
  letI := hm
  change Language.DefinableFunction₂ ℒₒᵣ (fun cmd e : V =>
    chooseZero (pi₁ cmd) (mp (pi₂ cmd) e) (chooseZero (pi₁ cmd-1) (mode (pi₂ cmd) e) (axOn (pi₂ cmd) e)))
  definability

@[simp] theorem exec_mp (d e : V) : exec (cmdMP d) e=mp d e := by simp [exec,cmdMP,chooseZero]
@[simp] theorem exec_mode (d e : V) : exec (cmdMode d) e=mode d e := by simp [exec,cmdMode,chooseZero]
@[simp] theorem exec_ax (u b d c e : V) : exec (cmdAX u b d c) e=pi₁ (axRaw u b d c (zeroBatches c 0) e) := by
  have two : (2:V)=1+1 := by norm_num
  have minus : (2:V)-1=1 := by rw [two]; simp
  simp [exec,cmdAX,chooseZero,minus,axOn,argBody,axRaw]

@[simp] theorem nip_packed (t s h : V) : exec nip (state t s h 0)=state t (right s) (left s) 0 := by
  simp [nip,nip_state]
@[simp] theorem swap_packed (t s h : V) : exec swap (state t s h 0)=state h s t 0 := by
  simp [swap,swap_state]
@[simp] theorem blank_packed (t s h p : V) : exec blank (state t s h p)=
    state (row8 p h) (front7 p h 0 p (cantor t s)) (row7 p h) 0 := by
  simp [blank,ax_zero]

instance consNipDef : Language.DefinableFunction₁ ℒₒᵣ (cons (nip:V)) := by
  unfold nip cmdMode; definability

noncomputable def nips (n : V) := iterate (cons (nip : V)) n 0
instance nipsDef : Language.DefinableFunction₁ ℒₒᵣ (nips (V:=V)) := by
  unfold nips; definability

@[simp] theorem nips_zero : nips (0:V)=0 := by simp [nips]
theorem nips_succ (n : V) : nips (n+1) = cons nip (nips n) := iterate_succ _ _ _

theorem nip_add (a b s : V) : run exec (nips (a+b)) s = run exec (nips b) (run exec (nips a) s) := by
  have aux : ∀ n : V, ∀ p, run exec (nips (n+b)) p = run exec (nips b) (run exec (nips n) p) := by
    apply modelInduct
    · definability
    · simp
    · intro n ih p; rw [add_right_comm n 1 b,nips_succ,nips_succ,run_cons,run_cons,ih]
  exact aux a s

noncomputable def singleton (x : V) := cons x 0
@[simp] theorem run_single (x s : V) : run exec (singleton x) s=exec x s := by simp [singleton]

end PA192.ModelSearch.Compiler
#print axioms PA192.ModelSearch.Compiler.nip_add
