import NF185PATapeBatchCheck
namespace NF185PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w640_0 : checkWitness 640 false false 544 = true := by decide +kernel
private theorem w640_1 : checkWitness 640 false true 4640 = true := by decide +kernel
private theorem w640_2 : checkWitness 640 true false 544 = true := by decide +kernel
private theorem w640_3 : checkWitness 640 true true 4640 = true := by decide +kernel
private theorem cases640 : checkFour 640 (544,4640,544,4640) = true := by
  simp only [checkFour, w640_0, w640_1, w640_2, w640_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one640 : Coverage 640 641 := checkList_sound (ws:=[(544,4640,544,4640)]) (by simpa only [checkList, Bool.and_true] using cases640)
private theorem w641_0 : checkWitness 641 false false 8887 = true := by decide +kernel
private theorem w641_2 : checkWitness 641 true false 8883 = true := by decide +kernel
private theorem cases641 : checkFour 641 (8887,0,8883,0) = true := by
  simp only [checkFour, w641_0, w641_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one641 : Coverage 641 642 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases641)
private theorem w642_0 : checkWitness 642 false false 8928 = true := by decide +kernel
private theorem w642_2 : checkWitness 642 true false 8919 = true := by decide +kernel
private theorem cases642 : checkFour 642 (8928,0,8919,0) = true := by
  simp only [checkFour, w642_0, w642_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one642 : Coverage 642 643 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases642)
private theorem w643_0 : checkWitness 643 false false 78 = true := by decide +kernel
private theorem w643_2 : checkWitness 643 true false 78 = true := by decide +kernel
private theorem cases643 : checkFour 643 (78,0,78,0) = true := by
  simp only [checkFour, w643_0, w643_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one643 : Coverage 643 644 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases643)
private theorem w644_0 : checkWitness 644 false false 632 = true := by decide +kernel
private theorem w644_1 : checkWitness 644 false true 4724 = true := by decide +kernel
private theorem w644_2 : checkWitness 644 true false 623 = true := by decide +kernel
private theorem w644_3 : checkWitness 644 true true 4715 = true := by decide +kernel
private theorem cases644 : checkFour 644 (632,4724,623,4715) = true := by
  simp only [checkFour, w644_0, w644_1, w644_2, w644_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one644 : Coverage 644 645 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases644)
private theorem w645_0 : checkWitness 645 false false 8883 = true := by decide +kernel
private theorem w645_2 : checkWitness 645 true false 8879 = true := by decide +kernel
private theorem cases645 : checkFour 645 (8883,0,8879,0) = true := by
  simp only [checkFour, w645_0, w645_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one645 : Coverage 645 646 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases645)
private theorem w646_0 : checkWitness 646 false false 620 = true := by decide +kernel
private theorem w646_1 : checkWitness 646 false true 4712 = true := by decide +kernel
private theorem w646_2 : checkWitness 646 true false 611 = true := by decide +kernel
private theorem w646_3 : checkWitness 646 true true 4703 = true := by decide +kernel
private theorem cases646 : checkFour 646 (620,4712,611,4703) = true := by
  simp only [checkFour, w646_0, w646_1, w646_2, w646_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one646 : Coverage 646 647 := checkList_sound (ws:=[(620,4712,611,4703)]) (by simpa only [checkList, Bool.and_true] using cases646)
private theorem w647_0 : checkWitness 647 false false 8850 = true := by decide +kernel
private theorem w647_2 : checkWitness 647 true false 8846 = true := by decide +kernel
private theorem cases647 : checkFour 647 (8850,0,8846,0) = true := by
  simp only [checkFour, w647_0, w647_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one647 : Coverage 647 648 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases647)
private theorem w648_0 : checkWitness 648 false false 78 = true := by decide +kernel
private theorem w648_2 : checkWitness 648 true false 78 = true := by decide +kernel
private theorem cases648 : checkFour 648 (78,0,78,0) = true := by
  simp only [checkFour, w648_0, w648_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one648 : Coverage 648 649 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases648)
private theorem w649_0 : checkWitness 649 false false 72 = true := by decide +kernel
private theorem w649_2 : checkWitness 649 true false 72 = true := by decide +kernel
private theorem cases649 : checkFour 649 (72,0,72,0) = true := by
  simp only [checkFour, w649_0, w649_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one649 : Coverage 649 650 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases649)
private theorem w650_0 : checkWitness 650 false false 583 = true := by decide +kernel
private theorem w650_1 : checkWitness 650 false true 4671 = true := by decide +kernel
private theorem w650_2 : checkWitness 650 true false 583 = true := by decide +kernel
private theorem w650_3 : checkWitness 650 true true 4671 = true := by decide +kernel
private theorem cases650 : checkFour 650 (583,4671,583,4671) = true := by
  simp only [checkFour, w650_0, w650_1, w650_2, w650_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one650 : Coverage 650 651 := checkList_sound (ws:=[(583,4671,583,4671)]) (by simpa only [checkList, Bool.and_true] using cases650)
private theorem w651_0 : checkWitness 651 false false 8866 = true := by decide +kernel
private theorem w651_2 : checkWitness 651 true false 8862 = true := by decide +kernel
private theorem cases651 : checkFour 651 (8866,0,8862,0) = true := by
  simp only [checkFour, w651_0, w651_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one651 : Coverage 651 652 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases651)
private theorem w652_0 : checkWitness 652 false false 8862 = true := by decide +kernel
private theorem w652_2 : checkWitness 652 true false 8858 = true := by decide +kernel
private theorem cases652 : checkFour 652 (8862,0,8858,0) = true := by
  simp only [checkFour, w652_0, w652_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one652 : Coverage 652 653 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases652)
private theorem w653_0 : checkWitness 653 false false 74 = true := by decide +kernel
private theorem w653_2 : checkWitness 653 true false 74 = true := by decide +kernel
private theorem cases653 : checkFour 653 (74,0,74,0) = true := by
  simp only [checkFour, w653_0, w653_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one653 : Coverage 653 654 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases653)
private theorem w654_0 : checkWitness 654 false false 8882 = true := by decide +kernel
private theorem w654_2 : checkWitness 654 true false 8878 = true := by decide +kernel
private theorem cases654 : checkFour 654 (8882,0,8878,0) = true := by
  simp only [checkFour, w654_0, w654_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one654 : Coverage 654 655 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases654)
private theorem w655_0 : checkWitness 655 false false 506 = true := by decide +kernel
private theorem w655_1 : checkWitness 655 false true 4602 = true := by decide +kernel
private theorem w655_2 : checkWitness 655 true false 506 = true := by decide +kernel
private theorem w655_3 : checkWitness 655 true true 4602 = true := by decide +kernel
private theorem cases655 : checkFour 655 (506,4602,506,4602) = true := by
  simp only [checkFour, w655_0, w655_1, w655_2, w655_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one655 : Coverage 655 656 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases655)
private theorem w656_0 : checkWitness 656 false false 8958 = true := by decide +kernel
private theorem w656_2 : checkWitness 656 true false 8949 = true := by decide +kernel
private theorem cases656 : checkFour 656 (8958,0,8949,0) = true := by
  simp only [checkFour, w656_0, w656_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one656 : Coverage 656 657 := checkList_sound (ws:=[(8958,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases656)
private theorem w657_0 : checkWitness 657 false false 78 = true := by decide +kernel
private theorem w657_2 : checkWitness 657 true false 78 = true := by decide +kernel
private theorem cases657 : checkFour 657 (78,0,78,0) = true := by
  simp only [checkFour, w657_0, w657_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one657 : Coverage 657 658 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases657)
private theorem w658_0 : checkWitness 658 false false 538 = true := by decide +kernel
private theorem w658_1 : checkWitness 658 false true 4634 = true := by decide +kernel
private theorem w658_2 : checkWitness 658 true false 538 = true := by decide +kernel
private theorem w658_3 : checkWitness 658 true true 4634 = true := by decide +kernel
private theorem cases658 : checkFour 658 (538,4634,538,4634) = true := by
  simp only [checkFour, w658_0, w658_1, w658_2, w658_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one658 : Coverage 658 659 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases658)
private theorem w659_0 : checkWitness 659 false false 8902 = true := by decide +kernel
private theorem w659_2 : checkWitness 659 true false 8898 = true := by decide +kernel
private theorem cases659 : checkFour 659 (8902,0,8898,0) = true := by
  simp only [checkFour, w659_0, w659_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one659 : Coverage 659 660 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases659)
private theorem w660_0 : checkWitness 660 false false 82 = true := by decide +kernel
private theorem w660_2 : checkWitness 660 true false 82 = true := by decide +kernel
private theorem cases660 : checkFour 660 (82,0,82,0) = true := by
  simp only [checkFour, w660_0, w660_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one660 : Coverage 660 661 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases660)
private theorem w661_0 : checkWitness 661 false false 582 = true := by decide +kernel
private theorem w661_1 : checkWitness 661 false true 4678 = true := by decide +kernel
private theorem w661_2 : checkWitness 661 true false 582 = true := by decide +kernel
private theorem w661_3 : checkWitness 661 true true 4678 = true := by decide +kernel
private theorem cases661 : checkFour 661 (582,4678,582,4678) = true := by
  simp only [checkFour, w661_0, w661_1, w661_2, w661_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one661 : Coverage 661 662 := checkList_sound (ws:=[(582,4678,582,4678)]) (by simpa only [checkList, Bool.and_true] using cases661)
private theorem w662_0 : checkWitness 662 false false 8925 = true := by decide +kernel
private theorem w662_2 : checkWitness 662 true false 8921 = true := by decide +kernel
private theorem cases662 : checkFour 662 (8925,0,8921,0) = true := by
  simp only [checkFour, w662_0, w662_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one662 : Coverage 662 663 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases662)
private theorem w663_0 : checkWitness 663 false false 8966 = true := by decide +kernel
private theorem w663_2 : checkWitness 663 true false 8957 = true := by decide +kernel
private theorem cases663 : checkFour 663 (8966,0,8957,0) = true := by
  simp only [checkFour, w663_0, w663_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one663 : Coverage 663 664 := checkList_sound (ws:=[(8966,0,8957,0)]) (by simpa only [checkList, Bool.and_true] using cases663)
private theorem w664_0 : checkWitness 664 false false 94 = true := by decide +kernel
private theorem w664_2 : checkWitness 664 true false 94 = true := by decide +kernel
private theorem cases664 : checkFour 664 (94,0,94,0) = true := by
  simp only [checkFour, w664_0, w664_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one664 : Coverage 664 665 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases664)
private theorem w665_0 : checkWitness 665 false false 670 = true := by decide +kernel
private theorem w665_1 : checkWitness 665 false true 4762 = true := by decide +kernel
private theorem w665_2 : checkWitness 665 true false 661 = true := by decide +kernel
private theorem w665_3 : checkWitness 665 true true 4753 = true := by decide +kernel
private theorem cases665 : checkFour 665 (670,4762,661,4753) = true := by
  simp only [checkFour, w665_0, w665_1, w665_2, w665_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one665 : Coverage 665 666 := checkList_sound (ws:=[(670,4762,661,4753)]) (by simpa only [checkList, Bool.and_true] using cases665)
private theorem w666_0 : checkWitness 666 false false 8921 = true := by decide +kernel
private theorem w666_2 : checkWitness 666 true false 8917 = true := by decide +kernel
private theorem cases666 : checkFour 666 (8921,0,8917,0) = true := by
  simp only [checkFour, w666_0, w666_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one666 : Coverage 666 667 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases666)
private theorem w667_0 : checkWitness 667 false false 658 = true := by decide +kernel
private theorem w667_1 : checkWitness 667 false true 4750 = true := by decide +kernel
private theorem w667_2 : checkWitness 667 true false 649 = true := by decide +kernel
private theorem w667_3 : checkWitness 667 true true 4741 = true := by decide +kernel
private theorem cases667 : checkFour 667 (658,4750,649,4741) = true := by
  simp only [checkFour, w667_0, w667_1, w667_2, w667_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one667 : Coverage 667 668 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases667)
private theorem w668_0 : checkWitness 668 false false 8888 = true := by decide +kernel
private theorem w668_2 : checkWitness 668 true false 8884 = true := by decide +kernel
private theorem cases668 : checkFour 668 (8888,0,8884,0) = true := by
  simp only [checkFour, w668_0, w668_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one668 : Coverage 668 669 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases668)
private theorem w669_0 : checkWitness 669 false false 94 = true := by decide +kernel
private theorem w669_2 : checkWitness 669 true false 94 = true := by decide +kernel
private theorem cases669 : checkFour 669 (94,0,94,0) = true := by
  simp only [checkFour, w669_0, w669_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one669 : Coverage 669 670 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases669)
private theorem w670_0 : checkWitness 670 false false 88 = true := by decide +kernel
private theorem w670_2 : checkWitness 670 true false 88 = true := by decide +kernel
private theorem cases670 : checkFour 670 (88,0,88,0) = true := by
  simp only [checkFour, w670_0, w670_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one670 : Coverage 670 671 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases670)
private theorem w671_0 : checkWitness 671 false false 619 = true := by decide +kernel
private theorem w671_1 : checkWitness 671 false true 4703 = true := by decide +kernel
private theorem w671_2 : checkWitness 671 true false 619 = true := by decide +kernel
private theorem w671_3 : checkWitness 671 true true 4703 = true := by decide +kernel
private theorem cases671 : checkFour 671 (619,4703,619,4703) = true := by
  simp only [checkFour, w671_0, w671_1, w671_2, w671_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one671 : Coverage 671 672 := checkList_sound (ws:=[(619,4703,619,4703)]) (by simpa only [checkList, Bool.and_true] using cases671)
theorem cover0640 : Coverage 640 672 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one640 one641) (Coverage.join one642 one643)) (Coverage.join (Coverage.join one644 one645) (Coverage.join one646 one647))) (Coverage.join (Coverage.join (Coverage.join one648 one649) (Coverage.join one650 one651)) (Coverage.join (Coverage.join one652 one653) (Coverage.join one654 one655)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one656 one657) (Coverage.join one658 one659)) (Coverage.join (Coverage.join one660 one661) (Coverage.join one662 one663))) (Coverage.join (Coverage.join (Coverage.join one664 one665) (Coverage.join one666 one667)) (Coverage.join (Coverage.join one668 one669) (Coverage.join one670 one671)))))
end NF185PA.Symbolic
