import DefinableQuotient
import RawLanguage
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF192.Direct NF192.Ground PA192.Numerals.FoundationRoute
namespace NF192.Internal
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem cons_restore (e : Fin (n+1) → V) : (fun i => Fin.cases (e 0) (fun j => e j.succ) i)=e := by
  funext i;cases i using Fin.cases <;> rfl

/-- Every *fixed* displayed row subformula defines an old-arithmetic relation
    as soon as the row equality and the Jensen membership do. -/
theorem fixedSetDef {r m : V → V → Prop} [Language.DefinableRel ℒₒᵣ r] [Language.DefinableRel ℒₒᵣ m]
    (a : SetForm n) : Language.Definable ℒₒᵣ (a.truthWith r m) := by
  induction a with
  | mem i j => exact Language.DefinableRel.comp (P:=m) (Language.DefinableFunction.projection _) (Language.DefinableFunction.projection _)
  | eq i j => exact Language.DefinableRel.comp (P:=r) (Language.DefinableFunction.projection _) (Language.DefinableFunction.projection _)
  | not a h => exact h.not
  | and a b h j => exact h.and j
  | or a b h j => exact h.or j
  | imp a b h j => exact h.imp j
  | iff a b h j => exact h.biconditional j
  | all a h =>
    apply Language.Definable.all
    exact h.of_iff (by intro v;rw [cons_restore])
  | ex a h =>
    apply Language.Definable.exs
    exact h.of_iff (by intro v;rw [cons_restore])

theorem jensenDef (sig : Signature V) (r : V → V → Prop)
    [Language.DefinableRel ℒₒᵣ r] [Language.DefinableFunction₂ ℒₒᵣ sig.app] :
    Language.DefinableRel ℒₒᵣ (RawJ sig r) := by
  unfold RawJ
  definability

theorem minChoice {R : (Fin (n+1) → V) → Prop} (hR : Language.Definable ℒₒᵣ R)
    (existsR : ∀e:Fin n→V,∃x,R (x :> e)) :
    ∃f : (Fin n → V) → V, Language.DefinableFunction ℒₒᵣ f ∧ ∀e,R (f e :> e) := by
  classical
  have pl (e : Fin n → V) : Language.DefinablePred ℒₒᵣ (fun x => R (x :> e)) := by
    change Language.Definable ℒₒᵣ (fun v : Fin 1→V => R (v 0 :> e))
    apply Language.Definable.of_iff (Language.Definable.substitution hR (f:=fun i => Fin.cases (fun v : Fin 1→V => v 0) (fun j _ => e j) i)
      (by intro i;cases i using Fin.cases <;> definability))
    intro v;apply Iff.of_eq;congr 1;funext i;cases i using Fin.cases <;> rfl
  have get (e : Fin n→V) : ∃x,R (x :> e) ∧ ∀y<x, ¬R (y :> e) := by
    obtain ⟨x,hx⟩ := existsR e;letI := pl e
    exact least_plain (fun y => R (y :> e)) hx
  let f (e : Fin n→V) := (get e).choose
  have good (e) : R (f e :> e) ∧ ∀y<f e,¬R (y :> e) := (get e).choose_spec
  refine ⟨f,?_,fun e => (good e).1⟩
  let P := fun v : Fin (n+1)→V => R v ∧ ∀ y<v 0,¬R (y :> (fun j => v j.succ))
  have htail : Language.Definable ℒₒᵣ (fun w : Fin ((n+1)+1)→V => R (w 0 :> (fun j => w j.succ.succ))) := by
    apply Language.Definable.of_iff (Language.Definable.retraction hR (Fin.cases 0 (fun j => j.succ.succ)))
    intro w;apply Iff.of_eq;congr 1;funext i;cases i using Fin.cases <;> rfl
  have pdef : Language.Definable ℒₒᵣ P := by
    refine hR.and (Language.Definable.all ?_)
    exact Language.Definable.imp (by definability) htail.not
  apply Language.Definable.of_iff pdef
  intro v
  change v 0=f (fun j => v j.succ) ↔ _
  let e := fun j : Fin n => v j.succ
  have restore : (v 0 :> e)=v := by funext i;cases i using Fin.cases <;> rfl
  change v 0=f e ↔ R v ∧ ∀ y<v 0,¬R (y :> e)
  rw [←restore];change v 0=f e ↔ R (v 0 :> e) ∧ ∀y<v 0,¬R (y :> e)
  constructor
  · intro h;rw [h];exact good e
  · intro hu;rcases lt_trichotomy (v 0) (f e) with h|h|h
    · exact False.elim ((good e).2 _ h hu.1)
    · exact h
    · exact False.elim (hu.2 _ h (good e).1)

#print axioms fixedSetDef
#print axioms minChoice
end NF192.Internal
