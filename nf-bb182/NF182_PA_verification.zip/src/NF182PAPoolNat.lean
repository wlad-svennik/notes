import NF182PAPool
import Moving186Logic
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
namespace NF182PA.Pool
theorem batch_exact (a b c u : Nat) : batch a b c u = Moving186.rowList a b c u := by
  have hs : (s : Nat) = NF192.Numerical.s := rfl
  have hk (x : Nat) : konst x = NF192.Numerical.konst x := literal_witness _ _
  simp only [batch,Moving186.rowList,row0,row2,row3,row4,row6,row8,
    nativeB,test,single,NF192.Emitter.row0,NF192.Emitter.row2,NF192.Emitter.row3,
    NF192.Emitter.row4,NF192.Emitter.row6,NF192.Emitter.row9,
    Moving186.bRow,Moving186.testRow,Moving186.single,hs,hk,
    literal_imp,literal_eqn,literal_app,literal_witness,q,NF192.Numerical.q]
  rfl

theorem pool_of_derivation {p : Nat} (d : Moving186.Deriv p) : Pr ∅ p := by
  induction d with
  | @row a b c u x hu hx =>
    exact leaf (Or.inl (ax_of_mem (a:=a) (b:=b) (c:=c) (u:=u) (Nat.not_lt.mpr hu) (by rwa [batch_exact])))
  | mp _ _ major minor => exact mp (by simpa only [literal_imp] using major) minor

theorem derivation_of_pool {p : Nat} (d : Pr ∅ p) : Moving186.Deriv p := by
  obtain ⟨pool,k,valid,hp⟩ := d
  have sound (j : Nat) : ∀ x, ⟪j,x⟫ ∈ pool → Moving186.Deriv x := by
    induction j using Nat.strongRecOn with
    | ind j ih =>
      intro x hx
      rcases valid j x hx with ⟨a,b,c,u,hu,hr⟩ | empty | ⟨a,i,l,hi,hl,major,minor⟩
      · exact .row (a:=a) (b:=b) (c:=c) (u:=u) (Nat.le_of_not_gt hu) (by rwa [←batch_exact])
      · simp at empty
      · exact .mp (by simpa only [literal_imp] using ih i hi _ major) (ih l hl _ minor)
  exact sound k p hp

theorem deriv_iff_pool (p : Nat) : Moving186.Deriv p ↔ Pr ∅ p :=
  ⟨pool_of_derivation,derivation_of_pool⟩
end NF182PA.Pool
#print axioms NF182PA.Pool.deriv_iff_pool
