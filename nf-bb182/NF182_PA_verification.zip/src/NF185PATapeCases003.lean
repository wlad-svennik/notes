import NF185PATapeBatchCheck
namespace NF185PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w96_0 : checkWitness 96 false false 633 = true := by decide +kernel
private theorem w96_1 : checkWitness 96 false true 4717 = true := by decide +kernel
private theorem w96_2 : checkWitness 96 true false 633 = true := by decide +kernel
private theorem w96_3 : checkWitness 96 true true 4717 = true := by decide +kernel
private theorem cases96 : checkFour 96 (633,4717,633,4717) = true := by
  simp only [checkFour, w96_0, w96_1, w96_2, w96_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one96 : Coverage 96 97 := checkList_sound (ws:=[(633,4717,633,4717)]) (by simpa only [checkList, Bool.and_true] using cases96)
private theorem w97_0 : checkWitness 97 false false 8902 = true := by decide +kernel
private theorem w97_2 : checkWitness 97 true false 8898 = true := by decide +kernel
private theorem cases97 : checkFour 97 (8902,0,8898,0) = true := by
  simp only [checkFour, w97_0, w97_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one97 : Coverage 97 98 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases97)
private theorem w98_0 : checkWitness 98 false false 64 = true := by decide +kernel
private theorem w98_2 : checkWitness 98 true false 64 = true := by decide +kernel
private theorem cases98 : checkFour 98 (64,0,64,0) = true := by
  simp only [checkFour, w98_0, w98_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one98 : Coverage 98 99 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases98)
private theorem w99_0 : checkWitness 99 false false 603 = true := by decide +kernel
private theorem w99_1 : checkWitness 99 false true 4699 = true := by decide +kernel
private theorem w99_2 : checkWitness 99 true false 603 = true := by decide +kernel
private theorem w99_3 : checkWitness 99 true true 4699 = true := by decide +kernel
private theorem cases99 : checkFour 99 (603,4699,603,4699) = true := by
  simp only [checkFour, w99_0, w99_1, w99_2, w99_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one99 : Coverage 99 100 := checkList_sound (ws:=[(603,4699,603,4699)]) (by simpa only [checkList, Bool.and_true] using cases99)
private theorem w100_0 : checkWitness 100 false false 8954 = true := by decide +kernel
private theorem w100_2 : checkWitness 100 true false 8945 = true := by decide +kernel
private theorem cases100 : checkFour 100 (8954,0,8945,0) = true := by
  simp only [checkFour, w100_0, w100_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one100 : Coverage 100 101 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases100)
private theorem w101_0 : checkWitness 101 false false 8898 = true := by decide +kernel
private theorem w101_2 : checkWitness 101 true false 8894 = true := by decide +kernel
private theorem cases101 : checkFour 101 (8898,0,8894,0) = true := by
  simp only [checkFour, w101_0, w101_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one101 : Coverage 101 102 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases101)
private theorem w102_0 : checkWitness 102 false false 56 = true := by decide +kernel
private theorem w102_2 : checkWitness 102 true false 56 = true := by decide +kernel
private theorem cases102 : checkFour 102 (56,0,56,0) = true := by
  simp only [checkFour, w102_0, w102_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one102 : Coverage 102 103 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases102)
private theorem w103_0 : checkWitness 103 false false 682 = true := by decide +kernel
private theorem w103_1 : checkWitness 103 false true 4770 = true := by decide +kernel
private theorem w103_2 : checkWitness 103 true false 673 = true := by decide +kernel
private theorem w103_3 : checkWitness 103 true true 4761 = true := by decide +kernel
private theorem cases103 : checkFour 103 (682,4770,673,4761) = true := by
  simp only [checkFour, w103_0, w103_1, w103_2, w103_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one103 : Coverage 103 104 := checkList_sound (ws:=[(682,4770,673,4761)]) (by simpa only [checkList, Bool.and_true] using cases103)
private theorem w104_0 : checkWitness 104 false false 8939 = true := by decide +kernel
private theorem w104_2 : checkWitness 104 true false 8935 = true := by decide +kernel
private theorem cases104 : checkFour 104 (8939,0,8935,0) = true := by
  simp only [checkFour, w104_0, w104_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one104 : Coverage 104 105 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases104)
private theorem w105_0 : checkWitness 105 false false 60 = true := by decide +kernel
private theorem w105_2 : checkWitness 105 true false 60 = true := by decide +kernel
private theorem cases105 : checkFour 105 (60,0,60,0) = true := by
  simp only [checkFour, w105_0, w105_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one105 : Coverage 105 106 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases105)
private theorem w106_0 : checkWitness 106 false false 526 = true := by decide +kernel
private theorem w106_1 : checkWitness 106 false true 4622 = true := by decide +kernel
private theorem w106_2 : checkWitness 106 true false 526 = true := by decide +kernel
private theorem w106_3 : checkWitness 106 true true 4622 = true := by decide +kernel
private theorem cases106 : checkFour 106 (526,4622,526,4622) = true := by
  simp only [checkFour, w106_0, w106_1, w106_2, w106_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one106 : Coverage 106 107 := checkList_sound (ws:=[(526,4622,526,4622)]) (by simpa only [checkList, Bool.and_true] using cases106)
private theorem w107_0 : checkWitness 107 false false 8929 = true := by decide +kernel
private theorem w107_2 : checkWitness 107 true false 8925 = true := by decide +kernel
private theorem cases107 : checkFour 107 (8929,0,8925,0) = true := by
  simp only [checkFour, w107_0, w107_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one107 : Coverage 107 108 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases107)
private theorem w108_0 : checkWitness 108 false false 658 = true := by decide +kernel
private theorem w108_1 : checkWitness 108 false true 4754 = true := by decide +kernel
private theorem w108_2 : checkWitness 108 true false 649 = true := by decide +kernel
private theorem w108_3 : checkWitness 108 true true 4745 = true := by decide +kernel
private theorem cases108 : checkFour 108 (658,4754,649,4745) = true := by
  simp only [checkFour, w108_0, w108_1, w108_2, w108_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one108 : Coverage 108 109 := checkList_sound (ws:=[(658,4754,649,4745)]) (by simpa only [checkList, Bool.and_true] using cases108)
private theorem w109_0 : checkWitness 109 false false 196 = true := by decide +kernel
private theorem w109_2 : checkWitness 109 true false 196 = true := by decide +kernel
private theorem cases109 : checkFour 109 (196,0,196,0) = true := by
  simp only [checkFour, w109_0, w109_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one109 : Coverage 109 110 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases109)
private theorem w110_0 : checkWitness 110 false false 603 = true := by decide +kernel
private theorem w110_1 : checkWitness 110 false true 4691 = true := by decide +kernel
private theorem w110_2 : checkWitness 110 true false 603 = true := by decide +kernel
private theorem w110_3 : checkWitness 110 true true 4691 = true := by decide +kernel
private theorem cases110 : checkFour 110 (603,4691,603,4691) = true := by
  simp only [checkFour, w110_0, w110_1, w110_2, w110_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one110 : Coverage 110 111 := checkList_sound (ws:=[(603,4691,603,4691)]) (by simpa only [checkList, Bool.and_true] using cases110)
private theorem w111_0 : checkWitness 111 false false 8944 = true := by decide +kernel
private theorem w111_2 : checkWitness 111 true false 8935 = true := by decide +kernel
private theorem cases111 : checkFour 111 (8944,0,8935,0) = true := by
  simp only [checkFour, w111_0, w111_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one111 : Coverage 111 112 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases111)
private theorem w112_0 : checkWitness 112 false false 60 = true := by decide +kernel
private theorem w112_2 : checkWitness 112 true false 60 = true := by decide +kernel
private theorem cases112 : checkFour 112 (60,0,60,0) = true := by
  simp only [checkFour, w112_0, w112_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one112 : Coverage 112 113 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases112)
private theorem w113_0 : checkWitness 113 false false 52 = true := by decide +kernel
private theorem w113_2 : checkWitness 113 true false 52 = true := by decide +kernel
private theorem cases113 : checkFour 113 (52,0,52,0) = true := by
  simp only [checkFour, w113_0, w113_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one113 : Coverage 113 114 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases113)
private theorem w114_0 : checkWitness 114 false false 609 = true := by decide +kernel
private theorem w114_1 : checkWitness 114 false true 4701 = true := by decide +kernel
private theorem w114_2 : checkWitness 114 true false 609 = true := by decide +kernel
private theorem w114_3 : checkWitness 114 true true 4701 = true := by decide +kernel
private theorem cases114 : checkFour 114 (609,4701,609,4701) = true := by
  simp only [checkFour, w114_0, w114_1, w114_2, w114_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one114 : Coverage 114 115 := checkList_sound (ws:=[(609,4701,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases114)
private theorem w115_0 : checkWitness 115 false false 8886 = true := by decide +kernel
private theorem w115_2 : checkWitness 115 true false 8882 = true := by decide +kernel
private theorem cases115 : checkFour 115 (8886,0,8882,0) = true := by
  simp only [checkFour, w115_0, w115_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one115 : Coverage 115 116 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases115)
private theorem w116_0 : checkWitness 116 false false 52 = true := by decide +kernel
private theorem w116_2 : checkWitness 116 true false 52 = true := by decide +kernel
private theorem cases116 : checkFour 116 (52,0,52,0) = true := by
  simp only [checkFour, w116_0, w116_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one116 : Coverage 116 117 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases116)
private theorem w117_0 : checkWitness 117 false false 574 = true := by decide +kernel
private theorem w117_1 : checkWitness 117 false true 4670 = true := by decide +kernel
private theorem w117_2 : checkWitness 117 true false 574 = true := by decide +kernel
private theorem w117_3 : checkWitness 117 true true 4670 = true := by decide +kernel
private theorem cases117 : checkFour 117 (574,4670,574,4670) = true := by
  simp only [checkFour, w117_0, w117_1, w117_2, w117_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one117 : Coverage 117 118 := checkList_sound (ws:=[(574,4670,574,4670)]) (by simpa only [checkList, Bool.and_true] using cases117)
private theorem w118_0 : checkWitness 118 false false 8917 = true := by decide +kernel
private theorem w118_2 : checkWitness 118 true false 8913 = true := by decide +kernel
private theorem cases118 : checkFour 118 (8917,0,8913,0) = true := by
  simp only [checkFour, w118_0, w118_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one118 : Coverage 118 119 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases118)
private theorem w119_0 : checkWitness 119 false false 8958 = true := by decide +kernel
private theorem w119_2 : checkWitness 119 true false 8949 = true := by decide +kernel
private theorem cases119 : checkFour 119 (8958,0,8949,0) = true := by
  simp only [checkFour, w119_0, w119_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one119 : Coverage 119 120 := checkList_sound (ws:=[(8958,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases119)
private theorem w120_0 : checkWitness 120 false false 58 = true := by decide +kernel
private theorem w120_2 : checkWitness 120 true false 58 = true := by decide +kernel
private theorem cases120 : checkFour 120 (58,0,58,0) = true := by
  simp only [checkFour, w120_0, w120_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one120 : Coverage 120 121 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases120)
private theorem w121_0 : checkWitness 121 false false 662 = true := by decide +kernel
private theorem w121_1 : checkWitness 121 false true 4754 = true := by decide +kernel
private theorem w121_2 : checkWitness 121 true false 653 = true := by decide +kernel
private theorem w121_3 : checkWitness 121 true true 4745 = true := by decide +kernel
private theorem cases121 : checkFour 121 (662,4754,653,4745) = true := by
  simp only [checkFour, w121_0, w121_1, w121_2, w121_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one121 : Coverage 121 122 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases121)
private theorem w122_0 : checkWitness 122 false false 8913 = true := by decide +kernel
private theorem w122_2 : checkWitness 122 true false 8909 = true := by decide +kernel
private theorem cases122 : checkFour 122 (8913,0,8909,0) = true := by
  simp only [checkFour, w122_0, w122_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one122 : Coverage 122 123 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases122)
private theorem w123_0 : checkWitness 123 false false 650 = true := by decide +kernel
private theorem w123_1 : checkWitness 123 false true 4742 = true := by decide +kernel
private theorem w123_2 : checkWitness 123 true false 641 = true := by decide +kernel
private theorem w123_3 : checkWitness 123 true true 4733 = true := by decide +kernel
private theorem cases123 : checkFour 123 (650,4742,641,4733) = true := by
  simp only [checkFour, w123_0, w123_1, w123_2, w123_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one123 : Coverage 123 124 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases123)
private theorem w124_0 : checkWitness 124 false false 8880 = true := by decide +kernel
private theorem w124_2 : checkWitness 124 true false 8876 = true := by decide +kernel
private theorem cases124 : checkFour 124 (8880,0,8876,0) = true := by
  simp only [checkFour, w124_0, w124_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one124 : Coverage 124 125 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases124)
private theorem w125_0 : checkWitness 125 false false 58 = true := by decide +kernel
private theorem w125_2 : checkWitness 125 true false 58 = true := by decide +kernel
private theorem cases125 : checkFour 125 (58,0,58,0) = true := by
  simp only [checkFour, w125_0, w125_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one125 : Coverage 125 126 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases125)
private theorem w126_0 : checkWitness 126 false false 52 = true := by decide +kernel
private theorem w126_2 : checkWitness 126 true false 52 = true := by decide +kernel
private theorem cases126 : checkFour 126 (52,0,52,0) = true := by
  simp only [checkFour, w126_0, w126_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one126 : Coverage 126 127 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases126)
private theorem w127_0 : checkWitness 127 false false 617 = true := by decide +kernel
private theorem w127_1 : checkWitness 127 false true 4701 = true := by decide +kernel
private theorem w127_2 : checkWitness 127 true false 617 = true := by decide +kernel
private theorem w127_3 : checkWitness 127 true true 4701 = true := by decide +kernel
private theorem cases127 : checkFour 127 (617,4701,617,4701) = true := by
  simp only [checkFour, w127_0, w127_1, w127_2, w127_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one127 : Coverage 127 128 := checkList_sound (ws:=[(617,4701,617,4701)]) (by simpa only [checkList, Bool.and_true] using cases127)
theorem cover0096 : Coverage 96 128 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one96 one97) (Coverage.join one98 one99)) (Coverage.join (Coverage.join one100 one101) (Coverage.join one102 one103))) (Coverage.join (Coverage.join (Coverage.join one104 one105) (Coverage.join one106 one107)) (Coverage.join (Coverage.join one108 one109) (Coverage.join one110 one111)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one112 one113) (Coverage.join one114 one115)) (Coverage.join (Coverage.join one116 one117) (Coverage.join one118 one119))) (Coverage.join (Coverage.join (Coverage.join one120 one121) (Coverage.join one122 one123)) (Coverage.join (Coverage.join one124 one125) (Coverage.join one126 one127)))))
end NF185PA.Symbolic
