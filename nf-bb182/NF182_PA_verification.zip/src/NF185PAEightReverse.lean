import NF185PAEightEntry
import NF185PABootPrefix
import NF185PATapeCompiler
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.PhysicalModel PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.Register185 (Reach address registers)
open PA192.ModelSearch.Register185.Commands (vm atS)
open NF185PA.Scanner NF185PA.ScannerSource NF185PA.Sound
namespace NF185PA.Reverse
open Symbolic
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 5000000
set_option maxRecDepth 20000

private noncomputable abbrev tape (t : V) := rawRun Gate.machine Gate.start t

/-- A signed source reachability witness can be spliced onto any tape boundary. -/
theorem splice (cover : Coverage 0 2959) {s c d : V} (start : Boundary s (tape c)) (r : Reach s d) :
    ∃ t : V, c ≤ t ∧ Boundary d (tape t) := by
  obtain ⟨j,rfl⟩ := r
  have walk : ∀ j : V, ∃ t : V, c≤t ∧ Boundary (Register185.run j s) (tape t) := by
    apply modelInduct
    · definability
    · exact ⟨c,le_rfl,by simpa using start⟩
    · rintro j ⟨t,ct,b⟩
      obtain ⟨k,path⟩ := allRows_simulate (checked_row table_safe cover) _ _ b
      exact ⟨t+k,le_trans ct le_self_add,by
        simpa only [Register185.run_succ,Register185.step,tape,rawRun,iterate_add] using path⟩
  exact walk j

private theorem live_at (p : Fin 2959) {s c : V} (pc : address s=(p.val:V)) (h : Boundary s c) :
    ∃ f : Bool, ∃ g k : V, c=packedFrame p.val f (registers s) g k := by
  rcases h with stopped|live
  · have eq : (p.val:V)=((4095:Nat):V) := pc.symm.trans stopped.1
    have bad : p.val=4095 := by exact_mod_cast eq
    omega
  · obtain ⟨q,_,f,_,atq,_,_,g,k,frame⟩ := (anyFrame_iff _ _ _).mp live
    have eq : (q:V)=(p.val:V) := atq.symm.trans pc
    have same : q=p.val := by exact_mod_cast eq
    exact ⟨f,g,k,same ▸ frame⟩

private theorem bit_div (b : Bool) (r : V) : Execute.bit b r / 2 = r := (Execute.halves b r).1
private theorem bit_mod (b : Bool) (r : V) : Execute.bit b r % 2 = (b.toNat : V) := (Execute.halves b r).2

private theorem distinct_boundary {s0 s10 c : V} (h0 : address s0=0) (h10 : address s10=10)
    (a : Boundary s0 c) (b : Boundary s10 c) : False := by
  obtain ⟨f,g,k,x⟩ := live_at (⟨0,by decide⟩ : Fin 2959) (by simpa using h0) a
  obtain ⟨ff,gg,kk,y⟩ := live_at (⟨10,by decide⟩ : Fin 2959) (by simpa using h10) b
  have he := x.symm.trans y
  have b0 : P185.Frame.addressBits 0 = [false,false,false,false,false] := by decide +kernel
  have b10 : P185.Frame.addressBits 10 = [false,false,true,false,false] := by decide +kernel
  have bits := congrArg (fun x : V => (rightRay x / 2 / 2) % 2) he
  simp only [packedFrame,canonical,b0,b10,rayLit,right_pack,bit_div,bit_mod,Bool.toNat_false,Bool.toNat_true,Nat.cast_zero,Nat.cast_one] at bits
  exact zero_ne_one bits

private theorem halted_persists {j t : V} (ht : state (tape j)=185) (le : j≤t) :
    state (tape t)=185 := by
  obtain ⟨d,rfl⟩ := exists_add_of_le le
  have fixed : rawStep Gate.machine (tape j)=tape j := by
    apply pick_none
    intro q _ hq
    have ne : ((185:Nat):V) ≠ (q.val:V) := by exact_mod_cast (Nat.ne_of_lt q.isLt).symm
    exact ne (ht.symm.trans hq)
  rw [tape,rawRun,iterate_add]
  change state (iterate (rawStep Gate.machine) d (tape j))=185
  have stay : iterate (rawStep Gate.machine) d (tape j)=tape j := by
    clear le
    induction d using modelInduct with
    | defP => definability
    | zero => simp
    | step n ih => rw [iterate_succ,ih,fixed]
  simpa only [stay] using ht

private theorem unobserved (no : ¬Pool.Pr (∅ : V) goal) {a : V} (good : goodState (dataState a)) :
    ¬observed a := by
  intro hit
  apply no
  simpa only [Prov,goal_three,←hit.2] using good.2.2

/-- Each live command goes through PC 0 before returning to PC 10. Thus 98
commands suffice to overtake the signed 98-step source prefix, irrespective
of the length chosen by the initial scanner entry proof. -/
theorem after_margin (no : ¬Pool.Pr (∅ : V) goal) :
    ∃ a : V, Reach (Registers.margin V) (view a) ∧ goodState (dataState a) := by
  have late (n : Nat) : ∃ (a t : V), (n:V)≤t ∧ Register185.run t (origin V)=view a ∧ goodState (dataState a) := by
    induction n with
    | zero =>
      obtain ⟨e,⟨t,ht⟩,good⟩ := signed_entry_sound (V:=V)
      exact ⟨fresh 0 0 e,t,by simp,ht,by simpa [fresh,dataState] using good⟩
    | succ n ih =>
      obtain ⟨a,t,le,ht,good⟩ := ih
      have cmd := actualCommand (k:=index a) (raw:=input a) (e:=dataState a) (unobserved no good)
      rw [←view_unpack] at cmd
      obtain ⟨d,hd⟩ := cmd
      have pos : 0<d := lt_of_le_of_ne zero_le (fun ee => by
        rw [←ee,Register185.run_zero] at hd
        have p := congrArg Register185.address hd
        simp [view,vm,atS] at p)
      obtain ⟨r,hr⟩ := actualRefill (index a) (input a) (rawAction (input a) (dataState a))
      refine ⟨next a,t+d+r,?_,?_,goodNext _ good⟩
      · rw [Nat.cast_succ]
        exact le_trans (succ_le_iff_lt.mpr (lt_of_le_of_lt le (lt_add_of_pos_right _ pos))) le_self_add
      · rw [Register185.run_add,Register185.run_add,ht,hd,hr]
        simp only [next,view_fresh,Scanner.control]
  obtain ⟨a,t,le,ht,good⟩ := late 98
  obtain ⟨d,td⟩ := exists_add_of_le le
  refine ⟨a,⟨d,?_⟩,good⟩
  rw [td,Register185.run_add] at ht
  have hprefix : Register185.run ((98:Nat):V) (origin V) = Registers.margin V := by
    rw [Boot.run_eq]
    exact Boot.prefix98
  rwa [hprefix] at ht

/-- In any PA model in which the eight-row pool has no refutation, the scanner
has live tape checkpoints beyond every model clock. -/
theorem halting_implies_pool (cover : Coverage 0 2959) (halt : V ⊧/![] H185) :
    Pool.Pr (∅ : V) goal := by
  by_contra no
  obtain ⟨a,entry,good⟩ := after_margin no
  have never (j : V) : ¬observed (iterate next j a) := fun hit => no (observation_implies_pool a j good hit)
  have cofinal : ∀ j : V, ∃ c : V, j≤c ∧ Boundary (view (iterate next j a)) (tape c) := by
    apply modelInduct
    · definability
    · obtain ⟨c,_,b⟩ := splice cover boot_boundary entry
      exact ⟨c,zero_le,by simpa using b⟩
    · rintro j ⟨c,jc,here⟩
      let x := iterate next j a
      let k := index x
      let raw := input x
      let e := dataState x
      let z := rawAction raw e
      have first := actualCommand (k:=k) (raw:=raw) (e:=e) (never j)
      have bstart : Boundary (vm 10 0 k e raw) (tape c) := by
        simpa only [view_unpack,k,raw,e,x] using here
      obtain ⟨c0,c_le,middle⟩ := splice cover bstart first
      obtain ⟨c1,m_le,arrive⟩ := splice cover middle (actualRefill k raw z)
      have pc0 : address (vm 0 0 k z (Enumeration.tail raw))=0 := by simp [vm,atS]
      have pc10 : address (view x)=10 := by simp [view]
      have lt : c<c0 := lt_of_le_of_ne c_le (fun eq => by
        rw [←eq] at middle
        exact distinct_boundary pc0 pc10 middle here)
      refine ⟨c1,le_trans (succ_le_iff_lt.mpr (lt_of_le_of_lt jc lt)) m_le,?_⟩
      rw [iterate_succ]
      simpa only [next,view_fresh,Scanner.control,k,raw,e,z,x] using arrive
  obtain ⟨t,ht⟩ := H185_eval.mp halt
  obtain ⟨c,tc,b⟩ := cofinal t
  obtain ⟨f,g,k,frame⟩ := live_at (⟨10,by decide⟩ : Fin 2959) (by simp [view]) b
  have stopped := halted_persists ht tc
  rw [frame] at stopped
  norm_num [packedFrame,canonical] at stopped

end NF185PA.Reverse
#print axioms NF185PA.Reverse.halting_implies_pool
