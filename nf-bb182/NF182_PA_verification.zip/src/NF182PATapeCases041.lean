import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1312_0 : checkWitness 1312 false false 8902 = true := by decide +kernel
private theorem w1312_2 : checkWitness 1312 true false 8893 = true := by decide +kernel
private theorem cases1312 : checkFour 1312 (8902,0,8893,0) = true := by
  simp only [checkFour, w1312_0, w1312_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1312 : Coverage 1312 1313 := checkList_sound (ws:=[(8902,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases1312)
private theorem w1313_0 : checkWitness 1313 false false 104 = true := by decide +kernel
private theorem w1313_2 : checkWitness 1313 true false 104 = true := by decide +kernel
private theorem cases1313 : checkFour 1313 (104,0,104,0) = true := by
  simp only [checkFour, w1313_0, w1313_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1313 : Coverage 1313 1314 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases1313)
private theorem w1314_0 : checkWitness 1314 false false 614 = true := by decide +kernel
private theorem w1314_1 : checkWitness 1314 false true 4706 = true := by decide +kernel
private theorem w1314_2 : checkWitness 1314 true false 605 = true := by decide +kernel
private theorem w1314_3 : checkWitness 1314 true true 4697 = true := by decide +kernel
private theorem cases1314 : checkFour 1314 (614,4706,605,4697) = true := by
  simp only [checkFour, w1314_0, w1314_1, w1314_2, w1314_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1314 : Coverage 1314 1315 := checkList_sound (ws:=[(614,4706,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases1314)
private theorem w1315_0 : checkWitness 1315 false false 8863 = true := by decide +kernel
private theorem w1315_2 : checkWitness 1315 true false 8859 = true := by decide +kernel
private theorem cases1315 : checkFour 1315 (8863,0,8859,0) = true := by
  simp only [checkFour, w1315_0, w1315_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1315 : Coverage 1315 1316 := checkList_sound (ws:=[(8863,0,8859,0)]) (by simpa only [checkList, Bool.and_true] using cases1315)
private theorem w1316_0 : checkWitness 1316 false false 608 = true := by decide +kernel
private theorem w1316_1 : checkWitness 1316 false true 4700 = true := by decide +kernel
private theorem w1316_2 : checkWitness 1316 true false 599 = true := by decide +kernel
private theorem w1316_3 : checkWitness 1316 true true 4691 = true := by decide +kernel
private theorem cases1316 : checkFour 1316 (608,4700,599,4691) = true := by
  simp only [checkFour, w1316_0, w1316_1, w1316_2, w1316_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1316 : Coverage 1316 1317 := checkList_sound (ws:=[(608,4700,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases1316)
private theorem w1317_0 : checkWitness 1317 false false 8832 = true := by decide +kernel
private theorem w1317_2 : checkWitness 1317 true false 8828 = true := by decide +kernel
private theorem cases1317 : checkFour 1317 (8832,0,8828,0) = true := by
  simp only [checkFour, w1317_0, w1317_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1317 : Coverage 1317 1318 := checkList_sound (ws:=[(8832,0,8828,0)]) (by simpa only [checkList, Bool.and_true] using cases1317)
private theorem w1318_0 : checkWitness 1318 false false 92 = true := by decide +kernel
private theorem w1318_2 : checkWitness 1318 true false 92 = true := by decide +kernel
private theorem cases1318 : checkFour 1318 (92,0,92,0) = true := by
  simp only [checkFour, w1318_0, w1318_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1318 : Coverage 1318 1319 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1318)
private theorem w1319_0 : checkWitness 1319 false false 84 = true := by decide +kernel
private theorem w1319_2 : checkWitness 1319 true false 84 = true := by decide +kernel
private theorem cases1319 : checkFour 1319 (84,0,84,0) = true := by
  simp only [checkFour, w1319_0, w1319_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1319 : Coverage 1319 1320 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1319)
private theorem w1320_0 : checkWitness 1320 false false 573 = true := by decide +kernel
private theorem w1320_1 : checkWitness 1320 false true 4657 = true := by decide +kernel
private theorem w1320_2 : checkWitness 1320 true false 573 = true := by decide +kernel
private theorem w1320_3 : checkWitness 1320 true true 4657 = true := by decide +kernel
private theorem cases1320 : checkFour 1320 (573,4657,573,4657) = true := by
  simp only [checkFour, w1320_0, w1320_1, w1320_2, w1320_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1320 : Coverage 1320 1321 := checkList_sound (ws:=[(573,4657,573,4657)]) (by simpa only [checkList, Bool.and_true] using cases1320)
private theorem w1321_0 : checkWitness 1321 false false 8826 = true := by decide +kernel
private theorem w1321_2 : checkWitness 1321 true false 8822 = true := by decide +kernel
private theorem cases1321 : checkFour 1321 (8826,0,8822,0) = true := by
  simp only [checkFour, w1321_0, w1321_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1321 : Coverage 1321 1322 := checkList_sound (ws:=[(8826,0,8822,0)]) (by simpa only [checkList, Bool.and_true] using cases1321)
private theorem w1322_0 : checkWitness 1322 false false 84 = true := by decide +kernel
private theorem w1322_2 : checkWitness 1322 true false 84 = true := by decide +kernel
private theorem cases1322 : checkFour 1322 (84,0,84,0) = true := by
  simp only [checkFour, w1322_0, w1322_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1322 : Coverage 1322 1323 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1322)
private theorem w1323_0 : checkWitness 1323 false false 578 = true := by decide +kernel
private theorem w1323_1 : checkWitness 1323 false true 4674 = true := by decide +kernel
private theorem w1323_2 : checkWitness 1323 true false 578 = true := by decide +kernel
private theorem w1323_3 : checkWitness 1323 true true 4674 = true := by decide +kernel
private theorem cases1323 : checkFour 1323 (578,4674,578,4674) = true := by
  simp only [checkFour, w1323_0, w1323_1, w1323_2, w1323_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1323 : Coverage 1323 1324 := checkList_sound (ws:=[(578,4674,578,4674)]) (by simpa only [checkList, Bool.and_true] using cases1323)
private theorem w1324_0 : checkWitness 1324 false false 8894 = true := by decide +kernel
private theorem w1324_2 : checkWitness 1324 true false 8885 = true := by decide +kernel
private theorem cases1324 : checkFour 1324 (8894,0,8885,0) = true := by
  simp only [checkFour, w1324_0, w1324_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1324 : Coverage 1324 1325 := checkList_sound (ws:=[(8894,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1324)
private theorem w1325_0 : checkWitness 1325 false false 8840 = true := by decide +kernel
private theorem w1325_2 : checkWitness 1325 true false 8836 = true := by decide +kernel
private theorem cases1325 : checkFour 1325 (8840,0,8836,0) = true := by
  simp only [checkFour, w1325_0, w1325_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1325 : Coverage 1325 1326 := checkList_sound (ws:=[(8840,0,8836,0)]) (by simpa only [checkList, Bool.and_true] using cases1325)
private theorem w1326_0 : checkWitness 1326 false false 92 = true := by decide +kernel
private theorem w1326_2 : checkWitness 1326 true false 92 = true := by decide +kernel
private theorem cases1326 : checkFour 1326 (92,0,92,0) = true := by
  simp only [checkFour, w1326_0, w1326_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1326 : Coverage 1326 1327 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1326)
private theorem w1327_0 : checkWitness 1327 false false 624 = true := by decide +kernel
private theorem w1327_1 : checkWitness 1327 false true 4712 = true := by decide +kernel
private theorem w1327_2 : checkWitness 1327 true false 615 = true := by decide +kernel
private theorem w1327_3 : checkWitness 1327 true true 4703 = true := by decide +kernel
private theorem cases1327 : checkFour 1327 (624,4712,615,4703) = true := by
  simp only [checkFour, w1327_0, w1327_1, w1327_2, w1327_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1327 : Coverage 1327 1328 := checkList_sound (ws:=[(624,4712,615,4703)]) (by simpa only [checkList, Bool.and_true] using cases1327)
private theorem w1328_0 : checkWitness 1328 false false 8882 = true := by decide +kernel
private theorem w1328_2 : checkWitness 1328 true false 8878 = true := by decide +kernel
private theorem cases1328 : checkFour 1328 (8882,0,8878,0) = true := by
  simp only [checkFour, w1328_0, w1328_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1328 : Coverage 1328 1329 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases1328)
private theorem w1329_0 : checkWitness 1329 false false 82 = true := by decide +kernel
private theorem w1329_2 : checkWitness 1329 true false 82 = true := by decide +kernel
private theorem cases1329 : checkFour 1329 (82,0,82,0) = true := by
  simp only [checkFour, w1329_0, w1329_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1329 : Coverage 1329 1330 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1329)
private theorem w1330_0 : checkWitness 1330 false false 482 = true := by decide +kernel
private theorem w1330_1 : checkWitness 1330 false true 4578 = true := by decide +kernel
private theorem w1330_2 : checkWitness 1330 true false 482 = true := by decide +kernel
private theorem w1330_3 : checkWitness 1330 true true 4578 = true := by decide +kernel
private theorem cases1330 : checkFour 1330 (482,4578,482,4578) = true := by
  simp only [checkFour, w1330_0, w1330_1, w1330_2, w1330_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1330 : Coverage 1330 1331 := checkList_sound (ws:=[(482,4578,482,4578)]) (by simpa only [checkList, Bool.and_true] using cases1330)
private theorem w1331_0 : checkWitness 1331 false false 8922 = true := by decide +kernel
private theorem w1331_2 : checkWitness 1331 true false 8913 = true := by decide +kernel
private theorem cases1331 : checkFour 1331 (8922,0,8913,0) = true := by
  simp only [checkFour, w1331_0, w1331_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1331 : Coverage 1331 1332 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases1331)
private theorem w1332_0 : checkWitness 1332 false false 90 = true := by decide +kernel
private theorem w1332_2 : checkWitness 1332 true false 90 = true := by decide +kernel
private theorem cases1332 : checkFour 1332 (90,0,90,0) = true := by
  simp only [checkFour, w1332_0, w1332_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1332 : Coverage 1332 1333 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1332)
private theorem w1333_0 : checkWitness 1333 false false 504 = true := by decide +kernel
private theorem w1333_1 : checkWitness 1333 false true 4600 = true := by decide +kernel
private theorem w1333_2 : checkWitness 1333 true false 504 = true := by decide +kernel
private theorem w1333_3 : checkWitness 1333 true true 4600 = true := by decide +kernel
private theorem cases1333 : checkFour 1333 (504,4600,504,4600) = true := by
  simp only [checkFour, w1333_0, w1333_1, w1333_2, w1333_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1333 : Coverage 1333 1334 := checkList_sound (ws:=[(504,4600,504,4600)]) (by simpa only [checkList, Bool.and_true] using cases1333)
private theorem w1334_0 : checkWitness 1334 false false 8862 = true := by decide +kernel
private theorem w1334_2 : checkWitness 1334 true false 8858 = true := by decide +kernel
private theorem cases1334 : checkFour 1334 (8862,0,8858,0) = true := by
  simp only [checkFour, w1334_0, w1334_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1334 : Coverage 1334 1335 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases1334)
private theorem w1335_0 : checkWitness 1335 false false 92 = true := by decide +kernel
private theorem w1335_2 : checkWitness 1335 true false 92 = true := by decide +kernel
private theorem cases1335 : checkFour 1335 (92,0,92,0) = true := by
  simp only [checkFour, w1335_0, w1335_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1335 : Coverage 1335 1336 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1335)
private theorem w1336_0 : checkWitness 1336 false false 548 = true := by decide +kernel
private theorem w1336_1 : checkWitness 1336 false true 4644 = true := by decide +kernel
private theorem w1336_2 : checkWitness 1336 true false 548 = true := by decide +kernel
private theorem w1336_3 : checkWitness 1336 true true 4644 = true := by decide +kernel
private theorem cases1336 : checkFour 1336 (548,4644,548,4644) = true := by
  simp only [checkFour, w1336_0, w1336_1, w1336_2, w1336_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1336 : Coverage 1336 1337 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases1336)
private theorem w1337_0 : checkWitness 1337 false false 8883 = true := by decide +kernel
private theorem w1337_2 : checkWitness 1337 true false 8879 = true := by decide +kernel
private theorem cases1337 : checkFour 1337 (8883,0,8879,0) = true := by
  simp only [checkFour, w1337_0, w1337_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1337 : Coverage 1337 1338 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1337)
private theorem w1338_0 : checkWitness 1338 false false 8918 = true := by decide +kernel
private theorem w1338_2 : checkWitness 1338 true false 8909 = true := by decide +kernel
private theorem cases1338 : checkFour 1338 (8918,0,8909,0) = true := by
  simp only [checkFour, w1338_0, w1338_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1338 : Coverage 1338 1339 := checkList_sound (ws:=[(8918,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases1338)
private theorem w1339_0 : checkWitness 1339 false false 116 = true := by decide +kernel
private theorem w1339_2 : checkWitness 1339 true false 116 = true := by decide +kernel
private theorem cases1339 : checkFour 1339 (116,0,116,0) = true := by
  simp only [checkFour, w1339_0, w1339_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1339 : Coverage 1339 1340 := checkList_sound (ws:=[(116,0,116,0)]) (by simpa only [checkList, Bool.and_true] using cases1339)
private theorem w1340_0 : checkWitness 1340 false false 630 = true := by decide +kernel
private theorem w1340_1 : checkWitness 1340 false true 4722 = true := by decide +kernel
private theorem w1340_2 : checkWitness 1340 true false 621 = true := by decide +kernel
private theorem w1340_3 : checkWitness 1340 true true 4713 = true := by decide +kernel
private theorem cases1340 : checkFour 1340 (630,4722,621,4713) = true := by
  simp only [checkFour, w1340_0, w1340_1, w1340_2, w1340_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1340 : Coverage 1340 1341 := checkList_sound (ws:=[(630,4722,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases1340)
private theorem w1341_0 : checkWitness 1341 false false 8879 = true := by decide +kernel
private theorem w1341_2 : checkWitness 1341 true false 8875 = true := by decide +kernel
private theorem cases1341 : checkFour 1341 (8879,0,8875,0) = true := by
  simp only [checkFour, w1341_0, w1341_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1341 : Coverage 1341 1342 := checkList_sound (ws:=[(8879,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases1341)
private theorem w1342_0 : checkWitness 1342 false false 624 = true := by decide +kernel
private theorem w1342_1 : checkWitness 1342 false true 4716 = true := by decide +kernel
private theorem w1342_2 : checkWitness 1342 true false 615 = true := by decide +kernel
private theorem w1342_3 : checkWitness 1342 true true 4707 = true := by decide +kernel
private theorem cases1342 : checkFour 1342 (624,4716,615,4707) = true := by
  simp only [checkFour, w1342_0, w1342_1, w1342_2, w1342_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1342 : Coverage 1342 1343 := checkList_sound (ws:=[(624,4716,615,4707)]) (by simpa only [checkList, Bool.and_true] using cases1342)
private theorem w1343_0 : checkWitness 1343 false false 8849 = true := by decide +kernel
private theorem w1343_2 : checkWitness 1343 true false 8845 = true := by decide +kernel
private theorem cases1343 : checkFour 1343 (8849,0,8845,0) = true := by
  simp only [checkFour, w1343_0, w1343_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1343 : Coverage 1343 1344 := checkList_sound (ws:=[(8849,0,8845,0)]) (by simpa only [checkList, Bool.and_true] using cases1343)
theorem cover1312 : Coverage 1312 1344 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1312 one1313) (Coverage.join one1314 one1315)) (Coverage.join (Coverage.join one1316 one1317) (Coverage.join one1318 one1319))) (Coverage.join (Coverage.join (Coverage.join one1320 one1321) (Coverage.join one1322 one1323)) (Coverage.join (Coverage.join one1324 one1325) (Coverage.join one1326 one1327)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1328 one1329) (Coverage.join one1330 one1331)) (Coverage.join (Coverage.join one1332 one1333) (Coverage.join one1334 one1335))) (Coverage.join (Coverage.join (Coverage.join one1336 one1337) (Coverage.join one1338 one1339)) (Coverage.join (Coverage.join one1340 one1341) (Coverage.join one1342 one1343)))))
end NF182PA.Symbolic
