module
public import SyntaxMaps
public import NativeAxiomTruth

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding FFL.FirstOrder.Arithmetic.Bootstrapping

namespace PA192.SyntaxTruth
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

instance plainNeg : Language.DefinableFunction₁ ℒₒᵣ (neg ℒₒᵣ : V→V) :=
  FFL.FirstOrder.Defined.to_definable (φ:=(negGraph ℒₒᵣ).val) ⟨(neg.defined (L:=ℒₒᵣ) (V:=V)).df⟩

namespace Semantics
variable (S : Semantics V)

theorem neg_eval {p n b f : V} (hp : IsSemiformula ℒₒᵣ n p) (hb : S.D b) (hf : S.D f) :
    S.tr (neg ℒₒᵣ p) b f ↔ ¬S.tr p b f := by
  classical
  let P := fun p => ∀ n b f, IsSemiformula ℒₒᵣ n p → S.D b → S.D f →
    (S.tr (neg ℒₒᵣ p) b f ↔ ¬S.tr p b f)
  apply strongInd P (by dsimp [P]; definability) _ p n b f hp hb hf
  intro p ih n b f hp hb hf
  rcases IsSemiformula.case_iff.mp hp with ⟨k,h,v,legal,hv,rfl⟩|⟨k,h,v,legal,hv,rfl⟩|rfl|rfl|
    ⟨u,v,hu,hv,rfl⟩|⟨u,v,hu,hv,rfl⟩|⟨u,hu,rfl⟩|⟨u,hu,rfl⟩
  · rw [neg_rel legal hv.isUTerm,S.nrel legal hv.lh hb hf]
  · rw [neg_nrel legal hv.isUTerm,S.nrel legal hv.lh hb hf]; simp
  · rw [neg_verum]; exact iff_of_false (S.bot hb hf) (fun h => h (S.top hb hf))
  · rw [neg_falsum]; exact iff_of_true (S.top hb hf) (S.bot hb hf)
  · rw [neg_and hu.isUFormula hv.isUFormula,S.or _ _ hb hf,S.and _ _ hb hf,
      ih u (by simp) n b f hu hb hf,ih v (by simp) n b f hv hb hf]; tauto
  · rw [neg_or hu.isUFormula hv.isUFormula,S.and _ _ hb hf,S.or _ _ hb hf,
      ih u (by simp) n b f hu hb hf,ih v (by simp) n b f hv hb hf]; tauto
  · rw [neg_all hu.isUFormula,S.exs _ hb hf,S.all _ hb hf]
    constructor
    · rintro ⟨x,hx,negx⟩ allx
      exact (ih u (by simp) _ _ _ hu (S.pushOK hx hb) hf).mp negx (allx x hx)
    · intro no
      by_contra none
      apply no
      intro x hx
      by_contra bad
      exact none ⟨x,hx,(ih u (by simp) _ _ _ hu (S.pushOK hx hb) hf).mpr bad⟩
  · rw [neg_ex hu.isUFormula,S.all _ hb hf,S.exs _ hb hf]
    simp only [not_exists,not_and]
    apply forall_congr'; intro x
    exact forall_congr' (fun hx => ih u (by simp) _ _ _ hu (S.pushOK hx hb) hf)

theorem imp_eval {n p : V} (hp : IsSemiformula ℒₒᵣ n p) (q : V) {b f : V} (hb : S.D b) (hf : S.D f) :
    S.tr (imp ℒₒᵣ p q) b f ↔ (S.tr p b f → S.tr q b f) := by
  classical
  rw [imp,S.or _ _ hb hf,S.neg_eval hp hb hf]
  tauto

/-- A single term may itself depend on the current bound stack. The new bound
assignment adds its evaluated value, and the old body has at most one bound
variable. -/
theorem single_eval {p m t b f : V} (hp : IsSemiformula ℒₒᵣ 1 p) (ht : IsSemiterm ℒₒᵣ m t)
    (hb : S.D b) (hf : S.D f) :
    S.tr (substs1 ℒₒᵣ t p) b f ↔ S.tr p (S.push (S.ev t b f) b) f := by
  have dx := S.evOK ht hb hf
  apply S.subst_eval hp hb hf (S.pushOK dx hb) hf (IsSemitermVec.singleton.mpr ht).isUTerm _ (fun _=>rfl)
  intro i hi
  have iz : i=0 := by simpa using hi
  subst i
  simp only [nth_adjoin_zero,S.getZero dx hb]

theorem free_eval {p f x : V} (hp : IsSemiformula ℒₒᵣ 1 p) (hf : S.D f) (hx : S.D x) :
    S.tr (free ℒₒᵣ p) S.base (S.push x f) ↔ S.tr p (S.push x S.base) f := by
  have hpush := S.pushOK hx hf
  have ev : S.ev (qqFvar 0) S.base (S.push x f)=x := by rw [S.fvar _ S.baseOK hpush,S.getZero hx hf]
  unfold free
  rw [S.single_eval hp.shift (m:=0) (t:=qqFvar 0) (by simp) S.baseOK hpush,ev]
  exact S.shift_eval hp (S.pushOK hx S.baseOK) hpush (S.pushOK hx S.baseOK) hf
    (fun _ _=>rfl) (fun i=>S.getSucc i hx hf)

noncomputable def nativeTruth (ax : ∀ {f p : V}, S.D f → p∈𝗣𝗔.Δ₁Class → S.tr p S.base f) :
    PA192.NativeTruth.Truth 𝗣𝗔 V where
  OK := S.D
  dom := S.D
  tr f p := S.tr p S.base f
  push := S.push
  drop := S.drop
  defOK := S.dD
  defTr := by change Language.DefinableRel ℒₒᵣ (fun f p => S.tr p S.base f); definability
  inhabited := ⟨S.base,S.baseOK⟩
  pushOK := S.pushOK
  dropOK := S.dropOK
  top hf := S.top S.baseOK hf
  bot hf := S.bot S.baseOK hf
  neg hf hp := S.neg_eval hp S.baseOK hf
  conj hf _ hx hy := (S.and _ _ S.baseOK hf).mpr ⟨hx,hy⟩
  disj hf _ h := (S.or _ _ S.baseOK hf).mpr h
  all hf hp h := (S.all _ S.baseOK hf).mpr (fun x hx => (S.free_eval (by simpa using hp) hf hx).mp (h x hx))
  exs hf hp ht h := (S.exs _ S.baseOK hf).mpr ⟨_,S.evOK ht S.baseOK hf,
    (S.single_eval (by simpa using hp) ht S.baseOK hf).mp h⟩
  shiftPush hf hx hp h := (S.shift_eval hp S.baseOK (S.pushOK hx hf) S.baseOK hf
    (fun _ _=>rfl) (fun i=>S.getSucc i hx hf)).mp h
  shiftDrop hf hp h := (S.shift_eval hp S.baseOK hf S.baseOK (S.dropOK hf)
    (fun _ _=>rfl) (fun i=>(S.dropGet i hf).symm)).mpr h
  axiomTrue := ax

end Semantics
end PA192.SyntaxTruth
#print axioms PA192.SyntaxTruth.Semantics.nativeTruth
