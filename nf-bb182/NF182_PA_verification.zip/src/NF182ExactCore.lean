import NF182PAPoolNat
import NF182PAEightReverse
import NF182PARegisterHalting
import Moving186NF
namespace NFMachine182
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic NF210 NF182PA PA192.Literal
open scoped FFL.FirstOrder.Arithmetic

/-- Both implications use the same literal 364-row table. -/
theorem halts_iff_nf_refutation_of_coverage (cover : Symbolic.Coverage 0 2971) : TM.Halts Reduced182.Table.machine Reduced182.Table.start ↔ (𝗡𝗙 ⊢ ⊥) := by
  rw [←H182_standard,←Moving186.deriv_goal_iff_nf_refutation]
  have code : (goal : Nat) = NF192.Numerical.goal := goal_three.trans NF192.Numerical.goal_is_three.symm
  rw [←code]
  constructor
  · intro h
    exact Pool.derivation_of_pool (Reverse.halting_implies_pool cover h)
  · intro h
    exact Symbolic.tape_of_coverage cover
      (refutation_reaches_register_halt (Pool.pool_of_derivation h))
end NFMachine182
#print axioms NFMachine182.halts_iff_nf_refutation_of_coverage
