import CodedSections
import CodedAgreement
import ConcreteOps
import BaseGraphInterface
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding FFL.FirstOrder.Arithmetic.Bootstrapping
open NF192.Direct NF192.Direct.Baseline
namespace NF192.Internal
variable {V X : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] {m : X→X→Prop}
/-- A represented numerical domain and the one fixed package rule out even
nonstandard ambient FFL proofs of contradiction from full PA. -/
theorem truthOfPresentation (d : Presentation V X m)
    (h : ∃D z S A B P,CoreAt m D z S A B P ∧ ClosureAt m D z S A B P ∧ ExtraAt m D z S A P ∧
      peanoMinusBody.truth m (params D z S A B P)) : Nonempty (PA192.NativeTruth.Truth 𝗣𝗔 V) := by
  obtain ⟨D,z,S,A,B,P,core,cl,aux,base⟩ := h
  obtain ⟨n,L,q,ind⟩ := extractOps core
  obtain ⟨o,defO,C⟩ := concreteOps d D z S A B P cl aux
  letI := defO
  let c := codingOf L C
  letI := numORing n
  have modl : (Dom m D)↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻ := (body_of_ops L).mp base
  let G := c.agreement (by rfl) (by rfl) (fun _ _=>rfl) (fun _ _=>rfl) (fun _ _=>Iff.rfl)
  exact ⟨G.nativeTruth modl (inductionSets L C cl q ind)⟩

theorem bridgeSemantics (d : Presentation V X m)
    (h : ∃D z S A B P,CoreAt m D z S A B P ∧ ClosureAt m D z S A B P ∧ ExtraAt m D z S A P ∧
      peanoMinusBody.truth m (params D z S A B P)) : ¬Provable 𝗣𝗔 (qqFalsum : V) :=
  fun hp => (truthOfPresentation d h).elim fun tr => tr.no_refutation hp
#print axioms truthOfPresentation
#print axioms bridgeSemantics
end NF192.Internal
