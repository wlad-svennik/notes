import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w160_0 : checkWitness 160 false false 68 = true := by decide +kernel
private theorem w160_2 : checkWitness 160 true false 68 = true := by decide +kernel
private theorem cases160 : checkFour 160 (68,0,68,0) = true := by
  simp only [checkFour, w160_0, w160_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one160 : Coverage 160 161 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases160)
private theorem w161_0 : checkWitness 161 false false 615 = true := by decide +kernel
private theorem w161_1 : checkWitness 161 false true 4699 = true := by decide +kernel
private theorem w161_2 : checkWitness 161 true false 615 = true := by decide +kernel
private theorem w161_3 : checkWitness 161 true true 4699 = true := by decide +kernel
private theorem cases161 : checkFour 161 (615,4699,615,4699) = true := by
  simp only [checkFour, w161_0, w161_1, w161_2, w161_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one161 : Coverage 161 162 := checkList_sound (ws:=[(615,4699,615,4699)]) (by simpa only [checkList, Bool.and_true] using cases161)
private theorem w162_0 : checkWitness 162 false false 8868 = true := by decide +kernel
private theorem w162_2 : checkWitness 162 true false 8864 = true := by decide +kernel
private theorem cases162 : checkFour 162 (8868,0,8864,0) = true := by
  simp only [checkFour, w162_0, w162_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one162 : Coverage 162 163 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases162)
private theorem w163_0 : checkWitness 163 false false 68 = true := by decide +kernel
private theorem w163_2 : checkWitness 163 true false 68 = true := by decide +kernel
private theorem cases163 : checkFour 163 (68,0,68,0) = true := by
  simp only [checkFour, w163_0, w163_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one163 : Coverage 163 164 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases163)
private theorem w164_0 : checkWitness 164 false false 583 = true := by decide +kernel
private theorem w164_1 : checkWitness 164 false true 4679 = true := by decide +kernel
private theorem w164_2 : checkWitness 164 true false 583 = true := by decide +kernel
private theorem w164_3 : checkWitness 164 true true 4679 = true := by decide +kernel
private theorem cases164 : checkFour 164 (583,4679,583,4679) = true := by
  simp only [checkFour, w164_0, w164_1, w164_2, w164_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one164 : Coverage 164 165 := checkList_sound (ws:=[(583,4679,583,4679)]) (by simpa only [checkList, Bool.and_true] using cases164)
private theorem w165_0 : checkWitness 165 false false 8936 = true := by decide +kernel
private theorem w165_2 : checkWitness 165 true false 8927 = true := by decide +kernel
private theorem cases165 : checkFour 165 (8936,0,8927,0) = true := by
  simp only [checkFour, w165_0, w165_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one165 : Coverage 165 166 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases165)
private theorem w166_0 : checkWitness 166 false false 8882 = true := by decide +kernel
private theorem w166_2 : checkWitness 166 true false 8878 = true := by decide +kernel
private theorem cases166 : checkFour 166 (8882,0,8878,0) = true := by
  simp only [checkFour, w166_0, w166_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one166 : Coverage 166 167 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases166)
private theorem w167_0 : checkWitness 167 false false 76 = true := by decide +kernel
private theorem w167_2 : checkWitness 167 true false 76 = true := by decide +kernel
private theorem cases167 : checkFour 167 (76,0,76,0) = true := by
  simp only [checkFour, w167_0, w167_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one167 : Coverage 167 168 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases167)
private theorem w168_0 : checkWitness 168 false false 666 = true := by decide +kernel
private theorem w168_1 : checkWitness 168 false true 4754 = true := by decide +kernel
private theorem w168_2 : checkWitness 168 true false 657 = true := by decide +kernel
private theorem w168_3 : checkWitness 168 true true 4745 = true := by decide +kernel
private theorem cases168 : checkFour 168 (666,4754,657,4745) = true := by
  simp only [checkFour, w168_0, w168_1, w168_2, w168_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one168 : Coverage 168 169 := checkList_sound (ws:=[(666,4754,657,4745)]) (by simpa only [checkList, Bool.and_true] using cases168)
private theorem w169_0 : checkWitness 169 false false 8901 = true := by decide +kernel
private theorem w169_2 : checkWitness 169 true false 8897 = true := by decide +kernel
private theorem cases169 : checkFour 169 (8901,0,8897,0) = true := by
  simp only [checkFour, w169_0, w169_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one169 : Coverage 169 170 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases169)
private theorem w170_0 : checkWitness 170 false false 66 = true := by decide +kernel
private theorem w170_2 : checkWitness 170 true false 66 = true := by decide +kernel
private theorem cases170 : checkFour 170 (66,0,66,0) = true := by
  simp only [checkFour, w170_0, w170_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one170 : Coverage 170 171 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases170)
private theorem w171_0 : checkWitness 171 false false 516 = true := by decide +kernel
private theorem w171_1 : checkWitness 171 false true 4612 = true := by decide +kernel
private theorem w171_2 : checkWitness 171 true false 516 = true := by decide +kernel
private theorem w171_3 : checkWitness 171 true true 4612 = true := by decide +kernel
private theorem cases171 : checkFour 171 (516,4612,516,4612) = true := by
  simp only [checkFour, w171_0, w171_1, w171_2, w171_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one171 : Coverage 171 172 := checkList_sound (ws:=[(516,4612,516,4612)]) (by simpa only [checkList, Bool.and_true] using cases171)
private theorem w172_0 : checkWitness 172 false false 8911 = true := by decide +kernel
private theorem w172_2 : checkWitness 172 true false 8907 = true := by decide +kernel
private theorem cases172 : checkFour 172 (8911,0,8907,0) = true := by
  simp only [checkFour, w172_0, w172_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one172 : Coverage 172 173 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases172)
private theorem w173_0 : checkWitness 173 false false 642 = true := by decide +kernel
private theorem w173_1 : checkWitness 173 false true 4738 = true := by decide +kernel
private theorem w173_2 : checkWitness 173 true false 633 = true := by decide +kernel
private theorem w173_3 : checkWitness 173 true true 4729 = true := by decide +kernel
private theorem cases173 : checkFour 173 (642,4738,633,4729) = true := by
  simp only [checkFour, w173_0, w173_1, w173_2, w173_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one173 : Coverage 173 174 := checkList_sound (ws:=[(642,4738,633,4729)]) (by simpa only [checkList, Bool.and_true] using cases173)
private theorem w174_0 : checkWitness 174 false false 188 = true := by decide +kernel
private theorem w174_2 : checkWitness 174 true false 188 = true := by decide +kernel
private theorem cases174 : checkFour 174 (188,0,188,0) = true := by
  simp only [checkFour, w174_0, w174_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one174 : Coverage 174 175 := checkList_sound (ws:=[(188,0,188,0)]) (by simpa only [checkList, Bool.and_true] using cases174)
private theorem w175_0 : checkWitness 175 false false 597 = true := by decide +kernel
private theorem w175_1 : checkWitness 175 false true 4685 = true := by decide +kernel
private theorem w175_2 : checkWitness 175 true false 597 = true := by decide +kernel
private theorem w175_3 : checkWitness 175 true true 4685 = true := by decide +kernel
private theorem cases175 : checkFour 175 (597,4685,597,4685) = true := by
  simp only [checkFour, w175_0, w175_1, w175_2, w175_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one175 : Coverage 175 176 := checkList_sound (ws:=[(597,4685,597,4685)]) (by simpa only [checkList, Bool.and_true] using cases175)
private theorem w176_0 : checkWitness 176 false false 8926 = true := by decide +kernel
private theorem w176_2 : checkWitness 176 true false 8917 = true := by decide +kernel
private theorem cases176 : checkFour 176 (8926,0,8917,0) = true := by
  simp only [checkFour, w176_0, w176_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one176 : Coverage 176 177 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases176)
private theorem w177_0 : checkWitness 177 false false 68 = true := by decide +kernel
private theorem w177_2 : checkWitness 177 true false 68 = true := by decide +kernel
private theorem cases177 : checkFour 177 (68,0,68,0) = true := by
  simp only [checkFour, w177_0, w177_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one177 : Coverage 177 178 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases177)
private theorem w178_0 : checkWitness 178 false false 60 = true := by decide +kernel
private theorem w178_2 : checkWitness 178 true false 60 = true := by decide +kernel
private theorem cases178 : checkFour 178 (60,0,60,0) = true := by
  simp only [checkFour, w178_0, w178_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one178 : Coverage 178 179 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases178)
private theorem w179_0 : checkWitness 179 false false 603 = true := by decide +kernel
private theorem w179_1 : checkWitness 179 false true 4695 = true := by decide +kernel
private theorem w179_2 : checkWitness 179 true false 603 = true := by decide +kernel
private theorem w179_3 : checkWitness 179 true true 4695 = true := by decide +kernel
private theorem cases179 : checkFour 179 (603,4695,603,4695) = true := by
  simp only [checkFour, w179_0, w179_1, w179_2, w179_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one179 : Coverage 179 180 := checkList_sound (ws:=[(603,4695,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases179)
private theorem w180_0 : checkWitness 180 false false 8864 = true := by decide +kernel
private theorem w180_2 : checkWitness 180 true false 8860 = true := by decide +kernel
private theorem cases180 : checkFour 180 (8864,0,8860,0) = true := by
  simp only [checkFour, w180_0, w180_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one180 : Coverage 180 181 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases180)
private theorem w181_0 : checkWitness 181 false false 60 = true := by decide +kernel
private theorem w181_2 : checkWitness 181 true false 60 = true := by decide +kernel
private theorem cases181 : checkFour 181 (60,0,60,0) = true := by
  simp only [checkFour, w181_0, w181_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one181 : Coverage 181 182 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases181)
private theorem w182_0 : checkWitness 182 false false 564 = true := by decide +kernel
private theorem w182_1 : checkWitness 182 false true 4660 = true := by decide +kernel
private theorem w182_2 : checkWitness 182 true false 564 = true := by decide +kernel
private theorem w182_3 : checkWitness 182 true true 4660 = true := by decide +kernel
private theorem cases182 : checkFour 182 (564,4660,564,4660) = true := by
  simp only [checkFour, w182_0, w182_1, w182_2, w182_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one182 : Coverage 182 183 := checkList_sound (ws:=[(564,4660,564,4660)]) (by simpa only [checkList, Bool.and_true] using cases182)
private theorem w183_0 : checkWitness 183 false false 8899 = true := by decide +kernel
private theorem w183_2 : checkWitness 183 true false 8895 = true := by decide +kernel
private theorem cases183 : checkFour 183 (8899,0,8895,0) = true := by
  simp only [checkFour, w183_0, w183_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one183 : Coverage 183 184 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases183)
private theorem w184_0 : checkWitness 184 false false 8934 = true := by decide +kernel
private theorem w184_2 : checkWitness 184 true false 8925 = true := by decide +kernel
private theorem cases184 : checkFour 184 (8934,0,8925,0) = true := by
  simp only [checkFour, w184_0, w184_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one184 : Coverage 184 185 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases184)
private theorem w185_0 : checkWitness 185 false false 78 = true := by decide +kernel
private theorem w185_2 : checkWitness 185 true false 78 = true := by decide +kernel
private theorem cases185 : checkFour 185 (78,0,78,0) = true := by
  simp only [checkFour, w185_0, w185_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one185 : Coverage 185 186 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases185)
private theorem w186_0 : checkWitness 186 false false 646 = true := by decide +kernel
private theorem w186_1 : checkWitness 186 false true 4738 = true := by decide +kernel
private theorem w186_2 : checkWitness 186 true false 637 = true := by decide +kernel
private theorem w186_3 : checkWitness 186 true true 4729 = true := by decide +kernel
private theorem cases186 : checkFour 186 (646,4738,637,4729) = true := by
  simp only [checkFour, w186_0, w186_1, w186_2, w186_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one186 : Coverage 186 187 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases186)
private theorem w187_0 : checkWitness 187 false false 8895 = true := by decide +kernel
private theorem w187_2 : checkWitness 187 true false 8891 = true := by decide +kernel
private theorem cases187 : checkFour 187 (8895,0,8891,0) = true := by
  simp only [checkFour, w187_0, w187_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one187 : Coverage 187 188 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases187)
private theorem w188_0 : checkWitness 188 false false 640 = true := by decide +kernel
private theorem w188_1 : checkWitness 188 false true 4732 = true := by decide +kernel
private theorem w188_2 : checkWitness 188 true false 631 = true := by decide +kernel
private theorem w188_3 : checkWitness 188 true true 4723 = true := by decide +kernel
private theorem cases188 : checkFour 188 (640,4732,631,4723) = true := by
  simp only [checkFour, w188_0, w188_1, w188_2, w188_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one188 : Coverage 188 189 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases188)
private theorem w189_0 : checkWitness 189 false false 8864 = true := by decide +kernel
private theorem w189_2 : checkWitness 189 true false 8860 = true := by decide +kernel
private theorem cases189 : checkFour 189 (8864,0,8860,0) = true := by
  simp only [checkFour, w189_0, w189_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one189 : Coverage 189 190 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases189)
private theorem w190_0 : checkWitness 190 false false 66 = true := by decide +kernel
private theorem w190_2 : checkWitness 190 true false 66 = true := by decide +kernel
private theorem cases190 : checkFour 190 (66,0,66,0) = true := by
  simp only [checkFour, w190_0, w190_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one190 : Coverage 190 191 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases190)
private theorem w191_0 : checkWitness 191 false false 58 = true := by decide +kernel
private theorem w191_2 : checkWitness 191 true false 58 = true := by decide +kernel
private theorem cases191 : checkFour 191 (58,0,58,0) = true := by
  simp only [checkFour, w191_0, w191_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one191 : Coverage 191 192 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases191)
theorem cover0160 : Coverage 160 192 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one160 one161) (Coverage.join one162 one163)) (Coverage.join (Coverage.join one164 one165) (Coverage.join one166 one167))) (Coverage.join (Coverage.join (Coverage.join one168 one169) (Coverage.join one170 one171)) (Coverage.join (Coverage.join one172 one173) (Coverage.join one174 one175)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one176 one177) (Coverage.join one178 one179)) (Coverage.join (Coverage.join one180 one181) (Coverage.join one182 one183))) (Coverage.join (Coverage.join (Coverage.join one184 one185) (Coverage.join one186 one187)) (Coverage.join (Coverage.join one188 one189) (Coverage.join one190 one191)))))
end NF182PA.Symbolic
