import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w864_0 : checkWitness 864 false false 8894 = true := by decide +kernel
private theorem w864_2 : checkWitness 864 true false 8890 = true := by decide +kernel
private theorem cases864 : checkFour 864 (8894,0,8890,0) = true := by
  simp only [checkFour, w864_0, w864_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one864 : Coverage 864 865 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases864)
private theorem w865_0 : checkWitness 865 false false 8890 = true := by decide +kernel
private theorem w865_2 : checkWitness 865 true false 8886 = true := by decide +kernel
private theorem cases865 : checkFour 865 (8890,0,8886,0) = true := by
  simp only [checkFour, w865_0, w865_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one865 : Coverage 865 866 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases865)
private theorem w866_0 : checkWitness 866 false false 70 = true := by decide +kernel
private theorem w866_2 : checkWitness 866 true false 70 = true := by decide +kernel
private theorem cases866 : checkFour 866 (70,0,70,0) = true := by
  simp only [checkFour, w866_0, w866_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one866 : Coverage 866 867 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases866)
private theorem w867_0 : checkWitness 867 false false 550 = true := by decide +kernel
private theorem w867_1 : checkWitness 867 false true 4646 = true := by decide +kernel
private theorem w867_2 : checkWitness 867 true false 550 = true := by decide +kernel
private theorem w867_3 : checkWitness 867 true true 4646 = true := by decide +kernel
private theorem cases867 : checkFour 867 (550,4646,550,4646) = true := by
  simp only [checkFour, w867_0, w867_1, w867_2, w867_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one867 : Coverage 867 868 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases867)
private theorem w868_0 : checkWitness 868 false false 8964 = true := by decide +kernel
private theorem w868_2 : checkWitness 868 true false 8955 = true := by decide +kernel
private theorem cases868 : checkFour 868 (8964,0,8955,0) = true := by
  simp only [checkFour, w868_0, w868_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one868 : Coverage 868 869 := checkList_sound (ws:=[(8964,0,8955,0)]) (by simpa only [checkList, Bool.and_true] using cases868)
private theorem w869_0 : checkWitness 869 false false 64 = true := by decide +kernel
private theorem w869_2 : checkWitness 869 true false 64 = true := by decide +kernel
private theorem cases869 : checkFour 869 (64,0,64,0) = true := by
  simp only [checkFour, w869_0, w869_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one869 : Coverage 869 870 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases869)
private theorem w870_0 : checkWitness 870 false false 546 = true := by decide +kernel
private theorem w870_1 : checkWitness 870 false true 4642 = true := by decide +kernel
private theorem w870_2 : checkWitness 870 true false 546 = true := by decide +kernel
private theorem w870_3 : checkWitness 870 true true 4642 = true := by decide +kernel
private theorem cases870 : checkFour 870 (546,4642,546,4642) = true := by
  simp only [checkFour, w870_0, w870_1, w870_2, w870_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one870 : Coverage 870 871 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases870)
private theorem w871_0 : checkWitness 871 false false 8904 = true := by decide +kernel
private theorem w871_2 : checkWitness 871 true false 8900 = true := by decide +kernel
private theorem cases871 : checkFour 871 (8904,0,8900,0) = true := by
  simp only [checkFour, w871_0, w871_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one871 : Coverage 871 872 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases871)
private theorem w872_0 : checkWitness 872 false false 66 = true := by decide +kernel
private theorem w872_2 : checkWitness 872 true false 66 = true := by decide +kernel
private theorem cases872 : checkFour 872 (66,0,66,0) = true := by
  simp only [checkFour, w872_0, w872_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one872 : Coverage 872 873 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases872)
private theorem w873_0 : checkWitness 873 false false 590 = true := by decide +kernel
private theorem w873_1 : checkWitness 873 false true 4686 = true := by decide +kernel
private theorem w873_2 : checkWitness 873 true false 590 = true := by decide +kernel
private theorem w873_3 : checkWitness 873 true true 4686 = true := by decide +kernel
private theorem cases873 : checkFour 873 (590,4686,590,4686) = true := by
  simp only [checkFour, w873_0, w873_1, w873_2, w873_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one873 : Coverage 873 874 := checkList_sound (ws:=[(590,4686,590,4686)]) (by simpa only [checkList, Bool.and_true] using cases873)
private theorem w874_0 : checkWitness 874 false false 8925 = true := by decide +kernel
private theorem w874_2 : checkWitness 874 true false 8921 = true := by decide +kernel
private theorem cases874 : checkFour 874 (8925,0,8921,0) = true := by
  simp only [checkFour, w874_0, w874_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one874 : Coverage 874 875 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases874)
private theorem w875_0 : checkWitness 875 false false 8960 = true := by decide +kernel
private theorem w875_2 : checkWitness 875 true false 8951 = true := by decide +kernel
private theorem cases875 : checkFour 875 (8960,0,8951,0) = true := by
  simp only [checkFour, w875_0, w875_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one875 : Coverage 875 876 := checkList_sound (ws:=[(8960,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases875)
private theorem w876_0 : checkWitness 876 false false 90 = true := by decide +kernel
private theorem w876_2 : checkWitness 876 true false 90 = true := by decide +kernel
private theorem cases876 : checkFour 876 (90,0,90,0) = true := by
  simp only [checkFour, w876_0, w876_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one876 : Coverage 876 877 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases876)
private theorem w877_0 : checkWitness 877 false false 672 = true := by decide +kernel
private theorem w877_1 : checkWitness 877 false true 4764 = true := by decide +kernel
private theorem w877_2 : checkWitness 877 true false 663 = true := by decide +kernel
private theorem w877_3 : checkWitness 877 true true 4755 = true := by decide +kernel
private theorem cases877 : checkFour 877 (672,4764,663,4755) = true := by
  simp only [checkFour, w877_0, w877_1, w877_2, w877_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one877 : Coverage 877 878 := checkList_sound (ws:=[(672,4764,663,4755)]) (by simpa only [checkList, Bool.and_true] using cases877)
private theorem w878_0 : checkWitness 878 false false 8921 = true := by decide +kernel
private theorem w878_2 : checkWitness 878 true false 8917 = true := by decide +kernel
private theorem cases878 : checkFour 878 (8921,0,8917,0) = true := by
  simp only [checkFour, w878_0, w878_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one878 : Coverage 878 879 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases878)
private theorem w879_0 : checkWitness 879 false false 666 = true := by decide +kernel
private theorem w879_1 : checkWitness 879 false true 4758 = true := by decide +kernel
private theorem w879_2 : checkWitness 879 true false 657 = true := by decide +kernel
private theorem w879_3 : checkWitness 879 true true 4749 = true := by decide +kernel
private theorem cases879 : checkFour 879 (666,4758,657,4749) = true := by
  simp only [checkFour, w879_0, w879_1, w879_2, w879_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one879 : Coverage 879 880 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases879)
private theorem w880_0 : checkWitness 880 false false 8890 = true := by decide +kernel
private theorem w880_2 : checkWitness 880 true false 8886 = true := by decide +kernel
private theorem cases880 : checkFour 880 (8890,0,8886,0) = true := by
  simp only [checkFour, w880_0, w880_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one880 : Coverage 880 881 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases880)
private theorem w881_0 : checkWitness 881 false false 78 = true := by decide +kernel
private theorem w881_2 : checkWitness 881 true false 78 = true := by decide +kernel
private theorem cases881 : checkFour 881 (78,0,78,0) = true := by
  simp only [checkFour, w881_0, w881_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one881 : Coverage 881 882 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases881)
private theorem w882_0 : checkWitness 882 false false 70 = true := by decide +kernel
private theorem w882_2 : checkWitness 882 true false 70 = true := by decide +kernel
private theorem cases882 : checkFour 882 (70,0,70,0) = true := by
  simp only [checkFour, w882_0, w882_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one882 : Coverage 882 883 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases882)
private theorem w883_0 : checkWitness 883 false false 631 = true := by decide +kernel
private theorem w883_1 : checkWitness 883 false true 4715 = true := by decide +kernel
private theorem w883_2 : checkWitness 883 true false 631 = true := by decide +kernel
private theorem w883_3 : checkWitness 883 true true 4715 = true := by decide +kernel
private theorem cases883 : checkFour 883 (631,4715,631,4715) = true := by
  simp only [checkFour, w883_0, w883_1, w883_2, w883_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one883 : Coverage 883 884 := checkList_sound (ws:=[(631,4715,631,4715)]) (by simpa only [checkList, Bool.and_true] using cases883)
private theorem w884_0 : checkWitness 884 false false 8884 = true := by decide +kernel
private theorem w884_2 : checkWitness 884 true false 8880 = true := by decide +kernel
private theorem cases884 : checkFour 884 (8884,0,8880,0) = true := by
  simp only [checkFour, w884_0, w884_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one884 : Coverage 884 885 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases884)
private theorem w885_0 : checkWitness 885 false false 70 = true := by decide +kernel
private theorem w885_2 : checkWitness 885 true false 70 = true := by decide +kernel
private theorem cases885 : checkFour 885 (70,0,70,0) = true := by
  simp only [checkFour, w885_0, w885_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one885 : Coverage 885 886 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases885)
private theorem w886_0 : checkWitness 886 false false 8898 = true := by decide +kernel
private theorem w886_2 : checkWitness 886 true false 8894 = true := by decide +kernel
private theorem cases886 : checkFour 886 (8898,0,8894,0) = true := by
  simp only [checkFour, w886_0, w886_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one886 : Coverage 886 887 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases886)
private theorem w887_0 : checkWitness 887 false false 578 = true := by decide +kernel
private theorem w887_1 : checkWitness 887 false true 4674 = true := by decide +kernel
private theorem w887_2 : checkWitness 887 true false 578 = true := by decide +kernel
private theorem w887_3 : checkWitness 887 true true 4674 = true := by decide +kernel
private theorem cases887 : checkFour 887 (578,4674,578,4674) = true := by
  simp only [checkFour, w887_0, w887_1, w887_2, w887_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one887 : Coverage 887 888 := checkList_sound (ws:=[(578,4674,578,4674)]) (by simpa only [checkList, Bool.and_true] using cases887)
private theorem w888_0 : checkWitness 888 false false 8934 = true := by decide +kernel
private theorem w888_2 : checkWitness 888 true false 8925 = true := by decide +kernel
private theorem cases888 : checkFour 888 (8934,0,8925,0) = true := by
  simp only [checkFour, w888_0, w888_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one888 : Coverage 888 889 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases888)
private theorem w889_0 : checkWitness 889 false false 74 = true := by decide +kernel
private theorem w889_2 : checkWitness 889 true false 74 = true := by decide +kernel
private theorem cases889 : checkFour 889 (74,0,74,0) = true := by
  simp only [checkFour, w889_0, w889_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one889 : Coverage 889 890 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases889)
private theorem w890_0 : checkWitness 890 false false 516 = true := by decide +kernel
private theorem w890_1 : checkWitness 890 false true 4612 = true := by decide +kernel
private theorem w890_2 : checkWitness 890 true false 516 = true := by decide +kernel
private theorem w890_3 : checkWitness 890 true true 4612 = true := by decide +kernel
private theorem cases890 : checkFour 890 (516,4612,516,4612) = true := by
  simp only [checkFour, w890_0, w890_1, w890_2, w890_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one890 : Coverage 890 891 := checkList_sound (ws:=[(516,4612,516,4612)]) (by simpa only [checkList, Bool.and_true] using cases890)
private theorem w891_0 : checkWitness 891 false false 8874 = true := by decide +kernel
private theorem w891_2 : checkWitness 891 true false 8870 = true := by decide +kernel
private theorem cases891 : checkFour 891 (8874,0,8870,0) = true := by
  simp only [checkFour, w891_0, w891_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one891 : Coverage 891 892 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases891)
private theorem w892_0 : checkWitness 892 false false 76 = true := by decide +kernel
private theorem w892_2 : checkWitness 892 true false 76 = true := by decide +kernel
private theorem cases892 : checkFour 892 (76,0,76,0) = true := by
  simp only [checkFour, w892_0, w892_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one892 : Coverage 892 893 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases892)
private theorem w893_0 : checkWitness 893 false false 560 = true := by decide +kernel
private theorem w893_1 : checkWitness 893 false true 4656 = true := by decide +kernel
private theorem w893_2 : checkWitness 893 true false 560 = true := by decide +kernel
private theorem w893_3 : checkWitness 893 true true 4656 = true := by decide +kernel
private theorem cases893 : checkFour 893 (560,4656,560,4656) = true := by
  simp only [checkFour, w893_0, w893_1, w893_2, w893_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one893 : Coverage 893 894 := checkList_sound (ws:=[(560,4656,560,4656)]) (by simpa only [checkList, Bool.and_true] using cases893)
private theorem w894_0 : checkWitness 894 false false 8895 = true := by decide +kernel
private theorem w894_2 : checkWitness 894 true false 8891 = true := by decide +kernel
private theorem cases894 : checkFour 894 (8895,0,8891,0) = true := by
  simp only [checkFour, w894_0, w894_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one894 : Coverage 894 895 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases894)
private theorem w895_0 : checkWitness 895 false false 8930 = true := by decide +kernel
private theorem w895_2 : checkWitness 895 true false 8921 = true := by decide +kernel
private theorem cases895 : checkFour 895 (8930,0,8921,0) = true := by
  simp only [checkFour, w895_0, w895_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one895 : Coverage 895 896 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases895)
theorem cover0864 : Coverage 864 896 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one864 one865) (Coverage.join one866 one867)) (Coverage.join (Coverage.join one868 one869) (Coverage.join one870 one871))) (Coverage.join (Coverage.join (Coverage.join one872 one873) (Coverage.join one874 one875)) (Coverage.join (Coverage.join one876 one877) (Coverage.join one878 one879)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one880 one881) (Coverage.join one882 one883)) (Coverage.join (Coverage.join one884 one885) (Coverage.join one886 one887))) (Coverage.join (Coverage.join (Coverage.join one888 one889) (Coverage.join one890 one891)) (Coverage.join (Coverage.join one892 one893) (Coverage.join one894 one895)))))
end NF182PA.Symbolic
