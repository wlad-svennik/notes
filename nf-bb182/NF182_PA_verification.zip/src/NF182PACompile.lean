module
public import CommandWords
public import ModelPackedCommands
public import NF182PACommands
public import ModelExtract

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxHeartbeats 3000000
set_option maxRecDepth 32000
namespace NF182PA.Commands
open PA192.ModelSearch
open NF182PA.Pool (test nativeB)
open PA192.ModelSearch.RegisterFields NF182PA.Packed PA192.ModelSearch.Words
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- Standard finite macros are interpreted in every arithmetic model. -/
theorem unfold_nips (m : Nat) (s : V) : run exec (nips (m:V)) s =
    run exec (literal (List.replicate m nip)) s := by
  induction m generalizing s with
  | zero => simp
  | succ n ih => simp [Nat.cast_succ,nips_succ,List.replicate_succ,ih]

theorem strip_six (a b c u t z h : V) : run exec (nips 6)
    (state t (front6 a b c u z) h 0) = state t z (row0 a b c u) 0 := by
  rw [show nips (6:V) = nips ((6:Nat):V) from rfl,unfold_nips]
  simp [List.replicate_succ,front6]

theorem strip_eight (a b c u t z h : V) : run exec (nips 8)
    (state t (front8 a b c u z) h 0) = state t z (row0 a b c u) 0 := by
  rw [show nips (8:V) = nips ((8:Nat):V) from rfl,unfold_nips]
  simp [List.replicate_succ,front8,front6]

theorem strip_higher (a b : V) : ∀ j : V, ∀ z t h, ∃ x,
    run exec (nips (8*j)) (state t (higher a b j z) h 0) = state t z x 0 := by
  apply modelInduct
  · unfold state higher body packBatch; definability
  · intro z t h; exact ⟨h,by simp⟩
  · intro j ih z t h
    rw [mul_add,mul_one,nip_add,higher_succ]
    obtain ⟨x,hx⟩ := ih (front8 a b (j+1) a z) t h
    rw [hx,strip_eight]
    exact ⟨_,rfl⟩

theorem strip_extra (a b j z t h : V) : ∃ x, run exec (nips (6+8*j))
    (state t (front6 a b 0 a (higher a b j z)) h 0) = state t z x 0 := by
  rw [nip_add,strip_six]
  exact strip_higher ..

noncomputable def sweep : V := literal [blank,nip,nip,nip,nip,nip,nip]
noncomputable def reset : V := append sweep (append sweep (singleton (cmdMode 0)))

theorem sweep_run (t s h p : V) : run exec sweep (state t s h p) =
    state 0 (cantor t s) (row0 p h 0 p) 0 := by simp [sweep,front6]
@[simp] theorem reset_run (t s h p : V) : run exec reset (state t s h p) = state 0 (cantor t s) 0 0 := by
  simp [reset,run_append,sweep_run,deduction_state]

def Produces (w x : V) : Prop := ∀ t s h p, ∃ z, run exec w (state t s h p) = state x (cantor t s) z 0
instance producesDef : Language.DefinableRel ℒₒᵣ (Produces (V:=V)) := by unfold Produces state; definability
def Obtainable (x : V) : Prop := ∃ w : V, Produces w x
instance obtainableDef : Language.DefinablePred ℒₒᵣ (Obtainable (V:=V)) := by unfold Obtainable; definability

theorem produces_mp {a b m M : V} (hm : Produces m a) (hM : Produces M (imp a b)) :
    Produces (append reset (append m (append M (literal [nip,swap,cmdMode b])))) b := by
  intro t s h p
  obtain ⟨z,hz⟩ := hm 0 (cantor t s) 0 0
  obtain ⟨Z,hZ⟩ := hM a (cantor 0 (cantor t s)) z 0
  exact ⟨0,by simp [run_append,reset_run,hz,hZ,deduction_state]⟩

private theorem get_0_zero (u b d : V) : Obtainable (row0 (u+d) b 0 u) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,nip,nip,nip,swap,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front6]⟩

private theorem get_0_pos (u b d j : V) : Obtainable (row0 (u+d) b (j+1) u) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (6+8*j)) (literal [nip,nip,nip,nip,nip,nip,nip,nip,swap,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]
  obtain ⟨x,hx⟩ := strip_extra (u+d) b j _ 0 (test b (u+d))
  rw [hx]
  exact ⟨0,by simp [front8,front6]⟩

private theorem get_1_zero (u b d : V) : Obtainable (row3 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,nip,nip,swap,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front6]⟩

private theorem get_1_pos (u b d j : V) : Obtainable (row3 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (6+8*j)) (literal [nip,nip,nip,nip,nip,nip,nip,swap,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]
  obtain ⟨x,hx⟩ := strip_extra (u+d) b j _ 0 (test b (u+d))
  rw [hx]
  exact ⟨0,by simp [front8,front6]⟩

private theorem get_2_zero (u b d : V) : Obtainable (row6 (u+d) b 0) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,nip,swap,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front6]⟩

private theorem get_2_pos (u b d j : V) : Obtainable (row6 (u+d) b (j+1)) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (6+8*j)) (literal [nip,nip,nip,nip,nip,nip,swap,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]
  obtain ⟨x,hx⟩ := strip_extra (u+d) b j _ 0 (test b (u+d))
  rw [hx]
  exact ⟨0,by simp [front8,front6]⟩

private theorem get_3_zero (u b d : V) : Obtainable (nativeB (u+d) b 0) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,nip,swap,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front6]⟩

private theorem get_3_pos (u b d j : V) : Obtainable (nativeB (u+d) b (j+1)) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (6+8*j)) (literal [nip,nip,nip,nip,nip,swap,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]
  obtain ⟨x,hx⟩ := strip_extra (u+d) b j _ 0 (test b (u+d))
  rw [hx]
  exact ⟨0,by simp [front8,front6]⟩

private theorem get_4_zero (u b d : V) : Obtainable (row2 (u+d) b 0) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,nip,swap,nip,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front6]⟩

private theorem get_4_pos (u b d j : V) : Obtainable (row2 (u+d) b (j+1)) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (6+8*j)) (literal [nip,nip,nip,nip,swap,nip,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]
  obtain ⟨x,hx⟩ := strip_extra (u+d) b j _ 0 (test b (u+d))
  rw [hx]
  exact ⟨0,by simp [front8,front6]⟩

private theorem get_5_zero (u b d : V) : Obtainable (row4 (u+d) b 0) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [nip,swap,nip,nip,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front6]⟩

private theorem get_5_pos (u b d j : V) : Obtainable (row4 (u+d) b (j+1)) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (6+8*j)) (literal [nip,nip,nip,swap,nip,nip,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]
  obtain ⟨x,hx⟩ := strip_extra (u+d) b j _ 0 (test b (u+d))
  rw [hx]
  exact ⟨0,by simp [front8,front6]⟩

private theorem get_6_zero (u b d : V) : Obtainable (test b (u+d)) := by
  refine ⟨append reset (cons (cmdAX u b d 0) (literal [swap,nip,nip,nip,nip,nip,nip,nip])),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_zero,pi₁_pair,zero_add]
  exact ⟨0,by simp [front6]⟩

private theorem get_6_pos (u b d j : V) : Obtainable (test b (u+d)) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (6+8*j)) (literal [nip,nip,swap,nip,nip,nip,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]
  obtain ⟨x,hx⟩ := strip_extra (u+d) b j _ 0 (test b (u+d))
  rw [hx]
  exact ⟨0,by simp [front8,front6]⟩

private theorem get_7_pos (u b d j : V) : Obtainable (row8 (u+d) b) := by
  refine ⟨append reset (cons (cmdAX u b d (j+1)) (append (nips (6+8*j)) (literal [nip,swap,nip,nip,nip,nip,nip,nip,nip,nip]))),?_⟩
  intro t s h p
  simp only [run_append,reset_run,run_cons,exec_ax,ax_positive,pi₁_pair,zero_add]
  obtain ⟨x,hx⟩ := strip_extra (u+d) b j _ 0 (test b (u+d))
  rw [hx]
  exact ⟨0,by simp [front8,front6]⟩

theorem proof_produces {p : V} (h : NF182PA.Pool.Pr (∅ : V) p) : Obtainable p := by
  apply NF182PA.Pool.realize (R:=Obtainable) (h:=h)
  · rintro x ⟨a,b,c,u,hu,hr⟩
    obtain ⟨d,rfl⟩ := exists_add_of_le (le_of_not_gt hu)
    by_cases hc : c=0
    · subst c
      simp only [NF182PA.Pool.batch,List.mem_cons,List.not_mem_nil,or_false] at hr
      rcases hr with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
      · exact get_0_zero u b d
      · exact get_1_zero u b d
      · exact get_2_zero u b d
      · exact get_3_zero u b d
      · exact get_4_zero u b d
      · exact get_5_zero u b d
      · exact get_6_zero u b d
      · exact get_7_pos u b d 0
    · have one : 1 ≤ c := by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne zero_le (Ne.symm hc))
      obtain ⟨j,rfl⟩ : ∃ j, c=j+1 := ⟨c-1,(sub_add_self_of_le one).symm⟩
      simp only [NF182PA.Pool.batch,List.mem_cons,List.not_mem_nil,or_false] at hr
      rcases hr with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
      · exact get_0_pos u b d j
      · exact get_1_pos u b d j
      · exact get_2_pos u b d j
      · exact get_3_pos u b d j
      · exact get_4_pos u b d j
      · exact get_5_pos u b d j
      · exact get_6_pos u b d j
      · exact get_7_pos u b d j
  · intro _ empty
    simp at empty
  · rintro a b ⟨major,hm⟩ ⟨minor,hn⟩
    exact ⟨_,produces_mp hn hm⟩
end NF182PA.Commands
#print axioms NF182PA.Commands.proof_produces
