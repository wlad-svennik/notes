import PackageFacts
import PAAxioms
namespace NF192.Direct
universe u
variable {V : Type u}
abbrev Dom (m : V → V → Prop) (D : V) := {n // m n D}

theorem makeFun1 {N : V → Prop} {r : V → V → Prop} (h : Fn1 N r) :
    ∃f : {x//N x} → {x//N x},∀x y,r x.val y.val ↔ f x=y := by
  classical
  have h1 (x : {x//N x}) : ∃ y : {x//N x}, r x.val y.val ∧ ∀w : {x//N x},r x.val w.val → w=y := by
    obtain ⟨y,hy,hxy,hw⟩ := h x x.property
    exact ⟨⟨y,hy⟩,hxy,fun w huw => Subtype.ext (hw w w.2 huw)⟩
  let f := fun x => Classical.choose (h1 x)
  refine ⟨f,fun x y => ⟨fun hxy => ((Classical.choose_spec (h1 x)).2 y hxy).symm,?_⟩⟩
  rintro rfl;exact (Classical.choose_spec (h1 x)).1

theorem makeFun2 {N : V → Prop} {r : V → V → V → Prop} (h : Fn2 N r) :
    ∃f : {x//N x} → {x//N x} → {x//N x},∀x y z,r x.val y.val z.val ↔ f x y=z := by
  classical
  have h1 (x y : {x//N x}) : ∃ z : {x//N x}, r x.val y.val z.val ∧ ∀w : {x//N x},r x.val y.val w.val → w=z := by
    obtain ⟨z,hz,hxyz,hw⟩ := h x y ⟨x.2,y.2⟩
    exact ⟨⟨z,hz⟩,hxyz,fun w huw => Subtype.ext (hw w w.2 huw)⟩
  let f := fun x y => Classical.choose (h1 x y)
  refine ⟨f,fun x y z => ⟨fun hxy => ((Classical.choose_spec (h1 x y)).2 z hxy).symm,?_⟩⟩
  rintro rfl;exact (Classical.choose_spec (h1 x y)).1

def RepOne (m : V → V → Prop) (D : V) (X : One (Dom m D)) := ∃ C,∀x,m x.val C ↔ X x
def RepTwo (m : V → V → Prop) (D P : V) (R : Two (Dom m D)) := ∃ C,∀x y,RelObj m D P C x.val y.val ↔ R x y

structure OpsLaws (m : V → V → Prop) (D z S A B P : V) (o : NumOps (Dom m D)) : Prop where
  zv : o.z.val=z
  sv : ∀x y,Edge m S x.val y.val ↔ o.s x=y
  av : ∀x y w,Tri m A x.val y.val w.val ↔ o.add x y=w
  mv : ∀x y w,Tri m B x.val y.val w.val ↔ o.mul x y=w
  pv : ∀x y w,Tri m P x.val y.val w.val ↔ o.pair x y=w

theorem extractOps {m : V → V → Prop} {D z S A B P : V} (hc : CoreAt m D z S A B P) :
    ∃o : NumOps (Dom m D),OpsLaws m D z S A B P o ∧ o.SatisfiesQ ∧
      ∀ X, RepOne m D X → InductiveOn o.z o.s X → ∀ n,X n := by
  obtain ⟨hz,fS,fA,fB,fP,ip,nz,is,pr,az,as_,mz,ms,si⟩ := hc
  obtain ⟨s,hs⟩ := makeFun1 fS
  obtain ⟨a,ha⟩ := makeFun2 fA
  obtain ⟨b,hb⟩ := makeFun2 fB
  obtain ⟨p,hp⟩ := makeFun2 fP
  let Z : Dom m D := ⟨z,hz⟩
  let o : NumOps (Dom m D) := ⟨Z,s,a,b,p,by
    intro x y v w e
    have a0 := (hp x y (p x y)).mpr rfl
    have b0 := (hp v w (p x y)).mpr e.symm
    obtain ⟨ex,ey⟩ := ip _ _ _ _ _ ⟨x.2,y.2,v.2,w.2,(p x y).2⟩ ⟨a0,b0⟩
    exact ⟨Subtype.ext ex,Subtype.ext ey⟩⟩
  refine ⟨o,⟨rfl,hs,ha,hb,hp⟩,⟨?_,?_,?_,?_,?_,?_,?_⟩,?_⟩
  · intro x e; exact nz x x.2 ((hs x Z).mpr e)
  · intro x y e;apply Subtype.ext
    exact is x y (s x) ⟨x.2,y.2,(s x).2⟩ ⟨(hs x _).mpr rfl,(hs y _).mpr e.symm⟩
  · intro x;rcases pr x x.2 with e | ⟨y,hy,hxy⟩
    · exact Or.inl (Subtype.ext e)
    · exact Or.inr ⟨⟨y,hy⟩,((hs ⟨y,hy⟩ x).mp hxy).symm⟩
  · intro x;exact (ha x Z x).mp (az x x.2)
  · intro x y;exact (ha x (s y) (s (a x y))).mp (as_ x y (s y) (a x y) (s (a x y))
      ⟨x.2,y.2,(s y).2,(a x y).2,(s (a x y)).2⟩
      ⟨(hs y _).mpr rfl,(ha x y _).mpr rfl,(hs (a x y) _).mpr rfl⟩)
  · intro x;exact (hb x Z Z).mp (mz x x.2)
  · intro x y;exact (hb x (s y) (a (b x y) x)).mp (ms x y (s y) (b x y) (a (b x y) x)
      ⟨x.2,y.2,(s y).2,(b x y).2,(a (b x y) x).2⟩
      ⟨(hs y _).mpr rfl,(hb x y _).mpr rfl,(ha (b x y) x _).mpr rfl⟩)
  · intro X ⟨C,hC⟩ ⟨h0,hstep⟩ n
    apply (hC n).mp
    apply si C _ n n.2
    refine ⟨(hC Z).mpr h0,?_⟩
    intro x y ⟨nx,ny⟩ ⟨es,hx⟩
    let u : Dom m D := ⟨x,nx⟩;let v : Dom m D := ⟨y,ny⟩
    have ev : s u=v := (hs u v).mp es
    apply (hC v).mpr
    rw [← ev];exact hstep u ((hC u).mp hx)

#print axioms extractOps
end NF192.Direct
