import NF185PATapeBatchCheck
namespace NF185PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w256_0 : checkWitness 256 false false 585 = true := by decide +kernel
private theorem w256_1 : checkWitness 256 false true 4677 = true := by decide +kernel
private theorem w256_2 : checkWitness 256 true false 585 = true := by decide +kernel
private theorem w256_3 : checkWitness 256 true true 4677 = true := by decide +kernel
private theorem cases256 : checkFour 256 (585,4677,585,4677) = true := by
  simp only [checkFour, w256_0, w256_1, w256_2, w256_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one256 : Coverage 256 257 := checkList_sound (ws:=[(585,4677,585,4677)]) (by simpa only [checkList, Bool.and_true] using cases256)
private theorem w257_0 : checkWitness 257 false false 8862 = true := by decide +kernel
private theorem w257_2 : checkWitness 257 true false 8858 = true := by decide +kernel
private theorem cases257 : checkFour 257 (8862,0,8858,0) = true := by
  simp only [checkFour, w257_0, w257_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one257 : Coverage 257 258 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases257)
private theorem w258_0 : checkWitness 258 false false 64 = true := by decide +kernel
private theorem w258_2 : checkWitness 258 true false 64 = true := by decide +kernel
private theorem cases258 : checkFour 258 (64,0,64,0) = true := by
  simp only [checkFour, w258_0, w258_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one258 : Coverage 258 259 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases258)
private theorem w259_0 : checkWitness 259 false false 550 = true := by decide +kernel
private theorem w259_1 : checkWitness 259 false true 4646 = true := by decide +kernel
private theorem w259_2 : checkWitness 259 true false 550 = true := by decide +kernel
private theorem w259_3 : checkWitness 259 true true 4646 = true := by decide +kernel
private theorem cases259 : checkFour 259 (550,4646,550,4646) = true := by
  simp only [checkFour, w259_0, w259_1, w259_2, w259_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one259 : Coverage 259 260 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases259)
private theorem w260_0 : checkWitness 260 false false 8893 = true := by decide +kernel
private theorem w260_2 : checkWitness 260 true false 8889 = true := by decide +kernel
private theorem cases260 : checkFour 260 (8893,0,8889,0) = true := by
  simp only [checkFour, w260_0, w260_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one260 : Coverage 260 261 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases260)
private theorem w261_0 : checkWitness 261 false false 8934 = true := by decide +kernel
private theorem w261_2 : checkWitness 261 true false 8925 = true := by decide +kernel
private theorem cases261 : checkFour 261 (8934,0,8925,0) = true := by
  simp only [checkFour, w261_0, w261_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one261 : Coverage 261 262 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases261)
private theorem w262_0 : checkWitness 262 false false 70 = true := by decide +kernel
private theorem w262_2 : checkWitness 262 true false 70 = true := by decide +kernel
private theorem cases262 : checkFour 262 (70,0,70,0) = true := by
  simp only [checkFour, w262_0, w262_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one262 : Coverage 262 263 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases262)
private theorem w263_0 : checkWitness 263 false false 638 = true := by decide +kernel
private theorem w263_1 : checkWitness 263 false true 4730 = true := by decide +kernel
private theorem w263_2 : checkWitness 263 true false 629 = true := by decide +kernel
private theorem w263_3 : checkWitness 263 true true 4721 = true := by decide +kernel
private theorem cases263 : checkFour 263 (638,4730,629,4721) = true := by
  simp only [checkFour, w263_0, w263_1, w263_2, w263_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one263 : Coverage 263 264 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases263)
private theorem w264_0 : checkWitness 264 false false 8889 = true := by decide +kernel
private theorem w264_2 : checkWitness 264 true false 8885 = true := by decide +kernel
private theorem cases264 : checkFour 264 (8889,0,8885,0) = true := by
  simp only [checkFour, w264_0, w264_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one264 : Coverage 264 265 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases264)
private theorem w265_0 : checkWitness 265 false false 626 = true := by decide +kernel
private theorem w265_1 : checkWitness 265 false true 4718 = true := by decide +kernel
private theorem w265_2 : checkWitness 265 true false 617 = true := by decide +kernel
private theorem w265_3 : checkWitness 265 true true 4709 = true := by decide +kernel
private theorem cases265 : checkFour 265 (626,4718,617,4709) = true := by
  simp only [checkFour, w265_0, w265_1, w265_2, w265_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one265 : Coverage 265 266 := checkList_sound (ws:=[(626,4718,617,4709)]) (by simpa only [checkList, Bool.and_true] using cases265)
private theorem w266_0 : checkWitness 266 false false 8856 = true := by decide +kernel
private theorem w266_2 : checkWitness 266 true false 8852 = true := by decide +kernel
private theorem cases266 : checkFour 266 (8856,0,8852,0) = true := by
  simp only [checkFour, w266_0, w266_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one266 : Coverage 266 267 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases266)
private theorem w267_0 : checkWitness 267 false false 70 = true := by decide +kernel
private theorem w267_2 : checkWitness 267 true false 70 = true := by decide +kernel
private theorem cases267 : checkFour 267 (70,0,70,0) = true := by
  simp only [checkFour, w267_0, w267_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one267 : Coverage 267 268 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases267)
private theorem w268_0 : checkWitness 268 false false 64 = true := by decide +kernel
private theorem w268_2 : checkWitness 268 true false 64 = true := by decide +kernel
private theorem cases268 : checkFour 268 (64,0,64,0) = true := by
  simp only [checkFour, w268_0, w268_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one268 : Coverage 268 269 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases268)
private theorem w269_0 : checkWitness 269 false false 593 = true := by decide +kernel
private theorem w269_1 : checkWitness 269 false true 4677 = true := by decide +kernel
private theorem w269_2 : checkWitness 269 true false 593 = true := by decide +kernel
private theorem w269_3 : checkWitness 269 true true 4677 = true := by decide +kernel
private theorem cases269 : checkFour 269 (593,4677,593,4677) = true := by
  simp only [checkFour, w269_0, w269_1, w269_2, w269_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one269 : Coverage 269 270 := checkList_sound (ws:=[(593,4677,593,4677)]) (by simpa only [checkList, Bool.and_true] using cases269)
private theorem w270_0 : checkWitness 270 false false 8872 = true := by decide +kernel
private theorem w270_2 : checkWitness 270 true false 8868 = true := by decide +kernel
private theorem cases270 : checkFour 270 (8872,0,8868,0) = true := by
  simp only [checkFour, w270_0, w270_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one270 : Coverage 270 271 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases270)
private theorem w271_0 : checkWitness 271 false false 8868 = true := by decide +kernel
private theorem w271_2 : checkWitness 271 true false 8864 = true := by decide +kernel
private theorem cases271 : checkFour 271 (8868,0,8864,0) = true := by
  simp only [checkFour, w271_0, w271_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one271 : Coverage 271 272 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases271)
private theorem w272_0 : checkWitness 272 false false 66 = true := by decide +kernel
private theorem w272_2 : checkWitness 272 true false 66 = true := by decide +kernel
private theorem cases272 : checkFour 272 (66,0,66,0) = true := by
  simp only [checkFour, w272_0, w272_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one272 : Coverage 272 273 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases272)
private theorem w273_0 : checkWitness 273 false false 542 = true := by decide +kernel
private theorem w273_1 : checkWitness 273 false true 4638 = true := by decide +kernel
private theorem w273_2 : checkWitness 273 true false 542 = true := by decide +kernel
private theorem w273_3 : checkWitness 273 true true 4638 = true := by decide +kernel
private theorem cases273 : checkFour 273 (542,4638,542,4638) = true := by
  simp only [checkFour, w273_0, w273_1, w273_2, w273_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one273 : Coverage 273 274 := checkList_sound (ws:=[(542,4638,542,4638)]) (by simpa only [checkList, Bool.and_true] using cases273)
private theorem w274_0 : checkWitness 274 false false 8924 = true := by decide +kernel
private theorem w274_2 : checkWitness 274 true false 8915 = true := by decide +kernel
private theorem cases274 : checkFour 274 (8924,0,8915,0) = true := by
  simp only [checkFour, w274_0, w274_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one274 : Coverage 274 275 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases274)
private theorem w275_0 : checkWitness 275 false false 60 = true := by decide +kernel
private theorem w275_2 : checkWitness 275 true false 60 = true := by decide +kernel
private theorem cases275 : checkFour 275 (60,0,60,0) = true := by
  simp only [checkFour, w275_0, w275_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one275 : Coverage 275 276 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases275)
private theorem w276_0 : checkWitness 276 false false 504 = true := by decide +kernel
private theorem w276_1 : checkWitness 276 false true 4600 = true := by decide +kernel
private theorem w276_2 : checkWitness 276 true false 504 = true := by decide +kernel
private theorem w276_3 : checkWitness 276 true true 4600 = true := by decide +kernel
private theorem cases276 : checkFour 276 (504,4600,504,4600) = true := by
  simp only [checkFour, w276_0, w276_1, w276_2, w276_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one276 : Coverage 276 277 := checkList_sound (ws:=[(504,4600,504,4600)]) (by simpa only [checkList, Bool.and_true] using cases276)
private theorem w277_0 : checkWitness 277 false false 8868 = true := by decide +kernel
private theorem w277_2 : checkWitness 277 true false 8864 = true := by decide +kernel
private theorem cases277 : checkFour 277 (8868,0,8864,0) = true := by
  simp only [checkFour, w277_0, w277_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one277 : Coverage 277 278 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases277)
private theorem w278_0 : checkWitness 278 false false 64 = true := by decide +kernel
private theorem w278_2 : checkWitness 278 true false 64 = true := by decide +kernel
private theorem cases278 : checkFour 278 (64,0,64,0) = true := by
  simp only [checkFour, w278_0, w278_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one278 : Coverage 278 279 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases278)
private theorem w279_0 : checkWitness 279 false false 548 = true := by decide +kernel
private theorem w279_1 : checkWitness 279 false true 4644 = true := by decide +kernel
private theorem w279_2 : checkWitness 279 true false 548 = true := by decide +kernel
private theorem w279_3 : checkWitness 279 true true 4644 = true := by decide +kernel
private theorem cases279 : checkFour 279 (548,4644,548,4644) = true := by
  simp only [checkFour, w279_0, w279_1, w279_2, w279_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one279 : Coverage 279 280 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases279)
private theorem w280_0 : checkWitness 280 false false 8891 = true := by decide +kernel
private theorem w280_2 : checkWitness 280 true false 8887 = true := by decide +kernel
private theorem cases280 : checkFour 280 (8891,0,8887,0) = true := by
  simp only [checkFour, w280_0, w280_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one280 : Coverage 280 281 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases280)
private theorem w281_0 : checkWitness 281 false false 8932 = true := by decide +kernel
private theorem w281_2 : checkWitness 281 true false 8923 = true := by decide +kernel
private theorem cases281 : checkFour 281 (8932,0,8923,0) = true := by
  simp only [checkFour, w281_0, w281_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one281 : Coverage 281 282 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases281)
private theorem w282_0 : checkWitness 282 false false 76 = true := by decide +kernel
private theorem w282_2 : checkWitness 282 true false 76 = true := by decide +kernel
private theorem cases282 : checkFour 282 (76,0,76,0) = true := by
  simp only [checkFour, w282_0, w282_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one282 : Coverage 282 283 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases282)
private theorem w283_0 : checkWitness 283 false false 636 = true := by decide +kernel
private theorem w283_1 : checkWitness 283 false true 4728 = true := by decide +kernel
private theorem w283_2 : checkWitness 283 true false 627 = true := by decide +kernel
private theorem w283_3 : checkWitness 283 true true 4719 = true := by decide +kernel
private theorem cases283 : checkFour 283 (636,4728,627,4719) = true := by
  simp only [checkFour, w283_0, w283_1, w283_2, w283_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one283 : Coverage 283 284 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases283)
private theorem w284_0 : checkWitness 284 false false 8887 = true := by decide +kernel
private theorem w284_2 : checkWitness 284 true false 8883 = true := by decide +kernel
private theorem cases284 : checkFour 284 (8887,0,8883,0) = true := by
  simp only [checkFour, w284_0, w284_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one284 : Coverage 284 285 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases284)
private theorem w285_0 : checkWitness 285 false false 624 = true := by decide +kernel
private theorem w285_1 : checkWitness 285 false true 4716 = true := by decide +kernel
private theorem w285_2 : checkWitness 285 true false 615 = true := by decide +kernel
private theorem w285_3 : checkWitness 285 true true 4707 = true := by decide +kernel
private theorem cases285 : checkFour 285 (624,4716,615,4707) = true := by
  simp only [checkFour, w285_0, w285_1, w285_2, w285_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one285 : Coverage 285 286 := checkList_sound (ws:=[(624,4716,615,4707)]) (by simpa only [checkList, Bool.and_true] using cases285)
private theorem w286_0 : checkWitness 286 false false 8854 = true := by decide +kernel
private theorem w286_2 : checkWitness 286 true false 8850 = true := by decide +kernel
private theorem cases286 : checkFour 286 (8854,0,8850,0) = true := by
  simp only [checkFour, w286_0, w286_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one286 : Coverage 286 287 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases286)
private theorem w287_0 : checkWitness 287 false false 76 = true := by decide +kernel
private theorem w287_2 : checkWitness 287 true false 76 = true := by decide +kernel
private theorem cases287 : checkFour 287 (76,0,76,0) = true := by
  simp only [checkFour, w287_0, w287_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one287 : Coverage 287 288 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases287)
theorem cover0256 : Coverage 256 288 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one256 one257) (Coverage.join one258 one259)) (Coverage.join (Coverage.join one260 one261) (Coverage.join one262 one263))) (Coverage.join (Coverage.join (Coverage.join one264 one265) (Coverage.join one266 one267)) (Coverage.join (Coverage.join one268 one269) (Coverage.join one270 one271)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one272 one273) (Coverage.join one274 one275)) (Coverage.join (Coverage.join one276 one277) (Coverage.join one278 one279))) (Coverage.join (Coverage.join (Coverage.join one280 one281) (Coverage.join one282 one283)) (Coverage.join (Coverage.join one284 one285) (Coverage.join one286 one287)))))
end NF185PA.Symbolic
