import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2496_0 : checkWitness 2496 false false 688 = true := by decide +kernel
private theorem w2496_1 : checkWitness 2496 false true 4780 = true := by decide +kernel
private theorem w2496_2 : checkWitness 2496 true false 679 = true := by decide +kernel
private theorem w2496_3 : checkWitness 2496 true true 4771 = true := by decide +kernel
private theorem cases2496 : checkFour 2496 (688,4780,679,4771) = true := by
  simp only [checkFour, w2496_0, w2496_1, w2496_2, w2496_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2496 : Coverage 2496 2497 := checkList_sound (ws:=[(688,4780,679,4771)]) (by simpa only [checkList, Bool.and_true] using cases2496)
private theorem w2497_0 : checkWitness 2497 false false 8912 = true := by decide +kernel
private theorem w2497_2 : checkWitness 2497 true false 8908 = true := by decide +kernel
private theorem cases2497 : checkFour 2497 (8912,0,8908,0) = true := by
  simp only [checkFour, w2497_0, w2497_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2497 : Coverage 2497 2498 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases2497)
private theorem w2498_0 : checkWitness 2498 false false 72 = true := by decide +kernel
private theorem w2498_2 : checkWitness 2498 true false 72 = true := by decide +kernel
private theorem cases2498 : checkFour 2498 (72,0,72,0) = true := by
  simp only [checkFour, w2498_0, w2498_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2498 : Coverage 2498 2499 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2498)
private theorem w2499_0 : checkWitness 2499 false false 64 = true := by decide +kernel
private theorem w2499_2 : checkWitness 2499 true false 64 = true := by decide +kernel
private theorem cases2499 : checkFour 2499 (64,0,64,0) = true := by
  simp only [checkFour, w2499_0, w2499_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2499 : Coverage 2499 2500 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2499)
private theorem w2500_0 : checkWitness 2500 false false 653 = true := by decide +kernel
private theorem w2500_1 : checkWitness 2500 false true 4737 = true := by decide +kernel
private theorem w2500_2 : checkWitness 2500 true false 653 = true := by decide +kernel
private theorem w2500_3 : checkWitness 2500 true true 4737 = true := by decide +kernel
private theorem cases2500 : checkFour 2500 (653,4737,653,4737) = true := by
  simp only [checkFour, w2500_0, w2500_1, w2500_2, w2500_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2500 : Coverage 2500 2501 := checkList_sound (ws:=[(653,4737,653,4737)]) (by simpa only [checkList, Bool.and_true] using cases2500)
private theorem w2501_0 : checkWitness 2501 false false 8906 = true := by decide +kernel
private theorem w2501_2 : checkWitness 2501 true false 8902 = true := by decide +kernel
private theorem cases2501 : checkFour 2501 (8906,0,8902,0) = true := by
  simp only [checkFour, w2501_0, w2501_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2501 : Coverage 2501 2502 := checkList_sound (ws:=[(8906,0,8902,0)]) (by simpa only [checkList, Bool.and_true] using cases2501)
private theorem w2502_0 : checkWitness 2502 false false 64 = true := by decide +kernel
private theorem w2502_2 : checkWitness 2502 true false 64 = true := by decide +kernel
private theorem cases2502 : checkFour 2502 (64,0,64,0) = true := by
  simp only [checkFour, w2502_0, w2502_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2502 : Coverage 2502 2503 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2502)
private theorem w2503_0 : checkWitness 2503 false false 621 = true := by decide +kernel
private theorem w2503_1 : checkWitness 2503 false true 4717 = true := by decide +kernel
private theorem w2503_2 : checkWitness 2503 true false 621 = true := by decide +kernel
private theorem w2503_3 : checkWitness 2503 true true 4717 = true := by decide +kernel
private theorem cases2503 : checkFour 2503 (621,4717,621,4717) = true := by
  simp only [checkFour, w2503_0, w2503_1, w2503_2, w2503_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2503 : Coverage 2503 2504 := checkList_sound (ws:=[(621,4717,621,4717)]) (by simpa only [checkList, Bool.and_true] using cases2503)
private theorem w2504_0 : checkWitness 2504 false false 8974 = true := by decide +kernel
private theorem w2504_2 : checkWitness 2504 true false 8965 = true := by decide +kernel
private theorem cases2504 : checkFour 2504 (8974,0,8965,0) = true := by
  simp only [checkFour, w2504_0, w2504_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2504 : Coverage 2504 2505 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases2504)
private theorem w2505_0 : checkWitness 2505 false false 8920 = true := by decide +kernel
private theorem w2505_2 : checkWitness 2505 true false 8916 = true := by decide +kernel
private theorem cases2505 : checkFour 2505 (8920,0,8916,0) = true := by
  simp only [checkFour, w2505_0, w2505_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2505 : Coverage 2505 2506 := checkList_sound (ws:=[(8920,0,8916,0)]) (by simpa only [checkList, Bool.and_true] using cases2505)
private theorem w2506_0 : checkWitness 2506 false false 72 = true := by decide +kernel
private theorem w2506_2 : checkWitness 2506 true false 72 = true := by decide +kernel
private theorem cases2506 : checkFour 2506 (72,0,72,0) = true := by
  simp only [checkFour, w2506_0, w2506_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2506 : Coverage 2506 2507 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2506)
private theorem w2507_0 : checkWitness 2507 false false 704 = true := by decide +kernel
private theorem w2507_1 : checkWitness 2507 false true 4792 = true := by decide +kernel
private theorem w2507_2 : checkWitness 2507 true false 695 = true := by decide +kernel
private theorem w2507_3 : checkWitness 2507 true true 4783 = true := by decide +kernel
private theorem cases2507 : checkFour 2507 (704,4792,695,4783) = true := by
  simp only [checkFour, w2507_0, w2507_1, w2507_2, w2507_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2507 : Coverage 2507 2508 := checkList_sound (ws:=[(704,4792,695,4783)]) (by simpa only [checkList, Bool.and_true] using cases2507)
private theorem w2508_0 : checkWitness 2508 false false 8939 = true := by decide +kernel
private theorem w2508_2 : checkWitness 2508 true false 8935 = true := by decide +kernel
private theorem cases2508 : checkFour 2508 (8939,0,8935,0) = true := by
  simp only [checkFour, w2508_0, w2508_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2508 : Coverage 2508 2509 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2508)
private theorem w2509_0 : checkWitness 2509 false false 62 = true := by decide +kernel
private theorem w2509_2 : checkWitness 2509 true false 62 = true := by decide +kernel
private theorem cases2509 : checkFour 2509 (62,0,62,0) = true := by
  simp only [checkFour, w2509_0, w2509_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2509 : Coverage 2509 2510 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2509)
private theorem w2510_0 : checkWitness 2510 false false 570 = true := by decide +kernel
private theorem w2510_1 : checkWitness 2510 false true 4666 = true := by decide +kernel
private theorem w2510_2 : checkWitness 2510 true false 570 = true := by decide +kernel
private theorem w2510_3 : checkWitness 2510 true true 4666 = true := by decide +kernel
private theorem cases2510 : checkFour 2510 (570,4666,570,4666) = true := by
  simp only [checkFour, w2510_0, w2510_1, w2510_2, w2510_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2510 : Coverage 2510 2511 := checkList_sound (ws:=[(570,4666,570,4666)]) (by simpa only [checkList, Bool.and_true] using cases2510)
private theorem w2511_0 : checkWitness 2511 false false 8984 = true := by decide +kernel
private theorem w2511_2 : checkWitness 2511 true false 8975 = true := by decide +kernel
private theorem cases2511 : checkFour 2511 (8984,0,8975,0) = true := by
  simp only [checkFour, w2511_0, w2511_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2511 : Coverage 2511 2512 := checkList_sound (ws:=[(8984,0,8975,0)]) (by simpa only [checkList, Bool.and_true] using cases2511)
private theorem w2512_0 : checkWitness 2512 false false 64 = true := by decide +kernel
private theorem w2512_2 : checkWitness 2512 true false 64 = true := by decide +kernel
private theorem cases2512 : checkFour 2512 (64,0,64,0) = true := by
  simp only [checkFour, w2512_0, w2512_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2512 : Coverage 2512 2513 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2512)
private theorem w2513_0 : checkWitness 2513 false false 566 = true := by decide +kernel
private theorem w2513_1 : checkWitness 2513 false true 4662 = true := by decide +kernel
private theorem w2513_2 : checkWitness 2513 true false 566 = true := by decide +kernel
private theorem w2513_3 : checkWitness 2513 true true 4662 = true := by decide +kernel
private theorem cases2513 : checkFour 2513 (566,4662,566,4662) = true := by
  simp only [checkFour, w2513_0, w2513_1, w2513_2, w2513_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2513 : Coverage 2513 2514 := checkList_sound (ws:=[(566,4662,566,4662)]) (by simpa only [checkList, Bool.and_true] using cases2513)
private theorem w2514_0 : checkWitness 2514 false false 8924 = true := by decide +kernel
private theorem w2514_2 : checkWitness 2514 true false 8920 = true := by decide +kernel
private theorem cases2514 : checkFour 2514 (8924,0,8920,0) = true := by
  simp only [checkFour, w2514_0, w2514_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2514 : Coverage 2514 2515 := checkList_sound (ws:=[(8924,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases2514)
private theorem w2515_0 : checkWitness 2515 false false 66 = true := by decide +kernel
private theorem w2515_2 : checkWitness 2515 true false 66 = true := by decide +kernel
private theorem cases2515 : checkFour 2515 (66,0,66,0) = true := by
  simp only [checkFour, w2515_0, w2515_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2515 : Coverage 2515 2516 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2515)
private theorem w2516_0 : checkWitness 2516 false false 610 = true := by decide +kernel
private theorem w2516_1 : checkWitness 2516 false true 4706 = true := by decide +kernel
private theorem w2516_2 : checkWitness 2516 true false 610 = true := by decide +kernel
private theorem w2516_3 : checkWitness 2516 true true 4706 = true := by decide +kernel
private theorem cases2516 : checkFour 2516 (610,4706,610,4706) = true := by
  simp only [checkFour, w2516_0, w2516_1, w2516_2, w2516_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2516 : Coverage 2516 2517 := checkList_sound (ws:=[(610,4706,610,4706)]) (by simpa only [checkList, Bool.and_true] using cases2516)
private theorem w2517_0 : checkWitness 2517 false false 8945 = true := by decide +kernel
private theorem w2517_2 : checkWitness 2517 true false 8941 = true := by decide +kernel
private theorem cases2517 : checkFour 2517 (8945,0,8941,0) = true := by
  simp only [checkFour, w2517_0, w2517_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2517 : Coverage 2517 2518 := checkList_sound (ws:=[(8945,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2517)
private theorem w2518_0 : checkWitness 2518 false false 8980 = true := by decide +kernel
private theorem w2518_2 : checkWitness 2518 true false 8971 = true := by decide +kernel
private theorem cases2518 : checkFour 2518 (8980,0,8971,0) = true := by
  simp only [checkFour, w2518_0, w2518_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2518 : Coverage 2518 2519 := checkList_sound (ws:=[(8980,0,8971,0)]) (by simpa only [checkList, Bool.and_true] using cases2518)
private theorem w2519_0 : checkWitness 2519 false false 90 = true := by decide +kernel
private theorem w2519_2 : checkWitness 2519 true false 90 = true := by decide +kernel
private theorem cases2519 : checkFour 2519 (90,0,90,0) = true := by
  simp only [checkFour, w2519_0, w2519_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2519 : Coverage 2519 2520 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases2519)
private theorem w2520_0 : checkWitness 2520 false false 692 = true := by decide +kernel
private theorem w2520_1 : checkWitness 2520 false true 4784 = true := by decide +kernel
private theorem w2520_2 : checkWitness 2520 true false 683 = true := by decide +kernel
private theorem w2520_3 : checkWitness 2520 true true 4775 = true := by decide +kernel
private theorem cases2520 : checkFour 2520 (692,4784,683,4775) = true := by
  simp only [checkFour, w2520_0, w2520_1, w2520_2, w2520_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2520 : Coverage 2520 2521 := checkList_sound (ws:=[(692,4784,683,4775)]) (by simpa only [checkList, Bool.and_true] using cases2520)
private theorem w2521_0 : checkWitness 2521 false false 8941 = true := by decide +kernel
private theorem w2521_2 : checkWitness 2521 true false 8937 = true := by decide +kernel
private theorem cases2521 : checkFour 2521 (8941,0,8937,0) = true := by
  simp only [checkFour, w2521_0, w2521_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2521 : Coverage 2521 2522 := checkList_sound (ws:=[(8941,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases2521)
private theorem w2522_0 : checkWitness 2522 false false 686 = true := by decide +kernel
private theorem w2522_1 : checkWitness 2522 false true 4778 = true := by decide +kernel
private theorem w2522_2 : checkWitness 2522 true false 677 = true := by decide +kernel
private theorem w2522_3 : checkWitness 2522 true true 4769 = true := by decide +kernel
private theorem cases2522 : checkFour 2522 (686,4778,677,4769) = true := by
  simp only [checkFour, w2522_0, w2522_1, w2522_2, w2522_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2522 : Coverage 2522 2523 := checkList_sound (ws:=[(686,4778,677,4769)]) (by simpa only [checkList, Bool.and_true] using cases2522)
private theorem w2523_0 : checkWitness 2523 false false 8910 = true := by decide +kernel
private theorem w2523_2 : checkWitness 2523 true false 8906 = true := by decide +kernel
private theorem cases2523 : checkFour 2523 (8910,0,8906,0) = true := by
  simp only [checkFour, w2523_0, w2523_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2523 : Coverage 2523 2524 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2523)
private theorem w2524_0 : checkWitness 2524 false false 78 = true := by decide +kernel
private theorem w2524_2 : checkWitness 2524 true false 78 = true := by decide +kernel
private theorem cases2524 : checkFour 2524 (78,0,78,0) = true := by
  simp only [checkFour, w2524_0, w2524_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2524 : Coverage 2524 2525 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2524)
private theorem w2525_0 : checkWitness 2525 false false 70 = true := by decide +kernel
private theorem w2525_2 : checkWitness 2525 true false 70 = true := by decide +kernel
private theorem cases2525 : checkFour 2525 (70,0,70,0) = true := by
  simp only [checkFour, w2525_0, w2525_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2525 : Coverage 2525 2526 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2525)
private theorem w2526_0 : checkWitness 2526 false false 651 = true := by decide +kernel
private theorem w2526_1 : checkWitness 2526 false true 4735 = true := by decide +kernel
private theorem w2526_2 : checkWitness 2526 true false 651 = true := by decide +kernel
private theorem w2526_3 : checkWitness 2526 true true 4735 = true := by decide +kernel
private theorem cases2526 : checkFour 2526 (651,4735,651,4735) = true := by
  simp only [checkFour, w2526_0, w2526_1, w2526_2, w2526_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2526 : Coverage 2526 2527 := checkList_sound (ws:=[(651,4735,651,4735)]) (by simpa only [checkList, Bool.and_true] using cases2526)
private theorem w2527_0 : checkWitness 2527 false false 8904 = true := by decide +kernel
private theorem w2527_2 : checkWitness 2527 true false 8900 = true := by decide +kernel
private theorem cases2527 : checkFour 2527 (8904,0,8900,0) = true := by
  simp only [checkFour, w2527_0, w2527_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2527 : Coverage 2527 2528 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2527)
theorem cover2496 : Coverage 2496 2528 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2496 one2497) (Coverage.join one2498 one2499)) (Coverage.join (Coverage.join one2500 one2501) (Coverage.join one2502 one2503))) (Coverage.join (Coverage.join (Coverage.join one2504 one2505) (Coverage.join one2506 one2507)) (Coverage.join (Coverage.join one2508 one2509) (Coverage.join one2510 one2511)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2512 one2513) (Coverage.join one2514 one2515)) (Coverage.join (Coverage.join one2516 one2517) (Coverage.join one2518 one2519))) (Coverage.join (Coverage.join (Coverage.join one2520 one2521) (Coverage.join one2522 one2523)) (Coverage.join (Coverage.join one2524 one2525) (Coverage.join one2526 one2527)))))
end NF182PA.Symbolic
