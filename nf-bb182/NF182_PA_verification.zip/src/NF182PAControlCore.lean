module
public import ModelPackedCommands
public import Src182Reach
public import Mathlib.Tactic.Ring
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch.RegisterFields PA192.ModelSearch.RegisterCommands
set_option maxRecDepth 10000
set_option maxHeartbeats 3500000
namespace PA192.ModelSearch.Register182.Commands
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
/-- A source checkpoint where scratch coordinates R6 and R7 are clear. -/
noncomputable def atS (pc : Nat) (f n t s rank p h w : V) : V :=
  config (pc:V) f (vector n t s rank p h 0 0 w)
noncomputable def vm (pc : Nat) (f n e w : V) : V := atS pc f n (top e) (stack e) 0 (param e) (cache e) w

@[simp] theorem vm_state (pc : Nat) (f n t s h p w : V) : vm pc f n (state t s h p) w = atS pc f n t s 0 p h w := by
  simp [vm,top,stack,cache,param,state]

theorem zeroOrSuccessor (a : V) : a=0 ∨ ∃ j, a=j+1 := (eq_zero_or_pos a).imp_right eq_succ_of_pos

theorem pairUnpack (a : V) : cantor (left a) (right a)=a := inversePair_correct a

theorem pairUnpackTwo (raw : V) : cantor (left raw) (cantor (left (right raw)) (right (right raw)))=raw := by
  rw [pairUnpack,pairUnpack]

end PA192.ModelSearch.Register182.Commands
