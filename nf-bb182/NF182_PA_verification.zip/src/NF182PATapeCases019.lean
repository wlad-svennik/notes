import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w608_0 : checkWitness 608 false false 70 = true := by decide +kernel
private theorem w608_2 : checkWitness 608 true false 70 = true := by decide +kernel
private theorem cases608 : checkFour 608 (70,0,70,0) = true := by
  simp only [checkFour, w608_0, w608_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one608 : Coverage 608 609 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases608)
private theorem w609_0 : checkWitness 609 false false 546 = true := by decide +kernel
private theorem w609_1 : checkWitness 609 false true 4642 = true := by decide +kernel
private theorem w609_2 : checkWitness 609 true false 546 = true := by decide +kernel
private theorem w609_3 : checkWitness 609 true true 4642 = true := by decide +kernel
private theorem cases609 : checkFour 609 (546,4642,546,4642) = true := by
  simp only [checkFour, w609_0, w609_1, w609_2, w609_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one609 : Coverage 609 610 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases609)
private theorem w610_0 : checkWitness 610 false false 8968 = true := by decide +kernel
private theorem w610_2 : checkWitness 610 true false 8959 = true := by decide +kernel
private theorem cases610 : checkFour 610 (8968,0,8959,0) = true := by
  simp only [checkFour, w610_0, w610_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one610 : Coverage 610 611 := checkList_sound (ws:=[(8968,0,8959,0)]) (by simpa only [checkList, Bool.and_true] using cases610)
private theorem w611_0 : checkWitness 611 false false 72 = true := by decide +kernel
private theorem w611_2 : checkWitness 611 true false 72 = true := by decide +kernel
private theorem cases611 : checkFour 611 (72,0,72,0) = true := by
  simp only [checkFour, w611_0, w611_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one611 : Coverage 611 612 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases611)
private theorem w612_0 : checkWitness 612 false false 550 = true := by decide +kernel
private theorem w612_1 : checkWitness 612 false true 4646 = true := by decide +kernel
private theorem w612_2 : checkWitness 612 true false 550 = true := by decide +kernel
private theorem w612_3 : checkWitness 612 true true 4646 = true := by decide +kernel
private theorem cases612 : checkFour 612 (550,4646,550,4646) = true := by
  simp only [checkFour, w612_0, w612_1, w612_2, w612_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one612 : Coverage 612 613 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases612)
private theorem w613_0 : checkWitness 613 false false 8908 = true := by decide +kernel
private theorem w613_2 : checkWitness 613 true false 8904 = true := by decide +kernel
private theorem cases613 : checkFour 613 (8908,0,8904,0) = true := by
  simp only [checkFour, w613_0, w613_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one613 : Coverage 613 614 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases613)
private theorem w614_0 : checkWitness 614 false false 74 = true := by decide +kernel
private theorem w614_2 : checkWitness 614 true false 74 = true := by decide +kernel
private theorem cases614 : checkFour 614 (74,0,74,0) = true := by
  simp only [checkFour, w614_0, w614_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one614 : Coverage 614 615 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases614)
private theorem w615_0 : checkWitness 615 false false 594 = true := by decide +kernel
private theorem w615_1 : checkWitness 615 false true 4690 = true := by decide +kernel
private theorem w615_2 : checkWitness 615 true false 594 = true := by decide +kernel
private theorem w615_3 : checkWitness 615 true true 4690 = true := by decide +kernel
private theorem cases615 : checkFour 615 (594,4690,594,4690) = true := by
  simp only [checkFour, w615_0, w615_1, w615_2, w615_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one615 : Coverage 615 616 := checkList_sound (ws:=[(594,4690,594,4690)]) (by simpa only [checkList, Bool.and_true] using cases615)
private theorem w616_0 : checkWitness 616 false false 8929 = true := by decide +kernel
private theorem w616_2 : checkWitness 616 true false 8925 = true := by decide +kernel
private theorem cases616 : checkFour 616 (8929,0,8925,0) = true := by
  simp only [checkFour, w616_0, w616_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one616 : Coverage 616 617 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases616)
private theorem w617_0 : checkWitness 617 false false 8964 = true := by decide +kernel
private theorem w617_2 : checkWitness 617 true false 8955 = true := by decide +kernel
private theorem cases617 : checkFour 617 (8964,0,8955,0) = true := by
  simp only [checkFour, w617_0, w617_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one617 : Coverage 617 618 := checkList_sound (ws:=[(8964,0,8955,0)]) (by simpa only [checkList, Bool.and_true] using cases617)
private theorem w618_0 : checkWitness 618 false false 98 = true := by decide +kernel
private theorem w618_2 : checkWitness 618 true false 98 = true := by decide +kernel
private theorem cases618 : checkFour 618 (98,0,98,0) = true := by
  simp only [checkFour, w618_0, w618_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one618 : Coverage 618 619 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases618)
private theorem w619_0 : checkWitness 619 false false 676 = true := by decide +kernel
private theorem w619_1 : checkWitness 619 false true 4768 = true := by decide +kernel
private theorem w619_2 : checkWitness 619 true false 667 = true := by decide +kernel
private theorem w619_3 : checkWitness 619 true true 4759 = true := by decide +kernel
private theorem cases619 : checkFour 619 (676,4768,667,4759) = true := by
  simp only [checkFour, w619_0, w619_1, w619_2, w619_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one619 : Coverage 619 620 := checkList_sound (ws:=[(676,4768,667,4759)]) (by simpa only [checkList, Bool.and_true] using cases619)
private theorem w620_0 : checkWitness 620 false false 8925 = true := by decide +kernel
private theorem w620_2 : checkWitness 620 true false 8921 = true := by decide +kernel
private theorem cases620 : checkFour 620 (8925,0,8921,0) = true := by
  simp only [checkFour, w620_0, w620_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one620 : Coverage 620 621 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases620)
private theorem w621_0 : checkWitness 621 false false 670 = true := by decide +kernel
private theorem w621_1 : checkWitness 621 false true 4762 = true := by decide +kernel
private theorem w621_2 : checkWitness 621 true false 661 = true := by decide +kernel
private theorem w621_3 : checkWitness 621 true true 4753 = true := by decide +kernel
private theorem cases621 : checkFour 621 (670,4762,661,4753) = true := by
  simp only [checkFour, w621_0, w621_1, w621_2, w621_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one621 : Coverage 621 622 := checkList_sound (ws:=[(670,4762,661,4753)]) (by simpa only [checkList, Bool.and_true] using cases621)
private theorem w622_0 : checkWitness 622 false false 8894 = true := by decide +kernel
private theorem w622_2 : checkWitness 622 true false 8890 = true := by decide +kernel
private theorem cases622 : checkFour 622 (8894,0,8890,0) = true := by
  simp only [checkFour, w622_0, w622_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one622 : Coverage 622 623 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases622)
private theorem w623_0 : checkWitness 623 false false 86 = true := by decide +kernel
private theorem w623_2 : checkWitness 623 true false 86 = true := by decide +kernel
private theorem cases623 : checkFour 623 (86,0,86,0) = true := by
  simp only [checkFour, w623_0, w623_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one623 : Coverage 623 624 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases623)
private theorem w624_0 : checkWitness 624 false false 78 = true := by decide +kernel
private theorem w624_2 : checkWitness 624 true false 78 = true := by decide +kernel
private theorem cases624 : checkFour 624 (78,0,78,0) = true := by
  simp only [checkFour, w624_0, w624_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one624 : Coverage 624 625 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases624)
private theorem w625_0 : checkWitness 625 false false 635 = true := by decide +kernel
private theorem w625_1 : checkWitness 625 false true 4719 = true := by decide +kernel
private theorem w625_2 : checkWitness 625 true false 635 = true := by decide +kernel
private theorem w625_3 : checkWitness 625 true true 4719 = true := by decide +kernel
private theorem cases625 : checkFour 625 (635,4719,635,4719) = true := by
  simp only [checkFour, w625_0, w625_1, w625_2, w625_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one625 : Coverage 625 626 := checkList_sound (ws:=[(635,4719,635,4719)]) (by simpa only [checkList, Bool.and_true] using cases625)
private theorem w626_0 : checkWitness 626 false false 8888 = true := by decide +kernel
private theorem w626_2 : checkWitness 626 true false 8884 = true := by decide +kernel
private theorem cases626 : checkFour 626 (8888,0,8884,0) = true := by
  simp only [checkFour, w626_0, w626_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one626 : Coverage 626 627 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases626)
private theorem w627_0 : checkWitness 627 false false 78 = true := by decide +kernel
private theorem w627_2 : checkWitness 627 true false 78 = true := by decide +kernel
private theorem cases627 : checkFour 627 (78,0,78,0) = true := by
  simp only [checkFour, w627_0, w627_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one627 : Coverage 627 628 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases627)
private theorem w628_0 : checkWitness 628 false false 633 = true := by decide +kernel
private theorem w628_1 : checkWitness 628 false true 4725 = true := by decide +kernel
private theorem w628_2 : checkWitness 628 true false 624 = true := by decide +kernel
private theorem w628_3 : checkWitness 628 true true 4716 = true := by decide +kernel
private theorem cases628 : checkFour 628 (633,4725,624,4716) = true := by
  simp only [checkFour, w628_0, w628_1, w628_2, w628_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one628 : Coverage 628 629 := checkList_sound (ws:=[(633,4725,624,4716)]) (by simpa only [checkList, Bool.and_true] using cases628)
private theorem w629_0 : checkWitness 629 false false 8930 = true := by decide +kernel
private theorem w629_2 : checkWitness 629 true false 8921 = true := by decide +kernel
private theorem cases629 : checkFour 629 (8930,0,8921,0) = true := by
  simp only [checkFour, w629_0, w629_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one629 : Coverage 629 630 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases629)
private theorem w630_0 : checkWitness 630 false false 8876 = true := by decide +kernel
private theorem w630_2 : checkWitness 630 true false 8872 = true := by decide +kernel
private theorem cases630 : checkFour 630 (8876,0,8872,0) = true := by
  simp only [checkFour, w630_0, w630_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one630 : Coverage 630 631 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases630)
private theorem w631_0 : checkWitness 631 false false 72 = true := by decide +kernel
private theorem w631_2 : checkWitness 631 true false 72 = true := by decide +kernel
private theorem cases631 : checkFour 631 (72,0,72,0) = true := by
  simp only [checkFour, w631_0, w631_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one631 : Coverage 631 632 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases631)
private theorem w632_0 : checkWitness 632 false false 660 = true := by decide +kernel
private theorem w632_1 : checkWitness 632 false true 4752 = true := by decide +kernel
private theorem w632_2 : checkWitness 632 true false 651 = true := by decide +kernel
private theorem w632_3 : checkWitness 632 true true 4743 = true := by decide +kernel
private theorem cases632 : checkFour 632 (660,4752,651,4743) = true := by
  simp only [checkFour, w632_0, w632_1, w632_2, w632_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one632 : Coverage 632 633 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases632)
private theorem w633_0 : checkWitness 633 false false 8937 = true := by decide +kernel
private theorem w633_2 : checkWitness 633 true false 8928 = true := by decide +kernel
private theorem cases633 : checkFour 633 (8937,0,8928,0) = true := by
  simp only [checkFour, w633_0, w633_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one633 : Coverage 633 634 := checkList_sound (ws:=[(8937,0,8928,0)]) (by simpa only [checkList, Bool.and_true] using cases633)
private theorem w634_0 : checkWitness 634 false false 56 = true := by decide +kernel
private theorem w634_2 : checkWitness 634 true false 56 = true := by decide +kernel
private theorem cases634 : checkFour 634 (56,0,56,0) = true := by
  simp only [checkFour, w634_0, w634_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one634 : Coverage 634 635 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases634)
private theorem w635_0 : checkWitness 635 false false 524 = true := by decide +kernel
private theorem w635_1 : checkWitness 635 false true 4620 = true := by decide +kernel
private theorem w635_2 : checkWitness 635 true false 524 = true := by decide +kernel
private theorem w635_3 : checkWitness 635 true true 4620 = true := by decide +kernel
private theorem cases635 : checkFour 635 (524,4620,524,4620) = true := by
  simp only [checkFour, w635_0, w635_1, w635_2, w635_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one635 : Coverage 635 636 := checkList_sound (ws:=[(524,4620,524,4620)]) (by simpa only [checkList, Bool.and_true] using cases635)
private theorem w636_0 : checkWitness 636 false false 8919 = true := by decide +kernel
private theorem w636_2 : checkWitness 636 true false 8915 = true := by decide +kernel
private theorem cases636 : checkFour 636 (8919,0,8915,0) = true := by
  simp only [checkFour, w636_0, w636_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one636 : Coverage 636 637 := checkList_sound (ws:=[(8919,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases636)
private theorem w637_0 : checkWitness 637 false false 650 = true := by decide +kernel
private theorem w637_1 : checkWitness 637 false true 4746 = true := by decide +kernel
private theorem w637_2 : checkWitness 637 true false 641 = true := by decide +kernel
private theorem w637_3 : checkWitness 637 true true 4737 = true := by decide +kernel
private theorem cases637 : checkFour 637 (650,4746,641,4737) = true := by
  simp only [checkFour, w637_0, w637_1, w637_2, w637_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one637 : Coverage 637 638 := checkList_sound (ws:=[(650,4746,641,4737)]) (by simpa only [checkList, Bool.and_true] using cases637)
private theorem w638_0 : checkWitness 638 false false 190 = true := by decide +kernel
private theorem w638_2 : checkWitness 638 true false 190 = true := by decide +kernel
private theorem cases638 : checkFour 638 (190,0,190,0) = true := by
  simp only [checkFour, w638_0, w638_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one638 : Coverage 638 639 := checkList_sound (ws:=[(190,0,190,0)]) (by simpa only [checkList, Bool.and_true] using cases638)
private theorem w639_0 : checkWitness 639 false false 605 = true := by decide +kernel
private theorem w639_1 : checkWitness 639 false true 4693 = true := by decide +kernel
private theorem w639_2 : checkWitness 639 true false 605 = true := by decide +kernel
private theorem w639_3 : checkWitness 639 true true 4693 = true := by decide +kernel
private theorem cases639 : checkFour 639 (605,4693,605,4693) = true := by
  simp only [checkFour, w639_0, w639_1, w639_2, w639_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one639 : Coverage 639 640 := checkList_sound (ws:=[(605,4693,605,4693)]) (by simpa only [checkList, Bool.and_true] using cases639)
theorem cover0608 : Coverage 608 640 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one608 one609) (Coverage.join one610 one611)) (Coverage.join (Coverage.join one612 one613) (Coverage.join one614 one615))) (Coverage.join (Coverage.join (Coverage.join one616 one617) (Coverage.join one618 one619)) (Coverage.join (Coverage.join one620 one621) (Coverage.join one622 one623)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one624 one625) (Coverage.join one626 one627)) (Coverage.join (Coverage.join one628 one629) (Coverage.join one630 one631))) (Coverage.join (Coverage.join (Coverage.join one632 one633) (Coverage.join one634 one635)) (Coverage.join (Coverage.join one636 one637) (Coverage.join one638 one639)))))
end NF182PA.Symbolic
