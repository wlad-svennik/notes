import PackageFacts
namespace NF192.Direct
universe u
variable {X : Type u}

def HasR (m : X→X→Prop) (D P C : X) (F : X→X→Prop) :=
  ∀x y,m x D ∧ m y D → (RelObj m D P C x y ↔ F x y)
def HasU (m : X→X→Prop) (D C : X) (F : X→Prop) :=
  ∀x,m x D → (m x C ↔ F x)

def HeadP (m : X→X→Prop) (D z P h x : X) :=
  (∃ y,m y D ∧ Tri m P x y h) ∨ (x=z ∧ ¬∃a b,m a D ∧ m b D ∧ Tri m P a b h)
def TailP (m : X→X→Prop) (D z P h y : X) :=
  (∃ x,m x D ∧ Tri m P x y h) ∨ (y=z ∧ ¬∃a b,m a D ∧ m b D ∧ Tri m P a b h)
def InvTailP (m : X→X→Prop) (D P b u : X) := ∃ x,m x D ∧ Tri m P x b u
def OrderP (m : X→X→Prop) (D S A a b : X) := ∃ k t,m k D ∧ m t D ∧ Edge m S k t ∧ Tri m A a t b

def ExtraAt (m : X→X→Prop) (D z S A P : X) :=
  BinaryObject m D P (HeadP m D z P) ∧ BinaryObject m D P (TailP m D z P) ∧
  BinaryObject m D P (InvTailP m D P) ∧ BinaryObject m D P (OrderP m D S A)
end NF192.Direct
