module
public import DefinableQuotient
public import Foundation.FirstOrder.Arithmetic.Bootstrapping.Syntax.Proof.Basic

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding

namespace PA192.NativeTruth
open PA192.Numerals.FoundationRoute

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
variable {L : Language} [L.Encodable] [L.LORDefinable] (T : Theory L) [T.Δ₁]

/-- Closed-bound formulas may still have free variables. Assignments are coded
numbers of the ambient PA model. The target object domain may be a definable
quotient. The quantifier laws are in substitution form, exactly as in native LK2. -/
structure Truth (V : Type) [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] where
  OK : V → Prop
  dom : V → Prop
  tr : V → V → Prop
  push : V → V → V
  drop : V → V
  defOK : Language.DefinablePred ℒₒᵣ OK
  defTr : Language.DefinableRel ℒₒᵣ tr
  inhabited : ∃ f, OK f
  pushOK : ∀{x f}, dom x → OK f → OK (push x f)
  dropOK : ∀{f}, OK f → OK (drop f)
  top : ∀{f}, OK f → tr f qqVerum
  bot : ∀{f}, OK f → ¬tr f qqFalsum
  neg : ∀{f p}, OK f → IsFormula L p → (tr f (Bootstrapping.neg L p) ↔ ¬tr f p)
  conj : ∀{f p q}, OK f → IsFormula L (qqAnd p q) → tr f p → tr f q → tr f (qqAnd p q)
  disj : ∀{f p q}, OK f → IsFormula L (qqOr p q) → (tr f p ∨ tr f q) → tr f (qqOr p q)
  all : ∀{f p}, OK f → IsFormula L (qqAll p) →
         (∀ x, dom x → tr (push x f) (free L p)) → tr f (qqAll p)
  exs : ∀{f p t}, OK f → IsFormula L (qqExs p) → IsTerm L t →
         tr f (substs1 L t p) → tr f (qqExs p)
  shiftPush : ∀{f x p}, OK f → dom x → IsFormula L p →
         tr (push x f) (shift L p) → tr f p
  shiftDrop : ∀{f p}, OK f → IsFormula L p → tr (drop f) p → tr f (shift L p)
  axiomTrue : ∀{f p}, OK f → p∈T.Δ₁Class → tr f p

namespace Truth
variable {T} (S : Truth T V)

def Meets (f s : V) : Prop := ∃ p, p∈s ∧ S.tr f p
def Valid (s : V) : Prop := ∀ f, S.OK f → S.Meets f s

private instance meetsDef : Language.DefinableRel ℒₒᵣ S.Meets := by
  let _ := S.defTr
  unfold Meets
  definability
private instance validDef : Language.DefinablePred ℒₒᵣ S.Valid := by
  let _ := S.defOK
  unfold Valid
  definability

theorem meets_insert {s p f : V} : S.Meets f (insert p s) ↔ S.tr f p ∨ S.Meets f s := by
  constructor
  · rintro ⟨q,hq,tq⟩
    rcases mem_bitInsert_iff.mp hq with rfl | hq
    · exact Or.inl tq
    · exact Or.inr ⟨q,hq,tq⟩
  · rintro (tp | ⟨q,hq,tq⟩)
    · exact ⟨p,by simp,tp⟩
    · exact ⟨q,by simp [hq],tq⟩

theorem valid_step {d : V} (hd : Derivation T d)
    (ih : ∀ u<d, Derivation T u → S.Valid (fstIdx u)) : S.Valid (fstIdx d) := by
  classical
  obtain ⟨ds,cases⟩ := Derivation.case_iff.mp hd
  rcases cases with ⟨s,p,rfl,hm,hn⟩ | ⟨s,rfl,hv⟩ | ⟨s,p,q,a,b,rfl,hpq,ha,hb⟩ |
    ⟨s,p,q,a,rfl,hpq,ha⟩ | ⟨s,p,a,rfl,hp,ha⟩ | ⟨s,p,t,a,rfl,hp,ht,ha⟩ |
    ⟨s,a,rfl,hs,ha⟩ | ⟨s,a,rfl,rfl,ha⟩ | ⟨s,p,a,b,rfl,ha,hb⟩ | ⟨s,p,rfl,hp,hT⟩
  all_goals simp only [fstIdx_axL,fstIdx_verumIntro,fstIdx_andIntro,fstIdx_orIntro,
    fstIdx_allIntro,fstIdx_exsIntro,fstIdx_wkRule,fstIdx_shiftRule,fstIdx_cutRule,fstIdx_axm] at ds ⊢
  all_goals intro f hf
  · by_cases tp : S.tr f p
    · exact ⟨p,hm,tp⟩
    · exact ⟨_,hn,(S.neg hf (ds _ hm)).mpr tp⟩
  · exact ⟨_,hv,S.top hf⟩
  · by_contra no
    have va := ih a (by simp) ha.2 f hf
    have vb := ih b (by simp) hb.2 f hf
    rw [ha.1,S.meets_insert] at va
    rw [hb.1,S.meets_insert] at vb
    exact no ⟨_,hpq,S.conj hf (ds _ hpq) (va.resolve_right no) (vb.resolve_right no)⟩
  · by_contra no
    have va := ih a (by simp) ha.2 f hf
    rw [ha.1,S.meets_insert,S.meets_insert] at va
    exact no ⟨_,hpq,S.disj hf (ds _ hpq) (va.elim Or.inl (fun h=>Or.inr (h.resolve_right no)))⟩
  · by_contra no
    apply no
    refine ⟨_,hp,S.all hf (ds _ hp) ?_⟩
    intro x hx
    have va := ih a (by simp) ha.2 (S.push x f) (S.pushOK hx hf)
    rw [ha.1,S.meets_insert] at va
    apply va.resolve_right
    rintro ⟨q,hq,tq⟩
    obtain ⟨p,hp,rfl⟩ := mem_setShift_iff.mp hq
    exact no ⟨p,hp,S.shiftPush hf hx (ds _ hp) tq⟩
  · by_contra no
    have va := ih a (by simp) ha.2 f hf
    rw [ha.1,S.meets_insert] at va
    exact no ⟨_,hp,S.exs hf (ds _ hp) ht (va.resolve_right no)⟩
  · obtain ⟨p,hp,tp⟩ := ih a (by simp) ha f hf
    exact ⟨p,hs hp,tp⟩
  · obtain ⟨p,hp,tp⟩ := ih a (by simp) ha (S.drop f) (S.dropOK hf)
    exact ⟨_,shift_mem_setShift hp,S.shiftDrop hf (ha.isFormulaSet _ hp) tp⟩
  · by_contra no
    have va := ih a (by simp) ha.2 f hf
    have vb := ih b (by simp) hb.2 f hf
    rw [ha.1,S.meets_insert] at va
    rw [hb.1,S.meets_insert] at vb
    have wf : IsFormula L p := ha.isFormulaSet p (by simp)
    exact (S.neg hf wf).mp (vb.resolve_right no) (va.resolve_right no)
  · exact ⟨p,hp,S.axiomTrue hf hT⟩

private instance derivDef : Language.DefinablePred ℒₒᵣ (Derivation T : V → Prop) :=
  FFL.FirstOrder.Defined.to_definable (φ:=(derivation T).val) ⟨(Derivation.defined (T:=T) (V:=V)).df⟩
private instance idxDef : Language.DefinableFunction₁ ℒₒᵣ (fstIdx : V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ:=fstIdxDef.val) ⟨(fstIdx_defined (V:=V)).df⟩

def Bad (d : V) := Derivation T d ∧ ¬S.Valid (fstIdx d)
private instance badDef : Language.DefinablePred ℒₒᵣ S.Bad := by unfold Bad; definability

/-- All-model soundness needs induction for one generally unbounded arithmetic
formula. Choosing a least counterexample uses the PA scheme in the ambient
number model and does not presuppose external well-foundedness of its order. -/
theorem sound {d : V} (hd : Derivation T d) : S.Valid (fstIdx d) := by
  classical
  by_contra no
  obtain ⟨u,⟨hu,fail⟩,least⟩ := least_plain S.Bad (x:=d) ⟨hd,no⟩
  apply fail
  apply S.valid_step hu
  intro j hj good
  by_contra bad
  exact least j hj ⟨good,bad⟩

include S in
theorem no_refutation : ¬Provable T (qqFalsum : V) := by
  rintro ⟨d,he,hd⟩
  have good := S.sound hd
  rw [he] at good
  obtain ⟨f,hf⟩ := S.inhabited
  obtain ⟨p,hp,tp⟩ := good f hf
  obtain rfl := mem_singleton_iff.mp hp
  exact S.bot hf tp

end Truth
end PA192.NativeTruth

#print axioms PA192.NativeTruth.Truth.no_refutation
