import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w768_0 : checkWitness 768 false false 546 = true := by decide +kernel
private theorem w768_1 : checkWitness 768 false true 4642 = true := by decide +kernel
private theorem w768_2 : checkWitness 768 true false 546 = true := by decide +kernel
private theorem w768_3 : checkWitness 768 true true 4642 = true := by decide +kernel
private theorem cases768 : checkFour 768 (546,4642,546,4642) = true := by
  simp only [checkFour, w768_0, w768_1, w768_2, w768_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one768 : Coverage 768 769 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases768)
private theorem w769_0 : checkWitness 769 false false 8904 = true := by decide +kernel
private theorem w769_2 : checkWitness 769 true false 8900 = true := by decide +kernel
private theorem cases769 : checkFour 769 (8904,0,8900,0) = true := by
  simp only [checkFour, w769_0, w769_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one769 : Coverage 769 770 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases769)
private theorem w770_0 : checkWitness 770 false false 76 = true := by decide +kernel
private theorem w770_2 : checkWitness 770 true false 76 = true := by decide +kernel
private theorem cases770 : checkFour 770 (76,0,76,0) = true := by
  simp only [checkFour, w770_0, w770_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one770 : Coverage 770 771 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases770)
private theorem w771_0 : checkWitness 771 false false 590 = true := by decide +kernel
private theorem w771_1 : checkWitness 771 false true 4686 = true := by decide +kernel
private theorem w771_2 : checkWitness 771 true false 590 = true := by decide +kernel
private theorem w771_3 : checkWitness 771 true true 4686 = true := by decide +kernel
private theorem cases771 : checkFour 771 (590,4686,590,4686) = true := by
  simp only [checkFour, w771_0, w771_1, w771_2, w771_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one771 : Coverage 771 772 := checkList_sound (ws:=[(590,4686,590,4686)]) (by simpa only [checkList, Bool.and_true] using cases771)
private theorem w772_0 : checkWitness 772 false false 8925 = true := by decide +kernel
private theorem w772_2 : checkWitness 772 true false 8921 = true := by decide +kernel
private theorem cases772 : checkFour 772 (8925,0,8921,0) = true := by
  simp only [checkFour, w772_0, w772_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one772 : Coverage 772 773 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases772)
private theorem w773_0 : checkWitness 773 false false 8960 = true := by decide +kernel
private theorem w773_2 : checkWitness 773 true false 8951 = true := by decide +kernel
private theorem cases773 : checkFour 773 (8960,0,8951,0) = true := by
  simp only [checkFour, w773_0, w773_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one773 : Coverage 773 774 := checkList_sound (ws:=[(8960,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases773)
private theorem w774_0 : checkWitness 774 false false 100 = true := by decide +kernel
private theorem w774_2 : checkWitness 774 true false 100 = true := by decide +kernel
private theorem cases774 : checkFour 774 (100,0,100,0) = true := by
  simp only [checkFour, w774_0, w774_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one774 : Coverage 774 775 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases774)
private theorem w775_0 : checkWitness 775 false false 672 = true := by decide +kernel
private theorem w775_1 : checkWitness 775 false true 4764 = true := by decide +kernel
private theorem w775_2 : checkWitness 775 true false 663 = true := by decide +kernel
private theorem w775_3 : checkWitness 775 true true 4755 = true := by decide +kernel
private theorem cases775 : checkFour 775 (672,4764,663,4755) = true := by
  simp only [checkFour, w775_0, w775_1, w775_2, w775_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one775 : Coverage 775 776 := checkList_sound (ws:=[(672,4764,663,4755)]) (by simpa only [checkList, Bool.and_true] using cases775)
private theorem w776_0 : checkWitness 776 false false 8921 = true := by decide +kernel
private theorem w776_2 : checkWitness 776 true false 8917 = true := by decide +kernel
private theorem cases776 : checkFour 776 (8921,0,8917,0) = true := by
  simp only [checkFour, w776_0, w776_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one776 : Coverage 776 777 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases776)
private theorem w777_0 : checkWitness 777 false false 666 = true := by decide +kernel
private theorem w777_1 : checkWitness 777 false true 4758 = true := by decide +kernel
private theorem w777_2 : checkWitness 777 true false 657 = true := by decide +kernel
private theorem w777_3 : checkWitness 777 true true 4749 = true := by decide +kernel
private theorem cases777 : checkFour 777 (666,4758,657,4749) = true := by
  simp only [checkFour, w777_0, w777_1, w777_2, w777_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one777 : Coverage 777 778 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases777)
private theorem w778_0 : checkWitness 778 false false 8890 = true := by decide +kernel
private theorem w778_2 : checkWitness 778 true false 8886 = true := by decide +kernel
private theorem cases778 : checkFour 778 (8890,0,8886,0) = true := by
  simp only [checkFour, w778_0, w778_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one778 : Coverage 778 779 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases778)
private theorem w779_0 : checkWitness 779 false false 88 = true := by decide +kernel
private theorem w779_2 : checkWitness 779 true false 88 = true := by decide +kernel
private theorem cases779 : checkFour 779 (88,0,88,0) = true := by
  simp only [checkFour, w779_0, w779_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one779 : Coverage 779 780 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases779)
private theorem w780_0 : checkWitness 780 false false 80 = true := by decide +kernel
private theorem w780_2 : checkWitness 780 true false 80 = true := by decide +kernel
private theorem cases780 : checkFour 780 (80,0,80,0) = true := by
  simp only [checkFour, w780_0, w780_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one780 : Coverage 780 781 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases780)
private theorem w781_0 : checkWitness 781 false false 631 = true := by decide +kernel
private theorem w781_1 : checkWitness 781 false true 4715 = true := by decide +kernel
private theorem w781_2 : checkWitness 781 true false 631 = true := by decide +kernel
private theorem w781_3 : checkWitness 781 true true 4715 = true := by decide +kernel
private theorem cases781 : checkFour 781 (631,4715,631,4715) = true := by
  simp only [checkFour, w781_0, w781_1, w781_2, w781_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one781 : Coverage 781 782 := checkList_sound (ws:=[(631,4715,631,4715)]) (by simpa only [checkList, Bool.and_true] using cases781)
private theorem w782_0 : checkWitness 782 false false 8884 = true := by decide +kernel
private theorem w782_2 : checkWitness 782 true false 8880 = true := by decide +kernel
private theorem cases782 : checkFour 782 (8884,0,8880,0) = true := by
  simp only [checkFour, w782_0, w782_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one782 : Coverage 782 783 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases782)
private theorem w783_0 : checkWitness 783 false false 80 = true := by decide +kernel
private theorem w783_2 : checkWitness 783 true false 80 = true := by decide +kernel
private theorem cases783 : checkFour 783 (80,0,80,0) = true := by
  simp only [checkFour, w783_0, w783_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one783 : Coverage 783 784 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases783)
private theorem w784_0 : checkWitness 784 false false 629 = true := by decide +kernel
private theorem w784_1 : checkWitness 784 false true 4721 = true := by decide +kernel
private theorem w784_2 : checkWitness 784 true false 620 = true := by decide +kernel
private theorem w784_3 : checkWitness 784 true true 4712 = true := by decide +kernel
private theorem cases784 : checkFour 784 (629,4721,620,4712) = true := by
  simp only [checkFour, w784_0, w784_1, w784_2, w784_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one784 : Coverage 784 785 := checkList_sound (ws:=[(629,4721,620,4712)]) (by simpa only [checkList, Bool.and_true] using cases784)
private theorem w785_0 : checkWitness 785 false false 8926 = true := by decide +kernel
private theorem w785_2 : checkWitness 785 true false 8917 = true := by decide +kernel
private theorem cases785 : checkFour 785 (8926,0,8917,0) = true := by
  simp only [checkFour, w785_0, w785_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one785 : Coverage 785 786 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases785)
private theorem w786_0 : checkWitness 786 false false 8872 = true := by decide +kernel
private theorem w786_2 : checkWitness 786 true false 8868 = true := by decide +kernel
private theorem cases786 : checkFour 786 (8872,0,8868,0) = true := by
  simp only [checkFour, w786_0, w786_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one786 : Coverage 786 787 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases786)
private theorem w787_0 : checkWitness 787 false false 74 = true := by decide +kernel
private theorem w787_2 : checkWitness 787 true false 74 = true := by decide +kernel
private theorem cases787 : checkFour 787 (74,0,74,0) = true := by
  simp only [checkFour, w787_0, w787_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one787 : Coverage 787 788 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases787)
private theorem w788_0 : checkWitness 788 false false 656 = true := by decide +kernel
private theorem w788_1 : checkWitness 788 false true 4748 = true := by decide +kernel
private theorem w788_2 : checkWitness 788 true false 647 = true := by decide +kernel
private theorem w788_3 : checkWitness 788 true true 4739 = true := by decide +kernel
private theorem cases788 : checkFour 788 (656,4748,647,4739) = true := by
  simp only [checkFour, w788_0, w788_1, w788_2, w788_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one788 : Coverage 788 789 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases788)
private theorem w789_0 : checkWitness 789 false false 8933 = true := by decide +kernel
private theorem w789_2 : checkWitness 789 true false 8924 = true := by decide +kernel
private theorem cases789 : checkFour 789 (8933,0,8924,0) = true := by
  simp only [checkFour, w789_0, w789_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one789 : Coverage 789 790 := checkList_sound (ws:=[(8933,0,8924,0)]) (by simpa only [checkList, Bool.and_true] using cases789)
private theorem w790_0 : checkWitness 790 false false 58 = true := by decide +kernel
private theorem w790_2 : checkWitness 790 true false 58 = true := by decide +kernel
private theorem cases790 : checkFour 790 (58,0,58,0) = true := by
  simp only [checkFour, w790_0, w790_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one790 : Coverage 790 791 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases790)
private theorem w791_0 : checkWitness 791 false false 520 = true := by decide +kernel
private theorem w791_1 : checkWitness 791 false true 4616 = true := by decide +kernel
private theorem w791_2 : checkWitness 791 true false 520 = true := by decide +kernel
private theorem w791_3 : checkWitness 791 true true 4616 = true := by decide +kernel
private theorem cases791 : checkFour 791 (520,4616,520,4616) = true := by
  simp only [checkFour, w791_0, w791_1, w791_2, w791_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one791 : Coverage 791 792 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases791)
private theorem w792_0 : checkWitness 792 false false 8915 = true := by decide +kernel
private theorem w792_2 : checkWitness 792 true false 8911 = true := by decide +kernel
private theorem cases792 : checkFour 792 (8915,0,8911,0) = true := by
  simp only [checkFour, w792_0, w792_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one792 : Coverage 792 793 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases792)
private theorem w793_0 : checkWitness 793 false false 646 = true := by decide +kernel
private theorem w793_1 : checkWitness 793 false true 4742 = true := by decide +kernel
private theorem w793_2 : checkWitness 793 true false 637 = true := by decide +kernel
private theorem w793_3 : checkWitness 793 true true 4733 = true := by decide +kernel
private theorem cases793 : checkFour 793 (646,4742,637,4733) = true := by
  simp only [checkFour, w793_0, w793_1, w793_2, w793_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one793 : Coverage 793 794 := checkList_sound (ws:=[(646,4742,637,4733)]) (by simpa only [checkList, Bool.and_true] using cases793)
private theorem w794_0 : checkWitness 794 false false 188 = true := by decide +kernel
private theorem w794_2 : checkWitness 794 true false 188 = true := by decide +kernel
private theorem cases794 : checkFour 794 (188,0,188,0) = true := by
  simp only [checkFour, w794_0, w794_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one794 : Coverage 794 795 := checkList_sound (ws:=[(188,0,188,0)]) (by simpa only [checkList, Bool.and_true] using cases794)
private theorem w795_0 : checkWitness 795 false false 601 = true := by decide +kernel
private theorem w795_1 : checkWitness 795 false true 4689 = true := by decide +kernel
private theorem w795_2 : checkWitness 795 true false 601 = true := by decide +kernel
private theorem w795_3 : checkWitness 795 true true 4689 = true := by decide +kernel
private theorem cases795 : checkFour 795 (601,4689,601,4689) = true := by
  simp only [checkFour, w795_0, w795_1, w795_2, w795_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one795 : Coverage 795 796 := checkList_sound (ws:=[(601,4689,601,4689)]) (by simpa only [checkList, Bool.and_true] using cases795)
private theorem w796_0 : checkWitness 796 false false 8930 = true := by decide +kernel
private theorem w796_2 : checkWitness 796 true false 8921 = true := by decide +kernel
private theorem cases796 : checkFour 796 (8930,0,8921,0) = true := by
  simp only [checkFour, w796_0, w796_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one796 : Coverage 796 797 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases796)
private theorem w797_0 : checkWitness 797 false false 76 = true := by decide +kernel
private theorem w797_2 : checkWitness 797 true false 76 = true := by decide +kernel
private theorem cases797 : checkFour 797 (76,0,76,0) = true := by
  simp only [checkFour, w797_0, w797_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one797 : Coverage 797 798 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases797)
private theorem w798_0 : checkWitness 798 false false 68 = true := by decide +kernel
private theorem w798_2 : checkWitness 798 true false 68 = true := by decide +kernel
private theorem cases798 : checkFour 798 (68,0,68,0) = true := by
  simp only [checkFour, w798_0, w798_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one798 : Coverage 798 799 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases798)
private theorem w799_0 : checkWitness 799 false false 607 = true := by decide +kernel
private theorem w799_1 : checkWitness 799 false true 4699 = true := by decide +kernel
private theorem w799_2 : checkWitness 799 true false 607 = true := by decide +kernel
private theorem w799_3 : checkWitness 799 true true 4699 = true := by decide +kernel
private theorem cases799 : checkFour 799 (607,4699,607,4699) = true := by
  simp only [checkFour, w799_0, w799_1, w799_2, w799_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one799 : Coverage 799 800 := checkList_sound (ws:=[(607,4699,607,4699)]) (by simpa only [checkList, Bool.and_true] using cases799)
theorem cover0768 : Coverage 768 800 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one768 one769) (Coverage.join one770 one771)) (Coverage.join (Coverage.join one772 one773) (Coverage.join one774 one775))) (Coverage.join (Coverage.join (Coverage.join one776 one777) (Coverage.join one778 one779)) (Coverage.join (Coverage.join one780 one781) (Coverage.join one782 one783)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one784 one785) (Coverage.join one786 one787)) (Coverage.join (Coverage.join one788 one789) (Coverage.join one790 one791))) (Coverage.join (Coverage.join (Coverage.join one792 one793) (Coverage.join one794 one795)) (Coverage.join (Coverage.join one796 one797) (Coverage.join one798 one799)))))
end NF182PA.Symbolic
