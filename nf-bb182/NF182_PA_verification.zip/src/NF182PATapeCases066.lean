import NF182PATapeBatchCheck
namespace NF182PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2112_0 : checkWitness 2112 false false 676 = true := by decide +kernel
private theorem w2112_1 : checkWitness 2112 false true 4768 = true := by decide +kernel
private theorem w2112_2 : checkWitness 2112 true false 667 = true := by decide +kernel
private theorem w2112_3 : checkWitness 2112 true true 4759 = true := by decide +kernel
private theorem cases2112 : checkFour 2112 (676,4768,667,4759) = true := by
  simp only [checkFour, w2112_0, w2112_1, w2112_2, w2112_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2112 : Coverage 2112 2113 := checkList_sound (ws:=[(676,4768,667,4759)]) (by simpa only [checkList, Bool.and_true] using cases2112)
private theorem w2113_0 : checkWitness 2113 false false 8925 = true := by decide +kernel
private theorem w2113_2 : checkWitness 2113 true false 8921 = true := by decide +kernel
private theorem cases2113 : checkFour 2113 (8925,0,8921,0) = true := by
  simp only [checkFour, w2113_0, w2113_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2113 : Coverage 2113 2114 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases2113)
private theorem w2114_0 : checkWitness 2114 false false 670 = true := by decide +kernel
private theorem w2114_1 : checkWitness 2114 false true 4762 = true := by decide +kernel
private theorem w2114_2 : checkWitness 2114 true false 661 = true := by decide +kernel
private theorem w2114_3 : checkWitness 2114 true true 4753 = true := by decide +kernel
private theorem cases2114 : checkFour 2114 (670,4762,661,4753) = true := by
  simp only [checkFour, w2114_0, w2114_1, w2114_2, w2114_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2114 : Coverage 2114 2115 := checkList_sound (ws:=[(670,4762,661,4753)]) (by simpa only [checkList, Bool.and_true] using cases2114)
private theorem w2115_0 : checkWitness 2115 false false 8894 = true := by decide +kernel
private theorem w2115_2 : checkWitness 2115 true false 8890 = true := by decide +kernel
private theorem cases2115 : checkFour 2115 (8894,0,8890,0) = true := by
  simp only [checkFour, w2115_0, w2115_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2115 : Coverage 2115 2116 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases2115)
private theorem w2116_0 : checkWitness 2116 false false 86 = true := by decide +kernel
private theorem w2116_2 : checkWitness 2116 true false 86 = true := by decide +kernel
private theorem cases2116 : checkFour 2116 (86,0,86,0) = true := by
  simp only [checkFour, w2116_0, w2116_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2116 : Coverage 2116 2117 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases2116)
private theorem w2117_0 : checkWitness 2117 false false 78 = true := by decide +kernel
private theorem w2117_2 : checkWitness 2117 true false 78 = true := by decide +kernel
private theorem cases2117 : checkFour 2117 (78,0,78,0) = true := by
  simp only [checkFour, w2117_0, w2117_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2117 : Coverage 2117 2118 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2117)
private theorem w2118_0 : checkWitness 2118 false false 635 = true := by decide +kernel
private theorem w2118_1 : checkWitness 2118 false true 4719 = true := by decide +kernel
private theorem w2118_2 : checkWitness 2118 true false 635 = true := by decide +kernel
private theorem w2118_3 : checkWitness 2118 true true 4719 = true := by decide +kernel
private theorem cases2118 : checkFour 2118 (635,4719,635,4719) = true := by
  simp only [checkFour, w2118_0, w2118_1, w2118_2, w2118_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2118 : Coverage 2118 2119 := checkList_sound (ws:=[(635,4719,635,4719)]) (by simpa only [checkList, Bool.and_true] using cases2118)
private theorem w2119_0 : checkWitness 2119 false false 8888 = true := by decide +kernel
private theorem w2119_2 : checkWitness 2119 true false 8884 = true := by decide +kernel
private theorem cases2119 : checkFour 2119 (8888,0,8884,0) = true := by
  simp only [checkFour, w2119_0, w2119_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2119 : Coverage 2119 2120 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases2119)
private theorem w2120_0 : checkWitness 2120 false false 78 = true := by decide +kernel
private theorem w2120_2 : checkWitness 2120 true false 78 = true := by decide +kernel
private theorem cases2120 : checkFour 2120 (78,0,78,0) = true := by
  simp only [checkFour, w2120_0, w2120_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2120 : Coverage 2120 2121 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2120)
private theorem w2121_0 : checkWitness 2121 false false 528 = true := by decide +kernel
private theorem w2121_1 : checkWitness 2121 false true 4624 = true := by decide +kernel
private theorem w2121_2 : checkWitness 2121 true false 528 = true := by decide +kernel
private theorem w2121_3 : checkWitness 2121 true true 4624 = true := by decide +kernel
private theorem cases2121 : checkFour 2121 (528,4624,528,4624) = true := by
  simp only [checkFour, w2121_0, w2121_1, w2121_2, w2121_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2121 : Coverage 2121 2122 := checkList_sound (ws:=[(528,4624,528,4624)]) (by simpa only [checkList, Bool.and_true] using cases2121)
private theorem w2122_0 : checkWitness 2122 false false 8956 = true := by decide +kernel
private theorem w2122_2 : checkWitness 2122 true false 8947 = true := by decide +kernel
private theorem cases2122 : checkFour 2122 (8956,0,8947,0) = true := by
  simp only [checkFour, w2122_0, w2122_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2122 : Coverage 2122 2123 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2122)
private theorem w2123_0 : checkWitness 2123 false false 78 = true := by decide +kernel
private theorem w2123_2 : checkWitness 2123 true false 78 = true := by decide +kernel
private theorem cases2123 : checkFour 2123 (78,0,78,0) = true := by
  simp only [checkFour, w2123_0, w2123_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2123 : Coverage 2123 2124 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2123)
private theorem w2124_0 : checkWitness 2124 false false 538 = true := by decide +kernel
private theorem w2124_1 : checkWitness 2124 false true 4634 = true := by decide +kernel
private theorem w2124_2 : checkWitness 2124 true false 538 = true := by decide +kernel
private theorem w2124_3 : checkWitness 2124 true true 4634 = true := by decide +kernel
private theorem cases2124 : checkFour 2124 (538,4634,538,4634) = true := by
  simp only [checkFour, w2124_0, w2124_1, w2124_2, w2124_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2124 : Coverage 2124 2125 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases2124)
private theorem w2125_0 : checkWitness 2125 false false 8896 = true := by decide +kernel
private theorem w2125_2 : checkWitness 2125 true false 8892 = true := by decide +kernel
private theorem cases2125 : checkFour 2125 (8896,0,8892,0) = true := by
  simp only [checkFour, w2125_0, w2125_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2125 : Coverage 2125 2126 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases2125)
private theorem w2126_0 : checkWitness 2126 false false 80 = true := by decide +kernel
private theorem w2126_2 : checkWitness 2126 true false 80 = true := by decide +kernel
private theorem cases2126 : checkFour 2126 (80,0,80,0) = true := by
  simp only [checkFour, w2126_0, w2126_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2126 : Coverage 2126 2127 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2126)
private theorem w2127_0 : checkWitness 2127 false false 582 = true := by decide +kernel
private theorem w2127_1 : checkWitness 2127 false true 4678 = true := by decide +kernel
private theorem w2127_2 : checkWitness 2127 true false 582 = true := by decide +kernel
private theorem w2127_3 : checkWitness 2127 true true 4678 = true := by decide +kernel
private theorem cases2127 : checkFour 2127 (582,4678,582,4678) = true := by
  simp only [checkFour, w2127_0, w2127_1, w2127_2, w2127_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2127 : Coverage 2127 2128 := checkList_sound (ws:=[(582,4678,582,4678)]) (by simpa only [checkList, Bool.and_true] using cases2127)
private theorem w2128_0 : checkWitness 2128 false false 8917 = true := by decide +kernel
private theorem w2128_2 : checkWitness 2128 true false 8913 = true := by decide +kernel
private theorem cases2128 : checkFour 2128 (8917,0,8913,0) = true := by
  simp only [checkFour, w2128_0, w2128_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2128 : Coverage 2128 2129 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2128)
private theorem w2129_0 : checkWitness 2129 false false 8952 = true := by decide +kernel
private theorem w2129_2 : checkWitness 2129 true false 8943 = true := by decide +kernel
private theorem cases2129 : checkFour 2129 (8952,0,8943,0) = true := by
  simp only [checkFour, w2129_0, w2129_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2129 : Coverage 2129 2130 := checkList_sound (ws:=[(8952,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases2129)
private theorem w2130_0 : checkWitness 2130 false false 104 = true := by decide +kernel
private theorem w2130_2 : checkWitness 2130 true false 104 = true := by decide +kernel
private theorem cases2130 : checkFour 2130 (104,0,104,0) = true := by
  simp only [checkFour, w2130_0, w2130_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2130 : Coverage 2130 2131 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases2130)
private theorem w2131_0 : checkWitness 2131 false false 664 = true := by decide +kernel
private theorem w2131_1 : checkWitness 2131 false true 4756 = true := by decide +kernel
private theorem w2131_2 : checkWitness 2131 true false 655 = true := by decide +kernel
private theorem w2131_3 : checkWitness 2131 true true 4747 = true := by decide +kernel
private theorem cases2131 : checkFour 2131 (664,4756,655,4747) = true := by
  simp only [checkFour, w2131_0, w2131_1, w2131_2, w2131_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2131 : Coverage 2131 2132 := checkList_sound (ws:=[(664,4756,655,4747)]) (by simpa only [checkList, Bool.and_true] using cases2131)
private theorem w2132_0 : checkWitness 2132 false false 8913 = true := by decide +kernel
private theorem w2132_2 : checkWitness 2132 true false 8909 = true := by decide +kernel
private theorem cases2132 : checkFour 2132 (8913,0,8909,0) = true := by
  simp only [checkFour, w2132_0, w2132_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2132 : Coverage 2132 2133 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases2132)
private theorem w2133_0 : checkWitness 2133 false false 658 = true := by decide +kernel
private theorem w2133_1 : checkWitness 2133 false true 4750 = true := by decide +kernel
private theorem w2133_2 : checkWitness 2133 true false 649 = true := by decide +kernel
private theorem w2133_3 : checkWitness 2133 true true 4741 = true := by decide +kernel
private theorem cases2133 : checkFour 2133 (658,4750,649,4741) = true := by
  simp only [checkFour, w2133_0, w2133_1, w2133_2, w2133_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2133 : Coverage 2133 2134 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases2133)
private theorem w2134_0 : checkWitness 2134 false false 8882 = true := by decide +kernel
private theorem w2134_2 : checkWitness 2134 true false 8878 = true := by decide +kernel
private theorem cases2134 : checkFour 2134 (8882,0,8878,0) = true := by
  simp only [checkFour, w2134_0, w2134_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2134 : Coverage 2134 2135 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases2134)
private theorem w2135_0 : checkWitness 2135 false false 92 = true := by decide +kernel
private theorem w2135_2 : checkWitness 2135 true false 92 = true := by decide +kernel
private theorem cases2135 : checkFour 2135 (92,0,92,0) = true := by
  simp only [checkFour, w2135_0, w2135_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2135 : Coverage 2135 2136 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases2135)
private theorem w2136_0 : checkWitness 2136 false false 84 = true := by decide +kernel
private theorem w2136_2 : checkWitness 2136 true false 84 = true := by decide +kernel
private theorem cases2136 : checkFour 2136 (84,0,84,0) = true := by
  simp only [checkFour, w2136_0, w2136_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2136 : Coverage 2136 2137 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2136)
private theorem w2137_0 : checkWitness 2137 false false 623 = true := by decide +kernel
private theorem w2137_1 : checkWitness 2137 false true 4707 = true := by decide +kernel
private theorem w2137_2 : checkWitness 2137 true false 623 = true := by decide +kernel
private theorem w2137_3 : checkWitness 2137 true true 4707 = true := by decide +kernel
private theorem cases2137 : checkFour 2137 (623,4707,623,4707) = true := by
  simp only [checkFour, w2137_0, w2137_1, w2137_2, w2137_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2137 : Coverage 2137 2138 := checkList_sound (ws:=[(623,4707,623,4707)]) (by simpa only [checkList, Bool.and_true] using cases2137)
private theorem w2138_0 : checkWitness 2138 false false 8876 = true := by decide +kernel
private theorem w2138_2 : checkWitness 2138 true false 8872 = true := by decide +kernel
private theorem cases2138 : checkFour 2138 (8876,0,8872,0) = true := by
  simp only [checkFour, w2138_0, w2138_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2138 : Coverage 2138 2139 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases2138)
private theorem w2139_0 : checkWitness 2139 false false 84 = true := by decide +kernel
private theorem w2139_2 : checkWitness 2139 true false 84 = true := by decide +kernel
private theorem cases2139 : checkFour 2139 (84,0,84,0) = true := by
  simp only [checkFour, w2139_0, w2139_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2139 : Coverage 2139 2140 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2139)
private theorem w2140_0 : checkWitness 2140 false false 621 = true := by decide +kernel
private theorem w2140_1 : checkWitness 2140 false true 4713 = true := by decide +kernel
private theorem w2140_2 : checkWitness 2140 true false 612 = true := by decide +kernel
private theorem w2140_3 : checkWitness 2140 true true 4704 = true := by decide +kernel
private theorem cases2140 : checkFour 2140 (621,4713,612,4704) = true := by
  simp only [checkFour, w2140_0, w2140_1, w2140_2, w2140_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2140 : Coverage 2140 2141 := checkList_sound (ws:=[(621,4713,612,4704)]) (by simpa only [checkList, Bool.and_true] using cases2140)
private theorem w2141_0 : checkWitness 2141 false false 8918 = true := by decide +kernel
private theorem w2141_2 : checkWitness 2141 true false 8909 = true := by decide +kernel
private theorem cases2141 : checkFour 2141 (8918,0,8909,0) = true := by
  simp only [checkFour, w2141_0, w2141_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2141 : Coverage 2141 2142 := checkList_sound (ws:=[(8918,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases2141)
private theorem w2142_0 : checkWitness 2142 false false 8864 = true := by decide +kernel
private theorem w2142_2 : checkWitness 2142 true false 8860 = true := by decide +kernel
private theorem cases2142 : checkFour 2142 (8864,0,8860,0) = true := by
  simp only [checkFour, w2142_0, w2142_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2142 : Coverage 2142 2143 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases2142)
private theorem w2143_0 : checkWitness 2143 false false 78 = true := by decide +kernel
private theorem w2143_2 : checkWitness 2143 true false 78 = true := by decide +kernel
private theorem cases2143 : checkFour 2143 (78,0,78,0) = true := by
  simp only [checkFour, w2143_0, w2143_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2143 : Coverage 2143 2144 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2143)
theorem cover2112 : Coverage 2112 2144 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2112 one2113) (Coverage.join one2114 one2115)) (Coverage.join (Coverage.join one2116 one2117) (Coverage.join one2118 one2119))) (Coverage.join (Coverage.join (Coverage.join one2120 one2121) (Coverage.join one2122 one2123)) (Coverage.join (Coverage.join one2124 one2125) (Coverage.join one2126 one2127)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2128 one2129) (Coverage.join one2130 one2131)) (Coverage.join (Coverage.join one2132 one2133) (Coverage.join one2134 one2135))) (Coverage.join (Coverage.join (Coverage.join one2136 one2137) (Coverage.join one2138 one2139)) (Coverage.join (Coverage.join one2140 one2141) (Coverage.join one2142 one2143)))))
end NF182PA.Symbolic
