module
public import LiteralArithmetic
public import LindenbaumInPA
public import CodedNumerals

/-! A ranked proof pool for the eight 182-state row families in arbitrary
models of PA. The ranked-pool deduction and realization inductions adapt
FiniteNumericalProof.lean from the tagged nf192-pa review bundle. -/
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.Numerals.FoundationRoute SetTheory.BusyBeaver.ZFC

namespace NF182PA.Pool

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

def nativeB (a b c : V) :=
  eqn (app (app (app s c) a) b) (app (app c (konst b)) (app a b))
def single (x y : V) := app (app q (konst x)) y
def test (x y : V) := imp (imp (eqn (single x y) x) (eqn (single x x) x)) (eqn y x)

/-- Literal emitter order in the eight-row program. -/
def batch (a b c u : V) : List V :=
  [row0 a b c u,row3 a b,row6 a b c,nativeB a b c,row2 a b c,row4 a b c,test b a,row8 a b]

def axiom182 (p : V) : Prop := ∃ a b c u, ¬a<u ∧ p ∈ batch a b c u

instance axiom182Def : Language.DefinablePred ℒₒᵣ (axiom182 (V:=V)) := by
  unfold axiom182 batch
  simp only [List.mem_cons,List.not_mem_nil,or_false]
  unfold row0 row3 nativeB row2 row4 row6 test single row8
  definability

theorem ax_of_mem {a b c u p : V} (hu : ¬a<u) (hp : p∈batch a b c u) :
    axiom182 p := ⟨a,b,c,u,hu,hp⟩

theorem restricted182 {P : V → Prop} (ax : ∀ p, axiom182 p → P p)
    (mp : ∀ {a b}, P (imp a b) → P a → P b) : DominatedImplication.Restricted domin P where
  mp := mp
  rho8 := fun _ _ _ _ hu => ax _ (ax_of_mem (not_lt_of_ge hu) (.head _))

def Line (ctx pool k p : V) : Prop :=
  axiom182 p ∨ p∈ctx ∨ ∃ a j l, j<k ∧ l<k ∧ ⟪j,imp a p⟫∈pool ∧ ⟪l,a⟫∈pool

def Valid (ctx pool : V) : Prop := ∀ k p, ⟪k,p⟫∈pool → Line ctx pool k p
def Pr (ctx p : V) : Prop := ∃ pool k, Valid ctx pool ∧ ⟪k,p⟫∈pool

instance lineDef : Language.DefinableRel₄ ℒₒᵣ (Line (V:=V)) := by unfold Line; definability
instance validDef : Language.DefinableRel ℒₒᵣ (Valid (V:=V)) := by unfold Valid; definability
instance provDef : Language.DefinableRel ℒₒᵣ (Pr (V:=V)) := by unfold Pr; definability

theorem line_mono {s t p q k a : V} (st : s⊆t) (pq : p⊆q)
    (h : Line s p k a) : Line t q k a := by
  rcases h with ax | hh | ⟨b,j,l,hj,hl,hm,ha⟩
  · exact Or.inl ax
  · exact Or.inr (Or.inl (st hh))
  · exact Or.inr (Or.inr ⟨b,j,l,hj,hl,pq hm,pq ha⟩)

theorem mono {s t a : V} (st : s⊆t) (h : Pr s a) : Pr t a := by
  obtain ⟨pool,k,hp,hk⟩ := h
  exact ⟨pool,k,fun j f hf => line_mono st (fun _ hx => hx) (hp j f hf),hk⟩

theorem leaf {s a : V} (h : axiom182 a ∨ a∈s) : Pr s a := by
  refine ⟨{⟪0,a⟫},0,?_,by simp⟩
  intro j p hp
  have he : j=0 ∧ p=a := by simpa using hp
  rw [he.2]
  rcases h with h | h
  · exact Or.inl h
  · exact Or.inr (Or.inl h)

theorem mp {s a b : V} (hmaj : Pr s (imp a b)) (hmin : Pr s a) : Pr s b := by
  obtain ⟨pool,j,hp,hj⟩ := hmaj
  obtain ⟨other,l,ho,hl⟩ := hmin
  let r := max j l+1
  let united : V := insert ⟪r,b⟫ (pool ∪ other)
  have ps : pool⊆united := by intro x hx; simp [united,hx]
  have os : other⊆united := by intro x hx; simp [united,hx]
  refine ⟨united,r,?_,by simp [united]⟩
  intro k p h
  rcases mem_bitInsert_iff.mp h with e | old
  · obtain ⟨rfl,rfl⟩ := pair_ext_iff.mp e
    exact Or.inr (Or.inr ⟨a,j,l,lt_succ_iff_le.mpr (le_max_left j l),
      lt_succ_iff_le.mpr (le_max_right j l),ps hj,os hl⟩)
  · rcases mem_cup_iff.mp old with h₁ | h₂
    · exact line_mono (fun _ hx => hx) ps (hp k p h₁)
    · exact line_mono (fun _ hx => hx) os (ho k p h₂)

theorem restrictedPr (s : V) : DominatedImplication.Restricted domin (Pr s) :=
  restricted182 (fun _ h => leaf (Or.inl h)) mp

theorem weaken {s a : V} (q : V) (ha : Pr s a) : Pr s (imp q a) :=
  mp (DominatedImplication.k (restrictedPr s) a q) ha

theorem refl (s a : V) : Pr s (imp a a) :=
  mp (mp (DominatedImplication.s (restrictedPr s) a (imp a a) a)
       (DominatedImplication.k (restrictedPr s) a (imp a a))) (DominatedImplication.k (restrictedPr s) a a)

theorem deduction {s a b : V} (h : Pr (insert a s) b) : Pr s (imp a b) := by
  obtain ⟨pool,k,hp,hk⟩ := h
  have trans : ∀ n : V, ∀ j<n, ∀ p, ⟪j,p⟫∈pool → Pr s (imp a p) := by
    apply induction_of_arith
    · apply arithPred_of_definable
      definability
    · intro j hj
      change j<0 at hj
      exact False.elim ((not_lt_of_ge (show (0:V)≤j from zero_le)) hj)
    · intro n ih j hj p elem
      rcases lt_or_eq_of_le (lt_succ_iff_le.mp hj) with jl | rfl
      · exact ih _ jl _ elem
      · rcases hp j p elem with ax | hh | ⟨c,k,l,hk,hl,h1,h2⟩
        · exact weaken _ (leaf (Or.inl ax))
        · rcases mem_bitInsert_iff.mp hh with rfl | hh
          · exact refl _ _
          · exact weaken _ (leaf (Or.inr hh))
        · exact mp (mp (DominatedImplication.s (restrictedPr s) a c p) (ih k hk _ h1))
            (ih l hl _ h2)
  exact trans (k+1) k (by simp) b hk

/-- The conclusion of every internally coded finite proof satisfies any
definable predicate closed under its local rules. This can connect the ranked
format directly to a tree-proof checker or a coded successful command word. -/
theorem realize {s b : V} {R : V → Prop} [Language.DefinablePred ℒₒᵣ R]
    (ha : ∀ p, axiom182 p → R p) (hh : ∀ p, p∈s → R p)
    (hmp : ∀ a p, R (imp a p) → R a → R p) (h : Pr s b) : R b := by
  obtain ⟨pool,k,hp,hk⟩ := h
  have trans : ∀ n : V, ∀ j<n, ∀ p, ⟪j,p⟫∈pool → R p := by
    apply induction_of_arith
    · apply arithPred_of_definable
      definability
    · intro j hj
      change j<0 at hj
      exact False.elim ((not_lt_of_ge (show (0:V)≤j from zero_le)) hj)
    · intro n ih j hj p elem
      rcases lt_or_eq_of_le (lt_succ_iff_le.mp hj) with jl | rfl
      · exact ih _ jl _ elem
      · rcases hp j p elem with ax | hyp | ⟨a,k,l,hk,hl,h1,h2⟩
        · exact ha _ ax
        · exact hh _ hyp
        · exact hmp _ _ (ih k hk _ h1) (ih l hl _ h2)
  exact trans (k+1) k (by simp) b hk


noncomputable def calculus (V : Type) [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    Lindenbaum.Hilbert V where
  imp := imp
  goal := goal
  prov := Pr
  defined := provDef
  assumption := fun _ _ h => leaf (Or.inr h)
  monotone := fun _ _ h _ p => mono h p
  mp := fun _ _ _ maj min => mp maj min
  weaken := fun _ a _ h => weaken a h
  deduction := fun _ _ _ h => deduction h
  composition := fun s a b c ab bc =>
    mp (mp (DominatedImplication.composition (restrictedPr s) a b c) ab) bc
  peirce := fun s a b => DominatedImplication.peirce (restrictedPr s) a b

def E (a b : V) := (calculus V).Holds (eqn a b)

instance E_def : Language.DefinableRel ℒₒᵣ (E (V:=V)) := by unfold E; definability

end NF182PA.Pool
#print axioms NF182PA.Pool.realize
