import NF182PARegisterHalting
import NF182PACountermodel
import NF182PATapeCompiler
import M6PA.Calibration.Foundation
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
namespace NF182PA

/-- The only finite premise is the coverage computation for the 182-state table. -/
theorem internal_consistency_of_coverage (cover : Symbolic.Coverage 0 2971) :
    M6.PA.theory ⊢ (∼H182) 🡒 M6.PA.consistencySentence := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff,LogicalConnective.HomClass.map_imply,LogicalConnective.HomClass.map_neg]
  intro nh
  have no : ¬Pool.Pr (∅ : V) goal :=
    fun p => nh (Symbolic.tape_of_coverage cover (refutation_reaches_register_halt p))
  have hc : M6.PA.theory.Consistent V := by
    intro h
    exact Pool.no_refutation_implies_pa_consistency no (by simpa only [Sentence.quote_falsum] using h)
  simpa [M6.PA.consistencySentence,ProvabilityAbstraction.Provability.con,
    ProvabilityAbstraction.Provability.pr,Theory.Consistent] using hc
end NF182PA
#print axioms NF182PA.internal_consistency_of_coverage
