module
public import NF182Literal
public import MachineCountdown
@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Moving184.Raw
open NF192 NF192.Source

def asCommand : NF192.Emitter.Instruction → Command
  | .inc r next => .inc r.val next
  | .dec r z next => .dec r.val z next false
  | .decHalt r next => .dec r.val 2957 next true
  | .jump next => .jump next
  | .halt => .inc 9 0

def program (pc : Nat) : Command := asCommand (Moving184.Literal.program pc)
end Moving184.Raw
