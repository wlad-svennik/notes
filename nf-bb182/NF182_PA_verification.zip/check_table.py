"""Compare the machine data named by the Lean theorems with the two published tables."""
from pathlib import Path
import hashlib
import json
import re
import sys

PUBLISHED = {
    182: '27613930a4fb7365b761eb23624efa32f1990da0c2d7763e68ad48e0082cb7b7',
    185: '5504746071e10a0555754b55efc2da348ebfb1f8e8ab5bc7af474eaad81f60fe',
}

def verify(machine, lean, count=182):
    data = machine.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != PUBLISHED[count]:
        raise ValueError('published digest mismatch: ' + machine.name)
    header, rest = data.decode('ascii').split('\n',1)
    code = lean.read_text()
    entries = re.search(r'def literalRows : List String := (\[.*?\])\s*theorem serialized_exact',code,re.S)
    if not entries or ''.join(json.loads(entries.group(1))) != rest:
        raise ValueError('rendered row strings differ: ' + lean.name)
    names = json.loads(re.search(r'def stateNames : Array String := #(\[.*?\])', code, re.S).group(1))
    start = int(re.search(r'def start : State := (\d+)',code).group(1))
    if len(set(names))!=count or len(names)!=count or names[start]!=header.split()[-1] or names[start]!='k:64':
        raise ValueError('state names or blank-tape start differ')
    rows = [line.split() for line in rest.splitlines()]
    if len(rows)!=2*count or {(r[0],r[1]) for r in rows}!={(q,b) for q in names for b in ('0','1')}:
        raise ValueError('incomplete literal table')
    return digest

if __name__=='__main__':
    print(verify(Path(sys.argv[1]),Path(sys.argv[2]),int(sys.argv[3]) if len(sys.argv)>3 else 182))
