import NF182PATapeBatchCheck

open NF182PA.Symbolic

/-- Evaluate every row using the exact finite Boolean checker. The proof
batches separately establish each of the resulting equalities in the kernel. -/
def main (args : List String) : IO Unit := do
  let [path] := args | throw (IO.userError "expected a witness CSV path")
  let rows := ((← IO.FS.readFile path).trimAscii.toString.splitOn "\n").drop 1
  if rows.length != 2971 then throw (IO.userError "expected 2971 rows")
  let mut enabled := 0
  let mut pc := 0
  for line in rows do
    let cols := (line.splitOn ",").map String.toNat?
    let [some p,some a,some b,some c,some d] := cols | throw (IO.userError s!"malformed row {pc}")
    if p != pc || !checkFour p (a,b,c,d) then throw (IO.userError s!"rejected row {pc}")
    enabled := enabled + ([a,b,c,d].filter (· != 0)).length
    pc := pc + 1
  IO.println s!"{pc} PCs, {enabled} branch witnesses accepted by NF182PA.Symbolic.checkFour"
