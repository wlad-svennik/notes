"""Apply the bounded-memory reindexing proof to the pinned Foundation source."""
import argparse
import hashlib
import json
from pathlib import Path

MODULE = "Foundation.FirstOrder.Arithmetic.Bootstrapping.Syntax.Term.Basic"
ORIGINAL_SHA256 = "011d4e6c7d222628926ef327104ee6ef4dd683ed4a8447f8379a6752c61e78ec"
MARKER = '''  func := .mkSigma “y k f v v'. !listMaxDef y v'”

variable (L)'''
WITH_HELPER = '''  func := .mkSigma “y k f v v'. !listMaxDef y v'”

omit [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁] in
/-- Check the variable substitution while the substituted formula is abstract. -/
private theorem eval_output {code : 𝚺ᴬ₁.Semisentence 2} {f : V → V}
    (h : 𝚺ᴬ₁-Function₁ f via code) (v : Fin 5 → V) :
    ((.mkSigma “y k i u w. !code y w” : 𝚺ᴬ₁.Semisentence 5).val.Evalb v) ↔ v 0 = f (v 4) := by
  change (code.val ⇜ ![#0,#4]).Evalb v ↔ _
  have a := Semiformula.eval_substs (s:=inferInstanceAs (Tarski.Structure ℒₒᵣ V))
    (b:=v) (f:=Empty.elim) ![#0,#4] code.val
  exact a.trans (h.df _)

variable (L)'''
OLD_PROOF = '  func_defined := .mk fun v ↦ by simp [blueprint]\n\nend IsUTerm.BV'
NEW_PROOF = '''  func_defined := .mk fun v ↦ by
    exact eval_output (code:=listMaxDef) (f:=listMax) (listMax_defined (V:=V)) v

end IsUTerm.BV'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original", type=Path, help="the pinned, unmodified Term/Basic.lean")
    parser.add_argument("destination", type=Path, help="output directory for src/ and provenance.json")
    args = parser.parse_args()
    data = args.original.read_bytes()
    if hashlib.sha256(data).hexdigest() != ORIGINAL_SHA256:
        raise SystemExit("The input differs from the pinned Foundation module")
    source = data.decode()
    assert source.count(MARKER) == source.count(OLD_PROOF) == 1
    replacement = source.replace(MARKER, WITH_HELPER).replace(OLD_PROOF, NEW_PROOF).encode()
    target = (args.destination / "src" / Path(*MODULE.split("."))).with_suffix(".lean")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(replacement)
    manifest = {"module": MODULE, "original_sha256": ORIGINAL_SHA256,
                "source_sha256": hashlib.sha256(replacement).hexdigest()}
    (args.destination / "provenance.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()
