# The 182-state machine in first-order PA

Let H182 and H185 say that the corresponding literal binary machine halts on a blank tape. The machine starts in k:64 and blank is zero. The 182 working states have 364 transitions. The halt state is separate.

| Lean theorem | Mathematical statement |
|---|---|
| `NF182PA.machine_transfer` | PA proves H185 → H182. |
| `NF182PA.internal_consistency` | PA proves ¬H182 → Con(PA), for the standard PA proof predicate. |
| `NF182PA.pa_cannot_prove_nonhalting_of_consistent` | If PA is consistent, PA cannot prove ¬H182. |
| `NFMachine182.halts_iff_nf_refutation` | On the ordinary blank tape the 182-state machine halts exactly when pure NF proves falsum. |
| `NF182PA.pa_independence` | Assuming NF is consistent, PA settles neither sign of H182 and proves no individual numerical upper bound on the 182-state runtime Busy Beaver value. |

## The moving marker and the arithmetic interpretation

Fix any model M of PA. Suppose its internal proof pool for the 182-state machine has no refutation. The eight rows yield an extensional quotient in which D(x,y) = x whenever x and y differ, and D(x,x) differs from x. The term construction gives a reference r and an object p(x,y) with p(x,y) = r for x ≠ y and p(x,x) ≠ r. Put s = D(r,r). Now D(r,p(x,y)) equals s off the diagonal and r on the diagonal. The inequality s ≠ r follows from the moving-marker law itself. Four applications of extensionality choose a,b,c,d such that s a b c d ≠ r a b c d. These give the distinct fixed outputs of the term implementing the tester. The Boolean basis retains the same application operation. Choose representatives t and f for its two Boolean values in M. Membership on representatives has the arithmetic formula

```text
x ∈ y  iff  (∀u, E(yu,t) ∨ E(yu,f)) ∧ E(yx,t).
```

Both parameters belong to M and stay fixed while the proof code varies. PA allows induction with these parameters. Every model gets its own choices and satisfies the same parameter-free halting implication.

For the direct consistency theorem, the represented structure satisfies a fixed arithmetic seed theorem. It supplies the truth and soundness conditions needed for induction on M's own PA proof codes. For the 185-to-182 comparison, interpretation of pure NF in the represented structure yields a chart for the old eight fixed-marker rows. Its application graph is represented by a fixed formula. Least-witness selection gives definable application and extensionality witnesses in M. Induction over a ranked 185 proof in M now establishes its soundness in this chart. A 185 refutation would violate the separation of the chart's distinguished elements. Consequently a 185 refutation forces a 182 refutation in every M.

## From proof codes to the two tapes

The 182 source emits all eight rows and implements modus ponens. Its scanner eventually tests a suitable command word for each internally ranked refutation. The run from the signed origin at PC 40 passes the covered margin at PC 111 after 80 register instructions. The literal blank tape reaches that margin after 51,157 steps. A kernel-checked symbolic proof covers 7,794 branches across all 2,971 register addresses. Each branch applies to register values, unused tape space and clocks throughout M. Induction in M converts an internal refutation to an internal 182 tape halt.

For the reverse direction, every element of the scanner's stack, its top and its cache carries a pool proof. The invariant is arithmetically definable, including the quantification over stack positions. When no refutation exists, a command at PC 10 goes through PC 0 and returns live to PC 10. The frames at the two addresses differ at a fixed bit, so each complete command advances the physical clock. Induction gives live frames past every clock in M. Halting is absorbing, which rules out an earlier halt. The construction is carried out for each of the two tables, with separate boot and branch certificates. This also gives the standard 182-state NF equivalence as a single Lean theorem.

First-order completeness turns the all-model implications into provability in PA. Gödel's second theorem gives the external unprovability of nonhalting under consistency of PA. The separate assumption that NF is consistent supplies actual nonhalting and the positive half of independence. For example, a model of PA which believes PA has a proof of falsum must see this very table halt. If NF is consistent externally, every standard finite run stays live, so the time that model sees must be nonstandard.

## Replay

Install the Lean release in `lean-toolchain`. The included Lake manifest pins Mathlib and its dependencies. From this directory run the following commands.

```sh
lake exe cache get
python3 replay.py --check-inputs
lake env python3 replay.py -j 2
```

The replay verifies the file manifest, the literal table and start state, the exact dependency revisions, and the final theorem axiom reports. Completed modules can be reused on a later invocation. The final reports allow only propositional extensionality, classical choice and quotient soundness. The finite coverage is computed in Lean's kernel. To regenerate the numerical witnesses independently, run the following command.

```sh
python3 witness.py --machine NF182.tm --sites source.sites.json --literal src/NF182Literal.lean --check witnesses.csv
```

The state table SHA-256 is `27613930a4fb7365b761eb23624efa32f1990da0c2d7763e68ad48e0082cb7b7`. The historical source base is the NF185 PA verification archive in the wlad-svennik/notes repository. The source closure required by the listed endpoints is included.

The two files for arithmetic term syntax in `compat/` recast the proofs of formula reindexing for `listMaxDef` and `nthDef`. Their statements and the arithmetic operations they define are identical to the upstream ones. A third patch narrows the import in `NumericalBound` to the PA theory it uses, so the historical tape simulation can be checked independently of Gödel's theorem. The patches and source hashes are under `compat/`. The corresponding original files are under `upstream-original/`.
