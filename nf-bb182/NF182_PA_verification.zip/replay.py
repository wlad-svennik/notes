"""Rebuild the NF182 arithmetic endpoints with the pinned Lean kernel."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

from check_table import verify as check_table

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT/'build'
PIN = 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
CORE = {'propext', 'Classical.choice', 'Quot.sound'}
MAIN = ['NF182PAInternalConsistency','NF182PAMachineTransfer','NF182PAIndependence','NF182PATapeKernel']
EXPECT = {'NF182PATapeKernel':['NF182PA.Symbolic.tape_of_register_halt'],'NF182PAInternalConsistency':['NF182PA.internal_consistency'],
          'NF182PAMachineTransfer':['NF182PA.machine_transfer'],
          'NF182Exact':['NFMachine182.halts_iff_nf_refutation'],
          'NF182PAIndependence':['NF182PA.pa_cannot_prove_nonhalting_of_consistent',
                                'NF182PA.pa_independence','NF182PA.true_value_independent']}
IMPORT = re.compile(r'^\s*(?:(?:public|meta|private)\s+)*import\s+(?:all\s+)?([\w.]+)',re.M)
AX = re.compile(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",re.S)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('targets',nargs='*',default=MAIN)
    parser.add_argument('-j','--jobs',type=int,default=2)
    parser.add_argument('--check-inputs',action='store_true')
    opts=parser.parse_args()
    if opts.jobs<1:
        parser.error('worker count must be positive')
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        expected,path=line.split('  ',1)
        if sha((ROOT/path).read_bytes())!=expected:
            raise ValueError('file hash differs: '+path)
    src=ROOT/'src'
    check_table(ROOT/'NF182.tm',src/'Reduced182Table.lean')
    check_table(ROOT/'NF185.tm',src/'Table185.lean',185)
    subprocess.run([sys.executable, '-B', str(ROOT/'check_source.py'),
                    str(ROOT/'source.sites.json'), str(src/'NF182Literal.lean')],check=True)
    with (ROOT/'witnesses.csv').open() as f:
        rows=list(csv.reader(f))[1:]
    assert [int(row[0]) for row in rows]==list(range(2971))
    assert sum(int(w)>0 for row in rows for w in row[1:])==7794
    if opts.check_inputs:
        print('All manifest hashes, 364 table rows, the start state and the witness dimensions verified.')
        return
    lean=shutil.which('lean')
    if not lean or PIN not in subprocess.check_output([lean,'--version'],text=True):
        parser.error('Run in the included Lake environment with the pinned Lean version.')
    pins=json.loads((ROOT/'lake-manifest.json').read_text())
    for pkg in pins['packages']:
        if 'rev' in pkg:
            name='.'.join(part.removeprefix('«').removesuffix('»') for part in pkg['name'].split('.'))
            checkout=ROOT/'.lake/packages'/name
            got=subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip()
            if got!=pkg['rev']:
                raise ValueError('dependency revision differs: '+pkg['name'])
    allsrc={'.'.join(p.relative_to(src).with_suffix('').parts):p for p in src.rglob('*.lean')}
    deps={}
    keys={}
    def use(m):
        if m not in keys:
            body=allsrc[m].read_bytes()
            deps[m]=sorted(set(IMPORT.findall(body.decode())) & allsrc.keys())
            keys[m]=sha(PIN.encode()+body+''.join(use(n) for n in deps[m]).encode())
        return keys[m]
    for m in opts.targets:
        use(m)
    OUTPUT.mkdir(exist_ok=True)
    env=dict(os.environ)
    env['LEAN_PATH']=os.pathsep.join([str(OUTPUT),*(str(Path(s).resolve()) for s in env.get('LEAN_PATH','').split(os.pathsep) if s)])
    def output_hashes(out):
        return {s:sha(p.read_bytes()) for s in ('.olean','.olean.private','.olean.server','.ir','.ir.sig')
                if (p:=out.with_suffix(s)).is_file()}
    def validate_axioms(m,axioms):
        for theorem in EXPECT.get(m,[]):
            if theorem not in axioms or not set(axioms[theorem])<=CORE:
                raise ValueError('missing theorem or unexpected axioms: '+theorem)
    def compile_one(m):
        rel=allsrc[m].relative_to(src)
        out=(OUTPUT/rel).with_suffix('.olean')
        out.parent.mkdir(parents=True,exist_ok=True)
        receipt=OUTPUT/(m+'.json')
        if out.exists() and receipt.exists():
            prev=json.loads(receipt.read_text())
            if prev['key']==keys[m] and prev['outputs']==output_hashes(out):
                validate_axioms(m,prev['axioms'])
                return prev
        log=OUTPUT/(m+'.log')
        with log.open('w') as stream:
            proc=subprocess.run([lean,'-j','1','-s','131072','-o',str(out),str(rel)],
                                cwd=src,env=env,stdout=stream,stderr=subprocess.STDOUT)
        report=log.read_text()
        if proc.returncode or "uses 'sorry'" in report or 'sorryAx' in report:
            raise RuntimeError(m+' failed. See '+str(log)+'\n'+report[-1400:])
        axioms={name:sorted(v.strip() for v in ax.split(',') if v.strip()) for name,ax in AX.findall(report)}
        validate_axioms(m,axioms)
        result={'module':m,'key':keys[m],'outputs':output_hashes(out),'axioms':axioms}
        receipt.write_text(json.dumps(result,indent=2)+'\n')
        return result
    pending=set(deps)
    seen={}
    running={}
    with ThreadPoolExecutor(max_workers=opts.jobs) as pool:
        while pending or running:
            ready=sorted(m for m in pending if set(deps[m])<=seen.keys())
            for m in ready[:opts.jobs-len(running)]:
                pending.remove(m)
                running[pool.submit(compile_one,m)]=m
            if not running:
                raise ValueError('import cycle')
            done,_=wait(running,return_when=FIRST_COMPLETED)
            for job in done:
                m=running.pop(job)
                seen[m]=job.result()
                print(f'{len(seen)}/{len(deps)} {m}',flush=True)
    audit={t:seen[m]['axioms'][t] for m,names in EXPECT.items() if m in seen for t in names}
    if audit:
        declarations=''.join('import '+m+'\n' for m in sorted(set(opts.targets)))
        declarations+=''.join('#print axioms '+t+'\n' for t in audit)
        with tempfile.TemporaryDirectory() as tmp:
            probe=Path(tmp)/'Audit.lean'
            probe.write_text(declarations)
            checked=subprocess.run([lean,'-j','1','-s','131072',str(probe)],cwd=tmp,env=env,
                                   capture_output=True,text=True,check=True)
        observed={name:sorted(v.strip() for v in ax.split(',') if v.strip())
                  for name,ax in AX.findall(checked.stdout)}
        if observed!=audit:
            raise ValueError('exported axiom audit differs from build receipts')
    (OUTPUT/'axioms.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps(audit,indent=2))
if __name__=='__main__':
    main()
