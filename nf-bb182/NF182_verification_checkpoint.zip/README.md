# A 182-state binary Turing machine for pure NF

Started on a blank tape, this machine halts if and only if pure Quine NF proves a contradiction. The literal transition table is `NF182.tm`. It has 182 graph-reachable working states, two tape symbols, and 364 transitions. Blank is 0, the initial state is `k:64`, and the terminal state is designated separately as `halt`. The table's SHA-256 is `27613930a4fb7365b761eb23624efa32f1990da0c2d7763e68ad48e0082cb7b7`.

## How the two states come out

The first change reuses a decoder path and removes `d:127`. The second reuses states shared by the decoder and the register machinery, eliminating `a:CD:1`. These are the five changed rows among surviving states. All five read zero. The entries show the written bit, head motion and next state.

| Reduction | State | Old instruction | New instruction |
|---|---|---|---|
| 184 → 183 | `fresh:5` | `0 R d:127` | `0 R purenew:5` |
| 184 → 183 | `purenew:9` | `0 L d:142` | `0 L d:76` |
| 183 → 182 | `d:155` | `0 R a:CD:5` | `0 L d:146` |
| 183 → 182 | `d:51` | `0 R a:CD:1` | `0 L d:6` |
| 183 → 182 | `k:60` | `0 R k:55` | `1 L d:155` |

The 184-state table and its proof dependencies are inside `NF184_verification_checkpoint.zip`. The intermediate literal is `NF183.tm`. After each set of changes the removed state has no reachable incoming transition. The checks compare every surviving row at both stages. All three tables implement identical register source bytes. The source has 2,971 instructions and SHA-256 `0aa8f1ebc66afd3b7dd1775863db312d24cee23f9fed5d0bab1ec060d9c0d278`.

## Why the NF halting criterion carries over

* On the integer-indexed tape the 182-state machine reaches the first signed source frame, at address 40, after 17,319 steps. After 80 source instructions, at tape step 51,157, it reaches covered address 111 with the head at −1, gap 51, 32 zero spares and registers `[-1, 0, 0, 2, 0, 0, 0, 1, 0]`. The local Lean theorem `Reduced182.Calibration.safe_frame` checks this against the literal table.
* The default Lean kernel checked all 7,794 branch theorems in 62 batches. The branches quantify over register widths, gap, spare count and exterior tape outside the frame margins. The symbolic certificate uses 20 repeated-block lemmas and 370,204 actions. Every branch takes at least 26 binary steps.
* `Reduced182.Rays.normalized_run` proves that the two tape rays used by the branch certificates describe the ordinary integer-indexed tape after any number of steps. `Reduced182.Rays.halt_agrees` identifies the raw terminal control number with ordinary machine halting. These Lean theorems compare every instruction of the literal table and apply to every initial configuration and either head orientation.
* Independently, a C++ simulator replayed 48 complete tapes at each of the 2,971 addresses. The 142,608 tests took 88,735,299 binary steps. At the halt gate, 23 inputs halted and 25 continued. All 48 outcomes agreed with the 196-state reference.

Starting at the certified frame at address 111, each live source step takes the tape frame to its prescribed successor in positive time. A halting source step takes the physical machine to its terminal state. By induction, a finite source halt gives a tape halt. If the source runs forever, live frames occur at strictly increasing times. An absorbing halt would preclude any later live frame. Together with the upstream theorem relating the register program to refutation in pure NF, this gives the stated halting equivalence.

Lean also checks the induction in `FrameInduction.from_blank_iff` under its explicit frame-transfer hypothesis. The application of the separately checked branch family to that hypothesis is the mathematical argument above. A PA-internal Busy Beaver theorem would require an additional formalization.

## Reproduce the checks

The basic command validates the graph, exact edits, source identity and binding of the receipts to the literal. The next commands run the independent full-tape tests, regenerate the symbolic traces, and regenerate and kernel-check the proof terms.

```sh
python3 verify.py
python3 verify.py --frames
python3 verify.py --symbolic
python3 verify.py --kernel --jobs 2
```

Python 3 is required. The tape simulator requires a C++17 compiler. The kernel replay uses Lean 4.35.0's `leanchecker-paranoid` on PATH. To replay the blank-tape theorems, build `NF_Eight_Row_185` from `upstream185.zip` inside the bundled 184-state checkpoint, following its README. Run the command below in its Lake environment with the directory containing the built upstream `.olean` modules. This regenerates the four local Lean sources, compares them byte-for-byte, and compiles them.

```sh
lake env python3 /path/to/verify.py --lean-build /path/to/upstream-build
```

To check the two-ray interpretation as well, add `--ray-bridge` to the last command. It regenerates the raw semantics directly from this table, imports the definitions through `ReadSweep.lean`, and checks the 182 table cases, the head-motion proof, and the normalized and halting correspondences. All formal sources are included.

## Proofs for the search below 182

`research/load/` contains three further kernel-checked Lean modules. They analyze a proof-search command that loads the old cache into the top register, pops the stack head into the cache, and retains the rest of the stack. An axiom command can save the old top on the stack. Loading through the emitted rows later recovers it and exposes the next stack value, which is enough to schedule both premises of modus ponens.

`PopLoadStream.stream_halting_iff_goal` proves that the fair register-level search halts exactly when its numerical calculus derives the goal. The bundled upstream work relates that calculus to pure NF. A smaller binary implementation of this LOAD command is an open construction in this checkpoint. To replay these modules, use the 184-state Lean environment with `Moving184Search` built and compile `PopLoadSearch.lean`, `LiteralPopLoad.lean` and `PopLoadStream.lean` in that order.


Two more files formalize ways to simplify the scanner or its halt gate. Both compile in the same Lean environment.

* `research/Stride.lean` proves that the proof scanner can enumerate any arithmetic progression with step `2^k` and any starting offset. Given a detecting word, one disposable MP command supplies a free parameter. The two nested Cantor pairings use that parameter to place the word in the required residue class, arbitrarily far out. `Stride.proof_word_at_stride` checks that a candidate on that progression halts the proof search from every proof state whenever the numerical goal is derivable. The stronger theorem `Stride.reset_scan_halting_iff_goal` also permits each refill to reset the proof state in any way that preserves derivability of its stored formulas.
* `research/AlternateGoals.lean` proves that the contradiction marker 3 is derivable exactly when any one of the markers 5, 7, 11, 13, 15, 17, 19, 23 or 27 is derivable. The proof uses the eight original axiom rows. It also shows that 71 is derivable unconditionally, so a halt test that accepts every number congruent to 3 modulo 4 would give a false positive.
