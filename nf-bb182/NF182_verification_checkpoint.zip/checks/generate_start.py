"""Rebind the NF184 finite blank-prefix proof to a checked smaller table."""
from pathlib import Path
from zipfile import ZipFile
import argparse
import json
import re

def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('machine', type=Path)
    cli.add_argument('release184', type=Path)
    cli.add_argument('out', type=Path)
    cli.add_argument('--calibration', type=Path)
    args = cli.parse_args()
    folder = args.out
    folder.mkdir(exist_ok=True, parents=True)
    (folder/'NF210').mkdir(exist_ok=True)
    with ZipFile(args.release184/'upstream185.zip') as z:
        for f in ('NF210/MachineSemantics.lean','MachineBits.lean','MachineFrame.lean'):
            (folder/f).write_bytes(z.read('NF_Eight_Row_185/src/'+f))
    text=args.machine.read_text()
    lines=text.splitlines()
    states=sorted({s.split()[0] for s in lines[1:]})
    n=len(states); ids={s:i for i,s in enumerate(states)}
    table={}
    for line in lines[1:]:
        q,b,w,d,p=line.split()
        assert (q,int(b)) not in table
        table[q,int(b)] = int(w),d,p
    assert len(table)==2*n
    start=lines[0].split()[-1]
    prefix='Reduced'+str(n)
    def template(name):
        return (args.release184/'lean'/('Moving184'+name+'.lean')).read_text().replace('Moving184',prefix)
    def inst(q,b):
        w,d,p=table[q,b]
        dest='none' if p=='halt' else f'some ({ids[p]} : State)'
        return '⟨'+str(bool(w)).lower()+', '+('.right' if d=='R' else '.left')+', '+dest+'⟩'
    def balanced(lo,hi,indent):
        if hi==lo+1:
            return indent+'('+inst(states[lo],0)+', '+inst(states[lo],1)+')'
        mid=(lo+hi)//2
        return '\n'.join((indent+f'if q.val < {mid} then',balanced(lo,mid,indent+'  '),indent+'else',balanced(mid,hi,indent+'  ')))
    src=template('Table')
    src=re.sub(r'def stateNames : Array String := .*',lambda m:'def stateNames : Array String := #'+json.dumps(states),src)
    src=re.sub(r'def start : State := \d+',f'def start : State := {ids[start]}',src)
    src=re.sub(r'(?<=× Instruction 184 :=\n).*?(?=\ndef machine)',lambda m:balanced(0,n,'  '),src,flags=re.S)
    src=re.sub(r'def literalOrder : List State := .*',lambda m:'def literalOrder : List State := '+str(list(range(n))),src)
    src=re.sub(r'def literalRows : List String := \[\n.*?\]\ntheorem',lambda m:'def literalRows : List String := [\n'+',\n'.join(json.dumps(s+'\n')for s in lines[1:])+']\ntheorem',src,flags=re.S)
    src=re.sub(r'\b184\b',str(n),src)
    (folder/(prefix+'Table.lean')).write_text(src)
    receipt=json.loads((args.calibration or args.machine.with_name('blank.json')).read_bytes())
    first_tick=receipt['start_step']
    safe_tick=receipt['covered_step']
    assert (receipt['start_pc'],receipt['covered_pc'],receipt['gap'],receipt['zero_spares'],receipt['registers'])==(40,111,51,32,[-1,0,0,2,0,0,0,1,0])
    moments=sorted({*range(0,safe_tick,500),first_tick,safe_tick})
    wanted=set(moments)
    snaps={}
    q=start;head=10;bits=0
    for i in range(safe_tick+1):
        if i in wanted:
            snaps[i]=(ids[q], head, bits)
        if i<safe_tick:
            bit=(bits>>head)&1
            w,d,q=table[q,bit];bits^=(bit^w)<<head;head+=1 if d=='R' else -1
            assert 0<=head<256 and q!='halt'
    for typ,lo,hi in [('Boot',0,first_tick),('Safe',first_tick,safe_tick)]:
        src=template(typ)
        inner=[x for x in moments if lo<x<=hi]
        listed=([0] if typ=='Boot' else [])+inner
        text=src[:src.index('def snap')]
        for step in listed:
            state,head,bits=snaps[step]
            text+=f'def snap{step} : KernelBits.Configuration {n} := ⟨some ({state} : State), {head}, {bits}⟩\n'
        prev=lo
        for end_tick in inner:
            delta=end_tick-prev
            text+=f'theorem chunk{end_tick} : Prefix {delta} snap{prev} snap{end_tick} := checked _ _ _ (by decide) (by decide)\n'
            proof=f'chunk{end_tick}' if prev==0 else f'@compose {prev} {delta} snap0 snap{prev} snap{end_tick} fromBlank{prev} chunk{end_tick}'
            text+=f'theorem fromBlank{end_tick} : Prefix {end_tick} snap0 snap{end_tick} := {proof}\n'
            prev=end_tick
        last=src[src.index('theorem embed_start' if typ=='Boot' else 'theorem blank_safe_gap'):]
        text+=last.replace('17265',str(first_tick)).replace('50923',str(safe_tick))
        (folder/(prefix+typ+'.lean')).write_text(re.sub(r'\b184\b',str(n),text))
    src=template('Frame').replace('17265',str(first_tick)).replace('50923',str(safe_tick))
    src=re.sub(r'def decoderRoot : State := \d+',f'def decoderRoot : State := {ids["d:0"]}',src)
    (folder/(prefix+'Frame.lean')).write_text(re.sub(r'\b184\b',str(n),src))

if __name__=='__main__':
    main()
