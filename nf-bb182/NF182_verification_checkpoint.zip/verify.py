"""Replay the physical reduction to 182 states using the bundled NF184 source checkpoint."""
import argparse
import gzip
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
TABLE_HASH = '27613930a4fb7365b761eb23624efa32f1990da0c2d7763e68ad48e0082cb7b7'
INTERMEDIATE_HASH = 'dc5d97babf82dca5fcaa6b0130f3ba7e8f3b4b1c12fdf370ba42268a6e8a6c2f'
SOURCE_HASH = '0aa8f1ebc66afd3b7dd1775863db312d24cee23f9fed5d0bab1ec060d9c0d278'
py = sys.executable

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def require(value, message):
    if not value:
        raise ValueError(message)

def parse(path):
    header, *rows = path.read_text().splitlines()
    start = header.split()[-1]
    table = {}
    for row in rows:
        state,bit,w,side,target = row.split()
        require(bit in ('0','1') and w in ('0','1') and side in ('L','R'), row)
        require((state,bit) not in table, 'duplicate transition')
        table[state,bit] = w,side,target
    states = {q for q,b in table}
    seen = set()
    pending = [start]
    while pending:
        q = pending.pop()
        if q != 'halt' and q not in seen:
            seen.add(q)
            pending.extend(table[q,b][2] for b in ('0','1'))
    require(seen == states and len(table)==2*len(states), 'incomplete or unreachable state')
    return start,table,states

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frames', action='store_true')
    parser.add_argument('--symbolic', action='store_true')
    parser.add_argument('--kernel', action='store_true')
    parser.add_argument('--jobs', type=int, default=2)
    parser.add_argument('--lean-build', type=Path, help='prebuilt NF_Eight_Row_185 module directory')
    parser.add_argument('--ray-bridge', action='store_true',
                        help='also check agreement of raw certificate semantics with the integer tape; requires --lean-build')
    args=parser.parse_args()
    if args.ray_bridge and not args.lean_build:
        parser.error('--ray-bridge requires --lean-build')
    with TemporaryDirectory() as d:
        tmp=Path(d)
        release=tmp/'prior'
        with ZipFile(ROOT/'NF184_verification_checkpoint.zip') as prior:
            prior.extractall(release)
        machine=tmp/'machine'
        machine.mkdir()
        cand=machine/'candidate.tm'
        cand.write_bytes((ROOT/'NF182.tm').read_bytes())
        src=machine/'source.sites.json'
        src.write_bytes((release/'machines/variable184/source.sites.json').read_bytes())
        require(digest(cand)==TABLE_HASH and digest(src)==SOURCE_HASH, 'machine/source hashes')
        intermediate=ROOT/'NF183.tm'
        require(digest(intermediate)==INTERMEDIATE_HASH,'intermediate 183-state table hash')
        start,T,S=parse(intermediate)
        start0,T0,S0=parse(release/'machines/variable184/candidate.tm')
        require(start==start0 and len(S)==183 and S0-S=={'d:127'} and S<=S0,'state delta')
        changes={k:(T0[k],T[k]) for k in T if T[k]!=T0[k]}
        require(changes=={
            ('fresh:5','0'):(('0','R','d:127'),('0','R','purenew:5')),
            ('purenew:9','0'):(('0','L','d:142'),('0','L','d:76'))},'transition delta '+str(changes))
        final_start,final_table,final_states=parse(cand)
        require(start==final_start and len(final_states)==182 and final_states<=S and S-final_states=={'a:CD:1'}, '182-state graph delta')
        changes={k:(T[k],final_table[k]) for k in final_table if final_table[k]!=T[k]}
        require(changes=={
            ('d:155','0'):(('0','R','a:CD:5'),('0','L','d:146')),
            ('d:51','0'):(('0','R','a:CD:1'),('0','L','d:6')),
            ('k:60','0'):(('0','R','k:55'),('1','L','d:155'))},'182-state transition delta '+str(changes))
        traces=ROOT/'traces.json.gz'
        tr=json.loads(gzip.decompress(traces.read_bytes()))
        rec=json.loads((ROOT/'receipts/kernel.json').read_bytes())
        require(tr['table']==rec['table']==TABLE_HASH and tr['source']==rec['source']==SOURCE_HASH,'certificate binding')
        require(rec['trace_sha256']==digest(traces) and rec['branch_theorems']==len(tr['traces'])==7794,'branch count')
        sites=json.loads(src.read_bytes())
        expected={(pc,cold,zero) for pc,(_,kind,reg) in enumerate(sites)
                  for cold in (False,True) if not(cold and kind=='CD' and reg==0)
                  for zero in ((False,True) if kind=='CD' else (False,))}
        observed={(t['pc'],t['cold'],t['zero']) for t in tr['traces']}
        require(observed==expected and len(expected)==len(tr['traces']), 'duplicate or missing branch')
        require(all(len(t['clock'])==12 and t['clock'][0]>=26 and min(t['clock'])>=0 for t in tr['traces']), 'a branch lacks a positive duration')
        intervals=rec['intervals']
        require(intervals[0]['first_pc']==0 and intervals[-1]['past_last_pc']==2971 and all(a['past_last_pc']==b['first_pc'] for a,b in zip(intervals,intervals[1:])), 'kernel intervals')
        require(all(t['kernel']=='Lean default kernel accepts the solution' for t in intervals) and sum(t['branches'] for t in intervals)==len(tr['traces']), 'kernel receipt coverage')
        print('182 graph-reachable working states, 364 transitions, 2,971 unchanged source instructions, 7,794 recorded branch proofs.',flush=True)
        checks=release/'checks'
        if args.frames:
            with ZipFile(release/'upstream185.zip') as upstream:
                ref=tmp/'ref'
                ref.mkdir()
                for name in ('counting196.sites.json','counting196.tm'):
                    (ref/name).write_bytes(upstream.read('NF_Eight_Row_185/reference/'+name))
            observed=tmp/'frames.json'
            subprocess.run([py,ROOT/'checks/run.py',cand,src,ref/'counting196.tm','--reference-source',ref/'counting196.sites.json','--fixtures','48','--output',observed],check=True)
            require(json.loads(observed.read_bytes())==json.loads((ROOT/'receipts/frames48.json').read_bytes()),'finite replay differs')
        if args.symbolic:
            gen=tmp/'traces.json.gz'
            subprocess.run([py,checks/'symbolic_frames.py',machine,'--write',gen],check=True)
            require(gzip.decompress(gen.read_bytes())==gzip.decompress(traces.read_bytes()),'regenerated symbolic trace differs')
        if args.kernel:
            new=tmp/'kernel.json'
            subprocess.run([py,checks/'check_all.py',machine,traces,new,'--jobs',str(args.jobs)],check=True)
            require(json.loads(new.read_bytes())==rec,'kernel receipt differs')
        if args.lean_build:
            out=tmp/'lean'
            build=args.lean_build.resolve()
            subprocess.run([py,ROOT/'checks/generate_start.py',cand,release,out,'--calibration',ROOT/'receipts/blank.json'],check=True)
            env=dict(os.environ,LEAN_PATH=os.pathsep.join([str(build),str(out),os.environ.get('LEAN_PATH','')]))
            for suffix in ('Table','Boot','Safe','Frame'):
                mod='Reduced182'+suffix
                require((out/(mod+'.lean')).read_bytes()==(ROOT/'lean'/(mod+'.lean')).read_bytes(),'Lean listing mismatch')
                rep=subprocess.run(['lean','-j1','-s','131072','-o',mod+'.olean',mod+'.lean'],cwd=out,env=env,check=True,capture_output=True,text=True)
                require(not re.search(r'\bsorryAx\b|declaration uses .sorry.|\berror:',rep.stdout+rep.stderr),'Lean proof error')
                print((rep.stdout+rep.stderr).strip(),flush=True)
            induction=ROOT/'lean/FrameInduction.lean'
            if induction.exists():
                shutil.copyfile(induction,out/induction.name)
                rep=subprocess.run(['lean','-j1','-s','131072','-o','FrameInduction.olean',induction.name],cwd=out,env=env,check=True,capture_output=True,text=True)
                require('sorryAx' not in rep.stdout+rep.stderr,'induction proof error')
                print((rep.stdout+rep.stderr).strip(),flush=True)
            if args.ray_bridge:
                env=dict(env,NF_TABLE=str(cand),NF_TRACES=str(traces))
                subprocess.run([py,checks/'kernel_branches.py',machine,out/'base.ndjson','--lo','0','--hi','0'],env=env,check=True)
                ray_receipt=json.loads((ROOT/'receipts/ray-semantics.json').read_bytes())
                require(ray_receipt['table']==TABLE_HASH and digest(out/'base.ndjson')==ray_receipt['raw_semantics_sha256'],'raw semantics binding')
                for mod in ('ReadSweep','SweepBase','RayTable','RayPhysical','RayBridge'):
                    name=mod+'.lean'
                    shutil.copyfile(ROOT/'lean'/name,out/name)
                    rep=subprocess.run(['lean','-j1','-s','131072','-o',mod+'.olean',name],cwd=out,env=env,check=True,capture_output=True,text=True)
                    require('sorryAx' not in rep.stdout+rep.stderr,'ray semantics proof error')
                    print((rep.stdout+rep.stderr).strip(),flush=True)
if __name__=='__main__':
    main()
