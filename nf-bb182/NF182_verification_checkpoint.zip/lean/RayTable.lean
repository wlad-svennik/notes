import SweepBase
import Reduced182Table
set_option maxRecDepth 400000
set_option maxHeartbeats 0

noncomputable section
namespace Reduced182.Rays
open NF210.TM
abbrev Ray := Nat → Nat
abbrev Raw := Nat → Ray
def encodeState : Option (Fin 182) → Nat
  | none => 182
  | some q => q.val
def encodeDir : Direction → Nat
  | .right => 0
  | .left => 1
def ahead (c : Configuration 182) (d : Direction) (i : Nat) : Nat :=
  (c.tape (match d with | .right => c.head + (i:Int) | .left => c.head - (i:Int))).toNat
def behind (c : Configuration 182) (d : Direction) (i : Nat) : Nat :=
  (c.tape (match d with | .right => c.head - (i:Int) - 1 | .left => c.head + (i:Int) + 1)).toNat
def encode (c : Configuration 182) (d : Direction) : Raw :=
  NFSearchSweep.cfg (encodeState c.state) (encodeDir d) (ahead c d) (behind c d)

def nextFacing (c : Configuration 182) (d : Direction) : Direction :=
  match c.state with
  | none => d
  | some q => (Table.machine q (c.tape c.head)).move

theorem table_agrees (q : Fin 182) (b : Bool) (d : Nat) (a h : Ray) :
    NFSearchSweep.table0 q.val b.toNat d a h =
    NFSearchSweep.applyRow (encodeState (Table.machine q b).next) (Table.machine q b).write.toNat
      (encodeDir (Table.machine q b).move) d a h := by
  rcases q with ⟨i, hi⟩
  match i with
  | 0 => cases b <;> rfl
  | 1 => cases b <;> rfl
  | 2 => cases b <;> rfl
  | 3 => cases b <;> rfl
  | 4 => cases b <;> rfl
  | 5 => cases b <;> rfl
  | 6 => cases b <;> rfl
  | 7 => cases b <;> rfl
  | 8 => cases b <;> rfl
  | 9 => cases b <;> rfl
  | 10 => cases b <;> rfl
  | 11 => cases b <;> rfl
  | 12 => cases b <;> rfl
  | 13 => cases b <;> rfl
  | 14 => cases b <;> rfl
  | 15 => cases b <;> rfl
  | 16 => cases b <;> rfl
  | 17 => cases b <;> rfl
  | 18 => cases b <;> rfl
  | 19 => cases b <;> rfl
  | 20 => cases b <;> rfl
  | 21 => cases b <;> rfl
  | 22 => cases b <;> rfl
  | 23 => cases b <;> rfl
  | 24 => cases b <;> rfl
  | 25 => cases b <;> rfl
  | 26 => cases b <;> rfl
  | 27 => cases b <;> rfl
  | 28 => cases b <;> rfl
  | 29 => cases b <;> rfl
  | 30 => cases b <;> rfl
  | 31 => cases b <;> rfl
  | 32 => cases b <;> rfl
  | 33 => cases b <;> rfl
  | 34 => cases b <;> rfl
  | 35 => cases b <;> rfl
  | 36 => cases b <;> rfl
  | 37 => cases b <;> rfl
  | 38 => cases b <;> rfl
  | 39 => cases b <;> rfl
  | 40 => cases b <;> rfl
  | 41 => cases b <;> rfl
  | 42 => cases b <;> rfl
  | 43 => cases b <;> rfl
  | 44 => cases b <;> rfl
  | 45 => cases b <;> rfl
  | 46 => cases b <;> rfl
  | 47 => cases b <;> rfl
  | 48 => cases b <;> rfl
  | 49 => cases b <;> rfl
  | 50 => cases b <;> rfl
  | 51 => cases b <;> rfl
  | 52 => cases b <;> rfl
  | 53 => cases b <;> rfl
  | 54 => cases b <;> rfl
  | 55 => cases b <;> rfl
  | 56 => cases b <;> rfl
  | 57 => cases b <;> rfl
  | 58 => cases b <;> rfl
  | 59 => cases b <;> rfl
  | 60 => cases b <;> rfl
  | 61 => cases b <;> rfl
  | 62 => cases b <;> rfl
  | 63 => cases b <;> rfl
  | 64 => cases b <;> rfl
  | 65 => cases b <;> rfl
  | 66 => cases b <;> rfl
  | 67 => cases b <;> rfl
  | 68 => cases b <;> rfl
  | 69 => cases b <;> rfl
  | 70 => cases b <;> rfl
  | 71 => cases b <;> rfl
  | 72 => cases b <;> rfl
  | 73 => cases b <;> rfl
  | 74 => cases b <;> rfl
  | 75 => cases b <;> rfl
  | 76 => cases b <;> rfl
  | 77 => cases b <;> rfl
  | 78 => cases b <;> rfl
  | 79 => cases b <;> rfl
  | 80 => cases b <;> rfl
  | 81 => cases b <;> rfl
  | 82 => cases b <;> rfl
  | 83 => cases b <;> rfl
  | 84 => cases b <;> rfl
  | 85 => cases b <;> rfl
  | 86 => cases b <;> rfl
  | 87 => cases b <;> rfl
  | 88 => cases b <;> rfl
  | 89 => cases b <;> rfl
  | 90 => cases b <;> rfl
  | 91 => cases b <;> rfl
  | 92 => cases b <;> rfl
  | 93 => cases b <;> rfl
  | 94 => cases b <;> rfl
  | 95 => cases b <;> rfl
  | 96 => cases b <;> rfl
  | 97 => cases b <;> rfl
  | 98 => cases b <;> rfl
  | 99 => cases b <;> rfl
  | 100 => cases b <;> rfl
  | 101 => cases b <;> rfl
  | 102 => cases b <;> rfl
  | 103 => cases b <;> rfl
  | 104 => cases b <;> rfl
  | 105 => cases b <;> rfl
  | 106 => cases b <;> rfl
  | 107 => cases b <;> rfl
  | 108 => cases b <;> rfl
  | 109 => cases b <;> rfl
  | 110 => cases b <;> rfl
  | 111 => cases b <;> rfl
  | 112 => cases b <;> rfl
  | 113 => cases b <;> rfl
  | 114 => cases b <;> rfl
  | 115 => cases b <;> rfl
  | 116 => cases b <;> rfl
  | 117 => cases b <;> rfl
  | 118 => cases b <;> rfl
  | 119 => cases b <;> rfl
  | 120 => cases b <;> rfl
  | 121 => cases b <;> rfl
  | 122 => cases b <;> rfl
  | 123 => cases b <;> rfl
  | 124 => cases b <;> rfl
  | 125 => cases b <;> rfl
  | 126 => cases b <;> rfl
  | 127 => cases b <;> rfl
  | 128 => cases b <;> rfl
  | 129 => cases b <;> rfl
  | 130 => cases b <;> rfl
  | 131 => cases b <;> rfl
  | 132 => cases b <;> rfl
  | 133 => cases b <;> rfl
  | 134 => cases b <;> rfl
  | 135 => cases b <;> rfl
  | 136 => cases b <;> rfl
  | 137 => cases b <;> rfl
  | 138 => cases b <;> rfl
  | 139 => cases b <;> rfl
  | 140 => cases b <;> rfl
  | 141 => cases b <;> rfl
  | 142 => cases b <;> rfl
  | 143 => cases b <;> rfl
  | 144 => cases b <;> rfl
  | 145 => cases b <;> rfl
  | 146 => cases b <;> rfl
  | 147 => cases b <;> rfl
  | 148 => cases b <;> rfl
  | 149 => cases b <;> rfl
  | 150 => cases b <;> rfl
  | 151 => cases b <;> rfl
  | 152 => cases b <;> rfl
  | 153 => cases b <;> rfl
  | 154 => cases b <;> rfl
  | 155 => cases b <;> rfl
  | 156 => cases b <;> rfl
  | 157 => cases b <;> rfl
  | 158 => cases b <;> rfl
  | 159 => cases b <;> rfl
  | 160 => cases b <;> rfl
  | 161 => cases b <;> rfl
  | 162 => cases b <;> rfl
  | 163 => cases b <;> rfl
  | 164 => cases b <;> rfl
  | 165 => cases b <;> rfl
  | 166 => cases b <;> rfl
  | 167 => cases b <;> rfl
  | 168 => cases b <;> rfl
  | 169 => cases b <;> rfl
  | 170 => cases b <;> rfl
  | 171 => cases b <;> rfl
  | 172 => cases b <;> rfl
  | 173 => cases b <;> rfl
  | 174 => cases b <;> rfl
  | 175 => cases b <;> rfl
  | 176 => cases b <;> rfl
  | 177 => cases b <;> rfl
  | 178 => cases b <;> rfl
  | 179 => cases b <;> rfl
  | 180 => cases b <;> rfl
  | 181 => cases b <;> rfl
  | i+182 => omega

end Reduced182.Rays
