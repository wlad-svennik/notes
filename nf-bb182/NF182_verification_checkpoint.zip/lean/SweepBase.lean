import ReadSweep
set_option maxRecDepth 500000
set_option maxHeartbeats 0
read_sweep "base.ndjson"
#check NFSearchSweep.step
#print axioms NFSearchSweep.sweep0
