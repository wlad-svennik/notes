import RayTable
set_option maxRecDepth 400000
set_option maxHeartbeats 0
noncomputable section
namespace Reduced182.Rays
open NF210.TM
def after (c : Configuration 182) (ins : Instruction 182) : Configuration 182 :=
  ⟨ins.next, moveHead ins.move c.head, writeTape c.tape c.head ins.write⟩

private theorem eqRays {q d : Nat} {a b c e : Ray} (ha : a=c) (hb : b=e) :
    NFSearchSweep.cfg q d a b = NFSearchSweep.cfg q d c e := by rw [ha,hb]

private theorem sameRays (c : Configuration 182) (d : Direction) (ins : Instruction 182) :
  NFSearchSweep.applyRow (encodeState ins.next) ins.write.toNat (encodeDir ins.move)
    (encodeDir d) (ahead c d) (behind c d) = encode (after c ins) ins.move := by
  rcases c with ⟨q, h, t⟩
  have tape_eq {i j : Int} (hij : i=j) : (t i).toNat = (t j).toNat := by rw [hij]
  rcases ins with ⟨w, m, p⟩
  cases d <;> cases m <;>
    apply eqRays <;>
    funext i <;> cases i <;>
    simp [after, ahead, behind, moveHead, writeTape, NFSearchSweep.tail,
      NFSearchSweep.push, Nat.succ_eq_add_one]
  all_goals try rfl
  all_goals try split
  all_goals first | rfl | omega | (apply tape_eq; omega)

theorem step_agrees (c : Configuration 182) (d : Direction) :
    NFSearchSweep.step (encode c d) = encode (step Table.machine c) (nextFacing c d) := by
  rcases c with ⟨q, h, t⟩
  cases q with
  | none => rfl
  | some q =>
    let c : Configuration 182 := ⟨some q,h,t⟩
    change NFSearchSweep.table0 q.val (ahead c d 0) (encodeDir d) (ahead c d) (behind c d) = _
    have rd : ahead c d 0 = (t h).toNat := by cases d <;> simp [ahead,c]
    rw [rd, table_agrees]
    exact sameRays c d (Table.machine q (t h))

def facingAfter (n : Nat) (c : Configuration 182) (d : Direction) : Direction :=
  match n with
  | 0 => d
  | k+1 => nextFacing (run Table.machine k c) (facingAfter k c d)

theorem run_agrees (n : Nat) (c : Configuration 182) (d : Direction) :
    NFSearchSweep.iterate Raw NFSearchSweep.step n (encode c d) =
    encode (run Table.machine n c) (facingAfter n c d) := by
  induction n with
  | zero => rfl
  | succ k ih =>
    change NFSearchSweep.step (NFSearchSweep.iterate Raw NFSearchSweep.step k (encode c d)) = _
    rw [ih, step_agrees]
    rfl
#print axioms run_agrees
end Reduced182.Rays
