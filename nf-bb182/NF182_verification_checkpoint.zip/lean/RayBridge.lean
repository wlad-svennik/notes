import RayPhysical
set_option maxHeartbeats 0
set_option maxRecDepth 400000
noncomputable section
namespace Reduced182.Rays
open NF210.TM
theorem norm_encode (c : Configuration 182) (d : Direction) :
    NFSearchSweep.norm (encode c d) = encode c .right := by
  cases d with
  | right => rfl
  | left =>
    have tape_eq {i j : Int} (hi : i=j) : (c.tape i).toNat = (c.tape j).toNat := by rw [hi]
    have same {q d : Nat} {a b f g : Ray} (ha : a=f) (hb : b=g) :
        NFSearchSweep.cfg q d a b = NFSearchSweep.cfg q d f g := by rw [ha,hb]
    apply same <;> funext i <;> cases i <;>
      simp [NFSearchSweep.push, NFSearchSweep.tail, ahead, behind, Nat.succ_eq_add_one]
    all_goals first | rfl | (apply tape_eq; try dsimp; omega)

theorem normalized_run (n : Nat) (c : Configuration 182) (d : Direction) :
    NFSearchSweep.norm (NFSearchSweep.iterate Raw NFSearchSweep.step n (encode c d)) =
    encode (run Table.machine n c) .right := by
  rw [run_agrees, norm_encode]

theorem halt_agrees (n : Nat) (c : Configuration 182) (d : Direction) :
    (NFSearchSweep.iterate Raw NFSearchSweep.step n (encode c d)) 0 0 = 182
      ↔ (run Table.machine n c).state = none := by
  rw [run_agrees]
  change encodeState (run Table.machine n c).state = 182 ↔ _
  cases h : (run Table.machine n c).state with
  | none => simp [encodeState]
  | some q => simp [encodeState, Nat.ne_of_lt q.isLt]

#print axioms normalized_run
#print axioms halt_agrees
end Reduced182.Rays
