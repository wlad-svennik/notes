import Lean
import LeanExport.Parse

open Lean Elab Command in
elab "read_sweep " path:str : command => do
  let f ← IO.FS.Handle.mk path.getString .read
  let data ← LeanExport.parseStream (IO.FS.Stream.ofHandle f)
  for n in data.constOrder do
    if !(`NFSearchSweep).isPrefixOf n then continue
    if (← getEnv).contains n then continue
    let some ci := data.constMap[n]? | throwError "missing declaration {n}"
    let decl ← match ci with
      | .defnInfo d => pure (Declaration.defnDecl d)
      | .thmInfo d => pure (Declaration.thmDecl d)
      | _ => throwError "unexpected declaration kind for {n}"
    liftCoreM (addDecl decl true)
