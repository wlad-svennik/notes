import NF210.MachineSemantics

namespace NFSearch.FrameInduction
open NF210.TM

/-- Finite execution ending on a halting instruction of the register program. -/
inductive Stops {S : Type} (next : S → Option S) : S → Prop where
  | last {s : S} : next s = none → Stops next s
  | more {s z : S} : next s = some z → Stops next z → Stops next s

/-- The entry condition and two kinds of conclusion checked by frame simulation. -/
structure Transfers {n : Nat} {S : Type} (machine : Machine n) (next : S → Option S)
    (frame : S → Configuration n → Prop) : Prop where
  live {s c} : frame s c → c.state ≠ none
  advance {s z c} : frame s c → next s = some z →
    ∃ ticks, 0 < ticks ∧ frame z (run machine ticks c)
  finish {s c} : frame s c → next s = none → ∃ ticks, (run machine ticks c).state = none

variable {n : Nat} {S : Type} {machine : Machine n} {next : S → Option S}
variable {frame : S → Configuration n → Prop}

theorem finite_halt (sim : Transfers machine next frame) {s : S} (hs : Stops next s)
    {c : Configuration n} (hc : frame s c) : ∃ ticks, (run machine ticks c).state = none := by
  induction hs generalizing c with
  | last z => exact sim.finish hc z
  | more h _ ih =>
    obtain ⟨t, _, hnext⟩ := sim.advance hc h
    obtain ⟨u, hu⟩ := ih hnext
    exact ⟨t+u, (run_add machine t u c) ▸ hu⟩

theorem arbitrarily_late (sim : Transfers machine next frame) (N : Nat)
    {s : S} (hs : ¬Stops next s) {c : Configuration n} (hc : frame s c) :
    ∃ k, N ≤ k ∧ (run machine k c).state ≠ none := by
  induction N generalizing s c with
  | zero => exact ⟨0, Nat.zero_le _, sim.live hc⟩
  | succ N ih =>
    cases hn : next s with
    | none => exact False.elim (hs (.last hn))
    | some nextState =>
      obtain ⟨t, ht, hnext⟩ := sim.advance hc hn
      have hns : ¬Stops next nextState := fun h => hs (.more hn h)
      obtain ⟨k,hk,hlive⟩ := ih hns hnext
      exact ⟨t+k, by omega, by simpa only [run_add] using hlive⟩

theorem from_frame_iff (sim : Transfers machine next frame) {s : S} {c : Configuration n}
    (hc : frame s c) : (∃ t, (run machine t c).state = none) ↔ Stops next s := by
  constructor
  · rintro ⟨t, ht⟩
    apply Classical.byContradiction
    intro noStop
    obtain ⟨k,hk,hlive⟩ := arbitrarily_late sim t noStop hc
    obtain ⟨u,rfl⟩ := Nat.exists_eq_add_of_le hk
    apply hlive
    rw [run_add, run_of_halted machine _ ht u]
    exact ht
  · intro hs
    exact finite_halt sim hs hc

theorem from_blank_iff (sim : Transfers machine next frame) (start : Fin n) (prefixTime : Nat)
    {s : S} (hc : frame s (run machine prefixTime (blank start))) :
    Halts machine start ↔ Stops next s := by
  constructor
  · rintro ⟨t, ht⟩
    apply (from_frame_iff sim hc).mp
    refine ⟨t, ?_⟩
    rw [← run_add, Nat.add_comm, run_add, run_of_halted machine _ ht prefixTime]
    exact ht
  · intro stop
    obtain ⟨t, ht⟩ := (from_frame_iff sim hc).mpr stop
    exact ⟨prefixTime+t, by simpa only [run_add] using ht⟩
#print axioms from_blank_iff
end NFSearch.FrameInduction
