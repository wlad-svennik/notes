import LiteralPopLoad

set_option maxHeartbeats 8000000
set_option maxRecDepth 100000
namespace PopLoadStream
open NF192.Numerical NF192.Emitter
open NF192.ProofSearch (Command candidate candidate_prefix candidate_ne_nil)
open NF192.SourceFields
abbrev State := Moving184.State
abbrev Deriv := Moving186.Deriv
abbrev observes := Moving184.observes

def step (c : Command) (s : State) : State :=
  match c with
  | .mp d => ⟨s.cache,s.stack.tail,s.stack.headD 0,s.param+d⟩
  | .mode d => Moving184.step (.mode d) s
  | .ax u y delta rest => Moving184.step (.ax u y delta rest) s

def run : List Command → State → State
  | [],s => s
  | c::cs,s => run cs (step c s)

def checkedRun : List Command → State → Option State
  | [],s => some s
  | c::cs,s => if observes c s then none else checkedRun cs (step c s)
theorem run_append (u v : List Command) (s : State) :
    run (u ++ v) s = run v (run u s) := by
  induction u generalizing s with
  | nil => rfl
  | cons c cs ih => exact ih (step c s)

theorem checkedRun_append (u v : List Command) (s : State) :
    checkedRun (u ++ v) s = (checkedRun u s).bind (checkedRun v) := by
  induction u generalizing s with
  | nil => rfl
  | cons c cs ih =>
    by_cases h : observes c s = true <;> simp [checkedRun, h, ih]

theorem checkedRun_survives {cs : List Command} {s t : State}
    (h : checkedRun cs s = some t) : t = run cs s := by
  induction cs generalizing s with
  | nil => exact (Option.some.inj h).symm
  | cons c cs ih =>
    by_cases e : observes c s = true
    · simp [checkedRun, e] at h
    · exact ih (by simpa [checkedRun, e] using h)


theorem step_sound (c : Command) (s : State) (hs : s.Sound) : (step c s).Sound := by
  cases c with
  | mode d => exact Moving184.step_sound (.mode d) s hs
  | ax a y d r => exact Moving184.step_sound (.ax a y d r) s hs
  | mp d =>
    have n := Moving184.nip_sound (⟨s.cache,s.stack,s.cache,s.param⟩ : State) ⟨hs.2.2,hs.2.1,hs.2.2⟩
    exact n

theorem detects_only_goal {cs : List Command} {s : State} (hs : s.Sound)
    (h : checkedRun cs s = none) : Deriv goal := by
  induction cs generalizing s with
  | nil => contradiction
  | cons c cs ih =>
    by_cases o : observes c s = true
    · cases c with
      | mode d => simp [observes,Moving184.observes] at o
      | ax u b d rest => simp [observes,Moving184.observes] at o
      | mp d =>
        have e : s.cache = goal := by simpa only [observes, Moving184.observes, beq_iff_eq] using o
        exact e ▸ hs.2.2
    · exact ih (step_sound c s hs) (by simpa [checkedRun, o] using h)





def lift (s : PopLoadSearch.State) : State := ⟨s.top,s.stack,s.cache,0⟩
def cmd : PopLoadSearch.Command LiteralPopLoad.AX → Command
  | .load => .mp 0
  | .mode d => .mode d
  | .emit p => .ax p.u p.y p.delta p.rest

theorem step_lift (c) (s) : step (cmd c) (lift s) = lift (PopLoadSearch.step LiteralPopLoad.system c s) := by
  cases c with
  | load => rfl
  | mode d => simp [cmd,step,lift,Moving184.step,Moving184.nip,PopLoadSearch.step,PopLoadSearch.park,LiteralPopLoad.system] <;> rfl
  | emit p => rfl

theorem run_lift (w) (s) : run (w.map cmd) (lift s) = lift (PopLoadSearch.run LiteralPopLoad.system w s) := by
  induction w generalizing s with
  | nil => rfl
  | cons c cs ih => simp only [List.map_cons,run,step_lift,PopLoadSearch.run,ih]

def payload (s : State) : PopLoadSearch.State := ⟨s.top,s.stack,s.cache⟩
private theorem after_reset (s : State) : step (.mode 0) s = lift (payload (step (.mode 0) s)) := rfl

theorem exists_detecting_word (d : Deriv goal) : ∃ cs : List Command, ∀ s, checkedRun cs s = none := by
  obtain ⟨w,hw⟩ := LiteralPopLoad.uniform_exact_detector d
  refine ⟨.mode 0 :: (w.map cmd ++ [.mp 0]),fun s => ?_⟩
  change checkedRun (w.map cmd ++ [.mp 0]) (step (.mode 0) s) = none
  let v := payload (step (.mode 0) s)
  rw [after_reset s,checkedRun_append]
  change (checkedRun (w.map cmd) (lift v)).bind (checkedRun [.mp 0]) = none
  cases eq : checkedRun (w.map cmd) (lift v) with
  | none => rfl
  | some t =>
    have e := checkedRun_survives eq
    rw [run_lift] at e
    subst t
    have h := hw v
    simp [checkedRun,observes,Moving184.observes,lift,h]

def one (c : Command) (s : State) : Option State :=
  if observes c s then none else some (step c s)

theorem checkedRun_cons (c : Command) (cs : List Command) (s : State) :
    checkedRun (c::cs) s = (one c s).bind (checkedRun cs) := by
  by_cases h : observes c s = true <;> simp [checkedRun, one, h]

def scan (start : Nat) (s : State) : Nat → Option State
  | 0 => some s
  | k+1 => (scan start s k).bind (checkedRun (candidate (start+k)))

theorem scan_eventually_halts (d : Deriv goal) (start : Nat) (s : State) :
    ∃ k, scan start s k = none := by
  obtain ⟨cs, universal⟩ := exists_detecting_word d
  obtain ⟨n, hn, hword⟩ := cofinal cs start
  have idx : start + (n-start) = n := by omega
  refine ⟨(n-start)+1, ?_⟩
  rw [scan,idx,candidate_prefix hword]
  cases h : scan start s (n-start) with
  | none => rfl
  | some old =>
    simp only [Option.bind_some, checkedRun_append, universal, Option.bind_none]

structure StreamState where
  next : Nat
  cursor : Nat
  proof : State

def streamStep (s : StreamState) : Option StreamState :=
  let fresh := s.cursor = 0
  let input := if fresh then s.next else s.cursor-1
  let next := if fresh then s.next+1 else s.next
  let parsed := parse input
  (one parsed.1 s.proof).map (fun result => ⟨next,parsed.2,result⟩)

def streamRun : Nat → StreamState → Option StreamState
  | 0,s => some s
  | n+1,s => (streamStep s).bind (streamRun n)

theorem stream_run_add (n m : Nat) (s : StreamState) :
    streamRun (n+m) s = (streamRun n s).bind (streamRun m) := by
  induction n generalizing s with
  | zero => simp only [Nat.zero_add, streamRun, Option.bind_some]
  | succ n ih =>
    rw [Nat.succ_add, streamRun, streamRun]
    cases h : streamStep s with
    | none => rfl
    | some t => simpa only [Option.bind_some] using ih t

theorem stream_continued (n next : Nat) (s : State) :
    streamStep ⟨next,n+1,s⟩ =
      (one (parse n).1 s).map (fun t => ⟨next,(parse n).2,t⟩) := by
  simp [streamStep]

theorem stream_candidate (n next : Nat) (s : State) :
    streamRun (candidate n).length ⟨next,n+1,s⟩ =
      (checkedRun (candidate n) s).map (fun t => ⟨next,0,t⟩) := by
  induction n using Nat.strongRecOn generalizing s with
  | ind n ih =>
    rw [candidate]
    simp only [List.length_cons, streamRun, stream_continued, checkedRun_cons]
    cases hs : one (parse n).1 s with
    | none => rfl
    | some t =>
      simp only [Option.map_some, Option.bind_some]
      by_cases hz : (parse n).2 = 0
      · simp [hz, streamRun, checkedRun]
      · simp only [hz, ↓reduceDIte]
        have hlt : (parse n).2 - 1 < n := by
          have hle := parse_decreases n
          omega
        have he : (parse n).2 = ((parse n).2-1)+1 := by omega
        rw [he]
        exact ih ((parse n).2-1) hlt t

theorem stream_fresh (n : Nat) (s : State) :
    streamStep ⟨n,0,s⟩ = streamStep ⟨n+1,n+1,s⟩ := by simp [streamStep]

theorem stream_candidate_fresh (n : Nat) (s : State) :
    streamRun (candidate n).length ⟨n,0,s⟩ =
      (checkedRun (candidate n) s).map (fun t => ⟨n+1,0,t⟩) := by
  have he := stream_candidate n (n+1) s
  have hn := List.length_pos_iff.mpr (candidate_ne_nil n)
  obtain ⟨m,hm⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : (candidate n).length ≠ 0)
  rw [hm, streamRun, stream_fresh]
  simpa only [hm, streamRun] using he

theorem scan_reached (start : Nat) (s : State) (k : Nat) :
    ∃ ticks, streamRun ticks ⟨start,0,s⟩ = (scan start s k).map (fun t => ⟨start+k,0,t⟩) := by
  induction k with
  | zero => exact ⟨0,rfl⟩
  | succ n ih =>
    obtain ⟨ticks,ht⟩ := ih
    refine ⟨ticks+(candidate (start+n)).length, ?_⟩
    rw [stream_run_add, ht, scan]
    cases hs : scan start s n with
    | none => rfl
    | some s => exact stream_candidate_fresh (start+n) s

def StreamSound : Option StreamState → Prop
  | none => Deriv goal
  | some s => s.proof.Sound

theorem stream_step_sound (s : StreamState) (hs : s.proof.Sound) :
    StreamSound (streamStep s) := by
  simp only [streamStep]
  generalize parse (if s.cursor = 0 then s.next else s.cursor-1) = parsed
  rcases parsed with ⟨c, tail⟩
  by_cases o : observes c s.proof = true
  · have halt : checkedRun [c] s.proof = none := by simp [checkedRun, o]
    simpa [one, o, StreamSound] using detects_only_goal hs halt
  · simpa [one, o, StreamSound] using step_sound c s.proof hs

theorem stream_run_sound (ticks : Nat) (s : StreamState) (hs : s.proof.Sound) :
    StreamSound (streamRun ticks s) := by
  induction ticks generalizing s with
  | zero => exact hs
  | succ n ih =>
    have hc := stream_step_sound s hs
    cases he : streamStep s with
    | none => simpa only [streamRun, he, Option.bind_none] using hc
    | some t =>
      have ht : t.proof.Sound := by simpa only [he, StreamSound] using hc
      simpa only [streamRun, he, Option.bind_some] using ih t ht

/-- For every sound entry at a refill boundary, the successive natural
candidates halt exactly when the numerical calculus derives numeral 3. -/
theorem stream_halting_iff_goal (start : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, streamRun ticks ⟨start,0,s⟩ = none) ↔ Deriv goal := by
  constructor
  · rintro ⟨ticks, ht⟩
    simpa only [ht, StreamSound] using stream_run_sound ticks ⟨start,0,s⟩ hs
  · intro h
    obtain ⟨k,hk⟩ := scan_eventually_halts h start s
    obtain ⟨ticks,ht⟩ := scan_reached start s k
    exact ⟨ticks, by simpa only [hk, Option.map_none] using ht⟩


#print axioms stream_halting_iff_goal
end PopLoadStream
