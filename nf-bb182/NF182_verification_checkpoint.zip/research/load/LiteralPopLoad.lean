import PopLoadSearch
import Moving184Search

namespace LiteralPopLoad
open NF192.Numerical NF192.Emitter
set_option maxHeartbeats 8000000
set_option maxRecDepth 100000

structure AX where
  u : Nat
  y : Nat
  delta : Nat
  rest : List (Nat × Nat)

def raw (p : AX) (h : Nat) : List Nat :=
  Moving184.rows p.u p.y p.delta p.rest ⟨0,[],h,0⟩

def retained (p : AX) (h : Nat) := (raw p h).reverse.tail

def GroundAxiom (x : Nat) := ∃ a b c u, u ≤ a ∧ x ∈ Moving184.rowList a b c u

private theorem tailAxiom (a b : Nat) (r : List (Nat×Nat)) : ∀ x ∈ Moving184.tailRows a b r, GroundAxiom x := by
  induction r generalizing a b with
  | nil => intro x hx; cases hx
  | cons t ts ih =>
    rcases t with ⟨y,d⟩
    intro x hx
    rcases List.mem_append.mp hx with hf|ht
    · exact ⟨a+d,b+y,ts.length,a,Nat.le_add_right _ _,hf⟩
    · exact ih _ _ _ ht

private theorem isRow (p : AX) (h x : Nat) (mem : x ∈ retained p h) : GroundAxiom x := by
  have hr : x ∈ raw p h := List.mem_reverse.mp (List.mem_of_mem_tail mem)
  simp only [raw,Moving184.rows,Nat.zero_add] at hr
  rcases List.mem_append.mp hr with hf|ht
  · exact ⟨p.u+p.delta,h+p.y,p.rest.length,p.u,Nat.le_add_right _ _,hf⟩
  · exact tailAxiom _ _ _ _ ht

private theorem retained_prefix {l r : List Nat} {x : Nat} (hm : x ∈ l) (hr : r ≠ []) : x ∈ (l ++ r).reverse.tail := by
  rw [List.reverse_append]
  cases eq : r.reverse with
  | nil =>
    have er := congrArg List.reverse eq
    simp only [List.reverse_reverse,List.reverse_nil] at er
    exact False.elim (hr er)
  | cons v vs => exact List.mem_append_right vs (List.mem_reverse.mpr hm)

private theorem coverage_aux {a b c u x : Nat} (bound : u ≤ a)
    (h : x ∈ (Moving184.rowList a b c u).take 7 ∨ 0 < c ∧ x ∈ Moving184.rowList a b c u) :
    ∃ p, x ∈ retained p 0 := by
  let rest := List.replicate c (0,0)
  let p : AX := ⟨u,b,a-u,rest⟩
  refine ⟨p,?_⟩
  change x ∈ (Moving184.rows u b (a-u) rest ⟨0,[],0,0⟩).reverse.tail
  simp only [Moving184.rows,rest,List.length_replicate,Nat.zero_add,show u+(a-u)=a by omega]
  rcases h with h|⟨hc,h⟩
  · rw [Moving184.last_row_split a b c u,List.append_assoc]
    exact retained_prefix h (by simp)
  · apply retained_prefix h
    cases c with | zero => omega | succ n => simp [List.replicate_succ,Moving184.tailRows,Moving184.rowList,Moving186.rowList]

private theorem cover {x} (hx : GroundAxiom x) : ∃ p, x ∈ retained p 0 := by
  obtain ⟨a,b,c,u,hu,h⟩ := hx
  rw [Moving184.last_row_split a b c u] at h
  rcases List.mem_append.mp h with hp|hl
  · exact coverage_aux hu (.inl hp)
  · have he : x = Moving184.lastRow a b := by simpa using hl
    subst x
    apply coverage_aux (a:=a) (b:=b) (c:=1) (u:=u) hu
    exact .inr ⟨by decide,by simp [Moving184.rowList,Moving186.rowList]⟩

def system : PopLoadSearch.System AX where
  imp := imp
  isAxiom := GroundAxiom
  retained := retained
  resetParam := ⟨0,0,0,[]⟩
  resetCount := 6
  resetLen := fun h => by simp [retained,raw,Moving184.rows,Moving184.tailRows,Moving184.rowList,Moving186.rowList]
  cover := cover
  trueRow := isRow

theorem deriv_iff {x : Nat} : PopLoadSearch.Deriv system x ↔ Moving186.Deriv x := by
  constructor
  · intro h
    induction h with
    | zero => exact Moving186.deriv_zero
    | row h => obtain ⟨a,b,c,u,hu,m⟩ := h; exact Moving186.Deriv.row hu m
    | mp _ _ a b => exact Moving186.Deriv.mp a b
  · intro h
    induction h with
    | @row a b c u x hu hx => exact PopLoadSearch.Deriv.row ⟨a,b,c,u,hu,hx⟩
    | mp _ _ a b => exact PopLoadSearch.Deriv.mp a b

theorem exact_detector (s : PopLoadSearch.State) (hs : s.Sound system) :
    (∃ w, (PopLoadSearch.run system w s).cache = goal) ↔ Moving186.Deriv goal :=
  (PopLoadSearch.detects_iff system goal s hs).trans deriv_iff

theorem uniform_exact_detector (h : Moving186.Deriv goal) :
    ∃ w, ∀ s, (PopLoadSearch.run system w s).cache = goal :=
  PopLoadSearch.uniform_detect system (deriv_iff.mpr h)

#print axioms exact_detector
#print axioms uniform_exact_detector
end LiteralPopLoad
