import Init

namespace PopLoadSearch

/-- `retained p h` lists the axiom rows in machine pop order. The standard
8-row emitter retains seven rows of its last batch, and the one-shot push5
variant retains all eight. Only a reset command of fixed positive length is
needed to reproduce NIP with unconditional load-and-pop. -/
structure System (P : Type) where
  imp : Nat → Nat → Nat
  isAxiom : Nat → Prop
  retained : P → Nat → List Nat
  resetParam : P
  resetCount : Nat
  resetLen (h) : (retained resetParam h).length = resetCount + 1
  cover {x} : isAxiom x → ∃ p, x ∈ retained p 0
  trueRow (p h x) : x ∈ retained p h → isAxiom x

structure State where
  top : Nat
  stack : List Nat
  cache : Nat
  deriving DecidableEq, Repr

def park (t : Nat) (q : List Nat) : State := ⟨t,q.tail,q.headD 0⟩
@[simp] theorem park_cons (t q : Nat) (qs : List Nat) : park t (q::qs) = ⟨t,qs,q⟩ := rfl
inductive Command (P : Type) where | load | mode (d : Nat) | emit (p : P)
variable {P : Type} (L : System P)

def step : Command P → State → State
  | .load,s => park s.cache s.stack
  | .mode d,s => park (if s.cache = L.imp s.top d then d else 0) s.stack
  | .emit p,s => park 0 (L.retained p s.cache ++ s.top::s.stack)

def run : List (Command P) → State → State
  | [],s => s
  | c::cs,s => run cs (step L c s)

theorem run_append (a b : List (Command P)) (s) : run L (a ++ b) s = run L b (run L a s) := by
  induction a generalizing s with | nil => rfl | cons c a ih => exact ih _

def loads (n : Nat) : List (Command P) := List.replicate n .load

private theorem shift (pre tail : List Nat) (t x : Nat) :
    run L (loads (pre.length + 1)) (park t (pre ++ x :: tail)) = park x tail := by
  induction pre generalizing t with
  | nil => rfl
  | cons y ys ih =>
    change run L (loads (ys.length+1)) (park y (ys ++ x :: tail)) = _
    exact ih y

/-- Materialize the current top in the AX stack, then select it as the last
LOAD. That final LOAD places the original stack head in cache at the same time. -/
def nipWord : List (Command P) := .emit L.resetParam :: loads (L.resetCount + 2)

theorem nip_eval (s : State) : run L (nipWord L) s = park s.top s.stack := by
  unfold nipWord
  change run L (loads (L.resetCount+2)) (park 0 (L.retained L.resetParam s.cache ++ s.top::s.stack)) = _
  have h := shift L (L.retained L.resetParam s.cache) s.stack 0 s.top
  simpa only [L.resetLen] using h

def nips (L : System P) : Nat → List (Command P)
  | 0 => []
  | n+1 => nipWord L ++ nips L n

private theorem skip (pre tail : List Nat) (t : Nat) :
    run L (nips L pre.length) (park t (pre ++ tail)) = park t tail := by
  induction pre with
  | nil => rfl
  | cons x xs ih =>
    rw [List.length_cons,nips,run_append,nip_eval]
    exact ih

def sweep : List (Command P) := .emit L.resetParam :: nips L L.resetCount

private theorem lastSplit (xs : List Nat) (ne : xs ≠ []) : ∃ pre c, xs = pre ++ [c] := by
  induction xs with
  | nil => exact False.elim (ne rfl)
  | cons x xs ih =>
    cases xs with
    | nil => exact ⟨[],x,rfl⟩
    | cons y ys =>
      obtain ⟨p,c,h⟩ := ih (List.cons_ne_nil _ _)
      exact ⟨x::p,c,congrArg (List.cons x) h⟩

private theorem sweep_eval (s : State) : ∃ c, run L (sweep L) s = ⟨0,s.top::s.stack,c⟩ := by
  let vs := L.retained L.resetParam s.cache
  have hv : vs.length = L.resetCount + 1 := L.resetLen _
  have ne : vs ≠ [] := by intro e; simp [e] at hv
  obtain ⟨pre,c,eq⟩ := lastSplit vs ne
  have len : pre.length = L.resetCount := by rw [eq] at hv; simpa using hv
  refine ⟨c,?_⟩
  change run L (nips L L.resetCount) (park 0 (vs ++ s.top::s.stack)) = _
  rw [eq,List.append_assoc,←len]
  exact skip L pre (c::s.top::s.stack) 0

def reset : List (Command P) := sweep L ++ sweep L ++ [.mode 0]

theorem reset_eval (s : State) : run L (reset L) s = ⟨0,s.top::s.stack,0⟩ := by
  obtain ⟨a,ha⟩ := sweep_eval L s
  obtain ⟨b,hb⟩ := sweep_eval L ⟨0,s.top::s.stack,a⟩
  simp only [reset,run_append,ha,hb,run,step,ite_self,park_cons]

def Builds (x : Nat) (w : List (Command P)) : Prop :=
  ∀ s,run L w s = ⟨x,s.top::s.stack,0⟩

private theorem splitMember {x : Nat} {xs : List Nat} (h : x ∈ xs) : ∃ pre post, xs = pre ++ x::post := by
  induction xs with
  | nil => cases h
  | cons a xs ih =>
    rcases List.mem_cons.mp h with rfl|hs
    · exact ⟨[],xs,rfl⟩
    · obtain ⟨p,q,e⟩ := ih hs; exact ⟨a::p,q,congrArg (List.cons a) e⟩

theorem build_row {x} (hx : L.isAxiom x) : ∃ w, Builds L x w := by
  obtain ⟨p,hp⟩ := L.cover hx
  obtain ⟨pre,post,eq⟩ := splitMember hp
  refine ⟨reset L ++ (.emit p :: (loads (pre.length+1) ++ nips L post.length)),?_⟩
  intro s
  rw [run_append,reset_eval]
  change run L (loads (pre.length+1) ++ nips L post.length) (park 0 (L.retained p 0 ++ 0::s.top::s.stack)) = _
  rw [eq,List.append_assoc,run_append]
  have h := shift L pre (post ++ 0::s.top::s.stack) 0 x
  rw [show x::post ++ 0::s.top::s.stack = x::(post ++ 0::s.top::s.stack) from rfl,h]
  exact skip L post (0::s.top::s.stack) x

/-- Produce the major first. Building the minor saves that major immediately
above the zero sentinel. A simulated NIP now presents the desired MP pair. -/
theorem build_mp {a b : Nat} {M m : List (Command P)} (hM : Builds L (L.imp a b) M) (hm : Builds L a m) :
    Builds L b (reset L ++ M ++ m ++ nipWord L ++ [.mode b]) := by
  intro s
  rw [run_append,run_append,run_append,run_append,reset_eval,hM,hm,nip_eval]
  simp [run,step,park]

inductive Deriv : Nat → Prop
  | zero : Deriv 0
  | row {x} : L.isAxiom x → Deriv x
  | mp {a b} : Deriv (L.imp a b) → Deriv a → Deriv b

theorem buildable {x} (d : Deriv L x) : ∃ w, Builds L x w := by
  induction d with
  | zero => exact ⟨reset L,reset_eval L⟩
  | row h => exact build_row L h
  | mp _ _ maj min => obtain ⟨u,hu⟩ := maj; obtain ⟨v,hv⟩ := min; exact ⟨_,build_mp L hu hv⟩

def State.Sound (s : State) := Deriv L s.top ∧ Deriv L s.cache ∧ ∀ x∈s.stack, Deriv L x

private theorem park_sound (t : Nat) (q : List Nat) (h : Deriv L t) (hq : ∀ x∈q, Deriv L x) : (park t q).Sound L := by
  cases q with
  | nil => exact ⟨h,.zero,by intro x hx; cases hx⟩
  | cons a xs => exact ⟨h,hq a (by simp),fun x hx => hq x (List.mem_cons_of_mem a hx)⟩

theorem step_sound (c : Command P) (s : State) (h : s.Sound L) : (step L c s).Sound L := by
  obtain ⟨ht,hc,hs⟩ := h
  cases c with
  | load => exact park_sound L _ _ hc hs
  | mode b =>
    apply park_sound L _ _ _ hs
    split
    next e => exact Deriv.mp (e ▸ hc) ht
    next _ => exact Deriv.zero
  | emit p =>
    apply park_sound L _ _ Deriv.zero
    intro x hx
    rcases List.mem_append.mp hx with hx|hx
    · exact Deriv.row (L.trueRow _ _ _ hx)
    · rcases List.mem_cons.mp hx with rfl|h <;> first | exact ht | exact hs x h

theorem run_sound (cs : List (Command P)) (s : State) (h : s.Sound L) : (run L cs s).Sound L := by
  induction cs generalizing s with
  | nil => exact h
  | cons c cs ih => exact ih (step L c s) (step_sound L c s h)

private theorem cache_after_prefix (pre tail : List Nat) (t : Nat) :
    (run L (loads pre.length) (park t (pre ++ tail))).cache = tail.headD 0 := by
  induction pre generalizing t with
  | nil => rfl
  | cons a pre ih => exact ih a

def expose : List (Command P) := .emit L.resetParam :: loads (L.resetCount+1)

theorem expose_eval (s : State) : (run L (expose L) s).cache = s.top := by
  change (run L (loads (L.resetCount+1)) (park 0 (L.retained L.resetParam s.cache ++ s.top::s.stack))).cache = _
  rw [←L.resetLen s.cache]
  exact cache_after_prefix L _ _ 0

/-- A single finite word makes the goal observable from every initial payload.
The following LOAD tests that cache before making its transfer. -/
theorem detects_iff (goal : Nat) (s : State) (hs : s.Sound L) :
    (∃ word, (run L word s).cache = goal) ↔ Deriv L goal := by
  constructor
  · rintro ⟨word,h⟩
    exact h ▸ (run_sound L word s hs).2.1
  · intro h
    obtain ⟨word,hw⟩ := buildable L h
    refine ⟨word ++ expose L,?_⟩
    rw [run_append,expose_eval,hw]

theorem uniform_detect {goal : Nat} (h : Deriv L goal) :
    ∃ word, ∀ s, (run L word s).cache = goal := by
  obtain ⟨word,hw⟩ := buildable L h
  refine ⟨word ++ expose L,fun s => ?_⟩
  rw [run_append,expose_eval,hw]

#print axioms detects_iff
#print axioms uniform_detect
#print axioms nip_eval
#print axioms buildable
#print axioms step_sound
end PopLoadSearch
