import SourceFields
import Moving184Search
open NF192.Numerical NF192.Numerical.Cantor
namespace Stride
set_option maxHeartbeats 3000000

theorem triangle_jump (n m : Nat) :
    triangle (n+2*m) = triangle n + m + (2*m)*(n+m) := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [show n+2*(m+1) = n+2*m+1+1 by omega]
    rw [triangle_succ,triangle_succ,ih]
    grind

def Jump (F : Nat → Nat) := ∀ n m, ∃ s : Int,
  (F (n+2*m) : Int) = F n + m + 2*m*s

def Cong (m x y : Nat) := ∃ z : Int, (x:Int)-(y:Int) = (m:Int)*z

theorem inner_jump (tail : Nat) : Jump (fun u => pair u tail) := by
  intro n m
  refine ⟨n+tail+m,?_⟩
  change ((triangle (n+2*m+tail)+tail:Nat):Int) = ((triangle (n+tail)+tail:Nat):Int) + _ + _
  rw [show n+2*m+tail = (n+tail)+2*m by omega, triangle_jump]
  push_cast
  grind

theorem outer_jump : Jump (fun z => pair 0 z) := by
  intro n m
  refine ⟨n+m+1,?_⟩
  change ((triangle (0+(n+2*m))+(n+2*m):Nat):Int) = ((triangle (0+n)+n:Nat):Int) + _ + _
  simp only [Nat.zero_add, triangle_jump, Int.natCast_add, Int.natCast_mul]
  grind

theorem realizes (F : Nat → Nat) (h : Jump F) (k target bound : Nat) :
    ∃ x, bound ≤ x ∧ Cong (2^k) (F x) target := by
  induction k with
  | zero =>
    exact ⟨bound,Nat.le_refl _,(F bound:Int)-(target:Int),by simp⟩
  | succ k ih =>
    obtain ⟨x,hx,j,hj⟩ := ih
    let m := 2^k
    change (F x:Int)-(target:Int) = (m:Int)*j at hj
    rw [Nat.pow_succ]
    by_cases even : j%2=0
    · refine ⟨x,hx,j/2,?_⟩
      have hdiv : j=2*(j/2) := by omega
      change (F x:Int)-(target:Int) = ((m*2:Nat):Int)*(j/2)
      rw [hj]
      simp only [Int.natCast_mul]
      grind
    · obtain ⟨s,hs⟩ := h x m
      refine ⟨x+2*m, by omega, j/2+s+1,?_⟩
      have hdiv : j=2*(j/2)+1 := by omega
      change (F (x+2*m):Int)-(target:Int) = ((m*2:Nat):Int)*(j/2+s+1)
      rw [hs]
      simp only [Int.natCast_mul]
      grind

theorem outer_twice (z : Nat) :
    2 * (pair 0 z : Int) = (z:Int)*(z+3) := by
  induction z with
  | zero => decide
  | succ z ih =>
    simp only [pair_eq, Nat.zero_add,triangle_succ,Int.natCast_add,Int.natCast_succ] at *
    grind

theorem outer_cong (m n z : Nat) (h : Cong (2*m) n z) :
    Cong m (pair 0 n) (pair 0 z) := by
  obtain ⟨j,hj⟩ := h
  refine ⟨j*((n:Int)+z+3),?_⟩
  have a := outer_twice n
  have b := outer_twice z
  simp only [Int.natCast_mul] at hj
  grind

theorem padded_input (k target bound tail : Nat) :
    ∃ u input, bound ≤ input ∧ Cong (2^k) input target ∧
      NF192.SourceFields.parse input = (.mp u,tail) := by
  obtain ⟨z,_,v,hv⟩ := realizes _ outer_jump k target 0
  obtain ⟨u,hu,hi⟩ := realizes _ (inner_jump tail) (k+1) z bound
  have hi' : Cong (2*(2^k)) (pair u tail) z := by simpa [Nat.pow_succ,Nat.mul_comm] using hi
  obtain ⟨j,hj⟩ := outer_cong _ _ _ hi'
  refine ⟨u,pair 0 (pair u tail),Nat.le_trans hu (Nat.le_trans (pair_ge_left u tail) (pair_ge_right 0 _)),⟨j+v,?_⟩,?_⟩
  · change (pair 0 (pair u tail):Int)-(target:Int) = _ 
    grind
  · exact NF192.SourceFields.parse_assemble (.mp u) tail

theorem padded_word (k target bound : Nat) (cs : List NF192.ProofSearch.Command) :
    ∃ input u, bound ≤ input ∧ Cong (2^k) input target ∧
      NF192.SourceFields.Matches (.mp u :: cs) input 0 := by
  obtain ⟨u,n,hn,hr,hparse⟩ := padded_input k target bound (NF192.SourceFields.encode cs 0+1)
  exact ⟨n,u,hn,hr,.cons hparse (NF192.SourceFields.matches_encoding cs 0)⟩
#print axioms padded_word
theorem proof_word_at_stride (k start : Nat) (h : Moving184.Deriv goal) :
    ∃ j : Nat, ∀ s, Moving184.checkedRun (NF192.ProofSearch.candidate (start+(2^k)*j)) s = none := by
  obtain ⟨cs,hcs⟩ := Moving184.exists_detecting_word h
  obtain ⟨n,u,hn,⟨j,hj⟩,hm⟩ := padded_word k start start cs
  have pos : (0:Int)<((2^k:Nat):Int) := by exact_mod_cast Nat.pow_pos (by decide : 0<2)
  have hj0 : 0≤j := by
    by_cases hjneg : j<0
    · have bad := Int.mul_neg_of_pos_of_neg pos hjneg
      omega
    · omega
  have hc : (j.toNat:Int)=j := Int.toNat_of_nonneg hj0
  have hi : start+(2^k)*j.toNat = n := by
    apply Int.ofNat_inj.mp
    simp only [Int.natCast_add,Int.natCast_mul,hc]
    omega
  refine ⟨j.toNat,fun s => ?_⟩
  rw [hi,NF192.ProofSearch.candidate_prefix hm]
  change Moving184.checkedRun (.mp u :: (cs ++ _)) s = none
  rw [Moving184.checkedRun_cons]
  cases e : Moving184.one (.mp u) s with
  | none => rfl
  | some t => simp [Moving184.checkedRun_append,hcs]
#print axioms proof_word_at_stride
open Moving184 (State checkedRun)

def resetScan (reset : Nat → State → State) (k start : Nat) (initial : State) :
    Nat → Option State
  | 0 => some initial
  | j+1 => (resetScan reset k start initial j).bind
      (fun s => checkedRun (NF192.ProofSearch.candidate (start+(2^k)*j)) (reset j s))

private def soundResult : Option State → Prop
  | none => Moving184.Deriv goal
  | some s => s.Sound

private theorem checked_sound (cs : List NF192.ProofSearch.Command) (s : State) (hs : s.Sound) :
    soundResult (checkedRun cs s) := by
  induction cs generalizing s with
  | nil => exact hs
  | cons c cs ih =>
    by_cases h : Moving184.observes c s = true
    · have halt : checkedRun [c] s = none := by simp [Moving184.checkedRun,h]
      simpa only [Moving184.checkedRun,h,ite_true,soundResult] using Moving184.detects_only_goal hs halt
    · simpa [Moving184.checkedRun,h] using ih (Moving184.step c s) (Moving184.step_sound c s hs)

theorem reset_scan_halting_iff_goal (reset : Nat → State → State)
    (hsafe : ∀ j s, s.Sound → (reset j s).Sound) (k start : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, resetScan reset k start s ticks = none) ↔ Moving184.Deriv goal := by
  constructor
  · rintro ⟨ticks,h⟩
    have safe (n : Nat) : soundResult (resetScan reset k start s n) := by
      induction n with
      | zero => exact hs
      | succ n ih =>
        rw [resetScan]
        cases he : resetScan reset k start s n with
        | none => simpa only [he,soundResult,Option.bind_none] using ih
        | some t =>
          exact checked_sound _ _ (hsafe n t (by simpa only [he,soundResult] using ih))
    have a := safe ticks
    simpa only [h,soundResult] using a
  · intro d
    obtain ⟨j,hj⟩ := proof_word_at_stride k start d
    refine ⟨j+1,?_⟩
    rw [resetScan]
    cases resetScan reset k start s j with
    | none => rfl
    | some t => exact hj (reset j t)
#print axioms reset_scan_halting_iff_goal
end Stride
