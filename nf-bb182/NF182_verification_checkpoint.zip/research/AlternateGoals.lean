import Moving186Logic

namespace AlternateGoals
open NF192.Numerical (app eqn konst imp goal s q witness)
open NF192.Emitter (row2 row3 row4 row6)
open Moving186
set_option maxHeartbeats 3000000
set_option maxRecDepth 50000

private theorem tester (x y : Nat) : Deriv (testRow x y) :=
  .row (a:=y) (b:=x) (c:=0) (u:=0) (Nat.zero_le _) (by simp [rowList])
private theorem eu (a b c : Nat) : Deriv (row6 a b c) :=
  .row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [rowList])
private theorem fn (a b c : Nat) : Deriv (row3 a b c) :=
  .row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [rowList])
private theorem arg (a b c : Nat) : Deriv (row2 a b c) :=
  .row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [rowList])
private theorem constant (x y : Nat) : Deriv (eqn (app (konst x) y) x) :=
  .row (a:=y) (b:=x) (c:=0) (u:=0) (Nat.zero_le _) (by simp [rowList,row4])
private theorem abstractB (c a b : Nat) : Deriv (bRow a b c) :=
  .row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [rowList])

private theorem reflex (x : Nat) : Deriv (eqn x x) :=
  .mp (tester x x) (logic_identity _)
private theorem symmF {G : Nat → Prop} {a b} (h : From G (eqn a b)) : From G (eqn b a) :=
  .mp (.mp (.proved (eu a a b)) (.proved (reflex a))) h
private theorem transF {G : Nat → Prop} {a b c} (h : From G (eqn a b)) (j : From G (eqn b c)) : From G (eqn a c) :=
  .mp (.mp (.proved (eu b c a)) j) (symmF h)
private theorem fnF {G : Nat → Prop} {a b} (h : From G (eqn a b)) (y : Nat) : From G (eqn (app a y) (app b y)) :=
  symmF (.mp (.proved (fn a y b)) h)
private theorem argF {G : Nat → Prop} {a b} (x : Nat) (h : From G (eqn a b)) : From G (eqn (app x a) (app x b)) :=
  .mp (.proved (arg x b a)) h
private theorem up {G : Nat → Prop} {a b} (h : From G a) : From (fun x => G x ∨ x=b) a :=
  From.monotone (fun _ hx => Or.inl hx) h
private theorem last {G : Nat → Prop} {b} : From (fun x => G x ∨ x=b) b :=
  .assumption (.inr rfl)

private theorem consequence {G : Nat → Prop} {p g k}
    (rule : From G (imp (imp g k) p)) (body : From G (imp g p)) : From G p := by
  apply From.mp (.proved (logic_peirce p k))
  apply From.deduction
  exact .mp (up rule) (From.imp_trans (up body) last)

private theorem symmetricProbe {G : Nat → Prop} (h : From G (eqn (app s q) q)) (x y : Nat) :
    From G (eqn (single x y) (single y x)) := by
  apply transF (fnF (fnF (symmF h) (konst x)) y)
  apply transF (.proved (abstractB q (konst x) y))
  exact argF (app q (konst y)) (.proved (constant x y))

/-- If BJ=J, the two applications of the tester away from its diagonal
return opposing endpoints for one and the same probe. -/
theorem equation_of_bj_eq_j (h : Deriv (eqn (app s q) q)) (x y : Nat) : Deriv (eqn y x) := by
  apply From.no_assumptions
  apply consequence (.proved (tester x y))
  apply From.deduction
  let e := eqn (single x y) x
  have offx : From (fun r => False ∨ r=e) e := last
  have swap : From (fun r => False ∨ r=e) (imp (eqn x y) (eqn y x)) := From.deduction (symmF last)
  apply consequence (From.imp_trans (.proved (tester y x)) swap)
  apply From.deduction
  exact transF (symmF last) (transF (symmF (symmetricProbe (.proved h) x y)) (up offx))

theorem equation_of_goal (h : Deriv goal) (x y : Nat) : Deriv (eqn x y) := by
  apply equation_of_bj_eq_j _ y x
  exact From.no_assumptions (transF (fnF (.proved h) q) (.proved h))

private theorem goal_of_kj_eq_j (h : Deriv (eqn (konst q) q)) : Deriv goal :=
  From.no_assumptions (transF (symmF (fnF (.proved h) q)) (.proved (constant q q)))
private theorem goal_of_b_eq_kj (h : Deriv (eqn s (konst q))) : Deriv goal :=
  equation_of_bj_eq_j (From.no_assumptions (transF (fnF (.proved h) q) (.proved (constant q q)))) q s
private theorem flip {a b} (h : Deriv (eqn a b)) : Deriv (eqn b a) :=
  From.no_assumptions (symmF (.proved h))

theorem goal_iff_5 : Deriv goal ↔ Deriv 5 := ⟨fun h => equation_of_goal h q s, fun h => flip (a:=q) (b:=s) h⟩
theorem goal_iff_7 : Deriv goal ↔ Deriv 7 := ⟨fun h => equation_of_goal h (konst q) q, goal_of_kj_eq_j⟩
theorem goal_iff_11 : Deriv goal ↔ Deriv 11 := ⟨fun h => equation_of_goal h q (konst q), fun h => goal_of_kj_eq_j (flip (a:=q) (b:=konst q) h)⟩
theorem goal_iff_13 : Deriv goal ↔ Deriv 13 := ⟨fun h => equation_of_goal h (app s q) q, fun h => equation_of_bj_eq_j h q s⟩
theorem goal_iff_15 : Deriv goal ↔ Deriv 15 := ⟨fun h => equation_of_goal h (konst q) s, fun h => goal_of_b_eq_kj (flip (a:=konst q) (b:=s) h)⟩
theorem goal_iff_17 : Deriv goal ↔ Deriv 17 := ⟨fun h => equation_of_goal h s (konst q), goal_of_b_eq_kj⟩
theorem goal_iff_19 : Deriv goal ↔ Deriv 19 := ⟨fun h => equation_of_goal h q (app s q), fun h => equation_of_bj_eq_j (flip (a:=q) (b:=app s q) h) q s⟩


private theorem goal_of_bj_eq_b (h : Deriv (eqn (app s q) s)) : Deriv goal := by
  apply From.no_assumptions
  apply consequence (.proved (tester q s))
  apply From.deduction
  have e : From (fun r => False ∨ r=eqn (single q s) q) (eqn (single q s) q) := last
  have bbb : From (fun r => False ∨ r=eqn (single q s) q) (eqn (app (app (app s q) q) q) s) :=
    transF (fnF (fnF (.proved h) q) q) (transF (fnF (.proved h) q) (.proved h))
  exact transF (symmF bbb) (transF (.proved (abstractB q q q)) e)

theorem goal_iff_23 : Deriv goal ↔ Deriv 23 := ⟨fun h => equation_of_goal h (app s q) s, goal_of_bj_eq_b⟩
theorem goal_iff_27 : Deriv goal ↔ Deriv 27 := ⟨fun h => equation_of_goal h s (app s q), fun h => goal_of_bj_eq_b (flip (a:=s) (b:=app s q) h)⟩

/-- The numerical calculus proves every numeral as soon as the marker goal
is derivable. This includes numerals interpreted as implications. -/
theorem every_numeral_of_goal (h : Deriv goal) (n : Nat) : Deriv n := by
  induction n using Nat.strongRecOn with
  | ind n ih =>
    by_cases zero : n=0
    · exact zero ▸ Moving186.deriv_zero
    let a := (NF192.Numerical.Cantor.unpair (n/2)).1
    let b := (NF192.Numerical.Cantor.unpair (n/2)).2
    have pair : NF192.Numerical.pair a b = n/2 := NF192.Numerical.Cantor.pair_unpair _
    by_cases odd : n%2=1
    · have shape : eqn a b = n := by rw [eqn,pair]; omega
      exact shape ▸ equation_of_goal h a b
    · have shape : imp a b = n := by rw [imp,pair]; omega
      have hb : b ≤ n/2 := NF192.Numerical.Cantor.unpair_right_le _
      exact shape ▸ Deriv.mp (logic_weakening b a) (ih b (by omega))
theorem deriv_71 : Deriv 71 := flip (a:=app (konst q) q) (b:=q) (constant q q)
#print axioms every_numeral_of_goal
#print axioms goal_iff_27

#print axioms equation_of_goal
#print axioms goal_iff_19
end AlternateGoals
