import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank220.Boot
open NF210 NF192 Blank220.Table
theorem chunk134400 : Prefix 700 snap133700 snap134400 := checked _ _ _ (by decide) (by decide)
theorem chunk135100 : Prefix 700 snap134400 snap135100 := checked _ _ _ (by decide) (by decide)
theorem chunk135800 : Prefix 700 snap135100 snap135800 := checked _ _ _ (by decide) (by decide)
theorem chunk136500 : Prefix 700 snap135800 snap136500 := checked _ _ _ (by decide) (by decide)
theorem chunk137200 : Prefix 700 snap136500 snap137200 := checked _ _ _ (by decide) (by decide)
theorem chunk137900 : Prefix 700 snap137200 snap137900 := checked _ _ _ (by decide) (by decide)
theorem chunk138600 : Prefix 700 snap137900 snap138600 := checked _ _ _ (by decide) (by decide)
theorem chunk139300 : Prefix 700 snap138600 snap139300 := checked _ _ _ (by decide) (by decide)
theorem chunk140000 : Prefix 700 snap139300 snap140000 := checked _ _ _ (by decide) (by decide)
theorem chunk140700 : Prefix 700 snap140000 snap140700 := checked _ _ _ (by decide) (by decide)
theorem chunk141400 : Prefix 700 snap140700 snap141400 := checked _ _ _ (by decide) (by decide)
theorem chunk142100 : Prefix 700 snap141400 snap142100 := checked _ _ _ (by decide) (by decide)
end Blank220.Boot
