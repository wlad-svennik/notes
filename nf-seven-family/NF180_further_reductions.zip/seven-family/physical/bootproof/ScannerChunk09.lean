import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank220.Boot
open NF210 NF192 Blank220.Table
theorem chunk75600 : Prefix 700 snap74900 snap75600 := checked _ _ _ (by decide) (by decide)
theorem chunk76300 : Prefix 700 snap75600 snap76300 := checked _ _ _ (by decide) (by decide)
theorem chunk77000 : Prefix 700 snap76300 snap77000 := checked _ _ _ (by decide) (by decide)
theorem chunk77700 : Prefix 700 snap77000 snap77700 := checked _ _ _ (by decide) (by decide)
theorem chunk78400 : Prefix 700 snap77700 snap78400 := checked _ _ _ (by decide) (by decide)
theorem chunk79100 : Prefix 700 snap78400 snap79100 := checked _ _ _ (by decide) (by decide)
theorem chunk79800 : Prefix 700 snap79100 snap79800 := checked _ _ _ (by decide) (by decide)
theorem chunk80500 : Prefix 700 snap79800 snap80500 := checked _ _ _ (by decide) (by decide)
theorem chunk81200 : Prefix 700 snap80500 snap81200 := checked _ _ _ (by decide) (by decide)
theorem chunk81900 : Prefix 700 snap81200 snap81900 := checked _ _ _ (by decide) (by decide)
theorem chunk82600 : Prefix 700 snap81900 snap82600 := checked _ _ _ (by decide) (by decide)
theorem chunk83300 : Prefix 700 snap82600 snap83300 := checked _ _ _ (by decide) (by decide)
end Blank220.Boot
