import NF210.MachineSemantics
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank220.Table
open NF210.TM
abbrev State := Fin 220
def start : State := 215
def names : Array String := #["a:CD:5", "a:CD:6", "a:CD:7", "a:CI:1", "a:CI:2", "a:CI:4", "a:CI:5", "a:CI:6", "a:CI:7", "d:0", "d:14", "d:146", "d:147", "d:148", "d:15", "d:152", "d:153", "d:154", "d:155", "d:16", "d:161", "d:162", "d:163", "d:166", "d:17", "d:18", "d:19", "d:26", "d:39", "d:40", "d:52", "d:61", "d:62", "d:64", "d:65", "d:71", "g:053ed47e8b9e", "g:0ba9c5497499", "g:0c19552b339d", "g:0d1d7ec2d66d", "g:0e568c8f6399", "g:0ebfc9788c56", "g:10cae23b6379", "g:1122ae7e09fd", "g:1635dc4d4d06", "g:1645409aa46d", "g:1681e8c9b097", "g:1d352d44de89", "g:1d371ec4ff72", "g:1ec6a2afd561", "g:1fda07337cb1", "g:21c9c2771699", "g:22c545e7ed29", "g:234a336c3324", "g:237bb64a6b29", "g:23e6a661adc5", "g:24cd868c1ad7", "g:24efb646178c", "g:29f9e19dba57", "g:2aaa9ce38e69", "g:2e22cffb44b3", "g:32cbf534c34e", "g:3301efc130c2", "g:34afa327a302", "g:35a0aced0c6c", "g:36d0f4c43090", "g:37d6ff4d8fc6", "g:39d1afa9735d", "g:3ae2853ac0da", "g:408b4dd54e78", "g:42c15cddd137", "g:436359a150c1", "g:458883ef0f6b", "g:459b7b508bfd", "g:480e92940d12", "g:49a16b15b0b8", "g:4aed2dea46bd", "g:4b77aa9c1a40", "g:4bbb4f0ff3b3", "g:4beace4d83fa", "g:4c19d3a8e1c5", "g:4ce6e0d3c599", "g:4d007c9db1a4", "g:4e9f3c4e5c89", "g:5013aab8ea64", "g:50fe60e0d1d1", "g:5161b61a0f9a", "g:52c6f301c90c", "g:560426379b40", "g:572b2f24a7ac", "g:5738ff74a56d", "g:5b67d23add24", "g:5bc91c9a8986", "g:5bed38825a60", "g:5fe30628b5a6", "g:615995402fbf", "g:6371767f3b87", "g:64182fd212c1", "g:644685e1a0d1", "g:6453a0c6e2e2", "g:65ba7447e737", "g:6658983afbf1", "g:67ae6dd9e34d", "g:67cb7ed735bc", "g:6927bba09caf", "g:69af9ae0b4d5", "g:69e61d7d97e5", "g:6df6eadb1ecd", "g:6e77c03791de", "g:6e97673c0a4e", "g:7000bafde523", "g:709fe41e0d89", "g:736b7ac63e58", "g:73f5433e35f1", "g:7420db9ef9fa", "g:75f540460632", "g:790bf589e986", "g:79994337bd36", "g:7bd127408625", "g:7c442ede59a1", "g:7f4c6ec96750", "g:7fbc3b2e2a86", "g:801dcca3cdd6", "g:81700f2ffcee", "g:82bfb469ffc4", "g:830b5d939388", "g:84155c324890", "g:85cadc9e9a81", "g:8ca79d95474b", "g:8cc7d8a844ea", "g:8dd1bb82b807", "g:91355ad6aa0a", "g:92c784e2c469", "g:92f6762f648d", "g:9337278f23d9", "g:94df689c1ebd", "g:96e2e250f6f3", "g:978401e82b96", "g:994a281639b3", "g:99fed693183e", "g:9aa00e38f876", "g:9cbf8be0c77a", "g:a4e15051a8fd", "g:a660e080950f", "g:aaade5658be7", "g:b0ed7f8438ca", "g:b55cd6a9a134", "g:b55d3482fecc", "g:b5bfe848f961", "g:b66f747934d8", "g:b8066ce46fc1", "g:bb33e8045d18", "g:bd51f563256c", "g:c07ec8abac1b", "g:c09cea0ef858", "g:c22330772889", "g:c64b512b7ad5", "g:c76c6f86c00c", "g:cb5c283fb209", "g:cba24c796da6", "g:cf9aa00fd8a8", "g:d0545245c311", "g:d22c7d3ad8eb", "g:d4c13ba48c90", "g:d5268f01c058", "g:e21fd92dbc8a", "g:e38de1582c6f", "g:e4b71fa4b9f0", "g:ea76af9a9495", "g:ecaeaeb59c7b", "g:ed177d9ace57", "g:ededb294d247", "g:ee6b1ebf9569", "g:f2193549a42b", "g:f27d9b85a69a", "g:f302278ff65f", "g:f540213af020", "g:f88bac377f3b", "g:f97e45df04a2", "g:fa2c1cad303a", "g:fc3328f9b3dc", "g:fcacaa729d33", "g:fde511465768", "g:fe40f2a14f6d", "g:ff74304eff87", "k16share:0", "k16share:1", "k:0", "k:10", "k:113", "k:15", "k:198", "k:2", "k:22", "k:23", "k:24", "k:25", "k:3", "k:302", "k:32", "k:33", "k:35", "k:36", "k:4", "k:40", "k:48", "k:49", "k:5", "k:51", "k:54", "k:55", "k:6", "k:60", "k:64", "k:66", "k:74", "k:75", "k:9", "k:94", "k:97"]
def name (q : State) := names[q.val]?.getD ""
def pair (q : State) : Instruction 220 × Instruction 220 :=
  if q.val < 110 then
    if q.val < 55 then
      if q.val < 27 then
        if q.val < 13 then
          if q.val < 6 then
            if q.val < 3 then
              if q.val < 1 then
                (⟨false, .right, some (195:State)⟩,⟨false, .right, some (210:State)⟩)
              else
                if q.val < 2 then
                  (⟨false, .left, some (23:State)⟩,⟨true, .left, some (31:State)⟩)
                else
                  (⟨false, .left, some (34:State)⟩,⟨false, .left, some (210:State)⟩)
            else
              if q.val < 4 then
                (⟨false, .right, some (206:State)⟩,⟨false, .right, some (196:State)⟩)
              else
                if q.val < 5 then
                  (⟨false, .left, some (29:State)⟩,⟨false, .left, some (196:State)⟩)
                else
                  (⟨false, .left, some (29:State)⟩,⟨false, .right, some (205:State)⟩)
          else
            if q.val < 9 then
              if q.val < 7 then
                (⟨false, .left, some (31:State)⟩,⟨true, .left, some (34:State)⟩)
              else
                if q.val < 8 then
                  (⟨false, .right, some (206:State)⟩,⟨false, .right, some (212:State)⟩)
                else
                  (⟨false, .left, some (31:State)⟩,⟨true, .left, some (25:State)⟩)
            else
              if q.val < 11 then
                if q.val < 10 then
                  (⟨false, .right, some (60:State)⟩,⟨true, .right, some (124:State)⟩)
                else
                  (⟨false, .right, some (14:State)⟩,⟨false, .left, some (185:State)⟩)
              else
                if q.val < 12 then
                  (⟨false, .right, some (12:State)⟩,⟨true, .right, some (13:State)⟩)
                else
                  (⟨false, .right, some (5:State)⟩,⟨false, .left, some (186:State)⟩)
        else
          if q.val < 20 then
            if q.val < 16 then
              if q.val < 14 then
                (⟨false, .right, some (0:State)⟩,⟨false, .left, some (192:State)⟩)
              else
                if q.val < 15 then
                  (⟨false, .right, some (8:State)⟩,⟨true, .right, some (19:State)⟩)
                else
                  (⟨false, .right, some (16:State)⟩,⟨true, .right, some (13:State)⟩)
            else
              if q.val < 18 then
                if q.val < 17 then
                  (⟨false, .right, some (0:State)⟩,⟨true, .right, some (17:State)⟩)
                else
                  (⟨false, .left, some (11:State)⟩,⟨true, .right, some (18:State)⟩)
              else
                if q.val < 19 then
                  (⟨false, .left, some (11:State)⟩,⟨true, .right, some (0:State)⟩)
                else
                  (⟨false, .right, some (24:State)⟩,⟨true, .right, some (25:State)⟩)
          else
            if q.val < 23 then
              if q.val < 21 then
                (⟨false, .right, some (21:State)⟩,⟨true, .right, some (22:State)⟩)
              else
                if q.val < 22 then
                  (⟨false, .right, some (0:State)⟩,⟨false, .left, some (185:State)⟩)
                else
                  (⟨false, .right, some (6:State)⟩,⟨true, .right, some (28:State)⟩)
            else
              if q.val < 25 then
                if q.val < 24 then
                  (⟨false, .right, some (0:State)⟩,⟨true, .left, some (19:State)⟩)
                else
                  (⟨false, .right, some (1:State)⟩,⟨false, .left, some (198:State)⟩)
              else
                if q.val < 26 then
                  (⟨false, .right, some (2:State)⟩,⟨true, .right, some (26:State)⟩)
                else
                  (⟨false, .left, some (34:State)⟩,⟨false, .left, some (185:State)⟩)
      else
        if q.val < 41 then
          if q.val < 34 then
            if q.val < 30 then
              if q.val < 28 then
                (⟨false, .right, some (1:State)⟩,⟨true, .right, some (12:State)⟩)
              else
                if q.val < 29 then
                  (⟨false, .right, some (1:State)⟩,⟨true, .right, some (29:State)⟩)
                else
                  (⟨false, .left, some (20:State)⟩,⟨false, .left, some (185:State)⟩)
            else
              if q.val < 32 then
                if q.val < 31 then
                  (⟨false, .right, some (8:State)⟩,⟨true, .right, some (1:State)⟩)
                else
                  (⟨false, .right, some (7:State)⟩,⟨true, .right, some (32:State)⟩)
              else
                if q.val < 33 then
                  (⟨false, .right, some (3:State)⟩,⟨false, .left, some (188:State)⟩)
                else
                  (⟨false, .right, some (34:State)⟩,⟨true, .right, some (27:State)⟩)
          else
            if q.val < 37 then
              if q.val < 35 then
                (⟨false, .left, some (11:State)⟩,⟨true, .right, some (31:State)⟩)
              else
                if q.val < 36 then
                  (⟨false, .left, some (19:State)⟩,⟨true, .right, some (6:State)⟩)
                else
                  (⟨false, .right, some (139:State)⟩,⟨true, .right, some (26:State)⟩)
            else
              if q.val < 39 then
                if q.val < 38 then
                  (⟨false, .right, some (47:State)⟩,⟨true, .right, some (35:State)⟩)
                else
                  (⟨false, .right, some (195:State)⟩,⟨false, .right, some (193:State)⟩)
              else
                if q.val < 40 then
                  (⟨false, .left, some (19:State)⟩,⟨false, .left, some (192:State)⟩)
                else
                  (⟨false, .right, some (61:State)⟩,⟨true, .right, some (31:State)⟩)
        else
          if q.val < 48 then
            if q.val < 44 then
              if q.val < 42 then
                (⟨false, .right, some (1:State)⟩,⟨true, .right, some (8:State)⟩)
              else
                if q.val < 43 then
                  (⟨false, .right, some (162:State)⟩,⟨true, .right, some (34:State)⟩)
                else
                  (⟨false, .right, some (81:State)⟩,⟨true, .right, some (165:State)⟩)
            else
              if q.val < 46 then
                if q.val < 45 then
                  (⟨false, .right, some (162:State)⟩,⟨true, .right, some (172:State)⟩)
                else
                  (⟨false, .right, some (162:State)⟩,⟨true, .right, some (49:State)⟩)
              else
                if q.val < 47 then
                  (⟨false, .right, some (51:State)⟩,⟨true, .right, some (148:State)⟩)
                else
                  (⟨false, .right, some (140:State)⟩,⟨true, .right, some (128:State)⟩)
          else
            if q.val < 51 then
              if q.val < 49 then
                (⟨false, .right, some (146:State)⟩,⟨true, .right, some (49:State)⟩)
              else
                if q.val < 50 then
                  (⟨false, .right, some (90:State)⟩,⟨true, .right, some (125:State)⟩)
                else
                  (⟨false, .right, some (41:State)⟩,⟨true, .right, some (134:State)⟩)
            else
              if q.val < 53 then
                if q.val < 52 then
                  (⟨false, .right, some (129:State)⟩,⟨true, .left, some (19:State)⟩)
                else
                  (⟨false, .right, some (95:State)⟩,⟨true, .right, some (90:State)⟩)
              else
                if q.val < 54 then
                  (⟨false, .right, some (1:State)⟩,⟨false, .left, some (192:State)⟩)
                else
                  (⟨false, .right, some (127:State)⟩,⟨true, .right, some (71:State)⟩)
    else
      if q.val < 82 then
        if q.val < 68 then
          if q.val < 61 then
            if q.val < 58 then
              if q.val < 56 then
                (⟨false, .right, some (95:State)⟩,⟨true, .right, some (160:State)⟩)
              else
                if q.val < 57 then
                  (⟨false, .right, some (69:State)⟩,⟨true, .right, some (58:State)⟩)
                else
                  (⟨false, .right, some (96:State)⟩,⟨true, .right, some (90:State)⟩)
            else
              if q.val < 59 then
                (⟨false, .right, some (47:State)⟩,⟨true, .right, some (92:State)⟩)
              else
                if q.val < 60 then
                  (⟨false, .right, some (127:State)⟩,⟨true, .right, some (55:State)⟩)
                else
                  (⟨false, .right, some (46:State)⟩,⟨true, .right, some (102:State)⟩)
          else
            if q.val < 64 then
              if q.val < 62 then
                (⟨false, .right, some (195:State)⟩,⟨false, .right, some (199:State)⟩)
              else
                if q.val < 63 then
                  (⟨false, .right, some (67:State)⟩,⟨true, .right, some (136:State)⟩)
                else
                  (⟨false, .right, some (140:State)⟩,⟨true, .right, some (171:State)⟩)
            else
              if q.val < 66 then
                if q.val < 65 then
                  (⟨false, .right, some (68:State)⟩,⟨true, .left, some (28:State)⟩)
                else
                  (⟨false, .right, some (168:State)⟩,⟨true, .right, some (11:State)⟩)
              else
                if q.val < 67 then
                  (⟨false, .right, some (101:State)⟩,⟨true, .right, some (97:State)⟩)
                else
                  (⟨false, .right, some (105:State)⟩,⟨true, .right, some (41:State)⟩)
        else
          if q.val < 75 then
            if q.val < 71 then
              if q.val < 69 then
                (⟨false, .right, some (206:State)⟩,⟨false, .right, some (199:State)⟩)
              else
                if q.val < 70 then
                  (⟨false, .right, some (4:State)⟩,⟨true, .right, some (8:State)⟩)
                else
                  (⟨false, .right, some (110:State)⟩,⟨true, .right, some (53:State)⟩)
            else
              if q.val < 73 then
                if q.val < 72 then
                  (⟨false, .right, some (44:State)⟩,⟨true, .right, some (95:State)⟩)
                else
                  (⟨false, .right, some (1:State)⟩,⟨true, .right, some (20:State)⟩)
              else
                if q.val < 74 then
                  (⟨false, .right, some (2:State)⟩,⟨true, .right, some (123:State)⟩)
                else
                  (⟨false, .right, some (80:State)⟩,⟨true, .right, some (167:State)⟩)
          else
            if q.val < 78 then
              if q.val < 76 then
                (⟨false, .right, some (77:State)⟩,⟨true, .right, some (154:State)⟩)
              else
                if q.val < 77 then
                  (⟨false, .right, some (87:State)⟩,⟨false, .left, some (185:State)⟩)
                else
                  (⟨false, .right, some (152:State)⟩,⟨true, .right, some (132:State)⟩)
            else
              if q.val < 80 then
                if q.val < 79 then
                  (⟨false, .right, some (173:State)⟩,⟨true, .right, some (117:State)⟩)
                else
                  (⟨false, .right, some (5:State)⟩,⟨true, .right, some (90:State)⟩)
              else
                if q.val < 81 then
                  (⟨false, .right, some (178:State)⟩,⟨true, .right, some (92:State)⟩)
                else
                  (⟨false, .right, some (1:State)⟩,⟨true, .right, some (64:State)⟩)
      else
        if q.val < 96 then
          if q.val < 89 then
            if q.val < 85 then
              if q.val < 83 then
                (⟨false, .right, some (45:State)⟩,⟨true, .right, some (101:State)⟩)
              else
                if q.val < 84 then
                  (⟨false, .right, some (44:State)⟩,⟨true, .right, some (52:State)⟩)
                else
                  (⟨false, .right, some (206:State)⟩,⟨false, .right, some (193:State)⟩)
            else
              if q.val < 87 then
                if q.val < 86 then
                  (⟨false, .right, some (95:State)⟩,⟨true, .right, some (146:State)⟩)
                else
                  (⟨false, .right, some (104:State)⟩,⟨true, .right, some (48:State)⟩)
              else
                if q.val < 88 then
                  (⟨false, .right, some (183:State)⟩,⟨true, .right, some (107:State)⟩)
                else
                  (⟨false, .right, some (80:State)⟩,⟨true, .right, some (37:State)⟩)
          else
            if q.val < 92 then
              if q.val < 90 then
                (⟨false, .right, some (61:State)⟩,⟨true, .right, some (161:State)⟩)
              else
                if q.val < 91 then
                  (⟨false, .right, some (42:State)⟩,⟨true, .right, some (28:State)⟩)
                else
                  (⟨false, .right, some (89:State)⟩,⟨true, .right, some (99:State)⟩)
            else
              if q.val < 94 then
                if q.val < 93 then
                  (⟨false, .left, some (19:State)⟩,⟨true, .right, some (145:State)⟩)
                else
                  (⟨false, .left, some (19:State)⟩,⟨true, .right, some (8:State)⟩)
              else
                if q.val < 95 then
                  (⟨false, .right, some (163:State)⟩,⟨true, .right, some (116:State)⟩)
                else
                  (⟨false, .right, some (88:State)⟩,⟨true, .right, some (3:State)⟩)
        else
          if q.val < 103 then
            if q.val < 99 then
              if q.val < 97 then
                (⟨false, .right, some (44:State)⟩,⟨true, .right, some (88:State)⟩)
              else
                if q.val < 98 then
                  (⟨false, .right, some (143:State)⟩,⟨true, .right, some (88:State)⟩)
                else
                  (⟨false, .right, some (105:State)⟩,⟨true, .right, some (50:State)⟩)
            else
              if q.val < 101 then
                if q.val < 100 then
                  (⟨false, .right, some (79:State)⟩,⟨true, .right, some (156:State)⟩)
                else
                  (⟨false, .right, some (95:State)⟩,⟨true, .right, some (97:State)⟩)
              else
                if q.val < 102 then
                  (⟨false, .right, some (3:State)⟩,⟨true, .right, some (95:State)⟩)
                else
                  (⟨false, .right, some (181:State)⟩,⟨true, .right, some (73:State)⟩)
          else
            if q.val < 106 then
              if q.val < 104 then
                (⟨false, .right, some (173:State)⟩,⟨true, .right, some (86:State)⟩)
              else
                if q.val < 105 then
                  (⟨false, .right, some (165:State)⟩,⟨true, .right, some (119:State)⟩)
                else
                  (⟨false, .right, some (110:State)⟩,⟨true, .right, some (39:State)⟩)
            else
              if q.val < 108 then
                if q.val < 107 then
                  (⟨false, .right, some (80:State)⟩,⟨true, .right, some (28:State)⟩)
                else
                  (⟨false, .right, some (175:State)⟩,⟨true, .right, some (100:State)⟩)
              else
                if q.val < 109 then
                  (⟨false, .right, some (44:State)⟩,⟨true, .right, some (125:State)⟩)
                else
                  (⟨false, .right, some (36:State)⟩,⟨true, .right, some (72:State)⟩)
  else
    if q.val < 165 then
      if q.val < 137 then
        if q.val < 123 then
          if q.val < 116 then
            if q.val < 113 then
              if q.val < 111 then
                (⟨false, .right, some (139:State)⟩,⟨true, .right, some (10:State)⟩)
              else
                if q.val < 112 then
                  (⟨false, .right, some (142:State)⟩,⟨true, .right, some (179:State)⟩)
                else
                  (⟨false, .right, some (90:State)⟩,⟨true, .right, some (133:State)⟩)
            else
              if q.val < 114 then
                (⟨false, .right, some (130:State)⟩,⟨false, .left, some (26:State)⟩)
              else
                if q.val < 115 then
                  (⟨false, .right, some (158:State)⟩,⟨true, .right, some (71:State)⟩)
                else
                  (⟨false, .right, some (158:State)⟩,⟨true, .right, some (57:State)⟩)
          else
            if q.val < 119 then
              if q.val < 117 then
                (⟨false, .right, some (82:State)⟩,⟨true, .right, some (125:State)⟩)
              else
                if q.val < 118 then
                  (⟨false, .right, some (109:State)⟩,⟨true, .right, some (65:State)⟩)
                else
                  (⟨false, .right, some (101:State)⟩,⟨true, .right, some (141:State)⟩)
            else
              if q.val < 121 then
                if q.val < 120 then
                  (⟨false, .right, some (173:State)⟩,⟨true, .right, some (182:State)⟩)
                else
                  (⟨false, .right, some (184:State)⟩,⟨true, .right, some (125:State)⟩)
              else
                if q.val < 122 then
                  (⟨false, .right, some (74:State)⟩,⟨true, .right, some (74:State)⟩)
                else
                  (⟨false, .right, some (3:State)⟩,⟨true, .right, some (71:State)⟩)
        else
          if q.val < 130 then
            if q.val < 126 then
              if q.val < 124 then
                (⟨false, .right, some (174:State)⟩,⟨false, .left, some (185:State)⟩)
              else
                if q.val < 125 then
                  (⟨false, .right, some (43:State)⟩,⟨true, .right, some (91:State)⟩)
                else
                  (⟨false, .right, some (90:State)⟩,⟨true, .right, some (95:State)⟩)
            else
              if q.val < 128 then
                if q.val < 127 then
                  (⟨false, .right, some (143:State)⟩,⟨true, .right, some (135:State)⟩)
                else
                  (⟨false, .right, some (70:State)⟩,⟨true, .right, some (93:State)⟩)
              else
                if q.val < 129 then
                  (⟨false, .right, some (1:State)⟩,⟨true, .right, some (113:State)⟩)
                else
                  (⟨false, .right, some (195:State)⟩,⟨false, .right, some (202:State)⟩)
          else
            if q.val < 133 then
              if q.val < 131 then
                (⟨false, .right, some (8:State)⟩,⟨true, .right, some (41:State)⟩)
              else
                if q.val < 132 then
                  (⟨false, .right, some (149:State)⟩,⟨true, .right, some (153:State)⟩)
                else
                  (⟨false, .right, some (176:State)⟩,⟨true, .right, some (138:State)⟩)
            else
              if q.val < 135 then
                if q.val < 134 then
                  (⟨false, .right, some (95:State)⟩,⟨true, .right, some (88:State)⟩)
                else
                  (⟨false, .right, some (184:State)⟩,⟨true, .right, some (90:State)⟩)
              else
                if q.val < 136 then
                  (⟨false, .right, some (114:State)⟩,⟨true, .right, some (108:State)⟩)
                else
                  (⟨false, .right, some (90:State)⟩,⟨true, .right, some (166:State)⟩)
      else
        if q.val < 151 then
          if q.val < 144 then
            if q.val < 140 then
              if q.val < 138 then
                (⟨false, .right, some (150:State)⟩,⟨true, .right, some (177:State)⟩)
              else
                if q.val < 139 then
                  (⟨false, .right, some (66:State)⟩,⟨true, .right, some (118:State)⟩)
                else
                  (⟨false, .right, some (195:State)⟩,⟨false, .right, some (196:State)⟩)
            else
              if q.val < 142 then
                if q.val < 141 then
                  (⟨false, .right, some (139:State)⟩,⟨true, .right, some (30:State)⟩)
                else
                  (⟨false, .right, some (90:State)⟩,⟨true, .right, some (62:State)⟩)
              else
                if q.val < 143 then
                  (⟨false, .right, some (28:State)⟩,⟨true, .right, some (131:State)⟩)
                else
                  (⟨false, .right, some (158:State)⟩,⟨true, .right, some (125:State)⟩)
          else
            if q.val < 147 then
              if q.val < 145 then
                (⟨false, .right, some (143:State)⟩,⟨true, .right, some (101:State)⟩)
              else
                if q.val < 146 then
                  (⟨false, .right, some (4:State)⟩,⟨true, .left, some (28:State)⟩)
                else
                  (⟨false, .right, some (88:State)⟩,⟨true, .right, some (88:State)⟩)
            else
              if q.val < 149 then
                if q.val < 148 then
                  (⟨false, .right, some (94:State)⟩,⟨true, .right, some (112:State)⟩)
                else
                  (⟨false, .right, some (157:State)⟩,⟨true, .right, some (169:State)⟩)
              else
                if q.val < 150 then
                  (⟨false, .right, some (44:State)⟩,⟨true, .right, some (103:State)⟩)
                else
                  (⟨false, .right, some (164:State)⟩,⟨true, .right, some (126:State)⟩)
        else
          if q.val < 158 then
            if q.val < 154 then
              if q.val < 152 then
                (⟨false, .right, some (83:State)⟩,⟨true, .right, some (98:State)⟩)
              else
                if q.val < 153 then
                  (⟨false, .right, some (122:State)⟩,⟨true, .right, some (120:State)⟩)
                else
                  (⟨false, .right, some (137:State)⟩,⟨true, .right, some (97:State)⟩)
            else
              if q.val < 156 then
                if q.val < 155 then
                  (⟨false, .right, some (82:State)⟩,⟨true, .right, some (120:State)⟩)
                else
                  (⟨false, .right, some (61:State)⟩,⟨true, .right, some (76:State)⟩)
              else
                if q.val < 157 then
                  (⟨false, .right, some (15:State)⟩,⟨true, .right, some (106:State)⟩)
                else
                  (⟨false, .right, some (38:State)⟩,⟨true, .right, some (30:State)⟩)
          else
            if q.val < 161 then
              if q.val < 159 then
                (⟨false, .right, some (162:State)⟩,⟨true, .right, some (33:State)⟩)
              else
                if q.val < 160 then
                  (⟨false, .right, some (158:State)⟩,⟨true, .right, some (151:State)⟩)
                else
                  (⟨false, .right, some (159:State)⟩,⟨true, .right, some (54:State)⟩)
            else
              if q.val < 163 then
                if q.val < 162 then
                  (⟨false, .right, some (155:State)⟩,⟨true, .right, some (78:State)⟩)
                else
                  (⟨false, .right, some (36:State)⟩,⟨true, .right, some (56:State)⟩)
              else
                if q.val < 164 then
                  (⟨false, .right, some (162:State)⟩,⟨true, .right, some (75:State)⟩)
                else
                  (⟨false, .right, some (3:State)⟩,⟨true, .right, some (120:State)⟩)
    else
      if q.val < 192 then
        if q.val < 178 then
          if q.val < 171 then
            if q.val < 168 then
              if q.val < 166 then
                (⟨false, .right, some (102:State)⟩,⟨true, .right, some (27:State)⟩)
              else
                if q.val < 167 then
                  (⟨false, .right, some (59:State)⟩,⟨true, .right, some (85:State)⟩)
                else
                  (⟨false, .right, some (63:State)⟩,⟨true, .right, some (35:State)⟩)
            else
              if q.val < 169 then
                (⟨false, .right, some (23:State)⟩,⟨true, .right, some (33:State)⟩)
              else
                if q.val < 170 then
                  (⟨false, .right, some (84:State)⟩,⟨true, .right, some (170:State)⟩)
                else
                  (⟨false, .right, some (1:State)⟩,⟨true, .left, some (25:State)⟩)
          else
            if q.val < 174 then
              if q.val < 172 then
                (⟨false, .right, some (1:State)⟩,⟨true, .right, some (180:State)⟩)
              else
                if q.val < 173 then
                  (⟨false, .right, some (40:State)⟩,⟨true, .right, some (81:State)⟩)
                else
                  (⟨false, .right, some (158:State)⟩,⟨true, .right, some (88:State)⟩)
            else
              if q.val < 176 then
                if q.val < 175 then
                  (⟨false, .right, some (206:State)⟩,⟨false, .right, some (202:State)⟩)
                else
                  (⟨false, .right, some (158:State)⟩,⟨true, .right, some (144:State)⟩)
              else
                if q.val < 177 then
                  (⟨false, .right, some (44:State)⟩,⟨true, .right, some (49:State)⟩)
                else
                  (⟨false, .right, some (121:State)⟩,⟨true, .right, some (147:State)⟩)
        else
          if q.val < 185 then
            if q.val < 181 then
              if q.val < 179 then
                (⟨false, .right, some (4:State)⟩,⟨true, .right, some (10:State)⟩)
              else
                if q.val < 180 then
                  (⟨false, .right, some (90:State)⟩,⟨true, .right, some (144:State)⟩)
                else
                  (⟨false, .right, some (130:State)⟩,⟨true, .left, some (31:State)⟩)
            else
              if q.val < 183 then
                if q.val < 182 then
                  (⟨false, .right, some (129:State)⟩,⟨true, .right, some (10:State)⟩)
                else
                  (⟨false, .right, some (115:State)⟩,⟨true, .right, some (96:State)⟩)
              else
                if q.val < 184 then
                  (⟨false, .right, some (102:State)⟩,⟨true, .right, some (111:State)⟩)
                else
                  (⟨false, .right, some (158:State)⟩,⟨true, .right, some (95:State)⟩)
          else
            if q.val < 188 then
              if q.val < 186 then
                (⟨true, .left, some (186:State)⟩,⟨false, .left, some (192:State)⟩)
              else
                if q.val < 187 then
                  (⟨true, .left, some (11:State)⟩,⟨false, .right, some (186:State)⟩)
                else
                  (⟨true, .right, some (218:State)⟩,⟨true, .right, some (187:State)⟩)
            else
              if q.val < 190 then
                if q.val < 189 then
                  (⟨false, .left, some (185:State)⟩,⟨false, .right, some (188:State)⟩)
                else
                  (⟨false, .left, some (198:State)⟩,⟨false, .left, some (219:State)⟩)
              else
                if q.val < 191 then
                  (⟨false, .left, some (194:State)⟩,⟨true, .left, some (192:State)⟩)
                else
                  (⟨false, .left, some (219:State)⟩,⟨true, .left, some (209:State)⟩)
      else
        if q.val < 206 then
          if q.val < 199 then
            if q.val < 195 then
              if q.val < 193 then
                (⟨false, .left, some (197:State)⟩,⟨true, .left, some (192:State)⟩)
              else
                if q.val < 194 then
                  (⟨false, .right, some (200:State)⟩,⟨true, .right, some (193:State)⟩)
                else
                  (⟨false, .left, some (216:State)⟩,⟨true, .left, some (192:State)⟩)
            else
              if q.val < 197 then
                if q.val < 196 then
                  (⟨false, .left, some (201:State)⟩,⟨false, .right, some (187:State)⟩)
                else
                  (⟨false, .right, some (202:State)⟩,⟨true, .right, some (196:State)⟩)
              else
                if q.val < 198 then
                  (⟨false, .left, some (207:State)⟩,⟨true, .left, some (192:State)⟩)
                else
                  (⟨false, .left, some (203:State)⟩,⟨false, .left, none⟩)
          else
            if q.val < 202 then
              if q.val < 200 then
                (⟨false, .right, some (205:State)⟩,⟨true, .right, some (199:State)⟩)
              else
                if q.val < 201 then
                  (⟨false, .right, some (199:State)⟩,⟨true, .right, some (200:State)⟩)
                else
                  (⟨true, .right, some (201:State)⟩,⟨true, .left, some (192:State)⟩)
            else
              if q.val < 204 then
                if q.val < 203 then
                  (⟨false, .right, some (208:State)⟩,⟨true, .right, some (202:State)⟩)
                else
                  (⟨true, .right, some (211:State)⟩,⟨false, .left, some (203:State)⟩)
              else
                if q.val < 205 then
                  (⟨false, .left, some (203:State)⟩,⟨true, .left, some (209:State)⟩)
                else
                  (⟨false, .right, some (196:State)⟩,⟨true, .right, some (205:State)⟩)
        else
          if q.val < 213 then
            if q.val < 209 then
              if q.val < 207 then
                (⟨false, .left, some (201:State)⟩,⟨false, .right, some (213:State)⟩)
              else
                if q.val < 208 then
                  (⟨false, .left, some (217:State)⟩,⟨true, .left, some (192:State)⟩)
                else
                  (⟨false, .right, some (185:State)⟩,⟨true, .right, some (208:State)⟩)
            else
              if q.val < 211 then
                if q.val < 210 then
                  (⟨false, .left, some (204:State)⟩,⟨true, .left, some (209:State)⟩)
                else
                  (⟨false, .right, some (193:State)⟩,⟨true, .right, some (210:State)⟩)
              else
                if q.val < 212 then
                  (⟨false, .right, some (211:State)⟩,⟨false, .right, some (188:State)⟩)
                else
                  (⟨true, .left, some (18:State)⟩,⟨true, .right, some (212:State)⟩)
          else
            if q.val < 216 then
              if q.val < 214 then
                (⟨false, .right, some (215:State)⟩,⟨true, .right, some (213:State)⟩)
              else
                if q.val < 215 then
                  (⟨true, .left, some (209:State)⟩,⟨true, .right, some (191:State)⟩)
                else
                  (⟨true, .right, some (187:State)⟩,⟨true, .right, some (213:State)⟩)
            else
              if q.val < 218 then
                if q.val < 217 then
                  (⟨false, .right, some (216:State)⟩,⟨true, .right, some (9:State)⟩)
                else
                  (⟨false, .left, some (190:State)⟩,⟨true, .left, some (192:State)⟩)
              else
                if q.val < 219 then
                  (⟨false, .right, some (214:State)⟩,⟨false, .right, some (187:State)⟩)
                else
                  (⟨true, .left, some (189:State)⟩,⟨true, .left, some (219:State)⟩)
def machine (q : State) (b : Bool) : Instruction 220 := if b then (pair q).2 else (pair q).1
def row (q : State) (b : Bool) : String :=
  let a := machine q b
  name q ++ " " ++ (if b then "1" else "0") ++ " " ++
    (if a.write then "1" else "0") ++ " " ++ (if a.move = .right then "R" else "L") ++ " " ++
    (a.next.map name).getD "halt" ++ "\n"
def rendered : List String := (List.finRange 220).flatMap fun q => [row q false,row q true]
def raw : List String := [
"a:CD:5 0 0 R k:24\n",
"a:CD:5 1 0 R k:55\n",
"a:CD:6 0 0 L d:166\n",
"a:CD:6 1 1 L d:61\n",
"a:CD:7 0 0 L d:65\n",
"a:CD:7 1 0 L k:55\n",
"a:CI:1 0 0 R k:49\n",
"a:CI:1 1 0 R k:25\n",
"a:CI:2 0 0 L d:40\n",
"a:CI:2 1 0 L k:25\n",
"a:CI:4 0 0 L d:40\n",
"a:CI:4 1 0 R k:48\n",
"a:CI:5 0 0 L d:61\n",
"a:CI:5 1 1 L d:65\n",
"a:CI:6 0 0 R k:49\n",
"a:CI:6 1 0 R k:60\n",
"a:CI:7 0 0 L d:61\n",
"a:CI:7 1 1 L d:18\n",
"d:0 0 0 R g:2e22cffb44b3\n",
"d:0 1 1 R g:82bfb469ffc4\n",
"d:14 0 0 R d:15\n",
"d:14 1 0 L k16share:0\n",
"d:146 0 0 R d:147\n",
"d:146 1 1 R d:148\n",
"d:147 0 0 R a:CI:4\n",
"d:147 1 0 L k16share:1\n",
"d:148 0 0 R a:CD:5\n",
"d:148 1 0 L k:2\n",
"d:15 0 0 R a:CI:7\n",
"d:15 1 1 R d:16\n",
"d:152 0 0 R d:153\n",
"d:152 1 1 R d:148\n",
"d:153 0 0 R a:CD:5\n",
"d:153 1 1 R d:154\n",
"d:154 0 0 L d:146\n",
"d:154 1 1 R d:155\n",
"d:155 0 0 L d:146\n",
"d:155 1 1 R a:CD:5\n",
"d:16 0 0 R d:17\n",
"d:16 1 1 R d:18\n",
"d:161 0 0 R d:162\n",
"d:161 1 1 R d:163\n",
"d:162 0 0 R a:CD:5\n",
"d:162 1 0 L k16share:0\n",
"d:163 0 0 R a:CI:5\n",
"d:163 1 1 R d:39\n",
"d:166 0 0 R a:CD:5\n",
"d:166 1 1 L d:16\n",
"d:17 0 0 R a:CD:6\n",
"d:17 1 0 L k:302\n",
"d:18 0 0 R a:CD:7\n",
"d:18 1 1 R d:19\n",
"d:19 0 0 L d:65\n",
"d:19 1 0 L k16share:0\n",
"d:26 0 0 R a:CD:6\n",
"d:26 1 1 R d:147\n",
"d:39 0 0 R a:CD:6\n",
"d:39 1 1 R d:40\n",
"d:40 0 0 L d:161\n",
"d:40 1 0 L k16share:0\n",
"d:52 0 0 R a:CI:7\n",
"d:52 1 1 R a:CD:6\n",
"d:61 0 0 R a:CI:6\n",
"d:61 1 1 R d:62\n",
"d:62 0 0 R a:CI:1\n",
"d:62 1 0 L k:10\n",
"d:64 0 0 R d:65\n",
"d:64 1 1 R d:26\n",
"d:65 0 0 L d:146\n",
"d:65 1 1 R d:61\n",
"d:71 0 0 L d:16\n",
"d:71 1 1 R a:CI:5\n",
"g:053ed47e8b9e 0 0 R g:99fed693183e\n",
"g:053ed47e8b9e 1 1 R d:19\n",
"g:0ba9c5497499 0 0 R g:1d352d44de89\n",
"g:0ba9c5497499 1 1 R d:71\n",
"g:0c19552b339d 0 0 R k:24\n",
"g:0c19552b339d 1 0 R k:22\n",
"g:0d1d7ec2d66d 0 0 L d:16\n",
"g:0d1d7ec2d66d 1 0 L k:2\n",
"g:0e568c8f6399 0 0 R g:32cbf534c34e\n",
"g:0e568c8f6399 1 1 R d:61\n",
"g:0ebfc9788c56 0 0 R a:CD:6\n",
"g:0ebfc9788c56 1 1 R a:CI:7\n",
"g:10cae23b6379 0 0 R g:d22c7d3ad8eb\n",
"g:10cae23b6379 1 1 R d:65\n",
"g:1122ae7e09fd 0 0 R g:4ce6e0d3c599\n",
"g:1122ae7e09fd 1 1 R g:e21fd92dbc8a\n",
"g:1635dc4d4d06 0 0 R g:d22c7d3ad8eb\n",
"g:1635dc4d4d06 1 1 R g:ee6b1ebf9569\n",
"g:1645409aa46d 0 0 R g:d22c7d3ad8eb\n",
"g:1645409aa46d 1 1 R g:1ec6a2afd561\n",
"g:1681e8c9b097 0 0 R g:21c9c2771699\n",
"g:1681e8c9b097 1 1 R g:b5bfe848f961\n",
"g:1d352d44de89 0 0 R g:9aa00e38f876\n",
"g:1d352d44de89 1 1 R g:8ca79d95474b\n",
"g:1d371ec4ff72 0 0 R g:b55cd6a9a134\n",
"g:1d371ec4ff72 1 1 R g:1ec6a2afd561\n",
"g:1ec6a2afd561 0 0 R g:5738ff74a56d\n",
"g:1ec6a2afd561 1 1 R g:830b5d939388\n",
"g:1fda07337cb1 0 0 R g:0ebfc9788c56\n",
"g:1fda07337cb1 1 1 R g:9337278f23d9\n",
"g:21c9c2771699 0 0 R g:8cc7d8a844ea\n",
"g:21c9c2771699 1 1 L d:16\n",
"g:22c545e7ed29 0 0 R g:615995402fbf\n",
"g:22c545e7ed29 1 1 R g:5738ff74a56d\n",
"g:234a336c3324 0 0 R a:CD:6\n",
"g:234a336c3324 1 0 L k:2\n",
"g:237bb64a6b29 0 0 R g:85cadc9e9a81\n",
"g:237bb64a6b29 1 1 R g:436359a150c1\n",
"g:23e6a661adc5 0 0 R g:615995402fbf\n",
"g:23e6a661adc5 1 1 R g:cf9aa00fd8a8\n",
"g:24cd868c1ad7 0 0 R g:408b4dd54e78\n",
"g:24cd868c1ad7 1 1 R g:29f9e19dba57\n",
"g:24efb646178c 0 0 R g:6371767f3b87\n",
"g:24efb646178c 1 1 R g:5738ff74a56d\n",
"g:29f9e19dba57 0 0 R g:1d352d44de89\n",
"g:29f9e19dba57 1 1 R g:5bc91c9a8986\n",
"g:2aaa9ce38e69 0 0 R g:85cadc9e9a81\n",
"g:2aaa9ce38e69 1 1 R g:23e6a661adc5\n",
"g:2e22cffb44b3 0 0 R g:1681e8c9b097\n",
"g:2e22cffb44b3 1 1 R g:67ae6dd9e34d\n",
"g:32cbf534c34e 0 0 R k:24\n",
"g:32cbf534c34e 1 0 R k:32\n",
"g:3301efc130c2 0 0 R g:39d1afa9735d\n",
"g:3301efc130c2 1 1 R g:96e2e250f6f3\n",
"g:34afa327a302 0 0 R g:9aa00e38f876\n",
"g:34afa327a302 1 1 R g:ededb294d247\n",
"g:35a0aced0c6c 0 0 R g:3ae2853ac0da\n",
"g:35a0aced0c6c 1 1 L d:39\n",
"g:36d0f4c43090 0 0 R g:ea76af9a9495\n",
"g:36d0f4c43090 1 1 R d:146\n",
"g:37d6ff4d8fc6 0 0 R g:6658983afbf1\n",
"g:37d6ff4d8fc6 1 1 R g:64182fd212c1\n",
"g:39d1afa9735d 0 0 R g:69af9ae0b4d5\n",
"g:39d1afa9735d 1 1 R g:0ebfc9788c56\n",
"g:3ae2853ac0da 0 0 R k:49\n",
"g:3ae2853ac0da 1 0 R k:32\n",
"g:408b4dd54e78 0 0 R a:CI:2\n",
"g:408b4dd54e78 1 1 R a:CI:7\n",
"g:42c15cddd137 0 0 R g:7000bafde523\n",
"g:42c15cddd137 1 1 R g:234a336c3324\n",
"g:436359a150c1 0 0 R g:1635dc4d4d06\n",
"g:436359a150c1 1 1 R g:615995402fbf\n",
"g:458883ef0f6b 0 0 R a:CD:6\n",
"g:458883ef0f6b 1 1 R d:161\n",
"g:459b7b508bfd 0 0 R a:CD:7\n",
"g:459b7b508bfd 1 1 R g:81700f2ffcee\n",
"g:480e92940d12 0 0 R g:4c19d3a8e1c5\n",
"g:480e92940d12 1 1 R g:e4b71fa4b9f0\n",
"g:49a16b15b0b8 0 0 R g:4b77aa9c1a40\n",
"g:49a16b15b0b8 1 1 R g:c09cea0ef858\n",
"g:4aed2dea46bd 0 0 R g:52c6f301c90c\n",
"g:4aed2dea46bd 1 0 L k16share:0\n",
"g:4b77aa9c1a40 0 0 R g:bd51f563256c\n",
"g:4b77aa9c1a40 1 1 R g:92c784e2c469\n",
"g:4bbb4f0ff3b3 0 0 R g:f2193549a42b\n",
"g:4bbb4f0ff3b3 1 1 R g:79994337bd36\n",
"g:4beace4d83fa 0 0 R a:CI:4\n",
"g:4beace4d83fa 1 1 R g:5738ff74a56d\n",
"g:4c19d3a8e1c5 0 0 R g:f97e45df04a2\n",
"g:4c19d3a8e1c5 1 1 R g:5bc91c9a8986\n",
"g:4ce6e0d3c599 0 0 R a:CD:6\n",
"g:4ce6e0d3c599 1 1 R g:35a0aced0c6c\n",
"g:4d007c9db1a4 0 0 R g:1645409aa46d\n",
"g:4d007c9db1a4 1 1 R g:6658983afbf1\n",
"g:4e9f3c4e5c89 0 0 R g:1635dc4d4d06\n",
"g:4e9f3c4e5c89 1 1 R g:22c545e7ed29\n",
"g:5013aab8ea64 0 0 R k:49\n",
"g:5013aab8ea64 1 0 R k:22\n",
"g:50fe60e0d1d1 0 0 R g:615995402fbf\n",
"g:50fe60e0d1d1 1 1 R g:b55cd6a9a134\n",
"g:5161b61a0f9a 0 0 R g:6927bba09caf\n",
"g:5161b61a0f9a 1 1 R g:1d371ec4ff72\n",
"g:52c6f301c90c 0 0 R g:fe40f2a14f6d\n",
"g:52c6f301c90c 1 1 R g:6df6eadb1ecd\n",
"g:560426379b40 0 0 R g:4c19d3a8e1c5\n",
"g:560426379b40 1 1 R g:0ba9c5497499\n",
"g:572b2f24a7ac 0 0 R g:32cbf534c34e\n",
"g:572b2f24a7ac 1 1 R g:d0545245c311\n",
"g:5738ff74a56d 0 0 R g:10cae23b6379\n",
"g:5738ff74a56d 1 1 R d:39\n",
"g:5b67d23add24 0 0 R g:572b2f24a7ac\n",
"g:5b67d23add24 1 1 R g:6453a0c6e2e2\n",
"g:5bc91c9a8986 0 0 L d:16\n",
"g:5bc91c9a8986 1 1 R g:b0ed7f8438ca\n",
"g:5bed38825a60 0 0 L d:16\n",
"g:5bed38825a60 1 1 R a:CI:7\n",
"g:5fe30628b5a6 0 0 R g:d4c13ba48c90\n",
"g:5fe30628b5a6 1 1 R g:790bf589e986\n",
"g:615995402fbf 0 0 R g:560426379b40\n",
"g:615995402fbf 1 1 R a:CI:1\n",
"g:6371767f3b87 0 0 R g:1635dc4d4d06\n",
"g:6371767f3b87 1 1 R g:560426379b40\n",
"g:64182fd212c1 0 0 R g:a660e080950f\n",
"g:64182fd212c1 1 1 R g:560426379b40\n",
"g:644685e1a0d1 0 0 R g:69af9ae0b4d5\n",
"g:644685e1a0d1 1 1 R g:1fda07337cb1\n",
"g:6453a0c6e2e2 0 0 R g:4beace4d83fa\n",
"g:6453a0c6e2e2 1 1 R g:c64b512b7ad5\n",
"g:65ba7447e737 0 0 R g:615995402fbf\n",
"g:65ba7447e737 1 1 R g:64182fd212c1\n",
"g:6658983afbf1 0 0 R a:CI:1\n",
"g:6658983afbf1 1 1 R g:615995402fbf\n",
"g:67ae6dd9e34d 0 0 R g:fcacaa729d33\n",
"g:67ae6dd9e34d 1 1 R g:459b7b508bfd\n",
"g:67cb7ed735bc 0 0 R g:f2193549a42b\n",
"g:67cb7ed735bc 1 1 R g:5161b61a0f9a\n",
"g:6927bba09caf 0 0 R g:e21fd92dbc8a\n",
"g:6927bba09caf 1 1 R g:7c442ede59a1\n",
"g:69af9ae0b4d5 0 0 R g:7000bafde523\n",
"g:69af9ae0b4d5 1 1 R g:0d1d7ec2d66d\n",
"g:69e61d7d97e5 0 0 R g:4c19d3a8e1c5\n",
"g:69e61d7d97e5 1 1 R d:39\n",
"g:6df6eadb1ecd 0 0 R g:f302278ff65f\n",
"g:6df6eadb1ecd 1 1 R g:65ba7447e737\n",
"g:6e77c03791de 0 0 R g:1635dc4d4d06\n",
"g:6e77c03791de 1 1 R g:830b5d939388\n",
"g:6e97673c0a4e 0 0 R g:053ed47e8b9e\n",
"g:6e97673c0a4e 1 1 R g:458883ef0f6b\n",
"g:7000bafde523 0 0 R g:99fed693183e\n",
"g:7000bafde523 1 1 R d:14\n",
"g:709fe41e0d89 0 0 R g:a4e15051a8fd\n",
"g:709fe41e0d89 1 1 R g:fa2c1cad303a\n",
"g:736b7ac63e58 0 0 R g:5738ff74a56d\n",
"g:736b7ac63e58 1 1 R g:92f6762f648d\n",
"g:73f5433e35f1 0 0 R g:8dd1bb82b807\n",
"g:73f5433e35f1 1 0 L d:19\n",
"g:7420db9ef9fa 0 0 R g:cb5c283fb209\n",
"g:7420db9ef9fa 1 1 R g:436359a150c1\n",
"g:75f540460632 0 0 R g:cb5c283fb209\n",
"g:75f540460632 1 1 R g:24efb646178c\n",
"g:790bf589e986 0 0 R g:4d007c9db1a4\n",
"g:790bf589e986 1 1 R g:830b5d939388\n",
"g:79994337bd36 0 0 R g:6e97673c0a4e\n",
"g:79994337bd36 1 1 R g:36d0f4c43090\n",
"g:7bd127408625 0 0 R g:6658983afbf1\n",
"g:7bd127408625 1 1 R g:9cbf8be0c77a\n",
"g:7c442ede59a1 0 0 R g:f2193549a42b\n",
"g:7c442ede59a1 1 1 R g:fde511465768\n",
"g:7f4c6ec96750 0 0 R g:ff74304eff87\n",
"g:7f4c6ec96750 1 1 R g:830b5d939388\n",
"g:7fbc3b2e2a86 0 0 R g:480e92940d12\n",
"g:7fbc3b2e2a86 1 1 R g:480e92940d12\n",
"g:801dcca3cdd6 0 0 R a:CI:1\n",
"g:801dcca3cdd6 1 1 R g:436359a150c1\n",
"g:81700f2ffcee 0 0 R g:f27d9b85a69a\n",
"g:81700f2ffcee 1 0 L k16share:0\n",
"g:82bfb469ffc4 0 0 R g:1122ae7e09fd\n",
"g:82bfb469ffc4 1 1 R g:5b67d23add24\n",
"g:830b5d939388 0 0 R g:5738ff74a56d\n",
"g:830b5d939388 1 1 R g:615995402fbf\n",
"g:84155c324890 0 0 R g:a660e080950f\n",
"g:84155c324890 1 1 R g:94df689c1ebd\n",
"g:85cadc9e9a81 0 0 R g:42c15cddd137\n",
"g:85cadc9e9a81 1 1 R g:5bed38825a60\n",
"g:8ca79d95474b 0 0 R a:CD:6\n",
"g:8ca79d95474b 1 1 R g:73f5433e35f1\n",
"g:8cc7d8a844ea 0 0 R k:24\n",
"g:8cc7d8a844ea 1 0 R k:36\n",
"g:8dd1bb82b807 0 0 R a:CI:7\n",
"g:8dd1bb82b807 1 1 R g:0ebfc9788c56\n",
"g:91355ad6aa0a 0 0 R g:b66f747934d8\n",
"g:91355ad6aa0a 1 1 R g:c07ec8abac1b\n",
"g:92c784e2c469 0 0 R g:f540213af020\n",
"g:92c784e2c469 1 1 R g:994a281639b3\n",
"g:92f6762f648d 0 0 R g:615995402fbf\n",
"g:92f6762f648d 1 1 R g:560426379b40\n",
"g:9337278f23d9 0 0 R g:ff74304eff87\n",
"g:9337278f23d9 1 1 R g:5738ff74a56d\n",
"g:94df689c1ebd 0 0 R g:7420db9ef9fa\n",
"g:94df689c1ebd 1 1 R g:6e77c03791de\n",
"g:96e2e250f6f3 0 0 R g:5738ff74a56d\n",
"g:96e2e250f6f3 1 1 R g:e38de1582c6f\n",
"g:978401e82b96 0 0 R g:b8066ce46fc1\n",
"g:978401e82b96 1 1 R g:f88bac377f3b\n",
"g:994a281639b3 0 0 R g:37d6ff4d8fc6\n",
"g:994a281639b3 1 1 R g:7bd127408625\n",
"g:99fed693183e 0 0 R k:24\n",
"g:99fed693183e 1 0 R k:25\n",
"g:9aa00e38f876 0 0 R g:99fed693183e\n",
"g:9aa00e38f876 1 1 R d:52\n",
"g:9cbf8be0c77a 0 0 R g:5738ff74a56d\n",
"g:9cbf8be0c77a 1 1 R g:3301efc130c2\n",
"g:a4e15051a8fd 0 0 R d:39\n",
"g:a4e15051a8fd 1 1 R g:91355ad6aa0a\n",
"g:a660e080950f 0 0 R g:cb5c283fb209\n",
"g:a660e080950f 1 1 R g:830b5d939388\n",
"g:aaade5658be7 0 0 R g:a660e080950f\n",
"g:aaade5658be7 1 1 R g:6658983afbf1\n",
"g:b0ed7f8438ca 0 0 R a:CI:2\n",
"g:b0ed7f8438ca 1 1 L d:39\n",
"g:b55cd6a9a134 0 0 R g:560426379b40\n",
"g:b55cd6a9a134 1 1 R g:560426379b40\n",
"g:b55d3482fecc 0 0 R g:5fe30628b5a6\n",
"g:b55d3482fecc 1 1 R g:736b7ac63e58\n",
"g:b5bfe848f961 0 0 R g:c76c6f86c00c\n",
"g:b5bfe848f961 1 1 R g:ecaeaeb59c7b\n",
"g:b66f747934d8 0 0 R g:1635dc4d4d06\n",
"g:b66f747934d8 1 1 R g:67cb7ed735bc\n",
"g:b8066ce46fc1 0 0 R g:d5268f01c058\n",
"g:b8066ce46fc1 1 1 R g:84155c324890\n",
"g:bb33e8045d18 0 0 R g:4e9f3c4e5c89\n",
"g:bb33e8045d18 1 1 R g:644685e1a0d1\n",
"g:bd51f563256c 0 0 R g:801dcca3cdd6\n",
"g:bd51f563256c 1 1 R g:7f4c6ec96750\n",
"g:c07ec8abac1b 0 0 R g:978401e82b96\n",
"g:c07ec8abac1b 1 1 R g:64182fd212c1\n",
"g:c09cea0ef858 0 0 R g:4d007c9db1a4\n",
"g:c09cea0ef858 1 1 R g:7f4c6ec96750\n",
"g:c22330772889 0 0 R g:32cbf534c34e\n",
"g:c22330772889 1 1 R g:4aed2dea46bd\n",
"g:c64b512b7ad5 0 0 R d:152\n",
"g:c64b512b7ad5 1 1 R g:69e61d7d97e5\n",
"g:c76c6f86c00c 0 0 R g:0c19552b339d\n",
"g:c76c6f86c00c 1 1 R d:52\n",
"g:cb5c283fb209 0 0 R g:d22c7d3ad8eb\n",
"g:cb5c283fb209 1 1 R d:64\n",
"g:cba24c796da6 0 0 R g:cb5c283fb209\n",
"g:cba24c796da6 1 1 R g:bb33e8045d18\n",
"g:cf9aa00fd8a8 0 0 R g:cba24c796da6\n",
"g:cf9aa00fd8a8 1 1 R g:237bb64a6b29\n",
"g:d0545245c311 0 0 R g:c22330772889\n",
"g:d0545245c311 1 1 R g:4bbb4f0ff3b3\n",
"g:d22c7d3ad8eb 0 0 R g:053ed47e8b9e\n",
"g:d22c7d3ad8eb 1 1 R g:24cd868c1ad7\n",
"g:d4c13ba48c90 0 0 R g:d22c7d3ad8eb\n",
"g:d4c13ba48c90 1 1 R g:49a16b15b0b8\n",
"g:d5268f01c058 0 0 R a:CI:1\n",
"g:d5268f01c058 1 1 R g:7f4c6ec96750\n",
"g:e21fd92dbc8a 0 0 R g:67ae6dd9e34d\n",
"g:e21fd92dbc8a 1 1 R d:26\n",
"g:e38de1582c6f 0 0 R g:2aaa9ce38e69\n",
"g:e38de1582c6f 1 1 R g:50fe60e0d1d1\n",
"g:e4b71fa4b9f0 0 0 R g:34afa327a302\n",
"g:e4b71fa4b9f0 1 1 R d:71\n",
"g:ea76af9a9495 0 0 R d:166\n",
"g:ea76af9a9495 1 1 R d:64\n",
"g:ecaeaeb59c7b 0 0 R g:5013aab8ea64\n",
"g:ecaeaeb59c7b 1 1 R g:ed177d9ace57\n",
"g:ed177d9ace57 0 0 R a:CD:6\n",
"g:ed177d9ace57 1 1 L d:18\n",
"g:ededb294d247 0 0 R a:CD:6\n",
"g:ededb294d247 1 1 R g:fc3328f9b3dc\n",
"g:ee6b1ebf9569 0 0 R g:0e568c8f6399\n",
"g:ee6b1ebf9569 1 1 R g:4ce6e0d3c599\n",
"g:f2193549a42b 0 0 R g:cb5c283fb209\n",
"g:f2193549a42b 1 1 R g:560426379b40\n",
"g:f27d9b85a69a 0 0 R k:49\n",
"g:f27d9b85a69a 1 0 R k:36\n",
"g:f302278ff65f 0 0 R g:cb5c283fb209\n",
"g:f302278ff65f 1 1 R g:aaade5658be7\n",
"g:f540213af020 0 0 R g:1635dc4d4d06\n",
"g:f540213af020 1 1 R g:1ec6a2afd561\n",
"g:f88bac377f3b 0 0 R g:7fbc3b2e2a86\n",
"g:f88bac377f3b 1 1 R g:b55d3482fecc\n",
"g:f97e45df04a2 0 0 R a:CI:2\n",
"g:f97e45df04a2 1 1 R d:14\n",
"g:fa2c1cad303a 0 0 R g:5738ff74a56d\n",
"g:fa2c1cad303a 1 1 R g:aaade5658be7\n",
"g:fc3328f9b3dc 0 0 R g:8dd1bb82b807\n",
"g:fc3328f9b3dc 1 1 L d:61\n",
"g:fcacaa729d33 0 0 R g:8cc7d8a844ea\n",
"g:fcacaa729d33 1 1 R d:14\n",
"g:fde511465768 0 0 R g:75f540460632\n",
"g:fde511465768 1 1 R g:6371767f3b87\n",
"g:fe40f2a14f6d 0 0 R g:67ae6dd9e34d\n",
"g:fe40f2a14f6d 1 1 R g:709fe41e0d89\n",
"g:ff74304eff87 0 0 R g:cb5c283fb209\n",
"g:ff74304eff87 1 1 R g:615995402fbf\n",
"k16share:0 0 1 L k16share:1\n",
"k16share:0 1 0 L k:2\n",
"k16share:1 0 1 L d:146\n",
"k16share:1 1 0 R k16share:1\n",
"k:0 0 1 R k:94\n",
"k:0 1 1 R k:0\n",
"k:10 0 0 L k16share:0\n",
"k:10 1 0 R k:10\n",
"k:113 0 0 L k:302\n",
"k:113 1 0 L k:97\n",
"k:15 0 0 L k:23\n",
"k:15 1 1 L k:2\n",
"k:198 0 0 L k:97\n",
"k:198 1 1 L k:54\n",
"k:2 0 0 L k:3\n",
"k:2 1 1 L k:2\n",
"k:22 0 0 R k:33\n",
"k:22 1 1 R k:22\n",
"k:23 0 0 L k:75\n",
"k:23 1 1 L k:2\n",
"k:24 0 0 L k:35\n",
"k:24 1 0 R k:0\n",
"k:25 0 0 R k:36\n",
"k:25 1 1 R k:25\n",
"k:3 0 0 L k:5\n",
"k:3 1 1 L k:2\n",
"k:302 0 0 L k:4\n",
"k:302 1 0 L halt\n",
"k:32 0 0 R k:48\n",
"k:32 1 1 R k:32\n",
"k:33 0 0 R k:32\n",
"k:33 1 1 R k:33\n",
"k:35 0 1 R k:35\n",
"k:35 1 1 L k:2\n",
"k:36 0 0 R k:51\n",
"k:36 1 1 R k:36\n",
"k:4 0 1 R k:6\n",
"k:4 1 0 L k:4\n",
"k:40 0 0 L k:4\n",
"k:40 1 1 L k:54\n",
"k:48 0 0 R k:25\n",
"k:48 1 1 R k:48\n",
"k:49 0 0 L k:35\n",
"k:49 1 0 R k:64\n",
"k:5 0 0 L k:9\n",
"k:5 1 1 L k:2\n",
"k:51 0 0 R k16share:0\n",
"k:51 1 1 R k:51\n",
"k:54 0 0 L k:40\n",
"k:54 1 1 L k:54\n",
"k:55 0 0 R k:22\n",
"k:55 1 1 R k:55\n",
"k:6 0 0 R k:6\n",
"k:6 1 0 R k:10\n",
"k:60 0 1 L d:155\n",
"k:60 1 1 R k:60\n",
"k:64 0 0 R k:74\n",
"k:64 1 1 R k:64\n",
"k:66 0 1 L k:54\n",
"k:66 1 1 R k:198\n",
"k:74 0 1 R k:0\n",
"k:74 1 1 R k:64\n",
"k:75 0 0 R k:75\n",
"k:75 1 1 R d:0\n",
"k:9 0 0 L k:15\n",
"k:9 1 1 L k:2\n",
"k:94 0 0 R k:66\n",
"k:94 1 0 R k:0\n",
"k:97 0 1 L k:113\n",
"k:97 1 1 L k:97\n"]
theorem literal_exact : rendered = raw := by decide +kernel
#print axioms literal_exact
end Blank220.Table
