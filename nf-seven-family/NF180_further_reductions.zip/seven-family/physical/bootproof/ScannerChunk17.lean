import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank220.Boot
open NF210 NF192 Blank220.Table
theorem chunk142800 : Prefix 700 snap142100 snap142800 := checked _ _ _ (by decide) (by decide)
theorem chunk143500 : Prefix 700 snap142800 snap143500 := checked _ _ _ (by decide) (by decide)
theorem chunk144200 : Prefix 700 snap143500 snap144200 := checked _ _ _ (by decide) (by decide)
theorem chunk144900 : Prefix 700 snap144200 snap144900 := checked _ _ _ (by decide) (by decide)
theorem chunk145600 : Prefix 700 snap144900 snap145600 := checked _ _ _ (by decide) (by decide)
theorem chunk146300 : Prefix 700 snap145600 snap146300 := checked _ _ _ (by decide) (by decide)
theorem chunk147000 : Prefix 700 snap146300 snap147000 := checked _ _ _ (by decide) (by decide)
theorem chunk147700 : Prefix 700 snap147000 snap147700 := checked _ _ _ (by decide) (by decide)
theorem chunk148400 : Prefix 700 snap147700 snap148400 := checked _ _ _ (by decide) (by decide)
theorem chunk149100 : Prefix 700 snap148400 snap149100 := checked _ _ _ (by decide) (by decide)
theorem chunk149800 : Prefix 700 snap149100 snap149800 := checked _ _ _ (by decide) (by decide)
theorem chunk150500 : Prefix 700 snap149800 snap150500 := checked _ _ _ (by decide) (by decide)
end Blank220.Boot
