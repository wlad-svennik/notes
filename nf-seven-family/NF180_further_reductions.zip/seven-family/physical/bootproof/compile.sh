#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export LEAN_PATH="$(pwd):${LEAN_PATH:-}"
compile(){ lean -o "$1.olean" "$1.lean" >"$1.log" 2>&1 || { cat "$1.log"; return 1; }; }
export -f compile
compile NF210/MachineSemantics
printf '%s\n' MachineBits Blank220Table | xargs -P 3 -n1 bash -c 'compile "$1"' _
compile ScannerSnapshots
printf '%s\n' ScannerChunk*.lean | sed 's/.lean$//' | xargs -P "${JOBS:-3}" -n1 bash -c 'compile "$1"' _
compile ScannerPrefix
compile ScannerFrames
