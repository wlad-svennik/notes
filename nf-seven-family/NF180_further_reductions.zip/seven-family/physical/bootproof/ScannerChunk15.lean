import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank220.Boot
open NF210 NF192 Blank220.Table
theorem chunk126000 : Prefix 700 snap125300 snap126000 := checked _ _ _ (by decide) (by decide)
theorem chunk126700 : Prefix 700 snap126000 snap126700 := checked _ _ _ (by decide) (by decide)
theorem chunk127400 : Prefix 700 snap126700 snap127400 := checked _ _ _ (by decide) (by decide)
theorem chunk128100 : Prefix 700 snap127400 snap128100 := checked _ _ _ (by decide) (by decide)
theorem chunk128800 : Prefix 700 snap128100 snap128800 := checked _ _ _ (by decide) (by decide)
theorem chunk129500 : Prefix 700 snap128800 snap129500 := checked _ _ _ (by decide) (by decide)
theorem chunk130200 : Prefix 700 snap129500 snap130200 := checked _ _ _ (by decide) (by decide)
theorem chunk130900 : Prefix 700 snap130200 snap130900 := checked _ _ _ (by decide) (by decide)
theorem chunk131600 : Prefix 700 snap130900 snap131600 := checked _ _ _ (by decide) (by decide)
theorem chunk132300 : Prefix 700 snap131600 snap132300 := checked _ _ _ (by decide) (by decide)
theorem chunk133000 : Prefix 700 snap132300 snap133000 := checked _ _ _ (by decide) (by decide)
theorem chunk133700 : Prefix 700 snap133000 snap133700 := checked _ _ _ (by decide) (by decide)
end Blank220.Boot
