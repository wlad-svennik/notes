import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank220.Boot
open NF210 NF192 Blank220.Table
theorem chunk176400 : Prefix 700 snap175700 snap176400 := checked _ _ _ (by decide) (by decide)
theorem chunk177100 : Prefix 700 snap176400 snap177100 := checked _ _ _ (by decide) (by decide)
theorem chunk177800 : Prefix 700 snap177100 snap177800 := checked _ _ _ (by decide) (by decide)
theorem chunk178500 : Prefix 700 snap177800 snap178500 := checked _ _ _ (by decide) (by decide)
theorem chunk179200 : Prefix 700 snap178500 snap179200 := checked _ _ _ (by decide) (by decide)
theorem chunk179900 : Prefix 700 snap179200 snap179900 := checked _ _ _ (by decide) (by decide)
theorem chunk180600 : Prefix 700 snap179900 snap180600 := checked _ _ _ (by decide) (by decide)
theorem chunk181300 : Prefix 700 snap180600 snap181300 := checked _ _ _ (by decide) (by decide)
theorem chunk182000 : Prefix 700 snap181300 snap182000 := checked _ _ _ (by decide) (by decide)
theorem chunk182700 : Prefix 700 snap182000 snap182700 := checked _ _ _ (by decide) (by decide)
theorem chunk183400 : Prefix 700 snap182700 snap183400 := checked _ _ _ (by decide) (by decide)
theorem chunk184100 : Prefix 700 snap183400 snap184100 := checked _ _ _ (by decide) (by decide)
end Blank220.Boot
