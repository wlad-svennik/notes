import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank220.Boot
open NF210 NF192 Blank220.Table
theorem chunk9100 : Prefix 700 snap8400 snap9100 := checked _ _ _ (by decide) (by decide)
theorem chunk9800 : Prefix 700 snap9100 snap9800 := checked _ _ _ (by decide) (by decide)
theorem chunk10500 : Prefix 700 snap9800 snap10500 := checked _ _ _ (by decide) (by decide)
theorem chunk11200 : Prefix 700 snap10500 snap11200 := checked _ _ _ (by decide) (by decide)
theorem chunk11900 : Prefix 700 snap11200 snap11900 := checked _ _ _ (by decide) (by decide)
theorem chunk12600 : Prefix 700 snap11900 snap12600 := checked _ _ _ (by decide) (by decide)
theorem chunk13300 : Prefix 700 snap12600 snap13300 := checked _ _ _ (by decide) (by decide)
theorem chunk14000 : Prefix 700 snap13300 snap14000 := checked _ _ _ (by decide) (by decide)
theorem chunk14700 : Prefix 700 snap14000 snap14700 := checked _ _ _ (by decide) (by decide)
theorem chunk15400 : Prefix 700 snap14700 snap15400 := checked _ _ _ (by decide) (by decide)
theorem chunk16100 : Prefix 700 snap15400 snap16100 := checked _ _ _ (by decide) (by decide)
theorem chunk16800 : Prefix 700 snap16100 snap16800 := checked _ _ _ (by decide) (by decide)
end Blank220.Boot
