"""Generate the Lean equality from the two literal prefix-code programs."""
from pathlib import Path
import json

folder = Path(__file__).resolve().parent
definitions = []
indices = {}
def syntax(filename):
    rows = json.loads(filename.read_bytes())
    assert len(rows) == 2840
    leaves = {p: (op, n) for p, op, n in rows}
    assert len(leaves) == len(rows) and list(leaves) == sorted(leaves)
    def visit(p):
        if p in leaves:
            op, n = leaves[p]
            assert op in {"CI", "CD", "CC", "CB"}
            key = f".leaf .{op} {n}"
        else:
            assert len(p) < 80
            a, b = visit(p+"0"), visit(p+"1")
            key = f".fork tree{a} tree{b}"
        if key not in indices:
            indices[key] = len(definitions)
            definitions.append(f"def tree{indices[key]} : Tree := {key}")
        return indices[key]
    return visit("")

original = syntax(folder.parent / "joint-delivery" / "NF7.source.sites.json")
relabeled = syntax(folder / "source.sites.json")
header = """set_option maxRecDepth 200000
set_option maxHeartbeats 0
namespace SevenReaddressing
inductive Cmd where
  | inc (r next : Nat)
  | dec (r : Nat) (zero : Option Nat) (positive : Nat)
  | jump (dest : Nat)
  deriving DecidableEq
inductive Op where
  | CI | CD | CC | CB
inductive Tree where
  | leaf (op : Op) (operand : Nat)
  | fork (left right : Tree)
def Tree.width : Tree → Nat
  | .leaf _ _ => 1
  | .fork l r => l.width + r.width
def decode (t : Tree) (pc : Nat) (forward backward : List Nat) (lastRight : Bool) : List Cmd :=
  match t with
  | .fork l r =>
    decode l pc (((pc+t.width)%2840)::forward) backward false ++
    decode r (pc+l.width) forward (pc::backward) true
  | .leaf op n =>
    let next := (pc+1)%2840
    [match op with
      | .CI => .inc n next
      | .CD => .dec n (if lastRight then none else forward[0]?) next
      | .CC => .jump (backward[n-1]?.getD 4095)
      | .CB => .jump (forward[n-1]?.getD 4095)]
"""
footer = f"""
theorem programs_equal : decode tree{original} 0 [] [] false = decode tree{relabeled} 0 [] [] false := by
  decide +kernel
#print axioms programs_equal
end SevenReaddressing
"""
(folder / "Readdressing.lean").write_text(header+"\n".join(definitions)+"\n"+footer)
