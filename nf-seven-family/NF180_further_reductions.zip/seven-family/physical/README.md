# Binary implementation of the seven-family register program

The table has 220 working states, all reachable in the transition graph, and one transition into the separate halt state. Its literal start on an all-zero tape is k:74. The SHA-256 digest of candidate.tm is 13d500eba248ec7a98fe721fa16965792be9b9ed72de46d58b849a8c6e3efb9d.

Reassociating the projection subroutines shortens problematic leftward paths in the binary address tree. The supplied layout reproduces every instruction, fallthrough, conditional branch, jump and halting edge of the 2,840-instruction source in joint-delivery. SevenReaddressing.programs_equal checks that equality in Lean.

| Physical check | Result |
| --- | --- |
| Exact blank startup | PC 0 with counter 2 at step 40,711 and counter 5 at step 229,892. At the second boundary the other eight registers are zero, the head is at −10, the gap is 97 and there are 78 spares. |
| Signed symbolic simulation | The Lean reference kernel accepted all 7,460 branch theorems for the 2,840 source instructions, with 20 repetition lemmas. The minimum gap is 58. |
| Independent finite examples | 136,304 full successor-tape matches and 16 halts over 95,180,798 binary transitions. The tests vary the gap from the source-specific minimum. |

The existing mathematical proof establishes all-model equivalence of the two proof calculi. A complete PA proof connecting the modified seven-row command scanner and this particular literal halting sentence remains open. The published 180-state machine retains the end-to-end proof.

## Replay

Use Lean 4.35.0 with leanchecker-paranoid. The baseline argument is the extracted physical verification archive from the 180-state release. The following commands operate in this directory.

```sh
python3 replay.py /path/to/extracted/NF180 --kernel --examples
python3 generate_readdressing.py
lean Readdressing.lean
bash bootproof/compile.sh
```

The bootproof directory supplies the full literal-table equality and blank-prefix sources, including the two infinite-tape boundary equalities.
