"""Compare the literal control-flow graphs after readdressing the same register program."""
import json
from pathlib import Path

def decode(rows):
    first = {}
    for pc, (bits, _, _) in enumerate(rows):
        for n in range(len(bits) + 1):
            first.setdefault(bits[:n], pc)

    def advance(bits):
        i = bits.rfind("0")
        return bits[:i] + "1" if i >= 0 else ""

    def cut(bits, bit, n):
        for _ in range(n):
            bits = bits[:bits.rindex(bit)]
        return bits

    result = []
    for bits, op, arg in rows:
        if op == "CI":
            command = (op, arg, first[advance(bits)])
        elif op == "CD":
            zero = -1 if bits.endswith("1") else first[advance(cut(bits, "0", 1))]
            command = (op, arg, zero, first[advance(bits)])
        else:
            dest = cut(bits, "1", arg) if op == "CC" else advance(cut(bits, "0", arg))
            command = ("jump", first[dest])
        result.append(command)
    return result

folder = Path(__file__).resolve().parent
source = json.loads((folder / "source.sites.json").read_bytes())
original = json.loads((folder.parent / "joint-delivery" / "NF7.source.sites.json").read_bytes())
assert len(source) == len(original) == 2840
assert decode(source) == decode(original)
print("All 2,840 decoded instructions and all successors agree, including halt.")
