"""Repeat the physical checks using the checks/ directory of the published NF180 physical archive."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

folder = Path(__file__).resolve().parent
args = argparse.ArgumentParser(description=__doc__)
args.add_argument("baseline", type=Path)
args.add_argument("--kernel", action="store_true")
args.add_argument("--examples", action="store_true")
args.add_argument("--jobs", type=int, default=2)
options = args.parse_args()
checks = options.baseline.resolve() / "checks"

def run(*args):
    subprocess.run([str(x) for x in args], check=True)

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

run(sys.executable, folder / "compare_source.py")
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    trace = tmp / "traces.json.gz"
    run(sys.executable, checks / "symbolic_frames.py", folder, "--write", trace)
    assert digest(trace) == digest(folder / "traces.json.gz")
    if options.examples:
        for name in ("candidate.tm", "source.sites.json"):
            shutil.copyfile(folder / name, tmp / name)
        run(sys.executable, checks / "prepare.py", tmp)
        run("c++", "-std=c++17", "-O3", "-I", checks, folder / "replay_examples.cpp",
            "-o", tmp / "replay_examples")
        run(tmp / "replay_examples", tmp / "source.txt", tmp / "table.txt")
    if options.kernel:
        expected = json.loads((folder / "kernel-receipt.json").read_bytes())
        receipt = tmp / "receipt.json"
        run(sys.executable, checks / "check_all.py", folder, trace, receipt,
            "--jobs", options.jobs, "--chunk", 120)
        assert json.loads(receipt.read_bytes()) == expected
