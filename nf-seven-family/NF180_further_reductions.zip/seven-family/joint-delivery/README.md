# Seven axiom families for the NF proof search

The seven-family calculus proves exactly the same formula codes as the published eight-family calculus, in every model of first-order Peano arithmetic and with any internally coded assumption context. The new register source has 2,840 instructions. The published 180-state table remains the smallest verified physical implementation in this comparison.

## Change to the proof calculus

The original emitter produces both argument congruence and function congruence. Their replacement is the single family

    f = g → (x = y → fx = gy).

The three parameter registers hold a, b and c. The new row takes f and g from the left and right Cantor projections of b, and takes x = a and y = c. Every desired pair (f,g) is available by choosing b to be its Cantor code. The other six families, including extensionality, remain present.

In the old calculus, successive applications of the two congruences and transitivity yield the joint row. Conversely, choosing f = g gives argument congruence, and choosing x = y gives function congruence. The retained constant and Euclidean axioms supply reflexivity and symmetry. JointPA.lean uses these derivations with the internal deduction theorem and induction on the ranks of internally coded proofs. Its endpoint is JointPool.iff_original (ctx p : V) : JointPool.Pr ctx p ↔ NF182PA.Pool.Pr ctx p for every arithmetic model V ⊨ PA.

## Register source and proof coverage

NF7.source.sites.json is the complete binary-addressed register program. It replaces original instructions 1303 through 1872, inclusive, by 440 instructions. build_source.py checks every external successor after reindexing and every new instruction edge against its macro. It also runs 384 finite projection fixtures.

Projection.lean proves the two projection macros correct for arbitrary standard natural register contents satisfying their stated clean-scratch contract. Its theorem SevenEmitter.emits proves that the replacement block stores the joint formula on top and the previous top on the proof stack, while preserving the parameters, input and counter and restoring both scratch registers to zero. The numerical coding uses the same constructor for an application term and for an equality formula.

The all-model PA equivalence concerns the seven-family ranked calculus. The command compiler, scanner and literal tape-machine bridge for the modified seven-row program remain open. Among 162 physical encoding trials the smallest proposal had 214 working states and its symbolic check stopped at PC 1303. A conservative 241-state encoding of the exact source in this folder also failed that physical branch check.

## Replay

Use Lean 4.35.0. The verification archive accompanying the published 180-state table contains the baseline source file. Its PA archive contains replay.py and build.py. Unpack that archive and run the following command there to prepare both imports.

    python3 replay.py --jobs 2 NF181PAPacked NumericalEmitterBatch

This command uses the pinned 181-state verification archive. For an offline local copy pass --baseline /path/to/NF181_verification.zip. With the resulting replay-work and Lean on PATH, run the following commands in this directory.

    sha256sum -c SHA256SUMS
    sh replay.sh /path/to/180/source.sites.json /path/to/PA-archive/replay-work

The proof files print their axiom dependencies. Both use only Lean's propositional extensionality, classical choice and quotient soundness.

Published verification archives are available at https://github.com/wlad-svennik/notes/tree/87440d0dc4a281caa4a32dd4165838ae9a35a0b0/nf-bb180.
