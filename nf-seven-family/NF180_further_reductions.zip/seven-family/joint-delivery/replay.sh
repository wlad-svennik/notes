#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 2 ]; then
  echo "usage: sh replay.sh /path/to/NF180/source.sites.json /path/to/replay-work" >&2
  exit 2
fi
original=$1
project=$2
python3 "$here/build_source.py" "$original"
cd "$project"
for file in JointPA Projection; do
  SEVEN_FILE="$here/$file.lean" lake env sh -ec 'export LEAN_PATH="$PWD/build:$LEAN_PATH"; exec lean "$SEVEN_FILE"'
done
