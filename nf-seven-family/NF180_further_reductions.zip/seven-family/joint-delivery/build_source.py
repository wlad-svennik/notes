"""Rebuild the seven-family register source from the exact published NF180 source.

The addresses are leaves of a binary instruction tree. A conditional decrement
skips the right subtree on zero. CB and CC are counted left/right-edge jumps.
"""
import argparse
import hashlib
import json
from pathlib import Path

BASE_SHA = "7bacb7672e2df5f580588cc493b52c62bb0574de94c3a374d28e07195beccd47"
HERE = Path(__file__).resolve().parent

def is_leaf(tree):
    return isinstance(tree[0], str)

def from_sites(rows):
    by_path = {address: (op, arg, pc) for pc, (address, op, arg) in enumerate(rows)}
    def walk(path):
        if path in by_path:
            return by_path[path]
        return walk(path + "0"), walk(path + "1")
    return walk("")

def strip(tree):
    return tree[:2] if is_leaf(tree) else (strip(tree[0]), strip(tree[1]))

def subrange(tree, start, end):
    if is_leaf(tree):
        return tree[:2] if start <= tree[2] < end else None
    a, b = (subrange(t, start, end) for t in tree)
    return b if a is None else a if b is None else (a, b)

def rows_of(tree, path=""):
    if is_leaf(tree):
        yield [path, *tree]
    else:
        yield from rows_of(tree[0], path + "0")
        yield from rows_of(tree[1], path + "1")

def sequence(blocks):
    if len(blocks) == 1:
        return blocks[0]
    middle = len(blocks) // 2
    return sequence(blocks[:middle]), sequence(blocks[middle:])

def replace_first(tree, first):
    if is_leaf(tree):
        return first
    return replace_first(tree[0], first), tree[1]

def transfer(source, target):
    return ("CD",source), (("CI",target), ("CC",2))

def targets(rows):
    bounds = {}
    for i,(p,_,_) in enumerate(rows):
        for j in range(len(p)+1):
            bounds.setdefault(p[:j],[i,i+1])[1] = i+1
    result = []
    for p,o,k in rows:
        if o == "CI":
            result.append(None)
            continue
        if o == "CD" and p.endswith("1"):
            result.append(-1)
            continue
        bit = "1" if o == "CC" else "0"
        index = len(p)
        for _ in range(k if o in ("CC","CB") else 1):
            index = p.rfind(bit,0,index)
            assert index >= 0
        result.append(bounds[p[:index]][0 if bit=="1" else 1] % len(rows))
    return result

def program(old):
    tree = from_sites(old)
    # These are complete literal subtrees of the original two congruence words.
    intervals = {"A": (1381,1407), "B": (1329,1355), "C": (1303,1329),
        "pair1": (1355,1381), "imp": (1563,1588)}
    blocks = {name:subrange(tree,*interval) for name,interval in intervals.items()}
    # The original input unpair starts with CD8 and drains into R6 and R7.
    # After a parameter push, R1 can be destructively split the same way.
    unpair = replace_first(subrange(tree,39,47),("CD",1))
    def projected(side):
        take = (6,7)[side]
        discard = (7,6)[side]
        clear = ("CD",discard), ("CC",1)
        return sequence([blocks["B"],unpair,clear,transfer(take,1)])
    blocks["leftB"],blocks["rightB"] = projected(0),projected(1)
    # E(left b,right b) -> (E(a,c) -> E((left b) a,(right b) c)).
    tokens = ["leftB","rightB","pair1","A","C","pair1","leftB","A","pair1",
              "rightB","C","pair1","pair1","imp","imp"]
    joint = sequence([blocks[token] for token in tokens])
    def transplant(t):
        if is_leaf(t):
            return joint if t[2]==1303 else None if 1303<t[2]<1873 else t[:2]
        a,b = map(transplant,t)
        return b if a is None else a if b is None else (a,b)
    result = list(rows_of(transplant(tree)))
    assert len(old)==2970 and len(result)==2840
    old_t,new_t = targets(old),targets(result)
    def external_dest(t):
        return t if t is None or t<=1303 else t-130
    for i in list(range(1303))+list(range(1873,len(old))):
        j=i if i<1303 else i-130
        assert old[i][1:]==result[j][1:]
        assert new_t[j]==external_dest(old_t[i]),(i,j)
    # Check every edge of the new body against independently re-embedded
    # macro semantics. A successor reaching a macro's exit enters the next one.
    at=1303
    for token in tokens:
        local=list(rows_of((blocks[token],("CI",8))))
        tt=targets(local)
        for i,(p,op,k) in enumerate(local[:-1]):
            assert result[at+i][1:]==[op,k]
            assert new_t[at+i]==(None if tt[i] is None else at+tt[i]),(token,i)
        at += len(local)-1
    assert at==1743
    return result,blocks,tokens

def projection_tests(block):
    pair=lambda a,b:(a+b)*(a+b+1)//2+b
    rows=list(rows_of((block,("CI",8))));ts=targets(rows);count=0
    for x in range(8):
        for y in range(8):
            for top,stack in ((0,0),(4,7),(7,3)):
                regs=[3,top,stack,9,11,pair(x,y),0,0,5]
                expected=regs.copy();expected[2]=pair(top,stack)
                pc=0
                for _ in range(100000):
                    if pc==len(rows)-1:break
                    _,op,k=rows[pc];n=pc+1
                    if op=="CI":regs[k]+=1
                    elif op=="CD":
                        if regs[k]==0:n=ts[pc]
                        else:regs[k]-=1
                    else:n=ts[pc]
                    assert n>=0
                    pc=n
                else:raise AssertionError("projection exceeded finite test budget")
                yield regs,expected,x,y
                count+=1

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("original",type=Path)
    p.add_argument("--write",type=Path)
    args=p.parse_args()
    data=args.original.read_bytes()
    assert hashlib.sha256(data).hexdigest()==BASE_SHA,"unexpected baseline"
    result,blocks,tokens=program(json.loads(data))
    out=json.dumps(result,separators=(",",":")).encode()
    for tag,side in (("leftB",0),("rightB",1)):
        for regs,expected,x,y in projection_tests(blocks[tag]):
            expected[1]=(x,y)[side]
            assert regs==expected
    if args.write:args.write.write_bytes(out)
    else:assert out==(HERE/"NF7.source.sites.json").read_bytes()
    print("2,840 register sites; all external and inserted macro edges verified.")
    print("384 complete projection-state fixtures passed.")
    print("SHA-256",hashlib.sha256(out).hexdigest())
if __name__=="__main__":main()
