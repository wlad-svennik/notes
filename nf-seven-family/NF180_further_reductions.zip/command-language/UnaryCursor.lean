import NF181PAScanner
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.Enumeration
open PA192.ModelSearch.RegisterFields PA192.ModelSearch.Words
namespace NF180Research.UnaryCursor
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000
noncomputable def remainder (n : V) : V :=
  let tag := left n
  let rest := right n
  chooseZero tag rest (chooseZero (tag-1) rest (chooseZero (tag-2) rest
    (unread (tag-3) (right (right rest)))))
instance : Language.DefinableFunction₁ ℒₒᵣ (remainder (V:=V)) := by
  unfold remainder
  definability
theorem remainder_bounded (n : V) : remainder n ≤ n := by
  have h₁ : right n ≤ n := right_bounded _
  have h₂ : right (right (right n)) ≤ n := le_trans (right_bounded _) (le_trans (right_bounded _) h₁)
  dsimp only [remainder,chooseZero]
  split
  · exact h₁
  · split
    · exact h₁
    · split
      · exact h₁
      · exact le_trans (unread_bounded ..) h₂

noncomputable def advance (s : V) : V :=
  let k := pi₁ s
  let t := remainder (pi₂ s)
  chooseZero t ⟪k+1,cantor 0 (k+1)⟫ ⟪k,t-1⟫
instance advanceDef : Language.DefinableFunction₁ ℒₒᵣ (advance (V:=V)) := by unfold advance; definability

theorem advance_zero {k n : V} (h : remainder n=0) : advance ⟪k,n⟫=⟪k+1,cantor 0 (k+1)⟫ := by simp [advance,h,chooseZero]
theorem advance_pos {k n : V} (h : remainder n≠0) : advance ⟪k,n⟫=⟪k,remainder n-1⟫ := by simp [advance,h,chooseZero]

/-- Every candidate, of arbitrary internal size and with arbitrary command fields, exhausts. -/
theorem exhaust (n : V) : ∀ k, ∃ j, j≤n+1 ∧ iterate advance j ⟪k,n⟫=⟪k+1,cantor 0 (k+1)⟫ := by
  induction n using strongModel with
  | d => definability
  | step n ih =>
    intro k
    by_cases h : remainder n=0
    · refine ⟨1,?_,?_⟩
      · simp
      · rw [show (1:V)=0+1 by simp,iterate_succ_left,iterate_zero,advance_zero h,zero_add]
    · have hp : 0<remainder n := lt_of_le_of_ne zero_le (Ne.symm h)
      have hg : 1≤remainder n := by simpa using succ_le_iff_lt.mpr hp
      have rep := sub_add_self_of_le hg
      have lt : remainder n-1<n := lt_of_lt_of_le (lt_of_lt_of_eq (show remainder n-1<(remainder n-1)+1 from by simp) rep) (remainder_bounded n)
      obtain ⟨j,hj,endp⟩ := ih (remainder n-1) lt k
      refine ⟨j+1,add_le_add (le_trans hj (le_of_eq_of_le rep (remainder_bounded n))) (le_refl 1),?_⟩
      rw [iterate_succ_left,advance_pos h,endp]

/-- Consecutive enumeration visits each candidate above the current one, also in a nonstandard model. -/
theorem epochs (start : V) : ∀ d : V, ∃ j, iterate advance j ⟪start,cantor 0 start⟫=⟪start+d,cantor 0 (start+d)⟫ := by
  apply modelInduct
  · definability
  · exact ⟨0,by simp⟩
  · intro d ih
    obtain ⟨j,h⟩ := ih
    obtain ⟨k,_,hk⟩ := exhaust (cantor 0 (start+d)) (start+d)
    exact ⟨j+k,by rw [iterate_add,h,hk,add_assoc]⟩



/-- Every internal raw candidate beyond the current epoch occurs as a cursor input. -/
theorem visits (start q : V) (hq : start ≤ q+1) : ∃ j : V,
    iterate advance j ⟪start,cantor 0 start⟫ = ⟪q+1,q⟫ := by
  obtain ⟨j,h⟩ := epochs start (q+1-start)
  have eq : start+(q+1-start)=q+1 := by rw [add_comm,sub_add_self_of_le hq]
  rw [eq] at h
  have er : remainder (cantor (0:V) (q+1)) = q+1 := by simp [remainder,chooseZero]
  have pos : remainder (cantor (0:V) (q+1)) ≠ 0 := by rw [er]; simp
  refine ⟨j+1,?_⟩
  rw [iterate_succ,h,advance_pos pos,er]
  simp
#print axioms visits
end NF180Research.UnaryCursor
