import NF181PAScanner
import NF181PAEightSound
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch
open NF181PA.Packed NF181PA.Commands NF181PA.Scanner
open PA192.ModelSearch.RegisterFields PA192.ModelSearch.Enumeration PA192.ModelSearch.Words
set_option maxHeartbeats 3000000
namespace NF180Research.NipGate
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
def observedNip (p a : V) : Prop := left (input a)=0 ∧ left (right (input a))=0 ∧ param (dataState a)=0 ∧ cache (dataState a)=p
theorem cache_on_nip {p : V} (ob : Obtainable p) (start e : V) :
    ∃ t : V, observedNip p (iterate next t (fresh start (cantor 0 start) e)) := by
  obtain ⟨w,hw⟩ := ob
  let pref := append w (NF181PA.Commands.singleton swap)
  let last := NF181PA.Commands.singleton (nip:V)
  let q := encode (append pref last) (start+1)
  obtain ⟨j,k,hj⟩ := candidate_for_word (append pref last) start
  let a := iterate next j (fresh start (cantor 0 start) e)
  have hctl : NF181PA.Scanner.control a=⟪k,q⟫ := by simpa [a,projection] using hj
  have hk : index a=k := by simpa [NF181PA.Scanner.control] using congrArg pi₁ hctl
  have hi : input a=q := by simpa [NF181PA.Scanner.control] using congrArg pi₂ hctl
  have ae : a=fresh k q (dataState a) := by
    have shape : a=fresh (index a) (input a) (dataState a) := by simp [fresh,index,input,dataState]
    exact shape.trans (by rw [hk,hi])
  have qs : q=encode pref (encode last (start+1)) := encode_append .. 
  let z:=dataState a
  have eta := state_eta z
  obtain ⟨c,hc⟩ := hw (top z) (stack z) (cache z) (param z)
  rw [eta] at hc
  have ru : run exec pref z=state c (cantor (top z) (stack z)) p 0 := by
    simp [pref,run_append,hc]
  refine ⟨j+length pref,?_⟩
  rw [iterate_add]
  change observedNip p (iterate next (length pref) a)
  rw [ae]
  change observedNip p (iterate next (length pref) (fresh k q z))
  rw [show fresh k q z=fresh k (encode pref (encode last (start+1))) z from congrArg (fun x=>fresh k x z) qs,executes_prefix,ru]
  simp [observedNip,input,dataState,fresh,last,NF181PA.Commands.singleton,assemble,nip,cmdMP,state,cache,param,chooseZero]



theorem refutation_on_nip (h : NF181PA.Pool.Pr (∅ : V) goal) (start e : V) :
    ∃ t : V, observedNip 3 (iterate next t (fresh start (cantor 0 start) e)) := by
  apply cache_on_nip _ start e
  rw [←goal_three]
  exact proof_produces h
end NF180Research.NipGate
#print axioms NF180Research.NipGate.refutation_on_nip
