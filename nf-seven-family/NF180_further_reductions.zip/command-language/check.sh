#!/bin/sh
set -eu
cd "$(dirname "$0")"
for proof in UnaryArguments UnaryCursor NipGate; do lean "$proof.lean"; done
