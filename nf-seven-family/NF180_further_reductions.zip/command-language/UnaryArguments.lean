import NF181PAScanner
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch
open PA192.ModelSearch.Enumeration PA192.ModelSearch.RegisterFields PA192.ModelSearch.Words
open NF181PA.Packed NF181PA.Commands
namespace NF180Research.UnaryArguments
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

noncomputable def bump (e : V) : V :=
  state (top e) (stack e) (cache e) (param e + 1)
instance bumpDef : Language.DefinableFunction₁ ℒₒᵣ (bump (V:=V)) := by
  unfold bump state top stack cache param
  definability

theorem bumps (t s h p : V) : ∀ d : V,
    iterate bump d (state t s h p) = state t s h (p+d) := by
  apply modelInduct
  · unfold state
    definability
  · simp
  · intro d ih
    rw [iterate_succ,ih]
    simp [bump,state,top,stack,cache,param,add_assoc]

theorem mode_from_bumps (t s h p d : V) :
    mode 0 (iterate bump d (state t s h p)) = mode d (state t s h p) := by
  rw [bumps]
  simp [mode,state,top,stack,cache,param]

theorem deduction_from_bumps (t s h p d : V) :
    deduction 0 (iterate bump d (state t s h p)) = deduction d (state t s h p) := by
  rw [bumps]
  simp [deduction,state,top,stack,cache,param]

theorem ax_from_bumps (t s h p u y delta c tail : V) :
    axRaw 0 y delta c tail (iterate bump u (state t s h p)) =
      axRaw u y delta c tail (state t s h p) := by
  rw [bumps]
  simp [axRaw,state,top,stack,cache,param]

#print axioms bumps
#print axioms mode_from_bumps
#print axioms deduction_from_bumps
#print axioms ax_from_bumps
end NF180Research.UnaryArguments
