# Further reductions after the 180-state NF machine

The published binary, blank-tape machine has 180 working states. It halts exactly when pure Quine NF proves falsum. Its PA verification includes nonstandard times and proof codes. [Machine and verification at the published commit](https://github.com/wlad-svennik/notes/tree/87440d0dc4a281caa4a32dd4165838ae9a35a0b0/nf-bb180)

## Seven axiom families

The original emitter has separate application-congruence families for the function and its argument. The new emitter uses the scheme

    f = g → (x = y → f·x = g·y).

Instantiating either equality reflexively recovers each old congruence. Applying the old congruences in succession and composing their conclusions recovers the joint rule. The Lean theorem JointPool.iff_original proves that the seven families and the original eight prove the same formulas from every assumption context in every model of PA, including formulas with nonstandard proof codes. Two of the four input terms are obtained from the two Cantor projections of one register.

SevenEmitter.emits checks the implementation of the joint rule block for arbitrary standard-natural register inputs. Regeneration checks every external and inserted macro edge and replays 384 projection fixtures.

The proposed register source has 2,840 instructions. The published source has 2,970. The logical equivalence concerns the proof calculus. Certification of a new smaller blank-tape table additionally requires physical simulation, the blank start, and a correspondence between its literal source and the seven-family scanner.

A new layout in seven-family/physical implements that register program with 220 binary working states. It starts from a blank tape, reaches the clean counter-5 frame, and passes all 7,460 signed physical branch cases. Lean also confirms that the change of addresses preserves the full decoded instruction graph. The 220-state table is a separate research implementation.

## Three 179-state candidates

The archive of literal experiments contains the transition tables, replay programs and receipts. No candidate in this archive qualifies as a lower NF bound.

| Candidate | What its tests established |
| --- | --- |
| Refill decrement changed to increment | The blank computation reaches the refill loop after 28,001 transitions. Three verified register branches keep it in that loop indefinitely. |
| Modus ponens decrements the wrong register | The altered test accepts when the cache is zero. In a literal frame for a proposed conclusion of 3, the candidate produces 3 after 43,812 binary transitions. The published machine produces 0 after 66,434. An exact command-level replay observes 3 on command 72 at epoch 42. Lean also checks a finite forcing word in every PA model. |
| Four writes to the input register redirected to the stack register | The literal table halts from the all-zero tape after precisely 53,536,390 transitions. The last transition is k:302 reading 1. |

## Other checked reductions

The decoder checkpoint contains a different 180-state table and its complete symbolic and blank-start checks. Its search jointly varies incoming and outgoing transitions when it attempts to eliminate a state. The negative results apply to the exact families and bounds recorded there.

The command-language directory contains two independent simplifications. UnaryArguments proves that repeated unit increments of the parameter can replace the argument field of each original command in every PA model. UnaryCursor proves fairness of the corresponding input cursor. The decoder checkpoint includes a 2,960-instruction version with 7,764 signed branches verified on a 228-state reference table. NipGate separately proves that an actual refutation can always be observed on a NIP command.

The command-language Lean files import NF181PAScanner. To repeat their checks after building the pinned source foundation from the published verification archive, run Lean 4.35.0 with that foundation's build directory on LEAN_PATH and its Lake dependencies on the same path. The accompanying logs list the axiom dependencies printed by Lean.
