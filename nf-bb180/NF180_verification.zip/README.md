# The 180-state blank-tape pure NF machine

`NF180.tm` is a deterministic binary Turing machine with 180 working states. Its head starts in `k:74` on an all-zero, two-way infinite tape. It enters the halt state exactly when pure Quine NF proves falsum. The halt state is separate. All 180 working states are reachable in the transition graph, and exactly one of the 360 transition rows goes to halt.

**Machine SHA-256** `6540567cb4bef6be14fce422a409338be21afeea73a1a6de856352f03b201a03`

**Register source SHA-256** `7bacb7672e2df5f580588cc493b52c62bb0574de94c3a374d28e07195beccd47`

The published 181-state machine includes an end-to-end Lean proof in first-order Peano arithmetic. This checkpoint establishes the 180-state criterion for standard computations by composing the checked components below with the published fair-search and soundness theorems. The object-PA transfer for the 180-state halting sentence is a separate proof obligation. [Published machine and PA development](https://github.com/wlad-svennik/notes/tree/261601a9e9998a7b9bf3096ee4589dfda166274b/nf-bb181)

## What saves a state

Removing one instruction from the refill loop lets the register counter start one unit ahead of the counter in the published program. Both then enumerate the same proof-search words from the corresponding epochs. An implementation with 180 states initially needed a 1 under the head. Rotating the first binary split of its address decoder makes the ordinary blank tape work with the same number of states. The old address prefixes `00`, `01`, and `1` become `0`, `10`, and `11`. The physical change touches four transitions, in `d:0` and `d:1`. The source decoder proof checks every branch destination under the new addressing.

## Verification

| What is checked | Result |
|---|---|
| Literal table | Lean proves that rendering its formal machine reproduces each of the 360 supplied transitions. The replay also checks the designated start. |
| Blank startup | At step 41,947 the machine reaches PC 0, counter 2, the eight other registers zero, gap 35, and 18 spares. At step 233,734 it reaches PC 0 with counter 5 and the eight others zero, head −10, gap 97 and 78 spares. Lean proves both full infinite-tape equalities. |
| Source program | Lean decodes the two register syntax trees and proves equality at all 2,970 instruction addresses, including the halting branch and all jump destinations. |
| Source correspondence | From the covered blank startup, the new program halts iff the published 181-state source program halts from clean PC 0 with counter 4. |
| Physical simulation | The Lean reference kernel checks 7,792 signed branch theorems, including both physical halting cases. The branches allow arbitrary register and padding values above their stated minima. There are 20 tape repetition lemmas. The blank startup gap of 97 exceeds the required 52. |
| Independent finite tests | 142,544 full successor-tape comparisons and 16 literal halts, covering 95,401,370 binary transitions. These are additional test cases. |

At the published counter-4 boundary, the initial proof data are empty. The published warm refill reaches the command scanner at candidate 5. Soundness holds from empty proof data. Any finite NF refutation is eventually tested because the fair-search theorem applies from every starting candidate. These are the two directions of the ordinary halting criterion. The relevant published theorems include `Commands.refill0To24`, `ScannerSource.halts_of_entry` and `Scanner.pool_hits`.

The principal new declarations are `Blank180.Boot.blank_margin_frame` for the physical startup and `NF180Rotation.blank_eventual_source_halt` for the source correspondence. The general physical proofs use raw Lean kernel exports. Each interval receipt ties those exports to the supplied table, program and traces. No finite search can establish nonhalting under NF consistency, and the verification does not assume a bound on the length of an NF proof.

## Replay

The default command checks every manifest entry, verifies the state count and reachability, replays the blank prefix, regenerates the parameterized symbolic traces, and regenerates the Lean counting decoder and source graph. The additional switches rebuild the Lean theorems, resubmit the raw exports to the kernel, and rerun the independent C++ simulation. Use Lean 4.35.0, including `leanchecker-paranoid`, for the proof switches.

```sh
python3 verify.py
python3 verify.py --lean --jobs 2
python3 verify.py --kernel --jobs 2
python3 verify.py --examples
```

The physical branch inventory includes 7,792 witnesses in the format of the published PA tape checker. Its finite symbolic evaluator is in `pa-format/`. To regenerate the integer witnesses, use the following commands from that directory with Lean 4.35.0 on PATH. Column order is PC, warm zero, warm positive, cold zero and cold positive. A zero entry denotes an inapplicable branch.

```sh
export LEAN_PATH="$PWD"
for f in NF210/MachineSemantics Blank180Table SourceData Finite Check; do
  lean -o "$f.olean" "$f.lean"
done
lean --run Find.lean 0 2970
```

## Search below 180

The fixed-table experiments in `search/` tested single-state removal through redirects and shared-state mergers. The recorded search spaces are finite. The checkpoint supplies no minimality claim.
