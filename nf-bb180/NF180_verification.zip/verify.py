"""Replay the ordinary blank-tape NF machine with 180 working states."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--lean', action='store_true', help='rebuild the standalone literal startup and source proofs')
ap.add_argument('--kernel', action='store_true', help='regenerate all raw exports and recheck them with leanchecker-paranoid')
ap.add_argument('--examples', action='store_true', help='replay the 142,560 concrete whole-tape cases with a C++ compiler')
ap.add_argument('--jobs', type=int, default=2)
args = ap.parse_args()
if args.jobs < 1:
    ap.error('--jobs must be positive')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run(*argv, cwd=root, env=None):
    subprocess.run(list(map(str,argv)), cwd=cwd, env=env, check=True)

for line in (root/'SHA256SUMS').read_text().splitlines():
    expected, file = line.split('  ',1)
    assert sha(root/file) == expected, file

table = root/'NF180.tm'
source = root/'source.sites.json'
sources = json.loads(source.read_text())
header,*rows = table.read_text().splitlines()
arcs = {(s,int(b)):(int(w),d,t) for s,b,w,d,t in map(str.split,rows)}
states = sorted({s for s,_ in arcs})
assert len(states)==180 and len(rows)==len(arcs)==360 and len(sources)==2970
start=header.split()[-1]
assert start=='k:74'
todo=[start]
reachable={start}
for state in todo:
    for b in [0,1]:
        w,d,t=arcs[state,b]
        assert w in [0,1] and d in ['L','R']
        if t!='halt' and t not in reachable:
            reachable.add(t)
            todo.append(t)
assert reachable==set(states)
assert [(s,b) for (s,b),(_,_,t) in arcs.items() if t=='halt']==[('k:302',1)]
literal=(root/'boot/Blank180Table.lean').read_text()
texts=re.search(r'def raw : List String := (\[.*?\])\ntheorem',literal,re.S)
assert texts and json.loads(texts[1])==[line+'\n' for line in rows]
assert int(re.search(r'def start : State := (\d+)',literal)[1])==states.index(start)
receipt=json.loads((root/'physical/kernel.json').read_text())
witness=root/'physical/traces.json.gz'
assert receipt['table']==sha(table) and receipt['source']==sha(source) and receipt['trace_sha256']==sha(witness)
intervals=sorted(receipt['intervals'],key=lambda i:i['first_pc'])
assert intervals[0]['first_pc']==0 and intervals[-1]['past_last_pc']==2970
assert all(x['past_last_pc']==y['first_pc'] for x,y in zip(intervals,intervals[1:]))
assert sum(x['branches'] for x in intervals)==receipt['branch_theorems']==7792
assert all('accepts the solution' in x['kernel'] for x in intervals)

with tempfile.TemporaryDirectory() as tmp:
    work=Path(tmp)
    shutil.copyfile(table,work/'candidate.tm')
    shutil.copyfile(source,work/'source.sites.json')
    run(sys.executable,root/'checks/replay_start.py',work,'--seed',0)
    assert (work/'seed0-frames.json').read_bytes()==(root/'blank-frames.json').read_bytes()
    run(sys.executable,root/'checks/symbolic_frames.py',work,'--write',work/'new.gz')
    assert gzip.decompress((work/'new.gz').read_bytes())==gzip.decompress(witness.read_bytes())
    proof=root/'sourceproof'
    run(sys.executable,proof/'generate_source.py',proof/'published181.sites.json',proof/'seeded.sites.json',work)
    assert (work/'SourceGraph.lean').read_bytes()==(proof/'SourceGraph.lean').read_bytes()
    run(sys.executable,proof/'generate_rotation.py','--before',proof/'seeded.sites.json',source,work)
    assert (work/'RootRotation.lean').read_bytes()==(proof/'RootRotation.lean').read_bytes()
    if args.examples:
        run(sys.executable,root/'checks/prepare.py',work)
        run('c++','-std=c++20','-O3',root/'checks/replay_examples.cpp','-o',work/'examples')
        run(work/'examples',work/'source.txt',work/'table.txt')
    if args.lean:
        build=work/'boot'
        shutil.copytree(root/'boot',build)
        run('bash','compile.sh',cwd=build,env=dict(os.environ,JOBS=str(args.jobs)))
        run('bash',proof/'verify.sh')
    if args.kernel:
        chunk=intervals[0]['past_last_pc']
        run(sys.executable,root/'checks/check_all.py',work,witness,work/'kernel.json','--jobs',args.jobs,'--chunk',chunk)
        actual=sorted(json.loads((work/'kernel.json').read_text())['intervals'],key=lambda i:i['first_pc'])
        assert [i['export_sha256'] for i in intervals]==[i['export_sha256'] for i in actual]
print('Verified the 180-state table, blank startup, 2,970 register commands and 7,792 signed branches.')
