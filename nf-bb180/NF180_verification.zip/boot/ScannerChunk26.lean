import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank180.Boot
open NF210 NF192 Blank180.Table
theorem chunk218400 : Prefix 700 snap217700 snap218400 := checked _ _ _ (by decide) (by decide)
theorem chunk219100 : Prefix 700 snap218400 snap219100 := checked _ _ _ (by decide) (by decide)
theorem chunk219800 : Prefix 700 snap219100 snap219800 := checked _ _ _ (by decide) (by decide)
theorem chunk220500 : Prefix 700 snap219800 snap220500 := checked _ _ _ (by decide) (by decide)
theorem chunk221200 : Prefix 700 snap220500 snap221200 := checked _ _ _ (by decide) (by decide)
theorem chunk221900 : Prefix 700 snap221200 snap221900 := checked _ _ _ (by decide) (by decide)
theorem chunk222600 : Prefix 700 snap221900 snap222600 := checked _ _ _ (by decide) (by decide)
theorem chunk223300 : Prefix 700 snap222600 snap223300 := checked _ _ _ (by decide) (by decide)
theorem chunk224000 : Prefix 700 snap223300 snap224000 := checked _ _ _ (by decide) (by decide)
theorem chunk224700 : Prefix 700 snap224000 snap224700 := checked _ _ _ (by decide) (by decide)
theorem chunk225400 : Prefix 700 snap224700 snap225400 := checked _ _ _ (by decide) (by decide)
theorem chunk226100 : Prefix 700 snap225400 snap226100 := checked _ _ _ (by decide) (by decide)
end Blank180.Boot
