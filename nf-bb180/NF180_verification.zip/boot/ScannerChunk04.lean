import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank180.Boot
open NF210 NF192 Blank180.Table
theorem chunk34300 : Prefix 700 snap33600 snap34300 := checked _ _ _ (by decide) (by decide)
theorem chunk35000 : Prefix 700 snap34300 snap35000 := checked _ _ _ (by decide) (by decide)
theorem chunk35700 : Prefix 700 snap35000 snap35700 := checked _ _ _ (by decide) (by decide)
theorem chunk36400 : Prefix 700 snap35700 snap36400 := checked _ _ _ (by decide) (by decide)
theorem chunk37100 : Prefix 700 snap36400 snap37100 := checked _ _ _ (by decide) (by decide)
theorem chunk37800 : Prefix 700 snap37100 snap37800 := checked _ _ _ (by decide) (by decide)
theorem chunk38500 : Prefix 700 snap37800 snap38500 := checked _ _ _ (by decide) (by decide)
theorem chunk39200 : Prefix 700 snap38500 snap39200 := checked _ _ _ (by decide) (by decide)
theorem chunk39900 : Prefix 700 snap39200 snap39900 := checked _ _ _ (by decide) (by decide)
theorem chunk40600 : Prefix 700 snap39900 snap40600 := checked _ _ _ (by decide) (by decide)
theorem chunk41300 : Prefix 700 snap40600 snap41300 := checked _ _ _ (by decide) (by decide)
theorem chunk41947 : Prefix 647 snap41300 snap41947 := checked _ _ _ (by decide) (by decide)
end Blank180.Boot
