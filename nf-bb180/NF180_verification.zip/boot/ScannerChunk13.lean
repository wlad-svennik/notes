import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank180.Boot
open NF210 NF192 Blank180.Table
theorem chunk109200 : Prefix 700 snap108500 snap109200 := checked _ _ _ (by decide) (by decide)
theorem chunk109900 : Prefix 700 snap109200 snap109900 := checked _ _ _ (by decide) (by decide)
theorem chunk110600 : Prefix 700 snap109900 snap110600 := checked _ _ _ (by decide) (by decide)
theorem chunk111300 : Prefix 700 snap110600 snap111300 := checked _ _ _ (by decide) (by decide)
theorem chunk112000 : Prefix 700 snap111300 snap112000 := checked _ _ _ (by decide) (by decide)
theorem chunk112700 : Prefix 700 snap112000 snap112700 := checked _ _ _ (by decide) (by decide)
theorem chunk113400 : Prefix 700 snap112700 snap113400 := checked _ _ _ (by decide) (by decide)
theorem chunk114100 : Prefix 700 snap113400 snap114100 := checked _ _ _ (by decide) (by decide)
theorem chunk114800 : Prefix 700 snap114100 snap114800 := checked _ _ _ (by decide) (by decide)
theorem chunk115500 : Prefix 700 snap114800 snap115500 := checked _ _ _ (by decide) (by decide)
theorem chunk116200 : Prefix 700 snap115500 snap116200 := checked _ _ _ (by decide) (by decide)
theorem chunk116900 : Prefix 700 snap116200 snap116900 := checked _ _ _ (by decide) (by decide)
end Blank180.Boot
