#!/usr/bin/env bash
set -eu
src=$(cd "$(dirname "$0")" && pwd)
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
python3 "$src/generate_rotation.py" "$src/../source.sites.json" "$out"
cmp "$src/RootRotation.lean" "$out/RootRotation.lean"
for name in ShiftSemantics SourceGraph SourceShift Halting RootRotation RotationHalting; do
  LEAN_PATH="$out" "${LEAN:-lean}" -o "$out/$name.olean" "$src/$name.lean"
done
