import RootRotation

namespace NF180Rotation
open NF180Shift

def program (i : Nat) : Cmd := rotated[i]?.getD (.jump 0)

theorem literalProgram_eq : program = newProgram := by
  funext i
  rw [program, decoded_is_inherited]
  by_cases hi : i < 9
  · have hlen : ((List.range 9).map newPrefix).length = 9 := by simp
    rw [newProgram, ite_eq_left hi]
    simp [inherited, List.getElem?_append, hlen, hi]
  · rw [newProgram, ite_eq_right hi]
    simp only [inherited, List.getElem?_append, List.length_map, List.length_range, ite_eq_right hi, List.getElem?_map, atRow]
    cases h : batches.flatten[i-9]? <;> rfl

/-- The entirely blank run enters this clean PC0 configuration with counter 5.
The old search has counter 4 at the matching boundary. -/
theorem blank_eventual_source_halt :
    Halts (raw program) (some (conf 0 5 0 0 (fun _ => 0))) ↔
      Halts (raw oldProgram) (some (conf 0 4 0 0 (fun _ => 0))) := by
  rw [literalProgram_eq]
  exact (source_halts_iff (i:=0) (by decide) ⟨4,0,0,fun _ => 0⟩).symm

private theorem shift_halts (p : Nat → Cmd) (n : Nat) (a : Option State) :
    Halts (raw p) a ↔ Halts (raw p) (iterate (raw p) n a) := by
  constructor
  · rintro ⟨k, hk⟩
    exact ⟨k, by rw [←iterate_add, Nat.add_comm, iterate_add, hk, at_none (f:=raw p) rfl]⟩
  · rintro ⟨k, hk⟩
    exact ⟨n+k, by rw [iterate_add, hk]⟩

/-- The first covered physical frame occurs at tape step 81313. The
register configuration occurs ten instructions into a clean refill. -/
theorem early_source_halt :
    Halts (raw program) (some (conf 3 0 2 2 (fun _ => 0))) ↔
      Halts (raw oldProgram) (some (conf 0 2 0 0 (fun _ => 0))) := by
  rw [literalProgram_eq]
  have entry : iterate (raw newProgram) 10 (some (conf 0 3 0 0 (fun _ => 0))) =
      some (conf 3 0 2 2 (fun _ => 0)) := by rfl
  rw [←entry, ←shift_halts]
  exact (source_halts_iff (i:=0) (by decide) ⟨2,0,0,fun _ => 0⟩).symm

#print axioms early_source_halt
#print axioms blank_eventual_source_halt
end NF180Rotation
