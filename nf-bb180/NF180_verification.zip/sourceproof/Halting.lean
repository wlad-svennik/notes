import SourceShift
namespace NF180Shift

def iterate {X : Type} (f : X → X) : Nat → X → X
  | 0, s => s
  | k+1, s => iterate f k (f s)

theorem iterate_add {X : Type} (f : X → X) (a b : Nat) (s : X) :
    iterate f (a+b) s = iterate f b (iterate f a s) := by
  induction a generalizing s with
  | zero => simp [iterate]
  | succ a ih => simpa [Nat.succ_add,iterate] using ih (f s)

def raw (p : Nat → Cmd) (s : Option State) := s.bind (fun a => execute (p a.1) a.2)

theorem reached {p : Nat → Cmd} {a b : State} (h : Reach p a b) :
    ∃ n, iterate (raw p) n (some a) = some b := by
  induction h with
  | refl => exact ⟨0,rfl⟩
  | next e _ ih =>
    obtain ⟨n,hn⟩ := ih
    exact ⟨n+1,by simpa [iterate,raw,e] using hn⟩

theorem reached_pos {p : Nat → Cmd} {a b : State} (ne : a.1≠b.1) (h : Reach p a b) :
    ∃ n, iterate (raw p) (n+1) (some a) = some b := by
  obtain ⟨n,hn⟩ := reached h
  cases n with
  | zero => have bad : a=b := by simpa [iterate] using hn
            exact (ne (congrArg Prod.fst bad)).elim
  | succ n => exact ⟨n,hn⟩

def macroOld : Option State → Option State
  | none => none
  | some (p,r) => if p=2 then some (conf 10 (r.temp+(r.counter+1)) 0 (r.word+(r.counter+1)) r.others)
      else execute (oldProgram p) r
def macroNew : Option State → Option State
  | none => none
  | some (p,r) => if p=2 then some (conf 9 (r.temp+r.counter+1) 0 (r.word+r.counter) r.others)
      else execute (newProgram p) r

theorem expandedOld (s : Option State) : ∃ n, iterate (raw oldProgram) (n+1) s = macroOld s := by
  rcases s with _|⟨p,⟨n,t,w,r⟩⟩
  · exact ⟨0,rfl⟩
  · by_cases hp : p=2
    · subst p; exact reached_pos (by change 2 ≠ 10; decide) (old_refill_all n t w r)
    · exact ⟨0,by simp [macroOld,hp,iterate,raw]⟩

theorem expandedNew (s : Option State) : ∃ n, iterate (raw newProgram) (n+1) s = macroNew s := by
  rcases s with _|⟨p,⟨n,t,w,r⟩⟩
  · exact ⟨0,rfl⟩
  · by_cases hp : p=2
    · subst p; exact reached_pos (by change 2 ≠ 9; decide) (new_refill_all n t w r)
    · exact ⟨0,by simp [macroNew,hp,iterate,raw]⟩

theorem unroll {X : Type} {f g : X → X} (expansion : ∀ s, ∃ n, iterate f (n+1) s = g s)
    (t : Nat) (s : X) : ∃ k, t≤k ∧ iterate f k s = iterate g t s := by
  induction t generalizing s with
  | zero => exact ⟨0,Nat.le_refl _,rfl⟩
  | succ t ih =>
    obtain ⟨n,hn⟩ := expansion s
    obtain ⟨k,hk,he⟩ := ih (g s)
    exact ⟨n+1+k,by omega,by rw [iterate_add,hn,he]; rfl⟩

def Halts (f : Option State → Option State) (s : Option State) := ∃ n, iterate f n s = none

theorem at_none {f : Option State → Option State} (absorbs : f none=none) (t : Nat) : iterate f t none=none := by
  induction t with
  | zero => rfl
  | succ _ ih => simpa [iterate,absorbs] using ih

theorem halts_macro {f g : Option State → Option State} (absorbs : f none=none)
    (expansion : ∀ s, ∃ n, iterate f (n+1) s=g s) (s : Option State) : Halts f s ↔ Halts g s := by
  constructor
  · rintro ⟨n,hn⟩
    obtain ⟨k,hk,he⟩ := unroll expansion n s
    refine ⟨n,?_⟩
    rw [←he, show k = n+(k-n) by omega, iterate_add,hn,at_none absorbs]
  · rintro ⟨n,hn⟩
    obtain ⟨k,_,he⟩ := unroll expansion n s
    exact ⟨k,he.trans hn⟩

inductive Related : Option State → Option State → Prop where
  | halt : Related none none
  | live (i : Nat) (r : Regs) : Allowed i → Related (some (liftPC i,r)) (some (i,r.bump))

theorem preserves_closed {c : Cmd} (h : c.closed=true) {r : Regs} {p : Nat} {s : Regs}
    (step : execute c r = some (p,s)) : Allowed p := by
  cases c with
  | jump next => simp [execute] at step; simpa [step.1,Cmd.closed] using h
  | inc i next => simp [execute] at step; simpa [step.1,Cmd.closed] using h
  | dec i z n =>
    cases e : r.read i with
    | zero =>
      cases z with
      | none => simp [execute,e] at step
      | some k =>
        simp [execute,e] at step
        simpa [Cmd.closed,step.1] using (Bool.and_eq_true_iff.mp h).2
    | succ a =>
      simp [execute,e] at step
      simpa [Cmd.closed,step.1] using (Bool.and_eq_true_iff.mp h).1

theorem forward {a b} (h : Related a b) : Related (macroOld a) (macroNew b) := by
  cases h with
  | halt => exact .halt
  | live i r ok =>
    by_cases special : i=2
    · subst i
      rcases r with ⟨k,t,w,o⟩
      change Related (some (10,⟨t+(k+1),0,w+(k+1),o⟩)) (some (9,⟨t+(k+1)+1,0,w+(k+1),o⟩))
      exact .live 9 _ (by decide)
    · have ordinary : i≤1 ∨ 9≤i := by unfold Allowed at ok; omega
      have ne : liftPC i ≠ 2 := by unfold liftPC; split <;> omega
      simp only [macroOld,macroNew,ite_eq_right ne,ite_eq_right special]
      have step := ordinary_simulation ordinary r
      cases ho : execute (oldProgram (liftPC i)) r with
      | none =>
        cases hn : execute (newProgram i) r.bump with
        | none => exact .halt
        | some n => simp [ho,hn] at step
      | some old =>
        cases hn : execute (newProgram i) r.bump with
        | none => simp [ho,hn] at step
        | some new =>
          rcases old with ⟨o,s⟩; rcases new with ⟨p,t⟩
          simp only [ho,hn,Option.map_some,Option.some.injEq,Prod.mk.injEq] at step
          rw [step.1,←step.2]
          exact .live _ _ (preserves_closed (closed_outside ordinary) hn)

theorem related_iterates {a b} (h : Related a b) (t : Nat) : Related (iterate macroOld t a) (iterate macroNew t b) := by
  induction t generalizing a b with
  | zero => exact h
  | succ t ih => exact ih (forward h)

theorem simultaneous {a b} (h : Related a b) : a=none ↔ b=none := by cases h <;> simp

/-- Source-level halting equivalence for arbitrary logical natural-register
values. At new PC 0 with epoch 2 the corresponding old epoch is 1. -/
theorem source_halts_iff {i : Nat} (ok : Allowed i) (r : Regs) :
    Halts (raw oldProgram) (some (liftPC i,r)) ↔ Halts (raw newProgram) (some (i,r.bump)) := by
  rw [halts_macro rfl expandedOld,halts_macro rfl expandedNew]
  exact ⟨fun ⟨t,ht⟩ => ⟨t,(simultaneous (related_iterates (.live i r ok) t)).mp ht⟩,
         fun ⟨t,ht⟩ => ⟨t,(simultaneous (related_iterates (.live i r ok) t)).mpr ht⟩⟩

theorem seeded_source_halts_iff :
    Halts (raw oldProgram) (some (conf 0 1 0 0 (fun _ => 0))) ↔
    Halts (raw newProgram) (some (conf 0 2 0 0 (fun _ => 0))) :=
  source_halts_iff (i:=0) (by decide) ⟨1,0,0,fun _ => 0⟩

/-- Both first complete refills expose the candidate word 2. -/
theorem first_refills :
    Reach oldProgram (conf 0 1 0 0 (fun _ => 0)) (conf 10 2 0 2 (fun _ => 0)) ∧
    Reach newProgram (conf 0 2 0 0 (fun _ => 0)) (conf 9 3 0 2 (fun _ => 0)) := by
  obtain ⟨o,n⟩ := refill_agrees 1 (fun _ => 0)
  exact ⟨.next rfl o,.next rfl n⟩

#print axioms source_halts_iff
#print axioms seeded_source_halts_iff
#print axioms first_refills
end NF180Shift
