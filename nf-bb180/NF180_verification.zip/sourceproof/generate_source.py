"""Decode two literal prefix programs, exhaustively checking every target."""
import json
import hashlib
from pathlib import Path
import argparse
a=argparse.ArgumentParser()
a.add_argument('old',type=Path)
a.add_argument('new',type=Path)
a.add_argument('out',type=Path)
args=a.parse_args()

def decode(path):
    rows=json.loads(path.read_bytes())
    ids={p:i for i,(p,o,a) in enumerate(rows)}
    assert len(ids)==len(rows)
    assert sorted(ids)==list(ids)
    assert sum(2**(40-len(p)) for p in ids)==2**40
    def first(p):
        while p not in ids:
            p+='0'
            assert len(p)<=40
        return ids[p]
    def adv(p):
        return p[:p.rfind('0')]+'1' if '0' in p else ''
    def cut(p,b,n):
        for _ in range(n):
            p=p[:p.rindex(b)]
        return p
    def cmd(p,o,a):
        if o=='CI':
            return ('inc',a,first(adv(p)))
        if o=='CD':
            return ('dec',a,None if p.endswith('1') else first(adv(cut(p,'0',1))),first(adv(p)))
        if o=='CC':
            return ('jump',first(cut(p,'1',a)))
        assert o=='CB'
        return ('jump',first(adv(cut(p,'0',a))))
    return rows, [cmd(*r) for r in rows]

oldrows,old=decode(args.old)
newrows,new=decode(args.new)
assert len(new)==2970 and len(old)==2971
assert oldrows[10:]==newrows[9:] and oldrows[:2]==newrows[:2]
def lift(p):
    return p if p is None or p<=2 else p+1

def remap(cmd):
    op,*xs=cmd
    return (op,*([xs[0]] if op!='jump' else []),*map(lift,xs[1:] if op!='jump' else xs))

for i in [0,1,*range(9,len(new))]:
    c=new[i]
    assert c[0]=='jump' or c[1]!=0
    assert old[lift(i)]==remap(c)
    assert not any(k is not None and 3<=k<9 for k in (c[2:] if c[0]!='jump' else c[1:]))

def quote(c):
    s='.'+c[0]
    for i,x in enumerate(c[1:]):
        if c[0]=='dec' and i==1:
            s+=' none' if x is None else f' (some {x})'
        else: s+=f' {x}'
    return s

head='import ShiftSemantics\n\nset_option maxHeartbeats 0\nset_option maxRecDepth 20000\nnamespace NF180Shift\n'
text=head
for name,cmds in [('oldPrefix',old[:10]),('newPrefix',new[:9])]:
    text+=f'def {name} : Nat → Cmd\n'
    for i,c in enumerate(cmds):text+='  | '+str(i)+' => '+quote(c)+'\n'
    text+='  | _ => .jump 0\n\n'
text+='''structure Entry where
  old : Cmd
  new : Cmd
  deriving Inhabited

def Entry.ok (e : Entry) : Bool := (decide (e.old=e.new.remap) && e.new.free) && e.new.closed
'''
text=text.replace('  deriving Inhabited\n','')
groups=[]
for i in range(9,len(new),64):
    group=f'rows{i:04}'
    groups.append(group)
    text+=f'def {group} : List Entry := [\n'
    text+=',\n'.join(f'  ⟨{quote(oc)}, {quote(nc)}⟩' for oc,nc in zip(old[i+1:i+65],new[i:i+64]))
    text+=']\n'
    text+=f'theorem {group}_ok : {group}.all Entry.ok = true := by decide +kernel\n'
text+='def batches : List (List Entry) := ['+', '.join(groups)+']\n'
text+='theorem batches_ok : batches.all (·.all Entry.ok) = true := by\n  simp only [batches,List.all_cons,List.all_nil,Bool.true_and,'+', '.join(f'{g}_ok' for g in groups)+']\n'
text+='end NF180Shift\n'
(args.out/'SourceGraph.lean').write_text(text)
print(f"{len(new)-7} ordinary rows including addresses 0 and 1, {len(new)-9} tail rows, 7 new and 8 old refill rows.")
