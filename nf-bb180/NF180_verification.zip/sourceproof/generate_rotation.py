"""Generate the compact counting decoder directly from both literal prefix files."""
import argparse
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--before", type=Path, help="Verify the inverse rotation against an independently supplied seeded source")
p.add_argument("after", type=Path)
p.add_argument("out", type=Path)
args = p.parse_args()

rows = {}
nodes = {}

def read_program(sites):
    assert len(sites) == 2970
    leaves = {p: (op, r) for p, op, r in sites}
    assert list(leaves) == sorted(leaves) and len(leaves) == len(sites)
    def visit(prefix):
        if prefix in leaves:
            op, r = leaves[prefix]
            assert op in ["CI", "CD", "CC", "CB"]
            key = (op, r)
            value = f".leaf .{op} {r}"
        else:
            assert len(prefix) < 48
            l = visit(prefix + "0")
            r = visit(prefix + "1")
            key = l, r
            value = f".fork tree{l} tree{r}"
        if key not in nodes:
            nodes[key] = len(nodes)
            rows[nodes[key]] = value
        return nodes[key]
    return visit("")

literal = json.loads(args.after.read_bytes())
def inverse(address):
    if address.startswith("0"):
        return "0" + address
    if address.startswith("10"):
        return "01" + address[2:]
    assert address.startswith("11")
    return address[1:]
seeded = [[inverse(p), op, reg] for p, op, reg in literal]
if args.before:
    assert seeded == json.loads(args.before.read_bytes())
original = read_program(seeded)
rotated = read_program(literal)
base = """import Halting

set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
namespace NF180Rotation
open NF180Shift

inductive Op where
  | CI | CD | CC | CB
  deriving DecidableEq

inductive Tree where
  | leaf (op : Op) (operand : Nat)
  | fork (left right : Tree)

def Tree.width : Tree → Nat
  | .leaf _ _ => 1
  | .fork l r => l.width + r.width

/-- Going left adds the exit ordinal of this subtree to the forward stack.
Going right adds the entry ordinal to the backward stack. The zero branch of
a decrement whose last direction was right halts. An exit past the final
leaf wraps to ordinal zero. -/
def decode (t : Tree) (pc : Nat) (forward backward : List Nat)
    (lastRight : Bool) : List Cmd :=
  match t with
  | .fork l r =>
      decode l pc (((pc+t.width)%2970)::forward) backward false ++
      decode r (pc+l.width) forward (pc::backward) true
  | .leaf op n =>
      let next := (pc+1)%2970
      [match op with
       | .CI => .inc n next
       | .CD => .dec n (if lastRight then none else forward[0]?) next
       | .CC => .jump (backward[n-1]?.getD 4095)
       | .CB => .jump (forward[n-1]?.getD 4095)]

"""
base += "".join(f"def tree{i} : Tree := {rhs}\n" for i, rhs in rows.items())
base += f"""
def seeded := decode tree{original} 0 [] [] false
def rotated := decode tree{rotated} 0 [] [] false
def inherited : List Cmd := (List.range 9).map newPrefix ++ batches.flatten.map Entry.new

theorem siteCount : tree{rotated}.width = 2970 := by decide +kernel
theorem rotation_preserves_every_edge : rotated = seeded := by decide +kernel
theorem decoded_is_inherited : rotated = inherited := by decide +kernel
"""
(args.out / "RootRotation.lean").write_text(base + "\nend NF180Rotation\n")
print(f"{len(rows)} distinct syntax trees cover both 2,970-leaf programs.")
