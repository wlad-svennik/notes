import Halting

set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
namespace NF180Rotation
open NF180Shift

inductive Op where
  | CI | CD | CC | CB
  deriving DecidableEq

inductive Tree where
  | leaf (op : Op) (operand : Nat)
  | fork (left right : Tree)

def Tree.width : Tree → Nat
  | .leaf _ _ => 1
  | .fork l r => l.width + r.width

/-- Going left adds the exit ordinal of this subtree to the forward stack.
Going right adds the entry ordinal to the backward stack. The zero branch of
a decrement whose last direction was right halts. An exit past the final
leaf wraps to ordinal zero. -/
def decode (t : Tree) (pc : Nat) (forward backward : List Nat)
    (lastRight : Bool) : List Cmd :=
  match t with
  | .fork l r =>
      decode l pc (((pc+t.width)%2970)::forward) backward false ++
      decode r (pc+l.width) forward (pc::backward) true
  | .leaf op n =>
      let next := (pc+1)%2970
      [match op with
       | .CI => .inc n next
       | .CD => .dec n (if lastRight then none else forward[0]?) next
       | .CC => .jump (backward[n-1]?.getD 4095)
       | .CB => .jump (forward[n-1]?.getD 4095)]

def tree0 : Tree := .leaf .CD 8
def tree1 : Tree := .leaf .CB 1
def tree2 : Tree := .fork tree0 tree1
def tree3 : Tree := .leaf .CD 0
def tree4 : Tree := .leaf .CI 7
def tree5 : Tree := .leaf .CI 6
def tree6 : Tree := .leaf .CC 3
def tree7 : Tree := .fork tree5 tree6
def tree8 : Tree := .fork tree4 tree7
def tree9 : Tree := .fork tree3 tree8
def tree10 : Tree := .leaf .CI 0
def tree11 : Tree := .leaf .CD 6
def tree12 : Tree := .leaf .CC 2
def tree13 : Tree := .fork tree11 tree12
def tree14 : Tree := .fork tree10 tree13
def tree15 : Tree := .fork tree9 tree14
def tree16 : Tree := .fork tree2 tree15
def tree17 : Tree := .fork tree11 tree1
def tree18 : Tree := .leaf .CD 7
def tree19 : Tree := .fork tree5 tree12
def tree20 : Tree := .fork tree18 tree19
def tree21 : Tree := .fork tree17 tree20
def tree22 : Tree := .fork tree4 tree21
def tree23 : Tree := .fork tree22 tree12
def tree24 : Tree := .fork tree0 tree23
def tree25 : Tree := .leaf .CI 8
def tree26 : Tree := .fork tree25 tree12
def tree27 : Tree := .fork tree18 tree26
def tree28 : Tree := .fork tree24 tree27
def tree29 : Tree := .fork tree16 tree28
def tree30 : Tree := .leaf .CI 3
def tree31 : Tree := .fork tree30 tree12
def tree32 : Tree := .fork tree11 tree31
def tree33 : Tree := .leaf .CI 4
def tree34 : Tree := .fork tree33 tree12
def tree35 : Tree := .fork tree11 tree34
def tree36 : Tree := .fork tree28 tree35
def tree37 : Tree := .fork tree32 tree36
def tree38 : Tree := .fork tree29 tree37
def tree39 : Tree := .leaf .CD 3
def tree40 : Tree := .leaf .CI 5
def tree41 : Tree := .fork tree40 tree12
def tree42 : Tree := .fork tree11 tree41
def tree43 : Tree := .leaf .CD 1
def tree44 : Tree := .fork tree43 tree19
def tree45 : Tree := .leaf .CD 2
def tree46 : Tree := .leaf .CI 1
def tree47 : Tree := .fork tree46 tree12
def tree48 : Tree := .fork tree45 tree47
def tree49 : Tree := .fork tree43 tree8
def tree50 : Tree := .fork tree11 tree47
def tree51 : Tree := .fork tree4 tree50
def tree52 : Tree := .fork tree51 tree6
def tree53 : Tree := .fork tree11 tree52
def tree54 : Tree := .fork tree49 tree53
def tree55 : Tree := .leaf .CI 2
def tree56 : Tree := .fork tree55 tree12
def tree57 : Tree := .fork tree18 tree56
def tree58 : Tree := .fork tree54 tree57
def tree59 : Tree := .fork tree48 tree58
def tree60 : Tree := .fork tree44 tree59
def tree61 : Tree := .fork tree46 tree6
def tree62 : Tree := .fork tree5 tree61
def tree63 : Tree := .fork tree39 tree62
def tree64 : Tree := .fork tree63 tree32
def tree65 : Tree := .fork tree60 tree64
def tree66 : Tree := .leaf .CD 4
def tree67 : Tree := .fork tree66 tree62
def tree68 : Tree := .fork tree67 tree35
def tree69 : Tree := .fork tree60 tree68
def tree70 : Tree := .fork tree45 tree23
def tree71 : Tree := .fork tree70 tree57
def tree72 : Tree := .fork tree46 tree61
def tree73 : Tree := .fork tree18 tree72
def tree74 : Tree := .fork tree54 tree73
def tree75 : Tree := .fork tree71 tree74
def tree76 : Tree := .fork tree69 tree75
def tree77 : Tree := .fork tree65 tree75
def tree78 : Tree := .leaf .CD 5
def tree79 : Tree := .fork tree78 tree62
def tree80 : Tree := .fork tree60 tree79
def tree81 : Tree := .fork tree80 tree42
def tree82 : Tree := .fork tree77 tree81
def tree83 : Tree := .fork tree69 tree82
def tree84 : Tree := .fork tree83 tree77
def tree85 : Tree := .fork tree76 tree84
def tree86 : Tree := .fork tree36 tree85
def tree87 : Tree := .fork tree75 tree75
def tree88 : Tree := .fork tree75 tree46
def tree89 : Tree := .fork tree81 tree88
def tree90 : Tree := .fork tree81 tree89
def tree91 : Tree := .fork tree87 tree90
def tree92 : Tree := .fork tree86 tree91
def tree93 : Tree := .fork tree76 tree92
def tree94 : Tree := .fork tree65 tree93
def tree95 : Tree := .fork tree69 tree88
def tree96 : Tree := .fork tree95 tree89
def tree97 : Tree := .fork tree46 tree96
def tree98 : Tree := .fork tree69 tree89
def tree99 : Tree := .fork tree65 tree88
def tree100 : Tree := .fork tree69 tree99
def tree101 : Tree := .fork tree65 tree89
def tree102 : Tree := .fork tree100 tree101
def tree103 : Tree := .fork tree98 tree102
def tree104 : Tree := .fork tree97 tree103
def tree105 : Tree := .fork tree46 tree99
def tree106 : Tree := .fork tree105 tree96
def tree107 : Tree := .fork tree65 tree90
def tree108 : Tree := .fork tree46 tree88
def tree109 : Tree := .fork tree98 tree75
def tree110 : Tree := .fork tree108 tree109
def tree111 : Tree := .fork tree108 tree101
def tree112 : Tree := .fork tree88 tree75
def tree113 : Tree := .fork tree98 tree112
def tree114 : Tree := .fork tree100 tree113
def tree115 : Tree := .fork tree111 tree114
def tree116 : Tree := .fork tree115 tree102
def tree117 : Tree := .fork tree110 tree116
def tree118 : Tree := .fork tree117 tree113
def tree119 : Tree := .fork tree107 tree118
def tree120 : Tree := .fork tree106 tree119
def tree121 : Tree := .fork tree60 tree90
def tree122 : Tree := .fork tree121 tree108
def tree123 : Tree := .fork tree122 tree96
def tree124 : Tree := .fork tree120 tree123
def tree125 : Tree := .fork tree60 tree124
def tree126 : Tree := .fork tree122 tree89
def tree127 : Tree := .fork tree125 tree126
def tree128 : Tree := .fork tree81 tree112
def tree129 : Tree := .fork tree127 tree128
def tree130 : Tree := .fork tree87 tree129
def tree131 : Tree := .fork tree104 tree130
def tree132 : Tree := .fork tree131 tree109
def tree133 : Tree := .fork tree94 tree132
def tree134 : Tree := .fork tree42 tree133
def tree135 : Tree := .fork tree98 tree108
def tree136 : Tree := .fork tree81 tree135
def tree137 : Tree := .fork tree134 tree136
def tree138 : Tree := .fork tree28 tree137
def tree139 : Tree := .fork tree69 tree135
def tree140 : Tree := .fork tree88 tree109
def tree141 : Tree := .fork tree139 tree140
def tree142 : Tree := .fork tree138 tree141
def tree143 : Tree := .fork tree142 tree12
def tree144 : Tree := .fork tree39 tree143
def tree145 : Tree := .fork tree78 tree12
def tree146 : Tree := .fork tree40 tree42
def tree147 : Tree := .fork tree145 tree146
def tree148 : Tree := .fork tree11 tree147
def tree149 : Tree := .fork tree44 tree148
def tree150 : Tree := .fork tree78 tree1
def tree151 : Tree := .fork tree150 tree68
def tree152 : Tree := .leaf .CC 1
def tree153 : Tree := .fork tree66 tree152
def tree154 : Tree := .fork tree78 tree152
def tree155 : Tree := .fork tree153 tree154
def tree156 : Tree := .fork tree151 tree155
def tree157 : Tree := .fork tree149 tree156
def tree158 : Tree := .fork tree76 tree157
def tree159 : Tree := .fork tree144 tree158
def tree160 : Tree := .fork tree39 tree159
def tree161 : Tree := .fork tree66 tree81
def tree162 : Tree := .fork tree78 tree78
def tree163 : Tree := .fork tree78 tree162
def tree164 : Tree := .fork tree78 tree163
def tree165 : Tree := .fork tree164 tree154
def tree166 : Tree := .fork tree71 tree42
def tree167 : Tree := .fork tree165 tree166
def tree168 : Tree := .fork tree161 tree167
def tree169 : Tree := .fork tree160 tree168
def tree170 : Tree := .fork tree38 tree169
def tree171 : Tree := .fork tree37 tree169
def tree172 : Tree := .fork tree29 tree171

def seeded := decode tree170 0 [] [] false
def rotated := decode tree172 0 [] [] false
def inherited : List Cmd := (List.range 9).map newPrefix ++ batches.flatten.map Entry.new

theorem siteCount : tree172.width = 2970 := by decide +kernel
theorem rotation_preserves_every_edge : rotated = seeded := by decide +kernel
theorem decoded_is_inherited : rotated = inherited := by decide +kernel

end NF180Rotation
