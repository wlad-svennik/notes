import Check
open Blank180 Blank180.Symbolic
def seek (pc : Nat) (cold pos : Bool) (c : Config) (n : Nat) : Nat → Option Nat
  | 0 => none
  | rest+1 => Id.run do
    if expectedHalt pc pos then
      if atGate c then return some n
    else if c.q = Data.decoderRoot && n > 0 then
      for g in [0,1] do
        for s in [0,1] do
          if returns c (signedFrame pc cold pos true g s) then
            return some (n+4096*g+8192*s)
    match step c with
    | none => return none
    | some d => return seek pc cold pos d (n+1) rest

def main (args : List String) : IO Unit := do
  let lo := (args[0]?.getD "0").toNat!
  let hi := (args[1]?.getD "2970").toNat!
  for pc in [lo:hi] do
    let mut w : Array Nat := #[]
    for c in [false,true] do
      for b in [false,true] do
        if admissible pc c b then
          match seek pc c b (signedFrame pc c b false 0 0) 0 3000 with
          | none => throw (IO.userError s!"Unresolved branch at {pc} {c} {b}")
          | some k => w := w.push k
        else w := w.push 0
    IO.println s!"{pc},{w[0]!},{w[1]!},{w[2]!},{w[3]!}"
