import sys,json
from pathlib import Path
p=Path(sys.argv[1]); table=p/'candidate.tm'; source=p/'source.sites.json'; head,*lines=table.read_text().splitlines();a=[l.split() for l in lines];names=sorted({q for q,*_ in a});idx={q:i for i,q in enumerate(names+['halt'])};t={(q,int(b)):(int(w),1 if d=='R' else -1,idx[s]) for q,b,w,d,s in a};(p/'names').write_text('\n'.join(names)+'\n');(p/'source.txt').write_text(''.join(f'{s} {o} {r}\n' for s,o,r in json.loads(source.read_text())));
with (p/'table.txt').open('w')as out:
 print(len(names),idx[head.split()[-1]],idx['d:0'],idx.get('k:302',-1),file=out)
 for q in names:
  for b in (0,1):print(*t[q,b],file=out)
