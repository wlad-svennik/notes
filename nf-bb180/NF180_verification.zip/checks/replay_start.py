from pathlib import Path
from hashlib import sha256
import argparse,json
parser=argparse.ArgumentParser();parser.add_argument('machine',type=Path);parser.add_argument('--seed',type=int,default=1);args=parser.parse_args();base=args.machine
rows=json.loads((base/'source.sites.json').read_bytes());table=(base/'candidate.tm').read_text().splitlines();start=table[0].split()[-1];names=sorted({l.split()[0]for l in table[1:]});code=rows[0][0]
arcs={(q,int(b)):(int(w),1 if d=='R'else -1,to) for q,b,w,d,to in map(str.split,table[1:])}
order=[2,8,1,4,3,7,0,5,6];h=50;q=start;b=args.seed<<h;meta=[]
for t in range(850000):
 if q=='d:0' and h>0 and (b&-b)==1<<(h-1):
  bs=bin(b>>h)[2:][::-1]
  if bs.startswith(code):
   gap=bs.find('1',len(code))
   if gap>0 and bs[gap+1:gap+2]=='0':
    blocks=bs[gap+2:].split('0');v=[len(k)-2 for k in blocks[:9]]
    if len(v)==9 and all(v[order.index(i)]==0 for i in range(1,9)) and v[order.index(0)]>=2 and all(k=='1' for k in blocks[9:]):
     if not meta or gap>=51:
      f=dict(time=t,pc=0,head=h-50,gap=gap,spares=len(blocks)-9,counter=v[order.index(0)]);meta.append(f);print(f,flush=True)
      if gap>=51:break
 if h<2 or h>=950 or q=='halt':break
 bit=b>>h&1;w,dr,q=arcs[q,bit];b^=(w^bit)<<h;h+=dr
(base/('seed'+str(args.seed)+'-frames.json')).write_text(json.dumps(meta,indent=2)+'\n')
