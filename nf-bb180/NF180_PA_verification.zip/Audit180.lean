import NF180PAIndependence
import NF180PAModelSearchExact
import NF180PAEquivalence
import NF180PAPublished181
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
open PA192.Literal
#check NF180PA.H180_eval
#check Blank180.Table.literal_exact
#check NF180PA.model_refutation
#check NF180PA.halting_equivalence
#check NFMachine180.halts_iff_nf_refutation
#check NF180PA.internal_consistency
#check NF180PA.pa_independence
#check NF180PA.true_value_independent
#check NF180PA.FromPublished181.busy_beaver
#print axioms NF180PA.model_refutation
#print axioms NF180PA.halting_equivalence
#print axioms NFMachine180.halts_iff_nf_refutation
#print axioms NF180PA.internal_consistency
#print axioms NF180PA.pa_independence
#print axioms NF180PA.true_value_independent
#print axioms NF180PA.FromPublished181.internal_consistency
#print axioms NF180PA.FromPublished181.busy_beaver
