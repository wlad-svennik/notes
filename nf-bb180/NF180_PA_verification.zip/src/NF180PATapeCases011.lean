import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w352_0 : checkWitness 352 false false 196 = true := by decide +kernel
private theorem w352_2 : checkWitness 352 true false 196 = true := by decide +kernel
private theorem cases352 : checkFour 352 (196,0,196,0) = true := by
  simp only [checkFour, w352_0,w352_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one352 : Coverage 352 353 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases352)
private theorem w353_0 : checkWitness 353 false false 619 = true := by decide +kernel
private theorem w353_1 : checkWitness 353 false true 4707 = true := by decide +kernel
private theorem w353_2 : checkWitness 353 true false 619 = true := by decide +kernel
private theorem w353_3 : checkWitness 353 true true 4707 = true := by decide +kernel
private theorem cases353 : checkFour 353 (619,4707,619,4707) = true := by
  simp only [checkFour, w353_0,w353_1,w353_2,w353_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one353 : Coverage 353 354 := checkList_sound (ws:=[(619,4707,619,4707)]) (by simpa only [checkList, Bool.and_true] using cases353)
private theorem w354_0 : checkWitness 354 false false 8948 = true := by decide +kernel
private theorem w354_2 : checkWitness 354 true false 8939 = true := by decide +kernel
private theorem cases354 : checkFour 354 (8948,0,8939,0) = true := by
  simp only [checkFour, w354_0,w354_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one354 : Coverage 354 355 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases354)
private theorem w355_0 : checkWitness 355 false false 72 = true := by decide +kernel
private theorem w355_2 : checkWitness 355 true false 72 = true := by decide +kernel
private theorem cases355 : checkFour 355 (72,0,72,0) = true := by
  simp only [checkFour, w355_0,w355_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one355 : Coverage 355 356 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases355)
private theorem w356_0 : checkWitness 356 false false 64 = true := by decide +kernel
private theorem w356_2 : checkWitness 356 true false 64 = true := by decide +kernel
private theorem cases356 : checkFour 356 (64,0,64,0) = true := by
  simp only [checkFour, w356_0,w356_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one356 : Coverage 356 357 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases356)
private theorem w357_0 : checkWitness 357 false false 625 = true := by decide +kernel
private theorem w357_1 : checkWitness 357 false true 4717 = true := by decide +kernel
private theorem w357_2 : checkWitness 357 true false 625 = true := by decide +kernel
private theorem w357_3 : checkWitness 357 true true 4717 = true := by decide +kernel
private theorem cases357 : checkFour 357 (625,4717,625,4717) = true := by
  simp only [checkFour, w357_0,w357_1,w357_2,w357_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one357 : Coverage 357 358 := checkList_sound (ws:=[(625,4717,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases357)
private theorem w358_0 : checkWitness 358 false false 8886 = true := by decide +kernel
private theorem w358_2 : checkWitness 358 true false 8882 = true := by decide +kernel
private theorem cases358 : checkFour 358 (8886,0,8882,0) = true := by
  simp only [checkFour, w358_0,w358_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one358 : Coverage 358 359 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases358)
private theorem w359_0 : checkWitness 359 false false 64 = true := by decide +kernel
private theorem w359_2 : checkWitness 359 true false 64 = true := by decide +kernel
private theorem cases359 : checkFour 359 (64,0,64,0) = true := by
  simp only [checkFour, w359_0,w359_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one359 : Coverage 359 360 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases359)
private theorem w360_0 : checkWitness 360 false false 580 = true := by decide +kernel
private theorem w360_1 : checkWitness 360 false true 4676 = true := by decide +kernel
private theorem w360_2 : checkWitness 360 true false 580 = true := by decide +kernel
private theorem w360_3 : checkWitness 360 true true 4676 = true := by decide +kernel
private theorem cases360 : checkFour 360 (580,4676,580,4676) = true := by
  simp only [checkFour, w360_0,w360_1,w360_2,w360_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one360 : Coverage 360 361 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases360)
private theorem w361_0 : checkWitness 361 false false 8921 = true := by decide +kernel
private theorem w361_2 : checkWitness 361 true false 8917 = true := by decide +kernel
private theorem cases361 : checkFour 361 (8921,0,8917,0) = true := by
  simp only [checkFour, w361_0,w361_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one361 : Coverage 361 362 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases361)
private theorem w362_0 : checkWitness 362 false false 8956 = true := by decide +kernel
private theorem w362_2 : checkWitness 362 true false 8947 = true := by decide +kernel
private theorem cases362 : checkFour 362 (8956,0,8947,0) = true := by
  simp only [checkFour, w362_0,w362_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one362 : Coverage 362 363 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases362)
private theorem w363_0 : checkWitness 363 false false 82 = true := by decide +kernel
private theorem w363_2 : checkWitness 363 true false 82 = true := by decide +kernel
private theorem cases363 : checkFour 363 (82,0,82,0) = true := by
  simp only [checkFour, w363_0,w363_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one363 : Coverage 363 364 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases363)
private theorem w364_0 : checkWitness 364 false false 668 = true := by decide +kernel
private theorem w364_1 : checkWitness 364 false true 4760 = true := by decide +kernel
private theorem w364_2 : checkWitness 364 true false 659 = true := by decide +kernel
private theorem w364_3 : checkWitness 364 true true 4751 = true := by decide +kernel
private theorem cases364 : checkFour 364 (668,4760,659,4751) = true := by
  simp only [checkFour, w364_0,w364_1,w364_2,w364_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one364 : Coverage 364 365 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases364)
private theorem w365_0 : checkWitness 365 false false 8917 = true := by decide +kernel
private theorem w365_2 : checkWitness 365 true false 8913 = true := by decide +kernel
private theorem cases365 : checkFour 365 (8917,0,8913,0) = true := by
  simp only [checkFour, w365_0,w365_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one365 : Coverage 365 366 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases365)
private theorem w366_0 : checkWitness 366 false false 662 = true := by decide +kernel
private theorem w366_1 : checkWitness 366 false true 4754 = true := by decide +kernel
private theorem w366_2 : checkWitness 366 true false 653 = true := by decide +kernel
private theorem w366_3 : checkWitness 366 true true 4745 = true := by decide +kernel
private theorem cases366 : checkFour 366 (662,4754,653,4745) = true := by
  simp only [checkFour, w366_0,w366_1,w366_2,w366_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one366 : Coverage 366 367 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases366)
private theorem w367_0 : checkWitness 367 false false 8886 = true := by decide +kernel
private theorem w367_2 : checkWitness 367 true false 8882 = true := by decide +kernel
private theorem cases367 : checkFour 367 (8886,0,8882,0) = true := by
  simp only [checkFour, w367_0,w367_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one367 : Coverage 367 368 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases367)
private theorem w368_0 : checkWitness 368 false false 70 = true := by decide +kernel
private theorem w368_2 : checkWitness 368 true false 70 = true := by decide +kernel
private theorem cases368 : checkFour 368 (70,0,70,0) = true := by
  simp only [checkFour, w368_0,w368_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one368 : Coverage 368 369 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases368)
private theorem w369_0 : checkWitness 369 false false 62 = true := by decide +kernel
private theorem w369_2 : checkWitness 369 true false 62 = true := by decide +kernel
private theorem cases369 : checkFour 369 (62,0,62,0) = true := by
  simp only [checkFour, w369_0,w369_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one369 : Coverage 369 370 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases369)
private theorem w370_0 : checkWitness 370 false false 629 = true := by decide +kernel
private theorem w370_1 : checkWitness 370 false true 4717 = true := by decide +kernel
private theorem w370_2 : checkWitness 370 true false 629 = true := by decide +kernel
private theorem w370_3 : checkWitness 370 true true 4717 = true := by decide +kernel
private theorem cases370 : checkFour 370 (629,4717,629,4717) = true := by
  simp only [checkFour, w370_0,w370_1,w370_2,w370_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one370 : Coverage 370 371 := checkList_sound (ws:=[(629,4717,629,4717)]) (by simpa only [checkList, Bool.and_true] using cases370)
private theorem w371_0 : checkWitness 371 false false 8902 = true := by decide +kernel
private theorem w371_2 : checkWitness 371 true false 8898 = true := by decide +kernel
private theorem cases371 : checkFour 371 (8902,0,8898,0) = true := by
  simp only [checkFour, w371_0,w371_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one371 : Coverage 371 372 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases371)
private theorem w372_0 : checkWitness 372 false false 8898 = true := by decide +kernel
private theorem w372_2 : checkWitness 372 true false 8894 = true := by decide +kernel
private theorem cases372 : checkFour 372 (8898,0,8894,0) = true := by
  simp only [checkFour, w372_0,w372_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one372 : Coverage 372 373 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases372)
private theorem w373_0 : checkWitness 373 false false 76 = true := by decide +kernel
private theorem w373_2 : checkWitness 373 true false 76 = true := by decide +kernel
private theorem cases373 : checkFour 373 (76,0,76,0) = true := by
  simp only [checkFour, w373_0,w373_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one373 : Coverage 373 374 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases373)
private theorem w374_0 : checkWitness 374 false false 538 = true := by decide +kernel
private theorem w374_1 : checkWitness 374 false true 4634 = true := by decide +kernel
private theorem w374_2 : checkWitness 374 true false 538 = true := by decide +kernel
private theorem w374_3 : checkWitness 374 true true 4634 = true := by decide +kernel
private theorem cases374 : checkFour 374 (538,4634,538,4634) = true := by
  simp only [checkFour, w374_0,w374_1,w374_2,w374_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one374 : Coverage 374 375 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases374)
private theorem w375_0 : checkWitness 375 false false 8933 = true := by decide +kernel
private theorem w375_2 : checkWitness 375 true false 8929 = true := by decide +kernel
private theorem cases375 : checkFour 375 (8933,0,8929,0) = true := by
  simp only [checkFour, w375_0,w375_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one375 : Coverage 375 376 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases375)
private theorem w376_0 : checkWitness 376 false false 664 = true := by decide +kernel
private theorem w376_1 : checkWitness 376 false true 4760 = true := by decide +kernel
private theorem w376_2 : checkWitness 376 true false 655 = true := by decide +kernel
private theorem w376_3 : checkWitness 376 true true 4751 = true := by decide +kernel
private theorem cases376 : checkFour 376 (664,4760,655,4751) = true := by
  simp only [checkFour, w376_0,w376_1,w376_2,w376_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one376 : Coverage 376 377 := checkList_sound (ws:=[(664,4760,655,4751)]) (by simpa only [checkList, Bool.and_true] using cases376)
private theorem w377_0 : checkWitness 377 false false 196 = true := by decide +kernel
private theorem w377_2 : checkWitness 377 true false 196 = true := by decide +kernel
private theorem cases377 : checkFour 377 (196,0,196,0) = true := by
  simp only [checkFour, w377_0,w377_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one377 : Coverage 377 378 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases377)
private theorem w378_0 : checkWitness 378 false false 619 = true := by decide +kernel
private theorem w378_1 : checkWitness 378 false true 4707 = true := by decide +kernel
private theorem w378_2 : checkWitness 378 true false 619 = true := by decide +kernel
private theorem w378_3 : checkWitness 378 true true 4707 = true := by decide +kernel
private theorem cases378 : checkFour 378 (619,4707,619,4707) = true := by
  simp only [checkFour, w378_0,w378_1,w378_2,w378_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one378 : Coverage 378 379 := checkList_sound (ws:=[(619,4707,619,4707)]) (by simpa only [checkList, Bool.and_true] using cases378)
private theorem w379_0 : checkWitness 379 false false 8948 = true := by decide +kernel
private theorem w379_2 : checkWitness 379 true false 8939 = true := by decide +kernel
private theorem cases379 : checkFour 379 (8948,0,8939,0) = true := by
  simp only [checkFour, w379_0,w379_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one379 : Coverage 379 380 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases379)
private theorem w380_0 : checkWitness 380 false false 72 = true := by decide +kernel
private theorem w380_2 : checkWitness 380 true false 72 = true := by decide +kernel
private theorem cases380 : checkFour 380 (72,0,72,0) = true := by
  simp only [checkFour, w380_0,w380_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one380 : Coverage 380 381 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases380)
private theorem w381_0 : checkWitness 381 false false 64 = true := by decide +kernel
private theorem w381_2 : checkWitness 381 true false 64 = true := by decide +kernel
private theorem cases381 : checkFour 381 (64,0,64,0) = true := by
  simp only [checkFour, w381_0,w381_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one381 : Coverage 381 382 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases381)
private theorem w382_0 : checkWitness 382 false false 625 = true := by decide +kernel
private theorem w382_1 : checkWitness 382 false true 4717 = true := by decide +kernel
private theorem w382_2 : checkWitness 382 true false 625 = true := by decide +kernel
private theorem w382_3 : checkWitness 382 true true 4717 = true := by decide +kernel
private theorem cases382 : checkFour 382 (625,4717,625,4717) = true := by
  simp only [checkFour, w382_0,w382_1,w382_2,w382_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one382 : Coverage 382 383 := checkList_sound (ws:=[(625,4717,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases382)
private theorem w383_0 : checkWitness 383 false false 8886 = true := by decide +kernel
private theorem w383_2 : checkWitness 383 true false 8882 = true := by decide +kernel
private theorem cases383 : checkFour 383 (8886,0,8882,0) = true := by
  simp only [checkFour, w383_0,w383_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one383 : Coverage 383 384 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases383)
theorem cover0352 : Coverage 352 384 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one352 one353) (Coverage.join one354 one355)) (Coverage.join (Coverage.join one356 one357) (Coverage.join one358 one359))) (Coverage.join (Coverage.join (Coverage.join one360 one361) (Coverage.join one362 one363)) (Coverage.join (Coverage.join one364 one365) (Coverage.join one366 one367)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one368 one369) (Coverage.join one370 one371)) (Coverage.join (Coverage.join one372 one373) (Coverage.join one374 one375))) (Coverage.join (Coverage.join (Coverage.join one376 one377) (Coverage.join one378 one379)) (Coverage.join (Coverage.join one380 one381) (Coverage.join one382 one383)))))
end NF180PA.Symbolic
