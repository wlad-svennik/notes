import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1344_0 : checkWitness 1344 false false 98 = true := by decide +kernel
private theorem w1344_2 : checkWitness 1344 true false 98 = true := by decide +kernel
private theorem cases1344 : checkFour 1344 (98,0,98,0) = true := by
  simp only [checkFour, w1344_0,w1344_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1344 : Coverage 1344 1345 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1344)
private theorem w1345_0 : checkWitness 1345 false false 595 = true := by decide +kernel
private theorem w1345_1 : checkWitness 1345 false true 4679 = true := by decide +kernel
private theorem w1345_2 : checkWitness 1345 true false 595 = true := by decide +kernel
private theorem w1345_3 : checkWitness 1345 true true 4679 = true := by decide +kernel
private theorem cases1345 : checkFour 1345 (595,4679,595,4679) = true := by
  simp only [checkFour, w1345_0,w1345_1,w1345_2,w1345_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1345 : Coverage 1345 1346 := checkList_sound (ws:=[(595,4679,595,4679)]) (by simpa only [checkList, Bool.and_true] using cases1345)
private theorem w1346_0 : checkWitness 1346 false false 8848 = true := by decide +kernel
private theorem w1346_2 : checkWitness 1346 true false 8844 = true := by decide +kernel
private theorem cases1346 : checkFour 1346 (8848,0,8844,0) = true := by
  simp only [checkFour, w1346_0,w1346_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1346 : Coverage 1346 1347 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases1346)
private theorem w1347_0 : checkWitness 1347 false false 98 = true := by decide +kernel
private theorem w1347_2 : checkWitness 1347 true false 98 = true := by decide +kernel
private theorem cases1347 : checkFour 1347 (98,0,98,0) = true := by
  simp only [checkFour, w1347_0,w1347_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1347 : Coverage 1347 1348 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1347)
private theorem w1348_0 : checkWitness 1348 false false 593 = true := by decide +kernel
private theorem w1348_1 : checkWitness 1348 false true 4685 = true := by decide +kernel
private theorem w1348_2 : checkWitness 1348 true false 584 = true := by decide +kernel
private theorem w1348_3 : checkWitness 1348 true true 4676 = true := by decide +kernel
private theorem cases1348 : checkFour 1348 (593,4685,584,4676) = true := by
  simp only [checkFour, w1348_0,w1348_1,w1348_2,w1348_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1348 : Coverage 1348 1349 := checkList_sound (ws:=[(593,4685,584,4676)]) (by simpa only [checkList, Bool.and_true] using cases1348)
private theorem w1349_0 : checkWitness 1349 false false 8890 = true := by decide +kernel
private theorem w1349_2 : checkWitness 1349 true false 8881 = true := by decide +kernel
private theorem cases1349 : checkFour 1349 (8890,0,8881,0) = true := by
  simp only [checkFour, w1349_0,w1349_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1349 : Coverage 1349 1350 := checkList_sound (ws:=[(8890,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases1349)
private theorem w1350_0 : checkWitness 1350 false false 8836 = true := by decide +kernel
private theorem w1350_2 : checkWitness 1350 true false 8832 = true := by decide +kernel
private theorem cases1350 : checkFour 1350 (8836,0,8832,0) = true := by
  simp only [checkFour, w1350_0,w1350_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1350 : Coverage 1350 1351 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1350)
private theorem w1351_0 : checkWitness 1351 false false 92 = true := by decide +kernel
private theorem w1351_2 : checkWitness 1351 true false 92 = true := by decide +kernel
private theorem cases1351 : checkFour 1351 (92,0,92,0) = true := by
  simp only [checkFour, w1351_0,w1351_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1351 : Coverage 1351 1352 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1351)
private theorem w1352_0 : checkWitness 1352 false false 620 = true := by decide +kernel
private theorem w1352_1 : checkWitness 1352 false true 4712 = true := by decide +kernel
private theorem w1352_2 : checkWitness 1352 true false 611 = true := by decide +kernel
private theorem w1352_3 : checkWitness 1352 true true 4703 = true := by decide +kernel
private theorem cases1352 : checkFour 1352 (620,4712,611,4703) = true := by
  simp only [checkFour, w1352_0,w1352_1,w1352_2,w1352_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1352 : Coverage 1352 1353 := checkList_sound (ws:=[(620,4712,611,4703)]) (by simpa only [checkList, Bool.and_true] using cases1352)
private theorem w1353_0 : checkWitness 1353 false false 8897 = true := by decide +kernel
private theorem w1353_2 : checkWitness 1353 true false 8888 = true := by decide +kernel
private theorem cases1353 : checkFour 1353 (8897,0,8888,0) = true := by
  simp only [checkFour, w1353_0,w1353_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1353 : Coverage 1353 1354 := checkList_sound (ws:=[(8897,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases1353)
private theorem w1354_0 : checkWitness 1354 false false 76 = true := by decide +kernel
private theorem w1354_2 : checkWitness 1354 true false 76 = true := by decide +kernel
private theorem cases1354 : checkFour 1354 (76,0,76,0) = true := by
  simp only [checkFour, w1354_0,w1354_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1354 : Coverage 1354 1355 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1354)
private theorem w1355_0 : checkWitness 1355 false false 484 = true := by decide +kernel
private theorem w1355_1 : checkWitness 1355 false true 4580 = true := by decide +kernel
private theorem w1355_2 : checkWitness 1355 true false 484 = true := by decide +kernel
private theorem w1355_3 : checkWitness 1355 true true 4580 = true := by decide +kernel
private theorem cases1355 : checkFour 1355 (484,4580,484,4580) = true := by
  simp only [checkFour, w1355_0,w1355_1,w1355_2,w1355_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1355 : Coverage 1355 1356 := checkList_sound (ws:=[(484,4580,484,4580)]) (by simpa only [checkList, Bool.and_true] using cases1355)
private theorem w1356_0 : checkWitness 1356 false false 8879 = true := by decide +kernel
private theorem w1356_2 : checkWitness 1356 true false 8875 = true := by decide +kernel
private theorem cases1356 : checkFour 1356 (8879,0,8875,0) = true := by
  simp only [checkFour, w1356_0,w1356_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1356 : Coverage 1356 1357 := checkList_sound (ws:=[(8879,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases1356)
private theorem w1357_0 : checkWitness 1357 false false 610 = true := by decide +kernel
private theorem w1357_1 : checkWitness 1357 false true 4706 = true := by decide +kernel
private theorem w1357_2 : checkWitness 1357 true false 601 = true := by decide +kernel
private theorem w1357_3 : checkWitness 1357 true true 4697 = true := by decide +kernel
private theorem cases1357 : checkFour 1357 (610,4706,601,4697) = true := by
  simp only [checkFour, w1357_0,w1357_1,w1357_2,w1357_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1357 : Coverage 1357 1358 := checkList_sound (ws:=[(610,4706,601,4697)]) (by simpa only [checkList, Bool.and_true] using cases1357)
private theorem w1358_0 : checkWitness 1358 false false 170 = true := by decide +kernel
private theorem w1358_2 : checkWitness 1358 true false 170 = true := by decide +kernel
private theorem cases1358 : checkFour 1358 (170,0,170,0) = true := by
  simp only [checkFour, w1358_0,w1358_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1358 : Coverage 1358 1359 := checkList_sound (ws:=[(170,0,170,0)]) (by simpa only [checkList, Bool.and_true] using cases1358)
private theorem w1359_0 : checkWitness 1359 false false 565 = true := by decide +kernel
private theorem w1359_1 : checkWitness 1359 false true 4653 = true := by decide +kernel
private theorem w1359_2 : checkWitness 1359 true false 565 = true := by decide +kernel
private theorem w1359_3 : checkWitness 1359 true true 4653 = true := by decide +kernel
private theorem cases1359 : checkFour 1359 (565,4653,565,4653) = true := by
  simp only [checkFour, w1359_0,w1359_1,w1359_2,w1359_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1359 : Coverage 1359 1360 := checkList_sound (ws:=[(565,4653,565,4653)]) (by simpa only [checkList, Bool.and_true] using cases1359)
private theorem w1360_0 : checkWitness 1360 false false 8894 = true := by decide +kernel
private theorem w1360_2 : checkWitness 1360 true false 8885 = true := by decide +kernel
private theorem cases1360 : checkFour 1360 (8894,0,8885,0) = true := by
  simp only [checkFour, w1360_0,w1360_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1360 : Coverage 1360 1361 := checkList_sound (ws:=[(8894,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1360)
private theorem w1361_0 : checkWitness 1361 false false 94 = true := by decide +kernel
private theorem w1361_2 : checkWitness 1361 true false 94 = true := by decide +kernel
private theorem cases1361 : checkFour 1361 (94,0,94,0) = true := by
  simp only [checkFour, w1361_0,w1361_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1361 : Coverage 1361 1362 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1361)
private theorem w1362_0 : checkWitness 1362 false false 86 = true := by decide +kernel
private theorem w1362_2 : checkWitness 1362 true false 86 = true := by decide +kernel
private theorem cases1362 : checkFour 1362 (86,0,86,0) = true := by
  simp only [checkFour, w1362_0,w1362_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1362 : Coverage 1362 1363 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1362)
private theorem w1363_0 : checkWitness 1363 false false 571 = true := by decide +kernel
private theorem w1363_1 : checkWitness 1363 false true 4663 = true := by decide +kernel
private theorem w1363_2 : checkWitness 1363 true false 571 = true := by decide +kernel
private theorem w1363_3 : checkWitness 1363 true true 4663 = true := by decide +kernel
private theorem cases1363 : checkFour 1363 (571,4663,571,4663) = true := by
  simp only [checkFour, w1363_0,w1363_1,w1363_2,w1363_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1363 : Coverage 1363 1364 := checkList_sound (ws:=[(571,4663,571,4663)]) (by simpa only [checkList, Bool.and_true] using cases1363)
private theorem w1364_0 : checkWitness 1364 false false 8832 = true := by decide +kernel
private theorem w1364_2 : checkWitness 1364 true false 8828 = true := by decide +kernel
private theorem cases1364 : checkFour 1364 (8832,0,8828,0) = true := by
  simp only [checkFour, w1364_0,w1364_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1364 : Coverage 1364 1365 := checkList_sound (ws:=[(8832,0,8828,0)]) (by simpa only [checkList, Bool.and_true] using cases1364)
private theorem w1365_0 : checkWitness 1365 false false 86 = true := by decide +kernel
private theorem w1365_2 : checkWitness 1365 true false 86 = true := by decide +kernel
private theorem cases1365 : checkFour 1365 (86,0,86,0) = true := by
  simp only [checkFour, w1365_0,w1365_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1365 : Coverage 1365 1366 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1365)
private theorem w1366_0 : checkWitness 1366 false false 526 = true := by decide +kernel
private theorem w1366_1 : checkWitness 1366 false true 4622 = true := by decide +kernel
private theorem w1366_2 : checkWitness 1366 true false 526 = true := by decide +kernel
private theorem w1366_3 : checkWitness 1366 true true 4622 = true := by decide +kernel
private theorem cases1366 : checkFour 1366 (526,4622,526,4622) = true := by
  simp only [checkFour, w1366_0,w1366_1,w1366_2,w1366_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1366 : Coverage 1366 1367 := checkList_sound (ws:=[(526,4622,526,4622)]) (by simpa only [checkList, Bool.and_true] using cases1366)
private theorem w1367_0 : checkWitness 1367 false false 8867 = true := by decide +kernel
private theorem w1367_2 : checkWitness 1367 true false 8863 = true := by decide +kernel
private theorem cases1367 : checkFour 1367 (8867,0,8863,0) = true := by
  simp only [checkFour, w1367_0,w1367_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1367 : Coverage 1367 1368 := checkList_sound (ws:=[(8867,0,8863,0)]) (by simpa only [checkList, Bool.and_true] using cases1367)
private theorem w1368_0 : checkWitness 1368 false false 8902 = true := by decide +kernel
private theorem w1368_2 : checkWitness 1368 true false 8893 = true := by decide +kernel
private theorem cases1368 : checkFour 1368 (8902,0,8893,0) = true := by
  simp only [checkFour, w1368_0,w1368_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1368 : Coverage 1368 1369 := checkList_sound (ws:=[(8902,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases1368)
private theorem w1369_0 : checkWitness 1369 false false 104 = true := by decide +kernel
private theorem w1369_2 : checkWitness 1369 true false 104 = true := by decide +kernel
private theorem cases1369 : checkFour 1369 (104,0,104,0) = true := by
  simp only [checkFour, w1369_0,w1369_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1369 : Coverage 1369 1370 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases1369)
private theorem w1370_0 : checkWitness 1370 false false 614 = true := by decide +kernel
private theorem w1370_1 : checkWitness 1370 false true 4706 = true := by decide +kernel
private theorem w1370_2 : checkWitness 1370 true false 605 = true := by decide +kernel
private theorem w1370_3 : checkWitness 1370 true true 4697 = true := by decide +kernel
private theorem cases1370 : checkFour 1370 (614,4706,605,4697) = true := by
  simp only [checkFour, w1370_0,w1370_1,w1370_2,w1370_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1370 : Coverage 1370 1371 := checkList_sound (ws:=[(614,4706,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases1370)
private theorem w1371_0 : checkWitness 1371 false false 8863 = true := by decide +kernel
private theorem w1371_2 : checkWitness 1371 true false 8859 = true := by decide +kernel
private theorem cases1371 : checkFour 1371 (8863,0,8859,0) = true := by
  simp only [checkFour, w1371_0,w1371_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1371 : Coverage 1371 1372 := checkList_sound (ws:=[(8863,0,8859,0)]) (by simpa only [checkList, Bool.and_true] using cases1371)
private theorem w1372_0 : checkWitness 1372 false false 608 = true := by decide +kernel
private theorem w1372_1 : checkWitness 1372 false true 4700 = true := by decide +kernel
private theorem w1372_2 : checkWitness 1372 true false 599 = true := by decide +kernel
private theorem w1372_3 : checkWitness 1372 true true 4691 = true := by decide +kernel
private theorem cases1372 : checkFour 1372 (608,4700,599,4691) = true := by
  simp only [checkFour, w1372_0,w1372_1,w1372_2,w1372_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1372 : Coverage 1372 1373 := checkList_sound (ws:=[(608,4700,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases1372)
private theorem w1373_0 : checkWitness 1373 false false 8832 = true := by decide +kernel
private theorem w1373_2 : checkWitness 1373 true false 8828 = true := by decide +kernel
private theorem cases1373 : checkFour 1373 (8832,0,8828,0) = true := by
  simp only [checkFour, w1373_0,w1373_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1373 : Coverage 1373 1374 := checkList_sound (ws:=[(8832,0,8828,0)]) (by simpa only [checkList, Bool.and_true] using cases1373)
private theorem w1374_0 : checkWitness 1374 false false 92 = true := by decide +kernel
private theorem w1374_2 : checkWitness 1374 true false 92 = true := by decide +kernel
private theorem cases1374 : checkFour 1374 (92,0,92,0) = true := by
  simp only [checkFour, w1374_0,w1374_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1374 : Coverage 1374 1375 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1374)
private theorem w1375_0 : checkWitness 1375 false false 84 = true := by decide +kernel
private theorem w1375_2 : checkWitness 1375 true false 84 = true := by decide +kernel
private theorem cases1375 : checkFour 1375 (84,0,84,0) = true := by
  simp only [checkFour, w1375_0,w1375_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1375 : Coverage 1375 1376 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1375)
theorem cover1344 : Coverage 1344 1376 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1344 one1345) (Coverage.join one1346 one1347)) (Coverage.join (Coverage.join one1348 one1349) (Coverage.join one1350 one1351))) (Coverage.join (Coverage.join (Coverage.join one1352 one1353) (Coverage.join one1354 one1355)) (Coverage.join (Coverage.join one1356 one1357) (Coverage.join one1358 one1359)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1360 one1361) (Coverage.join one1362 one1363)) (Coverage.join (Coverage.join one1364 one1365) (Coverage.join one1366 one1367))) (Coverage.join (Coverage.join (Coverage.join one1368 one1369) (Coverage.join one1370 one1371)) (Coverage.join (Coverage.join one1372 one1373) (Coverage.join one1374 one1375)))))
end NF180PA.Symbolic
