import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w224_0 : checkWitness 224 false false 512 = true := by decide +kernel
private theorem w224_1 : checkWitness 224 false true 4608 = true := by decide +kernel
private theorem w224_2 : checkWitness 224 true false 512 = true := by decide +kernel
private theorem w224_3 : checkWitness 224 true true 4608 = true := by decide +kernel
private theorem cases224 : checkFour 224 (512,4608,512,4608) = true := by
  simp only [checkFour, w224_0,w224_1,w224_2,w224_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one224 : Coverage 224 225 := checkList_sound (ws:=[(512,4608,512,4608)]) (by simpa only [checkList, Bool.and_true] using cases224)
private theorem w225_0 : checkWitness 225 false false 8870 = true := by decide +kernel
private theorem w225_2 : checkWitness 225 true false 8866 = true := by decide +kernel
private theorem cases225 : checkFour 225 (8870,0,8866,0) = true := by
  simp only [checkFour, w225_0,w225_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one225 : Coverage 225 226 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases225)
private theorem w226_0 : checkWitness 226 false false 68 = true := by decide +kernel
private theorem w226_2 : checkWitness 226 true false 68 = true := by decide +kernel
private theorem cases226 : checkFour 226 (68,0,68,0) = true := by
  simp only [checkFour, w226_0,w226_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one226 : Coverage 226 227 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases226)
private theorem w227_0 : checkWitness 227 false false 550 = true := by decide +kernel
private theorem w227_1 : checkWitness 227 false true 4646 = true := by decide +kernel
private theorem w227_2 : checkWitness 227 true false 550 = true := by decide +kernel
private theorem w227_3 : checkWitness 227 true true 4646 = true := by decide +kernel
private theorem cases227 : checkFour 227 (550,4646,550,4646) = true := by
  simp only [checkFour, w227_0,w227_1,w227_2,w227_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one227 : Coverage 227 228 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases227)
private theorem w228_0 : checkWitness 228 false false 8891 = true := by decide +kernel
private theorem w228_2 : checkWitness 228 true false 8887 = true := by decide +kernel
private theorem cases228 : checkFour 228 (8891,0,8887,0) = true := by
  simp only [checkFour, w228_0,w228_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one228 : Coverage 228 229 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases228)
private theorem w229_0 : checkWitness 229 false false 8926 = true := by decide +kernel
private theorem w229_2 : checkWitness 229 true false 8917 = true := by decide +kernel
private theorem cases229 : checkFour 229 (8926,0,8917,0) = true := by
  simp only [checkFour, w229_0,w229_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one229 : Coverage 229 230 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases229)
private theorem w230_0 : checkWitness 230 false false 92 = true := by decide +kernel
private theorem w230_2 : checkWitness 230 true false 92 = true := by decide +kernel
private theorem cases230 : checkFour 230 (92,0,92,0) = true := by
  simp only [checkFour, w230_0,w230_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one230 : Coverage 230 231 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases230)
private theorem w231_0 : checkWitness 231 false false 638 = true := by decide +kernel
private theorem w231_1 : checkWitness 231 false true 4730 = true := by decide +kernel
private theorem w231_2 : checkWitness 231 true false 629 = true := by decide +kernel
private theorem w231_3 : checkWitness 231 true true 4721 = true := by decide +kernel
private theorem cases231 : checkFour 231 (638,4730,629,4721) = true := by
  simp only [checkFour, w231_0,w231_1,w231_2,w231_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one231 : Coverage 231 232 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases231)
private theorem w232_0 : checkWitness 232 false false 8887 = true := by decide +kernel
private theorem w232_2 : checkWitness 232 true false 8883 = true := by decide +kernel
private theorem cases232 : checkFour 232 (8887,0,8883,0) = true := by
  simp only [checkFour, w232_0,w232_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one232 : Coverage 232 233 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases232)
private theorem w233_0 : checkWitness 233 false false 632 = true := by decide +kernel
private theorem w233_1 : checkWitness 233 false true 4724 = true := by decide +kernel
private theorem w233_2 : checkWitness 233 true false 623 = true := by decide +kernel
private theorem w233_3 : checkWitness 233 true true 4715 = true := by decide +kernel
private theorem cases233 : checkFour 233 (632,4724,623,4715) = true := by
  simp only [checkFour, w233_0,w233_1,w233_2,w233_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one233 : Coverage 233 234 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases233)
private theorem w234_0 : checkWitness 234 false false 8856 = true := by decide +kernel
private theorem w234_2 : checkWitness 234 true false 8852 = true := by decide +kernel
private theorem cases234 : checkFour 234 (8856,0,8852,0) = true := by
  simp only [checkFour, w234_0,w234_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one234 : Coverage 234 235 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases234)
private theorem w235_0 : checkWitness 235 false false 80 = true := by decide +kernel
private theorem w235_2 : checkWitness 235 true false 80 = true := by decide +kernel
private theorem cases235 : checkFour 235 (80,0,80,0) = true := by
  simp only [checkFour, w235_0,w235_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one235 : Coverage 235 236 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases235)
private theorem w236_0 : checkWitness 236 false false 72 = true := by decide +kernel
private theorem w236_2 : checkWitness 236 true false 72 = true := by decide +kernel
private theorem cases236 : checkFour 236 (72,0,72,0) = true := by
  simp only [checkFour, w236_0,w236_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one236 : Coverage 236 237 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases236)
private theorem w237_0 : checkWitness 237 false false 597 = true := by decide +kernel
private theorem w237_1 : checkWitness 237 false true 4681 = true := by decide +kernel
private theorem w237_2 : checkWitness 237 true false 597 = true := by decide +kernel
private theorem w237_3 : checkWitness 237 true true 4681 = true := by decide +kernel
private theorem cases237 : checkFour 237 (597,4681,597,4681) = true := by
  simp only [checkFour, w237_0,w237_1,w237_2,w237_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one237 : Coverage 237 238 := checkList_sound (ws:=[(597,4681,597,4681)]) (by simpa only [checkList, Bool.and_true] using cases237)
private theorem w238_0 : checkWitness 238 false false 8850 = true := by decide +kernel
private theorem w238_2 : checkWitness 238 true false 8846 = true := by decide +kernel
private theorem cases238 : checkFour 238 (8850,0,8846,0) = true := by
  simp only [checkFour, w238_0,w238_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one238 : Coverage 238 239 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases238)
private theorem w239_0 : checkWitness 239 false false 72 = true := by decide +kernel
private theorem w239_2 : checkWitness 239 true false 72 = true := by decide +kernel
private theorem cases239 : checkFour 239 (72,0,72,0) = true := by
  simp only [checkFour, w239_0,w239_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one239 : Coverage 239 240 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases239)
private theorem w240_0 : checkWitness 240 false false 602 = true := by decide +kernel
private theorem w240_1 : checkWitness 240 false true 4698 = true := by decide +kernel
private theorem w240_2 : checkWitness 240 true false 602 = true := by decide +kernel
private theorem w240_3 : checkWitness 240 true true 4698 = true := by decide +kernel
private theorem cases240 : checkFour 240 (602,4698,602,4698) = true := by
  simp only [checkFour, w240_0,w240_1,w240_2,w240_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one240 : Coverage 240 241 := checkList_sound (ws:=[(602,4698,602,4698)]) (by simpa only [checkList, Bool.and_true] using cases240)
private theorem w241_0 : checkWitness 241 false false 8918 = true := by decide +kernel
private theorem w241_2 : checkWitness 241 true false 8909 = true := by decide +kernel
private theorem cases241 : checkFour 241 (8918,0,8909,0) = true := by
  simp only [checkFour, w241_0,w241_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one241 : Coverage 241 242 := checkList_sound (ws:=[(8918,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases241)
private theorem w242_0 : checkWitness 242 false false 8864 = true := by decide +kernel
private theorem w242_2 : checkWitness 242 true false 8860 = true := by decide +kernel
private theorem cases242 : checkFour 242 (8864,0,8860,0) = true := by
  simp only [checkFour, w242_0,w242_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one242 : Coverage 242 243 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases242)
private theorem w243_0 : checkWitness 243 false false 80 = true := by decide +kernel
private theorem w243_2 : checkWitness 243 true false 80 = true := by decide +kernel
private theorem cases243 : checkFour 243 (80,0,80,0) = true := by
  simp only [checkFour, w243_0,w243_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one243 : Coverage 243 244 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases243)
private theorem w244_0 : checkWitness 244 false false 648 = true := by decide +kernel
private theorem w244_1 : checkWitness 244 false true 4736 = true := by decide +kernel
private theorem w244_2 : checkWitness 244 true false 639 = true := by decide +kernel
private theorem w244_3 : checkWitness 244 true true 4727 = true := by decide +kernel
private theorem cases244 : checkFour 244 (648,4736,639,4727) = true := by
  simp only [checkFour, w244_0,w244_1,w244_2,w244_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one244 : Coverage 244 245 := checkList_sound (ws:=[(648,4736,639,4727)]) (by simpa only [checkList, Bool.and_true] using cases244)
private theorem w245_0 : checkWitness 245 false false 8906 = true := by decide +kernel
private theorem w245_2 : checkWitness 245 true false 8902 = true := by decide +kernel
private theorem cases245 : checkFour 245 (8906,0,8902,0) = true := by
  simp only [checkFour, w245_0,w245_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one245 : Coverage 245 246 := checkList_sound (ws:=[(8906,0,8902,0)]) (by simpa only [checkList, Bool.and_true] using cases245)
private theorem w246_0 : checkWitness 246 false false 70 = true := by decide +kernel
private theorem w246_2 : checkWitness 246 true false 70 = true := by decide +kernel
private theorem cases246 : checkFour 246 (70,0,70,0) = true := by
  simp only [checkFour, w246_0,w246_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one246 : Coverage 246 247 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases246)
private theorem w247_0 : checkWitness 247 false false 510 = true := by decide +kernel
private theorem w247_1 : checkWitness 247 false true 4606 = true := by decide +kernel
private theorem w247_2 : checkWitness 247 true false 510 = true := by decide +kernel
private theorem w247_3 : checkWitness 247 true true 4606 = true := by decide +kernel
private theorem cases247 : checkFour 247 (510,4606,510,4606) = true := by
  simp only [checkFour, w247_0,w247_1,w247_2,w247_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one247 : Coverage 247 248 := checkList_sound (ws:=[(510,4606,510,4606)]) (by simpa only [checkList, Bool.and_true] using cases247)
private theorem w248_0 : checkWitness 248 false false 8905 = true := by decide +kernel
private theorem w248_2 : checkWitness 248 true false 8901 = true := by decide +kernel
private theorem cases248 : checkFour 248 (8905,0,8901,0) = true := by
  simp only [checkFour, w248_0,w248_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one248 : Coverage 248 249 := checkList_sound (ws:=[(8905,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases248)
private theorem w249_0 : checkWitness 249 false false 636 = true := by decide +kernel
private theorem w249_1 : checkWitness 249 false true 4732 = true := by decide +kernel
private theorem w249_2 : checkWitness 249 true false 627 = true := by decide +kernel
private theorem w249_3 : checkWitness 249 true true 4723 = true := by decide +kernel
private theorem cases249 : checkFour 249 (636,4732,627,4723) = true := by
  simp only [checkFour, w249_0,w249_1,w249_2,w249_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one249 : Coverage 249 250 := checkList_sound (ws:=[(636,4732,627,4723)]) (by simpa only [checkList, Bool.and_true] using cases249)
private theorem w250_0 : checkWitness 250 false false 184 = true := by decide +kernel
private theorem w250_2 : checkWitness 250 true false 184 = true := by decide +kernel
private theorem cases250 : checkFour 250 (184,0,184,0) = true := by
  simp only [checkFour, w250_0,w250_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one250 : Coverage 250 251 := checkList_sound (ws:=[(184,0,184,0)]) (by simpa only [checkList, Bool.and_true] using cases250)
private theorem w251_0 : checkWitness 251 false false 591 = true := by decide +kernel
private theorem w251_1 : checkWitness 251 false true 4679 = true := by decide +kernel
private theorem w251_2 : checkWitness 251 true false 591 = true := by decide +kernel
private theorem w251_3 : checkWitness 251 true true 4679 = true := by decide +kernel
private theorem cases251 : checkFour 251 (591,4679,591,4679) = true := by
  simp only [checkFour, w251_0,w251_1,w251_2,w251_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one251 : Coverage 251 252 := checkList_sound (ws:=[(591,4679,591,4679)]) (by simpa only [checkList, Bool.and_true] using cases251)
private theorem w252_0 : checkWitness 252 false false 8920 = true := by decide +kernel
private theorem w252_2 : checkWitness 252 true false 8911 = true := by decide +kernel
private theorem cases252 : checkFour 252 (8920,0,8911,0) = true := by
  simp only [checkFour, w252_0,w252_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one252 : Coverage 252 253 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases252)
private theorem w253_0 : checkWitness 253 false false 76 = true := by decide +kernel
private theorem w253_2 : checkWitness 253 true false 76 = true := by decide +kernel
private theorem cases253 : checkFour 253 (76,0,76,0) = true := by
  simp only [checkFour, w253_0,w253_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one253 : Coverage 253 254 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases253)
private theorem w254_0 : checkWitness 254 false false 68 = true := by decide +kernel
private theorem w254_2 : checkWitness 254 true false 68 = true := by decide +kernel
private theorem cases254 : checkFour 254 (68,0,68,0) = true := by
  simp only [checkFour, w254_0,w254_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one254 : Coverage 254 255 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases254)
private theorem w255_0 : checkWitness 255 false false 597 = true := by decide +kernel
private theorem w255_1 : checkWitness 255 false true 4689 = true := by decide +kernel
private theorem w255_2 : checkWitness 255 true false 597 = true := by decide +kernel
private theorem w255_3 : checkWitness 255 true true 4689 = true := by decide +kernel
private theorem cases255 : checkFour 255 (597,4689,597,4689) = true := by
  simp only [checkFour, w255_0,w255_1,w255_2,w255_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one255 : Coverage 255 256 := checkList_sound (ws:=[(597,4689,597,4689)]) (by simpa only [checkList, Bool.and_true] using cases255)
theorem cover0224 : Coverage 224 256 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one224 one225) (Coverage.join one226 one227)) (Coverage.join (Coverage.join one228 one229) (Coverage.join one230 one231))) (Coverage.join (Coverage.join (Coverage.join one232 one233) (Coverage.join one234 one235)) (Coverage.join (Coverage.join one236 one237) (Coverage.join one238 one239)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one240 one241) (Coverage.join one242 one243)) (Coverage.join (Coverage.join one244 one245) (Coverage.join one246 one247))) (Coverage.join (Coverage.join (Coverage.join one248 one249) (Coverage.join one250 one251)) (Coverage.join (Coverage.join one252 one253) (Coverage.join one254 one255)))))
end NF180PA.Symbolic
