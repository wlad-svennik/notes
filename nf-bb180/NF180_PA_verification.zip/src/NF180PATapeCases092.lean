import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2944_0 : checkWitness 2944 false false 8982 = true := by decide +kernel
private theorem w2944_2 : checkWitness 2944 true false 8973 = true := by decide +kernel
private theorem cases2944 : checkFour 2944 (8982,0,8973,0) = true := by
  simp only [checkFour, w2944_0,w2944_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2944 : Coverage 2944 2945 := checkList_sound (ws:=[(8982,0,8973,0)]) (by simpa only [checkList, Bool.and_true] using cases2944)
private theorem w2945_0 : checkWitness 2945 false false 8928 = true := by decide +kernel
private theorem w2945_2 : checkWitness 2945 true false 8924 = true := by decide +kernel
private theorem cases2945 : checkFour 2945 (8928,0,8924,0) = true := by
  simp only [checkFour, w2945_0,w2945_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2945 : Coverage 2945 2946 := checkList_sound (ws:=[(8928,0,8924,0)]) (by simpa only [checkList, Bool.and_true] using cases2945)
private theorem w2946_0 : checkWitness 2946 false false 46 = true := by decide +kernel
private theorem w2946_2 : checkWitness 2946 true false 46 = true := by decide +kernel
private theorem cases2946 : checkFour 2946 (46,0,46,0) = true := by
  simp only [checkFour, w2946_0,w2946_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2946 : Coverage 2946 2947 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2946)
private theorem w2947_0 : checkWitness 2947 false false 716 = true := by decide +kernel
private theorem w2947_1 : checkWitness 2947 false true 4804 = true := by decide +kernel
private theorem w2947_2 : checkWitness 2947 true false 707 = true := by decide +kernel
private theorem w2947_3 : checkWitness 2947 true true 4795 = true := by decide +kernel
private theorem cases2947 : checkFour 2947 (716,4804,707,4795) = true := by
  simp only [checkFour, w2947_0,w2947_1,w2947_2,w2947_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2947 : Coverage 2947 2948 := checkList_sound (ws:=[(716,4804,707,4795)]) (by simpa only [checkList, Bool.and_true] using cases2947)
private theorem w2948_0 : checkWitness 2948 false false 8989 = true := by decide +kernel
private theorem w2948_2 : checkWitness 2948 true false 8980 = true := by decide +kernel
private theorem cases2948 : checkFour 2948 (8989,0,8980,0) = true := by
  simp only [checkFour, w2948_0,w2948_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2948 : Coverage 2948 2949 := checkList_sound (ws:=[(8989,0,8980,0)]) (by simpa only [checkList, Bool.and_true] using cases2948)
private theorem w2949_0 : checkWitness 2949 false false 30 = true := by decide +kernel
private theorem w2949_2 : checkWitness 2949 true false 30 = true := by decide +kernel
private theorem cases2949 : checkFour 2949 (30,0,30,0) = true := by
  simp only [checkFour, w2949_0,w2949_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2949 : Coverage 2949 2950 := checkList_sound (ws:=[(30,0,30,0)]) (by simpa only [checkList, Bool.and_true] using cases2949)
private theorem w2950_0 : checkWitness 2950 false false 679 = true := by decide +kernel
private theorem w2950_1 : checkWitness 2950 false true 4775 = true := by decide +kernel
private theorem w2950_2 : checkWitness 2950 true false 670 = true := by decide +kernel
private theorem w2950_3 : checkWitness 2950 true true 4766 = true := by decide +kernel
private theorem cases2950 : checkFour 2950 (679,4775,670,4766) = true := by
  simp only [checkFour, w2950_0,w2950_1,w2950_2,w2950_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2950 : Coverage 2950 2951 := checkList_sound (ws:=[(679,4775,670,4766)]) (by simpa only [checkList, Bool.and_true] using cases2950)
private theorem w2951_0 : checkWitness 2951 false false 685 = true := by decide +kernel
private theorem w2951_1 : checkWitness 2951 false true 4777 = true := by decide +kernel
private theorem w2951_2 : checkWitness 2951 true false 676 = true := by decide +kernel
private theorem w2951_3 : checkWitness 2951 true true 4768 = true := by decide +kernel
private theorem cases2951 : checkFour 2951 (685,4777,676,4768) = true := by
  simp only [checkFour, w2951_0,w2951_1,w2951_2,w2951_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2951 : Coverage 2951 2952 := checkList_sound (ws:=[(685,4777,676,4768)]) (by simpa only [checkList, Bool.and_true] using cases2951)
private theorem w2952_0 : checkWitness 2952 false false 685 = true := by decide +kernel
private theorem w2952_1 : checkWitness 2952 false true 4773 = true := by decide +kernel
private theorem w2952_2 : checkWitness 2952 true false 676 = true := by decide +kernel
private theorem w2952_3 : checkWitness 2952 true true 4764 = true := by decide +kernel
private theorem cases2952 : checkFour 2952 (685,4773,676,4764) = true := by
  simp only [checkFour, w2952_0,w2952_1,w2952_2,w2952_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2952 : Coverage 2952 2953 := checkList_sound (ws:=[(685,4773,676,4764)]) (by simpa only [checkList, Bool.and_true] using cases2952)
private theorem w2953_0 : checkWitness 2953 false false 469 = true := by decide +kernel
private theorem w2953_1 : checkWitness 2953 false true 4779 = true := by decide +kernel
private theorem w2953_2 : checkWitness 2953 true false 460 = true := by decide +kernel
private theorem w2953_3 : checkWitness 2953 true true 4770 = true := by decide +kernel
private theorem cases2953 : checkFour 2953 (469,4779,460,4770) = true := by
  simp only [checkFour, w2953_0,w2953_1,w2953_2,w2953_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2953 : Coverage 2953 2954 := checkList_sound (ws:=[(469,4779,460,4770)]) (by simpa only [checkList, Bool.and_true] using cases2953)
private theorem w2954_0 : checkWitness 2954 false false 683 = true := by decide +kernel
private theorem w2954_1 : checkWitness 2954 false true 4775 = true := by decide +kernel
private theorem w2954_2 : checkWitness 2954 true false 674 = true := by decide +kernel
private theorem w2954_3 : checkWitness 2954 true true 4766 = true := by decide +kernel
private theorem cases2954 : checkFour 2954 (683,4775,674,4766) = true := by
  simp only [checkFour, w2954_0,w2954_1,w2954_2,w2954_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2954 : Coverage 2954 2955 := checkList_sound (ws:=[(683,4775,674,4766)]) (by simpa only [checkList, Bool.and_true] using cases2954)
private theorem w2955_0 : checkWitness 2955 false false 28 = true := by decide +kernel
private theorem w2955_2 : checkWitness 2955 true false 28 = true := by decide +kernel
private theorem cases2955 : checkFour 2955 (28,0,28,0) = true := by
  simp only [checkFour, w2955_0,w2955_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2955 : Coverage 2955 2956 := checkList_sound (ws:=[(28,0,28,0)]) (by simpa only [checkList, Bool.and_true] using cases2955)
private theorem w2956_0 : checkWitness 2956 false false 586 = true := by decide +kernel
private theorem w2956_1 : checkWitness 2956 false true 4682 = true := by decide +kernel
private theorem w2956_2 : checkWitness 2956 true false 586 = true := by decide +kernel
private theorem w2956_3 : checkWitness 2956 true true 4682 = true := by decide +kernel
private theorem cases2956 : checkFour 2956 (586,4682,586,4682) = true := by
  simp only [checkFour, w2956_0,w2956_1,w2956_2,w2956_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2956 : Coverage 2956 2957 := checkList_sound (ws:=[(586,4682,586,4682)]) (by simpa only [checkList, Bool.and_true] using cases2956)
private theorem w2957_0 : checkWitness 2957 false false 8981 = true := by decide +kernel
private theorem w2957_2 : checkWitness 2957 true false 8977 = true := by decide +kernel
private theorem cases2957 : checkFour 2957 (8981,0,8977,0) = true := by
  simp only [checkFour, w2957_0,w2957_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2957 : Coverage 2957 2958 := checkList_sound (ws:=[(8981,0,8977,0)]) (by simpa only [checkList, Bool.and_true] using cases2957)
private theorem w2958_0 : checkWitness 2958 false false 712 = true := by decide +kernel
private theorem w2958_1 : checkWitness 2958 false true 4808 = true := by decide +kernel
private theorem w2958_2 : checkWitness 2958 true false 703 = true := by decide +kernel
private theorem w2958_3 : checkWitness 2958 true true 4799 = true := by decide +kernel
private theorem cases2958 : checkFour 2958 (712,4808,703,4799) = true := by
  simp only [checkFour, w2958_0,w2958_1,w2958_2,w2958_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2958 : Coverage 2958 2959 := checkList_sound (ws:=[(712,4808,703,4799)]) (by simpa only [checkList, Bool.and_true] using cases2958)
private theorem w2959_0 : checkWitness 2959 false false 220 = true := by decide +kernel
private theorem w2959_2 : checkWitness 2959 true false 220 = true := by decide +kernel
private theorem cases2959 : checkFour 2959 (220,0,220,0) = true := by
  simp only [checkFour, w2959_0,w2959_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2959 : Coverage 2959 2960 := checkList_sound (ws:=[(220,0,220,0)]) (by simpa only [checkList, Bool.and_true] using cases2959)
private theorem w2960_0 : checkWitness 2960 false false 667 = true := by decide +kernel
private theorem w2960_1 : checkWitness 2960 false true 4755 = true := by decide +kernel
private theorem w2960_2 : checkWitness 2960 true false 667 = true := by decide +kernel
private theorem w2960_3 : checkWitness 2960 true true 4755 = true := by decide +kernel
private theorem cases2960 : checkFour 2960 (667,4755,667,4755) = true := by
  simp only [checkFour, w2960_0,w2960_1,w2960_2,w2960_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2960 : Coverage 2960 2961 := checkList_sound (ws:=[(667,4755,667,4755)]) (by simpa only [checkList, Bool.and_true] using cases2960)
private theorem w2961_0 : checkWitness 2961 false false 8996 = true := by decide +kernel
private theorem w2961_2 : checkWitness 2961 true false 8987 = true := by decide +kernel
private theorem cases2961 : checkFour 2961 (8996,0,8987,0) = true := by
  simp only [checkFour, w2961_0,w2961_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2961 : Coverage 2961 2962 := checkList_sound (ws:=[(8996,0,8987,0)]) (by simpa only [checkList, Bool.and_true] using cases2961)
private theorem w2962_0 : checkWitness 2962 false false 48 = true := by decide +kernel
private theorem w2962_2 : checkWitness 2962 true false 48 = true := by decide +kernel
private theorem cases2962 : checkFour 2962 (48,0,48,0) = true := by
  simp only [checkFour, w2962_0,w2962_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2962 : Coverage 2962 2963 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2962)
private theorem w2963_0 : checkWitness 2963 false false 40 = true := by decide +kernel
private theorem w2963_2 : checkWitness 2963 true false 40 = true := by decide +kernel
private theorem cases2963 : checkFour 2963 (40,0,40,0) = true := by
  simp only [checkFour, w2963_0,w2963_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2963 : Coverage 2963 2964 := checkList_sound (ws:=[(40,0,40,0)]) (by simpa only [checkList, Bool.and_true] using cases2963)
private theorem w2964_0 : checkWitness 2964 false false 673 = true := by decide +kernel
private theorem w2964_1 : checkWitness 2964 false true 4765 = true := by decide +kernel
private theorem w2964_2 : checkWitness 2964 true false 673 = true := by decide +kernel
private theorem w2964_3 : checkWitness 2964 true true 4765 = true := by decide +kernel
private theorem cases2964 : checkFour 2964 (673,4765,673,4765) = true := by
  simp only [checkFour, w2964_0,w2964_1,w2964_2,w2964_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2964 : Coverage 2964 2965 := checkList_sound (ws:=[(673,4765,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases2964)
private theorem w2965_0 : checkWitness 2965 false false 8934 = true := by decide +kernel
private theorem w2965_2 : checkWitness 2965 true false 8930 = true := by decide +kernel
private theorem cases2965 : checkFour 2965 (8934,0,8930,0) = true := by
  simp only [checkFour, w2965_0,w2965_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2965 : Coverage 2965 2966 := checkList_sound (ws:=[(8934,0,8930,0)]) (by simpa only [checkList, Bool.and_true] using cases2965)
private theorem w2966_0 : checkWitness 2966 false false 40 = true := by decide +kernel
private theorem w2966_2 : checkWitness 2966 true false 40 = true := by decide +kernel
private theorem cases2966 : checkFour 2966 (40,0,40,0) = true := by
  simp only [checkFour, w2966_0,w2966_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2966 : Coverage 2966 2967 := checkList_sound (ws:=[(40,0,40,0)]) (by simpa only [checkList, Bool.and_true] using cases2966)
private theorem w2967_0 : checkWitness 2967 false false 4839 = true := by decide +kernel
private theorem w2967_1 : checkWitness 2967 false true 4810 = true := by decide +kernel
private theorem w2967_2 : checkWitness 2967 true false 4830 = true := by decide +kernel
private theorem w2967_3 : checkWitness 2967 true true 4801 = true := by decide +kernel
private theorem cases2967 : checkFour 2967 (4839,4810,4830,4801) = true := by
  simp only [checkFour, w2967_0,w2967_1,w2967_2,w2967_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2967 : Coverage 2967 2968 := checkList_sound (ws:=[(4839,4810,4830,4801)]) (by simpa only [checkList, Bool.and_true] using cases2967)
private theorem w2968_0 : checkWitness 2968 false false 8995 = true := by decide +kernel
private theorem w2968_2 : checkWitness 2968 true false 8986 = true := by decide +kernel
private theorem cases2968 : checkFour 2968 (8995,0,8986,0) = true := by
  simp only [checkFour, w2968_0,w2968_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2968 : Coverage 2968 2969 := checkList_sound (ws:=[(8995,0,8986,0)]) (by simpa only [checkList, Bool.and_true] using cases2968)
private theorem w2969_0 : checkWitness 2969 false false 32 = true := by decide +kernel
private theorem w2969_2 : checkWitness 2969 true false 32 = true := by decide +kernel
private theorem cases2969 : checkFour 2969 (32,0,32,0) = true := by
  simp only [checkFour, w2969_0,w2969_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2969 : Coverage 2969 2970 := checkList_sound (ws:=[(32,0,32,0)]) (by simpa only [checkList, Bool.and_true] using cases2969)
theorem cover2944 : Coverage 2944 2970 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2944 (Coverage.join one2945 one2946)) (Coverage.join one2947 (Coverage.join one2948 one2949))) (Coverage.join (Coverage.join one2950 (Coverage.join one2951 one2952)) (Coverage.join (Coverage.join one2953 one2954) (Coverage.join one2955 one2956)))) (Coverage.join (Coverage.join (Coverage.join one2957 (Coverage.join one2958 one2959)) (Coverage.join one2960 (Coverage.join one2961 one2962))) (Coverage.join (Coverage.join one2963 (Coverage.join one2964 one2965)) (Coverage.join (Coverage.join one2966 one2967) (Coverage.join one2968 one2969)))))
end NF180PA.Symbolic
