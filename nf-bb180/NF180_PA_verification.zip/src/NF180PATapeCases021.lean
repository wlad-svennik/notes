import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w672_0 : checkWitness 672 false false 650 = true := by decide +kernel
private theorem w672_1 : checkWitness 672 false true 4742 = true := by decide +kernel
private theorem w672_2 : checkWitness 672 true false 641 = true := by decide +kernel
private theorem w672_3 : checkWitness 672 true true 4733 = true := by decide +kernel
private theorem cases672 : checkFour 672 (650,4742,641,4733) = true := by
  simp only [checkFour, w672_0,w672_1,w672_2,w672_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one672 : Coverage 672 673 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases672)
private theorem w673_0 : checkWitness 673 false false 8874 = true := by decide +kernel
private theorem w673_2 : checkWitness 673 true false 8870 = true := by decide +kernel
private theorem cases673 : checkFour 673 (8874,0,8870,0) = true := by
  simp only [checkFour, w673_0,w673_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one673 : Coverage 673 674 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases673)
private theorem w674_0 : checkWitness 674 false false 76 = true := by decide +kernel
private theorem w674_2 : checkWitness 674 true false 76 = true := by decide +kernel
private theorem cases674 : checkFour 674 (76,0,76,0) = true := by
  simp only [checkFour, w674_0,w674_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one674 : Coverage 674 675 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases674)
private theorem w675_0 : checkWitness 675 false false 68 = true := by decide +kernel
private theorem w675_2 : checkWitness 675 true false 68 = true := by decide +kernel
private theorem cases675 : checkFour 675 (68,0,68,0) = true := by
  simp only [checkFour, w675_0,w675_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one675 : Coverage 675 676 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases675)
private theorem w676_0 : checkWitness 676 false false 615 = true := by decide +kernel
private theorem w676_1 : checkWitness 676 false true 4699 = true := by decide +kernel
private theorem w676_2 : checkWitness 676 true false 615 = true := by decide +kernel
private theorem w676_3 : checkWitness 676 true true 4699 = true := by decide +kernel
private theorem cases676 : checkFour 676 (615,4699,615,4699) = true := by
  simp only [checkFour, w676_0,w676_1,w676_2,w676_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one676 : Coverage 676 677 := checkList_sound (ws:=[(615,4699,615,4699)]) (by simpa only [checkList, Bool.and_true] using cases676)
private theorem w677_0 : checkWitness 677 false false 8868 = true := by decide +kernel
private theorem w677_2 : checkWitness 677 true false 8864 = true := by decide +kernel
private theorem cases677 : checkFour 677 (8868,0,8864,0) = true := by
  simp only [checkFour, w677_0,w677_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one677 : Coverage 677 678 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases677)
private theorem w678_0 : checkWitness 678 false false 68 = true := by decide +kernel
private theorem w678_2 : checkWitness 678 true false 68 = true := by decide +kernel
private theorem cases678 : checkFour 678 (68,0,68,0) = true := by
  simp only [checkFour, w678_0,w678_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one678 : Coverage 678 679 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases678)
private theorem w679_0 : checkWitness 679 false false 583 = true := by decide +kernel
private theorem w679_1 : checkWitness 679 false true 4679 = true := by decide +kernel
private theorem w679_2 : checkWitness 679 true false 583 = true := by decide +kernel
private theorem w679_3 : checkWitness 679 true true 4679 = true := by decide +kernel
private theorem cases679 : checkFour 679 (583,4679,583,4679) = true := by
  simp only [checkFour, w679_0,w679_1,w679_2,w679_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one679 : Coverage 679 680 := checkList_sound (ws:=[(583,4679,583,4679)]) (by simpa only [checkList, Bool.and_true] using cases679)
private theorem w680_0 : checkWitness 680 false false 8936 = true := by decide +kernel
private theorem w680_2 : checkWitness 680 true false 8927 = true := by decide +kernel
private theorem cases680 : checkFour 680 (8936,0,8927,0) = true := by
  simp only [checkFour, w680_0,w680_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one680 : Coverage 680 681 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases680)
private theorem w681_0 : checkWitness 681 false false 8882 = true := by decide +kernel
private theorem w681_2 : checkWitness 681 true false 8878 = true := by decide +kernel
private theorem cases681 : checkFour 681 (8882,0,8878,0) = true := by
  simp only [checkFour, w681_0,w681_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one681 : Coverage 681 682 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases681)
private theorem w682_0 : checkWitness 682 false false 76 = true := by decide +kernel
private theorem w682_2 : checkWitness 682 true false 76 = true := by decide +kernel
private theorem cases682 : checkFour 682 (76,0,76,0) = true := by
  simp only [checkFour, w682_0,w682_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one682 : Coverage 682 683 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases682)
private theorem w683_0 : checkWitness 683 false false 666 = true := by decide +kernel
private theorem w683_1 : checkWitness 683 false true 4754 = true := by decide +kernel
private theorem w683_2 : checkWitness 683 true false 657 = true := by decide +kernel
private theorem w683_3 : checkWitness 683 true true 4745 = true := by decide +kernel
private theorem cases683 : checkFour 683 (666,4754,657,4745) = true := by
  simp only [checkFour, w683_0,w683_1,w683_2,w683_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one683 : Coverage 683 684 := checkList_sound (ws:=[(666,4754,657,4745)]) (by simpa only [checkList, Bool.and_true] using cases683)
private theorem w684_0 : checkWitness 684 false false 8901 = true := by decide +kernel
private theorem w684_2 : checkWitness 684 true false 8897 = true := by decide +kernel
private theorem cases684 : checkFour 684 (8901,0,8897,0) = true := by
  simp only [checkFour, w684_0,w684_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one684 : Coverage 684 685 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases684)
private theorem w685_0 : checkWitness 685 false false 66 = true := by decide +kernel
private theorem w685_2 : checkWitness 685 true false 66 = true := by decide +kernel
private theorem cases685 : checkFour 685 (66,0,66,0) = true := by
  simp only [checkFour, w685_0,w685_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one685 : Coverage 685 686 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases685)
private theorem w686_0 : checkWitness 686 false false 594 = true := by decide +kernel
private theorem w686_1 : checkWitness 686 false true 4690 = true := by decide +kernel
private theorem w686_2 : checkWitness 686 true false 594 = true := by decide +kernel
private theorem w686_3 : checkWitness 686 true true 4690 = true := by decide +kernel
private theorem cases686 : checkFour 686 (594,4690,594,4690) = true := by
  simp only [checkFour, w686_0,w686_1,w686_2,w686_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one686 : Coverage 686 687 := checkList_sound (ws:=[(594,4690,594,4690)]) (by simpa only [checkList, Bool.and_true] using cases686)
private theorem w687_0 : checkWitness 687 false false 8956 = true := by decide +kernel
private theorem w687_2 : checkWitness 687 true false 8947 = true := by decide +kernel
private theorem cases687 : checkFour 687 (8956,0,8947,0) = true := by
  simp only [checkFour, w687_0,w687_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one687 : Coverage 687 688 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases687)
private theorem w688_0 : checkWitness 688 false false 68 = true := by decide +kernel
private theorem w688_2 : checkWitness 688 true false 68 = true := by decide +kernel
private theorem cases688 : checkFour 688 (68,0,68,0) = true := by
  simp only [checkFour, w688_0,w688_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one688 : Coverage 688 689 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases688)
private theorem w689_0 : checkWitness 689 false false 538 = true := by decide +kernel
private theorem w689_1 : checkWitness 689 false true 4634 = true := by decide +kernel
private theorem w689_2 : checkWitness 689 true false 538 = true := by decide +kernel
private theorem w689_3 : checkWitness 689 true true 4634 = true := by decide +kernel
private theorem cases689 : checkFour 689 (538,4634,538,4634) = true := by
  simp only [checkFour, w689_0,w689_1,w689_2,w689_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one689 : Coverage 689 690 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases689)
private theorem w690_0 : checkWitness 690 false false 8896 = true := by decide +kernel
private theorem w690_2 : checkWitness 690 true false 8892 = true := by decide +kernel
private theorem cases690 : checkFour 690 (8896,0,8892,0) = true := by
  simp only [checkFour, w690_0,w690_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one690 : Coverage 690 691 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases690)
private theorem w691_0 : checkWitness 691 false false 70 = true := by decide +kernel
private theorem w691_2 : checkWitness 691 true false 70 = true := by decide +kernel
private theorem cases691 : checkFour 691 (70,0,70,0) = true := by
  simp only [checkFour, w691_0,w691_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one691 : Coverage 691 692 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases691)
private theorem w692_0 : checkWitness 692 false false 576 = true := by decide +kernel
private theorem w692_1 : checkWitness 692 false true 4672 = true := by decide +kernel
private theorem w692_2 : checkWitness 692 true false 576 = true := by decide +kernel
private theorem w692_3 : checkWitness 692 true true 4672 = true := by decide +kernel
private theorem cases692 : checkFour 692 (576,4672,576,4672) = true := by
  simp only [checkFour, w692_0,w692_1,w692_2,w692_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one692 : Coverage 692 693 := checkList_sound (ws:=[(576,4672,576,4672)]) (by simpa only [checkList, Bool.and_true] using cases692)
private theorem w693_0 : checkWitness 693 false false 8917 = true := by decide +kernel
private theorem w693_2 : checkWitness 693 true false 8913 = true := by decide +kernel
private theorem cases693 : checkFour 693 (8917,0,8913,0) = true := by
  simp only [checkFour, w693_0,w693_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one693 : Coverage 693 694 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases693)
private theorem w694_0 : checkWitness 694 false false 8952 = true := by decide +kernel
private theorem w694_2 : checkWitness 694 true false 8943 = true := by decide +kernel
private theorem cases694 : checkFour 694 (8952,0,8943,0) = true := by
  simp only [checkFour, w694_0,w694_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one694 : Coverage 694 695 := checkList_sound (ws:=[(8952,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases694)
private theorem w695_0 : checkWitness 695 false false 94 = true := by decide +kernel
private theorem w695_2 : checkWitness 695 true false 94 = true := by decide +kernel
private theorem cases695 : checkFour 695 (94,0,94,0) = true := by
  simp only [checkFour, w695_0,w695_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one695 : Coverage 695 696 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases695)
private theorem w696_0 : checkWitness 696 false false 664 = true := by decide +kernel
private theorem w696_1 : checkWitness 696 false true 4756 = true := by decide +kernel
private theorem w696_2 : checkWitness 696 true false 655 = true := by decide +kernel
private theorem w696_3 : checkWitness 696 true true 4747 = true := by decide +kernel
private theorem cases696 : checkFour 696 (664,4756,655,4747) = true := by
  simp only [checkFour, w696_0,w696_1,w696_2,w696_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one696 : Coverage 696 697 := checkList_sound (ws:=[(664,4756,655,4747)]) (by simpa only [checkList, Bool.and_true] using cases696)
private theorem w697_0 : checkWitness 697 false false 8913 = true := by decide +kernel
private theorem w697_2 : checkWitness 697 true false 8909 = true := by decide +kernel
private theorem cases697 : checkFour 697 (8913,0,8909,0) = true := by
  simp only [checkFour, w697_0,w697_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one697 : Coverage 697 698 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases697)
private theorem w698_0 : checkWitness 698 false false 658 = true := by decide +kernel
private theorem w698_1 : checkWitness 698 false true 4750 = true := by decide +kernel
private theorem w698_2 : checkWitness 698 true false 649 = true := by decide +kernel
private theorem w698_3 : checkWitness 698 true true 4741 = true := by decide +kernel
private theorem cases698 : checkFour 698 (658,4750,649,4741) = true := by
  simp only [checkFour, w698_0,w698_1,w698_2,w698_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one698 : Coverage 698 699 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases698)
private theorem w699_0 : checkWitness 699 false false 8882 = true := by decide +kernel
private theorem w699_2 : checkWitness 699 true false 8878 = true := by decide +kernel
private theorem cases699 : checkFour 699 (8882,0,8878,0) = true := by
  simp only [checkFour, w699_0,w699_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one699 : Coverage 699 700 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases699)
private theorem w700_0 : checkWitness 700 false false 82 = true := by decide +kernel
private theorem w700_2 : checkWitness 700 true false 82 = true := by decide +kernel
private theorem cases700 : checkFour 700 (82,0,82,0) = true := by
  simp only [checkFour, w700_0,w700_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one700 : Coverage 700 701 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases700)
private theorem w701_0 : checkWitness 701 false false 74 = true := by decide +kernel
private theorem w701_2 : checkWitness 701 true false 74 = true := by decide +kernel
private theorem cases701 : checkFour 701 (74,0,74,0) = true := by
  simp only [checkFour, w701_0,w701_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one701 : Coverage 701 702 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases701)
private theorem w702_0 : checkWitness 702 false false 623 = true := by decide +kernel
private theorem w702_1 : checkWitness 702 false true 4707 = true := by decide +kernel
private theorem w702_2 : checkWitness 702 true false 623 = true := by decide +kernel
private theorem w702_3 : checkWitness 702 true true 4707 = true := by decide +kernel
private theorem cases702 : checkFour 702 (623,4707,623,4707) = true := by
  simp only [checkFour, w702_0,w702_1,w702_2,w702_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one702 : Coverage 702 703 := checkList_sound (ws:=[(623,4707,623,4707)]) (by simpa only [checkList, Bool.and_true] using cases702)
private theorem w703_0 : checkWitness 703 false false 8876 = true := by decide +kernel
private theorem w703_2 : checkWitness 703 true false 8872 = true := by decide +kernel
private theorem cases703 : checkFour 703 (8876,0,8872,0) = true := by
  simp only [checkFour, w703_0,w703_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one703 : Coverage 703 704 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases703)
theorem cover0672 : Coverage 672 704 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one672 one673) (Coverage.join one674 one675)) (Coverage.join (Coverage.join one676 one677) (Coverage.join one678 one679))) (Coverage.join (Coverage.join (Coverage.join one680 one681) (Coverage.join one682 one683)) (Coverage.join (Coverage.join one684 one685) (Coverage.join one686 one687)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one688 one689) (Coverage.join one690 one691)) (Coverage.join (Coverage.join one692 one693) (Coverage.join one694 one695))) (Coverage.join (Coverage.join (Coverage.join one696 one697) (Coverage.join one698 one699)) (Coverage.join (Coverage.join one700 one701) (Coverage.join one702 one703)))))
end NF180PA.Symbolic
