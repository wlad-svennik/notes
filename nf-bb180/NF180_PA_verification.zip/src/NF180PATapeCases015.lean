import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w480_0 : checkWitness 480 false false 62 = true := by decide +kernel
private theorem w480_2 : checkWitness 480 true false 62 = true := by decide +kernel
private theorem cases480 : checkFour 480 (62,0,62,0) = true := by
  simp only [checkFour, w480_0,w480_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one480 : Coverage 480 481 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases480)
private theorem w481_0 : checkWitness 481 false false 530 = true := by decide +kernel
private theorem w481_1 : checkWitness 481 false true 4626 = true := by decide +kernel
private theorem w481_2 : checkWitness 481 true false 530 = true := by decide +kernel
private theorem w481_3 : checkWitness 481 true true 4626 = true := by decide +kernel
private theorem cases481 : checkFour 481 (530,4626,530,4626) = true := by
  simp only [checkFour, w481_0,w481_1,w481_2,w481_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one481 : Coverage 481 482 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases481)
private theorem w482_0 : checkWitness 482 false false 8888 = true := by decide +kernel
private theorem w482_2 : checkWitness 482 true false 8884 = true := by decide +kernel
private theorem cases482 : checkFour 482 (8888,0,8884,0) = true := by
  simp only [checkFour, w482_0,w482_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one482 : Coverage 482 483 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases482)
private theorem w483_0 : checkWitness 483 false false 64 = true := by decide +kernel
private theorem w483_2 : checkWitness 483 true false 64 = true := by decide +kernel
private theorem cases483 : checkFour 483 (64,0,64,0) = true := by
  simp only [checkFour, w483_0,w483_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one483 : Coverage 483 484 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases483)
private theorem w484_0 : checkWitness 484 false false 568 = true := by decide +kernel
private theorem w484_1 : checkWitness 484 false true 4664 = true := by decide +kernel
private theorem w484_2 : checkWitness 484 true false 568 = true := by decide +kernel
private theorem w484_3 : checkWitness 484 true true 4664 = true := by decide +kernel
private theorem cases484 : checkFour 484 (568,4664,568,4664) = true := by
  simp only [checkFour, w484_0,w484_1,w484_2,w484_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one484 : Coverage 484 485 := checkList_sound (ws:=[(568,4664,568,4664)]) (by simpa only [checkList, Bool.and_true] using cases484)
private theorem w485_0 : checkWitness 485 false false 8909 = true := by decide +kernel
private theorem w485_2 : checkWitness 485 true false 8905 = true := by decide +kernel
private theorem cases485 : checkFour 485 (8909,0,8905,0) = true := by
  simp only [checkFour, w485_0,w485_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one485 : Coverage 485 486 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases485)
private theorem w486_0 : checkWitness 486 false false 8944 = true := by decide +kernel
private theorem w486_2 : checkWitness 486 true false 8935 = true := by decide +kernel
private theorem cases486 : checkFour 486 (8944,0,8935,0) = true := by
  simp only [checkFour, w486_0,w486_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one486 : Coverage 486 487 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases486)
private theorem w487_0 : checkWitness 487 false false 88 = true := by decide +kernel
private theorem w487_2 : checkWitness 487 true false 88 = true := by decide +kernel
private theorem cases487 : checkFour 487 (88,0,88,0) = true := by
  simp only [checkFour, w487_0,w487_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one487 : Coverage 487 488 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases487)
private theorem w488_0 : checkWitness 488 false false 656 = true := by decide +kernel
private theorem w488_1 : checkWitness 488 false true 4748 = true := by decide +kernel
private theorem w488_2 : checkWitness 488 true false 647 = true := by decide +kernel
private theorem w488_3 : checkWitness 488 true true 4739 = true := by decide +kernel
private theorem cases488 : checkFour 488 (656,4748,647,4739) = true := by
  simp only [checkFour, w488_0,w488_1,w488_2,w488_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one488 : Coverage 488 489 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases488)
private theorem w489_0 : checkWitness 489 false false 8905 = true := by decide +kernel
private theorem w489_2 : checkWitness 489 true false 8901 = true := by decide +kernel
private theorem cases489 : checkFour 489 (8905,0,8901,0) = true := by
  simp only [checkFour, w489_0,w489_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one489 : Coverage 489 490 := checkList_sound (ws:=[(8905,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases489)
private theorem w490_0 : checkWitness 490 false false 650 = true := by decide +kernel
private theorem w490_1 : checkWitness 490 false true 4742 = true := by decide +kernel
private theorem w490_2 : checkWitness 490 true false 641 = true := by decide +kernel
private theorem w490_3 : checkWitness 490 true true 4733 = true := by decide +kernel
private theorem cases490 : checkFour 490 (650,4742,641,4733) = true := by
  simp only [checkFour, w490_0,w490_1,w490_2,w490_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one490 : Coverage 490 491 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases490)
private theorem w491_0 : checkWitness 491 false false 8874 = true := by decide +kernel
private theorem w491_2 : checkWitness 491 true false 8870 = true := by decide +kernel
private theorem cases491 : checkFour 491 (8874,0,8870,0) = true := by
  simp only [checkFour, w491_0,w491_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one491 : Coverage 491 492 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases491)
private theorem w492_0 : checkWitness 492 false false 76 = true := by decide +kernel
private theorem w492_2 : checkWitness 492 true false 76 = true := by decide +kernel
private theorem cases492 : checkFour 492 (76,0,76,0) = true := by
  simp only [checkFour, w492_0,w492_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one492 : Coverage 492 493 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases492)
private theorem w493_0 : checkWitness 493 false false 68 = true := by decide +kernel
private theorem w493_2 : checkWitness 493 true false 68 = true := by decide +kernel
private theorem cases493 : checkFour 493 (68,0,68,0) = true := by
  simp only [checkFour, w493_0,w493_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one493 : Coverage 493 494 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases493)
private theorem w494_0 : checkWitness 494 false false 615 = true := by decide +kernel
private theorem w494_1 : checkWitness 494 false true 4699 = true := by decide +kernel
private theorem w494_2 : checkWitness 494 true false 615 = true := by decide +kernel
private theorem w494_3 : checkWitness 494 true true 4699 = true := by decide +kernel
private theorem cases494 : checkFour 494 (615,4699,615,4699) = true := by
  simp only [checkFour, w494_0,w494_1,w494_2,w494_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one494 : Coverage 494 495 := checkList_sound (ws:=[(615,4699,615,4699)]) (by simpa only [checkList, Bool.and_true] using cases494)
private theorem w495_0 : checkWitness 495 false false 8868 = true := by decide +kernel
private theorem w495_2 : checkWitness 495 true false 8864 = true := by decide +kernel
private theorem cases495 : checkFour 495 (8868,0,8864,0) = true := by
  simp only [checkFour, w495_0,w495_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one495 : Coverage 495 496 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases495)
private theorem w496_0 : checkWitness 496 false false 68 = true := by decide +kernel
private theorem w496_2 : checkWitness 496 true false 68 = true := by decide +kernel
private theorem cases496 : checkFour 496 (68,0,68,0) = true := by
  simp only [checkFour, w496_0,w496_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one496 : Coverage 496 497 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases496)
private theorem w497_0 : checkWitness 497 false false 583 = true := by decide +kernel
private theorem w497_1 : checkWitness 497 false true 4679 = true := by decide +kernel
private theorem w497_2 : checkWitness 497 true false 583 = true := by decide +kernel
private theorem w497_3 : checkWitness 497 true true 4679 = true := by decide +kernel
private theorem cases497 : checkFour 497 (583,4679,583,4679) = true := by
  simp only [checkFour, w497_0,w497_1,w497_2,w497_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one497 : Coverage 497 498 := checkList_sound (ws:=[(583,4679,583,4679)]) (by simpa only [checkList, Bool.and_true] using cases497)
private theorem w498_0 : checkWitness 498 false false 8936 = true := by decide +kernel
private theorem w498_2 : checkWitness 498 true false 8927 = true := by decide +kernel
private theorem cases498 : checkFour 498 (8936,0,8927,0) = true := by
  simp only [checkFour, w498_0,w498_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one498 : Coverage 498 499 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases498)
private theorem w499_0 : checkWitness 499 false false 8882 = true := by decide +kernel
private theorem w499_2 : checkWitness 499 true false 8878 = true := by decide +kernel
private theorem cases499 : checkFour 499 (8882,0,8878,0) = true := by
  simp only [checkFour, w499_0,w499_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one499 : Coverage 499 500 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases499)
private theorem w500_0 : checkWitness 500 false false 76 = true := by decide +kernel
private theorem w500_2 : checkWitness 500 true false 76 = true := by decide +kernel
private theorem cases500 : checkFour 500 (76,0,76,0) = true := by
  simp only [checkFour, w500_0,w500_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one500 : Coverage 500 501 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases500)
private theorem w501_0 : checkWitness 501 false false 666 = true := by decide +kernel
private theorem w501_1 : checkWitness 501 false true 4754 = true := by decide +kernel
private theorem w501_2 : checkWitness 501 true false 657 = true := by decide +kernel
private theorem w501_3 : checkWitness 501 true true 4745 = true := by decide +kernel
private theorem cases501 : checkFour 501 (666,4754,657,4745) = true := by
  simp only [checkFour, w501_0,w501_1,w501_2,w501_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one501 : Coverage 501 502 := checkList_sound (ws:=[(666,4754,657,4745)]) (by simpa only [checkList, Bool.and_true] using cases501)
private theorem w502_0 : checkWitness 502 false false 8901 = true := by decide +kernel
private theorem w502_2 : checkWitness 502 true false 8897 = true := by decide +kernel
private theorem cases502 : checkFour 502 (8901,0,8897,0) = true := by
  simp only [checkFour, w502_0,w502_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one502 : Coverage 502 503 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases502)
private theorem w503_0 : checkWitness 503 false false 66 = true := by decide +kernel
private theorem w503_2 : checkWitness 503 true false 66 = true := by decide +kernel
private theorem cases503 : checkFour 503 (66,0,66,0) = true := by
  simp only [checkFour, w503_0,w503_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one503 : Coverage 503 504 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases503)
private theorem w504_0 : checkWitness 504 false false 518 = true := by decide +kernel
private theorem w504_1 : checkWitness 504 false true 4614 = true := by decide +kernel
private theorem w504_2 : checkWitness 504 true false 518 = true := by decide +kernel
private theorem w504_3 : checkWitness 504 true true 4614 = true := by decide +kernel
private theorem cases504 : checkFour 504 (518,4614,518,4614) = true := by
  simp only [checkFour, w504_0,w504_1,w504_2,w504_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one504 : Coverage 504 505 := checkList_sound (ws:=[(518,4614,518,4614)]) (by simpa only [checkList, Bool.and_true] using cases504)
private theorem w505_0 : checkWitness 505 false false 8913 = true := by decide +kernel
private theorem w505_2 : checkWitness 505 true false 8909 = true := by decide +kernel
private theorem cases505 : checkFour 505 (8913,0,8909,0) = true := by
  simp only [checkFour, w505_0,w505_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one505 : Coverage 505 506 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases505)
private theorem w506_0 : checkWitness 506 false false 644 = true := by decide +kernel
private theorem w506_1 : checkWitness 506 false true 4740 = true := by decide +kernel
private theorem w506_2 : checkWitness 506 true false 635 = true := by decide +kernel
private theorem w506_3 : checkWitness 506 true true 4731 = true := by decide +kernel
private theorem cases506 : checkFour 506 (644,4740,635,4731) = true := by
  simp only [checkFour, w506_0,w506_1,w506_2,w506_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one506 : Coverage 506 507 := checkList_sound (ws:=[(644,4740,635,4731)]) (by simpa only [checkList, Bool.and_true] using cases506)
private theorem w507_0 : checkWitness 507 false false 188 = true := by decide +kernel
private theorem w507_2 : checkWitness 507 true false 188 = true := by decide +kernel
private theorem cases507 : checkFour 507 (188,0,188,0) = true := by
  simp only [checkFour, w507_0,w507_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one507 : Coverage 507 508 := checkList_sound (ws:=[(188,0,188,0)]) (by simpa only [checkList, Bool.and_true] using cases507)
private theorem w508_0 : checkWitness 508 false false 599 = true := by decide +kernel
private theorem w508_1 : checkWitness 508 false true 4687 = true := by decide +kernel
private theorem w508_2 : checkWitness 508 true false 599 = true := by decide +kernel
private theorem w508_3 : checkWitness 508 true true 4687 = true := by decide +kernel
private theorem cases508 : checkFour 508 (599,4687,599,4687) = true := by
  simp only [checkFour, w508_0,w508_1,w508_2,w508_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one508 : Coverage 508 509 := checkList_sound (ws:=[(599,4687,599,4687)]) (by simpa only [checkList, Bool.and_true] using cases508)
private theorem w509_0 : checkWitness 509 false false 8928 = true := by decide +kernel
private theorem w509_2 : checkWitness 509 true false 8919 = true := by decide +kernel
private theorem cases509 : checkFour 509 (8928,0,8919,0) = true := by
  simp only [checkFour, w509_0,w509_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one509 : Coverage 509 510 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases509)
private theorem w510_0 : checkWitness 510 false false 72 = true := by decide +kernel
private theorem w510_2 : checkWitness 510 true false 72 = true := by decide +kernel
private theorem cases510 : checkFour 510 (72,0,72,0) = true := by
  simp only [checkFour, w510_0,w510_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one510 : Coverage 510 511 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases510)
private theorem w511_0 : checkWitness 511 false false 64 = true := by decide +kernel
private theorem w511_2 : checkWitness 511 true false 64 = true := by decide +kernel
private theorem cases511 : checkFour 511 (64,0,64,0) = true := by
  simp only [checkFour, w511_0,w511_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one511 : Coverage 511 512 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases511)
theorem cover0480 : Coverage 480 512 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one480 one481) (Coverage.join one482 one483)) (Coverage.join (Coverage.join one484 one485) (Coverage.join one486 one487))) (Coverage.join (Coverage.join (Coverage.join one488 one489) (Coverage.join one490 one491)) (Coverage.join (Coverage.join one492 one493) (Coverage.join one494 one495)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one496 one497) (Coverage.join one498 one499)) (Coverage.join (Coverage.join one500 one501) (Coverage.join one502 one503))) (Coverage.join (Coverage.join (Coverage.join one504 one505) (Coverage.join one506 one507)) (Coverage.join (Coverage.join one508 one509) (Coverage.join one510 one511)))))
end NF180PA.Symbolic
