import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2016_0 : checkWitness 2016 false false 567 = true := by decide +kernel
private theorem w2016_1 : checkWitness 2016 false true 4663 = true := by decide +kernel
private theorem w2016_2 : checkWitness 2016 true false 567 = true := by decide +kernel
private theorem w2016_3 : checkWitness 2016 true true 4663 = true := by decide +kernel
private theorem cases2016 : checkFour 2016 (567,4663,567,4663) = true := by
  simp only [checkFour, w2016_0,w2016_1,w2016_2,w2016_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2016 : Coverage 2016 2017 := checkList_sound (ws:=[(567,4663,567,4663)]) (by simpa only [checkList, Bool.and_true] using cases2016)
private theorem w2017_0 : checkWitness 2017 false false 8920 = true := by decide +kernel
private theorem w2017_2 : checkWitness 2017 true false 8911 = true := by decide +kernel
private theorem cases2017 : checkFour 2017 (8920,0,8911,0) = true := by
  simp only [checkFour, w2017_0,w2017_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2017 : Coverage 2017 2018 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2017)
private theorem w2018_0 : checkWitness 2018 false false 8866 = true := by decide +kernel
private theorem w2018_2 : checkWitness 2018 true false 8862 = true := by decide +kernel
private theorem cases2018 : checkFour 2018 (8866,0,8862,0) = true := by
  simp only [checkFour, w2018_0,w2018_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2018 : Coverage 2018 2019 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases2018)
private theorem w2019_0 : checkWitness 2019 false false 84 = true := by decide +kernel
private theorem w2019_2 : checkWitness 2019 true false 84 = true := by decide +kernel
private theorem cases2019 : checkFour 2019 (84,0,84,0) = true := by
  simp only [checkFour, w2019_0,w2019_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2019 : Coverage 2019 2020 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2019)
private theorem w2020_0 : checkWitness 2020 false false 650 = true := by decide +kernel
private theorem w2020_1 : checkWitness 2020 false true 4738 = true := by decide +kernel
private theorem w2020_2 : checkWitness 2020 true false 641 = true := by decide +kernel
private theorem w2020_3 : checkWitness 2020 true true 4729 = true := by decide +kernel
private theorem cases2020 : checkFour 2020 (650,4738,641,4729) = true := by
  simp only [checkFour, w2020_0,w2020_1,w2020_2,w2020_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2020 : Coverage 2020 2021 := checkList_sound (ws:=[(650,4738,641,4729)]) (by simpa only [checkList, Bool.and_true] using cases2020)
private theorem w2021_0 : checkWitness 2021 false false 8885 = true := by decide +kernel
private theorem w2021_2 : checkWitness 2021 true false 8881 = true := by decide +kernel
private theorem cases2021 : checkFour 2021 (8885,0,8881,0) = true := by
  simp only [checkFour, w2021_0,w2021_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2021 : Coverage 2021 2022 := checkList_sound (ws:=[(8885,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases2021)
private theorem w2022_0 : checkWitness 2022 false false 74 = true := by decide +kernel
private theorem w2022_2 : checkWitness 2022 true false 74 = true := by decide +kernel
private theorem cases2022 : checkFour 2022 (74,0,74,0) = true := by
  simp only [checkFour, w2022_0,w2022_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2022 : Coverage 2022 2023 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2022)
private theorem w2023_0 : checkWitness 2023 false false 502 = true := by decide +kernel
private theorem w2023_1 : checkWitness 2023 false true 4598 = true := by decide +kernel
private theorem w2023_2 : checkWitness 2023 true false 502 = true := by decide +kernel
private theorem w2023_3 : checkWitness 2023 true true 4598 = true := by decide +kernel
private theorem cases2023 : checkFour 2023 (502,4598,502,4598) = true := by
  simp only [checkFour, w2023_0,w2023_1,w2023_2,w2023_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2023 : Coverage 2023 2024 := checkList_sound (ws:=[(502,4598,502,4598)]) (by simpa only [checkList, Bool.and_true] using cases2023)
private theorem w2024_0 : checkWitness 2024 false false 8897 = true := by decide +kernel
private theorem w2024_2 : checkWitness 2024 true false 8893 = true := by decide +kernel
private theorem cases2024 : checkFour 2024 (8897,0,8893,0) = true := by
  simp only [checkFour, w2024_0,w2024_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2024 : Coverage 2024 2025 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases2024)
private theorem w2025_0 : checkWitness 2025 false false 628 = true := by decide +kernel
private theorem w2025_1 : checkWitness 2025 false true 4724 = true := by decide +kernel
private theorem w2025_2 : checkWitness 2025 true false 619 = true := by decide +kernel
private theorem w2025_3 : checkWitness 2025 true true 4715 = true := by decide +kernel
private theorem cases2025 : checkFour 2025 (628,4724,619,4715) = true := by
  simp only [checkFour, w2025_0,w2025_1,w2025_2,w2025_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2025 : Coverage 2025 2026 := checkList_sound (ws:=[(628,4724,619,4715)]) (by simpa only [checkList, Bool.and_true] using cases2025)
private theorem w2026_0 : checkWitness 2026 false false 180 = true := by decide +kernel
private theorem w2026_2 : checkWitness 2026 true false 180 = true := by decide +kernel
private theorem cases2026 : checkFour 2026 (180,0,180,0) = true := by
  simp only [checkFour, w2026_0,w2026_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2026 : Coverage 2026 2027 := checkList_sound (ws:=[(180,0,180,0)]) (by simpa only [checkList, Bool.and_true] using cases2026)
private theorem w2027_0 : checkWitness 2027 false false 583 = true := by decide +kernel
private theorem w2027_1 : checkWitness 2027 false true 4671 = true := by decide +kernel
private theorem w2027_2 : checkWitness 2027 true false 583 = true := by decide +kernel
private theorem w2027_3 : checkWitness 2027 true true 4671 = true := by decide +kernel
private theorem cases2027 : checkFour 2027 (583,4671,583,4671) = true := by
  simp only [checkFour, w2027_0,w2027_1,w2027_2,w2027_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2027 : Coverage 2027 2028 := checkList_sound (ws:=[(583,4671,583,4671)]) (by simpa only [checkList, Bool.and_true] using cases2027)
private theorem w2028_0 : checkWitness 2028 false false 8912 = true := by decide +kernel
private theorem w2028_2 : checkWitness 2028 true false 8903 = true := by decide +kernel
private theorem cases2028 : checkFour 2028 (8912,0,8903,0) = true := by
  simp only [checkFour, w2028_0,w2028_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2028 : Coverage 2028 2029 := checkList_sound (ws:=[(8912,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases2028)
private theorem w2029_0 : checkWitness 2029 false false 80 = true := by decide +kernel
private theorem w2029_2 : checkWitness 2029 true false 80 = true := by decide +kernel
private theorem cases2029 : checkFour 2029 (80,0,80,0) = true := by
  simp only [checkFour, w2029_0,w2029_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2029 : Coverage 2029 2030 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2029)
private theorem w2030_0 : checkWitness 2030 false false 72 = true := by decide +kernel
private theorem w2030_2 : checkWitness 2030 true false 72 = true := by decide +kernel
private theorem cases2030 : checkFour 2030 (72,0,72,0) = true := by
  simp only [checkFour, w2030_0,w2030_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2030 : Coverage 2030 2031 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2030)
private theorem w2031_0 : checkWitness 2031 false false 589 = true := by decide +kernel
private theorem w2031_1 : checkWitness 2031 false true 4681 = true := by decide +kernel
private theorem w2031_2 : checkWitness 2031 true false 589 = true := by decide +kernel
private theorem w2031_3 : checkWitness 2031 true true 4681 = true := by decide +kernel
private theorem cases2031 : checkFour 2031 (589,4681,589,4681) = true := by
  simp only [checkFour, w2031_0,w2031_1,w2031_2,w2031_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2031 : Coverage 2031 2032 := checkList_sound (ws:=[(589,4681,589,4681)]) (by simpa only [checkList, Bool.and_true] using cases2031)
private theorem w2032_0 : checkWitness 2032 false false 8850 = true := by decide +kernel
private theorem w2032_2 : checkWitness 2032 true false 8846 = true := by decide +kernel
private theorem cases2032 : checkFour 2032 (8850,0,8846,0) = true := by
  simp only [checkFour, w2032_0,w2032_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2032 : Coverage 2032 2033 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases2032)
private theorem w2033_0 : checkWitness 2033 false false 72 = true := by decide +kernel
private theorem w2033_2 : checkWitness 2033 true false 72 = true := by decide +kernel
private theorem cases2033 : checkFour 2033 (72,0,72,0) = true := by
  simp only [checkFour, w2033_0,w2033_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2033 : Coverage 2033 2034 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2033)
private theorem w2034_0 : checkWitness 2034 false false 544 = true := by decide +kernel
private theorem w2034_1 : checkWitness 2034 false true 4640 = true := by decide +kernel
private theorem w2034_2 : checkWitness 2034 true false 544 = true := by decide +kernel
private theorem w2034_3 : checkWitness 2034 true true 4640 = true := by decide +kernel
private theorem cases2034 : checkFour 2034 (544,4640,544,4640) = true := by
  simp only [checkFour, w2034_0,w2034_1,w2034_2,w2034_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2034 : Coverage 2034 2035 := checkList_sound (ws:=[(544,4640,544,4640)]) (by simpa only [checkList, Bool.and_true] using cases2034)
private theorem w2035_0 : checkWitness 2035 false false 8885 = true := by decide +kernel
private theorem w2035_2 : checkWitness 2035 true false 8881 = true := by decide +kernel
private theorem cases2035 : checkFour 2035 (8885,0,8881,0) = true := by
  simp only [checkFour, w2035_0,w2035_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2035 : Coverage 2035 2036 := checkList_sound (ws:=[(8885,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases2035)
private theorem w2036_0 : checkWitness 2036 false false 8920 = true := by decide +kernel
private theorem w2036_2 : checkWitness 2036 true false 8911 = true := by decide +kernel
private theorem cases2036 : checkFour 2036 (8920,0,8911,0) = true := by
  simp only [checkFour, w2036_0,w2036_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2036 : Coverage 2036 2037 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2036)
private theorem w2037_0 : checkWitness 2037 false false 90 = true := by decide +kernel
private theorem w2037_2 : checkWitness 2037 true false 90 = true := by decide +kernel
private theorem cases2037 : checkFour 2037 (90,0,90,0) = true := by
  simp only [checkFour, w2037_0,w2037_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2037 : Coverage 2037 2038 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases2037)
private theorem w2038_0 : checkWitness 2038 false false 632 = true := by decide +kernel
private theorem w2038_1 : checkWitness 2038 false true 4724 = true := by decide +kernel
private theorem w2038_2 : checkWitness 2038 true false 623 = true := by decide +kernel
private theorem w2038_3 : checkWitness 2038 true true 4715 = true := by decide +kernel
private theorem cases2038 : checkFour 2038 (632,4724,623,4715) = true := by
  simp only [checkFour, w2038_0,w2038_1,w2038_2,w2038_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2038 : Coverage 2038 2039 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases2038)
private theorem w2039_0 : checkWitness 2039 false false 8881 = true := by decide +kernel
private theorem w2039_2 : checkWitness 2039 true false 8877 = true := by decide +kernel
private theorem cases2039 : checkFour 2039 (8881,0,8877,0) = true := by
  simp only [checkFour, w2039_0,w2039_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2039 : Coverage 2039 2040 := checkList_sound (ws:=[(8881,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases2039)
private theorem w2040_0 : checkWitness 2040 false false 626 = true := by decide +kernel
private theorem w2040_1 : checkWitness 2040 false true 4718 = true := by decide +kernel
private theorem w2040_2 : checkWitness 2040 true false 617 = true := by decide +kernel
private theorem w2040_3 : checkWitness 2040 true true 4709 = true := by decide +kernel
private theorem cases2040 : checkFour 2040 (626,4718,617,4709) = true := by
  simp only [checkFour, w2040_0,w2040_1,w2040_2,w2040_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2040 : Coverage 2040 2041 := checkList_sound (ws:=[(626,4718,617,4709)]) (by simpa only [checkList, Bool.and_true] using cases2040)
private theorem w2041_0 : checkWitness 2041 false false 8850 = true := by decide +kernel
private theorem w2041_2 : checkWitness 2041 true false 8846 = true := by decide +kernel
private theorem cases2041 : checkFour 2041 (8850,0,8846,0) = true := by
  simp only [checkFour, w2041_0,w2041_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2041 : Coverage 2041 2042 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases2041)
private theorem w2042_0 : checkWitness 2042 false false 78 = true := by decide +kernel
private theorem w2042_2 : checkWitness 2042 true false 78 = true := by decide +kernel
private theorem cases2042 : checkFour 2042 (78,0,78,0) = true := by
  simp only [checkFour, w2042_0,w2042_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2042 : Coverage 2042 2043 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2042)
private theorem w2043_0 : checkWitness 2043 false false 70 = true := by decide +kernel
private theorem w2043_2 : checkWitness 2043 true false 70 = true := by decide +kernel
private theorem cases2043 : checkFour 2043 (70,0,70,0) = true := by
  simp only [checkFour, w2043_0,w2043_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2043 : Coverage 2043 2044 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2043)
private theorem w2044_0 : checkWitness 2044 false false 593 = true := by decide +kernel
private theorem w2044_1 : checkWitness 2044 false true 4681 = true := by decide +kernel
private theorem w2044_2 : checkWitness 2044 true false 593 = true := by decide +kernel
private theorem w2044_3 : checkWitness 2044 true true 4681 = true := by decide +kernel
private theorem cases2044 : checkFour 2044 (593,4681,593,4681) = true := by
  simp only [checkFour, w2044_0,w2044_1,w2044_2,w2044_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2044 : Coverage 2044 2045 := checkList_sound (ws:=[(593,4681,593,4681)]) (by simpa only [checkList, Bool.and_true] using cases2044)
private theorem w2045_0 : checkWitness 2045 false false 8866 = true := by decide +kernel
private theorem w2045_2 : checkWitness 2045 true false 8862 = true := by decide +kernel
private theorem cases2045 : checkFour 2045 (8866,0,8862,0) = true := by
  simp only [checkFour, w2045_0,w2045_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2045 : Coverage 2045 2046 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases2045)
private theorem w2046_0 : checkWitness 2046 false false 8862 = true := by decide +kernel
private theorem w2046_2 : checkWitness 2046 true false 8858 = true := by decide +kernel
private theorem cases2046 : checkFour 2046 (8862,0,8858,0) = true := by
  simp only [checkFour, w2046_0,w2046_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2046 : Coverage 2046 2047 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases2046)
private theorem w2047_0 : checkWitness 2047 false false 84 = true := by decide +kernel
private theorem w2047_2 : checkWitness 2047 true false 84 = true := by decide +kernel
private theorem cases2047 : checkFour 2047 (84,0,84,0) = true := by
  simp only [checkFour, w2047_0,w2047_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2047 : Coverage 2047 2048 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2047)
theorem cover2016 : Coverage 2016 2048 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2016 one2017) (Coverage.join one2018 one2019)) (Coverage.join (Coverage.join one2020 one2021) (Coverage.join one2022 one2023))) (Coverage.join (Coverage.join (Coverage.join one2024 one2025) (Coverage.join one2026 one2027)) (Coverage.join (Coverage.join one2028 one2029) (Coverage.join one2030 one2031)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2032 one2033) (Coverage.join one2034 one2035)) (Coverage.join (Coverage.join one2036 one2037) (Coverage.join one2038 one2039))) (Coverage.join (Coverage.join (Coverage.join one2040 one2041) (Coverage.join one2042 one2043)) (Coverage.join (Coverage.join one2044 one2045) (Coverage.join one2046 one2047)))))
end NF180PA.Symbolic
