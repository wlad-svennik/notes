import NF180PATapeFinite

namespace NF180PA.Links
open Blank180.Data
set_option maxRecDepth 200000
set_option maxHeartbeats 0

def tag (p : Nat) (c : Bool) : Bool := !c

def atTarget (p : Nat) (c : Bool) : Bool := decide (p<2970) && tag p c

def allowed (p : Nat) (op : Command) (c : Bool) : Bool :=
  !tag p c || match op with
    | .inl (r,n) => atTarget n (c && !(r==0))
    | .inr (.inr n) => atTarget n c
    | .inr (.inl (r,z,n,h)) => !(c && (r==0)) && (h || atTarget z c) && atTarget n c

theorem release_links : ∀ (p : Fin 2970) (c : Bool), allowed p.val (Blank180.Data.program p.val) c = true := by
  decide +kernel
#print axioms release_links
end NF180PA.Links
