import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1056_0 : checkWitness 1056 false false 86 = true := by decide +kernel
private theorem w1056_2 : checkWitness 1056 true false 86 = true := by decide +kernel
private theorem cases1056 : checkFour 1056 (86,0,86,0) = true := by
  simp only [checkFour, w1056_0,w1056_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1056 : Coverage 1056 1057 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1056)
private theorem w1057_0 : checkWitness 1057 false false 78 = true := by decide +kernel
private theorem w1057_2 : checkWitness 1057 true false 78 = true := by decide +kernel
private theorem cases1057 : checkFour 1057 (78,0,78,0) = true := by
  simp only [checkFour, w1057_0,w1057_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1057 : Coverage 1057 1058 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1057)
private theorem w1058_0 : checkWitness 1058 false false 605 = true := by decide +kernel
private theorem w1058_1 : checkWitness 1058 false true 4689 = true := by decide +kernel
private theorem w1058_2 : checkWitness 1058 true false 605 = true := by decide +kernel
private theorem w1058_3 : checkWitness 1058 true true 4689 = true := by decide +kernel
private theorem cases1058 : checkFour 1058 (605,4689,605,4689) = true := by
  simp only [checkFour, w1058_0,w1058_1,w1058_2,w1058_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1058 : Coverage 1058 1059 := checkList_sound (ws:=[(605,4689,605,4689)]) (by simpa only [checkList, Bool.and_true] using cases1058)
private theorem w1059_0 : checkWitness 1059 false false 8858 = true := by decide +kernel
private theorem w1059_2 : checkWitness 1059 true false 8854 = true := by decide +kernel
private theorem cases1059 : checkFour 1059 (8858,0,8854,0) = true := by
  simp only [checkFour, w1059_0,w1059_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1059 : Coverage 1059 1060 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1059)
private theorem w1060_0 : checkWitness 1060 false false 78 = true := by decide +kernel
private theorem w1060_2 : checkWitness 1060 true false 78 = true := by decide +kernel
private theorem cases1060 : checkFour 1060 (78,0,78,0) = true := by
  simp only [checkFour, w1060_0,w1060_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1060 : Coverage 1060 1061 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1060)
private theorem w1061_0 : checkWitness 1061 false false 610 = true := by decide +kernel
private theorem w1061_1 : checkWitness 1061 false true 4706 = true := by decide +kernel
private theorem w1061_2 : checkWitness 1061 true false 610 = true := by decide +kernel
private theorem w1061_3 : checkWitness 1061 true true 4706 = true := by decide +kernel
private theorem cases1061 : checkFour 1061 (610,4706,610,4706) = true := by
  simp only [checkFour, w1061_0,w1061_1,w1061_2,w1061_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1061 : Coverage 1061 1062 := checkList_sound (ws:=[(610,4706,610,4706)]) (by simpa only [checkList, Bool.and_true] using cases1061)
private theorem w1062_0 : checkWitness 1062 false false 8926 = true := by decide +kernel
private theorem w1062_2 : checkWitness 1062 true false 8917 = true := by decide +kernel
private theorem cases1062 : checkFour 1062 (8926,0,8917,0) = true := by
  simp only [checkFour, w1062_0,w1062_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1062 : Coverage 1062 1063 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases1062)
private theorem w1063_0 : checkWitness 1063 false false 8872 = true := by decide +kernel
private theorem w1063_2 : checkWitness 1063 true false 8868 = true := by decide +kernel
private theorem cases1063 : checkFour 1063 (8872,0,8868,0) = true := by
  simp only [checkFour, w1063_0,w1063_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1063 : Coverage 1063 1064 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases1063)
private theorem w1064_0 : checkWitness 1064 false false 86 = true := by decide +kernel
private theorem w1064_2 : checkWitness 1064 true false 86 = true := by decide +kernel
private theorem cases1064 : checkFour 1064 (86,0,86,0) = true := by
  simp only [checkFour, w1064_0,w1064_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1064 : Coverage 1064 1065 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1064)
private theorem w1065_0 : checkWitness 1065 false false 656 = true := by decide +kernel
private theorem w1065_1 : checkWitness 1065 false true 4744 = true := by decide +kernel
private theorem w1065_2 : checkWitness 1065 true false 647 = true := by decide +kernel
private theorem w1065_3 : checkWitness 1065 true true 4735 = true := by decide +kernel
private theorem cases1065 : checkFour 1065 (656,4744,647,4735) = true := by
  simp only [checkFour, w1065_0,w1065_1,w1065_2,w1065_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1065 : Coverage 1065 1066 := checkList_sound (ws:=[(656,4744,647,4735)]) (by simpa only [checkList, Bool.and_true] using cases1065)
private theorem w1066_0 : checkWitness 1066 false false 8914 = true := by decide +kernel
private theorem w1066_2 : checkWitness 1066 true false 8910 = true := by decide +kernel
private theorem cases1066 : checkFour 1066 (8914,0,8910,0) = true := by
  simp only [checkFour, w1066_0,w1066_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1066 : Coverage 1066 1067 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases1066)
private theorem w1067_0 : checkWitness 1067 false false 76 = true := by decide +kernel
private theorem w1067_2 : checkWitness 1067 true false 76 = true := by decide +kernel
private theorem cases1067 : checkFour 1067 (76,0,76,0) = true := by
  simp only [checkFour, w1067_0,w1067_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1067 : Coverage 1067 1068 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1067)
private theorem w1068_0 : checkWitness 1068 false false 702 = true := by decide +kernel
private theorem w1068_1 : checkWitness 1068 false true 4798 = true := by decide +kernel
private theorem w1068_2 : checkWitness 1068 true false 702 = true := by decide +kernel
private theorem w1068_3 : checkWitness 1068 true true 4798 = true := by decide +kernel
private theorem cases1068 : checkFour 1068 (702,4798,702,4798) = true := by
  simp only [checkFour, w1068_0,w1068_1,w1068_2,w1068_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1068 : Coverage 1068 1069 := checkList_sound (ws:=[(702,4798,702,4798)]) (by simpa only [checkList, Bool.and_true] using cases1068)
private theorem w1069_0 : checkWitness 1069 false false 8954 = true := by decide +kernel
private theorem w1069_2 : checkWitness 1069 true false 8945 = true := by decide +kernel
private theorem cases1069 : checkFour 1069 (8954,0,8945,0) = true := by
  simp only [checkFour, w1069_0,w1069_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1069 : Coverage 1069 1070 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases1069)
private theorem w1070_0 : checkWitness 1070 false false 84 = true := by decide +kernel
private theorem w1070_2 : checkWitness 1070 true false 84 = true := by decide +kernel
private theorem cases1070 : checkFour 1070 (84,0,84,0) = true := by
  simp only [checkFour, w1070_0,w1070_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1070 : Coverage 1070 1071 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1070)
private theorem w1071_0 : checkWitness 1071 false false 536 = true := by decide +kernel
private theorem w1071_1 : checkWitness 1071 false true 4632 = true := by decide +kernel
private theorem w1071_2 : checkWitness 1071 true false 536 = true := by decide +kernel
private theorem w1071_3 : checkWitness 1071 true true 4632 = true := by decide +kernel
private theorem cases1071 : checkFour 1071 (536,4632,536,4632) = true := by
  simp only [checkFour, w1071_0,w1071_1,w1071_2,w1071_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1071 : Coverage 1071 1072 := checkList_sound (ws:=[(536,4632,536,4632)]) (by simpa only [checkList, Bool.and_true] using cases1071)
private theorem w1072_0 : checkWitness 1072 false false 8894 = true := by decide +kernel
private theorem w1072_2 : checkWitness 1072 true false 8890 = true := by decide +kernel
private theorem cases1072 : checkFour 1072 (8894,0,8890,0) = true := by
  simp only [checkFour, w1072_0,w1072_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1072 : Coverage 1072 1073 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases1072)
private theorem w1073_0 : checkWitness 1073 false false 86 = true := by decide +kernel
private theorem w1073_2 : checkWitness 1073 true false 86 = true := by decide +kernel
private theorem cases1073 : checkFour 1073 (86,0,86,0) = true := by
  simp only [checkFour, w1073_0,w1073_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1073 : Coverage 1073 1074 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1073)
private theorem w1074_0 : checkWitness 1074 false false 574 = true := by decide +kernel
private theorem w1074_1 : checkWitness 1074 false true 4670 = true := by decide +kernel
private theorem w1074_2 : checkWitness 1074 true false 574 = true := by decide +kernel
private theorem w1074_3 : checkWitness 1074 true true 4670 = true := by decide +kernel
private theorem cases1074 : checkFour 1074 (574,4670,574,4670) = true := by
  simp only [checkFour, w1074_0,w1074_1,w1074_2,w1074_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1074 : Coverage 1074 1075 := checkList_sound (ws:=[(574,4670,574,4670)]) (by simpa only [checkList, Bool.and_true] using cases1074)
private theorem w1075_0 : checkWitness 1075 false false 8915 = true := by decide +kernel
private theorem w1075_2 : checkWitness 1075 true false 8911 = true := by decide +kernel
private theorem cases1075 : checkFour 1075 (8915,0,8911,0) = true := by
  simp only [checkFour, w1075_0,w1075_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1075 : Coverage 1075 1076 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases1075)
private theorem w1076_0 : checkWitness 1076 false false 8950 = true := by decide +kernel
private theorem w1076_2 : checkWitness 1076 true false 8941 = true := by decide +kernel
private theorem cases1076 : checkFour 1076 (8950,0,8941,0) = true := by
  simp only [checkFour, w1076_0,w1076_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1076 : Coverage 1076 1077 := checkList_sound (ws:=[(8950,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases1076)
private theorem w1077_0 : checkWitness 1077 false false 110 = true := by decide +kernel
private theorem w1077_2 : checkWitness 1077 true false 110 = true := by decide +kernel
private theorem cases1077 : checkFour 1077 (110,0,110,0) = true := by
  simp only [checkFour, w1077_0,w1077_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1077 : Coverage 1077 1078 := checkList_sound (ws:=[(110,0,110,0)]) (by simpa only [checkList, Bool.and_true] using cases1077)
private theorem w1078_0 : checkWitness 1078 false false 662 = true := by decide +kernel
private theorem w1078_1 : checkWitness 1078 false true 4754 = true := by decide +kernel
private theorem w1078_2 : checkWitness 1078 true false 653 = true := by decide +kernel
private theorem w1078_3 : checkWitness 1078 true true 4745 = true := by decide +kernel
private theorem cases1078 : checkFour 1078 (662,4754,653,4745) = true := by
  simp only [checkFour, w1078_0,w1078_1,w1078_2,w1078_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1078 : Coverage 1078 1079 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases1078)
private theorem w1079_0 : checkWitness 1079 false false 8911 = true := by decide +kernel
private theorem w1079_2 : checkWitness 1079 true false 8907 = true := by decide +kernel
private theorem cases1079 : checkFour 1079 (8911,0,8907,0) = true := by
  simp only [checkFour, w1079_0,w1079_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1079 : Coverage 1079 1080 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases1079)
private theorem w1080_0 : checkWitness 1080 false false 656 = true := by decide +kernel
private theorem w1080_1 : checkWitness 1080 false true 4748 = true := by decide +kernel
private theorem w1080_2 : checkWitness 1080 true false 647 = true := by decide +kernel
private theorem w1080_3 : checkWitness 1080 true true 4739 = true := by decide +kernel
private theorem cases1080 : checkFour 1080 (656,4748,647,4739) = true := by
  simp only [checkFour, w1080_0,w1080_1,w1080_2,w1080_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1080 : Coverage 1080 1081 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases1080)
private theorem w1081_0 : checkWitness 1081 false false 8880 = true := by decide +kernel
private theorem w1081_2 : checkWitness 1081 true false 8876 = true := by decide +kernel
private theorem cases1081 : checkFour 1081 (8880,0,8876,0) = true := by
  simp only [checkFour, w1081_0,w1081_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1081 : Coverage 1081 1082 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases1081)
private theorem w1082_0 : checkWitness 1082 false false 98 = true := by decide +kernel
private theorem w1082_2 : checkWitness 1082 true false 98 = true := by decide +kernel
private theorem cases1082 : checkFour 1082 (98,0,98,0) = true := by
  simp only [checkFour, w1082_0,w1082_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1082 : Coverage 1082 1083 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1082)
private theorem w1083_0 : checkWitness 1083 false false 90 = true := by decide +kernel
private theorem w1083_2 : checkWitness 1083 true false 90 = true := by decide +kernel
private theorem cases1083 : checkFour 1083 (90,0,90,0) = true := by
  simp only [checkFour, w1083_0,w1083_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1083 : Coverage 1083 1084 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1083)
private theorem w1084_0 : checkWitness 1084 false false 621 = true := by decide +kernel
private theorem w1084_1 : checkWitness 1084 false true 4705 = true := by decide +kernel
private theorem w1084_2 : checkWitness 1084 true false 621 = true := by decide +kernel
private theorem w1084_3 : checkWitness 1084 true true 4705 = true := by decide +kernel
private theorem cases1084 : checkFour 1084 (621,4705,621,4705) = true := by
  simp only [checkFour, w1084_0,w1084_1,w1084_2,w1084_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1084 : Coverage 1084 1085 := checkList_sound (ws:=[(621,4705,621,4705)]) (by simpa only [checkList, Bool.and_true] using cases1084)
private theorem w1085_0 : checkWitness 1085 false false 8874 = true := by decide +kernel
private theorem w1085_2 : checkWitness 1085 true false 8870 = true := by decide +kernel
private theorem cases1085 : checkFour 1085 (8874,0,8870,0) = true := by
  simp only [checkFour, w1085_0,w1085_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1085 : Coverage 1085 1086 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases1085)
private theorem w1086_0 : checkWitness 1086 false false 90 = true := by decide +kernel
private theorem w1086_2 : checkWitness 1086 true false 90 = true := by decide +kernel
private theorem cases1086 : checkFour 1086 (90,0,90,0) = true := by
  simp only [checkFour, w1086_0,w1086_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1086 : Coverage 1086 1087 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1086)
private theorem w1087_0 : checkWitness 1087 false false 619 = true := by decide +kernel
private theorem w1087_1 : checkWitness 1087 false true 4711 = true := by decide +kernel
private theorem w1087_2 : checkWitness 1087 true false 610 = true := by decide +kernel
private theorem w1087_3 : checkWitness 1087 true true 4702 = true := by decide +kernel
private theorem cases1087 : checkFour 1087 (619,4711,610,4702) = true := by
  simp only [checkFour, w1087_0,w1087_1,w1087_2,w1087_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1087 : Coverage 1087 1088 := checkList_sound (ws:=[(619,4711,610,4702)]) (by simpa only [checkList, Bool.and_true] using cases1087)
theorem cover1056 : Coverage 1056 1088 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1056 one1057) (Coverage.join one1058 one1059)) (Coverage.join (Coverage.join one1060 one1061) (Coverage.join one1062 one1063))) (Coverage.join (Coverage.join (Coverage.join one1064 one1065) (Coverage.join one1066 one1067)) (Coverage.join (Coverage.join one1068 one1069) (Coverage.join one1070 one1071)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1072 one1073) (Coverage.join one1074 one1075)) (Coverage.join (Coverage.join one1076 one1077) (Coverage.join one1078 one1079))) (Coverage.join (Coverage.join (Coverage.join one1080 one1081) (Coverage.join one1082 one1083)) (Coverage.join (Coverage.join one1084 one1085) (Coverage.join one1086 one1087)))))
end NF180PA.Symbolic
