import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2496_0 : checkWitness 2496 false false 8918 = true := by decide +kernel
private theorem w2496_2 : checkWitness 2496 true false 8914 = true := by decide +kernel
private theorem cases2496 : checkFour 2496 (8918,0,8914,0) = true := by
  simp only [checkFour, w2496_0,w2496_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2496 : Coverage 2496 2497 := checkList_sound (ws:=[(8918,0,8914,0)]) (by simpa only [checkList, Bool.and_true] using cases2496)
private theorem w2497_0 : checkWitness 2497 false false 74 = true := by decide +kernel
private theorem w2497_2 : checkWitness 2497 true false 74 = true := by decide +kernel
private theorem cases2497 : checkFour 2497 (74,0,74,0) = true := by
  simp only [checkFour, w2497_0,w2497_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2497 : Coverage 2497 2498 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2497)
private theorem w2498_0 : checkWitness 2498 false false 66 = true := by decide +kernel
private theorem w2498_2 : checkWitness 2498 true false 66 = true := by decide +kernel
private theorem cases2498 : checkFour 2498 (66,0,66,0) = true := by
  simp only [checkFour, w2498_0,w2498_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2498 : Coverage 2498 2499 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2498)
private theorem w2499_0 : checkWitness 2499 false false 659 = true := by decide +kernel
private theorem w2499_1 : checkWitness 2499 false true 4743 = true := by decide +kernel
private theorem w2499_2 : checkWitness 2499 true false 659 = true := by decide +kernel
private theorem w2499_3 : checkWitness 2499 true true 4743 = true := by decide +kernel
private theorem cases2499 : checkFour 2499 (659,4743,659,4743) = true := by
  simp only [checkFour, w2499_0,w2499_1,w2499_2,w2499_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2499 : Coverage 2499 2500 := checkList_sound (ws:=[(659,4743,659,4743)]) (by simpa only [checkList, Bool.and_true] using cases2499)
private theorem w2500_0 : checkWitness 2500 false false 8912 = true := by decide +kernel
private theorem w2500_2 : checkWitness 2500 true false 8908 = true := by decide +kernel
private theorem cases2500 : checkFour 2500 (8912,0,8908,0) = true := by
  simp only [checkFour, w2500_0,w2500_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2500 : Coverage 2500 2501 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases2500)
private theorem w2501_0 : checkWitness 2501 false false 66 = true := by decide +kernel
private theorem w2501_2 : checkWitness 2501 true false 66 = true := by decide +kernel
private theorem cases2501 : checkFour 2501 (66,0,66,0) = true := by
  simp only [checkFour, w2501_0,w2501_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2501 : Coverage 2501 2502 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2501)
private theorem w2502_0 : checkWitness 2502 false false 627 = true := by decide +kernel
private theorem w2502_1 : checkWitness 2502 false true 4723 = true := by decide +kernel
private theorem w2502_2 : checkWitness 2502 true false 627 = true := by decide +kernel
private theorem w2502_3 : checkWitness 2502 true true 4723 = true := by decide +kernel
private theorem cases2502 : checkFour 2502 (627,4723,627,4723) = true := by
  simp only [checkFour, w2502_0,w2502_1,w2502_2,w2502_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2502 : Coverage 2502 2503 := checkList_sound (ws:=[(627,4723,627,4723)]) (by simpa only [checkList, Bool.and_true] using cases2502)
private theorem w2503_0 : checkWitness 2503 false false 8980 = true := by decide +kernel
private theorem w2503_2 : checkWitness 2503 true false 8971 = true := by decide +kernel
private theorem cases2503 : checkFour 2503 (8980,0,8971,0) = true := by
  simp only [checkFour, w2503_0,w2503_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2503 : Coverage 2503 2504 := checkList_sound (ws:=[(8980,0,8971,0)]) (by simpa only [checkList, Bool.and_true] using cases2503)
private theorem w2504_0 : checkWitness 2504 false false 8926 = true := by decide +kernel
private theorem w2504_2 : checkWitness 2504 true false 8922 = true := by decide +kernel
private theorem cases2504 : checkFour 2504 (8926,0,8922,0) = true := by
  simp only [checkFour, w2504_0,w2504_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2504 : Coverage 2504 2505 := checkList_sound (ws:=[(8926,0,8922,0)]) (by simpa only [checkList, Bool.and_true] using cases2504)
private theorem w2505_0 : checkWitness 2505 false false 74 = true := by decide +kernel
private theorem w2505_2 : checkWitness 2505 true false 74 = true := by decide +kernel
private theorem cases2505 : checkFour 2505 (74,0,74,0) = true := by
  simp only [checkFour, w2505_0,w2505_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2505 : Coverage 2505 2506 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2505)
private theorem w2506_0 : checkWitness 2506 false false 710 = true := by decide +kernel
private theorem w2506_1 : checkWitness 2506 false true 4798 = true := by decide +kernel
private theorem w2506_2 : checkWitness 2506 true false 701 = true := by decide +kernel
private theorem w2506_3 : checkWitness 2506 true true 4789 = true := by decide +kernel
private theorem cases2506 : checkFour 2506 (710,4798,701,4789) = true := by
  simp only [checkFour, w2506_0,w2506_1,w2506_2,w2506_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2506 : Coverage 2506 2507 := checkList_sound (ws:=[(710,4798,701,4789)]) (by simpa only [checkList, Bool.and_true] using cases2506)
private theorem w2507_0 : checkWitness 2507 false false 8945 = true := by decide +kernel
private theorem w2507_2 : checkWitness 2507 true false 8941 = true := by decide +kernel
private theorem cases2507 : checkFour 2507 (8945,0,8941,0) = true := by
  simp only [checkFour, w2507_0,w2507_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2507 : Coverage 2507 2508 := checkList_sound (ws:=[(8945,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2507)
private theorem w2508_0 : checkWitness 2508 false false 64 = true := by decide +kernel
private theorem w2508_2 : checkWitness 2508 true false 64 = true := by decide +kernel
private theorem cases2508 : checkFour 2508 (64,0,64,0) = true := by
  simp only [checkFour, w2508_0,w2508_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2508 : Coverage 2508 2509 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2508)
private theorem w2509_0 : checkWitness 2509 false false 720 = true := by decide +kernel
private theorem w2509_1 : checkWitness 2509 false true 4816 = true := by decide +kernel
private theorem w2509_2 : checkWitness 2509 true false 720 = true := by decide +kernel
private theorem w2509_3 : checkWitness 2509 true true 4816 = true := by decide +kernel
private theorem cases2509 : checkFour 2509 (720,4816,720,4816) = true := by
  simp only [checkFour, w2509_0,w2509_1,w2509_2,w2509_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2509 : Coverage 2509 2510 := checkList_sound (ws:=[(720,4816,720,4816)]) (by simpa only [checkList, Bool.and_true] using cases2509)
private theorem w2510_0 : checkWitness 2510 false false 8990 = true := by decide +kernel
private theorem w2510_2 : checkWitness 2510 true false 8981 = true := by decide +kernel
private theorem cases2510 : checkFour 2510 (8990,0,8981,0) = true := by
  simp only [checkFour, w2510_0,w2510_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2510 : Coverage 2510 2511 := checkList_sound (ws:=[(8990,0,8981,0)]) (by simpa only [checkList, Bool.and_true] using cases2510)
private theorem w2511_0 : checkWitness 2511 false false 66 = true := by decide +kernel
private theorem w2511_2 : checkWitness 2511 true false 66 = true := by decide +kernel
private theorem cases2511 : checkFour 2511 (66,0,66,0) = true := by
  simp only [checkFour, w2511_0,w2511_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2511 : Coverage 2511 2512 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2511)
private theorem w2512_0 : checkWitness 2512 false false 572 = true := by decide +kernel
private theorem w2512_1 : checkWitness 2512 false true 4668 = true := by decide +kernel
private theorem w2512_2 : checkWitness 2512 true false 572 = true := by decide +kernel
private theorem w2512_3 : checkWitness 2512 true true 4668 = true := by decide +kernel
private theorem cases2512 : checkFour 2512 (572,4668,572,4668) = true := by
  simp only [checkFour, w2512_0,w2512_1,w2512_2,w2512_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2512 : Coverage 2512 2513 := checkList_sound (ws:=[(572,4668,572,4668)]) (by simpa only [checkList, Bool.and_true] using cases2512)
private theorem w2513_0 : checkWitness 2513 false false 8930 = true := by decide +kernel
private theorem w2513_2 : checkWitness 2513 true false 8926 = true := by decide +kernel
private theorem cases2513 : checkFour 2513 (8930,0,8926,0) = true := by
  simp only [checkFour, w2513_0,w2513_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2513 : Coverage 2513 2514 := checkList_sound (ws:=[(8930,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases2513)
private theorem w2514_0 : checkWitness 2514 false false 68 = true := by decide +kernel
private theorem w2514_2 : checkWitness 2514 true false 68 = true := by decide +kernel
private theorem cases2514 : checkFour 2514 (68,0,68,0) = true := by
  simp only [checkFour, w2514_0,w2514_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2514 : Coverage 2514 2515 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2514)
private theorem w2515_0 : checkWitness 2515 false false 610 = true := by decide +kernel
private theorem w2515_1 : checkWitness 2515 false true 4706 = true := by decide +kernel
private theorem w2515_2 : checkWitness 2515 true false 610 = true := by decide +kernel
private theorem w2515_3 : checkWitness 2515 true true 4706 = true := by decide +kernel
private theorem cases2515 : checkFour 2515 (610,4706,610,4706) = true := by
  simp only [checkFour, w2515_0,w2515_1,w2515_2,w2515_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2515 : Coverage 2515 2516 := checkList_sound (ws:=[(610,4706,610,4706)]) (by simpa only [checkList, Bool.and_true] using cases2515)
private theorem w2516_0 : checkWitness 2516 false false 8951 = true := by decide +kernel
private theorem w2516_2 : checkWitness 2516 true false 8947 = true := by decide +kernel
private theorem cases2516 : checkFour 2516 (8951,0,8947,0) = true := by
  simp only [checkFour, w2516_0,w2516_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2516 : Coverage 2516 2517 := checkList_sound (ws:=[(8951,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2516)
private theorem w2517_0 : checkWitness 2517 false false 8986 = true := by decide +kernel
private theorem w2517_2 : checkWitness 2517 true false 8977 = true := by decide +kernel
private theorem cases2517 : checkFour 2517 (8986,0,8977,0) = true := by
  simp only [checkFour, w2517_0,w2517_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2517 : Coverage 2517 2518 := checkList_sound (ws:=[(8986,0,8977,0)]) (by simpa only [checkList, Bool.and_true] using cases2517)
private theorem w2518_0 : checkWitness 2518 false false 92 = true := by decide +kernel
private theorem w2518_2 : checkWitness 2518 true false 92 = true := by decide +kernel
private theorem cases2518 : checkFour 2518 (92,0,92,0) = true := by
  simp only [checkFour, w2518_0,w2518_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2518 : Coverage 2518 2519 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases2518)
private theorem w2519_0 : checkWitness 2519 false false 698 = true := by decide +kernel
private theorem w2519_1 : checkWitness 2519 false true 4790 = true := by decide +kernel
private theorem w2519_2 : checkWitness 2519 true false 689 = true := by decide +kernel
private theorem w2519_3 : checkWitness 2519 true true 4781 = true := by decide +kernel
private theorem cases2519 : checkFour 2519 (698,4790,689,4781) = true := by
  simp only [checkFour, w2519_0,w2519_1,w2519_2,w2519_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2519 : Coverage 2519 2520 := checkList_sound (ws:=[(698,4790,689,4781)]) (by simpa only [checkList, Bool.and_true] using cases2519)
private theorem w2520_0 : checkWitness 2520 false false 8947 = true := by decide +kernel
private theorem w2520_2 : checkWitness 2520 true false 8943 = true := by decide +kernel
private theorem cases2520 : checkFour 2520 (8947,0,8943,0) = true := by
  simp only [checkFour, w2520_0,w2520_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2520 : Coverage 2520 2521 := checkList_sound (ws:=[(8947,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases2520)
private theorem w2521_0 : checkWitness 2521 false false 692 = true := by decide +kernel
private theorem w2521_1 : checkWitness 2521 false true 4784 = true := by decide +kernel
private theorem w2521_2 : checkWitness 2521 true false 683 = true := by decide +kernel
private theorem w2521_3 : checkWitness 2521 true true 4775 = true := by decide +kernel
private theorem cases2521 : checkFour 2521 (692,4784,683,4775) = true := by
  simp only [checkFour, w2521_0,w2521_1,w2521_2,w2521_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2521 : Coverage 2521 2522 := checkList_sound (ws:=[(692,4784,683,4775)]) (by simpa only [checkList, Bool.and_true] using cases2521)
private theorem w2522_0 : checkWitness 2522 false false 8916 = true := by decide +kernel
private theorem w2522_2 : checkWitness 2522 true false 8912 = true := by decide +kernel
private theorem cases2522 : checkFour 2522 (8916,0,8912,0) = true := by
  simp only [checkFour, w2522_0,w2522_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2522 : Coverage 2522 2523 := checkList_sound (ws:=[(8916,0,8912,0)]) (by simpa only [checkList, Bool.and_true] using cases2522)
private theorem w2523_0 : checkWitness 2523 false false 80 = true := by decide +kernel
private theorem w2523_2 : checkWitness 2523 true false 80 = true := by decide +kernel
private theorem cases2523 : checkFour 2523 (80,0,80,0) = true := by
  simp only [checkFour, w2523_0,w2523_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2523 : Coverage 2523 2524 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2523)
private theorem w2524_0 : checkWitness 2524 false false 72 = true := by decide +kernel
private theorem w2524_2 : checkWitness 2524 true false 72 = true := by decide +kernel
private theorem cases2524 : checkFour 2524 (72,0,72,0) = true := by
  simp only [checkFour, w2524_0,w2524_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2524 : Coverage 2524 2525 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2524)
private theorem w2525_0 : checkWitness 2525 false false 657 = true := by decide +kernel
private theorem w2525_1 : checkWitness 2525 false true 4741 = true := by decide +kernel
private theorem w2525_2 : checkWitness 2525 true false 657 = true := by decide +kernel
private theorem w2525_3 : checkWitness 2525 true true 4741 = true := by decide +kernel
private theorem cases2525 : checkFour 2525 (657,4741,657,4741) = true := by
  simp only [checkFour, w2525_0,w2525_1,w2525_2,w2525_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2525 : Coverage 2525 2526 := checkList_sound (ws:=[(657,4741,657,4741)]) (by simpa only [checkList, Bool.and_true] using cases2525)
private theorem w2526_0 : checkWitness 2526 false false 8910 = true := by decide +kernel
private theorem w2526_2 : checkWitness 2526 true false 8906 = true := by decide +kernel
private theorem cases2526 : checkFour 2526 (8910,0,8906,0) = true := by
  simp only [checkFour, w2526_0,w2526_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2526 : Coverage 2526 2527 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2526)
private theorem w2527_0 : checkWitness 2527 false false 72 = true := by decide +kernel
private theorem w2527_2 : checkWitness 2527 true false 72 = true := by decide +kernel
private theorem cases2527 : checkFour 2527 (72,0,72,0) = true := by
  simp only [checkFour, w2527_0,w2527_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2527 : Coverage 2527 2528 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2527)
theorem cover2496 : Coverage 2496 2528 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2496 one2497) (Coverage.join one2498 one2499)) (Coverage.join (Coverage.join one2500 one2501) (Coverage.join one2502 one2503))) (Coverage.join (Coverage.join (Coverage.join one2504 one2505) (Coverage.join one2506 one2507)) (Coverage.join (Coverage.join one2508 one2509) (Coverage.join one2510 one2511)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2512 one2513) (Coverage.join one2514 one2515)) (Coverage.join (Coverage.join one2516 one2517) (Coverage.join one2518 one2519))) (Coverage.join (Coverage.join (Coverage.join one2520 one2521) (Coverage.join one2522 one2523)) (Coverage.join (Coverage.join one2524 one2525) (Coverage.join one2526 one2527)))))
end NF180PA.Symbolic
