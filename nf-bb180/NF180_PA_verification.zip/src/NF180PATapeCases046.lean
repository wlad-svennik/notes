import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1472_0 : checkWitness 1472 false false 8852 = true := by decide +kernel
private theorem w1472_2 : checkWitness 1472 true false 8848 = true := by decide +kernel
private theorem cases1472 : checkFour 1472 (8852,0,8848,0) = true := by
  simp only [checkFour, w1472_0,w1472_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1472 : Coverage 1472 1473 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1472)
private theorem w1473_0 : checkWitness 1473 false false 102 = true := by decide +kernel
private theorem w1473_2 : checkWitness 1473 true false 102 = true := by decide +kernel
private theorem cases1473 : checkFour 1473 (102,0,102,0) = true := by
  simp only [checkFour, w1473_0,w1473_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1473 : Coverage 1473 1474 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1473)
private theorem w1474_0 : checkWitness 1474 false false 94 = true := by decide +kernel
private theorem w1474_2 : checkWitness 1474 true false 94 = true := by decide +kernel
private theorem cases1474 : checkFour 1474 (94,0,94,0) = true := by
  simp only [checkFour, w1474_0,w1474_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1474 : Coverage 1474 1475 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1474)
private theorem w1475_0 : checkWitness 1475 false false 593 = true := by decide +kernel
private theorem w1475_1 : checkWitness 1475 false true 4677 = true := by decide +kernel
private theorem w1475_2 : checkWitness 1475 true false 593 = true := by decide +kernel
private theorem w1475_3 : checkWitness 1475 true true 4677 = true := by decide +kernel
private theorem cases1475 : checkFour 1475 (593,4677,593,4677) = true := by
  simp only [checkFour, w1475_0,w1475_1,w1475_2,w1475_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1475 : Coverage 1475 1476 := checkList_sound (ws:=[(593,4677,593,4677)]) (by simpa only [checkList, Bool.and_true] using cases1475)
private theorem w1476_0 : checkWitness 1476 false false 8846 = true := by decide +kernel
private theorem w1476_2 : checkWitness 1476 true false 8842 = true := by decide +kernel
private theorem cases1476 : checkFour 1476 (8846,0,8842,0) = true := by
  simp only [checkFour, w1476_0,w1476_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1476 : Coverage 1476 1477 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1476)
private theorem w1477_0 : checkWitness 1477 false false 94 = true := by decide +kernel
private theorem w1477_2 : checkWitness 1477 true false 94 = true := by decide +kernel
private theorem cases1477 : checkFour 1477 (94,0,94,0) = true := by
  simp only [checkFour, w1477_0,w1477_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1477 : Coverage 1477 1478 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1477)
private theorem w1478_0 : checkWitness 1478 false false 561 = true := by decide +kernel
private theorem w1478_1 : checkWitness 1478 false true 4657 = true := by decide +kernel
private theorem w1478_2 : checkWitness 1478 true false 561 = true := by decide +kernel
private theorem w1478_3 : checkWitness 1478 true true 4657 = true := by decide +kernel
private theorem cases1478 : checkFour 1478 (561,4657,561,4657) = true := by
  simp only [checkFour, w1478_0,w1478_1,w1478_2,w1478_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1478 : Coverage 1478 1479 := checkList_sound (ws:=[(561,4657,561,4657)]) (by simpa only [checkList, Bool.and_true] using cases1478)
private theorem w1479_0 : checkWitness 1479 false false 8914 = true := by decide +kernel
private theorem w1479_2 : checkWitness 1479 true false 8905 = true := by decide +kernel
private theorem cases1479 : checkFour 1479 (8914,0,8905,0) = true := by
  simp only [checkFour, w1479_0,w1479_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1479 : Coverage 1479 1480 := checkList_sound (ws:=[(8914,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases1479)
private theorem w1480_0 : checkWitness 1480 false false 8860 = true := by decide +kernel
private theorem w1480_2 : checkWitness 1480 true false 8856 = true := by decide +kernel
private theorem cases1480 : checkFour 1480 (8860,0,8856,0) = true := by
  simp only [checkFour, w1480_0,w1480_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1480 : Coverage 1480 1481 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases1480)
private theorem w1481_0 : checkWitness 1481 false false 102 = true := by decide +kernel
private theorem w1481_2 : checkWitness 1481 true false 102 = true := by decide +kernel
private theorem cases1481 : checkFour 1481 (102,0,102,0) = true := by
  simp only [checkFour, w1481_0,w1481_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1481 : Coverage 1481 1482 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1481)
private theorem w1482_0 : checkWitness 1482 false false 644 = true := by decide +kernel
private theorem w1482_1 : checkWitness 1482 false true 4732 = true := by decide +kernel
private theorem w1482_2 : checkWitness 1482 true false 635 = true := by decide +kernel
private theorem w1482_3 : checkWitness 1482 true true 4723 = true := by decide +kernel
private theorem cases1482 : checkFour 1482 (644,4732,635,4723) = true := by
  simp only [checkFour, w1482_0,w1482_1,w1482_2,w1482_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1482 : Coverage 1482 1483 := checkList_sound (ws:=[(644,4732,635,4723)]) (by simpa only [checkList, Bool.and_true] using cases1482)
private theorem w1483_0 : checkWitness 1483 false false 8879 = true := by decide +kernel
private theorem w1483_2 : checkWitness 1483 true false 8875 = true := by decide +kernel
private theorem cases1483 : checkFour 1483 (8879,0,8875,0) = true := by
  simp only [checkFour, w1483_0,w1483_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1483 : Coverage 1483 1484 := checkList_sound (ws:=[(8879,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases1483)
private theorem w1484_0 : checkWitness 1484 false false 92 = true := by decide +kernel
private theorem w1484_2 : checkWitness 1484 true false 92 = true := by decide +kernel
private theorem cases1484 : checkFour 1484 (92,0,92,0) = true := by
  simp only [checkFour, w1484_0,w1484_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1484 : Coverage 1484 1485 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1484)
private theorem w1485_0 : checkWitness 1485 false false 682 = true := by decide +kernel
private theorem w1485_1 : checkWitness 1485 false true 4778 = true := by decide +kernel
private theorem w1485_2 : checkWitness 1485 true false 682 = true := by decide +kernel
private theorem w1485_3 : checkWitness 1485 true true 4778 = true := by decide +kernel
private theorem cases1485 : checkFour 1485 (682,4778,682,4778) = true := by
  simp only [checkFour, w1485_0,w1485_1,w1485_2,w1485_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1485 : Coverage 1485 1486 := checkList_sound (ws:=[(682,4778,682,4778)]) (by simpa only [checkList, Bool.and_true] using cases1485)
private theorem w1486_0 : checkWitness 1486 false false 8924 = true := by decide +kernel
private theorem w1486_2 : checkWitness 1486 true false 8915 = true := by decide +kernel
private theorem cases1486 : checkFour 1486 (8924,0,8915,0) = true := by
  simp only [checkFour, w1486_0,w1486_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1486 : Coverage 1486 1487 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases1486)
private theorem w1487_0 : checkWitness 1487 false false 94 = true := by decide +kernel
private theorem w1487_2 : checkWitness 1487 true false 94 = true := by decide +kernel
private theorem cases1487 : checkFour 1487 (94,0,94,0) = true := by
  simp only [checkFour, w1487_0,w1487_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1487 : Coverage 1487 1488 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1487)
private theorem w1488_0 : checkWitness 1488 false false 506 = true := by decide +kernel
private theorem w1488_1 : checkWitness 1488 false true 4602 = true := by decide +kernel
private theorem w1488_2 : checkWitness 1488 true false 506 = true := by decide +kernel
private theorem w1488_3 : checkWitness 1488 true true 4602 = true := by decide +kernel
private theorem cases1488 : checkFour 1488 (506,4602,506,4602) = true := by
  simp only [checkFour, w1488_0,w1488_1,w1488_2,w1488_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1488 : Coverage 1488 1489 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases1488)
private theorem w1489_0 : checkWitness 1489 false false 8864 = true := by decide +kernel
private theorem w1489_2 : checkWitness 1489 true false 8860 = true := by decide +kernel
private theorem cases1489 : checkFour 1489 (8864,0,8860,0) = true := by
  simp only [checkFour, w1489_0,w1489_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1489 : Coverage 1489 1490 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases1489)
private theorem w1490_0 : checkWitness 1490 false false 96 = true := by decide +kernel
private theorem w1490_2 : checkWitness 1490 true false 96 = true := by decide +kernel
private theorem cases1490 : checkFour 1490 (96,0,96,0) = true := by
  simp only [checkFour, w1490_0,w1490_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1490 : Coverage 1490 1491 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1490)
private theorem w1491_0 : checkWitness 1491 false false 544 = true := by decide +kernel
private theorem w1491_1 : checkWitness 1491 false true 4640 = true := by decide +kernel
private theorem w1491_2 : checkWitness 1491 true false 544 = true := by decide +kernel
private theorem w1491_3 : checkWitness 1491 true true 4640 = true := by decide +kernel
private theorem cases1491 : checkFour 1491 (544,4640,544,4640) = true := by
  simp only [checkFour, w1491_0,w1491_1,w1491_2,w1491_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1491 : Coverage 1491 1492 := checkList_sound (ws:=[(544,4640,544,4640)]) (by simpa only [checkList, Bool.and_true] using cases1491)
private theorem w1492_0 : checkWitness 1492 false false 8885 = true := by decide +kernel
private theorem w1492_2 : checkWitness 1492 true false 8881 = true := by decide +kernel
private theorem cases1492 : checkFour 1492 (8885,0,8881,0) = true := by
  simp only [checkFour, w1492_0,w1492_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1492 : Coverage 1492 1493 := checkList_sound (ws:=[(8885,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases1492)
private theorem w1493_0 : checkWitness 1493 false false 8920 = true := by decide +kernel
private theorem w1493_2 : checkWitness 1493 true false 8911 = true := by decide +kernel
private theorem cases1493 : checkFour 1493 (8920,0,8911,0) = true := by
  simp only [checkFour, w1493_0,w1493_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1493 : Coverage 1493 1494 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases1493)
private theorem w1494_0 : checkWitness 1494 false false 120 = true := by decide +kernel
private theorem w1494_2 : checkWitness 1494 true false 120 = true := by decide +kernel
private theorem cases1494 : checkFour 1494 (120,0,120,0) = true := by
  simp only [checkFour, w1494_0,w1494_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1494 : Coverage 1494 1495 := checkList_sound (ws:=[(120,0,120,0)]) (by simpa only [checkList, Bool.and_true] using cases1494)
private theorem w1495_0 : checkWitness 1495 false false 632 = true := by decide +kernel
private theorem w1495_1 : checkWitness 1495 false true 4724 = true := by decide +kernel
private theorem w1495_2 : checkWitness 1495 true false 623 = true := by decide +kernel
private theorem w1495_3 : checkWitness 1495 true true 4715 = true := by decide +kernel
private theorem cases1495 : checkFour 1495 (632,4724,623,4715) = true := by
  simp only [checkFour, w1495_0,w1495_1,w1495_2,w1495_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1495 : Coverage 1495 1496 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases1495)
private theorem w1496_0 : checkWitness 1496 false false 8881 = true := by decide +kernel
private theorem w1496_2 : checkWitness 1496 true false 8877 = true := by decide +kernel
private theorem cases1496 : checkFour 1496 (8881,0,8877,0) = true := by
  simp only [checkFour, w1496_0,w1496_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1496 : Coverage 1496 1497 := checkList_sound (ws:=[(8881,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases1496)
private theorem w1497_0 : checkWitness 1497 false false 626 = true := by decide +kernel
private theorem w1497_1 : checkWitness 1497 false true 4719 = true := by decide +kernel
private theorem w1497_2 : checkWitness 1497 true false 617 = true := by decide +kernel
private theorem w1497_3 : checkWitness 1497 true true 4710 = true := by decide +kernel
private theorem cases1497 : checkFour 1497 (626,4719,617,4710) = true := by
  simp only [checkFour, w1497_0,w1497_1,w1497_2,w1497_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1497 : Coverage 1497 1498 := checkList_sound (ws:=[(626,4719,617,4710)]) (by simpa only [checkList, Bool.and_true] using cases1497)
private theorem w1498_0 : checkWitness 1498 false false 8852 = true := by decide +kernel
private theorem w1498_2 : checkWitness 1498 true false 8848 = true := by decide +kernel
private theorem cases1498 : checkFour 1498 (8852,0,8848,0) = true := by
  simp only [checkFour, w1498_0,w1498_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1498 : Coverage 1498 1499 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1498)
private theorem w1499_0 : checkWitness 1499 false false 108 = true := by decide +kernel
private theorem w1499_2 : checkWitness 1499 true false 108 = true := by decide +kernel
private theorem cases1499 : checkFour 1499 (108,0,108,0) = true := by
  simp only [checkFour, w1499_0,w1499_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1499 : Coverage 1499 1500 := checkList_sound (ws:=[(108,0,108,0)]) (by simpa only [checkList, Bool.and_true] using cases1499)
private theorem w1500_0 : checkWitness 1500 false false 100 = true := by decide +kernel
private theorem w1500_2 : checkWitness 1500 true false 100 = true := by decide +kernel
private theorem cases1500 : checkFour 1500 (100,0,100,0) = true := by
  simp only [checkFour, w1500_0,w1500_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1500 : Coverage 1500 1501 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1500)
private theorem w1501_0 : checkWitness 1501 false false 591 = true := by decide +kernel
private theorem w1501_1 : checkWitness 1501 false true 4675 = true := by decide +kernel
private theorem w1501_2 : checkWitness 1501 true false 591 = true := by decide +kernel
private theorem w1501_3 : checkWitness 1501 true true 4675 = true := by decide +kernel
private theorem cases1501 : checkFour 1501 (591,4675,591,4675) = true := by
  simp only [checkFour, w1501_0,w1501_1,w1501_2,w1501_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1501 : Coverage 1501 1502 := checkList_sound (ws:=[(591,4675,591,4675)]) (by simpa only [checkList, Bool.and_true] using cases1501)
private theorem w1502_0 : checkWitness 1502 false false 8844 = true := by decide +kernel
private theorem w1502_2 : checkWitness 1502 true false 8840 = true := by decide +kernel
private theorem cases1502 : checkFour 1502 (8844,0,8840,0) = true := by
  simp only [checkFour, w1502_0,w1502_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1502 : Coverage 1502 1503 := checkList_sound (ws:=[(8844,0,8840,0)]) (by simpa only [checkList, Bool.and_true] using cases1502)
private theorem w1503_0 : checkWitness 1503 false false 100 = true := by decide +kernel
private theorem w1503_2 : checkWitness 1503 true false 100 = true := by decide +kernel
private theorem cases1503 : checkFour 1503 (100,0,100,0) = true := by
  simp only [checkFour, w1503_0,w1503_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1503 : Coverage 1503 1504 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1503)
theorem cover1472 : Coverage 1472 1504 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1472 one1473) (Coverage.join one1474 one1475)) (Coverage.join (Coverage.join one1476 one1477) (Coverage.join one1478 one1479))) (Coverage.join (Coverage.join (Coverage.join one1480 one1481) (Coverage.join one1482 one1483)) (Coverage.join (Coverage.join one1484 one1485) (Coverage.join one1486 one1487)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1488 one1489) (Coverage.join one1490 one1491)) (Coverage.join (Coverage.join one1492 one1493) (Coverage.join one1494 one1495))) (Coverage.join (Coverage.join (Coverage.join one1496 one1497) (Coverage.join one1498 one1499)) (Coverage.join (Coverage.join one1500 one1501) (Coverage.join one1502 one1503)))))
end NF180PA.Symbolic
