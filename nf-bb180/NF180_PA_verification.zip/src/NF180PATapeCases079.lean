import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2528_0 : checkWitness 2528 false false 655 = true := by decide +kernel
private theorem w2528_1 : checkWitness 2528 false true 4747 = true := by decide +kernel
private theorem w2528_2 : checkWitness 2528 true false 646 = true := by decide +kernel
private theorem w2528_3 : checkWitness 2528 true true 4738 = true := by decide +kernel
private theorem cases2528 : checkFour 2528 (655,4747,646,4738) = true := by
  simp only [checkFour, w2528_0,w2528_1,w2528_2,w2528_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2528 : Coverage 2528 2529 := checkList_sound (ws:=[(655,4747,646,4738)]) (by simpa only [checkList, Bool.and_true] using cases2528)
private theorem w2529_0 : checkWitness 2529 false false 8952 = true := by decide +kernel
private theorem w2529_2 : checkWitness 2529 true false 8943 = true := by decide +kernel
private theorem cases2529 : checkFour 2529 (8952,0,8943,0) = true := by
  simp only [checkFour, w2529_0,w2529_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2529 : Coverage 2529 2530 := checkList_sound (ws:=[(8952,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases2529)
private theorem w2530_0 : checkWitness 2530 false false 8898 = true := by decide +kernel
private theorem w2530_2 : checkWitness 2530 true false 8894 = true := by decide +kernel
private theorem cases2530 : checkFour 2530 (8898,0,8894,0) = true := by
  simp only [checkFour, w2530_0,w2530_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2530 : Coverage 2530 2531 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2530)
private theorem w2531_0 : checkWitness 2531 false false 66 = true := by decide +kernel
private theorem w2531_2 : checkWitness 2531 true false 66 = true := by decide +kernel
private theorem cases2531 : checkFour 2531 (66,0,66,0) = true := by
  simp only [checkFour, w2531_0,w2531_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2531 : Coverage 2531 2532 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2531)
private theorem w2532_0 : checkWitness 2532 false false 682 = true := by decide +kernel
private theorem w2532_1 : checkWitness 2532 false true 4774 = true := by decide +kernel
private theorem w2532_2 : checkWitness 2532 true false 673 = true := by decide +kernel
private theorem w2532_3 : checkWitness 2532 true true 4765 = true := by decide +kernel
private theorem cases2532 : checkFour 2532 (682,4774,673,4765) = true := by
  simp only [checkFour, w2532_0,w2532_1,w2532_2,w2532_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2532 : Coverage 2532 2533 := checkList_sound (ws:=[(682,4774,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases2532)
private theorem w2533_0 : checkWitness 2533 false false 8959 = true := by decide +kernel
private theorem w2533_2 : checkWitness 2533 true false 8950 = true := by decide +kernel
private theorem cases2533 : checkFour 2533 (8959,0,8950,0) = true := by
  simp only [checkFour, w2533_0,w2533_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2533 : Coverage 2533 2534 := checkList_sound (ws:=[(8959,0,8950,0)]) (by simpa only [checkList, Bool.and_true] using cases2533)
private theorem w2534_0 : checkWitness 2534 false false 50 = true := by decide +kernel
private theorem w2534_2 : checkWitness 2534 true false 50 = true := by decide +kernel
private theorem cases2534 : checkFour 2534 (50,0,50,0) = true := by
  simp only [checkFour, w2534_0,w2534_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2534 : Coverage 2534 2535 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2534)
private theorem w2535_0 : checkWitness 2535 false false 546 = true := by decide +kernel
private theorem w2535_1 : checkWitness 2535 false true 4642 = true := by decide +kernel
private theorem w2535_2 : checkWitness 2535 true false 546 = true := by decide +kernel
private theorem w2535_3 : checkWitness 2535 true true 4642 = true := by decide +kernel
private theorem cases2535 : checkFour 2535 (546,4642,546,4642) = true := by
  simp only [checkFour, w2535_0,w2535_1,w2535_2,w2535_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2535 : Coverage 2535 2536 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases2535)
private theorem w2536_0 : checkWitness 2536 false false 8941 = true := by decide +kernel
private theorem w2536_2 : checkWitness 2536 true false 8937 = true := by decide +kernel
private theorem cases2536 : checkFour 2536 (8941,0,8937,0) = true := by
  simp only [checkFour, w2536_0,w2536_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2536 : Coverage 2536 2537 := checkList_sound (ws:=[(8941,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases2536)
private theorem w2537_0 : checkWitness 2537 false false 672 = true := by decide +kernel
private theorem w2537_1 : checkWitness 2537 false true 4768 = true := by decide +kernel
private theorem w2537_2 : checkWitness 2537 true false 663 = true := by decide +kernel
private theorem w2537_3 : checkWitness 2537 true true 4759 = true := by decide +kernel
private theorem cases2537 : checkFour 2537 (672,4768,663,4759) = true := by
  simp only [checkFour, w2537_0,w2537_1,w2537_2,w2537_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2537 : Coverage 2537 2538 := checkList_sound (ws:=[(672,4768,663,4759)]) (by simpa only [checkList, Bool.and_true] using cases2537)
private theorem w2538_0 : checkWitness 2538 false false 200 = true := by decide +kernel
private theorem w2538_2 : checkWitness 2538 true false 200 = true := by decide +kernel
private theorem cases2538 : checkFour 2538 (200,0,200,0) = true := by
  simp only [checkFour, w2538_0,w2538_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2538 : Coverage 2538 2539 := checkList_sound (ws:=[(200,0,200,0)]) (by simpa only [checkList, Bool.and_true] using cases2538)
private theorem w2539_0 : checkWitness 2539 false false 627 = true := by decide +kernel
private theorem w2539_1 : checkWitness 2539 false true 4715 = true := by decide +kernel
private theorem w2539_2 : checkWitness 2539 true false 627 = true := by decide +kernel
private theorem w2539_3 : checkWitness 2539 true true 4715 = true := by decide +kernel
private theorem cases2539 : checkFour 2539 (627,4715,627,4715) = true := by
  simp only [checkFour, w2539_0,w2539_1,w2539_2,w2539_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2539 : Coverage 2539 2540 := checkList_sound (ws:=[(627,4715,627,4715)]) (by simpa only [checkList, Bool.and_true] using cases2539)
private theorem w2540_0 : checkWitness 2540 false false 8956 = true := by decide +kernel
private theorem w2540_2 : checkWitness 2540 true false 8947 = true := by decide +kernel
private theorem cases2540 : checkFour 2540 (8956,0,8947,0) = true := by
  simp only [checkFour, w2540_0,w2540_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2540 : Coverage 2540 2541 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2540)
private theorem w2541_0 : checkWitness 2541 false false 68 = true := by decide +kernel
private theorem w2541_2 : checkWitness 2541 true false 68 = true := by decide +kernel
private theorem cases2541 : checkFour 2541 (68,0,68,0) = true := by
  simp only [checkFour, w2541_0,w2541_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2541 : Coverage 2541 2542 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2541)
private theorem w2542_0 : checkWitness 2542 false false 60 = true := by decide +kernel
private theorem w2542_2 : checkWitness 2542 true false 60 = true := by decide +kernel
private theorem cases2542 : checkFour 2542 (60,0,60,0) = true := by
  simp only [checkFour, w2542_0,w2542_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2542 : Coverage 2542 2543 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2542)
private theorem w2543_0 : checkWitness 2543 false false 633 = true := by decide +kernel
private theorem w2543_1 : checkWitness 2543 false true 4725 = true := by decide +kernel
private theorem w2543_2 : checkWitness 2543 true false 633 = true := by decide +kernel
private theorem w2543_3 : checkWitness 2543 true true 4725 = true := by decide +kernel
private theorem cases2543 : checkFour 2543 (633,4725,633,4725) = true := by
  simp only [checkFour, w2543_0,w2543_1,w2543_2,w2543_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2543 : Coverage 2543 2544 := checkList_sound (ws:=[(633,4725,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases2543)
private theorem w2544_0 : checkWitness 2544 false false 8894 = true := by decide +kernel
private theorem w2544_2 : checkWitness 2544 true false 8890 = true := by decide +kernel
private theorem cases2544 : checkFour 2544 (8894,0,8890,0) = true := by
  simp only [checkFour, w2544_0,w2544_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2544 : Coverage 2544 2545 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases2544)
private theorem w2545_0 : checkWitness 2545 false false 60 = true := by decide +kernel
private theorem w2545_2 : checkWitness 2545 true false 60 = true := by decide +kernel
private theorem cases2545 : checkFour 2545 (60,0,60,0) = true := by
  simp only [checkFour, w2545_0,w2545_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2545 : Coverage 2545 2546 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2545)
private theorem w2546_0 : checkWitness 2546 false false 588 = true := by decide +kernel
private theorem w2546_1 : checkWitness 2546 false true 4684 = true := by decide +kernel
private theorem w2546_2 : checkWitness 2546 true false 588 = true := by decide +kernel
private theorem w2546_3 : checkWitness 2546 true true 4684 = true := by decide +kernel
private theorem cases2546 : checkFour 2546 (588,4684,588,4684) = true := by
  simp only [checkFour, w2546_0,w2546_1,w2546_2,w2546_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2546 : Coverage 2546 2547 := checkList_sound (ws:=[(588,4684,588,4684)]) (by simpa only [checkList, Bool.and_true] using cases2546)
private theorem w2547_0 : checkWitness 2547 false false 8929 = true := by decide +kernel
private theorem w2547_2 : checkWitness 2547 true false 8925 = true := by decide +kernel
private theorem cases2547 : checkFour 2547 (8929,0,8925,0) = true := by
  simp only [checkFour, w2547_0,w2547_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2547 : Coverage 2547 2548 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases2547)
private theorem w2548_0 : checkWitness 2548 false false 8964 = true := by decide +kernel
private theorem w2548_2 : checkWitness 2548 true false 8955 = true := by decide +kernel
private theorem cases2548 : checkFour 2548 (8964,0,8955,0) = true := by
  simp only [checkFour, w2548_0,w2548_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2548 : Coverage 2548 2549 := checkList_sound (ws:=[(8964,0,8955,0)]) (by simpa only [checkList, Bool.and_true] using cases2548)
private theorem w2549_0 : checkWitness 2549 false false 78 = true := by decide +kernel
private theorem w2549_2 : checkWitness 2549 true false 78 = true := by decide +kernel
private theorem cases2549 : checkFour 2549 (78,0,78,0) = true := by
  simp only [checkFour, w2549_0,w2549_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2549 : Coverage 2549 2550 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2549)
private theorem w2550_0 : checkWitness 2550 false false 676 = true := by decide +kernel
private theorem w2550_1 : checkWitness 2550 false true 4768 = true := by decide +kernel
private theorem w2550_2 : checkWitness 2550 true false 667 = true := by decide +kernel
private theorem w2550_3 : checkWitness 2550 true true 4759 = true := by decide +kernel
private theorem cases2550 : checkFour 2550 (676,4768,667,4759) = true := by
  simp only [checkFour, w2550_0,w2550_1,w2550_2,w2550_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2550 : Coverage 2550 2551 := checkList_sound (ws:=[(676,4768,667,4759)]) (by simpa only [checkList, Bool.and_true] using cases2550)
private theorem w2551_0 : checkWitness 2551 false false 8925 = true := by decide +kernel
private theorem w2551_2 : checkWitness 2551 true false 8921 = true := by decide +kernel
private theorem cases2551 : checkFour 2551 (8925,0,8921,0) = true := by
  simp only [checkFour, w2551_0,w2551_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2551 : Coverage 2551 2552 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases2551)
private theorem w2552_0 : checkWitness 2552 false false 670 = true := by decide +kernel
private theorem w2552_1 : checkWitness 2552 false true 4762 = true := by decide +kernel
private theorem w2552_2 : checkWitness 2552 true false 661 = true := by decide +kernel
private theorem w2552_3 : checkWitness 2552 true true 4753 = true := by decide +kernel
private theorem cases2552 : checkFour 2552 (670,4762,661,4753) = true := by
  simp only [checkFour, w2552_0,w2552_1,w2552_2,w2552_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2552 : Coverage 2552 2553 := checkList_sound (ws:=[(670,4762,661,4753)]) (by simpa only [checkList, Bool.and_true] using cases2552)
private theorem w2553_0 : checkWitness 2553 false false 8894 = true := by decide +kernel
private theorem w2553_2 : checkWitness 2553 true false 8890 = true := by decide +kernel
private theorem cases2553 : checkFour 2553 (8894,0,8890,0) = true := by
  simp only [checkFour, w2553_0,w2553_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2553 : Coverage 2553 2554 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases2553)
private theorem w2554_0 : checkWitness 2554 false false 66 = true := by decide +kernel
private theorem w2554_2 : checkWitness 2554 true false 66 = true := by decide +kernel
private theorem cases2554 : checkFour 2554 (66,0,66,0) = true := by
  simp only [checkFour, w2554_0,w2554_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2554 : Coverage 2554 2555 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2554)
private theorem w2555_0 : checkWitness 2555 false false 58 = true := by decide +kernel
private theorem w2555_2 : checkWitness 2555 true false 58 = true := by decide +kernel
private theorem cases2555 : checkFour 2555 (58,0,58,0) = true := by
  simp only [checkFour, w2555_0,w2555_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2555 : Coverage 2555 2556 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2555)
private theorem w2556_0 : checkWitness 2556 false false 637 = true := by decide +kernel
private theorem w2556_1 : checkWitness 2556 false true 4725 = true := by decide +kernel
private theorem w2556_2 : checkWitness 2556 true false 637 = true := by decide +kernel
private theorem w2556_3 : checkWitness 2556 true true 4725 = true := by decide +kernel
private theorem cases2556 : checkFour 2556 (637,4725,637,4725) = true := by
  simp only [checkFour, w2556_0,w2556_1,w2556_2,w2556_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2556 : Coverage 2556 2557 := checkList_sound (ws:=[(637,4725,637,4725)]) (by simpa only [checkList, Bool.and_true] using cases2556)
private theorem w2557_0 : checkWitness 2557 false false 8910 = true := by decide +kernel
private theorem w2557_2 : checkWitness 2557 true false 8906 = true := by decide +kernel
private theorem cases2557 : checkFour 2557 (8910,0,8906,0) = true := by
  simp only [checkFour, w2557_0,w2557_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2557 : Coverage 2557 2558 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2557)
private theorem w2558_0 : checkWitness 2558 false false 8906 = true := by decide +kernel
private theorem w2558_2 : checkWitness 2558 true false 8902 = true := by decide +kernel
private theorem cases2558 : checkFour 2558 (8906,0,8902,0) = true := by
  simp only [checkFour, w2558_0,w2558_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2558 : Coverage 2558 2559 := checkList_sound (ws:=[(8906,0,8902,0)]) (by simpa only [checkList, Bool.and_true] using cases2558)
private theorem w2559_0 : checkWitness 2559 false false 72 = true := by decide +kernel
private theorem w2559_2 : checkWitness 2559 true false 72 = true := by decide +kernel
private theorem cases2559 : checkFour 2559 (72,0,72,0) = true := by
  simp only [checkFour, w2559_0,w2559_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2559 : Coverage 2559 2560 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2559)
theorem cover2528 : Coverage 2528 2560 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2528 one2529) (Coverage.join one2530 one2531)) (Coverage.join (Coverage.join one2532 one2533) (Coverage.join one2534 one2535))) (Coverage.join (Coverage.join (Coverage.join one2536 one2537) (Coverage.join one2538 one2539)) (Coverage.join (Coverage.join one2540 one2541) (Coverage.join one2542 one2543)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2544 one2545) (Coverage.join one2546 one2547)) (Coverage.join (Coverage.join one2548 one2549) (Coverage.join one2550 one2551))) (Coverage.join (Coverage.join (Coverage.join one2552 one2553) (Coverage.join one2554 one2555)) (Coverage.join (Coverage.join one2556 one2557) (Coverage.join one2558 one2559)))))
end NF180PA.Symbolic
