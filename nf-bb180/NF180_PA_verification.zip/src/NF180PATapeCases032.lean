import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1024_0 : checkWitness 1024 false false 609 = true := by decide +kernel
private theorem w1024_1 : checkWitness 1024 false true 4701 = true := by decide +kernel
private theorem w1024_2 : checkWitness 1024 true false 609 = true := by decide +kernel
private theorem w1024_3 : checkWitness 1024 true true 4701 = true := by decide +kernel
private theorem cases1024 : checkFour 1024 (609,4701,609,4701) = true := by
  simp only [checkFour, w1024_0,w1024_1,w1024_2,w1024_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1024 : Coverage 1024 1025 := checkList_sound (ws:=[(609,4701,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases1024)
private theorem w1025_0 : checkWitness 1025 false false 8870 = true := by decide +kernel
private theorem w1025_2 : checkWitness 1025 true false 8866 = true := by decide +kernel
private theorem cases1025 : checkFour 1025 (8870,0,8866,0) = true := by
  simp only [checkFour, w1025_0,w1025_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1025 : Coverage 1025 1026 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases1025)
private theorem w1026_0 : checkWitness 1026 false false 82 = true := by decide +kernel
private theorem w1026_2 : checkWitness 1026 true false 82 = true := by decide +kernel
private theorem cases1026 : checkFour 1026 (82,0,82,0) = true := by
  simp only [checkFour, w1026_0,w1026_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1026 : Coverage 1026 1027 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1026)
private theorem w1027_0 : checkWitness 1027 false false 564 = true := by decide +kernel
private theorem w1027_1 : checkWitness 1027 false true 4660 = true := by decide +kernel
private theorem w1027_2 : checkWitness 1027 true false 564 = true := by decide +kernel
private theorem w1027_3 : checkWitness 1027 true true 4660 = true := by decide +kernel
private theorem cases1027 : checkFour 1027 (564,4660,564,4660) = true := by
  simp only [checkFour, w1027_0,w1027_1,w1027_2,w1027_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1027 : Coverage 1027 1028 := checkList_sound (ws:=[(564,4660,564,4660)]) (by simpa only [checkList, Bool.and_true] using cases1027)
private theorem w1028_0 : checkWitness 1028 false false 8905 = true := by decide +kernel
private theorem w1028_2 : checkWitness 1028 true false 8901 = true := by decide +kernel
private theorem cases1028 : checkFour 1028 (8905,0,8901,0) = true := by
  simp only [checkFour, w1028_0,w1028_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1028 : Coverage 1028 1029 := checkList_sound (ws:=[(8905,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases1028)
private theorem w1029_0 : checkWitness 1029 false false 8940 = true := by decide +kernel
private theorem w1029_2 : checkWitness 1029 true false 8931 = true := by decide +kernel
private theorem cases1029 : checkFour 1029 (8940,0,8931,0) = true := by
  simp only [checkFour, w1029_0,w1029_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1029 : Coverage 1029 1030 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases1029)
private theorem w1030_0 : checkWitness 1030 false false 100 = true := by decide +kernel
private theorem w1030_2 : checkWitness 1030 true false 100 = true := by decide +kernel
private theorem cases1030 : checkFour 1030 (100,0,100,0) = true := by
  simp only [checkFour, w1030_0,w1030_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1030 : Coverage 1030 1031 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1030)
private theorem w1031_0 : checkWitness 1031 false false 652 = true := by decide +kernel
private theorem w1031_1 : checkWitness 1031 false true 4744 = true := by decide +kernel
private theorem w1031_2 : checkWitness 1031 true false 643 = true := by decide +kernel
private theorem w1031_3 : checkWitness 1031 true true 4735 = true := by decide +kernel
private theorem cases1031 : checkFour 1031 (652,4744,643,4735) = true := by
  simp only [checkFour, w1031_0,w1031_1,w1031_2,w1031_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1031 : Coverage 1031 1032 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases1031)
private theorem w1032_0 : checkWitness 1032 false false 8901 = true := by decide +kernel
private theorem w1032_2 : checkWitness 1032 true false 8897 = true := by decide +kernel
private theorem cases1032 : checkFour 1032 (8901,0,8897,0) = true := by
  simp only [checkFour, w1032_0,w1032_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1032 : Coverage 1032 1033 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1032)
private theorem w1033_0 : checkWitness 1033 false false 646 = true := by decide +kernel
private theorem w1033_1 : checkWitness 1033 false true 4738 = true := by decide +kernel
private theorem w1033_2 : checkWitness 1033 true false 637 = true := by decide +kernel
private theorem w1033_3 : checkWitness 1033 true true 4729 = true := by decide +kernel
private theorem cases1033 : checkFour 1033 (646,4738,637,4729) = true := by
  simp only [checkFour, w1033_0,w1033_1,w1033_2,w1033_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1033 : Coverage 1033 1034 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases1033)
private theorem w1034_0 : checkWitness 1034 false false 8870 = true := by decide +kernel
private theorem w1034_2 : checkWitness 1034 true false 8866 = true := by decide +kernel
private theorem cases1034 : checkFour 1034 (8870,0,8866,0) = true := by
  simp only [checkFour, w1034_0,w1034_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1034 : Coverage 1034 1035 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases1034)
private theorem w1035_0 : checkWitness 1035 false false 88 = true := by decide +kernel
private theorem w1035_2 : checkWitness 1035 true false 88 = true := by decide +kernel
private theorem cases1035 : checkFour 1035 (88,0,88,0) = true := by
  simp only [checkFour, w1035_0,w1035_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1035 : Coverage 1035 1036 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1035)
private theorem w1036_0 : checkWitness 1036 false false 80 = true := by decide +kernel
private theorem w1036_2 : checkWitness 1036 true false 80 = true := by decide +kernel
private theorem cases1036 : checkFour 1036 (80,0,80,0) = true := by
  simp only [checkFour, w1036_0,w1036_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1036 : Coverage 1036 1037 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1036)
private theorem w1037_0 : checkWitness 1037 false false 613 = true := by decide +kernel
private theorem w1037_1 : checkWitness 1037 false true 4701 = true := by decide +kernel
private theorem w1037_2 : checkWitness 1037 true false 613 = true := by decide +kernel
private theorem w1037_3 : checkWitness 1037 true true 4701 = true := by decide +kernel
private theorem cases1037 : checkFour 1037 (613,4701,613,4701) = true := by
  simp only [checkFour, w1037_0,w1037_1,w1037_2,w1037_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1037 : Coverage 1037 1038 := checkList_sound (ws:=[(613,4701,613,4701)]) (by simpa only [checkList, Bool.and_true] using cases1037)
private theorem w1038_0 : checkWitness 1038 false false 8886 = true := by decide +kernel
private theorem w1038_2 : checkWitness 1038 true false 8882 = true := by decide +kernel
private theorem cases1038 : checkFour 1038 (8886,0,8882,0) = true := by
  simp only [checkFour, w1038_0,w1038_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1038 : Coverage 1038 1039 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases1038)
private theorem w1039_0 : checkWitness 1039 false false 8882 = true := by decide +kernel
private theorem w1039_2 : checkWitness 1039 true false 8878 = true := by decide +kernel
private theorem cases1039 : checkFour 1039 (8882,0,8878,0) = true := by
  simp only [checkFour, w1039_0,w1039_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1039 : Coverage 1039 1040 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases1039)
private theorem w1040_0 : checkWitness 1040 false false 94 = true := by decide +kernel
private theorem w1040_2 : checkWitness 1040 true false 94 = true := by decide +kernel
private theorem cases1040 : checkFour 1040 (94,0,94,0) = true := by
  simp only [checkFour, w1040_0,w1040_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1040 : Coverage 1040 1041 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1040)
private theorem w1041_0 : checkWitness 1041 false false 8906 = true := by decide +kernel
private theorem w1041_2 : checkWitness 1041 true false 8902 = true := by decide +kernel
private theorem cases1041 : checkFour 1041 (8906,0,8902,0) = true := by
  simp only [checkFour, w1041_0,w1041_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1041 : Coverage 1041 1042 := checkList_sound (ws:=[(8906,0,8902,0)]) (by simpa only [checkList, Bool.and_true] using cases1041)
private theorem w1042_0 : checkWitness 1042 false false 674 = true := by decide +kernel
private theorem w1042_1 : checkWitness 1042 false true 4770 = true := by decide +kernel
private theorem w1042_2 : checkWitness 1042 true false 674 = true := by decide +kernel
private theorem w1042_3 : checkWitness 1042 true true 4770 = true := by decide +kernel
private theorem cases1042 : checkFour 1042 (674,4770,674,4770) = true := by
  simp only [checkFour, w1042_0,w1042_1,w1042_2,w1042_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1042 : Coverage 1042 1043 := checkList_sound (ws:=[(674,4770,674,4770)]) (by simpa only [checkList, Bool.and_true] using cases1042)
private theorem w1043_0 : checkWitness 1043 false false 8938 = true := by decide +kernel
private theorem w1043_2 : checkWitness 1043 true false 8929 = true := by decide +kernel
private theorem cases1043 : checkFour 1043 (8938,0,8929,0) = true := by
  simp only [checkFour, w1043_0,w1043_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1043 : Coverage 1043 1044 := checkList_sound (ws:=[(8938,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases1043)
private theorem w1044_0 : checkWitness 1044 false false 72 = true := by decide +kernel
private theorem w1044_2 : checkWitness 1044 true false 72 = true := by decide +kernel
private theorem cases1044 : checkFour 1044 (72,0,72,0) = true := by
  simp only [checkFour, w1044_0,w1044_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1044 : Coverage 1044 1045 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases1044)
private theorem w1045_0 : checkWitness 1045 false false 520 = true := by decide +kernel
private theorem w1045_1 : checkWitness 1045 false true 4616 = true := by decide +kernel
private theorem w1045_2 : checkWitness 1045 true false 520 = true := by decide +kernel
private theorem w1045_3 : checkWitness 1045 true true 4616 = true := by decide +kernel
private theorem cases1045 : checkFour 1045 (520,4616,520,4616) = true := by
  simp only [checkFour, w1045_0,w1045_1,w1045_2,w1045_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1045 : Coverage 1045 1046 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases1045)
private theorem w1046_0 : checkWitness 1046 false false 8878 = true := by decide +kernel
private theorem w1046_2 : checkWitness 1046 true false 8874 = true := by decide +kernel
private theorem cases1046 : checkFour 1046 (8878,0,8874,0) = true := by
  simp only [checkFour, w1046_0,w1046_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1046 : Coverage 1046 1047 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases1046)
private theorem w1047_0 : checkWitness 1047 false false 74 = true := by decide +kernel
private theorem w1047_2 : checkWitness 1047 true false 74 = true := by decide +kernel
private theorem cases1047 : checkFour 1047 (74,0,74,0) = true := by
  simp only [checkFour, w1047_0,w1047_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1047 : Coverage 1047 1048 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1047)
private theorem w1048_0 : checkWitness 1048 false false 558 = true := by decide +kernel
private theorem w1048_1 : checkWitness 1048 false true 4654 = true := by decide +kernel
private theorem w1048_2 : checkWitness 1048 true false 558 = true := by decide +kernel
private theorem w1048_3 : checkWitness 1048 true true 4654 = true := by decide +kernel
private theorem cases1048 : checkFour 1048 (558,4654,558,4654) = true := by
  simp only [checkFour, w1048_0,w1048_1,w1048_2,w1048_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1048 : Coverage 1048 1049 := checkList_sound (ws:=[(558,4654,558,4654)]) (by simpa only [checkList, Bool.and_true] using cases1048)
private theorem w1049_0 : checkWitness 1049 false false 8899 = true := by decide +kernel
private theorem w1049_2 : checkWitness 1049 true false 8895 = true := by decide +kernel
private theorem cases1049 : checkFour 1049 (8899,0,8895,0) = true := by
  simp only [checkFour, w1049_0,w1049_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1049 : Coverage 1049 1050 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases1049)
private theorem w1050_0 : checkWitness 1050 false false 8934 = true := by decide +kernel
private theorem w1050_2 : checkWitness 1050 true false 8925 = true := by decide +kernel
private theorem cases1050 : checkFour 1050 (8934,0,8925,0) = true := by
  simp only [checkFour, w1050_0,w1050_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1050 : Coverage 1050 1051 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases1050)
private theorem w1051_0 : checkWitness 1051 false false 98 = true := by decide +kernel
private theorem w1051_2 : checkWitness 1051 true false 98 = true := by decide +kernel
private theorem cases1051 : checkFour 1051 (98,0,98,0) = true := by
  simp only [checkFour, w1051_0,w1051_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1051 : Coverage 1051 1052 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1051)
private theorem w1052_0 : checkWitness 1052 false false 646 = true := by decide +kernel
private theorem w1052_1 : checkWitness 1052 false true 4738 = true := by decide +kernel
private theorem w1052_2 : checkWitness 1052 true false 637 = true := by decide +kernel
private theorem w1052_3 : checkWitness 1052 true true 4729 = true := by decide +kernel
private theorem cases1052 : checkFour 1052 (646,4738,637,4729) = true := by
  simp only [checkFour, w1052_0,w1052_1,w1052_2,w1052_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1052 : Coverage 1052 1053 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases1052)
private theorem w1053_0 : checkWitness 1053 false false 8895 = true := by decide +kernel
private theorem w1053_2 : checkWitness 1053 true false 8891 = true := by decide +kernel
private theorem cases1053 : checkFour 1053 (8895,0,8891,0) = true := by
  simp only [checkFour, w1053_0,w1053_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1053 : Coverage 1053 1054 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1053)
private theorem w1054_0 : checkWitness 1054 false false 640 = true := by decide +kernel
private theorem w1054_1 : checkWitness 1054 false true 4732 = true := by decide +kernel
private theorem w1054_2 : checkWitness 1054 true false 631 = true := by decide +kernel
private theorem w1054_3 : checkWitness 1054 true true 4723 = true := by decide +kernel
private theorem cases1054 : checkFour 1054 (640,4732,631,4723) = true := by
  simp only [checkFour, w1054_0,w1054_1,w1054_2,w1054_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1054 : Coverage 1054 1055 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases1054)
private theorem w1055_0 : checkWitness 1055 false false 8864 = true := by decide +kernel
private theorem w1055_2 : checkWitness 1055 true false 8860 = true := by decide +kernel
private theorem cases1055 : checkFour 1055 (8864,0,8860,0) = true := by
  simp only [checkFour, w1055_0,w1055_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1055 : Coverage 1055 1056 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases1055)
theorem cover1024 : Coverage 1024 1056 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1024 one1025) (Coverage.join one1026 one1027)) (Coverage.join (Coverage.join one1028 one1029) (Coverage.join one1030 one1031))) (Coverage.join (Coverage.join (Coverage.join one1032 one1033) (Coverage.join one1034 one1035)) (Coverage.join (Coverage.join one1036 one1037) (Coverage.join one1038 one1039)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1040 one1041) (Coverage.join one1042 one1043)) (Coverage.join (Coverage.join one1044 one1045) (Coverage.join one1046 one1047))) (Coverage.join (Coverage.join (Coverage.join one1048 one1049) (Coverage.join one1050 one1051)) (Coverage.join (Coverage.join one1052 one1053) (Coverage.join one1054 one1055)))))
end NF180PA.Symbolic
