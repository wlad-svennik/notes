import NF180PATapeFinite

namespace NF180PA.Clock

def conflict : List Bool → List Bool → Bool
  | x::xs, y::ys => if x=y then conflict xs ys else true
  | _, _ => false

/-- Once two finite prefixes disagree, extending either ray cannot make them equal. -/
theorem separated {X : Type} (put : Bool → X → X)
    (disjoint : ∀ x y, put false x ≠ put true y)
    (injective : ∀ b x y, put b x = put b y → x=y)
    {a b : List Bool} (h : conflict a b=true) (x y : X) :
    a.foldr put x ≠ b.foldr put y := by
  induction a generalizing b with
  | nil => simp [conflict] at h
  | cons u us ih =>
    cases b with
    | nil => simp [conflict] at h
    | cons v vs =>
      by_cases same : u=v
      · subst v
        intro eq
        exact ih (by simpa [conflict] using h) (injective u _ _ eq)
      · cases u <;> cases v <;> simp_all [List.foldr,Ne.symm]

open NF180PA.Symbolic
open Blank180.Data (addressBits)

def branchConflict (p : Nat) (z : Bool) : Bool :=
  expectedHalt p z || conflict (addressBits p) (addressBits (nextPc p z))

set_option maxRecDepth 30000
set_option maxHeartbeats 0

def block (lo : Nat) : Nat → Bool
  | 0 => true
  | n+1 => branchConflict lo false && branchConflict lo true && block (lo+1) n
termination_by n => n

def Covers (lo hi : Nat) : Prop :=
  ∀ p, lo≤p → p<hi → ∀ z, branchConflict p z=true

theorem block_sound {lo n : Nat} (h : block lo n = true) : Covers lo (lo+n) := by
  induction n generalizing lo with
  | zero => intro p a b; omega
  | succ n ih =>
    simp only [block,Bool.and_eq_true] at h
    intro p lower upper z
    by_cases atStart : p=lo
    · subst p; cases z <;> first | exact h.1.1 | exact h.1.2
    · exact ih h.2 p (by omega) (by omega) z

theorem Covers.join {a b c : Nat} (l : Covers a b) (r : Covers b c) : Covers a c := by
  intro p hp hq z
  by_cases mid : p<b
  · exact l p hp mid z
  · exact r p (by omega) hq z

private theorem part0 : Covers 0 32 := block_sound (lo:=0) (n:=32) (by decide +kernel)
private theorem part32 : Covers 32 64 := block_sound (lo:=32) (n:=32) (by decide +kernel)
private theorem part64 : Covers 64 96 := block_sound (lo:=64) (n:=32) (by decide +kernel)
private theorem part96 : Covers 96 128 := block_sound (lo:=96) (n:=32) (by decide +kernel)
private theorem part128 : Covers 128 160 := block_sound (lo:=128) (n:=32) (by decide +kernel)
private theorem part160 : Covers 160 192 := block_sound (lo:=160) (n:=32) (by decide +kernel)
private theorem part192 : Covers 192 224 := block_sound (lo:=192) (n:=32) (by decide +kernel)
private theorem part224 : Covers 224 256 := block_sound (lo:=224) (n:=32) (by decide +kernel)
private theorem part256 : Covers 256 288 := block_sound (lo:=256) (n:=32) (by decide +kernel)
private theorem part288 : Covers 288 320 := block_sound (lo:=288) (n:=32) (by decide +kernel)
private theorem part320 : Covers 320 352 := block_sound (lo:=320) (n:=32) (by decide +kernel)
private theorem part352 : Covers 352 384 := block_sound (lo:=352) (n:=32) (by decide +kernel)
private theorem part384 : Covers 384 416 := block_sound (lo:=384) (n:=32) (by decide +kernel)
private theorem part416 : Covers 416 448 := block_sound (lo:=416) (n:=32) (by decide +kernel)
private theorem part448 : Covers 448 480 := block_sound (lo:=448) (n:=32) (by decide +kernel)
private theorem part480 : Covers 480 512 := block_sound (lo:=480) (n:=32) (by decide +kernel)
private theorem part512 : Covers 512 544 := block_sound (lo:=512) (n:=32) (by decide +kernel)
private theorem part544 : Covers 544 576 := block_sound (lo:=544) (n:=32) (by decide +kernel)
private theorem part576 : Covers 576 608 := block_sound (lo:=576) (n:=32) (by decide +kernel)
private theorem part608 : Covers 608 640 := block_sound (lo:=608) (n:=32) (by decide +kernel)
private theorem part640 : Covers 640 672 := block_sound (lo:=640) (n:=32) (by decide +kernel)
private theorem part672 : Covers 672 704 := block_sound (lo:=672) (n:=32) (by decide +kernel)
private theorem part704 : Covers 704 736 := block_sound (lo:=704) (n:=32) (by decide +kernel)
private theorem part736 : Covers 736 768 := block_sound (lo:=736) (n:=32) (by decide +kernel)
private theorem part768 : Covers 768 800 := block_sound (lo:=768) (n:=32) (by decide +kernel)
private theorem part800 : Covers 800 832 := block_sound (lo:=800) (n:=32) (by decide +kernel)
private theorem part832 : Covers 832 864 := block_sound (lo:=832) (n:=32) (by decide +kernel)
private theorem part864 : Covers 864 896 := block_sound (lo:=864) (n:=32) (by decide +kernel)
private theorem part896 : Covers 896 928 := block_sound (lo:=896) (n:=32) (by decide +kernel)
private theorem part928 : Covers 928 960 := block_sound (lo:=928) (n:=32) (by decide +kernel)
private theorem part960 : Covers 960 992 := block_sound (lo:=960) (n:=32) (by decide +kernel)
private theorem part992 : Covers 992 1024 := block_sound (lo:=992) (n:=32) (by decide +kernel)
private theorem part1024 : Covers 1024 1056 := block_sound (lo:=1024) (n:=32) (by decide +kernel)
private theorem part1056 : Covers 1056 1088 := block_sound (lo:=1056) (n:=32) (by decide +kernel)
private theorem part1088 : Covers 1088 1120 := block_sound (lo:=1088) (n:=32) (by decide +kernel)
private theorem part1120 : Covers 1120 1152 := block_sound (lo:=1120) (n:=32) (by decide +kernel)
private theorem part1152 : Covers 1152 1184 := block_sound (lo:=1152) (n:=32) (by decide +kernel)
private theorem part1184 : Covers 1184 1216 := block_sound (lo:=1184) (n:=32) (by decide +kernel)
private theorem part1216 : Covers 1216 1248 := block_sound (lo:=1216) (n:=32) (by decide +kernel)
private theorem part1248 : Covers 1248 1280 := block_sound (lo:=1248) (n:=32) (by decide +kernel)
private theorem part1280 : Covers 1280 1312 := block_sound (lo:=1280) (n:=32) (by decide +kernel)
private theorem part1312 : Covers 1312 1344 := block_sound (lo:=1312) (n:=32) (by decide +kernel)
private theorem part1344 : Covers 1344 1376 := block_sound (lo:=1344) (n:=32) (by decide +kernel)
private theorem part1376 : Covers 1376 1408 := block_sound (lo:=1376) (n:=32) (by decide +kernel)
private theorem part1408 : Covers 1408 1440 := block_sound (lo:=1408) (n:=32) (by decide +kernel)
private theorem part1440 : Covers 1440 1472 := block_sound (lo:=1440) (n:=32) (by decide +kernel)
private theorem part1472 : Covers 1472 1504 := block_sound (lo:=1472) (n:=32) (by decide +kernel)
private theorem part1504 : Covers 1504 1536 := block_sound (lo:=1504) (n:=32) (by decide +kernel)
private theorem part1536 : Covers 1536 1568 := block_sound (lo:=1536) (n:=32) (by decide +kernel)
private theorem part1568 : Covers 1568 1600 := block_sound (lo:=1568) (n:=32) (by decide +kernel)
private theorem part1600 : Covers 1600 1632 := block_sound (lo:=1600) (n:=32) (by decide +kernel)
private theorem part1632 : Covers 1632 1664 := block_sound (lo:=1632) (n:=32) (by decide +kernel)
private theorem part1664 : Covers 1664 1696 := block_sound (lo:=1664) (n:=32) (by decide +kernel)
private theorem part1696 : Covers 1696 1728 := block_sound (lo:=1696) (n:=32) (by decide +kernel)
private theorem part1728 : Covers 1728 1760 := block_sound (lo:=1728) (n:=32) (by decide +kernel)
private theorem part1760 : Covers 1760 1792 := block_sound (lo:=1760) (n:=32) (by decide +kernel)
private theorem part1792 : Covers 1792 1824 := block_sound (lo:=1792) (n:=32) (by decide +kernel)
private theorem part1824 : Covers 1824 1856 := block_sound (lo:=1824) (n:=32) (by decide +kernel)
private theorem part1856 : Covers 1856 1888 := block_sound (lo:=1856) (n:=32) (by decide +kernel)
private theorem part1888 : Covers 1888 1920 := block_sound (lo:=1888) (n:=32) (by decide +kernel)
private theorem part1920 : Covers 1920 1952 := block_sound (lo:=1920) (n:=32) (by decide +kernel)
private theorem part1952 : Covers 1952 1984 := block_sound (lo:=1952) (n:=32) (by decide +kernel)
private theorem part1984 : Covers 1984 2016 := block_sound (lo:=1984) (n:=32) (by decide +kernel)
private theorem part2016 : Covers 2016 2048 := block_sound (lo:=2016) (n:=32) (by decide +kernel)
private theorem part2048 : Covers 2048 2080 := block_sound (lo:=2048) (n:=32) (by decide +kernel)
private theorem part2080 : Covers 2080 2112 := block_sound (lo:=2080) (n:=32) (by decide +kernel)
private theorem part2112 : Covers 2112 2144 := block_sound (lo:=2112) (n:=32) (by decide +kernel)
private theorem part2144 : Covers 2144 2176 := block_sound (lo:=2144) (n:=32) (by decide +kernel)
private theorem part2176 : Covers 2176 2208 := block_sound (lo:=2176) (n:=32) (by decide +kernel)
private theorem part2208 : Covers 2208 2240 := block_sound (lo:=2208) (n:=32) (by decide +kernel)
private theorem part2240 : Covers 2240 2272 := block_sound (lo:=2240) (n:=32) (by decide +kernel)
private theorem part2272 : Covers 2272 2304 := block_sound (lo:=2272) (n:=32) (by decide +kernel)
private theorem part2304 : Covers 2304 2336 := block_sound (lo:=2304) (n:=32) (by decide +kernel)
private theorem part2336 : Covers 2336 2368 := block_sound (lo:=2336) (n:=32) (by decide +kernel)
private theorem part2368 : Covers 2368 2400 := block_sound (lo:=2368) (n:=32) (by decide +kernel)
private theorem part2400 : Covers 2400 2432 := block_sound (lo:=2400) (n:=32) (by decide +kernel)
private theorem part2432 : Covers 2432 2464 := block_sound (lo:=2432) (n:=32) (by decide +kernel)
private theorem part2464 : Covers 2464 2496 := block_sound (lo:=2464) (n:=32) (by decide +kernel)
private theorem part2496 : Covers 2496 2528 := block_sound (lo:=2496) (n:=32) (by decide +kernel)
private theorem part2528 : Covers 2528 2560 := block_sound (lo:=2528) (n:=32) (by decide +kernel)
private theorem part2560 : Covers 2560 2592 := block_sound (lo:=2560) (n:=32) (by decide +kernel)
private theorem part2592 : Covers 2592 2624 := block_sound (lo:=2592) (n:=32) (by decide +kernel)
private theorem part2624 : Covers 2624 2656 := block_sound (lo:=2624) (n:=32) (by decide +kernel)
private theorem part2656 : Covers 2656 2688 := block_sound (lo:=2656) (n:=32) (by decide +kernel)
private theorem part2688 : Covers 2688 2720 := block_sound (lo:=2688) (n:=32) (by decide +kernel)
private theorem part2720 : Covers 2720 2752 := block_sound (lo:=2720) (n:=32) (by decide +kernel)
private theorem part2752 : Covers 2752 2784 := block_sound (lo:=2752) (n:=32) (by decide +kernel)
private theorem part2784 : Covers 2784 2816 := block_sound (lo:=2784) (n:=32) (by decide +kernel)
private theorem part2816 : Covers 2816 2848 := block_sound (lo:=2816) (n:=32) (by decide +kernel)
private theorem part2848 : Covers 2848 2880 := block_sound (lo:=2848) (n:=32) (by decide +kernel)
private theorem part2880 : Covers 2880 2912 := block_sound (lo:=2880) (n:=32) (by decide +kernel)
private theorem part2912 : Covers 2912 2944 := block_sound (lo:=2912) (n:=32) (by decide +kernel)
private theorem part2944 : Covers 2944 2970 := block_sound (lo:=2944) (n:=26) (by decide +kernel)

theorem all_checked : ∀ p : Fin 2970, ∀ z : Bool, branchConflict p.val z = true :=
  fun p => (Covers.join (Covers.join (Covers.join (Covers.join (Covers.join (Covers.join (Covers.join part0 part32) (Covers.join part64 part96)) (Covers.join (Covers.join part128 part160) (Covers.join part192 part224))) (Covers.join (Covers.join (Covers.join part256 part288) (Covers.join part320 part352)) (Covers.join (Covers.join part384 part416) (Covers.join part448 part480)))) (Covers.join (Covers.join (Covers.join (Covers.join part512 part544) (Covers.join part576 part608)) (Covers.join (Covers.join part640 part672) (Covers.join part704 part736))) (Covers.join (Covers.join (Covers.join part768 part800) (Covers.join part832 part864)) (Covers.join (Covers.join part896 part928) (Covers.join part960 part992))))) (Covers.join (Covers.join (Covers.join (Covers.join (Covers.join part1024 part1056) (Covers.join part1088 part1120)) (Covers.join (Covers.join part1152 part1184) (Covers.join part1216 part1248))) (Covers.join (Covers.join (Covers.join part1280 part1312) (Covers.join part1344 part1376)) (Covers.join (Covers.join part1408 part1440) (Covers.join part1472 part1504)))) (Covers.join (Covers.join (Covers.join (Covers.join part1536 part1568) (Covers.join part1600 part1632)) (Covers.join (Covers.join part1664 part1696) (Covers.join part1728 part1760))) (Covers.join (Covers.join (Covers.join part1792 part1824) (Covers.join part1856 part1888)) (Covers.join (Covers.join part1920 part1952) (Covers.join part1984 part2016)))))) (Covers.join (Covers.join (Covers.join (Covers.join (Covers.join part2048 part2080) (Covers.join part2112 part2144)) (Covers.join (Covers.join part2176 part2208) (Covers.join part2240 part2272))) (Covers.join (Covers.join (Covers.join part2304 part2336) (Covers.join part2368 part2400)) (Covers.join (Covers.join part2432 part2464) (Covers.join part2496 part2528)))) (Covers.join (Covers.join (Covers.join (Covers.join part2560 part2592) (Covers.join part2624 part2656)) (Covers.join (Covers.join part2688 part2720) (Covers.join part2752 part2784))) (Covers.join (Covers.join (Covers.join part2816 part2848) (Covers.join part2880 part2912)) part2944)))) p.val (Nat.zero_le _) p.isLt

theorem live_conflict (p : Fin 2970) (z : Bool) (live : expectedHalt p.val z = false) :
    conflict (addressBits p.val) (addressBits (nextPc p.val z)) = true := by
  simpa [branchConflict,live] using all_checked p z

#print axioms all_checked
#print axioms live_conflict

end NF180PA.Clock
