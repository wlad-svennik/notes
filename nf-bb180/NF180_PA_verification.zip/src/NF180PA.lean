import H192Standard
import ModelTrace
import SourceData


open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM PA192.PhysicalModel

namespace NF180PA

/-- First-order PA formula over the literal 360 rows and the blank initial state. -/
def H180 : ArithmeticSentence := traceF Blank180.Table.machine Blank180.Table.start

/-- Semantics of the sentence for every PA model, including nonstandard times. -/
theorem H180_eval {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    (V ⊧/![] H180) ↔ ∃ t : V, state (rawRun Blank180.Table.machine Blank180.Table.start t) = (180 : V) :=
  traceF_iff_model_run _ _

theorem H180_standard :
    (Nat ⊧/![] H180) ↔ Halts Blank180.Table.machine Blank180.Table.start :=
  traceF_standard _ _

end NF180PA
