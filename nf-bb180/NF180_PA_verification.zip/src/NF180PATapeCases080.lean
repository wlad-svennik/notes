import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2560_0 : checkWitness 2560 false false 8926 = true := by decide +kernel
private theorem w2560_2 : checkWitness 2560 true false 8922 = true := by decide +kernel
private theorem cases2560 : checkFour 2560 (8926,0,8922,0) = true := by
  simp only [checkFour, w2560_0,w2560_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2560 : Coverage 2560 2561 := checkList_sound (ws:=[(8926,0,8922,0)]) (by simpa only [checkList, Bool.and_true] using cases2560)
private theorem w2561_0 : checkWitness 2561 false false 8910 = true := by decide +kernel
private theorem w2561_2 : checkWitness 2561 true false 8906 = true := by decide +kernel
private theorem cases2561 : checkFour 2561 (8910,0,8906,0) = true := by
  simp only [checkFour, w2561_0,w2561_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2561 : Coverage 2561 2562 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2561)
private theorem w2562_0 : checkWitness 2562 false false 538 = true := by decide +kernel
private theorem w2562_1 : checkWitness 2562 false true 4634 = true := by decide +kernel
private theorem w2562_2 : checkWitness 2562 true false 538 = true := by decide +kernel
private theorem w2562_3 : checkWitness 2562 true true 4634 = true := by decide +kernel
private theorem cases2562 : checkFour 2562 (538,4634,538,4634) = true := by
  simp only [checkFour, w2562_0,w2562_1,w2562_2,w2562_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2562 : Coverage 2562 2563 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases2562)
private theorem w2563_0 : checkWitness 2563 false false 8933 = true := by decide +kernel
private theorem w2563_2 : checkWitness 2563 true false 8929 = true := by decide +kernel
private theorem cases2563 : checkFour 2563 (8933,0,8929,0) = true := by
  simp only [checkFour, w2563_0,w2563_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2563 : Coverage 2563 2564 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases2563)
private theorem w2564_0 : checkWitness 2564 false false 664 = true := by decide +kernel
private theorem w2564_1 : checkWitness 2564 false true 4760 = true := by decide +kernel
private theorem w2564_2 : checkWitness 2564 true false 655 = true := by decide +kernel
private theorem w2564_3 : checkWitness 2564 true true 4751 = true := by decide +kernel
private theorem cases2564 : checkFour 2564 (664,4760,655,4751) = true := by
  simp only [checkFour, w2564_0,w2564_1,w2564_2,w2564_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2564 : Coverage 2564 2565 := checkList_sound (ws:=[(664,4760,655,4751)]) (by simpa only [checkList, Bool.and_true] using cases2564)
private theorem w2565_0 : checkWitness 2565 false false 198 = true := by decide +kernel
private theorem w2565_2 : checkWitness 2565 true false 198 = true := by decide +kernel
private theorem cases2565 : checkFour 2565 (198,0,198,0) = true := by
  simp only [checkFour, w2565_0,w2565_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2565 : Coverage 2565 2566 := checkList_sound (ws:=[(198,0,198,0)]) (by simpa only [checkList, Bool.and_true] using cases2565)
private theorem w2566_0 : checkWitness 2566 false false 619 = true := by decide +kernel
private theorem w2566_1 : checkWitness 2566 false true 4707 = true := by decide +kernel
private theorem w2566_2 : checkWitness 2566 true false 619 = true := by decide +kernel
private theorem w2566_3 : checkWitness 2566 true true 4707 = true := by decide +kernel
private theorem cases2566 : checkFour 2566 (619,4707,619,4707) = true := by
  simp only [checkFour, w2566_0,w2566_1,w2566_2,w2566_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2566 : Coverage 2566 2567 := checkList_sound (ws:=[(619,4707,619,4707)]) (by simpa only [checkList, Bool.and_true] using cases2566)
private theorem w2567_0 : checkWitness 2567 false false 8948 = true := by decide +kernel
private theorem w2567_2 : checkWitness 2567 true false 8939 = true := by decide +kernel
private theorem cases2567 : checkFour 2567 (8948,0,8939,0) = true := by
  simp only [checkFour, w2567_0,w2567_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2567 : Coverage 2567 2568 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2567)
private theorem w2568_0 : checkWitness 2568 false false 62 = true := by decide +kernel
private theorem w2568_2 : checkWitness 2568 true false 62 = true := by decide +kernel
private theorem cases2568 : checkFour 2568 (62,0,62,0) = true := by
  simp only [checkFour, w2568_0,w2568_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2568 : Coverage 2568 2569 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2568)
private theorem w2569_0 : checkWitness 2569 false false 54 = true := by decide +kernel
private theorem w2569_2 : checkWitness 2569 true false 54 = true := by decide +kernel
private theorem cases2569 : checkFour 2569 (54,0,54,0) = true := by
  simp only [checkFour, w2569_0,w2569_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2569 : Coverage 2569 2570 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases2569)
private theorem w2570_0 : checkWitness 2570 false false 625 = true := by decide +kernel
private theorem w2570_1 : checkWitness 2570 false true 4717 = true := by decide +kernel
private theorem w2570_2 : checkWitness 2570 true false 625 = true := by decide +kernel
private theorem w2570_3 : checkWitness 2570 true true 4717 = true := by decide +kernel
private theorem cases2570 : checkFour 2570 (625,4717,625,4717) = true := by
  simp only [checkFour, w2570_0,w2570_1,w2570_2,w2570_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2570 : Coverage 2570 2571 := checkList_sound (ws:=[(625,4717,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases2570)
private theorem w2571_0 : checkWitness 2571 false false 8886 = true := by decide +kernel
private theorem w2571_2 : checkWitness 2571 true false 8882 = true := by decide +kernel
private theorem cases2571 : checkFour 2571 (8886,0,8882,0) = true := by
  simp only [checkFour, w2571_0,w2571_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2571 : Coverage 2571 2572 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases2571)
private theorem w2572_0 : checkWitness 2572 false false 54 = true := by decide +kernel
private theorem w2572_2 : checkWitness 2572 true false 54 = true := by decide +kernel
private theorem cases2572 : checkFour 2572 (54,0,54,0) = true := by
  simp only [checkFour, w2572_0,w2572_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2572 : Coverage 2572 2573 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases2572)
private theorem w2573_0 : checkWitness 2573 false false 580 = true := by decide +kernel
private theorem w2573_1 : checkWitness 2573 false true 4676 = true := by decide +kernel
private theorem w2573_2 : checkWitness 2573 true false 580 = true := by decide +kernel
private theorem w2573_3 : checkWitness 2573 true true 4676 = true := by decide +kernel
private theorem cases2573 : checkFour 2573 (580,4676,580,4676) = true := by
  simp only [checkFour, w2573_0,w2573_1,w2573_2,w2573_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2573 : Coverage 2573 2574 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases2573)
private theorem w2574_0 : checkWitness 2574 false false 8921 = true := by decide +kernel
private theorem w2574_2 : checkWitness 2574 true false 8917 = true := by decide +kernel
private theorem cases2574 : checkFour 2574 (8921,0,8917,0) = true := by
  simp only [checkFour, w2574_0,w2574_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2574 : Coverage 2574 2575 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases2574)
private theorem w2575_0 : checkWitness 2575 false false 8956 = true := by decide +kernel
private theorem w2575_2 : checkWitness 2575 true false 8947 = true := by decide +kernel
private theorem cases2575 : checkFour 2575 (8956,0,8947,0) = true := by
  simp only [checkFour, w2575_0,w2575_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2575 : Coverage 2575 2576 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2575)
private theorem w2576_0 : checkWitness 2576 false false 72 = true := by decide +kernel
private theorem w2576_2 : checkWitness 2576 true false 72 = true := by decide +kernel
private theorem cases2576 : checkFour 2576 (72,0,72,0) = true := by
  simp only [checkFour, w2576_0,w2576_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2576 : Coverage 2576 2577 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2576)
private theorem w2577_0 : checkWitness 2577 false false 668 = true := by decide +kernel
private theorem w2577_1 : checkWitness 2577 false true 4760 = true := by decide +kernel
private theorem w2577_2 : checkWitness 2577 true false 659 = true := by decide +kernel
private theorem w2577_3 : checkWitness 2577 true true 4751 = true := by decide +kernel
private theorem cases2577 : checkFour 2577 (668,4760,659,4751) = true := by
  simp only [checkFour, w2577_0,w2577_1,w2577_2,w2577_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2577 : Coverage 2577 2578 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases2577)
private theorem w2578_0 : checkWitness 2578 false false 8917 = true := by decide +kernel
private theorem w2578_2 : checkWitness 2578 true false 8913 = true := by decide +kernel
private theorem cases2578 : checkFour 2578 (8917,0,8913,0) = true := by
  simp only [checkFour, w2578_0,w2578_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2578 : Coverage 2578 2579 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2578)
private theorem w2579_0 : checkWitness 2579 false false 662 = true := by decide +kernel
private theorem w2579_1 : checkWitness 2579 false true 4754 = true := by decide +kernel
private theorem w2579_2 : checkWitness 2579 true false 653 = true := by decide +kernel
private theorem w2579_3 : checkWitness 2579 true true 4745 = true := by decide +kernel
private theorem cases2579 : checkFour 2579 (662,4754,653,4745) = true := by
  simp only [checkFour, w2579_0,w2579_1,w2579_2,w2579_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2579 : Coverage 2579 2580 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases2579)
private theorem w2580_0 : checkWitness 2580 false false 8886 = true := by decide +kernel
private theorem w2580_2 : checkWitness 2580 true false 8882 = true := by decide +kernel
private theorem cases2580 : checkFour 2580 (8886,0,8882,0) = true := by
  simp only [checkFour, w2580_0,w2580_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2580 : Coverage 2580 2581 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases2580)
private theorem w2581_0 : checkWitness 2581 false false 60 = true := by decide +kernel
private theorem w2581_2 : checkWitness 2581 true false 60 = true := by decide +kernel
private theorem cases2581 : checkFour 2581 (60,0,60,0) = true := by
  simp only [checkFour, w2581_0,w2581_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2581 : Coverage 2581 2582 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2581)
private theorem w2582_0 : checkWitness 2582 false false 52 = true := by decide +kernel
private theorem w2582_2 : checkWitness 2582 true false 52 = true := by decide +kernel
private theorem cases2582 : checkFour 2582 (52,0,52,0) = true := by
  simp only [checkFour, w2582_0,w2582_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2582 : Coverage 2582 2583 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2582)
private theorem w2583_0 : checkWitness 2583 false false 629 = true := by decide +kernel
private theorem w2583_1 : checkWitness 2583 false true 4717 = true := by decide +kernel
private theorem w2583_2 : checkWitness 2583 true false 629 = true := by decide +kernel
private theorem w2583_3 : checkWitness 2583 true true 4717 = true := by decide +kernel
private theorem cases2583 : checkFour 2583 (629,4717,629,4717) = true := by
  simp only [checkFour, w2583_0,w2583_1,w2583_2,w2583_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2583 : Coverage 2583 2584 := checkList_sound (ws:=[(629,4717,629,4717)]) (by simpa only [checkList, Bool.and_true] using cases2583)
private theorem w2584_0 : checkWitness 2584 false false 8902 = true := by decide +kernel
private theorem w2584_2 : checkWitness 2584 true false 8898 = true := by decide +kernel
private theorem cases2584 : checkFour 2584 (8902,0,8898,0) = true := by
  simp only [checkFour, w2584_0,w2584_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2584 : Coverage 2584 2585 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases2584)
private theorem w2585_0 : checkWitness 2585 false false 8898 = true := by decide +kernel
private theorem w2585_2 : checkWitness 2585 true false 8894 = true := by decide +kernel
private theorem cases2585 : checkFour 2585 (8898,0,8894,0) = true := by
  simp only [checkFour, w2585_0,w2585_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2585 : Coverage 2585 2586 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2585)
private theorem w2586_0 : checkWitness 2586 false false 66 = true := by decide +kernel
private theorem w2586_2 : checkWitness 2586 true false 66 = true := by decide +kernel
private theorem cases2586 : checkFour 2586 (66,0,66,0) = true := by
  simp only [checkFour, w2586_0,w2586_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2586 : Coverage 2586 2587 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2586)
private theorem w2587_0 : checkWitness 2587 false false 8930 = true := by decide +kernel
private theorem w2587_2 : checkWitness 2587 true false 8926 = true := by decide +kernel
private theorem cases2587 : checkFour 2587 (8930,0,8926,0) = true := by
  simp only [checkFour, w2587_0,w2587_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2587 : Coverage 2587 2588 := checkList_sound (ws:=[(8930,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases2587)
private theorem w2588_0 : checkWitness 2588 false false 698 = true := by decide +kernel
private theorem w2588_1 : checkWitness 2588 false true 4794 = true := by decide +kernel
private theorem w2588_2 : checkWitness 2588 true false 698 = true := by decide +kernel
private theorem w2588_3 : checkWitness 2588 true true 4794 = true := by decide +kernel
private theorem cases2588 : checkFour 2588 (698,4794,698,4794) = true := by
  simp only [checkFour, w2588_0,w2588_1,w2588_2,w2588_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2588 : Coverage 2588 2589 := checkList_sound (ws:=[(698,4794,698,4794)]) (by simpa only [checkList, Bool.and_true] using cases2588)
private theorem w2589_0 : checkWitness 2589 false false 8986 = true := by decide +kernel
private theorem w2589_2 : checkWitness 2589 true false 8977 = true := by decide +kernel
private theorem cases2589 : checkFour 2589 (8986,0,8977,0) = true := by
  simp only [checkFour, w2589_0,w2589_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2589 : Coverage 2589 2590 := checkList_sound (ws:=[(8986,0,8977,0)]) (by simpa only [checkList, Bool.and_true] using cases2589)
private theorem w2590_0 : checkWitness 2590 false false 48 = true := by decide +kernel
private theorem w2590_2 : checkWitness 2590 true false 48 = true := by decide +kernel
private theorem cases2590 : checkFour 2590 (48,0,48,0) = true := by
  simp only [checkFour, w2590_0,w2590_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2590 : Coverage 2590 2591 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2590)
private theorem w2591_0 : checkWitness 2591 false false 568 = true := by decide +kernel
private theorem w2591_1 : checkWitness 2591 false true 4664 = true := by decide +kernel
private theorem w2591_2 : checkWitness 2591 true false 568 = true := by decide +kernel
private theorem w2591_3 : checkWitness 2591 true true 4664 = true := by decide +kernel
private theorem cases2591 : checkFour 2591 (568,4664,568,4664) = true := by
  simp only [checkFour, w2591_0,w2591_1,w2591_2,w2591_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2591 : Coverage 2591 2592 := checkList_sound (ws:=[(568,4664,568,4664)]) (by simpa only [checkList, Bool.and_true] using cases2591)
theorem cover2560 : Coverage 2560 2592 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2560 one2561) (Coverage.join one2562 one2563)) (Coverage.join (Coverage.join one2564 one2565) (Coverage.join one2566 one2567))) (Coverage.join (Coverage.join (Coverage.join one2568 one2569) (Coverage.join one2570 one2571)) (Coverage.join (Coverage.join one2572 one2573) (Coverage.join one2574 one2575)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2576 one2577) (Coverage.join one2578 one2579)) (Coverage.join (Coverage.join one2580 one2581) (Coverage.join one2582 one2583))) (Coverage.join (Coverage.join (Coverage.join one2584 one2585) (Coverage.join one2586 one2587)) (Coverage.join (Coverage.join one2588 one2589) (Coverage.join one2590 one2591)))))
end NF180PA.Symbolic
