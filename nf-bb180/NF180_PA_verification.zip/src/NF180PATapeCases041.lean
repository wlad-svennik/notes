import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1312_0 : checkWitness 1312 false false 106 = true := by decide +kernel
private theorem w1312_2 : checkWitness 1312 true false 106 = true := by decide +kernel
private theorem cases1312 : checkFour 1312 (106,0,106,0) = true := by
  simp only [checkFour, w1312_0,w1312_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1312 : Coverage 1312 1313 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1312)
private theorem w1313_0 : checkWitness 1313 false false 620 = true := by decide +kernel
private theorem w1313_1 : checkWitness 1313 false true 4712 = true := by decide +kernel
private theorem w1313_2 : checkWitness 1313 true false 611 = true := by decide +kernel
private theorem w1313_3 : checkWitness 1313 true true 4703 = true := by decide +kernel
private theorem cases1313 : checkFour 1313 (620,4712,611,4703) = true := by
  simp only [checkFour, w1313_0,w1313_1,w1313_2,w1313_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1313 : Coverage 1313 1314 := checkList_sound (ws:=[(620,4712,611,4703)]) (by simpa only [checkList, Bool.and_true] using cases1313)
private theorem w1314_0 : checkWitness 1314 false false 8869 = true := by decide +kernel
private theorem w1314_2 : checkWitness 1314 true false 8865 = true := by decide +kernel
private theorem cases1314 : checkFour 1314 (8869,0,8865,0) = true := by
  simp only [checkFour, w1314_0,w1314_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1314 : Coverage 1314 1315 := checkList_sound (ws:=[(8869,0,8865,0)]) (by simpa only [checkList, Bool.and_true] using cases1314)
private theorem w1315_0 : checkWitness 1315 false false 614 = true := by decide +kernel
private theorem w1315_1 : checkWitness 1315 false true 4706 = true := by decide +kernel
private theorem w1315_2 : checkWitness 1315 true false 605 = true := by decide +kernel
private theorem w1315_3 : checkWitness 1315 true true 4697 = true := by decide +kernel
private theorem cases1315 : checkFour 1315 (614,4706,605,4697) = true := by
  simp only [checkFour, w1315_0,w1315_1,w1315_2,w1315_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1315 : Coverage 1315 1316 := checkList_sound (ws:=[(614,4706,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases1315)
private theorem w1316_0 : checkWitness 1316 false false 8838 = true := by decide +kernel
private theorem w1316_2 : checkWitness 1316 true false 8834 = true := by decide +kernel
private theorem cases1316 : checkFour 1316 (8838,0,8834,0) = true := by
  simp only [checkFour, w1316_0,w1316_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1316 : Coverage 1316 1317 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1316)
private theorem w1317_0 : checkWitness 1317 false false 94 = true := by decide +kernel
private theorem w1317_2 : checkWitness 1317 true false 94 = true := by decide +kernel
private theorem cases1317 : checkFour 1317 (94,0,94,0) = true := by
  simp only [checkFour, w1317_0,w1317_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1317 : Coverage 1317 1318 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1317)
private theorem w1318_0 : checkWitness 1318 false false 86 = true := by decide +kernel
private theorem w1318_2 : checkWitness 1318 true false 86 = true := by decide +kernel
private theorem cases1318 : checkFour 1318 (86,0,86,0) = true := by
  simp only [checkFour, w1318_0,w1318_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1318 : Coverage 1318 1319 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1318)
private theorem w1319_0 : checkWitness 1319 false false 579 = true := by decide +kernel
private theorem w1319_1 : checkWitness 1319 false true 4663 = true := by decide +kernel
private theorem w1319_2 : checkWitness 1319 true false 579 = true := by decide +kernel
private theorem w1319_3 : checkWitness 1319 true true 4663 = true := by decide +kernel
private theorem cases1319 : checkFour 1319 (579,4663,579,4663) = true := by
  simp only [checkFour, w1319_0,w1319_1,w1319_2,w1319_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1319 : Coverage 1319 1320 := checkList_sound (ws:=[(579,4663,579,4663)]) (by simpa only [checkList, Bool.and_true] using cases1319)
private theorem w1320_0 : checkWitness 1320 false false 8832 = true := by decide +kernel
private theorem w1320_2 : checkWitness 1320 true false 8828 = true := by decide +kernel
private theorem cases1320 : checkFour 1320 (8832,0,8828,0) = true := by
  simp only [checkFour, w1320_0,w1320_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1320 : Coverage 1320 1321 := checkList_sound (ws:=[(8832,0,8828,0)]) (by simpa only [checkList, Bool.and_true] using cases1320)
private theorem w1321_0 : checkWitness 1321 false false 86 = true := by decide +kernel
private theorem w1321_2 : checkWitness 1321 true false 86 = true := by decide +kernel
private theorem cases1321 : checkFour 1321 (86,0,86,0) = true := by
  simp only [checkFour, w1321_0,w1321_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1321 : Coverage 1321 1322 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1321)
private theorem w1322_0 : checkWitness 1322 false false 584 = true := by decide +kernel
private theorem w1322_1 : checkWitness 1322 false true 4680 = true := by decide +kernel
private theorem w1322_2 : checkWitness 1322 true false 584 = true := by decide +kernel
private theorem w1322_3 : checkWitness 1322 true true 4680 = true := by decide +kernel
private theorem cases1322 : checkFour 1322 (584,4680,584,4680) = true := by
  simp only [checkFour, w1322_0,w1322_1,w1322_2,w1322_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1322 : Coverage 1322 1323 := checkList_sound (ws:=[(584,4680,584,4680)]) (by simpa only [checkList, Bool.and_true] using cases1322)
private theorem w1323_0 : checkWitness 1323 false false 8900 = true := by decide +kernel
private theorem w1323_2 : checkWitness 1323 true false 8891 = true := by decide +kernel
private theorem cases1323 : checkFour 1323 (8900,0,8891,0) = true := by
  simp only [checkFour, w1323_0,w1323_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1323 : Coverage 1323 1324 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1323)
private theorem w1324_0 : checkWitness 1324 false false 8846 = true := by decide +kernel
private theorem w1324_2 : checkWitness 1324 true false 8842 = true := by decide +kernel
private theorem cases1324 : checkFour 1324 (8846,0,8842,0) = true := by
  simp only [checkFour, w1324_0,w1324_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1324 : Coverage 1324 1325 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1324)
private theorem w1325_0 : checkWitness 1325 false false 94 = true := by decide +kernel
private theorem w1325_2 : checkWitness 1325 true false 94 = true := by decide +kernel
private theorem cases1325 : checkFour 1325 (94,0,94,0) = true := by
  simp only [checkFour, w1325_0,w1325_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1325 : Coverage 1325 1326 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1325)
private theorem w1326_0 : checkWitness 1326 false false 630 = true := by decide +kernel
private theorem w1326_1 : checkWitness 1326 false true 4718 = true := by decide +kernel
private theorem w1326_2 : checkWitness 1326 true false 621 = true := by decide +kernel
private theorem w1326_3 : checkWitness 1326 true true 4709 = true := by decide +kernel
private theorem cases1326 : checkFour 1326 (630,4718,621,4709) = true := by
  simp only [checkFour, w1326_0,w1326_1,w1326_2,w1326_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1326 : Coverage 1326 1327 := checkList_sound (ws:=[(630,4718,621,4709)]) (by simpa only [checkList, Bool.and_true] using cases1326)
private theorem w1327_0 : checkWitness 1327 false false 8888 = true := by decide +kernel
private theorem w1327_2 : checkWitness 1327 true false 8884 = true := by decide +kernel
private theorem cases1327 : checkFour 1327 (8888,0,8884,0) = true := by
  simp only [checkFour, w1327_0,w1327_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1327 : Coverage 1327 1328 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases1327)
private theorem w1328_0 : checkWitness 1328 false false 84 = true := by decide +kernel
private theorem w1328_2 : checkWitness 1328 true false 84 = true := by decide +kernel
private theorem cases1328 : checkFour 1328 (84,0,84,0) = true := by
  simp only [checkFour, w1328_0,w1328_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1328 : Coverage 1328 1329 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1328)
private theorem w1329_0 : checkWitness 1329 false false 684 = true := by decide +kernel
private theorem w1329_1 : checkWitness 1329 false true 4780 = true := by decide +kernel
private theorem w1329_2 : checkWitness 1329 true false 684 = true := by decide +kernel
private theorem w1329_3 : checkWitness 1329 true true 4780 = true := by decide +kernel
private theorem cases1329 : checkFour 1329 (684,4780,684,4780) = true := by
  simp only [checkFour, w1329_0,w1329_1,w1329_2,w1329_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1329 : Coverage 1329 1330 := checkList_sound (ws:=[(684,4780,684,4780)]) (by simpa only [checkList, Bool.and_true] using cases1329)
private theorem w1330_0 : checkWitness 1330 false false 8928 = true := by decide +kernel
private theorem w1330_2 : checkWitness 1330 true false 8919 = true := by decide +kernel
private theorem cases1330 : checkFour 1330 (8928,0,8919,0) = true := by
  simp only [checkFour, w1330_0,w1330_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1330 : Coverage 1330 1331 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases1330)
private theorem w1331_0 : checkWitness 1331 false false 92 = true := by decide +kernel
private theorem w1331_2 : checkWitness 1331 true false 92 = true := by decide +kernel
private theorem cases1331 : checkFour 1331 (92,0,92,0) = true := by
  simp only [checkFour, w1331_0,w1331_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1331 : Coverage 1331 1332 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1331)
private theorem w1332_0 : checkWitness 1332 false false 510 = true := by decide +kernel
private theorem w1332_1 : checkWitness 1332 false true 4606 = true := by decide +kernel
private theorem w1332_2 : checkWitness 1332 true false 510 = true := by decide +kernel
private theorem w1332_3 : checkWitness 1332 true true 4606 = true := by decide +kernel
private theorem cases1332 : checkFour 1332 (510,4606,510,4606) = true := by
  simp only [checkFour, w1332_0,w1332_1,w1332_2,w1332_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1332 : Coverage 1332 1333 := checkList_sound (ws:=[(510,4606,510,4606)]) (by simpa only [checkList, Bool.and_true] using cases1332)
private theorem w1333_0 : checkWitness 1333 false false 8868 = true := by decide +kernel
private theorem w1333_2 : checkWitness 1333 true false 8864 = true := by decide +kernel
private theorem cases1333 : checkFour 1333 (8868,0,8864,0) = true := by
  simp only [checkFour, w1333_0,w1333_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1333 : Coverage 1333 1334 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases1333)
private theorem w1334_0 : checkWitness 1334 false false 94 = true := by decide +kernel
private theorem w1334_2 : checkWitness 1334 true false 94 = true := by decide +kernel
private theorem cases1334 : checkFour 1334 (94,0,94,0) = true := by
  simp only [checkFour, w1334_0,w1334_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1334 : Coverage 1334 1335 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1334)
private theorem w1335_0 : checkWitness 1335 false false 548 = true := by decide +kernel
private theorem w1335_1 : checkWitness 1335 false true 4644 = true := by decide +kernel
private theorem w1335_2 : checkWitness 1335 true false 548 = true := by decide +kernel
private theorem w1335_3 : checkWitness 1335 true true 4644 = true := by decide +kernel
private theorem cases1335 : checkFour 1335 (548,4644,548,4644) = true := by
  simp only [checkFour, w1335_0,w1335_1,w1335_2,w1335_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1335 : Coverage 1335 1336 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases1335)
private theorem w1336_0 : checkWitness 1336 false false 8889 = true := by decide +kernel
private theorem w1336_2 : checkWitness 1336 true false 8885 = true := by decide +kernel
private theorem cases1336 : checkFour 1336 (8889,0,8885,0) = true := by
  simp only [checkFour, w1336_0,w1336_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1336 : Coverage 1336 1337 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1336)
private theorem w1337_0 : checkWitness 1337 false false 8924 = true := by decide +kernel
private theorem w1337_2 : checkWitness 1337 true false 8915 = true := by decide +kernel
private theorem cases1337 : checkFour 1337 (8924,0,8915,0) = true := by
  simp only [checkFour, w1337_0,w1337_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1337 : Coverage 1337 1338 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases1337)
private theorem w1338_0 : checkWitness 1338 false false 118 = true := by decide +kernel
private theorem w1338_2 : checkWitness 1338 true false 118 = true := by decide +kernel
private theorem cases1338 : checkFour 1338 (118,0,118,0) = true := by
  simp only [checkFour, w1338_0,w1338_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1338 : Coverage 1338 1339 := checkList_sound (ws:=[(118,0,118,0)]) (by simpa only [checkList, Bool.and_true] using cases1338)
private theorem w1339_0 : checkWitness 1339 false false 636 = true := by decide +kernel
private theorem w1339_1 : checkWitness 1339 false true 4728 = true := by decide +kernel
private theorem w1339_2 : checkWitness 1339 true false 627 = true := by decide +kernel
private theorem w1339_3 : checkWitness 1339 true true 4719 = true := by decide +kernel
private theorem cases1339 : checkFour 1339 (636,4728,627,4719) = true := by
  simp only [checkFour, w1339_0,w1339_1,w1339_2,w1339_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1339 : Coverage 1339 1340 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases1339)
private theorem w1340_0 : checkWitness 1340 false false 8885 = true := by decide +kernel
private theorem w1340_2 : checkWitness 1340 true false 8881 = true := by decide +kernel
private theorem cases1340 : checkFour 1340 (8885,0,8881,0) = true := by
  simp only [checkFour, w1340_0,w1340_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1340 : Coverage 1340 1341 := checkList_sound (ws:=[(8885,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases1340)
private theorem w1341_0 : checkWitness 1341 false false 630 = true := by decide +kernel
private theorem w1341_1 : checkWitness 1341 false true 4722 = true := by decide +kernel
private theorem w1341_2 : checkWitness 1341 true false 621 = true := by decide +kernel
private theorem w1341_3 : checkWitness 1341 true true 4713 = true := by decide +kernel
private theorem cases1341 : checkFour 1341 (630,4722,621,4713) = true := by
  simp only [checkFour, w1341_0,w1341_1,w1341_2,w1341_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1341 : Coverage 1341 1342 := checkList_sound (ws:=[(630,4722,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases1341)
private theorem w1342_0 : checkWitness 1342 false false 8855 = true := by decide +kernel
private theorem w1342_2 : checkWitness 1342 true false 8851 = true := by decide +kernel
private theorem cases1342 : checkFour 1342 (8855,0,8851,0) = true := by
  simp only [checkFour, w1342_0,w1342_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1342 : Coverage 1342 1343 := checkList_sound (ws:=[(8855,0,8851,0)]) (by simpa only [checkList, Bool.and_true] using cases1342)
private theorem w1343_0 : checkWitness 1343 false false 106 = true := by decide +kernel
private theorem w1343_2 : checkWitness 1343 true false 106 = true := by decide +kernel
private theorem cases1343 : checkFour 1343 (106,0,106,0) = true := by
  simp only [checkFour, w1343_0,w1343_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1343 : Coverage 1343 1344 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1343)
theorem cover1312 : Coverage 1312 1344 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1312 one1313) (Coverage.join one1314 one1315)) (Coverage.join (Coverage.join one1316 one1317) (Coverage.join one1318 one1319))) (Coverage.join (Coverage.join (Coverage.join one1320 one1321) (Coverage.join one1322 one1323)) (Coverage.join (Coverage.join one1324 one1325) (Coverage.join one1326 one1327)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1328 one1329) (Coverage.join one1330 one1331)) (Coverage.join (Coverage.join one1332 one1333) (Coverage.join one1334 one1335))) (Coverage.join (Coverage.join (Coverage.join one1336 one1337) (Coverage.join one1338 one1339)) (Coverage.join (Coverage.join one1340 one1341) (Coverage.join one1342 one1343)))))
end NF180PA.Symbolic
