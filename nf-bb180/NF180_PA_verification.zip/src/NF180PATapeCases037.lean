import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1184_0 : checkWitness 1184 false false 8897 = true := by decide +kernel
private theorem w1184_2 : checkWitness 1184 true false 8893 = true := by decide +kernel
private theorem cases1184 : checkFour 1184 (8897,0,8893,0) = true := by
  simp only [checkFour, w1184_0,w1184_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1184 : Coverage 1184 1185 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases1184)
private theorem w1185_0 : checkWitness 1185 false false 642 = true := by decide +kernel
private theorem w1185_1 : checkWitness 1185 false true 4734 = true := by decide +kernel
private theorem w1185_2 : checkWitness 1185 true false 633 = true := by decide +kernel
private theorem w1185_3 : checkWitness 1185 true true 4725 = true := by decide +kernel
private theorem cases1185 : checkFour 1185 (642,4734,633,4725) = true := by
  simp only [checkFour, w1185_0,w1185_1,w1185_2,w1185_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1185 : Coverage 1185 1186 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases1185)
private theorem w1186_0 : checkWitness 1186 false false 8866 = true := by decide +kernel
private theorem w1186_2 : checkWitness 1186 true false 8862 = true := by decide +kernel
private theorem cases1186 : checkFour 1186 (8866,0,8862,0) = true := by
  simp only [checkFour, w1186_0,w1186_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1186 : Coverage 1186 1187 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases1186)
private theorem w1187_0 : checkWitness 1187 false false 100 = true := by decide +kernel
private theorem w1187_2 : checkWitness 1187 true false 100 = true := by decide +kernel
private theorem cases1187 : checkFour 1187 (100,0,100,0) = true := by
  simp only [checkFour, w1187_0,w1187_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1187 : Coverage 1187 1188 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1187)
private theorem w1188_0 : checkWitness 1188 false false 92 = true := by decide +kernel
private theorem w1188_2 : checkWitness 1188 true false 92 = true := by decide +kernel
private theorem cases1188 : checkFour 1188 (92,0,92,0) = true := by
  simp only [checkFour, w1188_0,w1188_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1188 : Coverage 1188 1189 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1188)
private theorem w1189_0 : checkWitness 1189 false false 607 = true := by decide +kernel
private theorem w1189_1 : checkWitness 1189 false true 4691 = true := by decide +kernel
private theorem w1189_2 : checkWitness 1189 true false 607 = true := by decide +kernel
private theorem w1189_3 : checkWitness 1189 true true 4691 = true := by decide +kernel
private theorem cases1189 : checkFour 1189 (607,4691,607,4691) = true := by
  simp only [checkFour, w1189_0,w1189_1,w1189_2,w1189_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1189 : Coverage 1189 1190 := checkList_sound (ws:=[(607,4691,607,4691)]) (by simpa only [checkList, Bool.and_true] using cases1189)
private theorem w1190_0 : checkWitness 1190 false false 8860 = true := by decide +kernel
private theorem w1190_2 : checkWitness 1190 true false 8856 = true := by decide +kernel
private theorem cases1190 : checkFour 1190 (8860,0,8856,0) = true := by
  simp only [checkFour, w1190_0,w1190_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1190 : Coverage 1190 1191 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases1190)
private theorem w1191_0 : checkWitness 1191 false false 92 = true := by decide +kernel
private theorem w1191_2 : checkWitness 1191 true false 92 = true := by decide +kernel
private theorem cases1191 : checkFour 1191 (92,0,92,0) = true := by
  simp only [checkFour, w1191_0,w1191_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1191 : Coverage 1191 1192 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1191)
private theorem w1192_0 : checkWitness 1192 false false 575 = true := by decide +kernel
private theorem w1192_1 : checkWitness 1192 false true 4671 = true := by decide +kernel
private theorem w1192_2 : checkWitness 1192 true false 575 = true := by decide +kernel
private theorem w1192_3 : checkWitness 1192 true true 4671 = true := by decide +kernel
private theorem cases1192 : checkFour 1192 (575,4671,575,4671) = true := by
  simp only [checkFour, w1192_0,w1192_1,w1192_2,w1192_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1192 : Coverage 1192 1193 := checkList_sound (ws:=[(575,4671,575,4671)]) (by simpa only [checkList, Bool.and_true] using cases1192)
private theorem w1193_0 : checkWitness 1193 false false 8928 = true := by decide +kernel
private theorem w1193_2 : checkWitness 1193 true false 8919 = true := by decide +kernel
private theorem cases1193 : checkFour 1193 (8928,0,8919,0) = true := by
  simp only [checkFour, w1193_0,w1193_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1193 : Coverage 1193 1194 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases1193)
private theorem w1194_0 : checkWitness 1194 false false 8874 = true := by decide +kernel
private theorem w1194_2 : checkWitness 1194 true false 8870 = true := by decide +kernel
private theorem cases1194 : checkFour 1194 (8874,0,8870,0) = true := by
  simp only [checkFour, w1194_0,w1194_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1194 : Coverage 1194 1195 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases1194)
private theorem w1195_0 : checkWitness 1195 false false 100 = true := by decide +kernel
private theorem w1195_2 : checkWitness 1195 true false 100 = true := by decide +kernel
private theorem cases1195 : checkFour 1195 (100,0,100,0) = true := by
  simp only [checkFour, w1195_0,w1195_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1195 : Coverage 1195 1196 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1195)
private theorem w1196_0 : checkWitness 1196 false false 658 = true := by decide +kernel
private theorem w1196_1 : checkWitness 1196 false true 4746 = true := by decide +kernel
private theorem w1196_2 : checkWitness 1196 true false 649 = true := by decide +kernel
private theorem w1196_3 : checkWitness 1196 true true 4737 = true := by decide +kernel
private theorem cases1196 : checkFour 1196 (658,4746,649,4737) = true := by
  simp only [checkFour, w1196_0,w1196_1,w1196_2,w1196_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1196 : Coverage 1196 1197 := checkList_sound (ws:=[(658,4746,649,4737)]) (by simpa only [checkList, Bool.and_true] using cases1196)
private theorem w1197_0 : checkWitness 1197 false false 8893 = true := by decide +kernel
private theorem w1197_2 : checkWitness 1197 true false 8889 = true := by decide +kernel
private theorem cases1197 : checkFour 1197 (8893,0,8889,0) = true := by
  simp only [checkFour, w1197_0,w1197_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1197 : Coverage 1197 1198 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1197)
private theorem w1198_0 : checkWitness 1198 false false 90 = true := by decide +kernel
private theorem w1198_2 : checkWitness 1198 true false 90 = true := by decide +kernel
private theorem cases1198 : checkFour 1198 (90,0,90,0) = true := by
  simp only [checkFour, w1198_0,w1198_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1198 : Coverage 1198 1199 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1198)
private theorem w1199_0 : checkWitness 1199 false false 694 = true := by decide +kernel
private theorem w1199_1 : checkWitness 1199 false true 4790 = true := by decide +kernel
private theorem w1199_2 : checkWitness 1199 true false 694 = true := by decide +kernel
private theorem w1199_3 : checkWitness 1199 true true 4790 = true := by decide +kernel
private theorem cases1199 : checkFour 1199 (694,4790,694,4790) = true := by
  simp only [checkFour, w1199_0,w1199_1,w1199_2,w1199_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1199 : Coverage 1199 1200 := checkList_sound (ws:=[(694,4790,694,4790)]) (by simpa only [checkList, Bool.and_true] using cases1199)
private theorem w1200_0 : checkWitness 1200 false false 8938 = true := by decide +kernel
private theorem w1200_2 : checkWitness 1200 true false 8929 = true := by decide +kernel
private theorem cases1200 : checkFour 1200 (8938,0,8929,0) = true := by
  simp only [checkFour, w1200_0,w1200_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1200 : Coverage 1200 1201 := checkList_sound (ws:=[(8938,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases1200)
private theorem w1201_0 : checkWitness 1201 false false 92 = true := by decide +kernel
private theorem w1201_2 : checkWitness 1201 true false 92 = true := by decide +kernel
private theorem cases1201 : checkFour 1201 (92,0,92,0) = true := by
  simp only [checkFour, w1201_0,w1201_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1201 : Coverage 1201 1202 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1201)
private theorem w1202_0 : checkWitness 1202 false false 520 = true := by decide +kernel
private theorem w1202_1 : checkWitness 1202 false true 4616 = true := by decide +kernel
private theorem w1202_2 : checkWitness 1202 true false 520 = true := by decide +kernel
private theorem w1202_3 : checkWitness 1202 true true 4616 = true := by decide +kernel
private theorem cases1202 : checkFour 1202 (520,4616,520,4616) = true := by
  simp only [checkFour, w1202_0,w1202_1,w1202_2,w1202_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1202 : Coverage 1202 1203 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases1202)
private theorem w1203_0 : checkWitness 1203 false false 8878 = true := by decide +kernel
private theorem w1203_2 : checkWitness 1203 true false 8874 = true := by decide +kernel
private theorem cases1203 : checkFour 1203 (8878,0,8874,0) = true := by
  simp only [checkFour, w1203_0,w1203_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1203 : Coverage 1203 1204 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases1203)
private theorem w1204_0 : checkWitness 1204 false false 94 = true := by decide +kernel
private theorem w1204_2 : checkWitness 1204 true false 94 = true := by decide +kernel
private theorem cases1204 : checkFour 1204 (94,0,94,0) = true := by
  simp only [checkFour, w1204_0,w1204_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1204 : Coverage 1204 1205 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1204)
private theorem w1205_0 : checkWitness 1205 false false 558 = true := by decide +kernel
private theorem w1205_1 : checkWitness 1205 false true 4654 = true := by decide +kernel
private theorem w1205_2 : checkWitness 1205 true false 558 = true := by decide +kernel
private theorem w1205_3 : checkWitness 1205 true true 4654 = true := by decide +kernel
private theorem cases1205 : checkFour 1205 (558,4654,558,4654) = true := by
  simp only [checkFour, w1205_0,w1205_1,w1205_2,w1205_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1205 : Coverage 1205 1206 := checkList_sound (ws:=[(558,4654,558,4654)]) (by simpa only [checkList, Bool.and_true] using cases1205)
private theorem w1206_0 : checkWitness 1206 false false 8899 = true := by decide +kernel
private theorem w1206_2 : checkWitness 1206 true false 8895 = true := by decide +kernel
private theorem cases1206 : checkFour 1206 (8899,0,8895,0) = true := by
  simp only [checkFour, w1206_0,w1206_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1206 : Coverage 1206 1207 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases1206)
private theorem w1207_0 : checkWitness 1207 false false 8934 = true := by decide +kernel
private theorem w1207_2 : checkWitness 1207 true false 8925 = true := by decide +kernel
private theorem cases1207 : checkFour 1207 (8934,0,8925,0) = true := by
  simp only [checkFour, w1207_0,w1207_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1207 : Coverage 1207 1208 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases1207)
private theorem w1208_0 : checkWitness 1208 false false 118 = true := by decide +kernel
private theorem w1208_2 : checkWitness 1208 true false 118 = true := by decide +kernel
private theorem cases1208 : checkFour 1208 (118,0,118,0) = true := by
  simp only [checkFour, w1208_0,w1208_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1208 : Coverage 1208 1209 := checkList_sound (ws:=[(118,0,118,0)]) (by simpa only [checkList, Bool.and_true] using cases1208)
private theorem w1209_0 : checkWitness 1209 false false 646 = true := by decide +kernel
private theorem w1209_1 : checkWitness 1209 false true 4738 = true := by decide +kernel
private theorem w1209_2 : checkWitness 1209 true false 637 = true := by decide +kernel
private theorem w1209_3 : checkWitness 1209 true true 4729 = true := by decide +kernel
private theorem cases1209 : checkFour 1209 (646,4738,637,4729) = true := by
  simp only [checkFour, w1209_0,w1209_1,w1209_2,w1209_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1209 : Coverage 1209 1210 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases1209)
private theorem w1210_0 : checkWitness 1210 false false 8895 = true := by decide +kernel
private theorem w1210_2 : checkWitness 1210 true false 8891 = true := by decide +kernel
private theorem cases1210 : checkFour 1210 (8895,0,8891,0) = true := by
  simp only [checkFour, w1210_0,w1210_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1210 : Coverage 1210 1211 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1210)
private theorem w1211_0 : checkWitness 1211 false false 640 = true := by decide +kernel
private theorem w1211_1 : checkWitness 1211 false true 4732 = true := by decide +kernel
private theorem w1211_2 : checkWitness 1211 true false 631 = true := by decide +kernel
private theorem w1211_3 : checkWitness 1211 true true 4723 = true := by decide +kernel
private theorem cases1211 : checkFour 1211 (640,4732,631,4723) = true := by
  simp only [checkFour, w1211_0,w1211_1,w1211_2,w1211_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1211 : Coverage 1211 1212 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases1211)
private theorem w1212_0 : checkWitness 1212 false false 8864 = true := by decide +kernel
private theorem w1212_2 : checkWitness 1212 true false 8860 = true := by decide +kernel
private theorem cases1212 : checkFour 1212 (8864,0,8860,0) = true := by
  simp only [checkFour, w1212_0,w1212_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1212 : Coverage 1212 1213 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases1212)
private theorem w1213_0 : checkWitness 1213 false false 106 = true := by decide +kernel
private theorem w1213_2 : checkWitness 1213 true false 106 = true := by decide +kernel
private theorem cases1213 : checkFour 1213 (106,0,106,0) = true := by
  simp only [checkFour, w1213_0,w1213_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1213 : Coverage 1213 1214 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1213)
private theorem w1214_0 : checkWitness 1214 false false 98 = true := by decide +kernel
private theorem w1214_2 : checkWitness 1214 true false 98 = true := by decide +kernel
private theorem cases1214 : checkFour 1214 (98,0,98,0) = true := by
  simp only [checkFour, w1214_0,w1214_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1214 : Coverage 1214 1215 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1214)
private theorem w1215_0 : checkWitness 1215 false false 605 = true := by decide +kernel
private theorem w1215_1 : checkWitness 1215 false true 4689 = true := by decide +kernel
private theorem w1215_2 : checkWitness 1215 true false 605 = true := by decide +kernel
private theorem w1215_3 : checkWitness 1215 true true 4689 = true := by decide +kernel
private theorem cases1215 : checkFour 1215 (605,4689,605,4689) = true := by
  simp only [checkFour, w1215_0,w1215_1,w1215_2,w1215_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1215 : Coverage 1215 1216 := checkList_sound (ws:=[(605,4689,605,4689)]) (by simpa only [checkList, Bool.and_true] using cases1215)
theorem cover1184 : Coverage 1184 1216 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1184 one1185) (Coverage.join one1186 one1187)) (Coverage.join (Coverage.join one1188 one1189) (Coverage.join one1190 one1191))) (Coverage.join (Coverage.join (Coverage.join one1192 one1193) (Coverage.join one1194 one1195)) (Coverage.join (Coverage.join one1196 one1197) (Coverage.join one1198 one1199)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1200 one1201) (Coverage.join one1202 one1203)) (Coverage.join (Coverage.join one1204 one1205) (Coverage.join one1206 one1207))) (Coverage.join (Coverage.join (Coverage.join one1208 one1209) (Coverage.join one1210 one1211)) (Coverage.join (Coverage.join one1212 one1213) (Coverage.join one1214 one1215)))))
end NF180PA.Symbolic
