import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w320_0 : checkWitness 320 false false 76 = true := by decide +kernel
private theorem w320_2 : checkWitness 320 true false 76 = true := by decide +kernel
private theorem cases320 : checkFour 320 (76,0,76,0) = true := by
  simp only [checkFour, w320_0,w320_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one320 : Coverage 320 321 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases320)
private theorem w321_0 : checkWitness 321 false false 656 = true := by decide +kernel
private theorem w321_1 : checkWitness 321 false true 4744 = true := by decide +kernel
private theorem w321_2 : checkWitness 321 true false 647 = true := by decide +kernel
private theorem w321_3 : checkWitness 321 true true 4735 = true := by decide +kernel
private theorem cases321 : checkFour 321 (656,4744,647,4735) = true := by
  simp only [checkFour, w321_0,w321_1,w321_2,w321_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one321 : Coverage 321 322 := checkList_sound (ws:=[(656,4744,647,4735)]) (by simpa only [checkList, Bool.and_true] using cases321)
private theorem w322_0 : checkWitness 322 false false 8914 = true := by decide +kernel
private theorem w322_2 : checkWitness 322 true false 8910 = true := by decide +kernel
private theorem cases322 : checkFour 322 (8914,0,8910,0) = true := by
  simp only [checkFour, w322_0,w322_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one322 : Coverage 322 323 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases322)
private theorem w323_0 : checkWitness 323 false false 66 = true := by decide +kernel
private theorem w323_2 : checkWitness 323 true false 66 = true := by decide +kernel
private theorem cases323 : checkFour 323 (66,0,66,0) = true := by
  simp only [checkFour, w323_0,w323_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one323 : Coverage 323 324 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases323)
private theorem w324_0 : checkWitness 324 false false 518 = true := by decide +kernel
private theorem w324_1 : checkWitness 324 false true 4614 = true := by decide +kernel
private theorem w324_2 : checkWitness 324 true false 518 = true := by decide +kernel
private theorem w324_3 : checkWitness 324 true true 4614 = true := by decide +kernel
private theorem cases324 : checkFour 324 (518,4614,518,4614) = true := by
  simp only [checkFour, w324_0,w324_1,w324_2,w324_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one324 : Coverage 324 325 := checkList_sound (ws:=[(518,4614,518,4614)]) (by simpa only [checkList, Bool.and_true] using cases324)
private theorem w325_0 : checkWitness 325 false false 8913 = true := by decide +kernel
private theorem w325_2 : checkWitness 325 true false 8909 = true := by decide +kernel
private theorem cases325 : checkFour 325 (8913,0,8909,0) = true := by
  simp only [checkFour, w325_0,w325_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one325 : Coverage 325 326 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases325)
private theorem w326_0 : checkWitness 326 false false 644 = true := by decide +kernel
private theorem w326_1 : checkWitness 326 false true 4740 = true := by decide +kernel
private theorem w326_2 : checkWitness 326 true false 635 = true := by decide +kernel
private theorem w326_3 : checkWitness 326 true true 4731 = true := by decide +kernel
private theorem cases326 : checkFour 326 (644,4740,635,4731) = true := by
  simp only [checkFour, w326_0,w326_1,w326_2,w326_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one326 : Coverage 326 327 := checkList_sound (ws:=[(644,4740,635,4731)]) (by simpa only [checkList, Bool.and_true] using cases326)
private theorem w327_0 : checkWitness 327 false false 188 = true := by decide +kernel
private theorem w327_2 : checkWitness 327 true false 188 = true := by decide +kernel
private theorem cases327 : checkFour 327 (188,0,188,0) = true := by
  simp only [checkFour, w327_0,w327_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one327 : Coverage 327 328 := checkList_sound (ws:=[(188,0,188,0)]) (by simpa only [checkList, Bool.and_true] using cases327)
private theorem w328_0 : checkWitness 328 false false 599 = true := by decide +kernel
private theorem w328_1 : checkWitness 328 false true 4687 = true := by decide +kernel
private theorem w328_2 : checkWitness 328 true false 599 = true := by decide +kernel
private theorem w328_3 : checkWitness 328 true true 4687 = true := by decide +kernel
private theorem cases328 : checkFour 328 (599,4687,599,4687) = true := by
  simp only [checkFour, w328_0,w328_1,w328_2,w328_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one328 : Coverage 328 329 := checkList_sound (ws:=[(599,4687,599,4687)]) (by simpa only [checkList, Bool.and_true] using cases328)
private theorem w329_0 : checkWitness 329 false false 8928 = true := by decide +kernel
private theorem w329_2 : checkWitness 329 true false 8919 = true := by decide +kernel
private theorem cases329 : checkFour 329 (8928,0,8919,0) = true := by
  simp only [checkFour, w329_0,w329_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one329 : Coverage 329 330 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases329)
private theorem w330_0 : checkWitness 330 false false 72 = true := by decide +kernel
private theorem w330_2 : checkWitness 330 true false 72 = true := by decide +kernel
private theorem cases330 : checkFour 330 (72,0,72,0) = true := by
  simp only [checkFour, w330_0,w330_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one330 : Coverage 330 331 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases330)
private theorem w331_0 : checkWitness 331 false false 64 = true := by decide +kernel
private theorem w331_2 : checkWitness 331 true false 64 = true := by decide +kernel
private theorem cases331 : checkFour 331 (64,0,64,0) = true := by
  simp only [checkFour, w331_0,w331_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one331 : Coverage 331 332 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases331)
private theorem w332_0 : checkWitness 332 false false 605 = true := by decide +kernel
private theorem w332_1 : checkWitness 332 false true 4697 = true := by decide +kernel
private theorem w332_2 : checkWitness 332 true false 605 = true := by decide +kernel
private theorem w332_3 : checkWitness 332 true true 4697 = true := by decide +kernel
private theorem cases332 : checkFour 332 (605,4697,605,4697) = true := by
  simp only [checkFour, w332_0,w332_1,w332_2,w332_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one332 : Coverage 332 333 := checkList_sound (ws:=[(605,4697,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases332)
private theorem w333_0 : checkWitness 333 false false 8866 = true := by decide +kernel
private theorem w333_2 : checkWitness 333 true false 8862 = true := by decide +kernel
private theorem cases333 : checkFour 333 (8866,0,8862,0) = true := by
  simp only [checkFour, w333_0,w333_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one333 : Coverage 333 334 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases333)
private theorem w334_0 : checkWitness 334 false false 64 = true := by decide +kernel
private theorem w334_2 : checkWitness 334 true false 64 = true := by decide +kernel
private theorem cases334 : checkFour 334 (64,0,64,0) = true := by
  simp only [checkFour, w334_0,w334_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one334 : Coverage 334 335 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases334)
private theorem w335_0 : checkWitness 335 false false 560 = true := by decide +kernel
private theorem w335_1 : checkWitness 335 false true 4656 = true := by decide +kernel
private theorem w335_2 : checkWitness 335 true false 560 = true := by decide +kernel
private theorem w335_3 : checkWitness 335 true true 4656 = true := by decide +kernel
private theorem cases335 : checkFour 335 (560,4656,560,4656) = true := by
  simp only [checkFour, w335_0,w335_1,w335_2,w335_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one335 : Coverage 335 336 := checkList_sound (ws:=[(560,4656,560,4656)]) (by simpa only [checkList, Bool.and_true] using cases335)
private theorem w336_0 : checkWitness 336 false false 8901 = true := by decide +kernel
private theorem w336_2 : checkWitness 336 true false 8897 = true := by decide +kernel
private theorem cases336 : checkFour 336 (8901,0,8897,0) = true := by
  simp only [checkFour, w336_0,w336_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one336 : Coverage 336 337 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases336)
private theorem w337_0 : checkWitness 337 false false 8936 = true := by decide +kernel
private theorem w337_2 : checkWitness 337 true false 8927 = true := by decide +kernel
private theorem cases337 : checkFour 337 (8936,0,8927,0) = true := by
  simp only [checkFour, w337_0,w337_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one337 : Coverage 337 338 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases337)
private theorem w338_0 : checkWitness 338 false false 82 = true := by decide +kernel
private theorem w338_2 : checkWitness 338 true false 82 = true := by decide +kernel
private theorem cases338 : checkFour 338 (82,0,82,0) = true := by
  simp only [checkFour, w338_0,w338_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one338 : Coverage 338 339 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases338)
private theorem w339_0 : checkWitness 339 false false 648 = true := by decide +kernel
private theorem w339_1 : checkWitness 339 false true 4740 = true := by decide +kernel
private theorem w339_2 : checkWitness 339 true false 639 = true := by decide +kernel
private theorem w339_3 : checkWitness 339 true true 4731 = true := by decide +kernel
private theorem cases339 : checkFour 339 (648,4740,639,4731) = true := by
  simp only [checkFour, w339_0,w339_1,w339_2,w339_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one339 : Coverage 339 340 := checkList_sound (ws:=[(648,4740,639,4731)]) (by simpa only [checkList, Bool.and_true] using cases339)
private theorem w340_0 : checkWitness 340 false false 8897 = true := by decide +kernel
private theorem w340_2 : checkWitness 340 true false 8893 = true := by decide +kernel
private theorem cases340 : checkFour 340 (8897,0,8893,0) = true := by
  simp only [checkFour, w340_0,w340_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one340 : Coverage 340 341 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases340)
private theorem w341_0 : checkWitness 341 false false 642 = true := by decide +kernel
private theorem w341_1 : checkWitness 341 false true 4734 = true := by decide +kernel
private theorem w341_2 : checkWitness 341 true false 633 = true := by decide +kernel
private theorem w341_3 : checkWitness 341 true true 4725 = true := by decide +kernel
private theorem cases341 : checkFour 341 (642,4734,633,4725) = true := by
  simp only [checkFour, w341_0,w341_1,w341_2,w341_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one341 : Coverage 341 342 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases341)
private theorem w342_0 : checkWitness 342 false false 8866 = true := by decide +kernel
private theorem w342_2 : checkWitness 342 true false 8862 = true := by decide +kernel
private theorem cases342 : checkFour 342 (8866,0,8862,0) = true := by
  simp only [checkFour, w342_0,w342_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one342 : Coverage 342 343 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases342)
private theorem w343_0 : checkWitness 343 false false 70 = true := by decide +kernel
private theorem w343_2 : checkWitness 343 true false 70 = true := by decide +kernel
private theorem cases343 : checkFour 343 (70,0,70,0) = true := by
  simp only [checkFour, w343_0,w343_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one343 : Coverage 343 344 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases343)
private theorem w344_0 : checkWitness 344 false false 62 = true := by decide +kernel
private theorem w344_2 : checkWitness 344 true false 62 = true := by decide +kernel
private theorem cases344 : checkFour 344 (62,0,62,0) = true := by
  simp only [checkFour, w344_0,w344_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one344 : Coverage 344 345 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases344)
private theorem w345_0 : checkWitness 345 false false 625 = true := by decide +kernel
private theorem w345_1 : checkWitness 345 false true 4697 = true := by decide +kernel
private theorem w345_2 : checkWitness 345 true false 625 = true := by decide +kernel
private theorem w345_3 : checkWitness 345 true true 4697 = true := by decide +kernel
private theorem cases345 : checkFour 345 (625,4697,625,4697) = true := by
  simp only [checkFour, w345_0,w345_1,w345_2,w345_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one345 : Coverage 345 346 := checkList_sound (ws:=[(625,4697,625,4697)]) (by simpa only [checkList, Bool.and_true] using cases345)
private theorem w346_0 : checkWitness 346 false false 8882 = true := by decide +kernel
private theorem w346_2 : checkWitness 346 true false 8878 = true := by decide +kernel
private theorem cases346 : checkFour 346 (8882,0,8878,0) = true := by
  simp only [checkFour, w346_0,w346_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one346 : Coverage 346 347 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases346)
private theorem w347_0 : checkWitness 347 false false 8878 = true := by decide +kernel
private theorem w347_2 : checkWitness 347 true false 8874 = true := by decide +kernel
private theorem cases347 : checkFour 347 (8878,0,8874,0) = true := by
  simp only [checkFour, w347_0,w347_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one347 : Coverage 347 348 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases347)
private theorem w348_0 : checkWitness 348 false false 76 = true := by decide +kernel
private theorem w348_2 : checkWitness 348 true false 76 = true := by decide +kernel
private theorem cases348 : checkFour 348 (76,0,76,0) = true := by
  simp only [checkFour, w348_0,w348_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one348 : Coverage 348 349 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases348)
private theorem w349_0 : checkWitness 349 false false 628 = true := by decide +kernel
private theorem w349_1 : checkWitness 349 false true 4724 = true := by decide +kernel
private theorem w349_2 : checkWitness 349 true false 628 = true := by decide +kernel
private theorem w349_3 : checkWitness 349 true true 4724 = true := by decide +kernel
private theorem cases349 : checkFour 349 (628,4724,628,4724) = true := by
  simp only [checkFour, w349_0,w349_1,w349_2,w349_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one349 : Coverage 349 350 := checkList_sound (ws:=[(628,4724,628,4724)]) (by simpa only [checkList, Bool.and_true] using cases349)
private theorem w350_0 : checkWitness 350 false false 8933 = true := by decide +kernel
private theorem w350_2 : checkWitness 350 true false 8929 = true := by decide +kernel
private theorem cases350 : checkFour 350 (8933,0,8929,0) = true := by
  simp only [checkFour, w350_0,w350_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one350 : Coverage 350 351 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases350)
private theorem w351_0 : checkWitness 351 false false 664 = true := by decide +kernel
private theorem w351_1 : checkWitness 351 false true 4760 = true := by decide +kernel
private theorem w351_2 : checkWitness 351 true false 655 = true := by decide +kernel
private theorem w351_3 : checkWitness 351 true true 4751 = true := by decide +kernel
private theorem cases351 : checkFour 351 (664,4760,655,4751) = true := by
  simp only [checkFour, w351_0,w351_1,w351_2,w351_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one351 : Coverage 351 352 := checkList_sound (ws:=[(664,4760,655,4751)]) (by simpa only [checkList, Bool.and_true] using cases351)
theorem cover0320 : Coverage 320 352 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one320 one321) (Coverage.join one322 one323)) (Coverage.join (Coverage.join one324 one325) (Coverage.join one326 one327))) (Coverage.join (Coverage.join (Coverage.join one328 one329) (Coverage.join one330 one331)) (Coverage.join (Coverage.join one332 one333) (Coverage.join one334 one335)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one336 one337) (Coverage.join one338 one339)) (Coverage.join (Coverage.join one340 one341) (Coverage.join one342 one343))) (Coverage.join (Coverage.join (Coverage.join one344 one345) (Coverage.join one346 one347)) (Coverage.join (Coverage.join one348 one349) (Coverage.join one350 one351)))))
end NF180PA.Symbolic
