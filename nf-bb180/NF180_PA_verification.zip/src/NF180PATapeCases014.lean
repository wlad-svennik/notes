import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w448_0 : checkWitness 448 false false 666 = true := by decide +kernel
private theorem w448_1 : checkWitness 448 false true 4758 = true := by decide +kernel
private theorem w448_2 : checkWitness 448 true false 657 = true := by decide +kernel
private theorem w448_3 : checkWitness 448 true true 4749 = true := by decide +kernel
private theorem cases448 : checkFour 448 (666,4758,657,4749) = true := by
  simp only [checkFour, w448_0,w448_1,w448_2,w448_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one448 : Coverage 448 449 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases448)
private theorem w449_0 : checkWitness 449 false false 8943 = true := by decide +kernel
private theorem w449_2 : checkWitness 449 true false 8934 = true := by decide +kernel
private theorem cases449 : checkFour 449 (8943,0,8934,0) = true := by
  simp only [checkFour, w449_0,w449_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one449 : Coverage 449 450 := checkList_sound (ws:=[(8943,0,8934,0)]) (by simpa only [checkList, Bool.and_true] using cases449)
private theorem w450_0 : checkWitness 450 false false 58 = true := by decide +kernel
private theorem w450_2 : checkWitness 450 true false 58 = true := by decide +kernel
private theorem cases450 : checkFour 450 (58,0,58,0) = true := by
  simp only [checkFour, w450_0,w450_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one450 : Coverage 450 451 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases450)
private theorem w451_0 : checkWitness 451 false false 530 = true := by decide +kernel
private theorem w451_1 : checkWitness 451 false true 4626 = true := by decide +kernel
private theorem w451_2 : checkWitness 451 true false 530 = true := by decide +kernel
private theorem w451_3 : checkWitness 451 true true 4626 = true := by decide +kernel
private theorem cases451 : checkFour 451 (530,4626,530,4626) = true := by
  simp only [checkFour, w451_0,w451_1,w451_2,w451_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one451 : Coverage 451 452 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases451)
private theorem w452_0 : checkWitness 452 false false 8925 = true := by decide +kernel
private theorem w452_2 : checkWitness 452 true false 8921 = true := by decide +kernel
private theorem cases452 : checkFour 452 (8925,0,8921,0) = true := by
  simp only [checkFour, w452_0,w452_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one452 : Coverage 452 453 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases452)
private theorem w453_0 : checkWitness 453 false false 656 = true := by decide +kernel
private theorem w453_1 : checkWitness 453 false true 4752 = true := by decide +kernel
private theorem w453_2 : checkWitness 453 true false 647 = true := by decide +kernel
private theorem w453_3 : checkWitness 453 true true 4743 = true := by decide +kernel
private theorem cases453 : checkFour 453 (656,4752,647,4743) = true := by
  simp only [checkFour, w453_0,w453_1,w453_2,w453_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one453 : Coverage 453 454 := checkList_sound (ws:=[(656,4752,647,4743)]) (by simpa only [checkList, Bool.and_true] using cases453)
private theorem w454_0 : checkWitness 454 false false 192 = true := by decide +kernel
private theorem w454_2 : checkWitness 454 true false 192 = true := by decide +kernel
private theorem cases454 : checkFour 454 (192,0,192,0) = true := by
  simp only [checkFour, w454_0,w454_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one454 : Coverage 454 455 := checkList_sound (ws:=[(192,0,192,0)]) (by simpa only [checkList, Bool.and_true] using cases454)
private theorem w455_0 : checkWitness 455 false false 611 = true := by decide +kernel
private theorem w455_1 : checkWitness 455 false true 4699 = true := by decide +kernel
private theorem w455_2 : checkWitness 455 true false 611 = true := by decide +kernel
private theorem w455_3 : checkWitness 455 true true 4699 = true := by decide +kernel
private theorem cases455 : checkFour 455 (611,4699,611,4699) = true := by
  simp only [checkFour, w455_0,w455_1,w455_2,w455_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one455 : Coverage 455 456 := checkList_sound (ws:=[(611,4699,611,4699)]) (by simpa only [checkList, Bool.and_true] using cases455)
private theorem w456_0 : checkWitness 456 false false 8940 = true := by decide +kernel
private theorem w456_2 : checkWitness 456 true false 8931 = true := by decide +kernel
private theorem cases456 : checkFour 456 (8940,0,8931,0) = true := by
  simp only [checkFour, w456_0,w456_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one456 : Coverage 456 457 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases456)
private theorem w457_0 : checkWitness 457 false false 76 = true := by decide +kernel
private theorem w457_2 : checkWitness 457 true false 76 = true := by decide +kernel
private theorem cases457 : checkFour 457 (76,0,76,0) = true := by
  simp only [checkFour, w457_0,w457_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one457 : Coverage 457 458 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases457)
private theorem w458_0 : checkWitness 458 false false 68 = true := by decide +kernel
private theorem w458_2 : checkWitness 458 true false 68 = true := by decide +kernel
private theorem cases458 : checkFour 458 (68,0,68,0) = true := by
  simp only [checkFour, w458_0,w458_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one458 : Coverage 458 459 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases458)
private theorem w459_0 : checkWitness 459 false false 617 = true := by decide +kernel
private theorem w459_1 : checkWitness 459 false true 4709 = true := by decide +kernel
private theorem w459_2 : checkWitness 459 true false 617 = true := by decide +kernel
private theorem w459_3 : checkWitness 459 true true 4709 = true := by decide +kernel
private theorem cases459 : checkFour 459 (617,4709,617,4709) = true := by
  simp only [checkFour, w459_0,w459_1,w459_2,w459_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one459 : Coverage 459 460 := checkList_sound (ws:=[(617,4709,617,4709)]) (by simpa only [checkList, Bool.and_true] using cases459)
private theorem w460_0 : checkWitness 460 false false 8878 = true := by decide +kernel
private theorem w460_2 : checkWitness 460 true false 8874 = true := by decide +kernel
private theorem cases460 : checkFour 460 (8878,0,8874,0) = true := by
  simp only [checkFour, w460_0,w460_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one460 : Coverage 460 461 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases460)
private theorem w461_0 : checkWitness 461 false false 68 = true := by decide +kernel
private theorem w461_2 : checkWitness 461 true false 68 = true := by decide +kernel
private theorem cases461 : checkFour 461 (68,0,68,0) = true := by
  simp only [checkFour, w461_0,w461_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one461 : Coverage 461 462 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases461)
private theorem w462_0 : checkWitness 462 false false 572 = true := by decide +kernel
private theorem w462_1 : checkWitness 462 false true 4668 = true := by decide +kernel
private theorem w462_2 : checkWitness 462 true false 572 = true := by decide +kernel
private theorem w462_3 : checkWitness 462 true true 4668 = true := by decide +kernel
private theorem cases462 : checkFour 462 (572,4668,572,4668) = true := by
  simp only [checkFour, w462_0,w462_1,w462_2,w462_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one462 : Coverage 462 463 := checkList_sound (ws:=[(572,4668,572,4668)]) (by simpa only [checkList, Bool.and_true] using cases462)
private theorem w463_0 : checkWitness 463 false false 8913 = true := by decide +kernel
private theorem w463_2 : checkWitness 463 true false 8909 = true := by decide +kernel
private theorem cases463 : checkFour 463 (8913,0,8909,0) = true := by
  simp only [checkFour, w463_0,w463_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one463 : Coverage 463 464 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases463)
private theorem w464_0 : checkWitness 464 false false 8948 = true := by decide +kernel
private theorem w464_2 : checkWitness 464 true false 8939 = true := by decide +kernel
private theorem cases464 : checkFour 464 (8948,0,8939,0) = true := by
  simp only [checkFour, w464_0,w464_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one464 : Coverage 464 465 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases464)
private theorem w465_0 : checkWitness 465 false false 86 = true := by decide +kernel
private theorem w465_2 : checkWitness 465 true false 86 = true := by decide +kernel
private theorem cases465 : checkFour 465 (86,0,86,0) = true := by
  simp only [checkFour, w465_0,w465_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one465 : Coverage 465 466 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases465)
private theorem w466_0 : checkWitness 466 false false 660 = true := by decide +kernel
private theorem w466_1 : checkWitness 466 false true 4752 = true := by decide +kernel
private theorem w466_2 : checkWitness 466 true false 651 = true := by decide +kernel
private theorem w466_3 : checkWitness 466 true true 4743 = true := by decide +kernel
private theorem cases466 : checkFour 466 (660,4752,651,4743) = true := by
  simp only [checkFour, w466_0,w466_1,w466_2,w466_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one466 : Coverage 466 467 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases466)
private theorem w467_0 : checkWitness 467 false false 8909 = true := by decide +kernel
private theorem w467_2 : checkWitness 467 true false 8905 = true := by decide +kernel
private theorem cases467 : checkFour 467 (8909,0,8905,0) = true := by
  simp only [checkFour, w467_0,w467_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one467 : Coverage 467 468 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases467)
private theorem w468_0 : checkWitness 468 false false 654 = true := by decide +kernel
private theorem w468_1 : checkWitness 468 false true 4746 = true := by decide +kernel
private theorem w468_2 : checkWitness 468 true false 645 = true := by decide +kernel
private theorem w468_3 : checkWitness 468 true true 4737 = true := by decide +kernel
private theorem cases468 : checkFour 468 (654,4746,645,4737) = true := by
  simp only [checkFour, w468_0,w468_1,w468_2,w468_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one468 : Coverage 468 469 := checkList_sound (ws:=[(654,4746,645,4737)]) (by simpa only [checkList, Bool.and_true] using cases468)
private theorem w469_0 : checkWitness 469 false false 8878 = true := by decide +kernel
private theorem w469_2 : checkWitness 469 true false 8874 = true := by decide +kernel
private theorem cases469 : checkFour 469 (8878,0,8874,0) = true := by
  simp only [checkFour, w469_0,w469_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one469 : Coverage 469 470 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases469)
private theorem w470_0 : checkWitness 470 false false 74 = true := by decide +kernel
private theorem w470_2 : checkWitness 470 true false 74 = true := by decide +kernel
private theorem cases470 : checkFour 470 (74,0,74,0) = true := by
  simp only [checkFour, w470_0,w470_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one470 : Coverage 470 471 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases470)
private theorem w471_0 : checkWitness 471 false false 66 = true := by decide +kernel
private theorem w471_2 : checkWitness 471 true false 66 = true := by decide +kernel
private theorem cases471 : checkFour 471 (66,0,66,0) = true := by
  simp only [checkFour, w471_0,w471_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one471 : Coverage 471 472 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases471)
private theorem w472_0 : checkWitness 472 false false 621 = true := by decide +kernel
private theorem w472_1 : checkWitness 472 false true 4709 = true := by decide +kernel
private theorem w472_2 : checkWitness 472 true false 621 = true := by decide +kernel
private theorem w472_3 : checkWitness 472 true true 4709 = true := by decide +kernel
private theorem cases472 : checkFour 472 (621,4709,621,4709) = true := by
  simp only [checkFour, w472_0,w472_1,w472_2,w472_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one472 : Coverage 472 473 := checkList_sound (ws:=[(621,4709,621,4709)]) (by simpa only [checkList, Bool.and_true] using cases472)
private theorem w473_0 : checkWitness 473 false false 8894 = true := by decide +kernel
private theorem w473_2 : checkWitness 473 true false 8890 = true := by decide +kernel
private theorem cases473 : checkFour 473 (8894,0,8890,0) = true := by
  simp only [checkFour, w473_0,w473_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one473 : Coverage 473 474 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases473)
private theorem w474_0 : checkWitness 474 false false 8890 = true := by decide +kernel
private theorem w474_2 : checkWitness 474 true false 8886 = true := by decide +kernel
private theorem cases474 : checkFour 474 (8890,0,8886,0) = true := by
  simp only [checkFour, w474_0,w474_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one474 : Coverage 474 475 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases474)
private theorem w475_0 : checkWitness 475 false false 80 = true := by decide +kernel
private theorem w475_2 : checkWitness 475 true false 80 = true := by decide +kernel
private theorem cases475 : checkFour 475 (80,0,80,0) = true := by
  simp only [checkFour, w475_0,w475_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one475 : Coverage 475 476 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases475)
private theorem w476_0 : checkWitness 476 false false 8926 = true := by decide +kernel
private theorem w476_2 : checkWitness 476 true false 8922 = true := by decide +kernel
private theorem cases476 : checkFour 476 (8926,0,8922,0) = true := by
  simp only [checkFour, w476_0,w476_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one476 : Coverage 476 477 := checkList_sound (ws:=[(8926,0,8922,0)]) (by simpa only [checkList, Bool.and_true] using cases476)
private theorem w477_0 : checkWitness 477 false false 8928 = true := by decide +kernel
private theorem w477_2 : checkWitness 477 true false 8924 = true := by decide +kernel
private theorem cases477 : checkFour 477 (8928,0,8924,0) = true := by
  simp only [checkFour, w477_0,w477_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one477 : Coverage 477 478 := checkList_sound (ws:=[(8928,0,8924,0)]) (by simpa only [checkList, Bool.and_true] using cases477)
private theorem w478_0 : checkWitness 478 false false 674 = true := by decide +kernel
private theorem w478_1 : checkWitness 478 false true 4770 = true := by decide +kernel
private theorem w478_2 : checkWitness 478 true false 674 = true := by decide +kernel
private theorem w478_3 : checkWitness 478 true true 4770 = true := by decide +kernel
private theorem cases478 : checkFour 478 (674,4770,674,4770) = true := by
  simp only [checkFour, w478_0,w478_1,w478_2,w478_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one478 : Coverage 478 479 := checkList_sound (ws:=[(674,4770,674,4770)]) (by simpa only [checkList, Bool.and_true] using cases478)
private theorem w479_0 : checkWitness 479 false false 8948 = true := by decide +kernel
private theorem w479_2 : checkWitness 479 true false 8939 = true := by decide +kernel
private theorem cases479 : checkFour 479 (8948,0,8939,0) = true := by
  simp only [checkFour, w479_0,w479_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one479 : Coverage 479 480 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases479)
theorem cover0448 : Coverage 448 480 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one448 one449) (Coverage.join one450 one451)) (Coverage.join (Coverage.join one452 one453) (Coverage.join one454 one455))) (Coverage.join (Coverage.join (Coverage.join one456 one457) (Coverage.join one458 one459)) (Coverage.join (Coverage.join one460 one461) (Coverage.join one462 one463)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one464 one465) (Coverage.join one466 one467)) (Coverage.join (Coverage.join one468 one469) (Coverage.join one470 one471))) (Coverage.join (Coverage.join (Coverage.join one472 one473) (Coverage.join one474 one475)) (Coverage.join (Coverage.join one476 one477) (Coverage.join one478 one479)))))
end NF180PA.Symbolic
