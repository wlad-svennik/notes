import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w960_0 : checkWitness 960 false false 88 = true := by decide +kernel
private theorem w960_2 : checkWitness 960 true false 88 = true := by decide +kernel
private theorem cases960 : checkFour 960 (88,0,88,0) = true := by
  simp only [checkFour, w960_0,w960_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one960 : Coverage 960 961 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases960)
private theorem w961_0 : checkWitness 961 false false 652 = true := by decide +kernel
private theorem w961_1 : checkWitness 961 false true 4740 = true := by decide +kernel
private theorem w961_2 : checkWitness 961 true false 643 = true := by decide +kernel
private theorem w961_3 : checkWitness 961 true true 4731 = true := by decide +kernel
private theorem cases961 : checkFour 961 (652,4740,643,4731) = true := by
  simp only [checkFour, w961_0,w961_1,w961_2,w961_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one961 : Coverage 961 962 := checkList_sound (ws:=[(652,4740,643,4731)]) (by simpa only [checkList, Bool.and_true] using cases961)
private theorem w962_0 : checkWitness 962 false false 8887 = true := by decide +kernel
private theorem w962_2 : checkWitness 962 true false 8883 = true := by decide +kernel
private theorem cases962 : checkFour 962 (8887,0,8883,0) = true := by
  simp only [checkFour, w962_0,w962_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one962 : Coverage 962 963 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases962)
private theorem w963_0 : checkWitness 963 false false 78 = true := by decide +kernel
private theorem w963_2 : checkWitness 963 true false 78 = true := by decide +kernel
private theorem cases963 : checkFour 963 (78,0,78,0) = true := by
  simp only [checkFour, w963_0,w963_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one963 : Coverage 963 964 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases963)
private theorem w964_0 : checkWitness 964 false false 504 = true := by decide +kernel
private theorem w964_1 : checkWitness 964 false true 4600 = true := by decide +kernel
private theorem w964_2 : checkWitness 964 true false 504 = true := by decide +kernel
private theorem w964_3 : checkWitness 964 true true 4600 = true := by decide +kernel
private theorem cases964 : checkFour 964 (504,4600,504,4600) = true := by
  simp only [checkFour, w964_0,w964_1,w964_2,w964_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one964 : Coverage 964 965 := checkList_sound (ws:=[(504,4600,504,4600)]) (by simpa only [checkList, Bool.and_true] using cases964)
private theorem w965_0 : checkWitness 965 false false 8899 = true := by decide +kernel
private theorem w965_2 : checkWitness 965 true false 8895 = true := by decide +kernel
private theorem cases965 : checkFour 965 (8899,0,8895,0) = true := by
  simp only [checkFour, w965_0,w965_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one965 : Coverage 965 966 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases965)
private theorem w966_0 : checkWitness 966 false false 630 = true := by decide +kernel
private theorem w966_1 : checkWitness 966 false true 4726 = true := by decide +kernel
private theorem w966_2 : checkWitness 966 true false 621 = true := by decide +kernel
private theorem w966_3 : checkWitness 966 true true 4717 = true := by decide +kernel
private theorem cases966 : checkFour 966 (630,4726,621,4717) = true := by
  simp only [checkFour, w966_0,w966_1,w966_2,w966_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one966 : Coverage 966 967 := checkList_sound (ws:=[(630,4726,621,4717)]) (by simpa only [checkList, Bool.and_true] using cases966)
private theorem w967_0 : checkWitness 967 false false 180 = true := by decide +kernel
private theorem w967_2 : checkWitness 967 true false 180 = true := by decide +kernel
private theorem cases967 : checkFour 967 (180,0,180,0) = true := by
  simp only [checkFour, w967_0,w967_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one967 : Coverage 967 968 := checkList_sound (ws:=[(180,0,180,0)]) (by simpa only [checkList, Bool.and_true] using cases967)
private theorem w968_0 : checkWitness 968 false false 585 = true := by decide +kernel
private theorem w968_1 : checkWitness 968 false true 4673 = true := by decide +kernel
private theorem w968_2 : checkWitness 968 true false 585 = true := by decide +kernel
private theorem w968_3 : checkWitness 968 true true 4673 = true := by decide +kernel
private theorem cases968 : checkFour 968 (585,4673,585,4673) = true := by
  simp only [checkFour, w968_0,w968_1,w968_2,w968_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one968 : Coverage 968 969 := checkList_sound (ws:=[(585,4673,585,4673)]) (by simpa only [checkList, Bool.and_true] using cases968)
private theorem w969_0 : checkWitness 969 false false 8914 = true := by decide +kernel
private theorem w969_2 : checkWitness 969 true false 8905 = true := by decide +kernel
private theorem cases969 : checkFour 969 (8914,0,8905,0) = true := by
  simp only [checkFour, w969_0,w969_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one969 : Coverage 969 970 := checkList_sound (ws:=[(8914,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases969)
private theorem w970_0 : checkWitness 970 false false 84 = true := by decide +kernel
private theorem w970_2 : checkWitness 970 true false 84 = true := by decide +kernel
private theorem cases970 : checkFour 970 (84,0,84,0) = true := by
  simp only [checkFour, w970_0,w970_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one970 : Coverage 970 971 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases970)
private theorem w971_0 : checkWitness 971 false false 76 = true := by decide +kernel
private theorem w971_2 : checkWitness 971 true false 76 = true := by decide +kernel
private theorem cases971 : checkFour 971 (76,0,76,0) = true := by
  simp only [checkFour, w971_0,w971_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one971 : Coverage 971 972 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases971)
private theorem w972_0 : checkWitness 972 false false 591 = true := by decide +kernel
private theorem w972_1 : checkWitness 972 false true 4683 = true := by decide +kernel
private theorem w972_2 : checkWitness 972 true false 591 = true := by decide +kernel
private theorem w972_3 : checkWitness 972 true true 4683 = true := by decide +kernel
private theorem cases972 : checkFour 972 (591,4683,591,4683) = true := by
  simp only [checkFour, w972_0,w972_1,w972_2,w972_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one972 : Coverage 972 973 := checkList_sound (ws:=[(591,4683,591,4683)]) (by simpa only [checkList, Bool.and_true] using cases972)
private theorem w973_0 : checkWitness 973 false false 8852 = true := by decide +kernel
private theorem w973_2 : checkWitness 973 true false 8848 = true := by decide +kernel
private theorem cases973 : checkFour 973 (8852,0,8848,0) = true := by
  simp only [checkFour, w973_0,w973_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one973 : Coverage 973 974 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases973)
private theorem w974_0 : checkWitness 974 false false 76 = true := by decide +kernel
private theorem w974_2 : checkWitness 974 true false 76 = true := by decide +kernel
private theorem cases974 : checkFour 974 (76,0,76,0) = true := by
  simp only [checkFour, w974_0,w974_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one974 : Coverage 974 975 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases974)
private theorem w975_0 : checkWitness 975 false false 546 = true := by decide +kernel
private theorem w975_1 : checkWitness 975 false true 4642 = true := by decide +kernel
private theorem w975_2 : checkWitness 975 true false 546 = true := by decide +kernel
private theorem w975_3 : checkWitness 975 true true 4642 = true := by decide +kernel
private theorem cases975 : checkFour 975 (546,4642,546,4642) = true := by
  simp only [checkFour, w975_0,w975_1,w975_2,w975_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one975 : Coverage 975 976 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases975)
private theorem w976_0 : checkWitness 976 false false 8887 = true := by decide +kernel
private theorem w976_2 : checkWitness 976 true false 8883 = true := by decide +kernel
private theorem cases976 : checkFour 976 (8887,0,8883,0) = true := by
  simp only [checkFour, w976_0,w976_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one976 : Coverage 976 977 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases976)
private theorem w977_0 : checkWitness 977 false false 8922 = true := by decide +kernel
private theorem w977_2 : checkWitness 977 true false 8913 = true := by decide +kernel
private theorem cases977 : checkFour 977 (8922,0,8913,0) = true := by
  simp only [checkFour, w977_0,w977_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one977 : Coverage 977 978 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases977)
private theorem w978_0 : checkWitness 978 false false 94 = true := by decide +kernel
private theorem w978_2 : checkWitness 978 true false 94 = true := by decide +kernel
private theorem cases978 : checkFour 978 (94,0,94,0) = true := by
  simp only [checkFour, w978_0,w978_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one978 : Coverage 978 979 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases978)
private theorem w979_0 : checkWitness 979 false false 634 = true := by decide +kernel
private theorem w979_1 : checkWitness 979 false true 4726 = true := by decide +kernel
private theorem w979_2 : checkWitness 979 true false 625 = true := by decide +kernel
private theorem w979_3 : checkWitness 979 true true 4717 = true := by decide +kernel
private theorem cases979 : checkFour 979 (634,4726,625,4717) = true := by
  simp only [checkFour, w979_0,w979_1,w979_2,w979_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one979 : Coverage 979 980 := checkList_sound (ws:=[(634,4726,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases979)
private theorem w980_0 : checkWitness 980 false false 8883 = true := by decide +kernel
private theorem w980_2 : checkWitness 980 true false 8879 = true := by decide +kernel
private theorem cases980 : checkFour 980 (8883,0,8879,0) = true := by
  simp only [checkFour, w980_0,w980_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one980 : Coverage 980 981 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases980)
private theorem w981_0 : checkWitness 981 false false 628 = true := by decide +kernel
private theorem w981_1 : checkWitness 981 false true 4720 = true := by decide +kernel
private theorem w981_2 : checkWitness 981 true false 619 = true := by decide +kernel
private theorem w981_3 : checkWitness 981 true true 4711 = true := by decide +kernel
private theorem cases981 : checkFour 981 (628,4720,619,4711) = true := by
  simp only [checkFour, w981_0,w981_1,w981_2,w981_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one981 : Coverage 981 982 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases981)
private theorem w982_0 : checkWitness 982 false false 8852 = true := by decide +kernel
private theorem w982_2 : checkWitness 982 true false 8848 = true := by decide +kernel
private theorem cases982 : checkFour 982 (8852,0,8848,0) = true := by
  simp only [checkFour, w982_0,w982_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one982 : Coverage 982 983 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases982)
private theorem w983_0 : checkWitness 983 false false 82 = true := by decide +kernel
private theorem w983_2 : checkWitness 983 true false 82 = true := by decide +kernel
private theorem cases983 : checkFour 983 (82,0,82,0) = true := by
  simp only [checkFour, w983_0,w983_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one983 : Coverage 983 984 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases983)
private theorem w984_0 : checkWitness 984 false false 74 = true := by decide +kernel
private theorem w984_2 : checkWitness 984 true false 74 = true := by decide +kernel
private theorem cases984 : checkFour 984 (74,0,74,0) = true := by
  simp only [checkFour, w984_0,w984_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one984 : Coverage 984 985 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases984)
private theorem w985_0 : checkWitness 985 false false 595 = true := by decide +kernel
private theorem w985_1 : checkWitness 985 false true 4683 = true := by decide +kernel
private theorem w985_2 : checkWitness 985 true false 595 = true := by decide +kernel
private theorem w985_3 : checkWitness 985 true true 4683 = true := by decide +kernel
private theorem cases985 : checkFour 985 (595,4683,595,4683) = true := by
  simp only [checkFour, w985_0,w985_1,w985_2,w985_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one985 : Coverage 985 986 := checkList_sound (ws:=[(595,4683,595,4683)]) (by simpa only [checkList, Bool.and_true] using cases985)
private theorem w986_0 : checkWitness 986 false false 8868 = true := by decide +kernel
private theorem w986_2 : checkWitness 986 true false 8864 = true := by decide +kernel
private theorem cases986 : checkFour 986 (8868,0,8864,0) = true := by
  simp only [checkFour, w986_0,w986_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one986 : Coverage 986 987 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases986)
private theorem w987_0 : checkWitness 987 false false 8864 = true := by decide +kernel
private theorem w987_2 : checkWitness 987 true false 8860 = true := by decide +kernel
private theorem cases987 : checkFour 987 (8864,0,8860,0) = true := by
  simp only [checkFour, w987_0,w987_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one987 : Coverage 987 988 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases987)
private theorem w988_0 : checkWitness 988 false false 88 = true := by decide +kernel
private theorem w988_2 : checkWitness 988 true false 88 = true := by decide +kernel
private theorem cases988 : checkFour 988 (88,0,88,0) = true := by
  simp only [checkFour, w988_0,w988_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one988 : Coverage 988 989 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases988)
private theorem w989_0 : checkWitness 989 false false 8880 = true := by decide +kernel
private theorem w989_2 : checkWitness 989 true false 8876 = true := by decide +kernel
private theorem cases989 : checkFour 989 (8880,0,8876,0) = true := by
  simp only [checkFour, w989_0,w989_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one989 : Coverage 989 990 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases989)
private theorem w990_0 : checkWitness 990 false false 718 = true := by decide +kernel
private theorem w990_1 : checkWitness 990 false true 4814 = true := by decide +kernel
private theorem w990_2 : checkWitness 990 true false 718 = true := by decide +kernel
private theorem w990_3 : checkWitness 990 true true 4814 = true := by decide +kernel
private theorem cases990 : checkFour 990 (718,4814,718,4814) = true := by
  simp only [checkFour, w990_0,w990_1,w990_2,w990_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one990 : Coverage 990 991 := checkList_sound (ws:=[(718,4814,718,4814)]) (by simpa only [checkList, Bool.and_true] using cases990)
private theorem w991_0 : checkWitness 991 false false 8966 = true := by decide +kernel
private theorem w991_2 : checkWitness 991 true false 8957 = true := by decide +kernel
private theorem cases991 : checkFour 991 (8966,0,8957,0) = true := by
  simp only [checkFour, w991_0,w991_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one991 : Coverage 991 992 := checkList_sound (ws:=[(8966,0,8957,0)]) (by simpa only [checkList, Bool.and_true] using cases991)
theorem cover0960 : Coverage 960 992 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one960 one961) (Coverage.join one962 one963)) (Coverage.join (Coverage.join one964 one965) (Coverage.join one966 one967))) (Coverage.join (Coverage.join (Coverage.join one968 one969) (Coverage.join one970 one971)) (Coverage.join (Coverage.join one972 one973) (Coverage.join one974 one975)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one976 one977) (Coverage.join one978 one979)) (Coverage.join (Coverage.join one980 one981) (Coverage.join one982 one983))) (Coverage.join (Coverage.join (Coverage.join one984 one985) (Coverage.join one986 one987)) (Coverage.join (Coverage.join one988 one989) (Coverage.join one990 one991)))))
end NF180PA.Symbolic
