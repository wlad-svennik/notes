import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1280_0 : checkWitness 1280 false false 170 = true := by decide +kernel
private theorem w1280_2 : checkWitness 1280 true false 170 = true := by decide +kernel
private theorem cases1280 : checkFour 1280 (170,0,170,0) = true := by
  simp only [checkFour, w1280_0,w1280_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1280 : Coverage 1280 1281 := checkList_sound (ws:=[(170,0,170,0)]) (by simpa only [checkList, Bool.and_true] using cases1280)
private theorem w1281_0 : checkWitness 1281 false false 563 = true := by decide +kernel
private theorem w1281_1 : checkWitness 1281 false true 4651 = true := by decide +kernel
private theorem w1281_2 : checkWitness 1281 true false 563 = true := by decide +kernel
private theorem w1281_3 : checkWitness 1281 true true 4651 = true := by decide +kernel
private theorem cases1281 : checkFour 1281 (563,4651,563,4651) = true := by
  simp only [checkFour, w1281_0,w1281_1,w1281_2,w1281_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1281 : Coverage 1281 1282 := checkList_sound (ws:=[(563,4651,563,4651)]) (by simpa only [checkList, Bool.and_true] using cases1281)
private theorem w1282_0 : checkWitness 1282 false false 8892 = true := by decide +kernel
private theorem w1282_2 : checkWitness 1282 true false 8883 = true := by decide +kernel
private theorem cases1282 : checkFour 1282 (8892,0,8883,0) = true := by
  simp only [checkFour, w1282_0,w1282_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1282 : Coverage 1282 1283 := checkList_sound (ws:=[(8892,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1282)
private theorem w1283_0 : checkWitness 1283 false false 90 = true := by decide +kernel
private theorem w1283_2 : checkWitness 1283 true false 90 = true := by decide +kernel
private theorem cases1283 : checkFour 1283 (90,0,90,0) = true := by
  simp only [checkFour, w1283_0,w1283_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1283 : Coverage 1283 1284 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1283)
private theorem w1284_0 : checkWitness 1284 false false 82 = true := by decide +kernel
private theorem w1284_2 : checkWitness 1284 true false 82 = true := by decide +kernel
private theorem cases1284 : checkFour 1284 (82,0,82,0) = true := by
  simp only [checkFour, w1284_0,w1284_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1284 : Coverage 1284 1285 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1284)
private theorem w1285_0 : checkWitness 1285 false false 569 = true := by decide +kernel
private theorem w1285_1 : checkWitness 1285 false true 4661 = true := by decide +kernel
private theorem w1285_2 : checkWitness 1285 true false 569 = true := by decide +kernel
private theorem w1285_3 : checkWitness 1285 true true 4661 = true := by decide +kernel
private theorem cases1285 : checkFour 1285 (569,4661,569,4661) = true := by
  simp only [checkFour, w1285_0,w1285_1,w1285_2,w1285_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1285 : Coverage 1285 1286 := checkList_sound (ws:=[(569,4661,569,4661)]) (by simpa only [checkList, Bool.and_true] using cases1285)
private theorem w1286_0 : checkWitness 1286 false false 8830 = true := by decide +kernel
private theorem w1286_2 : checkWitness 1286 true false 8826 = true := by decide +kernel
private theorem cases1286 : checkFour 1286 (8830,0,8826,0) = true := by
  simp only [checkFour, w1286_0,w1286_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1286 : Coverage 1286 1287 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1286)
private theorem w1287_0 : checkWitness 1287 false false 82 = true := by decide +kernel
private theorem w1287_2 : checkWitness 1287 true false 82 = true := by decide +kernel
private theorem cases1287 : checkFour 1287 (82,0,82,0) = true := by
  simp only [checkFour, w1287_0,w1287_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1287 : Coverage 1287 1288 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1287)
private theorem w1288_0 : checkWitness 1288 false false 524 = true := by decide +kernel
private theorem w1288_1 : checkWitness 1288 false true 4620 = true := by decide +kernel
private theorem w1288_2 : checkWitness 1288 true false 524 = true := by decide +kernel
private theorem w1288_3 : checkWitness 1288 true true 4620 = true := by decide +kernel
private theorem cases1288 : checkFour 1288 (524,4620,524,4620) = true := by
  simp only [checkFour, w1288_0,w1288_1,w1288_2,w1288_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1288 : Coverage 1288 1289 := checkList_sound (ws:=[(524,4620,524,4620)]) (by simpa only [checkList, Bool.and_true] using cases1288)
private theorem w1289_0 : checkWitness 1289 false false 8865 = true := by decide +kernel
private theorem w1289_2 : checkWitness 1289 true false 8861 = true := by decide +kernel
private theorem cases1289 : checkFour 1289 (8865,0,8861,0) = true := by
  simp only [checkFour, w1289_0,w1289_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1289 : Coverage 1289 1290 := checkList_sound (ws:=[(8865,0,8861,0)]) (by simpa only [checkList, Bool.and_true] using cases1289)
private theorem w1290_0 : checkWitness 1290 false false 8900 = true := by decide +kernel
private theorem w1290_2 : checkWitness 1290 true false 8891 = true := by decide +kernel
private theorem cases1290 : checkFour 1290 (8900,0,8891,0) = true := by
  simp only [checkFour, w1290_0,w1290_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1290 : Coverage 1290 1291 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1290)
private theorem w1291_0 : checkWitness 1291 false false 100 = true := by decide +kernel
private theorem w1291_2 : checkWitness 1291 true false 100 = true := by decide +kernel
private theorem cases1291 : checkFour 1291 (100,0,100,0) = true := by
  simp only [checkFour, w1291_0,w1291_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1291 : Coverage 1291 1292 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1291)
private theorem w1292_0 : checkWitness 1292 false false 612 = true := by decide +kernel
private theorem w1292_1 : checkWitness 1292 false true 4704 = true := by decide +kernel
private theorem w1292_2 : checkWitness 1292 true false 603 = true := by decide +kernel
private theorem w1292_3 : checkWitness 1292 true true 4695 = true := by decide +kernel
private theorem cases1292 : checkFour 1292 (612,4704,603,4695) = true := by
  simp only [checkFour, w1292_0,w1292_1,w1292_2,w1292_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1292 : Coverage 1292 1293 := checkList_sound (ws:=[(612,4704,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases1292)
private theorem w1293_0 : checkWitness 1293 false false 8861 = true := by decide +kernel
private theorem w1293_2 : checkWitness 1293 true false 8857 = true := by decide +kernel
private theorem cases1293 : checkFour 1293 (8861,0,8857,0) = true := by
  simp only [checkFour, w1293_0,w1293_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1293 : Coverage 1293 1294 := checkList_sound (ws:=[(8861,0,8857,0)]) (by simpa only [checkList, Bool.and_true] using cases1293)
private theorem w1294_0 : checkWitness 1294 false false 606 = true := by decide +kernel
private theorem w1294_1 : checkWitness 1294 false true 4698 = true := by decide +kernel
private theorem w1294_2 : checkWitness 1294 true false 597 = true := by decide +kernel
private theorem w1294_3 : checkWitness 1294 true true 4689 = true := by decide +kernel
private theorem cases1294 : checkFour 1294 (606,4698,597,4689) = true := by
  simp only [checkFour, w1294_0,w1294_1,w1294_2,w1294_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1294 : Coverage 1294 1295 := checkList_sound (ws:=[(606,4698,597,4689)]) (by simpa only [checkList, Bool.and_true] using cases1294)
private theorem w1295_0 : checkWitness 1295 false false 8830 = true := by decide +kernel
private theorem w1295_2 : checkWitness 1295 true false 8826 = true := by decide +kernel
private theorem cases1295 : checkFour 1295 (8830,0,8826,0) = true := by
  simp only [checkFour, w1295_0,w1295_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1295 : Coverage 1295 1296 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1295)
private theorem w1296_0 : checkWitness 1296 false false 88 = true := by decide +kernel
private theorem w1296_2 : checkWitness 1296 true false 88 = true := by decide +kernel
private theorem cases1296 : checkFour 1296 (88,0,88,0) = true := by
  simp only [checkFour, w1296_0,w1296_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1296 : Coverage 1296 1297 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1296)
private theorem w1297_0 : checkWitness 1297 false false 80 = true := by decide +kernel
private theorem w1297_2 : checkWitness 1297 true false 80 = true := by decide +kernel
private theorem cases1297 : checkFour 1297 (80,0,80,0) = true := by
  simp only [checkFour, w1297_0,w1297_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1297 : Coverage 1297 1298 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1297)
private theorem w1298_0 : checkWitness 1298 false false 573 = true := by decide +kernel
private theorem w1298_1 : checkWitness 1298 false true 4661 = true := by decide +kernel
private theorem w1298_2 : checkWitness 1298 true false 573 = true := by decide +kernel
private theorem w1298_3 : checkWitness 1298 true true 4661 = true := by decide +kernel
private theorem cases1298 : checkFour 1298 (573,4661,573,4661) = true := by
  simp only [checkFour, w1298_0,w1298_1,w1298_2,w1298_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1298 : Coverage 1298 1299 := checkList_sound (ws:=[(573,4661,573,4661)]) (by simpa only [checkList, Bool.and_true] using cases1298)
private theorem w1299_0 : checkWitness 1299 false false 8846 = true := by decide +kernel
private theorem w1299_2 : checkWitness 1299 true false 8842 = true := by decide +kernel
private theorem cases1299 : checkFour 1299 (8846,0,8842,0) = true := by
  simp only [checkFour, w1299_0,w1299_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1299 : Coverage 1299 1300 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1299)
private theorem w1300_0 : checkWitness 1300 false false 8842 = true := by decide +kernel
private theorem w1300_2 : checkWitness 1300 true false 8838 = true := by decide +kernel
private theorem cases1300 : checkFour 1300 (8842,0,8838,0) = true := by
  simp only [checkFour, w1300_0,w1300_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1300 : Coverage 1300 1301 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1300)
private theorem w1301_0 : checkWitness 1301 false false 94 = true := by decide +kernel
private theorem w1301_2 : checkWitness 1301 true false 94 = true := by decide +kernel
private theorem cases1301 : checkFour 1301 (94,0,94,0) = true := by
  simp only [checkFour, w1301_0,w1301_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1301 : Coverage 1301 1302 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1301)
private theorem w1302_0 : checkWitness 1302 false false 8858 = true := by decide +kernel
private theorem w1302_2 : checkWitness 1302 true false 8854 = true := by decide +kernel
private theorem cases1302 : checkFour 1302 (8858,0,8854,0) = true := by
  simp only [checkFour, w1302_0,w1302_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1302 : Coverage 1302 1303 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1302)
private theorem w1303_0 : checkWitness 1303 false false 550 = true := by decide +kernel
private theorem w1303_1 : checkWitness 1303 false true 4646 = true := by decide +kernel
private theorem w1303_2 : checkWitness 1303 true false 550 = true := by decide +kernel
private theorem w1303_3 : checkWitness 1303 true true 4646 = true := by decide +kernel
private theorem cases1303 : checkFour 1303 (550,4646,550,4646) = true := by
  simp only [checkFour, w1303_0,w1303_1,w1303_2,w1303_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1303 : Coverage 1303 1304 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases1303)
private theorem w1304_0 : checkWitness 1304 false false 8912 = true := by decide +kernel
private theorem w1304_2 : checkWitness 1304 true false 8903 = true := by decide +kernel
private theorem cases1304 : checkFour 1304 (8912,0,8903,0) = true := by
  simp only [checkFour, w1304_0,w1304_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1304 : Coverage 1304 1305 := checkList_sound (ws:=[(8912,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases1304)
private theorem w1305_0 : checkWitness 1305 false false 80 = true := by decide +kernel
private theorem w1305_2 : checkWitness 1305 true false 80 = true := by decide +kernel
private theorem cases1305 : checkFour 1305 (80,0,80,0) = true := by
  simp only [checkFour, w1305_0,w1305_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1305 : Coverage 1305 1306 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1305)
private theorem w1306_0 : checkWitness 1306 false false 494 = true := by decide +kernel
private theorem w1306_1 : checkWitness 1306 false true 4590 = true := by decide +kernel
private theorem w1306_2 : checkWitness 1306 true false 494 = true := by decide +kernel
private theorem w1306_3 : checkWitness 1306 true true 4590 = true := by decide +kernel
private theorem cases1306 : checkFour 1306 (494,4590,494,4590) = true := by
  simp only [checkFour, w1306_0,w1306_1,w1306_2,w1306_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1306 : Coverage 1306 1307 := checkList_sound (ws:=[(494,4590,494,4590)]) (by simpa only [checkList, Bool.and_true] using cases1306)
private theorem w1307_0 : checkWitness 1307 false false 8852 = true := by decide +kernel
private theorem w1307_2 : checkWitness 1307 true false 8848 = true := by decide +kernel
private theorem cases1307 : checkFour 1307 (8852,0,8848,0) = true := by
  simp only [checkFour, w1307_0,w1307_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1307 : Coverage 1307 1308 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1307)
private theorem w1308_0 : checkWitness 1308 false false 82 = true := by decide +kernel
private theorem w1308_2 : checkWitness 1308 true false 82 = true := by decide +kernel
private theorem cases1308 : checkFour 1308 (82,0,82,0) = true := by
  simp only [checkFour, w1308_0,w1308_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1308 : Coverage 1308 1309 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1308)
private theorem w1309_0 : checkWitness 1309 false false 532 = true := by decide +kernel
private theorem w1309_1 : checkWitness 1309 false true 4628 = true := by decide +kernel
private theorem w1309_2 : checkWitness 1309 true false 532 = true := by decide +kernel
private theorem w1309_3 : checkWitness 1309 true true 4628 = true := by decide +kernel
private theorem cases1309 : checkFour 1309 (532,4628,532,4628) = true := by
  simp only [checkFour, w1309_0,w1309_1,w1309_2,w1309_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1309 : Coverage 1309 1310 := checkList_sound (ws:=[(532,4628,532,4628)]) (by simpa only [checkList, Bool.and_true] using cases1309)
private theorem w1310_0 : checkWitness 1310 false false 8873 = true := by decide +kernel
private theorem w1310_2 : checkWitness 1310 true false 8869 = true := by decide +kernel
private theorem cases1310 : checkFour 1310 (8873,0,8869,0) = true := by
  simp only [checkFour, w1310_0,w1310_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1310 : Coverage 1310 1311 := checkList_sound (ws:=[(8873,0,8869,0)]) (by simpa only [checkList, Bool.and_true] using cases1310)
private theorem w1311_0 : checkWitness 1311 false false 8908 = true := by decide +kernel
private theorem w1311_2 : checkWitness 1311 true false 8899 = true := by decide +kernel
private theorem cases1311 : checkFour 1311 (8908,0,8899,0) = true := by
  simp only [checkFour, w1311_0,w1311_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1311 : Coverage 1311 1312 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases1311)
theorem cover1280 : Coverage 1280 1312 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1280 one1281) (Coverage.join one1282 one1283)) (Coverage.join (Coverage.join one1284 one1285) (Coverage.join one1286 one1287))) (Coverage.join (Coverage.join (Coverage.join one1288 one1289) (Coverage.join one1290 one1291)) (Coverage.join (Coverage.join one1292 one1293) (Coverage.join one1294 one1295)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1296 one1297) (Coverage.join one1298 one1299)) (Coverage.join (Coverage.join one1300 one1301) (Coverage.join one1302 one1303))) (Coverage.join (Coverage.join (Coverage.join one1304 one1305) (Coverage.join one1306 one1307)) (Coverage.join (Coverage.join one1308 one1309) (Coverage.join one1310 one1311)))))
end NF180PA.Symbolic
