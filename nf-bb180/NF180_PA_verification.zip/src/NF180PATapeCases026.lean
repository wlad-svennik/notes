import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w832_0 : checkWitness 832 false false 8915 = true := by decide +kernel
private theorem w832_2 : checkWitness 832 true false 8911 = true := by decide +kernel
private theorem cases832 : checkFour 832 (8915,0,8911,0) = true := by
  simp only [checkFour, w832_0,w832_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one832 : Coverage 832 833 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases832)
private theorem w833_0 : checkWitness 833 false false 660 = true := by decide +kernel
private theorem w833_1 : checkWitness 833 false true 4752 = true := by decide +kernel
private theorem w833_2 : checkWitness 833 true false 651 = true := by decide +kernel
private theorem w833_3 : checkWitness 833 true true 4743 = true := by decide +kernel
private theorem cases833 : checkFour 833 (660,4752,651,4743) = true := by
  simp only [checkFour, w833_0,w833_1,w833_2,w833_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one833 : Coverage 833 834 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases833)
private theorem w834_0 : checkWitness 834 false false 8884 = true := by decide +kernel
private theorem w834_2 : checkWitness 834 true false 8880 = true := by decide +kernel
private theorem cases834 : checkFour 834 (8884,0,8880,0) = true := by
  simp only [checkFour, w834_0,w834_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one834 : Coverage 834 835 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases834)
private theorem w835_0 : checkWitness 835 false false 66 = true := by decide +kernel
private theorem w835_2 : checkWitness 835 true false 66 = true := by decide +kernel
private theorem cases835 : checkFour 835 (66,0,66,0) = true := by
  simp only [checkFour, w835_0,w835_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one835 : Coverage 835 836 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases835)
private theorem w836_0 : checkWitness 836 false false 58 = true := by decide +kernel
private theorem w836_2 : checkWitness 836 true false 58 = true := by decide +kernel
private theorem cases836 : checkFour 836 (58,0,58,0) = true := by
  simp only [checkFour, w836_0,w836_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one836 : Coverage 836 837 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases836)
private theorem w837_0 : checkWitness 837 false false 627 = true := by decide +kernel
private theorem w837_1 : checkWitness 837 false true 4715 = true := by decide +kernel
private theorem w837_2 : checkWitness 837 true false 627 = true := by decide +kernel
private theorem w837_3 : checkWitness 837 true true 4715 = true := by decide +kernel
private theorem cases837 : checkFour 837 (627,4715,627,4715) = true := by
  simp only [checkFour, w837_0,w837_1,w837_2,w837_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one837 : Coverage 837 838 := checkList_sound (ws:=[(627,4715,627,4715)]) (by simpa only [checkList, Bool.and_true] using cases837)
private theorem w838_0 : checkWitness 838 false false 8900 = true := by decide +kernel
private theorem w838_2 : checkWitness 838 true false 8896 = true := by decide +kernel
private theorem cases838 : checkFour 838 (8900,0,8896,0) = true := by
  simp only [checkFour, w838_0,w838_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one838 : Coverage 838 839 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases838)
private theorem w839_0 : checkWitness 839 false false 8896 = true := by decide +kernel
private theorem w839_2 : checkWitness 839 true false 8892 = true := by decide +kernel
private theorem cases839 : checkFour 839 (8896,0,8892,0) = true := by
  simp only [checkFour, w839_0,w839_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one839 : Coverage 839 840 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases839)
private theorem w840_0 : checkWitness 840 false false 72 = true := by decide +kernel
private theorem w840_2 : checkWitness 840 true false 72 = true := by decide +kernel
private theorem cases840 : checkFour 840 (72,0,72,0) = true := by
  simp only [checkFour, w840_0,w840_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one840 : Coverage 840 841 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases840)
private theorem w841_0 : checkWitness 841 false false 536 = true := by decide +kernel
private theorem w841_1 : checkWitness 841 false true 4632 = true := by decide +kernel
private theorem w841_2 : checkWitness 841 true false 536 = true := by decide +kernel
private theorem w841_3 : checkWitness 841 true true 4632 = true := by decide +kernel
private theorem cases841 : checkFour 841 (536,4632,536,4632) = true := by
  simp only [checkFour, w841_0,w841_1,w841_2,w841_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one841 : Coverage 841 842 := checkList_sound (ws:=[(536,4632,536,4632)]) (by simpa only [checkList, Bool.and_true] using cases841)
private theorem w842_0 : checkWitness 842 false false 8931 = true := by decide +kernel
private theorem w842_2 : checkWitness 842 true false 8927 = true := by decide +kernel
private theorem cases842 : checkFour 842 (8931,0,8927,0) = true := by
  simp only [checkFour, w842_0,w842_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one842 : Coverage 842 843 := checkList_sound (ws:=[(8931,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases842)
private theorem w843_0 : checkWitness 843 false false 662 = true := by decide +kernel
private theorem w843_1 : checkWitness 843 false true 4758 = true := by decide +kernel
private theorem w843_2 : checkWitness 843 true false 653 = true := by decide +kernel
private theorem w843_3 : checkWitness 843 true true 4749 = true := by decide +kernel
private theorem cases843 : checkFour 843 (662,4758,653,4749) = true := by
  simp only [checkFour, w843_0,w843_1,w843_2,w843_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one843 : Coverage 843 844 := checkList_sound (ws:=[(662,4758,653,4749)]) (by simpa only [checkList, Bool.and_true] using cases843)
private theorem w844_0 : checkWitness 844 false false 196 = true := by decide +kernel
private theorem w844_2 : checkWitness 844 true false 196 = true := by decide +kernel
private theorem cases844 : checkFour 844 (196,0,196,0) = true := by
  simp only [checkFour, w844_0,w844_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one844 : Coverage 844 845 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases844)
private theorem w845_0 : checkWitness 845 false false 617 = true := by decide +kernel
private theorem w845_1 : checkWitness 845 false true 4705 = true := by decide +kernel
private theorem w845_2 : checkWitness 845 true false 617 = true := by decide +kernel
private theorem w845_3 : checkWitness 845 true true 4705 = true := by decide +kernel
private theorem cases845 : checkFour 845 (617,4705,617,4705) = true := by
  simp only [checkFour, w845_0,w845_1,w845_2,w845_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one845 : Coverage 845 846 := checkList_sound (ws:=[(617,4705,617,4705)]) (by simpa only [checkList, Bool.and_true] using cases845)
private theorem w846_0 : checkWitness 846 false false 8946 = true := by decide +kernel
private theorem w846_2 : checkWitness 846 true false 8937 = true := by decide +kernel
private theorem cases846 : checkFour 846 (8946,0,8937,0) = true := by
  simp only [checkFour, w846_0,w846_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one846 : Coverage 846 847 := checkList_sound (ws:=[(8946,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases846)
private theorem w847_0 : checkWitness 847 false false 68 = true := by decide +kernel
private theorem w847_2 : checkWitness 847 true false 68 = true := by decide +kernel
private theorem cases847 : checkFour 847 (68,0,68,0) = true := by
  simp only [checkFour, w847_0,w847_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one847 : Coverage 847 848 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases847)
private theorem w848_0 : checkWitness 848 false false 60 = true := by decide +kernel
private theorem w848_2 : checkWitness 848 true false 60 = true := by decide +kernel
private theorem cases848 : checkFour 848 (60,0,60,0) = true := by
  simp only [checkFour, w848_0,w848_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one848 : Coverage 848 849 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases848)
private theorem w849_0 : checkWitness 849 false false 623 = true := by decide +kernel
private theorem w849_1 : checkWitness 849 false true 4715 = true := by decide +kernel
private theorem w849_2 : checkWitness 849 true false 623 = true := by decide +kernel
private theorem w849_3 : checkWitness 849 true true 4715 = true := by decide +kernel
private theorem cases849 : checkFour 849 (623,4715,623,4715) = true := by
  simp only [checkFour, w849_0,w849_1,w849_2,w849_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one849 : Coverage 849 850 := checkList_sound (ws:=[(623,4715,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases849)
private theorem w850_0 : checkWitness 850 false false 8884 = true := by decide +kernel
private theorem w850_2 : checkWitness 850 true false 8880 = true := by decide +kernel
private theorem cases850 : checkFour 850 (8884,0,8880,0) = true := by
  simp only [checkFour, w850_0,w850_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one850 : Coverage 850 851 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases850)
private theorem w851_0 : checkWitness 851 false false 60 = true := by decide +kernel
private theorem w851_2 : checkWitness 851 true false 60 = true := by decide +kernel
private theorem cases851 : checkFour 851 (60,0,60,0) = true := by
  simp only [checkFour, w851_0,w851_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one851 : Coverage 851 852 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases851)
private theorem w852_0 : checkWitness 852 false false 578 = true := by decide +kernel
private theorem w852_1 : checkWitness 852 false true 4674 = true := by decide +kernel
private theorem w852_2 : checkWitness 852 true false 578 = true := by decide +kernel
private theorem w852_3 : checkWitness 852 true true 4674 = true := by decide +kernel
private theorem cases852 : checkFour 852 (578,4674,578,4674) = true := by
  simp only [checkFour, w852_0,w852_1,w852_2,w852_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one852 : Coverage 852 853 := checkList_sound (ws:=[(578,4674,578,4674)]) (by simpa only [checkList, Bool.and_true] using cases852)
private theorem w853_0 : checkWitness 853 false false 8919 = true := by decide +kernel
private theorem w853_2 : checkWitness 853 true false 8915 = true := by decide +kernel
private theorem cases853 : checkFour 853 (8919,0,8915,0) = true := by
  simp only [checkFour, w853_0,w853_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one853 : Coverage 853 854 := checkList_sound (ws:=[(8919,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases853)
private theorem w854_0 : checkWitness 854 false false 8954 = true := by decide +kernel
private theorem w854_2 : checkWitness 854 true false 8945 = true := by decide +kernel
private theorem cases854 : checkFour 854 (8954,0,8945,0) = true := by
  simp only [checkFour, w854_0,w854_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one854 : Coverage 854 855 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases854)
private theorem w855_0 : checkWitness 855 false false 78 = true := by decide +kernel
private theorem w855_2 : checkWitness 855 true false 78 = true := by decide +kernel
private theorem cases855 : checkFour 855 (78,0,78,0) = true := by
  simp only [checkFour, w855_0,w855_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one855 : Coverage 855 856 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases855)
private theorem w856_0 : checkWitness 856 false false 666 = true := by decide +kernel
private theorem w856_1 : checkWitness 856 false true 4758 = true := by decide +kernel
private theorem w856_2 : checkWitness 856 true false 657 = true := by decide +kernel
private theorem w856_3 : checkWitness 856 true true 4749 = true := by decide +kernel
private theorem cases856 : checkFour 856 (666,4758,657,4749) = true := by
  simp only [checkFour, w856_0,w856_1,w856_2,w856_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one856 : Coverage 856 857 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases856)
private theorem w857_0 : checkWitness 857 false false 8915 = true := by decide +kernel
private theorem w857_2 : checkWitness 857 true false 8911 = true := by decide +kernel
private theorem cases857 : checkFour 857 (8915,0,8911,0) = true := by
  simp only [checkFour, w857_0,w857_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one857 : Coverage 857 858 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases857)
private theorem w858_0 : checkWitness 858 false false 660 = true := by decide +kernel
private theorem w858_1 : checkWitness 858 false true 4752 = true := by decide +kernel
private theorem w858_2 : checkWitness 858 true false 651 = true := by decide +kernel
private theorem w858_3 : checkWitness 858 true true 4743 = true := by decide +kernel
private theorem cases858 : checkFour 858 (660,4752,651,4743) = true := by
  simp only [checkFour, w858_0,w858_1,w858_2,w858_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one858 : Coverage 858 859 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases858)
private theorem w859_0 : checkWitness 859 false false 8884 = true := by decide +kernel
private theorem w859_2 : checkWitness 859 true false 8880 = true := by decide +kernel
private theorem cases859 : checkFour 859 (8884,0,8880,0) = true := by
  simp only [checkFour, w859_0,w859_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one859 : Coverage 859 860 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases859)
private theorem w860_0 : checkWitness 860 false false 66 = true := by decide +kernel
private theorem w860_2 : checkWitness 860 true false 66 = true := by decide +kernel
private theorem cases860 : checkFour 860 (66,0,66,0) = true := by
  simp only [checkFour, w860_0,w860_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one860 : Coverage 860 861 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases860)
private theorem w861_0 : checkWitness 861 false false 58 = true := by decide +kernel
private theorem w861_2 : checkWitness 861 true false 58 = true := by decide +kernel
private theorem cases861 : checkFour 861 (58,0,58,0) = true := by
  simp only [checkFour, w861_0,w861_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one861 : Coverage 861 862 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases861)
private theorem w862_0 : checkWitness 862 false false 631 = true := by decide +kernel
private theorem w862_1 : checkWitness 862 false true 4715 = true := by decide +kernel
private theorem w862_2 : checkWitness 862 true false 631 = true := by decide +kernel
private theorem w862_3 : checkWitness 862 true true 4715 = true := by decide +kernel
private theorem cases862 : checkFour 862 (631,4715,631,4715) = true := by
  simp only [checkFour, w862_0,w862_1,w862_2,w862_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one862 : Coverage 862 863 := checkList_sound (ws:=[(631,4715,631,4715)]) (by simpa only [checkList, Bool.and_true] using cases862)
private theorem w863_0 : checkWitness 863 false false 8900 = true := by decide +kernel
private theorem w863_2 : checkWitness 863 true false 8896 = true := by decide +kernel
private theorem cases863 : checkFour 863 (8900,0,8896,0) = true := by
  simp only [checkFour, w863_0,w863_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one863 : Coverage 863 864 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases863)
theorem cover0832 : Coverage 832 864 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one832 one833) (Coverage.join one834 one835)) (Coverage.join (Coverage.join one836 one837) (Coverage.join one838 one839))) (Coverage.join (Coverage.join (Coverage.join one840 one841) (Coverage.join one842 one843)) (Coverage.join (Coverage.join one844 one845) (Coverage.join one846 one847)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one848 one849) (Coverage.join one850 one851)) (Coverage.join (Coverage.join one852 one853) (Coverage.join one854 one855))) (Coverage.join (Coverage.join (Coverage.join one856 one857) (Coverage.join one858 one859)) (Coverage.join (Coverage.join one860 one861) (Coverage.join one862 one863)))))
end NF180PA.Symbolic
