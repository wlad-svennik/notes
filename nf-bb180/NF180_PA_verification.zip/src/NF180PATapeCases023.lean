import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w736_0 : checkWitness 736 false false 80 = true := by decide +kernel
private theorem w736_2 : checkWitness 736 true false 80 = true := by decide +kernel
private theorem cases736 : checkFour 736 (80,0,80,0) = true := by
  simp only [checkFour, w736_0,w736_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one736 : Coverage 736 737 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases736)
private theorem w737_0 : checkWitness 737 false false 8900 = true := by decide +kernel
private theorem w737_2 : checkWitness 737 true false 8896 = true := by decide +kernel
private theorem cases737 : checkFour 737 (8900,0,8896,0) = true := by
  simp only [checkFour, w737_0,w737_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one737 : Coverage 737 738 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases737)
private theorem w738_0 : checkWitness 738 false false 592 = true := by decide +kernel
private theorem w738_1 : checkWitness 738 false true 4688 = true := by decide +kernel
private theorem w738_2 : checkWitness 738 true false 592 = true := by decide +kernel
private theorem w738_3 : checkWitness 738 true true 4688 = true := by decide +kernel
private theorem cases738 : checkFour 738 (592,4688,592,4688) = true := by
  simp only [checkFour, w738_0,w738_1,w738_2,w738_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one738 : Coverage 738 739 := checkList_sound (ws:=[(592,4688,592,4688)]) (by simpa only [checkList, Bool.and_true] using cases738)
private theorem w739_0 : checkWitness 739 false false 8954 = true := by decide +kernel
private theorem w739_2 : checkWitness 739 true false 8945 = true := by decide +kernel
private theorem cases739 : checkFour 739 (8954,0,8945,0) = true := by
  simp only [checkFour, w739_0,w739_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one739 : Coverage 739 740 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases739)
private theorem w740_0 : checkWitness 740 false false 64 = true := by decide +kernel
private theorem w740_2 : checkWitness 740 true false 64 = true := by decide +kernel
private theorem cases740 : checkFour 740 (64,0,64,0) = true := by
  simp only [checkFour, w740_0,w740_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one740 : Coverage 740 741 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases740)
private theorem w741_0 : checkWitness 741 false false 536 = true := by decide +kernel
private theorem w741_1 : checkWitness 741 false true 4632 = true := by decide +kernel
private theorem w741_2 : checkWitness 741 true false 536 = true := by decide +kernel
private theorem w741_3 : checkWitness 741 true true 4632 = true := by decide +kernel
private theorem cases741 : checkFour 741 (536,4632,536,4632) = true := by
  simp only [checkFour, w741_0,w741_1,w741_2,w741_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one741 : Coverage 741 742 := checkList_sound (ws:=[(536,4632,536,4632)]) (by simpa only [checkList, Bool.and_true] using cases741)
private theorem w742_0 : checkWitness 742 false false 8894 = true := by decide +kernel
private theorem w742_2 : checkWitness 742 true false 8890 = true := by decide +kernel
private theorem cases742 : checkFour 742 (8894,0,8890,0) = true := by
  simp only [checkFour, w742_0,w742_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one742 : Coverage 742 743 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases742)
private theorem w743_0 : checkWitness 743 false false 66 = true := by decide +kernel
private theorem w743_2 : checkWitness 743 true false 66 = true := by decide +kernel
private theorem cases743 : checkFour 743 (66,0,66,0) = true := by
  simp only [checkFour, w743_0,w743_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one743 : Coverage 743 744 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases743)
private theorem w744_0 : checkWitness 744 false false 574 = true := by decide +kernel
private theorem w744_1 : checkWitness 744 false true 4670 = true := by decide +kernel
private theorem w744_2 : checkWitness 744 true false 574 = true := by decide +kernel
private theorem w744_3 : checkWitness 744 true true 4670 = true := by decide +kernel
private theorem cases744 : checkFour 744 (574,4670,574,4670) = true := by
  simp only [checkFour, w744_0,w744_1,w744_2,w744_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one744 : Coverage 744 745 := checkList_sound (ws:=[(574,4670,574,4670)]) (by simpa only [checkList, Bool.and_true] using cases744)
private theorem w745_0 : checkWitness 745 false false 8915 = true := by decide +kernel
private theorem w745_2 : checkWitness 745 true false 8911 = true := by decide +kernel
private theorem cases745 : checkFour 745 (8915,0,8911,0) = true := by
  simp only [checkFour, w745_0,w745_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one745 : Coverage 745 746 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases745)
private theorem w746_0 : checkWitness 746 false false 8950 = true := by decide +kernel
private theorem w746_2 : checkWitness 746 true false 8941 = true := by decide +kernel
private theorem cases746 : checkFour 746 (8950,0,8941,0) = true := by
  simp only [checkFour, w746_0,w746_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one746 : Coverage 746 747 := checkList_sound (ws:=[(8950,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases746)
private theorem w747_0 : checkWitness 747 false false 90 = true := by decide +kernel
private theorem w747_2 : checkWitness 747 true false 90 = true := by decide +kernel
private theorem cases747 : checkFour 747 (90,0,90,0) = true := by
  simp only [checkFour, w747_0,w747_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one747 : Coverage 747 748 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases747)
private theorem w748_0 : checkWitness 748 false false 662 = true := by decide +kernel
private theorem w748_1 : checkWitness 748 false true 4754 = true := by decide +kernel
private theorem w748_2 : checkWitness 748 true false 653 = true := by decide +kernel
private theorem w748_3 : checkWitness 748 true true 4745 = true := by decide +kernel
private theorem cases748 : checkFour 748 (662,4754,653,4745) = true := by
  simp only [checkFour, w748_0,w748_1,w748_2,w748_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one748 : Coverage 748 749 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases748)
private theorem w749_0 : checkWitness 749 false false 8911 = true := by decide +kernel
private theorem w749_2 : checkWitness 749 true false 8907 = true := by decide +kernel
private theorem cases749 : checkFour 749 (8911,0,8907,0) = true := by
  simp only [checkFour, w749_0,w749_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one749 : Coverage 749 750 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases749)
private theorem w750_0 : checkWitness 750 false false 656 = true := by decide +kernel
private theorem w750_1 : checkWitness 750 false true 4748 = true := by decide +kernel
private theorem w750_2 : checkWitness 750 true false 647 = true := by decide +kernel
private theorem w750_3 : checkWitness 750 true true 4739 = true := by decide +kernel
private theorem cases750 : checkFour 750 (656,4748,647,4739) = true := by
  simp only [checkFour, w750_0,w750_1,w750_2,w750_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one750 : Coverage 750 751 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases750)
private theorem w751_0 : checkWitness 751 false false 8880 = true := by decide +kernel
private theorem w751_2 : checkWitness 751 true false 8876 = true := by decide +kernel
private theorem cases751 : checkFour 751 (8880,0,8876,0) = true := by
  simp only [checkFour, w751_0,w751_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one751 : Coverage 751 752 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases751)
private theorem w752_0 : checkWitness 752 false false 78 = true := by decide +kernel
private theorem w752_2 : checkWitness 752 true false 78 = true := by decide +kernel
private theorem cases752 : checkFour 752 (78,0,78,0) = true := by
  simp only [checkFour, w752_0,w752_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one752 : Coverage 752 753 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases752)
private theorem w753_0 : checkWitness 753 false false 70 = true := by decide +kernel
private theorem w753_2 : checkWitness 753 true false 70 = true := by decide +kernel
private theorem cases753 : checkFour 753 (70,0,70,0) = true := by
  simp only [checkFour, w753_0,w753_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one753 : Coverage 753 754 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases753)
private theorem w754_0 : checkWitness 754 false false 621 = true := by decide +kernel
private theorem w754_1 : checkWitness 754 false true 4705 = true := by decide +kernel
private theorem w754_2 : checkWitness 754 true false 621 = true := by decide +kernel
private theorem w754_3 : checkWitness 754 true true 4705 = true := by decide +kernel
private theorem cases754 : checkFour 754 (621,4705,621,4705) = true := by
  simp only [checkFour, w754_0,w754_1,w754_2,w754_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one754 : Coverage 754 755 := checkList_sound (ws:=[(621,4705,621,4705)]) (by simpa only [checkList, Bool.and_true] using cases754)
private theorem w755_0 : checkWitness 755 false false 8874 = true := by decide +kernel
private theorem w755_2 : checkWitness 755 true false 8870 = true := by decide +kernel
private theorem cases755 : checkFour 755 (8874,0,8870,0) = true := by
  simp only [checkFour, w755_0,w755_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one755 : Coverage 755 756 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases755)
private theorem w756_0 : checkWitness 756 false false 70 = true := by decide +kernel
private theorem w756_2 : checkWitness 756 true false 70 = true := by decide +kernel
private theorem cases756 : checkFour 756 (70,0,70,0) = true := by
  simp only [checkFour, w756_0,w756_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one756 : Coverage 756 757 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases756)
private theorem w757_0 : checkWitness 757 false false 626 = true := by decide +kernel
private theorem w757_1 : checkWitness 757 false true 4722 = true := by decide +kernel
private theorem w757_2 : checkWitness 757 true false 626 = true := by decide +kernel
private theorem w757_3 : checkWitness 757 true true 4722 = true := by decide +kernel
private theorem cases757 : checkFour 757 (626,4722,626,4722) = true := by
  simp only [checkFour, w757_0,w757_1,w757_2,w757_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one757 : Coverage 757 758 := checkList_sound (ws:=[(626,4722,626,4722)]) (by simpa only [checkList, Bool.and_true] using cases757)
private theorem w758_0 : checkWitness 758 false false 8942 = true := by decide +kernel
private theorem w758_2 : checkWitness 758 true false 8933 = true := by decide +kernel
private theorem cases758 : checkFour 758 (8942,0,8933,0) = true := by
  simp only [checkFour, w758_0,w758_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one758 : Coverage 758 759 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases758)
private theorem w759_0 : checkWitness 759 false false 8888 = true := by decide +kernel
private theorem w759_2 : checkWitness 759 true false 8884 = true := by decide +kernel
private theorem cases759 : checkFour 759 (8888,0,8884,0) = true := by
  simp only [checkFour, w759_0,w759_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one759 : Coverage 759 760 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases759)
private theorem w760_0 : checkWitness 760 false false 78 = true := by decide +kernel
private theorem w760_2 : checkWitness 760 true false 78 = true := by decide +kernel
private theorem cases760 : checkFour 760 (78,0,78,0) = true := by
  simp only [checkFour, w760_0,w760_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one760 : Coverage 760 761 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases760)
private theorem w761_0 : checkWitness 761 false false 672 = true := by decide +kernel
private theorem w761_1 : checkWitness 761 false true 4760 = true := by decide +kernel
private theorem w761_2 : checkWitness 761 true false 663 = true := by decide +kernel
private theorem w761_3 : checkWitness 761 true true 4751 = true := by decide +kernel
private theorem cases761 : checkFour 761 (672,4760,663,4751) = true := by
  simp only [checkFour, w761_0,w761_1,w761_2,w761_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one761 : Coverage 761 762 := checkList_sound (ws:=[(672,4760,663,4751)]) (by simpa only [checkList, Bool.and_true] using cases761)
private theorem w762_0 : checkWitness 762 false false 8930 = true := by decide +kernel
private theorem w762_2 : checkWitness 762 true false 8926 = true := by decide +kernel
private theorem cases762 : checkFour 762 (8930,0,8926,0) = true := by
  simp only [checkFour, w762_0,w762_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one762 : Coverage 762 763 := checkList_sound (ws:=[(8930,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases762)
private theorem w763_0 : checkWitness 763 false false 68 = true := by decide +kernel
private theorem w763_2 : checkWitness 763 true false 68 = true := by decide +kernel
private theorem cases763 : checkFour 763 (68,0,68,0) = true := by
  simp only [checkFour, w763_0,w763_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one763 : Coverage 763 764 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases763)
private theorem w764_0 : checkWitness 764 false false 710 = true := by decide +kernel
private theorem w764_1 : checkWitness 764 false true 4806 = true := by decide +kernel
private theorem w764_2 : checkWitness 764 true false 710 = true := by decide +kernel
private theorem w764_3 : checkWitness 764 true true 4806 = true := by decide +kernel
private theorem cases764 : checkFour 764 (710,4806,710,4806) = true := by
  simp only [checkFour, w764_0,w764_1,w764_2,w764_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one764 : Coverage 764 765 := checkList_sound (ws:=[(710,4806,710,4806)]) (by simpa only [checkList, Bool.and_true] using cases764)
private theorem w765_0 : checkWitness 765 false false 8970 = true := by decide +kernel
private theorem w765_2 : checkWitness 765 true false 8961 = true := by decide +kernel
private theorem cases765 : checkFour 765 (8970,0,8961,0) = true := by
  simp only [checkFour, w765_0,w765_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one765 : Coverage 765 766 := checkList_sound (ws:=[(8970,0,8961,0)]) (by simpa only [checkList, Bool.and_true] using cases765)
private theorem w766_0 : checkWitness 766 false false 76 = true := by decide +kernel
private theorem w766_2 : checkWitness 766 true false 76 = true := by decide +kernel
private theorem cases766 : checkFour 766 (76,0,76,0) = true := by
  simp only [checkFour, w766_0,w766_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one766 : Coverage 766 767 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases766)
private theorem w767_0 : checkWitness 767 false false 552 = true := by decide +kernel
private theorem w767_1 : checkWitness 767 false true 4648 = true := by decide +kernel
private theorem w767_2 : checkWitness 767 true false 552 = true := by decide +kernel
private theorem w767_3 : checkWitness 767 true true 4648 = true := by decide +kernel
private theorem cases767 : checkFour 767 (552,4648,552,4648) = true := by
  simp only [checkFour, w767_0,w767_1,w767_2,w767_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one767 : Coverage 767 768 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases767)
theorem cover0736 : Coverage 736 768 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one736 one737) (Coverage.join one738 one739)) (Coverage.join (Coverage.join one740 one741) (Coverage.join one742 one743))) (Coverage.join (Coverage.join (Coverage.join one744 one745) (Coverage.join one746 one747)) (Coverage.join (Coverage.join one748 one749) (Coverage.join one750 one751)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one752 one753) (Coverage.join one754 one755)) (Coverage.join (Coverage.join one756 one757) (Coverage.join one758 one759))) (Coverage.join (Coverage.join (Coverage.join one760 one761) (Coverage.join one762 one763)) (Coverage.join (Coverage.join one764 one765) (Coverage.join one766 one767)))))
end NF180PA.Symbolic
