import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w416_0 : checkWitness 416 false false 8898 = true := by decide +kernel
private theorem w416_2 : checkWitness 416 true false 8894 = true := by decide +kernel
private theorem cases416 : checkFour 416 (8898,0,8894,0) = true := by
  simp only [checkFour, w416_0,w416_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one416 : Coverage 416 417 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases416)
private theorem w417_0 : checkWitness 417 false false 78 = true := by decide +kernel
private theorem w417_2 : checkWitness 417 true false 78 = true := by decide +kernel
private theorem cases417 : checkFour 417 (78,0,78,0) = true := by
  simp only [checkFour, w417_0,w417_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one417 : Coverage 417 418 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases417)
private theorem w418_0 : checkWitness 418 false false 643 = true := by decide +kernel
private theorem w418_1 : checkWitness 418 false true 4735 = true := by decide +kernel
private theorem w418_2 : checkWitness 418 true false 634 = true := by decide +kernel
private theorem w418_3 : checkWitness 418 true true 4726 = true := by decide +kernel
private theorem cases418 : checkFour 418 (643,4735,634,4726) = true := by
  simp only [checkFour, w418_0,w418_1,w418_2,w418_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one418 : Coverage 418 419 := checkList_sound (ws:=[(643,4735,634,4726)]) (by simpa only [checkList, Bool.and_true] using cases418)
private theorem w419_0 : checkWitness 419 false false 8940 = true := by decide +kernel
private theorem w419_2 : checkWitness 419 true false 8931 = true := by decide +kernel
private theorem cases419 : checkFour 419 (8940,0,8931,0) = true := by
  simp only [checkFour, w419_0,w419_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one419 : Coverage 419 420 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases419)
private theorem w420_0 : checkWitness 420 false false 8886 = true := by decide +kernel
private theorem w420_2 : checkWitness 420 true false 8882 = true := by decide +kernel
private theorem cases420 : checkFour 420 (8886,0,8882,0) = true := by
  simp only [checkFour, w420_0,w420_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one420 : Coverage 420 421 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases420)
private theorem w421_0 : checkWitness 421 false false 72 = true := by decide +kernel
private theorem w421_2 : checkWitness 421 true false 72 = true := by decide +kernel
private theorem cases421 : checkFour 421 (72,0,72,0) = true := by
  simp only [checkFour, w421_0,w421_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one421 : Coverage 421 422 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases421)
private theorem w422_0 : checkWitness 422 false false 670 = true := by decide +kernel
private theorem w422_1 : checkWitness 422 false true 4762 = true := by decide +kernel
private theorem w422_2 : checkWitness 422 true false 661 = true := by decide +kernel
private theorem w422_3 : checkWitness 422 true true 4753 = true := by decide +kernel
private theorem cases422 : checkFour 422 (670,4762,661,4753) = true := by
  simp only [checkFour, w422_0,w422_1,w422_2,w422_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one422 : Coverage 422 423 := checkList_sound (ws:=[(670,4762,661,4753)]) (by simpa only [checkList, Bool.and_true] using cases422)
private theorem w423_0 : checkWitness 423 false false 8947 = true := by decide +kernel
private theorem w423_2 : checkWitness 423 true false 8938 = true := by decide +kernel
private theorem cases423 : checkFour 423 (8947,0,8938,0) = true := by
  simp only [checkFour, w423_0,w423_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one423 : Coverage 423 424 := checkList_sound (ws:=[(8947,0,8938,0)]) (by simpa only [checkList, Bool.and_true] using cases423)
private theorem w424_0 : checkWitness 424 false false 56 = true := by decide +kernel
private theorem w424_2 : checkWitness 424 true false 56 = true := by decide +kernel
private theorem cases424 : checkFour 424 (56,0,56,0) = true := by
  simp only [checkFour, w424_0,w424_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one424 : Coverage 424 425 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases424)
private theorem w425_0 : checkWitness 425 false false 712 = true := by decide +kernel
private theorem w425_1 : checkWitness 425 false true 4808 = true := by decide +kernel
private theorem w425_2 : checkWitness 425 true false 712 = true := by decide +kernel
private theorem w425_3 : checkWitness 425 true true 4808 = true := by decide +kernel
private theorem cases425 : checkFour 425 (712,4808,712,4808) = true := by
  simp only [checkFour, w425_0,w425_1,w425_2,w425_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one425 : Coverage 425 426 := checkList_sound (ws:=[(712,4808,712,4808)]) (by simpa only [checkList, Bool.and_true] using cases425)
private theorem w426_0 : checkWitness 426 false false 8974 = true := by decide +kernel
private theorem w426_2 : checkWitness 426 true false 8965 = true := by decide +kernel
private theorem cases426 : checkFour 426 (8974,0,8965,0) = true := by
  simp only [checkFour, w426_0,w426_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one426 : Coverage 426 427 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases426)
private theorem w427_0 : checkWitness 427 false false 74 = true := by decide +kernel
private theorem w427_2 : checkWitness 427 true false 74 = true := by decide +kernel
private theorem cases427 : checkFour 427 (74,0,74,0) = true := by
  simp only [checkFour, w427_0,w427_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one427 : Coverage 427 428 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases427)
private theorem w428_0 : checkWitness 428 false false 556 = true := by decide +kernel
private theorem w428_1 : checkWitness 428 false true 4652 = true := by decide +kernel
private theorem w428_2 : checkWitness 428 true false 556 = true := by decide +kernel
private theorem w428_3 : checkWitness 428 true true 4652 = true := by decide +kernel
private theorem cases428 : checkFour 428 (556,4652,556,4652) = true := by
  simp only [checkFour, w428_0,w428_1,w428_2,w428_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one428 : Coverage 428 429 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases428)
private theorem w429_0 : checkWitness 429 false false 8914 = true := by decide +kernel
private theorem w429_2 : checkWitness 429 true false 8910 = true := by decide +kernel
private theorem cases429 : checkFour 429 (8914,0,8910,0) = true := by
  simp only [checkFour, w429_0,w429_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one429 : Coverage 429 430 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases429)
private theorem w430_0 : checkWitness 430 false false 76 = true := by decide +kernel
private theorem w430_2 : checkWitness 430 true false 76 = true := by decide +kernel
private theorem cases430 : checkFour 430 (76,0,76,0) = true := by
  simp only [checkFour, w430_0,w430_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one430 : Coverage 430 431 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases430)
private theorem w431_0 : checkWitness 431 false false 594 = true := by decide +kernel
private theorem w431_1 : checkWitness 431 false true 4690 = true := by decide +kernel
private theorem w431_2 : checkWitness 431 true false 594 = true := by decide +kernel
private theorem w431_3 : checkWitness 431 true true 4690 = true := by decide +kernel
private theorem cases431 : checkFour 431 (594,4690,594,4690) = true := by
  simp only [checkFour, w431_0,w431_1,w431_2,w431_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one431 : Coverage 431 432 := checkList_sound (ws:=[(594,4690,594,4690)]) (by simpa only [checkList, Bool.and_true] using cases431)
private theorem w432_0 : checkWitness 432 false false 8935 = true := by decide +kernel
private theorem w432_2 : checkWitness 432 true false 8931 = true := by decide +kernel
private theorem cases432 : checkFour 432 (8935,0,8931,0) = true := by
  simp only [checkFour, w432_0,w432_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one432 : Coverage 432 433 := checkList_sound (ws:=[(8935,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases432)
private theorem w433_0 : checkWitness 433 false false 8970 = true := by decide +kernel
private theorem w433_2 : checkWitness 433 true false 8961 = true := by decide +kernel
private theorem cases433 : checkFour 433 (8970,0,8961,0) = true := by
  simp only [checkFour, w433_0,w433_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one433 : Coverage 433 434 := checkList_sound (ws:=[(8970,0,8961,0)]) (by simpa only [checkList, Bool.and_true] using cases433)
private theorem w434_0 : checkWitness 434 false false 100 = true := by decide +kernel
private theorem w434_2 : checkWitness 434 true false 100 = true := by decide +kernel
private theorem cases434 : checkFour 434 (100,0,100,0) = true := by
  simp only [checkFour, w434_0,w434_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one434 : Coverage 434 435 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases434)
private theorem w435_0 : checkWitness 435 false false 682 = true := by decide +kernel
private theorem w435_1 : checkWitness 435 false true 4774 = true := by decide +kernel
private theorem w435_2 : checkWitness 435 true false 673 = true := by decide +kernel
private theorem w435_3 : checkWitness 435 true true 4765 = true := by decide +kernel
private theorem cases435 : checkFour 435 (682,4774,673,4765) = true := by
  simp only [checkFour, w435_0,w435_1,w435_2,w435_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one435 : Coverage 435 436 := checkList_sound (ws:=[(682,4774,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases435)
private theorem w436_0 : checkWitness 436 false false 8931 = true := by decide +kernel
private theorem w436_2 : checkWitness 436 true false 8927 = true := by decide +kernel
private theorem cases436 : checkFour 436 (8931,0,8927,0) = true := by
  simp only [checkFour, w436_0,w436_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one436 : Coverage 436 437 := checkList_sound (ws:=[(8931,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases436)
private theorem w437_0 : checkWitness 437 false false 676 = true := by decide +kernel
private theorem w437_1 : checkWitness 437 false true 4768 = true := by decide +kernel
private theorem w437_2 : checkWitness 437 true false 667 = true := by decide +kernel
private theorem w437_3 : checkWitness 437 true true 4759 = true := by decide +kernel
private theorem cases437 : checkFour 437 (676,4768,667,4759) = true := by
  simp only [checkFour, w437_0,w437_1,w437_2,w437_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one437 : Coverage 437 438 := checkList_sound (ws:=[(676,4768,667,4759)]) (by simpa only [checkList, Bool.and_true] using cases437)
private theorem w438_0 : checkWitness 438 false false 8900 = true := by decide +kernel
private theorem w438_2 : checkWitness 438 true false 8896 = true := by decide +kernel
private theorem cases438 : checkFour 438 (8900,0,8896,0) = true := by
  simp only [checkFour, w438_0,w438_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one438 : Coverage 438 439 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases438)
private theorem w439_0 : checkWitness 439 false false 88 = true := by decide +kernel
private theorem w439_2 : checkWitness 439 true false 88 = true := by decide +kernel
private theorem cases439 : checkFour 439 (88,0,88,0) = true := by
  simp only [checkFour, w439_0,w439_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one439 : Coverage 439 440 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases439)
private theorem w440_0 : checkWitness 440 false false 80 = true := by decide +kernel
private theorem w440_2 : checkWitness 440 true false 80 = true := by decide +kernel
private theorem cases440 : checkFour 440 (80,0,80,0) = true := by
  simp only [checkFour, w440_0,w440_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one440 : Coverage 440 441 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases440)
private theorem w441_0 : checkWitness 441 false false 641 = true := by decide +kernel
private theorem w441_1 : checkWitness 441 false true 4725 = true := by decide +kernel
private theorem w441_2 : checkWitness 441 true false 641 = true := by decide +kernel
private theorem w441_3 : checkWitness 441 true true 4725 = true := by decide +kernel
private theorem cases441 : checkFour 441 (641,4725,641,4725) = true := by
  simp only [checkFour, w441_0,w441_1,w441_2,w441_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one441 : Coverage 441 442 := checkList_sound (ws:=[(641,4725,641,4725)]) (by simpa only [checkList, Bool.and_true] using cases441)
private theorem w442_0 : checkWitness 442 false false 8894 = true := by decide +kernel
private theorem w442_2 : checkWitness 442 true false 8890 = true := by decide +kernel
private theorem cases442 : checkFour 442 (8894,0,8890,0) = true := by
  simp only [checkFour, w442_0,w442_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one442 : Coverage 442 443 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases442)
private theorem w443_0 : checkWitness 443 false false 80 = true := by decide +kernel
private theorem w443_2 : checkWitness 443 true false 80 = true := by decide +kernel
private theorem cases443 : checkFour 443 (80,0,80,0) = true := by
  simp only [checkFour, w443_0,w443_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one443 : Coverage 443 444 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases443)
private theorem w444_0 : checkWitness 444 false false 639 = true := by decide +kernel
private theorem w444_1 : checkWitness 444 false true 4731 = true := by decide +kernel
private theorem w444_2 : checkWitness 444 true false 630 = true := by decide +kernel
private theorem w444_3 : checkWitness 444 true true 4722 = true := by decide +kernel
private theorem cases444 : checkFour 444 (639,4731,630,4722) = true := by
  simp only [checkFour, w444_0,w444_1,w444_2,w444_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one444 : Coverage 444 445 := checkList_sound (ws:=[(639,4731,630,4722)]) (by simpa only [checkList, Bool.and_true] using cases444)
private theorem w445_0 : checkWitness 445 false false 8936 = true := by decide +kernel
private theorem w445_2 : checkWitness 445 true false 8927 = true := by decide +kernel
private theorem cases445 : checkFour 445 (8936,0,8927,0) = true := by
  simp only [checkFour, w445_0,w445_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one445 : Coverage 445 446 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases445)
private theorem w446_0 : checkWitness 446 false false 8882 = true := by decide +kernel
private theorem w446_2 : checkWitness 446 true false 8878 = true := by decide +kernel
private theorem cases446 : checkFour 446 (8882,0,8878,0) = true := by
  simp only [checkFour, w446_0,w446_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one446 : Coverage 446 447 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases446)
private theorem w447_0 : checkWitness 447 false false 74 = true := by decide +kernel
private theorem w447_2 : checkWitness 447 true false 74 = true := by decide +kernel
private theorem cases447 : checkFour 447 (74,0,74,0) = true := by
  simp only [checkFour, w447_0,w447_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one447 : Coverage 447 448 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases447)
theorem cover0416 : Coverage 416 448 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one416 one417) (Coverage.join one418 one419)) (Coverage.join (Coverage.join one420 one421) (Coverage.join one422 one423))) (Coverage.join (Coverage.join (Coverage.join one424 one425) (Coverage.join one426 one427)) (Coverage.join (Coverage.join one428 one429) (Coverage.join one430 one431)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one432 one433) (Coverage.join one434 one435)) (Coverage.join (Coverage.join one436 one437) (Coverage.join one438 one439))) (Coverage.join (Coverage.join (Coverage.join one440 one441) (Coverage.join one442 one443)) (Coverage.join (Coverage.join one444 one445) (Coverage.join one446 one447)))))
end NF180PA.Symbolic
