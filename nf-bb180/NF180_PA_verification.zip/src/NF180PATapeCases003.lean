import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w96_0 : checkWitness 96 false false 8886 = true := by decide +kernel
private theorem w96_2 : checkWitness 96 true false 8882 = true := by decide +kernel
private theorem cases96 : checkFour 96 (8886,0,8882,0) = true := by
  simp only [checkFour, w96_0,w96_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one96 : Coverage 96 97 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases96)
private theorem w97_0 : checkWitness 97 false false 64 = true := by decide +kernel
private theorem w97_2 : checkWitness 97 true false 64 = true := by decide +kernel
private theorem cases97 : checkFour 97 (64,0,64,0) = true := by
  simp only [checkFour, w97_0,w97_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one97 : Coverage 97 98 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases97)
private theorem w98_0 : checkWitness 98 false false 601 = true := by decide +kernel
private theorem w98_1 : checkWitness 98 false true 4697 = true := by decide +kernel
private theorem w98_2 : checkWitness 98 true false 601 = true := by decide +kernel
private theorem w98_3 : checkWitness 98 true true 4697 = true := by decide +kernel
private theorem cases98 : checkFour 98 (601,4697,601,4697) = true := by
  simp only [checkFour, w98_0,w98_1,w98_2,w98_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one98 : Coverage 98 99 := checkList_sound (ws:=[(601,4697,601,4697)]) (by simpa only [checkList, Bool.and_true] using cases98)
private theorem w99_0 : checkWitness 99 false false 8954 = true := by decide +kernel
private theorem w99_2 : checkWitness 99 true false 8945 = true := by decide +kernel
private theorem cases99 : checkFour 99 (8954,0,8945,0) = true := by
  simp only [checkFour, w99_0,w99_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one99 : Coverage 99 100 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases99)
private theorem w100_0 : checkWitness 100 false false 8900 = true := by decide +kernel
private theorem w100_2 : checkWitness 100 true false 8896 = true := by decide +kernel
private theorem cases100 : checkFour 100 (8900,0,8896,0) = true := by
  simp only [checkFour, w100_0,w100_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one100 : Coverage 100 101 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases100)
private theorem w101_0 : checkWitness 101 false false 72 = true := by decide +kernel
private theorem w101_2 : checkWitness 101 true false 72 = true := by decide +kernel
private theorem cases101 : checkFour 101 (72,0,72,0) = true := by
  simp only [checkFour, w101_0,w101_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one101 : Coverage 101 102 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases101)
private theorem w102_0 : checkWitness 102 false false 684 = true := by decide +kernel
private theorem w102_1 : checkWitness 102 false true 4772 = true := by decide +kernel
private theorem w102_2 : checkWitness 102 true false 675 = true := by decide +kernel
private theorem w102_3 : checkWitness 102 true true 4763 = true := by decide +kernel
private theorem cases102 : checkFour 102 (684,4772,675,4763) = true := by
  simp only [checkFour, w102_0,w102_1,w102_2,w102_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one102 : Coverage 102 103 := checkList_sound (ws:=[(684,4772,675,4763)]) (by simpa only [checkList, Bool.and_true] using cases102)
private theorem w103_0 : checkWitness 103 false false 8919 = true := by decide +kernel
private theorem w103_2 : checkWitness 103 true false 8915 = true := by decide +kernel
private theorem cases103 : checkFour 103 (8919,0,8915,0) = true := by
  simp only [checkFour, w103_0,w103_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one103 : Coverage 103 104 := checkList_sound (ws:=[(8919,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases103)
private theorem w104_0 : checkWitness 104 false false 62 = true := by decide +kernel
private theorem w104_2 : checkWitness 104 true false 62 = true := by decide +kernel
private theorem cases104 : checkFour 104 (62,0,62,0) = true := by
  simp only [checkFour, w104_0,w104_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one104 : Coverage 104 105 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases104)
private theorem w105_0 : checkWitness 105 false false 534 = true := by decide +kernel
private theorem w105_1 : checkWitness 105 false true 4630 = true := by decide +kernel
private theorem w105_2 : checkWitness 105 true false 534 = true := by decide +kernel
private theorem w105_3 : checkWitness 105 true true 4630 = true := by decide +kernel
private theorem cases105 : checkFour 105 (534,4630,534,4630) = true := by
  simp only [checkFour, w105_0,w105_1,w105_2,w105_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one105 : Coverage 105 106 := checkList_sound (ws:=[(534,4630,534,4630)]) (by simpa only [checkList, Bool.and_true] using cases105)
private theorem w106_0 : checkWitness 106 false false 8929 = true := by decide +kernel
private theorem w106_2 : checkWitness 106 true false 8925 = true := by decide +kernel
private theorem cases106 : checkFour 106 (8929,0,8925,0) = true := by
  simp only [checkFour, w106_0,w106_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one106 : Coverage 106 107 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases106)
private theorem w107_0 : checkWitness 107 false false 660 = true := by decide +kernel
private theorem w107_1 : checkWitness 107 false true 4756 = true := by decide +kernel
private theorem w107_2 : checkWitness 107 true false 651 = true := by decide +kernel
private theorem w107_3 : checkWitness 107 true true 4747 = true := by decide +kernel
private theorem cases107 : checkFour 107 (660,4756,651,4747) = true := by
  simp only [checkFour, w107_0,w107_1,w107_2,w107_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one107 : Coverage 107 108 := checkList_sound (ws:=[(660,4756,651,4747)]) (by simpa only [checkList, Bool.and_true] using cases107)
private theorem w108_0 : checkWitness 108 false false 196 = true := by decide +kernel
private theorem w108_2 : checkWitness 108 true false 196 = true := by decide +kernel
private theorem cases108 : checkFour 108 (196,0,196,0) = true := by
  simp only [checkFour, w108_0,w108_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one108 : Coverage 108 109 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases108)
private theorem w109_0 : checkWitness 109 false false 615 = true := by decide +kernel
private theorem w109_1 : checkWitness 109 false true 4703 = true := by decide +kernel
private theorem w109_2 : checkWitness 109 true false 615 = true := by decide +kernel
private theorem w109_3 : checkWitness 109 true true 4703 = true := by decide +kernel
private theorem cases109 : checkFour 109 (615,4703,615,4703) = true := by
  simp only [checkFour, w109_0,w109_1,w109_2,w109_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one109 : Coverage 109 110 := checkList_sound (ws:=[(615,4703,615,4703)]) (by simpa only [checkList, Bool.and_true] using cases109)
private theorem w110_0 : checkWitness 110 false false 8944 = true := by decide +kernel
private theorem w110_2 : checkWitness 110 true false 8935 = true := by decide +kernel
private theorem cases110 : checkFour 110 (8944,0,8935,0) = true := by
  simp only [checkFour, w110_0,w110_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one110 : Coverage 110 111 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases110)
private theorem w111_0 : checkWitness 111 false false 64 = true := by decide +kernel
private theorem w111_2 : checkWitness 111 true false 64 = true := by decide +kernel
private theorem cases111 : checkFour 111 (64,0,64,0) = true := by
  simp only [checkFour, w111_0,w111_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one111 : Coverage 111 112 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases111)
private theorem w112_0 : checkWitness 112 false false 56 = true := by decide +kernel
private theorem w112_2 : checkWitness 112 true false 56 = true := by decide +kernel
private theorem cases112 : checkFour 112 (56,0,56,0) = true := by
  simp only [checkFour, w112_0,w112_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one112 : Coverage 112 113 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases112)
private theorem w113_0 : checkWitness 113 false false 621 = true := by decide +kernel
private theorem w113_1 : checkWitness 113 false true 4713 = true := by decide +kernel
private theorem w113_2 : checkWitness 113 true false 621 = true := by decide +kernel
private theorem w113_3 : checkWitness 113 true true 4713 = true := by decide +kernel
private theorem cases113 : checkFour 113 (621,4713,621,4713) = true := by
  simp only [checkFour, w113_0,w113_1,w113_2,w113_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one113 : Coverage 113 114 := checkList_sound (ws:=[(621,4713,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases113)
private theorem w114_0 : checkWitness 114 false false 8882 = true := by decide +kernel
private theorem w114_2 : checkWitness 114 true false 8878 = true := by decide +kernel
private theorem cases114 : checkFour 114 (8882,0,8878,0) = true := by
  simp only [checkFour, w114_0,w114_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one114 : Coverage 114 115 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases114)
private theorem w115_0 : checkWitness 115 false false 56 = true := by decide +kernel
private theorem w115_2 : checkWitness 115 true false 56 = true := by decide +kernel
private theorem cases115 : checkFour 115 (56,0,56,0) = true := by
  simp only [checkFour, w115_0,w115_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one115 : Coverage 115 116 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases115)
private theorem w116_0 : checkWitness 116 false false 576 = true := by decide +kernel
private theorem w116_1 : checkWitness 116 false true 4672 = true := by decide +kernel
private theorem w116_2 : checkWitness 116 true false 576 = true := by decide +kernel
private theorem w116_3 : checkWitness 116 true true 4672 = true := by decide +kernel
private theorem cases116 : checkFour 116 (576,4672,576,4672) = true := by
  simp only [checkFour, w116_0,w116_1,w116_2,w116_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one116 : Coverage 116 117 := checkList_sound (ws:=[(576,4672,576,4672)]) (by simpa only [checkList, Bool.and_true] using cases116)
private theorem w117_0 : checkWitness 117 false false 8917 = true := by decide +kernel
private theorem w117_2 : checkWitness 117 true false 8913 = true := by decide +kernel
private theorem cases117 : checkFour 117 (8917,0,8913,0) = true := by
  simp only [checkFour, w117_0,w117_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one117 : Coverage 117 118 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases117)
private theorem w118_0 : checkWitness 118 false false 8952 = true := by decide +kernel
private theorem w118_2 : checkWitness 118 true false 8943 = true := by decide +kernel
private theorem cases118 : checkFour 118 (8952,0,8943,0) = true := by
  simp only [checkFour, w118_0,w118_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one118 : Coverage 118 119 := checkList_sound (ws:=[(8952,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases118)
private theorem w119_0 : checkWitness 119 false false 74 = true := by decide +kernel
private theorem w119_2 : checkWitness 119 true false 74 = true := by decide +kernel
private theorem cases119 : checkFour 119 (74,0,74,0) = true := by
  simp only [checkFour, w119_0,w119_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one119 : Coverage 119 120 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases119)
private theorem w120_0 : checkWitness 120 false false 664 = true := by decide +kernel
private theorem w120_1 : checkWitness 120 false true 4756 = true := by decide +kernel
private theorem w120_2 : checkWitness 120 true false 655 = true := by decide +kernel
private theorem w120_3 : checkWitness 120 true true 4747 = true := by decide +kernel
private theorem cases120 : checkFour 120 (664,4756,655,4747) = true := by
  simp only [checkFour, w120_0,w120_1,w120_2,w120_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one120 : Coverage 120 121 := checkList_sound (ws:=[(664,4756,655,4747)]) (by simpa only [checkList, Bool.and_true] using cases120)
private theorem w121_0 : checkWitness 121 false false 8913 = true := by decide +kernel
private theorem w121_2 : checkWitness 121 true false 8909 = true := by decide +kernel
private theorem cases121 : checkFour 121 (8913,0,8909,0) = true := by
  simp only [checkFour, w121_0,w121_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one121 : Coverage 121 122 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases121)
private theorem w122_0 : checkWitness 122 false false 658 = true := by decide +kernel
private theorem w122_1 : checkWitness 122 false true 4750 = true := by decide +kernel
private theorem w122_2 : checkWitness 122 true false 649 = true := by decide +kernel
private theorem w122_3 : checkWitness 122 true true 4741 = true := by decide +kernel
private theorem cases122 : checkFour 122 (658,4750,649,4741) = true := by
  simp only [checkFour, w122_0,w122_1,w122_2,w122_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one122 : Coverage 122 123 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases122)
private theorem w123_0 : checkWitness 123 false false 8882 = true := by decide +kernel
private theorem w123_2 : checkWitness 123 true false 8878 = true := by decide +kernel
private theorem cases123 : checkFour 123 (8882,0,8878,0) = true := by
  simp only [checkFour, w123_0,w123_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one123 : Coverage 123 124 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases123)
private theorem w124_0 : checkWitness 124 false false 62 = true := by decide +kernel
private theorem w124_2 : checkWitness 124 true false 62 = true := by decide +kernel
private theorem cases124 : checkFour 124 (62,0,62,0) = true := by
  simp only [checkFour, w124_0,w124_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one124 : Coverage 124 125 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases124)
private theorem w125_0 : checkWitness 125 false false 54 = true := by decide +kernel
private theorem w125_2 : checkWitness 125 true false 54 = true := by decide +kernel
private theorem cases125 : checkFour 125 (54,0,54,0) = true := by
  simp only [checkFour, w125_0,w125_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one125 : Coverage 125 126 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases125)
private theorem w126_0 : checkWitness 126 false false 629 = true := by decide +kernel
private theorem w126_1 : checkWitness 126 false true 4713 = true := by decide +kernel
private theorem w126_2 : checkWitness 126 true false 629 = true := by decide +kernel
private theorem w126_3 : checkWitness 126 true true 4713 = true := by decide +kernel
private theorem cases126 : checkFour 126 (629,4713,629,4713) = true := by
  simp only [checkFour, w126_0,w126_1,w126_2,w126_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one126 : Coverage 126 127 := checkList_sound (ws:=[(629,4713,629,4713)]) (by simpa only [checkList, Bool.and_true] using cases126)
private theorem w127_0 : checkWitness 127 false false 8898 = true := by decide +kernel
private theorem w127_2 : checkWitness 127 true false 8894 = true := by decide +kernel
private theorem cases127 : checkFour 127 (8898,0,8894,0) = true := by
  simp only [checkFour, w127_0,w127_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one127 : Coverage 127 128 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases127)
theorem cover0096 : Coverage 96 128 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one96 one97) (Coverage.join one98 one99)) (Coverage.join (Coverage.join one100 one101) (Coverage.join one102 one103))) (Coverage.join (Coverage.join (Coverage.join one104 one105) (Coverage.join one106 one107)) (Coverage.join (Coverage.join one108 one109) (Coverage.join one110 one111)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one112 one113) (Coverage.join one114 one115)) (Coverage.join (Coverage.join one116 one117) (Coverage.join one118 one119))) (Coverage.join (Coverage.join (Coverage.join one120 one121) (Coverage.join one122 one123)) (Coverage.join (Coverage.join one124 one125) (Coverage.join one126 one127)))))
end NF180PA.Symbolic
