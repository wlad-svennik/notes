import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2432_0 : checkWitness 2432 false false 538 = true := by decide +kernel
private theorem w2432_1 : checkWitness 2432 false true 4634 = true := by decide +kernel
private theorem w2432_2 : checkWitness 2432 true false 538 = true := by decide +kernel
private theorem w2432_3 : checkWitness 2432 true true 4634 = true := by decide +kernel
private theorem cases2432 : checkFour 2432 (538,4634,538,4634) = true := by
  simp only [checkFour, w2432_0,w2432_1,w2432_2,w2432_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2432 : Coverage 2432 2433 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases2432)
private theorem w2433_0 : checkWitness 2433 false false 8933 = true := by decide +kernel
private theorem w2433_2 : checkWitness 2433 true false 8929 = true := by decide +kernel
private theorem cases2433 : checkFour 2433 (8933,0,8929,0) = true := by
  simp only [checkFour, w2433_0,w2433_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2433 : Coverage 2433 2434 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases2433)
private theorem w2434_0 : checkWitness 2434 false false 664 = true := by decide +kernel
private theorem w2434_1 : checkWitness 2434 false true 4760 = true := by decide +kernel
private theorem w2434_2 : checkWitness 2434 true false 655 = true := by decide +kernel
private theorem w2434_3 : checkWitness 2434 true true 4751 = true := by decide +kernel
private theorem cases2434 : checkFour 2434 (664,4760,655,4751) = true := by
  simp only [checkFour, w2434_0,w2434_1,w2434_2,w2434_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2434 : Coverage 2434 2435 := checkList_sound (ws:=[(664,4760,655,4751)]) (by simpa only [checkList, Bool.and_true] using cases2434)
private theorem w2435_0 : checkWitness 2435 false false 198 = true := by decide +kernel
private theorem w2435_2 : checkWitness 2435 true false 198 = true := by decide +kernel
private theorem cases2435 : checkFour 2435 (198,0,198,0) = true := by
  simp only [checkFour, w2435_0,w2435_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2435 : Coverage 2435 2436 := checkList_sound (ws:=[(198,0,198,0)]) (by simpa only [checkList, Bool.and_true] using cases2435)
private theorem w2436_0 : checkWitness 2436 false false 619 = true := by decide +kernel
private theorem w2436_1 : checkWitness 2436 false true 4707 = true := by decide +kernel
private theorem w2436_2 : checkWitness 2436 true false 619 = true := by decide +kernel
private theorem w2436_3 : checkWitness 2436 true true 4707 = true := by decide +kernel
private theorem cases2436 : checkFour 2436 (619,4707,619,4707) = true := by
  simp only [checkFour, w2436_0,w2436_1,w2436_2,w2436_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2436 : Coverage 2436 2437 := checkList_sound (ws:=[(619,4707,619,4707)]) (by simpa only [checkList, Bool.and_true] using cases2436)
private theorem w2437_0 : checkWitness 2437 false false 8948 = true := by decide +kernel
private theorem w2437_2 : checkWitness 2437 true false 8939 = true := by decide +kernel
private theorem cases2437 : checkFour 2437 (8948,0,8939,0) = true := by
  simp only [checkFour, w2437_0,w2437_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2437 : Coverage 2437 2438 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2437)
private theorem w2438_0 : checkWitness 2438 false false 62 = true := by decide +kernel
private theorem w2438_2 : checkWitness 2438 true false 62 = true := by decide +kernel
private theorem cases2438 : checkFour 2438 (62,0,62,0) = true := by
  simp only [checkFour, w2438_0,w2438_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2438 : Coverage 2438 2439 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2438)
private theorem w2439_0 : checkWitness 2439 false false 54 = true := by decide +kernel
private theorem w2439_2 : checkWitness 2439 true false 54 = true := by decide +kernel
private theorem cases2439 : checkFour 2439 (54,0,54,0) = true := by
  simp only [checkFour, w2439_0,w2439_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2439 : Coverage 2439 2440 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases2439)
private theorem w2440_0 : checkWitness 2440 false false 625 = true := by decide +kernel
private theorem w2440_1 : checkWitness 2440 false true 4717 = true := by decide +kernel
private theorem w2440_2 : checkWitness 2440 true false 625 = true := by decide +kernel
private theorem w2440_3 : checkWitness 2440 true true 4717 = true := by decide +kernel
private theorem cases2440 : checkFour 2440 (625,4717,625,4717) = true := by
  simp only [checkFour, w2440_0,w2440_1,w2440_2,w2440_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2440 : Coverage 2440 2441 := checkList_sound (ws:=[(625,4717,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases2440)
private theorem w2441_0 : checkWitness 2441 false false 8886 = true := by decide +kernel
private theorem w2441_2 : checkWitness 2441 true false 8882 = true := by decide +kernel
private theorem cases2441 : checkFour 2441 (8886,0,8882,0) = true := by
  simp only [checkFour, w2441_0,w2441_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2441 : Coverage 2441 2442 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases2441)
private theorem w2442_0 : checkWitness 2442 false false 54 = true := by decide +kernel
private theorem w2442_2 : checkWitness 2442 true false 54 = true := by decide +kernel
private theorem cases2442 : checkFour 2442 (54,0,54,0) = true := by
  simp only [checkFour, w2442_0,w2442_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2442 : Coverage 2442 2443 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases2442)
private theorem w2443_0 : checkWitness 2443 false false 580 = true := by decide +kernel
private theorem w2443_1 : checkWitness 2443 false true 4676 = true := by decide +kernel
private theorem w2443_2 : checkWitness 2443 true false 580 = true := by decide +kernel
private theorem w2443_3 : checkWitness 2443 true true 4676 = true := by decide +kernel
private theorem cases2443 : checkFour 2443 (580,4676,580,4676) = true := by
  simp only [checkFour, w2443_0,w2443_1,w2443_2,w2443_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2443 : Coverage 2443 2444 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases2443)
private theorem w2444_0 : checkWitness 2444 false false 8921 = true := by decide +kernel
private theorem w2444_2 : checkWitness 2444 true false 8917 = true := by decide +kernel
private theorem cases2444 : checkFour 2444 (8921,0,8917,0) = true := by
  simp only [checkFour, w2444_0,w2444_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2444 : Coverage 2444 2445 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases2444)
private theorem w2445_0 : checkWitness 2445 false false 8956 = true := by decide +kernel
private theorem w2445_2 : checkWitness 2445 true false 8947 = true := by decide +kernel
private theorem cases2445 : checkFour 2445 (8956,0,8947,0) = true := by
  simp only [checkFour, w2445_0,w2445_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2445 : Coverage 2445 2446 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2445)
private theorem w2446_0 : checkWitness 2446 false false 72 = true := by decide +kernel
private theorem w2446_2 : checkWitness 2446 true false 72 = true := by decide +kernel
private theorem cases2446 : checkFour 2446 (72,0,72,0) = true := by
  simp only [checkFour, w2446_0,w2446_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2446 : Coverage 2446 2447 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2446)
private theorem w2447_0 : checkWitness 2447 false false 668 = true := by decide +kernel
private theorem w2447_1 : checkWitness 2447 false true 4760 = true := by decide +kernel
private theorem w2447_2 : checkWitness 2447 true false 659 = true := by decide +kernel
private theorem w2447_3 : checkWitness 2447 true true 4751 = true := by decide +kernel
private theorem cases2447 : checkFour 2447 (668,4760,659,4751) = true := by
  simp only [checkFour, w2447_0,w2447_1,w2447_2,w2447_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2447 : Coverage 2447 2448 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases2447)
private theorem w2448_0 : checkWitness 2448 false false 8917 = true := by decide +kernel
private theorem w2448_2 : checkWitness 2448 true false 8913 = true := by decide +kernel
private theorem cases2448 : checkFour 2448 (8917,0,8913,0) = true := by
  simp only [checkFour, w2448_0,w2448_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2448 : Coverage 2448 2449 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2448)
private theorem w2449_0 : checkWitness 2449 false false 662 = true := by decide +kernel
private theorem w2449_1 : checkWitness 2449 false true 4754 = true := by decide +kernel
private theorem w2449_2 : checkWitness 2449 true false 653 = true := by decide +kernel
private theorem w2449_3 : checkWitness 2449 true true 4745 = true := by decide +kernel
private theorem cases2449 : checkFour 2449 (662,4754,653,4745) = true := by
  simp only [checkFour, w2449_0,w2449_1,w2449_2,w2449_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2449 : Coverage 2449 2450 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases2449)
private theorem w2450_0 : checkWitness 2450 false false 8886 = true := by decide +kernel
private theorem w2450_2 : checkWitness 2450 true false 8882 = true := by decide +kernel
private theorem cases2450 : checkFour 2450 (8886,0,8882,0) = true := by
  simp only [checkFour, w2450_0,w2450_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2450 : Coverage 2450 2451 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases2450)
private theorem w2451_0 : checkWitness 2451 false false 60 = true := by decide +kernel
private theorem w2451_2 : checkWitness 2451 true false 60 = true := by decide +kernel
private theorem cases2451 : checkFour 2451 (60,0,60,0) = true := by
  simp only [checkFour, w2451_0,w2451_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2451 : Coverage 2451 2452 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2451)
private theorem w2452_0 : checkWitness 2452 false false 52 = true := by decide +kernel
private theorem w2452_2 : checkWitness 2452 true false 52 = true := by decide +kernel
private theorem cases2452 : checkFour 2452 (52,0,52,0) = true := by
  simp only [checkFour, w2452_0,w2452_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2452 : Coverage 2452 2453 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2452)
private theorem w2453_0 : checkWitness 2453 false false 645 = true := by decide +kernel
private theorem w2453_1 : checkWitness 2453 false true 4717 = true := by decide +kernel
private theorem w2453_2 : checkWitness 2453 true false 645 = true := by decide +kernel
private theorem w2453_3 : checkWitness 2453 true true 4717 = true := by decide +kernel
private theorem cases2453 : checkFour 2453 (645,4717,645,4717) = true := by
  simp only [checkFour, w2453_0,w2453_1,w2453_2,w2453_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2453 : Coverage 2453 2454 := checkList_sound (ws:=[(645,4717,645,4717)]) (by simpa only [checkList, Bool.and_true] using cases2453)
private theorem w2454_0 : checkWitness 2454 false false 8902 = true := by decide +kernel
private theorem w2454_2 : checkWitness 2454 true false 8898 = true := by decide +kernel
private theorem cases2454 : checkFour 2454 (8902,0,8898,0) = true := by
  simp only [checkFour, w2454_0,w2454_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2454 : Coverage 2454 2455 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases2454)
private theorem w2455_0 : checkWitness 2455 false false 8898 = true := by decide +kernel
private theorem w2455_2 : checkWitness 2455 true false 8894 = true := by decide +kernel
private theorem cases2455 : checkFour 2455 (8898,0,8894,0) = true := by
  simp only [checkFour, w2455_0,w2455_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2455 : Coverage 2455 2456 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2455)
private theorem w2456_0 : checkWitness 2456 false false 66 = true := by decide +kernel
private theorem w2456_2 : checkWitness 2456 true false 66 = true := by decide +kernel
private theorem cases2456 : checkFour 2456 (66,0,66,0) = true := by
  simp only [checkFour, w2456_0,w2456_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2456 : Coverage 2456 2457 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2456)
private theorem w2457_0 : checkWitness 2457 false false 742 = true := by decide +kernel
private theorem w2457_1 : checkWitness 2457 false true 4838 = true := by decide +kernel
private theorem w2457_2 : checkWitness 2457 true false 742 = true := by decide +kernel
private theorem w2457_3 : checkWitness 2457 true true 4838 = true := by decide +kernel
private theorem cases2457 : checkFour 2457 (742,4838,742,4838) = true := by
  simp only [checkFour, w2457_0,w2457_1,w2457_2,w2457_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2457 : Coverage 2457 2458 := checkList_sound (ws:=[(742,4838,742,4838)]) (by simpa only [checkList, Bool.and_true] using cases2457)
private theorem w2458_0 : checkWitness 2458 false false 9014 = true := by decide +kernel
private theorem w2458_2 : checkWitness 2458 true false 9005 = true := by decide +kernel
private theorem cases2458 : checkFour 2458 (9014,0,9005,0) = true := by
  simp only [checkFour, w2458_0,w2458_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2458 : Coverage 2458 2459 := checkList_sound (ws:=[(9014,0,9005,0)]) (by simpa only [checkList, Bool.and_true] using cases2458)
private theorem w2459_0 : checkWitness 2459 false false 64 = true := by decide +kernel
private theorem w2459_2 : checkWitness 2459 true false 64 = true := by decide +kernel
private theorem cases2459 : checkFour 2459 (64,0,64,0) = true := by
  simp only [checkFour, w2459_0,w2459_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2459 : Coverage 2459 2460 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2459)
private theorem w2460_0 : checkWitness 2460 false false 596 = true := by decide +kernel
private theorem w2460_1 : checkWitness 2460 false true 4692 = true := by decide +kernel
private theorem w2460_2 : checkWitness 2460 true false 596 = true := by decide +kernel
private theorem w2460_3 : checkWitness 2460 true true 4692 = true := by decide +kernel
private theorem cases2460 : checkFour 2460 (596,4692,596,4692) = true := by
  simp only [checkFour, w2460_0,w2460_1,w2460_2,w2460_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2460 : Coverage 2460 2461 := checkList_sound (ws:=[(596,4692,596,4692)]) (by simpa only [checkList, Bool.and_true] using cases2460)
private theorem w2461_0 : checkWitness 2461 false false 8954 = true := by decide +kernel
private theorem w2461_2 : checkWitness 2461 true false 8950 = true := by decide +kernel
private theorem cases2461 : checkFour 2461 (8954,0,8950,0) = true := by
  simp only [checkFour, w2461_0,w2461_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2461 : Coverage 2461 2462 := checkList_sound (ws:=[(8954,0,8950,0)]) (by simpa only [checkList, Bool.and_true] using cases2461)
private theorem w2462_0 : checkWitness 2462 false false 66 = true := by decide +kernel
private theorem w2462_2 : checkWitness 2462 true false 66 = true := by decide +kernel
private theorem cases2462 : checkFour 2462 (66,0,66,0) = true := by
  simp only [checkFour, w2462_0,w2462_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2462 : Coverage 2462 2463 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2462)
private theorem w2463_0 : checkWitness 2463 false false 634 = true := by decide +kernel
private theorem w2463_1 : checkWitness 2463 false true 4730 = true := by decide +kernel
private theorem w2463_2 : checkWitness 2463 true false 634 = true := by decide +kernel
private theorem w2463_3 : checkWitness 2463 true true 4730 = true := by decide +kernel
private theorem cases2463 : checkFour 2463 (634,4730,634,4730) = true := by
  simp only [checkFour, w2463_0,w2463_1,w2463_2,w2463_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2463 : Coverage 2463 2464 := checkList_sound (ws:=[(634,4730,634,4730)]) (by simpa only [checkList, Bool.and_true] using cases2463)
theorem cover2432 : Coverage 2432 2464 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2432 one2433) (Coverage.join one2434 one2435)) (Coverage.join (Coverage.join one2436 one2437) (Coverage.join one2438 one2439))) (Coverage.join (Coverage.join (Coverage.join one2440 one2441) (Coverage.join one2442 one2443)) (Coverage.join (Coverage.join one2444 one2445) (Coverage.join one2446 one2447)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2448 one2449) (Coverage.join one2450 one2451)) (Coverage.join (Coverage.join one2452 one2453) (Coverage.join one2454 one2455))) (Coverage.join (Coverage.join (Coverage.join one2456 one2457) (Coverage.join one2458 one2459)) (Coverage.join (Coverage.join one2460 one2461) (Coverage.join one2462 one2463)))))
end NF180PA.Symbolic
