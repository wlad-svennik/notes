import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1632_0 : checkWitness 1632 false false 88 = true := by decide +kernel
private theorem w1632_2 : checkWitness 1632 true false 88 = true := by decide +kernel
private theorem cases1632 : checkFour 1632 (88,0,88,0) = true := by
  simp only [checkFour, w1632_0,w1632_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1632 : Coverage 1632 1633 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1632)
private theorem w1633_0 : checkWitness 1633 false false 590 = true := by decide +kernel
private theorem w1633_1 : checkWitness 1633 false true 4686 = true := by decide +kernel
private theorem w1633_2 : checkWitness 1633 true false 590 = true := by decide +kernel
private theorem w1633_3 : checkWitness 1633 true true 4686 = true := by decide +kernel
private theorem cases1633 : checkFour 1633 (590,4686,590,4686) = true := by
  simp only [checkFour, w1633_0,w1633_1,w1633_2,w1633_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1633 : Coverage 1633 1634 := checkList_sound (ws:=[(590,4686,590,4686)]) (by simpa only [checkList, Bool.and_true] using cases1633)
private theorem w1634_0 : checkWitness 1634 false false 8906 = true := by decide +kernel
private theorem w1634_2 : checkWitness 1634 true false 8897 = true := by decide +kernel
private theorem cases1634 : checkFour 1634 (8906,0,8897,0) = true := by
  simp only [checkFour, w1634_0,w1634_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1634 : Coverage 1634 1635 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1634)
private theorem w1635_0 : checkWitness 1635 false false 8852 = true := by decide +kernel
private theorem w1635_2 : checkWitness 1635 true false 8848 = true := by decide +kernel
private theorem cases1635 : checkFour 1635 (8852,0,8848,0) = true := by
  simp only [checkFour, w1635_0,w1635_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1635 : Coverage 1635 1636 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1635)
private theorem w1636_0 : checkWitness 1636 false false 96 = true := by decide +kernel
private theorem w1636_2 : checkWitness 1636 true false 96 = true := by decide +kernel
private theorem cases1636 : checkFour 1636 (96,0,96,0) = true := by
  simp only [checkFour, w1636_0,w1636_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1636 : Coverage 1636 1637 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1636)
private theorem w1637_0 : checkWitness 1637 false false 636 = true := by decide +kernel
private theorem w1637_1 : checkWitness 1637 false true 4724 = true := by decide +kernel
private theorem w1637_2 : checkWitness 1637 true false 627 = true := by decide +kernel
private theorem w1637_3 : checkWitness 1637 true true 4715 = true := by decide +kernel
private theorem cases1637 : checkFour 1637 (636,4724,627,4715) = true := by
  simp only [checkFour, w1637_0,w1637_1,w1637_2,w1637_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1637 : Coverage 1637 1638 := checkList_sound (ws:=[(636,4724,627,4715)]) (by simpa only [checkList, Bool.and_true] using cases1637)
private theorem w1638_0 : checkWitness 1638 false false 8894 = true := by decide +kernel
private theorem w1638_2 : checkWitness 1638 true false 8890 = true := by decide +kernel
private theorem cases1638 : checkFour 1638 (8894,0,8890,0) = true := by
  simp only [checkFour, w1638_0,w1638_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1638 : Coverage 1638 1639 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases1638)
private theorem w1639_0 : checkWitness 1639 false false 86 = true := by decide +kernel
private theorem w1639_2 : checkWitness 1639 true false 86 = true := by decide +kernel
private theorem cases1639 : checkFour 1639 (86,0,86,0) = true := by
  simp only [checkFour, w1639_0,w1639_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1639 : Coverage 1639 1640 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1639)
private theorem w1640_0 : checkWitness 1640 false false 482 = true := by decide +kernel
private theorem w1640_1 : checkWitness 1640 false true 4578 = true := by decide +kernel
private theorem w1640_2 : checkWitness 1640 true false 482 = true := by decide +kernel
private theorem w1640_3 : checkWitness 1640 true true 4578 = true := by decide +kernel
private theorem cases1640 : checkFour 1640 (482,4578,482,4578) = true := by
  simp only [checkFour, w1640_0,w1640_1,w1640_2,w1640_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1640 : Coverage 1640 1641 := checkList_sound (ws:=[(482,4578,482,4578)]) (by simpa only [checkList, Bool.and_true] using cases1640)
private theorem w1641_0 : checkWitness 1641 false false 8877 = true := by decide +kernel
private theorem w1641_2 : checkWitness 1641 true false 8873 = true := by decide +kernel
private theorem cases1641 : checkFour 1641 (8877,0,8873,0) = true := by
  simp only [checkFour, w1641_0,w1641_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1641 : Coverage 1641 1642 := checkList_sound (ws:=[(8877,0,8873,0)]) (by simpa only [checkList, Bool.and_true] using cases1641)
private theorem w1642_0 : checkWitness 1642 false false 608 = true := by decide +kernel
private theorem w1642_1 : checkWitness 1642 false true 4704 = true := by decide +kernel
private theorem w1642_2 : checkWitness 1642 true false 599 = true := by decide +kernel
private theorem w1642_3 : checkWitness 1642 true true 4695 = true := by decide +kernel
private theorem cases1642 : checkFour 1642 (608,4704,599,4695) = true := by
  simp only [checkFour, w1642_0,w1642_1,w1642_2,w1642_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1642 : Coverage 1642 1643 := checkList_sound (ws:=[(608,4704,599,4695)]) (by simpa only [checkList, Bool.and_true] using cases1642)
private theorem w1643_0 : checkWitness 1643 false false 170 = true := by decide +kernel
private theorem w1643_2 : checkWitness 1643 true false 170 = true := by decide +kernel
private theorem cases1643 : checkFour 1643 (170,0,170,0) = true := by
  simp only [checkFour, w1643_0,w1643_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1643 : Coverage 1643 1644 := checkList_sound (ws:=[(170,0,170,0)]) (by simpa only [checkList, Bool.and_true] using cases1643)
private theorem w1644_0 : checkWitness 1644 false false 563 = true := by decide +kernel
private theorem w1644_1 : checkWitness 1644 false true 4651 = true := by decide +kernel
private theorem w1644_2 : checkWitness 1644 true false 563 = true := by decide +kernel
private theorem w1644_3 : checkWitness 1644 true true 4651 = true := by decide +kernel
private theorem cases1644 : checkFour 1644 (563,4651,563,4651) = true := by
  simp only [checkFour, w1644_0,w1644_1,w1644_2,w1644_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1644 : Coverage 1644 1645 := checkList_sound (ws:=[(563,4651,563,4651)]) (by simpa only [checkList, Bool.and_true] using cases1644)
private theorem w1645_0 : checkWitness 1645 false false 8892 = true := by decide +kernel
private theorem w1645_2 : checkWitness 1645 true false 8883 = true := by decide +kernel
private theorem cases1645 : checkFour 1645 (8892,0,8883,0) = true := by
  simp only [checkFour, w1645_0,w1645_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1645 : Coverage 1645 1646 := checkList_sound (ws:=[(8892,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1645)
private theorem w1646_0 : checkWitness 1646 false false 90 = true := by decide +kernel
private theorem w1646_2 : checkWitness 1646 true false 90 = true := by decide +kernel
private theorem cases1646 : checkFour 1646 (90,0,90,0) = true := by
  simp only [checkFour, w1646_0,w1646_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1646 : Coverage 1646 1647 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1646)
private theorem w1647_0 : checkWitness 1647 false false 82 = true := by decide +kernel
private theorem w1647_2 : checkWitness 1647 true false 82 = true := by decide +kernel
private theorem cases1647 : checkFour 1647 (82,0,82,0) = true := by
  simp only [checkFour, w1647_0,w1647_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1647 : Coverage 1647 1648 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1647)
private theorem w1648_0 : checkWitness 1648 false false 569 = true := by decide +kernel
private theorem w1648_1 : checkWitness 1648 false true 4661 = true := by decide +kernel
private theorem w1648_2 : checkWitness 1648 true false 569 = true := by decide +kernel
private theorem w1648_3 : checkWitness 1648 true true 4661 = true := by decide +kernel
private theorem cases1648 : checkFour 1648 (569,4661,569,4661) = true := by
  simp only [checkFour, w1648_0,w1648_1,w1648_2,w1648_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1648 : Coverage 1648 1649 := checkList_sound (ws:=[(569,4661,569,4661)]) (by simpa only [checkList, Bool.and_true] using cases1648)
private theorem w1649_0 : checkWitness 1649 false false 8830 = true := by decide +kernel
private theorem w1649_2 : checkWitness 1649 true false 8826 = true := by decide +kernel
private theorem cases1649 : checkFour 1649 (8830,0,8826,0) = true := by
  simp only [checkFour, w1649_0,w1649_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1649 : Coverage 1649 1650 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1649)
private theorem w1650_0 : checkWitness 1650 false false 82 = true := by decide +kernel
private theorem w1650_2 : checkWitness 1650 true false 82 = true := by decide +kernel
private theorem cases1650 : checkFour 1650 (82,0,82,0) = true := by
  simp only [checkFour, w1650_0,w1650_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1650 : Coverage 1650 1651 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1650)
private theorem w1651_0 : checkWitness 1651 false false 524 = true := by decide +kernel
private theorem w1651_1 : checkWitness 1651 false true 4620 = true := by decide +kernel
private theorem w1651_2 : checkWitness 1651 true false 524 = true := by decide +kernel
private theorem w1651_3 : checkWitness 1651 true true 4620 = true := by decide +kernel
private theorem cases1651 : checkFour 1651 (524,4620,524,4620) = true := by
  simp only [checkFour, w1651_0,w1651_1,w1651_2,w1651_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1651 : Coverage 1651 1652 := checkList_sound (ws:=[(524,4620,524,4620)]) (by simpa only [checkList, Bool.and_true] using cases1651)
private theorem w1652_0 : checkWitness 1652 false false 8865 = true := by decide +kernel
private theorem w1652_2 : checkWitness 1652 true false 8861 = true := by decide +kernel
private theorem cases1652 : checkFour 1652 (8865,0,8861,0) = true := by
  simp only [checkFour, w1652_0,w1652_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1652 : Coverage 1652 1653 := checkList_sound (ws:=[(8865,0,8861,0)]) (by simpa only [checkList, Bool.and_true] using cases1652)
private theorem w1653_0 : checkWitness 1653 false false 8900 = true := by decide +kernel
private theorem w1653_2 : checkWitness 1653 true false 8891 = true := by decide +kernel
private theorem cases1653 : checkFour 1653 (8900,0,8891,0) = true := by
  simp only [checkFour, w1653_0,w1653_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1653 : Coverage 1653 1654 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1653)
private theorem w1654_0 : checkWitness 1654 false false 100 = true := by decide +kernel
private theorem w1654_2 : checkWitness 1654 true false 100 = true := by decide +kernel
private theorem cases1654 : checkFour 1654 (100,0,100,0) = true := by
  simp only [checkFour, w1654_0,w1654_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1654 : Coverage 1654 1655 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1654)
private theorem w1655_0 : checkWitness 1655 false false 612 = true := by decide +kernel
private theorem w1655_1 : checkWitness 1655 false true 4704 = true := by decide +kernel
private theorem w1655_2 : checkWitness 1655 true false 603 = true := by decide +kernel
private theorem w1655_3 : checkWitness 1655 true true 4695 = true := by decide +kernel
private theorem cases1655 : checkFour 1655 (612,4704,603,4695) = true := by
  simp only [checkFour, w1655_0,w1655_1,w1655_2,w1655_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1655 : Coverage 1655 1656 := checkList_sound (ws:=[(612,4704,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases1655)
private theorem w1656_0 : checkWitness 1656 false false 8861 = true := by decide +kernel
private theorem w1656_2 : checkWitness 1656 true false 8857 = true := by decide +kernel
private theorem cases1656 : checkFour 1656 (8861,0,8857,0) = true := by
  simp only [checkFour, w1656_0,w1656_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1656 : Coverage 1656 1657 := checkList_sound (ws:=[(8861,0,8857,0)]) (by simpa only [checkList, Bool.and_true] using cases1656)
private theorem w1657_0 : checkWitness 1657 false false 606 = true := by decide +kernel
private theorem w1657_1 : checkWitness 1657 false true 4698 = true := by decide +kernel
private theorem w1657_2 : checkWitness 1657 true false 597 = true := by decide +kernel
private theorem w1657_3 : checkWitness 1657 true true 4689 = true := by decide +kernel
private theorem cases1657 : checkFour 1657 (606,4698,597,4689) = true := by
  simp only [checkFour, w1657_0,w1657_1,w1657_2,w1657_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1657 : Coverage 1657 1658 := checkList_sound (ws:=[(606,4698,597,4689)]) (by simpa only [checkList, Bool.and_true] using cases1657)
private theorem w1658_0 : checkWitness 1658 false false 8830 = true := by decide +kernel
private theorem w1658_2 : checkWitness 1658 true false 8826 = true := by decide +kernel
private theorem cases1658 : checkFour 1658 (8830,0,8826,0) = true := by
  simp only [checkFour, w1658_0,w1658_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1658 : Coverage 1658 1659 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1658)
private theorem w1659_0 : checkWitness 1659 false false 88 = true := by decide +kernel
private theorem w1659_2 : checkWitness 1659 true false 88 = true := by decide +kernel
private theorem cases1659 : checkFour 1659 (88,0,88,0) = true := by
  simp only [checkFour, w1659_0,w1659_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1659 : Coverage 1659 1660 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1659)
private theorem w1660_0 : checkWitness 1660 false false 80 = true := by decide +kernel
private theorem w1660_2 : checkWitness 1660 true false 80 = true := by decide +kernel
private theorem cases1660 : checkFour 1660 (80,0,80,0) = true := by
  simp only [checkFour, w1660_0,w1660_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1660 : Coverage 1660 1661 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1660)
private theorem w1661_0 : checkWitness 1661 false false 573 = true := by decide +kernel
private theorem w1661_1 : checkWitness 1661 false true 4661 = true := by decide +kernel
private theorem w1661_2 : checkWitness 1661 true false 573 = true := by decide +kernel
private theorem w1661_3 : checkWitness 1661 true true 4661 = true := by decide +kernel
private theorem cases1661 : checkFour 1661 (573,4661,573,4661) = true := by
  simp only [checkFour, w1661_0,w1661_1,w1661_2,w1661_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1661 : Coverage 1661 1662 := checkList_sound (ws:=[(573,4661,573,4661)]) (by simpa only [checkList, Bool.and_true] using cases1661)
private theorem w1662_0 : checkWitness 1662 false false 8846 = true := by decide +kernel
private theorem w1662_2 : checkWitness 1662 true false 8842 = true := by decide +kernel
private theorem cases1662 : checkFour 1662 (8846,0,8842,0) = true := by
  simp only [checkFour, w1662_0,w1662_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1662 : Coverage 1662 1663 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1662)
private theorem w1663_0 : checkWitness 1663 false false 8842 = true := by decide +kernel
private theorem w1663_2 : checkWitness 1663 true false 8838 = true := by decide +kernel
private theorem cases1663 : checkFour 1663 (8842,0,8838,0) = true := by
  simp only [checkFour, w1663_0,w1663_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1663 : Coverage 1663 1664 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1663)
theorem cover1632 : Coverage 1632 1664 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1632 one1633) (Coverage.join one1634 one1635)) (Coverage.join (Coverage.join one1636 one1637) (Coverage.join one1638 one1639))) (Coverage.join (Coverage.join (Coverage.join one1640 one1641) (Coverage.join one1642 one1643)) (Coverage.join (Coverage.join one1644 one1645) (Coverage.join one1646 one1647)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1648 one1649) (Coverage.join one1650 one1651)) (Coverage.join (Coverage.join one1652 one1653) (Coverage.join one1654 one1655))) (Coverage.join (Coverage.join (Coverage.join one1656 one1657) (Coverage.join one1658 one1659)) (Coverage.join (Coverage.join one1660 one1661) (Coverage.join one1662 one1663)))))
end NF180PA.Symbolic
