import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2848_0 : checkWitness 2848 false false 30 = true := by decide +kernel
private theorem w2848_2 : checkWitness 2848 true false 30 = true := by decide +kernel
private theorem cases2848 : checkFour 2848 (30,0,30,0) = true := by
  simp only [checkFour, w2848_0,w2848_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2848 : Coverage 2848 2849 := checkList_sound (ws:=[(30,0,30,0)]) (by simpa only [checkList, Bool.and_true] using cases2848)
private theorem w2849_0 : checkWitness 2849 false false 704 = true := by decide +kernel
private theorem w2849_1 : checkWitness 2849 false true 4800 = true := by decide +kernel
private theorem w2849_2 : checkWitness 2849 true false 704 = true := by decide +kernel
private theorem w2849_3 : checkWitness 2849 true true 4800 = true := by decide +kernel
private theorem cases2849 : checkFour 2849 (704,4800,704,4800) = true := by
  simp only [checkFour, w2849_0,w2849_1,w2849_2,w2849_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2849 : Coverage 2849 2850 := checkList_sound (ws:=[(704,4800,704,4800)]) (by simpa only [checkList, Bool.and_true] using cases2849)
private theorem w2850_0 : checkWitness 2850 false false 8998 = true := by decide +kernel
private theorem w2850_2 : checkWitness 2850 true false 8989 = true := by decide +kernel
private theorem cases2850 : checkFour 2850 (8998,0,8989,0) = true := by
  simp only [checkFour, w2850_0,w2850_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2850 : Coverage 2850 2851 := checkList_sound (ws:=[(8998,0,8989,0)]) (by simpa only [checkList, Bool.and_true] using cases2850)
private theorem w2851_0 : checkWitness 2851 false false 42 = true := by decide +kernel
private theorem w2851_2 : checkWitness 2851 true false 42 = true := by decide +kernel
private theorem cases2851 : checkFour 2851 (42,0,42,0) = true := by
  simp only [checkFour, w2851_0,w2851_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2851 : Coverage 2851 2852 := checkList_sound (ws:=[(42,0,42,0)]) (by simpa only [checkList, Bool.and_true] using cases2851)
private theorem w2852_0 : checkWitness 2852 false false 580 = true := by decide +kernel
private theorem w2852_1 : checkWitness 2852 false true 4676 = true := by decide +kernel
private theorem w2852_2 : checkWitness 2852 true false 580 = true := by decide +kernel
private theorem w2852_3 : checkWitness 2852 true true 4676 = true := by decide +kernel
private theorem cases2852 : checkFour 2852 (580,4676,580,4676) = true := by
  simp only [checkFour, w2852_0,w2852_1,w2852_2,w2852_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2852 : Coverage 2852 2853 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases2852)
private theorem w2853_0 : checkWitness 2853 false false 8938 = true := by decide +kernel
private theorem w2853_2 : checkWitness 2853 true false 8934 = true := by decide +kernel
private theorem cases2853 : checkFour 2853 (8938,0,8934,0) = true := by
  simp only [checkFour, w2853_0,w2853_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2853 : Coverage 2853 2854 := checkList_sound (ws:=[(8938,0,8934,0)]) (by simpa only [checkList, Bool.and_true] using cases2853)
private theorem w2854_0 : checkWitness 2854 false false 44 = true := by decide +kernel
private theorem w2854_2 : checkWitness 2854 true false 44 = true := by decide +kernel
private theorem cases2854 : checkFour 2854 (44,0,44,0) = true := by
  simp only [checkFour, w2854_0,w2854_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2854 : Coverage 2854 2855 := checkList_sound (ws:=[(44,0,44,0)]) (by simpa only [checkList, Bool.and_true] using cases2854)
private theorem w2855_0 : checkWitness 2855 false false 618 = true := by decide +kernel
private theorem w2855_1 : checkWitness 2855 false true 4714 = true := by decide +kernel
private theorem w2855_2 : checkWitness 2855 true false 618 = true := by decide +kernel
private theorem w2855_3 : checkWitness 2855 true true 4714 = true := by decide +kernel
private theorem cases2855 : checkFour 2855 (618,4714,618,4714) = true := by
  simp only [checkFour, w2855_0,w2855_1,w2855_2,w2855_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2855 : Coverage 2855 2856 := checkList_sound (ws:=[(618,4714,618,4714)]) (by simpa only [checkList, Bool.and_true] using cases2855)
private theorem w2856_0 : checkWitness 2856 false false 8959 = true := by decide +kernel
private theorem w2856_2 : checkWitness 2856 true false 8955 = true := by decide +kernel
private theorem cases2856 : checkFour 2856 (8959,0,8955,0) = true := by
  simp only [checkFour, w2856_0,w2856_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2856 : Coverage 2856 2857 := checkList_sound (ws:=[(8959,0,8955,0)]) (by simpa only [checkList, Bool.and_true] using cases2856)
private theorem w2857_0 : checkWitness 2857 false false 8994 = true := by decide +kernel
private theorem w2857_2 : checkWitness 2857 true false 8985 = true := by decide +kernel
private theorem cases2857 : checkFour 2857 (8994,0,8985,0) = true := by
  simp only [checkFour, w2857_0,w2857_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2857 : Coverage 2857 2858 := checkList_sound (ws:=[(8994,0,8985,0)]) (by simpa only [checkList, Bool.and_true] using cases2857)
private theorem w2858_0 : checkWitness 2858 false false 68 = true := by decide +kernel
private theorem w2858_2 : checkWitness 2858 true false 68 = true := by decide +kernel
private theorem cases2858 : checkFour 2858 (68,0,68,0) = true := by
  simp only [checkFour, w2858_0,w2858_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2858 : Coverage 2858 2859 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2858)
private theorem w2859_0 : checkWitness 2859 false false 706 = true := by decide +kernel
private theorem w2859_1 : checkWitness 2859 false true 4798 = true := by decide +kernel
private theorem w2859_2 : checkWitness 2859 true false 697 = true := by decide +kernel
private theorem w2859_3 : checkWitness 2859 true true 4789 = true := by decide +kernel
private theorem cases2859 : checkFour 2859 (706,4798,697,4789) = true := by
  simp only [checkFour, w2859_0,w2859_1,w2859_2,w2859_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2859 : Coverage 2859 2860 := checkList_sound (ws:=[(706,4798,697,4789)]) (by simpa only [checkList, Bool.and_true] using cases2859)
private theorem w2860_0 : checkWitness 2860 false false 8955 = true := by decide +kernel
private theorem w2860_2 : checkWitness 2860 true false 8951 = true := by decide +kernel
private theorem cases2860 : checkFour 2860 (8955,0,8951,0) = true := by
  simp only [checkFour, w2860_0,w2860_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2860 : Coverage 2860 2861 := checkList_sound (ws:=[(8955,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases2860)
private theorem w2861_0 : checkWitness 2861 false false 700 = true := by decide +kernel
private theorem w2861_1 : checkWitness 2861 false true 4792 = true := by decide +kernel
private theorem w2861_2 : checkWitness 2861 true false 691 = true := by decide +kernel
private theorem w2861_3 : checkWitness 2861 true true 4783 = true := by decide +kernel
private theorem cases2861 : checkFour 2861 (700,4792,691,4783) = true := by
  simp only [checkFour, w2861_0,w2861_1,w2861_2,w2861_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2861 : Coverage 2861 2862 := checkList_sound (ws:=[(700,4792,691,4783)]) (by simpa only [checkList, Bool.and_true] using cases2861)
private theorem w2862_0 : checkWitness 2862 false false 8924 = true := by decide +kernel
private theorem w2862_2 : checkWitness 2862 true false 8920 = true := by decide +kernel
private theorem cases2862 : checkFour 2862 (8924,0,8920,0) = true := by
  simp only [checkFour, w2862_0,w2862_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2862 : Coverage 2862 2863 := checkList_sound (ws:=[(8924,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases2862)
private theorem w2863_0 : checkWitness 2863 false false 56 = true := by decide +kernel
private theorem w2863_2 : checkWitness 2863 true false 56 = true := by decide +kernel
private theorem cases2863 : checkFour 2863 (56,0,56,0) = true := by
  simp only [checkFour, w2863_0,w2863_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2863 : Coverage 2863 2864 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2863)
private theorem w2864_0 : checkWitness 2864 false false 48 = true := by decide +kernel
private theorem w2864_2 : checkWitness 2864 true false 48 = true := by decide +kernel
private theorem cases2864 : checkFour 2864 (48,0,48,0) = true := by
  simp only [checkFour, w2864_0,w2864_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2864 : Coverage 2864 2865 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2864)
private theorem w2865_0 : checkWitness 2865 false false 665 = true := by decide +kernel
private theorem w2865_1 : checkWitness 2865 false true 4749 = true := by decide +kernel
private theorem w2865_2 : checkWitness 2865 true false 665 = true := by decide +kernel
private theorem w2865_3 : checkWitness 2865 true true 4749 = true := by decide +kernel
private theorem cases2865 : checkFour 2865 (665,4749,665,4749) = true := by
  simp only [checkFour, w2865_0,w2865_1,w2865_2,w2865_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2865 : Coverage 2865 2866 := checkList_sound (ws:=[(665,4749,665,4749)]) (by simpa only [checkList, Bool.and_true] using cases2865)
private theorem w2866_0 : checkWitness 2866 false false 8918 = true := by decide +kernel
private theorem w2866_2 : checkWitness 2866 true false 8914 = true := by decide +kernel
private theorem cases2866 : checkFour 2866 (8918,0,8914,0) = true := by
  simp only [checkFour, w2866_0,w2866_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2866 : Coverage 2866 2867 := checkList_sound (ws:=[(8918,0,8914,0)]) (by simpa only [checkList, Bool.and_true] using cases2866)
private theorem w2867_0 : checkWitness 2867 false false 48 = true := by decide +kernel
private theorem w2867_2 : checkWitness 2867 true false 48 = true := by decide +kernel
private theorem cases2867 : checkFour 2867 (48,0,48,0) = true := by
  simp only [checkFour, w2867_0,w2867_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2867 : Coverage 2867 2868 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2867)
private theorem w2868_0 : checkWitness 2868 false false 633 = true := by decide +kernel
private theorem w2868_1 : checkWitness 2868 false true 4729 = true := by decide +kernel
private theorem w2868_2 : checkWitness 2868 true false 633 = true := by decide +kernel
private theorem w2868_3 : checkWitness 2868 true true 4729 = true := by decide +kernel
private theorem cases2868 : checkFour 2868 (633,4729,633,4729) = true := by
  simp only [checkFour, w2868_0,w2868_1,w2868_2,w2868_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2868 : Coverage 2868 2869 := checkList_sound (ws:=[(633,4729,633,4729)]) (by simpa only [checkList, Bool.and_true] using cases2868)
private theorem w2869_0 : checkWitness 2869 false false 8986 = true := by decide +kernel
private theorem w2869_2 : checkWitness 2869 true false 8977 = true := by decide +kernel
private theorem cases2869 : checkFour 2869 (8986,0,8977,0) = true := by
  simp only [checkFour, w2869_0,w2869_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2869 : Coverage 2869 2870 := checkList_sound (ws:=[(8986,0,8977,0)]) (by simpa only [checkList, Bool.and_true] using cases2869)
private theorem w2870_0 : checkWitness 2870 false false 8932 = true := by decide +kernel
private theorem w2870_2 : checkWitness 2870 true false 8928 = true := by decide +kernel
private theorem cases2870 : checkFour 2870 (8932,0,8928,0) = true := by
  simp only [checkFour, w2870_0,w2870_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2870 : Coverage 2870 2871 := checkList_sound (ws:=[(8932,0,8928,0)]) (by simpa only [checkList, Bool.and_true] using cases2870)
private theorem w2871_0 : checkWitness 2871 false false 56 = true := by decide +kernel
private theorem w2871_2 : checkWitness 2871 true false 56 = true := by decide +kernel
private theorem cases2871 : checkFour 2871 (56,0,56,0) = true := by
  simp only [checkFour, w2871_0,w2871_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2871 : Coverage 2871 2872 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2871)
private theorem w2872_0 : checkWitness 2872 false false 716 = true := by decide +kernel
private theorem w2872_1 : checkWitness 2872 false true 4804 = true := by decide +kernel
private theorem w2872_2 : checkWitness 2872 true false 707 = true := by decide +kernel
private theorem w2872_3 : checkWitness 2872 true true 4795 = true := by decide +kernel
private theorem cases2872 : checkFour 2872 (716,4804,707,4795) = true := by
  simp only [checkFour, w2872_0,w2872_1,w2872_2,w2872_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2872 : Coverage 2872 2873 := checkList_sound (ws:=[(716,4804,707,4795)]) (by simpa only [checkList, Bool.and_true] using cases2872)
private theorem w2873_0 : checkWitness 2873 false false 8951 = true := by decide +kernel
private theorem w2873_2 : checkWitness 2873 true false 8947 = true := by decide +kernel
private theorem cases2873 : checkFour 2873 (8951,0,8947,0) = true := by
  simp only [checkFour, w2873_0,w2873_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2873 : Coverage 2873 2874 := checkList_sound (ws:=[(8951,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2873)
private theorem w2874_0 : checkWitness 2874 false false 46 = true := by decide +kernel
private theorem w2874_2 : checkWitness 2874 true false 46 = true := by decide +kernel
private theorem cases2874 : checkFour 2874 (46,0,46,0) = true := by
  simp only [checkFour, w2874_0,w2874_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2874 : Coverage 2874 2875 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2874)
private theorem w2875_0 : checkWitness 2875 false false 566 = true := by decide +kernel
private theorem w2875_1 : checkWitness 2875 false true 4662 = true := by decide +kernel
private theorem w2875_2 : checkWitness 2875 true false 566 = true := by decide +kernel
private theorem w2875_3 : checkWitness 2875 true true 4662 = true := by decide +kernel
private theorem cases2875 : checkFour 2875 (566,4662,566,4662) = true := by
  simp only [checkFour, w2875_0,w2875_1,w2875_2,w2875_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2875 : Coverage 2875 2876 := checkList_sound (ws:=[(566,4662,566,4662)]) (by simpa only [checkList, Bool.and_true] using cases2875)
private theorem w2876_0 : checkWitness 2876 false false 8961 = true := by decide +kernel
private theorem w2876_2 : checkWitness 2876 true false 8957 = true := by decide +kernel
private theorem cases2876 : checkFour 2876 (8961,0,8957,0) = true := by
  simp only [checkFour, w2876_0,w2876_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2876 : Coverage 2876 2877 := checkList_sound (ws:=[(8961,0,8957,0)]) (by simpa only [checkList, Bool.and_true] using cases2876)
private theorem w2877_0 : checkWitness 2877 false false 692 = true := by decide +kernel
private theorem w2877_1 : checkWitness 2877 false true 4788 = true := by decide +kernel
private theorem w2877_2 : checkWitness 2877 true false 683 = true := by decide +kernel
private theorem w2877_3 : checkWitness 2877 true true 4779 = true := by decide +kernel
private theorem cases2877 : checkFour 2877 (692,4788,683,4779) = true := by
  simp only [checkFour, w2877_0,w2877_1,w2877_2,w2877_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2877 : Coverage 2877 2878 := checkList_sound (ws:=[(692,4788,683,4779)]) (by simpa only [checkList, Bool.and_true] using cases2877)
private theorem w2878_0 : checkWitness 2878 false false 212 = true := by decide +kernel
private theorem w2878_2 : checkWitness 2878 true false 212 = true := by decide +kernel
private theorem cases2878 : checkFour 2878 (212,0,212,0) = true := by
  simp only [checkFour, w2878_0,w2878_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2878 : Coverage 2878 2879 := checkList_sound (ws:=[(212,0,212,0)]) (by simpa only [checkList, Bool.and_true] using cases2878)
private theorem w2879_0 : checkWitness 2879 false false 647 = true := by decide +kernel
private theorem w2879_1 : checkWitness 2879 false true 4735 = true := by decide +kernel
private theorem w2879_2 : checkWitness 2879 true false 647 = true := by decide +kernel
private theorem w2879_3 : checkWitness 2879 true true 4735 = true := by decide +kernel
private theorem cases2879 : checkFour 2879 (647,4735,647,4735) = true := by
  simp only [checkFour, w2879_0,w2879_1,w2879_2,w2879_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2879 : Coverage 2879 2880 := checkList_sound (ws:=[(647,4735,647,4735)]) (by simpa only [checkList, Bool.and_true] using cases2879)
theorem cover2848 : Coverage 2848 2880 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2848 one2849) (Coverage.join one2850 one2851)) (Coverage.join (Coverage.join one2852 one2853) (Coverage.join one2854 one2855))) (Coverage.join (Coverage.join (Coverage.join one2856 one2857) (Coverage.join one2858 one2859)) (Coverage.join (Coverage.join one2860 one2861) (Coverage.join one2862 one2863)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2864 one2865) (Coverage.join one2866 one2867)) (Coverage.join (Coverage.join one2868 one2869) (Coverage.join one2870 one2871))) (Coverage.join (Coverage.join (Coverage.join one2872 one2873) (Coverage.join one2874 one2875)) (Coverage.join (Coverage.join one2876 one2877) (Coverage.join one2878 one2879)))))
end NF180PA.Symbolic
