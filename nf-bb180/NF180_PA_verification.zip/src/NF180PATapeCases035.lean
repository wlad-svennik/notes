import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1120_0 : checkWitness 1120 false false 506 = true := by decide +kernel
private theorem w1120_1 : checkWitness 1120 false true 4602 = true := by decide +kernel
private theorem w1120_2 : checkWitness 1120 true false 506 = true := by decide +kernel
private theorem w1120_3 : checkWitness 1120 true true 4602 = true := by decide +kernel
private theorem cases1120 : checkFour 1120 (506,4602,506,4602) = true := by
  simp only [checkFour, w1120_0,w1120_1,w1120_2,w1120_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1120 : Coverage 1120 1121 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases1120)
private theorem w1121_0 : checkWitness 1121 false false 8901 = true := by decide +kernel
private theorem w1121_2 : checkWitness 1121 true false 8897 = true := by decide +kernel
private theorem cases1121 : checkFour 1121 (8901,0,8897,0) = true := by
  simp only [checkFour, w1121_0,w1121_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1121 : Coverage 1121 1122 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1121)
private theorem w1122_0 : checkWitness 1122 false false 632 = true := by decide +kernel
private theorem w1122_1 : checkWitness 1122 false true 4728 = true := by decide +kernel
private theorem w1122_2 : checkWitness 1122 true false 623 = true := by decide +kernel
private theorem w1122_3 : checkWitness 1122 true true 4719 = true := by decide +kernel
private theorem cases1122 : checkFour 1122 (632,4728,623,4719) = true := by
  simp only [checkFour, w1122_0,w1122_1,w1122_2,w1122_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1122 : Coverage 1122 1123 := checkList_sound (ws:=[(632,4728,623,4719)]) (by simpa only [checkList, Bool.and_true] using cases1122)
private theorem w1123_0 : checkWitness 1123 false false 180 = true := by decide +kernel
private theorem w1123_2 : checkWitness 1123 true false 180 = true := by decide +kernel
private theorem cases1123 : checkFour 1123 (180,0,180,0) = true := by
  simp only [checkFour, w1123_0,w1123_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1123 : Coverage 1123 1124 := checkList_sound (ws:=[(180,0,180,0)]) (by simpa only [checkList, Bool.and_true] using cases1123)
private theorem w1124_0 : checkWitness 1124 false false 587 = true := by decide +kernel
private theorem w1124_1 : checkWitness 1124 false true 4675 = true := by decide +kernel
private theorem w1124_2 : checkWitness 1124 true false 587 = true := by decide +kernel
private theorem w1124_3 : checkWitness 1124 true true 4675 = true := by decide +kernel
private theorem cases1124 : checkFour 1124 (587,4675,587,4675) = true := by
  simp only [checkFour, w1124_0,w1124_1,w1124_2,w1124_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1124 : Coverage 1124 1125 := checkList_sound (ws:=[(587,4675,587,4675)]) (by simpa only [checkList, Bool.and_true] using cases1124)
private theorem w1125_0 : checkWitness 1125 false false 8916 = true := by decide +kernel
private theorem w1125_2 : checkWitness 1125 true false 8907 = true := by decide +kernel
private theorem cases1125 : checkFour 1125 (8916,0,8907,0) = true := by
  simp only [checkFour, w1125_0,w1125_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1125 : Coverage 1125 1126 := checkList_sound (ws:=[(8916,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases1125)
private theorem w1126_0 : checkWitness 1126 false false 88 = true := by decide +kernel
private theorem w1126_2 : checkWitness 1126 true false 88 = true := by decide +kernel
private theorem cases1126 : checkFour 1126 (88,0,88,0) = true := by
  simp only [checkFour, w1126_0,w1126_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1126 : Coverage 1126 1127 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1126)
private theorem w1127_0 : checkWitness 1127 false false 80 = true := by decide +kernel
private theorem w1127_2 : checkWitness 1127 true false 80 = true := by decide +kernel
private theorem cases1127 : checkFour 1127 (80,0,80,0) = true := by
  simp only [checkFour, w1127_0,w1127_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1127 : Coverage 1127 1128 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1127)
private theorem w1128_0 : checkWitness 1128 false false 593 = true := by decide +kernel
private theorem w1128_1 : checkWitness 1128 false true 4685 = true := by decide +kernel
private theorem w1128_2 : checkWitness 1128 true false 593 = true := by decide +kernel
private theorem w1128_3 : checkWitness 1128 true true 4685 = true := by decide +kernel
private theorem cases1128 : checkFour 1128 (593,4685,593,4685) = true := by
  simp only [checkFour, w1128_0,w1128_1,w1128_2,w1128_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1128 : Coverage 1128 1129 := checkList_sound (ws:=[(593,4685,593,4685)]) (by simpa only [checkList, Bool.and_true] using cases1128)
private theorem w1129_0 : checkWitness 1129 false false 8854 = true := by decide +kernel
private theorem w1129_2 : checkWitness 1129 true false 8850 = true := by decide +kernel
private theorem cases1129 : checkFour 1129 (8854,0,8850,0) = true := by
  simp only [checkFour, w1129_0,w1129_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1129 : Coverage 1129 1130 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases1129)
private theorem w1130_0 : checkWitness 1130 false false 80 = true := by decide +kernel
private theorem w1130_2 : checkWitness 1130 true false 80 = true := by decide +kernel
private theorem cases1130 : checkFour 1130 (80,0,80,0) = true := by
  simp only [checkFour, w1130_0,w1130_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1130 : Coverage 1130 1131 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1130)
private theorem w1131_0 : checkWitness 1131 false false 548 = true := by decide +kernel
private theorem w1131_1 : checkWitness 1131 false true 4644 = true := by decide +kernel
private theorem w1131_2 : checkWitness 1131 true false 548 = true := by decide +kernel
private theorem w1131_3 : checkWitness 1131 true true 4644 = true := by decide +kernel
private theorem cases1131 : checkFour 1131 (548,4644,548,4644) = true := by
  simp only [checkFour, w1131_0,w1131_1,w1131_2,w1131_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1131 : Coverage 1131 1132 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases1131)
private theorem w1132_0 : checkWitness 1132 false false 8889 = true := by decide +kernel
private theorem w1132_2 : checkWitness 1132 true false 8885 = true := by decide +kernel
private theorem cases1132 : checkFour 1132 (8889,0,8885,0) = true := by
  simp only [checkFour, w1132_0,w1132_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1132 : Coverage 1132 1133 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1132)
private theorem w1133_0 : checkWitness 1133 false false 8924 = true := by decide +kernel
private theorem w1133_2 : checkWitness 1133 true false 8915 = true := by decide +kernel
private theorem cases1133 : checkFour 1133 (8924,0,8915,0) = true := by
  simp only [checkFour, w1133_0,w1133_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1133 : Coverage 1133 1134 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases1133)
private theorem w1134_0 : checkWitness 1134 false false 98 = true := by decide +kernel
private theorem w1134_2 : checkWitness 1134 true false 98 = true := by decide +kernel
private theorem cases1134 : checkFour 1134 (98,0,98,0) = true := by
  simp only [checkFour, w1134_0,w1134_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1134 : Coverage 1134 1135 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1134)
private theorem w1135_0 : checkWitness 1135 false false 636 = true := by decide +kernel
private theorem w1135_1 : checkWitness 1135 false true 4728 = true := by decide +kernel
private theorem w1135_2 : checkWitness 1135 true false 627 = true := by decide +kernel
private theorem w1135_3 : checkWitness 1135 true true 4719 = true := by decide +kernel
private theorem cases1135 : checkFour 1135 (636,4728,627,4719) = true := by
  simp only [checkFour, w1135_0,w1135_1,w1135_2,w1135_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1135 : Coverage 1135 1136 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases1135)
private theorem w1136_0 : checkWitness 1136 false false 8885 = true := by decide +kernel
private theorem w1136_2 : checkWitness 1136 true false 8881 = true := by decide +kernel
private theorem cases1136 : checkFour 1136 (8885,0,8881,0) = true := by
  simp only [checkFour, w1136_0,w1136_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1136 : Coverage 1136 1137 := checkList_sound (ws:=[(8885,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases1136)
private theorem w1137_0 : checkWitness 1137 false false 630 = true := by decide +kernel
private theorem w1137_1 : checkWitness 1137 false true 4722 = true := by decide +kernel
private theorem w1137_2 : checkWitness 1137 true false 621 = true := by decide +kernel
private theorem w1137_3 : checkWitness 1137 true true 4713 = true := by decide +kernel
private theorem cases1137 : checkFour 1137 (630,4722,621,4713) = true := by
  simp only [checkFour, w1137_0,w1137_1,w1137_2,w1137_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1137 : Coverage 1137 1138 := checkList_sound (ws:=[(630,4722,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases1137)
private theorem w1138_0 : checkWitness 1138 false false 8854 = true := by decide +kernel
private theorem w1138_2 : checkWitness 1138 true false 8850 = true := by decide +kernel
private theorem cases1138 : checkFour 1138 (8854,0,8850,0) = true := by
  simp only [checkFour, w1138_0,w1138_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1138 : Coverage 1138 1139 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases1138)
private theorem w1139_0 : checkWitness 1139 false false 86 = true := by decide +kernel
private theorem w1139_2 : checkWitness 1139 true false 86 = true := by decide +kernel
private theorem cases1139 : checkFour 1139 (86,0,86,0) = true := by
  simp only [checkFour, w1139_0,w1139_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1139 : Coverage 1139 1140 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1139)
private theorem w1140_0 : checkWitness 1140 false false 78 = true := by decide +kernel
private theorem w1140_2 : checkWitness 1140 true false 78 = true := by decide +kernel
private theorem cases1140 : checkFour 1140 (78,0,78,0) = true := by
  simp only [checkFour, w1140_0,w1140_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1140 : Coverage 1140 1141 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1140)
private theorem w1141_0 : checkWitness 1141 false false 597 = true := by decide +kernel
private theorem w1141_1 : checkWitness 1141 false true 4685 = true := by decide +kernel
private theorem w1141_2 : checkWitness 1141 true false 597 = true := by decide +kernel
private theorem w1141_3 : checkWitness 1141 true true 4685 = true := by decide +kernel
private theorem cases1141 : checkFour 1141 (597,4685,597,4685) = true := by
  simp only [checkFour, w1141_0,w1141_1,w1141_2,w1141_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1141 : Coverage 1141 1142 := checkList_sound (ws:=[(597,4685,597,4685)]) (by simpa only [checkList, Bool.and_true] using cases1141)
private theorem w1142_0 : checkWitness 1142 false false 8870 = true := by decide +kernel
private theorem w1142_2 : checkWitness 1142 true false 8866 = true := by decide +kernel
private theorem cases1142 : checkFour 1142 (8870,0,8866,0) = true := by
  simp only [checkFour, w1142_0,w1142_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1142 : Coverage 1142 1143 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases1142)
private theorem w1143_0 : checkWitness 1143 false false 8866 = true := by decide +kernel
private theorem w1143_2 : checkWitness 1143 true false 8862 = true := by decide +kernel
private theorem cases1143 : checkFour 1143 (8866,0,8862,0) = true := by
  simp only [checkFour, w1143_0,w1143_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1143 : Coverage 1143 1144 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases1143)
private theorem w1144_0 : checkWitness 1144 false false 92 = true := by decide +kernel
private theorem w1144_2 : checkWitness 1144 true false 92 = true := by decide +kernel
private theorem cases1144 : checkFour 1144 (92,0,92,0) = true := by
  simp only [checkFour, w1144_0,w1144_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1144 : Coverage 1144 1145 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1144)
private theorem w1145_0 : checkWitness 1145 false false 8890 = true := by decide +kernel
private theorem w1145_2 : checkWitness 1145 true false 8886 = true := by decide +kernel
private theorem cases1145 : checkFour 1145 (8890,0,8886,0) = true := by
  simp only [checkFour, w1145_0,w1145_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1145 : Coverage 1145 1146 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases1145)
private theorem w1146_0 : checkWitness 1146 false false 8892 = true := by decide +kernel
private theorem w1146_2 : checkWitness 1146 true false 8888 = true := by decide +kernel
private theorem cases1146 : checkFour 1146 (8892,0,8888,0) = true := by
  simp only [checkFour, w1146_0,w1146_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1146 : Coverage 1146 1147 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases1146)
private theorem w1147_0 : checkWitness 1147 false false 520 = true := by decide +kernel
private theorem w1147_1 : checkWitness 1147 false true 4616 = true := by decide +kernel
private theorem w1147_2 : checkWitness 1147 true false 520 = true := by decide +kernel
private theorem w1147_3 : checkWitness 1147 true true 4616 = true := by decide +kernel
private theorem cases1147 : checkFour 1147 (520,4616,520,4616) = true := by
  simp only [checkFour, w1147_0,w1147_1,w1147_2,w1147_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1147 : Coverage 1147 1148 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases1147)
private theorem w1148_0 : checkWitness 1148 false false 8915 = true := by decide +kernel
private theorem w1148_2 : checkWitness 1148 true false 8911 = true := by decide +kernel
private theorem cases1148 : checkFour 1148 (8915,0,8911,0) = true := by
  simp only [checkFour, w1148_0,w1148_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1148 : Coverage 1148 1149 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases1148)
private theorem w1149_0 : checkWitness 1149 false false 646 = true := by decide +kernel
private theorem w1149_1 : checkWitness 1149 false true 4742 = true := by decide +kernel
private theorem w1149_2 : checkWitness 1149 true false 637 = true := by decide +kernel
private theorem w1149_3 : checkWitness 1149 true true 4733 = true := by decide +kernel
private theorem cases1149 : checkFour 1149 (646,4742,637,4733) = true := by
  simp only [checkFour, w1149_0,w1149_1,w1149_2,w1149_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1149 : Coverage 1149 1150 := checkList_sound (ws:=[(646,4742,637,4733)]) (by simpa only [checkList, Bool.and_true] using cases1149)
private theorem w1150_0 : checkWitness 1150 false false 184 = true := by decide +kernel
private theorem w1150_2 : checkWitness 1150 true false 184 = true := by decide +kernel
private theorem cases1150 : checkFour 1150 (184,0,184,0) = true := by
  simp only [checkFour, w1150_0,w1150_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1150 : Coverage 1150 1151 := checkList_sound (ws:=[(184,0,184,0)]) (by simpa only [checkList, Bool.and_true] using cases1150)
private theorem w1151_0 : checkWitness 1151 false false 601 = true := by decide +kernel
private theorem w1151_1 : checkWitness 1151 false true 4689 = true := by decide +kernel
private theorem w1151_2 : checkWitness 1151 true false 601 = true := by decide +kernel
private theorem w1151_3 : checkWitness 1151 true true 4689 = true := by decide +kernel
private theorem cases1151 : checkFour 1151 (601,4689,601,4689) = true := by
  simp only [checkFour, w1151_0,w1151_1,w1151_2,w1151_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1151 : Coverage 1151 1152 := checkList_sound (ws:=[(601,4689,601,4689)]) (by simpa only [checkList, Bool.and_true] using cases1151)
theorem cover1120 : Coverage 1120 1152 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1120 one1121) (Coverage.join one1122 one1123)) (Coverage.join (Coverage.join one1124 one1125) (Coverage.join one1126 one1127))) (Coverage.join (Coverage.join (Coverage.join one1128 one1129) (Coverage.join one1130 one1131)) (Coverage.join (Coverage.join one1132 one1133) (Coverage.join one1134 one1135)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1136 one1137) (Coverage.join one1138 one1139)) (Coverage.join (Coverage.join one1140 one1141) (Coverage.join one1142 one1143))) (Coverage.join (Coverage.join (Coverage.join one1144 one1145) (Coverage.join one1146 one1147)) (Coverage.join (Coverage.join one1148 one1149) (Coverage.join one1150 one1151)))))
end NF180PA.Symbolic
