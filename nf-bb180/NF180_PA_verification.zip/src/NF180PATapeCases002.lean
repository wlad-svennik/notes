import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w64_0 : checkWitness 64 false false 8925 = true := by decide +kernel
private theorem w64_2 : checkWitness 64 true false 8921 = true := by decide +kernel
private theorem cases64 : checkFour 64 (8925,0,8921,0) = true := by
  simp only [checkFour, w64_0,w64_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one64 : Coverage 64 65 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases64)
private theorem w65_0 : checkWitness 65 false false 670 = true := by decide +kernel
private theorem w65_1 : checkWitness 65 false true 4762 = true := by decide +kernel
private theorem w65_2 : checkWitness 65 true false 661 = true := by decide +kernel
private theorem w65_3 : checkWitness 65 true true 4753 = true := by decide +kernel
private theorem cases65 : checkFour 65 (670,4762,661,4753) = true := by
  simp only [checkFour, w65_0,w65_1,w65_2,w65_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one65 : Coverage 65 66 := checkList_sound (ws:=[(670,4762,661,4753)]) (by simpa only [checkList, Bool.and_true] using cases65)
private theorem w66_0 : checkWitness 66 false false 8894 = true := by decide +kernel
private theorem w66_2 : checkWitness 66 true false 8890 = true := by decide +kernel
private theorem cases66 : checkFour 66 (8894,0,8890,0) = true := by
  simp only [checkFour, w66_0,w66_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one66 : Coverage 66 67 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases66)
private theorem w67_0 : checkWitness 67 false false 66 = true := by decide +kernel
private theorem w67_2 : checkWitness 67 true false 66 = true := by decide +kernel
private theorem cases67 : checkFour 67 (66,0,66,0) = true := by
  simp only [checkFour, w67_0,w67_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one67 : Coverage 67 68 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases67)
private theorem w68_0 : checkWitness 68 false false 58 = true := by decide +kernel
private theorem w68_2 : checkWitness 68 true false 58 = true := by decide +kernel
private theorem cases68 : checkFour 68 (58,0,58,0) = true := by
  simp only [checkFour, w68_0,w68_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one68 : Coverage 68 69 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases68)
private theorem w69_0 : checkWitness 69 false false 635 = true := by decide +kernel
private theorem w69_1 : checkWitness 69 false true 4719 = true := by decide +kernel
private theorem w69_2 : checkWitness 69 true false 635 = true := by decide +kernel
private theorem w69_3 : checkWitness 69 true true 4719 = true := by decide +kernel
private theorem cases69 : checkFour 69 (635,4719,635,4719) = true := by
  simp only [checkFour, w69_0,w69_1,w69_2,w69_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one69 : Coverage 69 70 := checkList_sound (ws:=[(635,4719,635,4719)]) (by simpa only [checkList, Bool.and_true] using cases69)
private theorem w70_0 : checkWitness 70 false false 8888 = true := by decide +kernel
private theorem w70_2 : checkWitness 70 true false 8884 = true := by decide +kernel
private theorem cases70 : checkFour 70 (8888,0,8884,0) = true := by
  simp only [checkFour, w70_0,w70_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one70 : Coverage 70 71 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases70)
private theorem w71_0 : checkWitness 71 false false 58 = true := by decide +kernel
private theorem w71_2 : checkWitness 71 true false 58 = true := by decide +kernel
private theorem cases71 : checkFour 71 (58,0,58,0) = true := by
  simp only [checkFour, w71_0,w71_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one71 : Coverage 71 72 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases71)
private theorem w72_0 : checkWitness 72 false false 640 = true := by decide +kernel
private theorem w72_1 : checkWitness 72 false true 4736 = true := by decide +kernel
private theorem w72_2 : checkWitness 72 true false 640 = true := by decide +kernel
private theorem w72_3 : checkWitness 72 true true 4736 = true := by decide +kernel
private theorem cases72 : checkFour 72 (640,4736,640,4736) = true := by
  simp only [checkFour, w72_0,w72_1,w72_2,w72_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one72 : Coverage 72 73 := checkList_sound (ws:=[(640,4736,640,4736)]) (by simpa only [checkList, Bool.and_true] using cases72)
private theorem w73_0 : checkWitness 73 false false 8956 = true := by decide +kernel
private theorem w73_2 : checkWitness 73 true false 8947 = true := by decide +kernel
private theorem cases73 : checkFour 73 (8956,0,8947,0) = true := by
  simp only [checkFour, w73_0,w73_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one73 : Coverage 73 74 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases73)
private theorem w74_0 : checkWitness 74 false false 8902 = true := by decide +kernel
private theorem w74_2 : checkWitness 74 true false 8898 = true := by decide +kernel
private theorem cases74 : checkFour 74 (8902,0,8898,0) = true := by
  simp only [checkFour, w74_0,w74_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one74 : Coverage 74 75 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases74)
private theorem w75_0 : checkWitness 75 false false 66 = true := by decide +kernel
private theorem w75_2 : checkWitness 75 true false 66 = true := by decide +kernel
private theorem cases75 : checkFour 75 (66,0,66,0) = true := by
  simp only [checkFour, w75_0,w75_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one75 : Coverage 75 76 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases75)
private theorem w76_0 : checkWitness 76 false false 686 = true := by decide +kernel
private theorem w76_1 : checkWitness 76 false true 4774 = true := by decide +kernel
private theorem w76_2 : checkWitness 76 true false 677 = true := by decide +kernel
private theorem w76_3 : checkWitness 76 true true 4765 = true := by decide +kernel
private theorem cases76 : checkFour 76 (686,4774,677,4765) = true := by
  simp only [checkFour, w76_0,w76_1,w76_2,w76_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one76 : Coverage 76 77 := checkList_sound (ws:=[(686,4774,677,4765)]) (by simpa only [checkList, Bool.and_true] using cases76)
private theorem w77_0 : checkWitness 77 false false 8944 = true := by decide +kernel
private theorem w77_2 : checkWitness 77 true false 8940 = true := by decide +kernel
private theorem cases77 : checkFour 77 (8944,0,8940,0) = true := by
  simp only [checkFour, w77_0,w77_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one77 : Coverage 77 78 := checkList_sound (ws:=[(8944,0,8940,0)]) (by simpa only [checkList, Bool.and_true] using cases77)
private theorem w78_0 : checkWitness 78 false false 56 = true := by decide +kernel
private theorem w78_2 : checkWitness 78 true false 56 = true := by decide +kernel
private theorem cases78 : checkFour 78 (56,0,56,0) = true := by
  simp only [checkFour, w78_0,w78_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one78 : Coverage 78 79 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases78)
private theorem w79_0 : checkWitness 79 false false 688 = true := by decide +kernel
private theorem w79_1 : checkWitness 79 false true 4784 = true := by decide +kernel
private theorem w79_2 : checkWitness 79 true false 688 = true := by decide +kernel
private theorem w79_3 : checkWitness 79 true true 4784 = true := by decide +kernel
private theorem cases79 : checkFour 79 (688,4784,688,4784) = true := by
  simp only [checkFour, w79_0,w79_1,w79_2,w79_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one79 : Coverage 79 80 := checkList_sound (ws:=[(688,4784,688,4784)]) (by simpa only [checkList, Bool.and_true] using cases79)
private theorem w80_0 : checkWitness 80 false false 8966 = true := by decide +kernel
private theorem w80_2 : checkWitness 80 true false 8957 = true := by decide +kernel
private theorem cases80 : checkFour 80 (8966,0,8957,0) = true := by
  simp only [checkFour, w80_0,w80_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one80 : Coverage 80 81 := checkList_sound (ws:=[(8966,0,8957,0)]) (by simpa only [checkList, Bool.and_true] using cases80)
private theorem w81_0 : checkWitness 81 false false 58 = true := by decide +kernel
private theorem w81_2 : checkWitness 81 true false 58 = true := by decide +kernel
private theorem cases81 : checkFour 81 (58,0,58,0) = true := by
  simp only [checkFour, w81_0,w81_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one81 : Coverage 81 82 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases81)
private theorem w82_0 : checkWitness 82 false false 548 = true := by decide +kernel
private theorem w82_1 : checkWitness 82 false true 4644 = true := by decide +kernel
private theorem w82_2 : checkWitness 82 true false 548 = true := by decide +kernel
private theorem w82_3 : checkWitness 82 true true 4644 = true := by decide +kernel
private theorem cases82 : checkFour 82 (548,4644,548,4644) = true := by
  simp only [checkFour, w82_0,w82_1,w82_2,w82_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one82 : Coverage 82 83 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases82)
private theorem w83_0 : checkWitness 83 false false 8906 = true := by decide +kernel
private theorem w83_2 : checkWitness 83 true false 8902 = true := by decide +kernel
private theorem cases83 : checkFour 83 (8906,0,8902,0) = true := by
  simp only [checkFour, w83_0,w83_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one83 : Coverage 83 84 := checkList_sound (ws:=[(8906,0,8902,0)]) (by simpa only [checkList, Bool.and_true] using cases83)
private theorem w84_0 : checkWitness 84 false false 60 = true := by decide +kernel
private theorem w84_2 : checkWitness 84 true false 60 = true := by decide +kernel
private theorem cases84 : checkFour 84 (60,0,60,0) = true := by
  simp only [checkFour, w84_0,w84_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one84 : Coverage 84 85 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases84)
private theorem w85_0 : checkWitness 85 false false 586 = true := by decide +kernel
private theorem w85_1 : checkWitness 85 false true 4682 = true := by decide +kernel
private theorem w85_2 : checkWitness 85 true false 586 = true := by decide +kernel
private theorem w85_3 : checkWitness 85 true true 4682 = true := by decide +kernel
private theorem cases85 : checkFour 85 (586,4682,586,4682) = true := by
  simp only [checkFour, w85_0,w85_1,w85_2,w85_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one85 : Coverage 85 86 := checkList_sound (ws:=[(586,4682,586,4682)]) (by simpa only [checkList, Bool.and_true] using cases85)
private theorem w86_0 : checkWitness 86 false false 8927 = true := by decide +kernel
private theorem w86_2 : checkWitness 86 true false 8923 = true := by decide +kernel
private theorem cases86 : checkFour 86 (8927,0,8923,0) = true := by
  simp only [checkFour, w86_0,w86_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one86 : Coverage 86 87 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases86)
private theorem w87_0 : checkWitness 87 false false 8962 = true := by decide +kernel
private theorem w87_2 : checkWitness 87 true false 8953 = true := by decide +kernel
private theorem cases87 : checkFour 87 (8962,0,8953,0) = true := by
  simp only [checkFour, w87_0,w87_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one87 : Coverage 87 88 := checkList_sound (ws:=[(8962,0,8953,0)]) (by simpa only [checkList, Bool.and_true] using cases87)
private theorem w88_0 : checkWitness 88 false false 84 = true := by decide +kernel
private theorem w88_2 : checkWitness 88 true false 84 = true := by decide +kernel
private theorem cases88 : checkFour 88 (84,0,84,0) = true := by
  simp only [checkFour, w88_0,w88_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one88 : Coverage 88 89 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases88)
private theorem w89_0 : checkWitness 89 false false 674 = true := by decide +kernel
private theorem w89_1 : checkWitness 89 false true 4766 = true := by decide +kernel
private theorem w89_2 : checkWitness 89 true false 665 = true := by decide +kernel
private theorem w89_3 : checkWitness 89 true true 4757 = true := by decide +kernel
private theorem cases89 : checkFour 89 (674,4766,665,4757) = true := by
  simp only [checkFour, w89_0,w89_1,w89_2,w89_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one89 : Coverage 89 90 := checkList_sound (ws:=[(674,4766,665,4757)]) (by simpa only [checkList, Bool.and_true] using cases89)
private theorem w90_0 : checkWitness 90 false false 8923 = true := by decide +kernel
private theorem w90_2 : checkWitness 90 true false 8919 = true := by decide +kernel
private theorem cases90 : checkFour 90 (8923,0,8919,0) = true := by
  simp only [checkFour, w90_0,w90_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one90 : Coverage 90 91 := checkList_sound (ws:=[(8923,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases90)
private theorem w91_0 : checkWitness 91 false false 668 = true := by decide +kernel
private theorem w91_1 : checkWitness 91 false true 4760 = true := by decide +kernel
private theorem w91_2 : checkWitness 91 true false 659 = true := by decide +kernel
private theorem w91_3 : checkWitness 91 true true 4751 = true := by decide +kernel
private theorem cases91 : checkFour 91 (668,4760,659,4751) = true := by
  simp only [checkFour, w91_0,w91_1,w91_2,w91_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one91 : Coverage 91 92 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases91)
private theorem w92_0 : checkWitness 92 false false 8892 = true := by decide +kernel
private theorem w92_2 : checkWitness 92 true false 8888 = true := by decide +kernel
private theorem cases92 : checkFour 92 (8892,0,8888,0) = true := by
  simp only [checkFour, w92_0,w92_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one92 : Coverage 92 93 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases92)
private theorem w93_0 : checkWitness 93 false false 72 = true := by decide +kernel
private theorem w93_2 : checkWitness 93 true false 72 = true := by decide +kernel
private theorem cases93 : checkFour 93 (72,0,72,0) = true := by
  simp only [checkFour, w93_0,w93_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one93 : Coverage 93 94 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases93)
private theorem w94_0 : checkWitness 94 false false 64 = true := by decide +kernel
private theorem w94_2 : checkWitness 94 true false 64 = true := by decide +kernel
private theorem cases94 : checkFour 94 (64,0,64,0) = true := by
  simp only [checkFour, w94_0,w94_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one94 : Coverage 94 95 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases94)
private theorem w95_0 : checkWitness 95 false false 633 = true := by decide +kernel
private theorem w95_1 : checkWitness 95 false true 4717 = true := by decide +kernel
private theorem w95_2 : checkWitness 95 true false 633 = true := by decide +kernel
private theorem w95_3 : checkWitness 95 true true 4717 = true := by decide +kernel
private theorem cases95 : checkFour 95 (633,4717,633,4717) = true := by
  simp only [checkFour, w95_0,w95_1,w95_2,w95_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one95 : Coverage 95 96 := checkList_sound (ws:=[(633,4717,633,4717)]) (by simpa only [checkList, Bool.and_true] using cases95)
theorem cover0064 : Coverage 64 96 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one64 one65) (Coverage.join one66 one67)) (Coverage.join (Coverage.join one68 one69) (Coverage.join one70 one71))) (Coverage.join (Coverage.join (Coverage.join one72 one73) (Coverage.join one74 one75)) (Coverage.join (Coverage.join one76 one77) (Coverage.join one78 one79)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one80 one81) (Coverage.join one82 one83)) (Coverage.join (Coverage.join one84 one85) (Coverage.join one86 one87))) (Coverage.join (Coverage.join (Coverage.join one88 one89) (Coverage.join one90 one91)) (Coverage.join (Coverage.join one92 one93) (Coverage.join one94 one95)))))
end NF180PA.Symbolic
