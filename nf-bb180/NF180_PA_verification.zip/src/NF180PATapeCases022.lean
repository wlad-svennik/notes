import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w704_0 : checkWitness 704 false false 74 = true := by decide +kernel
private theorem w704_2 : checkWitness 704 true false 74 = true := by decide +kernel
private theorem cases704 : checkFour 704 (74,0,74,0) = true := by
  simp only [checkFour, w704_0,w704_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one704 : Coverage 704 705 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases704)
private theorem w705_0 : checkWitness 705 false false 628 = true := by decide +kernel
private theorem w705_1 : checkWitness 705 false true 4724 = true := by decide +kernel
private theorem w705_2 : checkWitness 705 true false 628 = true := by decide +kernel
private theorem w705_3 : checkWitness 705 true true 4724 = true := by decide +kernel
private theorem cases705 : checkFour 705 (628,4724,628,4724) = true := by
  simp only [checkFour, w705_0,w705_1,w705_2,w705_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one705 : Coverage 705 706 := checkList_sound (ws:=[(628,4724,628,4724)]) (by simpa only [checkList, Bool.and_true] using cases705)
private theorem w706_0 : checkWitness 706 false false 8944 = true := by decide +kernel
private theorem w706_2 : checkWitness 706 true false 8935 = true := by decide +kernel
private theorem cases706 : checkFour 706 (8944,0,8935,0) = true := by
  simp only [checkFour, w706_0,w706_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one706 : Coverage 706 707 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases706)
private theorem w707_0 : checkWitness 707 false false 8890 = true := by decide +kernel
private theorem w707_2 : checkWitness 707 true false 8886 = true := by decide +kernel
private theorem cases707 : checkFour 707 (8890,0,8886,0) = true := by
  simp only [checkFour, w707_0,w707_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one707 : Coverage 707 708 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases707)
private theorem w708_0 : checkWitness 708 false false 82 = true := by decide +kernel
private theorem w708_2 : checkWitness 708 true false 82 = true := by decide +kernel
private theorem cases708 : checkFour 708 (82,0,82,0) = true := by
  simp only [checkFour, w708_0,w708_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one708 : Coverage 708 709 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases708)
private theorem w709_0 : checkWitness 709 false false 674 = true := by decide +kernel
private theorem w709_1 : checkWitness 709 false true 4762 = true := by decide +kernel
private theorem w709_2 : checkWitness 709 true false 665 = true := by decide +kernel
private theorem w709_3 : checkWitness 709 true true 4753 = true := by decide +kernel
private theorem cases709 : checkFour 709 (674,4762,665,4753) = true := by
  simp only [checkFour, w709_0,w709_1,w709_2,w709_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one709 : Coverage 709 710 := checkList_sound (ws:=[(674,4762,665,4753)]) (by simpa only [checkList, Bool.and_true] using cases709)
private theorem w710_0 : checkWitness 710 false false 8932 = true := by decide +kernel
private theorem w710_2 : checkWitness 710 true false 8928 = true := by decide +kernel
private theorem cases710 : checkFour 710 (8932,0,8928,0) = true := by
  simp only [checkFour, w710_0,w710_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one710 : Coverage 710 711 := checkList_sound (ws:=[(8932,0,8928,0)]) (by simpa only [checkList, Bool.and_true] using cases710)
private theorem w711_0 : checkWitness 711 false false 72 = true := by decide +kernel
private theorem w711_2 : checkWitness 711 true false 72 = true := by decide +kernel
private theorem cases711 : checkFour 711 (72,0,72,0) = true := by
  simp only [checkFour, w711_0,w711_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one711 : Coverage 711 712 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases711)
private theorem w712_0 : checkWitness 712 false false 520 = true := by decide +kernel
private theorem w712_1 : checkWitness 712 false true 4616 = true := by decide +kernel
private theorem w712_2 : checkWitness 712 true false 520 = true := by decide +kernel
private theorem w712_3 : checkWitness 712 true true 4616 = true := by decide +kernel
private theorem cases712 : checkFour 712 (520,4616,520,4616) = true := by
  simp only [checkFour, w712_0,w712_1,w712_2,w712_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one712 : Coverage 712 713 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases712)
private theorem w713_0 : checkWitness 713 false false 8915 = true := by decide +kernel
private theorem w713_2 : checkWitness 713 true false 8911 = true := by decide +kernel
private theorem cases713 : checkFour 713 (8915,0,8911,0) = true := by
  simp only [checkFour, w713_0,w713_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one713 : Coverage 713 714 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases713)
private theorem w714_0 : checkWitness 714 false false 646 = true := by decide +kernel
private theorem w714_1 : checkWitness 714 false true 4742 = true := by decide +kernel
private theorem w714_2 : checkWitness 714 true false 637 = true := by decide +kernel
private theorem w714_3 : checkWitness 714 true true 4733 = true := by decide +kernel
private theorem cases714 : checkFour 714 (646,4742,637,4733) = true := by
  simp only [checkFour, w714_0,w714_1,w714_2,w714_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one714 : Coverage 714 715 := checkList_sound (ws:=[(646,4742,637,4733)]) (by simpa only [checkList, Bool.and_true] using cases714)
private theorem w715_0 : checkWitness 715 false false 188 = true := by decide +kernel
private theorem w715_2 : checkWitness 715 true false 188 = true := by decide +kernel
private theorem cases715 : checkFour 715 (188,0,188,0) = true := by
  simp only [checkFour, w715_0,w715_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one715 : Coverage 715 716 := checkList_sound (ws:=[(188,0,188,0)]) (by simpa only [checkList, Bool.and_true] using cases715)
private theorem w716_0 : checkWitness 716 false false 601 = true := by decide +kernel
private theorem w716_1 : checkWitness 716 false true 4689 = true := by decide +kernel
private theorem w716_2 : checkWitness 716 true false 601 = true := by decide +kernel
private theorem w716_3 : checkWitness 716 true true 4689 = true := by decide +kernel
private theorem cases716 : checkFour 716 (601,4689,601,4689) = true := by
  simp only [checkFour, w716_0,w716_1,w716_2,w716_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one716 : Coverage 716 717 := checkList_sound (ws:=[(601,4689,601,4689)]) (by simpa only [checkList, Bool.and_true] using cases716)
private theorem w717_0 : checkWitness 717 false false 8930 = true := by decide +kernel
private theorem w717_2 : checkWitness 717 true false 8921 = true := by decide +kernel
private theorem cases717 : checkFour 717 (8930,0,8921,0) = true := by
  simp only [checkFour, w717_0,w717_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one717 : Coverage 717 718 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases717)
private theorem w718_0 : checkWitness 718 false false 76 = true := by decide +kernel
private theorem w718_2 : checkWitness 718 true false 76 = true := by decide +kernel
private theorem cases718 : checkFour 718 (76,0,76,0) = true := by
  simp only [checkFour, w718_0,w718_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one718 : Coverage 718 719 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases718)
private theorem w719_0 : checkWitness 719 false false 68 = true := by decide +kernel
private theorem w719_2 : checkWitness 719 true false 68 = true := by decide +kernel
private theorem cases719 : checkFour 719 (68,0,68,0) = true := by
  simp only [checkFour, w719_0,w719_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one719 : Coverage 719 720 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases719)
private theorem w720_0 : checkWitness 720 false false 607 = true := by decide +kernel
private theorem w720_1 : checkWitness 720 false true 4699 = true := by decide +kernel
private theorem w720_2 : checkWitness 720 true false 607 = true := by decide +kernel
private theorem w720_3 : checkWitness 720 true true 4699 = true := by decide +kernel
private theorem cases720 : checkFour 720 (607,4699,607,4699) = true := by
  simp only [checkFour, w720_0,w720_1,w720_2,w720_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one720 : Coverage 720 721 := checkList_sound (ws:=[(607,4699,607,4699)]) (by simpa only [checkList, Bool.and_true] using cases720)
private theorem w721_0 : checkWitness 721 false false 8868 = true := by decide +kernel
private theorem w721_2 : checkWitness 721 true false 8864 = true := by decide +kernel
private theorem cases721 : checkFour 721 (8868,0,8864,0) = true := by
  simp only [checkFour, w721_0,w721_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one721 : Coverage 721 722 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases721)
private theorem w722_0 : checkWitness 722 false false 68 = true := by decide +kernel
private theorem w722_2 : checkWitness 722 true false 68 = true := by decide +kernel
private theorem cases722 : checkFour 722 (68,0,68,0) = true := by
  simp only [checkFour, w722_0,w722_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one722 : Coverage 722 723 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases722)
private theorem w723_0 : checkWitness 723 false false 562 = true := by decide +kernel
private theorem w723_1 : checkWitness 723 false true 4658 = true := by decide +kernel
private theorem w723_2 : checkWitness 723 true false 562 = true := by decide +kernel
private theorem w723_3 : checkWitness 723 true true 4658 = true := by decide +kernel
private theorem cases723 : checkFour 723 (562,4658,562,4658) = true := by
  simp only [checkFour, w723_0,w723_1,w723_2,w723_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one723 : Coverage 723 724 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases723)
private theorem w724_0 : checkWitness 724 false false 8903 = true := by decide +kernel
private theorem w724_2 : checkWitness 724 true false 8899 = true := by decide +kernel
private theorem cases724 : checkFour 724 (8903,0,8899,0) = true := by
  simp only [checkFour, w724_0,w724_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one724 : Coverage 724 725 := checkList_sound (ws:=[(8903,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases724)
private theorem w725_0 : checkWitness 725 false false 8938 = true := by decide +kernel
private theorem w725_2 : checkWitness 725 true false 8929 = true := by decide +kernel
private theorem cases725 : checkFour 725 (8938,0,8929,0) = true := by
  simp only [checkFour, w725_0,w725_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one725 : Coverage 725 726 := checkList_sound (ws:=[(8938,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases725)
private theorem w726_0 : checkWitness 726 false false 86 = true := by decide +kernel
private theorem w726_2 : checkWitness 726 true false 86 = true := by decide +kernel
private theorem cases726 : checkFour 726 (86,0,86,0) = true := by
  simp only [checkFour, w726_0,w726_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one726 : Coverage 726 727 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases726)
private theorem w727_0 : checkWitness 727 false false 650 = true := by decide +kernel
private theorem w727_1 : checkWitness 727 false true 4742 = true := by decide +kernel
private theorem w727_2 : checkWitness 727 true false 641 = true := by decide +kernel
private theorem w727_3 : checkWitness 727 true true 4733 = true := by decide +kernel
private theorem cases727 : checkFour 727 (650,4742,641,4733) = true := by
  simp only [checkFour, w727_0,w727_1,w727_2,w727_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one727 : Coverage 727 728 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases727)
private theorem w728_0 : checkWitness 728 false false 8899 = true := by decide +kernel
private theorem w728_2 : checkWitness 728 true false 8895 = true := by decide +kernel
private theorem cases728 : checkFour 728 (8899,0,8895,0) = true := by
  simp only [checkFour, w728_0,w728_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one728 : Coverage 728 729 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases728)
private theorem w729_0 : checkWitness 729 false false 644 = true := by decide +kernel
private theorem w729_1 : checkWitness 729 false true 4736 = true := by decide +kernel
private theorem w729_2 : checkWitness 729 true false 635 = true := by decide +kernel
private theorem w729_3 : checkWitness 729 true true 4727 = true := by decide +kernel
private theorem cases729 : checkFour 729 (644,4736,635,4727) = true := by
  simp only [checkFour, w729_0,w729_1,w729_2,w729_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one729 : Coverage 729 730 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases729)
private theorem w730_0 : checkWitness 730 false false 8868 = true := by decide +kernel
private theorem w730_2 : checkWitness 730 true false 8864 = true := by decide +kernel
private theorem cases730 : checkFour 730 (8868,0,8864,0) = true := by
  simp only [checkFour, w730_0,w730_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one730 : Coverage 730 731 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases730)
private theorem w731_0 : checkWitness 731 false false 74 = true := by decide +kernel
private theorem w731_2 : checkWitness 731 true false 74 = true := by decide +kernel
private theorem cases731 : checkFour 731 (74,0,74,0) = true := by
  simp only [checkFour, w731_0,w731_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one731 : Coverage 731 732 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases731)
private theorem w732_0 : checkWitness 732 false false 66 = true := by decide +kernel
private theorem w732_2 : checkWitness 732 true false 66 = true := by decide +kernel
private theorem cases732 : checkFour 732 (66,0,66,0) = true := by
  simp only [checkFour, w732_0,w732_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one732 : Coverage 732 733 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases732)
private theorem w733_0 : checkWitness 733 false false 611 = true := by decide +kernel
private theorem w733_1 : checkWitness 733 false true 4699 = true := by decide +kernel
private theorem w733_2 : checkWitness 733 true false 611 = true := by decide +kernel
private theorem w733_3 : checkWitness 733 true true 4699 = true := by decide +kernel
private theorem cases733 : checkFour 733 (611,4699,611,4699) = true := by
  simp only [checkFour, w733_0,w733_1,w733_2,w733_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one733 : Coverage 733 734 := checkList_sound (ws:=[(611,4699,611,4699)]) (by simpa only [checkList, Bool.and_true] using cases733)
private theorem w734_0 : checkWitness 734 false false 8884 = true := by decide +kernel
private theorem w734_2 : checkWitness 734 true false 8880 = true := by decide +kernel
private theorem cases734 : checkFour 734 (8884,0,8880,0) = true := by
  simp only [checkFour, w734_0,w734_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one734 : Coverage 734 735 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases734)
private theorem w735_0 : checkWitness 735 false false 8880 = true := by decide +kernel
private theorem w735_2 : checkWitness 735 true false 8876 = true := by decide +kernel
private theorem cases735 : checkFour 735 (8880,0,8876,0) = true := by
  simp only [checkFour, w735_0,w735_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one735 : Coverage 735 736 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases735)
theorem cover0704 : Coverage 704 736 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one704 one705) (Coverage.join one706 one707)) (Coverage.join (Coverage.join one708 one709) (Coverage.join one710 one711))) (Coverage.join (Coverage.join (Coverage.join one712 one713) (Coverage.join one714 one715)) (Coverage.join (Coverage.join one716 one717) (Coverage.join one718 one719)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one720 one721) (Coverage.join one722 one723)) (Coverage.join (Coverage.join one724 one725) (Coverage.join one726 one727))) (Coverage.join (Coverage.join (Coverage.join one728 one729) (Coverage.join one730 one731)) (Coverage.join (Coverage.join one732 one733) (Coverage.join one734 one735)))))
end NF180PA.Symbolic
