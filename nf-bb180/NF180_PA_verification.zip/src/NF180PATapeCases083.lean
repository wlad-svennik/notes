import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2656_0 : checkWitness 2656 false false 661 = true := by decide +kernel
private theorem w2656_1 : checkWitness 2656 false true 4745 = true := by decide +kernel
private theorem w2656_2 : checkWitness 2656 true false 661 = true := by decide +kernel
private theorem w2656_3 : checkWitness 2656 true true 4745 = true := by decide +kernel
private theorem cases2656 : checkFour 2656 (661,4745,661,4745) = true := by
  simp only [checkFour, w2656_0,w2656_1,w2656_2,w2656_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2656 : Coverage 2656 2657 := checkList_sound (ws:=[(661,4745,661,4745)]) (by simpa only [checkList, Bool.and_true] using cases2656)
private theorem w2657_0 : checkWitness 2657 false false 8914 = true := by decide +kernel
private theorem w2657_2 : checkWitness 2657 true false 8910 = true := by decide +kernel
private theorem cases2657 : checkFour 2657 (8914,0,8910,0) = true := by
  simp only [checkFour, w2657_0,w2657_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2657 : Coverage 2657 2658 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases2657)
private theorem w2658_0 : checkWitness 2658 false false 70 = true := by decide +kernel
private theorem w2658_2 : checkWitness 2658 true false 70 = true := by decide +kernel
private theorem cases2658 : checkFour 2658 (70,0,70,0) = true := by
  simp only [checkFour, w2658_0,w2658_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2658 : Coverage 2658 2659 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2658)
private theorem w2659_0 : checkWitness 2659 false false 659 = true := by decide +kernel
private theorem w2659_1 : checkWitness 2659 false true 4751 = true := by decide +kernel
private theorem w2659_2 : checkWitness 2659 true false 650 = true := by decide +kernel
private theorem w2659_3 : checkWitness 2659 true true 4742 = true := by decide +kernel
private theorem cases2659 : checkFour 2659 (659,4751,650,4742) = true := by
  simp only [checkFour, w2659_0,w2659_1,w2659_2,w2659_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2659 : Coverage 2659 2660 := checkList_sound (ws:=[(659,4751,650,4742)]) (by simpa only [checkList, Bool.and_true] using cases2659)
private theorem w2660_0 : checkWitness 2660 false false 8956 = true := by decide +kernel
private theorem w2660_2 : checkWitness 2660 true false 8947 = true := by decide +kernel
private theorem cases2660 : checkFour 2660 (8956,0,8947,0) = true := by
  simp only [checkFour, w2660_0,w2660_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2660 : Coverage 2660 2661 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2660)
private theorem w2661_0 : checkWitness 2661 false false 8902 = true := by decide +kernel
private theorem w2661_2 : checkWitness 2661 true false 8898 = true := by decide +kernel
private theorem cases2661 : checkFour 2661 (8902,0,8898,0) = true := by
  simp only [checkFour, w2661_0,w2661_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2661 : Coverage 2661 2662 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases2661)
private theorem w2662_0 : checkWitness 2662 false false 64 = true := by decide +kernel
private theorem w2662_2 : checkWitness 2662 true false 64 = true := by decide +kernel
private theorem cases2662 : checkFour 2662 (64,0,64,0) = true := by
  simp only [checkFour, w2662_0,w2662_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2662 : Coverage 2662 2663 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2662)
private theorem w2663_0 : checkWitness 2663 false false 686 = true := by decide +kernel
private theorem w2663_1 : checkWitness 2663 false true 4778 = true := by decide +kernel
private theorem w2663_2 : checkWitness 2663 true false 677 = true := by decide +kernel
private theorem w2663_3 : checkWitness 2663 true true 4769 = true := by decide +kernel
private theorem cases2663 : checkFour 2663 (686,4778,677,4769) = true := by
  simp only [checkFour, w2663_0,w2663_1,w2663_2,w2663_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2663 : Coverage 2663 2664 := checkList_sound (ws:=[(686,4778,677,4769)]) (by simpa only [checkList, Bool.and_true] using cases2663)
private theorem w2664_0 : checkWitness 2664 false false 8963 = true := by decide +kernel
private theorem w2664_2 : checkWitness 2664 true false 8954 = true := by decide +kernel
private theorem cases2664 : checkFour 2664 (8963,0,8954,0) = true := by
  simp only [checkFour, w2664_0,w2664_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2664 : Coverage 2664 2665 := checkList_sound (ws:=[(8963,0,8954,0)]) (by simpa only [checkList, Bool.and_true] using cases2664)
private theorem w2665_0 : checkWitness 2665 false false 48 = true := by decide +kernel
private theorem w2665_2 : checkWitness 2665 true false 48 = true := by decide +kernel
private theorem cases2665 : checkFour 2665 (48,0,48,0) = true := by
  simp only [checkFour, w2665_0,w2665_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2665 : Coverage 2665 2666 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2665)
private theorem w2666_0 : checkWitness 2666 false false 550 = true := by decide +kernel
private theorem w2666_1 : checkWitness 2666 false true 4646 = true := by decide +kernel
private theorem w2666_2 : checkWitness 2666 true false 550 = true := by decide +kernel
private theorem w2666_3 : checkWitness 2666 true true 4646 = true := by decide +kernel
private theorem cases2666 : checkFour 2666 (550,4646,550,4646) = true := by
  simp only [checkFour, w2666_0,w2666_1,w2666_2,w2666_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2666 : Coverage 2666 2667 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases2666)
private theorem w2667_0 : checkWitness 2667 false false 8945 = true := by decide +kernel
private theorem w2667_2 : checkWitness 2667 true false 8941 = true := by decide +kernel
private theorem cases2667 : checkFour 2667 (8945,0,8941,0) = true := by
  simp only [checkFour, w2667_0,w2667_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2667 : Coverage 2667 2668 := checkList_sound (ws:=[(8945,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2667)
private theorem w2668_0 : checkWitness 2668 false false 676 = true := by decide +kernel
private theorem w2668_1 : checkWitness 2668 false true 4772 = true := by decide +kernel
private theorem w2668_2 : checkWitness 2668 true false 667 = true := by decide +kernel
private theorem w2668_3 : checkWitness 2668 true true 4763 = true := by decide +kernel
private theorem cases2668 : checkFour 2668 (676,4772,667,4763) = true := by
  simp only [checkFour, w2668_0,w2668_1,w2668_2,w2668_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2668 : Coverage 2668 2669 := checkList_sound (ws:=[(676,4772,667,4763)]) (by simpa only [checkList, Bool.and_true] using cases2668)
private theorem w2669_0 : checkWitness 2669 false false 202 = true := by decide +kernel
private theorem w2669_2 : checkWitness 2669 true false 202 = true := by decide +kernel
private theorem cases2669 : checkFour 2669 (202,0,202,0) = true := by
  simp only [checkFour, w2669_0,w2669_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2669 : Coverage 2669 2670 := checkList_sound (ws:=[(202,0,202,0)]) (by simpa only [checkList, Bool.and_true] using cases2669)
private theorem w2670_0 : checkWitness 2670 false false 631 = true := by decide +kernel
private theorem w2670_1 : checkWitness 2670 false true 4719 = true := by decide +kernel
private theorem w2670_2 : checkWitness 2670 true false 631 = true := by decide +kernel
private theorem w2670_3 : checkWitness 2670 true true 4719 = true := by decide +kernel
private theorem cases2670 : checkFour 2670 (631,4719,631,4719) = true := by
  simp only [checkFour, w2670_0,w2670_1,w2670_2,w2670_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2670 : Coverage 2670 2671 := checkList_sound (ws:=[(631,4719,631,4719)]) (by simpa only [checkList, Bool.and_true] using cases2670)
private theorem w2671_0 : checkWitness 2671 false false 8960 = true := by decide +kernel
private theorem w2671_2 : checkWitness 2671 true false 8951 = true := by decide +kernel
private theorem cases2671 : checkFour 2671 (8960,0,8951,0) = true := by
  simp only [checkFour, w2671_0,w2671_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2671 : Coverage 2671 2672 := checkList_sound (ws:=[(8960,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases2671)
private theorem w2672_0 : checkWitness 2672 false false 66 = true := by decide +kernel
private theorem w2672_2 : checkWitness 2672 true false 66 = true := by decide +kernel
private theorem cases2672 : checkFour 2672 (66,0,66,0) = true := by
  simp only [checkFour, w2672_0,w2672_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2672 : Coverage 2672 2673 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2672)
private theorem w2673_0 : checkWitness 2673 false false 58 = true := by decide +kernel
private theorem w2673_2 : checkWitness 2673 true false 58 = true := by decide +kernel
private theorem cases2673 : checkFour 2673 (58,0,58,0) = true := by
  simp only [checkFour, w2673_0,w2673_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2673 : Coverage 2673 2674 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2673)
private theorem w2674_0 : checkWitness 2674 false false 637 = true := by decide +kernel
private theorem w2674_1 : checkWitness 2674 false true 4729 = true := by decide +kernel
private theorem w2674_2 : checkWitness 2674 true false 637 = true := by decide +kernel
private theorem w2674_3 : checkWitness 2674 true true 4729 = true := by decide +kernel
private theorem cases2674 : checkFour 2674 (637,4729,637,4729) = true := by
  simp only [checkFour, w2674_0,w2674_1,w2674_2,w2674_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2674 : Coverage 2674 2675 := checkList_sound (ws:=[(637,4729,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases2674)
private theorem w2675_0 : checkWitness 2675 false false 8898 = true := by decide +kernel
private theorem w2675_2 : checkWitness 2675 true false 8894 = true := by decide +kernel
private theorem cases2675 : checkFour 2675 (8898,0,8894,0) = true := by
  simp only [checkFour, w2675_0,w2675_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2675 : Coverage 2675 2676 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2675)
private theorem w2676_0 : checkWitness 2676 false false 58 = true := by decide +kernel
private theorem w2676_2 : checkWitness 2676 true false 58 = true := by decide +kernel
private theorem cases2676 : checkFour 2676 (58,0,58,0) = true := by
  simp only [checkFour, w2676_0,w2676_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2676 : Coverage 2676 2677 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2676)
private theorem w2677_0 : checkWitness 2677 false false 592 = true := by decide +kernel
private theorem w2677_1 : checkWitness 2677 false true 4688 = true := by decide +kernel
private theorem w2677_2 : checkWitness 2677 true false 592 = true := by decide +kernel
private theorem w2677_3 : checkWitness 2677 true true 4688 = true := by decide +kernel
private theorem cases2677 : checkFour 2677 (592,4688,592,4688) = true := by
  simp only [checkFour, w2677_0,w2677_1,w2677_2,w2677_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2677 : Coverage 2677 2678 := checkList_sound (ws:=[(592,4688,592,4688)]) (by simpa only [checkList, Bool.and_true] using cases2677)
private theorem w2678_0 : checkWitness 2678 false false 8933 = true := by decide +kernel
private theorem w2678_2 : checkWitness 2678 true false 8929 = true := by decide +kernel
private theorem cases2678 : checkFour 2678 (8933,0,8929,0) = true := by
  simp only [checkFour, w2678_0,w2678_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2678 : Coverage 2678 2679 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases2678)
private theorem w2679_0 : checkWitness 2679 false false 8968 = true := by decide +kernel
private theorem w2679_2 : checkWitness 2679 true false 8959 = true := by decide +kernel
private theorem cases2679 : checkFour 2679 (8968,0,8959,0) = true := by
  simp only [checkFour, w2679_0,w2679_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2679 : Coverage 2679 2680 := checkList_sound (ws:=[(8968,0,8959,0)]) (by simpa only [checkList, Bool.and_true] using cases2679)
private theorem w2680_0 : checkWitness 2680 false false 76 = true := by decide +kernel
private theorem w2680_2 : checkWitness 2680 true false 76 = true := by decide +kernel
private theorem cases2680 : checkFour 2680 (76,0,76,0) = true := by
  simp only [checkFour, w2680_0,w2680_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2680 : Coverage 2680 2681 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2680)
private theorem w2681_0 : checkWitness 2681 false false 680 = true := by decide +kernel
private theorem w2681_1 : checkWitness 2681 false true 4772 = true := by decide +kernel
private theorem w2681_2 : checkWitness 2681 true false 671 = true := by decide +kernel
private theorem w2681_3 : checkWitness 2681 true true 4763 = true := by decide +kernel
private theorem cases2681 : checkFour 2681 (680,4772,671,4763) = true := by
  simp only [checkFour, w2681_0,w2681_1,w2681_2,w2681_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2681 : Coverage 2681 2682 := checkList_sound (ws:=[(680,4772,671,4763)]) (by simpa only [checkList, Bool.and_true] using cases2681)
private theorem w2682_0 : checkWitness 2682 false false 8929 = true := by decide +kernel
private theorem w2682_2 : checkWitness 2682 true false 8925 = true := by decide +kernel
private theorem cases2682 : checkFour 2682 (8929,0,8925,0) = true := by
  simp only [checkFour, w2682_0,w2682_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2682 : Coverage 2682 2683 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases2682)
private theorem w2683_0 : checkWitness 2683 false false 674 = true := by decide +kernel
private theorem w2683_1 : checkWitness 2683 false true 4766 = true := by decide +kernel
private theorem w2683_2 : checkWitness 2683 true false 665 = true := by decide +kernel
private theorem w2683_3 : checkWitness 2683 true true 4757 = true := by decide +kernel
private theorem cases2683 : checkFour 2683 (674,4766,665,4757) = true := by
  simp only [checkFour, w2683_0,w2683_1,w2683_2,w2683_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2683 : Coverage 2683 2684 := checkList_sound (ws:=[(674,4766,665,4757)]) (by simpa only [checkList, Bool.and_true] using cases2683)
private theorem w2684_0 : checkWitness 2684 false false 8898 = true := by decide +kernel
private theorem w2684_2 : checkWitness 2684 true false 8894 = true := by decide +kernel
private theorem cases2684 : checkFour 2684 (8898,0,8894,0) = true := by
  simp only [checkFour, w2684_0,w2684_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2684 : Coverage 2684 2685 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2684)
private theorem w2685_0 : checkWitness 2685 false false 64 = true := by decide +kernel
private theorem w2685_2 : checkWitness 2685 true false 64 = true := by decide +kernel
private theorem cases2685 : checkFour 2685 (64,0,64,0) = true := by
  simp only [checkFour, w2685_0,w2685_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2685 : Coverage 2685 2686 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2685)
private theorem w2686_0 : checkWitness 2686 false false 56 = true := by decide +kernel
private theorem w2686_2 : checkWitness 2686 true false 56 = true := by decide +kernel
private theorem cases2686 : checkFour 2686 (56,0,56,0) = true := by
  simp only [checkFour, w2686_0,w2686_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2686 : Coverage 2686 2687 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2686)
private theorem w2687_0 : checkWitness 2687 false false 641 = true := by decide +kernel
private theorem w2687_1 : checkWitness 2687 false true 4729 = true := by decide +kernel
private theorem w2687_2 : checkWitness 2687 true false 641 = true := by decide +kernel
private theorem w2687_3 : checkWitness 2687 true true 4729 = true := by decide +kernel
private theorem cases2687 : checkFour 2687 (641,4729,641,4729) = true := by
  simp only [checkFour, w2687_0,w2687_1,w2687_2,w2687_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2687 : Coverage 2687 2688 := checkList_sound (ws:=[(641,4729,641,4729)]) (by simpa only [checkList, Bool.and_true] using cases2687)
theorem cover2656 : Coverage 2656 2688 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2656 one2657) (Coverage.join one2658 one2659)) (Coverage.join (Coverage.join one2660 one2661) (Coverage.join one2662 one2663))) (Coverage.join (Coverage.join (Coverage.join one2664 one2665) (Coverage.join one2666 one2667)) (Coverage.join (Coverage.join one2668 one2669) (Coverage.join one2670 one2671)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2672 one2673) (Coverage.join one2674 one2675)) (Coverage.join (Coverage.join one2676 one2677) (Coverage.join one2678 one2679))) (Coverage.join (Coverage.join (Coverage.join one2680 one2681) (Coverage.join one2682 one2683)) (Coverage.join (Coverage.join one2684 one2685) (Coverage.join one2686 one2687)))))
end NF180PA.Symbolic
