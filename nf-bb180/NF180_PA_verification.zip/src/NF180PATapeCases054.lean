import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1728_0 : checkWitness 1728 false false 84 = true := by decide +kernel
private theorem w1728_2 : checkWitness 1728 true false 84 = true := by decide +kernel
private theorem cases1728 : checkFour 1728 (84,0,84,0) = true := by
  simp only [checkFour, w1728_0,w1728_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1728 : Coverage 1728 1729 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1728)
private theorem w1729_0 : checkWitness 1729 false false 530 = true := by decide +kernel
private theorem w1729_1 : checkWitness 1729 false true 4626 = true := by decide +kernel
private theorem w1729_2 : checkWitness 1729 true false 530 = true := by decide +kernel
private theorem w1729_3 : checkWitness 1729 true true 4626 = true := by decide +kernel
private theorem cases1729 : checkFour 1729 (530,4626,530,4626) = true := by
  simp only [checkFour, w1729_0,w1729_1,w1729_2,w1729_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1729 : Coverage 1729 1730 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases1729)
private theorem w1730_0 : checkWitness 1730 false false 8871 = true := by decide +kernel
private theorem w1730_2 : checkWitness 1730 true false 8867 = true := by decide +kernel
private theorem cases1730 : checkFour 1730 (8871,0,8867,0) = true := by
  simp only [checkFour, w1730_0,w1730_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1730 : Coverage 1730 1731 := checkList_sound (ws:=[(8871,0,8867,0)]) (by simpa only [checkList, Bool.and_true] using cases1730)
private theorem w1731_0 : checkWitness 1731 false false 8906 = true := by decide +kernel
private theorem w1731_2 : checkWitness 1731 true false 8897 = true := by decide +kernel
private theorem cases1731 : checkFour 1731 (8906,0,8897,0) = true := by
  simp only [checkFour, w1731_0,w1731_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1731 : Coverage 1731 1732 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1731)
private theorem w1732_0 : checkWitness 1732 false false 102 = true := by decide +kernel
private theorem w1732_2 : checkWitness 1732 true false 102 = true := by decide +kernel
private theorem cases1732 : checkFour 1732 (102,0,102,0) = true := by
  simp only [checkFour, w1732_0,w1732_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1732 : Coverage 1732 1733 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1732)
private theorem w1733_0 : checkWitness 1733 false false 618 = true := by decide +kernel
private theorem w1733_1 : checkWitness 1733 false true 4710 = true := by decide +kernel
private theorem w1733_2 : checkWitness 1733 true false 609 = true := by decide +kernel
private theorem w1733_3 : checkWitness 1733 true true 4701 = true := by decide +kernel
private theorem cases1733 : checkFour 1733 (618,4710,609,4701) = true := by
  simp only [checkFour, w1733_0,w1733_1,w1733_2,w1733_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1733 : Coverage 1733 1734 := checkList_sound (ws:=[(618,4710,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases1733)
private theorem w1734_0 : checkWitness 1734 false false 8867 = true := by decide +kernel
private theorem w1734_2 : checkWitness 1734 true false 8863 = true := by decide +kernel
private theorem cases1734 : checkFour 1734 (8867,0,8863,0) = true := by
  simp only [checkFour, w1734_0,w1734_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1734 : Coverage 1734 1735 := checkList_sound (ws:=[(8867,0,8863,0)]) (by simpa only [checkList, Bool.and_true] using cases1734)
private theorem w1735_0 : checkWitness 1735 false false 612 = true := by decide +kernel
private theorem w1735_1 : checkWitness 1735 false true 4704 = true := by decide +kernel
private theorem w1735_2 : checkWitness 1735 true false 603 = true := by decide +kernel
private theorem w1735_3 : checkWitness 1735 true true 4695 = true := by decide +kernel
private theorem cases1735 : checkFour 1735 (612,4704,603,4695) = true := by
  simp only [checkFour, w1735_0,w1735_1,w1735_2,w1735_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1735 : Coverage 1735 1736 := checkList_sound (ws:=[(612,4704,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases1735)
private theorem w1736_0 : checkWitness 1736 false false 8836 = true := by decide +kernel
private theorem w1736_2 : checkWitness 1736 true false 8832 = true := by decide +kernel
private theorem cases1736 : checkFour 1736 (8836,0,8832,0) = true := by
  simp only [checkFour, w1736_0,w1736_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1736 : Coverage 1736 1737 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1736)
private theorem w1737_0 : checkWitness 1737 false false 90 = true := by decide +kernel
private theorem w1737_2 : checkWitness 1737 true false 90 = true := by decide +kernel
private theorem cases1737 : checkFour 1737 (90,0,90,0) = true := by
  simp only [checkFour, w1737_0,w1737_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1737 : Coverage 1737 1738 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1737)
private theorem w1738_0 : checkWitness 1738 false false 82 = true := by decide +kernel
private theorem w1738_2 : checkWitness 1738 true false 82 = true := by decide +kernel
private theorem cases1738 : checkFour 1738 (82,0,82,0) = true := by
  simp only [checkFour, w1738_0,w1738_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1738 : Coverage 1738 1739 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1738)
private theorem w1739_0 : checkWitness 1739 false false 579 = true := by decide +kernel
private theorem w1739_1 : checkWitness 1739 false true 4667 = true := by decide +kernel
private theorem w1739_2 : checkWitness 1739 true false 579 = true := by decide +kernel
private theorem w1739_3 : checkWitness 1739 true true 4667 = true := by decide +kernel
private theorem cases1739 : checkFour 1739 (579,4667,579,4667) = true := by
  simp only [checkFour, w1739_0,w1739_1,w1739_2,w1739_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1739 : Coverage 1739 1740 := checkList_sound (ws:=[(579,4667,579,4667)]) (by simpa only [checkList, Bool.and_true] using cases1739)
private theorem w1740_0 : checkWitness 1740 false false 8852 = true := by decide +kernel
private theorem w1740_2 : checkWitness 1740 true false 8848 = true := by decide +kernel
private theorem cases1740 : checkFour 1740 (8852,0,8848,0) = true := by
  simp only [checkFour, w1740_0,w1740_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1740 : Coverage 1740 1741 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1740)
private theorem w1741_0 : checkWitness 1741 false false 8848 = true := by decide +kernel
private theorem w1741_2 : checkWitness 1741 true false 8844 = true := by decide +kernel
private theorem cases1741 : checkFour 1741 (8848,0,8844,0) = true := by
  simp only [checkFour, w1741_0,w1741_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1741 : Coverage 1741 1742 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases1741)
private theorem w1742_0 : checkWitness 1742 false false 96 = true := by decide +kernel
private theorem w1742_2 : checkWitness 1742 true false 96 = true := by decide +kernel
private theorem cases1742 : checkFour 1742 (96,0,96,0) = true := by
  simp only [checkFour, w1742_0,w1742_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1742 : Coverage 1742 1743 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1742)
private theorem w1743_0 : checkWitness 1743 false false 8880 = true := by decide +kernel
private theorem w1743_2 : checkWitness 1743 true false 8876 = true := by decide +kernel
private theorem cases1743 : checkFour 1743 (8880,0,8876,0) = true := by
  simp only [checkFour, w1743_0,w1743_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1743 : Coverage 1743 1744 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases1743)
private theorem w1744_0 : checkWitness 1744 false false 686 = true := by decide +kernel
private theorem w1744_1 : checkWitness 1744 false true 4782 = true := by decide +kernel
private theorem w1744_2 : checkWitness 1744 true false 686 = true := by decide +kernel
private theorem w1744_3 : checkWitness 1744 true true 4782 = true := by decide +kernel
private theorem cases1744 : checkFour 1744 (686,4782,686,4782) = true := by
  simp only [checkFour, w1744_0,w1744_1,w1744_2,w1744_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1744 : Coverage 1744 1745 := checkList_sound (ws:=[(686,4782,686,4782)]) (by simpa only [checkList, Bool.and_true] using cases1744)
private theorem w1745_0 : checkWitness 1745 false false 8942 = true := by decide +kernel
private theorem w1745_2 : checkWitness 1745 true false 8933 = true := by decide +kernel
private theorem cases1745 : checkFour 1745 (8942,0,8933,0) = true := by
  simp only [checkFour, w1745_0,w1745_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1745 : Coverage 1745 1746 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases1745)
private theorem w1746_0 : checkWitness 1746 false false 80 = true := by decide +kernel
private theorem w1746_2 : checkWitness 1746 true false 80 = true := by decide +kernel
private theorem cases1746 : checkFour 1746 (80,0,80,0) = true := by
  simp only [checkFour, w1746_0,w1746_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1746 : Coverage 1746 1747 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1746)
private theorem w1747_0 : checkWitness 1747 false false 524 = true := by decide +kernel
private theorem w1747_1 : checkWitness 1747 false true 4620 = true := by decide +kernel
private theorem w1747_2 : checkWitness 1747 true false 524 = true := by decide +kernel
private theorem w1747_3 : checkWitness 1747 true true 4620 = true := by decide +kernel
private theorem cases1747 : checkFour 1747 (524,4620,524,4620) = true := by
  simp only [checkFour, w1747_0,w1747_1,w1747_2,w1747_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1747 : Coverage 1747 1748 := checkList_sound (ws:=[(524,4620,524,4620)]) (by simpa only [checkList, Bool.and_true] using cases1747)
private theorem w1748_0 : checkWitness 1748 false false 8882 = true := by decide +kernel
private theorem w1748_2 : checkWitness 1748 true false 8878 = true := by decide +kernel
private theorem cases1748 : checkFour 1748 (8882,0,8878,0) = true := by
  simp only [checkFour, w1748_0,w1748_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1748 : Coverage 1748 1749 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases1748)
private theorem w1749_0 : checkWitness 1749 false false 82 = true := by decide +kernel
private theorem w1749_2 : checkWitness 1749 true false 82 = true := by decide +kernel
private theorem cases1749 : checkFour 1749 (82,0,82,0) = true := by
  simp only [checkFour, w1749_0,w1749_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1749 : Coverage 1749 1750 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1749)
private theorem w1750_0 : checkWitness 1750 false false 562 = true := by decide +kernel
private theorem w1750_1 : checkWitness 1750 false true 4658 = true := by decide +kernel
private theorem w1750_2 : checkWitness 1750 true false 562 = true := by decide +kernel
private theorem w1750_3 : checkWitness 1750 true true 4658 = true := by decide +kernel
private theorem cases1750 : checkFour 1750 (562,4658,562,4658) = true := by
  simp only [checkFour, w1750_0,w1750_1,w1750_2,w1750_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1750 : Coverage 1750 1751 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases1750)
private theorem w1751_0 : checkWitness 1751 false false 8903 = true := by decide +kernel
private theorem w1751_2 : checkWitness 1751 true false 8899 = true := by decide +kernel
private theorem cases1751 : checkFour 1751 (8903,0,8899,0) = true := by
  simp only [checkFour, w1751_0,w1751_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1751 : Coverage 1751 1752 := checkList_sound (ws:=[(8903,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases1751)
private theorem w1752_0 : checkWitness 1752 false false 8938 = true := by decide +kernel
private theorem w1752_2 : checkWitness 1752 true false 8929 = true := by decide +kernel
private theorem cases1752 : checkFour 1752 (8938,0,8929,0) = true := by
  simp only [checkFour, w1752_0,w1752_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1752 : Coverage 1752 1753 := checkList_sound (ws:=[(8938,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases1752)
private theorem w1753_0 : checkWitness 1753 false false 106 = true := by decide +kernel
private theorem w1753_2 : checkWitness 1753 true false 106 = true := by decide +kernel
private theorem cases1753 : checkFour 1753 (106,0,106,0) = true := by
  simp only [checkFour, w1753_0,w1753_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1753 : Coverage 1753 1754 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1753)
private theorem w1754_0 : checkWitness 1754 false false 650 = true := by decide +kernel
private theorem w1754_1 : checkWitness 1754 false true 4742 = true := by decide +kernel
private theorem w1754_2 : checkWitness 1754 true false 641 = true := by decide +kernel
private theorem w1754_3 : checkWitness 1754 true true 4733 = true := by decide +kernel
private theorem cases1754 : checkFour 1754 (650,4742,641,4733) = true := by
  simp only [checkFour, w1754_0,w1754_1,w1754_2,w1754_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1754 : Coverage 1754 1755 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases1754)
private theorem w1755_0 : checkWitness 1755 false false 8899 = true := by decide +kernel
private theorem w1755_2 : checkWitness 1755 true false 8895 = true := by decide +kernel
private theorem cases1755 : checkFour 1755 (8899,0,8895,0) = true := by
  simp only [checkFour, w1755_0,w1755_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1755 : Coverage 1755 1756 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases1755)
private theorem w1756_0 : checkWitness 1756 false false 644 = true := by decide +kernel
private theorem w1756_1 : checkWitness 1756 false true 4736 = true := by decide +kernel
private theorem w1756_2 : checkWitness 1756 true false 635 = true := by decide +kernel
private theorem w1756_3 : checkWitness 1756 true true 4727 = true := by decide +kernel
private theorem cases1756 : checkFour 1756 (644,4736,635,4727) = true := by
  simp only [checkFour, w1756_0,w1756_1,w1756_2,w1756_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1756 : Coverage 1756 1757 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases1756)
private theorem w1757_0 : checkWitness 1757 false false 8868 = true := by decide +kernel
private theorem w1757_2 : checkWitness 1757 true false 8864 = true := by decide +kernel
private theorem cases1757 : checkFour 1757 (8868,0,8864,0) = true := by
  simp only [checkFour, w1757_0,w1757_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1757 : Coverage 1757 1758 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases1757)
private theorem w1758_0 : checkWitness 1758 false false 94 = true := by decide +kernel
private theorem w1758_2 : checkWitness 1758 true false 94 = true := by decide +kernel
private theorem cases1758 : checkFour 1758 (94,0,94,0) = true := by
  simp only [checkFour, w1758_0,w1758_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1758 : Coverage 1758 1759 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1758)
private theorem w1759_0 : checkWitness 1759 false false 86 = true := by decide +kernel
private theorem w1759_2 : checkWitness 1759 true false 86 = true := by decide +kernel
private theorem cases1759 : checkFour 1759 (86,0,86,0) = true := by
  simp only [checkFour, w1759_0,w1759_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1759 : Coverage 1759 1760 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1759)
theorem cover1728 : Coverage 1728 1760 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1728 one1729) (Coverage.join one1730 one1731)) (Coverage.join (Coverage.join one1732 one1733) (Coverage.join one1734 one1735))) (Coverage.join (Coverage.join (Coverage.join one1736 one1737) (Coverage.join one1738 one1739)) (Coverage.join (Coverage.join one1740 one1741) (Coverage.join one1742 one1743)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1744 one1745) (Coverage.join one1746 one1747)) (Coverage.join (Coverage.join one1748 one1749) (Coverage.join one1750 one1751))) (Coverage.join (Coverage.join (Coverage.join one1752 one1753) (Coverage.join one1754 one1755)) (Coverage.join (Coverage.join one1756 one1757) (Coverage.join one1758 one1759)))))
end NF180PA.Symbolic
