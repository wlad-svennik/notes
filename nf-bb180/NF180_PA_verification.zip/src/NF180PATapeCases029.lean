import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w928_0 : checkWitness 928 false false 8883 = true := by decide +kernel
private theorem w928_2 : checkWitness 928 true false 8879 = true := by decide +kernel
private theorem cases928 : checkFour 928 (8883,0,8879,0) = true := by
  simp only [checkFour, w928_0,w928_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one928 : Coverage 928 929 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases928)
private theorem w929_0 : checkWitness 929 false false 628 = true := by decide +kernel
private theorem w929_1 : checkWitness 929 false true 4720 = true := by decide +kernel
private theorem w929_2 : checkWitness 929 true false 619 = true := by decide +kernel
private theorem w929_3 : checkWitness 929 true true 4711 = true := by decide +kernel
private theorem cases929 : checkFour 929 (628,4720,619,4711) = true := by
  simp only [checkFour, w929_0,w929_1,w929_2,w929_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one929 : Coverage 929 930 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases929)
private theorem w930_0 : checkWitness 930 false false 8852 = true := by decide +kernel
private theorem w930_2 : checkWitness 930 true false 8848 = true := by decide +kernel
private theorem cases930 : checkFour 930 (8852,0,8848,0) = true := by
  simp only [checkFour, w930_0,w930_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one930 : Coverage 930 931 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases930)
private theorem w931_0 : checkWitness 931 false false 82 = true := by decide +kernel
private theorem w931_2 : checkWitness 931 true false 82 = true := by decide +kernel
private theorem cases931 : checkFour 931 (82,0,82,0) = true := by
  simp only [checkFour, w931_0,w931_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one931 : Coverage 931 932 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases931)
private theorem w932_0 : checkWitness 932 false false 74 = true := by decide +kernel
private theorem w932_2 : checkWitness 932 true false 74 = true := by decide +kernel
private theorem cases932 : checkFour 932 (74,0,74,0) = true := by
  simp only [checkFour, w932_0,w932_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one932 : Coverage 932 933 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases932)
private theorem w933_0 : checkWitness 933 false false 595 = true := by decide +kernel
private theorem w933_1 : checkWitness 933 false true 4683 = true := by decide +kernel
private theorem w933_2 : checkWitness 933 true false 595 = true := by decide +kernel
private theorem w933_3 : checkWitness 933 true true 4683 = true := by decide +kernel
private theorem cases933 : checkFour 933 (595,4683,595,4683) = true := by
  simp only [checkFour, w933_0,w933_1,w933_2,w933_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one933 : Coverage 933 934 := checkList_sound (ws:=[(595,4683,595,4683)]) (by simpa only [checkList, Bool.and_true] using cases933)
private theorem w934_0 : checkWitness 934 false false 8868 = true := by decide +kernel
private theorem w934_2 : checkWitness 934 true false 8864 = true := by decide +kernel
private theorem cases934 : checkFour 934 (8868,0,8864,0) = true := by
  simp only [checkFour, w934_0,w934_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one934 : Coverage 934 935 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases934)
private theorem w935_0 : checkWitness 935 false false 8864 = true := by decide +kernel
private theorem w935_2 : checkWitness 935 true false 8860 = true := by decide +kernel
private theorem cases935 : checkFour 935 (8864,0,8860,0) = true := by
  simp only [checkFour, w935_0,w935_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one935 : Coverage 935 936 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases935)
private theorem w936_0 : checkWitness 936 false false 88 = true := by decide +kernel
private theorem w936_2 : checkWitness 936 true false 88 = true := by decide +kernel
private theorem cases936 : checkFour 936 (88,0,88,0) = true := by
  simp only [checkFour, w936_0,w936_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one936 : Coverage 936 937 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases936)
private theorem w937_0 : checkWitness 937 false false 8884 = true := by decide +kernel
private theorem w937_2 : checkWitness 937 true false 8880 = true := by decide +kernel
private theorem cases937 : checkFour 937 (8884,0,8880,0) = true := by
  simp only [checkFour, w937_0,w937_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one937 : Coverage 937 938 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases937)
private theorem w938_0 : checkWitness 938 false false 672 = true := by decide +kernel
private theorem w938_1 : checkWitness 938 false true 4768 = true := by decide +kernel
private theorem w938_2 : checkWitness 938 true false 672 = true := by decide +kernel
private theorem w938_3 : checkWitness 938 true true 4768 = true := by decide +kernel
private theorem cases938 : checkFour 938 (672,4768,672,4768) = true := by
  simp only [checkFour, w938_0,w938_1,w938_2,w938_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one938 : Coverage 938 939 := checkList_sound (ws:=[(672,4768,672,4768)]) (by simpa only [checkList, Bool.and_true] using cases938)
private theorem w939_0 : checkWitness 939 false false 8934 = true := by decide +kernel
private theorem w939_2 : checkWitness 939 true false 8925 = true := by decide +kernel
private theorem cases939 : checkFour 939 (8934,0,8925,0) = true := by
  simp only [checkFour, w939_0,w939_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one939 : Coverage 939 940 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases939)
private theorem w940_0 : checkWitness 940 false false 74 = true := by decide +kernel
private theorem w940_2 : checkWitness 940 true false 74 = true := by decide +kernel
private theorem cases940 : checkFour 940 (74,0,74,0) = true := by
  simp only [checkFour, w940_0,w940_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one940 : Coverage 940 941 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases940)
private theorem w941_0 : checkWitness 941 false false 516 = true := by decide +kernel
private theorem w941_1 : checkWitness 941 false true 4612 = true := by decide +kernel
private theorem w941_2 : checkWitness 941 true false 516 = true := by decide +kernel
private theorem w941_3 : checkWitness 941 true true 4612 = true := by decide +kernel
private theorem cases941 : checkFour 941 (516,4612,516,4612) = true := by
  simp only [checkFour, w941_0,w941_1,w941_2,w941_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one941 : Coverage 941 942 := checkList_sound (ws:=[(516,4612,516,4612)]) (by simpa only [checkList, Bool.and_true] using cases941)
private theorem w942_0 : checkWitness 942 false false 8874 = true := by decide +kernel
private theorem w942_2 : checkWitness 942 true false 8870 = true := by decide +kernel
private theorem cases942 : checkFour 942 (8874,0,8870,0) = true := by
  simp only [checkFour, w942_0,w942_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one942 : Coverage 942 943 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases942)
private theorem w943_0 : checkWitness 943 false false 76 = true := by decide +kernel
private theorem w943_2 : checkWitness 943 true false 76 = true := by decide +kernel
private theorem cases943 : checkFour 943 (76,0,76,0) = true := by
  simp only [checkFour, w943_0,w943_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one943 : Coverage 943 944 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases943)
private theorem w944_0 : checkWitness 944 false false 554 = true := by decide +kernel
private theorem w944_1 : checkWitness 944 false true 4650 = true := by decide +kernel
private theorem w944_2 : checkWitness 944 true false 554 = true := by decide +kernel
private theorem w944_3 : checkWitness 944 true true 4650 = true := by decide +kernel
private theorem cases944 : checkFour 944 (554,4650,554,4650) = true := by
  simp only [checkFour, w944_0,w944_1,w944_2,w944_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one944 : Coverage 944 945 := checkList_sound (ws:=[(554,4650,554,4650)]) (by simpa only [checkList, Bool.and_true] using cases944)
private theorem w945_0 : checkWitness 945 false false 8895 = true := by decide +kernel
private theorem w945_2 : checkWitness 945 true false 8891 = true := by decide +kernel
private theorem cases945 : checkFour 945 (8895,0,8891,0) = true := by
  simp only [checkFour, w945_0,w945_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one945 : Coverage 945 946 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases945)
private theorem w946_0 : checkWitness 946 false false 8930 = true := by decide +kernel
private theorem w946_2 : checkWitness 946 true false 8921 = true := by decide +kernel
private theorem cases946 : checkFour 946 (8930,0,8921,0) = true := by
  simp only [checkFour, w946_0,w946_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one946 : Coverage 946 947 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases946)
private theorem w947_0 : checkWitness 947 false false 100 = true := by decide +kernel
private theorem w947_2 : checkWitness 947 true false 100 = true := by decide +kernel
private theorem cases947 : checkFour 947 (100,0,100,0) = true := by
  simp only [checkFour, w947_0,w947_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one947 : Coverage 947 948 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases947)
private theorem w948_0 : checkWitness 948 false false 642 = true := by decide +kernel
private theorem w948_1 : checkWitness 948 false true 4734 = true := by decide +kernel
private theorem w948_2 : checkWitness 948 true false 633 = true := by decide +kernel
private theorem w948_3 : checkWitness 948 true true 4725 = true := by decide +kernel
private theorem cases948 : checkFour 948 (642,4734,633,4725) = true := by
  simp only [checkFour, w948_0,w948_1,w948_2,w948_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one948 : Coverage 948 949 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases948)
private theorem w949_0 : checkWitness 949 false false 8891 = true := by decide +kernel
private theorem w949_2 : checkWitness 949 true false 8887 = true := by decide +kernel
private theorem cases949 : checkFour 949 (8891,0,8887,0) = true := by
  simp only [checkFour, w949_0,w949_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one949 : Coverage 949 950 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases949)
private theorem w950_0 : checkWitness 950 false false 636 = true := by decide +kernel
private theorem w950_1 : checkWitness 950 false true 4728 = true := by decide +kernel
private theorem w950_2 : checkWitness 950 true false 627 = true := by decide +kernel
private theorem w950_3 : checkWitness 950 true true 4719 = true := by decide +kernel
private theorem cases950 : checkFour 950 (636,4728,627,4719) = true := by
  simp only [checkFour, w950_0,w950_1,w950_2,w950_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one950 : Coverage 950 951 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases950)
private theorem w951_0 : checkWitness 951 false false 8860 = true := by decide +kernel
private theorem w951_2 : checkWitness 951 true false 8856 = true := by decide +kernel
private theorem cases951 : checkFour 951 (8860,0,8856,0) = true := by
  simp only [checkFour, w951_0,w951_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one951 : Coverage 951 952 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases951)
private theorem w952_0 : checkWitness 952 false false 88 = true := by decide +kernel
private theorem w952_2 : checkWitness 952 true false 88 = true := by decide +kernel
private theorem cases952 : checkFour 952 (88,0,88,0) = true := by
  simp only [checkFour, w952_0,w952_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one952 : Coverage 952 953 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases952)
private theorem w953_0 : checkWitness 953 false false 80 = true := by decide +kernel
private theorem w953_2 : checkWitness 953 true false 80 = true := by decide +kernel
private theorem cases953 : checkFour 953 (80,0,80,0) = true := by
  simp only [checkFour, w953_0,w953_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one953 : Coverage 953 954 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases953)
private theorem w954_0 : checkWitness 954 false false 601 = true := by decide +kernel
private theorem w954_1 : checkWitness 954 false true 4685 = true := by decide +kernel
private theorem w954_2 : checkWitness 954 true false 601 = true := by decide +kernel
private theorem w954_3 : checkWitness 954 true true 4685 = true := by decide +kernel
private theorem cases954 : checkFour 954 (601,4685,601,4685) = true := by
  simp only [checkFour, w954_0,w954_1,w954_2,w954_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one954 : Coverage 954 955 := checkList_sound (ws:=[(601,4685,601,4685)]) (by simpa only [checkList, Bool.and_true] using cases954)
private theorem w955_0 : checkWitness 955 false false 8854 = true := by decide +kernel
private theorem w955_2 : checkWitness 955 true false 8850 = true := by decide +kernel
private theorem cases955 : checkFour 955 (8854,0,8850,0) = true := by
  simp only [checkFour, w955_0,w955_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one955 : Coverage 955 956 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases955)
private theorem w956_0 : checkWitness 956 false false 80 = true := by decide +kernel
private theorem w956_2 : checkWitness 956 true false 80 = true := by decide +kernel
private theorem cases956 : checkFour 956 (80,0,80,0) = true := by
  simp only [checkFour, w956_0,w956_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one956 : Coverage 956 957 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases956)
private theorem w957_0 : checkWitness 957 false false 569 = true := by decide +kernel
private theorem w957_1 : checkWitness 957 false true 4665 = true := by decide +kernel
private theorem w957_2 : checkWitness 957 true false 569 = true := by decide +kernel
private theorem w957_3 : checkWitness 957 true true 4665 = true := by decide +kernel
private theorem cases957 : checkFour 957 (569,4665,569,4665) = true := by
  simp only [checkFour, w957_0,w957_1,w957_2,w957_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one957 : Coverage 957 958 := checkList_sound (ws:=[(569,4665,569,4665)]) (by simpa only [checkList, Bool.and_true] using cases957)
private theorem w958_0 : checkWitness 958 false false 8922 = true := by decide +kernel
private theorem w958_2 : checkWitness 958 true false 8913 = true := by decide +kernel
private theorem cases958 : checkFour 958 (8922,0,8913,0) = true := by
  simp only [checkFour, w958_0,w958_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one958 : Coverage 958 959 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases958)
private theorem w959_0 : checkWitness 959 false false 8868 = true := by decide +kernel
private theorem w959_2 : checkWitness 959 true false 8864 = true := by decide +kernel
private theorem cases959 : checkFour 959 (8868,0,8864,0) = true := by
  simp only [checkFour, w959_0,w959_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one959 : Coverage 959 960 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases959)
theorem cover0928 : Coverage 928 960 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one928 one929) (Coverage.join one930 one931)) (Coverage.join (Coverage.join one932 one933) (Coverage.join one934 one935))) (Coverage.join (Coverage.join (Coverage.join one936 one937) (Coverage.join one938 one939)) (Coverage.join (Coverage.join one940 one941) (Coverage.join one942 one943)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one944 one945) (Coverage.join one946 one947)) (Coverage.join (Coverage.join one948 one949) (Coverage.join one950 one951))) (Coverage.join (Coverage.join (Coverage.join one952 one953) (Coverage.join one954 one955)) (Coverage.join (Coverage.join one956 one957) (Coverage.join one958 one959)))))
end NF180PA.Symbolic
