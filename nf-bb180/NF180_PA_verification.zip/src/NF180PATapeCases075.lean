import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2400_0 : checkWitness 2400 false false 8944 = true := by decide +kernel
private theorem w2400_2 : checkWitness 2400 true false 8935 = true := by decide +kernel
private theorem cases2400 : checkFour 2400 (8944,0,8935,0) = true := by
  simp only [checkFour, w2400_0,w2400_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2400 : Coverage 2400 2401 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2400)
private theorem w2401_0 : checkWitness 2401 false false 8890 = true := by decide +kernel
private theorem w2401_2 : checkWitness 2401 true false 8886 = true := by decide +kernel
private theorem cases2401 : checkFour 2401 (8890,0,8886,0) = true := by
  simp only [checkFour, w2401_0,w2401_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2401 : Coverage 2401 2402 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases2401)
private theorem w2402_0 : checkWitness 2402 false false 70 = true := by decide +kernel
private theorem w2402_2 : checkWitness 2402 true false 70 = true := by decide +kernel
private theorem cases2402 : checkFour 2402 (70,0,70,0) = true := by
  simp only [checkFour, w2402_0,w2402_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2402 : Coverage 2402 2403 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2402)
private theorem w2403_0 : checkWitness 2403 false false 674 = true := by decide +kernel
private theorem w2403_1 : checkWitness 2403 false true 4766 = true := by decide +kernel
private theorem w2403_2 : checkWitness 2403 true false 665 = true := by decide +kernel
private theorem w2403_3 : checkWitness 2403 true true 4757 = true := by decide +kernel
private theorem cases2403 : checkFour 2403 (674,4766,665,4757) = true := by
  simp only [checkFour, w2403_0,w2403_1,w2403_2,w2403_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2403 : Coverage 2403 2404 := checkList_sound (ws:=[(674,4766,665,4757)]) (by simpa only [checkList, Bool.and_true] using cases2403)
private theorem w2404_0 : checkWitness 2404 false false 8951 = true := by decide +kernel
private theorem w2404_2 : checkWitness 2404 true false 8942 = true := by decide +kernel
private theorem cases2404 : checkFour 2404 (8951,0,8942,0) = true := by
  simp only [checkFour, w2404_0,w2404_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2404 : Coverage 2404 2405 := checkList_sound (ws:=[(8951,0,8942,0)]) (by simpa only [checkList, Bool.and_true] using cases2404)
private theorem w2405_0 : checkWitness 2405 false false 54 = true := by decide +kernel
private theorem w2405_2 : checkWitness 2405 true false 54 = true := by decide +kernel
private theorem cases2405 : checkFour 2405 (54,0,54,0) = true := by
  simp only [checkFour, w2405_0,w2405_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2405 : Coverage 2405 2406 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases2405)
private theorem w2406_0 : checkWitness 2406 false false 538 = true := by decide +kernel
private theorem w2406_1 : checkWitness 2406 false true 4634 = true := by decide +kernel
private theorem w2406_2 : checkWitness 2406 true false 538 = true := by decide +kernel
private theorem w2406_3 : checkWitness 2406 true true 4634 = true := by decide +kernel
private theorem cases2406 : checkFour 2406 (538,4634,538,4634) = true := by
  simp only [checkFour, w2406_0,w2406_1,w2406_2,w2406_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2406 : Coverage 2406 2407 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases2406)
private theorem w2407_0 : checkWitness 2407 false false 8933 = true := by decide +kernel
private theorem w2407_2 : checkWitness 2407 true false 8929 = true := by decide +kernel
private theorem cases2407 : checkFour 2407 (8933,0,8929,0) = true := by
  simp only [checkFour, w2407_0,w2407_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2407 : Coverage 2407 2408 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases2407)
private theorem w2408_0 : checkWitness 2408 false false 664 = true := by decide +kernel
private theorem w2408_1 : checkWitness 2408 false true 4760 = true := by decide +kernel
private theorem w2408_2 : checkWitness 2408 true false 655 = true := by decide +kernel
private theorem w2408_3 : checkWitness 2408 true true 4751 = true := by decide +kernel
private theorem cases2408 : checkFour 2408 (664,4760,655,4751) = true := by
  simp only [checkFour, w2408_0,w2408_1,w2408_2,w2408_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2408 : Coverage 2408 2409 := checkList_sound (ws:=[(664,4760,655,4751)]) (by simpa only [checkList, Bool.and_true] using cases2408)
private theorem w2409_0 : checkWitness 2409 false false 196 = true := by decide +kernel
private theorem w2409_2 : checkWitness 2409 true false 196 = true := by decide +kernel
private theorem cases2409 : checkFour 2409 (196,0,196,0) = true := by
  simp only [checkFour, w2409_0,w2409_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2409 : Coverage 2409 2410 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases2409)
private theorem w2410_0 : checkWitness 2410 false false 619 = true := by decide +kernel
private theorem w2410_1 : checkWitness 2410 false true 4707 = true := by decide +kernel
private theorem w2410_2 : checkWitness 2410 true false 619 = true := by decide +kernel
private theorem w2410_3 : checkWitness 2410 true true 4707 = true := by decide +kernel
private theorem cases2410 : checkFour 2410 (619,4707,619,4707) = true := by
  simp only [checkFour, w2410_0,w2410_1,w2410_2,w2410_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2410 : Coverage 2410 2411 := checkList_sound (ws:=[(619,4707,619,4707)]) (by simpa only [checkList, Bool.and_true] using cases2410)
private theorem w2411_0 : checkWitness 2411 false false 8948 = true := by decide +kernel
private theorem w2411_2 : checkWitness 2411 true false 8939 = true := by decide +kernel
private theorem cases2411 : checkFour 2411 (8948,0,8939,0) = true := by
  simp only [checkFour, w2411_0,w2411_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2411 : Coverage 2411 2412 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2411)
private theorem w2412_0 : checkWitness 2412 false false 72 = true := by decide +kernel
private theorem w2412_2 : checkWitness 2412 true false 72 = true := by decide +kernel
private theorem cases2412 : checkFour 2412 (72,0,72,0) = true := by
  simp only [checkFour, w2412_0,w2412_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2412 : Coverage 2412 2413 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2412)
private theorem w2413_0 : checkWitness 2413 false false 64 = true := by decide +kernel
private theorem w2413_2 : checkWitness 2413 true false 64 = true := by decide +kernel
private theorem cases2413 : checkFour 2413 (64,0,64,0) = true := by
  simp only [checkFour, w2413_0,w2413_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2413 : Coverage 2413 2414 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2413)
private theorem w2414_0 : checkWitness 2414 false false 625 = true := by decide +kernel
private theorem w2414_1 : checkWitness 2414 false true 4717 = true := by decide +kernel
private theorem w2414_2 : checkWitness 2414 true false 625 = true := by decide +kernel
private theorem w2414_3 : checkWitness 2414 true true 4717 = true := by decide +kernel
private theorem cases2414 : checkFour 2414 (625,4717,625,4717) = true := by
  simp only [checkFour, w2414_0,w2414_1,w2414_2,w2414_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2414 : Coverage 2414 2415 := checkList_sound (ws:=[(625,4717,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases2414)
private theorem w2415_0 : checkWitness 2415 false false 8886 = true := by decide +kernel
private theorem w2415_2 : checkWitness 2415 true false 8882 = true := by decide +kernel
private theorem cases2415 : checkFour 2415 (8886,0,8882,0) = true := by
  simp only [checkFour, w2415_0,w2415_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2415 : Coverage 2415 2416 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases2415)
private theorem w2416_0 : checkWitness 2416 false false 64 = true := by decide +kernel
private theorem w2416_2 : checkWitness 2416 true false 64 = true := by decide +kernel
private theorem cases2416 : checkFour 2416 (64,0,64,0) = true := by
  simp only [checkFour, w2416_0,w2416_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2416 : Coverage 2416 2417 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2416)
private theorem w2417_0 : checkWitness 2417 false false 580 = true := by decide +kernel
private theorem w2417_1 : checkWitness 2417 false true 4676 = true := by decide +kernel
private theorem w2417_2 : checkWitness 2417 true false 580 = true := by decide +kernel
private theorem w2417_3 : checkWitness 2417 true true 4676 = true := by decide +kernel
private theorem cases2417 : checkFour 2417 (580,4676,580,4676) = true := by
  simp only [checkFour, w2417_0,w2417_1,w2417_2,w2417_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2417 : Coverage 2417 2418 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases2417)
private theorem w2418_0 : checkWitness 2418 false false 8921 = true := by decide +kernel
private theorem w2418_2 : checkWitness 2418 true false 8917 = true := by decide +kernel
private theorem cases2418 : checkFour 2418 (8921,0,8917,0) = true := by
  simp only [checkFour, w2418_0,w2418_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2418 : Coverage 2418 2419 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases2418)
private theorem w2419_0 : checkWitness 2419 false false 8956 = true := by decide +kernel
private theorem w2419_2 : checkWitness 2419 true false 8947 = true := by decide +kernel
private theorem cases2419 : checkFour 2419 (8956,0,8947,0) = true := by
  simp only [checkFour, w2419_0,w2419_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2419 : Coverage 2419 2420 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2419)
private theorem w2420_0 : checkWitness 2420 false false 82 = true := by decide +kernel
private theorem w2420_2 : checkWitness 2420 true false 82 = true := by decide +kernel
private theorem cases2420 : checkFour 2420 (82,0,82,0) = true := by
  simp only [checkFour, w2420_0,w2420_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2420 : Coverage 2420 2421 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2420)
private theorem w2421_0 : checkWitness 2421 false false 668 = true := by decide +kernel
private theorem w2421_1 : checkWitness 2421 false true 4760 = true := by decide +kernel
private theorem w2421_2 : checkWitness 2421 true false 659 = true := by decide +kernel
private theorem w2421_3 : checkWitness 2421 true true 4751 = true := by decide +kernel
private theorem cases2421 : checkFour 2421 (668,4760,659,4751) = true := by
  simp only [checkFour, w2421_0,w2421_1,w2421_2,w2421_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2421 : Coverage 2421 2422 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases2421)
private theorem w2422_0 : checkWitness 2422 false false 8917 = true := by decide +kernel
private theorem w2422_2 : checkWitness 2422 true false 8913 = true := by decide +kernel
private theorem cases2422 : checkFour 2422 (8917,0,8913,0) = true := by
  simp only [checkFour, w2422_0,w2422_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2422 : Coverage 2422 2423 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2422)
private theorem w2423_0 : checkWitness 2423 false false 662 = true := by decide +kernel
private theorem w2423_1 : checkWitness 2423 false true 4754 = true := by decide +kernel
private theorem w2423_2 : checkWitness 2423 true false 653 = true := by decide +kernel
private theorem w2423_3 : checkWitness 2423 true true 4745 = true := by decide +kernel
private theorem cases2423 : checkFour 2423 (662,4754,653,4745) = true := by
  simp only [checkFour, w2423_0,w2423_1,w2423_2,w2423_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2423 : Coverage 2423 2424 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases2423)
private theorem w2424_0 : checkWitness 2424 false false 8886 = true := by decide +kernel
private theorem w2424_2 : checkWitness 2424 true false 8882 = true := by decide +kernel
private theorem cases2424 : checkFour 2424 (8886,0,8882,0) = true := by
  simp only [checkFour, w2424_0,w2424_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2424 : Coverage 2424 2425 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases2424)
private theorem w2425_0 : checkWitness 2425 false false 70 = true := by decide +kernel
private theorem w2425_2 : checkWitness 2425 true false 70 = true := by decide +kernel
private theorem cases2425 : checkFour 2425 (70,0,70,0) = true := by
  simp only [checkFour, w2425_0,w2425_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2425 : Coverage 2425 2426 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2425)
private theorem w2426_0 : checkWitness 2426 false false 62 = true := by decide +kernel
private theorem w2426_2 : checkWitness 2426 true false 62 = true := by decide +kernel
private theorem cases2426 : checkFour 2426 (62,0,62,0) = true := by
  simp only [checkFour, w2426_0,w2426_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2426 : Coverage 2426 2427 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2426)
private theorem w2427_0 : checkWitness 2427 false false 629 = true := by decide +kernel
private theorem w2427_1 : checkWitness 2427 false true 4717 = true := by decide +kernel
private theorem w2427_2 : checkWitness 2427 true false 629 = true := by decide +kernel
private theorem w2427_3 : checkWitness 2427 true true 4717 = true := by decide +kernel
private theorem cases2427 : checkFour 2427 (629,4717,629,4717) = true := by
  simp only [checkFour, w2427_0,w2427_1,w2427_2,w2427_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2427 : Coverage 2427 2428 := checkList_sound (ws:=[(629,4717,629,4717)]) (by simpa only [checkList, Bool.and_true] using cases2427)
private theorem w2428_0 : checkWitness 2428 false false 8902 = true := by decide +kernel
private theorem w2428_2 : checkWitness 2428 true false 8898 = true := by decide +kernel
private theorem cases2428 : checkFour 2428 (8902,0,8898,0) = true := by
  simp only [checkFour, w2428_0,w2428_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2428 : Coverage 2428 2429 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases2428)
private theorem w2429_0 : checkWitness 2429 false false 8898 = true := by decide +kernel
private theorem w2429_2 : checkWitness 2429 true false 8894 = true := by decide +kernel
private theorem cases2429 : checkFour 2429 (8898,0,8894,0) = true := by
  simp only [checkFour, w2429_0,w2429_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2429 : Coverage 2429 2430 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2429)
private theorem w2430_0 : checkWitness 2430 false false 76 = true := by decide +kernel
private theorem w2430_2 : checkWitness 2430 true false 76 = true := by decide +kernel
private theorem cases2430 : checkFour 2430 (76,0,76,0) = true := by
  simp only [checkFour, w2430_0,w2430_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2430 : Coverage 2430 2431 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2430)
private theorem w2431_0 : checkWitness 2431 false false 8918 = true := by decide +kernel
private theorem w2431_2 : checkWitness 2431 true false 8914 = true := by decide +kernel
private theorem cases2431 : checkFour 2431 (8918,0,8914,0) = true := by
  simp only [checkFour, w2431_0,w2431_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2431 : Coverage 2431 2432 := checkList_sound (ws:=[(8918,0,8914,0)]) (by simpa only [checkList, Bool.and_true] using cases2431)
theorem cover2400 : Coverage 2400 2432 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2400 one2401) (Coverage.join one2402 one2403)) (Coverage.join (Coverage.join one2404 one2405) (Coverage.join one2406 one2407))) (Coverage.join (Coverage.join (Coverage.join one2408 one2409) (Coverage.join one2410 one2411)) (Coverage.join (Coverage.join one2412 one2413) (Coverage.join one2414 one2415)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2416 one2417) (Coverage.join one2418 one2419)) (Coverage.join (Coverage.join one2420 one2421) (Coverage.join one2422 one2423))) (Coverage.join (Coverage.join (Coverage.join one2424 one2425) (Coverage.join one2426 one2427)) (Coverage.join (Coverage.join one2428 one2429) (Coverage.join one2430 one2431)))))
end NF180PA.Symbolic
