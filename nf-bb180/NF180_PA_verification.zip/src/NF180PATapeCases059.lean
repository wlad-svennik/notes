import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1888_0 : checkWitness 1888 false false 86 = true := by decide +kernel
private theorem w1888_2 : checkWitness 1888 true false 86 = true := by decide +kernel
private theorem cases1888 : checkFour 1888 (86,0,86,0) = true := by
  simp only [checkFour, w1888_0,w1888_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1888 : Coverage 1888 1889 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1888)
private theorem w1889_0 : checkWitness 1889 false false 639 = true := by decide +kernel
private theorem w1889_1 : checkWitness 1889 false true 4723 = true := by decide +kernel
private theorem w1889_2 : checkWitness 1889 true false 639 = true := by decide +kernel
private theorem w1889_3 : checkWitness 1889 true true 4723 = true := by decide +kernel
private theorem cases1889 : checkFour 1889 (639,4723,639,4723) = true := by
  simp only [checkFour, w1889_0,w1889_1,w1889_2,w1889_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1889 : Coverage 1889 1890 := checkList_sound (ws:=[(639,4723,639,4723)]) (by simpa only [checkList, Bool.and_true] using cases1889)
private theorem w1890_0 : checkWitness 1890 false false 8892 = true := by decide +kernel
private theorem w1890_2 : checkWitness 1890 true false 8888 = true := by decide +kernel
private theorem cases1890 : checkFour 1890 (8892,0,8888,0) = true := by
  simp only [checkFour, w1890_0,w1890_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1890 : Coverage 1890 1891 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases1890)
private theorem w1891_0 : checkWitness 1891 false false 86 = true := by decide +kernel
private theorem w1891_2 : checkWitness 1891 true false 86 = true := by decide +kernel
private theorem cases1891 : checkFour 1891 (86,0,86,0) = true := by
  simp only [checkFour, w1891_0,w1891_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1891 : Coverage 1891 1892 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1891)
private theorem w1892_0 : checkWitness 1892 false false 710 = true := by decide +kernel
private theorem w1892_1 : checkWitness 1892 false true 4806 = true := by decide +kernel
private theorem w1892_2 : checkWitness 1892 true false 710 = true := by decide +kernel
private theorem w1892_3 : checkWitness 1892 true true 4806 = true := by decide +kernel
private theorem cases1892 : checkFour 1892 (710,4806,710,4806) = true := by
  simp only [checkFour, w1892_0,w1892_1,w1892_2,w1892_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1892 : Coverage 1892 1893 := checkList_sound (ws:=[(710,4806,710,4806)]) (by simpa only [checkList, Bool.and_true] using cases1892)
private theorem w1893_0 : checkWitness 1893 false false 8960 = true := by decide +kernel
private theorem w1893_2 : checkWitness 1893 true false 8951 = true := by decide +kernel
private theorem cases1893 : checkFour 1893 (8960,0,8951,0) = true := by
  simp only [checkFour, w1893_0,w1893_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1893 : Coverage 1893 1894 := checkList_sound (ws:=[(8960,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases1893)
private theorem w1894_0 : checkWitness 1894 false false 86 = true := by decide +kernel
private theorem w1894_2 : checkWitness 1894 true false 86 = true := by decide +kernel
private theorem cases1894 : checkFour 1894 (86,0,86,0) = true := by
  simp only [checkFour, w1894_0,w1894_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1894 : Coverage 1894 1895 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1894)
private theorem w1895_0 : checkWitness 1895 false false 542 = true := by decide +kernel
private theorem w1895_1 : checkWitness 1895 false true 4638 = true := by decide +kernel
private theorem w1895_2 : checkWitness 1895 true false 542 = true := by decide +kernel
private theorem w1895_3 : checkWitness 1895 true true 4638 = true := by decide +kernel
private theorem cases1895 : checkFour 1895 (542,4638,542,4638) = true := by
  simp only [checkFour, w1895_0,w1895_1,w1895_2,w1895_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1895 : Coverage 1895 1896 := checkList_sound (ws:=[(542,4638,542,4638)]) (by simpa only [checkList, Bool.and_true] using cases1895)
private theorem w1896_0 : checkWitness 1896 false false 8900 = true := by decide +kernel
private theorem w1896_2 : checkWitness 1896 true false 8896 = true := by decide +kernel
private theorem cases1896 : checkFour 1896 (8900,0,8896,0) = true := by
  simp only [checkFour, w1896_0,w1896_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1896 : Coverage 1896 1897 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases1896)
private theorem w1897_0 : checkWitness 1897 false false 88 = true := by decide +kernel
private theorem w1897_2 : checkWitness 1897 true false 88 = true := by decide +kernel
private theorem cases1897 : checkFour 1897 (88,0,88,0) = true := by
  simp only [checkFour, w1897_0,w1897_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1897 : Coverage 1897 1898 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1897)
private theorem w1898_0 : checkWitness 1898 false false 580 = true := by decide +kernel
private theorem w1898_1 : checkWitness 1898 false true 4676 = true := by decide +kernel
private theorem w1898_2 : checkWitness 1898 true false 580 = true := by decide +kernel
private theorem w1898_3 : checkWitness 1898 true true 4676 = true := by decide +kernel
private theorem cases1898 : checkFour 1898 (580,4676,580,4676) = true := by
  simp only [checkFour, w1898_0,w1898_1,w1898_2,w1898_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1898 : Coverage 1898 1899 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases1898)
private theorem w1899_0 : checkWitness 1899 false false 8921 = true := by decide +kernel
private theorem w1899_2 : checkWitness 1899 true false 8917 = true := by decide +kernel
private theorem cases1899 : checkFour 1899 (8921,0,8917,0) = true := by
  simp only [checkFour, w1899_0,w1899_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1899 : Coverage 1899 1900 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases1899)
private theorem w1900_0 : checkWitness 1900 false false 8956 = true := by decide +kernel
private theorem w1900_2 : checkWitness 1900 true false 8947 = true := by decide +kernel
private theorem cases1900 : checkFour 1900 (8956,0,8947,0) = true := by
  simp only [checkFour, w1900_0,w1900_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1900 : Coverage 1900 1901 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases1900)
private theorem w1901_0 : checkWitness 1901 false false 112 = true := by decide +kernel
private theorem w1901_2 : checkWitness 1901 true false 112 = true := by decide +kernel
private theorem cases1901 : checkFour 1901 (112,0,112,0) = true := by
  simp only [checkFour, w1901_0,w1901_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1901 : Coverage 1901 1902 := checkList_sound (ws:=[(112,0,112,0)]) (by simpa only [checkList, Bool.and_true] using cases1901)
private theorem w1902_0 : checkWitness 1902 false false 668 = true := by decide +kernel
private theorem w1902_1 : checkWitness 1902 false true 4760 = true := by decide +kernel
private theorem w1902_2 : checkWitness 1902 true false 659 = true := by decide +kernel
private theorem w1902_3 : checkWitness 1902 true true 4751 = true := by decide +kernel
private theorem cases1902 : checkFour 1902 (668,4760,659,4751) = true := by
  simp only [checkFour, w1902_0,w1902_1,w1902_2,w1902_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1902 : Coverage 1902 1903 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases1902)
private theorem w1903_0 : checkWitness 1903 false false 8917 = true := by decide +kernel
private theorem w1903_2 : checkWitness 1903 true false 8913 = true := by decide +kernel
private theorem cases1903 : checkFour 1903 (8917,0,8913,0) = true := by
  simp only [checkFour, w1903_0,w1903_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1903 : Coverage 1903 1904 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases1903)
private theorem w1904_0 : checkWitness 1904 false false 662 = true := by decide +kernel
private theorem w1904_1 : checkWitness 1904 false true 4754 = true := by decide +kernel
private theorem w1904_2 : checkWitness 1904 true false 653 = true := by decide +kernel
private theorem w1904_3 : checkWitness 1904 true true 4745 = true := by decide +kernel
private theorem cases1904 : checkFour 1904 (662,4754,653,4745) = true := by
  simp only [checkFour, w1904_0,w1904_1,w1904_2,w1904_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1904 : Coverage 1904 1905 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases1904)
private theorem w1905_0 : checkWitness 1905 false false 8886 = true := by decide +kernel
private theorem w1905_2 : checkWitness 1905 true false 8882 = true := by decide +kernel
private theorem cases1905 : checkFour 1905 (8886,0,8882,0) = true := by
  simp only [checkFour, w1905_0,w1905_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1905 : Coverage 1905 1906 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases1905)
private theorem w1906_0 : checkWitness 1906 false false 100 = true := by decide +kernel
private theorem w1906_2 : checkWitness 1906 true false 100 = true := by decide +kernel
private theorem cases1906 : checkFour 1906 (100,0,100,0) = true := by
  simp only [checkFour, w1906_0,w1906_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1906 : Coverage 1906 1907 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1906)
private theorem w1907_0 : checkWitness 1907 false false 92 = true := by decide +kernel
private theorem w1907_2 : checkWitness 1907 true false 92 = true := by decide +kernel
private theorem cases1907 : checkFour 1907 (92,0,92,0) = true := by
  simp only [checkFour, w1907_0,w1907_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1907 : Coverage 1907 1908 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1907)
private theorem w1908_0 : checkWitness 1908 false false 627 = true := by decide +kernel
private theorem w1908_1 : checkWitness 1908 false true 4711 = true := by decide +kernel
private theorem w1908_2 : checkWitness 1908 true false 627 = true := by decide +kernel
private theorem w1908_3 : checkWitness 1908 true true 4711 = true := by decide +kernel
private theorem cases1908 : checkFour 1908 (627,4711,627,4711) = true := by
  simp only [checkFour, w1908_0,w1908_1,w1908_2,w1908_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1908 : Coverage 1908 1909 := checkList_sound (ws:=[(627,4711,627,4711)]) (by simpa only [checkList, Bool.and_true] using cases1908)
private theorem w1909_0 : checkWitness 1909 false false 8880 = true := by decide +kernel
private theorem w1909_2 : checkWitness 1909 true false 8876 = true := by decide +kernel
private theorem cases1909 : checkFour 1909 (8880,0,8876,0) = true := by
  simp only [checkFour, w1909_0,w1909_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1909 : Coverage 1909 1910 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases1909)
private theorem w1910_0 : checkWitness 1910 false false 92 = true := by decide +kernel
private theorem w1910_2 : checkWitness 1910 true false 92 = true := by decide +kernel
private theorem cases1910 : checkFour 1910 (92,0,92,0) = true := by
  simp only [checkFour, w1910_0,w1910_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1910 : Coverage 1910 1911 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1910)
private theorem w1911_0 : checkWitness 1911 false false 625 = true := by decide +kernel
private theorem w1911_1 : checkWitness 1911 false true 4717 = true := by decide +kernel
private theorem w1911_2 : checkWitness 1911 true false 616 = true := by decide +kernel
private theorem w1911_3 : checkWitness 1911 true true 4708 = true := by decide +kernel
private theorem cases1911 : checkFour 1911 (625,4717,616,4708) = true := by
  simp only [checkFour, w1911_0,w1911_1,w1911_2,w1911_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1911 : Coverage 1911 1912 := checkList_sound (ws:=[(625,4717,616,4708)]) (by simpa only [checkList, Bool.and_true] using cases1911)
private theorem w1912_0 : checkWitness 1912 false false 8922 = true := by decide +kernel
private theorem w1912_2 : checkWitness 1912 true false 8913 = true := by decide +kernel
private theorem cases1912 : checkFour 1912 (8922,0,8913,0) = true := by
  simp only [checkFour, w1912_0,w1912_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1912 : Coverage 1912 1913 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases1912)
private theorem w1913_0 : checkWitness 1913 false false 8868 = true := by decide +kernel
private theorem w1913_2 : checkWitness 1913 true false 8864 = true := by decide +kernel
private theorem cases1913 : checkFour 1913 (8868,0,8864,0) = true := by
  simp only [checkFour, w1913_0,w1913_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1913 : Coverage 1913 1914 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases1913)
private theorem w1914_0 : checkWitness 1914 false false 86 = true := by decide +kernel
private theorem w1914_2 : checkWitness 1914 true false 86 = true := by decide +kernel
private theorem cases1914 : checkFour 1914 (86,0,86,0) = true := by
  simp only [checkFour, w1914_0,w1914_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1914 : Coverage 1914 1915 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1914)
private theorem w1915_0 : checkWitness 1915 false false 652 = true := by decide +kernel
private theorem w1915_1 : checkWitness 1915 false true 4744 = true := by decide +kernel
private theorem w1915_2 : checkWitness 1915 true false 643 = true := by decide +kernel
private theorem w1915_3 : checkWitness 1915 true true 4735 = true := by decide +kernel
private theorem cases1915 : checkFour 1915 (652,4744,643,4735) = true := by
  simp only [checkFour, w1915_0,w1915_1,w1915_2,w1915_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1915 : Coverage 1915 1916 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases1915)
private theorem w1916_0 : checkWitness 1916 false false 8929 = true := by decide +kernel
private theorem w1916_2 : checkWitness 1916 true false 8920 = true := by decide +kernel
private theorem cases1916 : checkFour 1916 (8929,0,8920,0) = true := by
  simp only [checkFour, w1916_0,w1916_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1916 : Coverage 1916 1917 := checkList_sound (ws:=[(8929,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases1916)
private theorem w1917_0 : checkWitness 1917 false false 70 = true := by decide +kernel
private theorem w1917_2 : checkWitness 1917 true false 70 = true := by decide +kernel
private theorem cases1917 : checkFour 1917 (70,0,70,0) = true := by
  simp only [checkFour, w1917_0,w1917_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1917 : Coverage 1917 1918 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases1917)
private theorem w1918_0 : checkWitness 1918 false false 708 = true := by decide +kernel
private theorem w1918_1 : checkWitness 1918 false true 4804 = true := by decide +kernel
private theorem w1918_2 : checkWitness 1918 true false 708 = true := by decide +kernel
private theorem w1918_3 : checkWitness 1918 true true 4804 = true := by decide +kernel
private theorem cases1918 : checkFour 1918 (708,4804,708,4804) = true := by
  simp only [checkFour, w1918_0,w1918_1,w1918_2,w1918_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1918 : Coverage 1918 1919 := checkList_sound (ws:=[(708,4804,708,4804)]) (by simpa only [checkList, Bool.and_true] using cases1918)
private theorem w1919_0 : checkWitness 1919 false false 8956 = true := by decide +kernel
private theorem w1919_2 : checkWitness 1919 true false 8947 = true := by decide +kernel
private theorem cases1919 : checkFour 1919 (8956,0,8947,0) = true := by
  simp only [checkFour, w1919_0,w1919_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1919 : Coverage 1919 1920 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases1919)
theorem cover1888 : Coverage 1888 1920 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1888 one1889) (Coverage.join one1890 one1891)) (Coverage.join (Coverage.join one1892 one1893) (Coverage.join one1894 one1895))) (Coverage.join (Coverage.join (Coverage.join one1896 one1897) (Coverage.join one1898 one1899)) (Coverage.join (Coverage.join one1900 one1901) (Coverage.join one1902 one1903)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1904 one1905) (Coverage.join one1906 one1907)) (Coverage.join (Coverage.join one1908 one1909) (Coverage.join one1910 one1911))) (Coverage.join (Coverage.join (Coverage.join one1912 one1913) (Coverage.join one1914 one1915)) (Coverage.join (Coverage.join one1916 one1917) (Coverage.join one1918 one1919)))))
end NF180PA.Symbolic
