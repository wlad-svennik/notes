import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1216_0 : checkWitness 1216 false false 8858 = true := by decide +kernel
private theorem w1216_2 : checkWitness 1216 true false 8854 = true := by decide +kernel
private theorem cases1216 : checkFour 1216 (8858,0,8854,0) = true := by
  simp only [checkFour, w1216_0,w1216_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1216 : Coverage 1216 1217 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1216)
private theorem w1217_0 : checkWitness 1217 false false 98 = true := by decide +kernel
private theorem w1217_2 : checkWitness 1217 true false 98 = true := by decide +kernel
private theorem cases1217 : checkFour 1217 (98,0,98,0) = true := by
  simp only [checkFour, w1217_0,w1217_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1217 : Coverage 1217 1218 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1217)
private theorem w1218_0 : checkWitness 1218 false false 603 = true := by decide +kernel
private theorem w1218_1 : checkWitness 1218 false true 4695 = true := by decide +kernel
private theorem w1218_2 : checkWitness 1218 true false 594 = true := by decide +kernel
private theorem w1218_3 : checkWitness 1218 true true 4686 = true := by decide +kernel
private theorem cases1218 : checkFour 1218 (603,4695,594,4686) = true := by
  simp only [checkFour, w1218_0,w1218_1,w1218_2,w1218_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1218 : Coverage 1218 1219 := checkList_sound (ws:=[(603,4695,594,4686)]) (by simpa only [checkList, Bool.and_true] using cases1218)
private theorem w1219_0 : checkWitness 1219 false false 8900 = true := by decide +kernel
private theorem w1219_2 : checkWitness 1219 true false 8891 = true := by decide +kernel
private theorem cases1219 : checkFour 1219 (8900,0,8891,0) = true := by
  simp only [checkFour, w1219_0,w1219_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1219 : Coverage 1219 1220 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1219)
private theorem w1220_0 : checkWitness 1220 false false 8846 = true := by decide +kernel
private theorem w1220_2 : checkWitness 1220 true false 8842 = true := by decide +kernel
private theorem cases1220 : checkFour 1220 (8846,0,8842,0) = true := by
  simp only [checkFour, w1220_0,w1220_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1220 : Coverage 1220 1221 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1220)
private theorem w1221_0 : checkWitness 1221 false false 92 = true := by decide +kernel
private theorem w1221_2 : checkWitness 1221 true false 92 = true := by decide +kernel
private theorem cases1221 : checkFour 1221 (92,0,92,0) = true := by
  simp only [checkFour, w1221_0,w1221_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1221 : Coverage 1221 1222 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1221)
private theorem w1222_0 : checkWitness 1222 false false 630 = true := by decide +kernel
private theorem w1222_1 : checkWitness 1222 false true 4722 = true := by decide +kernel
private theorem w1222_2 : checkWitness 1222 true false 621 = true := by decide +kernel
private theorem w1222_3 : checkWitness 1222 true true 4713 = true := by decide +kernel
private theorem cases1222 : checkFour 1222 (630,4722,621,4713) = true := by
  simp only [checkFour, w1222_0,w1222_1,w1222_2,w1222_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1222 : Coverage 1222 1223 := checkList_sound (ws:=[(630,4722,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases1222)
private theorem w1223_0 : checkWitness 1223 false false 8907 = true := by decide +kernel
private theorem w1223_2 : checkWitness 1223 true false 8898 = true := by decide +kernel
private theorem cases1223 : checkFour 1223 (8907,0,8898,0) = true := by
  simp only [checkFour, w1223_0,w1223_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1223 : Coverage 1223 1224 := checkList_sound (ws:=[(8907,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases1223)
private theorem w1224_0 : checkWitness 1224 false false 76 = true := by decide +kernel
private theorem w1224_2 : checkWitness 1224 true false 76 = true := by decide +kernel
private theorem cases1224 : checkFour 1224 (76,0,76,0) = true := by
  simp only [checkFour, w1224_0,w1224_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1224 : Coverage 1224 1225 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1224)
private theorem w1225_0 : checkWitness 1225 false false 494 = true := by decide +kernel
private theorem w1225_1 : checkWitness 1225 false true 4590 = true := by decide +kernel
private theorem w1225_2 : checkWitness 1225 true false 494 = true := by decide +kernel
private theorem w1225_3 : checkWitness 1225 true true 4590 = true := by decide +kernel
private theorem cases1225 : checkFour 1225 (494,4590,494,4590) = true := by
  simp only [checkFour, w1225_0,w1225_1,w1225_2,w1225_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1225 : Coverage 1225 1226 := checkList_sound (ws:=[(494,4590,494,4590)]) (by simpa only [checkList, Bool.and_true] using cases1225)
private theorem w1226_0 : checkWitness 1226 false false 8889 = true := by decide +kernel
private theorem w1226_2 : checkWitness 1226 true false 8885 = true := by decide +kernel
private theorem cases1226 : checkFour 1226 (8889,0,8885,0) = true := by
  simp only [checkFour, w1226_0,w1226_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1226 : Coverage 1226 1227 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1226)
private theorem w1227_0 : checkWitness 1227 false false 620 = true := by decide +kernel
private theorem w1227_1 : checkWitness 1227 false true 4716 = true := by decide +kernel
private theorem w1227_2 : checkWitness 1227 true false 611 = true := by decide +kernel
private theorem w1227_3 : checkWitness 1227 true true 4707 = true := by decide +kernel
private theorem cases1227 : checkFour 1227 (620,4716,611,4707) = true := by
  simp only [checkFour, w1227_0,w1227_1,w1227_2,w1227_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1227 : Coverage 1227 1228 := checkList_sound (ws:=[(620,4716,611,4707)]) (by simpa only [checkList, Bool.and_true] using cases1227)
private theorem w1228_0 : checkWitness 1228 false false 174 = true := by decide +kernel
private theorem w1228_2 : checkWitness 1228 true false 174 = true := by decide +kernel
private theorem cases1228 : checkFour 1228 (174,0,174,0) = true := by
  simp only [checkFour, w1228_0,w1228_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1228 : Coverage 1228 1229 := checkList_sound (ws:=[(174,0,174,0)]) (by simpa only [checkList, Bool.and_true] using cases1228)
private theorem w1229_0 : checkWitness 1229 false false 575 = true := by decide +kernel
private theorem w1229_1 : checkWitness 1229 false true 4663 = true := by decide +kernel
private theorem w1229_2 : checkWitness 1229 true false 575 = true := by decide +kernel
private theorem w1229_3 : checkWitness 1229 true true 4663 = true := by decide +kernel
private theorem cases1229 : checkFour 1229 (575,4663,575,4663) = true := by
  simp only [checkFour, w1229_0,w1229_1,w1229_2,w1229_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1229 : Coverage 1229 1230 := checkList_sound (ws:=[(575,4663,575,4663)]) (by simpa only [checkList, Bool.and_true] using cases1229)
private theorem w1230_0 : checkWitness 1230 false false 8904 = true := by decide +kernel
private theorem w1230_2 : checkWitness 1230 true false 8895 = true := by decide +kernel
private theorem cases1230 : checkFour 1230 (8904,0,8895,0) = true := by
  simp only [checkFour, w1230_0,w1230_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1230 : Coverage 1230 1231 := checkList_sound (ws:=[(8904,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases1230)
private theorem w1231_0 : checkWitness 1231 false false 94 = true := by decide +kernel
private theorem w1231_2 : checkWitness 1231 true false 94 = true := by decide +kernel
private theorem cases1231 : checkFour 1231 (94,0,94,0) = true := by
  simp only [checkFour, w1231_0,w1231_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1231 : Coverage 1231 1232 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1231)
private theorem w1232_0 : checkWitness 1232 false false 86 = true := by decide +kernel
private theorem w1232_2 : checkWitness 1232 true false 86 = true := by decide +kernel
private theorem cases1232 : checkFour 1232 (86,0,86,0) = true := by
  simp only [checkFour, w1232_0,w1232_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1232 : Coverage 1232 1233 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1232)
private theorem w1233_0 : checkWitness 1233 false false 581 = true := by decide +kernel
private theorem w1233_1 : checkWitness 1233 false true 4673 = true := by decide +kernel
private theorem w1233_2 : checkWitness 1233 true false 581 = true := by decide +kernel
private theorem w1233_3 : checkWitness 1233 true true 4673 = true := by decide +kernel
private theorem cases1233 : checkFour 1233 (581,4673,581,4673) = true := by
  simp only [checkFour, w1233_0,w1233_1,w1233_2,w1233_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1233 : Coverage 1233 1234 := checkList_sound (ws:=[(581,4673,581,4673)]) (by simpa only [checkList, Bool.and_true] using cases1233)
private theorem w1234_0 : checkWitness 1234 false false 8842 = true := by decide +kernel
private theorem w1234_2 : checkWitness 1234 true false 8838 = true := by decide +kernel
private theorem cases1234 : checkFour 1234 (8842,0,8838,0) = true := by
  simp only [checkFour, w1234_0,w1234_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1234 : Coverage 1234 1235 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1234)
private theorem w1235_0 : checkWitness 1235 false false 86 = true := by decide +kernel
private theorem w1235_2 : checkWitness 1235 true false 86 = true := by decide +kernel
private theorem cases1235 : checkFour 1235 (86,0,86,0) = true := by
  simp only [checkFour, w1235_0,w1235_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1235 : Coverage 1235 1236 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1235)
private theorem w1236_0 : checkWitness 1236 false false 536 = true := by decide +kernel
private theorem w1236_1 : checkWitness 1236 false true 4632 = true := by decide +kernel
private theorem w1236_2 : checkWitness 1236 true false 536 = true := by decide +kernel
private theorem w1236_3 : checkWitness 1236 true true 4632 = true := by decide +kernel
private theorem cases1236 : checkFour 1236 (536,4632,536,4632) = true := by
  simp only [checkFour, w1236_0,w1236_1,w1236_2,w1236_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1236 : Coverage 1236 1237 := checkList_sound (ws:=[(536,4632,536,4632)]) (by simpa only [checkList, Bool.and_true] using cases1236)
private theorem w1237_0 : checkWitness 1237 false false 8877 = true := by decide +kernel
private theorem w1237_2 : checkWitness 1237 true false 8873 = true := by decide +kernel
private theorem cases1237 : checkFour 1237 (8877,0,8873,0) = true := by
  simp only [checkFour, w1237_0,w1237_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1237 : Coverage 1237 1238 := checkList_sound (ws:=[(8877,0,8873,0)]) (by simpa only [checkList, Bool.and_true] using cases1237)
private theorem w1238_0 : checkWitness 1238 false false 8912 = true := by decide +kernel
private theorem w1238_2 : checkWitness 1238 true false 8903 = true := by decide +kernel
private theorem cases1238 : checkFour 1238 (8912,0,8903,0) = true := by
  simp only [checkFour, w1238_0,w1238_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1238 : Coverage 1238 1239 := checkList_sound (ws:=[(8912,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases1238)
private theorem w1239_0 : checkWitness 1239 false false 104 = true := by decide +kernel
private theorem w1239_2 : checkWitness 1239 true false 104 = true := by decide +kernel
private theorem cases1239 : checkFour 1239 (104,0,104,0) = true := by
  simp only [checkFour, w1239_0,w1239_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1239 : Coverage 1239 1240 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases1239)
private theorem w1240_0 : checkWitness 1240 false false 624 = true := by decide +kernel
private theorem w1240_1 : checkWitness 1240 false true 4716 = true := by decide +kernel
private theorem w1240_2 : checkWitness 1240 true false 615 = true := by decide +kernel
private theorem w1240_3 : checkWitness 1240 true true 4707 = true := by decide +kernel
private theorem cases1240 : checkFour 1240 (624,4716,615,4707) = true := by
  simp only [checkFour, w1240_0,w1240_1,w1240_2,w1240_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1240 : Coverage 1240 1241 := checkList_sound (ws:=[(624,4716,615,4707)]) (by simpa only [checkList, Bool.and_true] using cases1240)
private theorem w1241_0 : checkWitness 1241 false false 8873 = true := by decide +kernel
private theorem w1241_2 : checkWitness 1241 true false 8869 = true := by decide +kernel
private theorem cases1241 : checkFour 1241 (8873,0,8869,0) = true := by
  simp only [checkFour, w1241_0,w1241_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1241 : Coverage 1241 1242 := checkList_sound (ws:=[(8873,0,8869,0)]) (by simpa only [checkList, Bool.and_true] using cases1241)
private theorem w1242_0 : checkWitness 1242 false false 618 = true := by decide +kernel
private theorem w1242_1 : checkWitness 1242 false true 4710 = true := by decide +kernel
private theorem w1242_2 : checkWitness 1242 true false 609 = true := by decide +kernel
private theorem w1242_3 : checkWitness 1242 true true 4701 = true := by decide +kernel
private theorem cases1242 : checkFour 1242 (618,4710,609,4701) = true := by
  simp only [checkFour, w1242_0,w1242_1,w1242_2,w1242_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1242 : Coverage 1242 1243 := checkList_sound (ws:=[(618,4710,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases1242)
private theorem w1243_0 : checkWitness 1243 false false 8842 = true := by decide +kernel
private theorem w1243_2 : checkWitness 1243 true false 8838 = true := by decide +kernel
private theorem cases1243 : checkFour 1243 (8842,0,8838,0) = true := by
  simp only [checkFour, w1243_0,w1243_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1243 : Coverage 1243 1244 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1243)
private theorem w1244_0 : checkWitness 1244 false false 92 = true := by decide +kernel
private theorem w1244_2 : checkWitness 1244 true false 92 = true := by decide +kernel
private theorem cases1244 : checkFour 1244 (92,0,92,0) = true := by
  simp only [checkFour, w1244_0,w1244_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1244 : Coverage 1244 1245 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1244)
private theorem w1245_0 : checkWitness 1245 false false 84 = true := by decide +kernel
private theorem w1245_2 : checkWitness 1245 true false 84 = true := by decide +kernel
private theorem cases1245 : checkFour 1245 (84,0,84,0) = true := by
  simp only [checkFour, w1245_0,w1245_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1245 : Coverage 1245 1246 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1245)
private theorem w1246_0 : checkWitness 1246 false false 585 = true := by decide +kernel
private theorem w1246_1 : checkWitness 1246 false true 4673 = true := by decide +kernel
private theorem w1246_2 : checkWitness 1246 true false 585 = true := by decide +kernel
private theorem w1246_3 : checkWitness 1246 true true 4673 = true := by decide +kernel
private theorem cases1246 : checkFour 1246 (585,4673,585,4673) = true := by
  simp only [checkFour, w1246_0,w1246_1,w1246_2,w1246_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1246 : Coverage 1246 1247 := checkList_sound (ws:=[(585,4673,585,4673)]) (by simpa only [checkList, Bool.and_true] using cases1246)
private theorem w1247_0 : checkWitness 1247 false false 8858 = true := by decide +kernel
private theorem w1247_2 : checkWitness 1247 true false 8854 = true := by decide +kernel
private theorem cases1247 : checkFour 1247 (8858,0,8854,0) = true := by
  simp only [checkFour, w1247_0,w1247_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1247 : Coverage 1247 1248 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1247)
theorem cover1216 : Coverage 1216 1248 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1216 one1217) (Coverage.join one1218 one1219)) (Coverage.join (Coverage.join one1220 one1221) (Coverage.join one1222 one1223))) (Coverage.join (Coverage.join (Coverage.join one1224 one1225) (Coverage.join one1226 one1227)) (Coverage.join (Coverage.join one1228 one1229) (Coverage.join one1230 one1231)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1232 one1233) (Coverage.join one1234 one1235)) (Coverage.join (Coverage.join one1236 one1237) (Coverage.join one1238 one1239))) (Coverage.join (Coverage.join (Coverage.join one1240 one1241) (Coverage.join one1242 one1243)) (Coverage.join (Coverage.join one1244 one1245) (Coverage.join one1246 one1247)))))
end NF180PA.Symbolic
