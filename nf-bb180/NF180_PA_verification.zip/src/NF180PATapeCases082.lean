import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2624_0 : checkWitness 2624 false false 704 = true := by decide +kernel
private theorem w2624_1 : checkWitness 2624 false true 4796 = true := by decide +kernel
private theorem w2624_2 : checkWitness 2624 true false 695 = true := by decide +kernel
private theorem w2624_3 : checkWitness 2624 true true 4787 = true := by decide +kernel
private theorem cases2624 : checkFour 2624 (704,4796,695,4787) = true := by
  simp only [checkFour, w2624_0,w2624_1,w2624_2,w2624_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2624 : Coverage 2624 2625 := checkList_sound (ws:=[(704,4796,695,4787)]) (by simpa only [checkList, Bool.and_true] using cases2624)
private theorem w2625_0 : checkWitness 2625 false false 8953 = true := by decide +kernel
private theorem w2625_2 : checkWitness 2625 true false 8949 = true := by decide +kernel
private theorem cases2625 : checkFour 2625 (8953,0,8949,0) = true := by
  simp only [checkFour, w2625_0,w2625_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2625 : Coverage 2625 2626 := checkList_sound (ws:=[(8953,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases2625)
private theorem w2626_0 : checkWitness 2626 false false 698 = true := by decide +kernel
private theorem w2626_1 : checkWitness 2626 false true 4790 = true := by decide +kernel
private theorem w2626_2 : checkWitness 2626 true false 689 = true := by decide +kernel
private theorem w2626_3 : checkWitness 2626 true true 4781 = true := by decide +kernel
private theorem cases2626 : checkFour 2626 (698,4790,689,4781) = true := by
  simp only [checkFour, w2626_0,w2626_1,w2626_2,w2626_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2626 : Coverage 2626 2627 := checkList_sound (ws:=[(698,4790,689,4781)]) (by simpa only [checkList, Bool.and_true] using cases2626)
private theorem w2627_0 : checkWitness 2627 false false 8922 = true := by decide +kernel
private theorem w2627_2 : checkWitness 2627 true false 8918 = true := by decide +kernel
private theorem cases2627 : checkFour 2627 (8922,0,8918,0) = true := by
  simp only [checkFour, w2627_0,w2627_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2627 : Coverage 2627 2628 := checkList_sound (ws:=[(8922,0,8918,0)]) (by simpa only [checkList, Bool.and_true] using cases2627)
private theorem w2628_0 : checkWitness 2628 false false 72 = true := by decide +kernel
private theorem w2628_2 : checkWitness 2628 true false 72 = true := by decide +kernel
private theorem cases2628 : checkFour 2628 (72,0,72,0) = true := by
  simp only [checkFour, w2628_0,w2628_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2628 : Coverage 2628 2629 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2628)
private theorem w2629_0 : checkWitness 2629 false false 64 = true := by decide +kernel
private theorem w2629_2 : checkWitness 2629 true false 64 = true := by decide +kernel
private theorem cases2629 : checkFour 2629 (64,0,64,0) = true := by
  simp only [checkFour, w2629_0,w2629_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2629 : Coverage 2629 2630 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2629)
private theorem w2630_0 : checkWitness 2630 false false 663 = true := by decide +kernel
private theorem w2630_1 : checkWitness 2630 false true 4747 = true := by decide +kernel
private theorem w2630_2 : checkWitness 2630 true false 663 = true := by decide +kernel
private theorem w2630_3 : checkWitness 2630 true true 4747 = true := by decide +kernel
private theorem cases2630 : checkFour 2630 (663,4747,663,4747) = true := by
  simp only [checkFour, w2630_0,w2630_1,w2630_2,w2630_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2630 : Coverage 2630 2631 := checkList_sound (ws:=[(663,4747,663,4747)]) (by simpa only [checkList, Bool.and_true] using cases2630)
private theorem w2631_0 : checkWitness 2631 false false 8916 = true := by decide +kernel
private theorem w2631_2 : checkWitness 2631 true false 8912 = true := by decide +kernel
private theorem cases2631 : checkFour 2631 (8916,0,8912,0) = true := by
  simp only [checkFour, w2631_0,w2631_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2631 : Coverage 2631 2632 := checkList_sound (ws:=[(8916,0,8912,0)]) (by simpa only [checkList, Bool.and_true] using cases2631)
private theorem w2632_0 : checkWitness 2632 false false 64 = true := by decide +kernel
private theorem w2632_2 : checkWitness 2632 true false 64 = true := by decide +kernel
private theorem cases2632 : checkFour 2632 (64,0,64,0) = true := by
  simp only [checkFour, w2632_0,w2632_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2632 : Coverage 2632 2633 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2632)
private theorem w2633_0 : checkWitness 2633 false false 631 = true := by decide +kernel
private theorem w2633_1 : checkWitness 2633 false true 4727 = true := by decide +kernel
private theorem w2633_2 : checkWitness 2633 true false 631 = true := by decide +kernel
private theorem w2633_3 : checkWitness 2633 true true 4727 = true := by decide +kernel
private theorem cases2633 : checkFour 2633 (631,4727,631,4727) = true := by
  simp only [checkFour, w2633_0,w2633_1,w2633_2,w2633_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2633 : Coverage 2633 2634 := checkList_sound (ws:=[(631,4727,631,4727)]) (by simpa only [checkList, Bool.and_true] using cases2633)
private theorem w2634_0 : checkWitness 2634 false false 8984 = true := by decide +kernel
private theorem w2634_2 : checkWitness 2634 true false 8975 = true := by decide +kernel
private theorem cases2634 : checkFour 2634 (8984,0,8975,0) = true := by
  simp only [checkFour, w2634_0,w2634_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2634 : Coverage 2634 2635 := checkList_sound (ws:=[(8984,0,8975,0)]) (by simpa only [checkList, Bool.and_true] using cases2634)
private theorem w2635_0 : checkWitness 2635 false false 8930 = true := by decide +kernel
private theorem w2635_2 : checkWitness 2635 true false 8926 = true := by decide +kernel
private theorem cases2635 : checkFour 2635 (8930,0,8926,0) = true := by
  simp only [checkFour, w2635_0,w2635_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2635 : Coverage 2635 2636 := checkList_sound (ws:=[(8930,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases2635)
private theorem w2636_0 : checkWitness 2636 false false 72 = true := by decide +kernel
private theorem w2636_2 : checkWitness 2636 true false 72 = true := by decide +kernel
private theorem cases2636 : checkFour 2636 (72,0,72,0) = true := by
  simp only [checkFour, w2636_0,w2636_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2636 : Coverage 2636 2637 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2636)
private theorem w2637_0 : checkWitness 2637 false false 714 = true := by decide +kernel
private theorem w2637_1 : checkWitness 2637 false true 4802 = true := by decide +kernel
private theorem w2637_2 : checkWitness 2637 true false 705 = true := by decide +kernel
private theorem w2637_3 : checkWitness 2637 true true 4793 = true := by decide +kernel
private theorem cases2637 : checkFour 2637 (714,4802,705,4793) = true := by
  simp only [checkFour, w2637_0,w2637_1,w2637_2,w2637_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2637 : Coverage 2637 2638 := checkList_sound (ws:=[(714,4802,705,4793)]) (by simpa only [checkList, Bool.and_true] using cases2637)
private theorem w2638_0 : checkWitness 2638 false false 8949 = true := by decide +kernel
private theorem w2638_2 : checkWitness 2638 true false 8945 = true := by decide +kernel
private theorem cases2638 : checkFour 2638 (8949,0,8945,0) = true := by
  simp only [checkFour, w2638_0,w2638_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2638 : Coverage 2638 2639 := checkList_sound (ws:=[(8949,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2638)
private theorem w2639_0 : checkWitness 2639 false false 62 = true := by decide +kernel
private theorem w2639_2 : checkWitness 2639 true false 62 = true := by decide +kernel
private theorem cases2639 : checkFour 2639 (62,0,62,0) = true := by
  simp only [checkFour, w2639_0,w2639_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2639 : Coverage 2639 2640 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2639)
private theorem w2640_0 : checkWitness 2640 false false 722 = true := by decide +kernel
private theorem w2640_1 : checkWitness 2640 false true 4818 = true := by decide +kernel
private theorem w2640_2 : checkWitness 2640 true false 722 = true := by decide +kernel
private theorem w2640_3 : checkWitness 2640 true true 4818 = true := by decide +kernel
private theorem cases2640 : checkFour 2640 (722,4818,722,4818) = true := by
  simp only [checkFour, w2640_0,w2640_1,w2640_2,w2640_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2640 : Coverage 2640 2641 := checkList_sound (ws:=[(722,4818,722,4818)]) (by simpa only [checkList, Bool.and_true] using cases2640)
private theorem w2641_0 : checkWitness 2641 false false 8994 = true := by decide +kernel
private theorem w2641_2 : checkWitness 2641 true false 8985 = true := by decide +kernel
private theorem cases2641 : checkFour 2641 (8994,0,8985,0) = true := by
  simp only [checkFour, w2641_0,w2641_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2641 : Coverage 2641 2642 := checkList_sound (ws:=[(8994,0,8985,0)]) (by simpa only [checkList, Bool.and_true] using cases2641)
private theorem w2642_0 : checkWitness 2642 false false 64 = true := by decide +kernel
private theorem w2642_2 : checkWitness 2642 true false 64 = true := by decide +kernel
private theorem cases2642 : checkFour 2642 (64,0,64,0) = true := by
  simp only [checkFour, w2642_0,w2642_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2642 : Coverage 2642 2643 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2642)
private theorem w2643_0 : checkWitness 2643 false false 576 = true := by decide +kernel
private theorem w2643_1 : checkWitness 2643 false true 4672 = true := by decide +kernel
private theorem w2643_2 : checkWitness 2643 true false 576 = true := by decide +kernel
private theorem w2643_3 : checkWitness 2643 true true 4672 = true := by decide +kernel
private theorem cases2643 : checkFour 2643 (576,4672,576,4672) = true := by
  simp only [checkFour, w2643_0,w2643_1,w2643_2,w2643_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2643 : Coverage 2643 2644 := checkList_sound (ws:=[(576,4672,576,4672)]) (by simpa only [checkList, Bool.and_true] using cases2643)
private theorem w2644_0 : checkWitness 2644 false false 8934 = true := by decide +kernel
private theorem w2644_2 : checkWitness 2644 true false 8930 = true := by decide +kernel
private theorem cases2644 : checkFour 2644 (8934,0,8930,0) = true := by
  simp only [checkFour, w2644_0,w2644_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2644 : Coverage 2644 2645 := checkList_sound (ws:=[(8934,0,8930,0)]) (by simpa only [checkList, Bool.and_true] using cases2644)
private theorem w2645_0 : checkWitness 2645 false false 66 = true := by decide +kernel
private theorem w2645_2 : checkWitness 2645 true false 66 = true := by decide +kernel
private theorem cases2645 : checkFour 2645 (66,0,66,0) = true := by
  simp only [checkFour, w2645_0,w2645_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2645 : Coverage 2645 2646 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2645)
private theorem w2646_0 : checkWitness 2646 false false 614 = true := by decide +kernel
private theorem w2646_1 : checkWitness 2646 false true 4710 = true := by decide +kernel
private theorem w2646_2 : checkWitness 2646 true false 614 = true := by decide +kernel
private theorem w2646_3 : checkWitness 2646 true true 4710 = true := by decide +kernel
private theorem cases2646 : checkFour 2646 (614,4710,614,4710) = true := by
  simp only [checkFour, w2646_0,w2646_1,w2646_2,w2646_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2646 : Coverage 2646 2647 := checkList_sound (ws:=[(614,4710,614,4710)]) (by simpa only [checkList, Bool.and_true] using cases2646)
private theorem w2647_0 : checkWitness 2647 false false 8955 = true := by decide +kernel
private theorem w2647_2 : checkWitness 2647 true false 8951 = true := by decide +kernel
private theorem cases2647 : checkFour 2647 (8955,0,8951,0) = true := by
  simp only [checkFour, w2647_0,w2647_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2647 : Coverage 2647 2648 := checkList_sound (ws:=[(8955,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases2647)
private theorem w2648_0 : checkWitness 2648 false false 8990 = true := by decide +kernel
private theorem w2648_2 : checkWitness 2648 true false 8981 = true := by decide +kernel
private theorem cases2648 : checkFour 2648 (8990,0,8981,0) = true := by
  simp only [checkFour, w2648_0,w2648_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2648 : Coverage 2648 2649 := checkList_sound (ws:=[(8990,0,8981,0)]) (by simpa only [checkList, Bool.and_true] using cases2648)
private theorem w2649_0 : checkWitness 2649 false false 90 = true := by decide +kernel
private theorem w2649_2 : checkWitness 2649 true false 90 = true := by decide +kernel
private theorem cases2649 : checkFour 2649 (90,0,90,0) = true := by
  simp only [checkFour, w2649_0,w2649_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2649 : Coverage 2649 2650 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases2649)
private theorem w2650_0 : checkWitness 2650 false false 702 = true := by decide +kernel
private theorem w2650_1 : checkWitness 2650 false true 4794 = true := by decide +kernel
private theorem w2650_2 : checkWitness 2650 true false 693 = true := by decide +kernel
private theorem w2650_3 : checkWitness 2650 true true 4785 = true := by decide +kernel
private theorem cases2650 : checkFour 2650 (702,4794,693,4785) = true := by
  simp only [checkFour, w2650_0,w2650_1,w2650_2,w2650_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2650 : Coverage 2650 2651 := checkList_sound (ws:=[(702,4794,693,4785)]) (by simpa only [checkList, Bool.and_true] using cases2650)
private theorem w2651_0 : checkWitness 2651 false false 8951 = true := by decide +kernel
private theorem w2651_2 : checkWitness 2651 true false 8947 = true := by decide +kernel
private theorem cases2651 : checkFour 2651 (8951,0,8947,0) = true := by
  simp only [checkFour, w2651_0,w2651_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2651 : Coverage 2651 2652 := checkList_sound (ws:=[(8951,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2651)
private theorem w2652_0 : checkWitness 2652 false false 696 = true := by decide +kernel
private theorem w2652_1 : checkWitness 2652 false true 4788 = true := by decide +kernel
private theorem w2652_2 : checkWitness 2652 true false 687 = true := by decide +kernel
private theorem w2652_3 : checkWitness 2652 true true 4779 = true := by decide +kernel
private theorem cases2652 : checkFour 2652 (696,4788,687,4779) = true := by
  simp only [checkFour, w2652_0,w2652_1,w2652_2,w2652_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2652 : Coverage 2652 2653 := checkList_sound (ws:=[(696,4788,687,4779)]) (by simpa only [checkList, Bool.and_true] using cases2652)
private theorem w2653_0 : checkWitness 2653 false false 8920 = true := by decide +kernel
private theorem w2653_2 : checkWitness 2653 true false 8916 = true := by decide +kernel
private theorem cases2653 : checkFour 2653 (8920,0,8916,0) = true := by
  simp only [checkFour, w2653_0,w2653_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2653 : Coverage 2653 2654 := checkList_sound (ws:=[(8920,0,8916,0)]) (by simpa only [checkList, Bool.and_true] using cases2653)
private theorem w2654_0 : checkWitness 2654 false false 78 = true := by decide +kernel
private theorem w2654_2 : checkWitness 2654 true false 78 = true := by decide +kernel
private theorem cases2654 : checkFour 2654 (78,0,78,0) = true := by
  simp only [checkFour, w2654_0,w2654_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2654 : Coverage 2654 2655 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2654)
private theorem w2655_0 : checkWitness 2655 false false 70 = true := by decide +kernel
private theorem w2655_2 : checkWitness 2655 true false 70 = true := by decide +kernel
private theorem cases2655 : checkFour 2655 (70,0,70,0) = true := by
  simp only [checkFour, w2655_0,w2655_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2655 : Coverage 2655 2656 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2655)
theorem cover2624 : Coverage 2624 2656 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2624 one2625) (Coverage.join one2626 one2627)) (Coverage.join (Coverage.join one2628 one2629) (Coverage.join one2630 one2631))) (Coverage.join (Coverage.join (Coverage.join one2632 one2633) (Coverage.join one2634 one2635)) (Coverage.join (Coverage.join one2636 one2637) (Coverage.join one2638 one2639)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2640 one2641) (Coverage.join one2642 one2643)) (Coverage.join (Coverage.join one2644 one2645) (Coverage.join one2646 one2647))) (Coverage.join (Coverage.join (Coverage.join one2648 one2649) (Coverage.join one2650 one2651)) (Coverage.join (Coverage.join one2652 one2653) (Coverage.join one2654 one2655)))))
end NF180PA.Symbolic
