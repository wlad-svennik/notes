import NF180PATapeFinite
import NF180PATapeExecution
import SourceData

/-! A kernel-executed checker for parameterized runs of the literal 180 table.
Each unary block can have any length in an arbitrary PA model. -/
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.PhysicalModel PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace NF180PA.Symbolic
open Gate (machine)
open Execute (bit face Path)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 1600000
set_option maxRecDepth 16000

noncomputable def rep (b : Bool) (k s : V) := iterate (bit b) k s
instance repDef (b : Bool) : Language.DefinableFunction₂ ℒₒᵣ (rep (V:=V) b) := by unfold rep; infer_instance
def pairBits (b : Bool) (r : V) := bit b (bit (!b) r)
instance pairBitsDef (b : Bool) : Language.DefinableFunction₁ ℒₒᵣ (pairBits (V:=V) b) := by unfold pairBits; definability
noncomputable def pairs (b : Bool) (n r : V) := iterate (pairBits b) n r
instance pairsDef (b : Bool) : Language.DefinableFunction₂ ℒₒᵣ (pairs (V:=V) b) := by unfold pairs; infer_instance
noncomputable def rays (d : Direction) (q : State) (s o : V) :=
  match d with
  | .right => pack (q.val:V) o s
  | .left => face q s o
instance raysDef (d : Direction) (q : State) : Language.DefinableFunction₂ ℒₒᵣ (rays (V:=V) d q) := by
  cases d <;> unfold rays <;> definability
noncomputable def word (v : Nat → V) : List Atom → V
  | [] => 0
  | .digit b :: w => bit b (word v w)
  | .many b k :: w => rep b (v k) (word v w)
  | .paired b k :: w => pairs b (v k) (word v w)
  | .tail i :: _ => v i
noncomputable def Config.val (c : Config) (v : Nat → V) := rays c.dir c.q (word v c.scan) (word v c.back)

private theorem reflPath (a : V) : Path a a := ⟨0,iterate_zero _ _⟩
private theorem single {q q' : State} {b w : Bool} {d : Direction}
    (row : machine q b = ⟨w,d,some q'⟩) (old : Direction) (s o : V) :
    Path (rays old q (bit b s) o)
      (if d=old then rays d q' s (bit w o) else rays d q' o (bit w s)) := by
  cases d <;> cases old <;> simp only [ite_true,reduceCtorEq,ite_false,rays]
  · exact Execute.fromLeft row s o
  · exact Execute.toLeft row o s
  · rw [Execute.face_cons]
    exact Execute.toRight row s o
  · exact Execute.toRight row o s

private theorem sweep {q : State} {b w : Bool} (d : Direction)
    (row : machine q b = ⟨w,d,some q⟩) :
    ∀ k : V, ∀ s o : V, Path (rays d q (rep b k s) o) (rays d q s (rep w k o)) := by
  apply modelInduct
  · definability
  · intro s o
    simp [rep,reflPath]
  · intro n prev s o
    rw [rep,iterate_succ,rep,iterate_succ_left]
    exact (show Path (rays d q (bit b (rep b n s)) o) (rays d q (rep b n s) (bit w o)) from
      by simpa using single row d (rep b n s) o).trans (prev s (bit w o))

/-- When a repeated field meets an identical adjacent literal, that literal
may be read before the field. This holds even when the field width is zero. -/
private theorem commute (b : Bool) (k r : V) : rep b k (bit b r) = bit b (rep b k r) :=
  (iterate_succ_left (bit b) k r).symm.trans (iterate_succ (bit b) k r)

theorem pair_commute (b : Bool) : ∀ k : V, ∀ r : V, pairs b k (bit b r) = bit b (pairs (!b) k r) := by
  apply modelInduct
  · definability
  · simp [pairs]
  · intro k prev r
    have step := prev r
    unfold pairs at step ⊢
    simp only [iterate_succ,step,pairBits,Bool.not_not]

private theorem marker_base (l r : V) :
    Path (rays .left 29 (bit false l) (bit true r)) (rays .left 29 l (bit true (bit false r))) := by
  apply (show Path _ _ from single (q:=(29:State)) (q':=(30:State)) (b:=false) (w:=false) (d:=.right) (by decide) .left l (bit true r)).trans
  apply (show Path _ _ from single (q:=(30:State)) (q':=(118:State)) (b:=true) (w:=false) (d:=.left) (by decide) .right r (bit false l)).trans
  exact single (q:=(118:State)) (q':=(29:State)) (b:=false) (w:=true) (d:=.left) (by decide) .left l (bit false r)

private theorem marker : ∀ k : V, ∀ l r : V,
    Path (rays .left 29 (rep false k l) (bit true r)) (rays .left 29 l (bit true (rep false k r))) := by
  apply modelInduct
  · definability
  · intro l r; simp [rep,reflPath]
  · intro n prev l r
    rw [rep,iterate_succ,rep,iterate_succ_left]
    exact (marker_base (rep false n l) r).trans (prev l (bit false r))

private theorem paired_sweep {q : State} (d : Direction) (b w : Bool)
    (base : ∀ s o : V, Path (rays d q (pairBits b s) o) (rays d q s (pairBits w o))) :
    ∀ k : V, ∀ s o : V, Path (rays d q (pairs b k s) o) (rays d q s (pairs w k o)) := by
  apply modelInduct
  · clear base; definability
  · intro s o; simp [pairs,reflPath]
  · intro n prev s o
    rw [pairs,iterate_succ,pairs,iterate_succ_left]
    exact (base _ _).trans (prev s (pairBits w o))

private theorem right_paired (k s o : V) :
    Path (rays .right 119 (pairs false k s) o) (rays .right 119 s (pairs false k o)) := by
  apply paired_sweep
  intro s o
  exact (single (q:=(119:State)) (q':=(150:State)) (b:=false) (w:=true) (d:=.right) (by decide) .right _ _).trans
    (single (q:=(150:State)) (q':=(119:State)) (b:=true) (w:=false) (d:=.right) (by decide) .right _ _)

private theorem left_paired (k s o : V) :
    Path (rays .left 141 (pairs false k s) o) (rays .left 141 s (pairs true k o)) := by
  apply paired_sweep
  intro s o
  exact (single (q:=(141:State)) (q':=(136:State)) (b:=false) (w:=false) (d:=.left) (by decide) .left _ _).trans
    (single (q:=(136:State)) (q':=(141:State)) (b:=true) (w:=true) (d:=.left) (by decide) .left _ _)

private theorem lit_sound {q q' : State} {b w : Bool} {d : Direction} (old : Direction)
    (row : machine q b = ⟨w,d,some q'⟩) (s o : List Atom) (v : Nat → V) :
    Path ((Config.mk q old (.digit b::s) o).val v) ((literalStep q' d old w s o).val v) := by
  unfold Config.val literalStep
  split <;> rename_i h <;> simpa [h,word] using single row old (word v s) (word v o)

private theorem many_sound {q q' : State} {b w : Bool} {d : Direction} (old : Direction)
    (row : machine q b = ⟨w,d,some q'⟩) (k : Nat) (s o : List Atom) (v : Nat → V)
    {z : Config} (h : manyStep q q' d old b w k s o = some z) :
    Path ((Config.mk q old (.many b k::s) o).val v) (z.val v) := by
  unfold manyStep at h
  split at h
  · rename_i eq
    obtain ⟨rfl,rfl⟩ := eq
    cases h
    exact sweep _ row (v k) (word v s) (word v o)
  · cases s with
    | nil => contradiction
    | cons a s =>
      cases a with
      | tail j => contradiction
      | many c j => contradiction
      | paired c j => contradiction
      | digit c =>
        by_cases eq : b=c
        · subst c
          simp only [ite_true] at h
          cases h
          change Path (rays old q (rep b (v k) (bit b (word v s))) (word v o))
            (rays old q (bit b (rep b (v k) (word v s))) (word v o))
          rw [commute]
          apply reflPath
        · simp [eq] at h

theorem step_sound {c c' : Config} (h : step c = some c') (v : Nat → V) :
    Path (c.val v) (c'.val v) := by
  rcases c with ⟨q,d,scan,o⟩
  cases scan with
  | nil => contradiction
  | cons a scan =>
    cases a with
    | tail j => contradiction
    | digit b =>
      cases e : machine q b with
      | mk w m next =>
        cases next with
        | none => simp [step,e] at h
        | some q' => simp [step,e] at h; subst c'; exact lit_sound d e scan o v
    | many b k =>
      by_cases hit : q=29 ∧ d=.left ∧ b=false
      · obtain ⟨rfl,rfl,rfl⟩ := hit
        cases o with
        | nil => simp [step] at h
        | cons z back =>
          cases z with
          | digit v' =>
            cases v' <;> simp [step] at h
            subst c'
            exact marker (v k) (word v scan) (word v back)
          | _ => simp [step] at h
      · cases e : machine q b with
        | mk w m next =>
          cases next with
          | none => simp [step,hit,e] at h
          | some q' => exact many_sound d e k scan o v (by simpa [step,hit,e] using h)
    | paired b k =>
      by_cases hr : b=false ∧ q=119 ∧ d=.right
      · obtain ⟨rfl,rfl,rfl⟩ := hr; simp [step] at h; subst c'
        exact right_paired _ _ _
      · by_cases hl : b=false ∧ q=141 ∧ d=.left
        · obtain ⟨rfl,rfl,rfl⟩ := hl; simp [step] at h; subst c'
          exact left_paired _ _ _
        · cases scan with
          | nil => simp [step,hl,hr] at h
          | cons x scan =>
            cases x with
            | digit z =>
              by_cases eq : z=b
              · subst z; simp [step,hl,hr] at h; subst c'
                simp only [Config.val,word,pair_commute]
                exact reflPath _
              · simp [step,hl,hr,eq] at h
            | _ => simp [step,hl,hr] at h

theorem after_sound {k : Nat} {c c' : Config} (h : after k c = some c') (v : Nat → V) :
    Path (c.val v) (c'.val v) := by
  induction k generalizing c with
  | zero => cases h; exact reflPath _
  | succ k ih =>
    cases e : step c with
    | none => simp [after,e] at h
    | some a => exact (step_sound e v).trans (ih (by simpa [after,e] using h : after k a = some c'))


theorem atGate_sound {c : Config} (h : atGate c = true) (v : Nat → V) : Gate.onGate (c.val v) := by
  rcases c with ⟨q,d,s,b⟩
  simp only [atGate,Bool.and_eq_true,beq_iff_eq] at h
  obtain ⟨rfl,hs⟩ := h
  cases s with
  | nil => contradiction
  | cons a s =>
    simp at hs
    subst a
    cases d <;> simp only [Config.val,rays,word,Execute.face_cons]
    all_goals exact ⟨state_pack ..,by rw [right_pack]; simpa using (Execute.halves true _).2⟩

#print axioms after_sound
#print axioms atGate_sound
end NF180PA.Symbolic
