import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2720_0 : checkWitness 2720 false false 8957 = true := by decide +kernel
private theorem w2720_2 : checkWitness 2720 true false 8953 = true := by decide +kernel
private theorem cases2720 : checkFour 2720 (8957,0,8953,0) = true := by
  simp only [checkFour, w2720_0,w2720_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2720 : Coverage 2720 2721 := checkList_sound (ws:=[(8957,0,8953,0)]) (by simpa only [checkList, Bool.and_true] using cases2720)
private theorem w2721_0 : checkWitness 2721 false false 688 = true := by decide +kernel
private theorem w2721_1 : checkWitness 2721 false true 4784 = true := by decide +kernel
private theorem w2721_2 : checkWitness 2721 true false 679 = true := by decide +kernel
private theorem w2721_3 : checkWitness 2721 true true 4775 = true := by decide +kernel
private theorem cases2721 : checkFour 2721 (688,4784,679,4775) = true := by
  simp only [checkFour, w2721_0,w2721_1,w2721_2,w2721_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2721 : Coverage 2721 2722 := checkList_sound (ws:=[(688,4784,679,4775)]) (by simpa only [checkList, Bool.and_true] using cases2721)
private theorem w2722_0 : checkWitness 2722 false false 208 = true := by decide +kernel
private theorem w2722_2 : checkWitness 2722 true false 208 = true := by decide +kernel
private theorem cases2722 : checkFour 2722 (208,0,208,0) = true := by
  simp only [checkFour, w2722_0,w2722_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2722 : Coverage 2722 2723 := checkList_sound (ws:=[(208,0,208,0)]) (by simpa only [checkList, Bool.and_true] using cases2722)
private theorem w2723_0 : checkWitness 2723 false false 643 = true := by decide +kernel
private theorem w2723_1 : checkWitness 2723 false true 4731 = true := by decide +kernel
private theorem w2723_2 : checkWitness 2723 true false 643 = true := by decide +kernel
private theorem w2723_3 : checkWitness 2723 true true 4731 = true := by decide +kernel
private theorem cases2723 : checkFour 2723 (643,4731,643,4731) = true := by
  simp only [checkFour, w2723_0,w2723_1,w2723_2,w2723_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2723 : Coverage 2723 2724 := checkList_sound (ws:=[(643,4731,643,4731)]) (by simpa only [checkList, Bool.and_true] using cases2723)
private theorem w2724_0 : checkWitness 2724 false false 8972 = true := by decide +kernel
private theorem w2724_2 : checkWitness 2724 true false 8963 = true := by decide +kernel
private theorem cases2724 : checkFour 2724 (8972,0,8963,0) = true := by
  simp only [checkFour, w2724_0,w2724_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2724 : Coverage 2724 2725 := checkList_sound (ws:=[(8972,0,8963,0)]) (by simpa only [checkList, Bool.and_true] using cases2724)
private theorem w2725_0 : checkWitness 2725 false false 60 = true := by decide +kernel
private theorem w2725_2 : checkWitness 2725 true false 60 = true := by decide +kernel
private theorem cases2725 : checkFour 2725 (60,0,60,0) = true := by
  simp only [checkFour, w2725_0,w2725_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2725 : Coverage 2725 2726 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2725)
private theorem w2726_0 : checkWitness 2726 false false 52 = true := by decide +kernel
private theorem w2726_2 : checkWitness 2726 true false 52 = true := by decide +kernel
private theorem cases2726 : checkFour 2726 (52,0,52,0) = true := by
  simp only [checkFour, w2726_0,w2726_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2726 : Coverage 2726 2727 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2726)
private theorem w2727_0 : checkWitness 2727 false false 649 = true := by decide +kernel
private theorem w2727_1 : checkWitness 2727 false true 4741 = true := by decide +kernel
private theorem w2727_2 : checkWitness 2727 true false 649 = true := by decide +kernel
private theorem w2727_3 : checkWitness 2727 true true 4741 = true := by decide +kernel
private theorem cases2727 : checkFour 2727 (649,4741,649,4741) = true := by
  simp only [checkFour, w2727_0,w2727_1,w2727_2,w2727_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2727 : Coverage 2727 2728 := checkList_sound (ws:=[(649,4741,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases2727)
private theorem w2728_0 : checkWitness 2728 false false 8910 = true := by decide +kernel
private theorem w2728_2 : checkWitness 2728 true false 8906 = true := by decide +kernel
private theorem cases2728 : checkFour 2728 (8910,0,8906,0) = true := by
  simp only [checkFour, w2728_0,w2728_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2728 : Coverage 2728 2729 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2728)
private theorem w2729_0 : checkWitness 2729 false false 52 = true := by decide +kernel
private theorem w2729_2 : checkWitness 2729 true false 52 = true := by decide +kernel
private theorem cases2729 : checkFour 2729 (52,0,52,0) = true := by
  simp only [checkFour, w2729_0,w2729_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2729 : Coverage 2729 2730 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2729)
private theorem w2730_0 : checkWitness 2730 false false 604 = true := by decide +kernel
private theorem w2730_1 : checkWitness 2730 false true 4700 = true := by decide +kernel
private theorem w2730_2 : checkWitness 2730 true false 604 = true := by decide +kernel
private theorem w2730_3 : checkWitness 2730 true true 4700 = true := by decide +kernel
private theorem cases2730 : checkFour 2730 (604,4700,604,4700) = true := by
  simp only [checkFour, w2730_0,w2730_1,w2730_2,w2730_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2730 : Coverage 2730 2731 := checkList_sound (ws:=[(604,4700,604,4700)]) (by simpa only [checkList, Bool.and_true] using cases2730)
private theorem w2731_0 : checkWitness 2731 false false 8945 = true := by decide +kernel
private theorem w2731_2 : checkWitness 2731 true false 8941 = true := by decide +kernel
private theorem cases2731 : checkFour 2731 (8945,0,8941,0) = true := by
  simp only [checkFour, w2731_0,w2731_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2731 : Coverage 2731 2732 := checkList_sound (ws:=[(8945,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2731)
private theorem w2732_0 : checkWitness 2732 false false 8980 = true := by decide +kernel
private theorem w2732_2 : checkWitness 2732 true false 8971 = true := by decide +kernel
private theorem cases2732 : checkFour 2732 (8980,0,8971,0) = true := by
  simp only [checkFour, w2732_0,w2732_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2732 : Coverage 2732 2733 := checkList_sound (ws:=[(8980,0,8971,0)]) (by simpa only [checkList, Bool.and_true] using cases2732)
private theorem w2733_0 : checkWitness 2733 false false 70 = true := by decide +kernel
private theorem w2733_2 : checkWitness 2733 true false 70 = true := by decide +kernel
private theorem cases2733 : checkFour 2733 (70,0,70,0) = true := by
  simp only [checkFour, w2733_0,w2733_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2733 : Coverage 2733 2734 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2733)
private theorem w2734_0 : checkWitness 2734 false false 692 = true := by decide +kernel
private theorem w2734_1 : checkWitness 2734 false true 4784 = true := by decide +kernel
private theorem w2734_2 : checkWitness 2734 true false 683 = true := by decide +kernel
private theorem w2734_3 : checkWitness 2734 true true 4775 = true := by decide +kernel
private theorem cases2734 : checkFour 2734 (692,4784,683,4775) = true := by
  simp only [checkFour, w2734_0,w2734_1,w2734_2,w2734_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2734 : Coverage 2734 2735 := checkList_sound (ws:=[(692,4784,683,4775)]) (by simpa only [checkList, Bool.and_true] using cases2734)
private theorem w2735_0 : checkWitness 2735 false false 8941 = true := by decide +kernel
private theorem w2735_2 : checkWitness 2735 true false 8937 = true := by decide +kernel
private theorem cases2735 : checkFour 2735 (8941,0,8937,0) = true := by
  simp only [checkFour, w2735_0,w2735_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2735 : Coverage 2735 2736 := checkList_sound (ws:=[(8941,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases2735)
private theorem w2736_0 : checkWitness 2736 false false 686 = true := by decide +kernel
private theorem w2736_1 : checkWitness 2736 false true 4778 = true := by decide +kernel
private theorem w2736_2 : checkWitness 2736 true false 677 = true := by decide +kernel
private theorem w2736_3 : checkWitness 2736 true true 4769 = true := by decide +kernel
private theorem cases2736 : checkFour 2736 (686,4778,677,4769) = true := by
  simp only [checkFour, w2736_0,w2736_1,w2736_2,w2736_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2736 : Coverage 2736 2737 := checkList_sound (ws:=[(686,4778,677,4769)]) (by simpa only [checkList, Bool.and_true] using cases2736)
private theorem w2737_0 : checkWitness 2737 false false 8910 = true := by decide +kernel
private theorem w2737_2 : checkWitness 2737 true false 8906 = true := by decide +kernel
private theorem cases2737 : checkFour 2737 (8910,0,8906,0) = true := by
  simp only [checkFour, w2737_0,w2737_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2737 : Coverage 2737 2738 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2737)
private theorem w2738_0 : checkWitness 2738 false false 58 = true := by decide +kernel
private theorem w2738_2 : checkWitness 2738 true false 58 = true := by decide +kernel
private theorem cases2738 : checkFour 2738 (58,0,58,0) = true := by
  simp only [checkFour, w2738_0,w2738_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2738 : Coverage 2738 2739 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2738)
private theorem w2739_0 : checkWitness 2739 false false 50 = true := by decide +kernel
private theorem w2739_2 : checkWitness 2739 true false 50 = true := by decide +kernel
private theorem cases2739 : checkFour 2739 (50,0,50,0) = true := by
  simp only [checkFour, w2739_0,w2739_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2739 : Coverage 2739 2740 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2739)
private theorem w2740_0 : checkWitness 2740 false false 653 = true := by decide +kernel
private theorem w2740_1 : checkWitness 2740 false true 4741 = true := by decide +kernel
private theorem w2740_2 : checkWitness 2740 true false 653 = true := by decide +kernel
private theorem w2740_3 : checkWitness 2740 true true 4741 = true := by decide +kernel
private theorem cases2740 : checkFour 2740 (653,4741,653,4741) = true := by
  simp only [checkFour, w2740_0,w2740_1,w2740_2,w2740_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2740 : Coverage 2740 2741 := checkList_sound (ws:=[(653,4741,653,4741)]) (by simpa only [checkList, Bool.and_true] using cases2740)
private theorem w2741_0 : checkWitness 2741 false false 8926 = true := by decide +kernel
private theorem w2741_2 : checkWitness 2741 true false 8922 = true := by decide +kernel
private theorem cases2741 : checkFour 2741 (8926,0,8922,0) = true := by
  simp only [checkFour, w2741_0,w2741_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2741 : Coverage 2741 2742 := checkList_sound (ws:=[(8926,0,8922,0)]) (by simpa only [checkList, Bool.and_true] using cases2741)
private theorem w2742_0 : checkWitness 2742 false false 8922 = true := by decide +kernel
private theorem w2742_2 : checkWitness 2742 true false 8918 = true := by decide +kernel
private theorem cases2742 : checkFour 2742 (8922,0,8918,0) = true := by
  simp only [checkFour, w2742_0,w2742_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2742 : Coverage 2742 2743 := checkList_sound (ws:=[(8922,0,8918,0)]) (by simpa only [checkList, Bool.and_true] using cases2742)
private theorem w2743_0 : checkWitness 2743 false false 64 = true := by decide +kernel
private theorem w2743_2 : checkWitness 2743 true false 64 = true := by decide +kernel
private theorem cases2743 : checkFour 2743 (64,0,64,0) = true := by
  simp only [checkFour, w2743_0,w2743_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2743 : Coverage 2743 2744 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2743)
private theorem w2744_0 : checkWitness 2744 false false 8934 = true := by decide +kernel
private theorem w2744_2 : checkWitness 2744 true false 8930 = true := by decide +kernel
private theorem cases2744 : checkFour 2744 (8934,0,8930,0) = true := by
  simp only [checkFour, w2744_0,w2744_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2744 : Coverage 2744 2745 := checkList_sound (ws:=[(8934,0,8930,0)]) (by simpa only [checkList, Bool.and_true] using cases2744)
private theorem w2745_0 : checkWitness 2745 false false 718 = true := by decide +kernel
private theorem w2745_1 : checkWitness 2745 false true 4814 = true := by decide +kernel
private theorem w2745_2 : checkWitness 2745 true false 718 = true := by decide +kernel
private theorem w2745_3 : checkWitness 2745 true true 4814 = true := by decide +kernel
private theorem cases2745 : checkFour 2745 (718,4814,718,4814) = true := by
  simp only [checkFour, w2745_0,w2745_1,w2745_2,w2745_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2745 : Coverage 2745 2746 := checkList_sound (ws:=[(718,4814,718,4814)]) (by simpa only [checkList, Bool.and_true] using cases2745)
private theorem w2746_0 : checkWitness 2746 false false 8996 = true := by decide +kernel
private theorem w2746_2 : checkWitness 2746 true false 8987 = true := by decide +kernel
private theorem cases2746 : checkFour 2746 (8996,0,8987,0) = true := by
  simp only [checkFour, w2746_0,w2746_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2746 : Coverage 2746 2747 := checkList_sound (ws:=[(8996,0,8987,0)]) (by simpa only [checkList, Bool.and_true] using cases2746)
private theorem w2747_0 : checkWitness 2747 false false 58 = true := by decide +kernel
private theorem w2747_2 : checkWitness 2747 true false 58 = true := by decide +kernel
private theorem cases2747 : checkFour 2747 (58,0,58,0) = true := by
  simp only [checkFour, w2747_0,w2747_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2747 : Coverage 2747 2748 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2747)
private theorem w2748_0 : checkWitness 2748 false false 578 = true := by decide +kernel
private theorem w2748_1 : checkWitness 2748 false true 4674 = true := by decide +kernel
private theorem w2748_2 : checkWitness 2748 true false 578 = true := by decide +kernel
private theorem w2748_3 : checkWitness 2748 true true 4674 = true := by decide +kernel
private theorem cases2748 : checkFour 2748 (578,4674,578,4674) = true := by
  simp only [checkFour, w2748_0,w2748_1,w2748_2,w2748_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2748 : Coverage 2748 2749 := checkList_sound (ws:=[(578,4674,578,4674)]) (by simpa only [checkList, Bool.and_true] using cases2748)
private theorem w2749_0 : checkWitness 2749 false false 8936 = true := by decide +kernel
private theorem w2749_2 : checkWitness 2749 true false 8932 = true := by decide +kernel
private theorem cases2749 : checkFour 2749 (8936,0,8932,0) = true := by
  simp only [checkFour, w2749_0,w2749_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2749 : Coverage 2749 2750 := checkList_sound (ws:=[(8936,0,8932,0)]) (by simpa only [checkList, Bool.and_true] using cases2749)
private theorem w2750_0 : checkWitness 2750 false false 60 = true := by decide +kernel
private theorem w2750_2 : checkWitness 2750 true false 60 = true := by decide +kernel
private theorem cases2750 : checkFour 2750 (60,0,60,0) = true := by
  simp only [checkFour, w2750_0,w2750_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2750 : Coverage 2750 2751 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2750)
private theorem w2751_0 : checkWitness 2751 false false 616 = true := by decide +kernel
private theorem w2751_1 : checkWitness 2751 false true 4712 = true := by decide +kernel
private theorem w2751_2 : checkWitness 2751 true false 616 = true := by decide +kernel
private theorem w2751_3 : checkWitness 2751 true true 4712 = true := by decide +kernel
private theorem cases2751 : checkFour 2751 (616,4712,616,4712) = true := by
  simp only [checkFour, w2751_0,w2751_1,w2751_2,w2751_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2751 : Coverage 2751 2752 := checkList_sound (ws:=[(616,4712,616,4712)]) (by simpa only [checkList, Bool.and_true] using cases2751)
theorem cover2720 : Coverage 2720 2752 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2720 one2721) (Coverage.join one2722 one2723)) (Coverage.join (Coverage.join one2724 one2725) (Coverage.join one2726 one2727))) (Coverage.join (Coverage.join (Coverage.join one2728 one2729) (Coverage.join one2730 one2731)) (Coverage.join (Coverage.join one2732 one2733) (Coverage.join one2734 one2735)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2736 one2737) (Coverage.join one2738 one2739)) (Coverage.join (Coverage.join one2740 one2741) (Coverage.join one2742 one2743))) (Coverage.join (Coverage.join (Coverage.join one2744 one2745) (Coverage.join one2746 one2747)) (Coverage.join (Coverage.join one2748 one2749) (Coverage.join one2750 one2751)))))
end NF180PA.Symbolic
