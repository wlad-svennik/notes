import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1856_0 : checkWitness 1856 false false 597 = true := by decide +kernel
private theorem w1856_1 : checkWitness 1856 false true 4689 = true := by decide +kernel
private theorem w1856_2 : checkWitness 1856 true false 597 = true := by decide +kernel
private theorem w1856_3 : checkWitness 1856 true true 4689 = true := by decide +kernel
private theorem cases1856 : checkFour 1856 (597,4689,597,4689) = true := by
  simp only [checkFour, w1856_0,w1856_1,w1856_2,w1856_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1856 : Coverage 1856 1857 := checkList_sound (ws:=[(597,4689,597,4689)]) (by simpa only [checkList, Bool.and_true] using cases1856)
private theorem w1857_0 : checkWitness 1857 false false 8858 = true := by decide +kernel
private theorem w1857_2 : checkWitness 1857 true false 8854 = true := by decide +kernel
private theorem cases1857 : checkFour 1857 (8858,0,8854,0) = true := by
  simp only [checkFour, w1857_0,w1857_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1857 : Coverage 1857 1858 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1857)
private theorem w1858_0 : checkWitness 1858 false false 78 = true := by decide +kernel
private theorem w1858_2 : checkWitness 1858 true false 78 = true := by decide +kernel
private theorem cases1858 : checkFour 1858 (78,0,78,0) = true := by
  simp only [checkFour, w1858_0,w1858_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1858 : Coverage 1858 1859 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1858)
private theorem w1859_0 : checkWitness 1859 false false 552 = true := by decide +kernel
private theorem w1859_1 : checkWitness 1859 false true 4648 = true := by decide +kernel
private theorem w1859_2 : checkWitness 1859 true false 552 = true := by decide +kernel
private theorem w1859_3 : checkWitness 1859 true true 4648 = true := by decide +kernel
private theorem cases1859 : checkFour 1859 (552,4648,552,4648) = true := by
  simp only [checkFour, w1859_0,w1859_1,w1859_2,w1859_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1859 : Coverage 1859 1860 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases1859)
private theorem w1860_0 : checkWitness 1860 false false 8893 = true := by decide +kernel
private theorem w1860_2 : checkWitness 1860 true false 8889 = true := by decide +kernel
private theorem cases1860 : checkFour 1860 (8893,0,8889,0) = true := by
  simp only [checkFour, w1860_0,w1860_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1860 : Coverage 1860 1861 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1860)
private theorem w1861_0 : checkWitness 1861 false false 8928 = true := by decide +kernel
private theorem w1861_2 : checkWitness 1861 true false 8919 = true := by decide +kernel
private theorem cases1861 : checkFour 1861 (8928,0,8919,0) = true := by
  simp only [checkFour, w1861_0,w1861_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1861 : Coverage 1861 1862 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases1861)
private theorem w1862_0 : checkWitness 1862 false false 96 = true := by decide +kernel
private theorem w1862_2 : checkWitness 1862 true false 96 = true := by decide +kernel
private theorem cases1862 : checkFour 1862 (96,0,96,0) = true := by
  simp only [checkFour, w1862_0,w1862_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1862 : Coverage 1862 1863 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1862)
private theorem w1863_0 : checkWitness 1863 false false 640 = true := by decide +kernel
private theorem w1863_1 : checkWitness 1863 false true 4732 = true := by decide +kernel
private theorem w1863_2 : checkWitness 1863 true false 631 = true := by decide +kernel
private theorem w1863_3 : checkWitness 1863 true true 4723 = true := by decide +kernel
private theorem cases1863 : checkFour 1863 (640,4732,631,4723) = true := by
  simp only [checkFour, w1863_0,w1863_1,w1863_2,w1863_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1863 : Coverage 1863 1864 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases1863)
private theorem w1864_0 : checkWitness 1864 false false 8889 = true := by decide +kernel
private theorem w1864_2 : checkWitness 1864 true false 8885 = true := by decide +kernel
private theorem cases1864 : checkFour 1864 (8889,0,8885,0) = true := by
  simp only [checkFour, w1864_0,w1864_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1864 : Coverage 1864 1865 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1864)
private theorem w1865_0 : checkWitness 1865 false false 634 = true := by decide +kernel
private theorem w1865_1 : checkWitness 1865 false true 4726 = true := by decide +kernel
private theorem w1865_2 : checkWitness 1865 true false 625 = true := by decide +kernel
private theorem w1865_3 : checkWitness 1865 true true 4717 = true := by decide +kernel
private theorem cases1865 : checkFour 1865 (634,4726,625,4717) = true := by
  simp only [checkFour, w1865_0,w1865_1,w1865_2,w1865_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1865 : Coverage 1865 1866 := checkList_sound (ws:=[(634,4726,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases1865)
private theorem w1866_0 : checkWitness 1866 false false 8858 = true := by decide +kernel
private theorem w1866_2 : checkWitness 1866 true false 8854 = true := by decide +kernel
private theorem cases1866 : checkFour 1866 (8858,0,8854,0) = true := by
  simp only [checkFour, w1866_0,w1866_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1866 : Coverage 1866 1867 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1866)
private theorem w1867_0 : checkWitness 1867 false false 84 = true := by decide +kernel
private theorem w1867_2 : checkWitness 1867 true false 84 = true := by decide +kernel
private theorem cases1867 : checkFour 1867 (84,0,84,0) = true := by
  simp only [checkFour, w1867_0,w1867_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1867 : Coverage 1867 1868 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1867)
private theorem w1868_0 : checkWitness 1868 false false 76 = true := by decide +kernel
private theorem w1868_2 : checkWitness 1868 true false 76 = true := by decide +kernel
private theorem cases1868 : checkFour 1868 (76,0,76,0) = true := by
  simp only [checkFour, w1868_0,w1868_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1868 : Coverage 1868 1869 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1868)
private theorem w1869_0 : checkWitness 1869 false false 621 = true := by decide +kernel
private theorem w1869_1 : checkWitness 1869 false true 4689 = true := by decide +kernel
private theorem w1869_2 : checkWitness 1869 true false 621 = true := by decide +kernel
private theorem w1869_3 : checkWitness 1869 true true 4689 = true := by decide +kernel
private theorem cases1869 : checkFour 1869 (621,4689,621,4689) = true := by
  simp only [checkFour, w1869_0,w1869_1,w1869_2,w1869_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1869 : Coverage 1869 1870 := checkList_sound (ws:=[(621,4689,621,4689)]) (by simpa only [checkList, Bool.and_true] using cases1869)
private theorem w1870_0 : checkWitness 1870 false false 8874 = true := by decide +kernel
private theorem w1870_2 : checkWitness 1870 true false 8870 = true := by decide +kernel
private theorem cases1870 : checkFour 1870 (8874,0,8870,0) = true := by
  simp only [checkFour, w1870_0,w1870_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1870 : Coverage 1870 1871 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases1870)
private theorem w1871_0 : checkWitness 1871 false false 8870 = true := by decide +kernel
private theorem w1871_2 : checkWitness 1871 true false 8866 = true := by decide +kernel
private theorem cases1871 : checkFour 1871 (8870,0,8866,0) = true := by
  simp only [checkFour, w1871_0,w1871_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1871 : Coverage 1871 1872 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases1871)
private theorem w1872_0 : checkWitness 1872 false false 90 = true := by decide +kernel
private theorem w1872_2 : checkWitness 1872 true false 90 = true := by decide +kernel
private theorem cases1872 : checkFour 1872 (90,0,90,0) = true := by
  simp only [checkFour, w1872_0,w1872_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1872 : Coverage 1872 1873 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1872)
private theorem w1873_0 : checkWitness 1873 false false 716 = true := by decide +kernel
private theorem w1873_1 : checkWitness 1873 false true 4812 = true := by decide +kernel
private theorem w1873_2 : checkWitness 1873 true false 716 = true := by decide +kernel
private theorem w1873_3 : checkWitness 1873 true true 4812 = true := by decide +kernel
private theorem cases1873 : checkFour 1873 (716,4812,716,4812) = true := by
  simp only [checkFour, w1873_0,w1873_1,w1873_2,w1873_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1873 : Coverage 1873 1874 := checkList_sound (ws:=[(716,4812,716,4812)]) (by simpa only [checkList, Bool.and_true] using cases1873)
private theorem w1874_0 : checkWitness 1874 false false 8972 = true := by decide +kernel
private theorem w1874_2 : checkWitness 1874 true false 8963 = true := by decide +kernel
private theorem cases1874 : checkFour 1874 (8972,0,8963,0) = true := by
  simp only [checkFour, w1874_0,w1874_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1874 : Coverage 1874 1875 := checkList_sound (ws:=[(8972,0,8963,0)]) (by simpa only [checkList, Bool.and_true] using cases1874)
private theorem w1875_0 : checkWitness 1875 false false 80 = true := by decide +kernel
private theorem w1875_2 : checkWitness 1875 true false 80 = true := by decide +kernel
private theorem cases1875 : checkFour 1875 (80,0,80,0) = true := by
  simp only [checkFour, w1875_0,w1875_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1875 : Coverage 1875 1876 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1875)
private theorem w1876_0 : checkWitness 1876 false false 554 = true := by decide +kernel
private theorem w1876_1 : checkWitness 1876 false true 4650 = true := by decide +kernel
private theorem w1876_2 : checkWitness 1876 true false 554 = true := by decide +kernel
private theorem w1876_3 : checkWitness 1876 true true 4650 = true := by decide +kernel
private theorem cases1876 : checkFour 1876 (554,4650,554,4650) = true := by
  simp only [checkFour, w1876_0,w1876_1,w1876_2,w1876_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1876 : Coverage 1876 1877 := checkList_sound (ws:=[(554,4650,554,4650)]) (by simpa only [checkList, Bool.and_true] using cases1876)
private theorem w1877_0 : checkWitness 1877 false false 8912 = true := by decide +kernel
private theorem w1877_2 : checkWitness 1877 true false 8908 = true := by decide +kernel
private theorem cases1877 : checkFour 1877 (8912,0,8908,0) = true := by
  simp only [checkFour, w1877_0,w1877_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1877 : Coverage 1877 1878 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases1877)
private theorem w1878_0 : checkWitness 1878 false false 82 = true := by decide +kernel
private theorem w1878_2 : checkWitness 1878 true false 82 = true := by decide +kernel
private theorem cases1878 : checkFour 1878 (82,0,82,0) = true := by
  simp only [checkFour, w1878_0,w1878_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1878 : Coverage 1878 1879 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1878)
private theorem w1879_0 : checkWitness 1879 false false 592 = true := by decide +kernel
private theorem w1879_1 : checkWitness 1879 false true 4688 = true := by decide +kernel
private theorem w1879_2 : checkWitness 1879 true false 592 = true := by decide +kernel
private theorem w1879_3 : checkWitness 1879 true true 4688 = true := by decide +kernel
private theorem cases1879 : checkFour 1879 (592,4688,592,4688) = true := by
  simp only [checkFour, w1879_0,w1879_1,w1879_2,w1879_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1879 : Coverage 1879 1880 := checkList_sound (ws:=[(592,4688,592,4688)]) (by simpa only [checkList, Bool.and_true] using cases1879)
private theorem w1880_0 : checkWitness 1880 false false 8933 = true := by decide +kernel
private theorem w1880_2 : checkWitness 1880 true false 8929 = true := by decide +kernel
private theorem cases1880 : checkFour 1880 (8933,0,8929,0) = true := by
  simp only [checkFour, w1880_0,w1880_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1880 : Coverage 1880 1881 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases1880)
private theorem w1881_0 : checkWitness 1881 false false 8968 = true := by decide +kernel
private theorem w1881_2 : checkWitness 1881 true false 8959 = true := by decide +kernel
private theorem cases1881 : checkFour 1881 (8968,0,8959,0) = true := by
  simp only [checkFour, w1881_0,w1881_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1881 : Coverage 1881 1882 := checkList_sound (ws:=[(8968,0,8959,0)]) (by simpa only [checkList, Bool.and_true] using cases1881)
private theorem w1882_0 : checkWitness 1882 false false 106 = true := by decide +kernel
private theorem w1882_2 : checkWitness 1882 true false 106 = true := by decide +kernel
private theorem cases1882 : checkFour 1882 (106,0,106,0) = true := by
  simp only [checkFour, w1882_0,w1882_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1882 : Coverage 1882 1883 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1882)
private theorem w1883_0 : checkWitness 1883 false false 680 = true := by decide +kernel
private theorem w1883_1 : checkWitness 1883 false true 4772 = true := by decide +kernel
private theorem w1883_2 : checkWitness 1883 true false 671 = true := by decide +kernel
private theorem w1883_3 : checkWitness 1883 true true 4763 = true := by decide +kernel
private theorem cases1883 : checkFour 1883 (680,4772,671,4763) = true := by
  simp only [checkFour, w1883_0,w1883_1,w1883_2,w1883_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1883 : Coverage 1883 1884 := checkList_sound (ws:=[(680,4772,671,4763)]) (by simpa only [checkList, Bool.and_true] using cases1883)
private theorem w1884_0 : checkWitness 1884 false false 8929 = true := by decide +kernel
private theorem w1884_2 : checkWitness 1884 true false 8925 = true := by decide +kernel
private theorem cases1884 : checkFour 1884 (8929,0,8925,0) = true := by
  simp only [checkFour, w1884_0,w1884_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1884 : Coverage 1884 1885 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases1884)
private theorem w1885_0 : checkWitness 1885 false false 674 = true := by decide +kernel
private theorem w1885_1 : checkWitness 1885 false true 4766 = true := by decide +kernel
private theorem w1885_2 : checkWitness 1885 true false 665 = true := by decide +kernel
private theorem w1885_3 : checkWitness 1885 true true 4757 = true := by decide +kernel
private theorem cases1885 : checkFour 1885 (674,4766,665,4757) = true := by
  simp only [checkFour, w1885_0,w1885_1,w1885_2,w1885_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1885 : Coverage 1885 1886 := checkList_sound (ws:=[(674,4766,665,4757)]) (by simpa only [checkList, Bool.and_true] using cases1885)
private theorem w1886_0 : checkWitness 1886 false false 8898 = true := by decide +kernel
private theorem w1886_2 : checkWitness 1886 true false 8894 = true := by decide +kernel
private theorem cases1886 : checkFour 1886 (8898,0,8894,0) = true := by
  simp only [checkFour, w1886_0,w1886_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1886 : Coverage 1886 1887 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases1886)
private theorem w1887_0 : checkWitness 1887 false false 94 = true := by decide +kernel
private theorem w1887_2 : checkWitness 1887 true false 94 = true := by decide +kernel
private theorem cases1887 : checkFour 1887 (94,0,94,0) = true := by
  simp only [checkFour, w1887_0,w1887_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1887 : Coverage 1887 1888 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1887)
theorem cover1856 : Coverage 1856 1888 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1856 one1857) (Coverage.join one1858 one1859)) (Coverage.join (Coverage.join one1860 one1861) (Coverage.join one1862 one1863))) (Coverage.join (Coverage.join (Coverage.join one1864 one1865) (Coverage.join one1866 one1867)) (Coverage.join (Coverage.join one1868 one1869) (Coverage.join one1870 one1871)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1872 one1873) (Coverage.join one1874 one1875)) (Coverage.join (Coverage.join one1876 one1877) (Coverage.join one1878 one1879))) (Coverage.join (Coverage.join (Coverage.join one1880 one1881) (Coverage.join one1882 one1883)) (Coverage.join (Coverage.join one1884 one1885) (Coverage.join one1886 one1887)))))
end NF180PA.Symbolic
