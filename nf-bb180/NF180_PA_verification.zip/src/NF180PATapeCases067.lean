import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2144_0 : checkWitness 2144 false false 8931 = true := by decide +kernel
private theorem w2144_2 : checkWitness 2144 true false 8922 = true := by decide +kernel
private theorem cases2144 : checkFour 2144 (8931,0,8922,0) = true := by
  simp only [checkFour, w2144_0,w2144_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2144 : Coverage 2144 2145 := checkList_sound (ws:=[(8931,0,8922,0)]) (by simpa only [checkList, Bool.and_true] using cases2144)
private theorem w2145_0 : checkWitness 2145 false false 64 = true := by decide +kernel
private theorem w2145_2 : checkWitness 2145 true false 64 = true := by decide +kernel
private theorem cases2145 : checkFour 2145 (64,0,64,0) = true := by
  simp only [checkFour, w2145_0,w2145_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2145 : Coverage 2145 2146 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2145)
private theorem w2146_0 : checkWitness 2146 false false 704 = true := by decide +kernel
private theorem w2146_1 : checkWitness 2146 false true 4800 = true := by decide +kernel
private theorem w2146_2 : checkWitness 2146 true false 704 = true := by decide +kernel
private theorem w2146_3 : checkWitness 2146 true true 4800 = true := by decide +kernel
private theorem cases2146 : checkFour 2146 (704,4800,704,4800) = true := by
  simp only [checkFour, w2146_0,w2146_1,w2146_2,w2146_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2146 : Coverage 2146 2147 := checkList_sound (ws:=[(704,4800,704,4800)]) (by simpa only [checkList, Bool.and_true] using cases2146)
private theorem w2147_0 : checkWitness 2147 false false 8958 = true := by decide +kernel
private theorem w2147_2 : checkWitness 2147 true false 8949 = true := by decide +kernel
private theorem cases2147 : checkFour 2147 (8958,0,8949,0) = true := by
  simp only [checkFour, w2147_0,w2147_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2147 : Coverage 2147 2148 := checkList_sound (ws:=[(8958,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases2147)
private theorem w2148_0 : checkWitness 2148 false false 82 = true := by decide +kernel
private theorem w2148_2 : checkWitness 2148 true false 82 = true := by decide +kernel
private theorem cases2148 : checkFour 2148 (82,0,82,0) = true := by
  simp only [checkFour, w2148_0,w2148_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2148 : Coverage 2148 2149 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2148)
private theorem w2149_0 : checkWitness 2149 false false 540 = true := by decide +kernel
private theorem w2149_1 : checkWitness 2149 false true 4636 = true := by decide +kernel
private theorem w2149_2 : checkWitness 2149 true false 540 = true := by decide +kernel
private theorem w2149_3 : checkWitness 2149 true true 4636 = true := by decide +kernel
private theorem cases2149 : checkFour 2149 (540,4636,540,4636) = true := by
  simp only [checkFour, w2149_0,w2149_1,w2149_2,w2149_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2149 : Coverage 2149 2150 := checkList_sound (ws:=[(540,4636,540,4636)]) (by simpa only [checkList, Bool.and_true] using cases2149)
private theorem w2150_0 : checkWitness 2150 false false 8898 = true := by decide +kernel
private theorem w2150_2 : checkWitness 2150 true false 8894 = true := by decide +kernel
private theorem cases2150 : checkFour 2150 (8898,0,8894,0) = true := by
  simp only [checkFour, w2150_0,w2150_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2150 : Coverage 2150 2151 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2150)
private theorem w2151_0 : checkWitness 2151 false false 84 = true := by decide +kernel
private theorem w2151_2 : checkWitness 2151 true false 84 = true := by decide +kernel
private theorem cases2151 : checkFour 2151 (84,0,84,0) = true := by
  simp only [checkFour, w2151_0,w2151_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2151 : Coverage 2151 2152 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2151)
private theorem w2152_0 : checkWitness 2152 false false 578 = true := by decide +kernel
private theorem w2152_1 : checkWitness 2152 false true 4674 = true := by decide +kernel
private theorem w2152_2 : checkWitness 2152 true false 578 = true := by decide +kernel
private theorem w2152_3 : checkWitness 2152 true true 4674 = true := by decide +kernel
private theorem cases2152 : checkFour 2152 (578,4674,578,4674) = true := by
  simp only [checkFour, w2152_0,w2152_1,w2152_2,w2152_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2152 : Coverage 2152 2153 := checkList_sound (ws:=[(578,4674,578,4674)]) (by simpa only [checkList, Bool.and_true] using cases2152)
private theorem w2153_0 : checkWitness 2153 false false 8919 = true := by decide +kernel
private theorem w2153_2 : checkWitness 2153 true false 8915 = true := by decide +kernel
private theorem cases2153 : checkFour 2153 (8919,0,8915,0) = true := by
  simp only [checkFour, w2153_0,w2153_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2153 : Coverage 2153 2154 := checkList_sound (ws:=[(8919,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases2153)
private theorem w2154_0 : checkWitness 2154 false false 8954 = true := by decide +kernel
private theorem w2154_2 : checkWitness 2154 true false 8945 = true := by decide +kernel
private theorem cases2154 : checkFour 2154 (8954,0,8945,0) = true := by
  simp only [checkFour, w2154_0,w2154_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2154 : Coverage 2154 2155 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2154)
private theorem w2155_0 : checkWitness 2155 false false 108 = true := by decide +kernel
private theorem w2155_2 : checkWitness 2155 true false 108 = true := by decide +kernel
private theorem cases2155 : checkFour 2155 (108,0,108,0) = true := by
  simp only [checkFour, w2155_0,w2155_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2155 : Coverage 2155 2156 := checkList_sound (ws:=[(108,0,108,0)]) (by simpa only [checkList, Bool.and_true] using cases2155)
private theorem w2156_0 : checkWitness 2156 false false 666 = true := by decide +kernel
private theorem w2156_1 : checkWitness 2156 false true 4758 = true := by decide +kernel
private theorem w2156_2 : checkWitness 2156 true false 657 = true := by decide +kernel
private theorem w2156_3 : checkWitness 2156 true true 4749 = true := by decide +kernel
private theorem cases2156 : checkFour 2156 (666,4758,657,4749) = true := by
  simp only [checkFour, w2156_0,w2156_1,w2156_2,w2156_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2156 : Coverage 2156 2157 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases2156)
private theorem w2157_0 : checkWitness 2157 false false 8915 = true := by decide +kernel
private theorem w2157_2 : checkWitness 2157 true false 8911 = true := by decide +kernel
private theorem cases2157 : checkFour 2157 (8915,0,8911,0) = true := by
  simp only [checkFour, w2157_0,w2157_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2157 : Coverage 2157 2158 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2157)
private theorem w2158_0 : checkWitness 2158 false false 660 = true := by decide +kernel
private theorem w2158_1 : checkWitness 2158 false true 4752 = true := by decide +kernel
private theorem w2158_2 : checkWitness 2158 true false 651 = true := by decide +kernel
private theorem w2158_3 : checkWitness 2158 true true 4743 = true := by decide +kernel
private theorem cases2158 : checkFour 2158 (660,4752,651,4743) = true := by
  simp only [checkFour, w2158_0,w2158_1,w2158_2,w2158_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2158 : Coverage 2158 2159 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases2158)
private theorem w2159_0 : checkWitness 2159 false false 8884 = true := by decide +kernel
private theorem w2159_2 : checkWitness 2159 true false 8880 = true := by decide +kernel
private theorem cases2159 : checkFour 2159 (8884,0,8880,0) = true := by
  simp only [checkFour, w2159_0,w2159_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2159 : Coverage 2159 2160 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases2159)
private theorem w2160_0 : checkWitness 2160 false false 96 = true := by decide +kernel
private theorem w2160_2 : checkWitness 2160 true false 96 = true := by decide +kernel
private theorem cases2160 : checkFour 2160 (96,0,96,0) = true := by
  simp only [checkFour, w2160_0,w2160_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2160 : Coverage 2160 2161 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases2160)
private theorem w2161_0 : checkWitness 2161 false false 88 = true := by decide +kernel
private theorem w2161_2 : checkWitness 2161 true false 88 = true := by decide +kernel
private theorem cases2161 : checkFour 2161 (88,0,88,0) = true := by
  simp only [checkFour, w2161_0,w2161_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2161 : Coverage 2161 2162 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases2161)
private theorem w2162_0 : checkWitness 2162 false false 625 = true := by decide +kernel
private theorem w2162_1 : checkWitness 2162 false true 4709 = true := by decide +kernel
private theorem w2162_2 : checkWitness 2162 true false 625 = true := by decide +kernel
private theorem w2162_3 : checkWitness 2162 true true 4709 = true := by decide +kernel
private theorem cases2162 : checkFour 2162 (625,4709,625,4709) = true := by
  simp only [checkFour, w2162_0,w2162_1,w2162_2,w2162_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2162 : Coverage 2162 2163 := checkList_sound (ws:=[(625,4709,625,4709)]) (by simpa only [checkList, Bool.and_true] using cases2162)
private theorem w2163_0 : checkWitness 2163 false false 8878 = true := by decide +kernel
private theorem w2163_2 : checkWitness 2163 true false 8874 = true := by decide +kernel
private theorem cases2163 : checkFour 2163 (8878,0,8874,0) = true := by
  simp only [checkFour, w2163_0,w2163_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2163 : Coverage 2163 2164 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases2163)
private theorem w2164_0 : checkWitness 2164 false false 88 = true := by decide +kernel
private theorem w2164_2 : checkWitness 2164 true false 88 = true := by decide +kernel
private theorem cases2164 : checkFour 2164 (88,0,88,0) = true := by
  simp only [checkFour, w2164_0,w2164_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2164 : Coverage 2164 2165 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases2164)
private theorem w2165_0 : checkWitness 2165 false false 623 = true := by decide +kernel
private theorem w2165_1 : checkWitness 2165 false true 4715 = true := by decide +kernel
private theorem w2165_2 : checkWitness 2165 true false 614 = true := by decide +kernel
private theorem w2165_3 : checkWitness 2165 true true 4706 = true := by decide +kernel
private theorem cases2165 : checkFour 2165 (623,4715,614,4706) = true := by
  simp only [checkFour, w2165_0,w2165_1,w2165_2,w2165_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2165 : Coverage 2165 2166 := checkList_sound (ws:=[(623,4715,614,4706)]) (by simpa only [checkList, Bool.and_true] using cases2165)
private theorem w2166_0 : checkWitness 2166 false false 8920 = true := by decide +kernel
private theorem w2166_2 : checkWitness 2166 true false 8911 = true := by decide +kernel
private theorem cases2166 : checkFour 2166 (8920,0,8911,0) = true := by
  simp only [checkFour, w2166_0,w2166_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2166 : Coverage 2166 2167 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2166)
private theorem w2167_0 : checkWitness 2167 false false 8866 = true := by decide +kernel
private theorem w2167_2 : checkWitness 2167 true false 8862 = true := by decide +kernel
private theorem cases2167 : checkFour 2167 (8866,0,8862,0) = true := by
  simp only [checkFour, w2167_0,w2167_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2167 : Coverage 2167 2168 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases2167)
private theorem w2168_0 : checkWitness 2168 false false 82 = true := by decide +kernel
private theorem w2168_2 : checkWitness 2168 true false 82 = true := by decide +kernel
private theorem cases2168 : checkFour 2168 (82,0,82,0) = true := by
  simp only [checkFour, w2168_0,w2168_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2168 : Coverage 2168 2169 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2168)
private theorem w2169_0 : checkWitness 2169 false false 650 = true := by decide +kernel
private theorem w2169_1 : checkWitness 2169 false true 4742 = true := by decide +kernel
private theorem w2169_2 : checkWitness 2169 true false 641 = true := by decide +kernel
private theorem w2169_3 : checkWitness 2169 true true 4733 = true := by decide +kernel
private theorem cases2169 : checkFour 2169 (650,4742,641,4733) = true := by
  simp only [checkFour, w2169_0,w2169_1,w2169_2,w2169_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2169 : Coverage 2169 2170 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases2169)
private theorem w2170_0 : checkWitness 2170 false false 8927 = true := by decide +kernel
private theorem w2170_2 : checkWitness 2170 true false 8918 = true := by decide +kernel
private theorem cases2170 : checkFour 2170 (8927,0,8918,0) = true := by
  simp only [checkFour, w2170_0,w2170_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2170 : Coverage 2170 2171 := checkList_sound (ws:=[(8927,0,8918,0)]) (by simpa only [checkList, Bool.and_true] using cases2170)
private theorem w2171_0 : checkWitness 2171 false false 66 = true := by decide +kernel
private theorem w2171_2 : checkWitness 2171 true false 66 = true := by decide +kernel
private theorem cases2171 : checkFour 2171 (66,0,66,0) = true := by
  simp only [checkFour, w2171_0,w2171_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2171 : Coverage 2171 2172 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2171)
private theorem w2172_0 : checkWitness 2172 false false 514 = true := by decide +kernel
private theorem w2172_1 : checkWitness 2172 false true 4610 = true := by decide +kernel
private theorem w2172_2 : checkWitness 2172 true false 514 = true := by decide +kernel
private theorem w2172_3 : checkWitness 2172 true true 4610 = true := by decide +kernel
private theorem cases2172 : checkFour 2172 (514,4610,514,4610) = true := by
  simp only [checkFour, w2172_0,w2172_1,w2172_2,w2172_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2172 : Coverage 2172 2173 := checkList_sound (ws:=[(514,4610,514,4610)]) (by simpa only [checkList, Bool.and_true] using cases2172)
private theorem w2173_0 : checkWitness 2173 false false 8909 = true := by decide +kernel
private theorem w2173_2 : checkWitness 2173 true false 8905 = true := by decide +kernel
private theorem cases2173 : checkFour 2173 (8909,0,8905,0) = true := by
  simp only [checkFour, w2173_0,w2173_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2173 : Coverage 2173 2174 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases2173)
private theorem w2174_0 : checkWitness 2174 false false 640 = true := by decide +kernel
private theorem w2174_1 : checkWitness 2174 false true 4736 = true := by decide +kernel
private theorem w2174_2 : checkWitness 2174 true false 631 = true := by decide +kernel
private theorem w2174_3 : checkWitness 2174 true true 4727 = true := by decide +kernel
private theorem cases2174 : checkFour 2174 (640,4736,631,4727) = true := by
  simp only [checkFour, w2174_0,w2174_1,w2174_2,w2174_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2174 : Coverage 2174 2175 := checkList_sound (ws:=[(640,4736,631,4727)]) (by simpa only [checkList, Bool.and_true] using cases2174)
private theorem w2175_0 : checkWitness 2175 false false 184 = true := by decide +kernel
private theorem w2175_2 : checkWitness 2175 true false 184 = true := by decide +kernel
private theorem cases2175 : checkFour 2175 (184,0,184,0) = true := by
  simp only [checkFour, w2175_0,w2175_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2175 : Coverage 2175 2176 := checkList_sound (ws:=[(184,0,184,0)]) (by simpa only [checkList, Bool.and_true] using cases2175)
theorem cover2144 : Coverage 2144 2176 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2144 one2145) (Coverage.join one2146 one2147)) (Coverage.join (Coverage.join one2148 one2149) (Coverage.join one2150 one2151))) (Coverage.join (Coverage.join (Coverage.join one2152 one2153) (Coverage.join one2154 one2155)) (Coverage.join (Coverage.join one2156 one2157) (Coverage.join one2158 one2159)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2160 one2161) (Coverage.join one2162 one2163)) (Coverage.join (Coverage.join one2164 one2165) (Coverage.join one2166 one2167))) (Coverage.join (Coverage.join (Coverage.join one2168 one2169) (Coverage.join one2170 one2171)) (Coverage.join (Coverage.join one2172 one2173) (Coverage.join one2174 one2175)))))
end NF180PA.Symbolic
