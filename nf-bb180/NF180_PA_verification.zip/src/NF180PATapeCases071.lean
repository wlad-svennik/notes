import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2272_0 : checkWitness 2272 false false 611 = true := by decide +kernel
private theorem w2272_1 : checkWitness 2272 false true 4699 = true := by decide +kernel
private theorem w2272_2 : checkWitness 2272 true false 611 = true := by decide +kernel
private theorem w2272_3 : checkWitness 2272 true true 4699 = true := by decide +kernel
private theorem cases2272 : checkFour 2272 (611,4699,611,4699) = true := by
  simp only [checkFour, w2272_0,w2272_1,w2272_2,w2272_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2272 : Coverage 2272 2273 := checkList_sound (ws:=[(611,4699,611,4699)]) (by simpa only [checkList, Bool.and_true] using cases2272)
private theorem w2273_0 : checkWitness 2273 false false 8884 = true := by decide +kernel
private theorem w2273_2 : checkWitness 2273 true false 8880 = true := by decide +kernel
private theorem cases2273 : checkFour 2273 (8884,0,8880,0) = true := by
  simp only [checkFour, w2273_0,w2273_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2273 : Coverage 2273 2274 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases2273)
private theorem w2274_0 : checkWitness 2274 false false 8880 = true := by decide +kernel
private theorem w2274_2 : checkWitness 2274 true false 8876 = true := by decide +kernel
private theorem cases2274 : checkFour 2274 (8880,0,8876,0) = true := by
  simp only [checkFour, w2274_0,w2274_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2274 : Coverage 2274 2275 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases2274)
private theorem w2275_0 : checkWitness 2275 false false 80 = true := by decide +kernel
private theorem w2275_2 : checkWitness 2275 true false 80 = true := by decide +kernel
private theorem cases2275 : checkFour 2275 (80,0,80,0) = true := by
  simp only [checkFour, w2275_0,w2275_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2275 : Coverage 2275 2276 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2275)
private theorem w2276_0 : checkWitness 2276 false false 8904 = true := by decide +kernel
private theorem w2276_2 : checkWitness 2276 true false 8900 = true := by decide +kernel
private theorem cases2276 : checkFour 2276 (8904,0,8900,0) = true := by
  simp only [checkFour, w2276_0,w2276_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2276 : Coverage 2276 2277 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2276)
private theorem w2277_0 : checkWitness 2277 false false 738 = true := by decide +kernel
private theorem w2277_1 : checkWitness 2277 false true 4834 = true := by decide +kernel
private theorem w2277_2 : checkWitness 2277 true false 738 = true := by decide +kernel
private theorem w2277_3 : checkWitness 2277 true true 4834 = true := by decide +kernel
private theorem cases2277 : checkFour 2277 (738,4834,738,4834) = true := by
  simp only [checkFour, w2277_0,w2277_1,w2277_2,w2277_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2277 : Coverage 2277 2278 := checkList_sound (ws:=[(738,4834,738,4834)]) (by simpa only [checkList, Bool.and_true] using cases2277)
private theorem w2278_0 : checkWitness 2278 false false 8996 = true := by decide +kernel
private theorem w2278_2 : checkWitness 2278 true false 8987 = true := by decide +kernel
private theorem cases2278 : checkFour 2278 (8996,0,8987,0) = true := by
  simp only [checkFour, w2278_0,w2278_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2278 : Coverage 2278 2279 := checkList_sound (ws:=[(8996,0,8987,0)]) (by simpa only [checkList, Bool.and_true] using cases2278)
private theorem w2279_0 : checkWitness 2279 false false 78 = true := by decide +kernel
private theorem w2279_2 : checkWitness 2279 true false 78 = true := by decide +kernel
private theorem cases2279 : checkFour 2279 (78,0,78,0) = true := by
  simp only [checkFour, w2279_0,w2279_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2279 : Coverage 2279 2280 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2279)
private theorem w2280_0 : checkWitness 2280 false false 578 = true := by decide +kernel
private theorem w2280_1 : checkWitness 2280 false true 4674 = true := by decide +kernel
private theorem w2280_2 : checkWitness 2280 true false 578 = true := by decide +kernel
private theorem w2280_3 : checkWitness 2280 true true 4674 = true := by decide +kernel
private theorem cases2280 : checkFour 2280 (578,4674,578,4674) = true := by
  simp only [checkFour, w2280_0,w2280_1,w2280_2,w2280_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2280 : Coverage 2280 2281 := checkList_sound (ws:=[(578,4674,578,4674)]) (by simpa only [checkList, Bool.and_true] using cases2280)
private theorem w2281_0 : checkWitness 2281 false false 8936 = true := by decide +kernel
private theorem w2281_2 : checkWitness 2281 true false 8932 = true := by decide +kernel
private theorem cases2281 : checkFour 2281 (8936,0,8932,0) = true := by
  simp only [checkFour, w2281_0,w2281_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2281 : Coverage 2281 2282 := checkList_sound (ws:=[(8936,0,8932,0)]) (by simpa only [checkList, Bool.and_true] using cases2281)
private theorem w2282_0 : checkWitness 2282 false false 80 = true := by decide +kernel
private theorem w2282_2 : checkWitness 2282 true false 80 = true := by decide +kernel
private theorem cases2282 : checkFour 2282 (80,0,80,0) = true := by
  simp only [checkFour, w2282_0,w2282_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2282 : Coverage 2282 2283 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2282)
private theorem w2283_0 : checkWitness 2283 false false 616 = true := by decide +kernel
private theorem w2283_1 : checkWitness 2283 false true 4712 = true := by decide +kernel
private theorem w2283_2 : checkWitness 2283 true false 616 = true := by decide +kernel
private theorem w2283_3 : checkWitness 2283 true true 4712 = true := by decide +kernel
private theorem cases2283 : checkFour 2283 (616,4712,616,4712) = true := by
  simp only [checkFour, w2283_0,w2283_1,w2283_2,w2283_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2283 : Coverage 2283 2284 := checkList_sound (ws:=[(616,4712,616,4712)]) (by simpa only [checkList, Bool.and_true] using cases2283)
private theorem w2284_0 : checkWitness 2284 false false 8957 = true := by decide +kernel
private theorem w2284_2 : checkWitness 2284 true false 8953 = true := by decide +kernel
private theorem cases2284 : checkFour 2284 (8957,0,8953,0) = true := by
  simp only [checkFour, w2284_0,w2284_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2284 : Coverage 2284 2285 := checkList_sound (ws:=[(8957,0,8953,0)]) (by simpa only [checkList, Bool.and_true] using cases2284)
private theorem w2285_0 : checkWitness 2285 false false 8992 = true := by decide +kernel
private theorem w2285_2 : checkWitness 2285 true false 8983 = true := by decide +kernel
private theorem cases2285 : checkFour 2285 (8992,0,8983,0) = true := by
  simp only [checkFour, w2285_0,w2285_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2285 : Coverage 2285 2286 := checkList_sound (ws:=[(8992,0,8983,0)]) (by simpa only [checkList, Bool.and_true] using cases2285)
private theorem w2286_0 : checkWitness 2286 false false 104 = true := by decide +kernel
private theorem w2286_2 : checkWitness 2286 true false 104 = true := by decide +kernel
private theorem cases2286 : checkFour 2286 (104,0,104,0) = true := by
  simp only [checkFour, w2286_0,w2286_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2286 : Coverage 2286 2287 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases2286)
private theorem w2287_0 : checkWitness 2287 false false 704 = true := by decide +kernel
private theorem w2287_1 : checkWitness 2287 false true 4796 = true := by decide +kernel
private theorem w2287_2 : checkWitness 2287 true false 695 = true := by decide +kernel
private theorem w2287_3 : checkWitness 2287 true true 4787 = true := by decide +kernel
private theorem cases2287 : checkFour 2287 (704,4796,695,4787) = true := by
  simp only [checkFour, w2287_0,w2287_1,w2287_2,w2287_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2287 : Coverage 2287 2288 := checkList_sound (ws:=[(704,4796,695,4787)]) (by simpa only [checkList, Bool.and_true] using cases2287)
private theorem w2288_0 : checkWitness 2288 false false 8953 = true := by decide +kernel
private theorem w2288_2 : checkWitness 2288 true false 8949 = true := by decide +kernel
private theorem cases2288 : checkFour 2288 (8953,0,8949,0) = true := by
  simp only [checkFour, w2288_0,w2288_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2288 : Coverage 2288 2289 := checkList_sound (ws:=[(8953,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases2288)
private theorem w2289_0 : checkWitness 2289 false false 698 = true := by decide +kernel
private theorem w2289_1 : checkWitness 2289 false true 4790 = true := by decide +kernel
private theorem w2289_2 : checkWitness 2289 true false 689 = true := by decide +kernel
private theorem w2289_3 : checkWitness 2289 true true 4781 = true := by decide +kernel
private theorem cases2289 : checkFour 2289 (698,4790,689,4781) = true := by
  simp only [checkFour, w2289_0,w2289_1,w2289_2,w2289_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2289 : Coverage 2289 2290 := checkList_sound (ws:=[(698,4790,689,4781)]) (by simpa only [checkList, Bool.and_true] using cases2289)
private theorem w2290_0 : checkWitness 2290 false false 8922 = true := by decide +kernel
private theorem w2290_2 : checkWitness 2290 true false 8918 = true := by decide +kernel
private theorem cases2290 : checkFour 2290 (8922,0,8918,0) = true := by
  simp only [checkFour, w2290_0,w2290_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2290 : Coverage 2290 2291 := checkList_sound (ws:=[(8922,0,8918,0)]) (by simpa only [checkList, Bool.and_true] using cases2290)
private theorem w2291_0 : checkWitness 2291 false false 92 = true := by decide +kernel
private theorem w2291_2 : checkWitness 2291 true false 92 = true := by decide +kernel
private theorem cases2291 : checkFour 2291 (92,0,92,0) = true := by
  simp only [checkFour, w2291_0,w2291_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2291 : Coverage 2291 2292 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases2291)
private theorem w2292_0 : checkWitness 2292 false false 84 = true := by decide +kernel
private theorem w2292_2 : checkWitness 2292 true false 84 = true := by decide +kernel
private theorem cases2292 : checkFour 2292 (84,0,84,0) = true := by
  simp only [checkFour, w2292_0,w2292_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2292 : Coverage 2292 2293 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2292)
private theorem w2293_0 : checkWitness 2293 false false 663 = true := by decide +kernel
private theorem w2293_1 : checkWitness 2293 false true 4747 = true := by decide +kernel
private theorem w2293_2 : checkWitness 2293 true false 663 = true := by decide +kernel
private theorem w2293_3 : checkWitness 2293 true true 4747 = true := by decide +kernel
private theorem cases2293 : checkFour 2293 (663,4747,663,4747) = true := by
  simp only [checkFour, w2293_0,w2293_1,w2293_2,w2293_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2293 : Coverage 2293 2294 := checkList_sound (ws:=[(663,4747,663,4747)]) (by simpa only [checkList, Bool.and_true] using cases2293)
private theorem w2294_0 : checkWitness 2294 false false 8916 = true := by decide +kernel
private theorem w2294_2 : checkWitness 2294 true false 8912 = true := by decide +kernel
private theorem cases2294 : checkFour 2294 (8916,0,8912,0) = true := by
  simp only [checkFour, w2294_0,w2294_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2294 : Coverage 2294 2295 := checkList_sound (ws:=[(8916,0,8912,0)]) (by simpa only [checkList, Bool.and_true] using cases2294)
private theorem w2295_0 : checkWitness 2295 false false 84 = true := by decide +kernel
private theorem w2295_2 : checkWitness 2295 true false 84 = true := by decide +kernel
private theorem cases2295 : checkFour 2295 (84,0,84,0) = true := by
  simp only [checkFour, w2295_0,w2295_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2295 : Coverage 2295 2296 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2295)
private theorem w2296_0 : checkWitness 2296 false false 661 = true := by decide +kernel
private theorem w2296_1 : checkWitness 2296 false true 4753 = true := by decide +kernel
private theorem w2296_2 : checkWitness 2296 true false 652 = true := by decide +kernel
private theorem w2296_3 : checkWitness 2296 true true 4744 = true := by decide +kernel
private theorem cases2296 : checkFour 2296 (661,4753,652,4744) = true := by
  simp only [checkFour, w2296_0,w2296_1,w2296_2,w2296_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2296 : Coverage 2296 2297 := checkList_sound (ws:=[(661,4753,652,4744)]) (by simpa only [checkList, Bool.and_true] using cases2296)
private theorem w2297_0 : checkWitness 2297 false false 8958 = true := by decide +kernel
private theorem w2297_2 : checkWitness 2297 true false 8949 = true := by decide +kernel
private theorem cases2297 : checkFour 2297 (8958,0,8949,0) = true := by
  simp only [checkFour, w2297_0,w2297_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2297 : Coverage 2297 2298 := checkList_sound (ws:=[(8958,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases2297)
private theorem w2298_0 : checkWitness 2298 false false 8904 = true := by decide +kernel
private theorem w2298_2 : checkWitness 2298 true false 8900 = true := by decide +kernel
private theorem cases2298 : checkFour 2298 (8904,0,8900,0) = true := by
  simp only [checkFour, w2298_0,w2298_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2298 : Coverage 2298 2299 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2298)
private theorem w2299_0 : checkWitness 2299 false false 78 = true := by decide +kernel
private theorem w2299_2 : checkWitness 2299 true false 78 = true := by decide +kernel
private theorem cases2299 : checkFour 2299 (78,0,78,0) = true := by
  simp only [checkFour, w2299_0,w2299_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2299 : Coverage 2299 2300 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2299)
private theorem w2300_0 : checkWitness 2300 false false 688 = true := by decide +kernel
private theorem w2300_1 : checkWitness 2300 false true 4780 = true := by decide +kernel
private theorem w2300_2 : checkWitness 2300 true false 679 = true := by decide +kernel
private theorem w2300_3 : checkWitness 2300 true true 4771 = true := by decide +kernel
private theorem cases2300 : checkFour 2300 (688,4780,679,4771) = true := by
  simp only [checkFour, w2300_0,w2300_1,w2300_2,w2300_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2300 : Coverage 2300 2301 := checkList_sound (ws:=[(688,4780,679,4771)]) (by simpa only [checkList, Bool.and_true] using cases2300)
private theorem w2301_0 : checkWitness 2301 false false 8965 = true := by decide +kernel
private theorem w2301_2 : checkWitness 2301 true false 8956 = true := by decide +kernel
private theorem cases2301 : checkFour 2301 (8965,0,8956,0) = true := by
  simp only [checkFour, w2301_0,w2301_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2301 : Coverage 2301 2302 := checkList_sound (ws:=[(8965,0,8956,0)]) (by simpa only [checkList, Bool.and_true] using cases2301)
private theorem w2302_0 : checkWitness 2302 false false 62 = true := by decide +kernel
private theorem w2302_2 : checkWitness 2302 true false 62 = true := by decide +kernel
private theorem cases2302 : checkFour 2302 (62,0,62,0) = true := by
  simp only [checkFour, w2302_0,w2302_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2302 : Coverage 2302 2303 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2302)
private theorem w2303_0 : checkWitness 2303 false false 608 = true := by decide +kernel
private theorem w2303_1 : checkWitness 2303 false true 4704 = true := by decide +kernel
private theorem w2303_2 : checkWitness 2303 true false 608 = true := by decide +kernel
private theorem w2303_3 : checkWitness 2303 true true 4704 = true := by decide +kernel
private theorem cases2303 : checkFour 2303 (608,4704,608,4704) = true := by
  simp only [checkFour, w2303_0,w2303_1,w2303_2,w2303_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2303 : Coverage 2303 2304 := checkList_sound (ws:=[(608,4704,608,4704)]) (by simpa only [checkList, Bool.and_true] using cases2303)
theorem cover2272 : Coverage 2272 2304 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2272 one2273) (Coverage.join one2274 one2275)) (Coverage.join (Coverage.join one2276 one2277) (Coverage.join one2278 one2279))) (Coverage.join (Coverage.join (Coverage.join one2280 one2281) (Coverage.join one2282 one2283)) (Coverage.join (Coverage.join one2284 one2285) (Coverage.join one2286 one2287)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2288 one2289) (Coverage.join one2290 one2291)) (Coverage.join (Coverage.join one2292 one2293) (Coverage.join one2294 one2295))) (Coverage.join (Coverage.join (Coverage.join one2296 one2297) (Coverage.join one2298 one2299)) (Coverage.join (Coverage.join one2300 one2301) (Coverage.join one2302 one2303)))))
end NF180PA.Symbolic
