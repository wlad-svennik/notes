import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w768_0 : checkWitness 768 false false 8910 = true := by decide +kernel
private theorem w768_2 : checkWitness 768 true false 8906 = true := by decide +kernel
private theorem cases768 : checkFour 768 (8910,0,8906,0) = true := by
  simp only [checkFour, w768_0,w768_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one768 : Coverage 768 769 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases768)
private theorem w769_0 : checkWitness 769 false false 78 = true := by decide +kernel
private theorem w769_2 : checkWitness 769 true false 78 = true := by decide +kernel
private theorem cases769 : checkFour 769 (78,0,78,0) = true := by
  simp only [checkFour, w769_0,w769_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one769 : Coverage 769 770 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases769)
private theorem w770_0 : checkWitness 770 false false 590 = true := by decide +kernel
private theorem w770_1 : checkWitness 770 false true 4686 = true := by decide +kernel
private theorem w770_2 : checkWitness 770 true false 590 = true := by decide +kernel
private theorem w770_3 : checkWitness 770 true true 4686 = true := by decide +kernel
private theorem cases770 : checkFour 770 (590,4686,590,4686) = true := by
  simp only [checkFour, w770_0,w770_1,w770_2,w770_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one770 : Coverage 770 771 := checkList_sound (ws:=[(590,4686,590,4686)]) (by simpa only [checkList, Bool.and_true] using cases770)
private theorem w771_0 : checkWitness 771 false false 8931 = true := by decide +kernel
private theorem w771_2 : checkWitness 771 true false 8927 = true := by decide +kernel
private theorem cases771 : checkFour 771 (8931,0,8927,0) = true := by
  simp only [checkFour, w771_0,w771_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one771 : Coverage 771 772 := checkList_sound (ws:=[(8931,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases771)
private theorem w772_0 : checkWitness 772 false false 8966 = true := by decide +kernel
private theorem w772_2 : checkWitness 772 true false 8957 = true := by decide +kernel
private theorem cases772 : checkFour 772 (8966,0,8957,0) = true := by
  simp only [checkFour, w772_0,w772_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one772 : Coverage 772 773 := checkList_sound (ws:=[(8966,0,8957,0)]) (by simpa only [checkList, Bool.and_true] using cases772)
private theorem w773_0 : checkWitness 773 false false 102 = true := by decide +kernel
private theorem w773_2 : checkWitness 773 true false 102 = true := by decide +kernel
private theorem cases773 : checkFour 773 (102,0,102,0) = true := by
  simp only [checkFour, w773_0,w773_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one773 : Coverage 773 774 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases773)
private theorem w774_0 : checkWitness 774 false false 678 = true := by decide +kernel
private theorem w774_1 : checkWitness 774 false true 4770 = true := by decide +kernel
private theorem w774_2 : checkWitness 774 true false 669 = true := by decide +kernel
private theorem w774_3 : checkWitness 774 true true 4761 = true := by decide +kernel
private theorem cases774 : checkFour 774 (678,4770,669,4761) = true := by
  simp only [checkFour, w774_0,w774_1,w774_2,w774_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one774 : Coverage 774 775 := checkList_sound (ws:=[(678,4770,669,4761)]) (by simpa only [checkList, Bool.and_true] using cases774)
private theorem w775_0 : checkWitness 775 false false 8927 = true := by decide +kernel
private theorem w775_2 : checkWitness 775 true false 8923 = true := by decide +kernel
private theorem cases775 : checkFour 775 (8927,0,8923,0) = true := by
  simp only [checkFour, w775_0,w775_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one775 : Coverage 775 776 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases775)
private theorem w776_0 : checkWitness 776 false false 672 = true := by decide +kernel
private theorem w776_1 : checkWitness 776 false true 4764 = true := by decide +kernel
private theorem w776_2 : checkWitness 776 true false 663 = true := by decide +kernel
private theorem w776_3 : checkWitness 776 true true 4755 = true := by decide +kernel
private theorem cases776 : checkFour 776 (672,4764,663,4755) = true := by
  simp only [checkFour, w776_0,w776_1,w776_2,w776_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one776 : Coverage 776 777 := checkList_sound (ws:=[(672,4764,663,4755)]) (by simpa only [checkList, Bool.and_true] using cases776)
private theorem w777_0 : checkWitness 777 false false 8896 = true := by decide +kernel
private theorem w777_2 : checkWitness 777 true false 8892 = true := by decide +kernel
private theorem cases777 : checkFour 777 (8896,0,8892,0) = true := by
  simp only [checkFour, w777_0,w777_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one777 : Coverage 777 778 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases777)
private theorem w778_0 : checkWitness 778 false false 90 = true := by decide +kernel
private theorem w778_2 : checkWitness 778 true false 90 = true := by decide +kernel
private theorem cases778 : checkFour 778 (90,0,90,0) = true := by
  simp only [checkFour, w778_0,w778_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one778 : Coverage 778 779 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases778)
private theorem w779_0 : checkWitness 779 false false 82 = true := by decide +kernel
private theorem w779_2 : checkWitness 779 true false 82 = true := by decide +kernel
private theorem cases779 : checkFour 779 (82,0,82,0) = true := by
  simp only [checkFour, w779_0,w779_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one779 : Coverage 779 780 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases779)
private theorem w780_0 : checkWitness 780 false false 637 = true := by decide +kernel
private theorem w780_1 : checkWitness 780 false true 4721 = true := by decide +kernel
private theorem w780_2 : checkWitness 780 true false 637 = true := by decide +kernel
private theorem w780_3 : checkWitness 780 true true 4721 = true := by decide +kernel
private theorem cases780 : checkFour 780 (637,4721,637,4721) = true := by
  simp only [checkFour, w780_0,w780_1,w780_2,w780_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one780 : Coverage 780 781 := checkList_sound (ws:=[(637,4721,637,4721)]) (by simpa only [checkList, Bool.and_true] using cases780)
private theorem w781_0 : checkWitness 781 false false 8890 = true := by decide +kernel
private theorem w781_2 : checkWitness 781 true false 8886 = true := by decide +kernel
private theorem cases781 : checkFour 781 (8890,0,8886,0) = true := by
  simp only [checkFour, w781_0,w781_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one781 : Coverage 781 782 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases781)
private theorem w782_0 : checkWitness 782 false false 82 = true := by decide +kernel
private theorem w782_2 : checkWitness 782 true false 82 = true := by decide +kernel
private theorem cases782 : checkFour 782 (82,0,82,0) = true := by
  simp only [checkFour, w782_0,w782_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one782 : Coverage 782 783 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases782)
private theorem w783_0 : checkWitness 783 false false 635 = true := by decide +kernel
private theorem w783_1 : checkWitness 783 false true 4727 = true := by decide +kernel
private theorem w783_2 : checkWitness 783 true false 626 = true := by decide +kernel
private theorem w783_3 : checkWitness 783 true true 4718 = true := by decide +kernel
private theorem cases783 : checkFour 783 (635,4727,626,4718) = true := by
  simp only [checkFour, w783_0,w783_1,w783_2,w783_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one783 : Coverage 783 784 := checkList_sound (ws:=[(635,4727,626,4718)]) (by simpa only [checkList, Bool.and_true] using cases783)
private theorem w784_0 : checkWitness 784 false false 8932 = true := by decide +kernel
private theorem w784_2 : checkWitness 784 true false 8923 = true := by decide +kernel
private theorem cases784 : checkFour 784 (8932,0,8923,0) = true := by
  simp only [checkFour, w784_0,w784_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one784 : Coverage 784 785 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases784)
private theorem w785_0 : checkWitness 785 false false 8878 = true := by decide +kernel
private theorem w785_2 : checkWitness 785 true false 8874 = true := by decide +kernel
private theorem cases785 : checkFour 785 (8878,0,8874,0) = true := by
  simp only [checkFour, w785_0,w785_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one785 : Coverage 785 786 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases785)
private theorem w786_0 : checkWitness 786 false false 76 = true := by decide +kernel
private theorem w786_2 : checkWitness 786 true false 76 = true := by decide +kernel
private theorem cases786 : checkFour 786 (76,0,76,0) = true := by
  simp only [checkFour, w786_0,w786_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one786 : Coverage 786 787 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases786)
private theorem w787_0 : checkWitness 787 false false 662 = true := by decide +kernel
private theorem w787_1 : checkWitness 787 false true 4754 = true := by decide +kernel
private theorem w787_2 : checkWitness 787 true false 653 = true := by decide +kernel
private theorem w787_3 : checkWitness 787 true true 4745 = true := by decide +kernel
private theorem cases787 : checkFour 787 (662,4754,653,4745) = true := by
  simp only [checkFour, w787_0,w787_1,w787_2,w787_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one787 : Coverage 787 788 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases787)
private theorem w788_0 : checkWitness 788 false false 8939 = true := by decide +kernel
private theorem w788_2 : checkWitness 788 true false 8930 = true := by decide +kernel
private theorem cases788 : checkFour 788 (8939,0,8930,0) = true := by
  simp only [checkFour, w788_0,w788_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one788 : Coverage 788 789 := checkList_sound (ws:=[(8939,0,8930,0)]) (by simpa only [checkList, Bool.and_true] using cases788)
private theorem w789_0 : checkWitness 789 false false 60 = true := by decide +kernel
private theorem w789_2 : checkWitness 789 true false 60 = true := by decide +kernel
private theorem cases789 : checkFour 789 (60,0,60,0) = true := by
  simp only [checkFour, w789_0,w789_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one789 : Coverage 789 790 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases789)
private theorem w790_0 : checkWitness 790 false false 526 = true := by decide +kernel
private theorem w790_1 : checkWitness 790 false true 4622 = true := by decide +kernel
private theorem w790_2 : checkWitness 790 true false 526 = true := by decide +kernel
private theorem w790_3 : checkWitness 790 true true 4622 = true := by decide +kernel
private theorem cases790 : checkFour 790 (526,4622,526,4622) = true := by
  simp only [checkFour, w790_0,w790_1,w790_2,w790_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one790 : Coverage 790 791 := checkList_sound (ws:=[(526,4622,526,4622)]) (by simpa only [checkList, Bool.and_true] using cases790)
private theorem w791_0 : checkWitness 791 false false 8921 = true := by decide +kernel
private theorem w791_2 : checkWitness 791 true false 8917 = true := by decide +kernel
private theorem cases791 : checkFour 791 (8921,0,8917,0) = true := by
  simp only [checkFour, w791_0,w791_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one791 : Coverage 791 792 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases791)
private theorem w792_0 : checkWitness 792 false false 652 = true := by decide +kernel
private theorem w792_1 : checkWitness 792 false true 4748 = true := by decide +kernel
private theorem w792_2 : checkWitness 792 true false 643 = true := by decide +kernel
private theorem w792_3 : checkWitness 792 true true 4739 = true := by decide +kernel
private theorem cases792 : checkFour 792 (652,4748,643,4739) = true := by
  simp only [checkFour, w792_0,w792_1,w792_2,w792_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one792 : Coverage 792 793 := checkList_sound (ws:=[(652,4748,643,4739)]) (by simpa only [checkList, Bool.and_true] using cases792)
private theorem w793_0 : checkWitness 793 false false 190 = true := by decide +kernel
private theorem w793_2 : checkWitness 793 true false 190 = true := by decide +kernel
private theorem cases793 : checkFour 793 (190,0,190,0) = true := by
  simp only [checkFour, w793_0,w793_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one793 : Coverage 793 794 := checkList_sound (ws:=[(190,0,190,0)]) (by simpa only [checkList, Bool.and_true] using cases793)
private theorem w794_0 : checkWitness 794 false false 607 = true := by decide +kernel
private theorem w794_1 : checkWitness 794 false true 4695 = true := by decide +kernel
private theorem w794_2 : checkWitness 794 true false 607 = true := by decide +kernel
private theorem w794_3 : checkWitness 794 true true 4695 = true := by decide +kernel
private theorem cases794 : checkFour 794 (607,4695,607,4695) = true := by
  simp only [checkFour, w794_0,w794_1,w794_2,w794_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one794 : Coverage 794 795 := checkList_sound (ws:=[(607,4695,607,4695)]) (by simpa only [checkList, Bool.and_true] using cases794)
private theorem w795_0 : checkWitness 795 false false 8936 = true := by decide +kernel
private theorem w795_2 : checkWitness 795 true false 8927 = true := by decide +kernel
private theorem cases795 : checkFour 795 (8936,0,8927,0) = true := by
  simp only [checkFour, w795_0,w795_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one795 : Coverage 795 796 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases795)
private theorem w796_0 : checkWitness 796 false false 78 = true := by decide +kernel
private theorem w796_2 : checkWitness 796 true false 78 = true := by decide +kernel
private theorem cases796 : checkFour 796 (78,0,78,0) = true := by
  simp only [checkFour, w796_0,w796_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one796 : Coverage 796 797 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases796)
private theorem w797_0 : checkWitness 797 false false 70 = true := by decide +kernel
private theorem w797_2 : checkWitness 797 true false 70 = true := by decide +kernel
private theorem cases797 : checkFour 797 (70,0,70,0) = true := by
  simp only [checkFour, w797_0,w797_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one797 : Coverage 797 798 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases797)
private theorem w798_0 : checkWitness 798 false false 613 = true := by decide +kernel
private theorem w798_1 : checkWitness 798 false true 4705 = true := by decide +kernel
private theorem w798_2 : checkWitness 798 true false 613 = true := by decide +kernel
private theorem w798_3 : checkWitness 798 true true 4705 = true := by decide +kernel
private theorem cases798 : checkFour 798 (613,4705,613,4705) = true := by
  simp only [checkFour, w798_0,w798_1,w798_2,w798_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one798 : Coverage 798 799 := checkList_sound (ws:=[(613,4705,613,4705)]) (by simpa only [checkList, Bool.and_true] using cases798)
private theorem w799_0 : checkWitness 799 false false 8874 = true := by decide +kernel
private theorem w799_2 : checkWitness 799 true false 8870 = true := by decide +kernel
private theorem cases799 : checkFour 799 (8874,0,8870,0) = true := by
  simp only [checkFour, w799_0,w799_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one799 : Coverage 799 800 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases799)
theorem cover0768 : Coverage 768 800 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one768 one769) (Coverage.join one770 one771)) (Coverage.join (Coverage.join one772 one773) (Coverage.join one774 one775))) (Coverage.join (Coverage.join (Coverage.join one776 one777) (Coverage.join one778 one779)) (Coverage.join (Coverage.join one780 one781) (Coverage.join one782 one783)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one784 one785) (Coverage.join one786 one787)) (Coverage.join (Coverage.join one788 one789) (Coverage.join one790 one791))) (Coverage.join (Coverage.join (Coverage.join one792 one793) (Coverage.join one794 one795)) (Coverage.join (Coverage.join one796 one797) (Coverage.join one798 one799)))))
end NF180PA.Symbolic
