import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1920_0 : checkWitness 1920 false false 88 = true := by decide +kernel
private theorem w1920_2 : checkWitness 1920 true false 88 = true := by decide +kernel
private theorem cases1920 : checkFour 1920 (88,0,88,0) = true := by
  simp only [checkFour, w1920_0,w1920_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1920 : Coverage 1920 1921 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1920)
private theorem w1921_0 : checkWitness 1921 false false 538 = true := by decide +kernel
private theorem w1921_1 : checkWitness 1921 false true 4634 = true := by decide +kernel
private theorem w1921_2 : checkWitness 1921 true false 538 = true := by decide +kernel
private theorem w1921_3 : checkWitness 1921 true true 4634 = true := by decide +kernel
private theorem cases1921 : checkFour 1921 (538,4634,538,4634) = true := by
  simp only [checkFour, w1921_0,w1921_1,w1921_2,w1921_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1921 : Coverage 1921 1922 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases1921)
private theorem w1922_0 : checkWitness 1922 false false 8896 = true := by decide +kernel
private theorem w1922_2 : checkWitness 1922 true false 8892 = true := by decide +kernel
private theorem cases1922 : checkFour 1922 (8896,0,8892,0) = true := by
  simp only [checkFour, w1922_0,w1922_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1922 : Coverage 1922 1923 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases1922)
private theorem w1923_0 : checkWitness 1923 false false 90 = true := by decide +kernel
private theorem w1923_2 : checkWitness 1923 true false 90 = true := by decide +kernel
private theorem cases1923 : checkFour 1923 (90,0,90,0) = true := by
  simp only [checkFour, w1923_0,w1923_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1923 : Coverage 1923 1924 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1923)
private theorem w1924_0 : checkWitness 1924 false false 576 = true := by decide +kernel
private theorem w1924_1 : checkWitness 1924 false true 4672 = true := by decide +kernel
private theorem w1924_2 : checkWitness 1924 true false 576 = true := by decide +kernel
private theorem w1924_3 : checkWitness 1924 true true 4672 = true := by decide +kernel
private theorem cases1924 : checkFour 1924 (576,4672,576,4672) = true := by
  simp only [checkFour, w1924_0,w1924_1,w1924_2,w1924_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1924 : Coverage 1924 1925 := checkList_sound (ws:=[(576,4672,576,4672)]) (by simpa only [checkList, Bool.and_true] using cases1924)
private theorem w1925_0 : checkWitness 1925 false false 8917 = true := by decide +kernel
private theorem w1925_2 : checkWitness 1925 true false 8913 = true := by decide +kernel
private theorem cases1925 : checkFour 1925 (8917,0,8913,0) = true := by
  simp only [checkFour, w1925_0,w1925_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1925 : Coverage 1925 1926 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases1925)
private theorem w1926_0 : checkWitness 1926 false false 8952 = true := by decide +kernel
private theorem w1926_2 : checkWitness 1926 true false 8943 = true := by decide +kernel
private theorem cases1926 : checkFour 1926 (8952,0,8943,0) = true := by
  simp only [checkFour, w1926_0,w1926_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1926 : Coverage 1926 1927 := checkList_sound (ws:=[(8952,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases1926)
private theorem w1927_0 : checkWitness 1927 false false 114 = true := by decide +kernel
private theorem w1927_2 : checkWitness 1927 true false 114 = true := by decide +kernel
private theorem cases1927 : checkFour 1927 (114,0,114,0) = true := by
  simp only [checkFour, w1927_0,w1927_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1927 : Coverage 1927 1928 := checkList_sound (ws:=[(114,0,114,0)]) (by simpa only [checkList, Bool.and_true] using cases1927)
private theorem w1928_0 : checkWitness 1928 false false 664 = true := by decide +kernel
private theorem w1928_1 : checkWitness 1928 false true 4756 = true := by decide +kernel
private theorem w1928_2 : checkWitness 1928 true false 655 = true := by decide +kernel
private theorem w1928_3 : checkWitness 1928 true true 4747 = true := by decide +kernel
private theorem cases1928 : checkFour 1928 (664,4756,655,4747) = true := by
  simp only [checkFour, w1928_0,w1928_1,w1928_2,w1928_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1928 : Coverage 1928 1929 := checkList_sound (ws:=[(664,4756,655,4747)]) (by simpa only [checkList, Bool.and_true] using cases1928)
private theorem w1929_0 : checkWitness 1929 false false 8913 = true := by decide +kernel
private theorem w1929_2 : checkWitness 1929 true false 8909 = true := by decide +kernel
private theorem cases1929 : checkFour 1929 (8913,0,8909,0) = true := by
  simp only [checkFour, w1929_0,w1929_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1929 : Coverage 1929 1930 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases1929)
private theorem w1930_0 : checkWitness 1930 false false 658 = true := by decide +kernel
private theorem w1930_1 : checkWitness 1930 false true 4750 = true := by decide +kernel
private theorem w1930_2 : checkWitness 1930 true false 649 = true := by decide +kernel
private theorem w1930_3 : checkWitness 1930 true true 4741 = true := by decide +kernel
private theorem cases1930 : checkFour 1930 (658,4750,649,4741) = true := by
  simp only [checkFour, w1930_0,w1930_1,w1930_2,w1930_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1930 : Coverage 1930 1931 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases1930)
private theorem w1931_0 : checkWitness 1931 false false 8882 = true := by decide +kernel
private theorem w1931_2 : checkWitness 1931 true false 8878 = true := by decide +kernel
private theorem cases1931 : checkFour 1931 (8882,0,8878,0) = true := by
  simp only [checkFour, w1931_0,w1931_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1931 : Coverage 1931 1932 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases1931)
private theorem w1932_0 : checkWitness 1932 false false 102 = true := by decide +kernel
private theorem w1932_2 : checkWitness 1932 true false 102 = true := by decide +kernel
private theorem cases1932 : checkFour 1932 (102,0,102,0) = true := by
  simp only [checkFour, w1932_0,w1932_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1932 : Coverage 1932 1933 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1932)
private theorem w1933_0 : checkWitness 1933 false false 94 = true := by decide +kernel
private theorem w1933_2 : checkWitness 1933 true false 94 = true := by decide +kernel
private theorem cases1933 : checkFour 1933 (94,0,94,0) = true := by
  simp only [checkFour, w1933_0,w1933_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1933 : Coverage 1933 1934 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1933)
private theorem w1934_0 : checkWitness 1934 false false 623 = true := by decide +kernel
private theorem w1934_1 : checkWitness 1934 false true 4707 = true := by decide +kernel
private theorem w1934_2 : checkWitness 1934 true false 623 = true := by decide +kernel
private theorem w1934_3 : checkWitness 1934 true true 4707 = true := by decide +kernel
private theorem cases1934 : checkFour 1934 (623,4707,623,4707) = true := by
  simp only [checkFour, w1934_0,w1934_1,w1934_2,w1934_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1934 : Coverage 1934 1935 := checkList_sound (ws:=[(623,4707,623,4707)]) (by simpa only [checkList, Bool.and_true] using cases1934)
private theorem w1935_0 : checkWitness 1935 false false 8876 = true := by decide +kernel
private theorem w1935_2 : checkWitness 1935 true false 8872 = true := by decide +kernel
private theorem cases1935 : checkFour 1935 (8876,0,8872,0) = true := by
  simp only [checkFour, w1935_0,w1935_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1935 : Coverage 1935 1936 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases1935)
private theorem w1936_0 : checkWitness 1936 false false 94 = true := by decide +kernel
private theorem w1936_2 : checkWitness 1936 true false 94 = true := by decide +kernel
private theorem cases1936 : checkFour 1936 (94,0,94,0) = true := by
  simp only [checkFour, w1936_0,w1936_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1936 : Coverage 1936 1937 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1936)
private theorem w1937_0 : checkWitness 1937 false false 621 = true := by decide +kernel
private theorem w1937_1 : checkWitness 1937 false true 4713 = true := by decide +kernel
private theorem w1937_2 : checkWitness 1937 true false 612 = true := by decide +kernel
private theorem w1937_3 : checkWitness 1937 true true 4704 = true := by decide +kernel
private theorem cases1937 : checkFour 1937 (621,4713,612,4704) = true := by
  simp only [checkFour, w1937_0,w1937_1,w1937_2,w1937_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1937 : Coverage 1937 1938 := checkList_sound (ws:=[(621,4713,612,4704)]) (by simpa only [checkList, Bool.and_true] using cases1937)
private theorem w1938_0 : checkWitness 1938 false false 8918 = true := by decide +kernel
private theorem w1938_2 : checkWitness 1938 true false 8909 = true := by decide +kernel
private theorem cases1938 : checkFour 1938 (8918,0,8909,0) = true := by
  simp only [checkFour, w1938_0,w1938_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1938 : Coverage 1938 1939 := checkList_sound (ws:=[(8918,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases1938)
private theorem w1939_0 : checkWitness 1939 false false 8864 = true := by decide +kernel
private theorem w1939_2 : checkWitness 1939 true false 8860 = true := by decide +kernel
private theorem cases1939 : checkFour 1939 (8864,0,8860,0) = true := by
  simp only [checkFour, w1939_0,w1939_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1939 : Coverage 1939 1940 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases1939)
private theorem w1940_0 : checkWitness 1940 false false 88 = true := by decide +kernel
private theorem w1940_2 : checkWitness 1940 true false 88 = true := by decide +kernel
private theorem cases1940 : checkFour 1940 (88,0,88,0) = true := by
  simp only [checkFour, w1940_0,w1940_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1940 : Coverage 1940 1941 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1940)
private theorem w1941_0 : checkWitness 1941 false false 648 = true := by decide +kernel
private theorem w1941_1 : checkWitness 1941 false true 4740 = true := by decide +kernel
private theorem w1941_2 : checkWitness 1941 true false 639 = true := by decide +kernel
private theorem w1941_3 : checkWitness 1941 true true 4731 = true := by decide +kernel
private theorem cases1941 : checkFour 1941 (648,4740,639,4731) = true := by
  simp only [checkFour, w1941_0,w1941_1,w1941_2,w1941_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1941 : Coverage 1941 1942 := checkList_sound (ws:=[(648,4740,639,4731)]) (by simpa only [checkList, Bool.and_true] using cases1941)
private theorem w1942_0 : checkWitness 1942 false false 8925 = true := by decide +kernel
private theorem w1942_2 : checkWitness 1942 true false 8916 = true := by decide +kernel
private theorem cases1942 : checkFour 1942 (8925,0,8916,0) = true := by
  simp only [checkFour, w1942_0,w1942_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1942 : Coverage 1942 1943 := checkList_sound (ws:=[(8925,0,8916,0)]) (by simpa only [checkList, Bool.and_true] using cases1942)
private theorem w1943_0 : checkWitness 1943 false false 72 = true := by decide +kernel
private theorem w1943_2 : checkWitness 1943 true false 72 = true := by decide +kernel
private theorem cases1943 : checkFour 1943 (72,0,72,0) = true := by
  simp only [checkFour, w1943_0,w1943_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1943 : Coverage 1943 1944 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases1943)
private theorem w1944_0 : checkWitness 1944 false false 512 = true := by decide +kernel
private theorem w1944_1 : checkWitness 1944 false true 4608 = true := by decide +kernel
private theorem w1944_2 : checkWitness 1944 true false 512 = true := by decide +kernel
private theorem w1944_3 : checkWitness 1944 true true 4608 = true := by decide +kernel
private theorem cases1944 : checkFour 1944 (512,4608,512,4608) = true := by
  simp only [checkFour, w1944_0,w1944_1,w1944_2,w1944_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1944 : Coverage 1944 1945 := checkList_sound (ws:=[(512,4608,512,4608)]) (by simpa only [checkList, Bool.and_true] using cases1944)
private theorem w1945_0 : checkWitness 1945 false false 8907 = true := by decide +kernel
private theorem w1945_2 : checkWitness 1945 true false 8903 = true := by decide +kernel
private theorem cases1945 : checkFour 1945 (8907,0,8903,0) = true := by
  simp only [checkFour, w1945_0,w1945_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1945 : Coverage 1945 1946 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases1945)
private theorem w1946_0 : checkWitness 1946 false false 638 = true := by decide +kernel
private theorem w1946_1 : checkWitness 1946 false true 4734 = true := by decide +kernel
private theorem w1946_2 : checkWitness 1946 true false 629 = true := by decide +kernel
private theorem w1946_3 : checkWitness 1946 true true 4725 = true := by decide +kernel
private theorem cases1946 : checkFour 1946 (638,4734,629,4725) = true := by
  simp only [checkFour, w1946_0,w1946_1,w1946_2,w1946_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1946 : Coverage 1946 1947 := checkList_sound (ws:=[(638,4734,629,4725)]) (by simpa only [checkList, Bool.and_true] using cases1946)
private theorem w1947_0 : checkWitness 1947 false false 182 = true := by decide +kernel
private theorem w1947_2 : checkWitness 1947 true false 182 = true := by decide +kernel
private theorem cases1947 : checkFour 1947 (182,0,182,0) = true := by
  simp only [checkFour, w1947_0,w1947_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1947 : Coverage 1947 1948 := checkList_sound (ws:=[(182,0,182,0)]) (by simpa only [checkList, Bool.and_true] using cases1947)
private theorem w1948_0 : checkWitness 1948 false false 593 = true := by decide +kernel
private theorem w1948_1 : checkWitness 1948 false true 4681 = true := by decide +kernel
private theorem w1948_2 : checkWitness 1948 true false 593 = true := by decide +kernel
private theorem w1948_3 : checkWitness 1948 true true 4681 = true := by decide +kernel
private theorem cases1948 : checkFour 1948 (593,4681,593,4681) = true := by
  simp only [checkFour, w1948_0,w1948_1,w1948_2,w1948_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1948 : Coverage 1948 1949 := checkList_sound (ws:=[(593,4681,593,4681)]) (by simpa only [checkList, Bool.and_true] using cases1948)
private theorem w1949_0 : checkWitness 1949 false false 8922 = true := by decide +kernel
private theorem w1949_2 : checkWitness 1949 true false 8913 = true := by decide +kernel
private theorem cases1949 : checkFour 1949 (8922,0,8913,0) = true := by
  simp only [checkFour, w1949_0,w1949_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1949 : Coverage 1949 1950 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases1949)
private theorem w1950_0 : checkWitness 1950 false false 90 = true := by decide +kernel
private theorem w1950_2 : checkWitness 1950 true false 90 = true := by decide +kernel
private theorem cases1950 : checkFour 1950 (90,0,90,0) = true := by
  simp only [checkFour, w1950_0,w1950_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1950 : Coverage 1950 1951 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1950)
private theorem w1951_0 : checkWitness 1951 false false 82 = true := by decide +kernel
private theorem w1951_2 : checkWitness 1951 true false 82 = true := by decide +kernel
private theorem cases1951 : checkFour 1951 (82,0,82,0) = true := by
  simp only [checkFour, w1951_0,w1951_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1951 : Coverage 1951 1952 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1951)
theorem cover1920 : Coverage 1920 1952 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1920 one1921) (Coverage.join one1922 one1923)) (Coverage.join (Coverage.join one1924 one1925) (Coverage.join one1926 one1927))) (Coverage.join (Coverage.join (Coverage.join one1928 one1929) (Coverage.join one1930 one1931)) (Coverage.join (Coverage.join one1932 one1933) (Coverage.join one1934 one1935)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1936 one1937) (Coverage.join one1938 one1939)) (Coverage.join (Coverage.join one1940 one1941) (Coverage.join one1942 one1943))) (Coverage.join (Coverage.join (Coverage.join one1944 one1945) (Coverage.join one1946 one1947)) (Coverage.join (Coverage.join one1948 one1949) (Coverage.join one1950 one1951)))))
end NF180PA.Symbolic
