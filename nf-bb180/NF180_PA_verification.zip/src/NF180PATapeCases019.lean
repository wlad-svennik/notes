import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w608_0 : checkWitness 608 false false 712 = true := by decide +kernel
private theorem w608_1 : checkWitness 608 false true 4808 = true := by decide +kernel
private theorem w608_2 : checkWitness 608 true false 712 = true := by decide +kernel
private theorem w608_3 : checkWitness 608 true true 4808 = true := by decide +kernel
private theorem cases608 : checkFour 608 (712,4808,712,4808) = true := by
  simp only [checkFour, w608_0,w608_1,w608_2,w608_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one608 : Coverage 608 609 := checkList_sound (ws:=[(712,4808,712,4808)]) (by simpa only [checkList, Bool.and_true] using cases608)
private theorem w609_0 : checkWitness 609 false false 8974 = true := by decide +kernel
private theorem w609_2 : checkWitness 609 true false 8965 = true := by decide +kernel
private theorem cases609 : checkFour 609 (8974,0,8965,0) = true := by
  simp only [checkFour, w609_0,w609_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one609 : Coverage 609 610 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases609)
private theorem w610_0 : checkWitness 610 false false 74 = true := by decide +kernel
private theorem w610_2 : checkWitness 610 true false 74 = true := by decide +kernel
private theorem cases610 : checkFour 610 (74,0,74,0) = true := by
  simp only [checkFour, w610_0,w610_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one610 : Coverage 610 611 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases610)
private theorem w611_0 : checkWitness 611 false false 556 = true := by decide +kernel
private theorem w611_1 : checkWitness 611 false true 4652 = true := by decide +kernel
private theorem w611_2 : checkWitness 611 true false 556 = true := by decide +kernel
private theorem w611_3 : checkWitness 611 true true 4652 = true := by decide +kernel
private theorem cases611 : checkFour 611 (556,4652,556,4652) = true := by
  simp only [checkFour, w611_0,w611_1,w611_2,w611_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one611 : Coverage 611 612 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases611)
private theorem w612_0 : checkWitness 612 false false 8914 = true := by decide +kernel
private theorem w612_2 : checkWitness 612 true false 8910 = true := by decide +kernel
private theorem cases612 : checkFour 612 (8914,0,8910,0) = true := by
  simp only [checkFour, w612_0,w612_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one612 : Coverage 612 613 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases612)
private theorem w613_0 : checkWitness 613 false false 76 = true := by decide +kernel
private theorem w613_2 : checkWitness 613 true false 76 = true := by decide +kernel
private theorem cases613 : checkFour 613 (76,0,76,0) = true := by
  simp only [checkFour, w613_0,w613_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one613 : Coverage 613 614 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases613)
private theorem w614_0 : checkWitness 614 false false 594 = true := by decide +kernel
private theorem w614_1 : checkWitness 614 false true 4690 = true := by decide +kernel
private theorem w614_2 : checkWitness 614 true false 594 = true := by decide +kernel
private theorem w614_3 : checkWitness 614 true true 4690 = true := by decide +kernel
private theorem cases614 : checkFour 614 (594,4690,594,4690) = true := by
  simp only [checkFour, w614_0,w614_1,w614_2,w614_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one614 : Coverage 614 615 := checkList_sound (ws:=[(594,4690,594,4690)]) (by simpa only [checkList, Bool.and_true] using cases614)
private theorem w615_0 : checkWitness 615 false false 8935 = true := by decide +kernel
private theorem w615_2 : checkWitness 615 true false 8931 = true := by decide +kernel
private theorem cases615 : checkFour 615 (8935,0,8931,0) = true := by
  simp only [checkFour, w615_0,w615_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one615 : Coverage 615 616 := checkList_sound (ws:=[(8935,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases615)
private theorem w616_0 : checkWitness 616 false false 8970 = true := by decide +kernel
private theorem w616_2 : checkWitness 616 true false 8961 = true := by decide +kernel
private theorem cases616 : checkFour 616 (8970,0,8961,0) = true := by
  simp only [checkFour, w616_0,w616_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one616 : Coverage 616 617 := checkList_sound (ws:=[(8970,0,8961,0)]) (by simpa only [checkList, Bool.and_true] using cases616)
private theorem w617_0 : checkWitness 617 false false 100 = true := by decide +kernel
private theorem w617_2 : checkWitness 617 true false 100 = true := by decide +kernel
private theorem cases617 : checkFour 617 (100,0,100,0) = true := by
  simp only [checkFour, w617_0,w617_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one617 : Coverage 617 618 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases617)
private theorem w618_0 : checkWitness 618 false false 682 = true := by decide +kernel
private theorem w618_1 : checkWitness 618 false true 4774 = true := by decide +kernel
private theorem w618_2 : checkWitness 618 true false 673 = true := by decide +kernel
private theorem w618_3 : checkWitness 618 true true 4765 = true := by decide +kernel
private theorem cases618 : checkFour 618 (682,4774,673,4765) = true := by
  simp only [checkFour, w618_0,w618_1,w618_2,w618_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one618 : Coverage 618 619 := checkList_sound (ws:=[(682,4774,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases618)
private theorem w619_0 : checkWitness 619 false false 8931 = true := by decide +kernel
private theorem w619_2 : checkWitness 619 true false 8927 = true := by decide +kernel
private theorem cases619 : checkFour 619 (8931,0,8927,0) = true := by
  simp only [checkFour, w619_0,w619_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one619 : Coverage 619 620 := checkList_sound (ws:=[(8931,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases619)
private theorem w620_0 : checkWitness 620 false false 676 = true := by decide +kernel
private theorem w620_1 : checkWitness 620 false true 4768 = true := by decide +kernel
private theorem w620_2 : checkWitness 620 true false 667 = true := by decide +kernel
private theorem w620_3 : checkWitness 620 true true 4759 = true := by decide +kernel
private theorem cases620 : checkFour 620 (676,4768,667,4759) = true := by
  simp only [checkFour, w620_0,w620_1,w620_2,w620_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one620 : Coverage 620 621 := checkList_sound (ws:=[(676,4768,667,4759)]) (by simpa only [checkList, Bool.and_true] using cases620)
private theorem w621_0 : checkWitness 621 false false 8900 = true := by decide +kernel
private theorem w621_2 : checkWitness 621 true false 8896 = true := by decide +kernel
private theorem cases621 : checkFour 621 (8900,0,8896,0) = true := by
  simp only [checkFour, w621_0,w621_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one621 : Coverage 621 622 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases621)
private theorem w622_0 : checkWitness 622 false false 88 = true := by decide +kernel
private theorem w622_2 : checkWitness 622 true false 88 = true := by decide +kernel
private theorem cases622 : checkFour 622 (88,0,88,0) = true := by
  simp only [checkFour, w622_0,w622_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one622 : Coverage 622 623 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases622)
private theorem w623_0 : checkWitness 623 false false 80 = true := by decide +kernel
private theorem w623_2 : checkWitness 623 true false 80 = true := by decide +kernel
private theorem cases623 : checkFour 623 (80,0,80,0) = true := by
  simp only [checkFour, w623_0,w623_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one623 : Coverage 623 624 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases623)
private theorem w624_0 : checkWitness 624 false false 641 = true := by decide +kernel
private theorem w624_1 : checkWitness 624 false true 4725 = true := by decide +kernel
private theorem w624_2 : checkWitness 624 true false 641 = true := by decide +kernel
private theorem w624_3 : checkWitness 624 true true 4725 = true := by decide +kernel
private theorem cases624 : checkFour 624 (641,4725,641,4725) = true := by
  simp only [checkFour, w624_0,w624_1,w624_2,w624_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one624 : Coverage 624 625 := checkList_sound (ws:=[(641,4725,641,4725)]) (by simpa only [checkList, Bool.and_true] using cases624)
private theorem w625_0 : checkWitness 625 false false 8894 = true := by decide +kernel
private theorem w625_2 : checkWitness 625 true false 8890 = true := by decide +kernel
private theorem cases625 : checkFour 625 (8894,0,8890,0) = true := by
  simp only [checkFour, w625_0,w625_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one625 : Coverage 625 626 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases625)
private theorem w626_0 : checkWitness 626 false false 80 = true := by decide +kernel
private theorem w626_2 : checkWitness 626 true false 80 = true := by decide +kernel
private theorem cases626 : checkFour 626 (80,0,80,0) = true := by
  simp only [checkFour, w626_0,w626_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one626 : Coverage 626 627 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases626)
private theorem w627_0 : checkWitness 627 false false 639 = true := by decide +kernel
private theorem w627_1 : checkWitness 627 false true 4731 = true := by decide +kernel
private theorem w627_2 : checkWitness 627 true false 630 = true := by decide +kernel
private theorem w627_3 : checkWitness 627 true true 4722 = true := by decide +kernel
private theorem cases627 : checkFour 627 (639,4731,630,4722) = true := by
  simp only [checkFour, w627_0,w627_1,w627_2,w627_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one627 : Coverage 627 628 := checkList_sound (ws:=[(639,4731,630,4722)]) (by simpa only [checkList, Bool.and_true] using cases627)
private theorem w628_0 : checkWitness 628 false false 8936 = true := by decide +kernel
private theorem w628_2 : checkWitness 628 true false 8927 = true := by decide +kernel
private theorem cases628 : checkFour 628 (8936,0,8927,0) = true := by
  simp only [checkFour, w628_0,w628_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one628 : Coverage 628 629 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases628)
private theorem w629_0 : checkWitness 629 false false 8882 = true := by decide +kernel
private theorem w629_2 : checkWitness 629 true false 8878 = true := by decide +kernel
private theorem cases629 : checkFour 629 (8882,0,8878,0) = true := by
  simp only [checkFour, w629_0,w629_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one629 : Coverage 629 630 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases629)
private theorem w630_0 : checkWitness 630 false false 74 = true := by decide +kernel
private theorem w630_2 : checkWitness 630 true false 74 = true := by decide +kernel
private theorem cases630 : checkFour 630 (74,0,74,0) = true := by
  simp only [checkFour, w630_0,w630_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one630 : Coverage 630 631 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases630)
private theorem w631_0 : checkWitness 631 false false 666 = true := by decide +kernel
private theorem w631_1 : checkWitness 631 false true 4758 = true := by decide +kernel
private theorem w631_2 : checkWitness 631 true false 657 = true := by decide +kernel
private theorem w631_3 : checkWitness 631 true true 4749 = true := by decide +kernel
private theorem cases631 : checkFour 631 (666,4758,657,4749) = true := by
  simp only [checkFour, w631_0,w631_1,w631_2,w631_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one631 : Coverage 631 632 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases631)
private theorem w632_0 : checkWitness 632 false false 8943 = true := by decide +kernel
private theorem w632_2 : checkWitness 632 true false 8934 = true := by decide +kernel
private theorem cases632 : checkFour 632 (8943,0,8934,0) = true := by
  simp only [checkFour, w632_0,w632_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one632 : Coverage 632 633 := checkList_sound (ws:=[(8943,0,8934,0)]) (by simpa only [checkList, Bool.and_true] using cases632)
private theorem w633_0 : checkWitness 633 false false 58 = true := by decide +kernel
private theorem w633_2 : checkWitness 633 true false 58 = true := by decide +kernel
private theorem cases633 : checkFour 633 (58,0,58,0) = true := by
  simp only [checkFour, w633_0,w633_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one633 : Coverage 633 634 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases633)
private theorem w634_0 : checkWitness 634 false false 530 = true := by decide +kernel
private theorem w634_1 : checkWitness 634 false true 4626 = true := by decide +kernel
private theorem w634_2 : checkWitness 634 true false 530 = true := by decide +kernel
private theorem w634_3 : checkWitness 634 true true 4626 = true := by decide +kernel
private theorem cases634 : checkFour 634 (530,4626,530,4626) = true := by
  simp only [checkFour, w634_0,w634_1,w634_2,w634_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one634 : Coverage 634 635 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases634)
private theorem w635_0 : checkWitness 635 false false 8925 = true := by decide +kernel
private theorem w635_2 : checkWitness 635 true false 8921 = true := by decide +kernel
private theorem cases635 : checkFour 635 (8925,0,8921,0) = true := by
  simp only [checkFour, w635_0,w635_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one635 : Coverage 635 636 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases635)
private theorem w636_0 : checkWitness 636 false false 656 = true := by decide +kernel
private theorem w636_1 : checkWitness 636 false true 4752 = true := by decide +kernel
private theorem w636_2 : checkWitness 636 true false 647 = true := by decide +kernel
private theorem w636_3 : checkWitness 636 true true 4743 = true := by decide +kernel
private theorem cases636 : checkFour 636 (656,4752,647,4743) = true := by
  simp only [checkFour, w636_0,w636_1,w636_2,w636_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one636 : Coverage 636 637 := checkList_sound (ws:=[(656,4752,647,4743)]) (by simpa only [checkList, Bool.and_true] using cases636)
private theorem w637_0 : checkWitness 637 false false 192 = true := by decide +kernel
private theorem w637_2 : checkWitness 637 true false 192 = true := by decide +kernel
private theorem cases637 : checkFour 637 (192,0,192,0) = true := by
  simp only [checkFour, w637_0,w637_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one637 : Coverage 637 638 := checkList_sound (ws:=[(192,0,192,0)]) (by simpa only [checkList, Bool.and_true] using cases637)
private theorem w638_0 : checkWitness 638 false false 611 = true := by decide +kernel
private theorem w638_1 : checkWitness 638 false true 4699 = true := by decide +kernel
private theorem w638_2 : checkWitness 638 true false 611 = true := by decide +kernel
private theorem w638_3 : checkWitness 638 true true 4699 = true := by decide +kernel
private theorem cases638 : checkFour 638 (611,4699,611,4699) = true := by
  simp only [checkFour, w638_0,w638_1,w638_2,w638_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one638 : Coverage 638 639 := checkList_sound (ws:=[(611,4699,611,4699)]) (by simpa only [checkList, Bool.and_true] using cases638)
private theorem w639_0 : checkWitness 639 false false 8940 = true := by decide +kernel
private theorem w639_2 : checkWitness 639 true false 8931 = true := by decide +kernel
private theorem cases639 : checkFour 639 (8940,0,8931,0) = true := by
  simp only [checkFour, w639_0,w639_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one639 : Coverage 639 640 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases639)
theorem cover0608 : Coverage 608 640 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one608 one609) (Coverage.join one610 one611)) (Coverage.join (Coverage.join one612 one613) (Coverage.join one614 one615))) (Coverage.join (Coverage.join (Coverage.join one616 one617) (Coverage.join one618 one619)) (Coverage.join (Coverage.join one620 one621) (Coverage.join one622 one623)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one624 one625) (Coverage.join one626 one627)) (Coverage.join (Coverage.join one628 one629) (Coverage.join one630 one631))) (Coverage.join (Coverage.join (Coverage.join one632 one633) (Coverage.join one634 one635)) (Coverage.join (Coverage.join one636 one637) (Coverage.join one638 one639)))))
end NF180PA.Symbolic
