import NF180PAEquivalence
import NF180PABoundTransport
import NF181PAIndependence

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open PA192.BusyBeaver

namespace NF180PA.FromPublished181

theorem internal_consistency : M6.PA.theory ⊢ (∼H180) 🡒 M6.PA.consistencySentence :=
  transport_nonhalting_implication _ halting_equivalence NF181PA.internal_consistency

theorem busy_beaver (nf : Consistent 𝗡𝗙) :
    (M6.PA.theory ⊬ ∼H180) ∧ (M6.PA.theory ⊬ H180) ∧
    (∀ k : Nat, M6.PA.theory ⊬ upper 180 k) ∧
    ∃ k : Nat, (Nat ⊧/![] (value 180 k)) ∧
      (M6.PA.theory ⊬ value 180 k) ∧ (M6.PA.theory ⊬ ∼(value 180 k)) :=
  busy_beaver_of_equivalence halting_equivalence NF181PA.pa_cannot_prove_nonhalting
    (fun h => NF181PA.runs_forever_of_con_nf nf (NF181PA.H181_standard.mp h))

end NF180PA.FromPublished181
#print axioms NF180PA.FromPublished181.internal_consistency
#print axioms NF180PA.FromPublished181.busy_beaver
