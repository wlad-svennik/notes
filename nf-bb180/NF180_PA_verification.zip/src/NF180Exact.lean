import NF180UnifiedCore
import NF180PATapeAll
namespace NFMachine180
open FFL FFL.FirstOrder NF210 NF180PA
/-- The released 180-state table halts on blank tape iff pure NF proves falsum. -/
theorem halts_iff_nf_refutation : TM.Halts Blank180.Table.machine Blank180.Table.start ↔ (𝗡𝗙 ⊢ ⊥) :=
  halts_iff_nf_refutation_of_coverage Symbolic.literal_table_coverage
end NFMachine180
#print axioms NFMachine180.halts_iff_nf_refutation
