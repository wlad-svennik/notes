# The 180-state NF machine and first-order Peano arithmetic

The binary machine in `machine/NF180.tm` starts in state `k:74` on the all-zero two-way tape. It has 180 working states and one halt transition. It halts exactly when pure Quine NF proves falsum. Its literal halting assertion is the sentence `NF180PA.H180` in the language of first-order Peano arithmetic.

| Lean theorem | Statement |
|---|---|
| `NFMachine180.halts_iff_nf_refutation` | The machine halts on blank tape if and only if pure NF proves falsum. |
| `NF180PA.model_refutation` | In every model of PA, its halting sentence holds exactly when that model contains an internally ranked refutation in the calibrated eight-schema calculus. |
| `NF180PA.halting_equivalence` | PA proves the equivalence of the literal 180-state and 181-state blank-tape halting sentences. |
| `NF180PA.internal_consistency` | PA proves that nonhalting of the 180-state machine implies the usual consistency sentence for PA. |
| `NF180PA.pa_cannot_prove_nonhalting_of_consistent` | Consistency of PA suffices for PA to be unable to prove that the machine runs forever. |
| `NF180PA.pa_independence` | Assuming NF is consistent, PA proves neither sign of the halting sentence and proves no numeral upper bound for the runtime Busy Beaver function at 180 states. |
| `NF180PA.true_value_independent` | Assuming NF is consistent, there is an actual standard value of BB(180) for which PA proves neither the equality to its numeral nor its negation. |

## From the physical run to an internal PA proof

The finite startup reaches a complete register frame after 233,734 transitions. At that point the source instruction is 0, the epoch counter is 5, and the remaining registers are zero. After removing one refill instruction, this computation synchronizes with the published 181-state register program starting at epoch 4. The change of physical decoder lets the actual all-zero tape enter this frame.

The forward simulation covers 2,970 source addresses through 7,792 branch certificates in 93 Lean modules. For the reverse implication, 5,940 checks distinguish each live address from the corresponding next address. This proves progress of the physical clock between live checkpoints. Inductions in an arbitrary PA model then cover that model's own halting times and proof codes, including nonstandard ones. The implication to PA's consistency sentence uses the published proof that absence of an internal ranked refutation gives internal consistency of PA.

A second checked proof, `NF180PA.FromPublished181.busy_beaver`, derives the Busy Beaver conclusion by transferring the published 181-state result through the object-PA halting equivalence. The direct proof uses the 180-state proof search to derive internal consistency. Both routes are included in the final audit.

The axiom audits of the listed results contain only `propext`, `Classical.choice`, and `Quot.sound`. The full machine table has SHA-256 `6540567cb4bef6be14fce422a409338be21afeea73a1a6de856352f03b201a03`.

## Replay

Install Lean 4.35.0 and place `lean` and `lake` on PATH. Run the following inside the extracted directory.

```sh
python3 replay.py --jobs 2 --audit
```

The driver checks the archive manifest, compares all 360 transition rows and the start state with the literal Lean table, obtains the pinned 181-state public archive, restores its dependencies, builds all four endpoint modules and runs the independent audit in `Audit180.lean`. To supply the published verification archive locally, add `--baseline /path/to/NF181_verification.zip`. To replay a single part, give its module explicitly, for example `python3 replay.py --jobs 2 NF180PAModelSearchExact`. The pinned 181-state archive has SHA-256 `ed694fe1be7fc540c8e6248e7caba3d3c7cba24de7837648c65fa31f120be3b1`.

[Published 181-state machine and verification archive](https://github.com/wlad-svennik/notes/tree/261601a9e9998a7b9bf3096ee4589dfda166274b/nf-bb181)
