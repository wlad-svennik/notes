"""Rebuild the 180-state PA modules on the pinned public 181-state foundation."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import shutil
import subprocess
import sys
import urllib.request
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
BASE_SHA='ed694fe1be7fc540c8e6248e7caba3d3c7cba24de7837648c65fa31f120be3b1'
BASE_URL='https://raw.githubusercontent.com/wlad-svennik/notes/261601a9e9998a7b9bf3096ee4589dfda166274b/nf-bb181/NF181_verification.zip'
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('targets',nargs='*', default=['NF180PAIndependence'])
ap.add_argument('--baseline',type=Path,help='local published NF181_verification.zip')
ap.add_argument('--work',type=Path,default=HERE/'replay-work')
ap.add_argument('--jobs',type=int,default=2)
ap.add_argument('--audit',action='store_true',help='build all release endpoints and check their types and axiom dependencies')
args=ap.parse_args()
if args.jobs < 1:
    ap.error('--jobs must be positive')
if args.audit:
    args.targets=list(dict.fromkeys([*args.targets,'NF180PAIndependence','NF180PAModelSearchExact','NF180PAEquivalence','NF180PAPublished181']))
work=args.work.resolve();work.mkdir(parents=True,exist_ok=True)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for row in (HERE/'SHA256SUMS').read_text().splitlines():
    digest,f=row.split('  ',1)
    assert sha(HERE/f)==digest, f
base=args.baseline
if base is None:
    base=work/'NF181_verification.zip'
    if not base.exists():urllib.request.urlretrieve(BASE_URL,base)
assert sha(base)==BASE_SHA, base
old=work/'published181';old.mkdir(exist_ok=True)
with ZipFile(base)as z:z.extractall(old)
with ZipFile(old/'NF182_PA_verification.zip')as z:z.extractall(work)
for folder in [old/'lean',HERE/'src']:
    for f in folder.rglob('*.lean'):
        dest=work/'src'/f.relative_to(folder);dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists() and dest.read_bytes()!=f.read_bytes():
            raise ValueError('source collision: '+str(dest))
        shutil.copyfile(f,dest)
machine_file=HERE/'machine/NF180.tm'
assert sha(machine_file)=='6540567cb4bef6be14fce422a409338be21afeea73a1a6de856352f03b201a03'
formal=(HERE/'src/Blank180Table.lean').read_text()
states=json.loads(re.search(r'^def names : Array String := #(.+)$',formal,re.M).group(1))
start=int(re.search(r'^def start : State := (\d+)$',formal,re.M).group(1))
raw=re.search(r'def raw : List String := (\[.*?\])\s*theorem literal_exact',formal,re.S).group(1)
table='#! start '+states[start]+'\n'+''.join(json.loads(raw))
assert len(states)==180 and table.encode()==machine_file.read_bytes(), 'literal table or start differs from the PA machine'
subprocess.run(['lake','exe','cache','get'],cwd=work,check=True)
subprocess.run(['lake','env',sys.executable,HERE/'build.py',str(args.jobs),*args.targets],cwd=work,check=True)
if args.audit:
    with (HERE/'Audit180.lean').open('rb') as proof:
        subprocess.run(['lake','env','sh','-ec','export LEAN_PATH="$PWD/build${LEAN_PATH:+:$LEAN_PATH}"\nexec lean --stdin'],cwd=work,stdin=proof,check=True)
