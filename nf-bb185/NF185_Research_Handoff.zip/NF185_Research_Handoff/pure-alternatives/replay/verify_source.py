"""Check that a full prefix-address compilation gives the bundled register program."""
import argparse
import json
from pathlib import Path

def check(condition, message):
    if not condition:
        raise ValueError(message)

def graph(rows, *, isolated=False):
    n = len(rows)
    bounds = {}
    paths = [p for p, op, r in rows]
    check(paths == sorted(set(paths)), "input paths are not distinct and sorted")
    for i, path in enumerate(paths):
        for j in range(len(path)+1):
            k = path[:j]
            if k not in bounds:
                bounds[k] = [i, i+1]
            else:
                bounds[k][1] = i+1
    check(len(bounds) == 2*n-1, "input is not a complete binary tree")

    def resolve(path, side, distance):
        for at in range(len(path)-1, -1, -1):
            if path[at] == side:
                distance -= 1
                if distance == 0:
                    first, stop = bounds[path[:at]]
                    return first if side == "1" else (stop if isolated else stop%n)
        raise ValueError(f"unbound jump {path} {side} {distance}")

    result = []
    for i, (path, op, r) in enumerate(rows):
        nxt = i+1 if isolated else (i+1)%n
        if op == "CI":
            result.append((op,r,(nxt,)))
        elif op == "CD":
            result.append((op,r,(resolve(path,"0",1), nxt)))
        elif op in ("CB", "CC"):
            side = "0" if op == "CB" else "1"
            result.append((op,r,(resolve(path,side,r),)))
        else:
            raise ValueError(op)
    return result

def listing(rows):
 g=graph(rows);rs=[]
 for i,(op,k,j) in enumerate(g):
  if op=='CI':line=f'inc {k} {j[0]}'
  elif op=='CD':line=f'decHalt {k} {j[1]}'if rows[i][0].endswith('1')else f'dec {k} {j[0]} {j[1]}'
  else:line=f'jump {j[0]}'
  rs.append(f'{i} '+line)
 return '\n'.join(rs)+'\n'

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder', type=Path)
    folder = parser.parse_args().folder
    rows = json.loads((folder / 'source.sites.json').read_bytes())
    check(listing(rows) == (folder / 'source.register').read_text(), 'register program mismatch')
    print(f'Checked {len(rows)} instructions including all branch destinations.')
