"""Reproduce the two weaker source programs from the verified 185-state table."""
import json
from pathlib import Path


def read_table(path):
    lines = path.read_text().splitlines()
    table = {}
    for line in lines[1:]:
        state, bit, symbol, direction, target = line.split()
        table[state, int(bit)] = (symbol, direction, target)
    return lines[0].split()[-1], table


def rewrite_table(start, original, old, new):
    changed = {}
    for key, (write, direction, target) in original.items():
        changed[key] = (write, direction, new if target == old else target)
    pending = [start]
    live = {start}
    for state in pending:
        for bit in range(2):
            target = changed[state, bit][2]
            if target != 'halt' and target not in live:
                live.add(target)
                pending.append(target)
    return {key: value for key, value in changed.items() if key[0] in live}


def rewrite_source(rows, donor, sites):
    block = [(path[len(donor):], op, arg) for path, op, arg in rows if path.startswith(donor)]
    result = [row for row in rows if not any(row[0].startswith(site) for site in sites)]
    for site in sites:
        result.extend([site + suffix, op, arg] for suffix, op, arg in block)
    return sorted(result)


def main():
    root = Path(__file__).resolve().parents[1]
    start, table = read_table(root / 'baseline-185/candidate.tm')
    rows = json.loads((root / 'baseline-185/source.sites.json').read_bytes())
    for tag in ['ablation-184', 'rejected-183']:
        candidate = root / tag
        recipe = json.loads((candidate / 'rewrite.json').read_bytes())
        changed = rewrite_table(start, table, recipe['removed_state'], recipe['replacement_state'])
        actual_start, actual_table = read_table(candidate / 'candidate.tm')
        if changed != actual_table or start != actual_start:
            raise ValueError(f'Transition mismatch for {tag}')
        source = rewrite_source(rows, recipe['donor_prefix'], recipe['replaced_prefixes'])
        if source != json.loads((candidate / 'source.sites.json').read_bytes()):
            raise ValueError(f'Instruction mismatch for {tag}')
        print(f'{tag} reproduced with {len(changed) // 2} working states and {len(source)} instructions.')


if __name__ == '__main__':
    main()
