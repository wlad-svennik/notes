"""Run the independent C++17 canonical-frame and blank-tape audit."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def convert_table(source, destination):
    lines = source.read_text().splitlines()
    start = next(line.split()[-1] for line in lines if line.startswith('#! start '))
    arcs = [line.split() for line in lines if line.strip() and not line.startswith('#')]
    names = sorted({row[0] for row in arcs})
    ids = {name: index for index, name in enumerate([*names, 'halt'])}
    transitions = {}
    for state, bit, write, direction, target in arcs:
        if (state, bit) in transitions:
            raise ValueError(f'Duplicate transition for {(state, bit)}')
        if bit not in ('0', '1') or write not in ('0', '1') or direction not in ('L', 'R'):
            raise ValueError(f'Invalid transition for {(state, bit)}')
        transitions[state, bit] = (int(write), -1 if direction == 'L' else 1, ids[target])
    if len(transitions) != 2 * len(names) or 'halt' in names:
        raise ValueError('Incomplete table or transitions from the halting state')
    with destination.open('w') as out:
        print(len(names), ids[start], ids['d:0'], ids['k:302'], file=out)
        for state in names:
            for bit in ('0', '1'):
                print(*transitions[state, bit], file=out)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('source', type=Path)
    parser.add_argument('reference', type=Path, help='The reference 196-state table')
    parser.add_argument('--fixtures', type=int, default=24)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reference-source', type=Path, default=Path(__file__).resolve().parents[1]/'reference/counting196.sites.json')
    args = parser.parse_args()

    with tempfile.TemporaryDirectory() as scratch:
        folder = Path(scratch)
        candidate, reference, source = [folder / name for name in ('candidate', 'reference', 'source')]
        convert_table(args.candidate, candidate)
        convert_table(args.reference, reference)
        with source.open('w') as out:
            for row in json.loads(args.source.read_bytes()):
                print(*row, file=out)
        oldsource = folder / 'oldsource'
        with oldsource.open('w') as out:
            for row in json.loads(args.reference_source.read_bytes()):
                print(*row, file=out)
        binary = folder / 'frames'
        subprocess.run([
            os.environ.get('CXX', 'c++'), '-std=c++17', '-O3',
            str(Path(__file__).with_name('frames.cpp')), '-o', str(binary),
        ], check=True)
        process = subprocess.run([
            str(binary), str(source), str(candidate), str(reference), str(args.fixtures), str(oldsource),
        ], check=True, stdout=subprocess.PIPE, text=True)
        receipt = json.loads(process.stdout)
        receipt['sha256'] = {
            'table': digest(args.candidate), 'source': digest(args.source),
            '196_reference': digest(args.reference),
        }
        receipt['scope'] = ('Finite independent full-tape tests at every source address, '
                            'with varied frames, and exact comparisons at boot and the halt gate.')
        args.output.write_text(json.dumps(receipt, indent=2) + '\n')
        print(args.output.read_text(), end='')


if __name__ == '__main__':
    main()
