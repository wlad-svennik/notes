# Replaying the pure NF search candidates

Run the following commands from this directory using Python 3 and a C++17 compiler. Each candidate includes a two-symbol table, the source prefix addresses, the full nine-register control-flow listing, the ordered postfix schema words and a finite replay receipt. All registers and PCs are numbered from zero. A `decHalt` site halts on the zero branch.

```sh
sha256sum -c SHA256SUMS
python3 replay/rebuild_ablations.py
python3 replay/verify_source.py ablation-184
python3 replay/verify_source.py rejected-183
python3 replay/verify_source.py seven-fused-186
python3 replay/verify_source.py diagonal-190
python3 replay/run.py seven-fused-186/candidate.tm seven-fused-186/source.sites.json reference/counting196.tm --fixtures 48 --output /tmp/nf-seven-fused-186.json
python3 replay/run.py diagonal-190/candidate.tm diagonal-190/source.sites.json reference/counting196.tm --fixtures 48 --output /tmp/nf-diagonal-190.json
```

The simulation checks the whole tape at every return to the source interpreter, exercises zero and positive decrements, checks the distinguished halt, and verifies blank startup. The reference table supplies a separate comparison for the halt decision. Each run writes fixture counts, tape steps, startup coordinates and file hashes.

In the schema words, C, D and E push registers 3, 4 and 5. Z pushes zero, + increments the top, A constructs the odd application or equation code, H constructs the witness code and I constructs implication. V and R read the two successive fields. X denotes the 49-instruction diagonal macro in the 2,839-instruction program. The two proof archives each have their own README and pinned build instructions.

The baseline directory contains the verified 185-state literal data. Each ablation has a small rewrite recipe identifying the removed state, its replacement, and the altered source-address prefixes. The rebuild script reproduces both tables and their prefix-address sources directly from the baseline.
