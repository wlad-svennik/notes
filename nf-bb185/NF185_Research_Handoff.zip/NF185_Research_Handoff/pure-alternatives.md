# Pure NF machine search

The verified pure NF record in this work is **185 working states**. Its blank-tape halting theorem is `NFMachine185.halts_iff_nf_refutation`. This note identifies other starting tables and explains which checks each has passed.

| Candidate | Working states | Register instructions | Evidence |
| --- | ---: | ---: | --- |
| Eight-row cross-diagonal tester | 186 | 2,959 | Lean proof of blank-tape halting iff pure NF proves a contradiction |
| Seven-row fused tester and extensionality | 186 | 2,984 | Complete source listing and 48 finite fixtures per instruction |
| Eight rows with four diagonal macros | 190 | 2,839 | Exact match to a Lean-certified register source and 48 finite fixtures per instruction |

## The two 186-state machines

Write `B = JJ`, `K(x) = H(x,x)` and `D(x,y) = (J K(x))y`. The eight-row machine uses `((D(x,y)=B → D(y,y)=B) → y=x)`. For unequal x and y, applying the clause in both orders forces both off-diagonal tests to equal B and both diagonal tests to differ from B. This recovers the previous tester, whose consequent inside the guard uses `D(x,x)`. Lean links the new table to pure NF in `NF198.Cross186.halts_iff_nf_refutation`. Its audit lists the three standard Lean axioms and eleven native-decided finite checks. [Eight-row Lean proof and table](pure-alternatives/NF_Cross_Diagonal_186_Verification.zip)

The seven-row table combines that guard with extensionality. Let `E(x,y)` denote `x H(x,y) = y H(x,y) → x=y`. Its combined row is

```text
(D(x,y)=B → (E(x,y) → D(y,y)=B)) → x=y.
```

When x differs from y, this forces `D(x,y)=B`, `E(x,y)` and `D(y,y)≠B`. When x equals y, extensionality's conclusion already holds. The physical replay checks every source address against the bundled seven-row register program. A Lean link from this particular fused table to pure NF is open. [Seven-row table and source](pure-alternatives/seven-fused-186/)

## Four diagonal macros

The compact source replaces all four occurrences of `push5, push5, witness` by a 49-instruction macro. Each substitution saves 30 instructions. The signed source theorem is `G2839.source_iff_nf_refutation`. Starting with a decoder already containing that macro, we compiled the eight rows in their original order and found a 191-state layout. Transition rewrites yielded the 190-state table. Its decoded instructions, including both targets of each decrement, match the pinned 2,839-instruction listing exactly. An unbounded binary simulation proof for this table is open. [Register proof](pure-alternatives/NF_Eight_Diagonal_2839_Register.zip) · [190-state table and source](pure-alternatives/diagonal-190/)

## What went wrong below 185

One 184-state edit preserved seven rows and replaced extensionality by `y=H(x,y) → x=y`. The surviving clause only restricts the value of H on unequal arguments. Its calibration to pure NF is open. A 183-state edit instead replaced the tester by `((x=y → P) → x=y)`. Peirce's law then derives `x=y` for arbitrary x and y, including the contradiction goal. Full-tape fixture checks can pass for either edit because they test the compiled source as written. [184-state ablation](pure-alternatives/ablation-184/) · [Rejected 183-state table](pure-alternatives/rejected-183/)

For a new candidate, decode the full register program and compare the emitted formulas before drawing conclusions about NF strength. The replay folder includes the source decoder, binary simulator, reference table, recorded results and commands for retesting both candidates. [Replay instructions](pure-alternatives/README.md)
