# Why the 184-state carry candidate fails

The published 185-state machine halts from a blank tape exactly when pure Quine NF proves a contradiction. One transition edit produced a 184-state candidate that passed 141,936 physical instruction fixtures. Its altered proof search can reach the designated goal code 3 by arithmetic on cached formulas. The certified record remains 185 states.

## Replay in Python

From this directory, run the following command with Python 3. It uses the two published inputs in `inputs/` and requires no dependencies.

```sh
python3 replay.py
```

The script verifies the input hashes, reconstructs the candidate, regenerates both register programs, checks the control flow at every surviving instruction and runs the final 91 commands directly through the decoded register instructions. The output matches `replay.txt`. To reconstruct from the distributed release and save the rejected candidate to a new directory, run

```sh
python3 replay.py --release /path/to/NF_Eight_Row_185_Verification.zip --write /tmp/rejected-carry184
```

The `--release` argument also accepts the extracted `NF_Eight_Row_185` directory. The reconstructed table has 184 working states, 368 transitions and SHA-256 `1336d7f52d9dbc56c5000a6fb4eab8bda07ffc113f3482868a71c8c280c88196`.

## The transition and its effect

On symbol 0, state `d:151` formerly wrote 0 and moved right to `d:152`. Redirecting that edge to `d:153` makes `d:152` unreachable. At register level, the change removes the clear-register-5 loop at the published PCs 2943 and 2944. Both countdowns halt on an incoming cache of exactly 3. For a larger cache `h`, the shortened countdown can leave `h − 4` in register 5. The pop routine then adds the next stack entry to that residue.

From the empty command state, issue one `AX(0,0,1,[])`, five `MODE(0)` commands and 91 `NIP` commands. The Lean command for NIP is `.mp 0`. The first six commands leave cache 241 and stack `[122,0]`. The first NIP gives `241 − 4 + 122 = 359`, and the second gives 355. After 88 more NIPs the cache is `355 − 4 × 88 = 3`. The 97th command observes 3. Under the published semantics, the corresponding cache values are 241, 122, 0 and 0. The published machine's command semantics survive this word.

## What was checked

- `CarryGate.lean` imports the published eight-row proof search and defines the shortened NIP/SWAP behavior. The theorem `NF198.CarryGate.halt_without_derivation_input` proves that the 97-command word halts from the empty command state. Two intermediate theorems check the six-command setup and the final cache. The audit in `CarryGate.log` lists propositional extensionality.
- `replay.py` evaluates the eight published row functions for the setup and interprets each affected register instruction during the final 91 commands. It checks the shortened and original register runs independently against the two cache formulas.
- `physical-fixtures.json` records 48 complete physical tape-frame tests at each of the candidate's 2,957 register instructions, including zero and positive gate inputs. Those tests check how the binary executes its changed source. The counterexample concerns the meaning of that source. The Lean theorem here starts at the command interface. A blank-tape halting theorem for the 184-state table is outside its scope.

To replay the Lean check, first build the published 185-state proof from its extracted release directory using the pinned toolchain and the release instructions. With the release proof built in `/tmp/nf185-proof`, run this command from the release directory and supply the path to this folder's Lean file.

```sh
lake env sh -c 'LEAN_PATH="/tmp/nf185-proof:$LEAN_PATH" lean "$1"' sh /path/to/carry/CarryGate.lean
```

For another reduction attempt, preserve the all-input cache invariant at the end of the gate. In particular, test an incoming cache above 4 with a nonzero next stack entry and test at least two consecutive pops.
