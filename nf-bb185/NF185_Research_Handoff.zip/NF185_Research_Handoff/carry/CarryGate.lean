import Eight187Search
namespace NF198.CarryGate
open NF192.Numerical
open NF192.ProofSearch (Command)
open Eight187
/-- The survivor of the shortened four-decrement guard is added to the popped word. -/
def after (c : Command) (s : State) : Option State :=
  match c with
  | .mp d =>
    if s.cache = goal then none else
    let carry := s.cache - 4
    some (match s.param + d with
      | 0 => ⟨s.top, s.stack.tail, s.stack.headD 0 + carry, 0⟩
      | p+1 => ⟨s.cache, s.stack, s.top + carry, p⟩)
  | _ => some (Eight187.step c s)

def run (s : State) : List Command → Option State
  | [] => some s
  | c :: cs => (after c s).bind (fun t => run t cs)

def start : State := ⟨0,[],0,0⟩
def setup : List Command := .ax 0 0 1 [] :: List.replicate 5 (.mode 0)
theorem setup_cache : (run start setup).map (fun s => (s.top,s.stack,s.cache,s.param)) =
    some (0,[122,0],241,0) := by decide
theorem cache_three : (run start (setup ++ List.replicate 90 (.mp 0))).map State.cache = some 3 := by decide
theorem halt_without_derivation_input : run start (setup ++ List.replicate 91 (.mp 0)) = none := by decide
end NF198.CarryGate
#print axioms NF198.CarryGate.halt_without_derivation_input
