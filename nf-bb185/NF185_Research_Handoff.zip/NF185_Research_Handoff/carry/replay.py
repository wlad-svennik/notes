"""Reproduce the rejected carry candidate and its 97-command witness using Python 3."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
BASE_TM = "5504746071e10a0555754b55efc2da348ebfb1f8e8ab5bc7af474eaad81f60fe"
BASE_SITES = "5475cceee03b081dee3eddb77bd721c7130d81cff98be6b98a79272ca912f7ce"
SHORT_TM = "1336d7f52d9dbc56c5000a6fb4eab8bda07ffc113f3482868a71c8c280c88196"
SHORT_SITES = "521be20a09ee9785acf726335b95ab16a6fbf0ff2f6efff4667b5bffb97307be"


def require(test, message):
    if not test:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_inputs(location):
    names = ["candidate.tm", "source.sites.json"]
    if location.is_dir():
        return [(location / name).read_bytes() for name in names]
    with ZipFile(location) as archive:
        return [archive.read("NF_Eight_Row_185/" + name) for name in names]


def shorten_table(data):
    lines = data.decode().splitlines()
    require(lines[0] == "#! start k:64", "Unexpected initial state")
    table = {}
    for raw in lines[1:]:
        q, b, w, direction, target = raw.split()
        table[q, int(b)] = (w, direction, target)
    require(table["d:151", 0] == ("0", "R", "d:152"), "Missing published edge")
    table["d:151", 0] = ("0", "R", "d:153")
    todo = ["k:64"]
    live = set(todo)
    for q in todo:
        for b in (0, 1):
            target = table[q, b][2]
            if target != "halt" and target not in live:
                live.add(target)
                todo.append(target)
    require(len(live) == 184, "Candidate state count")
    result = ["#! start k:64"]
    for q in sorted(live):
        for b in (0, 1):
            result.append(" ".join((q, str(b), *table[q, b])))
    return ("\n".join(result) + "\n").encode()


def shorten_sites(old):
    prefix = "1110"
    eligible = [i for i, (address, _, _) in enumerate(old) if address.startswith(prefix)]
    require(eligible == list(range(2939, 2945)), "Countdown region")
    require([row[1:] for row in old[2939:2945]] ==
            [["CD", 5]] * 5 + [["CC", 1]], "Published countdown")
    four = [[prefix + suffix, "CD", 5] for suffix in ("0", "10", "110", "111")]
    return old[:2939] + four + old[2945:]


def compile_program(rows):
    lo, hi = {}, {}
    for i, (address, _, _) in enumerate(rows):
        for length in range(len(address) + 1):
            prefix = address[:length]
            lo.setdefault(prefix, i)
            hi[prefix] = i + 1
    count = len(rows)
    program = []
    for pc, (address, op, reg) in enumerate(rows):
        nxt = (pc + 1) % count
        if op == "CI":
            program.append(("inc", reg, nxt))
            continue
        if op == "CD" and address.endswith("1"):
            program.append(("halt-on-zero", reg, nxt))
            continue
        back = op == "CC"
        cuts = reg if op in ("CC", "CB") else 1
        prefix = address
        for _ in range(cuts):
            cut = prefix.rfind("1" if back else "0")
            require(cut >= 0, "Unbound register jump")
            prefix = prefix[:cut]
        target = (lo[prefix] if back else hi[prefix]) % count
        program.append(("dec", reg, target, nxt) if op == "CD" else ("jump", target))
    return program


def verify_deletion(before, after):
    def shifted(pc):
        return pc if pc < 2943 else max(2943, pc - 2)
    expected = []
    for pc, instruction in enumerate(before):
        if pc in (2943, 2944):
            continue
        start = 1 if instruction[0] == "jump" else 2
        expected.append((*instruction[:start], *(shifted(v) for v in instruction[start:])))
    require(expected == after, "Changed register behavior outside the deleted loop")


def pair(x, y):
    return (x + y) * (x + y + 1) // 2 + y


def implication(x, y):
    return 2 * pair(x, y)


def eq(x, y):
    return implication(x, y) + 1


def witness(x, y):
    return implication(x, y) + 2


# Published Eight187 row functions. J is zero and JJ is one in the term coding.
def ax_rows(a, b, c, u):
    constant = lambda x: witness(x, x)
    tester = lambda x, y: eq(eq(0, constant(x)), y)
    return [
        implication(implication(implication(c, u), a),
                    implication(implication(a, c), implication(b, c))),
        eq(eq(constant(b), a), b),
        eq(eq(eq(eq(1, c), a), b), eq(eq(c, constant(b)), eq(a, b))),
        implication(eq(c, b), eq(eq(a, c), eq(a, b))),
        implication(eq(a, c), eq(eq(c, b), eq(a, b))),
        implication(eq(a, b), implication(eq(a, c), eq(c, b))),
        implication(implication(eq(1, tester(b, a)), eq(1, tester(b, b))), eq(a, b)),
        implication(eq(eq(b, witness(a, b)), eq(a, witness(a, b))), eq(a, b)),
    ]


def encoded_stack(items):
    encoded = 0
    for value in reversed(items):
        encoded = pair(value, encoded)
    return encoded


def run_nip(program, regs):
    regs = regs.copy()
    pc = 2939
    for ticks in range(1, 200000):
        op, *args = program[pc]
        if op == "jump":
            pc = args[0]
        elif op == "inc":
            reg, pc = args
            regs[reg] += 1
        else:
            reg = args[0]
            if regs[reg]:
                regs[reg] -= 1
                pc = args[-1]
            elif op == "halt-on-zero":
                return True, regs, ticks
            else:
                pc = args[1]
        if pc == 0:
            return False, regs, ticks
    raise ValueError("Register replay exceeded its instruction bound")


def witness_trace(program, altered):
    # AX(0,0,1,[]) puts the penultimate emitted row in the cache, in front
    # of the remaining six rows and the previous top. MODE(0) clears cache
    # before it pops. With zero parameter its resulting top is always zero.
    rows = ax_rows(1, 0, 0, 0)
    cache, stack = rows[-2], [*reversed(rows[:-2]), 0]
    for _ in range(5):
        cache = stack.pop(0)
    require((cache, stack) == (241, [122, 0]), "Setup command effect")
    checkpoint = [cache]
    regs = [0] * 9
    regs[2], regs[5] = encoded_stack(stack), cache
    total_ticks = 0
    for nip in range(1, 92):
        halt, regs, ticks = run_nip(program, regs)
        total_ticks += ticks
        require(halt == (cache == 3), "Disagreement at the goal")
        if halt:
            require(altered and nip == 91, "Unexpected stopping command")
            break
        head = stack.pop(0) if stack else 0
        cache = head + (max(cache - 4, 0) if altered else 0)
        require((regs[2], regs[5], regs[6], regs[7]) ==
                (encoded_stack(stack), cache, 0, 0), "Register replay disagrees with cache arithmetic")
        if nip in (1, 2, 90):
            checkpoint.append(cache)
    require(halt == altered, "Unexpected final result")
    return checkpoint, total_ticks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", type=Path, default=HERE / "inputs",
                        help="published 185-state directory or verification ZIP")
    parser.add_argument("--write", type=Path, help="write the reconstructed rejected table and sites")
    args = parser.parse_args()
    raw, source_data = read_inputs(args.release)
    require((digest(raw), digest(source_data)) == (BASE_TM, BASE_SITES), "Published inputs differ")
    output = shorten_table(raw)
    old = json.loads(source_data)
    new = shorten_sites(old)
    new_sites = (json.dumps(new, separators=(",", ":")) + "\n").encode()
    require((digest(output), digest(new_sites)) == (SHORT_TM, SHORT_SITES), "Reconstruction hash")
    published, shortened = compile_program(old), compile_program(new)
    verify_deletion(published, shortened)
    original, oldticks = witness_trace(published, False)
    changed, newticks = witness_trace(shortened, True)
    require(changed == [241, 359, 355, 3], "Candidate checkpoints")
    print(f"Rejected table: 184 working states, 368 transitions, {len(new):,} register instructions.")
    print("Table SHA-256:", digest(output))
    print("Source SHA-256:", digest(new_sites))
    print("Cache checkpoints after setup and NIPs 1, 2, 90:", *changed)
    print(f"Shortened code halts on command 97. NIP register instructions executed: {newticks:,}.")
    print(f"Published code survives command 97. Original checkpoints: {original}. NIP register instructions: {oldticks:,}.")
    if args.write:
        args.write.mkdir(parents=True, exist_ok=True)
        (args.write / "rejected184.tm").write_bytes(output)
        (args.write / "rejected184.sites.json").write_bytes(new_sites)


if __name__ == "__main__":
    main()
