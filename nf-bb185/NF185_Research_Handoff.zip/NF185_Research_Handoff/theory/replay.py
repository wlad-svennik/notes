"""Check the research lemmas against the pin in NF_Eight_Row_185_Verification.zip."""
from pathlib import Path
import argparse, hashlib, os, shutil, subprocess, sys

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--standalone", action="store_true", help="Check all experiments with Lean Init only")
p.add_argument("--machine-build", required=False, type=Path,
               help="Directory containing CompactRows.olean from the machine bundle")
p.add_argument("--build", default=root / "build", type=Path)
p.add_argument("--lean", default="lean")
args = p.parse_args()
exe = shutil.which(args.lean)
if not exe:
    p.error("Lean executable not found")
if args.standalone:
    work = root / "standalone"
    proc = subprocess.run([exe, "-j", "1", "Check.lean"], cwd=work,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print(proc.stdout, end="")
    if proc.returncode or proc.stdout.strip() != (work / "check.log").read_text().strip():
        sys.exit("Standalone Lean audit differed")
    sys.exit(0)
if not args.machine_build:
    p.error("Provide --standalone or --machine-build")
base = args.machine_build.resolve()
if not (base / "CompactRows.olean").is_file():
    p.error("Run the machine bundle's replay.py before passing its build directory")
build = args.build.resolve()
build.mkdir(parents=True, exist_ok=True)
env = dict(os.environ)
env["LEAN_PATH"] = os.pathsep.join([str(build), str(base), env.get("LEAN_PATH", "")])
for name in ["ProbeCongruence", "TaggedProbe", "GuardedProbe", "StreamingGuard"]:
    src = root / "src" / (name + ".lean")
    if not src.exists(): continue
    run = subprocess.run([exe, "-j", "1", "-s", "131072", "-o",
                          str(build / (name + ".olean")), src.name],
                         cwd=src.parent, env=env, text=True,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(run.stdout, end="")
    (build / (name + ".log")).write_text(run.stdout)
    receipt = (root / "receipts" / (name + ".log")).read_text().strip()
    if run.returncode or run.stdout.strip() != receipt or "sorryAx" in run.stdout:
        sys.exit(f"Check or axiom audit failed for {name}")
print("All research theorem audits matched.")
