import CompactRows
namespace NF198.Probe
open NF192.Ground
structure Rows {X : Type} (S : Signature X) (r : X → X → Prop) : Prop where
  arg : ∀ f x y, r x y → r (S.app f x) (S.app f y)
  cancel : ∀ x y, r (S.k x) (S.k y) → r x y
  k2 : ∀ x d z, r (S.app (S.app (S.k x) d) z) (S.app x z)
  b : ∀ x y z, r (S.app (S.app (S.app S.s x) y) z) (S.app (S.app x (S.k z)) (S.app y z))
  euclid : ∀ x y z, r x y → r x z → r z y
  test : ∀ x y, (r (S.app (S.app S.q (S.k x)) y) S.s →
     r (S.app (S.app S.q (S.k x)) x) S.s) → r x y
  ext : ∀ x y, r (S.app y (S.h x y)) (S.app x (S.h x y)) → r x y
namespace Rows
variable {X : Type} {S : Signature X} {r : X → X → Prop} (R : Rows S r)
local infixl:75 " ⬝ " => S.app
include R

theorem refl (x : X) : r x x := R.test x x id
theorem sym {x y : X} (h : r x y) : r y x := R.euclid x x y (R.refl x) h
theorem trans {x y z : X} (h : r x y) (k : r y z) : r x z := R.euclid y z x k (R.sym h)
theorem extAll {x y : X} (h : ∀ z, r (x ⬝ z) (y ⬝ z)) : r x y := R.ext x y (R.sym (h _))
theorem k1 (x y : X) : r (S.k x ⬝ y) x := R.extAll fun _ => R.k2 .. 

/-- One use of B on a constant argument encodes evaluation at z, lifted by K. -/
theorem probe (f z : X) : r ((((S.s ⬝ S.s) ⬝ S.k (S.k z)) ⬝ f)) (S.k (f ⬝ z)) := by
  apply R.trans (R.b S.s (S.k (S.k z)) f)
  apply R.trans (R.arg (S.s ⬝ S.k f) _ _ (R.k1 (S.k z) f))
  apply R.extAll
  intro u
  apply R.trans (R.b (S.k f) (S.k z) u)
  apply R.trans (R.arg ((S.k f) ⬝ S.k u) _ _ (R.k1 z u))
  exact R.trans (R.k2 f (S.k u) z) (R.sym (R.k1 (f ⬝ z) u))

theorem funCongr {f g : X} (e : r f g) (z : X) : r (f ⬝ z) (g ⬝ z) := by
  apply R.cancel
  exact R.trans (R.sym (R.probe f z)) (R.trans (R.arg _ _ _ e) (R.probe g z))
end Rows

theorem iff_original {X : Type} (S : Signature X) (r : X → X → Prop) :
    Rows S r ↔ NF196.Compact.Rows S r := by
  constructor
  · intro R
    exact ⟨fun a b c => R.arg a c b,fun a b => R.k1 b a,
      fun a b c h => R.funCongr (R.sym h) b,fun a b c => R.b c a b,R.euclid,R.test,R.ext⟩
  · intro R
    refine ⟨fun f x y => R.argCongr f y x,?_,?_,fun x y z => R.bLaw y z x,R.euclid,R.test,R.ext⟩
    · intro x y h
      have p := R.funCongr _ S.q _ (R.rel_symm h)
      exact R.rel_trans (R.rel_symm (R.kLaw S.q x)) (R.rel_trans p (R.kLaw S.q y))
    · intro x d z
      exact R.funCongr _ z _ (R.rel_symm (R.kLaw d x))
end NF198.Probe
#print axioms NF198.Probe.iff_original
