# Pure NF research notes on congruence

The published 185-state machine uses ordinary argument and function congruence. These experiments keep its raw application, diagonal witness, Boolean marker, lifted composition and extensionality. They ask how much explicit congruence the axiom emitter needs. The 185-state verification is independent of these experiments.

## Reconstructing function congruence

Write `Kx = H(x,x)` and let `B` be the lifted composition combinator. The original axioms include `(Kx)d ∼ x` and function congruence `f ∼ g ⇒ fz ∼ gz`. In the first experiment they are replaced by two laws.

1. `Kx ∼ Ky ⇒ x ∼ y`
2. `((Kx)d)z ∼ xz`

Extensionality applied to the second law gives the ordinary constant law. Put `Tz = BB(K(Kz))`. Two applications of lifted composition show `Tz f ∼ K(fz)`. Applying argument congruence to `f ∼ g` gives `K(fz) ∼ K(gz)`. The first law then yields `fz ∼ gz`.

Lean proves this equivalence for every raw relation on every carrier and signature in `NF198.Probe.iff_original`. The theorem has no axiom dependencies.

## Two seven-schema versions

The standalone Lean proof in `standalone/Check.lean` checks the following results against the same eight-schema raw relation. It uses only Lean's `Init` library.

**Tagged singleton test.** Let `Dxy = J(Kx)y`, where `J` is the primitive and `B = JJ`. Keep extended K and replace K reflection and the original singleton test by one schema.

```
(Dxy ∼ B → K(Dxx) ∼ KB) → x ∼ y
```

If `Kx ∼ Ky`, argument congruence implies `J(Kx) ∼ J(Ky)`. The probe then gives `K(Dxx) ∼ K(Dyx)`. Assuming that x and y are inequivalent forces `Dyx ∼ B` while forbidding `K(Dxx) ∼ KB`. Hence K reflects the relation and ordinary function congruence follows. Lean also checks the version with a third variable naming the diagonal output.

**One read inside the guarded K row.** Keep the original singleton test. In place of the original K and function-congruence schemata, use the following row whenever the numerical codes satisfy `x ≤ d`.

```
u ∼ Kx → xz ∼ (u d)z
```

Lean uses the opposite orientation of the conclusion. The original singleton and Euclidean rows already imply reflexivity and symmetry, so either orientation gives the same relation. The postfix emitter puts every occurrence of `x` before the single occurrence of `d`; a read into the same register adds an arbitrary natural to x, supplying every permitted d. For a small argument d, choose a large L. The compound term `(Kd)L` is equivalent to d and its numerical code is at least L. This recovers the unrestricted K law. In the probe, the required argument is a diagonal witness whose code dominates the function code. The theorem `NF192.Numerical.streamed_iff_compact` verifies the argument on the literal Cantor codes, for every raw relation. The full streamed search and physical proof for this experimental emitter remain open.

## Physical experiments

The receipts in `fixtures/` record finite transition checks and blank-tape replays on three experimental tables. The recipe files give the emitted postfix words and their order. They serve as research comparisons. The unbounded theorem about the 185-state machine lives in the machine proof bundle.

| Experimental emitter | Working states | Signed source instructions |
|---|---:|---:|
| K reflection and extended K | 193 | 3065 |
| Tagged singleton test and extended K | 195 | 3028 |
| Single extra-read guarded K row | 193 | 2895 |

These runs give upper bounds for their respective constructions. They establish no lower bound on the number of states.

## Replay

To replay the six standalone axiom audits with Lean 4.35.0, run the following.

```sh
python3 replay.py --standalone
```

For the original-library version of the probe lemma, use the Lean version and Mathlib environment pinned in `NF_Eight_Row_185_Verification.zip` (SHA-256 `baf0832f57f361ea6dfa74e00152421c5eae6a01ae708a6b63892929b54080a4`). Its `src/CompactRows.lean` and transitive imports are the dependencies. After running the archive's own `replay.py`, run the following from its Lean environment.

```sh
python3 replay.py --machine-build /path/to/NF_Eight_Row_185/build
```

The script recompiles the enclosed Lean sources and compares their axiom audits with the recorded receipts. Source and receipt hashes are in `SHA256SUMS`.
