import Init

/-! Self-contained algebraic replay. Signature and Compact.Rows declarations
agree with the corresponding modules in the NF_Eight_Row_185 proof bundle.
The final two order-sensitive proofs below specialize their carrier to Nat. -/
namespace NF192.Ground

universe u

structure Signature (X : Type u) where
  q : X
  app : X → X → X
  h : X → X → X

namespace Signature

variable {X : Type u} (S : Signature X)

def k (a : X) : X := S.h a a
def s : X := S.app S.q S.q
def b : X := S.app S.s S.q

end Signature

end NF192.Ground
open NF192.Ground
namespace NF196.Compact
structure Rows {X : Type} (S : Signature X) (r : X → X → Prop) : Prop where
  argCongr : ∀ a b c, r c b → r (S.app a c) (S.app a b)
  kLaw : ∀ a b, r (S.app (S.k b) a) b
  funCongr : ∀ a b c, r a c → r (S.app c b) (S.app a b)
  bLaw : ∀ a b c, r (S.app (S.app (S.app (S.s) c) a) b)
    (S.app (S.app c (S.k b)) (S.app a b))
  euclid : ∀ a b c, r a b → r a c → r c b
  test : ∀ x y, (r (S.app (S.app S.q (S.k x)) y) S.s → r (S.app (S.app S.q (S.k x)) x) S.s) → r x y
  ext : ∀ a b, r (S.app b (S.h a b)) (S.app a (S.h a b)) → r a b
namespace Rows
variable {X : Type} {S : Signature X} {r : X → X → Prop} (R : Rows S r)
include R
theorem rel_refl (a : X) : r a a :=
  R.euclid _ a a (R.kLaw S.q a) (R.kLaw S.q a)

theorem rel_symm {a b : X} (h : r a b) : r b a :=
  R.euclid a a b (R.rel_refl a) h

theorem rel_trans {a b c : X} (hab : r a b) (hbc : r b c) : r a c :=
  R.euclid b c a hbc (R.rel_symm hab)

theorem app_congr {a b c d : X} (hac : r a c) (hbd : r b d) :
    r (S.app a b) (S.app c d) :=
  R.rel_trans (R.rel_symm (R.funCongr a b c hac)) (R.argCongr c d b hbd)

theorem k_congr {a b : X} (hab : r a b) : r (S.k a) (S.k b) := by
  let d := S.h (S.k a) (S.k b)
  have h : r (S.app (S.k a) d) (S.app (S.k b) d) :=
    R.rel_trans (R.rel_trans (R.kLaw d a) hab) (R.rel_symm (R.kLaw d b))
  exact R.ext (S.k a) (S.k b) (R.rel_symm h)

end Rows
end NF196.Compact
namespace NF198.Probe
open NF192.Ground
structure Rows {X : Type} (S : Signature X) (r : X → X → Prop) : Prop where
  arg : ∀ f x y, r x y → r (S.app f x) (S.app f y)
  cancel : ∀ x y, r (S.k x) (S.k y) → r x y
  k2 : ∀ x d z, r (S.app (S.app (S.k x) d) z) (S.app x z)
  b : ∀ x y z, r (S.app (S.app (S.app S.s x) y) z) (S.app (S.app x (S.k z)) (S.app y z))
  euclid : ∀ x y z, r x y → r x z → r z y
  test : ∀ x y, (r (S.app (S.app S.q (S.k x)) y) S.s →
     r (S.app (S.app S.q (S.k x)) x) S.s) → r x y
  ext : ∀ x y, r (S.app y (S.h x y)) (S.app x (S.h x y)) → r x y
namespace Rows
variable {X : Type} {S : Signature X} {r : X → X → Prop} (R : Rows S r)
local infixl:75 " ⬝ " => S.app
include R

theorem refl (x : X) : r x x := R.test x x id
theorem sym {x y : X} (h : r x y) : r y x := R.euclid x x y (R.refl x) h
theorem trans {x y z : X} (h : r x y) (k : r y z) : r x z := R.euclid y z x k (R.sym h)
theorem extAll {x y : X} (h : ∀ z, r (x ⬝ z) (y ⬝ z)) : r x y := R.ext x y (R.sym (h _))
theorem k1 (x y : X) : r (S.k x ⬝ y) x := R.extAll fun _ => R.k2 .. 

/-- One use of B on a constant argument encodes evaluation at z, lifted by K. -/
theorem probe (f z : X) : r ((((S.s ⬝ S.s) ⬝ S.k (S.k z)) ⬝ f)) (S.k (f ⬝ z)) := by
  apply R.trans (R.b S.s (S.k (S.k z)) f)
  apply R.trans (R.arg (S.s ⬝ S.k f) _ _ (R.k1 (S.k z) f))
  apply R.extAll
  intro u
  apply R.trans (R.b (S.k f) (S.k z) u)
  apply R.trans (R.arg ((S.k f) ⬝ S.k u) _ _ (R.k1 z u))
  exact R.trans (R.k2 f (S.k u) z) (R.sym (R.k1 (f ⬝ z) u))

theorem funCongr {f g : X} (e : r f g) (z : X) : r (f ⬝ z) (g ⬝ z) := by
  apply R.cancel
  exact R.trans (R.sym (R.probe f z)) (R.trans (R.arg _ _ _ e) (R.probe g z))
end Rows

theorem iff_original {X : Type} (S : Signature X) (r : X → X → Prop) :
    Rows S r ↔ NF196.Compact.Rows S r := by
  constructor
  · intro R
    exact ⟨fun a b c => R.arg a c b,fun a b => R.k1 b a,
      fun a b c h => R.funCongr (R.sym h) b,fun a b c => R.b c a b,R.euclid,R.test,R.ext⟩
  · intro R
    refine ⟨fun f x y => R.argCongr f y x,?_,?_,fun x y z => R.bLaw y z x,R.euclid,R.test,R.ext⟩
    · intro x y h
      have p := R.funCongr _ S.q _ (R.rel_symm h)
      exact R.rel_trans (R.rel_symm (R.kLaw S.q x)) (R.rel_trans p (R.kLaw S.q y))
    · intro x d z
      exact R.funCongr _ z _ (R.rel_symm (R.kLaw d x))
end NF198.Probe
#print axioms NF198.Probe.iff_original

namespace NF198.Tagged
open NF192.Ground
structure Rows {X : Type} (S : Signature X) (r : X → X → Prop) : Prop where
  arg : ∀ f x y, r x y → r (S.app f x) (S.app f y)
  k2 : ∀ x d z, r (S.app (S.app (S.k x) d) z) (S.app x z)
  b : ∀ x y z, r (S.app (S.app (S.app S.s x) y) z) (S.app (S.app x (S.k z)) (S.app y z))
  euclid : ∀ x y z, r x y → r x z → r z y
  ext : ∀ x y, r (S.app y (S.h x y)) (S.app x (S.h x y)) → r x y
namespace Rows
variable {X : Type} {S : Signature X} {r : X → X → Prop} (R : Rows S r)
local infixl:75 " ⬝ " => S.app
include R

theorem reflApp (x y : X) : r (x ⬝ y) (x ⬝ y) :=
  R.euclid _ _ _ (R.k2 x S.q y) (R.k2 x S.q y)
theorem refl (x : X) : r x x := R.ext x x (R.reflApp x _)
theorem sym {x y : X} (h : r x y) : r y x := R.euclid x x y (R.refl x) h
theorem trans {x y z : X} (h : r x y) (k : r y z) : r x z := R.euclid y z x k (R.sym h)
theorem extAll {x y : X} (h : ∀ z, r (x ⬝ z) (y ⬝ z)) : r x y := R.ext x y (R.sym (h _))
theorem k1 (x y : X) : r (S.k x ⬝ y) x := R.extAll fun _ => R.k2 .. 

/-- One use of B on a constant argument encodes evaluation at z, lifted by K. -/
theorem probe (f z : X) : r ((((S.s ⬝ S.s) ⬝ S.k (S.k z)) ⬝ f)) (S.k (f ⬝ z)) := by
  apply R.trans (R.b S.s (S.k (S.k z)) f)
  apply R.trans (R.arg (S.s ⬝ S.k f) _ _ (R.k1 (S.k z) f))
  apply R.extAll
  intro u
  apply R.trans (R.b (S.k f) (S.k z) u)
  apply R.trans (R.arg ((S.k f) ⬝ S.k u) _ _ (R.k1 z u))
  exact R.trans (R.k2 f (S.k u) z) (R.sym (R.k1 (f ⬝ z) u))


theorem k_congr {a b : X} (h : r a b) : r (S.k a) (S.k b) :=
  R.extAll fun z => R.trans (R.k1 a z) (R.trans h (R.sym (R.k1 b z)))
theorem probeCongr {a b : X} (h : r a b) (z : X) : r (S.k (a ⬝ z)) (S.k (b ⬝ z)) :=
  R.trans (R.sym (R.probe a z)) (R.trans (R.arg _ _ _ h) (R.probe b z))
end Rows
open Rows
def D {X : Type} (S : Signature X) (x y : X) : X := S.app (S.app S.q (S.k x)) y
def Test {X : Type} (S : Signature X) (r : X → X → Prop) :=
  ∀ x y, (r (D S x y) S.s → r (S.k (D S x x)) (S.k S.s)) → r x y
def Named {X : Type} (S : Signature X) (r : X → X → Prop) :=
  ∀ x y z, r z (D S x x) → (r (D S x y) S.s → r (S.k z) (S.k S.s)) → r x y
theorem iff_original {X : Type} (S : Signature X) (r : X → X → Prop) :
    Rows S r ∧ Test S r ↔ NF196.Compact.Rows S r := by
  constructor
  · rintro ⟨R,t⟩
    have off {x y} (h : ¬r x y) : r (D S x y) S.s := by
      apply Classical.byContradiction
      intro n
      exact h (t x y fun p => False.elim (n p))
    have cancel {x y} (h : r (S.k x) (S.k y)) : r x y := by
      apply Classical.byContradiction
      intro n
      have e := R.probeCongr (R.arg S.q _ _ h) x
      have down := off (fun p => n (R.sym p))
      exact n (t x y fun _ => R.trans e (R.k_congr down))
    apply (NF198.Probe.iff_original S r).mp
    exact ⟨R.arg,fun _ _ => cancel,R.k2,R.b,R.euclid,fun x y f =>
      t x y (fun e => R.k_congr (f e)),R.ext⟩
  · intro R
    have P := (NF198.Probe.iff_original S r).mpr R
    exact ⟨⟨P.arg,P.k2,P.b,P.euclid,P.ext⟩,fun x y h =>
      P.test x y (fun e => P.cancel _ _ (h e))⟩
theorem named_iff {X : Type} (S : Signature X) (r : X → X → Prop) (R : Rows S r) :
    Named S r ↔ Test S r := by
  constructor
  · intro h x y
    exact h x y _ (R.refl _)
  · intro h x y z e t
    exact h x y fun f => R.trans (R.k_congr (R.sym e)) (t f)
end NF198.Tagged
#print axioms NF198.Tagged.iff_original
#print axioms NF198.Tagged.named_iff

namespace NF198.Guarded
open NF192.Ground
structure Rows (S : Signature Nat) (r : Nat → Nat → Prop) : Prop where
  arg : ∀ f x y, r x y → r (S.app f x) (S.app f y)
  guard : ∀ x u d z, x ≤ u → r u (S.k x) → r (S.app (S.app u d) z) (S.app x z)
  b : ∀ x y z, r (S.app (S.app (S.app S.s x) y) z) (S.app (S.app x (S.k z)) (S.app y z))
  euclid : ∀ x y z, r x y → r x z → r z y
  test : ∀ x y, (r (S.app (S.app S.q (S.k x)) y) S.s →
     r (S.app (S.app S.q (S.k x)) x) S.s) → r x y
  ext : ∀ x y, r (S.app y (S.h x y)) (S.app x (S.h x y)) → r x y

theorem iff_original (S : Signature Nat) (r : Nat → Nat → Prop)
    (incr : ∀ x, x ≤ S.k x) : Rows S r ↔ NF196.Compact.Rows S r := by
  constructor
  · intro R
    have relRefl (x) : r x x := R.test x x id
    have symm {x y} : r x y → r y x := R.euclid x x y (relRefl x)
    have trans {x y z} (h : r x y) (k : r y z) : r x z := R.euclid y z x k (symm h)
    have k2 (x d z) := R.guard x (S.k x) d z (incr x) (relRefl _)
    have aux (x y) (hl : x ≤ S.k y) (h : r (S.k y) (S.k x)) : r x y := by
      apply R.ext
      exact trans (symm (k2 y S.q _)) (R.guard x (S.k y) S.q _ hl h)
    have cancel (x y) (h : r (S.k x) (S.k y)) : r x y := by
      rcases Nat.le_total x y with le|le
      · exact aux x y (Nat.le_trans le (incr y)) (symm h)
      · exact symm (aux y x (Nat.le_trans le (incr x)) h)
    exact (NF198.Probe.iff_original S r).mp ⟨R.arg,cancel,k2,R.b,R.euclid,R.test,R.ext⟩
  · intro R
    have Q := (NF198.Probe.iff_original S r).mpr R
    refine ⟨Q.arg,?_,Q.b,Q.euclid,Q.test,Q.ext⟩
    intro x u d z _ h
    exact Q.trans (Q.funCongr (Q.funCongr h d) z) (Q.k2 x d z)
end NF198.Guarded
#print axioms NF198.Guarded.iff_original

namespace NF198.StreamGuard
open NF192.Ground
structure Rows (S : Signature Nat) (r : Nat → Nat → Prop) : Prop where
  arg : ∀ f x y, r x y → r (S.app f x) (S.app f y)
  guard : ∀ x u d z, x ≤ d → r u (S.k x) → r (S.app (S.app u d) z) (S.app x z)
  b : ∀ x y z, r (S.app (S.app (S.app S.s x) y) z) (S.app (S.app x (S.k z)) (S.app y z))
  euclid : ∀ x y z, r x y → r x z → r z y
  test : ∀ x y, (r (S.app (S.app S.q (S.k x)) y) S.s →
     r (S.app (S.app S.q (S.k x)) x) S.s) → r x y
  ext : ∀ x y, r (S.app y (S.h x y)) (S.app x (S.h x y)) → r x y
structure Dom (S : Signature Nat) : Prop where
  left : ∀ x y, x ≤ S.app x y
  right : ∀ x y, y ≤ S.app x y
  witness : ∀ x y, y ≤ S.h x y
namespace Rows
variable {S : Signature Nat} {r : Nat → Nat → Prop} (R : Rows S r)
local infixl:75 " ⬝ " => S.app
include R
theorem refl (x : Nat) : r x x := R.test x x id
theorem sym {x y : Nat} : r x y → r y x := R.euclid x x y (R.refl x)
theorem trans {x y z : Nat} (h : r x y) (k : r y z) : r x z := R.euclid y z x k (R.sym h)
theorem extAll {x y : Nat} (h : ∀ z, r (x ⬝ z) (y ⬝ z)) : r x y := R.ext x y (R.sym (h _))
theorem k2big (x d z : Nat) (e : x ≤ d) : r ((S.k x ⬝ d) ⬝ z) (x ⬝ z) :=
  R.guard x _ d z e (R.refl _)
theorem k1big (x d : Nat) (e : x ≤ d) : r (S.k x ⬝ d) x :=
  R.extAll fun z => R.k2big x d z e
theorem k1 (D : Dom S) (x d : Nat) : r (S.k x ⬝ d) x := by
  let j := max x d
  have h := R.k1big d j (Nat.le_max_right _ _)
  exact R.trans (R.arg (S.k x) _ _ (R.sym h))
    (R.k1big x _ (Nat.le_trans (Nat.le_max_left x d) (D.right _ _)))
theorem cancel {x y : Nat} (e : r (S.k x) (S.k y)) : r x y := by
  let j := max x y
  apply R.extAll
  intro z
  exact R.trans (R.sym (R.guard x (S.k y) j z (Nat.le_max_left _ _) (R.sym e)))
    (R.k2big y j z (Nat.le_max_right _ _))
theorem probe (D : Dom S) (f z : Nat) : r (((S.s ⬝ S.s) ⬝ S.k (S.k z)) ⬝ f) (S.k (f ⬝ z)) := by
  apply R.trans (R.b S.s (S.k (S.k z)) f)
  apply R.trans (R.arg (S.s ⬝ S.k f) _ _ (R.k1 D (S.k z) f))
  let m := (S.s ⬝ S.k f) ⬝ S.k z
  let w := S.h m (S.k (f ⬝ z))
  have chain : f ≤ S.k w := Nat.le_trans (D.left f z) <| Nat.le_trans (D.witness (f ⬝ z) (f ⬝ z))
    <| Nat.le_trans (D.witness m (S.k (f ⬝ z))) (D.witness w w)
  apply R.ext m (S.k (f ⬝ z))
  apply R.sym
  apply R.trans (R.b (S.k f) (S.k z) w)
  apply R.trans (R.arg ((S.k f) ⬝ S.k w) _ _ (R.k1 D z w))
  exact R.trans (R.k2big f (S.k w) z chain) (R.sym (R.k1 D (f ⬝ z) w))
theorem funCongr (D : Dom S) {f g : Nat} (e : r f g) (z : Nat) : r (f ⬝ z) (g ⬝ z) :=
  R.cancel (R.trans (R.sym (R.probe D f z)) (R.trans (R.arg _ _ _ e) (R.probe D g z)))
end Rows
theorem iff_original (S : Signature Nat) (r : Nat → Nat → Prop)
    (D : Dom S) : Rows S r ↔ NF196.Compact.Rows S r := by
  constructor
  · intro R
    exact ⟨fun a b c => R.arg a c b,fun a b => R.k1 D b a,
      fun a b c h => R.funCongr D (R.sym h) b,fun a b c => R.b c a b,R.euclid,R.test,R.ext⟩
  · intro R
    have Q := (NF198.Probe.iff_original S r).mpr R
    refine ⟨Q.arg,?_,Q.b,Q.euclid,Q.test,Q.ext⟩
    intro x u d z _ h
    exact Q.trans (Q.funCongr (Q.funCongr h d) z) (Q.k2 x d z)
end NF198.StreamGuard
#print axioms NF198.StreamGuard.iff_original


namespace NF192.Numerical
def pair (x y : Nat) : Nat := (x + y) * (x + y + 1) / 2 + y
def imp (x y : Nat) : Nat := 2 * pair x y
def eqn (x y : Nat) : Nat := 2 * pair x y + 1
def app (x y : Nat) : Nat := 2 * pair x y + 1
def witness (x y : Nat) : Nat := 2 * pair x y + 2
def konst (x : Nat) : Nat := witness x x
def q : Nat := 0
def s : Nat := app q q
def B : Nat := app s q
def goal : Nat := eqn s q

theorem s_is_one : s = 1 := rfl
theorem B_is_three : B = 3 := rfl
theorem goal_is_three : goal = 3 := rfl
theorem zero_is_self_implication : imp 0 0 = 0 := rfl

theorem triangular_ge (n : Nat) : n ≤ n * (n + 1) / 2 := by
  cases n with
  | zero => decide
  | succ n =>
      apply (Nat.le_div_iff_mul_le (by decide : 0 < 2)).mpr
      exact Nat.mul_le_mul_left (n + 1) (by omega)

theorem pair_ge_left (x y : Nat) : x ≤ pair x y := by
  have h := triangular_ge (x + y)
  unfold pair
  omega

theorem pair_ge_right (x y : Nat) : y ≤ pair x y := by
  unfold pair
  omega


def signature : NF192.Ground.Signature Nat := ⟨q,app,witness⟩
theorem dominates : NF198.StreamGuard.Dom signature := by
  constructor
  · intro x y; change x ≤ 2 * pair x y + 1; have h := pair_ge_left x y; omega
  · intro x y; change y ≤ 2 * pair x y + 1; have h := pair_ge_right x y; omega
  · intro x y; change y ≤ 2 * pair x y + 2; have h := pair_ge_right x y; omega
theorem streamed_iff_compact (r : Nat → Nat → Prop) :
    NF198.StreamGuard.Rows signature r ↔ NF196.Compact.Rows signature r :=
  NF198.StreamGuard.iff_original signature r dominates
end NF192.Numerical
#print axioms NF192.Numerical.streamed_iff_compact
