#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <set>
#include <string>
#include <unordered_set>
#include <vector>
using namespace std; using U=uint64_t;
struct A {int q,d,w;};
struct C {U x;int q,h; bool operator==(const C&b)const{return x==b.x&&q==b.q&&h==b.h;}};
struct Case {C begin,end;int left,right;};
struct H {C c;int id;};
struct Move {int row,action;};
int n,boot,cap=145,seed,rounds;vector<A> arc;vector<int> old,T;vector<Case> cases;vector<vector<H>> touch;
vector<char> edit,exclude; mt19937_64 rg; vector<int> editable;
int action(C c){return 2*c.q+int(c.x>>c.h&1);}
C step(C c,int a){auto e=arc[a];U m=U(1)<<c.h;c.x=e.w?c.x|m:c.x&~m;c.h+=e.d;c.q=e.q;return c;}
bool run(C c,int id,vector<int>* saw=nullptr){auto&s=cases[id];C check=c;int nwait=1,k=1;
 for(int i=0;i<cap;i++){if(c.h<s.left||c.h>=s.right||c.q>=n)return false;
 int r=action(c);if(saw)saw->push_back(r);c=step(c,T[r]);if(c==s.end)return true;if(c==check)return false;if(--nwait==0){check=c;k*=2;nwait=k;}}return false;}
bool indexAll(){
 touch.assign(2*n,{});vector<int> seen(2*n,-1);
 for(int id=0;id<cases.size();id++){auto&s=cases[id];C c=s.begin;bool ok=false;
  for(int i=0;i<cap;i++){if(c.q>=n||c.h<s.left||c.h>=s.right)return false;int r=action(c);
   if(seen[r]!=id){touch[r].push_back({c,id});seen[r]=id;}
   c=step(c,T[r]);if(c==s.end){ok=true;break;}
  }if(!ok)return false;
 }for(auto&v:touch)shuffle(v.begin(),v.end(),rg);return true;}
bool checkHits(int r){for(auto h:touch[r])if(!run(h.c,h.id))return false;return true;}
vector<int> neighbors(int r){
 vector<int>v;if(!edit[r]||touch[r].empty())return v;int sav=T[r];
 for(int a=0;a<4*n;a++){if(a==sav)continue;T[r]=a;if(checkHits(r))v.push_back(a);}
 T[r]=sav;return v;
}
int live(){vector<unsigned char>s(n);vector<int>q{boot};s[boot]=1;for(int i=0;i<q.size();i++)for(int b:{0,1}){int a=T[q[i]*2+b]/4;if(a!=n&&!s[a])s[a]=1,q.push_back(a);}return q.size();}
U hashT(){U u=0;for(int a:T)u=u*0x517cc1b727220a95ULL+(a+1);return u;}
int indeg(int goal){int v=0;for(int r=0;r<2*n;r++)v+=r/2!=goal&&T[r]/4==goal;return v;}
bool win(int round){int sz=live();if(sz>=n)return false;
 cout<<"WIN "<<round<<" "<<sz;for(int r=0;r<2*n;r++)if(T[r]!=old[r])cout<<" "<<r<<" "<<T[r];cout<<endl;return true;}
void init(const string& d){
 ifstream f(d+"/alternate.in"),s(d+"/scenarios"),nf(d+"/editable");f>>n>>boot;arc.resize(4*(n+1));for(int q=0;q<=n;q++)for(int w:{0,1})for(int d:{-1,1})arc[q*4+w*2+(d==1)]={q,d,w};
 int w,dr,q;for(int r=0;r<2*n;r++){f>>w>>dr>>q;old.push_back(q*4+2*w+(dr==1));}T=old;Case v;while(s>>v.begin.q>>v.begin.h>>v.begin.x>>v.end.q>>v.end.h>>v.end.x>>v.left>>v.right)cases.push_back(v);
 edit.assign(2*n,false);exclude.assign(n,true);while(nf>>q){exclude[q]=false;for(int b:{0,1})edit[2*q+b]=true,editable.push_back(2*q+b);}
}
unsigned long long naive=0,duals=0,units=0,game=0;
int main(int ac,char**av){init(av[1]);seed=atoi(av[2]);rounds=atoi(av[3]);int mode=atoi(av[4]);rg.seed(seed);int baseCost=live();vector<vector<int>>bank{T};unordered_set<U>seen{hashT()};int dead=0,goals=0,good=0,bestdist=0;
 int target=-1,age=0,lastIndeg=100,stuck=0;vector<int>lastbase;vector<int>queue;
 for(int it=0;it<rounds;it++){
  if(it==0||age>=28||stuck>8||target<0){T=bank[rg()%bank.size()];target=rg()%n;
   for(int i=0;i<4*n&& (exclude[target]||indeg(target)>4||!indeg(target));i++)target=rg()%n;
   age=0;stuck=0;lastIndeg=indeg(target);goals++;
  }
  if(!indexAll()){auto where=find(bank.begin(),bank.end(),T);if(where!=bank.end()&&where!=bank.begin())bank.erase(where);target=-1;continue;} good++;
  vector<int>in;for(int r:editable)if(r/2!=target&&T[r]/4==target)in.push_back(r);
  vector<Move>costs;for(int r:in){auto v=neighbors(r);naive+=4*n;for(int a:v)if(a/4!=target)costs.push_back({r,a});}
  shuffle(costs.begin(),costs.end(),rg);bool did=false;
  for(auto m:costs){int orig=T[m.row];T[m.row]=m.action;if(seen.insert(hashT()).second){did=true;units++;break;}T[m.row]=orig;}
  if(!did){
   vector<int>rs=editable;shuffle(rs.begin(),rs.end(),rg);
   // Most effort is spent on branches in the direct neighborhood of the target.
   if(mode%2==0&&rg()%5){set<int>q{target};for(int r:in)q.insert(r/2),q.insert(T[r^1]/4);
    for(int b:{0,1})q.insert(T[2*target+b]/4);
    auto pref=[&](int r){return q.count(r/2)||q.count(T[r]/4);};stable_partition(rs.begin(),rs.end(),pref);}
   for(int r:rs){if(r/2==target)continue;auto v=neighbors(r);naive+=4*n;shuffle(v.begin(),v.end(),rg);
    for(int a:v){if(a/4==target)continue;int sav=T[r];T[r]=a;U h=hashT();if(seen.insert(h).second){did=true;break;}T[r]=sav;}
    if(did)break;
   }
  }
  if(!did){dead++;stuck++;continue;}
  if(live()<n){if(indexAll()&&win(it))return 0;target=-1;continue;}
  int cur=indeg(target);if(cur<lastIndeg){stuck=0;lastIndeg=cur;}else stuck++;age++;
  if(rg()%7==0||age==1){if(bank.size()<160)bank.push_back(T);else bank[1+rg()%(bank.size()-1)]=T;}
  if(it%100==0)cerr<<it<<" seen "<<seen.size()<<" options "<<naive<<" targeted "<<units<<" goals "<<goals<<" bank "<<bank.size()<<" dead "<<dead<<endl;
 }cerr<<"DONE "<<good<<" unique "<<seen.size()<<" options "<<naive<<" targeted "<<units<<" goals "<<goals<<" dead "<<dead<<endl;
}
