"""Search from the verified 185-state pure NF machine."""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def materialize(dataset, mutations, output):
    labels = json.loads((dataset / 'alternate.in.labels.json').read_text())
    arcs = {}
    for row in (dataset / 'candidate.tm').read_text().splitlines()[1:]:
        q, b, w, direction, dest = row.split()
        arcs[q, int(b)] = (w, direction, dest)
    fields = mutations.split()
    count = int(fields[2])
    vals = list(map(int, fields[3:]))
    if len(vals) % 2:
        raise ValueError('Incomplete transition pair')
    for row, action in zip(vals[::2], vals[1::2]):
        arcs[labels[row // 2], row % 2] = (str((action // 2) % 2),
                                         'R' if action % 2 else 'L', labels[action // 4])
    active = {'k:64'}
    pending = ['k:64']
    while pending:
        state = pending.pop()
        for bit in (0,1):
            target = arcs[state,bit][2]
            if target != 'halt' and target not in active:
                active.add(target)
                pending.append(target)
    if len(active) != count:
        raise ValueError('Working-state count disagrees with the search output')
    output.write_text('#! start k:64\n' + ''.join(
        f'{q} {bit} {w} {d} {z}\n' for q in sorted(active) for bit in (0,1)
        for w,d,z in [arcs[q,bit]]))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seed',type=int,default=19)
    p.add_argument('--rounds',type=int,default=400)
    p.add_argument('--mode',type=int,choices=(0,1),default=0)
    p.add_argument('--output',type=Path,default=Path('smaller.tm'))
    args = p.parse_args()
    name, states, package = 'data185-eight', 185, 'NF_Eight_Row_185'
    data = ROOT / name
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        binary = work / 'walk'
        subprocess.run(['c++','-std=c++17','-O3',str(ROOT/'search/walk.cpp'),'-o',binary],check=True)
        result = subprocess.run([binary,data,str(args.seed),str(args.rounds),str(args.mode)],
                                stdout=subprocess.PIPE,text=True,check=True)
        hits = [line for line in result.stdout.splitlines() if line.startswith('WIN ')]
        if not hits:
            print('No smaller table found in this run.')
            return
        if args.output.exists():
            raise FileExistsError(args.output)
        materialize(data,hits[0],args.output)
        print(hits[0])
        print('Checking the proposed table against all source addresses.',flush=True)
        with zipfile.ZipFile(ROOT/(package+'_Verification.zip')) as bundle:
            bundle.extractall(work)
        tests = work/package
        framing = tests/'independent/frames.cpp'
        source = framing.read_text()
        marker = f'm.n=={states}&&ref.n==196'
        if source.count(marker)!=1:
            raise ValueError('Unknown independent simulator version')
        framing.write_text(source.replace(marker,'m.n=='+hits[0].split()[2]+'&&ref.n==196'))
        subprocess.run(['python3',tests/'independent/run.py',args.output.resolve(),
                        data/'source.sites.json',tests/'reference/counting196.tm','--fixtures','48','--output',
                        args.output.with_suffix('.receipt.json').resolve()],check=True)
        print('The finite tests passed. A new table still needs its own unbounded simulation proof.')

if __name__ == '__main__':
    main()
