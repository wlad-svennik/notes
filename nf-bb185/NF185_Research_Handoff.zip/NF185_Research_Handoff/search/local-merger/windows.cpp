#include <cstdio>
#include <cstdlib>
#include <deque>
#include <vector>
#include <algorithm>
#include <cstdint>
using namespace std;
struct E{int w,d,t;};
int main(int argc,char**argv){int n,boot; if(scanf("%d%d",&n,&boot)!=2)return 1;vector<E>a(n*2);for(auto&e:a)scanf("%d%d%d",&e.w,&e.d,&e.t);
int rad=atoi(argv[1]),mod=atoi(argv[2]),bits=2*rad+1,dim=1<<bits,mask=dim-1,mid=(1<<rad);size_t size=(size_t)n*mod*dim;vector<uint64_t>seen((size+63)/64);deque<uint64_t> queue;
auto add=[&](uint64_t i){auto&m=seen[i>>6];uint64_t b=1ULL<<(i&63);if(!(m&b)){m|=b;queue.push_back(i);}};
add((uint64_t)boot*mod*dim);size_t count=0;while(!queue.empty()){auto i=queue.front();queue.pop_front();count++;int x=i&mask,p=(i>>bits)%mod,q=(i>>bits)/mod;auto e=a[2*q+!!(x&mid)];if(e.t>=n)continue;int y=(x&~mid)|(e.w<<rad);p=(p+e.d+mod)%mod;y=e.d==1?y>>1:(y<<1)&mask;uint64_t j=((uint64_t)e.t*mod+p)*dim+y;add(j);add(j|(e.d==1?dim>>1:1));}
FILE*f=fopen(argv[3],"wb");int nr=2*n;fwrite(&nr,4,1,f);fwrite(&rad,4,1,f);size_t cells=0;for(int q=0;q<n;q++){vector<int>w[2];for(int word=0;word<dim/64;word++){uint64_t seenword=0;for(int p=0;p<mod;p++)seenword|=seen[((uint64_t)q*mod+p)*(dim/64)+word];while(seenword){int b=__builtin_ctzll(seenword),x=word*64+b;w[!!(x&mid)].push_back(x);seenword&=seenword-1;}}for(auto&v:w){int n=v.size();cells+=n;fwrite(&n,4,1,f);fwrite(v.data(),4,n,f);}}fclose(f);fprintf(stderr,"radius %d modulus %d visits %zu windows %zu\n",rad,mod,count,cells);}
