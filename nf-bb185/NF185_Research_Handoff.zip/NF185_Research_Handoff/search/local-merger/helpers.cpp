#include <algorithm>
#include <array>
#include <bitset>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <vector>
using namespace std;
constexpr int M=1024;
using Bits=bitset<M>;
struct Config {int q,h;uint32_t word;bool operator==(const Config&)const=default;};
struct Path {array<Config,60> items;int size=0;};
struct Menus {Bits bypass;array<array<Bits,2>,4> through;};
struct Result {int zero,one;vector<int> enter;};
int n,start,rad,depth,actions; vector<int> tab;vector<vector<int>> windows;
Config tick(Config c,int action){int w=(action>>1)&1;c.word=(c.word&~(1u<<c.h))|(w<<c.h);c.h+=(action&1)?1:-1;c.q=action/4;return c;}
int row(Config c){return 2*c.q+((c.word>>c.h)&1);}
bool live(Config c){return c.q<n&&c.h>=0&&c.h<=2*rad;}
Path oldpath(Config c,int g,int h){
 Path p;
 for(int j=0;j<depth&&live(c);j++){c=tick(c,tab[row(c)]);if(c.q!=g&&c.q!=h)p.items[p.size++]=c;}
 return p;
}
bool good(Config c,const Path&p,int g,int h){
 for(int j=0;j<depth;j++){
  if(c.q==g||c.q==h)return false;
  for(int k=0;k<p.size;k++)if(c==p.items[k]||(c.q==n&&p.items[k].q==n))return true;
  if(!live(c))return false;
  c=tick(c,tab[row(c)]);
 }
 return false;
}
Bits allowed(int g,int h){Bits b;for(int a=0;a<actions;a++)if(a/4!=g&&a/4!=h)b.set(a);return b;}
Menus filter(int r,int g,int h,int sample){
 auto choices=allowed(g,h);Menus m;m.bypass=choices;for(auto&v:m.through)v={choices,choices};
 for(int j=0;j<int(windows[r].size())&&j<sample;j++){
  Config c{r/2,rad,uint32_t(windows[r][j])};auto old=oldpath(c,g,h);
  if(m.bypass.any())for(int e=m.bypass._Find_first();e<M;e=m.bypass._Find_next(e))if(!good(tick(c,e),old,g,h))m.bypass.reset(e);
  for(int f=0;f<4;f++){auto mid=tick(c,f);int b=(mid.word>>mid.h)&1;auto &v=m.through[f][b];
   if(m.through[f][1-b].none())continue;
   for(int e=v._Find_first();e<M;e=v._Find_next(e))if(!good(tick(mid,e),old,g,h))v.reset(e);
  }
 }
 return m;
}
bool solve(const vector<int>&rows,const vector<Menus>&ms,int g,int h,Result&sol){
 auto allow=allowed(g,h);
 for(int a=allow._Find_first();a<M;a=allow._Find_next(a)){
  Bits left=allow;
  for(int i=0;i<int(rows.size());i++){
   auto &m=ms[i];if((m.bypass&allow).any())continue;
   Bits old;for(auto&z:m.through)if(z[0][a])old|=z[1];left&=old;if(left.none())break;
  }
  if(left.none())continue;int b=left._Find_first();sol={a,b,{}};
  for(auto &m:ms){
   auto s=m.bypass&allow;
   if(s.any()){sol.enter.push_back(s._Find_first());continue;}
   for(int f=0;f<4;f++)if(m.through[f][0][a]&&m.through[f][1][b]){sol.enter.push_back(-1-f);break;}
  }
  return true;
 }return false;
}
bool individual(int r,int g,int h,int first,int a,int b,int j){
 Config c{r/2,rad,uint32_t(windows[r][j])};auto p=oldpath(c,g,h);
 if(first>=0)return good(tick(c,first),p,g,h);
 auto mid=tick(c,-1-first);int bit=(mid.word>>mid.h)&1;
 return good(tick(mid,bit?b:a),p,g,h);
}
int main(int argc,char**argv){
 ifstream t(argv[1]);t>>n>>start;actions=4*(n+1);int w,d,q;while(t>>w>>d>>q)tab.push_back(q*4+w*2+(d==1));
 ifstream f(argv[2],ios::binary);auto get=[&](int&x){f.read((char*)&x,4);};int rcount;get(rcount);get(rad);depth=stoi(argv[3]);int sample=stoi(argv[4]);
 windows.resize(rcount);mt19937 gen(198);for(auto&v:windows){int k;get(k);v.resize(k);f.read((char*)v.data(),4*k);shuffle(v.begin(),v.end(),gen);}
 vector<Menus> pre(rcount);for(int r=0;r<rcount;r++)if(tab[r]/4<n)pre[r]=filter(r,tab[r]/4,-1,sample);
 int pairs=0,loose=0,provisional=0,wins=0;vector<vector<int>> into(n);for(int r=0;r<rcount;r++)if(tab[r]/4<n)into[tab[r]/4].push_back(r);
 for(int g=0;g<n;g++){if(g==start)continue;for(int h=0;h<g;h++){if(h==start)continue;
  vector<int> rows;for(int q:{g,h})for(int r:into[q])if(r/2!=g&&r/2!=h)rows.push_back(r);pairs++;
  vector<Menus> ms;for(int r:rows)ms.push_back(pre[r]);Result sol;if(!solve(rows,ms,g,h,sol))continue;loose++;
  ms.clear();for(int r:rows)ms.push_back(filter(r,g,h,sample));
  if(!solve(rows,ms,g,h,sol))continue;provisional++;
  // CEGIS at fixed g,h. A rejecting tape window removes the bad bypass or
  // second action for this entry choice, and all other failures on that witness.
  bool winner=false;
  for(int it=0;it<50000;it++){
   bool fail=false;
   for(int i=0;i<int(rows.size())&&!fail;i++)for(int j=0;j<int(windows[rows[i]].size());j++){
    int r=rows[i];if(individual(r,g,h,sol.enter[i],sol.zero,sol.one,j))continue;
    fail=true;Config c{r/2,rad,uint32_t(windows[r][j])};auto path=oldpath(c,g,h);auto &m=ms[i];
    for(int e=m.bypass._Find_first();e<M;e=m.bypass._Find_next(e))if(!good(tick(c,e),path,g,h))m.bypass.reset(e);
    for(int f=0;f<4;f++){auto mid=tick(c,f);auto &v=m.through[f][(mid.word>>mid.h)&1];
     for(int e=v._Find_first();e<M;e=v._Find_next(e))if(!good(tick(mid,e),path,g,h))v.reset(e);
    }break;
   }
   if(!fail){winner=true;break;}
   if(!solve(rows,ms,g,h,sol))break;
  }
  if(winner){cout<<"MERGE "<<g<<" "<<h<<" "<<sol.zero<<" "<<sol.one;for(int i=0;i<int(rows.size());i++)cout<<" "<<rows[i]<<" "<<sol.enter[i];cout<<endl;wins++;}
 }}
 cerr<<"pairs "<<pairs<<" one-state relaxation "<<loose<<" two-state sampled "<<provisional<<" all invariant windows "<<wins<<"\n";
}
