from factor import *
import itertools,random,time
from functools import cache
class Multi(Model):
 def __init__(self,src):
  super().__init__(src);self.cuts={};self.node={q:w for q,w in self.word.items()}
  for q,w in self.word.items():
   if q not in self.f:continue
   self.cuts[q]=[]
   for k in range(1,len(w)):
    ls=w[:k];rs=w[k:]
    def options(piece):
     if piece in self.by:return [(p,None) for p in self.by[piece]]
     return [(None,(l,r))for n in range(1,len(piece)) for l in self.by.get(piece[:n],()) for r in self.by.get(piece[n:],())]
    a,b=options(ls),options(rs)
    for (u,v),(x,y)in product(a,b):
     new=frozenset(i for i in [v,y]if i);self.cuts[q].append(((u or v,x or y),new))
 def candidates(self,bans,limit):
  ps=sorted(set(q for z in bans for q,b in self.ins[z])-bans)
  if any(q not in self.f for q in ps):return
  opt=[]
  for q in ps:
   a=[(d,ad)for d,ad in self.cuts[q]if len(ad)<=limit and not any(k in bans for k in d) and all(all(j not in bans for j in t)for t in ad)]
   if not a:return
   opt.append((q,a))
  opt.sort(key=lambda t:len(t[1]))
  def walk(i,pr,extra):
   if i==len(opt):yield pr.copy(),extra;return
   p,ls=opt[i]
   for c,e in ls:
    ne=extra|e
    if len(ne)>limit:continue
    pr[p]=c;yield from walk(i+1,pr,ne)
   pr.pop(p,None)
  yield from walk(0,{},frozenset())
 def material(self,pr,ext):
  name={v:f'refact:{i}'for i,v in enumerate(sorted(ext))}
  pp={q:tuple(name.get(x,x)for x in v)for q,v in pr.items()}
  for v,k in name.items():pp[k]=v
  nt=self.t.copy();nt.update({p:fork(*x)for p,x in pp.items()});return pp,reach(nt)
