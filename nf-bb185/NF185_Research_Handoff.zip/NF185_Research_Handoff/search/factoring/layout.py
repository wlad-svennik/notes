from pathlib import Path
import json,sys,collections
import rotation as rot
def desc(p):
 rows=json.loads((p/'source.sites.json').read_text());tab=rot.actual_table((p/'candidate.tm').read_text());_,ids,_,bounds=rot.build(rows);sts=rot.prefix_states(ids,tab);sp=collections.defaultdict(list)
 for pre,q in sts.items():sp[q].append(pre)
 inputs=collections.defaultdict(list)
 for q,ar in tab.items():
  for b,(_,_,v)in enumerate(ar):inputs[v].append((q,b))
 forks={q for q,ar in tab.items()if all(x==(str(b),'R',x[2])for b,x in enumerate(ar)) and sp[q] and q!='d:0' and not q.startswith('k:') and all(v+'0'in ids for v in sp[q])}
 eligible={q for q in forks if all(pa in forks for pa,b in inputs[q])}
 return rows,tab,sts,sp,inputs,forks,eligible
