from layout import *
from functools import cache
from itertools import product
import hashlib,subprocess,os
def fork(a,b):return(('0','R',a),('1','R',b))
def reach(tab):
 todo=['k:64'];seen=set(todo)
 for q in todo:
  for _,_,z in tab[q]:
   if z!='halt'and z not in seen:todo.append(z);seen.add(z)
 return {q:tab[q]for q in sorted(seen)}
def checks(rows):
 return tuple((op if op in ('CI','CD')else 'CJ',k if op in ('CI','CD')else None,int(op=='CD'and p.endswith('1')),tg)for (p,op,k),tg in zip(rows,rot.targets(rows)))
class Model:
 def __init__(self,src):
  self.src=src;self.rows,self.t,self.st,self.sp,self.ins,f,eligible=desc(src);self.f=f
  self.ph={q:tuple(x[2]for x in self.t[q])for q in f};self.word={};self.paths={};self.offset={}
  def build(q):
   if q not in self.word:
    if q in f:
     l,r=self.ph[q];a,b=build(l),build(r);self.word[q]=a+b;self.paths[q]=tuple('0'+p for p in self.paths[l])+tuple('1'+p for p in self.paths[r])
    else:self.word[q]=(q,);self.paths[q]=('',)
   return self.word[q]
  for q in self.t:build(q)
  self.by=collections.defaultdict(list)
  for q,w in self.word.items():self.by[w].append(q)
  self.opt={}
  for q,w in self.word.items():
   if q not in f:continue
   pairs={self.ph[q]}
   for k in range(1,len(w)):
    for u in self.by.get(w[:k],()):
     for v in self.by.get(w[k:],()):pairs.add((u,v))
   self.opt[q]=sorted(pairs)
  self.graph=checks(self.rows)
  self.rest=[q for q in self.t if q not in f];self.na=0
 def readdress(self,prod):
  @cache
  def newpos(q):
   if q not in self.f and q not in prod:return ('',)
   l,r=prod.get(q,self.ph.get(q));return tuple('0'+p for p in newpos(l))+tuple('1'+p for p in newpos(r))
  mapped={q:newpos(q) for q in self.f};changed={q for q in mapped if mapped[q]!=self.paths[q]}
  @cache
  def trans(p):
   out='';q='d:0';i=0
   while i<len(p):
    if q in changed:
     a=q;j=0
     while a in self.f:
      l,r=self.ph[a];bit=int(p[i]);i+=1
      if bit:j+=len(self.word[l])
      a=(l,r)[bit]
     out+=mapped[q][j];q=a
    else:
     b=int(p[i]);ar=self.t[q][b];out+=p[i];i+=1
     if ar[:2]!=(str(b),'R'):return out+p[i:]
     q=ar[2]
   return out
  return [[trans(p),o,k]for p,o,k in self.rows]
