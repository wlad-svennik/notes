"""Screen sub-185 decoder factorizations at the register level."""
from pathlib import Path
from collections import Counter, deque
from itertools import combinations
import json, sys, random, time, hashlib
R=Path(__file__).resolve().parents[2]
D=Path.cwd()
from multifactor import Multi,checks,rot
base=R/'data185-eight'

def trace(graph,pc,vals,limit):
    frames=set()
    vals=list(vals)
    for _ in range(limit):
        stamp=(pc,tuple(vals))
        if stamp in frames:break
        frames.add(stamp)
        if pc<0:break
        op,r,h,t=graph[pc]
        if op=='CJ':pc=t
        elif op=='CI':vals[r]+=1;pc=(pc+1)%len(graph)
        elif vals[r]>0:vals[r]-=1;pc=(pc+1)%len(graph)
        else:pc=-1 if h else t
    return frames
def guard(graph,value):
    pc=2939;r5=value;seen=set()
    while (pc,r5) not in seen:
        if pc==2945:return 'next' if r5==0 else 'dirty'
        if pc<2939 or pc>2945:return 'escape'
        seen.add((pc,r5))
        op,r,h,t=graph[pc]
        if op=='CJ':pc=t
        elif op=='CI' and r==5:pc+=1;r5+=1
        elif op=='CD' and r==5:
            if r5:r5-=1;pc+=1
            elif h:return 'halt'
            else:pc=t
        else:return 'unknown'
    return 'loop'
def vals(bits):
    return [j for j in range(7) if bits & 1<<j]
def sample(graph,changed,facts,after):
    rng=random.Random(198)
    for i in changed:
        old,new=graph[i],after[i]; op,r,h,t=old
        if op=='CD':
            if (h,t)==new[2:]:continue
            if facts[i] is None or not(facts[i][r]&1):continue
        if facts[i] is None:continue
        for v in range(11):
            regs=[(min if v==0 else max if v==1 else rng.choice)(vals(k)) for k in facts[i]]
            if op=='CD':regs[r]=0
            start=(-1 if h else t)
            nstart=-1 if new[2] else new[3]
            if not(trace(graph,start,regs,55)&trace(after,nstart,regs,55)):
                return i
    return None
def search(host,seed):
    m=Multi(host);rng=random.Random(seed)
    if not (Path(__file__).with_name('base-facts.json')).is_file():
        (Path(__file__).with_name('base-facts.json')).write_text(json.dumps(calc(base,6)))
    facts=json.loads((Path(__file__).with_name('base-facts.json')).read_bytes())
    assert m.graph==checks(json.loads((base/'source.sites.json').read_bytes()))
    ok=sorted(z for z in m.f if all(p in m.f for p,_ in m.ins[z]))
    two=list(combinations(ok,2));three=[z for z in combinations(ok,3) if sum(len(m.ins[q]) for q in z)>len({p for q in z for p,b in m.ins[q]}-set(z))]
    rng.shuffle(three)
    count=Counter();hist=Counter();seen=set();sem=set()
    for bs in [*((x,) for x in ok),*two,*three]:
        for pr,ad in m.candidates(set(bs),len(bs)-1):
            pp,tab=m.material(pr,ad)
            if len(tab)>=185:continue
            sig=tuple(tab.items())
            if sig in seen:continue
            seen.add(sig);count['smaller_tables']+=1
            rows=m.readdress(pp)
            try:g=checks(rows)
            except TypeError:count['jump_outside_tree']+=1;continue
            diff=tuple((i,new)for i,(old,new) in enumerate(zip(m.graph,g))if old!=new)
            if diff in sem:continue
            sem.add(diff);count['distinct_programs']+=1
            resp=[guard(g,v)for v in range(16)]
            key=','.join(str(i)for i,k in enumerate(resp)if k=='halt')
            hist[key]+=1
            oldresp=[guard(m.graph,v)for v in range(16)]
            if any(a!=b for a,b in zip(oldresp,resp)):
                if all(x in ('halt','next') for x in resp) and key not in ('3','5','3,5'):count['gate_diff']+=1;continue
            i=sample(m.graph,[i for i,x in diff],facts,g)
            if i is not None:count['disjoint_local_traces']+=1;continue
            name=hashlib.sha256(repr(sig).encode()).hexdigest()[:16]
            h=D/('candidate-'+name);rot.save_candidate(h,rows,tab);(h/'recipe.json').write_text(json.dumps(pp))
            print('FOLLOW',host.name,h.name,'targets',key,[i for i,x in diff],flush=True);count['follow']+=1
    result={'host':str(host.relative_to(R)),'stats':count,'gate_outputs':hist}
    print(json.dumps(result),flush=True);return result
if __name__=='__main__':
    from concurrent.futures import ProcessPoolExecutor
    full=[base,*sorted((R/'equivalent-layouts').glob('pass-185-*'))]
    hosts=full[int(sys.argv[1]):int(sys.argv[2])]
    if not (Path(__file__).with_name('base-facts.json')).exists():(Path(__file__).with_name('base-facts.json')).write_text(json.dumps(calc(base,6)))
    with ProcessPoolExecutor(2)as ex:
        out=list(ex.map(search,hosts,range(len(hosts))))
    (D/('data-'+sys.argv[1]+'-'+sys.argv[2]+'.json')).write_text(json.dumps(out,indent=2)+'\n')
