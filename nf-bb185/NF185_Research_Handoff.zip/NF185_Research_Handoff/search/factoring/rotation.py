"""Search exact control-flow-preserving reassociations of a Counting selector tree.

Usage: python rotation_search.py EXTRACTED_CHECKPOINT OUTPUT_DIR
No third party modules. Raw subtree count is a source metric. Physical counts
below 201 are only candidates, until the independent physical checks succeed.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

def intern_pair(pool, a, b):
    key=(a,b)
    if key not in pool: pool[key]=len(pool)+10000
    return pool[key]

def build(rows):
    ids={}; leaf_ids={}; pool={}; children={}; boundaries={}
    for i,(p,o,r) in enumerate(rows):
        ids[p]=leaf_ids.setdefault((o,r),len(leaf_ids))
        for n in range(len(p)+1):
            k=p[:n]
            if k not in boundaries: boundaries[k]=[i,i+1]
            else: boundaries[k][1]=i+1
    for p in sorted(boundaries,key=len,reverse=True):
        if p in ids: continue
        l,r=ids[p+'0'],ids[p+'1']; ids[p]=intern_pair(pool,l,r);children[ids[p]]=(l,r)
    return pool,ids,children,boundaries

def actual_table(txt):
    table={}
    for l in txt.splitlines()[1:]:
        q,b,w,d,t=l.split()
        if q not in table: table[q]=[None,None]
        table[q][int(b)]=(w,d,t)
    return {k:tuple(v) for k,v in table.items()}

def next_plain(arc,bit):
    w,d,t=arc
    return t if w==str(bit) and d=='R' else None

def prefix_states(ids,tab):
    states={'':'d:0'}
    for p in sorted(ids,key=len):
        if p not in states or states[p] not in tab:continue
        for b,arc in enumerate(tab[states[p]]):
            target=next_plain(arc,b)
            if target and p+str(b) in ids:
                states[p+str(b)]=target
    return states

def replacement_paths(p,side):
    return [(p+x,p+y) for x,y in ([('00','0'),('01','10'),('1','11')] if side==0 else [('0','00'),('10','01'),('11','1')])]

def rewrite_rows(rows,bounds,sites,side):
    new=list(rows)
    for p in sites:
        for a,b in replacement_paths(p,side):
            i,j=bounds[a]
            for k in range(i,j):
                addr,op,r=rows[k];new[k]=[b+addr[len(a):],op,r]
    return new

def targets(rows):
    l={}; h={}; n=len(rows)
    for i,(p,o,r) in enumerate(rows):
        for k in range(len(p)+1):
            s=p[:k]
            if s not in l:l[s]=i
            h[s]=i+1
    out=[]
    for i,(p,o,r) in enumerate(rows):
        if o=='CI':out.append((i+1)%n);continue
        side='1' if o=='CC' else '0'
        ncuts=r if o in ('CC','CB') else 1
        j=len(p)
        for _ in range(ncuts):
            j=p.rfind(side,0,j)
            if j<0:return None
        out.append(l[p[:j]] if side=='1' else h[p[:j]]%n)
    return out

def save_candidate(folder,rows,table):
    folder.mkdir(exist_ok=True,parents=True)
    (folder/'source.sites.json').write_text(json.dumps(rows,separators=(',',':'))+'\n')
    with (folder/'candidate.tm').open('w') as f:
        print('#! start k:64',file=f)
        for q,ar in table.items():
            for b,(w,d,t) in enumerate(ar):print(q,b,w,d,t,file=f)

