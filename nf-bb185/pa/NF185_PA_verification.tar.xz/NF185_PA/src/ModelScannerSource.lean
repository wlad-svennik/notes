module
public import ModelScanner
public import ModelSourceReach

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
set_option maxHeartbeats 3500000
set_option maxRecDepth 9500
namespace PA192.ModelSearch.ScannerSource
open RegisterFields RegisterSource RegisterCommands Scanner
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- Warm PC10 register boundary. The physical source has the two scratch zeros R6, R7 and the zero R3. -/
noncomputable def view (a : V) := config 10 0 (vector (index a) (top (dataState a))
  (stack (dataState a)) 0 (param (dataState a)) (cache (dataState a)) 0 0 (input a))
instance viewDef : Language.DefinableFunction₁ ℒₒᵣ (view (V:=V)) := by
  unfold view vector index top dataState stack param cache input; definability

theorem terminal_of_reach {x y : V} (h : Reach x y) (fin : sourceHalts y) : sourceHalts x := by
  obtain ⟨i,hi⟩ := h
  obtain ⟨j,hj⟩ := fin
  exact ⟨i+j,by rw [RegisterSource.run_add,hi,hj]⟩

/-- With the concrete PC10 view, the only local requirements are entry, the observed
MODE halt and one nonobserving command, including a possible candidate refill. -/
theorem from_source (start e origin : V) (entry : Reach origin (view (fresh start start e)))
    (onHit : ∀ a : V, observed a → sourceHalts (view a))
    (onLive : ∀ a : V, ¬observed a → Reach (view a) (view (next a)))
    {n : V} (proof : evalCode n=3) : sourceHalts origin := by
  by_contra impossible
  let begin := fresh start start e
  have all : ∀ t : V, Reach origin (view (iterate next t begin)) := by
    apply modelInduct
    · definability
    · simpa [begin] using entry
    · intro t h
      have live : ¬ observed (iterate next t begin) := fun stop =>
        impossible (terminal_of_reach h (onHit _ stop))
      simpa only [iterate_succ] using h.trans (onLive _ live)
  obtain ⟨t,hit⟩ := evaluation_implies_observation proof start e
  exact impossible (terminal_of_reach (all t) (onHit _ hit))

end PA192.ModelSearch.ScannerSource
#print axioms PA192.ModelSearch.ScannerSource.from_source
