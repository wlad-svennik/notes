module
public import ModelExtract
public import ModelSearchCodes

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxHeartbeats 3000000
set_option maxRecDepth 8000
namespace PA192.ModelSearch.Compiler
open RegisterCommands Words
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem obtain_0 (u b c d : V) : Obtainable (row0 (u+d) b c u) := by
  by_cases h : c=0
  · subst c; exact get_0_zero .. 
  · have g : 1≤c := by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne (show 0≤c from zero_le) (Ne.symm h))
    obtain ⟨j,rfl⟩ : ∃ j, c=j+1 := ⟨c-1,(sub_add_self_of_le g).symm⟩
    exact get_0_pos ..

theorem obtain_2 (u b c d : V) : Obtainable (row2 (u+d) b c) := by
  by_cases h : c=0
  · subst c; exact get_2_zero .. 
  · have g : 1≤c := by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne (show 0≤c from zero_le) (Ne.symm h))
    obtain ⟨j,rfl⟩ : ∃ j, c=j+1 := ⟨c-1,(sub_add_self_of_le g).symm⟩
    exact get_2_pos ..

theorem obtain_4 (u b c d : V) : Obtainable (row4 (u+d) b c) := by
  by_cases h : c=0
  · subst c; exact get_4_zero .. 
  · have g : 1≤c := by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne (show 0≤c from zero_le) (Ne.symm h))
    obtain ⟨j,rfl⟩ : ∃ j, c=j+1 := ⟨c-1,(sub_add_self_of_le g).symm⟩
    exact get_4_pos ..

theorem obtain_5 (u b c d : V) : Obtainable (row5 (u+d) b c) := by
  by_cases h : c=0
  · subst c; exact get_5_zero .. 
  · have g : 1≤c := by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne (show 0≤c from zero_le) (Ne.symm h))
    obtain ⟨j,rfl⟩ : ∃ j, c=j+1 := ⟨c-1,(sub_add_self_of_le g).symm⟩
    exact get_5_pos ..

theorem obtain_6 (u b c d : V) : Obtainable (row6 (u+d) b c) := by
  by_cases h : c=0
  · subst c; exact get_6_zero .. 
  · have g : 1≤c := by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne (show 0≤c from zero_le) (Ne.symm h))
    obtain ⟨j,rfl⟩ : ∃ j, c=j+1 := ⟨c-1,(sub_add_self_of_le g).symm⟩
    exact get_6_pos ..

theorem leaves_produce {n p : V} (h : Leaf n p) : Obtainable p := by
  obtain ⟨u,b,c,d,i,_,hr⟩ := h
  rcases hr with h|h|h|h|h|h|h|h|h
  all_goals rcases h with ⟨_,rfl⟩
  · exact obtain_0 ..
  · exact get_1_zero ..
  · exact obtain_2 ..
  · exact get_3_zero ..
  · exact obtain_4 ..
  · exact obtain_5 ..
  · exact obtain_6 ..
  · exact get_7_zero ..
  · exact get_8_zero ..

theorem obtainable_mp {a b : V} (major : Obtainable (imp a b)) (minor : Obtainable a) : Obtainable b := by
  obtain ⟨m,hm⟩ := minor
  obtain ⟨M,hM⟩ := major
  exact ⟨_,produces_mp hm hM⟩

theorem proof_produces {p : V} (h : ProofPool.Pr (∅:V) p) : Obtainable p := by
  apply ProofPool.realize (R:=Obtainable) (h:=h)
  · intro x ax; obtain ⟨n,q⟩ := ax_has_leaf ax; exact leaves_produce q
  · intro x e; simp at e
  · intro a b hM hm; exact obtainable_mp hM hm

theorem zero_produces : Obtainable (0:V) := by
  have h := get_0_zero (0:V) 0 0
  simpa [row0,imp] using h

theorem leafvalue_produces (n : V) : Obtainable (leafValue n) := by
  let w:=right n; let u:=left w; let b:=left (right w)
  let c:=left (right (right w)); let d:=right (right (right w))
  change Obtainable (selectValue (left n) (u+d) b c u)
  unfold selectValue eqTest chooseZero
  by_cases h0 : left n=0
  · simp [h0]; exact obtain_0 ..
  by_cases h1 : left n=1
  · simp [h1,h0]; exact get_1_zero ..
  by_cases h2 : left n=2
  · simp [h2,h0,h1]; exact obtain_2 ..
  by_cases h3 : left n=3
  · simp [h3,h0,h1,h2]; exact get_3_zero ..
  by_cases h4 : left n=4
  · simp [h4,h0,h1,h2,h3]; exact obtain_4 ..
  by_cases h5 : left n=5
  · simp [h5,h0,h1,h2,h3,h4]; exact obtain_5 ..
  by_cases h6 : left n=6
  · simp [h6,h0,h1,h2,h3,h4,h5]; exact obtain_6 ..
  by_cases h7 : left n=7
  · simp [h7,h0,h1,h2,h3,h4,h5,h6]; exact get_7_zero ..
  · simp [h0,h1,h2,h3,h4,h5,h6,h7]; exact get_8_zero ..

theorem all_codes_produce (n : V) : Obtainable (evalCode n) := by
  induction n using Enumeration.strongModel with
  | d => definability
  | step n ih =>
    by_cases hz : n=0
    · subst n
      simpa [evalCode,foldCode,entry,nodeStep,chooseZero] using (zero_produces (V:=V))
    · have hn : 1≤n := by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne (show 0≤n from zero_le) (Ne.symm hz))
      have back : n-1+1=n := sub_add_self_of_le hn
      let q:=n-1; let p:=right q; let l:=left p; let r:=left (right p); let b:=right (right p)
      let F := nodeStep (0:V) leafValue detachValue
      have qlt : q<n := lt_of_lt_of_eq (show q<q+1 from by simp) back
      have p_le : p≤q := Enumeration.right_bounded _
      have left_le (x : V) : left x ≤ x := le_of_le_of_eq (cantor_ge_left (left x) (right x)) (inversePair_correct x)
      have ll : l<n := lt_of_le_of_lt (le_trans (left_le p) p_le) qlt
      have rr : r<n := lt_of_le_of_lt (le_trans (left_le _) (le_trans (Enumeration.right_bounded p) p_le)) qlt
      by_cases ht : left q=0
      · have e : evalCode n=leafValue p := by
          change chooseZero n 0 (chooseZero (left q) (leafValue p) _) = leafValue p
          simp [chooseZero,hz,ht]
        rw [e]; exact leafvalue_produces p
      · have e : evalCode n=detachValue (evalCode l) (evalCode r) b := by
          change F n (table F n)=_
          change chooseZero n 0 (chooseZero (left q) (leafValue p)
            (detachValue (znth (table F n) l) (znth (table F n) r) b))=_
          simp only [chooseZero,hz,ht,↓reduceIte]
          rw [table_lookup F n l ll,table_lookup F n r rr]
          rfl
        rw [e]
        by_cases ok : evalCode r=imp (evalCode l) b
        · simp [detachValue,eqTest,chooseZero,ok]
          exact obtainable_mp (ok ▸ ih r rr) (ih l ll)
        · simp [detachValue,eqTest,chooseZero,ok]
          exact zero_produces

end PA192.ModelSearch.Compiler
#print axioms PA192.ModelSearch.Compiler.proof_produces
#print axioms PA192.ModelSearch.Compiler.all_codes_produce
