module
public import ModelBranch
public import ModelTagClosure

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.ModelSearch PA192.ModelSearch.RegisterFields PA192.ModelSearch.RegisterSource
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000
set_option maxRecDepth 10000

/-- A precise finite assertion for the four external flag/branch combinations at one index. -/
def SiteSound (p : Nat) : Prop := ∀ op, program[p]?=some op → ∀ c z:Bool,
  TagClosure.legal p c=true → TagClosure.allowed op z=true → BranchSound p op c z

theorem root_legal {p : Nat} {f : V} (h : legalTag p f) :
    ∃c : Bool, f=(c.toNat:V) ∧ TagClosure.legal p c=true := by
  rcases h with hz|⟨ho,hp⟩
  · exact ⟨false,by simpa using hz,by simp [TagClosure.legal]⟩
  · exact ⟨true,by simpa using ho,by simp [TagClosure.legal,hp]⟩

theorem chosen_allowed (op : Instr) (z : Bool) (r : V) (h : choiceOk op z r) : TagClosure.allowed op z=true := by
  cases op with
  | dec _ _ _ => rfl
  | inc _ _ | jump _ => have hz : z=false := h; simp [TagClosure.allowed,hz]

theorem admissible {p : Fin 3089} (op : Instr) (h : program[p.val]?=some op) (c z : Bool)
    (l : TagClosure.legal p.val c=true) (a : TagClosure.allowed op z=true) : AdmissibleExit op c z := by
  have cl := TagClosure.closed p op h c z l a
  have d : TagClosure.next op z=dest op z := by cases op <;> rfl
  have f : TagClosure.cold' op c=exitCold op c := by cases op with | inc i k => cases i <;> rfl | _ => rfl
  rw [d,f] at cl
  rcases cl with st | ⟨b,leg⟩
  · exact Or.inl st
  · exact Or.inr ⟨b,by simpa [TagClosure.legal] using leg⟩

theorem site_to_row (p : Fin 3089) (site : SiteSound p.val) : RowSim (V:=V) p.val := by
  rintro s raw ⟨addressEq,legal,g,k,frameEq⟩
  obtain ⟨op,ins⟩ := TagClosure.instruction_at p
  obtain ⟨c,ce,lc⟩ := root_legal legal
  obtain ⟨z,pick⟩ := chooseCase op (registers s)
  have allow := chosen_allowed op z (registers s) pick
  obtain ⟨t,good⟩ := site op ins c z lc allow
  have hit := branch_step p.val op c z t good ins (admissible op ins c z lc allow) (registers s) g k pick
  have packBack : config (address s) (cold s) (registers s)=s := by simp [config,address,cold,registers]
  have same : config (p.val:V) (c.toNat:V) (registers s)=s := by simpa [addressEq,ce] using packBack
  rw [same] at hit
  simpa only [frameEq,ce] using hit

theorem h192_of_sites (allSites : ∀ p : Fin 3089, SiteSound p.val)
    (source : sourceHalts (coldMargin:V)) : V ⊧/![] PA192.LiteralTM.H192 :=
  margin_from_rows (fun p => site_to_row p (allSites p)) source

namespace Replay

def timing : Equation → Option Term
| ⟨.un .norm (.bin .run t _),_⟩ | ⟨.un .state (.bin .run t _),_⟩ => some t | _ => none

/-- The binder reconstructs the expected shape independently from the actual signed instruction.
An input declaration supplies only its time expression and its proof. -/
def checkCase (s : Store NF192.Selected.machine) (p : Nat) (op : Instr) (c z : Bool) (index : Nat) :
    Option (PLift (BranchSound p op c z)) := do
  let decl ← s.declarations[index]?
  let t ← timing decl.fact.claim
  let h ← verified 1 s index (branchStatement p op c z t)
  return ⟨⟨t,h.down⟩⟩

def checkBools {P : Bool→Prop} (f : (b : Bool) → Option (PLift (P b))) : Option (PLift (∀b,P b)) := do
  let l ← f false; let r ← f true
  return ⟨fun b => b.rec l.down r.down⟩

structure Location where
  pc : Nat
  warmPos : Nat
  warmZero : Nat
  coldPos : Nat
  coldZero : Nat
  deriving Inhabited,DecidableEq

def Location.index (l : Location) (c z : Bool) := if c then (if z then l.coldZero else l.coldPos)
  else (if z then l.warmZero else l.warmPos)

def checkSite (s : Store NF192.Selected.machine) (l : Location) : Option (PLift (SiteSound l.pc)) := do
  match h : program[l.pc]? with
  | none => none
  | some op =>
    let checks ← checkBools (P:=fun c => ∀z, TagClosure.legal l.pc c=true → TagClosure.allowed op z=true → BranchSound l.pc op c z)
      (fun c => checkBools (P:=fun z => TagClosure.legal l.pc c=true → TagClosure.allowed op z=true → BranchSound l.pc op c z)
        (fun z => if a : TagClosure.legal l.pc c=true ∧ TagClosure.allowed op z=true then do
          let out ← checkCase s l.pc op c z (l.index c z)
          return ⟨fun _ _ => out.down⟩
        else some ⟨fun hl ha => False.elim (a ⟨hl,ha⟩)⟩))
    return ⟨by
      intro other ho
      have eq : other=op := Option.some.inj (ho.symm.trans h)
      subst other
      exact checks.down⟩

def checkSites (s : Store NF192.Selected.machine) :
    (ls : List Location) → Option (PLift (∀ l∈ls, SiteSound l.pc))
  | [] => some ⟨by simp⟩
  | l::ls => do
    let h ← checkSite s l
    let t ← checkSites s ls
    return ⟨by
      intro p hp
      rcases List.mem_cons.mp hp with eq|rest
      · exact eq ▸ h.down
      · exact t.down _ rest⟩

end Replay
end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.h192_of_sites
#print axioms PA192.PhysicalModel.Replay.checkSites
