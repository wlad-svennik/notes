module
public import ModelCmdEmit05
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter193 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((969:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom31 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0966 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom31 n t s c u v y d w) w
  have d2 : (0+(atom31 n t s c u v y d w):V)=atom31 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter192 f n t s c u v y d w).trans mid

theorem commandEmitAfter194 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((979:Nat):V) f (vector n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) 0 (atom35 n t s c u v y d w) w)) := by
  have micro := site0969 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom31 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=atom35 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=0+(atom35 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter193 f n t s c u v y d w).trans mid

theorem commandEmitAfter195 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((983:Nat):V) f (vector n ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0979 f n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) 0 (atom35 n t s c u v y d w) w
  have d1 : (0+(2*(atom35 n t s c u v y d w)):V)=(atom35 n t s c u v y d w)+(atom35 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom35 n t s c u v y d w)):V)=0+((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter194 f n t s c u v y d w).trans mid

theorem commandEmitAfter196 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((984:Nat):V) f (vector n ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0983 f n ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w))+1:V)=(atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter195 f n t s c u v y d w).trans mid

theorem commandEmitAfter197 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((992:Nat):V) f (vector n ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom28 n t s c u v y d w) w)) := by
  have micro := site0984 f n ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom31 n t s c u v y d w)):V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom31 n t s c u v y d w):V)=0+(atom31 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom31 n t s c u v y d w)):V)=left (atom31 n t s c u v y d w)).trans (by change left (cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom28 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom31 n t s c u v y d w)):V)=atom28 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom31 n t s c u v y d w):V)=0+(atom31 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom31 n t s c u v y d w)):V)=right (atom31 n t s c u v y d w)).trans (by change right (cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom28 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter196 f n t s c u v y d w).trans mid

theorem commandEmitAfter198 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((995:Nat):V) f (vector n ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1) (atom28 n t s c u v y d w) c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0992 f n ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom28 n t s c u v y d w) w
  have d2 : (0+(atom28 n t s c u v y d w):V)=atom28 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter197 f n t s c u v y d w).trans mid

theorem commandEmitAfter199 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1005:Nat):V) f (vector n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) 0 (atom36 n t s c u v y d w) w)) := by
  have micro := site0995 f n ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1) (atom28 n t s c u v y d w) c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1)):V)=atom36 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1)):V)=0+(atom36 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter198 f n t s c u v y d w).trans mid

theorem commandEmitAfter200 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1009:Nat):V) f (vector n ((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)) (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1005 f n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) 0 (atom36 n t s c u v y d w) w
  have d1 : (0+(2*(atom36 n t s c u v y d w)):V)=(atom36 n t s c u v y d w)+(atom36 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom36 n t s c u v y d w)):V)=0+((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter199 f n t s c u v y d w).trans mid

theorem commandEmitAfter201 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1012:Nat):V) f (vector n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) ((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)) 0 w)) := by
  have micro := site1009 f n ((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)) (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)):V)=(atom36 n t s c u v y d w)+(atom36 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter200 f n t s c u v y d w).trans mid

theorem commandEmitAfter202 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1015:Nat):V) f (vector n (atom28 n t s c u v y d w) 0 c (d+u) (v+y) ((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)) 0 w)) := by
  have micro := site1012 f n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) ((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)) 0 w
  have d1 : (0+(atom28 n t s c u v y d w):V)=atom28 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter201 f n t s c u v y d w).trans mid

theorem commandEmitAfter203 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1025:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom37 n t s c u v y d w) w)) := by
  have micro := site1015 f n (atom28 n t s c u v y d w) 0 c (d+u) (v+y) ((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)) (atom28 n t s c u v y d w)):V)=atom37 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)) (atom28 n t s c u v y d w)):V)=0+(atom37 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter202 f n t s c u v y d w).trans mid

theorem commandEmitAfter204 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1028:Nat):V) f (vector n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1025 f n 0 0 c (d+u) (v+y) 0 (atom37 n t s c u v y d w) w
  have d2 : (0+(atom37 n t s c u v y d w):V)=atom37 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter203 f n t s c u v y d w).trans mid

theorem commandEmitAfter205 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1032:Nat):V) f (vector n (v+y) (atom37 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1028 f n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter204 f n t s c u v y d w).trans mid

theorem commandEmitAfter206 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1035:Nat):V) f (vector n (v+y) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1032 f n (v+y) (atom37 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter205 f n t s c u v y d w).trans mid

theorem commandEmitAfter207 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1038:Nat):V) f (vector n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1035 f n (v+y) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter206 f n t s c u v y d w).trans mid

theorem commandEmitAfter208 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1041:Nat):V) f (vector n (atom37 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1038 f n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d1 : (0+(atom37 n t s c u v y d w):V)=atom37 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter207 f n t s c u v y d w).trans mid

theorem commandEmitAfter209 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1051:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom38 n t s c u v y d w) w)) := by
  have micro := site1041 f n (atom37 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w
  have d7 : (0+(cantor (v+y) (atom37 n t s c u v y d w)):V)=atom38 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (v+y) (atom37 n t s c u v y d w)):V)=0+(atom38 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter208 f n t s c u v y d w).trans mid

theorem commandEmitAfter210 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1054:Nat):V) f (vector n 0 (atom38 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1051 f n 0 0 c (d+u) (v+y) 0 (atom38 n t s c u v y d w) w
  have d2 : (0+(atom38 n t s c u v y d w):V)=atom38 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter209 f n t s c u v y d w).trans mid

theorem commandEmitAfter211 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1058:Nat):V) f (vector n (v+y) (atom38 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1054 f n 0 (atom38 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter210 f n t s c u v y d w).trans mid

theorem commandEmitAfter212 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1061:Nat):V) f (vector n (v+y) (atom38 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1058 f n (v+y) (atom38 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter211 f n t s c u v y d w).trans mid

theorem commandEmitAfter213 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1069:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (v+y) (atom37 n t s c u v y d w) w)) := by
  have micro := site1061 f n (v+y) (atom38 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom38 n t s c u v y d w)):V)=v+y := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom38 n t s c u v y d w):V)=0+(atom38 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom38 n t s c u v y d w)):V)=left (atom38 n t s c u v y d w)).trans (by change left (cantor (v+y) (atom37 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom38 n t s c u v y d w)):V)=atom37 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom38 n t s c u v y d w):V)=0+(atom38 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom38 n t s c u v y d w)):V)=right (atom38 n t s c u v y d w)).trans (by change right (cantor (v+y) (atom37 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter212 f n t s c u v y d w).trans mid

theorem commandEmitAfter214 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1072:Nat):V) f (vector n (v+y) (atom37 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1069 f n (v+y) 0 c (d+u) (v+y) (v+y) (atom37 n t s c u v y d w) w
  have d2 : (0+(atom37 n t s c u v y d w):V)=atom37 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter213 f n t s c u v y d w).trans mid

theorem commandEmitAfter215 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1082:Nat):V) f (vector n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) 0 (atom39 n t s c u v y d w) w)) := by
  have micro := site1072 f n (v+y) (atom37 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d7 : (0+(cantor (v+y) (v+y)):V)=atom39 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (v+y) (v+y)):V)=0+(atom39 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter214 f n t s c u v y d w).trans mid

theorem commandEmitAfter216 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1086:Nat):V) f (vector n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1082 f n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) 0 (atom39 n t s c u v y d w) w
  have d1 : (0+(2*(atom39 n t s c u v y d w)):V)=(atom39 n t s c u v y d w)+(atom39 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom39 n t s c u v y d w)):V)=0+((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter215 f n t s c u v y d w).trans mid

theorem commandEmitAfter217 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1087:Nat):V) f (vector n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+1) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1086 f n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w))+1:V)=(atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter216 f n t s c u v y d w).trans mid

theorem commandEmitAfter218 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1088:Nat):V) f (vector n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1087 f n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+1) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+1)+1:V)=(atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter217 f n t s c u v y d w).trans mid

theorem commandEmitAfter219 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1091:Nat):V) f (vector n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) 0 w)) := by
  have micro := site1088 f n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2):V)=(atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter218 f n t s c u v y d w).trans mid

theorem commandEmitAfter220 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1094:Nat):V) f (vector n (atom37 n t s c u v y d w) 0 c (d+u) (v+y) ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) 0 w)) := by
  have micro := site1091 f n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) 0 w
  have d1 : (0+(atom37 n t s c u v y d w):V)=atom37 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter219 f n t s c u v y d w).trans mid

theorem commandEmitAfter221 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1104:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom40 n t s c u v y d w) w)) := by
  have micro := site1094 f n (atom37 n t s c u v y d w) 0 c (d+u) (v+y) ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) 0 w
  have d7 : (0+(cantor ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom37 n t s c u v y d w)):V)=atom40 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom37 n t s c u v y d w)):V)=0+(atom40 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter220 f n t s c u v y d w).trans mid

theorem commandEmitAfter222 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1107:Nat):V) f (vector n 0 (atom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1104 f n 0 0 c (d+u) (v+y) 0 (atom40 n t s c u v y d w) w
  have d2 : (0+(atom40 n t s c u v y d w):V)=atom40 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter221 f n t s c u v y d w).trans mid

theorem commandEmitAfter223 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1111:Nat):V) f (vector n (d+u) (atom40 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1107 f n 0 (atom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter222 f n t s c u v y d w).trans mid

theorem commandEmitAfter224 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1114:Nat):V) f (vector n (d+u) (atom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1111 f n (d+u) (atom40 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter223 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
