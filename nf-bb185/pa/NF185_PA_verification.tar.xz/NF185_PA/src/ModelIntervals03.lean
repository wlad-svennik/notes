module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site0575Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 575 f r x y z) (slots617.atReg 585 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 575 10 585 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 575 579 576 f r row0575)
    (slots617.pos_y 575 579 576 f r row0575)
    (slots617.inc_z 576 577 f r row0576 (Or.inl (by decide)))
    (slots617.inc_x 577 578 f r row0577 (Or.inl (by decide)))
    (slots617.jump 578 575 f r row0578)
    (slots617.zero_x 579 585 580 f r row0579)
    (slots617.pos_x 579 585 580 f r row0579)
    (slots617.inc_z 580 581 f r row0580 (Or.inl (by decide)))
    (slots617.zero_x 581 584 582 f r row0581)
    (slots617.pos_x 581 584 582 f r row0581)
    (slots617.inc_y 582 583 f r row0582 (Or.inl (by decide)))
    (slots617.jump 583 581 f r row0583)
    (slots617.jump 584 575 f r row0584)

theorem site0575 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((575:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((585:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0575Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0585Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 585 f r x y z) (slots720.atReg 588 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 585 3 588 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 585 588 586 f r row0585)
    (slots720.pos_x 585 588 586 f r row0585)
    (slots720.inc_y 586 587 f r row0586 (Or.inl (by decide)))
    (slots720.jump 587 585 f r row0587)

theorem site0585 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((585:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((588:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0585Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0588Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 588 f r x y z) (slots461.atReg 592 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 588 4 592 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 588 592 589 f r row0588)
    (slots461.pos_x 588 592 589 f r row0588)
    (slots461.inc_y 589 590 f r row0589 (Or.inl (by decide)))
    (slots461.inc_z 590 591 f r row0590 (Or.inl (by decide)))
    (slots461.jump 591 588 f r row0591)

theorem site0588 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((588:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((592:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0588Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site0592Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 592 f r x y z) (slots640.atReg 595 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 592 3 595 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 592 595 593 f r row0592)
    (slots640.pos_x 592 595 593 f r row0592)
    (slots640.inc_y 593 594 f r row0593 (Or.inl (by decide)))
    (slots640.jump 594 592 f r row0594)

theorem site0592 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((592:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((595:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0592Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site0595Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 595 f r x y z) (slots267.atReg 603 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 595 8 603 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 595 603 596 f r row0595)
    (slots267.pos_x 595 603 596 f r row0595)
    (slots267.inc_z 596 597 f r row0596 (Or.inl (by decide)))
    (slots267.zero_y 597 599 598 f r row0597)
    (slots267.pos_y 597 599 598 f r row0597)
    (slots267.jump 598 602 f r row0598)
    (slots267.zero_z 599 602 600 f r row0599)
    (slots267.pos_z 599 602 600 f r row0599)
    (slots267.inc_y 600 601 f r row0600 (Or.inl (by decide)))
    (slots267.jump 601 599 f r row0601)
    (slots267.jump 602 595 f r row0602)

theorem site0595 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((595:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((603:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0595Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0603Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 603 f r x y z) (slots720.atReg 606 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 603 3 606 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 603 606 604 f r row0603)
    (slots720.pos_x 603 606 604 f r row0603)
    (slots720.inc_y 604 605 f r row0604 (Or.inl (by decide)))
    (slots720.jump 605 603 f r row0605)

theorem site0603 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((603:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((606:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0603Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0606Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 606 f r x y z) (slots617.atReg 616 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 606 10 616 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 606 610 607 f r row0606)
    (slots617.pos_y 606 610 607 f r row0606)
    (slots617.inc_z 607 608 f r row0607 (Or.inl (by decide)))
    (slots617.inc_x 608 609 f r row0608 (Or.inl (by decide)))
    (slots617.jump 609 606 f r row0609)
    (slots617.zero_x 610 616 611 f r row0610)
    (slots617.pos_x 610 616 611 f r row0610)
    (slots617.inc_z 611 612 f r row0611 (Or.inl (by decide)))
    (slots617.zero_x 612 615 613 f r row0612)
    (slots617.pos_x 612 615 613 f r row0612)
    (slots617.inc_y 613 614 f r row0613 (Or.inl (by decide)))
    (slots617.jump 614 612 f r row0614)
    (slots617.jump 615 606 f r row0615)

theorem site0606 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((606:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((616:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0606Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0616Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 616 f r x y z) (slots710.atReg 620 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 616 4 620 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 616 620 617 f r row0616)
    (slots710.pos_x 616 620 617 f r row0616)
    (slots710.inc_y 617 618 f r row0617 (Or.inl (by decide)))
    (slots710.inc_y 618 619 f r row0618 (Or.inl (by decide)))
    (slots710.jump 619 616 f r row0619)

theorem site0616 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((616:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((620:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0616Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site0620 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((620:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((621:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 620 _ row0620]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0621Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 621 f r x y z) (slots160.atReg 624 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 621 3 624 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 621 624 622 f r row0621)
    (slots160.pos_x 621 624 622 f r row0621)
    (slots160.inc_y 622 623 f r row0622 (Or.inl (by decide)))
    (slots160.jump 623 621 f r row0623)

theorem site0621 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((621:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((624:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0621Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0624Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 624 f r x y z) (slots210.atReg 627 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 624 3 627 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 624 627 625 f r row0624)
    (slots210.pos_x 624 627 625 f r row0624)
    (slots210.inc_y 625 626 f r row0625 (Or.inl (by decide)))
    (slots210.jump 626 624 f r row0626)

theorem site0624 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((624:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((627:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0624Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0627Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 627 f r x y z) (slots617.atReg 637 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 627 10 637 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 627 631 628 f r row0627)
    (slots617.pos_y 627 631 628 f r row0627)
    (slots617.inc_z 628 629 f r row0628 (Or.inl (by decide)))
    (slots617.inc_x 629 630 f r row0629 (Or.inl (by decide)))
    (slots617.jump 630 627 f r row0630)
    (slots617.zero_x 631 637 632 f r row0631)
    (slots617.pos_x 631 637 632 f r row0631)
    (slots617.inc_z 632 633 f r row0632 (Or.inl (by decide)))
    (slots617.zero_x 633 636 634 f r row0633)
    (slots617.pos_x 633 636 634 f r row0633)
    (slots617.inc_y 634 635 f r row0634 (Or.inl (by decide)))
    (slots617.jump 635 633 f r row0635)
    (slots617.jump 636 627 f r row0636)

theorem site0627 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((627:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((637:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0627Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0637Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 637 f r x y z) (slots720.atReg 640 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 637 3 640 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 637 640 638 f r row0637)
    (slots720.pos_x 637 640 638 f r row0637)
    (slots720.inc_y 638 639 f r row0638 (Or.inl (by decide)))
    (slots720.jump 639 637 f r row0639)

theorem site0637 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((637:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((640:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0637Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0640Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 640 f r x y z) (slots561.atReg 644 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 640 4 644 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 640 644 641 f r row0640)
    (slots561.pos_x 640 644 641 f r row0640)
    (slots561.inc_y 641 642 f r row0641 (Or.inl (by decide)))
    (slots561.inc_z 642 643 f r row0642 (Or.inl (by decide)))
    (slots561.jump 643 640 f r row0643)

theorem site0640 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((640:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((644:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0640Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site0644Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 644 f r x y z) (slots650.atReg 647 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 644 3 647 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 644 647 645 f r row0644)
    (slots650.pos_x 644 647 645 f r row0644)
    (slots650.inc_y 645 646 f r row0645 (Or.inl (by decide)))
    (slots650.jump 646 644 f r row0646)

theorem site0644 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((644:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((647:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0644Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site0647Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 647 f r x y z) (slots267.atReg 655 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 647 8 655 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 647 655 648 f r row0647)
    (slots267.pos_x 647 655 648 f r row0647)
    (slots267.inc_z 648 649 f r row0648 (Or.inl (by decide)))
    (slots267.zero_y 649 651 650 f r row0649)
    (slots267.pos_y 649 651 650 f r row0649)
    (slots267.jump 650 654 f r row0650)
    (slots267.zero_z 651 654 652 f r row0651)
    (slots267.pos_z 651 654 652 f r row0651)
    (slots267.inc_y 652 653 f r row0652 (Or.inl (by decide)))
    (slots267.jump 653 651 f r row0653)
    (slots267.jump 654 647 f r row0654)

theorem site0647 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((647:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((655:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0647Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0655Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 655 f r x y z) (slots720.atReg 658 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 655 3 658 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 655 658 656 f r row0655)
    (slots720.pos_x 655 658 656 f r row0655)
    (slots720.inc_y 656 657 f r row0656 (Or.inl (by decide)))
    (slots720.jump 657 655 f r row0657)

theorem site0655 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((655:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((658:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0655Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0658Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 658 f r x y z) (slots617.atReg 668 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 658 10 668 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 658 662 659 f r row0658)
    (slots617.pos_y 658 662 659 f r row0658)
    (slots617.inc_z 659 660 f r row0659 (Or.inl (by decide)))
    (slots617.inc_x 660 661 f r row0660 (Or.inl (by decide)))
    (slots617.jump 661 658 f r row0661)
    (slots617.zero_x 662 668 663 f r row0662)
    (slots617.pos_x 662 668 663 f r row0662)
    (slots617.inc_z 663 664 f r row0663 (Or.inl (by decide)))
    (slots617.zero_x 664 667 665 f r row0664)
    (slots617.pos_x 664 667 665 f r row0664)
    (slots617.inc_y 665 666 f r row0665 (Or.inl (by decide)))
    (slots617.jump 666 664 f r row0666)
    (slots617.jump 667 658 f r row0667)

theorem site0658 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((658:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((668:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0658Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0668Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 668 f r x y z) (slots710.atReg 672 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 668 4 672 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 668 672 669 f r row0668)
    (slots710.pos_x 668 672 669 f r row0668)
    (slots710.inc_y 669 670 f r row0669 (Or.inl (by decide)))
    (slots710.inc_y 670 671 f r row0670 (Or.inl (by decide)))
    (slots710.jump 671 668 f r row0671)

theorem site0668 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((668:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((672:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0668Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site0672 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((672:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((673:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 672 _ row0672]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0673Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 673 f r x y z) (slots267.atReg 681 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 673 8 681 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 673 681 674 f r row0673)
    (slots267.pos_x 673 681 674 f r row0673)
    (slots267.inc_z 674 675 f r row0674 (Or.inl (by decide)))
    (slots267.zero_y 675 677 676 f r row0675)
    (slots267.pos_y 675 677 676 f r row0675)
    (slots267.jump 676 680 f r row0676)
    (slots267.zero_z 677 680 678 f r row0677)
    (slots267.pos_z 677 680 678 f r row0677)
    (slots267.inc_y 678 679 f r row0678 (Or.inl (by decide)))
    (slots267.jump 679 677 f r row0679)
    (slots267.jump 680 673 f r row0680)

theorem site0673 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((673:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((681:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0673Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0681Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 681 f r x y z) (slots720.atReg 684 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 681 3 684 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 681 684 682 f r row0681)
    (slots720.pos_x 681 684 682 f r row0681)
    (slots720.inc_y 682 683 f r row0682 (Or.inl (by decide)))
    (slots720.jump 683 681 f r row0683)

theorem site0681 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((681:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((684:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0681Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0684Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 684 f r x y z) (slots617.atReg 694 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 684 10 694 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 684 688 685 f r row0684)
    (slots617.pos_y 684 688 685 f r row0684)
    (slots617.inc_z 685 686 f r row0685 (Or.inl (by decide)))
    (slots617.inc_x 686 687 f r row0686 (Or.inl (by decide)))
    (slots617.jump 687 684 f r row0687)
    (slots617.zero_x 688 694 689 f r row0688)
    (slots617.pos_x 688 694 689 f r row0688)
    (slots617.inc_z 689 690 f r row0689 (Or.inl (by decide)))
    (slots617.zero_x 690 693 691 f r row0690)
    (slots617.pos_x 690 693 691 f r row0690)
    (slots617.inc_y 691 692 f r row0691 (Or.inl (by decide)))
    (slots617.jump 692 690 f r row0692)
    (slots617.jump 693 684 f r row0693)

theorem site0684 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((684:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((694:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0684Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0694Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 694 f r x y z) (slots710.atReg 698 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 694 4 698 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 694 698 695 f r row0694)
    (slots710.pos_x 694 698 695 f r row0694)
    (slots710.inc_y 695 696 f r row0695 (Or.inl (by decide)))
    (slots710.inc_y 696 697 f r row0696 (Or.inl (by decide)))
    (slots710.jump 697 694 f r row0697)

theorem site0694 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((694:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((698:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0694Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site0698 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((698:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((699:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 698 _ row0698]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0699Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 699 f r x y z) (slots267.atReg 707 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 699 8 707 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 699 707 700 f r row0699)
    (slots267.pos_x 699 707 700 f r row0699)
    (slots267.inc_z 700 701 f r row0700 (Or.inl (by decide)))
    (slots267.zero_y 701 703 702 f r row0701)
    (slots267.pos_y 701 703 702 f r row0701)
    (slots267.jump 702 706 f r row0702)
    (slots267.zero_z 703 706 704 f r row0703)
    (slots267.pos_z 703 706 704 f r row0703)
    (slots267.inc_y 704 705 f r row0704 (Or.inl (by decide)))
    (slots267.jump 705 703 f r row0705)
    (slots267.jump 706 699 f r row0706)

theorem site0699 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((699:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((707:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0699Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0707Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 707 f r x y z) (slots720.atReg 710 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 707 3 710 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 707 710 708 f r row0707)
    (slots720.pos_x 707 710 708 f r row0707)
    (slots720.inc_y 708 709 f r row0708 (Or.inl (by decide)))
    (slots720.jump 709 707 f r row0709)

theorem site0707 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((707:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((710:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0707Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0710Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 710 f r x y z) (slots617.atReg 720 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 710 10 720 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 710 714 711 f r row0710)
    (slots617.pos_y 710 714 711 f r row0710)
    (slots617.inc_z 711 712 f r row0711 (Or.inl (by decide)))
    (slots617.inc_x 712 713 f r row0712 (Or.inl (by decide)))
    (slots617.jump 713 710 f r row0713)
    (slots617.zero_x 714 720 715 f r row0714)
    (slots617.pos_x 714 720 715 f r row0714)
    (slots617.inc_z 715 716 f r row0715 (Or.inl (by decide)))
    (slots617.zero_x 716 719 717 f r row0716)
    (slots617.pos_x 716 719 717 f r row0716)
    (slots617.inc_y 717 718 f r row0717 (Or.inl (by decide)))
    (slots617.jump 718 716 f r row0718)
    (slots617.jump 719 710 f r row0719)

theorem site0710 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((710:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((720:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0710Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0720Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 720 f r x y z) (slots710.atReg 724 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 720 4 724 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 720 724 721 f r row0720)
    (slots710.pos_x 720 724 721 f r row0720)
    (slots710.inc_y 721 722 f r row0721 (Or.inl (by decide)))
    (slots710.inc_y 722 723 f r row0722 (Or.inl (by decide)))
    (slots710.jump 723 720 f r row0723)

theorem site0720 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((720:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((724:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0720Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site0724Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 724 f r x y z) (slots160.atReg 727 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 724 3 727 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 724 727 725 f r row0724)
    (slots160.pos_x 724 727 725 f r row0724)
    (slots160.inc_y 725 726 f r row0725 (Or.inl (by decide)))
    (slots160.jump 726 724 f r row0726)

theorem site0724 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((724:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((727:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0724Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0727Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 727 f r x y z) (slots210.atReg 730 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 727 3 730 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 727 730 728 f r row0727)
    (slots210.pos_x 727 730 728 f r row0727)
    (slots210.inc_y 728 729 f r row0728 (Or.inl (by decide)))
    (slots210.jump 729 727 f r row0729)

theorem site0727 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((727:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((730:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0727Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0730Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 730 f r x y z) (slots617.atReg 740 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 730 10 740 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 730 734 731 f r row0730)
    (slots617.pos_y 730 734 731 f r row0730)
    (slots617.inc_z 731 732 f r row0731 (Or.inl (by decide)))
    (slots617.inc_x 732 733 f r row0732 (Or.inl (by decide)))
    (slots617.jump 733 730 f r row0733)
    (slots617.zero_x 734 740 735 f r row0734)
    (slots617.pos_x 734 740 735 f r row0734)
    (slots617.inc_z 735 736 f r row0735 (Or.inl (by decide)))
    (slots617.zero_x 736 739 737 f r row0736)
    (slots617.pos_x 736 739 737 f r row0736)
    (slots617.inc_y 737 738 f r row0737 (Or.inl (by decide)))
    (slots617.jump 738 736 f r row0738)
    (slots617.jump 739 730 f r row0739)

theorem site0730 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((730:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((740:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0730Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0740Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 740 f r x y z) (slots720.atReg 743 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 740 3 743 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 740 743 741 f r row0740)
    (slots720.pos_x 740 743 741 f r row0740)
    (slots720.inc_y 741 742 f r row0741 (Or.inl (by decide)))
    (slots720.jump 742 740 f r row0742)

theorem site0740 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((740:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((743:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0740Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0743Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 743 f r x y z) (slots361.atReg 747 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 743 4 747 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 743 747 744 f r row0743)
    (slots361.pos_x 743 747 744 f r row0743)
    (slots361.inc_y 744 745 f r row0744 (Or.inl (by decide)))
    (slots361.inc_z 745 746 f r row0745 (Or.inl (by decide)))
    (slots361.jump 746 743 f r row0746)

theorem site0743 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((743:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((747:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0743Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site0747Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 747 f r x y z) (slots630.atReg 750 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 747 3 750 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 747 750 748 f r row0747)
    (slots630.pos_x 747 750 748 f r row0747)
    (slots630.inc_y 748 749 f r row0748 (Or.inl (by decide)))
    (slots630.jump 749 747 f r row0749)

theorem site0747 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((747:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((750:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0747Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site0750Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 750 f r x y z) (slots160.atReg 753 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 750 3 753 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 750 753 751 f r row0750)
    (slots160.pos_x 750 753 751 f r row0750)
    (slots160.inc_y 751 752 f r row0751 (Or.inl (by decide)))
    (slots160.jump 752 750 f r row0752)

theorem site0750 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((750:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((753:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0750Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0753Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 753 f r x y z) (slots210.atReg 756 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 753 3 756 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 753 756 754 f r row0753)
    (slots210.pos_x 753 756 754 f r row0753)
    (slots210.inc_y 754 755 f r row0754 (Or.inl (by decide)))
    (slots210.jump 755 753 f r row0755)

theorem site0753 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((753:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((756:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0753Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0756Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 756 f r x y z) (slots617.atReg 766 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 756 10 766 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 756 760 757 f r row0756)
    (slots617.pos_y 756 760 757 f r row0756)
    (slots617.inc_z 757 758 f r row0757 (Or.inl (by decide)))
    (slots617.inc_x 758 759 f r row0758 (Or.inl (by decide)))
    (slots617.jump 759 756 f r row0759)
    (slots617.zero_x 760 766 761 f r row0760)
    (slots617.pos_x 760 766 761 f r row0760)
    (slots617.inc_z 761 762 f r row0761 (Or.inl (by decide)))
    (slots617.zero_x 762 765 763 f r row0762)
    (slots617.pos_x 762 765 763 f r row0762)
    (slots617.inc_y 763 764 f r row0763 (Or.inl (by decide)))
    (slots617.jump 764 762 f r row0764)
    (slots617.jump 765 756 f r row0765)

theorem site0756 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((756:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((766:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0756Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0766Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 766 f r x y z) (slots720.atReg 769 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 766 3 769 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 766 769 767 f r row0766)
    (slots720.pos_x 766 769 767 f r row0766)
    (slots720.inc_y 767 768 f r row0767 (Or.inl (by decide)))
    (slots720.jump 768 766 f r row0768)

theorem site0766 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((766:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((769:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0766Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0769Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 769 f r x y z) (slots561.atReg 773 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 769 4 773 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 769 773 770 f r row0769)
    (slots561.pos_x 769 773 770 f r row0769)
    (slots561.inc_y 770 771 f r row0770 (Or.inl (by decide)))
    (slots561.inc_z 771 772 f r row0771 (Or.inl (by decide)))
    (slots561.jump 772 769 f r row0772)

theorem site0769 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((769:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((773:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0769Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site0773Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 773 f r x y z) (slots650.atReg 776 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 773 3 776 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 773 776 774 f r row0773)
    (slots650.pos_x 773 776 774 f r row0773)
    (slots650.inc_y 774 775 f r row0774 (Or.inl (by decide)))
    (slots650.jump 775 773 f r row0775)

theorem site0773 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((773:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((776:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0773Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site0776Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 776 f r x y z) (slots267.atReg 784 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 776 8 784 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 776 784 777 f r row0776)
    (slots267.pos_x 776 784 777 f r row0776)
    (slots267.inc_z 777 778 f r row0777 (Or.inl (by decide)))
    (slots267.zero_y 778 780 779 f r row0778)
    (slots267.pos_y 778 780 779 f r row0778)
    (slots267.jump 779 783 f r row0779)
    (slots267.zero_z 780 783 781 f r row0780)
    (slots267.pos_z 780 783 781 f r row0780)
    (slots267.inc_y 781 782 f r row0781 (Or.inl (by decide)))
    (slots267.jump 782 780 f r row0782)
    (slots267.jump 783 776 f r row0783)

theorem site0776 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((776:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((784:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0776Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

end PA192.ModelSearch.RegisterSource.Certified
