module
public import ModelCmdEmit16
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter545 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2615:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom87 n t s c u v y d w) w)) := by
  have micro := site2605 f n (atom86 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w
  have d7 : (0+(cantor (v+y) (atom86 n t s c u v y d w)):V)=atom87 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (v+y) (atom86 n t s c u v y d w)):V)=0+(atom87 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter544 f n t s c u v y d w).trans mid

theorem commandEmitAfter546 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2618:Nat):V) f (vector n 0 (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2615 f n 0 0 c (d+u) (v+y) 0 (atom87 n t s c u v y d w) w
  have d2 : (0+(atom87 n t s c u v y d w):V)=atom87 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter545 f n t s c u v y d w).trans mid

theorem commandEmitAfter547 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2622:Nat):V) f (vector n (d+u) (atom87 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2618 f n 0 (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter546 f n t s c u v y d w).trans mid

theorem commandEmitAfter548 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2625:Nat):V) f (vector n (d+u) (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2622 f n (d+u) (atom87 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter547 f n t s c u v y d w).trans mid

theorem commandEmitAfter549 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2628:Nat):V) f (vector n 0 (atom87 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2625 f n (d+u) (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter548 f n t s c u v y d w).trans mid

theorem commandEmitAfter550 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2631:Nat):V) f (vector n (atom87 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2628 f n 0 (atom87 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom87 n t s c u v y d w):V)=atom87 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter549 f n t s c u v y d w).trans mid

theorem commandEmitAfter551 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2641:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom88 n t s c u v y d w) w)) := by
  have micro := site2631 f n (atom87 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom87 n t s c u v y d w)):V)=atom88 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom87 n t s c u v y d w)):V)=0+(atom88 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter550 f n t s c u v y d w).trans mid

theorem commandEmitAfter552 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2644:Nat):V) f (vector n 0 (atom88 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2641 f n 0 0 c (d+u) (v+y) 0 (atom88 n t s c u v y d w) w
  have d2 : (0+(atom88 n t s c u v y d w):V)=atom88 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter551 f n t s c u v y d w).trans mid

theorem commandEmitAfter553 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2648:Nat):V) f (vector n (v+y) (atom88 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2644 f n 0 (atom88 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter552 f n t s c u v y d w).trans mid

theorem commandEmitAfter554 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2651:Nat):V) f (vector n (v+y) (atom88 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2648 f n (v+y) (atom88 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter553 f n t s c u v y d w).trans mid

theorem commandEmitAfter555 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2659:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom87 n t s c u v y d w) w)) := by
  have micro := site2651 f n (v+y) (atom88 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom88 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom88 n t s c u v y d w):V)=0+(atom88 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom88 n t s c u v y d w)):V)=left (atom88 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom87 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom88 n t s c u v y d w)):V)=atom87 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom88 n t s c u v y d w):V)=0+(atom88 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom88 n t s c u v y d w)):V)=right (atom88 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom87 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter554 f n t s c u v y d w).trans mid

theorem commandEmitAfter556 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2662:Nat):V) f (vector n (v+y) (atom87 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2659 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom87 n t s c u v y d w) w
  have d2 : (0+(atom87 n t s c u v y d w):V)=atom87 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter555 f n t s c u v y d w).trans mid

theorem commandEmitAfter557 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2672:Nat):V) f (vector n 0 (atom87 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site2662 f n (v+y) (atom87 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter556 f n t s c u v y d w).trans mid

theorem commandEmitAfter558 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2676:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2672 f n 0 (atom87 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter557 f n t s c u v y d w).trans mid

theorem commandEmitAfter559 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2677:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2676 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter558 f n t s c u v y d w).trans mid

theorem commandEmitAfter560 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2678:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2677 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter559 f n t s c u v y d w).trans mid

theorem commandEmitAfter561 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2686:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) (v+y) (atom86 n t s c u v y d w) w)) := by
  have micro := site2678 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) (atom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom87 n t s c u v y d w)):V)=v+y := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom87 n t s c u v y d w):V)=0+(atom87 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom87 n t s c u v y d w)):V)=left (atom87 n t s c u v y d w)).trans (by change left (cantor (v+y) (atom86 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom87 n t s c u v y d w)):V)=atom86 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom87 n t s c u v y d w):V)=0+(atom87 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom87 n t s c u v y d w)):V)=right (atom87 n t s c u v y d w)).trans (by change right (cantor (v+y) (atom86 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter560 f n t s c u v y d w).trans mid

theorem commandEmitAfter562 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2689:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) (atom86 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site2686 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) (v+y) (atom86 n t s c u v y d w) w
  have d2 : (0+(atom86 n t s c u v y d w):V)=atom86 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter561 f n t s c u v y d w).trans mid

theorem commandEmitAfter563 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2699:Nat):V) f (vector n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 (atom89 n t s c u v y d w) w)) := by
  have micro := site2689 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) (atom86 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d7 : (0+(cantor (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2)):V)=atom89 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2)):V)=0+(atom89 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter562 f n t s c u v y d w).trans mid

theorem commandEmitAfter564 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2703:Nat):V) f (vector n ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2699 f n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 (atom89 n t s c u v y d w) w
  have d1 : (0+(2*(atom89 n t s c u v y d w)):V)=(atom89 n t s c u v y d w)+(atom89 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom89 n t s c u v y d w)):V)=0+((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter563 f n t s c u v y d w).trans mid

theorem commandEmitAfter565 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2704:Nat):V) f (vector n ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2703 f n ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w))+1:V)=(atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter564 f n t s c u v y d w).trans mid

theorem commandEmitAfter566 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2707:Nat):V) f (vector n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2704 f n ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1):V)=(atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter565 f n t s c u v y d w).trans mid

theorem commandEmitAfter567 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2710:Nat):V) f (vector n (atom86 n t s c u v y d w) 0 c (d+u) (v+y) ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2707 f n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom86 n t s c u v y d w):V)=atom86 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter566 f n t s c u v y d w).trans mid

theorem commandEmitAfter568 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2720:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom90 n t s c u v y d w) w)) := by
  have micro := site2710 f n (atom86 n t s c u v y d w) 0 c (d+u) (v+y) ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) (atom86 n t s c u v y d w)):V)=atom90 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) (atom86 n t s c u v y d w)):V)=0+(atom90 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter567 f n t s c u v y d w).trans mid

theorem commandEmitAfter569 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2723:Nat):V) f (vector n 0 (atom90 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2720 f n 0 0 c (d+u) (v+y) 0 (atom90 n t s c u v y d w) w
  have d2 : (0+(atom90 n t s c u v y d w):V)=atom90 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter568 f n t s c u v y d w).trans mid

theorem commandEmitAfter570 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2727:Nat):V) f (vector n (d+u) (atom90 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2723 f n 0 (atom90 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter569 f n t s c u v y d w).trans mid

theorem commandEmitAfter571 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2730:Nat):V) f (vector n (d+u) (atom90 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2727 f n (d+u) (atom90 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter570 f n t s c u v y d w).trans mid

theorem commandEmitAfter572 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2733:Nat):V) f (vector n 0 (atom90 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2730 f n (d+u) (atom90 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter571 f n t s c u v y d w).trans mid

theorem commandEmitAfter573 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2736:Nat):V) f (vector n (atom90 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2733 f n 0 (atom90 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom90 n t s c u v y d w):V)=atom90 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter572 f n t s c u v y d w).trans mid

theorem commandEmitAfter574 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2746:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom91 n t s c u v y d w) w)) := by
  have micro := site2736 f n (atom90 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom90 n t s c u v y d w)):V)=atom91 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom90 n t s c u v y d w)):V)=0+(atom91 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter573 f n t s c u v y d w).trans mid

theorem commandEmitAfter575 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2749:Nat):V) f (vector n 0 (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2746 f n 0 0 c (d+u) (v+y) 0 (atom91 n t s c u v y d w) w
  have d2 : (0+(atom91 n t s c u v y d w):V)=atom91 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter574 f n t s c u v y d w).trans mid

theorem commandEmitAfter576 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2753:Nat):V) f (vector n (d+u) (atom91 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2749 f n 0 (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter575 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
