module
public import ModelCommandAtoms
public import ModelIntervals
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter13 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((99:Nat):V) f (vector n 0 (atom3 n t s c u v y d w) c u (v+y) 0 0 (atom0 n t s c u v y d w))) := by
  have micro := site0096 f n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w)
  have d2 : (0+(atom3 n t s c u v y d w):V)=atom3 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact mid

theorem seedEmitAfter14 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((103:Nat):V) f (vector n u (atom3 n t s c u v y d w) c 0 (v+y) u 0 (atom0 n t s c u v y d w))) := by
  have micro := site0099 f n 0 (atom3 n t s c u v y d w) c u (v+y) 0 0 (atom0 n t s c u v y d w)
  have d1 : (0+u:V)=u := by ring
  have d6 : (0+u:V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter13 f n t s c u v y d w).trans mid

theorem seedEmitAfter15 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((106:Nat):V) f (vector n u (atom3 n t s c u v y d w) c u (v+y) 0 0 (atom0 n t s c u v y d w))) := by
  have micro := site0103 f n u (atom3 n t s c u v y d w) c 0 (v+y) u 0 (atom0 n t s c u v y d w)
  have d4 : (0+u:V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter14 f n t s c u v y d w).trans mid

theorem seedEmitAfter16 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((114:Nat):V) f (vector n u (atom3 n t s c u v y d w) c u (v+y) d w 0)) := by
  have micro := site0106 f n u (atom3 n t s c u v y d w) c u (v+y) 0 0 (atom0 n t s c u v y d w)
  have d6 : (left ((cantor 0 0)+(atom0 n t s c u v y d w)):V)=d := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom0 n t s c u v y d w):V)=0+(atom0 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom0 n t s c u v y d w)):V)=left (atom0 n t s c u v y d w)).trans (by change left (cantor d w) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom0 n t s c u v y d w)):V)=w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom0 n t s c u v y d w):V)=0+(atom0 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom0 n t s c u v y d w)):V)=right (atom0 n t s c u v y d w)).trans (by change right (cantor d w) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter15 f n t s c u v y d w).trans mid

theorem seedEmitAfter17 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((117:Nat):V) f (vector n u (atom3 n t s c u v y d w) c u (v+y) d 0 w)) := by
  have micro := site0114 f n u (atom3 n t s c u v y d w) c u (v+y) d w 0
  have d8 : (0+w:V)=w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl rfl d8)
  exact (seedEmitAfter16 f n t s c u v y d w).trans mid

theorem seedEmitAfter18 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((120:Nat):V) f (vector n u (atom3 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0117 f n u (atom3 n t s c u v y d w) c u (v+y) d 0 w
  have d4 : (u+d:V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter17 f n t s c u v y d w).trans mid

theorem seedEmitAfter19 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((128:Nat):V) f (vector n u 0 c (d+u) (v+y) c (atom2 n t s c u v y d w) w)) := by
  have micro := site0120 f n u (atom3 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom3 n t s c u v y d w)):V)=c := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom3 n t s c u v y d w):V)=0+(atom3 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom3 n t s c u v y d w)):V)=left (atom3 n t s c u v y d w)).trans (by change left (cantor c (atom2 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom3 n t s c u v y d w)):V)=atom2 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom3 n t s c u v y d w):V)=0+(atom3 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom3 n t s c u v y d w)):V)=right (atom3 n t s c u v y d w)).trans (by change right (cantor c (atom2 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter18 f n t s c u v y d w).trans mid

theorem seedEmitAfter20 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((131:Nat):V) f (vector n u (atom2 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site0128 f n u 0 c (d+u) (v+y) c (atom2 n t s c u v y d w) w
  have d2 : (0+(atom2 n t s c u v y d w):V)=atom2 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter19 f n t s c u v y d w).trans mid

theorem seedEmitAfter21 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((141:Nat):V) f (vector n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) 0 (atom4 n t s c u v y d w) w)) := by
  have micro := site0131 f n u (atom2 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d7 : (0+(cantor c u):V)=atom4 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor c u):V)=0+(atom4 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter20 f n t s c u v y d w).trans mid

theorem seedEmitAfter22 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((145:Nat):V) f (vector n ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (atom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0141 f n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) 0 (atom4 n t s c u v y d w) w
  have d1 : (0+(2*(atom4 n t s c u v y d w)):V)=(atom4 n t s c u v y d w)+(atom4 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom4 n t s c u v y d w)):V)=0+((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter21 f n t s c u v y d w).trans mid

theorem seedEmitAfter23 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((148:Nat):V) f (vector n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) 0 w)) := by
  have micro := site0145 f n ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (atom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)):V)=(atom4 n t s c u v y d w)+(atom4 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter22 f n t s c u v y d w).trans mid

theorem seedEmitAfter24 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((151:Nat):V) f (vector n (atom2 n t s c u v y d w) 0 c (d+u) (v+y) ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) 0 w)) := by
  have micro := site0148 f n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) 0 w
  have d1 : (0+(atom2 n t s c u v y d w):V)=atom2 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter23 f n t s c u v y d w).trans mid

theorem seedEmitAfter25 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((161:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom5 n t s c u v y d w) w)) := by
  have micro := site0151 f n (atom2 n t s c u v y d w) 0 c (d+u) (v+y) ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (atom2 n t s c u v y d w)):V)=atom5 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (atom2 n t s c u v y d w)):V)=0+(atom5 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter24 f n t s c u v y d w).trans mid

theorem seedEmitAfter26 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((164:Nat):V) f (vector n 0 (atom5 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0161 f n 0 0 c (d+u) (v+y) 0 (atom5 n t s c u v y d w) w
  have d2 : (0+(atom5 n t s c u v y d w):V)=atom5 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter25 f n t s c u v y d w).trans mid

theorem seedEmitAfter27 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((168:Nat):V) f (vector n (d+u) (atom5 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0164 f n 0 (atom5 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter26 f n t s c u v y d w).trans mid

theorem seedEmitAfter28 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((171:Nat):V) f (vector n (d+u) (atom5 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0168 f n (d+u) (atom5 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter27 f n t s c u v y d w).trans mid

theorem seedEmitAfter29 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((179:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (atom2 n t s c u v y d w) w)) := by
  have micro := site0171 f n (d+u) (atom5 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom5 n t s c u v y d w)):V)=(atom4 n t s c u v y d w)+(atom4 n t s c u v y d w) := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom5 n t s c u v y d w):V)=0+(atom5 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom5 n t s c u v y d w)):V)=left (atom5 n t s c u v y d w)).trans (by change left (cantor ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (atom2 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom5 n t s c u v y d w)):V)=atom2 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom5 n t s c u v y d w):V)=0+(atom5 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom5 n t s c u v y d w)):V)=right (atom5 n t s c u v y d w)).trans (by change right (cantor ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (atom2 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter28 f n t s c u v y d w).trans mid

theorem seedEmitAfter30 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((182:Nat):V) f (vector n (d+u) (atom2 n t s c u v y d w) c (d+u) (v+y) ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) 0 w)) := by
  have micro := site0179 f n (d+u) 0 c (d+u) (v+y) ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (atom2 n t s c u v y d w) w
  have d2 : (0+(atom2 n t s c u v y d w):V)=atom2 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter29 f n t s c u v y d w).trans mid

theorem seedEmitAfter31 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((192:Nat):V) f (vector n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) 0 (atom6 n t s c u v y d w) w)) := by
  have micro := site0182 f n (d+u) (atom2 n t s c u v y d w) c (d+u) (v+y) ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (d+u)):V)=atom6 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (d+u)):V)=0+(atom6 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter30 f n t s c u v y d w).trans mid

theorem seedEmitAfter32 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((196:Nat):V) f (vector n ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) (atom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0192 f n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) 0 (atom6 n t s c u v y d w) w
  have d1 : (0+(2*(atom6 n t s c u v y d w)):V)=(atom6 n t s c u v y d w)+(atom6 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom6 n t s c u v y d w)):V)=0+((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter31 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
