module
public import LiteralRegisterProgram

@[expose] public section
namespace PA192.ModelSearch.RegisterSource

private def Slice (full part : List Instr) (i : Nat) : Prop :=
  ∀ n, n<part.length → full[i+n]? = part[n]?

private theorem splitL {full a b : List Instr} {i : Nat} (h : Slice full (a++b) i) : Slice full a i := by
  intro n lower
  exact (h n (by simp; omega)).trans (List.getElem?_append_left lower)

private theorem splitR {full a b : List Instr} {i j : Nat} (eq : j=i+a.length)
    (h : Slice full (a++b) i) : Slice full b j := by
  intro n lower
  subst j
  have inside : a.length+n < (a++b).length := by simp [lower]
  rw [Nat.add_assoc]
  rw [h (a.length+n) inside,List.getElem?_append_right (by omega)]
  simp

private theorem len0_32 : instructions0.length = 32 := rfl
private theorem len32_64 : instructions32.length = 32 := rfl
private theorem len64_96 : instructions64.length = 32 := rfl
private theorem len96_128 : instructions96.length = 32 := rfl
private theorem len128_160 : instructions128.length = 32 := rfl
private theorem len160_192 : instructions160.length = 32 := rfl
private theorem len192_224 : instructions192.length = 32 := rfl
private theorem len224_256 : instructions224.length = 32 := rfl
private theorem len256_288 : instructions256.length = 32 := rfl
private theorem len288_320 : instructions288.length = 32 := rfl
private theorem len320_352 : instructions320.length = 32 := rfl
private theorem len352_384 : instructions352.length = 32 := rfl
private theorem len384_416 : instructions384.length = 32 := rfl
private theorem len416_448 : instructions416.length = 32 := rfl
private theorem len448_480 : instructions448.length = 32 := rfl
private theorem len480_512 : instructions480.length = 32 := rfl
private theorem len512_544 : instructions512.length = 32 := rfl
private theorem len544_576 : instructions544.length = 32 := rfl
private theorem len576_608 : instructions576.length = 32 := rfl
private theorem len608_640 : instructions608.length = 32 := rfl
private theorem len640_672 : instructions640.length = 32 := rfl
private theorem len672_704 : instructions672.length = 32 := rfl
private theorem len704_736 : instructions704.length = 32 := rfl
private theorem len736_768 : instructions736.length = 32 := rfl
private theorem len768_800 : instructions768.length = 32 := rfl
private theorem len800_832 : instructions800.length = 32 := rfl
private theorem len832_864 : instructions832.length = 32 := rfl
private theorem len864_896 : instructions864.length = 32 := rfl
private theorem len896_928 : instructions896.length = 32 := rfl
private theorem len928_960 : instructions928.length = 32 := rfl
private theorem len960_992 : instructions960.length = 32 := rfl
private theorem len992_1024 : instructions992.length = 32 := rfl
private theorem len1024_1056 : instructions1024.length = 32 := rfl
private theorem len1056_1088 : instructions1056.length = 32 := rfl
private theorem len1088_1120 : instructions1088.length = 32 := rfl
private theorem len1120_1152 : instructions1120.length = 32 := rfl
private theorem len1152_1184 : instructions1152.length = 32 := rfl
private theorem len1184_1216 : instructions1184.length = 32 := rfl
private theorem len1216_1248 : instructions1216.length = 32 := rfl
private theorem len1248_1280 : instructions1248.length = 32 := rfl
private theorem len1280_1312 : instructions1280.length = 32 := rfl
private theorem len1312_1344 : instructions1312.length = 32 := rfl
private theorem len1344_1376 : instructions1344.length = 32 := rfl
private theorem len1376_1408 : instructions1376.length = 32 := rfl
private theorem len1408_1440 : instructions1408.length = 32 := rfl
private theorem len1440_1472 : instructions1440.length = 32 := rfl
private theorem len1472_1504 : instructions1472.length = 32 := rfl
private theorem len1504_1536 : instructions1504.length = 32 := rfl
private theorem len1536_1568 : instructions1536.length = 32 := rfl
private theorem len1568_1600 : instructions1568.length = 32 := rfl
private theorem len1600_1632 : instructions1600.length = 32 := rfl
private theorem len1632_1664 : instructions1632.length = 32 := rfl
private theorem len1664_1696 : instructions1664.length = 32 := rfl
private theorem len1696_1728 : instructions1696.length = 32 := rfl
private theorem len1728_1760 : instructions1728.length = 32 := rfl
private theorem len1760_1792 : instructions1760.length = 32 := rfl
private theorem len1792_1824 : instructions1792.length = 32 := rfl
private theorem len1824_1856 : instructions1824.length = 32 := rfl
private theorem len1856_1888 : instructions1856.length = 32 := rfl
private theorem len1888_1920 : instructions1888.length = 32 := rfl
private theorem len1920_1952 : instructions1920.length = 32 := rfl
private theorem len1952_1984 : instructions1952.length = 32 := rfl
private theorem len1984_2016 : instructions1984.length = 32 := rfl
private theorem len2016_2048 : instructions2016.length = 32 := rfl
private theorem len2048_2080 : instructions2048.length = 32 := rfl
private theorem len2080_2112 : instructions2080.length = 32 := rfl
private theorem len2112_2144 : instructions2112.length = 32 := rfl
private theorem len2144_2176 : instructions2144.length = 32 := rfl
private theorem len2176_2208 : instructions2176.length = 32 := rfl
private theorem len2208_2240 : instructions2208.length = 32 := rfl
private theorem len2240_2272 : instructions2240.length = 32 := rfl
private theorem len2272_2304 : instructions2272.length = 32 := rfl
private theorem len2304_2336 : instructions2304.length = 32 := rfl
private theorem len2336_2368 : instructions2336.length = 32 := rfl
private theorem len2368_2400 : instructions2368.length = 32 := rfl
private theorem len2400_2432 : instructions2400.length = 32 := rfl
private theorem len2432_2464 : instructions2432.length = 32 := rfl
private theorem len2464_2496 : instructions2464.length = 32 := rfl
private theorem len2496_2528 : instructions2496.length = 32 := rfl
private theorem len2528_2560 : instructions2528.length = 32 := rfl
private theorem len2560_2592 : instructions2560.length = 32 := rfl
private theorem len2592_2624 : instructions2592.length = 32 := rfl
private theorem len2624_2656 : instructions2624.length = 32 := rfl
private theorem len2656_2688 : instructions2656.length = 32 := rfl
private theorem len2688_2720 : instructions2688.length = 32 := rfl
private theorem len2720_2752 : instructions2720.length = 32 := rfl
private theorem len2752_2784 : instructions2752.length = 32 := rfl
private theorem len2784_2816 : instructions2784.length = 32 := rfl
private theorem len2816_2848 : instructions2816.length = 32 := rfl
private theorem len2848_2880 : instructions2848.length = 32 := rfl
private theorem len2880_2912 : instructions2880.length = 32 := rfl
private theorem len2912_2944 : instructions2912.length = 32 := rfl
private theorem len2944_2976 : instructions2944.length = 32 := rfl
private theorem len2976_3008 : instructions2976.length = 32 := rfl
private theorem len3008_3040 : instructions3008.length = 32 := rfl
private theorem len3040_3072 : instructions3040.length = 32 := rfl
private theorem len3072_3089 : instructions3072.length = 17 := rfl
private def node0_64 := instructions0 ++ instructions32
private theorem len0_64 : node0_64.length=64 := by rw [node0_64,List.length_append,len0_32,len32_64]
private def node64_128 := instructions64 ++ instructions96
private theorem len64_128 : node64_128.length=64 := by rw [node64_128,List.length_append,len64_96,len96_128]
private def node128_192 := instructions128 ++ instructions160
private theorem len128_192 : node128_192.length=64 := by rw [node128_192,List.length_append,len128_160,len160_192]
private def node192_256 := instructions192 ++ instructions224
private theorem len192_256 : node192_256.length=64 := by rw [node192_256,List.length_append,len192_224,len224_256]
private def node256_320 := instructions256 ++ instructions288
private theorem len256_320 : node256_320.length=64 := by rw [node256_320,List.length_append,len256_288,len288_320]
private def node320_384 := instructions320 ++ instructions352
private theorem len320_384 : node320_384.length=64 := by rw [node320_384,List.length_append,len320_352,len352_384]
private def node384_448 := instructions384 ++ instructions416
private theorem len384_448 : node384_448.length=64 := by rw [node384_448,List.length_append,len384_416,len416_448]
private def node448_512 := instructions448 ++ instructions480
private theorem len448_512 : node448_512.length=64 := by rw [node448_512,List.length_append,len448_480,len480_512]
private def node512_576 := instructions512 ++ instructions544
private theorem len512_576 : node512_576.length=64 := by rw [node512_576,List.length_append,len512_544,len544_576]
private def node576_640 := instructions576 ++ instructions608
private theorem len576_640 : node576_640.length=64 := by rw [node576_640,List.length_append,len576_608,len608_640]
private def node640_704 := instructions640 ++ instructions672
private theorem len640_704 : node640_704.length=64 := by rw [node640_704,List.length_append,len640_672,len672_704]
private def node704_768 := instructions704 ++ instructions736
private theorem len704_768 : node704_768.length=64 := by rw [node704_768,List.length_append,len704_736,len736_768]
private def node768_832 := instructions768 ++ instructions800
private theorem len768_832 : node768_832.length=64 := by rw [node768_832,List.length_append,len768_800,len800_832]
private def node832_896 := instructions832 ++ instructions864
private theorem len832_896 : node832_896.length=64 := by rw [node832_896,List.length_append,len832_864,len864_896]
private def node896_960 := instructions896 ++ instructions928
private theorem len896_960 : node896_960.length=64 := by rw [node896_960,List.length_append,len896_928,len928_960]
private def node960_1024 := instructions960 ++ instructions992
private theorem len960_1024 : node960_1024.length=64 := by rw [node960_1024,List.length_append,len960_992,len992_1024]
private def node1024_1088 := instructions1024 ++ instructions1056
private theorem len1024_1088 : node1024_1088.length=64 := by rw [node1024_1088,List.length_append,len1024_1056,len1056_1088]
private def node1088_1152 := instructions1088 ++ instructions1120
private theorem len1088_1152 : node1088_1152.length=64 := by rw [node1088_1152,List.length_append,len1088_1120,len1120_1152]
private def node1152_1216 := instructions1152 ++ instructions1184
private theorem len1152_1216 : node1152_1216.length=64 := by rw [node1152_1216,List.length_append,len1152_1184,len1184_1216]
private def node1216_1280 := instructions1216 ++ instructions1248
private theorem len1216_1280 : node1216_1280.length=64 := by rw [node1216_1280,List.length_append,len1216_1248,len1248_1280]
private def node1280_1344 := instructions1280 ++ instructions1312
private theorem len1280_1344 : node1280_1344.length=64 := by rw [node1280_1344,List.length_append,len1280_1312,len1312_1344]
private def node1344_1408 := instructions1344 ++ instructions1376
private theorem len1344_1408 : node1344_1408.length=64 := by rw [node1344_1408,List.length_append,len1344_1376,len1376_1408]
private def node1408_1472 := instructions1408 ++ instructions1440
private theorem len1408_1472 : node1408_1472.length=64 := by rw [node1408_1472,List.length_append,len1408_1440,len1440_1472]
private def node1472_1536 := instructions1472 ++ instructions1504
private theorem len1472_1536 : node1472_1536.length=64 := by rw [node1472_1536,List.length_append,len1472_1504,len1504_1536]
private def node1536_1600 := instructions1536 ++ instructions1568
private theorem len1536_1600 : node1536_1600.length=64 := by rw [node1536_1600,List.length_append,len1536_1568,len1568_1600]
private def node1600_1664 := instructions1600 ++ instructions1632
private theorem len1600_1664 : node1600_1664.length=64 := by rw [node1600_1664,List.length_append,len1600_1632,len1632_1664]
private def node1664_1728 := instructions1664 ++ instructions1696
private theorem len1664_1728 : node1664_1728.length=64 := by rw [node1664_1728,List.length_append,len1664_1696,len1696_1728]
private def node1728_1792 := instructions1728 ++ instructions1760
private theorem len1728_1792 : node1728_1792.length=64 := by rw [node1728_1792,List.length_append,len1728_1760,len1760_1792]
private def node1792_1856 := instructions1792 ++ instructions1824
private theorem len1792_1856 : node1792_1856.length=64 := by rw [node1792_1856,List.length_append,len1792_1824,len1824_1856]
private def node1856_1920 := instructions1856 ++ instructions1888
private theorem len1856_1920 : node1856_1920.length=64 := by rw [node1856_1920,List.length_append,len1856_1888,len1888_1920]
private def node1920_1984 := instructions1920 ++ instructions1952
private theorem len1920_1984 : node1920_1984.length=64 := by rw [node1920_1984,List.length_append,len1920_1952,len1952_1984]
private def node1984_2048 := instructions1984 ++ instructions2016
private theorem len1984_2048 : node1984_2048.length=64 := by rw [node1984_2048,List.length_append,len1984_2016,len2016_2048]
private def node2048_2112 := instructions2048 ++ instructions2080
private theorem len2048_2112 : node2048_2112.length=64 := by rw [node2048_2112,List.length_append,len2048_2080,len2080_2112]
private def node2112_2176 := instructions2112 ++ instructions2144
private theorem len2112_2176 : node2112_2176.length=64 := by rw [node2112_2176,List.length_append,len2112_2144,len2144_2176]
private def node2176_2240 := instructions2176 ++ instructions2208
private theorem len2176_2240 : node2176_2240.length=64 := by rw [node2176_2240,List.length_append,len2176_2208,len2208_2240]
private def node2240_2304 := instructions2240 ++ instructions2272
private theorem len2240_2304 : node2240_2304.length=64 := by rw [node2240_2304,List.length_append,len2240_2272,len2272_2304]
private def node2304_2368 := instructions2304 ++ instructions2336
private theorem len2304_2368 : node2304_2368.length=64 := by rw [node2304_2368,List.length_append,len2304_2336,len2336_2368]
private def node2368_2432 := instructions2368 ++ instructions2400
private theorem len2368_2432 : node2368_2432.length=64 := by rw [node2368_2432,List.length_append,len2368_2400,len2400_2432]
private def node2432_2496 := instructions2432 ++ instructions2464
private theorem len2432_2496 : node2432_2496.length=64 := by rw [node2432_2496,List.length_append,len2432_2464,len2464_2496]
private def node2496_2560 := instructions2496 ++ instructions2528
private theorem len2496_2560 : node2496_2560.length=64 := by rw [node2496_2560,List.length_append,len2496_2528,len2528_2560]
private def node2560_2624 := instructions2560 ++ instructions2592
private theorem len2560_2624 : node2560_2624.length=64 := by rw [node2560_2624,List.length_append,len2560_2592,len2592_2624]
private def node2624_2688 := instructions2624 ++ instructions2656
private theorem len2624_2688 : node2624_2688.length=64 := by rw [node2624_2688,List.length_append,len2624_2656,len2656_2688]
private def node2688_2752 := instructions2688 ++ instructions2720
private theorem len2688_2752 : node2688_2752.length=64 := by rw [node2688_2752,List.length_append,len2688_2720,len2720_2752]
private def node2752_2816 := instructions2752 ++ instructions2784
private theorem len2752_2816 : node2752_2816.length=64 := by rw [node2752_2816,List.length_append,len2752_2784,len2784_2816]
private def node2816_2880 := instructions2816 ++ instructions2848
private theorem len2816_2880 : node2816_2880.length=64 := by rw [node2816_2880,List.length_append,len2816_2848,len2848_2880]
private def node2880_2944 := instructions2880 ++ instructions2912
private theorem len2880_2944 : node2880_2944.length=64 := by rw [node2880_2944,List.length_append,len2880_2912,len2912_2944]
private def node2944_3008 := instructions2944 ++ instructions2976
private theorem len2944_3008 : node2944_3008.length=64 := by rw [node2944_3008,List.length_append,len2944_2976,len2976_3008]
private def node3008_3072 := instructions3008 ++ instructions3040
private theorem len3008_3072 : node3008_3072.length=64 := by rw [node3008_3072,List.length_append,len3008_3040,len3040_3072]
private def node0_128 := node0_64 ++ node64_128
private theorem len0_128 : node0_128.length=128 := by rw [node0_128,List.length_append,len0_64,len64_128]
private def node128_256 := node128_192 ++ node192_256
private theorem len128_256 : node128_256.length=128 := by rw [node128_256,List.length_append,len128_192,len192_256]
private def node256_384 := node256_320 ++ node320_384
private theorem len256_384 : node256_384.length=128 := by rw [node256_384,List.length_append,len256_320,len320_384]
private def node384_512 := node384_448 ++ node448_512
private theorem len384_512 : node384_512.length=128 := by rw [node384_512,List.length_append,len384_448,len448_512]
private def node512_640 := node512_576 ++ node576_640
private theorem len512_640 : node512_640.length=128 := by rw [node512_640,List.length_append,len512_576,len576_640]
private def node640_768 := node640_704 ++ node704_768
private theorem len640_768 : node640_768.length=128 := by rw [node640_768,List.length_append,len640_704,len704_768]
private def node768_896 := node768_832 ++ node832_896
private theorem len768_896 : node768_896.length=128 := by rw [node768_896,List.length_append,len768_832,len832_896]
private def node896_1024 := node896_960 ++ node960_1024
private theorem len896_1024 : node896_1024.length=128 := by rw [node896_1024,List.length_append,len896_960,len960_1024]
private def node1024_1152 := node1024_1088 ++ node1088_1152
private theorem len1024_1152 : node1024_1152.length=128 := by rw [node1024_1152,List.length_append,len1024_1088,len1088_1152]
private def node1152_1280 := node1152_1216 ++ node1216_1280
private theorem len1152_1280 : node1152_1280.length=128 := by rw [node1152_1280,List.length_append,len1152_1216,len1216_1280]
private def node1280_1408 := node1280_1344 ++ node1344_1408
private theorem len1280_1408 : node1280_1408.length=128 := by rw [node1280_1408,List.length_append,len1280_1344,len1344_1408]
private def node1408_1536 := node1408_1472 ++ node1472_1536
private theorem len1408_1536 : node1408_1536.length=128 := by rw [node1408_1536,List.length_append,len1408_1472,len1472_1536]
private def node1536_1664 := node1536_1600 ++ node1600_1664
private theorem len1536_1664 : node1536_1664.length=128 := by rw [node1536_1664,List.length_append,len1536_1600,len1600_1664]
private def node1664_1792 := node1664_1728 ++ node1728_1792
private theorem len1664_1792 : node1664_1792.length=128 := by rw [node1664_1792,List.length_append,len1664_1728,len1728_1792]
private def node1792_1920 := node1792_1856 ++ node1856_1920
private theorem len1792_1920 : node1792_1920.length=128 := by rw [node1792_1920,List.length_append,len1792_1856,len1856_1920]
private def node1920_2048 := node1920_1984 ++ node1984_2048
private theorem len1920_2048 : node1920_2048.length=128 := by rw [node1920_2048,List.length_append,len1920_1984,len1984_2048]
private def node2048_2176 := node2048_2112 ++ node2112_2176
private theorem len2048_2176 : node2048_2176.length=128 := by rw [node2048_2176,List.length_append,len2048_2112,len2112_2176]
private def node2176_2304 := node2176_2240 ++ node2240_2304
private theorem len2176_2304 : node2176_2304.length=128 := by rw [node2176_2304,List.length_append,len2176_2240,len2240_2304]
private def node2304_2432 := node2304_2368 ++ node2368_2432
private theorem len2304_2432 : node2304_2432.length=128 := by rw [node2304_2432,List.length_append,len2304_2368,len2368_2432]
private def node2432_2560 := node2432_2496 ++ node2496_2560
private theorem len2432_2560 : node2432_2560.length=128 := by rw [node2432_2560,List.length_append,len2432_2496,len2496_2560]
private def node2560_2688 := node2560_2624 ++ node2624_2688
private theorem len2560_2688 : node2560_2688.length=128 := by rw [node2560_2688,List.length_append,len2560_2624,len2624_2688]
private def node2688_2816 := node2688_2752 ++ node2752_2816
private theorem len2688_2816 : node2688_2816.length=128 := by rw [node2688_2816,List.length_append,len2688_2752,len2752_2816]
private def node2816_2944 := node2816_2880 ++ node2880_2944
private theorem len2816_2944 : node2816_2944.length=128 := by rw [node2816_2944,List.length_append,len2816_2880,len2880_2944]
private def node2944_3072 := node2944_3008 ++ node3008_3072
private theorem len2944_3072 : node2944_3072.length=128 := by rw [node2944_3072,List.length_append,len2944_3008,len3008_3072]
private def node0_256 := node0_128 ++ node128_256
private theorem len0_256 : node0_256.length=256 := by rw [node0_256,List.length_append,len0_128,len128_256]
private def node256_512 := node256_384 ++ node384_512
private theorem len256_512 : node256_512.length=256 := by rw [node256_512,List.length_append,len256_384,len384_512]
private def node512_768 := node512_640 ++ node640_768
private theorem len512_768 : node512_768.length=256 := by rw [node512_768,List.length_append,len512_640,len640_768]
private def node768_1024 := node768_896 ++ node896_1024
private theorem len768_1024 : node768_1024.length=256 := by rw [node768_1024,List.length_append,len768_896,len896_1024]
private def node1024_1280 := node1024_1152 ++ node1152_1280
private theorem len1024_1280 : node1024_1280.length=256 := by rw [node1024_1280,List.length_append,len1024_1152,len1152_1280]
private def node1280_1536 := node1280_1408 ++ node1408_1536
private theorem len1280_1536 : node1280_1536.length=256 := by rw [node1280_1536,List.length_append,len1280_1408,len1408_1536]
private def node1536_1792 := node1536_1664 ++ node1664_1792
private theorem len1536_1792 : node1536_1792.length=256 := by rw [node1536_1792,List.length_append,len1536_1664,len1664_1792]
private def node1792_2048 := node1792_1920 ++ node1920_2048
private theorem len1792_2048 : node1792_2048.length=256 := by rw [node1792_2048,List.length_append,len1792_1920,len1920_2048]
private def node2048_2304 := node2048_2176 ++ node2176_2304
private theorem len2048_2304 : node2048_2304.length=256 := by rw [node2048_2304,List.length_append,len2048_2176,len2176_2304]
private def node2304_2560 := node2304_2432 ++ node2432_2560
private theorem len2304_2560 : node2304_2560.length=256 := by rw [node2304_2560,List.length_append,len2304_2432,len2432_2560]
private def node2560_2816 := node2560_2688 ++ node2688_2816
private theorem len2560_2816 : node2560_2816.length=256 := by rw [node2560_2816,List.length_append,len2560_2688,len2688_2816]
private def node2816_3072 := node2816_2944 ++ node2944_3072
private theorem len2816_3072 : node2816_3072.length=256 := by rw [node2816_3072,List.length_append,len2816_2944,len2944_3072]
private def node0_512 := node0_256 ++ node256_512
private theorem len0_512 : node0_512.length=512 := by rw [node0_512,List.length_append,len0_256,len256_512]
private def node512_1024 := node512_768 ++ node768_1024
private theorem len512_1024 : node512_1024.length=512 := by rw [node512_1024,List.length_append,len512_768,len768_1024]
private def node1024_1536 := node1024_1280 ++ node1280_1536
private theorem len1024_1536 : node1024_1536.length=512 := by rw [node1024_1536,List.length_append,len1024_1280,len1280_1536]
private def node1536_2048 := node1536_1792 ++ node1792_2048
private theorem len1536_2048 : node1536_2048.length=512 := by rw [node1536_2048,List.length_append,len1536_1792,len1792_2048]
private def node2048_2560 := node2048_2304 ++ node2304_2560
private theorem len2048_2560 : node2048_2560.length=512 := by rw [node2048_2560,List.length_append,len2048_2304,len2304_2560]
private def node2560_3072 := node2560_2816 ++ node2816_3072
private theorem len2560_3072 : node2560_3072.length=512 := by rw [node2560_3072,List.length_append,len2560_2816,len2816_3072]
private def node0_1024 := node0_512 ++ node512_1024
private theorem len0_1024 : node0_1024.length=1024 := by rw [node0_1024,List.length_append,len0_512,len512_1024]
private def node1024_2048 := node1024_1536 ++ node1536_2048
private theorem len1024_2048 : node1024_2048.length=1024 := by rw [node1024_2048,List.length_append,len1024_1536,len1536_2048]
private def node2048_3072 := node2048_2560 ++ node2560_3072
private theorem len2048_3072 : node2048_3072.length=1024 := by rw [node2048_3072,List.length_append,len2048_2560,len2560_3072]
private def node0_2048 := node0_1024 ++ node1024_2048
private theorem len0_2048 : node0_2048.length=2048 := by rw [node0_2048,List.length_append,len0_1024,len1024_2048]
private def node2048_3089 := node2048_3072 ++ instructions3072
private theorem len2048_3089 : node2048_3089.length=1041 := by rw [node2048_3089,List.length_append,len2048_3072,len3072_3089]
private def node0_3089 := node0_2048 ++ node2048_3089
private theorem len0_3089 : node0_3089.length=3089 := by rw [node0_3089,List.length_append,len0_2048,len2048_3089]
private theorem rootSlice : Slice program node0_3089 0 := fun n _ => by simp only [Nat.zero_add]; rfl
private theorem slice0_2048 : Slice program node0_2048 0 := splitL (b:=node2048_3089) rootSlice
private theorem slice2048_3089 : Slice program node2048_3089 2048 := splitR (a:=node0_2048) (by rw [len0_2048]) rootSlice
private theorem slice2048_3072 : Slice program node2048_3072 2048 := splitL (b:=instructions3072) slice2048_3089
private theorem slice3072_3089 : Slice program instructions3072 3072 := splitR (a:=node2048_3072) (by rw [len2048_3072]) slice2048_3089
private theorem slice0_1024 : Slice program node0_1024 0 := splitL (b:=node1024_2048) slice0_2048
private theorem slice1024_2048 : Slice program node1024_2048 1024 := splitR (a:=node0_1024) (by rw [len0_1024]) slice0_2048
private theorem slice2048_2560 : Slice program node2048_2560 2048 := splitL (b:=node2560_3072) slice2048_3072
private theorem slice2560_3072 : Slice program node2560_3072 2560 := splitR (a:=node2048_2560) (by rw [len2048_2560]) slice2048_3072
private theorem slice1024_1536 : Slice program node1024_1536 1024 := splitL (b:=node1536_2048) slice1024_2048
private theorem slice1536_2048 : Slice program node1536_2048 1536 := splitR (a:=node1024_1536) (by rw [len1024_1536]) slice1024_2048
private theorem slice0_512 : Slice program node0_512 0 := splitL (b:=node512_1024) slice0_1024
private theorem slice512_1024 : Slice program node512_1024 512 := splitR (a:=node0_512) (by rw [len0_512]) slice0_1024
private theorem slice2560_2816 : Slice program node2560_2816 2560 := splitL (b:=node2816_3072) slice2560_3072
private theorem slice2816_3072 : Slice program node2816_3072 2816 := splitR (a:=node2560_2816) (by rw [len2560_2816]) slice2560_3072
private theorem slice2048_2304 : Slice program node2048_2304 2048 := splitL (b:=node2304_2560) slice2048_2560
private theorem slice2304_2560 : Slice program node2304_2560 2304 := splitR (a:=node2048_2304) (by rw [len2048_2304]) slice2048_2560
private theorem slice1536_1792 : Slice program node1536_1792 1536 := splitL (b:=node1792_2048) slice1536_2048
private theorem slice1792_2048 : Slice program node1792_2048 1792 := splitR (a:=node1536_1792) (by rw [len1536_1792]) slice1536_2048
private theorem slice1024_1280 : Slice program node1024_1280 1024 := splitL (b:=node1280_1536) slice1024_1536
private theorem slice1280_1536 : Slice program node1280_1536 1280 := splitR (a:=node1024_1280) (by rw [len1024_1280]) slice1024_1536
private theorem slice512_768 : Slice program node512_768 512 := splitL (b:=node768_1024) slice512_1024
private theorem slice768_1024 : Slice program node768_1024 768 := splitR (a:=node512_768) (by rw [len512_768]) slice512_1024
private theorem slice0_256 : Slice program node0_256 0 := splitL (b:=node256_512) slice0_512
private theorem slice256_512 : Slice program node256_512 256 := splitR (a:=node0_256) (by rw [len0_256]) slice0_512
private theorem slice2816_2944 : Slice program node2816_2944 2816 := splitL (b:=node2944_3072) slice2816_3072
private theorem slice2944_3072 : Slice program node2944_3072 2944 := splitR (a:=node2816_2944) (by rw [len2816_2944]) slice2816_3072
private theorem slice2560_2688 : Slice program node2560_2688 2560 := splitL (b:=node2688_2816) slice2560_2816
private theorem slice2688_2816 : Slice program node2688_2816 2688 := splitR (a:=node2560_2688) (by rw [len2560_2688]) slice2560_2816
private theorem slice2304_2432 : Slice program node2304_2432 2304 := splitL (b:=node2432_2560) slice2304_2560
private theorem slice2432_2560 : Slice program node2432_2560 2432 := splitR (a:=node2304_2432) (by rw [len2304_2432]) slice2304_2560
private theorem slice2048_2176 : Slice program node2048_2176 2048 := splitL (b:=node2176_2304) slice2048_2304
private theorem slice2176_2304 : Slice program node2176_2304 2176 := splitR (a:=node2048_2176) (by rw [len2048_2176]) slice2048_2304
private theorem slice1792_1920 : Slice program node1792_1920 1792 := splitL (b:=node1920_2048) slice1792_2048
private theorem slice1920_2048 : Slice program node1920_2048 1920 := splitR (a:=node1792_1920) (by rw [len1792_1920]) slice1792_2048
private theorem slice1536_1664 : Slice program node1536_1664 1536 := splitL (b:=node1664_1792) slice1536_1792
private theorem slice1664_1792 : Slice program node1664_1792 1664 := splitR (a:=node1536_1664) (by rw [len1536_1664]) slice1536_1792
private theorem slice1280_1408 : Slice program node1280_1408 1280 := splitL (b:=node1408_1536) slice1280_1536
private theorem slice1408_1536 : Slice program node1408_1536 1408 := splitR (a:=node1280_1408) (by rw [len1280_1408]) slice1280_1536
private theorem slice1024_1152 : Slice program node1024_1152 1024 := splitL (b:=node1152_1280) slice1024_1280
private theorem slice1152_1280 : Slice program node1152_1280 1152 := splitR (a:=node1024_1152) (by rw [len1024_1152]) slice1024_1280
private theorem slice768_896 : Slice program node768_896 768 := splitL (b:=node896_1024) slice768_1024
private theorem slice896_1024 : Slice program node896_1024 896 := splitR (a:=node768_896) (by rw [len768_896]) slice768_1024
private theorem slice512_640 : Slice program node512_640 512 := splitL (b:=node640_768) slice512_768
private theorem slice640_768 : Slice program node640_768 640 := splitR (a:=node512_640) (by rw [len512_640]) slice512_768
private theorem slice256_384 : Slice program node256_384 256 := splitL (b:=node384_512) slice256_512
private theorem slice384_512 : Slice program node384_512 384 := splitR (a:=node256_384) (by rw [len256_384]) slice256_512
private theorem slice0_128 : Slice program node0_128 0 := splitL (b:=node128_256) slice0_256
private theorem slice128_256 : Slice program node128_256 128 := splitR (a:=node0_128) (by rw [len0_128]) slice0_256
private theorem slice2944_3008 : Slice program node2944_3008 2944 := splitL (b:=node3008_3072) slice2944_3072
private theorem slice3008_3072 : Slice program node3008_3072 3008 := splitR (a:=node2944_3008) (by rw [len2944_3008]) slice2944_3072
private theorem slice2816_2880 : Slice program node2816_2880 2816 := splitL (b:=node2880_2944) slice2816_2944
private theorem slice2880_2944 : Slice program node2880_2944 2880 := splitR (a:=node2816_2880) (by rw [len2816_2880]) slice2816_2944
private theorem slice2688_2752 : Slice program node2688_2752 2688 := splitL (b:=node2752_2816) slice2688_2816
private theorem slice2752_2816 : Slice program node2752_2816 2752 := splitR (a:=node2688_2752) (by rw [len2688_2752]) slice2688_2816
private theorem slice2560_2624 : Slice program node2560_2624 2560 := splitL (b:=node2624_2688) slice2560_2688
private theorem slice2624_2688 : Slice program node2624_2688 2624 := splitR (a:=node2560_2624) (by rw [len2560_2624]) slice2560_2688
private theorem slice2432_2496 : Slice program node2432_2496 2432 := splitL (b:=node2496_2560) slice2432_2560
private theorem slice2496_2560 : Slice program node2496_2560 2496 := splitR (a:=node2432_2496) (by rw [len2432_2496]) slice2432_2560
private theorem slice2304_2368 : Slice program node2304_2368 2304 := splitL (b:=node2368_2432) slice2304_2432
private theorem slice2368_2432 : Slice program node2368_2432 2368 := splitR (a:=node2304_2368) (by rw [len2304_2368]) slice2304_2432
private theorem slice2176_2240 : Slice program node2176_2240 2176 := splitL (b:=node2240_2304) slice2176_2304
private theorem slice2240_2304 : Slice program node2240_2304 2240 := splitR (a:=node2176_2240) (by rw [len2176_2240]) slice2176_2304
private theorem slice2048_2112 : Slice program node2048_2112 2048 := splitL (b:=node2112_2176) slice2048_2176
private theorem slice2112_2176 : Slice program node2112_2176 2112 := splitR (a:=node2048_2112) (by rw [len2048_2112]) slice2048_2176
private theorem slice1920_1984 : Slice program node1920_1984 1920 := splitL (b:=node1984_2048) slice1920_2048
private theorem slice1984_2048 : Slice program node1984_2048 1984 := splitR (a:=node1920_1984) (by rw [len1920_1984]) slice1920_2048
private theorem slice1792_1856 : Slice program node1792_1856 1792 := splitL (b:=node1856_1920) slice1792_1920
private theorem slice1856_1920 : Slice program node1856_1920 1856 := splitR (a:=node1792_1856) (by rw [len1792_1856]) slice1792_1920
private theorem slice1664_1728 : Slice program node1664_1728 1664 := splitL (b:=node1728_1792) slice1664_1792
private theorem slice1728_1792 : Slice program node1728_1792 1728 := splitR (a:=node1664_1728) (by rw [len1664_1728]) slice1664_1792
private theorem slice1536_1600 : Slice program node1536_1600 1536 := splitL (b:=node1600_1664) slice1536_1664
private theorem slice1600_1664 : Slice program node1600_1664 1600 := splitR (a:=node1536_1600) (by rw [len1536_1600]) slice1536_1664
private theorem slice1408_1472 : Slice program node1408_1472 1408 := splitL (b:=node1472_1536) slice1408_1536
private theorem slice1472_1536 : Slice program node1472_1536 1472 := splitR (a:=node1408_1472) (by rw [len1408_1472]) slice1408_1536
private theorem slice1280_1344 : Slice program node1280_1344 1280 := splitL (b:=node1344_1408) slice1280_1408
private theorem slice1344_1408 : Slice program node1344_1408 1344 := splitR (a:=node1280_1344) (by rw [len1280_1344]) slice1280_1408
private theorem slice1152_1216 : Slice program node1152_1216 1152 := splitL (b:=node1216_1280) slice1152_1280
private theorem slice1216_1280 : Slice program node1216_1280 1216 := splitR (a:=node1152_1216) (by rw [len1152_1216]) slice1152_1280
private theorem slice1024_1088 : Slice program node1024_1088 1024 := splitL (b:=node1088_1152) slice1024_1152
private theorem slice1088_1152 : Slice program node1088_1152 1088 := splitR (a:=node1024_1088) (by rw [len1024_1088]) slice1024_1152
private theorem slice896_960 : Slice program node896_960 896 := splitL (b:=node960_1024) slice896_1024
private theorem slice960_1024 : Slice program node960_1024 960 := splitR (a:=node896_960) (by rw [len896_960]) slice896_1024
private theorem slice768_832 : Slice program node768_832 768 := splitL (b:=node832_896) slice768_896
private theorem slice832_896 : Slice program node832_896 832 := splitR (a:=node768_832) (by rw [len768_832]) slice768_896
private theorem slice640_704 : Slice program node640_704 640 := splitL (b:=node704_768) slice640_768
private theorem slice704_768 : Slice program node704_768 704 := splitR (a:=node640_704) (by rw [len640_704]) slice640_768
private theorem slice512_576 : Slice program node512_576 512 := splitL (b:=node576_640) slice512_640
private theorem slice576_640 : Slice program node576_640 576 := splitR (a:=node512_576) (by rw [len512_576]) slice512_640
private theorem slice384_448 : Slice program node384_448 384 := splitL (b:=node448_512) slice384_512
private theorem slice448_512 : Slice program node448_512 448 := splitR (a:=node384_448) (by rw [len384_448]) slice384_512
private theorem slice256_320 : Slice program node256_320 256 := splitL (b:=node320_384) slice256_384
private theorem slice320_384 : Slice program node320_384 320 := splitR (a:=node256_320) (by rw [len256_320]) slice256_384
private theorem slice128_192 : Slice program node128_192 128 := splitL (b:=node192_256) slice128_256
private theorem slice192_256 : Slice program node192_256 192 := splitR (a:=node128_192) (by rw [len128_192]) slice128_256
private theorem slice0_64 : Slice program node0_64 0 := splitL (b:=node64_128) slice0_128
private theorem slice64_128 : Slice program node64_128 64 := splitR (a:=node0_64) (by rw [len0_64]) slice0_128
private theorem slice3008_3040 : Slice program instructions3008 3008 := splitL (b:=instructions3040) slice3008_3072
private theorem slice3040_3072 : Slice program instructions3040 3040 := splitR (a:=instructions3008) (by rw [len3008_3040]) slice3008_3072
private theorem slice2944_2976 : Slice program instructions2944 2944 := splitL (b:=instructions2976) slice2944_3008
private theorem slice2976_3008 : Slice program instructions2976 2976 := splitR (a:=instructions2944) (by rw [len2944_2976]) slice2944_3008
private theorem slice2880_2912 : Slice program instructions2880 2880 := splitL (b:=instructions2912) slice2880_2944
private theorem slice2912_2944 : Slice program instructions2912 2912 := splitR (a:=instructions2880) (by rw [len2880_2912]) slice2880_2944
private theorem slice2816_2848 : Slice program instructions2816 2816 := splitL (b:=instructions2848) slice2816_2880
private theorem slice2848_2880 : Slice program instructions2848 2848 := splitR (a:=instructions2816) (by rw [len2816_2848]) slice2816_2880
private theorem slice2752_2784 : Slice program instructions2752 2752 := splitL (b:=instructions2784) slice2752_2816
private theorem slice2784_2816 : Slice program instructions2784 2784 := splitR (a:=instructions2752) (by rw [len2752_2784]) slice2752_2816
private theorem slice2688_2720 : Slice program instructions2688 2688 := splitL (b:=instructions2720) slice2688_2752
private theorem slice2720_2752 : Slice program instructions2720 2720 := splitR (a:=instructions2688) (by rw [len2688_2720]) slice2688_2752
private theorem slice2624_2656 : Slice program instructions2624 2624 := splitL (b:=instructions2656) slice2624_2688
private theorem slice2656_2688 : Slice program instructions2656 2656 := splitR (a:=instructions2624) (by rw [len2624_2656]) slice2624_2688
private theorem slice2560_2592 : Slice program instructions2560 2560 := splitL (b:=instructions2592) slice2560_2624
private theorem slice2592_2624 : Slice program instructions2592 2592 := splitR (a:=instructions2560) (by rw [len2560_2592]) slice2560_2624
private theorem slice2496_2528 : Slice program instructions2496 2496 := splitL (b:=instructions2528) slice2496_2560
private theorem slice2528_2560 : Slice program instructions2528 2528 := splitR (a:=instructions2496) (by rw [len2496_2528]) slice2496_2560
private theorem slice2432_2464 : Slice program instructions2432 2432 := splitL (b:=instructions2464) slice2432_2496
private theorem slice2464_2496 : Slice program instructions2464 2464 := splitR (a:=instructions2432) (by rw [len2432_2464]) slice2432_2496
private theorem slice2368_2400 : Slice program instructions2368 2368 := splitL (b:=instructions2400) slice2368_2432
private theorem slice2400_2432 : Slice program instructions2400 2400 := splitR (a:=instructions2368) (by rw [len2368_2400]) slice2368_2432
private theorem slice2304_2336 : Slice program instructions2304 2304 := splitL (b:=instructions2336) slice2304_2368
private theorem slice2336_2368 : Slice program instructions2336 2336 := splitR (a:=instructions2304) (by rw [len2304_2336]) slice2304_2368
private theorem slice2240_2272 : Slice program instructions2240 2240 := splitL (b:=instructions2272) slice2240_2304
private theorem slice2272_2304 : Slice program instructions2272 2272 := splitR (a:=instructions2240) (by rw [len2240_2272]) slice2240_2304
private theorem slice2176_2208 : Slice program instructions2176 2176 := splitL (b:=instructions2208) slice2176_2240
private theorem slice2208_2240 : Slice program instructions2208 2208 := splitR (a:=instructions2176) (by rw [len2176_2208]) slice2176_2240
private theorem slice2112_2144 : Slice program instructions2112 2112 := splitL (b:=instructions2144) slice2112_2176
private theorem slice2144_2176 : Slice program instructions2144 2144 := splitR (a:=instructions2112) (by rw [len2112_2144]) slice2112_2176
private theorem slice2048_2080 : Slice program instructions2048 2048 := splitL (b:=instructions2080) slice2048_2112
private theorem slice2080_2112 : Slice program instructions2080 2080 := splitR (a:=instructions2048) (by rw [len2048_2080]) slice2048_2112
private theorem slice1984_2016 : Slice program instructions1984 1984 := splitL (b:=instructions2016) slice1984_2048
private theorem slice2016_2048 : Slice program instructions2016 2016 := splitR (a:=instructions1984) (by rw [len1984_2016]) slice1984_2048
private theorem slice1920_1952 : Slice program instructions1920 1920 := splitL (b:=instructions1952) slice1920_1984
private theorem slice1952_1984 : Slice program instructions1952 1952 := splitR (a:=instructions1920) (by rw [len1920_1952]) slice1920_1984
private theorem slice1856_1888 : Slice program instructions1856 1856 := splitL (b:=instructions1888) slice1856_1920
private theorem slice1888_1920 : Slice program instructions1888 1888 := splitR (a:=instructions1856) (by rw [len1856_1888]) slice1856_1920
private theorem slice1792_1824 : Slice program instructions1792 1792 := splitL (b:=instructions1824) slice1792_1856
private theorem slice1824_1856 : Slice program instructions1824 1824 := splitR (a:=instructions1792) (by rw [len1792_1824]) slice1792_1856
private theorem slice1728_1760 : Slice program instructions1728 1728 := splitL (b:=instructions1760) slice1728_1792
private theorem slice1760_1792 : Slice program instructions1760 1760 := splitR (a:=instructions1728) (by rw [len1728_1760]) slice1728_1792
private theorem slice1664_1696 : Slice program instructions1664 1664 := splitL (b:=instructions1696) slice1664_1728
private theorem slice1696_1728 : Slice program instructions1696 1696 := splitR (a:=instructions1664) (by rw [len1664_1696]) slice1664_1728
private theorem slice1600_1632 : Slice program instructions1600 1600 := splitL (b:=instructions1632) slice1600_1664
private theorem slice1632_1664 : Slice program instructions1632 1632 := splitR (a:=instructions1600) (by rw [len1600_1632]) slice1600_1664
private theorem slice1536_1568 : Slice program instructions1536 1536 := splitL (b:=instructions1568) slice1536_1600
private theorem slice1568_1600 : Slice program instructions1568 1568 := splitR (a:=instructions1536) (by rw [len1536_1568]) slice1536_1600
private theorem slice1472_1504 : Slice program instructions1472 1472 := splitL (b:=instructions1504) slice1472_1536
private theorem slice1504_1536 : Slice program instructions1504 1504 := splitR (a:=instructions1472) (by rw [len1472_1504]) slice1472_1536
private theorem slice1408_1440 : Slice program instructions1408 1408 := splitL (b:=instructions1440) slice1408_1472
private theorem slice1440_1472 : Slice program instructions1440 1440 := splitR (a:=instructions1408) (by rw [len1408_1440]) slice1408_1472
private theorem slice1344_1376 : Slice program instructions1344 1344 := splitL (b:=instructions1376) slice1344_1408
private theorem slice1376_1408 : Slice program instructions1376 1376 := splitR (a:=instructions1344) (by rw [len1344_1376]) slice1344_1408
private theorem slice1280_1312 : Slice program instructions1280 1280 := splitL (b:=instructions1312) slice1280_1344
private theorem slice1312_1344 : Slice program instructions1312 1312 := splitR (a:=instructions1280) (by rw [len1280_1312]) slice1280_1344
private theorem slice1216_1248 : Slice program instructions1216 1216 := splitL (b:=instructions1248) slice1216_1280
private theorem slice1248_1280 : Slice program instructions1248 1248 := splitR (a:=instructions1216) (by rw [len1216_1248]) slice1216_1280
private theorem slice1152_1184 : Slice program instructions1152 1152 := splitL (b:=instructions1184) slice1152_1216
private theorem slice1184_1216 : Slice program instructions1184 1184 := splitR (a:=instructions1152) (by rw [len1152_1184]) slice1152_1216
private theorem slice1088_1120 : Slice program instructions1088 1088 := splitL (b:=instructions1120) slice1088_1152
private theorem slice1120_1152 : Slice program instructions1120 1120 := splitR (a:=instructions1088) (by rw [len1088_1120]) slice1088_1152
private theorem slice1024_1056 : Slice program instructions1024 1024 := splitL (b:=instructions1056) slice1024_1088
private theorem slice1056_1088 : Slice program instructions1056 1056 := splitR (a:=instructions1024) (by rw [len1024_1056]) slice1024_1088
private theorem slice960_992 : Slice program instructions960 960 := splitL (b:=instructions992) slice960_1024
private theorem slice992_1024 : Slice program instructions992 992 := splitR (a:=instructions960) (by rw [len960_992]) slice960_1024
private theorem slice896_928 : Slice program instructions896 896 := splitL (b:=instructions928) slice896_960
private theorem slice928_960 : Slice program instructions928 928 := splitR (a:=instructions896) (by rw [len896_928]) slice896_960
private theorem slice832_864 : Slice program instructions832 832 := splitL (b:=instructions864) slice832_896
private theorem slice864_896 : Slice program instructions864 864 := splitR (a:=instructions832) (by rw [len832_864]) slice832_896
private theorem slice768_800 : Slice program instructions768 768 := splitL (b:=instructions800) slice768_832
private theorem slice800_832 : Slice program instructions800 800 := splitR (a:=instructions768) (by rw [len768_800]) slice768_832
private theorem slice704_736 : Slice program instructions704 704 := splitL (b:=instructions736) slice704_768
private theorem slice736_768 : Slice program instructions736 736 := splitR (a:=instructions704) (by rw [len704_736]) slice704_768
private theorem slice640_672 : Slice program instructions640 640 := splitL (b:=instructions672) slice640_704
private theorem slice672_704 : Slice program instructions672 672 := splitR (a:=instructions640) (by rw [len640_672]) slice640_704
private theorem slice576_608 : Slice program instructions576 576 := splitL (b:=instructions608) slice576_640
private theorem slice608_640 : Slice program instructions608 608 := splitR (a:=instructions576) (by rw [len576_608]) slice576_640
private theorem slice512_544 : Slice program instructions512 512 := splitL (b:=instructions544) slice512_576
private theorem slice544_576 : Slice program instructions544 544 := splitR (a:=instructions512) (by rw [len512_544]) slice512_576
private theorem slice448_480 : Slice program instructions448 448 := splitL (b:=instructions480) slice448_512
private theorem slice480_512 : Slice program instructions480 480 := splitR (a:=instructions448) (by rw [len448_480]) slice448_512
private theorem slice384_416 : Slice program instructions384 384 := splitL (b:=instructions416) slice384_448
private theorem slice416_448 : Slice program instructions416 416 := splitR (a:=instructions384) (by rw [len384_416]) slice384_448
private theorem slice320_352 : Slice program instructions320 320 := splitL (b:=instructions352) slice320_384
private theorem slice352_384 : Slice program instructions352 352 := splitR (a:=instructions320) (by rw [len320_352]) slice320_384
private theorem slice256_288 : Slice program instructions256 256 := splitL (b:=instructions288) slice256_320
private theorem slice288_320 : Slice program instructions288 288 := splitR (a:=instructions256) (by rw [len256_288]) slice256_320
private theorem slice192_224 : Slice program instructions192 192 := splitL (b:=instructions224) slice192_256
private theorem slice224_256 : Slice program instructions224 224 := splitR (a:=instructions192) (by rw [len192_224]) slice192_256
private theorem slice128_160 : Slice program instructions128 128 := splitL (b:=instructions160) slice128_192
private theorem slice160_192 : Slice program instructions160 160 := splitR (a:=instructions128) (by rw [len128_160]) slice128_192
private theorem slice64_96 : Slice program instructions64 64 := splitL (b:=instructions96) slice64_128
private theorem slice96_128 : Slice program instructions96 96 := splitR (a:=instructions64) (by rw [len64_96]) slice64_128
private theorem slice0_32 : Slice program instructions0 0 := splitL (b:=instructions32) slice0_64
private theorem slice32_64 : Slice program instructions32 32 := splitR (a:=instructions0) (by rw [len0_32]) slice0_64
theorem inBlock0 (i : Nat) (h : i<32) : program[0+i]?=instructions0[i]? := slice0_32 i (by rwa [len0_32])
theorem inBlock32 (i : Nat) (h : i<32) : program[32+i]?=instructions32[i]? := slice32_64 i (by rwa [len32_64])
theorem inBlock64 (i : Nat) (h : i<32) : program[64+i]?=instructions64[i]? := slice64_96 i (by rwa [len64_96])
theorem inBlock96 (i : Nat) (h : i<32) : program[96+i]?=instructions96[i]? := slice96_128 i (by rwa [len96_128])
theorem inBlock128 (i : Nat) (h : i<32) : program[128+i]?=instructions128[i]? := slice128_160 i (by rwa [len128_160])
theorem inBlock160 (i : Nat) (h : i<32) : program[160+i]?=instructions160[i]? := slice160_192 i (by rwa [len160_192])
theorem inBlock192 (i : Nat) (h : i<32) : program[192+i]?=instructions192[i]? := slice192_224 i (by rwa [len192_224])
theorem inBlock224 (i : Nat) (h : i<32) : program[224+i]?=instructions224[i]? := slice224_256 i (by rwa [len224_256])
theorem inBlock256 (i : Nat) (h : i<32) : program[256+i]?=instructions256[i]? := slice256_288 i (by rwa [len256_288])
theorem inBlock288 (i : Nat) (h : i<32) : program[288+i]?=instructions288[i]? := slice288_320 i (by rwa [len288_320])
theorem inBlock320 (i : Nat) (h : i<32) : program[320+i]?=instructions320[i]? := slice320_352 i (by rwa [len320_352])
theorem inBlock352 (i : Nat) (h : i<32) : program[352+i]?=instructions352[i]? := slice352_384 i (by rwa [len352_384])
theorem inBlock384 (i : Nat) (h : i<32) : program[384+i]?=instructions384[i]? := slice384_416 i (by rwa [len384_416])
theorem inBlock416 (i : Nat) (h : i<32) : program[416+i]?=instructions416[i]? := slice416_448 i (by rwa [len416_448])
theorem inBlock448 (i : Nat) (h : i<32) : program[448+i]?=instructions448[i]? := slice448_480 i (by rwa [len448_480])
theorem inBlock480 (i : Nat) (h : i<32) : program[480+i]?=instructions480[i]? := slice480_512 i (by rwa [len480_512])
theorem inBlock512 (i : Nat) (h : i<32) : program[512+i]?=instructions512[i]? := slice512_544 i (by rwa [len512_544])
theorem inBlock544 (i : Nat) (h : i<32) : program[544+i]?=instructions544[i]? := slice544_576 i (by rwa [len544_576])
theorem inBlock576 (i : Nat) (h : i<32) : program[576+i]?=instructions576[i]? := slice576_608 i (by rwa [len576_608])
theorem inBlock608 (i : Nat) (h : i<32) : program[608+i]?=instructions608[i]? := slice608_640 i (by rwa [len608_640])
theorem inBlock640 (i : Nat) (h : i<32) : program[640+i]?=instructions640[i]? := slice640_672 i (by rwa [len640_672])
theorem inBlock672 (i : Nat) (h : i<32) : program[672+i]?=instructions672[i]? := slice672_704 i (by rwa [len672_704])
theorem inBlock704 (i : Nat) (h : i<32) : program[704+i]?=instructions704[i]? := slice704_736 i (by rwa [len704_736])
theorem inBlock736 (i : Nat) (h : i<32) : program[736+i]?=instructions736[i]? := slice736_768 i (by rwa [len736_768])
theorem inBlock768 (i : Nat) (h : i<32) : program[768+i]?=instructions768[i]? := slice768_800 i (by rwa [len768_800])
theorem inBlock800 (i : Nat) (h : i<32) : program[800+i]?=instructions800[i]? := slice800_832 i (by rwa [len800_832])
theorem inBlock832 (i : Nat) (h : i<32) : program[832+i]?=instructions832[i]? := slice832_864 i (by rwa [len832_864])
theorem inBlock864 (i : Nat) (h : i<32) : program[864+i]?=instructions864[i]? := slice864_896 i (by rwa [len864_896])
theorem inBlock896 (i : Nat) (h : i<32) : program[896+i]?=instructions896[i]? := slice896_928 i (by rwa [len896_928])
theorem inBlock928 (i : Nat) (h : i<32) : program[928+i]?=instructions928[i]? := slice928_960 i (by rwa [len928_960])
theorem inBlock960 (i : Nat) (h : i<32) : program[960+i]?=instructions960[i]? := slice960_992 i (by rwa [len960_992])
theorem inBlock992 (i : Nat) (h : i<32) : program[992+i]?=instructions992[i]? := slice992_1024 i (by rwa [len992_1024])
theorem inBlock1024 (i : Nat) (h : i<32) : program[1024+i]?=instructions1024[i]? := slice1024_1056 i (by rwa [len1024_1056])
theorem inBlock1056 (i : Nat) (h : i<32) : program[1056+i]?=instructions1056[i]? := slice1056_1088 i (by rwa [len1056_1088])
theorem inBlock1088 (i : Nat) (h : i<32) : program[1088+i]?=instructions1088[i]? := slice1088_1120 i (by rwa [len1088_1120])
theorem inBlock1120 (i : Nat) (h : i<32) : program[1120+i]?=instructions1120[i]? := slice1120_1152 i (by rwa [len1120_1152])
theorem inBlock1152 (i : Nat) (h : i<32) : program[1152+i]?=instructions1152[i]? := slice1152_1184 i (by rwa [len1152_1184])
theorem inBlock1184 (i : Nat) (h : i<32) : program[1184+i]?=instructions1184[i]? := slice1184_1216 i (by rwa [len1184_1216])
theorem inBlock1216 (i : Nat) (h : i<32) : program[1216+i]?=instructions1216[i]? := slice1216_1248 i (by rwa [len1216_1248])
theorem inBlock1248 (i : Nat) (h : i<32) : program[1248+i]?=instructions1248[i]? := slice1248_1280 i (by rwa [len1248_1280])
theorem inBlock1280 (i : Nat) (h : i<32) : program[1280+i]?=instructions1280[i]? := slice1280_1312 i (by rwa [len1280_1312])
theorem inBlock1312 (i : Nat) (h : i<32) : program[1312+i]?=instructions1312[i]? := slice1312_1344 i (by rwa [len1312_1344])
theorem inBlock1344 (i : Nat) (h : i<32) : program[1344+i]?=instructions1344[i]? := slice1344_1376 i (by rwa [len1344_1376])
theorem inBlock1376 (i : Nat) (h : i<32) : program[1376+i]?=instructions1376[i]? := slice1376_1408 i (by rwa [len1376_1408])
theorem inBlock1408 (i : Nat) (h : i<32) : program[1408+i]?=instructions1408[i]? := slice1408_1440 i (by rwa [len1408_1440])
theorem inBlock1440 (i : Nat) (h : i<32) : program[1440+i]?=instructions1440[i]? := slice1440_1472 i (by rwa [len1440_1472])
theorem inBlock1472 (i : Nat) (h : i<32) : program[1472+i]?=instructions1472[i]? := slice1472_1504 i (by rwa [len1472_1504])
theorem inBlock1504 (i : Nat) (h : i<32) : program[1504+i]?=instructions1504[i]? := slice1504_1536 i (by rwa [len1504_1536])
theorem inBlock1536 (i : Nat) (h : i<32) : program[1536+i]?=instructions1536[i]? := slice1536_1568 i (by rwa [len1536_1568])
theorem inBlock1568 (i : Nat) (h : i<32) : program[1568+i]?=instructions1568[i]? := slice1568_1600 i (by rwa [len1568_1600])
theorem inBlock1600 (i : Nat) (h : i<32) : program[1600+i]?=instructions1600[i]? := slice1600_1632 i (by rwa [len1600_1632])
theorem inBlock1632 (i : Nat) (h : i<32) : program[1632+i]?=instructions1632[i]? := slice1632_1664 i (by rwa [len1632_1664])
theorem inBlock1664 (i : Nat) (h : i<32) : program[1664+i]?=instructions1664[i]? := slice1664_1696 i (by rwa [len1664_1696])
theorem inBlock1696 (i : Nat) (h : i<32) : program[1696+i]?=instructions1696[i]? := slice1696_1728 i (by rwa [len1696_1728])
theorem inBlock1728 (i : Nat) (h : i<32) : program[1728+i]?=instructions1728[i]? := slice1728_1760 i (by rwa [len1728_1760])
theorem inBlock1760 (i : Nat) (h : i<32) : program[1760+i]?=instructions1760[i]? := slice1760_1792 i (by rwa [len1760_1792])
theorem inBlock1792 (i : Nat) (h : i<32) : program[1792+i]?=instructions1792[i]? := slice1792_1824 i (by rwa [len1792_1824])
theorem inBlock1824 (i : Nat) (h : i<32) : program[1824+i]?=instructions1824[i]? := slice1824_1856 i (by rwa [len1824_1856])
theorem inBlock1856 (i : Nat) (h : i<32) : program[1856+i]?=instructions1856[i]? := slice1856_1888 i (by rwa [len1856_1888])
theorem inBlock1888 (i : Nat) (h : i<32) : program[1888+i]?=instructions1888[i]? := slice1888_1920 i (by rwa [len1888_1920])
theorem inBlock1920 (i : Nat) (h : i<32) : program[1920+i]?=instructions1920[i]? := slice1920_1952 i (by rwa [len1920_1952])
theorem inBlock1952 (i : Nat) (h : i<32) : program[1952+i]?=instructions1952[i]? := slice1952_1984 i (by rwa [len1952_1984])
theorem inBlock1984 (i : Nat) (h : i<32) : program[1984+i]?=instructions1984[i]? := slice1984_2016 i (by rwa [len1984_2016])
theorem inBlock2016 (i : Nat) (h : i<32) : program[2016+i]?=instructions2016[i]? := slice2016_2048 i (by rwa [len2016_2048])
theorem inBlock2048 (i : Nat) (h : i<32) : program[2048+i]?=instructions2048[i]? := slice2048_2080 i (by rwa [len2048_2080])
theorem inBlock2080 (i : Nat) (h : i<32) : program[2080+i]?=instructions2080[i]? := slice2080_2112 i (by rwa [len2080_2112])
theorem inBlock2112 (i : Nat) (h : i<32) : program[2112+i]?=instructions2112[i]? := slice2112_2144 i (by rwa [len2112_2144])
theorem inBlock2144 (i : Nat) (h : i<32) : program[2144+i]?=instructions2144[i]? := slice2144_2176 i (by rwa [len2144_2176])
theorem inBlock2176 (i : Nat) (h : i<32) : program[2176+i]?=instructions2176[i]? := slice2176_2208 i (by rwa [len2176_2208])
theorem inBlock2208 (i : Nat) (h : i<32) : program[2208+i]?=instructions2208[i]? := slice2208_2240 i (by rwa [len2208_2240])
theorem inBlock2240 (i : Nat) (h : i<32) : program[2240+i]?=instructions2240[i]? := slice2240_2272 i (by rwa [len2240_2272])
theorem inBlock2272 (i : Nat) (h : i<32) : program[2272+i]?=instructions2272[i]? := slice2272_2304 i (by rwa [len2272_2304])
theorem inBlock2304 (i : Nat) (h : i<32) : program[2304+i]?=instructions2304[i]? := slice2304_2336 i (by rwa [len2304_2336])
theorem inBlock2336 (i : Nat) (h : i<32) : program[2336+i]?=instructions2336[i]? := slice2336_2368 i (by rwa [len2336_2368])
theorem inBlock2368 (i : Nat) (h : i<32) : program[2368+i]?=instructions2368[i]? := slice2368_2400 i (by rwa [len2368_2400])
theorem inBlock2400 (i : Nat) (h : i<32) : program[2400+i]?=instructions2400[i]? := slice2400_2432 i (by rwa [len2400_2432])
theorem inBlock2432 (i : Nat) (h : i<32) : program[2432+i]?=instructions2432[i]? := slice2432_2464 i (by rwa [len2432_2464])
theorem inBlock2464 (i : Nat) (h : i<32) : program[2464+i]?=instructions2464[i]? := slice2464_2496 i (by rwa [len2464_2496])
theorem inBlock2496 (i : Nat) (h : i<32) : program[2496+i]?=instructions2496[i]? := slice2496_2528 i (by rwa [len2496_2528])
theorem inBlock2528 (i : Nat) (h : i<32) : program[2528+i]?=instructions2528[i]? := slice2528_2560 i (by rwa [len2528_2560])
theorem inBlock2560 (i : Nat) (h : i<32) : program[2560+i]?=instructions2560[i]? := slice2560_2592 i (by rwa [len2560_2592])
theorem inBlock2592 (i : Nat) (h : i<32) : program[2592+i]?=instructions2592[i]? := slice2592_2624 i (by rwa [len2592_2624])
theorem inBlock2624 (i : Nat) (h : i<32) : program[2624+i]?=instructions2624[i]? := slice2624_2656 i (by rwa [len2624_2656])
theorem inBlock2656 (i : Nat) (h : i<32) : program[2656+i]?=instructions2656[i]? := slice2656_2688 i (by rwa [len2656_2688])
theorem inBlock2688 (i : Nat) (h : i<32) : program[2688+i]?=instructions2688[i]? := slice2688_2720 i (by rwa [len2688_2720])
theorem inBlock2720 (i : Nat) (h : i<32) : program[2720+i]?=instructions2720[i]? := slice2720_2752 i (by rwa [len2720_2752])
theorem inBlock2752 (i : Nat) (h : i<32) : program[2752+i]?=instructions2752[i]? := slice2752_2784 i (by rwa [len2752_2784])
theorem inBlock2784 (i : Nat) (h : i<32) : program[2784+i]?=instructions2784[i]? := slice2784_2816 i (by rwa [len2784_2816])
theorem inBlock2816 (i : Nat) (h : i<32) : program[2816+i]?=instructions2816[i]? := slice2816_2848 i (by rwa [len2816_2848])
theorem inBlock2848 (i : Nat) (h : i<32) : program[2848+i]?=instructions2848[i]? := slice2848_2880 i (by rwa [len2848_2880])
theorem inBlock2880 (i : Nat) (h : i<32) : program[2880+i]?=instructions2880[i]? := slice2880_2912 i (by rwa [len2880_2912])
theorem inBlock2912 (i : Nat) (h : i<32) : program[2912+i]?=instructions2912[i]? := slice2912_2944 i (by rwa [len2912_2944])
theorem inBlock2944 (i : Nat) (h : i<32) : program[2944+i]?=instructions2944[i]? := slice2944_2976 i (by rwa [len2944_2976])
theorem inBlock2976 (i : Nat) (h : i<32) : program[2976+i]?=instructions2976[i]? := slice2976_3008 i (by rwa [len2976_3008])
theorem inBlock3008 (i : Nat) (h : i<32) : program[3008+i]?=instructions3008[i]? := slice3008_3040 i (by rwa [len3008_3040])
theorem inBlock3040 (i : Nat) (h : i<32) : program[3040+i]?=instructions3040[i]? := slice3040_3072 i (by rwa [len3040_3072])
theorem inBlock3072 (i : Nat) (h : i<17) : program[3072+i]?=instructions3072[i]? := slice3072_3089 i (by rwa [len3072_3089])

end PA192.ModelSearch.RegisterSource
