module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site2135Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2135 f r x y z) (slots617.atReg 2145 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2135 10 2145 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2135 2139 2136 f r row2135)
    (slots617.pos_y 2135 2139 2136 f r row2135)
    (slots617.inc_z 2136 2137 f r row2136 (Or.inl (by decide)))
    (slots617.inc_x 2137 2138 f r row2137 (Or.inl (by decide)))
    (slots617.jump 2138 2135 f r row2138)
    (slots617.zero_x 2139 2145 2140 f r row2139)
    (slots617.pos_x 2139 2145 2140 f r row2139)
    (slots617.inc_z 2140 2141 f r row2140 (Or.inl (by decide)))
    (slots617.zero_x 2141 2144 2142 f r row2141)
    (slots617.pos_x 2141 2144 2142 f r row2141)
    (slots617.inc_y 2142 2143 f r row2142 (Or.inl (by decide)))
    (slots617.jump 2143 2141 f r row2143)
    (slots617.jump 2144 2135 f r row2144)

theorem site2135 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2135:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2145:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2135Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2145Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2145 f r x y z) (slots710.atReg 2149 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2145 4 2149 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2145 2149 2146 f r row2145)
    (slots710.pos_x 2145 2149 2146 f r row2145)
    (slots710.inc_y 2146 2147 f r row2146 (Or.inl (by decide)))
    (slots710.inc_y 2147 2148 f r row2147 (Or.inl (by decide)))
    (slots710.jump 2148 2145 f r row2148)

theorem site2145 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2145:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2149:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2145Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2149 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2149:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2150:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2149 _ row2149]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2150Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2150 f r x y z) (slots267.atReg 2158 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2150 8 2158 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2150 2158 2151 f r row2150)
    (slots267.pos_x 2150 2158 2151 f r row2150)
    (slots267.inc_z 2151 2152 f r row2151 (Or.inl (by decide)))
    (slots267.zero_y 2152 2154 2153 f r row2152)
    (slots267.pos_y 2152 2154 2153 f r row2152)
    (slots267.jump 2153 2157 f r row2153)
    (slots267.zero_z 2154 2157 2155 f r row2154)
    (slots267.pos_z 2154 2157 2155 f r row2154)
    (slots267.inc_y 2155 2156 f r row2155 (Or.inl (by decide)))
    (slots267.jump 2156 2154 f r row2156)
    (slots267.jump 2157 2150 f r row2157)

theorem site2150 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2150:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2158:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2150Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2158Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2158 f r x y z) (slots720.atReg 2161 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2158 3 2161 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2158 2161 2159 f r row2158)
    (slots720.pos_x 2158 2161 2159 f r row2158)
    (slots720.inc_y 2159 2160 f r row2159 (Or.inl (by decide)))
    (slots720.jump 2160 2158 f r row2160)

theorem site2158 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2158:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2161:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2158Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2161Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2161 f r x y z) (slots617.atReg 2171 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2161 10 2171 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2161 2165 2162 f r row2161)
    (slots617.pos_y 2161 2165 2162 f r row2161)
    (slots617.inc_z 2162 2163 f r row2162 (Or.inl (by decide)))
    (slots617.inc_x 2163 2164 f r row2163 (Or.inl (by decide)))
    (slots617.jump 2164 2161 f r row2164)
    (slots617.zero_x 2165 2171 2166 f r row2165)
    (slots617.pos_x 2165 2171 2166 f r row2165)
    (slots617.inc_z 2166 2167 f r row2166 (Or.inl (by decide)))
    (slots617.zero_x 2167 2170 2168 f r row2167)
    (slots617.pos_x 2167 2170 2168 f r row2167)
    (slots617.inc_y 2168 2169 f r row2168 (Or.inl (by decide)))
    (slots617.jump 2169 2167 f r row2169)
    (slots617.jump 2170 2161 f r row2170)

theorem site2161 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2161:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2171:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2161Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2171Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2171 f r x y z) (slots710.atReg 2175 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2171 4 2175 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2171 2175 2172 f r row2171)
    (slots710.pos_x 2171 2175 2172 f r row2171)
    (slots710.inc_y 2172 2173 f r row2172 (Or.inl (by decide)))
    (slots710.inc_y 2173 2174 f r row2173 (Or.inl (by decide)))
    (slots710.jump 2174 2171 f r row2174)

theorem site2171 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2171:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2175:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2171Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site2175Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2175 f r x y z) (slots267.atReg 2183 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2175 8 2183 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2175 2183 2176 f r row2175)
    (slots267.pos_x 2175 2183 2176 f r row2175)
    (slots267.inc_z 2176 2177 f r row2176 (Or.inl (by decide)))
    (slots267.zero_y 2177 2179 2178 f r row2177)
    (slots267.pos_y 2177 2179 2178 f r row2177)
    (slots267.jump 2178 2182 f r row2178)
    (slots267.zero_z 2179 2182 2180 f r row2179)
    (slots267.pos_z 2179 2182 2180 f r row2179)
    (slots267.inc_y 2180 2181 f r row2180 (Or.inl (by decide)))
    (slots267.jump 2181 2179 f r row2181)
    (slots267.jump 2182 2175 f r row2182)

theorem site2175 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2175:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2183:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2175Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2183Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2183 f r x y z) (slots720.atReg 2186 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2183 3 2186 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2183 2186 2184 f r row2183)
    (slots720.pos_x 2183 2186 2184 f r row2183)
    (slots720.inc_y 2184 2185 f r row2184 (Or.inl (by decide)))
    (slots720.jump 2185 2183 f r row2185)

theorem site2183 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2183:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2186:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2183Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2186Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2186 f r x y z) (slots617.atReg 2196 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2186 10 2196 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2186 2190 2187 f r row2186)
    (slots617.pos_y 2186 2190 2187 f r row2186)
    (slots617.inc_z 2187 2188 f r row2187 (Or.inl (by decide)))
    (slots617.inc_x 2188 2189 f r row2188 (Or.inl (by decide)))
    (slots617.jump 2189 2186 f r row2189)
    (slots617.zero_x 2190 2196 2191 f r row2190)
    (slots617.pos_x 2190 2196 2191 f r row2190)
    (slots617.inc_z 2191 2192 f r row2191 (Or.inl (by decide)))
    (slots617.zero_x 2192 2195 2193 f r row2192)
    (slots617.pos_x 2192 2195 2193 f r row2192)
    (slots617.inc_y 2193 2194 f r row2193 (Or.inl (by decide)))
    (slots617.jump 2194 2192 f r row2194)
    (slots617.jump 2195 2186 f r row2195)

theorem site2186 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2186:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2196:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2186Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2196Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2196 f r x y z) (slots710.atReg 2200 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2196 4 2200 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2196 2200 2197 f r row2196)
    (slots710.pos_x 2196 2200 2197 f r row2196)
    (slots710.inc_y 2197 2198 f r row2197 (Or.inl (by decide)))
    (slots710.inc_y 2198 2199 f r row2198 (Or.inl (by decide)))
    (slots710.jump 2199 2196 f r row2199)

theorem site2196 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2196:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2200:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2196Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site2200Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2200 f r x y z) (slots160.atReg 2203 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2200 3 2203 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2200 2203 2201 f r row2200)
    (slots160.pos_x 2200 2203 2201 f r row2200)
    (slots160.inc_y 2201 2202 f r row2201 (Or.inl (by decide)))
    (slots160.jump 2202 2200 f r row2202)

theorem site2200 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2200:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2203:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2200Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2203Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2203 f r x y z) (slots210.atReg 2206 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2203 3 2206 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2203 2206 2204 f r row2203)
    (slots210.pos_x 2203 2206 2204 f r row2203)
    (slots210.inc_y 2204 2205 f r row2204 (Or.inl (by decide)))
    (slots210.jump 2205 2203 f r row2205)

theorem site2203 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2203:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2206:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2203Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2206Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2206 f r x y z) (slots617.atReg 2216 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2206 10 2216 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2206 2210 2207 f r row2206)
    (slots617.pos_y 2206 2210 2207 f r row2206)
    (slots617.inc_z 2207 2208 f r row2207 (Or.inl (by decide)))
    (slots617.inc_x 2208 2209 f r row2208 (Or.inl (by decide)))
    (slots617.jump 2209 2206 f r row2209)
    (slots617.zero_x 2210 2216 2211 f r row2210)
    (slots617.pos_x 2210 2216 2211 f r row2210)
    (slots617.inc_z 2211 2212 f r row2211 (Or.inl (by decide)))
    (slots617.zero_x 2212 2215 2213 f r row2212)
    (slots617.pos_x 2212 2215 2213 f r row2212)
    (slots617.inc_y 2213 2214 f r row2213 (Or.inl (by decide)))
    (slots617.jump 2214 2212 f r row2214)
    (slots617.jump 2215 2206 f r row2215)

theorem site2206 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2206:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2216:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2206Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2216Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2216 f r x y z) (slots720.atReg 2219 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2216 3 2219 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2216 2219 2217 f r row2216)
    (slots720.pos_x 2216 2219 2217 f r row2216)
    (slots720.inc_y 2217 2218 f r row2217 (Or.inl (by decide)))
    (slots720.jump 2218 2216 f r row2218)

theorem site2216 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2216:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2219:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2216Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2219Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2219 f r x y z) (slots461.atReg 2223 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2219 4 2223 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2219 2223 2220 f r row2219)
    (slots461.pos_x 2219 2223 2220 f r row2219)
    (slots461.inc_y 2220 2221 f r row2220 (Or.inl (by decide)))
    (slots461.inc_z 2221 2222 f r row2221 (Or.inl (by decide)))
    (slots461.jump 2222 2219 f r row2222)

theorem site2219 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2219:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2223:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2219Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site2223Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2223 f r x y z) (slots640.atReg 2226 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2223 3 2226 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2223 2226 2224 f r row2223)
    (slots640.pos_x 2223 2226 2224 f r row2223)
    (slots640.inc_y 2224 2225 f r row2224 (Or.inl (by decide)))
    (slots640.jump 2225 2223 f r row2225)

theorem site2223 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2223:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2226:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2223Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site2226Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2226 f r x y z) (slots160.atReg 2229 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2226 3 2229 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2226 2229 2227 f r row2226)
    (slots160.pos_x 2226 2229 2227 f r row2226)
    (slots160.inc_y 2227 2228 f r row2227 (Or.inl (by decide)))
    (slots160.jump 2228 2226 f r row2228)

theorem site2226 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2226:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2229:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2226Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2229Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2229 f r x y z) (slots210.atReg 2232 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2229 3 2232 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2229 2232 2230 f r row2229)
    (slots210.pos_x 2229 2232 2230 f r row2229)
    (slots210.inc_y 2230 2231 f r row2230 (Or.inl (by decide)))
    (slots210.jump 2231 2229 f r row2231)

theorem site2229 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2229:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2232:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2229Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2232Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2232 f r x y z) (slots617.atReg 2242 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2232 10 2242 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2232 2236 2233 f r row2232)
    (slots617.pos_y 2232 2236 2233 f r row2232)
    (slots617.inc_z 2233 2234 f r row2233 (Or.inl (by decide)))
    (slots617.inc_x 2234 2235 f r row2234 (Or.inl (by decide)))
    (slots617.jump 2235 2232 f r row2235)
    (slots617.zero_x 2236 2242 2237 f r row2236)
    (slots617.pos_x 2236 2242 2237 f r row2236)
    (slots617.inc_z 2237 2238 f r row2237 (Or.inl (by decide)))
    (slots617.zero_x 2238 2241 2239 f r row2238)
    (slots617.pos_x 2238 2241 2239 f r row2238)
    (slots617.inc_y 2239 2240 f r row2239 (Or.inl (by decide)))
    (slots617.jump 2240 2238 f r row2240)
    (slots617.jump 2241 2232 f r row2241)

theorem site2232 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2232:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2242:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2232Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2242Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2242 f r x y z) (slots720.atReg 2245 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2242 3 2245 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2242 2245 2243 f r row2242)
    (slots720.pos_x 2242 2245 2243 f r row2242)
    (slots720.inc_y 2243 2244 f r row2243 (Or.inl (by decide)))
    (slots720.jump 2244 2242 f r row2244)

theorem site2242 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2242:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2245:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2242Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2245Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2245 f r x y z) (slots561.atReg 2249 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2245 4 2249 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2245 2249 2246 f r row2245)
    (slots561.pos_x 2245 2249 2246 f r row2245)
    (slots561.inc_y 2246 2247 f r row2246 (Or.inl (by decide)))
    (slots561.inc_z 2247 2248 f r row2247 (Or.inl (by decide)))
    (slots561.jump 2248 2245 f r row2248)

theorem site2245 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2245:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2249:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2245Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site2249Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2249 f r x y z) (slots650.atReg 2252 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2249 3 2252 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2249 2252 2250 f r row2249)
    (slots650.pos_x 2249 2252 2250 f r row2249)
    (slots650.inc_y 2250 2251 f r row2250 (Or.inl (by decide)))
    (slots650.jump 2251 2249 f r row2251)

theorem site2249 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2249:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2252:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2249Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site2252Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2252 f r x y z) (slots267.atReg 2260 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2252 8 2260 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2252 2260 2253 f r row2252)
    (slots267.pos_x 2252 2260 2253 f r row2252)
    (slots267.inc_z 2253 2254 f r row2253 (Or.inl (by decide)))
    (slots267.zero_y 2254 2256 2255 f r row2254)
    (slots267.pos_y 2254 2256 2255 f r row2254)
    (slots267.jump 2255 2259 f r row2255)
    (slots267.zero_z 2256 2259 2257 f r row2256)
    (slots267.pos_z 2256 2259 2257 f r row2256)
    (slots267.inc_y 2257 2258 f r row2257 (Or.inl (by decide)))
    (slots267.jump 2258 2256 f r row2258)
    (slots267.jump 2259 2252 f r row2259)

theorem site2252 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2252:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2260:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2252Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2260Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2260 f r x y z) (slots720.atReg 2263 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2260 3 2263 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2260 2263 2261 f r row2260)
    (slots720.pos_x 2260 2263 2261 f r row2260)
    (slots720.inc_y 2261 2262 f r row2261 (Or.inl (by decide)))
    (slots720.jump 2262 2260 f r row2262)

theorem site2260 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2260:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2263:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2260Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2263Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2263 f r x y z) (slots617.atReg 2273 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2263 10 2273 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2263 2267 2264 f r row2263)
    (slots617.pos_y 2263 2267 2264 f r row2263)
    (slots617.inc_z 2264 2265 f r row2264 (Or.inl (by decide)))
    (slots617.inc_x 2265 2266 f r row2265 (Or.inl (by decide)))
    (slots617.jump 2266 2263 f r row2266)
    (slots617.zero_x 2267 2273 2268 f r row2267)
    (slots617.pos_x 2267 2273 2268 f r row2267)
    (slots617.inc_z 2268 2269 f r row2268 (Or.inl (by decide)))
    (slots617.zero_x 2269 2272 2270 f r row2269)
    (slots617.pos_x 2269 2272 2270 f r row2269)
    (slots617.inc_y 2270 2271 f r row2270 (Or.inl (by decide)))
    (slots617.jump 2271 2269 f r row2271)
    (slots617.jump 2272 2263 f r row2272)

theorem site2263 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2263:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2273:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2263Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2273Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2273 f r x y z) (slots710.atReg 2277 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2273 4 2277 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2273 2277 2274 f r row2273)
    (slots710.pos_x 2273 2277 2274 f r row2273)
    (slots710.inc_y 2274 2275 f r row2274 (Or.inl (by decide)))
    (slots710.inc_y 2275 2276 f r row2275 (Or.inl (by decide)))
    (slots710.jump 2276 2273 f r row2276)

theorem site2273 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2273:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2277:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2273Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2277 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2277:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2278:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2277 _ row2277]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2278Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2278 f r x y z) (slots160.atReg 2281 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2278 3 2281 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2278 2281 2279 f r row2278)
    (slots160.pos_x 2278 2281 2279 f r row2278)
    (slots160.inc_y 2279 2280 f r row2279 (Or.inl (by decide)))
    (slots160.jump 2280 2278 f r row2280)

theorem site2278 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2278:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2281:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2278Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2281Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2281 f r x y z) (slots210.atReg 2284 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2281 3 2284 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2281 2284 2282 f r row2281)
    (slots210.pos_x 2281 2284 2282 f r row2281)
    (slots210.inc_y 2282 2283 f r row2282 (Or.inl (by decide)))
    (slots210.jump 2283 2281 f r row2283)

theorem site2281 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2281:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2284:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2281Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2284Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2284 f r x y z) (slots617.atReg 2294 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2284 10 2294 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2284 2288 2285 f r row2284)
    (slots617.pos_y 2284 2288 2285 f r row2284)
    (slots617.inc_z 2285 2286 f r row2285 (Or.inl (by decide)))
    (slots617.inc_x 2286 2287 f r row2286 (Or.inl (by decide)))
    (slots617.jump 2287 2284 f r row2287)
    (slots617.zero_x 2288 2294 2289 f r row2288)
    (slots617.pos_x 2288 2294 2289 f r row2288)
    (slots617.inc_z 2289 2290 f r row2289 (Or.inl (by decide)))
    (slots617.zero_x 2290 2293 2291 f r row2290)
    (slots617.pos_x 2290 2293 2291 f r row2290)
    (slots617.inc_y 2291 2292 f r row2291 (Or.inl (by decide)))
    (slots617.jump 2292 2290 f r row2292)
    (slots617.jump 2293 2284 f r row2293)

theorem site2284 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2284:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2294:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2284Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2294Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2294 f r x y z) (slots720.atReg 2297 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2294 3 2297 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2294 2297 2295 f r row2294)
    (slots720.pos_x 2294 2297 2295 f r row2294)
    (slots720.inc_y 2295 2296 f r row2295 (Or.inl (by decide)))
    (slots720.jump 2296 2294 f r row2296)

theorem site2294 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2294:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2297:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2294Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2297Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2297 f r x y z) (slots561.atReg 2301 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2297 4 2301 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2297 2301 2298 f r row2297)
    (slots561.pos_x 2297 2301 2298 f r row2297)
    (slots561.inc_y 2298 2299 f r row2298 (Or.inl (by decide)))
    (slots561.inc_z 2299 2300 f r row2299 (Or.inl (by decide)))
    (slots561.jump 2300 2297 f r row2300)

theorem site2297 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2297:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2301:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2297Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site2301Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2301 f r x y z) (slots650.atReg 2304 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2301 3 2304 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2301 2304 2302 f r row2301)
    (slots650.pos_x 2301 2304 2302 f r row2301)
    (slots650.inc_y 2302 2303 f r row2302 (Or.inl (by decide)))
    (slots650.jump 2303 2301 f r row2303)

theorem site2301 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2301:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2304:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2301Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site2304Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2304 f r x y z) (slots267.atReg 2312 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2304 8 2312 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2304 2312 2305 f r row2304)
    (slots267.pos_x 2304 2312 2305 f r row2304)
    (slots267.inc_z 2305 2306 f r row2305 (Or.inl (by decide)))
    (slots267.zero_y 2306 2308 2307 f r row2306)
    (slots267.pos_y 2306 2308 2307 f r row2306)
    (slots267.jump 2307 2311 f r row2307)
    (slots267.zero_z 2308 2311 2309 f r row2308)
    (slots267.pos_z 2308 2311 2309 f r row2308)
    (slots267.inc_y 2309 2310 f r row2309 (Or.inl (by decide)))
    (slots267.jump 2310 2308 f r row2310)
    (slots267.jump 2311 2304 f r row2311)

theorem site2304 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2304:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2312:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2304Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2312Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2312 f r x y z) (slots720.atReg 2315 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2312 3 2315 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2312 2315 2313 f r row2312)
    (slots720.pos_x 2312 2315 2313 f r row2312)
    (slots720.inc_y 2313 2314 f r row2313 (Or.inl (by decide)))
    (slots720.jump 2314 2312 f r row2314)

theorem site2312 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2312:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2315:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2312Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2315Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2315 f r x y z) (slots617.atReg 2325 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2315 10 2325 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2315 2319 2316 f r row2315)
    (slots617.pos_y 2315 2319 2316 f r row2315)
    (slots617.inc_z 2316 2317 f r row2316 (Or.inl (by decide)))
    (slots617.inc_x 2317 2318 f r row2317 (Or.inl (by decide)))
    (slots617.jump 2318 2315 f r row2318)
    (slots617.zero_x 2319 2325 2320 f r row2319)
    (slots617.pos_x 2319 2325 2320 f r row2319)
    (slots617.inc_z 2320 2321 f r row2320 (Or.inl (by decide)))
    (slots617.zero_x 2321 2324 2322 f r row2321)
    (slots617.pos_x 2321 2324 2322 f r row2321)
    (slots617.inc_y 2322 2323 f r row2322 (Or.inl (by decide)))
    (slots617.jump 2323 2321 f r row2323)
    (slots617.jump 2324 2315 f r row2324)

theorem site2315 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2315:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2325:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2315Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2325Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2325 f r x y z) (slots710.atReg 2329 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2325 4 2329 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2325 2329 2326 f r row2325)
    (slots710.pos_x 2325 2329 2326 f r row2325)
    (slots710.inc_y 2326 2327 f r row2326 (Or.inl (by decide)))
    (slots710.inc_y 2327 2328 f r row2327 (Or.inl (by decide)))
    (slots710.jump 2328 2325 f r row2328)

theorem site2325 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2325:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2329:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2325Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2329 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2329:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2330:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2329 _ row2329]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2330Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2330 f r x y z) (slots160.atReg 2333 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2330 3 2333 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2330 2333 2331 f r row2330)
    (slots160.pos_x 2330 2333 2331 f r row2330)
    (slots160.inc_y 2331 2332 f r row2331 (Or.inl (by decide)))
    (slots160.jump 2332 2330 f r row2332)

theorem site2330 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2330:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2333:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2330Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2333Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2333 f r x y z) (slots210.atReg 2336 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2333 3 2336 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2333 2336 2334 f r row2333)
    (slots210.pos_x 2333 2336 2334 f r row2333)
    (slots210.inc_y 2334 2335 f r row2334 (Or.inl (by decide)))
    (slots210.jump 2335 2333 f r row2335)

theorem site2333 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2333:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2336:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2333Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

end PA192.ModelSearch.RegisterSource.Certified
