module
public import ModelScannerRegister
public import ModelSeed19
public import ModelCmdRefillCold00
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch.RegisterFields PA192.ModelSearch.RegisterCommands PA192.ModelSearch.RegisterSource
open PA192.ModelSearch.RegisterSource.Certified PA192.ModelSearch.RegisterSource.Commands PA192.ModelSearch.Scanner
set_option maxRecDepth 8000
set_option maxHeartbeats 3500000
namespace PA192.ModelSearch.ScannerSource

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private noncomputable def seed (pc : Nat) (shadow : V) := config (pc:V) 1 (vector 0 0 0 2 0 0 0 shadow 0)

private theorem five : Reach (coldMargin : V) (seed 96 3) := by
  have q91 : step (seed 91 (2:V))=seed 92 3 := by
    unfold seed; rw [step_at 91 _ row0091]
    simp [perform,readReg,writeReg,vector,show (2:V)+1=3 by ring]
  have q92 : step (seed 92 (3:V))=seed 95 3 := by
    unfold seed; rw [step_at 92 _ row0092]; simp [perform,readReg,writeReg,vector,chooseZero]
  have q95 : step (seed 95 (3:V))=seed 86 3 := by
    unfold seed; rw [step_at 95 _ row0095]; rfl
  have q86 : step (seed 86 (3:V))=seed 90 3 := by
    unfold seed; rw [step_at 86 _ row0086]; simp [perform,readReg,writeReg,vector,chooseZero]
  have q90 : step (seed 90 (3:V))=seed 96 3 := by
    unfold seed; rw [step_at 90 _ row0090]; simp [perform,readReg,writeReg,vector,chooseZero]
  have s := (((((Reach.once q91).trans (Reach.once q92)).trans (Reach.once q95)).trans (Reach.once q86)).trans (Reach.once q90))
  simpa [coldMargin,seed] using s

private theorem triangle_two : triangle (2:V)=3 := by
  rw [show (2:V)=(0+1)+1 by ring,triangle_succ,triangle_succ,triangle_zero]
  ring

private theorem firstBatch : ∃ t s : V, Reach (coldMargin:V) (atS 2968 1 0 t s 2 0 0 0) := by
  let top := atom97 (V:=V) 0 0 0 2 0 0 0 0 0
  let stack := atom86 (V:=V) 0 0 0 2 0 0 0 0 0
  refine ⟨top+top,stack,five.trans ?_⟩
  have h := seedEmit (1:V) 0 0 0 2 0 0 0 0 0
  simpa only [seed,atS,top,stack,atom3,atom2,atom0,cantor,zero_add,add_zero,triangle_zero,triangle_two] using h

private theorem unread_empty : ∀ j : V, unread j 0=0 := by
  apply modelInduct
  · definability
  · simp [unread]
  · intro j ih
    change iterate consumePair j 0=0 at ih
    change iterate consumePair (j+1) 0=0
    rw [iterate_succ,ih]
    simp [consumePair,right]

private theorem coldRefill (e : V) : Reach (vm 0 1 0 e 0) (vm 10 0 0 e 0) :=
  (site0000Zero 1 0 (top e) (stack e) 0 (param e) (cache e) 0 0 0).trans
    (commandRefillCold 0 (top e) (stack e) 0 (param e) (cache e) 0 0 0)

/-- The signed source margin used by the physical 33,911-step boot starts the
real warm scanner, with candidate zero and exactly zero unread fields. -/
theorem signed_entry : ∃ e : V, Reach (coldMargin:V) (view (fresh 0 0 e)) := by
  obtain ⟨t,s,first⟩ := firstBatch (V:=V)
  let body := cantor t s
  let b : V := iterate nextBatch 2 (batch 2 body 0)
  let e := popAfterAX (batchBody b)
  have ret := site2968 (1:V) 0 t s 2 0 0 0 0 0
  have run := batchesRun (1:V) 0 2 body 0
  have tail0 : batchFields b=0 := (ax_ends 2 body 0).trans (unread_empty 2)
  have later : Reach (atS 39 1 0 t s 2 0 0 0) (vm 0 1 0 e 0) := by
    have hr : Reach (atS 39 1 0 t s 2 0 0 0) (vm 0 1 0 e (batchFields b)) := by
      simpa only [batchView_batch,body,left_cantor,right_cantor,e,b] using run
    rwa [tail0] at hr
  refine ⟨e,?_⟩
  rw [view_fresh]
  exact ((first.trans ret).trans later).trans (coldRefill e)

/-- No source hypotheses remain. A numerical contradiction in any PA model
forces the authentic signed 3,089-address program to reach its literal halt. -/
theorem proof_halts_cold_margin {n : V} (refutation : evalCode n=3) : sourceHalts (coldMargin : V) := by
  obtain ⟨e,startup⟩ := signed_entry (V:=V)
  exact halts_of_entry 0 e coldMargin startup refutation

end PA192.ModelSearch.ScannerSource
#print axioms PA192.ModelSearch.ScannerSource.signed_entry
#print axioms PA192.ModelSearch.ScannerSource.proof_halts_cold_margin
