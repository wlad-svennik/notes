module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem site0000Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((0:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 0)) (config ((2:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 0)) := by
  apply Reach.once
  rw [step_at 0 _ row0000]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site0000Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((0:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 (r8+1))) (config ((1:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 0 _ row0000]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site0001 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((10:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1 _ row0001]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site0002 (r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2:Nat):V) 0 (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3:Nat):V) 0 (vector (r0+1) r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2 _ row0002]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site0002Cold (r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2:Nat):V) 1 (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3:Nat):V) 0 (vector 0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2 _ row0002]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0003Frame (r : V) : ∀ x y z : V, Reach (slots086.atReg 3 0 r x y z) (slots086.atReg 7 0 r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots086.atReg (destination 3 4 7 4095 j) 0 r) (fun _=>Slots.frameDef ..)
    (slots086.zero_x 3 7 4 0 r row0003)
    (slots086.pos_x 3 7 4 0 r row0003)
    (slots086.inc_y 4 5 0 r row0004 (Or.inl (by decide)))
    (slots086.inc_z 5 6 0 r row0005 (Or.inl (by decide)))
    (slots086.jump 6 3 0 r row0006)

theorem site0003 (r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3:Nat):V) 0 (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((7:Nat):V) 0 (vector 0 r1 r2 r3 r4 r5 (r6+r0) r7 (r8+r0))) := by
  simpa only [Slots.atReg,Slots.fill,slots086,vector,writeReg,pi₁_pair,pi₂_pair] using site0003Frame (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r0 r8 r6

private theorem site0007Frame (r : V) : ∀ x y z : V, Reach (slots601.atReg 7 0 r x y z) (slots601.atReg 10 0 r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots601.atReg (destination 7 3 10 4095 j) 0 r) (fun _=>Slots.frameDef ..)
    (slots601.zero_x 7 10 8 0 r row0007)
    (slots601.pos_x 7 10 8 0 r row0007)
    (slots601.inc_y 8 9 0 r row0008 (Or.inr rfl))
    (slots601.jump 9 7 0 r row0009)

theorem site0007 (r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((7:Nat):V) 0 (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((10:Nat):V) 0 (vector (r0+r6) r1 r2 r3 r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots601,vector,writeReg,pi₁_pair,pi₂_pair] using site0007Frame (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r0 r1

private theorem site0010Frame (f r : V) : ∀ x y z : V, Reach (slots867.atReg 10 f r x y z) (slots867.atReg 18 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots867.atReg (destination 10 8 18 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots867.zero_x 10 18 11 f r row0010)
    (slots867.pos_x 10 18 11 f r row0010)
    (slots867.inc_z 11 12 f r row0011 (Or.inl (by decide)))
    (slots867.zero_y 12 14 13 f r row0012)
    (slots867.pos_y 12 14 13 f r row0012)
    (slots867.jump 13 17 f r row0013)
    (slots867.zero_z 14 17 15 f r row0014)
    (slots867.pos_z 14 17 15 f r row0014)
    (slots867.inc_y 15 16 f r row0015 (Or.inl (by decide)))
    (slots867.jump 16 14 f r row0016)
    (slots867.jump 17 10 f r row0017)

theorem site0010 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((10:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((18:Nat):V) f (vector r0 r1 r2 r3 r4 r5 (left (cantor r6 r7+r8)) (right (cantor r6 r7+r8)) 0)) := by
  simpa only [Slots.atReg,Slots.fill,slots867,vector,writeReg,pi₁_pair,pi₂_pair] using site0010Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r8 r6 r7

private theorem site0018Frame (f r : V) : ∀ x y z : V, Reach (slots780.atReg 18 f r x y z) (slots780.atReg 21 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots780.atReg (destination 18 3 21 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots780.zero_x 18 21 19 f r row0018)
    (slots780.pos_x 18 21 19 f r row0018)
    (slots780.inc_y 19 20 f r row0019 (Or.inl (by decide)))
    (slots780.jump 20 18 f r row0020)

theorem site0018 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((18:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((21:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 0 (r8+r7))) := by
  simpa only [Slots.atReg,Slots.fill,slots780,vector,writeReg,pi₁_pair,pi₂_pair] using site0018Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r8 r0

private theorem site0021Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 21 f r x y z) (slots630.atReg 24 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 21 3 24 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 21 24 22 f r row0021)
    (slots630.pos_x 21 24 22 f r row0021)
    (slots630.inc_y 22 23 f r row0022 (Or.inl (by decide)))
    (slots630.jump 23 21 f r row0023)

theorem site0021 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((21:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((24:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0021Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site0024Frame (f r : V) : ∀ x y z : V, Reach (slots867.atReg 24 f r x y z) (slots867.atReg 32 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots867.atReg (destination 24 8 32 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots867.zero_x 24 32 25 f r row0024)
    (slots867.pos_x 24 32 25 f r row0024)
    (slots867.inc_z 25 26 f r row0025 (Or.inl (by decide)))
    (slots867.zero_y 26 28 27 f r row0026)
    (slots867.pos_y 26 28 27 f r row0026)
    (slots867.jump 27 31 f r row0027)
    (slots867.zero_z 28 31 29 f r row0028)
    (slots867.pos_z 28 31 29 f r row0028)
    (slots867.inc_y 29 30 f r row0029 (Or.inl (by decide)))
    (slots867.jump 30 28 f r row0030)
    (slots867.jump 31 24 f r row0031)

theorem site0024 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((24:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((32:Nat):V) f (vector r0 r1 r2 r3 r4 r5 (left (cantor r6 r7+r8)) (right (cantor r6 r7+r8)) 0)) := by
  simpa only [Slots.atReg,Slots.fill,slots867,vector,writeReg,pi₁_pair,pi₂_pair] using site0024Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r8 r6 r7

private theorem site0032Frame (f r : V) : ∀ x y z : V, Reach (slots780.atReg 32 f r x y z) (slots780.atReg 35 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots780.atReg (destination 32 3 35 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots780.zero_x 32 35 33 f r row0032)
    (slots780.pos_x 32 35 33 f r row0032)
    (slots780.inc_y 33 34 f r row0033 (Or.inl (by decide)))
    (slots780.jump 34 32 f r row0034)

theorem site0032 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((32:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((35:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 0 (r8+r7))) := by
  simpa only [Slots.atReg,Slots.fill,slots780,vector,writeReg,pi₁_pair,pi₂_pair] using site0032Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r8 r0

private theorem site0035Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 35 f r x y z) (slots640.atReg 38 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 35 3 38 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 35 38 36 f r row0035)
    (slots640.pos_x 35 38 36 f r row0035)
    (slots640.inc_y 36 37 f r row0036 (Or.inl (by decide)))
    (slots640.jump 37 35 f r row0037)

theorem site0035 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((35:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((38:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0035Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

theorem site0038Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((38:Nat):V) f (vector r0 r1 r2 0 r4 r5 r6 r7 r8)) (config ((3017:Nat):V) f (vector r0 r1 r2 0 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 38 _ row0038]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site0038Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((38:Nat):V) f (vector r0 r1 r2 (r3+1) r4 r5 r6 r7 r8)) (config ((39:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 38 _ row0038]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site0039Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((39:Nat):V) f (vector r0 r1 r2 0 r4 r5 r6 r7 r8)) (config ((2969:Nat):V) f (vector r0 r1 r2 0 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 39 _ row0039]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site0039Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((39:Nat):V) f (vector r0 r1 r2 (r3+1) r4 r5 r6 r7 r8)) (config ((40:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 39 _ row0039]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0040Frame (f r : V) : ∀ x y z : V, Reach (slots867.atReg 40 f r x y z) (slots867.atReg 48 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots867.atReg (destination 40 8 48 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots867.zero_x 40 48 41 f r row0040)
    (slots867.pos_x 40 48 41 f r row0040)
    (slots867.inc_z 41 42 f r row0041 (Or.inl (by decide)))
    (slots867.zero_y 42 44 43 f r row0042)
    (slots867.pos_y 42 44 43 f r row0042)
    (slots867.jump 43 47 f r row0043)
    (slots867.zero_z 44 47 45 f r row0044)
    (slots867.pos_z 44 47 45 f r row0044)
    (slots867.inc_y 45 46 f r row0045 (Or.inl (by decide)))
    (slots867.jump 46 44 f r row0046)
    (slots867.jump 47 40 f r row0047)

theorem site0040 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((40:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((48:Nat):V) f (vector r0 r1 r2 r3 r4 r5 (left (cantor r6 r7+r8)) (right (cantor r6 r7+r8)) 0)) := by
  simpa only [Slots.atReg,Slots.fill,slots867,vector,writeReg,pi₁_pair,pi₂_pair] using site0040Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r8 r6 r7

private theorem site0048Frame (f r : V) : ∀ x y z : V, Reach (slots780.atReg 48 f r x y z) (slots780.atReg 51 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots780.atReg (destination 48 3 51 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots780.zero_x 48 51 49 f r row0048)
    (slots780.pos_x 48 51 49 f r row0048)
    (slots780.inc_y 49 50 f r row0049 (Or.inl (by decide)))
    (slots780.jump 50 48 f r row0050)

theorem site0048 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((48:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((51:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 0 (r8+r7))) := by
  simpa only [Slots.atReg,Slots.fill,slots780,vector,writeReg,pi₁_pair,pi₂_pair] using site0048Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r8 r0

private theorem site0051Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 51 f r x y z) (slots650.atReg 54 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 51 3 54 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 51 54 52 f r row0051)
    (slots650.pos_x 51 54 52 f r row0051)
    (slots650.inc_y 52 53 f r row0052 (Or.inl (by decide)))
    (slots650.jump 53 51 f r row0053)

theorem site0051 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((51:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((54:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0051Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site0054Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 54 f r x y z) (slots160.atReg 57 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 54 3 57 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 54 57 55 f r row0054)
    (slots160.pos_x 54 57 55 f r row0054)
    (slots160.inc_y 55 56 f r row0055 (Or.inl (by decide)))
    (slots160.jump 56 54 f r row0056)

theorem site0054 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((54:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((57:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0054Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0057Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 57 f r x y z) (slots210.atReg 60 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 57 3 60 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 57 60 58 f r row0057)
    (slots210.pos_x 57 60 58 f r row0057)
    (slots210.inc_y 58 59 f r row0058 (Or.inl (by decide)))
    (slots210.jump 59 57 f r row0059)

theorem site0057 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((57:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((60:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0057Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0060Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 60 f r x y z) (slots617.atReg 70 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 60 10 70 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 60 64 61 f r row0060)
    (slots617.pos_y 60 64 61 f r row0060)
    (slots617.inc_z 61 62 f r row0061 (Or.inl (by decide)))
    (slots617.inc_x 62 63 f r row0062 (Or.inl (by decide)))
    (slots617.jump 63 60 f r row0063)
    (slots617.zero_x 64 70 65 f r row0064)
    (slots617.pos_x 64 70 65 f r row0064)
    (slots617.inc_z 65 66 f r row0065 (Or.inl (by decide)))
    (slots617.zero_x 66 69 67 f r row0066)
    (slots617.pos_x 66 69 67 f r row0066)
    (slots617.inc_y 67 68 f r row0067 (Or.inl (by decide)))
    (slots617.jump 68 66 f r row0068)
    (slots617.jump 69 60 f r row0069)

theorem site0060 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((60:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((70:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0060Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0070Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 70 f r x y z) (slots720.atReg 73 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 70 3 73 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 70 73 71 f r row0070)
    (slots720.pos_x 70 73 71 f r row0070)
    (slots720.inc_y 71 72 f r row0071 (Or.inl (by decide)))
    (slots720.jump 72 70 f r row0072)

theorem site0070 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((70:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((73:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0070Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0073Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 73 f r x y z) (slots361.atReg 77 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 73 4 77 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 73 77 74 f r row0073)
    (slots361.pos_x 73 77 74 f r row0073)
    (slots361.inc_y 74 75 f r row0074 (Or.inl (by decide)))
    (slots361.inc_z 75 76 f r row0075 (Or.inl (by decide)))
    (slots361.jump 76 73 f r row0076)

theorem site0073 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((73:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((77:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0073Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site0077Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 77 f r x y z) (slots630.atReg 80 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 77 3 80 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 77 80 78 f r row0077)
    (slots630.pos_x 77 80 78 f r row0077)
    (slots630.inc_y 78 79 f r row0078 (Or.inl (by decide)))
    (slots630.jump 79 77 f r row0079)

theorem site0077 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((77:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((80:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0077Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site0080Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 80 f r x y z) (slots160.atReg 83 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 80 3 83 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 80 83 81 f r row0080)
    (slots160.pos_x 80 83 81 f r row0080)
    (slots160.inc_y 81 82 f r row0081 (Or.inl (by decide)))
    (slots160.jump 82 80 f r row0082)

theorem site0080 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((80:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((83:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0080Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0083Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 83 f r x y z) (slots210.atReg 86 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 83 3 86 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 83 86 84 f r row0083)
    (slots210.pos_x 83 86 84 f r row0083)
    (slots210.inc_y 84 85 f r row0084 (Or.inl (by decide)))
    (slots210.jump 85 83 f r row0085)

theorem site0083 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((83:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((86:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0083Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0086Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 86 f r x y z) (slots617.atReg 96 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 86 10 96 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 86 90 87 f r row0086)
    (slots617.pos_y 86 90 87 f r row0086)
    (slots617.inc_z 87 88 f r row0087 (Or.inl (by decide)))
    (slots617.inc_x 88 89 f r row0088 (Or.inl (by decide)))
    (slots617.jump 89 86 f r row0089)
    (slots617.zero_x 90 96 91 f r row0090)
    (slots617.pos_x 90 96 91 f r row0090)
    (slots617.inc_z 91 92 f r row0091 (Or.inl (by decide)))
    (slots617.zero_x 92 95 93 f r row0092)
    (slots617.pos_x 92 95 93 f r row0092)
    (slots617.inc_y 93 94 f r row0093 (Or.inl (by decide)))
    (slots617.jump 94 92 f r row0094)
    (slots617.jump 95 86 f r row0095)

theorem site0086 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((86:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((96:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0086Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0096Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 96 f r x y z) (slots720.atReg 99 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 96 3 99 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 96 99 97 f r row0096)
    (slots720.pos_x 96 99 97 f r row0096)
    (slots720.inc_y 97 98 f r row0097 (Or.inl (by decide)))
    (slots720.jump 98 96 f r row0098)

theorem site0096 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((96:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((99:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0096Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0099Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 99 f r x y z) (slots461.atReg 103 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 99 4 103 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 99 103 100 f r row0099)
    (slots461.pos_x 99 103 100 f r row0099)
    (slots461.inc_y 100 101 f r row0100 (Or.inl (by decide)))
    (slots461.inc_z 101 102 f r row0101 (Or.inl (by decide)))
    (slots461.jump 102 99 f r row0102)

theorem site0099 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((99:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((103:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0099Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site0103Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 103 f r x y z) (slots640.atReg 106 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 103 3 106 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 103 106 104 f r row0103)
    (slots640.pos_x 103 106 104 f r row0103)
    (slots640.inc_y 104 105 f r row0104 (Or.inl (by decide)))
    (slots640.jump 105 103 f r row0105)

theorem site0103 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((103:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((106:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0103Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site0106Frame (f r : V) : ∀ x y z : V, Reach (slots867.atReg 106 f r x y z) (slots867.atReg 114 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots867.atReg (destination 106 8 114 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots867.zero_x 106 114 107 f r row0106)
    (slots867.pos_x 106 114 107 f r row0106)
    (slots867.inc_z 107 108 f r row0107 (Or.inl (by decide)))
    (slots867.zero_y 108 110 109 f r row0108)
    (slots867.pos_y 108 110 109 f r row0108)
    (slots867.jump 109 113 f r row0109)
    (slots867.zero_z 110 113 111 f r row0110)
    (slots867.pos_z 110 113 111 f r row0110)
    (slots867.inc_y 111 112 f r row0111 (Or.inl (by decide)))
    (slots867.jump 112 110 f r row0112)
    (slots867.jump 113 106 f r row0113)

theorem site0106 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((106:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((114:Nat):V) f (vector r0 r1 r2 r3 r4 r5 (left (cantor r6 r7+r8)) (right (cantor r6 r7+r8)) 0)) := by
  simpa only [Slots.atReg,Slots.fill,slots867,vector,writeReg,pi₁_pair,pi₂_pair] using site0106Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r8 r6 r7

private theorem site0114Frame (f r : V) : ∀ x y z : V, Reach (slots780.atReg 114 f r x y z) (slots780.atReg 117 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots780.atReg (destination 114 3 117 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots780.zero_x 114 117 115 f r row0114)
    (slots780.pos_x 114 117 115 f r row0114)
    (slots780.inc_y 115 116 f r row0115 (Or.inl (by decide)))
    (slots780.jump 116 114 f r row0116)

theorem site0114 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((114:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((117:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 0 (r8+r7))) := by
  simpa only [Slots.atReg,Slots.fill,slots780,vector,writeReg,pi₁_pair,pi₂_pair] using site0114Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r8 r0

private theorem site0117Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 117 f r x y z) (slots640.atReg 120 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 117 3 120 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 117 120 118 f r row0117)
    (slots640.pos_x 117 120 118 f r row0117)
    (slots640.inc_y 118 119 f r row0118 (Or.inl (by decide)))
    (slots640.jump 119 117 f r row0119)

theorem site0117 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((117:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((120:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0117Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site0120Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 120 f r x y z) (slots267.atReg 128 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 120 8 128 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 120 128 121 f r row0120)
    (slots267.pos_x 120 128 121 f r row0120)
    (slots267.inc_z 121 122 f r row0121 (Or.inl (by decide)))
    (slots267.zero_y 122 124 123 f r row0122)
    (slots267.pos_y 122 124 123 f r row0122)
    (slots267.jump 123 127 f r row0123)
    (slots267.zero_z 124 127 125 f r row0124)
    (slots267.pos_z 124 127 125 f r row0124)
    (slots267.inc_y 125 126 f r row0125 (Or.inl (by decide)))
    (slots267.jump 126 124 f r row0126)
    (slots267.jump 127 120 f r row0127)

theorem site0120 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((120:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((128:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0120Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0128Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 128 f r x y z) (slots720.atReg 131 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 128 3 131 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 128 131 129 f r row0128)
    (slots720.pos_x 128 131 129 f r row0128)
    (slots720.inc_y 129 130 f r row0129 (Or.inl (by decide)))
    (slots720.jump 130 128 f r row0130)

theorem site0128 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((128:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((131:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0128Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0131Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 131 f r x y z) (slots617.atReg 141 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 131 10 141 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 131 135 132 f r row0131)
    (slots617.pos_y 131 135 132 f r row0131)
    (slots617.inc_z 132 133 f r row0132 (Or.inl (by decide)))
    (slots617.inc_x 133 134 f r row0133 (Or.inl (by decide)))
    (slots617.jump 134 131 f r row0134)
    (slots617.zero_x 135 141 136 f r row0135)
    (slots617.pos_x 135 141 136 f r row0135)
    (slots617.inc_z 136 137 f r row0136 (Or.inl (by decide)))
    (slots617.zero_x 137 140 138 f r row0137)
    (slots617.pos_x 137 140 138 f r row0137)
    (slots617.inc_y 138 139 f r row0138 (Or.inl (by decide)))
    (slots617.jump 139 137 f r row0139)
    (slots617.jump 140 131 f r row0140)

theorem site0131 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((131:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((141:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0131Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0141Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 141 f r x y z) (slots710.atReg 145 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 141 4 145 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 141 145 142 f r row0141)
    (slots710.pos_x 141 145 142 f r row0141)
    (slots710.inc_y 142 143 f r row0142 (Or.inl (by decide)))
    (slots710.inc_y 143 144 f r row0143 (Or.inl (by decide)))
    (slots710.jump 144 141 f r row0144)

theorem site0141 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((141:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((145:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0141Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site0145Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 145 f r x y z) (slots160.atReg 148 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 145 3 148 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 145 148 146 f r row0145)
    (slots160.pos_x 145 148 146 f r row0145)
    (slots160.inc_y 146 147 f r row0146 (Or.inl (by decide)))
    (slots160.jump 147 145 f r row0147)

theorem site0145 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((145:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((148:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0145Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0148Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 148 f r x y z) (slots210.atReg 151 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 148 3 151 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 148 151 149 f r row0148)
    (slots210.pos_x 148 151 149 f r row0148)
    (slots210.inc_y 149 150 f r row0149 (Or.inl (by decide)))
    (slots210.jump 150 148 f r row0150)

theorem site0148 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((148:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((151:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0148Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0151Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 151 f r x y z) (slots617.atReg 161 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 151 10 161 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 151 155 152 f r row0151)
    (slots617.pos_y 151 155 152 f r row0151)
    (slots617.inc_z 152 153 f r row0152 (Or.inl (by decide)))
    (slots617.inc_x 153 154 f r row0153 (Or.inl (by decide)))
    (slots617.jump 154 151 f r row0154)
    (slots617.zero_x 155 161 156 f r row0155)
    (slots617.pos_x 155 161 156 f r row0155)
    (slots617.inc_z 156 157 f r row0156 (Or.inl (by decide)))
    (slots617.zero_x 157 160 158 f r row0157)
    (slots617.pos_x 157 160 158 f r row0157)
    (slots617.inc_y 158 159 f r row0158 (Or.inl (by decide)))
    (slots617.jump 159 157 f r row0159)
    (slots617.jump 160 151 f r row0160)

theorem site0151 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((151:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((161:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0151Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0161Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 161 f r x y z) (slots720.atReg 164 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 161 3 164 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 161 164 162 f r row0161)
    (slots720.pos_x 161 164 162 f r row0161)
    (slots720.inc_y 162 163 f r row0162 (Or.inl (by decide)))
    (slots720.jump 163 161 f r row0163)

theorem site0161 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((161:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((164:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0161Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0164Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 164 f r x y z) (slots461.atReg 168 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 164 4 168 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 164 168 165 f r row0164)
    (slots461.pos_x 164 168 165 f r row0164)
    (slots461.inc_y 165 166 f r row0165 (Or.inl (by decide)))
    (slots461.inc_z 166 167 f r row0166 (Or.inl (by decide)))
    (slots461.jump 167 164 f r row0167)

theorem site0164 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((164:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((168:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0164Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site0168Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 168 f r x y z) (slots640.atReg 171 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 168 3 171 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 168 171 169 f r row0168)
    (slots640.pos_x 168 171 169 f r row0168)
    (slots640.inc_y 169 170 f r row0169 (Or.inl (by decide)))
    (slots640.jump 170 168 f r row0170)

theorem site0168 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((168:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((171:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0168Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

end PA192.ModelSearch.RegisterSource.Certified
