module
public import ModelSeed09
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter321 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1567:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom55 n t s c u v y d w) w)) := by
  have micro := site1557 f n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (atom52 n t s c u v y d w)):V)=atom55 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (atom52 n t s c u v y d w)):V)=0+(atom55 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter320 f n t s c u v y d w).trans mid

theorem seedEmitAfter322 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1570:Nat):V) f (vector n 0 (atom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1567 f n 0 0 c (d+u) (v+y) 0 (atom55 n t s c u v y d w) w
  have d2 : (0+(atom55 n t s c u v y d w):V)=atom55 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter321 f n t s c u v y d w).trans mid

theorem seedEmitAfter323 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1574:Nat):V) f (vector n (d+u) (atom55 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1570 f n 0 (atom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter322 f n t s c u v y d w).trans mid

theorem seedEmitAfter324 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1577:Nat):V) f (vector n (d+u) (atom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1574 f n (d+u) (atom55 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter323 f n t s c u v y d w).trans mid

theorem seedEmitAfter325 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1585:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (atom52 n t s c u v y d w) w)) := by
  have micro := site1577 f n (d+u) (atom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom55 n t s c u v y d w)):V)=(atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom55 n t s c u v y d w):V)=0+(atom55 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom55 n t s c u v y d w)):V)=left (atom55 n t s c u v y d w)).trans (by change left (cantor ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (atom52 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom55 n t s c u v y d w)):V)=atom52 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom55 n t s c u v y d w):V)=0+(atom55 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom55 n t s c u v y d w)):V)=right (atom55 n t s c u v y d w)).trans (by change right (cantor ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (atom52 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter324 f n t s c u v y d w).trans mid

theorem seedEmitAfter326 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1588:Nat):V) f (vector n (d+u) (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1585 f n (d+u) 0 c (d+u) (v+y) ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (atom52 n t s c u v y d w) w
  have d2 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter325 f n t s c u v y d w).trans mid

theorem seedEmitAfter327 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1598:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 (atom56 n t s c u v y d w) w)) := by
  have micro := site1588 f n (d+u) (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (d+u)):V)=atom56 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (d+u)):V)=0+(atom56 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter326 f n t s c u v y d w).trans mid

theorem seedEmitAfter328 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1602:Nat):V) f (vector n ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1598 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 (atom56 n t s c u v y d w) w
  have d1 : (0+(2*(atom56 n t s c u v y d w)):V)=(atom56 n t s c u v y d w)+(atom56 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom56 n t s c u v y d w)):V)=0+((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter327 f n t s c u v y d w).trans mid

theorem seedEmitAfter329 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1603:Nat):V) f (vector n ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1602 f n ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w))+1:V)=(atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter328 f n t s c u v y d w).trans mid

theorem seedEmitAfter330 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1606:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1603 f n ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1):V)=(atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter329 f n t s c u v y d w).trans mid

theorem seedEmitAfter331 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1609:Nat):V) f (vector n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1606 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter330 f n t s c u v y d w).trans mid

theorem seedEmitAfter332 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1619:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom57 n t s c u v y d w) w)) := by
  have micro := site1609 f n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (atom52 n t s c u v y d w)):V)=atom57 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (atom52 n t s c u v y d w)):V)=0+(atom57 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter331 f n t s c u v y d w).trans mid

theorem seedEmitAfter333 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1622:Nat):V) f (vector n 0 (atom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1619 f n 0 0 c (d+u) (v+y) 0 (atom57 n t s c u v y d w) w
  have d2 : (0+(atom57 n t s c u v y d w):V)=atom57 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter332 f n t s c u v y d w).trans mid

theorem seedEmitAfter334 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1626:Nat):V) f (vector n (v+y) (atom57 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1622 f n 0 (atom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter333 f n t s c u v y d w).trans mid

theorem seedEmitAfter335 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1629:Nat):V) f (vector n (v+y) (atom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1626 f n (v+y) (atom57 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter334 f n t s c u v y d w).trans mid

theorem seedEmitAfter336 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1637:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (atom52 n t s c u v y d w) w)) := by
  have micro := site1629 f n (v+y) (atom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom57 n t s c u v y d w)):V)=(atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom57 n t s c u v y d w):V)=0+(atom57 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom57 n t s c u v y d w)):V)=left (atom57 n t s c u v y d w)).trans (by change left (cantor ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (atom52 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom57 n t s c u v y d w)):V)=atom52 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom57 n t s c u v y d w):V)=0+(atom57 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom57 n t s c u v y d w)):V)=right (atom57 n t s c u v y d w)).trans (by change right (cantor ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (atom52 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter335 f n t s c u v y d w).trans mid

theorem seedEmitAfter337 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1640:Nat):V) f (vector n (v+y) (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1637 f n (v+y) 0 c (d+u) (v+y) ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (atom52 n t s c u v y d w) w
  have d2 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter336 f n t s c u v y d w).trans mid

theorem seedEmitAfter338 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1650:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 (atom58 n t s c u v y d w) w)) := by
  have micro := site1640 f n (v+y) (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (v+y)):V)=atom58 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (v+y)):V)=0+(atom58 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter337 f n t s c u v y d w).trans mid

theorem seedEmitAfter339 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1654:Nat):V) f (vector n ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1650 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 (atom58 n t s c u v y d w) w
  have d1 : (0+(2*(atom58 n t s c u v y d w)):V)=(atom58 n t s c u v y d w)+(atom58 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom58 n t s c u v y d w)):V)=0+((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter338 f n t s c u v y d w).trans mid

theorem seedEmitAfter340 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1655:Nat):V) f (vector n ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1654 f n ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w))+1:V)=(atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter339 f n t s c u v y d w).trans mid

theorem seedEmitAfter341 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1658:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1655 f n ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1):V)=(atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter340 f n t s c u v y d w).trans mid

theorem seedEmitAfter342 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1661:Nat):V) f (vector n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1658 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter341 f n t s c u v y d w).trans mid

theorem seedEmitAfter343 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1671:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom59 n t s c u v y d w) w)) := by
  have micro := site1661 f n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) (atom52 n t s c u v y d w)):V)=atom59 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) (atom52 n t s c u v y d w)):V)=0+(atom59 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter342 f n t s c u v y d w).trans mid

theorem seedEmitAfter344 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1674:Nat):V) f (vector n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1671 f n 0 0 c (d+u) (v+y) 0 (atom59 n t s c u v y d w) w
  have d2 : (0+(atom59 n t s c u v y d w):V)=atom59 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter343 f n t s c u v y d w).trans mid

theorem seedEmitAfter345 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1678:Nat):V) f (vector n c (atom59 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site1674 f n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+c:V)=c := by ring
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter344 f n t s c u v y d w).trans mid

theorem seedEmitAfter346 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1681:Nat):V) f (vector n c (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1678 f n c (atom59 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (seedEmitAfter345 f n t s c u v y d w).trans mid

theorem seedEmitAfter347 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1684:Nat):V) f (vector n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1681 f n c (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter346 f n t s c u v y d w).trans mid

theorem seedEmitAfter348 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1687:Nat):V) f (vector n (atom59 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w)) := by
  have micro := site1684 f n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d1 : (0+(atom59 n t s c u v y d w):V)=atom59 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter347 f n t s c u v y d w).trans mid

theorem seedEmitAfter349 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1697:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom60 n t s c u v y d w) w)) := by
  have micro := site1687 f n (atom59 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w
  have d7 : (0+(cantor c (atom59 n t s c u v y d w)):V)=atom60 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor c (atom59 n t s c u v y d w)):V)=0+(atom60 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter348 f n t s c u v y d w).trans mid

theorem seedEmitAfter350 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1700:Nat):V) f (vector n 0 (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1697 f n 0 0 c (d+u) (v+y) 0 (atom60 n t s c u v y d w) w
  have d2 : (0+(atom60 n t s c u v y d w):V)=atom60 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter349 f n t s c u v y d w).trans mid

theorem seedEmitAfter351 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1704:Nat):V) f (vector n (v+y) (atom60 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1700 f n 0 (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter350 f n t s c u v y d w).trans mid

theorem seedEmitAfter352 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1707:Nat):V) f (vector n (v+y) (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1704 f n (v+y) (atom60 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter351 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
