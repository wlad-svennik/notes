module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire2688 : String := include_str ".."/"data"/"FrozenSite2688.wire"
private def indices2688 : String := include_str ".."/"data"/"FrozenSite2688.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision2688 : (checkPayload 2688 48 wire2688 indices2688).isSome=true := by decide +native

theorem scope2688 : Scope 2688 48 := payload_sound _ _ _ _ decision2688
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope2688
