module
public import ModelCmdEmit17
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter577 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2756:Nat):V) f (vector n (d+u) (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2753 f n (d+u) (atom91 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter576 f n t s c u v y d w).trans mid

theorem commandEmitAfter578 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2759:Nat):V) f (vector n 0 (atom91 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2756 f n (d+u) (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter577 f n t s c u v y d w).trans mid

theorem commandEmitAfter579 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2762:Nat):V) f (vector n (atom91 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2759 f n 0 (atom91 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom91 n t s c u v y d w):V)=atom91 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter578 f n t s c u v y d w).trans mid

theorem commandEmitAfter580 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2772:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom92 n t s c u v y d w) w)) := by
  have micro := site2762 f n (atom91 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom91 n t s c u v y d w)):V)=atom92 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom91 n t s c u v y d w)):V)=0+(atom92 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter579 f n t s c u v y d w).trans mid

theorem commandEmitAfter581 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2775:Nat):V) f (vector n 0 (atom92 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2772 f n 0 0 c (d+u) (v+y) 0 (atom92 n t s c u v y d w) w
  have d2 : (0+(atom92 n t s c u v y d w):V)=atom92 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter580 f n t s c u v y d w).trans mid

theorem commandEmitAfter582 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2779:Nat):V) f (vector n (v+y) (atom92 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2775 f n 0 (atom92 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter581 f n t s c u v y d w).trans mid

theorem commandEmitAfter583 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2782:Nat):V) f (vector n (v+y) (atom92 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2779 f n (v+y) (atom92 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter582 f n t s c u v y d w).trans mid

theorem commandEmitAfter584 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2790:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom91 n t s c u v y d w) w)) := by
  have micro := site2782 f n (v+y) (atom92 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom92 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom92 n t s c u v y d w):V)=0+(atom92 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom92 n t s c u v y d w)):V)=left (atom92 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom91 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom92 n t s c u v y d w)):V)=atom91 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom92 n t s c u v y d w):V)=0+(atom92 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom92 n t s c u v y d w)):V)=right (atom92 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom91 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter583 f n t s c u v y d w).trans mid

theorem commandEmitAfter585 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2793:Nat):V) f (vector n (v+y) (atom91 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2790 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom91 n t s c u v y d w) w
  have d2 : (0+(atom91 n t s c u v y d w):V)=atom91 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter584 f n t s c u v y d w).trans mid

theorem commandEmitAfter586 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2803:Nat):V) f (vector n 0 (atom91 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site2793 f n (v+y) (atom91 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter585 f n t s c u v y d w).trans mid

theorem commandEmitAfter587 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2807:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2803 f n 0 (atom91 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter586 f n t s c u v y d w).trans mid

theorem commandEmitAfter588 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2808:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2807 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter587 f n t s c u v y d w).trans mid

theorem commandEmitAfter589 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2809:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2808 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter588 f n t s c u v y d w).trans mid

theorem commandEmitAfter590 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2817:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) (d+u) (atom90 n t s c u v y d w) w)) := by
  have micro := site2809 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) (atom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom91 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom91 n t s c u v y d w):V)=0+(atom91 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom91 n t s c u v y d w)):V)=left (atom91 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom90 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom91 n t s c u v y d w)):V)=atom90 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom91 n t s c u v y d w):V)=0+(atom91 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom91 n t s c u v y d w)):V)=right (atom91 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom90 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter589 f n t s c u v y d w).trans mid

theorem commandEmitAfter591 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2820:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) (atom90 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2817 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) (d+u) (atom90 n t s c u v y d w) w
  have d2 : (0+(atom90 n t s c u v y d w):V)=atom90 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter590 f n t s c u v y d w).trans mid

theorem commandEmitAfter592 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2830:Nat):V) f (vector n 0 (atom90 n t s c u v y d w) c (d+u) (v+y) 0 (atom93 n t s c u v y d w) w)) := by
  have micro := site2820 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2) (atom90 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2)):V)=atom93 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2)):V)=0+(atom93 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter591 f n t s c u v y d w).trans mid

theorem commandEmitAfter593 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2834:Nat):V) f (vector n ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)) (atom90 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2830 f n 0 (atom90 n t s c u v y d w) c (d+u) (v+y) 0 (atom93 n t s c u v y d w) w
  have d1 : (0+(2*(atom93 n t s c u v y d w)):V)=(atom93 n t s c u v y d w)+(atom93 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom93 n t s c u v y d w)):V)=0+((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter592 f n t s c u v y d w).trans mid

theorem commandEmitAfter594 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2835:Nat):V) f (vector n ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1) (atom90 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2834 f n ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)) (atom90 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w))+1:V)=(atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter593 f n t s c u v y d w).trans mid

theorem commandEmitAfter595 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2843:Nat):V) f (vector n ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) (atom86 n t s c u v y d w) w)) := by
  have micro := site2835 f n ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1) (atom90 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom90 n t s c u v y d w)):V)=(atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom90 n t s c u v y d w):V)=0+(atom90 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom90 n t s c u v y d w)):V)=left (atom90 n t s c u v y d w)).trans (by change left (cantor ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) (atom86 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom90 n t s c u v y d w)):V)=atom86 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom90 n t s c u v y d w):V)=0+(atom90 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom90 n t s c u v y d w)):V)=right (atom90 n t s c u v y d w)).trans (by change right (cantor ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) (atom86 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter594 f n t s c u v y d w).trans mid

theorem commandEmitAfter596 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2846:Nat):V) f (vector n ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2843 f n ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) (atom86 n t s c u v y d w) w
  have d2 : (0+(atom86 n t s c u v y d w):V)=atom86 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter595 f n t s c u v y d w).trans mid

theorem commandEmitAfter597 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2856:Nat):V) f (vector n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 (atom94 n t s c u v y d w) w)) := by
  have micro := site2846 f n ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1)):V)=atom94 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1)):V)=0+(atom94 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter596 f n t s c u v y d w).trans mid

theorem commandEmitAfter598 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2860:Nat):V) f (vector n ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2856 f n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 (atom94 n t s c u v y d w) w
  have d1 : (0+(2*(atom94 n t s c u v y d w)):V)=(atom94 n t s c u v y d w)+(atom94 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom94 n t s c u v y d w)):V)=0+((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter597 f n t s c u v y d w).trans mid

theorem commandEmitAfter599 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2861:Nat):V) f (vector n ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2860 f n ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w))+1:V)=(atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter598 f n t s c u v y d w).trans mid

theorem commandEmitAfter600 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2864:Nat):V) f (vector n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2861 f n ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1):V)=(atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter599 f n t s c u v y d w).trans mid

theorem commandEmitAfter601 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2867:Nat):V) f (vector n (atom86 n t s c u v y d w) 0 c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2864 f n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom86 n t s c u v y d w):V)=atom86 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter600 f n t s c u v y d w).trans mid

theorem commandEmitAfter602 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2877:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom95 n t s c u v y d w) w)) := by
  have micro := site2867 f n (atom86 n t s c u v y d w) 0 c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w)):V)=atom95 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w)):V)=0+(atom95 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter601 f n t s c u v y d w).trans mid

theorem commandEmitAfter603 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2880:Nat):V) f (vector n 0 (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2877 f n 0 0 c (d+u) (v+y) 0 (atom95 n t s c u v y d w) w
  have d2 : (0+(atom95 n t s c u v y d w):V)=atom95 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter602 f n t s c u v y d w).trans mid

theorem commandEmitAfter604 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2884:Nat):V) f (vector n (d+u) (atom95 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2880 f n 0 (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter603 f n t s c u v y d w).trans mid

theorem commandEmitAfter605 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2887:Nat):V) f (vector n (d+u) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2884 f n (d+u) (atom95 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter604 f n t s c u v y d w).trans mid

theorem commandEmitAfter606 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2890:Nat):V) f (vector n 0 (atom95 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2887 f n (d+u) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter605 f n t s c u v y d w).trans mid

theorem commandEmitAfter607 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2893:Nat):V) f (vector n (atom95 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2890 f n 0 (atom95 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom95 n t s c u v y d w):V)=atom95 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter606 f n t s c u v y d w).trans mid

theorem commandEmitAfter608 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2903:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom96 n t s c u v y d w) w)) := by
  have micro := site2893 f n (atom95 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom95 n t s c u v y d w)):V)=atom96 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom95 n t s c u v y d w)):V)=0+(atom96 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter607 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
