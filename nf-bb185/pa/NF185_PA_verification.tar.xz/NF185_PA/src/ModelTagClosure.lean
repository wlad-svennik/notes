module
public import ModelLiteralRegisters

@[expose] public section
namespace PA192.PhysicalModel.TagClosure
open PA192.ModelSearch.RegisterSource
set_option maxRecDepth 8000
set_option maxHeartbeats 2000000

def legal (p : Nat) (c : Bool) := !c || decide (p<3 ∨ 9<p)
def allowed (op : Instr) (z : Bool) : Bool := match op with
  | .dec .. => true | _ => !z
def next (op : Instr) (z : Bool) : Nat := match op with
  | .inc _ n | .jump n => n
  | .dec _ onZero onPositive => if z then onZero else onPositive
def cold' (op : Instr) (c : Bool) : Bool := match op with
  | .inc 0 _ => false | _ => c

private def Preserves (p : Nat) (op : Instr) : Prop :=
  ∀ c z : Bool, legal p c=true → allowed op z=true →
    next op z=4095 ∨ next op z<3089 ∧ legal (next op z) (cold' op c)=true

private instance (p : Nat) (op : Instr) : Decidable (Preserves p op) := by unfold Preserves; infer_instance

private def scan : Nat → List Instr → Bool
  | _, [] => true
  | p, op::rest => decide (Preserves p op) && scan (p+1) rest

private theorem scan_sound (ops : List Instr) (p i : Nat) (op : Instr)
    (pass : scan p ops=true) (here : ops[i]?=some op) : Preserves (p+i) op := by
  induction ops generalizing p i with
  | nil => simp at here
  | cons hd tl ih =>
    simp only [scan,Bool.and_eq_true,decide_eq_true_eq] at pass
    cases i with
    | zero => simp at here; subst op; simpa using pass.1
    | succ j =>
      simp at here
      have t := ih (p+1) j pass.2 here
      exact (show (p+1)+j = p+j.succ by omega) ▸ t

private theorem scan_append (a b : List Instr) (p : Nat) :
    scan p (a++b) = (scan p a && scan (p+a.length) b) := by
  induction a generalizing p with
  | nil => simp [scan]
  | cons op rest ih =>
    simp only [List.cons_append,scan,ih,List.length_cons,Bool.and_assoc]
    congr 3
    omega

private theorem combine {p m : Nat} {a b : List Instr} (size : a.length=m)
    (l : scan p a=true) (r : scan (p+m) b=true) : scan p (a++b)=true := by
  rw [scan_append,size,l,r]; rfl

private theorem size0_32 : instructions0.length = 32 := rfl
private theorem valid0_32 : scan 0 instructions0=true := by decide +kernel
private theorem size32_64 : instructions32.length = 32 := rfl
private theorem valid32_64 : scan 32 instructions32=true := by decide +kernel
private theorem size64_96 : instructions64.length = 32 := rfl
private theorem valid64_96 : scan 64 instructions64=true := by decide +kernel
private theorem size96_128 : instructions96.length = 32 := rfl
private theorem valid96_128 : scan 96 instructions96=true := by decide +kernel
private theorem size128_160 : instructions128.length = 32 := rfl
private theorem valid128_160 : scan 128 instructions128=true := by decide +kernel
private theorem size160_192 : instructions160.length = 32 := rfl
private theorem valid160_192 : scan 160 instructions160=true := by decide +kernel
private theorem size192_224 : instructions192.length = 32 := rfl
private theorem valid192_224 : scan 192 instructions192=true := by decide +kernel
private theorem size224_256 : instructions224.length = 32 := rfl
private theorem valid224_256 : scan 224 instructions224=true := by decide +kernel
private theorem size256_288 : instructions256.length = 32 := rfl
private theorem valid256_288 : scan 256 instructions256=true := by decide +kernel
private theorem size288_320 : instructions288.length = 32 := rfl
private theorem valid288_320 : scan 288 instructions288=true := by decide +kernel
private theorem size320_352 : instructions320.length = 32 := rfl
private theorem valid320_352 : scan 320 instructions320=true := by decide +kernel
private theorem size352_384 : instructions352.length = 32 := rfl
private theorem valid352_384 : scan 352 instructions352=true := by decide +kernel
private theorem size384_416 : instructions384.length = 32 := rfl
private theorem valid384_416 : scan 384 instructions384=true := by decide +kernel
private theorem size416_448 : instructions416.length = 32 := rfl
private theorem valid416_448 : scan 416 instructions416=true := by decide +kernel
private theorem size448_480 : instructions448.length = 32 := rfl
private theorem valid448_480 : scan 448 instructions448=true := by decide +kernel
private theorem size480_512 : instructions480.length = 32 := rfl
private theorem valid480_512 : scan 480 instructions480=true := by decide +kernel
private theorem size512_544 : instructions512.length = 32 := rfl
private theorem valid512_544 : scan 512 instructions512=true := by decide +kernel
private theorem size544_576 : instructions544.length = 32 := rfl
private theorem valid544_576 : scan 544 instructions544=true := by decide +kernel
private theorem size576_608 : instructions576.length = 32 := rfl
private theorem valid576_608 : scan 576 instructions576=true := by decide +kernel
private theorem size608_640 : instructions608.length = 32 := rfl
private theorem valid608_640 : scan 608 instructions608=true := by decide +kernel
private theorem size640_672 : instructions640.length = 32 := rfl
private theorem valid640_672 : scan 640 instructions640=true := by decide +kernel
private theorem size672_704 : instructions672.length = 32 := rfl
private theorem valid672_704 : scan 672 instructions672=true := by decide +kernel
private theorem size704_736 : instructions704.length = 32 := rfl
private theorem valid704_736 : scan 704 instructions704=true := by decide +kernel
private theorem size736_768 : instructions736.length = 32 := rfl
private theorem valid736_768 : scan 736 instructions736=true := by decide +kernel
private theorem size768_800 : instructions768.length = 32 := rfl
private theorem valid768_800 : scan 768 instructions768=true := by decide +kernel
private theorem size800_832 : instructions800.length = 32 := rfl
private theorem valid800_832 : scan 800 instructions800=true := by decide +kernel
private theorem size832_864 : instructions832.length = 32 := rfl
private theorem valid832_864 : scan 832 instructions832=true := by decide +kernel
private theorem size864_896 : instructions864.length = 32 := rfl
private theorem valid864_896 : scan 864 instructions864=true := by decide +kernel
private theorem size896_928 : instructions896.length = 32 := rfl
private theorem valid896_928 : scan 896 instructions896=true := by decide +kernel
private theorem size928_960 : instructions928.length = 32 := rfl
private theorem valid928_960 : scan 928 instructions928=true := by decide +kernel
private theorem size960_992 : instructions960.length = 32 := rfl
private theorem valid960_992 : scan 960 instructions960=true := by decide +kernel
private theorem size992_1024 : instructions992.length = 32 := rfl
private theorem valid992_1024 : scan 992 instructions992=true := by decide +kernel
private theorem size1024_1056 : instructions1024.length = 32 := rfl
private theorem valid1024_1056 : scan 1024 instructions1024=true := by decide +kernel
private theorem size1056_1088 : instructions1056.length = 32 := rfl
private theorem valid1056_1088 : scan 1056 instructions1056=true := by decide +kernel
private theorem size1088_1120 : instructions1088.length = 32 := rfl
private theorem valid1088_1120 : scan 1088 instructions1088=true := by decide +kernel
private theorem size1120_1152 : instructions1120.length = 32 := rfl
private theorem valid1120_1152 : scan 1120 instructions1120=true := by decide +kernel
private theorem size1152_1184 : instructions1152.length = 32 := rfl
private theorem valid1152_1184 : scan 1152 instructions1152=true := by decide +kernel
private theorem size1184_1216 : instructions1184.length = 32 := rfl
private theorem valid1184_1216 : scan 1184 instructions1184=true := by decide +kernel
private theorem size1216_1248 : instructions1216.length = 32 := rfl
private theorem valid1216_1248 : scan 1216 instructions1216=true := by decide +kernel
private theorem size1248_1280 : instructions1248.length = 32 := rfl
private theorem valid1248_1280 : scan 1248 instructions1248=true := by decide +kernel
private theorem size1280_1312 : instructions1280.length = 32 := rfl
private theorem valid1280_1312 : scan 1280 instructions1280=true := by decide +kernel
private theorem size1312_1344 : instructions1312.length = 32 := rfl
private theorem valid1312_1344 : scan 1312 instructions1312=true := by decide +kernel
private theorem size1344_1376 : instructions1344.length = 32 := rfl
private theorem valid1344_1376 : scan 1344 instructions1344=true := by decide +kernel
private theorem size1376_1408 : instructions1376.length = 32 := rfl
private theorem valid1376_1408 : scan 1376 instructions1376=true := by decide +kernel
private theorem size1408_1440 : instructions1408.length = 32 := rfl
private theorem valid1408_1440 : scan 1408 instructions1408=true := by decide +kernel
private theorem size1440_1472 : instructions1440.length = 32 := rfl
private theorem valid1440_1472 : scan 1440 instructions1440=true := by decide +kernel
private theorem size1472_1504 : instructions1472.length = 32 := rfl
private theorem valid1472_1504 : scan 1472 instructions1472=true := by decide +kernel
private theorem size1504_1536 : instructions1504.length = 32 := rfl
private theorem valid1504_1536 : scan 1504 instructions1504=true := by decide +kernel
private theorem size1536_1568 : instructions1536.length = 32 := rfl
private theorem valid1536_1568 : scan 1536 instructions1536=true := by decide +kernel
private theorem size1568_1600 : instructions1568.length = 32 := rfl
private theorem valid1568_1600 : scan 1568 instructions1568=true := by decide +kernel
private theorem size1600_1632 : instructions1600.length = 32 := rfl
private theorem valid1600_1632 : scan 1600 instructions1600=true := by decide +kernel
private theorem size1632_1664 : instructions1632.length = 32 := rfl
private theorem valid1632_1664 : scan 1632 instructions1632=true := by decide +kernel
private theorem size1664_1696 : instructions1664.length = 32 := rfl
private theorem valid1664_1696 : scan 1664 instructions1664=true := by decide +kernel
private theorem size1696_1728 : instructions1696.length = 32 := rfl
private theorem valid1696_1728 : scan 1696 instructions1696=true := by decide +kernel
private theorem size1728_1760 : instructions1728.length = 32 := rfl
private theorem valid1728_1760 : scan 1728 instructions1728=true := by decide +kernel
private theorem size1760_1792 : instructions1760.length = 32 := rfl
private theorem valid1760_1792 : scan 1760 instructions1760=true := by decide +kernel
private theorem size1792_1824 : instructions1792.length = 32 := rfl
private theorem valid1792_1824 : scan 1792 instructions1792=true := by decide +kernel
private theorem size1824_1856 : instructions1824.length = 32 := rfl
private theorem valid1824_1856 : scan 1824 instructions1824=true := by decide +kernel
private theorem size1856_1888 : instructions1856.length = 32 := rfl
private theorem valid1856_1888 : scan 1856 instructions1856=true := by decide +kernel
private theorem size1888_1920 : instructions1888.length = 32 := rfl
private theorem valid1888_1920 : scan 1888 instructions1888=true := by decide +kernel
private theorem size1920_1952 : instructions1920.length = 32 := rfl
private theorem valid1920_1952 : scan 1920 instructions1920=true := by decide +kernel
private theorem size1952_1984 : instructions1952.length = 32 := rfl
private theorem valid1952_1984 : scan 1952 instructions1952=true := by decide +kernel
private theorem size1984_2016 : instructions1984.length = 32 := rfl
private theorem valid1984_2016 : scan 1984 instructions1984=true := by decide +kernel
private theorem size2016_2048 : instructions2016.length = 32 := rfl
private theorem valid2016_2048 : scan 2016 instructions2016=true := by decide +kernel
private theorem size2048_2080 : instructions2048.length = 32 := rfl
private theorem valid2048_2080 : scan 2048 instructions2048=true := by decide +kernel
private theorem size2080_2112 : instructions2080.length = 32 := rfl
private theorem valid2080_2112 : scan 2080 instructions2080=true := by decide +kernel
private theorem size2112_2144 : instructions2112.length = 32 := rfl
private theorem valid2112_2144 : scan 2112 instructions2112=true := by decide +kernel
private theorem size2144_2176 : instructions2144.length = 32 := rfl
private theorem valid2144_2176 : scan 2144 instructions2144=true := by decide +kernel
private theorem size2176_2208 : instructions2176.length = 32 := rfl
private theorem valid2176_2208 : scan 2176 instructions2176=true := by decide +kernel
private theorem size2208_2240 : instructions2208.length = 32 := rfl
private theorem valid2208_2240 : scan 2208 instructions2208=true := by decide +kernel
private theorem size2240_2272 : instructions2240.length = 32 := rfl
private theorem valid2240_2272 : scan 2240 instructions2240=true := by decide +kernel
private theorem size2272_2304 : instructions2272.length = 32 := rfl
private theorem valid2272_2304 : scan 2272 instructions2272=true := by decide +kernel
private theorem size2304_2336 : instructions2304.length = 32 := rfl
private theorem valid2304_2336 : scan 2304 instructions2304=true := by decide +kernel
private theorem size2336_2368 : instructions2336.length = 32 := rfl
private theorem valid2336_2368 : scan 2336 instructions2336=true := by decide +kernel
private theorem size2368_2400 : instructions2368.length = 32 := rfl
private theorem valid2368_2400 : scan 2368 instructions2368=true := by decide +kernel
private theorem size2400_2432 : instructions2400.length = 32 := rfl
private theorem valid2400_2432 : scan 2400 instructions2400=true := by decide +kernel
private theorem size2432_2464 : instructions2432.length = 32 := rfl
private theorem valid2432_2464 : scan 2432 instructions2432=true := by decide +kernel
private theorem size2464_2496 : instructions2464.length = 32 := rfl
private theorem valid2464_2496 : scan 2464 instructions2464=true := by decide +kernel
private theorem size2496_2528 : instructions2496.length = 32 := rfl
private theorem valid2496_2528 : scan 2496 instructions2496=true := by decide +kernel
private theorem size2528_2560 : instructions2528.length = 32 := rfl
private theorem valid2528_2560 : scan 2528 instructions2528=true := by decide +kernel
private theorem size2560_2592 : instructions2560.length = 32 := rfl
private theorem valid2560_2592 : scan 2560 instructions2560=true := by decide +kernel
private theorem size2592_2624 : instructions2592.length = 32 := rfl
private theorem valid2592_2624 : scan 2592 instructions2592=true := by decide +kernel
private theorem size2624_2656 : instructions2624.length = 32 := rfl
private theorem valid2624_2656 : scan 2624 instructions2624=true := by decide +kernel
private theorem size2656_2688 : instructions2656.length = 32 := rfl
private theorem valid2656_2688 : scan 2656 instructions2656=true := by decide +kernel
private theorem size2688_2720 : instructions2688.length = 32 := rfl
private theorem valid2688_2720 : scan 2688 instructions2688=true := by decide +kernel
private theorem size2720_2752 : instructions2720.length = 32 := rfl
private theorem valid2720_2752 : scan 2720 instructions2720=true := by decide +kernel
private theorem size2752_2784 : instructions2752.length = 32 := rfl
private theorem valid2752_2784 : scan 2752 instructions2752=true := by decide +kernel
private theorem size2784_2816 : instructions2784.length = 32 := rfl
private theorem valid2784_2816 : scan 2784 instructions2784=true := by decide +kernel
private theorem size2816_2848 : instructions2816.length = 32 := rfl
private theorem valid2816_2848 : scan 2816 instructions2816=true := by decide +kernel
private theorem size2848_2880 : instructions2848.length = 32 := rfl
private theorem valid2848_2880 : scan 2848 instructions2848=true := by decide +kernel
private theorem size2880_2912 : instructions2880.length = 32 := rfl
private theorem valid2880_2912 : scan 2880 instructions2880=true := by decide +kernel
private theorem size2912_2944 : instructions2912.length = 32 := rfl
private theorem valid2912_2944 : scan 2912 instructions2912=true := by decide +kernel
private theorem size2944_2976 : instructions2944.length = 32 := rfl
private theorem valid2944_2976 : scan 2944 instructions2944=true := by decide +kernel
private theorem size2976_3008 : instructions2976.length = 32 := rfl
private theorem valid2976_3008 : scan 2976 instructions2976=true := by decide +kernel
private theorem size3008_3040 : instructions3008.length = 32 := rfl
private theorem valid3008_3040 : scan 3008 instructions3008=true := by decide +kernel
private theorem size3040_3072 : instructions3040.length = 32 := rfl
private theorem valid3040_3072 : scan 3040 instructions3040=true := by decide +kernel
private theorem size3072_3089 : instructions3072.length = 17 := rfl
private theorem valid3072_3089 : scan 3072 instructions3072=true := by decide +kernel
private def group0_64 : List Instr := instructions0 ++ instructions32
private theorem size0_64 : group0_64.length = 64 := by rw [group0_64,List.length_append,size0_32,size32_64]
private theorem valid0_64 : scan 0 group0_64=true := combine size0_32 valid0_32 valid32_64
private def group64_128 : List Instr := instructions64 ++ instructions96
private theorem size64_128 : group64_128.length = 64 := by rw [group64_128,List.length_append,size64_96,size96_128]
private theorem valid64_128 : scan 64 group64_128=true := combine size64_96 valid64_96 valid96_128
private def group128_192 : List Instr := instructions128 ++ instructions160
private theorem size128_192 : group128_192.length = 64 := by rw [group128_192,List.length_append,size128_160,size160_192]
private theorem valid128_192 : scan 128 group128_192=true := combine size128_160 valid128_160 valid160_192
private def group192_256 : List Instr := instructions192 ++ instructions224
private theorem size192_256 : group192_256.length = 64 := by rw [group192_256,List.length_append,size192_224,size224_256]
private theorem valid192_256 : scan 192 group192_256=true := combine size192_224 valid192_224 valid224_256
private def group256_320 : List Instr := instructions256 ++ instructions288
private theorem size256_320 : group256_320.length = 64 := by rw [group256_320,List.length_append,size256_288,size288_320]
private theorem valid256_320 : scan 256 group256_320=true := combine size256_288 valid256_288 valid288_320
private def group320_384 : List Instr := instructions320 ++ instructions352
private theorem size320_384 : group320_384.length = 64 := by rw [group320_384,List.length_append,size320_352,size352_384]
private theorem valid320_384 : scan 320 group320_384=true := combine size320_352 valid320_352 valid352_384
private def group384_448 : List Instr := instructions384 ++ instructions416
private theorem size384_448 : group384_448.length = 64 := by rw [group384_448,List.length_append,size384_416,size416_448]
private theorem valid384_448 : scan 384 group384_448=true := combine size384_416 valid384_416 valid416_448
private def group448_512 : List Instr := instructions448 ++ instructions480
private theorem size448_512 : group448_512.length = 64 := by rw [group448_512,List.length_append,size448_480,size480_512]
private theorem valid448_512 : scan 448 group448_512=true := combine size448_480 valid448_480 valid480_512
private def group512_576 : List Instr := instructions512 ++ instructions544
private theorem size512_576 : group512_576.length = 64 := by rw [group512_576,List.length_append,size512_544,size544_576]
private theorem valid512_576 : scan 512 group512_576=true := combine size512_544 valid512_544 valid544_576
private def group576_640 : List Instr := instructions576 ++ instructions608
private theorem size576_640 : group576_640.length = 64 := by rw [group576_640,List.length_append,size576_608,size608_640]
private theorem valid576_640 : scan 576 group576_640=true := combine size576_608 valid576_608 valid608_640
private def group640_704 : List Instr := instructions640 ++ instructions672
private theorem size640_704 : group640_704.length = 64 := by rw [group640_704,List.length_append,size640_672,size672_704]
private theorem valid640_704 : scan 640 group640_704=true := combine size640_672 valid640_672 valid672_704
private def group704_768 : List Instr := instructions704 ++ instructions736
private theorem size704_768 : group704_768.length = 64 := by rw [group704_768,List.length_append,size704_736,size736_768]
private theorem valid704_768 : scan 704 group704_768=true := combine size704_736 valid704_736 valid736_768
private def group768_832 : List Instr := instructions768 ++ instructions800
private theorem size768_832 : group768_832.length = 64 := by rw [group768_832,List.length_append,size768_800,size800_832]
private theorem valid768_832 : scan 768 group768_832=true := combine size768_800 valid768_800 valid800_832
private def group832_896 : List Instr := instructions832 ++ instructions864
private theorem size832_896 : group832_896.length = 64 := by rw [group832_896,List.length_append,size832_864,size864_896]
private theorem valid832_896 : scan 832 group832_896=true := combine size832_864 valid832_864 valid864_896
private def group896_960 : List Instr := instructions896 ++ instructions928
private theorem size896_960 : group896_960.length = 64 := by rw [group896_960,List.length_append,size896_928,size928_960]
private theorem valid896_960 : scan 896 group896_960=true := combine size896_928 valid896_928 valid928_960
private def group960_1024 : List Instr := instructions960 ++ instructions992
private theorem size960_1024 : group960_1024.length = 64 := by rw [group960_1024,List.length_append,size960_992,size992_1024]
private theorem valid960_1024 : scan 960 group960_1024=true := combine size960_992 valid960_992 valid992_1024
private def group1024_1088 : List Instr := instructions1024 ++ instructions1056
private theorem size1024_1088 : group1024_1088.length = 64 := by rw [group1024_1088,List.length_append,size1024_1056,size1056_1088]
private theorem valid1024_1088 : scan 1024 group1024_1088=true := combine size1024_1056 valid1024_1056 valid1056_1088
private def group1088_1152 : List Instr := instructions1088 ++ instructions1120
private theorem size1088_1152 : group1088_1152.length = 64 := by rw [group1088_1152,List.length_append,size1088_1120,size1120_1152]
private theorem valid1088_1152 : scan 1088 group1088_1152=true := combine size1088_1120 valid1088_1120 valid1120_1152
private def group1152_1216 : List Instr := instructions1152 ++ instructions1184
private theorem size1152_1216 : group1152_1216.length = 64 := by rw [group1152_1216,List.length_append,size1152_1184,size1184_1216]
private theorem valid1152_1216 : scan 1152 group1152_1216=true := combine size1152_1184 valid1152_1184 valid1184_1216
private def group1216_1280 : List Instr := instructions1216 ++ instructions1248
private theorem size1216_1280 : group1216_1280.length = 64 := by rw [group1216_1280,List.length_append,size1216_1248,size1248_1280]
private theorem valid1216_1280 : scan 1216 group1216_1280=true := combine size1216_1248 valid1216_1248 valid1248_1280
private def group1280_1344 : List Instr := instructions1280 ++ instructions1312
private theorem size1280_1344 : group1280_1344.length = 64 := by rw [group1280_1344,List.length_append,size1280_1312,size1312_1344]
private theorem valid1280_1344 : scan 1280 group1280_1344=true := combine size1280_1312 valid1280_1312 valid1312_1344
private def group1344_1408 : List Instr := instructions1344 ++ instructions1376
private theorem size1344_1408 : group1344_1408.length = 64 := by rw [group1344_1408,List.length_append,size1344_1376,size1376_1408]
private theorem valid1344_1408 : scan 1344 group1344_1408=true := combine size1344_1376 valid1344_1376 valid1376_1408
private def group1408_1472 : List Instr := instructions1408 ++ instructions1440
private theorem size1408_1472 : group1408_1472.length = 64 := by rw [group1408_1472,List.length_append,size1408_1440,size1440_1472]
private theorem valid1408_1472 : scan 1408 group1408_1472=true := combine size1408_1440 valid1408_1440 valid1440_1472
private def group1472_1536 : List Instr := instructions1472 ++ instructions1504
private theorem size1472_1536 : group1472_1536.length = 64 := by rw [group1472_1536,List.length_append,size1472_1504,size1504_1536]
private theorem valid1472_1536 : scan 1472 group1472_1536=true := combine size1472_1504 valid1472_1504 valid1504_1536
private def group1536_1600 : List Instr := instructions1536 ++ instructions1568
private theorem size1536_1600 : group1536_1600.length = 64 := by rw [group1536_1600,List.length_append,size1536_1568,size1568_1600]
private theorem valid1536_1600 : scan 1536 group1536_1600=true := combine size1536_1568 valid1536_1568 valid1568_1600
private def group1600_1664 : List Instr := instructions1600 ++ instructions1632
private theorem size1600_1664 : group1600_1664.length = 64 := by rw [group1600_1664,List.length_append,size1600_1632,size1632_1664]
private theorem valid1600_1664 : scan 1600 group1600_1664=true := combine size1600_1632 valid1600_1632 valid1632_1664
private def group1664_1728 : List Instr := instructions1664 ++ instructions1696
private theorem size1664_1728 : group1664_1728.length = 64 := by rw [group1664_1728,List.length_append,size1664_1696,size1696_1728]
private theorem valid1664_1728 : scan 1664 group1664_1728=true := combine size1664_1696 valid1664_1696 valid1696_1728
private def group1728_1792 : List Instr := instructions1728 ++ instructions1760
private theorem size1728_1792 : group1728_1792.length = 64 := by rw [group1728_1792,List.length_append,size1728_1760,size1760_1792]
private theorem valid1728_1792 : scan 1728 group1728_1792=true := combine size1728_1760 valid1728_1760 valid1760_1792
private def group1792_1856 : List Instr := instructions1792 ++ instructions1824
private theorem size1792_1856 : group1792_1856.length = 64 := by rw [group1792_1856,List.length_append,size1792_1824,size1824_1856]
private theorem valid1792_1856 : scan 1792 group1792_1856=true := combine size1792_1824 valid1792_1824 valid1824_1856
private def group1856_1920 : List Instr := instructions1856 ++ instructions1888
private theorem size1856_1920 : group1856_1920.length = 64 := by rw [group1856_1920,List.length_append,size1856_1888,size1888_1920]
private theorem valid1856_1920 : scan 1856 group1856_1920=true := combine size1856_1888 valid1856_1888 valid1888_1920
private def group1920_1984 : List Instr := instructions1920 ++ instructions1952
private theorem size1920_1984 : group1920_1984.length = 64 := by rw [group1920_1984,List.length_append,size1920_1952,size1952_1984]
private theorem valid1920_1984 : scan 1920 group1920_1984=true := combine size1920_1952 valid1920_1952 valid1952_1984
private def group1984_2048 : List Instr := instructions1984 ++ instructions2016
private theorem size1984_2048 : group1984_2048.length = 64 := by rw [group1984_2048,List.length_append,size1984_2016,size2016_2048]
private theorem valid1984_2048 : scan 1984 group1984_2048=true := combine size1984_2016 valid1984_2016 valid2016_2048
private def group2048_2112 : List Instr := instructions2048 ++ instructions2080
private theorem size2048_2112 : group2048_2112.length = 64 := by rw [group2048_2112,List.length_append,size2048_2080,size2080_2112]
private theorem valid2048_2112 : scan 2048 group2048_2112=true := combine size2048_2080 valid2048_2080 valid2080_2112
private def group2112_2176 : List Instr := instructions2112 ++ instructions2144
private theorem size2112_2176 : group2112_2176.length = 64 := by rw [group2112_2176,List.length_append,size2112_2144,size2144_2176]
private theorem valid2112_2176 : scan 2112 group2112_2176=true := combine size2112_2144 valid2112_2144 valid2144_2176
private def group2176_2240 : List Instr := instructions2176 ++ instructions2208
private theorem size2176_2240 : group2176_2240.length = 64 := by rw [group2176_2240,List.length_append,size2176_2208,size2208_2240]
private theorem valid2176_2240 : scan 2176 group2176_2240=true := combine size2176_2208 valid2176_2208 valid2208_2240
private def group2240_2304 : List Instr := instructions2240 ++ instructions2272
private theorem size2240_2304 : group2240_2304.length = 64 := by rw [group2240_2304,List.length_append,size2240_2272,size2272_2304]
private theorem valid2240_2304 : scan 2240 group2240_2304=true := combine size2240_2272 valid2240_2272 valid2272_2304
private def group2304_2368 : List Instr := instructions2304 ++ instructions2336
private theorem size2304_2368 : group2304_2368.length = 64 := by rw [group2304_2368,List.length_append,size2304_2336,size2336_2368]
private theorem valid2304_2368 : scan 2304 group2304_2368=true := combine size2304_2336 valid2304_2336 valid2336_2368
private def group2368_2432 : List Instr := instructions2368 ++ instructions2400
private theorem size2368_2432 : group2368_2432.length = 64 := by rw [group2368_2432,List.length_append,size2368_2400,size2400_2432]
private theorem valid2368_2432 : scan 2368 group2368_2432=true := combine size2368_2400 valid2368_2400 valid2400_2432
private def group2432_2496 : List Instr := instructions2432 ++ instructions2464
private theorem size2432_2496 : group2432_2496.length = 64 := by rw [group2432_2496,List.length_append,size2432_2464,size2464_2496]
private theorem valid2432_2496 : scan 2432 group2432_2496=true := combine size2432_2464 valid2432_2464 valid2464_2496
private def group2496_2560 : List Instr := instructions2496 ++ instructions2528
private theorem size2496_2560 : group2496_2560.length = 64 := by rw [group2496_2560,List.length_append,size2496_2528,size2528_2560]
private theorem valid2496_2560 : scan 2496 group2496_2560=true := combine size2496_2528 valid2496_2528 valid2528_2560
private def group2560_2624 : List Instr := instructions2560 ++ instructions2592
private theorem size2560_2624 : group2560_2624.length = 64 := by rw [group2560_2624,List.length_append,size2560_2592,size2592_2624]
private theorem valid2560_2624 : scan 2560 group2560_2624=true := combine size2560_2592 valid2560_2592 valid2592_2624
private def group2624_2688 : List Instr := instructions2624 ++ instructions2656
private theorem size2624_2688 : group2624_2688.length = 64 := by rw [group2624_2688,List.length_append,size2624_2656,size2656_2688]
private theorem valid2624_2688 : scan 2624 group2624_2688=true := combine size2624_2656 valid2624_2656 valid2656_2688
private def group2688_2752 : List Instr := instructions2688 ++ instructions2720
private theorem size2688_2752 : group2688_2752.length = 64 := by rw [group2688_2752,List.length_append,size2688_2720,size2720_2752]
private theorem valid2688_2752 : scan 2688 group2688_2752=true := combine size2688_2720 valid2688_2720 valid2720_2752
private def group2752_2816 : List Instr := instructions2752 ++ instructions2784
private theorem size2752_2816 : group2752_2816.length = 64 := by rw [group2752_2816,List.length_append,size2752_2784,size2784_2816]
private theorem valid2752_2816 : scan 2752 group2752_2816=true := combine size2752_2784 valid2752_2784 valid2784_2816
private def group2816_2880 : List Instr := instructions2816 ++ instructions2848
private theorem size2816_2880 : group2816_2880.length = 64 := by rw [group2816_2880,List.length_append,size2816_2848,size2848_2880]
private theorem valid2816_2880 : scan 2816 group2816_2880=true := combine size2816_2848 valid2816_2848 valid2848_2880
private def group2880_2944 : List Instr := instructions2880 ++ instructions2912
private theorem size2880_2944 : group2880_2944.length = 64 := by rw [group2880_2944,List.length_append,size2880_2912,size2912_2944]
private theorem valid2880_2944 : scan 2880 group2880_2944=true := combine size2880_2912 valid2880_2912 valid2912_2944
private def group2944_3008 : List Instr := instructions2944 ++ instructions2976
private theorem size2944_3008 : group2944_3008.length = 64 := by rw [group2944_3008,List.length_append,size2944_2976,size2976_3008]
private theorem valid2944_3008 : scan 2944 group2944_3008=true := combine size2944_2976 valid2944_2976 valid2976_3008
private def group3008_3072 : List Instr := instructions3008 ++ instructions3040
private theorem size3008_3072 : group3008_3072.length = 64 := by rw [group3008_3072,List.length_append,size3008_3040,size3040_3072]
private theorem valid3008_3072 : scan 3008 group3008_3072=true := combine size3008_3040 valid3008_3040 valid3040_3072
private def group0_128 : List Instr := group0_64 ++ group64_128
private theorem size0_128 : group0_128.length = 128 := by rw [group0_128,List.length_append,size0_64,size64_128]
private theorem valid0_128 : scan 0 group0_128=true := combine size0_64 valid0_64 valid64_128
private def group128_256 : List Instr := group128_192 ++ group192_256
private theorem size128_256 : group128_256.length = 128 := by rw [group128_256,List.length_append,size128_192,size192_256]
private theorem valid128_256 : scan 128 group128_256=true := combine size128_192 valid128_192 valid192_256
private def group256_384 : List Instr := group256_320 ++ group320_384
private theorem size256_384 : group256_384.length = 128 := by rw [group256_384,List.length_append,size256_320,size320_384]
private theorem valid256_384 : scan 256 group256_384=true := combine size256_320 valid256_320 valid320_384
private def group384_512 : List Instr := group384_448 ++ group448_512
private theorem size384_512 : group384_512.length = 128 := by rw [group384_512,List.length_append,size384_448,size448_512]
private theorem valid384_512 : scan 384 group384_512=true := combine size384_448 valid384_448 valid448_512
private def group512_640 : List Instr := group512_576 ++ group576_640
private theorem size512_640 : group512_640.length = 128 := by rw [group512_640,List.length_append,size512_576,size576_640]
private theorem valid512_640 : scan 512 group512_640=true := combine size512_576 valid512_576 valid576_640
private def group640_768 : List Instr := group640_704 ++ group704_768
private theorem size640_768 : group640_768.length = 128 := by rw [group640_768,List.length_append,size640_704,size704_768]
private theorem valid640_768 : scan 640 group640_768=true := combine size640_704 valid640_704 valid704_768
private def group768_896 : List Instr := group768_832 ++ group832_896
private theorem size768_896 : group768_896.length = 128 := by rw [group768_896,List.length_append,size768_832,size832_896]
private theorem valid768_896 : scan 768 group768_896=true := combine size768_832 valid768_832 valid832_896
private def group896_1024 : List Instr := group896_960 ++ group960_1024
private theorem size896_1024 : group896_1024.length = 128 := by rw [group896_1024,List.length_append,size896_960,size960_1024]
private theorem valid896_1024 : scan 896 group896_1024=true := combine size896_960 valid896_960 valid960_1024
private def group1024_1152 : List Instr := group1024_1088 ++ group1088_1152
private theorem size1024_1152 : group1024_1152.length = 128 := by rw [group1024_1152,List.length_append,size1024_1088,size1088_1152]
private theorem valid1024_1152 : scan 1024 group1024_1152=true := combine size1024_1088 valid1024_1088 valid1088_1152
private def group1152_1280 : List Instr := group1152_1216 ++ group1216_1280
private theorem size1152_1280 : group1152_1280.length = 128 := by rw [group1152_1280,List.length_append,size1152_1216,size1216_1280]
private theorem valid1152_1280 : scan 1152 group1152_1280=true := combine size1152_1216 valid1152_1216 valid1216_1280
private def group1280_1408 : List Instr := group1280_1344 ++ group1344_1408
private theorem size1280_1408 : group1280_1408.length = 128 := by rw [group1280_1408,List.length_append,size1280_1344,size1344_1408]
private theorem valid1280_1408 : scan 1280 group1280_1408=true := combine size1280_1344 valid1280_1344 valid1344_1408
private def group1408_1536 : List Instr := group1408_1472 ++ group1472_1536
private theorem size1408_1536 : group1408_1536.length = 128 := by rw [group1408_1536,List.length_append,size1408_1472,size1472_1536]
private theorem valid1408_1536 : scan 1408 group1408_1536=true := combine size1408_1472 valid1408_1472 valid1472_1536
private def group1536_1664 : List Instr := group1536_1600 ++ group1600_1664
private theorem size1536_1664 : group1536_1664.length = 128 := by rw [group1536_1664,List.length_append,size1536_1600,size1600_1664]
private theorem valid1536_1664 : scan 1536 group1536_1664=true := combine size1536_1600 valid1536_1600 valid1600_1664
private def group1664_1792 : List Instr := group1664_1728 ++ group1728_1792
private theorem size1664_1792 : group1664_1792.length = 128 := by rw [group1664_1792,List.length_append,size1664_1728,size1728_1792]
private theorem valid1664_1792 : scan 1664 group1664_1792=true := combine size1664_1728 valid1664_1728 valid1728_1792
private def group1792_1920 : List Instr := group1792_1856 ++ group1856_1920
private theorem size1792_1920 : group1792_1920.length = 128 := by rw [group1792_1920,List.length_append,size1792_1856,size1856_1920]
private theorem valid1792_1920 : scan 1792 group1792_1920=true := combine size1792_1856 valid1792_1856 valid1856_1920
private def group1920_2048 : List Instr := group1920_1984 ++ group1984_2048
private theorem size1920_2048 : group1920_2048.length = 128 := by rw [group1920_2048,List.length_append,size1920_1984,size1984_2048]
private theorem valid1920_2048 : scan 1920 group1920_2048=true := combine size1920_1984 valid1920_1984 valid1984_2048
private def group2048_2176 : List Instr := group2048_2112 ++ group2112_2176
private theorem size2048_2176 : group2048_2176.length = 128 := by rw [group2048_2176,List.length_append,size2048_2112,size2112_2176]
private theorem valid2048_2176 : scan 2048 group2048_2176=true := combine size2048_2112 valid2048_2112 valid2112_2176
private def group2176_2304 : List Instr := group2176_2240 ++ group2240_2304
private theorem size2176_2304 : group2176_2304.length = 128 := by rw [group2176_2304,List.length_append,size2176_2240,size2240_2304]
private theorem valid2176_2304 : scan 2176 group2176_2304=true := combine size2176_2240 valid2176_2240 valid2240_2304
private def group2304_2432 : List Instr := group2304_2368 ++ group2368_2432
private theorem size2304_2432 : group2304_2432.length = 128 := by rw [group2304_2432,List.length_append,size2304_2368,size2368_2432]
private theorem valid2304_2432 : scan 2304 group2304_2432=true := combine size2304_2368 valid2304_2368 valid2368_2432
private def group2432_2560 : List Instr := group2432_2496 ++ group2496_2560
private theorem size2432_2560 : group2432_2560.length = 128 := by rw [group2432_2560,List.length_append,size2432_2496,size2496_2560]
private theorem valid2432_2560 : scan 2432 group2432_2560=true := combine size2432_2496 valid2432_2496 valid2496_2560
private def group2560_2688 : List Instr := group2560_2624 ++ group2624_2688
private theorem size2560_2688 : group2560_2688.length = 128 := by rw [group2560_2688,List.length_append,size2560_2624,size2624_2688]
private theorem valid2560_2688 : scan 2560 group2560_2688=true := combine size2560_2624 valid2560_2624 valid2624_2688
private def group2688_2816 : List Instr := group2688_2752 ++ group2752_2816
private theorem size2688_2816 : group2688_2816.length = 128 := by rw [group2688_2816,List.length_append,size2688_2752,size2752_2816]
private theorem valid2688_2816 : scan 2688 group2688_2816=true := combine size2688_2752 valid2688_2752 valid2752_2816
private def group2816_2944 : List Instr := group2816_2880 ++ group2880_2944
private theorem size2816_2944 : group2816_2944.length = 128 := by rw [group2816_2944,List.length_append,size2816_2880,size2880_2944]
private theorem valid2816_2944 : scan 2816 group2816_2944=true := combine size2816_2880 valid2816_2880 valid2880_2944
private def group2944_3072 : List Instr := group2944_3008 ++ group3008_3072
private theorem size2944_3072 : group2944_3072.length = 128 := by rw [group2944_3072,List.length_append,size2944_3008,size3008_3072]
private theorem valid2944_3072 : scan 2944 group2944_3072=true := combine size2944_3008 valid2944_3008 valid3008_3072
private def group0_256 : List Instr := group0_128 ++ group128_256
private theorem size0_256 : group0_256.length = 256 := by rw [group0_256,List.length_append,size0_128,size128_256]
private theorem valid0_256 : scan 0 group0_256=true := combine size0_128 valid0_128 valid128_256
private def group256_512 : List Instr := group256_384 ++ group384_512
private theorem size256_512 : group256_512.length = 256 := by rw [group256_512,List.length_append,size256_384,size384_512]
private theorem valid256_512 : scan 256 group256_512=true := combine size256_384 valid256_384 valid384_512
private def group512_768 : List Instr := group512_640 ++ group640_768
private theorem size512_768 : group512_768.length = 256 := by rw [group512_768,List.length_append,size512_640,size640_768]
private theorem valid512_768 : scan 512 group512_768=true := combine size512_640 valid512_640 valid640_768
private def group768_1024 : List Instr := group768_896 ++ group896_1024
private theorem size768_1024 : group768_1024.length = 256 := by rw [group768_1024,List.length_append,size768_896,size896_1024]
private theorem valid768_1024 : scan 768 group768_1024=true := combine size768_896 valid768_896 valid896_1024
private def group1024_1280 : List Instr := group1024_1152 ++ group1152_1280
private theorem size1024_1280 : group1024_1280.length = 256 := by rw [group1024_1280,List.length_append,size1024_1152,size1152_1280]
private theorem valid1024_1280 : scan 1024 group1024_1280=true := combine size1024_1152 valid1024_1152 valid1152_1280
private def group1280_1536 : List Instr := group1280_1408 ++ group1408_1536
private theorem size1280_1536 : group1280_1536.length = 256 := by rw [group1280_1536,List.length_append,size1280_1408,size1408_1536]
private theorem valid1280_1536 : scan 1280 group1280_1536=true := combine size1280_1408 valid1280_1408 valid1408_1536
private def group1536_1792 : List Instr := group1536_1664 ++ group1664_1792
private theorem size1536_1792 : group1536_1792.length = 256 := by rw [group1536_1792,List.length_append,size1536_1664,size1664_1792]
private theorem valid1536_1792 : scan 1536 group1536_1792=true := combine size1536_1664 valid1536_1664 valid1664_1792
private def group1792_2048 : List Instr := group1792_1920 ++ group1920_2048
private theorem size1792_2048 : group1792_2048.length = 256 := by rw [group1792_2048,List.length_append,size1792_1920,size1920_2048]
private theorem valid1792_2048 : scan 1792 group1792_2048=true := combine size1792_1920 valid1792_1920 valid1920_2048
private def group2048_2304 : List Instr := group2048_2176 ++ group2176_2304
private theorem size2048_2304 : group2048_2304.length = 256 := by rw [group2048_2304,List.length_append,size2048_2176,size2176_2304]
private theorem valid2048_2304 : scan 2048 group2048_2304=true := combine size2048_2176 valid2048_2176 valid2176_2304
private def group2304_2560 : List Instr := group2304_2432 ++ group2432_2560
private theorem size2304_2560 : group2304_2560.length = 256 := by rw [group2304_2560,List.length_append,size2304_2432,size2432_2560]
private theorem valid2304_2560 : scan 2304 group2304_2560=true := combine size2304_2432 valid2304_2432 valid2432_2560
private def group2560_2816 : List Instr := group2560_2688 ++ group2688_2816
private theorem size2560_2816 : group2560_2816.length = 256 := by rw [group2560_2816,List.length_append,size2560_2688,size2688_2816]
private theorem valid2560_2816 : scan 2560 group2560_2816=true := combine size2560_2688 valid2560_2688 valid2688_2816
private def group2816_3072 : List Instr := group2816_2944 ++ group2944_3072
private theorem size2816_3072 : group2816_3072.length = 256 := by rw [group2816_3072,List.length_append,size2816_2944,size2944_3072]
private theorem valid2816_3072 : scan 2816 group2816_3072=true := combine size2816_2944 valid2816_2944 valid2944_3072
private def group0_512 : List Instr := group0_256 ++ group256_512
private theorem size0_512 : group0_512.length = 512 := by rw [group0_512,List.length_append,size0_256,size256_512]
private theorem valid0_512 : scan 0 group0_512=true := combine size0_256 valid0_256 valid256_512
private def group512_1024 : List Instr := group512_768 ++ group768_1024
private theorem size512_1024 : group512_1024.length = 512 := by rw [group512_1024,List.length_append,size512_768,size768_1024]
private theorem valid512_1024 : scan 512 group512_1024=true := combine size512_768 valid512_768 valid768_1024
private def group1024_1536 : List Instr := group1024_1280 ++ group1280_1536
private theorem size1024_1536 : group1024_1536.length = 512 := by rw [group1024_1536,List.length_append,size1024_1280,size1280_1536]
private theorem valid1024_1536 : scan 1024 group1024_1536=true := combine size1024_1280 valid1024_1280 valid1280_1536
private def group1536_2048 : List Instr := group1536_1792 ++ group1792_2048
private theorem size1536_2048 : group1536_2048.length = 512 := by rw [group1536_2048,List.length_append,size1536_1792,size1792_2048]
private theorem valid1536_2048 : scan 1536 group1536_2048=true := combine size1536_1792 valid1536_1792 valid1792_2048
private def group2048_2560 : List Instr := group2048_2304 ++ group2304_2560
private theorem size2048_2560 : group2048_2560.length = 512 := by rw [group2048_2560,List.length_append,size2048_2304,size2304_2560]
private theorem valid2048_2560 : scan 2048 group2048_2560=true := combine size2048_2304 valid2048_2304 valid2304_2560
private def group2560_3072 : List Instr := group2560_2816 ++ group2816_3072
private theorem size2560_3072 : group2560_3072.length = 512 := by rw [group2560_3072,List.length_append,size2560_2816,size2816_3072]
private theorem valid2560_3072 : scan 2560 group2560_3072=true := combine size2560_2816 valid2560_2816 valid2816_3072
private def group0_1024 : List Instr := group0_512 ++ group512_1024
private theorem size0_1024 : group0_1024.length = 1024 := by rw [group0_1024,List.length_append,size0_512,size512_1024]
private theorem valid0_1024 : scan 0 group0_1024=true := combine size0_512 valid0_512 valid512_1024
private def group1024_2048 : List Instr := group1024_1536 ++ group1536_2048
private theorem size1024_2048 : group1024_2048.length = 1024 := by rw [group1024_2048,List.length_append,size1024_1536,size1536_2048]
private theorem valid1024_2048 : scan 1024 group1024_2048=true := combine size1024_1536 valid1024_1536 valid1536_2048
private def group2048_3072 : List Instr := group2048_2560 ++ group2560_3072
private theorem size2048_3072 : group2048_3072.length = 1024 := by rw [group2048_3072,List.length_append,size2048_2560,size2560_3072]
private theorem valid2048_3072 : scan 2048 group2048_3072=true := combine size2048_2560 valid2048_2560 valid2560_3072
private def group0_2048 : List Instr := group0_1024 ++ group1024_2048
private theorem size0_2048 : group0_2048.length = 2048 := by rw [group0_2048,List.length_append,size0_1024,size1024_2048]
private theorem valid0_2048 : scan 0 group0_2048=true := combine size0_1024 valid0_1024 valid1024_2048
private def group2048_3089 : List Instr := group2048_3072 ++ instructions3072
private theorem size2048_3089 : group2048_3089.length = 1041 := by rw [group2048_3089,List.length_append,size2048_3072,size3072_3089]
private theorem valid2048_3089 : scan 2048 group2048_3089=true := combine size2048_3072 valid2048_3072 valid3072_3089
private def group0_3089 : List Instr := group0_2048 ++ group2048_3089
private theorem size0_3089 : group0_3089.length = 3089 := by rw [group0_3089,List.length_append,size0_2048,size2048_3089]
private theorem valid0_3089 : scan 0 group0_3089=true := combine size0_2048 valid0_2048 valid2048_3089

private theorem allValid : scan 0 program=true := valid0_3089

theorem closed (p : Fin 3089) (op : Instr) (h : program[p.val]?=some op) (c z : Bool)
    (l : legal p.val c=true) (a : allowed op z=true) :
    next op z=4095 ∨ next op z<3089 ∧ legal (next op z) (cold' op c)=true := by
  have spec := scan_sound program 0 p.val op allValid h
  rw [Nat.zero_add] at spec
  exact spec c z l a

theorem instruction_at (p : Fin 3089) : ∃ op, program[p.val]?=some op := by
  have bound : p.val<program.length := by rw [program_length]; exact p.isLt
  exact ⟨program[p.val],List.getElem?_eq_getElem bound⟩

end PA192.PhysicalModel.TagClosure
#print axioms PA192.PhysicalModel.TagClosure.closed
#print axioms PA192.PhysicalModel.TagClosure.instruction_at
