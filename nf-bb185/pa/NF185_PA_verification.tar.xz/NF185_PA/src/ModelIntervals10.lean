module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site1942Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1942 f r x y z) (slots160.atReg 1945 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1942 3 1945 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1942 1945 1943 f r row1942)
    (slots160.pos_x 1942 1945 1943 f r row1942)
    (slots160.inc_y 1943 1944 f r row1943 (Or.inl (by decide)))
    (slots160.jump 1944 1942 f r row1944)

theorem site1942 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1942:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1945:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1942Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1945Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1945 f r x y z) (slots210.atReg 1948 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1945 3 1948 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1945 1948 1946 f r row1945)
    (slots210.pos_x 1945 1948 1946 f r row1945)
    (slots210.inc_y 1946 1947 f r row1946 (Or.inl (by decide)))
    (slots210.jump 1947 1945 f r row1947)

theorem site1945 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1945:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1948:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1945Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1948Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1948 f r x y z) (slots617.atReg 1958 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1948 10 1958 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1948 1952 1949 f r row1948)
    (slots617.pos_y 1948 1952 1949 f r row1948)
    (slots617.inc_z 1949 1950 f r row1949 (Or.inl (by decide)))
    (slots617.inc_x 1950 1951 f r row1950 (Or.inl (by decide)))
    (slots617.jump 1951 1948 f r row1951)
    (slots617.zero_x 1952 1958 1953 f r row1952)
    (slots617.pos_x 1952 1958 1953 f r row1952)
    (slots617.inc_z 1953 1954 f r row1953 (Or.inl (by decide)))
    (slots617.zero_x 1954 1957 1955 f r row1954)
    (slots617.pos_x 1954 1957 1955 f r row1954)
    (slots617.inc_y 1955 1956 f r row1955 (Or.inl (by decide)))
    (slots617.jump 1956 1954 f r row1956)
    (slots617.jump 1957 1948 f r row1957)

theorem site1948 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1948:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1958:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1948Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1958Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1958 f r x y z) (slots720.atReg 1961 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1958 3 1961 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1958 1961 1959 f r row1958)
    (slots720.pos_x 1958 1961 1959 f r row1958)
    (slots720.inc_y 1959 1960 f r row1959 (Or.inl (by decide)))
    (slots720.jump 1960 1958 f r row1960)

theorem site1958 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1958:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1961:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1958Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1961Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1961 f r x y z) (slots561.atReg 1965 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1961 4 1965 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1961 1965 1962 f r row1961)
    (slots561.pos_x 1961 1965 1962 f r row1961)
    (slots561.inc_y 1962 1963 f r row1962 (Or.inl (by decide)))
    (slots561.inc_z 1963 1964 f r row1963 (Or.inl (by decide)))
    (slots561.jump 1964 1961 f r row1964)

theorem site1961 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1961:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1965:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1961Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1965Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1965 f r x y z) (slots650.atReg 1968 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1965 3 1968 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1965 1968 1966 f r row1965)
    (slots650.pos_x 1965 1968 1966 f r row1965)
    (slots650.inc_y 1966 1967 f r row1966 (Or.inl (by decide)))
    (slots650.jump 1967 1965 f r row1967)

theorem site1965 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1965:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1968:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1965Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1968Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1968 f r x y z) (slots267.atReg 1976 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1968 8 1976 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1968 1976 1969 f r row1968)
    (slots267.pos_x 1968 1976 1969 f r row1968)
    (slots267.inc_z 1969 1970 f r row1969 (Or.inl (by decide)))
    (slots267.zero_y 1970 1972 1971 f r row1970)
    (slots267.pos_y 1970 1972 1971 f r row1970)
    (slots267.jump 1971 1975 f r row1971)
    (slots267.zero_z 1972 1975 1973 f r row1972)
    (slots267.pos_z 1972 1975 1973 f r row1972)
    (slots267.inc_y 1973 1974 f r row1973 (Or.inl (by decide)))
    (slots267.jump 1974 1972 f r row1974)
    (slots267.jump 1975 1968 f r row1975)

theorem site1968 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1968:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1976:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1968Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1976Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1976 f r x y z) (slots720.atReg 1979 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1976 3 1979 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1976 1979 1977 f r row1976)
    (slots720.pos_x 1976 1979 1977 f r row1976)
    (slots720.inc_y 1977 1978 f r row1977 (Or.inl (by decide)))
    (slots720.jump 1978 1976 f r row1978)

theorem site1976 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1976:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1979:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1976Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1979Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1979 f r x y z) (slots617.atReg 1989 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1979 10 1989 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1979 1983 1980 f r row1979)
    (slots617.pos_y 1979 1983 1980 f r row1979)
    (slots617.inc_z 1980 1981 f r row1980 (Or.inl (by decide)))
    (slots617.inc_x 1981 1982 f r row1981 (Or.inl (by decide)))
    (slots617.jump 1982 1979 f r row1982)
    (slots617.zero_x 1983 1989 1984 f r row1983)
    (slots617.pos_x 1983 1989 1984 f r row1983)
    (slots617.inc_z 1984 1985 f r row1984 (Or.inl (by decide)))
    (slots617.zero_x 1985 1988 1986 f r row1985)
    (slots617.pos_x 1985 1988 1986 f r row1985)
    (slots617.inc_y 1986 1987 f r row1986 (Or.inl (by decide)))
    (slots617.jump 1987 1985 f r row1987)
    (slots617.jump 1988 1979 f r row1988)

theorem site1979 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1979:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1989:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1979Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1989Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1989 f r x y z) (slots710.atReg 1993 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1989 4 1993 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1989 1993 1990 f r row1989)
    (slots710.pos_x 1989 1993 1990 f r row1989)
    (slots710.inc_y 1990 1991 f r row1990 (Or.inl (by decide)))
    (slots710.inc_y 1991 1992 f r row1991 (Or.inl (by decide)))
    (slots710.jump 1992 1989 f r row1992)

theorem site1989 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1989:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1993:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1989Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1993 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1993:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1994:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1993 _ row1993]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1994Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1994 f r x y z) (slots160.atReg 1997 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1994 3 1997 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1994 1997 1995 f r row1994)
    (slots160.pos_x 1994 1997 1995 f r row1994)
    (slots160.inc_y 1995 1996 f r row1995 (Or.inl (by decide)))
    (slots160.jump 1996 1994 f r row1996)

theorem site1994 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1994:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1997:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1994Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1997Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1997 f r x y z) (slots210.atReg 2000 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1997 3 2000 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1997 2000 1998 f r row1997)
    (slots210.pos_x 1997 2000 1998 f r row1997)
    (slots210.inc_y 1998 1999 f r row1998 (Or.inl (by decide)))
    (slots210.jump 1999 1997 f r row1999)

theorem site1997 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1997:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2000:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1997Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2000Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2000 f r x y z) (slots617.atReg 2010 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2000 10 2010 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2000 2004 2001 f r row2000)
    (slots617.pos_y 2000 2004 2001 f r row2000)
    (slots617.inc_z 2001 2002 f r row2001 (Or.inl (by decide)))
    (slots617.inc_x 2002 2003 f r row2002 (Or.inl (by decide)))
    (slots617.jump 2003 2000 f r row2003)
    (slots617.zero_x 2004 2010 2005 f r row2004)
    (slots617.pos_x 2004 2010 2005 f r row2004)
    (slots617.inc_z 2005 2006 f r row2005 (Or.inl (by decide)))
    (slots617.zero_x 2006 2009 2007 f r row2006)
    (slots617.pos_x 2006 2009 2007 f r row2006)
    (slots617.inc_y 2007 2008 f r row2007 (Or.inl (by decide)))
    (slots617.jump 2008 2006 f r row2008)
    (slots617.jump 2009 2000 f r row2009)

theorem site2000 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2000:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2010:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2000Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2010Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2010 f r x y z) (slots720.atReg 2013 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2010 3 2013 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2010 2013 2011 f r row2010)
    (slots720.pos_x 2010 2013 2011 f r row2010)
    (slots720.inc_y 2011 2012 f r row2011 (Or.inl (by decide)))
    (slots720.jump 2012 2010 f r row2012)

theorem site2010 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2010:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2013:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2010Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2013Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2013 f r x y z) (slots461.atReg 2017 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2013 4 2017 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2013 2017 2014 f r row2013)
    (slots461.pos_x 2013 2017 2014 f r row2013)
    (slots461.inc_y 2014 2015 f r row2014 (Or.inl (by decide)))
    (slots461.inc_z 2015 2016 f r row2015 (Or.inl (by decide)))
    (slots461.jump 2016 2013 f r row2016)

theorem site2013 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2013:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2017:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2013Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site2017Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2017 f r x y z) (slots640.atReg 2020 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2017 3 2020 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2017 2020 2018 f r row2017)
    (slots640.pos_x 2017 2020 2018 f r row2017)
    (slots640.inc_y 2018 2019 f r row2018 (Or.inl (by decide)))
    (slots640.jump 2019 2017 f r row2019)

theorem site2017 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2017:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2020:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2017Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site2020Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2020 f r x y z) (slots160.atReg 2023 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2020 3 2023 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2020 2023 2021 f r row2020)
    (slots160.pos_x 2020 2023 2021 f r row2020)
    (slots160.inc_y 2021 2022 f r row2021 (Or.inl (by decide)))
    (slots160.jump 2022 2020 f r row2022)

theorem site2020 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2020:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2023:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2020Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2023Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2023 f r x y z) (slots210.atReg 2026 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2023 3 2026 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2023 2026 2024 f r row2023)
    (slots210.pos_x 2023 2026 2024 f r row2023)
    (slots210.inc_y 2024 2025 f r row2024 (Or.inl (by decide)))
    (slots210.jump 2025 2023 f r row2025)

theorem site2023 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2023:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2026:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2023Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2026Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2026 f r x y z) (slots617.atReg 2036 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2026 10 2036 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2026 2030 2027 f r row2026)
    (slots617.pos_y 2026 2030 2027 f r row2026)
    (slots617.inc_z 2027 2028 f r row2027 (Or.inl (by decide)))
    (slots617.inc_x 2028 2029 f r row2028 (Or.inl (by decide)))
    (slots617.jump 2029 2026 f r row2029)
    (slots617.zero_x 2030 2036 2031 f r row2030)
    (slots617.pos_x 2030 2036 2031 f r row2030)
    (slots617.inc_z 2031 2032 f r row2031 (Or.inl (by decide)))
    (slots617.zero_x 2032 2035 2033 f r row2032)
    (slots617.pos_x 2032 2035 2033 f r row2032)
    (slots617.inc_y 2033 2034 f r row2033 (Or.inl (by decide)))
    (slots617.jump 2034 2032 f r row2034)
    (slots617.jump 2035 2026 f r row2035)

theorem site2026 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2026:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2036:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2026Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2036Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2036 f r x y z) (slots720.atReg 2039 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2036 3 2039 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2036 2039 2037 f r row2036)
    (slots720.pos_x 2036 2039 2037 f r row2036)
    (slots720.inc_y 2037 2038 f r row2037 (Or.inl (by decide)))
    (slots720.jump 2038 2036 f r row2038)

theorem site2036 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2036:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2039:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2036Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2039Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 2039 f r x y z) (slots361.atReg 2043 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 2039 4 2043 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 2039 2043 2040 f r row2039)
    (slots361.pos_x 2039 2043 2040 f r row2039)
    (slots361.inc_y 2040 2041 f r row2040 (Or.inl (by decide)))
    (slots361.inc_z 2041 2042 f r row2041 (Or.inl (by decide)))
    (slots361.jump 2042 2039 f r row2042)

theorem site2039 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2039:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2043:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site2039Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site2043Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 2043 f r x y z) (slots630.atReg 2046 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 2043 3 2046 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 2043 2046 2044 f r row2043)
    (slots630.pos_x 2043 2046 2044 f r row2043)
    (slots630.inc_y 2044 2045 f r row2044 (Or.inl (by decide)))
    (slots630.jump 2045 2043 f r row2045)

theorem site2043 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2043:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2046:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site2043Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site2046Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2046 f r x y z) (slots267.atReg 2054 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2046 8 2054 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2046 2054 2047 f r row2046)
    (slots267.pos_x 2046 2054 2047 f r row2046)
    (slots267.inc_z 2047 2048 f r row2047 (Or.inl (by decide)))
    (slots267.zero_y 2048 2050 2049 f r row2048)
    (slots267.pos_y 2048 2050 2049 f r row2048)
    (slots267.jump 2049 2053 f r row2049)
    (slots267.zero_z 2050 2053 2051 f r row2050)
    (slots267.pos_z 2050 2053 2051 f r row2050)
    (slots267.inc_y 2051 2052 f r row2051 (Or.inl (by decide)))
    (slots267.jump 2052 2050 f r row2052)
    (slots267.jump 2053 2046 f r row2053)

theorem site2046 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2046:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2054:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2046Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2054Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2054 f r x y z) (slots720.atReg 2057 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2054 3 2057 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2054 2057 2055 f r row2054)
    (slots720.pos_x 2054 2057 2055 f r row2054)
    (slots720.inc_y 2055 2056 f r row2055 (Or.inl (by decide)))
    (slots720.jump 2056 2054 f r row2056)

theorem site2054 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2054:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2057:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2054Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2057Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2057 f r x y z) (slots617.atReg 2067 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2057 10 2067 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2057 2061 2058 f r row2057)
    (slots617.pos_y 2057 2061 2058 f r row2057)
    (slots617.inc_z 2058 2059 f r row2058 (Or.inl (by decide)))
    (slots617.inc_x 2059 2060 f r row2059 (Or.inl (by decide)))
    (slots617.jump 2060 2057 f r row2060)
    (slots617.zero_x 2061 2067 2062 f r row2061)
    (slots617.pos_x 2061 2067 2062 f r row2061)
    (slots617.inc_z 2062 2063 f r row2062 (Or.inl (by decide)))
    (slots617.zero_x 2063 2066 2064 f r row2063)
    (slots617.pos_x 2063 2066 2064 f r row2063)
    (slots617.inc_y 2064 2065 f r row2064 (Or.inl (by decide)))
    (slots617.jump 2065 2063 f r row2065)
    (slots617.jump 2066 2057 f r row2066)

theorem site2057 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2057:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2067:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2057Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2067Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2067 f r x y z) (slots710.atReg 2071 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2067 4 2071 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2067 2071 2068 f r row2067)
    (slots710.pos_x 2067 2071 2068 f r row2067)
    (slots710.inc_y 2068 2069 f r row2068 (Or.inl (by decide)))
    (slots710.inc_y 2069 2070 f r row2069 (Or.inl (by decide)))
    (slots710.jump 2070 2067 f r row2070)

theorem site2067 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2067:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2071:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2067Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2071 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2071:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2072:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2071 _ row2071]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2072Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2072 f r x y z) (slots160.atReg 2075 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2072 3 2075 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2072 2075 2073 f r row2072)
    (slots160.pos_x 2072 2075 2073 f r row2072)
    (slots160.inc_y 2073 2074 f r row2073 (Or.inl (by decide)))
    (slots160.jump 2074 2072 f r row2074)

theorem site2072 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2072:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2075:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2072Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2075Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2075 f r x y z) (slots210.atReg 2078 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2075 3 2078 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2075 2078 2076 f r row2075)
    (slots210.pos_x 2075 2078 2076 f r row2075)
    (slots210.inc_y 2076 2077 f r row2076 (Or.inl (by decide)))
    (slots210.jump 2077 2075 f r row2077)

theorem site2075 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2075:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2078:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2075Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2078Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2078 f r x y z) (slots617.atReg 2088 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2078 10 2088 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2078 2082 2079 f r row2078)
    (slots617.pos_y 2078 2082 2079 f r row2078)
    (slots617.inc_z 2079 2080 f r row2079 (Or.inl (by decide)))
    (slots617.inc_x 2080 2081 f r row2080 (Or.inl (by decide)))
    (slots617.jump 2081 2078 f r row2081)
    (slots617.zero_x 2082 2088 2083 f r row2082)
    (slots617.pos_x 2082 2088 2083 f r row2082)
    (slots617.inc_z 2083 2084 f r row2083 (Or.inl (by decide)))
    (slots617.zero_x 2084 2087 2085 f r row2084)
    (slots617.pos_x 2084 2087 2085 f r row2084)
    (slots617.inc_y 2085 2086 f r row2085 (Or.inl (by decide)))
    (slots617.jump 2086 2084 f r row2086)
    (slots617.jump 2087 2078 f r row2087)

theorem site2078 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2078:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2088:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2078Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2088Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2088 f r x y z) (slots720.atReg 2091 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2088 3 2091 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2088 2091 2089 f r row2088)
    (slots720.pos_x 2088 2091 2089 f r row2088)
    (slots720.inc_y 2089 2090 f r row2089 (Or.inl (by decide)))
    (slots720.jump 2090 2088 f r row2090)

theorem site2088 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2088:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2091:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2088Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2091Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 2091 f r x y z) (slots361.atReg 2095 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 2091 4 2095 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 2091 2095 2092 f r row2091)
    (slots361.pos_x 2091 2095 2092 f r row2091)
    (slots361.inc_y 2092 2093 f r row2092 (Or.inl (by decide)))
    (slots361.inc_z 2093 2094 f r row2093 (Or.inl (by decide)))
    (slots361.jump 2094 2091 f r row2094)

theorem site2091 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2091:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2095:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site2091Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site2095Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 2095 f r x y z) (slots630.atReg 2098 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 2095 3 2098 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 2095 2098 2096 f r row2095)
    (slots630.pos_x 2095 2098 2096 f r row2095)
    (slots630.inc_y 2096 2097 f r row2096 (Or.inl (by decide)))
    (slots630.jump 2097 2095 f r row2097)

theorem site2095 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2095:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2098:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site2095Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site2098Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2098 f r x y z) (slots160.atReg 2101 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2098 3 2101 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2098 2101 2099 f r row2098)
    (slots160.pos_x 2098 2101 2099 f r row2098)
    (slots160.inc_y 2099 2100 f r row2099 (Or.inl (by decide)))
    (slots160.jump 2100 2098 f r row2100)

theorem site2098 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2098:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2101:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2098Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2101Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2101 f r x y z) (slots210.atReg 2104 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2101 3 2104 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2101 2104 2102 f r row2101)
    (slots210.pos_x 2101 2104 2102 f r row2101)
    (slots210.inc_y 2102 2103 f r row2102 (Or.inl (by decide)))
    (slots210.jump 2103 2101 f r row2103)

theorem site2101 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2101:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2104:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2101Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2104Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2104 f r x y z) (slots617.atReg 2114 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2104 10 2114 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2104 2108 2105 f r row2104)
    (slots617.pos_y 2104 2108 2105 f r row2104)
    (slots617.inc_z 2105 2106 f r row2105 (Or.inl (by decide)))
    (slots617.inc_x 2106 2107 f r row2106 (Or.inl (by decide)))
    (slots617.jump 2107 2104 f r row2107)
    (slots617.zero_x 2108 2114 2109 f r row2108)
    (slots617.pos_x 2108 2114 2109 f r row2108)
    (slots617.inc_z 2109 2110 f r row2109 (Or.inl (by decide)))
    (slots617.zero_x 2110 2113 2111 f r row2110)
    (slots617.pos_x 2110 2113 2111 f r row2110)
    (slots617.inc_y 2111 2112 f r row2111 (Or.inl (by decide)))
    (slots617.jump 2112 2110 f r row2112)
    (slots617.jump 2113 2104 f r row2113)

theorem site2104 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2104:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2114:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2104Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2114Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2114 f r x y z) (slots720.atReg 2117 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2114 3 2117 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2114 2117 2115 f r row2114)
    (slots720.pos_x 2114 2117 2115 f r row2114)
    (slots720.inc_y 2115 2116 f r row2115 (Or.inl (by decide)))
    (slots720.jump 2116 2114 f r row2116)

theorem site2114 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2114:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2117:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2114Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2117Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2117 f r x y z) (slots561.atReg 2121 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2117 4 2121 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2117 2121 2118 f r row2117)
    (slots561.pos_x 2117 2121 2118 f r row2117)
    (slots561.inc_y 2118 2119 f r row2118 (Or.inl (by decide)))
    (slots561.inc_z 2119 2120 f r row2119 (Or.inl (by decide)))
    (slots561.jump 2120 2117 f r row2120)

theorem site2117 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2117:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2121:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2117Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site2121Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2121 f r x y z) (slots650.atReg 2124 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2121 3 2124 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2121 2124 2122 f r row2121)
    (slots650.pos_x 2121 2124 2122 f r row2121)
    (slots650.inc_y 2122 2123 f r row2122 (Or.inl (by decide)))
    (slots650.jump 2123 2121 f r row2123)

theorem site2121 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2121:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2124:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2121Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site2124Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2124 f r x y z) (slots267.atReg 2132 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2124 8 2132 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2124 2132 2125 f r row2124)
    (slots267.pos_x 2124 2132 2125 f r row2124)
    (slots267.inc_z 2125 2126 f r row2125 (Or.inl (by decide)))
    (slots267.zero_y 2126 2128 2127 f r row2126)
    (slots267.pos_y 2126 2128 2127 f r row2126)
    (slots267.jump 2127 2131 f r row2127)
    (slots267.zero_z 2128 2131 2129 f r row2128)
    (slots267.pos_z 2128 2131 2129 f r row2128)
    (slots267.inc_y 2129 2130 f r row2129 (Or.inl (by decide)))
    (slots267.jump 2130 2128 f r row2130)
    (slots267.jump 2131 2124 f r row2131)

theorem site2124 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2124:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2132:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2124Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2132Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2132 f r x y z) (slots720.atReg 2135 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2132 3 2135 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2132 2135 2133 f r row2132)
    (slots720.pos_x 2132 2135 2133 f r row2132)
    (slots720.inc_y 2133 2134 f r row2133 (Or.inl (by decide)))
    (slots720.jump 2134 2132 f r row2134)

theorem site2132 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2132:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2135:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2132Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

end PA192.ModelSearch.RegisterSource.Certified
