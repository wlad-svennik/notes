module
public import ModelPackage
public import FrozenSite0000
public import FrozenSite0048
public import FrozenSite0096
public import FrozenSite0144
public import FrozenSite0192
public import FrozenSite0240
public import FrozenSite0288
public import FrozenSite0336
public import FrozenSite0384
public import FrozenSite0432
public import FrozenSite0480
public import FrozenSite0528
public import FrozenSite0576
public import FrozenSite0624
public import FrozenSite0672
public import FrozenSite0720
public import FrozenSite0768
public import FrozenSite0816
public import FrozenSite0864
public import FrozenSite0912
public import FrozenSite0960
public import FrozenSite1008
public import FrozenSite1056
public import FrozenSite1104
public import FrozenSite1152
public import FrozenSite1200
public import FrozenSite1248
public import FrozenSite1296
public import FrozenSite1344
public import FrozenSite1392
public import FrozenSite1440
public import FrozenSite1488
public import FrozenSite1536
public import FrozenSite1584
public import FrozenSite1632
public import FrozenSite1680
public import FrozenSite1728
public import FrozenSite1776
public import FrozenSite1824
public import FrozenSite1872
public import FrozenSite1920
public import FrozenSite1968
public import FrozenSite2016
public import FrozenSite2064
public import FrozenSite2112
public import FrozenSite2160
public import FrozenSite2208
public import FrozenSite2256
public import FrozenSite2304
public import FrozenSite2352
public import FrozenSite2400
public import FrozenSite2448
public import FrozenSite2496
public import FrozenSite2544
public import FrozenSite2592
public import FrozenSite2640
public import FrozenSite2688
public import FrozenSite2736
public import FrozenSite2784
public import FrozenSite2832
public import FrozenSite2880
public import FrozenSite2928
public import FrozenSite2976
public import FrozenSite3024
public import FrozenSite3072

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
namespace PA192.PhysicalModel.Frozen
open Replay PA192.ModelSearch
private theorem span0_96 : Scope 0 96 := scope_join 0 48 48 scope0000 scope0048
private theorem span96_192 : Scope 96 96 := scope_join 96 48 48 scope0096 scope0144
private theorem span0_192 : Scope 0 192 := scope_join 0 96 96 span0_96 span96_192
private theorem span192_288 : Scope 192 96 := scope_join 192 48 48 scope0192 scope0240
private theorem span288_384 : Scope 288 96 := scope_join 288 48 48 scope0288 scope0336
private theorem span192_384 : Scope 192 192 := scope_join 192 96 96 span192_288 span288_384
private theorem span0_384 : Scope 0 384 := scope_join 0 192 192 span0_192 span192_384
private theorem span384_480 : Scope 384 96 := scope_join 384 48 48 scope0384 scope0432
private theorem span480_576 : Scope 480 96 := scope_join 480 48 48 scope0480 scope0528
private theorem span384_576 : Scope 384 192 := scope_join 384 96 96 span384_480 span480_576
private theorem span576_672 : Scope 576 96 := scope_join 576 48 48 scope0576 scope0624
private theorem span672_768 : Scope 672 96 := scope_join 672 48 48 scope0672 scope0720
private theorem span576_768 : Scope 576 192 := scope_join 576 96 96 span576_672 span672_768
private theorem span384_768 : Scope 384 384 := scope_join 384 192 192 span384_576 span576_768
private theorem span0_768 : Scope 0 768 := scope_join 0 384 384 span0_384 span384_768
private theorem span768_864 : Scope 768 96 := scope_join 768 48 48 scope0768 scope0816
private theorem span864_960 : Scope 864 96 := scope_join 864 48 48 scope0864 scope0912
private theorem span768_960 : Scope 768 192 := scope_join 768 96 96 span768_864 span864_960
private theorem span960_1056 : Scope 960 96 := scope_join 960 48 48 scope0960 scope1008
private theorem span1056_1152 : Scope 1056 96 := scope_join 1056 48 48 scope1056 scope1104
private theorem span960_1152 : Scope 960 192 := scope_join 960 96 96 span960_1056 span1056_1152
private theorem span768_1152 : Scope 768 384 := scope_join 768 192 192 span768_960 span960_1152
private theorem span1152_1248 : Scope 1152 96 := scope_join 1152 48 48 scope1152 scope1200
private theorem span1248_1344 : Scope 1248 96 := scope_join 1248 48 48 scope1248 scope1296
private theorem span1152_1344 : Scope 1152 192 := scope_join 1152 96 96 span1152_1248 span1248_1344
private theorem span1344_1440 : Scope 1344 96 := scope_join 1344 48 48 scope1344 scope1392
private theorem span1440_1536 : Scope 1440 96 := scope_join 1440 48 48 scope1440 scope1488
private theorem span1344_1536 : Scope 1344 192 := scope_join 1344 96 96 span1344_1440 span1440_1536
private theorem span1152_1536 : Scope 1152 384 := scope_join 1152 192 192 span1152_1344 span1344_1536
private theorem span768_1536 : Scope 768 768 := scope_join 768 384 384 span768_1152 span1152_1536
private theorem span0_1536 : Scope 0 1536 := scope_join 0 768 768 span0_768 span768_1536
private theorem span1536_1632 : Scope 1536 96 := scope_join 1536 48 48 scope1536 scope1584
private theorem span1632_1728 : Scope 1632 96 := scope_join 1632 48 48 scope1632 scope1680
private theorem span1536_1728 : Scope 1536 192 := scope_join 1536 96 96 span1536_1632 span1632_1728
private theorem span1728_1824 : Scope 1728 96 := scope_join 1728 48 48 scope1728 scope1776
private theorem span1824_1920 : Scope 1824 96 := scope_join 1824 48 48 scope1824 scope1872
private theorem span1728_1920 : Scope 1728 192 := scope_join 1728 96 96 span1728_1824 span1824_1920
private theorem span1536_1920 : Scope 1536 384 := scope_join 1536 192 192 span1536_1728 span1728_1920
private theorem span1920_2016 : Scope 1920 96 := scope_join 1920 48 48 scope1920 scope1968
private theorem span2016_2112 : Scope 2016 96 := scope_join 2016 48 48 scope2016 scope2064
private theorem span1920_2112 : Scope 1920 192 := scope_join 1920 96 96 span1920_2016 span2016_2112
private theorem span2112_2208 : Scope 2112 96 := scope_join 2112 48 48 scope2112 scope2160
private theorem span2208_2304 : Scope 2208 96 := scope_join 2208 48 48 scope2208 scope2256
private theorem span2112_2304 : Scope 2112 192 := scope_join 2112 96 96 span2112_2208 span2208_2304
private theorem span1920_2304 : Scope 1920 384 := scope_join 1920 192 192 span1920_2112 span2112_2304
private theorem span1536_2304 : Scope 1536 768 := scope_join 1536 384 384 span1536_1920 span1920_2304
private theorem span2304_2400 : Scope 2304 96 := scope_join 2304 48 48 scope2304 scope2352
private theorem span2400_2496 : Scope 2400 96 := scope_join 2400 48 48 scope2400 scope2448
private theorem span2304_2496 : Scope 2304 192 := scope_join 2304 96 96 span2304_2400 span2400_2496
private theorem span2496_2592 : Scope 2496 96 := scope_join 2496 48 48 scope2496 scope2544
private theorem span2592_2688 : Scope 2592 96 := scope_join 2592 48 48 scope2592 scope2640
private theorem span2496_2688 : Scope 2496 192 := scope_join 2496 96 96 span2496_2592 span2592_2688
private theorem span2304_2688 : Scope 2304 384 := scope_join 2304 192 192 span2304_2496 span2496_2688
private theorem span2688_2784 : Scope 2688 96 := scope_join 2688 48 48 scope2688 scope2736
private theorem span2784_2880 : Scope 2784 96 := scope_join 2784 48 48 scope2784 scope2832
private theorem span2688_2880 : Scope 2688 192 := scope_join 2688 96 96 span2688_2784 span2784_2880
private theorem span2880_2976 : Scope 2880 96 := scope_join 2880 48 48 scope2880 scope2928
private theorem span3024_3089 : Scope 3024 65 := scope_join 3024 48 17 scope3024 scope3072
private theorem span2976_3089 : Scope 2976 113 := scope_join 2976 48 65 scope2976 span3024_3089
private theorem span2880_3089 : Scope 2880 209 := scope_join 2880 96 113 span2880_2976 span2976_3089
private theorem span2688_3089 : Scope 2688 401 := scope_join 2688 192 209 span2688_2880 span2880_3089
private theorem span2304_3089 : Scope 2304 785 := scope_join 2304 384 401 span2304_2688 span2688_3089
private theorem span1536_3089 : Scope 1536 1553 := scope_join 1536 768 785 span1536_2304 span2304_3089
private theorem span0_3089 : Scope 0 3089 := scope_join 0 1536 1553 span0_1536 span1536_3089
theorem all_original_sites : Scope 0 3089 := span0_3089
theorem executes_scanner {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] (n : V) (h : evalCode n=3) :
    ∃ t : V, state (rawRun NF192.Selected.machine NF192.Selected.start t)=192 :=
  executes_of_scope all_original_sites n h
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.all_original_sites
#print axioms PA192.PhysicalModel.Frozen.executes_scanner
