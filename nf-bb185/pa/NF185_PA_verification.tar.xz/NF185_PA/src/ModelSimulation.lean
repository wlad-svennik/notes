module
public import ModelTrace
public import ModelLiteralRegisters

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM
open PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000

/-- A definable boundary relation can carry arbitrary scratch margins and final tape values.
Only finitely many source program sites need verification for its one-step premise. -/
theorem simulate_registers (m : Machine n) (q : Fin n) (origin : V) (R : V → V → Prop)
    (dR : Language.DefinableRel ℒₒᵣ R)
    (boot : ∃t:V, R origin (rawRun m q t))
    (localRows : ∀e c:V, R e c → ∃ ticks:V, R (RegisterSource.step e) (iterate (rawStep m) ticks c)) :
    ∀j:V, ∃ t:V, R (RegisterSource.run j origin) (rawRun m q t) := by
  apply modelInduct
  · definability
  · simpa using boot
  · rintro j ⟨t,h⟩
    obtain ⟨ticks,hits⟩ := localRows _ _ h
    refine ⟨t+ticks,?_⟩
    simpa only [RegisterSource.run_succ,rawRun,iterate_add] using hits

/-- Native all-model instantiation of the forward compiler route at the cold physical margin. -/
theorem margin_implies_h192 (R : V → V → Prop) (dR : Language.DefinableRel ℒₒᵣ R)
    (boot : ∃t:V, R RegisterSource.coldMargin (rawRun NF192.Selected.machine NF192.Selected.start t))
    (localRows : ∀e c:V, R e c → ∃ t:V,
      R (RegisterSource.step e) (iterate (rawStep NF192.Selected.machine) t c))
    (terminal : ∀e c:V, R e c → RegisterSource.address e=4095 → state c=192)
    (source : RegisterSource.sourceHalts (RegisterSource.coldMargin:V)) : V ⊧/![] H192 := by
  obtain ⟨j,endAt⟩ := source
  obtain ⟨t,r⟩ := simulate_registers _ _ _ R dR boot localRows j
  exact h192_iff_model_run.mpr ⟨t,terminal _ _ r endAt⟩

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.margin_implies_h192
