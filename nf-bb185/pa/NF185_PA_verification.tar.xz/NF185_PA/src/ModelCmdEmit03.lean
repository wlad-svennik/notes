module
public import ModelCmdEmit02
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter97 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((515:Nat):V) f (vector n (v+y) (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0512 f n (v+y) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w) w
  have d2 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter96 f n t s c u v y d w).trans mid

theorem commandEmitAfter98 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((525:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 (atom19 n t s c u v y d w) w)) := by
  have micro := site0515 f n (v+y) (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (v+y)):V)=atom19 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (v+y)):V)=0+(atom19 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter97 f n t s c u v y d w).trans mid

theorem commandEmitAfter99 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((529:Nat):V) f (vector n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0525 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 (atom19 n t s c u v y d w) w
  have d1 : (0+(2*(atom19 n t s c u v y d w)):V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom19 n t s c u v y d w)):V)=0+((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter98 f n t s c u v y d w).trans mid

theorem commandEmitAfter100 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((530:Nat):V) f (vector n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0529 f n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w))+1:V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter99 f n t s c u v y d w).trans mid

theorem commandEmitAfter101 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((533:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0530 f n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1):V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter100 f n t s c u v y d w).trans mid

theorem commandEmitAfter102 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((536:Nat):V) f (vector n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0533 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter101 f n t s c u v y d w).trans mid

theorem commandEmitAfter103 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((546:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom20 n t s c u v y d w) w)) := by
  have micro := site0536 f n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w)):V)=atom20 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w)):V)=0+(atom20 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter102 f n t s c u v y d w).trans mid

theorem commandEmitAfter104 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((549:Nat):V) f (vector n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0546 f n 0 0 c (d+u) (v+y) 0 (atom20 n t s c u v y d w) w
  have d2 : (0+(atom20 n t s c u v y d w):V)=atom20 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter103 f n t s c u v y d w).trans mid

theorem commandEmitAfter105 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((550:Nat):V) f (vector n 1 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0549 f n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+1:V)=1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter104 f n t s c u v y d w).trans mid

theorem commandEmitAfter106 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((553:Nat):V) f (vector n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 1 0 w)) := by
  have micro := site0550 f n 1 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+1:V)=1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter105 f n t s c u v y d w).trans mid

theorem commandEmitAfter107 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((556:Nat):V) f (vector n (atom20 n t s c u v y d w) 0 c (d+u) (v+y) 1 0 w)) := by
  have micro := site0553 f n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 1 0 w
  have d1 : (0+(atom20 n t s c u v y d w):V)=atom20 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter106 f n t s c u v y d w).trans mid

theorem commandEmitAfter108 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((566:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom21 n t s c u v y d w) w)) := by
  have micro := site0556 f n (atom20 n t s c u v y d w) 0 c (d+u) (v+y) 1 0 w
  have d7 : (0+(cantor 1 (atom20 n t s c u v y d w)):V)=atom21 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 1 (atom20 n t s c u v y d w)):V)=0+(atom21 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter107 f n t s c u v y d w).trans mid

theorem commandEmitAfter109 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((569:Nat):V) f (vector n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0566 f n 0 0 c (d+u) (v+y) 0 (atom21 n t s c u v y d w) w
  have d2 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter108 f n t s c u v y d w).trans mid

theorem commandEmitAfter110 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((572:Nat):V) f (vector n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0569 f n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+0:V)=0 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter109 f n t s c u v y d w).trans mid

theorem commandEmitAfter111 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((575:Nat):V) f (vector n (atom21 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w)) := by
  have micro := site0572 f n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter110 f n t s c u v y d w).trans mid

theorem commandEmitAfter112 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((585:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom22 n t s c u v y d w) w)) := by
  have micro := site0575 f n (atom21 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w
  have d7 : (0+(cantor 0 (atom21 n t s c u v y d w)):V)=atom22 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 0 (atom21 n t s c u v y d w)):V)=0+(atom22 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter111 f n t s c u v y d w).trans mid

theorem commandEmitAfter113 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((588:Nat):V) f (vector n 0 (atom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0585 f n 0 0 c (d+u) (v+y) 0 (atom22 n t s c u v y d w) w
  have d2 : (0+(atom22 n t s c u v y d w):V)=atom22 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter112 f n t s c u v y d w).trans mid

theorem commandEmitAfter114 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((592:Nat):V) f (vector n (d+u) (atom22 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0588 f n 0 (atom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter113 f n t s c u v y d w).trans mid

theorem commandEmitAfter115 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((595:Nat):V) f (vector n (d+u) (atom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0592 f n (d+u) (atom22 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter114 f n t s c u v y d w).trans mid

theorem commandEmitAfter116 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((603:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) 0 (atom21 n t s c u v y d w) w)) := by
  have micro := site0595 f n (d+u) (atom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom22 n t s c u v y d w)):V)=0 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom22 n t s c u v y d w):V)=0+(atom22 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom22 n t s c u v y d w)):V)=left (atom22 n t s c u v y d w)).trans (by change left (cantor 0 (atom21 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom22 n t s c u v y d w)):V)=atom21 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom22 n t s c u v y d w):V)=0+(atom22 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom22 n t s c u v y d w)):V)=right (atom22 n t s c u v y d w)).trans (by change right (cantor 0 (atom21 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter115 f n t s c u v y d w).trans mid

theorem commandEmitAfter117 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((606:Nat):V) f (vector n (d+u) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0603 f n (d+u) 0 c (d+u) (v+y) 0 (atom21 n t s c u v y d w) w
  have d2 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter116 f n t s c u v y d w).trans mid

theorem commandEmitAfter118 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((616:Nat):V) f (vector n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 (atom23 n t s c u v y d w) w)) := by
  have micro := site0606 f n (d+u) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d7 : (0+(cantor 0 (d+u)):V)=atom23 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 0 (d+u)):V)=0+(atom23 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter117 f n t s c u v y d w).trans mid

theorem commandEmitAfter119 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((620:Nat):V) f (vector n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0616 f n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 (atom23 n t s c u v y d w) w
  have d1 : (0+(2*(atom23 n t s c u v y d w)):V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom23 n t s c u v y d w)):V)=0+((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter118 f n t s c u v y d w).trans mid

theorem commandEmitAfter120 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((621:Nat):V) f (vector n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0620 f n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w))+1:V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter119 f n t s c u v y d w).trans mid

theorem commandEmitAfter121 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((624:Nat):V) f (vector n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0621 f n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1):V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter120 f n t s c u v y d w).trans mid

theorem commandEmitAfter122 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((627:Nat):V) f (vector n (atom21 n t s c u v y d w) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0624 f n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter121 f n t s c u v y d w).trans mid

theorem commandEmitAfter123 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((637:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom24 n t s c u v y d w) w)) := by
  have micro := site0627 f n (atom21 n t s c u v y d w) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w)):V)=atom24 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w)):V)=0+(atom24 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter122 f n t s c u v y d w).trans mid

theorem commandEmitAfter124 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((640:Nat):V) f (vector n 0 (atom24 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0637 f n 0 0 c (d+u) (v+y) 0 (atom24 n t s c u v y d w) w
  have d2 : (0+(atom24 n t s c u v y d w):V)=atom24 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter123 f n t s c u v y d w).trans mid

theorem commandEmitAfter125 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((644:Nat):V) f (vector n (v+y) (atom24 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0640 f n 0 (atom24 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter124 f n t s c u v y d w).trans mid

theorem commandEmitAfter126 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((647:Nat):V) f (vector n (v+y) (atom24 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0644 f n (v+y) (atom24 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter125 f n t s c u v y d w).trans mid

theorem commandEmitAfter127 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((655:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w) w)) := by
  have micro := site0647 f n (v+y) (atom24 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom24 n t s c u v y d w)):V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom24 n t s c u v y d w):V)=0+(atom24 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom24 n t s c u v y d w)):V)=left (atom24 n t s c u v y d w)).trans (by change left (cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom24 n t s c u v y d w)):V)=atom21 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom24 n t s c u v y d w):V)=0+(atom24 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom24 n t s c u v y d w)):V)=right (atom24 n t s c u v y d w)).trans (by change right (cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter126 f n t s c u v y d w).trans mid

theorem commandEmitAfter128 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((658:Nat):V) f (vector n (v+y) (atom21 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0655 f n (v+y) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w) w
  have d2 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter127 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
