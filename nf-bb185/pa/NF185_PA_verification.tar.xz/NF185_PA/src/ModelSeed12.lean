module
public import ModelSeed11
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter385 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1863:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1859 f n 0 (atom63 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter384 f n t s c u v y d w).trans mid

theorem seedEmitAfter386 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1864:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1863 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter385 f n t s c u v y d w).trans mid

theorem seedEmitAfter387 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1872:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) (atom59 n t s c u v y d w) w)) := by
  have micro := site1864 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom63 n t s c u v y d w)):V)=(atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom63 n t s c u v y d w):V)=0+(atom63 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom63 n t s c u v y d w)):V)=left (atom63 n t s c u v y d w)).trans (by change left (cantor ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) (atom59 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom63 n t s c u v y d w)):V)=atom59 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom63 n t s c u v y d w):V)=0+(atom63 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom63 n t s c u v y d w)):V)=right (atom63 n t s c u v y d w)).trans (by change right (cantor ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) (atom59 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter386 f n t s c u v y d w).trans mid

theorem seedEmitAfter388 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1875:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom59 n t s c u v y d w) c (d+u) (v+y) ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1872 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) (atom59 n t s c u v y d w) w
  have d2 : (0+(atom59 n t s c u v y d w):V)=atom59 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter387 f n t s c u v y d w).trans mid

theorem seedEmitAfter389 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1885:Nat):V) f (vector n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) 0 (atom65 n t s c u v y d w) w)) := by
  have micro := site1875 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom59 n t s c u v y d w) c (d+u) (v+y) ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=atom65 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=0+(atom65 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter388 f n t s c u v y d w).trans mid

theorem seedEmitAfter390 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1889:Nat):V) f (vector n ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)) (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1885 f n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) 0 (atom65 n t s c u v y d w) w
  have d1 : (0+(2*(atom65 n t s c u v y d w)):V)=(atom65 n t s c u v y d w)+(atom65 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom65 n t s c u v y d w)):V)=0+((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter389 f n t s c u v y d w).trans mid

theorem seedEmitAfter391 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1890:Nat):V) f (vector n ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1) (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1889 f n ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)) (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w))+1:V)=(atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter390 f n t s c u v y d w).trans mid

theorem seedEmitAfter392 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1898:Nat):V) f (vector n ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) (atom52 n t s c u v y d w) w)) := by
  have micro := site1890 f n ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1) (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom59 n t s c u v y d w)):V)=(atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom59 n t s c u v y d w):V)=0+(atom59 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom59 n t s c u v y d w)):V)=left (atom59 n t s c u v y d w)).trans (by change left (cantor ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) (atom52 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom59 n t s c u v y d w)):V)=atom52 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom59 n t s c u v y d w):V)=0+(atom59 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom59 n t s c u v y d w)):V)=right (atom59 n t s c u v y d w)).trans (by change right (cantor ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) (atom52 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter391 f n t s c u v y d w).trans mid

theorem seedEmitAfter393 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1901:Nat):V) f (vector n ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1898 f n ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) (atom52 n t s c u v y d w) w
  have d2 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter392 f n t s c u v y d w).trans mid

theorem seedEmitAfter394 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1911:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 (atom66 n t s c u v y d w) w)) := by
  have micro := site1901 f n ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1)):V)=atom66 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1)):V)=0+(atom66 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter393 f n t s c u v y d w).trans mid

theorem seedEmitAfter395 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1915:Nat):V) f (vector n ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1911 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 (atom66 n t s c u v y d w) w
  have d1 : (0+(2*(atom66 n t s c u v y d w)):V)=(atom66 n t s c u v y d w)+(atom66 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom66 n t s c u v y d w)):V)=0+((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter394 f n t s c u v y d w).trans mid

theorem seedEmitAfter396 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1916:Nat):V) f (vector n ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1915 f n ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w))+1:V)=(atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter395 f n t s c u v y d w).trans mid

theorem seedEmitAfter397 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1919:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1916 f n ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1):V)=(atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter396 f n t s c u v y d w).trans mid

theorem seedEmitAfter398 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1922:Nat):V) f (vector n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1919 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter397 f n t s c u v y d w).trans mid

theorem seedEmitAfter399 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1932:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom67 n t s c u v y d w) w)) := by
  have micro := site1922 f n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1) (atom52 n t s c u v y d w)):V)=atom67 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1) (atom52 n t s c u v y d w)):V)=0+(atom67 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter398 f n t s c u v y d w).trans mid

theorem seedEmitAfter400 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1935:Nat):V) f (vector n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1932 f n 0 0 c (d+u) (v+y) 0 (atom67 n t s c u v y d w) w
  have d2 : (0+(atom67 n t s c u v y d w):V)=atom67 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter399 f n t s c u v y d w).trans mid

theorem seedEmitAfter401 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1939:Nat):V) f (vector n (d+u) (atom67 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1935 f n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter400 f n t s c u v y d w).trans mid

theorem seedEmitAfter402 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1942:Nat):V) f (vector n (d+u) (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1939 f n (d+u) (atom67 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter401 f n t s c u v y d w).trans mid

theorem seedEmitAfter403 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1945:Nat):V) f (vector n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1942 f n (d+u) (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter402 f n t s c u v y d w).trans mid

theorem seedEmitAfter404 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1948:Nat):V) f (vector n (atom67 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1945 f n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom67 n t s c u v y d w):V)=atom67 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter403 f n t s c u v y d w).trans mid

theorem seedEmitAfter405 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1958:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom68 n t s c u v y d w) w)) := by
  have micro := site1948 f n (atom67 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom67 n t s c u v y d w)):V)=atom68 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom67 n t s c u v y d w)):V)=0+(atom68 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter404 f n t s c u v y d w).trans mid

theorem seedEmitAfter406 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1961:Nat):V) f (vector n 0 (atom68 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1958 f n 0 0 c (d+u) (v+y) 0 (atom68 n t s c u v y d w) w
  have d2 : (0+(atom68 n t s c u v y d w):V)=atom68 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter405 f n t s c u v y d w).trans mid

theorem seedEmitAfter407 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1965:Nat):V) f (vector n (v+y) (atom68 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1961 f n 0 (atom68 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter406 f n t s c u v y d w).trans mid

theorem seedEmitAfter408 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1968:Nat):V) f (vector n (v+y) (atom68 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1965 f n (v+y) (atom68 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter407 f n t s c u v y d w).trans mid

theorem seedEmitAfter409 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1976:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom67 n t s c u v y d w) w)) := by
  have micro := site1968 f n (v+y) (atom68 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom68 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom68 n t s c u v y d w):V)=0+(atom68 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom68 n t s c u v y d w)):V)=left (atom68 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom67 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom68 n t s c u v y d w)):V)=atom67 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom68 n t s c u v y d w):V)=0+(atom68 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom68 n t s c u v y d w)):V)=right (atom68 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom67 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter408 f n t s c u v y d w).trans mid

theorem seedEmitAfter410 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1979:Nat):V) f (vector n (v+y) (atom67 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1976 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom67 n t s c u v y d w) w
  have d2 : (0+(atom67 n t s c u v y d w):V)=atom67 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter409 f n t s c u v y d w).trans mid

theorem seedEmitAfter411 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1989:Nat):V) f (vector n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site1979 f n (v+y) (atom67 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter410 f n t s c u v y d w).trans mid

theorem seedEmitAfter412 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1993:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1989 f n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter411 f n t s c u v y d w).trans mid

theorem seedEmitAfter413 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1994:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1993 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter412 f n t s c u v y d w).trans mid

theorem seedEmitAfter414 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1997:Nat):V) f (vector n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1994 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter413 f n t s c u v y d w).trans mid

theorem seedEmitAfter415 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2000:Nat):V) f (vector n (atom67 n t s c u v y d w) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1997 f n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom67 n t s c u v y d w):V)=atom67 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter414 f n t s c u v y d w).trans mid

theorem seedEmitAfter416 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2010:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom69 n t s c u v y d w) w)) := by
  have micro := site2000 f n (atom67 n t s c u v y d w) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom67 n t s c u v y d w)):V)=atom69 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom67 n t s c u v y d w)):V)=0+(atom69 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter415 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
