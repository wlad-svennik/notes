module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site1364Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1364 f r x y z) (slots720.atReg 1367 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1364 3 1367 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1364 1367 1365 f r row1364)
    (slots720.pos_x 1364 1367 1365 f r row1364)
    (slots720.inc_y 1365 1366 f r row1365 (Or.inl (by decide)))
    (slots720.jump 1366 1364 f r row1366)

theorem site1364 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1364:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1367:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1364Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1367Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1367 f r x y z) (slots461.atReg 1371 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1367 4 1371 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1367 1371 1368 f r row1367)
    (slots461.pos_x 1367 1371 1368 f r row1367)
    (slots461.inc_y 1368 1369 f r row1368 (Or.inl (by decide)))
    (slots461.inc_z 1369 1370 f r row1369 (Or.inl (by decide)))
    (slots461.jump 1370 1367 f r row1370)

theorem site1367 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1367:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1371:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1367Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site1371Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1371 f r x y z) (slots640.atReg 1374 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1371 3 1374 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1371 1374 1372 f r row1371)
    (slots640.pos_x 1371 1374 1372 f r row1371)
    (slots640.inc_y 1372 1373 f r row1372 (Or.inl (by decide)))
    (slots640.jump 1373 1371 f r row1373)

theorem site1371 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1371:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1374:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1371Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site1374Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1374 f r x y z) (slots160.atReg 1377 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1374 3 1377 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1374 1377 1375 f r row1374)
    (slots160.pos_x 1374 1377 1375 f r row1374)
    (slots160.inc_y 1375 1376 f r row1375 (Or.inl (by decide)))
    (slots160.jump 1376 1374 f r row1376)

theorem site1374 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1374:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1377:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1374Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1377Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1377 f r x y z) (slots210.atReg 1380 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1377 3 1380 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1377 1380 1378 f r row1377)
    (slots210.pos_x 1377 1380 1378 f r row1377)
    (slots210.inc_y 1378 1379 f r row1378 (Or.inl (by decide)))
    (slots210.jump 1379 1377 f r row1379)

theorem site1377 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1377:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1380:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1377Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1380Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1380 f r x y z) (slots617.atReg 1390 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1380 10 1390 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1380 1384 1381 f r row1380)
    (slots617.pos_y 1380 1384 1381 f r row1380)
    (slots617.inc_z 1381 1382 f r row1381 (Or.inl (by decide)))
    (slots617.inc_x 1382 1383 f r row1382 (Or.inl (by decide)))
    (slots617.jump 1383 1380 f r row1383)
    (slots617.zero_x 1384 1390 1385 f r row1384)
    (slots617.pos_x 1384 1390 1385 f r row1384)
    (slots617.inc_z 1385 1386 f r row1385 (Or.inl (by decide)))
    (slots617.zero_x 1386 1389 1387 f r row1386)
    (slots617.pos_x 1386 1389 1387 f r row1386)
    (slots617.inc_y 1387 1388 f r row1387 (Or.inl (by decide)))
    (slots617.jump 1388 1386 f r row1388)
    (slots617.jump 1389 1380 f r row1389)

theorem site1380 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1380:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1390:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1380Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1390Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1390 f r x y z) (slots720.atReg 1393 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1390 3 1393 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1390 1393 1391 f r row1390)
    (slots720.pos_x 1390 1393 1391 f r row1390)
    (slots720.inc_y 1391 1392 f r row1391 (Or.inl (by decide)))
    (slots720.jump 1392 1390 f r row1392)

theorem site1390 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1390:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1393:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1390Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1393Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1393 f r x y z) (slots561.atReg 1397 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1393 4 1397 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1393 1397 1394 f r row1393)
    (slots561.pos_x 1393 1397 1394 f r row1393)
    (slots561.inc_y 1394 1395 f r row1394 (Or.inl (by decide)))
    (slots561.inc_z 1395 1396 f r row1395 (Or.inl (by decide)))
    (slots561.jump 1396 1393 f r row1396)

theorem site1393 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1393:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1397:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1393Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1397Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1397 f r x y z) (slots650.atReg 1400 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1397 3 1400 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1397 1400 1398 f r row1397)
    (slots650.pos_x 1397 1400 1398 f r row1397)
    (slots650.inc_y 1398 1399 f r row1398 (Or.inl (by decide)))
    (slots650.jump 1399 1397 f r row1399)

theorem site1397 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1397:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1400:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1397Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1400Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1400 f r x y z) (slots267.atReg 1408 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1400 8 1408 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1400 1408 1401 f r row1400)
    (slots267.pos_x 1400 1408 1401 f r row1400)
    (slots267.inc_z 1401 1402 f r row1401 (Or.inl (by decide)))
    (slots267.zero_y 1402 1404 1403 f r row1402)
    (slots267.pos_y 1402 1404 1403 f r row1402)
    (slots267.jump 1403 1407 f r row1403)
    (slots267.zero_z 1404 1407 1405 f r row1404)
    (slots267.pos_z 1404 1407 1405 f r row1404)
    (slots267.inc_y 1405 1406 f r row1405 (Or.inl (by decide)))
    (slots267.jump 1406 1404 f r row1406)
    (slots267.jump 1407 1400 f r row1407)

theorem site1400 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1400:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1408:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1400Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1408Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1408 f r x y z) (slots720.atReg 1411 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1408 3 1411 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1408 1411 1409 f r row1408)
    (slots720.pos_x 1408 1411 1409 f r row1408)
    (slots720.inc_y 1409 1410 f r row1409 (Or.inl (by decide)))
    (slots720.jump 1410 1408 f r row1410)

theorem site1408 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1408:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1411:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1408Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1411Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1411 f r x y z) (slots617.atReg 1421 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1411 10 1421 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1411 1415 1412 f r row1411)
    (slots617.pos_y 1411 1415 1412 f r row1411)
    (slots617.inc_z 1412 1413 f r row1412 (Or.inl (by decide)))
    (slots617.inc_x 1413 1414 f r row1413 (Or.inl (by decide)))
    (slots617.jump 1414 1411 f r row1414)
    (slots617.zero_x 1415 1421 1416 f r row1415)
    (slots617.pos_x 1415 1421 1416 f r row1415)
    (slots617.inc_z 1416 1417 f r row1416 (Or.inl (by decide)))
    (slots617.zero_x 1417 1420 1418 f r row1417)
    (slots617.pos_x 1417 1420 1418 f r row1417)
    (slots617.inc_y 1418 1419 f r row1418 (Or.inl (by decide)))
    (slots617.jump 1419 1417 f r row1419)
    (slots617.jump 1420 1411 f r row1420)

theorem site1411 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1411:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1421:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1411Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1421Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1421 f r x y z) (slots710.atReg 1425 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1421 4 1425 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1421 1425 1422 f r row1421)
    (slots710.pos_x 1421 1425 1422 f r row1421)
    (slots710.inc_y 1422 1423 f r row1422 (Or.inl (by decide)))
    (slots710.inc_y 1423 1424 f r row1423 (Or.inl (by decide)))
    (slots710.jump 1424 1421 f r row1424)

theorem site1421 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1421:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1425:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1421Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1425 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1425:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1426:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1425 _ row1425]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1426Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1426 f r x y z) (slots267.atReg 1434 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1426 8 1434 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1426 1434 1427 f r row1426)
    (slots267.pos_x 1426 1434 1427 f r row1426)
    (slots267.inc_z 1427 1428 f r row1427 (Or.inl (by decide)))
    (slots267.zero_y 1428 1430 1429 f r row1428)
    (slots267.pos_y 1428 1430 1429 f r row1428)
    (slots267.jump 1429 1433 f r row1429)
    (slots267.zero_z 1430 1433 1431 f r row1430)
    (slots267.pos_z 1430 1433 1431 f r row1430)
    (slots267.inc_y 1431 1432 f r row1431 (Or.inl (by decide)))
    (slots267.jump 1432 1430 f r row1432)
    (slots267.jump 1433 1426 f r row1433)

theorem site1426 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1426:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1434:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1426Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1434Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1434 f r x y z) (slots720.atReg 1437 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1434 3 1437 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1434 1437 1435 f r row1434)
    (slots720.pos_x 1434 1437 1435 f r row1434)
    (slots720.inc_y 1435 1436 f r row1435 (Or.inl (by decide)))
    (slots720.jump 1436 1434 f r row1436)

theorem site1434 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1434:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1437:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1434Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1437Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1437 f r x y z) (slots617.atReg 1447 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1437 10 1447 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1437 1441 1438 f r row1437)
    (slots617.pos_y 1437 1441 1438 f r row1437)
    (slots617.inc_z 1438 1439 f r row1438 (Or.inl (by decide)))
    (slots617.inc_x 1439 1440 f r row1439 (Or.inl (by decide)))
    (slots617.jump 1440 1437 f r row1440)
    (slots617.zero_x 1441 1447 1442 f r row1441)
    (slots617.pos_x 1441 1447 1442 f r row1441)
    (slots617.inc_z 1442 1443 f r row1442 (Or.inl (by decide)))
    (slots617.zero_x 1443 1446 1444 f r row1443)
    (slots617.pos_x 1443 1446 1444 f r row1443)
    (slots617.inc_y 1444 1445 f r row1444 (Or.inl (by decide)))
    (slots617.jump 1445 1443 f r row1445)
    (slots617.jump 1446 1437 f r row1446)

theorem site1437 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1437:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1447:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1437Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1447Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1447 f r x y z) (slots710.atReg 1451 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1447 4 1451 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1447 1451 1448 f r row1447)
    (slots710.pos_x 1447 1451 1448 f r row1447)
    (slots710.inc_y 1448 1449 f r row1448 (Or.inl (by decide)))
    (slots710.inc_y 1449 1450 f r row1449 (Or.inl (by decide)))
    (slots710.jump 1450 1447 f r row1450)

theorem site1447 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1447:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1451:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1447Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1451 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1451:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1452:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1451 _ row1451]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1452Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1452 f r x y z) (slots267.atReg 1460 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1452 8 1460 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1452 1460 1453 f r row1452)
    (slots267.pos_x 1452 1460 1453 f r row1452)
    (slots267.inc_z 1453 1454 f r row1453 (Or.inl (by decide)))
    (slots267.zero_y 1454 1456 1455 f r row1454)
    (slots267.pos_y 1454 1456 1455 f r row1454)
    (slots267.jump 1455 1459 f r row1455)
    (slots267.zero_z 1456 1459 1457 f r row1456)
    (slots267.pos_z 1456 1459 1457 f r row1456)
    (slots267.inc_y 1457 1458 f r row1457 (Or.inl (by decide)))
    (slots267.jump 1458 1456 f r row1458)
    (slots267.jump 1459 1452 f r row1459)

theorem site1452 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1452:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1460:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1452Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1460Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1460 f r x y z) (slots720.atReg 1463 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1460 3 1463 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1460 1463 1461 f r row1460)
    (slots720.pos_x 1460 1463 1461 f r row1460)
    (slots720.inc_y 1461 1462 f r row1461 (Or.inl (by decide)))
    (slots720.jump 1462 1460 f r row1462)

theorem site1460 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1460:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1463:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1460Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1463Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1463 f r x y z) (slots617.atReg 1473 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1463 10 1473 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1463 1467 1464 f r row1463)
    (slots617.pos_y 1463 1467 1464 f r row1463)
    (slots617.inc_z 1464 1465 f r row1464 (Or.inl (by decide)))
    (slots617.inc_x 1465 1466 f r row1465 (Or.inl (by decide)))
    (slots617.jump 1466 1463 f r row1466)
    (slots617.zero_x 1467 1473 1468 f r row1467)
    (slots617.pos_x 1467 1473 1468 f r row1467)
    (slots617.inc_z 1468 1469 f r row1468 (Or.inl (by decide)))
    (slots617.zero_x 1469 1472 1470 f r row1469)
    (slots617.pos_x 1469 1472 1470 f r row1469)
    (slots617.inc_y 1470 1471 f r row1470 (Or.inl (by decide)))
    (slots617.jump 1471 1469 f r row1471)
    (slots617.jump 1472 1463 f r row1472)

theorem site1463 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1463:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1473:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1463Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1473Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1473 f r x y z) (slots710.atReg 1477 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1473 4 1477 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1473 1477 1474 f r row1473)
    (slots710.pos_x 1473 1477 1474 f r row1473)
    (slots710.inc_y 1474 1475 f r row1474 (Or.inl (by decide)))
    (slots710.inc_y 1475 1476 f r row1475 (Or.inl (by decide)))
    (slots710.jump 1476 1473 f r row1476)

theorem site1473 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1473:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1477:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1473Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site1477Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1477 f r x y z) (slots160.atReg 1480 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1477 3 1480 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1477 1480 1478 f r row1477)
    (slots160.pos_x 1477 1480 1478 f r row1477)
    (slots160.inc_y 1478 1479 f r row1478 (Or.inl (by decide)))
    (slots160.jump 1479 1477 f r row1479)

theorem site1477 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1477:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1480:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1477Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1480Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1480 f r x y z) (slots210.atReg 1483 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1480 3 1483 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1480 1483 1481 f r row1480)
    (slots210.pos_x 1480 1483 1481 f r row1480)
    (slots210.inc_y 1481 1482 f r row1481 (Or.inl (by decide)))
    (slots210.jump 1482 1480 f r row1482)

theorem site1480 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1480:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1483:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1480Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1483Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1483 f r x y z) (slots617.atReg 1493 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1483 10 1493 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1483 1487 1484 f r row1483)
    (slots617.pos_y 1483 1487 1484 f r row1483)
    (slots617.inc_z 1484 1485 f r row1484 (Or.inl (by decide)))
    (slots617.inc_x 1485 1486 f r row1485 (Or.inl (by decide)))
    (slots617.jump 1486 1483 f r row1486)
    (slots617.zero_x 1487 1493 1488 f r row1487)
    (slots617.pos_x 1487 1493 1488 f r row1487)
    (slots617.inc_z 1488 1489 f r row1488 (Or.inl (by decide)))
    (slots617.zero_x 1489 1492 1490 f r row1489)
    (slots617.pos_x 1489 1492 1490 f r row1489)
    (slots617.inc_y 1490 1491 f r row1490 (Or.inl (by decide)))
    (slots617.jump 1491 1489 f r row1491)
    (slots617.jump 1492 1483 f r row1492)

theorem site1483 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1483:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1493:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1483Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1493Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1493 f r x y z) (slots720.atReg 1496 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1493 3 1496 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1493 1496 1494 f r row1493)
    (slots720.pos_x 1493 1496 1494 f r row1493)
    (slots720.inc_y 1494 1495 f r row1494 (Or.inl (by decide)))
    (slots720.jump 1495 1493 f r row1495)

theorem site1493 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1493:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1496:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1493Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

theorem site1496 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1496:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1497:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1496 _ row1496]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site1497 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1497:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1498:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1497 _ row1497]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site1498 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1498:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1499:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1498 _ row1498]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1499Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1499 f r x y z) (slots160.atReg 1502 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1499 3 1502 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1499 1502 1500 f r row1499)
    (slots160.pos_x 1499 1502 1500 f r row1499)
    (slots160.inc_y 1500 1501 f r row1500 (Or.inl (by decide)))
    (slots160.jump 1501 1499 f r row1501)

theorem site1499 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1499:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1502:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1499Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1502Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1502 f r x y z) (slots210.atReg 1505 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1502 3 1505 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1502 1505 1503 f r row1502)
    (slots210.pos_x 1502 1505 1503 f r row1502)
    (slots210.inc_y 1503 1504 f r row1503 (Or.inl (by decide)))
    (slots210.jump 1504 1502 f r row1504)

theorem site1502 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1502:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1505:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1502Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1505Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1505 f r x y z) (slots617.atReg 1515 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1505 10 1515 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1505 1509 1506 f r row1505)
    (slots617.pos_y 1505 1509 1506 f r row1505)
    (slots617.inc_z 1506 1507 f r row1506 (Or.inl (by decide)))
    (slots617.inc_x 1507 1508 f r row1507 (Or.inl (by decide)))
    (slots617.jump 1508 1505 f r row1508)
    (slots617.zero_x 1509 1515 1510 f r row1509)
    (slots617.pos_x 1509 1515 1510 f r row1509)
    (slots617.inc_z 1510 1511 f r row1510 (Or.inl (by decide)))
    (slots617.zero_x 1511 1514 1512 f r row1511)
    (slots617.pos_x 1511 1514 1512 f r row1511)
    (slots617.inc_y 1512 1513 f r row1512 (Or.inl (by decide)))
    (slots617.jump 1513 1511 f r row1513)
    (slots617.jump 1514 1505 f r row1514)

theorem site1505 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1505:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1515:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1505Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1515Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1515 f r x y z) (slots720.atReg 1518 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1515 3 1518 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1515 1518 1516 f r row1515)
    (slots720.pos_x 1515 1518 1516 f r row1515)
    (slots720.inc_y 1516 1517 f r row1516 (Or.inl (by decide)))
    (slots720.jump 1517 1515 f r row1517)

theorem site1515 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1515:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1518:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1515Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1518Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 1518 f r x y z) (slots361.atReg 1522 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 1518 4 1522 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 1518 1522 1519 f r row1518)
    (slots361.pos_x 1518 1522 1519 f r row1518)
    (slots361.inc_y 1519 1520 f r row1519 (Or.inl (by decide)))
    (slots361.inc_z 1520 1521 f r row1520 (Or.inl (by decide)))
    (slots361.jump 1521 1518 f r row1521)

theorem site1518 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1518:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1522:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site1518Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site1522Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 1522 f r x y z) (slots630.atReg 1525 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 1522 3 1525 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 1522 1525 1523 f r row1522)
    (slots630.pos_x 1522 1525 1523 f r row1522)
    (slots630.inc_y 1523 1524 f r row1523 (Or.inl (by decide)))
    (slots630.jump 1524 1522 f r row1524)

theorem site1522 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1522:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1525:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site1522Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site1525Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1525 f r x y z) (slots267.atReg 1533 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1525 8 1533 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1525 1533 1526 f r row1525)
    (slots267.pos_x 1525 1533 1526 f r row1525)
    (slots267.inc_z 1526 1527 f r row1526 (Or.inl (by decide)))
    (slots267.zero_y 1527 1529 1528 f r row1527)
    (slots267.pos_y 1527 1529 1528 f r row1527)
    (slots267.jump 1528 1532 f r row1528)
    (slots267.zero_z 1529 1532 1530 f r row1529)
    (slots267.pos_z 1529 1532 1530 f r row1529)
    (slots267.inc_y 1530 1531 f r row1530 (Or.inl (by decide)))
    (slots267.jump 1531 1529 f r row1531)
    (slots267.jump 1532 1525 f r row1532)

theorem site1525 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1525:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1533:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1525Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1533Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1533 f r x y z) (slots720.atReg 1536 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1533 3 1536 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1533 1536 1534 f r row1533)
    (slots720.pos_x 1533 1536 1534 f r row1533)
    (slots720.inc_y 1534 1535 f r row1534 (Or.inl (by decide)))
    (slots720.jump 1535 1533 f r row1535)

theorem site1533 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1533:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1536:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1533Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1536Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1536 f r x y z) (slots617.atReg 1546 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1536 10 1546 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1536 1540 1537 f r row1536)
    (slots617.pos_y 1536 1540 1537 f r row1536)
    (slots617.inc_z 1537 1538 f r row1537 (Or.inl (by decide)))
    (slots617.inc_x 1538 1539 f r row1538 (Or.inl (by decide)))
    (slots617.jump 1539 1536 f r row1539)
    (slots617.zero_x 1540 1546 1541 f r row1540)
    (slots617.pos_x 1540 1546 1541 f r row1540)
    (slots617.inc_z 1541 1542 f r row1541 (Or.inl (by decide)))
    (slots617.zero_x 1542 1545 1543 f r row1542)
    (slots617.pos_x 1542 1545 1543 f r row1542)
    (slots617.inc_y 1543 1544 f r row1543 (Or.inl (by decide)))
    (slots617.jump 1544 1542 f r row1544)
    (slots617.jump 1545 1536 f r row1545)

theorem site1536 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1536:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1546:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1536Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1546Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1546 f r x y z) (slots710.atReg 1550 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1546 4 1550 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1546 1550 1547 f r row1546)
    (slots710.pos_x 1546 1550 1547 f r row1546)
    (slots710.inc_y 1547 1548 f r row1547 (Or.inl (by decide)))
    (slots710.inc_y 1548 1549 f r row1548 (Or.inl (by decide)))
    (slots710.jump 1549 1546 f r row1549)

theorem site1546 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1546:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1550:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1546Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1550 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1550:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1551:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1550 _ row1550]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1551Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1551 f r x y z) (slots160.atReg 1554 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1551 3 1554 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1551 1554 1552 f r row1551)
    (slots160.pos_x 1551 1554 1552 f r row1551)
    (slots160.inc_y 1552 1553 f r row1552 (Or.inl (by decide)))
    (slots160.jump 1553 1551 f r row1553)

theorem site1551 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1551:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1554:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1551Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

end PA192.ModelSearch.RegisterSource.Certified
