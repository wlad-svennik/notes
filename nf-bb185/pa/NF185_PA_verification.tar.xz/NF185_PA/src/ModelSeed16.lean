module
public import ModelSeed15
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter513 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2455:Nat):V) f (vector n (d+u) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2452 f n (d+u) 0 c (d+u) (v+y) 0 (atom81 n t s c u v y d w) w
  have d2 : (0+(atom81 n t s c u v y d w):V)=atom81 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter512 f n t s c u v y d w).trans mid

theorem seedEmitAfter514 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2465:Nat):V) f (vector n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) 0 (atom23 n t s c u v y d w) w)) := by
  have micro := site2455 f n (d+u) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d7 : (0+(cantor 0 (d+u)):V)=atom23 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 0 (d+u)):V)=0+(atom23 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter513 f n t s c u v y d w).trans mid

theorem seedEmitAfter515 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2469:Nat):V) f (vector n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2465 f n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) 0 (atom23 n t s c u v y d w) w
  have d1 : (0+(2*(atom23 n t s c u v y d w)):V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom23 n t s c u v y d w)):V)=0+((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter514 f n t s c u v y d w).trans mid

theorem seedEmitAfter516 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2470:Nat):V) f (vector n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2469 f n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w))+1:V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter515 f n t s c u v y d w).trans mid

theorem seedEmitAfter517 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2473:Nat):V) f (vector n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2470 f n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1):V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter516 f n t s c u v y d w).trans mid

theorem seedEmitAfter518 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2476:Nat):V) f (vector n (atom81 n t s c u v y d w) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2473 f n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom81 n t s c u v y d w):V)=atom81 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter517 f n t s c u v y d w).trans mid

theorem seedEmitAfter519 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2486:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom83 n t s c u v y d w) w)) := by
  have micro := site2476 f n (atom81 n t s c u v y d w) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom81 n t s c u v y d w)):V)=atom83 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom81 n t s c u v y d w)):V)=0+(atom83 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter518 f n t s c u v y d w).trans mid

theorem seedEmitAfter520 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2489:Nat):V) f (vector n 0 (atom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2486 f n 0 0 c (d+u) (v+y) 0 (atom83 n t s c u v y d w) w
  have d2 : (0+(atom83 n t s c u v y d w):V)=atom83 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter519 f n t s c u v y d w).trans mid

theorem seedEmitAfter521 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2493:Nat):V) f (vector n (v+y) (atom83 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2489 f n 0 (atom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter520 f n t s c u v y d w).trans mid

theorem seedEmitAfter522 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2496:Nat):V) f (vector n (v+y) (atom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2493 f n (v+y) (atom83 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter521 f n t s c u v y d w).trans mid

theorem seedEmitAfter523 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2504:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom81 n t s c u v y d w) w)) := by
  have micro := site2496 f n (v+y) (atom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom83 n t s c u v y d w)):V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom83 n t s c u v y d w):V)=0+(atom83 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom83 n t s c u v y d w)):V)=left (atom83 n t s c u v y d w)).trans (by change left (cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom81 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom83 n t s c u v y d w)):V)=atom81 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom83 n t s c u v y d w):V)=0+(atom83 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom83 n t s c u v y d w)):V)=right (atom83 n t s c u v y d w)).trans (by change right (cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom81 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter522 f n t s c u v y d w).trans mid

theorem seedEmitAfter524 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2507:Nat):V) f (vector n (v+y) (atom81 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2504 f n (v+y) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom81 n t s c u v y d w) w
  have d2 : (0+(atom81 n t s c u v y d w):V)=atom81 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter523 f n t s c u v y d w).trans mid

theorem seedEmitAfter525 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2517:Nat):V) f (vector n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) 0 (atom25 n t s c u v y d w) w)) := by
  have micro := site2507 f n (v+y) (atom81 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (v+y)):V)=atom25 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (v+y)):V)=0+(atom25 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter524 f n t s c u v y d w).trans mid

theorem seedEmitAfter526 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2521:Nat):V) f (vector n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2517 f n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) 0 (atom25 n t s c u v y d w) w
  have d1 : (0+(2*(atom25 n t s c u v y d w)):V)=(atom25 n t s c u v y d w)+(atom25 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom25 n t s c u v y d w)):V)=0+((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter525 f n t s c u v y d w).trans mid

theorem seedEmitAfter527 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2522:Nat):V) f (vector n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2521 f n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w))+1:V)=(atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter526 f n t s c u v y d w).trans mid

theorem seedEmitAfter528 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2530:Nat):V) f (vector n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) 0 c (d+u) (v+y) 3 (atom80 n t s c u v y d w) w)) := by
  have micro := site2522 f n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom81 n t s c u v y d w)):V)=3 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom81 n t s c u v y d w):V)=0+(atom81 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom81 n t s c u v y d w)):V)=left (atom81 n t s c u v y d w)).trans (by change left (cantor 3 (atom80 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom81 n t s c u v y d w)):V)=atom80 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom81 n t s c u v y d w):V)=0+(atom81 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom81 n t s c u v y d w)):V)=right (atom81 n t s c u v y d w)).trans (by change right (cantor 3 (atom80 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter527 f n t s c u v y d w).trans mid

theorem seedEmitAfter529 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2533:Nat):V) f (vector n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) (atom80 n t s c u v y d w) c (d+u) (v+y) 3 0 w)) := by
  have micro := site2530 f n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) 0 c (d+u) (v+y) 3 (atom80 n t s c u v y d w) w
  have d2 : (0+(atom80 n t s c u v y d w):V)=atom80 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter528 f n t s c u v y d w).trans mid

theorem seedEmitAfter530 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2543:Nat):V) f (vector n 0 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 (atom84 n t s c u v y d w) w)) := by
  have micro := site2533 f n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) (atom80 n t s c u v y d w) c (d+u) (v+y) 3 0 w
  have d7 : (0+(cantor 3 ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1)):V)=atom84 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 3 ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1)):V)=0+(atom84 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter529 f n t s c u v y d w).trans mid

theorem seedEmitAfter531 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2547:Nat):V) f (vector n ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)) (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2543 f n 0 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 (atom84 n t s c u v y d w) w
  have d1 : (0+(2*(atom84 n t s c u v y d w)):V)=(atom84 n t s c u v y d w)+(atom84 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom84 n t s c u v y d w)):V)=0+((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter530 f n t s c u v y d w).trans mid

theorem seedEmitAfter532 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2548:Nat):V) f (vector n ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1) (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2547 f n ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)) (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w))+1:V)=(atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter531 f n t s c u v y d w).trans mid

theorem seedEmitAfter533 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2556:Nat):V) f (vector n ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) (atom75 n t s c u v y d w) w)) := by
  have micro := site2548 f n ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1) (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom80 n t s c u v y d w)):V)=(atom79 n t s c u v y d w)+(atom79 n t s c u v y d w) := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom80 n t s c u v y d w):V)=0+(atom80 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom80 n t s c u v y d w)):V)=left (atom80 n t s c u v y d w)).trans (by change left (cantor ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) (atom75 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom80 n t s c u v y d w)):V)=atom75 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom80 n t s c u v y d w):V)=0+(atom80 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom80 n t s c u v y d w)):V)=right (atom80 n t s c u v y d w)).trans (by change right (cantor ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) (atom75 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter532 f n t s c u v y d w).trans mid

theorem seedEmitAfter534 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2559:Nat):V) f (vector n ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1) (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) 0 w)) := by
  have micro := site2556 f n ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) (atom75 n t s c u v y d w) w
  have d2 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter533 f n t s c u v y d w).trans mid

theorem seedEmitAfter535 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2569:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 (atom85 n t s c u v y d w) w)) := by
  have micro := site2559 f n ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1) (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1)):V)=atom85 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1)):V)=0+(atom85 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter534 f n t s c u v y d w).trans mid

theorem seedEmitAfter536 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2573:Nat):V) f (vector n ((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2569 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 (atom85 n t s c u v y d w) w
  have d1 : (0+(2*(atom85 n t s c u v y d w)):V)=(atom85 n t s c u v y d w)+(atom85 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom85 n t s c u v y d w)):V)=0+((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter535 f n t s c u v y d w).trans mid

theorem seedEmitAfter537 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2576:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)) 0 w)) := by
  have micro := site2573 f n ((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)):V)=(atom85 n t s c u v y d w)+(atom85 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter536 f n t s c u v y d w).trans mid

theorem seedEmitAfter538 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2579:Nat):V) f (vector n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) ((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)) 0 w)) := by
  have micro := site2576 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)) 0 w
  have d1 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter537 f n t s c u v y d w).trans mid

theorem seedEmitAfter539 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2589:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom86 n t s c u v y d w) w)) := by
  have micro := site2579 f n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) ((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)) (atom75 n t s c u v y d w)):V)=atom86 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)) (atom75 n t s c u v y d w)):V)=0+(atom86 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter538 f n t s c u v y d w).trans mid

theorem seedEmitAfter540 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2592:Nat):V) f (vector n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2589 f n 0 0 c (d+u) (v+y) 0 (atom86 n t s c u v y d w) w
  have d2 : (0+(atom86 n t s c u v y d w):V)=atom86 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter539 f n t s c u v y d w).trans mid

theorem seedEmitAfter541 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2596:Nat):V) f (vector n (v+y) (atom86 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2592 f n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter540 f n t s c u v y d w).trans mid

theorem seedEmitAfter542 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2599:Nat):V) f (vector n (v+y) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2596 f n (v+y) (atom86 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter541 f n t s c u v y d w).trans mid

theorem seedEmitAfter543 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2602:Nat):V) f (vector n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site2599 f n (v+y) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter542 f n t s c u v y d w).trans mid

theorem seedEmitAfter544 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2605:Nat):V) f (vector n (atom86 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site2602 f n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d1 : (0+(atom86 n t s c u v y d w):V)=atom86 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter543 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
