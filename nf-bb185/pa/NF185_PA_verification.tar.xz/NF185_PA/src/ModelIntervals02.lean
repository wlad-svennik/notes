module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site0386Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 386 f r x y z) (slots617.atReg 396 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 386 10 396 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 386 390 387 f r row0386)
    (slots617.pos_y 386 390 387 f r row0386)
    (slots617.inc_z 387 388 f r row0387 (Or.inl (by decide)))
    (slots617.inc_x 388 389 f r row0388 (Or.inl (by decide)))
    (slots617.jump 389 386 f r row0389)
    (slots617.zero_x 390 396 391 f r row0390)
    (slots617.pos_x 390 396 391 f r row0390)
    (slots617.inc_z 391 392 f r row0391 (Or.inl (by decide)))
    (slots617.zero_x 392 395 393 f r row0392)
    (slots617.pos_x 392 395 393 f r row0392)
    (slots617.inc_y 393 394 f r row0393 (Or.inl (by decide)))
    (slots617.jump 394 392 f r row0394)
    (slots617.jump 395 386 f r row0395)

theorem site0386 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((386:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((396:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0386Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0396Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 396 f r x y z) (slots710.atReg 400 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 396 4 400 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 396 400 397 f r row0396)
    (slots710.pos_x 396 400 397 f r row0396)
    (slots710.inc_y 397 398 f r row0397 (Or.inl (by decide)))
    (slots710.inc_y 398 399 f r row0398 (Or.inl (by decide)))
    (slots710.jump 399 396 f r row0399)

theorem site0396 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((396:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((400:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0396Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site0400Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 400 f r x y z) (slots160.atReg 403 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 400 3 403 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 400 403 401 f r row0400)
    (slots160.pos_x 400 403 401 f r row0400)
    (slots160.inc_y 401 402 f r row0401 (Or.inl (by decide)))
    (slots160.jump 402 400 f r row0402)

theorem site0400 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((400:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((403:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0400Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0403Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 403 f r x y z) (slots210.atReg 406 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 403 3 406 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 403 406 404 f r row0403)
    (slots210.pos_x 403 406 404 f r row0403)
    (slots210.inc_y 404 405 f r row0404 (Or.inl (by decide)))
    (slots210.jump 405 403 f r row0405)

theorem site0403 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((403:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((406:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0403Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0406Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 406 f r x y z) (slots617.atReg 416 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 406 10 416 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 406 410 407 f r row0406)
    (slots617.pos_y 406 410 407 f r row0406)
    (slots617.inc_z 407 408 f r row0407 (Or.inl (by decide)))
    (slots617.inc_x 408 409 f r row0408 (Or.inl (by decide)))
    (slots617.jump 409 406 f r row0409)
    (slots617.zero_x 410 416 411 f r row0410)
    (slots617.pos_x 410 416 411 f r row0410)
    (slots617.inc_z 411 412 f r row0411 (Or.inl (by decide)))
    (slots617.zero_x 412 415 413 f r row0412)
    (slots617.pos_x 412 415 413 f r row0412)
    (slots617.inc_y 413 414 f r row0413 (Or.inl (by decide)))
    (slots617.jump 414 412 f r row0414)
    (slots617.jump 415 406 f r row0415)

theorem site0406 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((406:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((416:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0406Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0416Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 416 f r x y z) (slots720.atReg 419 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 416 3 419 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 416 419 417 f r row0416)
    (slots720.pos_x 416 419 417 f r row0416)
    (slots720.inc_y 417 418 f r row0417 (Or.inl (by decide)))
    (slots720.jump 418 416 f r row0418)

theorem site0416 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((416:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((419:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0416Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0419Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 419 f r x y z) (slots461.atReg 423 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 419 4 423 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 419 423 420 f r row0419)
    (slots461.pos_x 419 423 420 f r row0419)
    (slots461.inc_y 420 421 f r row0420 (Or.inl (by decide)))
    (slots461.inc_z 421 422 f r row0421 (Or.inl (by decide)))
    (slots461.jump 422 419 f r row0422)

theorem site0419 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((419:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((423:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0419Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site0423Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 423 f r x y z) (slots640.atReg 426 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 423 3 426 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 423 426 424 f r row0423)
    (slots640.pos_x 423 426 424 f r row0423)
    (slots640.inc_y 424 425 f r row0424 (Or.inl (by decide)))
    (slots640.jump 425 423 f r row0425)

theorem site0423 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((423:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((426:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0423Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site0426Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 426 f r x y z) (slots160.atReg 429 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 426 3 429 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 426 429 427 f r row0426)
    (slots160.pos_x 426 429 427 f r row0426)
    (slots160.inc_y 427 428 f r row0427 (Or.inl (by decide)))
    (slots160.jump 428 426 f r row0428)

theorem site0426 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((426:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((429:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0426Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0429Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 429 f r x y z) (slots210.atReg 432 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 429 3 432 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 429 432 430 f r row0429)
    (slots210.pos_x 429 432 430 f r row0429)
    (slots210.inc_y 430 431 f r row0430 (Or.inl (by decide)))
    (slots210.jump 431 429 f r row0431)

theorem site0429 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((429:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((432:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0429Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0432Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 432 f r x y z) (slots617.atReg 442 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 432 10 442 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 432 436 433 f r row0432)
    (slots617.pos_y 432 436 433 f r row0432)
    (slots617.inc_z 433 434 f r row0433 (Or.inl (by decide)))
    (slots617.inc_x 434 435 f r row0434 (Or.inl (by decide)))
    (slots617.jump 435 432 f r row0435)
    (slots617.zero_x 436 442 437 f r row0436)
    (slots617.pos_x 436 442 437 f r row0436)
    (slots617.inc_z 437 438 f r row0437 (Or.inl (by decide)))
    (slots617.zero_x 438 441 439 f r row0438)
    (slots617.pos_x 438 441 439 f r row0438)
    (slots617.inc_y 439 440 f r row0439 (Or.inl (by decide)))
    (slots617.jump 440 438 f r row0440)
    (slots617.jump 441 432 f r row0441)

theorem site0432 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((432:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((442:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0432Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0442Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 442 f r x y z) (slots720.atReg 445 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 442 3 445 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 442 445 443 f r row0442)
    (slots720.pos_x 442 445 443 f r row0442)
    (slots720.inc_y 443 444 f r row0443 (Or.inl (by decide)))
    (slots720.jump 444 442 f r row0444)

theorem site0442 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((442:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((445:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0442Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0445Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 445 f r x y z) (slots561.atReg 449 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 445 4 449 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 445 449 446 f r row0445)
    (slots561.pos_x 445 449 446 f r row0445)
    (slots561.inc_y 446 447 f r row0446 (Or.inl (by decide)))
    (slots561.inc_z 447 448 f r row0447 (Or.inl (by decide)))
    (slots561.jump 448 445 f r row0448)

theorem site0445 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((445:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((449:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0445Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site0449Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 449 f r x y z) (slots650.atReg 452 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 449 3 452 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 449 452 450 f r row0449)
    (slots650.pos_x 449 452 450 f r row0449)
    (slots650.inc_y 450 451 f r row0450 (Or.inl (by decide)))
    (slots650.jump 451 449 f r row0451)

theorem site0449 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((449:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((452:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0449Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site0452Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 452 f r x y z) (slots267.atReg 460 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 452 8 460 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 452 460 453 f r row0452)
    (slots267.pos_x 452 460 453 f r row0452)
    (slots267.inc_z 453 454 f r row0453 (Or.inl (by decide)))
    (slots267.zero_y 454 456 455 f r row0454)
    (slots267.pos_y 454 456 455 f r row0454)
    (slots267.jump 455 459 f r row0455)
    (slots267.zero_z 456 459 457 f r row0456)
    (slots267.pos_z 456 459 457 f r row0456)
    (slots267.inc_y 457 458 f r row0457 (Or.inl (by decide)))
    (slots267.jump 458 456 f r row0458)
    (slots267.jump 459 452 f r row0459)

theorem site0452 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((452:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((460:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0452Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0460Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 460 f r x y z) (slots720.atReg 463 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 460 3 463 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 460 463 461 f r row0460)
    (slots720.pos_x 460 463 461 f r row0460)
    (slots720.inc_y 461 462 f r row0461 (Or.inl (by decide)))
    (slots720.jump 462 460 f r row0462)

theorem site0460 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((460:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((463:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0460Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0463Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 463 f r x y z) (slots617.atReg 473 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 463 10 473 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 463 467 464 f r row0463)
    (slots617.pos_y 463 467 464 f r row0463)
    (slots617.inc_z 464 465 f r row0464 (Or.inl (by decide)))
    (slots617.inc_x 465 466 f r row0465 (Or.inl (by decide)))
    (slots617.jump 466 463 f r row0466)
    (slots617.zero_x 467 473 468 f r row0467)
    (slots617.pos_x 467 473 468 f r row0467)
    (slots617.inc_z 468 469 f r row0468 (Or.inl (by decide)))
    (slots617.zero_x 469 472 470 f r row0469)
    (slots617.pos_x 469 472 470 f r row0469)
    (slots617.inc_y 470 471 f r row0470 (Or.inl (by decide)))
    (slots617.jump 471 469 f r row0471)
    (slots617.jump 472 463 f r row0472)

theorem site0463 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((463:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((473:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0463Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0473Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 473 f r x y z) (slots710.atReg 477 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 473 4 477 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 473 477 474 f r row0473)
    (slots710.pos_x 473 477 474 f r row0473)
    (slots710.inc_y 474 475 f r row0474 (Or.inl (by decide)))
    (slots710.inc_y 475 476 f r row0475 (Or.inl (by decide)))
    (slots710.jump 476 473 f r row0476)

theorem site0473 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((473:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((477:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0473Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site0477 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((477:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((478:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 477 _ row0477]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0478Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 478 f r x y z) (slots160.atReg 481 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 478 3 481 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 478 481 479 f r row0478)
    (slots160.pos_x 478 481 479 f r row0478)
    (slots160.inc_y 479 480 f r row0479 (Or.inl (by decide)))
    (slots160.jump 480 478 f r row0480)

theorem site0478 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((478:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((481:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0478Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0481Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 481 f r x y z) (slots210.atReg 484 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 481 3 484 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 481 484 482 f r row0481)
    (slots210.pos_x 481 484 482 f r row0481)
    (slots210.inc_y 482 483 f r row0482 (Or.inl (by decide)))
    (slots210.jump 483 481 f r row0483)

theorem site0481 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((481:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((484:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0481Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0484Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 484 f r x y z) (slots617.atReg 494 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 484 10 494 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 484 488 485 f r row0484)
    (slots617.pos_y 484 488 485 f r row0484)
    (slots617.inc_z 485 486 f r row0485 (Or.inl (by decide)))
    (slots617.inc_x 486 487 f r row0486 (Or.inl (by decide)))
    (slots617.jump 487 484 f r row0487)
    (slots617.zero_x 488 494 489 f r row0488)
    (slots617.pos_x 488 494 489 f r row0488)
    (slots617.inc_z 489 490 f r row0489 (Or.inl (by decide)))
    (slots617.zero_x 490 493 491 f r row0490)
    (slots617.pos_x 490 493 491 f r row0490)
    (slots617.inc_y 491 492 f r row0491 (Or.inl (by decide)))
    (slots617.jump 492 490 f r row0492)
    (slots617.jump 493 484 f r row0493)

theorem site0484 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((484:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((494:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0484Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0494Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 494 f r x y z) (slots720.atReg 497 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 494 3 497 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 494 497 495 f r row0494)
    (slots720.pos_x 494 497 495 f r row0494)
    (slots720.inc_y 495 496 f r row0495 (Or.inl (by decide)))
    (slots720.jump 496 494 f r row0496)

theorem site0494 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((494:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((497:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0494Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0497Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 497 f r x y z) (slots561.atReg 501 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 497 4 501 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 497 501 498 f r row0497)
    (slots561.pos_x 497 501 498 f r row0497)
    (slots561.inc_y 498 499 f r row0498 (Or.inl (by decide)))
    (slots561.inc_z 499 500 f r row0499 (Or.inl (by decide)))
    (slots561.jump 500 497 f r row0500)

theorem site0497 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((497:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((501:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0497Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site0501Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 501 f r x y z) (slots650.atReg 504 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 501 3 504 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 501 504 502 f r row0501)
    (slots650.pos_x 501 504 502 f r row0501)
    (slots650.inc_y 502 503 f r row0502 (Or.inl (by decide)))
    (slots650.jump 503 501 f r row0503)

theorem site0501 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((501:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((504:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0501Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site0504Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 504 f r x y z) (slots267.atReg 512 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 504 8 512 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 504 512 505 f r row0504)
    (slots267.pos_x 504 512 505 f r row0504)
    (slots267.inc_z 505 506 f r row0505 (Or.inl (by decide)))
    (slots267.zero_y 506 508 507 f r row0506)
    (slots267.pos_y 506 508 507 f r row0506)
    (slots267.jump 507 511 f r row0507)
    (slots267.zero_z 508 511 509 f r row0508)
    (slots267.pos_z 508 511 509 f r row0508)
    (slots267.inc_y 509 510 f r row0509 (Or.inl (by decide)))
    (slots267.jump 510 508 f r row0510)
    (slots267.jump 511 504 f r row0511)

theorem site0504 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((504:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((512:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0504Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0512Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 512 f r x y z) (slots720.atReg 515 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 512 3 515 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 512 515 513 f r row0512)
    (slots720.pos_x 512 515 513 f r row0512)
    (slots720.inc_y 513 514 f r row0513 (Or.inl (by decide)))
    (slots720.jump 514 512 f r row0514)

theorem site0512 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((512:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((515:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0512Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0515Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 515 f r x y z) (slots617.atReg 525 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 515 10 525 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 515 519 516 f r row0515)
    (slots617.pos_y 515 519 516 f r row0515)
    (slots617.inc_z 516 517 f r row0516 (Or.inl (by decide)))
    (slots617.inc_x 517 518 f r row0517 (Or.inl (by decide)))
    (slots617.jump 518 515 f r row0518)
    (slots617.zero_x 519 525 520 f r row0519)
    (slots617.pos_x 519 525 520 f r row0519)
    (slots617.inc_z 520 521 f r row0520 (Or.inl (by decide)))
    (slots617.zero_x 521 524 522 f r row0521)
    (slots617.pos_x 521 524 522 f r row0521)
    (slots617.inc_y 522 523 f r row0522 (Or.inl (by decide)))
    (slots617.jump 523 521 f r row0523)
    (slots617.jump 524 515 f r row0524)

theorem site0515 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((515:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((525:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0515Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0525Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 525 f r x y z) (slots710.atReg 529 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 525 4 529 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 525 529 526 f r row0525)
    (slots710.pos_x 525 529 526 f r row0525)
    (slots710.inc_y 526 527 f r row0526 (Or.inl (by decide)))
    (slots710.inc_y 527 528 f r row0527 (Or.inl (by decide)))
    (slots710.jump 528 525 f r row0528)

theorem site0525 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((525:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((529:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0525Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site0529 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((529:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((530:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 529 _ row0529]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0530Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 530 f r x y z) (slots160.atReg 533 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 530 3 533 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 530 533 531 f r row0530)
    (slots160.pos_x 530 533 531 f r row0530)
    (slots160.inc_y 531 532 f r row0531 (Or.inl (by decide)))
    (slots160.jump 532 530 f r row0532)

theorem site0530 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((530:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((533:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0530Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0533Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 533 f r x y z) (slots210.atReg 536 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 533 3 536 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 533 536 534 f r row0533)
    (slots210.pos_x 533 536 534 f r row0533)
    (slots210.inc_y 534 535 f r row0534 (Or.inl (by decide)))
    (slots210.jump 535 533 f r row0535)

theorem site0533 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((533:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((536:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0533Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0536Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 536 f r x y z) (slots617.atReg 546 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 536 10 546 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 536 540 537 f r row0536)
    (slots617.pos_y 536 540 537 f r row0536)
    (slots617.inc_z 537 538 f r row0537 (Or.inl (by decide)))
    (slots617.inc_x 538 539 f r row0538 (Or.inl (by decide)))
    (slots617.jump 539 536 f r row0539)
    (slots617.zero_x 540 546 541 f r row0540)
    (slots617.pos_x 540 546 541 f r row0540)
    (slots617.inc_z 541 542 f r row0541 (Or.inl (by decide)))
    (slots617.zero_x 542 545 543 f r row0542)
    (slots617.pos_x 542 545 543 f r row0542)
    (slots617.inc_y 543 544 f r row0543 (Or.inl (by decide)))
    (slots617.jump 544 542 f r row0544)
    (slots617.jump 545 536 f r row0545)

theorem site0536 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((536:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((546:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0536Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0546Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 546 f r x y z) (slots720.atReg 549 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 546 3 549 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 546 549 547 f r row0546)
    (slots720.pos_x 546 549 547 f r row0546)
    (slots720.inc_y 547 548 f r row0547 (Or.inl (by decide)))
    (slots720.jump 548 546 f r row0548)

theorem site0546 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((546:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((549:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0546Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

theorem site0549 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((549:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((550:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 549 _ row0549]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0550Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 550 f r x y z) (slots160.atReg 553 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 550 3 553 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 550 553 551 f r row0550)
    (slots160.pos_x 550 553 551 f r row0550)
    (slots160.inc_y 551 552 f r row0551 (Or.inl (by decide)))
    (slots160.jump 552 550 f r row0552)

theorem site0550 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((550:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((553:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0550Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0553Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 553 f r x y z) (slots210.atReg 556 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 553 3 556 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 553 556 554 f r row0553)
    (slots210.pos_x 553 556 554 f r row0553)
    (slots210.inc_y 554 555 f r row0554 (Or.inl (by decide)))
    (slots210.jump 555 553 f r row0555)

theorem site0553 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((553:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((556:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0553Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0556Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 556 f r x y z) (slots617.atReg 566 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 556 10 566 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 556 560 557 f r row0556)
    (slots617.pos_y 556 560 557 f r row0556)
    (slots617.inc_z 557 558 f r row0557 (Or.inl (by decide)))
    (slots617.inc_x 558 559 f r row0558 (Or.inl (by decide)))
    (slots617.jump 559 556 f r row0559)
    (slots617.zero_x 560 566 561 f r row0560)
    (slots617.pos_x 560 566 561 f r row0560)
    (slots617.inc_z 561 562 f r row0561 (Or.inl (by decide)))
    (slots617.zero_x 562 565 563 f r row0562)
    (slots617.pos_x 562 565 563 f r row0562)
    (slots617.inc_y 563 564 f r row0563 (Or.inl (by decide)))
    (slots617.jump 564 562 f r row0564)
    (slots617.jump 565 556 f r row0565)

theorem site0556 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((556:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((566:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0556Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0566Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 566 f r x y z) (slots720.atReg 569 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 566 3 569 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 566 569 567 f r row0566)
    (slots720.pos_x 566 569 567 f r row0566)
    (slots720.inc_y 567 568 f r row0567 (Or.inl (by decide)))
    (slots720.jump 568 566 f r row0568)

theorem site0566 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((566:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((569:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0566Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0569Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 569 f r x y z) (slots160.atReg 572 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 569 3 572 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 569 572 570 f r row0569)
    (slots160.pos_x 569 572 570 f r row0569)
    (slots160.inc_y 570 571 f r row0570 (Or.inl (by decide)))
    (slots160.jump 571 569 f r row0571)

theorem site0569 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((569:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((572:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0569Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0572Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 572 f r x y z) (slots210.atReg 575 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 572 3 575 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 572 575 573 f r row0572)
    (slots210.pos_x 572 575 573 f r row0572)
    (slots210.inc_y 573 574 f r row0573 (Or.inl (by decide)))
    (slots210.jump 574 572 f r row0574)

theorem site0572 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((572:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((575:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0572Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

end PA192.ModelSearch.RegisterSource.Certified
