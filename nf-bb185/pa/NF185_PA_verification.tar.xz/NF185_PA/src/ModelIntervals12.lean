module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site2336Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2336 f r x y z) (slots617.atReg 2346 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2336 10 2346 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2336 2340 2337 f r row2336)
    (slots617.pos_y 2336 2340 2337 f r row2336)
    (slots617.inc_z 2337 2338 f r row2337 (Or.inl (by decide)))
    (slots617.inc_x 2338 2339 f r row2338 (Or.inl (by decide)))
    (slots617.jump 2339 2336 f r row2339)
    (slots617.zero_x 2340 2346 2341 f r row2340)
    (slots617.pos_x 2340 2346 2341 f r row2340)
    (slots617.inc_z 2341 2342 f r row2341 (Or.inl (by decide)))
    (slots617.zero_x 2342 2345 2343 f r row2342)
    (slots617.pos_x 2342 2345 2343 f r row2342)
    (slots617.inc_y 2343 2344 f r row2343 (Or.inl (by decide)))
    (slots617.jump 2344 2342 f r row2344)
    (slots617.jump 2345 2336 f r row2345)

theorem site2336 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2336:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2346:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2336Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2346Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2346 f r x y z) (slots720.atReg 2349 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2346 3 2349 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2346 2349 2347 f r row2346)
    (slots720.pos_x 2346 2349 2347 f r row2346)
    (slots720.inc_y 2347 2348 f r row2347 (Or.inl (by decide)))
    (slots720.jump 2348 2346 f r row2348)

theorem site2346 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2346:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2349:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2346Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

theorem site2349 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2349:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2350:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2349 _ row2349]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site2350 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2350:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2351:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2350 _ row2350]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site2351 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2351:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2352:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2351 _ row2351]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2352Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2352 f r x y z) (slots267.atReg 2360 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2352 8 2360 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2352 2360 2353 f r row2352)
    (slots267.pos_x 2352 2360 2353 f r row2352)
    (slots267.inc_z 2353 2354 f r row2353 (Or.inl (by decide)))
    (slots267.zero_y 2354 2356 2355 f r row2354)
    (slots267.pos_y 2354 2356 2355 f r row2354)
    (slots267.jump 2355 2359 f r row2355)
    (slots267.zero_z 2356 2359 2357 f r row2356)
    (slots267.pos_z 2356 2359 2357 f r row2356)
    (slots267.inc_y 2357 2358 f r row2357 (Or.inl (by decide)))
    (slots267.jump 2358 2356 f r row2358)
    (slots267.jump 2359 2352 f r row2359)

theorem site2352 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2352:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2360:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2352Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2360Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2360 f r x y z) (slots720.atReg 2363 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2360 3 2363 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2360 2363 2361 f r row2360)
    (slots720.pos_x 2360 2363 2361 f r row2360)
    (slots720.inc_y 2361 2362 f r row2361 (Or.inl (by decide)))
    (slots720.jump 2362 2360 f r row2362)

theorem site2360 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2360:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2363:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2360Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2363Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2363 f r x y z) (slots617.atReg 2373 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2363 10 2373 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2363 2367 2364 f r row2363)
    (slots617.pos_y 2363 2367 2364 f r row2363)
    (slots617.inc_z 2364 2365 f r row2364 (Or.inl (by decide)))
    (slots617.inc_x 2365 2366 f r row2365 (Or.inl (by decide)))
    (slots617.jump 2366 2363 f r row2366)
    (slots617.zero_x 2367 2373 2368 f r row2367)
    (slots617.pos_x 2367 2373 2368 f r row2367)
    (slots617.inc_z 2368 2369 f r row2368 (Or.inl (by decide)))
    (slots617.zero_x 2369 2372 2370 f r row2369)
    (slots617.pos_x 2369 2372 2370 f r row2369)
    (slots617.inc_y 2370 2371 f r row2370 (Or.inl (by decide)))
    (slots617.jump 2371 2369 f r row2371)
    (slots617.jump 2372 2363 f r row2372)

theorem site2363 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2363:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2373:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2363Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2373Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2373 f r x y z) (slots710.atReg 2377 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2373 4 2377 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2373 2377 2374 f r row2373)
    (slots710.pos_x 2373 2377 2374 f r row2373)
    (slots710.inc_y 2374 2375 f r row2374 (Or.inl (by decide)))
    (slots710.inc_y 2375 2376 f r row2375 (Or.inl (by decide)))
    (slots710.jump 2376 2373 f r row2376)

theorem site2373 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2373:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2377:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2373Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site2377Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2377 f r x y z) (slots160.atReg 2380 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2377 3 2380 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2377 2380 2378 f r row2377)
    (slots160.pos_x 2377 2380 2378 f r row2377)
    (slots160.inc_y 2378 2379 f r row2378 (Or.inl (by decide)))
    (slots160.jump 2379 2377 f r row2379)

theorem site2377 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2377:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2380:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2377Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2380Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2380 f r x y z) (slots210.atReg 2383 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2380 3 2383 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2380 2383 2381 f r row2380)
    (slots210.pos_x 2380 2383 2381 f r row2380)
    (slots210.inc_y 2381 2382 f r row2381 (Or.inl (by decide)))
    (slots210.jump 2382 2380 f r row2382)

theorem site2380 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2380:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2383:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2380Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2383Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2383 f r x y z) (slots617.atReg 2393 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2383 10 2393 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2383 2387 2384 f r row2383)
    (slots617.pos_y 2383 2387 2384 f r row2383)
    (slots617.inc_z 2384 2385 f r row2384 (Or.inl (by decide)))
    (slots617.inc_x 2385 2386 f r row2385 (Or.inl (by decide)))
    (slots617.jump 2386 2383 f r row2386)
    (slots617.zero_x 2387 2393 2388 f r row2387)
    (slots617.pos_x 2387 2393 2388 f r row2387)
    (slots617.inc_z 2388 2389 f r row2388 (Or.inl (by decide)))
    (slots617.zero_x 2389 2392 2390 f r row2389)
    (slots617.pos_x 2389 2392 2390 f r row2389)
    (slots617.inc_y 2390 2391 f r row2390 (Or.inl (by decide)))
    (slots617.jump 2391 2389 f r row2391)
    (slots617.jump 2392 2383 f r row2392)

theorem site2383 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2383:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2393:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2383Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2393Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2393 f r x y z) (slots720.atReg 2396 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2393 3 2396 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2393 2396 2394 f r row2393)
    (slots720.pos_x 2393 2396 2394 f r row2393)
    (slots720.inc_y 2394 2395 f r row2394 (Or.inl (by decide)))
    (slots720.jump 2395 2393 f r row2395)

theorem site2393 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2393:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2396:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2393Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

theorem site2396 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2396:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2397:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2396 _ row2396]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site2397 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2397:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2398:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2397 _ row2397]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site2398 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2398:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2399:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2398 _ row2398]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2399Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2399 f r x y z) (slots160.atReg 2402 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2399 3 2402 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2399 2402 2400 f r row2399)
    (slots160.pos_x 2399 2402 2400 f r row2399)
    (slots160.inc_y 2400 2401 f r row2400 (Or.inl (by decide)))
    (slots160.jump 2401 2399 f r row2401)

theorem site2399 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2399:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2402:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2399Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2402Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2402 f r x y z) (slots210.atReg 2405 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2402 3 2405 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2402 2405 2403 f r row2402)
    (slots210.pos_x 2402 2405 2403 f r row2402)
    (slots210.inc_y 2403 2404 f r row2403 (Or.inl (by decide)))
    (slots210.jump 2404 2402 f r row2404)

theorem site2402 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2402:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2405:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2402Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2405Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2405 f r x y z) (slots617.atReg 2415 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2405 10 2415 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2405 2409 2406 f r row2405)
    (slots617.pos_y 2405 2409 2406 f r row2405)
    (slots617.inc_z 2406 2407 f r row2406 (Or.inl (by decide)))
    (slots617.inc_x 2407 2408 f r row2407 (Or.inl (by decide)))
    (slots617.jump 2408 2405 f r row2408)
    (slots617.zero_x 2409 2415 2410 f r row2409)
    (slots617.pos_x 2409 2415 2410 f r row2409)
    (slots617.inc_z 2410 2411 f r row2410 (Or.inl (by decide)))
    (slots617.zero_x 2411 2414 2412 f r row2411)
    (slots617.pos_x 2411 2414 2412 f r row2411)
    (slots617.inc_y 2412 2413 f r row2412 (Or.inl (by decide)))
    (slots617.jump 2413 2411 f r row2413)
    (slots617.jump 2414 2405 f r row2414)

theorem site2405 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2405:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2415:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2405Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2415Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2415 f r x y z) (slots720.atReg 2418 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2415 3 2418 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2415 2418 2416 f r row2415)
    (slots720.pos_x 2415 2418 2416 f r row2415)
    (slots720.inc_y 2416 2417 f r row2416 (Or.inl (by decide)))
    (slots720.jump 2417 2415 f r row2417)

theorem site2415 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2415:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2418:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2415Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2418Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2418 f r x y z) (slots160.atReg 2421 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2418 3 2421 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2418 2421 2419 f r row2418)
    (slots160.pos_x 2418 2421 2419 f r row2418)
    (slots160.inc_y 2419 2420 f r row2419 (Or.inl (by decide)))
    (slots160.jump 2420 2418 f r row2420)

theorem site2418 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2418:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2421:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2418Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2421Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2421 f r x y z) (slots210.atReg 2424 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2421 3 2424 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2421 2424 2422 f r row2421)
    (slots210.pos_x 2421 2424 2422 f r row2421)
    (slots210.inc_y 2422 2423 f r row2422 (Or.inl (by decide)))
    (slots210.jump 2423 2421 f r row2423)

theorem site2421 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2421:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2424:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2421Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2424Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2424 f r x y z) (slots617.atReg 2434 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2424 10 2434 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2424 2428 2425 f r row2424)
    (slots617.pos_y 2424 2428 2425 f r row2424)
    (slots617.inc_z 2425 2426 f r row2425 (Or.inl (by decide)))
    (slots617.inc_x 2426 2427 f r row2426 (Or.inl (by decide)))
    (slots617.jump 2427 2424 f r row2427)
    (slots617.zero_x 2428 2434 2429 f r row2428)
    (slots617.pos_x 2428 2434 2429 f r row2428)
    (slots617.inc_z 2429 2430 f r row2429 (Or.inl (by decide)))
    (slots617.zero_x 2430 2433 2431 f r row2430)
    (slots617.pos_x 2430 2433 2431 f r row2430)
    (slots617.inc_y 2431 2432 f r row2431 (Or.inl (by decide)))
    (slots617.jump 2432 2430 f r row2432)
    (slots617.jump 2433 2424 f r row2433)

theorem site2424 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2424:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2434:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2424Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2434Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2434 f r x y z) (slots720.atReg 2437 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2434 3 2437 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2434 2437 2435 f r row2434)
    (slots720.pos_x 2434 2437 2435 f r row2434)
    (slots720.inc_y 2435 2436 f r row2435 (Or.inl (by decide)))
    (slots720.jump 2436 2434 f r row2436)

theorem site2434 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2434:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2437:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2434Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2437Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2437 f r x y z) (slots461.atReg 2441 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2437 4 2441 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2437 2441 2438 f r row2437)
    (slots461.pos_x 2437 2441 2438 f r row2437)
    (slots461.inc_y 2438 2439 f r row2438 (Or.inl (by decide)))
    (slots461.inc_z 2439 2440 f r row2439 (Or.inl (by decide)))
    (slots461.jump 2440 2437 f r row2440)

theorem site2437 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2437:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2441:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2437Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site2441Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2441 f r x y z) (slots640.atReg 2444 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2441 3 2444 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2441 2444 2442 f r row2441)
    (slots640.pos_x 2441 2444 2442 f r row2441)
    (slots640.inc_y 2442 2443 f r row2442 (Or.inl (by decide)))
    (slots640.jump 2443 2441 f r row2443)

theorem site2441 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2441:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2444:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2441Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site2444Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2444 f r x y z) (slots267.atReg 2452 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2444 8 2452 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2444 2452 2445 f r row2444)
    (slots267.pos_x 2444 2452 2445 f r row2444)
    (slots267.inc_z 2445 2446 f r row2445 (Or.inl (by decide)))
    (slots267.zero_y 2446 2448 2447 f r row2446)
    (slots267.pos_y 2446 2448 2447 f r row2446)
    (slots267.jump 2447 2451 f r row2447)
    (slots267.zero_z 2448 2451 2449 f r row2448)
    (slots267.pos_z 2448 2451 2449 f r row2448)
    (slots267.inc_y 2449 2450 f r row2449 (Or.inl (by decide)))
    (slots267.jump 2450 2448 f r row2450)
    (slots267.jump 2451 2444 f r row2451)

theorem site2444 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2444:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2452:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2444Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2452Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2452 f r x y z) (slots720.atReg 2455 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2452 3 2455 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2452 2455 2453 f r row2452)
    (slots720.pos_x 2452 2455 2453 f r row2452)
    (slots720.inc_y 2453 2454 f r row2453 (Or.inl (by decide)))
    (slots720.jump 2454 2452 f r row2454)

theorem site2452 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2452:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2455:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2452Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2455Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2455 f r x y z) (slots617.atReg 2465 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2455 10 2465 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2455 2459 2456 f r row2455)
    (slots617.pos_y 2455 2459 2456 f r row2455)
    (slots617.inc_z 2456 2457 f r row2456 (Or.inl (by decide)))
    (slots617.inc_x 2457 2458 f r row2457 (Or.inl (by decide)))
    (slots617.jump 2458 2455 f r row2458)
    (slots617.zero_x 2459 2465 2460 f r row2459)
    (slots617.pos_x 2459 2465 2460 f r row2459)
    (slots617.inc_z 2460 2461 f r row2460 (Or.inl (by decide)))
    (slots617.zero_x 2461 2464 2462 f r row2461)
    (slots617.pos_x 2461 2464 2462 f r row2461)
    (slots617.inc_y 2462 2463 f r row2462 (Or.inl (by decide)))
    (slots617.jump 2463 2461 f r row2463)
    (slots617.jump 2464 2455 f r row2464)

theorem site2455 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2455:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2465:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2455Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2465Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2465 f r x y z) (slots710.atReg 2469 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2465 4 2469 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2465 2469 2466 f r row2465)
    (slots710.pos_x 2465 2469 2466 f r row2465)
    (slots710.inc_y 2466 2467 f r row2466 (Or.inl (by decide)))
    (slots710.inc_y 2467 2468 f r row2467 (Or.inl (by decide)))
    (slots710.jump 2468 2465 f r row2468)

theorem site2465 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2465:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2469:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2465Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2469 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2469:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2470:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2469 _ row2469]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2470Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2470 f r x y z) (slots160.atReg 2473 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2470 3 2473 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2470 2473 2471 f r row2470)
    (slots160.pos_x 2470 2473 2471 f r row2470)
    (slots160.inc_y 2471 2472 f r row2471 (Or.inl (by decide)))
    (slots160.jump 2472 2470 f r row2472)

theorem site2470 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2470:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2473:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2470Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2473Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2473 f r x y z) (slots210.atReg 2476 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2473 3 2476 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2473 2476 2474 f r row2473)
    (slots210.pos_x 2473 2476 2474 f r row2473)
    (slots210.inc_y 2474 2475 f r row2474 (Or.inl (by decide)))
    (slots210.jump 2475 2473 f r row2475)

theorem site2473 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2473:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2476:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2473Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2476Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2476 f r x y z) (slots617.atReg 2486 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2476 10 2486 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2476 2480 2477 f r row2476)
    (slots617.pos_y 2476 2480 2477 f r row2476)
    (slots617.inc_z 2477 2478 f r row2477 (Or.inl (by decide)))
    (slots617.inc_x 2478 2479 f r row2478 (Or.inl (by decide)))
    (slots617.jump 2479 2476 f r row2479)
    (slots617.zero_x 2480 2486 2481 f r row2480)
    (slots617.pos_x 2480 2486 2481 f r row2480)
    (slots617.inc_z 2481 2482 f r row2481 (Or.inl (by decide)))
    (slots617.zero_x 2482 2485 2483 f r row2482)
    (slots617.pos_x 2482 2485 2483 f r row2482)
    (slots617.inc_y 2483 2484 f r row2483 (Or.inl (by decide)))
    (slots617.jump 2484 2482 f r row2484)
    (slots617.jump 2485 2476 f r row2485)

theorem site2476 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2476:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2486:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2476Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2486Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2486 f r x y z) (slots720.atReg 2489 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2486 3 2489 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2486 2489 2487 f r row2486)
    (slots720.pos_x 2486 2489 2487 f r row2486)
    (slots720.inc_y 2487 2488 f r row2487 (Or.inl (by decide)))
    (slots720.jump 2488 2486 f r row2488)

theorem site2486 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2486:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2489:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2486Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2489Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2489 f r x y z) (slots561.atReg 2493 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2489 4 2493 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2489 2493 2490 f r row2489)
    (slots561.pos_x 2489 2493 2490 f r row2489)
    (slots561.inc_y 2490 2491 f r row2490 (Or.inl (by decide)))
    (slots561.inc_z 2491 2492 f r row2491 (Or.inl (by decide)))
    (slots561.jump 2492 2489 f r row2492)

theorem site2489 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2489:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2493:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2489Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site2493Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2493 f r x y z) (slots650.atReg 2496 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2493 3 2496 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2493 2496 2494 f r row2493)
    (slots650.pos_x 2493 2496 2494 f r row2493)
    (slots650.inc_y 2494 2495 f r row2494 (Or.inl (by decide)))
    (slots650.jump 2495 2493 f r row2495)

theorem site2493 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2493:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2496:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2493Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site2496Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2496 f r x y z) (slots267.atReg 2504 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2496 8 2504 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2496 2504 2497 f r row2496)
    (slots267.pos_x 2496 2504 2497 f r row2496)
    (slots267.inc_z 2497 2498 f r row2497 (Or.inl (by decide)))
    (slots267.zero_y 2498 2500 2499 f r row2498)
    (slots267.pos_y 2498 2500 2499 f r row2498)
    (slots267.jump 2499 2503 f r row2499)
    (slots267.zero_z 2500 2503 2501 f r row2500)
    (slots267.pos_z 2500 2503 2501 f r row2500)
    (slots267.inc_y 2501 2502 f r row2501 (Or.inl (by decide)))
    (slots267.jump 2502 2500 f r row2502)
    (slots267.jump 2503 2496 f r row2503)

theorem site2496 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2496:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2504:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2496Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2504Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2504 f r x y z) (slots720.atReg 2507 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2504 3 2507 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2504 2507 2505 f r row2504)
    (slots720.pos_x 2504 2507 2505 f r row2504)
    (slots720.inc_y 2505 2506 f r row2505 (Or.inl (by decide)))
    (slots720.jump 2506 2504 f r row2506)

theorem site2504 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2504:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2507:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2504Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2507Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2507 f r x y z) (slots617.atReg 2517 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2507 10 2517 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2507 2511 2508 f r row2507)
    (slots617.pos_y 2507 2511 2508 f r row2507)
    (slots617.inc_z 2508 2509 f r row2508 (Or.inl (by decide)))
    (slots617.inc_x 2509 2510 f r row2509 (Or.inl (by decide)))
    (slots617.jump 2510 2507 f r row2510)
    (slots617.zero_x 2511 2517 2512 f r row2511)
    (slots617.pos_x 2511 2517 2512 f r row2511)
    (slots617.inc_z 2512 2513 f r row2512 (Or.inl (by decide)))
    (slots617.zero_x 2513 2516 2514 f r row2513)
    (slots617.pos_x 2513 2516 2514 f r row2513)
    (slots617.inc_y 2514 2515 f r row2514 (Or.inl (by decide)))
    (slots617.jump 2515 2513 f r row2515)
    (slots617.jump 2516 2507 f r row2516)

theorem site2507 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2507:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2517:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2507Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2517Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2517 f r x y z) (slots710.atReg 2521 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2517 4 2521 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2517 2521 2518 f r row2517)
    (slots710.pos_x 2517 2521 2518 f r row2517)
    (slots710.inc_y 2518 2519 f r row2518 (Or.inl (by decide)))
    (slots710.inc_y 2519 2520 f r row2519 (Or.inl (by decide)))
    (slots710.jump 2520 2517 f r row2520)

theorem site2517 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2517:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2521:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2517Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2521 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2521:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2522:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2521 _ row2521]
  simp [perform,chooseZero,vector,readReg,writeReg]

end PA192.ModelSearch.RegisterSource.Certified
