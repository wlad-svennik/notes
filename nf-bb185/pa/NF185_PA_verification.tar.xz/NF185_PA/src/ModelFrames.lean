module
public import ModelFinite
public import ModelSimulation
public import ModelBoot
public import LiteralPaths

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 5000000
set_option maxRecDepth 12000

noncomputable def rayLit : List Bool → V → V
| [],x => x
| b::w,x => 2*rayLit w x+(b.toNat : V)

instance rayLitDef (w : List Bool) : Language.DefinableFunction₁ ℒₒᵣ (rayLit w : V→V) := by
  induction w with
  | nil => change Language.DefinableFunction₁ ℒₒᵣ (id:V→V); definability
  | cons b w ih => simp only [rayLit]; definability

noncomputable def rayRep (w : List Bool) (n x : V) := iterate (rayLit w) n x
instance rayRepDef (w : List Bool) : Language.DefinableFunction₂ ℒₒᵣ (rayRep w : V→V→V) := by unfold rayRep; infer_instance

theorem payload_lit (w : List Bool) (x : V) : payload (literal w x)=rayLit w (payload x) := by
  induction w with
  | nil => rfl
  | cons b w ih => simp only [literal,rayLit,payload_push _ _ (bool_num b),ih]
theorem payload_repeat (w : List Bool) (x : V) :
    ∀ k : V, payload (repeatW w k x)=rayRep w k (payload x) := by
  apply modelInduct
  · definability
  · simp [rayRep]
  · intro k ih; simp only [repeat_succ,payload_lit,rayRep,iterate_succ]; exact congrArg (rayLit w) ih

def naturalLit : List Bool → Nat → Nat
| [],x => x | b::w,x => 2*naturalLit w x+b.toNat
def naturalRep (w : List Bool) (n x : Nat) := (naturalLit w)^[n] x
theorem rayLit_cast (w : List Bool) (x : Nat) : rayLit w (x:V)=(naturalLit w x : Nat) := by
  induction w with
  | nil => rfl
  | cons b w ih => simp [rayLit,naturalLit,ih]
theorem rayRep_cast (w : List Bool) (n x : Nat) : rayRep w (n:V) (x:V)=(naturalRep w n x : Nat) := by
  induction n with
  | zero => simp [rayRep,naturalRep]
  | succ k ih =>
    change rayRep w (↑(k+1):V) (x:V) = ↑(naturalRep w (k+1) x)
    rw [Nat.cast_succ,rayRep,iterate_succ,← rayRep,ih,rayLit_cast]
    simp only [naturalRep,Function.iterate_succ_apply']

noncomputable def blockCount (k : Nat) (flag r : V) :=
  if k=0 then chooseZero flag (RegisterSource.readReg k r+2) 1
  else RegisterSource.readReg k r+2
instance blockCountDef (k : Nat) : Language.DefinableFunction₂ ℒₒᵣ (blockCount (V:=V) k) := by
  unfold blockCount; split <;> definability

noncomputable def blocks : List Nat → V → V → V → V
| [],_,_,a => a
| k::ks,f,r,a => rayLit [false] (rayRep [true] (blockCount k f r) (blocks ks f r a))
instance blocksDef (ks : List Nat) : Language.DefinableFunction₃ ℒₒᵣ (blocks (V:=V) ks) := by
  induction ks with
  | nil => change Language.DefinableFunction₃ ℒₒᵣ (fun _ _ (a:V) => a); definability
  | cons k ks ih => simp only [blocks]; definability

def registerOrder : List Nat := [2,8,1,4,3,7,0,5,6]

noncomputable def frameOf (w : List Bool) (padding : Nat) (flag r gap spare : V) : V :=
  pack 13 1 (rayLit w (rayRep [false] ((padding:V)+gap)
    (rayLit [true] (blocks registerOrder flag r (rayRep [false,true] (24+spare) 0)))))
instance frameOfDef (w : List Bool) (padding : Nat) : Language.DefinableFunction₄ ℒₒᵣ (frameOf (V:=V) w padding) := by
  unfold frameOf; definability
noncomputable def frame (p : Nat) (flag r gap spare : V) : V :=
  frameOf (pathBits p) (42-(pathBits p).length) flag r gap spare
instance frameDef (p : Nat) : Language.DefinableFunction₄ ℒₒᵣ (frame (V:=V) p) := frameOfDef _ _

def legalTag (p : Nat) (flag : V) : Prop := flag=0 ∨ flag=1 ∧ (p<3 ∨ 9<p)
instance legalTagDef (p : Nat) : Language.DefinablePred ℒₒᵣ (legalTag (V:=V) p) := by
  by_cases h : p<3 ∨ 9<p
  · change Language.DefinablePred ℒₒᵣ (fun f : V => f=0 ∨ f=1 ∧ (p<3 ∨ 9<p))
    simp only [h,and_true]; definability
  · change Language.DefinablePred ℒₒᵣ (fun f : V => f=0 ∨ f=1 ∧ (p<3 ∨ 9<p))
    simp only [h,and_false,or_false]; definability

def LiveAt (p : Nat) (s c : V) : Prop := RegisterSource.address s=(p:V) ∧
  legalTag p (RegisterSource.cold s) ∧ ∃ g k:V, c=frame p (RegisterSource.cold s) (RegisterSource.registers s) g k
private theorem liveGeneric (index : V) (tag : V→Prop) (fr : V→V→V→V→V)
    (dt : Language.DefinablePred ℒₒᵣ tag) (df : Language.DefinableFunction₄ ℒₒᵣ fr) :
    Language.DefinableRel ℒₒᵣ (fun s c : V => RegisterSource.address s=index ∧ tag (RegisterSource.cold s)
      ∧ ∃g k:V, c=fr (RegisterSource.cold s) (RegisterSource.registers s) g k) := by
  apply Language.Definable.and (by definability)
  apply Language.Definable.and (by definability)
  apply Language.Definable.exs; apply Language.Definable.exs
  apply Language.DefinableRel.comp (P := (·=·)) (by definability)
  apply Language.DefinableFunction₄.comp (F:=fr) <;> definability
instance liveAtDef (p : Nat) : Language.DefinableRel ℒₒᵣ (LiveAt (V:=V) p) :=
  liveGeneric _ _ _ (legalTagDef p) (frameDef p)

def AnyLive : List Nat → V → V → Prop
| [],_,_ => False
| p::ps,s,c => LiveAt p s c ∨ AnyLive ps s c

instance anyLiveDef (ps : List Nat) : Language.DefinableRel ℒₒᵣ (AnyLive (V:=V) ps) := by
  induction ps with
  | nil => change Language.DefinableRel ℒₒᵣ (fun (_ _ : V) => False); definability
  | cons p ps ih => simp only [AnyLive]; definability

theorem anyLive_iff (ps : List Nat) (s c : V) : AnyLive ps s c ↔ ∃ p∈ps, LiveAt p s c := by
  induction ps with
  | nil => simp [AnyLive]
  | cons q qs ih => simp [AnyLive,ih]

def Boundary (s c : V) : Prop := (RegisterSource.address s=4095 ∧ state c=192) ∨
  AnyLive (List.range 3089) s c
instance boundaryDef : Language.DefinableRel ℒₒᵣ (Boundary (V:=V)) := by unfold Boundary; definability

theorem boundary_stop (s c : V) (h : Boundary s c) (stop : RegisterSource.address s=4095) : state c=192 := by
  rcases h with h | live
  · exact h.2
  · obtain ⟨p,mem,atp⟩ := (anyLive_iff _ _ _).mp live
    have lt : p<3089 := List.mem_range.mp mem
    have co : (p:V)=(4095:Nat) := atp.1.symm.trans stop
    have eq : p=4095 := by exact_mod_cast co
    omega

/-- Live rows include the finite source guard and free register, gap, and spare parameters.
Terminal frames carry the true raw tape by their state predicate. -/
def RowSim (p : Nat) : Prop := ∀ s c : V, LiveAt p s c → ∃ t : V,
  Boundary (RegisterSource.step s) (iterate (rawStep NF192.Selected.machine) t c)

theorem allRows_simulate (rows : ∀ p : Fin 3089, RowSim (V:=V) p.val) :
    ∀ s c : V, Boundary s c → ∃ t:V, Boundary (RegisterSource.step s) (iterate (rawStep NF192.Selected.machine) t c) := by
  rintro s c (stop|live)
  · refine ⟨0,Or.inl ⟨?_,by simpa using stop.2⟩⟩
    have reconstruct : RegisterSource.config (RegisterSource.address s) (RegisterSource.cold s) (RegisterSource.registers s)=s := by
      simp [RegisterSource.config,RegisterSource.address,RegisterSource.cold,RegisterSource.registers]
    have eq : RegisterSource.config 4095 (RegisterSource.cold s) (RegisterSource.registers s)=s := by simpa only [stop.1] using reconstruct
    rw [←eq,RegisterSource.step_terminal,RegisterSource.address_config]
  · obtain ⟨p,h,atp⟩ := (anyLive_iff _ _ _).mp live
    exact rows ⟨p,List.mem_range.mp h⟩ s c atp

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.allRows_simulate
