module
public import ModelDispatch
public import EquationalSoundness
public import Foundation.FirstOrder.Arithmetic.Exponential.Log

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 2500000

instance wordSubDef : Language.DefinableFunction₂ ℒₒᵣ ((· - ·) : V → V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := subDef.val) ⟨(sub_defined (V:=V)).df⟩
instance wordLogDef : Language.DefinableFunction₁ ℒₒᵣ (log : V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := logDef.val) ⟨(log_defined (V:=V)).df⟩
instance wordExpDef : Language.DefinableFunction₁ ℒₒᵣ (Exp.exp : V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := expDef.val) ⟨(exp_defined_deltaZero (V:=V)).df⟩

noncomputable def pushW (b x : V) := 2*x+1+b
noncomputable def headW (x : V) := (x-1)%2
noncomputable def tailW (x : V) := (x-1)/2

/-- Code+1 has a leading binary sentinel. Remove just that sentinel to
obtain the little-endian ordinary ray payload, even at nonstandard width. -/
noncomputable def payload (x : V) := (x+1) - Exp.exp (log (x+1))

instance pushWDef : Language.DefinableFunction₂ ℒₒᵣ (pushW : V→V→V) := by unfold pushW; definability
instance headWDef : Language.DefinableFunction₁ ℒₒᵣ (headW : V→V) := by unfold headW; definability
instance tailWDef : Language.DefinableFunction₁ ℒₒᵣ (tailW : V→V) := by unfold tailW; definability
instance payloadDef : Language.DefinableFunction₁ ℒₒᵣ (payload : V→V) := by unfold payload; definability

theorem bool_num (b : Bool) : (b.toNat : V)=0 ∨ (b.toNat : V)=1 := by cases b <;> simp
theorem head_digit (x : V) : headW x=0 ∨ headW x=1 := mod_two _
theorem payload_zero : payload (0:V)=0 := by simp [payload]
@[simp] theorem head_zero : headW (0:V)=0 := by simp [headW]
@[simp] theorem tail_zero : tailW (0:V)=0 := by simp [tailW]

theorem word_cases (a : V) : a=0 ∨ ∃ e x, (e=0 ∨ e=1) ∧ a=pushW e x := by
  by_cases az : a=0
  · exact Or.inl az
  have one : 1≤a := pos_iff_one_le.mp (pos_iff_ne_zero.mpr az)
  have add : 1+(a-1)=a := add_tsub_cancel_of_le one
  have dm := div_add_mod (a-1) 2
  refine Or.inr ⟨(a-1)%2,(a-1)/2,mod_two _,?_⟩
  calc
    a = 1+(a-1) := add.symm
    _ = 1+(2*((a-1)/2)+(a-1)%2) := congrArg (1+·) dm.symm
    _ = pushW ((a-1)%2) ((a-1)/2) := by unfold pushW; ac_rfl

theorem head_push (e x : V) (bit : e=0 ∨ e=1) : headW (pushW e x)=e := by
  have hh : pushW e x-1=2*x+e := by
    unfold pushW
    rw [add_right_comm (2*x) 1 e,add_sub_self]
  exact (pair_digit _ x e bit hh).2

theorem tail_push (e x : V) (bit : e=0 ∨ e=1) : tailW (pushW e x)=x := by
  have hh : pushW e x-1=2*x+e := by
    unfold pushW
    rw [add_right_comm (2*x) 1 e,add_sub_self]
  exact (pair_digit _ x e bit hh).1

private theorem scale_shift (a b e : V) (h : b≤a) : (2*a+e) - 2*b = 2*(a-b)+e := by
  have add : b+(a-b)=a := add_tsub_cancel_of_le h
  have eq : 2*a+e = 2*b+(2*(a-b)+e) := calc
    _ = 2*(b+(a-b))+e := congrArg (fun z => 2*z+e) add.symm
    _ = _ := by rw [mul_add,add_assoc]
  rw [eq,add_sub_self']

theorem payload_push (e x : V) (bit : e=0 ∨ e=1) :
    payload (pushW e x)=2*payload x+e := by
  have pos : 0<x+1 := by simp
  have low := exp_log_le_self pos
  have eq : pushW e x+1 = 2*(x+1)+e := by
    unfold pushW
    rw [mul_add,mul_one,show (2:V)=1+1 from by norm_num]
    ac_rfl
  unfold payload
  rw [eq]
  rcases bit with rfl | rfl
  · simpa only [add_zero,log_two_mul_of_pos pos,exp_succ] using scale_shift (x+1) _ 0 low
  · simpa only [log_two_mul_add_one_of_pos pos,exp_succ] using scale_shift (x+1) _ 1 low

theorem payload_half (a : V) : payload a / 2 = payload (tailW a) := by
  rcases word_cases a with rfl | ⟨e,x,b,rfl⟩
  · simp [payload_zero]
  · rw [payload_push e x b,tail_push e x b]; exact (pair_digit _ _ e b rfl).1

theorem payload_low (a : V) : payload a % 2 = headW a := by
  rcases word_cases a with rfl | ⟨e,x,b,rfl⟩
  · simp [payload_zero]
  · rw [payload_push e x b,head_push e x b]; exact (pair_digit _ _ e b rfl).2

noncomputable def literal : List Bool → V → V
  | [],x => x
  | b::bs,x => pushW (b.toNat : V) (literal bs x)

instance literalDef (w : List Bool) : Language.DefinableFunction₁ ℒₒᵣ (literal w : V→V) := by
  induction w with
  | nil => change Language.DefinableFunction₁ ℒₒᵣ (id : V→V); definability
  | cons b bs ih =>
    change Language.DefinableFunction₁ ℒₒᵣ (fun x : V => pushW (b.toNat : V) (literal bs x)); definability

noncomputable def repeatW (unit : List Bool) (n a : V) := iterate (literal unit) n a
instance repeatDef (w : List Bool) : Language.DefinableFunction₂ ℒₒᵣ (repeatW w : V→V→V) := by unfold repeatW; infer_instance
@[simp] theorem repeat_zero (w : List Bool) (a : V) : repeatW w 0 a=a := iterate_zero _ _
theorem repeat_succ (w : List Bool) (n a : V) : repeatW w (n+1) a=literal w (repeatW w n a) := iterate_succ _ _ _

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.payload_push
