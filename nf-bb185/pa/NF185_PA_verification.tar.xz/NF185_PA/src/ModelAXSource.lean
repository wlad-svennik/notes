module
public import ModelRowBridge
public import ModelScanner
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified PA192.ModelSearch.RegisterFields PA192.ModelSearch.RegisterCommands
set_option maxRecDepth 8000
set_option maxHeartbeats 3500000
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem pairUnpackTwo (raw : V) : cantor (left raw) (cantor (left (right raw)) (right (right raw)))=raw := by
  rw [pairUnpack,pairUnpack]

noncomputable def batchView (f n b : V) : V :=
  atS 39 f n (left (batchBody b)) (right (batchBody b)) (batchRank b) 0 0 (batchFields b)

instance batchViewDef (f n : V) : Language.DefinableFunction₁ ℒₒᵣ (batchView f n) := by
  unfold batchView atS config vector batchBody batchRank batchFields
  definability

@[simp] theorem batchView_batch (f n r body raw : V) :
    batchView f n (batch r body raw)=atS 39 f n (left body) (right body) r 0 0 raw := by
  simp [batchView,batch,batchBody,batchRank,batchFields]

theorem batch_eta (z : V) : batch (batchRank z) (batchBody z) (batchFields z)=z := by
  simp [batch,batchRank,batchBody,batchFields]

theorem nextAny (r body raw : V) :
    nextBatch (batch (r+1) body raw) =
      batch r (front9 (left (right raw)) (left raw) r 0 body) (right (right raw)) := by
  have h := next_literal r body (left raw) (left (right raw)) (right (right raw))
  rwa [pairUnpackTwo] at h

theorem batchOnce (f n r body raw : V) :
    Reach (batchView f n (batch r body raw)) (batchView f n (nextBatch (batch r body raw))) := by
  rcases zeroOrSuccessor r with rfl|⟨j,rfl⟩
  · simp only [nextBatch,batchRank,batch,pi₁_pair,chooseZero,ite_true]
    exact Reach.refl _
  · let composed := front9 (left (right raw)) (left raw) j 0 body
    have pop := site0039Positive f n (left body) (right body) j 0 0 0 0 raw
    have emit := emitFields f n (left body) (right body) j 0 0 (left raw) (left (right raw)) (right (right raw))
    simp only [pairUnpackTwo,pairUnpack,zero_add] at emit
    have ret := site2968 f n (left composed) (right composed) j 0 0 0 0 (right (right raw))
    rw [nextAny,batchView_batch,batchView_batch]
    exact (pop.trans emit).trans ret

theorem batchMoves (f n : V) : ∀ b, Reach (batchView f n b) (batchView f n (nextBatch b)) := by
  intro b
  have h := batchOnce f n (batchRank b) (batchBody b) (batchFields b)
  rwa [batch_eta] at h

theorem batchRankFinished : ∀ r : V, ∀ body raw,
    batchRank (iterate nextBatch r (batch r body raw))=0 := by
  apply modelInduct
  · unfold batchRank batch; definability
  · intro body raw; simp [batchRank,batch]
  · intro r ih body raw
    rw [iterate_succ_left,nextAny]
    exact ih _ _

theorem batchFinish (f n b : V) (rank : batchRank b=0) :
    Reach (batchView f n b) (vm 0 f n (popAfterAX (batchBody b)) (batchFields b)) := by
  let t := left (batchBody b)
  let s := right (batchBody b)
  let w := batchFields b
  have g := site0039Zero f n t s 0 0 0 0 0 w
  have h := (g.trans (modePrepareZero f n t s 0 w)).trans (modeRight f n t s 0 0 w (by simp))
  simpa only [batchView,rank,popAfterAX,vm_state,atS,t,s,w] using h

theorem batchesRun (f n r body raw : V) :
    let b := iterate nextBatch r (batch r body raw)
    Reach (batchView f n (batch r body raw)) (vm 0 f n (popAfterAX (batchBody b)) (batchFields b)) := by
  dsimp only
  have k := simulation nextBatch (batchView f n) (batchMoves f n) (batch r body raw) r
  exact k.trans (batchFinish f n _ (batchRankFinished r body raw))

/-- One full AX command, with every extra field unconstrained, all the way from actual PC10 to PC0. -/
theorem axTagged (f n t s p h outer y d c raw : V) :
    let z := axRaw outer y d c raw (state t s h p)
    Reach (atS 10 f n t s 0 p h (cantor (c+2) (cantor outer (cantor y (cantor d raw)))))
      (vm 0 f n (pi₁ z) (pi₂ z)) := by
  dsimp only
  let tail := cantor y (cantor d raw)
  let pp := p+outer
  let body := front9 (pp+d) (h+y) c pp (cantor t s)
  have r := readFields f n t s 0 p h (c+2) outer tail
  have outerGuard := site0038Positive f n t s (c+1) pp h 0 0 tail
  have outer' : Reach (atS 38 f n t s (0+(c+2)) pp h tail) (atS 39 f n t s (c+1) pp h tail) := by
    simpa only [atS,zero_add,show c+1+1=c+2 by ring] using outerGuard
  have first := site0039Positive f n t s c pp h 0 0 tail
  have emit := emitFields f n t s c pp h y d raw
  have back := site2968 f n (left body) (right body) c 0 0 0 0 raw
  have seg : Reach (atS 10 f n t s 0 p h (cantor (c+2) (cantor outer tail)))
      (atS 39 f n (left body) (right body) c 0 0 raw) :=
    (((r.trans outer').trans first).trans emit).trans back
  have many := batchesRun f n c body raw
  rw [batchView_batch] at many
  have done := seg.trans many
  simpa only [axRaw,state,param,cache,top,stack,pi₁_pair,pi₂_pair,pp,body,tail] using done

end PA192.ModelSearch.RegisterSource.Commands
#print axioms PA192.ModelSearch.RegisterSource.Commands.axTagged
