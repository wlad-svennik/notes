module
public import ModelCommandAtoms
public import ModelIntervals
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandTakeAfter1 (f n t s c u v y d w : V) : Reach (config ((3080:Nat):V) f (vector n 0 s c u 0 0 0 w)) (config ((3084:Nat):V) f (vector n u s c 0 0 u 0 w)) := by
  have micro := site3080 f n 0 s c u 0 0 0 w
  have d1 : (0+u:V)=u := by ring
  have d6 : (0+u:V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact mid

theorem commandTake (f n t s c u v y d w : V) : Reach (config ((3080:Nat):V) f (vector n 0 s c u 0 0 0 w)) (config ((3087:Nat):V) f (vector n u s c u 0 0 0 w)) := by
  have micro := site3084 f n u s c 0 0 u 0 w
  have d4 : (0+u:V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandTakeAfter1 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
