module
public import ModelCmdEmit01
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter65 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((358:Nat):V) f (vector n ((atom12 n t s c u v y d w)+(atom12 n t s c u v y d w)) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom7 n t s c u v y d w) w)) := by
  have micro := site0350 f n ((atom12 n t s c u v y d w)+(atom12 n t s c u v y d w)) (atom10 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom10 n t s c u v y d w)):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w) := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom10 n t s c u v y d w):V)=0+(atom10 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom10 n t s c u v y d w)):V)=left (atom10 n t s c u v y d w)).trans (by change left (cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom7 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom10 n t s c u v y d w)):V)=atom7 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom10 n t s c u v y d w):V)=0+(atom10 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom10 n t s c u v y d w)):V)=right (atom10 n t s c u v y d w)).trans (by change right (cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom7 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter64 f n t s c u v y d w).trans mid

theorem commandEmitAfter66 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((361:Nat):V) f (vector n ((atom12 n t s c u v y d w)+(atom12 n t s c u v y d w)) (atom7 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) 0 w)) := by
  have micro := site0358 f n ((atom12 n t s c u v y d w)+(atom12 n t s c u v y d w)) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom7 n t s c u v y d w) w
  have d2 : (0+(atom7 n t s c u v y d w):V)=atom7 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter65 f n t s c u v y d w).trans mid

theorem commandEmitAfter67 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((371:Nat):V) f (vector n 0 (atom7 n t s c u v y d w) c (d+u) (v+y) 0 (atom13 n t s c u v y d w) w)) := by
  have micro := site0361 f n ((atom12 n t s c u v y d w)+(atom12 n t s c u v y d w)) (atom7 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) ((atom12 n t s c u v y d w)+(atom12 n t s c u v y d w))):V)=atom13 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) ((atom12 n t s c u v y d w)+(atom12 n t s c u v y d w))):V)=0+(atom13 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter66 f n t s c u v y d w).trans mid

theorem commandEmitAfter68 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((375:Nat):V) f (vector n ((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w)) (atom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0371 f n 0 (atom7 n t s c u v y d w) c (d+u) (v+y) 0 (atom13 n t s c u v y d w) w
  have d1 : (0+(2*(atom13 n t s c u v y d w)):V)=(atom13 n t s c u v y d w)+(atom13 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom13 n t s c u v y d w)):V)=0+((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter67 f n t s c u v y d w).trans mid

theorem commandEmitAfter69 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((383:Nat):V) f (vector n ((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w)) 0 c (d+u) (v+y) ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) (atom2 n t s c u v y d w) w)) := by
  have micro := site0375 f n ((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w)) (atom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom7 n t s c u v y d w)):V)=(atom6 n t s c u v y d w)+(atom6 n t s c u v y d w) := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom7 n t s c u v y d w):V)=0+(atom7 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom7 n t s c u v y d w)):V)=left (atom7 n t s c u v y d w)).trans (by change left (cantor ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) (atom2 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom7 n t s c u v y d w)):V)=atom2 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom7 n t s c u v y d w):V)=0+(atom7 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom7 n t s c u v y d w)):V)=right (atom7 n t s c u v y d w)).trans (by change right (cantor ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) (atom2 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter68 f n t s c u v y d w).trans mid

theorem commandEmitAfter70 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((386:Nat):V) f (vector n ((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w)) (atom2 n t s c u v y d w) c (d+u) (v+y) ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) 0 w)) := by
  have micro := site0383 f n ((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w)) 0 c (d+u) (v+y) ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) (atom2 n t s c u v y d w) w
  have d2 : (0+(atom2 n t s c u v y d w):V)=atom2 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter69 f n t s c u v y d w).trans mid

theorem commandEmitAfter71 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((396:Nat):V) f (vector n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) 0 (atom14 n t s c u v y d w) w)) := by
  have micro := site0386 f n ((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w)) (atom2 n t s c u v y d w) c (d+u) (v+y) ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) ((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w))):V)=atom14 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) ((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w))):V)=0+(atom14 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter70 f n t s c u v y d w).trans mid

theorem commandEmitAfter72 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((400:Nat):V) f (vector n ((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)) (atom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0396 f n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) 0 (atom14 n t s c u v y d w) w
  have d1 : (0+(2*(atom14 n t s c u v y d w)):V)=(atom14 n t s c u v y d w)+(atom14 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom14 n t s c u v y d w)):V)=0+((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter71 f n t s c u v y d w).trans mid

theorem commandEmitAfter73 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((403:Nat):V) f (vector n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) ((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)) 0 w)) := by
  have micro := site0400 f n ((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)) (atom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)):V)=(atom14 n t s c u v y d w)+(atom14 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter72 f n t s c u v y d w).trans mid

theorem commandEmitAfter74 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((406:Nat):V) f (vector n (atom2 n t s c u v y d w) 0 c (d+u) (v+y) ((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)) 0 w)) := by
  have micro := site0403 f n 0 (atom2 n t s c u v y d w) c (d+u) (v+y) ((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)) 0 w
  have d1 : (0+(atom2 n t s c u v y d w):V)=atom2 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter73 f n t s c u v y d w).trans mid

theorem commandEmitAfter75 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((416:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom15 n t s c u v y d w) w)) := by
  have micro := site0406 f n (atom2 n t s c u v y d w) 0 c (d+u) (v+y) ((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)) (atom2 n t s c u v y d w)):V)=atom15 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)) (atom2 n t s c u v y d w)):V)=0+(atom15 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter74 f n t s c u v y d w).trans mid

theorem commandEmitAfter76 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((419:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0416 f n 0 0 c (d+u) (v+y) 0 (atom15 n t s c u v y d w) w
  have d2 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter75 f n t s c u v y d w).trans mid

theorem commandEmitAfter77 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((423:Nat):V) f (vector n (d+u) (atom15 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0419 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter76 f n t s c u v y d w).trans mid

theorem commandEmitAfter78 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((426:Nat):V) f (vector n (d+u) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0423 f n (d+u) (atom15 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter77 f n t s c u v y d w).trans mid

theorem commandEmitAfter79 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((429:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0426 f n (d+u) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter78 f n t s c u v y d w).trans mid

theorem commandEmitAfter80 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((432:Nat):V) f (vector n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0429 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter79 f n t s c u v y d w).trans mid

theorem commandEmitAfter81 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((442:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom16 n t s c u v y d w) w)) := by
  have micro := site0432 f n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom15 n t s c u v y d w)):V)=atom16 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom15 n t s c u v y d w)):V)=0+(atom16 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter80 f n t s c u v y d w).trans mid

theorem commandEmitAfter82 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((445:Nat):V) f (vector n 0 (atom16 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0442 f n 0 0 c (d+u) (v+y) 0 (atom16 n t s c u v y d w) w
  have d2 : (0+(atom16 n t s c u v y d w):V)=atom16 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter81 f n t s c u v y d w).trans mid

theorem commandEmitAfter83 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((449:Nat):V) f (vector n (v+y) (atom16 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0445 f n 0 (atom16 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter82 f n t s c u v y d w).trans mid

theorem commandEmitAfter84 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((452:Nat):V) f (vector n (v+y) (atom16 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0449 f n (v+y) (atom16 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter83 f n t s c u v y d w).trans mid

theorem commandEmitAfter85 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((460:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom15 n t s c u v y d w) w)) := by
  have micro := site0452 f n (v+y) (atom16 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom16 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom16 n t s c u v y d w):V)=0+(atom16 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom16 n t s c u v y d w)):V)=left (atom16 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom15 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom16 n t s c u v y d w)):V)=atom15 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom16 n t s c u v y d w):V)=0+(atom16 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom16 n t s c u v y d w)):V)=right (atom16 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom15 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter84 f n t s c u v y d w).trans mid

theorem commandEmitAfter86 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((463:Nat):V) f (vector n (v+y) (atom15 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0460 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom15 n t s c u v y d w) w
  have d2 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter85 f n t s c u v y d w).trans mid

theorem commandEmitAfter87 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((473:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site0463 f n (v+y) (atom15 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter86 f n t s c u v y d w).trans mid

theorem commandEmitAfter88 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((477:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0473 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter87 f n t s c u v y d w).trans mid

theorem commandEmitAfter89 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((478:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0477 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter88 f n t s c u v y d w).trans mid

theorem commandEmitAfter90 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((481:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0478 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter89 f n t s c u v y d w).trans mid

theorem commandEmitAfter91 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((484:Nat):V) f (vector n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0481 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter90 f n t s c u v y d w).trans mid

theorem commandEmitAfter92 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((494:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom18 n t s c u v y d w) w)) := by
  have micro := site0484 f n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w)):V)=atom18 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w)):V)=0+(atom18 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter91 f n t s c u v y d w).trans mid

theorem commandEmitAfter93 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((497:Nat):V) f (vector n 0 (atom18 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0494 f n 0 0 c (d+u) (v+y) 0 (atom18 n t s c u v y d w) w
  have d2 : (0+(atom18 n t s c u v y d w):V)=atom18 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter92 f n t s c u v y d w).trans mid

theorem commandEmitAfter94 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((501:Nat):V) f (vector n (v+y) (atom18 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0497 f n 0 (atom18 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter93 f n t s c u v y d w).trans mid

theorem commandEmitAfter95 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((504:Nat):V) f (vector n (v+y) (atom18 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0501 f n (v+y) (atom18 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter94 f n t s c u v y d w).trans mid

theorem commandEmitAfter96 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((512:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w) w)) := by
  have micro := site0504 f n (v+y) (atom18 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom18 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom18 n t s c u v y d w):V)=0+(atom18 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom18 n t s c u v y d w)):V)=left (atom18 n t s c u v y d w)).trans (by change left (cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom18 n t s c u v y d w)):V)=atom15 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom18 n t s c u v y d w):V)=0+(atom18 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom18 n t s c u v y d w)):V)=right (atom18 n t s c u v y d w)).trans (by change right (cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter95 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
