module
public import ModelCmdEmit07
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter257 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1270:Nat):V) f (vector n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1269 f n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w))+1:V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter256 f n t s c u v y d w).trans mid

theorem commandEmitAfter258 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1273:Nat):V) f (vector n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1270 f n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter257 f n t s c u v y d w).trans mid

theorem commandEmitAfter259 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1276:Nat):V) f (vector n (atom44 n t s c u v y d w) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1273 f n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom44 n t s c u v y d w):V)=atom44 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter258 f n t s c u v y d w).trans mid

theorem commandEmitAfter260 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1286:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom46 n t s c u v y d w) w)) := by
  have micro := site1276 f n (atom44 n t s c u v y d w) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom44 n t s c u v y d w)):V)=atom46 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom44 n t s c u v y d w)):V)=0+(atom46 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter259 f n t s c u v y d w).trans mid

theorem commandEmitAfter261 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1289:Nat):V) f (vector n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1286 f n 0 0 c (d+u) (v+y) 0 (atom46 n t s c u v y d w) w
  have d2 : (0+(atom46 n t s c u v y d w):V)=atom46 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter260 f n t s c u v y d w).trans mid

theorem commandEmitAfter262 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1293:Nat):V) f (vector n c (atom46 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site1289 f n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+c:V)=c := by ring
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter261 f n t s c u v y d w).trans mid

theorem commandEmitAfter263 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1296:Nat):V) f (vector n c (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1293 f n c (atom46 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter262 f n t s c u v y d w).trans mid

theorem commandEmitAfter264 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1299:Nat):V) f (vector n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1296 f n c (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter263 f n t s c u v y d w).trans mid

theorem commandEmitAfter265 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1302:Nat):V) f (vector n (atom46 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w)) := by
  have micro := site1299 f n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d1 : (0+(atom46 n t s c u v y d w):V)=atom46 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter264 f n t s c u v y d w).trans mid

theorem commandEmitAfter266 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1312:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom47 n t s c u v y d w) w)) := by
  have micro := site1302 f n (atom46 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w
  have d7 : (0+(cantor c (atom46 n t s c u v y d w)):V)=atom47 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor c (atom46 n t s c u v y d w)):V)=0+(atom47 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter265 f n t s c u v y d w).trans mid

theorem commandEmitAfter267 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1315:Nat):V) f (vector n 0 (atom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1312 f n 0 0 c (d+u) (v+y) 0 (atom47 n t s c u v y d w) w
  have d2 : (0+(atom47 n t s c u v y d w):V)=atom47 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter266 f n t s c u v y d w).trans mid

theorem commandEmitAfter268 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1319:Nat):V) f (vector n (v+y) (atom47 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1315 f n 0 (atom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter267 f n t s c u v y d w).trans mid

theorem commandEmitAfter269 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1322:Nat):V) f (vector n (v+y) (atom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1319 f n (v+y) (atom47 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter268 f n t s c u v y d w).trans mid

theorem commandEmitAfter270 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1330:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) c (atom46 n t s c u v y d w) w)) := by
  have micro := site1322 f n (v+y) (atom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom47 n t s c u v y d w)):V)=c := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom47 n t s c u v y d w):V)=0+(atom47 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom47 n t s c u v y d w)):V)=left (atom47 n t s c u v y d w)).trans (by change left (cantor c (atom46 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom47 n t s c u v y d w)):V)=atom46 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom47 n t s c u v y d w):V)=0+(atom47 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom47 n t s c u v y d w)):V)=right (atom47 n t s c u v y d w)).trans (by change right (cantor c (atom46 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter269 f n t s c u v y d w).trans mid

theorem commandEmitAfter271 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1333:Nat):V) f (vector n (v+y) (atom46 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1330 f n (v+y) 0 c (d+u) (v+y) c (atom46 n t s c u v y d w) w
  have d2 : (0+(atom46 n t s c u v y d w):V)=atom46 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter270 f n t s c u v y d w).trans mid

theorem commandEmitAfter272 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1343:Nat):V) f (vector n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) 0 (atom30 n t s c u v y d w) w)) := by
  have micro := site1333 f n (v+y) (atom46 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d7 : (0+(cantor c (v+y)):V)=atom30 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor c (v+y)):V)=0+(atom30 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter271 f n t s c u v y d w).trans mid

theorem commandEmitAfter273 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1347:Nat):V) f (vector n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)) (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1343 f n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) 0 (atom30 n t s c u v y d w) w
  have d1 : (0+(2*(atom30 n t s c u v y d w)):V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom30 n t s c u v y d w)):V)=0+((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter272 f n t s c u v y d w).trans mid

theorem commandEmitAfter274 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1348:Nat):V) f (vector n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1347 f n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)) (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w))+1:V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter273 f n t s c u v y d w).trans mid

theorem commandEmitAfter275 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1351:Nat):V) f (vector n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1348 f n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1):V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter274 f n t s c u v y d w).trans mid

theorem commandEmitAfter276 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1354:Nat):V) f (vector n (atom46 n t s c u v y d w) 0 c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1351 f n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom46 n t s c u v y d w):V)=atom46 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter275 f n t s c u v y d w).trans mid

theorem commandEmitAfter277 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1364:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom48 n t s c u v y d w) w)) := by
  have micro := site1354 f n (atom46 n t s c u v y d w) 0 c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom46 n t s c u v y d w)):V)=atom48 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom46 n t s c u v y d w)):V)=0+(atom48 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter276 f n t s c u v y d w).trans mid

theorem commandEmitAfter278 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1367:Nat):V) f (vector n 0 (atom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1364 f n 0 0 c (d+u) (v+y) 0 (atom48 n t s c u v y d w) w
  have d2 : (0+(atom48 n t s c u v y d w):V)=atom48 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter277 f n t s c u v y d w).trans mid

theorem commandEmitAfter279 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1371:Nat):V) f (vector n (d+u) (atom48 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1367 f n 0 (atom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter278 f n t s c u v y d w).trans mid

theorem commandEmitAfter280 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1374:Nat):V) f (vector n (d+u) (atom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1371 f n (d+u) (atom48 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter279 f n t s c u v y d w).trans mid

theorem commandEmitAfter281 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1377:Nat):V) f (vector n 0 (atom48 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1374 f n (d+u) (atom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter280 f n t s c u v y d w).trans mid

theorem commandEmitAfter282 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1380:Nat):V) f (vector n (atom48 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1377 f n 0 (atom48 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom48 n t s c u v y d w):V)=atom48 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter281 f n t s c u v y d w).trans mid

theorem commandEmitAfter283 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1390:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom49 n t s c u v y d w) w)) := by
  have micro := site1380 f n (atom48 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom48 n t s c u v y d w)):V)=atom49 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom48 n t s c u v y d w)):V)=0+(atom49 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter282 f n t s c u v y d w).trans mid

theorem commandEmitAfter284 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1393:Nat):V) f (vector n 0 (atom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1390 f n 0 0 c (d+u) (v+y) 0 (atom49 n t s c u v y d w) w
  have d2 : (0+(atom49 n t s c u v y d w):V)=atom49 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter283 f n t s c u v y d w).trans mid

theorem commandEmitAfter285 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1397:Nat):V) f (vector n (v+y) (atom49 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1393 f n 0 (atom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter284 f n t s c u v y d w).trans mid

theorem commandEmitAfter286 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1400:Nat):V) f (vector n (v+y) (atom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1397 f n (v+y) (atom49 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter285 f n t s c u v y d w).trans mid

theorem commandEmitAfter287 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1408:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom48 n t s c u v y d w) w)) := by
  have micro := site1400 f n (v+y) (atom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom49 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom49 n t s c u v y d w):V)=0+(atom49 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom49 n t s c u v y d w)):V)=left (atom49 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom48 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom49 n t s c u v y d w)):V)=atom48 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom49 n t s c u v y d w):V)=0+(atom49 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom49 n t s c u v y d w)):V)=right (atom49 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom48 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter286 f n t s c u v y d w).trans mid

theorem commandEmitAfter288 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1411:Nat):V) f (vector n (v+y) (atom48 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1408 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom48 n t s c u v y d w) w
  have d2 : (0+(atom48 n t s c u v y d w):V)=atom48 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter287 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
