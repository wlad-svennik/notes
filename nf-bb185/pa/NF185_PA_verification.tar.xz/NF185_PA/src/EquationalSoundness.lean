module
public import CodedNumerals
public import Foundation.FirstOrder.Arithmetic.PeanoMinus.Functions

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Numerals.FoundationRoute

namespace PA192.PhysicalModel

/-- The numerical backend needs five unary constructors/operations and
three kinds of binary operation. Pairing builds the four-field records. -/
inductive UOp | bit0 | bit1 | step | norm | state deriving DecidableEq
inductive BOp | pair | run | repeatWord (w : List Bool) deriving DecidableEq

inductive Term
  | var (i : Nat) | numeral (n : Nat)
  | succ (t : Term)
  | add (s t : Term) | sub (s t : Term) | mul (s t : Term)
  | un (op : UOp) (t : Term) | bin (op : BOp) (s t : Term)
  deriving DecidableEq

/-- All the remaining mathematical parameters must be definable. No external
predicate is admitted as an induction instance over a nonstandard model. -/
structure Operations (V : Type) where
  u : UOp → V → V
  b : BOp → V → V → V

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
private instance plainSub : Language.DefinableFunction₂ ℒₒᵣ ((· - ·) : V → V → V) :=
  FFL.FirstOrder.Defined.to_definable (φ := subDef.val) ⟨(sub_defined (V := V)).df⟩

structure Defined (o : Operations V) : Prop where
  unary : ∀ f, Language.DefinableFunction₁ ℒₒᵣ (o.u f)
  binary : ∀ f, Language.DefinableFunction₂ ℒₒᵣ (o.b f)

noncomputable def Term.val (o : Operations V) (ρ : Nat → V) : Term → V
  | .var i => ρ i | .numeral k => k
  | .succ t => t.val o ρ+1
  | .add s t => s.val o ρ+t.val o ρ
  | .sub s t => s.val o ρ-t.val o ρ
  | .mul s t => s.val o ρ*t.val o ρ
  | .un f t => o.u f (t.val o ρ)
  | .bin f s t => o.b f (s.val o ρ) (t.val o ρ)

def Term.subst (σ : Nat → Term) : Term → Term
  | .var i => σ i | .numeral k => .numeral k
  | .succ t => .succ (t.subst σ)
  | .add s t => .add (s.subst σ) (t.subst σ)
  | .sub s t => .sub (s.subst σ) (t.subst σ)
  | .mul s t => .mul (s.subst σ) (t.subst σ)
  | .un f t => .un f (t.subst σ)
  | .bin f s t => .bin f (s.subst σ) (t.subst σ)

def Term.replace (t : Term) (i : Nat) (x : Term) :=
  t.subst (Function.update Term.var i x)

theorem Term.val_subst (t : Term) (o : Operations V) (ρ : Nat → V) (σ : Nat → Term) :
    (t.subst σ).val o ρ = t.val o (fun j => (σ j).val o ρ) := by
  induction t <;> simp [subst,val, *]

theorem Term.val_replace (t : Term) (o : Operations V) (ρ : Nat → V) (i : Nat) (x : Term) :
    (t.replace i x).val o ρ = t.val o (Function.update ρ i (x.val o ρ)) := by
  rw [replace,val_subst]
  congr 1
  funext j
  by_cases e : j=i <;> simp [e,Function.update,val]

def Term.fresh (i : Nat) : Term → Prop
  | .var j => j ≠ i | .numeral _ => True
  | .succ a | .un _ a => a.fresh i
  | .add a b | .sub a b | .mul a b | .bin _ a b => a.fresh i ∧ b.fresh i

theorem Term.val_fresh (t : Term) (o : Operations V) (ρ : Nat → V) (i : Nat) (x : V)
    (h : t.fresh i) : t.val o (Function.update ρ i x) = t.val o ρ := by
  induction t with
  | var j => exact Function.update_of_ne h _ _
  | numeral n => rfl
  | succ t ih => simp [val,ih h]
  | un u t ih => simp [val,ih h]
  | add s t a b | sub s t a b | mul s t a b | bin _ s t a b =>
    simp [val,a h.1,b h.2]

theorem Term.val_def (t : Term) (o : Operations V) (d : Defined o)
    (v : Nat → V → V) (hv : ∀ j, Language.DefinableFunction₁ ℒₒᵣ (v j)) :
    Language.DefinableFunction₁ ℒₒᵣ (fun x => t.val o (fun i => v i x)) := by
  induction t with
  | var i => exact hv i
  | numeral n => simp only [val]; definability
  | succ a ih => simp only [val]; definability
  | add a b l r | mul a b l r | sub a b l r => simp only [val]; definability
  | un f a h =>
    let _ := d.unary f
    simp only [val]; definability
  | bin f a b l r =>
    let _ := d.binary f
    simp only [val]; definability

structure Equation where
  lhs : Term
  rhs : Term
  deriving DecidableEq

noncomputable def Equation.Holds (o : Operations V) (ρ : Nat → V) (e : Equation) :=
  e.lhs.val o ρ=e.rhs.val o ρ

def Equation.replace (e : Equation) (i : Nat) (x : Term) : Equation :=
  ⟨e.lhs.replace i x,e.rhs.replace i x⟩

def Equation.subst (e : Equation) (σ : Nat → Term) : Equation :=
  ⟨e.lhs.subst σ,e.rhs.subst σ⟩

theorem Equation.holds_replace (o : Operations V) (ρ : Nat → V) (e : Equation) (i : Nat) (t : Term) :
    (e.replace i t).Holds o ρ ↔ e.Holds o (Function.update ρ i (t.val o ρ)) := by
  simp [Holds,replace,Term.val_replace]

theorem Equation.holds_subst (o : Operations V) (ρ : Nat → V) (e : Equation) (σ : Nat → Term) :
    (e.subst σ).Holds o ρ ↔ e.Holds o (fun j => (σ j).val o ρ) := by
  simp [Holds,subst,Term.val_subst]

theorem Equation.arith (o : Operations V) (d : Defined o) (ρ : Nat → V) (e : Equation) (i : Nat) :
    Language.DefinablePred ℒₒᵣ (fun x => e.Holds o (Function.update ρ i x)) := by
  have vars (j : Nat) : Language.DefinableFunction₁ ℒₒᵣ (fun x : V => Function.update ρ i x j) := by
    by_cases ne : j=i <;> simp [ne,Function.update] <;> definability
  let _ := Term.val_def e.lhs o d (fun j x => Function.update ρ i x j) vars
  let _ := Term.val_def e.rhs o d (fun j x => Function.update ρ i x j) vars
  unfold Holds
  definability


def subGuard (bound : Term) (i : Nat) : Equation :=
  ⟨.sub bound (.var i),.succ (.sub bound (.succ (.var i)))⟩

/-- Open steps use only the displayed rigid equalities. In particular,
an induction hypothesis has no universally instantiable parameters. -/
inductive Derives (axiomSet : Equation → Prop) : List Equation → Equation → Prop
  | schema {Γ e} (source : axiomSet e) : Derives axiomSet Γ e
  | hyp {Γ e} (h : e ∈ Γ) : Derives axiomSet Γ e
  | refl {Γ a} : Derives axiomSet Γ ⟨a,a⟩
  | symm {Γ a b} (h : Derives axiomSet Γ ⟨a,b⟩) : Derives axiomSet Γ ⟨b,a⟩
  | trans {Γ a b c} (h : Derives axiomSet Γ ⟨a,b⟩) (k : Derives axiomSet Γ ⟨b,c⟩) :
      Derives axiomSet Γ ⟨a,c⟩
  | congr {Γ a b} (t : Term) (i : Nat) (h : Derives axiomSet Γ ⟨a,b⟩) :
      Derives axiomSet Γ ⟨t.replace i a,t.replace i b⟩
  | inst {Γ e} (σ : Nat → Term) (h : Derives axiomSet [] e) :
      Derives axiomSet Γ (e.subst σ)
  | induct {Γ e} (i : Nat)
      (base : Derives axiomSet [] (e.replace i (.numeral 0)))
      (next : Derives axiomSet [e] (e.replace i (.succ (.var i)))) : Derives axiomSet Γ e
  | bounded {Γ e} (i : Nat) (bound : Term) (fresh : bound.fresh i)
      (base : Derives axiomSet [] (e.replace i (.numeral 0)))
      (next : Derives axiomSet [e,subGuard bound i] (e.replace i (.succ (.var i)))) :
      Derives axiomSet Γ (e.replace i bound)

abbrev ValidAt (o : Operations V) (Γ : List Equation) (e : Equation) : Prop :=
  ∀ ρ, (∀ h ∈ Γ, h.Holds o ρ) → e.Holds o ρ

private theorem nil_holds (o : Operations V) (ρ : Nat → V) :
    ∀ h ∈ ([] : List Equation), h.Holds o ρ := by simp

theorem ordinary_sound (o : Operations V) (d : Defined o) (e : Equation) (i : Nat)
    (b : ValidAt o [] (e.replace i (.numeral 0)))
    (s : ValidAt o [e] (e.replace i (.succ (.var i)))) (ρ : Nat → V) : e.Holds o ρ := by
  have run : ∀ x : V, e.Holds o (Function.update ρ i x) := by
    apply induction_of_arith (arithPred_of_definable (Equation.arith o d ρ e i))
    · have h := (Equation.holds_replace o ρ e i _).mp (b ρ (nil_holds o ρ))
      simpa [Term.val,rob] using h
    · intro x hx
      have hp : ∀ g ∈ [e], g.Holds o (Function.update ρ i x) := by simpa using hx
      have h := (Equation.holds_replace o _ e i _).mp (s _ hp)
      simpa [Term.val,rob] using h
  simpa using run (ρ i)

theorem bounded_sound (o : Operations V) (d : Defined o) (e : Equation) (i : Nat)
    (bound : Term) (fresh : bound.fresh i)
    (b : ValidAt o [] (e.replace i (.numeral 0)))
    (s : ValidAt o [e,subGuard bound i] (e.replace i (.succ (.var i)))) (ρ : Nat → V) :
    (e.replace i bound).Holds o ρ := by
  let k := bound.val o ρ
  have run : ∀ x : V, x ≤ k → e.Holds o (Function.update ρ i x) := by
    apply induction_of_arith
    · apply arithPred_of_definable
      let _ := Equation.arith o d ρ e i
      definability
    · intro _
      have h := (Equation.holds_replace o ρ e i _).mp (b ρ (nil_holds o ρ))
      simpa [Term.val,rob] using h
    · intro x hx sx
      change x+1 ≤ k at sx
      have lt : x<k := lt_iff_succ_le.mpr sx
      have hx' := hx (le_of_lt lt)
      have sub : k-x = k-(x+1)+1 := by
        simpa using (sub_succ_add_succ lt (0:V)).symm
      have guard : (subGuard bound i).Holds o (Function.update ρ i x) := by
        simpa [subGuard,Equation.Holds,Term.val,bound.val_fresh o ρ i x fresh,k] using sub
      have hp : ∀ g ∈ [e,subGuard bound i], g.Holds o (Function.update ρ i x) := by
        simpa using And.intro hx' guard
      have h := (Equation.holds_replace o _ e i _).mp (s _ hp)
      simpa [Term.val,rob] using h
  exact (Equation.holds_replace o ρ e i bound).mpr (run k (le_refl _))

/-- Soundness covers arbitrary, including nonstandard, data and time values.
Only the primitive operation equations from the numerical normalizer are
assumptions. Every logical and induction rule is discharged here. -/
theorem derivation_sound {A : Equation → Prop} (o : Operations V) (d : Defined o)
    (interpret : ∀ e, A e → ∀ ρ, e.Holds o ρ) {Γ e} (proof : Derives A Γ e) :
    ValidAt o Γ e := by
  induction proof with
  | schema h => exact fun ρ _ => interpret _ h ρ
  | hyp h => exact fun ρ hs => hs _ h
  | refl => exact fun _ _ => rfl
  | symm _ ih => exact fun ρ hs => (ih ρ hs).symm
  | trans _ _ ih ik => exact fun ρ hs => (ih ρ hs).trans (ik ρ hs)
  | congr t i _ ih =>
    intro ρ hs
    have h := ih ρ hs
    unfold Equation.Holds at h ⊢
    simp only [Term.val_replace,h]
  | inst σ _ ih =>
    intro ρ _
    exact (Equation.holds_subst o ρ _ σ).mpr (ih _ (nil_holds o _))
  | induct i _ _ ib it => exact fun ρ _ => ordinary_sound o d _ i ib it ρ
  | bounded i bound fresh _ _ ib it => exact fun ρ _ => bounded_sound o d _ i bound fresh ib it ρ

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.derivation_sound

