module
public import ModelMargin
public import VerifiedWire

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 2500000

/-- A fixed number of copies followed by one optional arbitrary-width copy block. -/
structure Width where
  fixed : Nat
  growth : Option Nat
  deriving DecidableEq

def nVar (i : Nat) := (i+1)*3
def wVar (i : Nat) := (i+1)*3+1
def Width.extend (a : Width) (k : Nat) : Width := ⟨k+a.fixed,a.growth⟩
def Width.amount (a : Width) (ρ : Nat→V) := (a.fixed:V) + a.growth.elim 0 (fun i => ρ (nVar i))

def repeatFixed : List Bool → Nat → Term → Term
| _,0,a => a
| w,k+1,a => litWord w (repeatFixed w k a)
def Width.wrap (len : Width) (w : List Bool) (a : Term) :=
  repeatFixed w len.fixed (len.growth.elim a (fun i => rep w (.var (nVar i)) a))

theorem fixed_payload (m : Machine n) (w : List Bool) (k : Nat) (a : Term) (ρ : Nat→V) :
    payload ((repeatFixed w k a).val (operations m) ρ) = rayRep w (k:V) (payload (a.val (operations m) ρ)) := by
  induction k with
  | zero => simp [repeatFixed,rayRep]
  | succ k ih => simp only [repeatFixed,val_litWord,payload_lit,ih,Nat.cast_succ,rayRep,iterate_succ]

theorem wrap_payload (m : Machine n) (w : List Bool) (width : Width) (a : Term) (ρ : Nat→V) :
    payload ((width.wrap w a).val (operations m) ρ) = rayRep w (width.amount ρ) (payload (a.val (operations m) ρ)) := by
  cases width with | mk k i =>
    cases i with
    | none => simp [Width.wrap,Width.amount,fixed_payload]
    | some ix =>
      simp only [Width.wrap,Width.amount,Option.elim_some,fixed_payload]
      change rayRep w (k:V) (payload (repeatW w (ρ (nVar ix)) _)) = _
      rw [payload_repeat,add_comm]; simp only [rayRep,iterate_add]

theorem extend_amount (a : Width) (k : Nat) (ρ : Nat→V) :
    (a.extend k).amount ρ=(k:V)+a.amount ρ := by simp [Width.extend,Width.amount,add_assoc]

structure Pattern where
  pc : Nat
  cold : Bool
  regs : Nat→Width
  gap : Width
  spare : Width
def Pattern.field (p : Pattern) (i : Nat) : Width :=
  if p.cold && decide (i=0) then ⟨1,none⟩ else (p.regs i).extend 2

def Pattern.fields (p : Pattern) : List Nat → Term → Term
| [],tail => tail
| i::is,tail => digit false ((p.field i).wrap [true] (p.fields is tail))

def Pattern.encoded (p : Pattern) (leftPad rightPad : Nat) : Term :=
  let left := digit true (repeatFixed [false] leftPad (.var (wVar 11)))
  let endW := (p.spare.extend 24).wrap [false,true] (repeatFixed [false] rightPad (.var (wVar 12)))
  let after := digit true (p.fields registerOrder endW)
  let right := litWord (pathBits p.pc) ((p.gap.extend (42-(pathBits p.pc).length)).wrap [false] after)
  cf (.numeral 13) (.numeral 0) right left

theorem zero_ray_repeats (k : Nat) : rayRep [false] (k:V) 0=0 := by
  induction k with
  | zero => simp [rayRep]
  | succ k ih => rw [Nat.cast_succ,rayRep,iterate_succ,← rayRep,ih]; simp [rayLit]

theorem push0_payload (x : V) : payload (pushW 0 x)=2*payload x := by simpa using payload_push (0:V) x (Or.inl rfl)
theorem push1_payload (x : V) : payload (pushW 1 x)=2*payload x+1 := by simpa using payload_push (1:V) x (Or.inr rfl)
theorem val_varT (m : Machine n) (ρ : Nat→V) (i : Nat) : (Term.var i).val (operations m) ρ = ρ i := rfl
theorem pattern_fields (m : Machine n) (p : Pattern) (f r : V) (ρ : Nat→V)
    (hc : f=(p.cold.toNat:V)) (hregs : ∀ i∈registerOrder, (p.regs i).amount ρ=RegisterSource.readReg i r)
    (ks : List Nat) (sub : ks⊆registerOrder) (tail : Term) :
    payload ((p.fields ks tail).val (operations m) ρ) =
    blocks ks f r (payload (tail.val (operations m) ρ)) := by
  have counts (i : Nat) (hi : i ∈ registerOrder) : (p.field i).amount ρ=blockCount i f r := by
    subst f
    by_cases iz : i=0
    · subst i
      cases c : p.cold
      · simp [Pattern.field,c,blockCount,chooseZero,extend_amount,hregs 0 hi,add_comm]
      · simp [Pattern.field,c,blockCount,chooseZero,Width.amount]
    · simp only [Pattern.field,iz,decide_false,Bool.and_false,Bool.false_eq_true,ite_false,extend_amount,blockCount,hregs i hi,Nat.cast_ofNat]
      exact add_comm _ _
  induction ks with
  | nil => rfl
  | cons j js ih =>
    have member : j∈registerOrder := sub (by simp)
    have sub' : js⊆registerOrder := fun a h => sub (by simp [h])
    simp only [Pattern.fields,val_digit,Bool.toNat_false,Nat.cast_zero,push0_payload,wrap_payload,counts j member,ih sub',blocks,rayLit,add_zero]

theorem pattern_project (m : Machine n) (p : Pattern) (lp rp : Nat) (f r : V) (ρ : Nat→V)
    (hc : f=(p.cold.toNat:V)) (hregs : ∀i∈registerOrder,(p.regs i).amount ρ=RegisterSource.readReg i r)
    (lext : ρ (wVar 11)=0) (rext : ρ (wVar 12)=0) :
    project ((p.encoded lp rp).val (operations m) ρ) = frame p.pc f r (p.gap.amount ρ) (p.spare.amount ρ) := by
  unfold Pattern.encoded frame frameOf
  simp only [val_cf,val_numeral,Nat.cast_ofNat,Nat.cast_zero,project,fd_pack,ite_true,fq_pack,ff_pack,fb_pack,
    val_digit,val_litWord,push1_payload,fixed_payload,val_varT,lext,rext,payload_zero,zero_ray_repeats,
    payload_lit,wrap_payload,extend_amount,pattern_fields m p f r ρ hc hregs registerOrder (by rfl),
    Bool.toNat_true,Nat.cast_one,rayLit]
  simp

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.pattern_project
