module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site1554Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1554 f r x y z) (slots210.atReg 1557 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1554 3 1557 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1554 1557 1555 f r row1554)
    (slots210.pos_x 1554 1557 1555 f r row1554)
    (slots210.inc_y 1555 1556 f r row1555 (Or.inl (by decide)))
    (slots210.jump 1556 1554 f r row1556)

theorem site1554 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1554:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1557:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1554Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1557Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1557 f r x y z) (slots617.atReg 1567 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1557 10 1567 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1557 1561 1558 f r row1557)
    (slots617.pos_y 1557 1561 1558 f r row1557)
    (slots617.inc_z 1558 1559 f r row1558 (Or.inl (by decide)))
    (slots617.inc_x 1559 1560 f r row1559 (Or.inl (by decide)))
    (slots617.jump 1560 1557 f r row1560)
    (slots617.zero_x 1561 1567 1562 f r row1561)
    (slots617.pos_x 1561 1567 1562 f r row1561)
    (slots617.inc_z 1562 1563 f r row1562 (Or.inl (by decide)))
    (slots617.zero_x 1563 1566 1564 f r row1563)
    (slots617.pos_x 1563 1566 1564 f r row1563)
    (slots617.inc_y 1564 1565 f r row1564 (Or.inl (by decide)))
    (slots617.jump 1565 1563 f r row1565)
    (slots617.jump 1566 1557 f r row1566)

theorem site1557 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1557:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1567:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1557Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1567Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1567 f r x y z) (slots720.atReg 1570 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1567 3 1570 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1567 1570 1568 f r row1567)
    (slots720.pos_x 1567 1570 1568 f r row1567)
    (slots720.inc_y 1568 1569 f r row1568 (Or.inl (by decide)))
    (slots720.jump 1569 1567 f r row1569)

theorem site1567 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1567:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1570:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1567Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1570Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1570 f r x y z) (slots461.atReg 1574 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1570 4 1574 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1570 1574 1571 f r row1570)
    (slots461.pos_x 1570 1574 1571 f r row1570)
    (slots461.inc_y 1571 1572 f r row1571 (Or.inl (by decide)))
    (slots461.inc_z 1572 1573 f r row1572 (Or.inl (by decide)))
    (slots461.jump 1573 1570 f r row1573)

theorem site1570 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1570:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1574:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1570Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site1574Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1574 f r x y z) (slots640.atReg 1577 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1574 3 1577 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1574 1577 1575 f r row1574)
    (slots640.pos_x 1574 1577 1575 f r row1574)
    (slots640.inc_y 1575 1576 f r row1575 (Or.inl (by decide)))
    (slots640.jump 1576 1574 f r row1576)

theorem site1574 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1574:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1577:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1574Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site1577Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1577 f r x y z) (slots267.atReg 1585 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1577 8 1585 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1577 1585 1578 f r row1577)
    (slots267.pos_x 1577 1585 1578 f r row1577)
    (slots267.inc_z 1578 1579 f r row1578 (Or.inl (by decide)))
    (slots267.zero_y 1579 1581 1580 f r row1579)
    (slots267.pos_y 1579 1581 1580 f r row1579)
    (slots267.jump 1580 1584 f r row1580)
    (slots267.zero_z 1581 1584 1582 f r row1581)
    (slots267.pos_z 1581 1584 1582 f r row1581)
    (slots267.inc_y 1582 1583 f r row1582 (Or.inl (by decide)))
    (slots267.jump 1583 1581 f r row1583)
    (slots267.jump 1584 1577 f r row1584)

theorem site1577 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1577:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1585:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1577Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1585Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1585 f r x y z) (slots720.atReg 1588 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1585 3 1588 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1585 1588 1586 f r row1585)
    (slots720.pos_x 1585 1588 1586 f r row1585)
    (slots720.inc_y 1586 1587 f r row1586 (Or.inl (by decide)))
    (slots720.jump 1587 1585 f r row1587)

theorem site1585 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1585:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1588:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1585Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1588Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1588 f r x y z) (slots617.atReg 1598 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1588 10 1598 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1588 1592 1589 f r row1588)
    (slots617.pos_y 1588 1592 1589 f r row1588)
    (slots617.inc_z 1589 1590 f r row1589 (Or.inl (by decide)))
    (slots617.inc_x 1590 1591 f r row1590 (Or.inl (by decide)))
    (slots617.jump 1591 1588 f r row1591)
    (slots617.zero_x 1592 1598 1593 f r row1592)
    (slots617.pos_x 1592 1598 1593 f r row1592)
    (slots617.inc_z 1593 1594 f r row1593 (Or.inl (by decide)))
    (slots617.zero_x 1594 1597 1595 f r row1594)
    (slots617.pos_x 1594 1597 1595 f r row1594)
    (slots617.inc_y 1595 1596 f r row1595 (Or.inl (by decide)))
    (slots617.jump 1596 1594 f r row1596)
    (slots617.jump 1597 1588 f r row1597)

theorem site1588 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1588:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1598:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1588Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1598Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1598 f r x y z) (slots710.atReg 1602 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1598 4 1602 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1598 1602 1599 f r row1598)
    (slots710.pos_x 1598 1602 1599 f r row1598)
    (slots710.inc_y 1599 1600 f r row1599 (Or.inl (by decide)))
    (slots710.inc_y 1600 1601 f r row1600 (Or.inl (by decide)))
    (slots710.jump 1601 1598 f r row1601)

theorem site1598 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1598:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1602:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1598Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1602 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1602:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1603:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1602 _ row1602]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1603Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1603 f r x y z) (slots160.atReg 1606 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1603 3 1606 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1603 1606 1604 f r row1603)
    (slots160.pos_x 1603 1606 1604 f r row1603)
    (slots160.inc_y 1604 1605 f r row1604 (Or.inl (by decide)))
    (slots160.jump 1605 1603 f r row1605)

theorem site1603 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1603:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1606:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1603Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1606Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1606 f r x y z) (slots210.atReg 1609 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1606 3 1609 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1606 1609 1607 f r row1606)
    (slots210.pos_x 1606 1609 1607 f r row1606)
    (slots210.inc_y 1607 1608 f r row1607 (Or.inl (by decide)))
    (slots210.jump 1608 1606 f r row1608)

theorem site1606 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1606:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1609:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1606Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1609Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1609 f r x y z) (slots617.atReg 1619 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1609 10 1619 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1609 1613 1610 f r row1609)
    (slots617.pos_y 1609 1613 1610 f r row1609)
    (slots617.inc_z 1610 1611 f r row1610 (Or.inl (by decide)))
    (slots617.inc_x 1611 1612 f r row1611 (Or.inl (by decide)))
    (slots617.jump 1612 1609 f r row1612)
    (slots617.zero_x 1613 1619 1614 f r row1613)
    (slots617.pos_x 1613 1619 1614 f r row1613)
    (slots617.inc_z 1614 1615 f r row1614 (Or.inl (by decide)))
    (slots617.zero_x 1615 1618 1616 f r row1615)
    (slots617.pos_x 1615 1618 1616 f r row1615)
    (slots617.inc_y 1616 1617 f r row1616 (Or.inl (by decide)))
    (slots617.jump 1617 1615 f r row1617)
    (slots617.jump 1618 1609 f r row1618)

theorem site1609 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1609:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1619:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1609Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1619Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1619 f r x y z) (slots720.atReg 1622 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1619 3 1622 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1619 1622 1620 f r row1619)
    (slots720.pos_x 1619 1622 1620 f r row1619)
    (slots720.inc_y 1620 1621 f r row1620 (Or.inl (by decide)))
    (slots720.jump 1621 1619 f r row1621)

theorem site1619 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1619:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1622:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1619Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1622Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1622 f r x y z) (slots561.atReg 1626 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1622 4 1626 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1622 1626 1623 f r row1622)
    (slots561.pos_x 1622 1626 1623 f r row1622)
    (slots561.inc_y 1623 1624 f r row1623 (Or.inl (by decide)))
    (slots561.inc_z 1624 1625 f r row1624 (Or.inl (by decide)))
    (slots561.jump 1625 1622 f r row1625)

theorem site1622 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1622:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1626:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1622Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1626Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1626 f r x y z) (slots650.atReg 1629 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1626 3 1629 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1626 1629 1627 f r row1626)
    (slots650.pos_x 1626 1629 1627 f r row1626)
    (slots650.inc_y 1627 1628 f r row1627 (Or.inl (by decide)))
    (slots650.jump 1628 1626 f r row1628)

theorem site1626 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1626:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1629:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1626Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1629Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1629 f r x y z) (slots267.atReg 1637 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1629 8 1637 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1629 1637 1630 f r row1629)
    (slots267.pos_x 1629 1637 1630 f r row1629)
    (slots267.inc_z 1630 1631 f r row1630 (Or.inl (by decide)))
    (slots267.zero_y 1631 1633 1632 f r row1631)
    (slots267.pos_y 1631 1633 1632 f r row1631)
    (slots267.jump 1632 1636 f r row1632)
    (slots267.zero_z 1633 1636 1634 f r row1633)
    (slots267.pos_z 1633 1636 1634 f r row1633)
    (slots267.inc_y 1634 1635 f r row1634 (Or.inl (by decide)))
    (slots267.jump 1635 1633 f r row1635)
    (slots267.jump 1636 1629 f r row1636)

theorem site1629 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1629:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1637:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1629Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1637Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1637 f r x y z) (slots720.atReg 1640 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1637 3 1640 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1637 1640 1638 f r row1637)
    (slots720.pos_x 1637 1640 1638 f r row1637)
    (slots720.inc_y 1638 1639 f r row1638 (Or.inl (by decide)))
    (slots720.jump 1639 1637 f r row1639)

theorem site1637 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1637:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1640:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1637Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1640Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1640 f r x y z) (slots617.atReg 1650 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1640 10 1650 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1640 1644 1641 f r row1640)
    (slots617.pos_y 1640 1644 1641 f r row1640)
    (slots617.inc_z 1641 1642 f r row1641 (Or.inl (by decide)))
    (slots617.inc_x 1642 1643 f r row1642 (Or.inl (by decide)))
    (slots617.jump 1643 1640 f r row1643)
    (slots617.zero_x 1644 1650 1645 f r row1644)
    (slots617.pos_x 1644 1650 1645 f r row1644)
    (slots617.inc_z 1645 1646 f r row1645 (Or.inl (by decide)))
    (slots617.zero_x 1646 1649 1647 f r row1646)
    (slots617.pos_x 1646 1649 1647 f r row1646)
    (slots617.inc_y 1647 1648 f r row1647 (Or.inl (by decide)))
    (slots617.jump 1648 1646 f r row1648)
    (slots617.jump 1649 1640 f r row1649)

theorem site1640 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1640:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1650:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1640Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1650Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1650 f r x y z) (slots710.atReg 1654 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1650 4 1654 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1650 1654 1651 f r row1650)
    (slots710.pos_x 1650 1654 1651 f r row1650)
    (slots710.inc_y 1651 1652 f r row1651 (Or.inl (by decide)))
    (slots710.inc_y 1652 1653 f r row1652 (Or.inl (by decide)))
    (slots710.jump 1653 1650 f r row1653)

theorem site1650 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1650:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1654:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1650Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1654 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1654:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1655:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1654 _ row1654]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1655Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1655 f r x y z) (slots160.atReg 1658 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1655 3 1658 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1655 1658 1656 f r row1655)
    (slots160.pos_x 1655 1658 1656 f r row1655)
    (slots160.inc_y 1656 1657 f r row1656 (Or.inl (by decide)))
    (slots160.jump 1657 1655 f r row1657)

theorem site1655 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1655:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1658:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1655Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1658Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1658 f r x y z) (slots210.atReg 1661 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1658 3 1661 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1658 1661 1659 f r row1658)
    (slots210.pos_x 1658 1661 1659 f r row1658)
    (slots210.inc_y 1659 1660 f r row1659 (Or.inl (by decide)))
    (slots210.jump 1660 1658 f r row1660)

theorem site1658 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1658:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1661:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1658Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1661Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1661 f r x y z) (slots617.atReg 1671 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1661 10 1671 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1661 1665 1662 f r row1661)
    (slots617.pos_y 1661 1665 1662 f r row1661)
    (slots617.inc_z 1662 1663 f r row1662 (Or.inl (by decide)))
    (slots617.inc_x 1663 1664 f r row1663 (Or.inl (by decide)))
    (slots617.jump 1664 1661 f r row1664)
    (slots617.zero_x 1665 1671 1666 f r row1665)
    (slots617.pos_x 1665 1671 1666 f r row1665)
    (slots617.inc_z 1666 1667 f r row1666 (Or.inl (by decide)))
    (slots617.zero_x 1667 1670 1668 f r row1667)
    (slots617.pos_x 1667 1670 1668 f r row1667)
    (slots617.inc_y 1668 1669 f r row1668 (Or.inl (by decide)))
    (slots617.jump 1669 1667 f r row1669)
    (slots617.jump 1670 1661 f r row1670)

theorem site1661 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1661:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1671:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1661Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1671Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1671 f r x y z) (slots720.atReg 1674 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1671 3 1674 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1671 1674 1672 f r row1671)
    (slots720.pos_x 1671 1674 1672 f r row1671)
    (slots720.inc_y 1672 1673 f r row1672 (Or.inl (by decide)))
    (slots720.jump 1673 1671 f r row1673)

theorem site1671 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1671:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1674:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1671Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1674Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 1674 f r x y z) (slots361.atReg 1678 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 1674 4 1678 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 1674 1678 1675 f r row1674)
    (slots361.pos_x 1674 1678 1675 f r row1674)
    (slots361.inc_y 1675 1676 f r row1675 (Or.inl (by decide)))
    (slots361.inc_z 1676 1677 f r row1676 (Or.inl (by decide)))
    (slots361.jump 1677 1674 f r row1677)

theorem site1674 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1674:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1678:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site1674Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site1678Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 1678 f r x y z) (slots630.atReg 1681 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 1678 3 1681 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 1678 1681 1679 f r row1678)
    (slots630.pos_x 1678 1681 1679 f r row1678)
    (slots630.inc_y 1679 1680 f r row1679 (Or.inl (by decide)))
    (slots630.jump 1680 1678 f r row1680)

theorem site1678 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1678:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1681:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site1678Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site1681Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1681 f r x y z) (slots160.atReg 1684 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1681 3 1684 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1681 1684 1682 f r row1681)
    (slots160.pos_x 1681 1684 1682 f r row1681)
    (slots160.inc_y 1682 1683 f r row1682 (Or.inl (by decide)))
    (slots160.jump 1683 1681 f r row1683)

theorem site1681 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1681:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1684:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1681Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1684Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1684 f r x y z) (slots210.atReg 1687 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1684 3 1687 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1684 1687 1685 f r row1684)
    (slots210.pos_x 1684 1687 1685 f r row1684)
    (slots210.inc_y 1685 1686 f r row1685 (Or.inl (by decide)))
    (slots210.jump 1686 1684 f r row1686)

theorem site1684 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1684:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1687:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1684Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1687Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1687 f r x y z) (slots617.atReg 1697 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1687 10 1697 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1687 1691 1688 f r row1687)
    (slots617.pos_y 1687 1691 1688 f r row1687)
    (slots617.inc_z 1688 1689 f r row1688 (Or.inl (by decide)))
    (slots617.inc_x 1689 1690 f r row1689 (Or.inl (by decide)))
    (slots617.jump 1690 1687 f r row1690)
    (slots617.zero_x 1691 1697 1692 f r row1691)
    (slots617.pos_x 1691 1697 1692 f r row1691)
    (slots617.inc_z 1692 1693 f r row1692 (Or.inl (by decide)))
    (slots617.zero_x 1693 1696 1694 f r row1693)
    (slots617.pos_x 1693 1696 1694 f r row1693)
    (slots617.inc_y 1694 1695 f r row1694 (Or.inl (by decide)))
    (slots617.jump 1695 1693 f r row1695)
    (slots617.jump 1696 1687 f r row1696)

theorem site1687 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1687:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1697:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1687Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1697Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1697 f r x y z) (slots720.atReg 1700 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1697 3 1700 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1697 1700 1698 f r row1697)
    (slots720.pos_x 1697 1700 1698 f r row1697)
    (slots720.inc_y 1698 1699 f r row1698 (Or.inl (by decide)))
    (slots720.jump 1699 1697 f r row1699)

theorem site1697 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1697:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1700:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1697Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1700Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1700 f r x y z) (slots561.atReg 1704 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1700 4 1704 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1700 1704 1701 f r row1700)
    (slots561.pos_x 1700 1704 1701 f r row1700)
    (slots561.inc_y 1701 1702 f r row1701 (Or.inl (by decide)))
    (slots561.inc_z 1702 1703 f r row1702 (Or.inl (by decide)))
    (slots561.jump 1703 1700 f r row1703)

theorem site1700 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1700:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1704:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1700Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1704Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1704 f r x y z) (slots650.atReg 1707 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1704 3 1707 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1704 1707 1705 f r row1704)
    (slots650.pos_x 1704 1707 1705 f r row1704)
    (slots650.inc_y 1705 1706 f r row1705 (Or.inl (by decide)))
    (slots650.jump 1706 1704 f r row1706)

theorem site1704 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1704:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1707:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1704Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1707Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1707 f r x y z) (slots160.atReg 1710 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1707 3 1710 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1707 1710 1708 f r row1707)
    (slots160.pos_x 1707 1710 1708 f r row1707)
    (slots160.inc_y 1708 1709 f r row1708 (Or.inl (by decide)))
    (slots160.jump 1709 1707 f r row1709)

theorem site1707 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1707:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1710:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1707Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1710Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1710 f r x y z) (slots210.atReg 1713 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1710 3 1713 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1710 1713 1711 f r row1710)
    (slots210.pos_x 1710 1713 1711 f r row1710)
    (slots210.inc_y 1711 1712 f r row1711 (Or.inl (by decide)))
    (slots210.jump 1712 1710 f r row1712)

theorem site1710 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1710:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1713:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1710Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1713Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1713 f r x y z) (slots617.atReg 1723 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1713 10 1723 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1713 1717 1714 f r row1713)
    (slots617.pos_y 1713 1717 1714 f r row1713)
    (slots617.inc_z 1714 1715 f r row1714 (Or.inl (by decide)))
    (slots617.inc_x 1715 1716 f r row1715 (Or.inl (by decide)))
    (slots617.jump 1716 1713 f r row1716)
    (slots617.zero_x 1717 1723 1718 f r row1717)
    (slots617.pos_x 1717 1723 1718 f r row1717)
    (slots617.inc_z 1718 1719 f r row1718 (Or.inl (by decide)))
    (slots617.zero_x 1719 1722 1720 f r row1719)
    (slots617.pos_x 1719 1722 1720 f r row1719)
    (slots617.inc_y 1720 1721 f r row1720 (Or.inl (by decide)))
    (slots617.jump 1721 1719 f r row1721)
    (slots617.jump 1722 1713 f r row1722)

theorem site1713 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1713:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1723:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1713Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1723Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1723 f r x y z) (slots720.atReg 1726 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1723 3 1726 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1723 1726 1724 f r row1723)
    (slots720.pos_x 1723 1726 1724 f r row1723)
    (slots720.inc_y 1724 1725 f r row1724 (Or.inl (by decide)))
    (slots720.jump 1725 1723 f r row1725)

theorem site1723 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1723:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1726:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1723Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1726Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1726 f r x y z) (slots561.atReg 1730 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1726 4 1730 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1726 1730 1727 f r row1726)
    (slots561.pos_x 1726 1730 1727 f r row1726)
    (slots561.inc_y 1727 1728 f r row1727 (Or.inl (by decide)))
    (slots561.inc_z 1728 1729 f r row1728 (Or.inl (by decide)))
    (slots561.jump 1729 1726 f r row1729)

theorem site1726 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1726:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1730:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1726Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1730Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1730 f r x y z) (slots650.atReg 1733 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1730 3 1733 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1730 1733 1731 f r row1730)
    (slots650.pos_x 1730 1733 1731 f r row1730)
    (slots650.inc_y 1731 1732 f r row1731 (Or.inl (by decide)))
    (slots650.jump 1732 1730 f r row1732)

theorem site1730 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1730:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1733:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1730Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1733Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1733 f r x y z) (slots267.atReg 1741 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1733 8 1741 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1733 1741 1734 f r row1733)
    (slots267.pos_x 1733 1741 1734 f r row1733)
    (slots267.inc_z 1734 1735 f r row1734 (Or.inl (by decide)))
    (slots267.zero_y 1735 1737 1736 f r row1735)
    (slots267.pos_y 1735 1737 1736 f r row1735)
    (slots267.jump 1736 1740 f r row1736)
    (slots267.zero_z 1737 1740 1738 f r row1737)
    (slots267.pos_z 1737 1740 1738 f r row1737)
    (slots267.inc_y 1738 1739 f r row1738 (Or.inl (by decide)))
    (slots267.jump 1739 1737 f r row1739)
    (slots267.jump 1740 1733 f r row1740)

theorem site1733 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1733:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1741:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1733Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1741Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1741 f r x y z) (slots720.atReg 1744 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1741 3 1744 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1741 1744 1742 f r row1741)
    (slots720.pos_x 1741 1744 1742 f r row1741)
    (slots720.inc_y 1742 1743 f r row1742 (Or.inl (by decide)))
    (slots720.jump 1743 1741 f r row1743)

theorem site1741 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1741:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1744:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1741Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1744Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1744 f r x y z) (slots617.atReg 1754 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1744 10 1754 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1744 1748 1745 f r row1744)
    (slots617.pos_y 1744 1748 1745 f r row1744)
    (slots617.inc_z 1745 1746 f r row1745 (Or.inl (by decide)))
    (slots617.inc_x 1746 1747 f r row1746 (Or.inl (by decide)))
    (slots617.jump 1747 1744 f r row1747)
    (slots617.zero_x 1748 1754 1749 f r row1748)
    (slots617.pos_x 1748 1754 1749 f r row1748)
    (slots617.inc_z 1749 1750 f r row1749 (Or.inl (by decide)))
    (slots617.zero_x 1750 1753 1751 f r row1750)
    (slots617.pos_x 1750 1753 1751 f r row1750)
    (slots617.inc_y 1751 1752 f r row1751 (Or.inl (by decide)))
    (slots617.jump 1752 1750 f r row1752)
    (slots617.jump 1753 1744 f r row1753)

theorem site1744 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1744:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1754:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1744Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

end PA192.ModelSearch.RegisterSource.Certified
