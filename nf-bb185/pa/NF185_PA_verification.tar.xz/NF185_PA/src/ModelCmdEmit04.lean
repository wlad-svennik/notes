module
public import ModelCmdEmit03
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter129 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((668:Nat):V) f (vector n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 (atom25 n t s c u v y d w) w)) := by
  have micro := site0658 f n (v+y) (atom21 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (v+y)):V)=atom25 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (v+y)):V)=0+(atom25 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter128 f n t s c u v y d w).trans mid

theorem commandEmitAfter130 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((672:Nat):V) f (vector n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0668 f n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 (atom25 n t s c u v y d w) w
  have d1 : (0+(2*(atom25 n t s c u v y d w)):V)=(atom25 n t s c u v y d w)+(atom25 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom25 n t s c u v y d w)):V)=0+((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter129 f n t s c u v y d w).trans mid

theorem commandEmitAfter131 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((673:Nat):V) f (vector n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0672 f n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w))+1:V)=(atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter130 f n t s c u v y d w).trans mid

theorem commandEmitAfter132 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((681:Nat):V) f (vector n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) 0 c (d+u) (v+y) 1 (atom20 n t s c u v y d w) w)) := by
  have micro := site0673 f n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom21 n t s c u v y d w)):V)=1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom21 n t s c u v y d w):V)=0+(atom21 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom21 n t s c u v y d w)):V)=left (atom21 n t s c u v y d w)).trans (by change left (cantor 1 (atom20 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom21 n t s c u v y d w)):V)=atom20 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom21 n t s c u v y d w):V)=0+(atom21 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom21 n t s c u v y d w)):V)=right (atom21 n t s c u v y d w)).trans (by change right (cantor 1 (atom20 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter131 f n t s c u v y d w).trans mid

theorem commandEmitAfter133 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((684:Nat):V) f (vector n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) (atom20 n t s c u v y d w) c (d+u) (v+y) 1 0 w)) := by
  have micro := site0681 f n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) 0 c (d+u) (v+y) 1 (atom20 n t s c u v y d w) w
  have d2 : (0+(atom20 n t s c u v y d w):V)=atom20 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter132 f n t s c u v y d w).trans mid

theorem commandEmitAfter134 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((694:Nat):V) f (vector n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 (atom26 n t s c u v y d w) w)) := by
  have micro := site0684 f n ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1) (atom20 n t s c u v y d w) c (d+u) (v+y) 1 0 w
  have d7 : (0+(cantor 1 ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1)):V)=atom26 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 1 ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1)):V)=0+(atom26 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter133 f n t s c u v y d w).trans mid

theorem commandEmitAfter135 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((698:Nat):V) f (vector n ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)) (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0694 f n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 (atom26 n t s c u v y d w) w
  have d1 : (0+(2*(atom26 n t s c u v y d w)):V)=(atom26 n t s c u v y d w)+(atom26 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom26 n t s c u v y d w)):V)=0+((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter134 f n t s c u v y d w).trans mid

theorem commandEmitAfter136 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((699:Nat):V) f (vector n ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1) (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0698 f n ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)) (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w))+1:V)=(atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter135 f n t s c u v y d w).trans mid

theorem commandEmitAfter137 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((707:Nat):V) f (vector n ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w) w)) := by
  have micro := site0699 f n ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1) (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom20 n t s c u v y d w)):V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom20 n t s c u v y d w):V)=0+(atom20 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom20 n t s c u v y d w)):V)=left (atom20 n t s c u v y d w)).trans (by change left (cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom20 n t s c u v y d w)):V)=atom15 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom20 n t s c u v y d w):V)=0+(atom20 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom20 n t s c u v y d w)):V)=right (atom20 n t s c u v y d w)).trans (by change right (cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter136 f n t s c u v y d w).trans mid

theorem commandEmitAfter138 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((710:Nat):V) f (vector n ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1) (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0707 f n ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w) w
  have d2 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter137 f n t s c u v y d w).trans mid

theorem commandEmitAfter139 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((720:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 (atom27 n t s c u v y d w) w)) := by
  have micro := site0710 f n ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1) (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1)):V)=atom27 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1)):V)=0+(atom27 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter138 f n t s c u v y d w).trans mid

theorem commandEmitAfter140 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((724:Nat):V) f (vector n ((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0720 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 (atom27 n t s c u v y d w) w
  have d1 : (0+(2*(atom27 n t s c u v y d w)):V)=(atom27 n t s c u v y d w)+(atom27 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom27 n t s c u v y d w)):V)=0+((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter139 f n t s c u v y d w).trans mid

theorem commandEmitAfter141 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((727:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)) 0 w)) := by
  have micro := site0724 f n ((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)):V)=(atom27 n t s c u v y d w)+(atom27 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter140 f n t s c u v y d w).trans mid

theorem commandEmitAfter142 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((730:Nat):V) f (vector n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) ((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)) 0 w)) := by
  have micro := site0727 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)) 0 w
  have d1 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter141 f n t s c u v y d w).trans mid

theorem commandEmitAfter143 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((740:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom28 n t s c u v y d w) w)) := by
  have micro := site0730 f n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) ((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)) (atom15 n t s c u v y d w)):V)=atom28 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)) (atom15 n t s c u v y d w)):V)=0+(atom28 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter142 f n t s c u v y d w).trans mid

theorem commandEmitAfter144 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((743:Nat):V) f (vector n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0740 f n 0 0 c (d+u) (v+y) 0 (atom28 n t s c u v y d w) w
  have d2 : (0+(atom28 n t s c u v y d w):V)=atom28 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter143 f n t s c u v y d w).trans mid

theorem commandEmitAfter145 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((747:Nat):V) f (vector n c (atom28 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site0743 f n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+c:V)=c := by ring
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter144 f n t s c u v y d w).trans mid

theorem commandEmitAfter146 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((750:Nat):V) f (vector n c (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0747 f n c (atom28 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter145 f n t s c u v y d w).trans mid

theorem commandEmitAfter147 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((753:Nat):V) f (vector n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site0750 f n c (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter146 f n t s c u v y d w).trans mid

theorem commandEmitAfter148 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((756:Nat):V) f (vector n (atom28 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w)) := by
  have micro := site0753 f n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d1 : (0+(atom28 n t s c u v y d w):V)=atom28 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter147 f n t s c u v y d w).trans mid

theorem commandEmitAfter149 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((766:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom29 n t s c u v y d w) w)) := by
  have micro := site0756 f n (atom28 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w
  have d7 : (0+(cantor c (atom28 n t s c u v y d w)):V)=atom29 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor c (atom28 n t s c u v y d w)):V)=0+(atom29 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter148 f n t s c u v y d w).trans mid

theorem commandEmitAfter150 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((769:Nat):V) f (vector n 0 (atom29 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0766 f n 0 0 c (d+u) (v+y) 0 (atom29 n t s c u v y d w) w
  have d2 : (0+(atom29 n t s c u v y d w):V)=atom29 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter149 f n t s c u v y d w).trans mid

theorem commandEmitAfter151 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((773:Nat):V) f (vector n (v+y) (atom29 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0769 f n 0 (atom29 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter150 f n t s c u v y d w).trans mid

theorem commandEmitAfter152 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((776:Nat):V) f (vector n (v+y) (atom29 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0773 f n (v+y) (atom29 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter151 f n t s c u v y d w).trans mid

theorem commandEmitAfter153 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((784:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) c (atom28 n t s c u v y d w) w)) := by
  have micro := site0776 f n (v+y) (atom29 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom29 n t s c u v y d w)):V)=c := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom29 n t s c u v y d w):V)=0+(atom29 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom29 n t s c u v y d w)):V)=left (atom29 n t s c u v y d w)).trans (by change left (cantor c (atom28 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom29 n t s c u v y d w)):V)=atom28 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom29 n t s c u v y d w):V)=0+(atom29 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom29 n t s c u v y d w)):V)=right (atom29 n t s c u v y d w)).trans (by change right (cantor c (atom28 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter152 f n t s c u v y d w).trans mid

theorem commandEmitAfter154 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((787:Nat):V) f (vector n (v+y) (atom28 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site0784 f n (v+y) 0 c (d+u) (v+y) c (atom28 n t s c u v y d w) w
  have d2 : (0+(atom28 n t s c u v y d w):V)=atom28 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter153 f n t s c u v y d w).trans mid

theorem commandEmitAfter155 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((797:Nat):V) f (vector n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) 0 (atom30 n t s c u v y d w) w)) := by
  have micro := site0787 f n (v+y) (atom28 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d7 : (0+(cantor c (v+y)):V)=atom30 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor c (v+y)):V)=0+(atom30 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter154 f n t s c u v y d w).trans mid

theorem commandEmitAfter156 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((801:Nat):V) f (vector n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)) (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0797 f n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) 0 (atom30 n t s c u v y d w) w
  have d1 : (0+(2*(atom30 n t s c u v y d w)):V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom30 n t s c u v y d w)):V)=0+((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter155 f n t s c u v y d w).trans mid

theorem commandEmitAfter157 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((802:Nat):V) f (vector n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0801 f n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)) (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w))+1:V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter156 f n t s c u v y d w).trans mid

theorem commandEmitAfter158 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((805:Nat):V) f (vector n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0802 f n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1):V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter157 f n t s c u v y d w).trans mid

theorem commandEmitAfter159 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((808:Nat):V) f (vector n (atom28 n t s c u v y d w) 0 c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0805 f n 0 (atom28 n t s c u v y d w) c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom28 n t s c u v y d w):V)=atom28 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter158 f n t s c u v y d w).trans mid

theorem commandEmitAfter160 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((818:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom31 n t s c u v y d w) w)) := by
  have micro := site0808 f n (atom28 n t s c u v y d w) 0 c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom28 n t s c u v y d w)):V)=atom31 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom28 n t s c u v y d w)):V)=0+(atom31 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter159 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
