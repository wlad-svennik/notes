module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site0979Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 979 f r x y z) (slots710.atReg 983 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 979 4 983 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 979 983 980 f r row0979)
    (slots710.pos_x 979 983 980 f r row0979)
    (slots710.inc_y 980 981 f r row0980 (Or.inl (by decide)))
    (slots710.inc_y 981 982 f r row0981 (Or.inl (by decide)))
    (slots710.jump 982 979 f r row0982)

theorem site0979 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((979:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((983:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0979Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site0983 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((983:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((984:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 983 _ row0983]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0984Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 984 f r x y z) (slots267.atReg 992 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 984 8 992 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 984 992 985 f r row0984)
    (slots267.pos_x 984 992 985 f r row0984)
    (slots267.inc_z 985 986 f r row0985 (Or.inl (by decide)))
    (slots267.zero_y 986 988 987 f r row0986)
    (slots267.pos_y 986 988 987 f r row0986)
    (slots267.jump 987 991 f r row0987)
    (slots267.zero_z 988 991 989 f r row0988)
    (slots267.pos_z 988 991 989 f r row0988)
    (slots267.inc_y 989 990 f r row0989 (Or.inl (by decide)))
    (slots267.jump 990 988 f r row0990)
    (slots267.jump 991 984 f r row0991)

theorem site0984 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((984:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((992:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0984Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0992Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 992 f r x y z) (slots720.atReg 995 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 992 3 995 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 992 995 993 f r row0992)
    (slots720.pos_x 992 995 993 f r row0992)
    (slots720.inc_y 993 994 f r row0993 (Or.inl (by decide)))
    (slots720.jump 994 992 f r row0994)

theorem site0992 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((992:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((995:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0992Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0995Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 995 f r x y z) (slots617.atReg 1005 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 995 10 1005 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 995 999 996 f r row0995)
    (slots617.pos_y 995 999 996 f r row0995)
    (slots617.inc_z 996 997 f r row0996 (Or.inl (by decide)))
    (slots617.inc_x 997 998 f r row0997 (Or.inl (by decide)))
    (slots617.jump 998 995 f r row0998)
    (slots617.zero_x 999 1005 1000 f r row0999)
    (slots617.pos_x 999 1005 1000 f r row0999)
    (slots617.inc_z 1000 1001 f r row1000 (Or.inl (by decide)))
    (slots617.zero_x 1001 1004 1002 f r row1001)
    (slots617.pos_x 1001 1004 1002 f r row1001)
    (slots617.inc_y 1002 1003 f r row1002 (Or.inl (by decide)))
    (slots617.jump 1003 1001 f r row1003)
    (slots617.jump 1004 995 f r row1004)

theorem site0995 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((995:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1005:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0995Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1005Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1005 f r x y z) (slots710.atReg 1009 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1005 4 1009 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1005 1009 1006 f r row1005)
    (slots710.pos_x 1005 1009 1006 f r row1005)
    (slots710.inc_y 1006 1007 f r row1006 (Or.inl (by decide)))
    (slots710.inc_y 1007 1008 f r row1007 (Or.inl (by decide)))
    (slots710.jump 1008 1005 f r row1008)

theorem site1005 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1005:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1009:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1005Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site1009Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1009 f r x y z) (slots160.atReg 1012 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1009 3 1012 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1009 1012 1010 f r row1009)
    (slots160.pos_x 1009 1012 1010 f r row1009)
    (slots160.inc_y 1010 1011 f r row1010 (Or.inl (by decide)))
    (slots160.jump 1011 1009 f r row1011)

theorem site1009 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1009:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1012:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1009Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1012Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1012 f r x y z) (slots210.atReg 1015 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1012 3 1015 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1012 1015 1013 f r row1012)
    (slots210.pos_x 1012 1015 1013 f r row1012)
    (slots210.inc_y 1013 1014 f r row1013 (Or.inl (by decide)))
    (slots210.jump 1014 1012 f r row1014)

theorem site1012 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1012:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1015:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1012Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1015Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1015 f r x y z) (slots617.atReg 1025 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1015 10 1025 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1015 1019 1016 f r row1015)
    (slots617.pos_y 1015 1019 1016 f r row1015)
    (slots617.inc_z 1016 1017 f r row1016 (Or.inl (by decide)))
    (slots617.inc_x 1017 1018 f r row1017 (Or.inl (by decide)))
    (slots617.jump 1018 1015 f r row1018)
    (slots617.zero_x 1019 1025 1020 f r row1019)
    (slots617.pos_x 1019 1025 1020 f r row1019)
    (slots617.inc_z 1020 1021 f r row1020 (Or.inl (by decide)))
    (slots617.zero_x 1021 1024 1022 f r row1021)
    (slots617.pos_x 1021 1024 1022 f r row1021)
    (slots617.inc_y 1022 1023 f r row1022 (Or.inl (by decide)))
    (slots617.jump 1023 1021 f r row1023)
    (slots617.jump 1024 1015 f r row1024)

theorem site1015 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1015:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1025:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1015Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1025Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1025 f r x y z) (slots720.atReg 1028 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1025 3 1028 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1025 1028 1026 f r row1025)
    (slots720.pos_x 1025 1028 1026 f r row1025)
    (slots720.inc_y 1026 1027 f r row1026 (Or.inl (by decide)))
    (slots720.jump 1027 1025 f r row1027)

theorem site1025 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1025:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1028:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1025Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1028Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1028 f r x y z) (slots561.atReg 1032 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1028 4 1032 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1028 1032 1029 f r row1028)
    (slots561.pos_x 1028 1032 1029 f r row1028)
    (slots561.inc_y 1029 1030 f r row1029 (Or.inl (by decide)))
    (slots561.inc_z 1030 1031 f r row1030 (Or.inl (by decide)))
    (slots561.jump 1031 1028 f r row1031)

theorem site1028 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1028:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1032:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1028Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1032Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1032 f r x y z) (slots650.atReg 1035 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1032 3 1035 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1032 1035 1033 f r row1032)
    (slots650.pos_x 1032 1035 1033 f r row1032)
    (slots650.inc_y 1033 1034 f r row1033 (Or.inl (by decide)))
    (slots650.jump 1034 1032 f r row1034)

theorem site1032 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1032:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1035:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1032Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1035Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1035 f r x y z) (slots160.atReg 1038 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1035 3 1038 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1035 1038 1036 f r row1035)
    (slots160.pos_x 1035 1038 1036 f r row1035)
    (slots160.inc_y 1036 1037 f r row1036 (Or.inl (by decide)))
    (slots160.jump 1037 1035 f r row1037)

theorem site1035 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1035:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1038:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1035Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1038Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1038 f r x y z) (slots210.atReg 1041 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1038 3 1041 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1038 1041 1039 f r row1038)
    (slots210.pos_x 1038 1041 1039 f r row1038)
    (slots210.inc_y 1039 1040 f r row1039 (Or.inl (by decide)))
    (slots210.jump 1040 1038 f r row1040)

theorem site1038 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1038:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1041:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1038Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1041Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1041 f r x y z) (slots617.atReg 1051 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1041 10 1051 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1041 1045 1042 f r row1041)
    (slots617.pos_y 1041 1045 1042 f r row1041)
    (slots617.inc_z 1042 1043 f r row1042 (Or.inl (by decide)))
    (slots617.inc_x 1043 1044 f r row1043 (Or.inl (by decide)))
    (slots617.jump 1044 1041 f r row1044)
    (slots617.zero_x 1045 1051 1046 f r row1045)
    (slots617.pos_x 1045 1051 1046 f r row1045)
    (slots617.inc_z 1046 1047 f r row1046 (Or.inl (by decide)))
    (slots617.zero_x 1047 1050 1048 f r row1047)
    (slots617.pos_x 1047 1050 1048 f r row1047)
    (slots617.inc_y 1048 1049 f r row1048 (Or.inl (by decide)))
    (slots617.jump 1049 1047 f r row1049)
    (slots617.jump 1050 1041 f r row1050)

theorem site1041 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1041:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1051:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1041Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1051Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1051 f r x y z) (slots720.atReg 1054 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1051 3 1054 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1051 1054 1052 f r row1051)
    (slots720.pos_x 1051 1054 1052 f r row1051)
    (slots720.inc_y 1052 1053 f r row1052 (Or.inl (by decide)))
    (slots720.jump 1053 1051 f r row1053)

theorem site1051 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1051:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1054:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1051Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1054Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1054 f r x y z) (slots561.atReg 1058 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1054 4 1058 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1054 1058 1055 f r row1054)
    (slots561.pos_x 1054 1058 1055 f r row1054)
    (slots561.inc_y 1055 1056 f r row1055 (Or.inl (by decide)))
    (slots561.inc_z 1056 1057 f r row1056 (Or.inl (by decide)))
    (slots561.jump 1057 1054 f r row1057)

theorem site1054 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1054:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1058:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1054Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1058Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1058 f r x y z) (slots650.atReg 1061 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1058 3 1061 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1058 1061 1059 f r row1058)
    (slots650.pos_x 1058 1061 1059 f r row1058)
    (slots650.inc_y 1059 1060 f r row1059 (Or.inl (by decide)))
    (slots650.jump 1060 1058 f r row1060)

theorem site1058 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1058:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1061:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1058Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1061Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1061 f r x y z) (slots267.atReg 1069 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1061 8 1069 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1061 1069 1062 f r row1061)
    (slots267.pos_x 1061 1069 1062 f r row1061)
    (slots267.inc_z 1062 1063 f r row1062 (Or.inl (by decide)))
    (slots267.zero_y 1063 1065 1064 f r row1063)
    (slots267.pos_y 1063 1065 1064 f r row1063)
    (slots267.jump 1064 1068 f r row1064)
    (slots267.zero_z 1065 1068 1066 f r row1065)
    (slots267.pos_z 1065 1068 1066 f r row1065)
    (slots267.inc_y 1066 1067 f r row1066 (Or.inl (by decide)))
    (slots267.jump 1067 1065 f r row1067)
    (slots267.jump 1068 1061 f r row1068)

theorem site1061 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1061:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1069:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1061Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1069Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1069 f r x y z) (slots720.atReg 1072 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1069 3 1072 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1069 1072 1070 f r row1069)
    (slots720.pos_x 1069 1072 1070 f r row1069)
    (slots720.inc_y 1070 1071 f r row1070 (Or.inl (by decide)))
    (slots720.jump 1071 1069 f r row1071)

theorem site1069 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1069:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1072:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1069Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1072Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1072 f r x y z) (slots617.atReg 1082 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1072 10 1082 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1072 1076 1073 f r row1072)
    (slots617.pos_y 1072 1076 1073 f r row1072)
    (slots617.inc_z 1073 1074 f r row1073 (Or.inl (by decide)))
    (slots617.inc_x 1074 1075 f r row1074 (Or.inl (by decide)))
    (slots617.jump 1075 1072 f r row1075)
    (slots617.zero_x 1076 1082 1077 f r row1076)
    (slots617.pos_x 1076 1082 1077 f r row1076)
    (slots617.inc_z 1077 1078 f r row1077 (Or.inl (by decide)))
    (slots617.zero_x 1078 1081 1079 f r row1078)
    (slots617.pos_x 1078 1081 1079 f r row1078)
    (slots617.inc_y 1079 1080 f r row1079 (Or.inl (by decide)))
    (slots617.jump 1080 1078 f r row1080)
    (slots617.jump 1081 1072 f r row1081)

theorem site1072 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1072:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1082:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1072Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1082Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1082 f r x y z) (slots710.atReg 1086 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1082 4 1086 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1082 1086 1083 f r row1082)
    (slots710.pos_x 1082 1086 1083 f r row1082)
    (slots710.inc_y 1083 1084 f r row1083 (Or.inl (by decide)))
    (slots710.inc_y 1084 1085 f r row1084 (Or.inl (by decide)))
    (slots710.jump 1085 1082 f r row1085)

theorem site1082 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1082:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1086:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1082Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1086 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1086:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1087:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1086 _ row1086]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site1087 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1087:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1088:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1087 _ row1087]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1088Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1088 f r x y z) (slots160.atReg 1091 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1088 3 1091 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1088 1091 1089 f r row1088)
    (slots160.pos_x 1088 1091 1089 f r row1088)
    (slots160.inc_y 1089 1090 f r row1089 (Or.inl (by decide)))
    (slots160.jump 1090 1088 f r row1090)

theorem site1088 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1088:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1091:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1088Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1091Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1091 f r x y z) (slots210.atReg 1094 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1091 3 1094 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1091 1094 1092 f r row1091)
    (slots210.pos_x 1091 1094 1092 f r row1091)
    (slots210.inc_y 1092 1093 f r row1092 (Or.inl (by decide)))
    (slots210.jump 1093 1091 f r row1093)

theorem site1091 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1091:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1094:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1091Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1094Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1094 f r x y z) (slots617.atReg 1104 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1094 10 1104 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1094 1098 1095 f r row1094)
    (slots617.pos_y 1094 1098 1095 f r row1094)
    (slots617.inc_z 1095 1096 f r row1095 (Or.inl (by decide)))
    (slots617.inc_x 1096 1097 f r row1096 (Or.inl (by decide)))
    (slots617.jump 1097 1094 f r row1097)
    (slots617.zero_x 1098 1104 1099 f r row1098)
    (slots617.pos_x 1098 1104 1099 f r row1098)
    (slots617.inc_z 1099 1100 f r row1099 (Or.inl (by decide)))
    (slots617.zero_x 1100 1103 1101 f r row1100)
    (slots617.pos_x 1100 1103 1101 f r row1100)
    (slots617.inc_y 1101 1102 f r row1101 (Or.inl (by decide)))
    (slots617.jump 1102 1100 f r row1102)
    (slots617.jump 1103 1094 f r row1103)

theorem site1094 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1094:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1104:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1094Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1104Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1104 f r x y z) (slots720.atReg 1107 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1104 3 1107 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1104 1107 1105 f r row1104)
    (slots720.pos_x 1104 1107 1105 f r row1104)
    (slots720.inc_y 1105 1106 f r row1105 (Or.inl (by decide)))
    (slots720.jump 1106 1104 f r row1106)

theorem site1104 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1104:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1107:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1104Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1107Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1107 f r x y z) (slots461.atReg 1111 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1107 4 1111 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1107 1111 1108 f r row1107)
    (slots461.pos_x 1107 1111 1108 f r row1107)
    (slots461.inc_y 1108 1109 f r row1108 (Or.inl (by decide)))
    (slots461.inc_z 1109 1110 f r row1109 (Or.inl (by decide)))
    (slots461.jump 1110 1107 f r row1110)

theorem site1107 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1107:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1111:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1107Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site1111Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1111 f r x y z) (slots640.atReg 1114 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1111 3 1114 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1111 1114 1112 f r row1111)
    (slots640.pos_x 1111 1114 1112 f r row1111)
    (slots640.inc_y 1112 1113 f r row1112 (Or.inl (by decide)))
    (slots640.jump 1113 1111 f r row1113)

theorem site1111 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1111:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1114:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1111Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site1114Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1114 f r x y z) (slots267.atReg 1122 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1114 8 1122 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1114 1122 1115 f r row1114)
    (slots267.pos_x 1114 1122 1115 f r row1114)
    (slots267.inc_z 1115 1116 f r row1115 (Or.inl (by decide)))
    (slots267.zero_y 1116 1118 1117 f r row1116)
    (slots267.pos_y 1116 1118 1117 f r row1116)
    (slots267.jump 1117 1121 f r row1117)
    (slots267.zero_z 1118 1121 1119 f r row1118)
    (slots267.pos_z 1118 1121 1119 f r row1118)
    (slots267.inc_y 1119 1120 f r row1119 (Or.inl (by decide)))
    (slots267.jump 1120 1118 f r row1120)
    (slots267.jump 1121 1114 f r row1121)

theorem site1114 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1114:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1122:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1114Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1122Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1122 f r x y z) (slots720.atReg 1125 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1122 3 1125 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1122 1125 1123 f r row1122)
    (slots720.pos_x 1122 1125 1123 f r row1122)
    (slots720.inc_y 1123 1124 f r row1123 (Or.inl (by decide)))
    (slots720.jump 1124 1122 f r row1124)

theorem site1122 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1122:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1125:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1122Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1125Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1125 f r x y z) (slots617.atReg 1135 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1125 10 1135 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1125 1129 1126 f r row1125)
    (slots617.pos_y 1125 1129 1126 f r row1125)
    (slots617.inc_z 1126 1127 f r row1126 (Or.inl (by decide)))
    (slots617.inc_x 1127 1128 f r row1127 (Or.inl (by decide)))
    (slots617.jump 1128 1125 f r row1128)
    (slots617.zero_x 1129 1135 1130 f r row1129)
    (slots617.pos_x 1129 1135 1130 f r row1129)
    (slots617.inc_z 1130 1131 f r row1130 (Or.inl (by decide)))
    (slots617.zero_x 1131 1134 1132 f r row1131)
    (slots617.pos_x 1131 1134 1132 f r row1131)
    (slots617.inc_y 1132 1133 f r row1132 (Or.inl (by decide)))
    (slots617.jump 1133 1131 f r row1133)
    (slots617.jump 1134 1125 f r row1134)

theorem site1125 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1125:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1135:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1125Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1135Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1135 f r x y z) (slots710.atReg 1139 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1135 4 1139 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1135 1139 1136 f r row1135)
    (slots710.pos_x 1135 1139 1136 f r row1135)
    (slots710.inc_y 1136 1137 f r row1136 (Or.inl (by decide)))
    (slots710.inc_y 1137 1138 f r row1137 (Or.inl (by decide)))
    (slots710.jump 1138 1135 f r row1138)

theorem site1135 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1135:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1139:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1135Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1139 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1139:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1140:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1139 _ row1139]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1140Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1140 f r x y z) (slots160.atReg 1143 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1140 3 1143 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1140 1143 1141 f r row1140)
    (slots160.pos_x 1140 1143 1141 f r row1140)
    (slots160.inc_y 1141 1142 f r row1141 (Or.inl (by decide)))
    (slots160.jump 1142 1140 f r row1142)

theorem site1140 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1140:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1143:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1140Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1143Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1143 f r x y z) (slots210.atReg 1146 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1143 3 1146 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1143 1146 1144 f r row1143)
    (slots210.pos_x 1143 1146 1144 f r row1143)
    (slots210.inc_y 1144 1145 f r row1144 (Or.inl (by decide)))
    (slots210.jump 1145 1143 f r row1145)

theorem site1143 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1143:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1146:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1143Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1146Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1146 f r x y z) (slots617.atReg 1156 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1146 10 1156 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1146 1150 1147 f r row1146)
    (slots617.pos_y 1146 1150 1147 f r row1146)
    (slots617.inc_z 1147 1148 f r row1147 (Or.inl (by decide)))
    (slots617.inc_x 1148 1149 f r row1148 (Or.inl (by decide)))
    (slots617.jump 1149 1146 f r row1149)
    (slots617.zero_x 1150 1156 1151 f r row1150)
    (slots617.pos_x 1150 1156 1151 f r row1150)
    (slots617.inc_z 1151 1152 f r row1151 (Or.inl (by decide)))
    (slots617.zero_x 1152 1155 1153 f r row1152)
    (slots617.pos_x 1152 1155 1153 f r row1152)
    (slots617.inc_y 1153 1154 f r row1153 (Or.inl (by decide)))
    (slots617.jump 1154 1152 f r row1154)
    (slots617.jump 1155 1146 f r row1155)

theorem site1146 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1146:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1156:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1146Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1156Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1156 f r x y z) (slots720.atReg 1159 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1156 3 1159 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1156 1159 1157 f r row1156)
    (slots720.pos_x 1156 1159 1157 f r row1156)
    (slots720.inc_y 1157 1158 f r row1157 (Or.inl (by decide)))
    (slots720.jump 1158 1156 f r row1158)

theorem site1156 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1156:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1159:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1156Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1159Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1159 f r x y z) (slots561.atReg 1163 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1159 4 1163 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1159 1163 1160 f r row1159)
    (slots561.pos_x 1159 1163 1160 f r row1159)
    (slots561.inc_y 1160 1161 f r row1160 (Or.inl (by decide)))
    (slots561.inc_z 1161 1162 f r row1161 (Or.inl (by decide)))
    (slots561.jump 1162 1159 f r row1162)

theorem site1159 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1159:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1163:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1159Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1163Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1163 f r x y z) (slots650.atReg 1166 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1163 3 1166 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1163 1166 1164 f r row1163)
    (slots650.pos_x 1163 1166 1164 f r row1163)
    (slots650.inc_y 1164 1165 f r row1164 (Or.inl (by decide)))
    (slots650.jump 1165 1163 f r row1165)

theorem site1163 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1163:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1166:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1163Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1166Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1166 f r x y z) (slots267.atReg 1174 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1166 8 1174 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1166 1174 1167 f r row1166)
    (slots267.pos_x 1166 1174 1167 f r row1166)
    (slots267.inc_z 1167 1168 f r row1167 (Or.inl (by decide)))
    (slots267.zero_y 1168 1170 1169 f r row1168)
    (slots267.pos_y 1168 1170 1169 f r row1168)
    (slots267.jump 1169 1173 f r row1169)
    (slots267.zero_z 1170 1173 1171 f r row1170)
    (slots267.pos_z 1170 1173 1171 f r row1170)
    (slots267.inc_y 1171 1172 f r row1171 (Or.inl (by decide)))
    (slots267.jump 1172 1170 f r row1172)
    (slots267.jump 1173 1166 f r row1173)

theorem site1166 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1166:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1174:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1166Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

end PA192.ModelSearch.RegisterSource.Certified
