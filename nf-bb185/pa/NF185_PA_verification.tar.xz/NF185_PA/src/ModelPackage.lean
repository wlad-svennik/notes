module
public import ModelBoundRows
public import ModelSignedStartup

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch PA192.ModelSearch.RegisterSource
namespace PA192.PhysicalModel.Replay
set_option maxHeartbeats 2000000

/-- Source-site soundness over a contiguous interval with no holes. -/
def Scope (lo count : Nat) : Prop := ∀ j : Nat, j<count → SiteSound (lo+j)

def checkWindow (s : Store NF192.Selected.machine) : (lo count : Nat) → List Location → Option (PLift (Scope lo count))
  | _,0,[] => some ⟨by intro j h; omega⟩
  | lo,k+1,l::rest => do
    if e : l.pc=lo then
      let first ← checkSite s l
      let next ← checkWindow s (lo+1) k rest
      return ⟨by
        intro j hj
        cases j with
        | zero => simpa [e] using first.down
        | succ u => have h : u<k := by omega
                    simpa only [Nat.add_assoc,Nat.add_comm 1 u,Nat.succ_eq_add_one] using next.down u h⟩
    else none
  | _,_,_ => none

def parseNumbers (s : String) : Option (List Nat) := (s.splitOn " ").mapM String.toNat?
def parseLocation : List Nat → Option Location
  | [p,wp,wz,cp,cz] => some ⟨p,wp,wz,cp,cz⟩ | _ => none
def dataLines (s : String) : List String := s.trimAscii.toString.splitOn "\n"

def checkPayload (lo count : Nat) (wire locations : String) : Option (PLift (Scope lo count)) := do
  let state ← (dataLines wire).foldlM (fun s line => do ingest 8 s (←parseNumbers line)) ({} : Store NF192.Selected.machine)
  let indices ← (dataLines locations).mapM (fun line => do parseLocation (←parseNumbers line))
  checkWindow state lo count indices

theorem payload_sound (lo count : Nat) (wire loc : String) (ok : (checkPayload lo count wire loc).isSome=true) :
    Scope lo count := by
  cases e : checkPayload lo count wire loc with
  | none => simp [e] at ok
  | some h => exact h.down

theorem scope_join (lo k n : Nat) (left : Scope lo k) (right : Scope (lo+k) n) : Scope lo (k+n) := by
  intro i h
  by_cases h1 : i<k
  · exact left i h1
  · have h2 : i-k<n := by omega
    have eq : lo+k+(i-k)=lo+i := by omega
    exact eq ▸ right (i-k) h2

theorem scope_all (complete : Scope 0 3089) (p : Fin 3089) : SiteSound p.val := by
  simpa using complete p.val p.isLt

/-- The source theorem and all-model simulation compose to the endpoint without any arithmetic
or semantic premises after the finite source-site interval has been validated. -/
theorem executes_of_scope (complete : Scope 0 3089) {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
    (n : V) (refutation : evalCode n=3) :
    ∃ t : V, state (rawRun NF192.Selected.machine NF192.Selected.start t)=192 := by
  apply h192_iff_model_run.mp
  exact h192_of_sites (scope_all complete) (ScannerSource.proof_halts_cold_margin refutation)

end PA192.PhysicalModel.Replay
#print axioms PA192.PhysicalModel.Replay.executes_of_scope
#print axioms PA192.PhysicalModel.Replay.payload_sound
