module
public import ModelSeed10
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter353 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1710:Nat):V) f (vector n 0 (atom60 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1707 f n (v+y) (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter352 f n t s c u v y d w).trans mid

theorem seedEmitAfter354 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1713:Nat):V) f (vector n (atom60 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1710 f n 0 (atom60 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d1 : (0+(atom60 n t s c u v y d w):V)=atom60 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter353 f n t s c u v y d w).trans mid

theorem seedEmitAfter355 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1723:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom61 n t s c u v y d w) w)) := by
  have micro := site1713 f n (atom60 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w
  have d7 : (0+(cantor (v+y) (atom60 n t s c u v y d w)):V)=atom61 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (v+y) (atom60 n t s c u v y d w)):V)=0+(atom61 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter354 f n t s c u v y d w).trans mid

theorem seedEmitAfter356 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1726:Nat):V) f (vector n 0 (atom61 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1723 f n 0 0 c (d+u) (v+y) 0 (atom61 n t s c u v y d w) w
  have d2 : (0+(atom61 n t s c u v y d w):V)=atom61 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter355 f n t s c u v y d w).trans mid

theorem seedEmitAfter357 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1730:Nat):V) f (vector n (v+y) (atom61 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1726 f n 0 (atom61 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter356 f n t s c u v y d w).trans mid

theorem seedEmitAfter358 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1733:Nat):V) f (vector n (v+y) (atom61 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1730 f n (v+y) (atom61 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter357 f n t s c u v y d w).trans mid

theorem seedEmitAfter359 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1741:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (v+y) (atom60 n t s c u v y d w) w)) := by
  have micro := site1733 f n (v+y) (atom61 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom61 n t s c u v y d w)):V)=v+y := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom61 n t s c u v y d w):V)=0+(atom61 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom61 n t s c u v y d w)):V)=left (atom61 n t s c u v y d w)).trans (by change left (cantor (v+y) (atom60 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom61 n t s c u v y d w)):V)=atom60 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom61 n t s c u v y d w):V)=0+(atom61 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom61 n t s c u v y d w)):V)=right (atom61 n t s c u v y d w)).trans (by change right (cantor (v+y) (atom60 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter358 f n t s c u v y d w).trans mid

theorem seedEmitAfter360 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1744:Nat):V) f (vector n (v+y) (atom60 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1741 f n (v+y) 0 c (d+u) (v+y) (v+y) (atom60 n t s c u v y d w) w
  have d2 : (0+(atom60 n t s c u v y d w):V)=atom60 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter359 f n t s c u v y d w).trans mid

theorem seedEmitAfter361 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1754:Nat):V) f (vector n 0 (atom60 n t s c u v y d w) c (d+u) (v+y) 0 (atom39 n t s c u v y d w) w)) := by
  have micro := site1744 f n (v+y) (atom60 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d7 : (0+(cantor (v+y) (v+y)):V)=atom39 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (v+y) (v+y)):V)=0+(atom39 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter360 f n t s c u v y d w).trans mid

theorem seedEmitAfter362 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1758:Nat):V) f (vector n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)) (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1754 f n 0 (atom60 n t s c u v y d w) c (d+u) (v+y) 0 (atom39 n t s c u v y d w) w
  have d1 : (0+(2*(atom39 n t s c u v y d w)):V)=(atom39 n t s c u v y d w)+(atom39 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom39 n t s c u v y d w)):V)=0+((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter361 f n t s c u v y d w).trans mid

theorem seedEmitAfter363 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1759:Nat):V) f (vector n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+1) (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1758 f n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)) (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w))+1:V)=(atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter362 f n t s c u v y d w).trans mid

theorem seedEmitAfter364 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1760:Nat):V) f (vector n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1759 f n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+1) (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+1)+1:V)=(atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter363 f n t s c u v y d w).trans mid

theorem seedEmitAfter365 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1768:Nat):V) f (vector n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) 0 c (d+u) (v+y) c (atom59 n t s c u v y d w) w)) := by
  have micro := site1760 f n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom60 n t s c u v y d w)):V)=c := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom60 n t s c u v y d w):V)=0+(atom60 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom60 n t s c u v y d w)):V)=left (atom60 n t s c u v y d w)).trans (by change left (cantor c (atom59 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom60 n t s c u v y d w)):V)=atom59 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom60 n t s c u v y d w):V)=0+(atom60 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom60 n t s c u v y d w)):V)=right (atom60 n t s c u v y d w)).trans (by change right (cantor c (atom59 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter364 f n t s c u v y d w).trans mid

theorem seedEmitAfter366 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1771:Nat):V) f (vector n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom59 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1768 f n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) 0 c (d+u) (v+y) c (atom59 n t s c u v y d w) w
  have d2 : (0+(atom59 n t s c u v y d w):V)=atom59 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter365 f n t s c u v y d w).trans mid

theorem seedEmitAfter367 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1781:Nat):V) f (vector n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) 0 (atom62 n t s c u v y d w) w)) := by
  have micro := site1771 f n ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom59 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d7 : (0+(cantor c ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2)):V)=atom62 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor c ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2)):V)=0+(atom62 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter366 f n t s c u v y d w).trans mid

theorem seedEmitAfter368 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1785:Nat):V) f (vector n ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)) (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1781 f n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) 0 (atom62 n t s c u v y d w) w
  have d1 : (0+(2*(atom62 n t s c u v y d w)):V)=(atom62 n t s c u v y d w)+(atom62 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom62 n t s c u v y d w)):V)=0+((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter367 f n t s c u v y d w).trans mid

theorem seedEmitAfter369 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1786:Nat):V) f (vector n ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1785 f n ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)) (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w))+1:V)=(atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter368 f n t s c u v y d w).trans mid

theorem seedEmitAfter370 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1789:Nat):V) f (vector n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1786 f n ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) (atom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1):V)=(atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter369 f n t s c u v y d w).trans mid

theorem seedEmitAfter371 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1792:Nat):V) f (vector n (atom59 n t s c u v y d w) 0 c (d+u) (v+y) ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1789 f n 0 (atom59 n t s c u v y d w) c (d+u) (v+y) ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom59 n t s c u v y d w):V)=atom59 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter370 f n t s c u v y d w).trans mid

theorem seedEmitAfter372 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1802:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom63 n t s c u v y d w) w)) := by
  have micro := site1792 f n (atom59 n t s c u v y d w) 0 c (d+u) (v+y) ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) (atom59 n t s c u v y d w)):V)=atom63 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) (atom59 n t s c u v y d w)):V)=0+(atom63 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter371 f n t s c u v y d w).trans mid

theorem seedEmitAfter373 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1805:Nat):V) f (vector n 0 (atom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1802 f n 0 0 c (d+u) (v+y) 0 (atom63 n t s c u v y d w) w
  have d2 : (0+(atom63 n t s c u v y d w):V)=atom63 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter372 f n t s c u v y d w).trans mid

theorem seedEmitAfter374 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1809:Nat):V) f (vector n (d+u) (atom63 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1805 f n 0 (atom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter373 f n t s c u v y d w).trans mid

theorem seedEmitAfter375 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1812:Nat):V) f (vector n (d+u) (atom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1809 f n (d+u) (atom63 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter374 f n t s c u v y d w).trans mid

theorem seedEmitAfter376 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1815:Nat):V) f (vector n 0 (atom63 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1812 f n (d+u) (atom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter375 f n t s c u v y d w).trans mid

theorem seedEmitAfter377 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1818:Nat):V) f (vector n (atom63 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1815 f n 0 (atom63 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom63 n t s c u v y d w):V)=atom63 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter376 f n t s c u v y d w).trans mid

theorem seedEmitAfter378 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1828:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom64 n t s c u v y d w) w)) := by
  have micro := site1818 f n (atom63 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom63 n t s c u v y d w)):V)=atom64 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom63 n t s c u v y d w)):V)=0+(atom64 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter377 f n t s c u v y d w).trans mid

theorem seedEmitAfter379 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1831:Nat):V) f (vector n 0 (atom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1828 f n 0 0 c (d+u) (v+y) 0 (atom64 n t s c u v y d w) w
  have d2 : (0+(atom64 n t s c u v y d w):V)=atom64 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter378 f n t s c u v y d w).trans mid

theorem seedEmitAfter380 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1835:Nat):V) f (vector n (v+y) (atom64 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1831 f n 0 (atom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter379 f n t s c u v y d w).trans mid

theorem seedEmitAfter381 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1838:Nat):V) f (vector n (v+y) (atom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1835 f n (v+y) (atom64 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter380 f n t s c u v y d w).trans mid

theorem seedEmitAfter382 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1846:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom63 n t s c u v y d w) w)) := by
  have micro := site1838 f n (v+y) (atom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom64 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom64 n t s c u v y d w):V)=0+(atom64 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom64 n t s c u v y d w)):V)=left (atom64 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom63 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom64 n t s c u v y d w)):V)=atom63 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom64 n t s c u v y d w):V)=0+(atom64 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom64 n t s c u v y d w)):V)=right (atom64 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom63 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter381 f n t s c u v y d w).trans mid

theorem seedEmitAfter383 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1849:Nat):V) f (vector n (v+y) (atom63 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1846 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom63 n t s c u v y d w) w
  have d2 : (0+(atom63 n t s c u v y d w):V)=atom63 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter382 f n t s c u v y d w).trans mid

theorem seedEmitAfter384 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((1859:Nat):V) f (vector n 0 (atom63 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site1849 f n (v+y) (atom63 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter383 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
