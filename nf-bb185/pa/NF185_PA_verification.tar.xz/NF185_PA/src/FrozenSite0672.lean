module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire0672 : String := include_str ".."/"data"/"FrozenSite0672.wire"
private def indices0672 : String := include_str ".."/"data"/"FrozenSite0672.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision0672 : (checkPayload 672 48 wire0672 indices0672).isSome=true := by decide +native

theorem scope0672 : Scope 672 48 := payload_sound _ _ _ _ decision0672
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope0672
