module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site2910Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2910 f r x y z) (slots650.atReg 2913 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2910 3 2913 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2910 2913 2911 f r row2910)
    (slots650.pos_x 2910 2913 2911 f r row2910)
    (slots650.inc_y 2911 2912 f r row2911 (Or.inl (by decide)))
    (slots650.jump 2912 2910 f r row2912)

theorem site2910 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2910:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2913:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2910Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site2913Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2913 f r x y z) (slots267.atReg 2921 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2913 8 2921 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2913 2921 2914 f r row2913)
    (slots267.pos_x 2913 2921 2914 f r row2913)
    (slots267.inc_z 2914 2915 f r row2914 (Or.inl (by decide)))
    (slots267.zero_y 2915 2917 2916 f r row2915)
    (slots267.pos_y 2915 2917 2916 f r row2915)
    (slots267.jump 2916 2920 f r row2916)
    (slots267.zero_z 2917 2920 2918 f r row2917)
    (slots267.pos_z 2917 2920 2918 f r row2917)
    (slots267.inc_y 2918 2919 f r row2918 (Or.inl (by decide)))
    (slots267.jump 2919 2917 f r row2919)
    (slots267.jump 2920 2913 f r row2920)

theorem site2913 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2913:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2921:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2913Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2921Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2921 f r x y z) (slots720.atReg 2924 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2921 3 2924 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2921 2924 2922 f r row2921)
    (slots720.pos_x 2921 2924 2922 f r row2921)
    (slots720.inc_y 2922 2923 f r row2922 (Or.inl (by decide)))
    (slots720.jump 2923 2921 f r row2923)

theorem site2921 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2921:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2924:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2921Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2924Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2924 f r x y z) (slots617.atReg 2934 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2924 10 2934 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2924 2928 2925 f r row2924)
    (slots617.pos_y 2924 2928 2925 f r row2924)
    (slots617.inc_z 2925 2926 f r row2925 (Or.inl (by decide)))
    (slots617.inc_x 2926 2927 f r row2926 (Or.inl (by decide)))
    (slots617.jump 2927 2924 f r row2927)
    (slots617.zero_x 2928 2934 2929 f r row2928)
    (slots617.pos_x 2928 2934 2929 f r row2928)
    (slots617.inc_z 2929 2930 f r row2929 (Or.inl (by decide)))
    (slots617.zero_x 2930 2933 2931 f r row2930)
    (slots617.pos_x 2930 2933 2931 f r row2930)
    (slots617.inc_y 2931 2932 f r row2931 (Or.inl (by decide)))
    (slots617.jump 2932 2930 f r row2932)
    (slots617.jump 2933 2924 f r row2933)

theorem site2924 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2924:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2934:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2924Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2934Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2934 f r x y z) (slots710.atReg 2938 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2934 4 2938 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2934 2938 2935 f r row2934)
    (slots710.pos_x 2934 2938 2935 f r row2934)
    (slots710.inc_y 2935 2936 f r row2935 (Or.inl (by decide)))
    (slots710.inc_y 2936 2937 f r row2936 (Or.inl (by decide)))
    (slots710.jump 2937 2934 f r row2937)

theorem site2934 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2934:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2938:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2934Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2938 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2938:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2939:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2938 _ row2938]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2939Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2939 f r x y z) (slots267.atReg 2947 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2939 8 2947 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2939 2947 2940 f r row2939)
    (slots267.pos_x 2939 2947 2940 f r row2939)
    (slots267.inc_z 2940 2941 f r row2940 (Or.inl (by decide)))
    (slots267.zero_y 2941 2943 2942 f r row2941)
    (slots267.pos_y 2941 2943 2942 f r row2941)
    (slots267.jump 2942 2946 f r row2942)
    (slots267.zero_z 2943 2946 2944 f r row2943)
    (slots267.pos_z 2943 2946 2944 f r row2943)
    (slots267.inc_y 2944 2945 f r row2944 (Or.inl (by decide)))
    (slots267.jump 2945 2943 f r row2945)
    (slots267.jump 2946 2939 f r row2946)

theorem site2939 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2939:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2947:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2939Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2947Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2947 f r x y z) (slots720.atReg 2950 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2947 3 2950 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2947 2950 2948 f r row2947)
    (slots720.pos_x 2947 2950 2948 f r row2947)
    (slots720.inc_y 2948 2949 f r row2948 (Or.inl (by decide)))
    (slots720.jump 2949 2947 f r row2949)

theorem site2947 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2947:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2950:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2947Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2950Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2950 f r x y z) (slots617.atReg 2960 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2950 10 2960 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2950 2954 2951 f r row2950)
    (slots617.pos_y 2950 2954 2951 f r row2950)
    (slots617.inc_z 2951 2952 f r row2951 (Or.inl (by decide)))
    (slots617.inc_x 2952 2953 f r row2952 (Or.inl (by decide)))
    (slots617.jump 2953 2950 f r row2953)
    (slots617.zero_x 2954 2960 2955 f r row2954)
    (slots617.pos_x 2954 2960 2955 f r row2954)
    (slots617.inc_z 2955 2956 f r row2955 (Or.inl (by decide)))
    (slots617.zero_x 2956 2959 2957 f r row2956)
    (slots617.pos_x 2956 2959 2957 f r row2956)
    (slots617.inc_y 2957 2958 f r row2957 (Or.inl (by decide)))
    (slots617.jump 2958 2956 f r row2958)
    (slots617.jump 2959 2950 f r row2959)

theorem site2950 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2950:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2960:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2950Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2960Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2960 f r x y z) (slots710.atReg 2964 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2960 4 2964 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2960 2964 2961 f r row2960)
    (slots710.pos_x 2960 2964 2961 f r row2960)
    (slots710.inc_y 2961 2962 f r row2961 (Or.inl (by decide)))
    (slots710.inc_y 2962 2963 f r row2962 (Or.inl (by decide)))
    (slots710.jump 2963 2960 f r row2963)

theorem site2960 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2960:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2964:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2960Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site2964Frame (f r : V) : ∀ x y z : V, Reach (slots401.atReg 2964 f r x y z) (slots401.atReg 2966 f r 0 y z) :=
  @Templates.clearBlock V _ _ (fun j=>slots401.atReg (destination 2964 2 2966 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots401.zero_x 2964 2966 2965 f r row2964)
    (slots401.pos_x 2964 2966 2965 f r row2964)
    (slots401.jump 2965 2964 f r row2965)

theorem site2964 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2964:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2966:Nat):V) f (vector r0 r1 r2 r3 0 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots401,vector,writeReg,pi₁_pair,pi₂_pair] using site2964Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r0 r1

private theorem site2966Frame (f r : V) : ∀ x y z : V, Reach (slots501.atReg 2966 f r x y z) (slots501.atReg 2968 f r 0 y z) :=
  @Templates.clearBlock V _ _ (fun j=>slots501.atReg (destination 2966 2 2968 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots501.zero_x 2966 2968 2967 f r row2966)
    (slots501.pos_x 2966 2968 2967 f r row2966)
    (slots501.jump 2967 2966 f r row2967)

theorem site2966 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2966:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2968:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots501,vector,writeReg,pi₁_pair,pi₂_pair] using site2966Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r0 r1

theorem site2968 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2968:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((39:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2968 _ row2968]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site2969Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2969:Nat):V) f (vector r0 r1 r2 r3 0 r5 r6 r7 r8)) (config ((2996:Nat):V) f (vector r0 r1 r2 r3 0 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2969 _ row2969]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site2969Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2969:Nat):V) f (vector r0 r1 r2 r3 (r4+1) r5 r6 r7 r8)) (config ((2970:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2969 _ row2969]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2970Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2970 f r x y z) (slots160.atReg 2973 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2970 3 2973 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2970 2973 2971 f r row2970)
    (slots160.pos_x 2970 2973 2971 f r row2970)
    (slots160.inc_y 2971 2972 f r row2971 (Or.inl (by decide)))
    (slots160.jump 2972 2970 f r row2972)

theorem site2970 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2970:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2973:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2970Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2973Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2973 f r x y z) (slots210.atReg 2976 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2973 3 2976 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2973 2976 2974 f r row2973)
    (slots210.pos_x 2973 2976 2974 f r row2973)
    (slots210.inc_y 2974 2975 f r row2974 (Or.inl (by decide)))
    (slots210.jump 2975 2973 f r row2975)

theorem site2973 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2973:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2976:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2973Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2976Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2976 f r x y z) (slots617.atReg 2986 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2976 10 2986 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2976 2980 2977 f r row2976)
    (slots617.pos_y 2976 2980 2977 f r row2976)
    (slots617.inc_z 2977 2978 f r row2977 (Or.inl (by decide)))
    (slots617.inc_x 2978 2979 f r row2978 (Or.inl (by decide)))
    (slots617.jump 2979 2976 f r row2979)
    (slots617.zero_x 2980 2986 2981 f r row2980)
    (slots617.pos_x 2980 2986 2981 f r row2980)
    (slots617.inc_z 2981 2982 f r row2981 (Or.inl (by decide)))
    (slots617.zero_x 2982 2985 2983 f r row2982)
    (slots617.pos_x 2982 2985 2983 f r row2982)
    (slots617.inc_y 2983 2984 f r row2983 (Or.inl (by decide)))
    (slots617.jump 2984 2982 f r row2984)
    (slots617.jump 2985 2976 f r row2985)

theorem site2976 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2976:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2986:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2976Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2986Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2986 f r x y z) (slots720.atReg 2989 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2986 3 2989 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2986 2989 2987 f r row2986)
    (slots720.pos_x 2986 2989 2987 f r row2986)
    (slots720.inc_y 2987 2988 f r row2987 (Or.inl (by decide)))
    (slots720.jump 2988 2986 f r row2988)

theorem site2986 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2986:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2989:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2986Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2989Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2989 f r x y z) (slots561.atReg 2993 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2989 4 2993 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2989 2993 2990 f r row2989)
    (slots561.pos_x 2989 2993 2990 f r row2989)
    (slots561.inc_y 2990 2991 f r row2990 (Or.inl (by decide)))
    (slots561.inc_z 2991 2992 f r row2991 (Or.inl (by decide)))
    (slots561.jump 2992 2989 f r row2992)

theorem site2989 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2989:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2993:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2989Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site2993Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2993 f r x y z) (slots650.atReg 2996 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2993 3 2996 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2993 2996 2994 f r row2993)
    (slots650.pos_x 2993 2996 2994 f r row2993)
    (slots650.inc_y 2994 2995 f r row2994 (Or.inl (by decide)))
    (slots650.jump 2995 2993 f r row2995)

theorem site2993 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2993:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2996:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2993Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site2996Frame (f r : V) : ∀ x y z : V, Reach (slots501.atReg 2996 f r x y z) (if x=3 then slots501.atReg 4095 f r 0 y z else slots501.atReg 3002 f r 0 y z) :=
  @Templates.goalBlock V _ _ (fun j=>slots501.atReg (destination 2996 6 3002 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots501.zero_x 2996 3000 2997 f r row2996)
    (slots501.pos_x 2996 3000 2997 f r row2996)
    (slots501.zero_x 2997 3000 2998 f r row2997)
    (slots501.pos_x 2997 3000 2998 f r row2997)
    (slots501.zero_x 2998 3000 2999 f r row2998)
    (slots501.pos_x 2998 3000 2999 f r row2998)
    (slots501.zero_x 2999 4095 3000 f r row2999)
    (slots501.pos_x 2999 4095 3000 f r row2999)
    (slots501.zero_x 3000 3002 3001 f r row3000)
    (slots501.pos_x 3000 3002 3001 f r row3000)
    (slots501.jump 3001 3000 f r row3001)

theorem site2996 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2996:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (if r5=3 then config ((4095:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8) else config ((3002:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots501,vector,writeReg,pi₁_pair,pi₂_pair] using site2996Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r0 r1

private theorem site3002Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 3002 f r x y z) (slots267.atReg 3010 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 3002 8 3010 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 3002 3010 3003 f r row3002)
    (slots267.pos_x 3002 3010 3003 f r row3002)
    (slots267.inc_z 3003 3004 f r row3003 (Or.inl (by decide)))
    (slots267.zero_y 3004 3006 3005 f r row3004)
    (slots267.pos_y 3004 3006 3005 f r row3004)
    (slots267.jump 3005 3009 f r row3005)
    (slots267.zero_z 3006 3009 3007 f r row3006)
    (slots267.pos_z 3006 3009 3007 f r row3006)
    (slots267.inc_y 3007 3008 f r row3007 (Or.inl (by decide)))
    (slots267.jump 3008 3006 f r row3008)
    (slots267.jump 3009 3002 f r row3009)

theorem site3002 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3002:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3010:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site3002Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site3010Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 3010 f r x y z) (slots720.atReg 3013 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 3010 3 3013 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 3010 3013 3011 f r row3010)
    (slots720.pos_x 3010 3013 3011 f r row3010)
    (slots720.inc_y 3011 3012 f r row3011 (Or.inl (by decide)))
    (slots720.jump 3012 3010 f r row3012)

theorem site3010 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3010:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3013:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site3010Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site3013Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 3013 f r x y z) (slots650.atReg 3016 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 3013 3 3016 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 3013 3016 3014 f r row3013)
    (slots650.pos_x 3013 3016 3014 f r row3013)
    (slots650.inc_y 3014 3015 f r row3014 (Or.inl (by decide)))
    (slots650.jump 3015 3013 f r row3015)

theorem site3013 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3013:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3016:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site3013Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

theorem site3016 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3016:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((0:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 3016 _ row3016]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site3017Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 3017 f r x y z) (slots160.atReg 3020 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 3017 3 3020 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 3017 3020 3018 f r row3017)
    (slots160.pos_x 3017 3020 3018 f r row3017)
    (slots160.inc_y 3018 3019 f r row3018 (Or.inl (by decide)))
    (slots160.jump 3019 3017 f r row3019)

theorem site3017 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3017:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3020:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site3017Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site3020Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 3020 f r x y z) (slots210.atReg 3023 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 3020 3 3023 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 3020 3023 3021 f r row3020)
    (slots210.pos_x 3020 3023 3021 f r row3020)
    (slots210.inc_y 3021 3022 f r row3021 (Or.inl (by decide)))
    (slots210.jump 3022 3020 f r row3022)

theorem site3020 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3020:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3023:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site3020Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site3023Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 3023 f r x y z) (slots617.atReg 3033 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 3023 10 3033 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 3023 3027 3024 f r row3023)
    (slots617.pos_y 3023 3027 3024 f r row3023)
    (slots617.inc_z 3024 3025 f r row3024 (Or.inl (by decide)))
    (slots617.inc_x 3025 3026 f r row3025 (Or.inl (by decide)))
    (slots617.jump 3026 3023 f r row3026)
    (slots617.zero_x 3027 3033 3028 f r row3027)
    (slots617.pos_x 3027 3033 3028 f r row3027)
    (slots617.inc_z 3028 3029 f r row3028 (Or.inl (by decide)))
    (slots617.zero_x 3029 3032 3030 f r row3029)
    (slots617.pos_x 3029 3032 3030 f r row3029)
    (slots617.inc_y 3030 3031 f r row3030 (Or.inl (by decide)))
    (slots617.jump 3031 3029 f r row3031)
    (slots617.jump 3032 3023 f r row3032)

theorem site3023 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3023:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3033:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site3023Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site3033Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 3033 f r x y z) (slots720.atReg 3036 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 3033 3 3036 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 3033 3036 3034 f r row3033)
    (slots720.pos_x 3033 3036 3034 f r row3033)
    (slots720.inc_y 3034 3035 f r row3034 (Or.inl (by decide)))
    (slots720.jump 3035 3033 f r row3035)

theorem site3033 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3033:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3036:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site3033Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site3036Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 3036 f r x y z) (slots461.atReg 3040 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 3036 4 3040 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 3036 3040 3037 f r row3036)
    (slots461.pos_x 3036 3040 3037 f r row3036)
    (slots461.inc_y 3037 3038 f r row3037 (Or.inl (by decide)))
    (slots461.inc_z 3038 3039 f r row3038 (Or.inl (by decide)))
    (slots461.jump 3039 3036 f r row3039)

theorem site3036 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3036:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3040:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site3036Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site3040Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 3040 f r x y z) (slots640.atReg 3043 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 3040 3 3043 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 3040 3043 3041 f r row3040)
    (slots640.pos_x 3040 3043 3041 f r row3040)
    (slots640.inc_y 3041 3042 f r row3041 (Or.inl (by decide)))
    (slots640.jump 3042 3040 f r row3042)

theorem site3040 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3040:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3043:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site3040Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site3043Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 3043 f r x y z) (slots267.atReg 3051 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 3043 8 3051 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 3043 3051 3044 f r row3043)
    (slots267.pos_x 3043 3051 3044 f r row3043)
    (slots267.inc_z 3044 3045 f r row3044 (Or.inl (by decide)))
    (slots267.zero_y 3045 3047 3046 f r row3045)
    (slots267.pos_y 3045 3047 3046 f r row3045)
    (slots267.jump 3046 3050 f r row3046)
    (slots267.zero_z 3047 3050 3048 f r row3047)
    (slots267.pos_z 3047 3050 3048 f r row3047)
    (slots267.inc_y 3048 3049 f r row3048 (Or.inl (by decide)))
    (slots267.jump 3049 3047 f r row3049)
    (slots267.jump 3050 3043 f r row3050)

theorem site3043 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3043:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3051:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site3043Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site3051Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 3051 f r x y z) (slots720.atReg 3054 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 3051 3 3054 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 3051 3054 3052 f r row3051)
    (slots720.pos_x 3051 3054 3052 f r row3051)
    (slots720.inc_y 3052 3053 f r row3052 (Or.inl (by decide)))
    (slots720.jump 3053 3051 f r row3053)

theorem site3051 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3051:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3054:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site3051Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site3054Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 3054 f r x y z) (slots617.atReg 3064 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 3054 10 3064 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 3054 3058 3055 f r row3054)
    (slots617.pos_y 3054 3058 3055 f r row3054)
    (slots617.inc_z 3055 3056 f r row3055 (Or.inl (by decide)))
    (slots617.inc_x 3056 3057 f r row3056 (Or.inl (by decide)))
    (slots617.jump 3057 3054 f r row3057)
    (slots617.zero_x 3058 3064 3059 f r row3058)
    (slots617.pos_x 3058 3064 3059 f r row3058)
    (slots617.inc_z 3059 3060 f r row3059 (Or.inl (by decide)))
    (slots617.zero_x 3060 3063 3061 f r row3060)
    (slots617.pos_x 3060 3063 3061 f r row3060)
    (slots617.inc_y 3061 3062 f r row3061 (Or.inl (by decide)))
    (slots617.jump 3062 3060 f r row3062)
    (slots617.jump 3063 3054 f r row3063)

theorem site3054 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3054:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3064:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site3054Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site3064Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 3064 f r x y z) (slots710.atReg 3068 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 3064 4 3068 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 3064 3068 3065 f r row3064)
    (slots710.pos_x 3064 3068 3065 f r row3064)
    (slots710.inc_y 3065 3066 f r row3065 (Or.inl (by decide)))
    (slots710.inc_y 3066 3067 f r row3066 (Or.inl (by decide)))
    (slots710.jump 3067 3064 f r row3067)

theorem site3064 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3064:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3068:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site3064Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site3068Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 3068 f r x y z) (slots160.atReg 3071 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 3068 3 3071 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 3068 3071 3069 f r row3068)
    (slots160.pos_x 3068 3071 3069 f r row3068)
    (slots160.inc_y 3069 3070 f r row3069 (Or.inl (by decide)))
    (slots160.jump 3070 3068 f r row3070)

theorem site3068 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3068:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3071:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site3068Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site3071Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 3071 f r x y z) (slots650.atReg 3078 f r 0 ((x-y)+(y-x)) z) :=
  @Templates.differenceBlock V _ _ (fun j=>slots650.atReg (destination 3071 7 3078 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 3071 3078 3072 f r row3071)
    (slots650.pos_x 3071 3078 3072 f r row3071)
    (slots650.zero_y 3072 3074 3073 f r row3072)
    (slots650.pos_y 3072 3074 3073 f r row3072)
    (slots650.jump 3073 3071 f r row3073)
    (slots650.inc_y 3074 3075 f r row3074 (Or.inl (by decide)))
    (slots650.zero_x 3075 3078 3076 f r row3075)
    (slots650.pos_x 3075 3078 3076 f r row3075)
    (slots650.inc_y 3076 3077 f r row3076 (Or.inl (by decide)))
    (slots650.jump 3077 3075 f r row3077)

theorem site3071 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3071:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3078:Nat):V) f (vector r0 r1 r2 r3 r4 ((r6-r5)+(r5-r6)) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site3071Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

theorem site3078Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3078:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8)) (config ((3080:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 3078 _ row3078]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site3078Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3078:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+1) r6 r7 r8)) (config ((3079:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 3078 _ row3078]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site3079 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3079:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3087:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 3079 _ row3079]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site3080Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 3080 f r x y z) (slots461.atReg 3084 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 3080 4 3084 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 3080 3084 3081 f r row3080)
    (slots461.pos_x 3080 3084 3081 f r row3080)
    (slots461.inc_y 3081 3082 f r row3081 (Or.inl (by decide)))
    (slots461.inc_z 3082 3083 f r row3082 (Or.inl (by decide)))
    (slots461.jump 3083 3080 f r row3083)

theorem site3080 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3080:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3084:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site3080Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site3084Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 3084 f r x y z) (slots640.atReg 3087 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 3084 3 3087 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 3084 3087 3085 f r row3084)
    (slots640.pos_x 3084 3087 3085 f r row3084)
    (slots640.inc_y 3085 3086 f r row3085 (Or.inl (by decide)))
    (slots640.jump 3086 3084 f r row3086)

theorem site3084 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3084:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3087:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site3084Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site3087Frame (f r : V) : ∀ x y z : V, Reach (slots501.atReg 3087 f r x y z) (slots501.atReg 0 f r 0 y z) :=
  @Templates.clearBlock V _ _ (fun j=>slots501.atReg (destination 3087 2 0 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots501.zero_x 3087 0 3088 f r row3087)
    (slots501.pos_x 3087 0 3088 f r row3087)
    (slots501.jump 3088 3087 f r row3088)

theorem site3087 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3087:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((0:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots501,vector,writeReg,pi₁_pair,pi₂_pair] using site3087Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r0 r1

end PA192.ModelSearch.RegisterSource.Certified
