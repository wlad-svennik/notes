module
public import ModelSeed14
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter481 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2325:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 (atom19 n t s c u v y d w) w)) := by
  have micro := site2315 f n (v+y) (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (v+y)):V)=atom19 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (v+y)):V)=0+(atom19 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter480 f n t s c u v y d w).trans mid

theorem seedEmitAfter482 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2329:Nat):V) f (vector n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2325 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 (atom19 n t s c u v y d w) w
  have d1 : (0+(2*(atom19 n t s c u v y d w)):V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom19 n t s c u v y d w)):V)=0+((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter481 f n t s c u v y d w).trans mid

theorem seedEmitAfter483 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2330:Nat):V) f (vector n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2329 f n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w))+1:V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter482 f n t s c u v y d w).trans mid

theorem seedEmitAfter484 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2333:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2330 f n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1):V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter483 f n t s c u v y d w).trans mid

theorem seedEmitAfter485 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2336:Nat):V) f (vector n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2333 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter484 f n t s c u v y d w).trans mid

theorem seedEmitAfter486 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2346:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom78 n t s c u v y d w) w)) := by
  have micro := site2336 f n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom75 n t s c u v y d w)):V)=atom78 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom75 n t s c u v y d w)):V)=0+(atom78 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter485 f n t s c u v y d w).trans mid

theorem seedEmitAfter487 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2349:Nat):V) f (vector n 0 (atom78 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2346 f n 0 0 c (d+u) (v+y) 0 (atom78 n t s c u v y d w) w
  have d2 : (0+(atom78 n t s c u v y d w):V)=atom78 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter486 f n t s c u v y d w).trans mid

theorem seedEmitAfter488 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2350:Nat):V) f (vector n 1 (atom78 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2349 f n 0 (atom78 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+1:V)=1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter487 f n t s c u v y d w).trans mid

theorem seedEmitAfter489 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2351:Nat):V) f (vector n 2 (atom78 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2350 f n 1 (atom78 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (1+1:V)=2 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter488 f n t s c u v y d w).trans mid

theorem seedEmitAfter490 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2352:Nat):V) f (vector n 3 (atom78 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2351 f n 2 (atom78 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (2+1:V)=3 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter489 f n t s c u v y d w).trans mid

theorem seedEmitAfter491 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2360:Nat):V) f (vector n 3 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom75 n t s c u v y d w) w)) := by
  have micro := site2352 f n 3 (atom78 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom78 n t s c u v y d w)):V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom78 n t s c u v y d w):V)=0+(atom78 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom78 n t s c u v y d w)):V)=left (atom78 n t s c u v y d w)).trans (by change left (cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom75 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom78 n t s c u v y d w)):V)=atom75 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom78 n t s c u v y d w):V)=0+(atom78 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom78 n t s c u v y d w)):V)=right (atom78 n t s c u v y d w)).trans (by change right (cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom75 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter490 f n t s c u v y d w).trans mid

theorem seedEmitAfter492 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2363:Nat):V) f (vector n 3 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2360 f n 3 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom75 n t s c u v y d w) w
  have d2 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter491 f n t s c u v y d w).trans mid

theorem seedEmitAfter493 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2373:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 (atom79 n t s c u v y d w) w)) := by
  have micro := site2363 f n 3 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 3):V)=atom79 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 3):V)=0+(atom79 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter492 f n t s c u v y d w).trans mid

theorem seedEmitAfter494 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2377:Nat):V) f (vector n ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2373 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 (atom79 n t s c u v y d w) w
  have d1 : (0+(2*(atom79 n t s c u v y d w)):V)=(atom79 n t s c u v y d w)+(atom79 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom79 n t s c u v y d w)):V)=0+((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter493 f n t s c u v y d w).trans mid

theorem seedEmitAfter495 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2380:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) 0 w)) := by
  have micro := site2377 f n ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)):V)=(atom79 n t s c u v y d w)+(atom79 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter494 f n t s c u v y d w).trans mid

theorem seedEmitAfter496 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2383:Nat):V) f (vector n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) 0 w)) := by
  have micro := site2380 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) 0 w
  have d1 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter495 f n t s c u v y d w).trans mid

theorem seedEmitAfter497 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2393:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom80 n t s c u v y d w) w)) := by
  have micro := site2383 f n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) (atom75 n t s c u v y d w)):V)=atom80 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) (atom75 n t s c u v y d w)):V)=0+(atom80 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter496 f n t s c u v y d w).trans mid

theorem seedEmitAfter498 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2396:Nat):V) f (vector n 0 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2393 f n 0 0 c (d+u) (v+y) 0 (atom80 n t s c u v y d w) w
  have d2 : (0+(atom80 n t s c u v y d w):V)=atom80 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter497 f n t s c u v y d w).trans mid

theorem seedEmitAfter499 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2397:Nat):V) f (vector n 1 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2396 f n 0 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+1:V)=1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter498 f n t s c u v y d w).trans mid

theorem seedEmitAfter500 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2398:Nat):V) f (vector n 2 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2397 f n 1 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (1+1:V)=2 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter499 f n t s c u v y d w).trans mid

theorem seedEmitAfter501 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2399:Nat):V) f (vector n 3 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2398 f n 2 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (2+1:V)=3 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter500 f n t s c u v y d w).trans mid

theorem seedEmitAfter502 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2402:Nat):V) f (vector n 0 (atom80 n t s c u v y d w) c (d+u) (v+y) 3 0 w)) := by
  have micro := site2399 f n 3 (atom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+3:V)=3 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter501 f n t s c u v y d w).trans mid

theorem seedEmitAfter503 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2405:Nat):V) f (vector n (atom80 n t s c u v y d w) 0 c (d+u) (v+y) 3 0 w)) := by
  have micro := site2402 f n 0 (atom80 n t s c u v y d w) c (d+u) (v+y) 3 0 w
  have d1 : (0+(atom80 n t s c u v y d w):V)=atom80 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter502 f n t s c u v y d w).trans mid

theorem seedEmitAfter504 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2415:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom81 n t s c u v y d w) w)) := by
  have micro := site2405 f n (atom80 n t s c u v y d w) 0 c (d+u) (v+y) 3 0 w
  have d7 : (0+(cantor 3 (atom80 n t s c u v y d w)):V)=atom81 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 3 (atom80 n t s c u v y d w)):V)=0+(atom81 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter503 f n t s c u v y d w).trans mid

theorem seedEmitAfter505 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2418:Nat):V) f (vector n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2415 f n 0 0 c (d+u) (v+y) 0 (atom81 n t s c u v y d w) w
  have d2 : (0+(atom81 n t s c u v y d w):V)=atom81 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter504 f n t s c u v y d w).trans mid

theorem seedEmitAfter506 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2421:Nat):V) f (vector n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2418 f n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+0:V)=0 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter505 f n t s c u v y d w).trans mid

theorem seedEmitAfter507 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2424:Nat):V) f (vector n (atom81 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w)) := by
  have micro := site2421 f n 0 (atom81 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(atom81 n t s c u v y d w):V)=atom81 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter506 f n t s c u v y d w).trans mid

theorem seedEmitAfter508 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2434:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom82 n t s c u v y d w) w)) := by
  have micro := site2424 f n (atom81 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w
  have d7 : (0+(cantor 0 (atom81 n t s c u v y d w)):V)=atom82 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 0 (atom81 n t s c u v y d w)):V)=0+(atom82 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter507 f n t s c u v y d w).trans mid

theorem seedEmitAfter509 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2437:Nat):V) f (vector n 0 (atom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2434 f n 0 0 c (d+u) (v+y) 0 (atom82 n t s c u v y d w) w
  have d2 : (0+(atom82 n t s c u v y d w):V)=atom82 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter508 f n t s c u v y d w).trans mid

theorem seedEmitAfter510 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2441:Nat):V) f (vector n (d+u) (atom82 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2437 f n 0 (atom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter509 f n t s c u v y d w).trans mid

theorem seedEmitAfter511 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2444:Nat):V) f (vector n (d+u) (atom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2441 f n (d+u) (atom82 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter510 f n t s c u v y d w).trans mid

theorem seedEmitAfter512 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2452:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) 0 (atom81 n t s c u v y d w) w)) := by
  have micro := site2444 f n (d+u) (atom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom82 n t s c u v y d w)):V)=0 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom82 n t s c u v y d w):V)=0+(atom82 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom82 n t s c u v y d w)):V)=left (atom82 n t s c u v y d w)).trans (by change left (cantor 0 (atom81 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom82 n t s c u v y d w)):V)=atom81 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom82 n t s c u v y d w):V)=0+(atom82 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom82 n t s c u v y d w)):V)=right (atom82 n t s c u v y d w)).trans (by change right (cantor 0 (atom81 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter511 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
