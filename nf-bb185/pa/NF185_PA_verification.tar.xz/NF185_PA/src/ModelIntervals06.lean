module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site1174Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1174 f r x y z) (slots720.atReg 1177 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1174 3 1177 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1174 1177 1175 f r row1174)
    (slots720.pos_x 1174 1177 1175 f r row1174)
    (slots720.inc_y 1175 1176 f r row1175 (Or.inl (by decide)))
    (slots720.jump 1176 1174 f r row1176)

theorem site1174 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1174:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1177:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1174Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1177Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1177 f r x y z) (slots617.atReg 1187 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1177 10 1187 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1177 1181 1178 f r row1177)
    (slots617.pos_y 1177 1181 1178 f r row1177)
    (slots617.inc_z 1178 1179 f r row1178 (Or.inl (by decide)))
    (slots617.inc_x 1179 1180 f r row1179 (Or.inl (by decide)))
    (slots617.jump 1180 1177 f r row1180)
    (slots617.zero_x 1181 1187 1182 f r row1181)
    (slots617.pos_x 1181 1187 1182 f r row1181)
    (slots617.inc_z 1182 1183 f r row1182 (Or.inl (by decide)))
    (slots617.zero_x 1183 1186 1184 f r row1183)
    (slots617.pos_x 1183 1186 1184 f r row1183)
    (slots617.inc_y 1184 1185 f r row1184 (Or.inl (by decide)))
    (slots617.jump 1185 1183 f r row1185)
    (slots617.jump 1186 1177 f r row1186)

theorem site1177 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1177:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1187:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1177Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1187Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1187 f r x y z) (slots710.atReg 1191 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1187 4 1191 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1187 1191 1188 f r row1187)
    (slots710.pos_x 1187 1191 1188 f r row1187)
    (slots710.inc_y 1188 1189 f r row1188 (Or.inl (by decide)))
    (slots710.inc_y 1189 1190 f r row1189 (Or.inl (by decide)))
    (slots710.jump 1190 1187 f r row1190)

theorem site1187 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1187:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1191:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1187Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1191 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1191:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1192:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1191 _ row1191]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1192Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1192 f r x y z) (slots160.atReg 1195 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1192 3 1195 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1192 1195 1193 f r row1192)
    (slots160.pos_x 1192 1195 1193 f r row1192)
    (slots160.inc_y 1193 1194 f r row1193 (Or.inl (by decide)))
    (slots160.jump 1194 1192 f r row1194)

theorem site1192 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1192:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1195:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1192Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1195Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1195 f r x y z) (slots210.atReg 1198 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1195 3 1198 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1195 1198 1196 f r row1195)
    (slots210.pos_x 1195 1198 1196 f r row1195)
    (slots210.inc_y 1196 1197 f r row1196 (Or.inl (by decide)))
    (slots210.jump 1197 1195 f r row1197)

theorem site1195 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1195:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1198:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1195Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1198Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1198 f r x y z) (slots617.atReg 1208 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1198 10 1208 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1198 1202 1199 f r row1198)
    (slots617.pos_y 1198 1202 1199 f r row1198)
    (slots617.inc_z 1199 1200 f r row1199 (Or.inl (by decide)))
    (slots617.inc_x 1200 1201 f r row1200 (Or.inl (by decide)))
    (slots617.jump 1201 1198 f r row1201)
    (slots617.zero_x 1202 1208 1203 f r row1202)
    (slots617.pos_x 1202 1208 1203 f r row1202)
    (slots617.inc_z 1203 1204 f r row1203 (Or.inl (by decide)))
    (slots617.zero_x 1204 1207 1205 f r row1204)
    (slots617.pos_x 1204 1207 1205 f r row1204)
    (slots617.inc_y 1205 1206 f r row1205 (Or.inl (by decide)))
    (slots617.jump 1206 1204 f r row1206)
    (slots617.jump 1207 1198 f r row1207)

theorem site1198 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1198:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1208:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1198Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1208Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1208 f r x y z) (slots720.atReg 1211 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1208 3 1211 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1208 1211 1209 f r row1208)
    (slots720.pos_x 1208 1211 1209 f r row1208)
    (slots720.inc_y 1209 1210 f r row1209 (Or.inl (by decide)))
    (slots720.jump 1210 1208 f r row1210)

theorem site1208 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1208:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1211:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1208Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1211Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1211 f r x y z) (slots461.atReg 1215 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1211 4 1215 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1211 1215 1212 f r row1211)
    (slots461.pos_x 1211 1215 1212 f r row1211)
    (slots461.inc_y 1212 1213 f r row1212 (Or.inl (by decide)))
    (slots461.inc_z 1213 1214 f r row1213 (Or.inl (by decide)))
    (slots461.jump 1214 1211 f r row1214)

theorem site1211 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1211:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1215:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1211Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site1215Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1215 f r x y z) (slots640.atReg 1218 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1215 3 1218 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1215 1218 1216 f r row1215)
    (slots640.pos_x 1215 1218 1216 f r row1215)
    (slots640.inc_y 1216 1217 f r row1216 (Or.inl (by decide)))
    (slots640.jump 1217 1215 f r row1217)

theorem site1215 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1215:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1218:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1215Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site1218Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1218 f r x y z) (slots160.atReg 1221 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1218 3 1221 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1218 1221 1219 f r row1218)
    (slots160.pos_x 1218 1221 1219 f r row1218)
    (slots160.inc_y 1219 1220 f r row1219 (Or.inl (by decide)))
    (slots160.jump 1220 1218 f r row1220)

theorem site1218 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1218:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1221:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1218Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1221Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1221 f r x y z) (slots210.atReg 1224 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1221 3 1224 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1221 1224 1222 f r row1221)
    (slots210.pos_x 1221 1224 1222 f r row1221)
    (slots210.inc_y 1222 1223 f r row1222 (Or.inl (by decide)))
    (slots210.jump 1223 1221 f r row1223)

theorem site1221 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1221:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1224:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1221Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1224Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1224 f r x y z) (slots617.atReg 1234 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1224 10 1234 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1224 1228 1225 f r row1224)
    (slots617.pos_y 1224 1228 1225 f r row1224)
    (slots617.inc_z 1225 1226 f r row1225 (Or.inl (by decide)))
    (slots617.inc_x 1226 1227 f r row1226 (Or.inl (by decide)))
    (slots617.jump 1227 1224 f r row1227)
    (slots617.zero_x 1228 1234 1229 f r row1228)
    (slots617.pos_x 1228 1234 1229 f r row1228)
    (slots617.inc_z 1229 1230 f r row1229 (Or.inl (by decide)))
    (slots617.zero_x 1230 1233 1231 f r row1230)
    (slots617.pos_x 1230 1233 1231 f r row1230)
    (slots617.inc_y 1231 1232 f r row1231 (Or.inl (by decide)))
    (slots617.jump 1232 1230 f r row1232)
    (slots617.jump 1233 1224 f r row1233)

theorem site1224 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1224:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1234:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1224Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1234Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1234 f r x y z) (slots720.atReg 1237 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1234 3 1237 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1234 1237 1235 f r row1234)
    (slots720.pos_x 1234 1237 1235 f r row1234)
    (slots720.inc_y 1235 1236 f r row1235 (Or.inl (by decide)))
    (slots720.jump 1236 1234 f r row1236)

theorem site1234 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1234:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1237:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1234Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1237Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 1237 f r x y z) (slots361.atReg 1241 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 1237 4 1241 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 1237 1241 1238 f r row1237)
    (slots361.pos_x 1237 1241 1238 f r row1237)
    (slots361.inc_y 1238 1239 f r row1238 (Or.inl (by decide)))
    (slots361.inc_z 1239 1240 f r row1239 (Or.inl (by decide)))
    (slots361.jump 1240 1237 f r row1240)

theorem site1237 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1237:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1241:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site1237Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site1241Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 1241 f r x y z) (slots630.atReg 1244 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 1241 3 1244 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 1241 1244 1242 f r row1241)
    (slots630.pos_x 1241 1244 1242 f r row1241)
    (slots630.inc_y 1242 1243 f r row1242 (Or.inl (by decide)))
    (slots630.jump 1243 1241 f r row1243)

theorem site1241 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1241:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1244:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site1241Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site1244Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1244 f r x y z) (slots267.atReg 1252 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1244 8 1252 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1244 1252 1245 f r row1244)
    (slots267.pos_x 1244 1252 1245 f r row1244)
    (slots267.inc_z 1245 1246 f r row1245 (Or.inl (by decide)))
    (slots267.zero_y 1246 1248 1247 f r row1246)
    (slots267.pos_y 1246 1248 1247 f r row1246)
    (slots267.jump 1247 1251 f r row1247)
    (slots267.zero_z 1248 1251 1249 f r row1248)
    (slots267.pos_z 1248 1251 1249 f r row1248)
    (slots267.inc_y 1249 1250 f r row1249 (Or.inl (by decide)))
    (slots267.jump 1250 1248 f r row1250)
    (slots267.jump 1251 1244 f r row1251)

theorem site1244 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1244:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1252:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1244Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1252Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1252 f r x y z) (slots720.atReg 1255 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1252 3 1255 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1252 1255 1253 f r row1252)
    (slots720.pos_x 1252 1255 1253 f r row1252)
    (slots720.inc_y 1253 1254 f r row1253 (Or.inl (by decide)))
    (slots720.jump 1254 1252 f r row1254)

theorem site1252 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1252:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1255:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1252Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1255Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1255 f r x y z) (slots617.atReg 1265 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1255 10 1265 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1255 1259 1256 f r row1255)
    (slots617.pos_y 1255 1259 1256 f r row1255)
    (slots617.inc_z 1256 1257 f r row1256 (Or.inl (by decide)))
    (slots617.inc_x 1257 1258 f r row1257 (Or.inl (by decide)))
    (slots617.jump 1258 1255 f r row1258)
    (slots617.zero_x 1259 1265 1260 f r row1259)
    (slots617.pos_x 1259 1265 1260 f r row1259)
    (slots617.inc_z 1260 1261 f r row1260 (Or.inl (by decide)))
    (slots617.zero_x 1261 1264 1262 f r row1261)
    (slots617.pos_x 1261 1264 1262 f r row1261)
    (slots617.inc_y 1262 1263 f r row1262 (Or.inl (by decide)))
    (slots617.jump 1263 1261 f r row1263)
    (slots617.jump 1264 1255 f r row1264)

theorem site1255 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1255:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1265:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1255Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1265Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1265 f r x y z) (slots710.atReg 1269 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1265 4 1269 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1265 1269 1266 f r row1265)
    (slots710.pos_x 1265 1269 1266 f r row1265)
    (slots710.inc_y 1266 1267 f r row1266 (Or.inl (by decide)))
    (slots710.inc_y 1267 1268 f r row1267 (Or.inl (by decide)))
    (slots710.jump 1268 1265 f r row1268)

theorem site1265 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1265:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1269:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1265Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1269 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1269:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1270:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1269 _ row1269]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1270Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1270 f r x y z) (slots160.atReg 1273 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1270 3 1273 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1270 1273 1271 f r row1270)
    (slots160.pos_x 1270 1273 1271 f r row1270)
    (slots160.inc_y 1271 1272 f r row1271 (Or.inl (by decide)))
    (slots160.jump 1272 1270 f r row1272)

theorem site1270 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1270:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1273:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1270Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1273Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1273 f r x y z) (slots210.atReg 1276 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1273 3 1276 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1273 1276 1274 f r row1273)
    (slots210.pos_x 1273 1276 1274 f r row1273)
    (slots210.inc_y 1274 1275 f r row1274 (Or.inl (by decide)))
    (slots210.jump 1275 1273 f r row1275)

theorem site1273 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1273:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1276:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1273Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1276Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1276 f r x y z) (slots617.atReg 1286 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1276 10 1286 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1276 1280 1277 f r row1276)
    (slots617.pos_y 1276 1280 1277 f r row1276)
    (slots617.inc_z 1277 1278 f r row1277 (Or.inl (by decide)))
    (slots617.inc_x 1278 1279 f r row1278 (Or.inl (by decide)))
    (slots617.jump 1279 1276 f r row1279)
    (slots617.zero_x 1280 1286 1281 f r row1280)
    (slots617.pos_x 1280 1286 1281 f r row1280)
    (slots617.inc_z 1281 1282 f r row1281 (Or.inl (by decide)))
    (slots617.zero_x 1282 1285 1283 f r row1282)
    (slots617.pos_x 1282 1285 1283 f r row1282)
    (slots617.inc_y 1283 1284 f r row1283 (Or.inl (by decide)))
    (slots617.jump 1284 1282 f r row1284)
    (slots617.jump 1285 1276 f r row1285)

theorem site1276 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1276:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1286:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1276Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1286Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1286 f r x y z) (slots720.atReg 1289 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1286 3 1289 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1286 1289 1287 f r row1286)
    (slots720.pos_x 1286 1289 1287 f r row1286)
    (slots720.inc_y 1287 1288 f r row1287 (Or.inl (by decide)))
    (slots720.jump 1288 1286 f r row1288)

theorem site1286 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1286:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1289:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1286Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1289Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 1289 f r x y z) (slots361.atReg 1293 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 1289 4 1293 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 1289 1293 1290 f r row1289)
    (slots361.pos_x 1289 1293 1290 f r row1289)
    (slots361.inc_y 1290 1291 f r row1290 (Or.inl (by decide)))
    (slots361.inc_z 1291 1292 f r row1291 (Or.inl (by decide)))
    (slots361.jump 1292 1289 f r row1292)

theorem site1289 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1289:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1293:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site1289Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site1293Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 1293 f r x y z) (slots630.atReg 1296 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 1293 3 1296 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 1293 1296 1294 f r row1293)
    (slots630.pos_x 1293 1296 1294 f r row1293)
    (slots630.inc_y 1294 1295 f r row1294 (Or.inl (by decide)))
    (slots630.jump 1295 1293 f r row1295)

theorem site1293 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1293:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1296:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site1293Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site1296Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1296 f r x y z) (slots160.atReg 1299 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1296 3 1299 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1296 1299 1297 f r row1296)
    (slots160.pos_x 1296 1299 1297 f r row1296)
    (slots160.inc_y 1297 1298 f r row1297 (Or.inl (by decide)))
    (slots160.jump 1298 1296 f r row1298)

theorem site1296 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1296:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1299:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1296Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1299Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1299 f r x y z) (slots210.atReg 1302 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1299 3 1302 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1299 1302 1300 f r row1299)
    (slots210.pos_x 1299 1302 1300 f r row1299)
    (slots210.inc_y 1300 1301 f r row1300 (Or.inl (by decide)))
    (slots210.jump 1301 1299 f r row1301)

theorem site1299 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1299:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1302:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1299Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1302Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1302 f r x y z) (slots617.atReg 1312 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1302 10 1312 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1302 1306 1303 f r row1302)
    (slots617.pos_y 1302 1306 1303 f r row1302)
    (slots617.inc_z 1303 1304 f r row1303 (Or.inl (by decide)))
    (slots617.inc_x 1304 1305 f r row1304 (Or.inl (by decide)))
    (slots617.jump 1305 1302 f r row1305)
    (slots617.zero_x 1306 1312 1307 f r row1306)
    (slots617.pos_x 1306 1312 1307 f r row1306)
    (slots617.inc_z 1307 1308 f r row1307 (Or.inl (by decide)))
    (slots617.zero_x 1308 1311 1309 f r row1308)
    (slots617.pos_x 1308 1311 1309 f r row1308)
    (slots617.inc_y 1309 1310 f r row1309 (Or.inl (by decide)))
    (slots617.jump 1310 1308 f r row1310)
    (slots617.jump 1311 1302 f r row1311)

theorem site1302 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1302:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1312:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1302Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1312Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1312 f r x y z) (slots720.atReg 1315 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1312 3 1315 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1312 1315 1313 f r row1312)
    (slots720.pos_x 1312 1315 1313 f r row1312)
    (slots720.inc_y 1313 1314 f r row1313 (Or.inl (by decide)))
    (slots720.jump 1314 1312 f r row1314)

theorem site1312 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1312:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1315:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1312Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1315Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1315 f r x y z) (slots561.atReg 1319 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1315 4 1319 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1315 1319 1316 f r row1315)
    (slots561.pos_x 1315 1319 1316 f r row1315)
    (slots561.inc_y 1316 1317 f r row1316 (Or.inl (by decide)))
    (slots561.inc_z 1317 1318 f r row1317 (Or.inl (by decide)))
    (slots561.jump 1318 1315 f r row1318)

theorem site1315 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1315:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1319:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1315Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1319Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1319 f r x y z) (slots650.atReg 1322 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1319 3 1322 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1319 1322 1320 f r row1319)
    (slots650.pos_x 1319 1322 1320 f r row1319)
    (slots650.inc_y 1320 1321 f r row1320 (Or.inl (by decide)))
    (slots650.jump 1321 1319 f r row1321)

theorem site1319 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1319:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1322:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1319Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1322Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1322 f r x y z) (slots267.atReg 1330 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1322 8 1330 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1322 1330 1323 f r row1322)
    (slots267.pos_x 1322 1330 1323 f r row1322)
    (slots267.inc_z 1323 1324 f r row1323 (Or.inl (by decide)))
    (slots267.zero_y 1324 1326 1325 f r row1324)
    (slots267.pos_y 1324 1326 1325 f r row1324)
    (slots267.jump 1325 1329 f r row1325)
    (slots267.zero_z 1326 1329 1327 f r row1326)
    (slots267.pos_z 1326 1329 1327 f r row1326)
    (slots267.inc_y 1327 1328 f r row1327 (Or.inl (by decide)))
    (slots267.jump 1328 1326 f r row1328)
    (slots267.jump 1329 1322 f r row1329)

theorem site1322 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1322:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1330:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1322Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1330Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1330 f r x y z) (slots720.atReg 1333 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1330 3 1333 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1330 1333 1331 f r row1330)
    (slots720.pos_x 1330 1333 1331 f r row1330)
    (slots720.inc_y 1331 1332 f r row1331 (Or.inl (by decide)))
    (slots720.jump 1332 1330 f r row1332)

theorem site1330 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1330:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1333:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1330Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1333Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1333 f r x y z) (slots617.atReg 1343 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1333 10 1343 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1333 1337 1334 f r row1333)
    (slots617.pos_y 1333 1337 1334 f r row1333)
    (slots617.inc_z 1334 1335 f r row1334 (Or.inl (by decide)))
    (slots617.inc_x 1335 1336 f r row1335 (Or.inl (by decide)))
    (slots617.jump 1336 1333 f r row1336)
    (slots617.zero_x 1337 1343 1338 f r row1337)
    (slots617.pos_x 1337 1343 1338 f r row1337)
    (slots617.inc_z 1338 1339 f r row1338 (Or.inl (by decide)))
    (slots617.zero_x 1339 1342 1340 f r row1339)
    (slots617.pos_x 1339 1342 1340 f r row1339)
    (slots617.inc_y 1340 1341 f r row1340 (Or.inl (by decide)))
    (slots617.jump 1341 1339 f r row1341)
    (slots617.jump 1342 1333 f r row1342)

theorem site1333 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1333:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1343:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1333Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1343Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1343 f r x y z) (slots710.atReg 1347 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1343 4 1347 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1343 1347 1344 f r row1343)
    (slots710.pos_x 1343 1347 1344 f r row1343)
    (slots710.inc_y 1344 1345 f r row1344 (Or.inl (by decide)))
    (slots710.inc_y 1345 1346 f r row1345 (Or.inl (by decide)))
    (slots710.jump 1346 1343 f r row1346)

theorem site1343 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1343:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1347:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1343Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1347 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1347:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1348:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1347 _ row1347]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1348Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1348 f r x y z) (slots160.atReg 1351 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1348 3 1351 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1348 1351 1349 f r row1348)
    (slots160.pos_x 1348 1351 1349 f r row1348)
    (slots160.inc_y 1349 1350 f r row1349 (Or.inl (by decide)))
    (slots160.jump 1350 1348 f r row1350)

theorem site1348 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1348:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1351:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1348Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1351Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1351 f r x y z) (slots210.atReg 1354 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1351 3 1354 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1351 1354 1352 f r row1351)
    (slots210.pos_x 1351 1354 1352 f r row1351)
    (slots210.inc_y 1352 1353 f r row1352 (Or.inl (by decide)))
    (slots210.jump 1353 1351 f r row1353)

theorem site1351 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1351:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1354:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1351Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1354Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1354 f r x y z) (slots617.atReg 1364 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1354 10 1364 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1354 1358 1355 f r row1354)
    (slots617.pos_y 1354 1358 1355 f r row1354)
    (slots617.inc_z 1355 1356 f r row1355 (Or.inl (by decide)))
    (slots617.inc_x 1356 1357 f r row1356 (Or.inl (by decide)))
    (slots617.jump 1357 1354 f r row1357)
    (slots617.zero_x 1358 1364 1359 f r row1358)
    (slots617.pos_x 1358 1364 1359 f r row1358)
    (slots617.inc_z 1359 1360 f r row1359 (Or.inl (by decide)))
    (slots617.zero_x 1360 1363 1361 f r row1360)
    (slots617.pos_x 1360 1363 1361 f r row1360)
    (slots617.inc_y 1361 1362 f r row1361 (Or.inl (by decide)))
    (slots617.jump 1362 1360 f r row1362)
    (slots617.jump 1363 1354 f r row1363)

theorem site1354 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1354:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1364:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1354Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

end PA192.ModelSearch.RegisterSource.Certified
