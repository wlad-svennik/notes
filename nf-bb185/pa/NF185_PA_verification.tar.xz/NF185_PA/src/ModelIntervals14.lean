module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site2720Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2720 f r x y z) (slots720.atReg 2723 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2720 3 2723 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2720 2723 2721 f r row2720)
    (slots720.pos_x 2720 2723 2721 f r row2720)
    (slots720.inc_y 2721 2722 f r row2721 (Or.inl (by decide)))
    (slots720.jump 2722 2720 f r row2722)

theorem site2720 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2720:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2723:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2720Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2723Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2723 f r x y z) (slots461.atReg 2727 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2723 4 2727 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2723 2727 2724 f r row2723)
    (slots461.pos_x 2723 2727 2724 f r row2723)
    (slots461.inc_y 2724 2725 f r row2724 (Or.inl (by decide)))
    (slots461.inc_z 2725 2726 f r row2725 (Or.inl (by decide)))
    (slots461.jump 2726 2723 f r row2726)

theorem site2723 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2723:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2727:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2723Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site2727Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2727 f r x y z) (slots640.atReg 2730 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2727 3 2730 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2727 2730 2728 f r row2727)
    (slots640.pos_x 2727 2730 2728 f r row2727)
    (slots640.inc_y 2728 2729 f r row2728 (Or.inl (by decide)))
    (slots640.jump 2729 2727 f r row2729)

theorem site2727 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2727:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2730:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2727Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site2730Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2730 f r x y z) (slots160.atReg 2733 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2730 3 2733 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2730 2733 2731 f r row2730)
    (slots160.pos_x 2730 2733 2731 f r row2730)
    (slots160.inc_y 2731 2732 f r row2731 (Or.inl (by decide)))
    (slots160.jump 2732 2730 f r row2732)

theorem site2730 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2730:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2733:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2730Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2733Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2733 f r x y z) (slots210.atReg 2736 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2733 3 2736 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2733 2736 2734 f r row2733)
    (slots210.pos_x 2733 2736 2734 f r row2733)
    (slots210.inc_y 2734 2735 f r row2734 (Or.inl (by decide)))
    (slots210.jump 2735 2733 f r row2735)

theorem site2733 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2733:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2736:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2733Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2736Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2736 f r x y z) (slots617.atReg 2746 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2736 10 2746 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2736 2740 2737 f r row2736)
    (slots617.pos_y 2736 2740 2737 f r row2736)
    (slots617.inc_z 2737 2738 f r row2737 (Or.inl (by decide)))
    (slots617.inc_x 2738 2739 f r row2738 (Or.inl (by decide)))
    (slots617.jump 2739 2736 f r row2739)
    (slots617.zero_x 2740 2746 2741 f r row2740)
    (slots617.pos_x 2740 2746 2741 f r row2740)
    (slots617.inc_z 2741 2742 f r row2741 (Or.inl (by decide)))
    (slots617.zero_x 2742 2745 2743 f r row2742)
    (slots617.pos_x 2742 2745 2743 f r row2742)
    (slots617.inc_y 2743 2744 f r row2743 (Or.inl (by decide)))
    (slots617.jump 2744 2742 f r row2744)
    (slots617.jump 2745 2736 f r row2745)

theorem site2736 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2736:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2746:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2736Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2746Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2746 f r x y z) (slots720.atReg 2749 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2746 3 2749 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2746 2749 2747 f r row2746)
    (slots720.pos_x 2746 2749 2747 f r row2746)
    (slots720.inc_y 2747 2748 f r row2747 (Or.inl (by decide)))
    (slots720.jump 2748 2746 f r row2748)

theorem site2746 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2746:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2749:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2746Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2749Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2749 f r x y z) (slots461.atReg 2753 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2749 4 2753 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2749 2753 2750 f r row2749)
    (slots461.pos_x 2749 2753 2750 f r row2749)
    (slots461.inc_y 2750 2751 f r row2750 (Or.inl (by decide)))
    (slots461.inc_z 2751 2752 f r row2751 (Or.inl (by decide)))
    (slots461.jump 2752 2749 f r row2752)

theorem site2749 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2749:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2753:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2749Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site2753Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2753 f r x y z) (slots640.atReg 2756 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2753 3 2756 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2753 2756 2754 f r row2753)
    (slots640.pos_x 2753 2756 2754 f r row2753)
    (slots640.inc_y 2754 2755 f r row2754 (Or.inl (by decide)))
    (slots640.jump 2755 2753 f r row2755)

theorem site2753 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2753:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2756:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2753Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site2756Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2756 f r x y z) (slots160.atReg 2759 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2756 3 2759 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2756 2759 2757 f r row2756)
    (slots160.pos_x 2756 2759 2757 f r row2756)
    (slots160.inc_y 2757 2758 f r row2757 (Or.inl (by decide)))
    (slots160.jump 2758 2756 f r row2758)

theorem site2756 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2756:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2759:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2756Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2759Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2759 f r x y z) (slots210.atReg 2762 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2759 3 2762 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2759 2762 2760 f r row2759)
    (slots210.pos_x 2759 2762 2760 f r row2759)
    (slots210.inc_y 2760 2761 f r row2760 (Or.inl (by decide)))
    (slots210.jump 2761 2759 f r row2761)

theorem site2759 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2759:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2762:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2759Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2762Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2762 f r x y z) (slots617.atReg 2772 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2762 10 2772 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2762 2766 2763 f r row2762)
    (slots617.pos_y 2762 2766 2763 f r row2762)
    (slots617.inc_z 2763 2764 f r row2763 (Or.inl (by decide)))
    (slots617.inc_x 2764 2765 f r row2764 (Or.inl (by decide)))
    (slots617.jump 2765 2762 f r row2765)
    (slots617.zero_x 2766 2772 2767 f r row2766)
    (slots617.pos_x 2766 2772 2767 f r row2766)
    (slots617.inc_z 2767 2768 f r row2767 (Or.inl (by decide)))
    (slots617.zero_x 2768 2771 2769 f r row2768)
    (slots617.pos_x 2768 2771 2769 f r row2768)
    (slots617.inc_y 2769 2770 f r row2769 (Or.inl (by decide)))
    (slots617.jump 2770 2768 f r row2770)
    (slots617.jump 2771 2762 f r row2771)

theorem site2762 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2762:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2772:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2762Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2772Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2772 f r x y z) (slots720.atReg 2775 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2772 3 2775 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2772 2775 2773 f r row2772)
    (slots720.pos_x 2772 2775 2773 f r row2772)
    (slots720.inc_y 2773 2774 f r row2773 (Or.inl (by decide)))
    (slots720.jump 2774 2772 f r row2774)

theorem site2772 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2772:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2775:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2772Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2775Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2775 f r x y z) (slots561.atReg 2779 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2775 4 2779 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2775 2779 2776 f r row2775)
    (slots561.pos_x 2775 2779 2776 f r row2775)
    (slots561.inc_y 2776 2777 f r row2776 (Or.inl (by decide)))
    (slots561.inc_z 2777 2778 f r row2777 (Or.inl (by decide)))
    (slots561.jump 2778 2775 f r row2778)

theorem site2775 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2775:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2779:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2775Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site2779Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2779 f r x y z) (slots650.atReg 2782 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2779 3 2782 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2779 2782 2780 f r row2779)
    (slots650.pos_x 2779 2782 2780 f r row2779)
    (slots650.inc_y 2780 2781 f r row2780 (Or.inl (by decide)))
    (slots650.jump 2781 2779 f r row2781)

theorem site2779 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2779:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2782:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2779Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site2782Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2782 f r x y z) (slots267.atReg 2790 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2782 8 2790 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2782 2790 2783 f r row2782)
    (slots267.pos_x 2782 2790 2783 f r row2782)
    (slots267.inc_z 2783 2784 f r row2783 (Or.inl (by decide)))
    (slots267.zero_y 2784 2786 2785 f r row2784)
    (slots267.pos_y 2784 2786 2785 f r row2784)
    (slots267.jump 2785 2789 f r row2785)
    (slots267.zero_z 2786 2789 2787 f r row2786)
    (slots267.pos_z 2786 2789 2787 f r row2786)
    (slots267.inc_y 2787 2788 f r row2787 (Or.inl (by decide)))
    (slots267.jump 2788 2786 f r row2788)
    (slots267.jump 2789 2782 f r row2789)

theorem site2782 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2782:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2790:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2782Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2790Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2790 f r x y z) (slots720.atReg 2793 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2790 3 2793 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2790 2793 2791 f r row2790)
    (slots720.pos_x 2790 2793 2791 f r row2790)
    (slots720.inc_y 2791 2792 f r row2791 (Or.inl (by decide)))
    (slots720.jump 2792 2790 f r row2792)

theorem site2790 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2790:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2793:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2790Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2793Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2793 f r x y z) (slots617.atReg 2803 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2793 10 2803 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2793 2797 2794 f r row2793)
    (slots617.pos_y 2793 2797 2794 f r row2793)
    (slots617.inc_z 2794 2795 f r row2794 (Or.inl (by decide)))
    (slots617.inc_x 2795 2796 f r row2795 (Or.inl (by decide)))
    (slots617.jump 2796 2793 f r row2796)
    (slots617.zero_x 2797 2803 2798 f r row2797)
    (slots617.pos_x 2797 2803 2798 f r row2797)
    (slots617.inc_z 2798 2799 f r row2798 (Or.inl (by decide)))
    (slots617.zero_x 2799 2802 2800 f r row2799)
    (slots617.pos_x 2799 2802 2800 f r row2799)
    (slots617.inc_y 2800 2801 f r row2800 (Or.inl (by decide)))
    (slots617.jump 2801 2799 f r row2801)
    (slots617.jump 2802 2793 f r row2802)

theorem site2793 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2793:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2803:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2793Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2803Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2803 f r x y z) (slots710.atReg 2807 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2803 4 2807 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2803 2807 2804 f r row2803)
    (slots710.pos_x 2803 2807 2804 f r row2803)
    (slots710.inc_y 2804 2805 f r row2804 (Or.inl (by decide)))
    (slots710.inc_y 2805 2806 f r row2805 (Or.inl (by decide)))
    (slots710.jump 2806 2803 f r row2806)

theorem site2803 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2803:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2807:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2803Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2807 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2807:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2808:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2807 _ row2807]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site2808 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2808:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2809:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2808 _ row2808]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2809Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2809 f r x y z) (slots267.atReg 2817 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2809 8 2817 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2809 2817 2810 f r row2809)
    (slots267.pos_x 2809 2817 2810 f r row2809)
    (slots267.inc_z 2810 2811 f r row2810 (Or.inl (by decide)))
    (slots267.zero_y 2811 2813 2812 f r row2811)
    (slots267.pos_y 2811 2813 2812 f r row2811)
    (slots267.jump 2812 2816 f r row2812)
    (slots267.zero_z 2813 2816 2814 f r row2813)
    (slots267.pos_z 2813 2816 2814 f r row2813)
    (slots267.inc_y 2814 2815 f r row2814 (Or.inl (by decide)))
    (slots267.jump 2815 2813 f r row2815)
    (slots267.jump 2816 2809 f r row2816)

theorem site2809 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2809:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2817:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2809Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2817Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2817 f r x y z) (slots720.atReg 2820 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2817 3 2820 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2817 2820 2818 f r row2817)
    (slots720.pos_x 2817 2820 2818 f r row2817)
    (slots720.inc_y 2818 2819 f r row2818 (Or.inl (by decide)))
    (slots720.jump 2819 2817 f r row2819)

theorem site2817 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2817:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2820:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2817Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2820Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2820 f r x y z) (slots617.atReg 2830 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2820 10 2830 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2820 2824 2821 f r row2820)
    (slots617.pos_y 2820 2824 2821 f r row2820)
    (slots617.inc_z 2821 2822 f r row2821 (Or.inl (by decide)))
    (slots617.inc_x 2822 2823 f r row2822 (Or.inl (by decide)))
    (slots617.jump 2823 2820 f r row2823)
    (slots617.zero_x 2824 2830 2825 f r row2824)
    (slots617.pos_x 2824 2830 2825 f r row2824)
    (slots617.inc_z 2825 2826 f r row2825 (Or.inl (by decide)))
    (slots617.zero_x 2826 2829 2827 f r row2826)
    (slots617.pos_x 2826 2829 2827 f r row2826)
    (slots617.inc_y 2827 2828 f r row2827 (Or.inl (by decide)))
    (slots617.jump 2828 2826 f r row2828)
    (slots617.jump 2829 2820 f r row2829)

theorem site2820 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2820:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2830:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2820Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2830Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2830 f r x y z) (slots710.atReg 2834 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2830 4 2834 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2830 2834 2831 f r row2830)
    (slots710.pos_x 2830 2834 2831 f r row2830)
    (slots710.inc_y 2831 2832 f r row2831 (Or.inl (by decide)))
    (slots710.inc_y 2832 2833 f r row2832 (Or.inl (by decide)))
    (slots710.jump 2833 2830 f r row2833)

theorem site2830 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2830:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2834:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2830Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2834 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2834:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2835:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2834 _ row2834]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2835Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2835 f r x y z) (slots267.atReg 2843 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2835 8 2843 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2835 2843 2836 f r row2835)
    (slots267.pos_x 2835 2843 2836 f r row2835)
    (slots267.inc_z 2836 2837 f r row2836 (Or.inl (by decide)))
    (slots267.zero_y 2837 2839 2838 f r row2837)
    (slots267.pos_y 2837 2839 2838 f r row2837)
    (slots267.jump 2838 2842 f r row2838)
    (slots267.zero_z 2839 2842 2840 f r row2839)
    (slots267.pos_z 2839 2842 2840 f r row2839)
    (slots267.inc_y 2840 2841 f r row2840 (Or.inl (by decide)))
    (slots267.jump 2841 2839 f r row2841)
    (slots267.jump 2842 2835 f r row2842)

theorem site2835 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2835:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2843:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2835Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2843Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2843 f r x y z) (slots720.atReg 2846 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2843 3 2846 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2843 2846 2844 f r row2843)
    (slots720.pos_x 2843 2846 2844 f r row2843)
    (slots720.inc_y 2844 2845 f r row2844 (Or.inl (by decide)))
    (slots720.jump 2845 2843 f r row2845)

theorem site2843 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2843:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2846:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2843Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2846Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2846 f r x y z) (slots617.atReg 2856 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2846 10 2856 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2846 2850 2847 f r row2846)
    (slots617.pos_y 2846 2850 2847 f r row2846)
    (slots617.inc_z 2847 2848 f r row2847 (Or.inl (by decide)))
    (slots617.inc_x 2848 2849 f r row2848 (Or.inl (by decide)))
    (slots617.jump 2849 2846 f r row2849)
    (slots617.zero_x 2850 2856 2851 f r row2850)
    (slots617.pos_x 2850 2856 2851 f r row2850)
    (slots617.inc_z 2851 2852 f r row2851 (Or.inl (by decide)))
    (slots617.zero_x 2852 2855 2853 f r row2852)
    (slots617.pos_x 2852 2855 2853 f r row2852)
    (slots617.inc_y 2853 2854 f r row2853 (Or.inl (by decide)))
    (slots617.jump 2854 2852 f r row2854)
    (slots617.jump 2855 2846 f r row2855)

theorem site2846 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2846:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2856:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2846Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2856Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2856 f r x y z) (slots710.atReg 2860 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2856 4 2860 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2856 2860 2857 f r row2856)
    (slots710.pos_x 2856 2860 2857 f r row2856)
    (slots710.inc_y 2857 2858 f r row2857 (Or.inl (by decide)))
    (slots710.inc_y 2858 2859 f r row2858 (Or.inl (by decide)))
    (slots710.jump 2859 2856 f r row2859)

theorem site2856 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2856:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2860:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2856Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2860 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2860:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2861:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2860 _ row2860]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2861Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2861 f r x y z) (slots160.atReg 2864 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2861 3 2864 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2861 2864 2862 f r row2861)
    (slots160.pos_x 2861 2864 2862 f r row2861)
    (slots160.inc_y 2862 2863 f r row2862 (Or.inl (by decide)))
    (slots160.jump 2863 2861 f r row2863)

theorem site2861 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2861:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2864:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2861Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2864Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2864 f r x y z) (slots210.atReg 2867 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2864 3 2867 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2864 2867 2865 f r row2864)
    (slots210.pos_x 2864 2867 2865 f r row2864)
    (slots210.inc_y 2865 2866 f r row2865 (Or.inl (by decide)))
    (slots210.jump 2866 2864 f r row2866)

theorem site2864 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2864:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2867:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2864Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2867Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2867 f r x y z) (slots617.atReg 2877 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2867 10 2877 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2867 2871 2868 f r row2867)
    (slots617.pos_y 2867 2871 2868 f r row2867)
    (slots617.inc_z 2868 2869 f r row2868 (Or.inl (by decide)))
    (slots617.inc_x 2869 2870 f r row2869 (Or.inl (by decide)))
    (slots617.jump 2870 2867 f r row2870)
    (slots617.zero_x 2871 2877 2872 f r row2871)
    (slots617.pos_x 2871 2877 2872 f r row2871)
    (slots617.inc_z 2872 2873 f r row2872 (Or.inl (by decide)))
    (slots617.zero_x 2873 2876 2874 f r row2873)
    (slots617.pos_x 2873 2876 2874 f r row2873)
    (slots617.inc_y 2874 2875 f r row2874 (Or.inl (by decide)))
    (slots617.jump 2875 2873 f r row2875)
    (slots617.jump 2876 2867 f r row2876)

theorem site2867 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2867:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2877:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2867Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2877Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2877 f r x y z) (slots720.atReg 2880 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2877 3 2880 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2877 2880 2878 f r row2877)
    (slots720.pos_x 2877 2880 2878 f r row2877)
    (slots720.inc_y 2878 2879 f r row2878 (Or.inl (by decide)))
    (slots720.jump 2879 2877 f r row2879)

theorem site2877 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2877:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2880:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2877Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2880Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2880 f r x y z) (slots461.atReg 2884 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2880 4 2884 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2880 2884 2881 f r row2880)
    (slots461.pos_x 2880 2884 2881 f r row2880)
    (slots461.inc_y 2881 2882 f r row2881 (Or.inl (by decide)))
    (slots461.inc_z 2882 2883 f r row2882 (Or.inl (by decide)))
    (slots461.jump 2883 2880 f r row2883)

theorem site2880 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2880:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2884:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2880Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site2884Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2884 f r x y z) (slots640.atReg 2887 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2884 3 2887 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2884 2887 2885 f r row2884)
    (slots640.pos_x 2884 2887 2885 f r row2884)
    (slots640.inc_y 2885 2886 f r row2885 (Or.inl (by decide)))
    (slots640.jump 2886 2884 f r row2886)

theorem site2884 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2884:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2887:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2884Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site2887Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2887 f r x y z) (slots160.atReg 2890 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2887 3 2890 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2887 2890 2888 f r row2887)
    (slots160.pos_x 2887 2890 2888 f r row2887)
    (slots160.inc_y 2888 2889 f r row2888 (Or.inl (by decide)))
    (slots160.jump 2889 2887 f r row2889)

theorem site2887 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2887:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2890:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2887Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2890Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2890 f r x y z) (slots210.atReg 2893 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2890 3 2893 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2890 2893 2891 f r row2890)
    (slots210.pos_x 2890 2893 2891 f r row2890)
    (slots210.inc_y 2891 2892 f r row2891 (Or.inl (by decide)))
    (slots210.jump 2892 2890 f r row2892)

theorem site2890 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2890:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2893:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2890Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2893Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2893 f r x y z) (slots617.atReg 2903 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2893 10 2903 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2893 2897 2894 f r row2893)
    (slots617.pos_y 2893 2897 2894 f r row2893)
    (slots617.inc_z 2894 2895 f r row2894 (Or.inl (by decide)))
    (slots617.inc_x 2895 2896 f r row2895 (Or.inl (by decide)))
    (slots617.jump 2896 2893 f r row2896)
    (slots617.zero_x 2897 2903 2898 f r row2897)
    (slots617.pos_x 2897 2903 2898 f r row2897)
    (slots617.inc_z 2898 2899 f r row2898 (Or.inl (by decide)))
    (slots617.zero_x 2899 2902 2900 f r row2899)
    (slots617.pos_x 2899 2902 2900 f r row2899)
    (slots617.inc_y 2900 2901 f r row2900 (Or.inl (by decide)))
    (slots617.jump 2901 2899 f r row2901)
    (slots617.jump 2902 2893 f r row2902)

theorem site2893 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2893:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2903:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2893Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2903Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2903 f r x y z) (slots720.atReg 2906 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2903 3 2906 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2903 2906 2904 f r row2903)
    (slots720.pos_x 2903 2906 2904 f r row2903)
    (slots720.inc_y 2904 2905 f r row2904 (Or.inl (by decide)))
    (slots720.jump 2905 2903 f r row2905)

theorem site2903 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2903:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2906:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2903Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2906Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2906 f r x y z) (slots561.atReg 2910 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2906 4 2910 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2906 2910 2907 f r row2906)
    (slots561.pos_x 2906 2910 2907 f r row2906)
    (slots561.inc_y 2907 2908 f r row2907 (Or.inl (by decide)))
    (slots561.inc_z 2908 2909 f r row2908 (Or.inl (by decide)))
    (slots561.jump 2909 2906 f r row2909)

theorem site2906 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2906:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2910:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2906Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

end PA192.ModelSearch.RegisterSource.Certified
