module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire2832 : String := include_str ".."/"data"/"FrozenSite2832.wire"
private def indices2832 : String := include_str ".."/"data"/"FrozenSite2832.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision2832 : (checkPayload 2832 48 wire2832 indices2832).isSome=true := by decide +native

theorem scope2832 : Scope 2832 48 := payload_sound _ _ _ _ decision2832
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope2832
