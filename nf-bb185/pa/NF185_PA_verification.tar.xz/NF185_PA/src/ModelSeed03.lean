module
public import ModelSeed02
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter97 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((515:Nat):V) f (vector n (v+y) (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0512 f n (v+y) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w) w
  have d2 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter96 f n t s c u v y d w).trans mid

theorem seedEmitAfter98 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((525:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 (atom19 n t s c u v y d w) w)) := by
  have micro := site0515 f n (v+y) (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (v+y)):V)=atom19 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (v+y)):V)=0+(atom19 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter97 f n t s c u v y d w).trans mid

theorem seedEmitAfter99 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((529:Nat):V) f (vector n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0525 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) 0 (atom19 n t s c u v y d w) w
  have d1 : (0+(2*(atom19 n t s c u v y d w)):V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom19 n t s c u v y d w)):V)=0+((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter98 f n t s c u v y d w).trans mid

theorem seedEmitAfter100 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((530:Nat):V) f (vector n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0529 f n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w))+1:V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter99 f n t s c u v y d w).trans mid

theorem seedEmitAfter101 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((533:Nat):V) f (vector n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0530 f n ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1):V)=(atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter100 f n t s c u v y d w).trans mid

theorem seedEmitAfter102 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((536:Nat):V) f (vector n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0533 f n 0 (atom15 n t s c u v y d w) c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom15 n t s c u v y d w):V)=atom15 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter101 f n t s c u v y d w).trans mid

theorem seedEmitAfter103 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((546:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom20 n t s c u v y d w) w)) := by
  have micro := site0536 f n (atom15 n t s c u v y d w) 0 c (d+u) (v+y) ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w)):V)=atom20 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w)):V)=0+(atom20 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter102 f n t s c u v y d w).trans mid

theorem seedEmitAfter104 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((549:Nat):V) f (vector n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0546 f n 0 0 c (d+u) (v+y) 0 (atom20 n t s c u v y d w) w
  have d2 : (0+(atom20 n t s c u v y d w):V)=atom20 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter103 f n t s c u v y d w).trans mid

theorem seedEmitAfter105 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((550:Nat):V) f (vector n 1 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0549 f n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+1:V)=1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter104 f n t s c u v y d w).trans mid

theorem seedEmitAfter106 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((553:Nat):V) f (vector n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 1 0 w)) := by
  have micro := site0550 f n 1 (atom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+1:V)=1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter105 f n t s c u v y d w).trans mid

theorem seedEmitAfter107 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((556:Nat):V) f (vector n (atom20 n t s c u v y d w) 0 c (d+u) (v+y) 1 0 w)) := by
  have micro := site0553 f n 0 (atom20 n t s c u v y d w) c (d+u) (v+y) 1 0 w
  have d1 : (0+(atom20 n t s c u v y d w):V)=atom20 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter106 f n t s c u v y d w).trans mid

theorem seedEmitAfter108 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((566:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom21 n t s c u v y d w) w)) := by
  have micro := site0556 f n (atom20 n t s c u v y d w) 0 c (d+u) (v+y) 1 0 w
  have d7 : (0+(cantor 1 (atom20 n t s c u v y d w)):V)=atom21 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 1 (atom20 n t s c u v y d w)):V)=0+(atom21 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter107 f n t s c u v y d w).trans mid

theorem seedEmitAfter109 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((569:Nat):V) f (vector n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0566 f n 0 0 c (d+u) (v+y) 0 (atom21 n t s c u v y d w) w
  have d2 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter108 f n t s c u v y d w).trans mid

theorem seedEmitAfter110 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((572:Nat):V) f (vector n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0569 f n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+0:V)=0 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter109 f n t s c u v y d w).trans mid

theorem seedEmitAfter111 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((575:Nat):V) f (vector n (atom21 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w)) := by
  have micro := site0572 f n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter110 f n t s c u v y d w).trans mid

theorem seedEmitAfter112 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((585:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom22 n t s c u v y d w) w)) := by
  have micro := site0575 f n (atom21 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w
  have d7 : (0+(cantor 0 (atom21 n t s c u v y d w)):V)=atom22 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 0 (atom21 n t s c u v y d w)):V)=0+(atom22 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter111 f n t s c u v y d w).trans mid

theorem seedEmitAfter113 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((588:Nat):V) f (vector n 0 (atom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0585 f n 0 0 c (d+u) (v+y) 0 (atom22 n t s c u v y d w) w
  have d2 : (0+(atom22 n t s c u v y d w):V)=atom22 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter112 f n t s c u v y d w).trans mid

theorem seedEmitAfter114 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((592:Nat):V) f (vector n (d+u) (atom22 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0588 f n 0 (atom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter113 f n t s c u v y d w).trans mid

theorem seedEmitAfter115 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((595:Nat):V) f (vector n (d+u) (atom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0592 f n (d+u) (atom22 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter114 f n t s c u v y d w).trans mid

theorem seedEmitAfter116 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((603:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) 0 (atom21 n t s c u v y d w) w)) := by
  have micro := site0595 f n (d+u) (atom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom22 n t s c u v y d w)):V)=0 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom22 n t s c u v y d w):V)=0+(atom22 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom22 n t s c u v y d w)):V)=left (atom22 n t s c u v y d w)).trans (by change left (cantor 0 (atom21 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom22 n t s c u v y d w)):V)=atom21 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom22 n t s c u v y d w):V)=0+(atom22 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom22 n t s c u v y d w)):V)=right (atom22 n t s c u v y d w)).trans (by change right (cantor 0 (atom21 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter115 f n t s c u v y d w).trans mid

theorem seedEmitAfter117 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((606:Nat):V) f (vector n (d+u) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0603 f n (d+u) 0 c (d+u) (v+y) 0 (atom21 n t s c u v y d w) w
  have d2 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter116 f n t s c u v y d w).trans mid

theorem seedEmitAfter118 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((616:Nat):V) f (vector n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 (atom23 n t s c u v y d w) w)) := by
  have micro := site0606 f n (d+u) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d7 : (0+(cantor 0 (d+u)):V)=atom23 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 0 (d+u)):V)=0+(atom23 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter117 f n t s c u v y d w).trans mid

theorem seedEmitAfter119 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((620:Nat):V) f (vector n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0616 f n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) 0 (atom23 n t s c u v y d w) w
  have d1 : (0+(2*(atom23 n t s c u v y d w)):V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom23 n t s c u v y d w)):V)=0+((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter118 f n t s c u v y d w).trans mid

theorem seedEmitAfter120 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((621:Nat):V) f (vector n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0620 f n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w))+1:V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter119 f n t s c u v y d w).trans mid

theorem seedEmitAfter121 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((624:Nat):V) f (vector n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0621 f n ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1):V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter120 f n t s c u v y d w).trans mid

theorem seedEmitAfter122 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((627:Nat):V) f (vector n (atom21 n t s c u v y d w) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0624 f n 0 (atom21 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter121 f n t s c u v y d w).trans mid

theorem seedEmitAfter123 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((637:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom24 n t s c u v y d w) w)) := by
  have micro := site0627 f n (atom21 n t s c u v y d w) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w)):V)=atom24 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w)):V)=0+(atom24 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter122 f n t s c u v y d w).trans mid

theorem seedEmitAfter124 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((640:Nat):V) f (vector n 0 (atom24 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0637 f n 0 0 c (d+u) (v+y) 0 (atom24 n t s c u v y d w) w
  have d2 : (0+(atom24 n t s c u v y d w):V)=atom24 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter123 f n t s c u v y d w).trans mid

theorem seedEmitAfter125 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((644:Nat):V) f (vector n (v+y) (atom24 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0640 f n 0 (atom24 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter124 f n t s c u v y d w).trans mid

theorem seedEmitAfter126 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((647:Nat):V) f (vector n (v+y) (atom24 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0644 f n (v+y) (atom24 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter125 f n t s c u v y d w).trans mid

theorem seedEmitAfter127 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((655:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w) w)) := by
  have micro := site0647 f n (v+y) (atom24 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom24 n t s c u v y d w)):V)=(atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom24 n t s c u v y d w):V)=0+(atom24 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom24 n t s c u v y d w)):V)=left (atom24 n t s c u v y d w)).trans (by change left (cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom24 n t s c u v y d w)):V)=atom21 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom24 n t s c u v y d w):V)=0+(atom24 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom24 n t s c u v y d w)):V)=right (atom24 n t s c u v y d w)).trans (by change right (cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter126 f n t s c u v y d w).trans mid

theorem seedEmitAfter128 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((658:Nat):V) f (vector n (v+y) (atom21 n t s c u v y d w) c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0655 f n (v+y) 0 c (d+u) (v+y) ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w) w
  have d2 : (0+(atom21 n t s c u v y d w):V)=atom21 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter127 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
