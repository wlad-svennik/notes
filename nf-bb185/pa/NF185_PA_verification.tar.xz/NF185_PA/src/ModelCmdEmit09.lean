module
public import ModelCmdEmit08
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter289 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1421:Nat):V) f (vector n 0 (atom48 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site1411 f n (v+y) (atom48 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter288 f n t s c u v y d w).trans mid

theorem commandEmitAfter290 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1425:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1421 f n 0 (atom48 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter289 f n t s c u v y d w).trans mid

theorem commandEmitAfter291 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1426:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1425 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter290 f n t s c u v y d w).trans mid

theorem commandEmitAfter292 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1434:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom46 n t s c u v y d w) w)) := by
  have micro := site1426 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom48 n t s c u v y d w)):V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom48 n t s c u v y d w):V)=0+(atom48 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom48 n t s c u v y d w)):V)=left (atom48 n t s c u v y d w)).trans (by change left (cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom46 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom48 n t s c u v y d w)):V)=atom46 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom48 n t s c u v y d w):V)=0+(atom48 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom48 n t s c u v y d w)):V)=right (atom48 n t s c u v y d w)).trans (by change right (cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom46 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter291 f n t s c u v y d w).trans mid

theorem commandEmitAfter293 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1437:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom46 n t s c u v y d w) c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1434 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom46 n t s c u v y d w) w
  have d2 : (0+(atom46 n t s c u v y d w):V)=atom46 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter292 f n t s c u v y d w).trans mid

theorem commandEmitAfter294 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1447:Nat):V) f (vector n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) 0 (atom50 n t s c u v y d w) w)) := by
  have micro := site1437 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom46 n t s c u v y d w) c (d+u) (v+y) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=atom50 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=0+(atom50 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter293 f n t s c u v y d w).trans mid

theorem commandEmitAfter295 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1451:Nat):V) f (vector n ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)) (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1447 f n 0 (atom46 n t s c u v y d w) c (d+u) (v+y) 0 (atom50 n t s c u v y d w) w
  have d1 : (0+(2*(atom50 n t s c u v y d w)):V)=(atom50 n t s c u v y d w)+(atom50 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom50 n t s c u v y d w)):V)=0+((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter294 f n t s c u v y d w).trans mid

theorem commandEmitAfter296 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1452:Nat):V) f (vector n ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1) (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1451 f n ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)) (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w))+1:V)=(atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter295 f n t s c u v y d w).trans mid

theorem commandEmitAfter297 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1460:Nat):V) f (vector n ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom44 n t s c u v y d w) w)) := by
  have micro := site1452 f n ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1) (atom46 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom46 n t s c u v y d w)):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom46 n t s c u v y d w):V)=0+(atom46 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom46 n t s c u v y d w)):V)=left (atom46 n t s c u v y d w)).trans (by change left (cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom44 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom46 n t s c u v y d w)):V)=atom44 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom46 n t s c u v y d w):V)=0+(atom46 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom46 n t s c u v y d w)):V)=right (atom46 n t s c u v y d w)).trans (by change right (cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom44 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter296 f n t s c u v y d w).trans mid

theorem commandEmitAfter298 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1463:Nat):V) f (vector n ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1) (atom44 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1460 f n ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom44 n t s c u v y d w) w
  have d2 : (0+(atom44 n t s c u v y d w):V)=atom44 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter297 f n t s c u v y d w).trans mid

theorem commandEmitAfter299 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1473:Nat):V) f (vector n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) 0 (atom51 n t s c u v y d w) w)) := by
  have micro := site1463 f n ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1) (atom44 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1)):V)=atom51 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1)):V)=0+(atom51 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter298 f n t s c u v y d w).trans mid

theorem commandEmitAfter300 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1477:Nat):V) f (vector n ((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)) (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1473 f n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) 0 (atom51 n t s c u v y d w) w
  have d1 : (0+(2*(atom51 n t s c u v y d w)):V)=(atom51 n t s c u v y d w)+(atom51 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom51 n t s c u v y d w)):V)=0+((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter299 f n t s c u v y d w).trans mid

theorem commandEmitAfter301 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1480:Nat):V) f (vector n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) ((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)) 0 w)) := by
  have micro := site1477 f n ((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)) (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)):V)=(atom51 n t s c u v y d w)+(atom51 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter300 f n t s c u v y d w).trans mid

theorem commandEmitAfter302 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1483:Nat):V) f (vector n (atom44 n t s c u v y d w) 0 c (d+u) (v+y) ((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)) 0 w)) := by
  have micro := site1480 f n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) ((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)) 0 w
  have d1 : (0+(atom44 n t s c u v y d w):V)=atom44 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter301 f n t s c u v y d w).trans mid

theorem commandEmitAfter303 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1493:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom52 n t s c u v y d w) w)) := by
  have micro := site1483 f n (atom44 n t s c u v y d w) 0 c (d+u) (v+y) ((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)) (atom44 n t s c u v y d w)):V)=atom52 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)) (atom44 n t s c u v y d w)):V)=0+(atom52 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter302 f n t s c u v y d w).trans mid

theorem commandEmitAfter304 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1496:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1493 f n 0 0 c (d+u) (v+y) 0 (atom52 n t s c u v y d w) w
  have d2 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter303 f n t s c u v y d w).trans mid

theorem commandEmitAfter305 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1497:Nat):V) f (vector n 1 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1496 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+1:V)=1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter304 f n t s c u v y d w).trans mid

theorem commandEmitAfter306 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1498:Nat):V) f (vector n 2 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1497 f n 1 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (1+1:V)=2 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter305 f n t s c u v y d w).trans mid

theorem commandEmitAfter307 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1499:Nat):V) f (vector n 3 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1498 f n 2 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (2+1:V)=3 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter306 f n t s c u v y d w).trans mid

theorem commandEmitAfter308 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1502:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 3 0 w)) := by
  have micro := site1499 f n 3 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+3:V)=3 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter307 f n t s c u v y d w).trans mid

theorem commandEmitAfter309 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1505:Nat):V) f (vector n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) 3 0 w)) := by
  have micro := site1502 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 3 0 w
  have d1 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter308 f n t s c u v y d w).trans mid

theorem commandEmitAfter310 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1515:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom53 n t s c u v y d w) w)) := by
  have micro := site1505 f n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) 3 0 w
  have d7 : (0+(cantor 3 (atom52 n t s c u v y d w)):V)=atom53 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 3 (atom52 n t s c u v y d w)):V)=0+(atom53 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter309 f n t s c u v y d w).trans mid

theorem commandEmitAfter311 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1518:Nat):V) f (vector n 0 (atom53 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1515 f n 0 0 c (d+u) (v+y) 0 (atom53 n t s c u v y d w) w
  have d2 : (0+(atom53 n t s c u v y d w):V)=atom53 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter310 f n t s c u v y d w).trans mid

theorem commandEmitAfter312 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1522:Nat):V) f (vector n c (atom53 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site1518 f n 0 (atom53 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+c:V)=c := by ring
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter311 f n t s c u v y d w).trans mid

theorem commandEmitAfter313 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1525:Nat):V) f (vector n c (atom53 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1522 f n c (atom53 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter312 f n t s c u v y d w).trans mid

theorem commandEmitAfter314 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1533:Nat):V) f (vector n c 0 c (d+u) (v+y) 3 (atom52 n t s c u v y d w) w)) := by
  have micro := site1525 f n c (atom53 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom53 n t s c u v y d w)):V)=3 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom53 n t s c u v y d w):V)=0+(atom53 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom53 n t s c u v y d w)):V)=left (atom53 n t s c u v y d w)).trans (by change left (cantor 3 (atom52 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom53 n t s c u v y d w)):V)=atom52 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom53 n t s c u v y d w):V)=0+(atom53 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom53 n t s c u v y d w)):V)=right (atom53 n t s c u v y d w)).trans (by change right (cantor 3 (atom52 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter313 f n t s c u v y d w).trans mid

theorem commandEmitAfter315 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1536:Nat):V) f (vector n c (atom52 n t s c u v y d w) c (d+u) (v+y) 3 0 w)) := by
  have micro := site1533 f n c 0 c (d+u) (v+y) 3 (atom52 n t s c u v y d w) w
  have d2 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter314 f n t s c u v y d w).trans mid

theorem commandEmitAfter316 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1546:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 (atom54 n t s c u v y d w) w)) := by
  have micro := site1536 f n c (atom52 n t s c u v y d w) c (d+u) (v+y) 3 0 w
  have d7 : (0+(cantor 3 c):V)=atom54 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor 3 c):V)=0+(atom54 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter315 f n t s c u v y d w).trans mid

theorem commandEmitAfter317 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1550:Nat):V) f (vector n ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1546 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) 0 (atom54 n t s c u v y d w) w
  have d1 : (0+(2*(atom54 n t s c u v y d w)):V)=(atom54 n t s c u v y d w)+(atom54 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom54 n t s c u v y d w)):V)=0+((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter316 f n t s c u v y d w).trans mid

theorem commandEmitAfter318 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1551:Nat):V) f (vector n ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1550 f n ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w))+1:V)=(atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter317 f n t s c u v y d w).trans mid

theorem commandEmitAfter319 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1554:Nat):V) f (vector n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1551 f n ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (atom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1):V)=(atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter318 f n t s c u v y d w).trans mid

theorem commandEmitAfter320 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1557:Nat):V) f (vector n (atom52 n t s c u v y d w) 0 c (d+u) (v+y) ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1554 f n 0 (atom52 n t s c u v y d w) c (d+u) (v+y) ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom52 n t s c u v y d w):V)=atom52 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter319 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
