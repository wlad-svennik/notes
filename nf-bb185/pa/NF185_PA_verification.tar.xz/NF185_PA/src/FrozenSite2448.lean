module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire2448 : String := include_str ".."/"data"/"FrozenSite2448.wire"
private def indices2448 : String := include_str ".."/"data"/"FrozenSite2448.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision2448 : (checkPayload 2448 48 wire2448 indices2448).isSome=true := by decide +native

theorem scope2448 : Scope 2448 48 := payload_sound _ _ _ _ decision2448
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope2448
