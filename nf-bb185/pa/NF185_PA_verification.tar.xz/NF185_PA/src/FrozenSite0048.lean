module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire0048 : String := include_str ".."/"data"/"FrozenSite0048.wire"
private def indices0048 : String := include_str ".."/"data"/"FrozenSite0048.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision0048 : (checkPayload 48 48 wire0048 indices0048).isSome=true := by decide +native

theorem scope0048 : Scope 48 48 := payload_sound _ _ _ _ decision0048
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope0048
