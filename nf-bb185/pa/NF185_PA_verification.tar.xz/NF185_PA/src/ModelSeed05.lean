module
public import ModelSeed04
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter161 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((821:Nat):V) f (vector n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0818 f n 0 0 c (d+u) (v+y) 0 (atom31 n t s c u v y d w) w
  have d2 : (0+(atom31 n t s c u v y d w):V)=atom31 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter160 f n t s c u v y d w).trans mid

theorem seedEmitAfter162 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((825:Nat):V) f (vector n (d+u) (atom31 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0821 f n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter161 f n t s c u v y d w).trans mid

theorem seedEmitAfter163 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((828:Nat):V) f (vector n (d+u) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0825 f n (d+u) (atom31 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter162 f n t s c u v y d w).trans mid

theorem seedEmitAfter164 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((831:Nat):V) f (vector n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0828 f n (d+u) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter163 f n t s c u v y d w).trans mid

theorem seedEmitAfter165 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((834:Nat):V) f (vector n (atom31 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0831 f n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom31 n t s c u v y d w):V)=atom31 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter164 f n t s c u v y d w).trans mid

theorem seedEmitAfter166 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((844:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom32 n t s c u v y d w) w)) := by
  have micro := site0834 f n (atom31 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom31 n t s c u v y d w)):V)=atom32 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom31 n t s c u v y d w)):V)=0+(atom32 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter165 f n t s c u v y d w).trans mid

theorem seedEmitAfter167 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((847:Nat):V) f (vector n 0 (atom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0844 f n 0 0 c (d+u) (v+y) 0 (atom32 n t s c u v y d w) w
  have d2 : (0+(atom32 n t s c u v y d w):V)=atom32 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter166 f n t s c u v y d w).trans mid

theorem seedEmitAfter168 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((851:Nat):V) f (vector n c (atom32 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site0847 f n 0 (atom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+c:V)=c := by ring
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter167 f n t s c u v y d w).trans mid

theorem seedEmitAfter169 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((854:Nat):V) f (vector n c (atom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0851 f n c (atom32 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (seedEmitAfter168 f n t s c u v y d w).trans mid

theorem seedEmitAfter170 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((862:Nat):V) f (vector n c 0 c (d+u) (v+y) (d+u) (atom31 n t s c u v y d w) w)) := by
  have micro := site0854 f n c (atom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom32 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom32 n t s c u v y d w):V)=0+(atom32 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom32 n t s c u v y d w)):V)=left (atom32 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom31 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom32 n t s c u v y d w)):V)=atom31 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom32 n t s c u v y d w):V)=0+(atom32 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom32 n t s c u v y d w)):V)=right (atom32 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom31 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter169 f n t s c u v y d w).trans mid

theorem seedEmitAfter171 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((865:Nat):V) f (vector n c (atom31 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0862 f n c 0 c (d+u) (v+y) (d+u) (atom31 n t s c u v y d w) w
  have d2 : (0+(atom31 n t s c u v y d w):V)=atom31 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter170 f n t s c u v y d w).trans mid

theorem seedEmitAfter172 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((875:Nat):V) f (vector n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) 0 (atom9 n t s c u v y d w) w)) := by
  have micro := site0865 f n c (atom31 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) c):V)=atom9 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) c):V)=0+(atom9 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter171 f n t s c u v y d w).trans mid

theorem seedEmitAfter173 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((879:Nat):V) f (vector n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0875 f n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) 0 (atom9 n t s c u v y d w) w
  have d1 : (0+(2*(atom9 n t s c u v y d w)):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom9 n t s c u v y d w)):V)=0+((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter172 f n t s c u v y d w).trans mid

theorem seedEmitAfter174 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((880:Nat):V) f (vector n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0879 f n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w))+1:V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter173 f n t s c u v y d w).trans mid

theorem seedEmitAfter175 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((883:Nat):V) f (vector n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0880 f n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom31 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter174 f n t s c u v y d w).trans mid

theorem seedEmitAfter176 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((886:Nat):V) f (vector n (atom31 n t s c u v y d w) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0883 f n 0 (atom31 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom31 n t s c u v y d w):V)=atom31 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter175 f n t s c u v y d w).trans mid

theorem seedEmitAfter177 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((896:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom33 n t s c u v y d w) w)) := by
  have micro := site0886 f n (atom31 n t s c u v y d w) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom31 n t s c u v y d w)):V)=atom33 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom31 n t s c u v y d w)):V)=0+(atom33 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter176 f n t s c u v y d w).trans mid

theorem seedEmitAfter178 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((899:Nat):V) f (vector n 0 (atom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0896 f n 0 0 c (d+u) (v+y) 0 (atom33 n t s c u v y d w) w
  have d2 : (0+(atom33 n t s c u v y d w):V)=atom33 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter177 f n t s c u v y d w).trans mid

theorem seedEmitAfter179 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((903:Nat):V) f (vector n (d+u) (atom33 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0899 f n 0 (atom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter178 f n t s c u v y d w).trans mid

theorem seedEmitAfter180 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((906:Nat):V) f (vector n (d+u) (atom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0903 f n (d+u) (atom33 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter179 f n t s c u v y d w).trans mid

theorem seedEmitAfter181 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((909:Nat):V) f (vector n 0 (atom33 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0906 f n (d+u) (atom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter180 f n t s c u v y d w).trans mid

theorem seedEmitAfter182 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((912:Nat):V) f (vector n (atom33 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0909 f n 0 (atom33 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom33 n t s c u v y d w):V)=atom33 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter181 f n t s c u v y d w).trans mid

theorem seedEmitAfter183 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((922:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom34 n t s c u v y d w) w)) := by
  have micro := site0912 f n (atom33 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom33 n t s c u v y d w)):V)=atom34 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom33 n t s c u v y d w)):V)=0+(atom34 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter182 f n t s c u v y d w).trans mid

theorem seedEmitAfter184 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((925:Nat):V) f (vector n 0 (atom34 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0922 f n 0 0 c (d+u) (v+y) 0 (atom34 n t s c u v y d w) w
  have d2 : (0+(atom34 n t s c u v y d w):V)=atom34 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter183 f n t s c u v y d w).trans mid

theorem seedEmitAfter185 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((929:Nat):V) f (vector n (v+y) (atom34 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0925 f n 0 (atom34 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter184 f n t s c u v y d w).trans mid

theorem seedEmitAfter186 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((932:Nat):V) f (vector n (v+y) (atom34 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0929 f n (v+y) (atom34 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter185 f n t s c u v y d w).trans mid

theorem seedEmitAfter187 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((940:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom33 n t s c u v y d w) w)) := by
  have micro := site0932 f n (v+y) (atom34 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom34 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom34 n t s c u v y d w):V)=0+(atom34 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom34 n t s c u v y d w)):V)=left (atom34 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom33 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom34 n t s c u v y d w)):V)=atom33 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom34 n t s c u v y d w):V)=0+(atom34 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom34 n t s c u v y d w)):V)=right (atom34 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom33 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter186 f n t s c u v y d w).trans mid

theorem seedEmitAfter188 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((943:Nat):V) f (vector n (v+y) (atom33 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0940 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom33 n t s c u v y d w) w
  have d2 : (0+(atom33 n t s c u v y d w):V)=atom33 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter187 f n t s c u v y d w).trans mid

theorem seedEmitAfter189 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((953:Nat):V) f (vector n 0 (atom33 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site0943 f n (v+y) (atom33 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter188 f n t s c u v y d w).trans mid

theorem seedEmitAfter190 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((957:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0953 f n 0 (atom33 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter189 f n t s c u v y d w).trans mid

theorem seedEmitAfter191 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((958:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0957 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter190 f n t s c u v y d w).trans mid

theorem seedEmitAfter192 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((966:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom31 n t s c u v y d w) w)) := by
  have micro := site0958 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom33 n t s c u v y d w)):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom33 n t s c u v y d w):V)=0+(atom33 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom33 n t s c u v y d w)):V)=left (atom33 n t s c u v y d w)).trans (by change left (cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom31 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom33 n t s c u v y d w)):V)=atom31 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom33 n t s c u v y d w):V)=0+(atom33 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom33 n t s c u v y d w)):V)=right (atom33 n t s c u v y d w)).trans (by change right (cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom31 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter191 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
