module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site1754Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1754 f r x y z) (slots710.atReg 1758 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1754 4 1758 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1754 1758 1755 f r row1754)
    (slots710.pos_x 1754 1758 1755 f r row1754)
    (slots710.inc_y 1755 1756 f r row1755 (Or.inl (by decide)))
    (slots710.inc_y 1756 1757 f r row1756 (Or.inl (by decide)))
    (slots710.jump 1757 1754 f r row1757)

theorem site1754 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1754:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1758:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1754Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1758 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1758:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1759:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1758 _ row1758]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site1759 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1759:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1760:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1759 _ row1759]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1760Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1760 f r x y z) (slots267.atReg 1768 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1760 8 1768 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1760 1768 1761 f r row1760)
    (slots267.pos_x 1760 1768 1761 f r row1760)
    (slots267.inc_z 1761 1762 f r row1761 (Or.inl (by decide)))
    (slots267.zero_y 1762 1764 1763 f r row1762)
    (slots267.pos_y 1762 1764 1763 f r row1762)
    (slots267.jump 1763 1767 f r row1763)
    (slots267.zero_z 1764 1767 1765 f r row1764)
    (slots267.pos_z 1764 1767 1765 f r row1764)
    (slots267.inc_y 1765 1766 f r row1765 (Or.inl (by decide)))
    (slots267.jump 1766 1764 f r row1766)
    (slots267.jump 1767 1760 f r row1767)

theorem site1760 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1760:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1768:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1760Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1768Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1768 f r x y z) (slots720.atReg 1771 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1768 3 1771 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1768 1771 1769 f r row1768)
    (slots720.pos_x 1768 1771 1769 f r row1768)
    (slots720.inc_y 1769 1770 f r row1769 (Or.inl (by decide)))
    (slots720.jump 1770 1768 f r row1770)

theorem site1768 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1768:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1771:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1768Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1771Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1771 f r x y z) (slots617.atReg 1781 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1771 10 1781 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1771 1775 1772 f r row1771)
    (slots617.pos_y 1771 1775 1772 f r row1771)
    (slots617.inc_z 1772 1773 f r row1772 (Or.inl (by decide)))
    (slots617.inc_x 1773 1774 f r row1773 (Or.inl (by decide)))
    (slots617.jump 1774 1771 f r row1774)
    (slots617.zero_x 1775 1781 1776 f r row1775)
    (slots617.pos_x 1775 1781 1776 f r row1775)
    (slots617.inc_z 1776 1777 f r row1776 (Or.inl (by decide)))
    (slots617.zero_x 1777 1780 1778 f r row1777)
    (slots617.pos_x 1777 1780 1778 f r row1777)
    (slots617.inc_y 1778 1779 f r row1778 (Or.inl (by decide)))
    (slots617.jump 1779 1777 f r row1779)
    (slots617.jump 1780 1771 f r row1780)

theorem site1771 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1771:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1781:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1771Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1781Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1781 f r x y z) (slots710.atReg 1785 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1781 4 1785 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1781 1785 1782 f r row1781)
    (slots710.pos_x 1781 1785 1782 f r row1781)
    (slots710.inc_y 1782 1783 f r row1782 (Or.inl (by decide)))
    (slots710.inc_y 1783 1784 f r row1783 (Or.inl (by decide)))
    (slots710.jump 1784 1781 f r row1784)

theorem site1781 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1781:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1785:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1781Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1785 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1785:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1786:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1785 _ row1785]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1786Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1786 f r x y z) (slots160.atReg 1789 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1786 3 1789 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1786 1789 1787 f r row1786)
    (slots160.pos_x 1786 1789 1787 f r row1786)
    (slots160.inc_y 1787 1788 f r row1787 (Or.inl (by decide)))
    (slots160.jump 1788 1786 f r row1788)

theorem site1786 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1786:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1789:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1786Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1789Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1789 f r x y z) (slots210.atReg 1792 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1789 3 1792 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1789 1792 1790 f r row1789)
    (slots210.pos_x 1789 1792 1790 f r row1789)
    (slots210.inc_y 1790 1791 f r row1790 (Or.inl (by decide)))
    (slots210.jump 1791 1789 f r row1791)

theorem site1789 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1789:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1792:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1789Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1792Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1792 f r x y z) (slots617.atReg 1802 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1792 10 1802 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1792 1796 1793 f r row1792)
    (slots617.pos_y 1792 1796 1793 f r row1792)
    (slots617.inc_z 1793 1794 f r row1793 (Or.inl (by decide)))
    (slots617.inc_x 1794 1795 f r row1794 (Or.inl (by decide)))
    (slots617.jump 1795 1792 f r row1795)
    (slots617.zero_x 1796 1802 1797 f r row1796)
    (slots617.pos_x 1796 1802 1797 f r row1796)
    (slots617.inc_z 1797 1798 f r row1797 (Or.inl (by decide)))
    (slots617.zero_x 1798 1801 1799 f r row1798)
    (slots617.pos_x 1798 1801 1799 f r row1798)
    (slots617.inc_y 1799 1800 f r row1799 (Or.inl (by decide)))
    (slots617.jump 1800 1798 f r row1800)
    (slots617.jump 1801 1792 f r row1801)

theorem site1792 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1792:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1802:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1792Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1802Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1802 f r x y z) (slots720.atReg 1805 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1802 3 1805 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1802 1805 1803 f r row1802)
    (slots720.pos_x 1802 1805 1803 f r row1802)
    (slots720.inc_y 1803 1804 f r row1803 (Or.inl (by decide)))
    (slots720.jump 1804 1802 f r row1804)

theorem site1802 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1802:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1805:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1802Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1805Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1805 f r x y z) (slots461.atReg 1809 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1805 4 1809 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1805 1809 1806 f r row1805)
    (slots461.pos_x 1805 1809 1806 f r row1805)
    (slots461.inc_y 1806 1807 f r row1806 (Or.inl (by decide)))
    (slots461.inc_z 1807 1808 f r row1807 (Or.inl (by decide)))
    (slots461.jump 1808 1805 f r row1808)

theorem site1805 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1805:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1809:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1805Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site1809Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1809 f r x y z) (slots640.atReg 1812 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1809 3 1812 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1809 1812 1810 f r row1809)
    (slots640.pos_x 1809 1812 1810 f r row1809)
    (slots640.inc_y 1810 1811 f r row1810 (Or.inl (by decide)))
    (slots640.jump 1811 1809 f r row1811)

theorem site1809 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1809:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1812:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1809Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site1812Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1812 f r x y z) (slots160.atReg 1815 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1812 3 1815 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1812 1815 1813 f r row1812)
    (slots160.pos_x 1812 1815 1813 f r row1812)
    (slots160.inc_y 1813 1814 f r row1813 (Or.inl (by decide)))
    (slots160.jump 1814 1812 f r row1814)

theorem site1812 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1812:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1815:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1812Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1815Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1815 f r x y z) (slots210.atReg 1818 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1815 3 1818 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1815 1818 1816 f r row1815)
    (slots210.pos_x 1815 1818 1816 f r row1815)
    (slots210.inc_y 1816 1817 f r row1816 (Or.inl (by decide)))
    (slots210.jump 1817 1815 f r row1817)

theorem site1815 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1815:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1818:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1815Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1818Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1818 f r x y z) (slots617.atReg 1828 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1818 10 1828 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1818 1822 1819 f r row1818)
    (slots617.pos_y 1818 1822 1819 f r row1818)
    (slots617.inc_z 1819 1820 f r row1819 (Or.inl (by decide)))
    (slots617.inc_x 1820 1821 f r row1820 (Or.inl (by decide)))
    (slots617.jump 1821 1818 f r row1821)
    (slots617.zero_x 1822 1828 1823 f r row1822)
    (slots617.pos_x 1822 1828 1823 f r row1822)
    (slots617.inc_z 1823 1824 f r row1823 (Or.inl (by decide)))
    (slots617.zero_x 1824 1827 1825 f r row1824)
    (slots617.pos_x 1824 1827 1825 f r row1824)
    (slots617.inc_y 1825 1826 f r row1825 (Or.inl (by decide)))
    (slots617.jump 1826 1824 f r row1826)
    (slots617.jump 1827 1818 f r row1827)

theorem site1818 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1818:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1828:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1818Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1828Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1828 f r x y z) (slots720.atReg 1831 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1828 3 1831 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1828 1831 1829 f r row1828)
    (slots720.pos_x 1828 1831 1829 f r row1828)
    (slots720.inc_y 1829 1830 f r row1829 (Or.inl (by decide)))
    (slots720.jump 1830 1828 f r row1830)

theorem site1828 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1828:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1831:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1828Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1831Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1831 f r x y z) (slots561.atReg 1835 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1831 4 1835 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1831 1835 1832 f r row1831)
    (slots561.pos_x 1831 1835 1832 f r row1831)
    (slots561.inc_y 1832 1833 f r row1832 (Or.inl (by decide)))
    (slots561.inc_z 1833 1834 f r row1833 (Or.inl (by decide)))
    (slots561.jump 1834 1831 f r row1834)

theorem site1831 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1831:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1835:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1831Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site1835Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1835 f r x y z) (slots650.atReg 1838 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1835 3 1838 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1835 1838 1836 f r row1835)
    (slots650.pos_x 1835 1838 1836 f r row1835)
    (slots650.inc_y 1836 1837 f r row1836 (Or.inl (by decide)))
    (slots650.jump 1837 1835 f r row1837)

theorem site1835 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1835:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1838:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1835Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site1838Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1838 f r x y z) (slots267.atReg 1846 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1838 8 1846 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1838 1846 1839 f r row1838)
    (slots267.pos_x 1838 1846 1839 f r row1838)
    (slots267.inc_z 1839 1840 f r row1839 (Or.inl (by decide)))
    (slots267.zero_y 1840 1842 1841 f r row1840)
    (slots267.pos_y 1840 1842 1841 f r row1840)
    (slots267.jump 1841 1845 f r row1841)
    (slots267.zero_z 1842 1845 1843 f r row1842)
    (slots267.pos_z 1842 1845 1843 f r row1842)
    (slots267.inc_y 1843 1844 f r row1843 (Or.inl (by decide)))
    (slots267.jump 1844 1842 f r row1844)
    (slots267.jump 1845 1838 f r row1845)

theorem site1838 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1838:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1846:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1838Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1846Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1846 f r x y z) (slots720.atReg 1849 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1846 3 1849 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1846 1849 1847 f r row1846)
    (slots720.pos_x 1846 1849 1847 f r row1846)
    (slots720.inc_y 1847 1848 f r row1847 (Or.inl (by decide)))
    (slots720.jump 1848 1846 f r row1848)

theorem site1846 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1846:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1849:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1846Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1849Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1849 f r x y z) (slots617.atReg 1859 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1849 10 1859 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1849 1853 1850 f r row1849)
    (slots617.pos_y 1849 1853 1850 f r row1849)
    (slots617.inc_z 1850 1851 f r row1850 (Or.inl (by decide)))
    (slots617.inc_x 1851 1852 f r row1851 (Or.inl (by decide)))
    (slots617.jump 1852 1849 f r row1852)
    (slots617.zero_x 1853 1859 1854 f r row1853)
    (slots617.pos_x 1853 1859 1854 f r row1853)
    (slots617.inc_z 1854 1855 f r row1854 (Or.inl (by decide)))
    (slots617.zero_x 1855 1858 1856 f r row1855)
    (slots617.pos_x 1855 1858 1856 f r row1855)
    (slots617.inc_y 1856 1857 f r row1856 (Or.inl (by decide)))
    (slots617.jump 1857 1855 f r row1857)
    (slots617.jump 1858 1849 f r row1858)

theorem site1849 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1849:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1859:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1849Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1859Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1859 f r x y z) (slots710.atReg 1863 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1859 4 1863 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1859 1863 1860 f r row1859)
    (slots710.pos_x 1859 1863 1860 f r row1859)
    (slots710.inc_y 1860 1861 f r row1860 (Or.inl (by decide)))
    (slots710.inc_y 1861 1862 f r row1861 (Or.inl (by decide)))
    (slots710.jump 1862 1859 f r row1862)

theorem site1859 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1859:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1863:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1859Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1863 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1863:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1864:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1863 _ row1863]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1864Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1864 f r x y z) (slots267.atReg 1872 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1864 8 1872 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1864 1872 1865 f r row1864)
    (slots267.pos_x 1864 1872 1865 f r row1864)
    (slots267.inc_z 1865 1866 f r row1865 (Or.inl (by decide)))
    (slots267.zero_y 1866 1868 1867 f r row1866)
    (slots267.pos_y 1866 1868 1867 f r row1866)
    (slots267.jump 1867 1871 f r row1867)
    (slots267.zero_z 1868 1871 1869 f r row1868)
    (slots267.pos_z 1868 1871 1869 f r row1868)
    (slots267.inc_y 1869 1870 f r row1869 (Or.inl (by decide)))
    (slots267.jump 1870 1868 f r row1870)
    (slots267.jump 1871 1864 f r row1871)

theorem site1864 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1864:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1872:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1864Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1872Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1872 f r x y z) (slots720.atReg 1875 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1872 3 1875 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1872 1875 1873 f r row1872)
    (slots720.pos_x 1872 1875 1873 f r row1872)
    (slots720.inc_y 1873 1874 f r row1873 (Or.inl (by decide)))
    (slots720.jump 1874 1872 f r row1874)

theorem site1872 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1872:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1875:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1872Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1875Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1875 f r x y z) (slots617.atReg 1885 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1875 10 1885 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1875 1879 1876 f r row1875)
    (slots617.pos_y 1875 1879 1876 f r row1875)
    (slots617.inc_z 1876 1877 f r row1876 (Or.inl (by decide)))
    (slots617.inc_x 1877 1878 f r row1877 (Or.inl (by decide)))
    (slots617.jump 1878 1875 f r row1878)
    (slots617.zero_x 1879 1885 1880 f r row1879)
    (slots617.pos_x 1879 1885 1880 f r row1879)
    (slots617.inc_z 1880 1881 f r row1880 (Or.inl (by decide)))
    (slots617.zero_x 1881 1884 1882 f r row1881)
    (slots617.pos_x 1881 1884 1882 f r row1881)
    (slots617.inc_y 1882 1883 f r row1882 (Or.inl (by decide)))
    (slots617.jump 1883 1881 f r row1883)
    (slots617.jump 1884 1875 f r row1884)

theorem site1875 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1875:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1885:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1875Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1885Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1885 f r x y z) (slots710.atReg 1889 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1885 4 1889 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1885 1889 1886 f r row1885)
    (slots710.pos_x 1885 1889 1886 f r row1885)
    (slots710.inc_y 1886 1887 f r row1886 (Or.inl (by decide)))
    (slots710.inc_y 1887 1888 f r row1887 (Or.inl (by decide)))
    (slots710.jump 1888 1885 f r row1888)

theorem site1885 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1885:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1889:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1885Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1889 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1889:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1890:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1889 _ row1889]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1890Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1890 f r x y z) (slots267.atReg 1898 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1890 8 1898 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1890 1898 1891 f r row1890)
    (slots267.pos_x 1890 1898 1891 f r row1890)
    (slots267.inc_z 1891 1892 f r row1891 (Or.inl (by decide)))
    (slots267.zero_y 1892 1894 1893 f r row1892)
    (slots267.pos_y 1892 1894 1893 f r row1892)
    (slots267.jump 1893 1897 f r row1893)
    (slots267.zero_z 1894 1897 1895 f r row1894)
    (slots267.pos_z 1894 1897 1895 f r row1894)
    (slots267.inc_y 1895 1896 f r row1895 (Or.inl (by decide)))
    (slots267.jump 1896 1894 f r row1896)
    (slots267.jump 1897 1890 f r row1897)

theorem site1890 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1890:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1898:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1890Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site1898Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1898 f r x y z) (slots720.atReg 1901 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1898 3 1901 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1898 1901 1899 f r row1898)
    (slots720.pos_x 1898 1901 1899 f r row1898)
    (slots720.inc_y 1899 1900 f r row1899 (Or.inl (by decide)))
    (slots720.jump 1900 1898 f r row1900)

theorem site1898 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1898:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1901:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1898Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1901Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1901 f r x y z) (slots617.atReg 1911 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1901 10 1911 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1901 1905 1902 f r row1901)
    (slots617.pos_y 1901 1905 1902 f r row1901)
    (slots617.inc_z 1902 1903 f r row1902 (Or.inl (by decide)))
    (slots617.inc_x 1903 1904 f r row1903 (Or.inl (by decide)))
    (slots617.jump 1904 1901 f r row1904)
    (slots617.zero_x 1905 1911 1906 f r row1905)
    (slots617.pos_x 1905 1911 1906 f r row1905)
    (slots617.inc_z 1906 1907 f r row1906 (Or.inl (by decide)))
    (slots617.zero_x 1907 1910 1908 f r row1907)
    (slots617.pos_x 1907 1910 1908 f r row1907)
    (slots617.inc_y 1908 1909 f r row1908 (Or.inl (by decide)))
    (slots617.jump 1909 1907 f r row1909)
    (slots617.jump 1910 1901 f r row1910)

theorem site1901 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1901:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1911:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1901Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1911Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1911 f r x y z) (slots710.atReg 1915 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1911 4 1915 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1911 1915 1912 f r row1911)
    (slots710.pos_x 1911 1915 1912 f r row1911)
    (slots710.inc_y 1912 1913 f r row1912 (Or.inl (by decide)))
    (slots710.inc_y 1913 1914 f r row1913 (Or.inl (by decide)))
    (slots710.jump 1914 1911 f r row1914)

theorem site1911 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1911:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1915:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1911Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site1915 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1915:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1916:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1915 _ row1915]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site1916Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1916 f r x y z) (slots160.atReg 1919 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1916 3 1919 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1916 1919 1917 f r row1916)
    (slots160.pos_x 1916 1919 1917 f r row1916)
    (slots160.inc_y 1917 1918 f r row1917 (Or.inl (by decide)))
    (slots160.jump 1918 1916 f r row1918)

theorem site1916 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1916:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1919:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1916Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site1919Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1919 f r x y z) (slots210.atReg 1922 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1919 3 1922 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1919 1922 1920 f r row1919)
    (slots210.pos_x 1919 1922 1920 f r row1919)
    (slots210.inc_y 1920 1921 f r row1920 (Or.inl (by decide)))
    (slots210.jump 1921 1919 f r row1921)

theorem site1919 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1919:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1922:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1919Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site1922Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1922 f r x y z) (slots617.atReg 1932 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1922 10 1932 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1922 1926 1923 f r row1922)
    (slots617.pos_y 1922 1926 1923 f r row1922)
    (slots617.inc_z 1923 1924 f r row1923 (Or.inl (by decide)))
    (slots617.inc_x 1924 1925 f r row1924 (Or.inl (by decide)))
    (slots617.jump 1925 1922 f r row1925)
    (slots617.zero_x 1926 1932 1927 f r row1926)
    (slots617.pos_x 1926 1932 1927 f r row1926)
    (slots617.inc_z 1927 1928 f r row1927 (Or.inl (by decide)))
    (slots617.zero_x 1928 1931 1929 f r row1928)
    (slots617.pos_x 1928 1931 1929 f r row1928)
    (slots617.inc_y 1929 1930 f r row1929 (Or.inl (by decide)))
    (slots617.jump 1930 1928 f r row1930)
    (slots617.jump 1931 1922 f r row1931)

theorem site1922 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1922:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1932:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1922Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site1932Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1932 f r x y z) (slots720.atReg 1935 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1932 3 1935 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1932 1935 1933 f r row1932)
    (slots720.pos_x 1932 1935 1933 f r row1932)
    (slots720.inc_y 1933 1934 f r row1933 (Or.inl (by decide)))
    (slots720.jump 1934 1932 f r row1934)

theorem site1932 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1932:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1935:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1932Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site1935Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1935 f r x y z) (slots461.atReg 1939 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1935 4 1939 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1935 1939 1936 f r row1935)
    (slots461.pos_x 1935 1939 1936 f r row1935)
    (slots461.inc_y 1936 1937 f r row1936 (Or.inl (by decide)))
    (slots461.inc_z 1937 1938 f r row1937 (Or.inl (by decide)))
    (slots461.jump 1938 1935 f r row1938)

theorem site1935 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1935:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1939:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1935Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site1939Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1939 f r x y z) (slots640.atReg 1942 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1939 3 1942 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1939 1942 1940 f r row1939)
    (slots640.pos_x 1939 1942 1940 f r row1939)
    (slots640.inc_y 1940 1941 f r row1940 (Or.inl (by decide)))
    (slots640.jump 1941 1939 f r row1941)

theorem site1939 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1939:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1942:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1939Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

end PA192.ModelSearch.RegisterSource.Certified
