module
public import ModelSeed18
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter609 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2906:Nat):V) f (vector n 0 (atom96 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2903 f n 0 0 c (d+u) (v+y) 0 (atom96 n t s c u v y d w) w
  have d2 : (0+(atom96 n t s c u v y d w):V)=atom96 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter608 f n t s c u v y d w).trans mid

theorem seedEmitAfter610 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2910:Nat):V) f (vector n (v+y) (atom96 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2906 f n 0 (atom96 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter609 f n t s c u v y d w).trans mid

theorem seedEmitAfter611 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2913:Nat):V) f (vector n (v+y) (atom96 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2910 f n (v+y) (atom96 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter610 f n t s c u v y d w).trans mid

theorem seedEmitAfter612 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2921:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom95 n t s c u v y d w) w)) := by
  have micro := site2913 f n (v+y) (atom96 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom96 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom96 n t s c u v y d w):V)=0+(atom96 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom96 n t s c u v y d w)):V)=left (atom96 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom95 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom96 n t s c u v y d w)):V)=atom95 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom96 n t s c u v y d w):V)=0+(atom96 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom96 n t s c u v y d w)):V)=right (atom96 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom95 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter611 f n t s c u v y d w).trans mid

theorem seedEmitAfter613 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2924:Nat):V) f (vector n (v+y) (atom95 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2921 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom95 n t s c u v y d w) w
  have d2 : (0+(atom95 n t s c u v y d w):V)=atom95 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter612 f n t s c u v y d w).trans mid

theorem seedEmitAfter614 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2934:Nat):V) f (vector n 0 (atom95 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site2924 f n (v+y) (atom95 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter613 f n t s c u v y d w).trans mid

theorem seedEmitAfter615 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2938:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2934 f n 0 (atom95 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter614 f n t s c u v y d w).trans mid

theorem seedEmitAfter616 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2939:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2938 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter615 f n t s c u v y d w).trans mid

theorem seedEmitAfter617 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2947:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w) w)) := by
  have micro := site2939 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom95 n t s c u v y d w)):V)=(atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom95 n t s c u v y d w):V)=0+(atom95 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom95 n t s c u v y d w)):V)=left (atom95 n t s c u v y d w)).trans (by change left (cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom95 n t s c u v y d w)):V)=atom86 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom95 n t s c u v y d w):V)=0+(atom95 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom95 n t s c u v y d w)):V)=right (atom95 n t s c u v y d w)).trans (by change right (cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter616 f n t s c u v y d w).trans mid

theorem seedEmitAfter618 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2950:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2947 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w) w
  have d2 : (0+(atom86 n t s c u v y d w):V)=atom86 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter617 f n t s c u v y d w).trans mid

theorem seedEmitAfter619 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2960:Nat):V) f (vector n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 (atom97 n t s c u v y d w) w)) := by
  have micro := site2950 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=atom97 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=0+(atom97 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter618 f n t s c u v y d w).trans mid

theorem seedEmitAfter620 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2964:Nat):V) f (vector n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2960 f n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 (atom97 n t s c u v y d w) w
  have d1 : (0+(2*(atom97 n t s c u v y d w)):V)=(atom97 n t s c u v y d w)+(atom97 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom97 n t s c u v y d w)):V)=0+((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter619 f n t s c u v y d w).trans mid

theorem seedEmitAfter621 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2966:Nat):V) f (vector n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c 0 (v+y) 0 0 w)) := by
  have micro := site2964 f n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  exact (seedEmitAfter620 f n t s c u v y d w).trans micro

theorem seedEmit (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2968:Nat):V) f (vector n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c 0 0 0 0 w)) := by
  have micro := site2966 f n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c 0 (v+y) 0 0 w
  exact (seedEmitAfter621 f n t s c u v y d w).trans micro

end PA192.ModelSearch.RegisterSource.Commands
