module
public import ModelStandard

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM NF192.Selected

namespace PA192.PhysicalModel
set_option maxRecDepth 300000
set_option maxHeartbeats 0

private def runFrom (m : Machine n) (a : Rays n) : Nat → Rays n
| 0 => a
| k+1 => (runFrom m a k).advance m

private theorem run_shift (m : Machine n) (q : Fin n) (j k : Nat) :
  Rays.run m q (j+k)=runFrom m (Rays.run m q j) k := by
  induction k with
  | zero => rfl
  | succ k ih => rw [Nat.add_succ,Rays.run,runFrom,ih]

private theorem ground0 : Rays.run machine start 0=Rays.blank start := rfl
private theorem ground128 : Rays.run machine start 128=⟨some 164,139,127⟩ := by
  rw [show 128=0+128 by decide,run_shift,ground0]
  decide +kernel
private theorem ground256 : Rays.run machine start 256=⟨some 181,547,4831⟩ := by
  rw [show 256=128+128 by decide,run_shift,ground128]
  decide +kernel
private theorem ground384 : Rays.run machine start 384=⟨some 171,575469,4⟩ := by
  rw [show 384=256+128 by decide,run_shift,ground256]
  decide +kernel
private theorem ground512 : Rays.run machine start 512=⟨some 164,35,1158401⟩ := by
  rw [show 512=384+128 by decide,run_shift,ground384]
  decide +kernel
private theorem ground640 : Rays.run machine start 640=⟨some 179,35,17935865⟩ := by
  rw [show 640=512+128 by decide,run_shift,ground512]
  decide +kernel
private theorem ground768 : Rays.run machine start 768=⟨some 98,143,4642432⟩ := by
  rw [show 768=640+128 by decide,run_shift,ground640]
  decide +kernel
private theorem ground896 : Rays.run machine start 896=⟨some 68,143,448252⟩ := by
  rw [show 896=768+128 by decide,run_shift,ground768]
  decide +kernel
private theorem ground1024 : Rays.run machine start 1024=⟨some 188,0,3067510897⟩ := by
  rw [show 1024=896+128 by decide,run_shift,ground896]
  decide +kernel
private theorem ground1152 : Rays.run machine start 1152=⟨some 169,0,149709126084⟩ := by
  rw [show 1152=1024+128 by decide,run_shift,ground1024]
  decide +kernel
private theorem ground1280 : Rays.run machine start 1280=⟨some 188,0,922794069776⟩ := by
  rw [show 1280=1152+128 by decide,run_shift,ground1152]
  decide +kernel
private theorem ground1408 : Rays.run machine start 1408=⟨some 169,0,161979298756⟩ := by
  rw [show 1408=1280+128 by decide,run_shift,ground1280]
  decide +kernel
private theorem ground1536 : Rays.run machine start 1536=⟨some 169,0,1605088053188⟩ := by
  rw [show 1536=1408+128 by decide,run_shift,ground1408]
  decide +kernel
private theorem ground1664 : Rays.run machine start 1664=⟨some 174,9562937050,23⟩ := by
  rw [show 1664=1536+128 by decide,run_shift,ground1536]
  decide +kernel
private theorem ground1792 : Rays.run machine start 1792=⟨some 176,2330614,2812781⟩ := by
  rw [show 1792=1664+128 by decide,run_shift,ground1664]
  decide +kernel
private theorem ground1920 : Rays.run machine start 1920=⟨some 188,0,188762566946576⟩ := by
  rw [show 1920=1792+128 by decide,run_shift,ground1792]
  decide +kernel
private theorem ground2048 : Rays.run machine start 2048=⟨some 185,9604918125,684⟩ := by
  rw [show 2048=1920+128 by decide,run_shift,ground1920]
  decide +kernel
private theorem ground2176 : Rays.run machine start 2176=⟨some 189,0,1503778471675664⟩ := by
  rw [show 2176=2048+128 by decide,run_shift,ground2048]
  decide +kernel
private theorem ground2304 : Rays.run machine start 2304=⟨some 169,583677,85437877⟩ := by
  rw [show 2304=2176+128 by decide,run_shift,ground2176]
  decide +kernel
private theorem ground2432 : Rays.run machine start 2432=⟨some 157,146432,381513132⟩ := by
  rw [show 2432=2304+128 by decide,run_shift,ground2304]
  decide +kernel
private theorem ground2560 : Rays.run machine start 2560=⟨some 165,146687,381513133⟩ := by
  rw [show 2560=2432+128 by decide,run_shift,ground2432]
  decide +kernel
private theorem ground2688 : Rays.run machine start 2688=⟨some 181,9835455634170,43⟩ := by
  rw [show 2688=2560+128 by decide,run_shift,ground2560]
  decide +kernel
private theorem ground2816 : Rays.run machine start 2816=⟨some 188,0,763016890286193⟩ := by
  rw [show 2816=2688+128 by decide,run_shift,ground2688]
  decide +kernel
private theorem ground2944 : Rays.run machine start 2944=⟨some 164,36479,11374278327⟩ := by
  rw [show 2944=2816+128 by decide,run_shift,ground2816]
  decide +kernel
private theorem ground3072 : Rays.run machine start 3072=⟨some 160,576,745133682175⟩ := by
  rw [show 3072=2944+128 by decide,run_shift,ground2944]
  decide +kernel
private theorem ground3200 : Rays.run machine start 3200=⟨some 14,2,190754222637042⟩ := by
  rw [show 3200=3072+128 by decide,run_shift,ground3072]
  decide +kernel
private theorem ground3328 : Rays.run machine start 3328=⟨some 158,37888,11642713960⟩ := by
  rw [show 3328=3200+128 by decide,run_shift,ground3200]
  decide +kernel
private theorem ground3456 : Rays.run machine start 3456=⟨some 172,152063,2910678491⟩ := by
  rw [show 3456=3328+128 by decide,run_shift,ground3328]
  decide +kernel
private theorem ground3584 : Rays.run machine start 3584=⟨some 176,40750611655669,85⟩ := by
  rw [show 3584=3456+128 by decide,run_shift,ground3456]
  decide +kernel
private theorem ground3712 : Rays.run machine start 3712=⟨some 173,38207,92005578600⟩ := by
  rw [show 3712=3584+128 by decide,run_shift,ground3584]
  decide +kernel
private theorem ground3840 : Rays.run machine start 3840=⟨some 164,37,89815665983458⟩ := by
  rw [show 3840=3712+128 by decide,run_shift,ground3712]
  decide +kernel
private theorem ground3968 : Rays.run machine start 3968=⟨some 158,152832,24527952820⟩ := by
  rw [show 3968=3840+128 by decide,run_shift,ground3840]
  decide +kernel
private theorem ground4096 : Rays.run machine start 4096=⟨some 189,0,102877690624738960⟩ := by
  rw [show 4096=3968+128 by decide,run_shift,ground3968]
  decide +kernel
private theorem ground4224 : Rays.run machine start 4224=⟨some 164,149503,24527952695⟩ := by
  rw [show 4224=4096+128 by decide,run_shift,ground4096]
  decide +kernel
private theorem ground4352 : Rays.run machine start 4352=⟨some 158,2368,1569788975616⟩ := by
  rw [show 4352=4224+128 by decide,run_shift,ground4224]
  decide +kernel
private theorem ground4480 : Rays.run machine start 4480=⟨some 177,38928374,95812315⟩ := by
  rw [show 4480=4352+128 by decide,run_shift,ground4352]
  decide +kernel
private theorem ground4608 : Rays.run machine start 4608=⟨some 181,40750640117245,694⟩ := by
  rw [show 4608=4480+128 by decide,run_shift,ground4480]
  decide +kernel
private theorem ground4736 : Rays.run machine start 4736=⟨some 3,596,47742770178048⟩ := by
  rw [show 4736=4608+128 by decide,run_shift,ground4608]
  decide +kernel
private theorem ground4864 : Rays.run machine start 4864=⟨some 164,2443263,11387514294⟩ := by
  rw [show 4864=4736+128 by decide,run_shift,ground4736]
  decide +kernel
private theorem ground4992 : Rays.run machine start 4992=⟨some 191,9539,2983923136255⟩ := by
  rw [show 4992=4864+128 by decide,run_shift,ground4864]
  decide +kernel
private theorem ground5120 : Rays.run machine start 5120=⟨some 189,0,782217546630683280⟩ := by
  rw [show 5120=4992+128 by decide,run_shift,ground4992]
  decide +kernel
private theorem ground5248 : Rays.run machine start 5248=⟨some 159,627310518,45530925⟩ := by
  rw [show 5248=5120+128 by decide,run_shift,ground5120]
  decide +kernel
private theorem ground5376 : Rays.run machine start 5376=⟨some 173,2397,11935670973440⟩ := by
  rw [show 5376=5248+128 by decide,run_shift,ground5248]
  decide +kernel
private theorem ground5504 : Rays.run machine start 5504=⟨some 164,153407,182199891679⟩ := by
  rw [show 5504=5376+128 by decide,run_shift,ground5376]
  decide +kernel
private theorem ground5632 : Rays.run machine start 5632=⟨some 181,613503,368746261943⟩ := by
  rw [show 5632=5504+128 by decide,run_shift,ground5504]
  decide +kernel
private theorem ground5760 : Rays.run machine start 5760=⟨some 173,598,377596172226560⟩ := by
  rw [show 5760=5632+128 by decide,run_shift,ground5632]
  decide +kernel
private theorem ground5888 : Rays.run machine start 5888=⟨some 189,0,6186531287780530832⟩ := by
  rw [show 5888=5760+128 by decide,run_shift,ground5760]
  decide +kernel
private theorem ground6016 : Rays.run machine start 6016=⟨some 158,2396,94398999914496⟩ := by
  rw [show 6016=5888+128 by decide,run_shift,ground5888]
  decide +kernel
private theorem ground6144 : Rays.run machine start 6144=⟨some 171,10053746102,22506475⟩ := by
  rw [show 6144=6016+128 by decide,run_shift,ground6016]
  decide +kernel
private theorem ground6272 : Rays.run machine start 6272=⟨some 185,164686216410613,1369⟩ := by
  rw [show 6272=6144+128 by decide,run_shift,ground6144]
  decide +kernel
private theorem ground6400 : Rays.run machine start 6400=⟨some 169,0,12319243523269336740⟩ := by
  rw [show 6400=6272+128 by decide,run_shift,ground6272]
  decide +kernel
private theorem ground6528 : Rays.run machine start 6528=⟨some 172,612863,2937136536431⟩ := by
  rw [show 6528=6400+128 by decide,run_shift,ground6400]
  decide +kernel
private theorem ground6656 : Rays.run machine start 6656=⟨some 181,39206910,45892753115⟩ := by
  rw [show 6656=6528+128 by decide,run_shift,ground6528]
  decide +kernel
private theorem ground6784 : Rays.run machine start 6784=⟨some 164,2455551,734284049847⟩ := by
  rw [show 6784=6656+128 by decide,run_shift,ground6656]
  decide +kernel
private theorem ground6912 : Rays.run machine start 6912=⟨some 164,149,12026111826198515⟩ := by
  rw [show 6912=6784+128 by decide,run_shift,ground6784]
  decide +kernel
private theorem ground7040 : Rays.run machine start 7040=⟨some 181,2454015,5866769968567⟩ := by
  rw [show 7040=6912+128 by decide,run_shift,ground6912]
  decide +kernel
private theorem ground7168 : Rays.run machine start 7168=⟨some 14,2,6151754186556964970⟩ := by
  rw [show 7168=7040+128 by decide,run_shift,ground7040]
  decide +kernel
private theorem ground7296 : Rays.run machine start 7296=⟨some 164,9575,1501893044844543⟩ := by
  rw [show 7296=7168+128 by decide,run_shift,ground7168]
  decide +kernel
private theorem ground7424 : Rays.run machine start 7424=⟨some 158,2453504,5866769800040⟩ := by
  rw [show 7424=7296+128 by decide,run_shift,ground7296]
  decide +kernel
private theorem ground7552 : Rays.run machine start 7552=⟨some 188,0,24607016039420525481⟩ := by
  rw [show 7552=7424+128 by decide,run_shift,ground7424]
  decide +kernel
private theorem ground7680 : Rays.run machine start 7680=⟨some 185,9585,1501824349335551⟩ := by
  rw [show 7680=7552+128 by decide,run_shift,ground7552]
  decide +kernel
private theorem ground7808 : Rays.run machine start 7808=⟨some 158,9822208,11729516803802⟩ := by
  rw [show 7808=7680+128 by decide,run_shift,ground7680]
  decide +kernel
private theorem ground7936 : Rays.run machine start 7936=⟨some 164,9814015,11729516803803⟩ := by
  rw [show 7936=7808+128 by decide,run_shift,ground7808]
  decide +kernel
private theorem ground8064 : Rays.run machine start 8064=⟨some 188,0,12594472626817668639296⟩ := by
  rw [show 8064=7936+128 by decide,run_shift,ground7936]
  decide +kernel
private theorem ground8192 : Rays.run machine start 8192=⟨some 50,38336,3002756280202242⟩ := by
  rw [show 8192=8064+128 by decide,run_shift,ground8064]
  decide +kernel
private theorem ground8320 : Rays.run machine start 8320=⟨some 184,9587,12011025120813055⟩ := by
  rw [show 8320=8192+128 by decide,run_shift,ground8192]
  decide +kernel
private theorem ground8448 : Rays.run machine start 8448=⟨some 187,157057022,733090600667⟩ := by
  rw [show 8448=8320+128 by decide,run_shift,ground8320]
  decide +kernel
private theorem ground8576 : Rays.run machine start 8576=⟨some 50,2455552,375311266330322⟩ := by
  rw [show 8576=8448+128 by decide,run_shift,ground8448]
  decide +kernel
private theorem ground8704 : Rays.run machine start 8704=⟨some 164,2453503,375311266330335⟩ := by
  rw [show 8704=8576+128 by decide,run_shift,ground8576]
  decide +kernel
private theorem ground8832 : Rays.run machine start 8832=⟨some 188,0,100746850637846213978688⟩ := by
  rw [show 8832=8704+128 by decide,run_shift,ground8704]
  decide +kernel
private theorem ground8960 : Rays.run machine start 8960=⟨some 51,614400,1501245065321281⟩ := by
  rw [show 8960=8832+128 by decide,run_shift,ground8832]
  decide +kernel
private theorem ground9088 : Rays.run machine start 9088=⟨some 164,37887,24019921045141503⟩ := by
  rw [show 9088=8960+128 by decide,run_shift,ground8960]
  decide +kernel
private theorem ground9216 : Rays.run machine start 9216=⟨some 159,148479,6004980261277183⟩ := by
  rw [show 9216=9088+128 by decide,run_shift,ground9088]
  decide +kernel
private theorem ground9344 : Rays.run machine start 9344=⟨some 51,38,24596399150223851521⟩ := by
  rw [show 9344=9216+128 by decide,run_shift,ground9216]
  decide +kernel
private theorem ground9472 : Rays.run machine start 9472=⟨some 174,165356239725,5726795445⟩ := by
  rw [show 9472=9344+128 by decide,run_shift,ground9344]
  decide +kernel
private theorem ground9600 : Rays.run machine start 9600=⟨some 191,626687,1501245065321343⟩ := by
  rw [show 9600=9472+128 by decide,run_shift,ground9472]
  decide +kernel
private theorem ground9728 : Rays.run machine start 9728=⟨some 188,0,6296678182457305989140⟩ := by
  rw [show 9728=9600+128 by decide,run_shift,ground9600]
  decide +kernel
private theorem ground9856 : Rays.run machine start 9856=⟨some 164,45079976439213,22370278⟩ := by
  rw [show 9856=9728+128 by decide,run_shift,ground9728]
  decide +kernel
private theorem ground9984 : Rays.run machine start 9984=⟨some 181,173946174902,5726793067⟩ := by
  rw [show 9984=9856+128 by decide,run_shift,ground9856]
  decide +kernel
private theorem ground10112 : Rays.run machine start 10112=⟨some 169,2,393542222969019826181⟩ := by
  rw [show 10112=9984+128 by decide,run_shift,ground9984]
  decide +kernel
private theorem ground10240 : Rays.run machine start 10240=⟨some 174,45634027373,22907172269⟩ := by
  rw [show 10240=10112+128 by decide,run_shift,ground10112]
  decide +kernel
private theorem ground10368 : Rays.run machine start 10368=⟨some 190,3044433338285382645,341⟩ := by
  rw [show 10368=10240+128 by decide,run_shift,ground10240]
  decide +kernel
private theorem ground10496 : Rays.run machine start 10496=⟨some 158,176128,48038752558701056⟩ := by
  rw [show 10496=10368+128 by decide,run_shift,ground10368]
  decide +kernel
private theorem ground10624 : Rays.run machine start 10624=⟨some 164,2687,3074480163756900351⟩ := by
  rw [show 10624=10496+128 by decide,run_shift,ground10496]
  decide +kernel
private theorem ground10752 : Rays.run machine start 10752=⟨some 169,10,787066640446789779452⟩ := by
  rw [show 10752=10624+128 by decide,run_shift,ground10624]
  decide +kernel
private theorem ground10880 : Rays.run machine start 10880=⟨some 160,168,49191672410359726079⟩ := by
  rw [show 10880=10752+128 by decide,run_shift,ground10752]
  decide +kernel
private theorem ground11008 : Rays.run machine start 11008=⟨some 173,687,12297918102589669376⟩ := by
  rw [show 11008=10880+128 by decide,run_shift,ground10880]
  decide +kernel
private theorem ground11136 : Rays.run machine start 11136=⟨some 164,43519,192154970285858815⟩ := by
  rw [show 11136=11008+128 by decide,run_shift,ground11008]
  decide +kernel
private theorem ground11264 : Rays.run machine start 11264=⟨some 176,761108335798498750,87381⟩ := by
  rw [show 11264=11136+128 by decide,run_shift,ground11136]
  decide +kernel
private theorem ground11392 : Rays.run machine start 11392=⟨some 51,2752,24595703125617999873⟩ := by
  rw [show 11392=11264+128 by decide,run_shift,ground11264]
  decide +kernel
private theorem ground11520 : Rays.run machine start 11520=⟨some 166,0,6447616000162022138313024⟩ := by
  rw [show 11520=11392+128 by decide,run_shift,ground11392]
  decide +kernel
private theorem ground11648 : Rays.run machine start 11648=⟨some 188,0,1611903711810129382866000⟩ := by
  rw [show 11648=11520+128 by decide,run_shift,ground11520]
  decide +kernel
private theorem ground11776 : Rays.run machine start 11776=⟨some 160,172032,384307821465530367⟩ := by
  rw [show 11776=11648+128 by decide,run_shift,ground11648]
  decide +kernel
private theorem ground11904 : Rays.run machine start 11904=⟨some 173,44031,1537231285862113280⟩ := by
  rw [show 11904=11776+128 by decide,run_shift,ground11776]
  decide +kernel
private theorem ground12032 : Rays.run machine start 12032=⟨some 164,10879,6148925142911614975⟩ := by
  rw [show 12032=11904+128 by decide,run_shift,ground11904]
  decide +kernel
private theorem ground12160 : Rays.run machine start 12160=⟨some 181,12177733382592976629,43690⟩ := by
  rw [show 12160=12032+128 by decide,run_shift,ground12032]
  decide +kernel
private theorem ground12288 : Rays.run machine start 12288=⟨some 158,11008,49191338434622816256⟩ := by
  rw [show 12288=12160+128 by decide,run_shift,ground12160]
  decide +kernel
private theorem ground12416 : Rays.run machine start 12416=⟨some 164,10,50371930557053797400574⟩ := by
  rw [show 12416=12288+128 by decide,run_shift,ground12288]
  decide +kernel
private theorem ground12544 : Rays.run machine start 12544=⟨some 169,10,50371926053454170030076⟩ := by
  rw [show 12544=12416+128 by decide,run_shift,ground12416]
  decide +kernel
private theorem ground12672 : Rays.run machine start 12672=⟨some 181,161,3148245496518752075775⟩ := by
  rw [show 12672=12544+128 by decide,run_shift,ground12544]
  decide +kernel
private theorem ground12800 : Rays.run machine start 12800=⟨some 14,2,201487711777199864414213⟩ := by
  rw [show 12800=12672+128 by decide,run_shift,ground12672]
  decide +kernel
private theorem ground12928 : Rays.run machine start 12928=⟨some 164,730144440027,733008025318⟩ := by
  rw [show 12928=12800+128 by decide,run_shift,ground12800]
  decide +kernel
private theorem ground13056 : Rays.run machine start 13056=⟨some 159,194843734200022686634,2730⟩ := by
  rw [show 13056=12928+128 by decide,run_shift,ground12928]
  decide +kernel
private theorem ground13184 : Rays.run machine start 13184=⟨some 158,45088768,96076801012250320⟩ := by
  rw [show 13184=13056+128 by decide,run_shift,ground13056]
  decide +kernel
private theorem ground13312 : Rays.run machine start 13312=⟨some 173,172031,24595661059136081920⟩ := by
  rw [show 13312=13184+128 by decide,run_shift,ground13184]
  decide +kernel
private theorem ground13440 : Rays.run machine start 13440=⟨some 164,45079976720091,91625973431⟩ := by
  rw [show 13440=13312+128 by decide,run_shift,ground13312]
  decide +kernel
private theorem ground13568 : Rays.run machine start 13568=⟨some 176,11399736554384886,357913965⟩ := by
  rw [show 13568=13440+128 by decide,run_shift,ground13440]
  decide +kernel
private theorem ground13696 : Rays.run machine start 13696=⟨some 158,10752,393530566740721401856⟩ := by
  rw [show 13696=13568+128 by decide,run_shift,ground13568]
  decide +kernel
private theorem ground13824 : Rays.run machine start 13824=⟨some 188,0,103161676887679705527876944⟩ := by
  rw [show 13824=13696+128 by decide,run_shift,ground13696]
  decide +kernel
private theorem ground13952 : Rays.run machine start 13952=⟨some 185,10815,393530566738574049279⟩ := by
  rw [show 13952=13824+128 by decide,run_shift,ground13824]
  decide +kernel
private theorem ground14080 : Rays.run machine start 14080=⟨some 181,177209343,192153587336272751⟩ := by
  rw [show 14080=13952+128 by decide,run_shift,ground13952]
  decide +kernel
private theorem ground14208 : Rays.run machine start 14208=⟨some 164,10,3223802239915512461000707⟩ := by
  rw [show 14208=14080+128 by decide,run_shift,ground14080]
  decide +kernel
private theorem ground14336 : Rays.run machine start 14336=⟨some 119,10,3223802239915512595218430⟩ := by
  rw [show 14336=14208+128 by decide,run_shift,ground14208]
  decide +kernel
private theorem ground14464 : Rays.run machine start 14464=⟨some 188,0,206323338742906787666591508⟩ := by
  rw [show 14464=14336+128 by decide,run_shift,ground14336]
  decide +kernel
private theorem ground14592 : Rays.run machine start 14592=⟨some 183,44,805950559978878148804607⟩ := by
  rw [show 14592=14464+128 by decide,run_shift,ground14464]
  decide +kernel
private theorem ground14720 : Rays.run machine start 14720=⟨some 14,2,12895208959662049844002819⟩ := by
  rw [show 14720=14592+128 by decide,run_shift,ground14592]
  decide +kernel
private theorem ground14848 : Rays.run machine start 14848=⟨some 164,11599871,3074457397380359935⟩ := by
  rw [show 14848=14720+128 by decide,run_shift,ground14720]
  decide +kernel
private theorem ground14976 : Rays.run machine start 14976=⟨some 160,737280,49191318358085824511⟩ := by
  rw [show 14976=14848+128 by decide,run_shift,ground14848]
  decide +kernel
private theorem ground15104 : Rays.run machine start 15104=⟨some 173,186367,196765273432343289856⟩ := by
  rw [show 15104=14976+128 by decide,run_shift,ground14976]
  decide +kernel
private theorem ground15232 : Rays.run machine start 15232=⟨some 169,12146704381,3002399801867117⟩ := by
  rw [show 15232=15104+128 by decide,run_shift,ground15104]
  decide +kernel
private theorem ground15360 : Rays.run machine start 15360=⟨some 191,189267967,192153587336272751⟩ := by
  rw [show 15360=15232+128 by decide,run_shift,ground15232]
  decide +kernel
private theorem ground15488 : Rays.run machine start 15488=⟨some 51,46,805950559978878115250177⟩ := by
  rw [show 15488=15360+128 by decide,run_shift,ground15360]
  decide +kernel
private theorem ground15616 : Rays.run machine start 15616=⟨some 184,12189695,3074457397380364031⟩ := by
  rw [show 15616=15488+128 by decide,run_shift,ground15488]
  decide +kernel
private theorem ground15744 : Rays.run machine start 15744=⟨some 159,47359,787061076137187147775⟩ := by
  rw [show 15744=15616+128 by decide,run_shift,ground15616]
  decide +kernel
private theorem ground15872 : Rays.run machine start 15872=⟨some 160,3145728,12297829589521456127⟩ := by
  rw [show 15872=15744+128 by decide,run_shift,ground15744]
  decide +kernel
private theorem ground16000 : Rays.run machine start 16000=⟨some 173,207,201487639994719528812544⟩ := by
  rw [show 16000=15872+128 by decide,run_shift,ground15872]
  decide +kernel
private theorem ground16128 : Rays.run machine start 16128=⟨some 164,838860799,48038396834035419⟩ := by
  rw [show 16128=16000+128 by decide,run_shift,ground16000]
  decide +kernel
private theorem ground16256 : Rays.run machine start 16256=⟨some 181,12543,3148244374916265672703⟩ := by
  rw [show 16256=16128+128 by decide,run_shift,ground16128]
  decide +kernel
private theorem ground16384 : Rays.run machine start 16384=⟨some 164,3,12895208959657023121653762⟩ := by
  rw [show 16384=16256+128 by decide,run_shift,ground16256]
  decide +kernel
private theorem ground16512 : Rays.run machine start 16512=⟨some 171,219152383,192153587336197855⟩ := by
  rw [show 16512=16384+128 by decide,run_shift,ground16384]
  decide +kernel
private theorem ground16640 : Rays.run machine start 16640=⟨some 190,57312043595483,733007764190⟩ := by
  rw [show 16640=16512+128 by decide,run_shift,ground16512]
  decide +kernel
private theorem ground16768 : Rays.run machine start 16768=⟨some 158,13440,3148244374913810956288⟩ := by
  rw [show 16768=16640+128 by decide,run_shift,ground16640]
  decide +kernel
private theorem ground16896 : Rays.run machine start 16896=⟨some 188,0,206323343354351549191012652⟩ := by
  rw [show 16896=16768+128 by decide,run_shift,ground16768]
  decide +kernel
private theorem ground17024 : Rays.run machine start 17024=⟨some 191,3440895,12297829589507076095⟩ := by
  rw [show 17024=16896+128 by decide,run_shift,ground16896]
  decide +kernel
private theorem ground17152 : Rays.run machine start 17152=⟨some 188,0,51580835838587878707823691⟩ := by
  rw [show 17152=17024+128 by decide,run_shift,ground17024]
  decide +kernel
private theorem ground17280 : Rays.run machine start 17280=⟨some 174,57767310128859,733007764190⟩ := by
  rw [show 17280=17152+128 by decide,run_shift,ground17152]
  decide +kernel
private theorem ground17408 : Rays.run machine start 17408=⟨some 191,3696832970414959,11453246314⟩ := by
  rw [show 17408=17280+128 by decide,run_shift,ground17280]
  decide +kernel
private theorem ground17536 : Rays.run machine start 17536=⟨some 50,3364,12592977499655243825154⟩ := by
  rw [show 17536=17408+128 by decide,run_shift,ground17408]
  decide +kernel
private theorem ground17664 : Rays.run machine start 17664=⟨some 93,841,50371909998620983689200⟩ := by
  rw [show 17664=17536+128 by decide,run_shift,ground17536]
  decide +kernel
private theorem ground17792 : Rays.run machine start 17792=⟨some 84,3,12895208671416595672719506⟩ := by
  rw [show 17792=17664+128 by decide,run_shift,ground17664]
  decide +kernel
private theorem ground17920 : Rays.run machine start 17920=⟨some 160,220495872,192153587336048063⟩ := by
  rw [show 17920=17792+128 by decide,run_shift,ground17792]
  decide +kernel
private theorem ground18048 : Rays.run machine start 18048=⟨some 173,881987583,48038396834012008⟩ := by
  rw [show 18048=17920+128 by decide,run_shift,ground17920]
  decide +kernel
private theorem ground18176 : Rays.run machine start 18176=⟨some 12,215328,196765273432104828926⟩ := by
  rw [show 18176=18048+128 by decide,run_shift,ground18048]
  decide +kernel
private theorem ground18304 : Rays.run machine start 18304=⟨some 189,3364,12592977499655243825169⟩ := by
  rw [show 18304=18176+128 by decide,run_shift,ground18176]
  decide +kernel
private theorem ground18432 : Rays.run machine start 18432=⟨some 102,53832,787061093728452870137⟩ := by
  rw [show 18432=18304+128 by decide,run_shift,ground18304]
  decide +kernel
private theorem ground18560 : Rays.run machine start 18560=⟨some 170,215330,196765273432113217532⟩ := by
  rw [show 18560=18432+128 by decide,run_shift,ground18432]
  decide +kernel
private theorem ground18688 : Rays.run machine start 18688=⟨some 173,220499071,192153587336048032⟩ := by
  rw [show 18688=18560+128 by decide,run_shift,ground18560]
  decide +kernel
private theorem ground18816 : Rays.run machine start 18816=⟨some 164,210,201487639994475344806674⟩ := by
  rw [show 18816=18688+128 by decide,run_shift,ground18688]
  decide +kernel
private theorem ground18944 : Rays.run machine start 18944=⟨some 51,55124800,768614349344192129⟩ := by
  rw [show 18944=18816+128 by decide,run_shift,ground18816]
  decide +kernel
private theorem ground19072 : Rays.run machine start 19072=⟨some 166,0,3301173493669624786968679104⟩ := by
  rw [show 19072=18944+128 by decide,run_shift,ground18944]
  decide +kernel
private theorem ground19200 : Rays.run machine start 19200=⟨some 164,3,12895208671416595671860370⟩ := by
  rw [show 19200=19072+128 by decide,run_shift,ground19072]
  decide +kernel
private theorem ground19328 : Rays.run machine start 19328=⟨some 183,3445304,12297829589507076095⟩ := by
  rw [show 19328=19200+128 by decide,run_shift,ground19200]
  decide +kernel
private theorem ground19456 : Rays.run machine start 19456=⟨some 164,220499711,192153587336048063⟩ := by
  rw [show 19456=19328+128 by decide,run_shift,ground19328]
  decide +kernel
private theorem ground19584 : Rays.run machine start 19584=⟨some 179,215331,196765273414933348345⟩ := by
  rw [show 19584=19456+128 by decide,run_shift,ground19456]
  decide +kernel
private theorem ground19712 : Rays.run machine start 19712=⟨some 183,215332,196765273432113217528⟩ := by
  rw [show 19712=19584+128 by decide,run_shift,ground19584]
  decide +kernel
private theorem ground19840 : Rays.run machine start 19840=⟨some 173,13781311,3074457397376768512⟩ := by
  rw [show 19840=19712+128 by decide,run_shift,ground19712]
  decide +kernel
private theorem ground19968 : Rays.run machine start 19968=⟨some 164,3445319,12297829589473521663⟩ := by
  rw [show 19968=19840+128 by decide,run_shift,ground19840]
  decide +kernel
private theorem ground20096 : Rays.run machine start 20096=⟨some 160,13781312,3074457397371975679⟩ := by
  rw [show 20096=19968+128 by decide,run_shift,ground19968]
  decide +kernel
private theorem ground20224 : Rays.run machine start 20224=⟨some 173,14112096255,3002399802121069⟩ := by
  rw [show 20224=20096+128 by decide,run_shift,ground20096]
  decide +kernel
private theorem ground20352 : Rays.run machine start 20352=⟨some 169,903173111789,46912495859565⟩ := by
  rw [show 20352=20224+128 by decide,run_shift,ground20224]
  decide +kernel
private theorem ground20480 : Rays.run machine start 20480=⟨some 159,15516386903854249523882,2730⟩ := by
  rw [show 20480=20352+128 by decide,run_shift,ground20352]
  decide +kernel
private theorem ground20608 : Rays.run machine start 20608=⟨some 50,13781344,24595658908325753858⟩ := by
  rw [show 20608=20480+128 by decide,run_shift,ground20480]
  decide +kernel
private theorem ground20736 : Rays.run machine start 20736=⟨some 166,0,26409387658707544830988554944⟩ := by
  rw [show 20736=20608+128 by decide,run_shift,ground20608]
  decide +kernel
private theorem ground20864 : Rays.run machine start 20864=⟨some 185,3445336,98382635633301970943⟩ := by
  rw [show 20864=20736+128 by decide,run_shift,ground20736]
  decide +kernel
private theorem ground20992 : Rays.run machine start 20992=⟨some 181,3528025087,768614337524719031⟩ := by
  rw [show 20992=20864+128 by decide,run_shift,ground20864]
  decide +kernel
private theorem ground21120 : Rays.run machine start 21120=⟨some 164,53833,50371909224019986219008⟩ := by
  rw [show 21120=20992+128 by decide,run_shift,ground20992]
  decide +kernel
private theorem ground21248 : Rays.run machine start 21248=⟨some 93,841,3223802190337279134793508⟩ := by
  rw [show 21248=21120+128 by decide,run_shift,ground21120]
  decide +kernel
private theorem ground21376 : Rays.run machine start 21376=⟨some 159,3445315,787061081625178071039⟩ := by
  rw [show 21376=21248+128 by decide,run_shift,ground21248]
  decide +kernel
private theorem ground21504 : Rays.run machine start 21504=⟨some 51,861332,3148244326500944740353⟩ := by
  rw [show 21504=21376+128 by decide,run_shift,ground21376]
  decide +kernel
private theorem ground21632 : Rays.run machine start 21632=⟨some 87,13,206323340181565916651170084⟩ := by
  rw [show 21632=21504+128 by decide,run_shift,ground21504]
  decide +kernel
private theorem ground21760 : Rays.run machine start 21760=⟨some 188,0,52818775049587386515272049840⟩ := by
  rw [show 21760=21632+128 by decide,run_shift,ground21632]
  decide +kernel
private theorem ground21888 : Rays.run machine start 21888=⟨some 176,15152721585948702391,1431655765⟩ := by
  rw [show 21888=21760+128 by decide,run_shift,ground21760]
  decide +kernel
private theorem ground22016 : Rays.run machine start 22016=⟨some 169,13,1650586719732150070088329508⟩ := by
  rw [show 22016=21888+128 by decide,run_shift,ground21888]
  decide +kernel
private theorem ground22144 : Rays.run machine start 22144=⟨some 168,13781351,1574122161609792778239⟩ := by
  rw [show 22144=22016+128 by decide,run_shift,ground22016]
  decide +kernel
private theorem ground22272 : Rays.run machine start 22272=⟨some 159,3699402434637293,5864062017238⟩ := by
  rw [show 22272=22144+128 by decide,run_shift,ground22144]
  decide +kernel
private theorem ground22400 : Rays.run machine start 22400=⟨some 160,13781360,12592977288958876282879⟩ := by
  rw [show 22400=22272+128 by decide,run_shift,ground22272]
  decide +kernel
private theorem ground22528 : Rays.run machine start 22528=⟨some 164,3,52818775014989370620198790290⟩ := by
  rw [show 22528=22400+128 by decide,run_shift,ground22400]
  decide +kernel
private theorem ground22656 : Rays.run machine start 22656=⟨some 171,3445319,50371909155835505131519⟩ := by
  rw [show 22656=22528+128 by decide,run_shift,ground22528]
  decide +kernel
private theorem ground22784 : Rays.run machine start 22784=⟨some 159,882000895,196765270139980344767⟩ := by
  rw [show 22784=22656+128 by decide,run_shift,ground22656]
  decide +kernel
private theorem ground22912 : Rays.run machine start 22912=⟨some 50,215334,805950546493368081973250⟩ := by
  rw [show 22912=22784+128 by decide,run_shift,ground22784]
  decide +kernel
private theorem ground23040 : Rays.run machine start 23040=⟨some 84,3,52818775014989370628788675730⟩ := by
  rw [show 23040=22912+128 by decide,run_shift,ground22912]
  decide +kernel
private theorem ground23168 : Rays.run machine start 23168=⟨some 189,0,3380401600885532743947632846000⟩ := by
  rw [show 23168=23040+128 by decide,run_shift,ground23040]
  decide +kernel
private theorem ground23296 : Rays.run machine start 23296=⟨some 160,3445360,50371909155197399302143⟩ := by
  rw [show 23296=23168+128 by decide,run_shift,ground23168]
  decide +kernel
private theorem ground23424 : Rays.run machine start 23424=⟨some 178,861340,201487636620789597143040⟩ := by
  rw [show 23424=23296+128 by decide,run_shift,ground23296]
  decide +kernel
private theorem ground23552 : Rays.run machine start 23552=⟨some 164,14450904006582,12009599007414895⟩ := by
  rw [show 23552=23424+128 by decide,run_shift,ground23424]
  decide +kernel
private theorem ground23680 : Rays.run machine start 23680=⟨some 159,15152862323513716438,11453246123⟩ := by
  rw [show 23680=23552+128 by decide,run_shift,ground23552]
  decide +kernel
private theorem ground23808 : Rays.run machine start 23808=⟨some 160,220503552,6296488643969573416447⟩ := by
  rw [show 23808=23680+128 by decide,run_shift,ground23680]
  decide +kernel
private theorem ground23936 : Rays.run machine start 23936=⟨some 164,3,422550200085698522525244351634⟩ := by
  rw [show 23936=23808+128 by decide,run_shift,ground23808]
  decide +kernel
private theorem ground24064 : Rays.run machine start 24064=⟨some 184,861337,1611901092856210794610687⟩ := by
  rw [show 24064=23936+128 by decide,run_shift,ground23936]
  decide +kernel
private theorem ground24192 : Rays.run machine start 24192=⟨some 89,52,26409387505067927282749793865⟩ := by
  rw [show 24192=24064+128 by decide,run_shift,ground24064]
  decide +kernel
private theorem ground24320 : Rays.run machine start 24320=⟨some 160,14112194560,98382635061401582447⟩ := by
  rw [show 24320=24192+128 by decide,run_shift,ground24192]
  decide +kernel
private theorem ground24448 : Rays.run machine start 24448=⟨some 173,55125887,25185954575718805104640⟩ := by
  rw [show 24448=24320+128 by decide,run_shift,ground24320]
  decide +kernel
private theorem ground24576 : Rays.run machine start 24576=⟨some 169,903181500413,1537228672834391533⟩ := by
  rw [show 24576=24448+128 by decide,run_shift,ground24448]
  decide +kernel
private theorem ground24704 : Rays.run machine start 24704=⟨some 190,242445797176832129883,5726623061⟩ := by
  rw [show 24704=24576+128 by decide,run_shift,ground24576]
  decide +kernel
private theorem ground24832 : Rays.run machine start 24832=⟨some 160,55125888,201487636603266332848127⟩ := by
  rw [show 24832=24704+128 by decide,run_shift,ground24704]
  decide +kernel
private theorem ground24960 : Rays.run machine start 24960=⟨some 164,210,52818775009726649557602795922⟩ := by
  rw [show 24960=24832+128 by decide,run_shift,ground24832]
  decide +kernel
private theorem ground25088 : Rays.run machine start 25088=⟨some 100,13458,825293359526978899345932278⟩ := by
  rw [show 25088=24960+128 by decide,run_shift,ground24960]
  decide +kernel
private theorem ground25216 : Rays.run machine start 25216=⟨some 188,0,865382809754639059877690622644928⟩ := by
  rw [show 25216=25088+128 by decide,run_shift,ground25088]
  decide +kernel
private theorem ground25344 : Rays.run machine start 25344=⟨some 175,53833,206323339881744724836483065⟩ := by
  rw [show 25344=25216+128 by decide,run_shift,ground25216]
  decide +kernel
private theorem ground25472 : Rays.run machine start 25472=⟨some 89,52,211275100038906598230411182409⟩ := by
  rw [show 25472=25344+128 by decide,run_shift,ground25344]
  decide +kernel
private theorem ground25600 : Rays.run machine start 25600=⟨some 174,903186743293,12297829382523579885⟩ := by
  rw [show 25600=25472+128 by decide,run_shift,ground25472]
  decide +kernel
private theorem ground25728 : Rays.run machine start 25728=⟨some 181,3528069119,3148244321926036446079⟩ := by
  rw [show 25728=25600+128 by decide,run_shift,ground25600]
  decide +kernel
private theorem ground25856 : Rays.run machine start 25856=⟨some 188,0,54086425609960089066171158579500⟩ := by
  rw [show 25856=25728+128 by decide,run_shift,ground25728]
  decide +kernel
private theorem ground25984 : Rays.run machine start 25984=⟨some 184,14112342015,787061080481509111519⟩ := by
  rw [show 25984=25856+128 by decide,run_shift,ground25856]
  decide +kernel
private theorem ground26112 : Rays.run machine start 26112=⟨some 102,53834,206323339880618824623456242⟩ := by
  rw [show 26112=25984+128 by decide,run_shift,ground25984]
  decide +kernel
private theorem ground26240 : Rays.run machine start 26240=⟨some 176,242448048976951999323,366503875925⟩ := by
  rw [show 26240=26112+128 by decide,run_shift,ground26112]
  decide +kernel
private theorem ground26368 : Rays.run machine start 26368=⟨some 50,215337,412646679762380727946051587⟩ := by
  rw [show 26368=26240+128 by decide,run_shift,ground26240]
  decide +kernel
private theorem ground26496 : Rays.run machine start 26496=⟨some 164,56449302527,1574122160958788787639⟩ := by
  rw [show 26496=26368+128 by decide,run_shift,ground26368]
  decide +kernel
private theorem ground26624 : Rays.run machine start 26624=⟨some 179,53834,1650586719049522910714658808⟩ := by
  rw [show 26624=26496+128 by decide,run_shift,ground26496]
  decide +kernel
private theorem ground26752 : Rays.run machine start 26752=⟨some 160,14112325632,6296488643835155148223⟩ := by
  rw [show 26752=26624+128 by decide,run_shift,ground26624]
  decide +kernel
private theorem ground26880 : Rays.run machine start 26880=⟨some 173,13781599,6447604371287198871748608⟩ := by
  rw [show 26880=26752+128 by decide,run_shift,ground26752]
  decide +kernel
private theorem ground27008 : Rays.run machine start 27008=⟨some 168,947063241072630651,93824992237018⟩ := by
  rw [show 27008=26880+128 by decide,run_shift,ground26880]
  decide +kernel
private theorem ground27136 : Rays.run machine start 27136=⟨some 185,3612757458941,24595658764964297581⟩ := by
  rw [show 27136=27008+128 by decide,run_shift,ground27008]
  decide +kernel
private theorem ground27264 : Rays.run machine start 27264=⟨some 176,231216477372269,3074457345619504621⟩ := by
  rw [show 27264=27136+128 by decide,run_shift,ground27136]
  decide +kernel
private theorem ground27392 : Rays.run machine start 27392=⟨some 169,13,54086425609759707996068727776548⟩ := by
  rw [show 27392=27264+128 by decide,run_shift,ground27264]
  decide +kernel
private theorem ground27520 : Rays.run machine start 27520=⟨some 164,3445391,206323339880980331406032895⟩ := by
  rw [show 27520=27392+128 by decide,run_shift,ground27392]
  decide +kernel
private theorem ground27648 : Rays.run machine start 27648=⟨some 169,13,54086425609759707987306994435364⟩ := by
  rw [show 27648=27520+128 by decide,run_shift,ground27520]
  decide +kernel
private theorem ground27776 : Rays.run machine start 27776=⟨some 158,225798258688,3148244321914372732634⟩ := by
  rw [show 27776=27648+128 by decide,run_shift,ground27648]
  decide +kernel
private theorem ground27904 : Rays.run machine start 27904=⟨some 173,55126655,12895208742561270712868864⟩ := by
  rw [show 27904=27776+128 by decide,run_shift,ground27776]
  decide +kernel
private theorem ground28032 : Rays.run machine start 28032=⟨some 164,861352,825293359523921325622034431⟩ := by
  rw [show 28032=27904+128 by decide,run_shift,ground27904]
  decide +kernel
private theorem ground28160 : Rays.run machine start 28160=⟨some 160,225799307264,3148244321914372732635⟩ := by
  rw [show 28160=28032+128 by decide,run_shift,ground28032]
  decide +kernel
private theorem ground28288 : Rays.run machine start 28288=⟨some 173,55126815,12895208742561270712868864⟩ := by
  rw [show 28288=28160+128 by decide,run_shift,ground28160]
  decide +kernel
private theorem ground28416 : Rays.run machine start 28416=⟨some 164,14112460799,50371909150629963713983⟩ := by
  rw [show 28416=28288+128 by decide,run_shift,ground28288]
  decide +kernel
private theorem ground28544 : Rays.run machine start 28544=⟨some 170,861356,825293359523921325624131580⟩ := by
  rw [show 28544=28416+128 by decide,run_shift,ground28416]
  decide +kernel
private theorem ground28672 : Rays.run machine start 28672=⟨some 100,13458,52818775009530964839910866989⟩ := by
  rw [show 28672=28544+128 by decide,run_shift,ground28544]
  decide +kernel
private theorem ground28800 : Rays.run machine start 28800=⟨some 165,14451176636406,49191317529912073947⟩ := by
  rw [show 28800=28672+128 by decide,run_shift,ground28672]
  decide +kernel
private theorem ground28928 : Rays.run machine start 28928=⟨some 159,13781713,51580834970240684804997119⟩ := by
  rw [show 28928=28800+128 by decide,run_shift,ground28800]
  decide +kernel
private theorem ground29056 : Rays.run machine start 29056=⟨some 50,14112481280,50371909150627472005954⟩ := by
  rw [show 29056=28928+128 by decide,run_shift,ground28928]
  decide +kernel
private theorem ground29184 : Rays.run machine start 29184=⟨some 164,14112483327,50371909150627472006015⟩ := by
  rw [show 29184=29056+128 by decide,run_shift,ground29056]
  decide +kernel
private theorem ground29312 : Rays.run machine start 29312=⟨some 169,903198867455,787061080478553725805⟩ := by
  rw [show 29312=29184+128 by decide,run_shift,ground29184]
  decide +kernel
private theorem ground29440 : Rays.run machine start 29440=⟨some 159,3879209456769043258734,183251937962⟩ := by
  rw [show 29440=29312+128 by decide,run_shift,ground29312]
  decide +kernel
private theorem ground29568 : Rays.run machine start 29568=⟨some 181,13781720,412646679761830149186519038⟩ := by
  rw [show 29568=29440+128 by decide,run_shift,ground29440]
  decide +kernel
private theorem ground29696 : Rays.run machine start 29696=⟨some 106,215339,26409387504757129547933024278⟩ := by
  rw [show 29696=29568+128 by decide,run_shift,ground29568]
  decide +kernel
private theorem ground29824 : Rays.run machine start 29824=⟨some 182,3612795863038,1574122160956688496347⟩ := by
  rw [show 29824=29696+128 by decide,run_shift,ground29696]
  decide +kernel
private theorem ground29952 : Rays.run machine start 29952=⟨some 111,861357,6602346876189000912007593957⟩ := by
  rw [show 29952=29824+128 by decide,run_shift,ground29824]
  decide +kernel
private theorem ground30080 : Rays.run machine start 30080=⟨some 158,225799749632,25185954575306394098536⟩ := by
  rw [show 30080=29952+128 by decide,run_shift,ground29952]
  decide +kernel
private theorem ground30208 : Rays.run machine start 30208=⟨some 164,903199031295,6296488643826598524635⟩ := by
  rw [show 30208=30080+128 by decide,run_shift,ground30080]
  decide +kernel
private theorem ground30336 : Rays.run machine start 30336=⟨some 164,55126892,103161669940454990219247615⟩ := by
  rw [show 30336=30208+128 by decide,run_shift,ground30208]
  decide +kernel
private theorem ground30464 : Rays.run machine start 30464=⟨some 190,63556979845389865266369877,89478485⟩ := by
  rw [show 30464=30336+128 by decide,run_shift,ground30336]
  decide +kernel
private theorem ground30592 : Rays.run machine start 30592=⟨some 160,3528121216,12895208742556251842337791⟩ := by
  rw [show 30592=30464+128 by decide,run_shift,ground30464]
  decide +kernel
private theorem ground30720 : Rays.run machine start 30720=⟨some 169,861357,52818775009510407546213498885⟩ := by
  rw [show 30720=30592+128 by decide,run_shift,ground30592]
  decide +kernel
private theorem ground30848 : Rays.run machine start 30848=⟨some 166,0,3544607988759832646603556148099715776⟩ := by
  rw [show 30848=30720+128 by decide,run_shift,ground30720]
  decide +kernel
private theorem ground30976 : Rays.run machine start 30976=⟨some 164,13781722,3301173438094330102894297086⟩ := by
  rw [show 30976=30848+128 by decide,run_shift,ground30848]
  decide +kernel
private theorem ground31104 : Rays.run machine start 31104=⟨some 191,236768185385203437,192153584101144251⟩ := by
  rw [show 31104=30976+128 by decide,run_shift,ground30976]
  decide +kernel
private theorem ground31232 : Rays.run machine start 31232=⟨some 169,841,54086425609738657327322622856916⟩ := by
  rw [show 31232=31104+128 by decide,run_shift,ground31104]
  decide +kernel
private theorem ground31360 : Rays.run machine start 31360=⟨some 164,225799438335,201487636602441435036527⟩ := by
  rw [show 31360=31232+128 by decide,run_shift,ground31232]
  decide +kernel
private theorem ground31488 : Rays.run machine start 31488=⟨some 164,13781699,3301173438094400471604920319⟩ := by
  rw [show 31488=31360+128 by decide,run_shift,ground31360]
  decide +kernel
private theorem ground31616 : Rays.run machine start 31616=⟨some 160,55126816,825293359523600117904834559⟩ := by
  rw [show 31616=31488+128 by decide,run_shift,ground31488]
  decide +kernel
private theorem ground31744 : Rays.run machine start 31744=⟨some 95,3364,13521606402434664331751735689525⟩ := by
  rw [show 31744=31616+128 by decide,run_shift,ground31616]
  decide +kernel
private theorem ground31872 : Rays.run machine start 31872=⟨some 172,56449867775,805950546409765740141439⟩ := by
  rw [show 31872=31744+128 by decide,run_shift,ground31744]
  decide +kernel
private theorem ground32000 : Rays.run machine start 32000=⟨some 185,55126819,825293359523600083545096191⟩ := by
  rw [show 32000=31872+128 by decide,run_shift,ground31872]
  decide +kernel
private theorem ground32128 : Rays.run machine start 32128=⟨some 176,3972306016161612362069674,91625968981⟩ := by
  rw [show 32128=32000+128 by decide,run_shift,ground32000]
  decide +kernel
private theorem ground32256 : Rays.run machine start 32256=⟨some 50,55126832,6602346876188721353199517698⟩ := by
  rw [show 32256=32128+128 by decide,run_shift,ground32128]
  decide +kernel
private theorem ground32384 : Rays.run machine start 32384=⟨some 169,3364,108172851219476010650821971671861⟩ := by
  rw [show 32384=32256+128 by decide,run_shift,ground32256]
  decide +kernel
private theorem ground32512 : Rays.run machine start 32512=⟨some 169,3612792324095,100743818301218966199149⟩ := by
  rw [show 32512=32384+128 by decide,run_shift,ground32384]
  decide +kernel
private theorem ground32640 : Rays.run machine start 32640=⟨some 185,969801519767560764907,375299968947540⟩ := by
  rw [show 32640=32512+128 by decide,run_shift,ground32512]
  decide +kernel
private theorem ground32768 : Rays.run machine start 32768=⟨some 181,14451168772094,201487636602438476035803⟩ := by
  rw [show 32768=32640+128 by decide,run_shift,ground32640]
  decide +kernel
private theorem ground32896 : Rays.run machine start 32896=⟨some 189,0,56713727820156489460996812560292717744⟩ := by
  rw [show 32896=32768+128 by decide,run_shift,ground32768]
  decide +kernel
private theorem ground33024 : Rays.run machine start 33024=⟨some 164,882029055,3301173438094351991370604543⟩ := by
  rw [show 33024=32896+128 by decide,run_shift,ground32896]
  decide +kernel
private theorem ground33152 : Rays.run machine start 33152=⟨some 189,215339,13521606402434465756649701244912⟩ := by
  rw [show 33152=33024+128 by decide,run_shift,ground33024]
  decide +kernel
private theorem ground33280 : Rays.run machine start 33280=⟨some 160,220507392,13204693752377407965482418175⟩ := by
  rw [show 33280=33152+128 by decide,run_shift,ground33152]
  decide +kernel
private theorem ground33408 : Rays.run machine start 33408=⟨some 95,3364,865382809755805808425854683840693⟩ := by
  rw [show 33408=33280+128 by decide,run_shift,ground33280]
  decide +kernel
private theorem ground33536 : Rays.run machine start 33536=⟨some 184,56449908735,51580834970224249865165695⟩ := by
  rw [show 33536=33408+128 by decide,run_shift,ground33408]
  decide +kernel
private theorem ground33664 : Rays.run machine start 33664=⟨some 91,210,13846124956092883711441655266528082⟩ := by
  rw [show 33664=33536+128 by decide,run_shift,ground33536]
  decide +kernel
private theorem ground33792 : Rays.run machine start 33792=⟨some 160,220507520,13204693752377402875792785407⟩ := by
  rw [show 33792=33664+128 by decide,run_shift,ground33664]
  decide +kernel
private theorem ground33911 : Rays.run machine start 33911=⟨some 13,1,1772303994379889612529569458207697189⟩ := by
  rw [show 33911=33792+119 by decide,run_shift,ground33792]
  decide +kernel

/-- Ground startup endpoint in the original ray model, checked by kernel reduction. -/
theorem ground_boot : Rays.run machine start 33911 = ⟨some 13,1,1772303994379889612529569458207697189⟩ := ground33911

/-- The literal initialized frame is reached at its exact binary time in every PA model. -/
theorem model_boot {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    rawRun machine start (33911:V)=pack 13 1 1772303994379889612529569458207697189 := by
  rw [show (33911:V)=((33911:Nat):V) by norm_num,run_standard,ground_boot]
  simp [stdPack,LiteralTM.control]
end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.model_boot
