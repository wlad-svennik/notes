module
public import ModelCommandAtoms
public import ModelIntervals
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandClear (f n t s c u v y d w : V) : Reach (config ((3087:Nat):V) f (vector n t s c u v 0 0 w)) (config ((0:Nat):V) f (vector n t s c u 0 0 0 w)) := by
  have micro := site3087 f n t s c u v 0 0 w
  exact micro

end PA192.ModelSearch.RegisterSource.Commands
