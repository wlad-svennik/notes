module
public import ModelWords
public import ModelTrace

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000

noncomputable def fpack (q d a b : V) := ⟪q,⟪d,⟪a,b⟫⟫⟫
noncomputable def fq (c : V) := π₁ c
noncomputable def fd (c : V) := π₁ (π₂ c)
noncomputable def ff (c : V) := π₁ (π₂ (π₂ c))
noncomputable def fb (c : V) := π₂ (π₂ (π₂ c))
@[simp] theorem fq_pack (q d a b : V) : fq (fpack q d a b)=q := by simp [fpack,fq]
@[simp] theorem fd_pack (q d a b : V) : fd (fpack q d a b)=d := by simp [fpack,fd]
@[simp] theorem ff_pack (q d a b : V) : ff (fpack q d a b)=a := by simp [fpack,ff]
@[simp] theorem fb_pack (q d a b : V) : fb (fpack q d a b)=b := by simp [fpack,fb]
@[simp] theorem fpack_parts (c : V) : fpack (fq c) (fd c) (ff c) (fb c)=c := by
  simp [fpack,fq,fd,ff,fb]
instance fpackDef : Language.DefinableFunction₄ ℒₒᵣ (fpack : V→V→V→V→V) := by unfold fpack; definability
instance fqDef : Language.DefinableFunction₁ ℒₒᵣ (fq : V→V) := by unfold fq; definability
instance fdDef : Language.DefinableFunction₁ ℒₒᵣ (fd : V→V) := by unfold fd; definability
instance ffDef : Language.DefinableFunction₁ ℒₒᵣ (ff : V→V) := by unfold ff; definability
instance fbDef : Language.DefinableFunction₁ ℒₒᵣ (fb : V→V) := by unfold fb; definability

noncomputable def normF (c : V) := if fd c=0 then c else
  fpack (fq c) 0 (pushW (headW (ff c)) (fb c)) (tailW (ff c))
instance normFDef : Language.DefinableFunction₁ ℒₒᵣ (normF : V→V) :=
  unary_ite _ _ _ (by definability) (by definability) (by definability)

noncomputable def project (c : V) := if fd c=0 then
  pack (fq c) (payload (fb c)) (payload (ff c)) else
  pack (fq c) (payload (tailW (ff c))) (2*payload (fb c)+headW (ff c))
instance projectDef : Language.DefinableFunction₁ ℒₒᵣ (project : V→V) :=
  unary_ite _ _ _ (by definability) (by definability) (by definability)

noncomputable def fAction (a : Instruction n) (c : V) : V :=
  let q : V := PA192.LiteralTM.control a.next
  let w : V := a.write.toNat
  match a.move with
  | .right =>
    if fd c=0 then fpack q 0 (tailW (ff c)) (pushW w (fb c))
    else fpack q 0 (fb c) (pushW w (tailW (ff c)))
  | .left =>
    if fd c=0 then fpack q 1 (fb c) (pushW w (tailW (ff c)))
    else fpack q 1 (tailW (ff c)) (pushW w (fb c))

instance fActionDef (a : Instruction n) : Language.DefinableFunction₁ ℒₒᵣ (fAction a : V→V) := by
  rcases a with ⟨w,d,q⟩
  cases d <;> exact unary_ite _ _ _ (by definability) (by dsimp only [fpack]; definability) (by dsimp only [fpack]; definability)

noncomputable def fswitch (m : Machine n) (q : Fin n) (c : V) :=
  if headW (ff c)=1 then fAction (m q true) c else fAction (m q false) c
noncomputable def fstep (m : Machine n) (c : V) :=
  pick (List.finRange n) (fq c) c (fun q => fswitch m q c)
instance fstepDef (m : Machine n) : Language.DefinableFunction₁ ℒₒᵣ (fstep m : V→V) := by
  apply pick_def
  · infer_instance
  · definability
  · intro q; exact unary_ite _ _ _ (by definability) (fActionDef _) (fActionDef _)

theorem fswitch_bit (m : Machine n) (q : Fin n) (b : Bool) (c : V)
    (hb : headW (ff c)=(b.toNat : V)) : fswitch m q c=fAction (m q b) c := by
  cases b <;> simp [fswitch,hb]
theorem table_row (m : Machine n) (q : Fin n) (b : Bool) (d a z : V)
    (read : headW a=(b.toNat:V)) :
    fstep m (fpack (q.val:V) d a z)=fAction (m q b) (fpack (q.val:V) d a z) := by
  rw [fstep,fq_pack,pick_mem _ q (by simp),fswitch_bit m q b _ (by simpa using read)]
theorem table_sink (m : Machine n) (d a z : V) :
    fstep m (fpack (n : V) d a z)=fpack (n : V) d a z := by
  rw [fstep,fq_pack]; apply pick_none; intro q _; exact_mod_cast (Nat.ne_of_lt q.isLt).symm

private theorem joined_half (x s : V) : (2*x+headW s)/2=x :=
  (pair_digit _ x _ (head_digit s) rfl).1
private theorem joined_low (x s : V) : (2*x+headW s)%2=headW s :=
  (pair_digit _ x _ (head_digit s) rfl).2

theorem projected_state (c : V) : state (project c)=fq c := by
  unfold project; split <;> simp
theorem projected_read (c : V) : rightRay (project c)%2 = headW (ff c) := by
  unfold project; split <;> rw [right_pack]
  · exact payload_low _
  · exact joined_low _ _
theorem projected_norm (c : V) : project (normF c)=project c := by
  unfold normF; split
  · rfl
  · rename_i h
    simp [project,h,payload_push _ _ (head_digit _)]

theorem projected_action (a : Instruction n) (c : V) : project (fAction a c)=action a (project c) := by
  rcases a with ⟨w,d,q⟩
  have pw (x : V) : payload (pushW (w.toNat : V) x)=2*payload x+(w.toNat : V) :=
    payload_push _ _ (bool_num w)
  cases d <;> by_cases ori : fd c=0 <;>
    simp [fAction,project,action,nextL,nextR,ori,pw,payload_half,payload_low,joined_half,joined_low]

theorem pick_map (qs : List (Fin n)) (k df : V) (f : Fin n→V) (g : V→V) :
    g (pick qs k df f)=pick qs k (g df) (fun q => g (f q)) := by
  induction qs with
  | nil => rfl
  | cons q qs ih => by_cases h : k=(q.val : V) <;> simp [pick,h,ih]

theorem projected_switch (m : Machine n) (q : Fin n) (c : V) :
    project (fswitch m q c)=switch m q (project c) := by
  rw [fswitch,switch,projected_read]; split <;> exact projected_action _ _

theorem projected_step (m : Machine n) (c : V) :
    project (fstep m c)=rawStep m (project c) := by
  rw [fstep,pick_map (List.finRange n) (fq c) c (fun q => fswitch m q c) project,rawStep,projected_state]
  apply congrArg (pick _ _ _); funext q; exact projected_switch _ _ _

/-- Nonstandard time, arbitrary finite-code rays, and arbitrary orientation. -/
theorem projected_run (m : Machine n) (c : V) :
    ∀ t : V, project (iterate (fstep m) t c)=iterate (rawStep m) t (project c) := by
  apply modelInduct
  · definability
  · simp
  · intro t ih; rw [iterate_succ,iterate_succ,projected_step,ih]

noncomputable def operations (m : Machine n) : Operations V where
  u
    | .bit0 => pushW 0 | .bit1 => pushW 1
    | .step => fstep m | .norm => normF | .state => fq
  b
    | .pair => pair | .run => iterate (fstep m) | .repeatWord w => repeatW w

theorem operations_defined (m : Machine n) : Defined (operations (V:=V) m) := by
  constructor
  · intro f; cases f <;> simp only [operations] <;> first | infer_instance | definability
  · intro f; cases f <;> simp only [operations] <;> infer_instance

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.projected_run
#print axioms PA192.PhysicalModel.operations_defined
