module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire1056 : String := include_str ".."/"data"/"FrozenSite1056.wire"
private def indices1056 : String := include_str ".."/"data"/"FrozenSite1056.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision1056 : (checkPayload 1056 48 wire1056 indices1056).isSome=true := by decide +native

theorem scope1056 : Scope 1056 48 := payload_sound _ _ _ _ decision1056
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope1056
