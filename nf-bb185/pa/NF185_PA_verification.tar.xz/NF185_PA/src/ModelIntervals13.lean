module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site2522Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2522 f r x y z) (slots267.atReg 2530 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2522 8 2530 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2522 2530 2523 f r row2522)
    (slots267.pos_x 2522 2530 2523 f r row2522)
    (slots267.inc_z 2523 2524 f r row2523 (Or.inl (by decide)))
    (slots267.zero_y 2524 2526 2525 f r row2524)
    (slots267.pos_y 2524 2526 2525 f r row2524)
    (slots267.jump 2525 2529 f r row2525)
    (slots267.zero_z 2526 2529 2527 f r row2526)
    (slots267.pos_z 2526 2529 2527 f r row2526)
    (slots267.inc_y 2527 2528 f r row2527 (Or.inl (by decide)))
    (slots267.jump 2528 2526 f r row2528)
    (slots267.jump 2529 2522 f r row2529)

theorem site2522 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2522:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2530:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2522Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2530Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2530 f r x y z) (slots720.atReg 2533 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2530 3 2533 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2530 2533 2531 f r row2530)
    (slots720.pos_x 2530 2533 2531 f r row2530)
    (slots720.inc_y 2531 2532 f r row2531 (Or.inl (by decide)))
    (slots720.jump 2532 2530 f r row2532)

theorem site2530 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2530:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2533:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2530Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2533Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2533 f r x y z) (slots617.atReg 2543 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2533 10 2543 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2533 2537 2534 f r row2533)
    (slots617.pos_y 2533 2537 2534 f r row2533)
    (slots617.inc_z 2534 2535 f r row2534 (Or.inl (by decide)))
    (slots617.inc_x 2535 2536 f r row2535 (Or.inl (by decide)))
    (slots617.jump 2536 2533 f r row2536)
    (slots617.zero_x 2537 2543 2538 f r row2537)
    (slots617.pos_x 2537 2543 2538 f r row2537)
    (slots617.inc_z 2538 2539 f r row2538 (Or.inl (by decide)))
    (slots617.zero_x 2539 2542 2540 f r row2539)
    (slots617.pos_x 2539 2542 2540 f r row2539)
    (slots617.inc_y 2540 2541 f r row2540 (Or.inl (by decide)))
    (slots617.jump 2541 2539 f r row2541)
    (slots617.jump 2542 2533 f r row2542)

theorem site2533 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2533:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2543:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2533Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2543Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2543 f r x y z) (slots710.atReg 2547 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2543 4 2547 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2543 2547 2544 f r row2543)
    (slots710.pos_x 2543 2547 2544 f r row2543)
    (slots710.inc_y 2544 2545 f r row2544 (Or.inl (by decide)))
    (slots710.inc_y 2545 2546 f r row2545 (Or.inl (by decide)))
    (slots710.jump 2546 2543 f r row2546)

theorem site2543 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2543:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2547:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2543Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2547 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2547:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2548:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2547 _ row2547]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2548Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2548 f r x y z) (slots267.atReg 2556 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2548 8 2556 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2548 2556 2549 f r row2548)
    (slots267.pos_x 2548 2556 2549 f r row2548)
    (slots267.inc_z 2549 2550 f r row2549 (Or.inl (by decide)))
    (slots267.zero_y 2550 2552 2551 f r row2550)
    (slots267.pos_y 2550 2552 2551 f r row2550)
    (slots267.jump 2551 2555 f r row2551)
    (slots267.zero_z 2552 2555 2553 f r row2552)
    (slots267.pos_z 2552 2555 2553 f r row2552)
    (slots267.inc_y 2553 2554 f r row2553 (Or.inl (by decide)))
    (slots267.jump 2554 2552 f r row2554)
    (slots267.jump 2555 2548 f r row2555)

theorem site2548 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2548:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2556:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2548Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2556Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2556 f r x y z) (slots720.atReg 2559 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2556 3 2559 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2556 2559 2557 f r row2556)
    (slots720.pos_x 2556 2559 2557 f r row2556)
    (slots720.inc_y 2557 2558 f r row2557 (Or.inl (by decide)))
    (slots720.jump 2558 2556 f r row2558)

theorem site2556 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2556:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2559:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2556Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2559Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2559 f r x y z) (slots617.atReg 2569 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2559 10 2569 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2559 2563 2560 f r row2559)
    (slots617.pos_y 2559 2563 2560 f r row2559)
    (slots617.inc_z 2560 2561 f r row2560 (Or.inl (by decide)))
    (slots617.inc_x 2561 2562 f r row2561 (Or.inl (by decide)))
    (slots617.jump 2562 2559 f r row2562)
    (slots617.zero_x 2563 2569 2564 f r row2563)
    (slots617.pos_x 2563 2569 2564 f r row2563)
    (slots617.inc_z 2564 2565 f r row2564 (Or.inl (by decide)))
    (slots617.zero_x 2565 2568 2566 f r row2565)
    (slots617.pos_x 2565 2568 2566 f r row2565)
    (slots617.inc_y 2566 2567 f r row2566 (Or.inl (by decide)))
    (slots617.jump 2567 2565 f r row2567)
    (slots617.jump 2568 2559 f r row2568)

theorem site2559 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2559:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2569:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2559Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2569Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2569 f r x y z) (slots710.atReg 2573 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2569 4 2573 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2569 2573 2570 f r row2569)
    (slots710.pos_x 2569 2573 2570 f r row2569)
    (slots710.inc_y 2570 2571 f r row2570 (Or.inl (by decide)))
    (slots710.inc_y 2571 2572 f r row2571 (Or.inl (by decide)))
    (slots710.jump 2572 2569 f r row2572)

theorem site2569 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2569:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2573:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2569Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site2573Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2573 f r x y z) (slots160.atReg 2576 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2573 3 2576 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2573 2576 2574 f r row2573)
    (slots160.pos_x 2573 2576 2574 f r row2573)
    (slots160.inc_y 2574 2575 f r row2574 (Or.inl (by decide)))
    (slots160.jump 2575 2573 f r row2575)

theorem site2573 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2573:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2576:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2573Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2576Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2576 f r x y z) (slots210.atReg 2579 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2576 3 2579 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2576 2579 2577 f r row2576)
    (slots210.pos_x 2576 2579 2577 f r row2576)
    (slots210.inc_y 2577 2578 f r row2577 (Or.inl (by decide)))
    (slots210.jump 2578 2576 f r row2578)

theorem site2576 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2576:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2579:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2576Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2579Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2579 f r x y z) (slots617.atReg 2589 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2579 10 2589 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2579 2583 2580 f r row2579)
    (slots617.pos_y 2579 2583 2580 f r row2579)
    (slots617.inc_z 2580 2581 f r row2580 (Or.inl (by decide)))
    (slots617.inc_x 2581 2582 f r row2581 (Or.inl (by decide)))
    (slots617.jump 2582 2579 f r row2582)
    (slots617.zero_x 2583 2589 2584 f r row2583)
    (slots617.pos_x 2583 2589 2584 f r row2583)
    (slots617.inc_z 2584 2585 f r row2584 (Or.inl (by decide)))
    (slots617.zero_x 2585 2588 2586 f r row2585)
    (slots617.pos_x 2585 2588 2586 f r row2585)
    (slots617.inc_y 2586 2587 f r row2586 (Or.inl (by decide)))
    (slots617.jump 2587 2585 f r row2587)
    (slots617.jump 2588 2579 f r row2588)

theorem site2579 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2579:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2589:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2579Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2589Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2589 f r x y z) (slots720.atReg 2592 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2589 3 2592 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2589 2592 2590 f r row2589)
    (slots720.pos_x 2589 2592 2590 f r row2589)
    (slots720.inc_y 2590 2591 f r row2590 (Or.inl (by decide)))
    (slots720.jump 2591 2589 f r row2591)

theorem site2589 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2589:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2592:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2589Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2592Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2592 f r x y z) (slots561.atReg 2596 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2592 4 2596 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2592 2596 2593 f r row2592)
    (slots561.pos_x 2592 2596 2593 f r row2592)
    (slots561.inc_y 2593 2594 f r row2593 (Or.inl (by decide)))
    (slots561.inc_z 2594 2595 f r row2594 (Or.inl (by decide)))
    (slots561.jump 2595 2592 f r row2595)

theorem site2592 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2592:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2596:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2592Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site2596Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2596 f r x y z) (slots650.atReg 2599 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2596 3 2599 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2596 2599 2597 f r row2596)
    (slots650.pos_x 2596 2599 2597 f r row2596)
    (slots650.inc_y 2597 2598 f r row2597 (Or.inl (by decide)))
    (slots650.jump 2598 2596 f r row2598)

theorem site2596 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2596:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2599:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2596Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site2599Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2599 f r x y z) (slots160.atReg 2602 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2599 3 2602 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2599 2602 2600 f r row2599)
    (slots160.pos_x 2599 2602 2600 f r row2599)
    (slots160.inc_y 2600 2601 f r row2600 (Or.inl (by decide)))
    (slots160.jump 2601 2599 f r row2601)

theorem site2599 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2599:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2602:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2599Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2602Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2602 f r x y z) (slots210.atReg 2605 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2602 3 2605 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2602 2605 2603 f r row2602)
    (slots210.pos_x 2602 2605 2603 f r row2602)
    (slots210.inc_y 2603 2604 f r row2603 (Or.inl (by decide)))
    (slots210.jump 2604 2602 f r row2604)

theorem site2602 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2602:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2605:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2602Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2605Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2605 f r x y z) (slots617.atReg 2615 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2605 10 2615 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2605 2609 2606 f r row2605)
    (slots617.pos_y 2605 2609 2606 f r row2605)
    (slots617.inc_z 2606 2607 f r row2606 (Or.inl (by decide)))
    (slots617.inc_x 2607 2608 f r row2607 (Or.inl (by decide)))
    (slots617.jump 2608 2605 f r row2608)
    (slots617.zero_x 2609 2615 2610 f r row2609)
    (slots617.pos_x 2609 2615 2610 f r row2609)
    (slots617.inc_z 2610 2611 f r row2610 (Or.inl (by decide)))
    (slots617.zero_x 2611 2614 2612 f r row2611)
    (slots617.pos_x 2611 2614 2612 f r row2611)
    (slots617.inc_y 2612 2613 f r row2612 (Or.inl (by decide)))
    (slots617.jump 2613 2611 f r row2613)
    (slots617.jump 2614 2605 f r row2614)

theorem site2605 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2605:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2615:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2605Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2615Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2615 f r x y z) (slots720.atReg 2618 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2615 3 2618 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2615 2618 2616 f r row2615)
    (slots720.pos_x 2615 2618 2616 f r row2615)
    (slots720.inc_y 2616 2617 f r row2616 (Or.inl (by decide)))
    (slots720.jump 2617 2615 f r row2617)

theorem site2615 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2615:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2618:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2615Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2618Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2618 f r x y z) (slots461.atReg 2622 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2618 4 2622 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2618 2622 2619 f r row2618)
    (slots461.pos_x 2618 2622 2619 f r row2618)
    (slots461.inc_y 2619 2620 f r row2619 (Or.inl (by decide)))
    (slots461.inc_z 2620 2621 f r row2620 (Or.inl (by decide)))
    (slots461.jump 2621 2618 f r row2621)

theorem site2618 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2618:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2622:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2618Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site2622Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2622 f r x y z) (slots640.atReg 2625 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2622 3 2625 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2622 2625 2623 f r row2622)
    (slots640.pos_x 2622 2625 2623 f r row2622)
    (slots640.inc_y 2623 2624 f r row2623 (Or.inl (by decide)))
    (slots640.jump 2624 2622 f r row2624)

theorem site2622 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2622:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2625:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2622Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site2625Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2625 f r x y z) (slots160.atReg 2628 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2625 3 2628 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2625 2628 2626 f r row2625)
    (slots160.pos_x 2625 2628 2626 f r row2625)
    (slots160.inc_y 2626 2627 f r row2626 (Or.inl (by decide)))
    (slots160.jump 2627 2625 f r row2627)

theorem site2625 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2625:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2628:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2625Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2628Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2628 f r x y z) (slots210.atReg 2631 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2628 3 2631 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2628 2631 2629 f r row2628)
    (slots210.pos_x 2628 2631 2629 f r row2628)
    (slots210.inc_y 2629 2630 f r row2629 (Or.inl (by decide)))
    (slots210.jump 2630 2628 f r row2630)

theorem site2628 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2628:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2631:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2628Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2631Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2631 f r x y z) (slots617.atReg 2641 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2631 10 2641 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2631 2635 2632 f r row2631)
    (slots617.pos_y 2631 2635 2632 f r row2631)
    (slots617.inc_z 2632 2633 f r row2632 (Or.inl (by decide)))
    (slots617.inc_x 2633 2634 f r row2633 (Or.inl (by decide)))
    (slots617.jump 2634 2631 f r row2634)
    (slots617.zero_x 2635 2641 2636 f r row2635)
    (slots617.pos_x 2635 2641 2636 f r row2635)
    (slots617.inc_z 2636 2637 f r row2636 (Or.inl (by decide)))
    (slots617.zero_x 2637 2640 2638 f r row2637)
    (slots617.pos_x 2637 2640 2638 f r row2637)
    (slots617.inc_y 2638 2639 f r row2638 (Or.inl (by decide)))
    (slots617.jump 2639 2637 f r row2639)
    (slots617.jump 2640 2631 f r row2640)

theorem site2631 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2631:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2641:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2631Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2641Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2641 f r x y z) (slots720.atReg 2644 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2641 3 2644 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2641 2644 2642 f r row2641)
    (slots720.pos_x 2641 2644 2642 f r row2641)
    (slots720.inc_y 2642 2643 f r row2642 (Or.inl (by decide)))
    (slots720.jump 2643 2641 f r row2643)

theorem site2641 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2641:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2644:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2641Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2644Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2644 f r x y z) (slots561.atReg 2648 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2644 4 2648 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2644 2648 2645 f r row2644)
    (slots561.pos_x 2644 2648 2645 f r row2644)
    (slots561.inc_y 2645 2646 f r row2645 (Or.inl (by decide)))
    (slots561.inc_z 2646 2647 f r row2646 (Or.inl (by decide)))
    (slots561.jump 2647 2644 f r row2647)

theorem site2644 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2644:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2648:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2644Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site2648Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2648 f r x y z) (slots650.atReg 2651 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2648 3 2651 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2648 2651 2649 f r row2648)
    (slots650.pos_x 2648 2651 2649 f r row2648)
    (slots650.inc_y 2649 2650 f r row2649 (Or.inl (by decide)))
    (slots650.jump 2650 2648 f r row2650)

theorem site2648 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2648:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2651:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2648Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site2651Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2651 f r x y z) (slots267.atReg 2659 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2651 8 2659 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2651 2659 2652 f r row2651)
    (slots267.pos_x 2651 2659 2652 f r row2651)
    (slots267.inc_z 2652 2653 f r row2652 (Or.inl (by decide)))
    (slots267.zero_y 2653 2655 2654 f r row2653)
    (slots267.pos_y 2653 2655 2654 f r row2653)
    (slots267.jump 2654 2658 f r row2654)
    (slots267.zero_z 2655 2658 2656 f r row2655)
    (slots267.pos_z 2655 2658 2656 f r row2655)
    (slots267.inc_y 2656 2657 f r row2656 (Or.inl (by decide)))
    (slots267.jump 2657 2655 f r row2657)
    (slots267.jump 2658 2651 f r row2658)

theorem site2651 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2651:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2659:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2651Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2659Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2659 f r x y z) (slots720.atReg 2662 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2659 3 2662 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2659 2662 2660 f r row2659)
    (slots720.pos_x 2659 2662 2660 f r row2659)
    (slots720.inc_y 2660 2661 f r row2660 (Or.inl (by decide)))
    (slots720.jump 2661 2659 f r row2661)

theorem site2659 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2659:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2662:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2659Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2662Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2662 f r x y z) (slots617.atReg 2672 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2662 10 2672 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2662 2666 2663 f r row2662)
    (slots617.pos_y 2662 2666 2663 f r row2662)
    (slots617.inc_z 2663 2664 f r row2663 (Or.inl (by decide)))
    (slots617.inc_x 2664 2665 f r row2664 (Or.inl (by decide)))
    (slots617.jump 2665 2662 f r row2665)
    (slots617.zero_x 2666 2672 2667 f r row2666)
    (slots617.pos_x 2666 2672 2667 f r row2666)
    (slots617.inc_z 2667 2668 f r row2667 (Or.inl (by decide)))
    (slots617.zero_x 2668 2671 2669 f r row2668)
    (slots617.pos_x 2668 2671 2669 f r row2668)
    (slots617.inc_y 2669 2670 f r row2669 (Or.inl (by decide)))
    (slots617.jump 2670 2668 f r row2670)
    (slots617.jump 2671 2662 f r row2671)

theorem site2662 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2662:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2672:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2662Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2672Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2672 f r x y z) (slots710.atReg 2676 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2672 4 2676 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2672 2676 2673 f r row2672)
    (slots710.pos_x 2672 2676 2673 f r row2672)
    (slots710.inc_y 2673 2674 f r row2673 (Or.inl (by decide)))
    (slots710.inc_y 2674 2675 f r row2674 (Or.inl (by decide)))
    (slots710.jump 2675 2672 f r row2675)

theorem site2672 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2672:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2676:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2672Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2676 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2676:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2677:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2676 _ row2676]
  simp [perform,chooseZero,vector,readReg,writeReg]

theorem site2677 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2677:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2678:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2677 _ row2677]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2678Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2678 f r x y z) (slots267.atReg 2686 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2678 8 2686 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2678 2686 2679 f r row2678)
    (slots267.pos_x 2678 2686 2679 f r row2678)
    (slots267.inc_z 2679 2680 f r row2679 (Or.inl (by decide)))
    (slots267.zero_y 2680 2682 2681 f r row2680)
    (slots267.pos_y 2680 2682 2681 f r row2680)
    (slots267.jump 2681 2685 f r row2681)
    (slots267.zero_z 2682 2685 2683 f r row2682)
    (slots267.pos_z 2682 2685 2683 f r row2682)
    (slots267.inc_y 2683 2684 f r row2683 (Or.inl (by decide)))
    (slots267.jump 2684 2682 f r row2684)
    (slots267.jump 2685 2678 f r row2685)

theorem site2678 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2678:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2686:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2678Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site2686Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2686 f r x y z) (slots720.atReg 2689 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2686 3 2689 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2686 2689 2687 f r row2686)
    (slots720.pos_x 2686 2689 2687 f r row2686)
    (slots720.inc_y 2687 2688 f r row2687 (Or.inl (by decide)))
    (slots720.jump 2688 2686 f r row2688)

theorem site2686 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2686:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2689:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2686Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site2689Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2689 f r x y z) (slots617.atReg 2699 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2689 10 2699 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2689 2693 2690 f r row2689)
    (slots617.pos_y 2689 2693 2690 f r row2689)
    (slots617.inc_z 2690 2691 f r row2690 (Or.inl (by decide)))
    (slots617.inc_x 2691 2692 f r row2691 (Or.inl (by decide)))
    (slots617.jump 2692 2689 f r row2692)
    (slots617.zero_x 2693 2699 2694 f r row2693)
    (slots617.pos_x 2693 2699 2694 f r row2693)
    (slots617.inc_z 2694 2695 f r row2694 (Or.inl (by decide)))
    (slots617.zero_x 2695 2698 2696 f r row2695)
    (slots617.pos_x 2695 2698 2696 f r row2695)
    (slots617.inc_y 2696 2697 f r row2696 (Or.inl (by decide)))
    (slots617.jump 2697 2695 f r row2697)
    (slots617.jump 2698 2689 f r row2698)

theorem site2689 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2689:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2699:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2689Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site2699Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2699 f r x y z) (slots710.atReg 2703 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2699 4 2703 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2699 2703 2700 f r row2699)
    (slots710.pos_x 2699 2703 2700 f r row2699)
    (slots710.inc_y 2700 2701 f r row2700 (Or.inl (by decide)))
    (slots710.inc_y 2701 2702 f r row2701 (Or.inl (by decide)))
    (slots710.jump 2702 2699 f r row2702)

theorem site2699 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2699:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2703:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2699Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site2703 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2703:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2704:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2703 _ row2703]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site2704Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2704 f r x y z) (slots160.atReg 2707 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2704 3 2707 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2704 2707 2705 f r row2704)
    (slots160.pos_x 2704 2707 2705 f r row2704)
    (slots160.inc_y 2705 2706 f r row2705 (Or.inl (by decide)))
    (slots160.jump 2706 2704 f r row2706)

theorem site2704 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2704:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2707:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2704Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site2707Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2707 f r x y z) (slots210.atReg 2710 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2707 3 2710 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2707 2710 2708 f r row2707)
    (slots210.pos_x 2707 2710 2708 f r row2707)
    (slots210.inc_y 2708 2709 f r row2708 (Or.inl (by decide)))
    (slots210.jump 2709 2707 f r row2709)

theorem site2707 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2707:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2710:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2707Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site2710Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2710 f r x y z) (slots617.atReg 2720 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2710 10 2720 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2710 2714 2711 f r row2710)
    (slots617.pos_y 2710 2714 2711 f r row2710)
    (slots617.inc_z 2711 2712 f r row2711 (Or.inl (by decide)))
    (slots617.inc_x 2712 2713 f r row2712 (Or.inl (by decide)))
    (slots617.jump 2713 2710 f r row2713)
    (slots617.zero_x 2714 2720 2715 f r row2714)
    (slots617.pos_x 2714 2720 2715 f r row2714)
    (slots617.inc_z 2715 2716 f r row2715 (Or.inl (by decide)))
    (slots617.zero_x 2716 2719 2717 f r row2716)
    (slots617.pos_x 2716 2719 2717 f r row2716)
    (slots617.inc_y 2717 2718 f r row2717 (Or.inl (by decide)))
    (slots617.jump 2718 2716 f r row2718)
    (slots617.jump 2719 2710 f r row2719)

theorem site2710 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2710:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2720:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2710Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

end PA192.ModelSearch.RegisterSource.Certified
