module
public import ModelRegisterChart
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem Reach.endAt {a b c : V} (h : Reach a b) (e : b=c) : Reach a c := e ▸ h

theorem vectorEq (pc f : V) {a0 a1 a2 a3 a4 a5 a6 a7 a8 b0 b1 b2 b3 b4 b5 b6 b7 b8 : V}
    (h0:a0=b0) (h1:a1=b1) (h2:a2=b2) (h3:a3=b3) (h4:a4=b4) (h5:a5=b5) (h6:a6=b6) (h7:a7=b7) (h8:a8=b8) :
    config pc f (vector a0 a1 a2 a3 a4 a5 a6 a7 a8)=config pc f (vector b0 b1 b2 b3 b4 b5 b6 b7 b8) := by
  subst_vars; rfl

noncomputable def atom0 (n t s c u v y d w : V) : V := cantor d w
noncomputable def atom1 (n t s c u v y d w : V) : V := cantor y (atom0 n t s c u v y d w)
noncomputable def atom2 (n t s c u v y d w : V) : V := cantor t s
noncomputable def atom3 (n t s c u v y d w : V) : V := cantor c (atom2 n t s c u v y d w)
noncomputable def atom4 (n t s c u v y d w : V) : V := cantor c u
noncomputable def atom5 (n t s c u v y d w : V) : V := cantor ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (atom2 n t s c u v y d w)
noncomputable def atom6 (n t s c u v y d w : V) : V := cantor ((atom4 n t s c u v y d w)+(atom4 n t s c u v y d w)) (d+u)
noncomputable def atom7 (n t s c u v y d w : V) : V := cantor ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) (atom2 n t s c u v y d w)
noncomputable def atom8 (n t s c u v y d w : V) : V := cantor (d+u) (atom7 n t s c u v y d w)
noncomputable def atom9 (n t s c u v y d w : V) : V := cantor (d+u) c
noncomputable def atom10 (n t s c u v y d w : V) : V := cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom7 n t s c u v y d w)
noncomputable def atom11 (n t s c u v y d w : V) : V := cantor (v+y) (atom10 n t s c u v y d w)
noncomputable def atom12 (n t s c u v y d w : V) : V := cantor (v+y) c
noncomputable def atom13 (n t s c u v y d w : V) : V := cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) ((atom12 n t s c u v y d w)+(atom12 n t s c u v y d w))
noncomputable def atom14 (n t s c u v y d w : V) : V := cantor ((atom6 n t s c u v y d w)+(atom6 n t s c u v y d w)) ((atom13 n t s c u v y d w)+(atom13 n t s c u v y d w))
noncomputable def atom15 (n t s c u v y d w : V) : V := cantor ((atom14 n t s c u v y d w)+(atom14 n t s c u v y d w)) (atom2 n t s c u v y d w)
noncomputable def atom16 (n t s c u v y d w : V) : V := cantor (d+u) (atom15 n t s c u v y d w)
noncomputable def atom17 (n t s c u v y d w : V) : V := cantor (d+u) (v+y)
noncomputable def atom18 (n t s c u v y d w : V) : V := cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom15 n t s c u v y d w)
noncomputable def atom19 (n t s c u v y d w : V) : V := cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (v+y)
noncomputable def atom20 (n t s c u v y d w : V) : V := cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom15 n t s c u v y d w)
noncomputable def atom21 (n t s c u v y d w : V) : V := cantor 1 (atom20 n t s c u v y d w)
noncomputable def atom22 (n t s c u v y d w : V) : V := cantor 0 (atom21 n t s c u v y d w)
noncomputable def atom23 (n t s c u v y d w : V) : V := cantor 0 (d+u)
noncomputable def atom24 (n t s c u v y d w : V) : V := cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom21 n t s c u v y d w)
noncomputable def atom25 (n t s c u v y d w : V) : V := cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (v+y)
noncomputable def atom26 (n t s c u v y d w : V) : V := cantor 1 ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1)
noncomputable def atom27 (n t s c u v y d w : V) : V := cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) ((atom26 n t s c u v y d w)+(atom26 n t s c u v y d w)+1)
noncomputable def atom28 (n t s c u v y d w : V) : V := cantor ((atom27 n t s c u v y d w)+(atom27 n t s c u v y d w)) (atom15 n t s c u v y d w)
noncomputable def atom29 (n t s c u v y d w : V) : V := cantor c (atom28 n t s c u v y d w)
noncomputable def atom30 (n t s c u v y d w : V) : V := cantor c (v+y)
noncomputable def atom31 (n t s c u v y d w : V) : V := cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom28 n t s c u v y d w)
noncomputable def atom32 (n t s c u v y d w : V) : V := cantor (d+u) (atom31 n t s c u v y d w)
noncomputable def atom33 (n t s c u v y d w : V) : V := cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom31 n t s c u v y d w)
noncomputable def atom34 (n t s c u v y d w : V) : V := cantor (d+u) (atom33 n t s c u v y d w)
noncomputable def atom35 (n t s c u v y d w : V) : V := cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)
noncomputable def atom36 (n t s c u v y d w : V) : V := cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) ((atom35 n t s c u v y d w)+(atom35 n t s c u v y d w)+1)
noncomputable def atom37 (n t s c u v y d w : V) : V := cantor ((atom36 n t s c u v y d w)+(atom36 n t s c u v y d w)) (atom28 n t s c u v y d w)
noncomputable def atom38 (n t s c u v y d w : V) : V := cantor (v+y) (atom37 n t s c u v y d w)
noncomputable def atom39 (n t s c u v y d w : V) : V := cantor (v+y) (v+y)
noncomputable def atom40 (n t s c u v y d w : V) : V := cantor ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom37 n t s c u v y d w)
noncomputable def atom41 (n t s c u v y d w : V) : V := cantor ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (d+u)
noncomputable def atom42 (n t s c u v y d w : V) : V := cantor ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (atom37 n t s c u v y d w)
noncomputable def atom43 (n t s c u v y d w : V) : V := cantor ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (v+y)
noncomputable def atom44 (n t s c u v y d w : V) : V := cantor ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1) (atom37 n t s c u v y d w)
noncomputable def atom45 (n t s c u v y d w : V) : V := cantor (d+u) (atom44 n t s c u v y d w)
noncomputable def atom46 (n t s c u v y d w : V) : V := cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom44 n t s c u v y d w)
noncomputable def atom47 (n t s c u v y d w : V) : V := cantor c (atom46 n t s c u v y d w)
noncomputable def atom48 (n t s c u v y d w : V) : V := cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom46 n t s c u v y d w)
noncomputable def atom49 (n t s c u v y d w : V) : V := cantor (d+u) (atom48 n t s c u v y d w)
noncomputable def atom50 (n t s c u v y d w : V) : V := cantor ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)
noncomputable def atom51 (n t s c u v y d w : V) : V := cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) ((atom50 n t s c u v y d w)+(atom50 n t s c u v y d w)+1)
noncomputable def atom52 (n t s c u v y d w : V) : V := cantor ((atom51 n t s c u v y d w)+(atom51 n t s c u v y d w)) (atom44 n t s c u v y d w)
noncomputable def atom53 (n t s c u v y d w : V) : V := cantor 3 (atom52 n t s c u v y d w)
noncomputable def atom54 (n t s c u v y d w : V) : V := cantor 3 c
noncomputable def atom55 (n t s c u v y d w : V) : V := cantor ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (atom52 n t s c u v y d w)
noncomputable def atom56 (n t s c u v y d w : V) : V := cantor ((atom54 n t s c u v y d w)+(atom54 n t s c u v y d w)+1) (d+u)
noncomputable def atom57 (n t s c u v y d w : V) : V := cantor ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (atom52 n t s c u v y d w)
noncomputable def atom58 (n t s c u v y d w : V) : V := cantor ((atom56 n t s c u v y d w)+(atom56 n t s c u v y d w)+1) (v+y)
noncomputable def atom59 (n t s c u v y d w : V) : V := cantor ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) (atom52 n t s c u v y d w)
noncomputable def atom60 (n t s c u v y d w : V) : V := cantor c (atom59 n t s c u v y d w)
noncomputable def atom61 (n t s c u v y d w : V) : V := cantor (v+y) (atom60 n t s c u v y d w)
noncomputable def atom62 (n t s c u v y d w : V) : V := cantor c ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2)
noncomputable def atom63 (n t s c u v y d w : V) : V := cantor ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) (atom59 n t s c u v y d w)
noncomputable def atom64 (n t s c u v y d w : V) : V := cantor (d+u) (atom63 n t s c u v y d w)
noncomputable def atom65 (n t s c u v y d w : V) : V := cantor ((atom62 n t s c u v y d w)+(atom62 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)
noncomputable def atom66 (n t s c u v y d w : V) : V := cantor ((atom58 n t s c u v y d w)+(atom58 n t s c u v y d w)+1) ((atom65 n t s c u v y d w)+(atom65 n t s c u v y d w)+1)
noncomputable def atom67 (n t s c u v y d w : V) : V := cantor ((atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1) (atom52 n t s c u v y d w)
noncomputable def atom68 (n t s c u v y d w : V) : V := cantor (d+u) (atom67 n t s c u v y d w)
noncomputable def atom69 (n t s c u v y d w : V) : V := cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom67 n t s c u v y d w)
noncomputable def atom70 (n t s c u v y d w : V) : V := cantor (d+u) (atom69 n t s c u v y d w)
noncomputable def atom71 (n t s c u v y d w : V) : V := cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom69 n t s c u v y d w)
noncomputable def atom72 (n t s c u v y d w : V) : V := cantor c (atom71 n t s c u v y d w)
noncomputable def atom73 (n t s c u v y d w : V) : V := cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1)
noncomputable def atom74 (n t s c u v y d w : V) : V := cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) ((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w))
noncomputable def atom75 (n t s c u v y d w : V) : V := cantor ((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)) (atom67 n t s c u v y d w)
noncomputable def atom76 (n t s c u v y d w : V) : V := cantor (d+u) (atom75 n t s c u v y d w)
noncomputable def atom77 (n t s c u v y d w : V) : V := cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom75 n t s c u v y d w)
noncomputable def atom78 (n t s c u v y d w : V) : V := cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) (atom75 n t s c u v y d w)
noncomputable def atom79 (n t s c u v y d w : V) : V := cantor ((atom19 n t s c u v y d w)+(atom19 n t s c u v y d w)+1) 3
noncomputable def atom80 (n t s c u v y d w : V) : V := cantor ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) (atom75 n t s c u v y d w)
noncomputable def atom81 (n t s c u v y d w : V) : V := cantor 3 (atom80 n t s c u v y d w)
noncomputable def atom82 (n t s c u v y d w : V) : V := cantor 0 (atom81 n t s c u v y d w)
noncomputable def atom83 (n t s c u v y d w : V) : V := cantor ((atom23 n t s c u v y d w)+(atom23 n t s c u v y d w)+1) (atom81 n t s c u v y d w)
noncomputable def atom84 (n t s c u v y d w : V) : V := cantor 3 ((atom25 n t s c u v y d w)+(atom25 n t s c u v y d w)+1)
noncomputable def atom85 (n t s c u v y d w : V) : V := cantor ((atom79 n t s c u v y d w)+(atom79 n t s c u v y d w)) ((atom84 n t s c u v y d w)+(atom84 n t s c u v y d w)+1)
noncomputable def atom86 (n t s c u v y d w : V) : V := cantor ((atom85 n t s c u v y d w)+(atom85 n t s c u v y d w)) (atom75 n t s c u v y d w)
noncomputable def atom87 (n t s c u v y d w : V) : V := cantor (v+y) (atom86 n t s c u v y d w)
noncomputable def atom88 (n t s c u v y d w : V) : V := cantor (d+u) (atom87 n t s c u v y d w)
noncomputable def atom89 (n t s c u v y d w : V) : V := cantor (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2)
noncomputable def atom90 (n t s c u v y d w : V) : V := cantor ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) (atom86 n t s c u v y d w)
noncomputable def atom91 (n t s c u v y d w : V) : V := cantor (d+u) (atom90 n t s c u v y d w)
noncomputable def atom92 (n t s c u v y d w : V) : V := cantor (d+u) (atom91 n t s c u v y d w)
noncomputable def atom93 (n t s c u v y d w : V) : V := cantor (d+u) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+2)
noncomputable def atom94 (n t s c u v y d w : V) : V := cantor ((atom89 n t s c u v y d w)+(atom89 n t s c u v y d w)+1) ((atom93 n t s c u v y d w)+(atom93 n t s c u v y d w)+1)
noncomputable def atom95 (n t s c u v y d w : V) : V := cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w)
noncomputable def atom96 (n t s c u v y d w : V) : V := cantor (d+u) (atom95 n t s c u v y d w)
noncomputable def atom97 (n t s c u v y d w : V) : V := cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)
noncomputable def atom98 (n t s c u v y d w : V) : V := left s
noncomputable def atom99 (n t s c u v y d w : V) : V := right s
noncomputable def atom100 (n t s c u v y d w : V) : V := cantor t u
end PA192.ModelSearch.RegisterSource.Commands
