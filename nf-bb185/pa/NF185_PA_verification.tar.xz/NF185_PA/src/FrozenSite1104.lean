module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire1104 : String := include_str ".."/"data"/"FrozenSite1104.wire"
private def indices1104 : String := include_str ".."/"data"/"FrozenSite1104.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision1104 : (checkPayload 1104 48 wire1104 indices1104).isSome=true := by decide +native

theorem scope1104 : Scope 1104 48 := payload_sound _ _ _ _ decision1104
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope1104
