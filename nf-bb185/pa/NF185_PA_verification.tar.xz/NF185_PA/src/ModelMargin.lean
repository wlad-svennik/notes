module
public import ModelFrames
import Mathlib.Tactic.IntervalCases

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000
set_option maxRecDepth 20000

noncomputable def marginRegs : V := RegisterSource.vector 0 0 0 2 0 0 0 2 0
private def rNat (n : Nat) := if n=3 ∨ n=7 then 2 else 0
private def coldCount (n : Nat) := if n=0 then 1 else rNat n + 2
private def natBlocks : List Nat → Nat → Nat
| [],a => a | i::is,a => naturalLit [false] (naturalRep [true] (coldCount i) (natBlocks is a))

private theorem read_margin (i : Nat) (h : i<9) : RegisterSource.readReg i (marginRegs:V)=(rNat i:Nat) := by
  interval_cases i <;> simp [marginRegs,RegisterSource.vector,RegisterSource.readReg,rNat]

private theorem count_margin (i : Nat) (h : i<9) : blockCount i 1 (marginRegs:V)=(coldCount i:Nat) := by
  by_cases z : i=0
  · simp [blockCount,z,chooseZero,coldCount]
  · simp [blockCount,z,coldCount,read_margin _ h]

private theorem blocks_margin (ks : List Nat) (bound : ∀i∈ks,i<9) (a : Nat) :
    blocks ks 1 (marginRegs:V) (a:V)=(natBlocks ks a:Nat) := by
  induction ks with
  | nil => rfl
  | cons k ks ih =>
    simp only [blocks,natBlocks,count_margin k (bound k (by simp)),ih (fun i h => bound i (by simp [h])),
      rayRep_cast,rayLit_cast]

private def bootRight : Nat := naturalLit (pathBits 91) (naturalRep [false] (42-(pathBits 91).length)
  (naturalLit [true] (natBlocks registerOrder (naturalRep [false,true] 24 0))))
private theorem right_value : bootRight = 1772303994379889612529569458207697189 := by decide +kernel

theorem frame_margin : frame 91 1 (marginRegs:V) 0 0 = pack 13 1 1772303994379889612529569458207697189 := by
  have bound : ∀i∈registerOrder,i<9 := by simp [registerOrder]
  have rep0 : rayRep [false,true] (24+0:V) 0=(naturalRep [false,true] 24 0:Nat) := by
    convert rayRep_cast (V:=V) [false,true] 24 0 using 2 <;> norm_num
  unfold frame frameOf
  rw [rep0,blocks_margin registerOrder bound,rayLit_cast,add_zero,rayRep_cast,rayLit_cast]
  have joined : (↑bootRight : V)=1772303994379889612529569458207697189 := by rw [right_value]; norm_num
  rw [show naturalLit (pathBits 91) _=bootRight by rfl,joined]

theorem concrete_boot : Boundary (RegisterSource.coldMargin:V) (rawRun NF192.Selected.machine NF192.Selected.start 33911) := by
  apply Or.inr
  apply (anyLive_iff _ _ _).2
  refine ⟨91,by decide,?_,Or.inr ⟨?_,Or.inr (by decide)⟩,0,0,?_⟩
  · simp [RegisterSource.coldMargin]
  · simp [RegisterSource.coldMargin]
  · rw [model_boot]; simpa [RegisterSource.coldMargin,marginRegs] using (frame_margin (V:=V)).symm

/-- Every global nonstandard tick, all histories, the boot, and the source-to-formula interface
are discharged. Its single remaining argument lists 3,089 finite source locations. -/
theorem margin_from_rows (rows : ∀ p : Fin 3089, RowSim (V:=V) p.val)
    (source : RegisterSource.sourceHalts (RegisterSource.coldMargin:V)) : V ⊧/![] PA192.LiteralTM.H192 :=
  margin_implies_h192 Boundary boundaryDef ⟨33911,concrete_boot⟩ (allRows_simulate rows) boundary_stop source

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.concrete_boot
#print axioms PA192.PhysicalModel.margin_from_rows
