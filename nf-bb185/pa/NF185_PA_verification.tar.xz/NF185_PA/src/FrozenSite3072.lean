module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire3072 : String := include_str ".."/"data"/"FrozenSite3072.wire"
private def indices3072 : String := include_str ".."/"data"/"FrozenSite3072.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision3072 : (checkPayload 3072 17 wire3072 indices3072).isSome=true := by decide +native

theorem scope3072 : Scope 3072 17 := payload_sound _ _ _ _ decision3072
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope3072
