module
public import ModelCmdEmit13
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter449 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2161:Nat):V) f (vector n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom69 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2158 f n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom69 n t s c u v y d w) w
  have d2 : (0+(atom69 n t s c u v y d w):V)=atom69 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter448 f n t s c u v y d w).trans mid

theorem commandEmitAfter450 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2171:Nat):V) f (vector n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) 0 (atom73 n t s c u v y d w) w)) := by
  have micro := site2161 f n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom69 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1)):V)=atom73 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1)):V)=0+(atom73 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter449 f n t s c u v y d w).trans mid

theorem commandEmitAfter451 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2175:Nat):V) f (vector n ((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w)) (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2171 f n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) 0 (atom73 n t s c u v y d w) w
  have d1 : (0+(2*(atom73 n t s c u v y d w)):V)=(atom73 n t s c u v y d w)+(atom73 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom73 n t s c u v y d w)):V)=0+((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter450 f n t s c u v y d w).trans mid

theorem commandEmitAfter452 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2183:Nat):V) f (vector n ((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w)) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom67 n t s c u v y d w) w)) := by
  have micro := site2175 f n ((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w)) (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom69 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom69 n t s c u v y d w):V)=0+(atom69 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom69 n t s c u v y d w)):V)=left (atom69 n t s c u v y d w)).trans (by change left (cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom67 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom69 n t s c u v y d w)):V)=atom67 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom69 n t s c u v y d w):V)=0+(atom69 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom69 n t s c u v y d w)):V)=right (atom69 n t s c u v y d w)).trans (by change right (cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom67 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter451 f n t s c u v y d w).trans mid

theorem commandEmitAfter453 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2186:Nat):V) f (vector n ((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w)) (atom67 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2183 f n ((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w)) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom67 n t s c u v y d w) w
  have d2 : (0+(atom67 n t s c u v y d w):V)=atom67 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter452 f n t s c u v y d w).trans mid

theorem commandEmitAfter454 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2196:Nat):V) f (vector n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) 0 (atom74 n t s c u v y d w) w)) := by
  have micro := site2186 f n ((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w)) (atom67 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) ((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w))):V)=atom74 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) ((atom73 n t s c u v y d w)+(atom73 n t s c u v y d w))):V)=0+(atom74 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter453 f n t s c u v y d w).trans mid

theorem commandEmitAfter455 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2200:Nat):V) f (vector n ((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)) (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2196 f n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) 0 (atom74 n t s c u v y d w) w
  have d1 : (0+(2*(atom74 n t s c u v y d w)):V)=(atom74 n t s c u v y d w)+(atom74 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom74 n t s c u v y d w)):V)=0+((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter454 f n t s c u v y d w).trans mid

theorem commandEmitAfter456 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2203:Nat):V) f (vector n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) ((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)) 0 w)) := by
  have micro := site2200 f n ((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)) (atom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)):V)=(atom74 n t s c u v y d w)+(atom74 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter455 f n t s c u v y d w).trans mid

theorem commandEmitAfter457 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2206:Nat):V) f (vector n (atom67 n t s c u v y d w) 0 c (d+u) (v+y) ((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)) 0 w)) := by
  have micro := site2203 f n 0 (atom67 n t s c u v y d w) c (d+u) (v+y) ((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)) 0 w
  have d1 : (0+(atom67 n t s c u v y d w):V)=atom67 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter456 f n t s c u v y d w).trans mid

theorem commandEmitAfter458 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2216:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom75 n t s c u v y d w) w)) := by
  have micro := site2206 f n (atom67 n t s c u v y d w) 0 c (d+u) (v+y) ((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)) 0 w
  have d7 : (0+(cantor ((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)) (atom67 n t s c u v y d w)):V)=atom75 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom74 n t s c u v y d w)+(atom74 n t s c u v y d w)) (atom67 n t s c u v y d w)):V)=0+(atom75 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter457 f n t s c u v y d w).trans mid

theorem commandEmitAfter459 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2219:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2216 f n 0 0 c (d+u) (v+y) 0 (atom75 n t s c u v y d w) w
  have d2 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter458 f n t s c u v y d w).trans mid

theorem commandEmitAfter460 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2223:Nat):V) f (vector n (d+u) (atom75 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2219 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter459 f n t s c u v y d w).trans mid

theorem commandEmitAfter461 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2226:Nat):V) f (vector n (d+u) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2223 f n (d+u) (atom75 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter460 f n t s c u v y d w).trans mid

theorem commandEmitAfter462 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2229:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2226 f n (d+u) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter461 f n t s c u v y d w).trans mid

theorem commandEmitAfter463 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2232:Nat):V) f (vector n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2229 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter462 f n t s c u v y d w).trans mid

theorem commandEmitAfter464 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2242:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom76 n t s c u v y d w) w)) := by
  have micro := site2232 f n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom75 n t s c u v y d w)):V)=atom76 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom75 n t s c u v y d w)):V)=0+(atom76 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter463 f n t s c u v y d w).trans mid

theorem commandEmitAfter465 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2245:Nat):V) f (vector n 0 (atom76 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2242 f n 0 0 c (d+u) (v+y) 0 (atom76 n t s c u v y d w) w
  have d2 : (0+(atom76 n t s c u v y d w):V)=atom76 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter464 f n t s c u v y d w).trans mid

theorem commandEmitAfter466 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2249:Nat):V) f (vector n (v+y) (atom76 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2245 f n 0 (atom76 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter465 f n t s c u v y d w).trans mid

theorem commandEmitAfter467 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2252:Nat):V) f (vector n (v+y) (atom76 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2249 f n (v+y) (atom76 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter466 f n t s c u v y d w).trans mid

theorem commandEmitAfter468 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2260:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom75 n t s c u v y d w) w)) := by
  have micro := site2252 f n (v+y) (atom76 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom76 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom76 n t s c u v y d w):V)=0+(atom76 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom76 n t s c u v y d w)):V)=left (atom76 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom75 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom76 n t s c u v y d w)):V)=atom75 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom76 n t s c u v y d w):V)=0+(atom76 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom76 n t s c u v y d w)):V)=right (atom76 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom75 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter467 f n t s c u v y d w).trans mid

theorem commandEmitAfter469 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2263:Nat):V) f (vector n (v+y) (atom75 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2260 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom75 n t s c u v y d w) w
  have d2 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter468 f n t s c u v y d w).trans mid

theorem commandEmitAfter470 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2273:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site2263 f n (v+y) (atom75 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter469 f n t s c u v y d w).trans mid

theorem commandEmitAfter471 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2277:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2273 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter470 f n t s c u v y d w).trans mid

theorem commandEmitAfter472 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2278:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2277 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter471 f n t s c u v y d w).trans mid

theorem commandEmitAfter473 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2281:Nat):V) f (vector n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2278 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom75 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter472 f n t s c u v y d w).trans mid

theorem commandEmitAfter474 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2284:Nat):V) f (vector n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2281 f n 0 (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter473 f n t s c u v y d w).trans mid

theorem commandEmitAfter475 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2294:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom77 n t s c u v y d w) w)) := by
  have micro := site2284 f n (atom75 n t s c u v y d w) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom75 n t s c u v y d w)):V)=atom77 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom75 n t s c u v y d w)):V)=0+(atom77 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter474 f n t s c u v y d w).trans mid

theorem commandEmitAfter476 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2297:Nat):V) f (vector n 0 (atom77 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2294 f n 0 0 c (d+u) (v+y) 0 (atom77 n t s c u v y d w) w
  have d2 : (0+(atom77 n t s c u v y d w):V)=atom77 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter475 f n t s c u v y d w).trans mid

theorem commandEmitAfter477 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2301:Nat):V) f (vector n (v+y) (atom77 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2297 f n 0 (atom77 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter476 f n t s c u v y d w).trans mid

theorem commandEmitAfter478 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2304:Nat):V) f (vector n (v+y) (atom77 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2301 f n (v+y) (atom77 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter477 f n t s c u v y d w).trans mid

theorem commandEmitAfter479 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2312:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom75 n t s c u v y d w) w)) := by
  have micro := site2304 f n (v+y) (atom77 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom77 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom77 n t s c u v y d w):V)=0+(atom77 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom77 n t s c u v y d w)):V)=left (atom77 n t s c u v y d w)).trans (by change left (cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom75 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom77 n t s c u v y d w)):V)=atom75 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom77 n t s c u v y d w):V)=0+(atom77 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom77 n t s c u v y d w)):V)=right (atom77 n t s c u v y d w)).trans (by change right (cantor ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom75 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter478 f n t s c u v y d w).trans mid

theorem commandEmitAfter480 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2315:Nat):V) f (vector n (v+y) (atom75 n t s c u v y d w) c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2312 f n (v+y) 0 c (d+u) (v+y) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom75 n t s c u v y d w) w
  have d2 : (0+(atom75 n t s c u v y d w):V)=atom75 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter479 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
