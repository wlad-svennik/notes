module
public import ModelLiteralRegisters
public import ModelValue
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterFields
set_option maxRecDepth 7000
set_option maxHeartbeats 2500000
namespace PA192.ModelSearch.RegisterSource

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

def Reach (a b : V) : Prop := ∃ t : V, run t a=b
instance reachDef : Language.DefinableRel ℒₒᵣ (Reach (V:=V)) := by unfold Reach; definability
theorem Reach.refl (a : V) : Reach a a := ⟨0,run_zero _⟩
theorem Reach.once {a b : V} (h : step a=b) : Reach a b := by
  refine ⟨1,?_⟩
  simpa using (run_succ (0:V) a).trans (by simpa using h)
theorem Reach.trans {a b c : V} (h : Reach a b) (k : Reach b c) : Reach a c := by
  obtain ⟨x,e⟩ := h; obtain ⟨y,g⟩ := k
  exact ⟨x+y,(run_add x y a).trans (by rw [e,g])⟩

/-- One or more actual source steps; composition retains a positive witness. -/
def Progress (a b : V) : Prop := ∃ t : V, 0<t ∧ run t a=b
instance progressDef : Language.DefinableRel ℒₒᵣ (Progress (V:=V)) := by unfold Progress; definability
theorem Progress.reach {a b : V} (h : Progress a b) : Reach a b :=
  let ⟨t,_,ok⟩ := h; ⟨t,ok⟩
theorem Progress.once {a b : V} (h : step a=b) : Progress a b := by
  refine ⟨1,by simp,?_⟩
  simpa using (run_succ (0:V) a).trans (by simpa using h)
theorem Progress.thenReach {a b c : V} (h : Progress a b) (k : Reach b c) : Progress a c := by
  obtain ⟨x,p,e⟩ := h; obtain ⟨y,g⟩ := k
  exact ⟨x+y,lt_of_lt_of_le p le_self_add,(run_add x y a).trans (by rw [e,g])⟩

/-- A ranked loop can carry arbitrary PA-definable state. All local branch proofs
can be supplied from exact literal steps using the same source relation. -/
theorem rankLoop (atEntry : V → V → V) (atExit : V → V) (update : V → V)
    [Language.DefinableFunction₂ ℒₒᵣ atEntry]
    [Language.DefinableFunction₁ ℒₒᵣ atExit]
    [Language.DefinableFunction₁ ℒₒᵣ update]
    (base : ∀ v, Reach (atEntry 0 v) (atExit v))
    (more : ∀ r v, Reach (atEntry (r+1) v) (atEntry r (update v))) :
    ∀ r : V, ∀ v, Reach (atEntry r v) (atExit (iterate update r v)) := by
  apply modelInduct
  · definability
  · simpa using base
  · intro r ih v
    simpa only [iterate_succ_left] using (more r v).trans (ih (update v))

/-- The affine loop underlying clear, transfer, copy and doubling. The pair
of other register coordinates starts at arbitrary values and either may stay fixed. -/
theorem affineLoop (before : V → V → V → V) (after : V → V → V)
    [Language.DefinableFunction₃ ℒₒᵣ before] [Language.DefinableFunction₂ ℒₒᵣ after]
    (a b : V)
    (base : ∀ y z, Reach (before 0 y z) (after y z))
    (more : ∀ x y z, Reach (before (x+1) y z) (before x (y+a) (z+b))) :
    ∀ x : V, ∀ y z, Reach (before x y z) (after (y+a*x) (z+b*x)) := by
  apply modelInduct
  · definability
  · simpa using base
  · intro x ih y z
    apply (more x y z).trans
    have ha : y+a*(x+1)=y+a+a*x := by ring
    have hb : z+b*(x+1)=z+b+b*x := by ring
    simpa only [ha,hb] using ih (y+a) (z+b)

/-- Exact lifting of the inverse diagonal step of the Cantor unpair template.
Within each nonstandard PA model, its pair-value increases by one. -/
theorem diagonalLoop (before : V → V → V → V) (after : V → V → V)
    [Language.DefinableFunction₃ ℒₒᵣ before] [Language.DefinableFunction₂ ℒₒᵣ after]
    (base : ∀ y z, Reach (before 0 y z) (after y z))
    (more : ∀ x y z, Reach (before (x+1) y z)
      (before x (pi₁ (diagonalNext ⟪y,z⟫)) (pi₂ (diagonalNext ⟪y,z⟫)))) :
    ∀ x : V, ∀ y z, Reach (before x y z)
       (after (left (cantor y z+x)) (right (cantor y z+x))) := by
  apply modelInduct
  · definability
  · simpa using base
  · intro x ih y z
    apply (more x y z).trans
    have add1 := diagonalNext_code (⟪y,z⟫ : V)
    simp only [pi₁_pair,pi₂_pair] at add1
    simpa only [add1,add_assoc,add_comm (1:V) x] using
      ih (pi₁ (diagonalNext ⟪y,z⟫)) (pi₂ (diagonalNext ⟪y,z⟫))

/-- An arbitrary sequence of definable macro-steps can be collapsed to one
literal source run in V, with no preselected time or bound. -/
theorem simulation (jump view : V → V) [Language.DefinableFunction₁ ℒₒᵣ jump]
    [Language.DefinableFunction₁ ℒₒᵣ view]
    (localRun : ∀ z, Reach (view z) (view (jump z))) (s : V) :
    ∀ n : V, Reach (view s) (view (iterate jump n s)) := by
  apply modelInduct
  · definability
  · simpa using Reach.refl (view s)
  · intro n ih
    simpa only [iterate_succ] using ih.trans (localRun (iterate jump n s))

end PA192.ModelSearch.RegisterSource
#print axioms PA192.ModelSearch.RegisterSource.diagonalLoop
