module
public import ModelCases

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.ModelSearch PA192.ModelSearch.RegisterFields PA192.ModelSearch.RegisterSource
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 4000000
set_option maxRecDepth 30000

def leftExitPad (p : Nat) (z : Bool) (op : Instr) := match op with
  | .dec .. => if p=3087 ∧ z=true then 63 else 64
  | _ => 64
def rightExitPad (op : Instr) := match op with | .inc .. => 61 | _ => 64

/-- The complete signed finite-word endpoint, with literal source front/back padding. -/
def branchStatement (p : Nat) (op : Instr) (c z : Bool) (t : Term) : Equation :=
  let input := (incoming p op c z).encoded 64 64
  let run := runT t input
  if dest op z=4095 then ⟨.un .state run,.numeral 192⟩ else
    ⟨.un .norm run,(outgoing p op c z).encoded (leftExitPad p z op) (rightExitPad op)⟩

def AdmissibleExit (op : Instr) (c z : Bool) : Prop := dest op z=4095 ∨
  dest op z<3089 ∧ (exitCold op c=false ∨ dest op z<3 ∨ 9<dest op z)

def BranchSound (p : Nat) (op : Instr) (c z : Bool) : Prop :=
  ∃ t, Replay.Sound NF192.Selected.machine [] (branchStatement p op c z t)

theorem val_runT (m : Machine n) (t a : Term) (ρ : Nat→V) :
    (runT t a).val (operations m) ρ=iterate (fstep m) (t.val (operations m) ρ) (a.val (operations m) ρ) := rfl
theorem val_stateT (m : Machine n) (a : Term) (ρ : Nat→V) :
    (Term.un .state a).val (operations m) ρ=fq (a.val (operations m) ρ) := rfl
theorem branch_step (p : Nat) (op : Instr) (c z : Bool) (t : Term)
    (proof : Replay.Sound NF192.Selected.machine [] (branchStatement p op c z t))
    (hp : program[p]?=some op) (dst : AdmissibleExit op c z) (r g s : V)
    (chosen : choiceOk op z r) :
    ∃ticks:V, Boundary (step (config (p:V) (c.toNat:V) r))
      (iterate (rawStep NF192.Selected.machine) ticks (frame p (c.toNat:V) r g s)) := by
  let m := NF192.Selected.machine
  let ρ : Nat→V := valuation op z r g s
  let enter := incoming p op c z
  let exit := outgoing p op c z
  let input := (enter.encoded 64 64).val (operations m) ρ
  let ticks := t.val (operations m) ρ
  let exec := iterate (fstep m) ticks input
  have start : project input=frame p (c.toNat:V) r g s := by
    unfold input
    rw [pattern_project m enter 64 64 (c.toNat:V) r ρ rfl (valueInput op z r g s chosen) (valW _ _ _ _ _ 11) (valW _ _ _ _ _ 12)]
    simp [enter,incoming,Width.amount,vWidth,ρ,valN]
  have projection : project exec=iterate (rawStep m) ticks (frame p (c.toNat:V) r g s) := by
    unfold exec; rw [projected_run,start]
  have row := proof (V:=V) ρ (by simp)
  have pc := resulting_pc op c z r chosen
  have flag := resulting_flag op c z r chosen
  rw [step_at p op hp]
  refine ⟨ticks,?_⟩
  by_cases stopped : dest op z=4095
  · have controlEq : fq exec=192 := by simpa only [branchStatement,stopped,ite_true,Equation.Holds,val_stateT,val_runT,val_numeral,Nat.cast_ofNat,exec,ticks,input,enter,m] using row
    apply Or.inl
    constructor
    · rw [pc,stopped]; norm_num
    · rw [←projection,projected_state,controlEq]
  · have last : normF exec = (exit.encoded (leftExitPad p z op) (rightExitPad op)).val (operations m) ρ := by
      simpa only [branchStatement,stopped,ite_false,Equation.Holds,val_normT,val_runT,exec,ticks,input,enter,exit,m] using row
    have projected := congrArg project last
    rw [projected_norm,projection] at projected
    have toFrame := pattern_project m exit (leftExitPad p z op) (rightExitPad op)
      (cold (perform op (c.toNat:V) r)) (registers (perform op (c.toNat:V) r)) ρ flag
      (valueOutput op c z r g s chosen) (valW _ _ _ _ _ 11) (valW _ _ _ _ _ 12)
    obtain ⟨bound,legal⟩ := dst.resolve_left stopped
    apply Or.inr
    apply (anyLive_iff (List.range 3089) (perform op (c.toNat:V) r) (iterate (rawStep NF192.Selected.machine) ticks (frame p (c.toNat:V) r g s))).mpr
    refine ⟨dest op z,List.mem_range.mpr bound,pc,?_,exit.gap.amount ρ,exit.spare.amount ρ,projected.trans toFrame⟩
    rw [flag]
    cases ex : exitCold op c
    · simp [legalTag]
    · simp [legalTag,ex] at legal ⊢
      exact legal

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.branch_step
