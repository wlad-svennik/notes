module
public import ModelSeed12
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem seedEmitAfter417 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2013:Nat):V) f (vector n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2010 f n 0 0 c (d+u) (v+y) 0 (atom69 n t s c u v y d w) w
  have d2 : (0+(atom69 n t s c u v y d w):V)=atom69 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter416 f n t s c u v y d w).trans mid

theorem seedEmitAfter418 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2017:Nat):V) f (vector n (d+u) (atom69 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2013 f n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter417 f n t s c u v y d w).trans mid

theorem seedEmitAfter419 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2020:Nat):V) f (vector n (d+u) (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2017 f n (d+u) (atom69 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (seedEmitAfter418 f n t s c u v y d w).trans mid

theorem seedEmitAfter420 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2023:Nat):V) f (vector n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2020 f n (d+u) (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter419 f n t s c u v y d w).trans mid

theorem seedEmitAfter421 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2026:Nat):V) f (vector n (atom69 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2023 f n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom69 n t s c u v y d w):V)=atom69 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter420 f n t s c u v y d w).trans mid

theorem seedEmitAfter422 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2036:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom70 n t s c u v y d w) w)) := by
  have micro := site2026 f n (atom69 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom69 n t s c u v y d w)):V)=atom70 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom69 n t s c u v y d w)):V)=0+(atom70 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter421 f n t s c u v y d w).trans mid

theorem seedEmitAfter423 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2039:Nat):V) f (vector n 0 (atom70 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2036 f n 0 0 c (d+u) (v+y) 0 (atom70 n t s c u v y d w) w
  have d2 : (0+(atom70 n t s c u v y d w):V)=atom70 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter422 f n t s c u v y d w).trans mid

theorem seedEmitAfter424 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2043:Nat):V) f (vector n c (atom70 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site2039 f n 0 (atom70 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+c:V)=c := by ring
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter423 f n t s c u v y d w).trans mid

theorem seedEmitAfter425 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2046:Nat):V) f (vector n c (atom70 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2043 f n c (atom70 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (seedEmitAfter424 f n t s c u v y d w).trans mid

theorem seedEmitAfter426 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2054:Nat):V) f (vector n c 0 c (d+u) (v+y) (d+u) (atom69 n t s c u v y d w) w)) := by
  have micro := site2046 f n c (atom70 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom70 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom70 n t s c u v y d w):V)=0+(atom70 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom70 n t s c u v y d w)):V)=left (atom70 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom69 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom70 n t s c u v y d w)):V)=atom69 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom70 n t s c u v y d w):V)=0+(atom70 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom70 n t s c u v y d w)):V)=right (atom70 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom69 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter425 f n t s c u v y d w).trans mid

theorem seedEmitAfter427 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2057:Nat):V) f (vector n c (atom69 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2054 f n c 0 c (d+u) (v+y) (d+u) (atom69 n t s c u v y d w) w
  have d2 : (0+(atom69 n t s c u v y d w):V)=atom69 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter426 f n t s c u v y d w).trans mid

theorem seedEmitAfter428 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2067:Nat):V) f (vector n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) 0 (atom9 n t s c u v y d w) w)) := by
  have micro := site2057 f n c (atom69 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) c):V)=atom9 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) c):V)=0+(atom9 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter427 f n t s c u v y d w).trans mid

theorem seedEmitAfter429 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2071:Nat):V) f (vector n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2067 f n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) 0 (atom9 n t s c u v y d w) w
  have d1 : (0+(2*(atom9 n t s c u v y d w)):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom9 n t s c u v y d w)):V)=0+((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter428 f n t s c u v y d w).trans mid

theorem seedEmitAfter430 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2072:Nat):V) f (vector n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2071 f n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w))+1:V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter429 f n t s c u v y d w).trans mid

theorem seedEmitAfter431 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2075:Nat):V) f (vector n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2072 f n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter430 f n t s c u v y d w).trans mid

theorem seedEmitAfter432 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2078:Nat):V) f (vector n (atom69 n t s c u v y d w) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2075 f n 0 (atom69 n t s c u v y d w) c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom69 n t s c u v y d w):V)=atom69 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter431 f n t s c u v y d w).trans mid

theorem seedEmitAfter433 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2088:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom71 n t s c u v y d w) w)) := by
  have micro := site2078 f n (atom69 n t s c u v y d w) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom69 n t s c u v y d w)):V)=atom71 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom69 n t s c u v y d w)):V)=0+(atom71 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter432 f n t s c u v y d w).trans mid

theorem seedEmitAfter434 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2091:Nat):V) f (vector n 0 (atom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2088 f n 0 0 c (d+u) (v+y) 0 (atom71 n t s c u v y d w) w
  have d2 : (0+(atom71 n t s c u v y d w):V)=atom71 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter433 f n t s c u v y d w).trans mid

theorem seedEmitAfter435 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2095:Nat):V) f (vector n c (atom71 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site2091 f n 0 (atom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+c:V)=c := by ring
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter434 f n t s c u v y d w).trans mid

theorem seedEmitAfter436 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2098:Nat):V) f (vector n c (atom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2095 f n c (atom71 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (seedEmitAfter435 f n t s c u v y d w).trans mid

theorem seedEmitAfter437 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2101:Nat):V) f (vector n 0 (atom71 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site2098 f n c (atom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter436 f n t s c u v y d w).trans mid

theorem seedEmitAfter438 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2104:Nat):V) f (vector n (atom71 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w)) := by
  have micro := site2101 f n 0 (atom71 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d1 : (0+(atom71 n t s c u v y d w):V)=atom71 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter437 f n t s c u v y d w).trans mid

theorem seedEmitAfter439 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2114:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom72 n t s c u v y d w) w)) := by
  have micro := site2104 f n (atom71 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w
  have d7 : (0+(cantor c (atom71 n t s c u v y d w)):V)=atom72 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor c (atom71 n t s c u v y d w)):V)=0+(atom72 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter438 f n t s c u v y d w).trans mid

theorem seedEmitAfter440 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2117:Nat):V) f (vector n 0 (atom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2114 f n 0 0 c (d+u) (v+y) 0 (atom72 n t s c u v y d w) w
  have d2 : (0+(atom72 n t s c u v y d w):V)=atom72 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter439 f n t s c u v y d w).trans mid

theorem seedEmitAfter441 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2121:Nat):V) f (vector n (v+y) (atom72 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2117 f n 0 (atom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (seedEmitAfter440 f n t s c u v y d w).trans mid

theorem seedEmitAfter442 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2124:Nat):V) f (vector n (v+y) (atom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2121 f n (v+y) (atom72 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (seedEmitAfter441 f n t s c u v y d w).trans mid

theorem seedEmitAfter443 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2132:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) c (atom71 n t s c u v y d w) w)) := by
  have micro := site2124 f n (v+y) (atom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom72 n t s c u v y d w)):V)=c := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom72 n t s c u v y d w):V)=0+(atom72 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom72 n t s c u v y d w)):V)=left (atom72 n t s c u v y d w)).trans (by change left (cantor c (atom71 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom72 n t s c u v y d w)):V)=atom71 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom72 n t s c u v y d w):V)=0+(atom72 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom72 n t s c u v y d w)):V)=right (atom72 n t s c u v y d w)).trans (by change right (cantor c (atom71 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter442 f n t s c u v y d w).trans mid

theorem seedEmitAfter444 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2135:Nat):V) f (vector n (v+y) (atom71 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site2132 f n (v+y) 0 c (d+u) (v+y) c (atom71 n t s c u v y d w) w
  have d2 : (0+(atom71 n t s c u v y d w):V)=atom71 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter443 f n t s c u v y d w).trans mid

theorem seedEmitAfter445 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2145:Nat):V) f (vector n 0 (atom71 n t s c u v y d w) c (d+u) (v+y) 0 (atom30 n t s c u v y d w) w)) := by
  have micro := site2135 f n (v+y) (atom71 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d7 : (0+(cantor c (v+y)):V)=atom30 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor c (v+y)):V)=0+(atom30 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (seedEmitAfter444 f n t s c u v y d w).trans mid

theorem seedEmitAfter446 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2149:Nat):V) f (vector n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)) (atom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2145 f n 0 (atom71 n t s c u v y d w) c (d+u) (v+y) 0 (atom30 n t s c u v y d w) w
  have d1 : (0+(2*(atom30 n t s c u v y d w)):V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom30 n t s c u v y d w)):V)=0+((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter445 f n t s c u v y d w).trans mid

theorem seedEmitAfter447 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2150:Nat):V) f (vector n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2149 f n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)) (atom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w))+1:V)=(atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (seedEmitAfter446 f n t s c u v y d w).trans mid

theorem seedEmitAfter448 (f n t s c u v y d w : V) : Reach (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (atom3 n t s c u v y d w) (atom0 n t s c u v y d w))) (config ((2158:Nat):V) f (vector n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom69 n t s c u v y d w) w)) := by
  have micro := site2150 f n ((atom30 n t s c u v y d w)+(atom30 n t s c u v y d w)+1) (atom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom71 n t s c u v y d w)):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom71 n t s c u v y d w):V)=0+(atom71 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom71 n t s c u v y d w)):V)=left (atom71 n t s c u v y d w)).trans (by change left (cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom69 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom71 n t s c u v y d w)):V)=atom69 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom71 n t s c u v y d w):V)=0+(atom71 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom71 n t s c u v y d w)):V)=right (atom71 n t s c u v y d w)).trans (by change right (cantor ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)+1) (atom69 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (seedEmitAfter447 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
