module
public import ModelFinite

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.ModelSearch.RegisterFields
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 2000000

def cf (q d a b : Term) : Term := .bin .pair q (.bin .pair d (.bin .pair a b))
def digit (b : Bool) (a : Term) : Term := if b then .un .bit1 a else .un .bit0 a
def litWord : List Bool → Term → Term
  | [],a => a | b::bs,a => digit b (litWord bs a)
def rep (w : List Bool) (n a : Term) : Term := .bin (.repeatWord w) n a
def runT (n a : Term) : Term := .bin .run n a
def boolN (b : Bool) : Term := .numeral b.toNat
inductive View | blank | digit (b : Bool) (tail : Term)
def View.term : View → Term | .blank => .numeral 0 | .digit b a => PA192.PhysicalModel.digit b a
def View.hd : View → Bool | .blank => false | .digit b _ => b
def View.tl : View → Term | .blank => .numeral 0 | .digit _ a => a

def returnT (row : Instruction n) (dir : Bool) (tail back : Term) : Term :=
  let q := Term.numeral (PA192.LiteralTM.control row.next)
  match row.move with
  | .right => if dir then cf q (.numeral 0) back (digit row.write tail)
              else cf q (.numeral 0) tail (digit row.write back)
  | .left => if dir then cf q (.numeral 1) tail (digit row.write back)
             else cf q (.numeral 1) back (digit row.write tail)

/-- This inductive list is precisely the numerical backend's reduction
repertoire. In particular physical transition lookup is separate from
finite-word orientation normalization. -/
inductive Redex (m : Machine n) : Equation → Prop
  | succNum (a : Nat) : Redex m ⟨.succ (.numeral a),.numeral (a+1)⟩
  | addNum (a b : Nat) : Redex m ⟨.add (.numeral a) (.numeral b),.numeral (a+b)⟩
  | mulNum (a b : Nat) : Redex m ⟨.mul (.numeral a) (.numeral b),.numeral (a*b)⟩
  | subNum (a b : Nat) : Redex m ⟨.sub (.numeral a) (.numeral b),.numeral (a-b)⟩
  | addZero (a) : Redex m ⟨.add a (.numeral 0),a⟩
  | addSucc (a b) : Redex m ⟨.add a (.succ b),.succ (.add a b)⟩
  | mulZero (a) : Redex m ⟨.mul a (.numeral 0),.numeral 0⟩
  | mulSucc (a b) : Redex m ⟨.mul a (.succ b),.add a (.mul a b)⟩
  | subSelf (a) : Redex m ⟨.sub a a,.numeral 0⟩
  | subZero (a) : Redex m ⟨.sub a (.numeral 0),a⟩
  | zeroSub (a) : Redex m ⟨.sub (.numeral 0) a,.numeral 0⟩
  | subSucc (a b) : Redex m ⟨.sub (.succ a) (.succ b),.sub a b⟩
  | repZero (w a) : Redex m ⟨rep w (.numeral 0) a,a⟩
  | repSucc (w n a) : Redex m ⟨rep w (.succ n) a,litWord w (rep w n a)⟩
  | runZero (a) : Redex m ⟨runT (.numeral 0) a,a⟩
  | runSucc (n a) : Redex m ⟨runT (.succ n) a,.un .step (runT n a)⟩
  | control (q d a b) : Redex m ⟨.un .state (cf q d a b),q⟩
  | normRight (q a b) : Redex m ⟨.un .norm (cf q (.numeral 0) a b),cf q (.numeral 0) a b⟩
  | normLeft (q : Term) (v : View) (b : Term) : Redex m
      ⟨.un .norm (cf q (.numeral 1) v.term b),cf q (.numeral 0) (digit v.hd b) v.tl⟩
  | row (q : Fin n) (d : Bool) (v : View) (b : Term) : Redex m
      ⟨.un .step (cf (.numeral q.val) (boolN d) v.term b),returnT (m q v.hd) d v.tl b⟩
  | sink (d b f : Term) : Redex m
      ⟨.un .step (cf (.numeral n) d f b),cf (.numeral n) d f b⟩

@[simp] theorem val_cf (m : Machine n) (ρ : Nat→V) (q d a b : Term) :
    (cf q d a b).val (operations m) ρ=fpack (q.val (operations m) ρ) (d.val (operations m) ρ)
      (a.val (operations m) ρ) (b.val (operations m) ρ) := rfl
@[simp] theorem val_digit (m : Machine n) (ρ : Nat→V) (b : Bool) (a : Term) :
    (digit b a).val (operations m) ρ=pushW (b.toNat:V) (a.val (operations m) ρ) := by cases b <;> simp [digit,Term.val,operations]
@[simp] theorem val_litWord (m : Machine n) (ρ : Nat→V) (w : List Bool) (a : Term) :
    (litWord w a).val (operations m) ρ=literal w (a.val (operations m) ρ) := by
  induction w with | nil => rfl | cons b w h => simp [litWord,literal,h]

theorem view_head (m : Machine n) (ρ : Nat→V) (v : View) :
    headW (v.term.val (operations m) ρ)=(v.hd.toNat:V) := by
  cases v with
  | blank => simp [View.term,View.hd,Term.val]
  | digit b t => simpa only [View.term,View.hd,val_digit] using head_push (b.toNat:V) (t.val (operations m) ρ) (bool_num b)
theorem view_tail (m : Machine n) (ρ : Nat→V) (v : View) :
    tailW (v.term.val (operations m) ρ)=v.tl.val (operations m) ρ := by
  cases v with
  | blank => simp [View.term,View.tl,Term.val]
  | digit b t => simpa only [View.term,View.tl,val_digit] using tail_push (b.toNat:V) (t.val (operations m) ρ) (bool_num b)

theorem val_row_return (m : Machine n) (ρ : Nat→V) (q : Fin n) (d : Bool) (v : View) (b : Term) :
    fAction (m q v.hd) ((cf (.numeral q.val) (boolN d) v.term b).val (operations m) ρ) =
    (returnT (m q v.hd) d v.tl b).val (operations m) ρ := by
  cases e : m q v.hd with
  | mk w dir out =>
    cases dir <;> cases d <;> simp [fAction,returnT,val_cf,boolN,Term.val,view_tail]

private theorem cast_sub_num (a b : Nat) : (a:V)-(b:V)=((a-b : Nat):V) := by
  rcases le_total b a with h | h
  · apply sub_remove_left; exact_mod_cast (Nat.sub_add_cancel h).symm
  · rw [Nat.sub_eq_zero_of_le h, Nat.cast_zero, sub_spec_of_le (by exact_mod_cast h)]

@[simp] theorem val_numeral (m : Machine n) (ρ : Nat→V) (k : Nat) :
  (Term.numeral k).val (operations m) ρ = (k:V) := rfl
theorem val_normT (m : Machine n) (ρ : Nat→V) (t : Term) :
  (Term.un .norm t).val (operations m) ρ=normF (t.val (operations m) ρ) := rfl
theorem val_stepT (m : Machine n) (ρ : Nat→V) (t : Term) :
  (Term.un .step t).val (operations m) ρ=fstep m (t.val (operations m) ρ) := rfl
private theorem succ_sub_succ (a b : V) : (a+1)-(b+1)=a-b := by
  rw [add_comm b 1,← Arithmetic.sub_sub,add_sub_self]
theorem redex_sound (m : Machine n) {e : Equation} (h : Redex m e) (ρ : Nat → V) :
    e.Holds (operations m) ρ := by
  cases h with
  | succNum a => simp [Equation.Holds,Term.val]
  | addNum a b => simp [Equation.Holds,Term.val]
  | mulNum a b => simp [Equation.Holds,Term.val]
  | subNum a b => exact cast_sub_num _ _
  | addZero a => simp [Equation.Holds,Term.val]
  | addSucc a b => simp [Equation.Holds,Term.val,add_assoc]
  | mulZero a => simp [Equation.Holds,Term.val]
  | mulSucc a b => simp [Equation.Holds,Term.val,mul_add,add_comm]
  | subSelf a => simp [Equation.Holds,Term.val]
  | subZero a => simp [Equation.Holds,Term.val]
  | zeroSub a => simp [Equation.Holds,Term.val]
  | subSucc a b => exact succ_sub_succ _ _
  | repZero w a => exact repeat_zero _ _
  | repSucc w k a =>
    unfold Equation.Holds
    rw [val_litWord]; exact repeat_succ _ _ _
  | runZero a => exact iterate_zero _ _
  | runSucc k a => exact iterate_succ _ _ _
  | control q d a b => exact fq_pack _ _ _ _
  | normRight q a b =>
    simp only [Equation.Holds,val_normT,val_cf,val_numeral,Nat.cast_zero,normF,fd_pack,ite_true]
  | normLeft q v b =>
    simp only [Equation.Holds,val_normT,val_cf,val_numeral,Nat.cast_one,Nat.cast_zero,normF,fd_pack,Arithmetic.one_ne_zero,ite_false,ff_pack,fb_pack,fq_pack,view_head,view_tail,val_digit]
  | row q d v b =>
    simp only [Equation.Holds,val_stepT,val_cf,val_numeral,boolN]
    rw [table_row m q v.hd _ _ _ (view_head m ρ v)]
    exact val_row_return m ρ q d v b
  | sink d b f => exact table_sink _ _ _ _

/-- A closed numerical certificate is sound in every PA model for the
literal finite-word machine. This theorem has no interpretation premises. -/
theorem physical_certificate_sound (m : Machine n) {Γ e} (h : Derives (Redex m) Γ e) :
    ValidAt (operations (V:=V) m) Γ e :=
  derivation_sound _ (operations_defined m) (fun _ hh ρ => redex_sound m hh ρ) h

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.physical_certificate_sound
