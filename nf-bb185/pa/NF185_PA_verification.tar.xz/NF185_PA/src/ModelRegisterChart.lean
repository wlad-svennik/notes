module
public import ModelSourceReach

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 6000
set_option maxHeartbeats 1800000
set_option linter.unusedVariables false
namespace PA192.ModelSearch.RegisterSource

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

@[simp] theorem writeReg_overwrite (i : Nat) (r a b : V) : writeReg i (writeReg i r a) b = writeReg i r b := by
  induction i generalizing r with
  | zero => simp [writeReg]
  | succ i ih => simp [writeReg,ih]

@[simp] theorem writeReg_read (i : Nat) (r : V) : writeReg i r (readReg i r) = r := by
  induction i generalizing r with
  | zero => simp [writeReg,readReg]
  | succ i ih => simp [writeReg,readReg,ih]

theorem writeReg_comm (i j : Nat) (ne : i ≠ j) (r a b : V) :
    writeReg i (writeReg j r a) b = writeReg j (writeReg i r b) a := by
  induction i generalizing j r with
  | zero => cases j <;> simp_all [writeReg]
  | succ i ih => cases j <;> simp_all [writeReg]

theorem perform_inc (i target : Nat) (f r : V) (safe : i≠0 ∨ f=0) :
    perform (.inc i target) f r = config (target:V) f (writeReg i r (readReg i r+1)) := by
  cases i with
  | zero => rcases safe with h|rfl; contradiction; simp [perform,chooseZero]
  | succ => rfl

structure Slots where
  x : Nat
  y : Nat
  z : Nat
  xy : x≠y
  xz : x≠z
  yz : y≠z

noncomputable def Slots.fill (s : Slots) (r x y z : V) : V :=
  writeReg s.x (writeReg s.y (writeReg s.z r z) y) x

noncomputable def Slots.atReg (s : Slots) (pc : Nat) (f r x y z : V) : V := config (pc:V) f (s.fill r x y z)

instance Slots.frameDef (s : Slots) (pc : Nat) (f r : V) :
    Language.DefinableFunction₃ ℒₒᵣ (s.atReg pc f r) := by
  change Language.DefinableFunction₃ ℒₒᵣ
    (fun x y z:V=>config (pc:V) f (writeReg s.x (writeReg s.y (writeReg s.z r z) y) x))
  definability

@[simp] theorem Slots.fill_x (s : Slots) (r x y z : V) : readReg s.x (s.fill r x y z)=x := by simp [Slots.fill]
@[simp] theorem Slots.fill_y (s : Slots) (r x y z : V) : readReg s.y (s.fill r x y z)=y := by
  simp [Slots.fill,readReg_other _ _ s.xy.symm]
@[simp] theorem Slots.fill_z (s : Slots) (r x y z : V) : readReg s.z (s.fill r x y z)=z := by
  simp [Slots.fill,readReg_other _ _ s.xz.symm,readReg_other _ _ s.yz.symm]

@[simp] theorem Slots.write_x (s : Slots) (r x y z w : V) :
    writeReg s.x (s.fill r x y z) w = s.fill r w y z := by simp [Slots.fill]
@[simp] theorem Slots.write_y (s : Slots) (r x y z w : V) :
    writeReg s.y (s.fill r x y z) w = s.fill r x w z := by
  simp [Slots.fill,writeReg_comm _ _ s.xy.symm]
@[simp] theorem Slots.write_z (s : Slots) (r x y z w : V) :
    writeReg s.z (s.fill r x y z) w = s.fill r x y w := by
  simp [Slots.fill,writeReg_comm _ _ s.xz.symm,writeReg_comm _ _ s.yz.symm]

@[simp] theorem Slots.fill_original (s : Slots) (r : V) :
    s.fill r (readReg s.x r) (readReg s.y r) (readReg s.z r) = r := by simp [Slots.fill]

theorem Slots.jump (s : Slots) (pc tgt : Nat) (f r : V) (h : program[pc]?=some (.jump tgt)) (x y z : V) :
    Reach (s.atReg pc f r x y z) (s.atReg tgt f r x y z) := by
  apply Reach.once
  simp only [atReg,step_at pc _ h,perform]

theorem Slots.inc_x (s : Slots) (pc tgt : Nat) (f r : V) (h : program[pc]?=some (.inc s.x tgt))
    (safe : s.x ≠ 0 ∨ f=0) (x y z : V) :
    Reach (s.atReg pc f r x y z) (s.atReg tgt f r (x+1) y z) := by
  apply Reach.once
  simp only [atReg,step_at pc _ h,perform_inc _ _ _ _ safe,fill_x,write_x]

theorem Slots.zero_x (s : Slots) (pc zt st : Nat) (f r : V) (h : program[pc]?=some (.dec s.x zt st))
    (x y z : V) : Reach (s.atReg pc f r 0 y z) (s.atReg zt f r 0 y z) := by
  apply Reach.once
  simp [atReg,step_at pc _ h,perform,chooseZero]

theorem Slots.pos_x (s : Slots) (pc zt st : Nat) (f r : V) (h : program[pc]?=some (.dec s.x zt st))
    (x y z : V) : Reach (s.atReg pc f r (x+1) y z) (s.atReg st f r x y z) := by
  apply Reach.once
  simp [atReg,step_at pc _ h,perform,chooseZero]

theorem Slots.inc_y (s : Slots) (pc tgt : Nat) (f r : V) (h : program[pc]?=some (.inc s.y tgt))
    (safe : s.y ≠ 0 ∨ f=0) (x y z : V) :
    Reach (s.atReg pc f r x y z) (s.atReg tgt f r x (y+1) z) := by
  apply Reach.once
  simp only [atReg,step_at pc _ h,perform_inc _ _ _ _ safe,fill_y,write_y]

theorem Slots.zero_y (s : Slots) (pc zt st : Nat) (f r : V) (h : program[pc]?=some (.dec s.y zt st))
    (x y z : V) : Reach (s.atReg pc f r x 0 z) (s.atReg zt f r x 0 z) := by
  apply Reach.once
  simp [atReg,step_at pc _ h,perform,chooseZero]

theorem Slots.pos_y (s : Slots) (pc zt st : Nat) (f r : V) (h : program[pc]?=some (.dec s.y zt st))
    (x y z : V) : Reach (s.atReg pc f r x (y+1) z) (s.atReg st f r x y z) := by
  apply Reach.once
  simp [atReg,step_at pc _ h,perform,chooseZero]

theorem Slots.inc_z (s : Slots) (pc tgt : Nat) (f r : V) (h : program[pc]?=some (.inc s.z tgt))
    (safe : s.z ≠ 0 ∨ f=0) (x y z : V) :
    Reach (s.atReg pc f r x y z) (s.atReg tgt f r x y (z+1)) := by
  apply Reach.once
  simp only [atReg,step_at pc _ h,perform_inc _ _ _ _ safe,fill_z,write_z]

theorem Slots.zero_z (s : Slots) (pc zt st : Nat) (f r : V) (h : program[pc]?=some (.dec s.z zt st))
    (x y z : V) : Reach (s.atReg pc f r x y 0) (s.atReg zt f r x y 0) := by
  apply Reach.once
  simp [atReg,step_at pc _ h,perform,chooseZero]

theorem Slots.pos_z (s : Slots) (pc zt st : Nat) (f r : V) (h : program[pc]?=some (.dec s.z zt st))
    (x y z : V) : Reach (s.atReg pc f r x y (z+1)) (s.atReg st f r x y z) := by
  apply Reach.once
  simp [atReg,step_at pc _ h,perform,chooseZero]

end PA192.ModelSearch.RegisterSource
#print axioms PA192.ModelSearch.RegisterSource.Slots.pos_z
