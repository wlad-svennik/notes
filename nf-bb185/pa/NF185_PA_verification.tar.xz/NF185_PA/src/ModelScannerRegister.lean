module
public import ModelAXSource
public import ModelScannerSource
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterFields PA192.ModelSearch.RegisterCommands PA192.ModelSearch.RegisterSource
open PA192.ModelSearch.RegisterSource.Commands PA192.ModelSearch.Scanner PA192.ModelSearch.Enumeration
set_option maxRecDepth 8500
set_option maxHeartbeats 4200000
namespace PA192.ModelSearch.ScannerSource

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem view_fresh (k raw e : V) : view (fresh k raw e)=vm 10 0 k e raw := by
  simp [view,vm,atS,fresh,index,input,dataState]

theorem view_unpack (a : V) : view a=vm 10 0 (index a) (dataState a) (input a) := by
  simp [view,vm,atS]

theorem axTail (u y d c w e : V) : pi₂ (axRaw u y d c w e) = unread c w := by
  simp [axRaw,ax_ends]

theorem liveFields (k t s h p tag d w : V) (live : ¬(tag=1 ∧ h=3)) :
    let raw := cantor tag (cantor d w)
    let e := state t s h p
    Reach (vm 10 0 k e raw) (vm 0 0 k (rawAction raw e) (tail raw)) := by
  dsimp only
  rcases zeroOrSuccessor tag with rfl|⟨i,rfl⟩
  · simpa [rawAction,tail,chooseZero] using mpTagged 0 k t s p h d w
  rcases zeroOrSuccessor i with rfl|⟨c,rfl⟩
  · have neq : h≠3 := fun hh=>live ⟨by simp,hh⟩
    simpa [rawAction,tail,chooseZero] using modeTagged 0 k t s p h d w neq
  · have step := axTagged 0 k t s p h d (left w) (left (right w)) c (right (right w))
    dsimp only at step
    rw [pairUnpackTwo] at step
    have tag : c+1+1=c+2 := by ring
    have zz : c+2≠0 := by simp
    have zs : c+2-1≠0 := by rw [Enumeration.tag_succ_sub_one]; simp
    simpa only [tag,rawAction,rawAX,tail,left_cantor,right_cantor,chooseZero,zz,zs,ite_false,
      add_sub_self,vm_state,axTail] using step

theorem actualCommand {k raw e : V} (live : ¬(left raw=1 ∧ cache e=3)) :
    Reach (vm 10 0 k e raw) (vm 0 0 k (rawAction raw e) (tail raw)) := by
  have h := liveFields k (top e) (stack e) (cache e) (param e) (left raw) (left (right raw)) (right (right raw)) live
  rwa [pairUnpackTwo,state_eta] at h

theorem actualRefill (k raw result : V) :
    let c := cursor ⟪k,raw⟫
    Reach (vm 0 0 k result (tail raw)) (vm 10 0 (pi₁ c) result (pi₂ c)) := by
  dsimp only
  rcases zeroOrSuccessor (tail raw) with zero|⟨j,positive⟩
  · rw [cursor_zero zero,zero,pi₁_pair,pi₂_pair]
    exact warmRefill k result
  · have neq : tail raw≠0 := by simp [positive]
    rw [cursor_pos neq,positive,pi₁_pair,pi₂_pair]
    simpa using warmPositive k result j

/-- Every live scanner step is witnessed by an actual run on the frozen 3,089-address source, in any PA model. -/
theorem onLive (a : V) (ok : ¬ observed a) : Reach (view a) (view (next a)) := by
  let k := index a
  let raw := input a
  let e := dataState a
  have h := actualCommand (k:=k) (raw:=raw) (e:=e) ok
  rw [view_unpack,next,view_fresh]
  exact h.trans (actualRefill k raw (rawAction raw e))

/-- An observed command reaches the authentic 4095 source halt. -/
theorem onHit (a : V) (ok : observed a) : sourceHalts (view a) := by
  obtain ⟨tag,old⟩ := ok
  let k := index a
  let raw := input a
  let e := dataState a
  let p := param e
  let t := top e
  let s := stack e
  let d := left (right raw)
  let w := right (right raw)
  have code : cantor 1 (cantor d w)=raw := by
    have eq := pairUnpackTwo raw
    rw [show left raw=1 from tag] at eq
    exact eq
  have tr := modeTaggedHead 0 k t s p 3 d w
  rw [code] at tr
  have done := carryHalt tr (modeHalt 0 k t s (p+d) w)
  rw [view_unpack]
  simpa only [vm,show cache (dataState a)=3 from old,k,raw,t,s,p,e] using done

/-- The entire scanner-to-source implication now only takes its initial source-entry witness. -/
theorem halts_of_entry (start e origin : V) (entry : Reach origin (view (fresh start start e)))
    {n : V} (h : evalCode n=3) : sourceHalts origin :=
  from_source start e origin entry onHit onLive h

end PA192.ModelSearch.ScannerSource
#print axioms PA192.ModelSearch.ScannerSource.onLive
#print axioms PA192.ModelSearch.ScannerSource.onHit
#print axioms PA192.ModelSearch.ScannerSource.halts_of_entry
