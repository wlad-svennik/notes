module
public import ModelCmdEmit18
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter609 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2906:Nat):V) f (vector n 0 (atom96 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2903 f n 0 0 c (d+u) (v+y) 0 (atom96 n t s c u v y d w) w
  have d2 : (0+(atom96 n t s c u v y d w):V)=atom96 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter608 f n t s c u v y d w).trans mid

theorem commandEmitAfter610 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2910:Nat):V) f (vector n (v+y) (atom96 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2906 f n 0 (atom96 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter609 f n t s c u v y d w).trans mid

theorem commandEmitAfter611 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2913:Nat):V) f (vector n (v+y) (atom96 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2910 f n (v+y) (atom96 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter610 f n t s c u v y d w).trans mid

theorem commandEmitAfter612 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2921:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (atom95 n t s c u v y d w) w)) := by
  have micro := site2913 f n (v+y) (atom96 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom96 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom96 n t s c u v y d w):V)=0+(atom96 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom96 n t s c u v y d w)):V)=left (atom96 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom95 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom96 n t s c u v y d w)):V)=atom95 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom96 n t s c u v y d w):V)=0+(atom96 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom96 n t s c u v y d w)):V)=right (atom96 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom95 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter611 f n t s c u v y d w).trans mid

theorem commandEmitAfter613 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2924:Nat):V) f (vector n (v+y) (atom95 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2921 f n (v+y) 0 c (d+u) (v+y) (d+u) (atom95 n t s c u v y d w) w
  have d2 : (0+(atom95 n t s c u v y d w):V)=atom95 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter612 f n t s c u v y d w).trans mid

theorem commandEmitAfter614 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2934:Nat):V) f (vector n 0 (atom95 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w)) := by
  have micro := site2924 f n (v+y) (atom95 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (v+y)):V)=atom17 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (v+y)):V)=0+(atom17 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter613 f n t s c u v y d w).trans mid

theorem commandEmitAfter615 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2938:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2934 f n 0 (atom95 n t s c u v y d w) c (d+u) (v+y) 0 (atom17 n t s c u v y d w) w
  have d1 : (0+(2*(atom17 n t s c u v y d w)):V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom17 n t s c u v y d w)):V)=0+((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter614 f n t s c u v y d w).trans mid

theorem commandEmitAfter616 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2939:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2938 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w))+1:V)=(atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter615 f n t s c u v y d w).trans mid

theorem commandEmitAfter617 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2947:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w) w)) := by
  have micro := site2939 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom95 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom95 n t s c u v y d w)):V)=(atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom95 n t s c u v y d w):V)=0+(atom95 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom95 n t s c u v y d w)):V)=left (atom95 n t s c u v y d w)).trans (by change left (cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom95 n t s c u v y d w)):V)=atom86 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom95 n t s c u v y d w):V)=0+(atom95 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom95 n t s c u v y d w)):V)=right (atom95 n t s c u v y d w)).trans (by change right (cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter616 f n t s c u v y d w).trans mid

theorem commandEmitAfter618 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2950:Nat):V) f (vector n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2947 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) (atom86 n t s c u v y d w) w
  have d2 : (0+(atom86 n t s c u v y d w):V)=atom86 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter617 f n t s c u v y d w).trans mid

theorem commandEmitAfter619 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2960:Nat):V) f (vector n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 (atom97 n t s c u v y d w) w)) := by
  have micro := site2950 f n ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1) (atom86 n t s c u v y d w) c (d+u) (v+y) ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=atom97 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)+1) ((atom17 n t s c u v y d w)+(atom17 n t s c u v y d w)+1)):V)=0+(atom97 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter618 f n t s c u v y d w).trans mid

theorem commandEmitAfter620 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2964:Nat):V) f (vector n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2960 f n 0 (atom86 n t s c u v y d w) c (d+u) (v+y) 0 (atom97 n t s c u v y d w) w
  have d1 : (0+(2*(atom97 n t s c u v y d w)):V)=(atom97 n t s c u v y d w)+(atom97 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom97 n t s c u v y d w)):V)=0+((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter619 f n t s c u v y d w).trans mid

theorem commandEmitAfter621 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2966:Nat):V) f (vector n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c 0 (v+y) 0 0 w)) := by
  have micro := site2964 f n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  exact (commandEmitAfter620 f n t s c u v y d w).trans micro

theorem commandEmit (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((2968:Nat):V) f (vector n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c 0 0 0 0 w)) := by
  have micro := site2966 f n ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) c 0 (v+y) 0 0 w
  exact (commandEmitAfter621 f n t s c u v y d w).trans micro

end PA192.ModelSearch.RegisterSource.Commands
