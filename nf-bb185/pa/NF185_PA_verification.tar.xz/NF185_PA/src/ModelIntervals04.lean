module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site0784Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 784 f r x y z) (slots720.atReg 787 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 784 3 787 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 784 787 785 f r row0784)
    (slots720.pos_x 784 787 785 f r row0784)
    (slots720.inc_y 785 786 f r row0785 (Or.inl (by decide)))
    (slots720.jump 786 784 f r row0786)

theorem site0784 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((784:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((787:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0784Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0787Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 787 f r x y z) (slots617.atReg 797 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 787 10 797 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 787 791 788 f r row0787)
    (slots617.pos_y 787 791 788 f r row0787)
    (slots617.inc_z 788 789 f r row0788 (Or.inl (by decide)))
    (slots617.inc_x 789 790 f r row0789 (Or.inl (by decide)))
    (slots617.jump 790 787 f r row0790)
    (slots617.zero_x 791 797 792 f r row0791)
    (slots617.pos_x 791 797 792 f r row0791)
    (slots617.inc_z 792 793 f r row0792 (Or.inl (by decide)))
    (slots617.zero_x 793 796 794 f r row0793)
    (slots617.pos_x 793 796 794 f r row0793)
    (slots617.inc_y 794 795 f r row0794 (Or.inl (by decide)))
    (slots617.jump 795 793 f r row0795)
    (slots617.jump 796 787 f r row0796)

theorem site0787 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((787:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((797:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0787Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0797Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 797 f r x y z) (slots710.atReg 801 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 797 4 801 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 797 801 798 f r row0797)
    (slots710.pos_x 797 801 798 f r row0797)
    (slots710.inc_y 798 799 f r row0798 (Or.inl (by decide)))
    (slots710.inc_y 799 800 f r row0799 (Or.inl (by decide)))
    (slots710.jump 800 797 f r row0800)

theorem site0797 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((797:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((801:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0797Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site0801 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((801:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((802:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 801 _ row0801]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0802Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 802 f r x y z) (slots160.atReg 805 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 802 3 805 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 802 805 803 f r row0802)
    (slots160.pos_x 802 805 803 f r row0802)
    (slots160.inc_y 803 804 f r row0803 (Or.inl (by decide)))
    (slots160.jump 804 802 f r row0804)

theorem site0802 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((802:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((805:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0802Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0805Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 805 f r x y z) (slots210.atReg 808 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 805 3 808 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 805 808 806 f r row0805)
    (slots210.pos_x 805 808 806 f r row0805)
    (slots210.inc_y 806 807 f r row0806 (Or.inl (by decide)))
    (slots210.jump 807 805 f r row0807)

theorem site0805 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((805:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((808:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0805Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0808Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 808 f r x y z) (slots617.atReg 818 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 808 10 818 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 808 812 809 f r row0808)
    (slots617.pos_y 808 812 809 f r row0808)
    (slots617.inc_z 809 810 f r row0809 (Or.inl (by decide)))
    (slots617.inc_x 810 811 f r row0810 (Or.inl (by decide)))
    (slots617.jump 811 808 f r row0811)
    (slots617.zero_x 812 818 813 f r row0812)
    (slots617.pos_x 812 818 813 f r row0812)
    (slots617.inc_z 813 814 f r row0813 (Or.inl (by decide)))
    (slots617.zero_x 814 817 815 f r row0814)
    (slots617.pos_x 814 817 815 f r row0814)
    (slots617.inc_y 815 816 f r row0815 (Or.inl (by decide)))
    (slots617.jump 816 814 f r row0816)
    (slots617.jump 817 808 f r row0817)

theorem site0808 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((808:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((818:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0808Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0818Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 818 f r x y z) (slots720.atReg 821 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 818 3 821 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 818 821 819 f r row0818)
    (slots720.pos_x 818 821 819 f r row0818)
    (slots720.inc_y 819 820 f r row0819 (Or.inl (by decide)))
    (slots720.jump 820 818 f r row0820)

theorem site0818 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((818:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((821:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0818Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0821Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 821 f r x y z) (slots461.atReg 825 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 821 4 825 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 821 825 822 f r row0821)
    (slots461.pos_x 821 825 822 f r row0821)
    (slots461.inc_y 822 823 f r row0822 (Or.inl (by decide)))
    (slots461.inc_z 823 824 f r row0823 (Or.inl (by decide)))
    (slots461.jump 824 821 f r row0824)

theorem site0821 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((821:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((825:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0821Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site0825Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 825 f r x y z) (slots640.atReg 828 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 825 3 828 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 825 828 826 f r row0825)
    (slots640.pos_x 825 828 826 f r row0825)
    (slots640.inc_y 826 827 f r row0826 (Or.inl (by decide)))
    (slots640.jump 827 825 f r row0827)

theorem site0825 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((825:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((828:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0825Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site0828Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 828 f r x y z) (slots160.atReg 831 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 828 3 831 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 828 831 829 f r row0828)
    (slots160.pos_x 828 831 829 f r row0828)
    (slots160.inc_y 829 830 f r row0829 (Or.inl (by decide)))
    (slots160.jump 830 828 f r row0830)

theorem site0828 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((828:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((831:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0828Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0831Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 831 f r x y z) (slots210.atReg 834 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 831 3 834 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 831 834 832 f r row0831)
    (slots210.pos_x 831 834 832 f r row0831)
    (slots210.inc_y 832 833 f r row0832 (Or.inl (by decide)))
    (slots210.jump 833 831 f r row0833)

theorem site0831 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((831:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((834:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0831Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0834Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 834 f r x y z) (slots617.atReg 844 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 834 10 844 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 834 838 835 f r row0834)
    (slots617.pos_y 834 838 835 f r row0834)
    (slots617.inc_z 835 836 f r row0835 (Or.inl (by decide)))
    (slots617.inc_x 836 837 f r row0836 (Or.inl (by decide)))
    (slots617.jump 837 834 f r row0837)
    (slots617.zero_x 838 844 839 f r row0838)
    (slots617.pos_x 838 844 839 f r row0838)
    (slots617.inc_z 839 840 f r row0839 (Or.inl (by decide)))
    (slots617.zero_x 840 843 841 f r row0840)
    (slots617.pos_x 840 843 841 f r row0840)
    (slots617.inc_y 841 842 f r row0841 (Or.inl (by decide)))
    (slots617.jump 842 840 f r row0842)
    (slots617.jump 843 834 f r row0843)

theorem site0834 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((834:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((844:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0834Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0844Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 844 f r x y z) (slots720.atReg 847 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 844 3 847 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 844 847 845 f r row0844)
    (slots720.pos_x 844 847 845 f r row0844)
    (slots720.inc_y 845 846 f r row0845 (Or.inl (by decide)))
    (slots720.jump 846 844 f r row0846)

theorem site0844 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((844:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((847:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0844Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0847Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 847 f r x y z) (slots361.atReg 851 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 847 4 851 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 847 851 848 f r row0847)
    (slots361.pos_x 847 851 848 f r row0847)
    (slots361.inc_y 848 849 f r row0848 (Or.inl (by decide)))
    (slots361.inc_z 849 850 f r row0849 (Or.inl (by decide)))
    (slots361.jump 850 847 f r row0850)

theorem site0847 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((847:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((851:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0847Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site0851Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 851 f r x y z) (slots630.atReg 854 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 851 3 854 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 851 854 852 f r row0851)
    (slots630.pos_x 851 854 852 f r row0851)
    (slots630.inc_y 852 853 f r row0852 (Or.inl (by decide)))
    (slots630.jump 853 851 f r row0853)

theorem site0851 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((851:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((854:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0851Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site0854Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 854 f r x y z) (slots267.atReg 862 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 854 8 862 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 854 862 855 f r row0854)
    (slots267.pos_x 854 862 855 f r row0854)
    (slots267.inc_z 855 856 f r row0855 (Or.inl (by decide)))
    (slots267.zero_y 856 858 857 f r row0856)
    (slots267.pos_y 856 858 857 f r row0856)
    (slots267.jump 857 861 f r row0857)
    (slots267.zero_z 858 861 859 f r row0858)
    (slots267.pos_z 858 861 859 f r row0858)
    (slots267.inc_y 859 860 f r row0859 (Or.inl (by decide)))
    (slots267.jump 860 858 f r row0860)
    (slots267.jump 861 854 f r row0861)

theorem site0854 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((854:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((862:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0854Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0862Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 862 f r x y z) (slots720.atReg 865 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 862 3 865 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 862 865 863 f r row0862)
    (slots720.pos_x 862 865 863 f r row0862)
    (slots720.inc_y 863 864 f r row0863 (Or.inl (by decide)))
    (slots720.jump 864 862 f r row0864)

theorem site0862 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((862:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((865:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0862Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0865Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 865 f r x y z) (slots617.atReg 875 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 865 10 875 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 865 869 866 f r row0865)
    (slots617.pos_y 865 869 866 f r row0865)
    (slots617.inc_z 866 867 f r row0866 (Or.inl (by decide)))
    (slots617.inc_x 867 868 f r row0867 (Or.inl (by decide)))
    (slots617.jump 868 865 f r row0868)
    (slots617.zero_x 869 875 870 f r row0869)
    (slots617.pos_x 869 875 870 f r row0869)
    (slots617.inc_z 870 871 f r row0870 (Or.inl (by decide)))
    (slots617.zero_x 871 874 872 f r row0871)
    (slots617.pos_x 871 874 872 f r row0871)
    (slots617.inc_y 872 873 f r row0872 (Or.inl (by decide)))
    (slots617.jump 873 871 f r row0873)
    (slots617.jump 874 865 f r row0874)

theorem site0865 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((865:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((875:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0865Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0875Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 875 f r x y z) (slots710.atReg 879 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 875 4 879 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 875 879 876 f r row0875)
    (slots710.pos_x 875 879 876 f r row0875)
    (slots710.inc_y 876 877 f r row0876 (Or.inl (by decide)))
    (slots710.inc_y 877 878 f r row0877 (Or.inl (by decide)))
    (slots710.jump 878 875 f r row0878)

theorem site0875 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((875:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((879:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0875Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site0879 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((879:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((880:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 879 _ row0879]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0880Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 880 f r x y z) (slots160.atReg 883 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 880 3 883 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 880 883 881 f r row0880)
    (slots160.pos_x 880 883 881 f r row0880)
    (slots160.inc_y 881 882 f r row0881 (Or.inl (by decide)))
    (slots160.jump 882 880 f r row0882)

theorem site0880 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((880:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((883:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0880Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0883Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 883 f r x y z) (slots210.atReg 886 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 883 3 886 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 883 886 884 f r row0883)
    (slots210.pos_x 883 886 884 f r row0883)
    (slots210.inc_y 884 885 f r row0884 (Or.inl (by decide)))
    (slots210.jump 885 883 f r row0885)

theorem site0883 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((883:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((886:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0883Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0886Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 886 f r x y z) (slots617.atReg 896 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 886 10 896 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 886 890 887 f r row0886)
    (slots617.pos_y 886 890 887 f r row0886)
    (slots617.inc_z 887 888 f r row0887 (Or.inl (by decide)))
    (slots617.inc_x 888 889 f r row0888 (Or.inl (by decide)))
    (slots617.jump 889 886 f r row0889)
    (slots617.zero_x 890 896 891 f r row0890)
    (slots617.pos_x 890 896 891 f r row0890)
    (slots617.inc_z 891 892 f r row0891 (Or.inl (by decide)))
    (slots617.zero_x 892 895 893 f r row0892)
    (slots617.pos_x 892 895 893 f r row0892)
    (slots617.inc_y 893 894 f r row0893 (Or.inl (by decide)))
    (slots617.jump 894 892 f r row0894)
    (slots617.jump 895 886 f r row0895)

theorem site0886 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((886:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((896:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0886Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0896Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 896 f r x y z) (slots720.atReg 899 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 896 3 899 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 896 899 897 f r row0896)
    (slots720.pos_x 896 899 897 f r row0896)
    (slots720.inc_y 897 898 f r row0897 (Or.inl (by decide)))
    (slots720.jump 898 896 f r row0898)

theorem site0896 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((896:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((899:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0896Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0899Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 899 f r x y z) (slots461.atReg 903 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 899 4 903 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 899 903 900 f r row0899)
    (slots461.pos_x 899 903 900 f r row0899)
    (slots461.inc_y 900 901 f r row0900 (Or.inl (by decide)))
    (slots461.inc_z 901 902 f r row0901 (Or.inl (by decide)))
    (slots461.jump 902 899 f r row0902)

theorem site0899 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((899:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((903:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0899Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site0903Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 903 f r x y z) (slots640.atReg 906 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 903 3 906 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 903 906 904 f r row0903)
    (slots640.pos_x 903 906 904 f r row0903)
    (slots640.inc_y 904 905 f r row0904 (Or.inl (by decide)))
    (slots640.jump 905 903 f r row0905)

theorem site0903 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((903:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((906:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0903Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site0906Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 906 f r x y z) (slots160.atReg 909 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 906 3 909 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 906 909 907 f r row0906)
    (slots160.pos_x 906 909 907 f r row0906)
    (slots160.inc_y 907 908 f r row0907 (Or.inl (by decide)))
    (slots160.jump 908 906 f r row0908)

theorem site0906 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((906:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((909:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0906Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0909Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 909 f r x y z) (slots210.atReg 912 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 909 3 912 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 909 912 910 f r row0909)
    (slots210.pos_x 909 912 910 f r row0909)
    (slots210.inc_y 910 911 f r row0910 (Or.inl (by decide)))
    (slots210.jump 911 909 f r row0911)

theorem site0909 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((909:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((912:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0909Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0912Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 912 f r x y z) (slots617.atReg 922 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 912 10 922 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 912 916 913 f r row0912)
    (slots617.pos_y 912 916 913 f r row0912)
    (slots617.inc_z 913 914 f r row0913 (Or.inl (by decide)))
    (slots617.inc_x 914 915 f r row0914 (Or.inl (by decide)))
    (slots617.jump 915 912 f r row0915)
    (slots617.zero_x 916 922 917 f r row0916)
    (slots617.pos_x 916 922 917 f r row0916)
    (slots617.inc_z 917 918 f r row0917 (Or.inl (by decide)))
    (slots617.zero_x 918 921 919 f r row0918)
    (slots617.pos_x 918 921 919 f r row0918)
    (slots617.inc_y 919 920 f r row0919 (Or.inl (by decide)))
    (slots617.jump 920 918 f r row0920)
    (slots617.jump 921 912 f r row0921)

theorem site0912 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((912:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((922:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0912Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0922Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 922 f r x y z) (slots720.atReg 925 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 922 3 925 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 922 925 923 f r row0922)
    (slots720.pos_x 922 925 923 f r row0922)
    (slots720.inc_y 923 924 f r row0923 (Or.inl (by decide)))
    (slots720.jump 924 922 f r row0924)

theorem site0922 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((922:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((925:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0922Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0925Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 925 f r x y z) (slots561.atReg 929 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 925 4 929 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 925 929 926 f r row0925)
    (slots561.pos_x 925 929 926 f r row0925)
    (slots561.inc_y 926 927 f r row0926 (Or.inl (by decide)))
    (slots561.inc_z 927 928 f r row0927 (Or.inl (by decide)))
    (slots561.jump 928 925 f r row0928)

theorem site0925 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((925:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((929:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0925Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site0929Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 929 f r x y z) (slots650.atReg 932 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 929 3 932 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 929 932 930 f r row0929)
    (slots650.pos_x 929 932 930 f r row0929)
    (slots650.inc_y 930 931 f r row0930 (Or.inl (by decide)))
    (slots650.jump 931 929 f r row0931)

theorem site0929 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((929:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((932:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0929Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site0932Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 932 f r x y z) (slots267.atReg 940 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 932 8 940 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 932 940 933 f r row0932)
    (slots267.pos_x 932 940 933 f r row0932)
    (slots267.inc_z 933 934 f r row0933 (Or.inl (by decide)))
    (slots267.zero_y 934 936 935 f r row0934)
    (slots267.pos_y 934 936 935 f r row0934)
    (slots267.jump 935 939 f r row0935)
    (slots267.zero_z 936 939 937 f r row0936)
    (slots267.pos_z 936 939 937 f r row0936)
    (slots267.inc_y 937 938 f r row0937 (Or.inl (by decide)))
    (slots267.jump 938 936 f r row0938)
    (slots267.jump 939 932 f r row0939)

theorem site0932 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((932:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((940:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0932Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0940Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 940 f r x y z) (slots720.atReg 943 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 940 3 943 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 940 943 941 f r row0940)
    (slots720.pos_x 940 943 941 f r row0940)
    (slots720.inc_y 941 942 f r row0941 (Or.inl (by decide)))
    (slots720.jump 942 940 f r row0942)

theorem site0940 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((940:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((943:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0940Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0943Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 943 f r x y z) (slots617.atReg 953 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 943 10 953 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 943 947 944 f r row0943)
    (slots617.pos_y 943 947 944 f r row0943)
    (slots617.inc_z 944 945 f r row0944 (Or.inl (by decide)))
    (slots617.inc_x 945 946 f r row0945 (Or.inl (by decide)))
    (slots617.jump 946 943 f r row0946)
    (slots617.zero_x 947 953 948 f r row0947)
    (slots617.pos_x 947 953 948 f r row0947)
    (slots617.inc_z 948 949 f r row0948 (Or.inl (by decide)))
    (slots617.zero_x 949 952 950 f r row0949)
    (slots617.pos_x 949 952 950 f r row0949)
    (slots617.inc_y 950 951 f r row0950 (Or.inl (by decide)))
    (slots617.jump 951 949 f r row0951)
    (slots617.jump 952 943 f r row0952)

theorem site0943 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((943:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((953:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0943Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0953Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 953 f r x y z) (slots710.atReg 957 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 953 4 957 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 953 957 954 f r row0953)
    (slots710.pos_x 953 957 954 f r row0953)
    (slots710.inc_y 954 955 f r row0954 (Or.inl (by decide)))
    (slots710.inc_y 955 956 f r row0955 (Or.inl (by decide)))
    (slots710.jump 956 953 f r row0956)

theorem site0953 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((953:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((957:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0953Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

theorem site0957 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((957:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((958:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 957 _ row0957]
  simp [perform,chooseZero,vector,readReg,writeReg]

private theorem site0958Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 958 f r x y z) (slots267.atReg 966 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 958 8 966 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 958 966 959 f r row0958)
    (slots267.pos_x 958 966 959 f r row0958)
    (slots267.inc_z 959 960 f r row0959 (Or.inl (by decide)))
    (slots267.zero_y 960 962 961 f r row0960)
    (slots267.pos_y 960 962 961 f r row0960)
    (slots267.jump 961 965 f r row0961)
    (slots267.zero_z 962 965 963 f r row0962)
    (slots267.pos_z 962 965 963 f r row0962)
    (slots267.inc_y 963 964 f r row0963 (Or.inl (by decide)))
    (slots267.jump 964 962 f r row0964)
    (slots267.jump 965 958 f r row0965)

theorem site0958 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((958:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((966:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0958Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0966Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 966 f r x y z) (slots720.atReg 969 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 966 3 969 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 966 969 967 f r row0966)
    (slots720.pos_x 966 969 967 f r row0966)
    (slots720.inc_y 967 968 f r row0967 (Or.inl (by decide)))
    (slots720.jump 968 966 f r row0968)

theorem site0966 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((966:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((969:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0966Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0969Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 969 f r x y z) (slots617.atReg 979 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 969 10 979 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 969 973 970 f r row0969)
    (slots617.pos_y 969 973 970 f r row0969)
    (slots617.inc_z 970 971 f r row0970 (Or.inl (by decide)))
    (slots617.inc_x 971 972 f r row0971 (Or.inl (by decide)))
    (slots617.jump 972 969 f r row0972)
    (slots617.zero_x 973 979 974 f r row0973)
    (slots617.pos_x 973 979 974 f r row0973)
    (slots617.inc_z 974 975 f r row0974 (Or.inl (by decide)))
    (slots617.zero_x 975 978 976 f r row0975)
    (slots617.pos_x 975 978 976 f r row0975)
    (slots617.inc_y 976 977 f r row0976 (Or.inl (by decide)))
    (slots617.jump 977 975 f r row0977)
    (slots617.jump 978 969 f r row0978)

theorem site0969 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((969:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((979:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0969Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

end PA192.ModelSearch.RegisterSource.Certified
