module
public import ModelCmdEmit06
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterSource.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter225 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1122:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom37 n t s c u v y d w) w)) := by
  have micro := site1114 f n (d+u) (atom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom40 n t s c u v y d w)):V)=(atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom40 n t s c u v y d w):V)=0+(atom40 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom40 n t s c u v y d w)):V)=left (atom40 n t s c u v y d w)).trans (by change left (cantor ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom37 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom40 n t s c u v y d w)):V)=atom37 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom40 n t s c u v y d w):V)=0+(atom40 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom40 n t s c u v y d w)):V)=right (atom40 n t s c u v y d w)).trans (by change right (cantor ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom37 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter224 f n t s c u v y d w).trans mid

theorem commandEmitAfter226 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1125:Nat):V) f (vector n (d+u) (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) 0 w)) := by
  have micro := site1122 f n (d+u) 0 c (d+u) (v+y) ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (atom37 n t s c u v y d w) w
  have d2 : (0+(atom37 n t s c u v y d w):V)=atom37 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter225 f n t s c u v y d w).trans mid

theorem commandEmitAfter227 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1135:Nat):V) f (vector n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) 0 (atom41 n t s c u v y d w) w)) := by
  have micro := site1125 f n (d+u) (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) 0 w
  have d7 : (0+(cantor ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (d+u)):V)=atom41 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom39 n t s c u v y d w)+(atom39 n t s c u v y d w)+2) (d+u)):V)=0+(atom41 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter226 f n t s c u v y d w).trans mid

theorem commandEmitAfter228 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1139:Nat):V) f (vector n ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1135 f n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) 0 (atom41 n t s c u v y d w) w
  have d1 : (0+(2*(atom41 n t s c u v y d w)):V)=(atom41 n t s c u v y d w)+(atom41 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom41 n t s c u v y d w)):V)=0+((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter227 f n t s c u v y d w).trans mid

theorem commandEmitAfter229 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1140:Nat):V) f (vector n ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1139 f n ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w))+1:V)=(atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter228 f n t s c u v y d w).trans mid

theorem commandEmitAfter230 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1143:Nat):V) f (vector n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1140 f n ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1):V)=(atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter229 f n t s c u v y d w).trans mid

theorem commandEmitAfter231 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1146:Nat):V) f (vector n (atom37 n t s c u v y d w) 0 c (d+u) (v+y) ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1143 f n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom37 n t s c u v y d w):V)=atom37 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter230 f n t s c u v y d w).trans mid

theorem commandEmitAfter232 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1156:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom42 n t s c u v y d w) w)) := by
  have micro := site1146 f n (atom37 n t s c u v y d w) 0 c (d+u) (v+y) ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (atom37 n t s c u v y d w)):V)=atom42 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (atom37 n t s c u v y d w)):V)=0+(atom42 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter231 f n t s c u v y d w).trans mid

theorem commandEmitAfter233 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1159:Nat):V) f (vector n 0 (atom42 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1156 f n 0 0 c (d+u) (v+y) 0 (atom42 n t s c u v y d w) w
  have d2 : (0+(atom42 n t s c u v y d w):V)=atom42 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter232 f n t s c u v y d w).trans mid

theorem commandEmitAfter234 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1163:Nat):V) f (vector n (v+y) (atom42 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1159 f n 0 (atom42 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(v+y):V)=v+y := by ring
  have d6 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter233 f n t s c u v y d w).trans mid

theorem commandEmitAfter235 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1166:Nat):V) f (vector n (v+y) (atom42 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1163 f n (v+y) (atom42 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : (0+(v+y):V)=v+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter234 f n t s c u v y d w).trans mid

theorem commandEmitAfter236 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1174:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (atom37 n t s c u v y d w) w)) := by
  have micro := site1166 f n (v+y) (atom42 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom42 n t s c u v y d w)):V)=(atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1 := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom42 n t s c u v y d w):V)=0+(atom42 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom42 n t s c u v y d w)):V)=left (atom42 n t s c u v y d w)).trans (by change left (cantor ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (atom37 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom42 n t s c u v y d w)):V)=atom37 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom42 n t s c u v y d w):V)=0+(atom42 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom42 n t s c u v y d w)):V)=right (atom42 n t s c u v y d w)).trans (by change right (cantor ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (atom37 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter235 f n t s c u v y d w).trans mid

theorem commandEmitAfter237 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1177:Nat):V) f (vector n (v+y) (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1174 f n (v+y) 0 c (d+u) (v+y) ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (atom37 n t s c u v y d w) w
  have d2 : (0+(atom37 n t s c u v y d w):V)=atom37 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter236 f n t s c u v y d w).trans mid

theorem commandEmitAfter238 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1187:Nat):V) f (vector n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) 0 (atom43 n t s c u v y d w) w)) := by
  have micro := site1177 f n (v+y) (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (v+y)):V)=atom43 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom41 n t s c u v y d w)+(atom41 n t s c u v y d w)+1) (v+y)):V)=0+(atom43 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter237 f n t s c u v y d w).trans mid

theorem commandEmitAfter239 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1191:Nat):V) f (vector n ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1187 f n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) 0 (atom43 n t s c u v y d w) w
  have d1 : (0+(2*(atom43 n t s c u v y d w)):V)=(atom43 n t s c u v y d w)+(atom43 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom43 n t s c u v y d w)):V)=0+((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter238 f n t s c u v y d w).trans mid

theorem commandEmitAfter240 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1192:Nat):V) f (vector n ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1191 f n ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w))+1:V)=(atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter239 f n t s c u v y d w).trans mid

theorem commandEmitAfter241 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1195:Nat):V) f (vector n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1192 f n ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1) (atom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1):V)=(atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter240 f n t s c u v y d w).trans mid

theorem commandEmitAfter242 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1198:Nat):V) f (vector n (atom37 n t s c u v y d w) 0 c (d+u) (v+y) ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1195 f n 0 (atom37 n t s c u v y d w) c (d+u) (v+y) ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1) 0 w
  have d1 : (0+(atom37 n t s c u v y d w):V)=atom37 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter241 f n t s c u v y d w).trans mid

theorem commandEmitAfter243 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1208:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom44 n t s c u v y d w) w)) := by
  have micro := site1198 f n (atom37 n t s c u v y d w) 0 c (d+u) (v+y) ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1) 0 w
  have d7 : (0+(cantor ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1) (atom37 n t s c u v y d w)):V)=atom44 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor ((atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1) (atom37 n t s c u v y d w)):V)=0+(atom44 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter242 f n t s c u v y d w).trans mid

theorem commandEmitAfter244 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1211:Nat):V) f (vector n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1208 f n 0 0 c (d+u) (v+y) 0 (atom44 n t s c u v y d w) w
  have d2 : (0+(atom44 n t s c u v y d w):V)=atom44 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter243 f n t s c u v y d w).trans mid

theorem commandEmitAfter245 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1215:Nat):V) f (vector n (d+u) (atom44 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1211 f n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+(d+u):V)=d+u := by ring
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter244 f n t s c u v y d w).trans mid

theorem commandEmitAfter246 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1218:Nat):V) f (vector n (d+u) (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1215 f n (d+u) (atom44 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter245 f n t s c u v y d w).trans mid

theorem commandEmitAfter247 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1221:Nat):V) f (vector n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1218 f n (d+u) (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (0+(d+u):V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter246 f n t s c u v y d w).trans mid

theorem commandEmitAfter248 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1224:Nat):V) f (vector n (atom44 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1221 f n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : (0+(atom44 n t s c u v y d w):V)=atom44 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter247 f n t s c u v y d w).trans mid

theorem commandEmitAfter249 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1234:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (atom45 n t s c u v y d w) w)) := by
  have micro := site1224 f n (atom44 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) (atom44 n t s c u v y d w)):V)=atom45 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) (atom44 n t s c u v y d w)):V)=0+(atom45 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter248 f n t s c u v y d w).trans mid

theorem commandEmitAfter250 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1237:Nat):V) f (vector n 0 (atom45 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1234 f n 0 0 c (d+u) (v+y) 0 (atom45 n t s c u v y d w) w
  have d2 : (0+(atom45 n t s c u v y d w):V)=atom45 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter249 f n t s c u v y d w).trans mid

theorem commandEmitAfter251 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1241:Nat):V) f (vector n c (atom45 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site1237 f n 0 (atom45 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : (0+c:V)=c := by ring
  have d6 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter250 f n t s c u v y d w).trans mid

theorem commandEmitAfter252 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1244:Nat):V) f (vector n c (atom45 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1241 f n c (atom45 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : (0+c:V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter251 f n t s c u v y d w).trans mid

theorem commandEmitAfter253 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1252:Nat):V) f (vector n c 0 c (d+u) (v+y) (d+u) (atom44 n t s c u v y d w) w)) := by
  have micro := site1244 f n c (atom45 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : (left ((cantor 0 0)+(atom45 n t s c u v y d w)):V)=d+u := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom45 n t s c u v y d w):V)=0+(atom45 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom45 n t s c u v y d w)):V)=left (atom45 n t s c u v y d w)).trans (by change left (cantor (d+u) (atom44 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom45 n t s c u v y d w)):V)=atom44 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom45 n t s c u v y d w):V)=0+(atom45 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom45 n t s c u v y d w)):V)=right (atom45 n t s c u v y d w)).trans (by change right (cantor (d+u) (atom44 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter252 f n t s c u v y d w).trans mid

theorem commandEmitAfter254 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1255:Nat):V) f (vector n c (atom44 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1252 f n c 0 c (d+u) (v+y) (d+u) (atom44 n t s c u v y d w) w
  have d2 : (0+(atom44 n t s c u v y d w):V)=atom44 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter253 f n t s c u v y d w).trans mid

theorem commandEmitAfter255 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1265:Nat):V) f (vector n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) 0 (atom9 n t s c u v y d w) w)) := by
  have micro := site1255 f n c (atom44 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : (0+(cantor (d+u) c):V)=atom9 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor (d+u) c):V)=0+(atom9 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter254 f n t s c u v y d w).trans mid

theorem commandEmitAfter256 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((1269:Nat):V) f (vector n ((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w)) (atom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1265 f n 0 (atom44 n t s c u v y d w) c (d+u) (v+y) 0 (atom9 n t s c u v y d w) w
  have d1 : (0+(2*(atom9 n t s c u v y d w)):V)=(atom9 n t s c u v y d w)+(atom9 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom9 n t s c u v y d w)):V)=0+((atom9 n t s c u v y d w)+(atom9 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter255 f n t s c u v y d w).trans mid

end PA192.ModelSearch.RegisterSource.Commands
