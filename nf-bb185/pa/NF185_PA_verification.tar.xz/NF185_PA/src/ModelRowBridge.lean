module
public import ModelCmdEmit19
public import ModelCommandControl

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch.RegisterCommands
set_option maxRecDepth 15000
set_option maxHeartbeats 5000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Commands
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
theorem emittedRow0 (n t s c u v y d w : V) : row0 (u+d) (v+y) c u=(atom14 n t s c u v y d w)+(atom14 n t s c u v y d w) := by
  simp only [row0,s_one,goal_three,b_three,q,konst,eqn,app,witness,←twice_cantor,two_mul,atom14,atom13,atom12,atom9,atom6,atom4,add_assoc,add_comm,add_left_comm]

theorem emittedRow1 (n t s c u v y d w : V) : row1 (u+d) (v+y)=(atom27 n t s c u v y d w)+(atom27 n t s c u v y d w) := by
  simp only [row1,s_one,goal_three,b_three,q,konst,eqn,app,witness,←twice_cantor,two_mul,atom27,atom26,atom25,atom23,atom19,atom17,add_assoc,add_comm,add_left_comm]

theorem emittedRow2 (n t s c u v y d w : V) : row2 (u+d) (v+y) c=(atom36 n t s c u v y d w)+(atom36 n t s c u v y d w) := by
  simp only [row2,s_one,goal_three,b_three,q,konst,eqn,app,witness,←twice_cantor,two_mul,atom36,atom35,atom30,atom17,atom9,add_assoc,add_comm,add_left_comm]

theorem emittedRow3 (n t s c u v y d w : V) : row3 (u+d) (v+y)=(atom43 n t s c u v y d w)+(atom43 n t s c u v y d w)+1 := by
  simp only [row3,s_one,goal_three,b_three,q,konst,eqn,app,witness,←twice_cantor,two_mul,atom43,atom41,atom39,add_assoc,add_comm,add_left_comm]

theorem emittedRow4 (n t s c u v y d w : V) : row4 (u+d) (v+y) c=(atom51 n t s c u v y d w)+(atom51 n t s c u v y d w) := by
  simp only [row4,s_one,goal_three,b_three,q,konst,eqn,app,witness,←twice_cantor,two_mul,atom51,atom50,atom30,atom17,atom9,add_assoc,add_comm,add_left_comm]

theorem emittedRow5 (n t s c u v y d w : V) : row5 (u+d) (v+y) c=(atom66 n t s c u v y d w)+(atom66 n t s c u v y d w)+1 := by
  simp only [row5,s_one,goal_three,b_three,q,konst,eqn,app,witness,←twice_cantor,two_mul,atom66,atom65,atom62,atom58,atom56,atom54,atom39,atom17,add_assoc,add_comm,add_left_comm]

theorem emittedRow6 (n t s c u v y d w : V) : row6 (u+d) (v+y) c=(atom74 n t s c u v y d w)+(atom74 n t s c u v y d w) := by
  simp only [row6,s_one,goal_three,b_three,q,konst,eqn,app,witness,←twice_cantor,two_mul,atom74,atom73,atom30,atom17,atom9,add_assoc,add_comm,add_left_comm]

theorem emittedRow7 (n t s c u v y d w : V) : row7 (u+d) (v+y)=(atom85 n t s c u v y d w)+(atom85 n t s c u v y d w) := by
  simp only [row7,s_one,goal_three,b_three,q,konst,eqn,app,witness,←twice_cantor,two_mul,atom85,atom84,atom79,atom25,atom23,atom19,atom17,add_assoc,add_comm,add_left_comm]

theorem emittedRow8 (n t s c u v y d w : V) : row8 (u+d) (v+y)=(atom97 n t s c u v y d w)+(atom97 n t s c u v y d w) := by
  simp only [row8,s_one,goal_three,b_three,q,konst,eqn,app,witness,←twice_cantor,two_mul,atom97,atom94,atom93,atom89,atom17,add_assoc,add_comm,add_left_comm]

theorem emittedBody (n t s c u v y d w : V) :
    cantor ((atom97 n t s c u v y d w)+(atom97 n t s c u v y d w)) (atom86 n t s c u v y d w) =
      front9 (u+d) (v+y) c u (cantor t s) := by
  simp only [front9,front7,emittedRow0 n t s c u v y d w,emittedRow1 n t s c u v y d w,emittedRow2 n t s c u v y d w,emittedRow3 n t s c u v y d w,emittedRow4 n t s c u v y d w,emittedRow5 n t s c u v y d w,emittedRow6 n t s c u v y d w,emittedRow7 n t s c u v y d w,emittedRow8 n t s c u v y d w,atom15,atom28,atom37,atom44,atom52,atom67,atom75,atom86,atom2]

theorem emitFields (f n t s c u v y d w : V) :
    let body := front9 (u+d) (v+y) c u (cantor t s)
    Reach (atS 40 f n t s c u v (cantor y (cantor d w))) (atS 2968 f n (left body) (right body) c 0 0 w) := by
  dsimp only
  rw [←emittedBody n t s c u v y d w,left_cantor,right_cantor]
  exact commandEmit f n t s c u v y d w

end PA192.ModelSearch.RegisterSource.Commands
#print axioms PA192.ModelSearch.RegisterSource.Commands.emitFields
