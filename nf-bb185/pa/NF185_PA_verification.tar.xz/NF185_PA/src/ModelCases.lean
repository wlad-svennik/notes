module
public import ModelPatterns

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.ModelSearch PA192.ModelSearch.RegisterFields PA192.ModelSearch.RegisterSource
namespace PA192.PhysicalModel
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 4000000

def vWidth (i : Nat) : Width := ⟨0,some i⟩
def posWidth (i : Nat) : Width := ⟨1,some i⟩
def zeroWidth : Width := ⟨0,none⟩
def inputWidth (op : Instr) (z : Bool) (i : Nat) : Width :=
  match op with
  | .dec k _ _ => if i=k then (if z then zeroWidth else posWidth i) else vWidth i
  | _ => vWidth i
def outputWidth (op : Instr) (c z : Bool) (i : Nat) : Width :=
  match op with
  | .inc k _ => if i=k then (if c && decide (k=0) then zeroWidth else posWidth i) else vWidth i
  | .dec k _ _ => if z && decide (i=k) then zeroWidth else vWidth i
  | _ => vWidth i

def dest (op : Instr) (z : Bool) := match op with
  | .jump d | .inc _ d => d
  | .dec _ a b => if z then a else b
def exitCold (op : Instr) (c : Bool) := match op with
  | .inc 0 _ => false
  | _ => c
def gapIncr (p : Nat) (op : Instr) (z : Bool) := match op with
  | .dec .. => (!z || decide (p=3087)).toNat
  | _ => 0
def spareIncr (op : Instr) := match op with | .inc .. => 1 | _ => 0

def incoming (p : Nat) (op : Instr) (c z : Bool) : Pattern :=
  ⟨p,c,inputWidth op z,vWidth 9,vWidth 10⟩
def outgoing (p : Nat) (op : Instr) (c z : Bool) : Pattern :=
  ⟨dest op z,exitCold op c,outputWidth op c z,⟨gapIncr p op z,some 9⟩,⟨spareIncr op,some 10⟩⟩

def choiceOk (op : Instr) (z : Bool) (r : V) : Prop := match op with
  | .dec k _ _ => if z then readReg k r=0 else readReg k r≠0
  | _ => z=false
theorem chooseCase (op : Instr) (r : V) : ∃ z, choiceOk op z r := by
  cases op with
  | jump _ | inc _ _ => exact ⟨false,rfl⟩
  | dec k _ _ =>
    by_cases h : readReg k r=0
    · exact ⟨true,h⟩
    · exact ⟨false,h⟩

noncomputable def logicalFields (op : Instr) (z : Bool) (r : V) (i : Nat) : V :=
  match op with
  | .dec k _ _ => if i=k ∧ z=false then readReg i r-1 else readReg i r
  | _ => readReg i r

noncomputable def valuation (op : Instr) (z : Bool) (r gap spare : V) (j : Nat) : V :=
  if j%3=0 then
    let i := j/3-1
    if i=9 then gap else if i=10 then spare else logicalFields op z r i
  else 0

theorem valN (op : Instr) (z : Bool) (r g s : V) (i : Nat) :
    valuation op z r g s (nVar i) = if i=9 then g else if i=10 then s else logicalFields op z r i := by
  simp [valuation,nVar]
theorem valW (op : Instr) (z : Bool) (r g s : V) (i : Nat) :
    valuation op z r g s (wVar i)=0 := by
  have h : ((i+1)*3+1)%3 = 1 := by omega
  simp [valuation,wVar,h]
theorem reg_lt {i : Nat} (hi : i∈registerOrder) : i<9 := by
  simp [registerOrder] at hi; omega
theorem valRegister (op : Instr) (z : Bool) (r g s : V) {i : Nat} (hi : i∈registerOrder) :
    valuation op z r g s (nVar i)=logicalFields op z r i := by
  have h := reg_lt hi; simp [valN,show i≠9 by omega,show i≠10 by omega]

theorem valueInput (op : Instr) (z : Bool) (r g s : V) (ok : choiceOk op z r)
    (i : Nat) (hi : i∈registerOrder) :
    (inputWidth op z i).amount (valuation op z r g s)=readReg i r := by
  cases op with
  | jump _ | inc _ _ => simp [inputWidth,vWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields]
  | dec k a b =>
    by_cases eq : i=k
    · subst i
      cases z
      · have h : readReg k r≠0 := ok
        have one : 1≤readReg k r := pos_iff_one_le.mp (pos_iff_ne_zero.mpr h)
        simp [inputWidth,posWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,add_tsub_cancel_of_le one]
      · have h : readReg k r=0 := ok
        simp [inputWidth,zeroWidth,Width.amount,h]
    · simp [inputWidth,vWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,eq]

theorem read_write_if (r v : V) (j k : Nat) :
    readReg j (writeReg k r v)=if j=k then v else readReg j r := by
  by_cases h : j=k
  · subst j; simp
  · simp [h,readReg_other j k h]

theorem resulting_pc (op : Instr) (c z : Bool) (r : V) (ok : choiceOk op z r) :
    address (perform op (c.toNat:V) r)=(dest op z:Nat) := by
  cases op with
  | jump a => simp [perform,dest]
  | inc k a => cases k <;> simp [perform,dest]
  | dec k a b =>
    cases z
    · have h : readReg k r≠0 := ok; simp [perform,chooseZero,h,dest]
    · have h : readReg k r=0 := ok; simp [perform,chooseZero,h,dest]

theorem resulting_flag (op : Instr) (c z : Bool) (r : V) (ok : choiceOk op z r) :
    cold (perform op (c.toNat:V) r)=((exitCold op c).toNat:V) := by
  cases op with
  | jump a => simp [perform,exitCold]
  | inc k a => cases k <;> simp [perform,exitCold]
  | dec k a b =>
    cases z
    · have h : readReg k r≠0 := ok; simp [perform,chooseZero,h,exitCold]
    · have h : readReg k r=0 := ok; simp [perform,chooseZero,h,exitCold]

theorem valueOutput (op : Instr) (c z : Bool) (r g s : V) (ok : choiceOk op z r)
    (i : Nat) (hi : i∈registerOrder) :
    (outputWidth op c z i).amount (valuation op z r g s)=readReg i (registers (perform op (c.toNat:V) r)) := by
  cases op with
  | jump a => simp [outputWidth,vWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,perform]
  | inc k a =>
    cases k with
    | zero =>
      by_cases eq : i=0
      · subst i; cases c <;> simp [outputWidth,zeroWidth,posWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,perform,chooseZero,read_write_if,add_comm]
      · simp [outputWidth,vWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,perform,read_write_if,eq]
    | succ k =>
      by_cases eq : i=k+1
      · subst i; simp [outputWidth,posWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,perform,read_write_if,add_comm]
      · simp [outputWidth,vWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,perform,read_write_if,eq]
  | dec k a b =>
    cases z
    · have nz : readReg k r≠0 := ok
      by_cases eq : i=k
      · subst i; simp [outputWidth,vWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,perform,chooseZero,nz]
      · simp [outputWidth,vWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,perform,chooseZero,nz,read_write_if,eq]
    · have iz : readReg k r=0 := ok
      by_cases eq : i=k <;> simp [outputWidth,zeroWidth,vWidth,Width.amount,valRegister _ _ _ _ _ hi,logicalFields,perform,chooseZero,iz,read_write_if,eq]

end PA192.PhysicalModel
#print axioms PA192.PhysicalModel.valueOutput
