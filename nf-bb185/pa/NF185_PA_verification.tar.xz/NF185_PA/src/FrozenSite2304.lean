module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire2304 : String := include_str ".."/"data"/"FrozenSite2304.wire"
private def indices2304 : String := include_str ".."/"data"/"FrozenSite2304.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision2304 : (checkPayload 2304 48 wire2304 indices2304).isSome=true := by decide +native

theorem scope2304 : Scope 2304 48 := payload_sound _ _ _ _ decision2304
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope2304
