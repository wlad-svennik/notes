module
public import ModelPackage
import all ModelPackage
import all ModelBoundRows
import all ModelBranch
import all ModelCases
import all ModelPatterns
import all ModelFrames
import all ModelTagClosure
import all LiteralPaths
import all LiteralRegisterProgram
import all VerifiedWire
import all VerifiedInference
import all VerifiedReduction
import all ModelRules
import all EquationalSoundness
import all MachineTable
import all H192Rows

@[expose] public section
namespace PA192.PhysicalModel.Frozen
open Replay
set_option maxHeartbeats 0
set_option maxRecDepth 40000

private def wire0864 : String := include_str ".."/"data"/"FrozenSite0864.wire"
private def indices0864 : String := include_str ".."/"data"/"FrozenSite0864.locations"

/-- The only compiler-authorized step is the truth of this fixed finite computation. -/
private theorem decision0864 : (checkPayload 864 48 wire0864 indices0864).isSome=true := by decide +native

theorem scope0864 : Scope 864 48 := payload_sound _ _ _ _ decision0864
end PA192.PhysicalModel.Frozen
#print axioms PA192.PhysicalModel.Frozen.scope0864
