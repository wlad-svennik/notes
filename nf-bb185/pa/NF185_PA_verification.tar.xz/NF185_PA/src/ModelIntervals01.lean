module
public import ModelSlotLayouts

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.RegisterSource.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site0171Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 171 f r x y z) (slots267.atReg 179 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 171 8 179 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 171 179 172 f r row0171)
    (slots267.pos_x 171 179 172 f r row0171)
    (slots267.inc_z 172 173 f r row0172 (Or.inl (by decide)))
    (slots267.zero_y 173 175 174 f r row0173)
    (slots267.pos_y 173 175 174 f r row0173)
    (slots267.jump 174 178 f r row0174)
    (slots267.zero_z 175 178 176 f r row0175)
    (slots267.pos_z 175 178 176 f r row0175)
    (slots267.inc_y 176 177 f r row0176 (Or.inl (by decide)))
    (slots267.jump 177 175 f r row0177)
    (slots267.jump 178 171 f r row0178)

theorem site0171 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((171:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((179:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0171Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0179Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 179 f r x y z) (slots720.atReg 182 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 179 3 182 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 179 182 180 f r row0179)
    (slots720.pos_x 179 182 180 f r row0179)
    (slots720.inc_y 180 181 f r row0180 (Or.inl (by decide)))
    (slots720.jump 181 179 f r row0181)

theorem site0179 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((179:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((182:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0179Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0182Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 182 f r x y z) (slots617.atReg 192 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 182 10 192 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 182 186 183 f r row0182)
    (slots617.pos_y 182 186 183 f r row0182)
    (slots617.inc_z 183 184 f r row0183 (Or.inl (by decide)))
    (slots617.inc_x 184 185 f r row0184 (Or.inl (by decide)))
    (slots617.jump 185 182 f r row0185)
    (slots617.zero_x 186 192 187 f r row0186)
    (slots617.pos_x 186 192 187 f r row0186)
    (slots617.inc_z 187 188 f r row0187 (Or.inl (by decide)))
    (slots617.zero_x 188 191 189 f r row0188)
    (slots617.pos_x 188 191 189 f r row0188)
    (slots617.inc_y 189 190 f r row0189 (Or.inl (by decide)))
    (slots617.jump 190 188 f r row0190)
    (slots617.jump 191 182 f r row0191)

theorem site0182 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((182:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((192:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0182Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0192Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 192 f r x y z) (slots710.atReg 196 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 192 4 196 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 192 196 193 f r row0192)
    (slots710.pos_x 192 196 193 f r row0192)
    (slots710.inc_y 193 194 f r row0193 (Or.inl (by decide)))
    (slots710.inc_y 194 195 f r row0194 (Or.inl (by decide)))
    (slots710.jump 195 192 f r row0195)

theorem site0192 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((192:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((196:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0192Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site0196Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 196 f r x y z) (slots160.atReg 199 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 196 3 199 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 196 199 197 f r row0196)
    (slots160.pos_x 196 199 197 f r row0196)
    (slots160.inc_y 197 198 f r row0197 (Or.inl (by decide)))
    (slots160.jump 198 196 f r row0198)

theorem site0196 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((196:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((199:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0196Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0199Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 199 f r x y z) (slots210.atReg 202 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 199 3 202 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 199 202 200 f r row0199)
    (slots210.pos_x 199 202 200 f r row0199)
    (slots210.inc_y 200 201 f r row0200 (Or.inl (by decide)))
    (slots210.jump 201 199 f r row0201)

theorem site0199 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((199:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((202:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0199Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0202Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 202 f r x y z) (slots617.atReg 212 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 202 10 212 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 202 206 203 f r row0202)
    (slots617.pos_y 202 206 203 f r row0202)
    (slots617.inc_z 203 204 f r row0203 (Or.inl (by decide)))
    (slots617.inc_x 204 205 f r row0204 (Or.inl (by decide)))
    (slots617.jump 205 202 f r row0205)
    (slots617.zero_x 206 212 207 f r row0206)
    (slots617.pos_x 206 212 207 f r row0206)
    (slots617.inc_z 207 208 f r row0207 (Or.inl (by decide)))
    (slots617.zero_x 208 211 209 f r row0208)
    (slots617.pos_x 208 211 209 f r row0208)
    (slots617.inc_y 209 210 f r row0209 (Or.inl (by decide)))
    (slots617.jump 210 208 f r row0210)
    (slots617.jump 211 202 f r row0211)

theorem site0202 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((202:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((212:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0202Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0212Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 212 f r x y z) (slots720.atReg 215 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 212 3 215 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 212 215 213 f r row0212)
    (slots720.pos_x 212 215 213 f r row0212)
    (slots720.inc_y 213 214 f r row0213 (Or.inl (by decide)))
    (slots720.jump 214 212 f r row0214)

theorem site0212 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((212:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((215:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0212Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0215Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 215 f r x y z) (slots461.atReg 219 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 215 4 219 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 215 219 216 f r row0215)
    (slots461.pos_x 215 219 216 f r row0215)
    (slots461.inc_y 216 217 f r row0216 (Or.inl (by decide)))
    (slots461.inc_z 217 218 f r row0217 (Or.inl (by decide)))
    (slots461.jump 218 215 f r row0218)

theorem site0215 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((215:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((219:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0215Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1

private theorem site0219Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 219 f r x y z) (slots640.atReg 222 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 219 3 222 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 219 222 220 f r row0219)
    (slots640.pos_x 219 222 220 f r row0219)
    (slots640.inc_y 220 221 f r row0220 (Or.inl (by decide)))
    (slots640.jump 221 219 f r row0221)

theorem site0219 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((219:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((222:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0219Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0

private theorem site0222Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 222 f r x y z) (slots160.atReg 225 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 222 3 225 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 222 225 223 f r row0222)
    (slots160.pos_x 222 225 223 f r row0222)
    (slots160.inc_y 223 224 f r row0223 (Or.inl (by decide)))
    (slots160.jump 224 222 f r row0224)

theorem site0222 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((222:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((225:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0222Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0225Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 225 f r x y z) (slots210.atReg 228 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 225 3 228 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 225 228 226 f r row0225)
    (slots210.pos_x 225 228 226 f r row0225)
    (slots210.inc_y 226 227 f r row0226 (Or.inl (by decide)))
    (slots210.jump 227 225 f r row0227)

theorem site0225 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((225:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((228:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0225Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0228Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 228 f r x y z) (slots617.atReg 238 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 228 10 238 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 228 232 229 f r row0228)
    (slots617.pos_y 228 232 229 f r row0228)
    (slots617.inc_z 229 230 f r row0229 (Or.inl (by decide)))
    (slots617.inc_x 230 231 f r row0230 (Or.inl (by decide)))
    (slots617.jump 231 228 f r row0231)
    (slots617.zero_x 232 238 233 f r row0232)
    (slots617.pos_x 232 238 233 f r row0232)
    (slots617.inc_z 233 234 f r row0233 (Or.inl (by decide)))
    (slots617.zero_x 234 237 235 f r row0234)
    (slots617.pos_x 234 237 235 f r row0234)
    (slots617.inc_y 235 236 f r row0235 (Or.inl (by decide)))
    (slots617.jump 236 234 f r row0236)
    (slots617.jump 237 228 f r row0237)

theorem site0228 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((228:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((238:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0228Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0238Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 238 f r x y z) (slots720.atReg 241 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 238 3 241 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 238 241 239 f r row0238)
    (slots720.pos_x 238 241 239 f r row0238)
    (slots720.inc_y 239 240 f r row0239 (Or.inl (by decide)))
    (slots720.jump 240 238 f r row0240)

theorem site0238 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((238:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((241:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0238Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0241Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 241 f r x y z) (slots361.atReg 245 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 241 4 245 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 241 245 242 f r row0241)
    (slots361.pos_x 241 245 242 f r row0241)
    (slots361.inc_y 242 243 f r row0242 (Or.inl (by decide)))
    (slots361.inc_z 243 244 f r row0243 (Or.inl (by decide)))
    (slots361.jump 244 241 f r row0244)

theorem site0241 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((241:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((245:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0241Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site0245Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 245 f r x y z) (slots630.atReg 248 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 245 3 248 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 245 248 246 f r row0245)
    (slots630.pos_x 245 248 246 f r row0245)
    (slots630.inc_y 246 247 f r row0246 (Or.inl (by decide)))
    (slots630.jump 247 245 f r row0247)

theorem site0245 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((245:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((248:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0245Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site0248Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 248 f r x y z) (slots267.atReg 256 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 248 8 256 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 248 256 249 f r row0248)
    (slots267.pos_x 248 256 249 f r row0248)
    (slots267.inc_z 249 250 f r row0249 (Or.inl (by decide)))
    (slots267.zero_y 250 252 251 f r row0250)
    (slots267.pos_y 250 252 251 f r row0250)
    (slots267.jump 251 255 f r row0251)
    (slots267.zero_z 252 255 253 f r row0252)
    (slots267.pos_z 252 255 253 f r row0252)
    (slots267.inc_y 253 254 f r row0253 (Or.inl (by decide)))
    (slots267.jump 254 252 f r row0254)
    (slots267.jump 255 248 f r row0255)

theorem site0248 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((248:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((256:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0248Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0256Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 256 f r x y z) (slots720.atReg 259 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 256 3 259 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 256 259 257 f r row0256)
    (slots720.pos_x 256 259 257 f r row0256)
    (slots720.inc_y 257 258 f r row0257 (Or.inl (by decide)))
    (slots720.jump 258 256 f r row0258)

theorem site0256 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((256:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((259:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0256Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0259Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 259 f r x y z) (slots617.atReg 269 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 259 10 269 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 259 263 260 f r row0259)
    (slots617.pos_y 259 263 260 f r row0259)
    (slots617.inc_z 260 261 f r row0260 (Or.inl (by decide)))
    (slots617.inc_x 261 262 f r row0261 (Or.inl (by decide)))
    (slots617.jump 262 259 f r row0262)
    (slots617.zero_x 263 269 264 f r row0263)
    (slots617.pos_x 263 269 264 f r row0263)
    (slots617.inc_z 264 265 f r row0264 (Or.inl (by decide)))
    (slots617.zero_x 265 268 266 f r row0265)
    (slots617.pos_x 265 268 266 f r row0265)
    (slots617.inc_y 266 267 f r row0266 (Or.inl (by decide)))
    (slots617.jump 267 265 f r row0267)
    (slots617.jump 268 259 f r row0268)

theorem site0259 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((259:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((269:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0259Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0269Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 269 f r x y z) (slots710.atReg 273 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 269 4 273 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 269 273 270 f r row0269)
    (slots710.pos_x 269 273 270 f r row0269)
    (slots710.inc_y 270 271 f r row0270 (Or.inl (by decide)))
    (slots710.inc_y 271 272 f r row0271 (Or.inl (by decide)))
    (slots710.jump 272 269 f r row0272)

theorem site0269 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((269:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((273:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0269Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site0273Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 273 f r x y z) (slots160.atReg 276 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 273 3 276 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 273 276 274 f r row0273)
    (slots160.pos_x 273 276 274 f r row0273)
    (slots160.inc_y 274 275 f r row0274 (Or.inl (by decide)))
    (slots160.jump 275 273 f r row0275)

theorem site0273 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((273:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((276:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0273Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0276Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 276 f r x y z) (slots210.atReg 279 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 276 3 279 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 276 279 277 f r row0276)
    (slots210.pos_x 276 279 277 f r row0276)
    (slots210.inc_y 277 278 f r row0277 (Or.inl (by decide)))
    (slots210.jump 278 276 f r row0278)

theorem site0276 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((276:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((279:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0276Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0279Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 279 f r x y z) (slots617.atReg 289 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 279 10 289 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 279 283 280 f r row0279)
    (slots617.pos_y 279 283 280 f r row0279)
    (slots617.inc_z 280 281 f r row0280 (Or.inl (by decide)))
    (slots617.inc_x 281 282 f r row0281 (Or.inl (by decide)))
    (slots617.jump 282 279 f r row0282)
    (slots617.zero_x 283 289 284 f r row0283)
    (slots617.pos_x 283 289 284 f r row0283)
    (slots617.inc_z 284 285 f r row0284 (Or.inl (by decide)))
    (slots617.zero_x 285 288 286 f r row0285)
    (slots617.pos_x 285 288 286 f r row0285)
    (slots617.inc_y 286 287 f r row0286 (Or.inl (by decide)))
    (slots617.jump 287 285 f r row0287)
    (slots617.jump 288 279 f r row0288)

theorem site0279 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((279:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((289:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0279Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0289Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 289 f r x y z) (slots720.atReg 292 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 289 3 292 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 289 292 290 f r row0289)
    (slots720.pos_x 289 292 290 f r row0289)
    (slots720.inc_y 290 291 f r row0290 (Or.inl (by decide)))
    (slots720.jump 291 289 f r row0291)

theorem site0289 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((289:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((292:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0289Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0292Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 292 f r x y z) (slots561.atReg 296 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 292 4 296 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 292 296 293 f r row0292)
    (slots561.pos_x 292 296 293 f r row0292)
    (slots561.inc_y 293 294 f r row0293 (Or.inl (by decide)))
    (slots561.inc_z 294 295 f r row0294 (Or.inl (by decide)))
    (slots561.jump 295 292 f r row0295)

theorem site0292 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((292:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((296:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0292Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1

private theorem site0296Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 296 f r x y z) (slots650.atReg 299 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 296 3 299 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 296 299 297 f r row0296)
    (slots650.pos_x 296 299 297 f r row0296)
    (slots650.inc_y 297 298 f r row0297 (Or.inl (by decide)))
    (slots650.jump 298 296 f r row0298)

theorem site0296 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((296:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((299:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0296Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

private theorem site0299Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 299 f r x y z) (slots160.atReg 302 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 299 3 302 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 299 302 300 f r row0299)
    (slots160.pos_x 299 302 300 f r row0299)
    (slots160.inc_y 300 301 f r row0300 (Or.inl (by decide)))
    (slots160.jump 301 299 f r row0301)

theorem site0299 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((299:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((302:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0299Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0

private theorem site0302Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 302 f r x y z) (slots210.atReg 305 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 302 3 305 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 302 305 303 f r row0302)
    (slots210.pos_x 302 305 303 f r row0302)
    (slots210.inc_y 303 304 f r row0303 (Or.inl (by decide)))
    (slots210.jump 304 302 f r row0304)

theorem site0302 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((302:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((305:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0302Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0

private theorem site0305Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 305 f r x y z) (slots617.atReg 315 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 305 10 315 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 305 309 306 f r row0305)
    (slots617.pos_y 305 309 306 f r row0305)
    (slots617.inc_z 306 307 f r row0306 (Or.inl (by decide)))
    (slots617.inc_x 307 308 f r row0307 (Or.inl (by decide)))
    (slots617.jump 308 305 f r row0308)
    (slots617.zero_x 309 315 310 f r row0309)
    (slots617.pos_x 309 315 310 f r row0309)
    (slots617.inc_z 310 311 f r row0310 (Or.inl (by decide)))
    (slots617.zero_x 311 314 312 f r row0311)
    (slots617.pos_x 311 314 312 f r row0311)
    (slots617.inc_y 312 313 f r row0312 (Or.inl (by decide)))
    (slots617.jump 313 311 f r row0313)
    (slots617.jump 314 305 f r row0314)

theorem site0305 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((305:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((315:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0305Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0315Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 315 f r x y z) (slots720.atReg 318 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 315 3 318 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 315 318 316 f r row0315)
    (slots720.pos_x 315 318 316 f r row0315)
    (slots720.inc_y 316 317 f r row0316 (Or.inl (by decide)))
    (slots720.jump 317 315 f r row0317)

theorem site0315 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((315:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((318:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0315Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0318Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 318 f r x y z) (slots361.atReg 322 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 318 4 322 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 318 322 319 f r row0318)
    (slots361.pos_x 318 322 319 f r row0318)
    (slots361.inc_y 319 320 f r row0319 (Or.inl (by decide)))
    (slots361.inc_z 320 321 f r row0320 (Or.inl (by decide)))
    (slots361.jump 321 318 f r row0321)

theorem site0318 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((318:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((322:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0318Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1

private theorem site0322Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 322 f r x y z) (slots630.atReg 325 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 322 3 325 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 322 325 323 f r row0322)
    (slots630.pos_x 322 325 323 f r row0322)
    (slots630.inc_y 323 324 f r row0323 (Or.inl (by decide)))
    (slots630.jump 324 322 f r row0324)

theorem site0322 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((322:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((325:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0322Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0

private theorem site0325Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 325 f r x y z) (slots267.atReg 333 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 325 8 333 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 325 333 326 f r row0325)
    (slots267.pos_x 325 333 326 f r row0325)
    (slots267.inc_z 326 327 f r row0326 (Or.inl (by decide)))
    (slots267.zero_y 327 329 328 f r row0327)
    (slots267.pos_y 327 329 328 f r row0327)
    (slots267.jump 328 332 f r row0328)
    (slots267.zero_z 329 332 330 f r row0329)
    (slots267.pos_z 329 332 330 f r row0329)
    (slots267.inc_y 330 331 f r row0330 (Or.inl (by decide)))
    (slots267.jump 331 329 f r row0331)
    (slots267.jump 332 325 f r row0332)

theorem site0325 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((325:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((333:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0325Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0333Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 333 f r x y z) (slots720.atReg 336 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 333 3 336 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 333 336 334 f r row0333)
    (slots720.pos_x 333 336 334 f r row0333)
    (slots720.inc_y 334 335 f r row0334 (Or.inl (by decide)))
    (slots720.jump 335 333 f r row0335)

theorem site0333 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((333:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((336:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0333Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0336Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 336 f r x y z) (slots617.atReg 346 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 336 10 346 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 336 340 337 f r row0336)
    (slots617.pos_y 336 340 337 f r row0336)
    (slots617.inc_z 337 338 f r row0337 (Or.inl (by decide)))
    (slots617.inc_x 338 339 f r row0338 (Or.inl (by decide)))
    (slots617.jump 339 336 f r row0339)
    (slots617.zero_x 340 346 341 f r row0340)
    (slots617.pos_x 340 346 341 f r row0340)
    (slots617.inc_z 341 342 f r row0341 (Or.inl (by decide)))
    (slots617.zero_x 342 345 343 f r row0342)
    (slots617.pos_x 342 345 343 f r row0342)
    (slots617.inc_y 343 344 f r row0343 (Or.inl (by decide)))
    (slots617.jump 344 342 f r row0344)
    (slots617.jump 345 336 f r row0345)

theorem site0336 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((336:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((346:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0336Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0346Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 346 f r x y z) (slots710.atReg 350 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 346 4 350 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 346 350 347 f r row0346)
    (slots710.pos_x 346 350 347 f r row0346)
    (slots710.inc_y 347 348 f r row0347 (Or.inl (by decide)))
    (slots710.inc_y 348 349 f r row0348 (Or.inl (by decide)))
    (slots710.jump 349 346 f r row0349)

theorem site0346 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((346:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((350:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0346Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site0350Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 350 f r x y z) (slots267.atReg 358 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 350 8 358 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 350 358 351 f r row0350)
    (slots267.pos_x 350 358 351 f r row0350)
    (slots267.inc_z 351 352 f r row0351 (Or.inl (by decide)))
    (slots267.zero_y 352 354 353 f r row0352)
    (slots267.pos_y 352 354 353 f r row0352)
    (slots267.jump 353 357 f r row0353)
    (slots267.zero_z 354 357 355 f r row0354)
    (slots267.pos_z 354 357 355 f r row0354)
    (slots267.inc_y 355 356 f r row0355 (Or.inl (by decide)))
    (slots267.jump 356 354 f r row0356)
    (slots267.jump 357 350 f r row0357)

theorem site0350 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((350:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((358:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0350Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0358Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 358 f r x y z) (slots720.atReg 361 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 358 3 361 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 358 361 359 f r row0358)
    (slots720.pos_x 358 361 359 f r row0358)
    (slots720.inc_y 359 360 f r row0359 (Or.inl (by decide)))
    (slots720.jump 360 358 f r row0360)

theorem site0358 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((358:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((361:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0358Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

private theorem site0361Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 361 f r x y z) (slots617.atReg 371 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 361 10 371 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 361 365 362 f r row0361)
    (slots617.pos_y 361 365 362 f r row0361)
    (slots617.inc_z 362 363 f r row0362 (Or.inl (by decide)))
    (slots617.inc_x 363 364 f r row0363 (Or.inl (by decide)))
    (slots617.jump 364 361 f r row0364)
    (slots617.zero_x 365 371 366 f r row0365)
    (slots617.pos_x 365 371 366 f r row0365)
    (slots617.inc_z 366 367 f r row0366 (Or.inl (by decide)))
    (slots617.zero_x 367 370 368 f r row0367)
    (slots617.pos_x 367 370 368 f r row0367)
    (slots617.inc_y 368 369 f r row0368 (Or.inl (by decide)))
    (slots617.jump 369 367 f r row0369)
    (slots617.jump 370 361 f r row0370)

theorem site0361 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((361:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((371:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0361Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7

private theorem site0371Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 371 f r x y z) (slots710.atReg 375 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 371 4 375 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 371 375 372 f r row0371)
    (slots710.pos_x 371 375 372 f r row0371)
    (slots710.inc_y 372 373 f r row0372 (Or.inl (by decide)))
    (slots710.inc_y 373 374 f r row0373 (Or.inl (by decide)))
    (slots710.jump 374 371 f r row0374)

theorem site0371 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((371:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((375:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0371Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0

private theorem site0375Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 375 f r x y z) (slots267.atReg 383 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 375 8 383 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 375 383 376 f r row0375)
    (slots267.pos_x 375 383 376 f r row0375)
    (slots267.inc_z 376 377 f r row0376 (Or.inl (by decide)))
    (slots267.zero_y 377 379 378 f r row0377)
    (slots267.pos_y 377 379 378 f r row0377)
    (slots267.jump 378 382 f r row0378)
    (slots267.zero_z 379 382 380 f r row0379)
    (slots267.pos_z 379 382 380 f r row0379)
    (slots267.inc_y 380 381 f r row0380 (Or.inl (by decide)))
    (slots267.jump 381 379 f r row0381)
    (slots267.jump 382 375 f r row0382)

theorem site0375 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((375:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((383:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0375Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7

private theorem site0383Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 383 f r x y z) (slots720.atReg 386 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 383 3 386 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 383 386 384 f r row0383)
    (slots720.pos_x 383 386 384 f r row0383)
    (slots720.inc_y 384 385 f r row0384 (Or.inl (by decide)))
    (slots720.jump 385 383 f r row0385)

theorem site0383 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((383:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((386:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0383Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0

end PA192.ModelSearch.RegisterSource.Certified
