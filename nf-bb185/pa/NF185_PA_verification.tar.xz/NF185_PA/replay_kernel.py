"""Check all 185-state tape-to-register local branch witnesses in the Lean kernel.

Compile NF185PATapeBatchCheck and NF185PATapeCompiler first. Pass their build
directory and dependency LEAN_PATH to this independent replay.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

PIN = "eb6cafb7290e8bd5f2937522d8d804f58f02bafc"
COUNT = 2959
BATCH = 32
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}


def bracket(names):
    if len(names) == 1:
        return names[0]
    m = len(names) // 2
    return f"(Coverage.join {bracket(names[:m])} {bracket(names[m:])})"


def case_module(lo, rows):
    lines = ["import NF185PATapeBatchCheck", "namespace NF185PA.Symbolic",
             "set_option maxRecDepth 200000", "set_option maxHeartbeats 0",
             "set_option linter.unusedSimpArgs false"]
    for pc, values in enumerate(rows, lo):
        tuple_text = "(" + ",".join(map(str, values)) + ")"
        checked = []
        for j, w in enumerate(values):
            if w:
                cold, positive = ("true" if b else "false" for b in divmod(j, 2))
                name = f"w{pc}_{j}"
                lines.append(f"private theorem {name} : checkWitness {pc} {cold} {positive} {w} = true := by decide +kernel")
                checked.append(name)
        lines.extend([
            f"private theorem cases{pc} : checkFour {pc} {tuple_text} = true := by",
            f"  simp only [checkFour, {', '.join(checked)}, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel",
            f"private theorem one{pc} : Coverage {pc} {pc+1} := checkList_sound (ws:=[{tuple_text}]) (by simpa only [checkList, Bool.and_true] using cases{pc})",
        ])
    hi = lo + len(rows)
    theorem = f"cover{lo:04d}"
    lines.extend([f"theorem {theorem} : Coverage {lo} {hi} := {bracket([f'one{i}' for i in range(lo, hi)])}",
                  "end NF185PA.Symbolic"])
    return f"NF185PATapeCases{lo//BATCH:03d}", theorem, "\n".join(lines) + "\n"


def read_witnesses(path):
    with path.open() as handle:
        records = list(csv.reader(handle))
    if records[0] != ["pc", "warm_zero", "warm_positive", "cold_zero", "cold_positive"]:
        raise ValueError("Invalid witness header")
    if len(records) != COUNT + 1:
        raise ValueError("Incomplete program")
    rows = []
    for pc, record in enumerate(records[1:]):
        if len(record) != 5 or int(record[0]) != pc:
            raise ValueError(f"Invalid address {pc}")
        vals = list(map(int, record[1:]))
        if min(vals) < 0 or max(vals) >= 16384:
            raise ValueError(f"Invalid witness at {pc}")
        rows.append(vals)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--theory-build", required=True, type=Path)
    parser.add_argument("--work", required=True, type=Path)
    parser.add_argument("--lean", default="lean")
    parser.add_argument("--jobs", type=int, default=2)
    args = parser.parse_args()
    version = subprocess.check_output([args.lean, "--version"], text=True).strip()
    if PIN not in version or args.jobs < 1:
        parser.error("Use the pinned Lean compiler and a positive worker count")
    theory = args.theory_build.resolve()
    if any(not (theory/(m+".olean")).is_file() for m in ("NF185PATapeBatchCheck",)):
        parser.error("Compile NF185PATapeBatchCheck into the theory directory")
    root = args.work.resolve()
    root.mkdir(parents=True, exist_ok=False)
    witness = Path(__file__).with_name("witnesses.csv")
    rows = read_witnesses(witness)
    modules = [case_module(lo, rows[lo:lo+BATCH]) for lo in range(0, COUNT, BATCH)]
    paths = [root, theory, *filter(None, os.environ.get("LEAN_PATH", "").split(os.pathsep))]
    env = {**os.environ, "LEAN_PATH": os.pathsep.join(map(str, paths))}

    def build(entry):
        name, _, source = entry
        file = root/(name+".lean")
        file.write_text(source)
        command = [args.lean, "-j1", "-s", "131072", "-o", str(root/(name+".olean")), file.name]
        result = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True)
        log = result.stdout + result.stderr
        (root/(name+".log")).write_text(log)
        if result.returncode or re.search(r"\bsorry(?:Ax)?\b", log):
            raise RuntimeError(f"{name} failed\n{log[-2200:]}")
        print(name, flush=True)
        return log

    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        list(pool.map(build, modules))
    theorem = "literal_table_coverage"
    source = "\n".join("import "+m for m, _, _ in modules)
    source += f"\nnamespace NF185PA.Symbolic\ntheorem {theorem} : Coverage 0 {COUNT} := " + bracket([t for _, t, _ in modules])
    source += f"\n#print axioms {theorem}\nend NF185PA.Symbolic\n"
    log = build(("NF185PATapeAll", theorem, source))
    match = re.search(rf"'NF185PA.Symbolic.{theorem}' depends on axioms: \[([^\]]*)\]", log)
    if not match or set(a.strip() for a in match[1].split(",")) - ALLOWED:
        raise RuntimeError("Could not audit the table coverage theorem")
    transfer = """import NF185PATapeAll
import NF185PATapeCompiler
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
namespace NF185PA.Symbolic.Kernel
theorem tape_of_register_halt {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
    (h : ∃ j : V, PA192.ModelSearch.RegisterSource.address (Registers.run j)=4095) :
    V ⊧/![] H185 := tape_of_coverage literal_table_coverage h
#print axioms tape_of_register_halt
end NF185PA.Symbolic.Kernel
"""
    end_name = "NF185PA.Symbolic.Kernel.tape_of_register_halt"
    end_log = build(("NF185PATapeKernelRun", end_name, transfer))
    end_report = re.search(rf"'{re.escape(end_name)}' depends on axioms: \[([^\]]*)\]", end_log)
    if not end_report or set(a.strip() for a in end_report[1].split(",")) - ALLOWED:
        raise RuntimeError("Could not audit the all-model tape compiler theorem")
    receipt = {"lean": version, "witness_sha256": hashlib.sha256(witness.read_bytes()).hexdigest(),
               "source_addresses": COUNT, "enabled_branches": sum(bool(w) for row in rows for w in row),
               "theorem": "NF185PA.Symbolic."+theorem, "all_model_theorem": end_name, "axioms": sorted(a.strip() for a in match[1].split(","))}
    (root/"tape-receipt.json").write_text(json.dumps(receipt, indent=2)+"\n")


if __name__ == "__main__":
    main()
