# Internal eight-row proof search

Let $V$ be any model of first-order Peano arithmetic. All ranks, proof pools, command words, candidate indices, and iteration counts below are elements of $V$. The induction proofs use the model's induction scheme for definable predicates. 

## Proofs and emitted rows

`NF185PAPool.lean` uses a coded finite set of pairs $(k,p)$ as a ranked proof. A line is an instance of one of the eight emitted rows, an assumption, or an MP conclusion whose two premises occur at smaller ranks. The table gives the arithmetic names in the actual emitter order.

| Position in the emitted batch | Arithmetic expression |
| --- | --- |
| 1 | `row0 a b c u` |
| 2 | `row3 a b` (constant-function law) |
| 3 | `nativeB a b c` |
| 4 | `row2 a b c` |
| 5 | `row4 a b c` |
| 6 | `row6 a b c` |
| 7 | `test b a` |
| 8 | `row8 a b` (the extensionality witness) |

The first row is restricted by $u\le a$. The third uses $s=q q$ as its leading combinator. On standard naturals, `NF185PAPoolNat.lean` proves that this list is exactly the published eight-row list and that proof from the empty context is equivalent to `Eight187.Deriv`.

## The accumulator and the missing last row

The AX fields supply $u,y,d,c$ and a tail. If the incoming parameter and cache are $p,h$, the first emitted batch uses $(a,b,c,u')=(p+u+d,h+y,c,p+u)$. At each following pair of fields $(y',d')$, the updated parameters are $a+d',b+y'$, and the bound supplied to the first row is the previous $a$. The count drops by one. `Packed.next_literal` expresses this transition over Cantor-packed data.

The AX exit compares the incoming cache $b$ with the formula `imp (row8 a b) a`. The latter strictly exceeds $b$. The numerical constructors give $b\le\operatorname{imp}(a,b)<\operatorname{eqn}(a,b)\le\operatorname{row8}(a,b)\le\operatorname{imp}(\operatorname{row8}(a,b),a)$. Consequently the comparison fails, the top becomes zero, the last emitted row is discarded, and NIP moves the next row to the cache.

For an AX command of count zero, the six earliest rows remain on the stack and the seventh is cached. Each can be selected by finitely many NIPs, a SWAP, and enough NIPs to restore the saved stack. The discarded eighth row is independent of the count, so the compiler requests count one with a zero pair of fields. The first batch then lies intact under the final batch. For any positive count $j+1$, the same construction exposes the entire first batch after $6+8j$ NIPs. The model-inductive theorems `zero_batches_run` and `strip_higher` establish this also for nonstandard $j$.

## Proofs become observations

A command word produces formula $x$ if, for any starting registers $t,s,h,p$, it leaves $x$ on top, pushes the old $t$ over the old stack $s$, clears the parameter, and leaves some cache. The reset word uses two zero-argument AX sweeps and an MP command. For MP, the compiler runs reset, produces the minor, produces the major, then executes NIP, SWAP, and deduction with the desired consequent. The deduction comparison succeeds and its automatic pop restores the stack required by the invariant.

Obtainability by such a word is definable over $V$. It contains every emitted axiom and is closed under MP. Induction on the ranks of the coded proof therefore gives `Commands.proof_produces`. The scanner's packed instruction tag zero selects NIP or SWAP and observes the cache before execution. A word that produces the goal, whose numerical code is 3, can append a SWAP and a tag-zero command. Every prescribed finite command prefix occurs in the unbounded candidate enumeration after every starting index. `Scanner.pool_forces_observation` concludes that, from every fresh index and every initial proof state, the internal scanner reaches a goal observation.

## Signed source entry

`Registers.next` dispatches the exact 2,959 source instructions. The initial physical margin has PC 118, sign flag 1 and register vector $(0,0,0,2,0,0,0,1,0)$. The earlier signed entry at PC 40 has the same vector except that register 7 is zero. The independent literal prefix theorem checks the 98 steps between these configurations. For a deterministic iteration, executing first $k$ then $t$ steps gives the same state as executing first $t$ then $k$. Since address 4095 is absorbing, `Boot.halts_after_prefix` transports any terminal observation at the earlier entry to one at the margin. This argument also works if the putative first halt would occur within the prefix.

The literal command, control, and tape certificates connect `Scanner.pool_forces_observation` to the published transition table.

## The original 192-state machine, in the reverse direction

The old machine has nine rows, different command semantics, and its own literal arithmetic halting sentence. The following files refer to that original machine.

* `NF192PAScannerSound.lean` defines a stack to be sound if, after any internal number of tail operations, its head admits an internal nine-row proof. The implied infinite extension by zero is sound because zero is derivable. A whole emitted batch preserves this property. PA induction covers repeated batches of arbitrary internal length. It follows that every top, cache, and stack entry after a scanner operation is derivable whenever the input was sound. An observation therefore proves the nine-row goal.
* `NF192PASoundEntry.lean` strengthens the published signed startup theorem at source margin PC 91. It identifies the first emitted body with the first literal batch using `emittedBody`, follows the next two literal batches, then proves that the actual warmed-up scanner state is sound.
* `NF192PACofinal.lean` proves that a coded physical halt forces a scanner observation. Suppose there were a physical halt and every command stayed live. A live command reaches source PC 0 from PC 10, and the refill returns to PC 10. The old local physical simulation carries each of those segments into the same deterministic tape trajectory. The lexical address words for PC 0 and PC 10 are `00000` and `00100`. Their third low-order bit differs, so the two instants cannot coincide, regardless of register values or padding. Each complete command thus advances physical time by at least one. Internal induction gives a live PC 10 at a time at least $j$ for every $j\in V$. Take $j$ equal to the alleged halting time. The halted arithmetic tape is absorbing, whereas the control of every live frame is 13. This contradiction supplies an internally timed observation.
* `NF192PAHaltSound.lean` combines these proofs. Its theorem `h192_implies_proof_of_scope` assumes only the original finite table-coverage proposition `Scope 0 3089`. Its Lean axiom report lists `propext`, `Classical.choice`, and `Quot.sound`.
* `NF192PAFrozenSound.lean` supplies the published `Frozen.all_original_sites` to that theorem. The concrete conclusion is `V ⊧ H192 → PA192.Literal.ProofPool.Pr ∅ goal`. Its axiom report also names the 65 specific native transcript validation decisions from the original release. That release records an independent Lean IR replay and separate PRA checker. The individual tape certificates and their verification are inherited inputs for this corollary.

The old and new `Pr` relations refer to their respective calculi. The model-uniform implication from an old proof to a new proof is a separate interpretation theorem.
