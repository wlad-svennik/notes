# From the eight numerical rows to consistency inside PA

Fix any model $V$ of first-order PA. The ranks, proof-pool codes, and
register contents below range over all of $V$. In particular a rank may
be nonstandard. The halting target has code $3$.

Suppose the empty-context ranked pool in $V$ has no proof of $3$.
The arithmetic Lindenbaum construction gives a definable relation $E(x,y)$
by testing membership of the numerical equality formula in the saturated
theory. Its implication connective has the classical truth condition. Every
literal axiom row belongs to the saturated theory. Constant functions and
the Euclidean equality row imply reflexivity and symmetry. Symmetry converts
each of the three reversed atomic equalities in the printed tester into
the orientation used by `NF196.Compact.Rows`. The false goal gives
$\neg E(S,J)$, where the archive letter $J$ is the term $q$ and
$S=JJ$ is the composition combinator.

The quotient $V/E$ supports the operation
$D(x,y)=J(Kx)y$. The tester row and $S\ne J$ give
$D(x,y)=S$ whenever $x\ne y$, and $D(x,x)\ne S$ for every $x$.
The weak-tester construction realizes FunctionNF with true value $S$
and false value $D(S,S)$. On representatives its membership relation is

```
rawMem(x,y)  iff  (forall u, E(yu,S) or E(yu,D(S,S))) and E(yx,S).
```

This expression is definable in $V$. Each class has a representative,
and equality of representatives in the quotient is precisely $E$.
These properties give an arithmetic presentation of the quotient
membership structure.

Apply the fixed Jensen NFUI theorem `jensen_arithmeticSeed` to this
structure. The represented-truth theorem `truthOfPresentation` then gives
a truth object covering the syntax and proof codes of $V$ itself. An
internal proof of PA falsum would contradict its soundness. The checked
conclusion is

```lean
NF185PA.Pool.no_refutation_implies_pa_consistency
  (hd : ¬Pr (∅ : V) goal) : ¬Provable 𝗣𝗔 (qqFalsum : V)
```

`NF185PAChartTruth.lean` proves the quotient and presentation step for
any definable eight-row relation. `NF185PACountermodel.lean` specializes it
to the exact numerical proof pool. Both endpoint axiom audits contain
`propext`, `Classical.choice`, and `Quot.sound`.

The separate scanner, register, and tape arguments connect this statement
to the first-order halting sentence for the released table. Their required
direction sends a pool refutation in $V$ to a physical halting clock
in $V$.
