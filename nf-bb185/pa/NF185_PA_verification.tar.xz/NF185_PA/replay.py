"""Build the requested Lean proof and verify the compiled axiom reports."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PIN = 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
IMPORT = re.compile(r'^\s*(?:(?:public|meta|private)\s+)*import\s+(?:all\s+)?([\w.]+)', re.M)
AUDIT = re.compile(r"'([^']+)' depends on axioms: \[([^\]]*)\]", re.S)
CORE = {'propext', 'Classical.choice', 'Quot.sound'}


def relative(module, extension):
    return Path(*module.split('.')).with_suffix(extension)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def output_hashes(build, module):
    outputs={}
    for suffix in ('.olean','.olean.private','.olean.server','.ir','.ir.sig'):
        path=build/relative(module,suffix)
        if path.is_file():
            outputs[suffix]=digest(path)
    return outputs


def verify_file_list(jobs):
    manifest = ROOT / 'SHA256SUMS'
    missing = []
    for line in manifest.read_text().splitlines():
        expected, name = line.split('  ', 1)
        path = ROOT / name
        if name.startswith('data/FrozenSite') and not path.exists():
            missing.append((path, expected))
        elif digest(path) != expected:
            raise ValueError(f'File digest differs from manifest: {name}')
    if missing:
        print('Reconstructing the original NF192 tape certificates from the included inputs.', flush=True)
        subprocess.run([sys.executable, '-B', str(ROOT/'nf192_generator/regenerate.py'),
                        '--out', str(ROOT/'data'), '--manifest', str(manifest), '--jobs', str(jobs)],
                       check=True)
        for path, expected in missing:
            if digest(path) != expected:
                raise ValueError(f'Reconstructed file digest differs from manifest: {path.name}')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--lean', default='lean')
    cli.add_argument('--jobs', type=int, default=2)
    cli.add_argument('--build', type=Path, default=ROOT/'build')
    cli.add_argument('--target', action='append', help='Module name. Repeat to build several endpoints.')
    cli.add_argument('--reuse-prerequisites', action='store_true',
        help='Build the new modules only; provide compiled historical requirements and 93 coverage shards on LEAN_PATH.')
    cli.add_argument('--resume', action='store_true', help='Reuse matching outputs from an earlier run of this script.')
    cli.add_argument('--verify-only', action='store_true', help='Verify the SHA-256 manifest and stop.')
    args = cli.parse_args()
    if args.jobs < 1:
        cli.error('--jobs must be positive')
    verify_file_list(args.jobs)
    if args.verify_only:
        print('All manifest hashes verified.')
        return
    lean = shutil.which(args.lean)
    if not lean:
        cli.error('Provide the Lean 4.35.0 executable (or use lake env).')
    version = subprocess.check_output([lean,'--version'],text=True).strip()
    if PIN not in version:
        cli.error(f'The compiler must be Lean 4.35.0 at {PIN}')
    src, build = ROOT/'src', args.build.resolve()
    if build.exists() and any(build.iterdir()) and not args.resume:
        cli.error('Choose an empty build directory, or pass --resume.')
    build.mkdir(parents=True,exist_ok=True)
    info=json.loads((ROOT/'sources.json').read_text())
    modules=info['modules']
    targets=args.target or info['targets']
    available=set(modules)
    external=set(info['external'])
    selected={}
    def visit(m):
        if m in selected:
            return
        if m not in available:
            raise ValueError(f'Missing module {m}')
        group=modules[m]['group']
        if args.reuse_prerequisites and (not group.startswith('185-') or group=='185-tape-shards'):
            if not any((Path(p)/relative(m,'.olean')).is_file() for p in os.environ.get('LEAN_PATH','').split(os.pathsep) if p):
                raise ValueError(f'Compiled prerequisite {m} missing from LEAN_PATH')
            return
        f=src/relative(m,'.lean')
        imports=set(IMPORT.findall(f.read_text()))
        if missing:=imports-available-external:
            raise ValueError(f'{m} imports absent modules: {sorted(missing)}')
        selected[m]=imports&available
        for n in selected[m]:
            visit(n)
    for t in targets:
        visit(t)
    env={**os.environ,'LEAN_PATH':os.pathsep.join([str(build),*filter(None,os.environ.get('LEAN_PATH','').split(os.pathsep))])}
    per_module_audits={}
    # The semantic cache key includes the full transitive source graph through each
    # locally rebuilt module, the compiler revision, and the selected replay mode.
    keys={}
    def key(m):
        if m not in keys:
            parts=[PIN,str(args.reuse_prerequisites),modules[m]['sha256']]
            for n in sorted(selected[m]):
                parts.extend([n,key(n) if n in selected else modules[n]['sha256']])
            keys[m]=hashlib.sha256('\n'.join(parts).encode()).hexdigest()
        return keys[m]
    for m in selected:
        key(m)
    def compile_one(m):
        source=src/relative(m,'.lean')
        if digest(source)!=modules[m]['sha256']:
            raise RuntimeError(f'Source changed before compilation: {m}')
        out=build/relative(m,'.olean');out.parent.mkdir(parents=True,exist_ok=True)
        receipt=build/(m+'.replay.json')
        if args.resume and receipt.is_file() and out.is_file():
            data=json.loads(receipt.read_text())
            if data['key']==keys[m] and output_hashes(build,m)==data.get('output_sha256'):
                return data['audits']
        log=build/(m+'.log')
        with log.open('w') as fh:
            status=subprocess.run([lean,'-j','1','-s','131072','-o',str(out),str(relative(m,'.lean'))],
                cwd=src,env=env,stdout=fh,stderr=subprocess.STDOUT)
        if digest(source)!=modules[m]['sha256']:
            raise RuntimeError(f'Source changed during compilation: {m}')
        report=log.read_text()
        if status.returncode or "uses 'sorry'" in report or 'sorryAx' in report:
            raise RuntimeError(f'{m} failed. See {log}.\n{report[-1500:]}')
        found={name:[a.strip() for a in body.split(',') if a.strip()] for name,body in AUDIT.findall(report)}
        receipt.write_text(json.dumps({'module':m,'key':keys[m],'output_sha256':output_hashes(build,m),'audits':found})+'\n')
        return found
    pending=set(selected)
    finished=set()
    running={}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        while pending or running:
            ready=sorted(m for m in pending if not ((selected[m]&selected.keys())-finished))
            for m in ready[:args.jobs-len(running)]:
                running[pool.submit(compile_one,m)]=m
                pending.remove(m)
            if not running:
                raise ValueError(f'Cyclic dependency among {sorted(pending)}')
            done,_=wait(running,return_when=FIRST_COMPLETED)
            for f in done:
                m=running.pop(f)
                per_module_audits[m]=f.result()
                finished.add(m)
                print(f'{len(finished)}/{len(selected)} {m}',flush=True)
    expectations=json.loads((ROOT/'axiom-policy.json').read_text())
    for m in selected:
        for theorem, names in expectations.get(m,{}).items():
            observed=per_module_audits[m].get(theorem)
            if observed is None or set(observed)!=set(names):
                raise RuntimeError(f'Unexpected dependencies for {theorem} in {m}: {observed}')
    (build/'receipt.json').write_text(json.dumps({'compiler':version,'targets':targets,'fresh_or_resumable_modules':len(finished),
        'historical_prerequisites_reused':args.reuse_prerequisites,'module_audits':per_module_audits},indent=2)+'\n')

if __name__=='__main__':
    main()
