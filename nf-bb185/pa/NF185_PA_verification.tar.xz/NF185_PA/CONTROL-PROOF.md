# Literal register control flow

The 185-state source scanner decodes a candidate at PC 10. Its two scratch
registers and rank register are zero at this boundary. Nonzero ranks arise
while executing an AX command. Each line below gives source instruction
addresses in the 2,959-address signed register program.

| Command | Literal path | Checked effect |
| --- | --- | --- |
| Tag 0 | 10 → 38 → 2912 → 2939 | MODE tests the original cache for numeral 3, then pops or swaps according to the accumulated parameter. |
| Tag 1 | 10 → 38 → 39 → 2838 → 2892 → 2912 | MP compares the cache to the numerical implication from the top to the accumulated parameter. It clears the parameter and cache and falls through MODE, which pops the saved stack. |
| Tag 2 or higher | 10 → 38 → 39 → 40 → 2837 → 39 | Each positive-rank iteration pushes all eight rows in emitter order, updates both numerical parameters, and consumes two input fields. Rank zero falls through MP. |

The last row pushed is the extensionality row. Write its numeral as
`row8 a b`. At rank zero the MP input cache is `b` and the requested
implication is `imp (row8 a b) a`. The code `eqn a b` is strictly larger
than `b`. It occurs as the consequent of `row8 a b`, and each implication
code is at least as large as each argument. Hence this MP always fails.
Its fall-through places zero on top, removes the extensionality row, and
loads the tester row into the cache. The proof in `NF185PABatches.lean`
performs induction on the rank *inside each PA model*. The two accumulated
parameters and all residual input fields stay arbitrary.

`NF185PAScannerSource.lean` composes these literal paths along the
enumeration of candidate words. It stops at the first observed tag-0
command with cache 3. `NF185PASigned.lean` proves the signed startup at
PC 40 reaches PC 10 with empty input and index zero. This startup executes
the initial rank-2 emission and both lower-rank emissions. The separate
98-step prefix relates this starting point to the physical boot margin at
PC 118. All eventual clocks in these arguments belong to the ambient PA model.
