"""Check all 768 single physical transitions, both scan orientations, and orientation erasure.

This input-side table parser is separate from the definition emitter. Every
closed transition identity has unbounded exterior rays and proof Eq.refl.
"""
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
from export_syntax import Export
from kernel_pumps import PRE, TYPE, NAT, STACK, CONFIG, Z, ONE, F, K, V, ap, lam, num, EQ, REFL, physical
from kernel_branches import normalized_support


def output(e):
    # chooseZero, cfg, applyRow, all 384 literal entries, and step have
    # precisely the same definitions as in each complete branch certificate.
    physical(e);normalized_support(e)
    path=Path(__file__).with_name('inputs')/'NF_192_countdown.tm';raw=path.read_bytes()
    if sha256(raw).hexdigest()!='ee1391964b35c7ad2f0db90305a84e09c6523f73f3dce6c4f31a182aa270d565':raise ValueError('table digest')
    _,*rows=raw.decode().splitlines();state_list=sorted({row.partition(' ')[0] for row in rows})
    assert len(state_list)==192 and len(rows)==384
    A,B=V('A'),V('B');params=[('A',STACK),('B',STACK)];seen=set()
    for row in rows:
        state,read,write,dest_orientation,next_state=row.split()
        q=state_list.index(state);b=int(read);w=int(write);dm={'L':1,'R':0}[dest_orientation]
        nq=192 if next_state=='halt' else state_list.index(next_state)
        assert (q,b) not in seen;seen.add((q,b));ahead=F('push',num(b),A)
        def cfg(q,d,a,b):return F('cfg',num(q),num(d),a,b)
        for d in (0,1):
            old=cfg(q,d,ahead,B)
            if dm==d:final=cfg(nq,dm,A,F('push',num(w),B))
            else:final=cfg(nq,dm,B,F('push',num(w),A))
            e.declare(PRE+f'transition_{q}_{b}_{d}',params,EQ(CONFIG,F('step',old),final),REFL(CONFIG,final),theorem=True)
        old=cfg(q,1,ahead,B);right=cfg(q,0,F('push',num(b),B),A)
        e.declare(PRE+f'orientation_{q}_{b}',params,EQ(CONFIG,F('step',old),F('step',right)),
                  REFL(CONFIG,F('step',right)),theorem=True)
        e.declare(PRE+f'normalize_{q}_{b}',params,EQ(CONFIG,F('norm',old),right),REFL(CONFIG,right),theorem=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('export',type=Path);o=p.parse_args()
    with o.export.open('wb') as f:output(Export(f))
