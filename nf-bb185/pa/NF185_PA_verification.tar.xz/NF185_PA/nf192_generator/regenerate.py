"""Regenerate the NF192 tape certificates from their compact original inputs.

Uses only the Python standard library. Compares every output against the
SHA-256 in the complete release before placing it in the target directory.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor
from hashlib import sha256
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

from convert import write

HERE = Path(__file__).resolve().parent
TOTAL = 3089
WIDTH = 48


def load_hashes(manifest):
    entries = {}
    for line in manifest.read_text().splitlines():
        digest, filename = line.split("  ", 1)
        if filename.startswith("data/FrozenSite"):
            entries[Path(filename).name] = digest
    expected = {f"FrozenSite{n:04d}.{ext}" for n in range(0, TOTAL, WIDTH)
                for ext in ("wire", "locations")}
    if entries.keys() != expected:
        raise ValueError("The manifest must list all 130 FrozenSite inputs")
    return entries


def verified(path, hashes):
    return path.is_file() and sha256(path.read_bytes()).hexdigest() == hashes[path.name]


def run(step, *args):
    subprocess.run([sys.executable, "-B", str(HERE / step), *map(str, args)],
                   check=True, stdout=subprocess.DEVNULL)


def restore(job):
    lo, directory, hashes = job
    hi = min(lo + WIDTH, TOTAL)
    name = f"FrozenSite{lo:04d}"
    names = [name + ext for ext in (".wire", ".locations")]
    if all(verified(directory / n, hashes) for n in names):
        return name
    with TemporaryDirectory(prefix="nf192-wire-", dir=directory) as work:
        tmp = Path(work)
        proposal = tmp / "proposal.ndjson"
        proof, extra = tmp / "base.gz", tmp / "additional.gz"
        run("firstorder_kernel.py", proposal, "--lo", lo, "--hi", hi)
        run("compile_arithmetic.py", proposal, "--qf", "--write", proof)
        run("global/refine.py", proof, extra)
        counts, decls = write([proof, extra], tmp / names[0], [], None)
        with (tmp / names[1]).open("w", newline="\n") as locations:
            for pc in range(lo, hi):
                slots = [decls.get(f"source_branch_{pc}_{cold}_{zero}", counts["D"] + 1)
                         for cold in range(2) for zero in range(2)]
                print(pc, *slots, file=locations)
        for n in names:
            if not verified(tmp / n, hashes):
                raise ValueError(f"Regenerated {n} differs from the published certificate")
        for n in names:
            (tmp / n).replace(directory / n)
    return name


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True,
                        help="Output directory for the 130 .wire and .locations files")
    parser.add_argument("--jobs", type=int, default=2)
    options = parser.parse_args()
    if options.jobs < 1:
        parser.error("--jobs must be a positive integer")
    directory = options.out.resolve()
    directory.mkdir(parents=True, exist_ok=True)
    hashes = load_hashes(options.manifest)
    jobs = [(lo, directory, hashes) for lo in range(0, TOTAL, WIDTH)]
    with ProcessPoolExecutor(max_workers=options.jobs) as pool:
        for i, name in enumerate(pool.map(restore, jobs), 1):
            print(f"{i:2}/{len(jobs)}  {name}", flush=True)


if __name__ == "__main__":
    main()
