"""Emit axiom-free Lean kernel proofs of the universal physical sweep rules.

Usage: python kernel_pumps.py output.ndjson
The output is accepted directly by leanchecker-paranoid --from-export.
"""
import argparse
import gzip
from hashlib import sha256
import json
from pathlib import Path
from export_syntax import C, V, Export, ap, arrow, lam, num, pi

HERE = Path(__file__).resolve().parent
TABLE = HERE / 'inputs/NF_192_countdown.tm'
CERT = HERE / 'symbolic_traces.json.gz'
TABLE_HASH = 'ee1391964b35c7ad2f0db90305a84e09c6523f73f3dce6c4f31a182aa270d565'
PRE = 'NF192Sweep.'
NAT, TYPE, PROP = C('Nat'), ('sort', 1), ('sort', 0)
Z, ONE = num(0), num(1)
NREC = lambda u, mot, init, step, n: ap(C('Nat.rec', u), mot, init, step, n)
EQ = lambda ty, a, b: ap(C('Eq', 1), ty, a, b)
REFL = lambda ty, a: ap(C('Eq.refl', 1), ty, a)
SUC = lambda a: ap(C('Nat.succ'), a)
K = lambda s: C(PRE + s)
F = lambda s, *a: ap(K(s), *a)


def case_nat(typ, n, zero, name, succ):
    """Numeral cases. The predecessor is bound in the nonzero branch."""
    return NREC(1, lam([('caseTag', NAT)], typ), zero,
                lam([(name, NAT), ('unusedIH', typ)], succ), n)


def arithmetic(e):
    def put(name, params, typ, body, th=False):
        e.declare(PRE + name, params, typ, body, theorem=th)
    A,B,a,b,c,f,h=map(V,['A','B','a','b','c','f','h'])
    params=[('A', TYPE),('a',A),('b',A),('c',A),('p',EQ(A,a,b)),('h',EQ(A,b,c))]
    mot=lam([('y',A),('why',EQ(A,b,V('y')))],EQ(A,a,V('y')))
    put('trans',params,EQ(A,a,c),ap(C('Eq.rec',0,1),A,b,mot,V('p'),c,h),True)
    params=[('A',TYPE),('B',TYPE),('f',arrow(A,B)),('a',A),('b',A),('h',EQ(A,a,b))]
    mot=lam([('y',A),('why',EQ(A,a,V('y')))],EQ(B,ap(f,a),ap(f,V('y'))))
    put('congr',params,EQ(B,ap(f,a),ap(f,b)),ap(C('Eq.rec',0,1),A,a,mot,REFL(B,ap(f,a)),b,h),True)
    params=[('A',TYPE),('a',A),('b',A),('h',EQ(A,a,b))]
    mot=lam([('y',A),('why',EQ(A,a,V('y')))],EQ(A,V('y'),a))
    put('symm',params,EQ(A,b,a),ap(C('Eq.rec',0,1),A,a,mot,REFL(A,a),b,h),True)
    n,z,k,i=map(V,['n','z','k','i'])
    params=[('A',TYPE),('f',arrow(A,A)),('n',NAT),('z',A)]
    put('iterate',params,A,NREC(1,lam([('j',NAT)],A),z,
        lam([('j',NAT),('v',A)],ap(f,V('v'))),n))
    unary=arrow(A,A)
    tail=NREC(1,lam([('j',NAT)],unary),lam([('v',A)],V('v')),
        lam([('j',NAT),('g',unary),('v',A)],ap(V('g'),ap(f,V('v')))),n)
    put('tailIterate',params,A,ap(tail,z))
    put('plus',[('a',NAT),('b',NAT)],NAT,
        NREC(1,lam([('j',NAT)],NAT),a,lam([('j',NAT),('v',NAT)],SUC(V('v'))),b))
    put('clock',[('k',NAT),('n',NAT)],NAT,
        NREC(1,lam([('j',NAT)],NAT),Z,lam([('j',NAT),('v',NAT)],F('plus',k,V('v'))),n))
    params=[('A',TYPE),('f',unary),('a',NAT),('b',NAT),('z',A)]
    run=lambda count,x:F('iterate',A,f,count,x)
    left=lambda count:run(F('plus',a,count),z)
    right=lambda count:run(count,run(a,z))
    claim=lambda count:EQ(A,left(count),right(count))
    mot=lam([('j',NAT)],claim(V('j')))
    step=lam([('i',NAT),('ih',claim(i))],F('congr',A,A,f,left(i),right(i),V('ih')))
    put('iteratePlus',params,claim(b),NREC(0,mot,REFL(A,run(a,z)),step,b),True)


def pumping(e):
    P,Q,L,R,step,build,k,n=map(V,['P','Q','L','R','step','build','k','n'])
    a,b,i=map(V,['a','b','i'])
    params=[('P',TYPE),('Q',TYPE),('L',arrow(P,P)),('R',arrow(P,P)),('step',arrow(Q,Q)),
            ('build',arrow(P,P,Q)),('k',NAT)]
    rs=lambda m,c:F('iterate',Q,step,m,c)
    ahead=lambda m,c:F('iterate',P,R,m,c)
    behind=lambda m,c:F('tailIterate',P,L,m,c)
    conf=lambda x,y:ap(build,x,y)
    ab=[('a',P),('b',P)]
    local=pi(ab,EQ(Q,rs(k,conf(a,ap(R,b))),conf(ap(L,a),b)))
    params+= [('local',local),('n',NAT)]
    def claim(n,a,b):
        return EQ(Q,rs(F('clock',k,n),conf(a,ahead(n,b))),conf(behind(n,a),b))
    motive=lam([('j',NAT)],pi(ab,claim(V('j'),a,b)))
    initial=lam(ab,REFL(Q,conf(a,b)))
    t=F('clock',k,i); inp=conf(a,ap(R,ahead(i,b))); lhs=rs(F('plus',k,t),inp)
    mid=rs(t,rs(k,inp)); mid2=rs(t,conf(ap(L,a),ahead(i,b))); rhs=conf(behind(i,ap(L,a)),b)
    first=F('iteratePlus',Q,step,k,t,inp)
    second=F('congr',Q,Q,lam([('cfg',Q)],rs(t,V('cfg'))),rs(k,inp),conf(ap(L,a),ahead(i,b)),
             ap(V('local'),a,ahead(i,b)))
    third=ap(V('ih'),ap(L,a),b)
    mulstep=lam([('i',NAT),('ih',pi(ab,claim(i,a,b)))]+ab,
         F('trans',Q,lhs,mid,rhs,first,F('trans',Q,mid,mid2,rhs,second,third)))
    proof=NREC(0,motive,initial,mulstep,n)
    e.declare(PRE+'pump',params,pi(ab,claim(n,a,b)),proof,theorem=True)


def words_and_composition(e):
    A,U,Vv,P,n,x,i=map(V,['A','U','Vv','P','n','x','i'])
    unary=arrow(A,A); ux=lambda t:ap(U,t); vx=lambda t:ap(Vv,t); px=lambda t:ap(P,t)
    conjParams=[('A',TYPE),('U',unary),('Vv',unary),('P',unary)]
    commute=pi([('x',A)],EQ(A,ux(px(x)),px(vx(x))))
    it=lambda f,j,t:F('iterate',A,f,j,t)
    left=lambda j:it(U,j,px(x))
    right=lambda j:px(it(Vv,j,x))
    claim=lambda j:EQ(A,left(j),right(j))
    first=F('congr',A,A,U,left(i),right(i),V('ih'))
    second=ap(V('law'),it(Vv,i,x))
    ind=lam([('i',NAT),('ih',claim(i))],F('trans',A,ux(left(i)),ux(right(i)),right(SUC(i)),first,second))
    e.declare(PRE+'powerSlide',conjParams+[('law',commute),('n',NAT),('x',A)],claim(n),
        NREC(0,lam([('j',NAT)],claim(V('j'))),REFL(A,px(x)),ind,n),theorem=True)
    f=V('f'); itF=lambda j,t:it(f,j,t); tailF=lambda j,t:F('tailIterate',A,f,j,t)
    claim2=lambda j,t:EQ(A,tailF(j,t),itF(j,t))
    ff=lam([('z',A)],REFL(A,ap(f,ap(f,V('z')))))
    q=F('powerSlide',A,f,f,f,ff,i,x)
    trans=F('trans',A,tailF(i,ap(f,x)),itF(i,ap(f,x)),ap(f,itF(i,x)),ap(V('ih'),ap(f,x)),q)
    mot=lam([('j',NAT)],pi([('x',A)],claim2(V('j'),x)))
    ind=lam([('i',NAT),('ih',pi([('x',A)],claim2(i,x))),('x',A)],trans)
    e.declare(PRE+'tailEq',[('A',TYPE),('f',unary),('n',NAT)],pi([('x',A)],claim2(n,x)),
        NREC(0,mot,lam([('x',A)],REFL(A,x)),ind,n),theorem=True)
    j,y,z=map(V,['j','y','z']); st=lambda k,s:itF(k,s)
    pars=[('A',TYPE),('f',unary),('i',NAT),('j',NAT),('x',A),('y',A),('z',A),
          ('fwd',EQ(A,st(i,x),y)),('again',EQ(A,st(j,y),z))]
    a=st(F('plus',i,j),x);b=st(j,st(i,x));c=st(j,y)
    p=F('iteratePlus',A,f,i,j,x)
    q=F('congr',A,A,lam([('v',A)],st(j,V('v'))),st(i,x),y,V('fwd'))
    e.declare(PRE+'chain',pars,EQ(A,a,z),F('trans',A,a,b,z,p,F('trans',A,b,c,z,q,V('again'))),theorem=True)


STACK = arrow(NAT,NAT)
CONFIG = arrow(NAT,STACK)
ROW = arrow(NAT,NAT,STACK,STACK,CONFIG)


def raw_table():
    data=TABLE.read_bytes()
    if sha256(data).hexdigest()!=TABLE_HASH: raise ValueError('192-state table hash')
    header,*lines=data.decode().splitlines()
    if header!='#! start k:64': raise ValueError('blank state')
    raw=[line.split() for line in lines]
    states=sorted({r[0] for r in raw})
    if len(states)!=192 or len(raw)!=384: raise ValueError('expected 384 transitions')
    ids={s:i for i,s in enumerate(states)}
    rows={(ids[q],int(b)):(192 if target=='halt' else ids[target],int(w),int(d=='L'))
          for q,b,w,d,target in raw}
    if len(rows)!=384: raise ValueError('duplicate transition')
    return rows


def physical(e):
    def put(name,params,typ,val):e.declare(PRE+name,params,typ,val)
    A,n,x,y=map(V,['A','n','x','y'])
    put('chooseZero',[('A',TYPE),('n',NAT),('x',A),('y',A)],A,
        case_nat(A,n,x,'predTag',y))
    ZIF=lambda ty,s,a,b:F('chooseZero',ty,s,a,b)
    ray,i,b=map(V,['ray','i','b'])
    put('push',[('b',NAT),('ray',STACK),('i',NAT)],NAT,case_nat(NAT,i,b,'predIdx',ap(ray,V('predIdx'))))
    put('tail',[('ray',STACK),('i',NAT)],NAT,ap(ray,SUC(i)))
    q,d,a,h,t=map(V,['q','d','ahead','behind','tag'])
    # Only the rows at tags 0,1,2,3 are ever observed. The first two
    # repeat a scalar, and tags 2 and 3 hold the nearest-first rays.
    pick=case_nat(STACK,t,lam([('i',NAT)],q),'pred1',
        case_nat(STACK,V('pred1'),lam([('i',NAT)],d),'pred2',ZIF(STACK,V('pred2'),a,h)))
    put('cfg',[('q',NAT),('d',NAT),('ahead',STACK),('behind',STACK),('tag',NAT)],STACK,pick)
    w,m=V('write'),V('move')
    forward=F('cfg',q,m,F('tail',a),F('push',w,h))
    reverse=F('cfg',q,m,h,F('push',w,F('tail',a)))
    put('applyRow',[('q',NAT),('write',NAT),('move',NAT),('d',NAT),('ahead',STACK),('behind',STACK)],
        CONFIG,ZIF(CONFIG,m,ZIF(CONFIG,d,forward,reverse),ZIF(CONFIG,d,reverse,forward)))
    rows=raw_table()
    base=[('b',NAT),('d',NAT),('ahead',STACK),('behind',STACK)]
    put('table192',[('q',NAT)]+base,CONFIG,F('cfg',num(192),d,a,h))
    for j in reversed(range(192)):
        def one(bit):
            to,write,move=rows[j,bit]
            return F('applyRow',num(to),num(write),num(move))
        table_entry=lam([('b',NAT)],ZIF(arrow(NAT,STACK,STACK,CONFIG),b,one(0),one(1)))
        val=case_nat(ROW,q,table_entry,'smallerQ',F('table'+str(j+1),V('smallerQ')))
        put('table'+str(j),[('q',NAT)],ROW,val)
    c=V('c'); ahead=ap(c,num(2))
    put('step',[('c',CONFIG)],CONFIG,F('table0',ap(c,Z,Z),ap(ahead,Z),ap(c,ONE,Z),ahead,ap(c,num(3))))


def word(bits,tail):
    for b in reversed(bits):tail=F('push',num(int(b)),tail)
    return tail


def local_rules(e):
    cert=json.loads(gzip.decompress(CERT.read_bytes()))
    if cert['table']!=TABLE_HASH: raise ValueError('certificate/table binding')
    a,b,n=map(V,['a','b','n']); ab=[('a',STACK),('b',STACK)]
    for i,p in enumerate(cert['pumps']):
        q,side,k=map(num,[p['q'], int(p['dir']==-1),p['ticks']])
        S=lambda A,B:F('cfg',q,side,B,word(p['context'][::-1],A))
        L=lam([('x',STACK)],word(p['output'][::-1],V('x')))
        R=lam([('y',STACK)],word(p['unit'],V('y')))
        build=lam(ab,S(a,b))
        start=S(a,word(p['unit'],b)); end=S(word(p['output'][::-1],a),b)
        local='local'+str(i)
        e.declare(PRE+local,ab,EQ(CONFIG,F('iterate',CONFIG,K('step'),k,start),end),
            REFL(CONFIG,end),theorem=True)
        all_start=S(a,F('iterate',STACK,R,n,b))
        all_end=S(F('tailIterate',STACK,L,n,a),b)
        statement=EQ(CONFIG,F('iterate',CONFIG,K('step'),F('clock',k,n),all_start),all_end)
        term=F('pump',STACK,CONFIG,L,R,K('step'),build,k,K(local),n,a,b)
        e.declare(PRE+'universal'+str(i),[('n',NAT)]+ab,statement,term,theorem=True)

        expected=S(F('iterate',STACK,L,n,a),b)
        rewrite=F('congr',STACK,CONFIG,lam([('z',STACK)],S(V('z'),b)),F('tailIterate',STACK,L,n,a),
            F('iterate',STACK,L,n,a),F('tailEq',STACK,L,n,a))
        e.declare(PRE+'sweep'+str(i),[('n',NAT)]+ab,EQ(CONFIG,F('iterate',CONFIG,K('step'),
                    F('clock',k,n),all_start),expected),F('trans',CONFIG,F('iterate',CONFIG,K('step'),
                    F('clock',k,n),all_start),all_end,expected,F('universal'+str(i),n,a,b),rewrite),theorem=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    with args.output.open('wb') as out:
        e=Export(out);arithmetic(e);pumping(e);words_and_composition(e);physical(e);local_rules(e)
    print(args.output.stat().st_size,'bytes')


if __name__=='__main__': main()
