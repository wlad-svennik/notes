"""Produce a new axiom-free kernel certificate of NF192's run from blank."""
from argparse import ArgumentParser
from pathlib import Path
from kernel_branches import (A,B,CONFIG,EQ,F,HERE,PRE,REFL,ROOT,STACK,V,Block,Export,LiteralProver,
        arithmetic,ap,cfg,congr,lam,material,normalized_support,num,physical,pumping,run,
        simulate,trans,word,words_and_composition)
import json


def boot(e):
    arithmetic(e);words_and_composition(e);physical(e);normalized_support(e)
    literals=LiteralProver(e)
    q,d=185,0; ticks=33911
    a=('0',)*184+(B,);b=('0',)*66+(A,)
    start=cfg(q,d,material(a),material(b));p=literals.use(q,d,a,b,ticks)
    q,d,a,b=simulate(q,d,a,b,ticks);assert q==ROOT
    final=cfg(q,d,material(a),material(b))
    if d:
        head=a[0];assert head in ('0','1');a,b=(head,)+b,a[1:]
    path=json.loads((HERE/'inputs'/'countdown.sites.json').read_bytes())[91][0]
    stored=[0,1,1,3,1,1,1,3,1]
    frame=path+'0'*(42-len(path))+'1'+''.join('0'+'1'*(stored[i]+1) for i in [2,8,1,4,3,7,0,5,6])+'01'*24
    ra=tuple(frame+'0'*64)+(B,);lb=tuple('1'+'0'*64)+(A,)
    assert a==ra and b==lb
    wanted=cfg(ROOT,0,material(ra),material(lb));actual=run(num(ticks),start)
    proof=congr(CONFIG,CONFIG,F('norm'),actual,final,p)
    e.declare(PRE+'blankMargin',[(A.name,STACK),(B.name,STACK)],EQ(CONFIG,F('norm',actual),wanted),proof,theorem=True)
    print('blank run with arbitrary distant exteriors',len(literals.cache),'finite raw windows')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('export',type=Path);o=p.parse_args()
    with o.export.open('wb') as f:boot(Export(f))
