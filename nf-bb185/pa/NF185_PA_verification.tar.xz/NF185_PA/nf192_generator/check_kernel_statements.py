"""Independently decode the mathematical statements of emitted Lean branch theorems.

This audit intentionally uses no code from the proof emitter or symbolic
search. It reads only kernel export expressions, the signed source rows and
the published arrays of branch clock coefficients.
"""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
from hashlib import sha256

if not __debug__:
    raise RuntimeError('checking export statement bindings requires Python without -O')

HERE=Path(__file__).resolve().parent
RAW=(HERE/'inputs'/'countdown.sites.json').read_bytes()
if sha256(RAW).hexdigest()!='b991565b82033c133e1f2b4618dfe32d1e7ff1ef02e8e18620a2dfdccb5307aa':raise ValueError('source hash')
SITES=json.loads(RAW); LEAF={}
for pc,(path,kind,operand) in enumerate(SITES):
    for i in range(len(path)+1):LEAF.setdefault(path[:i],pc)
CERT=json.loads(gzip.decompress((HERE/'symbolic_traces.json.gz').read_bytes()))
REF={(t['pc'],t['cold'],t['zero']):t['clock'] for t in CERT['traces']}
QUAL='NF192Sweep.'


def destination(pc,z):
    p,k,a=SITES[pc]
    def ascend(path,b):return path[:path.rfind(b)] if b in path else ''
    def following(path):return ascend(path,'0')+'1' if '0' in path else ''
    if k=='CD' and z and p.endswith('1'):return None
    if k=='CC':
        for _ in range(a):p=ascend(p,'1')
    else:
        cuts=a if k=='CB' else int(k=='CD' and z)
        for _ in range(cuts):p=ascend(p,'0')
        p=following(p)
    return LEAF[p]


def shape(pc,cold,z):
    p,k,a=SITES[pc];base=[1]*9;vary=[True]*9
    if cold:base[0]=0;vary[0]=False
    if k=='CD':base[a]=1 if z else 2;vary[a]=not z
    def rays(q,stored,g,s,lg,rg):
        path=SITES[q][0]
        right=list(path+'0'*(g-len(path)-5))+[(9,'0')]+list('000001')
        for r in (2,8,1,4,3,7,0,5,6):
            right+=list('0'+'1'*stored[r]);right+=[(r,'1')] if vary[r] else []
            right+=['1']
        right+=list('01'*12)+[(10,'01')]+list('01'*(s-12)+'0'*rg)+['rightRay']
        return right,list('1'+'0'*lg)+['leftRay']
    initial=rays(pc,base,42,24,64,64);target=destination(pc,z)
    if target is None:return initial,None
    if k=='CI':base[a]+=1
    if k=='CD' and not z:base[a]-=1
    special=(k=='CD' and z and pc==3087)
    end=rays(target,base,42+int((k=='CD' and not z) or special),24+int(k=='CI'),64-int(special),64-3*int(k=='CI'))
    return initial,end


class Reader:
    def __init__(self):self.names={0:''};self.expr=[];self.seen=set();self.cut=0;self.finite=False
    def apps(self,i):
        args=[]
        while self.expr[i][0]=='app':
            app=self.expr[i][1];args.append(app['arg']);i=app['fn']
        args.reverse();return self.expr[i],args
    def call(self,i,name,n):
        head,args=self.apps(i);assert head[0]=='const' and self.names[head[1]['name']]==name,(name,i,head)
        assert len(args)==n,(name,n,len(args));return args
    def num(self,i):
        tag,strval=self.expr[i];assert tag=='natVal';return int(strval)
    def variable(self,i):
        tag,bv=self.expr[i];assert tag=='bvar';return bv
    def unit(self,i):
        tag,lam=self.expr[i];assert tag=='lam';i=lam['body'];bits=''
        while self.expr[i][0]!='bvar':
            b,i=self.call(i,QUAL+'push',2);bits+=str(self.num(b))
        assert self.variable(i)==0 and bits and set(bits)<=set('01');return bits
    def read_ray(self,i):
        word=[]
        while self.expr[i][0]!='bvar':
            head,args=self.apps(i);name=self.names[head[1]['name']]
            if name==QUAL+'push':
                b,i=args;b=self.num(b);assert b in (0,1);word.append(str(b))
            else:
                assert name==QUAL+'iterate' and len(args)==4
                _,f,n,i=args;idx=12-self.variable(n);assert 0<=idx<11
                word.append((idx,self.unit(f)))
        tail=self.variable(i);assert tail in (0,1);word.append(['rightRay','leftRay'][tail]);return word
    def config(self,i):
        q,d,r,l=self.call(i,QUAL+'cfg',4)
        assert (self.num(q),self.num(d))==(13,0)
        return self.read_ray(r),self.read_ray(l)
    def affine(self,i):
        vec=[0]*12;todo=[i]
        while todo:
            j=todo.pop();tag,body=self.expr[j]
            if tag=='natVal':vec[0]+=int(body);continue
            fn,args=self.apps(j);name=self.names[fn[1]['name']]
            if name==QUAL+'plus':assert len(args)==2;todo.extend(args)
            else:
                assert name==QUAL+'clock' and len(args)==2
                idx=12-self.variable(args[1]);assert 0<=idx<11
                vec[idx+1]+=self.num(args[0])
        return vec
    def typ(self,i,kind):
        tag,r=self.expr[i]
        if self.finite and kind>0:
            assert tag=='const' and self.names[r['name']]==QUAL+('Word' if kind==1 else 'Configuration');return
        if kind==0:
            assert tag=='const' and self.names[r['name']]=='Nat';return
        assert tag=='forallE';self.typ(r['type'],0);self.typ(r['body'],kind-1)
    def check(self,name,t):
        pc,c,z=map(int,name.split('_')[1:]);key=(pc,bool(c),bool(z));assert c in (0,1) and z in (0,1)
        assert key in REF and key not in self.seen;self.seen.add(key);i=t
        for j in range(13):
            tag,b=self.expr[i];assert tag=='forallE'
            if j==11:
                tv=self.expr[b['type']];self.finite=(tv[0]=='const' and self.names[tv[1]['name']]==QUAL+'Word')
            self.typ(b['type'],int(j>=11));i=b['body']
        ty,lhs,rhs=self.call(i,'Eq',3)
        start,finish=shape(*key)
        if finish is None:
            self.typ(ty,0);assert self.num(rhs)==192
            if self.finite:run,=self.call(lhs,QUAL+'state',1)
            else:
                head,app=self.expr[lhs];assert head=='app' and self.num(app['arg'])==0
                head,app=self.expr[app['fn']];assert head=='app' and self.num(app['arg'])==0
                run=app['fn']
        else:
            self.typ(ty,2);run,=self.call(lhs,QUAL+'norm',1)
            assert self.config(rhs)==finish,(name,'wrong return frame')
        typ,step,time,entry=self.call(run,QUAL+'iterate',4);self.typ(typ,2);self.call(step,QUAL+'step',0)
        assert self.config(entry)==start,(name,'wrong entry frame')
        assert self.affine(time)==REF[key],(name,'wrong clock')
    def read(self,p):
        op=gzip.open if p.suffix=='.gz' else open
        with op(p,'rt') as f:
            for line in f:
                r=json.loads(line)
                if 'in' in r:
                    e=r.get('str') or r.get('num');tag=str(e.get('str',e.get('i')));n=e['pre']
                    self.names[r['in']]=(self.names[n]+'.' if n else '')+tag
                elif 'ie' in r:
                    assert r.pop('ie')==len(self.expr);self.expr.append(next(iter(r.items())))
                elif 'axiom' in r:raise ValueError('extraneous axiom')
                elif 'thm' in r:
                    d=r['thm'];name=self.names[d['name']]
                    if name.startswith(QUAL+'branch_'):self.check(name.split('.')[-1],d['type'])
        return self.seen


def main():
    p=ArgumentParser(description=__doc__);p.add_argument('exports',nargs='+',type=Path);p.add_argument('--all',action='store_true');o=p.parse_args()
    seen=set()
    for file in o.exports:
        new=Reader().read(file);assert not seen.intersection(new);seen.update(new)
    if o.all:assert seen==set(REF)
    print(len(seen),'kernel theorem statements match complete frames and exact affine clocks')

if __name__=='__main__':main()
