# Reconstructing the NF192 certificates

Run from the extracted NF185_PA directory with Python 3.11 or later.

```sh
python3 -B nf192_generator/regenerate.py --manifest SHA256SUMS --out data --jobs 2
```

Each of the 65 intervals contains up to 48 source instruction addresses. The inputs are the literal 192-state transition table, its source-address listing, the compact symbolic traces, and the equality-and-natural-number syntax prelude. The Python programs come from the original NF192 PA review sources under `proof3/independent/`, `proof3/independent/global/` and `proof3/physical/model/replay/convert.py`.

For each interval, `firstorder_kernel.py` produces numerical proof terms. `compile_arithmetic.py` translates them to first-order equational derivations. `global/refine.py` produces the source-dispatch derivations. `convert.py` serializes both streams, and `regenerate.py` writes the source-branch indices in their original order. The only change in `convert.py` specifies ASCII and LF for portable output.

The driver checks both files against their SHA-256 digests in the complete release manifest before installing them. Subsequent invocations reuse matching pairs and regenerate missing or altered ones. The resulting 130 files are input to the original Lean checker. Temporary numerical proofs are removed as each interval finishes.
