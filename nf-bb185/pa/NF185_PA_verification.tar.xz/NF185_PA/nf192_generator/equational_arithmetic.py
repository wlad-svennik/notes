"""A small first-order equational proof checker for NF192's arithmetic certificate.

Sorts N, W, C stand for naturals, finite binary words, and four-field
configurations. Only first-order terms occur. Each written inference is
reflexivity up to defining equations, congruence, symmetry, transitivity,
instantiation of an earlier universal equation, or ordinary number induction.
Induction may generalize other universal number/finite-data variables, so its
formula is Pi_1 after the elementary numerical coding.
"""
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
from hashlib import sha256

if not __debug__:
    raise RuntimeError('arithmetic proof checking requires ordinary Python without -O')

HERE=Path(__file__).resolve().parent
TAPE_HASH='ee1391964b35c7ad2f0db90305a84e09c6523f73f3dce6c4f31a182aa270d565'

def read_table():
    raw=(HERE/'inputs'/'NF_192_countdown.tm').read_bytes()
    if sha256(raw).hexdigest()!=TAPE_HASH:raise ValueError('table digest')
    _,*lines=raw.decode().splitlines();rows=[l.split() for l in lines];keys=sorted({r[0] for r in rows})
    assert len(keys)==192 and len(rows)==384
    return {(keys.index(q),int(b)):(192 if nq=='halt' else keys.index(nq),int(w),int(d=='L')) for q,b,w,d,nq in rows}

TABLE=read_table()
SIGNATURE={'su':('N','N'),'add':('NN','N'),'sub':('NN','N'),'clk':('NN','N'),'B0':('W','W'),'B1':('W','W'),
           'blank':('','W'),'cfg':('NNWW','C'),'step':('C','C'),'norm':('C','C'),'state':('C','N'),
           'run':('NC','C')}


def sig(op):
    if op.startswith('rep:') and op[4:] and set(op[4:])<=set('01'):return 'NW','W'
    return SIGNATURE[op]


class Terms:
    def __init__(self,emit):
        self.rows=[];self.sorts=[];self.ids={};self.emit=emit
    def make(self,op,*args):
        row=(op,*args)
        if row in self.ids:return self.ids[row]
        if op=='v':
            s,i=args;assert s in ('N','W','C') and isinstance(i,int) and i>=-1
        elif op=='#':
            i,=args;assert isinstance(i,int) and i>=0;s='N'
        else:
            par,s=sig(op);assert len(args)==len(par) and all(0<=x<len(self.rows) and self.sorts[x]==y for x,y in zip(args,par)),row
        i=len(self.rows);self.rows.append(row);self.ids[row]=i;self.sorts.append(s);self.emit(['T',*row]);return i
    def num(self,n):return self.make('#',n)
    def var(self,s,i):return self.make('v',s,i)
    def litword(self,w,x):
        for b in reversed(w):x=self.make('B'+b,x)
        return x
    def rep(self,w,n,x):return self.make('rep:'+w,n,x) if w else x
    def cfg(self,q,d,a,b):return self.make('cfg',self.num(q),self.num(d),a,b)
    @lru_cache(maxsize=300000)
    def replace(self,id,bindings):
        tab=dict(bindings);stack=self.rows[id]
        if stack[0]=='v':return tab.get(id,id)
        if stack[0]=='#':return id
        return self.make(stack[0],*[self.replace(x,bindings) for x in stack[1:]])
    @lru_cache(maxsize=300000)
    def variables(self,id):
        op,*args=self.rows[id]
        if op=='v':return frozenset([id])
        if op=='#':return frozenset()
        return frozenset().union(*(self.variables(x) for x in args))
    def instantiated(self,x,src,dst):
        assert len(src)==len(dst) and len(set(src))==len(src)
        assert all(self.sorts[a]==self.sorts[b] for a,b in zip(src,dst))
        return self.replace(x,tuple(zip(src,dst)))
    @lru_cache(maxsize=500000)
    def norm(self,id):
        op,*xs=self.rows[id]
        if op in ('v','#','blank'):return id
        a=[self.norm(x) for x in xs];r=[self.rows[x] for x in a]
        if op=='su' and r[0][0]=='#':return self.num(r[0][1]+1)
        if op=='sub':
            if a[0]==a[1]:return self.num(0)
            if r[0][0]==r[1][0]=='#':return self.num(max(0,r[0][1]-r[1][1]))
            if r[1]==('#',0):return a[0]
            if r[0]==('#',0):return self.num(0)
            if r[0][0]==r[1][0]=='su':return self.norm(self.make('sub',r[0][1],r[1][1]))
        if op in ('add','clk'):

            if r[0][0]==r[1][0]=='#':return self.num((r[0][1]+r[1][1]) if op=='add' else r[0][1]*r[1][1])
            if r[1]==('#',0):return a[0] if op=='add' else self.num(0)
            if r[1][0]=='su':
                j=r[1][1];end=self.make(op,a[0],j)
                return self.norm(self.make('su',end) if op=='add' else self.make('add',a[0],end))
        if op.startswith('rep:'):
            word=op[4:];k=r[0]
            if k[0]=='#' and k[1]<=3:return self.litword(word*k[1],a[1])
            if k[0]=='su':return self.litword(word,self.norm(self.rep(word,k[1],a[1])))
        if op=='run':
            if r[0][0]=='#' and r[0][1]<=3:
                v=a[1]
                for _ in range(r[0][1]):v=self.norm(self.make('step',v))
                return v
            if r[0][0]=='su':return self.norm(self.make('step',self.make('run',r[0][1],a[1])))
        if op in ('step','norm','state') and r[0][0]=='cfg':
            _,q,d,front,back=r[0]
            if op=='state':return q
            dv=self.rows[d];qv=self.rows[q];f=self.rows[front]
            if op=='norm' and dv==('#',0):return a[0]
            if f[0] in ('B0','B1'):bit=int(f[0][1]);tail=f[1]
            elif f[0]=='blank':bit=0;tail=front
            else:bit=None
            if bit is not None and dv[0]=='#':
                if op=='norm' and dv[1]==1:return self.make('cfg',q,self.num(0),self.make('B'+str(bit),back),tail)
                if op=='step' and qv[0]=='#' and dv[1] in (0,1):
                    if qv[1]==192:return a[0]
                    nq,w,m=TABLE[qv[1],bit];new='B'+str(w)
                    return self.cfg(nq,m,tail,self.make(new,back)) if m==dv[1] else self.cfg(nq,m,back,self.make(new,tail))
        return self.make(op,*a)
    def eq(self,x,y):return x==y or self.norm(x)==self.norm(y)


@dataclass(frozen=True)
class Fact:
    l:int
    r:int
    deps:frozenset=frozenset()


class Derivation:
    """Validate every rule while writing it. This class can replay the same rows."""
    def __init__(self,output=None,allow_generalized=True):
        self.allow_generalized=allow_generalized;self.output=output;self.terms=Terms(self.emit);self.proofs=[];self.rules={};self.hypotheses=[];self.lemmas={};self.counts={}
    def emit(self,row):
        if self.output:self.output.write((json.dumps(row,ensure_ascii=True,separators=(',',':'))+'\n').encode())
    def proof(self,row):
        key=tuple(row);t=self.terms
        if key in self.rules:return self.rules[key]
        op,*v=key
        counts={'r':2,'s':1,'t':2,'c':3,'i':4,'b':6}
        if op in counts:assert len(v)==counts[op] and all(isinstance(j,int) and j>=0 for j in v)
        if op=='u':assert len(v)>=1 and isinstance(v[0],str) and all(isinstance(i,int) and i>=0 for i in v[1:])
        if op=='h':assert v and all(isinstance(i,int) and i>=0 for i in v)
        if op=='r':
            l,r=v;assert t.sorts[l]==t.sorts[r] and t.eq(l,r),('not convertible',l,r,t.rows[l],t.rows[r]);fact=Fact(l,r)
        elif op=='s':
            pr=self.proofs[v[0]];fact=Fact(pr.r,pr.l,pr.deps)
        elif op=='t':
            a,b=[self.proofs[i] for i in v];assert t.eq(a.r,b.l),('transitivity mismatch',a.r,b.l)
            fact=Fact(a.l,b.r,a.deps|b.deps)
        elif op=='c':
            ctx,hole,p=v;a=self.proofs[p];assert t.rows[hole]==('v',t.sorts[a.l],-1)
            x,y=(t.instantiated(ctx,(hole,),(z,)) for z in (a.l,a.r));fact=Fact(x,y,a.deps)
        elif op in ('u','h'):
            name,*args=v;schema=(self.lemmas[name] if op=='u' else self.hypotheses[name]);vs,l,r=schema
            fact=Fact(t.instantiated(l,vs,args),t.instantiated(r,vs,args),frozenset() if op=='u' else frozenset((name,)))
        elif op=='i':
            tag,n,bp,sp=v;gv,l,r=self.hypotheses[tag];base,step=self.proofs[bp],self.proofs[sp]
            assert t.rows[n][0]=='v' and t.rows[n][2]>=0 and t.sorts[n]=='N' and n not in gv and all(t.rows[x][0]=='v' and t.rows[x][2]>=0 for x in gv)
            assert not base.deps and step.deps<=frozenset((tag,))
            for st,vn in [(base,t.num(0)),(step,t.make('su',n))]:
                assert all(t.eq(out,t.instantiated(inp,(n,),(vn,))) for out,inp in [(st.l,l),(st.r,r)]),('bad induction case',tag,l,r,st)
            fact=Fact(l,r)
        elif op=='b':
            tag,guard,i,n,bp,sp=v;gv,l,r=self.hypotheses[tag];gg,gl,gr=self.hypotheses[guard]
            base,step=self.proofs[bp],self.proofs[sp]
            assert tag!=guard and not gv and not gg and t.rows[i][0]=='v' and t.rows[i][2]>=0 and t.sorts[i]==t.sorts[n]=='N'
            assert i not in t.variables(n) and not base.deps and step.deps<=frozenset((tag,guard))
            assert t.eq(gl,t.make('sub',n,i)) and t.eq(gr,t.make('su',t.make('sub',n,t.make('su',i))))
            for fact0,ix in [(base,t.num(0)),(step,t.make('su',i))]:
                assert t.eq(fact0.l,t.instantiated(l,(i,),(ix,))) and t.eq(fact0.r,t.instantiated(r,(i,),(ix,))),('bad bounded induction',tag)
            fact=Fact(t.instantiated(l,(i,),(n,)),t.instantiated(r,(i,),(n,)))
        else:raise ValueError(op)
        i=len(self.proofs);self.proofs.append(fact);self.rules[key]=i;self.counts[op]=self.counts.get(op,0)+1;self.emit(['P',*key]);return i
    def assumption(self,gen,l,r):
        t=self.terms;ids=(*gen,l,r);assert all(type(x) is int and 0<=x<len(t.rows) for x in ids)
        assert all(t.rows[v][0]=='v' and t.rows[v][2]>=0 for v in gen) and t.sorts[l]==t.sorts[r] and len(set(gen))==len(gen) and (self.allow_generalized or not gen)
        self.hypotheses.append((tuple(gen),l,r));self.emit(['H',list(gen),l,r]);return len(self.hypotheses)-1
    def rule(self,name,params,l,r,p):
        t=self.terms;assert isinstance(name,str) and name and all(type(x) is int and 0<=x<len(t.rows) for x in (*params,l,r))
        assert type(p) is int and 0<=p<len(self.proofs)
        v=self.proofs[p];assert t.sorts[l]==t.sorts[r] and name not in self.lemmas and not v.deps and len(set(params))==len(params)
        assert t.eq(l,v.l) and t.eq(r,v.r),('wrong theorem',name,t.rows[l],t.rows[r],t.rows[v.l],t.rows[v.r])
        assert t.variables(l)|t.variables(r)<=set(params) and all(t.rows[x][0]=='v' and t.rows[x][2]>=0 for x in params)
        self.lemmas[name]=(tuple(params),l,r);self.emit(['D',name,list(params),l,r,p]);return name
    def refl(self,l,r=None):return self.proof(('r',l,l if r is None else r))
    def sym(self,p):return self.proof(('s',p))
    def trans(self,*ps):
        assert ps
        p=ps[0]
        for q in ps[1:]:p=self.proof(('t',p,q))
        return p
    def cong(self,ctx,sort,p):return self.proof(('c',ctx,self.terms.var(sort,-1),p))
    def use(self,name,*args):return self.proof(('u',name,*args))
    def ih(self,tag,*args):return self.proof(('h',tag,*args))
    def induction(self,tag,var,base,step):return self.proof(('i',tag,var,base,step))
    def replay(self,rows):
        # Term/proof IDs follow their first occurrence in this interleaved
        # stream, including subterms created by definitional normalization.
        nti=npi=0
        for row in rows:
            k,*v=row
            if k=='T':assert self.terms.make(*v)==nti;nti+=1
            elif k=='P':assert self.proof(v)==npi;npi+=1
            elif k=='H':self.assumption(*v)
            elif k=='D':self.rule(*v)
            else:raise ValueError(k)
        return self


def run_plus(d):
    t=d.terms;mk=t.make;num=t.num;a,b,c=t.var('N',0),t.var('N',1),t.var('C',2)
    l=mk('run',mk('add',a,b),c);r=mk('run',b,mk('run',a,c));h=d.assumption((),l,r)
    base=d.refl(t.instantiated(l,(b,),(num(0),)),t.instantiated(r,(b,),(num(0),)))
    ih=d.ih(h);step=d.cong(mk('step',t.var('C',-1)),'C',ih)
    return d.rule('runPlus',(a,b,c),l,r,d.induction(h,b,base,step))


def power_slide(d,u,m,v):
    assert u and v and u+m==m+v
    name='slide/'+u+'/'+m+'/'+v
    if name in d.lemmas:return name
    t=d.terms;n=t.var('N',0);x=t.var('W',1);hole=t.var('W',-1)
    left=t.rep(u,n,t.litword(m,x));right=t.litword(m,t.rep(v,n,x));h=d.assumption((),left,right)
    base=d.refl(t.instantiated(left,(n,),(t.num(0),)),t.instantiated(right,(n,),(t.num(0),)))
    step=d.cong(t.litword(u,hole),'W',d.ih(h))
    return d.rule(name,(n,x),left,right,d.induction(h,n,base,step))


def chain(d,m,n,x,y,z,p,q):
    t=d.terms;hole=t.var('C',-1)
    return d.trans(d.use('runPlus',m,n,x),d.cong(t.make('run',n,hole),'C',p),q)


def fixed_pump(d,i,p):
    t=d.terms;mk=t.make;n=t.var('N',0);a=t.var('W',1);b=t.var('W',2);hole=t.var('W',-1)
    q=p['q'];side=int(p['dir']==-1);k=t.num(p['ticks']);u=p['unit'];v=p['output'][::-1];carry=p['context'][::-1]
    cfg=lambda a,b:t.cfg(q,side,b,t.litword(carry,a));L=lambda a:t.litword(v,a);R=lambda b:t.litword(u,b)
    time=mk('clk',k,n);left=mk('run',time,cfg(a,t.rep(u,n,b)));right=cfg(t.rep(v,n,a),b)
    h=d.assumption((a,b),left,right);base=d.refl(t.instantiated(left,(n,),(t.num(0),)),t.instantiated(right,(n,),(t.num(0),)))
    copy='local'+str(i);old=cfg(a,R(b));end=cfg(L(a),b)
    d.rule(copy,(a,b),mk('run',k,old),end,d.refl(mk('run',k,old),end))
    middle=t.rep(u,n,b);start=cfg(a,R(middle));mid=cfg(L(a),middle)
    p1=d.use('runPlus',k,time,start);p2=d.cong(mk('run',time,t.var('C',-1)),'C',d.use(copy,a,middle))
    p3=d.ih(h,L(a),b);slide=power_slide(d,v,v,v);p4=d.cong(cfg(hole,b),'W',d.use(slide,n,a))
    return d.rule('sweep'+str(i),(n,a,b),left,right,d.induction(h,n,base,d.trans(p1,p2,p3,p4)))


def fixed_pump_qf(d,i,p):
    """Increment the number of copies with an invariant of fixed parameters.

    For target n and current j use Phi(j, L^(n-j) a, b), 0 <= j <= n.
    A single bounded quantifier-free induction discharges the two hypotheses.
    The guarded arithmetic equation is part of the checked induction rule.
    """
    t=d.terms;mk=t.make;n=t.var('N',0);a=t.var('W',1);b=t.var('W',2);j=t.var('N',3)
    wh=t.var('W',-1);ch=t.var('C',-1);nh=t.var('N',-1)
    q=p['q'];side=int(p['dir']==-1);k=t.num(p['ticks']);u=p['unit'];v=p['output'][::-1];carry=p['context'][::-1]
    cfg=lambda a,b:t.cfg(q,side,b,t.litword(carry,a));L=lambda a:t.litword(v,a);R=lambda b:t.litword(u,b)
    def phi(j,a,b):return (mk('run',mk('clk',k,j),cfg(a,t.rep(u,j,b))),cfg(t.rep(v,j,a),b))
    left,right=phi(n,a,b);sj=mk('su',j);rem=mk('sub',n,j);next_rem=mk('sub',n,sj)
    old_a=t.rep(v,rem,a);new_a=t.rep(v,next_rem,a)
    cur_l,cur_r=phi(j,old_a,b);h=d.assumption((),cur_l,cur_r)
    guard=d.assumption((),rem,mk('su',next_rem))
    base=d.refl(t.instantiated(cur_l,(j,),(t.num(0),)),t.instantiated(cur_r,(j,),(t.num(0),)))
    copy='local'+str(i);old=cfg(a,R(b));end=cfg(L(a),b)
    d.rule(copy,(a,b),mk('run',k,old),end,d.refl(mk('run',k,old),end))
    # Transport the fixed induction hypothesis to the shifted accumulator.
    eq_a=d.cong(t.rep(v,nh,a),'N',d.ih(guard))
    ll,rr=phi(j,wh,b)
    shifted=d.trans(d.cong(ll,'W',d.sym(eq_a)),d.ih(h),d.cong(rr,'W',eq_a))
    time=mk('clk',k,j);middle=t.rep(u,j,b);start=cfg(new_a,R(middle))
    p1=d.use('runPlus',k,time,start);p2=d.cong(mk('run',time,ch),'C',d.use(copy,new_a,middle))
    slide=power_slide(d,v,v,v);p4=d.cong(cfg(wh,b),'W',d.use(slide,j,new_a))
    step=d.trans(p1,p2,shifted,p4)
    proof=d.proof(('b',h,guard,j,n,base,step))
    return d.rule('sweep'+str(i),(n,a,b),left,right,proof)
