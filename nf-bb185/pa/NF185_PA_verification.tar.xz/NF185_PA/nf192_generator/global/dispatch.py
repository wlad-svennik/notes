"""Instantiate the verified finite-word arithmetic proofs in the signed source step.

Each legal source tag is refined only by whether its selected decrement
operand is zero. Two independent symbolic calculations must give the same
entry and return frame for all remaining natural parameters. This is the
finite source dispatch in the global concatenation proof.
"""
from __future__ import annotations
from argparse import ArgumentParser
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import gzip,json,sys
from hashlib import sha256
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from equational_arithmetic import Derivation,Terms
SOURCE_BYTES=(ROOT/'inputs/countdown.sites.json').read_bytes()
assert sha256(SOURCE_BYTES).hexdigest()=='b991565b82033c133e1f2b4618dfe32d1e7ff1ef02e8e18620a2dfdccb5307aa'
SITES=json.loads(SOURCE_BYTES);N=len(SITES);assert N==3089
PATHS=[r[0] for r in SITES];PREFIX={}
for i,p in enumerate(PATHS):
    for j in range(len(p)+1):PREFIX.setdefault(p[:j],i)
ORDER=(2,8,1,4,3,7,0,5,6)


def cut(path,side):
    j=path.rfind(side);return path[:j] if j!=-1 else ''


def plus(path):
    j=path.rfind('0');return path[:j]+'1' if j!=-1 else ''


def next_pc(pc,zero):
    bits,op,arg=SITES[pc]
    if op=='CD' and zero and bits.endswith('1'):return None
    if op=='CC':
        for _ in range(arg):bits=cut(bits,'1')
    else:
        count=arg if op=='CB' else int(op=='CD' and zero)
        for _ in range(count):bits=cut(bits,'0')
        bits=plus(bits)
    return PREFIX[bits]


def valid(pc,cold):return 0<=pc<N and (not cold or pc<3 or pc>9)


@dataclass(frozen=True)
class Affine:
    constant:int
    variable:int|None
    def shift(self,n):return Affine(self.constant+n,self.variable)


def copies(word,n):
    assert n.constant>=0
    return list(word*n.constant)+([] if n.variable is None else [(n.variable,word)])


@dataclass(frozen=True)
class Source:
    pc:int
    cold:bool
    regs:tuple[Affine,...]
    gap:Affine
    spares:Affine


def source_patterns(pc,cold,zero):
    assert valid(pc,cold)
    _,op,arg=SITES[pc];r=[Affine(0,i) for i in range(9)]
    if op=='CD':
        assert not (cold and arg==0)
        r[arg]=Affine(0,None) if zero else Affine(1,arg)
    a=Source(pc,cold,tuple(r),Affine(0,9),Affine(0,10));np=next_pc(pc,zero)
    if np is None:return a,None
    if op=='CI' and cold and arg==0:r[0]=Affine(0,None)
    elif op=='CI':r[arg]=r[arg].shift(1)
    elif op=='CD' and not zero:r[arg]=r[arg].shift(-1)
    newcold=cold and not(op=='CI' and arg==0);assert valid(np,newcold)
    dg=int(op=='CD' and (not zero or pc==3087))
    return a,Source(np,newcold,tuple(r),a.gap.shift(dg),a.spares.shift(int(op=='CI')))


def literal_frame(s):
    # This definition intentionally leaves each variable at the end of its
    # unary field instead of using the split chosen by the trace generator.
    bits=PATHS[s.pc];ray=list(bits)+copies('0',s.gap.shift(42-len(bits)))+['1']
    for r in ORDER:
        ones=Affine(1,None) if s.cold and r==0 else s.regs[r].shift(2)
        ray+=['0']+copies('1',ones)
    ray+=copies('01',s.spares.shift(24))
    return ray,['1']


def canon_word_equality(left,right):
    # Infinite zero tails allow stripping far-end fixed zeros. The only
    # other conversions are disjoint fixed-word power slides by induction.
    def split(w):
        w=list(w)
        while w and w[-1]=='0':w.pop()
        base='';insert=[]
        for tok in w:
            if isinstance(tok,str):base+=tok
            else:insert.append((len(base),tok))
        return base,insert
    l,ls=split(left);r,rs=split(right)
    n=max(len(l),len(r));l=l.ljust(n,'0');r=r.ljust(n,'0');assert l==r and len(ls)==len(rs),(l,r,ls,rs)
    past=0;slides=[]
    for (a,(i,u)),(b,(j,v)) in zip(ls,rs):
        lo,hi=sorted((a,b));assert lo>=past and i==j and len(u)==len(v);past=hi
        mid=l[lo:hi]
        wu,wv=(u,v) if a<=b else (v,u)
        assert wu+mid==mid+wv
        if mid or wu!=wv:slides.append((wu,mid,wv))
    return slides


def read_local(d,name):
    t=d.terms;params,l,r=d.lemmas[name]
    assert tuple(t.rows[v] for v in params)==tuple(('v','N' if i<11 else 'W',i) for i in range(13))
    def unpack(i,op):row=t.rows[i];assert row[0]==op;return row[1:]
    def number(i):return unpack(i,'#')[0]
    def ray(i):
        ys=[]
        while True:
            row=t.rows[i];op=row[0]
            if op=='v':assert row[1]=='W' and row[2] in (11,12);return ys,row[2]
            if op=='B0' or op=='B1':ys.append(op[1]);i=row[1]
            else:
                assert op.startswith('rep:');kind,k=unpack(row[1],'v');assert kind=='N'
                ys.append((k,op[4:]));i=row[2]
    def cfg(i):
        q,d,x,y=unpack(i,'cfg');assert (number(q),number(d))==(13,0)
        a,ax=ray(x);b,bx=ray(y);assert (ax,bx)==(12,11)
        return a,b
    if t.rows[l][0]=='state':end=None;rr,=unpack(l,'state');assert number(r)==192
    else:rr,=unpack(l,'norm');end=cfg(r)
    tm,start=unpack(rr,'run');cost=[0]*12;todo=[tm]
    while todo:
        j=todo.pop();op,*v=t.rows[j]
        if op=='#':cost[0]+=v[0]
        elif op=='add':todo+=v
        else:
            assert op=='clk';kind,k=unpack(v[1],'v');assert kind=='N' and 0<=k<11
            cost[k+1]+=number(v[0])
    assert cost[0]>0
    return cfg(start),end,cost


def verify_shard(path):
    with gzip.open(path,'rt') as f:d=Derivation(allow_generalized=False).replay(map(json.loads,f))
    rows=[];lemmas=set()
    for name in list(d.lemmas):
        if not name.startswith('branch_'):continue
        p,c,z=map(int,name.split('_')[1:]);c=bool(c);z=bool(z)
        if not valid(p,c):continue
        inp,out,cost=read_local(d,name);s,dest=source_patterns(p,c,z)
        assert (out is None)==(dest is None)
        checked=[]
        for wordpair,frame in [(inp,literal_frame(s))]+([] if dest is None else [(out,literal_frame(dest))]):
            for a,b in zip(wordpair,frame):checked+=canon_word_equality(a,b)
        lemmas.update(checked)
        # Record the source identity of the coefficient variables. On the
        # positive CD branch x_r=pred(shadow_r); all other live x_i are
        # their natural shadows, except unset ghost slots with zero coefficient.
        _,op,arg=SITES[p]
        for j in range(9):
            if (c and j==0) or (op=='CD' and j==arg and z):assert cost[j+1]==0
        rows.append([p,int(c),int(z),-1 if dest is None else dest.pc,
            0 if dest is None else int(dest.cold),cost,len(checked)])
    Terms.replace.cache_clear();Terms.variables.cache_clear();Terms.norm.cache_clear()
    return rows,lemmas


def main():
    ap=ArgumentParser(description=__doc__);ap.add_argument('shards',nargs='+',type=Path);ap.add_argument('--output',type=Path);ap.add_argument('--all',action='store_true');o=ap.parse_args()
    rows=[];slides=set()
    for p in o.shards:
        r,s=verify_shard(p);rows+=r;slides.update(s)
    present=[tuple(row[:3]) for row in rows];assert len(set(present))==len(present)
    if o.all:
        keys={(p,c,z) for p,(_,op,_) in enumerate(SITES) for c in (0,1) if valid(p,c) for z in ((0,1) if op=='CD' else (0,))}
        assert set(present)==keys
    result={'branches':len(rows),'tags':len({(r[0],r[1]) for r in rows}),'returns':sum(r[3]>=0 for r in rows),
            'halt_cases':sum(r[3]<0 for r in rows),'slides':[list(x) for x in sorted(slides)],'rows':sorted(rows)}
    if o.output:
        text=json.dumps(result,separators=(',',':'),sort_keys=True).encode()
        o.output.write_bytes(gzip.compress(text,compresslevel=9,mtime=0))
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','slides')}|{'distinct_word_slides':len(slides)}))

if __name__=='__main__':main()
