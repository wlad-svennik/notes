"""Add checked source-frame and positive-time equations to a physical PRA proof shard.

The sidecar is a continuation of the original numerical proof stream. Every
new conversion is ordinary first-order arithmetic congruence, a previous
finite trace theorem, or a fixed-word slide proved by quantifier-free induction.
"""
from argparse import ArgumentParser
from contextlib import nullcontext
from hashlib import sha256
from itertools import chain
import gzip,json
from pathlib import Path
from dispatch import *
from equational_arithmetic import power_slide


def succ_add(d):
    t=d.terms;a,b=t.var('N',0),t.var('N',1);mk=t.make
    l=mk('add',mk('su',a),b);r=mk('su',mk('add',a,b));h=d.assumption((),l,r)
    z=t.num(0);base=d.refl(t.instantiated(l,(b,),(z,)),t.instantiated(r,(b,),(z,)))
    step=d.cong(mk('su',t.var('N',-1)),'N',d.ih(h));d.rule('globalSuccAdd',(a,b),l,r,d.induction(h,b,base,step))


def positive_time(d,id):
    t=d.terms;op,*v=t.rows[id]
    if op=='#' and v[0]>0:return t.num(v[0]-1),d.refl(id,t.make('su',t.num(v[0]-1)))
    if op!='add':return None
    a,b=v;l=positive_time(d,a);hole=t.var('N',-1)
    if l:
        smaller,proof=l;return t.make('add',smaller,b),d.trans(d.cong(t.make('add',hole,b),'N',proof),d.use('globalSuccAdd',smaller,b))
    r=positive_time(d,b)
    if r:
        smaller,proof=r;return t.make('add',a,smaller),d.cong(t.make('add',a,hole),'N',proof)
    return None


def termword(t,tokens,tail):
    for item in reversed(tokens):
        if isinstance(item,str):tail=t.make('B'+item,tail)
        else:j,w=item;tail=t.rep(w,t.var('N',j),tail)
    return tail


def word_eq(d,a,b,tail):
    t=d.terms;wh=t.var('W',-1);left=termword(t,a,tail);right=termword(t,b,tail)
    if left==right:return left,right,d.refl(left)
    def positions(xs):
        lit='';vs=[]
        for x in xs:
            if isinstance(x,str):lit+=x
            else:vs.append((len(lit),*x))
        return lit,vs
    base,av=positions(a);other,bv=positions(b);assert base==other and len(av)==len(bv)
    parts=[];edge=0
    for (u0,j,u),(v0,k,v) in zip(av,bv):
        lo,hi=sorted((u0,v0));assert lo>=edge and j==k
        parts.extend([('lit',base[edge:lo]),('seg',j,u,v,base[lo:hi],u0<=v0)]);edge=hi
    parts.append(('lit',base[edge:]));l=r=tail;pf=None
    for part in reversed(parts):
        if part[0]=='lit':
            w=part[1]
            if w:
                if pf is not None:pf=d.cong(t.litword(w,wh),'W',pf)
                l,r=t.litword(w,l),t.litword(w,r)
            continue
        _,j,u,v,m,forward=part;n=t.var('N',j)
        if forward:
            fnL=lambda z:t.rep(u,n,t.litword(m,z));fnR=lambda z:t.litword(m,t.rep(v,n,z))
            first=d.use(power_slide(d,u,m,v),n,l) if m or u!=v else None
        else:
            fnL=lambda z:t.litword(m,t.rep(u,n,z));fnR=lambda z:t.rep(v,n,t.litword(m,z))
            first=d.sym(d.use(power_slide(d,v,m,u),n,l)) if m or u!=v else None
        suffix=d.cong(fnR(wh),'W',pf) if pf is not None else None
        pf=d.trans(first,suffix) if first is not None and suffix is not None else first if first is not None else suffix
        l,r=fnL(l),fnR(r)
    assert t.eq(l,left) and t.eq(r,right)
    return l,r,pf if pf is not None else d.refl(l,r)


def frame_eq(d,actual,wanted):
    t=d.terms;wh=t.var('W',-1)
    ar,rr,p=word_eq(d,actual[0],wanted[0],t.var('W',12));al,rl,q=word_eq(d,actual[1],wanted[1],t.var('W',11))
    f=lambda a,b:t.cfg(13,0,a,b)
    return f(ar,al),f(rr,rl),d.trans(d.cong(f(wh,al),'W',p),d.cong(f(rr,wh),'W',q))


def padded(s,l,r):
    a,b=literal_frame(s);return a+['0']*r,b+['0']*l


def timing_tree(t,x):
    op,*args=t.rows[x]
    if op=='#':return args[0]
    if op=='add':return ['+',*(timing_tree(t,i) for i in args)]
    assert op=='clk';c,j=args;assert t.rows[c][0]=='#' and t.rows[j][:2]==('v','N')
    return ['x',t.rows[c][1],t.rows[j][2]]


def extend(d,name):
    t=d.terms;params,l,r=d.lemmas[name];p,c,z=map(int,name.split('_')[1:]);c=bool(c);z=bool(z)
    if not valid(p,c):return None
    inp,out,coeff=read_local(d,name);ss,nxt=source_patterns(p,c,z);rt=t.rows[t.rows[l][1]];assert rt[0]=='run';_,time,starting=rt
    pre,positive=positive_time(d,time);pos=t.make('su',pre);ch=t.var('C',-1);nh=t.var('N',-1)
    actual,expected,eq=frame_eq(d,inp,padded(ss,64,64));assert t.eq(actual,starting)
    head='state' if nxt is None else 'norm';root=lambda tm,cf:t.make(head,t.make('run',tm,cf))
    tx=d.cong(root(nh,expected),'N',d.sym(positive));enter=d.cong(root(time,ch),'C',d.sym(eq));orig=d.use(name,*params)
    finish=r;pieces=[tx,enter,orig]
    if nxt is not None:
        op=SITES[p][1];dy=int(op=='CD' and z and p==3087);inc=int(op=='CI')
        old,finish,pf=frame_eq(d,out,padded(nxt,64-dy,64-3*inc));assert t.eq(r,old);pieces.append(pf)
    destname='source_'+name;d.rule(destname,params,root(pos,expected),finish,d.trans(*pieces))
    return [p,int(c),int(z),-1 if nxt is None else nxt.pc,0 if nxt is None else int(nxt.cold),coeff,timing_tree(t,pre)]


def work(src,dst,verify=False):
    if verify:
        with gzip.open(src,'rt') as x,gzip.open(dst,'rt') as y:
            d=Derivation(allow_generalized=False).replay(map(json.loads,chain(x,y)))
        return sum(n.startswith('source_branch_') for n in d.lemmas)
    with gzip.open(src,'rt') as f:d=Derivation(allow_generalized=False).replay(map(json.loads,f))
    before=len(d.proofs);rows=[]
    with dst.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=5,mtime=0) as f:
        d.output=f;succ_add(d)
        for name in list(d.lemmas):
            if name.startswith('branch_'):
                row=extend(d,name)
                if row is not None:rows.append(row)
    return rows,len(d.proofs)-before


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('sidecar',type=Path);p.add_argument('--replay',action='store_true');p.add_argument('--rows',type=Path);o=p.parse_args()
    if o.replay:print(work(o.source,o.sidecar,True),'replayed source instances')
    else:
        rows,count=work(o.source,o.sidecar)
        if o.rows:o.rows.write_bytes(gzip.compress(json.dumps(rows,separators=(',',':')).encode(),mtime=0))
        print(len(rows),'source instances,',count,'new PRA inferences')
