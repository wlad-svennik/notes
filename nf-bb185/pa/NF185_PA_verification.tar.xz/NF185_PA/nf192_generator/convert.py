"""Compile the public EqPR interleaved transcript to the numerical Lean wire syntax.

Optional backward slicing preserves the original dependencies of named conclusions.
All output is untrusted input to the proof-carrying Lean verifier.
"""
from __future__ import annotations
import argparse,gzip,json
from pathlib import Path
from itertools import chain
from collections import Counter,defaultdict
OPS={'su':2,'add':3,'sub':4,'clk':5,'B0':6,'B1':7,'blank':8,'cfg':9,'step':10,'norm':11,'state':12,'run':13}
PIDS={'r':0,'s':1,'t':2,'c':3,'h':4,'u':5,'i':6,'b':7}
def read(files):
    top=[];data=defaultdict(list);names={}
    for f in files:
        for text in gzip.open(f,'rt'):
            k,*v=json.loads(text);i=len(data[k])
            if k=='D':names[v[0]]=i
            top.append((k,i));data[k].append(v)
    return top,data,names
def termdeps(t):
    op,*xs=t
    return [] if op in ('v','#','blank') else xs
def refs(k,r,names):
    if k=='T': return [('T',u) for u in termdeps(r)]
    if k=='D':
        n,ps,l,rr,p=r
        return [('T',t) for t in [*ps,l,rr]]+[('P',p)]
    if k=='H':
        ps,l,rr=r;assert ps==[];return [('T',l),('T',rr)]
    assert k=='P'
    op,*v=r
    if op=='r':return [('T',j) for j in v]
    if op in ('s','t'):return [('P',j) for j in v]
    if op=='c':return [('T',v[0]),('T',v[1]),('P',v[2])]
    if op=='u':return [('D',names[v[0]])]+[('T',j) for j in v[1:]]
    if op=='h':assert len(v)==1;return [('H',v[0])]
    if op=='i':return list(zip('HTPP',v))
    if op=='b':return list(zip('HHTTPP',v))
    raise ValueError(op)
def slice_rows(data,names,targets):
    need=set();q=[('D',names[n]) for n in targets]
    while q:
        key=q.pop()
        if key in need:continue
        need.add(key);k,i=key
        q.extend(refs(k,data[k][i],names))
    return need
def write(inp,out,targets,manifest):
    order,data,names=read(inp);keep=None if not targets else slice_rows(data,names,targets)
    ids={};counts=Counter();selected={}
    with open(out, 'w', encoding='ascii', newline='\n') as f:
        for key in order:
            if keep is not None and key not in keep:continue
            k,i=key;row=data[k][i];ids[key]=counts[k];counts[k]+=1
            op,*xs=row
            if k=='T':
                if op=='v': vals=[0,(xs[1]+1)*3+('N','W','C').index(xs[0])]
                elif op=='#':vals=[1,*xs]
                elif op.startswith('rep:'):
                    w=op[4:];vals=[14,len(w),int(w[::-1],2),*(ids['T',j] for j in xs)]
                else:vals=[OPS[op],*(ids['T',j] for j in xs)]
                wire=[0,*vals]
            elif k=='P':wire=[1,PIDS[op],*(ids[ref] for ref in refs(k,row,names))]
            elif k=='H':wire=[2,ids['T',xs[0]],ids['T',xs[1]]]
            else:
                name,params,l,r,p=row
                wire=[3,ids['P',p],ids['T',l],ids['T',r],*(ids['T',j] for j in params)]
                if name.startswith('source_branch_') or name in targets:selected[name]=ids[key]
            print(*wire,file=f)
    if manifest:Path(manifest).write_text(json.dumps({'counts':counts,'decls':selected},sort_keys=True)+'\n')
    return dict(counts),selected
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('files',nargs='+',type=Path);p.add_argument('--output',required=True);p.add_argument('--name',action='append',default=[]);p.add_argument('--manifest');o=p.parse_args()
    counts,decls=write(o.files,o.output,o.name,o.manifest);print(counts,len(decls))
