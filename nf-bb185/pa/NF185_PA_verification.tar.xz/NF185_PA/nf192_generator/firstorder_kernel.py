"""Finite first-order stack specialization of the NF192 physical proof.

The two new inductive types are binary words padded with zero at infinity
and a four-field configuration. The branch variables range over naturals
and finite words. The backend has the same 384 raw transitions as the
separately checked infinite-ray encoding.
"""
from argparse import ArgumentParser
from pathlib import Path
import kernel_pumps as core
import kernel_branches as branches
from export_syntax import C, V, Export, ap, arrow, lam, num, pi
from kernel_pumps import EQ,F,HERE,K,NAT,ONE,PRE,PROP,REFL,SUC,TYPE,Z,NREC,case_nat

WORD=K('Word');CONF=K('Configuration')


def inductive(e,name,constructors,recursive=False):
    """Emit the ordinary singly-index-free inductive and its recursor."""
    full=PRE+name;typ=C(full);tn=e.name(full);rname=full+'.rec';rn=e.name(rname)
    mot=V('motive');mot_type=arrow(typ,('sort','u'))
    ctors=[];minor_types=[]
    for i,(short,fields) in enumerate(constructors):
        c=e.name(full+'.'+short);ft=pi(fields,typ)
        ctors.append({'name':c,'levelParams':[],'type':e.expr(ft),'induct':tn,'cidx':i,
                      'numParams':0,'numFields':len(fields),'isUnsafe':False})
        term=ap(C(full+'.'+short),*[V(n) for n,_ in fields]);minor=list(fields)
        minor += [(n+'_ih',ap(mot,V(n))) for n,t in fields if t==typ]
        minor_types.append((short,pi(minor,ap(mot,term))))
    pref=[('motive',mot_type)]+minor_types
    rtype=e.expr(pi(pref+[('value',typ)],ap(mot,V('value'))));rules=[]
    for (cn,fields),ct in zip(constructors,ctors):
        args=[V(n) for n,_ in fields]
        for n,t in fields:
            if t==typ:args.append(ap(C(rname,'u'),mot,*[V(s) for s,_ in minor_types],V(n)))
        rhs=lam(pref+fields,ap(V(cn),*args));rules.append({'ctor':ct['name'],'nfields':len(fields),'rhs':e.expr(rhs)})
    rec={'all':[tn],'isUnsafe':False,'k':False,'levelParams':[e.name('u')],'name':rn,'numIndices':0,
          'numMinors':len(ctors),'numMotives':1,'numParams':0,'rules':rules,'type':rtype}
    ind={'all':[tn],'ctors':[ct['name'] for ct in ctors],'isRec':recursive,'isReflexive':False,
         'isUnsafe':False,'levelParams':[],'name':tn,'numIndices':0,'numNested':0,'numParams':0,'type':e.expr(TYPE)}
    e.row({'inductive':{'ctors':ctors,'recs':[rec],'types':[ind]}})


def types(e):
    inductive(e,'Word',[('blank',[]),('bit0',[('more',WORD)]),('bit1',[('more',WORD)])],True)
    inductive(e,'Configuration',[('mk',[('state',NAT),('side',NAT),('ahead',WORD),('behind',WORD)])])


def physical(e):
    def put(n,p,t,b):e.declare(PRE+n,p,t,b)
    types(e);T,n,x,y=map(V,['T','n','x','y'])
    put('chooseZero',[('T',TYPE),('n',NAT),('x',T),('y',T)],T,case_nat(T,n,x,'predTag',y))
    def zr(t,n,a,b):return F('chooseZero',t,n,a,b)
    b,w=V('b'),V('w')
    put('push',[('b',NAT),('w',WORD)],WORD,zr(WORD,b,ap(K('Word.bit0'),w),ap(K('Word.bit1'),w)))
    for label,ty,base,values in [('head',NAT,Z,(Z,ONE)),('tail',WORD,K('Word.blank'),(V('r'),V('r')))]:
        rm=lam([('v',WORD)],ty)
        minors=[lam([('r',WORD),('ih',ty)],v) for v in values]
        put(label,[('w',WORD)],ty,ap(C(PRE+'Word.rec',1),rm,base,*minors,w))
    fields=[('q',NAT),('d',NAT),('a',WORD),('b',WORD)];q,d,a,b=map(V,['q','d','a','b'])
    put('cfg',fields,CONF,ap(K('Configuration.mk'),q,d,a,b))
    for (v,t),label in zip(fields,['state','sense','fore','aft']):
        mot=lam([('c',CONF)],t);minor=lam(fields,V(v))
        put(label,[('c',CONF)],t,ap(C(PRE+'Configuration.rec',1),mot,minor,V('c')))
    wr,m=V('write'),V('move')
    fr=F('cfg',q,m,F('tail',a),F('push',wr,b))
    rv=F('cfg',q,m,b,F('push',wr,F('tail',a)))
    put('applyRow',[('q',NAT),('write',NAT),('move',NAT),('d',NAT),('a',WORD),('b',WORD)],CONF,
        zr(CONF,m,zr(CONF,d,fr,rv),zr(CONF,d,rv,fr)))
    rows=core.raw_table();tag=V('tag');bit=V('bit')
    tableparams=[('tag',NAT),('bit',NAT),('d',NAT),('a',WORD),('b',WORD)]
    put('table192',tableparams,CONF,F('cfg',num(192),d,a,b))
    for j in reversed(range(192)):
        def val(bit):
            nq,wr,mv=rows[j,bit];return F('applyRow',num(nq),num(wr),num(mv),d,a,b)
        put('table'+str(j),tableparams,CONF,case_nat(CONF,tag,zr(CONF,bit,val(0),val(1)),
                 'predQ',F('table'+str(j+1),V('predQ'),bit,d,a,b)))
    c=V('c');fore=F('fore',c)
    put('step',[('c',CONF)],CONF,F('table0',F('state',c),F('head',fore),F('sense',c),fore,F('aft',c)))


def norm(e):
    c=V('c');q=F('state',c);d=F('sense',c);a=F('fore',c);b=F('aft',c)
    term=F('chooseZero',CONF,d,c,F('cfg',q,Z,F('push',F('head',a),b),F('tail',a)))
    e.declare(PRE+'norm',[('c',CONF)],CONF,term)


class FilterDefinitions:
    def __init__(self,e,skip):self.e=e;self.skip=skip
    def declare(self,name,*args,**kwargs):
        if name not in self.skip:return self.e.declare(name,*args,**kwargs)


def first_arithmetic(e):
    # The function-valued tail recursion used by the independent infinite-ray
    # proof is absent from the finite-word export and all its dependencies.
    core.arithmetic(FilterDefinitions(e,{PRE+'tailIterate'}))


def canonical_pump(e):
    P,Q,L,R,step,build,k,n=map(V,['P','Q','L','R','step','build','k','n'])
    a,b,i=map(V,['a','b','i']);ab=[('a',P),('b',P)]
    params=[('P',TYPE),('Q',TYPE),('L',arrow(P,P)),('R',arrow(P,P)),('step',arrow(Q,Q)),
            ('build',arrow(P,P,Q)),('k',NAT)]
    rs=lambda m,x:F('iterate',Q,step,m,x);rp=lambda f,m,x:F('iterate',P,f,m,x)
    cfg=lambda x,y:ap(build,x,y);local=pi(ab,EQ(Q,rs(k,cfg(a,ap(R,b))),cfg(ap(L,a),b)))
    def claim(m,x,y):return EQ(Q,rs(F('clock',k,m),cfg(x,rp(R,m,y))),cfg(rp(L,m,x),y))
    mot=lam([('j',NAT)],pi(ab,claim(V('j'),a,b)));initial=lam(ab,REFL(Q,cfg(a,b)))
    t=F('clock',k,i);inp=cfg(a,ap(R,rp(R,i,b)));lhs=rs(F('plus',k,t),inp)
    a1=rs(t,rs(k,inp));a2=rs(t,cfg(ap(L,a),rp(R,i,b)));a3=cfg(rp(L,i,ap(L,a)),b);rhs=cfg(ap(L,rp(L,i,a)),b)
    p1=F('iteratePlus',Q,step,k,t,inp)
    p2=F('congr',Q,Q,lam([('v',Q)],rs(t,V('v'))),rs(k,inp),cfg(ap(L,a),rp(R,i,b)),ap(V('local'),a,rp(R,i,b)))
    p3=ap(V('ih'),ap(L,a),b)
    comm=F('powerSlide',P,L,L,L,lam([('v',P)],REFL(P,ap(L,ap(L,V('v'))))),i,a)
    p4=F('congr',P,Q,lam([('v',P)],cfg(V('v'),b)),rp(L,i,ap(L,a)),ap(L,rp(L,i,a)),comm)
    join=lambda a,b,c,p,q:F('trans',Q,a,b,c,p,q)
    rec=lam([('i',NAT),('ih',pi(ab,claim(i,a,b)))]+ab,
            join(lhs,a1,rhs,p1,join(a1,a2,rhs,p2,join(a2,a3,rhs,p3,p4))))
    e.declare(PRE+'pump',params+[('local',local),('n',NAT)],pi(ab,claim(n,a,b)),NREC(0,mot,initial,rec,n),theorem=True)


def first_words(e):
    core.words_and_composition(FilterDefinitions(e,{PRE+'tailEq'}));canonical_pump(e)


def first_locals(e):
    import gzip,json
    cert=json.loads(gzip.decompress(core.CERT.read_bytes()));assert cert['table']==core.TABLE_HASH
    a,b,n=map(V,['a','b','n']);ab=[('a',WORD),('b',WORD)]
    for i,p in enumerate(cert['pumps']):
        q,d,k=map(num,[p['q'],int(p['dir']==-1),p['ticks']]);word=core.word
        S=lambda A,B:F('cfg',q,d,B,word(p['context'][::-1],A))
        L=lam([('x',WORD)],word(p['output'][::-1],V('x')));R=lam([('y',WORD)],word(p['unit'],V('y')))
        start=S(a,word(p['unit'],b));end=S(word(p['output'][::-1],a),b);run=lambda t,c:F('iterate',CONF,K('step'),t,c)
        name='local'+str(i);e.declare(PRE+name,ab,EQ(CONF,run(k,start),end),REFL(CONF,end),theorem=True)
        input=S(a,F('iterate',WORD,R,n,b));output=S(F('iterate',WORD,L,n,a),b)
        statement=EQ(CONF,run(F('clock',k,n),input),output)
        proof=F('pump',WORD,CONF,L,R,K('step'),lam(ab,S(a,b)),k,K(name),n,a,b)
        e.declare(PRE+'sweep'+str(i),[('n',NAT)]+ab,statement,proof,theorem=True)

def configure():
    # Each invocation writes one backend in its own OS process. The existing
    # branch compiler is parametric in its two carrier types and state reader.
    core.STACK=WORD;core.CONFIG=CONF
    branches.STACK=WORD;branches.CONFIG=CONF;branches.control_of=lambda c:F('state',c)
    branches.physical=physical;branches.normalized_support=norm
    branches.arithmetic=first_arithmetic;branches.pumping=lambda e:None
    branches.words_and_composition=first_words;branches.local_rules=first_locals


def main():
    p=ArgumentParser(description=__doc__);p.add_argument('output',type=Path)
    p.add_argument('--lo',type=int,default=0);p.add_argument('--hi',type=int,default=1)
    p.add_argument('--cold',type=int,choices=(0,1));p.add_argument('--zero',type=int,choices=(0,1));p.add_argument('--types-only',action='store_true');p.add_argument('--boot',action='store_true');p.add_argument('--interface',action='store_true')
    args=p.parse_args();configure()
    if args.types_only:
        with args.output.open('wb') as f:physical(Export(f))
    elif args.boot:
        import kernel_boot as boot
        boot.STACK=WORD;boot.CONFIG=CONF;boot.arithmetic=first_arithmetic;boot.words_and_composition=first_words
        boot.physical=physical;boot.normalized_support=norm
        with args.output.open('wb') as f:boot.boot(Export(f))
    elif args.interface:
        import kernel_interface as table
        table.STACK=WORD;table.CONFIG=CONF;table.physical=physical;table.normalized_support=norm
        with args.output.open('wb') as f:table.output(Export(f))
    else:branches.generate(args)

if __name__=='__main__':main()
