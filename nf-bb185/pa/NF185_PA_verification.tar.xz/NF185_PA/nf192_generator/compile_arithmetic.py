"""Extract genuine first-order equational proofs of the concrete NF192 branch theorems.

A kernel export supplies a candidate proof DAG. Its source proof types need
not be trusted. The target checker independently derives the first-order
conclusion of every used instruction in its own equational induction calculus.
The optional output contains only first-order terms and inference records.
"""
from argparse import ArgumentParser
from functools import lru_cache
import gzip
import json
from pathlib import Path
from equational_arithmetic import Derivation,run_plus,fixed_pump,fixed_pump_qf,power_slide,chain
from check_kernel_statements import Reader,QUAL,CERT


class Compiler(Reader):
    def __init__(self,d,qf=False):
        super().__init__();self.d=d;self.t=d.terms;self.nbranch=self.nwindow=0
        run_plus(d)
        for i,p in enumerate(CERT['pumps']):(fixed_pump_qf if qf else fixed_pump)(d,i,p)
    @lru_cache(maxsize=350000)
    def fun(self,i):
        head,args=self.apps(i)
        if head[0]=='const':return self.names[head[1]['name']],args
        return head,args
    def type_sort(self,i):
        tag,body=self.expr[i];assert tag=='const'
        return {'Nat':'N',QUAL+'Word':'W',QUAL+'Configuration':'C'}[self.names[body['name']]]
    @lru_cache(maxsize=500000)
    def term(self,i,env):
        t=self.t;tag,body=self.expr[i]
        if tag=='bvar':return env[~body]
        if tag=='natVal':return t.num(int(body))
        name,args=self.fun(i)
        if not isinstance(name,str):
            if name[0]!='lam' or len(args)!=1:raise ValueError('term is not first order after beta reduction',name,args)
            return self.term(name[1]['body'],env+(self.term(args[0],env),))
        s=name.removeprefix(QUAL)
        if s=='iterate':
            typ,f,n,x=args
            if self.type_sort(typ)=='C':
                self.call(f,QUAL+'step',0);return t.make('run',self.term(n,env),self.term(x,env))
            assert self.type_sort(typ)=='W';return t.rep(self.unit(f),self.term(n,env),self.term(x,env))
        if s=='push':return t.make('B'+str(self.num(args[0])),self.term(args[1],env))
        if s=='Word.blank':assert not args;return t.make('blank')
        spec={'cfg':'cfg','norm':'norm','state':'state','step':'step','plus':'add','clock':'clk'}
        return t.make(spec[s],*[self.term(x,env) for x in args])
    def context(self,i,env,hole):
        tag,b=self.expr[i]
        if tag=='lam':return self.term(b['body'],env+(hole,))
        name,args=self.fun(i);assert not args
        return self.t.make({QUAL+'norm':'norm',QUAL+'state':'state',QUAL+'step':'step'}[name],hole)
    @lru_cache(maxsize=200000)
    def proof(self,i,env):
        name,args=self.fun(i);d=self.d;t=self.t
        T=lambda j:self.term(args[j],env);P=lambda j:self.proof(args[j],env)
        if name=='Eq.refl':return d.refl(T(1))
        assert name.startswith(QUAL);name=name.removeprefix(QUAL)
        if name=='trans':return d.trans(P(4),P(5))
        if name=='symm':return d.sym(P(3))
        if name=='congr':
            sort=self.type_sort(args[0]);hole=t.var(sort,-1)
            return d.cong(self.context(args[2],env,hole),sort,P(5))
        if name=='chain':return chain(d,T(2),T(3),T(4),T(5),T(6),P(7),P(8))
        if name=='powerSlide':
            u=self.unit(args[1]);v=self.unit(args[2]);m=self.unit(args[3]);return d.use(power_slide(d,u,m,v),T(5),T(6))
        if name.startswith('rawWindow') or name.startswith('sweep'):
            return d.use(name,*[self.term(i,env) for i in args])
        raise ValueError('unsupported proof operation',name)
    def simple_decl(self,name,decl):
        typ=decl['type'];pf=decl['value'];params=[]
        while self.expr[typ][0]=='forallE':
            _,bd=self.expr[typ];k,ld=self.expr[pf];assert k=='lam'
            sort=self.type_sort(bd['type']);assert self.type_sort(ld['type'])==sort
            params.append(self.t.var(sort,len(params)));typ=bd['body'];pf=ld['body']
        env=tuple(params);ty,left,right=self.call(typ,'Eq',3);sort=self.type_sort(ty)
        l=self.term(left,env);r=self.term(right,env);p=self.proof(pf,env)
        assert self.t.sorts[l]==self.t.sorts[r]==sort
        self.d.rule(name,env,l,r,p)
        if name.startswith('rawWindow'):self.nwindow+=1
        if name.startswith('branch_'):
            self.nbranch+=1;self.check(name,decl['type'])
    def read_proofs(self,p):
        op=gzip.open if p.suffix=='.gz' else open
        with op(p,'rt') as f:
            for line in f:
                r=json.loads(line)
                if 'in' in r:
                    a=r.get('str') or r.get('num');prefix=a['pre'];part=str(a.get('str',a.get('i')))
                    self.names[r['in']]=(self.names[prefix]+'.' if prefix else '')+part
                elif 'ie' in r:
                    assert r.pop('ie')==len(self.expr);self.expr.append(next(iter(r.items())))
                elif 'thm' in r:
                    decl=r['thm'];name=self.names[decl['name']].removeprefix(QUAL)
                    if name.startswith('rawWindow') or name.startswith('branch_') or name=='blankMargin':self.simple_decl(name,decl)
        assert self.nbranch or 'blankMargin' in self.d.lemmas
        return self


def do(source,output=None,qf=False):
    with (open(output,'wb') if output else open('/dev/null','wb')) as dst:
        with gzip.GzipFile(filename='',fileobj=dst,mode='wb',compresslevel=5,mtime=0) as out:
            d=Derivation(out if output else None,allow_generalized=not qf);c=Compiler(d,qf).read_proofs(source)
            return {'branches':c.nbranch,'raw_windows':c.nwindow,'theorems':len(d.lemmas),'terms':len(d.terms.rows),
                    'inferences':len(d.proofs),'by_rule':d.counts,'boot':'blankMargin' in d.lemmas}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('--write',type=Path);p.add_argument('--replay',action='store_true');p.add_argument('--qf',action='store_true')
    o=p.parse_args()
    if o.replay:
        with gzip.open(o.source,'rt') as f:d=Derivation(allow_generalized=not o.qf).replay(map(json.loads,f))
        print(json.dumps({'theorems':len(d.lemmas),'inferences':len(d.proofs),'by_rule':d.counts}))
    else:print(json.dumps(do(o.source,o.write,o.qf)))
