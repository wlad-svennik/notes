# PA verification of the 185-state machine

The primary Lean module is `NF185PAInternalConsistency`. It proves that first-order Peano arithmetic proves the implication from the literal machine's nonhalting to the usual consistency sentence for PA. The compiled theorem is `NF185PA.internal_consistency`. The machine's 370 binary transitions and its 2,959 source instructions are included.

`NF185PAMachineTransfer` proves in PA that a halt of the original 192-state pure NF machine forces a halt of the 185-state machine. The review module `NF185_PA` checks both PA implications and prints the Busy Beaver theorem dependencies.

`NF185PAIndependence` specializes the Busy Beaver consequences to 185 states. `REGISTER-PROOF.md` explains the arithmetic proof search and the reverse result for the original 192-state program. The 185 proof's finite tape cases occupy `NF185PATapeCases000` through `NF185PATapeCases092`. The module `NF185PATapeAll` joins these 93 kernel computations. The alternative `NF185PAFast` uses native arithmetic evaluation for its coverage certificate.

## Reproduce

Use Python 3.10 or later and the Lean compiler selected by the included `lean-toolchain`. The pinned Mathlib commit is `56a005855ea17e0b0958f73ec801ae140b0a1679`. The package includes the Foundation modules needed by this argument and the project sources imported by the targets. `receipts/verification-scope.json` describes which sources were compiled for the published audit. `receipts/new-module-audits.json` identifies the checked source and object for each new module and records the compiler’s printed axiom dependencies. The source manifest records the SHA-256 digest and origin group for every module. The 153 included Foundation source files agree byte-for-byte with Foundation commit `fbcfee52cb4a892087fa978366282a9ebd844f29`. The top-level SHA-256 manifest also covers the 192-state archived branch proofs in `data/` and every numerical input.

In the extracted directory, run the following commands. `lake update` is unnecessary when the registered dependency manifest is present.

```sh
python3 replay.py --verify-only
python3 -B verify.py
lake exe cache get
lake env python3 replay.py --target NF185PAInternalConsistency --jobs 2
lake env python3 replay.py --resume --target NF185_PA --jobs 2
```

To build a different endpoint or all default endpoints in the same directory, run `lake env python3 replay.py --resume` with the desired `--target` arguments. The script compiles from the packaged source in dependency order, checks its compiler revision, rejects unfinished Lean proofs, and validates the target's axiom report against `axiom-policy.json`. It writes per-module logs and a final receipt under `build/`. A source, dependency, or output-digest change invalidates the corresponding cached compilation.

The optional `--reuse-prerequisites` mode is intended for an existing installation with the historical modules and the 93 185-state tape case modules already compiled. Set `LEAN_PATH` to these directories and choose a separate `--build` directory. This mode still rebuilds the requested new arguments. The receipt records which mode ran.

## Scope of the old tape check

`NF192PAHaltSound` proves the reverse implication from an internal 192-state halt to a nine-row proof using the finite coverage proposition as an argument. `NF192PAFrozenSound` instantiates that argument with the older published 65 native transcript decisions. Each checks a specified closed Boolean. The 192 branch transcript and index files for those decisions are in `data/`. The primary 185-state internal consistency theorem uses the 185-state kernel coverage. Exact audit lists accompany the replay receipts.

The arithmetic dependency sources come from the NF192 PA review package and the published 185-state verification project. Foundation is distributed under the accompanying `FOUNDATION-LICENSE`. Upstream Mathlib and its dependency revisions appear in `lake-manifest.json`.
