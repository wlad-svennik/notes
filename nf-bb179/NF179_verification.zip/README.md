# Physical verification of the 179-state pure NF machine

The file `NF179.tm` gives the literal two-symbol transition table. On the all-zero two-way tape it enters the halt state if and only if pure Quine New Foundations proves falsum. It uses 179 working states. The sole halt transition is `k:302 1 0 L halt`.

## Halting criterion

At tick 230,892 the machine reaches register instruction zero with epoch counter five, all eight other registers zero, a gap of 97 and 78 spare cells. Lean checked the entire tape at that tick and proved that each earlier configuration is live. The register program is byte-for-byte the published 180-state program, which reaches the same register checkpoint. The Lean reference kernel accepted the 7,792 signed instruction branches of the new machine. Every live branch ends in the register frame of its prescribed successor. Each terminal branch implements the prescribed halt. The frame proofs cover arbitrary register lengths by induction. Composing these steps with the published soundness and fair-search results gives both directions of the standard halting criterion.

## How the reduction works

The predecessor had two decoder states reached immediately after right moves that wrote different bits. The new machine steps left to recover that bit when it needs to distinguish their continuations. Existing control states take over the two old roles and one helper state chooses the continuation. This removes two states and adds one. The discovery archive contains a five-edit version that isolates the saving, as well as the precise search witness for the primary table.

## Checks and reproduction

* `python3 verify.py --examples` checks the SHA-256 manifest, complete literal table, blank startup, symbolic traces, and 142,544 full successor-tape comparisons plus 16 halting fixtures. The supplementary fixtures executed 94,093,082 binary transitions.
* `python3 verify.py --kernel --jobs 2` regenerates and submits all 7,792 signed branches to the Lean reference kernel. Use Lean 4.35.0 with `leanchecker-paranoid` on PATH. The 30 accepted export digests are in `evidence/raw-kernel.json`.
* `NF179_blank_startup.zip` contains the separate Lean replay of all 230,892 startup steps, the literal table and its state graph. `NF179_discovery_and_local_replay.zip` reproduces the finite decoder search and both resulting 179-state tables.
* The published predecessor proof and its source semantics are in the two archives under `upstream/`. Their additional foundation dependencies are identified by their replay drivers.
* The PA-format executable checker accepted 7,792 witnesses. These finite calculations and the formal ordinary halting criterion are distinct from a completed end-to-end audit of PA independence for this exact table.

**Literal table SHA-256** `36c19b11e2b4c854ae41919cfd7cfc5be5a20f3846453da2e9099798e5edfee3`

**Register source SHA-256** `7bacb7672e2df5f580588cc493b52c62bb0574de94c3a374d28e07195beccd47`

[Published 180-state project](https://github.com/wlad-svennik/notes/tree/87440d0dc4a281caa4a32dd4165838ae9a35a0b0/nf-bb180)
