"""Rebuild the 179-state PA targets with their pinned public dependencies."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,sys
from zipfile import ZipFile
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify_release(root):
    for line in (root/'SHA256SUMS').read_text().splitlines():
        h,name=line.split('  ',1)
        if sha(root/name)!=h:
            raise ValueError('release checksum mismatch: '+name)

def check_audit(source,output):
    expected=set(re.findall(r'^#print axioms ([\w.]+)\s*$',source,re.M))
    found={}
    for n,body in re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",output,re.S):
        found[n]={x.strip() for x in body.split(',') if x.strip()}
    for n in re.findall(r"'([^']+)' does not depend on any axioms",output):
        found[n]=set()
    allowed={'propext','Classical.choice','Quot.sound'}
    if not expected or not expected<=set(found):
        raise ValueError('missing final axiom audit output: '+repr(sorted(expected-set(found))))
    unexpected={n:sorted(found[n]-allowed) for n in expected if found[n]-allowed}
    if unexpected:raise ValueError('unexpected final axiom dependencies: '+repr(unexpected))

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--work',type=Path,default=ROOT.parent/'pa-replay-work');ap.add_argument('--jobs',type=int,default=2);ap.add_argument('targets',nargs='*',default=['NF179Independence']);args=ap.parse_args()
    if args.jobs<1:ap.error('positive job count required')
    verify_release(ROOT.parent)
    base=ROOT.parent/'upstream/NF181_verification.zip'
    assert sha(base)=='ed694fe1be7fc540c8e6248e7caba3d3c7cba24de7837648c65fa31f120be3b1'
    table=ROOT.parent/'NF179.tm';assert sha(table)=='36c19b11e2b4c854ae41919cfd7cfc5be5a20f3846453da2e9099798e5edfee3'
    formal=(ROOT/'src/Blank180Table.lean').read_text()
    assert re.search(r'^abbrev State := Fin 179$',formal,re.M)
    names=json.loads(re.search(r'^def names : Array String := #(.+)$',formal,re.M)[1])
    start=int(re.search(r'^def start : State := (\d+)$',formal,re.M)[1])
    raw=json.loads(re.search(r'def raw : List String := (\[.*?\])\s*theorem literal_exact',formal,re.S)[1])
    assert ('#! start '+names[start]+'\n'+''.join(raw)).encode()==table.read_bytes()
    work=args.work.resolve();work.mkdir(exist_ok=True,parents=True)
    old=work/'published181';old.mkdir(exist_ok=True)
    with ZipFile(base)as zipf:zipf.extractall(old)
    with ZipFile(old/'NF182_PA_verification.zip')as zipf:zipf.extractall(work)
    for folder in [old/'lean',ROOT/'src']:
        for f in folder.rglob('*.lean'):
            target=work/'src'/f.relative_to(folder);target.parent.mkdir(parents=True,exist_ok=True)
            # These public source layers overlap only on byte-identical modules.
            if target.exists() and target.read_bytes()!=f.read_bytes():
                raise ValueError('conflicting source in replay workspace: '+str(target))
            shutil.copyfile(f,target)
    subprocess.run(['lake','exe','cache','get'],cwd=work,check=True)
    subprocess.run(['lake','env',sys.executable,str(ROOT/'build.py'),str(args.jobs),*args.targets],cwd=work,check=True)
    if 'NF179Independence' in args.targets:
        audit=(ROOT/'Audit179.lean').read_text()
        proc=subprocess.run(['lake','env','sh','-ec','export LEAN_PATH="$PWD/build${LEAN_PATH:+:$LEAN_PATH}"; exec lean --stdin'],
            cwd=work,input=audit,check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        print(proc.stdout,end='')
        check_audit(audit,proc.stdout)
if __name__=='__main__':main()
