# From the 179-state table to PA

The start state is `k:74`, which has index 145 in the literal table. The unique halting row is `k:302` reading one. In the arithmetization the working states are the elements of `Fin 179`, and the halt code is 179. The sentence `NF179.H179` asserts existence of a finite blank-tape halting trace of this table.

## Why using the same register source suffices

1. The blank run reaches the canonical register frame at tick 230,892. Its instruction address is zero, register zero contains five, and the remaining registers vanish. The 180-state realization enters the same logical frame at tick 233,734. The finite prefix ends in a live state, so no earlier state on it could have halted. The transition semantics make a halted configuration absorbing.
2. Each of the 2,970 register instructions has a checked symbolic path for every legal cold/warm and zero/positive case. The 7,792 paths cover arbitrary values of the register lengths, free space and spare slots. A live branch reaches the canonical frame for the prescribed successor. A terminal branch reaches the unique halting row. The model lemmas interpret each repetition in an arbitrary model of PA, so the result also covers nonstandard register values.
3. In the forward direction, induction along the register computation carries its boundaries to physical tape checkpoints. In the reverse direction, each live checkpoint advances physical time. The release's 5,940 address checks establish that a live source frame and its designated successor cannot coincide. By induction on the source clock, an everywhere-live source then has a tape checkpoint at or beyond every tape time. A physical halt would persist up to that checkpoint, contradicting its live source state.
4. The exact source and initial register values coincide with the calibrated 180-state realization. Its ranked refutation criterion therefore applies unchanged. In the standard model, the source finds a refutation exactly when pure Quine NF proves falsum. In arbitrary models of PA, physical halting is equivalent to existence of the model's internal numerical refutation. The direct consistency proof uses the established implication from absence of an internal refutation to the internal consistency sentence of PA and first-order completeness.

## Busy Beaver conclusions

If PA is consistent, Gödel's second incompleteness theorem applied to the internal implication from nonhalting to PA consistency excludes a PA proof of nonhalting. If pure NF is consistent, the literal machine runs forever in the standard model, so PA also cannot prove the halting sentence.

For each standard numeral (k), PA verifies the actual finite computation through tick (k). A PA proof of the assertion that every halting 179-state machine has halted by (k) would combine with the verified live prefix to prove nonhalting of the literal machine. Thus PA proves no such numeral bound under NF consistency. The exact standard value exists, and its identification with the corresponding numeral and its negation are then both unprovable in PA.

The direct Lean endpoint is `NF179Independence.lean`. The retained `Blank180` and `NF180PA` implementation namespaces refer to the 179-state table in this isolated source collection. The public aliases explicitly type the machine with `Fin 179`.
