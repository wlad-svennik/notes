"""Build this checkpoint's Lean import graph. Keep independent branches running on errors."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import sys,os,hashlib,subprocess,json,time,re
from collections import Counter
here=Path.cwd().resolve();src=here/'src';build=here/'build';build.mkdir(exist_ok=True)
jobs=int(sys.argv[1]);targets=sys.argv[2:];files={'.'.join(p.relative_to(src).with_suffix('').parts):p for p in src.rglob('*.lean')}
imports=re.compile(r'^\s*(?:(?:public|meta|private)\s+)*import\s+(?:all\s+)?([\w.]+)',re.M)
deps={};keys={}
def use(m):
 if m in keys:return keys[m]
 code=files[m].read_bytes();deps[m]=sorted(set(imports.findall(code.decode()))&files.keys())
 keys[m]=hashlib.sha256(code+''.join(use(n)for n in deps[m]).encode()).hexdigest();return keys[m]
for m in targets:use(m)
env=os.environ.copy();env['LEAN_PATH']=os.pathsep.join([str(build),*(str(Path(x).resolve())for x in env.get('LEAN_PATH','').split(os.pathsep)if x)])
def compile(m):
 f=files[m];out=(build/f.relative_to(src)).with_suffix('.olean');out.parent.mkdir(exist_ok=True,parents=True);log=build/(m+'.log');key=build/(m+'.hash')
 if out.is_file() and key.is_file() and key.read_text()==keys[m]:return True
 with log.open('w')as s:res=subprocess.run(['lean','-j','1','-s','131072','-o',str(out),str(f.relative_to(src))],cwd=src,env=env,stdout=s,stderr=subprocess.STDOUT)
 body=log.read_text()
 if res.returncode or 'sorryAx' in body or "uses 'sorry'" in body:
  print('FAIL',m,body[-370:],flush=True);return False
 key.write_text(keys[m]);return True
anc=Counter(n for ds in deps.values()for n in ds)
pending=set(deps);passed=set();failed=set();blocked=set();busy={}
with ThreadPoolExecutor(jobs)as pool:
 print('modules',len(pending),flush=True)
 while pending or busy:
  hold={m for m in pending if any(x in failed or x in blocked for x in deps[m])}
  if hold:pending-=hold;blocked|=hold;continue
  ready=sorted((m for m in pending if set(deps[m])<=passed),key=lambda m:(m.startswith('NF180PATapeCases'),-anc[m],m))
  for m in ready[:jobs-len(busy)]:pending.remove(m);busy[pool.submit(compile,m)]=m
  if not busy:
   if pending:raise ValueError('cycle')
   break
  done,_=wait(busy,return_when=FIRST_COMPLETED)
  for k in done:
   m=busy.pop(k);(passed if k.result()else failed).add(m)
  if len(passed)%15==0:print('compiled',len(passed),'failed',len(failed),'active',list(busy.values())[:4],flush=True)
print('passed',len(passed),'failed',sorted(failed),'blocked',len(blocked),flush=True)
sys.exit(bool(failed or blocked))
