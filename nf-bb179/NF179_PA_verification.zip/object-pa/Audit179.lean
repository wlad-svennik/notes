import NF179Independence
#check Blank180.Table.literal_exact
#check NF179.model_refutation
#check NF179.halts_iff_nf_refutation
#check NF179.internal_consistency
#check NF179.pa_cannot_prove_nonhalting_of_consistent
#check NF179.pa_independence
#check NF179.true_value_independent
#print axioms NF179.model_refutation
#print axioms NF179.halts_iff_nf_refutation
#print axioms NF179.internal_consistency
#print axioms NF179.pa_cannot_prove_nonhalting_of_consistent
#print axioms NF179.pa_independence
#print axioms NF179.true_value_independent
