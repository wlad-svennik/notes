import NF180PATapeFinite

namespace NF180PA.Links
open Blank180.Data
set_option maxRecDepth 200000
set_option maxHeartbeats 0

def tag (p : Nat) (c : Bool) : Bool := !c

def atTarget (p : Nat) (c : Bool) : Bool := decide (p<2970) && tag p c

def allowed (p : Nat) (op : Command) (c : Bool) : Bool :=
  !tag p c || match op with
    | .inl (r,n) => atTarget n (c && !(r==0))
    | .inr (.inr n) => atTarget n c
    | .inr (.inl (r,z,n,h)) => !(c && (r==0)) && (h || atTarget z c) && atTarget n c

def block (lo : Nat) : Nat → Bool
  | 0 => true
  | n+1 => allowed lo (program lo) false && allowed lo (program lo) true && block (lo+1) n
termination_by n => n

def Covers (lo hi : Nat) : Prop :=
  ∀ p, lo≤p → p<hi → ∀ z, allowed p (program p) z=true

theorem block_sound {lo n : Nat} (h : block lo n = true) : Covers lo (lo+n) := by
  induction n generalizing lo with
  | zero => intro p a b; omega
  | succ n ih =>
    simp only [block,Bool.and_eq_true] at h
    intro p lower upper z
    by_cases atStart : p=lo
    · subst p; cases z <;> first | exact h.1.1 | exact h.1.2
    · exact ih h.2 p (by omega) (by omega) z

theorem Covers.join {a b c : Nat} (l : Covers a b) (r : Covers b c) : Covers a c := by
  intro p hp hq z
  by_cases mid : p<b
  · exact l p hp mid z
  · exact r p (by omega) hq z


end NF180PA.Links
