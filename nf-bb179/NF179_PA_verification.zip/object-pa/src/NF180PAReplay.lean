import NF180PA
import ScannerFrames
import NumericalBound


open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.LiteralTM PA192.BusyBeaver

namespace NF180PA

/-- Halting within a fixed standard number of steps. -/
def byStep (k : Nat) : ArithmeticSentence := beforeF Blank180.Table.machine Blank180.Table.start k

/-- A finite live prefix yields a proof in object PA that the selected
179-state table did not halt within that many ticks. -/
theorem pa_no_halt_through (k : Nat)
    (live : (run Blank180.Table.machine k (blank Blank180.Table.start)).state ≠ none) :
    M6.PA.theory ⊢ ∼(byStep k) := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff, LogicalConnective.HomClass.map_neg]
  intro h
  obtain ⟨j,hj,stop⟩ := before_implies_halts _ _ k (V:=V) h
  obtain ⟨d,rfl⟩ := Nat.exists_eq_add_of_le hj
  exact live (halting_persists _ _ j d stop)

/-- A proposed standard time bound for the whole class, together with the
literal k-step live replay, would allow PA to prove nonhalting. -/
theorem pa_bound_implies_nonhalting (k : Nat)
    (live : (run Blank180.Table.machine k (blank Blank180.Table.start)).state ≠ none) :
    M6.PA.theory ⊢ upper 179 k 🡒 ∼H180 := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff, LogicalConnective.HomClass.map_imply, LogicalConnective.HomClass.map_neg]
  intro bound eventual
  have early := (upper_eval 179 k).mp bound Blank180.Table.machine Blank180.Table.start eventual
  obtain ⟨j,hj,stop⟩ := before_implies_halts _ _ k (V:=V) early
  obtain ⟨d,rfl⟩ := Nat.exists_eq_add_of_le hj
  exact live (halting_persists _ _ j d stop)

theorem pa_live_230892 : M6.PA.theory ⊢ ∼(byStep 230892) := by
  apply pa_no_halt_through
  rw [Blank180.Boot.blank_margin_frame]
  exact Option.some_ne_none _

end NF180PA
#print axioms NF180PA.pa_bound_implies_nonhalting
#print axioms NF180PA.pa_live_230892
