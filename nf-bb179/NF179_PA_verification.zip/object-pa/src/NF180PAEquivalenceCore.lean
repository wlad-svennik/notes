import NF180PAModelSearch
import M6PA.Theory
import Foundation.FirstOrder.Arithmetic.Basic.Model
import NF181PAEightReverse
import NF181PARegisterHalting
import NF181PATapeCompiler
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
namespace NF180PA

theorem equivalent_in_PA_models_of_coverage {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
    (new : Symbolic.Coverage 0 2970) (old : NF181PA.Symbolic.Coverage 0 2971) :
    (V ⊧/![] H180) ↔ (V ⊧/![] NF181PA.H181) := by
  rw [model_refutation_of_coverage new]
  exact ⟨fun h => NF181PA.Symbolic.tape_of_coverage old
    (NF181PA.refutation_reaches_register_halt h), NF181PA.Reverse.halting_implies_pool old⟩

theorem halting_equivalence_of_coverage
    (new : Symbolic.Coverage 0 2970) (old : NF181PA.Symbolic.Coverage 0 2971) :
    M6.PA.theory ⊢ H180 🡘 NF181PA.H181 := by
  apply FFL.Entailment.E_intro
  · apply Arithmetic.complete.{0} M6.PA.theory _
    intro V _ _
    simp only [models_iff,LogicalConnective.HomClass.map_imply]
    exact (equivalent_in_PA_models_of_coverage (V:=V) new old).mp
  · apply Arithmetic.complete.{0} M6.PA.theory _
    intro V _ _
    simp only [models_iff,LogicalConnective.HomClass.map_imply]
    exact (equivalent_in_PA_models_of_coverage (V:=V) new old).mpr
end NF180PA
#print axioms NF180PA.halting_equivalence_of_coverage
