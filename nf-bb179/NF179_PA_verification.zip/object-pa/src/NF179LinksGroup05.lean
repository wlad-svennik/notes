import NF179LinksBase
namespace NF180PA.Links
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part1280 : Covers 1280 1296 := block_sound (lo:=1280) (n:=16) (by decide +kernel)
private theorem part1296 : Covers 1296 1312 := block_sound (lo:=1296) (n:=16) (by decide +kernel)
private theorem part1312 : Covers 1312 1328 := block_sound (lo:=1312) (n:=16) (by decide +kernel)
private theorem part1328 : Covers 1328 1344 := block_sound (lo:=1328) (n:=16) (by decide +kernel)
private theorem part1344 : Covers 1344 1360 := block_sound (lo:=1344) (n:=16) (by decide +kernel)
private theorem part1360 : Covers 1360 1376 := block_sound (lo:=1360) (n:=16) (by decide +kernel)
private theorem part1376 : Covers 1376 1392 := block_sound (lo:=1376) (n:=16) (by decide +kernel)
private theorem part1392 : Covers 1392 1408 := block_sound (lo:=1392) (n:=16) (by decide +kernel)
private theorem part1408 : Covers 1408 1424 := block_sound (lo:=1408) (n:=16) (by decide +kernel)
private theorem part1424 : Covers 1424 1440 := block_sound (lo:=1424) (n:=16) (by decide +kernel)
private theorem part1440 : Covers 1440 1456 := block_sound (lo:=1440) (n:=16) (by decide +kernel)
private theorem part1456 : Covers 1456 1472 := block_sound (lo:=1456) (n:=16) (by decide +kernel)
private theorem part1472 : Covers 1472 1488 := block_sound (lo:=1472) (n:=16) (by decide +kernel)
private theorem part1488 : Covers 1488 1504 := block_sound (lo:=1488) (n:=16) (by decide +kernel)
private theorem part1504 : Covers 1504 1520 := block_sound (lo:=1504) (n:=16) (by decide +kernel)
private theorem part1520 : Covers 1520 1536 := block_sound (lo:=1520) (n:=16) (by decide +kernel)
theorem group1280 : Covers 1280 1536 := (Covers.join (Covers.join (Covers.join (Covers.join part1280 part1296) (Covers.join part1312 part1328)) (Covers.join (Covers.join part1344 part1360) (Covers.join part1376 part1392))) (Covers.join (Covers.join (Covers.join part1408 part1424) (Covers.join part1440 part1456)) (Covers.join (Covers.join part1472 part1488) (Covers.join part1504 part1520))))
end NF180PA.Links
