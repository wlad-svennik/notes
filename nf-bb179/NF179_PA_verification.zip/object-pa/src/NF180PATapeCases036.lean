import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1152_0 : checkWitness 1152 false false 8924 = true := by decide +kernel
private theorem w1152_2 : checkWitness 1152 true false 8915 = true := by decide +kernel
private theorem cases1152 : checkFour 1152 (8924,0,8915,0) = true := by
  simp only [checkFour, w1152_0, w1152_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1152 : Coverage 1152 1153 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases1152)
private theorem w1153_0 : checkWitness 1153 false false 96 = true := by decide +kernel
private theorem w1153_2 : checkWitness 1153 true false 96 = true := by decide +kernel
private theorem cases1153 : checkFour 1153 (96,0,96,0) = true := by
  simp only [checkFour, w1153_0, w1153_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1153 : Coverage 1153 1154 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1153)
private theorem w1154_0 : checkWitness 1154 false false 88 = true := by decide +kernel
private theorem w1154_2 : checkWitness 1154 true false 88 = true := by decide +kernel
private theorem cases1154 : checkFour 1154 (88,0,88,0) = true := by
  simp only [checkFour, w1154_0, w1154_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1154 : Coverage 1154 1155 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1154)
private theorem w1155_0 : checkWitness 1155 false false 591 = true := by decide +kernel
private theorem w1155_1 : checkWitness 1155 false true 4683 = true := by decide +kernel
private theorem w1155_2 : checkWitness 1155 true false 591 = true := by decide +kernel
private theorem w1155_3 : checkWitness 1155 true true 4683 = true := by decide +kernel
private theorem cases1155 : checkFour 1155 (591,4683,591,4683) = true := by
  simp only [checkFour, w1155_0, w1155_1, w1155_2, w1155_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1155 : Coverage 1155 1156 := checkList_sound (ws:=[(591,4683,591,4683)]) (by simpa only [checkList, Bool.and_true] using cases1155)
private theorem w1156_0 : checkWitness 1156 false false 8866 = true := by decide +kernel
private theorem w1156_2 : checkWitness 1156 true false 8862 = true := by decide +kernel
private theorem cases1156 : checkFour 1156 (8866,0,8862,0) = true := by
  simp only [checkFour, w1156_0, w1156_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1156 : Coverage 1156 1157 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases1156)
private theorem w1157_0 : checkWitness 1157 false false 88 = true := by decide +kernel
private theorem w1157_2 : checkWitness 1157 true false 88 = true := by decide +kernel
private theorem cases1157 : checkFour 1157 (88,0,88,0) = true := by
  simp only [checkFour, w1157_0, w1157_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1157 : Coverage 1157 1158 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1157)
private theorem w1158_0 : checkWitness 1158 false false 550 = true := by decide +kernel
private theorem w1158_1 : checkWitness 1158 false true 4646 = true := by decide +kernel
private theorem w1158_2 : checkWitness 1158 true false 550 = true := by decide +kernel
private theorem w1158_3 : checkWitness 1158 true true 4646 = true := by decide +kernel
private theorem cases1158 : checkFour 1158 (550,4646,550,4646) = true := by
  simp only [checkFour, w1158_0, w1158_1, w1158_2, w1158_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1158 : Coverage 1158 1159 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases1158)
private theorem w1159_0 : checkWitness 1159 false false 8901 = true := by decide +kernel
private theorem w1159_2 : checkWitness 1159 true false 8897 = true := by decide +kernel
private theorem cases1159 : checkFour 1159 (8901,0,8897,0) = true := by
  simp only [checkFour, w1159_0, w1159_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1159 : Coverage 1159 1160 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1159)
private theorem w1160_0 : checkWitness 1160 false false 8932 = true := by decide +kernel
private theorem w1160_2 : checkWitness 1160 true false 8923 = true := by decide +kernel
private theorem cases1160 : checkFour 1160 (8932,0,8923,0) = true := by
  simp only [checkFour, w1160_0, w1160_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1160 : Coverage 1160 1161 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases1160)
private theorem w1161_0 : checkWitness 1161 false false 106 = true := by decide +kernel
private theorem w1161_2 : checkWitness 1161 true false 106 = true := by decide +kernel
private theorem cases1161 : checkFour 1161 (106,0,106,0) = true := by
  simp only [checkFour, w1161_0, w1161_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1161 : Coverage 1161 1162 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1161)
private theorem w1162_0 : checkWitness 1162 false false 646 = true := by decide +kernel
private theorem w1162_1 : checkWitness 1162 false true 4738 = true := by decide +kernel
private theorem w1162_2 : checkWitness 1162 true false 637 = true := by decide +kernel
private theorem w1162_3 : checkWitness 1162 true true 4729 = true := by decide +kernel
private theorem cases1162 : checkFour 1162 (646,4738,637,4729) = true := by
  simp only [checkFour, w1162_0, w1162_1, w1162_2, w1162_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1162 : Coverage 1162 1163 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases1162)
private theorem w1163_0 : checkWitness 1163 false false 8897 = true := by decide +kernel
private theorem w1163_2 : checkWitness 1163 true false 8893 = true := by decide +kernel
private theorem cases1163 : checkFour 1163 (8897,0,8893,0) = true := by
  simp only [checkFour, w1163_0, w1163_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1163 : Coverage 1163 1164 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases1163)
private theorem w1164_0 : checkWitness 1164 false false 640 = true := by decide +kernel
private theorem w1164_1 : checkWitness 1164 false true 4732 = true := by decide +kernel
private theorem w1164_2 : checkWitness 1164 true false 631 = true := by decide +kernel
private theorem w1164_3 : checkWitness 1164 true true 4723 = true := by decide +kernel
private theorem cases1164 : checkFour 1164 (640,4732,631,4723) = true := by
  simp only [checkFour, w1164_0, w1164_1, w1164_2, w1164_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1164 : Coverage 1164 1165 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases1164)
private theorem w1165_0 : checkWitness 1165 false false 8868 = true := by decide +kernel
private theorem w1165_2 : checkWitness 1165 true false 8864 = true := by decide +kernel
private theorem cases1165 : checkFour 1165 (8868,0,8864,0) = true := by
  simp only [checkFour, w1165_0, w1165_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1165 : Coverage 1165 1166 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases1165)
private theorem w1166_0 : checkWitness 1166 false false 94 = true := by decide +kernel
private theorem w1166_2 : checkWitness 1166 true false 94 = true := by decide +kernel
private theorem cases1166 : checkFour 1166 (94,0,94,0) = true := by
  simp only [checkFour, w1166_0, w1166_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1166 : Coverage 1166 1167 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1166)
private theorem w1167_0 : checkWitness 1167 false false 86 = true := by decide +kernel
private theorem w1167_2 : checkWitness 1167 true false 86 = true := by decide +kernel
private theorem cases1167 : checkFour 1167 (86,0,86,0) = true := by
  simp only [checkFour, w1167_0, w1167_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1167 : Coverage 1167 1168 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1167)
private theorem w1168_0 : checkWitness 1168 false false 601 = true := by decide +kernel
private theorem w1168_1 : checkWitness 1168 false true 4689 = true := by decide +kernel
private theorem w1168_2 : checkWitness 1168 true false 601 = true := by decide +kernel
private theorem w1168_3 : checkWitness 1168 true true 4689 = true := by decide +kernel
private theorem cases1168 : checkFour 1168 (601,4689,601,4689) = true := by
  simp only [checkFour, w1168_0, w1168_1, w1168_2, w1168_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1168 : Coverage 1168 1169 := checkList_sound (ws:=[(601,4689,601,4689)]) (by simpa only [checkList, Bool.and_true] using cases1168)
private theorem w1169_0 : checkWitness 1169 false false 8884 = true := by decide +kernel
private theorem w1169_2 : checkWitness 1169 true false 8880 = true := by decide +kernel
private theorem cases1169 : checkFour 1169 (8884,0,8880,0) = true := by
  simp only [checkFour, w1169_0, w1169_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1169 : Coverage 1169 1170 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases1169)
private theorem w1170_0 : checkWitness 1170 false false 8880 = true := by decide +kernel
private theorem w1170_2 : checkWitness 1170 true false 8876 = true := by decide +kernel
private theorem cases1170 : checkFour 1170 (8880,0,8876,0) = true := by
  simp only [checkFour, w1170_0, w1170_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1170 : Coverage 1170 1171 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases1170)
private theorem w1171_0 : checkWitness 1171 false false 100 = true := by decide +kernel
private theorem w1171_2 : checkWitness 1171 true false 100 = true := by decide +kernel
private theorem cases1171 : checkFour 1171 (100,0,100,0) = true := by
  simp only [checkFour, w1171_0, w1171_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1171 : Coverage 1171 1172 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1171)
private theorem w1172_0 : checkWitness 1172 false false 8896 = true := by decide +kernel
private theorem w1172_2 : checkWitness 1172 true false 8892 = true := by decide +kernel
private theorem cases1172 : checkFour 1172 (8896,0,8892,0) = true := by
  simp only [checkFour, w1172_0, w1172_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1172 : Coverage 1172 1173 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases1172)
private theorem w1173_0 : checkWitness 1173 false false 660 = true := by decide +kernel
private theorem w1173_1 : checkWitness 1173 false true 4756 = true := by decide +kernel
private theorem w1173_2 : checkWitness 1173 true false 660 = true := by decide +kernel
private theorem w1173_3 : checkWitness 1173 true true 4756 = true := by decide +kernel
private theorem cases1173 : checkFour 1173 (660,4756,660,4756) = true := by
  simp only [checkFour, w1173_0, w1173_1, w1173_2, w1173_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1173 : Coverage 1173 1174 := checkList_sound (ws:=[(660,4756,660,4756)]) (by simpa only [checkList, Bool.and_true] using cases1173)
private theorem w1174_0 : checkWitness 1174 false false 8928 = true := by decide +kernel
private theorem w1174_2 : checkWitness 1174 true false 8919 = true := by decide +kernel
private theorem cases1174 : checkFour 1174 (8928,0,8919,0) = true := by
  simp only [checkFour, w1174_0, w1174_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1174 : Coverage 1174 1175 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases1174)
private theorem w1175_0 : checkWitness 1175 false false 84 = true := by decide +kernel
private theorem w1175_2 : checkWitness 1175 true false 84 = true := by decide +kernel
private theorem cases1175 : checkFour 1175 (84,0,84,0) = true := by
  simp only [checkFour, w1175_0, w1175_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1175 : Coverage 1175 1176 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1175)
private theorem w1176_0 : checkWitness 1176 false false 506 = true := by decide +kernel
private theorem w1176_1 : checkWitness 1176 false true 4602 = true := by decide +kernel
private theorem w1176_2 : checkWitness 1176 true false 506 = true := by decide +kernel
private theorem w1176_3 : checkWitness 1176 true true 4602 = true := by decide +kernel
private theorem cases1176 : checkFour 1176 (506,4602,506,4602) = true := by
  simp only [checkFour, w1176_0, w1176_1, w1176_2, w1176_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1176 : Coverage 1176 1177 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases1176)
private theorem w1177_0 : checkWitness 1177 false false 8880 = true := by decide +kernel
private theorem w1177_2 : checkWitness 1177 true false 8876 = true := by decide +kernel
private theorem cases1177 : checkFour 1177 (8880,0,8876,0) = true := by
  simp only [checkFour, w1177_0, w1177_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1177 : Coverage 1177 1178 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases1177)
private theorem w1178_0 : checkWitness 1178 false false 88 = true := by decide +kernel
private theorem w1178_2 : checkWitness 1178 true false 88 = true := by decide +kernel
private theorem cases1178 : checkFour 1178 (88,0,88,0) = true := by
  simp only [checkFour, w1178_0, w1178_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1178 : Coverage 1178 1179 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1178)
private theorem w1179_0 : checkWitness 1179 false false 548 = true := by decide +kernel
private theorem w1179_1 : checkWitness 1179 false true 4644 = true := by decide +kernel
private theorem w1179_2 : checkWitness 1179 true false 548 = true := by decide +kernel
private theorem w1179_3 : checkWitness 1179 true true 4644 = true := by decide +kernel
private theorem cases1179 : checkFour 1179 (548,4644,548,4644) = true := by
  simp only [checkFour, w1179_0, w1179_1, w1179_2, w1179_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1179 : Coverage 1179 1180 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases1179)
private theorem w1180_0 : checkWitness 1180 false false 8899 = true := by decide +kernel
private theorem w1180_2 : checkWitness 1180 true false 8895 = true := by decide +kernel
private theorem cases1180 : checkFour 1180 (8899,0,8895,0) = true := by
  simp only [checkFour, w1180_0, w1180_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1180 : Coverage 1180 1181 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases1180)
private theorem w1181_0 : checkWitness 1181 false false 8930 = true := by decide +kernel
private theorem w1181_2 : checkWitness 1181 true false 8921 = true := by decide +kernel
private theorem cases1181 : checkFour 1181 (8930,0,8921,0) = true := by
  simp only [checkFour, w1181_0, w1181_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1181 : Coverage 1181 1182 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases1181)
private theorem w1182_0 : checkWitness 1182 false false 112 = true := by decide +kernel
private theorem w1182_2 : checkWitness 1182 true false 112 = true := by decide +kernel
private theorem cases1182 : checkFour 1182 (112,0,112,0) = true := by
  simp only [checkFour, w1182_0, w1182_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1182 : Coverage 1182 1183 := checkList_sound (ws:=[(112,0,112,0)]) (by simpa only [checkList, Bool.and_true] using cases1182)
private theorem w1183_0 : checkWitness 1183 false false 644 = true := by decide +kernel
private theorem w1183_1 : checkWitness 1183 false true 4736 = true := by decide +kernel
private theorem w1183_2 : checkWitness 1183 true false 635 = true := by decide +kernel
private theorem w1183_3 : checkWitness 1183 true true 4727 = true := by decide +kernel
private theorem cases1183 : checkFour 1183 (644,4736,635,4727) = true := by
  simp only [checkFour, w1183_0, w1183_1, w1183_2, w1183_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1183 : Coverage 1183 1184 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases1183)
theorem cover1152 : Coverage 1152 1184 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1152 one1153) (Coverage.join one1154 one1155)) (Coverage.join (Coverage.join one1156 one1157) (Coverage.join one1158 one1159))) (Coverage.join (Coverage.join (Coverage.join one1160 one1161) (Coverage.join one1162 one1163)) (Coverage.join (Coverage.join one1164 one1165) (Coverage.join one1166 one1167)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1168 one1169) (Coverage.join one1170 one1171)) (Coverage.join (Coverage.join one1172 one1173) (Coverage.join one1174 one1175))) (Coverage.join (Coverage.join (Coverage.join one1176 one1177) (Coverage.join one1178 one1179)) (Coverage.join (Coverage.join one1180 one1181) (Coverage.join one1182 one1183)))))
end NF180PA.Symbolic
