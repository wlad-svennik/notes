import NF179ClockGroup00
import NF179ClockGroup01
import NF179ClockGroup02
import NF179ClockGroup03
import NF179ClockGroup04
import NF179ClockGroup05
import NF179ClockGroup06
import NF179ClockGroup07
import NF179ClockGroup08
import NF179ClockGroup09
import NF179ClockGroup10
import NF179ClockGroup11

namespace NF180PA.Clock
open NF180PA.Symbolic
open Blank180.Data (addressBits)
theorem all_checked : ∀ p : Fin 2970, ∀ z : Bool, branchConflict p.val z = true :=
  fun p => (Covers.join (Covers.join (Covers.join group0 (Covers.join group256 group512)) (Covers.join group768 (Covers.join group1024 group1280))) (Covers.join (Covers.join group1536 (Covers.join group1792 group2048)) (Covers.join group2304 (Covers.join group2560 group2816)))) p.val (Nat.zero_le _) p.isLt
theorem live_conflict (p : Fin 2970) (z : Bool) (live : expectedHalt p.val z = false) :
    conflict (addressBits p.val) (addressBits (nextPc p.val z)) = true := by
  simpa [branchConflict,live] using all_checked p z

#print axioms all_checked
#print axioms live_conflict

end NF180PA.Clock
