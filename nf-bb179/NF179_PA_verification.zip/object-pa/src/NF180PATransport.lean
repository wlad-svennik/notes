import NF180PA
import NF181PA
import M6PA.Theory
open FFL FFL.FirstOrder FFL.Entailment
namespace NF180PA
theorem transport_nonhalting_implication (c : ArithmeticSentence)
    (h : M6.PA.theory ⊢ H180 🡘 NF181PA.H181)
    (old : M6.PA.theory ⊢ (∼NF181PA.H181) 🡒 c) :
    M6.PA.theory ⊢ (∼H180) 🡒 c :=
  C_trans (contra (C_of_E_mpr h)) old
end NF180PA
#print axioms NF180PA.transport_nonhalting_implication
