import NF179ClockBase
namespace NF180PA.Clock
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part2048 : Covers 2048 2064 := block_sound (lo:=2048) (n:=16) (by decide +kernel)
private theorem part2064 : Covers 2064 2080 := block_sound (lo:=2064) (n:=16) (by decide +kernel)
private theorem part2080 : Covers 2080 2096 := block_sound (lo:=2080) (n:=16) (by decide +kernel)
private theorem part2096 : Covers 2096 2112 := block_sound (lo:=2096) (n:=16) (by decide +kernel)
private theorem part2112 : Covers 2112 2128 := block_sound (lo:=2112) (n:=16) (by decide +kernel)
private theorem part2128 : Covers 2128 2144 := block_sound (lo:=2128) (n:=16) (by decide +kernel)
private theorem part2144 : Covers 2144 2160 := block_sound (lo:=2144) (n:=16) (by decide +kernel)
private theorem part2160 : Covers 2160 2176 := block_sound (lo:=2160) (n:=16) (by decide +kernel)
private theorem part2176 : Covers 2176 2192 := block_sound (lo:=2176) (n:=16) (by decide +kernel)
private theorem part2192 : Covers 2192 2208 := block_sound (lo:=2192) (n:=16) (by decide +kernel)
private theorem part2208 : Covers 2208 2224 := block_sound (lo:=2208) (n:=16) (by decide +kernel)
private theorem part2224 : Covers 2224 2240 := block_sound (lo:=2224) (n:=16) (by decide +kernel)
private theorem part2240 : Covers 2240 2256 := block_sound (lo:=2240) (n:=16) (by decide +kernel)
private theorem part2256 : Covers 2256 2272 := block_sound (lo:=2256) (n:=16) (by decide +kernel)
private theorem part2272 : Covers 2272 2288 := block_sound (lo:=2272) (n:=16) (by decide +kernel)
private theorem part2288 : Covers 2288 2304 := block_sound (lo:=2288) (n:=16) (by decide +kernel)
theorem group2048 : Covers 2048 2304 := (Covers.join (Covers.join (Covers.join (Covers.join part2048 part2064) (Covers.join part2080 part2096)) (Covers.join (Covers.join part2112 part2128) (Covers.join part2144 part2160))) (Covers.join (Covers.join (Covers.join part2176 part2192) (Covers.join part2208 part2224)) (Covers.join (Covers.join part2240 part2256) (Covers.join part2272 part2288))))
end NF180PA.Clock
