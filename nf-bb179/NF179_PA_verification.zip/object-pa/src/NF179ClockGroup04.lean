import NF179ClockBase
namespace NF180PA.Clock
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part1024 : Covers 1024 1040 := block_sound (lo:=1024) (n:=16) (by decide +kernel)
private theorem part1040 : Covers 1040 1056 := block_sound (lo:=1040) (n:=16) (by decide +kernel)
private theorem part1056 : Covers 1056 1072 := block_sound (lo:=1056) (n:=16) (by decide +kernel)
private theorem part1072 : Covers 1072 1088 := block_sound (lo:=1072) (n:=16) (by decide +kernel)
private theorem part1088 : Covers 1088 1104 := block_sound (lo:=1088) (n:=16) (by decide +kernel)
private theorem part1104 : Covers 1104 1120 := block_sound (lo:=1104) (n:=16) (by decide +kernel)
private theorem part1120 : Covers 1120 1136 := block_sound (lo:=1120) (n:=16) (by decide +kernel)
private theorem part1136 : Covers 1136 1152 := block_sound (lo:=1136) (n:=16) (by decide +kernel)
private theorem part1152 : Covers 1152 1168 := block_sound (lo:=1152) (n:=16) (by decide +kernel)
private theorem part1168 : Covers 1168 1184 := block_sound (lo:=1168) (n:=16) (by decide +kernel)
private theorem part1184 : Covers 1184 1200 := block_sound (lo:=1184) (n:=16) (by decide +kernel)
private theorem part1200 : Covers 1200 1216 := block_sound (lo:=1200) (n:=16) (by decide +kernel)
private theorem part1216 : Covers 1216 1232 := block_sound (lo:=1216) (n:=16) (by decide +kernel)
private theorem part1232 : Covers 1232 1248 := block_sound (lo:=1232) (n:=16) (by decide +kernel)
private theorem part1248 : Covers 1248 1264 := block_sound (lo:=1248) (n:=16) (by decide +kernel)
private theorem part1264 : Covers 1264 1280 := block_sound (lo:=1264) (n:=16) (by decide +kernel)
theorem group1024 : Covers 1024 1280 := (Covers.join (Covers.join (Covers.join (Covers.join part1024 part1040) (Covers.join part1056 part1072)) (Covers.join (Covers.join part1088 part1104) (Covers.join part1120 part1136))) (Covers.join (Covers.join (Covers.join part1152 part1168) (Covers.join part1184 part1200)) (Covers.join (Covers.join part1216 part1232) (Covers.join part1248 part1264))))
end NF180PA.Clock
