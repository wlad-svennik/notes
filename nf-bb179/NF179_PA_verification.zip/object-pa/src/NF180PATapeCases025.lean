import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w800_0 : checkWitness 800 false false 68 = true := by decide +kernel
private theorem w800_2 : checkWitness 800 true false 68 = true := by decide +kernel
private theorem cases800 : checkFour 800 (68,0,68,0) = true := by
  simp only [checkFour, w800_0, w800_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one800 : Coverage 800 801 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases800)
private theorem w801_0 : checkWitness 801 false false 550 = true := by decide +kernel
private theorem w801_1 : checkWitness 801 false true 4646 = true := by decide +kernel
private theorem w801_2 : checkWitness 801 true false 550 = true := by decide +kernel
private theorem w801_3 : checkWitness 801 true true 4646 = true := by decide +kernel
private theorem cases801 : checkFour 801 (550,4646,550,4646) = true := by
  simp only [checkFour, w801_0, w801_1, w801_2, w801_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one801 : Coverage 801 802 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases801)
private theorem w802_0 : checkWitness 802 false false 8901 = true := by decide +kernel
private theorem w802_2 : checkWitness 802 true false 8897 = true := by decide +kernel
private theorem cases802 : checkFour 802 (8901,0,8897,0) = true := by
  simp only [checkFour, w802_0, w802_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one802 : Coverage 802 803 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases802)
private theorem w803_0 : checkWitness 803 false false 8932 = true := by decide +kernel
private theorem w803_2 : checkWitness 803 true false 8923 = true := by decide +kernel
private theorem cases803 : checkFour 803 (8932,0,8923,0) = true := by
  simp only [checkFour, w803_0, w803_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one803 : Coverage 803 804 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases803)
private theorem w804_0 : checkWitness 804 false false 86 = true := by decide +kernel
private theorem w804_2 : checkWitness 804 true false 86 = true := by decide +kernel
private theorem cases804 : checkFour 804 (86,0,86,0) = true := by
  simp only [checkFour, w804_0, w804_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one804 : Coverage 804 805 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases804)
private theorem w805_0 : checkWitness 805 false false 646 = true := by decide +kernel
private theorem w805_1 : checkWitness 805 false true 4738 = true := by decide +kernel
private theorem w805_2 : checkWitness 805 true false 637 = true := by decide +kernel
private theorem w805_3 : checkWitness 805 true true 4729 = true := by decide +kernel
private theorem cases805 : checkFour 805 (646,4738,637,4729) = true := by
  simp only [checkFour, w805_0, w805_1, w805_2, w805_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one805 : Coverage 805 806 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases805)
private theorem w806_0 : checkWitness 806 false false 8897 = true := by decide +kernel
private theorem w806_2 : checkWitness 806 true false 8893 = true := by decide +kernel
private theorem cases806 : checkFour 806 (8897,0,8893,0) = true := by
  simp only [checkFour, w806_0, w806_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one806 : Coverage 806 807 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases806)
private theorem w807_0 : checkWitness 807 false false 640 = true := by decide +kernel
private theorem w807_1 : checkWitness 807 false true 4732 = true := by decide +kernel
private theorem w807_2 : checkWitness 807 true false 631 = true := by decide +kernel
private theorem w807_3 : checkWitness 807 true true 4723 = true := by decide +kernel
private theorem cases807 : checkFour 807 (640,4732,631,4723) = true := by
  simp only [checkFour, w807_0, w807_1, w807_2, w807_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one807 : Coverage 807 808 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases807)
private theorem w808_0 : checkWitness 808 false false 8868 = true := by decide +kernel
private theorem w808_2 : checkWitness 808 true false 8864 = true := by decide +kernel
private theorem cases808 : checkFour 808 (8868,0,8864,0) = true := by
  simp only [checkFour, w808_0, w808_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one808 : Coverage 808 809 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases808)
private theorem w809_0 : checkWitness 809 false false 74 = true := by decide +kernel
private theorem w809_2 : checkWitness 809 true false 74 = true := by decide +kernel
private theorem cases809 : checkFour 809 (74,0,74,0) = true := by
  simp only [checkFour, w809_0, w809_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one809 : Coverage 809 810 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases809)
private theorem w810_0 : checkWitness 810 false false 66 = true := by decide +kernel
private theorem w810_2 : checkWitness 810 true false 66 = true := by decide +kernel
private theorem cases810 : checkFour 810 (66,0,66,0) = true := by
  simp only [checkFour, w810_0, w810_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one810 : Coverage 810 811 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases810)
private theorem w811_0 : checkWitness 811 false false 601 = true := by decide +kernel
private theorem w811_1 : checkWitness 811 false true 4689 = true := by decide +kernel
private theorem w811_2 : checkWitness 811 true false 601 = true := by decide +kernel
private theorem w811_3 : checkWitness 811 true true 4689 = true := by decide +kernel
private theorem cases811 : checkFour 811 (601,4689,601,4689) = true := by
  simp only [checkFour, w811_0, w811_1, w811_2, w811_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one811 : Coverage 811 812 := checkList_sound (ws:=[(601,4689,601,4689)]) (by simpa only [checkList, Bool.and_true] using cases811)
private theorem w812_0 : checkWitness 812 false false 8884 = true := by decide +kernel
private theorem w812_2 : checkWitness 812 true false 8880 = true := by decide +kernel
private theorem cases812 : checkFour 812 (8884,0,8880,0) = true := by
  simp only [checkFour, w812_0, w812_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one812 : Coverage 812 813 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases812)
private theorem w813_0 : checkWitness 813 false false 8880 = true := by decide +kernel
private theorem w813_2 : checkWitness 813 true false 8876 = true := by decide +kernel
private theorem cases813 : checkFour 813 (8880,0,8876,0) = true := by
  simp only [checkFour, w813_0, w813_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one813 : Coverage 813 814 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases813)
private theorem w814_0 : checkWitness 814 false false 80 = true := by decide +kernel
private theorem w814_2 : checkWitness 814 true false 80 = true := by decide +kernel
private theorem cases814 : checkFour 814 (80,0,80,0) = true := by
  simp only [checkFour, w814_0, w814_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one814 : Coverage 814 815 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases814)
private theorem w815_0 : checkWitness 815 false false 8912 = true := by decide +kernel
private theorem w815_2 : checkWitness 815 true false 8908 = true := by decide +kernel
private theorem cases815 : checkFour 815 (8912,0,8908,0) = true := by
  simp only [checkFour, w815_0, w815_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one815 : Coverage 815 816 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases815)
private theorem w816_0 : checkWitness 816 false false 608 = true := by decide +kernel
private theorem w816_1 : checkWitness 816 false true 4704 = true := by decide +kernel
private theorem w816_2 : checkWitness 816 true false 608 = true := by decide +kernel
private theorem w816_3 : checkWitness 816 true true 4704 = true := by decide +kernel
private theorem cases816 : checkFour 816 (608,4704,608,4704) = true := by
  simp only [checkFour, w816_0, w816_1, w816_2, w816_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one816 : Coverage 816 817 := checkList_sound (ws:=[(608,4704,608,4704)]) (by simpa only [checkList, Bool.and_true] using cases816)
private theorem w817_0 : checkWitness 817 false false 8929 = true := by decide +kernel
private theorem w817_2 : checkWitness 817 true false 8925 = true := by decide +kernel
private theorem cases817 : checkFour 817 (8929,0,8925,0) = true := by
  simp only [checkFour, w817_0, w817_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one817 : Coverage 817 818 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases817)
private theorem w818_0 : checkWitness 818 false false 658 = true := by decide +kernel
private theorem w818_1 : checkWitness 818 false true 4754 = true := by decide +kernel
private theorem w818_2 : checkWitness 818 true false 649 = true := by decide +kernel
private theorem w818_3 : checkWitness 818 true true 4745 = true := by decide +kernel
private theorem cases818 : checkFour 818 (658,4754,649,4745) = true := by
  simp only [checkFour, w818_0, w818_1, w818_2, w818_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one818 : Coverage 818 819 := checkList_sound (ws:=[(658,4754,649,4745)]) (by simpa only [checkList, Bool.and_true] using cases818)
private theorem w819_0 : checkWitness 819 false false 196 = true := by decide +kernel
private theorem w819_2 : checkWitness 819 true false 196 = true := by decide +kernel
private theorem cases819 : checkFour 819 (196,0,196,0) = true := by
  simp only [checkFour, w819_0, w819_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one819 : Coverage 819 820 := checkList_sound (ws:=[(196,0,196,0)]) (by simpa only [checkList, Bool.and_true] using cases819)
private theorem w820_0 : checkWitness 820 false false 607 = true := by decide +kernel
private theorem w820_1 : checkWitness 820 false true 4695 = true := by decide +kernel
private theorem w820_2 : checkWitness 820 true false 607 = true := by decide +kernel
private theorem w820_3 : checkWitness 820 true true 4695 = true := by decide +kernel
private theorem cases820 : checkFour 820 (607,4695,607,4695) = true := by
  simp only [checkFour, w820_0, w820_1, w820_2, w820_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one820 : Coverage 820 821 := checkList_sound (ws:=[(607,4695,607,4695)]) (by simpa only [checkList, Bool.and_true] using cases820)
private theorem w821_0 : checkWitness 821 false false 8940 = true := by decide +kernel
private theorem w821_2 : checkWitness 821 true false 8931 = true := by decide +kernel
private theorem cases821 : checkFour 821 (8940,0,8931,0) = true := by
  simp only [checkFour, w821_0, w821_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one821 : Coverage 821 822 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases821)
private theorem w822_0 : checkWitness 822 false false 68 = true := by decide +kernel
private theorem w822_2 : checkWitness 822 true false 68 = true := by decide +kernel
private theorem cases822 : checkFour 822 (68,0,68,0) = true := by
  simp only [checkFour, w822_0, w822_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one822 : Coverage 822 823 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases822)
private theorem w823_0 : checkWitness 823 false false 60 = true := by decide +kernel
private theorem w823_2 : checkWitness 823 true false 60 = true := by decide +kernel
private theorem cases823 : checkFour 823 (60,0,60,0) = true := by
  simp only [checkFour, w823_0, w823_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one823 : Coverage 823 824 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases823)
private theorem w824_0 : checkWitness 824 false false 607 = true := by decide +kernel
private theorem w824_1 : checkWitness 824 false true 4699 = true := by decide +kernel
private theorem w824_2 : checkWitness 824 true false 607 = true := by decide +kernel
private theorem w824_3 : checkWitness 824 true true 4699 = true := by decide +kernel
private theorem cases824 : checkFour 824 (607,4699,607,4699) = true := by
  simp only [checkFour, w824_0, w824_1, w824_2, w824_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one824 : Coverage 824 825 := checkList_sound (ws:=[(607,4699,607,4699)]) (by simpa only [checkList, Bool.and_true] using cases824)
private theorem w825_0 : checkWitness 825 false false 8882 = true := by decide +kernel
private theorem w825_2 : checkWitness 825 true false 8878 = true := by decide +kernel
private theorem cases825 : checkFour 825 (8882,0,8878,0) = true := by
  simp only [checkFour, w825_0, w825_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one825 : Coverage 825 826 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases825)
private theorem w826_0 : checkWitness 826 false false 60 = true := by decide +kernel
private theorem w826_2 : checkWitness 826 true false 60 = true := by decide +kernel
private theorem cases826 : checkFour 826 (60,0,60,0) = true := by
  simp only [checkFour, w826_0, w826_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one826 : Coverage 826 827 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases826)
private theorem w827_0 : checkWitness 827 false false 566 = true := by decide +kernel
private theorem w827_1 : checkWitness 827 false true 4662 = true := by decide +kernel
private theorem w827_2 : checkWitness 827 true false 566 = true := by decide +kernel
private theorem w827_3 : checkWitness 827 true true 4662 = true := by decide +kernel
private theorem cases827 : checkFour 827 (566,4662,566,4662) = true := by
  simp only [checkFour, w827_0, w827_1, w827_2, w827_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one827 : Coverage 827 828 := checkList_sound (ws:=[(566,4662,566,4662)]) (by simpa only [checkList, Bool.and_true] using cases827)
private theorem w828_0 : checkWitness 828 false false 8917 = true := by decide +kernel
private theorem w828_2 : checkWitness 828 true false 8913 = true := by decide +kernel
private theorem cases828 : checkFour 828 (8917,0,8913,0) = true := by
  simp only [checkFour, w828_0, w828_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one828 : Coverage 828 829 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases828)
private theorem w829_0 : checkWitness 829 false false 8948 = true := by decide +kernel
private theorem w829_2 : checkWitness 829 true false 8939 = true := by decide +kernel
private theorem cases829 : checkFour 829 (8948,0,8939,0) = true := by
  simp only [checkFour, w829_0, w829_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one829 : Coverage 829 830 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases829)
private theorem w830_0 : checkWitness 830 false false 78 = true := by decide +kernel
private theorem w830_2 : checkWitness 830 true false 78 = true := by decide +kernel
private theorem cases830 : checkFour 830 (78,0,78,0) = true := by
  simp only [checkFour, w830_0, w830_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one830 : Coverage 830 831 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases830)
private theorem w831_0 : checkWitness 831 false false 662 = true := by decide +kernel
private theorem w831_1 : checkWitness 831 false true 4754 = true := by decide +kernel
private theorem w831_2 : checkWitness 831 true false 653 = true := by decide +kernel
private theorem w831_3 : checkWitness 831 true true 4745 = true := by decide +kernel
private theorem cases831 : checkFour 831 (662,4754,653,4745) = true := by
  simp only [checkFour, w831_0, w831_1, w831_2, w831_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one831 : Coverage 831 832 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases831)
theorem cover0800 : Coverage 800 832 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one800 one801) (Coverage.join one802 one803)) (Coverage.join (Coverage.join one804 one805) (Coverage.join one806 one807))) (Coverage.join (Coverage.join (Coverage.join one808 one809) (Coverage.join one810 one811)) (Coverage.join (Coverage.join one812 one813) (Coverage.join one814 one815)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one816 one817) (Coverage.join one818 one819)) (Coverage.join (Coverage.join one820 one821) (Coverage.join one822 one823))) (Coverage.join (Coverage.join (Coverage.join one824 one825) (Coverage.join one826 one827)) (Coverage.join (Coverage.join one828 one829) (Coverage.join one830 one831)))))
end NF180PA.Symbolic
