import NF179LinksBase
namespace NF180PA.Links
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part1536 : Covers 1536 1552 := block_sound (lo:=1536) (n:=16) (by decide +kernel)
private theorem part1552 : Covers 1552 1568 := block_sound (lo:=1552) (n:=16) (by decide +kernel)
private theorem part1568 : Covers 1568 1584 := block_sound (lo:=1568) (n:=16) (by decide +kernel)
private theorem part1584 : Covers 1584 1600 := block_sound (lo:=1584) (n:=16) (by decide +kernel)
private theorem part1600 : Covers 1600 1616 := block_sound (lo:=1600) (n:=16) (by decide +kernel)
private theorem part1616 : Covers 1616 1632 := block_sound (lo:=1616) (n:=16) (by decide +kernel)
private theorem part1632 : Covers 1632 1648 := block_sound (lo:=1632) (n:=16) (by decide +kernel)
private theorem part1648 : Covers 1648 1664 := block_sound (lo:=1648) (n:=16) (by decide +kernel)
private theorem part1664 : Covers 1664 1680 := block_sound (lo:=1664) (n:=16) (by decide +kernel)
private theorem part1680 : Covers 1680 1696 := block_sound (lo:=1680) (n:=16) (by decide +kernel)
private theorem part1696 : Covers 1696 1712 := block_sound (lo:=1696) (n:=16) (by decide +kernel)
private theorem part1712 : Covers 1712 1728 := block_sound (lo:=1712) (n:=16) (by decide +kernel)
private theorem part1728 : Covers 1728 1744 := block_sound (lo:=1728) (n:=16) (by decide +kernel)
private theorem part1744 : Covers 1744 1760 := block_sound (lo:=1744) (n:=16) (by decide +kernel)
private theorem part1760 : Covers 1760 1776 := block_sound (lo:=1760) (n:=16) (by decide +kernel)
private theorem part1776 : Covers 1776 1792 := block_sound (lo:=1776) (n:=16) (by decide +kernel)
theorem group1536 : Covers 1536 1792 := (Covers.join (Covers.join (Covers.join (Covers.join part1536 part1552) (Covers.join part1568 part1584)) (Covers.join (Covers.join part1600 part1616) (Covers.join part1632 part1648))) (Covers.join (Covers.join (Covers.join part1664 part1680) (Covers.join part1696 part1712)) (Covers.join (Covers.join part1728 part1744) (Covers.join part1760 part1776))))
end NF180PA.Links
