import NF181Raw
import SourceData
import LiteralRegisterProgram
open PA192.ModelSearch.RegisterSource (Instr)
namespace NF180PA.Shift
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def newInstruction (p : Nat) : Instr :=
  match Blank180.Data.program p with
  | .inl (r,n) => .inc r n
  | .inr (.inl (r,z,n,h)) => .dec r (if h then 4095 else z) n
  | .inr (.inr n) => .jump n

def oldInstruction (p : Nat) : Instr :=
  match Direct181Source.Raw.program p with
  | .inl (r,n) => .inc r n
  | .inr (.inl (r,z,n,h)) => .dec r (if h then 4095 else z) n
  | .inr (.inr n) => .jump n

def ext (p : Nat) : Bool := decide (p≤1 ∨ (10≤p ∧ p<2971) ∨ p=4095)
def mappedTarget (p : Nat) : Nat := if p≤1 ∨ p=4095 then p else p-1
def mapped : Instr → Instr
  | .inc r n => .inc r (mappedTarget n)
  | .dec r z n => .dec r (mappedTarget z) (mappedTarget n)
  | .jump n => .jump (mappedTarget n)
def allowed : Instr → Bool
  | .inc r n => decide (r≠0) && ext n
  | .dec r z n => (decide (r≠0) && ext z) && ext n
  | .jump n => ext n

def checkRow (p : Nat) (op : Instr) : Bool :=
  if p=1 ∨ 10≤p then allowed op && decide (newInstruction (mappedTarget p)=mapped op)
  else true

def validRow (p : Nat) : Bool := checkRow p (oldInstruction p)

private def convert (ins : NF192.Emitter.Instruction) : Instr :=
  match Direct181Source.Raw.asCommand ins with
  | .inl (r,n) => .inc r n
  | .inr (.inl (r,z,n,h)) => .dec r (if h then 4095 else z) n
  | .inr (.inr n) => .jump n

private def scan : Nat → List NF192.Emitter.Instruction → Bool
  | _, [] => true
  | n, op::rest => checkRow n (convert op) && scan (n+1) rest

private theorem scan_sound (xs : List NF192.Emitter.Instruction) (start i : Nat)
    (ok : scan start xs=true) (bound : i<xs.length) (fallback : NF192.Emitter.Instruction) :
    checkRow (start+i) (convert (xs.getD i fallback))=true := by
  induction xs generalizing start i with
  | nil => simp at bound
  | cons x xs ih =>
    obtain ⟨row,tail⟩ := Bool.and_eq_true_iff.mp ok
    cases i with
    | zero => simpa using row
    | succ i =>
      have ii : i<xs.length := by simpa using bound
      have h := ih (start+1) i tail ii
      simpa [List.getD, Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using h

open Direct181Source.Literal in
private theorem parts : scan 0 pre=true ∧ scan 40 mid=true ∧ scan 2849 post=true := by decide +kernel

open Direct181Source.Literal in
theorem each_exterior (p : Fin 2971) : validRow p.val=true := by
  change checkRow p.val (convert (Direct181Source.Literal.program p.val))=true
  have bound := p.isLt
  by_cases lo : p.val<40
  · have size : pre.length=40 := by decide +kernel
    have preok := scan_sound pre 0 p.val parts.1 (by simpa [size] using lo) .halt
    simpa [Direct181Source.Literal.program,lo] using preok
  by_cases middle : p.val<2849
  · have size : mid.length=2809 := by decide +kernel
    have midok := scan_sound mid 40 (p.val-40) parts.2.1 (by rw [size]; omega) .halt
    have eq : 40+(p.val-40)=p.val := by omega
    simpa only [Direct181Source.Literal.program,lo,ite_false,middle,ite_true,eq] using midok
  · have size : post.length=122 := by decide +kernel
    have postok := scan_sound post 2849 (p.val-2849) parts.2.2 (by rw [size]; omega) (.jump p.val)
    have eq : 2849+(p.val-2849)=p.val := by omega
    simpa only [Direct181Source.Literal.program,lo,ite_false,middle,eq] using postok

theorem all_exterior : (List.range 2971).all validRow = true :=
  List.all_eq_true.mpr fun i hi => each_exterior ⟨i,List.mem_range.mp hi⟩
end NF180PA.Shift
#print axioms NF180PA.Shift.all_exterior
