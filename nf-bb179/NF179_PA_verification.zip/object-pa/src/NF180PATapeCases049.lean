import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1568_0 : checkWitness 1568 false false 8886 = true := by decide +kernel
private theorem w1568_2 : checkWitness 1568 true false 8877 = true := by decide +kernel
private theorem cases1568 : checkFour 1568 (8886,0,8877,0) = true := by
  simp only [checkFour, w1568_0, w1568_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1568 : Coverage 1568 1569 := checkList_sound (ws:=[(8886,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases1568)
private theorem w1569_0 : checkWitness 1569 false false 90 = true := by decide +kernel
private theorem w1569_2 : checkWitness 1569 true false 90 = true := by decide +kernel
private theorem cases1569 : checkFour 1569 (90,0,90,0) = true := by
  simp only [checkFour, w1569_0, w1569_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1569 : Coverage 1569 1570 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1569)
private theorem w1570_0 : checkWitness 1570 false false 82 = true := by decide +kernel
private theorem w1570_2 : checkWitness 1570 true false 82 = true := by decide +kernel
private theorem cases1570 : checkFour 1570 (82,0,82,0) = true := by
  simp only [checkFour, w1570_0, w1570_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1570 : Coverage 1570 1571 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1570)
private theorem w1571_0 : checkWitness 1571 false false 553 = true := by decide +kernel
private theorem w1571_1 : checkWitness 1571 false true 4645 = true := by decide +kernel
private theorem w1571_2 : checkWitness 1571 true false 553 = true := by decide +kernel
private theorem w1571_3 : checkWitness 1571 true true 4645 = true := by decide +kernel
private theorem cases1571 : checkFour 1571 (553,4645,553,4645) = true := by
  simp only [checkFour, w1571_0, w1571_1, w1571_2, w1571_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1571 : Coverage 1571 1572 := checkList_sound (ws:=[(553,4645,553,4645)]) (by simpa only [checkList, Bool.and_true] using cases1571)
private theorem w1572_0 : checkWitness 1572 false false 8828 = true := by decide +kernel
private theorem w1572_2 : checkWitness 1572 true false 8824 = true := by decide +kernel
private theorem cases1572 : checkFour 1572 (8828,0,8824,0) = true := by
  simp only [checkFour, w1572_0, w1572_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1572 : Coverage 1572 1573 := checkList_sound (ws:=[(8828,0,8824,0)]) (by simpa only [checkList, Bool.and_true] using cases1572)
private theorem w1573_0 : checkWitness 1573 false false 82 = true := by decide +kernel
private theorem w1573_2 : checkWitness 1573 true false 82 = true := by decide +kernel
private theorem cases1573 : checkFour 1573 (82,0,82,0) = true := by
  simp only [checkFour, w1573_0, w1573_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1573 : Coverage 1573 1574 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1573)
private theorem w1574_0 : checkWitness 1574 false false 512 = true := by decide +kernel
private theorem w1574_1 : checkWitness 1574 false true 4608 = true := by decide +kernel
private theorem w1574_2 : checkWitness 1574 true false 512 = true := by decide +kernel
private theorem w1574_3 : checkWitness 1574 true true 4608 = true := by decide +kernel
private theorem cases1574 : checkFour 1574 (512,4608,512,4608) = true := by
  simp only [checkFour, w1574_0, w1574_1, w1574_2, w1574_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1574 : Coverage 1574 1575 := checkList_sound (ws:=[(512,4608,512,4608)]) (by simpa only [checkList, Bool.and_true] using cases1574)
private theorem w1575_0 : checkWitness 1575 false false 8863 = true := by decide +kernel
private theorem w1575_2 : checkWitness 1575 true false 8859 = true := by decide +kernel
private theorem cases1575 : checkFour 1575 (8863,0,8859,0) = true := by
  simp only [checkFour, w1575_0, w1575_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1575 : Coverage 1575 1576 := checkList_sound (ws:=[(8863,0,8859,0)]) (by simpa only [checkList, Bool.and_true] using cases1575)
private theorem w1576_0 : checkWitness 1576 false false 8894 = true := by decide +kernel
private theorem w1576_2 : checkWitness 1576 true false 8885 = true := by decide +kernel
private theorem cases1576 : checkFour 1576 (8894,0,8885,0) = true := by
  simp only [checkFour, w1576_0, w1576_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1576 : Coverage 1576 1577 := checkList_sound (ws:=[(8894,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1576)
private theorem w1577_0 : checkWitness 1577 false false 100 = true := by decide +kernel
private theorem w1577_2 : checkWitness 1577 true false 100 = true := by decide +kernel
private theorem cases1577 : checkFour 1577 (100,0,100,0) = true := by
  simp only [checkFour, w1577_0, w1577_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1577 : Coverage 1577 1578 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1577)
private theorem w1578_0 : checkWitness 1578 false false 608 = true := by decide +kernel
private theorem w1578_1 : checkWitness 1578 false true 4700 = true := by decide +kernel
private theorem w1578_2 : checkWitness 1578 true false 599 = true := by decide +kernel
private theorem w1578_3 : checkWitness 1578 true true 4691 = true := by decide +kernel
private theorem cases1578 : checkFour 1578 (608,4700,599,4691) = true := by
  simp only [checkFour, w1578_0, w1578_1, w1578_2, w1578_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1578 : Coverage 1578 1579 := checkList_sound (ws:=[(608,4700,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases1578)
private theorem w1579_0 : checkWitness 1579 false false 8859 = true := by decide +kernel
private theorem w1579_2 : checkWitness 1579 true false 8855 = true := by decide +kernel
private theorem cases1579 : checkFour 1579 (8859,0,8855,0) = true := by
  simp only [checkFour, w1579_0, w1579_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1579 : Coverage 1579 1580 := checkList_sound (ws:=[(8859,0,8855,0)]) (by simpa only [checkList, Bool.and_true] using cases1579)
private theorem w1580_0 : checkWitness 1580 false false 602 = true := by decide +kernel
private theorem w1580_1 : checkWitness 1580 false true 4694 = true := by decide +kernel
private theorem w1580_2 : checkWitness 1580 true false 593 = true := by decide +kernel
private theorem w1580_3 : checkWitness 1580 true true 4685 = true := by decide +kernel
private theorem cases1580 : checkFour 1580 (602,4694,593,4685) = true := by
  simp only [checkFour, w1580_0, w1580_1, w1580_2, w1580_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1580 : Coverage 1580 1581 := checkList_sound (ws:=[(602,4694,593,4685)]) (by simpa only [checkList, Bool.and_true] using cases1580)
private theorem w1581_0 : checkWitness 1581 false false 8830 = true := by decide +kernel
private theorem w1581_2 : checkWitness 1581 true false 8826 = true := by decide +kernel
private theorem cases1581 : checkFour 1581 (8830,0,8826,0) = true := by
  simp only [checkFour, w1581_0, w1581_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1581 : Coverage 1581 1582 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1581)
private theorem w1582_0 : checkWitness 1582 false false 88 = true := by decide +kernel
private theorem w1582_2 : checkWitness 1582 true false 88 = true := by decide +kernel
private theorem cases1582 : checkFour 1582 (88,0,88,0) = true := by
  simp only [checkFour, w1582_0, w1582_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1582 : Coverage 1582 1583 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1582)
private theorem w1583_0 : checkWitness 1583 false false 80 = true := by decide +kernel
private theorem w1583_2 : checkWitness 1583 true false 80 = true := by decide +kernel
private theorem cases1583 : checkFour 1583 (80,0,80,0) = true := by
  simp only [checkFour, w1583_0, w1583_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1583 : Coverage 1583 1584 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1583)
private theorem w1584_0 : checkWitness 1584 false false 579 = true := by decide +kernel
private theorem w1584_1 : checkWitness 1584 false true 4651 = true := by decide +kernel
private theorem w1584_2 : checkWitness 1584 true false 579 = true := by decide +kernel
private theorem w1584_3 : checkWitness 1584 true true 4651 = true := by decide +kernel
private theorem cases1584 : checkFour 1584 (579,4651,579,4651) = true := by
  simp only [checkFour, w1584_0, w1584_1, w1584_2, w1584_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1584 : Coverage 1584 1585 := checkList_sound (ws:=[(579,4651,579,4651)]) (by simpa only [checkList, Bool.and_true] using cases1584)
private theorem w1585_0 : checkWitness 1585 false false 8846 = true := by decide +kernel
private theorem w1585_2 : checkWitness 1585 true false 8842 = true := by decide +kernel
private theorem cases1585 : checkFour 1585 (8846,0,8842,0) = true := by
  simp only [checkFour, w1585_0, w1585_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1585 : Coverage 1585 1586 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1585)
private theorem w1586_0 : checkWitness 1586 false false 8842 = true := by decide +kernel
private theorem w1586_2 : checkWitness 1586 true false 8838 = true := by decide +kernel
private theorem cases1586 : checkFour 1586 (8842,0,8838,0) = true := by
  simp only [checkFour, w1586_0, w1586_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1586 : Coverage 1586 1587 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1586)
private theorem w1587_0 : checkWitness 1587 false false 94 = true := by decide +kernel
private theorem w1587_2 : checkWitness 1587 true false 94 = true := by decide +kernel
private theorem cases1587 : checkFour 1587 (94,0,94,0) = true := by
  simp only [checkFour, w1587_0, w1587_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1587 : Coverage 1587 1588 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1587)
private theorem w1588_0 : checkWitness 1588 false false 620 = true := by decide +kernel
private theorem w1588_1 : checkWitness 1588 false true 4716 = true := by decide +kernel
private theorem w1588_2 : checkWitness 1588 true false 620 = true := by decide +kernel
private theorem w1588_3 : checkWitness 1588 true true 4716 = true := by decide +kernel
private theorem cases1588 : checkFour 1588 (620,4716,620,4716) = true := by
  simp only [checkFour, w1588_0, w1588_1, w1588_2, w1588_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1588 : Coverage 1588 1589 := checkList_sound (ws:=[(620,4716,620,4716)]) (by simpa only [checkList, Bool.and_true] using cases1588)
private theorem w1589_0 : checkWitness 1589 false false 8898 = true := by decide +kernel
private theorem w1589_2 : checkWitness 1589 true false 8889 = true := by decide +kernel
private theorem cases1589 : checkFour 1589 (8898,0,8889,0) = true := by
  simp only [checkFour, w1589_0, w1589_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1589 : Coverage 1589 1590 := checkList_sound (ws:=[(8898,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1589)
private theorem w1590_0 : checkWitness 1590 false false 74 = true := by decide +kernel
private theorem w1590_2 : checkWitness 1590 true false 74 = true := by decide +kernel
private theorem cases1590 : checkFour 1590 (74,0,74,0) = true := by
  simp only [checkFour, w1590_0, w1590_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1590 : Coverage 1590 1591 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1590)
private theorem w1591_0 : checkWitness 1591 false false 476 = true := by decide +kernel
private theorem w1591_1 : checkWitness 1591 false true 4572 = true := by decide +kernel
private theorem w1591_2 : checkWitness 1591 true false 476 = true := by decide +kernel
private theorem w1591_3 : checkWitness 1591 true true 4572 = true := by decide +kernel
private theorem cases1591 : checkFour 1591 (476,4572,476,4572) = true := by
  simp only [checkFour, w1591_0, w1591_1, w1591_2, w1591_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1591 : Coverage 1591 1592 := checkList_sound (ws:=[(476,4572,476,4572)]) (by simpa only [checkList, Bool.and_true] using cases1591)
private theorem w1592_0 : checkWitness 1592 false false 8850 = true := by decide +kernel
private theorem w1592_2 : checkWitness 1592 true false 8846 = true := by decide +kernel
private theorem cases1592 : checkFour 1592 (8850,0,8846,0) = true := by
  simp only [checkFour, w1592_0, w1592_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1592 : Coverage 1592 1593 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases1592)
private theorem w1593_0 : checkWitness 1593 false false 78 = true := by decide +kernel
private theorem w1593_2 : checkWitness 1593 true false 78 = true := by decide +kernel
private theorem cases1593 : checkFour 1593 (78,0,78,0) = true := by
  simp only [checkFour, w1593_0, w1593_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1593 : Coverage 1593 1594 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1593)
private theorem w1594_0 : checkWitness 1594 false false 518 = true := by decide +kernel
private theorem w1594_1 : checkWitness 1594 false true 4614 = true := by decide +kernel
private theorem w1594_2 : checkWitness 1594 true false 518 = true := by decide +kernel
private theorem w1594_3 : checkWitness 1594 true true 4614 = true := by decide +kernel
private theorem cases1594 : checkFour 1594 (518,4614,518,4614) = true := by
  simp only [checkFour, w1594_0, w1594_1, w1594_2, w1594_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1594 : Coverage 1594 1595 := checkList_sound (ws:=[(518,4614,518,4614)]) (by simpa only [checkList, Bool.and_true] using cases1594)
private theorem w1595_0 : checkWitness 1595 false false 8869 = true := by decide +kernel
private theorem w1595_2 : checkWitness 1595 true false 8865 = true := by decide +kernel
private theorem cases1595 : checkFour 1595 (8869,0,8865,0) = true := by
  simp only [checkFour, w1595_0, w1595_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1595 : Coverage 1595 1596 := checkList_sound (ws:=[(8869,0,8865,0)]) (by simpa only [checkList, Bool.and_true] using cases1595)
private theorem w1596_0 : checkWitness 1596 false false 8900 = true := by decide +kernel
private theorem w1596_2 : checkWitness 1596 true false 8891 = true := by decide +kernel
private theorem cases1596 : checkFour 1596 (8900,0,8891,0) = true := by
  simp only [checkFour, w1596_0, w1596_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1596 : Coverage 1596 1597 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1596)
private theorem w1597_0 : checkWitness 1597 false false 102 = true := by decide +kernel
private theorem w1597_2 : checkWitness 1597 true false 102 = true := by decide +kernel
private theorem cases1597 : checkFour 1597 (102,0,102,0) = true := by
  simp only [checkFour, w1597_0, w1597_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1597 : Coverage 1597 1598 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1597)
private theorem w1598_0 : checkWitness 1598 false false 614 = true := by decide +kernel
private theorem w1598_1 : checkWitness 1598 false true 4706 = true := by decide +kernel
private theorem w1598_2 : checkWitness 1598 true false 605 = true := by decide +kernel
private theorem w1598_3 : checkWitness 1598 true true 4697 = true := by decide +kernel
private theorem cases1598 : checkFour 1598 (614,4706,605,4697) = true := by
  simp only [checkFour, w1598_0, w1598_1, w1598_2, w1598_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1598 : Coverage 1598 1599 := checkList_sound (ws:=[(614,4706,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases1598)
private theorem w1599_0 : checkWitness 1599 false false 8865 = true := by decide +kernel
private theorem w1599_2 : checkWitness 1599 true false 8861 = true := by decide +kernel
private theorem cases1599 : checkFour 1599 (8865,0,8861,0) = true := by
  simp only [checkFour, w1599_0, w1599_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1599 : Coverage 1599 1600 := checkList_sound (ws:=[(8865,0,8861,0)]) (by simpa only [checkList, Bool.and_true] using cases1599)
theorem cover1568 : Coverage 1568 1600 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1568 one1569) (Coverage.join one1570 one1571)) (Coverage.join (Coverage.join one1572 one1573) (Coverage.join one1574 one1575))) (Coverage.join (Coverage.join (Coverage.join one1576 one1577) (Coverage.join one1578 one1579)) (Coverage.join (Coverage.join one1580 one1581) (Coverage.join one1582 one1583)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1584 one1585) (Coverage.join one1586 one1587)) (Coverage.join (Coverage.join one1588 one1589) (Coverage.join one1590 one1591))) (Coverage.join (Coverage.join (Coverage.join one1592 one1593) (Coverage.join one1594 one1595)) (Coverage.join (Coverage.join one1596 one1597) (Coverage.join one1598 one1599)))))
end NF180PA.Symbolic
