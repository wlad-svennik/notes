import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2784_0 : checkWitness 2784 false false 8890 = true := by decide +kernel
private theorem w2784_2 : checkWitness 2784 true false 8886 = true := by decide +kernel
private theorem cases2784 : checkFour 2784 (8890,0,8886,0) = true := by
  simp only [checkFour, w2784_0, w2784_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2784 : Coverage 2784 2785 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases2784)
private theorem w2785_0 : checkWitness 2785 false false 68 = true := by decide +kernel
private theorem w2785_2 : checkWitness 2785 true false 68 = true := by decide +kernel
private theorem cases2785 : checkFour 2785 (68,0,68,0) = true := by
  simp only [checkFour, w2785_0, w2785_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2785 : Coverage 2785 2786 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2785)
private theorem w2786_0 : checkWitness 2786 false false 60 = true := by decide +kernel
private theorem w2786_2 : checkWitness 2786 true false 60 = true := by decide +kernel
private theorem cases2786 : checkFour 2786 (60,0,60,0) = true := by
  simp only [checkFour, w2786_0, w2786_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2786 : Coverage 2786 2787 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2786)
private theorem w2787_0 : checkWitness 2787 false false 615 = true := by decide +kernel
private theorem w2787_1 : checkWitness 2787 false true 4699 = true := by decide +kernel
private theorem w2787_2 : checkWitness 2787 true false 615 = true := by decide +kernel
private theorem w2787_3 : checkWitness 2787 true true 4699 = true := by decide +kernel
private theorem cases2787 : checkFour 2787 (615,4699,615,4699) = true := by
  simp only [checkFour, w2787_0, w2787_1, w2787_2, w2787_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2787 : Coverage 2787 2788 := checkList_sound (ws:=[(615,4699,615,4699)]) (by simpa only [checkList, Bool.and_true] using cases2787)
private theorem w2788_0 : checkWitness 2788 false false 8882 = true := by decide +kernel
private theorem w2788_2 : checkWitness 2788 true false 8878 = true := by decide +kernel
private theorem cases2788 : checkFour 2788 (8882,0,8878,0) = true := by
  simp only [checkFour, w2788_0, w2788_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2788 : Coverage 2788 2789 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases2788)
private theorem w2789_0 : checkWitness 2789 false false 60 = true := by decide +kernel
private theorem w2789_2 : checkWitness 2789 true false 60 = true := by decide +kernel
private theorem cases2789 : checkFour 2789 (60,0,60,0) = true := by
  simp only [checkFour, w2789_0, w2789_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2789 : Coverage 2789 2790 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2789)
private theorem w2790_0 : checkWitness 2790 false false 659 = true := by decide +kernel
private theorem w2790_1 : checkWitness 2790 false true 4751 = true := by decide +kernel
private theorem w2790_2 : checkWitness 2790 true false 650 = true := by decide +kernel
private theorem w2790_3 : checkWitness 2790 true true 4742 = true := by decide +kernel
private theorem cases2790 : checkFour 2790 (659,4751,650,4742) = true := by
  simp only [checkFour, w2790_0, w2790_1, w2790_2, w2790_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2790 : Coverage 2790 2791 := checkList_sound (ws:=[(659,4751,650,4742)]) (by simpa only [checkList, Bool.and_true] using cases2790)
private theorem w2791_0 : checkWitness 2791 false false 8956 = true := by decide +kernel
private theorem w2791_2 : checkWitness 2791 true false 8947 = true := by decide +kernel
private theorem cases2791 : checkFour 2791 (8956,0,8947,0) = true := by
  simp only [checkFour, w2791_0, w2791_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2791 : Coverage 2791 2792 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2791)
private theorem w2792_0 : checkWitness 2792 false false 8902 = true := by decide +kernel
private theorem w2792_2 : checkWitness 2792 true false 8898 = true := by decide +kernel
private theorem cases2792 : checkFour 2792 (8902,0,8898,0) = true := by
  simp only [checkFour, w2792_0, w2792_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2792 : Coverage 2792 2793 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases2792)
private theorem w2793_0 : checkWitness 2793 false false 64 = true := by decide +kernel
private theorem w2793_2 : checkWitness 2793 true false 64 = true := by decide +kernel
private theorem cases2793 : checkFour 2793 (64,0,64,0) = true := by
  simp only [checkFour, w2793_0, w2793_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2793 : Coverage 2793 2794 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2793)
private theorem w2794_0 : checkWitness 2794 false false 682 = true := by decide +kernel
private theorem w2794_1 : checkWitness 2794 false true 4774 = true := by decide +kernel
private theorem w2794_2 : checkWitness 2794 true false 673 = true := by decide +kernel
private theorem w2794_3 : checkWitness 2794 true true 4765 = true := by decide +kernel
private theorem cases2794 : checkFour 2794 (682,4774,673,4765) = true := by
  simp only [checkFour, w2794_0, w2794_1, w2794_2, w2794_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2794 : Coverage 2794 2795 := checkList_sound (ws:=[(682,4774,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases2794)
private theorem w2795_0 : checkWitness 2795 false false 8963 = true := by decide +kernel
private theorem w2795_2 : checkWitness 2795 true false 8954 = true := by decide +kernel
private theorem cases2795 : checkFour 2795 (8963,0,8954,0) = true := by
  simp only [checkFour, w2795_0, w2795_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2795 : Coverage 2795 2796 := checkList_sound (ws:=[(8963,0,8954,0)]) (by simpa only [checkList, Bool.and_true] using cases2795)
private theorem w2796_0 : checkWitness 2796 false false 48 = true := by decide +kernel
private theorem w2796_2 : checkWitness 2796 true false 48 = true := by decide +kernel
private theorem cases2796 : checkFour 2796 (48,0,48,0) = true := by
  simp only [checkFour, w2796_0, w2796_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2796 : Coverage 2796 2797 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2796)
private theorem w2797_0 : checkWitness 2797 false false 540 = true := by decide +kernel
private theorem w2797_1 : checkWitness 2797 false true 4636 = true := by decide +kernel
private theorem w2797_2 : checkWitness 2797 true false 540 = true := by decide +kernel
private theorem w2797_3 : checkWitness 2797 true true 4636 = true := by decide +kernel
private theorem cases2797 : checkFour 2797 (540,4636,540,4636) = true := by
  simp only [checkFour, w2797_0, w2797_1, w2797_2, w2797_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2797 : Coverage 2797 2798 := checkList_sound (ws:=[(540,4636,540,4636)]) (by simpa only [checkList, Bool.and_true] using cases2797)
private theorem w2798_0 : checkWitness 2798 false false 8943 = true := by decide +kernel
private theorem w2798_2 : checkWitness 2798 true false 8939 = true := by decide +kernel
private theorem cases2798 : checkFour 2798 (8943,0,8939,0) = true := by
  simp only [checkFour, w2798_0, w2798_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2798 : Coverage 2798 2799 := checkList_sound (ws:=[(8943,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2798)
private theorem w2799_0 : checkWitness 2799 false false 672 = true := by decide +kernel
private theorem w2799_1 : checkWitness 2799 false true 4768 = true := by decide +kernel
private theorem w2799_2 : checkWitness 2799 true false 663 = true := by decide +kernel
private theorem w2799_3 : checkWitness 2799 true true 4759 = true := by decide +kernel
private theorem cases2799 : checkFour 2799 (672,4768,663,4759) = true := by
  simp only [checkFour, w2799_0, w2799_1, w2799_2, w2799_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2799 : Coverage 2799 2800 := checkList_sound (ws:=[(672,4768,663,4759)]) (by simpa only [checkList, Bool.and_true] using cases2799)
private theorem w2800_0 : checkWitness 2800 false false 202 = true := by decide +kernel
private theorem w2800_2 : checkWitness 2800 true false 202 = true := by decide +kernel
private theorem cases2800 : checkFour 2800 (202,0,202,0) = true := by
  simp only [checkFour, w2800_0, w2800_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2800 : Coverage 2800 2801 := checkList_sound (ws:=[(202,0,202,0)]) (by simpa only [checkList, Bool.and_true] using cases2800)
private theorem w2801_0 : checkWitness 2801 false false 621 = true := by decide +kernel
private theorem w2801_1 : checkWitness 2801 false true 4709 = true := by decide +kernel
private theorem w2801_2 : checkWitness 2801 true false 621 = true := by decide +kernel
private theorem w2801_3 : checkWitness 2801 true true 4709 = true := by decide +kernel
private theorem cases2801 : checkFour 2801 (621,4709,621,4709) = true := by
  simp only [checkFour, w2801_0, w2801_1, w2801_2, w2801_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2801 : Coverage 2801 2802 := checkList_sound (ws:=[(621,4709,621,4709)]) (by simpa only [checkList, Bool.and_true] using cases2801)
private theorem w2802_0 : checkWitness 2802 false false 8954 = true := by decide +kernel
private theorem w2802_2 : checkWitness 2802 true false 8945 = true := by decide +kernel
private theorem cases2802 : checkFour 2802 (8954,0,8945,0) = true := by
  simp only [checkFour, w2802_0, w2802_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2802 : Coverage 2802 2803 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2802)
private theorem w2803_0 : checkWitness 2803 false false 66 = true := by decide +kernel
private theorem w2803_2 : checkWitness 2803 true false 66 = true := by decide +kernel
private theorem cases2803 : checkFour 2803 (66,0,66,0) = true := by
  simp only [checkFour, w2803_0, w2803_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2803 : Coverage 2803 2804 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2803)
private theorem w2804_0 : checkWitness 2804 false false 58 = true := by decide +kernel
private theorem w2804_2 : checkWitness 2804 true false 58 = true := by decide +kernel
private theorem cases2804 : checkFour 2804 (58,0,58,0) = true := by
  simp only [checkFour, w2804_0, w2804_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2804 : Coverage 2804 2805 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2804)
private theorem w2805_0 : checkWitness 2805 false false 621 = true := by decide +kernel
private theorem w2805_1 : checkWitness 2805 false true 4713 = true := by decide +kernel
private theorem w2805_2 : checkWitness 2805 true false 621 = true := by decide +kernel
private theorem w2805_3 : checkWitness 2805 true true 4713 = true := by decide +kernel
private theorem cases2805 : checkFour 2805 (621,4713,621,4713) = true := by
  simp only [checkFour, w2805_0, w2805_1, w2805_2, w2805_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2805 : Coverage 2805 2806 := checkList_sound (ws:=[(621,4713,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases2805)
private theorem w2806_0 : checkWitness 2806 false false 8896 = true := by decide +kernel
private theorem w2806_2 : checkWitness 2806 true false 8892 = true := by decide +kernel
private theorem cases2806 : checkFour 2806 (8896,0,8892,0) = true := by
  simp only [checkFour, w2806_0, w2806_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2806 : Coverage 2806 2807 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases2806)
private theorem w2807_0 : checkWitness 2807 false false 58 = true := by decide +kernel
private theorem w2807_2 : checkWitness 2807 true false 58 = true := by decide +kernel
private theorem cases2807 : checkFour 2807 (58,0,58,0) = true := by
  simp only [checkFour, w2807_0, w2807_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2807 : Coverage 2807 2808 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2807)
private theorem w2808_0 : checkWitness 2808 false false 580 = true := by decide +kernel
private theorem w2808_1 : checkWitness 2808 false true 4676 = true := by decide +kernel
private theorem w2808_2 : checkWitness 2808 true false 580 = true := by decide +kernel
private theorem w2808_3 : checkWitness 2808 true true 4676 = true := by decide +kernel
private theorem cases2808 : checkFour 2808 (580,4676,580,4676) = true := by
  simp only [checkFour, w2808_0, w2808_1, w2808_2, w2808_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2808 : Coverage 2808 2809 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases2808)
private theorem w2809_0 : checkWitness 2809 false false 8931 = true := by decide +kernel
private theorem w2809_2 : checkWitness 2809 true false 8927 = true := by decide +kernel
private theorem cases2809 : checkFour 2809 (8931,0,8927,0) = true := by
  simp only [checkFour, w2809_0, w2809_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2809 : Coverage 2809 2810 := checkList_sound (ws:=[(8931,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases2809)
private theorem w2810_0 : checkWitness 2810 false false 8962 = true := by decide +kernel
private theorem w2810_2 : checkWitness 2810 true false 8953 = true := by decide +kernel
private theorem cases2810 : checkFour 2810 (8962,0,8953,0) = true := by
  simp only [checkFour, w2810_0, w2810_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2810 : Coverage 2810 2811 := checkList_sound (ws:=[(8962,0,8953,0)]) (by simpa only [checkList, Bool.and_true] using cases2810)
private theorem w2811_0 : checkWitness 2811 false false 76 = true := by decide +kernel
private theorem w2811_2 : checkWitness 2811 true false 76 = true := by decide +kernel
private theorem cases2811 : checkFour 2811 (76,0,76,0) = true := by
  simp only [checkFour, w2811_0, w2811_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2811 : Coverage 2811 2812 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2811)
private theorem w2812_0 : checkWitness 2812 false false 676 = true := by decide +kernel
private theorem w2812_1 : checkWitness 2812 false true 4768 = true := by decide +kernel
private theorem w2812_2 : checkWitness 2812 true false 667 = true := by decide +kernel
private theorem w2812_3 : checkWitness 2812 true true 4759 = true := by decide +kernel
private theorem cases2812 : checkFour 2812 (676,4768,667,4759) = true := by
  simp only [checkFour, w2812_0, w2812_1, w2812_2, w2812_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2812 : Coverage 2812 2813 := checkList_sound (ws:=[(676,4768,667,4759)]) (by simpa only [checkList, Bool.and_true] using cases2812)
private theorem w2813_0 : checkWitness 2813 false false 8927 = true := by decide +kernel
private theorem w2813_2 : checkWitness 2813 true false 8923 = true := by decide +kernel
private theorem cases2813 : checkFour 2813 (8927,0,8923,0) = true := by
  simp only [checkFour, w2813_0, w2813_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2813 : Coverage 2813 2814 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases2813)
private theorem w2814_0 : checkWitness 2814 false false 670 = true := by decide +kernel
private theorem w2814_1 : checkWitness 2814 false true 4762 = true := by decide +kernel
private theorem w2814_2 : checkWitness 2814 true false 661 = true := by decide +kernel
private theorem w2814_3 : checkWitness 2814 true true 4753 = true := by decide +kernel
private theorem cases2814 : checkFour 2814 (670,4762,661,4753) = true := by
  simp only [checkFour, w2814_0, w2814_1, w2814_2, w2814_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2814 : Coverage 2814 2815 := checkList_sound (ws:=[(670,4762,661,4753)]) (by simpa only [checkList, Bool.and_true] using cases2814)
private theorem w2815_0 : checkWitness 2815 false false 8898 = true := by decide +kernel
private theorem w2815_2 : checkWitness 2815 true false 8894 = true := by decide +kernel
private theorem cases2815 : checkFour 2815 (8898,0,8894,0) = true := by
  simp only [checkFour, w2815_0, w2815_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2815 : Coverage 2815 2816 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2815)
theorem cover2784 : Coverage 2784 2816 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2784 one2785) (Coverage.join one2786 one2787)) (Coverage.join (Coverage.join one2788 one2789) (Coverage.join one2790 one2791))) (Coverage.join (Coverage.join (Coverage.join one2792 one2793) (Coverage.join one2794 one2795)) (Coverage.join (Coverage.join one2796 one2797) (Coverage.join one2798 one2799)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2800 one2801) (Coverage.join one2802 one2803)) (Coverage.join (Coverage.join one2804 one2805) (Coverage.join one2806 one2807))) (Coverage.join (Coverage.join (Coverage.join one2808 one2809) (Coverage.join one2810 one2811)) (Coverage.join (Coverage.join one2812 one2813) (Coverage.join one2814 one2815)))))
end NF180PA.Symbolic
