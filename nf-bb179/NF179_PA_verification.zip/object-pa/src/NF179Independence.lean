import NF179Replay
import NF180PAIndependence
import NF180PAModelSearchExact

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.BusyBeaver PA192.Literal

namespace NF179
theorem halts_iff_nf_refutation : NF210.TM.Halts machine start ↔ (𝗡𝗙 ⊢ ⊥) :=
  NFMachine180.halts_iff_nf_refutation

theorem model_refutation {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    (V ⊧/![] H179) ↔ NF181PA.Pool.Pr (∅ : V) goal :=
  NF180PA.model_refutation

theorem internal_consistency : M6.PA.theory ⊢ (∼H179) 🡒 M6.PA.consistencySentence :=
  NF180PA.internal_consistency

theorem pa_cannot_prove_nonhalting_of_consistent (h : M6.PA.Consistent) :
    M6.PA.theory ⊬ ∼H179 :=
  NF180PA.pa_cannot_prove_nonhalting_of_consistent h

theorem pa_independence (nf : FFL.Entailment.Consistent 𝗡𝗙) :
    (M6.PA.theory ⊬ ∼H179) ∧ (M6.PA.theory ⊬ H179) ∧
    ∀ k : Nat, (M6.PA.theory ⊬ upper 179 k) ∧
      (M6.PA.theory ⊬ fixedUpper (0 : Fin 179) k) ∧ (M6.PA.theory ⊬ value 179 k) :=
  NF180PA.pa_independence nf

theorem true_value_independent (nf : FFL.Entailment.Consistent 𝗡𝗙) :
    ∃ k : Nat, (Nat ⊧/![] (value 179 k)) ∧
      (M6.PA.theory ⊬ value 179 k) ∧ (M6.PA.theory ⊬ ∼(value 179 k)) :=
  NF180PA.true_value_independent nf
end NF179
#print axioms NF179.halts_iff_nf_refutation
#print axioms NF179.model_refutation
#print axioms NF179.internal_consistency
#print axioms NF179.pa_cannot_prove_nonhalting_of_consistent
#print axioms NF179.pa_independence
#print axioms NF179.true_value_independent
