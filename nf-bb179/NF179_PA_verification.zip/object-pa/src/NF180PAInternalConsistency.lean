import NF180UnifiedCore
import NF180PATapeAll
open FFL FFL.FirstOrder
namespace NF180PA
/-- First-order PA proves that the literal table's blank-tape nonhalting
implies the consistency of PA. Finite coverage is checked in the Lean kernel. -/
theorem internal_consistency :
    M6.PA.theory ⊢ (∼H180) 🡒 M6.PA.consistencySentence :=
  internal_consistency_of_coverage Symbolic.literal_table_coverage
end NF180PA
#print axioms NF180PA.internal_consistency
