import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w608_0 : checkWitness 608 false false 642 = true := by decide +kernel
private theorem w608_1 : checkWitness 608 false true 4738 = true := by decide +kernel
private theorem w608_2 : checkWitness 608 true false 642 = true := by decide +kernel
private theorem w608_3 : checkWitness 608 true true 4738 = true := by decide +kernel
private theorem cases608 : checkFour 608 (642,4738,642,4738) = true := by
  simp only [checkFour, w608_0, w608_1, w608_2, w608_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one608 : Coverage 608 609 := checkList_sound (ws:=[(642,4738,642,4738)]) (by simpa only [checkList, Bool.and_true] using cases608)
private theorem w609_0 : checkWitness 609 false false 8932 = true := by decide +kernel
private theorem w609_2 : checkWitness 609 true false 8923 = true := by decide +kernel
private theorem cases609 : checkFour 609 (8932,0,8923,0) = true := by
  simp only [checkFour, w609_0, w609_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one609 : Coverage 609 610 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases609)
private theorem w610_0 : checkWitness 610 false false 62 = true := by decide +kernel
private theorem w610_2 : checkWitness 610 true false 62 = true := by decide +kernel
private theorem cases610 : checkFour 610 (62,0,62,0) = true := by
  simp only [checkFour, w610_0, w610_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one610 : Coverage 610 611 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases610)
private theorem w611_0 : checkWitness 611 false false 510 = true := by decide +kernel
private theorem w611_1 : checkWitness 611 false true 4606 = true := by decide +kernel
private theorem w611_2 : checkWitness 611 true false 510 = true := by decide +kernel
private theorem w611_3 : checkWitness 611 true true 4606 = true := by decide +kernel
private theorem cases611 : checkFour 611 (510,4606,510,4606) = true := by
  simp only [checkFour, w611_0, w611_1, w611_2, w611_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one611 : Coverage 611 612 := checkList_sound (ws:=[(510,4606,510,4606)]) (by simpa only [checkList, Bool.and_true] using cases611)
private theorem w612_0 : checkWitness 612 false false 8884 = true := by decide +kernel
private theorem w612_2 : checkWitness 612 true false 8880 = true := by decide +kernel
private theorem cases612 : checkFour 612 (8884,0,8880,0) = true := by
  simp only [checkFour, w612_0, w612_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one612 : Coverage 612 613 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases612)
private theorem w613_0 : checkWitness 613 false false 66 = true := by decide +kernel
private theorem w613_2 : checkWitness 613 true false 66 = true := by decide +kernel
private theorem cases613 : checkFour 613 (66,0,66,0) = true := by
  simp only [checkFour, w613_0, w613_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one613 : Coverage 613 614 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases613)
private theorem w614_0 : checkWitness 614 false false 552 = true := by decide +kernel
private theorem w614_1 : checkWitness 614 false true 4648 = true := by decide +kernel
private theorem w614_2 : checkWitness 614 true false 552 = true := by decide +kernel
private theorem w614_3 : checkWitness 614 true true 4648 = true := by decide +kernel
private theorem cases614 : checkFour 614 (552,4648,552,4648) = true := by
  simp only [checkFour, w614_0, w614_1, w614_2, w614_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one614 : Coverage 614 615 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases614)
private theorem w615_0 : checkWitness 615 false false 8903 = true := by decide +kernel
private theorem w615_2 : checkWitness 615 true false 8899 = true := by decide +kernel
private theorem cases615 : checkFour 615 (8903,0,8899,0) = true := by
  simp only [checkFour, w615_0, w615_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one615 : Coverage 615 616 := checkList_sound (ws:=[(8903,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases615)
private theorem w616_0 : checkWitness 616 false false 8934 = true := by decide +kernel
private theorem w616_2 : checkWitness 616 true false 8925 = true := by decide +kernel
private theorem cases616 : checkFour 616 (8934,0,8925,0) = true := by
  simp only [checkFour, w616_0, w616_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one616 : Coverage 616 617 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases616)
private theorem w617_0 : checkWitness 617 false false 90 = true := by decide +kernel
private theorem w617_2 : checkWitness 617 true false 90 = true := by decide +kernel
private theorem cases617 : checkFour 617 (90,0,90,0) = true := by
  simp only [checkFour, w617_0, w617_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one617 : Coverage 617 618 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases617)
private theorem w618_0 : checkWitness 618 false false 648 = true := by decide +kernel
private theorem w618_1 : checkWitness 618 false true 4740 = true := by decide +kernel
private theorem w618_2 : checkWitness 618 true false 639 = true := by decide +kernel
private theorem w618_3 : checkWitness 618 true true 4731 = true := by decide +kernel
private theorem cases618 : checkFour 618 (648,4740,639,4731) = true := by
  simp only [checkFour, w618_0, w618_1, w618_2, w618_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one618 : Coverage 618 619 := checkList_sound (ws:=[(648,4740,639,4731)]) (by simpa only [checkList, Bool.and_true] using cases618)
private theorem w619_0 : checkWitness 619 false false 8899 = true := by decide +kernel
private theorem w619_2 : checkWitness 619 true false 8895 = true := by decide +kernel
private theorem cases619 : checkFour 619 (8899,0,8895,0) = true := by
  simp only [checkFour, w619_0, w619_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one619 : Coverage 619 620 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases619)
private theorem w620_0 : checkWitness 620 false false 642 = true := by decide +kernel
private theorem w620_1 : checkWitness 620 false true 4734 = true := by decide +kernel
private theorem w620_2 : checkWitness 620 true false 633 = true := by decide +kernel
private theorem w620_3 : checkWitness 620 true true 4725 = true := by decide +kernel
private theorem cases620 : checkFour 620 (642,4734,633,4725) = true := by
  simp only [checkFour, w620_0, w620_1, w620_2, w620_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one620 : Coverage 620 621 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases620)
private theorem w621_0 : checkWitness 621 false false 8870 = true := by decide +kernel
private theorem w621_2 : checkWitness 621 true false 8866 = true := by decide +kernel
private theorem cases621 : checkFour 621 (8870,0,8866,0) = true := by
  simp only [checkFour, w621_0, w621_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one621 : Coverage 621 622 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases621)
private theorem w622_0 : checkWitness 622 false false 78 = true := by decide +kernel
private theorem w622_2 : checkWitness 622 true false 78 = true := by decide +kernel
private theorem cases622 : checkFour 622 (78,0,78,0) = true := by
  simp only [checkFour, w622_0, w622_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one622 : Coverage 622 623 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases622)
private theorem w623_0 : checkWitness 623 false false 70 = true := by decide +kernel
private theorem w623_2 : checkWitness 623 true false 70 = true := by decide +kernel
private theorem cases623 : checkFour 623 (70,0,70,0) = true := by
  simp only [checkFour, w623_0, w623_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one623 : Coverage 623 624 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases623)
private theorem w624_0 : checkWitness 624 false false 595 = true := by decide +kernel
private theorem w624_1 : checkWitness 624 false true 4679 = true := by decide +kernel
private theorem w624_2 : checkWitness 624 true false 595 = true := by decide +kernel
private theorem w624_3 : checkWitness 624 true true 4679 = true := by decide +kernel
private theorem cases624 : checkFour 624 (595,4679,595,4679) = true := by
  simp only [checkFour, w624_0, w624_1, w624_2, w624_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one624 : Coverage 624 625 := checkList_sound (ws:=[(595,4679,595,4679)]) (by simpa only [checkList, Bool.and_true] using cases624)
private theorem w625_0 : checkWitness 625 false false 8862 = true := by decide +kernel
private theorem w625_2 : checkWitness 625 true false 8858 = true := by decide +kernel
private theorem cases625 : checkFour 625 (8862,0,8858,0) = true := by
  simp only [checkFour, w625_0, w625_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one625 : Coverage 625 626 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases625)
private theorem w626_0 : checkWitness 626 false false 70 = true := by decide +kernel
private theorem w626_2 : checkWitness 626 true false 70 = true := by decide +kernel
private theorem cases626 : checkFour 626 (70,0,70,0) = true := by
  simp only [checkFour, w626_0, w626_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one626 : Coverage 626 627 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases626)
private theorem w627_0 : checkWitness 627 false false 639 = true := by decide +kernel
private theorem w627_1 : checkWitness 627 false true 4731 = true := by decide +kernel
private theorem w627_2 : checkWitness 627 true false 630 = true := by decide +kernel
private theorem w627_3 : checkWitness 627 true true 4722 = true := by decide +kernel
private theorem cases627 : checkFour 627 (639,4731,630,4722) = true := by
  simp only [checkFour, w627_0, w627_1, w627_2, w627_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one627 : Coverage 627 628 := checkList_sound (ws:=[(639,4731,630,4722)]) (by simpa only [checkList, Bool.and_true] using cases627)
private theorem w628_0 : checkWitness 628 false false 8936 = true := by decide +kernel
private theorem w628_2 : checkWitness 628 true false 8927 = true := by decide +kernel
private theorem cases628 : checkFour 628 (8936,0,8927,0) = true := by
  simp only [checkFour, w628_0, w628_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one628 : Coverage 628 629 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases628)
private theorem w629_0 : checkWitness 629 false false 8882 = true := by decide +kernel
private theorem w629_2 : checkWitness 629 true false 8878 = true := by decide +kernel
private theorem cases629 : checkFour 629 (8882,0,8878,0) = true := by
  simp only [checkFour, w629_0, w629_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one629 : Coverage 629 630 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases629)
private theorem w630_0 : checkWitness 630 false false 74 = true := by decide +kernel
private theorem w630_2 : checkWitness 630 true false 74 = true := by decide +kernel
private theorem cases630 : checkFour 630 (74,0,74,0) = true := by
  simp only [checkFour, w630_0, w630_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one630 : Coverage 630 631 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases630)
private theorem w631_0 : checkWitness 631 false false 662 = true := by decide +kernel
private theorem w631_1 : checkWitness 631 false true 4754 = true := by decide +kernel
private theorem w631_2 : checkWitness 631 true false 653 = true := by decide +kernel
private theorem w631_3 : checkWitness 631 true true 4745 = true := by decide +kernel
private theorem cases631 : checkFour 631 (662,4754,653,4745) = true := by
  simp only [checkFour, w631_0, w631_1, w631_2, w631_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one631 : Coverage 631 632 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases631)
private theorem w632_0 : checkWitness 632 false false 8943 = true := by decide +kernel
private theorem w632_2 : checkWitness 632 true false 8934 = true := by decide +kernel
private theorem cases632 : checkFour 632 (8943,0,8934,0) = true := by
  simp only [checkFour, w632_0, w632_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one632 : Coverage 632 633 := checkList_sound (ws:=[(8943,0,8934,0)]) (by simpa only [checkList, Bool.and_true] using cases632)
private theorem w633_0 : checkWitness 633 false false 58 = true := by decide +kernel
private theorem w633_2 : checkWitness 633 true false 58 = true := by decide +kernel
private theorem cases633 : checkFour 633 (58,0,58,0) = true := by
  simp only [checkFour, w633_0, w633_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one633 : Coverage 633 634 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases633)
private theorem w634_0 : checkWitness 634 false false 520 = true := by decide +kernel
private theorem w634_1 : checkWitness 634 false true 4616 = true := by decide +kernel
private theorem w634_2 : checkWitness 634 true false 520 = true := by decide +kernel
private theorem w634_3 : checkWitness 634 true true 4616 = true := by decide +kernel
private theorem cases634 : checkFour 634 (520,4616,520,4616) = true := by
  simp only [checkFour, w634_0, w634_1, w634_2, w634_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one634 : Coverage 634 635 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases634)
private theorem w635_0 : checkWitness 635 false false 8923 = true := by decide +kernel
private theorem w635_2 : checkWitness 635 true false 8919 = true := by decide +kernel
private theorem cases635 : checkFour 635 (8923,0,8919,0) = true := by
  simp only [checkFour, w635_0, w635_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one635 : Coverage 635 636 := checkList_sound (ws:=[(8923,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases635)
private theorem w636_0 : checkWitness 636 false false 652 = true := by decide +kernel
private theorem w636_1 : checkWitness 636 false true 4748 = true := by decide +kernel
private theorem w636_2 : checkWitness 636 true false 643 = true := by decide +kernel
private theorem w636_3 : checkWitness 636 true true 4739 = true := by decide +kernel
private theorem cases636 : checkFour 636 (652,4748,643,4739) = true := by
  simp only [checkFour, w636_0, w636_1, w636_2, w636_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one636 : Coverage 636 637 := checkList_sound (ws:=[(652,4748,643,4739)]) (by simpa only [checkList, Bool.and_true] using cases636)
private theorem w637_0 : checkWitness 637 false false 192 = true := by decide +kernel
private theorem w637_2 : checkWitness 637 true false 192 = true := by decide +kernel
private theorem cases637 : checkFour 637 (192,0,192,0) = true := by
  simp only [checkFour, w637_0, w637_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one637 : Coverage 637 638 := checkList_sound (ws:=[(192,0,192,0)]) (by simpa only [checkList, Bool.and_true] using cases637)
private theorem w638_0 : checkWitness 638 false false 601 = true := by decide +kernel
private theorem w638_1 : checkWitness 638 false true 4689 = true := by decide +kernel
private theorem w638_2 : checkWitness 638 true false 601 = true := by decide +kernel
private theorem w638_3 : checkWitness 638 true true 4689 = true := by decide +kernel
private theorem cases638 : checkFour 638 (601,4689,601,4689) = true := by
  simp only [checkFour, w638_0, w638_1, w638_2, w638_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one638 : Coverage 638 639 := checkList_sound (ws:=[(601,4689,601,4689)]) (by simpa only [checkList, Bool.and_true] using cases638)
private theorem w639_0 : checkWitness 639 false false 8934 = true := by decide +kernel
private theorem w639_2 : checkWitness 639 true false 8925 = true := by decide +kernel
private theorem cases639 : checkFour 639 (8934,0,8925,0) = true := by
  simp only [checkFour, w639_0, w639_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one639 : Coverage 639 640 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases639)
theorem cover0608 : Coverage 608 640 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one608 one609) (Coverage.join one610 one611)) (Coverage.join (Coverage.join one612 one613) (Coverage.join one614 one615))) (Coverage.join (Coverage.join (Coverage.join one616 one617) (Coverage.join one618 one619)) (Coverage.join (Coverage.join one620 one621) (Coverage.join one622 one623)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one624 one625) (Coverage.join one626 one627)) (Coverage.join (Coverage.join one628 one629) (Coverage.join one630 one631))) (Coverage.join (Coverage.join (Coverage.join one632 one633) (Coverage.join one634 one635)) (Coverage.join (Coverage.join one636 one637) (Coverage.join one638 one639)))))
end NF180PA.Symbolic
