import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2336_0 : checkWitness 2336 false false 62 = true := by decide +kernel
private theorem w2336_2 : checkWitness 2336 true false 62 = true := by decide +kernel
private theorem cases2336 : checkFour 2336 (62,0,62,0) = true := by
  simp only [checkFour, w2336_0, w2336_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2336 : Coverage 2336 2337 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2336)
private theorem w2337_0 : checkWitness 2337 false false 593 = true := by decide +kernel
private theorem w2337_1 : checkWitness 2337 false true 4685 = true := by decide +kernel
private theorem w2337_2 : checkWitness 2337 true false 593 = true := by decide +kernel
private theorem w2337_3 : checkWitness 2337 true true 4685 = true := by decide +kernel
private theorem cases2337 : checkFour 2337 (593,4685,593,4685) = true := by
  simp only [checkFour, w2337_0, w2337_1, w2337_2, w2337_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2337 : Coverage 2337 2338 := checkList_sound (ws:=[(593,4685,593,4685)]) (by simpa only [checkList, Bool.and_true] using cases2337)
private theorem w2338_0 : checkWitness 2338 false false 8868 = true := by decide +kernel
private theorem w2338_2 : checkWitness 2338 true false 8864 = true := by decide +kernel
private theorem cases2338 : checkFour 2338 (8868,0,8864,0) = true := by
  simp only [checkFour, w2338_0, w2338_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2338 : Coverage 2338 2339 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases2338)
private theorem w2339_0 : checkWitness 2339 false false 62 = true := by decide +kernel
private theorem w2339_2 : checkWitness 2339 true false 62 = true := by decide +kernel
private theorem cases2339 : checkFour 2339 (62,0,62,0) = true := by
  simp only [checkFour, w2339_0, w2339_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2339 : Coverage 2339 2340 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2339)
private theorem w2340_0 : checkWitness 2340 false false 552 = true := by decide +kernel
private theorem w2340_1 : checkWitness 2340 false true 4648 = true := by decide +kernel
private theorem w2340_2 : checkWitness 2340 true false 552 = true := by decide +kernel
private theorem w2340_3 : checkWitness 2340 true true 4648 = true := by decide +kernel
private theorem cases2340 : checkFour 2340 (552,4648,552,4648) = true := by
  simp only [checkFour, w2340_0, w2340_1, w2340_2, w2340_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2340 : Coverage 2340 2341 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases2340)
private theorem w2341_0 : checkWitness 2341 false false 8903 = true := by decide +kernel
private theorem w2341_2 : checkWitness 2341 true false 8899 = true := by decide +kernel
private theorem cases2341 : checkFour 2341 (8903,0,8899,0) = true := by
  simp only [checkFour, w2341_0, w2341_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2341 : Coverage 2341 2342 := checkList_sound (ws:=[(8903,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases2341)
private theorem w2342_0 : checkWitness 2342 false false 8934 = true := by decide +kernel
private theorem w2342_2 : checkWitness 2342 true false 8925 = true := by decide +kernel
private theorem cases2342 : checkFour 2342 (8934,0,8925,0) = true := by
  simp only [checkFour, w2342_0, w2342_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2342 : Coverage 2342 2343 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases2342)
private theorem w2343_0 : checkWitness 2343 false false 80 = true := by decide +kernel
private theorem w2343_2 : checkWitness 2343 true false 80 = true := by decide +kernel
private theorem cases2343 : checkFour 2343 (80,0,80,0) = true := by
  simp only [checkFour, w2343_0, w2343_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2343 : Coverage 2343 2344 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2343)
private theorem w2344_0 : checkWitness 2344 false false 648 = true := by decide +kernel
private theorem w2344_1 : checkWitness 2344 false true 4740 = true := by decide +kernel
private theorem w2344_2 : checkWitness 2344 true false 639 = true := by decide +kernel
private theorem w2344_3 : checkWitness 2344 true true 4731 = true := by decide +kernel
private theorem cases2344 : checkFour 2344 (648,4740,639,4731) = true := by
  simp only [checkFour, w2344_0, w2344_1, w2344_2, w2344_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2344 : Coverage 2344 2345 := checkList_sound (ws:=[(648,4740,639,4731)]) (by simpa only [checkList, Bool.and_true] using cases2344)
private theorem w2345_0 : checkWitness 2345 false false 8899 = true := by decide +kernel
private theorem w2345_2 : checkWitness 2345 true false 8895 = true := by decide +kernel
private theorem cases2345 : checkFour 2345 (8899,0,8895,0) = true := by
  simp only [checkFour, w2345_0, w2345_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2345 : Coverage 2345 2346 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases2345)
private theorem w2346_0 : checkWitness 2346 false false 642 = true := by decide +kernel
private theorem w2346_1 : checkWitness 2346 false true 4734 = true := by decide +kernel
private theorem w2346_2 : checkWitness 2346 true false 633 = true := by decide +kernel
private theorem w2346_3 : checkWitness 2346 true true 4725 = true := by decide +kernel
private theorem cases2346 : checkFour 2346 (642,4734,633,4725) = true := by
  simp only [checkFour, w2346_0, w2346_1, w2346_2, w2346_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2346 : Coverage 2346 2347 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases2346)
private theorem w2347_0 : checkWitness 2347 false false 8870 = true := by decide +kernel
private theorem w2347_2 : checkWitness 2347 true false 8866 = true := by decide +kernel
private theorem cases2347 : checkFour 2347 (8870,0,8866,0) = true := by
  simp only [checkFour, w2347_0, w2347_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2347 : Coverage 2347 2348 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases2347)
private theorem w2348_0 : checkWitness 2348 false false 68 = true := by decide +kernel
private theorem w2348_2 : checkWitness 2348 true false 68 = true := by decide +kernel
private theorem cases2348 : checkFour 2348 (68,0,68,0) = true := by
  simp only [checkFour, w2348_0, w2348_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2348 : Coverage 2348 2349 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2348)
private theorem w2349_0 : checkWitness 2349 false false 60 = true := by decide +kernel
private theorem w2349_2 : checkWitness 2349 true false 60 = true := by decide +kernel
private theorem cases2349 : checkFour 2349 (60,0,60,0) = true := by
  simp only [checkFour, w2349_0, w2349_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2349 : Coverage 2349 2350 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2349)
private theorem w2350_0 : checkWitness 2350 false false 623 = true := by decide +kernel
private theorem w2350_1 : checkWitness 2350 false true 4691 = true := by decide +kernel
private theorem w2350_2 : checkWitness 2350 true false 623 = true := by decide +kernel
private theorem w2350_3 : checkWitness 2350 true true 4691 = true := by decide +kernel
private theorem cases2350 : checkFour 2350 (623,4691,623,4691) = true := by
  simp only [checkFour, w2350_0, w2350_1, w2350_2, w2350_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2350 : Coverage 2350 2351 := checkList_sound (ws:=[(623,4691,623,4691)]) (by simpa only [checkList, Bool.and_true] using cases2350)
private theorem w2351_0 : checkWitness 2351 false false 8886 = true := by decide +kernel
private theorem w2351_2 : checkWitness 2351 true false 8882 = true := by decide +kernel
private theorem cases2351 : checkFour 2351 (8886,0,8882,0) = true := by
  simp only [checkFour, w2351_0, w2351_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2351 : Coverage 2351 2352 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases2351)
private theorem w2352_0 : checkWitness 2352 false false 8882 = true := by decide +kernel
private theorem w2352_2 : checkWitness 2352 true false 8878 = true := by decide +kernel
private theorem cases2352 : checkFour 2352 (8882,0,8878,0) = true := by
  simp only [checkFour, w2352_0, w2352_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2352 : Coverage 2352 2353 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases2352)
private theorem w2353_0 : checkWitness 2353 false false 74 = true := by decide +kernel
private theorem w2353_2 : checkWitness 2353 true false 74 = true := by decide +kernel
private theorem cases2353 : checkFour 2353 (74,0,74,0) = true := by
  simp only [checkFour, w2353_0, w2353_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2353 : Coverage 2353 2354 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2353)
private theorem w2354_0 : checkWitness 2354 false false 682 = true := by decide +kernel
private theorem w2354_1 : checkWitness 2354 false true 4778 = true := by decide +kernel
private theorem w2354_2 : checkWitness 2354 true false 682 = true := by decide +kernel
private theorem w2354_3 : checkWitness 2354 true true 4778 = true := by decide +kernel
private theorem cases2354 : checkFour 2354 (682,4778,682,4778) = true := by
  simp only [checkFour, w2354_0, w2354_1, w2354_2, w2354_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2354 : Coverage 2354 2355 := checkList_sound (ws:=[(682,4778,682,4778)]) (by simpa only [checkList, Bool.and_true] using cases2354)
private theorem w2355_0 : checkWitness 2355 false false 8972 = true := by decide +kernel
private theorem w2355_2 : checkWitness 2355 true false 8963 = true := by decide +kernel
private theorem cases2355 : checkFour 2355 (8972,0,8963,0) = true := by
  simp only [checkFour, w2355_0, w2355_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2355 : Coverage 2355 2356 := checkList_sound (ws:=[(8972,0,8963,0)]) (by simpa only [checkList, Bool.and_true] using cases2355)
private theorem w2356_0 : checkWitness 2356 false false 62 = true := by decide +kernel
private theorem w2356_2 : checkWitness 2356 true false 62 = true := by decide +kernel
private theorem cases2356 : checkFour 2356 (62,0,62,0) = true := by
  simp only [checkFour, w2356_0, w2356_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2356 : Coverage 2356 2357 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2356)
private theorem w2357_0 : checkWitness 2357 false false 550 = true := by decide +kernel
private theorem w2357_1 : checkWitness 2357 false true 4646 = true := by decide +kernel
private theorem w2357_2 : checkWitness 2357 true false 550 = true := by decide +kernel
private theorem w2357_3 : checkWitness 2357 true true 4646 = true := by decide +kernel
private theorem cases2357 : checkFour 2357 (550,4646,550,4646) = true := by
  simp only [checkFour, w2357_0, w2357_1, w2357_2, w2357_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2357 : Coverage 2357 2358 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases2357)
private theorem w2358_0 : checkWitness 2358 false false 8924 = true := by decide +kernel
private theorem w2358_2 : checkWitness 2358 true false 8920 = true := by decide +kernel
private theorem cases2358 : checkFour 2358 (8924,0,8920,0) = true := by
  simp only [checkFour, w2358_0, w2358_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2358 : Coverage 2358 2359 := checkList_sound (ws:=[(8924,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases2358)
private theorem w2359_0 : checkWitness 2359 false false 66 = true := by decide +kernel
private theorem w2359_2 : checkWitness 2359 true false 66 = true := by decide +kernel
private theorem cases2359 : checkFour 2359 (66,0,66,0) = true := by
  simp only [checkFour, w2359_0, w2359_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2359 : Coverage 2359 2360 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2359)
private theorem w2360_0 : checkWitness 2360 false false 592 = true := by decide +kernel
private theorem w2360_1 : checkWitness 2360 false true 4688 = true := by decide +kernel
private theorem w2360_2 : checkWitness 2360 true false 592 = true := by decide +kernel
private theorem w2360_3 : checkWitness 2360 true true 4688 = true := by decide +kernel
private theorem cases2360 : checkFour 2360 (592,4688,592,4688) = true := by
  simp only [checkFour, w2360_0, w2360_1, w2360_2, w2360_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2360 : Coverage 2360 2361 := checkList_sound (ws:=[(592,4688,592,4688)]) (by simpa only [checkList, Bool.and_true] using cases2360)
private theorem w2361_0 : checkWitness 2361 false false 8943 = true := by decide +kernel
private theorem w2361_2 : checkWitness 2361 true false 8939 = true := by decide +kernel
private theorem cases2361 : checkFour 2361 (8943,0,8939,0) = true := by
  simp only [checkFour, w2361_0, w2361_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2361 : Coverage 2361 2362 := checkList_sound (ws:=[(8943,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2361)
private theorem w2362_0 : checkWitness 2362 false false 8974 = true := by decide +kernel
private theorem w2362_2 : checkWitness 2362 true false 8965 = true := by decide +kernel
private theorem cases2362 : checkFour 2362 (8974,0,8965,0) = true := by
  simp only [checkFour, w2362_0, w2362_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2362 : Coverage 2362 2363 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases2362)
private theorem w2363_0 : checkWitness 2363 false false 90 = true := by decide +kernel
private theorem w2363_2 : checkWitness 2363 true false 90 = true := by decide +kernel
private theorem cases2363 : checkFour 2363 (90,0,90,0) = true := by
  simp only [checkFour, w2363_0, w2363_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2363 : Coverage 2363 2364 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases2363)
private theorem w2364_0 : checkWitness 2364 false false 688 = true := by decide +kernel
private theorem w2364_1 : checkWitness 2364 false true 4780 = true := by decide +kernel
private theorem w2364_2 : checkWitness 2364 true false 679 = true := by decide +kernel
private theorem w2364_3 : checkWitness 2364 true true 4771 = true := by decide +kernel
private theorem cases2364 : checkFour 2364 (688,4780,679,4771) = true := by
  simp only [checkFour, w2364_0, w2364_1, w2364_2, w2364_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2364 : Coverage 2364 2365 := checkList_sound (ws:=[(688,4780,679,4771)]) (by simpa only [checkList, Bool.and_true] using cases2364)
private theorem w2365_0 : checkWitness 2365 false false 8939 = true := by decide +kernel
private theorem w2365_2 : checkWitness 2365 true false 8935 = true := by decide +kernel
private theorem cases2365 : checkFour 2365 (8939,0,8935,0) = true := by
  simp only [checkFour, w2365_0, w2365_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2365 : Coverage 2365 2366 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2365)
private theorem w2366_0 : checkWitness 2366 false false 682 = true := by decide +kernel
private theorem w2366_1 : checkWitness 2366 false true 4774 = true := by decide +kernel
private theorem w2366_2 : checkWitness 2366 true false 673 = true := by decide +kernel
private theorem w2366_3 : checkWitness 2366 true true 4765 = true := by decide +kernel
private theorem cases2366 : checkFour 2366 (682,4774,673,4765) = true := by
  simp only [checkFour, w2366_0, w2366_1, w2366_2, w2366_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2366 : Coverage 2366 2367 := checkList_sound (ws:=[(682,4774,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases2366)
private theorem w2367_0 : checkWitness 2367 false false 8910 = true := by decide +kernel
private theorem w2367_2 : checkWitness 2367 true false 8906 = true := by decide +kernel
private theorem cases2367 : checkFour 2367 (8910,0,8906,0) = true := by
  simp only [checkFour, w2367_0, w2367_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2367 : Coverage 2367 2368 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2367)
theorem cover2336 : Coverage 2336 2368 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2336 one2337) (Coverage.join one2338 one2339)) (Coverage.join (Coverage.join one2340 one2341) (Coverage.join one2342 one2343))) (Coverage.join (Coverage.join (Coverage.join one2344 one2345) (Coverage.join one2346 one2347)) (Coverage.join (Coverage.join one2348 one2349) (Coverage.join one2350 one2351)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2352 one2353) (Coverage.join one2354 one2355)) (Coverage.join (Coverage.join one2356 one2357) (Coverage.join one2358 one2359))) (Coverage.join (Coverage.join (Coverage.join one2360 one2361) (Coverage.join one2362 one2363)) (Coverage.join (Coverage.join one2364 one2365) (Coverage.join one2366 one2367)))))
end NF180PA.Symbolic
