import NF179Literal
import NF180PATapeReverse
import NF179Replay
import M6PA.Theory
import Foundation.FirstOrder.Arithmetic.Basic.Model

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.BusyBeaver
open PA192.ModelSearch.RegisterSource (address)

namespace NF179

/-- Any other PA sentence realizing exactly this register search is provably
equivalent to the literal 179-state trace sentence. -/
theorem equivalent_to_realization (new : NF180PA.Symbolic.Coverage 0 2970) (other : ArithmeticSentence)
    (cover : ∀ {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔],
      (V ⊧/![] other) ↔ ∃ j : V, address (NF180PA.Registers.run j) = 4095) :
    M6.PA.theory ⊢ H179 🡘 other := by
  apply E_intro
  · apply Arithmetic.complete.{0} M6.PA.theory _
    intro V _ _
    simp only [models_iff, LogicalConnective.HomClass.map_imply]
    exact ((NF180PA.Symbolic.tape_iff_source_of_coverage new).trans (cover (V:=V)).symm).mp
  · apply Arithmetic.complete.{0} M6.PA.theory _
    intro V _ _
    simp only [models_iff, LogicalConnective.HomClass.map_imply]
    exact ((NF180PA.Symbolic.tape_iff_source_of_coverage new).trans (cover (V:=V)).symm).mpr

theorem upper_bounds_of_realization (other : ArithmeticSentence)
    (equiv : M6.PA.theory ⊢ H179 🡘 other)
    (negative : M6.PA.theory ⊬ ∼other) (standard : ¬(Nat ⊧/![] other)) :
    (M6.PA.theory ⊬ ∼H179) ∧ (M6.PA.theory ⊬ H179) ∧
    ∀ k : Nat, M6.PA.theory ⊬ upper 179 k := by
  have toOther : M6.PA.theory ⊢ H179 🡒 other := C_of_E_mp equiv
  have sem := models_iff.mp (models_of_provable (M:=Nat) inferInstance toOther)
  simp only [LogicalConnective.HomClass.map_imply] at sem
  have live : ¬ Halts machine start := fun stop => standard (sem (H179_standard.mpr stop))
  have neg : M6.PA.theory ⊬ ∼H179 := fun p => negative (contra (C_of_E_mpr equiv) ⨀ p)
  have pos : M6.PA.theory ⊬ H179 :=
    fun p => standard (models_iff.mp (models_of_provable (M:=Nat) inferInstance (toOther ⨀ p)))
  have noUpper (k : Nat) : M6.PA.theory ⊬ upper 179 k := fun p =>
    neg (pa_bound_implies_nonhalting k (fun stop => live ⟨k, stop⟩) ⨀ p)
  exact ⟨neg,pos,noUpper⟩

end NF179
#print axioms NF179.equivalent_to_realization
#print axioms NF179.upper_bounds_of_realization
