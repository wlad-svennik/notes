import NF179ClockBase
namespace NF180PA.Clock
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part2560 : Covers 2560 2576 := block_sound (lo:=2560) (n:=16) (by decide +kernel)
private theorem part2576 : Covers 2576 2592 := block_sound (lo:=2576) (n:=16) (by decide +kernel)
private theorem part2592 : Covers 2592 2608 := block_sound (lo:=2592) (n:=16) (by decide +kernel)
private theorem part2608 : Covers 2608 2624 := block_sound (lo:=2608) (n:=16) (by decide +kernel)
private theorem part2624 : Covers 2624 2640 := block_sound (lo:=2624) (n:=16) (by decide +kernel)
private theorem part2640 : Covers 2640 2656 := block_sound (lo:=2640) (n:=16) (by decide +kernel)
private theorem part2656 : Covers 2656 2672 := block_sound (lo:=2656) (n:=16) (by decide +kernel)
private theorem part2672 : Covers 2672 2688 := block_sound (lo:=2672) (n:=16) (by decide +kernel)
private theorem part2688 : Covers 2688 2704 := block_sound (lo:=2688) (n:=16) (by decide +kernel)
private theorem part2704 : Covers 2704 2720 := block_sound (lo:=2704) (n:=16) (by decide +kernel)
private theorem part2720 : Covers 2720 2736 := block_sound (lo:=2720) (n:=16) (by decide +kernel)
private theorem part2736 : Covers 2736 2752 := block_sound (lo:=2736) (n:=16) (by decide +kernel)
private theorem part2752 : Covers 2752 2768 := block_sound (lo:=2752) (n:=16) (by decide +kernel)
private theorem part2768 : Covers 2768 2784 := block_sound (lo:=2768) (n:=16) (by decide +kernel)
private theorem part2784 : Covers 2784 2800 := block_sound (lo:=2784) (n:=16) (by decide +kernel)
private theorem part2800 : Covers 2800 2816 := block_sound (lo:=2800) (n:=16) (by decide +kernel)
theorem group2560 : Covers 2560 2816 := (Covers.join (Covers.join (Covers.join (Covers.join part2560 part2576) (Covers.join part2592 part2608)) (Covers.join (Covers.join part2624 part2640) (Covers.join part2656 part2672))) (Covers.join (Covers.join (Covers.join part2688 part2704) (Covers.join part2720 part2736)) (Covers.join (Covers.join part2752 part2768) (Covers.join part2784 part2800))))
end NF180PA.Clock
