import NF179ModelTransfer
import TrueValue
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open PA192.BusyBeaver
namespace NF179
/-- Transfer a calibrated sentence's negative unprovability and its standard
falsity to the numerical Busy Beaver upper bounds for this specific table. -/
theorem bounds_of_realization (other : ArithmeticSentence)
    (equiv : M6.PA.theory ⊢ H179 🡘 other)
    (negative : M6.PA.theory ⊬ ∼other) (standard : ¬(Nat ⊧/![] other)) :
    (M6.PA.theory ⊬ ∼H179) ∧ (M6.PA.theory ⊬ H179) ∧
    (∀ k : Nat, M6.PA.theory ⊬ upper 179 k) ∧
      ∃ k : Nat, (Nat ⊧/![] (value 179 k)) ∧
        (M6.PA.theory ⊬ value 179 k) ∧ (M6.PA.theory ⊬ ∼(value 179 k)) := by
  obtain ⟨neg,pos,noUpper⟩ := upper_bounds_of_realization other equiv negative standard
  obtain ⟨k,actual⟩ := exists_true_value 179
  exact ⟨neg,pos,noUpper,k,actual,no_value_of_no_upper (noUpper k),true_value_unrefutable actual⟩

end NF179
#print axioms NF179.equivalent_to_realization
#print axioms NF179.bounds_of_realization
