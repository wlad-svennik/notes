import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w128_0 : checkWitness 128 false false 8894 = true := by decide +kernel
private theorem w128_2 : checkWitness 128 true false 8890 = true := by decide +kernel
private theorem cases128 : checkFour 128 (8894,0,8890,0) = true := by
  simp only [checkFour, w128_0, w128_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one128 : Coverage 128 129 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases128)
private theorem w129_0 : checkWitness 129 false false 68 = true := by decide +kernel
private theorem w129_2 : checkWitness 129 true false 68 = true := by decide +kernel
private theorem cases129 : checkFour 129 (68,0,68,0) = true := by
  simp only [checkFour, w129_0, w129_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one129 : Coverage 129 130 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases129)
private theorem w130_0 : checkWitness 130 false false 617 = true := by decide +kernel
private theorem w130_1 : checkWitness 130 false true 4713 = true := by decide +kernel
private theorem w130_2 : checkWitness 130 true false 617 = true := by decide +kernel
private theorem w130_3 : checkWitness 130 true true 4713 = true := by decide +kernel
private theorem cases130 : checkFour 130 (617,4713,617,4713) = true := by
  simp only [checkFour, w130_0, w130_1, w130_2, w130_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one130 : Coverage 130 131 := checkList_sound (ws:=[(617,4713,617,4713)]) (by simpa only [checkList, Bool.and_true] using cases130)
private theorem w131_0 : checkWitness 131 false false 8911 = true := by decide +kernel
private theorem w131_2 : checkWitness 131 true false 8907 = true := by decide +kernel
private theorem cases131 : checkFour 131 (8911,0,8907,0) = true := by
  simp only [checkFour, w131_0, w131_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one131 : Coverage 131 132 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases131)
private theorem w132_0 : checkWitness 132 false false 640 = true := by decide +kernel
private theorem w132_1 : checkWitness 132 false true 4736 = true := by decide +kernel
private theorem w132_2 : checkWitness 132 true false 631 = true := by decide +kernel
private theorem w132_3 : checkWitness 132 true true 4727 = true := by decide +kernel
private theorem cases132 : checkFour 132 (640,4736,631,4727) = true := by
  simp only [checkFour, w132_0, w132_1, w132_2, w132_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one132 : Coverage 132 133 := checkList_sound (ws:=[(640,4736,631,4727)]) (by simpa only [checkList, Bool.and_true] using cases132)
private theorem w133_0 : checkWitness 133 false false 190 = true := by decide +kernel
private theorem w133_2 : checkWitness 133 true false 190 = true := by decide +kernel
private theorem cases133 : checkFour 133 (190,0,190,0) = true := by
  simp only [checkFour, w133_0, w133_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one133 : Coverage 133 134 := checkList_sound (ws:=[(190,0,190,0)]) (by simpa only [checkList, Bool.and_true] using cases133)
private theorem w134_0 : checkWitness 134 false false 589 = true := by decide +kernel
private theorem w134_1 : checkWitness 134 false true 4677 = true := by decide +kernel
private theorem w134_2 : checkWitness 134 true false 589 = true := by decide +kernel
private theorem w134_3 : checkWitness 134 true true 4677 = true := by decide +kernel
private theorem cases134 : checkFour 134 (589,4677,589,4677) = true := by
  simp only [checkFour, w134_0, w134_1, w134_2, w134_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one134 : Coverage 134 135 := checkList_sound (ws:=[(589,4677,589,4677)]) (by simpa only [checkList, Bool.and_true] using cases134)
private theorem w135_0 : checkWitness 135 false false 8922 = true := by decide +kernel
private theorem w135_2 : checkWitness 135 true false 8913 = true := by decide +kernel
private theorem cases135 : checkFour 135 (8922,0,8913,0) = true := by
  simp only [checkFour, w135_0, w135_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one135 : Coverage 135 136 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases135)
private theorem w136_0 : checkWitness 136 false false 62 = true := by decide +kernel
private theorem w136_2 : checkWitness 136 true false 62 = true := by decide +kernel
private theorem cases136 : checkFour 136 (62,0,62,0) = true := by
  simp only [checkFour, w136_0, w136_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one136 : Coverage 136 137 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases136)
private theorem w137_0 : checkWitness 137 false false 54 = true := by decide +kernel
private theorem w137_2 : checkWitness 137 true false 54 = true := by decide +kernel
private theorem cases137 : checkFour 137 (54,0,54,0) = true := by
  simp only [checkFour, w137_0, w137_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one137 : Coverage 137 138 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases137)
private theorem w138_0 : checkWitness 138 false false 601 = true := by decide +kernel
private theorem w138_1 : checkWitness 138 false true 4693 = true := by decide +kernel
private theorem w138_2 : checkWitness 138 true false 601 = true := by decide +kernel
private theorem w138_3 : checkWitness 138 true true 4693 = true := by decide +kernel
private theorem cases138 : checkFour 138 (601,4693,601,4693) = true := by
  simp only [checkFour, w138_0, w138_1, w138_2, w138_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one138 : Coverage 138 139 := checkList_sound (ws:=[(601,4693,601,4693)]) (by simpa only [checkList, Bool.and_true] using cases138)
private theorem w139_0 : checkWitness 139 false false 8889 = true := by decide +kernel
private theorem w139_2 : checkWitness 139 true false 8885 = true := by decide +kernel
private theorem cases139 : checkFour 139 (8889,0,8885,0) = true := by
  simp only [checkFour, w139_0, w139_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one139 : Coverage 139 140 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases139)
private theorem w140_0 : checkWitness 140 false false 54 = true := by decide +kernel
private theorem w140_2 : checkWitness 140 true false 54 = true := by decide +kernel
private theorem cases140 : checkFour 140 (54,0,54,0) = true := by
  simp only [checkFour, w140_0, w140_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one140 : Coverage 140 141 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases140)
private theorem w141_0 : checkWitness 141 false false 664 = true := by decide +kernel
private theorem w141_1 : checkWitness 141 false true 4756 = true := by decide +kernel
private theorem w141_2 : checkWitness 141 true false 655 = true := by decide +kernel
private theorem w141_3 : checkWitness 141 true true 4747 = true := by decide +kernel
private theorem cases141 : checkFour 141 (664,4756,655,4747) = true := by
  simp only [checkFour, w141_0, w141_1, w141_2, w141_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one141 : Coverage 141 142 := checkList_sound (ws:=[(664,4756,655,4747)]) (by simpa only [checkList, Bool.and_true] using cases141)
private theorem w142_0 : checkWitness 142 false false 8907 = true := by decide +kernel
private theorem w142_2 : checkWitness 142 true false 8903 = true := by decide +kernel
private theorem cases142 : checkFour 142 (8907,0,8903,0) = true := by
  simp only [checkFour, w142_0, w142_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one142 : Coverage 142 143 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases142)
private theorem w143_0 : checkWitness 143 false false 58 = true := by decide +kernel
private theorem w143_2 : checkWitness 143 true false 58 = true := by decide +kernel
private theorem cases143 : checkFour 143 (58,0,58,0) = true := by
  simp only [checkFour, w143_0, w143_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one143 : Coverage 143 144 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases143)
private theorem w144_0 : checkWitness 144 false false 652 = true := by decide +kernel
private theorem w144_1 : checkWitness 144 false true 4748 = true := by decide +kernel
private theorem w144_2 : checkWitness 144 true false 652 = true := by decide +kernel
private theorem w144_3 : checkWitness 144 true true 4748 = true := by decide +kernel
private theorem cases144 : checkFour 144 (652,4748,652,4748) = true := by
  simp only [checkFour, w144_0, w144_1, w144_2, w144_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one144 : Coverage 144 145 := checkList_sound (ws:=[(652,4748,652,4748)]) (by simpa only [checkList, Bool.and_true] using cases144)
private theorem w145_0 : checkWitness 145 false false 8942 = true := by decide +kernel
private theorem w145_2 : checkWitness 145 true false 8933 = true := by decide +kernel
private theorem cases145 : checkFour 145 (8942,0,8933,0) = true := by
  simp only [checkFour, w145_0, w145_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one145 : Coverage 145 146 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases145)
private theorem w146_0 : checkWitness 146 false false 62 = true := by decide +kernel
private theorem w146_2 : checkWitness 146 true false 62 = true := by decide +kernel
private theorem cases146 : checkFour 146 (62,0,62,0) = true := by
  simp only [checkFour, w146_0, w146_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one146 : Coverage 146 147 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases146)
private theorem w147_0 : checkWitness 147 false false 520 = true := by decide +kernel
private theorem w147_1 : checkWitness 147 false true 4616 = true := by decide +kernel
private theorem w147_2 : checkWitness 147 true false 520 = true := by decide +kernel
private theorem w147_3 : checkWitness 147 true true 4616 = true := by decide +kernel
private theorem cases147 : checkFour 147 (520,4616,520,4616) = true := by
  simp only [checkFour, w147_0, w147_1, w147_2, w147_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one147 : Coverage 147 148 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases147)
private theorem w148_0 : checkWitness 148 false false 8894 = true := by decide +kernel
private theorem w148_2 : checkWitness 148 true false 8890 = true := by decide +kernel
private theorem cases148 : checkFour 148 (8894,0,8890,0) = true := by
  simp only [checkFour, w148_0, w148_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one148 : Coverage 148 149 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases148)
private theorem w149_0 : checkWitness 149 false false 66 = true := by decide +kernel
private theorem w149_2 : checkWitness 149 true false 66 = true := by decide +kernel
private theorem cases149 : checkFour 149 (66,0,66,0) = true := by
  simp only [checkFour, w149_0, w149_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one149 : Coverage 149 150 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases149)
private theorem w150_0 : checkWitness 150 false false 562 = true := by decide +kernel
private theorem w150_1 : checkWitness 150 false true 4658 = true := by decide +kernel
private theorem w150_2 : checkWitness 150 true false 562 = true := by decide +kernel
private theorem w150_3 : checkWitness 150 true true 4658 = true := by decide +kernel
private theorem cases150 : checkFour 150 (562,4658,562,4658) = true := by
  simp only [checkFour, w150_0, w150_1, w150_2, w150_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one150 : Coverage 150 151 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases150)
private theorem w151_0 : checkWitness 151 false false 8913 = true := by decide +kernel
private theorem w151_2 : checkWitness 151 true false 8909 = true := by decide +kernel
private theorem cases151 : checkFour 151 (8913,0,8909,0) = true := by
  simp only [checkFour, w151_0, w151_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one151 : Coverage 151 152 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases151)
private theorem w152_0 : checkWitness 152 false false 8944 = true := by decide +kernel
private theorem w152_2 : checkWitness 152 true false 8935 = true := by decide +kernel
private theorem cases152 : checkFour 152 (8944,0,8935,0) = true := by
  simp only [checkFour, w152_0, w152_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one152 : Coverage 152 153 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases152)
private theorem w153_0 : checkWitness 153 false false 90 = true := by decide +kernel
private theorem w153_2 : checkWitness 153 true false 90 = true := by decide +kernel
private theorem cases153 : checkFour 153 (90,0,90,0) = true := by
  simp only [checkFour, w153_0, w153_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one153 : Coverage 153 154 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases153)
private theorem w154_0 : checkWitness 154 false false 658 = true := by decide +kernel
private theorem w154_1 : checkWitness 154 false true 4750 = true := by decide +kernel
private theorem w154_2 : checkWitness 154 true false 649 = true := by decide +kernel
private theorem w154_3 : checkWitness 154 true true 4741 = true := by decide +kernel
private theorem cases154 : checkFour 154 (658,4750,649,4741) = true := by
  simp only [checkFour, w154_0, w154_1, w154_2, w154_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one154 : Coverage 154 155 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases154)
private theorem w155_0 : checkWitness 155 false false 8909 = true := by decide +kernel
private theorem w155_2 : checkWitness 155 true false 8905 = true := by decide +kernel
private theorem cases155 : checkFour 155 (8909,0,8905,0) = true := by
  simp only [checkFour, w155_0, w155_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one155 : Coverage 155 156 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases155)
private theorem w156_0 : checkWitness 156 false false 652 = true := by decide +kernel
private theorem w156_1 : checkWitness 156 false true 4744 = true := by decide +kernel
private theorem w156_2 : checkWitness 156 true false 643 = true := by decide +kernel
private theorem w156_3 : checkWitness 156 true true 4735 = true := by decide +kernel
private theorem cases156 : checkFour 156 (652,4744,643,4735) = true := by
  simp only [checkFour, w156_0, w156_1, w156_2, w156_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one156 : Coverage 156 157 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases156)
private theorem w157_0 : checkWitness 157 false false 8880 = true := by decide +kernel
private theorem w157_2 : checkWitness 157 true false 8876 = true := by decide +kernel
private theorem cases157 : checkFour 157 (8880,0,8876,0) = true := by
  simp only [checkFour, w157_0, w157_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one157 : Coverage 157 158 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases157)
private theorem w158_0 : checkWitness 158 false false 78 = true := by decide +kernel
private theorem w158_2 : checkWitness 158 true false 78 = true := by decide +kernel
private theorem cases158 : checkFour 158 (78,0,78,0) = true := by
  simp only [checkFour, w158_0, w158_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one158 : Coverage 158 159 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases158)
private theorem w159_0 : checkWitness 159 false false 70 = true := by decide +kernel
private theorem w159_2 : checkWitness 159 true false 70 = true := by decide +kernel
private theorem cases159 : checkFour 159 (70,0,70,0) = true := by
  simp only [checkFour, w159_0, w159_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one159 : Coverage 159 160 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases159)
theorem cover0128 : Coverage 128 160 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one128 one129) (Coverage.join one130 one131)) (Coverage.join (Coverage.join one132 one133) (Coverage.join one134 one135))) (Coverage.join (Coverage.join (Coverage.join one136 one137) (Coverage.join one138 one139)) (Coverage.join (Coverage.join one140 one141) (Coverage.join one142 one143)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one144 one145) (Coverage.join one146 one147)) (Coverage.join (Coverage.join one148 one149) (Coverage.join one150 one151))) (Coverage.join (Coverage.join (Coverage.join one152 one153) (Coverage.join one154 one155)) (Coverage.join (Coverage.join one156 one157) (Coverage.join one158 one159)))))
end NF180PA.Symbolic
