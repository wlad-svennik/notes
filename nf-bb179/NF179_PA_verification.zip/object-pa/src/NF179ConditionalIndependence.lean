import NF179StandardConditional
import NF180UnifiedCore
import NF179Replay
import M6PA.Calibration.Foundation
import TrueValue
import ModelStartBound

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.BusyBeaver

namespace NF179
/-- The only machine-specific premise is a finite Boolean claim about this
179-state artifact. The 93 witness modules discharge it in the released proof. -/
theorem pa_independence_of_coverage
    (cover : NF180PA.Symbolic.Coverage 0 2970) (nf : Consistent 𝗡𝗙) :
    (M6.PA.theory ⊬ ∼H179) ∧ (M6.PA.theory ⊬ H179) ∧
    ∀ k : Nat, (M6.PA.theory ⊬ upper 179 k) ∧
      (M6.PA.theory ⊬ fixedUpper (0 : Fin 179) k) ∧ (M6.PA.theory ⊬ value 179 k) := by
  have nonhalt : ¬ Halts machine start := fun stop =>
    (consistent_iff_unprovable_bot.mp nf) ((halts_iff_nf_refutation_of_coverage cover).mp stop)
  have transfer : M6.PA.theory ⊢ (∼H179) 🡒 M6.PA.consistencySentence :=
    NF180PA.internal_consistency_of_coverage cover
  have neg : M6.PA.theory ⊬ ∼H179 :=
    M6.PA.unprovable_of_internal_consistency_implication _ inferInstance transfer
  refine ⟨neg, ?_, ?_⟩
  · intro proof
    exact nonhalt (H179_standard.mp (models_iff.mp
      (models_of_provable (M:=Nat) inferInstance proof)))
  · intro k
    have noUpper : M6.PA.theory ⊬ upper 179 k := fun proof =>
      neg (pa_bound_implies_nonhalting k (fun stop => nonhalt ⟨k,stop⟩) ⨀ proof)
    exact ⟨noUpper, fun proof =>
      noUpper (fixed_upper_implies_upper (0 : Fin 179) k ⨀ proof),
      no_value_of_no_upper noUpper⟩

theorem true_value_independent_of_coverage
    (cover : NF180PA.Symbolic.Coverage 0 2970) (nf : Consistent 𝗡𝗙) :
    ∃ k : Nat, (Nat ⊧/![] (value 179 k)) ∧
      (M6.PA.theory ⊬ value 179 k) ∧ (M6.PA.theory ⊬ ∼(value 179 k)) := by
  obtain ⟨k,actual⟩ := exists_true_value 179
  exact ⟨k,actual,((pa_independence_of_coverage cover nf).2.2 k).2.2,
    true_value_unrefutable actual⟩
end NF179
#print axioms NF179.pa_independence_of_coverage
#print axioms NF179.true_value_independent_of_coverage
