import NF180PATapeReverse
import NF180PASourceTransfer
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
namespace NF180PA
theorem model_refutation_of_coverage {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
    (cover : Symbolic.Coverage 0 2970) :
    (V ⊧/![] H180) ↔ NF181PA.Pool.Pr (∅ : V) goal :=
  (Symbolic.tape_iff_source_of_coverage cover).trans Shift.sourceHalt_iff_pool

end NF180PA
#print axioms NF180PA.model_refutation_of_coverage
