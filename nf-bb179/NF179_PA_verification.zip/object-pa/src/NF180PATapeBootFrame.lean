import NF180PATapeBoundary
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.PhysicalModel PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.RegisterSource (readReg registers address cold vector)
namespace NF180PA.Symbolic
open Execute (bit)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 2000000
set_option maxRecDepth 16000

private theorem file_equal (ks : List Nat) (flag : Bool) (r u : Nat→V) (tail : V)
    (eq : ∀ i ∈ ks, r i=u i) : file ks flag r tail=file ks flag u tail := by
  induction ks with
  | nil => rfl
  | cons k ks ih =>
    simp only [file,List.foldr_cons]
    have htail := ih (fun i hi => eq i (List.mem_cons_of_mem _ hi))
    change bit false (rep true (count flag r k) (file ks flag r tail))=
      bit false (rep true (count flag u k) (file ks flag u tail))
    simp only [htail,count,eq k (List.mem_cons_self ..)]

theorem canonical_equal (p : Nat) (flag : Bool) (r u : Nat→V) (g k : V)
    (eq : ∀ i < 9, r i=u i) : canonical p flag r g k=canonical p flag u g k := by
  unfold canonical
  rw [file_equal Blank180.Data.registerOrder flag r u _ (fun i hi => eq i ?_)]
  have h : ∀ i ∈ Blank180.Data.registerOrder, i<9 := by decide
  exact h i hi

private def natBit (b : Bool) (r : Nat) : Nat := 2*r+b.toNat
private theorem bit_cast (b : Bool) (r : Nat) : bit b (r:V)=(natBit b r:Nat) := by
  simp [bit,natBit]
private def litNat (bs : List Bool) (r : Nat) := bs.foldr natBit r
private theorem lit_cast (bs : List Bool) (r : Nat) : rayLit bs (r:V)=(litNat bs r:Nat) := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp only [rayLit,ih,bit_cast]; rfl

private def repNat (b : Bool) (k r : Nat) := (natBit b)^[k] r
private theorem rep_cast (b : Bool) (k r : Nat) : rep b (k:V) (r:V)=(repNat b k r:Nat) := by
  induction k with
  | zero => simp [rep,repNat]
  | succ k ih =>
    simp only [Nat.cast_succ,rep,iterate_succ]
    change bit b (rep b (k:V) (r:V))=(repNat b (k+1) r:Nat)
    rw [ih,bit_cast]; simp [repNat,Function.iterate_succ_apply']

private def pairNat (b : Bool) (k r : Nat) := (fun a => natBit b (natBit (!b) a))^[k] r
private theorem pair_cast (b : Bool) (k r : Nat) : pairs b (k:V) (r:V)=(pairNat b k r:Nat) := by
  induction k with
  | zero => simp [pairs,pairNat]
  | succ k ih =>
    simp only [Nat.cast_succ,pairs,iterate_succ]
    change bit b (bit (!b) (pairs b (k:V) (r:V)))=(pairNat b (k+1) r:Nat)
    rw [ih,bit_cast,bit_cast]; simp [pairNat,Function.iterate_succ_apply']

private def nCount (c : Bool) (r : Nat → Nat) (i : Nat) : Nat := if c && i==0 then 1 else r i + 2
private def nFile (ks : List Nat) (c : Bool) (r : Nat→Nat) (t : Nat) : Nat :=
  ks.foldr (fun i a => natBit false (repNat true (nCount c r i) a)) t
private theorem file_cast (ks : List Nat) (c : Bool) (r : Nat→Nat) (t : Nat) :
    file ks c (fun i => (r i:V)) (t:V)=(nFile ks c r t:Nat) := by
  induction ks with
  | nil => rfl
  | cons i ks ih =>
    have hc : count c (fun j => (r j:V)) i = (nCount c r i:Nat) := by
      unfold count nCount; split <;> simp
    change bit false (rep true _ (file ks c (fun j => (r j:V)) (t:V)))=_
    rw [ih,hc,rep_cast,bit_cast]; rfl

private def bootRegs (i : Nat) : Nat := if i=0 then 5 else 0
theorem boot_frame : packedFrame 0 false (registers (Registers.margin V)) 46 54 = pack 12 1 (Gate.bootRight : V) := by
  have eq : ∀ i < 9, readReg i (registers (Registers.margin V))=(bootRegs i:V) := by
    intro i hi
    have limits : i=0 ∨ i=1 ∨ i=2 ∨ i=3 ∨ i=4 ∨ i=5 ∨ i=6 ∨ i=7 ∨ i=8 := by omega
    rcases limits with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> simp [Registers.margin,vector,readReg,bootRegs]
  change canonical 0 false _ 46 54=_
  rw [canonical_equal 0 false _ (fun i => (bootRegs i:V)) 46 54 eq]
  unfold canonical
  let addr := Blank180.Data.addressBits 0
  have g : (((41-addr.length:Nat):V)+46+10) = ((41-addr.length+46+10:Nat):V) := by simp
  have k : (24+54:V) = ((78:Nat):V) := by norm_num
  change pack 12 1 (rayLit addr (rep false (((41-addr.length:Nat):V)+46+10)
    (bit true (file _ false (fun i => (bootRegs i:V)) (pairs false (24+54) 0)))))=_
  rw [g,k,show (0:V)=((0:Nat):V) by simp,pair_cast,file_cast,bit_cast,rep_cast,lit_cast]
  apply congrArg (pack (12:V) 1)
  apply congrArg (fun n : Nat => (n:V))
  decide +kernel

theorem boot_boundary : Boundary (Registers.margin V) (rawRun Gate.machine Gate.start (230892:V)) := by
  apply Or.inr
  apply (anyFrame_iff _ _ _).mpr
  refine ⟨0,List.mem_range.mpr (by decide),false,rfl,?_,?_,?_,46,54,?_⟩
  · simp [Registers.margin]
  · simp [Registers.margin]
  · simp [Registers.margin,vector,readReg]
  · rw [Gate.model_boot,boot_frame]
#print axioms boot_boundary
end NF180PA.Symbolic
