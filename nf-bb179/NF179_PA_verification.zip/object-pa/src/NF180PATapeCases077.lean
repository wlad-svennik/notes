import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2464_0 : checkWitness 2464 false false 8943 = true := by decide +kernel
private theorem w2464_2 : checkWitness 2464 true false 8939 = true := by decide +kernel
private theorem cases2464 : checkFour 2464 (8943,0,8939,0) = true := by
  simp only [checkFour, w2464_0, w2464_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2464 : Coverage 2464 2465 := checkList_sound (ws:=[(8943,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2464)
private theorem w2465_0 : checkWitness 2465 false false 8974 = true := by decide +kernel
private theorem w2465_2 : checkWitness 2465 true false 8965 = true := by decide +kernel
private theorem cases2465 : checkFour 2465 (8974,0,8965,0) = true := by
  simp only [checkFour, w2465_0, w2465_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2465 : Coverage 2465 2466 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases2465)
private theorem w2466_0 : checkWitness 2466 false false 80 = true := by decide +kernel
private theorem w2466_2 : checkWitness 2466 true false 80 = true := by decide +kernel
private theorem cases2466 : checkFour 2466 (80,0,80,0) = true := by
  simp only [checkFour, w2466_0, w2466_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2466 : Coverage 2466 2467 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2466)
private theorem w2467_0 : checkWitness 2467 false false 688 = true := by decide +kernel
private theorem w2467_1 : checkWitness 2467 false true 4780 = true := by decide +kernel
private theorem w2467_2 : checkWitness 2467 true false 679 = true := by decide +kernel
private theorem w2467_3 : checkWitness 2467 true true 4771 = true := by decide +kernel
private theorem cases2467 : checkFour 2467 (688,4780,679,4771) = true := by
  simp only [checkFour, w2467_0, w2467_1, w2467_2, w2467_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2467 : Coverage 2467 2468 := checkList_sound (ws:=[(688,4780,679,4771)]) (by simpa only [checkList, Bool.and_true] using cases2467)
private theorem w2468_0 : checkWitness 2468 false false 8939 = true := by decide +kernel
private theorem w2468_2 : checkWitness 2468 true false 8935 = true := by decide +kernel
private theorem cases2468 : checkFour 2468 (8939,0,8935,0) = true := by
  simp only [checkFour, w2468_0, w2468_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2468 : Coverage 2468 2469 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2468)
private theorem w2469_0 : checkWitness 2469 false false 682 = true := by decide +kernel
private theorem w2469_1 : checkWitness 2469 false true 4774 = true := by decide +kernel
private theorem w2469_2 : checkWitness 2469 true false 673 = true := by decide +kernel
private theorem w2469_3 : checkWitness 2469 true true 4765 = true := by decide +kernel
private theorem cases2469 : checkFour 2469 (682,4774,673,4765) = true := by
  simp only [checkFour, w2469_0, w2469_1, w2469_2, w2469_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2469 : Coverage 2469 2470 := checkList_sound (ws:=[(682,4774,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases2469)
private theorem w2470_0 : checkWitness 2470 false false 8910 = true := by decide +kernel
private theorem w2470_2 : checkWitness 2470 true false 8906 = true := by decide +kernel
private theorem cases2470 : checkFour 2470 (8910,0,8906,0) = true := by
  simp only [checkFour, w2470_0, w2470_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2470 : Coverage 2470 2471 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2470)
private theorem w2471_0 : checkWitness 2471 false false 68 = true := by decide +kernel
private theorem w2471_2 : checkWitness 2471 true false 68 = true := by decide +kernel
private theorem cases2471 : checkFour 2471 (68,0,68,0) = true := by
  simp only [checkFour, w2471_0, w2471_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2471 : Coverage 2471 2472 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2471)
private theorem w2472_0 : checkWitness 2472 false false 60 = true := by decide +kernel
private theorem w2472_2 : checkWitness 2472 true false 60 = true := by decide +kernel
private theorem cases2472 : checkFour 2472 (60,0,60,0) = true := by
  simp only [checkFour, w2472_0, w2472_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2472 : Coverage 2472 2473 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2472)
private theorem w2473_0 : checkWitness 2473 false false 635 = true := by decide +kernel
private theorem w2473_1 : checkWitness 2473 false true 4719 = true := by decide +kernel
private theorem w2473_2 : checkWitness 2473 true false 635 = true := by decide +kernel
private theorem w2473_3 : checkWitness 2473 true true 4719 = true := by decide +kernel
private theorem cases2473 : checkFour 2473 (635,4719,635,4719) = true := by
  simp only [checkFour, w2473_0, w2473_1, w2473_2, w2473_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2473 : Coverage 2473 2474 := checkList_sound (ws:=[(635,4719,635,4719)]) (by simpa only [checkList, Bool.and_true] using cases2473)
private theorem w2474_0 : checkWitness 2474 false false 8902 = true := by decide +kernel
private theorem w2474_2 : checkWitness 2474 true false 8898 = true := by decide +kernel
private theorem cases2474 : checkFour 2474 (8902,0,8898,0) = true := by
  simp only [checkFour, w2474_0, w2474_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2474 : Coverage 2474 2475 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases2474)
private theorem w2475_0 : checkWitness 2475 false false 60 = true := by decide +kernel
private theorem w2475_2 : checkWitness 2475 true false 60 = true := by decide +kernel
private theorem cases2475 : checkFour 2475 (60,0,60,0) = true := by
  simp only [checkFour, w2475_0, w2475_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2475 : Coverage 2475 2476 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2475)
private theorem w2476_0 : checkWitness 2476 false false 679 = true := by decide +kernel
private theorem w2476_1 : checkWitness 2476 false true 4771 = true := by decide +kernel
private theorem w2476_2 : checkWitness 2476 true false 670 = true := by decide +kernel
private theorem w2476_3 : checkWitness 2476 true true 4762 = true := by decide +kernel
private theorem cases2476 : checkFour 2476 (679,4771,670,4762) = true := by
  simp only [checkFour, w2476_0, w2476_1, w2476_2, w2476_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2476 : Coverage 2476 2477 := checkList_sound (ws:=[(679,4771,670,4762)]) (by simpa only [checkList, Bool.and_true] using cases2476)
private theorem w2477_0 : checkWitness 2477 false false 8976 = true := by decide +kernel
private theorem w2477_2 : checkWitness 2477 true false 8967 = true := by decide +kernel
private theorem cases2477 : checkFour 2477 (8976,0,8967,0) = true := by
  simp only [checkFour, w2477_0, w2477_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2477 : Coverage 2477 2478 := checkList_sound (ws:=[(8976,0,8967,0)]) (by simpa only [checkList, Bool.and_true] using cases2477)
private theorem w2478_0 : checkWitness 2478 false false 8922 = true := by decide +kernel
private theorem w2478_2 : checkWitness 2478 true false 8918 = true := by decide +kernel
private theorem cases2478 : checkFour 2478 (8922,0,8918,0) = true := by
  simp only [checkFour, w2478_0, w2478_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2478 : Coverage 2478 2479 := checkList_sound (ws:=[(8922,0,8918,0)]) (by simpa only [checkList, Bool.and_true] using cases2478)
private theorem w2479_0 : checkWitness 2479 false false 64 = true := by decide +kernel
private theorem w2479_2 : checkWitness 2479 true false 64 = true := by decide +kernel
private theorem cases2479 : checkFour 2479 (64,0,64,0) = true := by
  simp only [checkFour, w2479_0, w2479_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2479 : Coverage 2479 2480 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2479)
private theorem w2480_0 : checkWitness 2480 false false 702 = true := by decide +kernel
private theorem w2480_1 : checkWitness 2480 false true 4794 = true := by decide +kernel
private theorem w2480_2 : checkWitness 2480 true false 693 = true := by decide +kernel
private theorem w2480_3 : checkWitness 2480 true true 4785 = true := by decide +kernel
private theorem cases2480 : checkFour 2480 (702,4794,693,4785) = true := by
  simp only [checkFour, w2480_0, w2480_1, w2480_2, w2480_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2480 : Coverage 2480 2481 := checkList_sound (ws:=[(702,4794,693,4785)]) (by simpa only [checkList, Bool.and_true] using cases2480)
private theorem w2481_0 : checkWitness 2481 false false 8983 = true := by decide +kernel
private theorem w2481_2 : checkWitness 2481 true false 8974 = true := by decide +kernel
private theorem cases2481 : checkFour 2481 (8983,0,8974,0) = true := by
  simp only [checkFour, w2481_0, w2481_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2481 : Coverage 2481 2482 := checkList_sound (ws:=[(8983,0,8974,0)]) (by simpa only [checkList, Bool.and_true] using cases2481)
private theorem w2482_0 : checkWitness 2482 false false 48 = true := by decide +kernel
private theorem w2482_2 : checkWitness 2482 true false 48 = true := by decide +kernel
private theorem cases2482 : checkFour 2482 (48,0,48,0) = true := by
  simp only [checkFour, w2482_0, w2482_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2482 : Coverage 2482 2483 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2482)
private theorem w2483_0 : checkWitness 2483 false false 678 = true := by decide +kernel
private theorem w2483_1 : checkWitness 2483 false true 4774 = true := by decide +kernel
private theorem w2483_2 : checkWitness 2483 true false 678 = true := by decide +kernel
private theorem w2483_3 : checkWitness 2483 true true 4774 = true := by decide +kernel
private theorem cases2483 : checkFour 2483 (678,4774,678,4774) = true := by
  simp only [checkFour, w2483_0, w2483_1, w2483_2, w2483_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2483 : Coverage 2483 2484 := checkList_sound (ws:=[(678,4774,678,4774)]) (by simpa only [checkList, Bool.and_true] using cases2483)
private theorem w2484_0 : checkWitness 2484 false false 8974 = true := by decide +kernel
private theorem w2484_2 : checkWitness 2484 true false 8965 = true := by decide +kernel
private theorem cases2484 : checkFour 2484 (8974,0,8965,0) = true := by
  simp only [checkFour, w2484_0, w2484_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2484 : Coverage 2484 2485 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases2484)
private theorem w2485_0 : checkWitness 2485 false false 56 = true := by decide +kernel
private theorem w2485_2 : checkWitness 2485 true false 56 = true := by decide +kernel
private theorem cases2485 : checkFour 2485 (56,0,56,0) = true := by
  simp only [checkFour, w2485_0, w2485_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2485 : Coverage 2485 2486 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2485)
private theorem w2486_0 : checkWitness 2486 false false 552 = true := by decide +kernel
private theorem w2486_1 : checkWitness 2486 false true 4648 = true := by decide +kernel
private theorem w2486_2 : checkWitness 2486 true false 552 = true := by decide +kernel
private theorem w2486_3 : checkWitness 2486 true true 4648 = true := by decide +kernel
private theorem cases2486 : checkFour 2486 (552,4648,552,4648) = true := by
  simp only [checkFour, w2486_0, w2486_1, w2486_2, w2486_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2486 : Coverage 2486 2487 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases2486)
private theorem w2487_0 : checkWitness 2487 false false 8926 = true := by decide +kernel
private theorem w2487_2 : checkWitness 2487 true false 8922 = true := by decide +kernel
private theorem cases2487 : checkFour 2487 (8926,0,8922,0) = true := by
  simp only [checkFour, w2487_0, w2487_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2487 : Coverage 2487 2488 := checkList_sound (ws:=[(8926,0,8922,0)]) (by simpa only [checkList, Bool.and_true] using cases2487)
private theorem w2488_0 : checkWitness 2488 false false 60 = true := by decide +kernel
private theorem w2488_2 : checkWitness 2488 true false 60 = true := by decide +kernel
private theorem cases2488 : checkFour 2488 (60,0,60,0) = true := by
  simp only [checkFour, w2488_0, w2488_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2488 : Coverage 2488 2489 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2488)
private theorem w2489_0 : checkWitness 2489 false false 594 = true := by decide +kernel
private theorem w2489_1 : checkWitness 2489 false true 4690 = true := by decide +kernel
private theorem w2489_2 : checkWitness 2489 true false 594 = true := by decide +kernel
private theorem w2489_3 : checkWitness 2489 true true 4690 = true := by decide +kernel
private theorem cases2489 : checkFour 2489 (594,4690,594,4690) = true := by
  simp only [checkFour, w2489_0, w2489_1, w2489_2, w2489_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2489 : Coverage 2489 2490 := checkList_sound (ws:=[(594,4690,594,4690)]) (by simpa only [checkList, Bool.and_true] using cases2489)
private theorem w2490_0 : checkWitness 2490 false false 8945 = true := by decide +kernel
private theorem w2490_2 : checkWitness 2490 true false 8941 = true := by decide +kernel
private theorem cases2490 : checkFour 2490 (8945,0,8941,0) = true := by
  simp only [checkFour, w2490_0, w2490_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2490 : Coverage 2490 2491 := checkList_sound (ws:=[(8945,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2490)
private theorem w2491_0 : checkWitness 2491 false false 8976 = true := by decide +kernel
private theorem w2491_2 : checkWitness 2491 true false 8967 = true := by decide +kernel
private theorem cases2491 : checkFour 2491 (8976,0,8967,0) = true := by
  simp only [checkFour, w2491_0, w2491_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2491 : Coverage 2491 2492 := checkList_sound (ws:=[(8976,0,8967,0)]) (by simpa only [checkList, Bool.and_true] using cases2491)
private theorem w2492_0 : checkWitness 2492 false false 84 = true := by decide +kernel
private theorem w2492_2 : checkWitness 2492 true false 84 = true := by decide +kernel
private theorem cases2492 : checkFour 2492 (84,0,84,0) = true := by
  simp only [checkFour, w2492_0, w2492_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2492 : Coverage 2492 2493 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2492)
private theorem w2493_0 : checkWitness 2493 false false 690 = true := by decide +kernel
private theorem w2493_1 : checkWitness 2493 false true 4782 = true := by decide +kernel
private theorem w2493_2 : checkWitness 2493 true false 681 = true := by decide +kernel
private theorem w2493_3 : checkWitness 2493 true true 4773 = true := by decide +kernel
private theorem cases2493 : checkFour 2493 (690,4782,681,4773) = true := by
  simp only [checkFour, w2493_0, w2493_1, w2493_2, w2493_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2493 : Coverage 2493 2494 := checkList_sound (ws:=[(690,4782,681,4773)]) (by simpa only [checkList, Bool.and_true] using cases2493)
private theorem w2494_0 : checkWitness 2494 false false 8941 = true := by decide +kernel
private theorem w2494_2 : checkWitness 2494 true false 8937 = true := by decide +kernel
private theorem cases2494 : checkFour 2494 (8941,0,8937,0) = true := by
  simp only [checkFour, w2494_0, w2494_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2494 : Coverage 2494 2495 := checkList_sound (ws:=[(8941,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases2494)
private theorem w2495_0 : checkWitness 2495 false false 684 = true := by decide +kernel
private theorem w2495_1 : checkWitness 2495 false true 4776 = true := by decide +kernel
private theorem w2495_2 : checkWitness 2495 true false 675 = true := by decide +kernel
private theorem w2495_3 : checkWitness 2495 true true 4767 = true := by decide +kernel
private theorem cases2495 : checkFour 2495 (684,4776,675,4767) = true := by
  simp only [checkFour, w2495_0, w2495_1, w2495_2, w2495_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2495 : Coverage 2495 2496 := checkList_sound (ws:=[(684,4776,675,4767)]) (by simpa only [checkList, Bool.and_true] using cases2495)
theorem cover2464 : Coverage 2464 2496 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2464 one2465) (Coverage.join one2466 one2467)) (Coverage.join (Coverage.join one2468 one2469) (Coverage.join one2470 one2471))) (Coverage.join (Coverage.join (Coverage.join one2472 one2473) (Coverage.join one2474 one2475)) (Coverage.join (Coverage.join one2476 one2477) (Coverage.join one2478 one2479)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2480 one2481) (Coverage.join one2482 one2483)) (Coverage.join (Coverage.join one2484 one2485) (Coverage.join one2486 one2487))) (Coverage.join (Coverage.join (Coverage.join one2488 one2489) (Coverage.join one2490 one2491)) (Coverage.join (Coverage.join one2492 one2493) (Coverage.join one2494 one2495)))))
end NF180PA.Symbolic
