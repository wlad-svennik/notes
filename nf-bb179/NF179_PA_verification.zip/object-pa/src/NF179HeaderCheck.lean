import Blank180Table
set_option maxRecDepth 30000
set_option maxHeartbeats 0
namespace NF179.HeaderCheck
open Blank180.Table
theorem start_name : name start = "k:74" := rfl
theorem header_exact : "#! start " ++ name start ++ "\n" = "#! start k:74\n" := by rw [start_name]; rfl
#print axioms header_exact
end NF179.HeaderCheck
