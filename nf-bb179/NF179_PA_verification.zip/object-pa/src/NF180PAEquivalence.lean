import NF180PAEquivalenceCore
import NF180PATapeAll
import NF181PATapeAll
open FFL FFL.FirstOrder
namespace NF180PA
theorem halting_equivalence : M6.PA.theory ⊢ H180 🡘 NF181PA.H181 :=
  halting_equivalence_of_coverage Symbolic.literal_table_coverage NF181PA.Symbolic.literal_table_coverage
end NF180PA
#print axioms NF180PA.halting_equivalence
