import Mathlib.Tactic.NormNum
import Mathlib.Algebra.Order.Sub.Basic
import NF180PAShiftRows
import NF180PARegisters
import NF181PARegisters

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.RegisterSource (Instr config address readReg writeReg perform)
namespace NF180PA.Shift
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000
set_option maxRecDepth 100000

def ready (p : V) := (p<2971 ∨ p=4095) ∧ p≠2
noncomputable def location (p : V) : V :=
  if p≤1 ∨ p=7 ∨ p=8 ∨ p=4095 then p else if p=9 then 6 else p-1
noncomputable def bump (r : V) : V := ⟪pi₁ r+1,pi₂ r⟫
/-- During the refill copy itself the two counters agree. At all exterior checkpoints the new counter is one higher. -/
noncomputable def biased (p r : V) : V :=
  if p≤1 ∨ p=7 ∨ p=8 ∨ 10≤p then bump r else r
noncomputable def image (p r : V) : V := config (location p) 0 (biased p r)
instance readyDef : Language.DefinablePred ℒₒᵣ (ready (V:=V)) := by unfold ready; definability
instance locationDef : Language.DefinableFunction₁ ℒₒᵣ (location (V:=V)) := by
  apply Language.Definable.of_iff (Q:=fun v : Fin 2 → V =>
    ((v 1≤1 ∨ v 1=7 ∨ v 1=8 ∨ v 1=4095) ∧ v 0=v 1) ∨
    (¬(v 1≤1 ∨ v 1=7 ∨ v 1=8 ∨ v 1=4095) ∧
      ((v 1=9 ∧ v 0=6) ∨ (v 1≠9 ∧ v 0=v 1-1))))
  · definability
  · intro v
    by_cases h : v 1≤1 ∨ v 1=7 ∨ v 1=8 ∨ v 1=4095 <;>
      by_cases h9 : v 1=9 <;> simp [location,h,h9]
instance bumpDef : Language.DefinableFunction₁ ℒₒᵣ (bump (V:=V)) := by
  unfold bump; definability
instance biasedDef : Language.DefinableFunction₂ ℒₒᵣ (biased (V:=V)) := by
  apply Language.Definable.of_iff (Q:=fun v : Fin 3 → V =>
    ((v 1≤1 ∨ v 1=7 ∨ v 1=8 ∨ 10≤v 1) ∧ v 0=bump (v 2)) ∨
      (¬(v 1≤1 ∨ v 1=7 ∨ v 1=8 ∨ 10≤v 1) ∧ v 0=v 2))
  · definability
  · intro v
    by_cases h : v 1≤1 ∨ v 1=7 ∨ v 1=8 ∨ 10≤v 1 <;> simp [biased,h]
instance imageDef : Language.DefinableFunction₂ ℒₒᵣ (image (V:=V)) := by
  unfold image; definability

def Local (p r : V) : Prop :=
  ∃ i j p' r' : V, 0<i ∧ 0<j ∧ ready p' ∧
    iterate NF181PA.Registers.next i (config p 0 r)=config p' 0 r' ∧
    iterate NF180PA.Registers.next j (image p r)=image p' r'

theorem oneIter (f : V → V) [Language.DefinableFunction₁ ℒₒᵣ f] (x : V) :
    iterate f 1 x=f x := by simpa using iterate_succ f (0:V) x
theorem twoIter (f : V → V) [Language.DefinableFunction₁ ℒₒᵣ f] (x : V) :
    iterate f 2 x=f (f x) := by
  have two : (1:V)+1=2 := by norm_num
  simpa [oneIter,two] using iterate_succ f (1:V) x

private theorem outsideFacts {p : Nat} (h : ext p=true) :
    ready (p:V) ∧ location (p:V)=(mappedTarget p:V) ∧ ∀r : V, biased (p:V) r=bump r := by
  have he : p≤1 ∨ (10≤p ∧ p<2971) ∨ p=4095 := of_decide_eq_true h
  rcases he with lo|⟨lo,hi⟩|rfl
  · have lo' : (p:V)≤1 := by exact_mod_cast lo
    have hi' : (p:V)<2971 := lt_of_le_of_lt lo' (by norm_num)
    have ne : (p:V)≠2 := (lt_of_le_of_lt lo' (by norm_num)).ne
    simp [ready,hi',ne,location,mappedTarget,biased,lo,lo']
  · have lo' : (10:V)≤p := by exact_mod_cast lo
    have hi' : (p:V)<2971 := by exact_mod_cast hi
    have xs : ¬(p:V)≤1 := not_le.mpr (lt_of_lt_of_le (by norm_num) lo')
    have oldxs : ¬p≤1 := by omega
    have n2 : (p:V)≠2 := (lt_of_lt_of_le (by norm_num : (2:V)<10) lo').ne'
    have n7 : (p:V)≠7 := (lt_of_lt_of_le (by norm_num : (7:V)<10) lo').ne'
    have n8 : (p:V)≠8 := (lt_of_lt_of_le (by norm_num : (8:V)<10) lo').ne'
    have n9 : (p:V)≠9 := (lt_of_lt_of_le (by norm_num : (9:V)<10) lo').ne'
    have nh : (p:V)≠4095 := (lt_trans hi' (by norm_num)).ne
    have oh : p≠4095 := by omega
    have sub : ((p-1 : Nat) : V)=(p:V)-1 := by
      obtain ⟨k,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (show p≠0 by omega)
      simp [Nat.cast_succ]
    simp [ready,hi',n2,location,mappedTarget,biased,lo',xs,oldxs,n7,n8,n9,nh,oh,sub]
  · norm_num [ready,location,mappedTarget,biased]

private theorem ordinary (o : Instr) (ok : allowed o=true) (r : V) :
    ∃ t : Nat, ∃ s : V, ext t=true ∧ perform o 0 r = config (t:V) 0 s ∧
      perform (mapped o) 0 (bump r) = config (mappedTarget t:V) 0 (bump s) := by
  cases o with
  | jump t => exact ⟨t,r,ok,rfl,rfl⟩
  | inc a t =>
    rcases a with _|a
    · simp [allowed] at ok
    · refine ⟨t,writeReg (a+1) r (readReg (a+1) r+1),?_,rfl,?_⟩
      · simpa [allowed] using ok
      · simp [mapped,perform,writeReg,readReg,bump]
  | dec a z t =>
    rcases a with _|a
    · simp [allowed] at ok
    · have both : ext z=true ∧ ext t=true := by simpa [allowed] using ok
      by_cases h : readReg (a+1) r=0
      · refine ⟨z,writeReg (a+1) r 0,both.1,?_,?_⟩
        · simp [perform,chooseZero,h]
        · change readReg a (pi₂ r)=0 at h
          simp [mapped,perform,chooseZero,writeReg,readReg,bump,h]
      · refine ⟨t,writeReg (a+1) r (readReg (a+1) r-1),both.2,?_,?_⟩
        · simp [perform,chooseZero,h]
        · change readReg a (pi₂ r)≠0 at h
          simp [mapped,perform,chooseZero,writeReg,readReg,bump,h]

private theorem oldInstruction_eq (p : Nat) : oldInstruction p=NF181PA.Registers.instruction p := by
  unfold oldInstruction NF181PA.Registers.instruction
  rcases Direct181Source.Raw.program p with ⟨r,t⟩|⟨r,z,n,h⟩|t <;> rfl

private theorem newInstruction_eq (p : Nat) : newInstruction p=Registers.instruction p := by
  unfold newInstruction Registers.instruction
  rcases Blank180.Data.program p with ⟨r,t⟩|⟨r,z,n,h⟩|t <;> rfl

theorem exterior (p : Fin 2971) (hx : p.val=1 ∨ 10≤p.val) (ok : validRow p.val=true) (r : V) :
    Local (p.val:V) r := by
  have hi : ext p.val=true := by
    apply decide_eq_true; rcases hx with a|a
    · exact Or.inl (by omega)
    · exact Or.inr (Or.inl ⟨a,p.isLt⟩)
  obtain ⟨_,loc,bias⟩ := outsideFacts (V:=V) hi
  have bounds : mappedTarget p.val<2970 := by
    unfold mappedTarget; split <;> omega
  have valid : allowed (NF181PA.Registers.instruction p.val)=true ∧
      NF180PA.Registers.instruction (mappedTarget p.val)=mapped (NF181PA.Registers.instruction p.val) := by
    simpa [validRow,checkRow,hx,oldInstruction_eq,newInstruction_eq] using ok
  obtain ⟨t,s,te,old,new⟩ := ordinary _ valid.1 r
  obtain ⟨clean,loc',bias'⟩ := outsideFacts (V:=V) te
  refine ⟨1,1,(t:V),s,by simp,by simp,clean,?_,?_⟩
  · rw [oneIter,NF181PA.Registers.next_at p]; exact old
  · unfold image
    rw [oneIter,loc,bias,loc',bias',NF180PA.Registers.next_at ⟨_,bounds⟩]
    rw [valid.2]; exact new

end NF180PA.Shift
