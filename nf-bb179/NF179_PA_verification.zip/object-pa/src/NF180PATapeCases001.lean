import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w32_0 : checkWitness 32 false false 8941 = true := by decide +kernel
private theorem w32_2 : checkWitness 32 true false 8937 = true := by decide +kernel
private theorem cases32 : checkFour 32 (8941,0,8937,0) = true := by
  simp only [checkFour, w32_0, w32_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one32 : Coverage 32 33 := checkList_sound (ws:=[(8941,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases32)
private theorem w33_0 : checkWitness 33 false false 28 = true := by decide +kernel
private theorem w33_2 : checkWitness 33 true false 28 = true := by decide +kernel
private theorem cases33 : checkFour 33 (28,0,28,0) = true := by
  simp only [checkFour, w33_0, w33_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one33 : Coverage 33 34 := checkList_sound (ws:=[(28,0,28,0)]) (by simpa only [checkList, Bool.and_true] using cases33)
private theorem w34_0 : checkWitness 34 false false 720 = true := by decide +kernel
private theorem w34_1 : checkWitness 34 false true 4808 = true := by decide +kernel
private theorem w34_2 : checkWitness 34 true false 711 = true := by decide +kernel
private theorem w34_3 : checkWitness 34 true true 4799 = true := by decide +kernel
private theorem cases34 : checkFour 34 (720,4808,711,4799) = true := by
  simp only [checkFour, w34_0, w34_1, w34_2, w34_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one34 : Coverage 34 35 := checkList_sound (ws:=[(720,4808,711,4799)]) (by simpa only [checkList, Bool.and_true] using cases34)
private theorem w35_0 : checkWitness 35 false false 8959 = true := by decide +kernel
private theorem w35_2 : checkWitness 35 true false 8955 = true := by decide +kernel
private theorem cases35 : checkFour 35 (8959,0,8955,0) = true := by
  simp only [checkFour, w35_0, w35_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one35 : Coverage 35 36 := checkList_sound (ws:=[(8959,0,8955,0)]) (by simpa only [checkList, Bool.and_true] using cases35)
private theorem w36_0 : checkWitness 36 false false 32 = true := by decide +kernel
private theorem w36_2 : checkWitness 36 true false 32 = true := by decide +kernel
private theorem cases36 : checkFour 36 (32,0,32,0) = true := by
  simp only [checkFour, w36_0, w36_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one36 : Coverage 36 37 := checkList_sound (ws:=[(32,0,32,0)]) (by simpa only [checkList, Bool.and_true] using cases36)
private theorem w37_0 : checkWitness 37 false false 664 = true := by decide +kernel
private theorem w37_1 : checkWitness 37 false true 4760 = true := by decide +kernel
private theorem w37_2 : checkWitness 37 true false 664 = true := by decide +kernel
private theorem w37_3 : checkWitness 37 true true 4760 = true := by decide +kernel
private theorem cases37 : checkFour 37 (664,4760,664,4760) = true := by
  simp only [checkFour, w37_0, w37_1, w37_2, w37_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one37 : Coverage 37 38 := checkList_sound (ws:=[(664,4760,664,4760)]) (by simpa only [checkList, Bool.and_true] using cases37)
private theorem w38_0 : checkWitness 38 false false 650 = true := by decide +kernel
private theorem w38_1 : checkWitness 38 false true 4746 = true := by decide +kernel
private theorem w38_2 : checkWitness 38 true false 650 = true := by decide +kernel
private theorem w38_3 : checkWitness 38 true true 4746 = true := by decide +kernel
private theorem cases38 : checkFour 38 (650,4746,650,4746) = true := by
  simp only [checkFour, w38_0, w38_1, w38_2, w38_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one38 : Coverage 38 39 := checkList_sound (ws:=[(650,4746,650,4746)]) (by simpa only [checkList, Bool.and_true] using cases38)
private theorem w39_0 : checkWitness 39 false false 633 = true := by decide +kernel
private theorem w39_1 : checkWitness 39 false true 4729 = true := by decide +kernel
private theorem w39_2 : checkWitness 39 true false 633 = true := by decide +kernel
private theorem w39_3 : checkWitness 39 true true 4729 = true := by decide +kernel
private theorem cases39 : checkFour 39 (633,4729,633,4729) = true := by
  simp only [checkFour, w39_0, w39_1, w39_2, w39_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one39 : Coverage 39 40 := checkList_sound (ws:=[(633,4729,633,4729)]) (by simpa only [checkList, Bool.and_true] using cases39)
private theorem w40_0 : checkWitness 40 false false 8943 = true := by decide +kernel
private theorem w40_2 : checkWitness 40 true false 8939 = true := by decide +kernel
private theorem cases40 : checkFour 40 (8943,0,8939,0) = true := by
  simp only [checkFour, w40_0, w40_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one40 : Coverage 40 41 := checkList_sound (ws:=[(8943,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases40)
private theorem w41_0 : checkWitness 41 false false 672 = true := by decide +kernel
private theorem w41_1 : checkWitness 41 false true 4768 = true := by decide +kernel
private theorem w41_2 : checkWitness 41 true false 663 = true := by decide +kernel
private theorem w41_3 : checkWitness 41 true true 4759 = true := by decide +kernel
private theorem cases41 : checkFour 41 (672,4768,663,4759) = true := by
  simp only [checkFour, w41_0, w41_1, w41_2, w41_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one41 : Coverage 41 42 := checkList_sound (ws:=[(672,4768,663,4759)]) (by simpa only [checkList, Bool.and_true] using cases41)
private theorem w42_0 : checkWitness 42 false false 206 = true := by decide +kernel
private theorem w42_2 : checkWitness 42 true false 206 = true := by decide +kernel
private theorem cases42 : checkFour 42 (206,0,206,0) = true := by
  simp only [checkFour, w42_0, w42_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one42 : Coverage 42 43 := checkList_sound (ws:=[(206,0,206,0)]) (by simpa only [checkList, Bool.and_true] using cases42)
private theorem w43_0 : checkWitness 43 false false 621 = true := by decide +kernel
private theorem w43_1 : checkWitness 43 false true 4709 = true := by decide +kernel
private theorem w43_2 : checkWitness 43 true false 621 = true := by decide +kernel
private theorem w43_3 : checkWitness 43 true true 4709 = true := by decide +kernel
private theorem cases43 : checkFour 43 (621,4709,621,4709) = true := by
  simp only [checkFour, w43_0, w43_1, w43_2, w43_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one43 : Coverage 43 44 := checkList_sound (ws:=[(621,4709,621,4709)]) (by simpa only [checkList, Bool.and_true] using cases43)
private theorem w44_0 : checkWitness 44 false false 8954 = true := by decide +kernel
private theorem w44_2 : checkWitness 44 true false 8945 = true := by decide +kernel
private theorem cases44 : checkFour 44 (8954,0,8945,0) = true := by
  simp only [checkFour, w44_0, w44_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one44 : Coverage 44 45 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases44)
private theorem w45_0 : checkWitness 45 false false 46 = true := by decide +kernel
private theorem w45_2 : checkWitness 45 true false 46 = true := by decide +kernel
private theorem cases45 : checkFour 45 (46,0,46,0) = true := by
  simp only [checkFour, w45_0, w45_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one45 : Coverage 45 46 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases45)
private theorem w46_0 : checkWitness 46 false false 38 = true := by decide +kernel
private theorem w46_2 : checkWitness 46 true false 38 = true := by decide +kernel
private theorem cases46 : checkFour 46 (38,0,38,0) = true := by
  simp only [checkFour, w46_0, w46_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one46 : Coverage 46 47 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases46)
private theorem w47_0 : checkWitness 47 false false 633 = true := by decide +kernel
private theorem w47_1 : checkWitness 47 false true 4725 = true := by decide +kernel
private theorem w47_2 : checkWitness 47 true false 633 = true := by decide +kernel
private theorem w47_3 : checkWitness 47 true true 4725 = true := by decide +kernel
private theorem cases47 : checkFour 47 (633,4725,633,4725) = true := by
  simp only [checkFour, w47_0, w47_1, w47_2, w47_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one47 : Coverage 47 48 := checkList_sound (ws:=[(633,4725,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases47)
private theorem w48_0 : checkWitness 48 false false 8921 = true := by decide +kernel
private theorem w48_2 : checkWitness 48 true false 8917 = true := by decide +kernel
private theorem cases48 : checkFour 48 (8921,0,8917,0) = true := by
  simp only [checkFour, w48_0, w48_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one48 : Coverage 48 49 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases48)
private theorem w49_0 : checkWitness 49 false false 38 = true := by decide +kernel
private theorem w49_2 : checkWitness 49 true false 38 = true := by decide +kernel
private theorem cases49 : checkFour 49 (38,0,38,0) = true := by
  simp only [checkFour, w49_0, w49_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one49 : Coverage 49 50 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases49)
private theorem w50_0 : checkWitness 50 false false 684 = true := by decide +kernel
private theorem w50_1 : checkWitness 50 false true 4780 = true := by decide +kernel
private theorem w50_2 : checkWitness 50 true false 675 = true := by decide +kernel
private theorem w50_3 : checkWitness 50 true true 4771 = true := by decide +kernel
private theorem cases50 : checkFour 50 (684,4780,675,4771) = true := by
  simp only [checkFour, w50_0, w50_1, w50_2, w50_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one50 : Coverage 50 51 := checkList_sound (ws:=[(684,4780,675,4771)]) (by simpa only [checkList, Bool.and_true] using cases50)
private theorem w51_0 : checkWitness 51 false false 8969 = true := by decide +kernel
private theorem w51_2 : checkWitness 51 true false 8960 = true := by decide +kernel
private theorem cases51 : checkFour 51 (8969,0,8960,0) = true := by
  simp only [checkFour, w51_0, w51_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one51 : Coverage 51 52 := checkList_sound (ws:=[(8969,0,8960,0)]) (by simpa only [checkList, Bool.and_true] using cases51)
private theorem w52_0 : checkWitness 52 false false 40 = true := by decide +kernel
private theorem w52_2 : checkWitness 52 true false 40 = true := by decide +kernel
private theorem cases52 : checkFour 52 (40,0,40,0) = true := by
  simp only [checkFour, w52_0, w52_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one52 : Coverage 52 53 := checkList_sound (ws:=[(40,0,40,0)]) (by simpa only [checkList, Bool.and_true] using cases52)
private theorem w53_0 : checkWitness 53 false false 654 = true := by decide +kernel
private theorem w53_1 : checkWitness 53 false true 4750 = true := by decide +kernel
private theorem w53_2 : checkWitness 53 true false 654 = true := by decide +kernel
private theorem w53_3 : checkWitness 53 true true 4750 = true := by decide +kernel
private theorem cases53 : checkFour 53 (654,4750,654,4750) = true := by
  simp only [checkFour, w53_0, w53_1, w53_2, w53_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one53 : Coverage 53 54 := checkList_sound (ws:=[(654,4750,654,4750)]) (by simpa only [checkList, Bool.and_true] using cases53)
private theorem w54_0 : checkWitness 54 false false 8956 = true := by decide +kernel
private theorem w54_2 : checkWitness 54 true false 8947 = true := by decide +kernel
private theorem cases54 : checkFour 54 (8956,0,8947,0) = true := by
  simp only [checkFour, w54_0, w54_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one54 : Coverage 54 55 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases54)
private theorem w55_0 : checkWitness 55 false false 50 = true := by decide +kernel
private theorem w55_2 : checkWitness 55 true false 50 = true := by decide +kernel
private theorem cases55 : checkFour 55 (50,0,50,0) = true := by
  simp only [checkFour, w55_0, w55_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one55 : Coverage 55 56 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases55)
private theorem w56_0 : checkWitness 56 false false 534 = true := by decide +kernel
private theorem w56_1 : checkWitness 56 false true 4630 = true := by decide +kernel
private theorem w56_2 : checkWitness 56 true false 534 = true := by decide +kernel
private theorem w56_3 : checkWitness 56 true true 4630 = true := by decide +kernel
private theorem cases56 : checkFour 56 (534,4630,534,4630) = true := by
  simp only [checkFour, w56_0, w56_1, w56_2, w56_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one56 : Coverage 56 57 := checkList_sound (ws:=[(534,4630,534,4630)]) (by simpa only [checkList, Bool.and_true] using cases56)
private theorem w57_0 : checkWitness 57 false false 8908 = true := by decide +kernel
private theorem w57_2 : checkWitness 57 true false 8904 = true := by decide +kernel
private theorem cases57 : checkFour 57 (8908,0,8904,0) = true := by
  simp only [checkFour, w57_0, w57_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one57 : Coverage 57 58 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases57)
private theorem w58_0 : checkWitness 58 false false 54 = true := by decide +kernel
private theorem w58_2 : checkWitness 58 true false 54 = true := by decide +kernel
private theorem cases58 : checkFour 58 (54,0,54,0) = true := by
  simp only [checkFour, w58_0, w58_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one58 : Coverage 58 59 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases58)
private theorem w59_0 : checkWitness 59 false false 576 = true := by decide +kernel
private theorem w59_1 : checkWitness 59 false true 4672 = true := by decide +kernel
private theorem w59_2 : checkWitness 59 true false 576 = true := by decide +kernel
private theorem w59_3 : checkWitness 59 true true 4672 = true := by decide +kernel
private theorem cases59 : checkFour 59 (576,4672,576,4672) = true := by
  simp only [checkFour, w59_0, w59_1, w59_2, w59_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one59 : Coverage 59 60 := checkList_sound (ws:=[(576,4672,576,4672)]) (by simpa only [checkList, Bool.and_true] using cases59)
private theorem w60_0 : checkWitness 60 false false 8927 = true := by decide +kernel
private theorem w60_2 : checkWitness 60 true false 8923 = true := by decide +kernel
private theorem cases60 : checkFour 60 (8927,0,8923,0) = true := by
  simp only [checkFour, w60_0, w60_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one60 : Coverage 60 61 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases60)
private theorem w61_0 : checkWitness 61 false false 8958 = true := by decide +kernel
private theorem w61_2 : checkWitness 61 true false 8949 = true := by decide +kernel
private theorem cases61 : checkFour 61 (8958,0,8949,0) = true := by
  simp only [checkFour, w61_0, w61_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one61 : Coverage 61 62 := checkList_sound (ws:=[(8958,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases61)
private theorem w62_0 : checkWitness 62 false false 78 = true := by decide +kernel
private theorem w62_2 : checkWitness 62 true false 78 = true := by decide +kernel
private theorem cases62 : checkFour 62 (78,0,78,0) = true := by
  simp only [checkFour, w62_0, w62_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one62 : Coverage 62 63 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases62)
private theorem w63_0 : checkWitness 63 false false 672 = true := by decide +kernel
private theorem w63_1 : checkWitness 63 false true 4764 = true := by decide +kernel
private theorem w63_2 : checkWitness 63 true false 663 = true := by decide +kernel
private theorem w63_3 : checkWitness 63 true true 4755 = true := by decide +kernel
private theorem cases63 : checkFour 63 (672,4764,663,4755) = true := by
  simp only [checkFour, w63_0, w63_1, w63_2, w63_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one63 : Coverage 63 64 := checkList_sound (ws:=[(672,4764,663,4755)]) (by simpa only [checkList, Bool.and_true] using cases63)
theorem cover0032 : Coverage 32 64 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one32 one33) (Coverage.join one34 one35)) (Coverage.join (Coverage.join one36 one37) (Coverage.join one38 one39))) (Coverage.join (Coverage.join (Coverage.join one40 one41) (Coverage.join one42 one43)) (Coverage.join (Coverage.join one44 one45) (Coverage.join one46 one47)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one48 one49) (Coverage.join one50 one51)) (Coverage.join (Coverage.join one52 one53) (Coverage.join one54 one55))) (Coverage.join (Coverage.join (Coverage.join one56 one57) (Coverage.join one58 one59)) (Coverage.join (Coverage.join one60 one61) (Coverage.join one62 one63)))))
end NF180PA.Symbolic
