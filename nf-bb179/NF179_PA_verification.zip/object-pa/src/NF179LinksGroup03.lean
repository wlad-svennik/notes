import NF179LinksBase
namespace NF180PA.Links
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part768 : Covers 768 784 := block_sound (lo:=768) (n:=16) (by decide +kernel)
private theorem part784 : Covers 784 800 := block_sound (lo:=784) (n:=16) (by decide +kernel)
private theorem part800 : Covers 800 816 := block_sound (lo:=800) (n:=16) (by decide +kernel)
private theorem part816 : Covers 816 832 := block_sound (lo:=816) (n:=16) (by decide +kernel)
private theorem part832 : Covers 832 848 := block_sound (lo:=832) (n:=16) (by decide +kernel)
private theorem part848 : Covers 848 864 := block_sound (lo:=848) (n:=16) (by decide +kernel)
private theorem part864 : Covers 864 880 := block_sound (lo:=864) (n:=16) (by decide +kernel)
private theorem part880 : Covers 880 896 := block_sound (lo:=880) (n:=16) (by decide +kernel)
private theorem part896 : Covers 896 912 := block_sound (lo:=896) (n:=16) (by decide +kernel)
private theorem part912 : Covers 912 928 := block_sound (lo:=912) (n:=16) (by decide +kernel)
private theorem part928 : Covers 928 944 := block_sound (lo:=928) (n:=16) (by decide +kernel)
private theorem part944 : Covers 944 960 := block_sound (lo:=944) (n:=16) (by decide +kernel)
private theorem part960 : Covers 960 976 := block_sound (lo:=960) (n:=16) (by decide +kernel)
private theorem part976 : Covers 976 992 := block_sound (lo:=976) (n:=16) (by decide +kernel)
private theorem part992 : Covers 992 1008 := block_sound (lo:=992) (n:=16) (by decide +kernel)
private theorem part1008 : Covers 1008 1024 := block_sound (lo:=1008) (n:=16) (by decide +kernel)
theorem group768 : Covers 768 1024 := (Covers.join (Covers.join (Covers.join (Covers.join part768 part784) (Covers.join part800 part816)) (Covers.join (Covers.join part832 part848) (Covers.join part864 part880))) (Covers.join (Covers.join (Covers.join part896 part912) (Covers.join part928 part944)) (Covers.join (Covers.join part960 part976) (Covers.join part992 part1008))))
end NF180PA.Links
