import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1760_0 : checkWitness 1760 false false 593 = true := by decide +kernel
private theorem w1760_1 : checkWitness 1760 false true 4677 = true := by decide +kernel
private theorem w1760_2 : checkWitness 1760 true false 593 = true := by decide +kernel
private theorem w1760_3 : checkWitness 1760 true true 4677 = true := by decide +kernel
private theorem cases1760 : checkFour 1760 (593,4677,593,4677) = true := by
  simp only [checkFour, w1760_0, w1760_1, w1760_2, w1760_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1760 : Coverage 1760 1761 := checkList_sound (ws:=[(593,4677,593,4677)]) (by simpa only [checkList, Bool.and_true] using cases1760)
private theorem w1761_0 : checkWitness 1761 false false 8860 = true := by decide +kernel
private theorem w1761_2 : checkWitness 1761 true false 8856 = true := by decide +kernel
private theorem cases1761 : checkFour 1761 (8860,0,8856,0) = true := by
  simp only [checkFour, w1761_0, w1761_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1761 : Coverage 1761 1762 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases1761)
private theorem w1762_0 : checkWitness 1762 false false 86 = true := by decide +kernel
private theorem w1762_2 : checkWitness 1762 true false 86 = true := by decide +kernel
private theorem cases1762 : checkFour 1762 (86,0,86,0) = true := by
  simp only [checkFour, w1762_0, w1762_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1762 : Coverage 1762 1763 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1762)
private theorem w1763_0 : checkWitness 1763 false false 569 = true := by decide +kernel
private theorem w1763_1 : checkWitness 1763 false true 4665 = true := by decide +kernel
private theorem w1763_2 : checkWitness 1763 true false 569 = true := by decide +kernel
private theorem w1763_3 : checkWitness 1763 true true 4665 = true := by decide +kernel
private theorem cases1763 : checkFour 1763 (569,4665,569,4665) = true := by
  simp only [checkFour, w1763_0, w1763_1, w1763_2, w1763_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1763 : Coverage 1763 1764 := checkList_sound (ws:=[(569,4665,569,4665)]) (by simpa only [checkList, Bool.and_true] using cases1763)
private theorem w1764_0 : checkWitness 1764 false false 8930 = true := by decide +kernel
private theorem w1764_2 : checkWitness 1764 true false 8921 = true := by decide +kernel
private theorem cases1764 : checkFour 1764 (8930,0,8921,0) = true := by
  simp only [checkFour, w1764_0, w1764_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1764 : Coverage 1764 1765 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases1764)
private theorem w1765_0 : checkWitness 1765 false false 8876 = true := by decide +kernel
private theorem w1765_2 : checkWitness 1765 true false 8872 = true := by decide +kernel
private theorem cases1765 : checkFour 1765 (8876,0,8872,0) = true := by
  simp only [checkFour, w1765_0, w1765_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1765 : Coverage 1765 1766 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases1765)
private theorem w1766_0 : checkWitness 1766 false false 94 = true := by decide +kernel
private theorem w1766_2 : checkWitness 1766 true false 94 = true := by decide +kernel
private theorem cases1766 : checkFour 1766 (94,0,94,0) = true := by
  simp only [checkFour, w1766_0, w1766_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1766 : Coverage 1766 1767 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1766)
private theorem w1767_0 : checkWitness 1767 false false 656 = true := by decide +kernel
private theorem w1767_1 : checkWitness 1767 false true 4744 = true := by decide +kernel
private theorem w1767_2 : checkWitness 1767 true false 647 = true := by decide +kernel
private theorem w1767_3 : checkWitness 1767 true true 4735 = true := by decide +kernel
private theorem cases1767 : checkFour 1767 (656,4744,647,4735) = true := by
  simp only [checkFour, w1767_0, w1767_1, w1767_2, w1767_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1767 : Coverage 1767 1768 := checkList_sound (ws:=[(656,4744,647,4735)]) (by simpa only [checkList, Bool.and_true] using cases1767)
private theorem w1768_0 : checkWitness 1768 false false 8895 = true := by decide +kernel
private theorem w1768_2 : checkWitness 1768 true false 8891 = true := by decide +kernel
private theorem cases1768 : checkFour 1768 (8895,0,8891,0) = true := by
  simp only [checkFour, w1768_0, w1768_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1768 : Coverage 1768 1769 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1768)
private theorem w1769_0 : checkWitness 1769 false false 84 = true := by decide +kernel
private theorem w1769_2 : checkWitness 1769 true false 84 = true := by decide +kernel
private theorem cases1769 : checkFour 1769 (84,0,84,0) = true := by
  simp only [checkFour, w1769_0, w1769_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1769 : Coverage 1769 1770 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1769)
private theorem w1770_0 : checkWitness 1770 false false 620 = true := by decide +kernel
private theorem w1770_1 : checkWitness 1770 false true 4716 = true := by decide +kernel
private theorem w1770_2 : checkWitness 1770 true false 620 = true := by decide +kernel
private theorem w1770_3 : checkWitness 1770 true true 4716 = true := by decide +kernel
private theorem cases1770 : checkFour 1770 (620,4716,620,4716) = true := by
  simp only [checkFour, w1770_0, w1770_1, w1770_2, w1770_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1770 : Coverage 1770 1771 := checkList_sound (ws:=[(620,4716,620,4716)]) (by simpa only [checkList, Bool.and_true] using cases1770)
private theorem w1771_0 : checkWitness 1771 false false 8898 = true := by decide +kernel
private theorem w1771_2 : checkWitness 1771 true false 8889 = true := by decide +kernel
private theorem cases1771 : checkFour 1771 (8898,0,8889,0) = true := by
  simp only [checkFour, w1771_0, w1771_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1771 : Coverage 1771 1772 := checkList_sound (ws:=[(8898,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1771)
private theorem w1772_0 : checkWitness 1772 false false 74 = true := by decide +kernel
private theorem w1772_2 : checkWitness 1772 true false 74 = true := by decide +kernel
private theorem cases1772 : checkFour 1772 (74,0,74,0) = true := by
  simp only [checkFour, w1772_0, w1772_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1772 : Coverage 1772 1773 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1772)
private theorem w1773_0 : checkWitness 1773 false false 476 = true := by decide +kernel
private theorem w1773_1 : checkWitness 1773 false true 4572 = true := by decide +kernel
private theorem w1773_2 : checkWitness 1773 true false 476 = true := by decide +kernel
private theorem w1773_3 : checkWitness 1773 true true 4572 = true := by decide +kernel
private theorem cases1773 : checkFour 1773 (476,4572,476,4572) = true := by
  simp only [checkFour, w1773_0, w1773_1, w1773_2, w1773_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1773 : Coverage 1773 1774 := checkList_sound (ws:=[(476,4572,476,4572)]) (by simpa only [checkList, Bool.and_true] using cases1773)
private theorem w1774_0 : checkWitness 1774 false false 8850 = true := by decide +kernel
private theorem w1774_2 : checkWitness 1774 true false 8846 = true := by decide +kernel
private theorem cases1774 : checkFour 1774 (8850,0,8846,0) = true := by
  simp only [checkFour, w1774_0, w1774_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1774 : Coverage 1774 1775 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases1774)
private theorem w1775_0 : checkWitness 1775 false false 78 = true := by decide +kernel
private theorem w1775_2 : checkWitness 1775 true false 78 = true := by decide +kernel
private theorem cases1775 : checkFour 1775 (78,0,78,0) = true := by
  simp only [checkFour, w1775_0, w1775_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1775 : Coverage 1775 1776 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1775)
private theorem w1776_0 : checkWitness 1776 false false 518 = true := by decide +kernel
private theorem w1776_1 : checkWitness 1776 false true 4614 = true := by decide +kernel
private theorem w1776_2 : checkWitness 1776 true false 518 = true := by decide +kernel
private theorem w1776_3 : checkWitness 1776 true true 4614 = true := by decide +kernel
private theorem cases1776 : checkFour 1776 (518,4614,518,4614) = true := by
  simp only [checkFour, w1776_0, w1776_1, w1776_2, w1776_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1776 : Coverage 1776 1777 := checkList_sound (ws:=[(518,4614,518,4614)]) (by simpa only [checkList, Bool.and_true] using cases1776)
private theorem w1777_0 : checkWitness 1777 false false 8869 = true := by decide +kernel
private theorem w1777_2 : checkWitness 1777 true false 8865 = true := by decide +kernel
private theorem cases1777 : checkFour 1777 (8869,0,8865,0) = true := by
  simp only [checkFour, w1777_0, w1777_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1777 : Coverage 1777 1778 := checkList_sound (ws:=[(8869,0,8865,0)]) (by simpa only [checkList, Bool.and_true] using cases1777)
private theorem w1778_0 : checkWitness 1778 false false 8900 = true := by decide +kernel
private theorem w1778_2 : checkWitness 1778 true false 8891 = true := by decide +kernel
private theorem cases1778 : checkFour 1778 (8900,0,8891,0) = true := by
  simp only [checkFour, w1778_0, w1778_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1778 : Coverage 1778 1779 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1778)
private theorem w1779_0 : checkWitness 1779 false false 102 = true := by decide +kernel
private theorem w1779_2 : checkWitness 1779 true false 102 = true := by decide +kernel
private theorem cases1779 : checkFour 1779 (102,0,102,0) = true := by
  simp only [checkFour, w1779_0, w1779_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1779 : Coverage 1779 1780 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1779)
private theorem w1780_0 : checkWitness 1780 false false 614 = true := by decide +kernel
private theorem w1780_1 : checkWitness 1780 false true 4706 = true := by decide +kernel
private theorem w1780_2 : checkWitness 1780 true false 605 = true := by decide +kernel
private theorem w1780_3 : checkWitness 1780 true true 4697 = true := by decide +kernel
private theorem cases1780 : checkFour 1780 (614,4706,605,4697) = true := by
  simp only [checkFour, w1780_0, w1780_1, w1780_2, w1780_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1780 : Coverage 1780 1781 := checkList_sound (ws:=[(614,4706,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases1780)
private theorem w1781_0 : checkWitness 1781 false false 8865 = true := by decide +kernel
private theorem w1781_2 : checkWitness 1781 true false 8861 = true := by decide +kernel
private theorem cases1781 : checkFour 1781 (8865,0,8861,0) = true := by
  simp only [checkFour, w1781_0, w1781_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1781 : Coverage 1781 1782 := checkList_sound (ws:=[(8865,0,8861,0)]) (by simpa only [checkList, Bool.and_true] using cases1781)
private theorem w1782_0 : checkWitness 1782 false false 608 = true := by decide +kernel
private theorem w1782_1 : checkWitness 1782 false true 4700 = true := by decide +kernel
private theorem w1782_2 : checkWitness 1782 true false 599 = true := by decide +kernel
private theorem w1782_3 : checkWitness 1782 true true 4691 = true := by decide +kernel
private theorem cases1782 : checkFour 1782 (608,4700,599,4691) = true := by
  simp only [checkFour, w1782_0, w1782_1, w1782_2, w1782_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1782 : Coverage 1782 1783 := checkList_sound (ws:=[(608,4700,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases1782)
private theorem w1783_0 : checkWitness 1783 false false 8836 = true := by decide +kernel
private theorem w1783_2 : checkWitness 1783 true false 8832 = true := by decide +kernel
private theorem cases1783 : checkFour 1783 (8836,0,8832,0) = true := by
  simp only [checkFour, w1783_0, w1783_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1783 : Coverage 1783 1784 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1783)
private theorem w1784_0 : checkWitness 1784 false false 90 = true := by decide +kernel
private theorem w1784_2 : checkWitness 1784 true false 90 = true := by decide +kernel
private theorem cases1784 : checkFour 1784 (90,0,90,0) = true := by
  simp only [checkFour, w1784_0, w1784_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1784 : Coverage 1784 1785 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1784)
private theorem w1785_0 : checkWitness 1785 false false 82 = true := by decide +kernel
private theorem w1785_2 : checkWitness 1785 true false 82 = true := by decide +kernel
private theorem cases1785 : checkFour 1785 (82,0,82,0) = true := by
  simp only [checkFour, w1785_0, w1785_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1785 : Coverage 1785 1786 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1785)
private theorem w1786_0 : checkWitness 1786 false false 561 = true := by decide +kernel
private theorem w1786_1 : checkWitness 1786 false true 4645 = true := by decide +kernel
private theorem w1786_2 : checkWitness 1786 true false 561 = true := by decide +kernel
private theorem w1786_3 : checkWitness 1786 true true 4645 = true := by decide +kernel
private theorem cases1786 : checkFour 1786 (561,4645,561,4645) = true := by
  simp only [checkFour, w1786_0, w1786_1, w1786_2, w1786_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1786 : Coverage 1786 1787 := checkList_sound (ws:=[(561,4645,561,4645)]) (by simpa only [checkList, Bool.and_true] using cases1786)
private theorem w1787_0 : checkWitness 1787 false false 8828 = true := by decide +kernel
private theorem w1787_2 : checkWitness 1787 true false 8824 = true := by decide +kernel
private theorem cases1787 : checkFour 1787 (8828,0,8824,0) = true := by
  simp only [checkFour, w1787_0, w1787_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1787 : Coverage 1787 1788 := checkList_sound (ws:=[(8828,0,8824,0)]) (by simpa only [checkList, Bool.and_true] using cases1787)
private theorem w1788_0 : checkWitness 1788 false false 82 = true := by decide +kernel
private theorem w1788_2 : checkWitness 1788 true false 82 = true := by decide +kernel
private theorem cases1788 : checkFour 1788 (82,0,82,0) = true := by
  simp only [checkFour, w1788_0, w1788_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1788 : Coverage 1788 1789 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1788)
private theorem w1789_0 : checkWitness 1789 false false 605 = true := by decide +kernel
private theorem w1789_1 : checkWitness 1789 false true 4697 = true := by decide +kernel
private theorem w1789_2 : checkWitness 1789 true false 596 = true := by decide +kernel
private theorem w1789_3 : checkWitness 1789 true true 4688 = true := by decide +kernel
private theorem cases1789 : checkFour 1789 (605,4697,596,4688) = true := by
  simp only [checkFour, w1789_0, w1789_1, w1789_2, w1789_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1789 : Coverage 1789 1790 := checkList_sound (ws:=[(605,4697,596,4688)]) (by simpa only [checkList, Bool.and_true] using cases1789)
private theorem w1790_0 : checkWitness 1790 false false 8902 = true := by decide +kernel
private theorem w1790_2 : checkWitness 1790 true false 8893 = true := by decide +kernel
private theorem cases1790 : checkFour 1790 (8902,0,8893,0) = true := by
  simp only [checkFour, w1790_0, w1790_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1790 : Coverage 1790 1791 := checkList_sound (ws:=[(8902,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases1790)
private theorem w1791_0 : checkWitness 1791 false false 8848 = true := by decide +kernel
private theorem w1791_2 : checkWitness 1791 true false 8844 = true := by decide +kernel
private theorem cases1791 : checkFour 1791 (8848,0,8844,0) = true := by
  simp only [checkFour, w1791_0, w1791_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1791 : Coverage 1791 1792 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases1791)
theorem cover1760 : Coverage 1760 1792 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1760 one1761) (Coverage.join one1762 one1763)) (Coverage.join (Coverage.join one1764 one1765) (Coverage.join one1766 one1767))) (Coverage.join (Coverage.join (Coverage.join one1768 one1769) (Coverage.join one1770 one1771)) (Coverage.join (Coverage.join one1772 one1773) (Coverage.join one1774 one1775)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1776 one1777) (Coverage.join one1778 one1779)) (Coverage.join (Coverage.join one1780 one1781) (Coverage.join one1782 one1783))) (Coverage.join (Coverage.join (Coverage.join one1784 one1785) (Coverage.join one1786 one1787)) (Coverage.join (Coverage.join one1788 one1789) (Coverage.join one1790 one1791)))))
end NF180PA.Symbolic
