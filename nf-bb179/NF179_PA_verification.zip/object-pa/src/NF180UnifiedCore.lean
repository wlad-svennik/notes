import NF180PAModelSearch
import NF182PAPoolNat
import NF182PACountermodel
import M6PA.Calibration.Foundation
import Moving186NF
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
namespace NF180PA

theorem internal_consistency_of_coverage (cover : Symbolic.Coverage 0 2970) :
    M6.PA.theory ⊢ (∼H180) 🡒 M6.PA.consistencySentence := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff,LogicalConnective.HomClass.map_imply,LogicalConnective.HomClass.map_neg]
  intro nh
  have no : ¬NF181PA.Pool.Pr (∅ : V) goal :=
    fun p => nh ((model_refutation_of_coverage cover).mpr p)
  have hc : M6.PA.theory.Consistent V := by
    intro h
    exact NF182PA.Pool.no_refutation_implies_pa_consistency no (by simpa only [Sentence.quote_falsum] using h)
  simpa [M6.PA.consistencySentence,ProvabilityAbstraction.Provability.con,
    ProvabilityAbstraction.Provability.pr,Theory.Consistent] using hc
end NF180PA
namespace NFMachine180
open NF180PA NF210

theorem halts_iff_nf_refutation_of_coverage (cover : Symbolic.Coverage 0 2970) :
    TM.Halts Blank180.Table.machine Blank180.Table.start ↔ (𝗡𝗙 ⊢ ⊥) := by
  rw [←H180_standard, ←Moving186.deriv_goal_iff_nf_refutation]
  have code : (goal : Nat) = NF192.Numerical.goal := goal_three.trans NF192.Numerical.goal_is_three.symm
  rw [←code]
  constructor
  · exact fun h => NF182PA.Pool.derivation_of_pool ((model_refutation_of_coverage cover).mp h)
  · exact fun h => (model_refutation_of_coverage cover).mpr (NF182PA.Pool.pool_of_derivation h)
end NFMachine180
#print axioms NF180PA.model_refutation_of_coverage
#print axioms NF180PA.internal_consistency_of_coverage
#print axioms NFMachine180.halts_iff_nf_refutation_of_coverage
