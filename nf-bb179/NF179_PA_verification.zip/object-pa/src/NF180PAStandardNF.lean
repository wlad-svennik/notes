import NF180PAStandardExact
import Moving186NF

open FFL FFL.FirstOrder
namespace NF180PA
theorem halts_iff_nf_refutes : NF210.TM.Halts Blank180.Table.machine Blank180.Table.start ↔
    (𝗡𝗙 ⊢ ⊥) := by
  rw [halts_iff_derivation,←NF192.Numerical.goal_is_three]
  exact Moving186.deriv_goal_iff_nf_refutation
end NF180PA
#print axioms NF180PA.halts_iff_nf_refutes
