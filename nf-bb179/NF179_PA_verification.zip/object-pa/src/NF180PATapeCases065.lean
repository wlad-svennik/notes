import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2080_0 : checkWitness 2080 false false 8924 = true := by decide +kernel
private theorem w2080_2 : checkWitness 2080 true false 8915 = true := by decide +kernel
private theorem cases2080 : checkFour 2080 (8924,0,8915,0) = true := by
  simp only [checkFour, w2080_0, w2080_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2080 : Coverage 2080 2081 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases2080)
private theorem w2081_0 : checkWitness 2081 false false 86 = true := by decide +kernel
private theorem w2081_2 : checkWitness 2081 true false 86 = true := by decide +kernel
private theorem cases2081 : checkFour 2081 (86,0,86,0) = true := by
  simp only [checkFour, w2081_0, w2081_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2081 : Coverage 2081 2082 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases2081)
private theorem w2082_0 : checkWitness 2082 false false 78 = true := by decide +kernel
private theorem w2082_2 : checkWitness 2082 true false 78 = true := by decide +kernel
private theorem cases2082 : checkFour 2082 (78,0,78,0) = true := by
  simp only [checkFour, w2082_0, w2082_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2082 : Coverage 2082 2083 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2082)
private theorem w2083_0 : checkWitness 2083 false false 591 = true := by decide +kernel
private theorem w2083_1 : checkWitness 2083 false true 4683 = true := by decide +kernel
private theorem w2083_2 : checkWitness 2083 true false 591 = true := by decide +kernel
private theorem w2083_3 : checkWitness 2083 true true 4683 = true := by decide +kernel
private theorem cases2083 : checkFour 2083 (591,4683,591,4683) = true := by
  simp only [checkFour, w2083_0, w2083_1, w2083_2, w2083_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2083 : Coverage 2083 2084 := checkList_sound (ws:=[(591,4683,591,4683)]) (by simpa only [checkList, Bool.and_true] using cases2083)
private theorem w2084_0 : checkWitness 2084 false false 8866 = true := by decide +kernel
private theorem w2084_2 : checkWitness 2084 true false 8862 = true := by decide +kernel
private theorem cases2084 : checkFour 2084 (8866,0,8862,0) = true := by
  simp only [checkFour, w2084_0, w2084_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2084 : Coverage 2084 2085 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases2084)
private theorem w2085_0 : checkWitness 2085 false false 78 = true := by decide +kernel
private theorem w2085_2 : checkWitness 2085 true false 78 = true := by decide +kernel
private theorem cases2085 : checkFour 2085 (78,0,78,0) = true := by
  simp only [checkFour, w2085_0, w2085_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2085 : Coverage 2085 2086 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2085)
private theorem w2086_0 : checkWitness 2086 false false 550 = true := by decide +kernel
private theorem w2086_1 : checkWitness 2086 false true 4646 = true := by decide +kernel
private theorem w2086_2 : checkWitness 2086 true false 550 = true := by decide +kernel
private theorem w2086_3 : checkWitness 2086 true true 4646 = true := by decide +kernel
private theorem cases2086 : checkFour 2086 (550,4646,550,4646) = true := by
  simp only [checkFour, w2086_0, w2086_1, w2086_2, w2086_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2086 : Coverage 2086 2087 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases2086)
private theorem w2087_0 : checkWitness 2087 false false 8901 = true := by decide +kernel
private theorem w2087_2 : checkWitness 2087 true false 8897 = true := by decide +kernel
private theorem cases2087 : checkFour 2087 (8901,0,8897,0) = true := by
  simp only [checkFour, w2087_0, w2087_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2087 : Coverage 2087 2088 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases2087)
private theorem w2088_0 : checkWitness 2088 false false 8932 = true := by decide +kernel
private theorem w2088_2 : checkWitness 2088 true false 8923 = true := by decide +kernel
private theorem cases2088 : checkFour 2088 (8932,0,8923,0) = true := by
  simp only [checkFour, w2088_0, w2088_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2088 : Coverage 2088 2089 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases2088)
private theorem w2089_0 : checkWitness 2089 false false 96 = true := by decide +kernel
private theorem w2089_2 : checkWitness 2089 true false 96 = true := by decide +kernel
private theorem cases2089 : checkFour 2089 (96,0,96,0) = true := by
  simp only [checkFour, w2089_0, w2089_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2089 : Coverage 2089 2090 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases2089)
private theorem w2090_0 : checkWitness 2090 false false 646 = true := by decide +kernel
private theorem w2090_1 : checkWitness 2090 false true 4738 = true := by decide +kernel
private theorem w2090_2 : checkWitness 2090 true false 637 = true := by decide +kernel
private theorem w2090_3 : checkWitness 2090 true true 4729 = true := by decide +kernel
private theorem cases2090 : checkFour 2090 (646,4738,637,4729) = true := by
  simp only [checkFour, w2090_0, w2090_1, w2090_2, w2090_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2090 : Coverage 2090 2091 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases2090)
private theorem w2091_0 : checkWitness 2091 false false 8897 = true := by decide +kernel
private theorem w2091_2 : checkWitness 2091 true false 8893 = true := by decide +kernel
private theorem cases2091 : checkFour 2091 (8897,0,8893,0) = true := by
  simp only [checkFour, w2091_0, w2091_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2091 : Coverage 2091 2092 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases2091)
private theorem w2092_0 : checkWitness 2092 false false 640 = true := by decide +kernel
private theorem w2092_1 : checkWitness 2092 false true 4732 = true := by decide +kernel
private theorem w2092_2 : checkWitness 2092 true false 631 = true := by decide +kernel
private theorem w2092_3 : checkWitness 2092 true true 4723 = true := by decide +kernel
private theorem cases2092 : checkFour 2092 (640,4732,631,4723) = true := by
  simp only [checkFour, w2092_0, w2092_1, w2092_2, w2092_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2092 : Coverage 2092 2093 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases2092)
private theorem w2093_0 : checkWitness 2093 false false 8868 = true := by decide +kernel
private theorem w2093_2 : checkWitness 2093 true false 8864 = true := by decide +kernel
private theorem cases2093 : checkFour 2093 (8868,0,8864,0) = true := by
  simp only [checkFour, w2093_0, w2093_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2093 : Coverage 2093 2094 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases2093)
private theorem w2094_0 : checkWitness 2094 false false 84 = true := by decide +kernel
private theorem w2094_2 : checkWitness 2094 true false 84 = true := by decide +kernel
private theorem cases2094 : checkFour 2094 (84,0,84,0) = true := by
  simp only [checkFour, w2094_0, w2094_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2094 : Coverage 2094 2095 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2094)
private theorem w2095_0 : checkWitness 2095 false false 76 = true := by decide +kernel
private theorem w2095_2 : checkWitness 2095 true false 76 = true := by decide +kernel
private theorem cases2095 : checkFour 2095 (76,0,76,0) = true := by
  simp only [checkFour, w2095_0, w2095_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2095 : Coverage 2095 2096 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2095)
private theorem w2096_0 : checkWitness 2096 false false 601 = true := by decide +kernel
private theorem w2096_1 : checkWitness 2096 false true 4689 = true := by decide +kernel
private theorem w2096_2 : checkWitness 2096 true false 601 = true := by decide +kernel
private theorem w2096_3 : checkWitness 2096 true true 4689 = true := by decide +kernel
private theorem cases2096 : checkFour 2096 (601,4689,601,4689) = true := by
  simp only [checkFour, w2096_0, w2096_1, w2096_2, w2096_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2096 : Coverage 2096 2097 := checkList_sound (ws:=[(601,4689,601,4689)]) (by simpa only [checkList, Bool.and_true] using cases2096)
private theorem w2097_0 : checkWitness 2097 false false 8884 = true := by decide +kernel
private theorem w2097_2 : checkWitness 2097 true false 8880 = true := by decide +kernel
private theorem cases2097 : checkFour 2097 (8884,0,8880,0) = true := by
  simp only [checkFour, w2097_0, w2097_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2097 : Coverage 2097 2098 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases2097)
private theorem w2098_0 : checkWitness 2098 false false 8880 = true := by decide +kernel
private theorem w2098_2 : checkWitness 2098 true false 8876 = true := by decide +kernel
private theorem cases2098 : checkFour 2098 (8880,0,8876,0) = true := by
  simp only [checkFour, w2098_0, w2098_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2098 : Coverage 2098 2099 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases2098)
private theorem w2099_0 : checkWitness 2099 false false 90 = true := by decide +kernel
private theorem w2099_2 : checkWitness 2099 true false 90 = true := by decide +kernel
private theorem cases2099 : checkFour 2099 (90,0,90,0) = true := by
  simp only [checkFour, w2099_0, w2099_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2099 : Coverage 2099 2100 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases2099)
private theorem w2100_0 : checkWitness 2100 false false 8912 = true := by decide +kernel
private theorem w2100_2 : checkWitness 2100 true false 8908 = true := by decide +kernel
private theorem cases2100 : checkFour 2100 (8912,0,8908,0) = true := by
  simp only [checkFour, w2100_0, w2100_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2100 : Coverage 2100 2101 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases2100)
private theorem w2101_0 : checkWitness 2101 false false 682 = true := by decide +kernel
private theorem w2101_1 : checkWitness 2101 false true 4778 = true := by decide +kernel
private theorem w2101_2 : checkWitness 2101 true false 682 = true := by decide +kernel
private theorem w2101_3 : checkWitness 2101 true true 4778 = true := by decide +kernel
private theorem cases2101 : checkFour 2101 (682,4778,682,4778) = true := by
  simp only [checkFour, w2101_0, w2101_1, w2101_2, w2101_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2101 : Coverage 2101 2102 := checkList_sound (ws:=[(682,4778,682,4778)]) (by simpa only [checkList, Bool.and_true] using cases2101)
private theorem w2102_0 : checkWitness 2102 false false 8962 = true := by decide +kernel
private theorem w2102_2 : checkWitness 2102 true false 8953 = true := by decide +kernel
private theorem cases2102 : checkFour 2102 (8962,0,8953,0) = true := by
  simp only [checkFour, w2102_0, w2102_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2102 : Coverage 2102 2103 := checkList_sound (ws:=[(8962,0,8953,0)]) (by simpa only [checkList, Bool.and_true] using cases2102)
private theorem w2103_0 : checkWitness 2103 false false 72 = true := by decide +kernel
private theorem w2103_2 : checkWitness 2103 true false 72 = true := by decide +kernel
private theorem cases2103 : checkFour 2103 (72,0,72,0) = true := by
  simp only [checkFour, w2103_0, w2103_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2103 : Coverage 2103 2104 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2103)
private theorem w2104_0 : checkWitness 2104 false false 540 = true := by decide +kernel
private theorem w2104_1 : checkWitness 2104 false true 4636 = true := by decide +kernel
private theorem w2104_2 : checkWitness 2104 true false 540 = true := by decide +kernel
private theorem w2104_3 : checkWitness 2104 true true 4636 = true := by decide +kernel
private theorem cases2104 : checkFour 2104 (540,4636,540,4636) = true := by
  simp only [checkFour, w2104_0, w2104_1, w2104_2, w2104_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2104 : Coverage 2104 2105 := checkList_sound (ws:=[(540,4636,540,4636)]) (by simpa only [checkList, Bool.and_true] using cases2104)
private theorem w2105_0 : checkWitness 2105 false false 8914 = true := by decide +kernel
private theorem w2105_2 : checkWitness 2105 true false 8910 = true := by decide +kernel
private theorem cases2105 : checkFour 2105 (8914,0,8910,0) = true := by
  simp only [checkFour, w2105_0, w2105_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2105 : Coverage 2105 2106 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases2105)
private theorem w2106_0 : checkWitness 2106 false false 76 = true := by decide +kernel
private theorem w2106_2 : checkWitness 2106 true false 76 = true := by decide +kernel
private theorem cases2106 : checkFour 2106 (76,0,76,0) = true := by
  simp only [checkFour, w2106_0, w2106_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2106 : Coverage 2106 2107 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2106)
private theorem w2107_0 : checkWitness 2107 false false 582 = true := by decide +kernel
private theorem w2107_1 : checkWitness 2107 false true 4678 = true := by decide +kernel
private theorem w2107_2 : checkWitness 2107 true false 582 = true := by decide +kernel
private theorem w2107_3 : checkWitness 2107 true true 4678 = true := by decide +kernel
private theorem cases2107 : checkFour 2107 (582,4678,582,4678) = true := by
  simp only [checkFour, w2107_0, w2107_1, w2107_2, w2107_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2107 : Coverage 2107 2108 := checkList_sound (ws:=[(582,4678,582,4678)]) (by simpa only [checkList, Bool.and_true] using cases2107)
private theorem w2108_0 : checkWitness 2108 false false 8933 = true := by decide +kernel
private theorem w2108_2 : checkWitness 2108 true false 8929 = true := by decide +kernel
private theorem cases2108 : checkFour 2108 (8933,0,8929,0) = true := by
  simp only [checkFour, w2108_0, w2108_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2108 : Coverage 2108 2109 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases2108)
private theorem w2109_0 : checkWitness 2109 false false 8964 = true := by decide +kernel
private theorem w2109_2 : checkWitness 2109 true false 8955 = true := by decide +kernel
private theorem cases2109 : checkFour 2109 (8964,0,8955,0) = true := by
  simp only [checkFour, w2109_0, w2109_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2109 : Coverage 2109 2110 := checkList_sound (ws:=[(8964,0,8955,0)]) (by simpa only [checkList, Bool.and_true] using cases2109)
private theorem w2110_0 : checkWitness 2110 false false 100 = true := by decide +kernel
private theorem w2110_2 : checkWitness 2110 true false 100 = true := by decide +kernel
private theorem cases2110 : checkFour 2110 (100,0,100,0) = true := by
  simp only [checkFour, w2110_0, w2110_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2110 : Coverage 2110 2111 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases2110)
private theorem w2111_0 : checkWitness 2111 false false 678 = true := by decide +kernel
private theorem w2111_1 : checkWitness 2111 false true 4770 = true := by decide +kernel
private theorem w2111_2 : checkWitness 2111 true false 669 = true := by decide +kernel
private theorem w2111_3 : checkWitness 2111 true true 4761 = true := by decide +kernel
private theorem cases2111 : checkFour 2111 (678,4770,669,4761) = true := by
  simp only [checkFour, w2111_0, w2111_1, w2111_2, w2111_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2111 : Coverage 2111 2112 := checkList_sound (ws:=[(678,4770,669,4761)]) (by simpa only [checkList, Bool.and_true] using cases2111)
theorem cover2080 : Coverage 2080 2112 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2080 one2081) (Coverage.join one2082 one2083)) (Coverage.join (Coverage.join one2084 one2085) (Coverage.join one2086 one2087))) (Coverage.join (Coverage.join (Coverage.join one2088 one2089) (Coverage.join one2090 one2091)) (Coverage.join (Coverage.join one2092 one2093) (Coverage.join one2094 one2095)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2096 one2097) (Coverage.join one2098 one2099)) (Coverage.join (Coverage.join one2100 one2101) (Coverage.join one2102 one2103))) (Coverage.join (Coverage.join (Coverage.join one2104 one2105) (Coverage.join one2106 one2107)) (Coverage.join (Coverage.join one2108 one2109) (Coverage.join one2110 one2111)))))
end NF180PA.Symbolic
