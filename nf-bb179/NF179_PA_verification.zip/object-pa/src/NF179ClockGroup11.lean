import NF179ClockBase
namespace NF180PA.Clock
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part2816 : Covers 2816 2832 := block_sound (lo:=2816) (n:=16) (by decide +kernel)
private theorem part2832 : Covers 2832 2848 := block_sound (lo:=2832) (n:=16) (by decide +kernel)
private theorem part2848 : Covers 2848 2864 := block_sound (lo:=2848) (n:=16) (by decide +kernel)
private theorem part2864 : Covers 2864 2880 := block_sound (lo:=2864) (n:=16) (by decide +kernel)
private theorem part2880 : Covers 2880 2896 := block_sound (lo:=2880) (n:=16) (by decide +kernel)
private theorem part2896 : Covers 2896 2912 := block_sound (lo:=2896) (n:=16) (by decide +kernel)
private theorem part2912 : Covers 2912 2928 := block_sound (lo:=2912) (n:=16) (by decide +kernel)
private theorem part2928 : Covers 2928 2944 := block_sound (lo:=2928) (n:=16) (by decide +kernel)
private theorem part2944 : Covers 2944 2960 := block_sound (lo:=2944) (n:=16) (by decide +kernel)
private theorem part2960 : Covers 2960 2970 := block_sound (lo:=2960) (n:=10) (by decide +kernel)
theorem group2816 : Covers 2816 2970 := (Covers.join (Covers.join (Covers.join part2816 part2832) (Covers.join part2848 (Covers.join part2864 part2880))) (Covers.join (Covers.join part2896 part2912) (Covers.join part2928 (Covers.join part2944 part2960))))
end NF180PA.Clock
