import NF180PAModelSearch
import NF180PATapeAll
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
namespace NF180PA
/-- The literal table's internally coded halt is equivalent to a ranked refutation in each model of PA. -/
theorem model_refutation {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    (V ⊧/![] H180) ↔ NF181PA.Pool.Pr (∅ : V) goal :=
  model_refutation_of_coverage Symbolic.literal_table_coverage
end NF180PA
#print axioms NF180PA.model_refutation
