import NF180PAShiftPrefix
import NF180PAWarm
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.RegisterSource (config address vector)
namespace NF180PA.Shift
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxRecDepth 200000
set_option maxHeartbeats 0

private theorem local_progress {p : V} (h : ready p) (r : V) : Local p r := by
  rcases h with ⟨lt|stop,n2⟩
  · obtain ⟨i,rfl⟩ := eq_fin_of_lt_nat (n:=2971) lt
    by_cases hx : i.val=1 ∨ 10≤i.val
    · exact exterior i hx (List.all_eq_true.mp all_exterior i.val (List.mem_range.mpr i.isLt)) r
    · have n1 : i.val≠1 := fun e => hx (Or.inl e)
      have n2' : i.val≠2 := fun e => n2 (by exact_mod_cast e)
      exact small (by omega) n1 n2' r
  · subst p; exact terminal r

private theorem terminal_at_map {p : V} (h : ready p) (r : V) :
    address (image p r)=4095 ↔ p=4095 := by
  simp only [image,RegisterSource.address_config]
  unfold location
  rcases h.1 with lt|eq
  · have ne : p≠4095 := (lt_trans lt (by norm_num)).ne
    have less : p-1 < 4095 := lt_of_le_of_lt tsub_le_self (lt_trans lt (by norm_num))
    by_cases pr : p≤1 ∨ p=7 ∨ p=8 ∨ p=4095
    · rw [if_pos pr]
    · rw [if_neg pr]
      by_cases p9 : p=9
      · rw [if_pos p9]
        exact iff_of_false (by norm_num) ne
      · rw [if_neg p9]
        exact iff_of_false less.ne ne
  · subst p; norm_num

private theorem start_eq : image (0:V) (vector 4 0 0 0 0 0 0 0 0)=Registers.margin V := by
  norm_num [image,bump,biased,location,Registers.margin,vector]

/-- Both literal runs reach related checkpoints at or beyond any clock in the ambient PA model. -/
private theorem paired (n : V) :
    ∃ a b p r : V, n≤a ∧ n≤b ∧ ready p ∧ Register181.run a (Warm.initial V)=config p 0 r ∧
      Registers.run b=image p r := by
  induction n using modelInduct with
  | defP => unfold Warm.initial; definability
  | zero =>
    refine ⟨0,0,0,vector 4 0 0 0 0 0 0 0 0,le_rfl,le_rfl,by norm_num [ready],?_,?_⟩
    · simp [Warm.initial]
    · simpa using (start_eq (V:=V)).symm
  | step n ih =>
    obtain ⟨a,b,p,r,na,nb,ok,aa,bb⟩ := ih
    obtain ⟨i,j,q,s,ipos,jpos,ok',oo,nn⟩ := local_progress ok r
    refine ⟨a+i,b+j,q,s,succ_le_iff_lt.mpr (lt_of_le_of_lt na (lt_add_of_pos_right _ ipos)),
      succ_le_iff_lt.mpr (lt_of_le_of_lt nb (lt_add_of_pos_right _ jpos)),ok',?_,?_⟩
    · rw [Register181.run_add,aa]; exact oo
    · change iterate Registers.next (b+j) (Registers.margin V)=_
      rw [iterate_add]; exact (congrArg (iterate Registers.next j) bb).trans nn

private theorem old_stopped {c d : V} (cd : c≤d)
    (h : address (Register181.run c (Warm.initial V))=4095) :
    address (Register181.run d (Warm.initial V))=4095 := by
  obtain ⟨u,rfl⟩ := exists_add_of_le cd
  clear cd
  rw [Register181.run_add]
  induction u using modelInduct with
  | defP => unfold Warm.initial; definability
  | zero => simpa using h
  | step t ih => rw [Register181.run_succ]; exact NF181PA.Registers.next_terminal _ ih

private theorem new_stopped {c d : V} (cd : c≤d)
    (h : address (Registers.run c)=4095) : address (Registers.run d)=4095 := by
  obtain ⟨u,rfl⟩ := exists_add_of_le cd
  clear cd
  change address (iterate Registers.next (c+u) (Registers.margin V))=4095
  rw [iterate_add]
  induction u using modelInduct with
  | defP => definability
  | zero => simpa [Registers.run] using h
  | step t ih => rw [iterate_succ]; exact Registers.next_terminal _ ih

theorem equivalent_source_halt :
    (∃ t : V, address (Registers.run t)=4095) ↔ Register181.sourceHalts (Warm.initial V) := by
  constructor
  · rintro ⟨t,ht⟩
    obtain ⟨a,b,p,r,_,tb,hp,old,new⟩ := paired t
    have e := new_stopped tb ht
    rw [new] at e
    exact ⟨a,by rw [old,RegisterSource.address_config,(terminal_at_map hp r).mp e]⟩
  · rintro ⟨t,ht⟩
    obtain ⟨a,b,p,r,ta,_,hp,old,new⟩ := paired t
    have e := old_stopped ta ht
    rw [old,RegisterSource.address_config] at e
    exact ⟨b,by rw [new]; exact (terminal_at_map hp r).mpr e⟩

/-- The new register run reaches the halt address exactly when the internal NF proof pool derives the goal. -/
theorem sourceHalt_iff_pool :
    (∃ t : V, address (Registers.run t)=4095) ↔ NF181PA.Pool.Pr (∅ : V) goal :=
  equivalent_source_halt.trans Warm.epoch_four_iff_pool
end NF180PA.Shift
#print axioms NF180PA.Shift.sourceHalt_iff_pool
