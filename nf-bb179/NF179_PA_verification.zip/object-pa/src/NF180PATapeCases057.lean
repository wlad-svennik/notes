import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1824_0 : checkWitness 1824 false false 616 = true := by decide +kernel
private theorem w1824_1 : checkWitness 1824 false true 4712 = true := by decide +kernel
private theorem w1824_2 : checkWitness 1824 true false 607 = true := by decide +kernel
private theorem w1824_3 : checkWitness 1824 true true 4703 = true := by decide +kernel
private theorem cases1824 : checkFour 1824 (616,4712,607,4703) = true := by
  simp only [checkFour, w1824_0, w1824_1, w1824_2, w1824_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1824 : Coverage 1824 1825 := checkList_sound (ws:=[(616,4712,607,4703)]) (by simpa only [checkList, Bool.and_true] using cases1824)
private theorem w1825_0 : checkWitness 1825 false false 176 = true := by decide +kernel
private theorem w1825_2 : checkWitness 1825 true false 176 = true := by decide +kernel
private theorem cases1825 : checkFour 1825 (176,0,176,0) = true := by
  simp only [checkFour, w1825_0, w1825_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1825 : Coverage 1825 1826 := checkList_sound (ws:=[(176,0,176,0)]) (by simpa only [checkList, Bool.and_true] using cases1825)
private theorem w1826_0 : checkWitness 1826 false false 565 = true := by decide +kernel
private theorem w1826_1 : checkWitness 1826 false true 4653 = true := by decide +kernel
private theorem w1826_2 : checkWitness 1826 true false 565 = true := by decide +kernel
private theorem w1826_3 : checkWitness 1826 true true 4653 = true := by decide +kernel
private theorem cases1826 : checkFour 1826 (565,4653,565,4653) = true := by
  simp only [checkFour, w1826_0, w1826_1, w1826_2, w1826_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1826 : Coverage 1826 1827 := checkList_sound (ws:=[(565,4653,565,4653)]) (by simpa only [checkList, Bool.and_true] using cases1826)
private theorem w1827_0 : checkWitness 1827 false false 8898 = true := by decide +kernel
private theorem w1827_2 : checkWitness 1827 true false 8889 = true := by decide +kernel
private theorem cases1827 : checkFour 1827 (8898,0,8889,0) = true := by
  simp only [checkFour, w1827_0, w1827_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1827 : Coverage 1827 1828 := checkList_sound (ws:=[(8898,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1827)
private theorem w1828_0 : checkWitness 1828 false false 84 = true := by decide +kernel
private theorem w1828_2 : checkWitness 1828 true false 84 = true := by decide +kernel
private theorem cases1828 : checkFour 1828 (84,0,84,0) = true := by
  simp only [checkFour, w1828_0, w1828_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1828 : Coverage 1828 1829 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1828)
private theorem w1829_0 : checkWitness 1829 false false 76 = true := by decide +kernel
private theorem w1829_2 : checkWitness 1829 true false 76 = true := by decide +kernel
private theorem cases1829 : checkFour 1829 (76,0,76,0) = true := by
  simp only [checkFour, w1829_0, w1829_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1829 : Coverage 1829 1830 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1829)
private theorem w1830_0 : checkWitness 1830 false false 565 = true := by decide +kernel
private theorem w1830_1 : checkWitness 1830 false true 4657 = true := by decide +kernel
private theorem w1830_2 : checkWitness 1830 true false 565 = true := by decide +kernel
private theorem w1830_3 : checkWitness 1830 true true 4657 = true := by decide +kernel
private theorem cases1830 : checkFour 1830 (565,4657,565,4657) = true := by
  simp only [checkFour, w1830_0, w1830_1, w1830_2, w1830_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1830 : Coverage 1830 1831 := checkList_sound (ws:=[(565,4657,565,4657)]) (by simpa only [checkList, Bool.and_true] using cases1830)
private theorem w1831_0 : checkWitness 1831 false false 8840 = true := by decide +kernel
private theorem w1831_2 : checkWitness 1831 true false 8836 = true := by decide +kernel
private theorem cases1831 : checkFour 1831 (8840,0,8836,0) = true := by
  simp only [checkFour, w1831_0, w1831_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1831 : Coverage 1831 1832 := checkList_sound (ws:=[(8840,0,8836,0)]) (by simpa only [checkList, Bool.and_true] using cases1831)
private theorem w1832_0 : checkWitness 1832 false false 76 = true := by decide +kernel
private theorem w1832_2 : checkWitness 1832 true false 76 = true := by decide +kernel
private theorem cases1832 : checkFour 1832 (76,0,76,0) = true := by
  simp only [checkFour, w1832_0, w1832_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1832 : Coverage 1832 1833 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1832)
private theorem w1833_0 : checkWitness 1833 false false 524 = true := by decide +kernel
private theorem w1833_1 : checkWitness 1833 false true 4620 = true := by decide +kernel
private theorem w1833_2 : checkWitness 1833 true false 524 = true := by decide +kernel
private theorem w1833_3 : checkWitness 1833 true true 4620 = true := by decide +kernel
private theorem cases1833 : checkFour 1833 (524,4620,524,4620) = true := by
  simp only [checkFour, w1833_0, w1833_1, w1833_2, w1833_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1833 : Coverage 1833 1834 := checkList_sound (ws:=[(524,4620,524,4620)]) (by simpa only [checkList, Bool.and_true] using cases1833)
private theorem w1834_0 : checkWitness 1834 false false 8875 = true := by decide +kernel
private theorem w1834_2 : checkWitness 1834 true false 8871 = true := by decide +kernel
private theorem cases1834 : checkFour 1834 (8875,0,8871,0) = true := by
  simp only [checkFour, w1834_0, w1834_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1834 : Coverage 1834 1835 := checkList_sound (ws:=[(8875,0,8871,0)]) (by simpa only [checkList, Bool.and_true] using cases1834)
private theorem w1835_0 : checkWitness 1835 false false 8906 = true := by decide +kernel
private theorem w1835_2 : checkWitness 1835 true false 8897 = true := by decide +kernel
private theorem cases1835 : checkFour 1835 (8906,0,8897,0) = true := by
  simp only [checkFour, w1835_0, w1835_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1835 : Coverage 1835 1836 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1835)
private theorem w1836_0 : checkWitness 1836 false false 94 = true := by decide +kernel
private theorem w1836_2 : checkWitness 1836 true false 94 = true := by decide +kernel
private theorem cases1836 : checkFour 1836 (94,0,94,0) = true := by
  simp only [checkFour, w1836_0, w1836_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1836 : Coverage 1836 1837 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1836)
private theorem w1837_0 : checkWitness 1837 false false 620 = true := by decide +kernel
private theorem w1837_1 : checkWitness 1837 false true 4712 = true := by decide +kernel
private theorem w1837_2 : checkWitness 1837 true false 611 = true := by decide +kernel
private theorem w1837_3 : checkWitness 1837 true true 4703 = true := by decide +kernel
private theorem cases1837 : checkFour 1837 (620,4712,611,4703) = true := by
  simp only [checkFour, w1837_0, w1837_1, w1837_2, w1837_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1837 : Coverage 1837 1838 := checkList_sound (ws:=[(620,4712,611,4703)]) (by simpa only [checkList, Bool.and_true] using cases1837)
private theorem w1838_0 : checkWitness 1838 false false 8871 = true := by decide +kernel
private theorem w1838_2 : checkWitness 1838 true false 8867 = true := by decide +kernel
private theorem cases1838 : checkFour 1838 (8871,0,8867,0) = true := by
  simp only [checkFour, w1838_0, w1838_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1838 : Coverage 1838 1839 := checkList_sound (ws:=[(8871,0,8867,0)]) (by simpa only [checkList, Bool.and_true] using cases1838)
private theorem w1839_0 : checkWitness 1839 false false 614 = true := by decide +kernel
private theorem w1839_1 : checkWitness 1839 false true 4706 = true := by decide +kernel
private theorem w1839_2 : checkWitness 1839 true false 605 = true := by decide +kernel
private theorem w1839_3 : checkWitness 1839 true true 4697 = true := by decide +kernel
private theorem cases1839 : checkFour 1839 (614,4706,605,4697) = true := by
  simp only [checkFour, w1839_0, w1839_1, w1839_2, w1839_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1839 : Coverage 1839 1840 := checkList_sound (ws:=[(614,4706,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases1839)
private theorem w1840_0 : checkWitness 1840 false false 8842 = true := by decide +kernel
private theorem w1840_2 : checkWitness 1840 true false 8838 = true := by decide +kernel
private theorem cases1840 : checkFour 1840 (8842,0,8838,0) = true := by
  simp only [checkFour, w1840_0, w1840_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1840 : Coverage 1840 1841 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1840)
private theorem w1841_0 : checkWitness 1841 false false 82 = true := by decide +kernel
private theorem w1841_2 : checkWitness 1841 true false 82 = true := by decide +kernel
private theorem cases1841 : checkFour 1841 (82,0,82,0) = true := by
  simp only [checkFour, w1841_0, w1841_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1841 : Coverage 1841 1842 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1841)
private theorem w1842_0 : checkWitness 1842 false false 74 = true := by decide +kernel
private theorem w1842_2 : checkWitness 1842 true false 74 = true := by decide +kernel
private theorem cases1842 : checkFour 1842 (74,0,74,0) = true := by
  simp only [checkFour, w1842_0, w1842_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1842 : Coverage 1842 1843 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1842)
private theorem w1843_0 : checkWitness 1843 false false 575 = true := by decide +kernel
private theorem w1843_1 : checkWitness 1843 false true 4663 = true := by decide +kernel
private theorem w1843_2 : checkWitness 1843 true false 575 = true := by decide +kernel
private theorem w1843_3 : checkWitness 1843 true true 4663 = true := by decide +kernel
private theorem cases1843 : checkFour 1843 (575,4663,575,4663) = true := by
  simp only [checkFour, w1843_0, w1843_1, w1843_2, w1843_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1843 : Coverage 1843 1844 := checkList_sound (ws:=[(575,4663,575,4663)]) (by simpa only [checkList, Bool.and_true] using cases1843)
private theorem w1844_0 : checkWitness 1844 false false 8858 = true := by decide +kernel
private theorem w1844_2 : checkWitness 1844 true false 8854 = true := by decide +kernel
private theorem cases1844 : checkFour 1844 (8858,0,8854,0) = true := by
  simp only [checkFour, w1844_0, w1844_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1844 : Coverage 1844 1845 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1844)
private theorem w1845_0 : checkWitness 1845 false false 8854 = true := by decide +kernel
private theorem w1845_2 : checkWitness 1845 true false 8850 = true := by decide +kernel
private theorem cases1845 : checkFour 1845 (8854,0,8850,0) = true := by
  simp only [checkFour, w1845_0, w1845_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1845 : Coverage 1845 1846 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases1845)
private theorem w1846_0 : checkWitness 1846 false false 88 = true := by decide +kernel
private theorem w1846_2 : checkWitness 1846 true false 88 = true := by decide +kernel
private theorem cases1846 : checkFour 1846 (88,0,88,0) = true := by
  simp only [checkFour, w1846_0, w1846_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1846 : Coverage 1846 1847 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1846)
private theorem w1847_0 : checkWitness 1847 false false 8866 = true := by decide +kernel
private theorem w1847_2 : checkWitness 1847 true false 8862 = true := by decide +kernel
private theorem cases1847 : checkFour 1847 (8866,0,8862,0) = true := by
  simp only [checkFour, w1847_0, w1847_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1847 : Coverage 1847 1848 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases1847)
private theorem w1848_0 : checkWitness 1848 false false 488 = true := by decide +kernel
private theorem w1848_1 : checkWitness 1848 false true 4584 = true := by decide +kernel
private theorem w1848_2 : checkWitness 1848 true false 488 = true := by decide +kernel
private theorem w1848_3 : checkWitness 1848 true true 4584 = true := by decide +kernel
private theorem cases1848 : checkFour 1848 (488,4584,488,4584) = true := by
  simp only [checkFour, w1848_0, w1848_1, w1848_2, w1848_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1848 : Coverage 1848 1849 := checkList_sound (ws:=[(488,4584,488,4584)]) (by simpa only [checkList, Bool.and_true] using cases1848)
private theorem w1849_0 : checkWitness 1849 false false 8891 = true := by decide +kernel
private theorem w1849_2 : checkWitness 1849 true false 8887 = true := by decide +kernel
private theorem cases1849 : checkFour 1849 (8891,0,8887,0) = true := by
  simp only [checkFour, w1849_0, w1849_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1849 : Coverage 1849 1850 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases1849)
private theorem w1850_0 : checkWitness 1850 false false 620 = true := by decide +kernel
private theorem w1850_1 : checkWitness 1850 false true 4716 = true := by decide +kernel
private theorem w1850_2 : checkWitness 1850 true false 611 = true := by decide +kernel
private theorem w1850_3 : checkWitness 1850 true true 4707 = true := by decide +kernel
private theorem cases1850 : checkFour 1850 (620,4716,611,4707) = true := by
  simp only [checkFour, w1850_0, w1850_1, w1850_2, w1850_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1850 : Coverage 1850 1851 := checkList_sound (ws:=[(620,4716,611,4707)]) (by simpa only [checkList, Bool.and_true] using cases1850)
private theorem w1851_0 : checkWitness 1851 false false 178 = true := by decide +kernel
private theorem w1851_2 : checkWitness 1851 true false 178 = true := by decide +kernel
private theorem cases1851 : checkFour 1851 (178,0,178,0) = true := by
  simp only [checkFour, w1851_0, w1851_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1851 : Coverage 1851 1852 := checkList_sound (ws:=[(178,0,178,0)]) (by simpa only [checkList, Bool.and_true] using cases1851)
private theorem w1852_0 : checkWitness 1852 false false 569 = true := by decide +kernel
private theorem w1852_1 : checkWitness 1852 false true 4657 = true := by decide +kernel
private theorem w1852_2 : checkWitness 1852 true false 569 = true := by decide +kernel
private theorem w1852_3 : checkWitness 1852 true true 4657 = true := by decide +kernel
private theorem cases1852 : checkFour 1852 (569,4657,569,4657) = true := by
  simp only [checkFour, w1852_0, w1852_1, w1852_2, w1852_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1852 : Coverage 1852 1853 := checkList_sound (ws:=[(569,4657,569,4657)]) (by simpa only [checkList, Bool.and_true] using cases1852)
private theorem w1853_0 : checkWitness 1853 false false 8902 = true := by decide +kernel
private theorem w1853_2 : checkWitness 1853 true false 8893 = true := by decide +kernel
private theorem cases1853 : checkFour 1853 (8902,0,8893,0) = true := by
  simp only [checkFour, w1853_0, w1853_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1853 : Coverage 1853 1854 := checkList_sound (ws:=[(8902,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases1853)
private theorem w1854_0 : checkWitness 1854 false false 82 = true := by decide +kernel
private theorem w1854_2 : checkWitness 1854 true false 82 = true := by decide +kernel
private theorem cases1854 : checkFour 1854 (82,0,82,0) = true := by
  simp only [checkFour, w1854_0, w1854_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1854 : Coverage 1854 1855 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1854)
private theorem w1855_0 : checkWitness 1855 false false 74 = true := by decide +kernel
private theorem w1855_2 : checkWitness 1855 true false 74 = true := by decide +kernel
private theorem cases1855 : checkFour 1855 (74,0,74,0) = true := by
  simp only [checkFour, w1855_0, w1855_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1855 : Coverage 1855 1856 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1855)
theorem cover1824 : Coverage 1824 1856 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1824 one1825) (Coverage.join one1826 one1827)) (Coverage.join (Coverage.join one1828 one1829) (Coverage.join one1830 one1831))) (Coverage.join (Coverage.join (Coverage.join one1832 one1833) (Coverage.join one1834 one1835)) (Coverage.join (Coverage.join one1836 one1837) (Coverage.join one1838 one1839)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1840 one1841) (Coverage.join one1842 one1843)) (Coverage.join (Coverage.join one1844 one1845) (Coverage.join one1846 one1847))) (Coverage.join (Coverage.join (Coverage.join one1848 one1849) (Coverage.join one1850 one1851)) (Coverage.join (Coverage.join one1852 one1853) (Coverage.join one1854 one1855)))))
end NF180PA.Symbolic
