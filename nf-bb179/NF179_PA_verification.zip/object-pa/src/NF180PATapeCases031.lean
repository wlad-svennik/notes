import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w992_0 : checkWitness 992 false false 76 = true := by decide +kernel
private theorem w992_2 : checkWitness 992 true false 76 = true := by decide +kernel
private theorem cases992 : checkFour 992 (76,0,76,0) = true := by
  simp only [checkFour, w992_0, w992_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one992 : Coverage 992 993 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases992)
private theorem w993_0 : checkWitness 993 false false 502 = true := by decide +kernel
private theorem w993_1 : checkWitness 993 false true 4598 = true := by decide +kernel
private theorem w993_2 : checkWitness 993 true false 502 = true := by decide +kernel
private theorem w993_3 : checkWitness 993 true true 4598 = true := by decide +kernel
private theorem cases993 : checkFour 993 (502,4598,502,4598) = true := by
  simp only [checkFour, w993_0, w993_1, w993_2, w993_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one993 : Coverage 993 994 := checkList_sound (ws:=[(502,4598,502,4598)]) (by simpa only [checkList, Bool.and_true] using cases993)
private theorem w994_0 : checkWitness 994 false false 8876 = true := by decide +kernel
private theorem w994_2 : checkWitness 994 true false 8872 = true := by decide +kernel
private theorem cases994 : checkFour 994 (8876,0,8872,0) = true := by
  simp only [checkFour, w994_0, w994_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one994 : Coverage 994 995 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases994)
private theorem w995_0 : checkWitness 995 false false 80 = true := by decide +kernel
private theorem w995_2 : checkWitness 995 true false 80 = true := by decide +kernel
private theorem cases995 : checkFour 995 (80,0,80,0) = true := by
  simp only [checkFour, w995_0, w995_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one995 : Coverage 995 996 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases995)
private theorem w996_0 : checkWitness 996 false false 544 = true := by decide +kernel
private theorem w996_1 : checkWitness 996 false true 4640 = true := by decide +kernel
private theorem w996_2 : checkWitness 996 true false 544 = true := by decide +kernel
private theorem w996_3 : checkWitness 996 true true 4640 = true := by decide +kernel
private theorem cases996 : checkFour 996 (544,4640,544,4640) = true := by
  simp only [checkFour, w996_0, w996_1, w996_2, w996_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one996 : Coverage 996 997 := checkList_sound (ws:=[(544,4640,544,4640)]) (by simpa only [checkList, Bool.and_true] using cases996)
private theorem w997_0 : checkWitness 997 false false 8895 = true := by decide +kernel
private theorem w997_2 : checkWitness 997 true false 8891 = true := by decide +kernel
private theorem cases997 : checkFour 997 (8895,0,8891,0) = true := by
  simp only [checkFour, w997_0, w997_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one997 : Coverage 997 998 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases997)
private theorem w998_0 : checkWitness 998 false false 8926 = true := by decide +kernel
private theorem w998_2 : checkWitness 998 true false 8917 = true := by decide +kernel
private theorem cases998 : checkFour 998 (8926,0,8917,0) = true := by
  simp only [checkFour, w998_0, w998_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one998 : Coverage 998 999 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases998)
private theorem w999_0 : checkWitness 999 false false 104 = true := by decide +kernel
private theorem w999_2 : checkWitness 999 true false 104 = true := by decide +kernel
private theorem cases999 : checkFour 999 (104,0,104,0) = true := by
  simp only [checkFour, w999_0, w999_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one999 : Coverage 999 1000 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases999)
private theorem w1000_0 : checkWitness 1000 false false 640 = true := by decide +kernel
private theorem w1000_1 : checkWitness 1000 false true 4732 = true := by decide +kernel
private theorem w1000_2 : checkWitness 1000 true false 631 = true := by decide +kernel
private theorem w1000_3 : checkWitness 1000 true true 4723 = true := by decide +kernel
private theorem cases1000 : checkFour 1000 (640,4732,631,4723) = true := by
  simp only [checkFour, w1000_0, w1000_1, w1000_2, w1000_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1000 : Coverage 1000 1001 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases1000)
private theorem w1001_0 : checkWitness 1001 false false 8891 = true := by decide +kernel
private theorem w1001_2 : checkWitness 1001 true false 8887 = true := by decide +kernel
private theorem cases1001 : checkFour 1001 (8891,0,8887,0) = true := by
  simp only [checkFour, w1001_0, w1001_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1001 : Coverage 1001 1002 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases1001)
private theorem w1002_0 : checkWitness 1002 false false 634 = true := by decide +kernel
private theorem w1002_1 : checkWitness 1002 false true 4726 = true := by decide +kernel
private theorem w1002_2 : checkWitness 1002 true false 625 = true := by decide +kernel
private theorem w1002_3 : checkWitness 1002 true true 4717 = true := by decide +kernel
private theorem cases1002 : checkFour 1002 (634,4726,625,4717) = true := by
  simp only [checkFour, w1002_0, w1002_1, w1002_2, w1002_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1002 : Coverage 1002 1003 := checkList_sound (ws:=[(634,4726,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases1002)
private theorem w1003_0 : checkWitness 1003 false false 8862 = true := by decide +kernel
private theorem w1003_2 : checkWitness 1003 true false 8858 = true := by decide +kernel
private theorem cases1003 : checkFour 1003 (8862,0,8858,0) = true := by
  simp only [checkFour, w1003_0, w1003_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1003 : Coverage 1003 1004 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases1003)
private theorem w1004_0 : checkWitness 1004 false false 92 = true := by decide +kernel
private theorem w1004_2 : checkWitness 1004 true false 92 = true := by decide +kernel
private theorem cases1004 : checkFour 1004 (92,0,92,0) = true := by
  simp only [checkFour, w1004_0, w1004_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1004 : Coverage 1004 1005 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1004)
private theorem w1005_0 : checkWitness 1005 false false 84 = true := by decide +kernel
private theorem w1005_2 : checkWitness 1005 true false 84 = true := by decide +kernel
private theorem cases1005 : checkFour 1005 (84,0,84,0) = true := by
  simp only [checkFour, w1005_0, w1005_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1005 : Coverage 1005 1006 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1005)
private theorem w1006_0 : checkWitness 1006 false false 587 = true := by decide +kernel
private theorem w1006_1 : checkWitness 1006 false true 4671 = true := by decide +kernel
private theorem w1006_2 : checkWitness 1006 true false 587 = true := by decide +kernel
private theorem w1006_3 : checkWitness 1006 true true 4671 = true := by decide +kernel
private theorem cases1006 : checkFour 1006 (587,4671,587,4671) = true := by
  simp only [checkFour, w1006_0, w1006_1, w1006_2, w1006_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1006 : Coverage 1006 1007 := checkList_sound (ws:=[(587,4671,587,4671)]) (by simpa only [checkList, Bool.and_true] using cases1006)
private theorem w1007_0 : checkWitness 1007 false false 8854 = true := by decide +kernel
private theorem w1007_2 : checkWitness 1007 true false 8850 = true := by decide +kernel
private theorem cases1007 : checkFour 1007 (8854,0,8850,0) = true := by
  simp only [checkFour, w1007_0, w1007_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1007 : Coverage 1007 1008 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases1007)
private theorem w1008_0 : checkWitness 1008 false false 84 = true := by decide +kernel
private theorem w1008_2 : checkWitness 1008 true false 84 = true := by decide +kernel
private theorem cases1008 : checkFour 1008 (84,0,84,0) = true := by
  simp only [checkFour, w1008_0, w1008_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1008 : Coverage 1008 1009 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1008)
private theorem w1009_0 : checkWitness 1009 false false 631 = true := by decide +kernel
private theorem w1009_1 : checkWitness 1009 false true 4723 = true := by decide +kernel
private theorem w1009_2 : checkWitness 1009 true false 622 = true := by decide +kernel
private theorem w1009_3 : checkWitness 1009 true true 4714 = true := by decide +kernel
private theorem cases1009 : checkFour 1009 (631,4723,622,4714) = true := by
  simp only [checkFour, w1009_0, w1009_1, w1009_2, w1009_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1009 : Coverage 1009 1010 := checkList_sound (ws:=[(631,4723,622,4714)]) (by simpa only [checkList, Bool.and_true] using cases1009)
private theorem w1010_0 : checkWitness 1010 false false 8928 = true := by decide +kernel
private theorem w1010_2 : checkWitness 1010 true false 8919 = true := by decide +kernel
private theorem cases1010 : checkFour 1010 (8928,0,8919,0) = true := by
  simp only [checkFour, w1010_0, w1010_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1010 : Coverage 1010 1011 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases1010)
private theorem w1011_0 : checkWitness 1011 false false 8874 = true := by decide +kernel
private theorem w1011_2 : checkWitness 1011 true false 8870 = true := by decide +kernel
private theorem cases1011 : checkFour 1011 (8874,0,8870,0) = true := by
  simp only [checkFour, w1011_0, w1011_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1011 : Coverage 1011 1012 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases1011)
private theorem w1012_0 : checkWitness 1012 false false 88 = true := by decide +kernel
private theorem w1012_2 : checkWitness 1012 true false 88 = true := by decide +kernel
private theorem cases1012 : checkFour 1012 (88,0,88,0) = true := by
  simp only [checkFour, w1012_0, w1012_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1012 : Coverage 1012 1013 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1012)
private theorem w1013_0 : checkWitness 1013 false false 654 = true := by decide +kernel
private theorem w1013_1 : checkWitness 1013 false true 4746 = true := by decide +kernel
private theorem w1013_2 : checkWitness 1013 true false 645 = true := by decide +kernel
private theorem w1013_3 : checkWitness 1013 true true 4737 = true := by decide +kernel
private theorem cases1013 : checkFour 1013 (654,4746,645,4737) = true := by
  simp only [checkFour, w1013_0, w1013_1, w1013_2, w1013_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1013 : Coverage 1013 1014 := checkList_sound (ws:=[(654,4746,645,4737)]) (by simpa only [checkList, Bool.and_true] using cases1013)
private theorem w1014_0 : checkWitness 1014 false false 8935 = true := by decide +kernel
private theorem w1014_2 : checkWitness 1014 true false 8926 = true := by decide +kernel
private theorem cases1014 : checkFour 1014 (8935,0,8926,0) = true := by
  simp only [checkFour, w1014_0, w1014_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1014 : Coverage 1014 1015 := checkList_sound (ws:=[(8935,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases1014)
private theorem w1015_0 : checkWitness 1015 false false 72 = true := by decide +kernel
private theorem w1015_2 : checkWitness 1015 true false 72 = true := by decide +kernel
private theorem cases1015 : checkFour 1015 (72,0,72,0) = true := by
  simp only [checkFour, w1015_0, w1015_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1015 : Coverage 1015 1016 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases1015)
private theorem w1016_0 : checkWitness 1016 false false 512 = true := by decide +kernel
private theorem w1016_1 : checkWitness 1016 false true 4608 = true := by decide +kernel
private theorem w1016_2 : checkWitness 1016 true false 512 = true := by decide +kernel
private theorem w1016_3 : checkWitness 1016 true true 4608 = true := by decide +kernel
private theorem cases1016 : checkFour 1016 (512,4608,512,4608) = true := by
  simp only [checkFour, w1016_0, w1016_1, w1016_2, w1016_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1016 : Coverage 1016 1017 := checkList_sound (ws:=[(512,4608,512,4608)]) (by simpa only [checkList, Bool.and_true] using cases1016)
private theorem w1017_0 : checkWitness 1017 false false 8915 = true := by decide +kernel
private theorem w1017_2 : checkWitness 1017 true false 8911 = true := by decide +kernel
private theorem cases1017 : checkFour 1017 (8915,0,8911,0) = true := by
  simp only [checkFour, w1017_0, w1017_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1017 : Coverage 1017 1018 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases1017)
private theorem w1018_0 : checkWitness 1018 false false 644 = true := by decide +kernel
private theorem w1018_1 : checkWitness 1018 false true 4740 = true := by decide +kernel
private theorem w1018_2 : checkWitness 1018 true false 635 = true := by decide +kernel
private theorem w1018_3 : checkWitness 1018 true true 4731 = true := by decide +kernel
private theorem cases1018 : checkFour 1018 (644,4740,635,4731) = true := by
  simp only [checkFour, w1018_0, w1018_1, w1018_2, w1018_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1018 : Coverage 1018 1019 := checkList_sound (ws:=[(644,4740,635,4731)]) (by simpa only [checkList, Bool.and_true] using cases1018)
private theorem w1019_0 : checkWitness 1019 false false 186 = true := by decide +kernel
private theorem w1019_2 : checkWitness 1019 true false 186 = true := by decide +kernel
private theorem cases1019 : checkFour 1019 (186,0,186,0) = true := by
  simp only [checkFour, w1019_0, w1019_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1019 : Coverage 1019 1020 := checkList_sound (ws:=[(186,0,186,0)]) (by simpa only [checkList, Bool.and_true] using cases1019)
private theorem w1020_0 : checkWitness 1020 false false 593 = true := by decide +kernel
private theorem w1020_1 : checkWitness 1020 false true 4681 = true := by decide +kernel
private theorem w1020_2 : checkWitness 1020 true false 593 = true := by decide +kernel
private theorem w1020_3 : checkWitness 1020 true true 4681 = true := by decide +kernel
private theorem cases1020 : checkFour 1020 (593,4681,593,4681) = true := by
  simp only [checkFour, w1020_0, w1020_1, w1020_2, w1020_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1020 : Coverage 1020 1021 := checkList_sound (ws:=[(593,4681,593,4681)]) (by simpa only [checkList, Bool.and_true] using cases1020)
private theorem w1021_0 : checkWitness 1021 false false 8926 = true := by decide +kernel
private theorem w1021_2 : checkWitness 1021 true false 8917 = true := by decide +kernel
private theorem cases1021 : checkFour 1021 (8926,0,8917,0) = true := by
  simp only [checkFour, w1021_0, w1021_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1021 : Coverage 1021 1022 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases1021)
private theorem w1022_0 : checkWitness 1022 false false 90 = true := by decide +kernel
private theorem w1022_2 : checkWitness 1022 true false 90 = true := by decide +kernel
private theorem cases1022 : checkFour 1022 (90,0,90,0) = true := by
  simp only [checkFour, w1022_0, w1022_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1022 : Coverage 1022 1023 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1022)
private theorem w1023_0 : checkWitness 1023 false false 82 = true := by decide +kernel
private theorem w1023_2 : checkWitness 1023 true false 82 = true := by decide +kernel
private theorem cases1023 : checkFour 1023 (82,0,82,0) = true := by
  simp only [checkFour, w1023_0, w1023_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1023 : Coverage 1023 1024 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1023)
theorem cover0992 : Coverage 992 1024 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one992 one993) (Coverage.join one994 one995)) (Coverage.join (Coverage.join one996 one997) (Coverage.join one998 one999))) (Coverage.join (Coverage.join (Coverage.join one1000 one1001) (Coverage.join one1002 one1003)) (Coverage.join (Coverage.join one1004 one1005) (Coverage.join one1006 one1007)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1008 one1009) (Coverage.join one1010 one1011)) (Coverage.join (Coverage.join one1012 one1013) (Coverage.join one1014 one1015))) (Coverage.join (Coverage.join (Coverage.join one1016 one1017) (Coverage.join one1018 one1019)) (Coverage.join (Coverage.join one1020 one1021) (Coverage.join one1022 one1023)))))
end NF180PA.Symbolic
