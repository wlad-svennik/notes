import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2304_0 : checkWitness 2304 false false 8911 = true := by decide +kernel
private theorem w2304_2 : checkWitness 2304 true false 8907 = true := by decide +kernel
private theorem cases2304 : checkFour 2304 (8911,0,8907,0) = true := by
  simp only [checkFour, w2304_0, w2304_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2304 : Coverage 2304 2305 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases2304)
private theorem w2305_0 : checkWitness 2305 false false 640 = true := by decide +kernel
private theorem w2305_1 : checkWitness 2305 false true 4736 = true := by decide +kernel
private theorem w2305_2 : checkWitness 2305 true false 631 = true := by decide +kernel
private theorem w2305_3 : checkWitness 2305 true true 4727 = true := by decide +kernel
private theorem cases2305 : checkFour 2305 (640,4736,631,4727) = true := by
  simp only [checkFour, w2305_0, w2305_1, w2305_2, w2305_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2305 : Coverage 2305 2306 := checkList_sound (ws:=[(640,4736,631,4727)]) (by simpa only [checkList, Bool.and_true] using cases2305)
private theorem w2306_0 : checkWitness 2306 false false 188 = true := by decide +kernel
private theorem w2306_2 : checkWitness 2306 true false 188 = true := by decide +kernel
private theorem cases2306 : checkFour 2306 (188,0,188,0) = true := by
  simp only [checkFour, w2306_0, w2306_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2306 : Coverage 2306 2307 := checkList_sound (ws:=[(188,0,188,0)]) (by simpa only [checkList, Bool.and_true] using cases2306)
private theorem w2307_0 : checkWitness 2307 false false 589 = true := by decide +kernel
private theorem w2307_1 : checkWitness 2307 false true 4677 = true := by decide +kernel
private theorem w2307_2 : checkWitness 2307 true false 589 = true := by decide +kernel
private theorem w2307_3 : checkWitness 2307 true true 4677 = true := by decide +kernel
private theorem cases2307 : checkFour 2307 (589,4677,589,4677) = true := by
  simp only [checkFour, w2307_0, w2307_1, w2307_2, w2307_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2307 : Coverage 2307 2308 := checkList_sound (ws:=[(589,4677,589,4677)]) (by simpa only [checkList, Bool.and_true] using cases2307)
private theorem w2308_0 : checkWitness 2308 false false 8922 = true := by decide +kernel
private theorem w2308_2 : checkWitness 2308 true false 8913 = true := by decide +kernel
private theorem cases2308 : checkFour 2308 (8922,0,8913,0) = true := by
  simp only [checkFour, w2308_0, w2308_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2308 : Coverage 2308 2309 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2308)
private theorem w2309_0 : checkWitness 2309 false false 72 = true := by decide +kernel
private theorem w2309_2 : checkWitness 2309 true false 72 = true := by decide +kernel
private theorem cases2309 : checkFour 2309 (72,0,72,0) = true := by
  simp only [checkFour, w2309_0, w2309_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2309 : Coverage 2309 2310 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2309)
private theorem w2310_0 : checkWitness 2310 false false 64 = true := by decide +kernel
private theorem w2310_2 : checkWitness 2310 true false 64 = true := by decide +kernel
private theorem cases2310 : checkFour 2310 (64,0,64,0) = true := by
  simp only [checkFour, w2310_0, w2310_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2310 : Coverage 2310 2311 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2310)
private theorem w2311_0 : checkWitness 2311 false false 589 = true := by decide +kernel
private theorem w2311_1 : checkWitness 2311 false true 4681 = true := by decide +kernel
private theorem w2311_2 : checkWitness 2311 true false 589 = true := by decide +kernel
private theorem w2311_3 : checkWitness 2311 true true 4681 = true := by decide +kernel
private theorem cases2311 : checkFour 2311 (589,4681,589,4681) = true := by
  simp only [checkFour, w2311_0, w2311_1, w2311_2, w2311_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2311 : Coverage 2311 2312 := checkList_sound (ws:=[(589,4681,589,4681)]) (by simpa only [checkList, Bool.and_true] using cases2311)
private theorem w2312_0 : checkWitness 2312 false false 8864 = true := by decide +kernel
private theorem w2312_2 : checkWitness 2312 true false 8860 = true := by decide +kernel
private theorem cases2312 : checkFour 2312 (8864,0,8860,0) = true := by
  simp only [checkFour, w2312_0, w2312_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2312 : Coverage 2312 2313 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases2312)
private theorem w2313_0 : checkWitness 2313 false false 64 = true := by decide +kernel
private theorem w2313_2 : checkWitness 2313 true false 64 = true := by decide +kernel
private theorem cases2313 : checkFour 2313 (64,0,64,0) = true := by
  simp only [checkFour, w2313_0, w2313_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2313 : Coverage 2313 2314 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2313)
private theorem w2314_0 : checkWitness 2314 false false 548 = true := by decide +kernel
private theorem w2314_1 : checkWitness 2314 false true 4644 = true := by decide +kernel
private theorem w2314_2 : checkWitness 2314 true false 548 = true := by decide +kernel
private theorem w2314_3 : checkWitness 2314 true true 4644 = true := by decide +kernel
private theorem cases2314 : checkFour 2314 (548,4644,548,4644) = true := by
  simp only [checkFour, w2314_0, w2314_1, w2314_2, w2314_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2314 : Coverage 2314 2315 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases2314)
private theorem w2315_0 : checkWitness 2315 false false 8899 = true := by decide +kernel
private theorem w2315_2 : checkWitness 2315 true false 8895 = true := by decide +kernel
private theorem cases2315 : checkFour 2315 (8899,0,8895,0) = true := by
  simp only [checkFour, w2315_0, w2315_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2315 : Coverage 2315 2316 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases2315)
private theorem w2316_0 : checkWitness 2316 false false 8930 = true := by decide +kernel
private theorem w2316_2 : checkWitness 2316 true false 8921 = true := by decide +kernel
private theorem cases2316 : checkFour 2316 (8930,0,8921,0) = true := by
  simp only [checkFour, w2316_0, w2316_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2316 : Coverage 2316 2317 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases2316)
private theorem w2317_0 : checkWitness 2317 false false 82 = true := by decide +kernel
private theorem w2317_2 : checkWitness 2317 true false 82 = true := by decide +kernel
private theorem cases2317 : checkFour 2317 (82,0,82,0) = true := by
  simp only [checkFour, w2317_0, w2317_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2317 : Coverage 2317 2318 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2317)
private theorem w2318_0 : checkWitness 2318 false false 644 = true := by decide +kernel
private theorem w2318_1 : checkWitness 2318 false true 4736 = true := by decide +kernel
private theorem w2318_2 : checkWitness 2318 true false 635 = true := by decide +kernel
private theorem w2318_3 : checkWitness 2318 true true 4727 = true := by decide +kernel
private theorem cases2318 : checkFour 2318 (644,4736,635,4727) = true := by
  simp only [checkFour, w2318_0, w2318_1, w2318_2, w2318_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2318 : Coverage 2318 2319 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases2318)
private theorem w2319_0 : checkWitness 2319 false false 8895 = true := by decide +kernel
private theorem w2319_2 : checkWitness 2319 true false 8891 = true := by decide +kernel
private theorem cases2319 : checkFour 2319 (8895,0,8891,0) = true := by
  simp only [checkFour, w2319_0, w2319_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2319 : Coverage 2319 2320 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases2319)
private theorem w2320_0 : checkWitness 2320 false false 638 = true := by decide +kernel
private theorem w2320_1 : checkWitness 2320 false true 4730 = true := by decide +kernel
private theorem w2320_2 : checkWitness 2320 true false 629 = true := by decide +kernel
private theorem w2320_3 : checkWitness 2320 true true 4721 = true := by decide +kernel
private theorem cases2320 : checkFour 2320 (638,4730,629,4721) = true := by
  simp only [checkFour, w2320_0, w2320_1, w2320_2, w2320_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2320 : Coverage 2320 2321 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases2320)
private theorem w2321_0 : checkWitness 2321 false false 8866 = true := by decide +kernel
private theorem w2321_2 : checkWitness 2321 true false 8862 = true := by decide +kernel
private theorem cases2321 : checkFour 2321 (8866,0,8862,0) = true := by
  simp only [checkFour, w2321_0, w2321_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2321 : Coverage 2321 2322 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases2321)
private theorem w2322_0 : checkWitness 2322 false false 70 = true := by decide +kernel
private theorem w2322_2 : checkWitness 2322 true false 70 = true := by decide +kernel
private theorem cases2322 : checkFour 2322 (70,0,70,0) = true := by
  simp only [checkFour, w2322_0, w2322_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2322 : Coverage 2322 2323 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2322)
private theorem w2323_0 : checkWitness 2323 false false 62 = true := by decide +kernel
private theorem w2323_2 : checkWitness 2323 true false 62 = true := by decide +kernel
private theorem cases2323 : checkFour 2323 (62,0,62,0) = true := by
  simp only [checkFour, w2323_0, w2323_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2323 : Coverage 2323 2324 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2323)
private theorem w2324_0 : checkWitness 2324 false false 599 = true := by decide +kernel
private theorem w2324_1 : checkWitness 2324 false true 4687 = true := by decide +kernel
private theorem w2324_2 : checkWitness 2324 true false 599 = true := by decide +kernel
private theorem w2324_3 : checkWitness 2324 true true 4687 = true := by decide +kernel
private theorem cases2324 : checkFour 2324 (599,4687,599,4687) = true := by
  simp only [checkFour, w2324_0, w2324_1, w2324_2, w2324_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2324 : Coverage 2324 2325 := checkList_sound (ws:=[(599,4687,599,4687)]) (by simpa only [checkList, Bool.and_true] using cases2324)
private theorem w2325_0 : checkWitness 2325 false false 8882 = true := by decide +kernel
private theorem w2325_2 : checkWitness 2325 true false 8878 = true := by decide +kernel
private theorem cases2325 : checkFour 2325 (8882,0,8878,0) = true := by
  simp only [checkFour, w2325_0, w2325_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2325 : Coverage 2325 2326 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases2325)
private theorem w2326_0 : checkWitness 2326 false false 8878 = true := by decide +kernel
private theorem w2326_2 : checkWitness 2326 true false 8874 = true := by decide +kernel
private theorem cases2326 : checkFour 2326 (8878,0,8874,0) = true := by
  simp only [checkFour, w2326_0, w2326_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2326 : Coverage 2326 2327 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases2326)
private theorem w2327_0 : checkWitness 2327 false false 76 = true := by decide +kernel
private theorem w2327_2 : checkWitness 2327 true false 76 = true := by decide +kernel
private theorem cases2327 : checkFour 2327 (76,0,76,0) = true := by
  simp only [checkFour, w2327_0, w2327_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2327 : Coverage 2327 2328 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2327)
private theorem w2328_0 : checkWitness 2328 false false 8890 = true := by decide +kernel
private theorem w2328_2 : checkWitness 2328 true false 8886 = true := by decide +kernel
private theorem cases2328 : checkFour 2328 (8890,0,8886,0) = true := by
  simp only [checkFour, w2328_0, w2328_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2328 : Coverage 2328 2329 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases2328)
private theorem w2329_0 : checkWitness 2329 false false 512 = true := by decide +kernel
private theorem w2329_1 : checkWitness 2329 false true 4608 = true := by decide +kernel
private theorem w2329_2 : checkWitness 2329 true false 512 = true := by decide +kernel
private theorem w2329_3 : checkWitness 2329 true true 4608 = true := by decide +kernel
private theorem cases2329 : checkFour 2329 (512,4608,512,4608) = true := by
  simp only [checkFour, w2329_0, w2329_1, w2329_2, w2329_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2329 : Coverage 2329 2330 := checkList_sound (ws:=[(512,4608,512,4608)]) (by simpa only [checkList, Bool.and_true] using cases2329)
private theorem w2330_0 : checkWitness 2330 false false 8915 = true := by decide +kernel
private theorem w2330_2 : checkWitness 2330 true false 8911 = true := by decide +kernel
private theorem cases2330 : checkFour 2330 (8915,0,8911,0) = true := by
  simp only [checkFour, w2330_0, w2330_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2330 : Coverage 2330 2331 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2330)
private theorem w2331_0 : checkWitness 2331 false false 644 = true := by decide +kernel
private theorem w2331_1 : checkWitness 2331 false true 4740 = true := by decide +kernel
private theorem w2331_2 : checkWitness 2331 true false 635 = true := by decide +kernel
private theorem w2331_3 : checkWitness 2331 true true 4731 = true := by decide +kernel
private theorem cases2331 : checkFour 2331 (644,4740,635,4731) = true := by
  simp only [checkFour, w2331_0, w2331_1, w2331_2, w2331_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2331 : Coverage 2331 2332 := checkList_sound (ws:=[(644,4740,635,4731)]) (by simpa only [checkList, Bool.and_true] using cases2331)
private theorem w2332_0 : checkWitness 2332 false false 190 = true := by decide +kernel
private theorem w2332_2 : checkWitness 2332 true false 190 = true := by decide +kernel
private theorem cases2332 : checkFour 2332 (190,0,190,0) = true := by
  simp only [checkFour, w2332_0, w2332_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2332 : Coverage 2332 2333 := checkList_sound (ws:=[(190,0,190,0)]) (by simpa only [checkList, Bool.and_true] using cases2332)
private theorem w2333_0 : checkWitness 2333 false false 593 = true := by decide +kernel
private theorem w2333_1 : checkWitness 2333 false true 4681 = true := by decide +kernel
private theorem w2333_2 : checkWitness 2333 true false 593 = true := by decide +kernel
private theorem w2333_3 : checkWitness 2333 true true 4681 = true := by decide +kernel
private theorem cases2333 : checkFour 2333 (593,4681,593,4681) = true := by
  simp only [checkFour, w2333_0, w2333_1, w2333_2, w2333_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2333 : Coverage 2333 2334 := checkList_sound (ws:=[(593,4681,593,4681)]) (by simpa only [checkList, Bool.and_true] using cases2333)
private theorem w2334_0 : checkWitness 2334 false false 8926 = true := by decide +kernel
private theorem w2334_2 : checkWitness 2334 true false 8917 = true := by decide +kernel
private theorem cases2334 : checkFour 2334 (8926,0,8917,0) = true := by
  simp only [checkFour, w2334_0, w2334_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2334 : Coverage 2334 2335 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases2334)
private theorem w2335_0 : checkWitness 2335 false false 70 = true := by decide +kernel
private theorem w2335_2 : checkWitness 2335 true false 70 = true := by decide +kernel
private theorem cases2335 : checkFour 2335 (70,0,70,0) = true := by
  simp only [checkFour, w2335_0, w2335_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2335 : Coverage 2335 2336 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2335)
theorem cover2304 : Coverage 2304 2336 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2304 one2305) (Coverage.join one2306 one2307)) (Coverage.join (Coverage.join one2308 one2309) (Coverage.join one2310 one2311))) (Coverage.join (Coverage.join (Coverage.join one2312 one2313) (Coverage.join one2314 one2315)) (Coverage.join (Coverage.join one2316 one2317) (Coverage.join one2318 one2319)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2320 one2321) (Coverage.join one2322 one2323)) (Coverage.join (Coverage.join one2324 one2325) (Coverage.join one2326 one2327))) (Coverage.join (Coverage.join (Coverage.join one2328 one2329) (Coverage.join one2330 one2331)) (Coverage.join (Coverage.join one2332 one2333) (Coverage.join one2334 one2335)))))
end NF180PA.Symbolic
