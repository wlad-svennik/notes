import NF179Literal
import NF180PAModelSearch
import NF182PAPoolNat
import Moving186NF

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
open PA192.Literal

namespace NF179
/-- Standard calibration, with the finite witness coverage stated explicitly.
This theorem is independent of the formalized proof of PA's consistency transfer. -/
theorem halts_iff_nf_refutation_of_coverage (cover : NF180PA.Symbolic.Coverage 0 2970) :
    NF210.TM.Halts machine start ↔ (𝗡𝗙 ⊢ ⊥) := by
  rw [←H179_standard, ←Moving186.deriv_goal_iff_nf_refutation]
  have code : (goal : Nat) = NF192.Numerical.goal :=
    goal_three.trans NF192.Numerical.goal_is_three.symm
  rw [←code]
  constructor
  · exact fun h => NF182PA.Pool.derivation_of_pool
      ((NF180PA.model_refutation_of_coverage cover).mp h)
  · exact fun h => (NF180PA.model_refutation_of_coverage cover).mpr
      (NF182PA.Pool.pool_of_derivation h)
end NF179
#print axioms NF179.halts_iff_nf_refutation_of_coverage
