import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w384_0 : checkWitness 384 false false 62 = true := by decide +kernel
private theorem w384_2 : checkWitness 384 true false 62 = true := by decide +kernel
private theorem cases384 : checkFour 384 (62,0,62,0) = true := by
  simp only [checkFour, w384_0, w384_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one384 : Coverage 384 385 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases384)
private theorem w385_0 : checkWitness 385 false false 562 = true := by decide +kernel
private theorem w385_1 : checkWitness 385 false true 4658 = true := by decide +kernel
private theorem w385_2 : checkWitness 385 true false 562 = true := by decide +kernel
private theorem w385_3 : checkWitness 385 true true 4658 = true := by decide +kernel
private theorem cases385 : checkFour 385 (562,4658,562,4658) = true := by
  simp only [checkFour, w385_0, w385_1, w385_2, w385_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one385 : Coverage 385 386 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases385)
private theorem w386_0 : checkWitness 386 false false 8913 = true := by decide +kernel
private theorem w386_2 : checkWitness 386 true false 8909 = true := by decide +kernel
private theorem cases386 : checkFour 386 (8913,0,8909,0) = true := by
  simp only [checkFour, w386_0, w386_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one386 : Coverage 386 387 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases386)
private theorem w387_0 : checkWitness 387 false false 8944 = true := by decide +kernel
private theorem w387_2 : checkWitness 387 true false 8935 = true := by decide +kernel
private theorem cases387 : checkFour 387 (8944,0,8935,0) = true := by
  simp only [checkFour, w387_0, w387_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one387 : Coverage 387 388 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases387)
private theorem w388_0 : checkWitness 388 false false 80 = true := by decide +kernel
private theorem w388_2 : checkWitness 388 true false 80 = true := by decide +kernel
private theorem cases388 : checkFour 388 (80,0,80,0) = true := by
  simp only [checkFour, w388_0, w388_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one388 : Coverage 388 389 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases388)
private theorem w389_0 : checkWitness 389 false false 658 = true := by decide +kernel
private theorem w389_1 : checkWitness 389 false true 4750 = true := by decide +kernel
private theorem w389_2 : checkWitness 389 true false 649 = true := by decide +kernel
private theorem w389_3 : checkWitness 389 true true 4741 = true := by decide +kernel
private theorem cases389 : checkFour 389 (658,4750,649,4741) = true := by
  simp only [checkFour, w389_0, w389_1, w389_2, w389_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one389 : Coverage 389 390 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases389)
private theorem w390_0 : checkWitness 390 false false 8909 = true := by decide +kernel
private theorem w390_2 : checkWitness 390 true false 8905 = true := by decide +kernel
private theorem cases390 : checkFour 390 (8909,0,8905,0) = true := by
  simp only [checkFour, w390_0, w390_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one390 : Coverage 390 391 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases390)
private theorem w391_0 : checkWitness 391 false false 652 = true := by decide +kernel
private theorem w391_1 : checkWitness 391 false true 4744 = true := by decide +kernel
private theorem w391_2 : checkWitness 391 true false 643 = true := by decide +kernel
private theorem w391_3 : checkWitness 391 true true 4735 = true := by decide +kernel
private theorem cases391 : checkFour 391 (652,4744,643,4735) = true := by
  simp only [checkFour, w391_0, w391_1, w391_2, w391_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one391 : Coverage 391 392 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases391)
private theorem w392_0 : checkWitness 392 false false 8880 = true := by decide +kernel
private theorem w392_2 : checkWitness 392 true false 8876 = true := by decide +kernel
private theorem cases392 : checkFour 392 (8880,0,8876,0) = true := by
  simp only [checkFour, w392_0, w392_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one392 : Coverage 392 393 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases392)
private theorem w393_0 : checkWitness 393 false false 68 = true := by decide +kernel
private theorem w393_2 : checkWitness 393 true false 68 = true := by decide +kernel
private theorem cases393 : checkFour 393 (68,0,68,0) = true := by
  simp only [checkFour, w393_0, w393_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one393 : Coverage 393 394 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases393)
private theorem w394_0 : checkWitness 394 false false 60 = true := by decide +kernel
private theorem w394_2 : checkWitness 394 true false 60 = true := by decide +kernel
private theorem cases394 : checkFour 394 (60,0,60,0) = true := by
  simp only [checkFour, w394_0, w394_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one394 : Coverage 394 395 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases394)
private theorem w395_0 : checkWitness 395 false false 617 = true := by decide +kernel
private theorem w395_1 : checkWitness 395 false true 4701 = true := by decide +kernel
private theorem w395_2 : checkWitness 395 true false 617 = true := by decide +kernel
private theorem w395_3 : checkWitness 395 true true 4701 = true := by decide +kernel
private theorem cases395 : checkFour 395 (617,4701,617,4701) = true := by
  simp only [checkFour, w395_0, w395_1, w395_2, w395_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one395 : Coverage 395 396 := checkList_sound (ws:=[(617,4701,617,4701)]) (by simpa only [checkList, Bool.and_true] using cases395)
private theorem w396_0 : checkWitness 396 false false 8896 = true := by decide +kernel
private theorem w396_2 : checkWitness 396 true false 8892 = true := by decide +kernel
private theorem cases396 : checkFour 396 (8896,0,8892,0) = true := by
  simp only [checkFour, w396_0, w396_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one396 : Coverage 396 397 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases396)
private theorem w397_0 : checkWitness 397 false false 8892 = true := by decide +kernel
private theorem w397_2 : checkWitness 397 true false 8888 = true := by decide +kernel
private theorem cases397 : checkFour 397 (8892,0,8888,0) = true := by
  simp only [checkFour, w397_0, w397_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one397 : Coverage 397 398 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases397)
private theorem w398_0 : checkWitness 398 false false 74 = true := by decide +kernel
private theorem w398_2 : checkWitness 398 true false 74 = true := by decide +kernel
private theorem cases398 : checkFour 398 (74,0,74,0) = true := by
  simp only [checkFour, w398_0, w398_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one398 : Coverage 398 399 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases398)
private theorem w399_0 : checkWitness 399 false false 644 = true := by decide +kernel
private theorem w399_1 : checkWitness 399 false true 4740 = true := by decide +kernel
private theorem w399_2 : checkWitness 399 true false 644 = true := by decide +kernel
private theorem w399_3 : checkWitness 399 true true 4740 = true := by decide +kernel
private theorem cases399 : checkFour 399 (644,4740,644,4740) = true := by
  simp only [checkFour, w399_0, w399_1, w399_2, w399_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one399 : Coverage 399 400 := checkList_sound (ws:=[(644,4740,644,4740)]) (by simpa only [checkList, Bool.and_true] using cases399)
private theorem w400_0 : checkWitness 400 false false 8936 = true := by decide +kernel
private theorem w400_2 : checkWitness 400 true false 8927 = true := by decide +kernel
private theorem cases400 : checkFour 400 (8936,0,8927,0) = true := by
  simp only [checkFour, w400_0, w400_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one400 : Coverage 400 401 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases400)
private theorem w401_0 : checkWitness 401 false false 60 = true := by decide +kernel
private theorem w401_2 : checkWitness 401 true false 60 = true := by decide +kernel
private theorem cases401 : checkFour 401 (60,0,60,0) = true := by
  simp only [checkFour, w401_0, w401_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one401 : Coverage 401 402 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases401)
private theorem w402_0 : checkWitness 402 false false 514 = true := by decide +kernel
private theorem w402_1 : checkWitness 402 false true 4610 = true := by decide +kernel
private theorem w402_2 : checkWitness 402 true false 514 = true := by decide +kernel
private theorem w402_3 : checkWitness 402 true true 4610 = true := by decide +kernel
private theorem cases402 : checkFour 402 (514,4610,514,4610) = true := by
  simp only [checkFour, w402_0, w402_1, w402_2, w402_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one402 : Coverage 402 403 := checkList_sound (ws:=[(514,4610,514,4610)]) (by simpa only [checkList, Bool.and_true] using cases402)
private theorem w403_0 : checkWitness 403 false false 8888 = true := by decide +kernel
private theorem w403_2 : checkWitness 403 true false 8884 = true := by decide +kernel
private theorem cases403 : checkFour 403 (8888,0,8884,0) = true := by
  simp only [checkFour, w403_0, w403_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one403 : Coverage 403 404 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases403)
private theorem w404_0 : checkWitness 404 false false 64 = true := by decide +kernel
private theorem w404_2 : checkWitness 404 true false 64 = true := by decide +kernel
private theorem cases404 : checkFour 404 (64,0,64,0) = true := by
  simp only [checkFour, w404_0, w404_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one404 : Coverage 404 405 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases404)
private theorem w405_0 : checkWitness 405 false false 556 = true := by decide +kernel
private theorem w405_1 : checkWitness 405 false true 4652 = true := by decide +kernel
private theorem w405_2 : checkWitness 405 true false 556 = true := by decide +kernel
private theorem w405_3 : checkWitness 405 true true 4652 = true := by decide +kernel
private theorem cases405 : checkFour 405 (556,4652,556,4652) = true := by
  simp only [checkFour, w405_0, w405_1, w405_2, w405_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one405 : Coverage 405 406 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases405)
private theorem w406_0 : checkWitness 406 false false 8907 = true := by decide +kernel
private theorem w406_2 : checkWitness 406 true false 8903 = true := by decide +kernel
private theorem cases406 : checkFour 406 (8907,0,8903,0) = true := by
  simp only [checkFour, w406_0, w406_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one406 : Coverage 406 407 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases406)
private theorem w407_0 : checkWitness 407 false false 8938 = true := by decide +kernel
private theorem w407_2 : checkWitness 407 true false 8929 = true := by decide +kernel
private theorem cases407 : checkFour 407 (8938,0,8929,0) = true := by
  simp only [checkFour, w407_0, w407_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one407 : Coverage 407 408 := checkList_sound (ws:=[(8938,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases407)
private theorem w408_0 : checkWitness 408 false false 88 = true := by decide +kernel
private theorem w408_2 : checkWitness 408 true false 88 = true := by decide +kernel
private theorem cases408 : checkFour 408 (88,0,88,0) = true := by
  simp only [checkFour, w408_0, w408_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one408 : Coverage 408 409 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases408)
private theorem w409_0 : checkWitness 409 false false 652 = true := by decide +kernel
private theorem w409_1 : checkWitness 409 false true 4744 = true := by decide +kernel
private theorem w409_2 : checkWitness 409 true false 643 = true := by decide +kernel
private theorem w409_3 : checkWitness 409 true true 4735 = true := by decide +kernel
private theorem cases409 : checkFour 409 (652,4744,643,4735) = true := by
  simp only [checkFour, w409_0, w409_1, w409_2, w409_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one409 : Coverage 409 410 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases409)
private theorem w410_0 : checkWitness 410 false false 8903 = true := by decide +kernel
private theorem w410_2 : checkWitness 410 true false 8899 = true := by decide +kernel
private theorem cases410 : checkFour 410 (8903,0,8899,0) = true := by
  simp only [checkFour, w410_0, w410_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one410 : Coverage 410 411 := checkList_sound (ws:=[(8903,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases410)
private theorem w411_0 : checkWitness 411 false false 646 = true := by decide +kernel
private theorem w411_1 : checkWitness 411 false true 4738 = true := by decide +kernel
private theorem w411_2 : checkWitness 411 true false 637 = true := by decide +kernel
private theorem w411_3 : checkWitness 411 true true 4729 = true := by decide +kernel
private theorem cases411 : checkFour 411 (646,4738,637,4729) = true := by
  simp only [checkFour, w411_0, w411_1, w411_2, w411_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one411 : Coverage 411 412 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases411)
private theorem w412_0 : checkWitness 412 false false 8874 = true := by decide +kernel
private theorem w412_2 : checkWitness 412 true false 8870 = true := by decide +kernel
private theorem cases412 : checkFour 412 (8874,0,8870,0) = true := by
  simp only [checkFour, w412_0, w412_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one412 : Coverage 412 413 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases412)
private theorem w413_0 : checkWitness 413 false false 76 = true := by decide +kernel
private theorem w413_2 : checkWitness 413 true false 76 = true := by decide +kernel
private theorem cases413 : checkFour 413 (76,0,76,0) = true := by
  simp only [checkFour, w413_0, w413_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one413 : Coverage 413 414 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases413)
private theorem w414_0 : checkWitness 414 false false 68 = true := by decide +kernel
private theorem w414_2 : checkWitness 414 true false 68 = true := by decide +kernel
private theorem cases414 : checkFour 414 (68,0,68,0) = true := by
  simp only [checkFour, w414_0, w414_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one414 : Coverage 414 415 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases414)
private theorem w415_0 : checkWitness 415 false false 599 = true := by decide +kernel
private theorem w415_1 : checkWitness 415 false true 4683 = true := by decide +kernel
private theorem w415_2 : checkWitness 415 true false 599 = true := by decide +kernel
private theorem w415_3 : checkWitness 415 true true 4683 = true := by decide +kernel
private theorem cases415 : checkFour 415 (599,4683,599,4683) = true := by
  simp only [checkFour, w415_0, w415_1, w415_2, w415_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one415 : Coverage 415 416 := checkList_sound (ws:=[(599,4683,599,4683)]) (by simpa only [checkList, Bool.and_true] using cases415)
theorem cover0384 : Coverage 384 416 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one384 one385) (Coverage.join one386 one387)) (Coverage.join (Coverage.join one388 one389) (Coverage.join one390 one391))) (Coverage.join (Coverage.join (Coverage.join one392 one393) (Coverage.join one394 one395)) (Coverage.join (Coverage.join one396 one397) (Coverage.join one398 one399)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one400 one401) (Coverage.join one402 one403)) (Coverage.join (Coverage.join one404 one405) (Coverage.join one406 one407))) (Coverage.join (Coverage.join (Coverage.join one408 one409) (Coverage.join one410 one411)) (Coverage.join (Coverage.join one412 one413) (Coverage.join one414 one415)))))
end NF180PA.Symbolic
