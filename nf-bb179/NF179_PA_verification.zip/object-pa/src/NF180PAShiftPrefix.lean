import NF180PAShiftCore
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.RegisterSource (Instr config address readReg writeReg perform)
namespace NF180PA.Shift
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 4000000
set_option maxRecDepth 100000
private theorem minus3 : (3:V)-1=2 := by
  calc (3:V)-1=((2:V)+1)-1 := by norm_num
       _=2 := add_tsub_cancel_right ..
private theorem minus4 : (4:V)-1=3 := by
  calc (4:V)-1=((3:V)+1)-1 := by norm_num
       _=3 := add_tsub_cancel_right ..
private theorem minus5 : (5:V)-1=4 := by
  calc (5:V)-1=((4:V)+1)-1 := by norm_num
       _=4 := add_tsub_cancel_right ..
private theorem minus6 : (6:V)-1=5 := by
  calc (6:V)-1=((5:V)+1)-1 := by norm_num
       _=5 := add_tsub_cancel_right ..
private theorem minus10 : (10:V)-1=9 := by
  calc (10:V)-1=((9:V)+1)-1 := by norm_num
       _=9 := add_tsub_cancel_right ..
private theorem o0 (r : V) :
    NF181PA.Registers.next (config 0 0 r)=perform (.dec 8 2 1) (0:V) r := by
  apply (NF181PA.Registers.next_at (⟨0,by decide⟩ : Fin 2971) 0 r).trans
  rfl
private theorem o2 (r : V) :
    NF181PA.Registers.next (config 2 0 r)=perform (.inc 0 3) (0:V) r := by
  apply (NF181PA.Registers.next_at (⟨2,by decide⟩ : Fin 2971) 0 r).trans
  rfl
private theorem o3 (r : V) :
    NF181PA.Registers.next (config 3 0 r)=perform (.dec 0 7 4) (0:V) r := by
  apply (NF181PA.Registers.next_at (⟨3,by decide⟩ : Fin 2971) 0 r).trans
  rfl
private theorem o4 (r : V) :
    NF181PA.Registers.next (config 4 0 r)=perform (.inc 7 5) (0:V) r := by
  apply (NF181PA.Registers.next_at (⟨4,by decide⟩ : Fin 2971) 0 r).trans
  rfl
private theorem o5 (r : V) :
    NF181PA.Registers.next (config 5 0 r)=perform (.inc 6 6) (0:V) r := by
  apply (NF181PA.Registers.next_at (⟨5,by decide⟩ : Fin 2971) 0 r).trans
  rfl
private theorem o6 (r : V) :
    NF181PA.Registers.next (config 6 0 r)=perform (.jump 3) (0:V) r := by
  apply (NF181PA.Registers.next_at (⟨6,by decide⟩ : Fin 2971) 0 r).trans
  rfl
private theorem o7 (r : V) :
    NF181PA.Registers.next (config 7 0 r)=perform (.dec 6 10 8) (0:V) r := by
  apply (NF181PA.Registers.next_at (⟨7,by decide⟩ : Fin 2971) 0 r).trans
  rfl
private theorem o8 (r : V) :
    NF181PA.Registers.next (config 8 0 r)=perform (.inc 0 9) (0:V) r := by
  apply (NF181PA.Registers.next_at (⟨8,by decide⟩ : Fin 2971) 0 r).trans
  rfl
private theorem o9 (r : V) :
    NF181PA.Registers.next (config 9 0 r)=perform (.jump 7) (0:V) r := by
  apply (NF181PA.Registers.next_at (⟨9,by decide⟩ : Fin 2971) 0 r).trans
  rfl
private theorem n0 (r : V) :
    NF180PA.Registers.next (config 0 0 r)=perform (.dec 8 2 1) (0:V) r := by
  apply (NF180PA.Registers.next_at (⟨0,by decide⟩ : Fin 2970) 0 r).trans
  rfl
private theorem n2 (r : V) :
    NF180PA.Registers.next (config 2 0 r)=perform (.dec 0 6 3) (0:V) r := by
  apply (NF180PA.Registers.next_at (⟨2,by decide⟩ : Fin 2970) 0 r).trans
  rfl
private theorem n3 (r : V) :
    NF180PA.Registers.next (config 3 0 r)=perform (.inc 7 4) (0:V) r := by
  apply (NF180PA.Registers.next_at (⟨3,by decide⟩ : Fin 2970) 0 r).trans
  rfl
private theorem n4 (r : V) :
    NF180PA.Registers.next (config 4 0 r)=perform (.inc 6 5) (0:V) r := by
  apply (NF180PA.Registers.next_at (⟨4,by decide⟩ : Fin 2970) 0 r).trans
  rfl
private theorem n5 (r : V) :
    NF180PA.Registers.next (config 5 0 r)=perform (.jump 2) (0:V) r := by
  apply (NF180PA.Registers.next_at (⟨5,by decide⟩ : Fin 2970) 0 r).trans
  rfl
private theorem n6 (r : V) :
    NF180PA.Registers.next (config 6 0 r)=perform (.inc 0 7) (0:V) r := by
  apply (NF180PA.Registers.next_at (⟨6,by decide⟩ : Fin 2970) 0 r).trans
  rfl
private theorem n7 (r : V) :
    NF180PA.Registers.next (config 7 0 r)=perform (.dec 6 9 8) (0:V) r := by
  apply (NF180PA.Registers.next_at (⟨7,by decide⟩ : Fin 2970) 0 r).trans
  rfl
private theorem n8 (r : V) :
    NF180PA.Registers.next (config 8 0 r)=perform (.jump 6) (0:V) r := by
  apply (NF180PA.Registers.next_at (⟨8,by decide⟩ : Fin 2970) 0 r).trans
  rfl
private theorem progress0 (r : V) : Local (0:V) r := by
  by_cases h : pi₁ (pi₂ (pi₂ (pi₂ (pi₂ (pi₂ (pi₂ (pi₂ (pi₂ (r)))))))))=0
  ·
    refine ⟨2,1,3,writeReg 0 (writeReg 8 r 0) (readReg 0 r+1),by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
      norm_num [oneIter,twoIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8,h]
  ·
    refine ⟨1,1,1,writeReg 8 r (readReg 8 r-1),by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
      norm_num [oneIter,twoIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8,h]

private theorem progress3 (r : V) : Local (3:V) r := by
  by_cases h : pi₁ (r)=0
  ·
    refine ⟨1,2,7,writeReg 0 r 0,by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
      norm_num [oneIter,twoIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8,h]
  ·
    refine ⟨1,1,4,writeReg 0 r (readReg 0 r-1),by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
      norm_num [oneIter,twoIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8,h]

private theorem progress7 (r : V) : Local (7:V) r := by
  by_cases h : pi₁ (pi₂ (pi₂ (pi₂ (pi₂ (pi₂ (pi₂ (r)))))))=0
  ·
    refine ⟨1,1,10,writeReg 6 r 0,by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
      norm_num [oneIter,twoIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8,h]
  ·
    refine ⟨1,1,8,writeReg 6 r (readReg 6 r-1),by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
      norm_num [oneIter,twoIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8,h]

private theorem progress4 (r : V) : Local (4:V) r := by
  refine ⟨1,1,5,writeReg 7 r (readReg 7 r+1),by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
    norm_num [oneIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8]
private theorem progress5 (r : V) : Local (5:V) r := by
  refine ⟨1,1,6,writeReg 6 r (readReg 6 r+1),by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
    norm_num [oneIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8]
private theorem progress6 (r : V) : Local (6:V) r := by
  refine ⟨1,1,3,r,by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
    norm_num [oneIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8]
private theorem progress8 (r : V) : Local (8:V) r := by
  refine ⟨1,1,9,writeReg 0 r (readReg 0 r+1),by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
    norm_num [oneIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8]
private theorem progress9 (r : V) : Local (9:V) r := by
  refine ⟨1,1,7,r,by norm_num,by norm_num,by norm_num [ready],?_,?_⟩ <;>
    norm_num [oneIter,image,location,biased,perform,chooseZero,bump,readReg,writeReg,minus3,minus4,minus5,minus6,minus10,o0,o2,o3,o4,o5,o6,o7,o8,o9,n0,n2,n3,n4,n5,n6,n7,n8]

theorem terminal (r : V) : Local (4095:V) r := by
  have old : NF181PA.Registers.next (config 4095 0 r)=config 4095 0 r := by
    simp only [NF181PA.Registers.next,RegisterSource.address_config,RegisterSource.cold_config,RegisterSource.registers_config]
    apply RegisterSource.dispatch_falloff; rw [NF181PA.Registers.program_length]; norm_num
  have new : NF180PA.Registers.next (config 4095 0 (bump r))=config 4095 0 (bump r) := by
    simp only [NF180PA.Registers.next,RegisterSource.address_config,RegisterSource.cold_config,RegisterSource.registers_config]
    apply RegisterSource.dispatch_falloff; rw [NF180PA.Registers.program_length]; norm_num
  have bias : biased (4095:V) r=bump r := by norm_num [biased]
  exact ⟨1,1,4095,r,by simp,by simp,by norm_num [ready],
    by simpa only [oneIter] using old,by simpa [oneIter,image,location,bias] using new⟩

theorem small {i : Nat} (small : i<10) (n1 : i≠1) (n2 : i≠2) (r : V) : Local (i:V) r := by
  have choices : i=0 ∨ i=3 ∨ i=4 ∨ i=5 ∨ i=6 ∨ i=7 ∨ i=8 ∨ i=9 := by omega
  rcases choices with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact progress0 r
  · exact progress3 r
  · exact progress4 r
  · exact progress5 r
  · exact progress6 r
  · exact progress7 r
  · exact progress8 r
  · exact progress9 r

end NF180PA.Shift
