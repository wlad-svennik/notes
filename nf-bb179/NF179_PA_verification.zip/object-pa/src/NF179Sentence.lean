import H192Trace
import SourceData
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
open PA192.LiteralTM

namespace NF179
/-- The subject has 179 working states and starts in k:74 on a two-way zero tape. -/
abbrev machine : NF210.TM.Machine 179 := Blank180.Table.machine
abbrev start : Fin 179 := Blank180.Table.start
def H179 : ArithmeticSentence := traceF machine start

theorem literal_sentence : H179 = traceF Blank180.Table.machine Blank180.Table.start := rfl
end NF179
#print axioms NF179.literal_sentence
