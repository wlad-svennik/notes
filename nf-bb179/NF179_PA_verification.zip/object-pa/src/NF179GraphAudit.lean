import Blank180Table
set_option maxRecDepth 20000
set_option maxHeartbeats 0
namespace NF179.GraphAudit
open Blank180.Table

def follow (q : Option State) : List Bool → Option State
  | [] => q
  | b::bs => follow (q.bind fun s => (machine s b).next) bs

def Reachable (q : State) : Prop := ∃ w : List Bool, follow (some start) w = some q

private theorem follow_append (a b : List Bool) (q : Option State) :
    follow q (a++b) = follow (follow q a) b := by
  induction a generalizing q with
  | nil => rfl
  | cons _ _ ih => exact ih _

private theorem extend {q u : State} (b : Bool) (hq : Reachable q)
    (edge : (machine q b).next = some u) : Reachable u := by
  obtain ⟨w,hw⟩ := hq
  refine ⟨w++[b],?_⟩
  rw [follow_append,hw]
  exact edge
private theorem r145 : Reachable 145 := ⟨[],rfl⟩
private theorem r117 : Reachable 117 := extend false r145 (by decide)
private theorem r143 : Reachable 143 := extend true r145 (by decide)
private theorem r148 : Reachable 148 := extend false r117 (by decide)
private theorem r144 : Reachable 144 := extend false r148 (by decide)
private theorem r139 : Reachable 139 := extend false r144 (by decide)
private theorem r121 : Reachable 121 := extend true r144 (by decide)
private theorem r134 : Reachable 134 := extend false r139 (by decide)
private theorem r149 : Reachable 149 := extend false r121 (by decide)
private theorem r133 : Reachable 133 := extend false r134 (by decide)
private theorem r119 : Reachable 119 := extend false r149 (by decide)
private theorem r141 : Reachable 141 := extend false r133 (by decide)
private theorem r128 : Reachable 128 := extend false r119 (by decide)
private theorem r118 : Reachable 118 := extend true r141 (by decide)
private theorem r115 : Reachable 115 := extend false r118 (by decide)
private theorem r116 : Reachable 116 := extend false r115 (by decide)
private theorem r122 : Reachable 122 := extend true r115 (by decide)
private theorem r29 : Reachable 29 := extend false r116 (by decide)
private theorem r127 : Reachable 127 := extend false r122 (by decide)
private theorem r30 : Reachable 30 := extend false r29 (by decide)
private theorem r31 : Reachable 31 := extend true r29 (by decide)
private theorem r137 : Reachable 137 := extend false r127 (by decide)
private theorem r7 : Reachable 7 := extend false r30 (by decide)
private theorem r0 : Reachable 0 := extend false r31 (by decide)
private theorem r147 : Reachable 147 := extend false r137 (by decide)
private theorem r67 : Reachable 67 := extend false r7 (by decide)
private theorem r135 : Reachable 135 := extend true r7 (by decide)
private theorem r125 : Reachable 125 := extend false r0 (by decide)
private theorem r140 : Reachable 140 := extend true r0 (by decide)
private theorem r120 : Reachable 120 := extend false r147 (by decide)
private theorem r45 : Reachable 45 := extend false r67 (by decide)
private theorem r126 : Reachable 126 := extend false r135 (by decide)
private theorem r131 : Reachable 131 := extend false r125 (by decide)
private theorem r123 : Reachable 123 := extend false r140 (by decide)
private theorem r124 : Reachable 124 := extend false r120 (by decide)
private theorem r46 : Reachable 46 := extend false r45 (by decide)
private theorem r47 : Reachable 47 := extend true r45 (by decide)
private theorem r132 : Reachable 132 := extend false r126 (by decide)
private theorem r130 : Reachable 130 := extend false r123 (by decide)
private theorem r146 : Reachable 146 := extend false r124 (by decide)
private theorem r8 : Reachable 8 := extend false r47 (by decide)
private theorem r66 : Reachable 66 := extend true r47 (by decide)
private theorem r138 : Reachable 138 := extend false r132 (by decide)
private theorem r129 : Reachable 129 := extend false r130 (by decide)
private theorem r12 : Reachable 12 := extend true r146 (by decide)
private theorem r83 : Reachable 83 := extend false r8 (by decide)
private theorem r87 : Reachable 87 := extend true r8 (by decide)
private theorem r1 : Reachable 1 := extend false r66 (by decide)
private theorem r53 : Reachable 53 := extend false r12 (by decide)
private theorem r13 : Reachable 13 := extend true r12 (by decide)
private theorem r9 : Reachable 9 := extend false r83 (by decide)
private theorem r84 : Reachable 84 := extend true r83 (by decide)
private theorem r50 : Reachable 50 := extend false r1 (by decide)
private theorem r62 : Reachable 62 := extend false r53 (by decide)
private theorem r20 : Reachable 20 := extend true r53 (by decide)
private theorem r55 : Reachable 55 := extend false r13 (by decide)
private theorem r60 : Reachable 60 := extend true r13 (by decide)
private theorem r136 : Reachable 136 := extend false r9 (by decide)
private theorem r142 : Reachable 142 := extend true r9 (by decide)
private theorem r175 : Reachable 175 := extend false r84 (by decide)
private theorem r43 : Reachable 43 := extend true r50 (by decide)
private theorem r101 : Reachable 101 := extend false r62 (by decide)
private theorem r111 : Reachable 111 := extend true r62 (by decide)
private theorem r21 : Reachable 21 := extend false r20 (by decide)
private theorem r54 : Reachable 54 := extend true r20 (by decide)
private theorem r56 : Reachable 56 := extend false r55 (by decide)
private theorem r58 : Reachable 58 := extend true r55 (by decide)
private theorem r61 : Reachable 61 := extend false r60 (by decide)
private theorem r32 : Reachable 32 := extend true r60 (by decide)
private theorem r39 : Reachable 39 := extend false r142 (by decide)
private theorem r174 : Reachable 174 := extend false r175 (by decide)
private theorem r22 : Reachable 22 := extend true r175 (by decide)
private theorem r109 : Reachable 109 := extend false r43 (by decide)
private theorem r51 : Reachable 51 := extend true r43 (by decide)
private theorem r11 : Reachable 11 := extend false r101 (by decide)
private theorem r156 : Reachable 156 := extend true r101 (by decide)
private theorem r91 : Reachable 91 := extend false r111 (by decide)
private theorem r110 : Reachable 110 := extend true r111 (by decide)
private theorem r24 : Reachable 24 := extend true r21 (by decide)
private theorem r2 : Reachable 2 := extend false r54 (by decide)
private theorem r57 : Reachable 57 := extend true r56 (by decide)
private theorem r59 : Reachable 59 := extend true r58 (by decide)
private theorem r63 : Reachable 63 := extend false r61 (by decide)
private theorem r34 : Reachable 34 := extend false r32 (by decide)
private theorem r35 : Reachable 35 := extend true r32 (by decide)
private theorem r178 : Reachable 178 := extend false r174 (by decide)
private theorem r17 : Reachable 17 := extend true r174 (by decide)
private theorem r4 : Reachable 4 := extend false r22 (by decide)
private theorem r105 : Reachable 105 := extend true r22 (by decide)
private theorem r52 : Reachable 52 := extend true r51 (by decide)
private theorem r90 : Reachable 90 := extend false r11 (by decide)
private theorem r3 : Reachable 3 := extend false r91 (by decide)
private theorem r75 : Reachable 75 := extend true r91 (by decide)
private theorem r33 : Reachable 33 := extend false r24 (by decide)
private theorem r6 : Reachable 6 := extend false r57 (by decide)
private theorem r64 : Reachable 64 := extend false r63 (by decide)
private theorem r40 : Reachable 40 := extend true r63 (by decide)
private theorem r100 : Reachable 100 := extend true r34 (by decide)
private theorem r36 : Reachable 36 := extend false r35 (by decide)
private theorem r103 : Reachable 103 := extend true r35 (by decide)
private theorem r97 : Reachable 97 := extend false r178 (by decide)
private theorem r177 : Reachable 177 := extend true r178 (by decide)
private theorem r104 : Reachable 104 := extend false r17 (by decide)
private theorem r18 : Reachable 18 := extend true r17 (by decide)
private theorem r88 : Reachable 88 := extend false r105 (by decide)
private theorem r5 : Reachable 5 := extend false r90 (by decide)
private theorem r79 : Reachable 79 := extend true r90 (by decide)
private theorem r10 : Reachable 10 := extend false r75 (by decide)
private theorem r65 : Reachable 65 := extend true r64 (by decide)
private theorem r95 : Reachable 95 := extend false r40 (by decide)
private theorem r41 : Reachable 41 := extend true r40 (by decide)
private theorem r102 : Reachable 102 := extend false r100 (by decide)
private theorem r37 : Reachable 37 := extend false r36 (by decide)
private theorem r108 : Reachable 108 := extend false r103 (by decide)
private theorem r98 : Reachable 98 := extend true r103 (by decide)
private theorem r94 : Reachable 94 := extend false r97 (by decide)
private theorem r114 : Reachable 114 := extend false r177 (by decide)
private theorem r176 : Reachable 176 := extend true r177 (by decide)
private theorem r96 : Reachable 96 := extend false r104 (by decide)
private theorem r19 : Reachable 19 := extend true r104 (by decide)
private theorem r15 : Reachable 15 := extend false r18 (by decide)
private theorem r89 : Reachable 89 := extend false r88 (by decide)
private theorem r92 : Reachable 92 := extend true r88 (by decide)
private theorem r171 : Reachable 171 := extend false r65 (by decide)
private theorem r14 : Reachable 14 := extend false r95 (by decide)
private theorem r42 : Reachable 42 := extend false r41 (by decide)
private theorem r48 : Reachable 48 := extend true r41 (by decide)
private theorem r69 : Reachable 69 := extend false r102 (by decide)
private theorem r38 : Reachable 38 := extend true r37 (by decide)
private theorem r99 : Reachable 99 := extend false r98 (by decide)
private theorem r112 : Reachable 112 := extend false r114 (by decide)
private theorem r113 : Reachable 113 := extend true r114 (by decide)
private theorem r160 : Reachable 160 := extend false r176 (by decide)
private theorem r106 : Reachable 106 := extend true r176 (by decide)
private theorem r85 : Reachable 85 := extend false r15 (by decide)
private theorem r107 : Reachable 107 := extend true r15 (by decide)
private theorem r80 : Reachable 80 := extend true r89 (by decide)
private theorem r74 : Reachable 74 := extend false r92 (by decide)
private theorem r93 : Reachable 93 := extend true r92 (by decide)
private theorem r170 : Reachable 170 := extend false r171 (by decide)
private theorem r26 : Reachable 26 := extend true r171 (by decide)
private theorem r151 : Reachable 151 := extend false r14 (by decide)
private theorem r16 : Reachable 16 := extend true r14 (by decide)
private theorem r70 : Reachable 70 := extend false r42 (by decide)
private theorem r44 : Reachable 44 := extend true r42 (by decide)
private theorem r49 : Reachable 49 := extend false r48 (by decide)
private theorem r71 : Reachable 71 := extend true r69 (by decide)
private theorem r68 : Reachable 68 := extend false r99 (by decide)
private theorem r173 : Reachable 173 := extend true r112 (by decide)
private theorem r153 : Reachable 153 := extend true r113 (by decide)
private theorem r159 : Reachable 159 := extend true r160 (by decide)
private theorem r157 : Reachable 157 := extend true r106 (by decide)
private theorem r86 : Reachable 86 := extend true r85 (by decide)
private theorem r76 : Reachable 76 := extend true r74 (by decide)
private theorem r168 : Reachable 168 := extend true r170 (by decide)
private theorem r27 : Reachable 27 := extend false r26 (by decide)
private theorem r28 : Reachable 28 := extend true r26 (by decide)
private theorem r155 : Reachable 155 := extend false r151 (by decide)
private theorem r72 : Reachable 72 := extend false r71 (by decide)
private theorem r73 : Reachable 73 := extend true r71 (by decide)
private theorem r81 : Reachable 81 := extend true r68 (by decide)
private theorem r23 : Reachable 23 := extend true r173 (by decide)
private theorem r152 : Reachable 152 := extend false r153 (by decide)
private theorem r77 : Reachable 77 := extend true r76 (by decide)
private theorem r167 : Reachable 167 := extend false r168 (by decide)
private theorem r25 : Reachable 25 := extend true r27 (by decide)
private theorem r154 : Reachable 154 := extend false r155 (by decide)
private theorem r82 : Reachable 82 := extend false r81 (by decide)
private theorem r78 : Reachable 78 := extend false r77 (by decide)
private theorem r166 : Reachable 166 := extend true r167 (by decide)
private theorem r172 : Reachable 172 := extend false r166 (by decide)
private theorem r165 : Reachable 165 := extend true r166 (by decide)
private theorem r169 : Reachable 169 := extend true r172 (by decide)
private theorem r164 : Reachable 164 := extend false r165 (by decide)
private theorem r158 : Reachable 158 := extend true r169 (by decide)
private theorem r163 : Reachable 163 := extend true r164 (by decide)
private theorem r150 : Reachable 150 := extend false r158 (by decide)
private theorem r162 : Reachable 162 := extend true r163 (by decide)
private theorem r161 : Reachable 161 := extend true r162 (by decide)
private def certified : Array {q : State // Reachable q} := #[
  ⟨0,r0⟩,
  ⟨1,r1⟩,
  ⟨2,r2⟩,
  ⟨3,r3⟩,
  ⟨4,r4⟩,
  ⟨5,r5⟩,
  ⟨6,r6⟩,
  ⟨7,r7⟩,
  ⟨8,r8⟩,
  ⟨9,r9⟩,
  ⟨10,r10⟩,
  ⟨11,r11⟩,
  ⟨12,r12⟩,
  ⟨13,r13⟩,
  ⟨14,r14⟩,
  ⟨15,r15⟩,
  ⟨16,r16⟩,
  ⟨17,r17⟩,
  ⟨18,r18⟩,
  ⟨19,r19⟩,
  ⟨20,r20⟩,
  ⟨21,r21⟩,
  ⟨22,r22⟩,
  ⟨23,r23⟩,
  ⟨24,r24⟩,
  ⟨25,r25⟩,
  ⟨26,r26⟩,
  ⟨27,r27⟩,
  ⟨28,r28⟩,
  ⟨29,r29⟩,
  ⟨30,r30⟩,
  ⟨31,r31⟩,
  ⟨32,r32⟩,
  ⟨33,r33⟩,
  ⟨34,r34⟩,
  ⟨35,r35⟩,
  ⟨36,r36⟩,
  ⟨37,r37⟩,
  ⟨38,r38⟩,
  ⟨39,r39⟩,
  ⟨40,r40⟩,
  ⟨41,r41⟩,
  ⟨42,r42⟩,
  ⟨43,r43⟩,
  ⟨44,r44⟩,
  ⟨45,r45⟩,
  ⟨46,r46⟩,
  ⟨47,r47⟩,
  ⟨48,r48⟩,
  ⟨49,r49⟩,
  ⟨50,r50⟩,
  ⟨51,r51⟩,
  ⟨52,r52⟩,
  ⟨53,r53⟩,
  ⟨54,r54⟩,
  ⟨55,r55⟩,
  ⟨56,r56⟩,
  ⟨57,r57⟩,
  ⟨58,r58⟩,
  ⟨59,r59⟩,
  ⟨60,r60⟩,
  ⟨61,r61⟩,
  ⟨62,r62⟩,
  ⟨63,r63⟩,
  ⟨64,r64⟩,
  ⟨65,r65⟩,
  ⟨66,r66⟩,
  ⟨67,r67⟩,
  ⟨68,r68⟩,
  ⟨69,r69⟩,
  ⟨70,r70⟩,
  ⟨71,r71⟩,
  ⟨72,r72⟩,
  ⟨73,r73⟩,
  ⟨74,r74⟩,
  ⟨75,r75⟩,
  ⟨76,r76⟩,
  ⟨77,r77⟩,
  ⟨78,r78⟩,
  ⟨79,r79⟩,
  ⟨80,r80⟩,
  ⟨81,r81⟩,
  ⟨82,r82⟩,
  ⟨83,r83⟩,
  ⟨84,r84⟩,
  ⟨85,r85⟩,
  ⟨86,r86⟩,
  ⟨87,r87⟩,
  ⟨88,r88⟩,
  ⟨89,r89⟩,
  ⟨90,r90⟩,
  ⟨91,r91⟩,
  ⟨92,r92⟩,
  ⟨93,r93⟩,
  ⟨94,r94⟩,
  ⟨95,r95⟩,
  ⟨96,r96⟩,
  ⟨97,r97⟩,
  ⟨98,r98⟩,
  ⟨99,r99⟩,
  ⟨100,r100⟩,
  ⟨101,r101⟩,
  ⟨102,r102⟩,
  ⟨103,r103⟩,
  ⟨104,r104⟩,
  ⟨105,r105⟩,
  ⟨106,r106⟩,
  ⟨107,r107⟩,
  ⟨108,r108⟩,
  ⟨109,r109⟩,
  ⟨110,r110⟩,
  ⟨111,r111⟩,
  ⟨112,r112⟩,
  ⟨113,r113⟩,
  ⟨114,r114⟩,
  ⟨115,r115⟩,
  ⟨116,r116⟩,
  ⟨117,r117⟩,
  ⟨118,r118⟩,
  ⟨119,r119⟩,
  ⟨120,r120⟩,
  ⟨121,r121⟩,
  ⟨122,r122⟩,
  ⟨123,r123⟩,
  ⟨124,r124⟩,
  ⟨125,r125⟩,
  ⟨126,r126⟩,
  ⟨127,r127⟩,
  ⟨128,r128⟩,
  ⟨129,r129⟩,
  ⟨130,r130⟩,
  ⟨131,r131⟩,
  ⟨132,r132⟩,
  ⟨133,r133⟩,
  ⟨134,r134⟩,
  ⟨135,r135⟩,
  ⟨136,r136⟩,
  ⟨137,r137⟩,
  ⟨138,r138⟩,
  ⟨139,r139⟩,
  ⟨140,r140⟩,
  ⟨141,r141⟩,
  ⟨142,r142⟩,
  ⟨143,r143⟩,
  ⟨144,r144⟩,
  ⟨145,r145⟩,
  ⟨146,r146⟩,
  ⟨147,r147⟩,
  ⟨148,r148⟩,
  ⟨149,r149⟩,
  ⟨150,r150⟩,
  ⟨151,r151⟩,
  ⟨152,r152⟩,
  ⟨153,r153⟩,
  ⟨154,r154⟩,
  ⟨155,r155⟩,
  ⟨156,r156⟩,
  ⟨157,r157⟩,
  ⟨158,r158⟩,
  ⟨159,r159⟩,
  ⟨160,r160⟩,
  ⟨161,r161⟩,
  ⟨162,r162⟩,
  ⟨163,r163⟩,
  ⟨164,r164⟩,
  ⟨165,r165⟩,
  ⟨166,r166⟩,
  ⟨167,r167⟩,
  ⟨168,r168⟩,
  ⟨169,r169⟩,
  ⟨170,r170⟩,
  ⟨171,r171⟩,
  ⟨172,r172⟩,
  ⟨173,r173⟩,
  ⟨174,r174⟩,
  ⟨175,r175⟩,
  ⟨176,r176⟩,
  ⟨177,r177⟩,
  ⟨178,r178⟩]
private def certificateAt (q : State) : {u : State // Reachable u} :=
  certified[q.val]?.getD ⟨145,r145⟩
private theorem index_exact : ∀ q : State, (certificateAt q).val = q := by decide +kernel

/-- Every working state has a path from the start in the abstract transition graph. -/
theorem all_control_states_reachable (q : State) : Reachable q := by
  exact (index_exact q) ▸ (certificateAt q).property
#print axioms all_control_states_reachable
end NF179.GraphAudit
