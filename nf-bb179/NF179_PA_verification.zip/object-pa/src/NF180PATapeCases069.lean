import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2208_0 : checkWitness 2208 false false 8856 = true := by decide +kernel
private theorem w2208_2 : checkWitness 2208 true false 8852 = true := by decide +kernel
private theorem cases2208 : checkFour 2208 (8856,0,8852,0) = true := by
  simp only [checkFour, w2208_0, w2208_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2208 : Coverage 2208 2209 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases2208)
private theorem w2209_0 : checkWitness 2209 false false 68 = true := by decide +kernel
private theorem w2209_2 : checkWitness 2209 true false 68 = true := by decide +kernel
private theorem cases2209 : checkFour 2209 (68,0,68,0) = true := by
  simp only [checkFour, w2209_0, w2209_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2209 : Coverage 2209 2210 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2209)
private theorem w2210_0 : checkWitness 2210 false false 540 = true := by decide +kernel
private theorem w2210_1 : checkWitness 2210 false true 4636 = true := by decide +kernel
private theorem w2210_2 : checkWitness 2210 true false 540 = true := by decide +kernel
private theorem w2210_3 : checkWitness 2210 true true 4636 = true := by decide +kernel
private theorem cases2210 : checkFour 2210 (540,4636,540,4636) = true := by
  simp only [checkFour, w2210_0, w2210_1, w2210_2, w2210_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2210 : Coverage 2210 2211 := checkList_sound (ws:=[(540,4636,540,4636)]) (by simpa only [checkList, Bool.and_true] using cases2210)
private theorem w2211_0 : checkWitness 2211 false false 8891 = true := by decide +kernel
private theorem w2211_2 : checkWitness 2211 true false 8887 = true := by decide +kernel
private theorem cases2211 : checkFour 2211 (8891,0,8887,0) = true := by
  simp only [checkFour, w2211_0, w2211_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2211 : Coverage 2211 2212 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases2211)
private theorem w2212_0 : checkWitness 2212 false false 8922 = true := by decide +kernel
private theorem w2212_2 : checkWitness 2212 true false 8913 = true := by decide +kernel
private theorem cases2212 : checkFour 2212 (8922,0,8913,0) = true := by
  simp only [checkFour, w2212_0, w2212_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2212 : Coverage 2212 2213 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2212)
private theorem w2213_0 : checkWitness 2213 false false 86 = true := by decide +kernel
private theorem w2213_2 : checkWitness 2213 true false 86 = true := by decide +kernel
private theorem cases2213 : checkFour 2213 (86,0,86,0) = true := by
  simp only [checkFour, w2213_0, w2213_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2213 : Coverage 2213 2214 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases2213)
private theorem w2214_0 : checkWitness 2214 false false 636 = true := by decide +kernel
private theorem w2214_1 : checkWitness 2214 false true 4728 = true := by decide +kernel
private theorem w2214_2 : checkWitness 2214 true false 627 = true := by decide +kernel
private theorem w2214_3 : checkWitness 2214 true true 4719 = true := by decide +kernel
private theorem cases2214 : checkFour 2214 (636,4728,627,4719) = true := by
  simp only [checkFour, w2214_0, w2214_1, w2214_2, w2214_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2214 : Coverage 2214 2215 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases2214)
private theorem w2215_0 : checkWitness 2215 false false 8887 = true := by decide +kernel
private theorem w2215_2 : checkWitness 2215 true false 8883 = true := by decide +kernel
private theorem cases2215 : checkFour 2215 (8887,0,8883,0) = true := by
  simp only [checkFour, w2215_0, w2215_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2215 : Coverage 2215 2216 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases2215)
private theorem w2216_0 : checkWitness 2216 false false 630 = true := by decide +kernel
private theorem w2216_1 : checkWitness 2216 false true 4722 = true := by decide +kernel
private theorem w2216_2 : checkWitness 2216 true false 621 = true := by decide +kernel
private theorem w2216_3 : checkWitness 2216 true true 4713 = true := by decide +kernel
private theorem cases2216 : checkFour 2216 (630,4722,621,4713) = true := by
  simp only [checkFour, w2216_0, w2216_1, w2216_2, w2216_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2216 : Coverage 2216 2217 := checkList_sound (ws:=[(630,4722,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases2216)
private theorem w2217_0 : checkWitness 2217 false false 8858 = true := by decide +kernel
private theorem w2217_2 : checkWitness 2217 true false 8854 = true := by decide +kernel
private theorem cases2217 : checkFour 2217 (8858,0,8854,0) = true := by
  simp only [checkFour, w2217_0, w2217_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2217 : Coverage 2217 2218 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases2217)
private theorem w2218_0 : checkWitness 2218 false false 74 = true := by decide +kernel
private theorem w2218_2 : checkWitness 2218 true false 74 = true := by decide +kernel
private theorem cases2218 : checkFour 2218 (74,0,74,0) = true := by
  simp only [checkFour, w2218_0, w2218_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2218 : Coverage 2218 2219 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2218)
private theorem w2219_0 : checkWitness 2219 false false 66 = true := by decide +kernel
private theorem w2219_2 : checkWitness 2219 true false 66 = true := by decide +kernel
private theorem cases2219 : checkFour 2219 (66,0,66,0) = true := by
  simp only [checkFour, w2219_0, w2219_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2219 : Coverage 2219 2220 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2219)
private theorem w2220_0 : checkWitness 2220 false false 591 = true := by decide +kernel
private theorem w2220_1 : checkWitness 2220 false true 4679 = true := by decide +kernel
private theorem w2220_2 : checkWitness 2220 true false 591 = true := by decide +kernel
private theorem w2220_3 : checkWitness 2220 true true 4679 = true := by decide +kernel
private theorem cases2220 : checkFour 2220 (591,4679,591,4679) = true := by
  simp only [checkFour, w2220_0, w2220_1, w2220_2, w2220_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2220 : Coverage 2220 2221 := checkList_sound (ws:=[(591,4679,591,4679)]) (by simpa only [checkList, Bool.and_true] using cases2220)
private theorem w2221_0 : checkWitness 2221 false false 8874 = true := by decide +kernel
private theorem w2221_2 : checkWitness 2221 true false 8870 = true := by decide +kernel
private theorem cases2221 : checkFour 2221 (8874,0,8870,0) = true := by
  simp only [checkFour, w2221_0, w2221_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2221 : Coverage 2221 2222 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases2221)
private theorem w2222_0 : checkWitness 2222 false false 8870 = true := by decide +kernel
private theorem w2222_2 : checkWitness 2222 true false 8866 = true := by decide +kernel
private theorem cases2222 : checkFour 2222 (8870,0,8866,0) = true := by
  simp only [checkFour, w2222_0, w2222_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2222 : Coverage 2222 2223 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases2222)
private theorem w2223_0 : checkWitness 2223 false false 80 = true := by decide +kernel
private theorem w2223_2 : checkWitness 2223 true false 80 = true := by decide +kernel
private theorem cases2223 : checkFour 2223 (80,0,80,0) = true := by
  simp only [checkFour, w2223_0, w2223_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2223 : Coverage 2223 2224 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2223)
private theorem w2224_0 : checkWitness 2224 false false 8890 = true := by decide +kernel
private theorem w2224_2 : checkWitness 2224 true false 8886 = true := by decide +kernel
private theorem cases2224 : checkFour 2224 (8890,0,8886,0) = true := by
  simp only [checkFour, w2224_0, w2224_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2224 : Coverage 2224 2225 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases2224)
private theorem w2225_0 : checkWitness 2225 false false 632 = true := by decide +kernel
private theorem w2225_1 : checkWitness 2225 false true 4728 = true := by decide +kernel
private theorem w2225_2 : checkWitness 2225 true false 632 = true := by decide +kernel
private theorem w2225_3 : checkWitness 2225 true true 4728 = true := by decide +kernel
private theorem cases2225 : checkFour 2225 (632,4728,632,4728) = true := by
  simp only [checkFour, w2225_0, w2225_1, w2225_2, w2225_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2225 : Coverage 2225 2226 := checkList_sound (ws:=[(632,4728,632,4728)]) (by simpa only [checkList, Bool.and_true] using cases2225)
private theorem w2226_0 : checkWitness 2226 false false 8922 = true := by decide +kernel
private theorem w2226_2 : checkWitness 2226 true false 8913 = true := by decide +kernel
private theorem cases2226 : checkFour 2226 (8922,0,8913,0) = true := by
  simp only [checkFour, w2226_0, w2226_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2226 : Coverage 2226 2227 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2226)
private theorem w2227_0 : checkWitness 2227 false false 62 = true := by decide +kernel
private theorem w2227_2 : checkWitness 2227 true false 62 = true := by decide +kernel
private theorem cases2227 : checkFour 2227 (62,0,62,0) = true := by
  simp only [checkFour, w2227_0, w2227_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2227 : Coverage 2227 2228 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2227)
private theorem w2228_0 : checkWitness 2228 false false 500 = true := by decide +kernel
private theorem w2228_1 : checkWitness 2228 false true 4596 = true := by decide +kernel
private theorem w2228_2 : checkWitness 2228 true false 500 = true := by decide +kernel
private theorem w2228_3 : checkWitness 2228 true true 4596 = true := by decide +kernel
private theorem cases2228 : checkFour 2228 (500,4596,500,4596) = true := by
  simp only [checkFour, w2228_0, w2228_1, w2228_2, w2228_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2228 : Coverage 2228 2229 := checkList_sound (ws:=[(500,4596,500,4596)]) (by simpa only [checkList, Bool.and_true] using cases2228)
private theorem w2229_0 : checkWitness 2229 false false 8874 = true := by decide +kernel
private theorem w2229_2 : checkWitness 2229 true false 8870 = true := by decide +kernel
private theorem cases2229 : checkFour 2229 (8874,0,8870,0) = true := by
  simp only [checkFour, w2229_0, w2229_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2229 : Coverage 2229 2230 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases2229)
private theorem w2230_0 : checkWitness 2230 false false 66 = true := by decide +kernel
private theorem w2230_2 : checkWitness 2230 true false 66 = true := by decide +kernel
private theorem cases2230 : checkFour 2230 (66,0,66,0) = true := by
  simp only [checkFour, w2230_0, w2230_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2230 : Coverage 2230 2231 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2230)
private theorem w2231_0 : checkWitness 2231 false false 542 = true := by decide +kernel
private theorem w2231_1 : checkWitness 2231 false true 4638 = true := by decide +kernel
private theorem w2231_2 : checkWitness 2231 true false 542 = true := by decide +kernel
private theorem w2231_3 : checkWitness 2231 true true 4638 = true := by decide +kernel
private theorem cases2231 : checkFour 2231 (542,4638,542,4638) = true := by
  simp only [checkFour, w2231_0, w2231_1, w2231_2, w2231_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2231 : Coverage 2231 2232 := checkList_sound (ws:=[(542,4638,542,4638)]) (by simpa only [checkList, Bool.and_true] using cases2231)
private theorem w2232_0 : checkWitness 2232 false false 8893 = true := by decide +kernel
private theorem w2232_2 : checkWitness 2232 true false 8889 = true := by decide +kernel
private theorem cases2232 : checkFour 2232 (8893,0,8889,0) = true := by
  simp only [checkFour, w2232_0, w2232_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2232 : Coverage 2232 2233 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases2232)
private theorem w2233_0 : checkWitness 2233 false false 8924 = true := by decide +kernel
private theorem w2233_2 : checkWitness 2233 true false 8915 = true := by decide +kernel
private theorem cases2233 : checkFour 2233 (8924,0,8915,0) = true := by
  simp only [checkFour, w2233_0, w2233_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2233 : Coverage 2233 2234 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases2233)
private theorem w2234_0 : checkWitness 2234 false false 90 = true := by decide +kernel
private theorem w2234_2 : checkWitness 2234 true false 90 = true := by decide +kernel
private theorem cases2234 : checkFour 2234 (90,0,90,0) = true := by
  simp only [checkFour, w2234_0, w2234_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2234 : Coverage 2234 2235 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases2234)
private theorem w2235_0 : checkWitness 2235 false false 638 = true := by decide +kernel
private theorem w2235_1 : checkWitness 2235 false true 4730 = true := by decide +kernel
private theorem w2235_2 : checkWitness 2235 true false 629 = true := by decide +kernel
private theorem w2235_3 : checkWitness 2235 true true 4721 = true := by decide +kernel
private theorem cases2235 : checkFour 2235 (638,4730,629,4721) = true := by
  simp only [checkFour, w2235_0, w2235_1, w2235_2, w2235_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2235 : Coverage 2235 2236 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases2235)
private theorem w2236_0 : checkWitness 2236 false false 8889 = true := by decide +kernel
private theorem w2236_2 : checkWitness 2236 true false 8885 = true := by decide +kernel
private theorem cases2236 : checkFour 2236 (8889,0,8885,0) = true := by
  simp only [checkFour, w2236_0, w2236_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2236 : Coverage 2236 2237 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases2236)
private theorem w2237_0 : checkWitness 2237 false false 632 = true := by decide +kernel
private theorem w2237_1 : checkWitness 2237 false true 4724 = true := by decide +kernel
private theorem w2237_2 : checkWitness 2237 true false 623 = true := by decide +kernel
private theorem w2237_3 : checkWitness 2237 true true 4715 = true := by decide +kernel
private theorem cases2237 : checkFour 2237 (632,4724,623,4715) = true := by
  simp only [checkFour, w2237_0, w2237_1, w2237_2, w2237_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2237 : Coverage 2237 2238 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases2237)
private theorem w2238_0 : checkWitness 2238 false false 8860 = true := by decide +kernel
private theorem w2238_2 : checkWitness 2238 true false 8856 = true := by decide +kernel
private theorem cases2238 : checkFour 2238 (8860,0,8856,0) = true := by
  simp only [checkFour, w2238_0, w2238_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2238 : Coverage 2238 2239 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases2238)
private theorem w2239_0 : checkWitness 2239 false false 78 = true := by decide +kernel
private theorem w2239_2 : checkWitness 2239 true false 78 = true := by decide +kernel
private theorem cases2239 : checkFour 2239 (78,0,78,0) = true := by
  simp only [checkFour, w2239_0, w2239_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2239 : Coverage 2239 2240 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2239)
theorem cover2208 : Coverage 2208 2240 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2208 one2209) (Coverage.join one2210 one2211)) (Coverage.join (Coverage.join one2212 one2213) (Coverage.join one2214 one2215))) (Coverage.join (Coverage.join (Coverage.join one2216 one2217) (Coverage.join one2218 one2219)) (Coverage.join (Coverage.join one2220 one2221) (Coverage.join one2222 one2223)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2224 one2225) (Coverage.join one2226 one2227)) (Coverage.join (Coverage.join one2228 one2229) (Coverage.join one2230 one2231))) (Coverage.join (Coverage.join (Coverage.join one2232 one2233) (Coverage.join one2234 one2235)) (Coverage.join (Coverage.join one2236 one2237) (Coverage.join one2238 one2239)))))
end NF180PA.Symbolic
