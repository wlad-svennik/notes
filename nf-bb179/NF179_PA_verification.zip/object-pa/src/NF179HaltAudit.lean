import Blank180Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace NF179.HaltAudit
open Blank180.Table NF210.TM
theorem halt_exact : ∀ (q : State) (b : Bool), (machine q b).next = none ↔
    q = 128 ∧ b = true := by decide +kernel
theorem halt_instruction : machine 128 true = ⟨false,.left,none⟩ := by decide +kernel
theorem start_id : start = (145 : State) := rfl
theorem binary_table_size : (List.finRange 179).length = 179 ∧ rendered.length = 358 := by
  constructor
  · simp
  · rw [literal_exact]
    rfl
#print axioms halt_exact
#print axioms halt_instruction
#print axioms start_id
#print axioms binary_table_size
end NF179.HaltAudit
