import NF179Literal
import NF180PAReplay
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.BusyBeaver

namespace NF179
theorem pa_live_230892 : M6.PA.theory ⊢ ∼(NF180PA.byStep 230892) :=
  NF180PA.pa_live_230892

theorem pa_bound_implies_nonhalting (k : Nat) (live : (run machine k (blank start)).state ≠ none) :
    M6.PA.theory ⊢ upper 179 k 🡒 ∼ H179 :=
  NF180PA.pa_bound_implies_nonhalting k live
end NF179
#print axioms NF179.pa_live_230892
#print axioms NF179.pa_bound_implies_nonhalting
