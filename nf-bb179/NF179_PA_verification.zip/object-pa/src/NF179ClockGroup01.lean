import NF179ClockBase
namespace NF180PA.Clock
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part256 : Covers 256 272 := block_sound (lo:=256) (n:=16) (by decide +kernel)
private theorem part272 : Covers 272 288 := block_sound (lo:=272) (n:=16) (by decide +kernel)
private theorem part288 : Covers 288 304 := block_sound (lo:=288) (n:=16) (by decide +kernel)
private theorem part304 : Covers 304 320 := block_sound (lo:=304) (n:=16) (by decide +kernel)
private theorem part320 : Covers 320 336 := block_sound (lo:=320) (n:=16) (by decide +kernel)
private theorem part336 : Covers 336 352 := block_sound (lo:=336) (n:=16) (by decide +kernel)
private theorem part352 : Covers 352 368 := block_sound (lo:=352) (n:=16) (by decide +kernel)
private theorem part368 : Covers 368 384 := block_sound (lo:=368) (n:=16) (by decide +kernel)
private theorem part384 : Covers 384 400 := block_sound (lo:=384) (n:=16) (by decide +kernel)
private theorem part400 : Covers 400 416 := block_sound (lo:=400) (n:=16) (by decide +kernel)
private theorem part416 : Covers 416 432 := block_sound (lo:=416) (n:=16) (by decide +kernel)
private theorem part432 : Covers 432 448 := block_sound (lo:=432) (n:=16) (by decide +kernel)
private theorem part448 : Covers 448 464 := block_sound (lo:=448) (n:=16) (by decide +kernel)
private theorem part464 : Covers 464 480 := block_sound (lo:=464) (n:=16) (by decide +kernel)
private theorem part480 : Covers 480 496 := block_sound (lo:=480) (n:=16) (by decide +kernel)
private theorem part496 : Covers 496 512 := block_sound (lo:=496) (n:=16) (by decide +kernel)
theorem group256 : Covers 256 512 := (Covers.join (Covers.join (Covers.join (Covers.join part256 part272) (Covers.join part288 part304)) (Covers.join (Covers.join part320 part336) (Covers.join part352 part368))) (Covers.join (Covers.join (Covers.join part384 part400) (Covers.join part416 part432)) (Covers.join (Covers.join part448 part464) (Covers.join part480 part496))))
end NF180PA.Clock
