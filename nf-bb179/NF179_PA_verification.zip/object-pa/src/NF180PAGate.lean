import NF180PA


open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM PA192.PhysicalModel

namespace NF180PA.Gate
set_option maxRecDepth 12000
set_option maxHeartbeats 2400000

abbrev machine := Blank180.Table.machine
abbrev start := Blank180.Table.start
abbrev gate := Blank180.Data.haltGate

/-- A kernel calculation over all 358 entries, using the released table. -/
theorem unique_halt_row : ∀ (q : Fin 179) (b : Bool),
    (machine q b).next = none ↔ q=gate ∧ b=true := by decide +kernel

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

def onGate (cfg : V) : Prop := state cfg = (gate.val : V) ∧ rightRay cfg % 2 = 1

/-- Over arbitrary possibly nonstandard rays, the only live-to-halted step
is precisely k:302 reading 1. -/
theorem step_halts_iff (cfg : V) (live : state cfg < (179 : V)) :
    state (rawStep machine cfg) = (179 : V) ↔ onGate cfg := by
  constructor
  · intro hit
    obtain ⟨q,b,w⟩ := step_from_raw machine cfg live
    obtain ⟨src,dst,rb,_,_⟩ := (local_iff_quotient ..).mp w
    have nextIsNone : (machine q b).next = none := by
      apply control_inj
      change control (machine q b).next = 179
      have cast : (control (machine q b).next : V) = (179:V) := dst.symm.trans hit
      exact_mod_cast cast
    obtain ⟨rfl,rfl⟩ := (unique_halt_row q b).mp nextIsNone
    exact ⟨src,by simpa using rb⟩
  · rintro ⟨src,bit⟩
    rw [rawStep,src,pick_mem _ gate (by simp),switch_bit machine gate true cfg (by simpa using bit)]
    change state (pack _ _ _) = _
    rw [state_pack]
    have out := (unique_halt_row gate true).mpr ⟨rfl,rfl⟩
    rw [out]; rfl

/-- The quantifier over clocks belongs to the PA model. -/
theorem H180_iff_gate : (V ⊧/![] H180) ↔ ∃ t : V, onGate (rawRun machine start t) := by
  rw [H180_eval]
  constructor
  · rintro ⟨j,hit⟩
    obtain ⟨t,stop,earlier⟩ :=
      first_model (fun t : V => state (rawRun machine start t) = (179 : V)) (by definability) hit
    have nz : t ≠ 0 := by
      intro h
      subst t
      change state (rawRun machine start (0 : V)) = (179 : V) at stop
      rw [PA192.PhysicalModel.run_zero,state_pack] at stop
      have h : (start.val:Nat) = 179 := by exact_mod_cast stop
      exact (Nat.ne_of_lt start.isLt) h
    have pos : 1≤t := by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne zero_le (Ne.symm nz))
    obtain ⟨k,rfl⟩ : ∃ k, t=k+1 := ⟨t-1,(sub_add_self_of_le pos).symm⟩
    have live := lt_of_le_of_ne (runs_bounded machine start k) (earlier k (by simp))
    exact ⟨k,(step_halts_iff _ live).mp (by simpa only [PA192.PhysicalModel.run_succ] using stop)⟩
  · rintro ⟨t,g⟩
    refine ⟨t+1,?_⟩
    rw [PA192.PhysicalModel.run_succ]
    apply (step_halts_iff _ ?_).mpr g
    rw [g.1]
    exact_mod_cast gate.isLt

end NF180PA.Gate
#print axioms NF180PA.Gate.unique_halt_row
#print axioms NF180PA.Gate.H180_iff_gate
