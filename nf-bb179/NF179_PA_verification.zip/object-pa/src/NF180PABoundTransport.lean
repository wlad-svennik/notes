import NF180PATransport
import NF180PAReplay
import TrueValue
import ModelStartBound

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.LiteralTM PA192.BusyBeaver

namespace NF180PA

/-- Transfer unprovability through an object-PA equivalence. The upper-bound part
uses the new literal 179-state machine, so its state count is also reduced. -/
theorem busy_beaver_of_equivalence
    (equiv : M6.PA.theory ⊢ H180 🡘 NF181PA.H181)
    (oldNeg : M6.PA.theory ⊬ ∼NF181PA.H181)
    (oldLive : ¬(Nat ⊧/![] NF181PA.H181)) :
    (M6.PA.theory ⊬ ∼H180) ∧ (M6.PA.theory ⊬ H180) ∧
    (∀ k : Nat, M6.PA.theory ⊬ upper 179 k) ∧
    ∃ k : Nat, (Nat ⊧/![] (value 179 k)) ∧
      (M6.PA.theory ⊬ value 179 k) ∧ (M6.PA.theory ⊬ ∼(value 179 k)) := by
  have toOld : M6.PA.theory ⊢ H180 🡒 NF181PA.H181 := C_of_E_mp equiv
  have sem := models_iff.mp (models_of_provable (M:=Nat) inferInstance toOld)
  simp only [LogicalConnective.HomClass.map_imply] at sem
  have live : ¬Halts Blank180.Table.machine Blank180.Table.start :=
    fun stop => oldLive (sem (H180_standard.mpr stop))
  have neg : M6.PA.theory ⊬ ∼H180 :=
    fun p => oldNeg (contra (C_of_E_mpr equiv) ⨀ p)
  have pos : M6.PA.theory ⊬ H180 := fun p =>
    oldLive (models_iff.mp (models_of_provable (M:=Nat) inferInstance (toOld ⨀ p)))
  have noUpper (k : Nat) : M6.PA.theory ⊬ upper 179 k := fun p =>
    neg (pa_bound_implies_nonhalting k (fun stop => live ⟨k, stop⟩) ⨀ p)
  obtain ⟨k,actual⟩ := exists_true_value 179
  exact ⟨neg,pos,noUpper,k,actual,no_value_of_no_upper (noUpper k),true_value_unrefutable actual⟩

end NF180PA
#print axioms NF180PA.busy_beaver_of_equivalence
