import NF179ClockBase
namespace NF180PA.Clock
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part1792 : Covers 1792 1808 := block_sound (lo:=1792) (n:=16) (by decide +kernel)
private theorem part1808 : Covers 1808 1824 := block_sound (lo:=1808) (n:=16) (by decide +kernel)
private theorem part1824 : Covers 1824 1840 := block_sound (lo:=1824) (n:=16) (by decide +kernel)
private theorem part1840 : Covers 1840 1856 := block_sound (lo:=1840) (n:=16) (by decide +kernel)
private theorem part1856 : Covers 1856 1872 := block_sound (lo:=1856) (n:=16) (by decide +kernel)
private theorem part1872 : Covers 1872 1888 := block_sound (lo:=1872) (n:=16) (by decide +kernel)
private theorem part1888 : Covers 1888 1904 := block_sound (lo:=1888) (n:=16) (by decide +kernel)
private theorem part1904 : Covers 1904 1920 := block_sound (lo:=1904) (n:=16) (by decide +kernel)
private theorem part1920 : Covers 1920 1936 := block_sound (lo:=1920) (n:=16) (by decide +kernel)
private theorem part1936 : Covers 1936 1952 := block_sound (lo:=1936) (n:=16) (by decide +kernel)
private theorem part1952 : Covers 1952 1968 := block_sound (lo:=1952) (n:=16) (by decide +kernel)
private theorem part1968 : Covers 1968 1984 := block_sound (lo:=1968) (n:=16) (by decide +kernel)
private theorem part1984 : Covers 1984 2000 := block_sound (lo:=1984) (n:=16) (by decide +kernel)
private theorem part2000 : Covers 2000 2016 := block_sound (lo:=2000) (n:=16) (by decide +kernel)
private theorem part2016 : Covers 2016 2032 := block_sound (lo:=2016) (n:=16) (by decide +kernel)
private theorem part2032 : Covers 2032 2048 := block_sound (lo:=2032) (n:=16) (by decide +kernel)
theorem group1792 : Covers 1792 2048 := (Covers.join (Covers.join (Covers.join (Covers.join part1792 part1808) (Covers.join part1824 part1840)) (Covers.join (Covers.join part1856 part1872) (Covers.join part1888 part1904))) (Covers.join (Covers.join (Covers.join part1920 part1936) (Covers.join part1952 part1968)) (Covers.join (Covers.join part1984 part2000) (Covers.join part2016 part2032))))
end NF180PA.Clock
