import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2912_0 : checkWitness 2912 false false 615 = true := by decide +kernel
private theorem w2912_1 : checkWitness 2912 false true 4711 = true := by decide +kernel
private theorem w2912_2 : checkWitness 2912 true false 615 = true := by decide +kernel
private theorem w2912_3 : checkWitness 2912 true true 4711 = true := by decide +kernel
private theorem cases2912 : checkFour 2912 (615,4711,615,4711) = true := by
  simp only [checkFour, w2912_0, w2912_1, w2912_2, w2912_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2912 : Coverage 2912 2913 := checkList_sound (ws:=[(615,4711,615,4711)]) (by simpa only [checkList, Bool.and_true] using cases2912)
private theorem w2913_0 : checkWitness 2913 false false 8976 = true := by decide +kernel
private theorem w2913_2 : checkWitness 2913 true false 8967 = true := by decide +kernel
private theorem cases2913 : checkFour 2913 (8976,0,8967,0) = true := by
  simp only [checkFour, w2913_0, w2913_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2913 : Coverage 2913 2914 := checkList_sound (ws:=[(8976,0,8967,0)]) (by simpa only [checkList, Bool.and_true] using cases2913)
private theorem w2914_0 : checkWitness 2914 false false 8922 = true := by decide +kernel
private theorem w2914_2 : checkWitness 2914 true false 8918 = true := by decide +kernel
private theorem cases2914 : checkFour 2914 (8922,0,8918,0) = true := by
  simp only [checkFour, w2914_0, w2914_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2914 : Coverage 2914 2915 := checkList_sound (ws:=[(8922,0,8918,0)]) (by simpa only [checkList, Bool.and_true] using cases2914)
private theorem w2915_0 : checkWitness 2915 false false 56 = true := by decide +kernel
private theorem w2915_2 : checkWitness 2915 true false 56 = true := by decide +kernel
private theorem cases2915 : checkFour 2915 (56,0,56,0) = true := by
  simp only [checkFour, w2915_0, w2915_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2915 : Coverage 2915 2916 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2915)
private theorem w2916_0 : checkWitness 2916 false false 702 = true := by decide +kernel
private theorem w2916_1 : checkWitness 2916 false true 4790 = true := by decide +kernel
private theorem w2916_2 : checkWitness 2916 true false 693 = true := by decide +kernel
private theorem w2916_3 : checkWitness 2916 true true 4781 = true := by decide +kernel
private theorem cases2916 : checkFour 2916 (702,4790,693,4781) = true := by
  simp only [checkFour, w2916_0, w2916_1, w2916_2, w2916_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2916 : Coverage 2916 2917 := checkList_sound (ws:=[(702,4790,693,4781)]) (by simpa only [checkList, Bool.and_true] using cases2916)
private theorem w2917_0 : checkWitness 2917 false false 8941 = true := by decide +kernel
private theorem w2917_2 : checkWitness 2917 true false 8937 = true := by decide +kernel
private theorem cases2917 : checkFour 2917 (8941,0,8937,0) = true := by
  simp only [checkFour, w2917_0, w2917_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2917 : Coverage 2917 2918 := checkList_sound (ws:=[(8941,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases2917)
private theorem w2918_0 : checkWitness 2918 false false 46 = true := by decide +kernel
private theorem w2918_2 : checkWitness 2918 true false 46 = true := by decide +kernel
private theorem cases2918 : checkFour 2918 (46,0,46,0) = true := by
  simp only [checkFour, w2918_0, w2918_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2918 : Coverage 2918 2919 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2918)
private theorem w2919_0 : checkWitness 2919 false false 607 = true := by decide +kernel
private theorem w2919_1 : checkWitness 2919 false true 4703 = true := by decide +kernel
private theorem w2919_2 : checkWitness 2919 true false 607 = true := by decide +kernel
private theorem w2919_3 : checkWitness 2919 true true 4703 = true := by decide +kernel
private theorem cases2919 : checkFour 2919 (607,4703,607,4703) = true := by
  simp only [checkFour, w2919_0, w2919_1, w2919_2, w2919_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2919 : Coverage 2919 2920 := checkList_sound (ws:=[(607,4703,607,4703)]) (by simpa only [checkList, Bool.and_true] using cases2919)
private theorem w2920_0 : checkWitness 2920 false false 36 = true := by decide +kernel
private theorem w2920_2 : checkWitness 2920 true false 36 = true := by decide +kernel
private theorem cases2920 : checkFour 2920 (36,0,36,0) = true := by
  simp only [checkFour, w2920_0, w2920_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2920 : Coverage 2920 2921 := checkList_sound (ws:=[(36,0,36,0)]) (by simpa only [checkList, Bool.and_true] using cases2920)
private theorem w2921_0 : checkWitness 2921 false false 691 = true := by decide +kernel
private theorem w2921_1 : checkWitness 2921 false true 4763 = true := by decide +kernel
private theorem w2921_2 : checkWitness 2921 true false 682 = true := by decide +kernel
private theorem w2921_3 : checkWitness 2921 true true 4754 = true := by decide +kernel
private theorem cases2921 : checkFour 2921 (691,4763,682,4754) = true := by
  simp only [checkFour, w2921_0, w2921_1, w2921_2, w2921_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2921 : Coverage 2921 2922 := checkList_sound (ws:=[(691,4763,682,4754)]) (by simpa only [checkList, Bool.and_true] using cases2921)
private theorem w2922_0 : checkWitness 2922 false false 34 = true := by decide +kernel
private theorem w2922_2 : checkWitness 2922 true false 34 = true := by decide +kernel
private theorem cases2922 : checkFour 2922 (34,0,34,0) = true := by
  simp only [checkFour, w2922_0, w2922_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2922 : Coverage 2922 2923 := checkList_sound (ws:=[(34,0,34,0)]) (by simpa only [checkList, Bool.and_true] using cases2922)
private theorem w2923_0 : checkWitness 2923 false false 627 = true := by decide +kernel
private theorem w2923_1 : checkWitness 2923 false true 4723 = true := by decide +kernel
private theorem w2923_2 : checkWitness 2923 true false 627 = true := by decide +kernel
private theorem w2923_3 : checkWitness 2923 true true 4723 = true := by decide +kernel
private theorem cases2923 : checkFour 2923 (627,4723,627,4723) = true := by
  simp only [checkFour, w2923_0, w2923_1, w2923_2, w2923_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2923 : Coverage 2923 2924 := checkList_sound (ws:=[(627,4723,627,4723)]) (by simpa only [checkList, Bool.and_true] using cases2923)
private theorem w2924_0 : checkWitness 2924 false false 604 = true := by decide +kernel
private theorem w2924_1 : checkWitness 2924 false true 4700 = true := by decide +kernel
private theorem w2924_2 : checkWitness 2924 true false 604 = true := by decide +kernel
private theorem w2924_3 : checkWitness 2924 true true 4700 = true := by decide +kernel
private theorem cases2924 : checkFour 2924 (604,4700,604,4700) = true := by
  simp only [checkFour, w2924_0, w2924_1, w2924_2, w2924_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2924 : Coverage 2924 2925 := checkList_sound (ws:=[(604,4700,604,4700)]) (by simpa only [checkList, Bool.and_true] using cases2924)
private theorem w2925_0 : checkWitness 2925 false false 8978 = true := by decide +kernel
private theorem w2925_2 : checkWitness 2925 true false 8969 = true := by decide +kernel
private theorem cases2925 : checkFour 2925 (8978,0,8969,0) = true := by
  simp only [checkFour, w2925_0, w2925_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2925 : Coverage 2925 2926 := checkList_sound (ws:=[(8978,0,8969,0)]) (by simpa only [checkList, Bool.and_true] using cases2925)
private theorem w2926_0 : checkWitness 2926 false false 34 = true := by decide +kernel
private theorem w2926_2 : checkWitness 2926 true false 34 = true := by decide +kernel
private theorem cases2926 : checkFour 2926 (34,0,34,0) = true := by
  simp only [checkFour, w2926_0, w2926_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2926 : Coverage 2926 2927 := checkList_sound (ws:=[(34,0,34,0)]) (by simpa only [checkList, Bool.and_true] using cases2926)
private theorem w2927_0 : checkWitness 2927 false false 556 = true := by decide +kernel
private theorem w2927_1 : checkWitness 2927 false true 4652 = true := by decide +kernel
private theorem w2927_2 : checkWitness 2927 true false 556 = true := by decide +kernel
private theorem w2927_3 : checkWitness 2927 true true 4652 = true := by decide +kernel
private theorem cases2927 : checkFour 2927 (556,4652,556,4652) = true := by
  simp only [checkFour, w2927_0, w2927_1, w2927_2, w2927_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2927 : Coverage 2927 2928 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases2927)
private theorem w2928_0 : checkWitness 2928 false false 8930 = true := by decide +kernel
private theorem w2928_2 : checkWitness 2928 true false 8926 = true := by decide +kernel
private theorem cases2928 : checkFour 2928 (8930,0,8926,0) = true := by
  simp only [checkFour, w2928_0, w2928_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2928 : Coverage 2928 2929 := checkList_sound (ws:=[(8930,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases2928)
private theorem w2929_0 : checkWitness 2929 false false 38 = true := by decide +kernel
private theorem w2929_2 : checkWitness 2929 true false 38 = true := by decide +kernel
private theorem cases2929 : checkFour 2929 (38,0,38,0) = true := by
  simp only [checkFour, w2929_0, w2929_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2929 : Coverage 2929 2930 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases2929)
private theorem w2930_0 : checkWitness 2930 false false 598 = true := by decide +kernel
private theorem w2930_1 : checkWitness 2930 false true 4694 = true := by decide +kernel
private theorem w2930_2 : checkWitness 2930 true false 598 = true := by decide +kernel
private theorem w2930_3 : checkWitness 2930 true true 4694 = true := by decide +kernel
private theorem cases2930 : checkFour 2930 (598,4694,598,4694) = true := by
  simp only [checkFour, w2930_0, w2930_1, w2930_2, w2930_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2930 : Coverage 2930 2931 := checkList_sound (ws:=[(598,4694,598,4694)]) (by simpa only [checkList, Bool.and_true] using cases2930)
private theorem w2931_0 : checkWitness 2931 false false 8949 = true := by decide +kernel
private theorem w2931_2 : checkWitness 2931 true false 8945 = true := by decide +kernel
private theorem cases2931 : checkFour 2931 (8949,0,8945,0) = true := by
  simp only [checkFour, w2931_0, w2931_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2931 : Coverage 2931 2932 := checkList_sound (ws:=[(8949,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2931)
private theorem w2932_0 : checkWitness 2932 false false 8980 = true := by decide +kernel
private theorem w2932_2 : checkWitness 2932 true false 8971 = true := by decide +kernel
private theorem cases2932 : checkFour 2932 (8980,0,8971,0) = true := by
  simp only [checkFour, w2932_0, w2932_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2932 : Coverage 2932 2933 := checkList_sound (ws:=[(8980,0,8971,0)]) (by simpa only [checkList, Bool.and_true] using cases2932)
private theorem w2933_0 : checkWitness 2933 false false 62 = true := by decide +kernel
private theorem w2933_2 : checkWitness 2933 true false 62 = true := by decide +kernel
private theorem cases2933 : checkFour 2933 (62,0,62,0) = true := by
  simp only [checkFour, w2933_0, w2933_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2933 : Coverage 2933 2934 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2933)
private theorem w2934_0 : checkWitness 2934 false false 694 = true := by decide +kernel
private theorem w2934_1 : checkWitness 2934 false true 4786 = true := by decide +kernel
private theorem w2934_2 : checkWitness 2934 true false 685 = true := by decide +kernel
private theorem w2934_3 : checkWitness 2934 true true 4777 = true := by decide +kernel
private theorem cases2934 : checkFour 2934 (694,4786,685,4777) = true := by
  simp only [checkFour, w2934_0, w2934_1, w2934_2, w2934_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2934 : Coverage 2934 2935 := checkList_sound (ws:=[(694,4786,685,4777)]) (by simpa only [checkList, Bool.and_true] using cases2934)
private theorem w2935_0 : checkWitness 2935 false false 8945 = true := by decide +kernel
private theorem w2935_2 : checkWitness 2935 true false 8941 = true := by decide +kernel
private theorem cases2935 : checkFour 2935 (8945,0,8941,0) = true := by
  simp only [checkFour, w2935_0, w2935_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2935 : Coverage 2935 2936 := checkList_sound (ws:=[(8945,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2935)
private theorem w2936_0 : checkWitness 2936 false false 688 = true := by decide +kernel
private theorem w2936_1 : checkWitness 2936 false true 4780 = true := by decide +kernel
private theorem w2936_2 : checkWitness 2936 true false 679 = true := by decide +kernel
private theorem w2936_3 : checkWitness 2936 true true 4771 = true := by decide +kernel
private theorem cases2936 : checkFour 2936 (688,4780,679,4771) = true := by
  simp only [checkFour, w2936_0, w2936_1, w2936_2, w2936_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2936 : Coverage 2936 2937 := checkList_sound (ws:=[(688,4780,679,4771)]) (by simpa only [checkList, Bool.and_true] using cases2936)
private theorem w2937_0 : checkWitness 2937 false false 8916 = true := by decide +kernel
private theorem w2937_2 : checkWitness 2937 true false 8912 = true := by decide +kernel
private theorem cases2937 : checkFour 2937 (8916,0,8912,0) = true := by
  simp only [checkFour, w2937_0, w2937_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2937 : Coverage 2937 2938 := checkList_sound (ws:=[(8916,0,8912,0)]) (by simpa only [checkList, Bool.and_true] using cases2937)
private theorem w2938_0 : checkWitness 2938 false false 50 = true := by decide +kernel
private theorem w2938_2 : checkWitness 2938 true false 50 = true := by decide +kernel
private theorem cases2938 : checkFour 2938 (50,0,50,0) = true := by
  simp only [checkFour, w2938_0, w2938_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2938 : Coverage 2938 2939 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2938)
private theorem w2939_0 : checkWitness 2939 false false 42 = true := by decide +kernel
private theorem w2939_2 : checkWitness 2939 true false 42 = true := by decide +kernel
private theorem cases2939 : checkFour 2939 (42,0,42,0) = true := by
  simp only [checkFour, w2939_0, w2939_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2939 : Coverage 2939 2940 := checkList_sound (ws:=[(42,0,42,0)]) (by simpa only [checkList, Bool.and_true] using cases2939)
private theorem w2940_0 : checkWitness 2940 false false 641 = true := by decide +kernel
private theorem w2940_1 : checkWitness 2940 false true 4725 = true := by decide +kernel
private theorem w2940_2 : checkWitness 2940 true false 641 = true := by decide +kernel
private theorem w2940_3 : checkWitness 2940 true true 4725 = true := by decide +kernel
private theorem cases2940 : checkFour 2940 (641,4725,641,4725) = true := by
  simp only [checkFour, w2940_0, w2940_1, w2940_2, w2940_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2940 : Coverage 2940 2941 := checkList_sound (ws:=[(641,4725,641,4725)]) (by simpa only [checkList, Bool.and_true] using cases2940)
private theorem w2941_0 : checkWitness 2941 false false 8908 = true := by decide +kernel
private theorem w2941_2 : checkWitness 2941 true false 8904 = true := by decide +kernel
private theorem cases2941 : checkFour 2941 (8908,0,8904,0) = true := by
  simp only [checkFour, w2941_0, w2941_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2941 : Coverage 2941 2942 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases2941)
private theorem w2942_0 : checkWitness 2942 false false 42 = true := by decide +kernel
private theorem w2942_2 : checkWitness 2942 true false 42 = true := by decide +kernel
private theorem cases2942 : checkFour 2942 (42,0,42,0) = true := by
  simp only [checkFour, w2942_0, w2942_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2942 : Coverage 2942 2943 := checkList_sound (ws:=[(42,0,42,0)]) (by simpa only [checkList, Bool.and_true] using cases2942)
private theorem w2943_0 : checkWitness 2943 false false 685 = true := by decide +kernel
private theorem w2943_1 : checkWitness 2943 false true 4777 = true := by decide +kernel
private theorem w2943_2 : checkWitness 2943 true false 676 = true := by decide +kernel
private theorem w2943_3 : checkWitness 2943 true true 4768 = true := by decide +kernel
private theorem cases2943 : checkFour 2943 (685,4777,676,4768) = true := by
  simp only [checkFour, w2943_0, w2943_1, w2943_2, w2943_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2943 : Coverage 2943 2944 := checkList_sound (ws:=[(685,4777,676,4768)]) (by simpa only [checkList, Bool.and_true] using cases2943)
theorem cover2912 : Coverage 2912 2944 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2912 one2913) (Coverage.join one2914 one2915)) (Coverage.join (Coverage.join one2916 one2917) (Coverage.join one2918 one2919))) (Coverage.join (Coverage.join (Coverage.join one2920 one2921) (Coverage.join one2922 one2923)) (Coverage.join (Coverage.join one2924 one2925) (Coverage.join one2926 one2927)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2928 one2929) (Coverage.join one2930 one2931)) (Coverage.join (Coverage.join one2932 one2933) (Coverage.join one2934 one2935))) (Coverage.join (Coverage.join (Coverage.join one2936 one2937) (Coverage.join one2938 one2939)) (Coverage.join (Coverage.join one2940 one2941) (Coverage.join one2942 one2943)))))
end NF180PA.Symbolic
