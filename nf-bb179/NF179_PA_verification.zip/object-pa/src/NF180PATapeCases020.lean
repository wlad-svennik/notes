import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w640_0 : checkWitness 640 false false 76 = true := by decide +kernel
private theorem w640_2 : checkWitness 640 true false 76 = true := by decide +kernel
private theorem cases640 : checkFour 640 (76,0,76,0) = true := by
  simp only [checkFour, w640_0, w640_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one640 : Coverage 640 641 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases640)
private theorem w641_0 : checkWitness 641 false false 68 = true := by decide +kernel
private theorem w641_2 : checkWitness 641 true false 68 = true := by decide +kernel
private theorem cases641 : checkFour 641 (68,0,68,0) = true := by
  simp only [checkFour, w641_0, w641_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one641 : Coverage 641 642 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases641)
private theorem w642_0 : checkWitness 642 false false 601 = true := by decide +kernel
private theorem w642_1 : checkWitness 642 false true 4693 = true := by decide +kernel
private theorem w642_2 : checkWitness 642 true false 601 = true := by decide +kernel
private theorem w642_3 : checkWitness 642 true true 4693 = true := by decide +kernel
private theorem cases642 : checkFour 642 (601,4693,601,4693) = true := by
  simp only [checkFour, w642_0, w642_1, w642_2, w642_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one642 : Coverage 642 643 := checkList_sound (ws:=[(601,4693,601,4693)]) (by simpa only [checkList, Bool.and_true] using cases642)
private theorem w643_0 : checkWitness 643 false false 8876 = true := by decide +kernel
private theorem w643_2 : checkWitness 643 true false 8872 = true := by decide +kernel
private theorem cases643 : checkFour 643 (8876,0,8872,0) = true := by
  simp only [checkFour, w643_0, w643_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one643 : Coverage 643 644 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases643)
private theorem w644_0 : checkWitness 644 false false 68 = true := by decide +kernel
private theorem w644_2 : checkWitness 644 true false 68 = true := by decide +kernel
private theorem cases644 : checkFour 644 (68,0,68,0) = true := by
  simp only [checkFour, w644_0, w644_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one644 : Coverage 644 645 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases644)
private theorem w645_0 : checkWitness 645 false false 560 = true := by decide +kernel
private theorem w645_1 : checkWitness 645 false true 4656 = true := by decide +kernel
private theorem w645_2 : checkWitness 645 true false 560 = true := by decide +kernel
private theorem w645_3 : checkWitness 645 true true 4656 = true := by decide +kernel
private theorem cases645 : checkFour 645 (560,4656,560,4656) = true := by
  simp only [checkFour, w645_0, w645_1, w645_2, w645_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one645 : Coverage 645 646 := checkList_sound (ws:=[(560,4656,560,4656)]) (by simpa only [checkList, Bool.and_true] using cases645)
private theorem w646_0 : checkWitness 646 false false 8911 = true := by decide +kernel
private theorem w646_2 : checkWitness 646 true false 8907 = true := by decide +kernel
private theorem cases646 : checkFour 646 (8911,0,8907,0) = true := by
  simp only [checkFour, w646_0, w646_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one646 : Coverage 646 647 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases646)
private theorem w647_0 : checkWitness 647 false false 8942 = true := by decide +kernel
private theorem w647_2 : checkWitness 647 true false 8933 = true := by decide +kernel
private theorem cases647 : checkFour 647 (8942,0,8933,0) = true := by
  simp only [checkFour, w647_0, w647_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one647 : Coverage 647 648 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases647)
private theorem w648_0 : checkWitness 648 false false 86 = true := by decide +kernel
private theorem w648_2 : checkWitness 648 true false 86 = true := by decide +kernel
private theorem cases648 : checkFour 648 (86,0,86,0) = true := by
  simp only [checkFour, w648_0, w648_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one648 : Coverage 648 649 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases648)
private theorem w649_0 : checkWitness 649 false false 656 = true := by decide +kernel
private theorem w649_1 : checkWitness 649 false true 4748 = true := by decide +kernel
private theorem w649_2 : checkWitness 649 true false 647 = true := by decide +kernel
private theorem w649_3 : checkWitness 649 true true 4739 = true := by decide +kernel
private theorem cases649 : checkFour 649 (656,4748,647,4739) = true := by
  simp only [checkFour, w649_0, w649_1, w649_2, w649_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one649 : Coverage 649 650 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases649)
private theorem w650_0 : checkWitness 650 false false 8907 = true := by decide +kernel
private theorem w650_2 : checkWitness 650 true false 8903 = true := by decide +kernel
private theorem cases650 : checkFour 650 (8907,0,8903,0) = true := by
  simp only [checkFour, w650_0, w650_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one650 : Coverage 650 651 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases650)
private theorem w651_0 : checkWitness 651 false false 650 = true := by decide +kernel
private theorem w651_1 : checkWitness 651 false true 4742 = true := by decide +kernel
private theorem w651_2 : checkWitness 651 true false 641 = true := by decide +kernel
private theorem w651_3 : checkWitness 651 true true 4733 = true := by decide +kernel
private theorem cases651 : checkFour 651 (650,4742,641,4733) = true := by
  simp only [checkFour, w651_0, w651_1, w651_2, w651_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one651 : Coverage 651 652 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases651)
private theorem w652_0 : checkWitness 652 false false 8878 = true := by decide +kernel
private theorem w652_2 : checkWitness 652 true false 8874 = true := by decide +kernel
private theorem cases652 : checkFour 652 (8878,0,8874,0) = true := by
  simp only [checkFour, w652_0, w652_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one652 : Coverage 652 653 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases652)
private theorem w653_0 : checkWitness 653 false false 74 = true := by decide +kernel
private theorem w653_2 : checkWitness 653 true false 74 = true := by decide +kernel
private theorem cases653 : checkFour 653 (74,0,74,0) = true := by
  simp only [checkFour, w653_0, w653_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one653 : Coverage 653 654 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases653)
private theorem w654_0 : checkWitness 654 false false 66 = true := by decide +kernel
private theorem w654_2 : checkWitness 654 true false 66 = true := by decide +kernel
private theorem cases654 : checkFour 654 (66,0,66,0) = true := by
  simp only [checkFour, w654_0, w654_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one654 : Coverage 654 655 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases654)
private theorem w655_0 : checkWitness 655 false false 611 = true := by decide +kernel
private theorem w655_1 : checkWitness 655 false true 4699 = true := by decide +kernel
private theorem w655_2 : checkWitness 655 true false 611 = true := by decide +kernel
private theorem w655_3 : checkWitness 655 true true 4699 = true := by decide +kernel
private theorem cases655 : checkFour 655 (611,4699,611,4699) = true := by
  simp only [checkFour, w655_0, w655_1, w655_2, w655_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one655 : Coverage 655 656 := checkList_sound (ws:=[(611,4699,611,4699)]) (by simpa only [checkList, Bool.and_true] using cases655)
private theorem w656_0 : checkWitness 656 false false 8894 = true := by decide +kernel
private theorem w656_2 : checkWitness 656 true false 8890 = true := by decide +kernel
private theorem cases656 : checkFour 656 (8894,0,8890,0) = true := by
  simp only [checkFour, w656_0, w656_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one656 : Coverage 656 657 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases656)
private theorem w657_0 : checkWitness 657 false false 8890 = true := by decide +kernel
private theorem w657_2 : checkWitness 657 true false 8886 = true := by decide +kernel
private theorem cases657 : checkFour 657 (8890,0,8886,0) = true := by
  simp only [checkFour, w657_0, w657_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one657 : Coverage 657 658 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases657)
private theorem w658_0 : checkWitness 658 false false 80 = true := by decide +kernel
private theorem w658_2 : checkWitness 658 true false 80 = true := by decide +kernel
private theorem cases658 : checkFour 658 (80,0,80,0) = true := by
  simp only [checkFour, w658_0, w658_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one658 : Coverage 658 659 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases658)
private theorem w659_0 : checkWitness 659 false false 8910 = true := by decide +kernel
private theorem w659_2 : checkWitness 659 true false 8906 = true := by decide +kernel
private theorem cases659 : checkFour 659 (8910,0,8906,0) = true := by
  simp only [checkFour, w659_0, w659_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one659 : Coverage 659 660 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases659)
private theorem w660_0 : checkWitness 660 false false 636 = true := by decide +kernel
private theorem w660_1 : checkWitness 660 false true 4732 = true := by decide +kernel
private theorem w660_2 : checkWitness 660 true false 636 = true := by decide +kernel
private theorem w660_3 : checkWitness 660 true true 4732 = true := by decide +kernel
private theorem cases660 : checkFour 660 (636,4732,636,4732) = true := by
  simp only [checkFour, w660_0, w660_1, w660_2, w660_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one660 : Coverage 660 661 := checkList_sound (ws:=[(636,4732,636,4732)]) (by simpa only [checkList, Bool.and_true] using cases660)
private theorem w661_0 : checkWitness 661 false false 8930 = true := by decide +kernel
private theorem w661_2 : checkWitness 661 true false 8921 = true := by decide +kernel
private theorem cases661 : checkFour 661 (8930,0,8921,0) = true := by
  simp only [checkFour, w661_0, w661_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one661 : Coverage 661 662 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases661)
private theorem w662_0 : checkWitness 662 false false 58 = true := by decide +kernel
private theorem w662_2 : checkWitness 662 true false 58 = true := by decide +kernel
private theorem cases662 : checkFour 662 (58,0,58,0) = true := by
  simp only [checkFour, w662_0, w662_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one662 : Coverage 662 663 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases662)
private theorem w663_0 : checkWitness 663 false false 508 = true := by decide +kernel
private theorem w663_1 : checkWitness 663 false true 4604 = true := by decide +kernel
private theorem w663_2 : checkWitness 663 true false 508 = true := by decide +kernel
private theorem w663_3 : checkWitness 663 true true 4604 = true := by decide +kernel
private theorem cases663 : checkFour 663 (508,4604,508,4604) = true := by
  simp only [checkFour, w663_0, w663_1, w663_2, w663_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one663 : Coverage 663 664 := checkList_sound (ws:=[(508,4604,508,4604)]) (by simpa only [checkList, Bool.and_true] using cases663)
private theorem w664_0 : checkWitness 664 false false 8882 = true := by decide +kernel
private theorem w664_2 : checkWitness 664 true false 8878 = true := by decide +kernel
private theorem cases664 : checkFour 664 (8882,0,8878,0) = true := by
  simp only [checkFour, w664_0, w664_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one664 : Coverage 664 665 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases664)
private theorem w665_0 : checkWitness 665 false false 62 = true := by decide +kernel
private theorem w665_2 : checkWitness 665 true false 62 = true := by decide +kernel
private theorem cases665 : checkFour 665 (62,0,62,0) = true := by
  simp only [checkFour, w665_0, w665_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one665 : Coverage 665 666 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases665)
private theorem w666_0 : checkWitness 666 false false 550 = true := by decide +kernel
private theorem w666_1 : checkWitness 666 false true 4646 = true := by decide +kernel
private theorem w666_2 : checkWitness 666 true false 550 = true := by decide +kernel
private theorem w666_3 : checkWitness 666 true true 4646 = true := by decide +kernel
private theorem cases666 : checkFour 666 (550,4646,550,4646) = true := by
  simp only [checkFour, w666_0, w666_1, w666_2, w666_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one666 : Coverage 666 667 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases666)
private theorem w667_0 : checkWitness 667 false false 8901 = true := by decide +kernel
private theorem w667_2 : checkWitness 667 true false 8897 = true := by decide +kernel
private theorem cases667 : checkFour 667 (8901,0,8897,0) = true := by
  simp only [checkFour, w667_0, w667_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one667 : Coverage 667 668 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases667)
private theorem w668_0 : checkWitness 668 false false 8932 = true := by decide +kernel
private theorem w668_2 : checkWitness 668 true false 8923 = true := by decide +kernel
private theorem cases668 : checkFour 668 (8932,0,8923,0) = true := by
  simp only [checkFour, w668_0, w668_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one668 : Coverage 668 669 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases668)
private theorem w669_0 : checkWitness 669 false false 86 = true := by decide +kernel
private theorem w669_2 : checkWitness 669 true false 86 = true := by decide +kernel
private theorem cases669 : checkFour 669 (86,0,86,0) = true := by
  simp only [checkFour, w669_0, w669_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one669 : Coverage 669 670 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases669)
private theorem w670_0 : checkWitness 670 false false 646 = true := by decide +kernel
private theorem w670_1 : checkWitness 670 false true 4738 = true := by decide +kernel
private theorem w670_2 : checkWitness 670 true false 637 = true := by decide +kernel
private theorem w670_3 : checkWitness 670 true true 4729 = true := by decide +kernel
private theorem cases670 : checkFour 670 (646,4738,637,4729) = true := by
  simp only [checkFour, w670_0, w670_1, w670_2, w670_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one670 : Coverage 670 671 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases670)
private theorem w671_0 : checkWitness 671 false false 8897 = true := by decide +kernel
private theorem w671_2 : checkWitness 671 true false 8893 = true := by decide +kernel
private theorem cases671 : checkFour 671 (8897,0,8893,0) = true := by
  simp only [checkFour, w671_0, w671_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one671 : Coverage 671 672 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases671)
theorem cover0640 : Coverage 640 672 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one640 one641) (Coverage.join one642 one643)) (Coverage.join (Coverage.join one644 one645) (Coverage.join one646 one647))) (Coverage.join (Coverage.join (Coverage.join one648 one649) (Coverage.join one650 one651)) (Coverage.join (Coverage.join one652 one653) (Coverage.join one654 one655)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one656 one657) (Coverage.join one658 one659)) (Coverage.join (Coverage.join one660 one661) (Coverage.join one662 one663))) (Coverage.join (Coverage.join (Coverage.join one664 one665) (Coverage.join one666 one667)) (Coverage.join (Coverage.join one668 one669) (Coverage.join one670 one671)))))
end NF180PA.Symbolic
