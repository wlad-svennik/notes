import Mathlib.Tactic.NormNum
import NF181PAScannerSource
import NF181PAEightSound
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.Register181 (Reach address config vector)
open PA192.ModelSearch.Register181.Commands (atS vm refill0To24)
open NF181PA.Packed NF181PA.Scanner NF181PA.ScannerSource NF181PA.Sound
namespace NF180PA.Warm
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 4500000

noncomputable def initial (V : Type) [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] : V :=
  config 0 0 (vector 4 0 0 0 0 0 0 0 0)
noncomputable def empty (V : Type) [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] : V := state 0 0 0 0

theorem entry : Reach (initial V) (view (fresh 5 (cantor 0 5) (empty V))) := by
  have five : (4:V)+1=5 := by norm_num
  simpa [initial,view_fresh,vm24,atS,empty,top,stack,param,cache,state,left_cantor,right_cantor,five] using
    (refill0To24 (4:V) 0 0 0 0 0)

private theorem good_empty : goodState (empty V) :=
  (good_state ..).mpr ⟨provZero,goodZero,provZero⟩

private theorem no_observation {a : V} (no : ¬NF181PA.Pool.Pr (∅ : V) goal)
    (good : goodState (dataState a)) : ¬observed a := by
  intro hit
  apply no
  simpa only [Prov,goal_three,←hit.2] using good.2.2

private theorem cofinal (no : ¬NF181PA.Pool.Pr (∅ : V) goal) (j : V) :
    ∃ a d : V, j≤d ∧ Register181.run d (initial V)=view a ∧ goodState (dataState a) := by
  induction j using modelInduct with
  | defP => unfold initial dataState; definability
  | zero =>
    obtain ⟨t,ht⟩ := entry (V:=V)
    exact ⟨fresh 5 (cantor 0 5) (empty V),t,zero_le,ht,
      by simpa [fresh,dataState] using (good_empty (V:=V))⟩
  | step j ih =>
    obtain ⟨a,t,le,ht,good⟩ := ih
    obtain ⟨u,hu⟩ := actualCommand (k:=index a) (raw:=input a) (e:=dataState a) (no_observation no good)
    have pos : 0<u := lt_of_le_of_ne zero_le (fun eq => by
      rw [←eq,Register181.run_zero] at hu
      have h := congrArg Register181.address hu
      simp [vm24,vm,atS] at h)
    obtain ⟨v,hv⟩ := actualRefill (index a) (input a) (rawAction (input a) (dataState a))
    refine ⟨next a,t+u+v,le_trans (succ_le_iff_lt.mpr (lt_of_le_of_lt le (lt_add_of_pos_right _ pos))) le_self_add,?_,goodNext a good⟩
    rw [Register181.run_add,Register181.run_add,ht]
    change Register181.run v (Register181.run u (vm24 0 (index a) (dataState a) (input a)))=_
    rw [hu,hv]
    simp only [next,view_fresh,NF181PA.Scanner.control]

/-- Starting the inherited enumerator at epoch four preserves its internal refutation criterion. -/
theorem epoch_four_iff_pool : Register181.sourceHalts (initial V) ↔ NF181PA.Pool.Pr (∅ : V) goal := by
  constructor
  · rintro ⟨t,ht⟩
    by_contra no
    obtain ⟨a,c,tc,hc,_⟩ := cofinal no t
    obtain ⟨d,rfl⟩ := exists_add_of_le tc
    rw [Register181.run_add] at hc
    have frozen : ∀ n : V, address (Register181.run n (Register181.run t (initial V)))=4095 := by
      apply modelInduct
      · unfold initial; definability
      · simpa using ht
      · intro n ih
        rw [Register181.run_succ]
        exact NF181PA.Registers.next_terminal _ ih
    have impossible := frozen d
    rw [hc] at impossible
    norm_num [view,vm24,vm,atS] at impossible
  · exact halts_of_entry 5 (empty V) (initial V) entry
end NF180PA.Warm
#print axioms NF180PA.Warm.epoch_four_iff_pool
