import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1696_0 : checkWitness 1696 false false 8842 = true := by decide +kernel
private theorem w1696_2 : checkWitness 1696 true false 8838 = true := by decide +kernel
private theorem cases1696 : checkFour 1696 (8842,0,8838,0) = true := by
  simp only [checkFour, w1696_0, w1696_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1696 : Coverage 1696 1697 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1696)
private theorem w1697_0 : checkWitness 1697 false false 82 = true := by decide +kernel
private theorem w1697_2 : checkWitness 1697 true false 82 = true := by decide +kernel
private theorem cases1697 : checkFour 1697 (82,0,82,0) = true := by
  simp only [checkFour, w1697_0, w1697_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1697 : Coverage 1697 1698 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1697)
private theorem w1698_0 : checkWitness 1698 false false 510 = true := by decide +kernel
private theorem w1698_1 : checkWitness 1698 false true 4606 = true := by decide +kernel
private theorem w1698_2 : checkWitness 1698 true false 510 = true := by decide +kernel
private theorem w1698_3 : checkWitness 1698 true true 4606 = true := by decide +kernel
private theorem cases1698 : checkFour 1698 (510,4606,510,4606) = true := by
  simp only [checkFour, w1698_0, w1698_1, w1698_2, w1698_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1698 : Coverage 1698 1699 := checkList_sound (ws:=[(510,4606,510,4606)]) (by simpa only [checkList, Bool.and_true] using cases1698)
private theorem w1699_0 : checkWitness 1699 false false 8861 = true := by decide +kernel
private theorem w1699_2 : checkWitness 1699 true false 8857 = true := by decide +kernel
private theorem cases1699 : checkFour 1699 (8861,0,8857,0) = true := by
  simp only [checkFour, w1699_0, w1699_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1699 : Coverage 1699 1700 := checkList_sound (ws:=[(8861,0,8857,0)]) (by simpa only [checkList, Bool.and_true] using cases1699)
private theorem w1700_0 : checkWitness 1700 false false 8892 = true := by decide +kernel
private theorem w1700_2 : checkWitness 1700 true false 8883 = true := by decide +kernel
private theorem cases1700 : checkFour 1700 (8892,0,8883,0) = true := by
  simp only [checkFour, w1700_0, w1700_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1700 : Coverage 1700 1701 := checkList_sound (ws:=[(8892,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1700)
private theorem w1701_0 : checkWitness 1701 false false 106 = true := by decide +kernel
private theorem w1701_2 : checkWitness 1701 true false 106 = true := by decide +kernel
private theorem cases1701 : checkFour 1701 (106,0,106,0) = true := by
  simp only [checkFour, w1701_0, w1701_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1701 : Coverage 1701 1702 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1701)
private theorem w1702_0 : checkWitness 1702 false false 606 = true := by decide +kernel
private theorem w1702_1 : checkWitness 1702 false true 4698 = true := by decide +kernel
private theorem w1702_2 : checkWitness 1702 true false 597 = true := by decide +kernel
private theorem w1702_3 : checkWitness 1702 true true 4689 = true := by decide +kernel
private theorem cases1702 : checkFour 1702 (606,4698,597,4689) = true := by
  simp only [checkFour, w1702_0, w1702_1, w1702_2, w1702_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1702 : Coverage 1702 1703 := checkList_sound (ws:=[(606,4698,597,4689)]) (by simpa only [checkList, Bool.and_true] using cases1702)
private theorem w1703_0 : checkWitness 1703 false false 8857 = true := by decide +kernel
private theorem w1703_2 : checkWitness 1703 true false 8853 = true := by decide +kernel
private theorem cases1703 : checkFour 1703 (8857,0,8853,0) = true := by
  simp only [checkFour, w1703_0, w1703_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1703 : Coverage 1703 1704 := checkList_sound (ws:=[(8857,0,8853,0)]) (by simpa only [checkList, Bool.and_true] using cases1703)
private theorem w1704_0 : checkWitness 1704 false false 600 = true := by decide +kernel
private theorem w1704_1 : checkWitness 1704 false true 4692 = true := by decide +kernel
private theorem w1704_2 : checkWitness 1704 true false 591 = true := by decide +kernel
private theorem w1704_3 : checkWitness 1704 true true 4683 = true := by decide +kernel
private theorem cases1704 : checkFour 1704 (600,4692,591,4683) = true := by
  simp only [checkFour, w1704_0, w1704_1, w1704_2, w1704_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1704 : Coverage 1704 1705 := checkList_sound (ws:=[(600,4692,591,4683)]) (by simpa only [checkList, Bool.and_true] using cases1704)
private theorem w1705_0 : checkWitness 1705 false false 8828 = true := by decide +kernel
private theorem w1705_2 : checkWitness 1705 true false 8824 = true := by decide +kernel
private theorem cases1705 : checkFour 1705 (8828,0,8824,0) = true := by
  simp only [checkFour, w1705_0, w1705_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1705 : Coverage 1705 1706 := checkList_sound (ws:=[(8828,0,8824,0)]) (by simpa only [checkList, Bool.and_true] using cases1705)
private theorem w1706_0 : checkWitness 1706 false false 94 = true := by decide +kernel
private theorem w1706_2 : checkWitness 1706 true false 94 = true := by decide +kernel
private theorem cases1706 : checkFour 1706 (94,0,94,0) = true := by
  simp only [checkFour, w1706_0, w1706_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1706 : Coverage 1706 1707 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1706)
private theorem w1707_0 : checkWitness 1707 false false 86 = true := by decide +kernel
private theorem w1707_2 : checkWitness 1707 true false 86 = true := by decide +kernel
private theorem cases1707 : checkFour 1707 (86,0,86,0) = true := by
  simp only [checkFour, w1707_0, w1707_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1707 : Coverage 1707 1708 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1707)
private theorem w1708_0 : checkWitness 1708 false false 553 = true := by decide +kernel
private theorem w1708_1 : checkWitness 1708 false true 4637 = true := by decide +kernel
private theorem w1708_2 : checkWitness 1708 true false 553 = true := by decide +kernel
private theorem w1708_3 : checkWitness 1708 true true 4637 = true := by decide +kernel
private theorem cases1708 : checkFour 1708 (553,4637,553,4637) = true := by
  simp only [checkFour, w1708_0, w1708_1, w1708_2, w1708_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1708 : Coverage 1708 1709 := checkList_sound (ws:=[(553,4637,553,4637)]) (by simpa only [checkList, Bool.and_true] using cases1708)
private theorem w1709_0 : checkWitness 1709 false false 8820 = true := by decide +kernel
private theorem w1709_2 : checkWitness 1709 true false 8816 = true := by decide +kernel
private theorem cases1709 : checkFour 1709 (8820,0,8816,0) = true := by
  simp only [checkFour, w1709_0, w1709_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1709 : Coverage 1709 1710 := checkList_sound (ws:=[(8820,0,8816,0)]) (by simpa only [checkList, Bool.and_true] using cases1709)
private theorem w1710_0 : checkWitness 1710 false false 86 = true := by decide +kernel
private theorem w1710_2 : checkWitness 1710 true false 86 = true := by decide +kernel
private theorem cases1710 : checkFour 1710 (86,0,86,0) = true := by
  simp only [checkFour, w1710_0, w1710_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1710 : Coverage 1710 1711 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1710)
private theorem w1711_0 : checkWitness 1711 false false 597 = true := by decide +kernel
private theorem w1711_1 : checkWitness 1711 false true 4689 = true := by decide +kernel
private theorem w1711_2 : checkWitness 1711 true false 588 = true := by decide +kernel
private theorem w1711_3 : checkWitness 1711 true true 4680 = true := by decide +kernel
private theorem cases1711 : checkFour 1711 (597,4689,588,4680) = true := by
  simp only [checkFour, w1711_0, w1711_1, w1711_2, w1711_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1711 : Coverage 1711 1712 := checkList_sound (ws:=[(597,4689,588,4680)]) (by simpa only [checkList, Bool.and_true] using cases1711)
private theorem w1712_0 : checkWitness 1712 false false 8894 = true := by decide +kernel
private theorem w1712_2 : checkWitness 1712 true false 8885 = true := by decide +kernel
private theorem cases1712 : checkFour 1712 (8894,0,8885,0) = true := by
  simp only [checkFour, w1712_0, w1712_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1712 : Coverage 1712 1713 := checkList_sound (ws:=[(8894,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1712)
private theorem w1713_0 : checkWitness 1713 false false 8840 = true := by decide +kernel
private theorem w1713_2 : checkWitness 1713 true false 8836 = true := by decide +kernel
private theorem cases1713 : checkFour 1713 (8840,0,8836,0) = true := by
  simp only [checkFour, w1713_0, w1713_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1713 : Coverage 1713 1714 := checkList_sound (ws:=[(8840,0,8836,0)]) (by simpa only [checkList, Bool.and_true] using cases1713)
private theorem w1714_0 : checkWitness 1714 false false 90 = true := by decide +kernel
private theorem w1714_2 : checkWitness 1714 true false 90 = true := by decide +kernel
private theorem cases1714 : checkFour 1714 (90,0,90,0) = true := by
  simp only [checkFour, w1714_0, w1714_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1714 : Coverage 1714 1715 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1714)
private theorem w1715_0 : checkWitness 1715 false false 620 = true := by decide +kernel
private theorem w1715_1 : checkWitness 1715 false true 4712 = true := by decide +kernel
private theorem w1715_2 : checkWitness 1715 true false 611 = true := by decide +kernel
private theorem w1715_3 : checkWitness 1715 true true 4703 = true := by decide +kernel
private theorem cases1715 : checkFour 1715 (620,4712,611,4703) = true := by
  simp only [checkFour, w1715_0, w1715_1, w1715_2, w1715_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1715 : Coverage 1715 1716 := checkList_sound (ws:=[(620,4712,611,4703)]) (by simpa only [checkList, Bool.and_true] using cases1715)
private theorem w1716_0 : checkWitness 1716 false false 8901 = true := by decide +kernel
private theorem w1716_2 : checkWitness 1716 true false 8892 = true := by decide +kernel
private theorem cases1716 : checkFour 1716 (8901,0,8892,0) = true := by
  simp only [checkFour, w1716_0, w1716_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1716 : Coverage 1716 1717 := checkList_sound (ws:=[(8901,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases1716)
private theorem w1717_0 : checkWitness 1717 false false 74 = true := by decide +kernel
private theorem w1717_2 : checkWitness 1717 true false 74 = true := by decide +kernel
private theorem cases1717 : checkFour 1717 (74,0,74,0) = true := by
  simp only [checkFour, w1717_0, w1717_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1717 : Coverage 1717 1718 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1717)
private theorem w1718_0 : checkWitness 1718 false false 478 = true := by decide +kernel
private theorem w1718_1 : checkWitness 1718 false true 4574 = true := by decide +kernel
private theorem w1718_2 : checkWitness 1718 true false 478 = true := by decide +kernel
private theorem w1718_3 : checkWitness 1718 true true 4574 = true := by decide +kernel
private theorem cases1718 : checkFour 1718 (478,4574,478,4574) = true := by
  simp only [checkFour, w1718_0, w1718_1, w1718_2, w1718_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1718 : Coverage 1718 1719 := checkList_sound (ws:=[(478,4574,478,4574)]) (by simpa only [checkList, Bool.and_true] using cases1718)
private theorem w1719_0 : checkWitness 1719 false false 8881 = true := by decide +kernel
private theorem w1719_2 : checkWitness 1719 true false 8877 = true := by decide +kernel
private theorem cases1719 : checkFour 1719 (8881,0,8877,0) = true := by
  simp only [checkFour, w1719_0, w1719_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1719 : Coverage 1719 1720 := checkList_sound (ws:=[(8881,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases1719)
private theorem w1720_0 : checkWitness 1720 false false 610 = true := by decide +kernel
private theorem w1720_1 : checkWitness 1720 false true 4706 = true := by decide +kernel
private theorem w1720_2 : checkWitness 1720 true false 601 = true := by decide +kernel
private theorem w1720_3 : checkWitness 1720 true true 4697 = true := by decide +kernel
private theorem cases1720 : checkFour 1720 (610,4706,601,4697) = true := by
  simp only [checkFour, w1720_0, w1720_1, w1720_2, w1720_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1720 : Coverage 1720 1721 := checkList_sound (ws:=[(610,4706,601,4697)]) (by simpa only [checkList, Bool.and_true] using cases1720)
private theorem w1721_0 : checkWitness 1721 false false 172 = true := by decide +kernel
private theorem w1721_2 : checkWitness 1721 true false 172 = true := by decide +kernel
private theorem cases1721 : checkFour 1721 (172,0,172,0) = true := by
  simp only [checkFour, w1721_0, w1721_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1721 : Coverage 1721 1722 := checkList_sound (ws:=[(172,0,172,0)]) (by simpa only [checkList, Bool.and_true] using cases1721)
private theorem w1722_0 : checkWitness 1722 false false 559 = true := by decide +kernel
private theorem w1722_1 : checkWitness 1722 false true 4647 = true := by decide +kernel
private theorem w1722_2 : checkWitness 1722 true false 559 = true := by decide +kernel
private theorem w1722_3 : checkWitness 1722 true true 4647 = true := by decide +kernel
private theorem cases1722 : checkFour 1722 (559,4647,559,4647) = true := by
  simp only [checkFour, w1722_0, w1722_1, w1722_2, w1722_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1722 : Coverage 1722 1723 := checkList_sound (ws:=[(559,4647,559,4647)]) (by simpa only [checkList, Bool.and_true] using cases1722)
private theorem w1723_0 : checkWitness 1723 false false 8892 = true := by decide +kernel
private theorem w1723_2 : checkWitness 1723 true false 8883 = true := by decide +kernel
private theorem cases1723 : checkFour 1723 (8892,0,8883,0) = true := by
  simp only [checkFour, w1723_0, w1723_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1723 : Coverage 1723 1724 := checkList_sound (ws:=[(8892,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1723)
private theorem w1724_0 : checkWitness 1724 false false 92 = true := by decide +kernel
private theorem w1724_2 : checkWitness 1724 true false 92 = true := by decide +kernel
private theorem cases1724 : checkFour 1724 (92,0,92,0) = true := by
  simp only [checkFour, w1724_0, w1724_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1724 : Coverage 1724 1725 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1724)
private theorem w1725_0 : checkWitness 1725 false false 84 = true := by decide +kernel
private theorem w1725_2 : checkWitness 1725 true false 84 = true := by decide +kernel
private theorem cases1725 : checkFour 1725 (84,0,84,0) = true := by
  simp only [checkFour, w1725_0, w1725_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1725 : Coverage 1725 1726 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1725)
private theorem w1726_0 : checkWitness 1726 false false 559 = true := by decide +kernel
private theorem w1726_1 : checkWitness 1726 false true 4651 = true := by decide +kernel
private theorem w1726_2 : checkWitness 1726 true false 559 = true := by decide +kernel
private theorem w1726_3 : checkWitness 1726 true true 4651 = true := by decide +kernel
private theorem cases1726 : checkFour 1726 (559,4651,559,4651) = true := by
  simp only [checkFour, w1726_0, w1726_1, w1726_2, w1726_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1726 : Coverage 1726 1727 := checkList_sound (ws:=[(559,4651,559,4651)]) (by simpa only [checkList, Bool.and_true] using cases1726)
private theorem w1727_0 : checkWitness 1727 false false 8834 = true := by decide +kernel
private theorem w1727_2 : checkWitness 1727 true false 8830 = true := by decide +kernel
private theorem cases1727 : checkFour 1727 (8834,0,8830,0) = true := by
  simp only [checkFour, w1727_0, w1727_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1727 : Coverage 1727 1728 := checkList_sound (ws:=[(8834,0,8830,0)]) (by simpa only [checkList, Bool.and_true] using cases1727)
theorem cover1696 : Coverage 1696 1728 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1696 one1697) (Coverage.join one1698 one1699)) (Coverage.join (Coverage.join one1700 one1701) (Coverage.join one1702 one1703))) (Coverage.join (Coverage.join (Coverage.join one1704 one1705) (Coverage.join one1706 one1707)) (Coverage.join (Coverage.join one1708 one1709) (Coverage.join one1710 one1711)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1712 one1713) (Coverage.join one1714 one1715)) (Coverage.join (Coverage.join one1716 one1717) (Coverage.join one1718 one1719))) (Coverage.join (Coverage.join (Coverage.join one1720 one1721) (Coverage.join one1722 one1723)) (Coverage.join (Coverage.join one1724 one1725) (Coverage.join one1726 one1727)))))
end NF180PA.Symbolic
