import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2368_0 : checkWitness 2368 false false 78 = true := by decide +kernel
private theorem w2368_2 : checkWitness 2368 true false 78 = true := by decide +kernel
private theorem cases2368 : checkFour 2368 (78,0,78,0) = true := by
  simp only [checkFour, w2368_0, w2368_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2368 : Coverage 2368 2369 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2368)
private theorem w2369_0 : checkWitness 2369 false false 70 = true := by decide +kernel
private theorem w2369_2 : checkWitness 2369 true false 70 = true := by decide +kernel
private theorem cases2369 : checkFour 2369 (70,0,70,0) = true := by
  simp only [checkFour, w2369_0, w2369_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2369 : Coverage 2369 2370 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2369)
private theorem w2370_0 : checkWitness 2370 false false 635 = true := by decide +kernel
private theorem w2370_1 : checkWitness 2370 false true 4719 = true := by decide +kernel
private theorem w2370_2 : checkWitness 2370 true false 635 = true := by decide +kernel
private theorem w2370_3 : checkWitness 2370 true true 4719 = true := by decide +kernel
private theorem cases2370 : checkFour 2370 (635,4719,635,4719) = true := by
  simp only [checkFour, w2370_0, w2370_1, w2370_2, w2370_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2370 : Coverage 2370 2371 := checkList_sound (ws:=[(635,4719,635,4719)]) (by simpa only [checkList, Bool.and_true] using cases2370)
private theorem w2371_0 : checkWitness 2371 false false 8902 = true := by decide +kernel
private theorem w2371_2 : checkWitness 2371 true false 8898 = true := by decide +kernel
private theorem cases2371 : checkFour 2371 (8902,0,8898,0) = true := by
  simp only [checkFour, w2371_0, w2371_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2371 : Coverage 2371 2372 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases2371)
private theorem w2372_0 : checkWitness 2372 false false 70 = true := by decide +kernel
private theorem w2372_2 : checkWitness 2372 true false 70 = true := by decide +kernel
private theorem cases2372 : checkFour 2372 (70,0,70,0) = true := by
  simp only [checkFour, w2372_0, w2372_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2372 : Coverage 2372 2373 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2372)
private theorem w2373_0 : checkWitness 2373 false false 611 = true := by decide +kernel
private theorem w2373_1 : checkWitness 2373 false true 4707 = true := by decide +kernel
private theorem w2373_2 : checkWitness 2373 true false 611 = true := by decide +kernel
private theorem w2373_3 : checkWitness 2373 true true 4707 = true := by decide +kernel
private theorem cases2373 : checkFour 2373 (611,4707,611,4707) = true := by
  simp only [checkFour, w2373_0, w2373_1, w2373_2, w2373_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2373 : Coverage 2373 2374 := checkList_sound (ws:=[(611,4707,611,4707)]) (by simpa only [checkList, Bool.and_true] using cases2373)
private theorem w2374_0 : checkWitness 2374 false false 8972 = true := by decide +kernel
private theorem w2374_2 : checkWitness 2374 true false 8963 = true := by decide +kernel
private theorem cases2374 : checkFour 2374 (8972,0,8963,0) = true := by
  simp only [checkFour, w2374_0, w2374_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2374 : Coverage 2374 2375 := checkList_sound (ws:=[(8972,0,8963,0)]) (by simpa only [checkList, Bool.and_true] using cases2374)
private theorem w2375_0 : checkWitness 2375 false false 8918 = true := by decide +kernel
private theorem w2375_2 : checkWitness 2375 true false 8914 = true := by decide +kernel
private theorem cases2375 : checkFour 2375 (8918,0,8914,0) = true := by
  simp only [checkFour, w2375_0, w2375_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2375 : Coverage 2375 2376 := checkList_sound (ws:=[(8918,0,8914,0)]) (by simpa only [checkList, Bool.and_true] using cases2375)
private theorem w2376_0 : checkWitness 2376 false false 78 = true := by decide +kernel
private theorem w2376_2 : checkWitness 2376 true false 78 = true := by decide +kernel
private theorem cases2376 : checkFour 2376 (78,0,78,0) = true := by
  simp only [checkFour, w2376_0, w2376_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2376 : Coverage 2376 2377 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2376)
private theorem w2377_0 : checkWitness 2377 false false 698 = true := by decide +kernel
private theorem w2377_1 : checkWitness 2377 false true 4786 = true := by decide +kernel
private theorem w2377_2 : checkWitness 2377 true false 689 = true := by decide +kernel
private theorem w2377_3 : checkWitness 2377 true true 4777 = true := by decide +kernel
private theorem cases2377 : checkFour 2377 (698,4786,689,4777) = true := by
  simp only [checkFour, w2377_0, w2377_1, w2377_2, w2377_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2377 : Coverage 2377 2378 := checkList_sound (ws:=[(698,4786,689,4777)]) (by simpa only [checkList, Bool.and_true] using cases2377)
private theorem w2378_0 : checkWitness 2378 false false 8937 = true := by decide +kernel
private theorem w2378_2 : checkWitness 2378 true false 8933 = true := by decide +kernel
private theorem cases2378 : checkFour 2378 (8937,0,8933,0) = true := by
  simp only [checkFour, w2378_0, w2378_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2378 : Coverage 2378 2379 := checkList_sound (ws:=[(8937,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases2378)
private theorem w2379_0 : checkWitness 2379 false false 68 = true := by decide +kernel
private theorem w2379_2 : checkWitness 2379 true false 68 = true := by decide +kernel
private theorem cases2379 : checkFour 2379 (68,0,68,0) = true := by
  simp only [checkFour, w2379_0, w2379_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2379 : Coverage 2379 2380 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2379)
private theorem w2380_0 : checkWitness 2380 false false 646 = true := by decide +kernel
private theorem w2380_1 : checkWitness 2380 false true 4742 = true := by decide +kernel
private theorem w2380_2 : checkWitness 2380 true false 646 = true := by decide +kernel
private theorem w2380_3 : checkWitness 2380 true true 4742 = true := by decide +kernel
private theorem cases2380 : checkFour 2380 (646,4742,646,4742) = true := by
  simp only [checkFour, w2380_0, w2380_1, w2380_2, w2380_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2380 : Coverage 2380 2381 := checkList_sound (ws:=[(646,4742,646,4742)]) (by simpa only [checkList, Bool.and_true] using cases2380)
private theorem w2381_0 : checkWitness 2381 false false 8940 = true := by decide +kernel
private theorem w2381_2 : checkWitness 2381 true false 8931 = true := by decide +kernel
private theorem cases2381 : checkFour 2381 (8940,0,8931,0) = true := by
  simp only [checkFour, w2381_0, w2381_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2381 : Coverage 2381 2382 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases2381)
private theorem w2382_0 : checkWitness 2382 false false 58 = true := by decide +kernel
private theorem w2382_2 : checkWitness 2382 true false 58 = true := by decide +kernel
private theorem cases2382 : checkFour 2382 (58,0,58,0) = true := by
  simp only [checkFour, w2382_0, w2382_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2382 : Coverage 2382 2383 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2382)
private theorem w2383_0 : checkWitness 2383 false false 518 = true := by decide +kernel
private theorem w2383_1 : checkWitness 2383 false true 4614 = true := by decide +kernel
private theorem w2383_2 : checkWitness 2383 true false 518 = true := by decide +kernel
private theorem w2383_3 : checkWitness 2383 true true 4614 = true := by decide +kernel
private theorem cases2383 : checkFour 2383 (518,4614,518,4614) = true := by
  simp only [checkFour, w2383_0, w2383_1, w2383_2, w2383_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2383 : Coverage 2383 2384 := checkList_sound (ws:=[(518,4614,518,4614)]) (by simpa only [checkList, Bool.and_true] using cases2383)
private theorem w2384_0 : checkWitness 2384 false false 8892 = true := by decide +kernel
private theorem w2384_2 : checkWitness 2384 true false 8888 = true := by decide +kernel
private theorem cases2384 : checkFour 2384 (8892,0,8888,0) = true := by
  simp only [checkFour, w2384_0, w2384_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2384 : Coverage 2384 2385 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2384)
private theorem w2385_0 : checkWitness 2385 false false 62 = true := by decide +kernel
private theorem w2385_2 : checkWitness 2385 true false 62 = true := by decide +kernel
private theorem cases2385 : checkFour 2385 (62,0,62,0) = true := by
  simp only [checkFour, w2385_0, w2385_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2385 : Coverage 2385 2386 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2385)
private theorem w2386_0 : checkWitness 2386 false false 560 = true := by decide +kernel
private theorem w2386_1 : checkWitness 2386 false true 4656 = true := by decide +kernel
private theorem w2386_2 : checkWitness 2386 true false 560 = true := by decide +kernel
private theorem w2386_3 : checkWitness 2386 true true 4656 = true := by decide +kernel
private theorem cases2386 : checkFour 2386 (560,4656,560,4656) = true := by
  simp only [checkFour, w2386_0, w2386_1, w2386_2, w2386_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2386 : Coverage 2386 2387 := checkList_sound (ws:=[(560,4656,560,4656)]) (by simpa only [checkList, Bool.and_true] using cases2386)
private theorem w2387_0 : checkWitness 2387 false false 8911 = true := by decide +kernel
private theorem w2387_2 : checkWitness 2387 true false 8907 = true := by decide +kernel
private theorem cases2387 : checkFour 2387 (8911,0,8907,0) = true := by
  simp only [checkFour, w2387_0, w2387_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2387 : Coverage 2387 2388 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases2387)
private theorem w2388_0 : checkWitness 2388 false false 8942 = true := by decide +kernel
private theorem w2388_2 : checkWitness 2388 true false 8933 = true := by decide +kernel
private theorem cases2388 : checkFour 2388 (8942,0,8933,0) = true := by
  simp only [checkFour, w2388_0, w2388_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2388 : Coverage 2388 2389 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases2388)
private theorem w2389_0 : checkWitness 2389 false false 86 = true := by decide +kernel
private theorem w2389_2 : checkWitness 2389 true false 86 = true := by decide +kernel
private theorem cases2389 : checkFour 2389 (86,0,86,0) = true := by
  simp only [checkFour, w2389_0, w2389_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2389 : Coverage 2389 2390 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases2389)
private theorem w2390_0 : checkWitness 2390 false false 656 = true := by decide +kernel
private theorem w2390_1 : checkWitness 2390 false true 4748 = true := by decide +kernel
private theorem w2390_2 : checkWitness 2390 true false 647 = true := by decide +kernel
private theorem w2390_3 : checkWitness 2390 true true 4739 = true := by decide +kernel
private theorem cases2390 : checkFour 2390 (656,4748,647,4739) = true := by
  simp only [checkFour, w2390_0, w2390_1, w2390_2, w2390_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2390 : Coverage 2390 2391 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases2390)
private theorem w2391_0 : checkWitness 2391 false false 8907 = true := by decide +kernel
private theorem w2391_2 : checkWitness 2391 true false 8903 = true := by decide +kernel
private theorem cases2391 : checkFour 2391 (8907,0,8903,0) = true := by
  simp only [checkFour, w2391_0, w2391_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2391 : Coverage 2391 2392 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases2391)
private theorem w2392_0 : checkWitness 2392 false false 650 = true := by decide +kernel
private theorem w2392_1 : checkWitness 2392 false true 4742 = true := by decide +kernel
private theorem w2392_2 : checkWitness 2392 true false 641 = true := by decide +kernel
private theorem w2392_3 : checkWitness 2392 true true 4733 = true := by decide +kernel
private theorem cases2392 : checkFour 2392 (650,4742,641,4733) = true := by
  simp only [checkFour, w2392_0, w2392_1, w2392_2, w2392_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2392 : Coverage 2392 2393 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases2392)
private theorem w2393_0 : checkWitness 2393 false false 8878 = true := by decide +kernel
private theorem w2393_2 : checkWitness 2393 true false 8874 = true := by decide +kernel
private theorem cases2393 : checkFour 2393 (8878,0,8874,0) = true := by
  simp only [checkFour, w2393_0, w2393_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2393 : Coverage 2393 2394 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases2393)
private theorem w2394_0 : checkWitness 2394 false false 74 = true := by decide +kernel
private theorem w2394_2 : checkWitness 2394 true false 74 = true := by decide +kernel
private theorem cases2394 : checkFour 2394 (74,0,74,0) = true := by
  simp only [checkFour, w2394_0, w2394_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2394 : Coverage 2394 2395 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2394)
private theorem w2395_0 : checkWitness 2395 false false 66 = true := by decide +kernel
private theorem w2395_2 : checkWitness 2395 true false 66 = true := by decide +kernel
private theorem cases2395 : checkFour 2395 (66,0,66,0) = true := by
  simp only [checkFour, w2395_0, w2395_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2395 : Coverage 2395 2396 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2395)
private theorem w2396_0 : checkWitness 2396 false false 603 = true := by decide +kernel
private theorem w2396_1 : checkWitness 2396 false true 4687 = true := by decide +kernel
private theorem w2396_2 : checkWitness 2396 true false 603 = true := by decide +kernel
private theorem w2396_3 : checkWitness 2396 true true 4687 = true := by decide +kernel
private theorem cases2396 : checkFour 2396 (603,4687,603,4687) = true := by
  simp only [checkFour, w2396_0, w2396_1, w2396_2, w2396_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2396 : Coverage 2396 2397 := checkList_sound (ws:=[(603,4687,603,4687)]) (by simpa only [checkList, Bool.and_true] using cases2396)
private theorem w2397_0 : checkWitness 2397 false false 8870 = true := by decide +kernel
private theorem w2397_2 : checkWitness 2397 true false 8866 = true := by decide +kernel
private theorem cases2397 : checkFour 2397 (8870,0,8866,0) = true := by
  simp only [checkFour, w2397_0, w2397_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2397 : Coverage 2397 2398 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases2397)
private theorem w2398_0 : checkWitness 2398 false false 66 = true := by decide +kernel
private theorem w2398_2 : checkWitness 2398 true false 66 = true := by decide +kernel
private theorem cases2398 : checkFour 2398 (66,0,66,0) = true := by
  simp only [checkFour, w2398_0, w2398_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2398 : Coverage 2398 2399 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2398)
private theorem w2399_0 : checkWitness 2399 false false 647 = true := by decide +kernel
private theorem w2399_1 : checkWitness 2399 false true 4739 = true := by decide +kernel
private theorem w2399_2 : checkWitness 2399 true false 638 = true := by decide +kernel
private theorem w2399_3 : checkWitness 2399 true true 4730 = true := by decide +kernel
private theorem cases2399 : checkFour 2399 (647,4739,638,4730) = true := by
  simp only [checkFour, w2399_0, w2399_1, w2399_2, w2399_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2399 : Coverage 2399 2400 := checkList_sound (ws:=[(647,4739,638,4730)]) (by simpa only [checkList, Bool.and_true] using cases2399)
theorem cover2368 : Coverage 2368 2400 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2368 one2369) (Coverage.join one2370 one2371)) (Coverage.join (Coverage.join one2372 one2373) (Coverage.join one2374 one2375))) (Coverage.join (Coverage.join (Coverage.join one2376 one2377) (Coverage.join one2378 one2379)) (Coverage.join (Coverage.join one2380 one2381) (Coverage.join one2382 one2383)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2384 one2385) (Coverage.join one2386 one2387)) (Coverage.join (Coverage.join one2388 one2389) (Coverage.join one2390 one2391))) (Coverage.join (Coverage.join (Coverage.join one2392 one2393) (Coverage.join one2394 one2395)) (Coverage.join (Coverage.join one2396 one2397) (Coverage.join one2398 one2399)))))
end NF180PA.Symbolic
