import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2880_0 : checkWitness 2880 false false 8970 = true := by decide +kernel
private theorem w2880_2 : checkWitness 2880 true false 8961 = true := by decide +kernel
private theorem cases2880 : checkFour 2880 (8970,0,8961,0) = true := by
  simp only [checkFour, w2880_0, w2880_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2880 : Coverage 2880 2881 := checkList_sound (ws:=[(8970,0,8961,0)]) (by simpa only [checkList, Bool.and_true] using cases2880)
private theorem w2881_0 : checkWitness 2881 false false 48 = true := by decide +kernel
private theorem w2881_2 : checkWitness 2881 true false 48 = true := by decide +kernel
private theorem cases2881 : checkFour 2881 (48,0,48,0) = true := by
  simp only [checkFour, w2881_0, w2881_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2881 : Coverage 2881 2882 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2881)
private theorem w2882_0 : checkWitness 2882 false false 40 = true := by decide +kernel
private theorem w2882_2 : checkWitness 2882 true false 40 = true := by decide +kernel
private theorem cases2882 : checkFour 2882 (40,0,40,0) = true := by
  simp only [checkFour, w2882_0, w2882_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2882 : Coverage 2882 2883 := checkList_sound (ws:=[(40,0,40,0)]) (by simpa only [checkList, Bool.and_true] using cases2882)
private theorem w2883_0 : checkWitness 2883 false false 637 = true := by decide +kernel
private theorem w2883_1 : checkWitness 2883 false true 4729 = true := by decide +kernel
private theorem w2883_2 : checkWitness 2883 true false 637 = true := by decide +kernel
private theorem w2883_3 : checkWitness 2883 true true 4729 = true := by decide +kernel
private theorem cases2883 : checkFour 2883 (637,4729,637,4729) = true := by
  simp only [checkFour, w2883_0, w2883_1, w2883_2, w2883_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2883 : Coverage 2883 2884 := checkList_sound (ws:=[(637,4729,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases2883)
private theorem w2884_0 : checkWitness 2884 false false 8912 = true := by decide +kernel
private theorem w2884_2 : checkWitness 2884 true false 8908 = true := by decide +kernel
private theorem cases2884 : checkFour 2884 (8912,0,8908,0) = true := by
  simp only [checkFour, w2884_0, w2884_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2884 : Coverage 2884 2885 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases2884)
private theorem w2885_0 : checkWitness 2885 false false 40 = true := by decide +kernel
private theorem w2885_2 : checkWitness 2885 true false 40 = true := by decide +kernel
private theorem cases2885 : checkFour 2885 (40,0,40,0) = true := by
  simp only [checkFour, w2885_0, w2885_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2885 : Coverage 2885 2886 := checkList_sound (ws:=[(40,0,40,0)]) (by simpa only [checkList, Bool.and_true] using cases2885)
private theorem w2886_0 : checkWitness 2886 false false 596 = true := by decide +kernel
private theorem w2886_1 : checkWitness 2886 false true 4692 = true := by decide +kernel
private theorem w2886_2 : checkWitness 2886 true false 596 = true := by decide +kernel
private theorem w2886_3 : checkWitness 2886 true true 4692 = true := by decide +kernel
private theorem cases2886 : checkFour 2886 (596,4692,596,4692) = true := by
  simp only [checkFour, w2886_0, w2886_1, w2886_2, w2886_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2886 : Coverage 2886 2887 := checkList_sound (ws:=[(596,4692,596,4692)]) (by simpa only [checkList, Bool.and_true] using cases2886)
private theorem w2887_0 : checkWitness 2887 false false 8947 = true := by decide +kernel
private theorem w2887_2 : checkWitness 2887 true false 8943 = true := by decide +kernel
private theorem cases2887 : checkFour 2887 (8947,0,8943,0) = true := by
  simp only [checkFour, w2887_0, w2887_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2887 : Coverage 2887 2888 := checkList_sound (ws:=[(8947,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases2887)
private theorem w2888_0 : checkWitness 2888 false false 8978 = true := by decide +kernel
private theorem w2888_2 : checkWitness 2888 true false 8969 = true := by decide +kernel
private theorem cases2888 : checkFour 2888 (8978,0,8969,0) = true := by
  simp only [checkFour, w2888_0, w2888_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2888 : Coverage 2888 2889 := checkList_sound (ws:=[(8978,0,8969,0)]) (by simpa only [checkList, Bool.and_true] using cases2888)
private theorem w2889_0 : checkWitness 2889 false false 58 = true := by decide +kernel
private theorem w2889_2 : checkWitness 2889 true false 58 = true := by decide +kernel
private theorem cases2889 : checkFour 2889 (58,0,58,0) = true := by
  simp only [checkFour, w2889_0, w2889_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2889 : Coverage 2889 2890 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2889)
private theorem w2890_0 : checkWitness 2890 false false 692 = true := by decide +kernel
private theorem w2890_1 : checkWitness 2890 false true 4784 = true := by decide +kernel
private theorem w2890_2 : checkWitness 2890 true false 683 = true := by decide +kernel
private theorem w2890_3 : checkWitness 2890 true true 4775 = true := by decide +kernel
private theorem cases2890 : checkFour 2890 (692,4784,683,4775) = true := by
  simp only [checkFour, w2890_0, w2890_1, w2890_2, w2890_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2890 : Coverage 2890 2891 := checkList_sound (ws:=[(692,4784,683,4775)]) (by simpa only [checkList, Bool.and_true] using cases2890)
private theorem w2891_0 : checkWitness 2891 false false 8943 = true := by decide +kernel
private theorem w2891_2 : checkWitness 2891 true false 8939 = true := by decide +kernel
private theorem cases2891 : checkFour 2891 (8943,0,8939,0) = true := by
  simp only [checkFour, w2891_0, w2891_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2891 : Coverage 2891 2892 := checkList_sound (ws:=[(8943,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2891)
private theorem w2892_0 : checkWitness 2892 false false 686 = true := by decide +kernel
private theorem w2892_1 : checkWitness 2892 false true 4778 = true := by decide +kernel
private theorem w2892_2 : checkWitness 2892 true false 677 = true := by decide +kernel
private theorem w2892_3 : checkWitness 2892 true true 4769 = true := by decide +kernel
private theorem cases2892 : checkFour 2892 (686,4778,677,4769) = true := by
  simp only [checkFour, w2892_0, w2892_1, w2892_2, w2892_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2892 : Coverage 2892 2893 := checkList_sound (ws:=[(686,4778,677,4769)]) (by simpa only [checkList, Bool.and_true] using cases2892)
private theorem w2893_0 : checkWitness 2893 false false 8914 = true := by decide +kernel
private theorem w2893_2 : checkWitness 2893 true false 8910 = true := by decide +kernel
private theorem cases2893 : checkFour 2893 (8914,0,8910,0) = true := by
  simp only [checkFour, w2893_0, w2893_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2893 : Coverage 2893 2894 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases2893)
private theorem w2894_0 : checkWitness 2894 false false 46 = true := by decide +kernel
private theorem w2894_2 : checkWitness 2894 true false 46 = true := by decide +kernel
private theorem cases2894 : checkFour 2894 (46,0,46,0) = true := by
  simp only [checkFour, w2894_0, w2894_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2894 : Coverage 2894 2895 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2894)
private theorem w2895_0 : checkWitness 2895 false false 38 = true := by decide +kernel
private theorem w2895_2 : checkWitness 2895 true false 38 = true := by decide +kernel
private theorem cases2895 : checkFour 2895 (38,0,38,0) = true := by
  simp only [checkFour, w2895_0, w2895_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2895 : Coverage 2895 2896 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases2895)
private theorem w2896_0 : checkWitness 2896 false false 651 = true := by decide +kernel
private theorem w2896_1 : checkWitness 2896 false true 4735 = true := by decide +kernel
private theorem w2896_2 : checkWitness 2896 true false 651 = true := by decide +kernel
private theorem w2896_3 : checkWitness 2896 true true 4735 = true := by decide +kernel
private theorem cases2896 : checkFour 2896 (651,4735,651,4735) = true := by
  simp only [checkFour, w2896_0, w2896_1, w2896_2, w2896_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2896 : Coverage 2896 2897 := checkList_sound (ws:=[(651,4735,651,4735)]) (by simpa only [checkList, Bool.and_true] using cases2896)
private theorem w2897_0 : checkWitness 2897 false false 8930 = true := by decide +kernel
private theorem w2897_2 : checkWitness 2897 true false 8926 = true := by decide +kernel
private theorem cases2897 : checkFour 2897 (8930,0,8926,0) = true := by
  simp only [checkFour, w2897_0, w2897_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2897 : Coverage 2897 2898 := checkList_sound (ws:=[(8930,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases2897)
private theorem w2898_0 : checkWitness 2898 false false 8926 = true := by decide +kernel
private theorem w2898_2 : checkWitness 2898 true false 8922 = true := by decide +kernel
private theorem cases2898 : checkFour 2898 (8926,0,8922,0) = true := by
  simp only [checkFour, w2898_0, w2898_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2898 : Coverage 2898 2899 := checkList_sound (ws:=[(8926,0,8922,0)]) (by simpa only [checkList, Bool.and_true] using cases2898)
private theorem w2899_0 : checkWitness 2899 false false 52 = true := by decide +kernel
private theorem w2899_2 : checkWitness 2899 true false 52 = true := by decide +kernel
private theorem cases2899 : checkFour 2899 (52,0,52,0) = true := by
  simp only [checkFour, w2899_0, w2899_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2899 : Coverage 2899 2900 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2899)
private theorem w2900_0 : checkWitness 2900 false false 604 = true := by decide +kernel
private theorem w2900_1 : checkWitness 2900 false true 4700 = true := by decide +kernel
private theorem w2900_2 : checkWitness 2900 true false 604 = true := by decide +kernel
private theorem w2900_3 : checkWitness 2900 true true 4700 = true := by decide +kernel
private theorem cases2900 : checkFour 2900 (604,4700,604,4700) = true := by
  simp only [checkFour, w2900_0, w2900_1, w2900_2, w2900_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2900 : Coverage 2900 2901 := checkList_sound (ws:=[(604,4700,604,4700)]) (by simpa only [checkList, Bool.and_true] using cases2900)
private theorem w2901_0 : checkWitness 2901 false false 8978 = true := by decide +kernel
private theorem w2901_2 : checkWitness 2901 true false 8969 = true := by decide +kernel
private theorem cases2901 : checkFour 2901 (8978,0,8969,0) = true := by
  simp only [checkFour, w2901_0, w2901_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2901 : Coverage 2901 2902 := checkList_sound (ws:=[(8978,0,8969,0)]) (by simpa only [checkList, Bool.and_true] using cases2901)
private theorem w2902_0 : checkWitness 2902 false false 34 = true := by decide +kernel
private theorem w2902_2 : checkWitness 2902 true false 34 = true := by decide +kernel
private theorem cases2902 : checkFour 2902 (34,0,34,0) = true := by
  simp only [checkFour, w2902_0, w2902_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2902 : Coverage 2902 2903 := checkList_sound (ws:=[(34,0,34,0)]) (by simpa only [checkList, Bool.and_true] using cases2902)
private theorem w2903_0 : checkWitness 2903 false false 700 = true := by decide +kernel
private theorem w2903_1 : checkWitness 2903 false true 4792 = true := by decide +kernel
private theorem w2903_2 : checkWitness 2903 true false 691 = true := by decide +kernel
private theorem w2903_3 : checkWitness 2903 true true 4783 = true := by decide +kernel
private theorem cases2903 : checkFour 2903 (700,4792,691,4783) = true := by
  simp only [checkFour, w2903_0, w2903_1, w2903_2, w2903_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2903 : Coverage 2903 2904 := checkList_sound (ws:=[(700,4792,691,4783)]) (by simpa only [checkList, Bool.and_true] using cases2903)
private theorem w2904_0 : checkWitness 2904 false false 663 = true := by decide +kernel
private theorem w2904_1 : checkWitness 2904 false true 4759 = true := by decide +kernel
private theorem w2904_2 : checkWitness 2904 true false 654 = true := by decide +kernel
private theorem w2904_3 : checkWitness 2904 true true 4750 = true := by decide +kernel
private theorem cases2904 : checkFour 2904 (663,4759,654,4750) = true := by
  simp only [checkFour, w2904_0, w2904_1, w2904_2, w2904_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2904 : Coverage 2904 2905 := checkList_sound (ws:=[(663,4759,654,4750)]) (by simpa only [checkList, Bool.and_true] using cases2904)
private theorem w2905_0 : checkWitness 2905 false false 46 = true := by decide +kernel
private theorem w2905_2 : checkWitness 2905 true false 46 = true := by decide +kernel
private theorem cases2905 : checkFour 2905 (46,0,46,0) = true := by
  simp only [checkFour, w2905_0, w2905_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2905 : Coverage 2905 2906 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2905)
private theorem w2906_0 : checkWitness 2906 false false 8971 = true := by decide +kernel
private theorem w2906_2 : checkWitness 2906 true false 8962 = true := by decide +kernel
private theorem cases2906 : checkFour 2906 (8971,0,8962,0) = true := by
  simp only [checkFour, w2906_0, w2906_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2906 : Coverage 2906 2907 := checkList_sound (ws:=[(8971,0,8962,0)]) (by simpa only [checkList, Bool.and_true] using cases2906)
private theorem w2907_0 : checkWitness 2907 false false 700 = true := by decide +kernel
private theorem w2907_1 : checkWitness 2907 false true 4780 = true := by decide +kernel
private theorem w2907_2 : checkWitness 2907 true false 691 = true := by decide +kernel
private theorem w2907_3 : checkWitness 2907 true true 4771 = true := by decide +kernel
private theorem cases2907 : checkFour 2907 (700,4780,691,4771) = true := by
  simp only [checkFour, w2907_0, w2907_1, w2907_2, w2907_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2907 : Coverage 2907 2908 := checkList_sound (ws:=[(700,4780,691,4771)]) (by simpa only [checkList, Bool.and_true] using cases2907)
private theorem w2908_0 : checkWitness 2908 false false 8969 = true := by decide +kernel
private theorem w2908_2 : checkWitness 2908 true false 8960 = true := by decide +kernel
private theorem cases2908 : checkFour 2908 (8969,0,8960,0) = true := by
  simp only [checkFour, w2908_0, w2908_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2908 : Coverage 2908 2909 := checkList_sound (ws:=[(8969,0,8960,0)]) (by simpa only [checkList, Bool.and_true] using cases2908)
private theorem w2909_0 : checkWitness 2909 false false 40 = true := by decide +kernel
private theorem w2909_2 : checkWitness 2909 true false 40 = true := by decide +kernel
private theorem cases2909 : checkFour 2909 (40,0,40,0) = true := by
  simp only [checkFour, w2909_0, w2909_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2909 : Coverage 2909 2910 := checkList_sound (ws:=[(40,0,40,0)]) (by simpa only [checkList, Bool.and_true] using cases2909)
private theorem w2910_0 : checkWitness 2910 false false 667 = true := by decide +kernel
private theorem w2910_1 : checkWitness 2910 false true 4763 = true := by decide +kernel
private theorem w2910_2 : checkWitness 2910 true false 658 = true := by decide +kernel
private theorem w2910_3 : checkWitness 2910 true true 4754 = true := by decide +kernel
private theorem cases2910 : checkFour 2910 (667,4763,658,4754) = true := by
  simp only [checkFour, w2910_0, w2910_1, w2910_2, w2910_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2910 : Coverage 2910 2911 := checkList_sound (ws:=[(667,4763,658,4754)]) (by simpa only [checkList, Bool.and_true] using cases2910)
private theorem w2911_0 : checkWitness 2911 false false 214 = true := by decide +kernel
private theorem w2911_2 : checkWitness 2911 true false 214 = true := by decide +kernel
private theorem cases2911 : checkFour 2911 (214,0,214,0) = true := by
  simp only [checkFour, w2911_0, w2911_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2911 : Coverage 2911 2912 := checkList_sound (ws:=[(214,0,214,0)]) (by simpa only [checkList, Bool.and_true] using cases2911)
theorem cover2880 : Coverage 2880 2912 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2880 one2881) (Coverage.join one2882 one2883)) (Coverage.join (Coverage.join one2884 one2885) (Coverage.join one2886 one2887))) (Coverage.join (Coverage.join (Coverage.join one2888 one2889) (Coverage.join one2890 one2891)) (Coverage.join (Coverage.join one2892 one2893) (Coverage.join one2894 one2895)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2896 one2897) (Coverage.join one2898 one2899)) (Coverage.join (Coverage.join one2900 one2901) (Coverage.join one2902 one2903))) (Coverage.join (Coverage.join (Coverage.join one2904 one2905) (Coverage.join one2906 one2907)) (Coverage.join (Coverage.join one2908 one2909) (Coverage.join one2910 one2911)))))
end NF180PA.Symbolic
