import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w192_0 : checkWitness 192 false false 8886 = true := by decide +kernel
private theorem w192_2 : checkWitness 192 true false 8882 = true := by decide +kernel
private theorem cases192 : checkFour 192 (8886,0,8882,0) = true := by
  simp only [checkFour, w192_0, w192_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one192 : Coverage 192 193 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases192)
private theorem w193_0 : checkWitness 193 false false 8882 = true := by decide +kernel
private theorem w193_2 : checkWitness 193 true false 8878 = true := by decide +kernel
private theorem cases193 : checkFour 193 (8882,0,8878,0) = true := by
  simp only [checkFour, w193_0, w193_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one193 : Coverage 193 194 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases193)
private theorem w194_0 : checkWitness 194 false false 74 = true := by decide +kernel
private theorem w194_2 : checkWitness 194 true false 74 = true := by decide +kernel
private theorem cases194 : checkFour 194 (74,0,74,0) = true := by
  simp only [checkFour, w194_0, w194_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one194 : Coverage 194 195 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases194)
private theorem w195_0 : checkWitness 195 false false 658 = true := by decide +kernel
private theorem w195_1 : checkWitness 195 false true 4754 = true := by decide +kernel
private theorem w195_2 : checkWitness 195 true false 658 = true := by decide +kernel
private theorem w195_3 : checkWitness 195 true true 4754 = true := by decide +kernel
private theorem cases195 : checkFour 195 (658,4754,658,4754) = true := by
  simp only [checkFour, w195_0, w195_1, w195_2, w195_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one195 : Coverage 195 196 := checkList_sound (ws:=[(658,4754,658,4754)]) (by simpa only [checkList, Bool.and_true] using cases195)
private theorem w196_0 : checkWitness 196 false false 8944 = true := by decide +kernel
private theorem w196_2 : checkWitness 196 true false 8935 = true := by decide +kernel
private theorem cases196 : checkFour 196 (8944,0,8935,0) = true := by
  simp only [checkFour, w196_0, w196_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one196 : Coverage 196 197 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases196)
private theorem w197_0 : checkWitness 197 false false 66 = true := by decide +kernel
private theorem w197_2 : checkWitness 197 true false 66 = true := by decide +kernel
private theorem cases197 : checkFour 197 (66,0,66,0) = true := by
  simp only [checkFour, w197_0, w197_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one197 : Coverage 197 198 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases197)
private theorem w198_0 : checkWitness 198 false false 522 = true := by decide +kernel
private theorem w198_1 : checkWitness 198 false true 4618 = true := by decide +kernel
private theorem w198_2 : checkWitness 198 true false 522 = true := by decide +kernel
private theorem w198_3 : checkWitness 198 true true 4618 = true := by decide +kernel
private theorem cases198 : checkFour 198 (522,4618,522,4618) = true := by
  simp only [checkFour, w198_0, w198_1, w198_2, w198_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one198 : Coverage 198 199 := checkList_sound (ws:=[(522,4618,522,4618)]) (by simpa only [checkList, Bool.and_true] using cases198)
private theorem w199_0 : checkWitness 199 false false 8896 = true := by decide +kernel
private theorem w199_2 : checkWitness 199 true false 8892 = true := by decide +kernel
private theorem cases199 : checkFour 199 (8896,0,8892,0) = true := by
  simp only [checkFour, w199_0, w199_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one199 : Coverage 199 200 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases199)
private theorem w200_0 : checkWitness 200 false false 70 = true := by decide +kernel
private theorem w200_2 : checkWitness 200 true false 70 = true := by decide +kernel
private theorem cases200 : checkFour 200 (70,0,70,0) = true := by
  simp only [checkFour, w200_0, w200_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one200 : Coverage 200 201 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases200)
private theorem w201_0 : checkWitness 201 false false 564 = true := by decide +kernel
private theorem w201_1 : checkWitness 201 false true 4660 = true := by decide +kernel
private theorem w201_2 : checkWitness 201 true false 564 = true := by decide +kernel
private theorem w201_3 : checkWitness 201 true true 4660 = true := by decide +kernel
private theorem cases201 : checkFour 201 (564,4660,564,4660) = true := by
  simp only [checkFour, w201_0, w201_1, w201_2, w201_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one201 : Coverage 201 202 := checkList_sound (ws:=[(564,4660,564,4660)]) (by simpa only [checkList, Bool.and_true] using cases201)
private theorem w202_0 : checkWitness 202 false false 8915 = true := by decide +kernel
private theorem w202_2 : checkWitness 202 true false 8911 = true := by decide +kernel
private theorem cases202 : checkFour 202 (8915,0,8911,0) = true := by
  simp only [checkFour, w202_0, w202_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one202 : Coverage 202 203 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases202)
private theorem w203_0 : checkWitness 203 false false 8946 = true := by decide +kernel
private theorem w203_2 : checkWitness 203 true false 8937 = true := by decide +kernel
private theorem cases203 : checkFour 203 (8946,0,8937,0) = true := by
  simp only [checkFour, w203_0, w203_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one203 : Coverage 203 204 := checkList_sound (ws:=[(8946,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases203)
private theorem w204_0 : checkWitness 204 false false 94 = true := by decide +kernel
private theorem w204_2 : checkWitness 204 true false 94 = true := by decide +kernel
private theorem cases204 : checkFour 204 (94,0,94,0) = true := by
  simp only [checkFour, w204_0, w204_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one204 : Coverage 204 205 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases204)
private theorem w205_0 : checkWitness 205 false false 660 = true := by decide +kernel
private theorem w205_1 : checkWitness 205 false true 4752 = true := by decide +kernel
private theorem w205_2 : checkWitness 205 true false 651 = true := by decide +kernel
private theorem w205_3 : checkWitness 205 true true 4743 = true := by decide +kernel
private theorem cases205 : checkFour 205 (660,4752,651,4743) = true := by
  simp only [checkFour, w205_0, w205_1, w205_2, w205_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one205 : Coverage 205 206 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases205)
private theorem w206_0 : checkWitness 206 false false 8911 = true := by decide +kernel
private theorem w206_2 : checkWitness 206 true false 8907 = true := by decide +kernel
private theorem cases206 : checkFour 206 (8911,0,8907,0) = true := by
  simp only [checkFour, w206_0, w206_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one206 : Coverage 206 207 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases206)
private theorem w207_0 : checkWitness 207 false false 654 = true := by decide +kernel
private theorem w207_1 : checkWitness 207 false true 4746 = true := by decide +kernel
private theorem w207_2 : checkWitness 207 true false 645 = true := by decide +kernel
private theorem w207_3 : checkWitness 207 true true 4737 = true := by decide +kernel
private theorem cases207 : checkFour 207 (654,4746,645,4737) = true := by
  simp only [checkFour, w207_0, w207_1, w207_2, w207_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one207 : Coverage 207 208 := checkList_sound (ws:=[(654,4746,645,4737)]) (by simpa only [checkList, Bool.and_true] using cases207)
private theorem w208_0 : checkWitness 208 false false 8882 = true := by decide +kernel
private theorem w208_2 : checkWitness 208 true false 8878 = true := by decide +kernel
private theorem cases208 : checkFour 208 (8882,0,8878,0) = true := by
  simp only [checkFour, w208_0, w208_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one208 : Coverage 208 209 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases208)
private theorem w209_0 : checkWitness 209 false false 82 = true := by decide +kernel
private theorem w209_2 : checkWitness 209 true false 82 = true := by decide +kernel
private theorem cases209 : checkFour 209 (82,0,82,0) = true := by
  simp only [checkFour, w209_0, w209_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one209 : Coverage 209 210 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases209)
private theorem w210_0 : checkWitness 210 false false 74 = true := by decide +kernel
private theorem w210_2 : checkWitness 210 true false 74 = true := by decide +kernel
private theorem cases210 : checkFour 210 (74,0,74,0) = true := by
  simp only [checkFour, w210_0, w210_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one210 : Coverage 210 211 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases210)
private theorem w211_0 : checkWitness 211 false false 607 = true := by decide +kernel
private theorem w211_1 : checkWitness 211 false true 4691 = true := by decide +kernel
private theorem w211_2 : checkWitness 211 true false 607 = true := by decide +kernel
private theorem w211_3 : checkWitness 211 true true 4691 = true := by decide +kernel
private theorem cases211 : checkFour 211 (607,4691,607,4691) = true := by
  simp only [checkFour, w211_0, w211_1, w211_2, w211_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one211 : Coverage 211 212 := checkList_sound (ws:=[(607,4691,607,4691)]) (by simpa only [checkList, Bool.and_true] using cases211)
private theorem w212_0 : checkWitness 212 false false 8874 = true := by decide +kernel
private theorem w212_2 : checkWitness 212 true false 8870 = true := by decide +kernel
private theorem cases212 : checkFour 212 (8874,0,8870,0) = true := by
  simp only [checkFour, w212_0, w212_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one212 : Coverage 212 213 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases212)
private theorem w213_0 : checkWitness 213 false false 74 = true := by decide +kernel
private theorem w213_2 : checkWitness 213 true false 74 = true := by decide +kernel
private theorem cases213 : checkFour 213 (74,0,74,0) = true := by
  simp only [checkFour, w213_0, w213_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one213 : Coverage 213 214 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases213)
private theorem w214_0 : checkWitness 214 false false 583 = true := by decide +kernel
private theorem w214_1 : checkWitness 214 false true 4679 = true := by decide +kernel
private theorem w214_2 : checkWitness 214 true false 583 = true := by decide +kernel
private theorem w214_3 : checkWitness 214 true true 4679 = true := by decide +kernel
private theorem cases214 : checkFour 214 (583,4679,583,4679) = true := by
  simp only [checkFour, w214_0, w214_1, w214_2, w214_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one214 : Coverage 214 215 := checkList_sound (ws:=[(583,4679,583,4679)]) (by simpa only [checkList, Bool.and_true] using cases214)
private theorem w215_0 : checkWitness 215 false false 8944 = true := by decide +kernel
private theorem w215_2 : checkWitness 215 true false 8935 = true := by decide +kernel
private theorem cases215 : checkFour 215 (8944,0,8935,0) = true := by
  simp only [checkFour, w215_0, w215_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one215 : Coverage 215 216 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases215)
private theorem w216_0 : checkWitness 216 false false 8890 = true := by decide +kernel
private theorem w216_2 : checkWitness 216 true false 8886 = true := by decide +kernel
private theorem cases216 : checkFour 216 (8890,0,8886,0) = true := by
  simp only [checkFour, w216_0, w216_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one216 : Coverage 216 217 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases216)
private theorem w217_0 : checkWitness 217 false false 82 = true := by decide +kernel
private theorem w217_2 : checkWitness 217 true false 82 = true := by decide +kernel
private theorem cases217 : checkFour 217 (82,0,82,0) = true := by
  simp only [checkFour, w217_0, w217_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one217 : Coverage 217 218 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases217)
private theorem w218_0 : checkWitness 218 false false 670 = true := by decide +kernel
private theorem w218_1 : checkWitness 218 false true 4758 = true := by decide +kernel
private theorem w218_2 : checkWitness 218 true false 661 = true := by decide +kernel
private theorem w218_3 : checkWitness 218 true true 4749 = true := by decide +kernel
private theorem cases218 : checkFour 218 (670,4758,661,4749) = true := by
  simp only [checkFour, w218_0, w218_1, w218_2, w218_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one218 : Coverage 218 219 := checkList_sound (ws:=[(670,4758,661,4749)]) (by simpa only [checkList, Bool.and_true] using cases218)
private theorem w219_0 : checkWitness 219 false false 8909 = true := by decide +kernel
private theorem w219_2 : checkWitness 219 true false 8905 = true := by decide +kernel
private theorem cases219 : checkFour 219 (8909,0,8905,0) = true := by
  simp only [checkFour, w219_0, w219_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one219 : Coverage 219 220 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases219)
private theorem w220_0 : checkWitness 220 false false 72 = true := by decide +kernel
private theorem w220_2 : checkWitness 220 true false 72 = true := by decide +kernel
private theorem cases220 : checkFour 220 (72,0,72,0) = true := by
  simp only [checkFour, w220_0, w220_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one220 : Coverage 220 221 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases220)
private theorem w221_0 : checkWitness 221 false false 630 = true := by decide +kernel
private theorem w221_1 : checkWitness 221 false true 4726 = true := by decide +kernel
private theorem w221_2 : checkWitness 221 true false 630 = true := by decide +kernel
private theorem w221_3 : checkWitness 221 true true 4726 = true := by decide +kernel
private theorem cases221 : checkFour 221 (630,4726,630,4726) = true := by
  simp only [checkFour, w221_0, w221_1, w221_2, w221_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one221 : Coverage 221 222 := checkList_sound (ws:=[(630,4726,630,4726)]) (by simpa only [checkList, Bool.and_true] using cases221)
private theorem w222_0 : checkWitness 222 false false 8918 = true := by decide +kernel
private theorem w222_2 : checkWitness 222 true false 8909 = true := by decide +kernel
private theorem cases222 : checkFour 222 (8918,0,8909,0) = true := by
  simp only [checkFour, w222_0, w222_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one222 : Coverage 222 223 := checkList_sound (ws:=[(8918,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases222)
private theorem w223_0 : checkWitness 223 false false 64 = true := by decide +kernel
private theorem w223_2 : checkWitness 223 true false 64 = true := by decide +kernel
private theorem cases223 : checkFour 223 (64,0,64,0) = true := by
  simp only [checkFour, w223_0, w223_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one223 : Coverage 223 224 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases223)
theorem cover0192 : Coverage 192 224 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one192 one193) (Coverage.join one194 one195)) (Coverage.join (Coverage.join one196 one197) (Coverage.join one198 one199))) (Coverage.join (Coverage.join (Coverage.join one200 one201) (Coverage.join one202 one203)) (Coverage.join (Coverage.join one204 one205) (Coverage.join one206 one207)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one208 one209) (Coverage.join one210 one211)) (Coverage.join (Coverage.join one212 one213) (Coverage.join one214 one215))) (Coverage.join (Coverage.join (Coverage.join one216 one217) (Coverage.join one218 one219)) (Coverage.join (Coverage.join one220 one221) (Coverage.join one222 one223)))))
end NF180PA.Symbolic
