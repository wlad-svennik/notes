import NF179TableAudit
import ScannerFrames

namespace NF179.Startup
open NF210.TM Blank180.Table Blank180.Boot

/-- The exact first and working-margin register frames of the literal 179-state table. -/
theorem exact_frames :
    run machine 41065 (blank start) = firstBoundary.config ∧
    run machine 230892 (blank start) = marginBoundary.config :=
  ⟨blank_first_frame, blank_margin_frame⟩

theorem epoch_five_layout :
    marginBoundary.head = -10 ∧ marginBoundary.address = [false,false,false,false] ∧
    marginBoundary.gap = 97 ∧ marginBoundary.spares = 78 ∧
    marginBoundary.registers = [5,0,0,0,0,0,0,0,0] := by decide

theorem live_through_startup {t : Nat} (ht : t ≤ 230892) :
    (run machine t (blank start)).state ≠ none := by
  intro bad
  have stopped := halting_persists machine start t (230892-t) bad
  rw [Nat.add_sub_of_le ht, blank_margin_frame] at stopped
  contradiction

#print axioms exact_frames
#print axioms epoch_five_layout
#print axioms live_through_startup
end NF179.Startup
