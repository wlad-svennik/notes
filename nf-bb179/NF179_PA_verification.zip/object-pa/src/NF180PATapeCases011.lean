import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w352_0 : checkWitness 352 false false 194 = true := by decide +kernel
private theorem w352_2 : checkWitness 352 true false 194 = true := by decide +kernel
private theorem cases352 : checkFour 352 (194,0,194,0) = true := by
  simp only [checkFour, w352_0, w352_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one352 : Coverage 352 353 := checkList_sound (ws:=[(194,0,194,0)]) (by simpa only [checkList, Bool.and_true] using cases352)
private theorem w353_0 : checkWitness 353 false false 603 = true := by decide +kernel
private theorem w353_1 : checkWitness 353 false true 4691 = true := by decide +kernel
private theorem w353_2 : checkWitness 353 true false 603 = true := by decide +kernel
private theorem w353_3 : checkWitness 353 true true 4691 = true := by decide +kernel
private theorem cases353 : checkFour 353 (603,4691,603,4691) = true := by
  simp only [checkFour, w353_0, w353_1, w353_2, w353_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one353 : Coverage 353 354 := checkList_sound (ws:=[(603,4691,603,4691)]) (by simpa only [checkList, Bool.and_true] using cases353)
private theorem w354_0 : checkWitness 354 false false 8936 = true := by decide +kernel
private theorem w354_2 : checkWitness 354 true false 8927 = true := by decide +kernel
private theorem cases354 : checkFour 354 (8936,0,8927,0) = true := by
  simp only [checkFour, w354_0, w354_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one354 : Coverage 354 355 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases354)
private theorem w355_0 : checkWitness 355 false false 70 = true := by decide +kernel
private theorem w355_2 : checkWitness 355 true false 70 = true := by decide +kernel
private theorem cases355 : checkFour 355 (70,0,70,0) = true := by
  simp only [checkFour, w355_0, w355_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one355 : Coverage 355 356 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases355)
private theorem w356_0 : checkWitness 356 false false 62 = true := by decide +kernel
private theorem w356_2 : checkWitness 356 true false 62 = true := by decide +kernel
private theorem cases356 : checkFour 356 (62,0,62,0) = true := by
  simp only [checkFour, w356_0, w356_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one356 : Coverage 356 357 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases356)
private theorem w357_0 : checkWitness 357 false false 603 = true := by decide +kernel
private theorem w357_1 : checkWitness 357 false true 4695 = true := by decide +kernel
private theorem w357_2 : checkWitness 357 true false 603 = true := by decide +kernel
private theorem w357_3 : checkWitness 357 true true 4695 = true := by decide +kernel
private theorem cases357 : checkFour 357 (603,4695,603,4695) = true := by
  simp only [checkFour, w357_0, w357_1, w357_2, w357_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one357 : Coverage 357 358 := checkList_sound (ws:=[(603,4695,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases357)
private theorem w358_0 : checkWitness 358 false false 8878 = true := by decide +kernel
private theorem w358_2 : checkWitness 358 true false 8874 = true := by decide +kernel
private theorem cases358 : checkFour 358 (8878,0,8874,0) = true := by
  simp only [checkFour, w358_0, w358_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one358 : Coverage 358 359 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases358)
private theorem w359_0 : checkWitness 359 false false 62 = true := by decide +kernel
private theorem w359_2 : checkWitness 359 true false 62 = true := by decide +kernel
private theorem cases359 : checkFour 359 (62,0,62,0) = true := by
  simp only [checkFour, w359_0, w359_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one359 : Coverage 359 360 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases359)
private theorem w360_0 : checkWitness 360 false false 562 = true := by decide +kernel
private theorem w360_1 : checkWitness 360 false true 4658 = true := by decide +kernel
private theorem w360_2 : checkWitness 360 true false 562 = true := by decide +kernel
private theorem w360_3 : checkWitness 360 true true 4658 = true := by decide +kernel
private theorem cases360 : checkFour 360 (562,4658,562,4658) = true := by
  simp only [checkFour, w360_0, w360_1, w360_2, w360_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one360 : Coverage 360 361 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases360)
private theorem w361_0 : checkWitness 361 false false 8913 = true := by decide +kernel
private theorem w361_2 : checkWitness 361 true false 8909 = true := by decide +kernel
private theorem cases361 : checkFour 361 (8913,0,8909,0) = true := by
  simp only [checkFour, w361_0, w361_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one361 : Coverage 361 362 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases361)
private theorem w362_0 : checkWitness 362 false false 8944 = true := by decide +kernel
private theorem w362_2 : checkWitness 362 true false 8935 = true := by decide +kernel
private theorem cases362 : checkFour 362 (8944,0,8935,0) = true := by
  simp only [checkFour, w362_0, w362_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one362 : Coverage 362 363 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases362)
private theorem w363_0 : checkWitness 363 false false 80 = true := by decide +kernel
private theorem w363_2 : checkWitness 363 true false 80 = true := by decide +kernel
private theorem cases363 : checkFour 363 (80,0,80,0) = true := by
  simp only [checkFour, w363_0, w363_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one363 : Coverage 363 364 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases363)
private theorem w364_0 : checkWitness 364 false false 658 = true := by decide +kernel
private theorem w364_1 : checkWitness 364 false true 4750 = true := by decide +kernel
private theorem w364_2 : checkWitness 364 true false 649 = true := by decide +kernel
private theorem w364_3 : checkWitness 364 true true 4741 = true := by decide +kernel
private theorem cases364 : checkFour 364 (658,4750,649,4741) = true := by
  simp only [checkFour, w364_0, w364_1, w364_2, w364_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one364 : Coverage 364 365 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases364)
private theorem w365_0 : checkWitness 365 false false 8909 = true := by decide +kernel
private theorem w365_2 : checkWitness 365 true false 8905 = true := by decide +kernel
private theorem cases365 : checkFour 365 (8909,0,8905,0) = true := by
  simp only [checkFour, w365_0, w365_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one365 : Coverage 365 366 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases365)
private theorem w366_0 : checkWitness 366 false false 652 = true := by decide +kernel
private theorem w366_1 : checkWitness 366 false true 4744 = true := by decide +kernel
private theorem w366_2 : checkWitness 366 true false 643 = true := by decide +kernel
private theorem w366_3 : checkWitness 366 true true 4735 = true := by decide +kernel
private theorem cases366 : checkFour 366 (652,4744,643,4735) = true := by
  simp only [checkFour, w366_0, w366_1, w366_2, w366_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one366 : Coverage 366 367 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases366)
private theorem w367_0 : checkWitness 367 false false 8880 = true := by decide +kernel
private theorem w367_2 : checkWitness 367 true false 8876 = true := by decide +kernel
private theorem cases367 : checkFour 367 (8880,0,8876,0) = true := by
  simp only [checkFour, w367_0, w367_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one367 : Coverage 367 368 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases367)
private theorem w368_0 : checkWitness 368 false false 68 = true := by decide +kernel
private theorem w368_2 : checkWitness 368 true false 68 = true := by decide +kernel
private theorem cases368 : checkFour 368 (68,0,68,0) = true := by
  simp only [checkFour, w368_0, w368_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one368 : Coverage 368 369 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases368)
private theorem w369_0 : checkWitness 369 false false 60 = true := by decide +kernel
private theorem w369_2 : checkWitness 369 true false 60 = true := by decide +kernel
private theorem cases369 : checkFour 369 (60,0,60,0) = true := by
  simp only [checkFour, w369_0, w369_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one369 : Coverage 369 370 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases369)
private theorem w370_0 : checkWitness 370 false false 613 = true := by decide +kernel
private theorem w370_1 : checkWitness 370 false true 4701 = true := by decide +kernel
private theorem w370_2 : checkWitness 370 true false 613 = true := by decide +kernel
private theorem w370_3 : checkWitness 370 true true 4701 = true := by decide +kernel
private theorem cases370 : checkFour 370 (613,4701,613,4701) = true := by
  simp only [checkFour, w370_0, w370_1, w370_2, w370_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one370 : Coverage 370 371 := checkList_sound (ws:=[(613,4701,613,4701)]) (by simpa only [checkList, Bool.and_true] using cases370)
private theorem w371_0 : checkWitness 371 false false 8896 = true := by decide +kernel
private theorem w371_2 : checkWitness 371 true false 8892 = true := by decide +kernel
private theorem cases371 : checkFour 371 (8896,0,8892,0) = true := by
  simp only [checkFour, w371_0, w371_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one371 : Coverage 371 372 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases371)
private theorem w372_0 : checkWitness 372 false false 8892 = true := by decide +kernel
private theorem w372_2 : checkWitness 372 true false 8888 = true := by decide +kernel
private theorem cases372 : checkFour 372 (8892,0,8888,0) = true := by
  simp only [checkFour, w372_0, w372_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one372 : Coverage 372 373 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases372)
private theorem w373_0 : checkWitness 373 false false 74 = true := by decide +kernel
private theorem w373_2 : checkWitness 373 true false 74 = true := by decide +kernel
private theorem cases373 : checkFour 373 (74,0,74,0) = true := by
  simp only [checkFour, w373_0, w373_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one373 : Coverage 373 374 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases373)
private theorem w374_0 : checkWitness 374 false false 522 = true := by decide +kernel
private theorem w374_1 : checkWitness 374 false true 4618 = true := by decide +kernel
private theorem w374_2 : checkWitness 374 true false 522 = true := by decide +kernel
private theorem w374_3 : checkWitness 374 true true 4618 = true := by decide +kernel
private theorem cases374 : checkFour 374 (522,4618,522,4618) = true := by
  simp only [checkFour, w374_0, w374_1, w374_2, w374_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one374 : Coverage 374 375 := checkList_sound (ws:=[(522,4618,522,4618)]) (by simpa only [checkList, Bool.and_true] using cases374)
private theorem w375_0 : checkWitness 375 false false 8925 = true := by decide +kernel
private theorem w375_2 : checkWitness 375 true false 8921 = true := by decide +kernel
private theorem cases375 : checkFour 375 (8925,0,8921,0) = true := by
  simp only [checkFour, w375_0, w375_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one375 : Coverage 375 376 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases375)
private theorem w376_0 : checkWitness 376 false false 654 = true := by decide +kernel
private theorem w376_1 : checkWitness 376 false true 4750 = true := by decide +kernel
private theorem w376_2 : checkWitness 376 true false 645 = true := by decide +kernel
private theorem w376_3 : checkWitness 376 true true 4741 = true := by decide +kernel
private theorem cases376 : checkFour 376 (654,4750,645,4741) = true := by
  simp only [checkFour, w376_0, w376_1, w376_2, w376_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one376 : Coverage 376 377 := checkList_sound (ws:=[(654,4750,645,4741)]) (by simpa only [checkList, Bool.and_true] using cases376)
private theorem w377_0 : checkWitness 377 false false 194 = true := by decide +kernel
private theorem w377_2 : checkWitness 377 true false 194 = true := by decide +kernel
private theorem cases377 : checkFour 377 (194,0,194,0) = true := by
  simp only [checkFour, w377_0, w377_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one377 : Coverage 377 378 := checkList_sound (ws:=[(194,0,194,0)]) (by simpa only [checkList, Bool.and_true] using cases377)
private theorem w378_0 : checkWitness 378 false false 603 = true := by decide +kernel
private theorem w378_1 : checkWitness 378 false true 4691 = true := by decide +kernel
private theorem w378_2 : checkWitness 378 true false 603 = true := by decide +kernel
private theorem w378_3 : checkWitness 378 true true 4691 = true := by decide +kernel
private theorem cases378 : checkFour 378 (603,4691,603,4691) = true := by
  simp only [checkFour, w378_0, w378_1, w378_2, w378_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one378 : Coverage 378 379 := checkList_sound (ws:=[(603,4691,603,4691)]) (by simpa only [checkList, Bool.and_true] using cases378)
private theorem w379_0 : checkWitness 379 false false 8936 = true := by decide +kernel
private theorem w379_2 : checkWitness 379 true false 8927 = true := by decide +kernel
private theorem cases379 : checkFour 379 (8936,0,8927,0) = true := by
  simp only [checkFour, w379_0, w379_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one379 : Coverage 379 380 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases379)
private theorem w380_0 : checkWitness 380 false false 70 = true := by decide +kernel
private theorem w380_2 : checkWitness 380 true false 70 = true := by decide +kernel
private theorem cases380 : checkFour 380 (70,0,70,0) = true := by
  simp only [checkFour, w380_0, w380_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one380 : Coverage 380 381 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases380)
private theorem w381_0 : checkWitness 381 false false 62 = true := by decide +kernel
private theorem w381_2 : checkWitness 381 true false 62 = true := by decide +kernel
private theorem cases381 : checkFour 381 (62,0,62,0) = true := by
  simp only [checkFour, w381_0, w381_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one381 : Coverage 381 382 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases381)
private theorem w382_0 : checkWitness 382 false false 603 = true := by decide +kernel
private theorem w382_1 : checkWitness 382 false true 4695 = true := by decide +kernel
private theorem w382_2 : checkWitness 382 true false 603 = true := by decide +kernel
private theorem w382_3 : checkWitness 382 true true 4695 = true := by decide +kernel
private theorem cases382 : checkFour 382 (603,4695,603,4695) = true := by
  simp only [checkFour, w382_0, w382_1, w382_2, w382_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one382 : Coverage 382 383 := checkList_sound (ws:=[(603,4695,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases382)
private theorem w383_0 : checkWitness 383 false false 8878 = true := by decide +kernel
private theorem w383_2 : checkWitness 383 true false 8874 = true := by decide +kernel
private theorem cases383 : checkFour 383 (8878,0,8874,0) = true := by
  simp only [checkFour, w383_0, w383_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one383 : Coverage 383 384 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases383)
theorem cover0352 : Coverage 352 384 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one352 one353) (Coverage.join one354 one355)) (Coverage.join (Coverage.join one356 one357) (Coverage.join one358 one359))) (Coverage.join (Coverage.join (Coverage.join one360 one361) (Coverage.join one362 one363)) (Coverage.join (Coverage.join one364 one365) (Coverage.join one366 one367)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one368 one369) (Coverage.join one370 one371)) (Coverage.join (Coverage.join one372 one373) (Coverage.join one374 one375))) (Coverage.join (Coverage.join (Coverage.join one376 one377) (Coverage.join one378 one379)) (Coverage.join (Coverage.join one380 one381) (Coverage.join one382 one383)))))
end NF180PA.Symbolic
