import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1376_0 : checkWitness 1376 false false 565 = true := by decide +kernel
private theorem w1376_1 : checkWitness 1376 false true 4653 = true := by decide +kernel
private theorem w1376_2 : checkWitness 1376 true false 565 = true := by decide +kernel
private theorem w1376_3 : checkWitness 1376 true true 4653 = true := by decide +kernel
private theorem cases1376 : checkFour 1376 (565,4653,565,4653) = true := by
  simp only [checkFour, w1376_0, w1376_1, w1376_2, w1376_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1376 : Coverage 1376 1377 := checkList_sound (ws:=[(565,4653,565,4653)]) (by simpa only [checkList, Bool.and_true] using cases1376)
private theorem w1377_0 : checkWitness 1377 false false 8848 = true := by decide +kernel
private theorem w1377_2 : checkWitness 1377 true false 8844 = true := by decide +kernel
private theorem cases1377 : checkFour 1377 (8848,0,8844,0) = true := by
  simp only [checkFour, w1377_0, w1377_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1377 : Coverage 1377 1378 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases1377)
private theorem w1378_0 : checkWitness 1378 false false 8844 = true := by decide +kernel
private theorem w1378_2 : checkWitness 1378 true false 8840 = true := by decide +kernel
private theorem cases1378 : checkFour 1378 (8844,0,8840,0) = true := by
  simp only [checkFour, w1378_0, w1378_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1378 : Coverage 1378 1379 := checkList_sound (ws:=[(8844,0,8840,0)]) (by simpa only [checkList, Bool.and_true] using cases1378)
private theorem w1379_0 : checkWitness 1379 false false 98 = true := by decide +kernel
private theorem w1379_2 : checkWitness 1379 true false 98 = true := by decide +kernel
private theorem cases1379 : checkFour 1379 (98,0,98,0) = true := by
  simp only [checkFour, w1379_0, w1379_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1379 : Coverage 1379 1380 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1379)
private theorem w1380_0 : checkWitness 1380 false false 8868 = true := by decide +kernel
private theorem w1380_2 : checkWitness 1380 true false 8864 = true := by decide +kernel
private theorem cases1380 : checkFour 1380 (8868,0,8864,0) = true := by
  simp only [checkFour, w1380_0, w1380_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1380 : Coverage 1380 1381 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases1380)
private theorem w1381_0 : checkWitness 1381 false false 626 = true := by decide +kernel
private theorem w1381_1 : checkWitness 1381 false true 4722 = true := by decide +kernel
private theorem w1381_2 : checkWitness 1381 true false 626 = true := by decide +kernel
private theorem w1381_3 : checkWitness 1381 true true 4722 = true := by decide +kernel
private theorem cases1381 : checkFour 1381 (626,4722,626,4722) = true := by
  simp only [checkFour, w1381_0, w1381_1, w1381_2, w1381_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1381 : Coverage 1381 1382 := checkList_sound (ws:=[(626,4722,626,4722)]) (by simpa only [checkList, Bool.and_true] using cases1381)
private theorem w1382_0 : checkWitness 1382 false false 8900 = true := by decide +kernel
private theorem w1382_2 : checkWitness 1382 true false 8891 = true := by decide +kernel
private theorem cases1382 : checkFour 1382 (8900,0,8891,0) = true := by
  simp only [checkFour, w1382_0, w1382_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1382 : Coverage 1382 1383 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1382)
private theorem w1383_0 : checkWitness 1383 false false 78 = true := by decide +kernel
private theorem w1383_2 : checkWitness 1383 true false 78 = true := by decide +kernel
private theorem cases1383 : checkFour 1383 (78,0,78,0) = true := by
  simp only [checkFour, w1383_0, w1383_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1383 : Coverage 1383 1384 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1383)
private theorem w1384_0 : checkWitness 1384 false false 478 = true := by decide +kernel
private theorem w1384_1 : checkWitness 1384 false true 4574 = true := by decide +kernel
private theorem w1384_2 : checkWitness 1384 true false 478 = true := by decide +kernel
private theorem w1384_3 : checkWitness 1384 true true 4574 = true := by decide +kernel
private theorem cases1384 : checkFour 1384 (478,4574,478,4574) = true := by
  simp only [checkFour, w1384_0, w1384_1, w1384_2, w1384_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1384 : Coverage 1384 1385 := checkList_sound (ws:=[(478,4574,478,4574)]) (by simpa only [checkList, Bool.and_true] using cases1384)
private theorem w1385_0 : checkWitness 1385 false false 8852 = true := by decide +kernel
private theorem w1385_2 : checkWitness 1385 true false 8848 = true := by decide +kernel
private theorem cases1385 : checkFour 1385 (8852,0,8848,0) = true := by
  simp only [checkFour, w1385_0, w1385_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1385 : Coverage 1385 1386 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1385)
private theorem w1386_0 : checkWitness 1386 false false 82 = true := by decide +kernel
private theorem w1386_2 : checkWitness 1386 true false 82 = true := by decide +kernel
private theorem cases1386 : checkFour 1386 (82,0,82,0) = true := by
  simp only [checkFour, w1386_0, w1386_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1386 : Coverage 1386 1387 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1386)
private theorem w1387_0 : checkWitness 1387 false false 520 = true := by decide +kernel
private theorem w1387_1 : checkWitness 1387 false true 4616 = true := by decide +kernel
private theorem w1387_2 : checkWitness 1387 true false 520 = true := by decide +kernel
private theorem w1387_3 : checkWitness 1387 true true 4616 = true := by decide +kernel
private theorem cases1387 : checkFour 1387 (520,4616,520,4616) = true := by
  simp only [checkFour, w1387_0, w1387_1, w1387_2, w1387_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1387 : Coverage 1387 1388 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases1387)
private theorem w1388_0 : checkWitness 1388 false false 8871 = true := by decide +kernel
private theorem w1388_2 : checkWitness 1388 true false 8867 = true := by decide +kernel
private theorem cases1388 : checkFour 1388 (8871,0,8867,0) = true := by
  simp only [checkFour, w1388_0, w1388_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1388 : Coverage 1388 1389 := checkList_sound (ws:=[(8871,0,8867,0)]) (by simpa only [checkList, Bool.and_true] using cases1388)
private theorem w1389_0 : checkWitness 1389 false false 8902 = true := by decide +kernel
private theorem w1389_2 : checkWitness 1389 true false 8893 = true := by decide +kernel
private theorem cases1389 : checkFour 1389 (8902,0,8893,0) = true := by
  simp only [checkFour, w1389_0, w1389_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1389 : Coverage 1389 1390 := checkList_sound (ws:=[(8902,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases1389)
private theorem w1390_0 : checkWitness 1390 false false 106 = true := by decide +kernel
private theorem w1390_2 : checkWitness 1390 true false 106 = true := by decide +kernel
private theorem cases1390 : checkFour 1390 (106,0,106,0) = true := by
  simp only [checkFour, w1390_0, w1390_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1390 : Coverage 1390 1391 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1390)
private theorem w1391_0 : checkWitness 1391 false false 616 = true := by decide +kernel
private theorem w1391_1 : checkWitness 1391 false true 4708 = true := by decide +kernel
private theorem w1391_2 : checkWitness 1391 true false 607 = true := by decide +kernel
private theorem w1391_3 : checkWitness 1391 true true 4699 = true := by decide +kernel
private theorem cases1391 : checkFour 1391 (616,4708,607,4699) = true := by
  simp only [checkFour, w1391_0, w1391_1, w1391_2, w1391_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1391 : Coverage 1391 1392 := checkList_sound (ws:=[(616,4708,607,4699)]) (by simpa only [checkList, Bool.and_true] using cases1391)
private theorem w1392_0 : checkWitness 1392 false false 8867 = true := by decide +kernel
private theorem w1392_2 : checkWitness 1392 true false 8863 = true := by decide +kernel
private theorem cases1392 : checkFour 1392 (8867,0,8863,0) = true := by
  simp only [checkFour, w1392_0, w1392_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1392 : Coverage 1392 1393 := checkList_sound (ws:=[(8867,0,8863,0)]) (by simpa only [checkList, Bool.and_true] using cases1392)
private theorem w1393_0 : checkWitness 1393 false false 610 = true := by decide +kernel
private theorem w1393_1 : checkWitness 1393 false true 4702 = true := by decide +kernel
private theorem w1393_2 : checkWitness 1393 true false 601 = true := by decide +kernel
private theorem w1393_3 : checkWitness 1393 true true 4693 = true := by decide +kernel
private theorem cases1393 : checkFour 1393 (610,4702,601,4693) = true := by
  simp only [checkFour, w1393_0, w1393_1, w1393_2, w1393_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1393 : Coverage 1393 1394 := checkList_sound (ws:=[(610,4702,601,4693)]) (by simpa only [checkList, Bool.and_true] using cases1393)
private theorem w1394_0 : checkWitness 1394 false false 8838 = true := by decide +kernel
private theorem w1394_2 : checkWitness 1394 true false 8834 = true := by decide +kernel
private theorem cases1394 : checkFour 1394 (8838,0,8834,0) = true := by
  simp only [checkFour, w1394_0, w1394_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1394 : Coverage 1394 1395 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1394)
private theorem w1395_0 : checkWitness 1395 false false 94 = true := by decide +kernel
private theorem w1395_2 : checkWitness 1395 true false 94 = true := by decide +kernel
private theorem cases1395 : checkFour 1395 (94,0,94,0) = true := by
  simp only [checkFour, w1395_0, w1395_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1395 : Coverage 1395 1396 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1395)
private theorem w1396_0 : checkWitness 1396 false false 86 = true := by decide +kernel
private theorem w1396_2 : checkWitness 1396 true false 86 = true := by decide +kernel
private theorem cases1396 : checkFour 1396 (86,0,86,0) = true := by
  simp only [checkFour, w1396_0, w1396_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1396 : Coverage 1396 1397 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1396)
private theorem w1397_0 : checkWitness 1397 false false 563 = true := by decide +kernel
private theorem w1397_1 : checkWitness 1397 false true 4647 = true := by decide +kernel
private theorem w1397_2 : checkWitness 1397 true false 563 = true := by decide +kernel
private theorem w1397_3 : checkWitness 1397 true true 4647 = true := by decide +kernel
private theorem cases1397 : checkFour 1397 (563,4647,563,4647) = true := by
  simp only [checkFour, w1397_0, w1397_1, w1397_2, w1397_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1397 : Coverage 1397 1398 := checkList_sound (ws:=[(563,4647,563,4647)]) (by simpa only [checkList, Bool.and_true] using cases1397)
private theorem w1398_0 : checkWitness 1398 false false 8830 = true := by decide +kernel
private theorem w1398_2 : checkWitness 1398 true false 8826 = true := by decide +kernel
private theorem cases1398 : checkFour 1398 (8830,0,8826,0) = true := by
  simp only [checkFour, w1398_0, w1398_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1398 : Coverage 1398 1399 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1398)
private theorem w1399_0 : checkWitness 1399 false false 86 = true := by decide +kernel
private theorem w1399_2 : checkWitness 1399 true false 86 = true := by decide +kernel
private theorem cases1399 : checkFour 1399 (86,0,86,0) = true := by
  simp only [checkFour, w1399_0, w1399_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1399 : Coverage 1399 1400 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1399)
private theorem w1400_0 : checkWitness 1400 false false 539 = true := by decide +kernel
private theorem w1400_1 : checkWitness 1400 false true 4635 = true := by decide +kernel
private theorem w1400_2 : checkWitness 1400 true false 539 = true := by decide +kernel
private theorem w1400_3 : checkWitness 1400 true true 4635 = true := by decide +kernel
private theorem cases1400 : checkFour 1400 (539,4635,539,4635) = true := by
  simp only [checkFour, w1400_0, w1400_1, w1400_2, w1400_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1400 : Coverage 1400 1401 := checkList_sound (ws:=[(539,4635,539,4635)]) (by simpa only [checkList, Bool.and_true] using cases1400)
private theorem w1401_0 : checkWitness 1401 false false 8900 = true := by decide +kernel
private theorem w1401_2 : checkWitness 1401 true false 8891 = true := by decide +kernel
private theorem cases1401 : checkFour 1401 (8900,0,8891,0) = true := by
  simp only [checkFour, w1401_0, w1401_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1401 : Coverage 1401 1402 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1401)
private theorem w1402_0 : checkWitness 1402 false false 8846 = true := by decide +kernel
private theorem w1402_2 : checkWitness 1402 true false 8842 = true := by decide +kernel
private theorem cases1402 : checkFour 1402 (8846,0,8842,0) = true := by
  simp only [checkFour, w1402_0, w1402_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1402 : Coverage 1402 1403 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1402)
private theorem w1403_0 : checkWitness 1403 false false 94 = true := by decide +kernel
private theorem w1403_2 : checkWitness 1403 true false 94 = true := by decide +kernel
private theorem cases1403 : checkFour 1403 (94,0,94,0) = true := by
  simp only [checkFour, w1403_0, w1403_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1403 : Coverage 1403 1404 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1403)
private theorem w1404_0 : checkWitness 1404 false false 626 = true := by decide +kernel
private theorem w1404_1 : checkWitness 1404 false true 4714 = true := by decide +kernel
private theorem w1404_2 : checkWitness 1404 true false 617 = true := by decide +kernel
private theorem w1404_3 : checkWitness 1404 true true 4705 = true := by decide +kernel
private theorem cases1404 : checkFour 1404 (626,4714,617,4705) = true := by
  simp only [checkFour, w1404_0, w1404_1, w1404_2, w1404_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1404 : Coverage 1404 1405 := checkList_sound (ws:=[(626,4714,617,4705)]) (by simpa only [checkList, Bool.and_true] using cases1404)
private theorem w1405_0 : checkWitness 1405 false false 8865 = true := by decide +kernel
private theorem w1405_2 : checkWitness 1405 true false 8861 = true := by decide +kernel
private theorem cases1405 : checkFour 1405 (8865,0,8861,0) = true := by
  simp only [checkFour, w1405_0, w1405_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1405 : Coverage 1405 1406 := checkList_sound (ws:=[(8865,0,8861,0)]) (by simpa only [checkList, Bool.and_true] using cases1405)
private theorem w1406_0 : checkWitness 1406 false false 84 = true := by decide +kernel
private theorem w1406_2 : checkWitness 1406 true false 84 = true := by decide +kernel
private theorem cases1406 : checkFour 1406 (84,0,84,0) = true := by
  simp only [checkFour, w1406_0, w1406_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1406 : Coverage 1406 1407 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1406)
private theorem w1407_0 : checkWitness 1407 false false 534 = true := by decide +kernel
private theorem w1407_1 : checkWitness 1407 false true 4630 = true := by decide +kernel
private theorem w1407_2 : checkWitness 1407 true false 534 = true := by decide +kernel
private theorem w1407_3 : checkWitness 1407 true true 4630 = true := by decide +kernel
private theorem cases1407 : checkFour 1407 (534,4630,534,4630) = true := by
  simp only [checkFour, w1407_0, w1407_1, w1407_2, w1407_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1407 : Coverage 1407 1408 := checkList_sound (ws:=[(534,4630,534,4630)]) (by simpa only [checkList, Bool.and_true] using cases1407)
theorem cover1376 : Coverage 1376 1408 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1376 one1377) (Coverage.join one1378 one1379)) (Coverage.join (Coverage.join one1380 one1381) (Coverage.join one1382 one1383))) (Coverage.join (Coverage.join (Coverage.join one1384 one1385) (Coverage.join one1386 one1387)) (Coverage.join (Coverage.join one1388 one1389) (Coverage.join one1390 one1391)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1392 one1393) (Coverage.join one1394 one1395)) (Coverage.join (Coverage.join one1396 one1397) (Coverage.join one1398 one1399))) (Coverage.join (Coverage.join (Coverage.join one1400 one1401) (Coverage.join one1402 one1403)) (Coverage.join (Coverage.join one1404 one1405) (Coverage.join one1406 one1407)))))
end NF180PA.Symbolic
