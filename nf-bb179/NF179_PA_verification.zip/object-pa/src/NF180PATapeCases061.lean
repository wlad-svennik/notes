import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1952_0 : checkWitness 1952 false false 583 = true := by decide +kernel
private theorem w1952_1 : checkWitness 1952 false true 4675 = true := by decide +kernel
private theorem w1952_2 : checkWitness 1952 true false 583 = true := by decide +kernel
private theorem w1952_3 : checkWitness 1952 true true 4675 = true := by decide +kernel
private theorem cases1952 : checkFour 1952 (583,4675,583,4675) = true := by
  simp only [checkFour, w1952_0, w1952_1, w1952_2, w1952_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1952 : Coverage 1952 1953 := checkList_sound (ws:=[(583,4675,583,4675)]) (by simpa only [checkList, Bool.and_true] using cases1952)
private theorem w1953_0 : checkWitness 1953 false false 8858 = true := by decide +kernel
private theorem w1953_2 : checkWitness 1953 true false 8854 = true := by decide +kernel
private theorem cases1953 : checkFour 1953 (8858,0,8854,0) = true := by
  simp only [checkFour, w1953_0, w1953_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1953 : Coverage 1953 1954 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1953)
private theorem w1954_0 : checkWitness 1954 false false 82 = true := by decide +kernel
private theorem w1954_2 : checkWitness 1954 true false 82 = true := by decide +kernel
private theorem cases1954 : checkFour 1954 (82,0,82,0) = true := by
  simp only [checkFour, w1954_0, w1954_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1954 : Coverage 1954 1955 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1954)
private theorem w1955_0 : checkWitness 1955 false false 542 = true := by decide +kernel
private theorem w1955_1 : checkWitness 1955 false true 4638 = true := by decide +kernel
private theorem w1955_2 : checkWitness 1955 true false 542 = true := by decide +kernel
private theorem w1955_3 : checkWitness 1955 true true 4638 = true := by decide +kernel
private theorem cases1955 : checkFour 1955 (542,4638,542,4638) = true := by
  simp only [checkFour, w1955_0, w1955_1, w1955_2, w1955_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1955 : Coverage 1955 1956 := checkList_sound (ws:=[(542,4638,542,4638)]) (by simpa only [checkList, Bool.and_true] using cases1955)
private theorem w1956_0 : checkWitness 1956 false false 8893 = true := by decide +kernel
private theorem w1956_2 : checkWitness 1956 true false 8889 = true := by decide +kernel
private theorem cases1956 : checkFour 1956 (8893,0,8889,0) = true := by
  simp only [checkFour, w1956_0, w1956_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1956 : Coverage 1956 1957 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1956)
private theorem w1957_0 : checkWitness 1957 false false 8924 = true := by decide +kernel
private theorem w1957_2 : checkWitness 1957 true false 8915 = true := by decide +kernel
private theorem cases1957 : checkFour 1957 (8924,0,8915,0) = true := by
  simp only [checkFour, w1957_0, w1957_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1957 : Coverage 1957 1958 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases1957)
private theorem w1958_0 : checkWitness 1958 false false 100 = true := by decide +kernel
private theorem w1958_2 : checkWitness 1958 true false 100 = true := by decide +kernel
private theorem cases1958 : checkFour 1958 (100,0,100,0) = true := by
  simp only [checkFour, w1958_0, w1958_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1958 : Coverage 1958 1959 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1958)
private theorem w1959_0 : checkWitness 1959 false false 638 = true := by decide +kernel
private theorem w1959_1 : checkWitness 1959 false true 4730 = true := by decide +kernel
private theorem w1959_2 : checkWitness 1959 true false 629 = true := by decide +kernel
private theorem w1959_3 : checkWitness 1959 true true 4721 = true := by decide +kernel
private theorem cases1959 : checkFour 1959 (638,4730,629,4721) = true := by
  simp only [checkFour, w1959_0, w1959_1, w1959_2, w1959_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1959 : Coverage 1959 1960 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases1959)
private theorem w1960_0 : checkWitness 1960 false false 8889 = true := by decide +kernel
private theorem w1960_2 : checkWitness 1960 true false 8885 = true := by decide +kernel
private theorem cases1960 : checkFour 1960 (8889,0,8885,0) = true := by
  simp only [checkFour, w1960_0, w1960_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1960 : Coverage 1960 1961 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1960)
private theorem w1961_0 : checkWitness 1961 false false 632 = true := by decide +kernel
private theorem w1961_1 : checkWitness 1961 false true 4724 = true := by decide +kernel
private theorem w1961_2 : checkWitness 1961 true false 623 = true := by decide +kernel
private theorem w1961_3 : checkWitness 1961 true true 4715 = true := by decide +kernel
private theorem cases1961 : checkFour 1961 (632,4724,623,4715) = true := by
  simp only [checkFour, w1961_0, w1961_1, w1961_2, w1961_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1961 : Coverage 1961 1962 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases1961)
private theorem w1962_0 : checkWitness 1962 false false 8860 = true := by decide +kernel
private theorem w1962_2 : checkWitness 1962 true false 8856 = true := by decide +kernel
private theorem cases1962 : checkFour 1962 (8860,0,8856,0) = true := by
  simp only [checkFour, w1962_0, w1962_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1962 : Coverage 1962 1963 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases1962)
private theorem w1963_0 : checkWitness 1963 false false 88 = true := by decide +kernel
private theorem w1963_2 : checkWitness 1963 true false 88 = true := by decide +kernel
private theorem cases1963 : checkFour 1963 (88,0,88,0) = true := by
  simp only [checkFour, w1963_0, w1963_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1963 : Coverage 1963 1964 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1963)
private theorem w1964_0 : checkWitness 1964 false false 80 = true := by decide +kernel
private theorem w1964_2 : checkWitness 1964 true false 80 = true := by decide +kernel
private theorem cases1964 : checkFour 1964 (80,0,80,0) = true := by
  simp only [checkFour, w1964_0, w1964_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1964 : Coverage 1964 1965 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1964)
private theorem w1965_0 : checkWitness 1965 false false 593 = true := by decide +kernel
private theorem w1965_1 : checkWitness 1965 false true 4681 = true := by decide +kernel
private theorem w1965_2 : checkWitness 1965 true false 593 = true := by decide +kernel
private theorem w1965_3 : checkWitness 1965 true true 4681 = true := by decide +kernel
private theorem cases1965 : checkFour 1965 (593,4681,593,4681) = true := by
  simp only [checkFour, w1965_0, w1965_1, w1965_2, w1965_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1965 : Coverage 1965 1966 := checkList_sound (ws:=[(593,4681,593,4681)]) (by simpa only [checkList, Bool.and_true] using cases1965)
private theorem w1966_0 : checkWitness 1966 false false 8876 = true := by decide +kernel
private theorem w1966_2 : checkWitness 1966 true false 8872 = true := by decide +kernel
private theorem cases1966 : checkFour 1966 (8876,0,8872,0) = true := by
  simp only [checkFour, w1966_0, w1966_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1966 : Coverage 1966 1967 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases1966)
private theorem w1967_0 : checkWitness 1967 false false 8872 = true := by decide +kernel
private theorem w1967_2 : checkWitness 1967 true false 8868 = true := by decide +kernel
private theorem cases1967 : checkFour 1967 (8872,0,8868,0) = true := by
  simp only [checkFour, w1967_0, w1967_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1967 : Coverage 1967 1968 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases1967)
private theorem w1968_0 : checkWitness 1968 false false 94 = true := by decide +kernel
private theorem w1968_2 : checkWitness 1968 true false 94 = true := by decide +kernel
private theorem cases1968 : checkFour 1968 (94,0,94,0) = true := by
  simp only [checkFour, w1968_0, w1968_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1968 : Coverage 1968 1969 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1968)
private theorem w1969_0 : checkWitness 1969 false false 8896 = true := by decide +kernel
private theorem w1969_2 : checkWitness 1969 true false 8892 = true := by decide +kernel
private theorem cases1969 : checkFour 1969 (8896,0,8892,0) = true := by
  simp only [checkFour, w1969_0, w1969_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1969 : Coverage 1969 1970 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases1969)
private theorem w1970_0 : checkWitness 1970 false false 8880 = true := by decide +kernel
private theorem w1970_2 : checkWitness 1970 true false 8876 = true := by decide +kernel
private theorem cases1970 : checkFour 1970 (8880,0,8876,0) = true := by
  simp only [checkFour, w1970_0, w1970_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1970 : Coverage 1970 1971 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases1970)
private theorem w1971_0 : checkWitness 1971 false false 498 = true := by decide +kernel
private theorem w1971_1 : checkWitness 1971 false true 4594 = true := by decide +kernel
private theorem w1971_2 : checkWitness 1971 true false 498 = true := by decide +kernel
private theorem w1971_3 : checkWitness 1971 true true 4594 = true := by decide +kernel
private theorem cases1971 : checkFour 1971 (498,4594,498,4594) = true := by
  simp only [checkFour, w1971_0, w1971_1, w1971_2, w1971_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1971 : Coverage 1971 1972 := checkList_sound (ws:=[(498,4594,498,4594)]) (by simpa only [checkList, Bool.and_true] using cases1971)
private theorem w1972_0 : checkWitness 1972 false false 8901 = true := by decide +kernel
private theorem w1972_2 : checkWitness 1972 true false 8897 = true := by decide +kernel
private theorem cases1972 : checkFour 1972 (8901,0,8897,0) = true := by
  simp only [checkFour, w1972_0, w1972_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1972 : Coverage 1972 1973 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1972)
private theorem w1973_0 : checkWitness 1973 false false 630 = true := by decide +kernel
private theorem w1973_1 : checkWitness 1973 false true 4726 = true := by decide +kernel
private theorem w1973_2 : checkWitness 1973 true false 621 = true := by decide +kernel
private theorem w1973_3 : checkWitness 1973 true true 4717 = true := by decide +kernel
private theorem cases1973 : checkFour 1973 (630,4726,621,4717) = true := by
  simp only [checkFour, w1973_0, w1973_1, w1973_2, w1973_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1973 : Coverage 1973 1974 := checkList_sound (ws:=[(630,4726,621,4717)]) (by simpa only [checkList, Bool.and_true] using cases1973)
private theorem w1974_0 : checkWitness 1974 false false 182 = true := by decide +kernel
private theorem w1974_2 : checkWitness 1974 true false 182 = true := by decide +kernel
private theorem cases1974 : checkFour 1974 (182,0,182,0) = true := by
  simp only [checkFour, w1974_0, w1974_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1974 : Coverage 1974 1975 := checkList_sound (ws:=[(182,0,182,0)]) (by simpa only [checkList, Bool.and_true] using cases1974)
private theorem w1975_0 : checkWitness 1975 false false 579 = true := by decide +kernel
private theorem w1975_1 : checkWitness 1975 false true 4667 = true := by decide +kernel
private theorem w1975_2 : checkWitness 1975 true false 579 = true := by decide +kernel
private theorem w1975_3 : checkWitness 1975 true true 4667 = true := by decide +kernel
private theorem cases1975 : checkFour 1975 (579,4667,579,4667) = true := by
  simp only [checkFour, w1975_0, w1975_1, w1975_2, w1975_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1975 : Coverage 1975 1976 := checkList_sound (ws:=[(579,4667,579,4667)]) (by simpa only [checkList, Bool.and_true] using cases1975)
private theorem w1976_0 : checkWitness 1976 false false 8912 = true := by decide +kernel
private theorem w1976_2 : checkWitness 1976 true false 8903 = true := by decide +kernel
private theorem cases1976 : checkFour 1976 (8912,0,8903,0) = true := by
  simp only [checkFour, w1976_0, w1976_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1976 : Coverage 1976 1977 := checkList_sound (ws:=[(8912,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases1976)
private theorem w1977_0 : checkWitness 1977 false false 82 = true := by decide +kernel
private theorem w1977_2 : checkWitness 1977 true false 82 = true := by decide +kernel
private theorem cases1977 : checkFour 1977 (82,0,82,0) = true := by
  simp only [checkFour, w1977_0, w1977_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1977 : Coverage 1977 1978 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1977)
private theorem w1978_0 : checkWitness 1978 false false 74 = true := by decide +kernel
private theorem w1978_2 : checkWitness 1978 true false 74 = true := by decide +kernel
private theorem cases1978 : checkFour 1978 (74,0,74,0) = true := by
  simp only [checkFour, w1978_0, w1978_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1978 : Coverage 1978 1979 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1978)
private theorem w1979_0 : checkWitness 1979 false false 579 = true := by decide +kernel
private theorem w1979_1 : checkWitness 1979 false true 4671 = true := by decide +kernel
private theorem w1979_2 : checkWitness 1979 true false 579 = true := by decide +kernel
private theorem w1979_3 : checkWitness 1979 true true 4671 = true := by decide +kernel
private theorem cases1979 : checkFour 1979 (579,4671,579,4671) = true := by
  simp only [checkFour, w1979_0, w1979_1, w1979_2, w1979_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1979 : Coverage 1979 1980 := checkList_sound (ws:=[(579,4671,579,4671)]) (by simpa only [checkList, Bool.and_true] using cases1979)
private theorem w1980_0 : checkWitness 1980 false false 8854 = true := by decide +kernel
private theorem w1980_2 : checkWitness 1980 true false 8850 = true := by decide +kernel
private theorem cases1980 : checkFour 1980 (8854,0,8850,0) = true := by
  simp only [checkFour, w1980_0, w1980_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1980 : Coverage 1980 1981 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases1980)
private theorem w1981_0 : checkWitness 1981 false false 74 = true := by decide +kernel
private theorem w1981_2 : checkWitness 1981 true false 74 = true := by decide +kernel
private theorem cases1981 : checkFour 1981 (74,0,74,0) = true := by
  simp only [checkFour, w1981_0, w1981_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1981 : Coverage 1981 1982 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1981)
private theorem w1982_0 : checkWitness 1982 false false 538 = true := by decide +kernel
private theorem w1982_1 : checkWitness 1982 false true 4634 = true := by decide +kernel
private theorem w1982_2 : checkWitness 1982 true false 538 = true := by decide +kernel
private theorem w1982_3 : checkWitness 1982 true true 4634 = true := by decide +kernel
private theorem cases1982 : checkFour 1982 (538,4634,538,4634) = true := by
  simp only [checkFour, w1982_0, w1982_1, w1982_2, w1982_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1982 : Coverage 1982 1983 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases1982)
private theorem w1983_0 : checkWitness 1983 false false 8889 = true := by decide +kernel
private theorem w1983_2 : checkWitness 1983 true false 8885 = true := by decide +kernel
private theorem cases1983 : checkFour 1983 (8889,0,8885,0) = true := by
  simp only [checkFour, w1983_0, w1983_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1983 : Coverage 1983 1984 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1983)
theorem cover1952 : Coverage 1952 1984 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1952 one1953) (Coverage.join one1954 one1955)) (Coverage.join (Coverage.join one1956 one1957) (Coverage.join one1958 one1959))) (Coverage.join (Coverage.join (Coverage.join one1960 one1961) (Coverage.join one1962 one1963)) (Coverage.join (Coverage.join one1964 one1965) (Coverage.join one1966 one1967)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1968 one1969) (Coverage.join one1970 one1971)) (Coverage.join (Coverage.join one1972 one1973) (Coverage.join one1974 one1975))) (Coverage.join (Coverage.join (Coverage.join one1976 one1977) (Coverage.join one1978 one1979)) (Coverage.join (Coverage.join one1980 one1981) (Coverage.join one1982 one1983)))))
end NF180PA.Symbolic
