import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1600_0 : checkWitness 1600 false false 608 = true := by decide +kernel
private theorem w1600_1 : checkWitness 1600 false true 4700 = true := by decide +kernel
private theorem w1600_2 : checkWitness 1600 true false 599 = true := by decide +kernel
private theorem w1600_3 : checkWitness 1600 true true 4691 = true := by decide +kernel
private theorem cases1600 : checkFour 1600 (608,4700,599,4691) = true := by
  simp only [checkFour, w1600_0, w1600_1, w1600_2, w1600_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1600 : Coverage 1600 1601 := checkList_sound (ws:=[(608,4700,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases1600)
private theorem w1601_0 : checkWitness 1601 false false 8836 = true := by decide +kernel
private theorem w1601_2 : checkWitness 1601 true false 8832 = true := by decide +kernel
private theorem cases1601 : checkFour 1601 (8836,0,8832,0) = true := by
  simp only [checkFour, w1601_0, w1601_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1601 : Coverage 1601 1602 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1601)
private theorem w1602_0 : checkWitness 1602 false false 90 = true := by decide +kernel
private theorem w1602_2 : checkWitness 1602 true false 90 = true := by decide +kernel
private theorem cases1602 : checkFour 1602 (90,0,90,0) = true := by
  simp only [checkFour, w1602_0, w1602_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1602 : Coverage 1602 1603 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1602)
private theorem w1603_0 : checkWitness 1603 false false 82 = true := by decide +kernel
private theorem w1603_2 : checkWitness 1603 true false 82 = true := by decide +kernel
private theorem cases1603 : checkFour 1603 (82,0,82,0) = true := by
  simp only [checkFour, w1603_0, w1603_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1603 : Coverage 1603 1604 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1603)
private theorem w1604_0 : checkWitness 1604 false false 561 = true := by decide +kernel
private theorem w1604_1 : checkWitness 1604 false true 4645 = true := by decide +kernel
private theorem w1604_2 : checkWitness 1604 true false 561 = true := by decide +kernel
private theorem w1604_3 : checkWitness 1604 true true 4645 = true := by decide +kernel
private theorem cases1604 : checkFour 1604 (561,4645,561,4645) = true := by
  simp only [checkFour, w1604_0, w1604_1, w1604_2, w1604_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1604 : Coverage 1604 1605 := checkList_sound (ws:=[(561,4645,561,4645)]) (by simpa only [checkList, Bool.and_true] using cases1604)
private theorem w1605_0 : checkWitness 1605 false false 8828 = true := by decide +kernel
private theorem w1605_2 : checkWitness 1605 true false 8824 = true := by decide +kernel
private theorem cases1605 : checkFour 1605 (8828,0,8824,0) = true := by
  simp only [checkFour, w1605_0, w1605_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1605 : Coverage 1605 1606 := checkList_sound (ws:=[(8828,0,8824,0)]) (by simpa only [checkList, Bool.and_true] using cases1605)
private theorem w1606_0 : checkWitness 1606 false false 82 = true := by decide +kernel
private theorem w1606_2 : checkWitness 1606 true false 82 = true := by decide +kernel
private theorem cases1606 : checkFour 1606 (82,0,82,0) = true := by
  simp only [checkFour, w1606_0, w1606_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1606 : Coverage 1606 1607 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1606)
private theorem w1607_0 : checkWitness 1607 false false 537 = true := by decide +kernel
private theorem w1607_1 : checkWitness 1607 false true 4633 = true := by decide +kernel
private theorem w1607_2 : checkWitness 1607 true false 537 = true := by decide +kernel
private theorem w1607_3 : checkWitness 1607 true true 4633 = true := by decide +kernel
private theorem cases1607 : checkFour 1607 (537,4633,537,4633) = true := by
  simp only [checkFour, w1607_0, w1607_1, w1607_2, w1607_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1607 : Coverage 1607 1608 := checkList_sound (ws:=[(537,4633,537,4633)]) (by simpa only [checkList, Bool.and_true] using cases1607)
private theorem w1608_0 : checkWitness 1608 false false 8898 = true := by decide +kernel
private theorem w1608_2 : checkWitness 1608 true false 8889 = true := by decide +kernel
private theorem cases1608 : checkFour 1608 (8898,0,8889,0) = true := by
  simp only [checkFour, w1608_0, w1608_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1608 : Coverage 1608 1609 := checkList_sound (ws:=[(8898,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1608)
private theorem w1609_0 : checkWitness 1609 false false 8844 = true := by decide +kernel
private theorem w1609_2 : checkWitness 1609 true false 8840 = true := by decide +kernel
private theorem cases1609 : checkFour 1609 (8844,0,8840,0) = true := by
  simp only [checkFour, w1609_0, w1609_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1609 : Coverage 1609 1610 := checkList_sound (ws:=[(8844,0,8840,0)]) (by simpa only [checkList, Bool.and_true] using cases1609)
private theorem w1610_0 : checkWitness 1610 false false 90 = true := by decide +kernel
private theorem w1610_2 : checkWitness 1610 true false 90 = true := by decide +kernel
private theorem cases1610 : checkFour 1610 (90,0,90,0) = true := by
  simp only [checkFour, w1610_0, w1610_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1610 : Coverage 1610 1611 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1610)
private theorem w1611_0 : checkWitness 1611 false false 624 = true := by decide +kernel
private theorem w1611_1 : checkWitness 1611 false true 4712 = true := by decide +kernel
private theorem w1611_2 : checkWitness 1611 true false 615 = true := by decide +kernel
private theorem w1611_3 : checkWitness 1611 true true 4703 = true := by decide +kernel
private theorem cases1611 : checkFour 1611 (624,4712,615,4703) = true := by
  simp only [checkFour, w1611_0, w1611_1, w1611_2, w1611_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1611 : Coverage 1611 1612 := checkList_sound (ws:=[(624,4712,615,4703)]) (by simpa only [checkList, Bool.and_true] using cases1611)
private theorem w1612_0 : checkWitness 1612 false false 8863 = true := by decide +kernel
private theorem w1612_2 : checkWitness 1612 true false 8859 = true := by decide +kernel
private theorem cases1612 : checkFour 1612 (8863,0,8859,0) = true := by
  simp only [checkFour, w1612_0, w1612_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1612 : Coverage 1612 1613 := checkList_sound (ws:=[(8863,0,8859,0)]) (by simpa only [checkList, Bool.and_true] using cases1612)
private theorem w1613_0 : checkWitness 1613 false false 80 = true := by decide +kernel
private theorem w1613_2 : checkWitness 1613 true false 80 = true := by decide +kernel
private theorem cases1613 : checkFour 1613 (80,0,80,0) = true := by
  simp only [checkFour, w1613_0, w1613_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1613 : Coverage 1613 1614 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1613)
private theorem w1614_0 : checkWitness 1614 false false 532 = true := by decide +kernel
private theorem w1614_1 : checkWitness 1614 false true 4628 = true := by decide +kernel
private theorem w1614_2 : checkWitness 1614 true false 532 = true := by decide +kernel
private theorem w1614_3 : checkWitness 1614 true true 4628 = true := by decide +kernel
private theorem cases1614 : checkFour 1614 (532,4628,532,4628) = true := by
  simp only [checkFour, w1614_0, w1614_1, w1614_2, w1614_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1614 : Coverage 1614 1615 := checkList_sound (ws:=[(532,4628,532,4628)]) (by simpa only [checkList, Bool.and_true] using cases1614)
private theorem w1615_0 : checkWitness 1615 false false 8906 = true := by decide +kernel
private theorem w1615_2 : checkWitness 1615 true false 8897 = true := by decide +kernel
private theorem cases1615 : checkFour 1615 (8906,0,8897,0) = true := by
  simp only [checkFour, w1615_0, w1615_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1615 : Coverage 1615 1616 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1615)
private theorem w1616_0 : checkWitness 1616 false false 80 = true := by decide +kernel
private theorem w1616_2 : checkWitness 1616 true false 80 = true := by decide +kernel
private theorem cases1616 : checkFour 1616 (80,0,80,0) = true := by
  simp only [checkFour, w1616_0, w1616_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1616 : Coverage 1616 1617 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1616)
private theorem w1617_0 : checkWitness 1617 false false 484 = true := by decide +kernel
private theorem w1617_1 : checkWitness 1617 false true 4580 = true := by decide +kernel
private theorem w1617_2 : checkWitness 1617 true false 484 = true := by decide +kernel
private theorem w1617_3 : checkWitness 1617 true true 4580 = true := by decide +kernel
private theorem cases1617 : checkFour 1617 (484,4580,484,4580) = true := by
  simp only [checkFour, w1617_0, w1617_1, w1617_2, w1617_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1617 : Coverage 1617 1618 := checkList_sound (ws:=[(484,4580,484,4580)]) (by simpa only [checkList, Bool.and_true] using cases1617)
private theorem w1618_0 : checkWitness 1618 false false 8858 = true := by decide +kernel
private theorem w1618_2 : checkWitness 1618 true false 8854 = true := by decide +kernel
private theorem cases1618 : checkFour 1618 (8858,0,8854,0) = true := by
  simp only [checkFour, w1618_0, w1618_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1618 : Coverage 1618 1619 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1618)
private theorem w1619_0 : checkWitness 1619 false false 84 = true := by decide +kernel
private theorem w1619_2 : checkWitness 1619 true false 84 = true := by decide +kernel
private theorem cases1619 : checkFour 1619 (84,0,84,0) = true := by
  simp only [checkFour, w1619_0, w1619_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1619 : Coverage 1619 1620 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1619)
private theorem w1620_0 : checkWitness 1620 false false 526 = true := by decide +kernel
private theorem w1620_1 : checkWitness 1620 false true 4622 = true := by decide +kernel
private theorem w1620_2 : checkWitness 1620 true false 526 = true := by decide +kernel
private theorem w1620_3 : checkWitness 1620 true true 4622 = true := by decide +kernel
private theorem cases1620 : checkFour 1620 (526,4622,526,4622) = true := by
  simp only [checkFour, w1620_0, w1620_1, w1620_2, w1620_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1620 : Coverage 1620 1621 := checkList_sound (ws:=[(526,4622,526,4622)]) (by simpa only [checkList, Bool.and_true] using cases1620)
private theorem w1621_0 : checkWitness 1621 false false 8877 = true := by decide +kernel
private theorem w1621_2 : checkWitness 1621 true false 8873 = true := by decide +kernel
private theorem cases1621 : checkFour 1621 (8877,0,8873,0) = true := by
  simp only [checkFour, w1621_0, w1621_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1621 : Coverage 1621 1622 := checkList_sound (ws:=[(8877,0,8873,0)]) (by simpa only [checkList, Bool.and_true] using cases1621)
private theorem w1622_0 : checkWitness 1622 false false 8908 = true := by decide +kernel
private theorem w1622_2 : checkWitness 1622 true false 8899 = true := by decide +kernel
private theorem cases1622 : checkFour 1622 (8908,0,8899,0) = true := by
  simp only [checkFour, w1622_0, w1622_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1622 : Coverage 1622 1623 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases1622)
private theorem w1623_0 : checkWitness 1623 false false 108 = true := by decide +kernel
private theorem w1623_2 : checkWitness 1623 true false 108 = true := by decide +kernel
private theorem cases1623 : checkFour 1623 (108,0,108,0) = true := by
  simp only [checkFour, w1623_0, w1623_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1623 : Coverage 1623 1624 := checkList_sound (ws:=[(108,0,108,0)]) (by simpa only [checkList, Bool.and_true] using cases1623)
private theorem w1624_0 : checkWitness 1624 false false 622 = true := by decide +kernel
private theorem w1624_1 : checkWitness 1624 false true 4714 = true := by decide +kernel
private theorem w1624_2 : checkWitness 1624 true false 613 = true := by decide +kernel
private theorem w1624_3 : checkWitness 1624 true true 4705 = true := by decide +kernel
private theorem cases1624 : checkFour 1624 (622,4714,613,4705) = true := by
  simp only [checkFour, w1624_0, w1624_1, w1624_2, w1624_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1624 : Coverage 1624 1625 := checkList_sound (ws:=[(622,4714,613,4705)]) (by simpa only [checkList, Bool.and_true] using cases1624)
private theorem w1625_0 : checkWitness 1625 false false 8873 = true := by decide +kernel
private theorem w1625_2 : checkWitness 1625 true false 8869 = true := by decide +kernel
private theorem cases1625 : checkFour 1625 (8873,0,8869,0) = true := by
  simp only [checkFour, w1625_0, w1625_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1625 : Coverage 1625 1626 := checkList_sound (ws:=[(8873,0,8869,0)]) (by simpa only [checkList, Bool.and_true] using cases1625)
private theorem w1626_0 : checkWitness 1626 false false 616 = true := by decide +kernel
private theorem w1626_1 : checkWitness 1626 false true 4708 = true := by decide +kernel
private theorem w1626_2 : checkWitness 1626 true false 607 = true := by decide +kernel
private theorem w1626_3 : checkWitness 1626 true true 4699 = true := by decide +kernel
private theorem cases1626 : checkFour 1626 (616,4708,607,4699) = true := by
  simp only [checkFour, w1626_0, w1626_1, w1626_2, w1626_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1626 : Coverage 1626 1627 := checkList_sound (ws:=[(616,4708,607,4699)]) (by simpa only [checkList, Bool.and_true] using cases1626)
private theorem w1627_0 : checkWitness 1627 false false 8844 = true := by decide +kernel
private theorem w1627_2 : checkWitness 1627 true false 8840 = true := by decide +kernel
private theorem cases1627 : checkFour 1627 (8844,0,8840,0) = true := by
  simp only [checkFour, w1627_0, w1627_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1627 : Coverage 1627 1628 := checkList_sound (ws:=[(8844,0,8840,0)]) (by simpa only [checkList, Bool.and_true] using cases1627)
private theorem w1628_0 : checkWitness 1628 false false 96 = true := by decide +kernel
private theorem w1628_2 : checkWitness 1628 true false 96 = true := by decide +kernel
private theorem cases1628 : checkFour 1628 (96,0,96,0) = true := by
  simp only [checkFour, w1628_0, w1628_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1628 : Coverage 1628 1629 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1628)
private theorem w1629_0 : checkWitness 1629 false false 88 = true := by decide +kernel
private theorem w1629_2 : checkWitness 1629 true false 88 = true := by decide +kernel
private theorem cases1629 : checkFour 1629 (88,0,88,0) = true := by
  simp only [checkFour, w1629_0, w1629_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1629 : Coverage 1629 1630 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1629)
private theorem w1630_0 : checkWitness 1630 false false 569 = true := by decide +kernel
private theorem w1630_1 : checkWitness 1630 false true 4653 = true := by decide +kernel
private theorem w1630_2 : checkWitness 1630 true false 569 = true := by decide +kernel
private theorem w1630_3 : checkWitness 1630 true true 4653 = true := by decide +kernel
private theorem cases1630 : checkFour 1630 (569,4653,569,4653) = true := by
  simp only [checkFour, w1630_0, w1630_1, w1630_2, w1630_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1630 : Coverage 1630 1631 := checkList_sound (ws:=[(569,4653,569,4653)]) (by simpa only [checkList, Bool.and_true] using cases1630)
private theorem w1631_0 : checkWitness 1631 false false 8836 = true := by decide +kernel
private theorem w1631_2 : checkWitness 1631 true false 8832 = true := by decide +kernel
private theorem cases1631 : checkFour 1631 (8836,0,8832,0) = true := by
  simp only [checkFour, w1631_0, w1631_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1631 : Coverage 1631 1632 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1631)
theorem cover1600 : Coverage 1600 1632 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1600 one1601) (Coverage.join one1602 one1603)) (Coverage.join (Coverage.join one1604 one1605) (Coverage.join one1606 one1607))) (Coverage.join (Coverage.join (Coverage.join one1608 one1609) (Coverage.join one1610 one1611)) (Coverage.join (Coverage.join one1612 one1613) (Coverage.join one1614 one1615)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1616 one1617) (Coverage.join one1618 one1619)) (Coverage.join (Coverage.join one1620 one1621) (Coverage.join one1622 one1623))) (Coverage.join (Coverage.join (Coverage.join one1624 one1625) (Coverage.join one1626 one1627)) (Coverage.join (Coverage.join one1628 one1629) (Coverage.join one1630 one1631)))))
end NF180PA.Symbolic
