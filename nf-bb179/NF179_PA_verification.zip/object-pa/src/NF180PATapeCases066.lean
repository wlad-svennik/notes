import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2112_0 : checkWitness 2112 false false 8929 = true := by decide +kernel
private theorem w2112_2 : checkWitness 2112 true false 8925 = true := by decide +kernel
private theorem cases2112 : checkFour 2112 (8929,0,8925,0) = true := by
  simp only [checkFour, w2112_0, w2112_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2112 : Coverage 2112 2113 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases2112)
private theorem w2113_0 : checkWitness 2113 false false 672 = true := by decide +kernel
private theorem w2113_1 : checkWitness 2113 false true 4764 = true := by decide +kernel
private theorem w2113_2 : checkWitness 2113 true false 663 = true := by decide +kernel
private theorem w2113_3 : checkWitness 2113 true true 4755 = true := by decide +kernel
private theorem cases2113 : checkFour 2113 (672,4764,663,4755) = true := by
  simp only [checkFour, w2113_0, w2113_1, w2113_2, w2113_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2113 : Coverage 2113 2114 := checkList_sound (ws:=[(672,4764,663,4755)]) (by simpa only [checkList, Bool.and_true] using cases2113)
private theorem w2114_0 : checkWitness 2114 false false 8900 = true := by decide +kernel
private theorem w2114_2 : checkWitness 2114 true false 8896 = true := by decide +kernel
private theorem cases2114 : checkFour 2114 (8900,0,8896,0) = true := by
  simp only [checkFour, w2114_0, w2114_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2114 : Coverage 2114 2115 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases2114)
private theorem w2115_0 : checkWitness 2115 false false 88 = true := by decide +kernel
private theorem w2115_2 : checkWitness 2115 true false 88 = true := by decide +kernel
private theorem cases2115 : checkFour 2115 (88,0,88,0) = true := by
  simp only [checkFour, w2115_0, w2115_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2115 : Coverage 2115 2116 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases2115)
private theorem w2116_0 : checkWitness 2116 false false 80 = true := by decide +kernel
private theorem w2116_2 : checkWitness 2116 true false 80 = true := by decide +kernel
private theorem cases2116 : checkFour 2116 (80,0,80,0) = true := by
  simp only [checkFour, w2116_0, w2116_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2116 : Coverage 2116 2117 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2116)
private theorem w2117_0 : checkWitness 2117 false false 625 = true := by decide +kernel
private theorem w2117_1 : checkWitness 2117 false true 4709 = true := by decide +kernel
private theorem w2117_2 : checkWitness 2117 true false 625 = true := by decide +kernel
private theorem w2117_3 : checkWitness 2117 true true 4709 = true := by decide +kernel
private theorem cases2117 : checkFour 2117 (625,4709,625,4709) = true := by
  simp only [checkFour, w2117_0, w2117_1, w2117_2, w2117_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2117 : Coverage 2117 2118 := checkList_sound (ws:=[(625,4709,625,4709)]) (by simpa only [checkList, Bool.and_true] using cases2117)
private theorem w2118_0 : checkWitness 2118 false false 8892 = true := by decide +kernel
private theorem w2118_2 : checkWitness 2118 true false 8888 = true := by decide +kernel
private theorem cases2118 : checkFour 2118 (8892,0,8888,0) = true := by
  simp only [checkFour, w2118_0, w2118_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2118 : Coverage 2118 2119 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2118)
private theorem w2119_0 : checkWitness 2119 false false 80 = true := by decide +kernel
private theorem w2119_2 : checkWitness 2119 true false 80 = true := by decide +kernel
private theorem cases2119 : checkFour 2119 (80,0,80,0) = true := by
  simp only [checkFour, w2119_0, w2119_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2119 : Coverage 2119 2120 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2119)
private theorem w2120_0 : checkWitness 2120 false false 636 = true := by decide +kernel
private theorem w2120_1 : checkWitness 2120 false true 4732 = true := by decide +kernel
private theorem w2120_2 : checkWitness 2120 true false 636 = true := by decide +kernel
private theorem w2120_3 : checkWitness 2120 true true 4732 = true := by decide +kernel
private theorem cases2120 : checkFour 2120 (636,4732,636,4732) = true := by
  simp only [checkFour, w2120_0, w2120_1, w2120_2, w2120_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2120 : Coverage 2120 2121 := checkList_sound (ws:=[(636,4732,636,4732)]) (by simpa only [checkList, Bool.and_true] using cases2120)
private theorem w2121_0 : checkWitness 2121 false false 8920 = true := by decide +kernel
private theorem w2121_2 : checkWitness 2121 true false 8911 = true := by decide +kernel
private theorem cases2121 : checkFour 2121 (8920,0,8911,0) = true := by
  simp only [checkFour, w2121_0, w2121_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2121 : Coverage 2121 2122 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2121)
private theorem w2122_0 : checkWitness 2122 false false 68 = true := by decide +kernel
private theorem w2122_2 : checkWitness 2122 true false 68 = true := by decide +kernel
private theorem cases2122 : checkFour 2122 (68,0,68,0) = true := by
  simp only [checkFour, w2122_0, w2122_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2122 : Coverage 2122 2123 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2122)
private theorem w2123_0 : checkWitness 2123 false false 498 = true := by decide +kernel
private theorem w2123_1 : checkWitness 2123 false true 4594 = true := by decide +kernel
private theorem w2123_2 : checkWitness 2123 true false 498 = true := by decide +kernel
private theorem w2123_3 : checkWitness 2123 true true 4594 = true := by decide +kernel
private theorem cases2123 : checkFour 2123 (498,4594,498,4594) = true := by
  simp only [checkFour, w2123_0, w2123_1, w2123_2, w2123_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2123 : Coverage 2123 2124 := checkList_sound (ws:=[(498,4594,498,4594)]) (by simpa only [checkList, Bool.and_true] using cases2123)
private theorem w2124_0 : checkWitness 2124 false false 8872 = true := by decide +kernel
private theorem w2124_2 : checkWitness 2124 true false 8868 = true := by decide +kernel
private theorem cases2124 : checkFour 2124 (8872,0,8868,0) = true := by
  simp only [checkFour, w2124_0, w2124_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2124 : Coverage 2124 2125 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases2124)
private theorem w2125_0 : checkWitness 2125 false false 72 = true := by decide +kernel
private theorem w2125_2 : checkWitness 2125 true false 72 = true := by decide +kernel
private theorem cases2125 : checkFour 2125 (72,0,72,0) = true := by
  simp only [checkFour, w2125_0, w2125_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2125 : Coverage 2125 2126 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2125)
private theorem w2126_0 : checkWitness 2126 false false 540 = true := by decide +kernel
private theorem w2126_1 : checkWitness 2126 false true 4636 = true := by decide +kernel
private theorem w2126_2 : checkWitness 2126 true false 540 = true := by decide +kernel
private theorem w2126_3 : checkWitness 2126 true true 4636 = true := by decide +kernel
private theorem cases2126 : checkFour 2126 (540,4636,540,4636) = true := by
  simp only [checkFour, w2126_0, w2126_1, w2126_2, w2126_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2126 : Coverage 2126 2127 := checkList_sound (ws:=[(540,4636,540,4636)]) (by simpa only [checkList, Bool.and_true] using cases2126)
private theorem w2127_0 : checkWitness 2127 false false 8891 = true := by decide +kernel
private theorem w2127_2 : checkWitness 2127 true false 8887 = true := by decide +kernel
private theorem cases2127 : checkFour 2127 (8891,0,8887,0) = true := by
  simp only [checkFour, w2127_0, w2127_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2127 : Coverage 2127 2128 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases2127)
private theorem w2128_0 : checkWitness 2128 false false 8922 = true := by decide +kernel
private theorem w2128_2 : checkWitness 2128 true false 8913 = true := by decide +kernel
private theorem cases2128 : checkFour 2128 (8922,0,8913,0) = true := by
  simp only [checkFour, w2128_0, w2128_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2128 : Coverage 2128 2129 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2128)
private theorem w2129_0 : checkWitness 2129 false false 96 = true := by decide +kernel
private theorem w2129_2 : checkWitness 2129 true false 96 = true := by decide +kernel
private theorem cases2129 : checkFour 2129 (96,0,96,0) = true := by
  simp only [checkFour, w2129_0, w2129_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2129 : Coverage 2129 2130 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases2129)
private theorem w2130_0 : checkWitness 2130 false false 636 = true := by decide +kernel
private theorem w2130_1 : checkWitness 2130 false true 4728 = true := by decide +kernel
private theorem w2130_2 : checkWitness 2130 true false 627 = true := by decide +kernel
private theorem w2130_3 : checkWitness 2130 true true 4719 = true := by decide +kernel
private theorem cases2130 : checkFour 2130 (636,4728,627,4719) = true := by
  simp only [checkFour, w2130_0, w2130_1, w2130_2, w2130_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2130 : Coverage 2130 2131 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases2130)
private theorem w2131_0 : checkWitness 2131 false false 8887 = true := by decide +kernel
private theorem w2131_2 : checkWitness 2131 true false 8883 = true := by decide +kernel
private theorem cases2131 : checkFour 2131 (8887,0,8883,0) = true := by
  simp only [checkFour, w2131_0, w2131_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2131 : Coverage 2131 2132 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases2131)
private theorem w2132_0 : checkWitness 2132 false false 630 = true := by decide +kernel
private theorem w2132_1 : checkWitness 2132 false true 4722 = true := by decide +kernel
private theorem w2132_2 : checkWitness 2132 true false 621 = true := by decide +kernel
private theorem w2132_3 : checkWitness 2132 true true 4713 = true := by decide +kernel
private theorem cases2132 : checkFour 2132 (630,4722,621,4713) = true := by
  simp only [checkFour, w2132_0, w2132_1, w2132_2, w2132_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2132 : Coverage 2132 2133 := checkList_sound (ws:=[(630,4722,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases2132)
private theorem w2133_0 : checkWitness 2133 false false 8858 = true := by decide +kernel
private theorem w2133_2 : checkWitness 2133 true false 8854 = true := by decide +kernel
private theorem cases2133 : checkFour 2133 (8858,0,8854,0) = true := by
  simp only [checkFour, w2133_0, w2133_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2133 : Coverage 2133 2134 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases2133)
private theorem w2134_0 : checkWitness 2134 false false 84 = true := by decide +kernel
private theorem w2134_2 : checkWitness 2134 true false 84 = true := by decide +kernel
private theorem cases2134 : checkFour 2134 (84,0,84,0) = true := by
  simp only [checkFour, w2134_0, w2134_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2134 : Coverage 2134 2135 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2134)
private theorem w2135_0 : checkWitness 2135 false false 76 = true := by decide +kernel
private theorem w2135_2 : checkWitness 2135 true false 76 = true := by decide +kernel
private theorem cases2135 : checkFour 2135 (76,0,76,0) = true := by
  simp only [checkFour, w2135_0, w2135_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2135 : Coverage 2135 2136 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2135)
private theorem w2136_0 : checkWitness 2136 false false 583 = true := by decide +kernel
private theorem w2136_1 : checkWitness 2136 false true 4667 = true := by decide +kernel
private theorem w2136_2 : checkWitness 2136 true false 583 = true := by decide +kernel
private theorem w2136_3 : checkWitness 2136 true true 4667 = true := by decide +kernel
private theorem cases2136 : checkFour 2136 (583,4667,583,4667) = true := by
  simp only [checkFour, w2136_0, w2136_1, w2136_2, w2136_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2136 : Coverage 2136 2137 := checkList_sound (ws:=[(583,4667,583,4667)]) (by simpa only [checkList, Bool.and_true] using cases2136)
private theorem w2137_0 : checkWitness 2137 false false 8850 = true := by decide +kernel
private theorem w2137_2 : checkWitness 2137 true false 8846 = true := by decide +kernel
private theorem cases2137 : checkFour 2137 (8850,0,8846,0) = true := by
  simp only [checkFour, w2137_0, w2137_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2137 : Coverage 2137 2138 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases2137)
private theorem w2138_0 : checkWitness 2138 false false 76 = true := by decide +kernel
private theorem w2138_2 : checkWitness 2138 true false 76 = true := by decide +kernel
private theorem cases2138 : checkFour 2138 (76,0,76,0) = true := by
  simp only [checkFour, w2138_0, w2138_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2138 : Coverage 2138 2139 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2138)
private theorem w2139_0 : checkWitness 2139 false false 627 = true := by decide +kernel
private theorem w2139_1 : checkWitness 2139 false true 4719 = true := by decide +kernel
private theorem w2139_2 : checkWitness 2139 true false 618 = true := by decide +kernel
private theorem w2139_3 : checkWitness 2139 true true 4710 = true := by decide +kernel
private theorem cases2139 : checkFour 2139 (627,4719,618,4710) = true := by
  simp only [checkFour, w2139_0, w2139_1, w2139_2, w2139_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2139 : Coverage 2139 2140 := checkList_sound (ws:=[(627,4719,618,4710)]) (by simpa only [checkList, Bool.and_true] using cases2139)
private theorem w2140_0 : checkWitness 2140 false false 8924 = true := by decide +kernel
private theorem w2140_2 : checkWitness 2140 true false 8915 = true := by decide +kernel
private theorem cases2140 : checkFour 2140 (8924,0,8915,0) = true := by
  simp only [checkFour, w2140_0, w2140_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2140 : Coverage 2140 2141 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases2140)
private theorem w2141_0 : checkWitness 2141 false false 8870 = true := by decide +kernel
private theorem w2141_2 : checkWitness 2141 true false 8866 = true := by decide +kernel
private theorem cases2141 : checkFour 2141 (8870,0,8866,0) = true := by
  simp only [checkFour, w2141_0, w2141_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2141 : Coverage 2141 2142 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases2141)
private theorem w2142_0 : checkWitness 2142 false false 80 = true := by decide +kernel
private theorem w2142_2 : checkWitness 2142 true false 80 = true := by decide +kernel
private theorem cases2142 : checkFour 2142 (80,0,80,0) = true := by
  simp only [checkFour, w2142_0, w2142_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2142 : Coverage 2142 2143 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2142)
private theorem w2143_0 : checkWitness 2143 false false 650 = true := by decide +kernel
private theorem w2143_1 : checkWitness 2143 false true 4742 = true := by decide +kernel
private theorem w2143_2 : checkWitness 2143 true false 641 = true := by decide +kernel
private theorem w2143_3 : checkWitness 2143 true true 4733 = true := by decide +kernel
private theorem cases2143 : checkFour 2143 (650,4742,641,4733) = true := by
  simp only [checkFour, w2143_0, w2143_1, w2143_2, w2143_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2143 : Coverage 2143 2144 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases2143)
theorem cover2112 : Coverage 2112 2144 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2112 one2113) (Coverage.join one2114 one2115)) (Coverage.join (Coverage.join one2116 one2117) (Coverage.join one2118 one2119))) (Coverage.join (Coverage.join (Coverage.join one2120 one2121) (Coverage.join one2122 one2123)) (Coverage.join (Coverage.join one2124 one2125) (Coverage.join one2126 one2127)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2128 one2129) (Coverage.join one2130 one2131)) (Coverage.join (Coverage.join one2132 one2133) (Coverage.join one2134 one2135))) (Coverage.join (Coverage.join (Coverage.join one2136 one2137) (Coverage.join one2138 one2139)) (Coverage.join (Coverage.join one2140 one2141) (Coverage.join one2142 one2143)))))
end NF180PA.Symbolic
