import NF180PATapeFinite

namespace NF180PA.Clock

def conflict : List Bool → List Bool → Bool
  | x::xs, y::ys => if x=y then conflict xs ys else true
  | _, _ => false

/-- Once two finite prefixes disagree, extending either ray cannot make them equal. -/
theorem separated {X : Type} (put : Bool → X → X)
    (disjoint : ∀ x y, put false x ≠ put true y)
    (injective : ∀ b x y, put b x = put b y → x=y)
    {a b : List Bool} (h : conflict a b=true) (x y : X) :
    a.foldr put x ≠ b.foldr put y := by
  induction a generalizing b with
  | nil => simp [conflict] at h
  | cons u us ih =>
    cases b with
    | nil => simp [conflict] at h
    | cons v vs =>
      by_cases same : u=v
      · subst v
        intro eq
        exact ih (by simpa [conflict] using h) (injective u _ _ eq)
      · cases u <;> cases v <;> simp_all [List.foldr,Ne.symm]

open NF180PA.Symbolic
open Blank180.Data (addressBits)

def branchConflict (p : Nat) (z : Bool) : Bool :=
  expectedHalt p z || conflict (addressBits p) (addressBits (nextPc p z))

set_option maxRecDepth 30000
set_option maxHeartbeats 0

def block (lo : Nat) : Nat → Bool
  | 0 => true
  | n+1 => branchConflict lo false && branchConflict lo true && block (lo+1) n
termination_by n => n

def Covers (lo hi : Nat) : Prop :=
  ∀ p, lo≤p → p<hi → ∀ z, branchConflict p z=true

theorem block_sound {lo n : Nat} (h : block lo n = true) : Covers lo (lo+n) := by
  induction n generalizing lo with
  | zero => intro p a b; omega
  | succ n ih =>
    simp only [block,Bool.and_eq_true] at h
    intro p lower upper z
    by_cases atStart : p=lo
    · subst p; cases z <;> first | exact h.1.1 | exact h.1.2
    · exact ih h.2 p (by omega) (by omega) z

theorem Covers.join {a b c : Nat} (l : Covers a b) (r : Covers b c) : Covers a c := by
  intro p hp hq z
  by_cases mid : p<b
  · exact l p hp mid z
  · exact r p (by omega) hq z


end NF180PA.Clock
