import NF180PATapeBootFrame
import NF180PATapeRegisterStep
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.PhysicalModel PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.RegisterSource (readReg registers address cold config perform)
namespace NF180PA.Symbolic
open Gate (machine)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 2500000
set_option maxRecDepth 16000

/-- Finite control-flow check. All quantified addresses and flags here are standard. -/
def LinksSafe : Prop := ∀ (p : Fin 2970) (c : Bool), legal p.val c →
  (c=true → isDecReg p.val 0=false) ∧ ∀ z, expectedHalt p.val z=false →
    nextPc p.val z<2970 ∧ legal (nextPc p.val z) (coldFor p.val c true)

theorem checked_row (links : LinksSafe) (cover : Coverage 0 2970) (p : Fin 2970) : RowSim (V:=V) p.val := by
  rintro flag s phys ⟨legalAt,atp,tag,debt,g,k,rfl⟩
  let r := registers s
  let z := positive p.val r
  let v := parameter p.val r g k
  let s' := perform (Registers.instruction p.val) (flag.toNat:V) r
  have hnext : Registers.next s = s' := by
    have eq : config (address s) (cold s) r = s := by
      simp [r,RegisterSource.config,RegisterSource.address,RegisterSource.cold,RegisterSource.registers]
    rw [atp,tag] at eq
    rw [←eq,Registers.next_at]
  obtain ⟨noDebt,targets⟩ := links p flag legalAt
  obtain ⟨w,hw⟩ := cover p.val (Nat.zero_le _) p.isLt flag z (params_admissible _ _ _ noDebt)
  let dg := w/4096%2
  let ds := w/8192%2
  have cert : checkRow p.val flag z (w%4096) dg ds = true := hw
  have source : (signedFrame p.val flag z false 0 0).val v = packedFrame p.val flag r g k := by
    rw [frame_correct]
    simp only [Bool.false_eq_true,ite_false,Nat.cast_zero,add_zero]
    have gv : v 9=g := by simp [v,parameter]
    have kv : v 10=k := by simp [v,parameter]
    rw [gv,kv]
    simp only [coldFor,Bool.false_and,Bool.not_false,Bool.and_true]
    change canonical p.val flag _ g k = canonical p.val flag _ g k
    apply canonical_equal
    exact params_input _ _ _ _ _ debt
  have run := row_sound cert v
  rw [source] at run
  change ∃ ticks : V, Boundary (Registers.next s) (iterate (rawStep machine) ticks (packedFrame p.val flag r g k))
  rw [hnext]
  obtain ⟨addr',flag',debt',regs'⟩ := source_fields p.val flag r g k debt
  change address s'=(outAddress p.val z:V) at addr'
  change cold s'=((coldFor p.val flag true).toNat:V) at flag'
  cases stops : expectedHalt p.val z with
  | true =>
    simp only [stops,ite_true] at run
    obtain ⟨t,gate⟩ := run
    refine ⟨t+1,Or.inl ⟨by simpa [outAddress,stops] using addr',?_⟩⟩
    rw [iterate_succ]
    apply (Gate.step_halts_iff _ ?_).mpr gate
    rw [gate.1]; exact_mod_cast Gate.gate.isLt
  | false =>
    simp only [stops,Bool.false_eq_true,ite_false] at run
    obtain ⟨t,ht⟩ := run
    rw [frame_correct] at ht
    obtain ⟨target,legal'⟩ := targets z stops
    refine ⟨t,Or.inr ((anyFrame_iff _ _ _).2 ⟨nextPc p.val z,List.mem_range.mpr target,coldFor p.val flag true,
      legal',by simpa [outAddress,stops] using addr',flag',debt',g+(dg:V),k+(ds:V),?_⟩)⟩
    rw [ht]
    simp only [ite_true]
    have gv : v 9=g := by simp [v,parameter]
    have kv : v 10=k := by simp [v,parameter]
    rw [gv,kv]
    apply canonical_equal
    exact regs'

/-- The only input to this compiler correctness theorem is a finite Boolean
calculation. Clocks, gaps, spares, and all nine registers may be nonstandard. -/
theorem tape_of_links_and_coverage (links : LinksSafe) (cover : Coverage 0 2970)
    (source : ∃ j : V, address (Registers.run j)=4095) : V ⊧/![] H180 :=
  tape_of_source boot_boundary (checked_row links cover) source

#print axioms checked_row
#print axioms tape_of_links_and_coverage
end NF180PA.Symbolic
