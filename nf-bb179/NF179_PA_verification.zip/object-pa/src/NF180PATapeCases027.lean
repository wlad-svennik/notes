import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w864_0 : checkWitness 864 false false 8896 = true := by decide +kernel
private theorem w864_2 : checkWitness 864 true false 8892 = true := by decide +kernel
private theorem cases864 : checkFour 864 (8896,0,8892,0) = true := by
  simp only [checkFour, w864_0, w864_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one864 : Coverage 864 865 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases864)
private theorem w865_0 : checkWitness 865 false false 72 = true := by decide +kernel
private theorem w865_2 : checkWitness 865 true false 72 = true := by decide +kernel
private theorem cases865 : checkFour 865 (72,0,72,0) = true := by
  simp only [checkFour, w865_0, w865_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one865 : Coverage 865 866 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases865)
private theorem w866_0 : checkWitness 866 false false 670 = true := by decide +kernel
private theorem w866_1 : checkWitness 866 false true 4766 = true := by decide +kernel
private theorem w866_2 : checkWitness 866 true false 670 = true := by decide +kernel
private theorem w866_3 : checkWitness 866 true true 4766 = true := by decide +kernel
private theorem cases866 : checkFour 866 (670,4766,670,4766) = true := by
  simp only [checkFour, w866_0, w866_1, w866_2, w866_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one866 : Coverage 866 867 := checkList_sound (ws:=[(670,4766,670,4766)]) (by simpa only [checkList, Bool.and_true] using cases866)
private theorem w867_0 : checkWitness 867 false false 8958 = true := by decide +kernel
private theorem w867_2 : checkWitness 867 true false 8949 = true := by decide +kernel
private theorem cases867 : checkFour 867 (8958,0,8949,0) = true := by
  simp only [checkFour, w867_0, w867_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one867 : Coverage 867 868 := checkList_sound (ws:=[(8958,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases867)
private theorem w868_0 : checkWitness 868 false false 64 = true := by decide +kernel
private theorem w868_2 : checkWitness 868 true false 64 = true := by decide +kernel
private theorem cases868 : checkFour 868 (64,0,64,0) = true := by
  simp only [checkFour, w868_0, w868_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one868 : Coverage 868 869 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases868)
private theorem w869_0 : checkWitness 869 false false 536 = true := by decide +kernel
private theorem w869_1 : checkWitness 869 false true 4632 = true := by decide +kernel
private theorem w869_2 : checkWitness 869 true false 536 = true := by decide +kernel
private theorem w869_3 : checkWitness 869 true true 4632 = true := by decide +kernel
private theorem cases869 : checkFour 869 (536,4632,536,4632) = true := by
  simp only [checkFour, w869_0, w869_1, w869_2, w869_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one869 : Coverage 869 870 := checkList_sound (ws:=[(536,4632,536,4632)]) (by simpa only [checkList, Bool.and_true] using cases869)
private theorem w870_0 : checkWitness 870 false false 8910 = true := by decide +kernel
private theorem w870_2 : checkWitness 870 true false 8906 = true := by decide +kernel
private theorem cases870 : checkFour 870 (8910,0,8906,0) = true := by
  simp only [checkFour, w870_0, w870_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one870 : Coverage 870 871 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases870)
private theorem w871_0 : checkWitness 871 false false 68 = true := by decide +kernel
private theorem w871_2 : checkWitness 871 true false 68 = true := by decide +kernel
private theorem cases871 : checkFour 871 (68,0,68,0) = true := by
  simp only [checkFour, w871_0, w871_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one871 : Coverage 871 872 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases871)
private theorem w872_0 : checkWitness 872 false false 578 = true := by decide +kernel
private theorem w872_1 : checkWitness 872 false true 4674 = true := by decide +kernel
private theorem w872_2 : checkWitness 872 true false 578 = true := by decide +kernel
private theorem w872_3 : checkWitness 872 true true 4674 = true := by decide +kernel
private theorem cases872 : checkFour 872 (578,4674,578,4674) = true := by
  simp only [checkFour, w872_0, w872_1, w872_2, w872_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one872 : Coverage 872 873 := checkList_sound (ws:=[(578,4674,578,4674)]) (by simpa only [checkList, Bool.and_true] using cases872)
private theorem w873_0 : checkWitness 873 false false 8929 = true := by decide +kernel
private theorem w873_2 : checkWitness 873 true false 8925 = true := by decide +kernel
private theorem cases873 : checkFour 873 (8929,0,8925,0) = true := by
  simp only [checkFour, w873_0, w873_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one873 : Coverage 873 874 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases873)
private theorem w874_0 : checkWitness 874 false false 8960 = true := by decide +kernel
private theorem w874_2 : checkWitness 874 true false 8951 = true := by decide +kernel
private theorem cases874 : checkFour 874 (8960,0,8951,0) = true := by
  simp only [checkFour, w874_0, w874_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one874 : Coverage 874 875 := checkList_sound (ws:=[(8960,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases874)
private theorem w875_0 : checkWitness 875 false false 92 = true := by decide +kernel
private theorem w875_2 : checkWitness 875 true false 92 = true := by decide +kernel
private theorem cases875 : checkFour 875 (92,0,92,0) = true := by
  simp only [checkFour, w875_0, w875_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one875 : Coverage 875 876 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases875)
private theorem w876_0 : checkWitness 876 false false 674 = true := by decide +kernel
private theorem w876_1 : checkWitness 876 false true 4766 = true := by decide +kernel
private theorem w876_2 : checkWitness 876 true false 665 = true := by decide +kernel
private theorem w876_3 : checkWitness 876 true true 4757 = true := by decide +kernel
private theorem cases876 : checkFour 876 (674,4766,665,4757) = true := by
  simp only [checkFour, w876_0, w876_1, w876_2, w876_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one876 : Coverage 876 877 := checkList_sound (ws:=[(674,4766,665,4757)]) (by simpa only [checkList, Bool.and_true] using cases876)
private theorem w877_0 : checkWitness 877 false false 8925 = true := by decide +kernel
private theorem w877_2 : checkWitness 877 true false 8921 = true := by decide +kernel
private theorem cases877 : checkFour 877 (8925,0,8921,0) = true := by
  simp only [checkFour, w877_0, w877_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one877 : Coverage 877 878 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases877)
private theorem w878_0 : checkWitness 878 false false 668 = true := by decide +kernel
private theorem w878_1 : checkWitness 878 false true 4760 = true := by decide +kernel
private theorem w878_2 : checkWitness 878 true false 659 = true := by decide +kernel
private theorem w878_3 : checkWitness 878 true true 4751 = true := by decide +kernel
private theorem cases878 : checkFour 878 (668,4760,659,4751) = true := by
  simp only [checkFour, w878_0, w878_1, w878_2, w878_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one878 : Coverage 878 879 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases878)
private theorem w879_0 : checkWitness 879 false false 8896 = true := by decide +kernel
private theorem w879_2 : checkWitness 879 true false 8892 = true := by decide +kernel
private theorem cases879 : checkFour 879 (8896,0,8892,0) = true := by
  simp only [checkFour, w879_0, w879_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one879 : Coverage 879 880 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases879)
private theorem w880_0 : checkWitness 880 false false 80 = true := by decide +kernel
private theorem w880_2 : checkWitness 880 true false 80 = true := by decide +kernel
private theorem cases880 : checkFour 880 (80,0,80,0) = true := by
  simp only [checkFour, w880_0, w880_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one880 : Coverage 880 881 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases880)
private theorem w881_0 : checkWitness 881 false false 72 = true := by decide +kernel
private theorem w881_2 : checkWitness 881 true false 72 = true := by decide +kernel
private theorem cases881 : checkFour 881 (72,0,72,0) = true := by
  simp only [checkFour, w881_0, w881_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one881 : Coverage 881 882 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases881)
private theorem w882_0 : checkWitness 882 false false 621 = true := by decide +kernel
private theorem w882_1 : checkWitness 882 false true 4705 = true := by decide +kernel
private theorem w882_2 : checkWitness 882 true false 621 = true := by decide +kernel
private theorem w882_3 : checkWitness 882 true true 4705 = true := by decide +kernel
private theorem cases882 : checkFour 882 (621,4705,621,4705) = true := by
  simp only [checkFour, w882_0, w882_1, w882_2, w882_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one882 : Coverage 882 883 := checkList_sound (ws:=[(621,4705,621,4705)]) (by simpa only [checkList, Bool.and_true] using cases882)
private theorem w883_0 : checkWitness 883 false false 8888 = true := by decide +kernel
private theorem w883_2 : checkWitness 883 true false 8884 = true := by decide +kernel
private theorem cases883 : checkFour 883 (8888,0,8884,0) = true := by
  simp only [checkFour, w883_0, w883_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one883 : Coverage 883 884 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases883)
private theorem w884_0 : checkWitness 884 false false 72 = true := by decide +kernel
private theorem w884_2 : checkWitness 884 true false 72 = true := by decide +kernel
private theorem cases884 : checkFour 884 (72,0,72,0) = true := by
  simp only [checkFour, w884_0, w884_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one884 : Coverage 884 885 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases884)
private theorem w885_0 : checkWitness 885 false false 8904 = true := by decide +kernel
private theorem w885_2 : checkWitness 885 true false 8900 = true := by decide +kernel
private theorem cases885 : checkFour 885 (8904,0,8900,0) = true := by
  simp only [checkFour, w885_0, w885_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one885 : Coverage 885 886 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases885)
private theorem w886_0 : checkWitness 886 false false 554 = true := by decide +kernel
private theorem w886_1 : checkWitness 886 false true 4650 = true := by decide +kernel
private theorem w886_2 : checkWitness 886 true false 554 = true := by decide +kernel
private theorem w886_3 : checkWitness 886 true true 4650 = true := by decide +kernel
private theorem cases886 : checkFour 886 (554,4650,554,4650) = true := by
  simp only [checkFour, w886_0, w886_1, w886_2, w886_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one886 : Coverage 886 887 := checkList_sound (ws:=[(554,4650,554,4650)]) (by simpa only [checkList, Bool.and_true] using cases886)
private theorem w887_0 : checkWitness 887 false false 8928 = true := by decide +kernel
private theorem w887_2 : checkWitness 887 true false 8919 = true := by decide +kernel
private theorem cases887 : checkFour 887 (8928,0,8919,0) = true := by
  simp only [checkFour, w887_0, w887_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one887 : Coverage 887 888 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases887)
private theorem w888_0 : checkWitness 888 false false 74 = true := by decide +kernel
private theorem w888_2 : checkWitness 888 true false 74 = true := by decide +kernel
private theorem cases888 : checkFour 888 (74,0,74,0) = true := by
  simp only [checkFour, w888_0, w888_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one888 : Coverage 888 889 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases888)
private theorem w889_0 : checkWitness 889 false false 506 = true := by decide +kernel
private theorem w889_1 : checkWitness 889 false true 4602 = true := by decide +kernel
private theorem w889_2 : checkWitness 889 true false 506 = true := by decide +kernel
private theorem w889_3 : checkWitness 889 true true 4602 = true := by decide +kernel
private theorem cases889 : checkFour 889 (506,4602,506,4602) = true := by
  simp only [checkFour, w889_0, w889_1, w889_2, w889_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one889 : Coverage 889 890 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases889)
private theorem w890_0 : checkWitness 890 false false 8880 = true := by decide +kernel
private theorem w890_2 : checkWitness 890 true false 8876 = true := by decide +kernel
private theorem cases890 : checkFour 890 (8880,0,8876,0) = true := by
  simp only [checkFour, w890_0, w890_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one890 : Coverage 890 891 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases890)
private theorem w891_0 : checkWitness 891 false false 78 = true := by decide +kernel
private theorem w891_2 : checkWitness 891 true false 78 = true := by decide +kernel
private theorem cases891 : checkFour 891 (78,0,78,0) = true := by
  simp only [checkFour, w891_0, w891_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one891 : Coverage 891 892 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases891)
private theorem w892_0 : checkWitness 892 false false 548 = true := by decide +kernel
private theorem w892_1 : checkWitness 892 false true 4644 = true := by decide +kernel
private theorem w892_2 : checkWitness 892 true false 548 = true := by decide +kernel
private theorem w892_3 : checkWitness 892 true true 4644 = true := by decide +kernel
private theorem cases892 : checkFour 892 (548,4644,548,4644) = true := by
  simp only [checkFour, w892_0, w892_1, w892_2, w892_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one892 : Coverage 892 893 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases892)
private theorem w893_0 : checkWitness 893 false false 8899 = true := by decide +kernel
private theorem w893_2 : checkWitness 893 true false 8895 = true := by decide +kernel
private theorem cases893 : checkFour 893 (8899,0,8895,0) = true := by
  simp only [checkFour, w893_0, w893_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one893 : Coverage 893 894 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases893)
private theorem w894_0 : checkWitness 894 false false 8930 = true := by decide +kernel
private theorem w894_2 : checkWitness 894 true false 8921 = true := by decide +kernel
private theorem cases894 : checkFour 894 (8930,0,8921,0) = true := by
  simp only [checkFour, w894_0, w894_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one894 : Coverage 894 895 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases894)
private theorem w895_0 : checkWitness 895 false false 102 = true := by decide +kernel
private theorem w895_2 : checkWitness 895 true false 102 = true := by decide +kernel
private theorem cases895 : checkFour 895 (102,0,102,0) = true := by
  simp only [checkFour, w895_0, w895_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one895 : Coverage 895 896 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases895)
theorem cover0864 : Coverage 864 896 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one864 one865) (Coverage.join one866 one867)) (Coverage.join (Coverage.join one868 one869) (Coverage.join one870 one871))) (Coverage.join (Coverage.join (Coverage.join one872 one873) (Coverage.join one874 one875)) (Coverage.join (Coverage.join one876 one877) (Coverage.join one878 one879)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one880 one881) (Coverage.join one882 one883)) (Coverage.join (Coverage.join one884 one885) (Coverage.join one886 one887))) (Coverage.join (Coverage.join (Coverage.join one888 one889) (Coverage.join one890 one891)) (Coverage.join (Coverage.join one892 one893) (Coverage.join one894 one895)))))
end NF180PA.Symbolic
