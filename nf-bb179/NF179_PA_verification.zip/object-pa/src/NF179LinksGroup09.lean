import NF179LinksBase
namespace NF180PA.Links
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part2304 : Covers 2304 2320 := block_sound (lo:=2304) (n:=16) (by decide +kernel)
private theorem part2320 : Covers 2320 2336 := block_sound (lo:=2320) (n:=16) (by decide +kernel)
private theorem part2336 : Covers 2336 2352 := block_sound (lo:=2336) (n:=16) (by decide +kernel)
private theorem part2352 : Covers 2352 2368 := block_sound (lo:=2352) (n:=16) (by decide +kernel)
private theorem part2368 : Covers 2368 2384 := block_sound (lo:=2368) (n:=16) (by decide +kernel)
private theorem part2384 : Covers 2384 2400 := block_sound (lo:=2384) (n:=16) (by decide +kernel)
private theorem part2400 : Covers 2400 2416 := block_sound (lo:=2400) (n:=16) (by decide +kernel)
private theorem part2416 : Covers 2416 2432 := block_sound (lo:=2416) (n:=16) (by decide +kernel)
private theorem part2432 : Covers 2432 2448 := block_sound (lo:=2432) (n:=16) (by decide +kernel)
private theorem part2448 : Covers 2448 2464 := block_sound (lo:=2448) (n:=16) (by decide +kernel)
private theorem part2464 : Covers 2464 2480 := block_sound (lo:=2464) (n:=16) (by decide +kernel)
private theorem part2480 : Covers 2480 2496 := block_sound (lo:=2480) (n:=16) (by decide +kernel)
private theorem part2496 : Covers 2496 2512 := block_sound (lo:=2496) (n:=16) (by decide +kernel)
private theorem part2512 : Covers 2512 2528 := block_sound (lo:=2512) (n:=16) (by decide +kernel)
private theorem part2528 : Covers 2528 2544 := block_sound (lo:=2528) (n:=16) (by decide +kernel)
private theorem part2544 : Covers 2544 2560 := block_sound (lo:=2544) (n:=16) (by decide +kernel)
theorem group2304 : Covers 2304 2560 := (Covers.join (Covers.join (Covers.join (Covers.join part2304 part2320) (Covers.join part2336 part2352)) (Covers.join (Covers.join part2368 part2384) (Covers.join part2400 part2416))) (Covers.join (Covers.join (Covers.join part2432 part2448) (Covers.join part2464 part2480)) (Covers.join (Covers.join part2496 part2512) (Covers.join part2528 part2544))))
end NF180PA.Links
