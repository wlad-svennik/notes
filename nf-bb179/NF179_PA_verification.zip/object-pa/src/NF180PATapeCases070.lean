import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2240_0 : checkWitness 2240 false false 70 = true := by decide +kernel
private theorem w2240_2 : checkWitness 2240 true false 70 = true := by decide +kernel
private theorem cases2240 : checkFour 2240 (70,0,70,0) = true := by
  simp only [checkFour, w2240_0, w2240_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2240 : Coverage 2240 2241 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2240)
private theorem w2241_0 : checkWitness 2241 false false 585 = true := by decide +kernel
private theorem w2241_1 : checkWitness 2241 false true 4669 = true := by decide +kernel
private theorem w2241_2 : checkWitness 2241 true false 585 = true := by decide +kernel
private theorem w2241_3 : checkWitness 2241 true true 4669 = true := by decide +kernel
private theorem cases2241 : checkFour 2241 (585,4669,585,4669) = true := by
  simp only [checkFour, w2241_0, w2241_1, w2241_2, w2241_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2241 : Coverage 2241 2242 := checkList_sound (ws:=[(585,4669,585,4669)]) (by simpa only [checkList, Bool.and_true] using cases2241)
private theorem w2242_0 : checkWitness 2242 false false 8852 = true := by decide +kernel
private theorem w2242_2 : checkWitness 2242 true false 8848 = true := by decide +kernel
private theorem cases2242 : checkFour 2242 (8852,0,8848,0) = true := by
  simp only [checkFour, w2242_0, w2242_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2242 : Coverage 2242 2243 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases2242)
private theorem w2243_0 : checkWitness 2243 false false 70 = true := by decide +kernel
private theorem w2243_2 : checkWitness 2243 true false 70 = true := by decide +kernel
private theorem cases2243 : checkFour 2243 (70,0,70,0) = true := by
  simp only [checkFour, w2243_0, w2243_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2243 : Coverage 2243 2244 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2243)
private theorem w2244_0 : checkWitness 2244 false false 629 = true := by decide +kernel
private theorem w2244_1 : checkWitness 2244 false true 4721 = true := by decide +kernel
private theorem w2244_2 : checkWitness 2244 true false 620 = true := by decide +kernel
private theorem w2244_3 : checkWitness 2244 true true 4712 = true := by decide +kernel
private theorem cases2244 : checkFour 2244 (629,4721,620,4712) = true := by
  simp only [checkFour, w2244_0, w2244_1, w2244_2, w2244_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2244 : Coverage 2244 2245 := checkList_sound (ws:=[(629,4721,620,4712)]) (by simpa only [checkList, Bool.and_true] using cases2244)
private theorem w2245_0 : checkWitness 2245 false false 8926 = true := by decide +kernel
private theorem w2245_2 : checkWitness 2245 true false 8917 = true := by decide +kernel
private theorem cases2245 : checkFour 2245 (8926,0,8917,0) = true := by
  simp only [checkFour, w2245_0, w2245_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2245 : Coverage 2245 2246 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases2245)
private theorem w2246_0 : checkWitness 2246 false false 8872 = true := by decide +kernel
private theorem w2246_2 : checkWitness 2246 true false 8868 = true := by decide +kernel
private theorem cases2246 : checkFour 2246 (8872,0,8868,0) = true := by
  simp only [checkFour, w2246_0, w2246_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2246 : Coverage 2246 2247 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases2246)
private theorem w2247_0 : checkWitness 2247 false false 74 = true := by decide +kernel
private theorem w2247_2 : checkWitness 2247 true false 74 = true := by decide +kernel
private theorem cases2247 : checkFour 2247 (74,0,74,0) = true := by
  simp only [checkFour, w2247_0, w2247_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2247 : Coverage 2247 2248 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2247)
private theorem w2248_0 : checkWitness 2248 false false 652 = true := by decide +kernel
private theorem w2248_1 : checkWitness 2248 false true 4744 = true := by decide +kernel
private theorem w2248_2 : checkWitness 2248 true false 643 = true := by decide +kernel
private theorem w2248_3 : checkWitness 2248 true true 4735 = true := by decide +kernel
private theorem cases2248 : checkFour 2248 (652,4744,643,4735) = true := by
  simp only [checkFour, w2248_0, w2248_1, w2248_2, w2248_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2248 : Coverage 2248 2249 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases2248)
private theorem w2249_0 : checkWitness 2249 false false 8933 = true := by decide +kernel
private theorem w2249_2 : checkWitness 2249 true false 8924 = true := by decide +kernel
private theorem cases2249 : checkFour 2249 (8933,0,8924,0) = true := by
  simp only [checkFour, w2249_0, w2249_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2249 : Coverage 2249 2250 := checkList_sound (ws:=[(8933,0,8924,0)]) (by simpa only [checkList, Bool.and_true] using cases2249)
private theorem w2250_0 : checkWitness 2250 false false 58 = true := by decide +kernel
private theorem w2250_2 : checkWitness 2250 true false 58 = true := by decide +kernel
private theorem cases2250 : checkFour 2250 (58,0,58,0) = true := by
  simp only [checkFour, w2250_0, w2250_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2250 : Coverage 2250 2251 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2250)
private theorem w2251_0 : checkWitness 2251 false false 510 = true := by decide +kernel
private theorem w2251_1 : checkWitness 2251 false true 4606 = true := by decide +kernel
private theorem w2251_2 : checkWitness 2251 true false 510 = true := by decide +kernel
private theorem w2251_3 : checkWitness 2251 true true 4606 = true := by decide +kernel
private theorem cases2251 : checkFour 2251 (510,4606,510,4606) = true := by
  simp only [checkFour, w2251_0, w2251_1, w2251_2, w2251_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2251 : Coverage 2251 2252 := checkList_sound (ws:=[(510,4606,510,4606)]) (by simpa only [checkList, Bool.and_true] using cases2251)
private theorem w2252_0 : checkWitness 2252 false false 8913 = true := by decide +kernel
private theorem w2252_2 : checkWitness 2252 true false 8909 = true := by decide +kernel
private theorem cases2252 : checkFour 2252 (8913,0,8909,0) = true := by
  simp only [checkFour, w2252_0, w2252_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2252 : Coverage 2252 2253 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases2252)
private theorem w2253_0 : checkWitness 2253 false false 642 = true := by decide +kernel
private theorem w2253_1 : checkWitness 2253 false true 4738 = true := by decide +kernel
private theorem w2253_2 : checkWitness 2253 true false 633 = true := by decide +kernel
private theorem w2253_3 : checkWitness 2253 true true 4729 = true := by decide +kernel
private theorem cases2253 : checkFour 2253 (642,4738,633,4729) = true := by
  simp only [checkFour, w2253_0, w2253_1, w2253_2, w2253_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2253 : Coverage 2253 2254 := checkList_sound (ws:=[(642,4738,633,4729)]) (by simpa only [checkList, Bool.and_true] using cases2253)
private theorem w2254_0 : checkWitness 2254 false false 188 = true := by decide +kernel
private theorem w2254_2 : checkWitness 2254 true false 188 = true := by decide +kernel
private theorem cases2254 : checkFour 2254 (188,0,188,0) = true := by
  simp only [checkFour, w2254_0, w2254_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2254 : Coverage 2254 2255 := checkList_sound (ws:=[(188,0,188,0)]) (by simpa only [checkList, Bool.and_true] using cases2254)
private theorem w2255_0 : checkWitness 2255 false false 591 = true := by decide +kernel
private theorem w2255_1 : checkWitness 2255 false true 4679 = true := by decide +kernel
private theorem w2255_2 : checkWitness 2255 true false 591 = true := by decide +kernel
private theorem w2255_3 : checkWitness 2255 true true 4679 = true := by decide +kernel
private theorem cases2255 : checkFour 2255 (591,4679,591,4679) = true := by
  simp only [checkFour, w2255_0, w2255_1, w2255_2, w2255_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2255 : Coverage 2255 2256 := checkList_sound (ws:=[(591,4679,591,4679)]) (by simpa only [checkList, Bool.and_true] using cases2255)
private theorem w2256_0 : checkWitness 2256 false false 8924 = true := by decide +kernel
private theorem w2256_2 : checkWitness 2256 true false 8915 = true := by decide +kernel
private theorem cases2256 : checkFour 2256 (8924,0,8915,0) = true := by
  simp only [checkFour, w2256_0, w2256_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2256 : Coverage 2256 2257 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases2256)
private theorem w2257_0 : checkWitness 2257 false false 76 = true := by decide +kernel
private theorem w2257_2 : checkWitness 2257 true false 76 = true := by decide +kernel
private theorem cases2257 : checkFour 2257 (76,0,76,0) = true := by
  simp only [checkFour, w2257_0, w2257_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2257 : Coverage 2257 2258 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2257)
private theorem w2258_0 : checkWitness 2258 false false 68 = true := by decide +kernel
private theorem w2258_2 : checkWitness 2258 true false 68 = true := by decide +kernel
private theorem cases2258 : checkFour 2258 (68,0,68,0) = true := by
  simp only [checkFour, w2258_0, w2258_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2258 : Coverage 2258 2259 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2258)
private theorem w2259_0 : checkWitness 2259 false false 591 = true := by decide +kernel
private theorem w2259_1 : checkWitness 2259 false true 4683 = true := by decide +kernel
private theorem w2259_2 : checkWitness 2259 true false 591 = true := by decide +kernel
private theorem w2259_3 : checkWitness 2259 true true 4683 = true := by decide +kernel
private theorem cases2259 : checkFour 2259 (591,4683,591,4683) = true := by
  simp only [checkFour, w2259_0, w2259_1, w2259_2, w2259_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2259 : Coverage 2259 2260 := checkList_sound (ws:=[(591,4683,591,4683)]) (by simpa only [checkList, Bool.and_true] using cases2259)
private theorem w2260_0 : checkWitness 2260 false false 8866 = true := by decide +kernel
private theorem w2260_2 : checkWitness 2260 true false 8862 = true := by decide +kernel
private theorem cases2260 : checkFour 2260 (8866,0,8862,0) = true := by
  simp only [checkFour, w2260_0, w2260_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2260 : Coverage 2260 2261 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases2260)
private theorem w2261_0 : checkWitness 2261 false false 68 = true := by decide +kernel
private theorem w2261_2 : checkWitness 2261 true false 68 = true := by decide +kernel
private theorem cases2261 : checkFour 2261 (68,0,68,0) = true := by
  simp only [checkFour, w2261_0, w2261_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2261 : Coverage 2261 2262 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2261)
private theorem w2262_0 : checkWitness 2262 false false 550 = true := by decide +kernel
private theorem w2262_1 : checkWitness 2262 false true 4646 = true := by decide +kernel
private theorem w2262_2 : checkWitness 2262 true false 550 = true := by decide +kernel
private theorem w2262_3 : checkWitness 2262 true true 4646 = true := by decide +kernel
private theorem cases2262 : checkFour 2262 (550,4646,550,4646) = true := by
  simp only [checkFour, w2262_0, w2262_1, w2262_2, w2262_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2262 : Coverage 2262 2263 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases2262)
private theorem w2263_0 : checkWitness 2263 false false 8901 = true := by decide +kernel
private theorem w2263_2 : checkWitness 2263 true false 8897 = true := by decide +kernel
private theorem cases2263 : checkFour 2263 (8901,0,8897,0) = true := by
  simp only [checkFour, w2263_0, w2263_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2263 : Coverage 2263 2264 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases2263)
private theorem w2264_0 : checkWitness 2264 false false 8932 = true := by decide +kernel
private theorem w2264_2 : checkWitness 2264 true false 8923 = true := by decide +kernel
private theorem cases2264 : checkFour 2264 (8932,0,8923,0) = true := by
  simp only [checkFour, w2264_0, w2264_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2264 : Coverage 2264 2265 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases2264)
private theorem w2265_0 : checkWitness 2265 false false 86 = true := by decide +kernel
private theorem w2265_2 : checkWitness 2265 true false 86 = true := by decide +kernel
private theorem cases2265 : checkFour 2265 (86,0,86,0) = true := by
  simp only [checkFour, w2265_0, w2265_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2265 : Coverage 2265 2266 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases2265)
private theorem w2266_0 : checkWitness 2266 false false 646 = true := by decide +kernel
private theorem w2266_1 : checkWitness 2266 false true 4738 = true := by decide +kernel
private theorem w2266_2 : checkWitness 2266 true false 637 = true := by decide +kernel
private theorem w2266_3 : checkWitness 2266 true true 4729 = true := by decide +kernel
private theorem cases2266 : checkFour 2266 (646,4738,637,4729) = true := by
  simp only [checkFour, w2266_0, w2266_1, w2266_2, w2266_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2266 : Coverage 2266 2267 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases2266)
private theorem w2267_0 : checkWitness 2267 false false 8897 = true := by decide +kernel
private theorem w2267_2 : checkWitness 2267 true false 8893 = true := by decide +kernel
private theorem cases2267 : checkFour 2267 (8897,0,8893,0) = true := by
  simp only [checkFour, w2267_0, w2267_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2267 : Coverage 2267 2268 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases2267)
private theorem w2268_0 : checkWitness 2268 false false 640 = true := by decide +kernel
private theorem w2268_1 : checkWitness 2268 false true 4732 = true := by decide +kernel
private theorem w2268_2 : checkWitness 2268 true false 631 = true := by decide +kernel
private theorem w2268_3 : checkWitness 2268 true true 4723 = true := by decide +kernel
private theorem cases2268 : checkFour 2268 (640,4732,631,4723) = true := by
  simp only [checkFour, w2268_0, w2268_1, w2268_2, w2268_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2268 : Coverage 2268 2269 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases2268)
private theorem w2269_0 : checkWitness 2269 false false 8868 = true := by decide +kernel
private theorem w2269_2 : checkWitness 2269 true false 8864 = true := by decide +kernel
private theorem cases2269 : checkFour 2269 (8868,0,8864,0) = true := by
  simp only [checkFour, w2269_0, w2269_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2269 : Coverage 2269 2270 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases2269)
private theorem w2270_0 : checkWitness 2270 false false 74 = true := by decide +kernel
private theorem w2270_2 : checkWitness 2270 true false 74 = true := by decide +kernel
private theorem cases2270 : checkFour 2270 (74,0,74,0) = true := by
  simp only [checkFour, w2270_0, w2270_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2270 : Coverage 2270 2271 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2270)
private theorem w2271_0 : checkWitness 2271 false false 66 = true := by decide +kernel
private theorem w2271_2 : checkWitness 2271 true false 66 = true := by decide +kernel
private theorem cases2271 : checkFour 2271 (66,0,66,0) = true := by
  simp only [checkFour, w2271_0, w2271_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2271 : Coverage 2271 2272 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2271)
theorem cover2240 : Coverage 2240 2272 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2240 one2241) (Coverage.join one2242 one2243)) (Coverage.join (Coverage.join one2244 one2245) (Coverage.join one2246 one2247))) (Coverage.join (Coverage.join (Coverage.join one2248 one2249) (Coverage.join one2250 one2251)) (Coverage.join (Coverage.join one2252 one2253) (Coverage.join one2254 one2255)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2256 one2257) (Coverage.join one2258 one2259)) (Coverage.join (Coverage.join one2260 one2261) (Coverage.join one2262 one2263))) (Coverage.join (Coverage.join (Coverage.join one2264 one2265) (Coverage.join one2266 one2267)) (Coverage.join (Coverage.join one2268 one2269) (Coverage.join one2270 one2271)))))
end NF180PA.Symbolic
