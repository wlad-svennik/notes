import NF179Literal
import NF180PATapeReverse
import NF180PATapeAll

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch.RegisterSource (address)

namespace NF179
/-- This equivalence quantifies over the register and tape clocks of each PA model. -/
theorem halting_iff_register_halt {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    (V ⊧/![] H179) ↔ ∃ j : V, address (NF180PA.Registers.run j) = 4095 :=
  NF180PA.Symbolic.tape_iff_source_of_coverage NF180PA.Symbolic.literal_table_coverage
end NF179
#print axioms NF179.halting_iff_register_halt
