import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w544_0 : checkWitness 544 false false 80 = true := by decide +kernel
private theorem w544_2 : checkWitness 544 true false 80 = true := by decide +kernel
private theorem cases544 : checkFour 544 (80,0,80,0) = true := by
  simp only [checkFour, w544_0, w544_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one544 : Coverage 544 545 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases544)
private theorem w545_0 : checkWitness 545 false false 72 = true := by decide +kernel
private theorem w545_2 : checkWitness 545 true false 72 = true := by decide +kernel
private theorem cases545 : checkFour 545 (72,0,72,0) = true := by
  simp only [checkFour, w545_0, w545_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one545 : Coverage 545 546 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases545)
private theorem w546_0 : checkWitness 546 false false 601 = true := by decide +kernel
private theorem w546_1 : checkWitness 546 false true 4685 = true := by decide +kernel
private theorem w546_2 : checkWitness 546 true false 601 = true := by decide +kernel
private theorem w546_3 : checkWitness 546 true true 4685 = true := by decide +kernel
private theorem cases546 : checkFour 546 (601,4685,601,4685) = true := by
  simp only [checkFour, w546_0, w546_1, w546_2, w546_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one546 : Coverage 546 547 := checkList_sound (ws:=[(601,4685,601,4685)]) (by simpa only [checkList, Bool.and_true] using cases546)
private theorem w547_0 : checkWitness 547 false false 8868 = true := by decide +kernel
private theorem w547_2 : checkWitness 547 true false 8864 = true := by decide +kernel
private theorem cases547 : checkFour 547 (8868,0,8864,0) = true := by
  simp only [checkFour, w547_0, w547_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one547 : Coverage 547 548 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases547)
private theorem w548_0 : checkWitness 548 false false 72 = true := by decide +kernel
private theorem w548_2 : checkWitness 548 true false 72 = true := by decide +kernel
private theorem cases548 : checkFour 548 (72,0,72,0) = true := by
  simp only [checkFour, w548_0, w548_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one548 : Coverage 548 549 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases548)
private theorem w549_0 : checkWitness 549 false false 645 = true := by decide +kernel
private theorem w549_1 : checkWitness 549 false true 4737 = true := by decide +kernel
private theorem w549_2 : checkWitness 549 true false 636 = true := by decide +kernel
private theorem w549_3 : checkWitness 549 true true 4728 = true := by decide +kernel
private theorem cases549 : checkFour 549 (645,4737,636,4728) = true := by
  simp only [checkFour, w549_0, w549_1, w549_2, w549_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one549 : Coverage 549 550 := checkList_sound (ws:=[(645,4737,636,4728)]) (by simpa only [checkList, Bool.and_true] using cases549)
private theorem w550_0 : checkWitness 550 false false 8942 = true := by decide +kernel
private theorem w550_2 : checkWitness 550 true false 8933 = true := by decide +kernel
private theorem cases550 : checkFour 550 (8942,0,8933,0) = true := by
  simp only [checkFour, w550_0, w550_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one550 : Coverage 550 551 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases550)
private theorem w551_0 : checkWitness 551 false false 8888 = true := by decide +kernel
private theorem w551_2 : checkWitness 551 true false 8884 = true := by decide +kernel
private theorem cases551 : checkFour 551 (8888,0,8884,0) = true := by
  simp only [checkFour, w551_0, w551_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one551 : Coverage 551 552 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases551)
private theorem w552_0 : checkWitness 552 false false 76 = true := by decide +kernel
private theorem w552_2 : checkWitness 552 true false 76 = true := by decide +kernel
private theorem cases552 : checkFour 552 (76,0,76,0) = true := by
  simp only [checkFour, w552_0, w552_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one552 : Coverage 552 553 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases552)
private theorem w553_0 : checkWitness 553 false false 668 = true := by decide +kernel
private theorem w553_1 : checkWitness 553 false true 4760 = true := by decide +kernel
private theorem w553_2 : checkWitness 553 true false 659 = true := by decide +kernel
private theorem w553_3 : checkWitness 553 true true 4751 = true := by decide +kernel
private theorem cases553 : checkFour 553 (668,4760,659,4751) = true := by
  simp only [checkFour, w553_0, w553_1, w553_2, w553_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one553 : Coverage 553 554 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases553)
private theorem w554_0 : checkWitness 554 false false 8949 = true := by decide +kernel
private theorem w554_2 : checkWitness 554 true false 8940 = true := by decide +kernel
private theorem cases554 : checkFour 554 (8949,0,8940,0) = true := by
  simp only [checkFour, w554_0, w554_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one554 : Coverage 554 555 := checkList_sound (ws:=[(8949,0,8940,0)]) (by simpa only [checkList, Bool.and_true] using cases554)
private theorem w555_0 : checkWitness 555 false false 60 = true := by decide +kernel
private theorem w555_2 : checkWitness 555 true false 60 = true := by decide +kernel
private theorem cases555 : checkFour 555 (60,0,60,0) = true := by
  simp only [checkFour, w555_0, w555_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one555 : Coverage 555 556 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases555)
private theorem w556_0 : checkWitness 556 false false 526 = true := by decide +kernel
private theorem w556_1 : checkWitness 556 false true 4622 = true := by decide +kernel
private theorem w556_2 : checkWitness 556 true false 526 = true := by decide +kernel
private theorem w556_3 : checkWitness 556 true true 4622 = true := by decide +kernel
private theorem cases556 : checkFour 556 (526,4622,526,4622) = true := by
  simp only [checkFour, w556_0, w556_1, w556_2, w556_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one556 : Coverage 556 557 := checkList_sound (ws:=[(526,4622,526,4622)]) (by simpa only [checkList, Bool.and_true] using cases556)
private theorem w557_0 : checkWitness 557 false false 8929 = true := by decide +kernel
private theorem w557_2 : checkWitness 557 true false 8925 = true := by decide +kernel
private theorem cases557 : checkFour 557 (8929,0,8925,0) = true := by
  simp only [checkFour, w557_0, w557_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one557 : Coverage 557 558 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases557)
private theorem w558_0 : checkWitness 558 false false 658 = true := by decide +kernel
private theorem w558_1 : checkWitness 558 false true 4754 = true := by decide +kernel
private theorem w558_2 : checkWitness 558 true false 649 = true := by decide +kernel
private theorem w558_3 : checkWitness 558 true true 4745 = true := by decide +kernel
private theorem cases558 : checkFour 558 (658,4754,649,4745) = true := by
  simp only [checkFour, w558_0, w558_1, w558_2, w558_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one558 : Coverage 558 559 := checkList_sound (ws:=[(658,4754,649,4745)]) (by simpa only [checkList, Bool.and_true] using cases558)
private theorem w559_0 : checkWitness 559 false false 194 = true := by decide +kernel
private theorem w559_2 : checkWitness 559 true false 194 = true := by decide +kernel
private theorem cases559 : checkFour 559 (194,0,194,0) = true := by
  simp only [checkFour, w559_0, w559_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one559 : Coverage 559 560 := checkList_sound (ws:=[(194,0,194,0)]) (by simpa only [checkList, Bool.and_true] using cases559)
private theorem w560_0 : checkWitness 560 false false 607 = true := by decide +kernel
private theorem w560_1 : checkWitness 560 false true 4695 = true := by decide +kernel
private theorem w560_2 : checkWitness 560 true false 607 = true := by decide +kernel
private theorem w560_3 : checkWitness 560 true true 4695 = true := by decide +kernel
private theorem cases560 : checkFour 560 (607,4695,607,4695) = true := by
  simp only [checkFour, w560_0, w560_1, w560_2, w560_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one560 : Coverage 560 561 := checkList_sound (ws:=[(607,4695,607,4695)]) (by simpa only [checkList, Bool.and_true] using cases560)
private theorem w561_0 : checkWitness 561 false false 8940 = true := by decide +kernel
private theorem w561_2 : checkWitness 561 true false 8931 = true := by decide +kernel
private theorem cases561 : checkFour 561 (8940,0,8931,0) = true := by
  simp only [checkFour, w561_0, w561_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one561 : Coverage 561 562 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases561)
private theorem w562_0 : checkWitness 562 false false 78 = true := by decide +kernel
private theorem w562_2 : checkWitness 562 true false 78 = true := by decide +kernel
private theorem cases562 : checkFour 562 (78,0,78,0) = true := by
  simp only [checkFour, w562_0, w562_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one562 : Coverage 562 563 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases562)
private theorem w563_0 : checkWitness 563 false false 70 = true := by decide +kernel
private theorem w563_2 : checkWitness 563 true false 70 = true := by decide +kernel
private theorem cases563 : checkFour 563 (70,0,70,0) = true := by
  simp only [checkFour, w563_0, w563_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one563 : Coverage 563 564 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases563)
private theorem w564_0 : checkWitness 564 false false 607 = true := by decide +kernel
private theorem w564_1 : checkWitness 564 false true 4699 = true := by decide +kernel
private theorem w564_2 : checkWitness 564 true false 607 = true := by decide +kernel
private theorem w564_3 : checkWitness 564 true true 4699 = true := by decide +kernel
private theorem cases564 : checkFour 564 (607,4699,607,4699) = true := by
  simp only [checkFour, w564_0, w564_1, w564_2, w564_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one564 : Coverage 564 565 := checkList_sound (ws:=[(607,4699,607,4699)]) (by simpa only [checkList, Bool.and_true] using cases564)
private theorem w565_0 : checkWitness 565 false false 8882 = true := by decide +kernel
private theorem w565_2 : checkWitness 565 true false 8878 = true := by decide +kernel
private theorem cases565 : checkFour 565 (8882,0,8878,0) = true := by
  simp only [checkFour, w565_0, w565_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one565 : Coverage 565 566 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases565)
private theorem w566_0 : checkWitness 566 false false 70 = true := by decide +kernel
private theorem w566_2 : checkWitness 566 true false 70 = true := by decide +kernel
private theorem cases566 : checkFour 566 (70,0,70,0) = true := by
  simp only [checkFour, w566_0, w566_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one566 : Coverage 566 567 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases566)
private theorem w567_0 : checkWitness 567 false false 566 = true := by decide +kernel
private theorem w567_1 : checkWitness 567 false true 4662 = true := by decide +kernel
private theorem w567_2 : checkWitness 567 true false 566 = true := by decide +kernel
private theorem w567_3 : checkWitness 567 true true 4662 = true := by decide +kernel
private theorem cases567 : checkFour 567 (566,4662,566,4662) = true := by
  simp only [checkFour, w567_0, w567_1, w567_2, w567_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one567 : Coverage 567 568 := checkList_sound (ws:=[(566,4662,566,4662)]) (by simpa only [checkList, Bool.and_true] using cases567)
private theorem w568_0 : checkWitness 568 false false 8917 = true := by decide +kernel
private theorem w568_2 : checkWitness 568 true false 8913 = true := by decide +kernel
private theorem cases568 : checkFour 568 (8917,0,8913,0) = true := by
  simp only [checkFour, w568_0, w568_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one568 : Coverage 568 569 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases568)
private theorem w569_0 : checkWitness 569 false false 8948 = true := by decide +kernel
private theorem w569_2 : checkWitness 569 true false 8939 = true := by decide +kernel
private theorem cases569 : checkFour 569 (8948,0,8939,0) = true := by
  simp only [checkFour, w569_0, w569_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one569 : Coverage 569 570 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases569)
private theorem w570_0 : checkWitness 570 false false 88 = true := by decide +kernel
private theorem w570_2 : checkWitness 570 true false 88 = true := by decide +kernel
private theorem cases570 : checkFour 570 (88,0,88,0) = true := by
  simp only [checkFour, w570_0, w570_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one570 : Coverage 570 571 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases570)
private theorem w571_0 : checkWitness 571 false false 662 = true := by decide +kernel
private theorem w571_1 : checkWitness 571 false true 4754 = true := by decide +kernel
private theorem w571_2 : checkWitness 571 true false 653 = true := by decide +kernel
private theorem w571_3 : checkWitness 571 true true 4745 = true := by decide +kernel
private theorem cases571 : checkFour 571 (662,4754,653,4745) = true := by
  simp only [checkFour, w571_0, w571_1, w571_2, w571_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one571 : Coverage 571 572 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases571)
private theorem w572_0 : checkWitness 572 false false 8913 = true := by decide +kernel
private theorem w572_2 : checkWitness 572 true false 8909 = true := by decide +kernel
private theorem cases572 : checkFour 572 (8913,0,8909,0) = true := by
  simp only [checkFour, w572_0, w572_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one572 : Coverage 572 573 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases572)
private theorem w573_0 : checkWitness 573 false false 656 = true := by decide +kernel
private theorem w573_1 : checkWitness 573 false true 4748 = true := by decide +kernel
private theorem w573_2 : checkWitness 573 true false 647 = true := by decide +kernel
private theorem w573_3 : checkWitness 573 true true 4739 = true := by decide +kernel
private theorem cases573 : checkFour 573 (656,4748,647,4739) = true := by
  simp only [checkFour, w573_0, w573_1, w573_2, w573_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one573 : Coverage 573 574 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases573)
private theorem w574_0 : checkWitness 574 false false 8884 = true := by decide +kernel
private theorem w574_2 : checkWitness 574 true false 8880 = true := by decide +kernel
private theorem cases574 : checkFour 574 (8884,0,8880,0) = true := by
  simp only [checkFour, w574_0, w574_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one574 : Coverage 574 575 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases574)
private theorem w575_0 : checkWitness 575 false false 76 = true := by decide +kernel
private theorem w575_2 : checkWitness 575 true false 76 = true := by decide +kernel
private theorem cases575 : checkFour 575 (76,0,76,0) = true := by
  simp only [checkFour, w575_0, w575_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one575 : Coverage 575 576 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases575)
theorem cover0544 : Coverage 544 576 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one544 one545) (Coverage.join one546 one547)) (Coverage.join (Coverage.join one548 one549) (Coverage.join one550 one551))) (Coverage.join (Coverage.join (Coverage.join one552 one553) (Coverage.join one554 one555)) (Coverage.join (Coverage.join one556 one557) (Coverage.join one558 one559)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one560 one561) (Coverage.join one562 one563)) (Coverage.join (Coverage.join one564 one565) (Coverage.join one566 one567))) (Coverage.join (Coverage.join (Coverage.join one568 one569) (Coverage.join one570 one571)) (Coverage.join (Coverage.join one572 one573) (Coverage.join one574 one575)))))
end NF180PA.Symbolic
