import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1088_0 : checkWitness 1088 false false 8916 = true := by decide +kernel
private theorem w1088_2 : checkWitness 1088 true false 8907 = true := by decide +kernel
private theorem cases1088 : checkFour 1088 (8916,0,8907,0) = true := by
  simp only [checkFour, w1088_0, w1088_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1088 : Coverage 1088 1089 := checkList_sound (ws:=[(8916,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases1088)
private theorem w1089_0 : checkWitness 1089 false false 8862 = true := by decide +kernel
private theorem w1089_2 : checkWitness 1089 true false 8858 = true := by decide +kernel
private theorem cases1089 : checkFour 1089 (8862,0,8858,0) = true := by
  simp only [checkFour, w1089_0, w1089_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1089 : Coverage 1089 1090 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases1089)
private theorem w1090_0 : checkWitness 1090 false false 84 = true := by decide +kernel
private theorem w1090_2 : checkWitness 1090 true false 84 = true := by decide +kernel
private theorem cases1090 : checkFour 1090 (84,0,84,0) = true := by
  simp only [checkFour, w1090_0, w1090_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1090 : Coverage 1090 1091 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1090)
private theorem w1091_0 : checkWitness 1091 false false 642 = true := by decide +kernel
private theorem w1091_1 : checkWitness 1091 false true 4734 = true := by decide +kernel
private theorem w1091_2 : checkWitness 1091 true false 633 = true := by decide +kernel
private theorem w1091_3 : checkWitness 1091 true true 4725 = true := by decide +kernel
private theorem cases1091 : checkFour 1091 (642,4734,633,4725) = true := by
  simp only [checkFour, w1091_0, w1091_1, w1091_2, w1091_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1091 : Coverage 1091 1092 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases1091)
private theorem w1092_0 : checkWitness 1092 false false 8923 = true := by decide +kernel
private theorem w1092_2 : checkWitness 1092 true false 8914 = true := by decide +kernel
private theorem cases1092 : checkFour 1092 (8923,0,8914,0) = true := by
  simp only [checkFour, w1092_0, w1092_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1092 : Coverage 1092 1093 := checkList_sound (ws:=[(8923,0,8914,0)]) (by simpa only [checkList, Bool.and_true] using cases1092)
private theorem w1093_0 : checkWitness 1093 false false 68 = true := by decide +kernel
private theorem w1093_2 : checkWitness 1093 true false 68 = true := by decide +kernel
private theorem cases1093 : checkFour 1093 (68,0,68,0) = true := by
  simp only [checkFour, w1093_0, w1093_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1093 : Coverage 1093 1094 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases1093)
private theorem w1094_0 : checkWitness 1094 false false 630 = true := by decide +kernel
private theorem w1094_1 : checkWitness 1094 false true 4726 = true := by decide +kernel
private theorem w1094_2 : checkWitness 1094 true false 630 = true := by decide +kernel
private theorem w1094_3 : checkWitness 1094 true true 4726 = true := by decide +kernel
private theorem cases1094 : checkFour 1094 (630,4726,630,4726) = true := by
  simp only [checkFour, w1094_0, w1094_1, w1094_2, w1094_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1094 : Coverage 1094 1095 := checkList_sound (ws:=[(630,4726,630,4726)]) (by simpa only [checkList, Bool.and_true] using cases1094)
private theorem w1095_0 : checkWitness 1095 false false 8908 = true := by decide +kernel
private theorem w1095_2 : checkWitness 1095 true false 8899 = true := by decide +kernel
private theorem cases1095 : checkFour 1095 (8908,0,8899,0) = true := by
  simp only [checkFour, w1095_0, w1095_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1095 : Coverage 1095 1096 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases1095)
private theorem w1096_0 : checkWitness 1096 false false 74 = true := by decide +kernel
private theorem w1096_2 : checkWitness 1096 true false 74 = true := by decide +kernel
private theorem cases1096 : checkFour 1096 (74,0,74,0) = true := by
  simp only [checkFour, w1096_0, w1096_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1096 : Coverage 1096 1097 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1096)
private theorem w1097_0 : checkWitness 1097 false false 486 = true := by decide +kernel
private theorem w1097_1 : checkWitness 1097 false true 4582 = true := by decide +kernel
private theorem w1097_2 : checkWitness 1097 true false 486 = true := by decide +kernel
private theorem w1097_3 : checkWitness 1097 true true 4582 = true := by decide +kernel
private theorem cases1097 : checkFour 1097 (486,4582,486,4582) = true := by
  simp only [checkFour, w1097_0, w1097_1, w1097_2, w1097_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1097 : Coverage 1097 1098 := checkList_sound (ws:=[(486,4582,486,4582)]) (by simpa only [checkList, Bool.and_true] using cases1097)
private theorem w1098_0 : checkWitness 1098 false false 8860 = true := by decide +kernel
private theorem w1098_2 : checkWitness 1098 true false 8856 = true := by decide +kernel
private theorem cases1098 : checkFour 1098 (8860,0,8856,0) = true := by
  simp only [checkFour, w1098_0, w1098_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1098 : Coverage 1098 1099 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases1098)
private theorem w1099_0 : checkWitness 1099 false false 78 = true := by decide +kernel
private theorem w1099_2 : checkWitness 1099 true false 78 = true := by decide +kernel
private theorem cases1099 : checkFour 1099 (78,0,78,0) = true := by
  simp only [checkFour, w1099_0, w1099_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1099 : Coverage 1099 1100 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1099)
private theorem w1100_0 : checkWitness 1100 false false 528 = true := by decide +kernel
private theorem w1100_1 : checkWitness 1100 false true 4624 = true := by decide +kernel
private theorem w1100_2 : checkWitness 1100 true false 528 = true := by decide +kernel
private theorem w1100_3 : checkWitness 1100 true true 4624 = true := by decide +kernel
private theorem cases1100 : checkFour 1100 (528,4624,528,4624) = true := by
  simp only [checkFour, w1100_0, w1100_1, w1100_2, w1100_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1100 : Coverage 1100 1101 := checkList_sound (ws:=[(528,4624,528,4624)]) (by simpa only [checkList, Bool.and_true] using cases1100)
private theorem w1101_0 : checkWitness 1101 false false 8879 = true := by decide +kernel
private theorem w1101_2 : checkWitness 1101 true false 8875 = true := by decide +kernel
private theorem cases1101 : checkFour 1101 (8879,0,8875,0) = true := by
  simp only [checkFour, w1101_0, w1101_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1101 : Coverage 1101 1102 := checkList_sound (ws:=[(8879,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases1101)
private theorem w1102_0 : checkWitness 1102 false false 8910 = true := by decide +kernel
private theorem w1102_2 : checkWitness 1102 true false 8901 = true := by decide +kernel
private theorem cases1102 : checkFour 1102 (8910,0,8901,0) = true := by
  simp only [checkFour, w1102_0, w1102_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1102 : Coverage 1102 1103 := checkList_sound (ws:=[(8910,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases1102)
private theorem w1103_0 : checkWitness 1103 false false 102 = true := by decide +kernel
private theorem w1103_2 : checkWitness 1103 true false 102 = true := by decide +kernel
private theorem cases1103 : checkFour 1103 (102,0,102,0) = true := by
  simp only [checkFour, w1103_0, w1103_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1103 : Coverage 1103 1104 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1103)
private theorem w1104_0 : checkWitness 1104 false false 624 = true := by decide +kernel
private theorem w1104_1 : checkWitness 1104 false true 4716 = true := by decide +kernel
private theorem w1104_2 : checkWitness 1104 true false 615 = true := by decide +kernel
private theorem w1104_3 : checkWitness 1104 true true 4707 = true := by decide +kernel
private theorem cases1104 : checkFour 1104 (624,4716,615,4707) = true := by
  simp only [checkFour, w1104_0, w1104_1, w1104_2, w1104_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1104 : Coverage 1104 1105 := checkList_sound (ws:=[(624,4716,615,4707)]) (by simpa only [checkList, Bool.and_true] using cases1104)
private theorem w1105_0 : checkWitness 1105 false false 8875 = true := by decide +kernel
private theorem w1105_2 : checkWitness 1105 true false 8871 = true := by decide +kernel
private theorem cases1105 : checkFour 1105 (8875,0,8871,0) = true := by
  simp only [checkFour, w1105_0, w1105_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1105 : Coverage 1105 1106 := checkList_sound (ws:=[(8875,0,8871,0)]) (by simpa only [checkList, Bool.and_true] using cases1105)
private theorem w1106_0 : checkWitness 1106 false false 618 = true := by decide +kernel
private theorem w1106_1 : checkWitness 1106 false true 4710 = true := by decide +kernel
private theorem w1106_2 : checkWitness 1106 true false 609 = true := by decide +kernel
private theorem w1106_3 : checkWitness 1106 true true 4701 = true := by decide +kernel
private theorem cases1106 : checkFour 1106 (618,4710,609,4701) = true := by
  simp only [checkFour, w1106_0, w1106_1, w1106_2, w1106_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1106 : Coverage 1106 1107 := checkList_sound (ws:=[(618,4710,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases1106)
private theorem w1107_0 : checkWitness 1107 false false 8846 = true := by decide +kernel
private theorem w1107_2 : checkWitness 1107 true false 8842 = true := by decide +kernel
private theorem cases1107 : checkFour 1107 (8846,0,8842,0) = true := by
  simp only [checkFour, w1107_0, w1107_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1107 : Coverage 1107 1108 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1107)
private theorem w1108_0 : checkWitness 1108 false false 90 = true := by decide +kernel
private theorem w1108_2 : checkWitness 1108 true false 90 = true := by decide +kernel
private theorem cases1108 : checkFour 1108 (90,0,90,0) = true := by
  simp only [checkFour, w1108_0, w1108_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1108 : Coverage 1108 1109 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1108)
private theorem w1109_0 : checkWitness 1109 false false 82 = true := by decide +kernel
private theorem w1109_2 : checkWitness 1109 true false 82 = true := by decide +kernel
private theorem cases1109 : checkFour 1109 (82,0,82,0) = true := by
  simp only [checkFour, w1109_0, w1109_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1109 : Coverage 1109 1110 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1109)
private theorem w1110_0 : checkWitness 1110 false false 571 = true := by decide +kernel
private theorem w1110_1 : checkWitness 1110 false true 4655 = true := by decide +kernel
private theorem w1110_2 : checkWitness 1110 true false 571 = true := by decide +kernel
private theorem w1110_3 : checkWitness 1110 true true 4655 = true := by decide +kernel
private theorem cases1110 : checkFour 1110 (571,4655,571,4655) = true := by
  simp only [checkFour, w1110_0, w1110_1, w1110_2, w1110_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1110 : Coverage 1110 1111 := checkList_sound (ws:=[(571,4655,571,4655)]) (by simpa only [checkList, Bool.and_true] using cases1110)
private theorem w1111_0 : checkWitness 1111 false false 8838 = true := by decide +kernel
private theorem w1111_2 : checkWitness 1111 true false 8834 = true := by decide +kernel
private theorem cases1111 : checkFour 1111 (8838,0,8834,0) = true := by
  simp only [checkFour, w1111_0, w1111_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1111 : Coverage 1111 1112 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1111)
private theorem w1112_0 : checkWitness 1112 false false 82 = true := by decide +kernel
private theorem w1112_2 : checkWitness 1112 true false 82 = true := by decide +kernel
private theorem cases1112 : checkFour 1112 (82,0,82,0) = true := by
  simp only [checkFour, w1112_0, w1112_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1112 : Coverage 1112 1113 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1112)
private theorem w1113_0 : checkWitness 1113 false false 615 = true := by decide +kernel
private theorem w1113_1 : checkWitness 1113 false true 4707 = true := by decide +kernel
private theorem w1113_2 : checkWitness 1113 true false 606 = true := by decide +kernel
private theorem w1113_3 : checkWitness 1113 true true 4698 = true := by decide +kernel
private theorem cases1113 : checkFour 1113 (615,4707,606,4698) = true := by
  simp only [checkFour, w1113_0, w1113_1, w1113_2, w1113_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1113 : Coverage 1113 1114 := checkList_sound (ws:=[(615,4707,606,4698)]) (by simpa only [checkList, Bool.and_true] using cases1113)
private theorem w1114_0 : checkWitness 1114 false false 8912 = true := by decide +kernel
private theorem w1114_2 : checkWitness 1114 true false 8903 = true := by decide +kernel
private theorem cases1114 : checkFour 1114 (8912,0,8903,0) = true := by
  simp only [checkFour, w1114_0, w1114_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1114 : Coverage 1114 1115 := checkList_sound (ws:=[(8912,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases1114)
private theorem w1115_0 : checkWitness 1115 false false 8858 = true := by decide +kernel
private theorem w1115_2 : checkWitness 1115 true false 8854 = true := by decide +kernel
private theorem cases1115 : checkFour 1115 (8858,0,8854,0) = true := by
  simp only [checkFour, w1115_0, w1115_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1115 : Coverage 1115 1116 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1115)
private theorem w1116_0 : checkWitness 1116 false false 86 = true := by decide +kernel
private theorem w1116_2 : checkWitness 1116 true false 86 = true := by decide +kernel
private theorem cases1116 : checkFour 1116 (86,0,86,0) = true := by
  simp only [checkFour, w1116_0, w1116_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1116 : Coverage 1116 1117 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1116)
private theorem w1117_0 : checkWitness 1117 false false 638 = true := by decide +kernel
private theorem w1117_1 : checkWitness 1117 false true 4730 = true := by decide +kernel
private theorem w1117_2 : checkWitness 1117 true false 629 = true := by decide +kernel
private theorem w1117_3 : checkWitness 1117 true true 4721 = true := by decide +kernel
private theorem cases1117 : checkFour 1117 (638,4730,629,4721) = true := by
  simp only [checkFour, w1117_0, w1117_1, w1117_2, w1117_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1117 : Coverage 1117 1118 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases1117)
private theorem w1118_0 : checkWitness 1118 false false 8919 = true := by decide +kernel
private theorem w1118_2 : checkWitness 1118 true false 8910 = true := by decide +kernel
private theorem cases1118 : checkFour 1118 (8919,0,8910,0) = true := by
  simp only [checkFour, w1118_0, w1118_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1118 : Coverage 1118 1119 := checkList_sound (ws:=[(8919,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases1118)
private theorem w1119_0 : checkWitness 1119 false false 70 = true := by decide +kernel
private theorem w1119_2 : checkWitness 1119 true false 70 = true := by decide +kernel
private theorem cases1119 : checkFour 1119 (70,0,70,0) = true := by
  simp only [checkFour, w1119_0, w1119_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1119 : Coverage 1119 1120 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases1119)
theorem cover1088 : Coverage 1088 1120 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1088 one1089) (Coverage.join one1090 one1091)) (Coverage.join (Coverage.join one1092 one1093) (Coverage.join one1094 one1095))) (Coverage.join (Coverage.join (Coverage.join one1096 one1097) (Coverage.join one1098 one1099)) (Coverage.join (Coverage.join one1100 one1101) (Coverage.join one1102 one1103)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1104 one1105) (Coverage.join one1106 one1107)) (Coverage.join (Coverage.join one1108 one1109) (Coverage.join one1110 one1111))) (Coverage.join (Coverage.join (Coverage.join one1112 one1113) (Coverage.join one1114 one1115)) (Coverage.join (Coverage.join one1116 one1117) (Coverage.join one1118 one1119)))))
end NF180PA.Symbolic
