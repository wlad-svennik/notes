import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1408_0 : checkWitness 1408 false false 8908 = true := by decide +kernel
private theorem w1408_2 : checkWitness 1408 true false 8899 = true := by decide +kernel
private theorem cases1408 : checkFour 1408 (8908,0,8899,0) = true := by
  simp only [checkFour, w1408_0, w1408_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1408 : Coverage 1408 1409 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases1408)
private theorem w1409_0 : checkWitness 1409 false false 84 = true := by decide +kernel
private theorem w1409_2 : checkWitness 1409 true false 84 = true := by decide +kernel
private theorem cases1409 : checkFour 1409 (84,0,84,0) = true := by
  simp only [checkFour, w1409_0, w1409_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1409 : Coverage 1409 1410 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1409)
private theorem w1410_0 : checkWitness 1410 false false 486 = true := by decide +kernel
private theorem w1410_1 : checkWitness 1410 false true 4582 = true := by decide +kernel
private theorem w1410_2 : checkWitness 1410 true false 486 = true := by decide +kernel
private theorem w1410_3 : checkWitness 1410 true true 4582 = true := by decide +kernel
private theorem cases1410 : checkFour 1410 (486,4582,486,4582) = true := by
  simp only [checkFour, w1410_0, w1410_1, w1410_2, w1410_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1410 : Coverage 1410 1411 := checkList_sound (ws:=[(486,4582,486,4582)]) (by simpa only [checkList, Bool.and_true] using cases1410)
private theorem w1411_0 : checkWitness 1411 false false 8860 = true := by decide +kernel
private theorem w1411_2 : checkWitness 1411 true false 8856 = true := by decide +kernel
private theorem cases1411 : checkFour 1411 (8860,0,8856,0) = true := by
  simp only [checkFour, w1411_0, w1411_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1411 : Coverage 1411 1412 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases1411)
private theorem w1412_0 : checkWitness 1412 false false 88 = true := by decide +kernel
private theorem w1412_2 : checkWitness 1412 true false 88 = true := by decide +kernel
private theorem cases1412 : checkFour 1412 (88,0,88,0) = true := by
  simp only [checkFour, w1412_0, w1412_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1412 : Coverage 1412 1413 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1412)
private theorem w1413_0 : checkWitness 1413 false false 528 = true := by decide +kernel
private theorem w1413_1 : checkWitness 1413 false true 4624 = true := by decide +kernel
private theorem w1413_2 : checkWitness 1413 true false 528 = true := by decide +kernel
private theorem w1413_3 : checkWitness 1413 true true 4624 = true := by decide +kernel
private theorem cases1413 : checkFour 1413 (528,4624,528,4624) = true := by
  simp only [checkFour, w1413_0, w1413_1, w1413_2, w1413_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1413 : Coverage 1413 1414 := checkList_sound (ws:=[(528,4624,528,4624)]) (by simpa only [checkList, Bool.and_true] using cases1413)
private theorem w1414_0 : checkWitness 1414 false false 8879 = true := by decide +kernel
private theorem w1414_2 : checkWitness 1414 true false 8875 = true := by decide +kernel
private theorem cases1414 : checkFour 1414 (8879,0,8875,0) = true := by
  simp only [checkFour, w1414_0, w1414_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1414 : Coverage 1414 1415 := checkList_sound (ws:=[(8879,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases1414)
private theorem w1415_0 : checkWitness 1415 false false 8910 = true := by decide +kernel
private theorem w1415_2 : checkWitness 1415 true false 8901 = true := by decide +kernel
private theorem cases1415 : checkFour 1415 (8910,0,8901,0) = true := by
  simp only [checkFour, w1415_0, w1415_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1415 : Coverage 1415 1416 := checkList_sound (ws:=[(8910,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases1415)
private theorem w1416_0 : checkWitness 1416 false false 112 = true := by decide +kernel
private theorem w1416_2 : checkWitness 1416 true false 112 = true := by decide +kernel
private theorem cases1416 : checkFour 1416 (112,0,112,0) = true := by
  simp only [checkFour, w1416_0, w1416_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1416 : Coverage 1416 1417 := checkList_sound (ws:=[(112,0,112,0)]) (by simpa only [checkList, Bool.and_true] using cases1416)
private theorem w1417_0 : checkWitness 1417 false false 624 = true := by decide +kernel
private theorem w1417_1 : checkWitness 1417 false true 4716 = true := by decide +kernel
private theorem w1417_2 : checkWitness 1417 true false 615 = true := by decide +kernel
private theorem w1417_3 : checkWitness 1417 true true 4707 = true := by decide +kernel
private theorem cases1417 : checkFour 1417 (624,4716,615,4707) = true := by
  simp only [checkFour, w1417_0, w1417_1, w1417_2, w1417_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1417 : Coverage 1417 1418 := checkList_sound (ws:=[(624,4716,615,4707)]) (by simpa only [checkList, Bool.and_true] using cases1417)
private theorem w1418_0 : checkWitness 1418 false false 8875 = true := by decide +kernel
private theorem w1418_2 : checkWitness 1418 true false 8871 = true := by decide +kernel
private theorem cases1418 : checkFour 1418 (8875,0,8871,0) = true := by
  simp only [checkFour, w1418_0, w1418_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1418 : Coverage 1418 1419 := checkList_sound (ws:=[(8875,0,8871,0)]) (by simpa only [checkList, Bool.and_true] using cases1418)
private theorem w1419_0 : checkWitness 1419 false false 618 = true := by decide +kernel
private theorem w1419_1 : checkWitness 1419 false true 4710 = true := by decide +kernel
private theorem w1419_2 : checkWitness 1419 true false 609 = true := by decide +kernel
private theorem w1419_3 : checkWitness 1419 true true 4701 = true := by decide +kernel
private theorem cases1419 : checkFour 1419 (618,4710,609,4701) = true := by
  simp only [checkFour, w1419_0, w1419_1, w1419_2, w1419_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1419 : Coverage 1419 1420 := checkList_sound (ws:=[(618,4710,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases1419)
private theorem w1420_0 : checkWitness 1420 false false 8846 = true := by decide +kernel
private theorem w1420_2 : checkWitness 1420 true false 8842 = true := by decide +kernel
private theorem cases1420 : checkFour 1420 (8846,0,8842,0) = true := by
  simp only [checkFour, w1420_0, w1420_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1420 : Coverage 1420 1421 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1420)
private theorem w1421_0 : checkWitness 1421 false false 100 = true := by decide +kernel
private theorem w1421_2 : checkWitness 1421 true false 100 = true := by decide +kernel
private theorem cases1421 : checkFour 1421 (100,0,100,0) = true := by
  simp only [checkFour, w1421_0, w1421_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1421 : Coverage 1421 1422 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1421)
private theorem w1422_0 : checkWitness 1422 false false 92 = true := by decide +kernel
private theorem w1422_2 : checkWitness 1422 true false 92 = true := by decide +kernel
private theorem cases1422 : checkFour 1422 (92,0,92,0) = true := by
  simp only [checkFour, w1422_0, w1422_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1422 : Coverage 1422 1423 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1422)
private theorem w1423_0 : checkWitness 1423 false false 571 = true := by decide +kernel
private theorem w1423_1 : checkWitness 1423 false true 4655 = true := by decide +kernel
private theorem w1423_2 : checkWitness 1423 true false 571 = true := by decide +kernel
private theorem w1423_3 : checkWitness 1423 true true 4655 = true := by decide +kernel
private theorem cases1423 : checkFour 1423 (571,4655,571,4655) = true := by
  simp only [checkFour, w1423_0, w1423_1, w1423_2, w1423_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1423 : Coverage 1423 1424 := checkList_sound (ws:=[(571,4655,571,4655)]) (by simpa only [checkList, Bool.and_true] using cases1423)
private theorem w1424_0 : checkWitness 1424 false false 8838 = true := by decide +kernel
private theorem w1424_2 : checkWitness 1424 true false 8834 = true := by decide +kernel
private theorem cases1424 : checkFour 1424 (8838,0,8834,0) = true := by
  simp only [checkFour, w1424_0, w1424_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1424 : Coverage 1424 1425 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1424)
private theorem w1425_0 : checkWitness 1425 false false 92 = true := by decide +kernel
private theorem w1425_2 : checkWitness 1425 true false 92 = true := by decide +kernel
private theorem cases1425 : checkFour 1425 (92,0,92,0) = true := by
  simp only [checkFour, w1425_0, w1425_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1425 : Coverage 1425 1426 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1425)
private theorem w1426_0 : checkWitness 1426 false false 568 = true := by decide +kernel
private theorem w1426_1 : checkWitness 1426 false true 4664 = true := by decide +kernel
private theorem w1426_2 : checkWitness 1426 true false 568 = true := by decide +kernel
private theorem w1426_3 : checkWitness 1426 true true 4664 = true := by decide +kernel
private theorem cases1426 : checkFour 1426 (568,4664,568,4664) = true := by
  simp only [checkFour, w1426_0, w1426_1, w1426_2, w1426_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1426 : Coverage 1426 1427 := checkList_sound (ws:=[(568,4664,568,4664)]) (by simpa only [checkList, Bool.and_true] using cases1426)
private theorem w1427_0 : checkWitness 1427 false false 8908 = true := by decide +kernel
private theorem w1427_2 : checkWitness 1427 true false 8899 = true := by decide +kernel
private theorem cases1427 : checkFour 1427 (8908,0,8899,0) = true := by
  simp only [checkFour, w1427_0, w1427_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1427 : Coverage 1427 1428 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases1427)
private theorem w1428_0 : checkWitness 1428 false false 8854 = true := by decide +kernel
private theorem w1428_2 : checkWitness 1428 true false 8850 = true := by decide +kernel
private theorem cases1428 : checkFour 1428 (8854,0,8850,0) = true := by
  simp only [checkFour, w1428_0, w1428_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1428 : Coverage 1428 1429 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases1428)
private theorem w1429_0 : checkWitness 1429 false false 100 = true := by decide +kernel
private theorem w1429_2 : checkWitness 1429 true false 100 = true := by decide +kernel
private theorem cases1429 : checkFour 1429 (100,0,100,0) = true := by
  simp only [checkFour, w1429_0, w1429_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1429 : Coverage 1429 1430 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1429)
private theorem w1430_0 : checkWitness 1430 false false 634 = true := by decide +kernel
private theorem w1430_1 : checkWitness 1430 false true 4722 = true := by decide +kernel
private theorem w1430_2 : checkWitness 1430 true false 625 = true := by decide +kernel
private theorem w1430_3 : checkWitness 1430 true true 4713 = true := by decide +kernel
private theorem cases1430 : checkFour 1430 (634,4722,625,4713) = true := by
  simp only [checkFour, w1430_0, w1430_1, w1430_2, w1430_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1430 : Coverage 1430 1431 := checkList_sound (ws:=[(634,4722,625,4713)]) (by simpa only [checkList, Bool.and_true] using cases1430)
private theorem w1431_0 : checkWitness 1431 false false 8892 = true := by decide +kernel
private theorem w1431_2 : checkWitness 1431 true false 8888 = true := by decide +kernel
private theorem cases1431 : checkFour 1431 (8892,0,8888,0) = true := by
  simp only [checkFour, w1431_0, w1431_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1431 : Coverage 1431 1432 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases1431)
private theorem w1432_0 : checkWitness 1432 false false 90 = true := by decide +kernel
private theorem w1432_2 : checkWitness 1432 true false 90 = true := by decide +kernel
private theorem cases1432 : checkFour 1432 (90,0,90,0) = true := by
  simp only [checkFour, w1432_0, w1432_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1432 : Coverage 1432 1433 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1432)
private theorem w1433_0 : checkWitness 1433 false false 474 = true := by decide +kernel
private theorem w1433_1 : checkWitness 1433 false true 4570 = true := by decide +kernel
private theorem w1433_2 : checkWitness 1433 true false 474 = true := by decide +kernel
private theorem w1433_3 : checkWitness 1433 true true 4570 = true := by decide +kernel
private theorem cases1433 : checkFour 1433 (474,4570,474,4570) = true := by
  simp only [checkFour, w1433_0, w1433_1, w1433_2, w1433_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1433 : Coverage 1433 1434 := checkList_sound (ws:=[(474,4570,474,4570)]) (by simpa only [checkList, Bool.and_true] using cases1433)
private theorem w1434_0 : checkWitness 1434 false false 8877 = true := by decide +kernel
private theorem w1434_2 : checkWitness 1434 true false 8873 = true := by decide +kernel
private theorem cases1434 : checkFour 1434 (8877,0,8873,0) = true := by
  simp only [checkFour, w1434_0, w1434_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1434 : Coverage 1434 1435 := checkList_sound (ws:=[(8877,0,8873,0)]) (by simpa only [checkList, Bool.and_true] using cases1434)
private theorem w1435_0 : checkWitness 1435 false false 606 = true := by decide +kernel
private theorem w1435_1 : checkWitness 1435 false true 4702 = true := by decide +kernel
private theorem w1435_2 : checkWitness 1435 true false 597 = true := by decide +kernel
private theorem w1435_3 : checkWitness 1435 true true 4693 = true := by decide +kernel
private theorem cases1435 : checkFour 1435 (606,4702,597,4693) = true := by
  simp only [checkFour, w1435_0, w1435_1, w1435_2, w1435_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1435 : Coverage 1435 1436 := checkList_sound (ws:=[(606,4702,597,4693)]) (by simpa only [checkList, Bool.and_true] using cases1435)
private theorem w1436_0 : checkWitness 1436 false false 170 = true := by decide +kernel
private theorem w1436_2 : checkWitness 1436 true false 170 = true := by decide +kernel
private theorem cases1436 : checkFour 1436 (170,0,170,0) = true := by
  simp only [checkFour, w1436_0, w1436_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1436 : Coverage 1436 1437 := checkList_sound (ws:=[(170,0,170,0)]) (by simpa only [checkList, Bool.and_true] using cases1436)
private theorem w1437_0 : checkWitness 1437 false false 555 = true := by decide +kernel
private theorem w1437_1 : checkWitness 1437 false true 4643 = true := by decide +kernel
private theorem w1437_2 : checkWitness 1437 true false 555 = true := by decide +kernel
private theorem w1437_3 : checkWitness 1437 true true 4643 = true := by decide +kernel
private theorem cases1437 : checkFour 1437 (555,4643,555,4643) = true := by
  simp only [checkFour, w1437_0, w1437_1, w1437_2, w1437_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1437 : Coverage 1437 1438 := checkList_sound (ws:=[(555,4643,555,4643)]) (by simpa only [checkList, Bool.and_true] using cases1437)
private theorem w1438_0 : checkWitness 1438 false false 8888 = true := by decide +kernel
private theorem w1438_2 : checkWitness 1438 true false 8879 = true := by decide +kernel
private theorem cases1438 : checkFour 1438 (8888,0,8879,0) = true := by
  simp only [checkFour, w1438_0, w1438_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1438 : Coverage 1438 1439 := checkList_sound (ws:=[(8888,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1438)
private theorem w1439_0 : checkWitness 1439 false false 94 = true := by decide +kernel
private theorem w1439_2 : checkWitness 1439 true false 94 = true := by decide +kernel
private theorem cases1439 : checkFour 1439 (94,0,94,0) = true := by
  simp only [checkFour, w1439_0, w1439_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1439 : Coverage 1439 1440 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1439)
theorem cover1408 : Coverage 1408 1440 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1408 one1409) (Coverage.join one1410 one1411)) (Coverage.join (Coverage.join one1412 one1413) (Coverage.join one1414 one1415))) (Coverage.join (Coverage.join (Coverage.join one1416 one1417) (Coverage.join one1418 one1419)) (Coverage.join (Coverage.join one1420 one1421) (Coverage.join one1422 one1423)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1424 one1425) (Coverage.join one1426 one1427)) (Coverage.join (Coverage.join one1428 one1429) (Coverage.join one1430 one1431))) (Coverage.join (Coverage.join (Coverage.join one1432 one1433) (Coverage.join one1434 one1435)) (Coverage.join (Coverage.join one1436 one1437) (Coverage.join one1438 one1439)))))
end NF180PA.Symbolic
