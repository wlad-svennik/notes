import NF180PATapeFrame
import NF180PARegisters
import NF180PATapeBoot
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.PhysicalModel PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.RegisterSource (readReg registers address cold)
namespace NF180PA.Symbolic
open Gate (machine start)
open Execute (bit)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000
set_option maxRecDepth 16000

private noncomputable def packedCount (flag : Bool) (k : Nat) (r : V) :=
  count flag (fun i => readReg i r) k

private instance countDef (c : Bool) (k : Nat) :
    Language.DefinableFunction₁ ℒₒᵣ (packedCount (V:=V) c k) := by
  unfold packedCount count
  split <;> definability

private noncomputable def packedFile (ks : List Nat) (flag : Bool) (r t : V) :=
  file ks flag (fun i => readReg i r) t

private instance fileDef (ks : List Nat) (c : Bool) :
    Language.DefinableFunction₂ ℒₒᵣ (packedFile (V:=V) ks c) := by
  induction ks with
  | nil => change Language.DefinableFunction₂ ℒₒᵣ (fun _ t : V => t); definability
  | cons k ks ih =>
    change Language.DefinableFunction₂ ℒₒᵣ (fun r t : V => bit false (rep true
      (packedCount c k r) (packedFile ks c r t)))
    definability

noncomputable def packedFrame (p : Nat) (c : Bool) (r g k : V) : V :=
  canonical p c (fun i => readReg i r) g k

private theorem frameDefAux (w : List Bool) (padding : V) (flag : Bool) (ks : List Nat) :
    Language.DefinableFunction₃ ℒₒᵣ (fun r g k : V => pack 12 1 (rayLit w (rep false (padding+g+10)
      (bit true (packedFile ks flag r (pairs false (24+k) 0)))))) := by
  definability

instance packedFrameDef (p : Nat) (c : Bool) : Language.DefinableFunction₃ ℒₒᵣ (packedFrame (V:=V) p c) :=
  frameDefAux _ _ _ _

def legal (p : Nat) (c : Bool) : Prop := c=false
def LiveTag (p : Nat) (c : Bool) (s t : V) : Prop :=
  legal p c ∧ address s=(p:V) ∧ cold s=(c.toNat:V) ∧
  (c=true → readReg 0 (registers s)=0) ∧ ∃ g k : V, t=packedFrame p c (registers s) g k

private theorem liveDefAux (n f : V) (legal : Prop) (flag : Bool)
    (fr : V→V→V→V) [Language.DefinableFunction₃ ℒₒᵣ fr] :
    Language.DefinableRel ℒₒᵣ (fun s t : V => legal ∧ address s=n ∧ cold s=f ∧
      (flag=true → readReg 0 (registers s)=0) ∧ ∃ g k : V, t=fr (registers s) g k) := by
  classical
  by_cases h : legal
  · cases flag <;> simp only [h,true_and,Bool.false_eq_true,false_implies,true_implies]
    all_goals
      repeat' apply Language.Definable.and (by definability)
      apply Language.Definable.exs; apply Language.Definable.exs
      apply Language.DefinableRel.comp (P:=(·=·)) (by definability)
      apply Language.DefinableFunction₃.comp (F:=fr) <;> definability
  · simp only [h,false_and]; definability

instance liveTagDef (p : Nat) (flag : Bool) : Language.DefinableRel ℒₒᵣ (LiveTag (V:=V) p flag) :=
  liveDefAux _ _ _ _ _

def AnyFrame : List Nat → V → V → Prop
  | [],_,_ => False
  | p::ps,s,t => LiveTag p false s t ∨ LiveTag p true s t ∨ AnyFrame ps s t

instance anyFrameDef (ps : List Nat) : Language.DefinableRel ℒₒᵣ (AnyFrame (V:=V) ps) := by
  induction ps with
  | nil => change Language.DefinableRel ℒₒᵣ (fun (_ _ : V) => False); definability
  | cons p ps ih => simp only [AnyFrame]; definability

theorem anyFrame_iff (ps : List Nat) (s t : V) :
    AnyFrame ps s t ↔ ∃ p ∈ ps, ∃ flag, LiveTag p flag s t := by
  induction ps with
  | nil => simp [AnyFrame]
  | cons p ps ih => simp [AnyFrame,ih,Bool.exists_bool,or_assoc]

def Boundary (s t : V) : Prop := (address s=4095 ∧ state t=179) ∨ AnyFrame (List.range 2970) s t

private theorem boundaryGeneric (ps : List Nat) : Language.DefinableRel ℒₒᵣ
    (fun s t : V => (address s=4095 ∧ state t=179) ∨ AnyFrame ps s t) := by definability

instance boundaryDef : Language.DefinableRel ℒₒᵣ (Boundary (V:=V)) := boundaryGeneric _

theorem boundary_stop {s t : V} (h : Boundary s t) (endAt : address s=4095) : state t = 179 := by
  rcases h with h | live
  · exact h.2
  · obtain ⟨p,hp,f,_,atp,_⟩ := (anyFrame_iff _ _ _).mp live
    have lt : p<2970 := List.mem_range.mp hp
    have co : (p:V)=(4095:Nat) := atp.symm.trans endAt
    have eq : p=4095 := by exact_mod_cast co
    omega

def RowSim (p : Nat) : Prop := ∀ (flag : Bool) (s t : V), LiveTag p flag s t →
  ∃ k : V, Boundary (Registers.next s) (iterate (rawStep machine) k t)

theorem allRows_simulate (rows : ∀ p : Fin 2970, RowSim (V:=V) p.val) :
    ∀ s t : V, Boundary s t → ∃ k : V, Boundary (Registers.next s) (iterate (rawStep machine) k t) := by
  rintro s t (h|live)
  · exact ⟨0,Or.inl ⟨Registers.next_terminal s h.1,by simpa using h.2⟩⟩
  · obtain ⟨p,hp,f,atp⟩ := (anyFrame_iff _ _ _).mp live
    exact rows ⟨p,List.mem_range.mp hp⟩ f s t atp

theorem simulate (boot : Boundary (Registers.margin V) (rawRun machine start (230892:V)))
    (rows : ∀ p : Fin 2970, RowSim (V:=V) p.val) :
    ∀ j : V, ∃ t : V, Boundary (Registers.run j) (rawRun machine start t) := by
  apply modelInduct
  · definability
  · exact ⟨230892,by simpa using boot⟩
  · rintro j ⟨t,h⟩
    obtain ⟨k,hits⟩ := allRows_simulate rows _ _ h
    exact ⟨t+k,by simpa only [Registers.run_succ,rawRun,iterate_add] using hits⟩

theorem tape_of_source (boot : Boundary (Registers.margin V) (rawRun machine start (230892:V)))
    (rows : ∀ p : Fin 2970, RowSim (V:=V) p.val)
    (source : ∃ j : V, address (Registers.run j)=4095) : V ⊧/![] H180 := by
  obtain ⟨j,endAt⟩ := source
  obtain ⟨t,h⟩ := simulate boot rows j
  exact H180_eval.mpr ⟨t,boundary_stop h endAt⟩

#print axioms tape_of_source
end NF180PA.Symbolic
