import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2528_0 : checkWitness 2528 false false 649 = true := by decide +kernel
private theorem w2528_1 : checkWitness 2528 false true 4741 = true := by decide +kernel
private theorem w2528_2 : checkWitness 2528 true false 640 = true := by decide +kernel
private theorem w2528_3 : checkWitness 2528 true true 4732 = true := by decide +kernel
private theorem cases2528 : checkFour 2528 (649,4741,640,4732) = true := by
  simp only [checkFour, w2528_0, w2528_1, w2528_2, w2528_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2528 : Coverage 2528 2529 := checkList_sound (ws:=[(649,4741,640,4732)]) (by simpa only [checkList, Bool.and_true] using cases2528)
private theorem w2529_0 : checkWitness 2529 false false 8946 = true := by decide +kernel
private theorem w2529_2 : checkWitness 2529 true false 8937 = true := by decide +kernel
private theorem cases2529 : checkFour 2529 (8946,0,8937,0) = true := by
  simp only [checkFour, w2529_0, w2529_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2529 : Coverage 2529 2530 := checkList_sound (ws:=[(8946,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases2529)
private theorem w2530_0 : checkWitness 2530 false false 8892 = true := by decide +kernel
private theorem w2530_2 : checkWitness 2530 true false 8888 = true := by decide +kernel
private theorem cases2530 : checkFour 2530 (8892,0,8888,0) = true := by
  simp only [checkFour, w2530_0, w2530_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2530 : Coverage 2530 2531 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2530)
private theorem w2531_0 : checkWitness 2531 false false 64 = true := by decide +kernel
private theorem w2531_2 : checkWitness 2531 true false 64 = true := by decide +kernel
private theorem cases2531 : checkFour 2531 (64,0,64,0) = true := by
  simp only [checkFour, w2531_0, w2531_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2531 : Coverage 2531 2532 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2531)
private theorem w2532_0 : checkWitness 2532 false false 672 = true := by decide +kernel
private theorem w2532_1 : checkWitness 2532 false true 4764 = true := by decide +kernel
private theorem w2532_2 : checkWitness 2532 true false 663 = true := by decide +kernel
private theorem w2532_3 : checkWitness 2532 true true 4755 = true := by decide +kernel
private theorem cases2532 : checkFour 2532 (672,4764,663,4755) = true := by
  simp only [checkFour, w2532_0, w2532_1, w2532_2, w2532_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2532 : Coverage 2532 2533 := checkList_sound (ws:=[(672,4764,663,4755)]) (by simpa only [checkList, Bool.and_true] using cases2532)
private theorem w2533_0 : checkWitness 2533 false false 8953 = true := by decide +kernel
private theorem w2533_2 : checkWitness 2533 true false 8944 = true := by decide +kernel
private theorem cases2533 : checkFour 2533 (8953,0,8944,0) = true := by
  simp only [checkFour, w2533_0, w2533_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2533 : Coverage 2533 2534 := checkList_sound (ws:=[(8953,0,8944,0)]) (by simpa only [checkList, Bool.and_true] using cases2533)
private theorem w2534_0 : checkWitness 2534 false false 48 = true := by decide +kernel
private theorem w2534_2 : checkWitness 2534 true false 48 = true := by decide +kernel
private theorem cases2534 : checkFour 2534 (48,0,48,0) = true := by
  simp only [checkFour, w2534_0, w2534_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2534 : Coverage 2534 2535 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2534)
private theorem w2535_0 : checkWitness 2535 false false 530 = true := by decide +kernel
private theorem w2535_1 : checkWitness 2535 false true 4626 = true := by decide +kernel
private theorem w2535_2 : checkWitness 2535 true false 530 = true := by decide +kernel
private theorem w2535_3 : checkWitness 2535 true true 4626 = true := by decide +kernel
private theorem cases2535 : checkFour 2535 (530,4626,530,4626) = true := by
  simp only [checkFour, w2535_0, w2535_1, w2535_2, w2535_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2535 : Coverage 2535 2536 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases2535)
private theorem w2536_0 : checkWitness 2536 false false 8933 = true := by decide +kernel
private theorem w2536_2 : checkWitness 2536 true false 8929 = true := by decide +kernel
private theorem cases2536 : checkFour 2536 (8933,0,8929,0) = true := by
  simp only [checkFour, w2536_0, w2536_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2536 : Coverage 2536 2537 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases2536)
private theorem w2537_0 : checkWitness 2537 false false 662 = true := by decide +kernel
private theorem w2537_1 : checkWitness 2537 false true 4758 = true := by decide +kernel
private theorem w2537_2 : checkWitness 2537 true false 653 = true := by decide +kernel
private theorem w2537_3 : checkWitness 2537 true true 4749 = true := by decide +kernel
private theorem cases2537 : checkFour 2537 (662,4758,653,4749) = true := by
  simp only [checkFour, w2537_0, w2537_1, w2537_2, w2537_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2537 : Coverage 2537 2538 := checkList_sound (ws:=[(662,4758,653,4749)]) (by simpa only [checkList, Bool.and_true] using cases2537)
private theorem w2538_0 : checkWitness 2538 false false 198 = true := by decide +kernel
private theorem w2538_2 : checkWitness 2538 true false 198 = true := by decide +kernel
private theorem cases2538 : checkFour 2538 (198,0,198,0) = true := by
  simp only [checkFour, w2538_0, w2538_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2538 : Coverage 2538 2539 := checkList_sound (ws:=[(198,0,198,0)]) (by simpa only [checkList, Bool.and_true] using cases2538)
private theorem w2539_0 : checkWitness 2539 false false 611 = true := by decide +kernel
private theorem w2539_1 : checkWitness 2539 false true 4699 = true := by decide +kernel
private theorem w2539_2 : checkWitness 2539 true false 611 = true := by decide +kernel
private theorem w2539_3 : checkWitness 2539 true true 4699 = true := by decide +kernel
private theorem cases2539 : checkFour 2539 (611,4699,611,4699) = true := by
  simp only [checkFour, w2539_0, w2539_1, w2539_2, w2539_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2539 : Coverage 2539 2540 := checkList_sound (ws:=[(611,4699,611,4699)]) (by simpa only [checkList, Bool.and_true] using cases2539)
private theorem w2540_0 : checkWitness 2540 false false 8944 = true := by decide +kernel
private theorem w2540_2 : checkWitness 2540 true false 8935 = true := by decide +kernel
private theorem cases2540 : checkFour 2540 (8944,0,8935,0) = true := by
  simp only [checkFour, w2540_0, w2540_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2540 : Coverage 2540 2541 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2540)
private theorem w2541_0 : checkWitness 2541 false false 66 = true := by decide +kernel
private theorem w2541_2 : checkWitness 2541 true false 66 = true := by decide +kernel
private theorem cases2541 : checkFour 2541 (66,0,66,0) = true := by
  simp only [checkFour, w2541_0, w2541_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2541 : Coverage 2541 2542 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2541)
private theorem w2542_0 : checkWitness 2542 false false 58 = true := by decide +kernel
private theorem w2542_2 : checkWitness 2542 true false 58 = true := by decide +kernel
private theorem cases2542 : checkFour 2542 (58,0,58,0) = true := by
  simp only [checkFour, w2542_0, w2542_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2542 : Coverage 2542 2543 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2542)
private theorem w2543_0 : checkWitness 2543 false false 611 = true := by decide +kernel
private theorem w2543_1 : checkWitness 2543 false true 4703 = true := by decide +kernel
private theorem w2543_2 : checkWitness 2543 true false 611 = true := by decide +kernel
private theorem w2543_3 : checkWitness 2543 true true 4703 = true := by decide +kernel
private theorem cases2543 : checkFour 2543 (611,4703,611,4703) = true := by
  simp only [checkFour, w2543_0, w2543_1, w2543_2, w2543_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2543 : Coverage 2543 2544 := checkList_sound (ws:=[(611,4703,611,4703)]) (by simpa only [checkList, Bool.and_true] using cases2543)
private theorem w2544_0 : checkWitness 2544 false false 8886 = true := by decide +kernel
private theorem w2544_2 : checkWitness 2544 true false 8882 = true := by decide +kernel
private theorem cases2544 : checkFour 2544 (8886,0,8882,0) = true := by
  simp only [checkFour, w2544_0, w2544_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2544 : Coverage 2544 2545 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases2544)
private theorem w2545_0 : checkWitness 2545 false false 58 = true := by decide +kernel
private theorem w2545_2 : checkWitness 2545 true false 58 = true := by decide +kernel
private theorem cases2545 : checkFour 2545 (58,0,58,0) = true := by
  simp only [checkFour, w2545_0, w2545_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2545 : Coverage 2545 2546 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2545)
private theorem w2546_0 : checkWitness 2546 false false 570 = true := by decide +kernel
private theorem w2546_1 : checkWitness 2546 false true 4666 = true := by decide +kernel
private theorem w2546_2 : checkWitness 2546 true false 570 = true := by decide +kernel
private theorem w2546_3 : checkWitness 2546 true true 4666 = true := by decide +kernel
private theorem cases2546 : checkFour 2546 (570,4666,570,4666) = true := by
  simp only [checkFour, w2546_0, w2546_1, w2546_2, w2546_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2546 : Coverage 2546 2547 := checkList_sound (ws:=[(570,4666,570,4666)]) (by simpa only [checkList, Bool.and_true] using cases2546)
private theorem w2547_0 : checkWitness 2547 false false 8921 = true := by decide +kernel
private theorem w2547_2 : checkWitness 2547 true false 8917 = true := by decide +kernel
private theorem cases2547 : checkFour 2547 (8921,0,8917,0) = true := by
  simp only [checkFour, w2547_0, w2547_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2547 : Coverage 2547 2548 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases2547)
private theorem w2548_0 : checkWitness 2548 false false 8952 = true := by decide +kernel
private theorem w2548_2 : checkWitness 2548 true false 8943 = true := by decide +kernel
private theorem cases2548 : checkFour 2548 (8952,0,8943,0) = true := by
  simp only [checkFour, w2548_0, w2548_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2548 : Coverage 2548 2549 := checkList_sound (ws:=[(8952,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases2548)
private theorem w2549_0 : checkWitness 2549 false false 76 = true := by decide +kernel
private theorem w2549_2 : checkWitness 2549 true false 76 = true := by decide +kernel
private theorem cases2549 : checkFour 2549 (76,0,76,0) = true := by
  simp only [checkFour, w2549_0, w2549_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2549 : Coverage 2549 2550 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2549)
private theorem w2550_0 : checkWitness 2550 false false 666 = true := by decide +kernel
private theorem w2550_1 : checkWitness 2550 false true 4758 = true := by decide +kernel
private theorem w2550_2 : checkWitness 2550 true false 657 = true := by decide +kernel
private theorem w2550_3 : checkWitness 2550 true true 4749 = true := by decide +kernel
private theorem cases2550 : checkFour 2550 (666,4758,657,4749) = true := by
  simp only [checkFour, w2550_0, w2550_1, w2550_2, w2550_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2550 : Coverage 2550 2551 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases2550)
private theorem w2551_0 : checkWitness 2551 false false 8917 = true := by decide +kernel
private theorem w2551_2 : checkWitness 2551 true false 8913 = true := by decide +kernel
private theorem cases2551 : checkFour 2551 (8917,0,8913,0) = true := by
  simp only [checkFour, w2551_0, w2551_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2551 : Coverage 2551 2552 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2551)
private theorem w2552_0 : checkWitness 2552 false false 660 = true := by decide +kernel
private theorem w2552_1 : checkWitness 2552 false true 4752 = true := by decide +kernel
private theorem w2552_2 : checkWitness 2552 true false 651 = true := by decide +kernel
private theorem w2552_3 : checkWitness 2552 true true 4743 = true := by decide +kernel
private theorem cases2552 : checkFour 2552 (660,4752,651,4743) = true := by
  simp only [checkFour, w2552_0, w2552_1, w2552_2, w2552_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2552 : Coverage 2552 2553 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases2552)
private theorem w2553_0 : checkWitness 2553 false false 8888 = true := by decide +kernel
private theorem w2553_2 : checkWitness 2553 true false 8884 = true := by decide +kernel
private theorem cases2553 : checkFour 2553 (8888,0,8884,0) = true := by
  simp only [checkFour, w2553_0, w2553_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2553 : Coverage 2553 2554 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases2553)
private theorem w2554_0 : checkWitness 2554 false false 64 = true := by decide +kernel
private theorem w2554_2 : checkWitness 2554 true false 64 = true := by decide +kernel
private theorem cases2554 : checkFour 2554 (64,0,64,0) = true := by
  simp only [checkFour, w2554_0, w2554_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2554 : Coverage 2554 2555 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2554)
private theorem w2555_0 : checkWitness 2555 false false 56 = true := by decide +kernel
private theorem w2555_2 : checkWitness 2555 true false 56 = true := by decide +kernel
private theorem cases2555 : checkFour 2555 (56,0,56,0) = true := by
  simp only [checkFour, w2555_0, w2555_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2555 : Coverage 2555 2556 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2555)
private theorem w2556_0 : checkWitness 2556 false false 621 = true := by decide +kernel
private theorem w2556_1 : checkWitness 2556 false true 4709 = true := by decide +kernel
private theorem w2556_2 : checkWitness 2556 true false 621 = true := by decide +kernel
private theorem w2556_3 : checkWitness 2556 true true 4709 = true := by decide +kernel
private theorem cases2556 : checkFour 2556 (621,4709,621,4709) = true := by
  simp only [checkFour, w2556_0, w2556_1, w2556_2, w2556_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2556 : Coverage 2556 2557 := checkList_sound (ws:=[(621,4709,621,4709)]) (by simpa only [checkList, Bool.and_true] using cases2556)
private theorem w2557_0 : checkWitness 2557 false false 8904 = true := by decide +kernel
private theorem w2557_2 : checkWitness 2557 true false 8900 = true := by decide +kernel
private theorem cases2557 : checkFour 2557 (8904,0,8900,0) = true := by
  simp only [checkFour, w2557_0, w2557_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2557 : Coverage 2557 2558 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2557)
private theorem w2558_0 : checkWitness 2558 false false 8900 = true := by decide +kernel
private theorem w2558_2 : checkWitness 2558 true false 8896 = true := by decide +kernel
private theorem cases2558 : checkFour 2558 (8900,0,8896,0) = true := by
  simp only [checkFour, w2558_0, w2558_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2558 : Coverage 2558 2559 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases2558)
private theorem w2559_0 : checkWitness 2559 false false 70 = true := by decide +kernel
private theorem w2559_2 : checkWitness 2559 true false 70 = true := by decide +kernel
private theorem cases2559 : checkFour 2559 (70,0,70,0) = true := by
  simp only [checkFour, w2559_0, w2559_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2559 : Coverage 2559 2560 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2559)
theorem cover2528 : Coverage 2528 2560 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2528 one2529) (Coverage.join one2530 one2531)) (Coverage.join (Coverage.join one2532 one2533) (Coverage.join one2534 one2535))) (Coverage.join (Coverage.join (Coverage.join one2536 one2537) (Coverage.join one2538 one2539)) (Coverage.join (Coverage.join one2540 one2541) (Coverage.join one2542 one2543)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2544 one2545) (Coverage.join one2546 one2547)) (Coverage.join (Coverage.join one2548 one2549) (Coverage.join one2550 one2551))) (Coverage.join (Coverage.join (Coverage.join one2552 one2553) (Coverage.join one2554 one2555)) (Coverage.join (Coverage.join one2556 one2557) (Coverage.join one2558 one2559)))))
end NF180PA.Symbolic
