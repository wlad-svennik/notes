import NF180PA
import NF179Sentence
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.PhysicalModel

namespace NF179
theorem H179_eval {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    (V ⊧/![] H179) ↔ ∃ t : V, state (rawRun machine start t) = (179 : V) :=
  NF180PA.H180_eval

theorem H179_standard : (Nat ⊧/![] H179) ↔ Halts machine start :=
  NF180PA.H180_standard
end NF179
#print axioms NF179.H179_eval
#print axioms NF179.H179_standard
