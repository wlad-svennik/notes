import NF180PATapeCompiler
import NF180PAClockCodes

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.PhysicalModel PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.RegisterSource (readReg registers address cold config perform)

namespace NF180PA.Symbolic
open Gate (machine start)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 4000000
set_option maxRecDepth 18000

private theorem word_fold (w : List Bool) (a : V) :
    rayLit w a = w.foldr Execute.bit a := by
  induction w with
  | nil => rfl
  | cons b w ih => simp only [rayLit,List.foldr,ih]

private theorem digit_disjoint (a b : V) : Execute.bit false a ≠ Execute.bit true b := by
  intro e
  have bits := congrArg (fun x : V => x % 2) e
  rw [(Execute.halves false a).2,(Execute.halves true b).2] at bits
  simp at bits

private theorem digit_inj (b : Bool) (a c : V) (h : Execute.bit b a = Execute.bit b c) : a=c := by
  have t := congrArg (fun x : V => x / 2) h
  simpa only [(Execute.halves b a).1,(Execute.halves b c).1] using t

private theorem separate_frames (p q : Nat) (c d : Bool) (r s g k g' k' : V)
    (clash : Clock.conflict (Blank180.Data.addressBits p) (Blank180.Data.addressBits q) = true) :
    packedFrame p c r g k ≠ packedFrame q d s g' k' := by
  intro eq
  have ray := congrArg (rightRay : V → V) eq
  simp only [packedFrame,canonical,right_pack,word_fold] at ray
  exact Clock.separated Execute.bit digit_disjoint digit_inj clash _ _ ray

private theorem boundary_halted {s u : V} (b : Boundary s u) (h : state u = 179) :
    address s=4095 := by
  rcases b with terminal | live
  · exact terminal.1
  · obtain ⟨p,_,f,_,_,_,_,g,k,rfl⟩ := (anyFrame_iff _ _ _).mp live
    norm_num [packedFrame,canonical] at h

/-- Two successive source instructions cannot share a live tape checkpoint.
This uses a disagreeing physical address bit for every live source edge. -/
theorem live_boundary_moves {s t : V} (b : Boundary s t) (still : address s ≠ 4095) :
    ¬ Boundary (Registers.next s) t := by
  intro nextB
  rcases b with ended | live
  · exact still ended.1
  obtain ⟨p,hp,f,_,atp,tag,debt,g,k,oldframe⟩ := (anyFrame_iff _ _ _).mp live
  let i : Fin 2970 := ⟨p,List.mem_range.mp hp⟩
  let r := registers s
  let z := positive p r
  have hnext : Registers.next s = perform (Registers.instruction p) (f.toNat:V) r := by
    have eq : config (address s) (cold s) r = s := by
      simp [r,RegisterSource.config,RegisterSource.address,RegisterSource.cold,RegisterSource.registers]
    rw [atp,tag] at eq
    rw [←eq,Registers.next_at i]
  have afterPC : address (Registers.next s) = (outAddress p z : V) := by
    rw [hnext]
    exact (source_fields p f r g k debt).1
  have active : state t ≠ 179 := by
    rw [oldframe]
    norm_num [packedFrame,canonical]
  rcases nextB with stopped | following
  · exact active stopped.2
  obtain ⟨q,hq,d,_,atq,_,_,g',k',newframe⟩ := (anyFrame_iff _ _ _).mp following
  have same : q = outAddress p z := by exact_mod_cast atq.symm.trans afterPC
  cases stop : expectedHalt p z with
  | true =>
    have bogus : q=4095 := by simpa only [outAddress,stop,ite_true] using same
    have limit : q<2970 := List.mem_range.mp hq
    omega
  | false =>
    have target : q=nextPc p z := by simpa [outAddress,stop] using same
    have clash : Clock.conflict (Blank180.Data.addressBits p) (Blank180.Data.addressBits q) = true := by
      rw [target]
      exact Clock.live_conflict i z stop
    exact separate_frames p q f d _ _ g k g' k' clash (oldframe.symm.trans newframe)

private noncomputable abbrev physicalAt (t : V) := rawRun machine start t

private theorem stop_after {j t : V} (hit : state (physicalAt j)=179) (later : j≤t) :
    state (physicalAt t)=179 := by
  obtain ⟨d,rfl⟩ := exists_add_of_le later
  have fixed : rawStep machine (physicalAt j)=physicalAt j := by
    apply pick_none
    intro q _ hq
    have ne : ((179:Nat):V) ≠ (q.val:V) := by exact_mod_cast (Nat.ne_of_lt q.isLt).symm
    exact ne (hit.symm.trans hq)
  rw [physicalAt,rawRun,iterate_add]
  change state (iterate (rawStep machine) d (physicalAt j))=179
  have stay : iterate (rawStep machine) d (physicalAt j)=physicalAt j := by
    clear later
    induction d using modelInduct with
    | defP => definability
    | zero => simp
    | step n ih => rw [iterate_succ,ih,fixed]
  simpa only [stay] using hit

/-- If the source continues at every model clock, its tape checkpoints are cofinal
in that model's physical time. No bound on the duration of a register instruction
is required. -/
theorem cofinal_live_checkpoints
    (boot : Boundary (Registers.margin V) (physicalAt (230892:V)))
    (rows : ∀ p : Fin 2970, RowSim (V:=V) p.val)
    (live : ∀ j : V, address (Registers.run j) ≠ 4095) :
    ∀ j : V, ∃ t : V, j≤t ∧ Boundary (Registers.run j) (physicalAt t) := by
  apply modelInduct
  · definability
  · exact ⟨230892,zero_le,by simpa using boot⟩
  · rintro j ⟨t,jt,b⟩
    obtain ⟨k,hk⟩ := allRows_simulate rows _ _ b
    have nz : (0:V) ≠ k := by
      intro e
      rw [←e,iterate_zero] at hk
      exact live_boundary_moves b (live j) hk
    have pos : (0:V)<k := lt_of_le_of_ne zero_le nz
    refine ⟨t+k,succ_le_iff_lt.mpr (lt_of_le_of_lt jt (lt_add_of_pos_right _ pos)),?_⟩
    simpa only [Registers.run_succ,physicalAt,rawRun,iterate_add] using hk

/-- Reverse compiler correctness for all models of PA, including their arbitrary
nonstandard physical halt times and register clocks. -/
theorem source_of_tape (boot : Boundary (Registers.margin V) (physicalAt (230892:V)))
    (rows : ∀ p : Fin 2970, RowSim (V:=V) p.val)
    (hit : V ⊧/![] H180) : ∃ j : V, address (Registers.run j)=4095 := by
  by_contra no
  have alive (j : V) : address (Registers.run j) ≠ 4095 := fun h => no ⟨j,h⟩
  obtain ⟨j,stopped⟩ := H180_eval.mp hit
  obtain ⟨t,jt,b⟩ := cofinal_live_checkpoints boot rows alive j
  exact alive j (boundary_halted b (stop_after stopped jt))

theorem tape_iff_source_of_coverage (cover : Coverage 0 2970) :
    (V ⊧/![] H180) ↔ ∃ j : V, address (Registers.run j)=4095 := by
  constructor
  · exact source_of_tape boot_boundary (checked_row table_safe cover)
  · exact tape_of_coverage cover

#print axioms cofinal_live_checkpoints
#print axioms source_of_tape
#print axioms tape_iff_source_of_coverage
end NF180PA.Symbolic
