import NF179HeaderCheck
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace NF179.TableAudit
open Blank180.Table NF210.TM

/-- The byte records of the transition file, including its start header and final newline. -/
def literalRecords : List String := "#! start k:74\n" :: raw
def renderedRecords : List String := ("#! start " ++ name start ++ "\n") :: rendered
noncomputable def literalBytes : ByteArray := (String.join literalRecords).toUTF8
noncomputable def renderedBytes : ByteArray := (String.join renderedRecords).toUTF8

theorem literal_records_exact : renderedRecords = literalRecords :=
  (congrArg (fun h => List.cons h rendered) NF179.HeaderCheck.header_exact).trans
    (congrArg (List.cons "#! start k:74\n") Blank180.Table.literal_exact)

theorem complete_file_exact : renderedBytes = literalBytes :=
  congrArg (fun records => (String.join records).toUTF8) literal_records_exact

#print axioms literal_records_exact
#print axioms complete_file_exact
end NF179.TableAudit
