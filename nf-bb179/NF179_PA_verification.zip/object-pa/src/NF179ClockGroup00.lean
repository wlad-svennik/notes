import NF179ClockBase
namespace NF180PA.Clock
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part0 : Covers 0 16 := block_sound (lo:=0) (n:=16) (by decide +kernel)
private theorem part16 : Covers 16 32 := block_sound (lo:=16) (n:=16) (by decide +kernel)
private theorem part32 : Covers 32 48 := block_sound (lo:=32) (n:=16) (by decide +kernel)
private theorem part48 : Covers 48 64 := block_sound (lo:=48) (n:=16) (by decide +kernel)
private theorem part64 : Covers 64 80 := block_sound (lo:=64) (n:=16) (by decide +kernel)
private theorem part80 : Covers 80 96 := block_sound (lo:=80) (n:=16) (by decide +kernel)
private theorem part96 : Covers 96 112 := block_sound (lo:=96) (n:=16) (by decide +kernel)
private theorem part112 : Covers 112 128 := block_sound (lo:=112) (n:=16) (by decide +kernel)
private theorem part128 : Covers 128 144 := block_sound (lo:=128) (n:=16) (by decide +kernel)
private theorem part144 : Covers 144 160 := block_sound (lo:=144) (n:=16) (by decide +kernel)
private theorem part160 : Covers 160 176 := block_sound (lo:=160) (n:=16) (by decide +kernel)
private theorem part176 : Covers 176 192 := block_sound (lo:=176) (n:=16) (by decide +kernel)
private theorem part192 : Covers 192 208 := block_sound (lo:=192) (n:=16) (by decide +kernel)
private theorem part208 : Covers 208 224 := block_sound (lo:=208) (n:=16) (by decide +kernel)
private theorem part224 : Covers 224 240 := block_sound (lo:=224) (n:=16) (by decide +kernel)
private theorem part240 : Covers 240 256 := block_sound (lo:=240) (n:=16) (by decide +kernel)
theorem group0 : Covers 0 256 := (Covers.join (Covers.join (Covers.join (Covers.join part0 part16) (Covers.join part32 part48)) (Covers.join (Covers.join part64 part80) (Covers.join part96 part112))) (Covers.join (Covers.join (Covers.join part128 part144) (Covers.join part160 part176)) (Covers.join (Covers.join part192 part208) (Covers.join part224 part240))))
end NF180PA.Clock
