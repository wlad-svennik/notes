import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w288_0 : checkWitness 288 false false 581 = true := by decide +kernel
private theorem w288_1 : checkWitness 288 false true 4665 = true := by decide +kernel
private theorem w288_2 : checkWitness 288 true false 581 = true := by decide +kernel
private theorem w288_3 : checkWitness 288 true true 4665 = true := by decide +kernel
private theorem cases288 : checkFour 288 (581,4665,581,4665) = true := by
  simp only [checkFour, w288_0, w288_1, w288_2, w288_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one288 : Coverage 288 289 := checkList_sound (ws:=[(581,4665,581,4665)]) (by simpa only [checkList, Bool.and_true] using cases288)
private theorem w289_0 : checkWitness 289 false false 8848 = true := by decide +kernel
private theorem w289_2 : checkWitness 289 true false 8844 = true := by decide +kernel
private theorem cases289 : checkFour 289 (8848,0,8844,0) = true := by
  simp only [checkFour, w289_0, w289_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one289 : Coverage 289 290 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases289)
private theorem w290_0 : checkWitness 290 false false 72 = true := by decide +kernel
private theorem w290_2 : checkWitness 290 true false 72 = true := by decide +kernel
private theorem cases290 : checkFour 290 (72,0,72,0) = true := by
  simp only [checkFour, w290_0, w290_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one290 : Coverage 290 291 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases290)
private theorem w291_0 : checkWitness 291 false false 625 = true := by decide +kernel
private theorem w291_1 : checkWitness 291 false true 4717 = true := by decide +kernel
private theorem w291_2 : checkWitness 291 true false 616 = true := by decide +kernel
private theorem w291_3 : checkWitness 291 true true 4708 = true := by decide +kernel
private theorem cases291 : checkFour 291 (625,4717,616,4708) = true := by
  simp only [checkFour, w291_0, w291_1, w291_2, w291_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one291 : Coverage 291 292 := checkList_sound (ws:=[(625,4717,616,4708)]) (by simpa only [checkList, Bool.and_true] using cases291)
private theorem w292_0 : checkWitness 292 false false 8922 = true := by decide +kernel
private theorem w292_2 : checkWitness 292 true false 8913 = true := by decide +kernel
private theorem cases292 : checkFour 292 (8922,0,8913,0) = true := by
  simp only [checkFour, w292_0, w292_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one292 : Coverage 292 293 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases292)
private theorem w293_0 : checkWitness 293 false false 8868 = true := by decide +kernel
private theorem w293_2 : checkWitness 293 true false 8864 = true := by decide +kernel
private theorem cases293 : checkFour 293 (8868,0,8864,0) = true := by
  simp only [checkFour, w293_0, w293_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one293 : Coverage 293 294 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases293)
private theorem w294_0 : checkWitness 294 false false 76 = true := by decide +kernel
private theorem w294_2 : checkWitness 294 true false 76 = true := by decide +kernel
private theorem cases294 : checkFour 294 (76,0,76,0) = true := by
  simp only [checkFour, w294_0, w294_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one294 : Coverage 294 295 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases294)
private theorem w295_0 : checkWitness 295 false false 656 = true := by decide +kernel
private theorem w295_1 : checkWitness 295 false true 4740 = true := by decide +kernel
private theorem w295_2 : checkWitness 295 true false 647 = true := by decide +kernel
private theorem w295_3 : checkWitness 295 true true 4731 = true := by decide +kernel
private theorem cases295 : checkFour 295 (656,4740,647,4731) = true := by
  simp only [checkFour, w295_0, w295_1, w295_2, w295_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one295 : Coverage 295 296 := checkList_sound (ws:=[(656,4740,647,4731)]) (by simpa only [checkList, Bool.and_true] using cases295)
private theorem w296_0 : checkWitness 296 false false 8929 = true := by decide +kernel
private theorem w296_2 : checkWitness 296 true false 8920 = true := by decide +kernel
private theorem cases296 : checkFour 296 (8929,0,8920,0) = true := by
  simp only [checkFour, w296_0, w296_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one296 : Coverage 296 297 := checkList_sound (ws:=[(8929,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases296)
private theorem w297_0 : checkWitness 297 false false 60 = true := by decide +kernel
private theorem w297_2 : checkWitness 297 true false 60 = true := by decide +kernel
private theorem cases297 : checkFour 297 (60,0,60,0) = true := by
  simp only [checkFour, w297_0, w297_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one297 : Coverage 297 298 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases297)
private theorem w298_0 : checkWitness 298 false false 552 = true := by decide +kernel
private theorem w298_1 : checkWitness 298 false true 4648 = true := by decide +kernel
private theorem w298_2 : checkWitness 298 true false 552 = true := by decide +kernel
private theorem w298_3 : checkWitness 298 true true 4648 = true := by decide +kernel
private theorem cases298 : checkFour 298 (552,4648,552,4648) = true := by
  simp only [checkFour, w298_0, w298_1, w298_2, w298_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one298 : Coverage 298 299 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases298)
private theorem w299_0 : checkWitness 299 false false 8926 = true := by decide +kernel
private theorem w299_2 : checkWitness 299 true false 8917 = true := by decide +kernel
private theorem cases299 : checkFour 299 (8926,0,8917,0) = true := by
  simp only [checkFour, w299_0, w299_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one299 : Coverage 299 300 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases299)
private theorem w300_0 : checkWitness 300 false false 60 = true := by decide +kernel
private theorem w300_2 : checkWitness 300 true false 60 = true := by decide +kernel
private theorem cases300 : checkFour 300 (60,0,60,0) = true := by
  simp only [checkFour, w300_0, w300_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one300 : Coverage 300 301 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases300)
private theorem w301_0 : checkWitness 301 false false 504 = true := by decide +kernel
private theorem w301_1 : checkWitness 301 false true 4600 = true := by decide +kernel
private theorem w301_2 : checkWitness 301 true false 504 = true := by decide +kernel
private theorem w301_3 : checkWitness 301 true true 4600 = true := by decide +kernel
private theorem cases301 : checkFour 301 (504,4600,504,4600) = true := by
  simp only [checkFour, w301_0, w301_1, w301_2, w301_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one301 : Coverage 301 302 := checkList_sound (ws:=[(504,4600,504,4600)]) (by simpa only [checkList, Bool.and_true] using cases301)
private theorem w302_0 : checkWitness 302 false false 8878 = true := by decide +kernel
private theorem w302_2 : checkWitness 302 true false 8874 = true := by decide +kernel
private theorem cases302 : checkFour 302 (8878,0,8874,0) = true := by
  simp only [checkFour, w302_0, w302_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one302 : Coverage 302 303 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases302)
private theorem w303_0 : checkWitness 303 false false 64 = true := by decide +kernel
private theorem w303_2 : checkWitness 303 true false 64 = true := by decide +kernel
private theorem cases303 : checkFour 303 (64,0,64,0) = true := by
  simp only [checkFour, w303_0, w303_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one303 : Coverage 303 304 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases303)
private theorem w304_0 : checkWitness 304 false false 546 = true := by decide +kernel
private theorem w304_1 : checkWitness 304 false true 4642 = true := by decide +kernel
private theorem w304_2 : checkWitness 304 true false 546 = true := by decide +kernel
private theorem w304_3 : checkWitness 304 true true 4642 = true := by decide +kernel
private theorem cases304 : checkFour 304 (546,4642,546,4642) = true := by
  simp only [checkFour, w304_0, w304_1, w304_2, w304_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one304 : Coverage 304 305 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases304)
private theorem w305_0 : checkWitness 305 false false 8897 = true := by decide +kernel
private theorem w305_2 : checkWitness 305 true false 8893 = true := by decide +kernel
private theorem cases305 : checkFour 305 (8897,0,8893,0) = true := by
  simp only [checkFour, w305_0, w305_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one305 : Coverage 305 306 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases305)
private theorem w306_0 : checkWitness 306 false false 8928 = true := by decide +kernel
private theorem w306_2 : checkWitness 306 true false 8919 = true := by decide +kernel
private theorem cases306 : checkFour 306 (8928,0,8919,0) = true := by
  simp only [checkFour, w306_0, w306_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one306 : Coverage 306 307 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases306)
private theorem w307_0 : checkWitness 307 false false 88 = true := by decide +kernel
private theorem w307_2 : checkWitness 307 true false 88 = true := by decide +kernel
private theorem cases307 : checkFour 307 (88,0,88,0) = true := by
  simp only [checkFour, w307_0, w307_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one307 : Coverage 307 308 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases307)
private theorem w308_0 : checkWitness 308 false false 642 = true := by decide +kernel
private theorem w308_1 : checkWitness 308 false true 4734 = true := by decide +kernel
private theorem w308_2 : checkWitness 308 true false 633 = true := by decide +kernel
private theorem w308_3 : checkWitness 308 true true 4725 = true := by decide +kernel
private theorem cases308 : checkFour 308 (642,4734,633,4725) = true := by
  simp only [checkFour, w308_0, w308_1, w308_2, w308_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one308 : Coverage 308 309 := checkList_sound (ws:=[(642,4734,633,4725)]) (by simpa only [checkList, Bool.and_true] using cases308)
private theorem w309_0 : checkWitness 309 false false 8893 = true := by decide +kernel
private theorem w309_2 : checkWitness 309 true false 8889 = true := by decide +kernel
private theorem cases309 : checkFour 309 (8893,0,8889,0) = true := by
  simp only [checkFour, w309_0, w309_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one309 : Coverage 309 310 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases309)
private theorem w310_0 : checkWitness 310 false false 636 = true := by decide +kernel
private theorem w310_1 : checkWitness 310 false true 4728 = true := by decide +kernel
private theorem w310_2 : checkWitness 310 true false 627 = true := by decide +kernel
private theorem w310_3 : checkWitness 310 true true 4719 = true := by decide +kernel
private theorem cases310 : checkFour 310 (636,4728,627,4719) = true := by
  simp only [checkFour, w310_0, w310_1, w310_2, w310_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one310 : Coverage 310 311 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases310)
private theorem w311_0 : checkWitness 311 false false 8864 = true := by decide +kernel
private theorem w311_2 : checkWitness 311 true false 8860 = true := by decide +kernel
private theorem cases311 : checkFour 311 (8864,0,8860,0) = true := by
  simp only [checkFour, w311_0, w311_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one311 : Coverage 311 312 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases311)
private theorem w312_0 : checkWitness 312 false false 76 = true := by decide +kernel
private theorem w312_2 : checkWitness 312 true false 76 = true := by decide +kernel
private theorem cases312 : checkFour 312 (76,0,76,0) = true := by
  simp only [checkFour, w312_0, w312_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one312 : Coverage 312 313 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases312)
private theorem w313_0 : checkWitness 313 false false 68 = true := by decide +kernel
private theorem w313_2 : checkWitness 313 true false 68 = true := by decide +kernel
private theorem cases313 : checkFour 313 (68,0,68,0) = true := by
  simp only [checkFour, w313_0, w313_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one313 : Coverage 313 314 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases313)
private theorem w314_0 : checkWitness 314 false false 589 = true := by decide +kernel
private theorem w314_1 : checkWitness 314 false true 4673 = true := by decide +kernel
private theorem w314_2 : checkWitness 314 true false 589 = true := by decide +kernel
private theorem w314_3 : checkWitness 314 true true 4673 = true := by decide +kernel
private theorem cases314 : checkFour 314 (589,4673,589,4673) = true := by
  simp only [checkFour, w314_0, w314_1, w314_2, w314_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one314 : Coverage 314 315 := checkList_sound (ws:=[(589,4673,589,4673)]) (by simpa only [checkList, Bool.and_true] using cases314)
private theorem w315_0 : checkWitness 315 false false 8856 = true := by decide +kernel
private theorem w315_2 : checkWitness 315 true false 8852 = true := by decide +kernel
private theorem cases315 : checkFour 315 (8856,0,8852,0) = true := by
  simp only [checkFour, w315_0, w315_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one315 : Coverage 315 316 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases315)
private theorem w316_0 : checkWitness 316 false false 68 = true := by decide +kernel
private theorem w316_2 : checkWitness 316 true false 68 = true := by decide +kernel
private theorem cases316 : checkFour 316 (68,0,68,0) = true := by
  simp only [checkFour, w316_0, w316_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one316 : Coverage 316 317 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases316)
private theorem w317_0 : checkWitness 317 false false 586 = true := by decide +kernel
private theorem w317_1 : checkWitness 317 false true 4682 = true := by decide +kernel
private theorem w317_2 : checkWitness 317 true false 586 = true := by decide +kernel
private theorem w317_3 : checkWitness 317 true true 4682 = true := by decide +kernel
private theorem cases317 : checkFour 317 (586,4682,586,4682) = true := by
  simp only [checkFour, w317_0, w317_1, w317_2, w317_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one317 : Coverage 317 318 := checkList_sound (ws:=[(586,4682,586,4682)]) (by simpa only [checkList, Bool.and_true] using cases317)
private theorem w318_0 : checkWitness 318 false false 8926 = true := by decide +kernel
private theorem w318_2 : checkWitness 318 true false 8917 = true := by decide +kernel
private theorem cases318 : checkFour 318 (8926,0,8917,0) = true := by
  simp only [checkFour, w318_0, w318_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one318 : Coverage 318 319 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases318)
private theorem w319_0 : checkWitness 319 false false 8872 = true := by decide +kernel
private theorem w319_2 : checkWitness 319 true false 8868 = true := by decide +kernel
private theorem cases319 : checkFour 319 (8872,0,8868,0) = true := by
  simp only [checkFour, w319_0, w319_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one319 : Coverage 319 320 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases319)
theorem cover0288 : Coverage 288 320 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one288 one289) (Coverage.join one290 one291)) (Coverage.join (Coverage.join one292 one293) (Coverage.join one294 one295))) (Coverage.join (Coverage.join (Coverage.join one296 one297) (Coverage.join one298 one299)) (Coverage.join (Coverage.join one300 one301) (Coverage.join one302 one303)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one304 one305) (Coverage.join one306 one307)) (Coverage.join (Coverage.join one308 one309) (Coverage.join one310 one311))) (Coverage.join (Coverage.join (Coverage.join one312 one313) (Coverage.join one314 one315)) (Coverage.join (Coverage.join one316 one317) (Coverage.join one318 one319)))))
end NF180PA.Symbolic
