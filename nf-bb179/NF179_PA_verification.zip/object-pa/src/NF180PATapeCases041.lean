import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1312_0 : checkWitness 1312 false false 106 = true := by decide +kernel
private theorem w1312_2 : checkWitness 1312 true false 106 = true := by decide +kernel
private theorem cases1312 : checkFour 1312 (106,0,106,0) = true := by
  simp only [checkFour, w1312_0, w1312_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1312 : Coverage 1312 1313 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1312)
private theorem w1313_0 : checkWitness 1313 false false 616 = true := by decide +kernel
private theorem w1313_1 : checkWitness 1313 false true 4708 = true := by decide +kernel
private theorem w1313_2 : checkWitness 1313 true false 607 = true := by decide +kernel
private theorem w1313_3 : checkWitness 1313 true true 4699 = true := by decide +kernel
private theorem cases1313 : checkFour 1313 (616,4708,607,4699) = true := by
  simp only [checkFour, w1313_0, w1313_1, w1313_2, w1313_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1313 : Coverage 1313 1314 := checkList_sound (ws:=[(616,4708,607,4699)]) (by simpa only [checkList, Bool.and_true] using cases1313)
private theorem w1314_0 : checkWitness 1314 false false 8867 = true := by decide +kernel
private theorem w1314_2 : checkWitness 1314 true false 8863 = true := by decide +kernel
private theorem cases1314 : checkFour 1314 (8867,0,8863,0) = true := by
  simp only [checkFour, w1314_0, w1314_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1314 : Coverage 1314 1315 := checkList_sound (ws:=[(8867,0,8863,0)]) (by simpa only [checkList, Bool.and_true] using cases1314)
private theorem w1315_0 : checkWitness 1315 false false 610 = true := by decide +kernel
private theorem w1315_1 : checkWitness 1315 false true 4702 = true := by decide +kernel
private theorem w1315_2 : checkWitness 1315 true false 601 = true := by decide +kernel
private theorem w1315_3 : checkWitness 1315 true true 4693 = true := by decide +kernel
private theorem cases1315 : checkFour 1315 (610,4702,601,4693) = true := by
  simp only [checkFour, w1315_0, w1315_1, w1315_2, w1315_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1315 : Coverage 1315 1316 := checkList_sound (ws:=[(610,4702,601,4693)]) (by simpa only [checkList, Bool.and_true] using cases1315)
private theorem w1316_0 : checkWitness 1316 false false 8838 = true := by decide +kernel
private theorem w1316_2 : checkWitness 1316 true false 8834 = true := by decide +kernel
private theorem cases1316 : checkFour 1316 (8838,0,8834,0) = true := by
  simp only [checkFour, w1316_0, w1316_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1316 : Coverage 1316 1317 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1316)
private theorem w1317_0 : checkWitness 1317 false false 94 = true := by decide +kernel
private theorem w1317_2 : checkWitness 1317 true false 94 = true := by decide +kernel
private theorem cases1317 : checkFour 1317 (94,0,94,0) = true := by
  simp only [checkFour, w1317_0, w1317_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1317 : Coverage 1317 1318 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1317)
private theorem w1318_0 : checkWitness 1318 false false 86 = true := by decide +kernel
private theorem w1318_2 : checkWitness 1318 true false 86 = true := by decide +kernel
private theorem cases1318 : checkFour 1318 (86,0,86,0) = true := by
  simp only [checkFour, w1318_0, w1318_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1318 : Coverage 1318 1319 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1318)
private theorem w1319_0 : checkWitness 1319 false false 563 = true := by decide +kernel
private theorem w1319_1 : checkWitness 1319 false true 4647 = true := by decide +kernel
private theorem w1319_2 : checkWitness 1319 true false 563 = true := by decide +kernel
private theorem w1319_3 : checkWitness 1319 true true 4647 = true := by decide +kernel
private theorem cases1319 : checkFour 1319 (563,4647,563,4647) = true := by
  simp only [checkFour, w1319_0, w1319_1, w1319_2, w1319_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1319 : Coverage 1319 1320 := checkList_sound (ws:=[(563,4647,563,4647)]) (by simpa only [checkList, Bool.and_true] using cases1319)
private theorem w1320_0 : checkWitness 1320 false false 8830 = true := by decide +kernel
private theorem w1320_2 : checkWitness 1320 true false 8826 = true := by decide +kernel
private theorem cases1320 : checkFour 1320 (8830,0,8826,0) = true := by
  simp only [checkFour, w1320_0, w1320_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1320 : Coverage 1320 1321 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1320)
private theorem w1321_0 : checkWitness 1321 false false 86 = true := by decide +kernel
private theorem w1321_2 : checkWitness 1321 true false 86 = true := by decide +kernel
private theorem cases1321 : checkFour 1321 (86,0,86,0) = true := by
  simp only [checkFour, w1321_0, w1321_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1321 : Coverage 1321 1322 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1321)
private theorem w1322_0 : checkWitness 1322 false false 560 = true := by decide +kernel
private theorem w1322_1 : checkWitness 1322 false true 4656 = true := by decide +kernel
private theorem w1322_2 : checkWitness 1322 true false 560 = true := by decide +kernel
private theorem w1322_3 : checkWitness 1322 true true 4656 = true := by decide +kernel
private theorem cases1322 : checkFour 1322 (560,4656,560,4656) = true := by
  simp only [checkFour, w1322_0, w1322_1, w1322_2, w1322_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1322 : Coverage 1322 1323 := checkList_sound (ws:=[(560,4656,560,4656)]) (by simpa only [checkList, Bool.and_true] using cases1322)
private theorem w1323_0 : checkWitness 1323 false false 8900 = true := by decide +kernel
private theorem w1323_2 : checkWitness 1323 true false 8891 = true := by decide +kernel
private theorem cases1323 : checkFour 1323 (8900,0,8891,0) = true := by
  simp only [checkFour, w1323_0, w1323_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1323 : Coverage 1323 1324 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1323)
private theorem w1324_0 : checkWitness 1324 false false 8846 = true := by decide +kernel
private theorem w1324_2 : checkWitness 1324 true false 8842 = true := by decide +kernel
private theorem cases1324 : checkFour 1324 (8846,0,8842,0) = true := by
  simp only [checkFour, w1324_0, w1324_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1324 : Coverage 1324 1325 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1324)
private theorem w1325_0 : checkWitness 1325 false false 94 = true := by decide +kernel
private theorem w1325_2 : checkWitness 1325 true false 94 = true := by decide +kernel
private theorem cases1325 : checkFour 1325 (94,0,94,0) = true := by
  simp only [checkFour, w1325_0, w1325_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1325 : Coverage 1325 1326 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1325)
private theorem w1326_0 : checkWitness 1326 false false 626 = true := by decide +kernel
private theorem w1326_1 : checkWitness 1326 false true 4714 = true := by decide +kernel
private theorem w1326_2 : checkWitness 1326 true false 617 = true := by decide +kernel
private theorem w1326_3 : checkWitness 1326 true true 4705 = true := by decide +kernel
private theorem cases1326 : checkFour 1326 (626,4714,617,4705) = true := by
  simp only [checkFour, w1326_0, w1326_1, w1326_2, w1326_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1326 : Coverage 1326 1327 := checkList_sound (ws:=[(626,4714,617,4705)]) (by simpa only [checkList, Bool.and_true] using cases1326)
private theorem w1327_0 : checkWitness 1327 false false 8884 = true := by decide +kernel
private theorem w1327_2 : checkWitness 1327 true false 8880 = true := by decide +kernel
private theorem cases1327 : checkFour 1327 (8884,0,8880,0) = true := by
  simp only [checkFour, w1327_0, w1327_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1327 : Coverage 1327 1328 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases1327)
private theorem w1328_0 : checkWitness 1328 false false 84 = true := by decide +kernel
private theorem w1328_2 : checkWitness 1328 true false 84 = true := by decide +kernel
private theorem cases1328 : checkFour 1328 (84,0,84,0) = true := by
  simp only [checkFour, w1328_0, w1328_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1328 : Coverage 1328 1329 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1328)
private theorem w1329_0 : checkWitness 1329 false false 614 = true := by decide +kernel
private theorem w1329_1 : checkWitness 1329 false true 4710 = true := by decide +kernel
private theorem w1329_2 : checkWitness 1329 true false 614 = true := by decide +kernel
private theorem w1329_3 : checkWitness 1329 true true 4710 = true := by decide +kernel
private theorem cases1329 : checkFour 1329 (614,4710,614,4710) = true := by
  simp only [checkFour, w1329_0, w1329_1, w1329_2, w1329_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1329 : Coverage 1329 1330 := checkList_sound (ws:=[(614,4710,614,4710)]) (by simpa only [checkList, Bool.and_true] using cases1329)
private theorem w1330_0 : checkWitness 1330 false false 8886 = true := by decide +kernel
private theorem w1330_2 : checkWitness 1330 true false 8877 = true := by decide +kernel
private theorem cases1330 : checkFour 1330 (8886,0,8877,0) = true := by
  simp only [checkFour, w1330_0, w1330_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1330 : Coverage 1330 1331 := checkList_sound (ws:=[(8886,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases1330)
private theorem w1331_0 : checkWitness 1331 false false 80 = true := by decide +kernel
private theorem w1331_2 : checkWitness 1331 true false 80 = true := by decide +kernel
private theorem cases1331 : checkFour 1331 (80,0,80,0) = true := by
  simp only [checkFour, w1331_0, w1331_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1331 : Coverage 1331 1332 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1331)
private theorem w1332_0 : checkWitness 1332 false false 464 = true := by decide +kernel
private theorem w1332_1 : checkWitness 1332 false true 4560 = true := by decide +kernel
private theorem w1332_2 : checkWitness 1332 true false 464 = true := by decide +kernel
private theorem w1332_3 : checkWitness 1332 true true 4560 = true := by decide +kernel
private theorem cases1332 : checkFour 1332 (464,4560,464,4560) = true := by
  simp only [checkFour, w1332_0, w1332_1, w1332_2, w1332_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1332 : Coverage 1332 1333 := checkList_sound (ws:=[(464,4560,464,4560)]) (by simpa only [checkList, Bool.and_true] using cases1332)
private theorem w1333_0 : checkWitness 1333 false false 8838 = true := by decide +kernel
private theorem w1333_2 : checkWitness 1333 true false 8834 = true := by decide +kernel
private theorem cases1333 : checkFour 1333 (8838,0,8834,0) = true := by
  simp only [checkFour, w1333_0, w1333_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1333 : Coverage 1333 1334 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1333)
private theorem w1334_0 : checkWitness 1334 false false 84 = true := by decide +kernel
private theorem w1334_2 : checkWitness 1334 true false 84 = true := by decide +kernel
private theorem cases1334 : checkFour 1334 (84,0,84,0) = true := by
  simp only [checkFour, w1334_0, w1334_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1334 : Coverage 1334 1335 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1334)
private theorem w1335_0 : checkWitness 1335 false false 506 = true := by decide +kernel
private theorem w1335_1 : checkWitness 1335 false true 4602 = true := by decide +kernel
private theorem w1335_2 : checkWitness 1335 true false 506 = true := by decide +kernel
private theorem w1335_3 : checkWitness 1335 true true 4602 = true := by decide +kernel
private theorem cases1335 : checkFour 1335 (506,4602,506,4602) = true := by
  simp only [checkFour, w1335_0, w1335_1, w1335_2, w1335_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1335 : Coverage 1335 1336 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases1335)
private theorem w1336_0 : checkWitness 1336 false false 8857 = true := by decide +kernel
private theorem w1336_2 : checkWitness 1336 true false 8853 = true := by decide +kernel
private theorem cases1336 : checkFour 1336 (8857,0,8853,0) = true := by
  simp only [checkFour, w1336_0, w1336_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1336 : Coverage 1336 1337 := checkList_sound (ws:=[(8857,0,8853,0)]) (by simpa only [checkList, Bool.and_true] using cases1336)
private theorem w1337_0 : checkWitness 1337 false false 8888 = true := by decide +kernel
private theorem w1337_2 : checkWitness 1337 true false 8879 = true := by decide +kernel
private theorem cases1337 : checkFour 1337 (8888,0,8879,0) = true := by
  simp only [checkFour, w1337_0, w1337_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1337 : Coverage 1337 1338 := checkList_sound (ws:=[(8888,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1337)
private theorem w1338_0 : checkWitness 1338 false false 108 = true := by decide +kernel
private theorem w1338_2 : checkWitness 1338 true false 108 = true := by decide +kernel
private theorem cases1338 : checkFour 1338 (108,0,108,0) = true := by
  simp only [checkFour, w1338_0, w1338_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1338 : Coverage 1338 1339 := checkList_sound (ws:=[(108,0,108,0)]) (by simpa only [checkList, Bool.and_true] using cases1338)
private theorem w1339_0 : checkWitness 1339 false false 602 = true := by decide +kernel
private theorem w1339_1 : checkWitness 1339 false true 4694 = true := by decide +kernel
private theorem w1339_2 : checkWitness 1339 true false 593 = true := by decide +kernel
private theorem w1339_3 : checkWitness 1339 true true 4685 = true := by decide +kernel
private theorem cases1339 : checkFour 1339 (602,4694,593,4685) = true := by
  simp only [checkFour, w1339_0, w1339_1, w1339_2, w1339_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1339 : Coverage 1339 1340 := checkList_sound (ws:=[(602,4694,593,4685)]) (by simpa only [checkList, Bool.and_true] using cases1339)
private theorem w1340_0 : checkWitness 1340 false false 8853 = true := by decide +kernel
private theorem w1340_2 : checkWitness 1340 true false 8849 = true := by decide +kernel
private theorem cases1340 : checkFour 1340 (8853,0,8849,0) = true := by
  simp only [checkFour, w1340_0, w1340_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1340 : Coverage 1340 1341 := checkList_sound (ws:=[(8853,0,8849,0)]) (by simpa only [checkList, Bool.and_true] using cases1340)
private theorem w1341_0 : checkWitness 1341 false false 596 = true := by decide +kernel
private theorem w1341_1 : checkWitness 1341 false true 4688 = true := by decide +kernel
private theorem w1341_2 : checkWitness 1341 true false 587 = true := by decide +kernel
private theorem w1341_3 : checkWitness 1341 true true 4679 = true := by decide +kernel
private theorem cases1341 : checkFour 1341 (596,4688,587,4679) = true := by
  simp only [checkFour, w1341_0, w1341_1, w1341_2, w1341_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1341 : Coverage 1341 1342 := checkList_sound (ws:=[(596,4688,587,4679)]) (by simpa only [checkList, Bool.and_true] using cases1341)
private theorem w1342_0 : checkWitness 1342 false false 8825 = true := by decide +kernel
private theorem w1342_2 : checkWitness 1342 true false 8821 = true := by decide +kernel
private theorem cases1342 : checkFour 1342 (8825,0,8821,0) = true := by
  simp only [checkFour, w1342_0, w1342_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1342 : Coverage 1342 1343 := checkList_sound (ws:=[(8825,0,8821,0)]) (by simpa only [checkList, Bool.and_true] using cases1342)
private theorem w1343_0 : checkWitness 1343 false false 96 = true := by decide +kernel
private theorem w1343_2 : checkWitness 1343 true false 96 = true := by decide +kernel
private theorem cases1343 : checkFour 1343 (96,0,96,0) = true := by
  simp only [checkFour, w1343_0, w1343_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1343 : Coverage 1343 1344 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1343)
theorem cover1312 : Coverage 1312 1344 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1312 one1313) (Coverage.join one1314 one1315)) (Coverage.join (Coverage.join one1316 one1317) (Coverage.join one1318 one1319))) (Coverage.join (Coverage.join (Coverage.join one1320 one1321) (Coverage.join one1322 one1323)) (Coverage.join (Coverage.join one1324 one1325) (Coverage.join one1326 one1327)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1328 one1329) (Coverage.join one1330 one1331)) (Coverage.join (Coverage.join one1332 one1333) (Coverage.join one1334 one1335))) (Coverage.join (Coverage.join (Coverage.join one1336 one1337) (Coverage.join one1338 one1339)) (Coverage.join (Coverage.join one1340 one1341) (Coverage.join one1342 one1343)))))
end NF180PA.Symbolic
