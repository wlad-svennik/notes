import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1792_0 : checkWitness 1792 false false 86 = true := by decide +kernel
private theorem w1792_2 : checkWitness 1792 true false 86 = true := by decide +kernel
private theorem cases1792 : checkFour 1792 (86,0,86,0) = true := by
  simp only [checkFour, w1792_0, w1792_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1792 : Coverage 1792 1793 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1792)
private theorem w1793_0 : checkWitness 1793 false false 628 = true := by decide +kernel
private theorem w1793_1 : checkWitness 1793 false true 4720 = true := by decide +kernel
private theorem w1793_2 : checkWitness 1793 true false 619 = true := by decide +kernel
private theorem w1793_3 : checkWitness 1793 true true 4711 = true := by decide +kernel
private theorem cases1793 : checkFour 1793 (628,4720,619,4711) = true := by
  simp only [checkFour, w1793_0, w1793_1, w1793_2, w1793_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1793 : Coverage 1793 1794 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases1793)
private theorem w1794_0 : checkWitness 1794 false false 8909 = true := by decide +kernel
private theorem w1794_2 : checkWitness 1794 true false 8900 = true := by decide +kernel
private theorem cases1794 : checkFour 1794 (8909,0,8900,0) = true := by
  simp only [checkFour, w1794_0, w1794_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1794 : Coverage 1794 1795 := checkList_sound (ws:=[(8909,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases1794)
private theorem w1795_0 : checkWitness 1795 false false 70 = true := by decide +kernel
private theorem w1795_2 : checkWitness 1795 true false 70 = true := by decide +kernel
private theorem cases1795 : checkFour 1795 (70,0,70,0) = true := by
  simp only [checkFour, w1795_0, w1795_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1795 : Coverage 1795 1796 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases1795)
private theorem w1796_0 : checkWitness 1796 false false 486 = true := by decide +kernel
private theorem w1796_1 : checkWitness 1796 false true 4582 = true := by decide +kernel
private theorem w1796_2 : checkWitness 1796 true false 486 = true := by decide +kernel
private theorem w1796_3 : checkWitness 1796 true true 4582 = true := by decide +kernel
private theorem cases1796 : checkFour 1796 (486,4582,486,4582) = true := by
  simp only [checkFour, w1796_0, w1796_1, w1796_2, w1796_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1796 : Coverage 1796 1797 := checkList_sound (ws:=[(486,4582,486,4582)]) (by simpa only [checkList, Bool.and_true] using cases1796)
private theorem w1797_0 : checkWitness 1797 false false 8889 = true := by decide +kernel
private theorem w1797_2 : checkWitness 1797 true false 8885 = true := by decide +kernel
private theorem cases1797 : checkFour 1797 (8889,0,8885,0) = true := by
  simp only [checkFour, w1797_0, w1797_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1797 : Coverage 1797 1798 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1797)
private theorem w1798_0 : checkWitness 1798 false false 618 = true := by decide +kernel
private theorem w1798_1 : checkWitness 1798 false true 4714 = true := by decide +kernel
private theorem w1798_2 : checkWitness 1798 true false 609 = true := by decide +kernel
private theorem w1798_3 : checkWitness 1798 true true 4705 = true := by decide +kernel
private theorem cases1798 : checkFour 1798 (618,4714,609,4705) = true := by
  simp only [checkFour, w1798_0, w1798_1, w1798_2, w1798_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1798 : Coverage 1798 1799 := checkList_sound (ws:=[(618,4714,609,4705)]) (by simpa only [checkList, Bool.and_true] using cases1798)
private theorem w1799_0 : checkWitness 1799 false false 176 = true := by decide +kernel
private theorem w1799_2 : checkWitness 1799 true false 176 = true := by decide +kernel
private theorem cases1799 : checkFour 1799 (176,0,176,0) = true := by
  simp only [checkFour, w1799_0, w1799_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1799 : Coverage 1799 1800 := checkList_sound (ws:=[(176,0,176,0)]) (by simpa only [checkList, Bool.and_true] using cases1799)
private theorem w1800_0 : checkWitness 1800 false false 567 = true := by decide +kernel
private theorem w1800_1 : checkWitness 1800 false true 4655 = true := by decide +kernel
private theorem w1800_2 : checkWitness 1800 true false 567 = true := by decide +kernel
private theorem w1800_3 : checkWitness 1800 true true 4655 = true := by decide +kernel
private theorem cases1800 : checkFour 1800 (567,4655,567,4655) = true := by
  simp only [checkFour, w1800_0, w1800_1, w1800_2, w1800_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1800 : Coverage 1800 1801 := checkList_sound (ws:=[(567,4655,567,4655)]) (by simpa only [checkList, Bool.and_true] using cases1800)
private theorem w1801_0 : checkWitness 1801 false false 8900 = true := by decide +kernel
private theorem w1801_2 : checkWitness 1801 true false 8891 = true := by decide +kernel
private theorem cases1801 : checkFour 1801 (8900,0,8891,0) = true := by
  simp only [checkFour, w1801_0, w1801_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1801 : Coverage 1801 1802 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1801)
private theorem w1802_0 : checkWitness 1802 false false 88 = true := by decide +kernel
private theorem w1802_2 : checkWitness 1802 true false 88 = true := by decide +kernel
private theorem cases1802 : checkFour 1802 (88,0,88,0) = true := by
  simp only [checkFour, w1802_0, w1802_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1802 : Coverage 1802 1803 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1802)
private theorem w1803_0 : checkWitness 1803 false false 80 = true := by decide +kernel
private theorem w1803_2 : checkWitness 1803 true false 80 = true := by decide +kernel
private theorem cases1803 : checkFour 1803 (80,0,80,0) = true := by
  simp only [checkFour, w1803_0, w1803_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1803 : Coverage 1803 1804 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1803)
private theorem w1804_0 : checkWitness 1804 false false 567 = true := by decide +kernel
private theorem w1804_1 : checkWitness 1804 false true 4659 = true := by decide +kernel
private theorem w1804_2 : checkWitness 1804 true false 567 = true := by decide +kernel
private theorem w1804_3 : checkWitness 1804 true true 4659 = true := by decide +kernel
private theorem cases1804 : checkFour 1804 (567,4659,567,4659) = true := by
  simp only [checkFour, w1804_0, w1804_1, w1804_2, w1804_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1804 : Coverage 1804 1805 := checkList_sound (ws:=[(567,4659,567,4659)]) (by simpa only [checkList, Bool.and_true] using cases1804)
private theorem w1805_0 : checkWitness 1805 false false 8842 = true := by decide +kernel
private theorem w1805_2 : checkWitness 1805 true false 8838 = true := by decide +kernel
private theorem cases1805 : checkFour 1805 (8842,0,8838,0) = true := by
  simp only [checkFour, w1805_0, w1805_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1805 : Coverage 1805 1806 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1805)
private theorem w1806_0 : checkWitness 1806 false false 80 = true := by decide +kernel
private theorem w1806_2 : checkWitness 1806 true false 80 = true := by decide +kernel
private theorem cases1806 : checkFour 1806 (80,0,80,0) = true := by
  simp only [checkFour, w1806_0, w1806_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1806 : Coverage 1806 1807 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1806)
private theorem w1807_0 : checkWitness 1807 false false 526 = true := by decide +kernel
private theorem w1807_1 : checkWitness 1807 false true 4622 = true := by decide +kernel
private theorem w1807_2 : checkWitness 1807 true false 526 = true := by decide +kernel
private theorem w1807_3 : checkWitness 1807 true true 4622 = true := by decide +kernel
private theorem cases1807 : checkFour 1807 (526,4622,526,4622) = true := by
  simp only [checkFour, w1807_0, w1807_1, w1807_2, w1807_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1807 : Coverage 1807 1808 := checkList_sound (ws:=[(526,4622,526,4622)]) (by simpa only [checkList, Bool.and_true] using cases1807)
private theorem w1808_0 : checkWitness 1808 false false 8877 = true := by decide +kernel
private theorem w1808_2 : checkWitness 1808 true false 8873 = true := by decide +kernel
private theorem cases1808 : checkFour 1808 (8877,0,8873,0) = true := by
  simp only [checkFour, w1808_0, w1808_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1808 : Coverage 1808 1809 := checkList_sound (ws:=[(8877,0,8873,0)]) (by simpa only [checkList, Bool.and_true] using cases1808)
private theorem w1809_0 : checkWitness 1809 false false 8908 = true := by decide +kernel
private theorem w1809_2 : checkWitness 1809 true false 8899 = true := by decide +kernel
private theorem cases1809 : checkFour 1809 (8908,0,8899,0) = true := by
  simp only [checkFour, w1809_0, w1809_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1809 : Coverage 1809 1810 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases1809)
private theorem w1810_0 : checkWitness 1810 false false 98 = true := by decide +kernel
private theorem w1810_2 : checkWitness 1810 true false 98 = true := by decide +kernel
private theorem cases1810 : checkFour 1810 (98,0,98,0) = true := by
  simp only [checkFour, w1810_0, w1810_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1810 : Coverage 1810 1811 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1810)
private theorem w1811_0 : checkWitness 1811 false false 622 = true := by decide +kernel
private theorem w1811_1 : checkWitness 1811 false true 4714 = true := by decide +kernel
private theorem w1811_2 : checkWitness 1811 true false 613 = true := by decide +kernel
private theorem w1811_3 : checkWitness 1811 true true 4705 = true := by decide +kernel
private theorem cases1811 : checkFour 1811 (622,4714,613,4705) = true := by
  simp only [checkFour, w1811_0, w1811_1, w1811_2, w1811_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1811 : Coverage 1811 1812 := checkList_sound (ws:=[(622,4714,613,4705)]) (by simpa only [checkList, Bool.and_true] using cases1811)
private theorem w1812_0 : checkWitness 1812 false false 8873 = true := by decide +kernel
private theorem w1812_2 : checkWitness 1812 true false 8869 = true := by decide +kernel
private theorem cases1812 : checkFour 1812 (8873,0,8869,0) = true := by
  simp only [checkFour, w1812_0, w1812_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1812 : Coverage 1812 1813 := checkList_sound (ws:=[(8873,0,8869,0)]) (by simpa only [checkList, Bool.and_true] using cases1812)
private theorem w1813_0 : checkWitness 1813 false false 616 = true := by decide +kernel
private theorem w1813_1 : checkWitness 1813 false true 4708 = true := by decide +kernel
private theorem w1813_2 : checkWitness 1813 true false 607 = true := by decide +kernel
private theorem w1813_3 : checkWitness 1813 true true 4699 = true := by decide +kernel
private theorem cases1813 : checkFour 1813 (616,4708,607,4699) = true := by
  simp only [checkFour, w1813_0, w1813_1, w1813_2, w1813_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1813 : Coverage 1813 1814 := checkList_sound (ws:=[(616,4708,607,4699)]) (by simpa only [checkList, Bool.and_true] using cases1813)
private theorem w1814_0 : checkWitness 1814 false false 8844 = true := by decide +kernel
private theorem w1814_2 : checkWitness 1814 true false 8840 = true := by decide +kernel
private theorem cases1814 : checkFour 1814 (8844,0,8840,0) = true := by
  simp only [checkFour, w1814_0, w1814_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1814 : Coverage 1814 1815 := checkList_sound (ws:=[(8844,0,8840,0)]) (by simpa only [checkList, Bool.and_true] using cases1814)
private theorem w1815_0 : checkWitness 1815 false false 86 = true := by decide +kernel
private theorem w1815_2 : checkWitness 1815 true false 86 = true := by decide +kernel
private theorem cases1815 : checkFour 1815 (86,0,86,0) = true := by
  simp only [checkFour, w1815_0, w1815_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1815 : Coverage 1815 1816 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1815)
private theorem w1816_0 : checkWitness 1816 false false 78 = true := by decide +kernel
private theorem w1816_2 : checkWitness 1816 true false 78 = true := by decide +kernel
private theorem cases1816 : checkFour 1816 (78,0,78,0) = true := by
  simp only [checkFour, w1816_0, w1816_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1816 : Coverage 1816 1817 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1816)
private theorem w1817_0 : checkWitness 1817 false false 577 = true := by decide +kernel
private theorem w1817_1 : checkWitness 1817 false true 4665 = true := by decide +kernel
private theorem w1817_2 : checkWitness 1817 true false 577 = true := by decide +kernel
private theorem w1817_3 : checkWitness 1817 true true 4665 = true := by decide +kernel
private theorem cases1817 : checkFour 1817 (577,4665,577,4665) = true := by
  simp only [checkFour, w1817_0, w1817_1, w1817_2, w1817_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1817 : Coverage 1817 1818 := checkList_sound (ws:=[(577,4665,577,4665)]) (by simpa only [checkList, Bool.and_true] using cases1817)
private theorem w1818_0 : checkWitness 1818 false false 8860 = true := by decide +kernel
private theorem w1818_2 : checkWitness 1818 true false 8856 = true := by decide +kernel
private theorem cases1818 : checkFour 1818 (8860,0,8856,0) = true := by
  simp only [checkFour, w1818_0, w1818_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1818 : Coverage 1818 1819 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases1818)
private theorem w1819_0 : checkWitness 1819 false false 8856 = true := by decide +kernel
private theorem w1819_2 : checkWitness 1819 true false 8852 = true := by decide +kernel
private theorem cases1819 : checkFour 1819 (8856,0,8852,0) = true := by
  simp only [checkFour, w1819_0, w1819_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1819 : Coverage 1819 1820 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases1819)
private theorem w1820_0 : checkWitness 1820 false false 92 = true := by decide +kernel
private theorem w1820_2 : checkWitness 1820 true false 92 = true := by decide +kernel
private theorem cases1820 : checkFour 1820 (92,0,92,0) = true := by
  simp only [checkFour, w1820_0, w1820_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1820 : Coverage 1820 1821 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1820)
private theorem w1821_0 : checkWitness 1821 false false 8876 = true := by decide +kernel
private theorem w1821_2 : checkWitness 1821 true false 8872 = true := by decide +kernel
private theorem cases1821 : checkFour 1821 (8876,0,8872,0) = true := by
  simp only [checkFour, w1821_0, w1821_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1821 : Coverage 1821 1822 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases1821)
private theorem w1822_0 : checkWitness 1822 false false 582 = true := by decide +kernel
private theorem w1822_1 : checkWitness 1822 false true 4678 = true := by decide +kernel
private theorem w1822_2 : checkWitness 1822 true false 582 = true := by decide +kernel
private theorem w1822_3 : checkWitness 1822 true true 4678 = true := by decide +kernel
private theorem cases1822 : checkFour 1822 (582,4678,582,4678) = true := by
  simp only [checkFour, w1822_0, w1822_1, w1822_2, w1822_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1822 : Coverage 1822 1823 := checkList_sound (ws:=[(582,4678,582,4678)]) (by simpa only [checkList, Bool.and_true] using cases1822)
private theorem w1823_0 : checkWitness 1823 false false 8887 = true := by decide +kernel
private theorem w1823_2 : checkWitness 1823 true false 8883 = true := by decide +kernel
private theorem cases1823 : checkFour 1823 (8887,0,8883,0) = true := by
  simp only [checkFour, w1823_0, w1823_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1823 : Coverage 1823 1824 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1823)
theorem cover1792 : Coverage 1792 1824 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1792 one1793) (Coverage.join one1794 one1795)) (Coverage.join (Coverage.join one1796 one1797) (Coverage.join one1798 one1799))) (Coverage.join (Coverage.join (Coverage.join one1800 one1801) (Coverage.join one1802 one1803)) (Coverage.join (Coverage.join one1804 one1805) (Coverage.join one1806 one1807)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1808 one1809) (Coverage.join one1810 one1811)) (Coverage.join (Coverage.join one1812 one1813) (Coverage.join one1814 one1815))) (Coverage.join (Coverage.join (Coverage.join one1816 one1817) (Coverage.join one1818 one1819)) (Coverage.join (Coverage.join one1820 one1821) (Coverage.join one1822 one1823)))))
end NF180PA.Symbolic
