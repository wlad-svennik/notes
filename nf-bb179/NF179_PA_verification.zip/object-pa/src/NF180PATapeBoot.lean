import NF180PAGate
import ModelStandard
import ScannerFrames


open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM PA192.PhysicalModel NF192.KernelBits

namespace NF180PA.Gate
set_option maxHeartbeats 2400000
set_option maxRecDepth 12000
set_option exponentiation.threshold 1024

def bootRight : Nat := Blank180.Boot.snap230892.bits >>> Blank180.Boot.snap230892.head
private abbrev endpoint := embed Blank180.Boot.width (-32) (fun _ => false) Blank180.Boot.snap230892

private theorem boot_rep : (Rays.mk (some (12 : Fin 179)) 1 bootRight).Rep endpoint := by
  refine ⟨rfl, ?_, ?_⟩
  · intro i
    by_cases small : i<512
    · have checked : ∀ j : Fin 512,
          endpoint.tape (endpoint.head + (j.val : Int)) = bootRight.testBit j.val := by decide +kernel
      exact checked ⟨i,small⟩
    · have headEq : endpoint.head = -10 := by decide
      rw [headEq]
      change tape 512 (-32) (fun _ => false) Blank180.Boot.snap230892.bits ((-10) + (i : Int)) = bootRight.testBit i
      have outside : ¬(0 ≤ -10 + (i : Int) - -32 ∧ -10 + (i : Int) - -32 < ((512:Nat):Int)) := by omega
      have below : bootRight < 2^512 := by decide +kernel
      have bigger : (2:Nat)^512 ≤ 2^i := Nat.pow_le_pow_right (by decide) (by omega)
      simp only [tape,outside,ite_false,Nat.testBit_lt_two_pow (below.trans_le bigger)]
  · intro i
    by_cases small : i<512
    · have checked : ∀ j : Fin 512,
          endpoint.tape (endpoint.head - ((j.val : Int) + 1)) = (1:Nat).testBit j.val := by decide +kernel
      exact checked ⟨i,small⟩
    · have headEq : endpoint.head = -10 := by decide
      rw [headEq]
      change tape 512 (-32) (fun _ => false) Blank180.Boot.snap230892.bits ((-10) - ((i : Int)+1)) = (1:Nat).testBit i
      have outside : ¬(0 ≤ -10 - ((i : Int)+1) - -32 ∧ -10 - ((i : Int)+1) - -32 < ((512:Nat):Int)) := by omega
      have below : (1 : Nat) < 2^i := Nat.one_lt_two_pow (by omega)
      simp only [tape,outside,ite_false,Nat.testBit_lt_two_pow below]

private theorem rep_unique {c : NF210.TM.Configuration 179} {a b : Rays 179}
    (ha : a.Rep c) (hb : b.Rep c) : a=b := by
  cases a with
  | mk q l p =>
    cases b with
    | mk r ll pp =>
      congr 1
      · exact ha.1.symm.trans hb.1
      · exact Nat.eq_of_testBit_eq fun i => (ha.2.2 i).symm.trans (hb.2.2 i)
      · exact Nat.eq_of_testBit_eq fun i => (ha.2.1 i).symm.trans (hb.2.1 i)

/-- The complete packed frame at the end of the original 233,734-step blank-tape startup. -/
theorem boot_rays : Rays.run machine start 230892 = ⟨some 12,1,bootRight⟩ := by
  apply rep_unique (c:=endpoint) _ boot_rep
  unfold endpoint
  have boot : NF210.TM.run machine 230892 (NF210.TM.blank start) = NF192.KernelBits.embed Blank180.Boot.width (-32) (fun _ => false) Blank180.Boot.snap230892 := by
    rw [← Blank180.Boot.start_snapshot]
    exact Blank180.Boot.prefix230892 _ _
  rw [← boot]
  exact Rays.rep_run machine start 230892

/-- The literal table starts its post-boot simulation with these exact tape
rays in every PA model. -/
theorem model_boot {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    rawRun machine start (230892 : V) = pack 12 1 (bootRight : V) := by
  rw [show (230892:V)=((230892:Nat):V) by norm_num,run_standard,boot_rays]
  simp [stdPack,PA192.LiteralTM.control]
end NF180PA.Gate
#print axioms NF180PA.Gate.model_boot
