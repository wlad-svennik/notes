import NF179LinksGroup00
import NF179LinksGroup01
import NF179LinksGroup02
import NF179LinksGroup03
import NF179LinksGroup04
import NF179LinksGroup05
import NF179LinksGroup06
import NF179LinksGroup07
import NF179LinksGroup08
import NF179LinksGroup09
import NF179LinksGroup10
import NF179LinksGroup11

namespace NF180PA.Links
theorem release_links : ∀ (p : Fin 2970) (c : Bool), allowed p.val (Blank180.Data.program p.val) c = true :=
  fun p => (Covers.join (Covers.join (Covers.join group0 (Covers.join group256 group512)) (Covers.join group768 (Covers.join group1024 group1280))) (Covers.join (Covers.join group1536 (Covers.join group1792 group2048)) (Covers.join group2304 (Covers.join group2560 group2816)))) p.val (Nat.zero_le _) p.isLt
#print axioms release_links
end NF180PA.Links
