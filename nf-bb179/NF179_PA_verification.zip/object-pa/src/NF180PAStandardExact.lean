import NF180PAModelSearchExact
import NF182PAPoolNat
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
open PA192.Literal

namespace NF180PA
/-- An actual blank-tape halt is equivalent to a finite, ordinary derivation of code 3. -/
theorem halts_iff_derivation : NF210.TM.Halts Blank180.Table.machine Blank180.Table.start ↔
    Moving186.Deriv 3 := by
  rw [←H180_standard,model_refutation,goal_three]
  exact (NF182PA.Pool.deriv_iff_pool 3).symm
end NF180PA
#print axioms NF180PA.halts_iff_derivation
