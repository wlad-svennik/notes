import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank180.Boot
open NF210 NF192 Blank180.Table
theorem chunk226800 : Prefix 700 snap226100 snap226800 := checked _ _ _ (by decide) (by decide)
theorem chunk227500 : Prefix 700 snap226800 snap227500 := checked _ _ _ (by decide) (by decide)
theorem chunk228200 : Prefix 700 snap227500 snap228200 := checked _ _ _ (by decide) (by decide)
theorem chunk228900 : Prefix 700 snap228200 snap228900 := checked _ _ _ (by decide) (by decide)
theorem chunk229600 : Prefix 700 snap228900 snap229600 := checked _ _ _ (by decide) (by decide)
theorem chunk230300 : Prefix 700 snap229600 snap230300 := checked _ _ _ (by decide) (by decide)
theorem chunk230892 : Prefix 592 snap230300 snap230892 := checked _ _ _ (by decide) (by decide)
end Blank180.Boot
