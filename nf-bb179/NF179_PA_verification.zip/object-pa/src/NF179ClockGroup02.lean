import NF179ClockBase
namespace NF180PA.Clock
set_option maxRecDepth 40000
set_option maxHeartbeats 0
private theorem part512 : Covers 512 528 := block_sound (lo:=512) (n:=16) (by decide +kernel)
private theorem part528 : Covers 528 544 := block_sound (lo:=528) (n:=16) (by decide +kernel)
private theorem part544 : Covers 544 560 := block_sound (lo:=544) (n:=16) (by decide +kernel)
private theorem part560 : Covers 560 576 := block_sound (lo:=560) (n:=16) (by decide +kernel)
private theorem part576 : Covers 576 592 := block_sound (lo:=576) (n:=16) (by decide +kernel)
private theorem part592 : Covers 592 608 := block_sound (lo:=592) (n:=16) (by decide +kernel)
private theorem part608 : Covers 608 624 := block_sound (lo:=608) (n:=16) (by decide +kernel)
private theorem part624 : Covers 624 640 := block_sound (lo:=624) (n:=16) (by decide +kernel)
private theorem part640 : Covers 640 656 := block_sound (lo:=640) (n:=16) (by decide +kernel)
private theorem part656 : Covers 656 672 := block_sound (lo:=656) (n:=16) (by decide +kernel)
private theorem part672 : Covers 672 688 := block_sound (lo:=672) (n:=16) (by decide +kernel)
private theorem part688 : Covers 688 704 := block_sound (lo:=688) (n:=16) (by decide +kernel)
private theorem part704 : Covers 704 720 := block_sound (lo:=704) (n:=16) (by decide +kernel)
private theorem part720 : Covers 720 736 := block_sound (lo:=720) (n:=16) (by decide +kernel)
private theorem part736 : Covers 736 752 := block_sound (lo:=736) (n:=16) (by decide +kernel)
private theorem part752 : Covers 752 768 := block_sound (lo:=752) (n:=16) (by decide +kernel)
theorem group512 : Covers 512 768 := (Covers.join (Covers.join (Covers.join (Covers.join part512 part528) (Covers.join part544 part560)) (Covers.join (Covers.join part576 part592) (Covers.join part608 part624))) (Covers.join (Covers.join (Covers.join part640 part656) (Covers.join part672 part688)) (Covers.join (Covers.join part704 part720) (Covers.join part736 part752))))
end NF180PA.Clock
