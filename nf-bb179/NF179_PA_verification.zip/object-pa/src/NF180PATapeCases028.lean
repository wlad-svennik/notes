import NF180PATapeBatchCheck
namespace NF180PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w896_0 : checkWitness 896 false false 644 = true := by decide +kernel
private theorem w896_1 : checkWitness 896 false true 4736 = true := by decide +kernel
private theorem w896_2 : checkWitness 896 true false 635 = true := by decide +kernel
private theorem w896_3 : checkWitness 896 true true 4727 = true := by decide +kernel
private theorem cases896 : checkFour 896 (644,4736,635,4727) = true := by
  simp only [checkFour, w896_0, w896_1, w896_2, w896_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one896 : Coverage 896 897 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases896)
private theorem w897_0 : checkWitness 897 false false 8895 = true := by decide +kernel
private theorem w897_2 : checkWitness 897 true false 8891 = true := by decide +kernel
private theorem cases897 : checkFour 897 (8895,0,8891,0) = true := by
  simp only [checkFour, w897_0, w897_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one897 : Coverage 897 898 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases897)
private theorem w898_0 : checkWitness 898 false false 638 = true := by decide +kernel
private theorem w898_1 : checkWitness 898 false true 4730 = true := by decide +kernel
private theorem w898_2 : checkWitness 898 true false 629 = true := by decide +kernel
private theorem w898_3 : checkWitness 898 true true 4721 = true := by decide +kernel
private theorem cases898 : checkFour 898 (638,4730,629,4721) = true := by
  simp only [checkFour, w898_0, w898_1, w898_2, w898_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one898 : Coverage 898 899 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases898)
private theorem w899_0 : checkWitness 899 false false 8866 = true := by decide +kernel
private theorem w899_2 : checkWitness 899 true false 8862 = true := by decide +kernel
private theorem cases899 : checkFour 899 (8866,0,8862,0) = true := by
  simp only [checkFour, w899_0, w899_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one899 : Coverage 899 900 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases899)
private theorem w900_0 : checkWitness 900 false false 90 = true := by decide +kernel
private theorem w900_2 : checkWitness 900 true false 90 = true := by decide +kernel
private theorem cases900 : checkFour 900 (90,0,90,0) = true := by
  simp only [checkFour, w900_0, w900_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one900 : Coverage 900 901 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases900)
private theorem w901_0 : checkWitness 901 false false 82 = true := by decide +kernel
private theorem w901_2 : checkWitness 901 true false 82 = true := by decide +kernel
private theorem cases901 : checkFour 901 (82,0,82,0) = true := by
  simp only [checkFour, w901_0, w901_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one901 : Coverage 901 902 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases901)
private theorem w902_0 : checkWitness 902 false false 591 = true := by decide +kernel
private theorem w902_1 : checkWitness 902 false true 4675 = true := by decide +kernel
private theorem w902_2 : checkWitness 902 true false 591 = true := by decide +kernel
private theorem w902_3 : checkWitness 902 true true 4675 = true := by decide +kernel
private theorem cases902 : checkFour 902 (591,4675,591,4675) = true := by
  simp only [checkFour, w902_0, w902_1, w902_2, w902_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one902 : Coverage 902 903 := checkList_sound (ws:=[(591,4675,591,4675)]) (by simpa only [checkList, Bool.and_true] using cases902)
private theorem w903_0 : checkWitness 903 false false 8858 = true := by decide +kernel
private theorem w903_2 : checkWitness 903 true false 8854 = true := by decide +kernel
private theorem cases903 : checkFour 903 (8858,0,8854,0) = true := by
  simp only [checkFour, w903_0, w903_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one903 : Coverage 903 904 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases903)
private theorem w904_0 : checkWitness 904 false false 82 = true := by decide +kernel
private theorem w904_2 : checkWitness 904 true false 82 = true := by decide +kernel
private theorem cases904 : checkFour 904 (82,0,82,0) = true := by
  simp only [checkFour, w904_0, w904_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one904 : Coverage 904 905 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases904)
private theorem w905_0 : checkWitness 905 false false 588 = true := by decide +kernel
private theorem w905_1 : checkWitness 905 false true 4684 = true := by decide +kernel
private theorem w905_2 : checkWitness 905 true false 588 = true := by decide +kernel
private theorem w905_3 : checkWitness 905 true true 4684 = true := by decide +kernel
private theorem cases905 : checkFour 905 (588,4684,588,4684) = true := by
  simp only [checkFour, w905_0, w905_1, w905_2, w905_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one905 : Coverage 905 906 := checkList_sound (ws:=[(588,4684,588,4684)]) (by simpa only [checkList, Bool.and_true] using cases905)
private theorem w906_0 : checkWitness 906 false false 8928 = true := by decide +kernel
private theorem w906_2 : checkWitness 906 true false 8919 = true := by decide +kernel
private theorem cases906 : checkFour 906 (8928,0,8919,0) = true := by
  simp only [checkFour, w906_0, w906_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one906 : Coverage 906 907 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases906)
private theorem w907_0 : checkWitness 907 false false 8874 = true := by decide +kernel
private theorem w907_2 : checkWitness 907 true false 8870 = true := by decide +kernel
private theorem cases907 : checkFour 907 (8874,0,8870,0) = true := by
  simp only [checkFour, w907_0, w907_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one907 : Coverage 907 908 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases907)
private theorem w908_0 : checkWitness 908 false false 90 = true := by decide +kernel
private theorem w908_2 : checkWitness 908 true false 90 = true := by decide +kernel
private theorem cases908 : checkFour 908 (90,0,90,0) = true := by
  simp only [checkFour, w908_0, w908_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one908 : Coverage 908 909 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases908)
private theorem w909_0 : checkWitness 909 false false 654 = true := by decide +kernel
private theorem w909_1 : checkWitness 909 false true 4742 = true := by decide +kernel
private theorem w909_2 : checkWitness 909 true false 645 = true := by decide +kernel
private theorem w909_3 : checkWitness 909 true true 4733 = true := by decide +kernel
private theorem cases909 : checkFour 909 (654,4742,645,4733) = true := by
  simp only [checkFour, w909_0, w909_1, w909_2, w909_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one909 : Coverage 909 910 := checkList_sound (ws:=[(654,4742,645,4733)]) (by simpa only [checkList, Bool.and_true] using cases909)
private theorem w910_0 : checkWitness 910 false false 8912 = true := by decide +kernel
private theorem w910_2 : checkWitness 910 true false 8908 = true := by decide +kernel
private theorem cases910 : checkFour 910 (8912,0,8908,0) = true := by
  simp only [checkFour, w910_0, w910_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one910 : Coverage 910 911 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases910)
private theorem w911_0 : checkWitness 911 false false 80 = true := by decide +kernel
private theorem w911_2 : checkWitness 911 true false 80 = true := by decide +kernel
private theorem cases911 : checkFour 911 (80,0,80,0) = true := by
  simp only [checkFour, w911_0, w911_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one911 : Coverage 911 912 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases911)
private theorem w912_0 : checkWitness 912 false false 494 = true := by decide +kernel
private theorem w912_1 : checkWitness 912 false true 4590 = true := by decide +kernel
private theorem w912_2 : checkWitness 912 true false 494 = true := by decide +kernel
private theorem w912_3 : checkWitness 912 true true 4590 = true := by decide +kernel
private theorem cases912 : checkFour 912 (494,4590,494,4590) = true := by
  simp only [checkFour, w912_0, w912_1, w912_2, w912_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one912 : Coverage 912 913 := checkList_sound (ws:=[(494,4590,494,4590)]) (by simpa only [checkList, Bool.and_true] using cases912)
private theorem w913_0 : checkWitness 913 false false 8897 = true := by decide +kernel
private theorem w913_2 : checkWitness 913 true false 8893 = true := by decide +kernel
private theorem cases913 : checkFour 913 (8897,0,8893,0) = true := by
  simp only [checkFour, w913_0, w913_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one913 : Coverage 913 914 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases913)
private theorem w914_0 : checkWitness 914 false false 626 = true := by decide +kernel
private theorem w914_1 : checkWitness 914 false true 4722 = true := by decide +kernel
private theorem w914_2 : checkWitness 914 true false 617 = true := by decide +kernel
private theorem w914_3 : checkWitness 914 true true 4713 = true := by decide +kernel
private theorem cases914 : checkFour 914 (626,4722,617,4713) = true := by
  simp only [checkFour, w914_0, w914_1, w914_2, w914_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one914 : Coverage 914 915 := checkList_sound (ws:=[(626,4722,617,4713)]) (by simpa only [checkList, Bool.and_true] using cases914)
private theorem w915_0 : checkWitness 915 false false 180 = true := by decide +kernel
private theorem w915_2 : checkWitness 915 true false 180 = true := by decide +kernel
private theorem cases915 : checkFour 915 (180,0,180,0) = true := by
  simp only [checkFour, w915_0, w915_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one915 : Coverage 915 916 := checkList_sound (ws:=[(180,0,180,0)]) (by simpa only [checkList, Bool.and_true] using cases915)
private theorem w916_0 : checkWitness 916 false false 575 = true := by decide +kernel
private theorem w916_1 : checkWitness 916 false true 4663 = true := by decide +kernel
private theorem w916_2 : checkWitness 916 true false 575 = true := by decide +kernel
private theorem w916_3 : checkWitness 916 true true 4663 = true := by decide +kernel
private theorem cases916 : checkFour 916 (575,4663,575,4663) = true := by
  simp only [checkFour, w916_0, w916_1, w916_2, w916_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one916 : Coverage 916 917 := checkList_sound (ws:=[(575,4663,575,4663)]) (by simpa only [checkList, Bool.and_true] using cases916)
private theorem w917_0 : checkWitness 917 false false 8908 = true := by decide +kernel
private theorem w917_2 : checkWitness 917 true false 8899 = true := by decide +kernel
private theorem cases917 : checkFour 917 (8908,0,8899,0) = true := by
  simp only [checkFour, w917_0, w917_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one917 : Coverage 917 918 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases917)
private theorem w918_0 : checkWitness 918 false false 84 = true := by decide +kernel
private theorem w918_2 : checkWitness 918 true false 84 = true := by decide +kernel
private theorem cases918 : checkFour 918 (84,0,84,0) = true := by
  simp only [checkFour, w918_0, w918_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one918 : Coverage 918 919 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases918)
private theorem w919_0 : checkWitness 919 false false 76 = true := by decide +kernel
private theorem w919_2 : checkWitness 919 true false 76 = true := by decide +kernel
private theorem cases919 : checkFour 919 (76,0,76,0) = true := by
  simp only [checkFour, w919_0, w919_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one919 : Coverage 919 920 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases919)
private theorem w920_0 : checkWitness 920 false false 575 = true := by decide +kernel
private theorem w920_1 : checkWitness 920 false true 4667 = true := by decide +kernel
private theorem w920_2 : checkWitness 920 true false 575 = true := by decide +kernel
private theorem w920_3 : checkWitness 920 true true 4667 = true := by decide +kernel
private theorem cases920 : checkFour 920 (575,4667,575,4667) = true := by
  simp only [checkFour, w920_0, w920_1, w920_2, w920_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one920 : Coverage 920 921 := checkList_sound (ws:=[(575,4667,575,4667)]) (by simpa only [checkList, Bool.and_true] using cases920)
private theorem w921_0 : checkWitness 921 false false 8850 = true := by decide +kernel
private theorem w921_2 : checkWitness 921 true false 8846 = true := by decide +kernel
private theorem cases921 : checkFour 921 (8850,0,8846,0) = true := by
  simp only [checkFour, w921_0, w921_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one921 : Coverage 921 922 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases921)
private theorem w922_0 : checkWitness 922 false false 76 = true := by decide +kernel
private theorem w922_2 : checkWitness 922 true false 76 = true := by decide +kernel
private theorem cases922 : checkFour 922 (76,0,76,0) = true := by
  simp only [checkFour, w922_0, w922_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one922 : Coverage 922 923 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases922)
private theorem w923_0 : checkWitness 923 false false 534 = true := by decide +kernel
private theorem w923_1 : checkWitness 923 false true 4630 = true := by decide +kernel
private theorem w923_2 : checkWitness 923 true false 534 = true := by decide +kernel
private theorem w923_3 : checkWitness 923 true true 4630 = true := by decide +kernel
private theorem cases923 : checkFour 923 (534,4630,534,4630) = true := by
  simp only [checkFour, w923_0, w923_1, w923_2, w923_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one923 : Coverage 923 924 := checkList_sound (ws:=[(534,4630,534,4630)]) (by simpa only [checkList, Bool.and_true] using cases923)
private theorem w924_0 : checkWitness 924 false false 8885 = true := by decide +kernel
private theorem w924_2 : checkWitness 924 true false 8881 = true := by decide +kernel
private theorem cases924 : checkFour 924 (8885,0,8881,0) = true := by
  simp only [checkFour, w924_0, w924_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one924 : Coverage 924 925 := checkList_sound (ws:=[(8885,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases924)
private theorem w925_0 : checkWitness 925 false false 8916 = true := by decide +kernel
private theorem w925_2 : checkWitness 925 true false 8907 = true := by decide +kernel
private theorem cases925 : checkFour 925 (8916,0,8907,0) = true := by
  simp only [checkFour, w925_0, w925_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one925 : Coverage 925 926 := checkList_sound (ws:=[(8916,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases925)
private theorem w926_0 : checkWitness 926 false false 94 = true := by decide +kernel
private theorem w926_2 : checkWitness 926 true false 94 = true := by decide +kernel
private theorem cases926 : checkFour 926 (94,0,94,0) = true := by
  simp only [checkFour, w926_0, w926_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one926 : Coverage 926 927 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases926)
private theorem w927_0 : checkWitness 927 false false 630 = true := by decide +kernel
private theorem w927_1 : checkWitness 927 false true 4722 = true := by decide +kernel
private theorem w927_2 : checkWitness 927 true false 621 = true := by decide +kernel
private theorem w927_3 : checkWitness 927 true true 4713 = true := by decide +kernel
private theorem cases927 : checkFour 927 (630,4722,621,4713) = true := by
  simp only [checkFour, w927_0, w927_1, w927_2, w927_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one927 : Coverage 927 928 := checkList_sound (ws:=[(630,4722,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases927)
theorem cover0896 : Coverage 896 928 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one896 one897) (Coverage.join one898 one899)) (Coverage.join (Coverage.join one900 one901) (Coverage.join one902 one903))) (Coverage.join (Coverage.join (Coverage.join one904 one905) (Coverage.join one906 one907)) (Coverage.join (Coverage.join one908 one909) (Coverage.join one910 one911)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one912 one913) (Coverage.join one914 one915)) (Coverage.join (Coverage.join one916 one917) (Coverage.join one918 one919))) (Coverage.join (Coverage.join (Coverage.join one920 one921) (Coverage.join one922 one923)) (Coverage.join (Coverage.join one924 one925) (Coverage.join one926 one927)))))
end NF180PA.Symbolic
