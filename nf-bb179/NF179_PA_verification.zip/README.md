# A 179-state binary Turing machine for pure NF

The machine halts from a blank tape exactly when pure Quine New Foundations proves falsum. It has 179 working states, two tape symbols and one separate halt state. The head starts in `k:74` on an all-zero, two-way infinite tape. Exactly one of the 358 transitions goes to halt.

## What saved the state

Two old decoder states enter immediately after a right move. One incoming transition writes 0 and the other writes 1. Their common handler can step left and use that bit to distinguish the two continuations. Existing controls can then perform the remaining operations. Removing `d:17` and `d:21` and adding `new:1` saves one working state.

The release table was found by searching for states that could share different register-decoder paths and rejoin the same physical configuration after different numbers of steps. Its register program is byte-for-byte identical to the published 180-state program. The archive also contains a second 179-state table that isolates the saving in five changed rows of surviving states. Its independent checks and exact edits are under `discovery/`. The primary receipts below apply to `NF179.tm`.

## Verification

| Check | Result for the primary table |
| --- | --- |
| Transition graph | All 179 working states reachable from the start in the transition graph. One halting transition, from `k:302` on 1. |
| Actual blank run | At tick 230,892 the machine first reaches the epoch-5 checkpoint used in the proof. The source address is zero, all eight other registers are zero, the head is at −10, the address gap is 97 and there are 78 spare cells. Lean verified the entire blank-tape prefix and the complete checkpoint. |
| Source and physical execution | All 2,970 source instructions have the same addresses, operations and operands as the published machine. The independent Lean reference kernel accepted all 7,792 signed branch theorems. The traces use 20 induction rules for arbitrary tape repetitions. |
| Independent concrete replay | 142,544 complete successor-tape comparisons and 16 halting fixtures across 94,093,082 binary transitions. |
| PA witness calculation | All 7,792 witnesses passed in Lean's executable checker. Of the witness integers for the published table, 5,800 changed. |

From the epoch-5 checkpoint both machines execute the same register proof search. For each source step, the physical simulation preserves the entire encoded register frame and implements the specified halt branch. Consequently the counterexample search has the same standard halting criterion as for the published 180-state machine.

## Peano arithmetic

The end-to-end Lean audit establishes the pure-NF halting criterion, its arbitrary-model calibration and conditional PA independence for the literal 179-state machine. The machine-specific proof source and a rebuild driver are under `object-pa/`. The older 180 names inside that isolated project preserve the predecessor's module interface. The new public declarations use `NF179` and the underlying state type is `Fin 179`. The exact table, proof statuses and hashes appear in `evidence/status.json`.

## Replay

Use Python 3 and an ordinary C++17 compiler for the physical replay. Put Lean 4.35.0 and its `leanchecker-paranoid` binary on PATH for kernel verification.

```sh
python3 verify.py --examples
python3 verify.py --kernel --jobs 2
python3 object-pa/replay.py --jobs 2
```

The last command builds the candidate-specific PA theorem and its audit from the bundled pinned foundation using Lake dependencies. It requires more time and memory than the ordinary table replay.

**Literal table SHA-256** `36c19b11e2b4c854ae41919cfd7cfc5be5a20f3846453da2e9099798e5edfee3`

**Register source SHA-256** `7bacb7672e2df5f580588cc493b52c62bb0574de94c3a374d28e07195beccd47`

[Published 180-state source and proof](https://github.com/wlad-svennik/notes/tree/87440d0dc4a281caa4a32dd4165838ae9a35a0b0/nf-bb180)
