# Physical verification of the 198-state NF + CS register machine

The binary table has 198 graph-reachable working states, 396 transitions, and a single halt transition. Its initial state is `k:64`. The exact table digest is `243ef9d4db45311377fc200b0205855ae24946b62505777f9e746f868e1459bb`; the 4,366-instruction register source has digest `a3e512b0f9886a6230f22634a7ec84a2a4b9d7aa8ec0dd001219023cf86c820a`.

Starting from an all-zero two-way tape, the Lean theorem `Blank198.Boot.blank_margin_frame` gives the complete configuration at step 75,040. It encodes register instruction zero, register 0 equal to three, eight zero registers, address gap 49, 31 spare pairs and all-zero exterior rays. Lean also verifies the earlier complete checkpoint at step 41,652.

The raw branch export contains 11,442 signed cases and 20 induction rules for unbounded tape runs. The independent binding checker compares all 5,722 warm statements to the register source and verifies the unique terminal case. Each signed branch takes at least 24 literal binary steps. The book-keeping for warm frames preserves nonnegative registers, never decreases the address gap or spare count, and leaves the exterior rays zero. An instruction reaching a live endpoint cannot have halted earlier because a halted configuration remains halted. These checks concern the literal machine’s register execution. The mathematical correspondence between the register proof search and NF + CS is a separate part of the argument.

The original 199-state source has a register-4 increment at instruction 3838. This version removes it before the last extensionality row. The checker verifies every retained opcode and source successor against the released parent, in addition to the two changes to batch input and exit control.

## Replay

From the extracted directory, the following commands verify the table bindings and source edits:

```sh
python3 check_binding.py
python3 check_source.py Original199.sites.json source.sites.json candidate.tm
```

To regenerate the 17,464 concrete cases use `python3 screen.py`. To rebuild the blank proofs and all signed proofs with Lean 4.35.0 and its `leanchecker-paranoid` executable on PATH:

```sh
bash boot/compile.sh
python3 physical/symbolic_frames.py . --write /tmp/cs198-signed.gz
python3 physical/check_all.py . /tmp/cs198-signed.gz /tmp/cs198-replay.json --chunk 120 --jobs 2
```

The compressed new trace should match `traces.gz` byte for byte. The resulting receipt should match `kernel.json`.
