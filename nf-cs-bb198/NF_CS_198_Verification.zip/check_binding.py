"""Audit the 198-state NF+CS candidate table, both blank checkpoints and all warm macro statements.

Run python3 check_binding.py [EXTRACTED_DIRECTORY]. Omit the directory when
this script is placed next to candidate.tm. All comparisons enable ordinary
Python exceptions, including when invoked with -O.
"""
import argparse
from bisect import bisect_left
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import sys

TABLE_SHA = "243ef9d4db45311377fc200b0205855ae24946b62505777f9e746f868e1459bb"
SOURCE_SHA = "a3e512b0f9886a6230f22634a7ec84a2a4b9d7aa8ec0dd001219023cf86c820a"
FIELD_ORDER = (2, 8, 1, 4, 3, 7, 0, 5, 6)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def read_table(directory):
    data = (directory / "candidate.tm").read_bytes()
    require(sha(data) == TABLE_SHA, "published table digest")
    header, *lines = data.decode("ascii").splitlines(keepends=True)
    require(header == "#! start k:64\n", "blank starting state")
    table = {}
    for line in lines:
        q, r, w, move, dest = line.split()
        require((q, int(r)) not in table, "duplicate transition")
        table[q, int(r)] = int(w), (1 if move == "R" else -1), dest
    require(len(table) == 396, "complete 198-state table")
    lean = (directory / "boot/Blank198Table.lean").read_text()
    parts = re.findall(r"^def raw\d+ : List String := (\[.*\])$", lean, re.M)
    require([v for part in parts for v in json.loads(part)] == lines, "Lean literal rows")
    names = json.loads(re.search(r"^def names : Array String := #(\[.*\])$", lean, re.M)[1])
    require(names == sorted({state for state, bit in table}), "common state numbering")
    require(names[int(re.search(r"def start : State := (\d+)", lean)[1])] == "k:64", "Lean start")
    frames = (directory / "boot/ScannerFrames.lean").read_text()
    root = int(re.search(r"def decoderRoot : State := (\d+)", frames)[1])
    require(names[root] == "d:0", "Lean decoder root")
    halt_arms = {key for key, action in table.items() if action[2] == "halt"}
    require(halt_arms == {("k:302", 1)}, "unique physical halt arm")
    return table


def replay_blank(table, record, path):
    checkpoints = {record[key]["step"]: record[key] for key in ("warm_anchor", "final")}
    require(set(checkpoints) == {41652, 75040}, "blank checkpoint times")
    q, head, ones = "k:64", 0, set()
    for tick in range(1, max(checkpoints) + 1):
        require(q != "halt", f"early blank halt at tick {tick-1}")
        w, step, q = table[q, int(head in ones)]
        if w:
            ones.add(head)
        else:
            ones.discard(head)
        head += step
        if tick in checkpoints:
            item = checkpoints[tick]
            require(q == item["state"] == "d:0" and head == item["head"]
                    and sorted(ones) == item["ones"], f"full blank configuration at {tick}")
    regs = [3] + [0] * 8
    word = "1" + path + "0" * (49 - len(path)) + "1"
    word += "".join("0" + "1" * (2 + regs[r]) for r in FIELD_ORDER)
    word += "01" * 31
    expected = {head - 1 + j for j, cell in enumerate(word) if cell == "1"}
    require(ones == expected and path == "0000", "complete warm PC0 input word and zero exterior")


def replay_pumps(table, pumps):
    """Each repeated local sweep stays inside its word and returns to a live state."""
    names = sorted({q for q, bit in table})
    require(len(pumps) == 20, "physical sweep count")
    for i, pump in enumerate(pumps):
        context, unit = pump["context"], pump["unit"]
        cells = list(context + unit)
        pos = len(context)
        start = names[pump["q"]]
        q = start
        for _ in range(pump["ticks"]):
            require(q != "halt" and 0 <= pos < len(cells), f"sweep {i} prefix")
            w, move, q = table[q, int(cells[pos])]
            cells[pos] = str(w)
            pos += move * pump["dir"]
        require(pos == len(cells) and q == start and "".join(cells) == pump["output"] + context,
                f"sweep {i} endpoint")


def source_successor(pc, row, zero, paths):
    """Independently use the lexicographic interval of a prefix in the complete code."""
    address, op, index = row
    if op == "CD" and zero and address.endswith("1"):
        return None, False
    if op in ("CI", "CD") and not (op == "CD" and zero):
        after = pc + 1
    else:
        bit = "1" if op == "CC" else "0"
        prefix = address
        for _ in range(1 if op == "CD" else index):
            edge = prefix.rfind(bit)
            require(edge >= 0, f"invalid {op} jump at PC {pc}")
            prefix = prefix[:edge]
        if op == "CC":
            return bisect_left(paths, prefix), False
        after = bisect_left(paths, prefix + "2")
    return after % len(paths), after == len(paths)


def frame_tokens(address, regs, extra_gap=0, extra_spares=0):
    """Register (n, free) denotes n or n+x_r. Gap and spare powers are independent."""
    word = [*address, *("0" * (49 + extra_gap - len(address))), (9, "0"), "1"]
    for r in FIELD_ORDER:
        n, free = regs[r]
        word.append("0")
        if free:
            word.append((r, "1"))
        word.extend("1" * (n + 2))
    word.append((10, "01"))
    word.extend("01" * (24 + extra_spares))
    return word


def canonical(ray):
    """Move each variable power left over complete identical fixed words."""
    parts, literal = [], []
    for token in ray:
        if isinstance(token, str):
            literal.append(token)
            continue
        _, unit = token
        before = "".join(literal)
        cut = len(before)
        while cut >= len(unit) and before.startswith(unit, cut - len(unit), cut):
            cut -= len(unit)
        parts.extend((before[:cut], token))
        literal = [before[cut:]]
    parts.append("".join(literal))
    return parts


def warm_statements(directory):
    # Use the same statement constructor as the export. Compare it to the
    # independent interval decoder and bit layout above for every warm branch.
    os.environ["NF_TABLE"] = str(directory / "candidate.tm")
    os.environ["NF_TRACES"] = str(directory / "traces.gz")
    sys.path.insert(0, str(directory / "physical"))
    # symbolic_frames reads a single directory argument during import.
    old_argv = sys.argv
    try:
        sys.argv = [old_argv[0], str(directory)]
        import kernel_branches
    finally:
        sys.argv = old_argv
    return kernel_branches


def compare_rays(exported, word, left_padding, right_padding, module, where):
    right, left = exported
    require(left == ("1",) + ("0",) * left_padding + (module.A,), f"{where}: left ray")
    require(right[-1] == module.B, f"{where}: right ray tail")
    require(canonical(right[:-1]) == canonical(word + ["0"] * right_padding),
            f"{where}: right ray word")


def check_branches(directory, program, trace):
    module = warm_statements(directory)
    paths = [row[0] for row in program]
    require(paths == sorted(paths), "lexicographic source addresses")
    require(trace["base_gap"] == 49, "base address gap")
    expected = {(pc, cold, zero) for pc, (_, op, r) in enumerate(program)
                for cold in (False, True) if not (cold and op == "CD" and r == 0)
                for zero in ((False, True) if op == "CD" else (False,))}
    observed = Counter((b["pc"], b["cold"], b["zero"]) for b in trace["traces"])
    require(len(expected) == 11442 and set(observed) == expected and max(observed.values()) == 1,
            "signed branch coverage")
    minimum = None
    warm = terminal = 0
    for branch in trace["traces"]:
        pc = branch["pc"]
        actions = branch["actions"]
        clock = branch["clock"]
        literal_ticks = sum(a for a in actions if a > 0)
        require(len(clock) == 12 and min(clock) >= 0 and clock[0] == literal_ticks > 0,
                f"positive elapsed time at PC {pc}")
        minimum = literal_ticks if minimum is None else min(literal_ticks, minimum)
        if branch["cold"]:
            continue
        zero = branch["zero"]
        path, op, r = program[pc]
        regs = [(0, True)] * 9
        if op == "CD":
            regs[r] = (0, False) if zero else (1, True)
        inp, out = module.branch_shape(branch)
        compare_rays(inp, frame_tokens(path, regs), module.PAD_L, module.PAD_R, module, f"PC {pc} input")
        dest, shift = source_successor(pc, program[pc], zero, paths)
        require(module.discover.transfer(pc, zero) == (dest, shift), f"source successor at PC {pc}")
        warm += 1
        if dest is None:
            require(out is None, f"terminal statement at PC {pc}")
            terminal += 1
            continue
        require(out is not None, f"live statement at PC {pc}")
        increment, decrement = op == "CI", op == "CD" and not zero
        if increment or decrement:
            n, free = regs[r]
            regs[r] = (n + 1 if increment else n - 1, free)
            require(regs[r][0] >= 0, f"warm register underflow at PC {pc}")
        word = frame_tokens(paths[dest], regs, int(decrement) + int(shift), int(increment))
        compare_rays(out, word, module.PAD_L - int(shift), module.PAD_R - 3 * int(increment),
                     module, f"PC {pc} successor")
    return warm, terminal, minimum


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path, nargs="?", default=Path(__file__).resolve().parent)
    directory = parser.parse_args().directory.resolve()
    table = read_table(directory)
    source = (directory / "source.sites.json").read_bytes()
    require(sha(source) == SOURCE_SHA, "published program digest")
    program = json.loads(source)
    trace_bytes = (directory / "traces.gz").read_bytes()
    trace = json.loads(gzip.decompress(trace_bytes))
    boot, kernel = read_json(directory / "bootstrap.json"), read_json(directory / "kernel.json")
    require(boot["table_sha256"] == kernel["table"] == trace["table"] == TABLE_SHA, "table binding")
    require(boot["source_sha256"] == kernel["source"] == trace["source"] == SOURCE_SHA, "program binding")
    require(kernel["trace_sha256"] == sha(trace_bytes), "kernel receipt and trace binding")
    replay_blank(table, boot, program[0][0])
    replay_pumps(table, trace["pumps"])
    warm, terminal, minimum = check_branches(directory, program, trace)
    require(terminal == 1, "unique warm terminal branch")
    print("Both complete blank checkpoints match. At tick 75040 the tape is the warm PC0 input.")
    print(f"All {warm} warm macro statements match the source, including its unique terminal branch.")
    print("All 20 repeated local sweeps return to a live state without an intervening halt.")
    print(f"Each of the 11442 signed traces includes at least {minimum} literal binary steps.")


if __name__ == "__main__":
    main()
