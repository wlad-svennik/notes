"""Verify the archived files and recheck the bindings at each machine boundary."""
from hashlib import sha256
from pathlib import Path
import json, subprocess, sys
if not __debug__:
    raise RuntimeError('Run Python without -O so the certificate checks are enabled.')
root=Path(__file__).resolve().parent
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    if sha256((root/name).read_bytes()).hexdigest()!=digest:
        raise ValueError('Hash mismatch in '+name)
subprocess.run([sys.executable,root/'check_binding.py'],cwd=root,check=True)
parent=root/'Original199.sites.json'
subprocess.run([sys.executable,root/'check_source.py',parent,root/'source.sites.json',root/'candidate.tm'],cwd=root,check=True)
subprocess.run([sys.executable,root/'scanner/check_source.py',root,parent],cwd=root,check=True)
pins=json.loads((root/'logic/source-sha256.json').read_bytes())
for module,digest in pins.items():
    text=(root/'logic/src'/Path(*module.split('.')).with_suffix('.lean')).read_bytes()
    if sha256(text).hexdigest()!=digest:raise ValueError('Lean source digest mismatch in '+module)
for module in ['Unshifted198Calibration','CS198MarkerReplay','CS198PhysicalRows','CS198GlobalBudget','CS198GroundBinding']:
    assert module in pins,module
print(f'Checked {len(pins)} pinned logical source modules and the packaged machine receipts.')
