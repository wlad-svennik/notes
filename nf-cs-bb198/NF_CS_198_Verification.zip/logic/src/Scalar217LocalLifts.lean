module
public import Scalar217Model
@[expose] public section
namespace CS217
open NF192 NF192.Numerical

/-- An entirely algebraic formulation of the local-lift property. Only u and v
are represented maps; the pointwise operation x ↦ {x} need not be a global row. -/
def HasLocalReadLifts {M : Type u} (A : NormalizedBasis M) : Prop :=
  ∀ u v, (∀ t, A.app v (A.app u t) = A.K (A.app u (A.app v (A.app t A.q)))) →
    ∃ w, ∀ x, A.app u (A.app v x) = x → A.app (A.app w x) A.q = x

theorem probes_iff_local_read_lifts {M : Type u} (A : NormalizedBasis M) : HasProbes A ↔ HasLocalReadLifts A := by
  classical
  constructor
  · intro h u v he
    obtain ⟨w,hw⟩ := h u v
    exact ⟨w,fun x hx => hw x hx (he w)⟩
  · intro h u v
    by_cases equal : ∀ t, A.app v (A.app u t) = A.K (A.app u (A.app v (A.app t A.q)))
    · obtain ⟨w,hw⟩ := h u v equal
      exact ⟨w,fun x hx _ => hw x hx⟩
    · obtain ⟨w,hw⟩ := Classical.not_forall.mp equal
      exact ⟨w,fun _ _ hbad => (hw hbad).elim⟩

theorem not_deriv_iff_local_read_lift_basis : ¬ Deriv goal ↔ ∃ M : Type, ∃ A : NormalizedBasis M, HasLocalReadLifts A := by
  rw [not_deriv_iff_probe_basis]
  exact exists_congr (fun _ => exists_congr fun A => probes_iff_local_read_lifts A)

end CS217
#print axioms CS217.not_deriv_iff_local_read_lift_basis
