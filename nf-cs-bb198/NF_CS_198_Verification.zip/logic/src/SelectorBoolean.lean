module
public import SelectorAbstraction
public import FiniteMenuProbe
@[expose] public section
set_option autoImplicit false
namespace SelectorBoolean
open NF192 PointPatch SelectorAbstraction
universe u
variable {M : Type u} {γ : Nat → Nat} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app
local notation "T" => A.K A.B
def bc {i : Nat} (f : Tm M γ (i+2)) (g : Tm M γ (i+1)) : Tm M γ (i+1) :=
  .app (.app (.par A.B (i+3)) f) g
def rc {i : Nat} (f : Tm M γ (i+2)) (c : Tm M γ i) : Tm M γ (i+1) := bc A f (.k c)
def single {i : Nat} (x : Tm M γ i) : Tm M γ (i+1) := .app (.par A.q (i+2)) (.k x)
def eqT {i : Nat} (x y : Tm M γ i) : Tm M γ i := .app (single A x) y
def patchT {i : Nat} (f : Tm M γ (i+1)) (a y : Tm M γ i) : Tm M γ (i+1) :=
  let p := single A (.k (.k (.k (.k (.k a)))))
  let c1 := rc A p (.k (.k (.k f)))
  let c2 := rc A c1 (.k (.k (.k y)))
  let c3 := rc A c2 (.par A.B (i+2))
  let c4 := rc A c3 (.par A.B (i+1))
  bc A c4 (.par (ident A) (i+1))
theorem vsingle {i : Nat} (e : Nat → M) (x : Tm M γ i) :
    val A e (single A x)=delta A (val A e x) := by simp only [single,vapp,vpar,vk,delta]
theorem vEq {i : Nat} (e : Nat → M) (x y : Tm M γ i) : val A e (eqT A x y)=delta A (val A e x) ⬝ val A e y := by
  simp only [eqT,vapp,vsingle]
theorem vpatch {i : Nat} (e : Nat → M) (f : Tm M γ (i+1)) (a y : Tm M γ i) :
    val A e (patchT A f a y)=patch A (val A e f) (val A e a) (val A e y) := by
  simp only [patchT,bc,rc,vsingle,vk,vapp,vpar,patch,choose,rightConstant]

def bt {i : Nat} (z : Tm M γ i) : Tm M γ (i+4) := single A (.k (.k (.k z)))
def st {i : Nat} (z : Tm M γ i) : Tm M γ (i+5) :=
  let b:=bt A z
  let B0 : Tm M γ (i+4) := .par A.B (i+4)
  let s1 := patchT A (.k b) B0 B0
  let s2 := patchT A s1 (.par T (i+4)) B0
  let s3 := patchT A s2 (.par (A.K T) (i+4)) B0
  patchT A s3 b B0
theorem vbt {i : Nat} (e : Nat → M) (z : Tm M γ i) : val A e (bt A z)=FiniteMenuProbe.beta A (val A e z) := by
  simp only [bt,vsingle,vk,FiniteMenuProbe.beta,ShiftedFork.S,ShiftedFork.Y]
theorem vst {i : Nat} (e : Nat → M) (z : Tm M γ i) : val A e (st A z)=FiniteMenuProbe.row A (val A e z) := by
  simp only [st,vpatch,vbt,vk,vpar,FiniteMenuProbe.row]

def Truth (p : M) (P : Prop) : Prop := (P → p=T) ∧ (¬P → p=A.B)
theorem truth_iff {p : M} {P : Prop} (hp : Truth A p P) : p=T ↔ P := by
  refine ⟨?_,hp.1⟩
  intro e; apply Classical.byContradiction; intro hn; exact A.distinct (e.symm.trans (hp.2 hn))
theorem false_iff {p : M} {P : Prop} (hp : Truth A p P) : p=A.B ↔ ¬P := by
  refine ⟨?_,hp.2⟩
  intro e h; exact A.distinct ((hp.1 h).symm.trans e)
theorem eqBool (x y : M) : Truth A (delta A x ⬝ y) (x=y) := by
  constructor
  · intro e; subst y; exact same A _
  · intro ne; exact diff A (Ne.symm ne)
def nT {i : Nat} (p : Tm M γ i) : Tm M γ i := eqT A (.par A.B i) p
theorem negOk {i : Nat} (e : Nat → M) (p : Tm M γ i) {P : Prop} (hp : Truth A (val A e p) P) :
    Truth A (val A e (nT A p)) (¬P) := by
  simp only [nT,vEq,vpar]
  constructor
  · intro h; rw [hp.2 h,same]
  · intro h; have yes : P := Classical.byContradiction h
    rw [hp.1 yes]; exact diff A A.distinct

def andT {i : Nat} (p q : Tm M γ i) : Tm M γ i :=
  .app (patchT A (.par (A.K A.B) (i+1)) (.par T i) q) p
theorem andOk {i : Nat} (e : Nat → M) (p q : Tm M γ i) {P Q : Prop}
    (hp : Truth A (val A e p) P) (hq : Truth A (val A e q) Q) :
    Truth A (val A e (andT A p q)) (P ∧ Q) := by
  simp only [andT,vapp,vpatch,vpar]
  constructor
  · rintro ⟨p0,q0⟩; rw [hp.1 p0,patch_at,hq.1 q0]
  · intro h; by_cases p0 : P
    · rw [hp.1 p0,patch_at,hq.2 (fun q0 => h ⟨p0,q0⟩)]
    · rw [hp.2 p0,patch_away A _ _ _ _ (Ne.symm A.distinct),A.k_app]

def low {i : Nat} (p : Tm M γ (i+1)) : Tm M γ i :=
  eqT A (.par A.B i) (.app p (.par A.q i))
theorem lowOk {i : Nat} (e : Nat → M) (p : Tm M γ (i+1)) {P : Prop} (hp : Truth A (val A e p) P) :
    Truth A (val A e (low A p)) P := by
  simp only [low,vEq,vapp,vpar]
  constructor
  · intro h; rw [hp.1 h,A.k_app,same]
  · intro h; rw [hp.2 h,RawSuffix.bq]; exact diff A (q_ne_b A)

def exT {i : Nat} (p : Tm M (cons i γ) i) : Tm M γ (i+1) :=
 nT A (eqT A (.par (A.K A.B) (i+1)) (.lam p))
theorem exOk {i : Nat} (e : Nat → M) (p : Tm M (cons i γ) i) {P : M → Prop}
    (hp : ∀ y, Truth A (val A (cons y e) p) (P y)) :
    Truth A (val A e (exT A p)) (∃y,P y) := by
  have eq : A.K A.B=val A e (.lam p) ↔ ¬∃y,P y := by
    constructor
    · rintro h ⟨y,hy⟩
      have atY := congrArg (fun a => a ⬝ y) h
      rw [A.k_app,vlam,(hp y).1 hy] at atY
      exact A.distinct atY.symm
    · intro no; apply A.ext; intro y
      rw [A.k_app,vlam,(hp y).2 (fun hy => no ⟨y,hy⟩)]
  have h : Truth A (val A e (eqT A (.par (A.K A.B) (i+1)) (.lam p))) (¬∃y,P y) := by
    simp only [vEq,vpar]
    exact ⟨fun n => (eqBool A _ _).1 (eq.mpr n),fun nn => (eqBool A _ _).2 (fun he => nn (eq.mp he))⟩
  have nn := negOk A e _ h
  exact ⟨fun yes => nn.1 (fun no => no yes),fun no => nn.2 (fun yes => yes no)⟩
end SelectorBoolean
#print axioms SelectorBoolean.vst
#print axioms SelectorBoolean.exOk
