import CS198RowDefs
namespace CS198.Scanner
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers
set_option maxRecDepth 100000
set_option maxHeartbeats 350000


def prefixCode := sequence .push3 FirstCS.preTokens.tail
def finalCode := Code.seq (sequence .push0 FirstCS.frontTokens.tail) (sequence .imp tokens9)
def batchCode := Code.seq prefixCode finalCode

private theorem prefix_parts (first : Macro) (xs ops : List Macro) (e : ops = first :: xs) (f : Frame) :
    Eval (sequence first xs) f.regs .normal (ops.foldl Frame.apply f).regs := by
  subst ops
  exact sequence_eval first xs f

private theorem prefix_run (f : Frame) : Eval prefixCode f.regs .normal (FirstCS.preTokens.foldl Frame.apply f).regs :=
  prefix_parts .push3 FirstCS.preTokens.tail FirstCS.preTokens rfl f

private theorem suffix_parts (first : Macro) (xs ops : List Macro) (e : ops = first :: xs) (f : Frame) :
    Eval (.seq (sequence first xs) (sequence .imp tokens9)) f.regs .normal
      (tokens9.foldl Frame.apply ((ops.foldl Frame.apply f).apply .imp)).regs := by
  subst ops
  exact Eval.seq_normal (sequence_eval first xs f) (sequence_eval .imp tokens9 (xs.foldl Frame.apply (f.apply first)))

private theorem suffix_run (f : Frame) : Eval finalCode f.regs .normal
    (tokens9.foldl Frame.apply (FirstCS.strengthTokens.foldl Frame.apply f)).regs := by
  have decomp : FirstCS.strengthTokens = FirstCS.frontTokens ++ [.imp] := rfl
  rw [decomp,List.foldl_append]
  exact suffix_parts .push0 FirstCS.frontTokens.tail FirstCS.frontTokens rfl f

/-- No .read5 input, no first-coordinate increment, one genuine .read4 field.
The first eight formulas include the entire CS strength schema. -/
theorem batch_eval (n t st c u b d tail : Nat) :
    Eval batchCode (Frame.regs ⟨n,t,st,c,u,b,pair d tail⟩) .normal
      (save ⟨n,t,st,c,u+d,b,tail⟩ (physicalRows (u+d) b c u)).regs := by
  let f : Frame := ⟨n,t,st,c,u,b,pair d tail⟩
  have h := Eval.seq_normal (prefix_run f) (suffix_run (FirstCS.preTokens.foldl Frame.apply f))
  simp only [FirstCS.preTokens,List.foldl_append,f] at h
  rw [C196.logicalEffect, effect4, Eight187.Seed.effectB, effect2, effect3, effect6,
    Eight187.Seed.effectTest, FirstCS.strength_effect,effect9] at h
  exact h
end CS198.Scanner
#print axioms CS198.Scanner.batch_eval
