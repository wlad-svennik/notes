module
public import NumericalModel
public import NumericalAxioms
@[expose] public section
namespace RangeCS
open NF192 NF192.Numerical NF192.Ground NF192.Emitter
universe u
variable {M : Type u}
def R (A : NormalizedBasis M) (s x : M) := A.app s (A.K x)
def P (A : NormalizedBasis M) (s x : M) := A.app s (A.app (A.app x A.q) A.q)
def Clause (A : NormalizedBasis M) (s w : M) :=
  R A s (P A s (R A s (A.app s w))) = A.app s w →
    ∀ x, A.app (A.app w x) A.q = A.app s x
def HasProbes (A : NormalizedBasis M) := ∀ s, ∃ w, Clause A s w

def Wcode (a : Nat) := witness s (konst a)
def rawR (a x : Nat) := app a (konst x)
def rawP (a x : Nat) := app a (app (app x q) q)
def rule (a x : Nat) : Nat :=
  let w := Wcode a
  let b := app a w
  imp (eqn (rawR a (rawP a (rawR a b))) b) (eqn (app (app w x) q) (app a x))
def rowList (a b c u : Nat) : List Nat :=
  [row0 a b c u,row1 a b,row2 a b c,row4 a b,row3 a b c,row5 a b c,
   row6 a b c,row7 a b,row9 a b,rule a b]
def RowsHold (r : Nat → Nat → Prop) : Prop :=
  ∀ a b c u, u ≤ a → ∀ y ∈ rowList a b c u, evaluate r y

private theorem instantiate {r} (h : RowsHold r) (a b c : Nat) {y : Nat}
    (hy : y ∈ rowList a b c 0) : evaluate r y := h _ _ _ _ (Nat.zero_le _) _ hy

set_option maxHeartbeats 1200000 in
theorem core {r} (h : RowsHold r) : Ground.Rows AsSignature r := by
  have positive (a b) := instantiate h a b 0 (y:=row1 a b) (by simp [rowList])
  have ar (a b c) := instantiate h a b c (y:=row2 a b c) (by simp [rowList])
  have kl (a b) := instantiate h a b 0 (y:=row4 a b) (by simp [rowList])
  have fl (a b c) := instantiate h a b c (y:=row3 a b c) (by simp [rowList])
  have bl (a b c) := instantiate h a b c (y:=row5 a b c) (by simp [rowList])
  have eu (a b c) := instantiate h a b c (y:=row6 a b c) (by simp [rowList])
  have ng (a b) := instantiate h a b 0 (y:=row7 a b) (by simp [rowList])
  have ex (a b) := instantiate h a b 0 (y:=row9 a b) (by simp [rowList])
  simp only [row1,row2,row4,row3,row5,row6,row7,row9,goal,evaluate_imp,evaluate_eqn] at *
  exact ⟨positive,ar,kl,fl,bl,eu,ng,ex⟩

private theorem lower {r} (h : RowsHold r) (hg : ¬r s q) : HasProbes ((core h).toBasis hg) := by
  let H := core h
  intro s0
  refine Quotient.inductionOn s0 ?_
  intro si
  let w := Wcode si
  refine ⟨H.obj w,?_⟩
  intro activation x
  refine Quotient.inductionOn x ?_
  intro xi
  have rr := instantiate h si xi 0 (y:=rule si xi) (by simp [rowList])
  simp only [rule,evaluate_imp,evaluate_eqn] at rr
  exact H.obj_eq_iff.mpr (rr (H.obj_eq_iff.mp activation))

section Evals
open Classical in
noncomputable def valueT (A : NormalizedBasis M) (W : M → M) : Term → M
  | .q => A.q
  | .app a b => A.app (valueT A W a) (valueT A W b)
  | .h (.app .q .q) (.h a b) =>
      if a = b then W (valueT A W a) else
        Interpretation.witness A (A.app A.q A.q)
          (valueT A W (.h a b))
  | .h a b => Interpretation.witness A (valueT A W a) (valueT A W b)

variable (A : NormalizedBasis M) (W : M → M)
noncomputable def value (i : Nat) := valueT A W (decodeTerm i)
theorem valq : value A W q = A.q := by simp [value,valueT]
theorem vala (a b : Nat) : value A W (app a b) = A.app (value A W a) (value A W b) := by simp [value,valueT]

theorem constT (a : Term) : valueT A W (.h a a) = A.K (valueT A W a) := by
  cases a with
  | q => exact Interpretation.witness_diag A _
  | h a b => exact Interpretation.witness_diag A _
  | app a b =>
    cases a <;> cases b <;> exact Interpretation.witness_diag A _

theorem valk (a : Nat) : value A W (konst a) = A.K (value A W a) := by
  simpa only [konst,value,decodeTerm_witness] using constT A W (decodeTerm a)

theorem valw (a : Nat) : value A W (Wcode a) = W (value A W a) := by
  simp [Wcode,konst,s,value,valueT]

theorem extT (a b : Term) :
    A.app (valueT A W b) (valueT A W (.h a b)) =
    A.app (valueT A W a) (valueT A W (.h a b)) → valueT A W a = valueT A W b := by
  cases a with
  | q => exact Interpretation.witness_ext A _ _
  | h a b => exact Interpretation.witness_ext A _ _
  | app a1 a2 =>
    cases a1 <;> cases a2
    all_goals try exact Interpretation.witness_ext A _ _
    cases b with
    | q => exact Interpretation.witness_ext A _ _
    | app a b => exact Interpretation.witness_ext A _ _
    | h d e =>
      by_cases same : d=e
      · subst e
        rw [constT]
        change A.app (A.K (valueT A W d)) _ = A.app (A.app A.q A.q) _ →
          A.app A.q A.q = A.K (valueT A W d)
        rw [A.qq_eq_kb,A.k_app,A.k_app]
        exact fun h => congrArg A.K h.symm
      · have ordinary : valueT A W (.h (.app .q .q) (.h d e)) =
            Interpretation.witness A (valueT A W (.app .q .q)) (valueT A W (.h d e)) := by
          simp [valueT,same]
        rw [ordinary]; exact Interpretation.witness_ext A _ _

theorem vale (a b : Nat) :
    A.app (value A W b) (value A W (witness a b)) =
    A.app (value A W a) (value A W (witness a b)) → value A W a = value A W b := by
  simpa only [value,decodeTerm_witness] using extT A W (decodeTerm a) (decodeTerm b)

set_option maxHeartbeats 2000000 in
theorem valid (h : ∀ s, Clause A s (W s)) : RowsHold (fun a b => value A W a = value A W b) := by
  intro a b c u hu y hy
  simp only [rowList,List.mem_cons,List.not_mem_nil,or_false] at hy
  rcases hy with hh|hh|hh|hh|hh|hh|hh|hh|hh|hh <;> subst y
  · simp only [row0,evaluate_imp]
    intro ca ac _
    by_cases e : evaluate (fun a b => value A W a = value A W b) c
    · exact e
    · exact ac (ca (fun h => (e h).elim))
  all_goals simp only [row1,row2,row4,row3,row5,row6,row7,row9,rule,rawR,rawP,
      evaluate_imp,evaluate_eqn,goal,B,s,vala,valk,valw,valq,A.qq_eq_kb,A.k_app]
  · intro he; exact (A.q_true _ _ he).symm
  · intro he; rw [he]
  · intro he; rw [he]
  · exact A.b_app _ _ _
  · intro h1 h2; exact h2.symm.trans h1
  · intro h; exact (A.q_false _ _ (fun e => A.qq_ne_q (A.qq_eq_kb.trans (h e)))).symm
  · exact vale A W _ _
  · exact fun on => h _ on _
end Evals

theorem countermodel_iff : (∃ r, RowsHold r ∧ ¬r s q) ↔ ∃ M : Type, ∃ A : NormalizedBasis M, HasProbes A := by
  constructor
  · rintro ⟨r,h,hg⟩
    exact ⟨(core h).Carrier,(core h).toBasis hg,lower h hg⟩
  · rintro ⟨M,A,h⟩
    let W := fun a => Classical.choose (h a)
    refine ⟨fun a b => value A W a = value A W b,valid A W (fun a => Classical.choose_spec (h a)),?_⟩
    simpa only [s,vala,valq] using A.qq_ne_q
end RangeCS
#print axioms RangeCS.countermodel_iff
