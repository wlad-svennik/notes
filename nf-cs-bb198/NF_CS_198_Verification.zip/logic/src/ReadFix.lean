module
public import CountSet
public import NormalizedToComb
public import CombModelCore
public import Scalar217LocalLifts
@[expose] public section


set_option autoImplicit false
namespace FFL.FirstOrder.FNF.CountSet
open JensenNFU.TFm (scons)
noncomputable section
variable {M : Type} [Tarski.Structure ℒλ M] [Tarski.Structure.Eq ℒλ M] [Nonempty M]
  [M↓[ℒλ] ⊧* 𝗙𝗡𝗙]
local infixl:70 " ⬝ " => App
def FixedSets (q : M) : Prop := ∀ u v,
  (∀ t z, ((v ⬝ (u ⬝ t)) ⬝ z) = u ⬝ (v ⬝ (t ⬝ q))) →
  ∃ d : M, IsSet d ∧ (∀ x, Mem x d ↔ u ⬝ (v ⬝ x) = x) ∧ Strong d

private theorem directLiftGraph (d j q : M) : ∃ g : M, IsSet g ∧ ∀ p,
    Mem p g ↔ ∃ x y w t, p = kp x y ∧ Mem x d ∧ j ⬝ x = w ∧ w ⬝ q = t ∧ y = sing t := by
  exact (BT.ex (Γ := [3,2,2,0]) 1 (BT.ex 1 (BT.ex 1 (BT.ex 0 ((kpB.sub [4,3,2] 1).and
   ((BT.mem 3 5 1 rfl rfl).and ((BT.app 6 3 1 1 rfl rfl rfl).and
    ((BT.app 1 7 0 0 rfl rfl rfl).and (singB.sub [2,0] 0))))))))).set (scons d (scons j (fun _ => q)))

theorem strongFix (q u v w : M) (lift : ∀ x, u ⬝ (v ⬝ x) = x → (w ⬝ x) ⬝ q = x) :
    ∃ d : M, IsSet d ∧ (∀ x, Mem x d ↔ u ⬝ (v ⬝ x) = x) ∧ Strong d := by
  obtain ⟨d,hd,h⟩ := (BT.ex (Γ:=[0,1,1]) 0 ((BT.app 3 1 0 0 rfl rfl rfl).and
    (BT.app 2 0 1 0 rfl rfl rfl))).set (scons u (fun _ => v))
  have fixed (x : M) : Mem x d ↔ u ⬝ (v ⬝ x) = x := by
    change Mem x d ↔ _
    have eq : Mem x d ↔ ∃ z, v ⬝ x = z ∧ u ⬝ z = x := h x
    simpa using eq
  obtain ⟨g,hg,gg⟩ := directLiftGraph d w q
  refine ⟨d,hd,fixed,g,hg,fun p => ?_⟩
  rw [gg]
  constructor
  · rintro ⟨x,y,_,_,pair,hx,rfl,rfl,rfl⟩
    exact ⟨x,hx,by simpa only [lift x ((fixed x).mp hx)] using pair⟩
  · rintro ⟨x,hx,rfl⟩
    exact ⟨x,sing x,w ⬝ x,x,rfl,hx,rfl,lift x ((fixed x).mp hx),rfl⟩
end
end FFL.FirstOrder.FNF.CountSet

namespace DirectNFU
open FFL FFL.FirstOrder
def HasFixedSetModel : Prop :=
  ∃ W : Type, ∃ nW : Nonempty W, letI := nW
  ∃ s : Tarski.Structure ℒλ W, letI := s
  ∃ t : Tarski.Structure.Eq ℒλ W, letI := t
  ∃ h : W↓[ℒλ] ⊧* 𝗙𝗡𝗙, letI := h
  ∃ q : W, FNF.CountSet.FixedSets q

theorem from_algebra {V : Type} (A : NF192.NormalizedBasis V) (lifts : CS217.HasLocalReadLifts A) :
    HasFixedSetModel := by
  letI : Nonempty V := ⟨A.B⟩
  letI : Tarski.Structure ℒᴄ V := A.combStructure
  letI : Tarski.Structure.Eq ℒᴄ V := ⟨fun _ _ => Iff.rfl⟩
  letI : V↓[ℒᴄ] ⊧* 𝗖𝗡𝗙 := CNF.models_of
    A.k_app A.b_app A.archiveQ_true A.archiveQ_false (fun _ _ h => A.ext h) A.b_ne_bb
  let W := CNFOnly.fnOfComb.Model V
  letI : W↓[ℒλ] ⊧* 𝗙𝗡𝗙 := CNFOnly.fnModel_models
  let Q : W := CNFOnly.toModel A.q
  have app (a b : W) : ((FNF.App a b : W) : V) = A.app (a : V) (b : V) := (CNFOnly.app_iff a b _).mp rfl
  have convert (t : V) : ((CNFOnly.toModel t : W) : V) = t := rfl
  have coeQ : (Q : V) = A.q := rfl
  refine ⟨W,inferInstance,inferInstance,inferInstance,inferInstance,Q,?_⟩
  intro u v guard
  obtain ⟨w,lift⟩ := lifts (u : V) (v : V) (by
    intro t
    apply A.ext
    intro z
    rw [A.k_app]
    have g := congrArg (fun a : W => (a : V)) (guard (CNFOnly.toModel t) (CNFOnly.toModel z))
    simpa only [app,coeQ,convert] using g)
  let w' : W := CNFOnly.toModel w
  apply FNF.CountSet.strongFix Q u v w'
  intro x hx
  apply CNFOnly.coe_inj
  have fix' : A.app (u : V) (A.app (v : V) (x : V)) = (x : V) := by
    simpa only [app] using congrArg (fun t : W => (t : V)) hx
  simp only [app,coeQ]
  change A.app (A.app w (x : V)) A.q = _
  exact lift (x : V) fix'
end DirectNFU
#print axioms DirectNFU.from_algebra
