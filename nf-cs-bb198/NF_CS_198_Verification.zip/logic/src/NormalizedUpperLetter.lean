module
public import SelectorBoolean
@[expose] public section
set_option autoImplicit false
namespace NativeWeakJ
open NF192 PointPatch SelectorAbstraction SelectorBoolean
universe u
variable {M : Type u} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app
local notation "T" => A.K A.B
def raw : Nat → Nat := fun _ => 0
abbrev g := cons 1 raw
def input : Tm M g 1 := .var g 0
def body : Tm M g 1 :=
  let z : Tm M g 1 := input
  let isConstant := eqT A z (.k (.app z (.par A.q 0)))
  let replacement := Tm.app (.par A.q 2) z
  .app (patchT A (.par (A.K A.B) 2) (.par T 1) replacement) isConstant
def namedJ : M := val A (fun _ => A.q) (Tm.lam (γ:=raw) (body A))
def Const (z : M) := ∃ a, z=A.K a
theorem at_arg (z : M) : namedJ A ⬝ z =
    patch A (A.K A.B) T (A.q ⬝ z) ⬝ (delta A z ⬝ A.K (z ⬝ A.q)) := by
  rw [namedJ,vlam]
  let e := cons z (fun _ : Nat => A.q)
  let zt : Tm M g 1 := input
  let read : Tm M g 0 := .app zt (.par A.q 0)
  let chk := eqT A zt (.k read)
  let repl : Tm M g 1 := .app (.par A.q 2) zt
  change (val A e (patchT A (.par (A.K A.B) 2) (.par T 1) repl)) ⬝ val A e chk=_
  rw [vpatch A e (.par (A.K A.B) 2) (.par T 1) repl]
  change patch A (A.K A.B) T (A.q ⬝ z) ⬝ val A e chk=_
  apply congrArg (A.app (patch A (A.K A.B) T (A.q ⬝ z)))
  exact (vEq A e zt (.k read)).trans (congrArg (A.app (delta A z)) (vk A e read))
theorem constant (a : M) : namedJ A ⬝ A.K a = delta A a := by
  rw [at_arg,A.k_app,same,patch_at]; rfl
theorem other (z : M) (outside : ¬Const A z) : namedJ A ⬝ z=A.B := by
  have e : A.K (z ⬝ A.q)≠z := fun eq => outside ⟨_,eq.symm⟩
  rw [at_arg,diff A e,patch_away A _ _ _ _ (Ne.symm A.distinct),A.k_app]
theorem j_not_constant : ¬Const A (namedJ A) := by
  rintro ⟨a,eq⟩
  have h (x : M) : delta A x=a := (constant A x).symm.trans
    ((congrArg (fun k=>k ⬝ A.K x) eq).trans (A.k_app _ _))
  exact A.distinct (delta_inj A ((h T).trans (h A.B).symm))
theorem jj : namedJ A ⬝ namedJ A=A.B := other A _ (j_not_constant A)
theorem j_ne_B : namedJ A ≠ A.B := by
  intro eq
  have h := congrArg (fun v => v ⬝ A.K (A.K A.q)) eq
  rw [constant,b_fixes_kk] at h
  exact delta_not_constant A _ _ h
theorem Bj : A.B ⬝ namedJ A=A.q := by
  apply A.ext; intro f; apply A.ext; intro x
  rw [A.b_app,constant]
  by_cases eq : f ⬝ x=x
  · rw [eq,same,A.q_true _ _ eq]
  · rw [diff A eq,A.q_false _ _ eq]
theorem no_K_range (z a : M) : namedJ A ⬝ z≠A.K a := by
  by_cases inK : Const A z
  · obtain ⟨v,rfl⟩ := inK; rw [constant]; exact delta_not_constant A _ _
  · rw [other A z inK]; exact CalibratedSlots.b_not_constant A a

theorem false_iff (a b : M) : namedJ A ⬝ A.K a ⬝ b=A.B ↔ a≠b := by
  rw [constant]
  constructor
  · intro eq he; subst b; exact A.distinct ((same A a).symm.trans eq)
  · exact fun ne => diff A (Ne.symm ne)

/-- The three surviving codes and all semantic corner identities are produced
by one explicit stratified term over the original normalized algebra. -/
theorem upper : ∃ j : M, j ⬝ j=A.B ∧ A.B ⬝ j=A.q ∧ j≠A.B ∧
    (∀ a b, j ⬝ A.K a ⬝ b=A.B ↔ a≠b) ∧ ∀ z a, j ⬝ z≠A.K a :=
  ⟨namedJ A,jj A,Bj A,j_ne_B A,false_iff A,no_K_range A⟩


end NativeWeakJ
#print axioms NativeWeakJ.upper
