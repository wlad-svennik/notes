import FirstCSRows
import MarkerEnumeration

namespace CS198.Scanner
open NF192.Numerical

/-- The phase machinery has one free numerical parameter for a final row.
Pair the actual additive first coordinate with the final rank coordinate. -/
def testRow (b p : Nat) : Nat := FirstCS.strength (Cantor.unpair p).2 (Cantor.unpair p).1 b

theorem testRow_literal (b a c : Nat) : testRow b (pair a c) = FirstCS.strength c a b := by
  simp [testRow,Cantor.unpair_pair]

private theorem twice_pair_ge_square (x y : Nat) : (x+y)^2 ≤ 2*pair x y := by
  unfold pair
  generalize x+y=n
  cases n with
  | zero => simp
  | succ m => simp only [Nat.pow_succ,Nat.pow_zero,Nat.one_mul,Nat.add_mul,Nat.mul_add,Nat.one_mul,Nat.mul_one]; omega

private theorem ls (x y : Nat) : x^2 ≤ imp x y :=
  (Nat.le_trans (Nat.pow_le_pow_left (Nat.le_add_right x y) 2) (twice_pair_ge_square x y))
private theorem rs (x y : Nat) : y^2 ≤ imp x y :=
  (Nat.le_trans (Nat.pow_le_pow_left (Nat.le_add_left y x) 2) (twice_pair_ge_square x y))
private theorem al (x y : Nat) : x ≤ app x y := (Nat.le_trans (imp_ge_left _ _) (Nat.le_succ _))
private theorem ar (x y : Nat) : y ≤ app x y := (Nat.le_trans (imp_ge_right _ _) (Nat.le_succ _))
private theorem wl (x y : Nat) : x ≤ witness x y := (Nat.le_trans (imp_ge_left _ _) (Nat.le_add_right _ 2))

theorem marker_grows_raw (a b c : Nat) : (pair a c)^16 ≤ FirstCS.strength c a b := by
  let p := pair a c
  let z := app a c
  let k := witness z z
  let v := app (app (app a k) a) a
  let x := app a v
  have hz : p ≤ z := by dsimp [p,z,app]; omega
  have h₁ : p^2 ≤ k := (Nat.le_trans (Nat.pow_le_pow_left hz 2) ((Nat.le_trans (ls z z) (Nat.le_add_right _ 2))))
  have h₂ : (p^2)^2 ≤ app a k := (Nat.le_trans (Nat.pow_le_pow_left h₁ 2) ((Nat.le_trans (rs a k) (Nat.le_succ _))))
  have h₃ : ((p^2)^2)^2 ≤ app (app a k) a := (Nat.le_trans (Nat.pow_le_pow_left h₂ 2) ((Nat.le_trans (ls _ a) (Nat.le_succ _))))
  have h₄ : (((p^2)^2)^2)^2 ≤ v := (Nat.le_trans (Nat.pow_le_pow_left h₃ 2) ((Nat.le_trans (ls _ a) (Nat.le_succ _))))
  have hx : p^16 ≤ x := by simpa only [← Nat.pow_mul] using (Nat.le_trans h₄ (ar a v))
  exact (Nat.le_trans hx ((Nat.le_trans (wl x x) ((Nat.le_trans (ar a _) ((Nat.le_trans (ar z _) ((Nat.le_trans (imp_ge_left _ _) (imp_ge_right _ _))))))))))

theorem marker_grows (b p : Nat) : p^16 ≤ testRow b p := by
  have h := marker_grows_raw (Cantor.unpair p).1 b (Cantor.unpair p).2
  simpa only [testRow,Cantor.pair_unpair] using h

theorem marker_double (b p : Nat) : 2*b ≤ testRow b p := by
  let c := (Cantor.unpair p).2
  let a := (Cantor.unpair p).1
  have hl : 2*b ≤ app a b := by unfold app; have := pair_ge_right a b; omega
  exact (Nat.le_trans hl ((Nat.le_trans (ar (app (app c b) a) (app a b)) ((Nat.le_trans (imp_ge_right _ _) (imp_ge_right _ _))))))

private theorem imp_mono {a b c d : Nat} (x : a ≤ c) (y : b ≤ d) : imp a b ≤ imp c d := by
  unfold imp; apply Nat.mul_le_mul_left
  simp only [Cantor.pair_eq]; exact Nat.add_le_add (Cantor.triangle_mono (Nat.add_le_add x y)) y

theorem fresh_mark_small (b p : Nat) : 22 ≤ testRow b p := by
  let a := (Cantor.unpair p).1
  let c := (Cantor.unpair p).2
  have ha : 1 ≤ app 0 a := by unfold app; omega
  have hw : witness 0 1 ≤ witness 0 (app 0 a) := Nat.add_le_add_right (imp_mono (Nat.le_refl _) ha) 2
  have h : app (witness 0 1) 0 ≤ app (witness 0 (app 0 a)) c := Nat.succ_le_succ (imp_mono hw (Nat.zero_le c))
  have hl : 22 ≤ app (witness 0 1) 0 := by decide
  exact (Nat.le_trans hl ((Nat.le_trans h (imp_ge_left _ _))))
end CS198.Scanner
#print axioms CS198.Scanner.marker_grows
#print axioms CS198.Scanner.marker_double
#print axioms CS198.Scanner.fresh_mark_small
