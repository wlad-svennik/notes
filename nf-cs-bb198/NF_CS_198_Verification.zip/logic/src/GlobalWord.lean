module
public import SplitRangeModel
@[expose] public section
namespace GlobalWord
open NF192
universe u
variable {M : Type u} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app

def comp (f g : M) := A.B ⬝ A.K f ⬝ g
def readK (r : M) := A.B ⬝ A.B ⬝ A.K (A.K r)
def down (r f : M) := A.B ⬝ f ⬝ A.K r
def up (r f : M) := comp A (A.B ⬝ A.K f) (readK A r)
def global (dual : Bool) (r f : M) :=
  if dual then comp A f (comp A (down A r f) (comp A (up A r f) f))
  else comp A f (comp A (up A r f) (comp A (down A r f) f))

theorem comp_apply (f g x : M) : comp A f g ⬝ x = f ⬝ (g ⬝ x) := by
  simp only [comp,A.b_app,A.k_app]
theorem readK_apply (r t : M) : readK A r ⬝ t = A.K (t ⬝ r) := by
  apply A.ext; intro x
  simp only [readK,A.b_app,A.k_app]
theorem down_apply (r f t : M) : down A r f ⬝ t = f ⬝ A.K t ⬝ r := by
  simp only [down,A.b_app,A.k_app]
theorem up_apply (r f t : M) : up A r f ⬝ t = A.K (f ⬝ (t ⬝ r)) := by
  apply A.ext; intro x
  simp only [up,comp_apply,readK_apply,A.b_app,A.k_app]

theorem global_apply (dual : Bool) (f t : M) :
    global A dual A.q f ⬝ t = SplitRange.word dual A f t := by
  cases dual <;> simp only [global,Bool.false_eq_true,ite_false,ite_true,
    SplitRange.word,RangeCS.R,RangeCS.P,RawSuffix.L,RawSuffix.D,
    comp_apply,down_apply,up_apply]

theorem global_iff (dual : Bool) (f : M) :
    global A dual A.q f = f ↔ ∀ t, SplitRange.word dual A f t = f ⬝ t := by
  constructor
  · intro h t; rw [←global_apply,h]
  · intro h; apply A.ext; intro t; rw [global_apply,h]

theorem global_clause_iff (dual : Bool) :
    SplitRange.HasProbes dual A ↔
      ∀ f, ∃ w, global A dual A.q f = f → ∀ x, w ⬝ x ⬝ A.q = f ⬝ x := by
  constructor
  · intro h f
    obtain ⟨w,hw⟩ := h f
    exact ⟨w,fun eq => hw ((global_iff A _ _).mp eq w)⟩
  · intro h f
    classical
    by_cases eq : global A dual A.q f = f
    · obtain ⟨w,hw⟩ := h f
      exact ⟨w,fun _ => hw eq⟩
    · have ex : ∃ w, ¬ SplitRange.word dual A f w = f ⬝ w := by
        apply Classical.byContradiction
        intro none
        exact eq ((global_iff A _ _).mpr (fun w => Classical.byContradiction (fun bad => none ⟨w,bad⟩)))
      obtain ⟨w,bad⟩ := ex
      exact ⟨w,fun on => (bad on).elim⟩
end GlobalWord
#print axioms GlobalWord.global_clause_iff
