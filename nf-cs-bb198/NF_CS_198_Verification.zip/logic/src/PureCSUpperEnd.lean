import ExplicitWitness
import NormalizedUpperLetter
import Scope209ChartExact
import ShortCSRegisterBridge
open Classical FFL FFL.FirstOrder FFL.FirstOrder.SetTheory
open NFFn NFFn.NF188Finite
namespace NFCS.Pure
noncomputable section
variable {V : Type} [SetStructure V] [Nonempty V] [V↓[ℒₛₑₜ] ⊧* 𝗡𝗙]
theorem chart_of_model (cs : CS V) : ∃ A : Scope209.Upper.Chart V, Scope209.Upper.LocalLaw A := by
  obtain ⟨N,appEq,kEq,_⟩ := NFCS.Upper.normalized_full_chart V
  obtain ⟨j,jj,_,prop,theta,_⟩ := NativeWeakJ.upper N
  have sep (a b : V) : ∃ z, N.app b z = N.app a z → a=b := by
    classical
    by_cases he : a=b
    · exact ⟨j,fun _ => he⟩
    · have diff : ∃ z, N.app b z ≠ N.app a z := by
        by_contra h
        exact he (N.ext (fun z => Eq.symm (Classical.byContradiction fun e => h ⟨z,e⟩)))
      obtain ⟨z,hz⟩ := diff
      exact ⟨z,fun h => False.elim (hz h)⟩
  let A : Scope209.Upper.Chart V := {
    J:=j, B:=N.B, app:=N.app, K:=N.K, witness:=fun a b => Classical.choose (sep a b),
    k_app:=N.k_app, b_app:=N.b_app, letter:=jj, proper:=prop.symm,
    off:=fun x y ne => (theta x y).mpr ne, on:=fun x e => (theta x x).mp e rfl,
    witness_ext:=fun a b => Classical.choose_spec (sep a b) }
  refine ⟨A,?_⟩
  change ∀ s, ∃ w, RPRCore.Law N.app N.K s s w id
  rw [appEq,kEq]
  exact localLaw cs

theorem nonderiv_of_model (cs : CS V) : ¬ Scope209.Deriv NF192.Numerical.goal :=
  Scope209.nonderivable_iff_chart_exists.mpr ⟨V,chart_of_model cs⟩

theorem source201_nonhalting_of_model (cs : CS V) :
    ¬ ∃ n, ShortCS.Raw.advance n ShortCSRegisterBridge.warmOrigin = NF192.Source.Config.halted := by
  exact (not_congr ShortCSRegisterBridge.source_halts_iff_original).mpr (nonderiv_of_model cs)
end
end NFCS.Pure
#print axioms NFCS.Pure.source201_nonhalting_of_model
