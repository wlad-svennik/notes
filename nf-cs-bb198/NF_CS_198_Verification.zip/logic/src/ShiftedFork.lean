module
public import NoUniformSelector
public import SemanticSlots
@[expose] public section
namespace ShiftedFork
open NF192 PointPatch
universe l
variable {M : Type l} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app
local notation "T" => A.K A.B

def Y (z : M) := A.K (A.K (A.K z))
def S (z : M) := delta A (Y A z)
def three (a : M) := a ⬝ A.q ⬝ A.q ⬝ A.q
def sample (j z : M) := j ⬝ A.K (S A z)
def H0 (j z t : M) := let w:=sample A j z; w ⬝ A.q ⬝ A.q ≠ A.B ∧ t=three A w
def H1 (j z t : M) := let w:=sample A j z; w ⬝ A.q ⬝ A.q = A.B ∧
  ∃ a, w ⬝ a ⬝ A.q = T ∧ t=three A a
def H2 (j z t : M) := H0 A j z t ∨ ∃ b, H1 A j z b ∧ H1 A j b t

theorem yq (z : M) : A.q ≠ Y A z := q_not_const A _
theorem byes (z : M) : A.B ≠ Y A z := CalibratedSlots.b_not_constant A _
theorem tyes (z : M) : T ≠ Y A z :=
  fun e => CalibratedSlots.b_not_constant A _ (A.k_inj e)
theorem ktyes (z : M) : A.K T ≠ Y A z :=
  fun e => CalibratedSlots.b_not_constant A _ (A.k_inj (A.k_inj e))
theorem two_y (z : M) : Y A z ⬝ A.q ⬝ A.q = A.K z := by simp only [Y,A.k_app]
theorem three_y (z : M) : three A (Y A z)=z := by simp only [three,Y,A.k_app]
theorem bool (z t : M) : S A z ⬝ t=T ∨ S A z ⬝ t=A.B := test_boolean A _ _
theorem rq (z : M) {t : M} (b : t=T ∨ t=A.B) : RangeCS.R A (S A z) t=A.B := by
  rcases b with e|e
  · subst t; exact diff A (ktyes A z)
  · subst t; exact diff A (tyes A z)
theorem lq (z : M) {t : M} (b : t=T ∨ t=A.B) : RawSuffix.L A (S A z) t=A.B := by
  rcases b with e|e
  · subst t; change delta A (Y A z) ⬝ (T ⬝ A.q)=A.B
    rw [A.k_app]; exact diff A (byes A z)
  · subst t; change delta A (Y A z) ⬝ (A.B ⬝ A.q)=A.B
    rw [RawSuffix.bq]; exact diff A (yq A z)

theorem wordB (dual : Bool) (z w : M) : SplitRange.word dual A (S A z) w=A.B := by
  cases dual
  · exact rq A z (bool A z _)
  · exact lq A z (bool A z _)

theorem fork (dual : Bool) (z w : M) (rule : SplitRange.Clause dual A (S A z) w) :
    w=Y A z ∨ SemanticSlots.Lift A (S A z) w := by
  by_cases eq : w=Y A z
  · exact Or.inl eq
  · exact Or.inr (rule ((wordB A dual z w).trans (diff A eq).symm))


theorem h0_iff (dual : Bool) (j : M) (rule : ∀ s : M, SplitRange.Clause dual A s (A.app j (A.K s))) (z t : M) : H0 A j z t ↔ sample A j z ⬝ A.q ⬝ A.q ≠ A.B ∧ t=z := by
  rcases fork A dual z (sample A j z) (rule (S A z)) with eq|hl
  · simp only [H0,eq,three_y]
  · have h := (hl A.q).trans (diff A (yq A z))
    simp [H0,h]

theorem h1_iff (dual : Bool) (j : M) (rule : ∀ s : M, SplitRange.Clause dual A s (A.app j (A.K s))) (z t : M) : H1 A j z t ↔ sample A j z ⬝ A.q ⬝ A.q=A.B ∧ t=z := by
  rcases fork A dual z (sample A j z) (rule (S A z)) with eq|hl
  · have bad : sample A j z ⬝ A.q ⬝ A.q ≠ A.B := by rw [eq,two_y]; exact Ne.symm (CalibratedSlots.b_not_constant A _)
    simp [H1,bad]
  · have h := (hl A.q).trans (diff A (yq A z))
    constructor
    · rintro ⟨_,a,ha,ht⟩
      have eq : a=Y A z := by
        apply Classical.byContradiction; intro ne
        exact A.distinct (ha.symm.trans ((hl a).trans (diff A ne)))
      exact ⟨h,ht.trans (eq ▸ three_y A z)⟩
    · rintro ⟨_,ht⟩
      exact ⟨h,Y A z,(hl _).trans (same A _),ht.trans (three_y A z).symm⟩

theorem h2_iff (dual : Bool) (j : M) (rule : ∀ s : M, SplitRange.Clause dual A s (A.app j (A.K s))) (z t : M) : H2 A j z t ↔ t=z := by
  simp only [H2,h0_iff A dual j rule,h1_iff A dual j rule]
  constructor
  · rintro (⟨_,eq⟩|⟨b,⟨_,eq⟩,⟨_,eq'⟩⟩)
    · exact eq
    · exact eq'.trans eq
  · intro eq
    by_cases e : sample A j z ⬝ A.q ⬝ A.q=A.B
    · exact Or.inr ⟨z,⟨e,rfl⟩,⟨e,eq⟩⟩
    · exact Or.inl ⟨e,eq⟩

/-- This is the final contradiction once stratified characteristic
comprehension is applied to the displayed two-grade formula. -/
theorem contradicts_comprehension (dual : Bool) (j : M) (rule : ∀ s : M, SplitRange.Clause dual A s (A.app j (A.K s)))
    (comp : ∃ d, ∀ x, d ⬝ x=T ↔ ∃ y, H2 A j y x ∧ (x ⬝ A.q ⬝ y) ≠ T) : False := by
  obtain ⟨d,hd⟩ := comp
  let e := A.K d
  have nequal : d ⬝ e=T ↔ d ⬝ e≠T := by
    rw [hd e]
    simp only [h2_iff A dual j rule,e,A.k_app]
    constructor
    · rintro ⟨y,h,nn⟩; exact h ▸ nn
    · intro nn; exact ⟨A.K d,rfl,nn⟩
  exact (fun no => no (nequal.mpr no)) (fun yes => nequal.mp yes yes)
end ShiftedFork
#print axioms ShiftedFork.fork
#print axioms ShiftedFork.h2_iff
#print axioms ShiftedFork.contradicts_comprehension
