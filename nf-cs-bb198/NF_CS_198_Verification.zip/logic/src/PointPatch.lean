module
public import CalibratedSlots
@[expose] public section

namespace PointPatch
open NF192
universe u
variable {M : Type u} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app
local notation "T" => A.K A.B

def delta (a : M) := A.q ⬝ A.K a

theorem same (a : M) : delta A a ⬝ a = T := A.q_true _ _ (A.k_app _ _)
theorem diff {a x : M} (h : x ≠ a) : delta A a ⬝ x = A.B :=
  A.q_false _ _ (by rw [A.k_app]; exact Ne.symm h)

theorem delta_inj {a b : M} (h : delta A a = delta A b) : a = b := by
  apply Classical.byContradiction
  intro no
  exact A.distinct ((same A a).symm.trans
    ((congrArg (fun z => z ⬝ a) h).trans (diff A no)))

theorem delta_not_constant (a b : M) : delta A a ≠ A.K b := by
  intro he
  have ha : T = b := (same A a).symm.trans
    ((congrArg (fun z => z ⬝ a) he).trans (A.k_app _ _))
  have hother : ∃ x, x ≠ a := by
    by_cases eq : a = A.B
    · exact ⟨T, eq ▸ A.distinct⟩
    · exact ⟨A.B,Ne.symm eq⟩
  obtain ⟨x,hx⟩ := hother
  have hb : A.B = b := (diff A hx).symm.trans
    ((congrArg (fun z => z ⬝ x) he).trans (A.k_app _ _))
  exact A.distinct (ha.trans hb.symm)

theorem q_not_const (b : M) : A.q ≠ A.K b := by
  intro h
  exact A.q_no_fixed b ((congrArg (fun z => z ⬝ b) h).trans (A.k_app _ _))

theorem b_fixes_kk (a : M) : A.B ⬝ A.K (A.K a) = A.K (A.K a) := by
  apply A.ext
  intro x
  apply A.ext
  intro y
  simp only [A.b_app,A.k_app]

theorem q_ne_b : A.q ≠ A.B := by
  intro h
  exact A.q_no_fixed _ ((congrArg (fun z => z ⬝ A.K (A.K A.B)) h).trans (b_fixes_kk A _))

theorem test_boolean (f t : M) : A.q ⬝ f ⬝ t = T ∨ A.q ⬝ f ⬝ t = A.B := by
  by_cases h : f ⬝ t = t
  · exact Or.inl (A.q_true _ _ h)
  · exact Or.inr (A.q_false _ _ h)

theorem test_ne_B (f : M) : A.q ⬝ f ≠ A.B := by
  intro he
  let w := A.K (A.K A.B)
  have fixed := b_fixes_kk A A.B
  change A.B ⬝ w = w at fixed
  have eq := (congrArg (fun z => z ⬝ w) he).trans fixed
  rcases test_boolean A f w with ht|hf
  · exact A.distinct (A.k_inj (eq.symm.trans ht))
  · exact CalibratedSlots.b_not_constant A _ (hf.symm.trans eq)

theorem q_ne_delta (a : M) : A.q ≠ delta A a := by
  intro he
  let z := A.K A.q
  have hh := congrArg (fun f => f ⬝ z) he
  rcases test_boolean A (A.K a) z with ht|hf
  · exact delta_not_constant A A.q A.B (hh.trans ht)
  · exact test_ne_B A z (hh.trans hf)

def ident := A.B ⬝ (A.B ⬝ A.B ⬝ A.B) ⬝ A.B
theorem ident_apply (x : M) : ident A ⬝ x = x := by simp only [ident,A.b_app,A.k_app]

def rightConstant (f c : M) := A.B ⬝ f ⬝ A.K c

def choose (p f g : M) :=
  rightConstant A (rightConstant A (rightConstant A (rightConstant A p
    (A.K (A.K (A.K f)))) (A.K (A.K g))) A.B) A.B

theorem choose_apply (p f g x : M) :
    choose A p f g ⬝ x = p ⬝ A.K (A.K (A.K (A.K x))) ⬝
      A.K (A.K (A.K f)) ⬝ A.K (A.K g) ⬝ A.B ⬝ A.B := by
  simp only [choose,rightConstant,A.b_app,A.k_app]

/-- An object implementing an arbitrary one-point override, in every normalized
algebra. Here the branch objects are functions and the last application passes x. -/
def patch (f a y : M) : M :=
  let target := A.K (A.K (A.K (A.K (A.K a))))
  A.B ⬝ choose A (delta A target) f (A.K y) ⬝ ident A

theorem patch_at (f a y : M) : patch A f a y ⬝ a = y := by
  simp only [patch,A.b_app,choose_apply,same,A.k_app,ident_apply]

theorem patch_away (f a y x : M) (h : x ≠ a) : patch A f a y ⬝ x = f ⬝ x := by
  have neq : A.K (A.K (A.K (A.K (A.K x)))) ≠ A.K (A.K (A.K (A.K (A.K a)))) :=
    fun ee => h (A.k_inj (A.k_inj (A.k_inj (A.k_inj (A.k_inj ee)))))
  simp only [patch,A.b_app,choose_apply,diff A neq,A.k_app,ident_apply]

end PointPatch
#print axioms PointPatch.patch_at
#print axioms PointPatch.patch_away
