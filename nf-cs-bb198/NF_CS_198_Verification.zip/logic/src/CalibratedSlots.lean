module
public import NumericalModel

@[expose] public section
namespace CalibratedSlots
open NF192 NF192.Numerical NF192.Ground
universe u
variable {M : Type u} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app

/-- The raw witness for two terms must pass this test at every fixed point. -/
def Clause (f g w : M) : Prop :=
  ∀ x, f ⬝ (g ⬝ x) = x →
    g ⬝ (f ⬝ w) = A.K (f ⬝ (g ⬝ (w ⬝ A.q))) →
    (w ⬝ x) ⬝ (f ⬝ x) = x

theorem b_not_constant (t : M) : A.B ≠ A.K t := by
  intro he
  have abs (u : M) := congrArg (fun f => f ⬝ A.K (A.K u) ⬝ A.B ⬝ A.B) he
  have abs' (u : M) : u = t ⬝ A.B ⬝ A.B := by
    simpa only [A.b_app,A.k_app] using abs u
  exact A.distinct ((abs' (A.K A.B)).trans (abs' A.B).symm)

/-- Every value works when the second raw argument denotes constant B. -/
theorem at_T (f w : M) : Clause A f (A.K A.B) w := by
  intro x hx h
  rw [A.k_app] at h
  exact (b_not_constant A _ h).elim

/-- Every diagonal H(f,f)=K(f) works by the first fixed-point assumption. -/
theorem on_diagonal (f : M) : Clause A f f (A.K f) := by
  intro x hx _
  simpa only [A.k_app] using hx

/-- Output parity tags t=0 or t=1 pack both raw extensionality arguments
into the left input of H.  The right input is always the raw code of qq. -/
def field (tag a b : Nat) : Nat := 2 * pair a b + tag

def extCode (tag a b : Nat) : Nat := witness (field tag a b) s

theorem no_even_diagonal (a b : Nat) : field 0 a b ≠ s := by
  change 2 * pair a b + 0 ≠ 1; omega

theorem odd_diagonal (a b : Nat) : field 1 a b = s ↔ a = 0 ∧ b = 0 := by
  change 2 * pair a b + 1 = 1 ↔ _
  rw [← Cantor.pair_zero_iff]
  omega

section Interpret
variable (W : M → M → M) (tag : Nat)

noncomputable def chooseH (read : Nat → M) (i j : Nat) : M :=
  if i = j then A.K (read i) else
  if j = s ∧ i % 2 = tag then
    let p := Cantor.unpair (i/2)
    Interpretation.witness A (read p.1) (read p.2)
  else W (read i) (read j)

noncomputable def step (n : Nat) (prev : ∀ m, m < n → M) : M :=
  if n = 0 then A.q else
  let read := fun k => if h : k < n then prev k h else A.q
  let p := Cantor.unpair ((n-1)/2)
  if n % 2 = 1 then (read p.1) ⬝ (read p.2) else
    chooseH A W tag read p.1 p.2

noncomputable def value (n : Nat) : M := Nat.lt_wfRel.wf.fix (step A W tag) n

private theorem val_unfold (n : Nat) : value A W tag n =
    step A W tag n (fun k _ => value A W tag k) := WellFounded.fix_eq _ _ _

theorem value_q : value A W tag q = A.q := by rw [val_unfold]; rfl

theorem value_app (i j : Nat) : value A W tag (app i j) =
    (value A W tag i) ⬝ (value A W tag j) := by
  have hi := pair_ge_left i j
  have hj := pair_ge_right i j
  have hp : app i j ≠ 0 := by unfold app; omega
  have hd : (app i j - 1)/2 = pair i j := by unfold app; omega
  have hm : app i j % 2 = 1 := by unfold app; omega
  have li : i < app i j := by unfold app; omega
  have lj : j < app i j := by unfold app; omega
  rw [val_unfold]
  simp only [step,if_neg hp,hd,Cantor.unpair_pair,if_pos hm,dif_pos li,dif_pos lj]

theorem value_T : value A W tag s = A.K A.B := by
  rw [s,value_app,value_q,A.qq_eq_kb]

theorem value_witness (i j : Nat) : value A W tag (witness i j) =
    chooseH A W tag (value A W tag) i j := by
  have hi := pair_ge_left i j
  have hj := pair_ge_right i j
  have hp : witness i j ≠ 0 := by unfold witness; omega
  have hd : (witness i j - 1)/2 = pair i j := by unfold witness; omega
  have hm : witness i j % 2 ≠ 1 := by unfold witness; omega
  have li : i < witness i j := by unfold witness; omega
  have lj : j < witness i j := by unfold witness; omega
  have hl := Cantor.unpair_left_le (i/2)
  have hr := Cantor.unpair_right_le (i/2)
  have ll : (Cantor.unpair (i/2)).1 < witness i j := by omega
  have lr : (Cantor.unpair (i/2)).2 < witness i j := by omega
  rw [val_unfold]
  simp only [step,if_neg hp,hd,Cantor.unpair_pair,if_neg hm,chooseH,
    dif_pos li,dif_pos lj,dif_pos ll,dif_pos lr]

theorem value_const (i : Nat) : value A W tag (konst i) = A.K (value A W tag i) := by
  simp [konst,value_witness,chooseH]

theorem value_ext (ht : tag ≤ 1) (a b : Nat) :
    (value A W tag b) ⬝ (value A W tag (extCode tag a b)) =
      (value A W tag a) ⬝ (value A W tag (extCode tag a b)) →
    value A W tag a = value A W tag b := by
  by_cases diag : field tag a b = s
  · have l := pair_ge_left a b
    have r := pair_ge_right a b
    change 2 * pair a b + tag = 1 at diag
    have eq : a = b := by omega
    rw [eq]; simp
  · have modOK : field tag a b % 2 = tag := by unfold field; omega
    have divOK : field tag a b / 2 = pair a b := by unfold field; omega
    simp only [extCode,value_witness,chooseH,if_neg diag,modOK,true_and,if_true,
      and_self,divOK,Cantor.unpair_pair]
    exact Interpretation.witness_ext A _ _

theorem raw_probes (hw : ∀ f g, Clause A f g (W f g)) (i j : Nat) :
    Clause A (value A W tag i) (value A W tag j) (value A W tag (witness i j)) := by
  rw [value_witness]
  unfold chooseH
  by_cases diag : i = j
  · subst j
    simp only [if_true]
    exact on_diagonal A _
  · simp only [if_neg diag]
    by_cases ext : j = s ∧ i % 2 = tag
    · simp only [if_pos ext]
      rw [ext.1,value_T]
      exact at_T A _ _
    · simp only [if_neg ext]
      exact hw _ _
end Interpret
end CalibratedSlots
#print axioms CalibratedSlots.b_not_constant
#print axioms CalibratedSlots.value_ext
#print axioms CalibratedSlots.raw_probes
