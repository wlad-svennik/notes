import ExplicitWitness
import NormalizedUpperLetter
import Scope209ChartExact
import Unshifted198Upper
import NormalizedSeparation
open Classical FFL FFL.FirstOrder FFL.FirstOrder.SetTheory
open NFFn NFFn.NF188Finite
namespace NFCS.Pure
noncomputable section
variable {V : Type} [SetStructure V] [Nonempty V] [V↓[ℒₛₑₜ] ⊧* 𝗡𝗙]
theorem separated_of_model (cs : CS V) : ∃ A : Scope209.Upper.Chart V, Unshifted198.Separated A := by
  obtain ⟨N,appEq,kEq,_⟩ := NFCS.Upper.normalized_full_chart V
  let j := NativeWeakJ.namedJ N
  have jj := NativeWeakJ.jj N
  have prop := NativeWeakJ.j_ne_B N
  have theta := NativeWeakJ.false_iff N
  have sep (a b : V) : ∃ z, N.app b z = N.app a z → a=b := by
    classical
    by_cases he : a=b
    · exact ⟨j,fun _ => he⟩
    · have diff : ∃ z, N.app b z ≠ N.app a z := by
        by_contra h
        exact he (N.ext (fun z => Eq.symm (Classical.byContradiction fun e => h ⟨z,e⟩)))
      obtain ⟨z,hz⟩ := diff
      exact ⟨z,fun h => False.elim (hz h)⟩
  let A : Scope209.Upper.Chart V := {
    J:=j, B:=N.B, app:=N.app, K:=N.K, witness:=fun a b => Classical.choose (sep a b),
    k_app:=N.k_app, b_app:=N.b_app, letter:=jj, proper:=prop.symm,
    off:=fun x y ne => (theta x y).mpr ne, on:=fun x e => (theta x x).mp e rfl,
    witness_ext:=fun a b => Classical.choose_spec (sep a b) }
  refine ⟨A,?_⟩
  apply UnshiftedSeparation.select N
  rw [appEq,kEq]
  exact localLaw cs

theorem unshifted198_full_ground_of_model (cs : CS V) :
    ∃ r : Nat → Nat → Prop, (∀ a b c u x, x ∈ Unshifted198.fullRows a b c u → NF192.Numerical.evaluate r x) ∧
       ¬r NF192.Numerical.s NF192.Numerical.q := by
  obtain ⟨A,h⟩ := separated_of_model cs
  exact Unshifted198.full_ground_of_separated A h
end
end NFCS.Pure
#print axioms NFCS.Pure.unshifted198_full_ground_of_model
