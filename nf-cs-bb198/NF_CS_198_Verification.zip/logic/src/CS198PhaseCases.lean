import MarkerEnumeration
import CS198Bounds
namespace CS198.Scanner
open NF180Counting.CensusMarker
open NF192.Numerical 
open CacheBound Phase

structure Plan where
  fields : Nat
  carry : Nat
  lastB : Nat

def literalAX (tag h : Nat) : Plan :=
  let q := tag-2
  let spent := min q h
  ⟨spent+1,q-spent,h-spent⟩

def boundedCache (D : Nat) : CacheBound → Nat → Prop
  | unknown, _ => True
  | marker, h => 22 ≤ h
  | huge, h => 2*D ≤ h

/-- The actual final marker preserves a single fixed huge-cache threshold. -/
theorem huge_invariant {D tag h : Nat} (ht : tag ≤ D) (hh : 2*D ≤ h) (a : Nat) :
    (literalAX tag h).carry = 0 ∧ h ≤ testRow (literalAX tag h).lastB a := by
  have le : tag-2 ≤ h := by omega
  simp only [literalAX,Nat.min_eq_left le,Nat.sub_self,true_and]
  have hd := marker_double (h-(tag-2)) a
  omega

/-- The set of schedules in regular's exact-tag branch contains the actual literal batch loop,
including CD5 failure exactly on the final batch. -/
theorem immediate_realized {D tag h : Nat} (bound : CacheBound)
    (hbound : boundedCache D bound h) (budget : tag ≤ D)
    (fax : 2 ≤ tag) (next finish : Phase → Bool) (v : Nat)
    (cert : regular v (immediate tag bound) next finish = true) :
    next (fields (literalAX tag h).fields bound (literalAX tag h).carry) = true := by
  have hn : ¬ tag ≤ 1 := by omega
  simp only [regular,if_neg hn,Bool.and_eq_true,decide_eq_true_eq] at cert
  obtain ⟨h22,keep⟩ := cert
  cases bound with
  | unknown =>
    have mem : min (tag-2) h ∈ List.range (tag-1) := List.mem_range.mpr (by omega)
    exact List.all_eq_true.mp keep _ mem
  | marker =>
    change 22 ≤ h at hbound
    have hq : tag-2 ≤ h := by omega
    simp [literalAX,hq,Nat.min_eq_left hq,show tag-2+1=tag-1 by omega] at *
    exact keep
  | huge =>
    change 2*D ≤ h at hbound
    have hq : tag-2 ≤ h := by omega
    simp [literalAX,hq,Nat.min_eq_left hq,show tag-2+1=tag-1 by omega] at *
    exact keep

/-- Actual post-cache after a bounded normal AX covers the marker class emitted by the
checker. For unknown/marker input this also dominates any residual allowed by t≤22. -/
theorem finish_realized {D tag h : Nat} (bound : CacheBound)
    (hbound : boundedCache D bound h) (budget : tag≤D) (short : tag≤22) (a : Nat) :
    boundedCache D (if bound == huge then huge else marker) (testRow (literalAX tag h).lastB a) ∧
    (literalAX tag h).carry ≤ testRow (literalAX tag h).lastB a := by
  have hs := fresh_mark_small (literalAX tag h).lastB a
  have hr : (literalAX tag h).carry ≤ 22 := by simp only [literalAX]; omega
  refine ⟨?_,by omega⟩
  cases bound with
  | huge =>
    change 2*D ≤ testRow _ a
    exact Nat.le_trans hbound (huge_invariant budget hbound a).2
  | marker => exact hs
  | unknown => exact hs
end CS198.Scanner
#print axioms CS198.Scanner.huge_invariant
#print axioms CS198.Scanner.immediate_realized
#print axioms CS198.Scanner.finish_realized
