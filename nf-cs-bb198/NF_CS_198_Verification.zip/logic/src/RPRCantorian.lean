import RPRGraph
import RPRCore
set_option autoImplicit false
namespace FFL.FirstOrder.FNF.CountSet.RPR
noncomputable section
variable {M : Type} [Tarski.Structure ℒλ M] [Tarski.Structure.Eq ℒλ M] [Nonempty M] [hM : M↓[ℒλ] ⊧* 𝗙𝗡𝗙]
local infixl:70 " ⬝ " => App
attribute [local instance] singletonBase graphAbstraction

private theorem nonconstant_sing (K : M → M) (kLaw : ∀ a x, K a ⬝ x = a) (a v : M) : sing a ≠ K v := by
  classical
  intro h
  obtain ⟨z,n⟩ : ∃ z : M, z ≠ a := if e : TT = a then ⟨FF,fun he => tt_ne_ff hM (e.trans he.symm)⟩ else ⟨TT,e⟩
  have y := characteristic_mem (sing a) a isSet_sing
  have f := characteristic_mem (sing a) z isSet_sing
  rw [bool_true (mem_sing.mpr rfl),h,kLaw] at y
  rw [bool_false (fun hz => n (mem_sing.mp hz)),h,kLaw] at f
  exact tt_ne_ff hM (y.symm.trans f)

theorem all_cantorian_of_local (K : M → M) (kLaw : ∀ a x, K a ⬝ x = a)
    (law : ∀ s : M, ∃ w, RPRCore.Law App K s s w id) : AllCantorian (M:=M) := by
  classical
  rintro X _ ⟨f,inj,onto⟩
  have hf : SingleImage.Bij f X (simg X) := ⟨⟨inj.dom,inj.tot,inj.func,inj.inj⟩,onto⟩
  by_cases nonemptyX : ∃ a, Mem a X
  · obtain ⟨a,ha⟩ := nonemptyX
    obtain ⟨h,hh⟩ := SingleImage.lift_bij hf
    obtain ⟨p,g,shift⟩ := SingleImage.split_bij hh
    let D := simg X
    let d := sing a
    let q : M := TT
    have hd : Mem d D := mem_simg.mpr ⟨a,ha,rfl⟩
    have sets (x : M) (hx : Mem x D) : IsSet x := by
      obtain ⟨z,_,rfl⟩ := mem_simg.mp hx; exact isSet_sing
    have nc (x v : M) (hx : Mem x D) : x ≠ K v := by
      obtain ⟨z,_,rfl⟩ := mem_simg.mp hx; exact nonconstant_sing K kLaw z v
    obtain ⟨u,v,hu,hv⟩ := SingleImage.realizeUV q D d h p g shift hd sets
    change ∀ t : M, u ⬝ t = g (SingleImage.retract D d (t ⬝ q)) at hu
    change ∀ t y : M, (v ⬝ t) ⬝ y = p (SingleImage.retract D d t) at hv
    have sV (t : M) : IsSet ((v ⬝ t) ⬝ q) := by rw [hv]; exact sets _ (shift.k_mem _ (SingleImage.retract_in hd t))
    have sU (t : M) : IsSet (u ⬝ t) := by rw [hu]; exact sets _ (shift.l_mem _ (SingleImage.retract_in hd _))
    obtain ⟨s,hs⟩ := exists_blend D u v q K kLaw (fun t x => (hv t x).trans (hv t q).symm) sV sU
    have hvK (t : M) : v ⬝ t = K (p (SingleImage.retract D d t)) := fn_ext hM (fun z => (hv t z).trans (kLaw _ z).symm)
    have L (b : M) (hb : Mem b D) : s ⬝ b = K (K (p (p b))) := by
      have hp : Mem (p b) D := shift.k_mem _ hb
      rw [hs,if_pos hb,hv,SingleImage.retract_fix hb,hvK,SingleImage.retract_fix hp]
    have R (b : M) (hb : Mem b D) : s ⬝ K (K (K b)) = K (K (g b)) := by
      have out : ¬ Mem (K (K (K b))) D := fun m => nc _ _ m rfl
      rw [hs,if_neg out,kLaw,kLaw,hu,kLaw,SingleImage.retract_fix hb]
    have range (t : M) : ∃ b, Mem b D ∧ s ⬝ t = K (K b) := by
      by_cases ht : Mem t D
      · exact ⟨p (p t),shift.k_mem _ (shift.k_mem _ ht),L t ht⟩
      · rw [hs,if_neg ht,hu]
        exact ⟨_,shift.l_mem _ (SingleImage.retract_in hd _),rfl⟩
    have all (b : M) (hb : Mem b D) : ∃ t, s ⬝ t = K (K b) := by
      have hgb := shift.l_mem _ hb
      refine ⟨g (g b),?_⟩
      rw [L _ (shift.l_mem _ hgb),shift.kl _ hgb,shift.kl _ hb]
    obtain ⟨w,hw⟩ := RPRCore.lowerLift App K s s id (fun x => Mem x D) p g kLaw shift.lk shift.kl shift.k_mem shift.l_mem L R range (law s)
    exact SingleImage.strong_down (strong_unboxed s w q D K kLaw range all hw)
  · exact ⟨emp,isSet_emp,fun z => ⟨fun bad => False.elim (not_mem_emp z bad),fun ⟨y,hy,_⟩ => False.elim (nonemptyX ⟨y,hy⟩)⟩⟩
end
end FFL.FirstOrder.FNF.CountSet.RPR
#print axioms FFL.FirstOrder.FNF.CountSet.RPR.all_cantorian_of_local
