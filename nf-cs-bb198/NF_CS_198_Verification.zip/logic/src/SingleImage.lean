module
public import Init
@[expose] public section
set_option autoImplicit false
namespace SingleImage
universe u
class Base (M : Type u) where
  app : M → M → M
  mem : M → M → Prop
  isSet : M → Prop
  kpair : M → M → M
  single : M → M
  image : M → M
  empty : M
  truth : Prop → M
  app_ext : ∀ f g, (∀ x, app f x = app g x) → f = g
  sets_ext : ∀ a b, isSet a → isSet b → (∀ x, mem x a ↔ mem x b) → a = b
  truth_congr : ∀ p q, (p ↔ q) → truth p = truth q
  characteristic : ∀ a x, isSet a → app a x = truth (mem x a)
  pair_inj : ∀ {x y z w}, kpair x y = kpair z w → x = z ∧ y = w
  sing_inj : ∀ {x y}, single x = single y → x = y
  image_mem : ∀ {x y}, mem x (image y) ↔ ∃ z, mem z y ∧ x = single z
  empty_set : isSet empty
  empty_mem : ∀ x, ¬ mem x empty
  sing_set : ∀ x, isSet (single x)
  image_set : ∀ x, isSet (image x)

variable {M : Type u} [Base M]
local infixl:70 " ⬝ " => Base.app
abbrev Mem := @Base.mem M _
abbrev IsSet := @Base.isSet M _
abbrev kp := @Base.kpair M _
abbrev sing := @Base.single M _
abbrev simg := @Base.image M _
abbrev emp := @Base.empty M _
abbrev bool := @Base.truth M _
def Ap (f x y : M) := Mem (kp x y) f
def Ret (D b t s : M) : Prop := (Mem t D ∧ s = t) ∨ (¬ Mem t D ∧ s = b)
def Strong (D : M) := ∃ g : M, IsSet g ∧ ∀ p, Mem p g ↔ ∃ x, Mem x D ∧ p = kp x (sing x)
def FixedSets (q : M) := ∀ u v : M, (∀ t z, v ⬝ (u ⬝ t) ⬝ z = u ⬝ (v ⬝ (t ⬝ q))) →
   ∃ D : M, IsSet D ∧ (∀ x, Mem x D ↔ u ⬝ (v ⬝ x) = x) ∧ Strong D
structure Inj (f a b : M) : Prop where
  dom : ∀ x y, Ap f x y → Mem x a ∧ Mem y b
  tot : ∀ x, Mem x a → ∃ y, Ap f x y
  func : ∀ x y z, Ap f x y → Ap f x z → y = z
  inj : ∀ x y z, Ap f x z → Ap f y z → x = y
def uTest (q D b f y t : M) : Prop :=
  ∃ p r a s, t ⬝ q = p ∧ Ret D b p r ∧ s = sing r ∧ Ap f a s ∧ Mem y a
def vTest (D b f z t : M) : Prop :=
  ∃ r a s, Ret D b t r ∧ s = sing a ∧ Ap f r s ∧ Mem z a
class Comprehension (M : Type u) [Base M] : Prop where
  makeU : ∀ q D b f : M, ∃ u : M, ∀ t y, (u ⬝ t) ⬝ y = bool (uTest q D b f y t)
  makeV : ∀ D b f : M, ∃ v : M, ∀ t y z, ((v ⬝ t) ⬝ y) ⬝ z = bool (vTest D b f z t)
  lifted : ∀ f : M, ∃ g : M, ∀ p : M, Mem p g ↔ ∃ a b z w, Ap f a b ∧ z = sing a ∧ w = sing b ∧ p = kp z w
  lowered : ∀ G : M, ∃ g : M, IsSet g ∧ ∀ p : M, Mem p g ↔ ∃ x y z w, p = kp x y ∧ z = sing x ∧ w = sing y ∧ Ap G z w

theorem mem_simg_sing {x D : M} : Mem (sing x) (simg D) ↔ Mem x D := by
  constructor
  · intro h
    obtain ⟨a,ha,e⟩ := Base.image_mem.mp h
    exact Base.sing_inj e ▸ ha
  · intro h; exact Base.image_mem.mpr ⟨x,h,rfl⟩

end SingleImage
