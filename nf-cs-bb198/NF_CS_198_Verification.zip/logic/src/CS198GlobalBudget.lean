import NumericalCodes

namespace CS198.GlobalBudget

open NF192.Numerical

private theorem selector_budget (x y : Nat) : x+y ≤ pair x y := by
  have h := triangular_ge (x+y)
  unfold pair
  omega

/-- A partial parse of any one raw cursor. Only fields used as selectors
contribute to the accumulated charge. Command ends may decrease the cursor. -/
inductive Scan : Nat → Nat → Nat → Prop where
  | stop (x : Nat) : Scan x 0 x
  | tag {x y charge rest} : Scan y charge rest → Scan (pair x y) (x + charge) rest
  | field {x y charge rest} : Scan y charge rest → Scan (pair x y) charge rest
  | shrink {a b charge rest} : b ≤ a → Scan b charge rest → Scan a charge rest

theorem scan_budget {raw charge rest} (s : Scan raw charge rest) : charge + rest ≤ raw := by
  induction s with
  | stop x => omega
  | @tag x y charge rest _ ih => have := selector_budget x y; omega
  | @field x y charge rest _ ih => have := selector_budget x y; omega
  | shrink h _ ih => omega

/-- Ranks at successive epoch boundaries, allowing the worst possible carry.
The first three fictitious epochs may be taken to have zero charge. -/
inductive Carry (initial : Nat) : Nat → Nat → Prop where
  | start : Carry initial 0 initial
  | step {m r r'} : Carry initial m r → r' ≤ r + m → Carry initial (m+1) r'

theorem carry_budget {initial m r} (c : Carry initial m r) : r ≤ initial + m*m := by
  induction c with
  | start => simp
  | @step m r r' _ h ih => simp only [Nat.add_mul, Nat.mul_add, Nat.one_mul, Nat.mul_one]; omega

theorem effective_rank {initial m r tagSum rest t}
    (c : Carry initial m r) (s : Scan m tagSum rest) (h : t ≤ r + tagSum) :
    t < initial + (m+2)^2 + 1 := by
  have := carry_budget c
  have := scan_budget s
  simp only [Nat.pow_succ, Nat.pow_zero, Nat.one_mul, Nat.add_mul, Nat.mul_add]
  omega

/-- A concrete witness large enough for both predecessor epochs and
the marker estimate, regardless of the length of the prescribed proof. -/
theorem choose_epoch (z initial first : Nat) :
    ∃ K n, n = pair K (z+1) ∧ first+2 ≤ n ∧
      100 * (initial + (n+2)^2 + 1) < K^16 := by
  let K := z + initial + first + 10000
  let n := pair K (z+1)
  refine ⟨K, n, rfl, ?_, ?_⟩
  · have hl := pair_ge_left K (z+1)
    dsimp [n, K] at *
    omega
  · have hz : z+1 ≤ K := by dsimp [K]; omega
    have hi : initial+1 ≤ K := by dsimp [K]; omega
    have hk : 10000 ≤ K := by dsimp [K]; omega
    have hn : n+2 ≤ 8 * (K*K) := by
      have a : K+(z+1) ≤ 2*K := by omega
      have b : K+(z+1)+1 ≤ 3*K := by omega
      have m := Nat.mul_le_mul a b
      have h6 : (2*K)*(3*K) = 6*(K*K) := by
        change (2*K)*(3*K) = (2*3)*(K*K)
        ac_rfl
      rw [h6] at m
      have hh : K ≤ K*K := by simpa using Nat.mul_le_mul_left K (show 1 ≤ K by omega)
      dsimp [n, pair]
      omega
    have sq := Nat.pow_le_pow_left hn 2
    have expand : (8*(K*K))^2 = 64*K^4 := by
      simp only [Nat.pow_succ, Nat.pow_zero, Nat.one_mul]
      change (8*(K*K))*(8*(K*K)) = (8*8)*(K*K*K*K)
      ac_rfl
    rw [expand] at sq
    have e1 : K ≤ K^4 := by
      simpa using Nat.pow_le_pow_right (show 0 < K by omega) (show 1 ≤ 4 by decide)
    have e2 : K^5 ≤ K^16 := Nat.pow_le_pow_right (by omega) (by decide)
    have mult := Nat.mul_le_mul_left (K^4) hk
    rw [← Nat.pow_succ] at mult
    change K^4 * 10000 ≤ K^5 at mult
    have pos : 0 < K^4 := Nat.pow_pos (by omega)
    omega

end CS198.GlobalBudget
#print axioms CS198.GlobalBudget.effective_rank
#print axioms CS198.GlobalBudget.choose_epoch
