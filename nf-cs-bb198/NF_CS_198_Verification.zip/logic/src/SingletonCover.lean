module
public import SingleImage
@[expose] public section
set_option autoImplicit false
namespace SingleImage
universe u
variable {M : Type u} [Base M] [Comprehension M]
local infixl:70 " ⬝ " => Base.app
noncomputable section
def retract (D b t : M) : M := by classical exact if Mem t D then t else b

theorem ret_iff (D b t s : M) : Ret D b t s ↔ s = retract D b t := by
  classical
  by_cases hx : Mem t D <;> simp [Ret,retract,hx]
theorem retract_in {D b : M} (base : Mem b D) (x : M) : Mem (retract D b x) D := by
  classical
  by_cases hx : Mem x D <;> simp [retract,hx, base]
theorem retract_fix {D b x : M} (hx : Mem x D) : retract D b x = x := by
  classical simp [retract,hx]

/-- A represented bijection to the singleton image, decomposed into its underlying permutation. -/
structure Shift (D f : M) (k l : M → M) : Prop where
  k_mem : ∀ x, Mem x D → Mem (k x) D
  l_mem : ∀ x, Mem x D → Mem (l x) D
  lk : ∀ x, Mem x D → l (k x) = x
  kl : ∀ x, Mem x D → k (l x) = x
  edge : ∀ a b, Ap f a (sing b) ↔ Mem a D ∧ k a = b

theorem realizeUV (q D b f : M) (k l : M → M) (shift : Shift D f k l) (base : Mem b D)
    (sets : ∀ a, Mem a D → IsSet a) :
    ∃ u v : M, (∀ t, u ⬝ t = l (retract D b (t ⬝ q))) ∧
      (∀ t y, (v ⬝ t) ⬝ y = k (retract D b t)) := by
  have utest (y t : M) : uTest q D b f y t ↔ Mem y (l (retract D b (t ⬝ q))) := by
    constructor
    · rintro ⟨p,r,a,s,hp,hr,hs,e,hy⟩
      subst p; subst s
      obtain ⟨ha,eq⟩ := (shift.edge a r).mp e
      have result : l (retract D b (t ⬝ q)) = a := (congrArg l (eq.trans ((ret_iff _ _ _ _).mp hr))).symm.trans (shift.lk a ha)
      rw [result]; exact hy
    · intro hy
      let r := retract D b (t ⬝ q)
      have hr : Mem r D := retract_in base _
      exact ⟨_,r,l r,sing r,rfl,(ret_iff _ _ _ _).mpr rfl,rfl,(shift.edge _ _).mpr ⟨shift.l_mem _ hr,shift.kl _ hr⟩,hy⟩
  have vtest (z t : M) : vTest D b f z t ↔ Mem z (k (retract D b t)) := by
    constructor
    · rintro ⟨r,a,s,hr,hs,e,hz⟩
      subst s
      obtain ⟨_,eq⟩ := (shift.edge r a).mp e
      simpa only [←(ret_iff _ _ _ _).mp hr, eq] using hz
    · intro hz
      let r := retract D b t
      have hr : Mem r D := retract_in base _
      exact ⟨r,k r,sing (k r),(ret_iff _ _ _ _).mpr rfl,rfl,(shift.edge _ _).mpr ⟨hr,rfl⟩,hz⟩
  obtain ⟨u,hu⟩ := Comprehension.makeU q D b f
  obtain ⟨v,hv⟩ := Comprehension.makeV D b f
  refine ⟨u,v,fun t => Base.app_ext _ _ fun y => ?_,fun t y => Base.app_ext _ _ fun z => ?_⟩
  · exact (hu t y).trans ((Base.truth_congr _ _ (utest y t)).trans (Base.characteristic _ y (sets _ (shift.l_mem _ (retract_in base _)))).symm)
  · exact (hv t y z).trans ((Base.truth_congr _ _ (vtest z t)).trans (Base.characteristic _ z (sets _ (shift.k_mem _ (retract_in base _)))).symm)

theorem strong_of_shift (q D b f : M) (k l : M → M) (fs : FixedSets q) (hd : IsSet D)
    (base : Mem b D) (sets : ∀ a, Mem a D → IsSet a) (shift : Shift D f k l) : Strong D := by
  obtain ⟨u,v,hu,hv⟩ := realizeUV q D b f k l shift base sets
  have uv (t : M) : u ⬝ (v ⬝ t) = retract D b t := by
    rw [hu,hv,retract_fix (shift.k_mem _ (retract_in base t)),shift.lk _ (retract_in base t)]
  obtain ⟨d,hd',mem,strong⟩ := fs u v (fun t z => by
    rw [hv,hu,retract_fix (shift.l_mem _ (retract_in base _)),shift.kl _ (retract_in base _),uv])
  have same : d = D := Base.sets_ext _ _ hd' hd (fun x => by
    change Mem x d ↔ Mem x D
    rw [mem,uv]; exact ⟨fun h => h ▸ retract_in base x, fun h => retract_fix h⟩)
  exact same ▸ strong
def Bij (f a b : M) : Prop := Inj f a b ∧ ∀ y, Mem y b → ∃ x, Ap f x y

theorem split_bij {D f : M} (h : Bij f D (simg D)) : ∃ k l : M → M, Shift D f k l := by
  classical
  obtain ⟨inj,onto⟩ := h
  have forth (a : M) (ha : Mem a D) : ∃ b, Ap f a (sing b) := by
    obtain ⟨y,e⟩ := inj.tot a ha
    obtain ⟨b,_,rfl⟩ := Base.image_mem.mp (inj.dom a y e).2
    exact ⟨b,e⟩
  have back (b : M) (hb : Mem b D) : ∃ a, Ap f a (sing b) := onto _ (mem_simg_sing.mpr hb)
  let k := fun a => if ha : Mem a D then (forth a ha).choose else a
  let l := fun a => if ha : Mem a D then (back a ha).choose else a
  have ek (a : M) (ha : Mem a D) : Ap f a (sing (k a)) := by
    simpa only [k,dif_pos ha] using (forth a ha).choose_spec
  have el (a : M) (ha : Mem a D) : Ap f (l a) (sing a) := by
    simpa only [l,dif_pos ha] using (back a ha).choose_spec
  have kin (a : M) (ha : Mem a D) := mem_simg_sing.mp (inj.dom _ _ (ek a ha)).2
  have lin (a : M) (ha : Mem a D) := (inj.dom _ _ (el a ha)).1
  refine ⟨k,l,kin,lin,?_,?_,?_⟩
  · intro a ha
    exact inj.inj _ _ _ (el (k a) (kin _ ha)) (ek _ ha)
  · intro a ha
    exact Base.sing_inj (inj.func _ _ _ (ek _ (lin _ ha)) (el _ ha))
  · intro a b
    constructor
    · intro e
      have ha := (inj.dom _ _ e).1
      exact ⟨ha,Base.sing_inj (inj.func _ _ _ (ek _ ha) e)⟩
    · rintro ⟨ha,rfl⟩; exact ek _ ha

private theorem lift_pairs (f : M) : ∃ g : M, ∀ x y, Ap g x y ↔ ∃ a b, Ap f a b ∧ x = sing a ∧ y = sing b := by
  obtain ⟨g,vg⟩ := Comprehension.lifted f
  refine ⟨g,fun x y => ?_⟩
  change Mem (kp x y) g ↔ _
  rw [vg]
  constructor
  · rintro ⟨a,b,z,w,e,rfl,rfl,eq⟩
    exact ⟨a,b,e,(Base.pair_inj eq).1,(Base.pair_inj eq).2⟩
  · rintro ⟨a,b,e,rfl,rfl⟩
    exact ⟨a,b,_,_,e,rfl,rfl,rfl⟩

theorem lift_bij {a b f : M} (h : Bij f a b) : ∃ g, Bij g (simg a) (simg b) := by
  obtain ⟨g,e⟩ := lift_pairs f
  obtain ⟨hf,onto⟩ := h
  refine ⟨g,⟨?_,?_,?_,?_⟩,?_⟩
  · intro x y edge
    obtain ⟨u,v,h,rfl,rfl⟩ := (e x y).mp edge
    exact ⟨mem_simg_sing.mpr (hf.dom _ _ h).1,mem_simg_sing.mpr (hf.dom _ _ h).2⟩
  · intro x hx
    obtain ⟨u,hu,rfl⟩ := Base.image_mem.mp hx
    obtain ⟨v,hv⟩ := hf.tot _ hu
    exact ⟨_,(e _ _).mpr ⟨u,v,hv,rfl,rfl⟩⟩
  · intro x y z ey ez
    obtain ⟨u,v,h,rfl,rfl⟩ := (e x y).mp ey
    obtain ⟨u',w,h',eq,rfl⟩ := (e _ z).mp ez
    obtain rfl := Base.sing_inj eq
    exact congrArg sing (hf.func _ _ _ h h')
  · intro x y z ex ey
    obtain ⟨u,v,h,rfl,rfl⟩ := (e x z).mp ex
    obtain ⟨w,v',h',rfl,eq⟩ := (e y _).mp ey
    obtain rfl := Base.sing_inj eq
    exact congrArg sing (hf.inj _ _ _ h h')
  · intro z hz
    obtain ⟨v,hv,rfl⟩ := Base.image_mem.mp hz
    obtain ⟨u,hu⟩ := onto _ hv
    exact ⟨_,(e _ _).mpr ⟨u,v,hu,rfl,rfl⟩⟩

theorem strong_down {a : M} (hs : Strong (simg a)) : Strong a := by
  obtain ⟨G,_,g⟩ := hs
  obtain ⟨f,hf,m⟩ := Comprehension.lowered G
  refine ⟨f,hf,fun p => ?_⟩
  rw [m]
  constructor
  · rintro ⟨x,y,z,w,pdef,rfl,rfl,edge⟩
    obtain ⟨v,hv,eq⟩ := (g _).mp edge
    obtain ⟨h1,h2⟩ := Base.pair_inj eq
    subst v
    exact ⟨x,mem_simg_sing.mp hv,by simpa only [Base.sing_inj h2] using pdef⟩
  · rintro ⟨x,hx,rfl⟩
    exact ⟨x,sing x,sing x,sing (sing x),rfl,rfl,rfl,(g _).mpr ⟨sing x,mem_simg_sing.mpr hx,rfl⟩⟩

def AllCantorian : Prop := ∀ X : M, IsSet X → (∃ f, Bij f X (simg X)) → Strong X

theorem all_cantorian (q : M) (fixed : FixedSets q) : AllCantorian (M:=M) := by
  classical
  rintro X _ ⟨f,hf⟩
  by_cases h : ∃ x, Mem x X
  · obtain ⟨x,hx⟩ := h
    obtain ⟨g,hg⟩ := lift_bij hf
    obtain ⟨k,l,shift⟩ := split_bij hg
    apply strong_down
    apply strong_of_shift q (simg X) (sing x) g k l fixed (Base.image_set _) (mem_simg_sing.mpr hx) _ shift
    intro a ha
    obtain ⟨y,_,rfl⟩ := Base.image_mem.mp ha
    exact (Base.sing_set _)
  · exact ⟨emp,Base.empty_set,fun p => ⟨fun e => False.elim (Base.empty_mem p e),fun ⟨x,hx,_⟩ => False.elim (h ⟨x,hx⟩)⟩⟩
end
end SingleImage
#print axioms SingleImage.all_cantorian
