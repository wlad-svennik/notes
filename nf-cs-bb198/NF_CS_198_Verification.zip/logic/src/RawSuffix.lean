module
public import PointPatch
public import RangeModel
@[expose] public section

namespace RawSuffix
open NF192 PointPatch
universe u
variable {M : Type u} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app
local notation "T" => A.K A.B

theorem bq : A.B ⬝ A.q = A.q := by
  apply A.ext
  intro a
  apply A.ext
  intro x
  rw [A.b_app]
  by_cases h : a ⬝ x = x
  · rw [h,A.q_true _ _ (A.k_app _ _),A.q_true _ _ h]
  · have left : A.K x ⬝ (a ⬝ x) ≠ a ⬝ x := by rw [A.k_app]; exact Ne.symm h
    rw [A.q_false _ _ left,A.q_false _ _ h]

theorem qB_ne_delta_q : A.q ⬝ A.B ≠ delta A A.q := by
  intro he
  have good := A.q_true A.B (A.K (A.K A.q)) (b_fixes_kk A A.q)
  have bad := diff A (Ne.symm (q_not_const A (A.K A.q)))
  exact A.distinct (good.symm.trans ((congrArg (fun f => f ⬝ A.K (A.K A.q)) he).trans bad))

theorem split_diagonal :
    RangeCS.R A A.q (RangeCS.P A A.q (RangeCS.R A A.q (A.q ⬝ A.K A.q))) ≠ A.q ⬝ A.K A.q := by
  let X := delta A A.q
  have hX : A.q ≠ X := q_ne_delta A _
  change delta A (A.q ⬝ ((delta A X ⬝ A.q) ⬝ A.q)) ≠ delta A A.q
  rw [diff A hX,bq,A.qq_eq_kb]
  exact fun hh => A.qq_ne_q (A.qq_eq_kb.trans (delta_inj A hh))

def L (s a : M) := s ⬝ (a ⬝ A.q)
def D (s a : M) := s ⬝ A.K (A.K a)

theorem dual_split_diagonal :
    L A A.q (D A A.q (L A A.q (A.q ⬝ A.K A.q))) ≠ A.q ⬝ A.K A.q := by
  let X := delta A A.q
  let Y := delta A A.B
  have first : L A A.q X = Y := by
    change A.q ⬝ (delta A A.q ⬝ A.q) = A.q ⬝ A.K A.B
    rw [same]
  have cent : D A A.q Y = delta A (A.K Y) := rfl
  have last : L A A.q (delta A (A.K Y)) = A.q ⬝ A.B := by
    change A.q ⬝ (delta A (A.K Y) ⬝ A.q) = _
    rw [diff A (q_not_const A Y)]
  change L A A.q (D A A.q (L A A.q X)) ≠ X
  rw [first,cent,last]
  exact qB_ne_delta_q A

end RawSuffix
#print axioms RawSuffix.split_diagonal
#print axioms RawSuffix.dual_split_diagonal
