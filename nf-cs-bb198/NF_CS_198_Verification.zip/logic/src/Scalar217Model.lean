module
public import Scalar217Logic
@[expose] public section
/-! Exact algebraic semantics of the split-witness numerical theory. Its local
selector is external. The represented application and K belong to the algebra. -/
namespace CS217
open NF192 NF192.Ground NF192.Numerical NF192.Emitter

universe v

def Clause {M : Type v} (A : NormalizedBasis M) (u v w : M) : Prop :=
  ∀ x, A.app u (A.app v x) = x →
    A.app v (A.app u w) = A.K (A.app u (A.app v (A.app w A.q))) → A.app (A.app w x) A.q = x

def HasProbes {M : Type v} (A : NormalizedBasis M) : Prop := ∀ u v, ∃ w, Clause A u v w

/-- In the quotient construction, this auxiliary two-place operation is used
only for its diagonal and for functional extensionality. -/
def normalizedSignature : Signature Nat where
  q := q
  app := app
  h := fun a b => if a = b then konst a else witness q (app a b)

theorem normalized_k (a : Nat) : normalizedSignature.k a = konst a := by
  simp [Signature.k,normalizedSignature]

private theorem instantiate {r} (hr : RowsHold r) (a b c : Nat) {x : Nat}
    (hx : x ∈ rowList a b c 0) : evaluate r x := hr a b c 0 (Nat.zero_le _) x hx

set_option maxHeartbeats 4000000 in
def core {r} (hr : RowsHold r) : Rows normalizedSignature r := by
  have pos (a b) := instantiate hr a b 0 (x:=row1 a b) (by simp [rowList])
  have arg (a b c) := instantiate hr a b c (x:=row2 a b c) (by simp [rowList])
  have con (a b) := instantiate hr a b 0 (x:=row4 a b) (by simp [rowList])
  have fnc (a b c) := instantiate hr a b c (x:=row3 a b c) (by simp [rowList])
  have abs (a b c) := instantiate hr a b c (x:=row5 a b c) (by simp [rowList])
  have euc (a b c) := instantiate hr a b c (x:=row6 a b c) (by simp [rowList])
  have neg (a b) := instantiate hr a b 0 (x:=row7 a b) (by simp [rowList])
  have ext (a b) := instantiate hr a b 0 (x:=extRow a b) (by simp [rowList])
  simp only [row1,row2,row4,row3,row5,row6,row7,extRow,evaluate_imp,evaluate_eqn,goal] at *
  constructor
  · exact pos
  · exact arg
  · intro a b; rw [normalized_k]; exact con a b
  · exact fnc
  · intro a b c; rw [normalized_k]; exact abs a b c
  · exact euc
  · exact neg
  · intro a b h
    by_cases eq : a = b
    · subst b
      exact euc _ a a (con q a) (con q a)
    · apply ext a b
      simpa [normalizedSignature,eq] using h

private theorem hasProbes_of_model {r} (R : RowsHold r) (hg : ¬ r s q) :
    HasProbes ((core R).toBasis hg) := by
  let H := core R
  intro u v
  refine Quotient.inductionOn₂ u v ?_
  intro ui vi
  let w := witness (app ui vi) q
  refine ⟨H.obj w, ?_⟩
  intro x
  refine Quotient.inductionOn x ?_
  intro xi hfix htest
  have hx := instantiate R vi xi ui (x:=fixedRow ui vi xi) (by simp [rowList])
  simp only [fixedRow,evaluate_imp,evaluate_eqn] at hx
  have hk (t : Nat) : H.kObj (H.obj t) = H.obj (konst t) := congrArg H.obj (normalized_k t)
  change H.obj (app (app w xi) q) = H.obj xi
  apply H.obj_eq_iff.mpr
  apply hx (H.obj_eq_iff.mp hfix)
  change H.obj (app vi (app ui w)) = H.kObj (H.obj (app ui (app vi (app w q)))) at htest
  rw [hk] at htest
  exact H.obj_eq_iff.mp htest

section Interpret
variable {M : Type v} (A : NormalizedBasis M) (W : M → M → M)

/-- The two witness constructors inspect raw syntax. The remaining H codes
may all take K of the first argument, including every diagonal. -/
noncomputable def evalTerm : Term → M
  | .q => A.q
  | .app a b => A.app (evalTerm a) (evalTerm b)
  | .h .q (.app a b) => Interpretation.witness A (evalTerm a) (evalTerm b)
  | .h (.app a b) .q => W (evalTerm a) (evalTerm b)
  | .h a _ => A.K (evalTerm a)

noncomputable def value (n : Nat) : M := evalTerm A W (decodeTerm n)

theorem value_q : value A W q = A.q := by simp [value,evalTerm]
theorem value_app (a b) : value A W (app a b) = A.app (value A W a) (value A W b) := by simp [value,evalTerm]
theorem value_const (a) : value A W (witness a a) = A.K (value A W a) := by
  simp only [value,decodeTerm_witness]
  cases decodeTerm a <;> rfl
theorem value_ext (a b) : value A W (witness q (app a b)) = Interpretation.witness A (value A W a) (value A W b) := by simp [value,evalTerm]
theorem value_probe (a b) : value A W (witness (app a b) q) = W (value A W a) (value A W b) := by simp [value,evalTerm]

set_option maxHeartbeats 4000000 in
theorem valid_rows (hw : ∀ u v, Clause A u v (W u v)) : RowsHold (fun a b => value A W a = value A W b) := by
  intro a b c u h x hx
  simp only [rowList,List.mem_cons,List.not_mem_nil,or_false] at hx
  rcases hx with hf|hf|hf|hf|hf|hf|hf|hf|hf|hf <;> subst x
  · simp only [row0,evaluate_imp]
    intro hca hac _
    by_cases hc : evaluate (fun i j => value A W i = value A W j) c
    · exact hc
    · exact hac (hca (fun hc' => (hc hc').elim))
  all_goals simp only [row1,row2,row4,row3,row5,row6,row7,extRow,fixedRow,evaluate_imp,
      evaluate_eqn,goal,B,s,konst,value_ext,value_probe,value_const,value_app,value_q,A.qq_eq_kb,A.k_app]
  · intro he; exact (A.q_true _ _ he).symm
  · intro he; rw [he]
  · intro he; rw [he]
  · exact A.b_app _ _ _
  · intro h1 h2; exact h2.symm.trans h1
  · intro h; exact (A.q_false _ _ (fun e => A.qq_ne_q (A.qq_eq_kb.trans (h e)))).symm
  · exact Interpretation.witness_ext A _ _
  · exact hw _ _ _
end Interpret

/-- A goal-falsifying model exists precisely when a normalized algebra has the
external witness property in the two actual emitted premises. -/
theorem not_deriv_iff_probe_basis : ¬ Deriv goal ↔ ∃ M : Type, ∃ A : NormalizedBasis M, HasProbes A := by
  constructor
  · intro h
    obtain ⟨r,hr,hg⟩ := not_deriv_iff_ground_model.mp h
    exact ⟨(core hr).Carrier,(core hr).toBasis hg,hasProbes_of_model hr hg⟩
  · rintro ⟨M,A,hA⟩
    let w := fun u v => Classical.choose (hA u v)
    apply not_deriv_iff_ground_model.mpr
    refine ⟨fun a b => value A w a = value A w b,valid_rows A w (fun u v => Classical.choose_spec (hA u v)),?_⟩
    simpa only [s,value_app,value_q] using A.qq_ne_q
end CS217
#print axioms CS217.not_deriv_iff_probe_basis
