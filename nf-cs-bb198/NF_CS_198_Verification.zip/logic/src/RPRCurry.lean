import Curry
set_option autoImplicit false
namespace FFL.FirstOrder.FNF.CountSet
open JensenNFU.TFm (scons)
noncomputable section
variable {M : Type} [Tarski.Structure ℒλ M] [Tarski.Structure.Eq ℒλ M] [Nonempty M] [M↓[ℒλ] ⊧* 𝗙𝗡𝗙]
local infixl:70 " ⬝ " => App
theorem curry4 {Γ : List Nat} {R : (Nat → M) → Prop} (P : BT (0 :: 1 :: 2 :: 3 :: Γ) R) (q : Nat → M) :
    ∃ f : M, ∀ a b c d, f ⬝ a ⬝ b ⬝ c ⬝ d = bool (R (scons d (scons c (scons b (scons a q))))) := by
  obtain ⟨D,hD⟩ := exists_sep (M := M)
  let body := P.tm 0 (fun i => i) (fun k => Γ.length+k+4)
  have adm : Adm (0 :: 1 :: 2 :: 3 :: Γ) (scons 0 (scons 1 (scons 2 (scons 3 (fun j => if h : j < Γ.length then Γ[j] else j - Γ.length))))) (fun i => i) (fun k => Γ.length+k+4) 0 := by
    constructor
    · intro i hi
      cases i with
      | zero => rfl
      | succ i =>
        cases i with
        | zero => rfl
        | succ i =>
          cases i with
          | zero => rfl
          | succ i =>
            cases i with
            | zero => rfl
            | succ i =>
              have hi' : i < Γ.length := by simpa using hi
              show (if h : i < Γ.length then Γ[i] else i - Γ.length) = Γ[i] + 0
              rw [dif_pos hi']; rfl
    · intro k
      change (if h : Γ.length+k < Γ.length then Γ[Γ.length+k] else Γ.length+k-Γ.length) = k+0
      rw [dif_neg (by omega)]; omega
  have lev0 : HasLev (scons 0 (scons 1 (scons 2 (scons 3 (fun j => if h : j < Γ.length then Γ[j] else j - Γ.length))))) body 0 := by simpa only [Nat.add_zero] using (P.ok 0).lev _ _ _ 0 adm
  have lev1 : HasLev (scons 1 (scons 2 (scons 3 (fun j => if h : j < Γ.length then Γ[j] else j - Γ.length)))) (.lam body) 1 := ⟨0,rfl,lev0⟩
  have lev2 : HasLev (scons 2 (scons 3 (fun j => if h : j < Γ.length then Γ[j] else j - Γ.length))) (.lam (.lam body)) 2 := ⟨1,rfl,lev1⟩
  have lev3 : HasLev (scons 3 (fun j => if h : j < Γ.length then Γ[j] else j - Γ.length)) (.lam (.lam (.lam body))) 3 := ⟨2,rfl,lev2⟩
  have lev4 : HasLev (fun j => if h : j < Γ.length then Γ[j] else j - Γ.length) (.lam (.lam (.lam (.lam body)))) 4 := ⟨3,rfl,lev3⟩
  refine ⟨ev (.lam (.lam (.lam (.lam body)))) (fun j => if j < Γ.length then q j else D),?_⟩
  intro a b c d
  rw [ev_lam lev4, ev_lam lev3, ev_lam lev2, ev_lam lev1]
  apply (P.ok 0).sem _ _ _ 0 _ (scons d (scons c (scons b (scons a q)))) adm
  · intro i hi
    cases i with
    | zero => rfl
    | succ i =>
      cases i with
      | zero => rfl
      | succ i =>
        cases i with
        | zero => rfl
        | succ i =>
          cases i with
          | zero => rfl
          | succ i =>
            have hi' : i < Γ.length := by simpa using hi
            show (if i < Γ.length then q i else D) = q i
            rw [if_pos hi']
  · intro k
    change Sep (if Γ.length+k < Γ.length then q (Γ.length+k) else D)
    rw [if_neg (by omega)]; exact hD
end
end FFL.FirstOrder.FNF.CountSet
#print axioms FFL.FirstOrder.FNF.CountSet.curry4
