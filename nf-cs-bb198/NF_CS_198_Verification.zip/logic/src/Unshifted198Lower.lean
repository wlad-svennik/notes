import Unshifted198Ground
import CSPositiveCensus
import FirstSlotExact

namespace Unshifted198
open NF192.Numerical NF192.Emitter
set_option maxHeartbeats 1500000

private theorem first7 (a b c u : Nat) (i : Fin 9) (h : i.val<7) :
    (FirstSlot.rowList a b c u)[i.val]'(by simpa [FirstSlot.rowList] using i.isLt) ∈ rowList a b c u := by
  have cases : i.val=0 ∨ i.val=1 ∨ i.val=2 ∨ i.val=3 ∨ i.val=4 ∨ i.val=5 ∨ i.val=6 := by omega
  rcases cases with x|x|x|x|x|x|x <;> simp [rowList,FirstSlot.rowList,x]

theorem granted {r} (hr : RowsHold r) : CSPositiveCensus.Granted r := by
  intro a b c i h
  by_cases low : i.val<7
  · exact hr a b c 0 (Nat.zero_le _) _ (first7 a b c 0 i low)
  have hb : b≠0 := by omega
  have one : i.val=7 ∨ i.val=8 := by have := i.isLt; omega
  rcases one with e|e
  · apply hr a b c 0 (Nat.zero_le _)
    simp [rowList,FirstSlot.rowList,e,hb]
  · apply hr (a+1) b 0 0 (Nat.zero_le _)
    simp [rowList,FirstSlot.rowList,lastRow,FirstSlot.lastRow,e,hb]

theorem original_of_nonderiv (hn : ¬ Deriv goal) :
    ∃ V : Type, ∃ A : Scope209.Upper.Chart V, Scope209.Upper.LocalLaw A := by
  obtain ⟨r,hr,ng⟩ := not_deriv_iff_ground_model.mp hn
  exact CSPositiveCensus.chart_from_positive_last_rows (granted hr) ng

theorem new_of_original (d : FirstSlot.Deriv goal) : Deriv goal := by
  apply Classical.byContradiction; intro ng
  exact Scope209.nonderivable_iff_chart_exists.mpr (original_of_nonderiv ng)
    (FirstCalibration.goal_iff_original.mp d)
end Unshifted198
#print axioms Unshifted198.new_of_original
