import Unshifted198Model
import Unshifted198Exact
import NFCSFormula
import RPRModel
open FFL FFL.FirstOrder FFL.FirstOrder.SetTheory NF192.Numerical
namespace Unshifted198
theorem a0_of_nonderiv (hn : ¬Deriv goal) : DirectNFU.HasA0Model := by
  obtain ⟨_,A,law⟩ := original_of_nonderiv hn
  exact NFCS.Lower.a0_of_chart A law

theorem nonderiv_of_consistent (hc : Entailment.Consistent NFCS.Pure.Formula.theory) : ¬Deriv goal := by
  intro he
  apply (Entailment.consistent_iff_unprovable_bot.mp hc)
  apply SetTheory.complete.{0}
  intro V _ _ h
  have : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙 := ⟨fun _ hf => Theory.models V NFCS.Pure.Formula.theory (Set.mem_union_left _ hf)⟩
  have ax : V↓[ℒₛₑₜ] ⊧ NFCS.Pure.Formula.sentence := Theory.models V NFCS.Pure.Formula.theory (Set.mem_union_right _ (Set.mem_singleton _))
  exact (nonderiv_iff_full_ground.mpr (NFCS.Pure.unshifted198_full_ground_of_model ((NFCS.Pure.Formula.models_iff_CS V).mp ax)) he).elim
end Unshifted198
#print axioms Unshifted198.a0_of_nonderiv
#print axioms Unshifted198.nonderiv_of_consistent
