import NormalizedUpperLetter
import ReadPoint204
namespace UnshiftedSeparation
open NF192 PointPatch NativeWeakJ
universe u
variable {V : Type u} (N : NormalizedBasis V)
local infixl:75 " ⬝ " => N.app

theorem b_range (w : V) : N.B ⬝ w ≠ N.B := by
  intro eq
  have act (u y x : V) := congrArg (fun f => f ⬝ u ⬝ y ⬝ x) eq
  simp only [N.b_app] at act
  have alt (u y x : V) := act (N.K (u ⬝ y)) y x
  simp only [N.k_app] at alt
  have e (u y x : V) := (alt u y x).symm.trans (act u y x)
  have idcase (y x : V) := e (ident N) y x
  simp only [ident_apply,N.k_app] at idcase
  have out := idcase (N.K N.B) (N.K N.B)
  simp only [N.k_app] at out
  exact N.distinct out.symm

include N in
private theorem another {f : V → V} (inj : Function.Injective f) (a : V) : ∃ v, f v≠a := by
  by_cases h : f N.B = a
  · exact ⟨N.K N.B,fun eq => N.distinct (inj (eq.trans h.symm))⟩
  · exact ⟨N.B,h⟩

theorem delta_ne_B (s : V) : delta N s ≠ N.B := by
  obtain ⟨v,hv⟩ := another N (f:=fun x=>N.K (N.K x)) (fun _ _ eq => N.k_inj (N.k_inj eq)) s
  intro eq
  have ee := congrArg (fun f => f ⬝ N.K (N.K v)) eq
  rw [diff N hv,b_fixes_kk] at ee
  exact CalibratedSlots.b_not_constant N _ ee

theorem separates_every_input (w : V) : namedJ N ⬝ w ≠ N.B ⬝ w := by
  by_cases hw : Const N w
  · obtain ⟨t,rfl⟩ := hw
    obtain ⟨v,hv⟩ := another N (f:=N.K) (fun _ _ => N.k_inj) t
    intro eq
    have e := congrArg (fun f=>f ⬝ N.K v) eq
    rw [constant,diff N hv] at e
    apply CalibratedSlots.b_not_constant N (t ⬝ v)
    rw [e]
    apply N.ext; intro z
    simp only [N.b_app,N.k_app]
  · rw [other N _ hw]
    exact Ne.symm (b_range N _)

theorem select (h : ∀ s, ∃ w, RPRCore.Law N.app N.K s s w id) (s : V) :
    ∃ w, RPRCore.Law N.app N.K s s w (fun _ => s) ∧
      ((namedJ N ⬝ s) ⬝ w = namedJ N ⬝ w → namedJ N = namedJ N ⬝ s) := by
  by_cases hs : Const N s
  · obtain ⟨t,rfl⟩ := hs
    refine ⟨N.K (N.K t),?_,?_⟩
    · intro x _
      simp only [N.k_app]
    · rw [constant,constant]
      by_cases eq : N.K (N.K t) = t
      · rw [eq,same]
        intro e
        exact False.elim (delta_not_constant N _ _ e.symm)
      · rw [diff N eq]
        intro e
        exact False.elim (delta_ne_B N _ e.symm)
  · obtain ⟨w,hw⟩ := CantorianReadPoint.changeRead N.app N.K N.B N.k_app N.b_app s s id (fun _ => s) (h s)
    refine ⟨w,hw,?_⟩
    rw [other N s hs]
    intro eq
    exact False.elim (separates_every_input N w eq.symm)
end UnshiftedSeparation
#print axioms UnshiftedSeparation.select
