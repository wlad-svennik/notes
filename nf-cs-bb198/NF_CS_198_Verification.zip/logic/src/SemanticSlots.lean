module
public import RawSuffix
@[expose] public section
namespace SemanticSlots
open NF192 PointPatch
universe u
variable {M : Type u} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app
local notation "T" => A.K A.B

def Lift (s w : M) := ∀ x, w ⬝ x ⬝ A.q = s ⬝ x

/-- A scalar lifter can carry any chosen value at a second, unconstrained
coordinate. The construction uses ordinary represented finite changes. -/
theorem rich {s w : M} (h : Lift A s w) {t : M} (ht : t ≠ A.q) (z v : M) :
    ∃ w', Lift A s w' ∧ w' ⬝ z ⬝ t = v := by
  let g := patch A (w ⬝ z) t v
  let w' := patch A w z g
  refine ⟨w',?_,?_⟩
  · intro x
    by_cases e : x=z
    · subst x
      calc w' ⬝ z ⬝ A.q = g ⬝ A.q := congrArg (fun t => t ⬝ A.q) (patch_at A _ _ _)
           _ = w ⬝ z ⬝ A.q := patch_away A _ _ _ _ (Ne.symm ht)
           _ = s ⬝ z := h z
    · calc w' ⬝ x ⬝ A.q = w ⬝ x ⬝ A.q := congrArg (fun t => t ⬝ A.q) (patch_away A _ _ _ _ e)
           _ = s ⬝ x := h x
  · calc w' ⬝ z ⬝ t = g ⬝ t := congrArg (fun a => a ⬝ t) (patch_at A _ _ _)
         _ = v := patch_at A _ _ _

theorem qs_conflict {s w : M} (h : A.q ⬝ s ⬝ w = A.q ⬝ w) : s ⬝ w = w := by
  apply Classical.byContradiction
  intro bad
  exact test_ne_B A w (h.symm.trans (A.q_false _ _ bad))

/-- If double evaluation of the range of s omits a value, a good scalar lifter
can also serve the old H(qs,q) separation rule. In the upper interpretation a
strongly Cantorian range has this omission. -/
theorem qs_good {s w t : M} (hw : Lift A s w) (ht : t ≠ A.q)
    (v : M) (omits : ∀ y, s ⬝ y ⬝ A.q ⬝ t ≠ v) :
    ∃ w', Lift A s w' ∧ A.q ⬝ s ⬝ w' ≠ A.q ⬝ w' := by
  obtain ⟨w',hh,hv⟩ := rich A hw ht A.q v
  refine ⟨w',hh,fun e => omits w' ?_⟩
  rw [qs_conflict A e]; exact hv

/-- At a bad sample one finite change combines an arbitrary q-column and a
fixed point. The latter separates q(w) from both Boolean values. -/
theorem qs_bad (s t : M) :
    ∃ w, w ⬝ A.q = t ∧ A.q ⬝ s ⬝ w ≠ A.q ⬝ w := by
  let b := A.K A.q
  have hb : b ≠ A.q := Ne.symm (q_not_const A A.q)
  let w := patch A (A.K t) b b
  have on : w ⬝ b = b := patch_at A _ _ _
  have atq : w ⬝ A.q = t := (patch_away A _ _ _ _ (Ne.symm hb)).trans (A.k_app _ _)
  refine ⟨w,atq,?_⟩
  intro e
  have notT : A.q ⬝ w ≠ T := by
    intro h
    exact A.distinct ((A.q_true _ _ on).symm.trans ((congrArg (fun f => f ⬝ b) h).trans (A.k_app _ _)))
  rcases test_boolean A s w with yes | no
  · exact notT (e.symm.trans yes)
  · exact test_ne_B A w (e.symm.trans no)

/-- Projected local lifts may choose w's off-domain fixed points freely.
Distinct outside points therefore yield distinct old q(w) rows, independent
of any remaining behaviour on the tested domain. -/
theorem different_fixed_profiles (C : M → Prop) {a b w v : M} (outside : ¬C a)
    (neq : a≠b) (aw : ∀ x, ¬C x → (w ⬝ x=x ↔ x=a)) (bv : ∀ x, ¬C x → (v ⬝ x=x ↔ x=b)) :
    A.q ⬝ w ≠ A.q ⬝ v := by
  intro eq
  have good := A.q_true w a ((aw a outside).mpr rfl)
  have bad := A.q_false v a (fun h => neq ((bv a outside).mp h))
  exact A.distinct (good.symm.trans ((congrArg (fun f => f ⬝ a) eq).trans bad))
end SemanticSlots
#print axioms SemanticSlots.rich
#print axioms SemanticSlots.qs_good
#print axioms SemanticSlots.qs_bad
#print axioms SemanticSlots.different_fixed_profiles
