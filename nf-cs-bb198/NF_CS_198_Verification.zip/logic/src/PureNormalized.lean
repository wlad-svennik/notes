import NF188OldBasis
import NF188Tester
import ChoppedFour
import NormalizedBasis

open Classical FFL FFL.FirstOrder FFL.FirstOrder.SetTheory
open NFFn NFFn.NF188Finite
namespace NFCS.Upper
noncomputable section

/-- No relabeling is needed to normalize the tester in the full chart of a
    pure NF model. Both application and K stay the canonical full-chart maps. -/
theorem normalized_full_chart (V : Type) [SetStructure V] [Nonempty V] [V↓[ℒₛₑₜ] ⊧* 𝗡𝗙] :
    ∃ S : NF192.NormalizedBasis V, S.app=oldApp ∧ S.K=oldK ∧ S.B=oldB := by
  let A : NF188.Relabel.Basis V := oldBasis
  obtain ⟨d,hd⟩ := NF188.Pure.four_labels V
  have distinct : A.K A.B ≠ A.B := by
    intro e
    have bfix (x : V) : A.app A.B x = A.B := by rw [←e,A.k_app,e]
    have collapse (v : V) : A.B = v := by
      have h := A.b_app (A.K (A.K v)) (A.K v) A.B
      simpa only [bfix,A.k_app] using h
    have h := hd ((collapse (d 0)).symm.trans (collapse (d 1)))
    exact (by decide : (0 : Fin 4) ≠ 1) h
  obtain ⟨q,hq⟩ := TaggedFixedPoint.exists_tester (A.K A.B) A.B
  have tests (f x : V) := ((hq f _).mp (oldApp_spec q f) x _).mp (oldApp_spec (oldApp q f) x)
  refine ⟨{app:=A.app,K:=A.K,B:=A.B,q:=q,k_app:=A.k_app,b_app:=A.b_app,ext:=A.ext,
           distinct:=distinct,q_true:=?_,q_false:=?_},rfl,rfl,rfl⟩
  · intro f x hit
    exact ((tests f x).resolve_right (fun row => row.1 ((oldApp_iff _ _ _).mpr hit))).2
  · intro f x miss
    exact ((tests f x).resolve_left (fun row => miss ((oldApp_iff _ _ _).mp row.1))).2

end
end NFCS.Upper
#print axioms NFCS.Upper.normalized_full_chart
