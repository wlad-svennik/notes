module
public import PointPatch
@[expose] public section
set_option autoImplicit false
namespace SelectorAbstraction
open NF192
universe u
variable {M : Type u} (A : NormalizedBasis M)
def cons {α : Type u} (a : α) (e : Nat → α) : Nat → α | 0 => a | i+1 => e i
inductive Atom (M : Type u) | var (i : Nat) | par (t : M)
inductive NT (M : Type u) | leaf (m : Nat) (a : Atom M) | app (f x : NT M)

def idT : NT M := .leaf 0 (.par (PointPatch.ident A))
def kpush : NT M → NT M
  | .leaf n a => .leaf (n+1) a
  | .app f x => .app (.app (.leaf 0 (.par A.B)) (kpush f)) (kpush x)
def absNT : Nat → NT M → NT M
  | _, .leaf _ (.var 0) => idT A
  | _, .leaf n (.var (i+1)) => .leaf (n+1) (.var i)
  | _, .leaf n (.par t) => .leaf (n+1) (.par t)
  | j, .app f x => .app (.app (.leaf 0 (.par A.B)) (absNT (j+1) f)) (absNT j x)
def lev : (Nat → Nat) → NT M → Nat → Prop
  | γ,.leaf n (.var i),l => γ i+n=l
  | _,.leaf _ (.par _),_ => True
  | γ,.app f x,l => lev γ f (l+1) ∧ lev γ x l
def good : Nat → NT M → Prop
  | j,.leaf n (.var 0) => n=j
  | _,.leaf _ (.var (_+1)) => True
  | _,.leaf _ (.par _ ) => True
  | j,.app f x => good (j+1) f ∧ good j x
theorem bound (T : NT M) : ∀ (j l k : Nat) (γ : Nat → Nat),
    lev (cons k γ) T l → k+j=l → good j T := by
  induction T with
  | leaf n a =>
    intro j l k γ h e
    cases a with
    | par t => trivial
    | var i =>
      cases i with
      | zero => change k+n=l at h; change n=j; omega
      | succ i => trivial
  | app f x hf hx =>
    intro j l k γ h e
    exact ⟨hf (j+1) (l+1) k γ h.1 (by omega),hx j l k γ h.2 e⟩
theorem lev_abs (T : NT M) : ∀ (j l k : Nat) (γ : Nat → Nat),
    lev (cons k γ) T l → k+j=l → lev γ (absNT A j T) (l+1) := by
  induction T with
  | leaf n a =>
    intro j l k γ h e
    cases a with
    | par t => trivial
    | var i =>
      cases i with
      | zero => trivial
      | succ i => change γ i+n=l at h; change γ i+(n+1)=l+1; omega
  | app f x hf hx =>
    intro j l k γ h e
    exact ⟨⟨trivial,hf (j+1) (l+1) k γ h.1 (by omega)⟩,hx j l k γ h.2 e⟩
theorem lev_push (T : NT M) : ∀ (l : Nat) (γ : Nat → Nat), lev γ T l → lev γ (kpush A T) (l+1) := by
  induction T with
  | leaf n a =>
    intro l γ h
    cases a with
    | par t => trivial
    | var i => change γ i+n=l at h; change γ i+(n+1)=l+1; omega
  | app f x hf hx => intro l γ h; exact ⟨⟨trivial,hf (l+1) γ h.1⟩,hx l γ h.2⟩

def kpow : Nat → M → M | 0,x => x | m+1,x => A.K (kpow m x)
def aval (e : Nat → M) : Atom M → M | .par v => v | .var i => e i
def nval (e : Nat → M) : NT M → M
  | .leaf m a => kpow A m (aval e a)
  | .app f x => A.app (nval e f) (nval e x)
theorem val_push (e : Nat → M) (T : NT M) : nval A e (kpush A T)=A.K (nval A e T) := by
  induction T with
  | leaf n a => rfl
  | app f x hf hx =>
    change A.app (A.app A.B (nval A e (kpush A f))) (nval A e (kpush A x))=_
    rw [hf,hx]; apply A.ext; intro t; simp only [A.b_app,A.k_app,nval]
theorem val_abs (T : NT M) : ∀ j, good j T → ∀ (e : Nat → M) x,
    A.app (nval A e (absNT A j T)) (kpow A j x)=nval A (cons x e) T := by
  induction T with
  | leaf m a =>
    intro j h e x
    cases a with
    | par t => exact A.k_app _ _
    | var i =>
      cases i with
      | zero => change m=j at h; subst j; exact PointPatch.ident_apply A _
      | succ i => exact A.k_app _ _
  | app f x hf hx =>
    intro j h e a
    change A.app (A.app (A.app A.B (nval A e (absNT A (j+1) f))) (nval A e (absNT A j x))) (kpow A j a) = A.app _ _
    rw [A.b_app,hx j h.2 e a]
    exact congrArg (fun v => A.app v (nval A (cons a e) x)) (hf (j+1) h.1 e a)

inductive Tm (M : Type u) : (Nat → Nat) → Nat → Type u where
  | var (γ : Nat → Nat) (n : Nat) : Tm M γ (γ n)
  | par {γ : Nat → Nat} (v : M) (i : Nat) : Tm M γ i
  | app {γ : Nat → Nat} {i : Nat} : Tm M γ (i+1) → Tm M γ i → Tm M γ i
  | k {γ : Nat → Nat} {i : Nat} : Tm M γ i → Tm M γ (i+1)
  | lam {γ : Nat → Nat} {i : Nat} : Tm M (cons i γ) i → Tm M γ (i+1)

def tr {γ : Nat → Nat} {i : Nat} : Tm M γ i → NT M
  | .var _ n => .leaf 0 (.var n)
  | .par v _ => .leaf 0 (.par v)
  | .app f x => .app (tr f) (tr x)
  | .k x => kpush A (tr x)
  | .lam t => absNT A 0 (tr t)
theorem valid {γ : Nat → Nat} {i : Nat} (t : Tm M γ i) : lev γ (tr A t) i := by
  induction t with
  | var γ n => rfl
  | par v n => trivial
  | app f x hf hx => exact ⟨hf,hx⟩
  | k x h => exact lev_push A _ _ _ h
  | lam t h => exact lev_abs A _ 0 _ _ _ h rfl
def val {γ : Nat → Nat} {i : Nat} (e : Nat → M) (t : Tm M γ i) := nval A e (tr A t)
theorem vvar (e : Nat → M) (γ : Nat → Nat) (n : Nat) : val A e (.var γ n)=e n := rfl
theorem vpar {γ : Nat → Nat} (e : Nat → M) (v : M) (i : Nat) : val (γ:=γ) A e (.par v i)=v := rfl
theorem vapp {γ : Nat → Nat} {i : Nat} (e : Nat → M) (f : Tm M γ (i+1)) (x : Tm M γ i) :
    val A e (.app f x)=A.app (val A e f) (val A e x) := rfl
theorem vk {γ : Nat → Nat} {i : Nat} (e : Nat → M) (x : Tm M γ i) : val A e (.k x)=A.K (val A e x) := val_push A e _
theorem vlam {γ : Nat → Nat} {i : Nat} (e : Nat → M) (t : Tm M (cons i γ) i) (x : M) :
    A.app (val A e (.lam t)) x=val A (cons x e) t :=
  val_abs A _ 0 (bound _ 0 i i γ (valid A t) rfl) e x
end SelectorAbstraction
#print axioms SelectorAbstraction.vlam
