import Unshifted198Lower
namespace Unshifted198
open Classical
open NF192.Numerical NF192.Ground
open NF192.Emitter (row0 row9)
open Scope209.Upper (Chart)
noncomputable section
variable {V : Type} (A : Chart V) (sel : V → V)
private noncomputable def evalT : Term → V
  | .q => A.J
  | .app f x => A.app (evalT f) (evalT x)
  | .h .q (.app .q s) => sel (evalT s)
  | .h a b => if a=b then A.K (evalT a) else A.witness (evalT a) (evalT b)

private theorem evalK (t : Term) : evalT A sel (.h t t) = A.K (evalT A sel t) := by
  cases t <;> simp [evalT]

def Separated (A : Chart V) := ∀ s, ∃ w, RPRCore.Law A.app A.K s s w (fun _=>s) ∧
   (A.app (A.app A.J s) w = A.app A.J w → A.J = A.app A.J s)

private theorem evalExt
    (sep : ∀ s, A.app (A.app A.J s) (sel s) = A.app A.J (sel s) → A.J = A.app A.J s)
    (a b : Term) :
    A.app (evalT A sel b) (evalT A sel (.h a b)) =
    A.app (evalT A sel a) (evalT A sel (.h a b)) → evalT A sel a = evalT A sel b := by
  by_cases same : a=b
  · rw [same]; exact fun _ => rfl
  · cases a with
    | app f x => simp only [evalT,if_neg same]; exact A.witness_ext _ _
    | h f x => simp only [evalT,if_neg same]; exact A.witness_ext _ _
    | q =>
      cases b with
      | q => exact (same rfl).elim
      | h f x => simp only [evalT,if_neg same]; exact A.witness_ext _ _
      | app f x =>
        cases f with
        | q => exact sep _
        | app g y => simp only [evalT,if_neg same]; exact A.witness_ext _ _
        | h g y => simp only [evalT,if_neg same]; exact A.witness_ext _ _

private def val (n : Nat) := evalT A sel (decodeTerm n)
private theorem valApp (a b : Nat) : val A sel (app a b) = A.app (val A sel a) (val A sel b) := by
  simp only [val,decodeTerm_app,evalT]
private theorem valK (a : Nat) : val A sel (witness a a) = A.K (val A sel a) := by
  simp only [val,decodeTerm_witness,evalK]
private theorem valJ : val A sel 0 = A.J := by
  change val A sel q = _; simp only [val,decodeTerm_q,evalT]
private theorem valB : val A sel 1 = A.B := by
  change val A sel (app 0 0) = _; rw [valApp,valJ,A.letter]
private theorem valW (a : Nat) : val A sel (witness 0 (app 0 a)) = sel (val A sel a) := by
  change val A sel (witness q (app q a)) = _
  simp only [val,decodeTerm_witness,decodeTerm_q,decodeTerm_app,evalT]
private def rel204 (a b : Nat) := val A sel a = val A sel b

theorem full_ground_of_separated (available : Separated A) :
    ∃ r : Nat → Nat → Prop, (∀ a b c u x, x ∈ fullRows a b c u → evaluate r x) ∧ ¬r s q := by
  let w := fun s => Classical.choose (available s)
  have hw (s) := Classical.choose_spec (available s)
  refine ⟨rel204 A w, ?_,?_⟩
  · intro a b c u x hx
    simp only [fullRows,List.mem_cons,List.not_mem_nil,or_false] at hx
    rcases hx with e|e|e|e|e|e|e|e|e <;> subst x
    · simp only [row0,evaluate_imp]
      intro hca hac _
      by_cases hc : evaluate (rel204 A w) c
      · exact hc
      · exact hac (hca (fun h => False.elim (hc h)))
    · change evaluate _ (eqn (app (witness b b) a) b)
      simpa only [evaluate_eqn,rel204,valApp,valK] using A.k_app (val A w b) (val A w a)
    · change evaluate _ (eqn (app (app (app 1 c) a) b) (app (app c (witness b b)) (app a b)))
      simpa only [evaluate_eqn,rel204,valApp,valK,valB] using A.b_app (val A w c) (val A w a) (val A w b)
    · change evaluate _ (imp (eqn c b) (eqn (app a c) (app a b)))
      simp only [evaluate_imp,evaluate_eqn,rel204,valApp]; exact congrArg (A.app (val A w a))
    · change evaluate _ (imp (eqn a c) (eqn (app c b) (app a b)))
      simp only [evaluate_imp,evaluate_eqn,rel204,valApp]; exact fun e => congrArg (fun t => A.app t (val A w b)) e.symm
    · change evaluate _ (imp (eqn a b) (imp (eqn a c) (eqn c b)))
      simp only [evaluate_imp,evaluate_eqn,rel204]; exact fun h k => k.symm.trans h
    · change evaluate _ (imp (imp (eqn 1 (app (app 0 (witness b b)) a)) (eqn 1 (app (app 0 (witness b b)) b))) (eqn a b))
      simp only [evaluate_imp,evaluate_eqn,rel204,valApp,valK,valJ,valB]
      intro h
      by_cases he : val A w a = val A w b
      · exact he
      · exact False.elim (A.on _ (h (A.off _ _ (Ne.symm he)).symm).symm)
    · let S := a
      let R (t : Nat) := app S (witness t t)
      let P (t : Nat) := app S (app (app t S) S)
      change evaluate _ (imp (eqn (witness 0 (app 0 S)) c) (imp (eqn (app S c) (R (P (R (app S c))))) (eqn (app (app c b) S) (app S b))))
      simp only [evaluate_imp,evaluate_eqn,rel204,R,P,S,valApp,valK,valW]
      intro e z
      rw [←e] at z ⊢
      exact (hw (val A w a)).1 (val A w b) z.symm
    · change evaluate _ (row9 a b)
      simp only [row9,evaluate_imp,evaluate_eqn,rel204,valApp]
      simp only [val,decodeTerm_witness]
      exact evalExt A w (fun v => (hw v).2) _ _
  · change val A w 1 ≠ val A w 0
    rw [valB,valJ]
    exact A.proper


theorem reduced_mem_full {a b c u x : Nat} (m : x ∈ rowList a b c u) : x ∈ fullRows a b c u := by
  by_cases hb : b=0 <;>
    simp [rowList,fullRows,lastRow,NF192.Emitter.row4,konst,eqn,app,hb] at m ⊢ <;> grind

theorem reduced_nonderiv_of_separated (available : Separated A) : ¬Deriv goal := by
  obtain ⟨r,hr,ng⟩ := full_ground_of_separated A available
  exact not_deriv_iff_ground_model.mpr ⟨r,fun a b c u _ x m=>hr a b c u x (reduced_mem_full m),ng⟩

end
end Unshifted198
#print axioms Unshifted198.full_ground_of_separated
#print axioms Unshifted198.reduced_nonderiv_of_separated
