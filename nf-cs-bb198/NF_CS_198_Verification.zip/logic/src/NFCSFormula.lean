import PureCSUpperEnd
open Classical FFL FFL.FirstOrder FFL.FirstOrder.SetTheory
namespace NFCS.Pure
namespace Formula
def one : SetTheorySemisentence 2 := “z a. ∀ c, c ∈ z ↔ c = a”
def up : SetTheorySemisentence 3 := “z a b. ∀ c, c ∈ z ↔ c = a ∨ c = b”
def pair : SetTheorySemisentence 3 := “p a b. ∀ z, z ∈ p ↔ !one z a ∨ !up z a b”
def arrow : SetTheorySemisentence 3 := “r x y. ∃ p, p ∈ r ∧ !pair p x y”
def edge : SetTheorySemisentence 3 := “r a b. ∃ z, !one z a ∧ !arrow r z b”
def cant : SetTheorySemisentence 1 :=
  “d. ∃ r, (∀ p, p ∈ r → ∃ a, ∃ b, ∃ z, a ∈ d ∧ b ∈ d ∧ !one z a ∧ !pair p z b) ∧
    (∀ a, a ∈ d → ∃! b, b ∈ d ∧ !edge r a b) ∧
    (∀ b, b ∈ d → ∃! a, a ∈ d ∧ !edge r a b)”
def sentence : SetTheorySentence :=
  “∀ d, !cant d → ∃ g, ∀ p, p ∈ g ↔ ∃ a, ∃ z, !pair p a z ∧ a ∈ d ∧ !one z a”
section eval
variable {V : Type} [SetStructure V]
@[simp] private theorem evalOne (v : Fin 2 → V) :
    (V ⊧/v one) ↔ Hin.IsSing (v 0) (v 1) := by simp [one,Hin.IsSing]
@[simp] private theorem evalUp (v : Fin 3 → V) :
    (V ⊧/v up) ↔ Hin.IsUp (v 0) (v 1) (v 2) := by simp [up,Hin.IsUp]
@[simp] private theorem evalPair (v : Fin 3 → V) :
    (V ⊧/v pair) ↔ Hin.IsOp (v 0) (v 1) (v 2) := by simp [pair,Hin.IsOp,Function.comp_def]
@[simp] private theorem evalArrow (v : Fin 3 → V) :
    (V ⊧/v arrow) ↔ Hin.Rl (v 0) (v 1) (v 2) := by simp [arrow,Hin.Rl,Function.comp_def]
@[simp] private theorem evalEdge (v : Fin 3 → V) :
    (V ⊧/v edge) ↔ Edge (v 0) (v 1) (v 2) := by simp [edge,Edge,Function.comp_def]
@[simp] private theorem evalCant (v : Fin 1 → V) :
    (V ⊧/v cant) ↔ Cantorian (v 0) := by simp [cant,Cantorian,Function.comp_def]
end eval
theorem models_iff_CS (V : Type) [SetStructure V] [Nonempty V] :
    (V↓[ℒₛₑₜ] ⊧ sentence) ↔ CS V := by
  simp [models_iff,sentence,CS,Function.comp_def]
def theory : SetTheory := 𝗡𝗙 ∪ {sentence}
instance : 𝗘𝗤 _ ⪯ theory :=
  Entailment.WeakerThan.trans (inferInstance : 𝗘𝗤 ℒₛₑₜ ⪯ 𝗡𝗙) (inferInstance : 𝗡𝗙 ⪯ (𝗡𝗙 ∪ {sentence} : SetTheory))

/-- Syntactic consistency of pure NF augmented by its full CS sentence implies
    that the verified scanner source runs forever. -/
theorem source_nonhalting_of_consistent (hc : Entailment.Consistent theory) :
    ¬ ∃ n, ShortCS.Raw.advance n ShortCSRegisterBridge.warmOrigin = NF192.Source.Config.halted := by
  intro he
  apply (Entailment.consistent_iff_unprovable_bot.mp hc)
  apply SetTheory.complete.{0}
  intro V _ _ h
  have : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙 := ⟨fun _ hf => Theory.models V theory (Set.mem_union_left _ hf)⟩
  have ax : V↓[ℒₛₑₜ] ⊧ sentence := Theory.models V theory (Set.mem_union_right _ (Set.mem_singleton _))
  exact (source201_nonhalting_of_model ((models_iff_CS V).mp ax) he).elim
theorem inconsistent_of_source_halts
    (he : ∃ n, ShortCS.Raw.advance n ShortCSRegisterBridge.warmOrigin = NF192.Source.Config.halted) :
    ¬ Entailment.Consistent theory :=
  fun hc => source_nonhalting_of_consistent hc he
end Formula
end NFCS.Pure
#print axioms NFCS.Pure.Formula.source_nonhalting_of_consistent
#print axioms NFCS.Pure.Formula.models_iff_CS
#print axioms NFCS.Pure.Formula.inconsistent_of_source_halts
