module
public import LiftRealization
public import ReadFix
public import DedekindNaturals
public import FunctionCut
@[expose] public section

set_option autoImplicit false

namespace NFUCut.Model
variable {V : Type} [Nonempty V] (M : NFUCut.Model V)
structure RepresentedBij (f a b : V) : Prop where
  dom : ∀ x y, M.mem (M.op x y) f → M.mem x a ∧ M.mem y b
  total : ∀ x, M.mem x a → ∃ y, M.mem (M.op x y) f
  functional : ∀ x y z, M.mem (M.op x y) f → M.mem (M.op x z) f → y = z
  injective : ∀ x y z, M.mem (M.op x z) f → M.mem (M.op y z) f → x = y
  onto : ∀ y, M.mem y b → ∃ x, M.mem (M.op x y) f

def CantorianSets : Prop := ∀ X, M.isSet X → (∃ f, M.RepresentedBij f X (M.simg X)) → M.SC X

end NFUCut.Model

namespace FFL.FirstOrder.FNF.CountSet
noncomputable section
variable {V : Type} [Tarski.Structure ℒλ V] [Tarski.Structure.Eq ℒλ V] [Nonempty V] [V↓[ℒλ] ⊧* 𝗙𝗡𝗙]
theorem to_a0_model (cs : AllCantorian (M:=V)) :
    ∃ M : NFUCut.Model V, ∃ h : Fact M.Infinity, letI := h
      M.CantorianSets ∧ ∃ g, M.isSet g ∧ M.DedekindMap M.nat g M.zero M.succ := by
  classical
  let M := FunctionCut.model (M:=V)
  have inf : M.Infinity := FunctionCut.infinity
  letI : Fact M.Infinity := ⟨inf⟩
  have mm (a b : V) : M.mem a b ↔ Mem a b := Iff.rfl
  have sameSet {x : V} : M.isSet x ↔ IsSet x := Iff.rfl
  have one (a : V) : M.sing a = sing a := M.ext (M.sing_isSet a) (sameSet.mpr isSet_sing) (fun z => M.mem_sing.trans mem_sing.symm)
  have pair (a b : V) : M.up a b = upr a b := M.ext (M.up_isSet a b) (sameSet.mpr isSet_upr) (fun z => M.mem_up.trans mem_upr.symm)
  have op (a b : V) : M.op a b = kp a b := by simp only [NFUCut.Model.op,kp,one,pair]
  have im (X : V) : M.simg X = simg X := by
    apply M.ext (M.simg_isSet X) (sameSet.mpr isSet_simg)
    intro z
    rw [M.mem_simg,mm,mem_simg]
    simp only [one,mm]
  refine ⟨M,⟨inf⟩,?_,M.naturals_dedekind⟩
  rintro X isX ⟨f,h⟩
  have app (a b : V) : M.mem (M.op a b) f ↔ Ap f a b := by rw [op]; rfl
  have b : Bij f X (simg X) := by
    refine ⟨⟨?_,?_,?_,?_⟩,?_⟩
    · intro x y e
      simpa only [im,mm] using h.dom _ _ ((app _ _).mpr e)
    · intro x hx
      obtain ⟨y,hy⟩ := h.total x ((mm _ _).mpr hx)
      exact ⟨y,(app _ _).mp hy⟩
    · intro x y z ey ez
      exact h.functional _ _ _ ((app _ _).mpr ey) ((app _ _).mpr ez)
    · intro x y z ex ey
      exact h.injective _ _ _ ((app _ _).mpr ex) ((app _ _).mpr ey)
    · intro y hy
      have mem : M.mem y (M.simg X) := by simpa only [im,mm] using hy
      obtain ⟨x,hx⟩ := h.onto _ mem
      exact ⟨x,(app _ _).mp hx⟩
  obtain ⟨g,_,eg⟩ := cs X (sameSet.mp isX) ⟨f,b⟩
  exact ⟨g,fun p => by simpa only [mm,op,one] using eg p⟩
end
end FFL.FirstOrder.FNF.CountSet
#print axioms FFL.FirstOrder.FNF.CountSet.to_a0_model

namespace DirectNFU
open FFL FFL.FirstOrder
def HasA0Model : Prop :=
  ∃ V : Type, ∃ nV : Nonempty V, letI := nV
  ∃ M : NFUCut.Model V, ∃ h : Fact M.Infinity, letI := h
  M.CantorianSets ∧ ∃ g, M.isSet g ∧ M.DedekindMap M.nat g M.zero M.succ

theorem a0_of_fixed (fixed : HasFixedSetModel) : HasA0Model := by
  obtain ⟨W,n,s,e,h,q,fs⟩ := fixed
  letI := n; letI := s; letI := e; letI := h
  exact ⟨W,n,FNF.CountSet.to_a0_model (FNF.CountSet.all_cantorian q fs)⟩
end DirectNFU
#print axioms DirectNFU.a0_of_fixed
