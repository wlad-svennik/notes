import RPRBlend
set_option autoImplicit false
open JensenNFU.TFm (scons)
namespace FFL.FirstOrder.FNF.CountSet.RPR
noncomputable section
variable {M : Type} [Tarski.Structure ℒλ M] [Tarski.Structure.Eq ℒλ M] [Nonempty M] [M↓[ℒλ] ⊧* 𝗙𝗡𝗙]
local infixl:70 " ⬝ " => App

def graphTest (e : Nat → M) := ∃ t, e 0 = kp ((((e 1) ⬝ t) ⬝ e 4) ⬝ e 5) (sing (((((e 2) ⬝ t) ⬝ e 3) ⬝ e 5) ⬝ e 6))
def graphB : BT [3,4,4,2,2,1,0] (graphTest (M:=M)) := by
  apply BT.congr (BT.ex 3 (BT.ex 3 (BT.ex 2 (BT.ex 1 (BT.ex 3 (BT.ex 2 (BT.ex 1 (BT.ex 0 (BT.ex 1 ((BT.app 10 8 7 3 rfl rfl rfl).and ((BT.app 7 13 6 2 rfl rfl rfl).and ((BT.app 6 14 5 1 rfl rfl rfl).and ((BT.app 11 8 4 3 rfl rfl rfl).and ((BT.app 4 12 3 2 rfl rfl rfl).and ((BT.app 3 14 2 1 rfl rfl rfl).and ((BT.app 2 15 1 0 rfl rfl rfl).and ((singB.sub [0,1] 0).and (kpB.sub [9,5,0] 1))))))))))))))))))
  intro e
  simp [graphTest,JensenNFU.TFm.scons,nth]

theorem strong_unboxed (s w q D : M) (K : M → M) (kLaw : ∀ a x, K a ⬝ x = a)
    (range : ∀ t, ∃ b, Mem b D ∧ s ⬝ t = K (K b))
    (onto : ∀ b, Mem b D → ∃ t, s ⬝ t = K (K b))
    (lift : ∀ t, (w ⬝ t) ⬝ w = s ⬝ t) : Strong D := by
  obtain ⟨G,hG,H⟩ := (graphB (M:=M)).set (scons s (scons w (scons w (fun _ => q))))
  refine ⟨G,hG,fun z => (H z).trans ?_⟩
  change (∃ t, z = kp (((s ⬝ t) ⬝ q) ⬝ q) (sing (((((w ⬝ t) ⬝ w) ⬝ q) ⬝ q)))) ↔ _
  constructor
  · rintro ⟨t,rfl⟩
    obtain ⟨b,h,eq⟩ := range t
    exact ⟨b,h,by rw [lift,eq,kLaw,kLaw]⟩
  · rintro ⟨b,h,rfl⟩
    obtain ⟨t,eq⟩ := onto b h
    exact ⟨t,by rw [lift,eq,kLaw,kLaw]⟩
end
end FFL.FirstOrder.FNF.CountSet.RPR
#print axioms FFL.FirstOrder.FNF.CountSet.RPR.strong_unboxed
