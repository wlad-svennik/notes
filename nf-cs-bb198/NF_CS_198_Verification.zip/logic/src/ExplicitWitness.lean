import PureNormalized
import RPRCore
import NFRel
set_option autoImplicit false
open Classical FFL FFL.FirstOrder FFL.FirstOrder.SetTheory
open NFFn NFFn.NF188Finite Hin
namespace NFCS.Pure
noncomputable section
section defs
variable {V : Type} [SetStructure V]
def Edge (r a b : V) := ∃ z, IsSing z a ∧ Rl r z b
/-- A Kuratowski graph pairing the singletons of D bijectively with D. -/
def Cantorian (D : V) : Prop := ∃ r : V,
  (∀ p, p ∈ r → ∃ a b z, a∈D ∧ b∈D ∧ IsSing z a ∧ IsOp p z b) ∧
  (∀ a, a∈D → ∃! b, b∈D ∧ Edge r a b) ∧ (∀ b, b∈D → ∃! a, a∈D ∧ Edge r a b)
/-- The singleton function on each Cantorian set is a set of Kuratowski pairs. -/
def CS (V : Type) [SetStructure V] : Prop := ∀ D : V, Cantorian D →
  ∃ G : V, ∀ p, p∈G ↔ ∃ a z, IsOp p a z ∧ a∈D ∧ IsSing z a
end defs
variable {V : Type} [SetStructure V] [Nonempty V] [V↓[ℒₛₑₜ] ⊧* 𝗡𝗙]
local infixl:70 " ⬝ " => oldApp
private def RngD : SDef ![8,9] (fun _ _ v => ∃ x, AppR (v 1) x (v 0)) :=
  ((SDef.ex (τ := ![8,9]) 8 (appD.comp ![2,0,1] 0)))
private def BijD : SDef ![11,9,10] (fun _ _ v => ∃ a z k b, a∈v 1 ∧ IsSing z a ∧ KR a k ∧ AppR (v 2) k b ∧ IsOp (v 0) z b) :=
  ((SDef.ex (τ := ![11,9,10]) 8 (SDef.ex 9 (SDef.ex 9 (SDef.ex 9 ((SDef.mem 3 5).and ((isSingD.comp ![2,3] 8).and ((kD.comp ![3,1] 0).and ((appD.comp ![6,1,0] 1).and (isOpD.comp ![4,2,0] 9))))))))))
private def LiftD : SDef ![9,10,12] (fun _ _ v => ∃ x o a z u, Pr (v 0) x o ∧ AppR (v 1) x a ∧ Rl (v 2) a z ∧ IsSing z u ∧ KR u o) :=
  ((SDef.ex (τ := ![9,10,12]) 9 (SDef.ex 9 (SDef.ex 9 (SDef.ex 9 (SDef.ex 8 ((prD.comp ![5,4,3] 1).and ((appD.comp ![6,4,2] 1).and ((rlD.comp ![7,2,1] 9).and ((isSingD.comp ![1,0] 8).and (kD.comp ![0,3] 0)))))))))))
private theorem rangeSet (s : V) : ∃ D : V, ∀ a, a∈D ↔ ∃ x, s ⬝ x = a := by
  obtain ⟨D,h⟩ := RngD.comprehension ![s]
  exact ⟨D,fun a => (h a).trans (exists_congr (fun x => oldApp_iff s x a))⟩

private theorem raisedGraph (D s : V) : ∃ r : V, ∀ p, p∈r ↔ ∃ a z, a∈D ∧ IsSing z a ∧ IsOp p z (s ⬝ oldK a) := by
  obtain ⟨r,hr⟩ := BijD.comprehension ![D,s]
  refine ⟨r,fun p => (hr p).trans ?_⟩
  change (∃ a z k b, a∈D ∧ IsSing z a ∧ KR a k ∧ AppR s k b ∧ IsOp p z b) ↔ _
  constructor
  · rintro ⟨a,z,k,b,ha,hz,hk,hb,hop⟩
    obtain rfl := k_unique hk (oldK_spec a)
    exact ⟨a,z,ha,hz,((oldApp_iff _ _ _).mp hb).symm ▸ hop⟩
  · rintro ⟨a,z,ha,hz,hop⟩
    exact ⟨a,z,oldK a,s ⬝ oldK a,ha,hz,oldK_spec _,oldApp_spec _ _,hop⟩

private theorem liftedGraph (G s : V) (hg : ∀ a z, Rl G a z ↔ (∃ x, s ⬝ x = a) ∧ IsSing z a) :
    ∃ w : V, ∀ x, w ⬝ x = oldK (s ⬝ x) := by
  obtain ⟨F,h⟩ := LiftD.comprehension ![s,G]
  have graph (p : V) : p∈F ↔ ∃ x o, Pr p x o ∧ o=oldK (s ⬝ x) := by
    apply (h p).trans
    change (∃ x o a z u, Pr p x o ∧ AppR s x a ∧ Rl G a z ∧ IsSing z u ∧ KR u o) ↔ _
    constructor
    · rintro ⟨x,o,a,z,u,hp,ha,hz,hu,ho⟩
      obtain rfl := (oldApp_iff _ _ _).mp ha
      obtain rfl := sing_inj hu ((hg _ _).mp hz).2
      exact ⟨x,o,hp,k_unique ho (oldK_spec _)⟩
    · rintro ⟨x,o,hp,rfl⟩
      obtain ⟨z,hz⟩ := exists_sing (s ⬝ x)
      exact ⟨x,_,_,z,_,hp,oldApp_spec _ _,(hg _ _).mpr ⟨⟨x,rfl⟩,hz⟩,hz,oldK_spec _⟩
  obtain ⟨w,hw⟩ := app_of_graph graph (fun x => ⟨_,rfl⟩) (fun _ _ _ f g => f.trans g.symm)
  exact ⟨w,fun x => (hw _ _).mp (oldApp_spec w x)⟩

/-- The full chart's RPR axiom follows from full CS with actual Kuratowski graphs. -/
theorem localLaw (cs : CS V) (s : V) : ∃ w, RPRCore.Law oldApp oldK s s w id := by
  apply RPRCore.upperChoice
  intro fixes
  obtain ⟨D,hD⟩ := rangeSet s
  let R := RPRCore.R oldApp oldK s
  let P := RPRCore.P oldApp s s
  have rd (a : V) : R a ∈ D := (hD _).mpr ⟨_,rfl⟩
  have pd (a : V) : P a ∈ D := (hD _).mpr ⟨_,rfl⟩
  have identityD (a : V) (ha : a ∈ D) : R (P (R a)) = a := by
    obtain ⟨x,rfl⟩ := (hD _).mp ha
    exact fixes x
  have inj {a b : V} (ha : a∈D) (hb : b∈D) (eq : R a = R b) : a=b :=
    (identityD _ ha).symm.trans ((congrArg (fun t => R (P t)) eq).trans (identityD _ hb))
  obtain ⟨r,hr⟩ := raisedGraph D s
  have edge (a b : V) : Edge r a b ↔ a∈D ∧ R a = b := by
    constructor
    · rintro ⟨z,hz,p,hp,hop⟩
      obtain ⟨a',z',hD',hz',hop'⟩ := (hr p).mp hp
      obtain ⟨rfl,e⟩ := op_inj hop' hop
      obtain rfl := sing_inj hz' hz
      exact ⟨hD',e⟩
    · rintro ⟨ha,rfl⟩
      obtain ⟨z,hz⟩ := exists_sing a
      obtain ⟨p,hp⟩ := exists_op z (R a)
      exact ⟨z,hz,p,(hr _).mpr ⟨a,z,ha,hz,hp⟩,hp⟩
  have dc : Cantorian D := by
    refine ⟨r,?_,?_,?_⟩
    · intro p hp
      obtain ⟨a,z,ha,hz,hp⟩ := (hr _).mp hp
      exact ⟨a,R a,z,ha,rd _,hz,hp⟩
    · intro a ha
      exact ⟨R a,⟨rd _,(edge _ _).mpr ⟨ha,rfl⟩⟩,fun b hb => ((edge _ _).mp hb.2).2.symm⟩
    · intro b hb
      have e := identityD b hb
      exact ⟨P (R b),⟨pd _,(edge _ _).mpr ⟨pd _,e⟩⟩,fun a ha => inj ha.1 (pd _) (((edge _ _).mp ha.2).2.trans e.symm)⟩
  obtain ⟨G,hG⟩ := cs D dc
  have edges (a z : V) : Rl G a z ↔ (∃ x, s ⬝ x = a) ∧ IsSing z a :=
    (rl_of_spec hG a z).trans (and_congr_left (fun _ => hD a))
  obtain ⟨w,hw⟩ := liftedGraph G s edges
  exact ⟨w,fun x => by change (w ⬝ x) ⬝ w = s ⬝ x; rw [hw]; exact (oldK_spec _ _ _).mp (oldApp_spec _ _)⟩

end
end NFCS.Pure
#print axioms NFCS.Pure.localLaw
