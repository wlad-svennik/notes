module
public import GlobalWord
@[expose] public section
namespace NoUniformSelector
open NF192 PointPatch
universe u
variable {M : Type u} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app
local notation "T" => A.K A.B

/-- An internal representative of the external K operation produces a
represented lifted diagonal x ↦ K(xx). A one-point Boolean change then gives
the Russell contradiction without any appeal to an interpreted set theory. -/
theorem no_internal_K (k : M) (hk : ∀ x, k ⬝ x = A.K x) : False := by
  let m := A.B ⬝ A.B ⬝ k
  have hm (x : M) : m ⬝ x = A.K (x ⬝ x) := by
    apply A.ext; intro z
    simp only [m,A.b_app,hk,A.k_app]
  let n := patch A (A.K T) (A.K T) A.B
  let d := GlobalWord.comp A n m
  have diag : d ⬝ d = n ⬝ A.K (d ⬝ d) := (GlobalWord.comp_apply A n m d).trans (congrArg (A.app n) (hm d))
  by_cases hit : d ⬝ d=T
  · rw [hit] at diag
    exact A.distinct (diag.trans (patch_at A _ _ _))
  · have neq : A.K (d ⬝ d) ≠ A.K T := fun h => hit (A.k_inj h)
    exact hit (diag.trans ((patch_away A _ _ _ _ neq).trans (A.k_app _ _)))

theorem no_represented_unbox (j : M) (h : ∀ y, j ⬝ A.K y ⬝ A.q ⬝ A.q = y) : False := by
  let t := GlobalWord.down A A.q j
  let k := GlobalWord.comp A (GlobalWord.readK A A.q) t
  apply no_internal_K A k
  intro x
  simp only [k,t,GlobalWord.comp_apply,GlobalWord.readK_apply,GlobalWord.down_apply,h]

theorem scalar_selector (dual : Bool) (j : M)
    (hw : ∀ s, SplitRange.Clause dual A s (j ⬝ s)) : False := by
  apply no_represented_unbox A j
  intro y
  have on : SplitRange.word dual A (A.K y) (j ⬝ A.K y) = A.K y ⬝ (j ⬝ A.K y) := by
    cases dual <;> simp only [SplitRange.word,Bool.false_eq_true,reduceIte,
      RangeCS.R,RangeCS.P,RawSuffix.L,RawSuffix.D,A.k_app]
  exact (hw _ on A.q).trans (A.k_app _ _)

/-- The opposite failure, an internal left inverse to K, represents ordinary
self-application directly and gives a fixed point of q. -/
theorem no_internal_read (u : M) (hu : ∀ x, u ⬝ A.K x = x) : False := by
  let m := A.B ⬝ u ⬝ ident A
  have hm (x : M) : m ⬝ x = x ⬝ x := by simp only [m,A.b_app,hu,ident_apply]
  let d := GlobalWord.comp A A.q m
  exact A.q_no_fixed (d ⬝ d) ((congrArg (A.app A.q) (hm d)).symm.trans
    (GlobalWord.comp_apply A A.q m d).symm)

theorem constant_guard (dual : Bool) (y w : M) :
    SplitRange.word dual A (A.K y) w = A.K y ⬝ w := by
  cases dual <;> simp only [SplitRange.word,Bool.false_eq_true,reduceIte,
    RangeCS.R,RangeCS.P,RawSuffix.L,RawSuffix.D,A.k_app]

theorem read_rhs_selector (dual : Bool) (j : M) (read : M → M → M)
    (hw : ∀ s, SplitRange.word dual A s (j ⬝ s) = s ⬝ (j ⬝ s) →
      ∀ x, j ⬝ s ⬝ x = s ⬝ x ⬝ read s x) : False := by
  apply no_internal_read A (GlobalWord.down A A.q j)
  intro y
  rw [GlobalWord.down_apply]
  exact (hw (A.K (A.K y)) (constant_guard A dual _ _) A.q).trans (by simp only [A.k_app])

theorem projected_selector (dual : Bool) (j : M)
    (hw : ∀ s, SplitRange.word dual A s (j ⬝ s) = s ⬝ (j ⬝ s) →
      ∀ x, j ⬝ s ⬝ (s ⬝ x) ⬝ A.q = s ⬝ x) : False := by
  let t := A.B ⬝ j ⬝ ident A
  let k := GlobalWord.comp A (GlobalWord.readK A A.q) t
  apply no_internal_K A k
  intro y
  have hh := hw (A.K y) (constant_guard A dual _ _) A.q
  simp only [A.k_app] at hh
  simp only [k,t,GlobalWord.comp_apply,GlobalWord.readK_apply,A.b_app,ident_apply,hh]
end NoUniformSelector
#print axioms NoUniformSelector.no_internal_K
#print axioms NoUniformSelector.no_represented_unbox
#print axioms NoUniformSelector.scalar_selector
#print axioms NoUniformSelector.no_internal_read
#print axioms NoUniformSelector.read_rhs_selector
#print axioms NoUniformSelector.projected_selector
