module
public import ShiftedFork
@[expose] public section
set_option autoImplicit false
namespace FiniteMenuProbe
open NF192 PointPatch
universe u
variable {M : Type u} (A : NormalizedBasis M)
local infixl:75 " ⬝ " => A.app
local notation "T" => A.K A.B
def beta (z : M) := ShiftedFork.S A z
def fixed (t : M) := t=A.B ∨ t=T ∨ t=A.K T
def covered (z t : M) := fixed A t ∨ t=beta A z
def row (z : M) : M :=
  patch A (patch A (patch A (patch A (A.K (beta A z)) A.B A.B) T A.B) (A.K T) A.B) (beta A z) A.B

theorem on (z t : M) (h : covered A z t) : row A z ⬝ t=A.B := by
  unfold row
  by_cases hb : t=beta A z
  · rw [hb,patch_at]
  rw [patch_away A _ _ _ _ hb]
  by_cases hkt : t=A.K T
  · rw [hkt,patch_at]
  rw [patch_away A _ _ _ _ hkt]
  by_cases ht : t=T
  · rw [ht,patch_at]
  rw [patch_away A _ _ _ _ ht]
  rcases h with (hh|hh|hh)|hh
  · rw [hh,patch_at]
  · exact (ht hh).elim
  · exact (hkt hh).elim
  · exact (hb hh).elim

theorem away (z t : M) (h : ¬covered A z t) : row A z ⬝ t=beta A z := by
  unfold row
  rw [patch_away A _ _ _ _ (fun he => h (Or.inr he)),
      patch_away A _ _ _ _ (fun he => h (Or.inl (Or.inr (Or.inr he)))),
      patch_away A _ _ _ _ (fun he => h (Or.inl (Or.inr (Or.inl he)))),
      patch_away A _ _ _ _ (fun he => h (Or.inl (Or.inl he))),A.k_app]

theorem b_ne_B (z : M) : beta A z ≠ A.B := test_ne_B A _
theorem b_ne_K (z t : M) : beta A z ≠ A.K t := delta_not_constant A _ _
theorem b_ne_q (z : M) : beta A z ≠ A.q := Ne.symm (q_ne_delta A _)
theorem b_out (z : M) : ¬fixed A (beta A z) := by
  rintro (e|e|e)
  · exact b_ne_B A z e
  · exact b_ne_K A z _ e
  · exact b_ne_K A z _ e

theorem q_out (z : M) : ¬covered A z A.q := by
  rintro ((e|e|e)|e)
  · exact q_ne_b A e
  · exact q_not_const A _ e
  · exact q_not_const A _ e
  · exact b_ne_q A z e.symm

theorem k_out (z : M) : ¬covered A z (A.K (beta A z)) := by
  rintro ((e|e|e)|e)
  · exact CalibratedSlots.b_not_constant A _ e.symm
  · exact b_ne_B A z (A.k_inj e)
  · exact b_ne_K A z _ (A.k_inj e)
  · exact b_ne_K A z _ e.symm

theorem kk_out (z : M) : ¬covered A z (A.K (A.K (beta A z))) := by
  rintro ((e|e|e)|e)
  · exact CalibratedSlots.b_not_constant A _ e.symm
  · exact CalibratedSlots.b_not_constant A _ (A.k_inj e).symm
  · exact b_ne_B A z (A.k_inj (A.k_inj e))
  · exact b_ne_K A z _ e.symm

theorem bq (z : M) : beta A z ⬝ A.q=A.B := diff A (ShiftedFork.yq A z)
theorem rng (z t : M) : row A z ⬝ t=A.B ∨ row A z ⬝ t=beta A z := by
  by_cases h : covered A z t
  · exact Or.inl (on A z t h)
  · exact Or.inr (away A z t h)

theorem action (z : M) :
    RangeCS.R A (row A z) A.B=A.B ∧ RangeCS.R A (row A z) (beta A z)=beta A z ∧
    RangeCS.P A (row A z) A.B=A.B ∧ RangeCS.P A (row A z) (beta A z)=beta A z ∧
    RawSuffix.L A (row A z) A.B=beta A z ∧ RawSuffix.L A (row A z) (beta A z)=A.B ∧
    RawSuffix.D A (row A z) A.B=A.B ∧ RawSuffix.D A (row A z) (beta A z)=beta A z := by
  refine ⟨on A z T (Or.inl (Or.inr (Or.inl rfl))),away A z _ (k_out A z),?_,?_,?_,?_,
    on A z _ (Or.inl (Or.inr (Or.inr rfl))),away A z _ (kk_out A z)⟩
  · rw [RangeCS.P,RawSuffix.bq,A.qq_eq_kb]
    exact on A z T (Or.inl (Or.inr (Or.inl rfl)))
  · rw [RangeCS.P,bq,RawSuffix.bq]; exact away A z _ (q_out A z)
  · rw [RawSuffix.L,RawSuffix.bq]; exact away A z _ (q_out A z)
  · rw [RawSuffix.L,bq]; exact on A z _ (Or.inl (Or.inl rfl))

theorem guards (dual : Bool) (z w : M) :
    SplitRange.word dual A (row A z) w = row A z ⬝ w := by
  obtain ⟨rB,rb,pB,pb,lB,lb,dB,db⟩ := action A z
  rcases rng A z w with hit|hit <;>
    cases dual <;> simp only [SplitRange.word,Bool.false_eq_true,reduceIte,hit,rB,rb,pB,pb,lB,lb,dB,db]

def Decode (a t : M) := ∃ h, a ⬝ h=T ∧ t=ShiftedFork.three A h

theorem decode (z t : M) : Decode A (beta A z) t ↔ t=z := by
  constructor
  · rintro ⟨h,hh,ht⟩
    have eq : h=ShiftedFork.Y A z := by
      apply Classical.byContradiction; intro ne
      exact A.distinct (hh.symm.trans (diff A ne))
    exact ht.trans (eq ▸ ShiftedFork.three_y A z)
  · intro eq; exact ⟨ShiftedFork.Y A z,same A _,eq.trans (ShiftedFork.three_y A z).symm⟩

theorem two_reads (dual : Bool) (z w : M) (hw : SplitRange.Clause dual A (row A z) w) :
    w ⬝ A.q ⬝ A.q=beta A z ∧ ∀ a, (¬fixed A a ∧ w ⬝ a ⬝ A.q=A.B) ↔ a=beta A z := by
  have lift := hw (guards A dual z w)
  refine ⟨(lift A.q).trans (away A z _ (q_out A z)),fun a => ?_⟩
  constructor
  · rintro ⟨off,hit⟩; apply Classical.byContradiction; intro ne
    have outside : ¬covered A z a := fun ee => ee.elim off ne
    exact b_ne_B A z (((away A z a outside).symm.trans (lift a).symm).trans hit)
  · intro e; subst a
    exact ⟨b_out A z,(lift _).trans (on A z _ (Or.inr rfl))⟩
theorem beta_inj {z t : M} (h : beta A z=beta A t) : z=t :=
  A.k_inj (A.k_inj (A.k_inj (delta_inj A h)))

theorem atomic (dual : Bool) (z w : M) (hw : SplitRange.Clause dual A (row A z) w) (t : M) :
    ((w ⬝ A.q ⬝ A.q=beta A t) ↔ t=z) ∧ (((w ⬝ beta A t) ⬝ A.q=A.B) ↔ t=z) := by
  obtain ⟨read,mark⟩ := two_reads A dual z w hw
  constructor
  · rw [read]
    exact ⟨fun e => (beta_inj A e).symm,fun e => congrArg (beta A) e.symm⟩
  · constructor
    · intro e
      exact beta_inj A ((mark _).mp ⟨b_out A t,e⟩)
    · intro e
      exact ((mark _).mpr (congrArg (beta A) e)).2

end FiniteMenuProbe
#print axioms FiniteMenuProbe.guards
#print axioms FiniteMenuProbe.decode
#print axioms FiniteMenuProbe.two_reads

#print axioms FiniteMenuProbe.atomic
