import RPRCantorian
import Scope209ChartExact
import WeakCalibration
import A0Models
set_option autoImplicit false
open FFL FFL.FirstOrder
namespace NFCS.Lower
noncomputable section

/-- The actual chart in the original 205-state calibration gives the same A₀
    predicate as the older 215-state machine, directly from the RPR law. -/
theorem a0_of_chart {V : Type} (A : Scope209.Upper.Chart V) (law : Scope209.Upper.LocalLaw A) :
    DirectNFU.HasA0Model := by
  let G : NF188.Relabel.Basis V := {
    app:=A.app,K:=A.K,B:=A.B,k_app:=A.k_app,b_app:=A.b_app,
    ext:=fun {f g} eq => A.witness_ext f g (eq _).symm }
  letI : Nonempty V := ⟨A.J⟩
  letI : ArbitraryBoolean.Basis V := NF196.Weak.weakBasis G A.J A.B A.off A.on
  letI : Tarski.Structure ℒλ V := ArbitraryBoolean.fnStructure
  letI : Tarski.Structure.Eq ℒλ V := ⟨fun _ _ => Iff.rfl⟩
  letI : V↓[ℒλ] ⊧* 𝗙𝗡𝗙 := ArbitraryBoolean.fnModel_models
  have cs := FNF.CountSet.RPR.all_cantorian_of_local A.K A.k_app law
  exact ⟨V,inferInstance,FNF.CountSet.to_a0_model cs⟩

theorem a0_of_nonderiv (h : ¬ Scope209.Deriv NF192.Numerical.goal) : DirectNFU.HasA0Model := by
  obtain ⟨_,A,law⟩ := Scope209.nonderivable_iff_chart_exists.mp h
  exact a0_of_chart A law
end
end NFCS.Lower
#print axioms NFCS.Lower.a0_of_chart
#print axioms NFCS.Lower.a0_of_nonderiv
