module
public import NumericalEmitterBatch
public import NumericalSemantics

@[expose] public section

/-! Register effects for the two changed row sequences, with the literal
register assignment and postfix stream taken from the portable source check. -/
set_option maxHeartbeats 0
set_option maxRecDepth 50000
namespace CS217
open NF192 NF192.Numerical NF192.Emitter

def extRow (a b : Nat) : Nat :=
  (imp (eqn (app b (witness q (app a b))) (app a (witness q (app a b)))) (eqn a b))

def extTokens : List Macro :=
  [.push5, .push0, .push4, .push5, .ap, .witness, .ap, .push4, .push0, .push4, .push5, .ap, .witness, .ap, .eqn, .push4, .push5, .eqn, .imp]

theorem ext_effect (n t stack c a b tail : Nat) :
    extTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
      ⟨n,extRow a b,pair t stack,c,a,b,tail⟩ := by
  simp only [extTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, extRow, imp, eqn, app, witness, q, Nat.add_zero] <;> rfl

def fixedRow (u v x : Nat) : Nat :=
  (imp (eqn (app u (app v x)) x) (imp (eqn (app v (app u (witness (app u v) q))) (witness (app u (app v (app (witness (app u v) q) q))) (app u (app v (app (witness (app u v) q) q))))) (eqn (app (app (witness (app u v) q) x) q) x)))

def fixedTokens : List Macro :=
  [.push3, .push4, .push5, .ap, .ap, .push5, .eqn, .push4, .push3, .push3, .push4, .ap, .push0, .witness, .ap, .ap, .push3, .push4, .push3, .push4, .ap, .push0, .witness, .push0, .ap, .ap, .ap, .push3, .push4, .push3, .push4, .ap, .push0, .witness, .push0, .ap, .ap, .ap, .witness, .eqn, .push3, .push4, .ap, .push0, .witness, .push5, .ap, .push0, .ap, .push5, .eqn, .imp, .imp]

theorem fixed_effect (n t stack c a b tail : Nat) :
    fixedTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
      ⟨n,fixedRow c a b,pair t stack,c,a,b,tail⟩ := by
  simp only [fixedTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, fixedRow, imp, eqn, app, witness, q, Nat.add_zero] <;> rfl

def rowList (a b c u : Nat) : List Nat :=
  [row0 a b c u,row1 a b,row2 a b c,row4 a b,row3 a b c,
   row5 a b c,row6 a b c,row7 a b,extRow a b,fixedRow c a b]

def suffix : List Macro := tokens0 ++ tokens1 ++ tokens2 ++ tokens4 ++ tokens3 ++
  tokens5 ++ tokens6 ++ tokens7 ++ extTokens ++ fixedTokens ++ [.clear4,.clear5]
def batchCode : Code := sequence .read5 suffix

theorem batch_effect (n t stack c u v y delta tail : Nat) :
    suffix.foldl Frame.apply (Frame.apply ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩ .read5) =
      save ⟨n,t,stack,c,0,0,tail⟩ (rowList (u+delta) (v+y) c u) := by
  simp only [suffix, List.foldl_append, Frame.apply, Cantor.unpair_pair]
  rw [effect0, effect1, effect2, effect4, effect3, effect5, effect6, effect7, ext_effect, fixed_effect]
  rfl

theorem batch_eval (n t stack c u v y delta tail : Nat) :
    Eval batchCode (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩) .normal
      (save ⟨n,t,stack,c,0,0,tail⟩ (rowList (u+delta) (v+y) c u)).regs := by
  rw [← batch_effect n t stack c u v y delta tail]
  exact sequence_eval .read5 suffix _

inductive Deriv : Nat → Prop where
  | row {a b c u x : Nat} (h : u ≤ a) (hx : x ∈ rowList a b c u) : Deriv x
  | mp {a b : Nat} : Deriv (imp a b) → Deriv a → Deriv b

theorem deriv_zero : Deriv 0 := .row (a:=0) (b:=0) (c:=0) (u:=0) (Nat.le_refl _) (.head _)

end CS217
#print axioms CS217.fixed_effect
#print axioms CS217.batch_eval
