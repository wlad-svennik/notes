import RPRCurry
import LiftRealization
set_option autoImplicit false
open JensenNFU.TFm (scons)
namespace FFL.FirstOrder.FNF.CountSet.RPR
noncomputable section
variable {M : Type} [Tarski.Structure ℒλ M] [Tarski.Structure.Eq ℒλ M] [Nonempty M] [M↓[ℒλ] ⊧* 𝗙𝗡𝗙]
local instance (p : Prop) : Decidable p := Classical.propDecidable p
local infixl:70 " ⬝ " => App

def blendTest (e : Nat → M) := (Mem (e 3) (e 4) ∧ Mem (e 0) ((e 7 ⬝ ((e 5 ⬝ e 3) ⬝ e 6)) ⬝ e 1)) ∨ (¬Mem (e 3) (e 4) ∧ Mem (e 0) (e 9 ⬝ ((e 3 ⬝ e 6) ⬝ e 8)))

def blendB : BT [0,1,2,3,4,4,2,3,1,2] (blendTest (M:=M)) := by
  apply BT.congr (((BT.mem 3 4 3 rfl rfl).and (BT.ex 3 (BT.ex 2 (BT.ex 2 (BT.ex 1 ((BT.app 9 7 3 3 rfl rfl rfl).and ((BT.app 3 10 2 2 rfl rfl rfl).and ((BT.app 11 2 1 2 rfl rfl rfl).and ((BT.app 1 5 0 1 rfl rfl rfl).and (BT.mem 4 0 0 rfl rfl)))))))))).or (((BT.mem 3 4 3 rfl rfl).not).and (BT.ex 2 (BT.ex 1 (BT.ex 1 ((BT.app 6 9 2 2 rfl rfl rfl).and ((BT.app 2 11 1 1 rfl rfl rfl).and ((BT.app 12 1 0 1 rfl rfl rfl).and (BT.mem 3 0 0 rfl rfl)))))))))
  intro e
  simp [blendTest, JensenNFU.TFm.scons]

/-- The two already represented maps supplied by SingletonCover.realizeUV
    can be combined into the single selector required by the RPR rule. -/
theorem exists_blend (D u v q : M) (K : M → M) (kLaw : ∀ a x, K a ⬝ x = a)
    (vconst : ∀ t x, (v ⬝ t) ⬝ x = (v ⬝ t) ⬝ q)
    (leftSet : ∀ t, IsSet ((v ⬝ t) ⬝ q)) (rightSet : ∀ t, IsSet (u ⬝ t)) :
    ∃ s, ∀ t, s ⬝ t = if Mem t D then K (v ⬝ ((v ⬝ t) ⬝ q)) else K (K (u ⬝ ((t ⬝ q) ⬝ q))) := by
  classical
  let env := scons D (scons v (scons q (scons v (scons q (fun _ => u)))))
  obtain ⟨s,hs⟩ := curry4 (M:=M) blendB env
  refine ⟨s,fun t => fn_ext (M:=M) inferInstance (fun b => fn_ext (M:=M) inferInstance (fun c => fn_ext (M:=M) inferInstance (fun d => ?_)))⟩
  have h := hs t b c d
  change s ⬝ t ⬝ b ⬝ c ⬝ d = bool ((Mem t D ∧ Mem d ((v ⬝ ((v ⬝ t) ⬝ q)) ⬝ c)) ∨ (¬Mem t D ∧ Mem d (u ⬝ ((t ⬝ q) ⬝ q)))) at h
  by_cases hit : Mem t D
  · rw [if_pos hit,kLaw,h,vconst _ c]
    apply Eq.trans _ (characteristic_mem _ _ (leftSet _)).symm
    exact bool_congr (by simp [hit])
  · rw [if_neg hit,kLaw,kLaw,h]
    apply Eq.trans _ (characteristic_mem _ _ (rightSet _)).symm
    exact bool_congr (by simp [hit])

end
end FFL.FirstOrder.FNF.CountSet.RPR
#print axioms FFL.FirstOrder.FNF.CountSet.RPR.exists_blend
