module
public import RawSuffix
public import NumericalModel
public import NumericalAxioms
@[expose] public section
namespace SplitRange
open NF192 NF192.Numerical NF192.Ground NF192.Emitter
universe v
variable {M : Type v}
def extRow (a b : Nat) : Nat :=
  imp (eqn (app b (witness q (app a b))) (app a (witness q (app a b)))) (eqn a b)
def Wcode (a : Nat) := witness a q
def rawR (a x : Nat) := app a (konst x)
def rawP (a x : Nat) := app a (app (app x q) q)
def rawL (a x : Nat) := app a (app x q)
def rawD (a x : Nat) := app a (konst (konst x))
def rule (dual : Bool) (a x : Nat) : Nat :=
  let w := Wcode a
  let b := app a w
  imp (eqn (if dual then rawL a (rawD a (rawL a b)) else rawR a (rawP a (rawR a b))) b) (eqn (app (app w x) q) (app a x))
def rowList (dual : Bool) (a b c u : Nat) : List Nat :=
  [row0 a b c u,row1 a b,row2 a b c,row4 a b,row3 a b c,row5 a b c,
   row6 a b c,row7 a b,extRow a b,rule dual a b]
def RowsHold (dual : Bool) (r : Nat → Nat → Prop) : Prop :=
  ∀ a b c u, u ≤ a → ∀ y ∈ rowList dual a b c u, evaluate r y


def word (dual : Bool) (A : NormalizedBasis M) (s w : M) :=
  let b := A.app s w
  if dual then RawSuffix.L A s (RawSuffix.D A s (RawSuffix.L A s b))
  else RangeCS.R A s (RangeCS.P A s (RangeCS.R A s b))
def Clause (dual : Bool) (A : NormalizedBasis M) (s w : M) :=
  word dual A s w = A.app s w → ∀ x, A.app (A.app w x) A.q = A.app s x
def HasProbes (dual : Bool) (A : NormalizedBasis M) := ∀ s, ∃ w, Clause dual A s w

def normalizedSignature : Signature Nat where
  q := q
  app := app
  h := fun a b => if a = b then konst a else witness q (app a b)

theorem normalized_k (a : Nat) : normalizedSignature.k a = konst a := by
  simp [Signature.k,normalizedSignature]

private theorem instantiate {r} (hr : RowsHold dual r) (a b c : Nat) {x : Nat}
    (hx : x ∈ rowList dual a b c 0) : evaluate r x := hr a b c 0 (Nat.zero_le _) x hx

set_option maxHeartbeats 4000000 in
theorem core {r} (hr : RowsHold dual r) : Rows normalizedSignature r := by
  have pos (a b) := instantiate hr a b 0 (x:=row1 a b) (by simp [rowList])
  have arg (a b c) := instantiate hr a b c (x:=row2 a b c) (by simp [rowList])
  have con (a b) := instantiate hr a b 0 (x:=row4 a b) (by simp [rowList])
  have fnc (a b c) := instantiate hr a b c (x:=row3 a b c) (by simp [rowList])
  have abs (a b c) := instantiate hr a b c (x:=row5 a b c) (by simp [rowList])
  have euc (a b c) := instantiate hr a b c (x:=row6 a b c) (by simp [rowList])
  have neg (a b) := instantiate hr a b 0 (x:=row7 a b) (by simp [rowList])
  have ext (a b) := instantiate hr a b 0 (x:=extRow a b) (by simp [rowList])
  simp only [row1,row2,row4,row3,row5,row6,row7,extRow,evaluate_imp,evaluate_eqn,goal] at *
  constructor
  · exact pos
  · exact arg
  · intro a b; rw [normalized_k]; exact con a b
  · exact fnc
  · intro a b c; rw [normalized_k]; exact abs a b c
  · exact euc
  · exact neg
  · intro a b h
    by_cases eq : a = b
    · subst b
      exact euc _ a a (con q a) (con q a)
    · apply ext a b
      simpa [normalizedSignature,eq] using h


private theorem hasProbes_of_model {dual r} (rr : RowsHold dual r) (hg : ¬r s q) :
    HasProbes dual ((core rr).toBasis hg) := by
  let H := core rr
  have hk (t : Nat) : H.kObj (H.obj t) = H.obj (konst t) := congrArg H.obj (normalized_k t)
  intro s0
  refine Quotient.inductionOn s0 ?_
  intro si
  let w := Wcode si
  refine ⟨H.obj w,?_⟩
  intro good x
  refine Quotient.inductionOn x ?_
  intro xi
  have hx := instantiate rr si xi 0 (x:=rule dual si xi) (by simp [rowList])
  simp only [rule,evaluate_imp,evaluate_eqn] at hx
  apply H.obj_eq_iff.mpr
  apply hx
  apply H.obj_eq_iff.mp
  cases dual
  · change H.obj (rawR si (rawP si (rawR si (app si w)))) = H.obj (app si w)
    change H.appObj (H.obj si) (H.kObj (H.appObj (H.obj si) (H.appObj (H.appObj (H.appObj (H.obj si) (H.kObj (H.obj (app si w)))) (H.obj q)) (H.obj q)))) = H.obj (app si w) at good
    rw [hk] at good
    change H.appObj (H.obj si) (H.kObj (H.obj (app si (app (app (app si (konst (app si w))) q) q)))) = H.obj (app si w) at good
    rw [hk] at good
    exact good
  · change H.obj (rawL si (rawD si (rawL si (app si w)))) = H.obj (app si w)
    change H.appObj (H.obj si) (H.appObj (H.appObj (H.obj si) (H.kObj (H.kObj (H.obj (rawL si (app si w)))))) (H.obj q)) = H.obj (app si w) at good
    rw [hk,hk] at good
    exact good

section Interpret
variable (A : NormalizedBasis M) (W : M → M)
noncomputable def evalTerm : Term → M
  | .q => A.q
  | .app a b => A.app (evalTerm a) (evalTerm b)
  | .h .q (.app a b) => Interpretation.witness A (evalTerm a) (evalTerm b)
  | .h a .q => W (evalTerm a)
  | .h a _ => A.K (evalTerm a)
noncomputable def value (n : Nat) : M := evalTerm A W (decodeTerm n)
theorem value_q : value A W q = A.q := by simp [value,evalTerm]
theorem value_app (a b : Nat) : value A W (app a b) = A.app (value A W a) (value A W b) := by simp [value,evalTerm]
theorem value_const (hw : W A.q = A.K A.q) (a) : value A W (witness a a) = A.K (value A W a) := by
  simp only [value,decodeTerm_witness]
  cases decodeTerm a <;> simp [evalTerm,hw]
theorem value_ext (a b) : value A W (witness q (app a b)) = Interpretation.witness A (value A W a) (value A W b) := by simp [value,evalTerm]
theorem value_probe (a) : value A W (witness a q) = W (value A W a) := by
  simp only [value,decodeTerm_witness,decodeTerm_q]
  cases decodeTerm a <;> rfl
set_option maxHeartbeats 4000000 in
theorem valid_rows {dual : Bool} (diag : W A.q = A.K A.q) (hw : ∀ s, Clause dual A s (W s)) : RowsHold dual (fun a b => value A W a = value A W b) := by
  intro a b c u h x hx
  simp only [rowList,List.mem_cons,List.not_mem_nil,or_false] at hx
  rcases hx with hf|hf|hf|hf|hf|hf|hf|hf|hf|hf <;> subst x
  · simp only [row0,evaluate_imp]
    intro hca hac _
    by_cases hc : evaluate (fun i j => value A W i = value A W j) c
    · exact hc
    · exact hac (hca (fun hc' => (hc hc').elim))
  all_goals simp only [row1,row2,row4,row3,row5,row6,row7,extRow,rule,rawR,rawP,rawL,rawD,Wcode,evaluate_imp,
      evaluate_eqn,goal,B,s,konst,value_ext,value_probe,value_const A W diag,value_app,value_q,A.qq_eq_kb,A.k_app]
  · intro he; exact (A.q_true _ _ he).symm
  · intro he; rw [he]
  · intro he; rw [he]
  · exact A.b_app _ _ _
  · intro h1 h2; exact h2.symm.trans h1
  · intro h; exact (A.q_false _ _ (fun e => A.qq_ne_q (A.qq_eq_kb.trans (h e)))).symm
  · exact Interpretation.witness_ext A _ _
  · cases dual <;> simpa only [Bool.false_eq_true,reduceIte,word,Clause,
        RawSuffix.L,RawSuffix.D,RangeCS.R,RangeCS.P,value_app,value_const A W diag,value_probe,value_q] using hw (value A W a) (x := value A W b)
end Interpret

theorem countermodel_iff (dual : Bool) : (∃ r, RowsHold dual r ∧ ¬r s q) ↔
    ∃ M : Type, ∃ A : NormalizedBasis M, HasProbes dual A := by
  constructor
  · rintro ⟨r,h,hg⟩
    exact ⟨(core h).Carrier,(core h).toBasis hg,hasProbes_of_model h hg⟩
  · rintro ⟨M,A,h⟩
    classical
    let W := fun t => if t = A.q then A.K A.q else Classical.choose (h t)
    have diag : W A.q = A.K A.q := by simp [W]
    have spec (t : M) : Clause dual A t (W t) := by
      by_cases eq : t=A.q
      · subst t
        rw [diag]
        intro activate
        cases dual
        · exact False.elim (RawSuffix.split_diagonal A activate)
        · exact False.elim (RawSuffix.dual_split_diagonal A activate)
      · simpa [W,eq] using Classical.choose_spec (h t)
    refine ⟨fun a b => value A W a = value A W b,valid_rows A W diag spec,?_⟩
    simpa only [s,value_app,value_q] using A.qq_ne_q
end SplitRange
#print axioms SplitRange.countermodel_iff
