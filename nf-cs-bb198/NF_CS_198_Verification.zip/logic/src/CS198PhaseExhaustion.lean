import CS198PhaseRealization
namespace CS198.Scanner
open NF180Counting.CensusMarker
open NF192.Numerical CacheBound Phase

/-- Following the last nonzero cursor, finish the present command by reading zero fields.
Only the numeric cache of a non-AX command may be arbitrary. -/
inductive CommandExit (t h : Nat) : Nat → Nat → Prop where
  | ordinary (newH : Nat) (hsmall : t≤1) : CommandExit t h 0 newH
  | ax (a : Nat) (hbig : 2≤t) : CommandExit t h (literalAX t h).carry (testRow (literalAX t h).lastB a)

def exhausted (v : Nat) : Control → Nat → Nat → Prop
  | .tag r h => CommandExit (r+v) h
  | .arg t h => CommandExit t h
  | .data _ r h => fun r' h' => r'=r ∧ h'=h

def finalBudget (D v : Nat) : Control → Prop
  | .tag r _ => r+v≤D
  | .arg t _ => t≤D
  | .data .. => True

def goodExit (allow : Bool) (r h : Nat) : Prop := if allow then r≤h else r=0

private theorem zero_good (allow : Bool) (h : Nat) : goodExit allow 0 h := by cases allow <;> simp [goodExit]
private theorem huge_exit {D t h r' h' : Nat} (allow : Bool) (bound : t≤D) (hk : 2*D≤h)
    (con : CommandExit t h r' h') : goodExit allow r' h' := by
  cases con with
  | ordinary h' sm => exact zero_good ..
  | ax a big => rw [(huge_invariant bound hk a).1]; exact zero_good ..

/-- Every positively escaped field yields the advertised end-of-epoch rank/cache postcondition,
including escape while reading a tag, an immediate, or any outstanding batch field. -/
theorem crossing_realization {D v : Nat} {p c} {r' h' : Nat} {allow : Bool}
    (hD : 22≤D) (h : Real D p c) (budget : finalBudget D v c) (con : exhausted v c r' h')
    (cert : crossing allow p = true) : goodExit allow r' h' := by
  cases h with
  | tag r k h hk =>
    cases k with
    | huge => exact huge_exit allow budget hk con
    | unknown => contradiction
    | marker => contradiction
  | bigArg t h ht hh => exact huge_exit allow budget hh con
  | prior r h hr hh => exact huge_exit allow budget hh con
  | bigData n h hn hh => obtain ⟨rfl,rfl⟩ := con; exact zero_good ..
  | first n r h hn hr hh =>
    obtain ⟨rfl,rfl⟩ := con
    change allow=true at cert
    rw [cert]; change r'≤h'; omega
  | fields n r h k hn hr hk =>
    obtain ⟨rfl,rfl⟩ := con
    cases allow with
    | false => simpa [crossing,goodExit] using cert
    | true =>
      change r'≤h'
      cases k with
      | unknown => change 22≤h' at hk; omega
      | marker => change 22≤h' at hk; omega
      | huge =>
        change 2*D≤h' at hk; omega
  | arg t k h hk =>
    change CommandExit t h r' h' at con
    cases con with
    | ordinary => exact zero_good ..
    | ax a big =>
      have ht : t≤22 := by simp only [crossing,Bool.and_eq_true,decide_eq_true_eq] at cert; exact cert.1
      cases allow with
      | true => exact (finish_realized k hk budget ht a).2
      | false =>
        change (literalAX t h).carry=0
        cases k with
        | unknown =>
          have ht2 : t≤2 := by simpa [crossing,ht] using cert
          simp only [literalAX]; omega
        | marker => change 22≤h at hk; simp only [literalAX]; omega
        | huge => exact (huge_invariant budget hk a).1
end CS198.Scanner
#print axioms CS198.Scanner.crossing_realization
