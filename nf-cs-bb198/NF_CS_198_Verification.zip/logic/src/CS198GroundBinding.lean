import CS198Words
import Unshifted198Exact
namespace CS198.Words
open NF192.Numerical

theorem full_derivation_holds {x : Nat} (d : FullDeriv x) {r : Nat → Nat → Prop}
    (allRows : ∀ a b c u z, z ∈ Unshifted198.fullRows a b c u → evaluate r z) : evaluate r x := by
  induction d with
  | row hu hx => exact allRows _ _ _ _ _ hx
  | mp p q ih iq => exact (evaluate_imp _ _ _).mp ih iq

theorem observed_goal_implies_reduced (h : FullDeriv goal) : Unshifted198.Deriv goal := by
  by_contra none
  obtain ⟨r,allRows,hg⟩ := Unshifted198.nonderiv_iff_full_ground.mp none
  exact hg ((evaluate_eqn _ _ _).mp (full_derivation_holds h allRows))

end CS198.Words
#print axioms CS198.Words.observed_goal_implies_reduced
