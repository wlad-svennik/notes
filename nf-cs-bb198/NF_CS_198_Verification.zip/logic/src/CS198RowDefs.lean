import FirstCSRows
namespace CS198.Scanner
open NF192.Numerical NF192.Emitter
def physicalRows (a b c u : Nat) : List Nat := (FirstSlot.rowList a b c u).take 8 ++ [row9 a b]
end CS198.Scanner
