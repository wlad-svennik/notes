module
public import CountSet
public import Curry
public import SingletonCover
@[expose] public section

set_option autoImplicit false
namespace FFL.FirstOrder.FNF.CountSet
open JensenNFU.TFm (scons)
noncomputable section
variable {M : Type} [Tarski.Structure ℒλ M] [Tarski.Structure.Eq ℒλ M] [Nonempty M] [hM : M↓[ℒλ] ⊧* 𝗙𝗡𝗙]
local infixl:70 " ⬝ " => App
theorem characteristic_mem (a y : M) (ha : IsSet a) : a ⬝ y = bool (Mem y a) := by
  rcases ha y with h | h
  · exact h.trans (bool_true ⟨ha,h⟩).symm
  · have no : ¬ Mem y a := fun hyp => tt_ne_ff hM (hyp.2.symm.trans h)
    exact h.trans (bool_false no).symm
local instance singletonBase : SingleImage.Base M where
  app := App
  mem := Mem
  isSet := IsSet
  kpair := kp
  single := sing
  image := simg
  empty := emp
  truth := bool
  app_ext := fun _ _ h => fn_ext hM h
  sets_ext := fun _ _ ha hb e => (eq_set_iff hb).mpr ⟨ha,e⟩
  truth_congr := fun _ _ h => bool_congr h
  characteristic := characteristic_mem
  pair_inj := kp_inj
  sing_inj := FNF.sing_inj
  image_mem := fun {_ _} => mem_simg
  empty_set := isSet_emp
  empty_mem := not_mem_emp
  sing_set := fun _ => isSet_sing
  image_set := fun _ => isSet_simg

def retB : BT [0,0,1,0] (fun e : Nat → M => SingleImage.Ret (e 2) (e 3) (e 0) (e 1)) :=
  ((BT.mem 0 2 0 rfl rfl).and (BT.eq 1 0 0 rfl rfl)).or
    ((BT.mem 0 2 0 rfl rfl).not.and (BT.eq 1 3 0 rfl rfl))

private def uB : BT [0,1,0,1,0,4] (fun e : Nat → M => SingleImage.uTest (e 2) (e 3) (e 4) (e 5) (e 0) (e 1)) :=
  BT.ex 0 (BT.ex 0 (BT.ex 1 (BT.ex 1
    ((BT.app 5 6 3 0 rfl rfl rfl).and ((retB.sub [3,2,7,8] 0).and
      ((singB.sub [0,2] 0).and ((apB.sub [9,1,0] 1).and (BT.mem 4 1 0 rfl rfl))))))))

private def vB : BT [0,1,2,3,2,5] (fun e : Nat → M => SingleImage.vTest (e 3) (e 4) (e 5) (e 0) (e 2)) :=
  BT.ex 2 (BT.ex 1 (BT.ex 2
    ((retB.sub [5,2,6,7] 2).and ((singB.sub [0,1] 1).and
      ((apB.sub [8,2,0] 2).and (BT.mem 3 1 0 rfl rfl))))))

private def liftPairB : BT [3,3] (fun e : Nat → M => ∃ a b z w : M,
    Ap (e 1) a b ∧ z = sing a ∧ w = sing b ∧ e 0 = kp z w) :=
  BT.ex 0 (BT.ex 0 (BT.ex 1 (BT.ex 1 ((apB.sub [5,3,2] 0).and
    ((singB.sub [1,3] 0).and ((singB.sub [0,2] 0).and (kpB.sub [4,1,0] 1)))))))

private def downB : BT [2,4] (fun e : Nat → M => ∃ x y z w : M,
    e 0 = kp x y ∧ z = sing x ∧ w = sing y ∧ Ap (e 1) z w) :=
  BT.ex 0 (BT.ex 0 (BT.ex 1 (BT.ex 1 ((kpB.sub [4,3,2] 0).and
    ((singB.sub [1,3] 0).and ((singB.sub [0,2] 0).and (apB.sub [5,1,0] 1)))))))


local instance graphAbstraction : SingleImage.Comprehension M where
  makeU := fun q D b f => curry2 (M:=M) uB (scons q (scons D (scons b (fun _ => f))))
  makeV := fun D b f => curry3 (M:=M) vB (scons D (scons b (fun _ => f)))
  lifted := fun f => by
    obtain ⟨g,_,e⟩ := (liftPairB (M:=M)).set (fun _ => f)
    exact ⟨g,e⟩
  lowered := fun f => (downB (M:=M)).set (fun _ => f)

def Bij (f a b : M) : Prop := Inj f a b ∧ ∀ y, Mem y b → ∃ x, Ap f x y
def AllCantorian : Prop := ∀ X : M, IsSet X → (∃ f, Bij f X (simg X)) → Strong X

theorem all_cantorian (q : M) (fixed : ∀ u v : M, (∀ t z, (v ⬝ (u ⬝ t)) ⬝ z = u ⬝ (v ⬝ (t ⬝ q))) →
    ∃ d, IsSet d ∧ (∀ x, Mem x d ↔ u ⬝ (v ⬝ x) = x) ∧ Strong d) : AllCantorian (M:=M) := by
  rintro X hs ⟨f,h,b⟩
  apply SingleImage.all_cantorian q fixed X hs
  exact ⟨f,⟨h.dom,h.tot,h.func,h.inj⟩,b⟩
end
end FFL.FirstOrder.FNF.CountSet
#print axioms FFL.FirstOrder.FNF.CountSet.all_cantorian
