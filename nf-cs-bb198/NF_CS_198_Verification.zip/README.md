# A 198-state binary Turing machine for NF + CS

R. Gutin and E. Glazer

On a blank two-way infinite binary tape, this machine searches for a contradiction in Quine’s pure NF with full CS. The register program enumerates proofs in a nine-schema numerical calculus and halts when it observes formula 3. The identification with pure NF + CS uses the written theory comparison described below.

## Replay

Run `python3 check.py` from the extracted directory with Python 3.10 or later. It verifies the file digests, links the 11,442 signed cases to the table, checks the exact source transformation and tests the entry code against 24,576 raw prefixes. Run `python3 screen.py` for the full set of concrete instruction fixtures. See [PHYSICAL.md](PHYSICAL.md) to regenerate the blank-tape and signed certificates with Lean 4.35.0.

[The scanner audit](scanner/Audit.md) describes how raw fields, register instructions and numerical derivations correspond. [The model comparison](Ground-calibration.md) gives the proof for the unshifted ninth row. The `logic` directory contains the combined chart and scanner Lean sources, dependency pins, and replay instructions in its README. From `logic`, run `lake exe cache get` and then `lake env python3 replay.py --jobs 2` to rebuild the included modules. The [parent calibration](Parent-calibration.md) describes the published mathematical construction used for the final consistency comparison.
