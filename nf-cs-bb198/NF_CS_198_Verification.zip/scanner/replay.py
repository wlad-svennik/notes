"""Check the unshifted CS emitter, proof words and actual ternary marker over the CS chart dependencies."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('objects',nargs='+',type=Path,help='one or more compiled chart and CS199 project dependency directories')
parser.add_argument('--build',type=Path,default=Path(__file__).resolve().parent/'.replay')
parser.add_argument('--lean',default='lean')
args=parser.parse_args()
objects=[p.resolve() for p in args.objects]; out=args.build.resolve();out.mkdir(exist_ok=True,parents=True)
for n in ('FirstCSRows', 'Unshifted198Core', 'Unshifted198Exact'):
    if not any((p/(n+'.olean')).is_file() for p in objects):parser.error(f'the supplied objects lack the project module {n}')
version=subprocess.check_output([args.lean,'--version'],text=True).strip()
if 'version 4.35.0' not in version:parser.error('use the Lean 4.35.0 and mathlib environment from the CS verification archive')
root=Path(__file__).resolve().parent; src=root/'src'
paths=[str(out),*map(str,objects),*(p for p in os.environ.get('LEAN_PATH','').split(os.pathsep) if p)]
env=dict(os.environ,LEAN_PATH=os.pathsep.join(paths))
entries={}
for n in ['MarkerArithmetic','MarkerEnumeration','CS198GlobalBudget','CS198RowDefs','CS198PhysicalRows','CS198Bounds','CS198PhaseCases','CS198PhaseRealization','CS198PhaseExhaustion','CS198CursorStep','CS198MarkerReplay','CS198Words','CS198GroundBinding']:
    p=src/(n+'.lean');target=out/(n+'.olean')
    run=subprocess.run([args.lean,'-j','1','-s','131072','-o',str(target),p.name],cwd=src,env=env,text=True,capture_output=True)
    report=run.stdout+run.stderr;(out/(n+'.log')).write_text(report)
    if run.returncode or 'sorryAx' in report or "uses 'sorry'" in report:raise SystemExit(n+' failed\n'+report)
    entries[n]={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'axiom_reports':[s for s in report.splitlines() if 'axioms' in s]}
    print('checked',n,flush=True)
(out/'receipt.json').write_text(json.dumps({'lean':version,'modules':entries},indent=2)+'\n')
