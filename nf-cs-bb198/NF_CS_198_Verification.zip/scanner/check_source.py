"""Bind the no-bump CS certificate and its actual raw command prefix to the published CS199 program."""
import argparse
import hashlib
import json
from itertools import product
from math import isqrt
from pathlib import Path
from zipfile import ZipFile, is_zipfile

PARENT_ARCHIVE='3bdd12b7e1a70fc26b80cc660e5b4bc47daf05cf2e4da1cee09d269a2dea16f5'
PARENT_SOURCE='7dadff2a8e765846abc8e008b6082b8ffedd3cf3e3782bfc2b8037339c26b757'
SOURCE='a3e512b0f9886a6230f22634a7ec84a2a4b9d7aa8ec0dd001219023cf86c820a'
TABLE='243ef9d4db45311377fc200b0205855ae24946b62505777f9e746f868e1459bb'

def sha(data):return hashlib.sha256(data).hexdigest()

def read_parent(path):
    if not is_zipfile(path):return path.read_bytes()
    assert sha(path.read_bytes())==PARENT_ARCHIVE
    with ZipFile(path) as z:return z.read('source.sites.json')

def instructions(data):
    rows=json.loads(data); leaves=[i[0] for i in rows]; bounds={}
    assert leaves==sorted(set(leaves))
    for pc,path in enumerate(leaves):
        assert path and not(set(path)-{'0','1'})
        for k in range(len(path)+1):bounds.setdefault(path[:k],[pc,pc])[1]=pc+1
    tips=set(leaves)
    assert all((p+'0' in bounds)==(p not in tips) and (p+'1' in bounds)==(p not in tips) for p in bounds)
    edges=[]
    def climb(p,ch,count):
        for _ in range(count):
            a=p.rfind(ch); assert a>=0; p=p[:a]
        return p
    for pc,(path,op,arg) in enumerate(rows):
        fall=(pc+1)%len(rows)
        if op=='CI':dst=(fall,)
        elif op=='CD':dst=(fall,None if path.endswith('1') else bounds[climb(path,'0',1)][1]%len(rows))
        elif op=='CB':dst=(bounds[climb(path,'0',arg)][1]%len(rows),)
        else:
            assert op=='CC';dst=(bounds[climb(path,'1',arg)][0],)
        edges.append(dst)
    return rows,edges

def shifted(pc):
    if pc is None or pc<=39:return pc
    if 50<=pc<=3838:return pc-11
    if 3839<=pc<=4255:return pc-12
    assert pc>4255;return pc-11

def unpair(n):
    s=(isqrt(8*n+1)-1)//2;r=n-s*(s+1)//2
    return s-r,r

def prefix_trial(rows,edges,reg):
    epoch,top,stack,rank,param,cache,_,_,cursor=reg
    regs=reg[:];pc=0
    while pc!=37:
        _,op,r=rows[pc];dst=edges[pc]
        if op=='CD' and not regs[r]:pc=dst[1];continue
        if op=='CD':regs[r]-=1
        elif op=='CI':regs[r]+=1
        pc=dst[0]
    if cursor:
        tag,after=unpair(cursor-1);imm,tail=unpair(after);n=epoch
    else:
        tag=0;imm,tail=unpair(epoch);n=epoch+1
    assert regs==[n,top,stack,rank+tag,param+imm,cache,0,0,tail]

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('directory',type=Path);cli.add_argument('parent',type=Path);args=cli.parse_args()
    data=(args.directory/'source.sites.json').read_bytes();raw=(args.directory/'candidate.tm').read_bytes()
    previous=read_parent(args.parent)
    assert (sha(previous),sha(data),sha(raw))==(PARENT_SOURCE,SOURCE,TABLE)
    old,oldedge=instructions(previous);new,edge=instructions(data)
    assert len(old)==4377 and len(new)==4366
    retained=0
    for i,row in enumerate(old):
        if 39<=i<50 or i in (3838,4255):continue
        k=shifted(i);assert new[k][1:]==row[1:] and edge[k]==tuple(map(shifted,oldedge[i]));retained+=1
    assert old[3838][1:]==['CI',4] and oldedge[3838]==(3839,)
    assert retained==4364
    cuts={37:('CD',3,(38,4319)),38:('CD',3,(39,4245)),39:('CD',6,(40,42)),40:('CI',5,(41,)),41:('CC',2,(39,)),4243:('CD',5,(4244,4245)),4244:('CC',3,(38,))}
    cuts.update({i:('CD',5,(i+1,4350 if i<4349 else None)) for i in range(4346,4350)})
    assert all((*new[i][1:],edge[i])==v for i,v in cuts.items())
    assert [i for i,v in enumerate(edge) if None in v]==[4349]
    expect=old[53:3838]+old[3839:4255]
    assert [r[1:] for r in new[42:4243]]==[r[1:] for r in expect]
    print('198-source and 199-source SHA-256 validated; 4,364 inherited operations and all their control successors agree.')
    print('4,201 emitter operations matched exactly after removing the first-coordinate increment at parent PC 3838. The only stopping register branch is PC 4349 on zero.')
    count=0
    for cursor,n,r,p in product(range(64),range(32),(0,1,2,7),(0,1,11)):
        prefix_trial(new,edge,[n,7,11,r,p,23,0,0,cursor]);count+=1
    print(f'{count:,} literal command-prefix tests passed, including fresh epochs, nonzero rank and nonzero parameter.')

if __name__=='__main__':main()
