"""Check the 198-state source against the published NF+CS199 source."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

PARENT_SOURCE = "7dadff2a8e765846abc8e008b6082b8ffedd3cf3e3782bfc2b8037339c26b757"
NEW_SOURCE = "a3e512b0f9886a6230f22634a7ec84a2a4b9d7aa8ec0dd001219023cf86c820a"
NEW_TABLE = "243ef9d4db45311377fc200b0205855ae24946b62505777f9e746f868e1459bb"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def instructions(data):
    rows = json.loads(data)
    spans = {}
    leaves = set()
    for i, (address, _, _) in enumerate(rows):
        assert address and set(address) <= {"0", "1"}
        assert address not in leaves
        leaves.add(address)
        for n in range(len(address) + 1):
            spans.setdefault(address[:n], [i, i])[1] = i + 1
    assert [a for a, _, _ in rows] == sorted(leaves)
    for node in spans:
        if node in leaves:
            assert node + "0" not in spans and node + "1" not in spans
        else:
            assert node + "0" in spans and node + "1" in spans
    edges = []
    for i, (address, op, arg) in enumerate(rows):
        seq = (i + 1) % len(rows)
        prefix = address
        if op == "CI":
            edges.append((seq,))
            continue
        char = "1" if op == "CC" else "0"
        for _ in range(arg if op in {"CC", "CB"} else 1):
            j = prefix.rfind(char)
            assert j >= 0
            prefix = prefix[:j]
        if op == "CD":
            edges.append((seq, None if address.endswith("1") else spans[prefix][1] % len(rows)))
        elif op == "CC":
            edges.append((spans[prefix][0],))
        else:
            assert op == "CB"
            edges.append((spans[prefix][1] % len(rows),))
    return rows, edges


def map_entry(pc):
    if pc is None or pc < 39:
        return pc
    if pc == 39:
        return 39
    if 50 <= pc <= 3838:
        return pc - 11
    if 3839 <= pc <= 4255:
        return pc - 12
    assert pc > 4255
    return pc - 11


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("parent", type=Path, help="NF+CS199 verification ZIP or extracted source.sites.json")
    parser.add_argument("source", type=Path)
    parser.add_argument("table", type=Path)
    args = parser.parse_args()
    if not __debug__:
        raise ValueError("Enable Python assertions for the source audit.")
    if zipfile.is_zipfile(args.parent):
        with zipfile.ZipFile(args.parent) as archive:
            parent = archive.read("source.sites.json")
    else:
        parent = args.parent.read_bytes()
    new = args.source.read_bytes()
    raw = args.table.read_bytes()
    assert digest(parent) == PARENT_SOURCE and digest(new) == NEW_SOURCE and digest(raw) == NEW_TABLE
    old, prev = instructions(parent)
    rows, nexts = instructions(new)
    assert (len(old), len(rows)) == (4377, 4366)
    assert old[3838][1:] == ['CI', 4] and prev[3838] == (3839,)
    assert map_entry(3838) == map_entry(3839) == 3827
    matched = 0
    for i, (_, op, arg) in enumerate(old):
        if 39 <= i < 50 or i in (3838, 4255):
            continue
        j = map_entry(i)
        assert rows[j][1:] == [op, arg]
        assert nexts[j] == tuple(map_entry(t) for t in prev[i])
        matched += 1
    assert matched == 4364
    assert [r[1:] for r in rows[42:4243]] == [r[1:] for r in old[53:3838] + old[3839:4255]]
    for i, op, k, targets in [
        (38, "CD", 3, (39, 4245)),
        (39, "CD", 6, (40, 42)),
        (40, "CI", 5, (41,)),
        (41, "CC", 2, (39,)),
        (4243, "CD", 5, (4244, 4245)),
        (4244, "CC", 3, (38,)),
    ]:
        assert rows[i][1:] == [op, k] and nexts[i] == targets
    header, *body = raw.decode().splitlines()
    assert header == "#! start k:64"
    table = {}
    for line in body:
        q, b, w, direction, dest = line.split()
        assert b in {"0", "1"} and w in {"0", "1"} and direction in {"L", "R"}
        assert (q, b) not in table and q != "halt"
        table[q, b] = dest
    reachable = set()
    todo = ["k:64"]
    while todo:
        q = todo.pop()
        if q != "halt" and q not in reachable:
            reachable.add(q)
            todo.extend((table[q, "0"], table[q, "1"]))
    assert len(body) == len(table) == 396 and len(reachable) == 198
    assert reachable == {q for q, _ in table} and "halt" in table.values()
    print("198 reachable states and 396 transitions. The source has 4,366 instruction sites.")
    print("Verified against the released Cantorian source: all 4,364 retained operations and all their control successors agree under relocation.")
    print("All 4,201 retained Cantorian axiom-emission instructions agree. Parent PC 3838 incremented R4. Its removal preserves the incoming value at the final extensionality row.")


if __name__ == "__main__":
    main()
