# NF + AxCount in 187 working states

Run `NF_AxCount_Guarded_187.tm` from state `k:74` on the all-zero, two-way infinite binary tape. There are 374 transitions on 187 reachable working states. The only transition to the separate halt state reads 1 in `k:302`. Each instruction gives current state, read bit, write bit, move and next state.

## What the machine searches

The register program retains all eight axiom families of the supplied 180-state pure NF machine and its refutation goal, formula code 3. It inserts a ninth axiom at old instruction 582. Write S for $(J(Jb))J=Jb$ and C for $bc=bd$, where juxtaposition denotes application. The added formula is $(S\to C)\to C$. Classically, requiring this for every c,d says that S holds whenever the row of b takes two distinct values. The whole register program has 3,642 instructions, including 672 added instructions.

`CountingRefill.GuardedBridge.guarded187_register_halts_iff_goal` proves in Lean that the literal register program from PC 0, R0 = 5 and eight zeros halts exactly when the nine schemas derive the goal. This includes arbitrarily late halts and every finite derivation. The proof binds both prefix trees, all jumps, the 3,481-instruction axiom block and the refill that forces the first outer selector. The kernel reports `propext`, `Classical.choice` and `Quot.sound`. A derivation corresponds to a refutation under the mathematical calibration described in `calculus/UPPER.md` and `upstream/JpointCalibration.md`.

## The last two states

Starting from the 189-state guarded predecessor, two pairs of decoder states already share their transition on symbol 1. For each pair a single replacement transition on symbol 0 handles both incoming tape contexts. Redirecting the incoming edges removes one state per pair. The register source is identical across these two reductions. Run `python3 reduction/check.py` to apply the exact diff to the 189-state table and compare every transition.

## Physical verification

* At 233,240 binary transitions the complete blank-tape run reaches PC 0, R0 = 5, the other registers zero, head −10, gap 97, and 78 spare fields. The earlier PC-0 checkpoint with counter 2 is at 41,865 transitions. `boot/ScannerFrames.lean` states both equalities for the literal table and full tape.
* The instruction certificate covers all 9,552 signed branches. Its 20 induction rules cover arbitrary lengths in the register and spare fields. Every live branch has a positive clock and returns the entire specified successor configuration, allowing the individual proofs to compose by ordinary induction on register execution. For a finite register run, concatenate those positive clocks. For an infinite register run, their partial sums exceed every fixed binary time. Since binary halting is absorbing, a computation with live boundary frames at all those times runs forever. `Native187.PhysicalRefinement.halting_iff` proves this general positive-clock argument in Lean. Applying it to these exports uses the written identification of their two tape rays with the ordinary binary tape at register boundaries.
* The independent C++ simulator compared 174,800 full successor tapes and 16 halts over 116,048,774 binary transitions.
* `build.py` reconstructs both the binary table and register program using the included pure NF180 release. `decoder-edits.json` records every changed binary transition. `calculus/REGISTER-PROOF.md` explains how a finite derivation becomes a finite word that the forced refill eventually selects.

## Mathematical scope

The upper direction constructs the guarded chart from a model of pure NF + AxCount, using the full-chart construction and available disjoint slices in the original calibration. The lower direction produces an NFU model with Dedekind Infinity and full AxCount. `CountingRefill.GuardedBridge.nonhalting_yields_counting_model` proves this directly from nonhalting of the literal counter-5 register machine. `CountingRefill.GuardedBridge.nonhalting_iff_guarded_chart` identifies nonhalting of this same register machine exactly with existence of a guarded native chart. The quotient construction is explained in `calculus/GROUND-CHART.md`. Converting this to consistency of pure NF + AxCount uses Proposition 17.13 and Theorem 21.1 of Ran Gutin's supplied *Choice and Consistency Strength in NF and NFU*, v15. The upstream calibration archive includes the relevant excerpt. The upper construction and pure-theory comparison are written mathematical inputs. The file records a new upper bound on the state count.

## Reproduce

Run `python3 verify.py --examples` to rebuild both literals, check the manifest and signed coverage, replay both full-tape blank checkpoints, check the inserted formulas and compare the concrete branch fixtures.

* `python3 verify.py --lean --jobs 2` checks the complete blank startup with Lean 4.35.0.
* `python3 verify.py --physical --jobs 2` regenerates the symbolic traces and verifies the independent kernel exports. This requires Lean 4.35.0's `leanchecker-paranoid` on PATH.
* `python3 verify.py --theory --jobs 2` rechecks the register and model proofs. Run this in the pinned mathlib environment described by `Jpoint_Calibration.zip`, for example with `lake env python3 /path/to/verify.py --theory --jobs 2` from its project root. `python3 calculus/replay_lean.py --list` resolves its full import graph without compilation. `python3 theory/check_literals.py` rebuilds the short–long register binding independently.

Table SHA-256 is `09aa41ff3962ce68e6050defa635071cc6b069029016b7cdd94ca35e74cda6db`. Register program SHA-256 is `8b40258cf8dde548d30f625804432d1c26c1668350a2a326e4c28e89837f1330`.
