"""Generate a Lean equality for each literal prefix tree and its complete register CFG."""
from pathlib import Path
import json, sys
here=Path(__file__).resolve().parent
def emit(path, start, nn):
    rows=json.loads(path.read_bytes());leaf={p:(o,r) for p,o,r in rows};nodes={};decl=[]
    def tree(p):
        if p in leaf:
            op,reg=leaf[p];name=op,reg;expr=f'.leaf .{op} {reg}'
        else:
            a,b=tree(p+'0'),tree(p+'1');name=a,b;expr=f'.fork t{a} t{b}'
        if name not in nodes:
            nodes[name]=len(nodes);decl.append(f'def t{nodes[name]} : Tree := {expr}')
        return nodes[name]
    root=tree('');s=nn
    return f'namespace {s}\n'+'\n'.join(decl)+f'''
def literal := decode {len(rows)} t{root} 0 [] [] false
def instructions : List Cmd := (List.range {start}).map {s}Prefix ++ batches.flatten.map Entry.{s}
theorem all_instructions : literal = instructions := by decide +kernel
theorem leaf_count : t{root}.width = {len(rows)} := by decide +kernel
end {s}
'''
head='''import Halting
set_option maxRecDepth 200000
set_option maxHeartbeats 0
namespace CountingRefill.Binding
open CountingRefill
inductive Op where
  | CI | CD | CC | CB
inductive Tree where
  | leaf (op : Op) (operand : Nat)
  | fork (left right : Tree)
def Tree.width : Tree → Nat
  | .leaf _ _ => 1
  | .fork a b => a.width+b.width
def decode (size : Nat) (t : Tree) (pc : Nat) (forward backward : List Nat)
    (lastRight : Bool) : List Cmd :=
  match t with
  | .fork l r =>
      decode size l pc (((pc+t.width)%size)::forward) backward false ++
      decode size r (pc+l.width) forward (pc::backward) true
  | .leaf op n =>
      let next := (pc+1)%size
      [match op with
       | .CI => .inc n next
       | .CD => .dec n (if lastRight then none else forward[0]?) next
       | .CC => .jump (backward[n-1]?.getD 4095)
       | .CB => .jump (forward[n-1]?.getD 4095)]
'''
end='''
/-- The actual warm frame has PC 0, counter 5 and eight zero registers. -/
theorem blank_frame_register_equivalence :
    Halts (raw newProgram) (some (conf 0 5 0 0 (fun _ => 0))) ↔
    Halts (raw oldProgram) (some (conf 0 4 0 0 (fun _ => 0))) :=
  (source_halts_iff (i:=0) (by decide) ⟨4,0,0,fun _ => 0⟩).symm
#print axioms old.all_instructions
#print axioms new.all_instructions
#print axioms blank_frame_register_equivalence
end CountingRefill.Binding
'''
(here/'Binding.lean').write_text(head+emit(Path(sys.argv[1]),10,'old')+emit(Path(sys.argv[2]),9,'new')+end)
