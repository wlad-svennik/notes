"""Replace the nine-leaf refill subtree by the ten-leaf auxiliary chart."""
import json
from pathlib import Path
import sys
def long_tree(short):
    prefix = [
        ["0000","CD",8], ["0001","CB",1], ["0010","CI",0], ["001100","CD",0],
        ["0011010","CI",7], ["00110110","CI",6], ["00110111","CC",3],
        ["001110","CD",6], ["0011110","CI",0], ["0011111","CC",2],
    ]
    # Both refill subtrees exhaust prefix 00. All other leaves retain their paths.
    assert all(row[0].startswith("00") for row in short[:9])
    assert not any(row[0].startswith("00") for row in short[9:])
    return prefix + short[9:]
if __name__ == "__main__":
    short = json.loads(Path(sys.argv[1]).read_bytes())
    Path(sys.argv[2]).write_text(json.dumps(long_tree(short),separators=(",",":")))
