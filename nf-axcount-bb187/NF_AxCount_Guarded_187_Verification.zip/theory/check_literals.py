"""Rebuild the two source trees and compare the generated Lean declarations literally."""
import hashlib
from pathlib import Path
from shutil import copyfile
import subprocess
import sys
from tempfile import TemporaryDirectory

here = Path(__file__).resolve().parent
source = here.parent / 'source.sites.json'
proof = here.parent / 'calculus/proof'
expected = '8b40258cf8dde548d30f625804432d1c26c1668350a2a326e4c28e89837f1330'
if hashlib.sha256(source.read_bytes()).hexdigest() != expected:
    raise ValueError('Guarded register source hash differs')
with TemporaryDirectory() as name:
    tmp = Path(name)
    copyfile(here / 'bind_source.py', tmp / 'bind_source.py')
    old = tmp / 'long.json'
    subprocess.run([sys.executable, here / 'make_long.py', source, old], check=True)
    subprocess.run([sys.executable, here / 'generate_source.py', old, source, tmp], check=True)
    subprocess.run([sys.executable, tmp / 'bind_source.py', old, source], check=True)
    for module in ('SourceGraph.lean', 'Binding.lean'):
        if (tmp / module).read_bytes() != (proof / module).read_bytes():
            raise ValueError('Generated Lean source differs for ' + module)
print('Both literal prefix trees and all decoded commands match the released Lean files.')
