"""Rebuild the quotient, check its blank run and verify all physical certificate inputs."""
import argparse
from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,sys,tempfile
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
def run(*cmd,env=None,cwd=None):
    subprocess.run([str(x)for x in cmd],env=env,cwd=cwd,check=True)
def require(ok,reason):
    if not ok:raise ValueError(reason)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--examples',action='store_true',help='Compare complete physical successor tapes with register semantics')
    p.add_argument('--physical',action='store_true',help='Regenerate and kernel-check all signed register branches')
    p.add_argument('--theory',action='store_true',help='Rebuild the register and model proofs in the pinned mathlib environment')
    p.add_argument('--lean',action='store_true',help='Regenerate and check the blank startup Lean proof')
    p.add_argument('--jobs',type=int,default=2)
    a=p.parse_args()
    for line in (HERE/'SHA256SUMS').read_text().splitlines():
        h,f=line.split('  ',1);require(digest(HERE/f)==h,'Manifest mismatch: '+f)
    data=json.loads((HERE/'machine.json').read_bytes());n=data['states']
    tfile=next(HERE.glob('*.tm'));sfile=HERE/'source.sites.json'
    require(digest(tfile)==data['table'] and digest(sfile)==data['source'],'Machine digest mismatch')
    sites=json.loads(sfile.read_bytes());head,*ls=tfile.read_text().splitlines();table={}
    for q,b,w,d,z in map(str.split,ls):
        require(b in '01' and w in '01' and d in ('L','R') and (q,int(b))not in table,'Ill-formed row')
        table[q,int(b)]=int(w),1 if d=='R' else -1,z
    start=head.split()[-1];pending=[start];live=set()
    while pending:
        q=pending.pop()
        if q=='halt' or q in live:continue
        live.add(q)
        pending.extend(table[q,b][2]for b in (0,1))
    require(len(live)==n and len(table)==2*n,'Working-state count or reachability')
    require([(q,b)for (q,b),(_,_,z)in table.items()if z=='halt']==[('k:302',1)],'Unexpected halt edge')
    frames=data['frames'];q=start;h=0;ones=set();ticks=0
    for f in frames:
        while ticks<f['time']:
            x,move,q=table[q,int(h in ones)]
            if x:ones.add(h)
            else:ones.discard(h)
            h+=move;ticks+=1
        regs=[f['counter']]+[0]*8;addr=sites[0][0];gap=f['gap']
        word='1'+addr+'0'*(gap-len(addr))+'1'
        word+=''.join('0'+'1'*(2+regs[i])for i in (2,8,1,4,3,7,0,5,6))+'01'*f['spares']
        require(q=='d:0' and h==f['head'] and ones=={h-1+j for j,b in enumerate(word)if b=='1'},'Blank tape frame mismatch')
    phy=HERE/'physical';ev=HERE/'receipts';trace=ev/'traces.json.gz'
    cc=json.loads(gzip.decompress(trace.read_bytes()));ks=json.loads((ev/'kernel.json').read_bytes())
    require(ks['table']==cc['table']==digest(tfile) and ks['source']==cc['source']==digest(sfile),'Branch bindings')
    require(digest(trace)==ks['trace_sha256'] and cc['base_gap']==51,'Trace digest or domain')
    expected={(pc,cold,zero)for pc,(_,op,r)in enumerate(sites)for cold in (False,True)
              if not(cold and op=='CD'and r==0)for zero in ((False,True)if op=='CD'else(False,))}
    branches=[(x['pc'],x['cold'],x['zero'])for x in cc['traces']]
    require(len(expected)==len(branches)==ks['branch_theorems'] and expected==set(branches),'Missing or repeated branch')
    require(all(t['clock'][0]>0 and min(t['clock'])>=0 for t in cc['traces']),'Invalid branch clock')
    pc=0
    for sect in ks['intervals']:
        hi=sect['past_last_pc']
        require(sect['first_pc']==pc and hi>pc and sect['branches']==sum(pc<=x[0]<hi for x in expected)
                and 'accepts the solution' in sect['kernel'],'Unverified interval')
        pc=hi
    require(pc==len(sites),'Incomplete proof coverage')
    run(sys.executable, HERE/'reduction/check.py')
    run(sys.executable, HERE/'theory/check_literals.py')
    if a.theory:
        run(sys.executable, HERE/'calculus/replay_lean.py', '--jobs', a.jobs)
    with tempfile.TemporaryDirectory()as t:
        work=Path(t);machine=work/'machine'
        if data['theory']=='guarded':
            run(sys.executable,HERE/'build.py',machine)
            run(sys.executable,HERE/'calculus/verify.py','--machine',HERE,'--upstream',HERE/'upstream/NF180_verification.zip')
            run(sys.executable,HERE/'calculus/check_formulas.py','--archive',HERE/'upstream/Jpoint_Calibration.zip')
        else:
            run(sys.executable,HERE/'build.py',HERE/'upstream/NF180_verification.zip',HERE/'upstream/Counting_Scalar_192_Verification.zip',machine)
        require((machine/'candidate.tm').read_bytes()==tfile.read_bytes() and (machine/sfile.name).read_bytes()==sfile.read_bytes(),'Reconstruction mismatch')
        if a.examples:
            run(sys.executable,phy/'prepare.py',machine)
            exe=work/'examples'
            run(os.environ.get('CXX','c++'),'-O3','-std=c++17',phy/'replay_examples.cpp','-o',exe)
            run(exe,machine/'source.txt',machine/'table.txt')
        if a.lean:
            boot=work/'boot';shutil.copytree(HERE/'boot',boot)
            run(sys.executable,boot/'generate.py',tfile,boot)
            for f in (HERE/'boot').glob('*.lean'):
                require(f.read_bytes()==(boot/f.name).read_bytes(),'Regenerated startup differs '+f.name)
            run('bash',boot/'compile.sh',env=dict(os.environ,JOBS=str(a.jobs)))
        if a.physical:
            out=work/'fresh.gz'
            run(sys.executable,phy/'symbolic_frames.py',machine,'--write',out)
            require(gzip.decompress(out.read_bytes())==gzip.decompress(trace.read_bytes()),'Regenerated trace differs')
            run(sys.executable,phy/'check_all.py',machine,out,work/'new-receipt.json','--jobs',a.jobs)
    print(f'{n} reachable working states, {2*n} transitions, {len(sites)} instructions and {len(expected)} signed branches. Blank tape reaches PC 0, counter {frames[-1]["counter"]} after {ticks} steps.')
if __name__=='__main__':verify()
