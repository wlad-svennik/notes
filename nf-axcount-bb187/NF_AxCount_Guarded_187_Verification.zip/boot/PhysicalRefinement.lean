import NF210.MachineSemantics

namespace Native187.PhysicalRefinement
open NF210.TM
variable {S : Type} {n : Nat}

def iterate (f : S → S) (s : S) : Nat → S
  | 0 => s
  | j+1 => f (iterate f s j)

/-- After j register transitions there is a related binary boundary at binary time k ≥ j. -/
theorem reaches_boundaries (machine : Machine n) (advance : S → S)
    (rel : S → Configuration n → Prop)
    (one : ∀ s c, rel s c → ∃ k, 0 < k ∧ rel (advance s) (run machine k c))
    {s c} (initial : rel s c) (j : Nat) :
    ∃ k, j ≤ k ∧ rel (iterate advance s j) (run machine k c) := by
  induction j with
  | zero => exact ⟨0, Nat.le_refl _, initial⟩
  | succ j ih =>
    obtain ⟨k, ge, atK⟩ := ih
    obtain ⟨t, pos, next⟩ := one _ _ atK
    refine ⟨k + t, by omega, ?_⟩
    rw [run_add]
    exact next

/-- Both directions hold for arbitrary positive and nonuniform finite branch times. -/
theorem halting_iff (machine : Machine n) (advance : S → S)
    (halted : S → Prop) (rel : S → Configuration n → Prop)
    (one : ∀ s c, rel s c → ∃ k, 0 < k ∧ rel (advance s) (run machine k c))
    (agree : ∀ s c, rel s c → (halted s ↔ c.state = none))
    {s c} (initial : rel s c) :
    (∃ j, halted (iterate advance s j)) ↔ (∃ t, (run machine t c).state = none) := by
  constructor
  · rintro ⟨j, h⟩
    obtain ⟨k, _, boundary⟩ := reaches_boundaries machine advance rel one initial j
    exact ⟨k, (agree _ _ boundary).mp h⟩
  · rintro ⟨t, dead⟩
    obtain ⟨k, ge, boundary⟩ := reaches_boundaries machine advance rel one initial t
    apply Exists.intro t
    apply (agree _ _ boundary).mpr
    obtain ⟨extra, rfl⟩ := Nat.exists_eq_add_of_le ge
    rw [run_add, run_of_halted machine _ dead]
    exact dead

theorem blank_halts_iff_suffix (machine : Machine n) (start : Fin n) (boot : Nat) :
    Halts machine start ↔ ∃ t, (run machine t (run machine boot (blank start))).state = none := by
  constructor
  · rintro ⟨t, dead⟩
    refine ⟨t, ?_⟩
    rw [← run_add, Nat.add_comm, run_add, run_of_halted machine _ dead]
    exact dead
  · rintro ⟨t, dead⟩
    exact ⟨boot+t, by rw [run_add]; exact dead⟩

end Native187.PhysicalRefinement
#print axioms Native187.PhysicalRefinement.halting_iff
#print axioms Native187.PhysicalRefinement.blank_halts_iff_suffix
