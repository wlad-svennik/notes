"""Match the physical row manifest to the literals in the Lean batch theorem."""
import argparse
import json
from pathlib import Path
import re
import zipfile

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--archive', type=Path, default=root.parent / 'deliver/upstream/Jpoint_Calibration.zip')
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as archive:
    standard = archive.read('Jpoint_Calibration/src/NumericalEmitterBatch.lean').decode()
special = (root / 'proof/ConditionalEmitter.lean').read_text()
batch = (root / 'proof/ConditionalBatch.lean').read_text()
manifest = json.loads((root / 'row.json').read_text())

def macro_list(source, name):
    pattern = r'\bdef\s+' + re.escape(name) + r'\s*:\s*List Macro\s*:=\s*\[(.*?)\]'
    match = re.search(pattern, source, re.S)
    assert match, name
    return [token.strip().removeprefix('.') for token in match[1].split(',')]

inserted = macro_list(special, 'tokens')
assert [t if t not in ('ap', 'eqn') else 'appOrEqual' for t in inserted] == manifest['word']
assert re.search(r'Eval\s*\(sequence\s+\.read5\s+tokens\)',batch)
parts = re.search(r'def tokens\s*:\s*List Macro\s*:=\s*(.*?)\n\ntheorem batch_effect',batch,re.S)[1].split('++')
program = ['read5']
for part in parts:
    name = part.strip()
    if name == 'GuardedEmitter.tokens':
        program.extend(inserted)
    else:
        program.extend(macro_list(standard if name.startswith('tokens') else batch, name))
pos = manifest['after_macros']
old = manifest['retained_tokens']
assert program == old[:pos] + inserted + old[pos:]
print(f'{len(program)} chronological Lean register macros exactly match the literal row manifest.')
