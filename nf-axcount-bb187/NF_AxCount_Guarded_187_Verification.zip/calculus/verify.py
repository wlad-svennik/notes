"""Check the inserted register program, every intra-macro exit, and all signed warm frames."""
import argparse, bisect, hashlib, json, subprocess, sys, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--upstream', type=Path, default=ROOT.parent/'upstream/NF180_verification.zip')
parser.add_argument('--frames',action='store_true')
parser.add_argument('--machine',type=Path,default=ROOT.parent)
args = parser.parse_args()
with zipfile.ZipFile(args.upstream) as archive:
    old = json.loads(archive.read('source.sites.json'))
new = json.loads((args.machine/'source.sites.json').read_text())
row = json.loads((args.machine/'row.json').read_text())
pos = row['old_instruction_offset']
insert = []
segments = []
for name in row['word']:
    lo, hi = row['representatives'][name]
    segments.append((pos + len(insert),lo,hi))
    insert.extend(old[lo:hi])
word = old[:pos] + insert + old[pos:]
assert [x[1:] for x in word] == [x[1:] for x in new]
def destinations(sites):
    intervals = {}
    for i,(p,_,_) in enumerate(sites):
        for j in range(len(p)+1):
            intervals.setdefault(p[:j],[i,i+1])[1] = i+1
    for i,(p,op,arg) in enumerate(sites):
        if op=='CI':
            yield None
            continue
        if op=='CD' and p.endswith('1'):
            yield -1
            continue
        side='1' if op=='CC' else '0'
        j=len(p)
        for _ in range(arg if op in ('CC','CB') else 1):
            j=p.rfind(side,0,j)
            assert j>=0
        yield intervals[p[:j]][0 if side=='1' else 1] % len(sites)
old_target=list(destinations(old));new_target=list(destinations(new))
for i,target in enumerate(old_target):
    if target is None or target==-1:
        expected=target
    else:
        expected=target+(len(insert) if target>pos or (target==pos and i>=pos) else 0)
    loc=i+(len(insert) if i>=pos else 0)
    assert new_target[loc]==expected,(loc,i,new_target[loc],expected)
for start,lo,hi in segments:
    for i in range(lo,hi):
        target=old_target[i];j=start+i-lo
        if target is None or target==-1:
            expected=target
        else:
            assert lo<=target<=hi,(start,lo,hi,i,target)
            expected=start+target-lo
        assert new_target[j]==expected,(j,new_target[j],expected)
p=next(args.machine.glob('*.tm'));head,*rows=p.read_text().splitlines()
matrix=[k.split() for k in rows];states=set(q for q,*_ in matrix)
assert len(states) in (187,189,190,191,192,193) and len(matrix)==len(states)*2
assert len({(q,s)for q,s,*_ in matrix})==len(matrix)
assert [r for r in matrix if r[-1]=='halt']==[['k:302','1','0','L','halt']]
print(f'{len(states)} states, {len(new)} instructions, {len(insert)} inserted instructions; all register targets match.')
arcs={(q,int(c)):(int(w),1 if d=='R' else -1,k)for q,c,w,d,k in matrix}
q=head.split()[-1]; h=0;ones=set();elapsed=0
for target in json.loads((args.machine/'receipts/blank-frames.json').read_text()):
    for _ in range(elapsed,target['time']):
        b=int(h in ones);w,d,q=arcs[q,b];ones.discard(h)
        if w:ones.add(h)
        h+=d
    elapsed=target['time']
    a=new[0][0];word='1'+a+'0'*(target['gap']-len(a))+'1'
    order=(2,8,1,4,3,7,0,5,6)
    word+=''.join('0'+'1'*(2+(target['counter'] if r==0 else 0))for r in order)
    word+='01'*target['spares']
    assert (q,h,ones)==('d:0',target['head'],{h-1+i for i,c in enumerate(word)if c=='1'})
    print(f"Blank step {elapsed:,}: register PC 0, counter {target['counter']}, gap {target['gap']}, {target['spares']} spares.")
if args.frames:
    subprocess.run([sys.executable,ROOT/'check_frames.py',args.machine,'--cold'],check=True)
    subprocess.run([sys.executable,ROOT/'check_frames.py',args.machine],check=True)
