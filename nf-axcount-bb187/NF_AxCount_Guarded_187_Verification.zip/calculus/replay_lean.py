"""Rebuild the guarded calculation against the upstream pinned Lean environment."""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parent
IMPORT=re.compile(r'^\s*(?:(?:public|meta|private)\s+)*import\s+(?:all\s+)?([\w.]+)',re.M)
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--archive',type=Path,default=ROOT.parent/'upstream/Jpoint_Calibration.zip')
parser.add_argument('--build',type=Path)
parser.add_argument('--jobs',type=int,default=2)
parser.add_argument('--list',action='store_true')
args=parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    sources={n.split('/src/',1)[1][:-5].replace('/','.'):z.read(n)
             for n in z.namelist() if '/src/' in n and n.endswith('.lean')}
for f in (ROOT/'proof').rglob('*.lean'):
    sources[str(f.relative_to(ROOT/'proof'))[:-5].replace('/','.')]=f.read_bytes()
graph={}
def resolve(m):
    if m in graph:return
    if m not in sources:
        if m.split('.')[0] not in ('Init','Std','Lean','Mathlib','Batteries','Aesop','Qq','ProofWidgets','Plausible','ImportGraph','Cli'):
            raise ValueError(f'Missing import {m}')
        return
    deps=set(IMPORT.findall(sources[m].decode()));graph[m]={d for d in deps if d in sources}
    for d in deps:resolve(d)
for target in ['ConditionalTransfer', 'ConditionalDerivation', 'ConditionalChart', 'GuardedBridge', 'GuardedLower', 'GuardedConclusion']:resolve(target)
if args.list:
    print(f'{len(graph)} pinned modules');raise SystemExit
if args.jobs<1:parser.error('--jobs needs a positive integer')
lean=shutil.which('lean')
if not lean or '4.35.0' not in subprocess.check_output([lean,'--version'],text=True):
    raise ValueError('Use the upstream Lean 4.35.0 mathlib environment')
tmp=tempfile.TemporaryDirectory()
work=Path(tmp.name);build=(args.build or (work/'build')).resolve()
build.mkdir(exist_ok=True,parents=True)
src=work/'src';src.mkdir()
for m in graph:
    f=src/Path(*m.split('.')).with_suffix('.lean');f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(sources[m])
env=dict(os.environ,LEAN_PATH=os.pathsep.join([str(build),os.getenv('LEAN_PATH','')]))
def compile_one(m):
    f=Path(*m.split('.')).with_suffix('.lean');o=build/f.with_suffix('.olean');o.parent.mkdir(parents=True,exist_ok=True)
    logfile=build/(m+'.log')
    with logfile.open('w') as out:
        proc=subprocess.run([lean,'-j','1','-s','131072','-o',str(o),str(f)],cwd=src,env=env,stdout=out,stderr=subprocess.STDOUT)
    log=logfile.read_text()
    if proc.returncode or "uses 'sorry'" in log or 'sorryAx' in log:raise RuntimeError(f'{m} failed\n{log[-1800:]}')
remaining=set(graph);running={}
with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
    while remaining:
        for m in sorted(remaining-running.keys()):
            if len(running)>=args.jobs:break
            if not graph[m]&remaining:running[m]=pool.submit(compile_one,m)
        if not running:raise ValueError('dependency cycle')
        concurrent.futures.wait(running.values(),return_when=concurrent.futures.FIRST_COMPLETED)
        for m,f in list(running.items()):
            if f.done():
                f.result();remaining.remove(m);del running[m];print(f'{len(graph)-len(remaining)}/{len(graph)} {m}',flush=True)
for name in ('ConditionalAlgebra', 'ConditionalModel', 'ConditionalRows', 'ConditionalEmitter', 'ConditionalBatch', 'ConditionalLogic', 'ConditionalScanner', 'ConditionalTransfer', 'ConditionalDerivation', 'ConditionalChart'):
    s=(build/(name+'.log')).read_text()
    assert "depends on axioms: [propext, Classical.choice, Quot.sound]" in s
