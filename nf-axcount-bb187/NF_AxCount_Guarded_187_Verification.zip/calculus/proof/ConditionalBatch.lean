import ConditionalLogic
namespace NF180Counting.GuardedBatch
open NF192.Numerical NF192.Emitter
set_option maxHeartbeats 0
set_option maxRecDepth 30000

def logic : List Macro := [.push3,.push4,.imp,.read4,.push4,.imp,.push4,.push3,.imp,.push5,.push3,.imp,.imp,.imp]
theorem logic_effect (n t stack c u b delta tail : Nat) :
    logic.foldl Frame.apply ⟨n,t,stack,c,u,b,pair delta tail⟩ = ⟨n,row0 (u+delta) b c u,pair t stack,c,u+delta,b,tail⟩ := by
  simp only [logic,List.foldl_cons,List.foldl_nil,Frame.apply,Frame.push,Frame.combine,
    Cantor.unpair_pair,ctor,row0,imp,eqn,app,konst,witness,s_is_one,q,Nat.add_zero,
    GuardedLogic.bRow,GuardedLogic.single,GuardedLogic.testRow]
  <;> rfl

def basis : List Macro := [.push0,.incTop,.push3,.ap,.push4,.ap,.push5,.ap,.push3,.push5,.push5,.witness,.ap,.push4,.push5,.ap,.ap,.eqn]
theorem basis_effect (n t stack c a b tail : Nat) :
    basis.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,GuardedLogic.bRow a b c,pair t stack,c,a,b,tail⟩ := by
  simp only [basis,List.foldl_cons,List.foldl_nil,Frame.apply,Frame.push,Frame.combine,
    Cantor.unpair_pair,ctor,row0,imp,eqn,app,konst,witness,s_is_one,q,Nat.add_zero,
    GuardedLogic.bRow,GuardedLogic.single,GuardedLogic.testRow]
  <;> rfl

def marker : List Macro := [.push0,.push5,.push5,.witness,.ap,.push4,.ap,.push5,.eqn,.push0,.push5,.push5,.witness,.ap,.push5,.ap,.push5,.eqn,.imp,.push4,.push5,.eqn,.imp]
theorem marker_effect (n t stack c a b tail : Nat) :
    marker.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,GuardedLogic.testRow b a,pair t stack,c,a,b,tail⟩ := by
  simp only [marker,List.foldl_cons,List.foldl_nil,Frame.apply,Frame.push,Frame.combine,
    Cantor.unpair_pair,ctor,row0,imp,eqn,app,konst,witness,s_is_one,q,Nat.add_zero,
    GuardedLogic.bRow,GuardedLogic.single,GuardedLogic.testRow]
  <;> rfl

def tokens : List Macro := logic ++ tokens4 ++ GuardedEmitter.tokens ++ tokens6 ++ basis ++
  tokens2 ++ tokens3 ++ marker ++ tokens9

theorem batch_effect (n t stack c u v y delta tail : Nat) :
    tokens.foldl Frame.apply (Frame.apply ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩ .read5) =
      save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (GuardedLogic.rowList (u+delta) (v+y) c u) := by
  simp only [tokens,List.foldl_append,Frame.apply,Cantor.unpair_pair]
  rw [logic_effect,effect4,GuardedEmitter.effect,effect6,basis_effect,effect2,effect3,marker_effect,effect9]
  rfl

theorem batch_eval (n t stack c u v y delta tail : Nat) :
    Eval (sequence .read5 tokens) (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩) .normal
      (save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (GuardedLogic.rowList (u+delta) (v+y) c u)).regs := by
  rw [← batch_effect n t stack c u v y delta tail]
  exact sequence_eval .read5 tokens ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩
end NF180Counting.GuardedBatch
#print axioms NF180Counting.GuardedBatch.batch_eval
