import ConditionalSearchWords
set_option maxHeartbeats 8000000
set_option maxRecDepth 100000
namespace NF180Counting.GuardedLogic
open NF192.Numerical NF192.Emitter
open NF192.ProofSearch (Command candidate candidate_prefix candidate_ne_nil)
open NF192.SourceFields
theorem builds_row {a b c u x : Nat} (hu : u ≤ a) (hx : x ∈ rowList a b c u) :
    ∃ word, Builds x word := by
  have shape := last_row_split a b c u
  rw [shape] at hx
  rcases List.mem_append.mp hx with front|last
  · exact builds_emitted hu (.inl front)
  · have eq : x = lastRow a b := by simpa using last
    subst x
    apply builds_emitted (a:=a) (b:=b) (c:=1) (u:=u) hu
    exact .inr ⟨by decide, by simp [rowList]⟩
theorem deriv_buildable {x : Nat} (d : Deriv x) : ∃ word, Builds x word := by
  induction d with
  | row h hx => exact builds_row h hx
  | mp _ _ major minor =>
    obtain ⟨m,h⟩ := major
    obtain ⟨n,k⟩ := minor
    exact ⟨_, builds_mp k h⟩

/-- If the goal is provable, a single finite word halts from every command
boundary, even when an earlier candidate left a nonzero parameter. -/
theorem exists_detecting_word (d : Deriv goal) :
    ∃ cs : List Command, ∀ s, checkedRun cs s = none := by
  obtain ⟨w,hw⟩ := deriv_buildable d
  let front := resetWord ++ w
  refine ⟨front ++ [.mp 1, .mp 0], fun s => ?_⟩
  rw [checkedRun_append]
  cases h : checkedRun front s with
  | none => rfl
  | some t =>
    have e := checkedRun_survives h
    obtain ⟨c,hr⟩ := hw 0 (s.top :: s.stack) 0
    rw [show run front s = ⟨goal,0::s.top::s.stack,c,0⟩ by
      rw [show front = resetWord ++ w from rfl, run_append, reset_results]; exact hr] at e
    subst t
    change checkedRun [.mp 1, .mp 0] ⟨goal,0::s.top::s.stack,c,0⟩ = none
    by_cases hc : c = goal
    · simp [checkedRun, observes, hc]
    · simp [checkedRun, observes, step, hc]

theorem detects_iff_derives {s : State} (hs : s.Sound) :
    (∃ cs : List Command, checkedRun cs s = none) ↔ Deriv goal := by
  constructor
  · rintro ⟨cs,h⟩
    exact detects_only_goal hs h
  · intro h
    obtain ⟨cs,k⟩ := exists_detecting_word h
    exact ⟨cs,k s⟩
def one (c : Command) (s : State) : Option State :=
  if observes c s then none else some (step c s)

theorem checkedRun_cons (c : Command) (cs : List Command) (s : State) :
    checkedRun (c::cs) s = (one c s).bind (checkedRun cs) := by
  by_cases h : observes c s = true <;> simp [checkedRun, one, h]

def scan (start : Nat) (s : State) : Nat → Option State
  | 0 => some s
  | k+1 => (scan start s k).bind (checkedRun (candidate (start+k)))

theorem scan_eventually_halts (d : Deriv goal) (start : Nat) (s : State) :
    ∃ k, scan start s k = none := by
  obtain ⟨cs, universal⟩ := exists_detecting_word d
  obtain ⟨n, hn, hword⟩ := cofinal cs start
  have idx : start + (n-start) = n := by omega
  refine ⟨(n-start)+1, ?_⟩
  rw [scan,idx,candidate_prefix hword]
  cases h : scan start s (n-start) with
  | none => rfl
  | some old =>
    simp only [Option.bind_some, checkedRun_append, universal, Option.bind_none]

structure StreamState where
  next : Nat
  cursor : Nat
  proof : State

def streamStep (s : StreamState) : Option StreamState :=
  let fresh := s.cursor = 0
  let input := if fresh then s.next else s.cursor-1
  let next := if fresh then s.next+1 else s.next
  let parsed := parse input
  (one parsed.1 s.proof).map (fun result => ⟨next,parsed.2,result⟩)

def streamRun : Nat → StreamState → Option StreamState
  | 0,s => some s
  | n+1,s => (streamStep s).bind (streamRun n)

theorem stream_run_add (n m : Nat) (s : StreamState) :
    streamRun (n+m) s = (streamRun n s).bind (streamRun m) := by
  induction n generalizing s with
  | zero => simp only [Nat.zero_add, streamRun, Option.bind_some]
  | succ n ih =>
    rw [Nat.succ_add, streamRun, streamRun]
    cases h : streamStep s with
    | none => rfl
    | some t => simpa only [Option.bind_some] using ih t

theorem stream_continued (n next : Nat) (s : State) :
    streamStep ⟨next,n+1,s⟩ =
      (one (parse n).1 s).map (fun t => ⟨next,(parse n).2,t⟩) := by
  simp [streamStep]

theorem stream_candidate (n next : Nat) (s : State) :
    streamRun (candidate n).length ⟨next,n+1,s⟩ =
      (checkedRun (candidate n) s).map (fun t => ⟨next,0,t⟩) := by
  induction n using Nat.strongRecOn generalizing s with
  | ind n ih =>
    rw [candidate]
    simp only [List.length_cons, streamRun, stream_continued, checkedRun_cons]
    cases hs : one (parse n).1 s with
    | none => rfl
    | some t =>
      simp only [Option.map_some, Option.bind_some]
      by_cases hz : (parse n).2 = 0
      · simp [hz, streamRun, checkedRun]
      · simp only [hz, ↓reduceDIte]
        have hlt : (parse n).2 - 1 < n := by
          have hle := parse_decreases n
          omega
        have he : (parse n).2 = ((parse n).2-1)+1 := by omega
        rw [he]
        exact ih ((parse n).2-1) hlt t

theorem stream_fresh (n : Nat) (s : State) :
    streamStep ⟨n,0,s⟩ = streamStep ⟨n+1,n+1,s⟩ := by simp [streamStep]

theorem stream_candidate_fresh (n : Nat) (s : State) :
    streamRun (candidate n).length ⟨n,0,s⟩ =
      (checkedRun (candidate n) s).map (fun t => ⟨n+1,0,t⟩) := by
  have he := stream_candidate n (n+1) s
  have hn := List.length_pos_iff.mpr (candidate_ne_nil n)
  obtain ⟨m,hm⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : (candidate n).length ≠ 0)
  rw [hm, streamRun, stream_fresh]
  simpa only [hm, streamRun] using he

theorem scan_reached (start : Nat) (s : State) (k : Nat) :
    ∃ ticks, streamRun ticks ⟨start,0,s⟩ = (scan start s k).map (fun t => ⟨start+k,0,t⟩) := by
  induction k with
  | zero => exact ⟨0,rfl⟩
  | succ n ih =>
    obtain ⟨ticks,ht⟩ := ih
    refine ⟨ticks+(candidate (start+n)).length, ?_⟩
    rw [stream_run_add, ht, scan]
    cases hs : scan start s n with
    | none => rfl
    | some s => exact stream_candidate_fresh (start+n) s

def StreamSound : Option StreamState → Prop
  | none => Deriv goal
  | some s => s.proof.Sound

theorem stream_step_sound (s : StreamState) (hs : s.proof.Sound) :
    StreamSound (streamStep s) := by
  simp only [streamStep]
  generalize parse (if s.cursor = 0 then s.next else s.cursor-1) = parsed
  rcases parsed with ⟨c, tail⟩
  by_cases o : observes c s.proof = true
  · have halt : checkedRun [c] s.proof = none := by simp [checkedRun, o]
    simpa [one, o, StreamSound] using detects_only_goal hs halt
  · simpa [one, o, StreamSound] using step_sound c s.proof hs

theorem stream_run_sound (ticks : Nat) (s : StreamState) (hs : s.proof.Sound) :
    StreamSound (streamRun ticks s) := by
  induction ticks generalizing s with
  | zero => exact hs
  | succ n ih =>
    have hc := stream_step_sound s hs
    cases he : streamStep s with
    | none => simpa only [streamRun, he, Option.bind_none] using hc
    | some t =>
      have ht : t.proof.Sound := by simpa only [he, StreamSound] using hc
      simpa only [streamRun, he, Option.bind_some] using ih t ht

/-- For every sound entry at a refill boundary, the successive natural
candidates halt exactly when the ten-family calculus derives numeral 3. -/
theorem stream_halting_iff_goal (start : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, streamRun ticks ⟨start,0,s⟩ = none) ↔ Deriv goal := by
  constructor
  · rintro ⟨ticks, ht⟩
    simpa only [ht, StreamSound] using stream_run_sound ticks ⟨start,0,s⟩ hs
  · intro h
    obtain ⟨k,hk⟩ := scan_eventually_halts h start s
    obtain ⟨ticks,ht⟩ := scan_reached start s k
    exact ⟨ticks, by simpa only [hk, Option.map_none] using ht⟩

end NF180Counting.GuardedLogic
#print axioms NF180Counting.GuardedLogic.deriv_buildable
#print axioms NF180Counting.GuardedLogic.stream_halting_iff_goal

#print axioms NF180Counting.GuardedLogic.stream_halting_iff_goal
