import GuardedBridge
import ConditionalDerivation

namespace CountingRefill.GuardedBridge
open NF192

theorem nonhalting_yields_counting_model
    (h : ¬ Halts (raw newProgram) (some (conf 0 5 0 0 (fun _ => 0)))) :
    RangeNFU.HasCountingModel :=
  NF180Counting.GuardedLogic.nonderivability_yields_counting
    (fun goal => h (guarded187_register_halts_iff_goal.mpr goal))

#print axioms nonhalting_yields_counting_model
end CountingRefill.GuardedBridge
