import Std

namespace CountingRefill
inductive Cmd where
  | inc (reg nextPC : Nat)
  | dec (reg : Nat) (zeroPC : Option Nat) (positivePC : Nat)
  | jump (nextPC : Nat)
  deriving Repr, DecidableEq, BEq

structure Regs where
  counter : Nat
  temp : Nat
  word : Nat
  others : Nat → Nat

def Regs.read (r : Regs) (i : Nat) : Nat :=
  if i=0 then r.counter else if i=6 then r.temp else if i=7 then r.word else r.others i

def Regs.write (r : Regs) (i v : Nat) : Regs :=
  if i=0 then { r with counter := v }
  else if i=6 then { r with temp := v }
  else if i=7 then { r with word := v }
  else { r with others := fun j => if j=i then v else r.others j }

def Regs.bump (r : Regs) : Regs := {r with counter := r.counter+1}

def liftPC (p : Nat) : Nat := if p≤2 then p else p+1

def Cmd.remap : Cmd → Cmd
  | .inc i p => .inc i (liftPC p)
  | .dec i z p => .dec i (z.map liftPC) (liftPC p)
  | .jump p => .jump (liftPC p)

def Cmd.free : Cmd → Bool
  | .inc i _ | .dec i _ _ => decide (i≠0)
  | .jump _ => true

def Allowed (i : Nat) : Prop := i≤2 ∨ 9≤i
instance (i : Nat) : Decidable (Allowed i) := inferInstanceAs (Decidable (_ ∨ _))

def Cmd.closed : Cmd → Bool
  | .inc _ p | .jump p => decide (Allowed p)
  | .dec _ z p => decide (Allowed p) && (z.map (fun v => decide (Allowed v))).getD true

abbrev State := Nat × Regs

def execute (c : Cmd) (r : Regs) : Option State :=
  match c with
  | .inc i p => some (p,r.write i (r.read i+1))
  | .dec i z p =>
    match r.read i with
    | 0 => z.map (fun k => (k,r))
    | n+1 => some (p,r.write i n)
  | .jump p => some (p,r)

theorem read_bump (i : Nat) (ne : i≠0) (r : Regs) :
    r.bump.read i = r.read i := by simp [Regs.read,Regs.bump,ne]

theorem write_bump (i v : Nat) (ne : i≠0) (r : Regs) :
    r.bump.write i v = (r.write i v).bump := by
  by_cases t : i=6 <;> by_cases w : i=7 <;> simp [Regs.write,Regs.bump,ne,t,w]

/-- Equality includes a zero-branch halt on both sides. The mapped old result
    has its counter raised by one to recover the new register state. -/
theorem single_step (new old : Cmd) (r : Regs)
    (rows : old = new.remap) (free : new.free = true) :
    (execute old r).map (fun s => (s.1,s.2.bump)) =
      (execute new r.bump).map (fun s => (liftPC s.1,s.2)) := by
  subst old
  cases new with
  | jump p => rfl
  | inc i p =>
    have h : i≠0 := by simpa [Cmd.free] using free
    simp [execute,Cmd.remap,read_bump _ h,write_bump _ _ h]
  | dec i z p =>
    have h : i≠0 := by simpa [Cmd.free] using free
    cases e : r.read i <;> cases z <;> simp [Cmd.remap,execute,read_bump _ h,write_bump _ _ h,e]

inductive Reach (program : Nat → Cmd) : State → State → Prop where
  | refl (s : State) : Reach program s s
  | next {a b c : State} : execute (program a.1) a.2 = some b → Reach program b c → Reach program a c

theorem Reach.trans {p a b c} (h : Reach p a b) (k : Reach p b c) : Reach p a c := by
  induction h with
  | refl => exact k
  | next s _ ih => exact .next s (ih k)

end CountingRefill
