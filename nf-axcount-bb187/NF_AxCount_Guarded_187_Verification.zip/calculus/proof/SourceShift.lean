import SourceGraph
set_option maxHeartbeats 0
set_option maxRecDepth 20000
namespace CountingRefill

def atRow (i : Nat) : Entry := (batches.flatten[i]?).getD ⟨.jump 0,.jump 0⟩

theorem row_ok (i : Nat) : (atRow i).ok = true := by
  unfold atRow
  cases h : batches.flatten[i]? with
  | none => rfl
  | some e =>
    obtain ⟨batch,hm,he⟩ := List.mem_flatten.mp (List.mem_of_getElem? h)
    exact List.all_eq_true.mp (List.all_eq_true.mp batches_ok batch hm) e he

def oldProgram (i : Nat) : Cmd := if i<10 then oldPrefix i else (atRow (i-10)).old
def newProgram (i : Nat) : Cmd := if i<9 then newPrefix i else (atRow (i-9)).new

theorem outside_rows {i : Nat} (outside : i≤1 ∨ 9≤i) :
    oldProgram (liftPC i) = (newProgram i).remap ∧ (newProgram i).free = true := by
  rcases outside with h|h
  · have cases : i=0 ∨ i=1 := by omega
    rcases cases with rfl|rfl <;> exact ⟨rfl,rfl⟩
  · have lt2 : ¬i≤2 := by omega
    have lt9 : ¬i<9 := by omega
    have lt10 : ¬i+1<10 := by omega
    have same : i+1-10=i-9 := by omega
    have ok := row_ok (i-9)
    simpa [newProgram,oldProgram,liftPC,lt2,lt9,lt10,same] using (show (decide ((atRow (i-9)).old=(atRow (i-9)).new.remap) && (atRow (i-9)).new.free) = true from (Bool.and_eq_true_iff.mp ok).1)

theorem ordinary_simulation {i : Nat} (outside : i≤1 ∨ 9≤i) (r : Regs) :
    (execute (oldProgram (liftPC i)) r).map (fun s => (s.1,s.2.bump)) =
      (execute (newProgram i) r.bump).map (fun s => (liftPC s.1,s.2)) :=
  single_step _ _ _ (outside_rows outside).1 (outside_rows outside).2

abbrev conf (p n t w : Nat) (r : Nat → Nat) : State := (p,⟨n,t,w,r⟩)

theorem new_copy (n t w : Nat) (r : Nat → Nat) :
    Reach newProgram (conf 2 n t w r) (conf 6 0 (t+n) (w+n) r) := by
  induction n generalizing t w with
  | zero => exact .next rfl (.refl _)
  | succ n ih =>
    have h := ih (t+1) (w+1)
    rw [show t+1+n=t+(n+1) by omega,show w+1+n=w+(n+1) by omega] at h
    exact .next (b:=conf 3 n t w r) rfl (.next (b:=conf 4 n t (w+1) r) rfl
      (.next (b:=conf 5 n (t+1) (w+1) r) rfl (.next rfl h)))

theorem new_restore (t n w : Nat) (r : Nat → Nat) :
    Reach newProgram (conf 6 n t w r) (conf 9 (n+t+1) 0 w r) := by
  induction t generalizing n with
  | zero => exact .next (b:=conf 7 (n+1) 0 w r) rfl (.next rfl (.refl _))
  | succ t ih =>
    have h := ih (n+1)
    rw [show n+1+t+1=n+(t+1)+1 by omega] at h
    exact .next (b:=conf 7 (n+1) (t+1) w r) rfl
      (.next (b:=conf 8 (n+1) t w r) rfl (.next rfl h))

theorem old_copy (n t w : Nat) (r : Nat → Nat) :
    Reach oldProgram (conf 3 n t w r) (conf 7 0 (t+n) (w+n) r) := by
  induction n generalizing t w with
  | zero => exact .next rfl (.refl _)
  | succ n ih =>
    have h := ih (t+1) (w+1)
    rw [show t+1+n=t+(n+1) by omega,show w+1+n=w+(n+1) by omega] at h
    exact .next (b:=conf 4 n t w r) rfl (.next (b:=conf 5 n t (w+1) r) rfl
      (.next (b:=conf 6 n (t+1) (w+1) r) rfl (.next rfl h)))

theorem old_restore (t n w : Nat) (r : Nat → Nat) :
    Reach oldProgram (conf 7 n t w r) (conf 10 (n+t) 0 w r) := by
  induction t generalizing n with
  | zero => exact .next rfl (.refl _)
  | succ t ih =>
    have h := ih (n+1)
    rw [show n+1+t=n+(t+1) by omega] at h
    exact .next (b:=conf 8 n t w r) rfl (.next (b:=conf 9 (n+1) t w r) rfl
      (.next rfl h))

/-- Both refill fragments produce the same next proof word. The one-unit
counter offset at entry is preserved at the exit. -/
theorem refill_agrees (k : Nat) (r : Nat → Nat) :
    Reach oldProgram (conf 2 k 0 0 r) (conf 10 (k+1) 0 (k+1) r) ∧
    Reach newProgram (conf 2 (k+1) 0 0 r) (conf 9 (k+2) 0 (k+1) r) := by
  constructor
  · apply Reach.next (b:=conf 3 (k+1) 0 0 r) rfl
    apply (old_copy (k+1) 0 0 r).trans
    simpa using old_restore (k+1) 0 (k+1) r
  · apply (new_copy (k+1) 0 0 r).trans
    simpa using new_restore (k+1) 0 (k+1) r

theorem new_refill_all (k t w : Nat) (r : Nat → Nat) :
    Reach newProgram (conf 2 k t w r) (conf 9 (t+k+1) 0 (w+k) r) := by
  apply (new_copy k t w r).trans
  simpa using new_restore (t+k) 0 (w+k) r

theorem old_refill_all (k t w : Nat) (r : Nat → Nat) :
    Reach oldProgram (conf 2 k t w r) (conf 10 (t+(k+1)) 0 (w+(k+1)) r) := by
  apply Reach.next (b:=conf 3 (k+1) t w r) rfl
  apply (old_copy (k+1) t w r).trans
  simpa using old_restore (t+(k+1)) 0 (w+(k+1)) r

theorem closed_outside {i : Nat} (outside : i≤1 ∨ 9≤i) : (newProgram i).closed = true := by
  rcases outside with h|h
  · have cases : i=0 ∨ i=1 := by omega
    rcases cases with rfl|rfl <;> rfl
  · have hn : ¬i<9 := by omega
    simpa [newProgram,hn] using (Bool.and_eq_true_iff.mp (row_ok (i-9))).2

#print axioms refill_agrees
#print axioms ordinary_simulation
end CountingRefill
