import ConditionalLiteral
import MachineCountdown
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace NF180Counting.GuardedLogic.R7Raw
open NF192 NF192.Source

def asCommand : NF192.Emitter.Instruction → Command
  | .inc r next => .inc r.val next
  | .dec r z next => .dec r.val z next false
  | .decHalt r next => .dec r.val 3629 next true
  | .jump next => .jump next
  | .halt => .inc 9 0

def program (pc : Nat) : Command := asCommand (NF180Counting.GuardedLogic.Literal.program pc)
def step : Config → Config
  | some (pc,rs) => execute (program pc) rs
  | none => none

def advance : Nat → Config → Config
  | 0, s => s
  | n+1, s => advance n (step s)

theorem advance_add (i j : Nat) (s : Config) :
    advance (i+j) s = advance j (advance i s) := by
  induction i generalizing s with
  | zero => simp [advance]
  | succ i ih => simp only [Nat.succ_add, advance, ih]
theorem countdown_row_3623 : program 3623 = Command.dec 5 3627 3624 false := by decide
theorem countdown_row_3624 : program 3624 = Command.dec 5 3627 3625 false := by decide
theorem countdown_row_3625 : program 3625 = Command.dec 5 3627 3626 false := by decide
theorem countdown_row_3626 : program 3626 = Command.dec 5 3629 3627 true := by decide
theorem countdown_row_3627 : program 3627 = Command.dec 5 3629 3628 false := by decide
theorem countdown_row_3628 : program 3628 = Command.jump 3627 := by decide

private theorem dec_pos {pc target zero : Nat} {hlt : Bool}
    (instruction : program pc = Command.dec 5 zero target hlt) (n : Nat) (rs : Registers) :
    step (goalConfig pc (n+1) rs) = goalConfig target n rs := by
  simp [step, goalConfig, execute, instruction]

private theorem dec_zero {pc target pos : Nat}
    (instruction : program pc = Command.dec 5 target pos false) (rs : Registers) :
    step (goalConfig pc 0 rs) = goalConfig target 0 rs := by
  simp [step, goalConfig, execute, instruction]

private theorem dec_stop {pc zero pos : Nat}
    (instruction : program pc = Command.dec 5 zero pos true) (rs : Registers) :
    step (goalConfig pc 0 rs) = Config.halted := by
  simp [step, goalConfig, execute, instruction]

private theorem jump_step {pc target : Nat} (instruction : program pc = Command.jump target)
    (n : Nat) (rs : Registers) :
    step (goalConfig pc n rs) = goalConfig target n rs := by
  simp [step, goalConfig, execute, instruction]

/-- Every iteration of the clear loop consumes one unit in exactly two steps. -/
theorem clear_all (n : Nat) (rs : Registers) :
    advance (2*n+1) (goalConfig 3627 n rs) = goalConfig 3629 0 rs := by
  induction n with
  | zero =>
    exact dec_zero countdown_row_3627 rs
  | succ k ih =>
    have ticks : 2*(k+1)+1 = 2 + (2*k+1) := by omega
    rw [ticks, advance_add]
    have iteration : advance 2 (goalConfig 3627 (k+1) rs) = goalConfig 3627 k rs := by
      change step (step (goalConfig 3627 (k+1) rs)) = goalConfig 3627 k rs
      rw [dec_pos countdown_row_3627, jump_step countdown_row_3628]
    rw [iteration]
    exact ih

theorem countdown_correct (n : Nat) (rs : Registers) :
    advance (countdownDuration n) (goalConfig 3623 n rs) =
    (if n = 3 then Config.halted else goalConfig 3629 0 rs) := by
  cases n with
  | zero =>
    change step (step (goalConfig 3623 0 rs)) = goalConfig 3629 0 rs
    rw [dec_zero countdown_row_3623, dec_zero countdown_row_3627]
  | succ n =>
    cases n with
    | zero =>
      change step (step (step (goalConfig 3623 1 rs))) = goalConfig 3629 0 rs
      rw [dec_pos countdown_row_3623, dec_zero countdown_row_3624, dec_zero countdown_row_3627]
    | succ n =>
      cases n with
      | zero =>
        change step (step (step (step (goalConfig 3623 2 rs)))) = goalConfig 3629 0 rs
        rw [dec_pos countdown_row_3623, dec_pos countdown_row_3624,
          dec_zero countdown_row_3625, dec_zero countdown_row_3627]
      | succ n =>
        cases n with
        | zero =>
          change step (step (step (step (goalConfig 3623 3 rs)))) = Config.halted
          rw [dec_pos countdown_row_3623, dec_pos countdown_row_3624,
            dec_pos countdown_row_3625, dec_stop countdown_row_3626]
        | succ k =>
          have neq : k.succ.succ.succ.succ ≠ 3 := by omega
          rw [ite_eq_right neq]
          change advance (4+(2*k+1)) (goalConfig 3623 (k+4) rs) = goalConfig 3629 0 rs
          rw [advance_add 4 (2*k+1)]
          have first : advance 4 (goalConfig 3623 (k+4) rs) = goalConfig 3627 k rs := by
            change step (step (step (step (goalConfig 3623 (k+4) rs)))) = goalConfig 3627 k rs
            rw [dec_pos countdown_row_3623, dec_pos countdown_row_3624,
              dec_pos countdown_row_3625, dec_pos countdown_row_3626]
          rw [first, clear_all]

theorem countdown_halts_iff (n : Nat) (rs : Registers) :
    advance (countdownDuration n) (goalConfig 3623 n rs) = Config.halted ↔ n = 3 := by
  rw [countdown_correct]
  by_cases h : n = 3 <;> simp [h, goalConfig]


end NF180Counting.GuardedLogic.R7Raw
#print axioms NF180Counting.GuardedLogic.R7Raw.countdown_correct
