import GuardedLower
import ConditionalChart

namespace CountingRefill.GuardedBridge
open NF192

theorem nonhalting_iff_guarded_chart :
    (¬ Halts (raw newProgram) (some (conf 0 5 0 0 (fun _ => 0)))) ↔
      NF180Counting.GuardedLogic.HasGuardedChart :=
  guarded187_register_halts_iff_goal.not.trans
    NF180Counting.GuardedLogic.nonderivability_iff_guarded_chart

#print axioms nonhalting_iff_guarded_chart
end CountingRefill.GuardedBridge
