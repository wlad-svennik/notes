import ConditionalRegisterAX
import ConditionalSearch
import NumericalAXBatches
import SourceRoundtrip
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace NF180Counting.GuardedLogic.R7Register
open NF180Counting.GuardedLogic
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers NF192.SourceFields
open NF192.ProofSearch (Command pack pop_pack candidate candidate_prefix candidate_ne_nil)
def registers (n cursor : Nat) (s : State) : Frame :=
  ⟨n,s.top,pack s.stack,0,s.param,s.cache,cursor⟩

def after (n cursor : Nat) : Option State → Source.Config
  | none => Source.Config.halted
  | some s => atFrame 0 (registers n cursor s)

theorem selected_mode (n d tail : Nat) (s : State) :
    Moves (atFrame 3522 ⟨n,s.top,pack s.stack,0,s.param+d,s.cache,tail⟩)
      (after n tail (one (.mode d) s)) := by
  have k := mp_correct n s.top (pack s.stack) 0 (s.param+d) s.cache tail
  rw [pop_pack] at k
  exact k

theorem selected_mp (n d tail : Nat) (s : State) :
    Moves (atFrame 3596 ⟨n,s.top,pack s.stack,0,s.param+d,s.cache,tail⟩)
      (after n tail (one (.mp d) s)) := by
  have hm := mode_correct n s.top (pack s.stack) 0 (s.param+d) s.cache tail
  rw [pop_pack] at hm
  by_cases hit : s.cache = goal
  · simpa only [hit, one, observes, beq_self_eq_true, ite_true, after, ite_eq_left, atFrame, frame, Frame.regs, Visits] using hm
  · have nohit : (s.cache == goal) = false := beq_eq_false_iff_ne.mpr hit
    cases hn : s.param+d with
    | zero => simpa only [one, observes, nohit, Bool.false_eq_true, ite_false, after, NF180Counting.GuardedLogic.step, hn,
        ite_eq_right hit, registers, atFrame, frame, Frame.regs] using hm
    | succ k => simpa only [one, observes, nohit, Bool.false_eq_true, ite_false, after, NF180Counting.GuardedLogic.step, hn,
        ite_eq_right hit, registers, atFrame, frame, Frame.regs] using hm

/-- All the AX batches, their loop branches, and the automatic final NIP. -/
def AxSimulation : Prop := ∀ (n u b d tail : Nat) (rest : List (Nat × Nat)) (s : State),
  Moves (atFrame 40 ⟨n,s.top,pack s.stack,rest.length,s.param+u,s.cache,
              encodeBatch (b,d) (encodeBatches rest tail)⟩)
    (after n tail (one (.ax u b d rest) s))

theorem command_encoded (ax : AxSimulation) (n : Nat) (c : Command)
    (tail : Nat) (s : State) :
    Moves (atFrame 10 (registers n (assemble c tail) s)) (after n tail (one c s)) := by
  cases c with
  | mp d =>
    have rd := outer_read_fields n s.top (pack s.stack) 0 s.param s.cache 0 d tail
    exact (rd.trans (dispatch_mp _ _ _ _ _ _)).trans (selected_mp n d tail s)
  | mode d =>
    have rd := outer_read_fields n s.top (pack s.stack) 0 s.param s.cache 1 d tail
    exact ((rd.trans (dispatch_positive _ _ _ 0 _ _ _)).trans (mode_entry _ _ _ _ _ _)).trans
      (selected_mode n d tail s)
  | ax u b d rest =>
    have rd := outer_read_fields n s.top (pack s.stack) 0 s.param s.cache (rest.length+2) u
      (encodeBatch (b,d) (encodeBatches rest tail))
    rw [Nat.zero_add] at rd
    exact ((rd.trans (dispatch_positive _ _ _ (rest.length+1) _ _ _)).trans
      (ax_entry _ _ _ rest.length _ _ _)).trans (ax n u b d tail rest s)

theorem command_arbitrary (ax : AxSimulation) (n raw : Nat) (s : State) :
    Moves (atFrame 10 (registers n raw s)) (after n (parse raw).2 (one (parse raw).1 s)) := by
  have h := command_encoded ax n (parse raw).1 (parse raw).2 s
  rwa [assemble_parse] at h

theorem selected_ax : AxSimulation := by
  intro n u b d tail rest s
  exact ax_command batch_embedded n u b d rest tail s

theorem command_fresh (n : Nat) (s : State) :
    Moves (atFrame 0 (registers n 0 s))
      (after (n+1) (Cantor.unpair (n+1)).2 (one (.mp (Cantor.unpair (n+1)).1) s)) := by
  have h := outer_fresh n s.top (pack s.stack) 0 s.param s.cache
  exact (h.trans (dispatch_mp _ _ _ _ _ _)).trans (selected_mp _ _ _ s)

theorem command_continued (n k : Nat) (s : State) :
    Moves (atFrame 0 (registers n (k+1) s)) (after n (parse k).2 (one (parse k).1 s)) :=
  (outer_continued n s.top (pack s.stack) 0 s.param s.cache k).trans (command_arbitrary selected_ax n k s)

end NF180Counting.GuardedLogic.R7Register
#print axioms NF180Counting.GuardedLogic.R7Register.command_fresh
#print axioms NF180Counting.GuardedLogic.R7Register.command_continued
