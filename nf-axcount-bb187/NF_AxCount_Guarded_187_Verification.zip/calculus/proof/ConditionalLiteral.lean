import ConditionalBatch
import NumericalEmitterChecking
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace NF180Counting.GuardedLogic
open NF192.Numerical NF192.Emitter
abbrev batchCode := sequence .read5 GuardedBatch.tokens
abbrev batch_eval := @GuardedBatch.batch_eval
namespace Literal
def pre0 : List Instruction := [
  .dec 8 2 1, .jump 10, .inc 0 3, .dec 0 7 4, .inc 7 5, .inc 6 6,
  .jump 3, .dec 6 10 8, .inc 0 9, .jump 7, .dec 8 18 11, .inc 7 12,
  .dec 6 14 13, .jump 17, .dec 7 17 15, .inc 6 16, .jump 14, .jump 10,
  .dec 7 21 19, .inc 8 20, .jump 18, .dec 6 24 22, .inc 3 23, .jump 21,
  .dec 8 32 25, .inc 7 26, .dec 6 28 27, .jump 31, .dec 7 31 29, .inc 6 30,
  .jump 28, .jump 24, .dec 7 35 33, .inc 8 34, .jump 32, .dec 6 38 36,
  .inc 4 37, .jump 35, .dec 3 3596 39, .dec 3 3522 40]
def pre : List Instruction := [pre0].flatten
def mid0 : List Instruction := [
  .dec 8 48 41, .inc 7 42, .dec 6 44 43, .jump 47, .dec 7 47 45, .inc 6 46,
  .jump 44, .jump 40, .dec 7 51 49, .inc 8 50, .jump 48, .dec 6 54 52,
  .inc 5 53, .jump 51, .dec 1 57 55, .inc 6 56, .jump 54, .dec 2 60 58,
  .inc 1 59, .jump 57, .dec 1 64 61, .inc 7 62, .inc 6 63, .jump 60,
  .dec 6 70 65, .inc 7 66, .dec 6 69 67, .inc 1 68, .jump 66, .jump 60,
  .dec 7 73 71, .inc 2 72, .jump 70, .dec 3 77 74, .inc 6 75, .inc 1 76,
  .jump 73, .dec 6 80 78, .inc 3 79, .jump 77, .dec 1 83 81, .inc 6 82,
  .jump 80, .dec 2 86 84, .inc 1 85, .jump 83, .dec 1 90 87, .inc 7 88]
def mid1 : List Instruction := [
  .inc 6 89, .jump 86, .dec 6 96 91, .inc 7 92, .dec 6 95 93, .inc 1 94,
  .jump 92, .jump 86, .dec 7 99 97, .inc 2 98, .jump 96, .dec 4 103 100,
  .inc 6 101, .inc 1 102, .jump 99, .dec 6 106 104, .inc 4 105, .jump 103,
  .dec 2 114 107, .inc 7 108, .dec 6 110 109, .jump 113, .dec 7 113 111, .inc 6 112,
  .jump 110, .jump 106, .dec 7 117 115, .inc 2 116, .jump 114, .dec 1 121 118,
  .inc 7 119, .inc 6 120, .jump 117, .dec 6 127 122, .inc 7 123, .dec 6 126 124,
  .inc 1 125, .jump 123, .jump 117, .dec 7 131 128, .inc 1 129, .inc 1 130,
  .jump 127, .dec 8 139 132, .inc 7 133, .dec 6 135 134, .jump 138, .dec 7 138 136]
def mid2 : List Instruction := [
  .inc 6 137, .jump 135, .jump 131, .dec 7 142 140, .inc 8 141, .jump 139,
  .dec 6 145 143, .inc 4 144, .jump 142, .dec 1 148 146, .inc 6 147, .jump 145,
  .dec 2 151 149, .inc 1 150, .jump 148, .dec 1 155 152, .inc 7 153, .inc 6 154,
  .jump 151, .dec 6 161 156, .inc 7 157, .dec 6 160 158, .inc 1 159, .jump 157,
  .jump 151, .dec 7 164 162, .inc 2 163, .jump 161, .dec 4 168 165, .inc 6 166,
  .inc 1 167, .jump 164, .dec 6 171 169, .inc 4 170, .jump 168, .dec 2 179 172,
  .inc 7 173, .dec 6 175 174, .jump 178, .dec 7 178 176, .inc 6 177, .jump 175,
  .jump 171, .dec 7 182 180, .inc 2 181, .jump 179, .dec 1 186 183, .inc 7 184]
def mid3 : List Instruction := [
  .inc 6 185, .jump 182, .dec 6 192 187, .inc 7 188, .dec 6 191 189, .inc 1 190,
  .jump 188, .jump 182, .dec 7 196 193, .inc 1 194, .inc 1 195, .jump 192,
  .dec 1 199 197, .inc 6 198, .jump 196, .dec 2 202 200, .inc 1 201, .jump 199,
  .dec 1 206 203, .inc 7 204, .inc 6 205, .jump 202, .dec 6 212 207, .inc 7 208,
  .dec 6 211 209, .inc 1 210, .jump 208, .jump 202, .dec 7 215 213, .inc 2 214,
  .jump 212, .dec 4 219 216, .inc 6 217, .inc 1 218, .jump 215, .dec 6 222 220,
  .inc 4 221, .jump 219, .dec 1 225 223, .inc 6 224, .jump 222, .dec 2 228 226,
  .inc 1 227, .jump 225, .dec 1 232 229, .inc 7 230, .inc 6 231, .jump 228]
def mid4 : List Instruction := [
  .dec 6 238 233, .inc 7 234, .dec 6 237 235, .inc 1 236, .jump 234, .jump 228,
  .dec 7 241 239, .inc 2 240, .jump 238, .dec 3 245 242, .inc 6 243, .inc 1 244,
  .jump 241, .dec 6 248 246, .inc 3 247, .jump 245, .dec 2 256 249, .inc 7 250,
  .dec 6 252 251, .jump 255, .dec 7 255 253, .inc 6 254, .jump 252, .jump 248,
  .dec 7 259 257, .inc 2 258, .jump 256, .dec 1 263 260, .inc 7 261, .inc 6 262,
  .jump 259, .dec 6 269 264, .inc 7 265, .dec 6 268 266, .inc 1 267, .jump 265,
  .jump 259, .dec 7 273 270, .inc 1 271, .inc 1 272, .jump 269, .dec 1 276 274,
  .inc 6 275, .jump 273, .dec 2 279 277, .inc 1 278, .jump 276, .dec 1 283 280]
def mid5 : List Instruction := [
  .inc 7 281, .inc 6 282, .jump 279, .dec 6 289 284, .inc 7 285, .dec 6 288 286,
  .inc 1 287, .jump 285, .jump 279, .dec 7 292 290, .inc 2 291, .jump 289,
  .dec 5 296 293, .inc 6 294, .inc 1 295, .jump 292, .dec 6 299 297, .inc 5 298,
  .jump 296, .dec 1 302 300, .inc 6 301, .jump 299, .dec 2 305 303, .inc 1 304,
  .jump 302, .dec 1 309 306, .inc 7 307, .inc 6 308, .jump 305, .dec 6 315 310,
  .inc 7 311, .dec 6 314 312, .inc 1 313, .jump 311, .jump 305, .dec 7 318 316,
  .inc 2 317, .jump 315, .dec 3 322 319, .inc 6 320, .inc 1 321, .jump 318,
  .dec 6 325 323, .inc 3 324, .jump 322, .dec 2 333 326, .inc 7 327, .dec 6 329 328]
def mid6 : List Instruction := [
  .jump 332, .dec 7 332 330, .inc 6 331, .jump 329, .jump 325, .dec 7 336 334,
  .inc 2 335, .jump 333, .dec 1 340 337, .inc 7 338, .inc 6 339, .jump 336,
  .dec 6 346 341, .inc 7 342, .dec 6 345 343, .inc 1 344, .jump 342, .jump 336,
  .dec 7 350 347, .inc 1 348, .inc 1 349, .jump 346, .dec 2 358 351, .inc 7 352,
  .dec 6 354 353, .jump 357, .dec 7 357 355, .inc 6 356, .jump 354, .jump 350,
  .dec 7 361 359, .inc 2 360, .jump 358, .dec 1 365 362, .inc 7 363, .inc 6 364,
  .jump 361, .dec 6 371 366, .inc 7 367, .dec 6 370 368, .inc 1 369, .jump 367,
  .jump 361, .dec 7 375 372, .inc 1 373, .inc 1 374, .jump 371, .dec 2 383 376]
def mid7 : List Instruction := [
  .inc 7 377, .dec 6 379 378, .jump 382, .dec 7 382 380, .inc 6 381, .jump 379,
  .jump 375, .dec 7 386 384, .inc 2 385, .jump 383, .dec 1 390 387, .inc 7 388,
  .inc 6 389, .jump 386, .dec 6 396 391, .inc 7 392, .dec 6 395 393, .inc 1 394,
  .jump 392, .jump 386, .dec 7 400 397, .inc 1 398, .inc 1 399, .jump 396,
  .dec 1 403 401, .inc 6 402, .jump 400, .dec 2 406 404, .inc 1 405, .jump 403,
  .dec 1 410 407, .inc 7 408, .inc 6 409, .jump 406, .dec 6 416 411, .inc 7 412,
  .dec 6 415 413, .inc 1 414, .jump 412, .jump 406, .dec 7 419 417, .inc 2 418,
  .jump 416, .dec 5 423 420, .inc 6 421, .inc 1 422, .jump 419, .dec 6 426 424]
def mid8 : List Instruction := [
  .inc 5 425, .jump 423, .dec 1 429 427, .inc 6 428, .jump 426, .dec 2 432 430,
  .inc 1 431, .jump 429, .dec 1 436 433, .inc 7 434, .inc 6 435, .jump 432,
  .dec 6 442 437, .inc 7 438, .dec 6 441 439, .inc 1 440, .jump 438, .jump 432,
  .dec 7 445 443, .inc 2 444, .jump 442, .dec 5 449 446, .inc 6 447, .inc 1 448,
  .jump 445, .dec 6 452 450, .inc 5 451, .jump 449, .dec 2 460 453, .inc 7 454,
  .dec 6 456 455, .jump 459, .dec 7 459 457, .inc 6 458, .jump 456, .jump 452,
  .dec 7 463 461, .inc 2 462, .jump 460, .dec 1 467 464, .inc 7 465, .inc 6 466,
  .jump 463, .dec 6 473 468, .inc 7 469, .dec 6 472 470, .inc 1 471, .jump 469]
def mid9 : List Instruction := [
  .jump 463, .dec 7 477 474, .inc 1 475, .inc 1 476, .jump 473, .inc 1 478,
  .inc 1 479, .dec 1 482 480, .inc 6 481, .jump 479, .dec 2 485 483, .inc 1 484,
  .jump 482, .dec 1 489 486, .inc 7 487, .inc 6 488, .jump 485, .dec 6 495 490,
  .inc 7 491, .dec 6 494 492, .inc 1 493, .jump 491, .jump 485, .dec 7 498 496,
  .inc 2 497, .jump 495, .dec 4 502 499, .inc 6 500, .inc 1 501, .jump 498,
  .dec 6 505 503, .inc 4 504, .jump 502, .dec 2 513 506, .inc 7 507, .dec 6 509 508,
  .jump 512, .dec 7 512 510, .inc 6 511, .jump 509, .jump 505, .dec 7 516 514,
  .inc 2 515, .jump 513, .dec 1 520 517, .inc 7 518, .inc 6 519, .jump 516]
def mid10 : List Instruction := [
  .dec 6 526 521, .inc 7 522, .dec 6 525 523, .inc 1 524, .jump 522, .jump 516,
  .dec 7 530 527, .inc 1 528, .inc 1 529, .jump 526, .inc 1 531, .dec 1 534 532,
  .inc 6 533, .jump 531, .dec 2 537 535, .inc 1 536, .jump 534, .dec 1 541 538,
  .inc 7 539, .inc 6 540, .jump 537, .dec 6 547 542, .inc 7 543, .dec 6 546 544,
  .inc 1 545, .jump 543, .jump 537, .dec 7 550 548, .inc 2 549, .jump 547,
  .dec 5 554 551, .inc 6 552, .inc 1 553, .jump 550, .dec 6 557 555, .inc 5 556,
  .jump 554, .dec 2 565 558, .inc 7 559, .dec 6 561 560, .jump 564, .dec 7 564 562,
  .inc 6 563, .jump 561, .jump 557, .dec 7 568 566, .inc 2 567, .jump 565]
def mid11 : List Instruction := [
  .dec 1 572 569, .inc 7 570, .inc 6 571, .jump 568, .dec 6 578 573, .inc 7 574,
  .dec 6 577 575, .inc 1 576, .jump 574, .jump 568, .dec 7 582 579, .inc 1 580,
  .inc 1 581, .jump 578, .inc 1 583, .dec 1 586 584, .inc 6 585, .jump 583,
  .dec 2 589 587, .inc 1 588, .jump 586, .dec 1 593 590, .inc 7 591, .inc 6 592,
  .jump 589, .dec 6 599 594, .inc 7 595, .dec 6 598 596, .inc 1 597, .jump 595,
  .jump 589, .dec 7 602 600, .inc 2 601, .jump 599, .dec 1 605 603, .inc 6 604,
  .jump 602, .dec 2 608 606, .inc 1 607, .jump 605, .dec 1 612 609, .inc 7 610,
  .inc 6 611, .jump 608, .dec 6 618 613, .inc 7 614, .dec 6 617 615, .inc 1 616]
def mid12 : List Instruction := [
  .jump 614, .jump 608, .dec 7 621 619, .inc 2 620, .jump 618, .dec 1 624 622,
  .inc 6 623, .jump 621, .dec 2 627 625, .inc 1 626, .jump 624, .dec 1 631 628,
  .inc 7 629, .inc 6 630, .jump 627, .dec 6 637 632, .inc 7 633, .dec 6 636 634,
  .inc 1 635, .jump 633, .jump 627, .dec 7 640 638, .inc 2 639, .jump 637,
  .dec 4 644 641, .inc 6 642, .inc 1 643, .jump 640, .dec 6 647 645, .inc 4 646,
  .jump 644, .dec 2 655 648, .inc 7 649, .dec 6 651 650, .jump 654, .dec 7 654 652,
  .inc 6 653, .jump 651, .jump 647, .dec 7 658 656, .inc 2 657, .jump 655,
  .dec 1 662 659, .inc 7 660, .inc 6 661, .jump 658, .dec 6 668 663, .inc 7 664]
def mid13 : List Instruction := [
  .dec 6 667 665, .inc 1 666, .jump 664, .jump 658, .dec 7 672 669, .inc 1 670,
  .inc 1 671, .jump 668, .inc 1 673, .dec 2 681 674, .inc 7 675, .dec 6 677 676,
  .jump 680, .dec 7 680 678, .inc 6 679, .jump 677, .jump 673, .dec 7 684 682,
  .inc 2 683, .jump 681, .dec 1 688 685, .inc 7 686, .inc 6 687, .jump 684,
  .dec 6 694 689, .inc 7 690, .dec 6 693 691, .inc 1 692, .jump 690, .jump 684,
  .dec 7 698 695, .inc 1 696, .inc 1 697, .jump 694, .inc 1 699, .dec 1 702 700,
  .inc 6 701, .jump 699, .dec 2 705 703, .inc 1 704, .jump 702, .dec 1 709 706,
  .inc 7 707, .inc 6 708, .jump 705, .dec 6 715 710, .inc 7 711, .dec 6 714 712]
def mid14 : List Instruction := [
  .inc 1 713, .jump 711, .jump 705, .dec 7 718 716, .inc 2 717, .jump 715,
  .dec 2 726 719, .inc 7 720, .dec 6 722 721, .jump 725, .dec 7 725 723, .inc 6 724,
  .jump 722, .jump 718, .dec 7 729 727, .inc 2 728, .jump 726, .dec 1 733 730,
  .inc 7 731, .inc 6 732, .jump 729, .dec 6 739 734, .inc 7 735, .dec 6 738 736,
  .inc 1 737, .jump 735, .jump 729, .dec 7 743 740, .inc 1 741, .inc 1 742,
  .jump 739, .inc 1 744, .dec 1 747 745, .inc 6 746, .jump 744, .dec 2 750 748,
  .inc 1 749, .jump 747, .dec 1 754 751, .inc 7 752, .inc 6 753, .jump 750,
  .dec 6 760 755, .inc 7 756, .dec 6 759 757, .inc 1 758, .jump 756, .jump 750]
def mid15 : List Instruction := [
  .dec 7 763 761, .inc 2 762, .jump 760, .dec 1 766 764, .inc 6 765, .jump 763,
  .dec 2 769 767, .inc 1 768, .jump 766, .dec 1 773 770, .inc 7 771, .inc 6 772,
  .jump 769, .dec 6 779 774, .inc 7 775, .dec 6 778 776, .inc 1 777, .jump 775,
  .jump 769, .dec 7 782 780, .inc 2 781, .jump 779, .dec 4 786 783, .inc 6 784,
  .inc 1 785, .jump 782, .dec 6 789 787, .inc 4 788, .jump 786, .dec 2 797 790,
  .inc 7 791, .dec 6 793 792, .jump 796, .dec 7 796 794, .inc 6 795, .jump 793,
  .jump 789, .dec 7 800 798, .inc 2 799, .jump 797, .dec 1 804 801, .inc 7 802,
  .inc 6 803, .jump 800, .dec 6 810 805, .inc 7 806, .dec 6 809 807, .inc 1 808]
def mid16 : List Instruction := [
  .jump 806, .jump 800, .dec 7 814 811, .inc 1 812, .inc 1 813, .jump 810,
  .inc 1 815, .dec 2 823 816, .inc 7 817, .dec 6 819 818, .jump 822, .dec 7 822 820,
  .inc 6 821, .jump 819, .jump 815, .dec 7 826 824, .inc 2 825, .jump 823,
  .dec 1 830 827, .inc 7 828, .inc 6 829, .jump 826, .dec 6 836 831, .inc 7 832,
  .dec 6 835 833, .inc 1 834, .jump 832, .jump 826, .dec 7 840 837, .inc 1 838,
  .inc 1 839, .jump 836, .inc 1 841, .dec 1 844 842, .inc 6 843, .jump 841,
  .dec 2 847 845, .inc 1 846, .jump 844, .dec 1 851 848, .inc 7 849, .inc 6 850,
  .jump 847, .dec 6 857 852, .inc 7 853, .dec 6 856 854, .inc 1 855, .jump 853]
def mid17 : List Instruction := [
  .jump 847, .dec 7 860 858, .inc 2 859, .jump 857, .dec 4 864 861, .inc 6 862,
  .inc 1 863, .jump 860, .dec 6 867 865, .inc 4 866, .jump 864, .dec 1 870 868,
  .inc 6 869, .jump 867, .dec 2 873 871, .inc 1 872, .jump 870, .dec 1 877 874,
  .inc 7 875, .inc 6 876, .jump 873, .dec 6 883 878, .inc 7 879, .dec 6 882 880,
  .inc 1 881, .jump 879, .jump 873, .dec 7 886 884, .inc 2 885, .jump 883,
  .dec 3 890 887, .inc 6 888, .inc 1 889, .jump 886, .dec 6 893 891, .inc 3 892,
  .jump 890, .dec 2 901 894, .inc 7 895, .dec 6 897 896, .jump 900, .dec 7 900 898,
  .inc 6 899, .jump 897, .jump 893, .dec 7 904 902, .inc 2 903, .jump 901]
def mid18 : List Instruction := [
  .dec 1 908 905, .inc 7 906, .inc 6 907, .jump 904, .dec 6 914 909, .inc 7 910,
  .dec 6 913 911, .inc 1 912, .jump 910, .jump 904, .dec 7 918 915, .inc 1 916,
  .inc 1 917, .jump 914, .inc 1 919, .dec 1 922 920, .inc 6 921, .jump 919,
  .dec 2 925 923, .inc 1 924, .jump 922, .dec 1 929 926, .inc 7 927, .inc 6 928,
  .jump 925, .dec 6 935 930, .inc 7 931, .dec 6 934 932, .inc 1 933, .jump 931,
  .jump 925, .dec 7 938 936, .inc 2 937, .jump 935, .dec 4 942 939, .inc 6 940,
  .inc 1 941, .jump 938, .dec 6 945 943, .inc 4 944, .jump 942, .dec 1 948 946,
  .inc 6 947, .jump 945, .dec 2 951 949, .inc 1 950, .jump 948, .dec 1 955 952]
def mid19 : List Instruction := [
  .inc 7 953, .inc 6 954, .jump 951, .dec 6 961 956, .inc 7 957, .dec 6 960 958,
  .inc 1 959, .jump 957, .jump 951, .dec 7 964 962, .inc 2 963, .jump 961,
  .dec 5 968 965, .inc 6 966, .inc 1 967, .jump 964, .dec 6 971 969, .inc 5 970,
  .jump 968, .dec 2 979 972, .inc 7 973, .dec 6 975 974, .jump 978, .dec 7 978 976,
  .inc 6 977, .jump 975, .jump 971, .dec 7 982 980, .inc 2 981, .jump 979,
  .dec 1 986 983, .inc 7 984, .inc 6 985, .jump 982, .dec 6 992 987, .inc 7 988,
  .dec 6 991 989, .inc 1 990, .jump 988, .jump 982, .dec 7 996 993, .inc 1 994,
  .inc 1 995, .jump 992, .inc 1 997, .dec 2 1005 998, .inc 7 999, .dec 6 1001 1000]
def mid20 : List Instruction := [
  .jump 1004, .dec 7 1004 1002, .inc 6 1003, .jump 1001, .jump 997, .dec 7 1008 1006,
  .inc 2 1007, .jump 1005, .dec 1 1012 1009, .inc 7 1010, .inc 6 1011, .jump 1008,
  .dec 6 1018 1013, .inc 7 1014, .dec 6 1017 1015, .inc 1 1016, .jump 1014, .jump 1008,
  .dec 7 1022 1019, .inc 1 1020, .inc 1 1021, .jump 1018, .inc 1 1023, .dec 2 1031 1024,
  .inc 7 1025, .dec 6 1027 1026, .jump 1030, .dec 7 1030 1028, .inc 6 1029, .jump 1027,
  .jump 1023, .dec 7 1034 1032, .inc 2 1033, .jump 1031, .dec 1 1038 1035, .inc 7 1036,
  .inc 6 1037, .jump 1034, .dec 6 1044 1039, .inc 7 1040, .dec 6 1043 1041, .inc 1 1042,
  .jump 1040, .jump 1034, .dec 7 1048 1045, .inc 1 1046, .inc 1 1047, .jump 1044]
def mid21 : List Instruction := [
  .dec 1 1051 1049, .inc 6 1050, .jump 1048, .dec 2 1054 1052, .inc 1 1053, .jump 1051,
  .dec 1 1058 1055, .inc 7 1056, .inc 6 1057, .jump 1054, .dec 6 1064 1059, .inc 7 1060,
  .dec 6 1063 1061, .inc 1 1062, .jump 1060, .jump 1054, .dec 7 1067 1065, .inc 2 1066,
  .jump 1064, .dec 4 1071 1068, .inc 6 1069, .inc 1 1070, .jump 1067, .dec 6 1074 1072,
  .inc 4 1073, .jump 1071, .dec 1 1077 1075, .inc 6 1076, .jump 1074, .dec 2 1080 1078,
  .inc 1 1079, .jump 1077, .dec 1 1084 1081, .inc 7 1082, .inc 6 1083, .jump 1080,
  .dec 6 1090 1085, .inc 7 1086, .dec 6 1089 1087, .inc 1 1088, .jump 1086, .jump 1080,
  .dec 7 1093 1091, .inc 2 1092, .jump 1090, .dec 3 1097 1094, .inc 6 1095, .inc 1 1096]
def mid22 : List Instruction := [
  .jump 1093, .dec 6 1100 1098, .inc 3 1099, .jump 1097, .dec 2 1108 1101, .inc 7 1102,
  .dec 6 1104 1103, .jump 1107, .dec 7 1107 1105, .inc 6 1106, .jump 1104, .jump 1100,
  .dec 7 1111 1109, .inc 2 1110, .jump 1108, .dec 1 1115 1112, .inc 7 1113, .inc 6 1114,
  .jump 1111, .dec 6 1121 1116, .inc 7 1117, .dec 6 1120 1118, .inc 1 1119, .jump 1117,
  .jump 1111, .dec 7 1125 1122, .inc 1 1123, .inc 1 1124, .jump 1121, .inc 1 1126,
  .dec 1 1129 1127, .inc 6 1128, .jump 1126, .dec 2 1132 1130, .inc 1 1131, .jump 1129,
  .dec 1 1136 1133, .inc 7 1134, .inc 6 1135, .jump 1132, .dec 6 1142 1137, .inc 7 1138,
  .dec 6 1141 1139, .inc 1 1140, .jump 1138, .jump 1132, .dec 7 1145 1143, .inc 2 1144]
def mid23 : List Instruction := [
  .jump 1142, .dec 4 1149 1146, .inc 6 1147, .inc 1 1148, .jump 1145, .dec 6 1152 1150,
  .inc 4 1151, .jump 1149, .dec 1 1155 1153, .inc 6 1154, .jump 1152, .dec 2 1158 1156,
  .inc 1 1157, .jump 1155, .dec 1 1162 1159, .inc 7 1160, .inc 6 1161, .jump 1158,
  .dec 6 1168 1163, .inc 7 1164, .dec 6 1167 1165, .inc 1 1166, .jump 1164, .jump 1158,
  .dec 7 1171 1169, .inc 2 1170, .jump 1168, .dec 5 1175 1172, .inc 6 1173, .inc 1 1174,
  .jump 1171, .dec 6 1178 1176, .inc 5 1177, .jump 1175, .dec 2 1186 1179, .inc 7 1180,
  .dec 6 1182 1181, .jump 1185, .dec 7 1185 1183, .inc 6 1184, .jump 1182, .jump 1178,
  .dec 7 1189 1187, .inc 2 1188, .jump 1186, .dec 1 1193 1190, .inc 7 1191, .inc 6 1192]
def mid24 : List Instruction := [
  .jump 1189, .dec 6 1199 1194, .inc 7 1195, .dec 6 1198 1196, .inc 1 1197, .jump 1195,
  .jump 1189, .dec 7 1203 1200, .inc 1 1201, .inc 1 1202, .jump 1199, .inc 1 1204,
  .dec 2 1212 1205, .inc 7 1206, .dec 6 1208 1207, .jump 1211, .dec 7 1211 1209, .inc 6 1210,
  .jump 1208, .jump 1204, .dec 7 1215 1213, .inc 2 1214, .jump 1212, .dec 1 1219 1216,
  .inc 7 1217, .inc 6 1218, .jump 1215, .dec 6 1225 1220, .inc 7 1221, .dec 6 1224 1222,
  .inc 1 1223, .jump 1221, .jump 1215, .dec 7 1229 1226, .inc 1 1227, .inc 1 1228,
  .jump 1225, .inc 1 1230, .dec 2 1238 1231, .inc 7 1232, .dec 6 1234 1233, .jump 1237,
  .dec 7 1237 1235, .inc 6 1236, .jump 1234, .jump 1230, .dec 7 1241 1239, .inc 2 1240]
def mid25 : List Instruction := [
  .jump 1238, .dec 1 1245 1242, .inc 7 1243, .inc 6 1244, .jump 1241, .dec 6 1251 1246,
  .inc 7 1247, .dec 6 1250 1248, .inc 1 1249, .jump 1247, .jump 1241, .dec 7 1255 1252,
  .inc 1 1253, .inc 1 1254, .jump 1251, .dec 1 1258 1256, .inc 6 1257, .jump 1255,
  .dec 2 1261 1259, .inc 1 1260, .jump 1258, .dec 1 1265 1262, .inc 7 1263, .inc 6 1264,
  .jump 1261, .dec 6 1271 1266, .inc 7 1267, .dec 6 1270 1268, .inc 1 1269, .jump 1267,
  .jump 1261, .dec 7 1274 1272, .inc 2 1273, .jump 1271, .dec 4 1278 1275, .inc 6 1276,
  .inc 1 1277, .jump 1274, .dec 6 1281 1279, .inc 4 1280, .jump 1278, .dec 1 1284 1282,
  .inc 6 1283, .jump 1281, .dec 2 1287 1285, .inc 1 1286, .jump 1284, .dec 1 1291 1288]
def mid26 : List Instruction := [
  .inc 7 1289, .inc 6 1290, .jump 1287, .dec 6 1297 1292, .inc 7 1293, .dec 6 1296 1294,
  .inc 1 1295, .jump 1293, .jump 1287, .dec 7 1300 1298, .inc 2 1299, .jump 1297,
  .dec 5 1304 1301, .inc 6 1302, .inc 1 1303, .jump 1300, .dec 6 1307 1305, .inc 5 1306,
  .jump 1304, .dec 2 1315 1308, .inc 7 1309, .dec 6 1311 1310, .jump 1314, .dec 7 1314 1312,
  .inc 6 1313, .jump 1311, .jump 1307, .dec 7 1318 1316, .inc 2 1317, .jump 1315,
  .dec 1 1322 1319, .inc 7 1320, .inc 6 1321, .jump 1318, .dec 6 1328 1323, .inc 7 1324,
  .dec 6 1327 1325, .inc 1 1326, .jump 1324, .jump 1318, .dec 7 1332 1329, .inc 1 1330,
  .inc 1 1331, .jump 1328, .inc 1 1333, .dec 1 1336 1334, .inc 6 1335, .jump 1333]
def mid27 : List Instruction := [
  .dec 2 1339 1337, .inc 1 1338, .jump 1336, .dec 1 1343 1340, .inc 7 1341, .inc 6 1342,
  .jump 1339, .dec 6 1349 1344, .inc 7 1345, .dec 6 1348 1346, .inc 1 1347, .jump 1345,
  .jump 1339, .dec 7 1352 1350, .inc 2 1351, .jump 1349, .dec 4 1356 1353, .inc 6 1354,
  .inc 1 1355, .jump 1352, .dec 6 1359 1357, .inc 4 1358, .jump 1356, .dec 1 1362 1360,
  .inc 6 1361, .jump 1359, .dec 2 1365 1363, .inc 1 1364, .jump 1362, .dec 1 1369 1366,
  .inc 7 1367, .inc 6 1368, .jump 1365, .dec 6 1375 1370, .inc 7 1371, .dec 6 1374 1372,
  .inc 1 1373, .jump 1371, .jump 1365, .dec 7 1378 1376, .inc 2 1377, .jump 1375,
  .dec 3 1382 1379, .inc 6 1380, .inc 1 1381, .jump 1378, .dec 6 1385 1383, .inc 3 1384]
def mid28 : List Instruction := [
  .jump 1382, .dec 2 1393 1386, .inc 7 1387, .dec 6 1389 1388, .jump 1392, .dec 7 1392 1390,
  .inc 6 1391, .jump 1389, .jump 1385, .dec 7 1396 1394, .inc 2 1395, .jump 1393,
  .dec 1 1400 1397, .inc 7 1398, .inc 6 1399, .jump 1396, .dec 6 1406 1401, .inc 7 1402,
  .dec 6 1405 1403, .inc 1 1404, .jump 1402, .jump 1396, .dec 7 1410 1407, .inc 1 1408,
  .inc 1 1409, .jump 1406, .inc 1 1411, .dec 1 1414 1412, .inc 6 1413, .jump 1411,
  .dec 2 1417 1415, .inc 1 1416, .jump 1414, .dec 1 1421 1418, .inc 7 1419, .inc 6 1420,
  .jump 1417, .dec 6 1427 1422, .inc 7 1423, .dec 6 1426 1424, .inc 1 1425, .jump 1423,
  .jump 1417, .dec 7 1430 1428, .inc 2 1429, .jump 1427, .dec 3 1434 1431, .inc 6 1432]
def mid29 : List Instruction := [
  .inc 1 1433, .jump 1430, .dec 6 1437 1435, .inc 3 1436, .jump 1434, .dec 1 1440 1438,
  .inc 6 1439, .jump 1437, .dec 2 1443 1441, .inc 1 1442, .jump 1440, .dec 1 1447 1444,
  .inc 7 1445, .inc 6 1446, .jump 1443, .dec 6 1453 1448, .inc 7 1449, .dec 6 1452 1450,
  .inc 1 1451, .jump 1449, .jump 1443, .dec 7 1456 1454, .inc 2 1455, .jump 1453,
  .dec 5 1460 1457, .inc 6 1458, .inc 1 1459, .jump 1456, .dec 6 1463 1461, .inc 5 1462,
  .jump 1460, .dec 2 1471 1464, .inc 7 1465, .dec 6 1467 1466, .jump 1470, .dec 7 1470 1468,
  .inc 6 1469, .jump 1467, .jump 1463, .dec 7 1474 1472, .inc 2 1473, .jump 1471,
  .dec 1 1478 1475, .inc 7 1476, .inc 6 1477, .jump 1474, .dec 6 1484 1479, .inc 7 1480]
def mid30 : List Instruction := [
  .dec 6 1483 1481, .inc 1 1482, .jump 1480, .jump 1474, .dec 7 1488 1485, .inc 1 1486,
  .inc 1 1487, .jump 1484, .inc 1 1489, .dec 2 1497 1490, .inc 7 1491, .dec 6 1493 1492,
  .jump 1496, .dec 7 1496 1494, .inc 6 1495, .jump 1493, .jump 1489, .dec 7 1500 1498,
  .inc 2 1499, .jump 1497, .dec 1 1504 1501, .inc 7 1502, .inc 6 1503, .jump 1500,
  .dec 6 1510 1505, .inc 7 1506, .dec 6 1509 1507, .inc 1 1508, .jump 1506, .jump 1500,
  .dec 7 1514 1511, .inc 1 1512, .inc 1 1513, .jump 1510, .dec 2 1522 1515, .inc 7 1516,
  .dec 6 1518 1517, .jump 1521, .dec 7 1521 1519, .inc 6 1520, .jump 1518, .jump 1514,
  .dec 7 1525 1523, .inc 2 1524, .jump 1522, .dec 1 1529 1526, .inc 7 1527, .inc 6 1528]
def mid31 : List Instruction := [
  .jump 1525, .dec 6 1535 1530, .inc 7 1531, .dec 6 1534 1532, .inc 1 1533, .jump 1531,
  .jump 1525, .dec 7 1539 1536, .inc 1 1537, .inc 1 1538, .jump 1535, .dec 1 1542 1540,
  .inc 6 1541, .jump 1539, .dec 2 1545 1543, .inc 1 1544, .jump 1542, .dec 1 1549 1546,
  .inc 7 1547, .inc 6 1548, .jump 1545, .dec 6 1555 1550, .inc 7 1551, .dec 6 1554 1552,
  .inc 1 1553, .jump 1551, .jump 1545, .dec 7 1558 1556, .inc 2 1557, .jump 1555,
  .inc 1 1559, .dec 1 1562 1560, .inc 6 1561, .jump 1559, .dec 2 1565 1563, .inc 1 1564,
  .jump 1562, .dec 1 1569 1566, .inc 7 1567, .inc 6 1568, .jump 1565, .dec 6 1575 1570,
  .inc 7 1571, .dec 6 1574 1572, .inc 1 1573, .jump 1571, .jump 1565, .dec 7 1578 1576]
def mid32 : List Instruction := [
  .inc 2 1577, .jump 1575, .dec 3 1582 1579, .inc 6 1580, .inc 1 1581, .jump 1578,
  .dec 6 1585 1583, .inc 3 1584, .jump 1582, .dec 2 1593 1586, .inc 7 1587, .dec 6 1589 1588,
  .jump 1592, .dec 7 1592 1590, .inc 6 1591, .jump 1589, .jump 1585, .dec 7 1596 1594,
  .inc 2 1595, .jump 1593, .dec 1 1600 1597, .inc 7 1598, .inc 6 1599, .jump 1596,
  .dec 6 1606 1601, .inc 7 1602, .dec 6 1605 1603, .inc 1 1604, .jump 1602, .jump 1596,
  .dec 7 1610 1607, .inc 1 1608, .inc 1 1609, .jump 1606, .inc 1 1611, .dec 1 1614 1612,
  .inc 6 1613, .jump 1611, .dec 2 1617 1615, .inc 1 1616, .jump 1614, .dec 1 1621 1618,
  .inc 7 1619, .inc 6 1620, .jump 1617, .dec 6 1627 1622, .inc 7 1623, .dec 6 1626 1624]
def mid33 : List Instruction := [
  .inc 1 1625, .jump 1623, .jump 1617, .dec 7 1630 1628, .inc 2 1629, .jump 1627,
  .dec 4 1634 1631, .inc 6 1632, .inc 1 1633, .jump 1630, .dec 6 1637 1635, .inc 4 1636,
  .jump 1634, .dec 2 1645 1638, .inc 7 1639, .dec 6 1641 1640, .jump 1644, .dec 7 1644 1642,
  .inc 6 1643, .jump 1641, .jump 1637, .dec 7 1648 1646, .inc 2 1647, .jump 1645,
  .dec 1 1652 1649, .inc 7 1650, .inc 6 1651, .jump 1648, .dec 6 1658 1653, .inc 7 1654,
  .dec 6 1657 1655, .inc 1 1656, .jump 1654, .jump 1648, .dec 7 1662 1659, .inc 1 1660,
  .inc 1 1661, .jump 1658, .inc 1 1663, .dec 1 1666 1664, .inc 6 1665, .jump 1663,
  .dec 2 1669 1667, .inc 1 1668, .jump 1666, .dec 1 1673 1670, .inc 7 1671, .inc 6 1672]
def mid34 : List Instruction := [
  .jump 1669, .dec 6 1679 1674, .inc 7 1675, .dec 6 1678 1676, .inc 1 1677, .jump 1675,
  .jump 1669, .dec 7 1682 1680, .inc 2 1681, .jump 1679, .dec 5 1686 1683, .inc 6 1684,
  .inc 1 1685, .jump 1682, .dec 6 1689 1687, .inc 5 1688, .jump 1686, .dec 2 1697 1690,
  .inc 7 1691, .dec 6 1693 1692, .jump 1696, .dec 7 1696 1694, .inc 6 1695, .jump 1693,
  .jump 1689, .dec 7 1700 1698, .inc 2 1699, .jump 1697, .dec 1 1704 1701, .inc 7 1702,
  .inc 6 1703, .jump 1700, .dec 6 1710 1705, .inc 7 1706, .dec 6 1709 1707, .inc 1 1708,
  .jump 1706, .jump 1700, .dec 7 1714 1711, .inc 1 1712, .inc 1 1713, .jump 1710,
  .inc 1 1715, .dec 1 1718 1716, .inc 6 1717, .jump 1715, .dec 2 1721 1719, .inc 1 1720]
def mid35 : List Instruction := [
  .jump 1718, .dec 1 1725 1722, .inc 7 1723, .inc 6 1724, .jump 1721, .dec 6 1731 1726,
  .inc 7 1727, .dec 6 1730 1728, .inc 1 1729, .jump 1727, .jump 1721, .dec 7 1734 1732,
  .inc 2 1733, .jump 1731, .dec 3 1738 1735, .inc 6 1736, .inc 1 1737, .jump 1734,
  .dec 6 1741 1739, .inc 3 1740, .jump 1738, .dec 1 1744 1742, .inc 6 1743, .jump 1741,
  .dec 2 1747 1745, .inc 1 1746, .jump 1744, .dec 1 1751 1748, .inc 7 1749, .inc 6 1750,
  .jump 1747, .dec 6 1757 1752, .inc 7 1753, .dec 6 1756 1754, .inc 1 1755, .jump 1753,
  .jump 1747, .dec 7 1760 1758, .inc 2 1759, .jump 1757, .dec 5 1764 1761, .inc 6 1762,
  .inc 1 1763, .jump 1760, .dec 6 1767 1765, .inc 5 1766, .jump 1764, .dec 1 1770 1768]
def mid36 : List Instruction := [
  .inc 6 1769, .jump 1767, .dec 2 1773 1771, .inc 1 1772, .jump 1770, .dec 1 1777 1774,
  .inc 7 1775, .inc 6 1776, .jump 1773, .dec 6 1783 1778, .inc 7 1779, .dec 6 1782 1780,
  .inc 1 1781, .jump 1779, .jump 1773, .dec 7 1786 1784, .inc 2 1785, .jump 1783,
  .dec 5 1790 1787, .inc 6 1788, .inc 1 1789, .jump 1786, .dec 6 1793 1791, .inc 5 1792,
  .jump 1790, .dec 2 1801 1794, .inc 7 1795, .dec 6 1797 1796, .jump 1800, .dec 7 1800 1798,
  .inc 6 1799, .jump 1797, .jump 1793, .dec 7 1804 1802, .inc 2 1803, .jump 1801,
  .dec 1 1808 1805, .inc 7 1806, .inc 6 1807, .jump 1804, .dec 6 1814 1809, .inc 7 1810,
  .dec 6 1813 1811, .inc 1 1812, .jump 1810, .jump 1804, .dec 7 1818 1815, .inc 1 1816]
def mid37 : List Instruction := [
  .inc 1 1817, .jump 1814, .inc 1 1819, .inc 1 1820, .dec 2 1828 1821, .inc 7 1822,
  .dec 6 1824 1823, .jump 1827, .dec 7 1827 1825, .inc 6 1826, .jump 1824, .jump 1820,
  .dec 7 1831 1829, .inc 2 1830, .jump 1828, .dec 1 1835 1832, .inc 7 1833, .inc 6 1834,
  .jump 1831, .dec 6 1841 1836, .inc 7 1837, .dec 6 1840 1838, .inc 1 1839, .jump 1837,
  .jump 1831, .dec 7 1845 1842, .inc 1 1843, .inc 1 1844, .jump 1841, .inc 1 1846,
  .dec 1 1849 1847, .inc 6 1848, .jump 1846, .dec 2 1852 1850, .inc 1 1851, .jump 1849,
  .dec 1 1856 1853, .inc 7 1854, .inc 6 1855, .jump 1852, .dec 6 1862 1857, .inc 7 1858,
  .dec 6 1861 1859, .inc 1 1860, .jump 1858, .jump 1852, .dec 7 1865 1863, .inc 2 1864]
def mid38 : List Instruction := [
  .jump 1862, .dec 4 1869 1866, .inc 6 1867, .inc 1 1868, .jump 1865, .dec 6 1872 1870,
  .inc 4 1871, .jump 1869, .dec 1 1875 1873, .inc 6 1874, .jump 1872, .dec 2 1878 1876,
  .inc 1 1877, .jump 1875, .dec 1 1882 1879, .inc 7 1880, .inc 6 1881, .jump 1878,
  .dec 6 1888 1883, .inc 7 1884, .dec 6 1887 1885, .inc 1 1886, .jump 1884, .jump 1878,
  .dec 7 1891 1889, .inc 2 1890, .jump 1888, .dec 5 1895 1892, .inc 6 1893, .inc 1 1894,
  .jump 1891, .dec 6 1898 1896, .inc 5 1897, .jump 1895, .dec 2 1906 1899, .inc 7 1900,
  .dec 6 1902 1901, .jump 1905, .dec 7 1905 1903, .inc 6 1904, .jump 1902, .jump 1898,
  .dec 7 1909 1907, .inc 2 1908, .jump 1906, .dec 1 1913 1910, .inc 7 1911, .inc 6 1912]
def mid39 : List Instruction := [
  .jump 1909, .dec 6 1919 1914, .inc 7 1915, .dec 6 1918 1916, .inc 1 1917, .jump 1915,
  .jump 1909, .dec 7 1923 1920, .inc 1 1921, .inc 1 1922, .jump 1919, .inc 1 1924,
  .dec 2 1932 1925, .inc 7 1926, .dec 6 1928 1927, .jump 1931, .dec 7 1931 1929, .inc 6 1930,
  .jump 1928, .jump 1924, .dec 7 1935 1933, .inc 2 1934, .jump 1932, .dec 1 1939 1936,
  .inc 7 1937, .inc 6 1938, .jump 1935, .dec 6 1945 1940, .inc 7 1941, .dec 6 1944 1942,
  .inc 1 1943, .jump 1941, .jump 1935, .dec 7 1949 1946, .inc 1 1947, .inc 1 1948,
  .jump 1945, .inc 1 1950, .dec 2 1958 1951, .inc 7 1952, .dec 6 1954 1953, .jump 1957,
  .dec 7 1957 1955, .inc 6 1956, .jump 1954, .jump 1950, .dec 7 1961 1959, .inc 2 1960]
def mid40 : List Instruction := [
  .jump 1958, .dec 1 1965 1962, .inc 7 1963, .inc 6 1964, .jump 1961, .dec 6 1971 1966,
  .inc 7 1967, .dec 6 1970 1968, .inc 1 1969, .jump 1967, .jump 1961, .dec 7 1975 1972,
  .inc 1 1973, .inc 1 1974, .jump 1971, .inc 1 1976, .dec 1 1979 1977, .inc 6 1978,
  .jump 1976, .dec 2 1982 1980, .inc 1 1981, .jump 1979, .dec 1 1986 1983, .inc 7 1984,
  .inc 6 1985, .jump 1982, .dec 6 1992 1987, .inc 7 1988, .dec 6 1991 1989, .inc 1 1990,
  .jump 1988, .jump 1982, .dec 7 1995 1993, .inc 2 1994, .jump 1992, .dec 3 1999 1996,
  .inc 6 1997, .inc 1 1998, .jump 1995, .dec 6 2002 2000, .inc 3 2001, .jump 1999,
  .dec 1 2005 2003, .inc 6 2004, .jump 2002, .dec 2 2008 2006, .inc 1 2007, .jump 2005]
def mid41 : List Instruction := [
  .dec 1 2012 2009, .inc 7 2010, .inc 6 2011, .jump 2008, .dec 6 2018 2013, .inc 7 2014,
  .dec 6 2017 2015, .inc 1 2016, .jump 2014, .jump 2008, .dec 7 2021 2019, .inc 2 2020,
  .jump 2018, .dec 5 2025 2022, .inc 6 2023, .inc 1 2024, .jump 2021, .dec 6 2028 2026,
  .inc 5 2027, .jump 2025, .dec 2 2036 2029, .inc 7 2030, .dec 6 2032 2031, .jump 2035,
  .dec 7 2035 2033, .inc 6 2034, .jump 2032, .jump 2028, .dec 7 2039 2037, .inc 2 2038,
  .jump 2036, .dec 1 2043 2040, .inc 7 2041, .inc 6 2042, .jump 2039, .dec 6 2049 2044,
  .inc 7 2045, .dec 6 2048 2046, .inc 1 2047, .jump 2045, .jump 2039, .dec 7 2053 2050,
  .inc 1 2051, .inc 1 2052, .jump 2049, .inc 1 2054, .dec 1 2057 2055, .inc 6 2056]
def mid42 : List Instruction := [
  .jump 2054, .dec 2 2060 2058, .inc 1 2059, .jump 2057, .dec 1 2064 2061, .inc 7 2062,
  .inc 6 2063, .jump 2060, .dec 6 2070 2065, .inc 7 2066, .dec 6 2069 2067, .inc 1 2068,
  .jump 2066, .jump 2060, .dec 7 2073 2071, .inc 2 2072, .jump 2070, .dec 4 2077 2074,
  .inc 6 2075, .inc 1 2076, .jump 2073, .dec 6 2080 2078, .inc 4 2079, .jump 2077,
  .dec 1 2083 2081, .inc 6 2082, .jump 2080, .dec 2 2086 2084, .inc 1 2085, .jump 2083,
  .dec 1 2090 2087, .inc 7 2088, .inc 6 2089, .jump 2086, .dec 6 2096 2091, .inc 7 2092,
  .dec 6 2095 2093, .inc 1 2094, .jump 2092, .jump 2086, .dec 7 2099 2097, .inc 2 2098,
  .jump 2096, .dec 3 2103 2100, .inc 6 2101, .inc 1 2102, .jump 2099, .dec 6 2106 2104]
def mid43 : List Instruction := [
  .inc 3 2105, .jump 2103, .dec 2 2114 2107, .inc 7 2108, .dec 6 2110 2109, .jump 2113,
  .dec 7 2113 2111, .inc 6 2112, .jump 2110, .jump 2106, .dec 7 2117 2115, .inc 2 2116,
  .jump 2114, .dec 1 2121 2118, .inc 7 2119, .inc 6 2120, .jump 2117, .dec 6 2127 2122,
  .inc 7 2123, .dec 6 2126 2124, .inc 1 2125, .jump 2123, .jump 2117, .dec 7 2131 2128,
  .inc 1 2129, .inc 1 2130, .jump 2127, .inc 1 2132, .dec 1 2135 2133, .inc 6 2134,
  .jump 2132, .dec 2 2138 2136, .inc 1 2137, .jump 2135, .dec 1 2142 2139, .inc 7 2140,
  .inc 6 2141, .jump 2138, .dec 6 2148 2143, .inc 7 2144, .dec 6 2147 2145, .inc 1 2146,
  .jump 2144, .jump 2138, .dec 7 2151 2149, .inc 2 2150, .jump 2148, .dec 4 2155 2152]
def mid44 : List Instruction := [
  .inc 6 2153, .inc 1 2154, .jump 2151, .dec 6 2158 2156, .inc 4 2157, .jump 2155,
  .dec 1 2161 2159, .inc 6 2160, .jump 2158, .dec 2 2164 2162, .inc 1 2163, .jump 2161,
  .dec 1 2168 2165, .inc 7 2166, .inc 6 2167, .jump 2164, .dec 6 2174 2169, .inc 7 2170,
  .dec 6 2173 2171, .inc 1 2172, .jump 2170, .jump 2164, .dec 7 2177 2175, .inc 2 2176,
  .jump 2174, .dec 5 2181 2178, .inc 6 2179, .inc 1 2180, .jump 2177, .dec 6 2184 2182,
  .inc 5 2183, .jump 2181, .dec 2 2192 2185, .inc 7 2186, .dec 6 2188 2187, .jump 2191,
  .dec 7 2191 2189, .inc 6 2190, .jump 2188, .jump 2184, .dec 7 2195 2193, .inc 2 2194,
  .jump 2192, .dec 1 2199 2196, .inc 7 2197, .inc 6 2198, .jump 2195, .dec 6 2205 2200]
def mid45 : List Instruction := [
  .inc 7 2201, .dec 6 2204 2202, .inc 1 2203, .jump 2201, .jump 2195, .dec 7 2209 2206,
  .inc 1 2207, .inc 1 2208, .jump 2205, .inc 1 2210, .dec 2 2218 2211, .inc 7 2212,
  .dec 6 2214 2213, .jump 2217, .dec 7 2217 2215, .inc 6 2216, .jump 2214, .jump 2210,
  .dec 7 2221 2219, .inc 2 2220, .jump 2218, .dec 1 2225 2222, .inc 7 2223, .inc 6 2224,
  .jump 2221, .dec 6 2231 2226, .inc 7 2227, .dec 6 2230 2228, .inc 1 2229, .jump 2227,
  .jump 2221, .dec 7 2235 2232, .inc 1 2233, .inc 1 2234, .jump 2231, .inc 1 2236,
  .dec 2 2244 2237, .inc 7 2238, .dec 6 2240 2239, .jump 2243, .dec 7 2243 2241, .inc 6 2242,
  .jump 2240, .jump 2236, .dec 7 2247 2245, .inc 2 2246, .jump 2244, .dec 1 2251 2248]
def mid46 : List Instruction := [
  .inc 7 2249, .inc 6 2250, .jump 2247, .dec 6 2257 2252, .inc 7 2253, .dec 6 2256 2254,
  .inc 1 2255, .jump 2253, .jump 2247, .dec 7 2261 2258, .inc 1 2259, .inc 1 2260,
  .jump 2257, .dec 1 2264 2262, .inc 6 2263, .jump 2261, .dec 2 2267 2265, .inc 1 2266,
  .jump 2264, .dec 1 2271 2268, .inc 7 2269, .inc 6 2270, .jump 2267, .dec 6 2277 2272,
  .inc 7 2273, .dec 6 2276 2274, .inc 1 2275, .jump 2273, .jump 2267, .dec 7 2280 2278,
  .inc 2 2279, .jump 2277, .dec 4 2284 2281, .inc 6 2282, .inc 1 2283, .jump 2280,
  .dec 6 2287 2285, .inc 4 2286, .jump 2284, .dec 1 2290 2288, .inc 6 2289, .jump 2287,
  .dec 2 2293 2291, .inc 1 2292, .jump 2290, .dec 1 2297 2294, .inc 7 2295, .inc 6 2296]
def mid47 : List Instruction := [
  .jump 2293, .dec 6 2303 2298, .inc 7 2299, .dec 6 2302 2300, .inc 1 2301, .jump 2299,
  .jump 2293, .dec 7 2306 2304, .inc 2 2305, .jump 2303, .dec 3 2310 2307, .inc 6 2308,
  .inc 1 2309, .jump 2306, .dec 6 2313 2311, .inc 3 2312, .jump 2310, .dec 2 2321 2314,
  .inc 7 2315, .dec 6 2317 2316, .jump 2320, .dec 7 2320 2318, .inc 6 2319, .jump 2317,
  .jump 2313, .dec 7 2324 2322, .inc 2 2323, .jump 2321, .dec 1 2328 2325, .inc 7 2326,
  .inc 6 2327, .jump 2324, .dec 6 2334 2329, .inc 7 2330, .dec 6 2333 2331, .inc 1 2332,
  .jump 2330, .jump 2324, .dec 7 2338 2335, .inc 1 2336, .inc 1 2337, .jump 2334,
  .inc 1 2339, .dec 1 2342 2340, .inc 6 2341, .jump 2339, .dec 2 2345 2343, .inc 1 2344]
def mid48 : List Instruction := [
  .jump 2342, .dec 1 2349 2346, .inc 7 2347, .inc 6 2348, .jump 2345, .dec 6 2355 2350,
  .inc 7 2351, .dec 6 2354 2352, .inc 1 2353, .jump 2351, .jump 2345, .dec 7 2358 2356,
  .inc 2 2357, .jump 2355, .dec 3 2362 2359, .inc 6 2360, .inc 1 2361, .jump 2358,
  .dec 6 2365 2363, .inc 3 2364, .jump 2362, .dec 1 2368 2366, .inc 6 2367, .jump 2365,
  .dec 2 2371 2369, .inc 1 2370, .jump 2368, .dec 1 2375 2372, .inc 7 2373, .inc 6 2374,
  .jump 2371, .dec 6 2381 2376, .inc 7 2377, .dec 6 2380 2378, .inc 1 2379, .jump 2377,
  .jump 2371, .dec 7 2384 2382, .inc 2 2383, .jump 2381, .dec 5 2388 2385, .inc 6 2386,
  .inc 1 2387, .jump 2384, .dec 6 2391 2389, .inc 5 2390, .jump 2388, .dec 2 2399 2392]
def mid49 : List Instruction := [
  .inc 7 2393, .dec 6 2395 2394, .jump 2398, .dec 7 2398 2396, .inc 6 2397, .jump 2395,
  .jump 2391, .dec 7 2402 2400, .inc 2 2401, .jump 2399, .dec 1 2406 2403, .inc 7 2404,
  .inc 6 2405, .jump 2402, .dec 6 2412 2407, .inc 7 2408, .dec 6 2411 2409, .inc 1 2410,
  .jump 2408, .jump 2402, .dec 7 2416 2413, .inc 1 2414, .inc 1 2415, .jump 2412,
  .inc 1 2417, .dec 1 2420 2418, .inc 6 2419, .jump 2417, .dec 2 2423 2421, .inc 1 2422,
  .jump 2420, .dec 1 2427 2424, .inc 7 2425, .inc 6 2426, .jump 2423, .dec 6 2433 2428,
  .inc 7 2429, .dec 6 2432 2430, .inc 1 2431, .jump 2429, .jump 2423, .dec 7 2436 2434,
  .inc 2 2435, .jump 2433, .dec 4 2440 2437, .inc 6 2438, .inc 1 2439, .jump 2436]
def mid50 : List Instruction := [
  .dec 6 2443 2441, .inc 4 2442, .jump 2440, .dec 1 2446 2444, .inc 6 2445, .jump 2443,
  .dec 2 2449 2447, .inc 1 2448, .jump 2446, .dec 1 2453 2450, .inc 7 2451, .inc 6 2452,
  .jump 2449, .dec 6 2459 2454, .inc 7 2455, .dec 6 2458 2456, .inc 1 2457, .jump 2455,
  .jump 2449, .dec 7 2462 2460, .inc 2 2461, .jump 2459, .dec 5 2466 2463, .inc 6 2464,
  .inc 1 2465, .jump 2462, .dec 6 2469 2467, .inc 5 2468, .jump 2466, .dec 2 2477 2470,
  .inc 7 2471, .dec 6 2473 2472, .jump 2476, .dec 7 2476 2474, .inc 6 2475, .jump 2473,
  .jump 2469, .dec 7 2480 2478, .inc 2 2479, .jump 2477, .dec 1 2484 2481, .inc 7 2482,
  .inc 6 2483, .jump 2480, .dec 6 2490 2485, .inc 7 2486, .dec 6 2489 2487, .inc 1 2488]
def mid51 : List Instruction := [
  .jump 2486, .jump 2480, .dec 7 2494 2491, .inc 1 2492, .inc 1 2493, .jump 2490,
  .inc 1 2495, .dec 2 2503 2496, .inc 7 2497, .dec 6 2499 2498, .jump 2502, .dec 7 2502 2500,
  .inc 6 2501, .jump 2499, .jump 2495, .dec 7 2506 2504, .inc 2 2505, .jump 2503,
  .dec 1 2510 2507, .inc 7 2508, .inc 6 2509, .jump 2506, .dec 6 2516 2511, .inc 7 2512,
  .dec 6 2515 2513, .inc 1 2514, .jump 2512, .jump 2506, .dec 7 2520 2517, .inc 1 2518,
  .inc 1 2519, .jump 2516, .inc 1 2521, .dec 2 2529 2522, .inc 7 2523, .dec 6 2525 2524,
  .jump 2528, .dec 7 2528 2526, .inc 6 2527, .jump 2525, .jump 2521, .dec 7 2532 2530,
  .inc 2 2531, .jump 2529, .dec 1 2536 2533, .inc 7 2534, .inc 6 2535, .jump 2532]
def mid52 : List Instruction := [
  .dec 6 2542 2537, .inc 7 2538, .dec 6 2541 2539, .inc 1 2540, .jump 2538, .jump 2532,
  .dec 7 2546 2543, .inc 1 2544, .inc 1 2545, .jump 2542, .dec 1 2549 2547, .inc 6 2548,
  .jump 2546, .dec 2 2552 2550, .inc 1 2551, .jump 2549, .dec 1 2556 2553, .inc 7 2554,
  .inc 6 2555, .jump 2552, .dec 6 2562 2557, .inc 7 2558, .dec 6 2561 2559, .inc 1 2560,
  .jump 2558, .jump 2552, .dec 7 2565 2563, .inc 2 2564, .jump 2562, .dec 1 2568 2566,
  .inc 6 2567, .jump 2565, .dec 2 2571 2569, .inc 1 2570, .jump 2568, .dec 1 2575 2572,
  .inc 7 2573, .inc 6 2574, .jump 2571, .dec 6 2581 2576, .inc 7 2577, .dec 6 2580 2578,
  .inc 1 2579, .jump 2577, .jump 2571, .dec 7 2584 2582, .inc 2 2583, .jump 2581]
def mid53 : List Instruction := [
  .dec 5 2588 2585, .inc 6 2586, .inc 1 2587, .jump 2584, .dec 6 2591 2589, .inc 5 2590,
  .jump 2588, .dec 1 2594 2592, .inc 6 2593, .jump 2591, .dec 2 2597 2595, .inc 1 2596,
  .jump 2594, .dec 1 2601 2598, .inc 7 2599, .inc 6 2600, .jump 2597, .dec 6 2607 2602,
  .inc 7 2603, .dec 6 2606 2604, .inc 1 2605, .jump 2603, .jump 2597, .dec 7 2610 2608,
  .inc 2 2609, .jump 2607, .dec 5 2614 2611, .inc 6 2612, .inc 1 2613, .jump 2610,
  .dec 6 2617 2615, .inc 5 2616, .jump 2614, .dec 2 2625 2618, .inc 7 2619, .dec 6 2621 2620,
  .jump 2624, .dec 7 2624 2622, .inc 6 2623, .jump 2621, .jump 2617, .dec 7 2628 2626,
  .inc 2 2627, .jump 2625, .dec 1 2632 2629, .inc 7 2630, .inc 6 2631, .jump 2628]
def mid54 : List Instruction := [
  .dec 6 2638 2633, .inc 7 2634, .dec 6 2637 2635, .inc 1 2636, .jump 2634, .jump 2628,
  .dec 7 2642 2639, .inc 1 2640, .inc 1 2641, .jump 2638, .inc 1 2643, .inc 1 2644,
  .dec 2 2652 2645, .inc 7 2646, .dec 6 2648 2647, .jump 2651, .dec 7 2651 2649, .inc 6 2650,
  .jump 2648, .jump 2644, .dec 7 2655 2653, .inc 2 2654, .jump 2652, .dec 1 2659 2656,
  .inc 7 2657, .inc 6 2658, .jump 2655, .dec 6 2665 2660, .inc 7 2661, .dec 6 2664 2662,
  .inc 1 2663, .jump 2661, .jump 2655, .dec 7 2669 2666, .inc 1 2667, .inc 1 2668,
  .jump 2665, .inc 1 2670, .dec 1 2673 2671, .inc 6 2672, .jump 2670, .dec 2 2676 2674,
  .inc 1 2675, .jump 2673, .dec 1 2680 2677, .inc 7 2678, .inc 6 2679, .jump 2676]
def mid55 : List Instruction := [
  .dec 6 2686 2681, .inc 7 2682, .dec 6 2685 2683, .inc 1 2684, .jump 2682, .jump 2676,
  .dec 7 2689 2687, .inc 2 2688, .jump 2686, .dec 4 2693 2690, .inc 6 2691, .inc 1 2692,
  .jump 2689, .dec 6 2696 2694, .inc 4 2695, .jump 2693, .dec 2 2704 2697, .inc 7 2698,
  .dec 6 2700 2699, .jump 2703, .dec 7 2703 2701, .inc 6 2702, .jump 2700, .jump 2696,
  .dec 7 2707 2705, .inc 2 2706, .jump 2704, .dec 1 2711 2708, .inc 7 2709, .inc 6 2710,
  .jump 2707, .dec 6 2717 2712, .inc 7 2713, .dec 6 2716 2714, .inc 1 2715, .jump 2713,
  .jump 2707, .dec 7 2721 2718, .inc 1 2719, .inc 1 2720, .jump 2717, .inc 1 2722,
  .dec 1 2725 2723, .inc 6 2724, .jump 2722, .dec 2 2728 2726, .inc 1 2727, .jump 2725]
def mid56 : List Instruction := [
  .dec 1 2732 2729, .inc 7 2730, .inc 6 2731, .jump 2728, .dec 6 2738 2733, .inc 7 2734,
  .dec 6 2737 2735, .inc 1 2736, .jump 2734, .jump 2728, .dec 7 2741 2739, .inc 2 2740,
  .jump 2738, .dec 5 2745 2742, .inc 6 2743, .inc 1 2744, .jump 2741, .dec 6 2748 2746,
  .inc 5 2747, .jump 2745, .dec 2 2756 2749, .inc 7 2750, .dec 6 2752 2751, .jump 2755,
  .dec 7 2755 2753, .inc 6 2754, .jump 2752, .jump 2748, .dec 7 2759 2757, .inc 2 2758,
  .jump 2756, .dec 1 2763 2760, .inc 7 2761, .inc 6 2762, .jump 2759, .dec 6 2769 2764,
  .inc 7 2765, .dec 6 2768 2766, .inc 1 2767, .jump 2765, .jump 2759, .dec 7 2773 2770,
  .inc 1 2771, .inc 1 2772, .jump 2769, .inc 1 2774, .dec 1 2777 2775, .inc 6 2776]
def mid57 : List Instruction := [
  .jump 2774, .dec 2 2780 2778, .inc 1 2779, .jump 2777, .dec 1 2784 2781, .inc 7 2782,
  .inc 6 2783, .jump 2780, .dec 6 2790 2785, .inc 7 2786, .dec 6 2789 2787, .inc 1 2788,
  .jump 2786, .jump 2780, .dec 7 2793 2791, .inc 2 2792, .jump 2790, .dec 1 2796 2794,
  .inc 6 2795, .jump 2793, .dec 2 2799 2797, .inc 1 2798, .jump 2796, .dec 1 2803 2800,
  .inc 7 2801, .inc 6 2802, .jump 2799, .dec 6 2809 2804, .inc 7 2805, .dec 6 2808 2806,
  .inc 1 2807, .jump 2805, .jump 2799, .dec 7 2812 2810, .inc 2 2811, .jump 2809,
  .dec 5 2816 2813, .inc 6 2814, .inc 1 2815, .jump 2812, .dec 6 2819 2817, .inc 5 2818,
  .jump 2816, .dec 1 2822 2820, .inc 6 2821, .jump 2819, .dec 2 2825 2823, .inc 1 2824]
def mid58 : List Instruction := [
  .jump 2822, .dec 1 2829 2826, .inc 7 2827, .inc 6 2828, .jump 2825, .dec 6 2835 2830,
  .inc 7 2831, .dec 6 2834 2832, .inc 1 2833, .jump 2831, .jump 2825, .dec 7 2838 2836,
  .inc 2 2837, .jump 2835, .dec 5 2842 2839, .inc 6 2840, .inc 1 2841, .jump 2838,
  .dec 6 2845 2843, .inc 5 2844, .jump 2842, .dec 2 2853 2846, .inc 7 2847, .dec 6 2849 2848,
  .jump 2852, .dec 7 2852 2850, .inc 6 2851, .jump 2849, .jump 2845, .dec 7 2856 2854,
  .inc 2 2855, .jump 2853, .dec 1 2860 2857, .inc 7 2858, .inc 6 2859, .jump 2856,
  .dec 6 2866 2861, .inc 7 2862, .dec 6 2865 2863, .inc 1 2864, .jump 2862, .jump 2856,
  .dec 7 2870 2867, .inc 1 2868, .inc 1 2869, .jump 2866, .inc 1 2871, .inc 1 2872]
def mid59 : List Instruction := [
  .dec 2 2880 2873, .inc 7 2874, .dec 6 2876 2875, .jump 2879, .dec 7 2879 2877, .inc 6 2878,
  .jump 2876, .jump 2872, .dec 7 2883 2881, .inc 2 2882, .jump 2880, .dec 1 2887 2884,
  .inc 7 2885, .inc 6 2886, .jump 2883, .dec 6 2893 2888, .inc 7 2889, .dec 6 2892 2890,
  .inc 1 2891, .jump 2889, .jump 2883, .dec 7 2897 2894, .inc 1 2895, .inc 1 2896,
  .jump 2893, .inc 1 2898, .dec 1 2901 2899, .inc 6 2900, .jump 2898, .dec 2 2904 2902,
  .inc 1 2903, .jump 2901, .dec 1 2908 2905, .inc 7 2906, .inc 6 2907, .jump 2904,
  .dec 6 2914 2909, .inc 7 2910, .dec 6 2913 2911, .inc 1 2912, .jump 2910, .jump 2904,
  .dec 7 2917 2915, .inc 2 2916, .jump 2914, .dec 5 2921 2918, .inc 6 2919, .inc 1 2920]
def mid60 : List Instruction := [
  .jump 2917, .dec 6 2924 2922, .inc 5 2923, .jump 2921, .dec 2 2932 2925, .inc 7 2926,
  .dec 6 2928 2927, .jump 2931, .dec 7 2931 2929, .inc 6 2930, .jump 2928, .jump 2924,
  .dec 7 2935 2933, .inc 2 2934, .jump 2932, .dec 1 2939 2936, .inc 7 2937, .inc 6 2938,
  .jump 2935, .dec 6 2945 2940, .inc 7 2941, .dec 6 2944 2942, .inc 1 2943, .jump 2941,
  .jump 2935, .dec 7 2949 2946, .inc 1 2947, .inc 1 2948, .jump 2945, .inc 1 2950,
  .dec 1 2953 2951, .inc 6 2952, .jump 2950, .dec 2 2956 2954, .inc 1 2955, .jump 2953,
  .dec 1 2960 2957, .inc 7 2958, .inc 6 2959, .jump 2956, .dec 6 2966 2961, .inc 7 2962,
  .dec 6 2965 2963, .inc 1 2964, .jump 2962, .jump 2956, .dec 7 2969 2967, .inc 2 2968]
def mid61 : List Instruction := [
  .jump 2966, .dec 5 2973 2970, .inc 6 2971, .inc 1 2972, .jump 2969, .dec 6 2976 2974,
  .inc 5 2975, .jump 2973, .dec 2 2984 2977, .inc 7 2978, .dec 6 2980 2979, .jump 2983,
  .dec 7 2983 2981, .inc 6 2982, .jump 2980, .jump 2976, .dec 7 2987 2985, .inc 2 2986,
  .jump 2984, .dec 1 2991 2988, .inc 7 2989, .inc 6 2990, .jump 2987, .dec 6 2997 2992,
  .inc 7 2993, .dec 6 2996 2994, .inc 1 2995, .jump 2993, .jump 2987, .dec 7 3001 2998,
  .inc 1 2999, .inc 1 3000, .jump 2997, .inc 1 3002, .dec 2 3010 3003, .inc 7 3004,
  .dec 6 3006 3005, .jump 3009, .dec 7 3009 3007, .inc 6 3008, .jump 3006, .jump 3002,
  .dec 7 3013 3011, .inc 2 3012, .jump 3010, .dec 1 3017 3014, .inc 7 3015, .inc 6 3016]
def mid62 : List Instruction := [
  .jump 3013, .dec 6 3023 3018, .inc 7 3019, .dec 6 3022 3020, .inc 1 3021, .jump 3019,
  .jump 3013, .dec 7 3027 3024, .inc 1 3025, .inc 1 3026, .jump 3023, .dec 1 3030 3028,
  .inc 6 3029, .jump 3027, .dec 2 3033 3031, .inc 1 3032, .jump 3030, .dec 1 3037 3034,
  .inc 7 3035, .inc 6 3036, .jump 3033, .dec 6 3043 3038, .inc 7 3039, .dec 6 3042 3040,
  .inc 1 3041, .jump 3039, .jump 3033, .dec 7 3046 3044, .inc 2 3045, .jump 3043,
  .dec 4 3050 3047, .inc 6 3048, .inc 1 3049, .jump 3046, .dec 6 3053 3051, .inc 4 3052,
  .jump 3050, .dec 1 3056 3054, .inc 6 3055, .jump 3053, .dec 2 3059 3057, .inc 1 3058,
  .jump 3056, .dec 1 3063 3060, .inc 7 3061, .inc 6 3062, .jump 3059, .dec 6 3069 3064]
def mid63 : List Instruction := [
  .inc 7 3065, .dec 6 3068 3066, .inc 1 3067, .jump 3065, .jump 3059, .dec 7 3072 3070,
  .inc 2 3071, .jump 3069, .dec 5 3076 3073, .inc 6 3074, .inc 1 3075, .jump 3072,
  .dec 6 3079 3077, .inc 5 3078, .jump 3076, .dec 2 3087 3080, .inc 7 3081, .dec 6 3083 3082,
  .jump 3086, .dec 7 3086 3084, .inc 6 3085, .jump 3083, .jump 3079, .dec 7 3090 3088,
  .inc 2 3089, .jump 3087, .dec 1 3094 3091, .inc 7 3092, .inc 6 3093, .jump 3090,
  .dec 6 3100 3095, .inc 7 3096, .dec 6 3099 3097, .inc 1 3098, .jump 3096, .jump 3090,
  .dec 7 3104 3101, .inc 1 3102, .inc 1 3103, .jump 3100, .inc 1 3105, .dec 2 3113 3106,
  .inc 7 3107, .dec 6 3109 3108, .jump 3112, .dec 7 3112 3110, .inc 6 3111, .jump 3109]
def mid64 : List Instruction := [
  .jump 3105, .dec 7 3116 3114, .inc 2 3115, .jump 3113, .dec 1 3120 3117, .inc 7 3118,
  .inc 6 3119, .jump 3116, .dec 6 3126 3121, .inc 7 3122, .dec 6 3125 3123, .inc 1 3124,
  .jump 3122, .jump 3116, .dec 7 3130 3127, .inc 1 3128, .inc 1 3129, .jump 3126,
  .dec 1 3133 3131, .inc 6 3132, .jump 3130, .dec 2 3136 3134, .inc 1 3135, .jump 3133,
  .dec 1 3140 3137, .inc 7 3138, .inc 6 3139, .jump 3136, .dec 6 3146 3141, .inc 7 3142,
  .dec 6 3145 3143, .inc 1 3144, .jump 3142, .jump 3136, .dec 7 3149 3147, .inc 2 3148,
  .jump 3146, .dec 5 3153 3150, .inc 6 3151, .inc 1 3152, .jump 3149, .dec 6 3156 3154,
  .inc 5 3155, .jump 3153, .dec 1 3159 3157, .inc 6 3158, .jump 3156, .dec 2 3162 3160]
def mid65 : List Instruction := [
  .inc 1 3161, .jump 3159, .dec 1 3166 3163, .inc 7 3164, .inc 6 3165, .jump 3162,
  .dec 6 3172 3167, .inc 7 3168, .dec 6 3171 3169, .inc 1 3170, .jump 3168, .jump 3162,
  .dec 7 3175 3173, .inc 2 3174, .jump 3172, .dec 4 3179 3176, .inc 6 3177, .inc 1 3178,
  .jump 3175, .dec 6 3182 3180, .inc 4 3181, .jump 3179, .dec 1 3185 3183, .inc 6 3184,
  .jump 3182, .dec 2 3188 3186, .inc 1 3187, .jump 3185, .dec 1 3192 3189, .inc 7 3190,
  .inc 6 3191, .jump 3188, .dec 6 3198 3193, .inc 7 3194, .dec 6 3197 3195, .inc 1 3196,
  .jump 3194, .jump 3188, .dec 7 3201 3199, .inc 2 3200, .jump 3198, .dec 5 3205 3202,
  .inc 6 3203, .inc 1 3204, .jump 3201, .dec 6 3208 3206, .inc 5 3207, .jump 3205]
def mid66 : List Instruction := [
  .dec 2 3216 3209, .inc 7 3210, .dec 6 3212 3211, .jump 3215, .dec 7 3215 3213, .inc 6 3214,
  .jump 3212, .jump 3208, .dec 7 3219 3217, .inc 2 3218, .jump 3216, .dec 1 3223 3220,
  .inc 7 3221, .inc 6 3222, .jump 3219, .dec 6 3229 3224, .inc 7 3225, .dec 6 3228 3226,
  .inc 1 3227, .jump 3225, .jump 3219, .dec 7 3233 3230, .inc 1 3231, .inc 1 3232,
  .jump 3229, .inc 1 3234, .inc 1 3235, .dec 2 3243 3236, .inc 7 3237, .dec 6 3239 3238,
  .jump 3242, .dec 7 3242 3240, .inc 6 3241, .jump 3239, .jump 3235, .dec 7 3246 3244,
  .inc 2 3245, .jump 3243, .dec 1 3250 3247, .inc 7 3248, .inc 6 3249, .jump 3246,
  .dec 6 3256 3251, .inc 7 3252, .dec 6 3255 3253, .inc 1 3254, .jump 3252, .jump 3246]
def mid67 : List Instruction := [
  .dec 7 3260 3257, .inc 1 3258, .inc 1 3259, .jump 3256, .inc 1 3261, .dec 1 3264 3262,
  .inc 6 3263, .jump 3261, .dec 2 3267 3265, .inc 1 3266, .jump 3264, .dec 1 3271 3268,
  .inc 7 3269, .inc 6 3270, .jump 3267, .dec 6 3277 3272, .inc 7 3273, .dec 6 3276 3274,
  .inc 1 3275, .jump 3273, .jump 3267, .dec 7 3280 3278, .inc 2 3279, .jump 3277,
  .dec 4 3284 3281, .inc 6 3282, .inc 1 3283, .jump 3280, .dec 6 3287 3285, .inc 4 3286,
  .jump 3284, .dec 1 3290 3288, .inc 6 3289, .jump 3287, .dec 2 3293 3291, .inc 1 3292,
  .jump 3290, .dec 1 3297 3294, .inc 7 3295, .inc 6 3296, .jump 3293, .dec 6 3303 3298,
  .inc 7 3299, .dec 6 3302 3300, .inc 1 3301, .jump 3299, .jump 3293, .dec 7 3306 3304]
def mid68 : List Instruction := [
  .inc 2 3305, .jump 3303, .dec 4 3310 3307, .inc 6 3308, .inc 1 3309, .jump 3306,
  .dec 6 3313 3311, .inc 4 3312, .jump 3310, .dec 1 3316 3314, .inc 6 3315, .jump 3313,
  .dec 2 3319 3317, .inc 1 3318, .jump 3316, .dec 1 3323 3320, .inc 7 3321, .inc 6 3322,
  .jump 3319, .dec 6 3329 3324, .inc 7 3325, .dec 6 3328 3326, .inc 1 3327, .jump 3325,
  .jump 3319, .dec 7 3332 3330, .inc 2 3331, .jump 3329, .dec 5 3336 3333, .inc 6 3334,
  .inc 1 3335, .jump 3332, .dec 6 3339 3337, .inc 5 3338, .jump 3336, .dec 2 3347 3340,
  .inc 7 3341, .dec 6 3343 3342, .jump 3346, .dec 7 3346 3344, .inc 6 3345, .jump 3343,
  .jump 3339, .dec 7 3350 3348, .inc 2 3349, .jump 3347, .dec 1 3354 3351, .inc 7 3352]
def mid69 : List Instruction := [
  .inc 6 3353, .jump 3350, .dec 6 3360 3355, .inc 7 3356, .dec 6 3359 3357, .inc 1 3358,
  .jump 3356, .jump 3350, .dec 7 3364 3361, .inc 1 3362, .inc 1 3363, .jump 3360,
  .inc 1 3365, .inc 1 3366, .dec 2 3374 3367, .inc 7 3368, .dec 6 3370 3369, .jump 3373,
  .dec 7 3373 3371, .inc 6 3372, .jump 3370, .jump 3366, .dec 7 3377 3375, .inc 2 3376,
  .jump 3374, .dec 1 3381 3378, .inc 7 3379, .inc 6 3380, .jump 3377, .dec 6 3387 3382,
  .inc 7 3383, .dec 6 3386 3384, .inc 1 3385, .jump 3383, .jump 3377, .dec 7 3391 3388,
  .inc 1 3389, .inc 1 3390, .jump 3387, .inc 1 3392, .dec 2 3400 3393, .inc 7 3394,
  .dec 6 3396 3395, .jump 3399, .dec 7 3399 3397, .inc 6 3398, .jump 3396, .jump 3392]
def mid70 : List Instruction := [
  .dec 7 3403 3401, .inc 2 3402, .jump 3400, .dec 1 3407 3404, .inc 7 3405, .inc 6 3406,
  .jump 3403, .dec 6 3413 3408, .inc 7 3409, .dec 6 3412 3410, .inc 1 3411, .jump 3409,
  .jump 3403, .dec 7 3417 3414, .inc 1 3415, .inc 1 3416, .jump 3413, .inc 1 3418,
  .dec 1 3421 3419, .inc 6 3420, .jump 3418, .dec 2 3424 3422, .inc 1 3423, .jump 3421,
  .dec 1 3428 3425, .inc 7 3426, .inc 6 3427, .jump 3424, .dec 6 3434 3429, .inc 7 3430,
  .dec 6 3433 3431, .inc 1 3432, .jump 3430, .jump 3424, .dec 7 3437 3435, .inc 2 3436,
  .jump 3434, .dec 4 3441 3438, .inc 6 3439, .inc 1 3440, .jump 3437, .dec 6 3444 3442,
  .inc 4 3443, .jump 3441, .dec 1 3447 3445, .inc 6 3446, .jump 3444, .dec 2 3450 3448]
def mid71 : List Instruction := [
  .inc 1 3449, .jump 3447, .dec 1 3454 3451, .inc 7 3452, .inc 6 3453, .jump 3450,
  .dec 6 3460 3455, .inc 7 3456, .dec 6 3459 3457, .inc 1 3458, .jump 3456, .jump 3450,
  .dec 7 3463 3461, .inc 2 3462, .jump 3460, .dec 5 3467 3464, .inc 6 3465, .inc 1 3466,
  .jump 3463, .dec 6 3470 3468, .inc 5 3469, .jump 3467, .dec 2 3478 3471, .inc 7 3472,
  .dec 6 3474 3473, .jump 3477, .dec 7 3477 3475, .inc 6 3476, .jump 3474, .jump 3470,
  .dec 7 3481 3479, .inc 2 3480, .jump 3478, .dec 1 3485 3482, .inc 7 3483, .inc 6 3484,
  .jump 3481, .dec 6 3491 3486, .inc 7 3487, .dec 6 3490 3488, .inc 1 3489, .jump 3487,
  .jump 3481, .dec 7 3495 3492, .inc 1 3493, .inc 1 3494, .jump 3491, .inc 1 3496]
def mid72 : List Instruction := [
  .dec 2 3504 3497, .inc 7 3498, .dec 6 3500 3499, .jump 3503, .dec 7 3503 3501, .inc 6 3502,
  .jump 3500, .jump 3496, .dec 7 3507 3505, .inc 2 3506, .jump 3504, .dec 1 3511 3508,
  .inc 7 3509, .inc 6 3510, .jump 3507, .dec 6 3517 3512, .inc 7 3513, .dec 6 3516 3514,
  .inc 1 3515, .jump 3513, .jump 3507, .dec 7 3521 3518, .inc 1 3519, .inc 1 3520,
  .jump 3517]
def mid : List Instruction := [mid0, mid1, mid2, mid3, mid4, mid5, mid6, mid7, mid8, mid9, mid10, mid11, mid12, mid13, mid14, mid15, mid16, mid17, mid18, mid19, mid20, mid21, mid22, mid23, mid24, mid25, mid26, mid27, mid28, mid29, mid30, mid31, mid32, mid33, mid34, mid35, mid36, mid37, mid38, mid39, mid40, mid41, mid42, mid43, mid44, mid45, mid46, mid47, mid48, mid49, mid50, mid51, mid52, mid53, mid54, mid55, mid56, mid57, mid58, mid59, mid60, mid61, mid62, mid63, mid64, mid65, mid66, mid67, mid68, mid69, mid70, mid71, mid72].flatten
def post0 : List Instruction := [
  .jump 39, .dec 1 3525 3523, .inc 6 3524, .jump 3522, .dec 2 3528 3526, .inc 1 3527,
  .jump 3525, .dec 1 3532 3529, .inc 7 3530, .inc 6 3531, .jump 3528, .dec 6 3538 3533,
  .inc 7 3534, .dec 6 3537 3535, .inc 1 3536, .jump 3534, .jump 3528, .dec 7 3541 3539,
  .inc 2 3540, .jump 3538, .dec 4 3545 3542, .inc 6 3543, .inc 1 3544, .jump 3541,
  .dec 6 3548 3546, .inc 4 3547, .jump 3545, .dec 2 3556 3549, .inc 7 3550, .dec 6 3552 3551,
  .jump 3555, .dec 7 3555 3553, .inc 6 3554, .jump 3552, .jump 3548, .dec 7 3559 3557,
  .inc 2 3558, .jump 3556, .dec 1 3563 3560, .inc 7 3561, .inc 6 3562, .jump 3559,
  .dec 6 3569 3564, .inc 7 3565, .dec 6 3568 3566, .inc 1 3567, .jump 3565, .jump 3559]
def post1 : List Instruction := [
  .dec 7 3573 3570, .inc 1 3571, .inc 1 3572, .jump 3569, .dec 1 3576 3574, .inc 6 3575,
  .jump 3573, .dec 6 3583 3577, .dec 5 3579 3578, .jump 3576, .inc 5 3580, .dec 6 3583 3581,
  .inc 5 3582, .jump 3580, .dec 5 3585 3584, .jump 3592, .dec 4 3589 3586, .inc 6 3587,
  .inc 1 3588, .jump 3585, .dec 6 3592 3590, .inc 4 3591, .jump 3589, .dec 4 3594 3593,
  .jump 3592, .dec 5 3596 3595, .jump 3594, .dec 4 3623 3597, .dec 1 3600 3598, .inc 6 3599,
  .jump 3597, .dec 2 3603 3601, .inc 1 3602, .jump 3600, .dec 1 3607 3604, .inc 7 3605,
  .inc 6 3606, .jump 3603, .dec 6 3613 3608, .inc 7 3609, .dec 6 3612 3610, .inc 1 3611,
  .jump 3609, .jump 3603, .dec 7 3616 3614, .inc 2 3615, .jump 3613, .dec 5 3620 3617]
def post2 : List Instruction := [
  .inc 6 3618, .inc 1 3619, .jump 3616, .dec 6 3623 3621, .inc 5 3622, .jump 3620,
  .dec 5 3627 3624, .dec 5 3627 3625, .dec 5 3627 3626, .decHalt 5 3627, .dec 5 3629 3628, .jump 3627,
  .dec 2 3637 3630, .inc 7 3631, .dec 6 3633 3632, .jump 3636, .dec 7 3636 3634, .inc 6 3635,
  .jump 3633, .jump 3629, .dec 7 3640 3638, .inc 2 3639, .jump 3637, .dec 6 0 3641,
  .inc 5 3642, .jump 3640]
def post : List Instruction := [post0, post1, post2].flatten
def program (pc : Nat) : Instruction :=
  if pc < 40 then pre.getD pc .halt else if pc < 3521 then mid.getD (pc-40) .halt else post.getD (pc-3521) (.jump pc)

theorem mid_eq_compile : mid = compile NF180Counting.GuardedLogic.batchCode 40 3521 [] [] := by rfl

theorem mid_length : mid.length = 3481 := by decide

theorem batch_embedded : Embedded program NF180Counting.GuardedLogic.batchCode 40 3521 [] [] := by
  intro i hi
  have eqsize : NF180Counting.GuardedLogic.batchCode.size = 3481 := by rw [← compile_length NF180Counting.GuardedLogic.batchCode 40 3521 [] [], ← mid_eq_compile, mid_length]
  have ha : ¬ 40+i < 40 := by omega
  have hb : 40+i < 3521 := by omega
  simp only [program,if_neg ha,if_pos hb,Nat.add_sub_cancel_left]
  rw [mid_eq_compile, List.getD_eq_getElem?_getD, List.getElem?_eq_getElem (by simpa only [compile_length] using hi)]
  rfl

theorem selected_batch (n t stack c u v y delta tail : Nat) :
    Reaches program ⟨40,Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩⟩
      (some ⟨3521,(save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (NF180Counting.GuardedLogic.rowList (u+delta) (v+y) c u)).regs⟩) :=
  (NF180Counting.GuardedLogic.batch_eval n t stack c u v y delta tail).compiled program 40 3521 [] [] batch_embedded

end Literal
end NF180Counting.GuardedLogic
#print axioms NF180Counting.GuardedLogic.Literal.selected_batch
