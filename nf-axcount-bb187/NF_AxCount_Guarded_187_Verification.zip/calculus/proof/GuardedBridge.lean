import Binding
import ConditionalTransfer

namespace CountingRefill.GuardedBridge
open NF192
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false

def command : Source.Command → Cmd
  | .inl (r,p) => .inc r p
  | .inr (.inl (r,z,p,h)) => .dec r (if h then none else some z) p
  | .inr (.inr p) => .jump p

def bounded : Cmd → Bool
  | .inc _ p | .jump p => decide (p < 3643)
  | .dec _ z p => decide (p < 3643) && (z.map (fun i => decide (i < 3643))).getD true

private def chart : List Cmd :=
  (NF180Counting.GuardedLogic.Literal.pre ++ (NF180Counting.GuardedLogic.Literal.mid ++ NF180Counting.GuardedLogic.Literal.post)).map
    (fun op => command (NF180Counting.GuardedLogic.R7Raw.asCommand op))

private theorem literal_match : Binding.old.instructions = chart := by decide +kernel
private theorem destinations : Binding.old.instructions.all bounded = true := by decide +kernel
private theorem tailLength : batches.flatten.length = 3633 := by decide +kernel
private theorem aLength : NF180Counting.GuardedLogic.Literal.pre.length = 40 := by decide +kernel
private theorem bLength : NF180Counting.GuardedLogic.Literal.mid.length = 3481 := by decide +kernel
private theorem cLength : NF180Counting.GuardedLogic.Literal.post.length = 122 := by decide +kernel

private theorem old_get (i : Nat) (hi : i < 3643) :
    Binding.old.instructions[i]? = some (oldProgram i) := by
  by_cases h : i < 10
  · simp [Binding.old.instructions, oldProgram, h, List.getElem?_append, List.getElem?_map,
      List.getElem?_range h]
  · have hl : i-10 < batches.flatten.length := by rw [tailLength]; omega
    simp only [Binding.old.instructions,List.getElem?_append,List.length_map,List.length_range,
      ite_eq_right h,List.getElem?_map,List.getElem?_eq_getElem hl,oldProgram,atRow,Option.map_some,
      Option.getD_some]


private theorem chart_get (i : Nat) (hi : i < 3643) :
    chart[i]? = some (command (NF180Counting.GuardedLogic.R7Raw.program i)) := by
  by_cases h : i < 40
  · have hpre : i < NF180Counting.GuardedLogic.Literal.pre.length := aLength ▸ h
    simp [chart, NF180Counting.GuardedLogic.R7Raw.program,NF180Counting.GuardedLogic.Literal.program,h,List.getElem?_map,
      List.getElem?_append,hpre,List.getD_eq_getElem?_getD,List.getElem?_eq_getElem hpre]
  by_cases k : i < 3521
  · have hm : i-40 < NF180Counting.GuardedLogic.Literal.mid.length := by rw [bLength]; omega
    simp [chart,NF180Counting.GuardedLogic.R7Raw.program,NF180Counting.GuardedLogic.Literal.program,h,k,List.getElem?_map,List.getElem?_append,
      aLength,hm,List.getD_eq_getElem?_getD,List.getElem?_eq_getElem hm]
  · have hm : ¬i-40 < 3481 := by omega
    have j : i-40-3481 = i-3521 := by omega
    have hp : i-3521 < NF180Counting.GuardedLogic.Literal.post.length := by rw [cLength]; omega
    simp [chart,NF180Counting.GuardedLogic.R7Raw.program,NF180Counting.GuardedLogic.Literal.program,h,k,List.getElem?_map,List.getElem?_append,
      aLength,bLength,hm,j,List.getD_eq_getElem?_getD,List.getElem?_eq_getElem hp]

theorem correct (i : Nat) (hi : i < 3643) :
    oldProgram i = command (NF180Counting.GuardedLogic.R7Raw.program i) ∧ bounded (oldProgram i) = true := by
  have ho := old_get i hi
  exact ⟨Option.some.inj (ho.symm.trans ((congrArg (fun xs : List Cmd => xs[i]?) literal_match).trans (chart_get i hi))),
     List.all_eq_true.mp destinations _ (List.mem_of_getElem? ho)⟩

def project (s : Option State) : Source.Config := s.map (fun (pc,r) => (pc,r.read))

theorem write_read (r : Regs) (i v : Nat) :
    (r.write i v).read = Source.setReg r.read i v := by
  funext j
  by_cases h0 : i=0 <;> by_cases h6 : i=6 <;> by_cases h7 : i=7 <;>
    by_cases g0 : j=0 <;> by_cases g6 : j=6 <;> by_cases g7 : j=7 <;>
      by_cases hj : j=i <;> simp_all [Regs.read,Regs.write,Source.setReg]

theorem eval (c : Source.Command) (r : Regs) :
    project (execute (command c) r) = Source.execute c r.read := by
  rcases c with ⟨k,p⟩ | (⟨k,z,p,h⟩ | p)
  · simp [project,execute,command,Source.execute,write_read]
  · cases e : r.read k with
    | zero => cases h <;> simp [project,execute,command,Source.execute,e]
    | succ v => cases h <;> simp [project,execute,command,Source.execute,e,write_read]
  · rfl

def InRange : Option State → Prop
  | none => True
  | some (pc,_) => pc < 3643

theorem bounded_step (c : Cmd) (hc : bounded c = true) (r : Regs) : InRange (execute c r) := by
  cases c with
  | inc k p => simpa [InRange, execute, bounded] using hc
  | jump p => simpa [InRange, execute, bounded] using hc
  | dec k z p =>
    cases z <;> cases e : r.read k <;> simp_all [InRange, execute, bounded]

theorem step (s : Option State) (hs : InRange s) :
  project (raw oldProgram s) = NF180Counting.GuardedLogic.R7Raw.step (project s) ∧ InRange (raw oldProgram s) := by
  rcases s with _ | ⟨i,r⟩
  · exact ⟨rfl,True.intro⟩
  have ⟨eq,cl⟩ := correct i hs
  change project (execute (oldProgram i) r) = Source.execute (NF180Counting.GuardedLogic.R7Raw.program i) r.read ∧ _
  exact ⟨eq ▸ eval _ _,bounded_step _ cl _⟩

theorem run (t : Nat) (s : Option State) (h : InRange s) :
    project (iterate (raw oldProgram) t s) = NF180Counting.GuardedLogic.R7Raw.advance t (project s) := by
  induction t generalizing s with
  | zero => rfl
  | succ t ih =>
    have ⟨e,b⟩ := step s h
    exact (ih (raw oldProgram s) b).trans (congrArg (NF180Counting.GuardedLogic.R7Raw.advance t) e)

theorem projected_none (s : Option State) : project s = none ↔ s = none := by cases s <;> simp [project]

theorem proj_start (n : Nat) :
   project (some (conf 0 n 0 0 (fun _ => 0))) =
   NF180Counting.GuardedLogic.R7Register.atFrame 0 (NF180Counting.GuardedLogic.R7Register.registers n 0 NF180Counting.GuardedLogic.R7Register.initialProof) := by
  apply congrArg some
  apply Prod.ext
  · rfl
  funext i
  by_cases h : i < 9
  · have split : i=0 ∨ i=1 ∨ i=2 ∨ i=3 ∨ i=4 ∨ i=5 ∨ i=6 ∨ i=7 ∨ i=8 := by omega
    rcases split with h|h|h|h|h|h|h|h|h <;> subst i <;> rfl
  · have e0 : i≠0 := by omega
    have e6 : i≠6 := by omega
    have e7 : i≠7 := by omega
    simp [Regs.read,e0,e6,e7,NF192.Emitter.liftRegisters,h]

theorem old_goal (n : Nat) :
    Halts (raw oldProgram) (some (conf 0 n 0 0 (fun _ => 0))) ↔ NF180Counting.GuardedLogic.Deriv Numerical.goal := by
  let s := some (conf 0 n 0 0 (fun _ => 0))
  have bound : InRange s := by change 0 < 3643; decide
  have eq : ∀ t, iterate (raw oldProgram) t s = none ↔
      NF180Counting.GuardedLogic.R7Raw.advance t (NF180Counting.GuardedLogic.R7Register.atFrame 0 (NF180Counting.GuardedLogic.R7Register.registers n 0 NF180Counting.GuardedLogic.R7Register.initialProof)) = none := by
    intro t
    rw [← projected_none,run _ s bound,proj_start]
  exact (exists_congr eq).trans (NF180Counting.GuardedLogic.R7Register.halts_iff_goal n _ NF180Counting.GuardedLogic.R7Register.initialProof_sound)

theorem guarded187_register_halts_iff_goal :
    Halts (raw newProgram) (some (conf 0 5 0 0 (fun _ => 0))) ↔ NF180Counting.GuardedLogic.Deriv Numerical.goal :=
  Binding.blank_frame_register_equivalence.trans (old_goal 4)

#print axioms guarded187_register_halts_iff_goal
end CountingRefill.GuardedBridge
