import ConditionalRaw
import NumericalOuter
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace NF180Counting.GuardedLogic.R7Register
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers

def actual (pc : Nat) : Instruction := readCommand (R7Raw.program pc)
theorem actual_eq : actual = NF180Counting.GuardedLogic.Literal.program := by
  funext pc; unfold actual R7Raw.program
  cases h : NF180Counting.GuardedLogic.Literal.program pc with
  | inc r n => simp [R7Raw.asCommand,readCommand,r.isLt]
  | dec r z n => simp [R7Raw.asCommand,readCommand,r.isLt]
  | decHalt r n => simp [R7Raw.asCommand,readCommand,r.isLt]
  | jump => rfl
  | halt => rfl

theorem batch_embedded : Embedded actual NF180Counting.GuardedLogic.batchCode 40 3521 [] [] := actual_eq ▸ NF180Counting.GuardedLogic.Literal.batch_embedded
theorem actual_step {s t : Config} (hs : NF192.Emitter.step actual s = some t) :
    R7Raw.step (liftConfig s) = liftConfig t := by
  obtain ⟨pc, rs⟩ := s
  cases hc : R7Raw.program pc with
  | inl inc =>
      obtain ⟨r, next⟩ := inc
      by_cases hr : r < 9
      · simp only [NF192.Emitter.step, actual, hc, readCommand, dif_pos hr, Option.some.injEq] at hs
        subst t
        change Source.execute (R7Raw.program pc) (liftRegisters rs) = _
        rw [hc]
        simp only [Source.execute, liftConfig, Registers.add]
        rw [show liftRegisters rs r = rs ⟨r,hr⟩ from liftRegisters_at rs ⟨r,hr⟩]
        rw [show Source.setReg (liftRegisters rs) r (rs ⟨r,hr⟩+1) =
          liftRegisters (rs.set ⟨r,hr⟩ (rs ⟨r,hr⟩+1)) from liftRegisters_set rs ⟨r,hr⟩ _]
      · simp [NF192.Emitter.step, actual, hc, readCommand, hr] at hs
  | inr cmd =>
      cases cmd with
      | inr next =>
          simp only [NF192.Emitter.step, actual, hc, readCommand, Option.some.injEq] at hs
          subst t
          change Source.execute (R7Raw.program pc) (liftRegisters rs) = _
          rw [hc]
          rfl
      | inl dec =>
          obtain ⟨r, z, p, flag⟩ := dec
          by_cases hr : r < 9
          · have get : liftRegisters rs r = rs ⟨r,hr⟩ := liftRegisters_at rs ⟨r,hr⟩
            cases hv : rs ⟨r,hr⟩ with
            | zero =>
                cases flag <;> simp [NF192.Emitter.step, actual, hc, readCommand, hr, hv] at hs
                subst t
                change Source.execute (R7Raw.program pc) (liftRegisters rs) = _
                rw [hc]
                simp [Source.execute, get, hv, liftConfig]
            | succ n =>
                have put := liftRegisters_set rs ⟨r,hr⟩ n
                cases flag <;> simp [NF192.Emitter.step, actual, hc, readCommand, hr, hv] at hs <;> subst t
                all_goals
                  change Source.execute (R7Raw.program pc) (liftRegisters rs) = _
                  rw [hc]
                  simp [Source.execute, liftConfig, get, hv, put]
          · simp [NF192.Emitter.step, actual, hc, readCommand, hr] at hs

theorem actual_run (n : Nat) {s t : Config} (h : NF192.Emitter.run actual n s = some t) :
    R7Raw.advance n (liftConfig s) = liftConfig t := by
  induction n generalizing s with
  | zero =>
      have e : s = t := Option.some.inj h
      subst t
      rfl
  | succ n ih =>
      cases hs : NF192.Emitter.step actual s with
      | none => simp [NF192.Emitter.run, hs] at h
      | some u =>
          have rest : NF192.Emitter.run actual n u = some t := by simpa only [NF192.Emitter.run, hs, Option.bind_some] using h
          exact (congrArg (R7Raw.advance n) (actual_step hs)).trans (ih rest)

/-- Any checked embedding of this emitter code supplies the all-input AX batch NF192.Emitter.step. -/
theorem ax_program_of_embedding
    (embedded : Embedded actual NF180Counting.GuardedLogic.batchCode 40 3521 [] [])
    (n t stack c u v y delta tail : Nat) :
    ∃ ticks, 0 < ticks ∧
      R7Raw.advance ticks
        (Source.Config.active 40 (liftRegisters (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩))) =
        Source.Config.active 3521 (liftRegisters ((save ⟨n,t,stack,c,u+delta,v+y,tail⟩
          (NF180Counting.GuardedLogic.rowList (u+delta) (v+y) c u)).regs)) := by
  obtain ⟨ticks, ht, hrun⟩ := (NF180Counting.GuardedLogic.batch_eval n t stack c u v y delta tail).compiled
    actual 40 3521 [] [] embedded
  exact ⟨ticks, ht, actual_run ticks hrun⟩
def matchesCode (pc : Nat) : List Instruction → Bool
  | [] => true
  | i :: is => decide (actual pc = i) && matchesCode (pc+1) is

theorem matchesCode_spec (pc : Nat) (xs : List Instruction) (yes : matchesCode pc xs = true)
    (i : Nat) (hi : i < xs.length) : actual (pc+i) = xs[i] := by
  induction xs generalizing pc i with
  | nil => simp at hi
  | cons x xs ih =>
      change (decide (actual pc = x) && matchesCode (pc+1) xs) = true at yes
      have hh : decide (actual pc = x) = true ∧ matchesCode (pc+1) xs = true := by simpa only [Bool.and_eq_true_iff] using yes
      cases i with
      | zero => simpa using (of_decide_eq_true hh.1 : actual pc = x)
      | succ j =>
          have hj : j < xs.length := by simpa using hi
          have he := ih (pc+1) hh.2 j hj
          simpa only [List.getElem_cons_succ, Nat.add_assoc, Nat.add_comm 1 j, Nat.succ_eq_add_one] using he

theorem embedded_of_matches (code : Code) (pc last : Nat)
    (check : matchesCode pc (compile code pc last [] []) = true) :
    Embedded actual code pc last [] [] := by
  intro i hi
  exact matchesCode_spec pc _ check i (by simpa only [compile_length] using hi)
def Moves (s t : Source.Config) : Prop := ∃ n, 0 < n ∧ R7Raw.advance n s = t

theorem Moves.one {s t : Source.Config} (h : R7Raw.step s = t) : Moves s t := ⟨1,by decide,h⟩
theorem Moves.trans {s t u : Source.Config} (a : Moves s t) (b : Moves t u) : Moves s u := by
  obtain ⟨n, pn, hn⟩ := a
  obtain ⟨m, pm, hm⟩ := b
  exact ⟨n+m, by omega, by rw [R7Raw.advance_add, hn, hm]⟩

def atFrame (pc : Nat) (f : Frame) : Source.Config := Source.Config.active pc (liftRegisters f.regs)

theorem move_compiled {code : Code} {s t : Registers} {p z : Nat}
    (h : Eval code s .normal t) (e : Embedded actual code p z [] []) :
    Moves (Source.Config.active p (liftRegisters s)) (Source.Config.active z (liftRegisters t)) := by
  obtain ⟨n, pos, hl⟩ := h.compiled actual p z [] [] e
  exact ⟨n, pos, actual_run n hl⟩

def firstRead : Code := .seq NF192.Emitter.Literal.seq158 NF192.Emitter.Literal.seq201

def twoReads : Code := .seq firstRead NF192.Emitter.Literal.seq175

theorem twoReads_spec (n t stack c a b selector field tail : Nat) :
    Eval twoReads (mk9 n t stack c a b 0 0 (pair selector (pair field tail))) .normal
      (mk9 n t stack (c+selector) (a+field) b 0 0 tail) := by
  have r₁ := seq158_normal n t stack c a b (pair selector (pair field tail))
  simp only [Cantor.unpair_pair] at r₁
  have r₂ := seq201_eval n t stack c a b selector 0 (pair field tail)
  have r₃ := seq175_normal n t stack (c+selector) a b (pair field tail)
  simp only [Cantor.unpair_pair] at r₃
  exact Eval.seq_normal (Eval.seq_normal r₁ r₂) r₃

theorem twoReads_placement : Embedded actual twoReads 10 38 [] [] :=
  embedded_of_matches _ _ _ (by decide)

theorem outer_read_fields (n t stack c a b selector field tail : Nat) :
    Moves (atFrame 10 ⟨n,t,stack,c,a,b,pair selector (pair field tail)⟩)
      (atFrame 38 ⟨n,t,stack,c+selector,a+field,b,tail⟩) :=
  move_compiled (twoReads_spec n t stack c a b selector field tail) twoReads_placement

def refillBlock : Code := .seq (.inc 0) (.seq (copyCode 0 7 6) NF192.Emitter.Literal.seq203)

theorem refillBlock_spec (n t stack c a b : Nat) :
    Eval refillBlock (mk9 n t stack c a b 0 0 0) .normal
      (mk9 (n+1) t stack c a b 0 (n+1) 0) := by
  have inc : Eval (.inc 0) (mk9 n t stack c a b 0 0 0) .normal
      (mk9 (n+1) t stack c a b 0 0 0) := by
    simpa only [Registers.add, mk9_get_0, mk9_set_0] using Eval.inc 0 (mk9 n t stack c a b 0 0 0)
  have cp : Eval (copyCode 0 7 6) (mk9 (n+1) t stack c a b 0 0 0) .normal
      (mk9 0 t stack c a b (n+1) (n+1) 0) := by
    simpa [Registers.add] using copy_eval 0 7 6 (by decide) (by decide) (mk9 (n+1) t stack c a b 0 0 0)
  have rest := seq203_eval 0 t stack c a b (n+1) (n+1) 0
  simp only [Nat.zero_add] at rest
  exact Eval.seq_normal inc (Eval.seq_normal cp rest)

theorem refill_placement : Embedded actual refillBlock 2 10 [] [] :=
  embedded_of_matches _ _ _ (by decide)

theorem carried_reads (n t stack c a b k : Nat) :
    Eval twoReads (mk9 n t stack c a b 0 k 0) .normal
      (mk9 n t stack c (a+(Cantor.unpair k).1) b 0 0 (Cantor.unpair k).2) := by
  have h0 := seq115_eval n t stack c a b 0 k 0
  simp only [Nat.add_zero,Cantor.unpair_pair] at h0
  have h1 := seq209_eval n t stack c a b 0 k 0
  have h2 := seq201_eval n t stack c a b 0 0 k
  simp only [Nat.zero_add,Nat.add_zero] at h1 h2
  exact Eval.seq_normal (Eval.seq_normal (Eval.seq_normal h0 h1) h2) (seq175_normal n t stack c a b k)

theorem row0_cmd : R7Raw.program 0 = Source.Command.dec 8 2 1 false := by decide
theorem row1_cmd : R7Raw.program 1 = Source.Command.jump 10 := by decide
theorem row38_cmd : R7Raw.program 38 = Source.Command.dec 3 3596 39 false := by decide
theorem row39_cmd : R7Raw.program 39 = Source.Command.dec 3 3522 40 false := by decide
theorem row3521_cmd : R7Raw.program 3521 = Source.Command.jump 39 := by decide

theorem jump_at (pc n : Nat) (f : Frame) (h : R7Raw.program pc = Source.Command.jump n) :
    Moves (atFrame pc f) (atFrame n f) := by
  apply Moves.one
  change Source.execute (R7Raw.program pc) _ = _
  rw [h]
  rfl

theorem outer_fresh (n t stack c a b : Nat) :
    Moves (atFrame 0 ⟨n,t,stack,c,a,b,0⟩)
      (atFrame 38 ⟨n+1,t,stack,c,a+(Cantor.unpair (n+1)).1,b,(Cantor.unpair (n+1)).2⟩) := by
  have h := move_compiled (refillBlock_spec n t stack c a b) refill_placement
  have g := move_compiled (carried_reads (n+1) t stack c a b (n+1)) twoReads_placement
  apply Moves.trans _ (h.trans g)
  apply Moves.one
  simp only [atFrame,R7Raw.step,row0_cmd]; rfl

theorem outer_continued (n t stack c a b p : Nat) :
    Moves (atFrame 0 ⟨n,t,stack,c,a,b,p+1⟩) (atFrame 10 ⟨n,t,stack,c,a,b,p⟩) := by
  apply Moves.trans _ (jump_at 1 10 _ row1_cmd)
  apply Moves.one
  simp only [atFrame, R7Raw.step, row0_cmd]
  change Source.Config.active 1 (Source.setReg (liftRegisters (mk9 n t stack c a b 0 0 (p+1))) 8 p) = _
  exact congrArg (Source.Config.active 1) ((liftRegisters_set _ (8 : Register) p).trans
    (congrArg liftRegisters (mk9_set_8 n t stack c a b 0 0 (p+1) p)))

theorem dispatch_mp (n t stack a b p : Nat) :
    Moves (atFrame 38 ⟨n,t,stack,0,a,b,p⟩) (atFrame 3596 ⟨n,t,stack,0,a,b,p⟩) := by
  apply Moves.one
  simp only [atFrame, R7Raw.step, row38_cmd]
  rfl

theorem dispatch_positive (n t stack c a b p : Nat) :
    Moves (atFrame 38 ⟨n,t,stack,c+1,a,b,p⟩) (atFrame 39 ⟨n,t,stack,c,a,b,p⟩) := by
  apply Moves.one
  simp only [atFrame, R7Raw.step, row38_cmd]
  change Source.Config.active 39 (Source.setReg (liftRegisters (mk9 n t stack (c+1) a b 0 0 p)) 3 c) = _
  exact congrArg (Source.Config.active 39) ((liftRegisters_set _ (3 : Register) c).trans
    (congrArg liftRegisters (mk9_set_3 n t stack (c+1) a b 0 0 p c)))

theorem mode_entry (n t stack a b p : Nat) :
    Moves (atFrame 39 ⟨n,t,stack,0,a,b,p⟩) (atFrame 3522 ⟨n,t,stack,0,a,b,p⟩) := by
  apply Moves.one
  simp only [atFrame, R7Raw.step, row39_cmd]
  rfl

theorem ax_entry (n t stack c a b p : Nat) :
    Moves (atFrame 39 ⟨n,t,stack,c+1,a,b,p⟩) (atFrame 40 ⟨n,t,stack,c,a,b,p⟩) := by
  apply Moves.one
  simp only [atFrame, R7Raw.step, row39_cmd]
  change Source.Config.active 40 (Source.setReg (liftRegisters (mk9 n t stack (c+1) a b 0 0 p)) 3 c) = _
  exact congrArg (Source.Config.active 40) ((liftRegisters_set _ (3 : Register) c).trans
    (congrArg liftRegisters (mk9_set_3 n t stack (c+1) a b 0 0 p c)))

end NF180Counting.GuardedLogic.R7Register
#print axioms NF180Counting.GuardedLogic.R7Register.outer_fresh
#print axioms NF180Counting.GuardedLogic.R7Register.outer_read_fields
#print axioms NF180Counting.GuardedLogic.R7Register.ax_program_of_embedding
