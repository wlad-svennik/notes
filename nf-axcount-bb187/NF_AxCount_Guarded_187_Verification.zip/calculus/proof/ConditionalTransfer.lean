import ConditionalRegister
import ConditionalScanner
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace NF180Counting.GuardedLogic.R7Register
open NF180Counting.GuardedLogic NF192 NF192.Numerical NF192.Emitter NF192.SourceFields
open NF192.ProofSearch (Command pack)
def boundary (s : StreamState) : Source.Config :=
  frame 0 (s.next-1) s.proof.top (pack s.proof.stack) 0 s.proof.param s.proof.cache 0 0 s.cursor

def embed : Option StreamState → Source.Config
  | none => Source.Config.halted
  | some s => boundary s

def Valid : Option StreamState → Prop
  | none => True
  | some s => 0 < s.next

theorem valid_step (s : StreamState) (hs : 0 < s.next) : Valid (NF180Counting.GuardedScanner.step s) := by
  rcases s with ⟨n,k,e⟩
  cases k with
  | zero =>
    rw [NF180Counting.GuardedScanner.fresh,NF180Counting.GuardedScanner.continued]
    cases one _ e <;> simp [Valid]
  | succ k =>
    rw [NF180Counting.GuardedScanner.continued]
    cases one _ e <;> simp [Valid] <;> exact hs

theorem halted_absorbing (ticks : Nat) : R7Raw.advance ticks Source.Config.halted = Source.Config.halted := by
  induction ticks with
  | zero => rfl
  | succ k ih => exact ih

/-- Every source command has positive duration on both checked outcomes. -/
def StepSimulation : Prop :=
  ∀ s : StreamState, 0 < s.next → Visits (boundary s) (embed (NF180Counting.GuardedScanner.step s))

theorem realize_run (oneCmd : StepSimulation) (k : Nat) (s : StreamState) (hs : 0 < s.next) :
    ∃ ticks, k ≤ ticks ∧ R7Raw.advance ticks (boundary s) = embed (NF180Counting.GuardedScanner.run k s) := by
  induction k generalizing s with
  | zero => exact ⟨0,Nat.le_refl 0,rfl⟩
  | succ k ih =>
    obtain ⟨ticks,pos,hr⟩ := oneCmd s hs
    cases he : NF180Counting.GuardedScanner.step s with
    | none =>
      rw [he] at hr
      refine ⟨ticks+k, by omega, ?_⟩
      rw [R7Raw.advance_add, hr]
      exact halted_absorbing k
        |>.trans (by simp only [NF180Counting.GuardedScanner.run, he, Option.bind_none]; rfl)
    | some t =>
      have ht : 0 < t.next := by
        have := valid_step _ hs
        simpa only [he, Valid] using this
      obtain ⟨tail, htail, hres⟩ := ih t ht
      refine ⟨ticks+tail, by omega, ?_⟩
      rw [R7Raw.advance_add, hr, he]
      simpa only [NF180Counting.GuardedScanner.run, he, Option.bind_some, embed] using hres

/-- The converse covers a halt at an arbitrary instruction tick. Reaching at
least that many literal ticks forces the abstract command execution to have
observed the absorbing halt too. -/
theorem source_halts_iff_stream (oneCmd : StepSimulation) (s : StreamState) (hs : 0 < s.next) :
    (∃ ticks, R7Raw.advance ticks (boundary s) = Source.Config.halted) ↔
    (∃ k, NF180Counting.GuardedScanner.run k s = none) := by
  constructor
  · rintro ⟨ticks,halt⟩
    obtain ⟨dt,hle,hr⟩ := realize_run oneCmd ticks s hs
    have large : R7Raw.advance dt (boundary s) = Source.Config.halted := by
      rw [show dt = ticks+(dt-ticks) by omega, R7Raw.advance_add, halt, halted_absorbing]
    rw [large] at hr
    refine ⟨ticks,?_⟩
    cases he : NF180Counting.GuardedScanner.run ticks s with
    | none => rfl
    | some out =>
      rw [he] at hr
      cases hr
  · rintro ⟨k,hk⟩
    obtain ⟨ticks,_,hr⟩ := realize_run oneCmd k s hs
    exact ⟨ticks,by simpa only [hk,embed] using hr⟩


theorem parse_forced (x : Nat) : parse (pair 0 x) = (.mp (Cantor.unpair x).1, (Cantor.unpair x).2) := by
  obtain ⟨u,v,h⟩ := show ∃ u v, x = pair u v from ⟨_,_,(Cantor.pair_unpair x).symm⟩
  subst x
  simp only [Cantor.unpair_pair]
  exact parse_assemble (.mp u) v

theorem after_as_boundary (n k : Nat) (res : Option State) :
    after n k res = embed (res.map (fun t => (⟨n+1,k,t⟩ : StreamState))) := by cases res <;> rfl

theorem literal_step : StepSimulation := by
  rintro ⟨next,k,s⟩ hn
  cases next with
  | zero => contradiction
  | succ n =>
    cases k with
    | zero =>
      rw [NF180Counting.GuardedScanner.fresh,NF180Counting.GuardedScanner.continued,parse_forced]
      exact (after_as_boundary _ _ _) ▸ command_fresh n s
    | succ k =>
      rw [NF180Counting.GuardedScanner.continued]
      exact (after_as_boundary _ _ _) ▸ command_continued n k s

theorem halts_iff_goal (n : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, R7Raw.advance ticks (atFrame 0 (registers n 0 s)) = Source.Config.halted) ↔ NF180Counting.GuardedLogic.Deriv goal :=
  (source_halts_iff_stream literal_step ⟨n+1,0,s⟩ (Nat.zero_lt_succ n)).trans (NF180Counting.GuardedScanner.halts_iff_goal (n+1) s hs)

def initialProof : State := ⟨0, [], 0, 0⟩

theorem initialProof_sound : initialProof.Sound := by
  exact ⟨deriv_zero, by simp [initialProof], deriv_zero⟩

theorem from_physical_seed :
    (∃ ticks, R7Raw.advance ticks (atFrame 0 (registers 4 0 initialProof)) = Source.Config.halted) ↔ NF180Counting.GuardedLogic.Deriv goal :=
  halts_iff_goal 4 _ initialProof_sound

end NF180Counting.GuardedLogic.R7Register
#print axioms NF180Counting.GuardedLogic.R7Register.halts_iff_goal
#print axioms NF180Counting.GuardedLogic.R7Register.from_physical_seed
