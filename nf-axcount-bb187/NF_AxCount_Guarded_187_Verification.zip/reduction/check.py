"""Replay the final two state merges from the 189-state guarded predecessor."""
import json
from pathlib import Path

here = Path(__file__).resolve().parent

def matrix(path):
    header, *lines = path.read_text().splitlines()
    table = {}
    for line in lines:
        state, bit, write, direction, target = line.split()
        key = (state, bit)
        if key in table:
            raise ValueError(f'Duplicate row {key}')
        table[key] = [write, direction, target]
    return header, table

start, old = matrix(here / 'guarded189.tm')
goal_start, goal = matrix(here.parent / 'NF_AxCount_Guarded_187.tm')
assert start == goal_start and len(old) == 378
for edit in json.loads((here / '189-to-187.json').read_bytes()):
    key = tuple(edit['row'])
    if old.get(key) != edit['old']:
        raise ValueError(f'Wrong predecessor row {key}')
    if edit['new'] is None:
        del old[key]
    else:
        old[key] = edit['new']
assert old == goal and len(goal) == 374
print('The two decoder merges reproduce the complete 187-state table.')
