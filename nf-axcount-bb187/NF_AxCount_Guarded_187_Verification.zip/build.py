"""Reconstitute the guarded machine and its register instructions from NF180."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
def main():
    target=Path(sys.argv[1]);target.mkdir(exist_ok=True,parents=True)
    meta=json.loads((HERE/'machine.json').read_bytes())
    with ZipFile(HERE/'upstream/NF180_verification.zip')as z:
        raw=z.read('NF180.tm')
        assert hashlib.sha256(raw).hexdigest()=='6540567cb4bef6be14fce422a409338be21afeea73a1a6de856352f03b201a03'
        old=json.loads(z.read('source.sites.json'))
    _,*rows=raw.decode().splitlines()
    edges={(q,int(b)):(w,d,z)for q,b,w,d,z in map(str.split,rows)}
    diff=json.loads((HERE/'decoder-edits.json').read_bytes())
    for q in diff['removed']:
        for bit in (0,1):del edges[q,bit]
    for q,bit,w,m,z in diff['transitions']:edges[q,bit]=(w,m,z)
    table='#! start k:74\n'+''.join(f'{q} {b} {w} {d} {z}\n'for (q,b),(w,d,z)in sorted(edges.items()))
    assert hashlib.sha256(table.encode()).hexdigest()==meta['table']
    (target/'candidate.tm').write_text(table)
    row=json.loads((HERE/'calculus/row.json').read_bytes())
    payload=[]
    for token in row['word']:
        lo,hi=row['representatives'][token]
        payload.extend(old[lo:hi])
    loc=row['old_instruction_offset'];cmd=old[:loc]+payload+old[loc:]
    addresses=json.loads((HERE/'addresses.json').read_bytes())
    assert len(addresses)==len(cmd)==3642
    source=json.dumps([[addr,o,k]for addr,(_,o,k)in zip(addresses,cmd)],separators=(',',':')).encode()
    assert hashlib.sha256(source).hexdigest()==meta['source']
    (target/'source.sites.json').write_bytes(source)
if __name__=='__main__':main()
