"""Regenerate the 57 proof batches, run the Lean reference kernel and check each theorem type.

Run with the path to the unpacked original release as the positional argument.
By default only one large proof file is retained at a time per worker.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("release", type=Path)
    parser.add_argument("--interval-start", type=int, help="Recheck only the batch beginning at this instruction")
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--keep", type=Path, help="Keep the rebuilt export files in this directory")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs needs a positive integer")
    release = args.release.resolve()
    checker = shutil.which("leanchecker-paranoid")
    if checker is None:
        parser.error("Lean 4.35.0 leanchecker-paranoid is required on PATH")
    intervals = json.loads((release / "receipts/kernel.json").read_text())["intervals"]
    if args.interval_start is not None:
        intervals = [interval for interval in intervals if interval["first_pc"] == args.interval_start]
        if not intervals:
            parser.error("No archived batch begins at that instruction")
    here = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        machine = work / "machine"
        subprocess.run([sys.executable, release / "build.py", machine], check=True)
        target = (args.keep or work / "exports").resolve()
        target.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ, NF_TABLE=str(machine / "candidate.tm"),
                   NF_TRACES=str(release / "receipts/traces.json.gz"))

        def check(interval):
            lo, hi = interval["first_pc"], interval["past_last_pc"]
            path = target / f"{lo}-{hi}.ndjson"
            with tempfile.TemporaryDirectory(dir=target) as one:
                proof = Path(one) / path.name
                subprocess.run([sys.executable, release / "physical/kernel_branches.py", machine,
                                proof, "--lo", str(lo), "--hi", str(hi)], env=env, check=True)
                if hashlib.sha256(proof.read_bytes()).hexdigest() != interval["export_sha256"]:
                    raise ValueError(f"Unmatched export hash at instructions {lo}..{hi}")
                run = subprocess.run([checker, "--from-export", proof], capture_output=True,
                                     text=True, check=True)
                if (run.stdout + run.stderr).strip() != interval["kernel"]:
                    raise ValueError(f"Unexpected kernel result at instructions {lo}..{hi}")
                subprocess.run([sys.executable, here / "check_export_types.py", release, proof],
                               check=True)
                if args.keep:
                    proof.replace(path)
            return interval["branches"]

        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            total = sum(pool.map(check, intervals))
        print(f"{len(intervals)} kernel batches accepted, {total} statement types matched")


if __name__ == "__main__":
    main()
