"""Compare actual Lean export theorem statements with the released literal program and table.

Usage: python3 check_export_types.py UNPACKED_RELEASE EXPORT_1.ndjson [EXPORT_2.ndjson ...]
The raw exports are emitted by physical/kernel_branches.py. This structural reader uses
only the Python standard library and does not import the physical proof generator.
"""
import argparse
import gzip
import hashlib
import json
from itertools import chain
from pathlib import Path

NS = "NFSearchSweep."
ORDER = (2, 8, 1, 4, 3, 7, 0, 5, 6)
PADDING = 64


class Export:
    def __init__(self, path, prelude):
        self.names = {0: ""}
        self.terms = {}
        self.defs = {}
        self.theorems = {}
        self.digest = hashlib.sha256()
        with path.open("rb") as stream:
            prefix = stream.read(len(prelude))
            assert prefix == prelude, "Unexpected kernel prelude"
            prelude_lines = len(prelude.splitlines())
            for i, line in enumerate(chain(prelude.splitlines(keepends=True), stream)):
                self.digest.update(line)
                row = json.loads(line)
                if i >= prelude_lines:
                    assert set(row).intersection({"in", "ie", "def", "thm"}), "Unexpected declaration after Eq/Nat"
                if "in" in row:
                    obj = row.get("str", row.get("num"))
                    prefix = self.names[obj["pre"]]
                    part = str(obj.get("str", obj.get("i")))
                    self.names[row["in"]] = (prefix + "." if prefix else "") + part
                elif "ie" in row:
                    idx = row.pop("ie")
                    tag, value = next(iter(row.items()))
                    if tag == "app":
                        value = (value["fn"], value["arg"])
                    elif tag in ("lam", "forallE"):
                        value = (self.names[value["name"]], value["type"], value["body"])
                    elif tag == "const":
                        value = self.names[value["name"]]
                    elif tag == "natVal":
                        value = int(value)
                    self.terms[idx] = (tag, value)
                elif "def" in row or "thm" in row:
                    d = row.get("def", row.get("thm"))
                    name = self.names[d["name"]]
                    if name.startswith(NS + "table") or name in {NS+"plus", NS+"clock", NS+"step"}:
                        self.defs[name] = d["value"]
                    elif name.startswith(NS + "branch_"):
                        self.theorems[name] = d["type"]

    def value(self, idx, expected_tag):
        tag, value = self.terms[idx]
        assert tag == expected_tag, (idx, expected_tag, tag)
        return value

    def spine(self, idx):
        args = []
        while self.terms[idx][0] == "app":
            idx, arg = self.value(idx, "app")
            args.append(arg)
        return self.value(idx, "const"), args[::-1]

    def args(self, idx, expected_name, count):
        name, args = self.spine(idx)
        assert name == expected_name and len(args) == count, (name, len(args), expected_name, count)
        return args

    def body(self, idx, tag="lam"):
        return self.value(idx, tag)[2]

    def is_nat(self, idx):
        return self.terms[idx] == ("const", "Nat")

    def is_ray(self, idx):
        _, domain, codomain = self.value(idx, "forallE")
        return self.is_nat(domain) and self.is_nat(codomain)

    def check_arithmetic_and_dispatch(self):
        # plus(a,b) iterates successor b times from a.
        # clock(k,n) iterates addition of k n times from zero.
        for name in ("plus", "clock"):
            core = self.body(self.body(self.defs[NS + name]))
            motive, base, succ, count = self.args(core, "Nat.rec", 4)
            assert self.is_nat(self.body(motive)) and self.value(count, "bvar") == 0
            action = self.body(self.body(succ))
            if name == "plus":
                assert self.value(base, "bvar") == 1
                result, = self.args(action, "Nat.succ", 1)
                assert self.value(result, "bvar") == 0
            else:
                assert self.value(base, "natVal") == 0
                weight, subtotal = self.args(action, NS + "plus", 2)
                assert [self.value(i, "bvar") for i in (weight, subtotal)] == [3, 0]
        # State, scanned bit and orientation occupy slots 0, 2 and 1.
        # The last two arguments are the entire forward and rear rays.
        args = self.args(self.body(self.defs[NS+"step"]), NS+"table0", 5)
        for term, indices in zip(args, ((0,0), (2,0), (1,0), (2,), (3,))):
            for index in reversed(indices):
                term, arg = self.value(term, "app")
                assert self.value(arg, "natVal") == index
            assert self.value(term, "bvar") == 0

    def check_table(self, rows):
        for q, pair in enumerate(rows):
            dispatch = self.body(self.defs[NS + "table" + str(q)])
            _, zero, succ, state = self.args(dispatch, "Nat.rec", 4)
            assert self.value(state, "bvar") == 0
            index = self.args(self.body(self.body(succ)), NS + "table" + str(q + 1), 1)
            assert self.value(index[0], "bvar") == 1
            _, bit, a, b = self.args(self.body(zero), NS + "chooseZero", 4)
            assert self.value(bit, "bvar") == 0
            for row, term in zip(pair, (a, b)):
                assert tuple(self.value(i, "natVal") for i in self.args(term, NS + "applyRow", 3)) == row
        terminal = self.defs[NS + "table" + str(len(rows))]
        for _ in range(5):
            terminal = self.body(terminal)
        q, d, a, b = self.args(terminal, NS + "cfg", 4)
        assert self.value(q, "natVal") == len(rows)
        assert [self.value(i, "bvar") for i in (d, a, b)] == [2, 1, 0]

    def ray(self, idx):
        """Nearest-first literal bits, symbolic word powers, and the open tail."""
        out = []
        while self.terms[idx][0] != "bvar":
            name, args = self.spine(idx)
            if name == NS + "push":
                bit, idx = args
                value = self.value(bit, "natVal")
                assert value in (0, 1)
                out.append(str(value))
            else:
                assert name == NS + "iterate"
                ty, fun, count, idx = args
                assert self.is_ray(ty)
                value = self.body(fun)
                unit = []
                while self.terms[value][0] != "bvar":
                    bit, value = self.args(value, NS + "push", 2)
                    unit.append(str(self.value(bit, "natVal")))
                assert self.value(value, "bvar") == 0 and unit
                out.append(("".join(unit), 12 - self.value(count, "bvar")))
        return out, self.value(idx, "bvar")

    def clock(self, idx):
        """Constant term followed by coefficients of the 11 natural-number parameters."""
        total = [0] * 12
        todo = [idx]
        while todo:
            term = todo.pop()
            if self.terms[term][0] == "natVal":
                total[0] += self.value(term, "natVal")
                continue
            name, args = self.spine(term)
            if name == NS + "plus":
                assert len(args) == 2
                todo.extend(args)
            else:
                assert name == NS + "clock" and len(args) == 2
                i = 12 - self.value(args[1], "bvar")
                assert 0 <= i < 11
                total[1+i] += self.value(args[0], "natVal")
        return total


def prefix_spans(sites):
    spans = {}
    for pc, (path, _, _) in enumerate(sites):
        for n in range(len(path)+1):
            prefix = path[:n]
            first, past = spans.get(prefix, (pc, pc))
            assert past == pc
            spans[prefix] = first, pc+1
    return spans


def successor(sites, spans, pc, zero):
    path, op, arg = sites[pc]
    if op == "CD" and zero and path.endswith("1"):
        return None, False
    climbs = arg if op in ("CC", "CB") else int(op == "CD" and zero)
    side = "1" if op == "CC" else "0"
    for _ in range(climbs):
        path = path[:path.rindex(side)]
    first, past = spans[path]
    if op == "CC":
        return first, False
    return past % len(sites), past == len(sites)


def expected_rays(path, registers, extra_gap, extra_spares, shift, increment):
    # There are 51+x9 address cells and 24+x10 spare fields in the initial frame.
    # Split the fixed zeros and pairs at the positions used to bind each exponent.
    ahead = list(path + "0" * (51+extra_gap-len(path)-5)) + [("0", 9)] + list("000001")
    for r in ORDER:
        fixed, variable = registers[r]
        ahead += list("0" + "1" * (fixed-1))
        if variable:
            ahead.append(("1", r))
        ahead.append("1")
    ahead += list("01"*12) + [("01", 10)] + list("01"*(12+extra_spares))
    ahead += list("0"*(PADDING-3*increment))
    behind = list("1"+"0"*(PADDING-shift))
    return (ahead, 0), (behind, 1)


def check_frame(export, idx, root, expected):
    q, direction, a, b = export.args(idx, NS + "cfg", 4)
    assert export.value(q, "natVal") == root and export.value(direction, "natVal") == 0
    assert (export.ray(a), export.ray(b)) == expected


def check_branch(export, idx, key, sites, spans, root, halt, clocks):
    pc, cold, zero = key
    path, op, r = sites[pc]
    for j in range(13):
        binder, ty, idx = export.value(idx, "forallE")
        if j < 11:
            assert binder == "x"+str(j) and export.is_nat(ty)
        else:
            assert binder == ("leftRay" if j == 11 else "rightRay") and export.is_ray(ty)
    registers = [(2, True)] * 9  # fixed ones, followed by an optional unary variable
    if cold:
        registers[0] = (1, False)
    if op == "CD":
        assert not (cold and r == 0)
        registers[r] = (2, False) if zero else (3, True)
    dest, wrapped = successor(sites, spans, pc, zero)
    _, lhs, rhs = export.args(idx, "Eq", 3)
    if dest is None:
        # A terminal theorem projects the control of the resulting physical configuration.
        run_term, z2 = export.value(lhs, "app")
        run_term, z1 = export.value(run_term, "app")
        assert export.value(z1,"natVal") == export.value(z2,"natVal") == 0
        assert export.value(rhs, "natVal") == halt
    else:
        run_term, = export.args(lhs, NS + "norm", 1)
    _, step, time, initial = export.args(run_term, NS + "iterate", 4)
    assert export.value(step, "const") == NS + "step"
    actual_clock = export.clock(time)
    assert actual_clock == clocks[key] and actual_clock[0] > 0
    check_frame(export, initial, root, expected_rays(path, registers, 0, 0, 0, 0))
    if dest is not None:
        inc, dec = int(op == "CI"), int(op == "CD" and not zero)
        if inc or dec:
            fixed, variable = registers[r]
            registers[r] = fixed+inc-dec, variable
        out = expected_rays(sites[dest][0], registers, dec+int(wrapped), inc, int(wrapped), inc)
        check_frame(export, rhs, root, out)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("release", type=Path)
    parser.add_argument("exports", type=Path, nargs="+")
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError("Run with Python assertions enabled")
    release = args.release
    machine = (release / "NF_AxCount_Guarded_187.tm").read_bytes()
    source = (release / "source.sites.json").read_bytes()
    trace = (release / "receipts/traces.json.gz").read_bytes()
    rec = json.loads((release / "receipts/kernel.json").read_bytes())
    for data, key in ((machine, "table"), (source, "source"), (trace, "trace_sha256")):
        assert hashlib.sha256(data).hexdigest() == rec[key]
    rows = [line.split() for line in machine.decode().splitlines()[1:]]
    names = sorted({q for q, *_ in rows})
    ids = {q: i for i, q in enumerate(names+["halt"])}
    raw = {(q,int(b)): (ids[dest],int(w),int(d=="L")) for q,b,w,d,dest in rows}
    pairs = [[raw[q,bit] for bit in (0,1)] for q in names]
    sites = json.loads(source)
    spans = prefix_spans(sites)
    clocks = {(t["pc"],t["cold"],t["zero"]): t["clock"] for t in json.loads(gzip.decompress(trace))["traces"]}
    by_digest = {i["export_sha256"]:i for i in rec["intervals"]}
    prelude = (release / "physical/eq_nat_prelude.ndjson").read_bytes()
    assert hashlib.sha256(prelude).hexdigest() == "e5d422d25746ba5eb85d2cde01df2e6701c577881be08934fa38a362d342b0ac"
    seen = set()
    for path in args.exports:
        # This exact prefix also supplies the functions rendered and checked
        # against the ordinary tape by the supplemental Lean transport proof.
        with path.open("rb") as raw_export:
            prefix = raw_export.read(287754)
        assert hashlib.sha256(prefix).hexdigest() == "fa9c0d008ce8cff8c5427c787d3a74b40a173461f2e22c10c81f8d6b1a75bc1a"
        exp = Export(path, prelude)
        interval = by_digest[exp.digest.hexdigest()]
        exp.check_arithmetic_and_dispatch()
        exp.check_table(pairs)
        keys = set()
        for name, typ in exp.theorems.items():
            pc, cold, zero = map(int, name.removeprefix(NS+"branch_").split("_"))
            assert cold in (0,1) and zero in (0,1)
            key = (pc, bool(cold), bool(zero))
            try:
                check_branch(exp, typ, key, sites, spans, ids["d:0"], ids["halt"], clocks)
            except (AssertionError, KeyError, ValueError) as error:
                raise ValueError(f"{path.name}: {name}") from error
            keys.add(key)
        lo, hi = interval["first_pc"], interval["past_last_pc"]
        expected = {(pc,c,z) for pc in range(lo,hi) for c in (False,True)
                    if not (c and sites[pc][1:]==["CD",0])
                    for z in ((False,True) if sites[pc][1]=="CD" else (False,))}
        assert keys == expected and len(keys) == interval["branches"] and keys.isdisjoint(seen)
        seen.update(keys)
        print(f"{lo}..{hi}  {len(keys)} theorem types, clocks and all {2*len(pairs)} rows match",flush=True)
        del exp
    print(f"{len(seen)} checked theorem types across {len(args.exports)} export(s)",flush=True)


if __name__ == "__main__":
    main()
