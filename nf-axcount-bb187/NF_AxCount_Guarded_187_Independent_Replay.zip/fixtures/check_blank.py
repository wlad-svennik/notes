"""Check the released text table and replay both complete blank-tape checkpoints."""

import argparse
from collections import deque
import gzip
import hashlib
import json
from pathlib import Path


TABLE_SHA = '09aa41ff3962ce68e6050defa635071cc6b069029016b7cdd94ca35e74cda6db'
SOURCE_SHA = '8b40258cf8dde548d30f625804432d1c26c1668350a2a326e4c28e89837f1330'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_table(path):
    lines = iter(path.read_text().splitlines())
    tag, keyword, start = next(lines).split()
    assert (tag, keyword) == ('#!', 'start')
    table = {}
    for row in lines:
        q, b, w, direction, target = row.split()
        assert q != 'halt' and b in ('0', '1') and w in ('0', '1')
        assert direction in ('L', 'R') and (q, int(b)) not in table
        table[q, int(b)] = int(w), (-1 if direction == 'L' else 1), target
    states = {q for q, b in table}
    assert set(table) == {(q, b) for q in states for b in (0, 1)}
    assert all(z in states or z == 'halt' for w, move, z in table.values())
    return start, table, states


def distances(start, table):
    seen = {start: 0}
    todo = deque([start])
    while todo:
        state = todo.popleft()
        if state == 'halt':
            continue
        for bit in (0, 1):
            following = table[state, bit][2]
            if following not in seen:
                seen[following] = seen[state] + 1
                todo.append(following)
    return seen


def frame_ones(address, r0, head, gap, spares):
    ones = {head - 1, head + gap}
    ones.update(head + i for i, bit in enumerate(address) if bit == '1')
    cell = head + gap + 2
    for register in (2, 8, 1, 4, 3, 7, 0, 5, 6):
        width = 2 + (r0 if register == 0 else 0)
        ones.update(range(cell, cell + width))
        cell += width + 1
    for _ in range(spares):
        ones.add(cell)
        cell += 2
    return ones


def check(packet, output):
    table_file = packet / 'NF_AxCount_Guarded_187.tm'
    source_file = packet / 'source.sites.json'
    assert sha(table_file) == TABLE_SHA and sha(source_file) == SOURCE_SHA
    start, table, states = parse_table(table_file)
    distance = distances(start, table)
    assert set(distance) == states | {'halt'}
    halt_rows = [(q, b, w, d) for (q, b), (w, d, z) in table.items() if z == 'halt']
    sites = json.loads(source_file.read_bytes())
    assert len({path for path, op, reg in sites}) == len(sites)
    checkpoints = {41865: (2, -5, 35, 18), 233240: (5, -10, 97, 78)}
    ones, rows_seen, states_seen = set(), set(), {start}
    lo = hi = head = 0
    q, frames = start, []
    for tick in range(1, max(checkpoints) + 1):
        bit = int(head in ones)
        rows_seen.add((q, bit))
        write, move, q = table[q, bit]
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        head += move
        lo, hi = min(lo, head), max(hi, head)
        assert q != 'halt'
        states_seen.add(q)
        if tick in checkpoints:
            r0, expected_head, gap, spares = checkpoints[tick]
            assert (q, head) == ('d:0', expected_head)
            assert ones == frame_ones(sites[0][0], r0, head, gap, spares)
            frames.append({'tick': tick, 'state': q, 'head': head, 'gap': gap,
                           'spares': spares, 'R0': r0, 'ones': len(ones),
                           'min_one': min(ones), 'max_one': max(ones)})
    result = {'table_sha256': TABLE_SHA, 'source_sha256': SOURCE_SHA,
              'commands': len(sites), 'working_states': len(states), 'rows': len(table),
              'graph_reachable_working': len(distance) - 1, 'start': start,
              'halt_rows': halt_rows, 'shortest_control_graph_halt_distance': distance['halt'],
              'max_working_control_graph_distance': max(n for q, n in distance.items() if q != 'halt'),
              'blank_visited_working_states_to_last_cut': len(states_seen),
              'blank_head_extent': [lo, hi], 'complete_blank_frames': frames}
    output.mkdir(exist_ok=True, parents=True)
    (output / 'independent-topology-blank.json').write_text(json.dumps(result, indent=2) + '\n')
    (output / 'sites.txt').write_text(''.join(f'{p} {op} {r}\n' for p, op, r in sites))
    (output / 'blank-visited-rows.txt').write_text(''.join(f'{q} {b}\n' for q, b in sorted(rows_seen)))
    traces = json.loads(gzip.decompress((packet / 'receipts/traces.json.gz').read_bytes()))
    assert traces['table'] == TABLE_SHA and traces['source'] == SOURCE_SHA and traces['base_gap'] == 51
    rows = ([t['pc'], int(t['cold']), int(t['zero']), *t['clock']] for t in traces['traces'])
    (output / 'clock-data.txt').write_text(''.join(' '.join(map(str, row)) + '\n' for row in rows))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('packet', type=Path, help='extracted original verification archive')
    parser.add_argument('output', type=Path, help='work directory for replay outputs')
    args = parser.parse_args()
    check(args.packet, args.output)
