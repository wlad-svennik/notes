#include <array>
#include <bitset>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <set>
#include <vector>
#include <algorithm>

using namespace std;
struct Edge {bool write; int move; int next;};
struct Site {string path,op; int arg;};
struct Frame {int h,header,pc,spares; array<int,9> reg;};
using Tape=bitset<8192>;
int at(int x){if(x < -4096 || x >= 4096)throw runtime_error("fixture extent");return x+4096;}
Tape encode(const vector<Site> &sites,const Frame &f){
    Tape out;out.set(at(f.h-1));
    const string &path=sites.at(f.pc).path;
    for(size_t i=0;i<path.size();++i)if(path[i]=='1')out.set(at(f.h+int(i)));
    int x=f.header;out.set(at(x));x+=2;
    for(int r:{2,8,1,4,3,7,0,5,6}){
        for(int j=0;j<f.reg[r]+2;++j)out.set(at(x++));
        ++x;
    }
    for(int i=0;i<f.spares;++i,x+=2)out.set(at(x));
    return out;
}
// Interpret an ordered prefix-tree node as a half-open interval of leaf ordinals.
// The entry of a subtree is its leftmost leaf. Its fallthrough is the first leaf after it.
struct Span {int first,past;};
int main(int argc,char **argv){
  try {
    if(argc!=5)throw runtime_error("table, sites, clock data and blank visited rows required");
    ifstream table(argv[1]), program(argv[2]);
    string token, start, src, dest, move;
    table>>token>>token>>start;
    map<string,int> ids{{"halt",0}};
    auto id=[&](const string&s){auto it=ids.find(s);if(it==ids.end())it=ids.emplace(s,ids.size()).first;return it->second;};
    vector<array<Edge,2>> trans(188);int r,w;
    while(table>>src>>r>>w>>move>>dest)trans.at(id(src)).at(r)={bool(w),move=="R"?1:-1,id(dest)};
    if(ids.size()!=188 || !ids.count("d:0"))throw runtime_error("literal parse");
    ifstream clocksFile(argv[3]),blankRows(argv[4]);
    map<array<int,3>,array<int,12>> clocks;
    int pcKey,coldKey,zeroKey;
    while(clocksFile>>pcKey>>coldKey>>zeroKey){
      array<int,12> coeff;for(int &n:coeff)if(!(clocksFile>>n))throw runtime_error("clock length");
      if(!clocks.emplace(array<int,3>{pcKey,coldKey,zeroKey},coeff).second)throw runtime_error("duplicate clock");
    }
    array<array<bool,2>,188> used{},boot{};
    while(blankRows>>src>>r)boot.at(ids.at(src)).at(r)=true;
    int d0=ids.at("d:0");vector<Site> sites;Site site;
    map<string,Span> nodes;
    while(program>>site.path>>site.op>>site.arg){
        int i=sites.size();if(i && sites.back().path>=site.path)throw runtime_error("unordered source");sites.push_back(site);
        for(size_t k=0;k<=site.path.size();++k){auto inserted=nodes.emplace(site.path.substr(0,k),Span{i,i+1});inserted.first->second.past=i+1;}
    }
    if(sites.size()!=3642)throw runtime_error("source count");
    int keys=0,live=0,halts=0,warmKeys=0,coldKeys=0,longest=0;int64_t steps=0;
    int haltPc=-1;setbuf(stdout,nullptr);
    for(int pc=0;pc<int(sites.size());++pc){
        const auto &s=sites[pc];
        for(int cold=0;cold<2;++cold){
          if(cold && s.op=="CD" && s.arg==0)continue;
          for(int zero=0;zero<1+(s.op=="CD");++zero){
            ++keys;cold?++coldKeys:++warmKeys;
            for(int fixture=0;fixture<4;++fixture){
                const array<int,4> origins{-700,-2,159,400},gaps{51,73,112,163},spares{24,30,61,85};
                Frame f{origins[fixture],origins[fixture]+gaps[fixture],pc,spares[fixture],{}};
                for(int j=0;j<9;++j){
                    if(fixture==1 && j==(pc%9))f.reg[j]=94;
                    if(fixture==2)f.reg[j]=(pc+3*j+11)%31;
                    if(fixture==3)f.reg[j]=(53*pc+43*j+5)%68;
                }
                if(cold)f.reg[0]=-1;
                if(s.op=="CD")f.reg[s.arg]=zero?0:(fixture==0?1:fixture*17+pc%7);
                const auto& clock=clocks.at({pc,cold,zero});
                int predicted=clock[0]+(gaps[fixture]-51)*clock[10]+(spares[fixture]-24)*clock[11];
                for(int reg=0;reg<9;++reg){
                    int exponent=max(0,f.reg[reg]);
                    if(s.op=="CD" && !zero && reg==s.arg)--exponent;
                    predicted+=exponent*clock[reg+1];
                }
                int h=f.h,q=d0;
                Tape tape=encode(sites,f);
                bool terminal=s.op=="CD" && zero && s.path.back()=='1';
                Span target=nodes.at(s.path);
                if(!terminal){
                    char direction='?';int levels=0;
                    if(s.op=="CI"){++f.reg[s.arg];++f.spares;}
                    else if(s.op=="CD"){
                      if(zero){direction='0';levels=1;}else{--f.reg[s.arg];++f.header;}
                    }else if(s.op=="CB" || s.op=="CC"){direction=s.op=="CB"?'0':'1';levels=s.arg;}
                    else throw runtime_error("unknown command");
                    if(levels){
                      int i=int(s.path.size());while(levels){if(--i<0)throw runtime_error("bad tree ascent");if(s.path[i]==direction)--levels;}
                      target=nodes.at(s.path.substr(0,i));
                    }
                    if(s.op=="CC")f.pc=target.first;
                    else if(target.past==int(sites.size())){f.pc=0;--f.h;}
                    else f.pc=target.past;
                }
                Tape expected=terminal?Tape{}:encode(sites,f);
                int t=0;
                do{
                  ++t;bool read=tape[at(h)];used[q][read]=true;auto edge=trans.at(q).at(read);tape.set(at(h),edge.write);h+=edge.move;q=edge.next;
                  if(!q){if(!terminal)throw runtime_error("premature halt");++halts;if(haltPc!=-1 && haltPc!=pc)throw runtime_error("multiple halt sites");haltPc=pc;break;}
                  if(!terminal && q==d0 && h==f.h && tape==expected){++live;break;}
                  if(t==100000)throw runtime_error("missing endpoint PC="+to_string(pc)+" cold="+to_string(cold)+" zero="+to_string(zero)+" fixture="+to_string(fixture));
                }while(true);
                if(t!=predicted)throw runtime_error("clock mismatch pc="+to_string(pc)+" measured="+to_string(t)+" claimed="+to_string(predicted));
                steps+=t;longest=max(longest,t);
            }
          }
        }
    }
    int fixtureControls=0,totalControls=0,fixtureRows=0,totalRows=0;
    for(int q=1;q<188;++q){
       bool hit=false,any=false;
       for(int bit=0;bit<2;++bit){hit=hit||used[q][bit];any=any||used[q][bit]||boot[q][bit];fixtureRows+=used[q][bit];totalRows+=used[q][bit]||boot[q][bit];}
       fixtureControls+=hit;totalControls+=any;
    }
    cout<<"{\"all_observed_clocks_match\":true,\"fixture_controls\":"<<fixtureControls<<",\"fixture_rows\":"<<fixtureRows<<",\"union_with_blank_controls\":"<<totalControls<<",\"union_with_blank_rows\":"<<totalRows<<",\"instruction_count\":"<<sites.size()<<",\"branch_keys\":"<<keys<<",\"warm_keys\":"<<warmKeys<<",\"cold_keys\":"<<coldKeys<<",\"variants_per_key\":4,\"complete_successors\":"<<live<<",\"halts\":"<<halts<<",\"halt_source_pc\":"<<haltPc<<",\"literal_steps\":"<<steps<<",\"max_steps\":"<<longest<<"}\n";
    if(keys!=9552 || live+halts!=4*keys || halts==0)return 2;
  }catch(const exception &e){cerr<<e.what()<<'\n';return 1;}
}
