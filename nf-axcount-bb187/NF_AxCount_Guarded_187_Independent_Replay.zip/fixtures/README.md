# Independent topology, blank tape and register-frame checks

Use Python 3.8 or newer and a C++17 compiler. Extract the original verification ZIP beside this directory as `packet/`, or set `packet` to its extracted root. Its SHA-256 is `5ee48c1dea054b2ea3694f034dde2e9a7d4934c8f33a13e857747f25fd418440`. Run these commands from the directory containing this README. Use Python with its default assertion checking enabled.

```sh
packet=../packet
python3 check_blank.py "$packet" replay
c++ -std=c++17 -O3 independent-fixtures.cpp -o replay/fixtures
replay/fixtures "$packet/NF_AxCount_Guarded_187.tm" replay/sites.txt replay/clock-data.txt replay/blank-visited-rows.txt > replay/independent-fixtures.json
cmp independent-topology-blank.json replay/independent-topology-blank.json
cmp independent-fixtures.json replay/independent-fixtures.json
```

The topology pass reads the literal text table, checks each bit transition, and searches its control graph. It counts 187 reachable working states, 374 rows, and one transition into the separate halt state. The simulator performs 233,240 primitive steps from the all-zero two-way tape. At ticks 41,865 and 233,240, it compares the complete set of nonzero cells, head and state against independently constructed register frames. The final frame is at PC 0, counter 5 and head −10, with gap 97 and 78 spare fields. The blank prefix visits 127 controls and 228 rows.

The C++ program interprets control transfers via the leaf intervals of the source prefix tree. Its separate binary interpreter uses the released `.tm` directly. For four data and gap assignments per signed branch it checks the *entire* expected successor tape and head, or the designated goal halt. It determines the successor time by executing to the matching boundary, then compares that measured time to the trace certificate’s affine clock. The tested branch domains comprise 4,777 warm and 4,775 cold cases; cold R0 is the one-cell sentinel, which is excluded from the source decrement of R0.

Across the 38,208 fixtures, the verifier finds 38,200 live successors and eight goal halts in 43,222,186 primitive transitions. It visits all 374 physical rows at least once over the whole set of starting frames. These finite fixtures complement the guarded release’s separate universal branch certificates. The two JSON files give the expected replay results.
