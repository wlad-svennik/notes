# From the guarded search to pure NF with full Rosser Counting

The exact Lean theorem for the 3,642-instruction program is an equivalence between halting from counter 5 and a finite derivation of the goal $JJ=J$ in the nine-schema calculus. At the same initialization, nonhalting is equivalent to the existence of a guarded chart. A separate Lean conclusion turns such nonhalting into a model of NFU with a represented proper self-injection and $T(n)=n$ for every internal natural number. The proof quantifies over the model’s naturals. This matters when the model is nonstandard.

## From pure NF + AxCount to nonhalting

The written upper construction starts with a pure NF + AxCount model. It uses its full function chart, represented disjoint families of labels, a represented completion of a partial assignment of rows, and the strongly Cantorian internal natural numbers. In the resulting chart the reader $q$ satisfies $qJ=B$ because its probes on arguments $P(t)$ code exactly $t\in B$. For any nonconstant row $b$, the value $Jb$ is either $B$ or a chain label $a_n$. In the former case $(J(Jb))J=qJ=B$. In the latter the successor row $a_{n+1}$ returns $a_n$ when read at $J$, since $J$ differs from the sentinel. These two cases give the extra guarded law.

The probe map $P$ is defined on every object of the original model, and its image lies in a reserved slice. Thus the reader at $J$ recovers the entire set $B$. For the reader’s comprehension, an argument $t$ and its probe $P(t)$ have the same type, while the row label $z$ and the resulting set $U(z)$ have the next type. The strongly Cantorian index supplies the type adjustment along the chain for every internal $n$.

The strength needed at the chart-construction step is an internally represented assignment. An arbitrary external bijection between sets of labels and rows would not establish the required stratified comprehension. The pure-model construction and internal completion remain written mathematical inputs in `calculus/UPPER.md` of the original archive.

## From nonhalting to consistency of pure NF + AxCount

The lower model has the membership and sethood structure of NFU, together with Dedekind Infinity and full AxCount. Its ordered pairs can be taken to be Kuratowski pairs. Thus the comparison in the supplied excerpt applies to bare NFU without a primitive type-level pairing axiom.

In *Choice and Consistency Strength in NF and NFU* (v15), R. Gutin and E. Glazer give the implication from consistency of this NFU theory to consistency of $C_\beth$ in Proposition 17.13. The **upper-construction direction** of the first row of Theorem 21.1 supplies consistency of pure NF + AxCount from consistency of $C_\beth$. Both are statements about consistency over PRA. They need not use the same model or universe in these implications. The release excerpt includes the statements and refers to other parts of the manuscript for details of the pure-theory construction. The authors describe these comparisons as self-audited research claims awaiting independent verification.

Together with the physical simulation, these written inputs give the intended conclusion that the literal blank-tape machine halts if and only if pure NF + full AxCount is inconsistent. The replay verifies the machine, the search and the formal model conclusions. Its review of the manuscript checked the definitions, hypotheses and directions of the implications.
