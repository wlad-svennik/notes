module
public import Std
@[expose] public section

/-!
# Ordinary deterministic binary Turing machines

This file contains definitions and elementary execution lemmas only.
The tape is a function on the integers, so its two directions and blank
exterior have their usual mathematical meaning. Entering `none` is halting;
a halted configuration is left fixed by subsequent steps.
-/

namespace NF210.TM

variable {n : Nat}

inductive Direction where
  | left
  | right
  deriving DecidableEq, Repr

structure Instruction (n : Nat) where
  write : Bool
  move : Direction
  next : Option (Fin n)
  deriving DecidableEq, Repr

abbrev Machine (n : Nat) := Fin n → Bool → Instruction n
abbrev Tape := Int → Bool

structure Configuration (n : Nat) where
  state : Option (Fin n)
  head : Int
  tape : Tape

def writeTape (tape : Tape) (position : Int) (symbol : Bool) : Tape :=
  fun p => if p = position then symbol else tape p

def moveHead (direction : Direction) (head : Int) : Int :=
  match direction with
  | .left => head - 1
  | .right => head + 1

def step (machine : Machine n) (configuration : Configuration n) : Configuration n :=
  match configuration.state with
  | none => configuration
  | some state =>
    let instruction := machine state (configuration.tape configuration.head)
    { state := instruction.next
      head := moveHead instruction.move configuration.head
      tape := writeTape configuration.tape configuration.head instruction.write }

def run (machine : Machine n) : Nat → Configuration n → Configuration n
  | 0, configuration => configuration
  | time + 1, configuration => step machine (run machine time configuration)

def blank (start : Fin n) : Configuration n :=
  { state := some start, head := 0, tape := fun _ => false }

def Halts (machine : Machine n) (start : Fin n) : Prop :=
  ∃ time, (run machine time (blank start)).state = none

@[simp] theorem writeTape_at (tape : Tape) (position : Int) (symbol : Bool) :
    writeTape tape position symbol position = symbol := by
  simp [writeTape]

theorem writeTape_away (tape : Tape) (position other : Int) (symbol : Bool)
    (different : other ≠ position) :
    writeTape tape position symbol other = tape other := by
  simp [writeTape, different]

@[simp] theorem run_zero (machine : Machine n) (configuration : Configuration n) :
    run machine 0 configuration = configuration := rfl

@[simp] theorem run_succ (machine : Machine n) (time : Nat)
    (configuration : Configuration n) :
    run machine (time + 1) configuration = step machine (run machine time configuration) := rfl

theorem run_add (machine : Machine n) (first second : Nat)
    (configuration : Configuration n) :
    run machine (first + second) configuration =
      run machine second (run machine first configuration) := by
  induction second with
  | zero => simp [run]
  | succ second ih => simp [run, ih]

theorem step_of_halted (machine : Machine n) (configuration : Configuration n)
    (halted : configuration.state = none) :
    step machine configuration = configuration := by
  simp [step, halted]

theorem run_of_halted (machine : Machine n) (configuration : Configuration n)
    (halted : configuration.state = none) (time : Nat) :
    run machine time configuration = configuration := by
  induction time with
  | zero => rfl
  | succ time ih => simp [run, ih, step_of_halted machine configuration halted]

theorem halting_persists (machine : Machine n) (start : Fin n) (time extra : Nat)
    (halted : (run machine time (blank start)).state = none) :
    (run machine (time + extra) (blank start)).state = none := by
  rw [run_add, run_of_halted machine _ halted extra]
  exact halted

end NF210.TM
