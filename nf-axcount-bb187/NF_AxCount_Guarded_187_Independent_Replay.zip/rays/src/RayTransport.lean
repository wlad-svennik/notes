import NF210.MachineSemantics

namespace Guarded187.RayTransport
open NF210.TM

/-- The export stores the head cell at index zero of the ray in the last move's direction. -/
abbrev Ray := Nat → Nat
abbrev Code := Nat → Ray

def push (w : Nat) (s : Ray) : Ray
  | 0 => w
  | i+1 => s i

def tail (s : Ray) : Ray := fun i => s (i+1)

def dirTag : Direction → Nat
 | .right => 0
 | .left => 1

def ahead (d : Direction) (h : Int) (t : Tape) : Ray := fun i =>
 (t (match d with | .right => h+(i:Int) | .left => h-(i:Int))).toNat

def behind (d : Direction) (h : Int) (t : Tape) : Ray := fun i =>
 (t (match d with | .right => h-(i:Int)-1 | .left => h+(i:Int)+1)).toNat

private theorem ahead_zero (d : Direction) (h : Int) (t : Tape) :
    ahead d h t 0 = (t h).toNat := by cases d <;> simp [ahead]

theorem ahead_after (d move : Direction) (h : Int) (t : Tape) (w : Bool) :
    ahead move (moveHead move h) (writeTape t h w) =
      if move = d then tail (ahead d h t) else behind d h t := by
  funext i
  cases d <;> cases move <;>
    simp (disch := omega) [ahead,behind,moveHead,writeTape,tail]
  all_goals
    apply congrArg Bool.toNat
    exact (ite_eq_right (by omega)).trans (congrArg t (by omega))

theorem behind_after (d move : Direction) (h : Int) (t : Tape) (w : Bool) :
    behind move (moveHead move h) (writeTape t h w) =
      push w.toNat (if move = d then behind d h t else tail (ahead d h t)) := by
  funext i
  cases i <;> cases d <;> cases move <;>
    simp (disch := omega) [ahead,behind,moveHead,writeTape,push,tail]
  all_goals
    apply congrArg Bool.toNat
    exact (ite_eq_right (by omega)).trans (congrArg t (by omega))

/-- Tags 0 and 1 hold constant scalars; tag 2 is the forward ray; all later tags return the rear ray. -/
def cfg (q d : Nat) (a b : Ray) : Code
  | 0 => fun _ => q
  | 1 => fun _ => d
  | 2 => a
  | _+3 => b

def applyRow (q write move d : Nat) (a b : Ray) : Code :=
  let forward := cfg q move (tail a) (push write b)
  let reverse := cfg q move b (push write (tail a))
  if move = 0 then (if d = 0 then forward else reverse)
  else (if d = 0 then reverse else forward)

theorem applyRow_exact (q : Nat) (d move : Direction) (h : Int) (t : Tape) (w : Bool) :
    applyRow q w.toNat (dirTag move) (dirTag d) (ahead d h t) (behind d h t) =
      cfg q (dirTag move) (ahead move (moveHead move h) (writeTape t h w))
        (behind move (moveHead move h) (writeTape t h w)) := by
  rw [ahead_after d move h t w,behind_after d move h t w]
  cases d <;> cases move <;> rfl

def stateCode {n : Nat} : Option (Fin n) → Nat
 | none => n
 | some q => q.val

def view {n : Nat} (d : Direction) (s : Configuration n) : Code :=
  cfg (stateCode s.state) (dirTag d) (ahead d s.head s.tape) (behind d s.head s.tape)

def rayStep {n : Nat} (machine : Machine n) (c : Code) : Code :=
  if h : c 0 0 < n then
    let row := machine ⟨c 0 0,h⟩ (decide (c 2 0 ≠ 0))
    applyRow (stateCode row.next) row.write.toNat (dirTag row.move) (c 1 0) (c 2) (c 3)
  else cfg n (c 1 0) (c 2) (c 3)

def nextDir {n : Nat} (m : Machine n) (d : Direction) (s : Configuration n) :=
  match s.state with | none => d | some q => (m q (s.tape s.head)).move

private theorem read_bit (b : Bool) : decide (b.toNat ≠ 0) = b := by cases b <;> rfl

/-- Every ordinary transition, including the absorbing halt, realizes the two-ray update. -/
theorem step_exact {n : Nat} (m : Machine n) (d : Direction) (s : Configuration n) :
    rayStep m (view d s) = view (nextDir m d s) (step m s) := by
  rcases s with ⟨_ | q, h, t⟩
  · simp [rayStep,view,stateCode,cfg,step,nextDir]
  · simp only [rayStep,view,stateCode,cfg,q.isLt,dite_eq_left,ahead_zero,read_bit,nextDir,step]
    exact applyRow_exact _ d _ h t _

def iterate {X : Type} (f : X → X) (x : X) : Nat → X
  | 0 => x
  | n+1 => f (iterate f x n)

def lastDir {n : Nat} (m : Machine n) (d : Direction) (s : Configuration n) : Nat → Direction
 | 0 => d
 | t+1 => nextDir m (lastDir m d s t) (run m t s)

theorem run_exact {n : Nat} (m : Machine n) (d : Direction) (s : Configuration n) (k : Nat) :
    iterate (rayStep m) (view d s) k = view (lastDir m d s k) (run m k s) := by
  induction k with
  | zero => rfl
  | succ k ih => rw [iterate,ih,step_exact,lastDir,run_succ]

/-- The emitted `norm` orients both rays to the right after a live branch. -/
def norm (c : Code) : Code :=
  if c 1 0 = 0 then c else cfg (c 0 0) 0 (push (c 2 0) (c 3)) (tail (c 2))

private theorem turn_front (h : Int) (t : Tape) :
    push (ahead .left h t 0) (behind .left h t) = ahead .right h t := by
  funext i
  cases i <;> simp [push,ahead,behind]
  apply congrArg Bool.toNat
  apply congrArg t
  omega

private theorem turn_back (h : Int) (t : Tape) :
    tail (ahead .left h t) = behind .right h t := by
  funext i
  simp [tail,ahead,behind]
  apply congrArg Bool.toNat
  apply congrArg t
  omega

theorem norm_view {n : Nat} (d : Direction) (s : Configuration n) :
    norm (view d s) = view .right s := by
  cases d with
  | left =>
    change cfg _ 0 (push (ahead .left _ _ 0) (behind .left _ _)) (tail (ahead .left _ _)) = _
    rw [turn_front,turn_back]
    rfl
  | right => rfl

theorem normalized_run {n : Nat} (m : Machine n) (d : Direction) (s : Configuration n) (k : Nat) :
    norm (iterate (rayStep m) (view d s) k) = view .right (run m k s) := by
  rw [run_exact,norm_view]

theorem halted_exact {n : Nat} (s : Configuration n) (d : Direction) :
    view d s 0 0 = n ↔ s.state = none := by
  rcases s with ⟨_ | q,h,t⟩
  · simp [view,stateCode,cfg]
  · change (q.val=n) ↔ some q = none
    simp [Nat.ne_of_lt q.isLt]

#print axioms applyRow_exact
#print axioms step_exact
#print axioms run_exact
#print axioms norm_view
#print axioms normalized_run
#print axioms halted_exact
end Guarded187.RayTransport
