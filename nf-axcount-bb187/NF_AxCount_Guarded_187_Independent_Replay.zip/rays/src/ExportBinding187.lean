import RayTransport
import Exported187
import Blank187Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Guarded187.ExportBinding
open NF210.TM Guarded187.RayTransport
open Blank187.Table (machine)
private theorem cfg_eq (q d : Nat) (a b : Ray) : NFSearchSweep.cfg q d a b = cfg q d a b := by
  funext t
  rcases t with _ | (_ | (_ | t)) <;> rfl
private theorem push_eq (q : Nat) (a : Ray) : NFSearchSweep.push q a = push q a := by
  funext i
  cases i <;> rfl
private theorem apply_eq (q w m d : Nat) (a b : Ray) :
    NFSearchSweep.applyRow q w m d a b = applyRow q w m d a b := by
  cases m <;> cases d <;> change NFSearchSweep.cfg _ _ _ _ = cfg _ _ _ _ <;> rw [cfg_eq,push_eq] <;> rfl
private theorem norm_eq (c : Code) : NFSearchSweep.norm c = norm c := by
  cases e : c 1 0 with
  | zero => simp [NFSearchSweep.norm,NFSearchSweep.chooseZero,norm,e]; rfl
  | succ k => simp [NFSearchSweep.norm,NFSearchSweep.chooseZero,norm,e,cfg_eq,push_eq]; rfl
private def Good (q : Fin 187) : Prop := ∀ (b : Bool) (d : Nat) (a rear : Ray),
    NFSearchSweep.table0 q.val b.toNat d a rear =
    let i := machine q b
    NFSearchSweep.applyRow (stateCode i.next) i.write.toNat (dirTag i.move) d a rear
private theorem e0 : Good 0 := by intro b d a r; cases b <;> rfl
private theorem e1 : Good 1 := by intro b d a r; cases b <;> rfl
private theorem e2 : Good 2 := by intro b d a r; cases b <;> rfl
private theorem e3 : Good 3 := by intro b d a r; cases b <;> rfl
private theorem e4 : Good 4 := by intro b d a r; cases b <;> rfl
private theorem e5 : Good 5 := by intro b d a r; cases b <;> rfl
private theorem e6 : Good 6 := by intro b d a r; cases b <;> rfl
private theorem e7 : Good 7 := by intro b d a r; cases b <;> rfl
private theorem e8 : Good 8 := by intro b d a r; cases b <;> rfl
private theorem e9 : Good 9 := by intro b d a r; cases b <;> rfl
private theorem e10 : Good 10 := by intro b d a r; cases b <;> rfl
private theorem e11 : Good 11 := by intro b d a r; cases b <;> rfl
private theorem e12 : Good 12 := by intro b d a r; cases b <;> rfl
private theorem e13 : Good 13 := by intro b d a r; cases b <;> rfl
private theorem e14 : Good 14 := by intro b d a r; cases b <;> rfl
private theorem e15 : Good 15 := by intro b d a r; cases b <;> rfl
private theorem e16 : Good 16 := by intro b d a r; cases b <;> rfl
private theorem e17 : Good 17 := by intro b d a r; cases b <;> rfl
private theorem e18 : Good 18 := by intro b d a r; cases b <;> rfl
private theorem e19 : Good 19 := by intro b d a r; cases b <;> rfl
private theorem e20 : Good 20 := by intro b d a r; cases b <;> rfl
private theorem e21 : Good 21 := by intro b d a r; cases b <;> rfl
private theorem e22 : Good 22 := by intro b d a r; cases b <;> rfl
private theorem e23 : Good 23 := by intro b d a r; cases b <;> rfl
private theorem e24 : Good 24 := by intro b d a r; cases b <;> rfl
private theorem e25 : Good 25 := by intro b d a r; cases b <;> rfl
private theorem e26 : Good 26 := by intro b d a r; cases b <;> rfl
private theorem e27 : Good 27 := by intro b d a r; cases b <;> rfl
private theorem e28 : Good 28 := by intro b d a r; cases b <;> rfl
private theorem e29 : Good 29 := by intro b d a r; cases b <;> rfl
private theorem e30 : Good 30 := by intro b d a r; cases b <;> rfl
private theorem e31 : Good 31 := by intro b d a r; cases b <;> rfl
private theorem e32 : Good 32 := by intro b d a r; cases b <;> rfl
private theorem e33 : Good 33 := by intro b d a r; cases b <;> rfl
private theorem e34 : Good 34 := by intro b d a r; cases b <;> rfl
private theorem e35 : Good 35 := by intro b d a r; cases b <;> rfl
private theorem e36 : Good 36 := by intro b d a r; cases b <;> rfl
private theorem e37 : Good 37 := by intro b d a r; cases b <;> rfl
private theorem e38 : Good 38 := by intro b d a r; cases b <;> rfl
private theorem e39 : Good 39 := by intro b d a r; cases b <;> rfl
private theorem e40 : Good 40 := by intro b d a r; cases b <;> rfl
private theorem e41 : Good 41 := by intro b d a r; cases b <;> rfl
private theorem e42 : Good 42 := by intro b d a r; cases b <;> rfl
private theorem e43 : Good 43 := by intro b d a r; cases b <;> rfl
private theorem e44 : Good 44 := by intro b d a r; cases b <;> rfl
private theorem e45 : Good 45 := by intro b d a r; cases b <;> rfl
private theorem e46 : Good 46 := by intro b d a r; cases b <;> rfl
private theorem e47 : Good 47 := by intro b d a r; cases b <;> rfl
private theorem e48 : Good 48 := by intro b d a r; cases b <;> rfl
private theorem e49 : Good 49 := by intro b d a r; cases b <;> rfl
private theorem e50 : Good 50 := by intro b d a r; cases b <;> rfl
private theorem e51 : Good 51 := by intro b d a r; cases b <;> rfl
private theorem e52 : Good 52 := by intro b d a r; cases b <;> rfl
private theorem e53 : Good 53 := by intro b d a r; cases b <;> rfl
private theorem e54 : Good 54 := by intro b d a r; cases b <;> rfl
private theorem e55 : Good 55 := by intro b d a r; cases b <;> rfl
private theorem e56 : Good 56 := by intro b d a r; cases b <;> rfl
private theorem e57 : Good 57 := by intro b d a r; cases b <;> rfl
private theorem e58 : Good 58 := by intro b d a r; cases b <;> rfl
private theorem e59 : Good 59 := by intro b d a r; cases b <;> rfl
private theorem e60 : Good 60 := by intro b d a r; cases b <;> rfl
private theorem e61 : Good 61 := by intro b d a r; cases b <;> rfl
private theorem e62 : Good 62 := by intro b d a r; cases b <;> rfl
private theorem e63 : Good 63 := by intro b d a r; cases b <;> rfl
private theorem e64 : Good 64 := by intro b d a r; cases b <;> rfl
private theorem e65 : Good 65 := by intro b d a r; cases b <;> rfl
private theorem e66 : Good 66 := by intro b d a r; cases b <;> rfl
private theorem e67 : Good 67 := by intro b d a r; cases b <;> rfl
private theorem e68 : Good 68 := by intro b d a r; cases b <;> rfl
private theorem e69 : Good 69 := by intro b d a r; cases b <;> rfl
private theorem e70 : Good 70 := by intro b d a r; cases b <;> rfl
private theorem e71 : Good 71 := by intro b d a r; cases b <;> rfl
private theorem e72 : Good 72 := by intro b d a r; cases b <;> rfl
private theorem e73 : Good 73 := by intro b d a r; cases b <;> rfl
private theorem e74 : Good 74 := by intro b d a r; cases b <;> rfl
private theorem e75 : Good 75 := by intro b d a r; cases b <;> rfl
private theorem e76 : Good 76 := by intro b d a r; cases b <;> rfl
private theorem e77 : Good 77 := by intro b d a r; cases b <;> rfl
private theorem e78 : Good 78 := by intro b d a r; cases b <;> rfl
private theorem e79 : Good 79 := by intro b d a r; cases b <;> rfl
private theorem e80 : Good 80 := by intro b d a r; cases b <;> rfl
private theorem e81 : Good 81 := by intro b d a r; cases b <;> rfl
private theorem e82 : Good 82 := by intro b d a r; cases b <;> rfl
private theorem e83 : Good 83 := by intro b d a r; cases b <;> rfl
private theorem e84 : Good 84 := by intro b d a r; cases b <;> rfl
private theorem e85 : Good 85 := by intro b d a r; cases b <;> rfl
private theorem e86 : Good 86 := by intro b d a r; cases b <;> rfl
private theorem e87 : Good 87 := by intro b d a r; cases b <;> rfl
private theorem e88 : Good 88 := by intro b d a r; cases b <;> rfl
private theorem e89 : Good 89 := by intro b d a r; cases b <;> rfl
private theorem e90 : Good 90 := by intro b d a r; cases b <;> rfl
private theorem e91 : Good 91 := by intro b d a r; cases b <;> rfl
private theorem e92 : Good 92 := by intro b d a r; cases b <;> rfl
private theorem e93 : Good 93 := by intro b d a r; cases b <;> rfl
private theorem e94 : Good 94 := by intro b d a r; cases b <;> rfl
private theorem e95 : Good 95 := by intro b d a r; cases b <;> rfl
private theorem e96 : Good 96 := by intro b d a r; cases b <;> rfl
private theorem e97 : Good 97 := by intro b d a r; cases b <;> rfl
private theorem e98 : Good 98 := by intro b d a r; cases b <;> rfl
private theorem e99 : Good 99 := by intro b d a r; cases b <;> rfl
private theorem e100 : Good 100 := by intro b d a r; cases b <;> rfl
private theorem e101 : Good 101 := by intro b d a r; cases b <;> rfl
private theorem e102 : Good 102 := by intro b d a r; cases b <;> rfl
private theorem e103 : Good 103 := by intro b d a r; cases b <;> rfl
private theorem e104 : Good 104 := by intro b d a r; cases b <;> rfl
private theorem e105 : Good 105 := by intro b d a r; cases b <;> rfl
private theorem e106 : Good 106 := by intro b d a r; cases b <;> rfl
private theorem e107 : Good 107 := by intro b d a r; cases b <;> rfl
private theorem e108 : Good 108 := by intro b d a r; cases b <;> rfl
private theorem e109 : Good 109 := by intro b d a r; cases b <;> rfl
private theorem e110 : Good 110 := by intro b d a r; cases b <;> rfl
private theorem e111 : Good 111 := by intro b d a r; cases b <;> rfl
private theorem e112 : Good 112 := by intro b d a r; cases b <;> rfl
private theorem e113 : Good 113 := by intro b d a r; cases b <;> rfl
private theorem e114 : Good 114 := by intro b d a r; cases b <;> rfl
private theorem e115 : Good 115 := by intro b d a r; cases b <;> rfl
private theorem e116 : Good 116 := by intro b d a r; cases b <;> rfl
private theorem e117 : Good 117 := by intro b d a r; cases b <;> rfl
private theorem e118 : Good 118 := by intro b d a r; cases b <;> rfl
private theorem e119 : Good 119 := by intro b d a r; cases b <;> rfl
private theorem e120 : Good 120 := by intro b d a r; cases b <;> rfl
private theorem e121 : Good 121 := by intro b d a r; cases b <;> rfl
private theorem e122 : Good 122 := by intro b d a r; cases b <;> rfl
private theorem e123 : Good 123 := by intro b d a r; cases b <;> rfl
private theorem e124 : Good 124 := by intro b d a r; cases b <;> rfl
private theorem e125 : Good 125 := by intro b d a r; cases b <;> rfl
private theorem e126 : Good 126 := by intro b d a r; cases b <;> rfl
private theorem e127 : Good 127 := by intro b d a r; cases b <;> rfl
private theorem e128 : Good 128 := by intro b d a r; cases b <;> rfl
private theorem e129 : Good 129 := by intro b d a r; cases b <;> rfl
private theorem e130 : Good 130 := by intro b d a r; cases b <;> rfl
private theorem e131 : Good 131 := by intro b d a r; cases b <;> rfl
private theorem e132 : Good 132 := by intro b d a r; cases b <;> rfl
private theorem e133 : Good 133 := by intro b d a r; cases b <;> rfl
private theorem e134 : Good 134 := by intro b d a r; cases b <;> rfl
private theorem e135 : Good 135 := by intro b d a r; cases b <;> rfl
private theorem e136 : Good 136 := by intro b d a r; cases b <;> rfl
private theorem e137 : Good 137 := by intro b d a r; cases b <;> rfl
private theorem e138 : Good 138 := by intro b d a r; cases b <;> rfl
private theorem e139 : Good 139 := by intro b d a r; cases b <;> rfl
private theorem e140 : Good 140 := by intro b d a r; cases b <;> rfl
private theorem e141 : Good 141 := by intro b d a r; cases b <;> rfl
private theorem e142 : Good 142 := by intro b d a r; cases b <;> rfl
private theorem e143 : Good 143 := by intro b d a r; cases b <;> rfl
private theorem e144 : Good 144 := by intro b d a r; cases b <;> rfl
private theorem e145 : Good 145 := by intro b d a r; cases b <;> rfl
private theorem e146 : Good 146 := by intro b d a r; cases b <;> rfl
private theorem e147 : Good 147 := by intro b d a r; cases b <;> rfl
private theorem e148 : Good 148 := by intro b d a r; cases b <;> rfl
private theorem e149 : Good 149 := by intro b d a r; cases b <;> rfl
private theorem e150 : Good 150 := by intro b d a r; cases b <;> rfl
private theorem e151 : Good 151 := by intro b d a r; cases b <;> rfl
private theorem e152 : Good 152 := by intro b d a r; cases b <;> rfl
private theorem e153 : Good 153 := by intro b d a r; cases b <;> rfl
private theorem e154 : Good 154 := by intro b d a r; cases b <;> rfl
private theorem e155 : Good 155 := by intro b d a r; cases b <;> rfl
private theorem e156 : Good 156 := by intro b d a r; cases b <;> rfl
private theorem e157 : Good 157 := by intro b d a r; cases b <;> rfl
private theorem e158 : Good 158 := by intro b d a r; cases b <;> rfl
private theorem e159 : Good 159 := by intro b d a r; cases b <;> rfl
private theorem e160 : Good 160 := by intro b d a r; cases b <;> rfl
private theorem e161 : Good 161 := by intro b d a r; cases b <;> rfl
private theorem e162 : Good 162 := by intro b d a r; cases b <;> rfl
private theorem e163 : Good 163 := by intro b d a r; cases b <;> rfl
private theorem e164 : Good 164 := by intro b d a r; cases b <;> rfl
private theorem e165 : Good 165 := by intro b d a r; cases b <;> rfl
private theorem e166 : Good 166 := by intro b d a r; cases b <;> rfl
private theorem e167 : Good 167 := by intro b d a r; cases b <;> rfl
private theorem e168 : Good 168 := by intro b d a r; cases b <;> rfl
private theorem e169 : Good 169 := by intro b d a r; cases b <;> rfl
private theorem e170 : Good 170 := by intro b d a r; cases b <;> rfl
private theorem e171 : Good 171 := by intro b d a r; cases b <;> rfl
private theorem e172 : Good 172 := by intro b d a r; cases b <;> rfl
private theorem e173 : Good 173 := by intro b d a r; cases b <;> rfl
private theorem e174 : Good 174 := by intro b d a r; cases b <;> rfl
private theorem e175 : Good 175 := by intro b d a r; cases b <;> rfl
private theorem e176 : Good 176 := by intro b d a r; cases b <;> rfl
private theorem e177 : Good 177 := by intro b d a r; cases b <;> rfl
private theorem e178 : Good 178 := by intro b d a r; cases b <;> rfl
private theorem e179 : Good 179 := by intro b d a r; cases b <;> rfl
private theorem e180 : Good 180 := by intro b d a r; cases b <;> rfl
private theorem e181 : Good 181 := by intro b d a r; cases b <;> rfl
private theorem e182 : Good 182 := by intro b d a r; cases b <;> rfl
private theorem e183 : Good 183 := by intro b d a r; cases b <;> rfl
private theorem e184 : Good 184 := by intro b d a r; cases b <;> rfl
private theorem e185 : Good 185 := by intro b d a r; cases b <;> rfl
private theorem e186 : Good 186 := by intro b d a r; cases b <;> rfl
private def certs : List {q : Fin 187 // Good q} := [
  ⟨0,e0⟩,
  ⟨1,e1⟩,
  ⟨2,e2⟩,
  ⟨3,e3⟩,
  ⟨4,e4⟩,
  ⟨5,e5⟩,
  ⟨6,e6⟩,
  ⟨7,e7⟩,
  ⟨8,e8⟩,
  ⟨9,e9⟩,
  ⟨10,e10⟩,
  ⟨11,e11⟩,
  ⟨12,e12⟩,
  ⟨13,e13⟩,
  ⟨14,e14⟩,
  ⟨15,e15⟩,
  ⟨16,e16⟩,
  ⟨17,e17⟩,
  ⟨18,e18⟩,
  ⟨19,e19⟩,
  ⟨20,e20⟩,
  ⟨21,e21⟩,
  ⟨22,e22⟩,
  ⟨23,e23⟩,
  ⟨24,e24⟩,
  ⟨25,e25⟩,
  ⟨26,e26⟩,
  ⟨27,e27⟩,
  ⟨28,e28⟩,
  ⟨29,e29⟩,
  ⟨30,e30⟩,
  ⟨31,e31⟩,
  ⟨32,e32⟩,
  ⟨33,e33⟩,
  ⟨34,e34⟩,
  ⟨35,e35⟩,
  ⟨36,e36⟩,
  ⟨37,e37⟩,
  ⟨38,e38⟩,
  ⟨39,e39⟩,
  ⟨40,e40⟩,
  ⟨41,e41⟩,
  ⟨42,e42⟩,
  ⟨43,e43⟩,
  ⟨44,e44⟩,
  ⟨45,e45⟩,
  ⟨46,e46⟩,
  ⟨47,e47⟩,
  ⟨48,e48⟩,
  ⟨49,e49⟩,
  ⟨50,e50⟩,
  ⟨51,e51⟩,
  ⟨52,e52⟩,
  ⟨53,e53⟩,
  ⟨54,e54⟩,
  ⟨55,e55⟩,
  ⟨56,e56⟩,
  ⟨57,e57⟩,
  ⟨58,e58⟩,
  ⟨59,e59⟩,
  ⟨60,e60⟩,
  ⟨61,e61⟩,
  ⟨62,e62⟩,
  ⟨63,e63⟩,
  ⟨64,e64⟩,
  ⟨65,e65⟩,
  ⟨66,e66⟩,
  ⟨67,e67⟩,
  ⟨68,e68⟩,
  ⟨69,e69⟩,
  ⟨70,e70⟩,
  ⟨71,e71⟩,
  ⟨72,e72⟩,
  ⟨73,e73⟩,
  ⟨74,e74⟩,
  ⟨75,e75⟩,
  ⟨76,e76⟩,
  ⟨77,e77⟩,
  ⟨78,e78⟩,
  ⟨79,e79⟩,
  ⟨80,e80⟩,
  ⟨81,e81⟩,
  ⟨82,e82⟩,
  ⟨83,e83⟩,
  ⟨84,e84⟩,
  ⟨85,e85⟩,
  ⟨86,e86⟩,
  ⟨87,e87⟩,
  ⟨88,e88⟩,
  ⟨89,e89⟩,
  ⟨90,e90⟩,
  ⟨91,e91⟩,
  ⟨92,e92⟩,
  ⟨93,e93⟩,
  ⟨94,e94⟩,
  ⟨95,e95⟩,
  ⟨96,e96⟩,
  ⟨97,e97⟩,
  ⟨98,e98⟩,
  ⟨99,e99⟩,
  ⟨100,e100⟩,
  ⟨101,e101⟩,
  ⟨102,e102⟩,
  ⟨103,e103⟩,
  ⟨104,e104⟩,
  ⟨105,e105⟩,
  ⟨106,e106⟩,
  ⟨107,e107⟩,
  ⟨108,e108⟩,
  ⟨109,e109⟩,
  ⟨110,e110⟩,
  ⟨111,e111⟩,
  ⟨112,e112⟩,
  ⟨113,e113⟩,
  ⟨114,e114⟩,
  ⟨115,e115⟩,
  ⟨116,e116⟩,
  ⟨117,e117⟩,
  ⟨118,e118⟩,
  ⟨119,e119⟩,
  ⟨120,e120⟩,
  ⟨121,e121⟩,
  ⟨122,e122⟩,
  ⟨123,e123⟩,
  ⟨124,e124⟩,
  ⟨125,e125⟩,
  ⟨126,e126⟩,
  ⟨127,e127⟩,
  ⟨128,e128⟩,
  ⟨129,e129⟩,
  ⟨130,e130⟩,
  ⟨131,e131⟩,
  ⟨132,e132⟩,
  ⟨133,e133⟩,
  ⟨134,e134⟩,
  ⟨135,e135⟩,
  ⟨136,e136⟩,
  ⟨137,e137⟩,
  ⟨138,e138⟩,
  ⟨139,e139⟩,
  ⟨140,e140⟩,
  ⟨141,e141⟩,
  ⟨142,e142⟩,
  ⟨143,e143⟩,
  ⟨144,e144⟩,
  ⟨145,e145⟩,
  ⟨146,e146⟩,
  ⟨147,e147⟩,
  ⟨148,e148⟩,
  ⟨149,e149⟩,
  ⟨150,e150⟩,
  ⟨151,e151⟩,
  ⟨152,e152⟩,
  ⟨153,e153⟩,
  ⟨154,e154⟩,
  ⟨155,e155⟩,
  ⟨156,e156⟩,
  ⟨157,e157⟩,
  ⟨158,e158⟩,
  ⟨159,e159⟩,
  ⟨160,e160⟩,
  ⟨161,e161⟩,
  ⟨162,e162⟩,
  ⟨163,e163⟩,
  ⟨164,e164⟩,
  ⟨165,e165⟩,
  ⟨166,e166⟩,
  ⟨167,e167⟩,
  ⟨168,e168⟩,
  ⟨169,e169⟩,
  ⟨170,e170⟩,
  ⟨171,e171⟩,
  ⟨172,e172⟩,
  ⟨173,e173⟩,
  ⟨174,e174⟩,
  ⟨175,e175⟩,
  ⟨176,e176⟩,
  ⟨177,e177⟩,
  ⟨178,e178⟩,
  ⟨179,e179⟩,
  ⟨180,e180⟩,
  ⟨181,e181⟩,
  ⟨182,e182⟩,
  ⟨183,e183⟩,
  ⟨184,e184⟩,
  ⟨185,e185⟩,
  ⟨186,e186⟩]
private def certAt (q : Fin 187) : {s : Fin 187 // Good s} := certs[q.val]?.getD ⟨0,e0⟩
private theorem index_exact : ∀ q : Fin 187, (certAt q).val = q := by decide +kernel
theorem table_exact (q : Fin 187) : Good q := (index_exact q) ▸ (certAt q).property

private theorem head_bit (d : Direction) (h : Int) (t : Tape) : ahead d h t 0 = (t h).toNat := by
  cases d <;> simp [ahead]

/-- The raw `step` definition from the 187-state export commutes with the ordinary literal step. -/
theorem step_view (d : Direction) (c : Configuration 187) :
    NFSearchSweep.step (view d c) = view (nextDir machine d c) (step machine c) := by
  rcases c with ⟨_ | q,h,t⟩
  · change NFSearchSweep.cfg 187 (dirTag d) (ahead d h t) (behind d h t) = _
    exact cfg_eq _ _ _ _
  · change NFSearchSweep.table0 q.val (ahead d h t 0) (dirTag d) (ahead d h t) (behind d h t) = _
    rw [head_bit,table_exact q (t h) (dirTag d) (ahead d h t) (behind d h t),apply_eq]
    exact applyRow_exact _ d _ h t _

/-- This `iterate` is the definition used for raw branch-boundary equalities in the export. -/
theorem iterate_view (d : Direction) (c : Configuration 187) (k : Nat) :
    NFSearchSweep.iterate Code NFSearchSweep.step k (view d c) = view (lastDir machine d c k) (run machine k c) := by
  induction k with
  | zero => rfl
  | succ k ih =>
    change NFSearchSweep.step (NFSearchSweep.iterate Code NFSearchSweep.step k (view d c)) = _
    rw [ih,step_view]
    rfl

theorem normalized_iterate_view (d : Direction) (c : Configuration 187) (k : Nat) :
    NFSearchSweep.norm (NFSearchSweep.iterate Code NFSearchSweep.step k (view d c)) = view .right (run machine k c) := by
  rw [iterate_view,norm_eq,norm_view]

theorem terminal_iff (d : Direction) (c : Configuration 187) (k : Nat) :
    NFSearchSweep.iterate Code NFSearchSweep.step k (view d c) 0 0 = 187 ↔
      (run machine k c).state = none := by rw [iterate_view,halted_exact]

#print axioms table_exact
#print axioms step_view
#print axioms iterate_view
#print axioms normalized_iterate_view
#print axioms terminal_iff
end Guarded187.ExportBinding
