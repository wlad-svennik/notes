"""Rebuild the ordinary-tape correspondence for the exact 187-state export."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent
MODULES = ['NF210/MachineSemantics', 'Blank187Table', 'RayTransport', 'Exported187', 'ExportBinding187']
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', default='lean')
    parser.add_argument('--work', type=Path, help='Keep the fresh objects and per-module logs in this directory')
    args = parser.parse_args()
    version = subprocess.check_output([args.lean, '--version'], text=True).strip()
    if not version.startswith('Lean (version 4.35.0,'):
        raise RuntimeError('The certificate uses Lean 4.35.0. Found ' + version)
    for item in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = item.split('  ', 1)
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError('Checksum mismatch for ' + name)
    with TemporaryDirectory() as temporary:
        build = (args.work or Path(temporary)).resolve()
        build.mkdir(parents=True, exist_ok=True)
        (build / 'NF210').mkdir(exist_ok=True)
        env = dict(os.environ, LEAN_PATH=str(build))
        for module in MODULES:
            output = build / (module + '.olean')
            process = subprocess.run([args.lean, '-j1', '-s', '131072', '-o', output, module + '.lean'],
                                     cwd=ROOT / 'src', env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            (build / (module.replace('/', '.') + '.log')).write_text(process.stdout)
            if process.returncode or 'sorry' in process.stdout:
                raise RuntimeError(module + '\n' + process.stdout)
            if module in ['RayTransport', 'ExportBinding187']:
                source = (ROOT / 'src' / (module + '.lean')).read_text()
                wanted = set(re.findall(r'^#print axioms (\w+)$', source, re.M))
                logs = re.findall(r"'[^']*\.(\w+)' depends on axioms: \[([^\]]+)\]", process.stdout)
                if {name for name, _ in logs} != wanted:
                    raise RuntimeError('Missing endpoint audit for ' + module)
                for name, names in logs:
                    if set(names.split(', ')) - ALLOWED:
                        raise RuntimeError('Unexpected axioms for ' + name)
            print('Accepted ' + module, flush=True)
    print('All source modules and endpoint axiom checks passed.')


if __name__ == '__main__':
    main()
