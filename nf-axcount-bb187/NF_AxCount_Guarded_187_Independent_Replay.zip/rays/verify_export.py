"""Recreate the Lean transcription of the released definitions and compare a certified export."""
import argparse
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
ARCHIVE_DIGEST = '807c5018b3649cdff66ab677af27123d6d1abaae751b3a8b0056121e012f9012'


def render(term):
    kind = term[0]
    if kind == 'var':
        return term[1]
    if kind == 'const':
        universes = '.{' + ','.join(map(str, term[2])) + '}' if term[2] else ''
        return '@_root_.' + term[1] + universes
    if kind == 'num':
        return str(term[1])
    if kind == 'sort':
        return {0: 'Prop', 1: 'Type'}[term[1]]
    if kind == 'app':
        args = []
        while term[0] == 'app':
            args.append(term[2])
            term = term[1]
        return '(' + render(term) + ' ' + ' '.join(render(arg) for arg in reversed(args)) + ')'
    if kind == 'lam':
        return '(fun (' + term[1] + ' : ' + render(term[2]) + ') => ' + render(term[3]) + ')'
    if kind == 'forallE':
        return '(( ' + term[1] + ' : ' + render(term[2]) + ') → ' + render(term[3]) + ')'
    raise ValueError('Unsupported export term ' + kind)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('release', type=Path)
    parser.add_argument('--sample', type=Path, help='Reuse a complete 0–64 export with the published hash')
    args = parser.parse_args()
    digest = lambda raw: sha256(raw).hexdigest()
    assert digest(args.release.read_bytes()) == ARCHIVE_DIGEST
    with TemporaryDirectory() as tmp:
        work = Path(tmp)
        machine = work / 'machine'
        machine.mkdir()
        with ZipFile(args.release) as release:
            for member in release.namelist():
                if member.startswith('physical/') and not member.endswith('/'):
                    release.extract(member, work)
            for new, old in [('candidate.tm', 'NF_AxCount_Guarded_187.tm'), ('source.sites.json', 'source.sites.json')]:
                (machine / new).write_bytes(release.read(old))
            trace = work / 'traces.gz'
            trace.write_bytes(release.read('receipts/traces.json.gz'))
            certified = json.loads(release.read('receipts/kernel.json'))
        physical = work / 'physical'
        os.environ.update(NF_TABLE=str(machine / 'candidate.tm'), NF_TRACES=str(trace))
        sys.path.insert(0, str(physical))
        sys.argv[1:] = [str(machine)]
        import kernel_branches as branches
        import kernel_pumps as pumps
        from export_syntax import Export

        chunks = ['set_option maxRecDepth 100000\nset_option maxHeartbeats 0\nset_option linter.unusedVariables false\nnamespace NFSearchSweep\n']
        captured = []
        prefix = BytesIO()
        writer = Export(prefix)

        class Capture:
            active = False

            def declare(self, name, params, typ, body, *, theorem=False):
                result = writer.declare(name, params, typ, body, theorem=theorem)
                if self.active or name == 'NFSearchSweep.iterate':
                    assert name.startswith('NFSearchSweep.') and not theorem
                    arguments = ' '.join('(' + var + ' : ' + render(t) + ')' for var, t in params)
                    chunks.append('def ' + name.split('.', 1)[1] + ' ' + arguments + ' : ' + render(typ) + ' :=\n  ' + render(body) + '\n')
                    captured.append(name)
                return result

        capture = Capture()
        pumps.arithmetic(capture)
        pumps.pumping(capture)
        pumps.words_and_composition(capture)
        capture.active = True
        pumps.physical(capture)
        capture.active = False
        pumps.local_rules(capture)
        capture.active = True
        branches.normalized_support(capture)
        chunks.append('end NFSearchSweep\n')
        transcript = '\n'.join(chunks).encode()
        assert transcript == (HERE / 'src/Exported187.lean').read_bytes()
        receipt = json.loads((HERE / 'export-binding.json').read_bytes())
        assert captured == receipt['emitted_definitions']
        assert digest(prefix.getvalue()) == receipt['binary_prefix_sha256']
        assert digest(transcript) == receipt['generated_source_sha256']
        sample = args.sample or (work / '0-64.ndjson')
        if args.sample is None:
            subprocess.run([sys.executable, physical / 'kernel_branches.py', machine, sample, '--lo', '0', '--hi', '64'], check=True)
        data = sample.read_bytes()
        assert digest(data) == certified['intervals'][0]['export_sha256'] == receipt['certified_sample_sha256']
        assert data.startswith(prefix.getvalue())
        print(f'{len(captured)} definitions reproduced. The {len(prefix.getvalue())}-byte prologue matches the certified 0–64 export.')


if __name__ == '__main__':
    main()
