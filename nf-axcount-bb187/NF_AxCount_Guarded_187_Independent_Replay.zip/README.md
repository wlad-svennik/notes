# Independent replay of the guarded 187-state NF + AxCount machine

The input is the published `NF_AxCount_Guarded_187_Verification.zip`, SHA-256 `5ee48c1dea054b2ea3694f034dde2e9a7d4934c8f33a13e857747f25fd418440`. The table starts in `k:74` on an all-zero, two-way infinite tape. Run with assertions enabled, Python 3.9 or later, a C++17 compiler and Lean 4.35.0. The logical source build also requires the package revisions listed in `records/package-pins.json`.

The numerical and logical replay records identify the original archive used for those runs. Its documentation was revised to credit R. Gutin and E. Glazer jointly for the v15 manuscript. The current excerpt credits both authors on the title page, at its running titles and in the PDF metadata. The current and original archive hashes and their exact member differences are in `records/documentation-revision.json`.

## The physical computation

The independent simulator in `fixtures/` reads the text table directly. At steps 41,865 and 233,240 it compares every nonzero cell, the head and the control with a separately constructed register frame. For each of 9,552 instruction cases it checks four choices of initial tape. All 38,200 live successor tapes and eight expected halts agree, including their exact transition counts. Together these runs exercise every binary transition. See `fixtures/README.md` to repeat the tests.

From the second blank checkpoint, all nine register fields are in the ordinary representation. An ordinary field for value $r$ contains $r+2$ ones. Zero/positive tests distinguish two cases of a decrement. A positive decrement can return to the zero representation. An increment preserves the ordinary representation. Thus the two excluded tests on a one-cell register-0 field at instruction 2 are outside the domain reached from this checkpoint. The 4,777 ordinary cases exhaust its register steps. The archive additionally covers 4,775 cases with a one-cell field at register 0.

A live boundary has an address gap of $51+x$ and $24+y$ spare fields for natural numbers $x,y$. The counter-5 checkpoint has $x=46$, $y=54$. Incrementing a register creates a spare field. A positive decrement or a wrap to instruction 0 enlarges the address gap. The next boundary’s head is one cell to the left on a wrap. On the blank run both exterior rays contain only zeros. Moving into that padding leaves the next boundary with arbitrary further blank padding. The complete tapes at successive boundaries therefore stay inside the domain of the proofs, with no upper bound on register values, gap sizes, or spare fields.

The Lean kernel checks the computation from each input to its endpoint. An independent reader in `physical/check_export_types.py` then decodes the actual theorem statements from the same exports. It verifies the transition rows, input variables, exact symbolic clock, complete tape fields, and destination or halt control against the literal register program. To compute jumps it identifies each prefix-tree subtree with its interval of consecutive instruction indices. Every branch clock has a positive constant term. Consequently the sum of branch times along an infinite register run exceeds every fixed binary time. Since a halting binary state is absorbing, a run that keeps reaching live boundaries cannot already have halted.

To regenerate and check all 57 proof batches with the reference kernel and the independent statement reader, run this from the directory containing this file. Replace the last path with the unpacked original release.

```sh
python3 physical/recheck_physical.py ../verify187 --jobs 2
```

For a shorter check, `--interval-start 3584` selects the final batch, which includes the halting instruction. The optional `--keep exports` keeps the 57 raw proofs for inspection. The SHA-256 of each rebuilt proof must match the original archive before its statements are decoded. The stored full batch results are in `records/kernel-replay.json`. The archive’s original `verify.py --physical` also regenerates the symbolic traces before it generates its kernel proofs.

## The tape correspondence

A certificate stores the forward and rear portions of the tape as two infinite sequences indexed from the head. The supplemental Lean theorem `Guarded187.ExportBinding.normalized_iterate_view` identifies the normalized result of iterating the actual exported step function with the ordinary Turing-machine tape and control viewed relative to the current head, for every starting tape and every finite duration. Its companion `terminal_iff` identifies the exported halt code with the ordinary machine’s halt state. The proof checks both scanned symbols in every state. The step functions used for this proof share the 287,754-byte prefix checked in every archived export. Run `python3 rays/replay.py` with Lean 4.35.0 to repeat the proof. See `rays/README.md` for source regeneration.

The full register-to-tape claim combines this transport theorem, the decoded register-field statements and the complete blank checkpoint using the positive-clock composition argument. The release presents these as linked proofs and explicit checks.

## The logical endpoints

`logic/Audit.lean` prints the register theorem, the guarded-chart equivalence, the lower Counting-model conclusion and their dependencies. To reproduce the logical source build, use the original verification archive’s pinned Mathlib environment and run `python3 verify.py --theory --jobs 2` from that environment as described in its README. A clean Lean 4.35.0 build compiled all 197 project modules against the 14 pinned external packages. Seven endpoint statements and their axiom dependencies were rechecked from that build. The model conclusions refer to all natural numbers of the interpreted model.

The pure NF + AxCount equivalence also uses the written chart construction in the original archive and the consistency comparisons in *Choice and Consistency Strength in NF and NFU* (v15) by R. Gutin and E. Glazer. These proofs of the machine and its register search leave the status of those mathematical inputs as described in the main README.
