module
public import NF181PABatches
public import Direct181PARefill
public import NF181PAScanner
@[expose] public section
section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterFields NF181PA.Packed PA192.ModelSearch.Register181
open PA192.ModelSearch.Register181.Certified PA192.ModelSearch.Register181.Commands NF181PA.Scanner PA192.ModelSearch.Enumeration
set_option maxRecDepth 8500
set_option maxHeartbeats 4200000
namespace NF181PA.ScannerSource
open PA192.ModelSearch

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- PC24 holds the decoded outer tag in R3 and the inner Cantor word in R8. -/
noncomputable def vm24 (f k e raw : V) :=
  atS 24 f k (top e) (stack e) (left raw) (param e) (cache e) (right raw)
noncomputable def view (a : V) := vm24 0 (index a) (dataState a) (input a)
instance viewDef : Language.DefinableFunction₁ ℒₒᵣ (view (V:=V)) := by
  unfold view vm24 atS vector index top dataState stack param cache input; definability

theorem terminal_of_reach {x y : V} (h : Reach x y) (fin : sourceHalts y) : sourceHalts x := by
  obtain ⟨i,hi⟩ := h
  obtain ⟨j,hj⟩ := fin
  exact ⟨i+j,by rw [PA192.ModelSearch.Register181.run_add,hi,hj]⟩

/-- With the concrete PC24 view, the only local requirements are entry, the observed
MODE halt and one nonobserving command, including a possible candidate refill. -/
theorem from_source (start e origin : V) (entry : Reach origin (view (fresh start (cantor 0 start) e)))
    (onHit : ∀ a : V, observed a → sourceHalts (view a))
    (onLive : ∀ a : V, ¬observed a → Reach (view a) (view (next a)))
    (proof : NF181PA.Pool.Pr (∅ : V) goal) : sourceHalts origin := by
  by_contra impossible
  let begin := fresh start (cantor 0 start) e
  have all : ∀ t : V, Reach origin (view (iterate next t begin)) := by
    apply modelInduct
    · definability
    · simpa [begin] using entry
    · intro t h
      have live : ¬ observed (iterate next t begin) := fun stop =>
        impossible (terminal_of_reach h (onHit _ stop))
      simpa only [iterate_succ] using h.trans (onLive _ live)
  obtain ⟨t,hit⟩ := pool_forces_observation proof start e
  exact impossible (terminal_of_reach (all t) (onHit _ hit))


theorem view_fresh (k raw e : V) : view (fresh k raw e)=vm24 0 k e raw := by
  simp [view,fresh,index,input,dataState]
theorem view_unpack (a : V) : view a=vm24 0 (index a) (dataState a) (input a) := rfl

theorem fields24 (f n t s c p h d w : V) :
    Reach (atS 24 f n t s c p h (cantor d w)) (atS 38 f n t s c (p+d) h w) := by
  simpa only [atS,Nat.cast_ofNat,left_cantor,right_cantor] using
    reader24 f n t s c p h (cantor d w)

theorem axTail (u y d c w e : V) : pi₂ (axRaw u y d c w e) = unread c w := by
  simp [axRaw,ax_ends]

theorem modeHead24 (f n t sp p h d w : V) :
    Reach (atS 24 f n t sp 0 p h (cantor d w)) (atS 2924 f n t sp 0 (p+d) h w) := by
  have r := fields24 f n t sp 0 p h d w
  exact r.trans (site0038Zero f n t sp 0 (p+d) h 0 0 w)

theorem mpTagged24 (f n t sp p h d w : V) :
    Reach (atS 24 f n t sp 1 p h (cantor d w))
      (vm 0 f n (NF181PA.Commands.deduction d (state t sp h p)) w) := by
  have r := fields24 f n t sp 1 p h d w
  have first := site0038Positive f n t sp 0 (p+d) h 0 0 w
  have next := site0039Zero f n t sp 0 (p+d) h 0 0 w
  have dest := ((r.trans (by simpa [atS] using first)).trans next).trans (mpAndPop f n t sp (p+d) h w)
  simpa only [NF181PA.Commands.deduction_state,vm_state] using dest

theorem modeTagged24 (f n t s p h d w : V) (live : h≠3) :
    Reach (atS 24 f n t s 0 p h (cantor d w)) (vm 0 f n (mode d (state t s h p)) w) := by
  have b := (modeHead24 f n t s p h d w).trans (modeLive f n t s (p+d) h w live)
  by_cases he : p+d=0
  · simpa [mode,state,top,stack,cache,param,vm,he] using b
  · simpa [mode,state,top,stack,cache,param,vm,he] using b

theorem axTagged24 (f n t s p h outer y d c raw : V) :
    let z := axRaw outer y d c raw (state t s h p)
    Reach (atS 24 f n t s (c+2) p h (cantor outer (cantor y (cantor d raw))))
      (vm 0 f n (pi₁ z) (pi₂ z)) := by
  dsimp only
  let tail := cantor y (cantor d raw)
  let pp := p+outer
  let z := front8 (pp+d) (h+y) c pp (cantor t s)
  have read := fields24 f n t s (c+2) p h outer tail
  have guard := site0038Positive f n t s (c+1) pp h 0 0 tail
  have go : Reach (atS 38 f n t s (c+2) pp h tail) (atS 39 f n t s (c+1) pp h tail) := by
    simpa only [atS,zero_add,show c+1+1=c+2 by ring] using guard
  have first := site0039Positive f n t s c pp h 0 0 tail
  have emit := emitFields f n t s c pp h y d raw
  have back := site2849 f n (left z) (right z) c (pp+d) (h+y) 0 0 raw
  have seg := (((read.trans go).trans first).trans emit).trans back
  have run := batchesRun f n c z (pp+d) (h+y) raw (by simp [z,front8])
  rw [entry_pack] at run
  simpa only [axRaw,state,param,cache,top,stack,pi₁_pair,pi₂_pair,pp,z,tail] using seg.trans run



theorem liveFields (k t s h p tag d w : V) (live : ¬(tag=0 ∧ h=3)) :
    let raw := cantor tag (cantor d w)
    let e := state t s h p
    Reach (atS 24 0 k t s tag p h (cantor d w)) (vm 0 0 k (rawAction raw e) (tail raw)) := by
  dsimp only
  rcases zeroOrSuccessor tag with rfl|⟨i,rfl⟩
  · have neq : h≠3 := fun hh=>live ⟨rfl,hh⟩
    simpa [rawAction,tail,chooseZero] using modeTagged24 0 k t s p h d w neq
  rcases zeroOrSuccessor i with rfl|⟨c,rfl⟩
  · simpa [rawAction,tail,chooseZero] using mpTagged24 0 k t s p h d w
  · have step := axTagged24 0 k t s p h d (left w) (left (right w)) c (right (right w))
    dsimp only at step
    rw [pairUnpackTwo] at step
    have tag : c+1+1=c+2 := by ring
    have zz : c+2≠0 := by simp
    have zs : c+2-1≠0 := by rw [Enumeration.tag_succ_sub_one]; simp
    simpa only [tag,rawAction,rawAX,tail,left_cantor,right_cantor,chooseZero,zz,zs,ite_false,
      add_sub_self,vm_state,axTail] using step

theorem actualCommand {k raw e : V} (live : ¬(left raw=0 ∧ cache e=3)) :
    Reach (vm24 0 k e raw) (vm 0 0 k (rawAction raw e) (tail raw)) := by
  have h := liveFields k (top e) (stack e) (cache e) (param e) (left raw) (left (right raw)) (right (right raw)) live
  simpa only [vm24,pairUnpackTwo,pairUnpack,state_eta] using h

theorem actualRefill (k raw result : V) :
    let c := NF181PA.Scanner.cursor ⟪k,raw⟫
    Reach (vm 0 0 k result (Enumeration.tail raw)) (vm24 0 (pi₁ c) result (pi₂ c)) := by
  dsimp only
  rcases zeroOrSuccessor (Enumeration.tail raw) with zero|⟨j,positive⟩
  · rw [NF181PA.Scanner.cursor_zero zero,zero,pi₁_pair,pi₂_pair]
    simpa only [vm,vm24,atS,left_cantor,right_cantor,Nat.cast_ofNat] using
      refill0To24 k (top result) (stack result) 0 (param result) (cache result)
  · have neq : Enumeration.tail raw≠0 := by simp [positive]
    rw [NF181PA.Scanner.cursor_pos neq,positive,pi₁_pair,pi₂_pair]
    simpa only [vm,vm24,atS,Nat.cast_ofNat,zero_add,add_tsub_cancel_right] using
      continue0To24 0 k (top result) (stack result) 0 (param result) (cache result) j

/-- Every live scanner step is witnessed by an actual run on the 2,971-address source, in any PA model. -/
theorem onLive (a : V) (ok : ¬ observed a) : Reach (view a) (view (next a)) := by
  let k := index a
  let raw := input a
  let e := dataState a
  have h := actualCommand (k:=k) (raw:=raw) (e:=e) ok
  rw [view_unpack,next,view_fresh]
  exact h.trans (actualRefill k raw (rawAction raw e))

/-- An observed command reaches the authentic 4095 source halt. -/
theorem onHit (a : V) (ok : observed a) : sourceHalts (view a) := by
  obtain ⟨tag,old⟩ := ok
  let k := index a
  let raw := input a
  let e := dataState a
  let p := param e
  let t := top e
  let s := stack e
  let d := left (right raw)
  let w := right (right raw)
  have bodyEq : cantor d w=right raw := pairUnpack _
  have tr := modeHead24 0 k t s p 3 d w
  rw [bodyEq] at tr
  have done := carryHalt tr (modeHalt 0 k t s (p+d) w)
  rw [view_unpack]
  simpa only [vm24,show left (input a)=0 from tag,show cache (dataState a)=3 from old,k,raw,t,s,p,e] using done

/-- The entire scanner-to-source implication now only takes its initial source-entry witness. -/
theorem halts_of_entry (start e origin : V) (entry : Reach origin (view (fresh start (cantor 0 start) e)))
    (h : NF181PA.Pool.Pr (∅ : V) goal) : sourceHalts origin :=
  from_source start e origin entry onHit onLive h

end NF181PA.ScannerSource
#print axioms NF181PA.ScannerSource.onLive
#print axioms NF181PA.ScannerSource.onHit
#print axioms NF181PA.ScannerSource.halts_of_entry

end
