import M6PA.Calibration.Foundation
import Direct181PATransferCore
import NF181PATapeAll
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
namespace NF181PA
theorem equivalent_in_PA_models {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    (V ⊧/![] H181) ↔ (V ⊧/![] NF182PA.H182) :=
  equivalent_in_PA_models_of_coverage Symbolic.literal_table_coverage
theorem transfer_from_182 : M6.PA.theory ⊢ NF182PA.H182 🡒 H181 := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff,LogicalConnective.HomClass.map_imply]
  exact (equivalent_in_PA_models (V:=V)).mpr
theorem transfer_to_182 : M6.PA.theory ⊢ H181 🡒 NF182PA.H182 := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff,LogicalConnective.HomClass.map_imply]
  exact (equivalent_in_PA_models (V:=V)).mp
theorem halting_equivalence : M6.PA.theory ⊢ H181 🡘 NF182PA.H182 :=
  FFL.Entailment.E_intro transfer_to_182 transfer_from_182
end NF181PA
#print axioms NF181PA.transfer_from_182
#print axioms NF181PA.transfer_to_182
#print axioms NF181PA.halting_equivalence
