import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1536_0 : checkWitness 1536 false false 98 = true := by decide +kernel
private theorem w1536_2 : checkWitness 1536 true false 98 = true := by decide +kernel
private theorem cases1536 : checkFour 1536 (98,0,98,0) = true := by
  simp only [checkFour, w1536_0, w1536_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1536 : Coverage 1536 1537 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1536)
private theorem w1537_0 : checkWitness 1537 false false 8854 = true := by decide +kernel
private theorem w1537_2 : checkWitness 1537 true false 8850 = true := by decide +kernel
private theorem cases1537 : checkFour 1537 (8854,0,8850,0) = true := by
  simp only [checkFour, w1537_0, w1537_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1537 : Coverage 1537 1538 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases1537)
private theorem w1538_0 : checkWitness 1538 false false 412 = true := by decide +kernel
private theorem w1538_1 : checkWitness 1538 false true 4508 = true := by decide +kernel
private theorem w1538_2 : checkWitness 1538 true false 412 = true := by decide +kernel
private theorem w1538_3 : checkWitness 1538 true true 4508 = true := by decide +kernel
private theorem cases1538 : checkFour 1538 (412,4508,412,4508) = true := by
  simp only [checkFour, w1538_0, w1538_1, w1538_2, w1538_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1538 : Coverage 1538 1539 := checkList_sound (ws:=[(412,4508,412,4508)]) (by simpa only [checkList, Bool.and_true] using cases1538)
private theorem w1539_0 : checkWitness 1539 false false 8873 = true := by decide +kernel
private theorem w1539_2 : checkWitness 1539 true false 8869 = true := by decide +kernel
private theorem cases1539 : checkFour 1539 (8873,0,8869,0) = true := by
  simp only [checkFour, w1539_0, w1539_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1539 : Coverage 1539 1540 := checkList_sound (ws:=[(8873,0,8869,0)]) (by simpa only [checkList, Bool.and_true] using cases1539)
private theorem w1540_0 : checkWitness 1540 false false 604 = true := by decide +kernel
private theorem w1540_1 : checkWitness 1540 false true 4700 = true := by decide +kernel
private theorem w1540_2 : checkWitness 1540 true false 595 = true := by decide +kernel
private theorem w1540_3 : checkWitness 1540 true true 4691 = true := by decide +kernel
private theorem cases1540 : checkFour 1540 (604,4700,595,4691) = true := by
  simp only [checkFour, w1540_0, w1540_1, w1540_2, w1540_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1540 : Coverage 1540 1541 := checkList_sound (ws:=[(604,4700,595,4691)]) (by simpa only [checkList, Bool.and_true] using cases1540)
private theorem w1541_0 : checkWitness 1541 false false 168 = true := by decide +kernel
private theorem w1541_2 : checkWitness 1541 true false 168 = true := by decide +kernel
private theorem cases1541 : checkFour 1541 (168,0,168,0) = true := by
  simp only [checkFour, w1541_0, w1541_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1541 : Coverage 1541 1542 := checkList_sound (ws:=[(168,0,168,0)]) (by simpa only [checkList, Bool.and_true] using cases1541)
private theorem w1542_0 : checkWitness 1542 false false 559 = true := by decide +kernel
private theorem w1542_1 : checkWitness 1542 false true 4647 = true := by decide +kernel
private theorem w1542_2 : checkWitness 1542 true false 559 = true := by decide +kernel
private theorem w1542_3 : checkWitness 1542 true true 4647 = true := by decide +kernel
private theorem cases1542 : checkFour 1542 (559,4647,559,4647) = true := by
  simp only [checkFour, w1542_0, w1542_1, w1542_2, w1542_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1542 : Coverage 1542 1543 := checkList_sound (ws:=[(559,4647,559,4647)]) (by simpa only [checkList, Bool.and_true] using cases1542)
private theorem w1543_0 : checkWitness 1543 false false 8888 = true := by decide +kernel
private theorem w1543_2 : checkWitness 1543 true false 8879 = true := by decide +kernel
private theorem cases1543 : checkFour 1543 (8888,0,8879,0) = true := by
  simp only [checkFour, w1543_0, w1543_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1543 : Coverage 1543 1544 := checkList_sound (ws:=[(8888,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1543)
private theorem w1544_0 : checkWitness 1544 false false 92 = true := by decide +kernel
private theorem w1544_2 : checkWitness 1544 true false 92 = true := by decide +kernel
private theorem cases1544 : checkFour 1544 (92,0,92,0) = true := by
  simp only [checkFour, w1544_0, w1544_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1544 : Coverage 1544 1545 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1544)
private theorem w1545_0 : checkWitness 1545 false false 84 = true := by decide +kernel
private theorem w1545_2 : checkWitness 1545 true false 84 = true := by decide +kernel
private theorem cases1545 : checkFour 1545 (84,0,84,0) = true := by
  simp only [checkFour, w1545_0, w1545_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1545 : Coverage 1545 1546 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1545)
private theorem w1546_0 : checkWitness 1546 false false 565 = true := by decide +kernel
private theorem w1546_1 : checkWitness 1546 false true 4657 = true := by decide +kernel
private theorem w1546_2 : checkWitness 1546 true false 565 = true := by decide +kernel
private theorem w1546_3 : checkWitness 1546 true true 4657 = true := by decide +kernel
private theorem cases1546 : checkFour 1546 (565,4657,565,4657) = true := by
  simp only [checkFour, w1546_0, w1546_1, w1546_2, w1546_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1546 : Coverage 1546 1547 := checkList_sound (ws:=[(565,4657,565,4657)]) (by simpa only [checkList, Bool.and_true] using cases1546)
private theorem w1547_0 : checkWitness 1547 false false 8826 = true := by decide +kernel
private theorem w1547_2 : checkWitness 1547 true false 8822 = true := by decide +kernel
private theorem cases1547 : checkFour 1547 (8826,0,8822,0) = true := by
  simp only [checkFour, w1547_0, w1547_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1547 : Coverage 1547 1548 := checkList_sound (ws:=[(8826,0,8822,0)]) (by simpa only [checkList, Bool.and_true] using cases1547)
private theorem w1548_0 : checkWitness 1548 false false 84 = true := by decide +kernel
private theorem w1548_2 : checkWitness 1548 true false 84 = true := by decide +kernel
private theorem cases1548 : checkFour 1548 (84,0,84,0) = true := by
  simp only [checkFour, w1548_0, w1548_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1548 : Coverage 1548 1549 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1548)
private theorem w1549_0 : checkWitness 1549 false false 520 = true := by decide +kernel
private theorem w1549_1 : checkWitness 1549 false true 4616 = true := by decide +kernel
private theorem w1549_2 : checkWitness 1549 true false 520 = true := by decide +kernel
private theorem w1549_3 : checkWitness 1549 true true 4616 = true := by decide +kernel
private theorem cases1549 : checkFour 1549 (520,4616,520,4616) = true := by
  simp only [checkFour, w1549_0, w1549_1, w1549_2, w1549_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1549 : Coverage 1549 1550 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases1549)
private theorem w1550_0 : checkWitness 1550 false false 8861 = true := by decide +kernel
private theorem w1550_2 : checkWitness 1550 true false 8857 = true := by decide +kernel
private theorem cases1550 : checkFour 1550 (8861,0,8857,0) = true := by
  simp only [checkFour, w1550_0, w1550_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1550 : Coverage 1550 1551 := checkList_sound (ws:=[(8861,0,8857,0)]) (by simpa only [checkList, Bool.and_true] using cases1550)
private theorem w1551_0 : checkWitness 1551 false false 8896 = true := by decide +kernel
private theorem w1551_2 : checkWitness 1551 true false 8887 = true := by decide +kernel
private theorem cases1551 : checkFour 1551 (8896,0,8887,0) = true := by
  simp only [checkFour, w1551_0, w1551_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1551 : Coverage 1551 1552 := checkList_sound (ws:=[(8896,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases1551)
private theorem w1552_0 : checkWitness 1552 false false 102 = true := by decide +kernel
private theorem w1552_2 : checkWitness 1552 true false 102 = true := by decide +kernel
private theorem cases1552 : checkFour 1552 (102,0,102,0) = true := by
  simp only [checkFour, w1552_0, w1552_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1552 : Coverage 1552 1553 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1552)
private theorem w1553_0 : checkWitness 1553 false false 608 = true := by decide +kernel
private theorem w1553_1 : checkWitness 1553 false true 4700 = true := by decide +kernel
private theorem w1553_2 : checkWitness 1553 true false 599 = true := by decide +kernel
private theorem w1553_3 : checkWitness 1553 true true 4691 = true := by decide +kernel
private theorem cases1553 : checkFour 1553 (608,4700,599,4691) = true := by
  simp only [checkFour, w1553_0, w1553_1, w1553_2, w1553_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1553 : Coverage 1553 1554 := checkList_sound (ws:=[(608,4700,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases1553)
private theorem w1554_0 : checkWitness 1554 false false 8857 = true := by decide +kernel
private theorem w1554_2 : checkWitness 1554 true false 8853 = true := by decide +kernel
private theorem cases1554 : checkFour 1554 (8857,0,8853,0) = true := by
  simp only [checkFour, w1554_0, w1554_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1554 : Coverage 1554 1555 := checkList_sound (ws:=[(8857,0,8853,0)]) (by simpa only [checkList, Bool.and_true] using cases1554)
private theorem w1555_0 : checkWitness 1555 false false 602 = true := by decide +kernel
private theorem w1555_1 : checkWitness 1555 false true 4694 = true := by decide +kernel
private theorem w1555_2 : checkWitness 1555 true false 593 = true := by decide +kernel
private theorem w1555_3 : checkWitness 1555 true true 4685 = true := by decide +kernel
private theorem cases1555 : checkFour 1555 (602,4694,593,4685) = true := by
  simp only [checkFour, w1555_0, w1555_1, w1555_2, w1555_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1555 : Coverage 1555 1556 := checkList_sound (ws:=[(602,4694,593,4685)]) (by simpa only [checkList, Bool.and_true] using cases1555)
private theorem w1556_0 : checkWitness 1556 false false 8826 = true := by decide +kernel
private theorem w1556_2 : checkWitness 1556 true false 8822 = true := by decide +kernel
private theorem cases1556 : checkFour 1556 (8826,0,8822,0) = true := by
  simp only [checkFour, w1556_0, w1556_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1556 : Coverage 1556 1557 := checkList_sound (ws:=[(8826,0,8822,0)]) (by simpa only [checkList, Bool.and_true] using cases1556)
private theorem w1557_0 : checkWitness 1557 false false 90 = true := by decide +kernel
private theorem w1557_2 : checkWitness 1557 true false 90 = true := by decide +kernel
private theorem cases1557 : checkFour 1557 (90,0,90,0) = true := by
  simp only [checkFour, w1557_0, w1557_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1557 : Coverage 1557 1558 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1557)
private theorem w1558_0 : checkWitness 1558 false false 82 = true := by decide +kernel
private theorem w1558_2 : checkWitness 1558 true false 82 = true := by decide +kernel
private theorem cases1558 : checkFour 1558 (82,0,82,0) = true := by
  simp only [checkFour, w1558_0, w1558_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1558 : Coverage 1558 1559 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1558)
private theorem w1559_0 : checkWitness 1559 false false 569 = true := by decide +kernel
private theorem w1559_1 : checkWitness 1559 false true 4657 = true := by decide +kernel
private theorem w1559_2 : checkWitness 1559 true false 569 = true := by decide +kernel
private theorem w1559_3 : checkWitness 1559 true true 4657 = true := by decide +kernel
private theorem cases1559 : checkFour 1559 (569,4657,569,4657) = true := by
  simp only [checkFour, w1559_0, w1559_1, w1559_2, w1559_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1559 : Coverage 1559 1560 := checkList_sound (ws:=[(569,4657,569,4657)]) (by simpa only [checkList, Bool.and_true] using cases1559)
private theorem w1560_0 : checkWitness 1560 false false 8842 = true := by decide +kernel
private theorem w1560_2 : checkWitness 1560 true false 8838 = true := by decide +kernel
private theorem cases1560 : checkFour 1560 (8842,0,8838,0) = true := by
  simp only [checkFour, w1560_0, w1560_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1560 : Coverage 1560 1561 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1560)
private theorem w1561_0 : checkWitness 1561 false false 8838 = true := by decide +kernel
private theorem w1561_2 : checkWitness 1561 true false 8834 = true := by decide +kernel
private theorem cases1561 : checkFour 1561 (8838,0,8834,0) = true := by
  simp only [checkFour, w1561_0, w1561_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1561 : Coverage 1561 1562 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1561)
private theorem w1562_0 : checkWitness 1562 false false 96 = true := by decide +kernel
private theorem w1562_2 : checkWitness 1562 true false 96 = true := by decide +kernel
private theorem cases1562 : checkFour 1562 (96,0,96,0) = true := by
  simp only [checkFour, w1562_0, w1562_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1562 : Coverage 1562 1563 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1562)
private theorem w1563_0 : checkWitness 1563 false false 8850 = true := by decide +kernel
private theorem w1563_2 : checkWitness 1563 true false 8846 = true := by decide +kernel
private theorem cases1563 : checkFour 1563 (8850,0,8846,0) = true := by
  simp only [checkFour, w1563_0, w1563_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1563 : Coverage 1563 1564 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases1563)
private theorem w1564_0 : checkWitness 1564 false false 488 = true := by decide +kernel
private theorem w1564_1 : checkWitness 1564 false true 4584 = true := by decide +kernel
private theorem w1564_2 : checkWitness 1564 true false 488 = true := by decide +kernel
private theorem w1564_3 : checkWitness 1564 true true 4584 = true := by decide +kernel
private theorem cases1564 : checkFour 1564 (488,4584,488,4584) = true := by
  simp only [checkFour, w1564_0, w1564_1, w1564_2, w1564_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1564 : Coverage 1564 1565 := checkList_sound (ws:=[(488,4584,488,4584)]) (by simpa only [checkList, Bool.and_true] using cases1564)
private theorem w1565_0 : checkWitness 1565 false false 8883 = true := by decide +kernel
private theorem w1565_2 : checkWitness 1565 true false 8879 = true := by decide +kernel
private theorem cases1565 : checkFour 1565 (8883,0,8879,0) = true := by
  simp only [checkFour, w1565_0, w1565_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1565 : Coverage 1565 1566 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1565)
private theorem w1566_0 : checkWitness 1566 false false 614 = true := by decide +kernel
private theorem w1566_1 : checkWitness 1566 false true 4710 = true := by decide +kernel
private theorem w1566_2 : checkWitness 1566 true false 605 = true := by decide +kernel
private theorem w1566_3 : checkWitness 1566 true true 4701 = true := by decide +kernel
private theorem cases1566 : checkFour 1566 (614,4710,605,4701) = true := by
  simp only [checkFour, w1566_0, w1566_1, w1566_2, w1566_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1566 : Coverage 1566 1567 := checkList_sound (ws:=[(614,4710,605,4701)]) (by simpa only [checkList, Bool.and_true] using cases1566)
private theorem w1567_0 : checkWitness 1567 false false 172 = true := by decide +kernel
private theorem w1567_2 : checkWitness 1567 true false 172 = true := by decide +kernel
private theorem cases1567 : checkFour 1567 (172,0,172,0) = true := by
  simp only [checkFour, w1567_0, w1567_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1567 : Coverage 1567 1568 := checkList_sound (ws:=[(172,0,172,0)]) (by simpa only [checkList, Bool.and_true] using cases1567)
theorem cover1536 : Coverage 1536 1568 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1536 one1537) (Coverage.join one1538 one1539)) (Coverage.join (Coverage.join one1540 one1541) (Coverage.join one1542 one1543))) (Coverage.join (Coverage.join (Coverage.join one1544 one1545) (Coverage.join one1546 one1547)) (Coverage.join (Coverage.join one1548 one1549) (Coverage.join one1550 one1551)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1552 one1553) (Coverage.join one1554 one1555)) (Coverage.join (Coverage.join one1556 one1557) (Coverage.join one1558 one1559))) (Coverage.join (Coverage.join (Coverage.join one1560 one1561) (Coverage.join one1562 one1563)) (Coverage.join (Coverage.join one1564 one1565) (Coverage.join one1566 one1567)))))
end NF181PA.Symbolic
