import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w224_0 : checkWitness 224 false false 64 = true := by decide +kernel
private theorem w224_2 : checkWitness 224 true false 64 = true := by decide +kernel
private theorem cases224 : checkFour 224 (64,0,64,0) = true := by
  simp only [checkFour, w224_0, w224_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one224 : Coverage 224 225 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases224)
private theorem w225_0 : checkWitness 225 false false 506 = true := by decide +kernel
private theorem w225_1 : checkWitness 225 false true 4602 = true := by decide +kernel
private theorem w225_2 : checkWitness 225 true false 506 = true := by decide +kernel
private theorem w225_3 : checkWitness 225 true true 4602 = true := by decide +kernel
private theorem cases225 : checkFour 225 (506,4602,506,4602) = true := by
  simp only [checkFour, w225_0, w225_1, w225_2, w225_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one225 : Coverage 225 226 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases225)
private theorem w226_0 : checkWitness 226 false false 8864 = true := by decide +kernel
private theorem w226_2 : checkWitness 226 true false 8860 = true := by decide +kernel
private theorem cases226 : checkFour 226 (8864,0,8860,0) = true := by
  simp only [checkFour, w226_0, w226_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one226 : Coverage 226 227 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases226)
private theorem w227_0 : checkWitness 227 false false 66 = true := by decide +kernel
private theorem w227_2 : checkWitness 227 true false 66 = true := by decide +kernel
private theorem cases227 : checkFour 227 (66,0,66,0) = true := by
  simp only [checkFour, w227_0, w227_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one227 : Coverage 227 228 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases227)
private theorem w228_0 : checkWitness 228 false false 544 = true := by decide +kernel
private theorem w228_1 : checkWitness 228 false true 4640 = true := by decide +kernel
private theorem w228_2 : checkWitness 228 true false 544 = true := by decide +kernel
private theorem w228_3 : checkWitness 228 true true 4640 = true := by decide +kernel
private theorem cases228 : checkFour 228 (544,4640,544,4640) = true := by
  simp only [checkFour, w228_0, w228_1, w228_2, w228_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one228 : Coverage 228 229 := checkList_sound (ws:=[(544,4640,544,4640)]) (by simpa only [checkList, Bool.and_true] using cases228)
private theorem w229_0 : checkWitness 229 false false 8885 = true := by decide +kernel
private theorem w229_2 : checkWitness 229 true false 8881 = true := by decide +kernel
private theorem cases229 : checkFour 229 (8885,0,8881,0) = true := by
  simp only [checkFour, w229_0, w229_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one229 : Coverage 229 230 := checkList_sound (ws:=[(8885,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases229)
private theorem w230_0 : checkWitness 230 false false 8920 = true := by decide +kernel
private theorem w230_2 : checkWitness 230 true false 8911 = true := by decide +kernel
private theorem cases230 : checkFour 230 (8920,0,8911,0) = true := by
  simp only [checkFour, w230_0, w230_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one230 : Coverage 230 231 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases230)
private theorem w231_0 : checkWitness 231 false false 90 = true := by decide +kernel
private theorem w231_2 : checkWitness 231 true false 90 = true := by decide +kernel
private theorem cases231 : checkFour 231 (90,0,90,0) = true := by
  simp only [checkFour, w231_0, w231_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one231 : Coverage 231 232 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases231)
private theorem w232_0 : checkWitness 232 false false 632 = true := by decide +kernel
private theorem w232_1 : checkWitness 232 false true 4724 = true := by decide +kernel
private theorem w232_2 : checkWitness 232 true false 623 = true := by decide +kernel
private theorem w232_3 : checkWitness 232 true true 4715 = true := by decide +kernel
private theorem cases232 : checkFour 232 (632,4724,623,4715) = true := by
  simp only [checkFour, w232_0, w232_1, w232_2, w232_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one232 : Coverage 232 233 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases232)
private theorem w233_0 : checkWitness 233 false false 8881 = true := by decide +kernel
private theorem w233_2 : checkWitness 233 true false 8877 = true := by decide +kernel
private theorem cases233 : checkFour 233 (8881,0,8877,0) = true := by
  simp only [checkFour, w233_0, w233_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one233 : Coverage 233 234 := checkList_sound (ws:=[(8881,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases233)
private theorem w234_0 : checkWitness 234 false false 626 = true := by decide +kernel
private theorem w234_1 : checkWitness 234 false true 4718 = true := by decide +kernel
private theorem w234_2 : checkWitness 234 true false 617 = true := by decide +kernel
private theorem w234_3 : checkWitness 234 true true 4709 = true := by decide +kernel
private theorem cases234 : checkFour 234 (626,4718,617,4709) = true := by
  simp only [checkFour, w234_0, w234_1, w234_2, w234_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one234 : Coverage 234 235 := checkList_sound (ws:=[(626,4718,617,4709)]) (by simpa only [checkList, Bool.and_true] using cases234)
private theorem w235_0 : checkWitness 235 false false 8850 = true := by decide +kernel
private theorem w235_2 : checkWitness 235 true false 8846 = true := by decide +kernel
private theorem cases235 : checkFour 235 (8850,0,8846,0) = true := by
  simp only [checkFour, w235_0, w235_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one235 : Coverage 235 236 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases235)
private theorem w236_0 : checkWitness 236 false false 78 = true := by decide +kernel
private theorem w236_2 : checkWitness 236 true false 78 = true := by decide +kernel
private theorem cases236 : checkFour 236 (78,0,78,0) = true := by
  simp only [checkFour, w236_0, w236_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one236 : Coverage 236 237 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases236)
private theorem w237_0 : checkWitness 237 false false 70 = true := by decide +kernel
private theorem w237_2 : checkWitness 237 true false 70 = true := by decide +kernel
private theorem cases237 : checkFour 237 (70,0,70,0) = true := by
  simp only [checkFour, w237_0, w237_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one237 : Coverage 237 238 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases237)
private theorem w238_0 : checkWitness 238 false false 591 = true := by decide +kernel
private theorem w238_1 : checkWitness 238 false true 4675 = true := by decide +kernel
private theorem w238_2 : checkWitness 238 true false 591 = true := by decide +kernel
private theorem w238_3 : checkWitness 238 true true 4675 = true := by decide +kernel
private theorem cases238 : checkFour 238 (591,4675,591,4675) = true := by
  simp only [checkFour, w238_0, w238_1, w238_2, w238_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one238 : Coverage 238 239 := checkList_sound (ws:=[(591,4675,591,4675)]) (by simpa only [checkList, Bool.and_true] using cases238)
private theorem w239_0 : checkWitness 239 false false 8844 = true := by decide +kernel
private theorem w239_2 : checkWitness 239 true false 8840 = true := by decide +kernel
private theorem cases239 : checkFour 239 (8844,0,8840,0) = true := by
  simp only [checkFour, w239_0, w239_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one239 : Coverage 239 240 := checkList_sound (ws:=[(8844,0,8840,0)]) (by simpa only [checkList, Bool.and_true] using cases239)
private theorem w240_0 : checkWitness 240 false false 70 = true := by decide +kernel
private theorem w240_2 : checkWitness 240 true false 70 = true := by decide +kernel
private theorem cases240 : checkFour 240 (70,0,70,0) = true := by
  simp only [checkFour, w240_0, w240_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one240 : Coverage 240 241 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases240)
private theorem w241_0 : checkWitness 241 false false 596 = true := by decide +kernel
private theorem w241_1 : checkWitness 241 false true 4692 = true := by decide +kernel
private theorem w241_2 : checkWitness 241 true false 596 = true := by decide +kernel
private theorem w241_3 : checkWitness 241 true true 4692 = true := by decide +kernel
private theorem cases241 : checkFour 241 (596,4692,596,4692) = true := by
  simp only [checkFour, w241_0, w241_1, w241_2, w241_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one241 : Coverage 241 242 := checkList_sound (ws:=[(596,4692,596,4692)]) (by simpa only [checkList, Bool.and_true] using cases241)
private theorem w242_0 : checkWitness 242 false false 8912 = true := by decide +kernel
private theorem w242_2 : checkWitness 242 true false 8903 = true := by decide +kernel
private theorem cases242 : checkFour 242 (8912,0,8903,0) = true := by
  simp only [checkFour, w242_0, w242_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one242 : Coverage 242 243 := checkList_sound (ws:=[(8912,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases242)
private theorem w243_0 : checkWitness 243 false false 8858 = true := by decide +kernel
private theorem w243_2 : checkWitness 243 true false 8854 = true := by decide +kernel
private theorem cases243 : checkFour 243 (8858,0,8854,0) = true := by
  simp only [checkFour, w243_0, w243_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one243 : Coverage 243 244 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases243)
private theorem w244_0 : checkWitness 244 false false 78 = true := by decide +kernel
private theorem w244_2 : checkWitness 244 true false 78 = true := by decide +kernel
private theorem cases244 : checkFour 244 (78,0,78,0) = true := by
  simp only [checkFour, w244_0, w244_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one244 : Coverage 244 245 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases244)
private theorem w245_0 : checkWitness 245 false false 642 = true := by decide +kernel
private theorem w245_1 : checkWitness 245 false true 4730 = true := by decide +kernel
private theorem w245_2 : checkWitness 245 true false 633 = true := by decide +kernel
private theorem w245_3 : checkWitness 245 true true 4721 = true := by decide +kernel
private theorem cases245 : checkFour 245 (642,4730,633,4721) = true := by
  simp only [checkFour, w245_0, w245_1, w245_2, w245_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one245 : Coverage 245 246 := checkList_sound (ws:=[(642,4730,633,4721)]) (by simpa only [checkList, Bool.and_true] using cases245)
private theorem w246_0 : checkWitness 246 false false 8900 = true := by decide +kernel
private theorem w246_2 : checkWitness 246 true false 8896 = true := by decide +kernel
private theorem cases246 : checkFour 246 (8900,0,8896,0) = true := by
  simp only [checkFour, w246_0, w246_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one246 : Coverage 246 247 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases246)
private theorem w247_0 : checkWitness 247 false false 68 = true := by decide +kernel
private theorem w247_2 : checkWitness 247 true false 68 = true := by decide +kernel
private theorem cases247 : checkFour 247 (68,0,68,0) = true := by
  simp only [checkFour, w247_0, w247_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one247 : Coverage 247 248 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases247)
private theorem w248_0 : checkWitness 248 false false 504 = true := by decide +kernel
private theorem w248_1 : checkWitness 248 false true 4600 = true := by decide +kernel
private theorem w248_2 : checkWitness 248 true false 504 = true := by decide +kernel
private theorem w248_3 : checkWitness 248 true true 4600 = true := by decide +kernel
private theorem cases248 : checkFour 248 (504,4600,504,4600) = true := by
  simp only [checkFour, w248_0, w248_1, w248_2, w248_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one248 : Coverage 248 249 := checkList_sound (ws:=[(504,4600,504,4600)]) (by simpa only [checkList, Bool.and_true] using cases248)
private theorem w249_0 : checkWitness 249 false false 8899 = true := by decide +kernel
private theorem w249_2 : checkWitness 249 true false 8895 = true := by decide +kernel
private theorem cases249 : checkFour 249 (8899,0,8895,0) = true := by
  simp only [checkFour, w249_0, w249_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one249 : Coverage 249 250 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases249)
private theorem w250_0 : checkWitness 250 false false 630 = true := by decide +kernel
private theorem w250_1 : checkWitness 250 false true 4726 = true := by decide +kernel
private theorem w250_2 : checkWitness 250 true false 621 = true := by decide +kernel
private theorem w250_3 : checkWitness 250 true true 4717 = true := by decide +kernel
private theorem cases250 : checkFour 250 (630,4726,621,4717) = true := by
  simp only [checkFour, w250_0, w250_1, w250_2, w250_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one250 : Coverage 250 251 := checkList_sound (ws:=[(630,4726,621,4717)]) (by simpa only [checkList, Bool.and_true] using cases250)
private theorem w251_0 : checkWitness 251 false false 182 = true := by decide +kernel
private theorem w251_2 : checkWitness 251 true false 182 = true := by decide +kernel
private theorem cases251 : checkFour 251 (182,0,182,0) = true := by
  simp only [checkFour, w251_0, w251_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one251 : Coverage 251 252 := checkList_sound (ws:=[(182,0,182,0)]) (by simpa only [checkList, Bool.and_true] using cases251)
private theorem w252_0 : checkWitness 252 false false 585 = true := by decide +kernel
private theorem w252_1 : checkWitness 252 false true 4673 = true := by decide +kernel
private theorem w252_2 : checkWitness 252 true false 585 = true := by decide +kernel
private theorem w252_3 : checkWitness 252 true true 4673 = true := by decide +kernel
private theorem cases252 : checkFour 252 (585,4673,585,4673) = true := by
  simp only [checkFour, w252_0, w252_1, w252_2, w252_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one252 : Coverage 252 253 := checkList_sound (ws:=[(585,4673,585,4673)]) (by simpa only [checkList, Bool.and_true] using cases252)
private theorem w253_0 : checkWitness 253 false false 8914 = true := by decide +kernel
private theorem w253_2 : checkWitness 253 true false 8905 = true := by decide +kernel
private theorem cases253 : checkFour 253 (8914,0,8905,0) = true := by
  simp only [checkFour, w253_0, w253_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one253 : Coverage 253 254 := checkList_sound (ws:=[(8914,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases253)
private theorem w254_0 : checkWitness 254 false false 74 = true := by decide +kernel
private theorem w254_2 : checkWitness 254 true false 74 = true := by decide +kernel
private theorem cases254 : checkFour 254 (74,0,74,0) = true := by
  simp only [checkFour, w254_0, w254_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one254 : Coverage 254 255 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases254)
private theorem w255_0 : checkWitness 255 false false 66 = true := by decide +kernel
private theorem w255_2 : checkWitness 255 true false 66 = true := by decide +kernel
private theorem cases255 : checkFour 255 (66,0,66,0) = true := by
  simp only [checkFour, w255_0, w255_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one255 : Coverage 255 256 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases255)
theorem cover0224 : Coverage 224 256 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one224 one225) (Coverage.join one226 one227)) (Coverage.join (Coverage.join one228 one229) (Coverage.join one230 one231))) (Coverage.join (Coverage.join (Coverage.join one232 one233) (Coverage.join one234 one235)) (Coverage.join (Coverage.join one236 one237) (Coverage.join one238 one239)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one240 one241) (Coverage.join one242 one243)) (Coverage.join (Coverage.join one244 one245) (Coverage.join one246 one247))) (Coverage.join (Coverage.join (Coverage.join one248 one249) (Coverage.join one250 one251)) (Coverage.join (Coverage.join one252 one253) (Coverage.join one254 one255)))))
end NF181PA.Symbolic
