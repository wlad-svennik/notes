module
public import NF181PARegisters

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.RegisterSource (address)
namespace NF181PA.Boot
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- Removing any already executed prefix preserves an eventual terminal address.
Both the prefix and the time of the halt may be nonstandard. -/
theorem halts_after_prefix {origin margin : V}
    (hprefix : ∃ k : V, iterate Registers.next k origin = margin)
    (halt : ∃ t : V, address (iterate Registers.next t origin) = 4095) :
    ∃ t : V, address (iterate Registers.next t margin) = 4095 := by
  obtain ⟨k,rfl⟩ := hprefix
  obtain ⟨t,ht⟩ := halt
  refine ⟨t,?_⟩
  rw [←iterate_add,add_comm k t,iterate_add]
  induction k using modelInduct with
  | defP => definability
  | zero => simpa using ht
  | step i ih => rw [iterate_succ]; exact Registers.next_terminal _ ih

end NF181PA.Boot
#print axioms NF181PA.Boot.halts_after_prefix
