import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2784_0 : checkWitness 2784 false false 690 = true := by decide +kernel
private theorem w2784_1 : checkWitness 2784 false true 4782 = true := by decide +kernel
private theorem w2784_2 : checkWitness 2784 true false 681 = true := by decide +kernel
private theorem w2784_3 : checkWitness 2784 true true 4773 = true := by decide +kernel
private theorem cases2784 : checkFour 2784 (690,4782,681,4773) = true := by
  simp only [checkFour, w2784_0, w2784_1, w2784_2, w2784_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2784 : Coverage 2784 2785 := checkList_sound (ws:=[(690,4782,681,4773)]) (by simpa only [checkList, Bool.and_true] using cases2784)
private theorem w2785_0 : checkWitness 2785 false false 8914 = true := by decide +kernel
private theorem w2785_2 : checkWitness 2785 true false 8910 = true := by decide +kernel
private theorem cases2785 : checkFour 2785 (8914,0,8910,0) = true := by
  simp only [checkFour, w2785_0, w2785_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2785 : Coverage 2785 2786 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases2785)
private theorem w2786_0 : checkWitness 2786 false false 76 = true := by decide +kernel
private theorem w2786_2 : checkWitness 2786 true false 76 = true := by decide +kernel
private theorem cases2786 : checkFour 2786 (76,0,76,0) = true := by
  simp only [checkFour, w2786_0, w2786_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2786 : Coverage 2786 2787 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2786)
private theorem w2787_0 : checkWitness 2787 false false 68 = true := by decide +kernel
private theorem w2787_2 : checkWitness 2787 true false 68 = true := by decide +kernel
private theorem cases2787 : checkFour 2787 (68,0,68,0) = true := by
  simp only [checkFour, w2787_0, w2787_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2787 : Coverage 2787 2788 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2787)
private theorem w2788_0 : checkWitness 2788 false false 655 = true := by decide +kernel
private theorem w2788_1 : checkWitness 2788 false true 4739 = true := by decide +kernel
private theorem w2788_2 : checkWitness 2788 true false 655 = true := by decide +kernel
private theorem w2788_3 : checkWitness 2788 true true 4739 = true := by decide +kernel
private theorem cases2788 : checkFour 2788 (655,4739,655,4739) = true := by
  simp only [checkFour, w2788_0, w2788_1, w2788_2, w2788_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2788 : Coverage 2788 2789 := checkList_sound (ws:=[(655,4739,655,4739)]) (by simpa only [checkList, Bool.and_true] using cases2788)
private theorem w2789_0 : checkWitness 2789 false false 8908 = true := by decide +kernel
private theorem w2789_2 : checkWitness 2789 true false 8904 = true := by decide +kernel
private theorem cases2789 : checkFour 2789 (8908,0,8904,0) = true := by
  simp only [checkFour, w2789_0, w2789_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2789 : Coverage 2789 2790 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases2789)
private theorem w2790_0 : checkWitness 2790 false false 68 = true := by decide +kernel
private theorem w2790_2 : checkWitness 2790 true false 68 = true := by decide +kernel
private theorem cases2790 : checkFour 2790 (68,0,68,0) = true := by
  simp only [checkFour, w2790_0, w2790_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2790 : Coverage 2790 2791 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2790)
private theorem w2791_0 : checkWitness 2791 false false 653 = true := by decide +kernel
private theorem w2791_1 : checkWitness 2791 false true 4745 = true := by decide +kernel
private theorem w2791_2 : checkWitness 2791 true false 644 = true := by decide +kernel
private theorem w2791_3 : checkWitness 2791 true true 4736 = true := by decide +kernel
private theorem cases2791 : checkFour 2791 (653,4745,644,4736) = true := by
  simp only [checkFour, w2791_0, w2791_1, w2791_2, w2791_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2791 : Coverage 2791 2792 := checkList_sound (ws:=[(653,4745,644,4736)]) (by simpa only [checkList, Bool.and_true] using cases2791)
private theorem w2792_0 : checkWitness 2792 false false 8950 = true := by decide +kernel
private theorem w2792_2 : checkWitness 2792 true false 8941 = true := by decide +kernel
private theorem cases2792 : checkFour 2792 (8950,0,8941,0) = true := by
  simp only [checkFour, w2792_0, w2792_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2792 : Coverage 2792 2793 := checkList_sound (ws:=[(8950,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2792)
private theorem w2793_0 : checkWitness 2793 false false 8896 = true := by decide +kernel
private theorem w2793_2 : checkWitness 2793 true false 8892 = true := by decide +kernel
private theorem cases2793 : checkFour 2793 (8896,0,8892,0) = true := by
  simp only [checkFour, w2793_0, w2793_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2793 : Coverage 2793 2794 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases2793)
private theorem w2794_0 : checkWitness 2794 false false 62 = true := by decide +kernel
private theorem w2794_2 : checkWitness 2794 true false 62 = true := by decide +kernel
private theorem cases2794 : checkFour 2794 (62,0,62,0) = true := by
  simp only [checkFour, w2794_0, w2794_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2794 : Coverage 2794 2795 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2794)
private theorem w2795_0 : checkWitness 2795 false false 680 = true := by decide +kernel
private theorem w2795_1 : checkWitness 2795 false true 4772 = true := by decide +kernel
private theorem w2795_2 : checkWitness 2795 true false 671 = true := by decide +kernel
private theorem w2795_3 : checkWitness 2795 true true 4763 = true := by decide +kernel
private theorem cases2795 : checkFour 2795 (680,4772,671,4763) = true := by
  simp only [checkFour, w2795_0, w2795_1, w2795_2, w2795_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2795 : Coverage 2795 2796 := checkList_sound (ws:=[(680,4772,671,4763)]) (by simpa only [checkList, Bool.and_true] using cases2795)
private theorem w2796_0 : checkWitness 2796 false false 8957 = true := by decide +kernel
private theorem w2796_2 : checkWitness 2796 true false 8948 = true := by decide +kernel
private theorem cases2796 : checkFour 2796 (8957,0,8948,0) = true := by
  simp only [checkFour, w2796_0, w2796_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2796 : Coverage 2796 2797 := checkList_sound (ws:=[(8957,0,8948,0)]) (by simpa only [checkList, Bool.and_true] using cases2796)
private theorem w2797_0 : checkWitness 2797 false false 46 = true := by decide +kernel
private theorem w2797_2 : checkWitness 2797 true false 46 = true := by decide +kernel
private theorem cases2797 : checkFour 2797 (46,0,46,0) = true := by
  simp only [checkFour, w2797_0, w2797_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2797 : Coverage 2797 2798 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2797)
private theorem w2798_0 : checkWitness 2798 false false 544 = true := by decide +kernel
private theorem w2798_1 : checkWitness 2798 false true 4640 = true := by decide +kernel
private theorem w2798_2 : checkWitness 2798 true false 544 = true := by decide +kernel
private theorem w2798_3 : checkWitness 2798 true true 4640 = true := by decide +kernel
private theorem cases2798 : checkFour 2798 (544,4640,544,4640) = true := by
  simp only [checkFour, w2798_0, w2798_1, w2798_2, w2798_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2798 : Coverage 2798 2799 := checkList_sound (ws:=[(544,4640,544,4640)]) (by simpa only [checkList, Bool.and_true] using cases2798)
private theorem w2799_0 : checkWitness 2799 false false 8939 = true := by decide +kernel
private theorem w2799_2 : checkWitness 2799 true false 8935 = true := by decide +kernel
private theorem cases2799 : checkFour 2799 (8939,0,8935,0) = true := by
  simp only [checkFour, w2799_0, w2799_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2799 : Coverage 2799 2800 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2799)
private theorem w2800_0 : checkWitness 2800 false false 670 = true := by decide +kernel
private theorem w2800_1 : checkWitness 2800 false true 4766 = true := by decide +kernel
private theorem w2800_2 : checkWitness 2800 true false 661 = true := by decide +kernel
private theorem w2800_3 : checkWitness 2800 true true 4757 = true := by decide +kernel
private theorem cases2800 : checkFour 2800 (670,4766,661,4757) = true := by
  simp only [checkFour, w2800_0, w2800_1, w2800_2, w2800_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2800 : Coverage 2800 2801 := checkList_sound (ws:=[(670,4766,661,4757)]) (by simpa only [checkList, Bool.and_true] using cases2800)
private theorem w2801_0 : checkWitness 2801 false false 200 = true := by decide +kernel
private theorem w2801_2 : checkWitness 2801 true false 200 = true := by decide +kernel
private theorem cases2801 : checkFour 2801 (200,0,200,0) = true := by
  simp only [checkFour, w2801_0, w2801_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2801 : Coverage 2801 2802 := checkList_sound (ws:=[(200,0,200,0)]) (by simpa only [checkList, Bool.and_true] using cases2801)
private theorem w2802_0 : checkWitness 2802 false false 625 = true := by decide +kernel
private theorem w2802_1 : checkWitness 2802 false true 4713 = true := by decide +kernel
private theorem w2802_2 : checkWitness 2802 true false 625 = true := by decide +kernel
private theorem w2802_3 : checkWitness 2802 true true 4713 = true := by decide +kernel
private theorem cases2802 : checkFour 2802 (625,4713,625,4713) = true := by
  simp only [checkFour, w2802_0, w2802_1, w2802_2, w2802_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2802 : Coverage 2802 2803 := checkList_sound (ws:=[(625,4713,625,4713)]) (by simpa only [checkList, Bool.and_true] using cases2802)
private theorem w2803_0 : checkWitness 2803 false false 8954 = true := by decide +kernel
private theorem w2803_2 : checkWitness 2803 true false 8945 = true := by decide +kernel
private theorem cases2803 : checkFour 2803 (8954,0,8945,0) = true := by
  simp only [checkFour, w2803_0, w2803_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2803 : Coverage 2803 2804 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2803)
private theorem w2804_0 : checkWitness 2804 false false 64 = true := by decide +kernel
private theorem w2804_2 : checkWitness 2804 true false 64 = true := by decide +kernel
private theorem cases2804 : checkFour 2804 (64,0,64,0) = true := by
  simp only [checkFour, w2804_0, w2804_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2804 : Coverage 2804 2805 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2804)
private theorem w2805_0 : checkWitness 2805 false false 56 = true := by decide +kernel
private theorem w2805_2 : checkWitness 2805 true false 56 = true := by decide +kernel
private theorem cases2805 : checkFour 2805 (56,0,56,0) = true := by
  simp only [checkFour, w2805_0, w2805_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2805 : Coverage 2805 2806 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2805)
private theorem w2806_0 : checkWitness 2806 false false 631 = true := by decide +kernel
private theorem w2806_1 : checkWitness 2806 false true 4723 = true := by decide +kernel
private theorem w2806_2 : checkWitness 2806 true false 631 = true := by decide +kernel
private theorem w2806_3 : checkWitness 2806 true true 4723 = true := by decide +kernel
private theorem cases2806 : checkFour 2806 (631,4723,631,4723) = true := by
  simp only [checkFour, w2806_0, w2806_1, w2806_2, w2806_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2806 : Coverage 2806 2807 := checkList_sound (ws:=[(631,4723,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases2806)
private theorem w2807_0 : checkWitness 2807 false false 8892 = true := by decide +kernel
private theorem w2807_2 : checkWitness 2807 true false 8888 = true := by decide +kernel
private theorem cases2807 : checkFour 2807 (8892,0,8888,0) = true := by
  simp only [checkFour, w2807_0, w2807_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2807 : Coverage 2807 2808 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2807)
private theorem w2808_0 : checkWitness 2808 false false 56 = true := by decide +kernel
private theorem w2808_2 : checkWitness 2808 true false 56 = true := by decide +kernel
private theorem cases2808 : checkFour 2808 (56,0,56,0) = true := by
  simp only [checkFour, w2808_0, w2808_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2808 : Coverage 2808 2809 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2808)
private theorem w2809_0 : checkWitness 2809 false false 586 = true := by decide +kernel
private theorem w2809_1 : checkWitness 2809 false true 4682 = true := by decide +kernel
private theorem w2809_2 : checkWitness 2809 true false 586 = true := by decide +kernel
private theorem w2809_3 : checkWitness 2809 true true 4682 = true := by decide +kernel
private theorem cases2809 : checkFour 2809 (586,4682,586,4682) = true := by
  simp only [checkFour, w2809_0, w2809_1, w2809_2, w2809_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2809 : Coverage 2809 2810 := checkList_sound (ws:=[(586,4682,586,4682)]) (by simpa only [checkList, Bool.and_true] using cases2809)
private theorem w2810_0 : checkWitness 2810 false false 8927 = true := by decide +kernel
private theorem w2810_2 : checkWitness 2810 true false 8923 = true := by decide +kernel
private theorem cases2810 : checkFour 2810 (8927,0,8923,0) = true := by
  simp only [checkFour, w2810_0, w2810_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2810 : Coverage 2810 2811 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases2810)
private theorem w2811_0 : checkWitness 2811 false false 8962 = true := by decide +kernel
private theorem w2811_2 : checkWitness 2811 true false 8953 = true := by decide +kernel
private theorem cases2811 : checkFour 2811 (8962,0,8953,0) = true := by
  simp only [checkFour, w2811_0, w2811_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2811 : Coverage 2811 2812 := checkList_sound (ws:=[(8962,0,8953,0)]) (by simpa only [checkList, Bool.and_true] using cases2811)
private theorem w2812_0 : checkWitness 2812 false false 74 = true := by decide +kernel
private theorem w2812_2 : checkWitness 2812 true false 74 = true := by decide +kernel
private theorem cases2812 : checkFour 2812 (74,0,74,0) = true := by
  simp only [checkFour, w2812_0, w2812_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2812 : Coverage 2812 2813 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2812)
private theorem w2813_0 : checkWitness 2813 false false 674 = true := by decide +kernel
private theorem w2813_1 : checkWitness 2813 false true 4766 = true := by decide +kernel
private theorem w2813_2 : checkWitness 2813 true false 665 = true := by decide +kernel
private theorem w2813_3 : checkWitness 2813 true true 4757 = true := by decide +kernel
private theorem cases2813 : checkFour 2813 (674,4766,665,4757) = true := by
  simp only [checkFour, w2813_0, w2813_1, w2813_2, w2813_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2813 : Coverage 2813 2814 := checkList_sound (ws:=[(674,4766,665,4757)]) (by simpa only [checkList, Bool.and_true] using cases2813)
private theorem w2814_0 : checkWitness 2814 false false 8923 = true := by decide +kernel
private theorem w2814_2 : checkWitness 2814 true false 8919 = true := by decide +kernel
private theorem cases2814 : checkFour 2814 (8923,0,8919,0) = true := by
  simp only [checkFour, w2814_0, w2814_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2814 : Coverage 2814 2815 := checkList_sound (ws:=[(8923,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases2814)
private theorem w2815_0 : checkWitness 2815 false false 668 = true := by decide +kernel
private theorem w2815_1 : checkWitness 2815 false true 4760 = true := by decide +kernel
private theorem w2815_2 : checkWitness 2815 true false 659 = true := by decide +kernel
private theorem w2815_3 : checkWitness 2815 true true 4751 = true := by decide +kernel
private theorem cases2815 : checkFour 2815 (668,4760,659,4751) = true := by
  simp only [checkFour, w2815_0, w2815_1, w2815_2, w2815_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2815 : Coverage 2815 2816 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases2815)
theorem cover2784 : Coverage 2784 2816 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2784 one2785) (Coverage.join one2786 one2787)) (Coverage.join (Coverage.join one2788 one2789) (Coverage.join one2790 one2791))) (Coverage.join (Coverage.join (Coverage.join one2792 one2793) (Coverage.join one2794 one2795)) (Coverage.join (Coverage.join one2796 one2797) (Coverage.join one2798 one2799)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2800 one2801) (Coverage.join one2802 one2803)) (Coverage.join (Coverage.join one2804 one2805) (Coverage.join one2806 one2807))) (Coverage.join (Coverage.join (Coverage.join one2808 one2809) (Coverage.join one2810 one2811)) (Coverage.join (Coverage.join one2812 one2813) (Coverage.join one2814 one2815)))))
end NF181PA.Symbolic
