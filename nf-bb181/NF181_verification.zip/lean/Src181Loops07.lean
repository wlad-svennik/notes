module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site1740Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1740 f r x y z) (slots710.atReg 1744 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1740 4 1744 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1740 1744 1741 f r (row_of_literal 1740 _ (by decide) RawRows.raw1740))
    (slots710.pos_x 1740 1744 1741 f r (row_of_literal 1740 _ (by decide) RawRows.raw1740))
    (slots710.inc_y 1741 1742 f r (row_of_literal 1741 _ (by decide) RawRows.raw1741) (Or.inl (by decide)))
    (slots710.inc_y 1742 1743 f r (row_of_literal 1742 _ (by decide) RawRows.raw1742) (Or.inl (by decide)))
    (slots710.jump 1743 1740 f r (row_of_literal 1743 _ (by decide) RawRows.raw1743))

theorem site1740 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1740:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1744:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1740Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1744 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1744:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1745:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1744 _ (row_of_literal 1744 _ (by decide) RawRows.raw1744)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1745Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1745 f r x y z) (slots160.atReg 1748 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1745 3 1748 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1745 1748 1746 f r (row_of_literal 1745 _ (by decide) RawRows.raw1745))
    (slots160.pos_x 1745 1748 1746 f r (row_of_literal 1745 _ (by decide) RawRows.raw1745))
    (slots160.inc_y 1746 1747 f r (row_of_literal 1746 _ (by decide) RawRows.raw1746) (Or.inl (by decide)))
    (slots160.jump 1747 1745 f r (row_of_literal 1747 _ (by decide) RawRows.raw1747))

theorem site1745 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1745:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1748:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1745Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1748Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1748 f r x y z) (slots210.atReg 1751 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1748 3 1751 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1748 1751 1749 f r (row_of_literal 1748 _ (by decide) RawRows.raw1748))
    (slots210.pos_x 1748 1751 1749 f r (row_of_literal 1748 _ (by decide) RawRows.raw1748))
    (slots210.inc_y 1749 1750 f r (row_of_literal 1749 _ (by decide) RawRows.raw1749) (Or.inl (by decide)))
    (slots210.jump 1750 1748 f r (row_of_literal 1750 _ (by decide) RawRows.raw1750))

theorem site1748 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1748:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1751:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1748Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1751Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1751 f r x y z) (slots617.atReg 1761 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1751 10 1761 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1751 1755 1752 f r (row_of_literal 1751 _ (by decide) RawRows.raw1751))
    (slots617.pos_y 1751 1755 1752 f r (row_of_literal 1751 _ (by decide) RawRows.raw1751))
    (slots617.inc_z 1752 1753 f r (row_of_literal 1752 _ (by decide) RawRows.raw1752) (Or.inl (by decide)))
    (slots617.inc_x 1753 1754 f r (row_of_literal 1753 _ (by decide) RawRows.raw1753) (Or.inl (by decide)))
    (slots617.jump 1754 1751 f r (row_of_literal 1754 _ (by decide) RawRows.raw1754))
    (slots617.zero_x 1755 1761 1756 f r (row_of_literal 1755 _ (by decide) RawRows.raw1755))
    (slots617.pos_x 1755 1761 1756 f r (row_of_literal 1755 _ (by decide) RawRows.raw1755))
    (slots617.inc_z 1756 1757 f r (row_of_literal 1756 _ (by decide) RawRows.raw1756) (Or.inl (by decide)))
    (slots617.zero_x 1757 1760 1758 f r (row_of_literal 1757 _ (by decide) RawRows.raw1757))
    (slots617.pos_x 1757 1760 1758 f r (row_of_literal 1757 _ (by decide) RawRows.raw1757))
    (slots617.inc_y 1758 1759 f r (row_of_literal 1758 _ (by decide) RawRows.raw1758) (Or.inl (by decide)))
    (slots617.jump 1759 1757 f r (row_of_literal 1759 _ (by decide) RawRows.raw1759))
    (slots617.jump 1760 1751 f r (row_of_literal 1760 _ (by decide) RawRows.raw1760))

theorem site1751 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1751:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1761:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1751Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1761Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1761 f r x y z) (slots720.atReg 1764 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1761 3 1764 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1761 1764 1762 f r (row_of_literal 1761 _ (by decide) RawRows.raw1761))
    (slots720.pos_x 1761 1764 1762 f r (row_of_literal 1761 _ (by decide) RawRows.raw1761))
    (slots720.inc_y 1762 1763 f r (row_of_literal 1762 _ (by decide) RawRows.raw1762) (Or.inl (by decide)))
    (slots720.jump 1763 1761 f r (row_of_literal 1763 _ (by decide) RawRows.raw1763))

theorem site1761 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1761:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1764:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1761Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1764Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1764 f r x y z) (slots461.atReg 1768 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1764 4 1768 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1764 1768 1765 f r (row_of_literal 1764 _ (by decide) RawRows.raw1764))
    (slots461.pos_x 1764 1768 1765 f r (row_of_literal 1764 _ (by decide) RawRows.raw1764))
    (slots461.inc_y 1765 1766 f r (row_of_literal 1765 _ (by decide) RawRows.raw1765) (Or.inl (by decide)))
    (slots461.inc_z 1766 1767 f r (row_of_literal 1766 _ (by decide) RawRows.raw1766) (Or.inl (by decide)))
    (slots461.jump 1767 1764 f r (row_of_literal 1767 _ (by decide) RawRows.raw1767))

theorem site1764 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1764:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1768:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1764Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site1768Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1768 f r x y z) (slots640.atReg 1771 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1768 3 1771 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1768 1771 1769 f r (row_of_literal 1768 _ (by decide) RawRows.raw1768))
    (slots640.pos_x 1768 1771 1769 f r (row_of_literal 1768 _ (by decide) RawRows.raw1768))
    (slots640.inc_y 1769 1770 f r (row_of_literal 1769 _ (by decide) RawRows.raw1769) (Or.inl (by decide)))
    (slots640.jump 1770 1768 f r (row_of_literal 1770 _ (by decide) RawRows.raw1770))

theorem site1768 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1768:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1771:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1768Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site1771Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1771 f r x y z) (slots160.atReg 1774 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1771 3 1774 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1771 1774 1772 f r (row_of_literal 1771 _ (by decide) RawRows.raw1771))
    (slots160.pos_x 1771 1774 1772 f r (row_of_literal 1771 _ (by decide) RawRows.raw1771))
    (slots160.inc_y 1772 1773 f r (row_of_literal 1772 _ (by decide) RawRows.raw1772) (Or.inl (by decide)))
    (slots160.jump 1773 1771 f r (row_of_literal 1773 _ (by decide) RawRows.raw1773))

theorem site1771 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1771:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1774:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1771Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1774Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1774 f r x y z) (slots210.atReg 1777 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1774 3 1777 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1774 1777 1775 f r (row_of_literal 1774 _ (by decide) RawRows.raw1774))
    (slots210.pos_x 1774 1777 1775 f r (row_of_literal 1774 _ (by decide) RawRows.raw1774))
    (slots210.inc_y 1775 1776 f r (row_of_literal 1775 _ (by decide) RawRows.raw1775) (Or.inl (by decide)))
    (slots210.jump 1776 1774 f r (row_of_literal 1776 _ (by decide) RawRows.raw1776))

theorem site1774 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1774:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1777:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1774Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1777Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1777 f r x y z) (slots617.atReg 1787 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1777 10 1787 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1777 1781 1778 f r (row_of_literal 1777 _ (by decide) RawRows.raw1777))
    (slots617.pos_y 1777 1781 1778 f r (row_of_literal 1777 _ (by decide) RawRows.raw1777))
    (slots617.inc_z 1778 1779 f r (row_of_literal 1778 _ (by decide) RawRows.raw1778) (Or.inl (by decide)))
    (slots617.inc_x 1779 1780 f r (row_of_literal 1779 _ (by decide) RawRows.raw1779) (Or.inl (by decide)))
    (slots617.jump 1780 1777 f r (row_of_literal 1780 _ (by decide) RawRows.raw1780))
    (slots617.zero_x 1781 1787 1782 f r (row_of_literal 1781 _ (by decide) RawRows.raw1781))
    (slots617.pos_x 1781 1787 1782 f r (row_of_literal 1781 _ (by decide) RawRows.raw1781))
    (slots617.inc_z 1782 1783 f r (row_of_literal 1782 _ (by decide) RawRows.raw1782) (Or.inl (by decide)))
    (slots617.zero_x 1783 1786 1784 f r (row_of_literal 1783 _ (by decide) RawRows.raw1783))
    (slots617.pos_x 1783 1786 1784 f r (row_of_literal 1783 _ (by decide) RawRows.raw1783))
    (slots617.inc_y 1784 1785 f r (row_of_literal 1784 _ (by decide) RawRows.raw1784) (Or.inl (by decide)))
    (slots617.jump 1785 1783 f r (row_of_literal 1785 _ (by decide) RawRows.raw1785))
    (slots617.jump 1786 1777 f r (row_of_literal 1786 _ (by decide) RawRows.raw1786))

theorem site1777 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1777:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1787:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1777Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1787Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1787 f r x y z) (slots720.atReg 1790 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1787 3 1790 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1787 1790 1788 f r (row_of_literal 1787 _ (by decide) RawRows.raw1787))
    (slots720.pos_x 1787 1790 1788 f r (row_of_literal 1787 _ (by decide) RawRows.raw1787))
    (slots720.inc_y 1788 1789 f r (row_of_literal 1788 _ (by decide) RawRows.raw1788) (Or.inl (by decide)))
    (slots720.jump 1789 1787 f r (row_of_literal 1789 _ (by decide) RawRows.raw1789))

theorem site1787 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1787:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1790:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1787Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1790Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1790 f r x y z) (slots561.atReg 1794 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1790 4 1794 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1790 1794 1791 f r (row_of_literal 1790 _ (by decide) RawRows.raw1790))
    (slots561.pos_x 1790 1794 1791 f r (row_of_literal 1790 _ (by decide) RawRows.raw1790))
    (slots561.inc_y 1791 1792 f r (row_of_literal 1791 _ (by decide) RawRows.raw1791) (Or.inl (by decide)))
    (slots561.inc_z 1792 1793 f r (row_of_literal 1792 _ (by decide) RawRows.raw1792) (Or.inl (by decide)))
    (slots561.jump 1793 1790 f r (row_of_literal 1793 _ (by decide) RawRows.raw1793))

theorem site1790 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1790:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1794:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1790Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1794Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1794 f r x y z) (slots650.atReg 1797 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1794 3 1797 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1794 1797 1795 f r (row_of_literal 1794 _ (by decide) RawRows.raw1794))
    (slots650.pos_x 1794 1797 1795 f r (row_of_literal 1794 _ (by decide) RawRows.raw1794))
    (slots650.inc_y 1795 1796 f r (row_of_literal 1795 _ (by decide) RawRows.raw1795) (Or.inl (by decide)))
    (slots650.jump 1796 1794 f r (row_of_literal 1796 _ (by decide) RawRows.raw1796))

theorem site1794 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1794:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1797:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1794Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1797Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1797 f r x y z) (slots267.atReg 1805 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1797 8 1805 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1797 1805 1798 f r (row_of_literal 1797 _ (by decide) RawRows.raw1797))
    (slots267.pos_x 1797 1805 1798 f r (row_of_literal 1797 _ (by decide) RawRows.raw1797))
    (slots267.inc_z 1798 1799 f r (row_of_literal 1798 _ (by decide) RawRows.raw1798) (Or.inl (by decide)))
    (slots267.zero_y 1799 1801 1800 f r (row_of_literal 1799 _ (by decide) RawRows.raw1799))
    (slots267.pos_y 1799 1801 1800 f r (row_of_literal 1799 _ (by decide) RawRows.raw1799))
    (slots267.jump 1800 1804 f r (row_of_literal 1800 _ (by decide) RawRows.raw1800))
    (slots267.zero_z 1801 1804 1802 f r (row_of_literal 1801 _ (by decide) RawRows.raw1801))
    (slots267.pos_z 1801 1804 1802 f r (row_of_literal 1801 _ (by decide) RawRows.raw1801))
    (slots267.inc_y 1802 1803 f r (row_of_literal 1802 _ (by decide) RawRows.raw1802) (Or.inl (by decide)))
    (slots267.jump 1803 1801 f r (row_of_literal 1803 _ (by decide) RawRows.raw1803))
    (slots267.jump 1804 1797 f r (row_of_literal 1804 _ (by decide) RawRows.raw1804))

theorem site1797 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1797:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1805:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1797Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1805Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1805 f r x y z) (slots720.atReg 1808 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1805 3 1808 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1805 1808 1806 f r (row_of_literal 1805 _ (by decide) RawRows.raw1805))
    (slots720.pos_x 1805 1808 1806 f r (row_of_literal 1805 _ (by decide) RawRows.raw1805))
    (slots720.inc_y 1806 1807 f r (row_of_literal 1806 _ (by decide) RawRows.raw1806) (Or.inl (by decide)))
    (slots720.jump 1807 1805 f r (row_of_literal 1807 _ (by decide) RawRows.raw1807))

theorem site1805 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1805:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1808:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1805Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1808Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1808 f r x y z) (slots617.atReg 1818 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1808 10 1818 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1808 1812 1809 f r (row_of_literal 1808 _ (by decide) RawRows.raw1808))
    (slots617.pos_y 1808 1812 1809 f r (row_of_literal 1808 _ (by decide) RawRows.raw1808))
    (slots617.inc_z 1809 1810 f r (row_of_literal 1809 _ (by decide) RawRows.raw1809) (Or.inl (by decide)))
    (slots617.inc_x 1810 1811 f r (row_of_literal 1810 _ (by decide) RawRows.raw1810) (Or.inl (by decide)))
    (slots617.jump 1811 1808 f r (row_of_literal 1811 _ (by decide) RawRows.raw1811))
    (slots617.zero_x 1812 1818 1813 f r (row_of_literal 1812 _ (by decide) RawRows.raw1812))
    (slots617.pos_x 1812 1818 1813 f r (row_of_literal 1812 _ (by decide) RawRows.raw1812))
    (slots617.inc_z 1813 1814 f r (row_of_literal 1813 _ (by decide) RawRows.raw1813) (Or.inl (by decide)))
    (slots617.zero_x 1814 1817 1815 f r (row_of_literal 1814 _ (by decide) RawRows.raw1814))
    (slots617.pos_x 1814 1817 1815 f r (row_of_literal 1814 _ (by decide) RawRows.raw1814))
    (slots617.inc_y 1815 1816 f r (row_of_literal 1815 _ (by decide) RawRows.raw1815) (Or.inl (by decide)))
    (slots617.jump 1816 1814 f r (row_of_literal 1816 _ (by decide) RawRows.raw1816))
    (slots617.jump 1817 1808 f r (row_of_literal 1817 _ (by decide) RawRows.raw1817))

theorem site1808 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1808:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1818:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1808Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1818Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1818 f r x y z) (slots710.atReg 1822 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1818 4 1822 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1818 1822 1819 f r (row_of_literal 1818 _ (by decide) RawRows.raw1818))
    (slots710.pos_x 1818 1822 1819 f r (row_of_literal 1818 _ (by decide) RawRows.raw1818))
    (slots710.inc_y 1819 1820 f r (row_of_literal 1819 _ (by decide) RawRows.raw1819) (Or.inl (by decide)))
    (slots710.inc_y 1820 1821 f r (row_of_literal 1820 _ (by decide) RawRows.raw1820) (Or.inl (by decide)))
    (slots710.jump 1821 1818 f r (row_of_literal 1821 _ (by decide) RawRows.raw1821))

theorem site1818 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1818:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1822:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1818Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1822 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1822:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1823:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1822 _ (row_of_literal 1822 _ (by decide) RawRows.raw1822)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1823Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1823 f r x y z) (slots267.atReg 1831 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1823 8 1831 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1823 1831 1824 f r (row_of_literal 1823 _ (by decide) RawRows.raw1823))
    (slots267.pos_x 1823 1831 1824 f r (row_of_literal 1823 _ (by decide) RawRows.raw1823))
    (slots267.inc_z 1824 1825 f r (row_of_literal 1824 _ (by decide) RawRows.raw1824) (Or.inl (by decide)))
    (slots267.zero_y 1825 1827 1826 f r (row_of_literal 1825 _ (by decide) RawRows.raw1825))
    (slots267.pos_y 1825 1827 1826 f r (row_of_literal 1825 _ (by decide) RawRows.raw1825))
    (slots267.jump 1826 1830 f r (row_of_literal 1826 _ (by decide) RawRows.raw1826))
    (slots267.zero_z 1827 1830 1828 f r (row_of_literal 1827 _ (by decide) RawRows.raw1827))
    (slots267.pos_z 1827 1830 1828 f r (row_of_literal 1827 _ (by decide) RawRows.raw1827))
    (slots267.inc_y 1828 1829 f r (row_of_literal 1828 _ (by decide) RawRows.raw1828) (Or.inl (by decide)))
    (slots267.jump 1829 1827 f r (row_of_literal 1829 _ (by decide) RawRows.raw1829))
    (slots267.jump 1830 1823 f r (row_of_literal 1830 _ (by decide) RawRows.raw1830))

theorem site1823 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1823:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1831:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1823Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1831Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1831 f r x y z) (slots720.atReg 1834 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1831 3 1834 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1831 1834 1832 f r (row_of_literal 1831 _ (by decide) RawRows.raw1831))
    (slots720.pos_x 1831 1834 1832 f r (row_of_literal 1831 _ (by decide) RawRows.raw1831))
    (slots720.inc_y 1832 1833 f r (row_of_literal 1832 _ (by decide) RawRows.raw1832) (Or.inl (by decide)))
    (slots720.jump 1833 1831 f r (row_of_literal 1833 _ (by decide) RawRows.raw1833))

theorem site1831 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1831:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1834:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1831Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1834Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1834 f r x y z) (slots617.atReg 1844 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1834 10 1844 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1834 1838 1835 f r (row_of_literal 1834 _ (by decide) RawRows.raw1834))
    (slots617.pos_y 1834 1838 1835 f r (row_of_literal 1834 _ (by decide) RawRows.raw1834))
    (slots617.inc_z 1835 1836 f r (row_of_literal 1835 _ (by decide) RawRows.raw1835) (Or.inl (by decide)))
    (slots617.inc_x 1836 1837 f r (row_of_literal 1836 _ (by decide) RawRows.raw1836) (Or.inl (by decide)))
    (slots617.jump 1837 1834 f r (row_of_literal 1837 _ (by decide) RawRows.raw1837))
    (slots617.zero_x 1838 1844 1839 f r (row_of_literal 1838 _ (by decide) RawRows.raw1838))
    (slots617.pos_x 1838 1844 1839 f r (row_of_literal 1838 _ (by decide) RawRows.raw1838))
    (slots617.inc_z 1839 1840 f r (row_of_literal 1839 _ (by decide) RawRows.raw1839) (Or.inl (by decide)))
    (slots617.zero_x 1840 1843 1841 f r (row_of_literal 1840 _ (by decide) RawRows.raw1840))
    (slots617.pos_x 1840 1843 1841 f r (row_of_literal 1840 _ (by decide) RawRows.raw1840))
    (slots617.inc_y 1841 1842 f r (row_of_literal 1841 _ (by decide) RawRows.raw1841) (Or.inl (by decide)))
    (slots617.jump 1842 1840 f r (row_of_literal 1842 _ (by decide) RawRows.raw1842))
    (slots617.jump 1843 1834 f r (row_of_literal 1843 _ (by decide) RawRows.raw1843))

theorem site1834 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1834:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1844:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1834Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1844Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1844 f r x y z) (slots710.atReg 1848 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1844 4 1848 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1844 1848 1845 f r (row_of_literal 1844 _ (by decide) RawRows.raw1844))
    (slots710.pos_x 1844 1848 1845 f r (row_of_literal 1844 _ (by decide) RawRows.raw1844))
    (slots710.inc_y 1845 1846 f r (row_of_literal 1845 _ (by decide) RawRows.raw1845) (Or.inl (by decide)))
    (slots710.inc_y 1846 1847 f r (row_of_literal 1846 _ (by decide) RawRows.raw1846) (Or.inl (by decide)))
    (slots710.jump 1847 1844 f r (row_of_literal 1847 _ (by decide) RawRows.raw1847))

theorem site1844 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1844:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1848:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1844Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1848 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1848:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1849:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1848 _ (row_of_literal 1848 _ (by decide) RawRows.raw1848)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1849Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1849 f r x y z) (slots267.atReg 1857 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1849 8 1857 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1849 1857 1850 f r (row_of_literal 1849 _ (by decide) RawRows.raw1849))
    (slots267.pos_x 1849 1857 1850 f r (row_of_literal 1849 _ (by decide) RawRows.raw1849))
    (slots267.inc_z 1850 1851 f r (row_of_literal 1850 _ (by decide) RawRows.raw1850) (Or.inl (by decide)))
    (slots267.zero_y 1851 1853 1852 f r (row_of_literal 1851 _ (by decide) RawRows.raw1851))
    (slots267.pos_y 1851 1853 1852 f r (row_of_literal 1851 _ (by decide) RawRows.raw1851))
    (slots267.jump 1852 1856 f r (row_of_literal 1852 _ (by decide) RawRows.raw1852))
    (slots267.zero_z 1853 1856 1854 f r (row_of_literal 1853 _ (by decide) RawRows.raw1853))
    (slots267.pos_z 1853 1856 1854 f r (row_of_literal 1853 _ (by decide) RawRows.raw1853))
    (slots267.inc_y 1854 1855 f r (row_of_literal 1854 _ (by decide) RawRows.raw1854) (Or.inl (by decide)))
    (slots267.jump 1855 1853 f r (row_of_literal 1855 _ (by decide) RawRows.raw1855))
    (slots267.jump 1856 1849 f r (row_of_literal 1856 _ (by decide) RawRows.raw1856))

theorem site1849 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1849:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1857:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1849Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1857Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1857 f r x y z) (slots720.atReg 1860 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1857 3 1860 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1857 1860 1858 f r (row_of_literal 1857 _ (by decide) RawRows.raw1857))
    (slots720.pos_x 1857 1860 1858 f r (row_of_literal 1857 _ (by decide) RawRows.raw1857))
    (slots720.inc_y 1858 1859 f r (row_of_literal 1858 _ (by decide) RawRows.raw1858) (Or.inl (by decide)))
    (slots720.jump 1859 1857 f r (row_of_literal 1859 _ (by decide) RawRows.raw1859))

theorem site1857 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1857:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1860:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1857Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1860Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1860 f r x y z) (slots617.atReg 1870 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1860 10 1870 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1860 1864 1861 f r (row_of_literal 1860 _ (by decide) RawRows.raw1860))
    (slots617.pos_y 1860 1864 1861 f r (row_of_literal 1860 _ (by decide) RawRows.raw1860))
    (slots617.inc_z 1861 1862 f r (row_of_literal 1861 _ (by decide) RawRows.raw1861) (Or.inl (by decide)))
    (slots617.inc_x 1862 1863 f r (row_of_literal 1862 _ (by decide) RawRows.raw1862) (Or.inl (by decide)))
    (slots617.jump 1863 1860 f r (row_of_literal 1863 _ (by decide) RawRows.raw1863))
    (slots617.zero_x 1864 1870 1865 f r (row_of_literal 1864 _ (by decide) RawRows.raw1864))
    (slots617.pos_x 1864 1870 1865 f r (row_of_literal 1864 _ (by decide) RawRows.raw1864))
    (slots617.inc_z 1865 1866 f r (row_of_literal 1865 _ (by decide) RawRows.raw1865) (Or.inl (by decide)))
    (slots617.zero_x 1866 1869 1867 f r (row_of_literal 1866 _ (by decide) RawRows.raw1866))
    (slots617.pos_x 1866 1869 1867 f r (row_of_literal 1866 _ (by decide) RawRows.raw1866))
    (slots617.inc_y 1867 1868 f r (row_of_literal 1867 _ (by decide) RawRows.raw1867) (Or.inl (by decide)))
    (slots617.jump 1868 1866 f r (row_of_literal 1868 _ (by decide) RawRows.raw1868))
    (slots617.jump 1869 1860 f r (row_of_literal 1869 _ (by decide) RawRows.raw1869))

theorem site1860 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1860:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1870:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1860Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1870Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1870 f r x y z) (slots710.atReg 1874 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1870 4 1874 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1870 1874 1871 f r (row_of_literal 1870 _ (by decide) RawRows.raw1870))
    (slots710.pos_x 1870 1874 1871 f r (row_of_literal 1870 _ (by decide) RawRows.raw1870))
    (slots710.inc_y 1871 1872 f r (row_of_literal 1871 _ (by decide) RawRows.raw1871) (Or.inl (by decide)))
    (slots710.inc_y 1872 1873 f r (row_of_literal 1872 _ (by decide) RawRows.raw1872) (Or.inl (by decide)))
    (slots710.jump 1873 1870 f r (row_of_literal 1873 _ (by decide) RawRows.raw1873))

theorem site1870 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1870:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1874:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1870Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site1874Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1874 f r x y z) (slots160.atReg 1877 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1874 3 1877 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1874 1877 1875 f r (row_of_literal 1874 _ (by decide) RawRows.raw1874))
    (slots160.pos_x 1874 1877 1875 f r (row_of_literal 1874 _ (by decide) RawRows.raw1874))
    (slots160.inc_y 1875 1876 f r (row_of_literal 1875 _ (by decide) RawRows.raw1875) (Or.inl (by decide)))
    (slots160.jump 1876 1874 f r (row_of_literal 1876 _ (by decide) RawRows.raw1876))

theorem site1874 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1874:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1877:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1874Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1877Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1877 f r x y z) (slots210.atReg 1880 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1877 3 1880 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1877 1880 1878 f r (row_of_literal 1877 _ (by decide) RawRows.raw1877))
    (slots210.pos_x 1877 1880 1878 f r (row_of_literal 1877 _ (by decide) RawRows.raw1877))
    (slots210.inc_y 1878 1879 f r (row_of_literal 1878 _ (by decide) RawRows.raw1878) (Or.inl (by decide)))
    (slots210.jump 1879 1877 f r (row_of_literal 1879 _ (by decide) RawRows.raw1879))

theorem site1877 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1877:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1880:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1877Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1880Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1880 f r x y z) (slots617.atReg 1890 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1880 10 1890 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1880 1884 1881 f r (row_of_literal 1880 _ (by decide) RawRows.raw1880))
    (slots617.pos_y 1880 1884 1881 f r (row_of_literal 1880 _ (by decide) RawRows.raw1880))
    (slots617.inc_z 1881 1882 f r (row_of_literal 1881 _ (by decide) RawRows.raw1881) (Or.inl (by decide)))
    (slots617.inc_x 1882 1883 f r (row_of_literal 1882 _ (by decide) RawRows.raw1882) (Or.inl (by decide)))
    (slots617.jump 1883 1880 f r (row_of_literal 1883 _ (by decide) RawRows.raw1883))
    (slots617.zero_x 1884 1890 1885 f r (row_of_literal 1884 _ (by decide) RawRows.raw1884))
    (slots617.pos_x 1884 1890 1885 f r (row_of_literal 1884 _ (by decide) RawRows.raw1884))
    (slots617.inc_z 1885 1886 f r (row_of_literal 1885 _ (by decide) RawRows.raw1885) (Or.inl (by decide)))
    (slots617.zero_x 1886 1889 1887 f r (row_of_literal 1886 _ (by decide) RawRows.raw1886))
    (slots617.pos_x 1886 1889 1887 f r (row_of_literal 1886 _ (by decide) RawRows.raw1886))
    (slots617.inc_y 1887 1888 f r (row_of_literal 1887 _ (by decide) RawRows.raw1887) (Or.inl (by decide)))
    (slots617.jump 1888 1886 f r (row_of_literal 1888 _ (by decide) RawRows.raw1888))
    (slots617.jump 1889 1880 f r (row_of_literal 1889 _ (by decide) RawRows.raw1889))

theorem site1880 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1880:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1890:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1880Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1890Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1890 f r x y z) (slots720.atReg 1893 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1890 3 1893 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1890 1893 1891 f r (row_of_literal 1890 _ (by decide) RawRows.raw1890))
    (slots720.pos_x 1890 1893 1891 f r (row_of_literal 1890 _ (by decide) RawRows.raw1890))
    (slots720.inc_y 1891 1892 f r (row_of_literal 1891 _ (by decide) RawRows.raw1891) (Or.inl (by decide)))
    (slots720.jump 1892 1890 f r (row_of_literal 1892 _ (by decide) RawRows.raw1892))

theorem site1890 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1890:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1893:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1890Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1893Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1893 f r x y z) (slots160.atReg 1896 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1893 3 1896 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1893 1896 1894 f r (row_of_literal 1893 _ (by decide) RawRows.raw1893))
    (slots160.pos_x 1893 1896 1894 f r (row_of_literal 1893 _ (by decide) RawRows.raw1893))
    (slots160.inc_y 1894 1895 f r (row_of_literal 1894 _ (by decide) RawRows.raw1894) (Or.inl (by decide)))
    (slots160.jump 1895 1893 f r (row_of_literal 1895 _ (by decide) RawRows.raw1895))

theorem site1893 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1893:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1896:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1893Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1896Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1896 f r x y z) (slots210.atReg 1899 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1896 3 1899 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1896 1899 1897 f r (row_of_literal 1896 _ (by decide) RawRows.raw1896))
    (slots210.pos_x 1896 1899 1897 f r (row_of_literal 1896 _ (by decide) RawRows.raw1896))
    (slots210.inc_y 1897 1898 f r (row_of_literal 1897 _ (by decide) RawRows.raw1897) (Or.inl (by decide)))
    (slots210.jump 1898 1896 f r (row_of_literal 1898 _ (by decide) RawRows.raw1898))

theorem site1896 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1896:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1899:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1896Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1899Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1899 f r x y z) (slots617.atReg 1909 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1899 10 1909 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1899 1903 1900 f r (row_of_literal 1899 _ (by decide) RawRows.raw1899))
    (slots617.pos_y 1899 1903 1900 f r (row_of_literal 1899 _ (by decide) RawRows.raw1899))
    (slots617.inc_z 1900 1901 f r (row_of_literal 1900 _ (by decide) RawRows.raw1900) (Or.inl (by decide)))
    (slots617.inc_x 1901 1902 f r (row_of_literal 1901 _ (by decide) RawRows.raw1901) (Or.inl (by decide)))
    (slots617.jump 1902 1899 f r (row_of_literal 1902 _ (by decide) RawRows.raw1902))
    (slots617.zero_x 1903 1909 1904 f r (row_of_literal 1903 _ (by decide) RawRows.raw1903))
    (slots617.pos_x 1903 1909 1904 f r (row_of_literal 1903 _ (by decide) RawRows.raw1903))
    (slots617.inc_z 1904 1905 f r (row_of_literal 1904 _ (by decide) RawRows.raw1904) (Or.inl (by decide)))
    (slots617.zero_x 1905 1908 1906 f r (row_of_literal 1905 _ (by decide) RawRows.raw1905))
    (slots617.pos_x 1905 1908 1906 f r (row_of_literal 1905 _ (by decide) RawRows.raw1905))
    (slots617.inc_y 1906 1907 f r (row_of_literal 1906 _ (by decide) RawRows.raw1906) (Or.inl (by decide)))
    (slots617.jump 1907 1905 f r (row_of_literal 1907 _ (by decide) RawRows.raw1907))
    (slots617.jump 1908 1899 f r (row_of_literal 1908 _ (by decide) RawRows.raw1908))

theorem site1899 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1899:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1909:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1899Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1909Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1909 f r x y z) (slots720.atReg 1912 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1909 3 1912 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1909 1912 1910 f r (row_of_literal 1909 _ (by decide) RawRows.raw1909))
    (slots720.pos_x 1909 1912 1910 f r (row_of_literal 1909 _ (by decide) RawRows.raw1909))
    (slots720.inc_y 1910 1911 f r (row_of_literal 1910 _ (by decide) RawRows.raw1910) (Or.inl (by decide)))
    (slots720.jump 1911 1909 f r (row_of_literal 1911 _ (by decide) RawRows.raw1911))

theorem site1909 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1909:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1912:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1909Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1912Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1912 f r x y z) (slots561.atReg 1916 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1912 4 1916 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1912 1916 1913 f r (row_of_literal 1912 _ (by decide) RawRows.raw1912))
    (slots561.pos_x 1912 1916 1913 f r (row_of_literal 1912 _ (by decide) RawRows.raw1912))
    (slots561.inc_y 1913 1914 f r (row_of_literal 1913 _ (by decide) RawRows.raw1913) (Or.inl (by decide)))
    (slots561.inc_z 1914 1915 f r (row_of_literal 1914 _ (by decide) RawRows.raw1914) (Or.inl (by decide)))
    (slots561.jump 1915 1912 f r (row_of_literal 1915 _ (by decide) RawRows.raw1915))

theorem site1912 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1912:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1916:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1912Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1916Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1916 f r x y z) (slots650.atReg 1919 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1916 3 1919 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1916 1919 1917 f r (row_of_literal 1916 _ (by decide) RawRows.raw1916))
    (slots650.pos_x 1916 1919 1917 f r (row_of_literal 1916 _ (by decide) RawRows.raw1916))
    (slots650.inc_y 1917 1918 f r (row_of_literal 1917 _ (by decide) RawRows.raw1917) (Or.inl (by decide)))
    (slots650.jump 1918 1916 f r (row_of_literal 1918 _ (by decide) RawRows.raw1918))

theorem site1916 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1916:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1919:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1916Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1919Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1919 f r x y z) (slots160.atReg 1922 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1919 3 1922 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1919 1922 1920 f r (row_of_literal 1919 _ (by decide) RawRows.raw1919))
    (slots160.pos_x 1919 1922 1920 f r (row_of_literal 1919 _ (by decide) RawRows.raw1919))
    (slots160.inc_y 1920 1921 f r (row_of_literal 1920 _ (by decide) RawRows.raw1920) (Or.inl (by decide)))
    (slots160.jump 1921 1919 f r (row_of_literal 1921 _ (by decide) RawRows.raw1921))

theorem site1919 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1919:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1922:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1919Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1922Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1922 f r x y z) (slots210.atReg 1925 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1922 3 1925 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1922 1925 1923 f r (row_of_literal 1922 _ (by decide) RawRows.raw1922))
    (slots210.pos_x 1922 1925 1923 f r (row_of_literal 1922 _ (by decide) RawRows.raw1922))
    (slots210.inc_y 1923 1924 f r (row_of_literal 1923 _ (by decide) RawRows.raw1923) (Or.inl (by decide)))
    (slots210.jump 1924 1922 f r (row_of_literal 1924 _ (by decide) RawRows.raw1924))

theorem site1922 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1922:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1925:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1922Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1925Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1925 f r x y z) (slots617.atReg 1935 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1925 10 1935 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1925 1929 1926 f r (row_of_literal 1925 _ (by decide) RawRows.raw1925))
    (slots617.pos_y 1925 1929 1926 f r (row_of_literal 1925 _ (by decide) RawRows.raw1925))
    (slots617.inc_z 1926 1927 f r (row_of_literal 1926 _ (by decide) RawRows.raw1926) (Or.inl (by decide)))
    (slots617.inc_x 1927 1928 f r (row_of_literal 1927 _ (by decide) RawRows.raw1927) (Or.inl (by decide)))
    (slots617.jump 1928 1925 f r (row_of_literal 1928 _ (by decide) RawRows.raw1928))
    (slots617.zero_x 1929 1935 1930 f r (row_of_literal 1929 _ (by decide) RawRows.raw1929))
    (slots617.pos_x 1929 1935 1930 f r (row_of_literal 1929 _ (by decide) RawRows.raw1929))
    (slots617.inc_z 1930 1931 f r (row_of_literal 1930 _ (by decide) RawRows.raw1930) (Or.inl (by decide)))
    (slots617.zero_x 1931 1934 1932 f r (row_of_literal 1931 _ (by decide) RawRows.raw1931))
    (slots617.pos_x 1931 1934 1932 f r (row_of_literal 1931 _ (by decide) RawRows.raw1931))
    (slots617.inc_y 1932 1933 f r (row_of_literal 1932 _ (by decide) RawRows.raw1932) (Or.inl (by decide)))
    (slots617.jump 1933 1931 f r (row_of_literal 1933 _ (by decide) RawRows.raw1933))
    (slots617.jump 1934 1925 f r (row_of_literal 1934 _ (by decide) RawRows.raw1934))

theorem site1925 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1925:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1935:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1925Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1935Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1935 f r x y z) (slots720.atReg 1938 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1935 3 1938 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1935 1938 1936 f r (row_of_literal 1935 _ (by decide) RawRows.raw1935))
    (slots720.pos_x 1935 1938 1936 f r (row_of_literal 1935 _ (by decide) RawRows.raw1935))
    (slots720.inc_y 1936 1937 f r (row_of_literal 1936 _ (by decide) RawRows.raw1936) (Or.inl (by decide)))
    (slots720.jump 1937 1935 f r (row_of_literal 1937 _ (by decide) RawRows.raw1937))

theorem site1935 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1935:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1938:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1935Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1938Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1938 f r x y z) (slots561.atReg 1942 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1938 4 1942 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1938 1942 1939 f r (row_of_literal 1938 _ (by decide) RawRows.raw1938))
    (slots561.pos_x 1938 1942 1939 f r (row_of_literal 1938 _ (by decide) RawRows.raw1938))
    (slots561.inc_y 1939 1940 f r (row_of_literal 1939 _ (by decide) RawRows.raw1939) (Or.inl (by decide)))
    (slots561.inc_z 1940 1941 f r (row_of_literal 1940 _ (by decide) RawRows.raw1940) (Or.inl (by decide)))
    (slots561.jump 1941 1938 f r (row_of_literal 1941 _ (by decide) RawRows.raw1941))

theorem site1938 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1938:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1942:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1938Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1942Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1942 f r x y z) (slots650.atReg 1945 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1942 3 1945 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1942 1945 1943 f r (row_of_literal 1942 _ (by decide) RawRows.raw1942))
    (slots650.pos_x 1942 1945 1943 f r (row_of_literal 1942 _ (by decide) RawRows.raw1942))
    (slots650.inc_y 1943 1944 f r (row_of_literal 1943 _ (by decide) RawRows.raw1943) (Or.inl (by decide)))
    (slots650.jump 1944 1942 f r (row_of_literal 1944 _ (by decide) RawRows.raw1944))

theorem site1942 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1942:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1945:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1942Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1945Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1945 f r x y z) (slots267.atReg 1953 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1945 8 1953 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1945 1953 1946 f r (row_of_literal 1945 _ (by decide) RawRows.raw1945))
    (slots267.pos_x 1945 1953 1946 f r (row_of_literal 1945 _ (by decide) RawRows.raw1945))
    (slots267.inc_z 1946 1947 f r (row_of_literal 1946 _ (by decide) RawRows.raw1946) (Or.inl (by decide)))
    (slots267.zero_y 1947 1949 1948 f r (row_of_literal 1947 _ (by decide) RawRows.raw1947))
    (slots267.pos_y 1947 1949 1948 f r (row_of_literal 1947 _ (by decide) RawRows.raw1947))
    (slots267.jump 1948 1952 f r (row_of_literal 1948 _ (by decide) RawRows.raw1948))
    (slots267.zero_z 1949 1952 1950 f r (row_of_literal 1949 _ (by decide) RawRows.raw1949))
    (slots267.pos_z 1949 1952 1950 f r (row_of_literal 1949 _ (by decide) RawRows.raw1949))
    (slots267.inc_y 1950 1951 f r (row_of_literal 1950 _ (by decide) RawRows.raw1950) (Or.inl (by decide)))
    (slots267.jump 1951 1949 f r (row_of_literal 1951 _ (by decide) RawRows.raw1951))
    (slots267.jump 1952 1945 f r (row_of_literal 1952 _ (by decide) RawRows.raw1952))

theorem site1945 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1945:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1953:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1945Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1953Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1953 f r x y z) (slots720.atReg 1956 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1953 3 1956 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1953 1956 1954 f r (row_of_literal 1953 _ (by decide) RawRows.raw1953))
    (slots720.pos_x 1953 1956 1954 f r (row_of_literal 1953 _ (by decide) RawRows.raw1953))
    (slots720.inc_y 1954 1955 f r (row_of_literal 1954 _ (by decide) RawRows.raw1954) (Or.inl (by decide)))
    (slots720.jump 1955 1953 f r (row_of_literal 1955 _ (by decide) RawRows.raw1955))

theorem site1953 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1953:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1956:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1953Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1956Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1956 f r x y z) (slots617.atReg 1966 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1956 10 1966 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1956 1960 1957 f r (row_of_literal 1956 _ (by decide) RawRows.raw1956))
    (slots617.pos_y 1956 1960 1957 f r (row_of_literal 1956 _ (by decide) RawRows.raw1956))
    (slots617.inc_z 1957 1958 f r (row_of_literal 1957 _ (by decide) RawRows.raw1957) (Or.inl (by decide)))
    (slots617.inc_x 1958 1959 f r (row_of_literal 1958 _ (by decide) RawRows.raw1958) (Or.inl (by decide)))
    (slots617.jump 1959 1956 f r (row_of_literal 1959 _ (by decide) RawRows.raw1959))
    (slots617.zero_x 1960 1966 1961 f r (row_of_literal 1960 _ (by decide) RawRows.raw1960))
    (slots617.pos_x 1960 1966 1961 f r (row_of_literal 1960 _ (by decide) RawRows.raw1960))
    (slots617.inc_z 1961 1962 f r (row_of_literal 1961 _ (by decide) RawRows.raw1961) (Or.inl (by decide)))
    (slots617.zero_x 1962 1965 1963 f r (row_of_literal 1962 _ (by decide) RawRows.raw1962))
    (slots617.pos_x 1962 1965 1963 f r (row_of_literal 1962 _ (by decide) RawRows.raw1962))
    (slots617.inc_y 1963 1964 f r (row_of_literal 1963 _ (by decide) RawRows.raw1963) (Or.inl (by decide)))
    (slots617.jump 1964 1962 f r (row_of_literal 1964 _ (by decide) RawRows.raw1964))
    (slots617.jump 1965 1956 f r (row_of_literal 1965 _ (by decide) RawRows.raw1965))

theorem site1956 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1956:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1966:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1956Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1966Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1966 f r x y z) (slots710.atReg 1970 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1966 4 1970 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1966 1970 1967 f r (row_of_literal 1966 _ (by decide) RawRows.raw1966))
    (slots710.pos_x 1966 1970 1967 f r (row_of_literal 1966 _ (by decide) RawRows.raw1966))
    (slots710.inc_y 1967 1968 f r (row_of_literal 1967 _ (by decide) RawRows.raw1967) (Or.inl (by decide)))
    (slots710.inc_y 1968 1969 f r (row_of_literal 1968 _ (by decide) RawRows.raw1968) (Or.inl (by decide)))
    (slots710.jump 1969 1966 f r (row_of_literal 1969 _ (by decide) RawRows.raw1969))

theorem site1966 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1966:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1970:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1966Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1970 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1970:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1971:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1970 _ (row_of_literal 1970 _ (by decide) RawRows.raw1970)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site1971 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1971:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1972:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1971 _ (row_of_literal 1971 _ (by decide) RawRows.raw1971)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1972Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1972 f r x y z) (slots267.atReg 1980 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1972 8 1980 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1972 1980 1973 f r (row_of_literal 1972 _ (by decide) RawRows.raw1972))
    (slots267.pos_x 1972 1980 1973 f r (row_of_literal 1972 _ (by decide) RawRows.raw1972))
    (slots267.inc_z 1973 1974 f r (row_of_literal 1973 _ (by decide) RawRows.raw1973) (Or.inl (by decide)))
    (slots267.zero_y 1974 1976 1975 f r (row_of_literal 1974 _ (by decide) RawRows.raw1974))
    (slots267.pos_y 1974 1976 1975 f r (row_of_literal 1974 _ (by decide) RawRows.raw1974))
    (slots267.jump 1975 1979 f r (row_of_literal 1975 _ (by decide) RawRows.raw1975))
    (slots267.zero_z 1976 1979 1977 f r (row_of_literal 1976 _ (by decide) RawRows.raw1976))
    (slots267.pos_z 1976 1979 1977 f r (row_of_literal 1976 _ (by decide) RawRows.raw1976))
    (slots267.inc_y 1977 1978 f r (row_of_literal 1977 _ (by decide) RawRows.raw1977) (Or.inl (by decide)))
    (slots267.jump 1978 1976 f r (row_of_literal 1978 _ (by decide) RawRows.raw1978))
    (slots267.jump 1979 1972 f r (row_of_literal 1979 _ (by decide) RawRows.raw1979))

theorem site1972 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1972:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1980:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1972Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1980Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1980 f r x y z) (slots720.atReg 1983 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1980 3 1983 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1980 1983 1981 f r (row_of_literal 1980 _ (by decide) RawRows.raw1980))
    (slots720.pos_x 1980 1983 1981 f r (row_of_literal 1980 _ (by decide) RawRows.raw1980))
    (slots720.inc_y 1981 1982 f r (row_of_literal 1981 _ (by decide) RawRows.raw1981) (Or.inl (by decide)))
    (slots720.jump 1982 1980 f r (row_of_literal 1982 _ (by decide) RawRows.raw1982))

theorem site1980 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1980:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1983:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1980Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1983Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1983 f r x y z) (slots617.atReg 1993 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1983 10 1993 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1983 1987 1984 f r (row_of_literal 1983 _ (by decide) RawRows.raw1983))
    (slots617.pos_y 1983 1987 1984 f r (row_of_literal 1983 _ (by decide) RawRows.raw1983))
    (slots617.inc_z 1984 1985 f r (row_of_literal 1984 _ (by decide) RawRows.raw1984) (Or.inl (by decide)))
    (slots617.inc_x 1985 1986 f r (row_of_literal 1985 _ (by decide) RawRows.raw1985) (Or.inl (by decide)))
    (slots617.jump 1986 1983 f r (row_of_literal 1986 _ (by decide) RawRows.raw1986))
    (slots617.zero_x 1987 1993 1988 f r (row_of_literal 1987 _ (by decide) RawRows.raw1987))
    (slots617.pos_x 1987 1993 1988 f r (row_of_literal 1987 _ (by decide) RawRows.raw1987))
    (slots617.inc_z 1988 1989 f r (row_of_literal 1988 _ (by decide) RawRows.raw1988) (Or.inl (by decide)))
    (slots617.zero_x 1989 1992 1990 f r (row_of_literal 1989 _ (by decide) RawRows.raw1989))
    (slots617.pos_x 1989 1992 1990 f r (row_of_literal 1989 _ (by decide) RawRows.raw1989))
    (slots617.inc_y 1990 1991 f r (row_of_literal 1990 _ (by decide) RawRows.raw1990) (Or.inl (by decide)))
    (slots617.jump 1991 1989 f r (row_of_literal 1991 _ (by decide) RawRows.raw1991))
    (slots617.jump 1992 1983 f r (row_of_literal 1992 _ (by decide) RawRows.raw1992))

theorem site1983 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1983:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1993:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1983Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


end PA192.ModelSearch.Register181.Certified
