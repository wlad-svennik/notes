module
public import Src181Atoms
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandSaveAfter1 (f n t s c u v y d w : V) : Reach (config ((2925:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2928:Nat):V) f (vector n 0 s c u v t 0 w)) := by
  have micro := site2925 f n t s c u v 0 0 w
  have d6 : (0+t:V)=t := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact mid

theorem commandSaveAfter2 (f n t s c u v y d w : V) : Reach (config ((2925:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2931:Nat):V) f (vector n s 0 c u v t 0 w)) := by
  have micro := site2928 f n 0 s c u v t 0 w
  have d1 : (0+s:V)=s := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandSaveAfter1 f n t s c u v y d w).trans mid

theorem commandSaveAfter3 (f n t s c u v y d w : V) : Reach (config ((2925:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2941:Nat):V) f (vector n 0 0 c u v 0 (atom2 n t s c u v y d w) w)) := by
  have micro := site2931 f n s 0 c u v t 0 w
  have d7 : (0+(cantor t s):V)=atom2 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor t s):V)=0+(atom2 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandSaveAfter2 f n t s c u v y d w).trans mid

theorem commandSaveAfter4 (f n t s c u v y d w : V) : Reach (config ((2925:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2944:Nat):V) f (vector n 0 (atom2 n t s c u v y d w) c u v 0 0 w)) := by
  have micro := site2941 f n 0 0 c u v 0 (atom2 n t s c u v y d w) w
  have d2 : (0+(atom2 n t s c u v y d w):V)=atom2 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandSaveAfter3 f n t s c u v y d w).trans mid

theorem commandSaveAfter5 (f n t s c u v y d w : V) : Reach (config ((2925:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2948:Nat):V) f (vector n v (atom2 n t s c u v y d w) c u 0 v 0 w)) := by
  have micro := site2944 f n 0 (atom2 n t s c u v y d w) c u v 0 0 w
  have d1 : (0+v:V)=v := by ring
  have d6 : (0+v:V)=v := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandSaveAfter4 f n t s c u v y d w).trans mid

theorem commandSave (f n t s c u v y d w : V) : Reach (config ((2925:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2951:Nat):V) f (vector n v (atom2 n t s c u v y d w) c u v 0 0 w)) := by
  have micro := site2948 f n v (atom2 n t s c u v y d w) c u 0 v 0 w
  have d5 : (0+v:V)=v := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandSaveAfter5 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
