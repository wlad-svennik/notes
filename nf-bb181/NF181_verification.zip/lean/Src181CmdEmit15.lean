module
public import Src181CmdEmit14
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter481 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2325:Nat):V) f (vector n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom77 n t s c u v y d w) w)) := by
  have micro := site2315 f n (v+y) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (v+y))):V)=(emitAtom77 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (v+y))):V)=(0+(emitAtom77 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter480 f n t s c u v y d w).trans mid

theorem commandEmitAfter482 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2329:Nat):V) f (vector n ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2325 f n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom77 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom77 n t s c u v y d w))):V)=((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom77 n t s c u v y d w))):V)=(0+((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter481 f n t s c u v y d w).trans mid

theorem commandEmitAfter483 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2330:Nat):V) f (vector n ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2329 f n ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w))+1):V)=((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter482 f n t s c u v y d w).trans mid

theorem commandEmitAfter484 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2338:Nat):V) f (vector n ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) w)) := by
  have micro := site2330 f n ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom71 n t s c u v y d w))):V)=((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom71 n t s c u v y d w)):V)=(0+(emitAtom71 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom71 n t s c u v y d w))):V)=left (emitAtom71 n t s c u v y d w))).trans (by change left (cantor ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom71 n t s c u v y d w))):V)=(emitAtom63 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom71 n t s c u v y d w)):V)=(0+(emitAtom71 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom71 n t s c u v y d w))):V)=right (emitAtom71 n t s c u v y d w))).trans (by change right (cantor ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter483 f n t s c u v y d w).trans mid

theorem commandEmitAfter485 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2341:Nat):V) f (vector n ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2338 f n ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) w
  have d2 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter484 f n t s c u v y d w).trans mid

theorem commandEmitAfter486 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2351:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom78 n t s c u v y d w) w)) := by
  have micro := site2341 f n ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1))):V)=(emitAtom78 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1))):V)=(0+(emitAtom78 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter485 f n t s c u v y d w).trans mid

theorem commandEmitAfter487 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2355:Nat):V) f (vector n ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2351 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom78 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom78 n t s c u v y d w))):V)=((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom78 n t s c u v y d w))):V)=(0+((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter486 f n t s c u v y d w).trans mid

theorem commandEmitAfter488 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2358:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) 0 w)) := by
  have micro := site2355 f n ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w))):V)=((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter487 f n t s c u v y d w).trans mid

theorem commandEmitAfter489 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2361:Nat):V) f (vector n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) 0 w)) := by
  have micro := site2358 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) 0 w
  have d1 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter488 f n t s c u v y d w).trans mid

theorem commandEmitAfter490 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2371:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom79 n t s c u v y d w) w)) := by
  have micro := site2361 f n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) (emitAtom63 n t s c u v y d w))):V)=(emitAtom79 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) (emitAtom63 n t s c u v y d w))):V)=(0+(emitAtom79 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter489 f n t s c u v y d w).trans mid

theorem commandEmitAfter491 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2374:Nat):V) f (vector n 0 (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2371 f n 0 0 c (d+u) (v+y) 0 (emitAtom79 n t s c u v y d w) w
  have d2 : ((0+(emitAtom79 n t s c u v y d w)):V)=(emitAtom79 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter490 f n t s c u v y d w).trans mid

theorem commandEmitAfter492 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2378:Nat):V) f (vector n (d+u) (emitAtom79 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2374 f n 0 (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter491 f n t s c u v y d w).trans mid

theorem commandEmitAfter493 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2381:Nat):V) f (vector n (d+u) (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2378 f n (d+u) (emitAtom79 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter492 f n t s c u v y d w).trans mid

theorem commandEmitAfter494 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2384:Nat):V) f (vector n 0 (emitAtom79 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2381 f n (d+u) (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter493 f n t s c u v y d w).trans mid

theorem commandEmitAfter495 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2387:Nat):V) f (vector n (emitAtom79 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2384 f n 0 (emitAtom79 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom79 n t s c u v y d w)):V)=(emitAtom79 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter494 f n t s c u v y d w).trans mid

theorem commandEmitAfter496 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2397:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom80 n t s c u v y d w) w)) := by
  have micro := site2387 f n (emitAtom79 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom79 n t s c u v y d w))):V)=(emitAtom80 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom79 n t s c u v y d w))):V)=(0+(emitAtom80 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter495 f n t s c u v y d w).trans mid

theorem commandEmitAfter497 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2400:Nat):V) f (vector n 0 (emitAtom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2397 f n 0 0 c (d+u) (v+y) 0 (emitAtom80 n t s c u v y d w) w
  have d2 : ((0+(emitAtom80 n t s c u v y d w)):V)=(emitAtom80 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter496 f n t s c u v y d w).trans mid

theorem commandEmitAfter498 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2404:Nat):V) f (vector n (v+y) (emitAtom80 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2400 f n 0 (emitAtom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter497 f n t s c u v y d w).trans mid

theorem commandEmitAfter499 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2407:Nat):V) f (vector n (v+y) (emitAtom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2404 f n (v+y) (emitAtom80 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter498 f n t s c u v y d w).trans mid

theorem commandEmitAfter500 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2415:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom79 n t s c u v y d w) w)) := by
  have micro := site2407 f n (v+y) (emitAtom80 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom80 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom80 n t s c u v y d w)):V)=(0+(emitAtom80 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom80 n t s c u v y d w))):V)=left (emitAtom80 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom79 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom80 n t s c u v y d w))):V)=(emitAtom79 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom80 n t s c u v y d w)):V)=(0+(emitAtom80 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom80 n t s c u v y d w))):V)=right (emitAtom80 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom79 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter499 f n t s c u v y d w).trans mid

theorem commandEmitAfter501 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2418:Nat):V) f (vector n (v+y) (emitAtom79 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2415 f n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom79 n t s c u v y d w) w
  have d2 : ((0+(emitAtom79 n t s c u v y d w)):V)=(emitAtom79 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter500 f n t s c u v y d w).trans mid

theorem commandEmitAfter502 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2428:Nat):V) f (vector n 0 (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w)) := by
  have micro := site2418 f n (v+y) (emitAtom79 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (v+y))):V)=(emitAtom24 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (v+y))):V)=(0+(emitAtom24 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter501 f n t s c u v y d w).trans mid

theorem commandEmitAfter503 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2432:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2428 f n 0 (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=(0+((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter502 f n t s c u v y d w).trans mid

theorem commandEmitAfter504 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2433:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2432 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter503 f n t s c u v y d w).trans mid

theorem commandEmitAfter505 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2441:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) w)) := by
  have micro := site2433 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom79 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom79 n t s c u v y d w))):V)=((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom79 n t s c u v y d w)):V)=(0+(emitAtom79 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom79 n t s c u v y d w))):V)=left (emitAtom79 n t s c u v y d w))).trans (by change left (cantor ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) (emitAtom63 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom79 n t s c u v y d w))):V)=(emitAtom63 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom79 n t s c u v y d w)):V)=(0+(emitAtom79 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom79 n t s c u v y d w))):V)=right (emitAtom79 n t s c u v y d w))).trans (by change right (cantor ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) (emitAtom63 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter504 f n t s c u v y d w).trans mid

theorem commandEmitAfter506 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2444:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) 0 w)) := by
  have micro := site2441 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) w
  have d2 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter505 f n t s c u v y d w).trans mid

theorem commandEmitAfter507 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2454:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom81 n t s c u v y d w) w)) := by
  have micro := site2444 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(emitAtom81 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(0+(emitAtom81 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter506 f n t s c u v y d w).trans mid

theorem commandEmitAfter508 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2458:Nat):V) f (vector n ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2454 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom81 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom81 n t s c u v y d w))):V)=((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom81 n t s c u v y d w))):V)=(0+((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter507 f n t s c u v y d w).trans mid

theorem commandEmitAfter509 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2461:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) 0 w)) := by
  have micro := site2458 f n ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w))):V)=((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter508 f n t s c u v y d w).trans mid

theorem commandEmitAfter510 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2464:Nat):V) f (vector n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) 0 w)) := by
  have micro := site2461 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) 0 w
  have d1 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter509 f n t s c u v y d w).trans mid

theorem commandEmitAfter511 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2474:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom82 n t s c u v y d w) w)) := by
  have micro := site2464 f n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) (emitAtom63 n t s c u v y d w))):V)=(emitAtom82 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) (emitAtom63 n t s c u v y d w))):V)=(0+(emitAtom82 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter510 f n t s c u v y d w).trans mid

theorem commandEmitAfter512 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2477:Nat):V) f (vector n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2474 f n 0 0 c (d+u) (v+y) 0 (emitAtom82 n t s c u v y d w) w
  have d2 : ((0+(emitAtom82 n t s c u v y d w)):V)=(emitAtom82 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter511 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
