module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem site0738 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((738:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((739:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 738 _ (row_of_literal 738 _ (by decide) RawRows.raw0738)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site0739Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 739 f r x y z) (slots160.atReg 742 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 739 3 742 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 739 742 740 f r (row_of_literal 739 _ (by decide) RawRows.raw0739))
    (slots160.pos_x 739 742 740 f r (row_of_literal 739 _ (by decide) RawRows.raw0739))
    (slots160.inc_y 740 741 f r (row_of_literal 740 _ (by decide) RawRows.raw0740) (Or.inl (by decide)))
    (slots160.jump 741 739 f r (row_of_literal 741 _ (by decide) RawRows.raw0741))

theorem site0739 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((739:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((742:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0739Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0742Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 742 f r x y z) (slots210.atReg 745 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 742 3 745 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 742 745 743 f r (row_of_literal 742 _ (by decide) RawRows.raw0742))
    (slots210.pos_x 742 745 743 f r (row_of_literal 742 _ (by decide) RawRows.raw0742))
    (slots210.inc_y 743 744 f r (row_of_literal 743 _ (by decide) RawRows.raw0743) (Or.inl (by decide)))
    (slots210.jump 744 742 f r (row_of_literal 744 _ (by decide) RawRows.raw0744))

theorem site0742 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((742:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((745:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0742Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0745Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 745 f r x y z) (slots617.atReg 755 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 745 10 755 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 745 749 746 f r (row_of_literal 745 _ (by decide) RawRows.raw0745))
    (slots617.pos_y 745 749 746 f r (row_of_literal 745 _ (by decide) RawRows.raw0745))
    (slots617.inc_z 746 747 f r (row_of_literal 746 _ (by decide) RawRows.raw0746) (Or.inl (by decide)))
    (slots617.inc_x 747 748 f r (row_of_literal 747 _ (by decide) RawRows.raw0747) (Or.inl (by decide)))
    (slots617.jump 748 745 f r (row_of_literal 748 _ (by decide) RawRows.raw0748))
    (slots617.zero_x 749 755 750 f r (row_of_literal 749 _ (by decide) RawRows.raw0749))
    (slots617.pos_x 749 755 750 f r (row_of_literal 749 _ (by decide) RawRows.raw0749))
    (slots617.inc_z 750 751 f r (row_of_literal 750 _ (by decide) RawRows.raw0750) (Or.inl (by decide)))
    (slots617.zero_x 751 754 752 f r (row_of_literal 751 _ (by decide) RawRows.raw0751))
    (slots617.pos_x 751 754 752 f r (row_of_literal 751 _ (by decide) RawRows.raw0751))
    (slots617.inc_y 752 753 f r (row_of_literal 752 _ (by decide) RawRows.raw0752) (Or.inl (by decide)))
    (slots617.jump 753 751 f r (row_of_literal 753 _ (by decide) RawRows.raw0753))
    (slots617.jump 754 745 f r (row_of_literal 754 _ (by decide) RawRows.raw0754))

theorem site0745 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((745:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((755:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0745Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0755Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 755 f r x y z) (slots720.atReg 758 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 755 3 758 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 755 758 756 f r (row_of_literal 755 _ (by decide) RawRows.raw0755))
    (slots720.pos_x 755 758 756 f r (row_of_literal 755 _ (by decide) RawRows.raw0755))
    (slots720.inc_y 756 757 f r (row_of_literal 756 _ (by decide) RawRows.raw0756) (Or.inl (by decide)))
    (slots720.jump 757 755 f r (row_of_literal 757 _ (by decide) RawRows.raw0757))

theorem site0755 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((755:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((758:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0755Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0758Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 758 f r x y z) (slots361.atReg 762 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 758 4 762 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 758 762 759 f r (row_of_literal 758 _ (by decide) RawRows.raw0758))
    (slots361.pos_x 758 762 759 f r (row_of_literal 758 _ (by decide) RawRows.raw0758))
    (slots361.inc_y 759 760 f r (row_of_literal 759 _ (by decide) RawRows.raw0759) (Or.inl (by decide)))
    (slots361.inc_z 760 761 f r (row_of_literal 760 _ (by decide) RawRows.raw0760) (Or.inl (by decide)))
    (slots361.jump 761 758 f r (row_of_literal 761 _ (by decide) RawRows.raw0761))

theorem site0758 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((758:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((762:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0758Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site0762Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 762 f r x y z) (slots630.atReg 765 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 762 3 765 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 762 765 763 f r (row_of_literal 762 _ (by decide) RawRows.raw0762))
    (slots630.pos_x 762 765 763 f r (row_of_literal 762 _ (by decide) RawRows.raw0762))
    (slots630.inc_y 763 764 f r (row_of_literal 763 _ (by decide) RawRows.raw0763) (Or.inl (by decide)))
    (slots630.jump 764 762 f r (row_of_literal 764 _ (by decide) RawRows.raw0764))

theorem site0762 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((762:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((765:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0762Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site0765Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 765 f r x y z) (slots160.atReg 768 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 765 3 768 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 765 768 766 f r (row_of_literal 765 _ (by decide) RawRows.raw0765))
    (slots160.pos_x 765 768 766 f r (row_of_literal 765 _ (by decide) RawRows.raw0765))
    (slots160.inc_y 766 767 f r (row_of_literal 766 _ (by decide) RawRows.raw0766) (Or.inl (by decide)))
    (slots160.jump 767 765 f r (row_of_literal 767 _ (by decide) RawRows.raw0767))

theorem site0765 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((765:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((768:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0765Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0768Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 768 f r x y z) (slots210.atReg 771 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 768 3 771 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 768 771 769 f r (row_of_literal 768 _ (by decide) RawRows.raw0768))
    (slots210.pos_x 768 771 769 f r (row_of_literal 768 _ (by decide) RawRows.raw0768))
    (slots210.inc_y 769 770 f r (row_of_literal 769 _ (by decide) RawRows.raw0769) (Or.inl (by decide)))
    (slots210.jump 770 768 f r (row_of_literal 770 _ (by decide) RawRows.raw0770))

theorem site0768 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((768:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((771:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0768Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0771Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 771 f r x y z) (slots617.atReg 781 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 771 10 781 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 771 775 772 f r (row_of_literal 771 _ (by decide) RawRows.raw0771))
    (slots617.pos_y 771 775 772 f r (row_of_literal 771 _ (by decide) RawRows.raw0771))
    (slots617.inc_z 772 773 f r (row_of_literal 772 _ (by decide) RawRows.raw0772) (Or.inl (by decide)))
    (slots617.inc_x 773 774 f r (row_of_literal 773 _ (by decide) RawRows.raw0773) (Or.inl (by decide)))
    (slots617.jump 774 771 f r (row_of_literal 774 _ (by decide) RawRows.raw0774))
    (slots617.zero_x 775 781 776 f r (row_of_literal 775 _ (by decide) RawRows.raw0775))
    (slots617.pos_x 775 781 776 f r (row_of_literal 775 _ (by decide) RawRows.raw0775))
    (slots617.inc_z 776 777 f r (row_of_literal 776 _ (by decide) RawRows.raw0776) (Or.inl (by decide)))
    (slots617.zero_x 777 780 778 f r (row_of_literal 777 _ (by decide) RawRows.raw0777))
    (slots617.pos_x 777 780 778 f r (row_of_literal 777 _ (by decide) RawRows.raw0777))
    (slots617.inc_y 778 779 f r (row_of_literal 778 _ (by decide) RawRows.raw0778) (Or.inl (by decide)))
    (slots617.jump 779 777 f r (row_of_literal 779 _ (by decide) RawRows.raw0779))
    (slots617.jump 780 771 f r (row_of_literal 780 _ (by decide) RawRows.raw0780))

theorem site0771 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((771:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((781:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0771Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0781Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 781 f r x y z) (slots720.atReg 784 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 781 3 784 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 781 784 782 f r (row_of_literal 781 _ (by decide) RawRows.raw0781))
    (slots720.pos_x 781 784 782 f r (row_of_literal 781 _ (by decide) RawRows.raw0781))
    (slots720.inc_y 782 783 f r (row_of_literal 782 _ (by decide) RawRows.raw0782) (Or.inl (by decide)))
    (slots720.jump 783 781 f r (row_of_literal 783 _ (by decide) RawRows.raw0783))

theorem site0781 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((781:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((784:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0781Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0784Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 784 f r x y z) (slots561.atReg 788 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 784 4 788 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 784 788 785 f r (row_of_literal 784 _ (by decide) RawRows.raw0784))
    (slots561.pos_x 784 788 785 f r (row_of_literal 784 _ (by decide) RawRows.raw0784))
    (slots561.inc_y 785 786 f r (row_of_literal 785 _ (by decide) RawRows.raw0785) (Or.inl (by decide)))
    (slots561.inc_z 786 787 f r (row_of_literal 786 _ (by decide) RawRows.raw0786) (Or.inl (by decide)))
    (slots561.jump 787 784 f r (row_of_literal 787 _ (by decide) RawRows.raw0787))

theorem site0784 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((784:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((788:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0784Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site0788Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 788 f r x y z) (slots650.atReg 791 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 788 3 791 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 788 791 789 f r (row_of_literal 788 _ (by decide) RawRows.raw0788))
    (slots650.pos_x 788 791 789 f r (row_of_literal 788 _ (by decide) RawRows.raw0788))
    (slots650.inc_y 789 790 f r (row_of_literal 789 _ (by decide) RawRows.raw0789) (Or.inl (by decide)))
    (slots650.jump 790 788 f r (row_of_literal 790 _ (by decide) RawRows.raw0790))

theorem site0788 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((788:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((791:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0788Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site0791Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 791 f r x y z) (slots267.atReg 799 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 791 8 799 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 791 799 792 f r (row_of_literal 791 _ (by decide) RawRows.raw0791))
    (slots267.pos_x 791 799 792 f r (row_of_literal 791 _ (by decide) RawRows.raw0791))
    (slots267.inc_z 792 793 f r (row_of_literal 792 _ (by decide) RawRows.raw0792) (Or.inl (by decide)))
    (slots267.zero_y 793 795 794 f r (row_of_literal 793 _ (by decide) RawRows.raw0793))
    (slots267.pos_y 793 795 794 f r (row_of_literal 793 _ (by decide) RawRows.raw0793))
    (slots267.jump 794 798 f r (row_of_literal 794 _ (by decide) RawRows.raw0794))
    (slots267.zero_z 795 798 796 f r (row_of_literal 795 _ (by decide) RawRows.raw0795))
    (slots267.pos_z 795 798 796 f r (row_of_literal 795 _ (by decide) RawRows.raw0795))
    (slots267.inc_y 796 797 f r (row_of_literal 796 _ (by decide) RawRows.raw0796) (Or.inl (by decide)))
    (slots267.jump 797 795 f r (row_of_literal 797 _ (by decide) RawRows.raw0797))
    (slots267.jump 798 791 f r (row_of_literal 798 _ (by decide) RawRows.raw0798))

theorem site0791 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((791:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((799:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0791Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0799Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 799 f r x y z) (slots720.atReg 802 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 799 3 802 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 799 802 800 f r (row_of_literal 799 _ (by decide) RawRows.raw0799))
    (slots720.pos_x 799 802 800 f r (row_of_literal 799 _ (by decide) RawRows.raw0799))
    (slots720.inc_y 800 801 f r (row_of_literal 800 _ (by decide) RawRows.raw0800) (Or.inl (by decide)))
    (slots720.jump 801 799 f r (row_of_literal 801 _ (by decide) RawRows.raw0801))

theorem site0799 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((799:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((802:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0799Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0802Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 802 f r x y z) (slots617.atReg 812 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 802 10 812 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 802 806 803 f r (row_of_literal 802 _ (by decide) RawRows.raw0802))
    (slots617.pos_y 802 806 803 f r (row_of_literal 802 _ (by decide) RawRows.raw0802))
    (slots617.inc_z 803 804 f r (row_of_literal 803 _ (by decide) RawRows.raw0803) (Or.inl (by decide)))
    (slots617.inc_x 804 805 f r (row_of_literal 804 _ (by decide) RawRows.raw0804) (Or.inl (by decide)))
    (slots617.jump 805 802 f r (row_of_literal 805 _ (by decide) RawRows.raw0805))
    (slots617.zero_x 806 812 807 f r (row_of_literal 806 _ (by decide) RawRows.raw0806))
    (slots617.pos_x 806 812 807 f r (row_of_literal 806 _ (by decide) RawRows.raw0806))
    (slots617.inc_z 807 808 f r (row_of_literal 807 _ (by decide) RawRows.raw0807) (Or.inl (by decide)))
    (slots617.zero_x 808 811 809 f r (row_of_literal 808 _ (by decide) RawRows.raw0808))
    (slots617.pos_x 808 811 809 f r (row_of_literal 808 _ (by decide) RawRows.raw0808))
    (slots617.inc_y 809 810 f r (row_of_literal 809 _ (by decide) RawRows.raw0809) (Or.inl (by decide)))
    (slots617.jump 810 808 f r (row_of_literal 810 _ (by decide) RawRows.raw0810))
    (slots617.jump 811 802 f r (row_of_literal 811 _ (by decide) RawRows.raw0811))

theorem site0802 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((802:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((812:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0802Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0812Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 812 f r x y z) (slots710.atReg 816 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 812 4 816 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 812 816 813 f r (row_of_literal 812 _ (by decide) RawRows.raw0812))
    (slots710.pos_x 812 816 813 f r (row_of_literal 812 _ (by decide) RawRows.raw0812))
    (slots710.inc_y 813 814 f r (row_of_literal 813 _ (by decide) RawRows.raw0813) (Or.inl (by decide)))
    (slots710.inc_y 814 815 f r (row_of_literal 814 _ (by decide) RawRows.raw0814) (Or.inl (by decide)))
    (slots710.jump 815 812 f r (row_of_literal 815 _ (by decide) RawRows.raw0815))

theorem site0812 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((812:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((816:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0812Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site0816 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((816:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((817:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 816 _ (row_of_literal 816 _ (by decide) RawRows.raw0816)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site0817Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 817 f r x y z) (slots267.atReg 825 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 817 8 825 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 817 825 818 f r (row_of_literal 817 _ (by decide) RawRows.raw0817))
    (slots267.pos_x 817 825 818 f r (row_of_literal 817 _ (by decide) RawRows.raw0817))
    (slots267.inc_z 818 819 f r (row_of_literal 818 _ (by decide) RawRows.raw0818) (Or.inl (by decide)))
    (slots267.zero_y 819 821 820 f r (row_of_literal 819 _ (by decide) RawRows.raw0819))
    (slots267.pos_y 819 821 820 f r (row_of_literal 819 _ (by decide) RawRows.raw0819))
    (slots267.jump 820 824 f r (row_of_literal 820 _ (by decide) RawRows.raw0820))
    (slots267.zero_z 821 824 822 f r (row_of_literal 821 _ (by decide) RawRows.raw0821))
    (slots267.pos_z 821 824 822 f r (row_of_literal 821 _ (by decide) RawRows.raw0821))
    (slots267.inc_y 822 823 f r (row_of_literal 822 _ (by decide) RawRows.raw0822) (Or.inl (by decide)))
    (slots267.jump 823 821 f r (row_of_literal 823 _ (by decide) RawRows.raw0823))
    (slots267.jump 824 817 f r (row_of_literal 824 _ (by decide) RawRows.raw0824))

theorem site0817 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((817:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((825:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0817Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0825Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 825 f r x y z) (slots720.atReg 828 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 825 3 828 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 825 828 826 f r (row_of_literal 825 _ (by decide) RawRows.raw0825))
    (slots720.pos_x 825 828 826 f r (row_of_literal 825 _ (by decide) RawRows.raw0825))
    (slots720.inc_y 826 827 f r (row_of_literal 826 _ (by decide) RawRows.raw0826) (Or.inl (by decide)))
    (slots720.jump 827 825 f r (row_of_literal 827 _ (by decide) RawRows.raw0827))

theorem site0825 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((825:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((828:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0825Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0828Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 828 f r x y z) (slots617.atReg 838 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 828 10 838 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 828 832 829 f r (row_of_literal 828 _ (by decide) RawRows.raw0828))
    (slots617.pos_y 828 832 829 f r (row_of_literal 828 _ (by decide) RawRows.raw0828))
    (slots617.inc_z 829 830 f r (row_of_literal 829 _ (by decide) RawRows.raw0829) (Or.inl (by decide)))
    (slots617.inc_x 830 831 f r (row_of_literal 830 _ (by decide) RawRows.raw0830) (Or.inl (by decide)))
    (slots617.jump 831 828 f r (row_of_literal 831 _ (by decide) RawRows.raw0831))
    (slots617.zero_x 832 838 833 f r (row_of_literal 832 _ (by decide) RawRows.raw0832))
    (slots617.pos_x 832 838 833 f r (row_of_literal 832 _ (by decide) RawRows.raw0832))
    (slots617.inc_z 833 834 f r (row_of_literal 833 _ (by decide) RawRows.raw0833) (Or.inl (by decide)))
    (slots617.zero_x 834 837 835 f r (row_of_literal 834 _ (by decide) RawRows.raw0834))
    (slots617.pos_x 834 837 835 f r (row_of_literal 834 _ (by decide) RawRows.raw0834))
    (slots617.inc_y 835 836 f r (row_of_literal 835 _ (by decide) RawRows.raw0835) (Or.inl (by decide)))
    (slots617.jump 836 834 f r (row_of_literal 836 _ (by decide) RawRows.raw0836))
    (slots617.jump 837 828 f r (row_of_literal 837 _ (by decide) RawRows.raw0837))

theorem site0828 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((828:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((838:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0828Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0838Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 838 f r x y z) (slots710.atReg 842 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 838 4 842 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 838 842 839 f r (row_of_literal 838 _ (by decide) RawRows.raw0838))
    (slots710.pos_x 838 842 839 f r (row_of_literal 838 _ (by decide) RawRows.raw0838))
    (slots710.inc_y 839 840 f r (row_of_literal 839 _ (by decide) RawRows.raw0839) (Or.inl (by decide)))
    (slots710.inc_y 840 841 f r (row_of_literal 840 _ (by decide) RawRows.raw0840) (Or.inl (by decide)))
    (slots710.jump 841 838 f r (row_of_literal 841 _ (by decide) RawRows.raw0841))

theorem site0838 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((838:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((842:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0838Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site0842Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 842 f r x y z) (slots267.atReg 850 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 842 8 850 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 842 850 843 f r (row_of_literal 842 _ (by decide) RawRows.raw0842))
    (slots267.pos_x 842 850 843 f r (row_of_literal 842 _ (by decide) RawRows.raw0842))
    (slots267.inc_z 843 844 f r (row_of_literal 843 _ (by decide) RawRows.raw0843) (Or.inl (by decide)))
    (slots267.zero_y 844 846 845 f r (row_of_literal 844 _ (by decide) RawRows.raw0844))
    (slots267.pos_y 844 846 845 f r (row_of_literal 844 _ (by decide) RawRows.raw0844))
    (slots267.jump 845 849 f r (row_of_literal 845 _ (by decide) RawRows.raw0845))
    (slots267.zero_z 846 849 847 f r (row_of_literal 846 _ (by decide) RawRows.raw0846))
    (slots267.pos_z 846 849 847 f r (row_of_literal 846 _ (by decide) RawRows.raw0846))
    (slots267.inc_y 847 848 f r (row_of_literal 847 _ (by decide) RawRows.raw0847) (Or.inl (by decide)))
    (slots267.jump 848 846 f r (row_of_literal 848 _ (by decide) RawRows.raw0848))
    (slots267.jump 849 842 f r (row_of_literal 849 _ (by decide) RawRows.raw0849))

theorem site0842 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((842:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((850:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0842Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0850Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 850 f r x y z) (slots720.atReg 853 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 850 3 853 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 850 853 851 f r (row_of_literal 850 _ (by decide) RawRows.raw0850))
    (slots720.pos_x 850 853 851 f r (row_of_literal 850 _ (by decide) RawRows.raw0850))
    (slots720.inc_y 851 852 f r (row_of_literal 851 _ (by decide) RawRows.raw0851) (Or.inl (by decide)))
    (slots720.jump 852 850 f r (row_of_literal 852 _ (by decide) RawRows.raw0852))

theorem site0850 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((850:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((853:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0850Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0853Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 853 f r x y z) (slots617.atReg 863 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 853 10 863 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 853 857 854 f r (row_of_literal 853 _ (by decide) RawRows.raw0853))
    (slots617.pos_y 853 857 854 f r (row_of_literal 853 _ (by decide) RawRows.raw0853))
    (slots617.inc_z 854 855 f r (row_of_literal 854 _ (by decide) RawRows.raw0854) (Or.inl (by decide)))
    (slots617.inc_x 855 856 f r (row_of_literal 855 _ (by decide) RawRows.raw0855) (Or.inl (by decide)))
    (slots617.jump 856 853 f r (row_of_literal 856 _ (by decide) RawRows.raw0856))
    (slots617.zero_x 857 863 858 f r (row_of_literal 857 _ (by decide) RawRows.raw0857))
    (slots617.pos_x 857 863 858 f r (row_of_literal 857 _ (by decide) RawRows.raw0857))
    (slots617.inc_z 858 859 f r (row_of_literal 858 _ (by decide) RawRows.raw0858) (Or.inl (by decide)))
    (slots617.zero_x 859 862 860 f r (row_of_literal 859 _ (by decide) RawRows.raw0859))
    (slots617.pos_x 859 862 860 f r (row_of_literal 859 _ (by decide) RawRows.raw0859))
    (slots617.inc_y 860 861 f r (row_of_literal 860 _ (by decide) RawRows.raw0860) (Or.inl (by decide)))
    (slots617.jump 861 859 f r (row_of_literal 861 _ (by decide) RawRows.raw0861))
    (slots617.jump 862 853 f r (row_of_literal 862 _ (by decide) RawRows.raw0862))

theorem site0853 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((853:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((863:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0853Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0863Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 863 f r x y z) (slots710.atReg 867 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 863 4 867 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 863 867 864 f r (row_of_literal 863 _ (by decide) RawRows.raw0863))
    (slots710.pos_x 863 867 864 f r (row_of_literal 863 _ (by decide) RawRows.raw0863))
    (slots710.inc_y 864 865 f r (row_of_literal 864 _ (by decide) RawRows.raw0864) (Or.inl (by decide)))
    (slots710.inc_y 865 866 f r (row_of_literal 865 _ (by decide) RawRows.raw0865) (Or.inl (by decide)))
    (slots710.jump 866 863 f r (row_of_literal 866 _ (by decide) RawRows.raw0866))

theorem site0863 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((863:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((867:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0863Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site0867Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 867 f r x y z) (slots160.atReg 870 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 867 3 870 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 867 870 868 f r (row_of_literal 867 _ (by decide) RawRows.raw0867))
    (slots160.pos_x 867 870 868 f r (row_of_literal 867 _ (by decide) RawRows.raw0867))
    (slots160.inc_y 868 869 f r (row_of_literal 868 _ (by decide) RawRows.raw0868) (Or.inl (by decide)))
    (slots160.jump 869 867 f r (row_of_literal 869 _ (by decide) RawRows.raw0869))

theorem site0867 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((867:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((870:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0867Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0870Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 870 f r x y z) (slots210.atReg 873 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 870 3 873 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 870 873 871 f r (row_of_literal 870 _ (by decide) RawRows.raw0870))
    (slots210.pos_x 870 873 871 f r (row_of_literal 870 _ (by decide) RawRows.raw0870))
    (slots210.inc_y 871 872 f r (row_of_literal 871 _ (by decide) RawRows.raw0871) (Or.inl (by decide)))
    (slots210.jump 872 870 f r (row_of_literal 872 _ (by decide) RawRows.raw0872))

theorem site0870 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((870:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((873:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0870Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0873Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 873 f r x y z) (slots617.atReg 883 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 873 10 883 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 873 877 874 f r (row_of_literal 873 _ (by decide) RawRows.raw0873))
    (slots617.pos_y 873 877 874 f r (row_of_literal 873 _ (by decide) RawRows.raw0873))
    (slots617.inc_z 874 875 f r (row_of_literal 874 _ (by decide) RawRows.raw0874) (Or.inl (by decide)))
    (slots617.inc_x 875 876 f r (row_of_literal 875 _ (by decide) RawRows.raw0875) (Or.inl (by decide)))
    (slots617.jump 876 873 f r (row_of_literal 876 _ (by decide) RawRows.raw0876))
    (slots617.zero_x 877 883 878 f r (row_of_literal 877 _ (by decide) RawRows.raw0877))
    (slots617.pos_x 877 883 878 f r (row_of_literal 877 _ (by decide) RawRows.raw0877))
    (slots617.inc_z 878 879 f r (row_of_literal 878 _ (by decide) RawRows.raw0878) (Or.inl (by decide)))
    (slots617.zero_x 879 882 880 f r (row_of_literal 879 _ (by decide) RawRows.raw0879))
    (slots617.pos_x 879 882 880 f r (row_of_literal 879 _ (by decide) RawRows.raw0879))
    (slots617.inc_y 880 881 f r (row_of_literal 880 _ (by decide) RawRows.raw0880) (Or.inl (by decide)))
    (slots617.jump 881 879 f r (row_of_literal 881 _ (by decide) RawRows.raw0881))
    (slots617.jump 882 873 f r (row_of_literal 882 _ (by decide) RawRows.raw0882))

theorem site0873 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((873:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((883:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0873Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0883Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 883 f r x y z) (slots720.atReg 886 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 883 3 886 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 883 886 884 f r (row_of_literal 883 _ (by decide) RawRows.raw0883))
    (slots720.pos_x 883 886 884 f r (row_of_literal 883 _ (by decide) RawRows.raw0883))
    (slots720.inc_y 884 885 f r (row_of_literal 884 _ (by decide) RawRows.raw0884) (Or.inl (by decide)))
    (slots720.jump 885 883 f r (row_of_literal 885 _ (by decide) RawRows.raw0885))

theorem site0883 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((883:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((886:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0883Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


theorem site0886 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((886:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((887:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 886 _ (row_of_literal 886 _ (by decide) RawRows.raw0886)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site0887Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 887 f r x y z) (slots160.atReg 890 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 887 3 890 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 887 890 888 f r (row_of_literal 887 _ (by decide) RawRows.raw0887))
    (slots160.pos_x 887 890 888 f r (row_of_literal 887 _ (by decide) RawRows.raw0887))
    (slots160.inc_y 888 889 f r (row_of_literal 888 _ (by decide) RawRows.raw0888) (Or.inl (by decide)))
    (slots160.jump 889 887 f r (row_of_literal 889 _ (by decide) RawRows.raw0889))

theorem site0887 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((887:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((890:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0887Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0890Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 890 f r x y z) (slots210.atReg 893 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 890 3 893 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 890 893 891 f r (row_of_literal 890 _ (by decide) RawRows.raw0890))
    (slots210.pos_x 890 893 891 f r (row_of_literal 890 _ (by decide) RawRows.raw0890))
    (slots210.inc_y 891 892 f r (row_of_literal 891 _ (by decide) RawRows.raw0891) (Or.inl (by decide)))
    (slots210.jump 892 890 f r (row_of_literal 892 _ (by decide) RawRows.raw0892))

theorem site0890 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((890:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((893:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0890Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0893Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 893 f r x y z) (slots617.atReg 903 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 893 10 903 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 893 897 894 f r (row_of_literal 893 _ (by decide) RawRows.raw0893))
    (slots617.pos_y 893 897 894 f r (row_of_literal 893 _ (by decide) RawRows.raw0893))
    (slots617.inc_z 894 895 f r (row_of_literal 894 _ (by decide) RawRows.raw0894) (Or.inl (by decide)))
    (slots617.inc_x 895 896 f r (row_of_literal 895 _ (by decide) RawRows.raw0895) (Or.inl (by decide)))
    (slots617.jump 896 893 f r (row_of_literal 896 _ (by decide) RawRows.raw0896))
    (slots617.zero_x 897 903 898 f r (row_of_literal 897 _ (by decide) RawRows.raw0897))
    (slots617.pos_x 897 903 898 f r (row_of_literal 897 _ (by decide) RawRows.raw0897))
    (slots617.inc_z 898 899 f r (row_of_literal 898 _ (by decide) RawRows.raw0898) (Or.inl (by decide)))
    (slots617.zero_x 899 902 900 f r (row_of_literal 899 _ (by decide) RawRows.raw0899))
    (slots617.pos_x 899 902 900 f r (row_of_literal 899 _ (by decide) RawRows.raw0899))
    (slots617.inc_y 900 901 f r (row_of_literal 900 _ (by decide) RawRows.raw0900) (Or.inl (by decide)))
    (slots617.jump 901 899 f r (row_of_literal 901 _ (by decide) RawRows.raw0901))
    (slots617.jump 902 893 f r (row_of_literal 902 _ (by decide) RawRows.raw0902))

theorem site0893 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((893:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((903:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0893Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0903Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 903 f r x y z) (slots720.atReg 906 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 903 3 906 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 903 906 904 f r (row_of_literal 903 _ (by decide) RawRows.raw0903))
    (slots720.pos_x 903 906 904 f r (row_of_literal 903 _ (by decide) RawRows.raw0903))
    (slots720.inc_y 904 905 f r (row_of_literal 904 _ (by decide) RawRows.raw0904) (Or.inl (by decide)))
    (slots720.jump 905 903 f r (row_of_literal 905 _ (by decide) RawRows.raw0905))

theorem site0903 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((903:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((906:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0903Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0906Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 906 f r x y z) (slots361.atReg 910 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 906 4 910 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 906 910 907 f r (row_of_literal 906 _ (by decide) RawRows.raw0906))
    (slots361.pos_x 906 910 907 f r (row_of_literal 906 _ (by decide) RawRows.raw0906))
    (slots361.inc_y 907 908 f r (row_of_literal 907 _ (by decide) RawRows.raw0907) (Or.inl (by decide)))
    (slots361.inc_z 908 909 f r (row_of_literal 908 _ (by decide) RawRows.raw0908) (Or.inl (by decide)))
    (slots361.jump 909 906 f r (row_of_literal 909 _ (by decide) RawRows.raw0909))

theorem site0906 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((906:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((910:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0906Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site0910Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 910 f r x y z) (slots630.atReg 913 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 910 3 913 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 910 913 911 f r (row_of_literal 910 _ (by decide) RawRows.raw0910))
    (slots630.pos_x 910 913 911 f r (row_of_literal 910 _ (by decide) RawRows.raw0910))
    (slots630.inc_y 911 912 f r (row_of_literal 911 _ (by decide) RawRows.raw0911) (Or.inl (by decide)))
    (slots630.jump 912 910 f r (row_of_literal 912 _ (by decide) RawRows.raw0912))

theorem site0910 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((910:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((913:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0910Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site0913Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 913 f r x y z) (slots267.atReg 921 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 913 8 921 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 913 921 914 f r (row_of_literal 913 _ (by decide) RawRows.raw0913))
    (slots267.pos_x 913 921 914 f r (row_of_literal 913 _ (by decide) RawRows.raw0913))
    (slots267.inc_z 914 915 f r (row_of_literal 914 _ (by decide) RawRows.raw0914) (Or.inl (by decide)))
    (slots267.zero_y 915 917 916 f r (row_of_literal 915 _ (by decide) RawRows.raw0915))
    (slots267.pos_y 915 917 916 f r (row_of_literal 915 _ (by decide) RawRows.raw0915))
    (slots267.jump 916 920 f r (row_of_literal 916 _ (by decide) RawRows.raw0916))
    (slots267.zero_z 917 920 918 f r (row_of_literal 917 _ (by decide) RawRows.raw0917))
    (slots267.pos_z 917 920 918 f r (row_of_literal 917 _ (by decide) RawRows.raw0917))
    (slots267.inc_y 918 919 f r (row_of_literal 918 _ (by decide) RawRows.raw0918) (Or.inl (by decide)))
    (slots267.jump 919 917 f r (row_of_literal 919 _ (by decide) RawRows.raw0919))
    (slots267.jump 920 913 f r (row_of_literal 920 _ (by decide) RawRows.raw0920))

theorem site0913 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((913:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((921:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0913Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0921Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 921 f r x y z) (slots720.atReg 924 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 921 3 924 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 921 924 922 f r (row_of_literal 921 _ (by decide) RawRows.raw0921))
    (slots720.pos_x 921 924 922 f r (row_of_literal 921 _ (by decide) RawRows.raw0921))
    (slots720.inc_y 922 923 f r (row_of_literal 922 _ (by decide) RawRows.raw0922) (Or.inl (by decide)))
    (slots720.jump 923 921 f r (row_of_literal 923 _ (by decide) RawRows.raw0923))

theorem site0921 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((921:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((924:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0921Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0924Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 924 f r x y z) (slots617.atReg 934 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 924 10 934 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 924 928 925 f r (row_of_literal 924 _ (by decide) RawRows.raw0924))
    (slots617.pos_y 924 928 925 f r (row_of_literal 924 _ (by decide) RawRows.raw0924))
    (slots617.inc_z 925 926 f r (row_of_literal 925 _ (by decide) RawRows.raw0925) (Or.inl (by decide)))
    (slots617.inc_x 926 927 f r (row_of_literal 926 _ (by decide) RawRows.raw0926) (Or.inl (by decide)))
    (slots617.jump 927 924 f r (row_of_literal 927 _ (by decide) RawRows.raw0927))
    (slots617.zero_x 928 934 929 f r (row_of_literal 928 _ (by decide) RawRows.raw0928))
    (slots617.pos_x 928 934 929 f r (row_of_literal 928 _ (by decide) RawRows.raw0928))
    (slots617.inc_z 929 930 f r (row_of_literal 929 _ (by decide) RawRows.raw0929) (Or.inl (by decide)))
    (slots617.zero_x 930 933 931 f r (row_of_literal 930 _ (by decide) RawRows.raw0930))
    (slots617.pos_x 930 933 931 f r (row_of_literal 930 _ (by decide) RawRows.raw0930))
    (slots617.inc_y 931 932 f r (row_of_literal 931 _ (by decide) RawRows.raw0931) (Or.inl (by decide)))
    (slots617.jump 932 930 f r (row_of_literal 932 _ (by decide) RawRows.raw0932))
    (slots617.jump 933 924 f r (row_of_literal 933 _ (by decide) RawRows.raw0933))

theorem site0924 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((924:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((934:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0924Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0934Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 934 f r x y z) (slots710.atReg 938 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 934 4 938 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 934 938 935 f r (row_of_literal 934 _ (by decide) RawRows.raw0934))
    (slots710.pos_x 934 938 935 f r (row_of_literal 934 _ (by decide) RawRows.raw0934))
    (slots710.inc_y 935 936 f r (row_of_literal 935 _ (by decide) RawRows.raw0935) (Or.inl (by decide)))
    (slots710.inc_y 936 937 f r (row_of_literal 936 _ (by decide) RawRows.raw0936) (Or.inl (by decide)))
    (slots710.jump 937 934 f r (row_of_literal 937 _ (by decide) RawRows.raw0937))

theorem site0934 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((934:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((938:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0934Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site0938 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((938:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((939:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 938 _ (row_of_literal 938 _ (by decide) RawRows.raw0938)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site0939Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 939 f r x y z) (slots160.atReg 942 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 939 3 942 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 939 942 940 f r (row_of_literal 939 _ (by decide) RawRows.raw0939))
    (slots160.pos_x 939 942 940 f r (row_of_literal 939 _ (by decide) RawRows.raw0939))
    (slots160.inc_y 940 941 f r (row_of_literal 940 _ (by decide) RawRows.raw0940) (Or.inl (by decide)))
    (slots160.jump 941 939 f r (row_of_literal 941 _ (by decide) RawRows.raw0941))

theorem site0939 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((939:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((942:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0939Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0942Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 942 f r x y z) (slots210.atReg 945 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 942 3 945 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 942 945 943 f r (row_of_literal 942 _ (by decide) RawRows.raw0942))
    (slots210.pos_x 942 945 943 f r (row_of_literal 942 _ (by decide) RawRows.raw0942))
    (slots210.inc_y 943 944 f r (row_of_literal 943 _ (by decide) RawRows.raw0943) (Or.inl (by decide)))
    (slots210.jump 944 942 f r (row_of_literal 944 _ (by decide) RawRows.raw0944))

theorem site0942 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((942:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((945:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0942Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0945Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 945 f r x y z) (slots617.atReg 955 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 945 10 955 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 945 949 946 f r (row_of_literal 945 _ (by decide) RawRows.raw0945))
    (slots617.pos_y 945 949 946 f r (row_of_literal 945 _ (by decide) RawRows.raw0945))
    (slots617.inc_z 946 947 f r (row_of_literal 946 _ (by decide) RawRows.raw0946) (Or.inl (by decide)))
    (slots617.inc_x 947 948 f r (row_of_literal 947 _ (by decide) RawRows.raw0947) (Or.inl (by decide)))
    (slots617.jump 948 945 f r (row_of_literal 948 _ (by decide) RawRows.raw0948))
    (slots617.zero_x 949 955 950 f r (row_of_literal 949 _ (by decide) RawRows.raw0949))
    (slots617.pos_x 949 955 950 f r (row_of_literal 949 _ (by decide) RawRows.raw0949))
    (slots617.inc_z 950 951 f r (row_of_literal 950 _ (by decide) RawRows.raw0950) (Or.inl (by decide)))
    (slots617.zero_x 951 954 952 f r (row_of_literal 951 _ (by decide) RawRows.raw0951))
    (slots617.pos_x 951 954 952 f r (row_of_literal 951 _ (by decide) RawRows.raw0951))
    (slots617.inc_y 952 953 f r (row_of_literal 952 _ (by decide) RawRows.raw0952) (Or.inl (by decide)))
    (slots617.jump 953 951 f r (row_of_literal 953 _ (by decide) RawRows.raw0953))
    (slots617.jump 954 945 f r (row_of_literal 954 _ (by decide) RawRows.raw0954))

theorem site0945 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((945:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((955:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0945Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0955Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 955 f r x y z) (slots720.atReg 958 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 955 3 958 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 955 958 956 f r (row_of_literal 955 _ (by decide) RawRows.raw0955))
    (slots720.pos_x 955 958 956 f r (row_of_literal 955 _ (by decide) RawRows.raw0955))
    (slots720.inc_y 956 957 f r (row_of_literal 956 _ (by decide) RawRows.raw0956) (Or.inl (by decide)))
    (slots720.jump 957 955 f r (row_of_literal 957 _ (by decide) RawRows.raw0957))

theorem site0955 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((955:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((958:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0955Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0958Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 958 f r x y z) (slots461.atReg 962 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 958 4 962 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 958 962 959 f r (row_of_literal 958 _ (by decide) RawRows.raw0958))
    (slots461.pos_x 958 962 959 f r (row_of_literal 958 _ (by decide) RawRows.raw0958))
    (slots461.inc_y 959 960 f r (row_of_literal 959 _ (by decide) RawRows.raw0959) (Or.inl (by decide)))
    (slots461.inc_z 960 961 f r (row_of_literal 960 _ (by decide) RawRows.raw0960) (Or.inl (by decide)))
    (slots461.jump 961 958 f r (row_of_literal 961 _ (by decide) RawRows.raw0961))

theorem site0958 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((958:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((962:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0958Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site0962Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 962 f r x y z) (slots640.atReg 965 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 962 3 965 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 962 965 963 f r (row_of_literal 962 _ (by decide) RawRows.raw0962))
    (slots640.pos_x 962 965 963 f r (row_of_literal 962 _ (by decide) RawRows.raw0962))
    (slots640.inc_y 963 964 f r (row_of_literal 963 _ (by decide) RawRows.raw0963) (Or.inl (by decide)))
    (slots640.jump 964 962 f r (row_of_literal 964 _ (by decide) RawRows.raw0964))

theorem site0962 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((962:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((965:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0962Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site0965Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 965 f r x y z) (slots267.atReg 973 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 965 8 973 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 965 973 966 f r (row_of_literal 965 _ (by decide) RawRows.raw0965))
    (slots267.pos_x 965 973 966 f r (row_of_literal 965 _ (by decide) RawRows.raw0965))
    (slots267.inc_z 966 967 f r (row_of_literal 966 _ (by decide) RawRows.raw0966) (Or.inl (by decide)))
    (slots267.zero_y 967 969 968 f r (row_of_literal 967 _ (by decide) RawRows.raw0967))
    (slots267.pos_y 967 969 968 f r (row_of_literal 967 _ (by decide) RawRows.raw0967))
    (slots267.jump 968 972 f r (row_of_literal 968 _ (by decide) RawRows.raw0968))
    (slots267.zero_z 969 972 970 f r (row_of_literal 969 _ (by decide) RawRows.raw0969))
    (slots267.pos_z 969 972 970 f r (row_of_literal 969 _ (by decide) RawRows.raw0969))
    (slots267.inc_y 970 971 f r (row_of_literal 970 _ (by decide) RawRows.raw0970) (Or.inl (by decide)))
    (slots267.jump 971 969 f r (row_of_literal 971 _ (by decide) RawRows.raw0971))
    (slots267.jump 972 965 f r (row_of_literal 972 _ (by decide) RawRows.raw0972))

theorem site0965 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((965:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((973:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0965Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0973Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 973 f r x y z) (slots720.atReg 976 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 973 3 976 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 973 976 974 f r (row_of_literal 973 _ (by decide) RawRows.raw0973))
    (slots720.pos_x 973 976 974 f r (row_of_literal 973 _ (by decide) RawRows.raw0973))
    (slots720.inc_y 974 975 f r (row_of_literal 974 _ (by decide) RawRows.raw0974) (Or.inl (by decide)))
    (slots720.jump 975 973 f r (row_of_literal 975 _ (by decide) RawRows.raw0975))

theorem site0973 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((973:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((976:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0973Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0976Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 976 f r x y z) (slots617.atReg 986 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 976 10 986 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 976 980 977 f r (row_of_literal 976 _ (by decide) RawRows.raw0976))
    (slots617.pos_y 976 980 977 f r (row_of_literal 976 _ (by decide) RawRows.raw0976))
    (slots617.inc_z 977 978 f r (row_of_literal 977 _ (by decide) RawRows.raw0977) (Or.inl (by decide)))
    (slots617.inc_x 978 979 f r (row_of_literal 978 _ (by decide) RawRows.raw0978) (Or.inl (by decide)))
    (slots617.jump 979 976 f r (row_of_literal 979 _ (by decide) RawRows.raw0979))
    (slots617.zero_x 980 986 981 f r (row_of_literal 980 _ (by decide) RawRows.raw0980))
    (slots617.pos_x 980 986 981 f r (row_of_literal 980 _ (by decide) RawRows.raw0980))
    (slots617.inc_z 981 982 f r (row_of_literal 981 _ (by decide) RawRows.raw0981) (Or.inl (by decide)))
    (slots617.zero_x 982 985 983 f r (row_of_literal 982 _ (by decide) RawRows.raw0982))
    (slots617.pos_x 982 985 983 f r (row_of_literal 982 _ (by decide) RawRows.raw0982))
    (slots617.inc_y 983 984 f r (row_of_literal 983 _ (by decide) RawRows.raw0983) (Or.inl (by decide)))
    (slots617.jump 984 982 f r (row_of_literal 984 _ (by decide) RawRows.raw0984))
    (slots617.jump 985 976 f r (row_of_literal 985 _ (by decide) RawRows.raw0985))

theorem site0976 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((976:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((986:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0976Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0986Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 986 f r x y z) (slots710.atReg 990 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 986 4 990 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 986 990 987 f r (row_of_literal 986 _ (by decide) RawRows.raw0986))
    (slots710.pos_x 986 990 987 f r (row_of_literal 986 _ (by decide) RawRows.raw0986))
    (slots710.inc_y 987 988 f r (row_of_literal 987 _ (by decide) RawRows.raw0987) (Or.inl (by decide)))
    (slots710.inc_y 988 989 f r (row_of_literal 988 _ (by decide) RawRows.raw0988) (Or.inl (by decide)))
    (slots710.jump 989 986 f r (row_of_literal 989 _ (by decide) RawRows.raw0989))

theorem site0986 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((986:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((990:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0986Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site0990 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((990:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((991:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 990 _ (row_of_literal 990 _ (by decide) RawRows.raw0990)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


end PA192.ModelSearch.Register181.Certified
