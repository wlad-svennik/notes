import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w192_0 : checkWitness 192 false false 611 = true := by decide +kernel
private theorem w192_1 : checkWitness 192 false true 4695 = true := by decide +kernel
private theorem w192_2 : checkWitness 192 true false 611 = true := by decide +kernel
private theorem w192_3 : checkWitness 192 true true 4695 = true := by decide +kernel
private theorem cases192 : checkFour 192 (611,4695,611,4695) = true := by
  simp only [checkFour, w192_0, w192_1, w192_2, w192_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one192 : Coverage 192 193 := checkList_sound (ws:=[(611,4695,611,4695)]) (by simpa only [checkList, Bool.and_true] using cases192)
private theorem w193_0 : checkWitness 193 false false 8880 = true := by decide +kernel
private theorem w193_2 : checkWitness 193 true false 8876 = true := by decide +kernel
private theorem cases193 : checkFour 193 (8880,0,8876,0) = true := by
  simp only [checkFour, w193_0, w193_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one193 : Coverage 193 194 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases193)
private theorem w194_0 : checkWitness 194 false false 8876 = true := by decide +kernel
private theorem w194_2 : checkWitness 194 true false 8872 = true := by decide +kernel
private theorem cases194 : checkFour 194 (8876,0,8872,0) = true := by
  simp only [checkFour, w194_0, w194_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one194 : Coverage 194 195 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases194)
private theorem w195_0 : checkWitness 195 false false 72 = true := by decide +kernel
private theorem w195_2 : checkWitness 195 true false 72 = true := by decide +kernel
private theorem cases195 : checkFour 195 (72,0,72,0) = true := by
  simp only [checkFour, w195_0, w195_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one195 : Coverage 195 196 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases195)
private theorem w196_0 : checkWitness 196 false false 530 = true := by decide +kernel
private theorem w196_1 : checkWitness 196 false true 4626 = true := by decide +kernel
private theorem w196_2 : checkWitness 196 true false 530 = true := by decide +kernel
private theorem w196_3 : checkWitness 196 true true 4626 = true := by decide +kernel
private theorem cases196 : checkFour 196 (530,4626,530,4626) = true := by
  simp only [checkFour, w196_0, w196_1, w196_2, w196_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one196 : Coverage 196 197 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases196)
private theorem w197_0 : checkWitness 197 false false 8950 = true := by decide +kernel
private theorem w197_2 : checkWitness 197 true false 8941 = true := by decide +kernel
private theorem cases197 : checkFour 197 (8950,0,8941,0) = true := by
  simp only [checkFour, w197_0, w197_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one197 : Coverage 197 198 := checkList_sound (ws:=[(8950,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases197)
private theorem w198_0 : checkWitness 198 false false 66 = true := by decide +kernel
private theorem w198_2 : checkWitness 198 true false 66 = true := by decide +kernel
private theorem cases198 : checkFour 198 (66,0,66,0) = true := by
  simp only [checkFour, w198_0, w198_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one198 : Coverage 198 199 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases198)
private theorem w199_0 : checkWitness 199 false false 532 = true := by decide +kernel
private theorem w199_1 : checkWitness 199 false true 4628 = true := by decide +kernel
private theorem w199_2 : checkWitness 199 true false 532 = true := by decide +kernel
private theorem w199_3 : checkWitness 199 true true 4628 = true := by decide +kernel
private theorem cases199 : checkFour 199 (532,4628,532,4628) = true := by
  simp only [checkFour, w199_0, w199_1, w199_2, w199_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one199 : Coverage 199 200 := checkList_sound (ws:=[(532,4628,532,4628)]) (by simpa only [checkList, Bool.and_true] using cases199)
private theorem w200_0 : checkWitness 200 false false 8890 = true := by decide +kernel
private theorem w200_2 : checkWitness 200 true false 8886 = true := by decide +kernel
private theorem cases200 : checkFour 200 (8890,0,8886,0) = true := by
  simp only [checkFour, w200_0, w200_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one200 : Coverage 200 201 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases200)
private theorem w201_0 : checkWitness 201 false false 68 = true := by decide +kernel
private theorem w201_2 : checkWitness 201 true false 68 = true := by decide +kernel
private theorem cases201 : checkFour 201 (68,0,68,0) = true := by
  simp only [checkFour, w201_0, w201_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one201 : Coverage 201 202 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases201)
private theorem w202_0 : checkWitness 202 false false 570 = true := by decide +kernel
private theorem w202_1 : checkWitness 202 false true 4666 = true := by decide +kernel
private theorem w202_2 : checkWitness 202 true false 570 = true := by decide +kernel
private theorem w202_3 : checkWitness 202 true true 4666 = true := by decide +kernel
private theorem cases202 : checkFour 202 (570,4666,570,4666) = true := by
  simp only [checkFour, w202_0, w202_1, w202_2, w202_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one202 : Coverage 202 203 := checkList_sound (ws:=[(570,4666,570,4666)]) (by simpa only [checkList, Bool.and_true] using cases202)
private theorem w203_0 : checkWitness 203 false false 8911 = true := by decide +kernel
private theorem w203_2 : checkWitness 203 true false 8907 = true := by decide +kernel
private theorem cases203 : checkFour 203 (8911,0,8907,0) = true := by
  simp only [checkFour, w203_0, w203_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one203 : Coverage 203 204 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases203)
private theorem w204_0 : checkWitness 204 false false 8946 = true := by decide +kernel
private theorem w204_2 : checkWitness 204 true false 8937 = true := by decide +kernel
private theorem cases204 : checkFour 204 (8946,0,8937,0) = true := by
  simp only [checkFour, w204_0, w204_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one204 : Coverage 204 205 := checkList_sound (ws:=[(8946,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases204)
private theorem w205_0 : checkWitness 205 false false 92 = true := by decide +kernel
private theorem w205_2 : checkWitness 205 true false 92 = true := by decide +kernel
private theorem cases205 : checkFour 205 (92,0,92,0) = true := by
  simp only [checkFour, w205_0, w205_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one205 : Coverage 205 206 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases205)
private theorem w206_0 : checkWitness 206 false false 658 = true := by decide +kernel
private theorem w206_1 : checkWitness 206 false true 4750 = true := by decide +kernel
private theorem w206_2 : checkWitness 206 true false 649 = true := by decide +kernel
private theorem w206_3 : checkWitness 206 true true 4741 = true := by decide +kernel
private theorem cases206 : checkFour 206 (658,4750,649,4741) = true := by
  simp only [checkFour, w206_0, w206_1, w206_2, w206_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one206 : Coverage 206 207 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases206)
private theorem w207_0 : checkWitness 207 false false 8907 = true := by decide +kernel
private theorem w207_2 : checkWitness 207 true false 8903 = true := by decide +kernel
private theorem cases207 : checkFour 207 (8907,0,8903,0) = true := by
  simp only [checkFour, w207_0, w207_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one207 : Coverage 207 208 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases207)
private theorem w208_0 : checkWitness 208 false false 652 = true := by decide +kernel
private theorem w208_1 : checkWitness 208 false true 4744 = true := by decide +kernel
private theorem w208_2 : checkWitness 208 true false 643 = true := by decide +kernel
private theorem w208_3 : checkWitness 208 true true 4735 = true := by decide +kernel
private theorem cases208 : checkFour 208 (652,4744,643,4735) = true := by
  simp only [checkFour, w208_0, w208_1, w208_2, w208_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one208 : Coverage 208 209 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases208)
private theorem w209_0 : checkWitness 209 false false 8876 = true := by decide +kernel
private theorem w209_2 : checkWitness 209 true false 8872 = true := by decide +kernel
private theorem cases209 : checkFour 209 (8876,0,8872,0) = true := by
  simp only [checkFour, w209_0, w209_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one209 : Coverage 209 210 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases209)
private theorem w210_0 : checkWitness 210 false false 80 = true := by decide +kernel
private theorem w210_2 : checkWitness 210 true false 80 = true := by decide +kernel
private theorem cases210 : checkFour 210 (80,0,80,0) = true := by
  simp only [checkFour, w210_0, w210_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one210 : Coverage 210 211 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases210)
private theorem w211_0 : checkWitness 211 false false 72 = true := by decide +kernel
private theorem w211_2 : checkWitness 211 true false 72 = true := by decide +kernel
private theorem cases211 : checkFour 211 (72,0,72,0) = true := by
  simp only [checkFour, w211_0, w211_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one211 : Coverage 211 212 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases211)
private theorem w212_0 : checkWitness 212 false false 617 = true := by decide +kernel
private theorem w212_1 : checkWitness 212 false true 4701 = true := by decide +kernel
private theorem w212_2 : checkWitness 212 true false 617 = true := by decide +kernel
private theorem w212_3 : checkWitness 212 true true 4701 = true := by decide +kernel
private theorem cases212 : checkFour 212 (617,4701,617,4701) = true := by
  simp only [checkFour, w212_0, w212_1, w212_2, w212_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one212 : Coverage 212 213 := checkList_sound (ws:=[(617,4701,617,4701)]) (by simpa only [checkList, Bool.and_true] using cases212)
private theorem w213_0 : checkWitness 213 false false 8870 = true := by decide +kernel
private theorem w213_2 : checkWitness 213 true false 8866 = true := by decide +kernel
private theorem cases213 : checkFour 213 (8870,0,8866,0) = true := by
  simp only [checkFour, w213_0, w213_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one213 : Coverage 213 214 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases213)
private theorem w214_0 : checkWitness 214 false false 72 = true := by decide +kernel
private theorem w214_2 : checkWitness 214 true false 72 = true := by decide +kernel
private theorem cases214 : checkFour 214 (72,0,72,0) = true := by
  simp only [checkFour, w214_0, w214_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one214 : Coverage 214 215 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases214)
private theorem w215_0 : checkWitness 215 false false 585 = true := by decide +kernel
private theorem w215_1 : checkWitness 215 false true 4681 = true := by decide +kernel
private theorem w215_2 : checkWitness 215 true false 585 = true := by decide +kernel
private theorem w215_3 : checkWitness 215 true true 4681 = true := by decide +kernel
private theorem cases215 : checkFour 215 (585,4681,585,4681) = true := by
  simp only [checkFour, w215_0, w215_1, w215_2, w215_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one215 : Coverage 215 216 := checkList_sound (ws:=[(585,4681,585,4681)]) (by simpa only [checkList, Bool.and_true] using cases215)
private theorem w216_0 : checkWitness 216 false false 8938 = true := by decide +kernel
private theorem w216_2 : checkWitness 216 true false 8929 = true := by decide +kernel
private theorem cases216 : checkFour 216 (8938,0,8929,0) = true := by
  simp only [checkFour, w216_0, w216_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one216 : Coverage 216 217 := checkList_sound (ws:=[(8938,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases216)
private theorem w217_0 : checkWitness 217 false false 8884 = true := by decide +kernel
private theorem w217_2 : checkWitness 217 true false 8880 = true := by decide +kernel
private theorem cases217 : checkFour 217 (8884,0,8880,0) = true := by
  simp only [checkFour, w217_0, w217_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one217 : Coverage 217 218 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases217)
private theorem w218_0 : checkWitness 218 false false 80 = true := by decide +kernel
private theorem w218_2 : checkWitness 218 true false 80 = true := by decide +kernel
private theorem cases218 : checkFour 218 (80,0,80,0) = true := by
  simp only [checkFour, w218_0, w218_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one218 : Coverage 218 219 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases218)
private theorem w219_0 : checkWitness 219 false false 668 = true := by decide +kernel
private theorem w219_1 : checkWitness 219 false true 4756 = true := by decide +kernel
private theorem w219_2 : checkWitness 219 true false 659 = true := by decide +kernel
private theorem w219_3 : checkWitness 219 true true 4747 = true := by decide +kernel
private theorem cases219 : checkFour 219 (668,4756,659,4747) = true := by
  simp only [checkFour, w219_0, w219_1, w219_2, w219_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one219 : Coverage 219 220 := checkList_sound (ws:=[(668,4756,659,4747)]) (by simpa only [checkList, Bool.and_true] using cases219)
private theorem w220_0 : checkWitness 220 false false 8903 = true := by decide +kernel
private theorem w220_2 : checkWitness 220 true false 8899 = true := by decide +kernel
private theorem cases220 : checkFour 220 (8903,0,8899,0) = true := by
  simp only [checkFour, w220_0, w220_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one220 : Coverage 220 221 := checkList_sound (ws:=[(8903,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases220)
private theorem w221_0 : checkWitness 221 false false 70 = true := by decide +kernel
private theorem w221_2 : checkWitness 221 true false 70 = true := by decide +kernel
private theorem cases221 : checkFour 221 (70,0,70,0) = true := by
  simp only [checkFour, w221_0, w221_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one221 : Coverage 221 222 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases221)
private theorem w222_0 : checkWitness 222 false false 506 = true := by decide +kernel
private theorem w222_1 : checkWitness 222 false true 4602 = true := by decide +kernel
private theorem w222_2 : checkWitness 222 true false 506 = true := by decide +kernel
private theorem w222_3 : checkWitness 222 true true 4602 = true := by decide +kernel
private theorem cases222 : checkFour 222 (506,4602,506,4602) = true := by
  simp only [checkFour, w222_0, w222_1, w222_2, w222_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one222 : Coverage 222 223 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases222)
private theorem w223_0 : checkWitness 223 false false 8924 = true := by decide +kernel
private theorem w223_2 : checkWitness 223 true false 8915 = true := by decide +kernel
private theorem cases223 : checkFour 223 (8924,0,8915,0) = true := by
  simp only [checkFour, w223_0, w223_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one223 : Coverage 223 224 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases223)
theorem cover0192 : Coverage 192 224 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one192 one193) (Coverage.join one194 one195)) (Coverage.join (Coverage.join one196 one197) (Coverage.join one198 one199))) (Coverage.join (Coverage.join (Coverage.join one200 one201) (Coverage.join one202 one203)) (Coverage.join (Coverage.join one204 one205) (Coverage.join one206 one207)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one208 one209) (Coverage.join one210 one211)) (Coverage.join (Coverage.join one212 one213) (Coverage.join one214 one215))) (Coverage.join (Coverage.join (Coverage.join one216 one217) (Coverage.join one218 one219)) (Coverage.join (Coverage.join one220 one221) (Coverage.join one222 one223)))))
end NF181PA.Symbolic
