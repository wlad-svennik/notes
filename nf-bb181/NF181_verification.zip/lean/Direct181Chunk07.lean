module
public import Direct181Snapshots
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem chunk41500 : Prefix 500 snap41000 snap41500 := checked _ _ _ (by decide) (by decide)
theorem chunk42000 : Prefix 500 snap41500 snap42000 := checked _ _ _ (by decide) (by decide)
theorem chunk42500 : Prefix 500 snap42000 snap42500 := checked _ _ _ (by decide) (by decide)
theorem chunk43000 : Prefix 500 snap42500 snap43000 := checked _ _ _ (by decide) (by decide)
theorem chunk43500 : Prefix 500 snap43000 snap43500 := checked _ _ _ (by decide) (by decide)
theorem chunk44000 : Prefix 500 snap43500 snap44000 := checked _ _ _ (by decide) (by decide)
theorem chunk44500 : Prefix 500 snap44000 snap44500 := checked _ _ _ (by decide) (by decide)
theorem chunk45000 : Prefix 500 snap44500 snap45000 := checked _ _ _ (by decide) (by decide)
theorem chunk45500 : Prefix 500 snap45000 snap45500 := checked _ _ _ (by decide) (by decide)
theorem chunk46000 : Prefix 500 snap45500 snap46000 := checked _ _ _ (by decide) (by decide)
theorem chunk46500 : Prefix 500 snap46000 snap46500 := checked _ _ _ (by decide) (by decide)
theorem chunk47000 : Prefix 500 snap46500 snap47000 := checked _ _ _ (by decide) (by decide)
end Direct181.Boot
