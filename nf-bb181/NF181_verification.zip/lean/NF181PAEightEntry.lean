module
public import NF181PASigned
public import NF181PAEightSound
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.Register181 PA192.ModelSearch.Register181.Certified PA192.ModelSearch.Register181.Commands
open NF181PA.Packed NF181PA.Scanner PA192.ModelSearch.Enumeration
namespace NF181PA.Reverse
open NF181PA.ScannerSource NF181PA.Sound
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxRecDepth 9000
set_option maxHeartbeats 3500000

private theorem unread_empty : ∀ j : V, unread j 0=0 := by
  apply modelInduct
  · definability
  · simp [unread]
  · intro j ih
    change iterate consumePair j 0=0 at ih
    change iterate consumePair (j+1) 0=0
    rw [iterate_succ,ih]
    simp [consumePair,right]

private theorem coldRefill (e : V) :
    Reach (vm 0 1 0 e 0) (vm24 0 0 e 0) := by
  simpa [vm,vm24,atS,left,right] using coldRefill0To24 (0:V) (top e) (stack e) 0 (param e) (cache e)

/-- The signed initial AX followed by the two lower-rank batches and first
counter increment enters the actual scanner with empty candidate input. -/
theorem signed_entry_sound : ∃ e : V, Reach (origin V) (view (fresh 0 0 e)) ∧ goodState e := by
  let z := front8 (0:V) 0 2 0 (cantor 0 0)
  have em := emitFields (1:V) 0 0 0 2 0 0 0 0 0
  have enter : Reach (origin V) (atS 2849 1 0 (left z) (right z) 2 0 0 0) := by
    simpa only [origin,atS,Nat.cast_ofNat,z,zero_add,cantor,add_zero,triangle_zero] using em
  have ret := site2849 (1:V) 0 (left z) (right z) 2 0 0 0 0 0
  let b := iterate nextBatch 2 (packBatch 2 z 0 0 0)
  let e := afterAX (body b)
  have run := batchesRun (1:V) 0 2 z 0 0 0 (by simp [z,front8])
  rw [entry_pack] at run
  have nil : fields b=0 := (ax_ends (2:V) z 0 0 0).trans (unread_empty 2)
  change Reach _ (vm 0 1 0 e (fields b)) at run
  rw [nil] at run
  have bottom : goodStack (cantor (0:V) 0) := push provZero goodZero
  have first : goodStack z := goodFront 0 0 2 0 _ le_rfl bottom
  have initial : goodStack (body (packBatch 2 z 0 0 0)) := by simpa only [packBatch,body,pi₂_pair,pi₁_pair] using first
  refine ⟨e,?_,goodPop (goodIterBatch _ 2 initial)⟩
  rw [view_fresh]
  exact ((enter.trans ret).trans run).trans (coldRefill e)

end NF181PA.Reverse
#print axioms NF181PA.Reverse.signed_entry_sound
