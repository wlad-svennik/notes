module
public import Src181CmdEmit15
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter513 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2481:Nat):V) f (vector n (v+y) (emitAtom82 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2477 f n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter512 f n t s c u v y d w).trans mid

theorem commandEmitAfter514 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2484:Nat):V) f (vector n (v+y) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2481 f n (v+y) (emitAtom82 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter513 f n t s c u v y d w).trans mid

theorem commandEmitAfter515 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2487:Nat):V) f (vector n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site2484 f n (v+y) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter514 f n t s c u v y d w).trans mid

theorem commandEmitAfter516 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2490:Nat):V) f (vector n (emitAtom82 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site2487 f n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d1 : ((0+(emitAtom82 n t s c u v y d w)):V)=(emitAtom82 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter515 f n t s c u v y d w).trans mid

theorem commandEmitAfter517 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2500:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom83 n t s c u v y d w) w)) := by
  have micro := site2490 f n (emitAtom82 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (emitAtom82 n t s c u v y d w))):V)=(emitAtom83 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (emitAtom82 n t s c u v y d w))):V)=(0+(emitAtom83 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter516 f n t s c u v y d w).trans mid

theorem commandEmitAfter518 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2503:Nat):V) f (vector n 0 (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2500 f n 0 0 c (d+u) (v+y) 0 (emitAtom83 n t s c u v y d w) w
  have d2 : ((0+(emitAtom83 n t s c u v y d w)):V)=(emitAtom83 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter517 f n t s c u v y d w).trans mid

theorem commandEmitAfter519 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2507:Nat):V) f (vector n (d+u) (emitAtom83 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2503 f n 0 (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter518 f n t s c u v y d w).trans mid

theorem commandEmitAfter520 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2510:Nat):V) f (vector n (d+u) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2507 f n (d+u) (emitAtom83 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter519 f n t s c u v y d w).trans mid

theorem commandEmitAfter521 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2513:Nat):V) f (vector n 0 (emitAtom83 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2510 f n (d+u) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter520 f n t s c u v y d w).trans mid

theorem commandEmitAfter522 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2516:Nat):V) f (vector n (emitAtom83 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2513 f n 0 (emitAtom83 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom83 n t s c u v y d w)):V)=(emitAtom83 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter521 f n t s c u v y d w).trans mid

theorem commandEmitAfter523 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2526:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom84 n t s c u v y d w) w)) := by
  have micro := site2516 f n (emitAtom83 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom83 n t s c u v y d w))):V)=(emitAtom84 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom83 n t s c u v y d w))):V)=(0+(emitAtom84 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter522 f n t s c u v y d w).trans mid

theorem commandEmitAfter524 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2529:Nat):V) f (vector n 0 (emitAtom84 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2526 f n 0 0 c (d+u) (v+y) 0 (emitAtom84 n t s c u v y d w) w
  have d2 : ((0+(emitAtom84 n t s c u v y d w)):V)=(emitAtom84 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter523 f n t s c u v y d w).trans mid

theorem commandEmitAfter525 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2533:Nat):V) f (vector n (v+y) (emitAtom84 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2529 f n 0 (emitAtom84 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter524 f n t s c u v y d w).trans mid

theorem commandEmitAfter526 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2536:Nat):V) f (vector n (v+y) (emitAtom84 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2533 f n (v+y) (emitAtom84 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter525 f n t s c u v y d w).trans mid

theorem commandEmitAfter527 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2544:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom83 n t s c u v y d w) w)) := by
  have micro := site2536 f n (v+y) (emitAtom84 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom84 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom84 n t s c u v y d w)):V)=(0+(emitAtom84 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom84 n t s c u v y d w))):V)=left (emitAtom84 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom83 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom84 n t s c u v y d w))):V)=(emitAtom83 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom84 n t s c u v y d w)):V)=(0+(emitAtom84 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom84 n t s c u v y d w))):V)=right (emitAtom84 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom83 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter526 f n t s c u v y d w).trans mid

theorem commandEmitAfter528 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2547:Nat):V) f (vector n (v+y) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2544 f n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom83 n t s c u v y d w) w
  have d2 : ((0+(emitAtom83 n t s c u v y d w)):V)=(emitAtom83 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter527 f n t s c u v y d w).trans mid

theorem commandEmitAfter529 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2557:Nat):V) f (vector n 0 (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w)) := by
  have micro := site2547 f n (v+y) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (v+y))):V)=(emitAtom24 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (v+y))):V)=(0+(emitAtom24 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter528 f n t s c u v y d w).trans mid

theorem commandEmitAfter530 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2561:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2557 f n 0 (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=(0+((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter529 f n t s c u v y d w).trans mid

theorem commandEmitAfter531 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2562:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2561 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter530 f n t s c u v y d w).trans mid

theorem commandEmitAfter532 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2563:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2562 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1)+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter531 f n t s c u v y d w).trans mid

theorem commandEmitAfter533 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2571:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) 0 c (d+u) (v+y) (v+y) (emitAtom82 n t s c u v y d w) w)) := by
  have micro := site2563 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) (emitAtom83 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom83 n t s c u v y d w))):V)=(v+y) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom83 n t s c u v y d w)):V)=(0+(emitAtom83 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom83 n t s c u v y d w))):V)=left (emitAtom83 n t s c u v y d w))).trans (by change left (cantor (v+y) (emitAtom82 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom83 n t s c u v y d w))):V)=(emitAtom82 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom83 n t s c u v y d w)):V)=(0+(emitAtom83 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom83 n t s c u v y d w))):V)=right (emitAtom83 n t s c u v y d w))).trans (by change right (cantor (v+y) (emitAtom82 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter532 f n t s c u v y d w).trans mid

theorem commandEmitAfter534 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2574:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site2571 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) 0 c (d+u) (v+y) (v+y) (emitAtom82 n t s c u v y d w) w
  have d2 : ((0+(emitAtom82 n t s c u v y d w)):V)=(emitAtom82 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter533 f n t s c u v y d w).trans mid

theorem commandEmitAfter535 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2584:Nat):V) f (vector n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom85 n t s c u v y d w) w)) := by
  have micro := site2574 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2))):V)=(emitAtom85 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2))):V)=(0+(emitAtom85 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter534 f n t s c u v y d w).trans mid

theorem commandEmitAfter536 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2588:Nat):V) f (vector n ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2584 f n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom85 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom85 n t s c u v y d w))):V)=((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom85 n t s c u v y d w))):V)=(0+((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter535 f n t s c u v y d w).trans mid

theorem commandEmitAfter537 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2589:Nat):V) f (vector n ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2588 f n ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w))+1):V)=((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter536 f n t s c u v y d w).trans mid

theorem commandEmitAfter538 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2592:Nat):V) f (vector n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2589 f n ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1)):V)=((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter537 f n t s c u v y d w).trans mid

theorem commandEmitAfter539 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2595:Nat):V) f (vector n (emitAtom82 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2592 f n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom82 n t s c u v y d w)):V)=(emitAtom82 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter538 f n t s c u v y d w).trans mid

theorem commandEmitAfter540 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2605:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom86 n t s c u v y d w) w)) := by
  have micro := site2595 f n (emitAtom82 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w))):V)=(emitAtom86 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w))):V)=(0+(emitAtom86 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter539 f n t s c u v y d w).trans mid

theorem commandEmitAfter541 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2608:Nat):V) f (vector n 0 (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2605 f n 0 0 c (d+u) (v+y) 0 (emitAtom86 n t s c u v y d w) w
  have d2 : ((0+(emitAtom86 n t s c u v y d w)):V)=(emitAtom86 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter540 f n t s c u v y d w).trans mid

theorem commandEmitAfter542 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2612:Nat):V) f (vector n (d+u) (emitAtom86 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2608 f n 0 (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter541 f n t s c u v y d w).trans mid

theorem commandEmitAfter543 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2615:Nat):V) f (vector n (d+u) (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2612 f n (d+u) (emitAtom86 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter542 f n t s c u v y d w).trans mid

theorem commandEmitAfter544 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2618:Nat):V) f (vector n 0 (emitAtom86 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2615 f n (d+u) (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter543 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
