module
public import Direct181Snapshots
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem chunk35500 : Prefix 500 snap35000 snap35500 := checked _ _ _ (by decide) (by decide)
theorem chunk36000 : Prefix 500 snap35500 snap36000 := checked _ _ _ (by decide) (by decide)
theorem chunk36500 : Prefix 500 snap36000 snap36500 := checked _ _ _ (by decide) (by decide)
theorem chunk37000 : Prefix 500 snap36500 snap37000 := checked _ _ _ (by decide) (by decide)
theorem chunk37500 : Prefix 500 snap37000 snap37500 := checked _ _ _ (by decide) (by decide)
theorem chunk38000 : Prefix 500 snap37500 snap38000 := checked _ _ _ (by decide) (by decide)
theorem chunk38500 : Prefix 500 snap38000 snap38500 := checked _ _ _ (by decide) (by decide)
theorem chunk39000 : Prefix 500 snap38500 snap39000 := checked _ _ _ (by decide) (by decide)
theorem chunk39500 : Prefix 500 snap39000 snap39500 := checked _ _ _ (by decide) (by decide)
theorem chunk40000 : Prefix 500 snap39500 snap40000 := checked _ _ _ (by decide) (by decide)
theorem chunk40500 : Prefix 500 snap40000 snap40500 := checked _ _ _ (by decide) (by decide)
theorem chunk41000 : Prefix 500 snap40500 snap41000 := checked _ _ _ (by decide) (by decide)
end Direct181.Boot
