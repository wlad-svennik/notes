import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2048_0 : checkWitness 2048 false false 82 = true := by decide +kernel
private theorem w2048_2 : checkWitness 2048 true false 82 = true := by decide +kernel
private theorem cases2048 : checkFour 2048 (82,0,82,0) = true := by
  simp only [checkFour, w2048_0, w2048_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2048 : Coverage 2048 2049 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2048)
private theorem w2049_0 : checkWitness 2049 false false 8872 = true := by decide +kernel
private theorem w2049_2 : checkWitness 2049 true false 8868 = true := by decide +kernel
private theorem cases2049 : checkFour 2049 (8872,0,8868,0) = true := by
  simp only [checkFour, w2049_0, w2049_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2049 : Coverage 2049 2050 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases2049)
private theorem w2050_0 : checkWitness 2050 false false 522 = true := by decide +kernel
private theorem w2050_1 : checkWitness 2050 false true 4618 = true := by decide +kernel
private theorem w2050_2 : checkWitness 2050 true false 522 = true := by decide +kernel
private theorem w2050_3 : checkWitness 2050 true true 4618 = true := by decide +kernel
private theorem cases2050 : checkFour 2050 (522,4618,522,4618) = true := by
  simp only [checkFour, w2050_0, w2050_1, w2050_2, w2050_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2050 : Coverage 2050 2051 := checkList_sound (ws:=[(522,4618,522,4618)]) (by simpa only [checkList, Bool.and_true] using cases2050)
private theorem w2051_0 : checkWitness 2051 false false 8958 = true := by decide +kernel
private theorem w2051_2 : checkWitness 2051 true false 8949 = true := by decide +kernel
private theorem cases2051 : checkFour 2051 (8958,0,8949,0) = true := by
  simp only [checkFour, w2051_0, w2051_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2051 : Coverage 2051 2052 := checkList_sound (ws:=[(8958,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases2051)
private theorem w2052_0 : checkWitness 2052 false false 82 = true := by decide +kernel
private theorem w2052_2 : checkWitness 2052 true false 82 = true := by decide +kernel
private theorem cases2052 : checkFour 2052 (82,0,82,0) = true := by
  simp only [checkFour, w2052_0, w2052_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2052 : Coverage 2052 2053 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2052)
private theorem w2053_0 : checkWitness 2053 false false 540 = true := by decide +kernel
private theorem w2053_1 : checkWitness 2053 false true 4636 = true := by decide +kernel
private theorem w2053_2 : checkWitness 2053 true false 540 = true := by decide +kernel
private theorem w2053_3 : checkWitness 2053 true true 4636 = true := by decide +kernel
private theorem cases2053 : checkFour 2053 (540,4636,540,4636) = true := by
  simp only [checkFour, w2053_0, w2053_1, w2053_2, w2053_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2053 : Coverage 2053 2054 := checkList_sound (ws:=[(540,4636,540,4636)]) (by simpa only [checkList, Bool.and_true] using cases2053)
private theorem w2054_0 : checkWitness 2054 false false 8898 = true := by decide +kernel
private theorem w2054_2 : checkWitness 2054 true false 8894 = true := by decide +kernel
private theorem cases2054 : checkFour 2054 (8898,0,8894,0) = true := by
  simp only [checkFour, w2054_0, w2054_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2054 : Coverage 2054 2055 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases2054)
private theorem w2055_0 : checkWitness 2055 false false 84 = true := by decide +kernel
private theorem w2055_2 : checkWitness 2055 true false 84 = true := by decide +kernel
private theorem cases2055 : checkFour 2055 (84,0,84,0) = true := by
  simp only [checkFour, w2055_0, w2055_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2055 : Coverage 2055 2056 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2055)
private theorem w2056_0 : checkWitness 2056 false false 578 = true := by decide +kernel
private theorem w2056_1 : checkWitness 2056 false true 4674 = true := by decide +kernel
private theorem w2056_2 : checkWitness 2056 true false 578 = true := by decide +kernel
private theorem w2056_3 : checkWitness 2056 true true 4674 = true := by decide +kernel
private theorem cases2056 : checkFour 2056 (578,4674,578,4674) = true := by
  simp only [checkFour, w2056_0, w2056_1, w2056_2, w2056_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2056 : Coverage 2056 2057 := checkList_sound (ws:=[(578,4674,578,4674)]) (by simpa only [checkList, Bool.and_true] using cases2056)
private theorem w2057_0 : checkWitness 2057 false false 8919 = true := by decide +kernel
private theorem w2057_2 : checkWitness 2057 true false 8915 = true := by decide +kernel
private theorem cases2057 : checkFour 2057 (8919,0,8915,0) = true := by
  simp only [checkFour, w2057_0, w2057_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2057 : Coverage 2057 2058 := checkList_sound (ws:=[(8919,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases2057)
private theorem w2058_0 : checkWitness 2058 false false 8954 = true := by decide +kernel
private theorem w2058_2 : checkWitness 2058 true false 8945 = true := by decide +kernel
private theorem cases2058 : checkFour 2058 (8954,0,8945,0) = true := by
  simp only [checkFour, w2058_0, w2058_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2058 : Coverage 2058 2059 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2058)
private theorem w2059_0 : checkWitness 2059 false false 108 = true := by decide +kernel
private theorem w2059_2 : checkWitness 2059 true false 108 = true := by decide +kernel
private theorem cases2059 : checkFour 2059 (108,0,108,0) = true := by
  simp only [checkFour, w2059_0, w2059_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2059 : Coverage 2059 2060 := checkList_sound (ws:=[(108,0,108,0)]) (by simpa only [checkList, Bool.and_true] using cases2059)
private theorem w2060_0 : checkWitness 2060 false false 666 = true := by decide +kernel
private theorem w2060_1 : checkWitness 2060 false true 4758 = true := by decide +kernel
private theorem w2060_2 : checkWitness 2060 true false 657 = true := by decide +kernel
private theorem w2060_3 : checkWitness 2060 true true 4749 = true := by decide +kernel
private theorem cases2060 : checkFour 2060 (666,4758,657,4749) = true := by
  simp only [checkFour, w2060_0, w2060_1, w2060_2, w2060_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2060 : Coverage 2060 2061 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases2060)
private theorem w2061_0 : checkWitness 2061 false false 8915 = true := by decide +kernel
private theorem w2061_2 : checkWitness 2061 true false 8911 = true := by decide +kernel
private theorem cases2061 : checkFour 2061 (8915,0,8911,0) = true := by
  simp only [checkFour, w2061_0, w2061_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2061 : Coverage 2061 2062 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2061)
private theorem w2062_0 : checkWitness 2062 false false 660 = true := by decide +kernel
private theorem w2062_1 : checkWitness 2062 false true 4752 = true := by decide +kernel
private theorem w2062_2 : checkWitness 2062 true false 651 = true := by decide +kernel
private theorem w2062_3 : checkWitness 2062 true true 4743 = true := by decide +kernel
private theorem cases2062 : checkFour 2062 (660,4752,651,4743) = true := by
  simp only [checkFour, w2062_0, w2062_1, w2062_2, w2062_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2062 : Coverage 2062 2063 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases2062)
private theorem w2063_0 : checkWitness 2063 false false 8884 = true := by decide +kernel
private theorem w2063_2 : checkWitness 2063 true false 8880 = true := by decide +kernel
private theorem cases2063 : checkFour 2063 (8884,0,8880,0) = true := by
  simp only [checkFour, w2063_0, w2063_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2063 : Coverage 2063 2064 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases2063)
private theorem w2064_0 : checkWitness 2064 false false 96 = true := by decide +kernel
private theorem w2064_2 : checkWitness 2064 true false 96 = true := by decide +kernel
private theorem cases2064 : checkFour 2064 (96,0,96,0) = true := by
  simp only [checkFour, w2064_0, w2064_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2064 : Coverage 2064 2065 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases2064)
private theorem w2065_0 : checkWitness 2065 false false 88 = true := by decide +kernel
private theorem w2065_2 : checkWitness 2065 true false 88 = true := by decide +kernel
private theorem cases2065 : checkFour 2065 (88,0,88,0) = true := by
  simp only [checkFour, w2065_0, w2065_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2065 : Coverage 2065 2066 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases2065)
private theorem w2066_0 : checkWitness 2066 false false 625 = true := by decide +kernel
private theorem w2066_1 : checkWitness 2066 false true 4709 = true := by decide +kernel
private theorem w2066_2 : checkWitness 2066 true false 625 = true := by decide +kernel
private theorem w2066_3 : checkWitness 2066 true true 4709 = true := by decide +kernel
private theorem cases2066 : checkFour 2066 (625,4709,625,4709) = true := by
  simp only [checkFour, w2066_0, w2066_1, w2066_2, w2066_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2066 : Coverage 2066 2067 := checkList_sound (ws:=[(625,4709,625,4709)]) (by simpa only [checkList, Bool.and_true] using cases2066)
private theorem w2067_0 : checkWitness 2067 false false 8878 = true := by decide +kernel
private theorem w2067_2 : checkWitness 2067 true false 8874 = true := by decide +kernel
private theorem cases2067 : checkFour 2067 (8878,0,8874,0) = true := by
  simp only [checkFour, w2067_0, w2067_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2067 : Coverage 2067 2068 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases2067)
private theorem w2068_0 : checkWitness 2068 false false 88 = true := by decide +kernel
private theorem w2068_2 : checkWitness 2068 true false 88 = true := by decide +kernel
private theorem cases2068 : checkFour 2068 (88,0,88,0) = true := by
  simp only [checkFour, w2068_0, w2068_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2068 : Coverage 2068 2069 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases2068)
private theorem w2069_0 : checkWitness 2069 false false 623 = true := by decide +kernel
private theorem w2069_1 : checkWitness 2069 false true 4715 = true := by decide +kernel
private theorem w2069_2 : checkWitness 2069 true false 614 = true := by decide +kernel
private theorem w2069_3 : checkWitness 2069 true true 4706 = true := by decide +kernel
private theorem cases2069 : checkFour 2069 (623,4715,614,4706) = true := by
  simp only [checkFour, w2069_0, w2069_1, w2069_2, w2069_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2069 : Coverage 2069 2070 := checkList_sound (ws:=[(623,4715,614,4706)]) (by simpa only [checkList, Bool.and_true] using cases2069)
private theorem w2070_0 : checkWitness 2070 false false 8920 = true := by decide +kernel
private theorem w2070_2 : checkWitness 2070 true false 8911 = true := by decide +kernel
private theorem cases2070 : checkFour 2070 (8920,0,8911,0) = true := by
  simp only [checkFour, w2070_0, w2070_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2070 : Coverage 2070 2071 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2070)
private theorem w2071_0 : checkWitness 2071 false false 8866 = true := by decide +kernel
private theorem w2071_2 : checkWitness 2071 true false 8862 = true := by decide +kernel
private theorem cases2071 : checkFour 2071 (8866,0,8862,0) = true := by
  simp only [checkFour, w2071_0, w2071_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2071 : Coverage 2071 2072 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases2071)
private theorem w2072_0 : checkWitness 2072 false false 82 = true := by decide +kernel
private theorem w2072_2 : checkWitness 2072 true false 82 = true := by decide +kernel
private theorem cases2072 : checkFour 2072 (82,0,82,0) = true := by
  simp only [checkFour, w2072_0, w2072_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2072 : Coverage 2072 2073 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2072)
private theorem w2073_0 : checkWitness 2073 false false 650 = true := by decide +kernel
private theorem w2073_1 : checkWitness 2073 false true 4742 = true := by decide +kernel
private theorem w2073_2 : checkWitness 2073 true false 641 = true := by decide +kernel
private theorem w2073_3 : checkWitness 2073 true true 4733 = true := by decide +kernel
private theorem cases2073 : checkFour 2073 (650,4742,641,4733) = true := by
  simp only [checkFour, w2073_0, w2073_1, w2073_2, w2073_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2073 : Coverage 2073 2074 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases2073)
private theorem w2074_0 : checkWitness 2074 false false 8927 = true := by decide +kernel
private theorem w2074_2 : checkWitness 2074 true false 8918 = true := by decide +kernel
private theorem cases2074 : checkFour 2074 (8927,0,8918,0) = true := by
  simp only [checkFour, w2074_0, w2074_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2074 : Coverage 2074 2075 := checkList_sound (ws:=[(8927,0,8918,0)]) (by simpa only [checkList, Bool.and_true] using cases2074)
private theorem w2075_0 : checkWitness 2075 false false 66 = true := by decide +kernel
private theorem w2075_2 : checkWitness 2075 true false 66 = true := by decide +kernel
private theorem cases2075 : checkFour 2075 (66,0,66,0) = true := by
  simp only [checkFour, w2075_0, w2075_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2075 : Coverage 2075 2076 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2075)
private theorem w2076_0 : checkWitness 2076 false false 514 = true := by decide +kernel
private theorem w2076_1 : checkWitness 2076 false true 4610 = true := by decide +kernel
private theorem w2076_2 : checkWitness 2076 true false 514 = true := by decide +kernel
private theorem w2076_3 : checkWitness 2076 true true 4610 = true := by decide +kernel
private theorem cases2076 : checkFour 2076 (514,4610,514,4610) = true := by
  simp only [checkFour, w2076_0, w2076_1, w2076_2, w2076_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2076 : Coverage 2076 2077 := checkList_sound (ws:=[(514,4610,514,4610)]) (by simpa only [checkList, Bool.and_true] using cases2076)
private theorem w2077_0 : checkWitness 2077 false false 8909 = true := by decide +kernel
private theorem w2077_2 : checkWitness 2077 true false 8905 = true := by decide +kernel
private theorem cases2077 : checkFour 2077 (8909,0,8905,0) = true := by
  simp only [checkFour, w2077_0, w2077_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2077 : Coverage 2077 2078 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases2077)
private theorem w2078_0 : checkWitness 2078 false false 640 = true := by decide +kernel
private theorem w2078_1 : checkWitness 2078 false true 4736 = true := by decide +kernel
private theorem w2078_2 : checkWitness 2078 true false 631 = true := by decide +kernel
private theorem w2078_3 : checkWitness 2078 true true 4727 = true := by decide +kernel
private theorem cases2078 : checkFour 2078 (640,4736,631,4727) = true := by
  simp only [checkFour, w2078_0, w2078_1, w2078_2, w2078_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2078 : Coverage 2078 2079 := checkList_sound (ws:=[(640,4736,631,4727)]) (by simpa only [checkList, Bool.and_true] using cases2078)
private theorem w2079_0 : checkWitness 2079 false false 184 = true := by decide +kernel
private theorem w2079_2 : checkWitness 2079 true false 184 = true := by decide +kernel
private theorem cases2079 : checkFour 2079 (184,0,184,0) = true := by
  simp only [checkFour, w2079_0, w2079_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2079 : Coverage 2079 2080 := checkList_sound (ws:=[(184,0,184,0)]) (by simpa only [checkList, Bool.and_true] using cases2079)
theorem cover2048 : Coverage 2048 2080 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2048 one2049) (Coverage.join one2050 one2051)) (Coverage.join (Coverage.join one2052 one2053) (Coverage.join one2054 one2055))) (Coverage.join (Coverage.join (Coverage.join one2056 one2057) (Coverage.join one2058 one2059)) (Coverage.join (Coverage.join one2060 one2061) (Coverage.join one2062 one2063)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2064 one2065) (Coverage.join one2066 one2067)) (Coverage.join (Coverage.join one2068 one2069) (Coverage.join one2070 one2071))) (Coverage.join (Coverage.join (Coverage.join one2072 one2073) (Coverage.join one2074 one2075)) (Coverage.join (Coverage.join one2076 one2077) (Coverage.join one2078 one2079)))))
end NF181PA.Symbolic
