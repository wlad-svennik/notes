import NF181TapeData
import NF181Raw

/-! Finite symbolic words, literal-table execution and frame comparisons.
This module is independent of the PA model semantics. -/
open NF210.TM
namespace NF181PA.Symbolic
abbrev State := Direct181.Table.State
inductive Atom where
  | digit : Bool → Atom
  | many : Bool → Nat → Atom
  | paired : Bool → Nat → Atom
  | tail : Nat → Atom
deriving DecidableEq, Inhabited, Repr

structure Config where
  q : State
  dir : Direction
  scan : List Atom
  back : List Atom

def literalStep (q' : State) (d old : Direction) (w : Bool) (s o : List Atom) : Config :=
  if d=old then ⟨q',d,s,.digit w::o⟩ else ⟨q',d,o,.digit w::s⟩

def manyStep (q q' : State) (d old : Direction) (b w : Bool) (k : Nat) (s o : List Atom) : Option Config :=
  if q=q' ∧ d=old then some ⟨q,old,s,.many w k::o⟩ else
  match s with
  | .digit v :: rest => if b=v then some ⟨q,old,.digit b :: .many b k :: rest,o⟩ else none
  | _ => none

def step (c : Config) : Option Config :=
  match c.scan with
  | .digit b :: s =>
    let a := Direct181.Table.machine c.q b
    a.next.map fun q' => literalStep q' a.move c.dir a.write s c.back
  | .many b k :: s =>
    if c.q=31 ∧ c.dir=.left ∧ b=false then
      match c.back with
      | .digit true :: back => some ⟨31,.left,s,.digit true :: .many false k :: back⟩
      | _ => none
    else
    let a := Direct181.Table.machine c.q b
    a.next.bind fun q' => manyStep c.q q' a.move c.dir b a.write k s c.back
  | .paired b k :: s =>
    if b=false ∧ c.q=120 ∧ c.dir=.right then some ⟨120,.right,s,.paired false k :: c.back⟩
    else if b=false ∧ c.q=142 ∧ c.dir=.left then some ⟨142,.left,s,.paired true k :: c.back⟩
    else match s with
      | .digit z :: rest => if z=b then some ⟨c.q,c.dir,.digit b :: .paired (!b) k :: rest,c.back⟩ else none
      | _ => none
  | _ => none

def after : Nat → Config → Option Config
  | 0,c => some c
  | n+1,c => (step c).bind (after n)

def atGate (c : Config) : Bool := c.q == NF181Data.haltGate && c.scan.head? == some (.digit true)

open Atom
def pushes (d : Bool) (paired : Bool) (k : Nat) : List Atom → List Atom
  | .digit b :: w =>
    if d=b then .digit b :: pushes (if paired then !d else d) paired k w
    else (if paired then .paired d k else .many d k) :: .digit b :: w
  | w => (if paired then .paired d k else .many d k) :: w

def normal : List Atom → List Atom
  | [] => []
  | .digit b :: w =>
    let rest := normal w
    if ¬b ∧ rest=[] then [] else .digit b :: rest
  | .tail i :: _ => [.tail i]
  | .many b k :: w => pushes b false k (normal w)
  | .paired b k :: w => pushes b true k (normal w)

def normalized (c : Config) : Option (State × List Atom × List Atom) :=
  match c.dir with
  | .right => some (c.q,normal c.back,normal c.scan)
  | .left => match c.scan with
             | .digit b :: scan => some (c.q,normal scan,normal (.digit b :: c.back))
             | _ => none

def returns (c t : Config) : Bool :=
  match normalized c, normalized t with
  | some a, some b => a == b
  | _,_ => false

/-- `pos` selects the positive branch of a decrement. `afterStep` selects
the expected output layout. Register variables represent an arbitrary
logical register value, or the predecessor of a positive decrement input. -/
def field (pc : Nat) (cold pos afterStep : Bool) (i : Nat) : List Atom :=
  let op := Direct181Source.Raw.program pc
  let inc := match op with | .inl (r,_) => r=i | _ => false
  let dec := match op with | .inr (.inl (r,_,_,_)) => r=i | _ => false
  let coldSlot := cold && i==0
  let fixed := if coldSlot then (if inc && afterStep then 2 else 1) else
    if inc && afterStep || dec && pos && !afterStep then 3 else 2
  [.digit false] ++ List.replicate fixed (.digit true) ++
    (if coldSlot || dec && !pos then [] else [.many true i])

def nextPc (pc : Nat) (pos : Bool) : Nat :=
  match Direct181Source.Raw.program pc with
  | .inl (_,n) => n
  | .inr (.inl (_,z,n,_)) => if pos then n else z
  | .inr (.inr n) => n

def expectedHalt (pc : Nat) (pos : Bool) : Bool :=
  match Direct181Source.Raw.program pc with
  | .inr (.inl (_,_,_,h)) => h && !pos
  | _ => false

def signedFrame (pc : Nat) (cold pos afterStep : Bool) (dg ds : Nat) : Config :=
  let addr := NF181Data.addressBits (if afterStep then nextPc pc pos else pc)
  let gap := List.replicate (40-addr.length+dg) (.digit false) ++ [.many false 9] ++ List.replicate 10 (.digit false)
  let file := NF181Data.registerOrder.flatMap (field pc cold pos afterStep)
  let spares := (List.replicate (24+ds) [Atom.digit false,.digit true]).flatten ++ [.paired false 10] ++ List.replicate 14 (.digit false)
  ⟨NF181Data.decoderRoot,.right,addr.map digit ++ gap ++ [.digit true] ++ file ++ spares,
    [.digit true] ++ List.replicate 12 (.digit false)⟩

def checkRow (pc : Nat) (cold pos : Bool) (fuel dg ds : Nat) : Bool :=
  match after fuel (signedFrame pc cold pos false 0 0) with
  | none => false
  | some c => if expectedHalt pc pos then atGate c else returns c (signedFrame pc cold pos true dg ds)


#print axioms checkRow
end NF181PA.Symbolic
