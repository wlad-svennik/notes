module
public import Direct181Snapshots
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem chunk17500 : Prefix 181 snap17319 snap17500 := checked _ _ _ (by decide) (by decide)
theorem chunk18000 : Prefix 500 snap17500 snap18000 := checked _ _ _ (by decide) (by decide)
theorem chunk18500 : Prefix 500 snap18000 snap18500 := checked _ _ _ (by decide) (by decide)
theorem chunk19000 : Prefix 500 snap18500 snap19000 := checked _ _ _ (by decide) (by decide)
theorem chunk19500 : Prefix 500 snap19000 snap19500 := checked _ _ _ (by decide) (by decide)
theorem chunk20000 : Prefix 500 snap19500 snap20000 := checked _ _ _ (by decide) (by decide)
theorem chunk20500 : Prefix 500 snap20000 snap20500 := checked _ _ _ (by decide) (by decide)
theorem chunk21000 : Prefix 500 snap20500 snap21000 := checked _ _ _ (by decide) (by decide)
theorem chunk21500 : Prefix 500 snap21000 snap21500 := checked _ _ _ (by decide) (by decide)
theorem chunk22000 : Prefix 500 snap21500 snap22000 := checked _ _ _ (by decide) (by decide)
theorem chunk22500 : Prefix 500 snap22000 snap22500 := checked _ _ _ (by decide) (by decide)
theorem chunk23000 : Prefix 500 snap22500 snap23000 := checked _ _ _ (by decide) (by decide)
end Direct181.Boot
