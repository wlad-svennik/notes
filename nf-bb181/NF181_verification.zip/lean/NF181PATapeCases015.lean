import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w480_0 : checkWitness 480 false false 8942 = true := by decide +kernel
private theorem w480_2 : checkWitness 480 true false 8933 = true := by decide +kernel
private theorem cases480 : checkFour 480 (8942,0,8933,0) = true := by
  simp only [checkFour, w480_0, w480_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one480 : Coverage 480 481 := checkList_sound (ws:=[(8942,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases480)
private theorem w481_0 : checkWitness 481 false false 60 = true := by decide +kernel
private theorem w481_2 : checkWitness 481 true false 60 = true := by decide +kernel
private theorem cases481 : checkFour 481 (60,0,60,0) = true := by
  simp only [checkFour, w481_0, w481_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one481 : Coverage 481 482 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases481)
private theorem w482_0 : checkWitness 482 false false 524 = true := by decide +kernel
private theorem w482_1 : checkWitness 482 false true 4620 = true := by decide +kernel
private theorem w482_2 : checkWitness 482 true false 524 = true := by decide +kernel
private theorem w482_3 : checkWitness 482 true true 4620 = true := by decide +kernel
private theorem cases482 : checkFour 482 (524,4620,524,4620) = true := by
  simp only [checkFour, w482_0, w482_1, w482_2, w482_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one482 : Coverage 482 483 := checkList_sound (ws:=[(524,4620,524,4620)]) (by simpa only [checkList, Bool.and_true] using cases482)
private theorem w483_0 : checkWitness 483 false false 8882 = true := by decide +kernel
private theorem w483_2 : checkWitness 483 true false 8878 = true := by decide +kernel
private theorem cases483 : checkFour 483 (8882,0,8878,0) = true := by
  simp only [checkFour, w483_0, w483_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one483 : Coverage 483 484 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases483)
private theorem w484_0 : checkWitness 484 false false 62 = true := by decide +kernel
private theorem w484_2 : checkWitness 484 true false 62 = true := by decide +kernel
private theorem cases484 : checkFour 484 (62,0,62,0) = true := by
  simp only [checkFour, w484_0, w484_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one484 : Coverage 484 485 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases484)
private theorem w485_0 : checkWitness 485 false false 562 = true := by decide +kernel
private theorem w485_1 : checkWitness 485 false true 4658 = true := by decide +kernel
private theorem w485_2 : checkWitness 485 true false 562 = true := by decide +kernel
private theorem w485_3 : checkWitness 485 true true 4658 = true := by decide +kernel
private theorem cases485 : checkFour 485 (562,4658,562,4658) = true := by
  simp only [checkFour, w485_0, w485_1, w485_2, w485_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one485 : Coverage 485 486 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases485)
private theorem w486_0 : checkWitness 486 false false 8903 = true := by decide +kernel
private theorem w486_2 : checkWitness 486 true false 8899 = true := by decide +kernel
private theorem cases486 : checkFour 486 (8903,0,8899,0) = true := by
  simp only [checkFour, w486_0, w486_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one486 : Coverage 486 487 := checkList_sound (ws:=[(8903,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases486)
private theorem w487_0 : checkWitness 487 false false 8938 = true := by decide +kernel
private theorem w487_2 : checkWitness 487 true false 8929 = true := by decide +kernel
private theorem cases487 : checkFour 487 (8938,0,8929,0) = true := by
  simp only [checkFour, w487_0, w487_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one487 : Coverage 487 488 := checkList_sound (ws:=[(8938,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases487)
private theorem w488_0 : checkWitness 488 false false 86 = true := by decide +kernel
private theorem w488_2 : checkWitness 488 true false 86 = true := by decide +kernel
private theorem cases488 : checkFour 488 (86,0,86,0) = true := by
  simp only [checkFour, w488_0, w488_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one488 : Coverage 488 489 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases488)
private theorem w489_0 : checkWitness 489 false false 650 = true := by decide +kernel
private theorem w489_1 : checkWitness 489 false true 4742 = true := by decide +kernel
private theorem w489_2 : checkWitness 489 true false 641 = true := by decide +kernel
private theorem w489_3 : checkWitness 489 true true 4733 = true := by decide +kernel
private theorem cases489 : checkFour 489 (650,4742,641,4733) = true := by
  simp only [checkFour, w489_0, w489_1, w489_2, w489_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one489 : Coverage 489 490 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases489)
private theorem w490_0 : checkWitness 490 false false 8899 = true := by decide +kernel
private theorem w490_2 : checkWitness 490 true false 8895 = true := by decide +kernel
private theorem cases490 : checkFour 490 (8899,0,8895,0) = true := by
  simp only [checkFour, w490_0, w490_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one490 : Coverage 490 491 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases490)
private theorem w491_0 : checkWitness 491 false false 644 = true := by decide +kernel
private theorem w491_1 : checkWitness 491 false true 4736 = true := by decide +kernel
private theorem w491_2 : checkWitness 491 true false 635 = true := by decide +kernel
private theorem w491_3 : checkWitness 491 true true 4727 = true := by decide +kernel
private theorem cases491 : checkFour 491 (644,4736,635,4727) = true := by
  simp only [checkFour, w491_0, w491_1, w491_2, w491_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one491 : Coverage 491 492 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases491)
private theorem w492_0 : checkWitness 492 false false 8868 = true := by decide +kernel
private theorem w492_2 : checkWitness 492 true false 8864 = true := by decide +kernel
private theorem cases492 : checkFour 492 (8868,0,8864,0) = true := by
  simp only [checkFour, w492_0, w492_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one492 : Coverage 492 493 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases492)
private theorem w493_0 : checkWitness 493 false false 74 = true := by decide +kernel
private theorem w493_2 : checkWitness 493 true false 74 = true := by decide +kernel
private theorem cases493 : checkFour 493 (74,0,74,0) = true := by
  simp only [checkFour, w493_0, w493_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one493 : Coverage 493 494 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases493)
private theorem w494_0 : checkWitness 494 false false 66 = true := by decide +kernel
private theorem w494_2 : checkWitness 494 true false 66 = true := by decide +kernel
private theorem cases494 : checkFour 494 (66,0,66,0) = true := by
  simp only [checkFour, w494_0, w494_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one494 : Coverage 494 495 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases494)
private theorem w495_0 : checkWitness 495 false false 609 = true := by decide +kernel
private theorem w495_1 : checkWitness 495 false true 4693 = true := by decide +kernel
private theorem w495_2 : checkWitness 495 true false 609 = true := by decide +kernel
private theorem w495_3 : checkWitness 495 true true 4693 = true := by decide +kernel
private theorem cases495 : checkFour 495 (609,4693,609,4693) = true := by
  simp only [checkFour, w495_0, w495_1, w495_2, w495_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one495 : Coverage 495 496 := checkList_sound (ws:=[(609,4693,609,4693)]) (by simpa only [checkList, Bool.and_true] using cases495)
private theorem w496_0 : checkWitness 496 false false 8862 = true := by decide +kernel
private theorem w496_2 : checkWitness 496 true false 8858 = true := by decide +kernel
private theorem cases496 : checkFour 496 (8862,0,8858,0) = true := by
  simp only [checkFour, w496_0, w496_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one496 : Coverage 496 497 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases496)
private theorem w497_0 : checkWitness 497 false false 66 = true := by decide +kernel
private theorem w497_2 : checkWitness 497 true false 66 = true := by decide +kernel
private theorem cases497 : checkFour 497 (66,0,66,0) = true := by
  simp only [checkFour, w497_0, w497_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one497 : Coverage 497 498 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases497)
private theorem w498_0 : checkWitness 498 false false 577 = true := by decide +kernel
private theorem w498_1 : checkWitness 498 false true 4673 = true := by decide +kernel
private theorem w498_2 : checkWitness 498 true false 577 = true := by decide +kernel
private theorem w498_3 : checkWitness 498 true true 4673 = true := by decide +kernel
private theorem cases498 : checkFour 498 (577,4673,577,4673) = true := by
  simp only [checkFour, w498_0, w498_1, w498_2, w498_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one498 : Coverage 498 499 := checkList_sound (ws:=[(577,4673,577,4673)]) (by simpa only [checkList, Bool.and_true] using cases498)
private theorem w499_0 : checkWitness 499 false false 8930 = true := by decide +kernel
private theorem w499_2 : checkWitness 499 true false 8921 = true := by decide +kernel
private theorem cases499 : checkFour 499 (8930,0,8921,0) = true := by
  simp only [checkFour, w499_0, w499_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one499 : Coverage 499 500 := checkList_sound (ws:=[(8930,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases499)
private theorem w500_0 : checkWitness 500 false false 8876 = true := by decide +kernel
private theorem w500_2 : checkWitness 500 true false 8872 = true := by decide +kernel
private theorem cases500 : checkFour 500 (8876,0,8872,0) = true := by
  simp only [checkFour, w500_0, w500_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one500 : Coverage 500 501 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases500)
private theorem w501_0 : checkWitness 501 false false 74 = true := by decide +kernel
private theorem w501_2 : checkWitness 501 true false 74 = true := by decide +kernel
private theorem cases501 : checkFour 501 (74,0,74,0) = true := by
  simp only [checkFour, w501_0, w501_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one501 : Coverage 501 502 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases501)
private theorem w502_0 : checkWitness 502 false false 660 = true := by decide +kernel
private theorem w502_1 : checkWitness 502 false true 4748 = true := by decide +kernel
private theorem w502_2 : checkWitness 502 true false 651 = true := by decide +kernel
private theorem w502_3 : checkWitness 502 true true 4739 = true := by decide +kernel
private theorem cases502 : checkFour 502 (660,4748,651,4739) = true := by
  simp only [checkFour, w502_0, w502_1, w502_2, w502_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one502 : Coverage 502 503 := checkList_sound (ws:=[(660,4748,651,4739)]) (by simpa only [checkList, Bool.and_true] using cases502)
private theorem w503_0 : checkWitness 503 false false 8895 = true := by decide +kernel
private theorem w503_2 : checkWitness 503 true false 8891 = true := by decide +kernel
private theorem cases503 : checkFour 503 (8895,0,8891,0) = true := by
  simp only [checkFour, w503_0, w503_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one503 : Coverage 503 504 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases503)
private theorem w504_0 : checkWitness 504 false false 64 = true := by decide +kernel
private theorem w504_2 : checkWitness 504 true false 64 = true := by decide +kernel
private theorem cases504 : checkFour 504 (64,0,64,0) = true := by
  simp only [checkFour, w504_0, w504_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one504 : Coverage 504 505 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases504)
private theorem w505_0 : checkWitness 505 false false 512 = true := by decide +kernel
private theorem w505_1 : checkWitness 505 false true 4608 = true := by decide +kernel
private theorem w505_2 : checkWitness 505 true false 512 = true := by decide +kernel
private theorem w505_3 : checkWitness 505 true true 4608 = true := by decide +kernel
private theorem cases505 : checkFour 505 (512,4608,512,4608) = true := by
  simp only [checkFour, w505_0, w505_1, w505_2, w505_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one505 : Coverage 505 506 := checkList_sound (ws:=[(512,4608,512,4608)]) (by simpa only [checkList, Bool.and_true] using cases505)
private theorem w506_0 : checkWitness 506 false false 8907 = true := by decide +kernel
private theorem w506_2 : checkWitness 506 true false 8903 = true := by decide +kernel
private theorem cases506 : checkFour 506 (8907,0,8903,0) = true := by
  simp only [checkFour, w506_0, w506_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one506 : Coverage 506 507 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases506)
private theorem w507_0 : checkWitness 507 false false 638 = true := by decide +kernel
private theorem w507_1 : checkWitness 507 false true 4734 = true := by decide +kernel
private theorem w507_2 : checkWitness 507 true false 629 = true := by decide +kernel
private theorem w507_3 : checkWitness 507 true true 4725 = true := by decide +kernel
private theorem cases507 : checkFour 507 (638,4734,629,4725) = true := by
  simp only [checkFour, w507_0, w507_1, w507_2, w507_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one507 : Coverage 507 508 := checkList_sound (ws:=[(638,4734,629,4725)]) (by simpa only [checkList, Bool.and_true] using cases507)
private theorem w508_0 : checkWitness 508 false false 186 = true := by decide +kernel
private theorem w508_2 : checkWitness 508 true false 186 = true := by decide +kernel
private theorem cases508 : checkFour 508 (186,0,186,0) = true := by
  simp only [checkFour, w508_0, w508_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one508 : Coverage 508 509 := checkList_sound (ws:=[(186,0,186,0)]) (by simpa only [checkList, Bool.and_true] using cases508)
private theorem w509_0 : checkWitness 509 false false 593 = true := by decide +kernel
private theorem w509_1 : checkWitness 509 false true 4681 = true := by decide +kernel
private theorem w509_2 : checkWitness 509 true false 593 = true := by decide +kernel
private theorem w509_3 : checkWitness 509 true true 4681 = true := by decide +kernel
private theorem cases509 : checkFour 509 (593,4681,593,4681) = true := by
  simp only [checkFour, w509_0, w509_1, w509_2, w509_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one509 : Coverage 509 510 := checkList_sound (ws:=[(593,4681,593,4681)]) (by simpa only [checkList, Bool.and_true] using cases509)
private theorem w510_0 : checkWitness 510 false false 8922 = true := by decide +kernel
private theorem w510_2 : checkWitness 510 true false 8913 = true := by decide +kernel
private theorem cases510 : checkFour 510 (8922,0,8913,0) = true := by
  simp only [checkFour, w510_0, w510_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one510 : Coverage 510 511 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases510)
private theorem w511_0 : checkWitness 511 false false 70 = true := by decide +kernel
private theorem w511_2 : checkWitness 511 true false 70 = true := by decide +kernel
private theorem cases511 : checkFour 511 (70,0,70,0) = true := by
  simp only [checkFour, w511_0, w511_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one511 : Coverage 511 512 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases511)
theorem cover0480 : Coverage 480 512 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one480 one481) (Coverage.join one482 one483)) (Coverage.join (Coverage.join one484 one485) (Coverage.join one486 one487))) (Coverage.join (Coverage.join (Coverage.join one488 one489) (Coverage.join one490 one491)) (Coverage.join (Coverage.join one492 one493) (Coverage.join one494 one495)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one496 one497) (Coverage.join one498 one499)) (Coverage.join (Coverage.join one500 one501) (Coverage.join one502 one503))) (Coverage.join (Coverage.join (Coverage.join one504 one505) (Coverage.join one506 one507)) (Coverage.join (Coverage.join one508 one509) (Coverage.join one510 one511)))))
end NF181PA.Symbolic
