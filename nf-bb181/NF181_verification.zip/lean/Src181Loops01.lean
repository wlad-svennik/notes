module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site0225Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 225 f r x y z) (slots210.atReg 228 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 225 3 228 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 225 228 226 f r (row_of_literal 225 _ (by decide) RawRows.raw0225))
    (slots210.pos_x 225 228 226 f r (row_of_literal 225 _ (by decide) RawRows.raw0225))
    (slots210.inc_y 226 227 f r (row_of_literal 226 _ (by decide) RawRows.raw0226) (Or.inl (by decide)))
    (slots210.jump 227 225 f r (row_of_literal 227 _ (by decide) RawRows.raw0227))

theorem site0225 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((225:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((228:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0225Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0228Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 228 f r x y z) (slots617.atReg 238 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 228 10 238 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 228 232 229 f r (row_of_literal 228 _ (by decide) RawRows.raw0228))
    (slots617.pos_y 228 232 229 f r (row_of_literal 228 _ (by decide) RawRows.raw0228))
    (slots617.inc_z 229 230 f r (row_of_literal 229 _ (by decide) RawRows.raw0229) (Or.inl (by decide)))
    (slots617.inc_x 230 231 f r (row_of_literal 230 _ (by decide) RawRows.raw0230) (Or.inl (by decide)))
    (slots617.jump 231 228 f r (row_of_literal 231 _ (by decide) RawRows.raw0231))
    (slots617.zero_x 232 238 233 f r (row_of_literal 232 _ (by decide) RawRows.raw0232))
    (slots617.pos_x 232 238 233 f r (row_of_literal 232 _ (by decide) RawRows.raw0232))
    (slots617.inc_z 233 234 f r (row_of_literal 233 _ (by decide) RawRows.raw0233) (Or.inl (by decide)))
    (slots617.zero_x 234 237 235 f r (row_of_literal 234 _ (by decide) RawRows.raw0234))
    (slots617.pos_x 234 237 235 f r (row_of_literal 234 _ (by decide) RawRows.raw0234))
    (slots617.inc_y 235 236 f r (row_of_literal 235 _ (by decide) RawRows.raw0235) (Or.inl (by decide)))
    (slots617.jump 236 234 f r (row_of_literal 236 _ (by decide) RawRows.raw0236))
    (slots617.jump 237 228 f r (row_of_literal 237 _ (by decide) RawRows.raw0237))

theorem site0228 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((228:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((238:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0228Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0238Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 238 f r x y z) (slots720.atReg 241 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 238 3 241 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 238 241 239 f r (row_of_literal 238 _ (by decide) RawRows.raw0238))
    (slots720.pos_x 238 241 239 f r (row_of_literal 238 _ (by decide) RawRows.raw0238))
    (slots720.inc_y 239 240 f r (row_of_literal 239 _ (by decide) RawRows.raw0239) (Or.inl (by decide)))
    (slots720.jump 240 238 f r (row_of_literal 240 _ (by decide) RawRows.raw0240))

theorem site0238 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((238:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((241:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0238Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0241Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 241 f r x y z) (slots361.atReg 245 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 241 4 245 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 241 245 242 f r (row_of_literal 241 _ (by decide) RawRows.raw0241))
    (slots361.pos_x 241 245 242 f r (row_of_literal 241 _ (by decide) RawRows.raw0241))
    (slots361.inc_y 242 243 f r (row_of_literal 242 _ (by decide) RawRows.raw0242) (Or.inl (by decide)))
    (slots361.inc_z 243 244 f r (row_of_literal 243 _ (by decide) RawRows.raw0243) (Or.inl (by decide)))
    (slots361.jump 244 241 f r (row_of_literal 244 _ (by decide) RawRows.raw0244))

theorem site0241 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((241:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((245:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0241Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site0245Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 245 f r x y z) (slots630.atReg 248 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 245 3 248 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 245 248 246 f r (row_of_literal 245 _ (by decide) RawRows.raw0245))
    (slots630.pos_x 245 248 246 f r (row_of_literal 245 _ (by decide) RawRows.raw0245))
    (slots630.inc_y 246 247 f r (row_of_literal 246 _ (by decide) RawRows.raw0246) (Or.inl (by decide)))
    (slots630.jump 247 245 f r (row_of_literal 247 _ (by decide) RawRows.raw0247))

theorem site0245 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((245:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((248:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0245Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site0248Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 248 f r x y z) (slots267.atReg 256 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 248 8 256 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 248 256 249 f r (row_of_literal 248 _ (by decide) RawRows.raw0248))
    (slots267.pos_x 248 256 249 f r (row_of_literal 248 _ (by decide) RawRows.raw0248))
    (slots267.inc_z 249 250 f r (row_of_literal 249 _ (by decide) RawRows.raw0249) (Or.inl (by decide)))
    (slots267.zero_y 250 252 251 f r (row_of_literal 250 _ (by decide) RawRows.raw0250))
    (slots267.pos_y 250 252 251 f r (row_of_literal 250 _ (by decide) RawRows.raw0250))
    (slots267.jump 251 255 f r (row_of_literal 251 _ (by decide) RawRows.raw0251))
    (slots267.zero_z 252 255 253 f r (row_of_literal 252 _ (by decide) RawRows.raw0252))
    (slots267.pos_z 252 255 253 f r (row_of_literal 252 _ (by decide) RawRows.raw0252))
    (slots267.inc_y 253 254 f r (row_of_literal 253 _ (by decide) RawRows.raw0253) (Or.inl (by decide)))
    (slots267.jump 254 252 f r (row_of_literal 254 _ (by decide) RawRows.raw0254))
    (slots267.jump 255 248 f r (row_of_literal 255 _ (by decide) RawRows.raw0255))

theorem site0248 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((248:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((256:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0248Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0256Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 256 f r x y z) (slots720.atReg 259 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 256 3 259 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 256 259 257 f r (row_of_literal 256 _ (by decide) RawRows.raw0256))
    (slots720.pos_x 256 259 257 f r (row_of_literal 256 _ (by decide) RawRows.raw0256))
    (slots720.inc_y 257 258 f r (row_of_literal 257 _ (by decide) RawRows.raw0257) (Or.inl (by decide)))
    (slots720.jump 258 256 f r (row_of_literal 258 _ (by decide) RawRows.raw0258))

theorem site0256 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((256:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((259:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0256Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0259Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 259 f r x y z) (slots617.atReg 269 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 259 10 269 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 259 263 260 f r (row_of_literal 259 _ (by decide) RawRows.raw0259))
    (slots617.pos_y 259 263 260 f r (row_of_literal 259 _ (by decide) RawRows.raw0259))
    (slots617.inc_z 260 261 f r (row_of_literal 260 _ (by decide) RawRows.raw0260) (Or.inl (by decide)))
    (slots617.inc_x 261 262 f r (row_of_literal 261 _ (by decide) RawRows.raw0261) (Or.inl (by decide)))
    (slots617.jump 262 259 f r (row_of_literal 262 _ (by decide) RawRows.raw0262))
    (slots617.zero_x 263 269 264 f r (row_of_literal 263 _ (by decide) RawRows.raw0263))
    (slots617.pos_x 263 269 264 f r (row_of_literal 263 _ (by decide) RawRows.raw0263))
    (slots617.inc_z 264 265 f r (row_of_literal 264 _ (by decide) RawRows.raw0264) (Or.inl (by decide)))
    (slots617.zero_x 265 268 266 f r (row_of_literal 265 _ (by decide) RawRows.raw0265))
    (slots617.pos_x 265 268 266 f r (row_of_literal 265 _ (by decide) RawRows.raw0265))
    (slots617.inc_y 266 267 f r (row_of_literal 266 _ (by decide) RawRows.raw0266) (Or.inl (by decide)))
    (slots617.jump 267 265 f r (row_of_literal 267 _ (by decide) RawRows.raw0267))
    (slots617.jump 268 259 f r (row_of_literal 268 _ (by decide) RawRows.raw0268))

theorem site0259 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((259:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((269:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0259Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0269Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 269 f r x y z) (slots710.atReg 273 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 269 4 273 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 269 273 270 f r (row_of_literal 269 _ (by decide) RawRows.raw0269))
    (slots710.pos_x 269 273 270 f r (row_of_literal 269 _ (by decide) RawRows.raw0269))
    (slots710.inc_y 270 271 f r (row_of_literal 270 _ (by decide) RawRows.raw0270) (Or.inl (by decide)))
    (slots710.inc_y 271 272 f r (row_of_literal 271 _ (by decide) RawRows.raw0271) (Or.inl (by decide)))
    (slots710.jump 272 269 f r (row_of_literal 272 _ (by decide) RawRows.raw0272))

theorem site0269 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((269:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((273:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0269Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site0273Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 273 f r x y z) (slots160.atReg 276 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 273 3 276 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 273 276 274 f r (row_of_literal 273 _ (by decide) RawRows.raw0273))
    (slots160.pos_x 273 276 274 f r (row_of_literal 273 _ (by decide) RawRows.raw0273))
    (slots160.inc_y 274 275 f r (row_of_literal 274 _ (by decide) RawRows.raw0274) (Or.inl (by decide)))
    (slots160.jump 275 273 f r (row_of_literal 275 _ (by decide) RawRows.raw0275))

theorem site0273 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((273:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((276:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0273Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0276Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 276 f r x y z) (slots210.atReg 279 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 276 3 279 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 276 279 277 f r (row_of_literal 276 _ (by decide) RawRows.raw0276))
    (slots210.pos_x 276 279 277 f r (row_of_literal 276 _ (by decide) RawRows.raw0276))
    (slots210.inc_y 277 278 f r (row_of_literal 277 _ (by decide) RawRows.raw0277) (Or.inl (by decide)))
    (slots210.jump 278 276 f r (row_of_literal 278 _ (by decide) RawRows.raw0278))

theorem site0276 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((276:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((279:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0276Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0279Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 279 f r x y z) (slots617.atReg 289 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 279 10 289 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 279 283 280 f r (row_of_literal 279 _ (by decide) RawRows.raw0279))
    (slots617.pos_y 279 283 280 f r (row_of_literal 279 _ (by decide) RawRows.raw0279))
    (slots617.inc_z 280 281 f r (row_of_literal 280 _ (by decide) RawRows.raw0280) (Or.inl (by decide)))
    (slots617.inc_x 281 282 f r (row_of_literal 281 _ (by decide) RawRows.raw0281) (Or.inl (by decide)))
    (slots617.jump 282 279 f r (row_of_literal 282 _ (by decide) RawRows.raw0282))
    (slots617.zero_x 283 289 284 f r (row_of_literal 283 _ (by decide) RawRows.raw0283))
    (slots617.pos_x 283 289 284 f r (row_of_literal 283 _ (by decide) RawRows.raw0283))
    (slots617.inc_z 284 285 f r (row_of_literal 284 _ (by decide) RawRows.raw0284) (Or.inl (by decide)))
    (slots617.zero_x 285 288 286 f r (row_of_literal 285 _ (by decide) RawRows.raw0285))
    (slots617.pos_x 285 288 286 f r (row_of_literal 285 _ (by decide) RawRows.raw0285))
    (slots617.inc_y 286 287 f r (row_of_literal 286 _ (by decide) RawRows.raw0286) (Or.inl (by decide)))
    (slots617.jump 287 285 f r (row_of_literal 287 _ (by decide) RawRows.raw0287))
    (slots617.jump 288 279 f r (row_of_literal 288 _ (by decide) RawRows.raw0288))

theorem site0279 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((279:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((289:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0279Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0289Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 289 f r x y z) (slots720.atReg 292 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 289 3 292 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 289 292 290 f r (row_of_literal 289 _ (by decide) RawRows.raw0289))
    (slots720.pos_x 289 292 290 f r (row_of_literal 289 _ (by decide) RawRows.raw0289))
    (slots720.inc_y 290 291 f r (row_of_literal 290 _ (by decide) RawRows.raw0290) (Or.inl (by decide)))
    (slots720.jump 291 289 f r (row_of_literal 291 _ (by decide) RawRows.raw0291))

theorem site0289 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((289:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((292:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0289Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0292Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 292 f r x y z) (slots561.atReg 296 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 292 4 296 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 292 296 293 f r (row_of_literal 292 _ (by decide) RawRows.raw0292))
    (slots561.pos_x 292 296 293 f r (row_of_literal 292 _ (by decide) RawRows.raw0292))
    (slots561.inc_y 293 294 f r (row_of_literal 293 _ (by decide) RawRows.raw0293) (Or.inl (by decide)))
    (slots561.inc_z 294 295 f r (row_of_literal 294 _ (by decide) RawRows.raw0294) (Or.inl (by decide)))
    (slots561.jump 295 292 f r (row_of_literal 295 _ (by decide) RawRows.raw0295))

theorem site0292 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((292:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((296:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0292Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site0296Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 296 f r x y z) (slots650.atReg 299 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 296 3 299 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 296 299 297 f r (row_of_literal 296 _ (by decide) RawRows.raw0296))
    (slots650.pos_x 296 299 297 f r (row_of_literal 296 _ (by decide) RawRows.raw0296))
    (slots650.inc_y 297 298 f r (row_of_literal 297 _ (by decide) RawRows.raw0297) (Or.inl (by decide)))
    (slots650.jump 298 296 f r (row_of_literal 298 _ (by decide) RawRows.raw0298))

theorem site0296 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((296:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((299:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0296Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site0299Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 299 f r x y z) (slots160.atReg 302 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 299 3 302 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 299 302 300 f r (row_of_literal 299 _ (by decide) RawRows.raw0299))
    (slots160.pos_x 299 302 300 f r (row_of_literal 299 _ (by decide) RawRows.raw0299))
    (slots160.inc_y 300 301 f r (row_of_literal 300 _ (by decide) RawRows.raw0300) (Or.inl (by decide)))
    (slots160.jump 301 299 f r (row_of_literal 301 _ (by decide) RawRows.raw0301))

theorem site0299 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((299:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((302:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0299Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0302Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 302 f r x y z) (slots210.atReg 305 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 302 3 305 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 302 305 303 f r (row_of_literal 302 _ (by decide) RawRows.raw0302))
    (slots210.pos_x 302 305 303 f r (row_of_literal 302 _ (by decide) RawRows.raw0302))
    (slots210.inc_y 303 304 f r (row_of_literal 303 _ (by decide) RawRows.raw0303) (Or.inl (by decide)))
    (slots210.jump 304 302 f r (row_of_literal 304 _ (by decide) RawRows.raw0304))

theorem site0302 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((302:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((305:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0302Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0305Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 305 f r x y z) (slots617.atReg 315 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 305 10 315 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 305 309 306 f r (row_of_literal 305 _ (by decide) RawRows.raw0305))
    (slots617.pos_y 305 309 306 f r (row_of_literal 305 _ (by decide) RawRows.raw0305))
    (slots617.inc_z 306 307 f r (row_of_literal 306 _ (by decide) RawRows.raw0306) (Or.inl (by decide)))
    (slots617.inc_x 307 308 f r (row_of_literal 307 _ (by decide) RawRows.raw0307) (Or.inl (by decide)))
    (slots617.jump 308 305 f r (row_of_literal 308 _ (by decide) RawRows.raw0308))
    (slots617.zero_x 309 315 310 f r (row_of_literal 309 _ (by decide) RawRows.raw0309))
    (slots617.pos_x 309 315 310 f r (row_of_literal 309 _ (by decide) RawRows.raw0309))
    (slots617.inc_z 310 311 f r (row_of_literal 310 _ (by decide) RawRows.raw0310) (Or.inl (by decide)))
    (slots617.zero_x 311 314 312 f r (row_of_literal 311 _ (by decide) RawRows.raw0311))
    (slots617.pos_x 311 314 312 f r (row_of_literal 311 _ (by decide) RawRows.raw0311))
    (slots617.inc_y 312 313 f r (row_of_literal 312 _ (by decide) RawRows.raw0312) (Or.inl (by decide)))
    (slots617.jump 313 311 f r (row_of_literal 313 _ (by decide) RawRows.raw0313))
    (slots617.jump 314 305 f r (row_of_literal 314 _ (by decide) RawRows.raw0314))

theorem site0305 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((305:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((315:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0305Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0315Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 315 f r x y z) (slots720.atReg 318 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 315 3 318 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 315 318 316 f r (row_of_literal 315 _ (by decide) RawRows.raw0315))
    (slots720.pos_x 315 318 316 f r (row_of_literal 315 _ (by decide) RawRows.raw0315))
    (slots720.inc_y 316 317 f r (row_of_literal 316 _ (by decide) RawRows.raw0316) (Or.inl (by decide)))
    (slots720.jump 317 315 f r (row_of_literal 317 _ (by decide) RawRows.raw0317))

theorem site0315 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((315:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((318:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0315Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0318Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 318 f r x y z) (slots361.atReg 322 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 318 4 322 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 318 322 319 f r (row_of_literal 318 _ (by decide) RawRows.raw0318))
    (slots361.pos_x 318 322 319 f r (row_of_literal 318 _ (by decide) RawRows.raw0318))
    (slots361.inc_y 319 320 f r (row_of_literal 319 _ (by decide) RawRows.raw0319) (Or.inl (by decide)))
    (slots361.inc_z 320 321 f r (row_of_literal 320 _ (by decide) RawRows.raw0320) (Or.inl (by decide)))
    (slots361.jump 321 318 f r (row_of_literal 321 _ (by decide) RawRows.raw0321))

theorem site0318 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((318:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((322:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0318Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site0322Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 322 f r x y z) (slots630.atReg 325 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 322 3 325 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 322 325 323 f r (row_of_literal 322 _ (by decide) RawRows.raw0322))
    (slots630.pos_x 322 325 323 f r (row_of_literal 322 _ (by decide) RawRows.raw0322))
    (slots630.inc_y 323 324 f r (row_of_literal 323 _ (by decide) RawRows.raw0323) (Or.inl (by decide)))
    (slots630.jump 324 322 f r (row_of_literal 324 _ (by decide) RawRows.raw0324))

theorem site0322 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((322:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((325:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0322Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site0325Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 325 f r x y z) (slots267.atReg 333 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 325 8 333 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 325 333 326 f r (row_of_literal 325 _ (by decide) RawRows.raw0325))
    (slots267.pos_x 325 333 326 f r (row_of_literal 325 _ (by decide) RawRows.raw0325))
    (slots267.inc_z 326 327 f r (row_of_literal 326 _ (by decide) RawRows.raw0326) (Or.inl (by decide)))
    (slots267.zero_y 327 329 328 f r (row_of_literal 327 _ (by decide) RawRows.raw0327))
    (slots267.pos_y 327 329 328 f r (row_of_literal 327 _ (by decide) RawRows.raw0327))
    (slots267.jump 328 332 f r (row_of_literal 328 _ (by decide) RawRows.raw0328))
    (slots267.zero_z 329 332 330 f r (row_of_literal 329 _ (by decide) RawRows.raw0329))
    (slots267.pos_z 329 332 330 f r (row_of_literal 329 _ (by decide) RawRows.raw0329))
    (slots267.inc_y 330 331 f r (row_of_literal 330 _ (by decide) RawRows.raw0330) (Or.inl (by decide)))
    (slots267.jump 331 329 f r (row_of_literal 331 _ (by decide) RawRows.raw0331))
    (slots267.jump 332 325 f r (row_of_literal 332 _ (by decide) RawRows.raw0332))

theorem site0325 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((325:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((333:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0325Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0333Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 333 f r x y z) (slots720.atReg 336 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 333 3 336 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 333 336 334 f r (row_of_literal 333 _ (by decide) RawRows.raw0333))
    (slots720.pos_x 333 336 334 f r (row_of_literal 333 _ (by decide) RawRows.raw0333))
    (slots720.inc_y 334 335 f r (row_of_literal 334 _ (by decide) RawRows.raw0334) (Or.inl (by decide)))
    (slots720.jump 335 333 f r (row_of_literal 335 _ (by decide) RawRows.raw0335))

theorem site0333 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((333:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((336:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0333Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0336Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 336 f r x y z) (slots617.atReg 346 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 336 10 346 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 336 340 337 f r (row_of_literal 336 _ (by decide) RawRows.raw0336))
    (slots617.pos_y 336 340 337 f r (row_of_literal 336 _ (by decide) RawRows.raw0336))
    (slots617.inc_z 337 338 f r (row_of_literal 337 _ (by decide) RawRows.raw0337) (Or.inl (by decide)))
    (slots617.inc_x 338 339 f r (row_of_literal 338 _ (by decide) RawRows.raw0338) (Or.inl (by decide)))
    (slots617.jump 339 336 f r (row_of_literal 339 _ (by decide) RawRows.raw0339))
    (slots617.zero_x 340 346 341 f r (row_of_literal 340 _ (by decide) RawRows.raw0340))
    (slots617.pos_x 340 346 341 f r (row_of_literal 340 _ (by decide) RawRows.raw0340))
    (slots617.inc_z 341 342 f r (row_of_literal 341 _ (by decide) RawRows.raw0341) (Or.inl (by decide)))
    (slots617.zero_x 342 345 343 f r (row_of_literal 342 _ (by decide) RawRows.raw0342))
    (slots617.pos_x 342 345 343 f r (row_of_literal 342 _ (by decide) RawRows.raw0342))
    (slots617.inc_y 343 344 f r (row_of_literal 343 _ (by decide) RawRows.raw0343) (Or.inl (by decide)))
    (slots617.jump 344 342 f r (row_of_literal 344 _ (by decide) RawRows.raw0344))
    (slots617.jump 345 336 f r (row_of_literal 345 _ (by decide) RawRows.raw0345))

theorem site0336 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((336:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((346:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0336Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0346Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 346 f r x y z) (slots710.atReg 350 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 346 4 350 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 346 350 347 f r (row_of_literal 346 _ (by decide) RawRows.raw0346))
    (slots710.pos_x 346 350 347 f r (row_of_literal 346 _ (by decide) RawRows.raw0346))
    (slots710.inc_y 347 348 f r (row_of_literal 347 _ (by decide) RawRows.raw0347) (Or.inl (by decide)))
    (slots710.inc_y 348 349 f r (row_of_literal 348 _ (by decide) RawRows.raw0348) (Or.inl (by decide)))
    (slots710.jump 349 346 f r (row_of_literal 349 _ (by decide) RawRows.raw0349))

theorem site0346 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((346:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((350:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0346Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site0350Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 350 f r x y z) (slots267.atReg 358 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 350 8 358 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 350 358 351 f r (row_of_literal 350 _ (by decide) RawRows.raw0350))
    (slots267.pos_x 350 358 351 f r (row_of_literal 350 _ (by decide) RawRows.raw0350))
    (slots267.inc_z 351 352 f r (row_of_literal 351 _ (by decide) RawRows.raw0351) (Or.inl (by decide)))
    (slots267.zero_y 352 354 353 f r (row_of_literal 352 _ (by decide) RawRows.raw0352))
    (slots267.pos_y 352 354 353 f r (row_of_literal 352 _ (by decide) RawRows.raw0352))
    (slots267.jump 353 357 f r (row_of_literal 353 _ (by decide) RawRows.raw0353))
    (slots267.zero_z 354 357 355 f r (row_of_literal 354 _ (by decide) RawRows.raw0354))
    (slots267.pos_z 354 357 355 f r (row_of_literal 354 _ (by decide) RawRows.raw0354))
    (slots267.inc_y 355 356 f r (row_of_literal 355 _ (by decide) RawRows.raw0355) (Or.inl (by decide)))
    (slots267.jump 356 354 f r (row_of_literal 356 _ (by decide) RawRows.raw0356))
    (slots267.jump 357 350 f r (row_of_literal 357 _ (by decide) RawRows.raw0357))

theorem site0350 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((350:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((358:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0350Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0358Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 358 f r x y z) (slots720.atReg 361 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 358 3 361 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 358 361 359 f r (row_of_literal 358 _ (by decide) RawRows.raw0358))
    (slots720.pos_x 358 361 359 f r (row_of_literal 358 _ (by decide) RawRows.raw0358))
    (slots720.inc_y 359 360 f r (row_of_literal 359 _ (by decide) RawRows.raw0359) (Or.inl (by decide)))
    (slots720.jump 360 358 f r (row_of_literal 360 _ (by decide) RawRows.raw0360))

theorem site0358 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((358:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((361:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0358Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0361Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 361 f r x y z) (slots617.atReg 371 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 361 10 371 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 361 365 362 f r (row_of_literal 361 _ (by decide) RawRows.raw0361))
    (slots617.pos_y 361 365 362 f r (row_of_literal 361 _ (by decide) RawRows.raw0361))
    (slots617.inc_z 362 363 f r (row_of_literal 362 _ (by decide) RawRows.raw0362) (Or.inl (by decide)))
    (slots617.inc_x 363 364 f r (row_of_literal 363 _ (by decide) RawRows.raw0363) (Or.inl (by decide)))
    (slots617.jump 364 361 f r (row_of_literal 364 _ (by decide) RawRows.raw0364))
    (slots617.zero_x 365 371 366 f r (row_of_literal 365 _ (by decide) RawRows.raw0365))
    (slots617.pos_x 365 371 366 f r (row_of_literal 365 _ (by decide) RawRows.raw0365))
    (slots617.inc_z 366 367 f r (row_of_literal 366 _ (by decide) RawRows.raw0366) (Or.inl (by decide)))
    (slots617.zero_x 367 370 368 f r (row_of_literal 367 _ (by decide) RawRows.raw0367))
    (slots617.pos_x 367 370 368 f r (row_of_literal 367 _ (by decide) RawRows.raw0367))
    (slots617.inc_y 368 369 f r (row_of_literal 368 _ (by decide) RawRows.raw0368) (Or.inl (by decide)))
    (slots617.jump 369 367 f r (row_of_literal 369 _ (by decide) RawRows.raw0369))
    (slots617.jump 370 361 f r (row_of_literal 370 _ (by decide) RawRows.raw0370))

theorem site0361 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((361:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((371:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0361Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0371Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 371 f r x y z) (slots710.atReg 375 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 371 4 375 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 371 375 372 f r (row_of_literal 371 _ (by decide) RawRows.raw0371))
    (slots710.pos_x 371 375 372 f r (row_of_literal 371 _ (by decide) RawRows.raw0371))
    (slots710.inc_y 372 373 f r (row_of_literal 372 _ (by decide) RawRows.raw0372) (Or.inl (by decide)))
    (slots710.inc_y 373 374 f r (row_of_literal 373 _ (by decide) RawRows.raw0373) (Or.inl (by decide)))
    (slots710.jump 374 371 f r (row_of_literal 374 _ (by decide) RawRows.raw0374))

theorem site0371 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((371:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((375:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0371Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site0375Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 375 f r x y z) (slots267.atReg 383 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 375 8 383 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 375 383 376 f r (row_of_literal 375 _ (by decide) RawRows.raw0375))
    (slots267.pos_x 375 383 376 f r (row_of_literal 375 _ (by decide) RawRows.raw0375))
    (slots267.inc_z 376 377 f r (row_of_literal 376 _ (by decide) RawRows.raw0376) (Or.inl (by decide)))
    (slots267.zero_y 377 379 378 f r (row_of_literal 377 _ (by decide) RawRows.raw0377))
    (slots267.pos_y 377 379 378 f r (row_of_literal 377 _ (by decide) RawRows.raw0377))
    (slots267.jump 378 382 f r (row_of_literal 378 _ (by decide) RawRows.raw0378))
    (slots267.zero_z 379 382 380 f r (row_of_literal 379 _ (by decide) RawRows.raw0379))
    (slots267.pos_z 379 382 380 f r (row_of_literal 379 _ (by decide) RawRows.raw0379))
    (slots267.inc_y 380 381 f r (row_of_literal 380 _ (by decide) RawRows.raw0380) (Or.inl (by decide)))
    (slots267.jump 381 379 f r (row_of_literal 381 _ (by decide) RawRows.raw0381))
    (slots267.jump 382 375 f r (row_of_literal 382 _ (by decide) RawRows.raw0382))

theorem site0375 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((375:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((383:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0375Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0383Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 383 f r x y z) (slots720.atReg 386 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 383 3 386 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 383 386 384 f r (row_of_literal 383 _ (by decide) RawRows.raw0383))
    (slots720.pos_x 383 386 384 f r (row_of_literal 383 _ (by decide) RawRows.raw0383))
    (slots720.inc_y 384 385 f r (row_of_literal 384 _ (by decide) RawRows.raw0384) (Or.inl (by decide)))
    (slots720.jump 385 383 f r (row_of_literal 385 _ (by decide) RawRows.raw0385))

theorem site0383 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((383:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((386:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0383Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0386Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 386 f r x y z) (slots617.atReg 396 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 386 10 396 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 386 390 387 f r (row_of_literal 386 _ (by decide) RawRows.raw0386))
    (slots617.pos_y 386 390 387 f r (row_of_literal 386 _ (by decide) RawRows.raw0386))
    (slots617.inc_z 387 388 f r (row_of_literal 387 _ (by decide) RawRows.raw0387) (Or.inl (by decide)))
    (slots617.inc_x 388 389 f r (row_of_literal 388 _ (by decide) RawRows.raw0388) (Or.inl (by decide)))
    (slots617.jump 389 386 f r (row_of_literal 389 _ (by decide) RawRows.raw0389))
    (slots617.zero_x 390 396 391 f r (row_of_literal 390 _ (by decide) RawRows.raw0390))
    (slots617.pos_x 390 396 391 f r (row_of_literal 390 _ (by decide) RawRows.raw0390))
    (slots617.inc_z 391 392 f r (row_of_literal 391 _ (by decide) RawRows.raw0391) (Or.inl (by decide)))
    (slots617.zero_x 392 395 393 f r (row_of_literal 392 _ (by decide) RawRows.raw0392))
    (slots617.pos_x 392 395 393 f r (row_of_literal 392 _ (by decide) RawRows.raw0392))
    (slots617.inc_y 393 394 f r (row_of_literal 393 _ (by decide) RawRows.raw0393) (Or.inl (by decide)))
    (slots617.jump 394 392 f r (row_of_literal 394 _ (by decide) RawRows.raw0394))
    (slots617.jump 395 386 f r (row_of_literal 395 _ (by decide) RawRows.raw0395))

theorem site0386 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((386:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((396:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0386Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0396Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 396 f r x y z) (slots710.atReg 400 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 396 4 400 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 396 400 397 f r (row_of_literal 396 _ (by decide) RawRows.raw0396))
    (slots710.pos_x 396 400 397 f r (row_of_literal 396 _ (by decide) RawRows.raw0396))
    (slots710.inc_y 397 398 f r (row_of_literal 397 _ (by decide) RawRows.raw0397) (Or.inl (by decide)))
    (slots710.inc_y 398 399 f r (row_of_literal 398 _ (by decide) RawRows.raw0398) (Or.inl (by decide)))
    (slots710.jump 399 396 f r (row_of_literal 399 _ (by decide) RawRows.raw0399))

theorem site0396 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((396:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((400:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0396Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site0400Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 400 f r x y z) (slots160.atReg 403 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 400 3 403 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 400 403 401 f r (row_of_literal 400 _ (by decide) RawRows.raw0400))
    (slots160.pos_x 400 403 401 f r (row_of_literal 400 _ (by decide) RawRows.raw0400))
    (slots160.inc_y 401 402 f r (row_of_literal 401 _ (by decide) RawRows.raw0401) (Or.inl (by decide)))
    (slots160.jump 402 400 f r (row_of_literal 402 _ (by decide) RawRows.raw0402))

theorem site0400 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((400:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((403:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0400Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0403Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 403 f r x y z) (slots210.atReg 406 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 403 3 406 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 403 406 404 f r (row_of_literal 403 _ (by decide) RawRows.raw0403))
    (slots210.pos_x 403 406 404 f r (row_of_literal 403 _ (by decide) RawRows.raw0403))
    (slots210.inc_y 404 405 f r (row_of_literal 404 _ (by decide) RawRows.raw0404) (Or.inl (by decide)))
    (slots210.jump 405 403 f r (row_of_literal 405 _ (by decide) RawRows.raw0405))

theorem site0403 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((403:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((406:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0403Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0406Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 406 f r x y z) (slots617.atReg 416 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 406 10 416 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 406 410 407 f r (row_of_literal 406 _ (by decide) RawRows.raw0406))
    (slots617.pos_y 406 410 407 f r (row_of_literal 406 _ (by decide) RawRows.raw0406))
    (slots617.inc_z 407 408 f r (row_of_literal 407 _ (by decide) RawRows.raw0407) (Or.inl (by decide)))
    (slots617.inc_x 408 409 f r (row_of_literal 408 _ (by decide) RawRows.raw0408) (Or.inl (by decide)))
    (slots617.jump 409 406 f r (row_of_literal 409 _ (by decide) RawRows.raw0409))
    (slots617.zero_x 410 416 411 f r (row_of_literal 410 _ (by decide) RawRows.raw0410))
    (slots617.pos_x 410 416 411 f r (row_of_literal 410 _ (by decide) RawRows.raw0410))
    (slots617.inc_z 411 412 f r (row_of_literal 411 _ (by decide) RawRows.raw0411) (Or.inl (by decide)))
    (slots617.zero_x 412 415 413 f r (row_of_literal 412 _ (by decide) RawRows.raw0412))
    (slots617.pos_x 412 415 413 f r (row_of_literal 412 _ (by decide) RawRows.raw0412))
    (slots617.inc_y 413 414 f r (row_of_literal 413 _ (by decide) RawRows.raw0413) (Or.inl (by decide)))
    (slots617.jump 414 412 f r (row_of_literal 414 _ (by decide) RawRows.raw0414))
    (slots617.jump 415 406 f r (row_of_literal 415 _ (by decide) RawRows.raw0415))

theorem site0406 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((406:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((416:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0406Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0416Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 416 f r x y z) (slots720.atReg 419 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 416 3 419 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 416 419 417 f r (row_of_literal 416 _ (by decide) RawRows.raw0416))
    (slots720.pos_x 416 419 417 f r (row_of_literal 416 _ (by decide) RawRows.raw0416))
    (slots720.inc_y 417 418 f r (row_of_literal 417 _ (by decide) RawRows.raw0417) (Or.inl (by decide)))
    (slots720.jump 418 416 f r (row_of_literal 418 _ (by decide) RawRows.raw0418))

theorem site0416 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((416:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((419:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0416Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0419Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 419 f r x y z) (slots561.atReg 423 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 419 4 423 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 419 423 420 f r (row_of_literal 419 _ (by decide) RawRows.raw0419))
    (slots561.pos_x 419 423 420 f r (row_of_literal 419 _ (by decide) RawRows.raw0419))
    (slots561.inc_y 420 421 f r (row_of_literal 420 _ (by decide) RawRows.raw0420) (Or.inl (by decide)))
    (slots561.inc_z 421 422 f r (row_of_literal 421 _ (by decide) RawRows.raw0421) (Or.inl (by decide)))
    (slots561.jump 422 419 f r (row_of_literal 422 _ (by decide) RawRows.raw0422))

theorem site0419 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((419:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((423:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0419Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site0423Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 423 f r x y z) (slots650.atReg 426 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 423 3 426 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 423 426 424 f r (row_of_literal 423 _ (by decide) RawRows.raw0423))
    (slots650.pos_x 423 426 424 f r (row_of_literal 423 _ (by decide) RawRows.raw0423))
    (slots650.inc_y 424 425 f r (row_of_literal 424 _ (by decide) RawRows.raw0424) (Or.inl (by decide)))
    (slots650.jump 425 423 f r (row_of_literal 425 _ (by decide) RawRows.raw0425))

theorem site0423 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((423:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((426:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0423Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site0426Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 426 f r x y z) (slots160.atReg 429 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 426 3 429 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 426 429 427 f r (row_of_literal 426 _ (by decide) RawRows.raw0426))
    (slots160.pos_x 426 429 427 f r (row_of_literal 426 _ (by decide) RawRows.raw0426))
    (slots160.inc_y 427 428 f r (row_of_literal 427 _ (by decide) RawRows.raw0427) (Or.inl (by decide)))
    (slots160.jump 428 426 f r (row_of_literal 428 _ (by decide) RawRows.raw0428))

theorem site0426 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((426:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((429:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0426Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0429Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 429 f r x y z) (slots210.atReg 432 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 429 3 432 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 429 432 430 f r (row_of_literal 429 _ (by decide) RawRows.raw0429))
    (slots210.pos_x 429 432 430 f r (row_of_literal 429 _ (by decide) RawRows.raw0429))
    (slots210.inc_y 430 431 f r (row_of_literal 430 _ (by decide) RawRows.raw0430) (Or.inl (by decide)))
    (slots210.jump 431 429 f r (row_of_literal 431 _ (by decide) RawRows.raw0431))

theorem site0429 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((429:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((432:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0429Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0432Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 432 f r x y z) (slots617.atReg 442 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 432 10 442 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 432 436 433 f r (row_of_literal 432 _ (by decide) RawRows.raw0432))
    (slots617.pos_y 432 436 433 f r (row_of_literal 432 _ (by decide) RawRows.raw0432))
    (slots617.inc_z 433 434 f r (row_of_literal 433 _ (by decide) RawRows.raw0433) (Or.inl (by decide)))
    (slots617.inc_x 434 435 f r (row_of_literal 434 _ (by decide) RawRows.raw0434) (Or.inl (by decide)))
    (slots617.jump 435 432 f r (row_of_literal 435 _ (by decide) RawRows.raw0435))
    (slots617.zero_x 436 442 437 f r (row_of_literal 436 _ (by decide) RawRows.raw0436))
    (slots617.pos_x 436 442 437 f r (row_of_literal 436 _ (by decide) RawRows.raw0436))
    (slots617.inc_z 437 438 f r (row_of_literal 437 _ (by decide) RawRows.raw0437) (Or.inl (by decide)))
    (slots617.zero_x 438 441 439 f r (row_of_literal 438 _ (by decide) RawRows.raw0438))
    (slots617.pos_x 438 441 439 f r (row_of_literal 438 _ (by decide) RawRows.raw0438))
    (slots617.inc_y 439 440 f r (row_of_literal 439 _ (by decide) RawRows.raw0439) (Or.inl (by decide)))
    (slots617.jump 440 438 f r (row_of_literal 440 _ (by decide) RawRows.raw0440))
    (slots617.jump 441 432 f r (row_of_literal 441 _ (by decide) RawRows.raw0441))

theorem site0432 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((432:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((442:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0432Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0442Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 442 f r x y z) (slots720.atReg 445 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 442 3 445 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 442 445 443 f r (row_of_literal 442 _ (by decide) RawRows.raw0442))
    (slots720.pos_x 442 445 443 f r (row_of_literal 442 _ (by decide) RawRows.raw0442))
    (slots720.inc_y 443 444 f r (row_of_literal 443 _ (by decide) RawRows.raw0443) (Or.inl (by decide)))
    (slots720.jump 444 442 f r (row_of_literal 444 _ (by decide) RawRows.raw0444))

theorem site0442 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((442:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((445:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0442Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0445Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 445 f r x y z) (slots561.atReg 449 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 445 4 449 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 445 449 446 f r (row_of_literal 445 _ (by decide) RawRows.raw0445))
    (slots561.pos_x 445 449 446 f r (row_of_literal 445 _ (by decide) RawRows.raw0445))
    (slots561.inc_y 446 447 f r (row_of_literal 446 _ (by decide) RawRows.raw0446) (Or.inl (by decide)))
    (slots561.inc_z 447 448 f r (row_of_literal 447 _ (by decide) RawRows.raw0447) (Or.inl (by decide)))
    (slots561.jump 448 445 f r (row_of_literal 448 _ (by decide) RawRows.raw0448))

theorem site0445 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((445:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((449:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0445Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site0449Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 449 f r x y z) (slots650.atReg 452 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 449 3 452 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 449 452 450 f r (row_of_literal 449 _ (by decide) RawRows.raw0449))
    (slots650.pos_x 449 452 450 f r (row_of_literal 449 _ (by decide) RawRows.raw0449))
    (slots650.inc_y 450 451 f r (row_of_literal 450 _ (by decide) RawRows.raw0450) (Or.inl (by decide)))
    (slots650.jump 451 449 f r (row_of_literal 451 _ (by decide) RawRows.raw0451))

theorem site0449 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((449:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((452:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0449Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site0452Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 452 f r x y z) (slots267.atReg 460 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 452 8 460 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 452 460 453 f r (row_of_literal 452 _ (by decide) RawRows.raw0452))
    (slots267.pos_x 452 460 453 f r (row_of_literal 452 _ (by decide) RawRows.raw0452))
    (slots267.inc_z 453 454 f r (row_of_literal 453 _ (by decide) RawRows.raw0453) (Or.inl (by decide)))
    (slots267.zero_y 454 456 455 f r (row_of_literal 454 _ (by decide) RawRows.raw0454))
    (slots267.pos_y 454 456 455 f r (row_of_literal 454 _ (by decide) RawRows.raw0454))
    (slots267.jump 455 459 f r (row_of_literal 455 _ (by decide) RawRows.raw0455))
    (slots267.zero_z 456 459 457 f r (row_of_literal 456 _ (by decide) RawRows.raw0456))
    (slots267.pos_z 456 459 457 f r (row_of_literal 456 _ (by decide) RawRows.raw0456))
    (slots267.inc_y 457 458 f r (row_of_literal 457 _ (by decide) RawRows.raw0457) (Or.inl (by decide)))
    (slots267.jump 458 456 f r (row_of_literal 458 _ (by decide) RawRows.raw0458))
    (slots267.jump 459 452 f r (row_of_literal 459 _ (by decide) RawRows.raw0459))

theorem site0452 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((452:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((460:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0452Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0460Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 460 f r x y z) (slots720.atReg 463 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 460 3 463 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 460 463 461 f r (row_of_literal 460 _ (by decide) RawRows.raw0460))
    (slots720.pos_x 460 463 461 f r (row_of_literal 460 _ (by decide) RawRows.raw0460))
    (slots720.inc_y 461 462 f r (row_of_literal 461 _ (by decide) RawRows.raw0461) (Or.inl (by decide)))
    (slots720.jump 462 460 f r (row_of_literal 462 _ (by decide) RawRows.raw0462))

theorem site0460 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((460:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((463:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0460Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0463Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 463 f r x y z) (slots617.atReg 473 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 463 10 473 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 463 467 464 f r (row_of_literal 463 _ (by decide) RawRows.raw0463))
    (slots617.pos_y 463 467 464 f r (row_of_literal 463 _ (by decide) RawRows.raw0463))
    (slots617.inc_z 464 465 f r (row_of_literal 464 _ (by decide) RawRows.raw0464) (Or.inl (by decide)))
    (slots617.inc_x 465 466 f r (row_of_literal 465 _ (by decide) RawRows.raw0465) (Or.inl (by decide)))
    (slots617.jump 466 463 f r (row_of_literal 466 _ (by decide) RawRows.raw0466))
    (slots617.zero_x 467 473 468 f r (row_of_literal 467 _ (by decide) RawRows.raw0467))
    (slots617.pos_x 467 473 468 f r (row_of_literal 467 _ (by decide) RawRows.raw0467))
    (slots617.inc_z 468 469 f r (row_of_literal 468 _ (by decide) RawRows.raw0468) (Or.inl (by decide)))
    (slots617.zero_x 469 472 470 f r (row_of_literal 469 _ (by decide) RawRows.raw0469))
    (slots617.pos_x 469 472 470 f r (row_of_literal 469 _ (by decide) RawRows.raw0469))
    (slots617.inc_y 470 471 f r (row_of_literal 470 _ (by decide) RawRows.raw0470) (Or.inl (by decide)))
    (slots617.jump 471 469 f r (row_of_literal 471 _ (by decide) RawRows.raw0471))
    (slots617.jump 472 463 f r (row_of_literal 472 _ (by decide) RawRows.raw0472))

theorem site0463 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((463:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((473:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0463Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0473Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 473 f r x y z) (slots710.atReg 477 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 473 4 477 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 473 477 474 f r (row_of_literal 473 _ (by decide) RawRows.raw0473))
    (slots710.pos_x 473 477 474 f r (row_of_literal 473 _ (by decide) RawRows.raw0473))
    (slots710.inc_y 474 475 f r (row_of_literal 474 _ (by decide) RawRows.raw0474) (Or.inl (by decide)))
    (slots710.inc_y 475 476 f r (row_of_literal 475 _ (by decide) RawRows.raw0475) (Or.inl (by decide)))
    (slots710.jump 476 473 f r (row_of_literal 476 _ (by decide) RawRows.raw0476))

theorem site0473 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((473:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((477:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0473Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site0477 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((477:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((478:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 477 _ (row_of_literal 477 _ (by decide) RawRows.raw0477)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site0478 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((478:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((479:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 478 _ (row_of_literal 478 _ (by decide) RawRows.raw0478)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site0479Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 479 f r x y z) (slots160.atReg 482 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 479 3 482 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 479 482 480 f r (row_of_literal 479 _ (by decide) RawRows.raw0479))
    (slots160.pos_x 479 482 480 f r (row_of_literal 479 _ (by decide) RawRows.raw0479))
    (slots160.inc_y 480 481 f r (row_of_literal 480 _ (by decide) RawRows.raw0480) (Or.inl (by decide)))
    (slots160.jump 481 479 f r (row_of_literal 481 _ (by decide) RawRows.raw0481))

theorem site0479 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((479:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((482:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0479Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0482Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 482 f r x y z) (slots210.atReg 485 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 482 3 485 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 482 485 483 f r (row_of_literal 482 _ (by decide) RawRows.raw0482))
    (slots210.pos_x 482 485 483 f r (row_of_literal 482 _ (by decide) RawRows.raw0482))
    (slots210.inc_y 483 484 f r (row_of_literal 483 _ (by decide) RawRows.raw0483) (Or.inl (by decide)))
    (slots210.jump 484 482 f r (row_of_literal 484 _ (by decide) RawRows.raw0484))

theorem site0482 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((482:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((485:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0482Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


end PA192.ModelSearch.Register181.Certified
