module
public import Src181Atoms
public import Src181Loops00
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandRefillAfter1 (n t s c u v y d w : V) : Reach (config ((2:Nat):V) 0 (vector n t s c u v 0 0 0)) (config ((3:Nat):V) 0 (vector (1+n) t s c u v 0 0 0)) := by
  have micro := site0002 n t s c u v 0 0 0
  have d0 : (n+1:V)=1+n := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ d0 rfl rfl rfl rfl rfl rfl rfl rfl)
  exact mid

theorem commandRefillAfter2 (n t s c u v y d w : V) : Reach (config ((2:Nat):V) 0 (vector n t s c u v 0 0 0)) (config ((7:Nat):V) 0 (vector 0 t s c u v (1+n) (1+n) 0)) := by
  have micro := site0003 (1+n) t s c u v 0 0 0
  have d6 : (0+(1+n):V)=1+n := by ring
  have d8 : (0+(1+n):V)=1+n := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d8 rfl)
  exact (commandRefillAfter1 n t s c u v y d w).trans mid

theorem commandRefill (n t s c u v y d w : V) : Reach (config ((2:Nat):V) 0 (vector n t s c u v 0 0 0)) (config ((10:Nat):V) 0 (vector (1+n) t s c u v 0 (1+n) 0)) := by
  have micro := site0007 0 t s c u v (1+n) (1+n) 0
  have d0 : (0+(1+n):V)=1+n := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ d0 rfl rfl rfl rfl rfl rfl rfl rfl)
  exact (commandRefillAfter2 n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
