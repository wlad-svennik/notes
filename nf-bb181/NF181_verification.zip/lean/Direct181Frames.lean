module
public import Direct181Prefix
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table

def cells (left : Int) (word : List Bool) (pos : Int) : Bool :=
  if pos < left then false else word[(pos-left).toNat]?.getD false

theorem packed_cells {left : Int} {bits : Nat} {word : List Bool}
    (lo : anchor ≤ left) (hi : left + (word.length : Int) ≤ anchor + (width : Int))
    (matching : ∀ i : Fin width, bits.testBit i = cells left word (anchor + (i.val : Int))) :
    KernelBits.tape width anchor (fun _ => false) bits = cells left word := by
  funext p
  by_cases h : 0 ≤ p-anchor ∧ p-anchor < (width : Int)
  · let i : Fin width := ⟨(p-anchor).toNat, by omega⟩
    have ix : p = anchor + (i.val : Int) := by dsimp [i]; omega
    rw [ix, KernelBits.tape_read width i.val bits i.isLt]
    exact matching i
  · simp only [KernelBits.tape, ite_eq_right h]
    by_cases before : p < left
    · simp [cells, before]
    · have past : word.length ≤ (p-left).toNat := by omega
      simp [cells, before, List.getElem?_eq_none past]

theorem start_snapshot : KernelBits.embed width anchor (fun _ => false) snap0 = TM.blank start := by
  change TM.Configuration.mk _ _ _ = TM.Configuration.mk _ _ _
  congr 1
  funext p
  simp [KernelBits.tape,snap0]

/-- The address is the prefix-code word for the specified source instruction.
    Logical register r occupies a block of r+2 ones. Each spare occupies one one. -/
structure Layout where
  head : Int
  address : List Bool
  gap : Nat
  registers : List Int
  spares : Nat

def Layout.word (f : Layout) : List Bool :=
  let registers := [2,8,1,4,3,7,0,5,6].flatMap (fun i =>
    false :: List.replicate ((f.registers[i]?.getD 0 + 2).toNat) true)
  (true :: f.address) ++ List.replicate (f.gap-f.address.length) false ++
    (true :: registers ++ (List.replicate f.spares [false,true]).flatten)

def decoderRoot : State := 12
def Layout.config (f : Layout) : TM.Configuration 181 :=
  ⟨some decoderRoot,f.head,cells (f.head-1) f.word⟩

theorem snapshot_layout (s : KernelBits.Configuration 181) (f : Layout)
    (hs : s.state = some decoderRoot) (hh : anchor + (s.head : Int) = f.head)
    (lo : anchor ≤ f.head-1) (hi : f.head-1 + (f.word.length : Int) ≤ anchor+(width:Int))
    (bits : ∀ i : Fin width, s.bits.testBit i = cells (f.head-1) f.word (anchor+(i.val:Int))) :
    KernelBits.embed width anchor (fun _ => false) s = f.config := by
  have eqt := packed_cells lo hi bits
  change TM.Configuration.mk _ _ _ = TM.Configuration.mk _ _ _
  rw [hs,hh,eqt]


/-- Source instruction 38 at the exact end of a literal blank-tape prefix. -/
def firstSigned : Layout := ⟨-1,[true,false,false],30,[-1, 0, 0, 4, 0, 0, 0, 0, 0],12⟩
theorem blank_first_signed_frame : TM.run machine 16439 (TM.blank start) = firstSigned.config := by
  rw [← start_snapshot,prefix16439]
  apply snapshot_layout <;> decide +kernel
#print axioms blank_first_signed_frame

/-- Source instruction 40 with the rank and operand data of the established signed origin. -/
def signedOrigin : Layout := ⟨-1,[true,false,true,false,true,false,false,false,false,false],32,[-1,0,0,2,0,0,0,0,0],12⟩
theorem blank_signed_origin : TM.run machine 17319 (TM.blank start) = signedOrigin.config := by
  rw [← start_snapshot,prefix17319]
  apply snapshot_layout <;> decide +kernel
#print axioms blank_signed_origin

/-- Source instruction 111 at the exact end of a literal blank-tape prefix. -/
def marginBoundary : Layout := ⟨-1,[true,false,true,false,true,false,false,true,false,true,false,true,false,true,false,false,true,false,true,true,true,false],51,[-1, 0, 0, 2, 0, 0, 0, 1, 0],32⟩
theorem blank_margin_frame : TM.run machine 51111 (TM.blank start) = marginBoundary.config := by
  rw [← start_snapshot,prefix51111]
  apply snapshot_layout <;> decide +kernel
#print axioms blank_margin_frame
theorem blank_safe_gap : TM.run machine 51111 (TM.blank start) =
    KernelBits.embed width anchor (fun _ => false) snap51111 := by
  rw [← start_snapshot,prefix51111]
end Direct181.Boot
