module
public import NF181PARawPrefix
public import NF181PAStepTransport
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch.RegisterFields PA192.ModelSearch.Register181
namespace NF181PA.Boot
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
theorem prefix80 : iterate Registers.next (80:V) (config 40 1 (vector 0 0 0 2 0 0 0 0 0)) = Registers.margin V := by
  have h := rawPrefix80 (V:=V)
  rw [run_eq] at h
  simpa only [Registers.margin,Nat.cast_ofNat] using h
end NF181PA.Boot
#print axioms NF181PA.Boot.prefix80
