import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1632_0 : checkWitness 1632 false false 8832 = true := by decide +kernel
private theorem w1632_2 : checkWitness 1632 true false 8828 = true := by decide +kernel
private theorem cases1632 : checkFour 1632 (8832,0,8828,0) = true := by
  simp only [checkFour, w1632_0, w1632_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1632 : Coverage 1632 1633 := checkList_sound (ws:=[(8832,0,8828,0)]) (by simpa only [checkList, Bool.and_true] using cases1632)
private theorem w1633_0 : checkWitness 1633 false false 86 = true := by decide +kernel
private theorem w1633_2 : checkWitness 1633 true false 86 = true := by decide +kernel
private theorem cases1633 : checkFour 1633 (86,0,86,0) = true := by
  simp only [checkFour, w1633_0, w1633_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1633 : Coverage 1633 1634 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1633)
private theorem w1634_0 : checkWitness 1634 false false 584 = true := by decide +kernel
private theorem w1634_1 : checkWitness 1634 false true 4680 = true := by decide +kernel
private theorem w1634_2 : checkWitness 1634 true false 584 = true := by decide +kernel
private theorem w1634_3 : checkWitness 1634 true true 4680 = true := by decide +kernel
private theorem cases1634 : checkFour 1634 (584,4680,584,4680) = true := by
  simp only [checkFour, w1634_0, w1634_1, w1634_2, w1634_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1634 : Coverage 1634 1635 := checkList_sound (ws:=[(584,4680,584,4680)]) (by simpa only [checkList, Bool.and_true] using cases1634)
private theorem w1635_0 : checkWitness 1635 false false 8900 = true := by decide +kernel
private theorem w1635_2 : checkWitness 1635 true false 8891 = true := by decide +kernel
private theorem cases1635 : checkFour 1635 (8900,0,8891,0) = true := by
  simp only [checkFour, w1635_0, w1635_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1635 : Coverage 1635 1636 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1635)
private theorem w1636_0 : checkWitness 1636 false false 8846 = true := by decide +kernel
private theorem w1636_2 : checkWitness 1636 true false 8842 = true := by decide +kernel
private theorem cases1636 : checkFour 1636 (8846,0,8842,0) = true := by
  simp only [checkFour, w1636_0, w1636_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1636 : Coverage 1636 1637 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1636)
private theorem w1637_0 : checkWitness 1637 false false 94 = true := by decide +kernel
private theorem w1637_2 : checkWitness 1637 true false 94 = true := by decide +kernel
private theorem cases1637 : checkFour 1637 (94,0,94,0) = true := by
  simp only [checkFour, w1637_0, w1637_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1637 : Coverage 1637 1638 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1637)
private theorem w1638_0 : checkWitness 1638 false false 630 = true := by decide +kernel
private theorem w1638_1 : checkWitness 1638 false true 4718 = true := by decide +kernel
private theorem w1638_2 : checkWitness 1638 true false 621 = true := by decide +kernel
private theorem w1638_3 : checkWitness 1638 true true 4709 = true := by decide +kernel
private theorem cases1638 : checkFour 1638 (630,4718,621,4709) = true := by
  simp only [checkFour, w1638_0, w1638_1, w1638_2, w1638_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1638 : Coverage 1638 1639 := checkList_sound (ws:=[(630,4718,621,4709)]) (by simpa only [checkList, Bool.and_true] using cases1638)
private theorem w1639_0 : checkWitness 1639 false false 8888 = true := by decide +kernel
private theorem w1639_2 : checkWitness 1639 true false 8884 = true := by decide +kernel
private theorem cases1639 : checkFour 1639 (8888,0,8884,0) = true := by
  simp only [checkFour, w1639_0, w1639_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1639 : Coverage 1639 1640 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases1639)
private theorem w1640_0 : checkWitness 1640 false false 84 = true := by decide +kernel
private theorem w1640_2 : checkWitness 1640 true false 84 = true := by decide +kernel
private theorem cases1640 : checkFour 1640 (84,0,84,0) = true := by
  simp only [checkFour, w1640_0, w1640_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1640 : Coverage 1640 1641 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1640)
private theorem w1641_0 : checkWitness 1641 false false 476 = true := by decide +kernel
private theorem w1641_1 : checkWitness 1641 false true 4572 = true := by decide +kernel
private theorem w1641_2 : checkWitness 1641 true false 476 = true := by decide +kernel
private theorem w1641_3 : checkWitness 1641 true true 4572 = true := by decide +kernel
private theorem cases1641 : checkFour 1641 (476,4572,476,4572) = true := by
  simp only [checkFour, w1641_0, w1641_1, w1641_2, w1641_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1641 : Coverage 1641 1642 := checkList_sound (ws:=[(476,4572,476,4572)]) (by simpa only [checkList, Bool.and_true] using cases1641)
private theorem w1642_0 : checkWitness 1642 false false 8871 = true := by decide +kernel
private theorem w1642_2 : checkWitness 1642 true false 8867 = true := by decide +kernel
private theorem cases1642 : checkFour 1642 (8871,0,8867,0) = true := by
  simp only [checkFour, w1642_0, w1642_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1642 : Coverage 1642 1643 := checkList_sound (ws:=[(8871,0,8867,0)]) (by simpa only [checkList, Bool.and_true] using cases1642)
private theorem w1643_0 : checkWitness 1643 false false 602 = true := by decide +kernel
private theorem w1643_1 : checkWitness 1643 false true 4698 = true := by decide +kernel
private theorem w1643_2 : checkWitness 1643 true false 593 = true := by decide +kernel
private theorem w1643_3 : checkWitness 1643 true true 4689 = true := by decide +kernel
private theorem cases1643 : checkFour 1643 (602,4698,593,4689) = true := by
  simp only [checkFour, w1643_0, w1643_1, w1643_2, w1643_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1643 : Coverage 1643 1644 := checkList_sound (ws:=[(602,4698,593,4689)]) (by simpa only [checkList, Bool.and_true] using cases1643)
private theorem w1644_0 : checkWitness 1644 false false 168 = true := by decide +kernel
private theorem w1644_2 : checkWitness 1644 true false 168 = true := by decide +kernel
private theorem cases1644 : checkFour 1644 (168,0,168,0) = true := by
  simp only [checkFour, w1644_0, w1644_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1644 : Coverage 1644 1645 := checkList_sound (ws:=[(168,0,168,0)]) (by simpa only [checkList, Bool.and_true] using cases1644)
private theorem w1645_0 : checkWitness 1645 false false 557 = true := by decide +kernel
private theorem w1645_1 : checkWitness 1645 false true 4645 = true := by decide +kernel
private theorem w1645_2 : checkWitness 1645 true false 557 = true := by decide +kernel
private theorem w1645_3 : checkWitness 1645 true true 4645 = true := by decide +kernel
private theorem cases1645 : checkFour 1645 (557,4645,557,4645) = true := by
  simp only [checkFour, w1645_0, w1645_1, w1645_2, w1645_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1645 : Coverage 1645 1646 := checkList_sound (ws:=[(557,4645,557,4645)]) (by simpa only [checkList, Bool.and_true] using cases1645)
private theorem w1646_0 : checkWitness 1646 false false 8886 = true := by decide +kernel
private theorem w1646_2 : checkWitness 1646 true false 8877 = true := by decide +kernel
private theorem cases1646 : checkFour 1646 (8886,0,8877,0) = true := by
  simp only [checkFour, w1646_0, w1646_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1646 : Coverage 1646 1647 := checkList_sound (ws:=[(8886,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases1646)
private theorem w1647_0 : checkWitness 1647 false false 88 = true := by decide +kernel
private theorem w1647_2 : checkWitness 1647 true false 88 = true := by decide +kernel
private theorem cases1647 : checkFour 1647 (88,0,88,0) = true := by
  simp only [checkFour, w1647_0, w1647_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1647 : Coverage 1647 1648 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1647)
private theorem w1648_0 : checkWitness 1648 false false 80 = true := by decide +kernel
private theorem w1648_2 : checkWitness 1648 true false 80 = true := by decide +kernel
private theorem cases1648 : checkFour 1648 (80,0,80,0) = true := by
  simp only [checkFour, w1648_0, w1648_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1648 : Coverage 1648 1649 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1648)
private theorem w1649_0 : checkWitness 1649 false false 563 = true := by decide +kernel
private theorem w1649_1 : checkWitness 1649 false true 4655 = true := by decide +kernel
private theorem w1649_2 : checkWitness 1649 true false 563 = true := by decide +kernel
private theorem w1649_3 : checkWitness 1649 true true 4655 = true := by decide +kernel
private theorem cases1649 : checkFour 1649 (563,4655,563,4655) = true := by
  simp only [checkFour, w1649_0, w1649_1, w1649_2, w1649_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1649 : Coverage 1649 1650 := checkList_sound (ws:=[(563,4655,563,4655)]) (by simpa only [checkList, Bool.and_true] using cases1649)
private theorem w1650_0 : checkWitness 1650 false false 8824 = true := by decide +kernel
private theorem w1650_2 : checkWitness 1650 true false 8820 = true := by decide +kernel
private theorem cases1650 : checkFour 1650 (8824,0,8820,0) = true := by
  simp only [checkFour, w1650_0, w1650_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1650 : Coverage 1650 1651 := checkList_sound (ws:=[(8824,0,8820,0)]) (by simpa only [checkList, Bool.and_true] using cases1650)
private theorem w1651_0 : checkWitness 1651 false false 80 = true := by decide +kernel
private theorem w1651_2 : checkWitness 1651 true false 80 = true := by decide +kernel
private theorem cases1651 : checkFour 1651 (80,0,80,0) = true := by
  simp only [checkFour, w1651_0, w1651_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1651 : Coverage 1651 1652 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1651)
private theorem w1652_0 : checkWitness 1652 false false 518 = true := by decide +kernel
private theorem w1652_1 : checkWitness 1652 false true 4614 = true := by decide +kernel
private theorem w1652_2 : checkWitness 1652 true false 518 = true := by decide +kernel
private theorem w1652_3 : checkWitness 1652 true true 4614 = true := by decide +kernel
private theorem cases1652 : checkFour 1652 (518,4614,518,4614) = true := by
  simp only [checkFour, w1652_0, w1652_1, w1652_2, w1652_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1652 : Coverage 1652 1653 := checkList_sound (ws:=[(518,4614,518,4614)]) (by simpa only [checkList, Bool.and_true] using cases1652)
private theorem w1653_0 : checkWitness 1653 false false 8859 = true := by decide +kernel
private theorem w1653_2 : checkWitness 1653 true false 8855 = true := by decide +kernel
private theorem cases1653 : checkFour 1653 (8859,0,8855,0) = true := by
  simp only [checkFour, w1653_0, w1653_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1653 : Coverage 1653 1654 := checkList_sound (ws:=[(8859,0,8855,0)]) (by simpa only [checkList, Bool.and_true] using cases1653)
private theorem w1654_0 : checkWitness 1654 false false 8894 = true := by decide +kernel
private theorem w1654_2 : checkWitness 1654 true false 8885 = true := by decide +kernel
private theorem cases1654 : checkFour 1654 (8894,0,8885,0) = true := by
  simp only [checkFour, w1654_0, w1654_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1654 : Coverage 1654 1655 := checkList_sound (ws:=[(8894,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1654)
private theorem w1655_0 : checkWitness 1655 false false 98 = true := by decide +kernel
private theorem w1655_2 : checkWitness 1655 true false 98 = true := by decide +kernel
private theorem cases1655 : checkFour 1655 (98,0,98,0) = true := by
  simp only [checkFour, w1655_0, w1655_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1655 : Coverage 1655 1656 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1655)
private theorem w1656_0 : checkWitness 1656 false false 606 = true := by decide +kernel
private theorem w1656_1 : checkWitness 1656 false true 4698 = true := by decide +kernel
private theorem w1656_2 : checkWitness 1656 true false 597 = true := by decide +kernel
private theorem w1656_3 : checkWitness 1656 true true 4689 = true := by decide +kernel
private theorem cases1656 : checkFour 1656 (606,4698,597,4689) = true := by
  simp only [checkFour, w1656_0, w1656_1, w1656_2, w1656_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1656 : Coverage 1656 1657 := checkList_sound (ws:=[(606,4698,597,4689)]) (by simpa only [checkList, Bool.and_true] using cases1656)
private theorem w1657_0 : checkWitness 1657 false false 8855 = true := by decide +kernel
private theorem w1657_2 : checkWitness 1657 true false 8851 = true := by decide +kernel
private theorem cases1657 : checkFour 1657 (8855,0,8851,0) = true := by
  simp only [checkFour, w1657_0, w1657_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1657 : Coverage 1657 1658 := checkList_sound (ws:=[(8855,0,8851,0)]) (by simpa only [checkList, Bool.and_true] using cases1657)
private theorem w1658_0 : checkWitness 1658 false false 600 = true := by decide +kernel
private theorem w1658_1 : checkWitness 1658 false true 4692 = true := by decide +kernel
private theorem w1658_2 : checkWitness 1658 true false 591 = true := by decide +kernel
private theorem w1658_3 : checkWitness 1658 true true 4683 = true := by decide +kernel
private theorem cases1658 : checkFour 1658 (600,4692,591,4683) = true := by
  simp only [checkFour, w1658_0, w1658_1, w1658_2, w1658_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1658 : Coverage 1658 1659 := checkList_sound (ws:=[(600,4692,591,4683)]) (by simpa only [checkList, Bool.and_true] using cases1658)
private theorem w1659_0 : checkWitness 1659 false false 8824 = true := by decide +kernel
private theorem w1659_2 : checkWitness 1659 true false 8820 = true := by decide +kernel
private theorem cases1659 : checkFour 1659 (8824,0,8820,0) = true := by
  simp only [checkFour, w1659_0, w1659_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1659 : Coverage 1659 1660 := checkList_sound (ws:=[(8824,0,8820,0)]) (by simpa only [checkList, Bool.and_true] using cases1659)
private theorem w1660_0 : checkWitness 1660 false false 86 = true := by decide +kernel
private theorem w1660_2 : checkWitness 1660 true false 86 = true := by decide +kernel
private theorem cases1660 : checkFour 1660 (86,0,86,0) = true := by
  simp only [checkFour, w1660_0, w1660_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1660 : Coverage 1660 1661 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1660)
private theorem w1661_0 : checkWitness 1661 false false 78 = true := by decide +kernel
private theorem w1661_2 : checkWitness 1661 true false 78 = true := by decide +kernel
private theorem cases1661 : checkFour 1661 (78,0,78,0) = true := by
  simp only [checkFour, w1661_0, w1661_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1661 : Coverage 1661 1662 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1661)
private theorem w1662_0 : checkWitness 1662 false false 567 = true := by decide +kernel
private theorem w1662_1 : checkWitness 1662 false true 4655 = true := by decide +kernel
private theorem w1662_2 : checkWitness 1662 true false 567 = true := by decide +kernel
private theorem w1662_3 : checkWitness 1662 true true 4655 = true := by decide +kernel
private theorem cases1662 : checkFour 1662 (567,4655,567,4655) = true := by
  simp only [checkFour, w1662_0, w1662_1, w1662_2, w1662_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1662 : Coverage 1662 1663 := checkList_sound (ws:=[(567,4655,567,4655)]) (by simpa only [checkList, Bool.and_true] using cases1662)
private theorem w1663_0 : checkWitness 1663 false false 8840 = true := by decide +kernel
private theorem w1663_2 : checkWitness 1663 true false 8836 = true := by decide +kernel
private theorem cases1663 : checkFour 1663 (8840,0,8836,0) = true := by
  simp only [checkFour, w1663_0, w1663_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1663 : Coverage 1663 1664 := checkList_sound (ws:=[(8840,0,8836,0)]) (by simpa only [checkList, Bool.and_true] using cases1663)
theorem cover1632 : Coverage 1632 1664 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1632 one1633) (Coverage.join one1634 one1635)) (Coverage.join (Coverage.join one1636 one1637) (Coverage.join one1638 one1639))) (Coverage.join (Coverage.join (Coverage.join one1640 one1641) (Coverage.join one1642 one1643)) (Coverage.join (Coverage.join one1644 one1645) (Coverage.join one1646 one1647)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1648 one1649) (Coverage.join one1650 one1651)) (Coverage.join (Coverage.join one1652 one1653) (Coverage.join one1654 one1655))) (Coverage.join (Coverage.join (Coverage.join one1656 one1657) (Coverage.join one1658 one1659)) (Coverage.join (Coverage.join one1660 one1661) (Coverage.join one1662 one1663)))))
end NF181PA.Symbolic
