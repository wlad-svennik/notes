import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w32_0 : checkWitness 32 false false 653 = true := by decide +kernel
private theorem w32_1 : checkWitness 32 false true 4745 = true := by decide +kernel
private theorem w32_2 : checkWitness 32 true false 653 = true := by decide +kernel
private theorem w32_3 : checkWitness 32 true true 4745 = true := by decide +kernel
private theorem cases32 : checkFour 32 (653,4745,653,4745) = true := by
  simp only [checkFour, w32_0, w32_1, w32_2, w32_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one32 : Coverage 32 33 := checkList_sound (ws:=[(653,4745,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases32)
private theorem w33_0 : checkWitness 33 false false 8931 = true := by decide +kernel
private theorem w33_2 : checkWitness 33 true false 8927 = true := by decide +kernel
private theorem cases33 : checkFour 33 (8931,0,8927,0) = true := by
  simp only [checkFour, w33_0, w33_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one33 : Coverage 33 34 := checkList_sound (ws:=[(8931,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases33)
private theorem w34_0 : checkWitness 34 false false 28 = true := by decide +kernel
private theorem w34_2 : checkWitness 34 true false 28 = true := by decide +kernel
private theorem cases34 : checkFour 34 (28,0,28,0) = true := by
  simp only [checkFour, w34_0, w34_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one34 : Coverage 34 35 := checkList_sound (ws:=[(28,0,28,0)]) (by simpa only [checkList, Bool.and_true] using cases34)
private theorem w35_0 : checkWitness 35 false false 718 = true := by decide +kernel
private theorem w35_1 : checkWitness 35 false true 4802 = true := by decide +kernel
private theorem w35_2 : checkWitness 35 true false 709 = true := by decide +kernel
private theorem w35_3 : checkWitness 35 true true 4793 = true := by decide +kernel
private theorem cases35 : checkFour 35 (718,4802,709,4793) = true := by
  simp only [checkFour, w35_0, w35_1, w35_2, w35_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one35 : Coverage 35 36 := checkList_sound (ws:=[(718,4802,709,4793)]) (by simpa only [checkList, Bool.and_true] using cases35)
private theorem w36_0 : checkWitness 36 false false 8949 = true := by decide +kernel
private theorem w36_2 : checkWitness 36 true false 8945 = true := by decide +kernel
private theorem cases36 : checkFour 36 (8949,0,8945,0) = true := by
  simp only [checkFour, w36_0, w36_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one36 : Coverage 36 37 := checkList_sound (ws:=[(8949,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases36)
private theorem w37_0 : checkWitness 37 false false 32 = true := by decide +kernel
private theorem w37_2 : checkWitness 37 true false 32 = true := by decide +kernel
private theorem cases37 : checkFour 37 (32,0,32,0) = true := by
  simp only [checkFour, w37_0, w37_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one37 : Coverage 37 38 := checkList_sound (ws:=[(32,0,32,0)]) (by simpa only [checkList, Bool.and_true] using cases37)
private theorem w38_0 : checkWitness 38 false false 670 = true := by decide +kernel
private theorem w38_1 : checkWitness 38 false true 4766 = true := by decide +kernel
private theorem w38_2 : checkWitness 38 true false 670 = true := by decide +kernel
private theorem w38_3 : checkWitness 38 true true 4766 = true := by decide +kernel
private theorem cases38 : checkFour 38 (670,4766,670,4766) = true := by
  simp only [checkFour, w38_0, w38_1, w38_2, w38_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one38 : Coverage 38 39 := checkList_sound (ws:=[(670,4766,670,4766)]) (by simpa only [checkList, Bool.and_true] using cases38)
private theorem w39_0 : checkWitness 39 false false 656 = true := by decide +kernel
private theorem w39_1 : checkWitness 39 false true 4752 = true := by decide +kernel
private theorem w39_2 : checkWitness 39 true false 656 = true := by decide +kernel
private theorem w39_3 : checkWitness 39 true true 4752 = true := by decide +kernel
private theorem cases39 : checkFour 39 (656,4752,656,4752) = true := by
  simp only [checkFour, w39_0, w39_1, w39_2, w39_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one39 : Coverage 39 40 := checkList_sound (ws:=[(656,4752,656,4752)]) (by simpa only [checkList, Bool.and_true] using cases39)
private theorem w40_0 : checkWitness 40 false false 551 = true := by decide +kernel
private theorem w40_1 : checkWitness 40 false true 4647 = true := by decide +kernel
private theorem w40_2 : checkWitness 40 true false 551 = true := by decide +kernel
private theorem w40_3 : checkWitness 40 true true 4647 = true := by decide +kernel
private theorem cases40 : checkFour 40 (551,4647,551,4647) = true := by
  simp only [checkFour, w40_0, w40_1, w40_2, w40_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one40 : Coverage 40 41 := checkList_sound (ws:=[(551,4647,551,4647)]) (by simpa only [checkList, Bool.and_true] using cases40)
private theorem w41_0 : checkWitness 41 false false 8939 = true := by decide +kernel
private theorem w41_2 : checkWitness 41 true false 8935 = true := by decide +kernel
private theorem cases41 : checkFour 41 (8939,0,8935,0) = true := by
  simp only [checkFour, w41_0, w41_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one41 : Coverage 41 42 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases41)
private theorem w42_0 : checkWitness 42 false false 670 = true := by decide +kernel
private theorem w42_1 : checkWitness 42 false true 4766 = true := by decide +kernel
private theorem w42_2 : checkWitness 42 true false 661 = true := by decide +kernel
private theorem w42_3 : checkWitness 42 true true 4757 = true := by decide +kernel
private theorem cases42 : checkFour 42 (670,4766,661,4757) = true := by
  simp only [checkFour, w42_0, w42_1, w42_2, w42_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one42 : Coverage 42 43 := checkList_sound (ws:=[(670,4766,661,4757)]) (by simpa only [checkList, Bool.and_true] using cases42)
private theorem w43_0 : checkWitness 43 false false 204 = true := by decide +kernel
private theorem w43_2 : checkWitness 43 true false 204 = true := by decide +kernel
private theorem cases43 : checkFour 43 (204,0,204,0) = true := by
  simp only [checkFour, w43_0, w43_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one43 : Coverage 43 44 := checkList_sound (ws:=[(204,0,204,0)]) (by simpa only [checkList, Bool.and_true] using cases43)
private theorem w44_0 : checkWitness 44 false false 625 = true := by decide +kernel
private theorem w44_1 : checkWitness 44 false true 4713 = true := by decide +kernel
private theorem w44_2 : checkWitness 44 true false 625 = true := by decide +kernel
private theorem w44_3 : checkWitness 44 true true 4713 = true := by decide +kernel
private theorem cases44 : checkFour 44 (625,4713,625,4713) = true := by
  simp only [checkFour, w44_0, w44_1, w44_2, w44_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one44 : Coverage 44 45 := checkList_sound (ws:=[(625,4713,625,4713)]) (by simpa only [checkList, Bool.and_true] using cases44)
private theorem w45_0 : checkWitness 45 false false 8954 = true := by decide +kernel
private theorem w45_2 : checkWitness 45 true false 8945 = true := by decide +kernel
private theorem cases45 : checkFour 45 (8954,0,8945,0) = true := by
  simp only [checkFour, w45_0, w45_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one45 : Coverage 45 46 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases45)
private theorem w46_0 : checkWitness 46 false false 44 = true := by decide +kernel
private theorem w46_2 : checkWitness 46 true false 44 = true := by decide +kernel
private theorem cases46 : checkFour 46 (44,0,44,0) = true := by
  simp only [checkFour, w46_0, w46_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one46 : Coverage 46 47 := checkList_sound (ws:=[(44,0,44,0)]) (by simpa only [checkList, Bool.and_true] using cases46)
private theorem w47_0 : checkWitness 47 false false 36 = true := by decide +kernel
private theorem w47_2 : checkWitness 47 true false 36 = true := by decide +kernel
private theorem cases47 : checkFour 47 (36,0,36,0) = true := by
  simp only [checkFour, w47_0, w47_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one47 : Coverage 47 48 := checkList_sound (ws:=[(36,0,36,0)]) (by simpa only [checkList, Bool.and_true] using cases47)
private theorem w48_0 : checkWitness 48 false false 637 = true := by decide +kernel
private theorem w48_1 : checkWitness 48 false true 4729 = true := by decide +kernel
private theorem w48_2 : checkWitness 48 true false 637 = true := by decide +kernel
private theorem w48_3 : checkWitness 48 true true 4729 = true := by decide +kernel
private theorem cases48 : checkFour 48 (637,4729,637,4729) = true := by
  simp only [checkFour, w48_0, w48_1, w48_2, w48_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one48 : Coverage 48 49 := checkList_sound (ws:=[(637,4729,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases48)
private theorem w49_0 : checkWitness 49 false false 8915 = true := by decide +kernel
private theorem w49_2 : checkWitness 49 true false 8911 = true := by decide +kernel
private theorem cases49 : checkFour 49 (8915,0,8911,0) = true := by
  simp only [checkFour, w49_0, w49_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one49 : Coverage 49 50 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases49)
private theorem w50_0 : checkWitness 50 false false 36 = true := by decide +kernel
private theorem w50_2 : checkWitness 50 true false 36 = true := by decide +kernel
private theorem cases50 : checkFour 50 (36,0,36,0) = true := by
  simp only [checkFour, w50_0, w50_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one50 : Coverage 50 51 := checkList_sound (ws:=[(36,0,36,0)]) (by simpa only [checkList, Bool.and_true] using cases50)
private theorem w51_0 : checkWitness 51 false false 682 = true := by decide +kernel
private theorem w51_1 : checkWitness 51 false true 4778 = true := by decide +kernel
private theorem w51_2 : checkWitness 51 true false 673 = true := by decide +kernel
private theorem w51_3 : checkWitness 51 true true 4769 = true := by decide +kernel
private theorem cases51 : checkFour 51 (682,4778,673,4769) = true := by
  simp only [checkFour, w51_0, w51_1, w51_2, w51_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one51 : Coverage 51 52 := checkList_sound (ws:=[(682,4778,673,4769)]) (by simpa only [checkList, Bool.and_true] using cases51)
private theorem w52_0 : checkWitness 52 false false 8963 = true := by decide +kernel
private theorem w52_2 : checkWitness 52 true false 8954 = true := by decide +kernel
private theorem cases52 : checkFour 52 (8963,0,8954,0) = true := by
  simp only [checkFour, w52_0, w52_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one52 : Coverage 52 53 := checkList_sound (ws:=[(8963,0,8954,0)]) (by simpa only [checkList, Bool.and_true] using cases52)
private theorem w53_0 : checkWitness 53 false false 38 = true := by decide +kernel
private theorem w53_2 : checkWitness 53 true false 38 = true := by decide +kernel
private theorem cases53 : checkFour 53 (38,0,38,0) = true := by
  simp only [checkFour, w53_0, w53_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one53 : Coverage 53 54 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases53)
private theorem w54_0 : checkWitness 54 false false 558 = true := by decide +kernel
private theorem w54_1 : checkWitness 54 false true 4654 = true := by decide +kernel
private theorem w54_2 : checkWitness 54 true false 558 = true := by decide +kernel
private theorem w54_3 : checkWitness 54 true true 4654 = true := by decide +kernel
private theorem cases54 : checkFour 54 (558,4654,558,4654) = true := by
  simp only [checkFour, w54_0, w54_1, w54_2, w54_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one54 : Coverage 54 55 := checkList_sound (ws:=[(558,4654,558,4654)]) (by simpa only [checkList, Bool.and_true] using cases54)
private theorem w55_0 : checkWitness 55 false false 8962 = true := by decide +kernel
private theorem w55_2 : checkWitness 55 true false 8953 = true := by decide +kernel
private theorem cases55 : checkFour 55 (8962,0,8953,0) = true := by
  simp only [checkFour, w55_0, w55_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one55 : Coverage 55 56 := checkList_sound (ws:=[(8962,0,8953,0)]) (by simpa only [checkList, Bool.and_true] using cases55)
private theorem w56_0 : checkWitness 56 false false 50 = true := by decide +kernel
private theorem w56_2 : checkWitness 56 true false 50 = true := by decide +kernel
private theorem cases56 : checkFour 56 (50,0,50,0) = true := by
  simp only [checkFour, w56_0, w56_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one56 : Coverage 56 57 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases56)
private theorem w57_0 : checkWitness 57 false false 544 = true := by decide +kernel
private theorem w57_1 : checkWitness 57 false true 4640 = true := by decide +kernel
private theorem w57_2 : checkWitness 57 true false 544 = true := by decide +kernel
private theorem w57_3 : checkWitness 57 true true 4640 = true := by decide +kernel
private theorem cases57 : checkFour 57 (544,4640,544,4640) = true := by
  simp only [checkFour, w57_0, w57_1, w57_2, w57_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one57 : Coverage 57 58 := checkList_sound (ws:=[(544,4640,544,4640)]) (by simpa only [checkList, Bool.and_true] using cases57)
private theorem w58_0 : checkWitness 58 false false 8902 = true := by decide +kernel
private theorem w58_2 : checkWitness 58 true false 8898 = true := by decide +kernel
private theorem cases58 : checkFour 58 (8902,0,8898,0) = true := by
  simp only [checkFour, w58_0, w58_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one58 : Coverage 58 59 := checkList_sound (ws:=[(8902,0,8898,0)]) (by simpa only [checkList, Bool.and_true] using cases58)
private theorem w59_0 : checkWitness 59 false false 52 = true := by decide +kernel
private theorem w59_2 : checkWitness 59 true false 52 = true := by decide +kernel
private theorem cases59 : checkFour 59 (52,0,52,0) = true := by
  simp only [checkFour, w59_0, w59_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one59 : Coverage 59 60 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases59)
private theorem w60_0 : checkWitness 60 false false 582 = true := by decide +kernel
private theorem w60_1 : checkWitness 60 false true 4678 = true := by decide +kernel
private theorem w60_2 : checkWitness 60 true false 582 = true := by decide +kernel
private theorem w60_3 : checkWitness 60 true true 4678 = true := by decide +kernel
private theorem cases60 : checkFour 60 (582,4678,582,4678) = true := by
  simp only [checkFour, w60_0, w60_1, w60_2, w60_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one60 : Coverage 60 61 := checkList_sound (ws:=[(582,4678,582,4678)]) (by simpa only [checkList, Bool.and_true] using cases60)
private theorem w61_0 : checkWitness 61 false false 8923 = true := by decide +kernel
private theorem w61_2 : checkWitness 61 true false 8919 = true := by decide +kernel
private theorem cases61 : checkFour 61 (8923,0,8919,0) = true := by
  simp only [checkFour, w61_0, w61_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one61 : Coverage 61 62 := checkList_sound (ws:=[(8923,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases61)
private theorem w62_0 : checkWitness 62 false false 8958 = true := by decide +kernel
private theorem w62_2 : checkWitness 62 true false 8949 = true := by decide +kernel
private theorem cases62 : checkFour 62 (8958,0,8949,0) = true := by
  simp only [checkFour, w62_0, w62_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one62 : Coverage 62 63 := checkList_sound (ws:=[(8958,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases62)
private theorem w63_0 : checkWitness 63 false false 76 = true := by decide +kernel
private theorem w63_2 : checkWitness 63 true false 76 = true := by decide +kernel
private theorem cases63 : checkFour 63 (76,0,76,0) = true := by
  simp only [checkFour, w63_0, w63_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one63 : Coverage 63 64 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases63)
theorem cover0032 : Coverage 32 64 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one32 one33) (Coverage.join one34 one35)) (Coverage.join (Coverage.join one36 one37) (Coverage.join one38 one39))) (Coverage.join (Coverage.join (Coverage.join one40 one41) (Coverage.join one42 one43)) (Coverage.join (Coverage.join one44 one45) (Coverage.join one46 one47)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one48 one49) (Coverage.join one50 one51)) (Coverage.join (Coverage.join one52 one53) (Coverage.join one54 one55))) (Coverage.join (Coverage.join (Coverage.join one56 one57) (Coverage.join one58 one59)) (Coverage.join (Coverage.join one60 one61) (Coverage.join one62 one63)))))
end NF181PA.Symbolic
