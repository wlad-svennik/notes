module
public import Src181CmdEmit04
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter161 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((812:Nat):V) f (vector n 0 (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom29 n t s c u v y d w) w)) := by
  have micro := site0802 f n (v+y) (emitAtom27 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d7 : ((0+(cantor c (v+y))):V)=(emitAtom29 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c (v+y))):V)=(0+(emitAtom29 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter160 f n t s c u v y d w).trans mid

theorem commandEmitAfter162 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((816:Nat):V) f (vector n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)) (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0812 f n 0 (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom29 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom29 n t s c u v y d w))):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom29 n t s c u v y d w))):V)=(0+((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter161 f n t s c u v y d w).trans mid

theorem commandEmitAfter163 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((817:Nat):V) f (vector n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0816 f n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)) (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w))+1):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter162 f n t s c u v y d w).trans mid

theorem commandEmitAfter164 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((825:Nat):V) f (vector n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w) w)) := by
  have micro := site0817 f n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom27 n t s c u v y d w))):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom27 n t s c u v y d w)):V)=(0+(emitAtom27 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom27 n t s c u v y d w))):V)=left (emitAtom27 n t s c u v y d w))).trans (by change left (cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom27 n t s c u v y d w))):V)=(emitAtom25 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom27 n t s c u v y d w)):V)=(0+(emitAtom27 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom27 n t s c u v y d w))):V)=right (emitAtom27 n t s c u v y d w))).trans (by change right (cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter163 f n t s c u v y d w).trans mid

theorem commandEmitAfter165 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((828:Nat):V) f (vector n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0825 f n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w) w
  have d2 : ((0+(emitAtom25 n t s c u v y d w)):V)=(emitAtom25 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter164 f n t s c u v y d w).trans mid

theorem commandEmitAfter166 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((838:Nat):V) f (vector n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom30 n t s c u v y d w) w)) := by
  have micro := site0828 f n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1))):V)=(emitAtom30 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1))):V)=(0+(emitAtom30 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter165 f n t s c u v y d w).trans mid

theorem commandEmitAfter167 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((842:Nat):V) f (vector n ((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w)) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0838 f n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom30 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom30 n t s c u v y d w))):V)=((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom30 n t s c u v y d w))):V)=(0+((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter166 f n t s c u v y d w).trans mid

theorem commandEmitAfter168 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((850:Nat):V) f (vector n ((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w)) 0 c (d+u) (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom22 n t s c u v y d w) w)) := by
  have micro := site0842 f n ((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w)) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom25 n t s c u v y d w))):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom25 n t s c u v y d w)):V)=(0+(emitAtom25 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom25 n t s c u v y d w))):V)=left (emitAtom25 n t s c u v y d w))).trans (by change left (cantor ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom22 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom25 n t s c u v y d w))):V)=(emitAtom22 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom25 n t s c u v y d w)):V)=(0+(emitAtom25 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom25 n t s c u v y d w))):V)=right (emitAtom25 n t s c u v y d w))).trans (by change right (cantor ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom22 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter167 f n t s c u v y d w).trans mid

theorem commandEmitAfter169 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((853:Nat):V) f (vector n ((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w)) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0850 f n ((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w)) 0 c (d+u) (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom22 n t s c u v y d w) w
  have d2 : ((0+(emitAtom22 n t s c u v y d w)):V)=(emitAtom22 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter168 f n t s c u v y d w).trans mid

theorem commandEmitAfter170 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((863:Nat):V) f (vector n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom31 n t s c u v y d w) w)) := by
  have micro := site0853 f n ((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w)) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) ((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w)))):V)=(emitAtom31 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) ((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w)))):V)=(0+(emitAtom31 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter169 f n t s c u v y d w).trans mid

theorem commandEmitAfter171 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((867:Nat):V) f (vector n ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0863 f n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom31 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom31 n t s c u v y d w))):V)=((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom31 n t s c u v y d w))):V)=(0+((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter170 f n t s c u v y d w).trans mid

theorem commandEmitAfter172 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((870:Nat):V) f (vector n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) 0 w)) := by
  have micro := site0867 f n ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w))):V)=((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter171 f n t s c u v y d w).trans mid

theorem commandEmitAfter173 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((873:Nat):V) f (vector n (emitAtom22 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) 0 w)) := by
  have micro := site0870 f n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) 0 w
  have d1 : ((0+(emitAtom22 n t s c u v y d w)):V)=(emitAtom22 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter172 f n t s c u v y d w).trans mid

theorem commandEmitAfter174 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((883:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom32 n t s c u v y d w) w)) := by
  have micro := site0873 f n (emitAtom22 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) (emitAtom22 n t s c u v y d w))):V)=(emitAtom32 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) (emitAtom22 n t s c u v y d w))):V)=(0+(emitAtom32 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter173 f n t s c u v y d w).trans mid

theorem commandEmitAfter175 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((886:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0883 f n 0 0 c (d+u) (v+y) 0 (emitAtom32 n t s c u v y d w) w
  have d2 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter174 f n t s c u v y d w).trans mid

theorem commandEmitAfter176 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((887:Nat):V) f (vector n 1 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0886 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+1):V)=1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter175 f n t s c u v y d w).trans mid

theorem commandEmitAfter177 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((890:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 1 0 w)) := by
  have micro := site0887 f n 1 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+1):V)=1 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter176 f n t s c u v y d w).trans mid

theorem commandEmitAfter178 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((893:Nat):V) f (vector n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) 1 0 w)) := by
  have micro := site0890 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 1 0 w
  have d1 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter177 f n t s c u v y d w).trans mid

theorem commandEmitAfter179 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((903:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom33 n t s c u v y d w) w)) := by
  have micro := site0893 f n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) 1 0 w
  have d7 : ((0+(cantor 1 (emitAtom32 n t s c u v y d w))):V)=(emitAtom33 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor 1 (emitAtom32 n t s c u v y d w))):V)=(0+(emitAtom33 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter178 f n t s c u v y d w).trans mid

theorem commandEmitAfter180 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((906:Nat):V) f (vector n 0 (emitAtom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0903 f n 0 0 c (d+u) (v+y) 0 (emitAtom33 n t s c u v y d w) w
  have d2 : ((0+(emitAtom33 n t s c u v y d w)):V)=(emitAtom33 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter179 f n t s c u v y d w).trans mid

theorem commandEmitAfter181 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((910:Nat):V) f (vector n c (emitAtom33 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site0906 f n 0 (emitAtom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter180 f n t s c u v y d w).trans mid

theorem commandEmitAfter182 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((913:Nat):V) f (vector n c (emitAtom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0910 f n c (emitAtom33 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter181 f n t s c u v y d w).trans mid

theorem commandEmitAfter183 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((921:Nat):V) f (vector n c 0 c (d+u) (v+y) 1 (emitAtom32 n t s c u v y d w) w)) := by
  have micro := site0913 f n c (emitAtom33 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom33 n t s c u v y d w))):V)=1 := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom33 n t s c u v y d w)):V)=(0+(emitAtom33 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom33 n t s c u v y d w))):V)=left (emitAtom33 n t s c u v y d w))).trans (by change left (cantor 1 (emitAtom32 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom33 n t s c u v y d w))):V)=(emitAtom32 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom33 n t s c u v y d w)):V)=(0+(emitAtom33 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom33 n t s c u v y d w))):V)=right (emitAtom33 n t s c u v y d w))).trans (by change right (cantor 1 (emitAtom32 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter182 f n t s c u v y d w).trans mid

theorem commandEmitAfter184 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((924:Nat):V) f (vector n c (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 1 0 w)) := by
  have micro := site0921 f n c 0 c (d+u) (v+y) 1 (emitAtom32 n t s c u v y d w) w
  have d2 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter183 f n t s c u v y d w).trans mid

theorem commandEmitAfter185 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((934:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom34 n t s c u v y d w) w)) := by
  have micro := site0924 f n c (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 1 0 w
  have d7 : ((0+(cantor 1 c)):V)=(emitAtom34 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor 1 c)):V)=(0+(emitAtom34 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter184 f n t s c u v y d w).trans mid

theorem commandEmitAfter186 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((938:Nat):V) f (vector n ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0934 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom34 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom34 n t s c u v y d w))):V)=((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom34 n t s c u v y d w))):V)=(0+((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter185 f n t s c u v y d w).trans mid

theorem commandEmitAfter187 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((939:Nat):V) f (vector n ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0938 f n ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w))+1):V)=((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter186 f n t s c u v y d w).trans mid

theorem commandEmitAfter188 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((942:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0939 f n ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1)):V)=((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter187 f n t s c u v y d w).trans mid

theorem commandEmitAfter189 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((945:Nat):V) f (vector n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0942 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter188 f n t s c u v y d w).trans mid

theorem commandEmitAfter190 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((955:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom35 n t s c u v y d w) w)) := by
  have micro := site0945 f n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w))):V)=(emitAtom35 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w))):V)=(0+(emitAtom35 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter189 f n t s c u v y d w).trans mid

theorem commandEmitAfter191 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((958:Nat):V) f (vector n 0 (emitAtom35 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0955 f n 0 0 c (d+u) (v+y) 0 (emitAtom35 n t s c u v y d w) w
  have d2 : ((0+(emitAtom35 n t s c u v y d w)):V)=(emitAtom35 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter190 f n t s c u v y d w).trans mid

theorem commandEmitAfter192 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((962:Nat):V) f (vector n (d+u) (emitAtom35 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0958 f n 0 (emitAtom35 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter191 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
