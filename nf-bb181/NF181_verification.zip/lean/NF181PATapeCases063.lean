import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2016_0 : checkWitness 2016 false false 74 = true := by decide +kernel
private theorem w2016_2 : checkWitness 2016 true false 74 = true := by decide +kernel
private theorem cases2016 : checkFour 2016 (74,0,74,0) = true := by
  simp only [checkFour, w2016_0, w2016_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2016 : Coverage 2016 2017 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2016)
private theorem w2017_0 : checkWitness 2017 false false 561 = true := by decide +kernel
private theorem w2017_1 : checkWitness 2017 false true 4657 = true := by decide +kernel
private theorem w2017_2 : checkWitness 2017 true false 561 = true := by decide +kernel
private theorem w2017_3 : checkWitness 2017 true true 4657 = true := by decide +kernel
private theorem cases2017 : checkFour 2017 (561,4657,561,4657) = true := by
  simp only [checkFour, w2017_0, w2017_1, w2017_2, w2017_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2017 : Coverage 2017 2018 := checkList_sound (ws:=[(561,4657,561,4657)]) (by simpa only [checkList, Bool.and_true] using cases2017)
private theorem w2018_0 : checkWitness 2018 false false 8914 = true := by decide +kernel
private theorem w2018_2 : checkWitness 2018 true false 8905 = true := by decide +kernel
private theorem cases2018 : checkFour 2018 (8914,0,8905,0) = true := by
  simp only [checkFour, w2018_0, w2018_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2018 : Coverage 2018 2019 := checkList_sound (ws:=[(8914,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases2018)
private theorem w2019_0 : checkWitness 2019 false false 8860 = true := by decide +kernel
private theorem w2019_2 : checkWitness 2019 true false 8856 = true := by decide +kernel
private theorem cases2019 : checkFour 2019 (8860,0,8856,0) = true := by
  simp only [checkFour, w2019_0, w2019_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2019 : Coverage 2019 2020 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases2019)
private theorem w2020_0 : checkWitness 2020 false false 82 = true := by decide +kernel
private theorem w2020_2 : checkWitness 2020 true false 82 = true := by decide +kernel
private theorem cases2020 : checkFour 2020 (82,0,82,0) = true := by
  simp only [checkFour, w2020_0, w2020_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2020 : Coverage 2020 2021 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2020)
private theorem w2021_0 : checkWitness 2021 false false 644 = true := by decide +kernel
private theorem w2021_1 : checkWitness 2021 false true 4732 = true := by decide +kernel
private theorem w2021_2 : checkWitness 2021 true false 635 = true := by decide +kernel
private theorem w2021_3 : checkWitness 2021 true true 4723 = true := by decide +kernel
private theorem cases2021 : checkFour 2021 (644,4732,635,4723) = true := by
  simp only [checkFour, w2021_0, w2021_1, w2021_2, w2021_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2021 : Coverage 2021 2022 := checkList_sound (ws:=[(644,4732,635,4723)]) (by simpa only [checkList, Bool.and_true] using cases2021)
private theorem w2022_0 : checkWitness 2022 false false 8879 = true := by decide +kernel
private theorem w2022_2 : checkWitness 2022 true false 8875 = true := by decide +kernel
private theorem cases2022 : checkFour 2022 (8879,0,8875,0) = true := by
  simp only [checkFour, w2022_0, w2022_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2022 : Coverage 2022 2023 := checkList_sound (ws:=[(8879,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases2022)
private theorem w2023_0 : checkWitness 2023 false false 72 = true := by decide +kernel
private theorem w2023_2 : checkWitness 2023 true false 72 = true := by decide +kernel
private theorem cases2023 : checkFour 2023 (72,0,72,0) = true := by
  simp only [checkFour, w2023_0, w2023_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2023 : Coverage 2023 2024 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2023)
private theorem w2024_0 : checkWitness 2024 false false 496 = true := by decide +kernel
private theorem w2024_1 : checkWitness 2024 false true 4592 = true := by decide +kernel
private theorem w2024_2 : checkWitness 2024 true false 496 = true := by decide +kernel
private theorem w2024_3 : checkWitness 2024 true true 4592 = true := by decide +kernel
private theorem cases2024 : checkFour 2024 (496,4592,496,4592) = true := by
  simp only [checkFour, w2024_0, w2024_1, w2024_2, w2024_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2024 : Coverage 2024 2025 := checkList_sound (ws:=[(496,4592,496,4592)]) (by simpa only [checkList, Bool.and_true] using cases2024)
private theorem w2025_0 : checkWitness 2025 false false 8891 = true := by decide +kernel
private theorem w2025_2 : checkWitness 2025 true false 8887 = true := by decide +kernel
private theorem cases2025 : checkFour 2025 (8891,0,8887,0) = true := by
  simp only [checkFour, w2025_0, w2025_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2025 : Coverage 2025 2026 := checkList_sound (ws:=[(8891,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases2025)
private theorem w2026_0 : checkWitness 2026 false false 622 = true := by decide +kernel
private theorem w2026_1 : checkWitness 2026 false true 4718 = true := by decide +kernel
private theorem w2026_2 : checkWitness 2026 true false 613 = true := by decide +kernel
private theorem w2026_3 : checkWitness 2026 true true 4709 = true := by decide +kernel
private theorem cases2026 : checkFour 2026 (622,4718,613,4709) = true := by
  simp only [checkFour, w2026_0, w2026_1, w2026_2, w2026_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2026 : Coverage 2026 2027 := checkList_sound (ws:=[(622,4718,613,4709)]) (by simpa only [checkList, Bool.and_true] using cases2026)
private theorem w2027_0 : checkWitness 2027 false false 178 = true := by decide +kernel
private theorem w2027_2 : checkWitness 2027 true false 178 = true := by decide +kernel
private theorem cases2027 : checkFour 2027 (178,0,178,0) = true := by
  simp only [checkFour, w2027_0, w2027_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2027 : Coverage 2027 2028 := checkList_sound (ws:=[(178,0,178,0)]) (by simpa only [checkList, Bool.and_true] using cases2027)
private theorem w2028_0 : checkWitness 2028 false false 577 = true := by decide +kernel
private theorem w2028_1 : checkWitness 2028 false true 4665 = true := by decide +kernel
private theorem w2028_2 : checkWitness 2028 true false 577 = true := by decide +kernel
private theorem w2028_3 : checkWitness 2028 true true 4665 = true := by decide +kernel
private theorem cases2028 : checkFour 2028 (577,4665,577,4665) = true := by
  simp only [checkFour, w2028_0, w2028_1, w2028_2, w2028_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2028 : Coverage 2028 2029 := checkList_sound (ws:=[(577,4665,577,4665)]) (by simpa only [checkList, Bool.and_true] using cases2028)
private theorem w2029_0 : checkWitness 2029 false false 8906 = true := by decide +kernel
private theorem w2029_2 : checkWitness 2029 true false 8897 = true := by decide +kernel
private theorem cases2029 : checkFour 2029 (8906,0,8897,0) = true := by
  simp only [checkFour, w2029_0, w2029_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2029 : Coverage 2029 2030 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases2029)
private theorem w2030_0 : checkWitness 2030 false false 78 = true := by decide +kernel
private theorem w2030_2 : checkWitness 2030 true false 78 = true := by decide +kernel
private theorem cases2030 : checkFour 2030 (78,0,78,0) = true := by
  simp only [checkFour, w2030_0, w2030_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2030 : Coverage 2030 2031 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2030)
private theorem w2031_0 : checkWitness 2031 false false 70 = true := by decide +kernel
private theorem w2031_2 : checkWitness 2031 true false 70 = true := by decide +kernel
private theorem cases2031 : checkFour 2031 (70,0,70,0) = true := by
  simp only [checkFour, w2031_0, w2031_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2031 : Coverage 2031 2032 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2031)
private theorem w2032_0 : checkWitness 2032 false false 583 = true := by decide +kernel
private theorem w2032_1 : checkWitness 2032 false true 4675 = true := by decide +kernel
private theorem w2032_2 : checkWitness 2032 true false 583 = true := by decide +kernel
private theorem w2032_3 : checkWitness 2032 true true 4675 = true := by decide +kernel
private theorem cases2032 : checkFour 2032 (583,4675,583,4675) = true := by
  simp only [checkFour, w2032_0, w2032_1, w2032_2, w2032_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2032 : Coverage 2032 2033 := checkList_sound (ws:=[(583,4675,583,4675)]) (by simpa only [checkList, Bool.and_true] using cases2032)
private theorem w2033_0 : checkWitness 2033 false false 8844 = true := by decide +kernel
private theorem w2033_2 : checkWitness 2033 true false 8840 = true := by decide +kernel
private theorem cases2033 : checkFour 2033 (8844,0,8840,0) = true := by
  simp only [checkFour, w2033_0, w2033_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2033 : Coverage 2033 2034 := checkList_sound (ws:=[(8844,0,8840,0)]) (by simpa only [checkList, Bool.and_true] using cases2033)
private theorem w2034_0 : checkWitness 2034 false false 70 = true := by decide +kernel
private theorem w2034_2 : checkWitness 2034 true false 70 = true := by decide +kernel
private theorem cases2034 : checkFour 2034 (70,0,70,0) = true := by
  simp only [checkFour, w2034_0, w2034_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2034 : Coverage 2034 2035 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2034)
private theorem w2035_0 : checkWitness 2035 false false 538 = true := by decide +kernel
private theorem w2035_1 : checkWitness 2035 false true 4634 = true := by decide +kernel
private theorem w2035_2 : checkWitness 2035 true false 538 = true := by decide +kernel
private theorem w2035_3 : checkWitness 2035 true true 4634 = true := by decide +kernel
private theorem cases2035 : checkFour 2035 (538,4634,538,4634) = true := by
  simp only [checkFour, w2035_0, w2035_1, w2035_2, w2035_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2035 : Coverage 2035 2036 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases2035)
private theorem w2036_0 : checkWitness 2036 false false 8879 = true := by decide +kernel
private theorem w2036_2 : checkWitness 2036 true false 8875 = true := by decide +kernel
private theorem cases2036 : checkFour 2036 (8879,0,8875,0) = true := by
  simp only [checkFour, w2036_0, w2036_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2036 : Coverage 2036 2037 := checkList_sound (ws:=[(8879,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases2036)
private theorem w2037_0 : checkWitness 2037 false false 8914 = true := by decide +kernel
private theorem w2037_2 : checkWitness 2037 true false 8905 = true := by decide +kernel
private theorem cases2037 : checkFour 2037 (8914,0,8905,0) = true := by
  simp only [checkFour, w2037_0, w2037_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2037 : Coverage 2037 2038 := checkList_sound (ws:=[(8914,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases2037)
private theorem w2038_0 : checkWitness 2038 false false 88 = true := by decide +kernel
private theorem w2038_2 : checkWitness 2038 true false 88 = true := by decide +kernel
private theorem cases2038 : checkFour 2038 (88,0,88,0) = true := by
  simp only [checkFour, w2038_0, w2038_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2038 : Coverage 2038 2039 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases2038)
private theorem w2039_0 : checkWitness 2039 false false 626 = true := by decide +kernel
private theorem w2039_1 : checkWitness 2039 false true 4718 = true := by decide +kernel
private theorem w2039_2 : checkWitness 2039 true false 617 = true := by decide +kernel
private theorem w2039_3 : checkWitness 2039 true true 4709 = true := by decide +kernel
private theorem cases2039 : checkFour 2039 (626,4718,617,4709) = true := by
  simp only [checkFour, w2039_0, w2039_1, w2039_2, w2039_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2039 : Coverage 2039 2040 := checkList_sound (ws:=[(626,4718,617,4709)]) (by simpa only [checkList, Bool.and_true] using cases2039)
private theorem w2040_0 : checkWitness 2040 false false 8875 = true := by decide +kernel
private theorem w2040_2 : checkWitness 2040 true false 8871 = true := by decide +kernel
private theorem cases2040 : checkFour 2040 (8875,0,8871,0) = true := by
  simp only [checkFour, w2040_0, w2040_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2040 : Coverage 2040 2041 := checkList_sound (ws:=[(8875,0,8871,0)]) (by simpa only [checkList, Bool.and_true] using cases2040)
private theorem w2041_0 : checkWitness 2041 false false 620 = true := by decide +kernel
private theorem w2041_1 : checkWitness 2041 false true 4712 = true := by decide +kernel
private theorem w2041_2 : checkWitness 2041 true false 611 = true := by decide +kernel
private theorem w2041_3 : checkWitness 2041 true true 4703 = true := by decide +kernel
private theorem cases2041 : checkFour 2041 (620,4712,611,4703) = true := by
  simp only [checkFour, w2041_0, w2041_1, w2041_2, w2041_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2041 : Coverage 2041 2042 := checkList_sound (ws:=[(620,4712,611,4703)]) (by simpa only [checkList, Bool.and_true] using cases2041)
private theorem w2042_0 : checkWitness 2042 false false 8844 = true := by decide +kernel
private theorem w2042_2 : checkWitness 2042 true false 8840 = true := by decide +kernel
private theorem cases2042 : checkFour 2042 (8844,0,8840,0) = true := by
  simp only [checkFour, w2042_0, w2042_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2042 : Coverage 2042 2043 := checkList_sound (ws:=[(8844,0,8840,0)]) (by simpa only [checkList, Bool.and_true] using cases2042)
private theorem w2043_0 : checkWitness 2043 false false 76 = true := by decide +kernel
private theorem w2043_2 : checkWitness 2043 true false 76 = true := by decide +kernel
private theorem cases2043 : checkFour 2043 (76,0,76,0) = true := by
  simp only [checkFour, w2043_0, w2043_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2043 : Coverage 2043 2044 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases2043)
private theorem w2044_0 : checkWitness 2044 false false 68 = true := by decide +kernel
private theorem w2044_2 : checkWitness 2044 true false 68 = true := by decide +kernel
private theorem cases2044 : checkFour 2044 (68,0,68,0) = true := by
  simp only [checkFour, w2044_0, w2044_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2044 : Coverage 2044 2045 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2044)
private theorem w2045_0 : checkWitness 2045 false false 587 = true := by decide +kernel
private theorem w2045_1 : checkWitness 2045 false true 4675 = true := by decide +kernel
private theorem w2045_2 : checkWitness 2045 true false 587 = true := by decide +kernel
private theorem w2045_3 : checkWitness 2045 true true 4675 = true := by decide +kernel
private theorem cases2045 : checkFour 2045 (587,4675,587,4675) = true := by
  simp only [checkFour, w2045_0, w2045_1, w2045_2, w2045_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2045 : Coverage 2045 2046 := checkList_sound (ws:=[(587,4675,587,4675)]) (by simpa only [checkList, Bool.and_true] using cases2045)
private theorem w2046_0 : checkWitness 2046 false false 8860 = true := by decide +kernel
private theorem w2046_2 : checkWitness 2046 true false 8856 = true := by decide +kernel
private theorem cases2046 : checkFour 2046 (8860,0,8856,0) = true := by
  simp only [checkFour, w2046_0, w2046_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2046 : Coverage 2046 2047 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases2046)
private theorem w2047_0 : checkWitness 2047 false false 8856 = true := by decide +kernel
private theorem w2047_2 : checkWitness 2047 true false 8852 = true := by decide +kernel
private theorem cases2047 : checkFour 2047 (8856,0,8852,0) = true := by
  simp only [checkFour, w2047_0, w2047_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2047 : Coverage 2047 2048 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases2047)
theorem cover2016 : Coverage 2016 2048 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2016 one2017) (Coverage.join one2018 one2019)) (Coverage.join (Coverage.join one2020 one2021) (Coverage.join one2022 one2023))) (Coverage.join (Coverage.join (Coverage.join one2024 one2025) (Coverage.join one2026 one2027)) (Coverage.join (Coverage.join one2028 one2029) (Coverage.join one2030 one2031)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2032 one2033) (Coverage.join one2034 one2035)) (Coverage.join (Coverage.join one2036 one2037) (Coverage.join one2038 one2039))) (Coverage.join (Coverage.join (Coverage.join one2040 one2041) (Coverage.join one2042 one2043)) (Coverage.join (Coverage.join one2044 one2045) (Coverage.join one2046 one2047)))))
end NF181PA.Symbolic
