module
public import ModelEncodedWord
public import ModelCommandDefinability
public import NF181PACompile
import Mathlib.Tactic.FinCases

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch
set_option maxHeartbeats 4500000
set_option maxRecDepth 12000
namespace NF181PA.Scanner
open NF181PA.Packed NF181PA.Commands
open PA192.ModelSearch.RegisterFields PA192.ModelSearch.Enumeration PA192.ModelSearch.Words
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem state_eta (e : V) : state (top e) (stack e) (cache e) (param e)=e := by
  simp [state,top,stack,cache,param]

/-- Reading AX with a fresh zero-batch payload preserves its prescribed continuation. -/
theorem ax_ignore_tail (u b d c t e : V) :
    pi₁ (axRaw u b d c (zeroBatches c t) e) = pi₁ (axRaw u b d c (zeroBatches c 0) e) := by
  conv => lhs; rw [←state_eta e]
  conv => rhs; rw [←state_eta e]
  by_cases h : c=0
  · subst c; simp [ax_zero]
  · have g : 1≤c := by simpa using succ_le_iff_lt.mpr (lt_of_le_of_ne (show 0≤c from zero_le) (Ne.symm h))
    obtain ⟨j,rfl⟩ : ∃ j, c=j+1 := ⟨c-1,(sub_add_self_of_le g).symm⟩
    simp [ax_positive]

/-- Value of the literal command on its incoming state, allowing arbitrary extra AX fields. -/
noncomputable def rawAX (n e : V) : V :=
  let t := right n
  let u := left t
  let t := right t
  let b := left t
  let t := right t
  pi₁ (axRaw u b (left t) (left n-2) (right t) e)

instance rawAXDef : Language.DefinableFunction₂ ℒₒᵣ (rawAX (V:=V)) := by
  let A (i : Fin 6) (v : Fin 2 → V) := ![left (right (v 0)),left (right (right (v 0))),
    left (right (right (right (v 0)))),left (v 0)-2,right (right (right (right (v 0)))),v 1] i
  have args (i : Fin 6) : Language.DefinableFunction ℒₒᵣ (A i) := by
    fin_cases i <;> dsimp [A] <;> definability
  apply Language.DefinableFunction₁.comp (F:=pi₁)
  exact Language.DefinableFunction.substitution (f:=A) (axRawDef (V:=V)) args

noncomputable def rawAction (n e : V) : V :=
  let tag:=left n
  let x:=left (right n)
  chooseZero tag (mode x e) (chooseZero (tag-1) (deduction x e) (rawAX n e))
instance rawActionDef : Language.DefinableFunction₂ ℒₒᵣ (rawAction (V:=V)) := by unfold rawAction; definability

theorem rawAction_ax (u b d c t e : V) : rawAction (literalAXInput u b d c t) e =
    pi₁ (axRaw u b d c (zeroBatches c t) e) := by
  have hp : c+2≠0 := by simp
  have hp' : c+2-1≠0 := by rw [tag_succ_sub_one]; simp
  simp [rawAction,rawAX,chooseZero,literalAXInput,hp,hp']

theorem rawAction_assemble (cmd t e : V) : rawAction (assemble cmd t) e=exec cmd e := by
  dsimp only [assemble,exec,chooseZero]
  by_cases h0 : pi₁ cmd=0
  · simp [h0,rawAction,chooseZero]
  by_cases h1 : pi₁ cmd-1=0
  · simp [h0,h1,rawAction,chooseZero]
  simp only [h0,h1,↓reduceIte,rawAction_ax]
  rw [ax_ignore_tail]
  rfl

theorem ax_ends : ∀ r : V, ∀ z a b tail : V,
    fields (iterate nextBatch r (packBatch r z a b tail)) = unread r tail := by
  apply modelInduct
  · unfold fields packBatch; definability
  · intro z a b tail; simp [unread,fields,packBatch]
  · intro r ih z a b tail
    rw [iterate_succ_left]
    have nex := next_literal r z a b (left tail) (left (right tail)) (right (right tail))
    have decomp : cantor (left tail) (cantor (left (right tail)) (right (right tail)))=tail := by
      rw [show cantor (left (right tail)) (right (right tail))=right tail from inversePair_correct _,show cantor (left tail) (right tail)=tail from inversePair_correct _]
    rw [decomp] at nex
    rw [nex,ih]; simp only [unread,iterate_succ_left,consumePair]

noncomputable def cursor (s : V) : V :=
  let k := pi₁ s
  let t := tail (pi₂ s)
  chooseZero t ⟪k+1,cantor 0 (k+1)⟫ ⟪k,t-1⟫
instance cursorDef : Language.DefinableFunction₁ ℒₒᵣ (cursor (V:=V)) := by unfold cursor; definability

theorem cursor_zero {k n : V} (h : tail n=0) : cursor ⟪k,n⟫=⟪k+1,cantor 0 (k+1)⟫ := by simp [cursor,h,chooseZero]
theorem cursor_pos {k n : V} (h : tail n≠0) : cursor ⟪k,n⟫=⟪k,tail n-1⟫ := by simp [cursor,h,chooseZero]

/-- Every candidate, of arbitrary internal size and with arbitrary command fields, exhausts. -/
theorem refill (n : V) : ∀ k, ∃ j, j≤n+1 ∧ iterate cursor j ⟪k,n⟫=⟪k+1,cantor 0 (k+1)⟫ := by
  induction n using strongModel with
  | d => definability
  | step n ih =>
    intro k
    by_cases h : tail n=0
    · refine ⟨1,?_,?_⟩
      · simpa using add_le_add_right (show (0:V)≤n from zero_le) 1
      · rw [show (1:V)=0+1 by simp,iterate_succ_left,iterate_zero,cursor_zero h,zero_add]
    · have hp : 0<tail n := lt_of_le_of_ne zero_le (Ne.symm h)
      have hg : 1≤tail n := by simpa using succ_le_iff_lt.mpr hp
      have rep := sub_add_self_of_le hg
      have lt : tail n-1<n := lt_of_lt_of_le (lt_of_lt_of_eq (show tail n-1<(tail n-1)+1 from by simp) rep) (tail_bounded n)
      obtain ⟨j,hj,endp⟩ := ih (tail n-1) lt k
      refine ⟨j+1,add_le_add (le_trans hj (le_of_eq_of_le rep (tail_bounded n))) (le_refl 1),?_⟩
      rw [iterate_succ_left,cursor_pos h,endp]

/-- Consecutive enumeration visits each candidate above the current one, also in a nonstandard model. -/
theorem reaches (start : V) : ∀ d : V, ∃ j, iterate cursor j ⟪start,cantor 0 start⟫=⟪start+d,cantor 0 (start+d)⟫ := by
  apply modelInduct
  · definability
  · exact ⟨0,by simp⟩
  · intro d ih
    obtain ⟨j,h⟩ := ih
    obtain ⟨k,_,hk⟩ := refill (cantor 0 (start+d)) (start+d)
    exact ⟨j+k,by rw [iterate_add,h,hk,add_assoc]⟩


theorem cursor_at_command (c w t k : V) :
    cursor ⟪k,encode (cons c w) t⟫ = ⟪k,encode w t⟫ := by
  rw [encode_cons]
  have h := restore_tail c (encode w t+1)
  have hp : Enumeration.tail (assemble c (encode w t+1))≠0 := by rw [h]; simp
  rw [cursor_pos hp,h]; simp

/-- In the first command the outer tag is zero, and the inner Cantor rank is the
new counter. Choose that rank to encode an arbitrary desired continuation. -/
theorem candidate_for_word (w start : V) : ∃ j k : V,
    iterate cursor j ⟪start,cantor 0 start⟫=⟪k,encode w (start+1)⟫ := by
  let q := encode w (start+1)
  let k := cantor 0 (q+1)
  have le : start≤k := le_trans (show start≤start+1 from le_self_add)
    (le_trans (encode_lower w _) (le_trans le_self_add (cantor_ge_right 0 (q+1))))
  have restore : start+(k-start)=k := by rw [add_comm,sub_add_self_of_le le]
  obtain ⟨j,h⟩ := reaches start (k-start)
  rw [restore] at h
  have tailQ : Enumeration.tail (cantor 0 k) = q+1 := by simp [k,Enumeration.tail,chooseZero]
  have pos : Enumeration.tail (cantor 0 k)≠0 := by rw [tailQ]; simp
  refine ⟨j+1,k,?_⟩
  rw [iterate_succ,h,cursor_pos pos,tailQ]; simp [q]

noncomputable def fresh (k raw e : V) := ⟪k,⟪raw,e⟫⟫
noncomputable def index (a : V) := pi₁ a
noncomputable def input (a : V) := pi₁ (pi₂ a)
noncomputable def dataState (a : V) := pi₂ (pi₂ a)
noncomputable def control (a : V) := ⟪index a,input a⟫
noncomputable def next (a : V) : V :=
  let c:=cursor (control a)
  fresh (pi₁ c) (pi₂ c) (rawAction (input a) (dataState a))
def observed (a : V) : Prop := left (input a)=0 ∧ cache (dataState a)=3

instance nextDef : Language.DefinableFunction₁ ℒₒᵣ (next (V:=V)) := by
  unfold next control fresh index input dataState; definability
instance controlDef : Language.DefinableFunction₁ ℒₒᵣ (control (V:=V)) := by unfold control index input; definability
instance observedDef : Language.DefinablePred ℒₒᵣ (observed (V:=V)) := by unfold observed input dataState cache; definability

@[simp] theorem control_fresh (k r e : V) : control (fresh k r e)=⟪k,r⟫ := by simp [control,fresh,index,input]
@[simp] theorem advance_control (a : V) : control (next a)=cursor (control a) := by simp [next]

theorem projection (a : V) : ∀ t : V, control (iterate next t a)=iterate cursor t (control a) := by
  apply modelInduct
  · definability
  · simp
  · intro t ih; rw [iterate_succ,iterate_succ,advance_control,ih]

theorem encoded_step (cmd w t k e : V) : next (fresh k (encode (cons cmd w) t) e) =
    fresh k (encode w t) (exec cmd e) := by
  simp only [next,control_fresh,cursor_at_command,pi₁_pair,pi₂_pair]
  unfold input dataState fresh
  simp [rawAction_assemble]

/-- The blind scanner runs the whole prescribed prefix. The actual machine stops at the first goal it observes. -/
theorem executes_prefix (w : V) : ∀ t k e,
    iterate next (length w) (fresh k (encode w t) e) = fresh k t (run exec w e) := by
  induction w using wordInduct with
  | dp => unfold fresh; definability
  | z => simp
  | s c w ih =>
    intro t k e
    rw [length_cons,iterate_succ_left,encoded_step,ih,run_cons]

theorem encode_append (w : V) : ∀ v t, encode (append w v) t=encode w (encode v t) := by
  induction w using wordInduct with
  | dp => definability
  | z => simp
  | s c w ih => intro v t; simp [ih]

theorem pool_hits {p : V} (hp : p=3) (ob : Obtainable p) (start e : V) :
    ∃ t : V, observed (iterate next t (fresh start (cantor 0 start) e)) := by
  subst p
  obtain ⟨w,hw⟩ := ob
  let pref := append w (NF181PA.Commands.singleton swap)
  let last := NF181PA.Commands.singleton (nip:V)
  let q := encode (append pref last) (start+1)
  obtain ⟨j,k,hj⟩ := candidate_for_word (append pref last) start
  let a := iterate next j (fresh start (cantor 0 start) e)
  have hctl : NF181PA.Scanner.control a=⟪k,q⟫ := by simpa [a,projection] using hj
  have hk : index a=k := by simpa [NF181PA.Scanner.control] using congrArg pi₁ hctl
  have hi : input a=q := by simpa [NF181PA.Scanner.control] using congrArg pi₂ hctl
  have ae : a=fresh k q (dataState a) := by
    have shape : a=fresh (index a) (input a) (dataState a) := by simp [fresh,index,input,dataState]
    exact shape.trans (by rw [hk,hi])
  have qs : q=encode pref (encode last (start+1)) := encode_append .. 
  let z:=dataState a
  have eta := state_eta z
  obtain ⟨c,hc⟩ := hw (top z) (stack z) (cache z) (param z)
  rw [eta] at hc
  have ru : run exec pref z=state c (cantor (top z) (stack z)) 3 0 := by
    simp [pref,run_append,hc]
  refine ⟨j+length pref,?_⟩
  rw [iterate_add]
  change observed (iterate next (length pref) a)
  rw [ae]
  change observed (iterate next (length pref) (fresh k q z))
  rw [show fresh k q z=fresh k (encode pref (encode last (start+1))) z from congrArg (fun x=>fresh k x z) qs,executes_prefix,ru]
  simp [observed,input,dataState,fresh,last,NF181PA.Commands.singleton,assemble,nip,cmdMP,state,cache,chooseZero]


/-- An internally ranked refutation forces a tag-zero goal observation by the
unbounded raw candidate scanner, from every initial candidate and proof state.
Both quantifiers range over the ambient PA model. -/
theorem pool_forces_observation (h : NF181PA.Pool.Pr (∅ : V) goal) (start e : V) :
    ∃ t : V, observed (iterate next t (fresh start (cantor 0 start) e)) :=
  pool_hits goal_three (proof_produces h) start e


end NF181PA.Scanner
#print axioms NF181PA.Scanner.pool_forces_observation
