import NF181PARegisterHalting
import NF182PACountermodel
import NF181PATapeCompiler
import M6PA.Calibration.Foundation
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.FirstOrder.Arithmetic.Bootstrapping
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
namespace NF181PA

/-- The only finite premise is the coverage computation for the 181-state table. -/
theorem internal_consistency_of_coverage (cover : Symbolic.Coverage 0 2971) :
    M6.PA.theory ⊢ (∼H181) 🡒 M6.PA.consistencySentence := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff,LogicalConnective.HomClass.map_imply,LogicalConnective.HomClass.map_neg]
  intro nh
  have no : ¬Pool.Pr (∅ : V) goal :=
    fun p => nh (Symbolic.tape_of_coverage cover (refutation_reaches_register_halt p))
  have hc : M6.PA.theory.Consistent V := by
    intro h
    exact NF182PA.Pool.no_refutation_implies_pa_consistency no (by simpa only [Sentence.quote_falsum] using h)
  simpa [M6.PA.consistencySentence,ProvabilityAbstraction.Provability.con,
    ProvabilityAbstraction.Provability.pr,Theory.Consistent] using hc
end NF181PA
#print axioms NF181PA.internal_consistency_of_coverage
