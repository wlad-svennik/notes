module
public import Src181Chart
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem Reach.endAt {a b c : V} (h : Reach a b) (e : b=c) : Reach a c := e ▸ h

theorem vectorEq (pc f : V) {a0 a1 a2 a3 a4 a5 a6 a7 a8 b0 b1 b2 b3 b4 b5 b6 b7 b8 : V}
    (h0:a0=b0) (h1:a1=b1) (h2:a2=b2) (h3:a3=b3) (h4:a4=b4) (h5:a5=b5) (h6:a6=b6) (h7:a7=b7) (h8:a8=b8) :
    config pc f (vector a0 a1 a2 a3 a4 a5 a6 a7 a8)=config pc f (vector b0 b1 b2 b3 b4 b5 b6 b7 b8) := by
  subst_vars; rfl

noncomputable def atom0 (n t s c u v y d w : V) : V := cantor d w
noncomputable def atom1 (n t s c u v y d w : V) : V := cantor y (atom0 n t s c u v y d w)
noncomputable def atom2 (n t s c u v y d w : V) : V := cantor t s
noncomputable def atom94 (n t s c u v y d w : V) : V := cantor t u
noncomputable def atom95 (n t s c u v y d w : V) : V := left s
noncomputable def atom96 (n t s c u v y d w : V) : V := right s
end PA192.ModelSearch.Register181.Commands
