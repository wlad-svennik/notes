import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1728_0 : checkWitness 1728 false false 8830 = true := by decide +kernel
private theorem w1728_2 : checkWitness 1728 true false 8826 = true := by decide +kernel
private theorem cases1728 : checkFour 1728 (8830,0,8826,0) = true := by
  simp only [checkFour, w1728_0, w1728_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1728 : Coverage 1728 1729 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1728)
private theorem w1729_0 : checkWitness 1729 false false 82 = true := by decide +kernel
private theorem w1729_2 : checkWitness 1729 true false 82 = true := by decide +kernel
private theorem cases1729 : checkFour 1729 (82,0,82,0) = true := by
  simp only [checkFour, w1729_0, w1729_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1729 : Coverage 1729 1730 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1729)
private theorem w1730_0 : checkWitness 1730 false false 524 = true := by decide +kernel
private theorem w1730_1 : checkWitness 1730 false true 4620 = true := by decide +kernel
private theorem w1730_2 : checkWitness 1730 true false 524 = true := by decide +kernel
private theorem w1730_3 : checkWitness 1730 true true 4620 = true := by decide +kernel
private theorem cases1730 : checkFour 1730 (524,4620,524,4620) = true := by
  simp only [checkFour, w1730_0, w1730_1, w1730_2, w1730_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1730 : Coverage 1730 1731 := checkList_sound (ws:=[(524,4620,524,4620)]) (by simpa only [checkList, Bool.and_true] using cases1730)
private theorem w1731_0 : checkWitness 1731 false false 8865 = true := by decide +kernel
private theorem w1731_2 : checkWitness 1731 true false 8861 = true := by decide +kernel
private theorem cases1731 : checkFour 1731 (8865,0,8861,0) = true := by
  simp only [checkFour, w1731_0, w1731_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1731 : Coverage 1731 1732 := checkList_sound (ws:=[(8865,0,8861,0)]) (by simpa only [checkList, Bool.and_true] using cases1731)
private theorem w1732_0 : checkWitness 1732 false false 8900 = true := by decide +kernel
private theorem w1732_2 : checkWitness 1732 true false 8891 = true := by decide +kernel
private theorem cases1732 : checkFour 1732 (8900,0,8891,0) = true := by
  simp only [checkFour, w1732_0, w1732_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1732 : Coverage 1732 1733 := checkList_sound (ws:=[(8900,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1732)
private theorem w1733_0 : checkWitness 1733 false false 100 = true := by decide +kernel
private theorem w1733_2 : checkWitness 1733 true false 100 = true := by decide +kernel
private theorem cases1733 : checkFour 1733 (100,0,100,0) = true := by
  simp only [checkFour, w1733_0, w1733_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1733 : Coverage 1733 1734 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1733)
private theorem w1734_0 : checkWitness 1734 false false 612 = true := by decide +kernel
private theorem w1734_1 : checkWitness 1734 false true 4704 = true := by decide +kernel
private theorem w1734_2 : checkWitness 1734 true false 603 = true := by decide +kernel
private theorem w1734_3 : checkWitness 1734 true true 4695 = true := by decide +kernel
private theorem cases1734 : checkFour 1734 (612,4704,603,4695) = true := by
  simp only [checkFour, w1734_0, w1734_1, w1734_2, w1734_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1734 : Coverage 1734 1735 := checkList_sound (ws:=[(612,4704,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases1734)
private theorem w1735_0 : checkWitness 1735 false false 8861 = true := by decide +kernel
private theorem w1735_2 : checkWitness 1735 true false 8857 = true := by decide +kernel
private theorem cases1735 : checkFour 1735 (8861,0,8857,0) = true := by
  simp only [checkFour, w1735_0, w1735_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1735 : Coverage 1735 1736 := checkList_sound (ws:=[(8861,0,8857,0)]) (by simpa only [checkList, Bool.and_true] using cases1735)
private theorem w1736_0 : checkWitness 1736 false false 606 = true := by decide +kernel
private theorem w1736_1 : checkWitness 1736 false true 4698 = true := by decide +kernel
private theorem w1736_2 : checkWitness 1736 true false 597 = true := by decide +kernel
private theorem w1736_3 : checkWitness 1736 true true 4689 = true := by decide +kernel
private theorem cases1736 : checkFour 1736 (606,4698,597,4689) = true := by
  simp only [checkFour, w1736_0, w1736_1, w1736_2, w1736_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1736 : Coverage 1736 1737 := checkList_sound (ws:=[(606,4698,597,4689)]) (by simpa only [checkList, Bool.and_true] using cases1736)
private theorem w1737_0 : checkWitness 1737 false false 8830 = true := by decide +kernel
private theorem w1737_2 : checkWitness 1737 true false 8826 = true := by decide +kernel
private theorem cases1737 : checkFour 1737 (8830,0,8826,0) = true := by
  simp only [checkFour, w1737_0, w1737_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1737 : Coverage 1737 1738 := checkList_sound (ws:=[(8830,0,8826,0)]) (by simpa only [checkList, Bool.and_true] using cases1737)
private theorem w1738_0 : checkWitness 1738 false false 88 = true := by decide +kernel
private theorem w1738_2 : checkWitness 1738 true false 88 = true := by decide +kernel
private theorem cases1738 : checkFour 1738 (88,0,88,0) = true := by
  simp only [checkFour, w1738_0, w1738_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1738 : Coverage 1738 1739 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1738)
private theorem w1739_0 : checkWitness 1739 false false 80 = true := by decide +kernel
private theorem w1739_2 : checkWitness 1739 true false 80 = true := by decide +kernel
private theorem cases1739 : checkFour 1739 (80,0,80,0) = true := by
  simp only [checkFour, w1739_0, w1739_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1739 : Coverage 1739 1740 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1739)
private theorem w1740_0 : checkWitness 1740 false false 573 = true := by decide +kernel
private theorem w1740_1 : checkWitness 1740 false true 4661 = true := by decide +kernel
private theorem w1740_2 : checkWitness 1740 true false 573 = true := by decide +kernel
private theorem w1740_3 : checkWitness 1740 true true 4661 = true := by decide +kernel
private theorem cases1740 : checkFour 1740 (573,4661,573,4661) = true := by
  simp only [checkFour, w1740_0, w1740_1, w1740_2, w1740_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1740 : Coverage 1740 1741 := checkList_sound (ws:=[(573,4661,573,4661)]) (by simpa only [checkList, Bool.and_true] using cases1740)
private theorem w1741_0 : checkWitness 1741 false false 8846 = true := by decide +kernel
private theorem w1741_2 : checkWitness 1741 true false 8842 = true := by decide +kernel
private theorem cases1741 : checkFour 1741 (8846,0,8842,0) = true := by
  simp only [checkFour, w1741_0, w1741_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1741 : Coverage 1741 1742 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1741)
private theorem w1742_0 : checkWitness 1742 false false 8842 = true := by decide +kernel
private theorem w1742_2 : checkWitness 1742 true false 8838 = true := by decide +kernel
private theorem cases1742 : checkFour 1742 (8842,0,8838,0) = true := by
  simp only [checkFour, w1742_0, w1742_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1742 : Coverage 1742 1743 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1742)
private theorem w1743_0 : checkWitness 1743 false false 94 = true := by decide +kernel
private theorem w1743_2 : checkWitness 1743 true false 94 = true := by decide +kernel
private theorem cases1743 : checkFour 1743 (94,0,94,0) = true := by
  simp only [checkFour, w1743_0, w1743_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1743 : Coverage 1743 1744 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1743)
private theorem w1744_0 : checkWitness 1744 false false 8874 = true := by decide +kernel
private theorem w1744_2 : checkWitness 1744 true false 8870 = true := by decide +kernel
private theorem cases1744 : checkFour 1744 (8874,0,8870,0) = true := by
  simp only [checkFour, w1744_0, w1744_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1744 : Coverage 1744 1745 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases1744)
private theorem w1745_0 : checkWitness 1745 false false 504 = true := by decide +kernel
private theorem w1745_1 : checkWitness 1745 false true 4600 = true := by decide +kernel
private theorem w1745_2 : checkWitness 1745 true false 504 = true := by decide +kernel
private theorem w1745_3 : checkWitness 1745 true true 4600 = true := by decide +kernel
private theorem cases1745 : checkFour 1745 (504,4600,504,4600) = true := by
  simp only [checkFour, w1745_0, w1745_1, w1745_2, w1745_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1745 : Coverage 1745 1746 := checkList_sound (ws:=[(504,4600,504,4600)]) (by simpa only [checkList, Bool.and_true] using cases1745)
private theorem w1746_0 : checkWitness 1746 false false 8936 = true := by decide +kernel
private theorem w1746_2 : checkWitness 1746 true false 8927 = true := by decide +kernel
private theorem cases1746 : checkFour 1746 (8936,0,8927,0) = true := by
  simp only [checkFour, w1746_0, w1746_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1746 : Coverage 1746 1747 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases1746)
private theorem w1747_0 : checkWitness 1747 false false 78 = true := by decide +kernel
private theorem w1747_2 : checkWitness 1747 true false 78 = true := by decide +kernel
private theorem cases1747 : checkFour 1747 (78,0,78,0) = true := by
  simp only [checkFour, w1747_0, w1747_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1747 : Coverage 1747 1748 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1747)
private theorem w1748_0 : checkWitness 1748 false false 518 = true := by decide +kernel
private theorem w1748_1 : checkWitness 1748 false true 4614 = true := by decide +kernel
private theorem w1748_2 : checkWitness 1748 true false 518 = true := by decide +kernel
private theorem w1748_3 : checkWitness 1748 true true 4614 = true := by decide +kernel
private theorem cases1748 : checkFour 1748 (518,4614,518,4614) = true := by
  simp only [checkFour, w1748_0, w1748_1, w1748_2, w1748_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1748 : Coverage 1748 1749 := checkList_sound (ws:=[(518,4614,518,4614)]) (by simpa only [checkList, Bool.and_true] using cases1748)
private theorem w1749_0 : checkWitness 1749 false false 8876 = true := by decide +kernel
private theorem w1749_2 : checkWitness 1749 true false 8872 = true := by decide +kernel
private theorem cases1749 : checkFour 1749 (8876,0,8872,0) = true := by
  simp only [checkFour, w1749_0, w1749_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1749 : Coverage 1749 1750 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases1749)
private theorem w1750_0 : checkWitness 1750 false false 80 = true := by decide +kernel
private theorem w1750_2 : checkWitness 1750 true false 80 = true := by decide +kernel
private theorem cases1750 : checkFour 1750 (80,0,80,0) = true := by
  simp only [checkFour, w1750_0, w1750_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1750 : Coverage 1750 1751 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1750)
private theorem w1751_0 : checkWitness 1751 false false 556 = true := by decide +kernel
private theorem w1751_1 : checkWitness 1751 false true 4652 = true := by decide +kernel
private theorem w1751_2 : checkWitness 1751 true false 556 = true := by decide +kernel
private theorem w1751_3 : checkWitness 1751 true true 4652 = true := by decide +kernel
private theorem cases1751 : checkFour 1751 (556,4652,556,4652) = true := by
  simp only [checkFour, w1751_0, w1751_1, w1751_2, w1751_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1751 : Coverage 1751 1752 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases1751)
private theorem w1752_0 : checkWitness 1752 false false 8897 = true := by decide +kernel
private theorem w1752_2 : checkWitness 1752 true false 8893 = true := by decide +kernel
private theorem cases1752 : checkFour 1752 (8897,0,8893,0) = true := by
  simp only [checkFour, w1752_0, w1752_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1752 : Coverage 1752 1753 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases1752)
private theorem w1753_0 : checkWitness 1753 false false 8932 = true := by decide +kernel
private theorem w1753_2 : checkWitness 1753 true false 8923 = true := by decide +kernel
private theorem cases1753 : checkFour 1753 (8932,0,8923,0) = true := by
  simp only [checkFour, w1753_0, w1753_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1753 : Coverage 1753 1754 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases1753)
private theorem w1754_0 : checkWitness 1754 false false 104 = true := by decide +kernel
private theorem w1754_2 : checkWitness 1754 true false 104 = true := by decide +kernel
private theorem cases1754 : checkFour 1754 (104,0,104,0) = true := by
  simp only [checkFour, w1754_0, w1754_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1754 : Coverage 1754 1755 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases1754)
private theorem w1755_0 : checkWitness 1755 false false 644 = true := by decide +kernel
private theorem w1755_1 : checkWitness 1755 false true 4736 = true := by decide +kernel
private theorem w1755_2 : checkWitness 1755 true false 635 = true := by decide +kernel
private theorem w1755_3 : checkWitness 1755 true true 4727 = true := by decide +kernel
private theorem cases1755 : checkFour 1755 (644,4736,635,4727) = true := by
  simp only [checkFour, w1755_0, w1755_1, w1755_2, w1755_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1755 : Coverage 1755 1756 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases1755)
private theorem w1756_0 : checkWitness 1756 false false 8893 = true := by decide +kernel
private theorem w1756_2 : checkWitness 1756 true false 8889 = true := by decide +kernel
private theorem cases1756 : checkFour 1756 (8893,0,8889,0) = true := by
  simp only [checkFour, w1756_0, w1756_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1756 : Coverage 1756 1757 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1756)
private theorem w1757_0 : checkWitness 1757 false false 638 = true := by decide +kernel
private theorem w1757_1 : checkWitness 1757 false true 4730 = true := by decide +kernel
private theorem w1757_2 : checkWitness 1757 true false 629 = true := by decide +kernel
private theorem w1757_3 : checkWitness 1757 true true 4721 = true := by decide +kernel
private theorem cases1757 : checkFour 1757 (638,4730,629,4721) = true := by
  simp only [checkFour, w1757_0, w1757_1, w1757_2, w1757_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1757 : Coverage 1757 1758 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases1757)
private theorem w1758_0 : checkWitness 1758 false false 8862 = true := by decide +kernel
private theorem w1758_2 : checkWitness 1758 true false 8858 = true := by decide +kernel
private theorem cases1758 : checkFour 1758 (8862,0,8858,0) = true := by
  simp only [checkFour, w1758_0, w1758_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1758 : Coverage 1758 1759 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases1758)
private theorem w1759_0 : checkWitness 1759 false false 92 = true := by decide +kernel
private theorem w1759_2 : checkWitness 1759 true false 92 = true := by decide +kernel
private theorem cases1759 : checkFour 1759 (92,0,92,0) = true := by
  simp only [checkFour, w1759_0, w1759_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1759 : Coverage 1759 1760 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1759)
theorem cover1728 : Coverage 1728 1760 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1728 one1729) (Coverage.join one1730 one1731)) (Coverage.join (Coverage.join one1732 one1733) (Coverage.join one1734 one1735))) (Coverage.join (Coverage.join (Coverage.join one1736 one1737) (Coverage.join one1738 one1739)) (Coverage.join (Coverage.join one1740 one1741) (Coverage.join one1742 one1743)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1744 one1745) (Coverage.join one1746 one1747)) (Coverage.join (Coverage.join one1748 one1749) (Coverage.join one1750 one1751))) (Coverage.join (Coverage.join (Coverage.join one1752 one1753) (Coverage.join one1754 one1755)) (Coverage.join (Coverage.join one1756 one1757) (Coverage.join one1758 one1759)))))
end NF181PA.Symbolic
