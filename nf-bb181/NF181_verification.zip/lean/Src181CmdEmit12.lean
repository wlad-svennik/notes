module
public import Src181CmdEmit11
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter385 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1874:Nat):V) f (vector n ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1870 f n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom62 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom62 n t s c u v y d w))):V)=((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom62 n t s c u v y d w))):V)=(0+((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter384 f n t s c u v y d w).trans mid

theorem commandEmitAfter386 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1877:Nat):V) f (vector n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) 0 w)) := by
  have micro := site1874 f n ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w))):V)=((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter385 f n t s c u v y d w).trans mid

theorem commandEmitAfter387 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1880:Nat):V) f (vector n (emitAtom55 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) 0 w)) := by
  have micro := site1877 f n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) 0 w
  have d1 : ((0+(emitAtom55 n t s c u v y d w)):V)=(emitAtom55 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter386 f n t s c u v y d w).trans mid

theorem commandEmitAfter388 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1890:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom63 n t s c u v y d w) w)) := by
  have micro := site1880 f n (emitAtom55 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) (emitAtom55 n t s c u v y d w))):V)=(emitAtom63 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) (emitAtom55 n t s c u v y d w))):V)=(0+(emitAtom63 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter387 f n t s c u v y d w).trans mid

theorem commandEmitAfter389 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1893:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1890 f n 0 0 c (d+u) (v+y) 0 (emitAtom63 n t s c u v y d w) w
  have d2 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter388 f n t s c u v y d w).trans mid

theorem commandEmitAfter390 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1896:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1893 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+0):V)=0 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter389 f n t s c u v y d w).trans mid

theorem commandEmitAfter391 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1899:Nat):V) f (vector n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w)) := by
  have micro := site1896 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter390 f n t s c u v y d w).trans mid

theorem commandEmitAfter392 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1909:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom64 n t s c u v y d w) w)) := by
  have micro := site1899 f n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w
  have d7 : ((0+(cantor 0 (emitAtom63 n t s c u v y d w))):V)=(emitAtom64 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor 0 (emitAtom63 n t s c u v y d w))):V)=(0+(emitAtom64 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter391 f n t s c u v y d w).trans mid

theorem commandEmitAfter393 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1912:Nat):V) f (vector n 0 (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1909 f n 0 0 c (d+u) (v+y) 0 (emitAtom64 n t s c u v y d w) w
  have d2 : ((0+(emitAtom64 n t s c u v y d w)):V)=(emitAtom64 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter392 f n t s c u v y d w).trans mid

theorem commandEmitAfter394 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1916:Nat):V) f (vector n (v+y) (emitAtom64 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1912 f n 0 (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter393 f n t s c u v y d w).trans mid

theorem commandEmitAfter395 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1919:Nat):V) f (vector n (v+y) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1916 f n (v+y) (emitAtom64 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter394 f n t s c u v y d w).trans mid

theorem commandEmitAfter396 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1922:Nat):V) f (vector n 0 (emitAtom64 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1919 f n (v+y) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter395 f n t s c u v y d w).trans mid

theorem commandEmitAfter397 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1925:Nat):V) f (vector n (emitAtom64 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1922 f n 0 (emitAtom64 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d1 : ((0+(emitAtom64 n t s c u v y d w)):V)=(emitAtom64 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter396 f n t s c u v y d w).trans mid

theorem commandEmitAfter398 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1935:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom65 n t s c u v y d w) w)) := by
  have micro := site1925 f n (emitAtom64 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (emitAtom64 n t s c u v y d w))):V)=(emitAtom65 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (emitAtom64 n t s c u v y d w))):V)=(0+(emitAtom65 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter397 f n t s c u v y d w).trans mid

theorem commandEmitAfter399 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1938:Nat):V) f (vector n 0 (emitAtom65 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1935 f n 0 0 c (d+u) (v+y) 0 (emitAtom65 n t s c u v y d w) w
  have d2 : ((0+(emitAtom65 n t s c u v y d w)):V)=(emitAtom65 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter398 f n t s c u v y d w).trans mid

theorem commandEmitAfter400 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1942:Nat):V) f (vector n (v+y) (emitAtom65 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1938 f n 0 (emitAtom65 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter399 f n t s c u v y d w).trans mid

theorem commandEmitAfter401 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1945:Nat):V) f (vector n (v+y) (emitAtom65 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1942 f n (v+y) (emitAtom65 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter400 f n t s c u v y d w).trans mid

theorem commandEmitAfter402 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1953:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (v+y) (emitAtom64 n t s c u v y d w) w)) := by
  have micro := site1945 f n (v+y) (emitAtom65 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom65 n t s c u v y d w))):V)=(v+y) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom65 n t s c u v y d w)):V)=(0+(emitAtom65 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom65 n t s c u v y d w))):V)=left (emitAtom65 n t s c u v y d w))).trans (by change left (cantor (v+y) (emitAtom64 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom65 n t s c u v y d w))):V)=(emitAtom64 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom65 n t s c u v y d w)):V)=(0+(emitAtom65 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom65 n t s c u v y d w))):V)=right (emitAtom65 n t s c u v y d w))).trans (by change right (cantor (v+y) (emitAtom64 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter401 f n t s c u v y d w).trans mid

theorem commandEmitAfter403 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1956:Nat):V) f (vector n (v+y) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1953 f n (v+y) 0 c (d+u) (v+y) (v+y) (emitAtom64 n t s c u v y d w) w
  have d2 : ((0+(emitAtom64 n t s c u v y d w)):V)=(emitAtom64 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter402 f n t s c u v y d w).trans mid

theorem commandEmitAfter404 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1966:Nat):V) f (vector n 0 (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom17 n t s c u v y d w) w)) := by
  have micro := site1956 f n (v+y) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (v+y))):V)=(emitAtom17 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (v+y))):V)=(0+(emitAtom17 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter403 f n t s c u v y d w).trans mid

theorem commandEmitAfter405 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1970:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1966 f n 0 (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom17 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom17 n t s c u v y d w))):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom17 n t s c u v y d w))):V)=(0+((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter404 f n t s c u v y d w).trans mid

theorem commandEmitAfter406 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1971:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1970 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w))+1):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter405 f n t s c u v y d w).trans mid

theorem commandEmitAfter407 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1972:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1971 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1)+1):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter406 f n t s c u v y d w).trans mid

theorem commandEmitAfter408 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1980:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) 0 (emitAtom63 n t s c u v y d w) w)) := by
  have micro := site1972 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom64 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom64 n t s c u v y d w))):V)=0 := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom64 n t s c u v y d w)):V)=(0+(emitAtom64 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom64 n t s c u v y d w))):V)=left (emitAtom64 n t s c u v y d w))).trans (by change left (cantor 0 (emitAtom63 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom64 n t s c u v y d w))):V)=(emitAtom63 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom64 n t s c u v y d w)):V)=(0+(emitAtom64 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom64 n t s c u v y d w))):V)=right (emitAtom64 n t s c u v y d w))).trans (by change right (cantor 0 (emitAtom63 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter407 f n t s c u v y d w).trans mid

theorem commandEmitAfter409 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1983:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1980 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) 0 (emitAtom63 n t s c u v y d w) w
  have d2 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter408 f n t s c u v y d w).trans mid

theorem commandEmitAfter410 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1993:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom66 n t s c u v y d w) w)) := by
  have micro := site1983 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d7 : ((0+(cantor 0 ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2))):V)=(emitAtom66 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor 0 ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2))):V)=(0+(emitAtom66 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter409 f n t s c u v y d w).trans mid

theorem commandEmitAfter411 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1997:Nat):V) f (vector n ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1993 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom66 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom66 n t s c u v y d w))):V)=((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom66 n t s c u v y d w))):V)=(0+((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter410 f n t s c u v y d w).trans mid

theorem commandEmitAfter412 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1998:Nat):V) f (vector n ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1997 f n ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w))+1):V)=((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter411 f n t s c u v y d w).trans mid

theorem commandEmitAfter413 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2001:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1998 f n ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1)):V)=((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter412 f n t s c u v y d w).trans mid

theorem commandEmitAfter414 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2004:Nat):V) f (vector n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2001 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter413 f n t s c u v y d w).trans mid

theorem commandEmitAfter415 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2014:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom67 n t s c u v y d w) w)) := by
  have micro := site2004 f n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w))):V)=(emitAtom67 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w))):V)=(0+(emitAtom67 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter414 f n t s c u v y d w).trans mid

theorem commandEmitAfter416 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2017:Nat):V) f (vector n 0 (emitAtom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2014 f n 0 0 c (d+u) (v+y) 0 (emitAtom67 n t s c u v y d w) w
  have d2 : ((0+(emitAtom67 n t s c u v y d w)):V)=(emitAtom67 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter415 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
