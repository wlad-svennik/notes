module
public import Src181CmdEmit00
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter33 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((199:Nat):V) f (vector n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) 0 w)) := by
  have micro := site0196 f n ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w))):V)=((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter32 f n t s c u v y d w).trans mid

theorem commandEmitAfter34 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((202:Nat):V) f (vector n (emitAtom2 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) 0 w)) := by
  have micro := site0199 f n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) 0 w
  have d1 : ((0+(emitAtom2 n t s c u v y d w)):V)=(emitAtom2 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter33 f n t s c u v y d w).trans mid

theorem commandEmitAfter35 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((212:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom7 n t s c u v y d w) w)) := by
  have micro := site0202 f n (emitAtom2 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) (emitAtom2 n t s c u v y d w))):V)=(emitAtom7 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) (emitAtom2 n t s c u v y d w))):V)=(0+(emitAtom7 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter34 f n t s c u v y d w).trans mid

theorem commandEmitAfter36 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((215:Nat):V) f (vector n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0212 f n 0 0 c (d+u) (v+y) 0 (emitAtom7 n t s c u v y d w) w
  have d2 : ((0+(emitAtom7 n t s c u v y d w)):V)=(emitAtom7 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter35 f n t s c u v y d w).trans mid

theorem commandEmitAfter37 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((219:Nat):V) f (vector n (d+u) (emitAtom7 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0215 f n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter36 f n t s c u v y d w).trans mid

theorem commandEmitAfter38 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((222:Nat):V) f (vector n (d+u) (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0219 f n (d+u) (emitAtom7 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter37 f n t s c u v y d w).trans mid

theorem commandEmitAfter39 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((225:Nat):V) f (vector n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0222 f n (d+u) (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter38 f n t s c u v y d w).trans mid

theorem commandEmitAfter40 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((228:Nat):V) f (vector n (emitAtom7 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0225 f n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom7 n t s c u v y d w)):V)=(emitAtom7 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter39 f n t s c u v y d w).trans mid

theorem commandEmitAfter41 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((238:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom8 n t s c u v y d w) w)) := by
  have micro := site0228 f n (emitAtom7 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom7 n t s c u v y d w))):V)=(emitAtom8 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom7 n t s c u v y d w))):V)=(0+(emitAtom8 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter40 f n t s c u v y d w).trans mid

theorem commandEmitAfter42 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((241:Nat):V) f (vector n 0 (emitAtom8 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0238 f n 0 0 c (d+u) (v+y) 0 (emitAtom8 n t s c u v y d w) w
  have d2 : ((0+(emitAtom8 n t s c u v y d w)):V)=(emitAtom8 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter41 f n t s c u v y d w).trans mid

theorem commandEmitAfter43 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((245:Nat):V) f (vector n c (emitAtom8 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site0241 f n 0 (emitAtom8 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter42 f n t s c u v y d w).trans mid

theorem commandEmitAfter44 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((248:Nat):V) f (vector n c (emitAtom8 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0245 f n c (emitAtom8 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter43 f n t s c u v y d w).trans mid

theorem commandEmitAfter45 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((256:Nat):V) f (vector n c 0 c (d+u) (v+y) (d+u) (emitAtom7 n t s c u v y d w) w)) := by
  have micro := site0248 f n c (emitAtom8 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom8 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom8 n t s c u v y d w)):V)=(0+(emitAtom8 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom8 n t s c u v y d w))):V)=left (emitAtom8 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom7 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom8 n t s c u v y d w))):V)=(emitAtom7 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom8 n t s c u v y d w)):V)=(0+(emitAtom8 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom8 n t s c u v y d w))):V)=right (emitAtom8 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom7 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter44 f n t s c u v y d w).trans mid

theorem commandEmitAfter46 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((259:Nat):V) f (vector n c (emitAtom7 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0256 f n c 0 c (d+u) (v+y) (d+u) (emitAtom7 n t s c u v y d w) w
  have d2 : ((0+(emitAtom7 n t s c u v y d w)):V)=(emitAtom7 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter45 f n t s c u v y d w).trans mid

theorem commandEmitAfter47 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((269:Nat):V) f (vector n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom9 n t s c u v y d w) w)) := by
  have micro := site0259 f n c (emitAtom7 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) c)):V)=(emitAtom9 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) c)):V)=(0+(emitAtom9 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter46 f n t s c u v y d w).trans mid

theorem commandEmitAfter48 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((273:Nat):V) f (vector n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0269 f n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom9 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom9 n t s c u v y d w))):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom9 n t s c u v y d w))):V)=(0+((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter47 f n t s c u v y d w).trans mid

theorem commandEmitAfter49 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((276:Nat):V) f (vector n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) 0 w)) := by
  have micro := site0273 f n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w))):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter48 f n t s c u v y d w).trans mid

theorem commandEmitAfter50 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((279:Nat):V) f (vector n (emitAtom7 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) 0 w)) := by
  have micro := site0276 f n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) 0 w
  have d1 : ((0+(emitAtom7 n t s c u v y d w)):V)=(emitAtom7 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter49 f n t s c u v y d w).trans mid

theorem commandEmitAfter51 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((289:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom10 n t s c u v y d w) w)) := by
  have micro := site0279 f n (emitAtom7 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom7 n t s c u v y d w))):V)=(emitAtom10 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom7 n t s c u v y d w))):V)=(0+(emitAtom10 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter50 f n t s c u v y d w).trans mid

theorem commandEmitAfter52 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((292:Nat):V) f (vector n 0 (emitAtom10 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0289 f n 0 0 c (d+u) (v+y) 0 (emitAtom10 n t s c u v y d w) w
  have d2 : ((0+(emitAtom10 n t s c u v y d w)):V)=(emitAtom10 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter51 f n t s c u v y d w).trans mid

theorem commandEmitAfter53 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((296:Nat):V) f (vector n (v+y) (emitAtom10 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0292 f n 0 (emitAtom10 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter52 f n t s c u v y d w).trans mid

theorem commandEmitAfter54 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((299:Nat):V) f (vector n (v+y) (emitAtom10 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0296 f n (v+y) (emitAtom10 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter53 f n t s c u v y d w).trans mid

theorem commandEmitAfter55 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((302:Nat):V) f (vector n 0 (emitAtom10 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site0299 f n (v+y) (emitAtom10 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter54 f n t s c u v y d w).trans mid

theorem commandEmitAfter56 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((305:Nat):V) f (vector n (emitAtom10 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site0302 f n 0 (emitAtom10 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d1 : ((0+(emitAtom10 n t s c u v y d w)):V)=(emitAtom10 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter55 f n t s c u v y d w).trans mid

theorem commandEmitAfter57 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((315:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom11 n t s c u v y d w) w)) := by
  have micro := site0305 f n (emitAtom10 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (emitAtom10 n t s c u v y d w))):V)=(emitAtom11 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (emitAtom10 n t s c u v y d w))):V)=(0+(emitAtom11 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter56 f n t s c u v y d w).trans mid

theorem commandEmitAfter58 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((318:Nat):V) f (vector n 0 (emitAtom11 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0315 f n 0 0 c (d+u) (v+y) 0 (emitAtom11 n t s c u v y d w) w
  have d2 : ((0+(emitAtom11 n t s c u v y d w)):V)=(emitAtom11 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter57 f n t s c u v y d w).trans mid

theorem commandEmitAfter59 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((322:Nat):V) f (vector n c (emitAtom11 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site0318 f n 0 (emitAtom11 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter58 f n t s c u v y d w).trans mid

theorem commandEmitAfter60 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((325:Nat):V) f (vector n c (emitAtom11 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0322 f n c (emitAtom11 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter59 f n t s c u v y d w).trans mid

theorem commandEmitAfter61 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((333:Nat):V) f (vector n c 0 c (d+u) (v+y) (v+y) (emitAtom10 n t s c u v y d w) w)) := by
  have micro := site0325 f n c (emitAtom11 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom11 n t s c u v y d w))):V)=(v+y) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom11 n t s c u v y d w)):V)=(0+(emitAtom11 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom11 n t s c u v y d w))):V)=left (emitAtom11 n t s c u v y d w))).trans (by change left (cantor (v+y) (emitAtom10 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom11 n t s c u v y d w))):V)=(emitAtom10 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom11 n t s c u v y d w)):V)=(0+(emitAtom11 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom11 n t s c u v y d w))):V)=right (emitAtom11 n t s c u v y d w))).trans (by change right (cantor (v+y) (emitAtom10 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter60 f n t s c u v y d w).trans mid

theorem commandEmitAfter62 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((336:Nat):V) f (vector n c (emitAtom10 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site0333 f n c 0 c (d+u) (v+y) (v+y) (emitAtom10 n t s c u v y d w) w
  have d2 : ((0+(emitAtom10 n t s c u v y d w)):V)=(emitAtom10 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter61 f n t s c u v y d w).trans mid

theorem commandEmitAfter63 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((346:Nat):V) f (vector n 0 (emitAtom10 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom12 n t s c u v y d w) w)) := by
  have micro := site0336 f n c (emitAtom10 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) c)):V)=(emitAtom12 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) c)):V)=(0+(emitAtom12 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter62 f n t s c u v y d w).trans mid

theorem commandEmitAfter64 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((350:Nat):V) f (vector n ((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w)) (emitAtom10 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0346 f n 0 (emitAtom10 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom12 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom12 n t s c u v y d w))):V)=((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom12 n t s c u v y d w))):V)=(0+((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter63 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
