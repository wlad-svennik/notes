import NF181PATapeFinite

namespace NF181PA.Symbolic
/-- One witness integer stores the number of symbolic operations and
the two single-cell changes in header gap and spare count. -/
def checkWitness (pc : Nat) (c p : Bool) (w : Nat) : Bool :=
  checkRow pc c p (w%4096) (w/4096%2) (w/8192%2)

def admissible (pc : Nat) (c p : Bool) : Bool :=
  match Direct181Source.Raw.program pc with
  | .inr (.inl (r,_,_,_)) => !(c && r==0)
  | _ => !p

def checkFour (pc : Nat) (w : Nat × Nat × Nat × Nat) : Bool :=
  let (a,b,c,d) := w
  (!admissible pc false false || checkWitness pc false false a) &&
  (!admissible pc false true  || checkWitness pc false true  b) &&
  (!admissible pc true  false || checkWitness pc true  false c) &&
  (!admissible pc true  true  || checkWitness pc true  true  d)

def checkList : Nat → List (Nat × Nat × Nat × Nat) → Bool
  | _,[] => true
  | pc,w::rest => checkFour pc w && checkList (pc+1) rest

def Coverage (lo hi : Nat) : Prop :=
  ∀ pc, lo ≤ pc → pc < hi → ∀ c p : Bool, admissible pc c p = true →
    ∃ w : Nat, checkWitness pc c p w = true

theorem checkFour_sound {pc : Nat} {w : Nat × Nat × Nat × Nat} (h : checkFour pc w = true) :
    ∀ c p, admissible pc c p = true → ∃ x, checkWitness pc c p x = true := by
  rcases w with ⟨w0,w1,w2,w3⟩
  simp only [checkFour,Bool.and_eq_true] at h
  intro c p enabled
  cases c <;> cases p
  · exact ⟨w0,by simpa [enabled] using h.1.1.1⟩
  · exact ⟨w1,by simpa [enabled] using h.1.1.2⟩
  · exact ⟨w2,by simpa [enabled] using h.1.2⟩
  · exact ⟨w3,by simpa [enabled] using h.2⟩

theorem checkList_sound {lo : Nat} {ws : List (Nat × Nat × Nat × Nat)} (h : checkList lo ws = true) :
    Coverage lo (lo+ws.length) := by
  induction ws generalizing lo with
  | nil => intro i a b; simp at b; omega
  | cons w rest ih =>
    simp only [checkList,Bool.and_eq_true] at h
    intro i a b
    by_cases e : i=lo
    · subst i; exact checkFour_sound h.1
    · have b' : i < lo+1+rest.length := by simp only [List.length_cons] at b; omega
      exact ih h.2 i (by omega) b'

theorem Coverage.join {a b c : Nat} (x : Coverage a b) (y : Coverage b c) : Coverage a c := by
  intro i lo hi
  by_cases h : i < b
  · exact x i lo h
  · exact y i (by omega) hi
#print axioms checkList_sound
#print axioms Coverage.join
end NF181PA.Symbolic
