module
public import Src181CmdEmit12
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter417 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2021:Nat):V) f (vector n (d+u) (emitAtom67 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2017 f n 0 (emitAtom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter416 f n t s c u v y d w).trans mid

theorem commandEmitAfter418 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2024:Nat):V) f (vector n (d+u) (emitAtom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2021 f n (d+u) (emitAtom67 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter417 f n t s c u v y d w).trans mid

theorem commandEmitAfter419 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2032:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) w)) := by
  have micro := site2024 f n (d+u) (emitAtom67 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom67 n t s c u v y d w))):V)=((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom67 n t s c u v y d w)):V)=(0+(emitAtom67 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom67 n t s c u v y d w))):V)=left (emitAtom67 n t s c u v y d w))).trans (by change left (cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom67 n t s c u v y d w))):V)=(emitAtom63 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom67 n t s c u v y d w)):V)=(0+(emitAtom67 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom67 n t s c u v y d w))):V)=right (emitAtom67 n t s c u v y d w))).trans (by change right (cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter418 f n t s c u v y d w).trans mid

theorem commandEmitAfter420 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2035:Nat):V) f (vector n (d+u) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2032 f n (d+u) 0 c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) w
  have d2 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter419 f n t s c u v y d w).trans mid

theorem commandEmitAfter421 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2045:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom68 n t s c u v y d w) w)) := by
  have micro := site2035 f n (d+u) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (d+u))):V)=(emitAtom68 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (d+u))):V)=(0+(emitAtom68 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter420 f n t s c u v y d w).trans mid

theorem commandEmitAfter422 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2049:Nat):V) f (vector n ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2045 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom68 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom68 n t s c u v y d w))):V)=((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom68 n t s c u v y d w))):V)=(0+((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter421 f n t s c u v y d w).trans mid

theorem commandEmitAfter423 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2050:Nat):V) f (vector n ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2049 f n ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w))+1):V)=((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter422 f n t s c u v y d w).trans mid

theorem commandEmitAfter424 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2053:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2050 f n ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1)):V)=((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter423 f n t s c u v y d w).trans mid

theorem commandEmitAfter425 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2056:Nat):V) f (vector n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2053 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter424 f n t s c u v y d w).trans mid

theorem commandEmitAfter426 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2066:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom69 n t s c u v y d w) w)) := by
  have micro := site2056 f n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w))):V)=(emitAtom69 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w))):V)=(0+(emitAtom69 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter425 f n t s c u v y d w).trans mid

theorem commandEmitAfter427 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2069:Nat):V) f (vector n 0 (emitAtom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2066 f n 0 0 c (d+u) (v+y) 0 (emitAtom69 n t s c u v y d w) w
  have d2 : ((0+(emitAtom69 n t s c u v y d w)):V)=(emitAtom69 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter426 f n t s c u v y d w).trans mid

theorem commandEmitAfter428 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2073:Nat):V) f (vector n (v+y) (emitAtom69 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2069 f n 0 (emitAtom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter427 f n t s c u v y d w).trans mid

theorem commandEmitAfter429 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2076:Nat):V) f (vector n (v+y) (emitAtom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2073 f n (v+y) (emitAtom69 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter428 f n t s c u v y d w).trans mid

theorem commandEmitAfter430 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2084:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) w)) := by
  have micro := site2076 f n (v+y) (emitAtom69 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom69 n t s c u v y d w))):V)=((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom69 n t s c u v y d w)):V)=(0+(emitAtom69 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom69 n t s c u v y d w))):V)=left (emitAtom69 n t s c u v y d w))).trans (by change left (cantor ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom69 n t s c u v y d w))):V)=(emitAtom63 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom69 n t s c u v y d w)):V)=(0+(emitAtom69 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom69 n t s c u v y d w))):V)=right (emitAtom69 n t s c u v y d w))).trans (by change right (cantor ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter429 f n t s c u v y d w).trans mid

theorem commandEmitAfter431 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2087:Nat):V) f (vector n (v+y) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2084 f n (v+y) 0 c (d+u) (v+y) ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) w
  have d2 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter430 f n t s c u v y d w).trans mid

theorem commandEmitAfter432 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2097:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom70 n t s c u v y d w) w)) := by
  have micro := site2087 f n (v+y) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (v+y))):V)=(emitAtom70 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (v+y))):V)=(0+(emitAtom70 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter431 f n t s c u v y d w).trans mid

theorem commandEmitAfter433 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2101:Nat):V) f (vector n ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2097 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom70 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom70 n t s c u v y d w))):V)=((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom70 n t s c u v y d w))):V)=(0+((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter432 f n t s c u v y d w).trans mid

theorem commandEmitAfter434 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2102:Nat):V) f (vector n ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2101 f n ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w))+1):V)=((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter433 f n t s c u v y d w).trans mid

theorem commandEmitAfter435 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2105:Nat):V) f (vector n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2102 f n ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1)):V)=((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter434 f n t s c u v y d w).trans mid

theorem commandEmitAfter436 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2108:Nat):V) f (vector n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2105 f n 0 (emitAtom63 n t s c u v y d w) c (d+u) (v+y) ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom63 n t s c u v y d w)):V)=(emitAtom63 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter435 f n t s c u v y d w).trans mid

theorem commandEmitAfter437 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2118:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom71 n t s c u v y d w) w)) := by
  have micro := site2108 f n (emitAtom63 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w))):V)=(emitAtom71 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w))):V)=(0+(emitAtom71 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter436 f n t s c u v y d w).trans mid

theorem commandEmitAfter438 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2121:Nat):V) f (vector n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2118 f n 0 0 c (d+u) (v+y) 0 (emitAtom71 n t s c u v y d w) w
  have d2 : ((0+(emitAtom71 n t s c u v y d w)):V)=(emitAtom71 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter437 f n t s c u v y d w).trans mid

theorem commandEmitAfter439 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2124:Nat):V) f (vector n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2121 f n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+0):V)=0 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter438 f n t s c u v y d w).trans mid

theorem commandEmitAfter440 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2127:Nat):V) f (vector n (emitAtom71 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w)) := by
  have micro := site2124 f n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(emitAtom71 n t s c u v y d w)):V)=(emitAtom71 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter439 f n t s c u v y d w).trans mid

theorem commandEmitAfter441 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2137:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom72 n t s c u v y d w) w)) := by
  have micro := site2127 f n (emitAtom71 n t s c u v y d w) 0 c (d+u) (v+y) 0 0 w
  have d7 : ((0+(cantor 0 (emitAtom71 n t s c u v y d w))):V)=(emitAtom72 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor 0 (emitAtom71 n t s c u v y d w))):V)=(0+(emitAtom72 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter440 f n t s c u v y d w).trans mid

theorem commandEmitAfter442 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2140:Nat):V) f (vector n 0 (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2137 f n 0 0 c (d+u) (v+y) 0 (emitAtom72 n t s c u v y d w) w
  have d2 : ((0+(emitAtom72 n t s c u v y d w)):V)=(emitAtom72 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter441 f n t s c u v y d w).trans mid

theorem commandEmitAfter443 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2144:Nat):V) f (vector n (v+y) (emitAtom72 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2140 f n 0 (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter442 f n t s c u v y d w).trans mid

theorem commandEmitAfter444 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2147:Nat):V) f (vector n (v+y) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2144 f n (v+y) (emitAtom72 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter443 f n t s c u v y d w).trans mid

theorem commandEmitAfter445 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2150:Nat):V) f (vector n 0 (emitAtom72 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site2147 f n (v+y) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter444 f n t s c u v y d w).trans mid

theorem commandEmitAfter446 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2153:Nat):V) f (vector n (emitAtom72 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site2150 f n 0 (emitAtom72 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d1 : ((0+(emitAtom72 n t s c u v y d w)):V)=(emitAtom72 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter445 f n t s c u v y d w).trans mid

theorem commandEmitAfter447 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2163:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom73 n t s c u v y d w) w)) := by
  have micro := site2153 f n (emitAtom72 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (emitAtom72 n t s c u v y d w))):V)=(emitAtom73 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (emitAtom72 n t s c u v y d w))):V)=(0+(emitAtom73 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter446 f n t s c u v y d w).trans mid

theorem commandEmitAfter448 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2166:Nat):V) f (vector n 0 (emitAtom73 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2163 f n 0 0 c (d+u) (v+y) 0 (emitAtom73 n t s c u v y d w) w
  have d2 : ((0+(emitAtom73 n t s c u v y d w)):V)=(emitAtom73 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter447 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
