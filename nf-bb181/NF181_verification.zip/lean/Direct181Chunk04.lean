module
public import Direct181Snapshots
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem chunk23500 : Prefix 500 snap23000 snap23500 := checked _ _ _ (by decide) (by decide)
theorem chunk24000 : Prefix 500 snap23500 snap24000 := checked _ _ _ (by decide) (by decide)
theorem chunk24500 : Prefix 500 snap24000 snap24500 := checked _ _ _ (by decide) (by decide)
theorem chunk25000 : Prefix 500 snap24500 snap25000 := checked _ _ _ (by decide) (by decide)
theorem chunk25500 : Prefix 500 snap25000 snap25500 := checked _ _ _ (by decide) (by decide)
theorem chunk26000 : Prefix 500 snap25500 snap26000 := checked _ _ _ (by decide) (by decide)
theorem chunk26500 : Prefix 500 snap26000 snap26500 := checked _ _ _ (by decide) (by decide)
theorem chunk27000 : Prefix 500 snap26500 snap27000 := checked _ _ _ (by decide) (by decide)
theorem chunk27500 : Prefix 500 snap27000 snap27500 := checked _ _ _ (by decide) (by decide)
theorem chunk28000 : Prefix 500 snap27500 snap28000 := checked _ _ _ (by decide) (by decide)
theorem chunk28500 : Prefix 500 snap28000 snap28500 := checked _ _ _ (by decide) (by decide)
theorem chunk29000 : Prefix 500 snap28500 snap29000 := checked _ _ _ (by decide) (by decide)
end Direct181.Boot
