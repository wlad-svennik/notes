module
public import Src181CmdRefill00
public import Src181CmdRefillCold00
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch.Register181.Certified

namespace PA192.ModelSearch.Register181.Commands
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- First Cantor reader, including the two scratch coordinates supplied by refill. -/
theorem reader10General (f n t s c u v a b raw : V) :
    Reach (config ((10:Nat):V) f (vector n t s c u v a b raw))
      (config ((24:Nat):V) f (vector n t s (c+left (cantor a b+raw)) u v 0 0 (right (cantor a b+raw)))) := by
  let j := cantor a b+raw
  have h := site0010 f n t s c u v a b raw
  have e := site0018 f n t s c u v (left j) (right j) 0
  have g := site0021 f n t s c u v (left j) 0 (right j)
  simpa only [j,zero_add] using (h.trans (by simpa only [j,zero_add] using e)).trans g

/-- The usual entry computes the tag and leaves the full inner field word. -/
theorem reader10 (f n t s c u v raw : V) :
    Reach (config ((10:Nat):V) f (vector n t s c u v 0 0 raw))
      (config ((24:Nat):V) f (vector n t s (c+left raw) u v 0 0 (right raw))) := by
  simpa [cantor] using reader10General f n t s c u v 0 0 raw

/-- At the special entry the scratch coordinates already stand for the pair (0,n+1). -/
theorem reader10Carry (f n t s c u v k : V) :
    Reach (config ((10:Nat):V) f (vector n t s c u v 0 k 0))
      (config ((24:Nat):V) f (vector n t s c u v 0 0 k)) := by
  simpa using reader10General f n t s c u v 0 k 0

/-- Full warm empty-boundary link in every model of PA for the literal 181 program. -/
theorem refill0To24 (n t s c u v : V) :
    Reach (config ((0:Nat):V) 0 (vector n t s c u v 0 0 0))
      (config ((24:Nat):V) 0 (vector (n+1) t s c u v 0 0 (n+1))) := by
  have h := site0000Zero 0 n t s c u v 0 0 0
  have e := commandRefill n t s c u v 0 0 0
  have g := reader10Carry 0 (1+n) t s c u v (1+n)
  simpa only [add_comm (1:V) n] using (h.trans e).trans g

/-- The second Cantor reader consumes a clean inner word and exposes its tail at dispatch. -/
theorem reader24 (f n t s c u v raw : V) :
    Reach (config ((24:Nat):V) f (vector n t s c u v 0 0 raw))
      (config ((38:Nat):V) f (vector n t s c (u+left raw) v 0 0 (right raw))) := by
  have h := site0024 f n t s c u v 0 0 raw
  have h' : Reach (config ((24:Nat):V) f (vector n t s c u v 0 0 raw))
      (config ((32:Nat):V) f (vector n t s c u v (left raw) (right raw) 0)) := by
    simpa [cantor] using h
  have e := site0032 f n t s c u v (left raw) (right raw) 0
  have g := site0035 f n t s c u v (left raw) 0 (right raw)
  exact (h'.trans (by simpa only [zero_add] using e)).trans g

/-- At a nonempty command boundary the predecessor of the cursor is read in the usual way. -/
theorem continue0To24 (f n t s c u v raw : V) :
    Reach (config ((0:Nat):V) f (vector n t s c u v 0 0 (raw+1)))
      (config ((24:Nat):V) f (vector n t s (c+left raw) u v 0 0 (right raw))) :=
  ((site0000Positive f n t s c u v 0 0 raw).trans (site0001 f n t s c u v 0 0 raw)).trans
    (reader10 f n t s c u v raw)

/-- Full warm refill and its first forced tag zero, through binary source dispatch. -/
theorem refill0To38 (n t s u v : V) :
    Reach (config ((0:Nat):V) 0 (vector n t s 0 u v 0 0 0))
      (config ((38:Nat):V) 0 (vector (n+1) t s 0 (u+left (n+1)) v 0 0 (right (n+1)))) :=
  (refill0To24 n t s 0 u v).trans (reader24 0 (n+1) t s 0 u v (n+1))

/-- The first empty refill also works if the signed counter flag was still pending. -/
theorem coldRefill0To24 (n t s c u v : V) :
    Reach (config ((0:Nat):V) 1 (vector n t s c u v 0 0 0))
      (config ((24:Nat):V) 0 (vector 0 t s c u v 0 0 0)) :=
  ((site0000Zero 1 n t s c u v 0 0 0).trans (commandRefillCold n t s c u v 0 0 0)).trans
    (reader10Carry 0 0 t s c u v 0)

end PA192.ModelSearch.Register181.Commands
#print axioms PA192.ModelSearch.Register181.Commands.refill0To24
#print axioms PA192.ModelSearch.Register181.Commands.reader24
