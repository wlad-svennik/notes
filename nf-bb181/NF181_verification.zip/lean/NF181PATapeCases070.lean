import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2240_0 : checkWitness 2240 false false 86 = true := by decide +kernel
private theorem w2240_2 : checkWitness 2240 true false 86 = true := by decide +kernel
private theorem cases2240 : checkFour 2240 (86,0,86,0) = true := by
  simp only [checkFour, w2240_0, w2240_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2240 : Coverage 2240 2241 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases2240)
private theorem w2241_0 : checkWitness 2241 false false 78 = true := by decide +kernel
private theorem w2241_2 : checkWitness 2241 true false 78 = true := by decide +kernel
private theorem cases2241 : checkFour 2241 (78,0,78,0) = true := by
  simp only [checkFour, w2241_0, w2241_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2241 : Coverage 2241 2242 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2241)
private theorem w2242_0 : checkWitness 2242 false false 625 = true := by decide +kernel
private theorem w2242_1 : checkWitness 2242 false true 4709 = true := by decide +kernel
private theorem w2242_2 : checkWitness 2242 true false 625 = true := by decide +kernel
private theorem w2242_3 : checkWitness 2242 true true 4709 = true := by decide +kernel
private theorem cases2242 : checkFour 2242 (625,4709,625,4709) = true := by
  simp only [checkFour, w2242_0, w2242_1, w2242_2, w2242_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2242 : Coverage 2242 2243 := checkList_sound (ws:=[(625,4709,625,4709)]) (by simpa only [checkList, Bool.and_true] using cases2242)
private theorem w2243_0 : checkWitness 2243 false false 8878 = true := by decide +kernel
private theorem w2243_2 : checkWitness 2243 true false 8874 = true := by decide +kernel
private theorem cases2243 : checkFour 2243 (8878,0,8874,0) = true := by
  simp only [checkFour, w2243_0, w2243_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2243 : Coverage 2243 2244 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases2243)
private theorem w2244_0 : checkWitness 2244 false false 78 = true := by decide +kernel
private theorem w2244_2 : checkWitness 2244 true false 78 = true := by decide +kernel
private theorem cases2244 : checkFour 2244 (78,0,78,0) = true := by
  simp only [checkFour, w2244_0, w2244_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2244 : Coverage 2244 2245 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases2244)
private theorem w2245_0 : checkWitness 2245 false false 623 = true := by decide +kernel
private theorem w2245_1 : checkWitness 2245 false true 4715 = true := by decide +kernel
private theorem w2245_2 : checkWitness 2245 true false 614 = true := by decide +kernel
private theorem w2245_3 : checkWitness 2245 true true 4706 = true := by decide +kernel
private theorem cases2245 : checkFour 2245 (623,4715,614,4706) = true := by
  simp only [checkFour, w2245_0, w2245_1, w2245_2, w2245_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2245 : Coverage 2245 2246 := checkList_sound (ws:=[(623,4715,614,4706)]) (by simpa only [checkList, Bool.and_true] using cases2245)
private theorem w2246_0 : checkWitness 2246 false false 8920 = true := by decide +kernel
private theorem w2246_2 : checkWitness 2246 true false 8911 = true := by decide +kernel
private theorem cases2246 : checkFour 2246 (8920,0,8911,0) = true := by
  simp only [checkFour, w2246_0, w2246_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2246 : Coverage 2246 2247 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2246)
private theorem w2247_0 : checkWitness 2247 false false 8866 = true := by decide +kernel
private theorem w2247_2 : checkWitness 2247 true false 8862 = true := by decide +kernel
private theorem cases2247 : checkFour 2247 (8866,0,8862,0) = true := by
  simp only [checkFour, w2247_0, w2247_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2247 : Coverage 2247 2248 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases2247)
private theorem w2248_0 : checkWitness 2248 false false 72 = true := by decide +kernel
private theorem w2248_2 : checkWitness 2248 true false 72 = true := by decide +kernel
private theorem cases2248 : checkFour 2248 (72,0,72,0) = true := by
  simp only [checkFour, w2248_0, w2248_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2248 : Coverage 2248 2249 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2248)
private theorem w2249_0 : checkWitness 2249 false false 650 = true := by decide +kernel
private theorem w2249_1 : checkWitness 2249 false true 4742 = true := by decide +kernel
private theorem w2249_2 : checkWitness 2249 true false 641 = true := by decide +kernel
private theorem w2249_3 : checkWitness 2249 true true 4733 = true := by decide +kernel
private theorem cases2249 : checkFour 2249 (650,4742,641,4733) = true := by
  simp only [checkFour, w2249_0, w2249_1, w2249_2, w2249_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2249 : Coverage 2249 2250 := checkList_sound (ws:=[(650,4742,641,4733)]) (by simpa only [checkList, Bool.and_true] using cases2249)
private theorem w2250_0 : checkWitness 2250 false false 8927 = true := by decide +kernel
private theorem w2250_2 : checkWitness 2250 true false 8918 = true := by decide +kernel
private theorem cases2250 : checkFour 2250 (8927,0,8918,0) = true := by
  simp only [checkFour, w2250_0, w2250_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2250 : Coverage 2250 2251 := checkList_sound (ws:=[(8927,0,8918,0)]) (by simpa only [checkList, Bool.and_true] using cases2250)
private theorem w2251_0 : checkWitness 2251 false false 56 = true := by decide +kernel
private theorem w2251_2 : checkWitness 2251 true false 56 = true := by decide +kernel
private theorem cases2251 : checkFour 2251 (56,0,56,0) = true := by
  simp only [checkFour, w2251_0, w2251_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2251 : Coverage 2251 2252 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2251)
private theorem w2252_0 : checkWitness 2252 false false 514 = true := by decide +kernel
private theorem w2252_1 : checkWitness 2252 false true 4610 = true := by decide +kernel
private theorem w2252_2 : checkWitness 2252 true false 514 = true := by decide +kernel
private theorem w2252_3 : checkWitness 2252 true true 4610 = true := by decide +kernel
private theorem cases2252 : checkFour 2252 (514,4610,514,4610) = true := by
  simp only [checkFour, w2252_0, w2252_1, w2252_2, w2252_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2252 : Coverage 2252 2253 := checkList_sound (ws:=[(514,4610,514,4610)]) (by simpa only [checkList, Bool.and_true] using cases2252)
private theorem w2253_0 : checkWitness 2253 false false 8909 = true := by decide +kernel
private theorem w2253_2 : checkWitness 2253 true false 8905 = true := by decide +kernel
private theorem cases2253 : checkFour 2253 (8909,0,8905,0) = true := by
  simp only [checkFour, w2253_0, w2253_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2253 : Coverage 2253 2254 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases2253)
private theorem w2254_0 : checkWitness 2254 false false 640 = true := by decide +kernel
private theorem w2254_1 : checkWitness 2254 false true 4736 = true := by decide +kernel
private theorem w2254_2 : checkWitness 2254 true false 631 = true := by decide +kernel
private theorem w2254_3 : checkWitness 2254 true true 4727 = true := by decide +kernel
private theorem cases2254 : checkFour 2254 (640,4736,631,4727) = true := by
  simp only [checkFour, w2254_0, w2254_1, w2254_2, w2254_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2254 : Coverage 2254 2255 := checkList_sound (ws:=[(640,4736,631,4727)]) (by simpa only [checkList, Bool.and_true] using cases2254)
private theorem w2255_0 : checkWitness 2255 false false 186 = true := by decide +kernel
private theorem w2255_2 : checkWitness 2255 true false 186 = true := by decide +kernel
private theorem cases2255 : checkFour 2255 (186,0,186,0) = true := by
  simp only [checkFour, w2255_0, w2255_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2255 : Coverage 2255 2256 := checkList_sound (ws:=[(186,0,186,0)]) (by simpa only [checkList, Bool.and_true] using cases2255)
private theorem w2256_0 : checkWitness 2256 false false 595 = true := by decide +kernel
private theorem w2256_1 : checkWitness 2256 false true 4683 = true := by decide +kernel
private theorem w2256_2 : checkWitness 2256 true false 595 = true := by decide +kernel
private theorem w2256_3 : checkWitness 2256 true true 4683 = true := by decide +kernel
private theorem cases2256 : checkFour 2256 (595,4683,595,4683) = true := by
  simp only [checkFour, w2256_0, w2256_1, w2256_2, w2256_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2256 : Coverage 2256 2257 := checkList_sound (ws:=[(595,4683,595,4683)]) (by simpa only [checkList, Bool.and_true] using cases2256)
private theorem w2257_0 : checkWitness 2257 false false 8924 = true := by decide +kernel
private theorem w2257_2 : checkWitness 2257 true false 8915 = true := by decide +kernel
private theorem cases2257 : checkFour 2257 (8924,0,8915,0) = true := by
  simp only [checkFour, w2257_0, w2257_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2257 : Coverage 2257 2258 := checkList_sound (ws:=[(8924,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases2257)
private theorem w2258_0 : checkWitness 2258 false false 74 = true := by decide +kernel
private theorem w2258_2 : checkWitness 2258 true false 74 = true := by decide +kernel
private theorem cases2258 : checkFour 2258 (74,0,74,0) = true := by
  simp only [checkFour, w2258_0, w2258_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2258 : Coverage 2258 2259 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2258)
private theorem w2259_0 : checkWitness 2259 false false 66 = true := by decide +kernel
private theorem w2259_2 : checkWitness 2259 true false 66 = true := by decide +kernel
private theorem cases2259 : checkFour 2259 (66,0,66,0) = true := by
  simp only [checkFour, w2259_0, w2259_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2259 : Coverage 2259 2260 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2259)
private theorem w2260_0 : checkWitness 2260 false false 601 = true := by decide +kernel
private theorem w2260_1 : checkWitness 2260 false true 4693 = true := by decide +kernel
private theorem w2260_2 : checkWitness 2260 true false 601 = true := by decide +kernel
private theorem w2260_3 : checkWitness 2260 true true 4693 = true := by decide +kernel
private theorem cases2260 : checkFour 2260 (601,4693,601,4693) = true := by
  simp only [checkFour, w2260_0, w2260_1, w2260_2, w2260_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2260 : Coverage 2260 2261 := checkList_sound (ws:=[(601,4693,601,4693)]) (by simpa only [checkList, Bool.and_true] using cases2260)
private theorem w2261_0 : checkWitness 2261 false false 8862 = true := by decide +kernel
private theorem w2261_2 : checkWitness 2261 true false 8858 = true := by decide +kernel
private theorem cases2261 : checkFour 2261 (8862,0,8858,0) = true := by
  simp only [checkFour, w2261_0, w2261_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2261 : Coverage 2261 2262 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases2261)
private theorem w2262_0 : checkWitness 2262 false false 66 = true := by decide +kernel
private theorem w2262_2 : checkWitness 2262 true false 66 = true := by decide +kernel
private theorem cases2262 : checkFour 2262 (66,0,66,0) = true := by
  simp only [checkFour, w2262_0, w2262_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2262 : Coverage 2262 2263 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2262)
private theorem w2263_0 : checkWitness 2263 false false 556 = true := by decide +kernel
private theorem w2263_1 : checkWitness 2263 false true 4652 = true := by decide +kernel
private theorem w2263_2 : checkWitness 2263 true false 556 = true := by decide +kernel
private theorem w2263_3 : checkWitness 2263 true true 4652 = true := by decide +kernel
private theorem cases2263 : checkFour 2263 (556,4652,556,4652) = true := by
  simp only [checkFour, w2263_0, w2263_1, w2263_2, w2263_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2263 : Coverage 2263 2264 := checkList_sound (ws:=[(556,4652,556,4652)]) (by simpa only [checkList, Bool.and_true] using cases2263)
private theorem w2264_0 : checkWitness 2264 false false 8897 = true := by decide +kernel
private theorem w2264_2 : checkWitness 2264 true false 8893 = true := by decide +kernel
private theorem cases2264 : checkFour 2264 (8897,0,8893,0) = true := by
  simp only [checkFour, w2264_0, w2264_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2264 : Coverage 2264 2265 := checkList_sound (ws:=[(8897,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases2264)
private theorem w2265_0 : checkWitness 2265 false false 8932 = true := by decide +kernel
private theorem w2265_2 : checkWitness 2265 true false 8923 = true := by decide +kernel
private theorem cases2265 : checkFour 2265 (8932,0,8923,0) = true := by
  simp only [checkFour, w2265_0, w2265_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2265 : Coverage 2265 2266 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases2265)
private theorem w2266_0 : checkWitness 2266 false false 84 = true := by decide +kernel
private theorem w2266_2 : checkWitness 2266 true false 84 = true := by decide +kernel
private theorem cases2266 : checkFour 2266 (84,0,84,0) = true := by
  simp only [checkFour, w2266_0, w2266_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2266 : Coverage 2266 2267 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases2266)
private theorem w2267_0 : checkWitness 2267 false false 644 = true := by decide +kernel
private theorem w2267_1 : checkWitness 2267 false true 4736 = true := by decide +kernel
private theorem w2267_2 : checkWitness 2267 true false 635 = true := by decide +kernel
private theorem w2267_3 : checkWitness 2267 true true 4727 = true := by decide +kernel
private theorem cases2267 : checkFour 2267 (644,4736,635,4727) = true := by
  simp only [checkFour, w2267_0, w2267_1, w2267_2, w2267_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2267 : Coverage 2267 2268 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases2267)
private theorem w2268_0 : checkWitness 2268 false false 8893 = true := by decide +kernel
private theorem w2268_2 : checkWitness 2268 true false 8889 = true := by decide +kernel
private theorem cases2268 : checkFour 2268 (8893,0,8889,0) = true := by
  simp only [checkFour, w2268_0, w2268_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2268 : Coverage 2268 2269 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases2268)
private theorem w2269_0 : checkWitness 2269 false false 638 = true := by decide +kernel
private theorem w2269_1 : checkWitness 2269 false true 4730 = true := by decide +kernel
private theorem w2269_2 : checkWitness 2269 true false 629 = true := by decide +kernel
private theorem w2269_3 : checkWitness 2269 true true 4721 = true := by decide +kernel
private theorem cases2269 : checkFour 2269 (638,4730,629,4721) = true := by
  simp only [checkFour, w2269_0, w2269_1, w2269_2, w2269_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2269 : Coverage 2269 2270 := checkList_sound (ws:=[(638,4730,629,4721)]) (by simpa only [checkList, Bool.and_true] using cases2269)
private theorem w2270_0 : checkWitness 2270 false false 8862 = true := by decide +kernel
private theorem w2270_2 : checkWitness 2270 true false 8858 = true := by decide +kernel
private theorem cases2270 : checkFour 2270 (8862,0,8858,0) = true := by
  simp only [checkFour, w2270_0, w2270_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2270 : Coverage 2270 2271 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases2270)
private theorem w2271_0 : checkWitness 2271 false false 72 = true := by decide +kernel
private theorem w2271_2 : checkWitness 2271 true false 72 = true := by decide +kernel
private theorem cases2271 : checkFour 2271 (72,0,72,0) = true := by
  simp only [checkFour, w2271_0, w2271_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2271 : Coverage 2271 2272 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2271)
theorem cover2240 : Coverage 2240 2272 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2240 one2241) (Coverage.join one2242 one2243)) (Coverage.join (Coverage.join one2244 one2245) (Coverage.join one2246 one2247))) (Coverage.join (Coverage.join (Coverage.join one2248 one2249) (Coverage.join one2250 one2251)) (Coverage.join (Coverage.join one2252 one2253) (Coverage.join one2254 one2255)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2256 one2257) (Coverage.join one2258 one2259)) (Coverage.join (Coverage.join one2260 one2261) (Coverage.join one2262 one2263))) (Coverage.join (Coverage.join (Coverage.join one2264 one2265) (Coverage.join one2266 one2267)) (Coverage.join (Coverage.join one2268 one2269) (Coverage.join one2270 one2271)))))
end NF181PA.Symbolic
