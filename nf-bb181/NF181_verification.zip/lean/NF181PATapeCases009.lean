import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w288_0 : checkWitness 288 false false 74 = true := by decide +kernel
private theorem w288_2 : checkWitness 288 true false 74 = true := by decide +kernel
private theorem cases288 : checkFour 288 (74,0,74,0) = true := by
  simp only [checkFour, w288_0, w288_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one288 : Coverage 288 289 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases288)
private theorem w289_0 : checkWitness 289 false false 603 = true := by decide +kernel
private theorem w289_1 : checkWitness 289 false true 4687 = true := by decide +kernel
private theorem w289_2 : checkWitness 289 true false 603 = true := by decide +kernel
private theorem w289_3 : checkWitness 289 true true 4687 = true := by decide +kernel
private theorem cases289 : checkFour 289 (603,4687,603,4687) = true := by
  simp only [checkFour, w289_0, w289_1, w289_2, w289_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one289 : Coverage 289 290 := checkList_sound (ws:=[(603,4687,603,4687)]) (by simpa only [checkList, Bool.and_true] using cases289)
private theorem w290_0 : checkWitness 290 false false 8856 = true := by decide +kernel
private theorem w290_2 : checkWitness 290 true false 8852 = true := by decide +kernel
private theorem cases290 : checkFour 290 (8856,0,8852,0) = true := by
  simp only [checkFour, w290_0, w290_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one290 : Coverage 290 291 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases290)
private theorem w291_0 : checkWitness 291 false false 74 = true := by decide +kernel
private theorem w291_2 : checkWitness 291 true false 74 = true := by decide +kernel
private theorem cases291 : checkFour 291 (74,0,74,0) = true := by
  simp only [checkFour, w291_0, w291_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one291 : Coverage 291 292 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases291)
private theorem w292_0 : checkWitness 292 false false 619 = true := by decide +kernel
private theorem w292_1 : checkWitness 292 false true 4711 = true := by decide +kernel
private theorem w292_2 : checkWitness 292 true false 610 = true := by decide +kernel
private theorem w292_3 : checkWitness 292 true true 4702 = true := by decide +kernel
private theorem cases292 : checkFour 292 (619,4711,610,4702) = true := by
  simp only [checkFour, w292_0, w292_1, w292_2, w292_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one292 : Coverage 292 293 := checkList_sound (ws:=[(619,4711,610,4702)]) (by simpa only [checkList, Bool.and_true] using cases292)
private theorem w293_0 : checkWitness 293 false false 8916 = true := by decide +kernel
private theorem w293_2 : checkWitness 293 true false 8907 = true := by decide +kernel
private theorem cases293 : checkFour 293 (8916,0,8907,0) = true := by
  simp only [checkFour, w293_0, w293_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one293 : Coverage 293 294 := checkList_sound (ws:=[(8916,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases293)
private theorem w294_0 : checkWitness 294 false false 8862 = true := by decide +kernel
private theorem w294_2 : checkWitness 294 true false 8858 = true := by decide +kernel
private theorem cases294 : checkFour 294 (8862,0,8858,0) = true := by
  simp only [checkFour, w294_0, w294_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one294 : Coverage 294 295 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases294)
private theorem w295_0 : checkWitness 295 false false 74 = true := by decide +kernel
private theorem w295_2 : checkWitness 295 true false 74 = true := by decide +kernel
private theorem cases295 : checkFour 295 (74,0,74,0) = true := by
  simp only [checkFour, w295_0, w295_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one295 : Coverage 295 296 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases295)
private theorem w296_0 : checkWitness 296 false false 654 = true := by decide +kernel
private theorem w296_1 : checkWitness 296 false true 4738 = true := by decide +kernel
private theorem w296_2 : checkWitness 296 true false 645 = true := by decide +kernel
private theorem w296_3 : checkWitness 296 true true 4729 = true := by decide +kernel
private theorem cases296 : checkFour 296 (654,4738,645,4729) = true := by
  simp only [checkFour, w296_0, w296_1, w296_2, w296_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one296 : Coverage 296 297 := checkList_sound (ws:=[(654,4738,645,4729)]) (by simpa only [checkList, Bool.and_true] using cases296)
private theorem w297_0 : checkWitness 297 false false 8923 = true := by decide +kernel
private theorem w297_2 : checkWitness 297 true false 8914 = true := by decide +kernel
private theorem cases297 : checkFour 297 (8923,0,8914,0) = true := by
  simp only [checkFour, w297_0, w297_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one297 : Coverage 297 298 := checkList_sound (ws:=[(8923,0,8914,0)]) (by simpa only [checkList, Bool.and_true] using cases297)
private theorem w298_0 : checkWitness 298 false false 58 = true := by decide +kernel
private theorem w298_2 : checkWitness 298 true false 58 = true := by decide +kernel
private theorem cases298 : checkFour 298 (58,0,58,0) = true := by
  simp only [checkFour, w298_0, w298_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one298 : Coverage 298 299 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases298)
private theorem w299_0 : checkWitness 299 false false 570 = true := by decide +kernel
private theorem w299_1 : checkWitness 299 false true 4666 = true := by decide +kernel
private theorem w299_2 : checkWitness 299 true false 570 = true := by decide +kernel
private theorem w299_3 : checkWitness 299 true true 4666 = true := by decide +kernel
private theorem cases299 : checkFour 299 (570,4666,570,4666) = true := by
  simp only [checkFour, w299_0, w299_1, w299_2, w299_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one299 : Coverage 299 300 := checkList_sound (ws:=[(570,4666,570,4666)]) (by simpa only [checkList, Bool.and_true] using cases299)
private theorem w300_0 : checkWitness 300 false false 8932 = true := by decide +kernel
private theorem w300_2 : checkWitness 300 true false 8923 = true := by decide +kernel
private theorem cases300 : checkFour 300 (8932,0,8923,0) = true := by
  simp only [checkFour, w300_0, w300_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one300 : Coverage 300 301 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases300)
private theorem w301_0 : checkWitness 301 false false 60 = true := by decide +kernel
private theorem w301_2 : checkWitness 301 true false 60 = true := by decide +kernel
private theorem cases301 : checkFour 301 (60,0,60,0) = true := by
  simp only [checkFour, w301_0, w301_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one301 : Coverage 301 302 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases301)
private theorem w302_0 : checkWitness 302 false false 514 = true := by decide +kernel
private theorem w302_1 : checkWitness 302 false true 4610 = true := by decide +kernel
private theorem w302_2 : checkWitness 302 true false 514 = true := by decide +kernel
private theorem w302_3 : checkWitness 302 true true 4610 = true := by decide +kernel
private theorem cases302 : checkFour 302 (514,4610,514,4610) = true := by
  simp only [checkFour, w302_0, w302_1, w302_2, w302_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one302 : Coverage 302 303 := checkList_sound (ws:=[(514,4610,514,4610)]) (by simpa only [checkList, Bool.and_true] using cases302)
private theorem w303_0 : checkWitness 303 false false 8872 = true := by decide +kernel
private theorem w303_2 : checkWitness 303 true false 8868 = true := by decide +kernel
private theorem cases303 : checkFour 303 (8872,0,8868,0) = true := by
  simp only [checkFour, w303_0, w303_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one303 : Coverage 303 304 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases303)
private theorem w304_0 : checkWitness 304 false false 62 = true := by decide +kernel
private theorem w304_2 : checkWitness 304 true false 62 = true := by decide +kernel
private theorem cases304 : checkFour 304 (62,0,62,0) = true := by
  simp only [checkFour, w304_0, w304_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one304 : Coverage 304 305 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases304)
private theorem w305_0 : checkWitness 305 false false 552 = true := by decide +kernel
private theorem w305_1 : checkWitness 305 false true 4648 = true := by decide +kernel
private theorem w305_2 : checkWitness 305 true false 552 = true := by decide +kernel
private theorem w305_3 : checkWitness 305 true true 4648 = true := by decide +kernel
private theorem cases305 : checkFour 305 (552,4648,552,4648) = true := by
  simp only [checkFour, w305_0, w305_1, w305_2, w305_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one305 : Coverage 305 306 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases305)
private theorem w306_0 : checkWitness 306 false false 8893 = true := by decide +kernel
private theorem w306_2 : checkWitness 306 true false 8889 = true := by decide +kernel
private theorem cases306 : checkFour 306 (8893,0,8889,0) = true := by
  simp only [checkFour, w306_0, w306_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one306 : Coverage 306 307 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases306)
private theorem w307_0 : checkWitness 307 false false 8928 = true := by decide +kernel
private theorem w307_2 : checkWitness 307 true false 8919 = true := by decide +kernel
private theorem cases307 : checkFour 307 (8928,0,8919,0) = true := by
  simp only [checkFour, w307_0, w307_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one307 : Coverage 307 308 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases307)
private theorem w308_0 : checkWitness 308 false false 86 = true := by decide +kernel
private theorem w308_2 : checkWitness 308 true false 86 = true := by decide +kernel
private theorem cases308 : checkFour 308 (86,0,86,0) = true := by
  simp only [checkFour, w308_0, w308_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one308 : Coverage 308 309 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases308)
private theorem w309_0 : checkWitness 309 false false 640 = true := by decide +kernel
private theorem w309_1 : checkWitness 309 false true 4732 = true := by decide +kernel
private theorem w309_2 : checkWitness 309 true false 631 = true := by decide +kernel
private theorem w309_3 : checkWitness 309 true true 4723 = true := by decide +kernel
private theorem cases309 : checkFour 309 (640,4732,631,4723) = true := by
  simp only [checkFour, w309_0, w309_1, w309_2, w309_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one309 : Coverage 309 310 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases309)
private theorem w310_0 : checkWitness 310 false false 8889 = true := by decide +kernel
private theorem w310_2 : checkWitness 310 true false 8885 = true := by decide +kernel
private theorem cases310 : checkFour 310 (8889,0,8885,0) = true := by
  simp only [checkFour, w310_0, w310_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one310 : Coverage 310 311 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases310)
private theorem w311_0 : checkWitness 311 false false 634 = true := by decide +kernel
private theorem w311_1 : checkWitness 311 false true 4726 = true := by decide +kernel
private theorem w311_2 : checkWitness 311 true false 625 = true := by decide +kernel
private theorem w311_3 : checkWitness 311 true true 4717 = true := by decide +kernel
private theorem cases311 : checkFour 311 (634,4726,625,4717) = true := by
  simp only [checkFour, w311_0, w311_1, w311_2, w311_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one311 : Coverage 311 312 := checkList_sound (ws:=[(634,4726,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases311)
private theorem w312_0 : checkWitness 312 false false 8858 = true := by decide +kernel
private theorem w312_2 : checkWitness 312 true false 8854 = true := by decide +kernel
private theorem cases312 : checkFour 312 (8858,0,8854,0) = true := by
  simp only [checkFour, w312_0, w312_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one312 : Coverage 312 313 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases312)
private theorem w313_0 : checkWitness 313 false false 74 = true := by decide +kernel
private theorem w313_2 : checkWitness 313 true false 74 = true := by decide +kernel
private theorem cases313 : checkFour 313 (74,0,74,0) = true := by
  simp only [checkFour, w313_0, w313_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one313 : Coverage 313 314 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases313)
private theorem w314_0 : checkWitness 314 false false 66 = true := by decide +kernel
private theorem w314_2 : checkWitness 314 true false 66 = true := by decide +kernel
private theorem cases314 : checkFour 314 (66,0,66,0) = true := by
  simp only [checkFour, w314_0, w314_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one314 : Coverage 314 315 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases314)
private theorem w315_0 : checkWitness 315 false false 599 = true := by decide +kernel
private theorem w315_1 : checkWitness 315 false true 4683 = true := by decide +kernel
private theorem w315_2 : checkWitness 315 true false 599 = true := by decide +kernel
private theorem w315_3 : checkWitness 315 true true 4683 = true := by decide +kernel
private theorem cases315 : checkFour 315 (599,4683,599,4683) = true := by
  simp only [checkFour, w315_0, w315_1, w315_2, w315_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one315 : Coverage 315 316 := checkList_sound (ws:=[(599,4683,599,4683)]) (by simpa only [checkList, Bool.and_true] using cases315)
private theorem w316_0 : checkWitness 316 false false 8852 = true := by decide +kernel
private theorem w316_2 : checkWitness 316 true false 8848 = true := by decide +kernel
private theorem cases316 : checkFour 316 (8852,0,8848,0) = true := by
  simp only [checkFour, w316_0, w316_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one316 : Coverage 316 317 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases316)
private theorem w317_0 : checkWitness 317 false false 66 = true := by decide +kernel
private theorem w317_2 : checkWitness 317 true false 66 = true := by decide +kernel
private theorem cases317 : checkFour 317 (66,0,66,0) = true := by
  simp only [checkFour, w317_0, w317_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one317 : Coverage 317 318 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases317)
private theorem w318_0 : checkWitness 318 false false 604 = true := by decide +kernel
private theorem w318_1 : checkWitness 318 false true 4700 = true := by decide +kernel
private theorem w318_2 : checkWitness 318 true false 604 = true := by decide +kernel
private theorem w318_3 : checkWitness 318 true true 4700 = true := by decide +kernel
private theorem cases318 : checkFour 318 (604,4700,604,4700) = true := by
  simp only [checkFour, w318_0, w318_1, w318_2, w318_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one318 : Coverage 318 319 := checkList_sound (ws:=[(604,4700,604,4700)]) (by simpa only [checkList, Bool.and_true] using cases318)
private theorem w319_0 : checkWitness 319 false false 8920 = true := by decide +kernel
private theorem w319_2 : checkWitness 319 true false 8911 = true := by decide +kernel
private theorem cases319 : checkFour 319 (8920,0,8911,0) = true := by
  simp only [checkFour, w319_0, w319_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one319 : Coverage 319 320 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases319)
theorem cover0288 : Coverage 288 320 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one288 one289) (Coverage.join one290 one291)) (Coverage.join (Coverage.join one292 one293) (Coverage.join one294 one295))) (Coverage.join (Coverage.join (Coverage.join one296 one297) (Coverage.join one298 one299)) (Coverage.join (Coverage.join one300 one301) (Coverage.join one302 one303)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one304 one305) (Coverage.join one306 one307)) (Coverage.join (Coverage.join one308 one309) (Coverage.join one310 one311))) (Coverage.join (Coverage.join (Coverage.join one312 one313) (Coverage.join one314 one315)) (Coverage.join (Coverage.join one316 one317) (Coverage.join one318 one319)))))
end NF181PA.Symbolic
