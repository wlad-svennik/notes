import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1376_0 : checkWitness 1376 false false 82 = true := by decide +kernel
private theorem w1376_2 : checkWitness 1376 true false 82 = true := by decide +kernel
private theorem cases1376 : checkFour 1376 (82,0,82,0) = true := by
  simp only [checkFour, w1376_0, w1376_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1376 : Coverage 1376 1377 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1376)
private theorem w1377_0 : checkWitness 1377 false false 569 = true := by decide +kernel
private theorem w1377_1 : checkWitness 1377 false true 4657 = true := by decide +kernel
private theorem w1377_2 : checkWitness 1377 true false 569 = true := by decide +kernel
private theorem w1377_3 : checkWitness 1377 true true 4657 = true := by decide +kernel
private theorem cases1377 : checkFour 1377 (569,4657,569,4657) = true := by
  simp only [checkFour, w1377_0, w1377_1, w1377_2, w1377_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1377 : Coverage 1377 1378 := checkList_sound (ws:=[(569,4657,569,4657)]) (by simpa only [checkList, Bool.and_true] using cases1377)
private theorem w1378_0 : checkWitness 1378 false false 8842 = true := by decide +kernel
private theorem w1378_2 : checkWitness 1378 true false 8838 = true := by decide +kernel
private theorem cases1378 : checkFour 1378 (8842,0,8838,0) = true := by
  simp only [checkFour, w1378_0, w1378_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1378 : Coverage 1378 1379 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1378)
private theorem w1379_0 : checkWitness 1379 false false 8838 = true := by decide +kernel
private theorem w1379_2 : checkWitness 1379 true false 8834 = true := by decide +kernel
private theorem cases1379 : checkFour 1379 (8838,0,8834,0) = true := by
  simp only [checkFour, w1379_0, w1379_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1379 : Coverage 1379 1380 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1379)
private theorem w1380_0 : checkWitness 1380 false false 96 = true := by decide +kernel
private theorem w1380_2 : checkWitness 1380 true false 96 = true := by decide +kernel
private theorem cases1380 : checkFour 1380 (96,0,96,0) = true := by
  simp only [checkFour, w1380_0, w1380_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1380 : Coverage 1380 1381 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1380)
private theorem w1381_0 : checkWitness 1381 false false 8862 = true := by decide +kernel
private theorem w1381_2 : checkWitness 1381 true false 8858 = true := by decide +kernel
private theorem cases1381 : checkFour 1381 (8862,0,8858,0) = true := by
  simp only [checkFour, w1381_0, w1381_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1381 : Coverage 1381 1382 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases1381)
private theorem w1382_0 : checkWitness 1382 false false 474 = true := by decide +kernel
private theorem w1382_1 : checkWitness 1382 false true 4570 = true := by decide +kernel
private theorem w1382_2 : checkWitness 1382 true false 474 = true := by decide +kernel
private theorem w1382_3 : checkWitness 1382 true true 4570 = true := by decide +kernel
private theorem cases1382 : checkFour 1382 (474,4570,474,4570) = true := by
  simp only [checkFour, w1382_0, w1382_1, w1382_2, w1382_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1382 : Coverage 1382 1383 := checkList_sound (ws:=[(474,4570,474,4570)]) (by simpa only [checkList, Bool.and_true] using cases1382)
private theorem w1383_0 : checkWitness 1383 false false 8906 = true := by decide +kernel
private theorem w1383_2 : checkWitness 1383 true false 8897 = true := by decide +kernel
private theorem cases1383 : checkFour 1383 (8906,0,8897,0) = true := by
  simp only [checkFour, w1383_0, w1383_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1383 : Coverage 1383 1384 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1383)
private theorem w1384_0 : checkWitness 1384 false false 78 = true := by decide +kernel
private theorem w1384_2 : checkWitness 1384 true false 78 = true := by decide +kernel
private theorem cases1384 : checkFour 1384 (78,0,78,0) = true := by
  simp only [checkFour, w1384_0, w1384_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1384 : Coverage 1384 1385 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1384)
private theorem w1385_0 : checkWitness 1385 false false 488 = true := by decide +kernel
private theorem w1385_1 : checkWitness 1385 false true 4584 = true := by decide +kernel
private theorem w1385_2 : checkWitness 1385 true false 488 = true := by decide +kernel
private theorem w1385_3 : checkWitness 1385 true true 4584 = true := by decide +kernel
private theorem cases1385 : checkFour 1385 (488,4584,488,4584) = true := by
  simp only [checkFour, w1385_0, w1385_1, w1385_2, w1385_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1385 : Coverage 1385 1386 := checkList_sound (ws:=[(488,4584,488,4584)]) (by simpa only [checkList, Bool.and_true] using cases1385)
private theorem w1386_0 : checkWitness 1386 false false 8846 = true := by decide +kernel
private theorem w1386_2 : checkWitness 1386 true false 8842 = true := by decide +kernel
private theorem cases1386 : checkFour 1386 (8846,0,8842,0) = true := by
  simp only [checkFour, w1386_0, w1386_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1386 : Coverage 1386 1387 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1386)
private theorem w1387_0 : checkWitness 1387 false false 80 = true := by decide +kernel
private theorem w1387_2 : checkWitness 1387 true false 80 = true := by decide +kernel
private theorem cases1387 : checkFour 1387 (80,0,80,0) = true := by
  simp only [checkFour, w1387_0, w1387_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1387 : Coverage 1387 1388 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1387)
private theorem w1388_0 : checkWitness 1388 false false 526 = true := by decide +kernel
private theorem w1388_1 : checkWitness 1388 false true 4622 = true := by decide +kernel
private theorem w1388_2 : checkWitness 1388 true false 526 = true := by decide +kernel
private theorem w1388_3 : checkWitness 1388 true true 4622 = true := by decide +kernel
private theorem cases1388 : checkFour 1388 (526,4622,526,4622) = true := by
  simp only [checkFour, w1388_0, w1388_1, w1388_2, w1388_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1388 : Coverage 1388 1389 := checkList_sound (ws:=[(526,4622,526,4622)]) (by simpa only [checkList, Bool.and_true] using cases1388)
private theorem w1389_0 : checkWitness 1389 false false 8867 = true := by decide +kernel
private theorem w1389_2 : checkWitness 1389 true false 8863 = true := by decide +kernel
private theorem cases1389 : checkFour 1389 (8867,0,8863,0) = true := by
  simp only [checkFour, w1389_0, w1389_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1389 : Coverage 1389 1390 := checkList_sound (ws:=[(8867,0,8863,0)]) (by simpa only [checkList, Bool.and_true] using cases1389)
private theorem w1390_0 : checkWitness 1390 false false 8902 = true := by decide +kernel
private theorem w1390_2 : checkWitness 1390 true false 8893 = true := by decide +kernel
private theorem cases1390 : checkFour 1390 (8902,0,8893,0) = true := by
  simp only [checkFour, w1390_0, w1390_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1390 : Coverage 1390 1391 := checkList_sound (ws:=[(8902,0,8893,0)]) (by simpa only [checkList, Bool.and_true] using cases1390)
private theorem w1391_0 : checkWitness 1391 false false 104 = true := by decide +kernel
private theorem w1391_2 : checkWitness 1391 true false 104 = true := by decide +kernel
private theorem cases1391 : checkFour 1391 (104,0,104,0) = true := by
  simp only [checkFour, w1391_0, w1391_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1391 : Coverage 1391 1392 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases1391)
private theorem w1392_0 : checkWitness 1392 false false 614 = true := by decide +kernel
private theorem w1392_1 : checkWitness 1392 false true 4706 = true := by decide +kernel
private theorem w1392_2 : checkWitness 1392 true false 605 = true := by decide +kernel
private theorem w1392_3 : checkWitness 1392 true true 4697 = true := by decide +kernel
private theorem cases1392 : checkFour 1392 (614,4706,605,4697) = true := by
  simp only [checkFour, w1392_0, w1392_1, w1392_2, w1392_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1392 : Coverage 1392 1393 := checkList_sound (ws:=[(614,4706,605,4697)]) (by simpa only [checkList, Bool.and_true] using cases1392)
private theorem w1393_0 : checkWitness 1393 false false 8863 = true := by decide +kernel
private theorem w1393_2 : checkWitness 1393 true false 8859 = true := by decide +kernel
private theorem cases1393 : checkFour 1393 (8863,0,8859,0) = true := by
  simp only [checkFour, w1393_0, w1393_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1393 : Coverage 1393 1394 := checkList_sound (ws:=[(8863,0,8859,0)]) (by simpa only [checkList, Bool.and_true] using cases1393)
private theorem w1394_0 : checkWitness 1394 false false 608 = true := by decide +kernel
private theorem w1394_1 : checkWitness 1394 false true 4700 = true := by decide +kernel
private theorem w1394_2 : checkWitness 1394 true false 599 = true := by decide +kernel
private theorem w1394_3 : checkWitness 1394 true true 4691 = true := by decide +kernel
private theorem cases1394 : checkFour 1394 (608,4700,599,4691) = true := by
  simp only [checkFour, w1394_0, w1394_1, w1394_2, w1394_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1394 : Coverage 1394 1395 := checkList_sound (ws:=[(608,4700,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases1394)
private theorem w1395_0 : checkWitness 1395 false false 8832 = true := by decide +kernel
private theorem w1395_2 : checkWitness 1395 true false 8828 = true := by decide +kernel
private theorem cases1395 : checkFour 1395 (8832,0,8828,0) = true := by
  simp only [checkFour, w1395_0, w1395_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1395 : Coverage 1395 1396 := checkList_sound (ws:=[(8832,0,8828,0)]) (by simpa only [checkList, Bool.and_true] using cases1395)
private theorem w1396_0 : checkWitness 1396 false false 92 = true := by decide +kernel
private theorem w1396_2 : checkWitness 1396 true false 92 = true := by decide +kernel
private theorem cases1396 : checkFour 1396 (92,0,92,0) = true := by
  simp only [checkFour, w1396_0, w1396_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1396 : Coverage 1396 1397 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1396)
private theorem w1397_0 : checkWitness 1397 false false 84 = true := by decide +kernel
private theorem w1397_2 : checkWitness 1397 true false 84 = true := by decide +kernel
private theorem cases1397 : checkFour 1397 (84,0,84,0) = true := by
  simp only [checkFour, w1397_0, w1397_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1397 : Coverage 1397 1398 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1397)
private theorem w1398_0 : checkWitness 1398 false false 573 = true := by decide +kernel
private theorem w1398_1 : checkWitness 1398 false true 4657 = true := by decide +kernel
private theorem w1398_2 : checkWitness 1398 true false 573 = true := by decide +kernel
private theorem w1398_3 : checkWitness 1398 true true 4657 = true := by decide +kernel
private theorem cases1398 : checkFour 1398 (573,4657,573,4657) = true := by
  simp only [checkFour, w1398_0, w1398_1, w1398_2, w1398_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1398 : Coverage 1398 1399 := checkList_sound (ws:=[(573,4657,573,4657)]) (by simpa only [checkList, Bool.and_true] using cases1398)
private theorem w1399_0 : checkWitness 1399 false false 8826 = true := by decide +kernel
private theorem w1399_2 : checkWitness 1399 true false 8822 = true := by decide +kernel
private theorem cases1399 : checkFour 1399 (8826,0,8822,0) = true := by
  simp only [checkFour, w1399_0, w1399_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1399 : Coverage 1399 1400 := checkList_sound (ws:=[(8826,0,8822,0)]) (by simpa only [checkList, Bool.and_true] using cases1399)
private theorem w1400_0 : checkWitness 1400 false false 84 = true := by decide +kernel
private theorem w1400_2 : checkWitness 1400 true false 84 = true := by decide +kernel
private theorem cases1400 : checkFour 1400 (84,0,84,0) = true := by
  simp only [checkFour, w1400_0, w1400_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1400 : Coverage 1400 1401 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1400)
private theorem w1401_0 : checkWitness 1401 false false 541 = true := by decide +kernel
private theorem w1401_1 : checkWitness 1401 false true 4637 = true := by decide +kernel
private theorem w1401_2 : checkWitness 1401 true false 541 = true := by decide +kernel
private theorem w1401_3 : checkWitness 1401 true true 4637 = true := by decide +kernel
private theorem cases1401 : checkFour 1401 (541,4637,541,4637) = true := by
  simp only [checkFour, w1401_0, w1401_1, w1401_2, w1401_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1401 : Coverage 1401 1402 := checkList_sound (ws:=[(541,4637,541,4637)]) (by simpa only [checkList, Bool.and_true] using cases1401)
private theorem w1402_0 : checkWitness 1402 false false 8894 = true := by decide +kernel
private theorem w1402_2 : checkWitness 1402 true false 8885 = true := by decide +kernel
private theorem cases1402 : checkFour 1402 (8894,0,8885,0) = true := by
  simp only [checkFour, w1402_0, w1402_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1402 : Coverage 1402 1403 := checkList_sound (ws:=[(8894,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1402)
private theorem w1403_0 : checkWitness 1403 false false 8840 = true := by decide +kernel
private theorem w1403_2 : checkWitness 1403 true false 8836 = true := by decide +kernel
private theorem cases1403 : checkFour 1403 (8840,0,8836,0) = true := by
  simp only [checkFour, w1403_0, w1403_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1403 : Coverage 1403 1404 := checkList_sound (ws:=[(8840,0,8836,0)]) (by simpa only [checkList, Bool.and_true] using cases1403)
private theorem w1404_0 : checkWitness 1404 false false 92 = true := by decide +kernel
private theorem w1404_2 : checkWitness 1404 true false 92 = true := by decide +kernel
private theorem cases1404 : checkFour 1404 (92,0,92,0) = true := by
  simp only [checkFour, w1404_0, w1404_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1404 : Coverage 1404 1405 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1404)
private theorem w1405_0 : checkWitness 1405 false false 624 = true := by decide +kernel
private theorem w1405_1 : checkWitness 1405 false true 4712 = true := by decide +kernel
private theorem w1405_2 : checkWitness 1405 true false 615 = true := by decide +kernel
private theorem w1405_3 : checkWitness 1405 true true 4703 = true := by decide +kernel
private theorem cases1405 : checkFour 1405 (624,4712,615,4703) = true := by
  simp only [checkFour, w1405_0, w1405_1, w1405_2, w1405_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1405 : Coverage 1405 1406 := checkList_sound (ws:=[(624,4712,615,4703)]) (by simpa only [checkList, Bool.and_true] using cases1405)
private theorem w1406_0 : checkWitness 1406 false false 8859 = true := by decide +kernel
private theorem w1406_2 : checkWitness 1406 true false 8855 = true := by decide +kernel
private theorem cases1406 : checkFour 1406 (8859,0,8855,0) = true := by
  simp only [checkFour, w1406_0, w1406_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1406 : Coverage 1406 1407 := checkList_sound (ws:=[(8859,0,8855,0)]) (by simpa only [checkList, Bool.and_true] using cases1406)
private theorem w1407_0 : checkWitness 1407 false false 82 = true := by decide +kernel
private theorem w1407_2 : checkWitness 1407 true false 82 = true := by decide +kernel
private theorem cases1407 : checkFour 1407 (82,0,82,0) = true := by
  simp only [checkFour, w1407_0, w1407_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1407 : Coverage 1407 1408 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1407)
theorem cover1376 : Coverage 1376 1408 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1376 one1377) (Coverage.join one1378 one1379)) (Coverage.join (Coverage.join one1380 one1381) (Coverage.join one1382 one1383))) (Coverage.join (Coverage.join (Coverage.join one1384 one1385) (Coverage.join one1386 one1387)) (Coverage.join (Coverage.join one1388 one1389) (Coverage.join one1390 one1391)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1392 one1393) (Coverage.join one1394 one1395)) (Coverage.join (Coverage.join one1396 one1397) (Coverage.join one1398 one1399))) (Coverage.join (Coverage.join (Coverage.join one1400 one1401) (Coverage.join one1402 one1403)) (Coverage.join (Coverage.join one1404 one1405) (Coverage.join one1406 one1407)))))
end NF181PA.Symbolic
