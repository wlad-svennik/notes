module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site2490Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2490 f r x y z) (slots617.atReg 2500 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2490 10 2500 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2490 2494 2491 f r (row_of_literal 2490 _ (by decide) RawRows.raw2490))
    (slots617.pos_y 2490 2494 2491 f r (row_of_literal 2490 _ (by decide) RawRows.raw2490))
    (slots617.inc_z 2491 2492 f r (row_of_literal 2491 _ (by decide) RawRows.raw2491) (Or.inl (by decide)))
    (slots617.inc_x 2492 2493 f r (row_of_literal 2492 _ (by decide) RawRows.raw2492) (Or.inl (by decide)))
    (slots617.jump 2493 2490 f r (row_of_literal 2493 _ (by decide) RawRows.raw2493))
    (slots617.zero_x 2494 2500 2495 f r (row_of_literal 2494 _ (by decide) RawRows.raw2494))
    (slots617.pos_x 2494 2500 2495 f r (row_of_literal 2494 _ (by decide) RawRows.raw2494))
    (slots617.inc_z 2495 2496 f r (row_of_literal 2495 _ (by decide) RawRows.raw2495) (Or.inl (by decide)))
    (slots617.zero_x 2496 2499 2497 f r (row_of_literal 2496 _ (by decide) RawRows.raw2496))
    (slots617.pos_x 2496 2499 2497 f r (row_of_literal 2496 _ (by decide) RawRows.raw2496))
    (slots617.inc_y 2497 2498 f r (row_of_literal 2497 _ (by decide) RawRows.raw2497) (Or.inl (by decide)))
    (slots617.jump 2498 2496 f r (row_of_literal 2498 _ (by decide) RawRows.raw2498))
    (slots617.jump 2499 2490 f r (row_of_literal 2499 _ (by decide) RawRows.raw2499))

theorem site2490 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2490:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2500:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2490Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2500Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2500 f r x y z) (slots720.atReg 2503 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2500 3 2503 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2500 2503 2501 f r (row_of_literal 2500 _ (by decide) RawRows.raw2500))
    (slots720.pos_x 2500 2503 2501 f r (row_of_literal 2500 _ (by decide) RawRows.raw2500))
    (slots720.inc_y 2501 2502 f r (row_of_literal 2501 _ (by decide) RawRows.raw2501) (Or.inl (by decide)))
    (slots720.jump 2502 2500 f r (row_of_literal 2502 _ (by decide) RawRows.raw2502))

theorem site2500 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2500:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2503:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2500Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2503Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2503 f r x y z) (slots461.atReg 2507 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2503 4 2507 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2503 2507 2504 f r (row_of_literal 2503 _ (by decide) RawRows.raw2503))
    (slots461.pos_x 2503 2507 2504 f r (row_of_literal 2503 _ (by decide) RawRows.raw2503))
    (slots461.inc_y 2504 2505 f r (row_of_literal 2504 _ (by decide) RawRows.raw2504) (Or.inl (by decide)))
    (slots461.inc_z 2505 2506 f r (row_of_literal 2505 _ (by decide) RawRows.raw2505) (Or.inl (by decide)))
    (slots461.jump 2506 2503 f r (row_of_literal 2506 _ (by decide) RawRows.raw2506))

theorem site2503 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2503:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2507:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2503Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site2507Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2507 f r x y z) (slots640.atReg 2510 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2507 3 2510 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2507 2510 2508 f r (row_of_literal 2507 _ (by decide) RawRows.raw2507))
    (slots640.pos_x 2507 2510 2508 f r (row_of_literal 2507 _ (by decide) RawRows.raw2507))
    (slots640.inc_y 2508 2509 f r (row_of_literal 2508 _ (by decide) RawRows.raw2508) (Or.inl (by decide)))
    (slots640.jump 2509 2507 f r (row_of_literal 2509 _ (by decide) RawRows.raw2509))

theorem site2507 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2507:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2510:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2507Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site2510Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2510 f r x y z) (slots160.atReg 2513 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2510 3 2513 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2510 2513 2511 f r (row_of_literal 2510 _ (by decide) RawRows.raw2510))
    (slots160.pos_x 2510 2513 2511 f r (row_of_literal 2510 _ (by decide) RawRows.raw2510))
    (slots160.inc_y 2511 2512 f r (row_of_literal 2511 _ (by decide) RawRows.raw2511) (Or.inl (by decide)))
    (slots160.jump 2512 2510 f r (row_of_literal 2512 _ (by decide) RawRows.raw2512))

theorem site2510 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2510:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2513:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2510Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2513Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2513 f r x y z) (slots210.atReg 2516 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2513 3 2516 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2513 2516 2514 f r (row_of_literal 2513 _ (by decide) RawRows.raw2513))
    (slots210.pos_x 2513 2516 2514 f r (row_of_literal 2513 _ (by decide) RawRows.raw2513))
    (slots210.inc_y 2514 2515 f r (row_of_literal 2514 _ (by decide) RawRows.raw2514) (Or.inl (by decide)))
    (slots210.jump 2515 2513 f r (row_of_literal 2515 _ (by decide) RawRows.raw2515))

theorem site2513 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2513:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2516:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2513Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2516Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2516 f r x y z) (slots617.atReg 2526 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2516 10 2526 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2516 2520 2517 f r (row_of_literal 2516 _ (by decide) RawRows.raw2516))
    (slots617.pos_y 2516 2520 2517 f r (row_of_literal 2516 _ (by decide) RawRows.raw2516))
    (slots617.inc_z 2517 2518 f r (row_of_literal 2517 _ (by decide) RawRows.raw2517) (Or.inl (by decide)))
    (slots617.inc_x 2518 2519 f r (row_of_literal 2518 _ (by decide) RawRows.raw2518) (Or.inl (by decide)))
    (slots617.jump 2519 2516 f r (row_of_literal 2519 _ (by decide) RawRows.raw2519))
    (slots617.zero_x 2520 2526 2521 f r (row_of_literal 2520 _ (by decide) RawRows.raw2520))
    (slots617.pos_x 2520 2526 2521 f r (row_of_literal 2520 _ (by decide) RawRows.raw2520))
    (slots617.inc_z 2521 2522 f r (row_of_literal 2521 _ (by decide) RawRows.raw2521) (Or.inl (by decide)))
    (slots617.zero_x 2522 2525 2523 f r (row_of_literal 2522 _ (by decide) RawRows.raw2522))
    (slots617.pos_x 2522 2525 2523 f r (row_of_literal 2522 _ (by decide) RawRows.raw2522))
    (slots617.inc_y 2523 2524 f r (row_of_literal 2523 _ (by decide) RawRows.raw2523) (Or.inl (by decide)))
    (slots617.jump 2524 2522 f r (row_of_literal 2524 _ (by decide) RawRows.raw2524))
    (slots617.jump 2525 2516 f r (row_of_literal 2525 _ (by decide) RawRows.raw2525))

theorem site2516 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2516:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2526:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2516Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2526Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2526 f r x y z) (slots720.atReg 2529 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2526 3 2529 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2526 2529 2527 f r (row_of_literal 2526 _ (by decide) RawRows.raw2526))
    (slots720.pos_x 2526 2529 2527 f r (row_of_literal 2526 _ (by decide) RawRows.raw2526))
    (slots720.inc_y 2527 2528 f r (row_of_literal 2527 _ (by decide) RawRows.raw2527) (Or.inl (by decide)))
    (slots720.jump 2528 2526 f r (row_of_literal 2528 _ (by decide) RawRows.raw2528))

theorem site2526 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2526:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2529:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2526Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2529Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2529 f r x y z) (slots561.atReg 2533 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2529 4 2533 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2529 2533 2530 f r (row_of_literal 2529 _ (by decide) RawRows.raw2529))
    (slots561.pos_x 2529 2533 2530 f r (row_of_literal 2529 _ (by decide) RawRows.raw2529))
    (slots561.inc_y 2530 2531 f r (row_of_literal 2530 _ (by decide) RawRows.raw2530) (Or.inl (by decide)))
    (slots561.inc_z 2531 2532 f r (row_of_literal 2531 _ (by decide) RawRows.raw2531) (Or.inl (by decide)))
    (slots561.jump 2532 2529 f r (row_of_literal 2532 _ (by decide) RawRows.raw2532))

theorem site2529 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2529:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2533:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2529Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2533Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2533 f r x y z) (slots650.atReg 2536 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2533 3 2536 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2533 2536 2534 f r (row_of_literal 2533 _ (by decide) RawRows.raw2533))
    (slots650.pos_x 2533 2536 2534 f r (row_of_literal 2533 _ (by decide) RawRows.raw2533))
    (slots650.inc_y 2534 2535 f r (row_of_literal 2534 _ (by decide) RawRows.raw2534) (Or.inl (by decide)))
    (slots650.jump 2535 2533 f r (row_of_literal 2535 _ (by decide) RawRows.raw2535))

theorem site2533 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2533:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2536:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2533Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2536Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2536 f r x y z) (slots267.atReg 2544 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2536 8 2544 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2536 2544 2537 f r (row_of_literal 2536 _ (by decide) RawRows.raw2536))
    (slots267.pos_x 2536 2544 2537 f r (row_of_literal 2536 _ (by decide) RawRows.raw2536))
    (slots267.inc_z 2537 2538 f r (row_of_literal 2537 _ (by decide) RawRows.raw2537) (Or.inl (by decide)))
    (slots267.zero_y 2538 2540 2539 f r (row_of_literal 2538 _ (by decide) RawRows.raw2538))
    (slots267.pos_y 2538 2540 2539 f r (row_of_literal 2538 _ (by decide) RawRows.raw2538))
    (slots267.jump 2539 2543 f r (row_of_literal 2539 _ (by decide) RawRows.raw2539))
    (slots267.zero_z 2540 2543 2541 f r (row_of_literal 2540 _ (by decide) RawRows.raw2540))
    (slots267.pos_z 2540 2543 2541 f r (row_of_literal 2540 _ (by decide) RawRows.raw2540))
    (slots267.inc_y 2541 2542 f r (row_of_literal 2541 _ (by decide) RawRows.raw2541) (Or.inl (by decide)))
    (slots267.jump 2542 2540 f r (row_of_literal 2542 _ (by decide) RawRows.raw2542))
    (slots267.jump 2543 2536 f r (row_of_literal 2543 _ (by decide) RawRows.raw2543))

theorem site2536 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2536:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2544:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2536Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2544Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2544 f r x y z) (slots720.atReg 2547 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2544 3 2547 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2544 2547 2545 f r (row_of_literal 2544 _ (by decide) RawRows.raw2544))
    (slots720.pos_x 2544 2547 2545 f r (row_of_literal 2544 _ (by decide) RawRows.raw2544))
    (slots720.inc_y 2545 2546 f r (row_of_literal 2545 _ (by decide) RawRows.raw2545) (Or.inl (by decide)))
    (slots720.jump 2546 2544 f r (row_of_literal 2546 _ (by decide) RawRows.raw2546))

theorem site2544 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2544:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2547:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2544Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2547Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2547 f r x y z) (slots617.atReg 2557 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2547 10 2557 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2547 2551 2548 f r (row_of_literal 2547 _ (by decide) RawRows.raw2547))
    (slots617.pos_y 2547 2551 2548 f r (row_of_literal 2547 _ (by decide) RawRows.raw2547))
    (slots617.inc_z 2548 2549 f r (row_of_literal 2548 _ (by decide) RawRows.raw2548) (Or.inl (by decide)))
    (slots617.inc_x 2549 2550 f r (row_of_literal 2549 _ (by decide) RawRows.raw2549) (Or.inl (by decide)))
    (slots617.jump 2550 2547 f r (row_of_literal 2550 _ (by decide) RawRows.raw2550))
    (slots617.zero_x 2551 2557 2552 f r (row_of_literal 2551 _ (by decide) RawRows.raw2551))
    (slots617.pos_x 2551 2557 2552 f r (row_of_literal 2551 _ (by decide) RawRows.raw2551))
    (slots617.inc_z 2552 2553 f r (row_of_literal 2552 _ (by decide) RawRows.raw2552) (Or.inl (by decide)))
    (slots617.zero_x 2553 2556 2554 f r (row_of_literal 2553 _ (by decide) RawRows.raw2553))
    (slots617.pos_x 2553 2556 2554 f r (row_of_literal 2553 _ (by decide) RawRows.raw2553))
    (slots617.inc_y 2554 2555 f r (row_of_literal 2554 _ (by decide) RawRows.raw2554) (Or.inl (by decide)))
    (slots617.jump 2555 2553 f r (row_of_literal 2555 _ (by decide) RawRows.raw2555))
    (slots617.jump 2556 2547 f r (row_of_literal 2556 _ (by decide) RawRows.raw2556))

theorem site2547 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2547:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2557:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2547Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2557Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2557 f r x y z) (slots710.atReg 2561 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2557 4 2561 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2557 2561 2558 f r (row_of_literal 2557 _ (by decide) RawRows.raw2557))
    (slots710.pos_x 2557 2561 2558 f r (row_of_literal 2557 _ (by decide) RawRows.raw2557))
    (slots710.inc_y 2558 2559 f r (row_of_literal 2558 _ (by decide) RawRows.raw2558) (Or.inl (by decide)))
    (slots710.inc_y 2559 2560 f r (row_of_literal 2559 _ (by decide) RawRows.raw2559) (Or.inl (by decide)))
    (slots710.jump 2560 2557 f r (row_of_literal 2560 _ (by decide) RawRows.raw2560))

theorem site2557 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2557:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2561:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2557Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2561 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2561:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2562:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2561 _ (row_of_literal 2561 _ (by decide) RawRows.raw2561)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site2562 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2562:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2563:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2562 _ (row_of_literal 2562 _ (by decide) RawRows.raw2562)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2563Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2563 f r x y z) (slots267.atReg 2571 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2563 8 2571 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2563 2571 2564 f r (row_of_literal 2563 _ (by decide) RawRows.raw2563))
    (slots267.pos_x 2563 2571 2564 f r (row_of_literal 2563 _ (by decide) RawRows.raw2563))
    (slots267.inc_z 2564 2565 f r (row_of_literal 2564 _ (by decide) RawRows.raw2564) (Or.inl (by decide)))
    (slots267.zero_y 2565 2567 2566 f r (row_of_literal 2565 _ (by decide) RawRows.raw2565))
    (slots267.pos_y 2565 2567 2566 f r (row_of_literal 2565 _ (by decide) RawRows.raw2565))
    (slots267.jump 2566 2570 f r (row_of_literal 2566 _ (by decide) RawRows.raw2566))
    (slots267.zero_z 2567 2570 2568 f r (row_of_literal 2567 _ (by decide) RawRows.raw2567))
    (slots267.pos_z 2567 2570 2568 f r (row_of_literal 2567 _ (by decide) RawRows.raw2567))
    (slots267.inc_y 2568 2569 f r (row_of_literal 2568 _ (by decide) RawRows.raw2568) (Or.inl (by decide)))
    (slots267.jump 2569 2567 f r (row_of_literal 2569 _ (by decide) RawRows.raw2569))
    (slots267.jump 2570 2563 f r (row_of_literal 2570 _ (by decide) RawRows.raw2570))

theorem site2563 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2563:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2571:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2563Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2571Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2571 f r x y z) (slots720.atReg 2574 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2571 3 2574 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2571 2574 2572 f r (row_of_literal 2571 _ (by decide) RawRows.raw2571))
    (slots720.pos_x 2571 2574 2572 f r (row_of_literal 2571 _ (by decide) RawRows.raw2571))
    (slots720.inc_y 2572 2573 f r (row_of_literal 2572 _ (by decide) RawRows.raw2572) (Or.inl (by decide)))
    (slots720.jump 2573 2571 f r (row_of_literal 2573 _ (by decide) RawRows.raw2573))

theorem site2571 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2571:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2574:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2571Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2574Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2574 f r x y z) (slots617.atReg 2584 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2574 10 2584 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2574 2578 2575 f r (row_of_literal 2574 _ (by decide) RawRows.raw2574))
    (slots617.pos_y 2574 2578 2575 f r (row_of_literal 2574 _ (by decide) RawRows.raw2574))
    (slots617.inc_z 2575 2576 f r (row_of_literal 2575 _ (by decide) RawRows.raw2575) (Or.inl (by decide)))
    (slots617.inc_x 2576 2577 f r (row_of_literal 2576 _ (by decide) RawRows.raw2576) (Or.inl (by decide)))
    (slots617.jump 2577 2574 f r (row_of_literal 2577 _ (by decide) RawRows.raw2577))
    (slots617.zero_x 2578 2584 2579 f r (row_of_literal 2578 _ (by decide) RawRows.raw2578))
    (slots617.pos_x 2578 2584 2579 f r (row_of_literal 2578 _ (by decide) RawRows.raw2578))
    (slots617.inc_z 2579 2580 f r (row_of_literal 2579 _ (by decide) RawRows.raw2579) (Or.inl (by decide)))
    (slots617.zero_x 2580 2583 2581 f r (row_of_literal 2580 _ (by decide) RawRows.raw2580))
    (slots617.pos_x 2580 2583 2581 f r (row_of_literal 2580 _ (by decide) RawRows.raw2580))
    (slots617.inc_y 2581 2582 f r (row_of_literal 2581 _ (by decide) RawRows.raw2581) (Or.inl (by decide)))
    (slots617.jump 2582 2580 f r (row_of_literal 2582 _ (by decide) RawRows.raw2582))
    (slots617.jump 2583 2574 f r (row_of_literal 2583 _ (by decide) RawRows.raw2583))

theorem site2574 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2574:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2584:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2574Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2584Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2584 f r x y z) (slots710.atReg 2588 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2584 4 2588 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2584 2588 2585 f r (row_of_literal 2584 _ (by decide) RawRows.raw2584))
    (slots710.pos_x 2584 2588 2585 f r (row_of_literal 2584 _ (by decide) RawRows.raw2584))
    (slots710.inc_y 2585 2586 f r (row_of_literal 2585 _ (by decide) RawRows.raw2585) (Or.inl (by decide)))
    (slots710.inc_y 2586 2587 f r (row_of_literal 2586 _ (by decide) RawRows.raw2586) (Or.inl (by decide)))
    (slots710.jump 2587 2584 f r (row_of_literal 2587 _ (by decide) RawRows.raw2587))

theorem site2584 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2584:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2588:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2584Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2588 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2588:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2589:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2588 _ (row_of_literal 2588 _ (by decide) RawRows.raw2588)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2589Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2589 f r x y z) (slots160.atReg 2592 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2589 3 2592 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2589 2592 2590 f r (row_of_literal 2589 _ (by decide) RawRows.raw2589))
    (slots160.pos_x 2589 2592 2590 f r (row_of_literal 2589 _ (by decide) RawRows.raw2589))
    (slots160.inc_y 2590 2591 f r (row_of_literal 2590 _ (by decide) RawRows.raw2590) (Or.inl (by decide)))
    (slots160.jump 2591 2589 f r (row_of_literal 2591 _ (by decide) RawRows.raw2591))

theorem site2589 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2589:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2592:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2589Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2592Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2592 f r x y z) (slots210.atReg 2595 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2592 3 2595 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2592 2595 2593 f r (row_of_literal 2592 _ (by decide) RawRows.raw2592))
    (slots210.pos_x 2592 2595 2593 f r (row_of_literal 2592 _ (by decide) RawRows.raw2592))
    (slots210.inc_y 2593 2594 f r (row_of_literal 2593 _ (by decide) RawRows.raw2593) (Or.inl (by decide)))
    (slots210.jump 2594 2592 f r (row_of_literal 2594 _ (by decide) RawRows.raw2594))

theorem site2592 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2592:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2595:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2592Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2595Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2595 f r x y z) (slots617.atReg 2605 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2595 10 2605 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2595 2599 2596 f r (row_of_literal 2595 _ (by decide) RawRows.raw2595))
    (slots617.pos_y 2595 2599 2596 f r (row_of_literal 2595 _ (by decide) RawRows.raw2595))
    (slots617.inc_z 2596 2597 f r (row_of_literal 2596 _ (by decide) RawRows.raw2596) (Or.inl (by decide)))
    (slots617.inc_x 2597 2598 f r (row_of_literal 2597 _ (by decide) RawRows.raw2597) (Or.inl (by decide)))
    (slots617.jump 2598 2595 f r (row_of_literal 2598 _ (by decide) RawRows.raw2598))
    (slots617.zero_x 2599 2605 2600 f r (row_of_literal 2599 _ (by decide) RawRows.raw2599))
    (slots617.pos_x 2599 2605 2600 f r (row_of_literal 2599 _ (by decide) RawRows.raw2599))
    (slots617.inc_z 2600 2601 f r (row_of_literal 2600 _ (by decide) RawRows.raw2600) (Or.inl (by decide)))
    (slots617.zero_x 2601 2604 2602 f r (row_of_literal 2601 _ (by decide) RawRows.raw2601))
    (slots617.pos_x 2601 2604 2602 f r (row_of_literal 2601 _ (by decide) RawRows.raw2601))
    (slots617.inc_y 2602 2603 f r (row_of_literal 2602 _ (by decide) RawRows.raw2602) (Or.inl (by decide)))
    (slots617.jump 2603 2601 f r (row_of_literal 2603 _ (by decide) RawRows.raw2603))
    (slots617.jump 2604 2595 f r (row_of_literal 2604 _ (by decide) RawRows.raw2604))

theorem site2595 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2595:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2605:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2595Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2605Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2605 f r x y z) (slots720.atReg 2608 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2605 3 2608 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2605 2608 2606 f r (row_of_literal 2605 _ (by decide) RawRows.raw2605))
    (slots720.pos_x 2605 2608 2606 f r (row_of_literal 2605 _ (by decide) RawRows.raw2605))
    (slots720.inc_y 2606 2607 f r (row_of_literal 2606 _ (by decide) RawRows.raw2606) (Or.inl (by decide)))
    (slots720.jump 2607 2605 f r (row_of_literal 2607 _ (by decide) RawRows.raw2607))

theorem site2605 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2605:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2608:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2605Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2608Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2608 f r x y z) (slots461.atReg 2612 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2608 4 2612 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2608 2612 2609 f r (row_of_literal 2608 _ (by decide) RawRows.raw2608))
    (slots461.pos_x 2608 2612 2609 f r (row_of_literal 2608 _ (by decide) RawRows.raw2608))
    (slots461.inc_y 2609 2610 f r (row_of_literal 2609 _ (by decide) RawRows.raw2609) (Or.inl (by decide)))
    (slots461.inc_z 2610 2611 f r (row_of_literal 2610 _ (by decide) RawRows.raw2610) (Or.inl (by decide)))
    (slots461.jump 2611 2608 f r (row_of_literal 2611 _ (by decide) RawRows.raw2611))

theorem site2608 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2608:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2612:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2608Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site2612Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2612 f r x y z) (slots640.atReg 2615 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2612 3 2615 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2612 2615 2613 f r (row_of_literal 2612 _ (by decide) RawRows.raw2612))
    (slots640.pos_x 2612 2615 2613 f r (row_of_literal 2612 _ (by decide) RawRows.raw2612))
    (slots640.inc_y 2613 2614 f r (row_of_literal 2613 _ (by decide) RawRows.raw2613) (Or.inl (by decide)))
    (slots640.jump 2614 2612 f r (row_of_literal 2614 _ (by decide) RawRows.raw2614))

theorem site2612 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2612:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2615:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2612Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site2615Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2615 f r x y z) (slots160.atReg 2618 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2615 3 2618 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2615 2618 2616 f r (row_of_literal 2615 _ (by decide) RawRows.raw2615))
    (slots160.pos_x 2615 2618 2616 f r (row_of_literal 2615 _ (by decide) RawRows.raw2615))
    (slots160.inc_y 2616 2617 f r (row_of_literal 2616 _ (by decide) RawRows.raw2616) (Or.inl (by decide)))
    (slots160.jump 2617 2615 f r (row_of_literal 2617 _ (by decide) RawRows.raw2617))

theorem site2615 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2615:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2618:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2615Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2618Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2618 f r x y z) (slots210.atReg 2621 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2618 3 2621 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2618 2621 2619 f r (row_of_literal 2618 _ (by decide) RawRows.raw2618))
    (slots210.pos_x 2618 2621 2619 f r (row_of_literal 2618 _ (by decide) RawRows.raw2618))
    (slots210.inc_y 2619 2620 f r (row_of_literal 2619 _ (by decide) RawRows.raw2619) (Or.inl (by decide)))
    (slots210.jump 2620 2618 f r (row_of_literal 2620 _ (by decide) RawRows.raw2620))

theorem site2618 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2618:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2621:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2618Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2621Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2621 f r x y z) (slots617.atReg 2631 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2621 10 2631 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2621 2625 2622 f r (row_of_literal 2621 _ (by decide) RawRows.raw2621))
    (slots617.pos_y 2621 2625 2622 f r (row_of_literal 2621 _ (by decide) RawRows.raw2621))
    (slots617.inc_z 2622 2623 f r (row_of_literal 2622 _ (by decide) RawRows.raw2622) (Or.inl (by decide)))
    (slots617.inc_x 2623 2624 f r (row_of_literal 2623 _ (by decide) RawRows.raw2623) (Or.inl (by decide)))
    (slots617.jump 2624 2621 f r (row_of_literal 2624 _ (by decide) RawRows.raw2624))
    (slots617.zero_x 2625 2631 2626 f r (row_of_literal 2625 _ (by decide) RawRows.raw2625))
    (slots617.pos_x 2625 2631 2626 f r (row_of_literal 2625 _ (by decide) RawRows.raw2625))
    (slots617.inc_z 2626 2627 f r (row_of_literal 2626 _ (by decide) RawRows.raw2626) (Or.inl (by decide)))
    (slots617.zero_x 2627 2630 2628 f r (row_of_literal 2627 _ (by decide) RawRows.raw2627))
    (slots617.pos_x 2627 2630 2628 f r (row_of_literal 2627 _ (by decide) RawRows.raw2627))
    (slots617.inc_y 2628 2629 f r (row_of_literal 2628 _ (by decide) RawRows.raw2628) (Or.inl (by decide)))
    (slots617.jump 2629 2627 f r (row_of_literal 2629 _ (by decide) RawRows.raw2629))
    (slots617.jump 2630 2621 f r (row_of_literal 2630 _ (by decide) RawRows.raw2630))

theorem site2621 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2621:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2631:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2621Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2631Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2631 f r x y z) (slots720.atReg 2634 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2631 3 2634 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2631 2634 2632 f r (row_of_literal 2631 _ (by decide) RawRows.raw2631))
    (slots720.pos_x 2631 2634 2632 f r (row_of_literal 2631 _ (by decide) RawRows.raw2631))
    (slots720.inc_y 2632 2633 f r (row_of_literal 2632 _ (by decide) RawRows.raw2632) (Or.inl (by decide)))
    (slots720.jump 2633 2631 f r (row_of_literal 2633 _ (by decide) RawRows.raw2633))

theorem site2631 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2631:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2634:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2631Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2634Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2634 f r x y z) (slots461.atReg 2638 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2634 4 2638 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2634 2638 2635 f r (row_of_literal 2634 _ (by decide) RawRows.raw2634))
    (slots461.pos_x 2634 2638 2635 f r (row_of_literal 2634 _ (by decide) RawRows.raw2634))
    (slots461.inc_y 2635 2636 f r (row_of_literal 2635 _ (by decide) RawRows.raw2635) (Or.inl (by decide)))
    (slots461.inc_z 2636 2637 f r (row_of_literal 2636 _ (by decide) RawRows.raw2636) (Or.inl (by decide)))
    (slots461.jump 2637 2634 f r (row_of_literal 2637 _ (by decide) RawRows.raw2637))

theorem site2634 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2634:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2638:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2634Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site2638Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2638 f r x y z) (slots640.atReg 2641 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2638 3 2641 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2638 2641 2639 f r (row_of_literal 2638 _ (by decide) RawRows.raw2638))
    (slots640.pos_x 2638 2641 2639 f r (row_of_literal 2638 _ (by decide) RawRows.raw2638))
    (slots640.inc_y 2639 2640 f r (row_of_literal 2639 _ (by decide) RawRows.raw2639) (Or.inl (by decide)))
    (slots640.jump 2640 2638 f r (row_of_literal 2640 _ (by decide) RawRows.raw2640))

theorem site2638 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2638:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2641:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2638Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site2641Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2641 f r x y z) (slots160.atReg 2644 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2641 3 2644 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2641 2644 2642 f r (row_of_literal 2641 _ (by decide) RawRows.raw2641))
    (slots160.pos_x 2641 2644 2642 f r (row_of_literal 2641 _ (by decide) RawRows.raw2641))
    (slots160.inc_y 2642 2643 f r (row_of_literal 2642 _ (by decide) RawRows.raw2642) (Or.inl (by decide)))
    (slots160.jump 2643 2641 f r (row_of_literal 2643 _ (by decide) RawRows.raw2643))

theorem site2641 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2641:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2644:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2641Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2644Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2644 f r x y z) (slots210.atReg 2647 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2644 3 2647 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2644 2647 2645 f r (row_of_literal 2644 _ (by decide) RawRows.raw2644))
    (slots210.pos_x 2644 2647 2645 f r (row_of_literal 2644 _ (by decide) RawRows.raw2644))
    (slots210.inc_y 2645 2646 f r (row_of_literal 2645 _ (by decide) RawRows.raw2645) (Or.inl (by decide)))
    (slots210.jump 2646 2644 f r (row_of_literal 2646 _ (by decide) RawRows.raw2646))

theorem site2644 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2644:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2647:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2644Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2647Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2647 f r x y z) (slots617.atReg 2657 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2647 10 2657 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2647 2651 2648 f r (row_of_literal 2647 _ (by decide) RawRows.raw2647))
    (slots617.pos_y 2647 2651 2648 f r (row_of_literal 2647 _ (by decide) RawRows.raw2647))
    (slots617.inc_z 2648 2649 f r (row_of_literal 2648 _ (by decide) RawRows.raw2648) (Or.inl (by decide)))
    (slots617.inc_x 2649 2650 f r (row_of_literal 2649 _ (by decide) RawRows.raw2649) (Or.inl (by decide)))
    (slots617.jump 2650 2647 f r (row_of_literal 2650 _ (by decide) RawRows.raw2650))
    (slots617.zero_x 2651 2657 2652 f r (row_of_literal 2651 _ (by decide) RawRows.raw2651))
    (slots617.pos_x 2651 2657 2652 f r (row_of_literal 2651 _ (by decide) RawRows.raw2651))
    (slots617.inc_z 2652 2653 f r (row_of_literal 2652 _ (by decide) RawRows.raw2652) (Or.inl (by decide)))
    (slots617.zero_x 2653 2656 2654 f r (row_of_literal 2653 _ (by decide) RawRows.raw2653))
    (slots617.pos_x 2653 2656 2654 f r (row_of_literal 2653 _ (by decide) RawRows.raw2653))
    (slots617.inc_y 2654 2655 f r (row_of_literal 2654 _ (by decide) RawRows.raw2654) (Or.inl (by decide)))
    (slots617.jump 2655 2653 f r (row_of_literal 2655 _ (by decide) RawRows.raw2655))
    (slots617.jump 2656 2647 f r (row_of_literal 2656 _ (by decide) RawRows.raw2656))

theorem site2647 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2647:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2657:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2647Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2657Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2657 f r x y z) (slots720.atReg 2660 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2657 3 2660 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2657 2660 2658 f r (row_of_literal 2657 _ (by decide) RawRows.raw2657))
    (slots720.pos_x 2657 2660 2658 f r (row_of_literal 2657 _ (by decide) RawRows.raw2657))
    (slots720.inc_y 2658 2659 f r (row_of_literal 2658 _ (by decide) RawRows.raw2658) (Or.inl (by decide)))
    (slots720.jump 2659 2657 f r (row_of_literal 2659 _ (by decide) RawRows.raw2659))

theorem site2657 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2657:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2660:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2657Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2660Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2660 f r x y z) (slots561.atReg 2664 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2660 4 2664 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2660 2664 2661 f r (row_of_literal 2660 _ (by decide) RawRows.raw2660))
    (slots561.pos_x 2660 2664 2661 f r (row_of_literal 2660 _ (by decide) RawRows.raw2660))
    (slots561.inc_y 2661 2662 f r (row_of_literal 2661 _ (by decide) RawRows.raw2661) (Or.inl (by decide)))
    (slots561.inc_z 2662 2663 f r (row_of_literal 2662 _ (by decide) RawRows.raw2662) (Or.inl (by decide)))
    (slots561.jump 2663 2660 f r (row_of_literal 2663 _ (by decide) RawRows.raw2663))

theorem site2660 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2660:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2664:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2660Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2664Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2664 f r x y z) (slots650.atReg 2667 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2664 3 2667 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2664 2667 2665 f r (row_of_literal 2664 _ (by decide) RawRows.raw2664))
    (slots650.pos_x 2664 2667 2665 f r (row_of_literal 2664 _ (by decide) RawRows.raw2664))
    (slots650.inc_y 2665 2666 f r (row_of_literal 2665 _ (by decide) RawRows.raw2665) (Or.inl (by decide)))
    (slots650.jump 2666 2664 f r (row_of_literal 2666 _ (by decide) RawRows.raw2666))

theorem site2664 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2664:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2667:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2664Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2667Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2667 f r x y z) (slots267.atReg 2675 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2667 8 2675 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2667 2675 2668 f r (row_of_literal 2667 _ (by decide) RawRows.raw2667))
    (slots267.pos_x 2667 2675 2668 f r (row_of_literal 2667 _ (by decide) RawRows.raw2667))
    (slots267.inc_z 2668 2669 f r (row_of_literal 2668 _ (by decide) RawRows.raw2668) (Or.inl (by decide)))
    (slots267.zero_y 2669 2671 2670 f r (row_of_literal 2669 _ (by decide) RawRows.raw2669))
    (slots267.pos_y 2669 2671 2670 f r (row_of_literal 2669 _ (by decide) RawRows.raw2669))
    (slots267.jump 2670 2674 f r (row_of_literal 2670 _ (by decide) RawRows.raw2670))
    (slots267.zero_z 2671 2674 2672 f r (row_of_literal 2671 _ (by decide) RawRows.raw2671))
    (slots267.pos_z 2671 2674 2672 f r (row_of_literal 2671 _ (by decide) RawRows.raw2671))
    (slots267.inc_y 2672 2673 f r (row_of_literal 2672 _ (by decide) RawRows.raw2672) (Or.inl (by decide)))
    (slots267.jump 2673 2671 f r (row_of_literal 2673 _ (by decide) RawRows.raw2673))
    (slots267.jump 2674 2667 f r (row_of_literal 2674 _ (by decide) RawRows.raw2674))

theorem site2667 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2667:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2675:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2667Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2675Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2675 f r x y z) (slots720.atReg 2678 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2675 3 2678 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2675 2678 2676 f r (row_of_literal 2675 _ (by decide) RawRows.raw2675))
    (slots720.pos_x 2675 2678 2676 f r (row_of_literal 2675 _ (by decide) RawRows.raw2675))
    (slots720.inc_y 2676 2677 f r (row_of_literal 2676 _ (by decide) RawRows.raw2676) (Or.inl (by decide)))
    (slots720.jump 2677 2675 f r (row_of_literal 2677 _ (by decide) RawRows.raw2677))

theorem site2675 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2675:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2678:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2675Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2678Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2678 f r x y z) (slots617.atReg 2688 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2678 10 2688 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2678 2682 2679 f r (row_of_literal 2678 _ (by decide) RawRows.raw2678))
    (slots617.pos_y 2678 2682 2679 f r (row_of_literal 2678 _ (by decide) RawRows.raw2678))
    (slots617.inc_z 2679 2680 f r (row_of_literal 2679 _ (by decide) RawRows.raw2679) (Or.inl (by decide)))
    (slots617.inc_x 2680 2681 f r (row_of_literal 2680 _ (by decide) RawRows.raw2680) (Or.inl (by decide)))
    (slots617.jump 2681 2678 f r (row_of_literal 2681 _ (by decide) RawRows.raw2681))
    (slots617.zero_x 2682 2688 2683 f r (row_of_literal 2682 _ (by decide) RawRows.raw2682))
    (slots617.pos_x 2682 2688 2683 f r (row_of_literal 2682 _ (by decide) RawRows.raw2682))
    (slots617.inc_z 2683 2684 f r (row_of_literal 2683 _ (by decide) RawRows.raw2683) (Or.inl (by decide)))
    (slots617.zero_x 2684 2687 2685 f r (row_of_literal 2684 _ (by decide) RawRows.raw2684))
    (slots617.pos_x 2684 2687 2685 f r (row_of_literal 2684 _ (by decide) RawRows.raw2684))
    (slots617.inc_y 2685 2686 f r (row_of_literal 2685 _ (by decide) RawRows.raw2685) (Or.inl (by decide)))
    (slots617.jump 2686 2684 f r (row_of_literal 2686 _ (by decide) RawRows.raw2686))
    (slots617.jump 2687 2678 f r (row_of_literal 2687 _ (by decide) RawRows.raw2687))

theorem site2678 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2678:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2688:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2678Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2688Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2688 f r x y z) (slots710.atReg 2692 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2688 4 2692 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2688 2692 2689 f r (row_of_literal 2688 _ (by decide) RawRows.raw2688))
    (slots710.pos_x 2688 2692 2689 f r (row_of_literal 2688 _ (by decide) RawRows.raw2688))
    (slots710.inc_y 2689 2690 f r (row_of_literal 2689 _ (by decide) RawRows.raw2689) (Or.inl (by decide)))
    (slots710.inc_y 2690 2691 f r (row_of_literal 2690 _ (by decide) RawRows.raw2690) (Or.inl (by decide)))
    (slots710.jump 2691 2688 f r (row_of_literal 2691 _ (by decide) RawRows.raw2691))

theorem site2688 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2688:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2692:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2688Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2692 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2692:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2693:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2692 _ (row_of_literal 2692 _ (by decide) RawRows.raw2692)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site2693 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2693:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2694:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2693 _ (row_of_literal 2693 _ (by decide) RawRows.raw2693)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2694Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2694 f r x y z) (slots267.atReg 2702 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2694 8 2702 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2694 2702 2695 f r (row_of_literal 2694 _ (by decide) RawRows.raw2694))
    (slots267.pos_x 2694 2702 2695 f r (row_of_literal 2694 _ (by decide) RawRows.raw2694))
    (slots267.inc_z 2695 2696 f r (row_of_literal 2695 _ (by decide) RawRows.raw2695) (Or.inl (by decide)))
    (slots267.zero_y 2696 2698 2697 f r (row_of_literal 2696 _ (by decide) RawRows.raw2696))
    (slots267.pos_y 2696 2698 2697 f r (row_of_literal 2696 _ (by decide) RawRows.raw2696))
    (slots267.jump 2697 2701 f r (row_of_literal 2697 _ (by decide) RawRows.raw2697))
    (slots267.zero_z 2698 2701 2699 f r (row_of_literal 2698 _ (by decide) RawRows.raw2698))
    (slots267.pos_z 2698 2701 2699 f r (row_of_literal 2698 _ (by decide) RawRows.raw2698))
    (slots267.inc_y 2699 2700 f r (row_of_literal 2699 _ (by decide) RawRows.raw2699) (Or.inl (by decide)))
    (slots267.jump 2700 2698 f r (row_of_literal 2700 _ (by decide) RawRows.raw2700))
    (slots267.jump 2701 2694 f r (row_of_literal 2701 _ (by decide) RawRows.raw2701))

theorem site2694 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2694:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2702:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2694Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2702Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2702 f r x y z) (slots720.atReg 2705 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2702 3 2705 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2702 2705 2703 f r (row_of_literal 2702 _ (by decide) RawRows.raw2702))
    (slots720.pos_x 2702 2705 2703 f r (row_of_literal 2702 _ (by decide) RawRows.raw2702))
    (slots720.inc_y 2703 2704 f r (row_of_literal 2703 _ (by decide) RawRows.raw2703) (Or.inl (by decide)))
    (slots720.jump 2704 2702 f r (row_of_literal 2704 _ (by decide) RawRows.raw2704))

theorem site2702 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2702:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2705:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2702Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2705Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2705 f r x y z) (slots617.atReg 2715 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2705 10 2715 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2705 2709 2706 f r (row_of_literal 2705 _ (by decide) RawRows.raw2705))
    (slots617.pos_y 2705 2709 2706 f r (row_of_literal 2705 _ (by decide) RawRows.raw2705))
    (slots617.inc_z 2706 2707 f r (row_of_literal 2706 _ (by decide) RawRows.raw2706) (Or.inl (by decide)))
    (slots617.inc_x 2707 2708 f r (row_of_literal 2707 _ (by decide) RawRows.raw2707) (Or.inl (by decide)))
    (slots617.jump 2708 2705 f r (row_of_literal 2708 _ (by decide) RawRows.raw2708))
    (slots617.zero_x 2709 2715 2710 f r (row_of_literal 2709 _ (by decide) RawRows.raw2709))
    (slots617.pos_x 2709 2715 2710 f r (row_of_literal 2709 _ (by decide) RawRows.raw2709))
    (slots617.inc_z 2710 2711 f r (row_of_literal 2710 _ (by decide) RawRows.raw2710) (Or.inl (by decide)))
    (slots617.zero_x 2711 2714 2712 f r (row_of_literal 2711 _ (by decide) RawRows.raw2711))
    (slots617.pos_x 2711 2714 2712 f r (row_of_literal 2711 _ (by decide) RawRows.raw2711))
    (slots617.inc_y 2712 2713 f r (row_of_literal 2712 _ (by decide) RawRows.raw2712) (Or.inl (by decide)))
    (slots617.jump 2713 2711 f r (row_of_literal 2713 _ (by decide) RawRows.raw2713))
    (slots617.jump 2714 2705 f r (row_of_literal 2714 _ (by decide) RawRows.raw2714))

theorem site2705 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2705:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2715:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2705Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2715Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2715 f r x y z) (slots710.atReg 2719 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2715 4 2719 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2715 2719 2716 f r (row_of_literal 2715 _ (by decide) RawRows.raw2715))
    (slots710.pos_x 2715 2719 2716 f r (row_of_literal 2715 _ (by decide) RawRows.raw2715))
    (slots710.inc_y 2716 2717 f r (row_of_literal 2716 _ (by decide) RawRows.raw2716) (Or.inl (by decide)))
    (slots710.inc_y 2717 2718 f r (row_of_literal 2717 _ (by decide) RawRows.raw2717) (Or.inl (by decide)))
    (slots710.jump 2718 2715 f r (row_of_literal 2718 _ (by decide) RawRows.raw2718))

theorem site2715 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2715:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2719:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2715Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2719 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2719:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2720:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2719 _ (row_of_literal 2719 _ (by decide) RawRows.raw2719)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2720Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2720 f r x y z) (slots267.atReg 2728 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2720 8 2728 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2720 2728 2721 f r (row_of_literal 2720 _ (by decide) RawRows.raw2720))
    (slots267.pos_x 2720 2728 2721 f r (row_of_literal 2720 _ (by decide) RawRows.raw2720))
    (slots267.inc_z 2721 2722 f r (row_of_literal 2721 _ (by decide) RawRows.raw2721) (Or.inl (by decide)))
    (slots267.zero_y 2722 2724 2723 f r (row_of_literal 2722 _ (by decide) RawRows.raw2722))
    (slots267.pos_y 2722 2724 2723 f r (row_of_literal 2722 _ (by decide) RawRows.raw2722))
    (slots267.jump 2723 2727 f r (row_of_literal 2723 _ (by decide) RawRows.raw2723))
    (slots267.zero_z 2724 2727 2725 f r (row_of_literal 2724 _ (by decide) RawRows.raw2724))
    (slots267.pos_z 2724 2727 2725 f r (row_of_literal 2724 _ (by decide) RawRows.raw2724))
    (slots267.inc_y 2725 2726 f r (row_of_literal 2725 _ (by decide) RawRows.raw2725) (Or.inl (by decide)))
    (slots267.jump 2726 2724 f r (row_of_literal 2726 _ (by decide) RawRows.raw2726))
    (slots267.jump 2727 2720 f r (row_of_literal 2727 _ (by decide) RawRows.raw2727))

theorem site2720 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2720:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2728:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2720Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2728Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2728 f r x y z) (slots720.atReg 2731 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2728 3 2731 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2728 2731 2729 f r (row_of_literal 2728 _ (by decide) RawRows.raw2728))
    (slots720.pos_x 2728 2731 2729 f r (row_of_literal 2728 _ (by decide) RawRows.raw2728))
    (slots720.inc_y 2729 2730 f r (row_of_literal 2729 _ (by decide) RawRows.raw2729) (Or.inl (by decide)))
    (slots720.jump 2730 2728 f r (row_of_literal 2730 _ (by decide) RawRows.raw2730))

theorem site2728 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2728:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2731:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2728Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2731Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2731 f r x y z) (slots617.atReg 2741 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2731 10 2741 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2731 2735 2732 f r (row_of_literal 2731 _ (by decide) RawRows.raw2731))
    (slots617.pos_y 2731 2735 2732 f r (row_of_literal 2731 _ (by decide) RawRows.raw2731))
    (slots617.inc_z 2732 2733 f r (row_of_literal 2732 _ (by decide) RawRows.raw2732) (Or.inl (by decide)))
    (slots617.inc_x 2733 2734 f r (row_of_literal 2733 _ (by decide) RawRows.raw2733) (Or.inl (by decide)))
    (slots617.jump 2734 2731 f r (row_of_literal 2734 _ (by decide) RawRows.raw2734))
    (slots617.zero_x 2735 2741 2736 f r (row_of_literal 2735 _ (by decide) RawRows.raw2735))
    (slots617.pos_x 2735 2741 2736 f r (row_of_literal 2735 _ (by decide) RawRows.raw2735))
    (slots617.inc_z 2736 2737 f r (row_of_literal 2736 _ (by decide) RawRows.raw2736) (Or.inl (by decide)))
    (slots617.zero_x 2737 2740 2738 f r (row_of_literal 2737 _ (by decide) RawRows.raw2737))
    (slots617.pos_x 2737 2740 2738 f r (row_of_literal 2737 _ (by decide) RawRows.raw2737))
    (slots617.inc_y 2738 2739 f r (row_of_literal 2738 _ (by decide) RawRows.raw2738) (Or.inl (by decide)))
    (slots617.jump 2739 2737 f r (row_of_literal 2739 _ (by decide) RawRows.raw2739))
    (slots617.jump 2740 2731 f r (row_of_literal 2740 _ (by decide) RawRows.raw2740))

theorem site2731 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2731:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2741:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2731Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


end PA192.ModelSearch.Register181.Certified
