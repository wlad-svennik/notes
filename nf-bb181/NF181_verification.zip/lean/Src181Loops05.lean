module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site1234Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1234 f r x y z) (slots720.atReg 1237 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1234 3 1237 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1234 1237 1235 f r (row_of_literal 1234 _ (by decide) RawRows.raw1234))
    (slots720.pos_x 1234 1237 1235 f r (row_of_literal 1234 _ (by decide) RawRows.raw1234))
    (slots720.inc_y 1235 1236 f r (row_of_literal 1235 _ (by decide) RawRows.raw1235) (Or.inl (by decide)))
    (slots720.jump 1236 1234 f r (row_of_literal 1236 _ (by decide) RawRows.raw1236))

theorem site1234 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1234:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1237:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1234Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1237Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1237 f r x y z) (slots617.atReg 1247 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1237 10 1247 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1237 1241 1238 f r (row_of_literal 1237 _ (by decide) RawRows.raw1237))
    (slots617.pos_y 1237 1241 1238 f r (row_of_literal 1237 _ (by decide) RawRows.raw1237))
    (slots617.inc_z 1238 1239 f r (row_of_literal 1238 _ (by decide) RawRows.raw1238) (Or.inl (by decide)))
    (slots617.inc_x 1239 1240 f r (row_of_literal 1239 _ (by decide) RawRows.raw1239) (Or.inl (by decide)))
    (slots617.jump 1240 1237 f r (row_of_literal 1240 _ (by decide) RawRows.raw1240))
    (slots617.zero_x 1241 1247 1242 f r (row_of_literal 1241 _ (by decide) RawRows.raw1241))
    (slots617.pos_x 1241 1247 1242 f r (row_of_literal 1241 _ (by decide) RawRows.raw1241))
    (slots617.inc_z 1242 1243 f r (row_of_literal 1242 _ (by decide) RawRows.raw1242) (Or.inl (by decide)))
    (slots617.zero_x 1243 1246 1244 f r (row_of_literal 1243 _ (by decide) RawRows.raw1243))
    (slots617.pos_x 1243 1246 1244 f r (row_of_literal 1243 _ (by decide) RawRows.raw1243))
    (slots617.inc_y 1244 1245 f r (row_of_literal 1244 _ (by decide) RawRows.raw1244) (Or.inl (by decide)))
    (slots617.jump 1245 1243 f r (row_of_literal 1245 _ (by decide) RawRows.raw1245))
    (slots617.jump 1246 1237 f r (row_of_literal 1246 _ (by decide) RawRows.raw1246))

theorem site1237 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1237:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1247:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1237Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1247Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1247 f r x y z) (slots710.atReg 1251 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1247 4 1251 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1247 1251 1248 f r (row_of_literal 1247 _ (by decide) RawRows.raw1247))
    (slots710.pos_x 1247 1251 1248 f r (row_of_literal 1247 _ (by decide) RawRows.raw1247))
    (slots710.inc_y 1248 1249 f r (row_of_literal 1248 _ (by decide) RawRows.raw1248) (Or.inl (by decide)))
    (slots710.inc_y 1249 1250 f r (row_of_literal 1249 _ (by decide) RawRows.raw1249) (Or.inl (by decide)))
    (slots710.jump 1250 1247 f r (row_of_literal 1250 _ (by decide) RawRows.raw1250))

theorem site1247 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1247:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1251:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1247Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1251 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1251:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1252:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1251 _ (row_of_literal 1251 _ (by decide) RawRows.raw1251)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1252Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1252 f r x y z) (slots267.atReg 1260 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1252 8 1260 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1252 1260 1253 f r (row_of_literal 1252 _ (by decide) RawRows.raw1252))
    (slots267.pos_x 1252 1260 1253 f r (row_of_literal 1252 _ (by decide) RawRows.raw1252))
    (slots267.inc_z 1253 1254 f r (row_of_literal 1253 _ (by decide) RawRows.raw1253) (Or.inl (by decide)))
    (slots267.zero_y 1254 1256 1255 f r (row_of_literal 1254 _ (by decide) RawRows.raw1254))
    (slots267.pos_y 1254 1256 1255 f r (row_of_literal 1254 _ (by decide) RawRows.raw1254))
    (slots267.jump 1255 1259 f r (row_of_literal 1255 _ (by decide) RawRows.raw1255))
    (slots267.zero_z 1256 1259 1257 f r (row_of_literal 1256 _ (by decide) RawRows.raw1256))
    (slots267.pos_z 1256 1259 1257 f r (row_of_literal 1256 _ (by decide) RawRows.raw1256))
    (slots267.inc_y 1257 1258 f r (row_of_literal 1257 _ (by decide) RawRows.raw1257) (Or.inl (by decide)))
    (slots267.jump 1258 1256 f r (row_of_literal 1258 _ (by decide) RawRows.raw1258))
    (slots267.jump 1259 1252 f r (row_of_literal 1259 _ (by decide) RawRows.raw1259))

theorem site1252 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1252:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1260:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1252Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1260Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1260 f r x y z) (slots720.atReg 1263 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1260 3 1263 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1260 1263 1261 f r (row_of_literal 1260 _ (by decide) RawRows.raw1260))
    (slots720.pos_x 1260 1263 1261 f r (row_of_literal 1260 _ (by decide) RawRows.raw1260))
    (slots720.inc_y 1261 1262 f r (row_of_literal 1261 _ (by decide) RawRows.raw1261) (Or.inl (by decide)))
    (slots720.jump 1262 1260 f r (row_of_literal 1262 _ (by decide) RawRows.raw1262))

theorem site1260 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1260:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1263:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1260Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1263Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1263 f r x y z) (slots617.atReg 1273 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1263 10 1273 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1263 1267 1264 f r (row_of_literal 1263 _ (by decide) RawRows.raw1263))
    (slots617.pos_y 1263 1267 1264 f r (row_of_literal 1263 _ (by decide) RawRows.raw1263))
    (slots617.inc_z 1264 1265 f r (row_of_literal 1264 _ (by decide) RawRows.raw1264) (Or.inl (by decide)))
    (slots617.inc_x 1265 1266 f r (row_of_literal 1265 _ (by decide) RawRows.raw1265) (Or.inl (by decide)))
    (slots617.jump 1266 1263 f r (row_of_literal 1266 _ (by decide) RawRows.raw1266))
    (slots617.zero_x 1267 1273 1268 f r (row_of_literal 1267 _ (by decide) RawRows.raw1267))
    (slots617.pos_x 1267 1273 1268 f r (row_of_literal 1267 _ (by decide) RawRows.raw1267))
    (slots617.inc_z 1268 1269 f r (row_of_literal 1268 _ (by decide) RawRows.raw1268) (Or.inl (by decide)))
    (slots617.zero_x 1269 1272 1270 f r (row_of_literal 1269 _ (by decide) RawRows.raw1269))
    (slots617.pos_x 1269 1272 1270 f r (row_of_literal 1269 _ (by decide) RawRows.raw1269))
    (slots617.inc_y 1270 1271 f r (row_of_literal 1270 _ (by decide) RawRows.raw1270) (Or.inl (by decide)))
    (slots617.jump 1271 1269 f r (row_of_literal 1271 _ (by decide) RawRows.raw1271))
    (slots617.jump 1272 1263 f r (row_of_literal 1272 _ (by decide) RawRows.raw1272))

theorem site1263 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1263:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1273:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1263Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1273Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1273 f r x y z) (slots710.atReg 1277 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1273 4 1277 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1273 1277 1274 f r (row_of_literal 1273 _ (by decide) RawRows.raw1273))
    (slots710.pos_x 1273 1277 1274 f r (row_of_literal 1273 _ (by decide) RawRows.raw1273))
    (slots710.inc_y 1274 1275 f r (row_of_literal 1274 _ (by decide) RawRows.raw1274) (Or.inl (by decide)))
    (slots710.inc_y 1275 1276 f r (row_of_literal 1275 _ (by decide) RawRows.raw1275) (Or.inl (by decide)))
    (slots710.jump 1276 1273 f r (row_of_literal 1276 _ (by decide) RawRows.raw1276))

theorem site1273 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1273:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1277:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1273Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1277 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1277:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1278:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1277 _ (row_of_literal 1277 _ (by decide) RawRows.raw1277)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1278Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1278 f r x y z) (slots267.atReg 1286 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1278 8 1286 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1278 1286 1279 f r (row_of_literal 1278 _ (by decide) RawRows.raw1278))
    (slots267.pos_x 1278 1286 1279 f r (row_of_literal 1278 _ (by decide) RawRows.raw1278))
    (slots267.inc_z 1279 1280 f r (row_of_literal 1279 _ (by decide) RawRows.raw1279) (Or.inl (by decide)))
    (slots267.zero_y 1280 1282 1281 f r (row_of_literal 1280 _ (by decide) RawRows.raw1280))
    (slots267.pos_y 1280 1282 1281 f r (row_of_literal 1280 _ (by decide) RawRows.raw1280))
    (slots267.jump 1281 1285 f r (row_of_literal 1281 _ (by decide) RawRows.raw1281))
    (slots267.zero_z 1282 1285 1283 f r (row_of_literal 1282 _ (by decide) RawRows.raw1282))
    (slots267.pos_z 1282 1285 1283 f r (row_of_literal 1282 _ (by decide) RawRows.raw1282))
    (slots267.inc_y 1283 1284 f r (row_of_literal 1283 _ (by decide) RawRows.raw1283) (Or.inl (by decide)))
    (slots267.jump 1284 1282 f r (row_of_literal 1284 _ (by decide) RawRows.raw1284))
    (slots267.jump 1285 1278 f r (row_of_literal 1285 _ (by decide) RawRows.raw1285))

theorem site1278 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1278:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1286:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1278Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1286Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1286 f r x y z) (slots720.atReg 1289 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1286 3 1289 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1286 1289 1287 f r (row_of_literal 1286 _ (by decide) RawRows.raw1286))
    (slots720.pos_x 1286 1289 1287 f r (row_of_literal 1286 _ (by decide) RawRows.raw1286))
    (slots720.inc_y 1287 1288 f r (row_of_literal 1287 _ (by decide) RawRows.raw1287) (Or.inl (by decide)))
    (slots720.jump 1288 1286 f r (row_of_literal 1288 _ (by decide) RawRows.raw1288))

theorem site1286 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1286:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1289:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1286Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1289Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1289 f r x y z) (slots617.atReg 1299 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1289 10 1299 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1289 1293 1290 f r (row_of_literal 1289 _ (by decide) RawRows.raw1289))
    (slots617.pos_y 1289 1293 1290 f r (row_of_literal 1289 _ (by decide) RawRows.raw1289))
    (slots617.inc_z 1290 1291 f r (row_of_literal 1290 _ (by decide) RawRows.raw1290) (Or.inl (by decide)))
    (slots617.inc_x 1291 1292 f r (row_of_literal 1291 _ (by decide) RawRows.raw1291) (Or.inl (by decide)))
    (slots617.jump 1292 1289 f r (row_of_literal 1292 _ (by decide) RawRows.raw1292))
    (slots617.zero_x 1293 1299 1294 f r (row_of_literal 1293 _ (by decide) RawRows.raw1293))
    (slots617.pos_x 1293 1299 1294 f r (row_of_literal 1293 _ (by decide) RawRows.raw1293))
    (slots617.inc_z 1294 1295 f r (row_of_literal 1294 _ (by decide) RawRows.raw1294) (Or.inl (by decide)))
    (slots617.zero_x 1295 1298 1296 f r (row_of_literal 1295 _ (by decide) RawRows.raw1295))
    (slots617.pos_x 1295 1298 1296 f r (row_of_literal 1295 _ (by decide) RawRows.raw1295))
    (slots617.inc_y 1296 1297 f r (row_of_literal 1296 _ (by decide) RawRows.raw1296) (Or.inl (by decide)))
    (slots617.jump 1297 1295 f r (row_of_literal 1297 _ (by decide) RawRows.raw1297))
    (slots617.jump 1298 1289 f r (row_of_literal 1298 _ (by decide) RawRows.raw1298))

theorem site1289 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1289:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1299:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1289Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1299Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1299 f r x y z) (slots710.atReg 1303 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1299 4 1303 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1299 1303 1300 f r (row_of_literal 1299 _ (by decide) RawRows.raw1299))
    (slots710.pos_x 1299 1303 1300 f r (row_of_literal 1299 _ (by decide) RawRows.raw1299))
    (slots710.inc_y 1300 1301 f r (row_of_literal 1300 _ (by decide) RawRows.raw1300) (Or.inl (by decide)))
    (slots710.inc_y 1301 1302 f r (row_of_literal 1301 _ (by decide) RawRows.raw1301) (Or.inl (by decide)))
    (slots710.jump 1302 1299 f r (row_of_literal 1302 _ (by decide) RawRows.raw1302))

theorem site1299 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1299:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1303:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1299Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1303 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1303:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1304:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1303 _ (row_of_literal 1303 _ (by decide) RawRows.raw1303)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1304Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1304 f r x y z) (slots160.atReg 1307 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1304 3 1307 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1304 1307 1305 f r (row_of_literal 1304 _ (by decide) RawRows.raw1304))
    (slots160.pos_x 1304 1307 1305 f r (row_of_literal 1304 _ (by decide) RawRows.raw1304))
    (slots160.inc_y 1305 1306 f r (row_of_literal 1305 _ (by decide) RawRows.raw1305) (Or.inl (by decide)))
    (slots160.jump 1306 1304 f r (row_of_literal 1306 _ (by decide) RawRows.raw1306))

theorem site1304 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1304:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1307:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1304Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1307Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1307 f r x y z) (slots210.atReg 1310 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1307 3 1310 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1307 1310 1308 f r (row_of_literal 1307 _ (by decide) RawRows.raw1307))
    (slots210.pos_x 1307 1310 1308 f r (row_of_literal 1307 _ (by decide) RawRows.raw1307))
    (slots210.inc_y 1308 1309 f r (row_of_literal 1308 _ (by decide) RawRows.raw1308) (Or.inl (by decide)))
    (slots210.jump 1309 1307 f r (row_of_literal 1309 _ (by decide) RawRows.raw1309))

theorem site1307 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1307:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1310:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1307Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1310Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1310 f r x y z) (slots617.atReg 1320 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1310 10 1320 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1310 1314 1311 f r (row_of_literal 1310 _ (by decide) RawRows.raw1310))
    (slots617.pos_y 1310 1314 1311 f r (row_of_literal 1310 _ (by decide) RawRows.raw1310))
    (slots617.inc_z 1311 1312 f r (row_of_literal 1311 _ (by decide) RawRows.raw1311) (Or.inl (by decide)))
    (slots617.inc_x 1312 1313 f r (row_of_literal 1312 _ (by decide) RawRows.raw1312) (Or.inl (by decide)))
    (slots617.jump 1313 1310 f r (row_of_literal 1313 _ (by decide) RawRows.raw1313))
    (slots617.zero_x 1314 1320 1315 f r (row_of_literal 1314 _ (by decide) RawRows.raw1314))
    (slots617.pos_x 1314 1320 1315 f r (row_of_literal 1314 _ (by decide) RawRows.raw1314))
    (slots617.inc_z 1315 1316 f r (row_of_literal 1315 _ (by decide) RawRows.raw1315) (Or.inl (by decide)))
    (slots617.zero_x 1316 1319 1317 f r (row_of_literal 1316 _ (by decide) RawRows.raw1316))
    (slots617.pos_x 1316 1319 1317 f r (row_of_literal 1316 _ (by decide) RawRows.raw1316))
    (slots617.inc_y 1317 1318 f r (row_of_literal 1317 _ (by decide) RawRows.raw1317) (Or.inl (by decide)))
    (slots617.jump 1318 1316 f r (row_of_literal 1318 _ (by decide) RawRows.raw1318))
    (slots617.jump 1319 1310 f r (row_of_literal 1319 _ (by decide) RawRows.raw1319))

theorem site1310 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1310:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1320:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1310Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1320Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1320 f r x y z) (slots720.atReg 1323 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1320 3 1323 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1320 1323 1321 f r (row_of_literal 1320 _ (by decide) RawRows.raw1320))
    (slots720.pos_x 1320 1323 1321 f r (row_of_literal 1320 _ (by decide) RawRows.raw1320))
    (slots720.inc_y 1321 1322 f r (row_of_literal 1321 _ (by decide) RawRows.raw1321) (Or.inl (by decide)))
    (slots720.jump 1322 1320 f r (row_of_literal 1322 _ (by decide) RawRows.raw1322))

theorem site1320 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1320:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1323:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1320Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1323Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 1323 f r x y z) (slots361.atReg 1327 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 1323 4 1327 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 1323 1327 1324 f r (row_of_literal 1323 _ (by decide) RawRows.raw1323))
    (slots361.pos_x 1323 1327 1324 f r (row_of_literal 1323 _ (by decide) RawRows.raw1323))
    (slots361.inc_y 1324 1325 f r (row_of_literal 1324 _ (by decide) RawRows.raw1324) (Or.inl (by decide)))
    (slots361.inc_z 1325 1326 f r (row_of_literal 1325 _ (by decide) RawRows.raw1325) (Or.inl (by decide)))
    (slots361.jump 1326 1323 f r (row_of_literal 1326 _ (by decide) RawRows.raw1326))

theorem site1323 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1323:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1327:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site1323Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site1327Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 1327 f r x y z) (slots630.atReg 1330 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 1327 3 1330 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 1327 1330 1328 f r (row_of_literal 1327 _ (by decide) RawRows.raw1327))
    (slots630.pos_x 1327 1330 1328 f r (row_of_literal 1327 _ (by decide) RawRows.raw1327))
    (slots630.inc_y 1328 1329 f r (row_of_literal 1328 _ (by decide) RawRows.raw1328) (Or.inl (by decide)))
    (slots630.jump 1329 1327 f r (row_of_literal 1329 _ (by decide) RawRows.raw1329))

theorem site1327 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1327:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1330:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site1327Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site1330Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1330 f r x y z) (slots160.atReg 1333 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1330 3 1333 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1330 1333 1331 f r (row_of_literal 1330 _ (by decide) RawRows.raw1330))
    (slots160.pos_x 1330 1333 1331 f r (row_of_literal 1330 _ (by decide) RawRows.raw1330))
    (slots160.inc_y 1331 1332 f r (row_of_literal 1331 _ (by decide) RawRows.raw1331) (Or.inl (by decide)))
    (slots160.jump 1332 1330 f r (row_of_literal 1332 _ (by decide) RawRows.raw1332))

theorem site1330 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1330:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1333:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1330Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1333Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1333 f r x y z) (slots210.atReg 1336 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1333 3 1336 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1333 1336 1334 f r (row_of_literal 1333 _ (by decide) RawRows.raw1333))
    (slots210.pos_x 1333 1336 1334 f r (row_of_literal 1333 _ (by decide) RawRows.raw1333))
    (slots210.inc_y 1334 1335 f r (row_of_literal 1334 _ (by decide) RawRows.raw1334) (Or.inl (by decide)))
    (slots210.jump 1335 1333 f r (row_of_literal 1335 _ (by decide) RawRows.raw1335))

theorem site1333 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1333:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1336:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1333Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1336Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1336 f r x y z) (slots617.atReg 1346 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1336 10 1346 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1336 1340 1337 f r (row_of_literal 1336 _ (by decide) RawRows.raw1336))
    (slots617.pos_y 1336 1340 1337 f r (row_of_literal 1336 _ (by decide) RawRows.raw1336))
    (slots617.inc_z 1337 1338 f r (row_of_literal 1337 _ (by decide) RawRows.raw1337) (Or.inl (by decide)))
    (slots617.inc_x 1338 1339 f r (row_of_literal 1338 _ (by decide) RawRows.raw1338) (Or.inl (by decide)))
    (slots617.jump 1339 1336 f r (row_of_literal 1339 _ (by decide) RawRows.raw1339))
    (slots617.zero_x 1340 1346 1341 f r (row_of_literal 1340 _ (by decide) RawRows.raw1340))
    (slots617.pos_x 1340 1346 1341 f r (row_of_literal 1340 _ (by decide) RawRows.raw1340))
    (slots617.inc_z 1341 1342 f r (row_of_literal 1341 _ (by decide) RawRows.raw1341) (Or.inl (by decide)))
    (slots617.zero_x 1342 1345 1343 f r (row_of_literal 1342 _ (by decide) RawRows.raw1342))
    (slots617.pos_x 1342 1345 1343 f r (row_of_literal 1342 _ (by decide) RawRows.raw1342))
    (slots617.inc_y 1343 1344 f r (row_of_literal 1343 _ (by decide) RawRows.raw1343) (Or.inl (by decide)))
    (slots617.jump 1344 1342 f r (row_of_literal 1344 _ (by decide) RawRows.raw1344))
    (slots617.jump 1345 1336 f r (row_of_literal 1345 _ (by decide) RawRows.raw1345))

theorem site1336 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1336:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1346:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1336Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1346Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1346 f r x y z) (slots720.atReg 1349 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1346 3 1349 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1346 1349 1347 f r (row_of_literal 1346 _ (by decide) RawRows.raw1346))
    (slots720.pos_x 1346 1349 1347 f r (row_of_literal 1346 _ (by decide) RawRows.raw1346))
    (slots720.inc_y 1347 1348 f r (row_of_literal 1347 _ (by decide) RawRows.raw1347) (Or.inl (by decide)))
    (slots720.jump 1348 1346 f r (row_of_literal 1348 _ (by decide) RawRows.raw1348))

theorem site1346 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1346:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1349:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1346Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1349Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1349 f r x y z) (slots561.atReg 1353 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1349 4 1353 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1349 1353 1350 f r (row_of_literal 1349 _ (by decide) RawRows.raw1349))
    (slots561.pos_x 1349 1353 1350 f r (row_of_literal 1349 _ (by decide) RawRows.raw1349))
    (slots561.inc_y 1350 1351 f r (row_of_literal 1350 _ (by decide) RawRows.raw1350) (Or.inl (by decide)))
    (slots561.inc_z 1351 1352 f r (row_of_literal 1351 _ (by decide) RawRows.raw1351) (Or.inl (by decide)))
    (slots561.jump 1352 1349 f r (row_of_literal 1352 _ (by decide) RawRows.raw1352))

theorem site1349 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1349:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1353:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1349Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1353Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1353 f r x y z) (slots650.atReg 1356 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1353 3 1356 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1353 1356 1354 f r (row_of_literal 1353 _ (by decide) RawRows.raw1353))
    (slots650.pos_x 1353 1356 1354 f r (row_of_literal 1353 _ (by decide) RawRows.raw1353))
    (slots650.inc_y 1354 1355 f r (row_of_literal 1354 _ (by decide) RawRows.raw1354) (Or.inl (by decide)))
    (slots650.jump 1355 1353 f r (row_of_literal 1355 _ (by decide) RawRows.raw1355))

theorem site1353 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1353:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1356:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1353Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1356Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1356 f r x y z) (slots267.atReg 1364 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1356 8 1364 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1356 1364 1357 f r (row_of_literal 1356 _ (by decide) RawRows.raw1356))
    (slots267.pos_x 1356 1364 1357 f r (row_of_literal 1356 _ (by decide) RawRows.raw1356))
    (slots267.inc_z 1357 1358 f r (row_of_literal 1357 _ (by decide) RawRows.raw1357) (Or.inl (by decide)))
    (slots267.zero_y 1358 1360 1359 f r (row_of_literal 1358 _ (by decide) RawRows.raw1358))
    (slots267.pos_y 1358 1360 1359 f r (row_of_literal 1358 _ (by decide) RawRows.raw1358))
    (slots267.jump 1359 1363 f r (row_of_literal 1359 _ (by decide) RawRows.raw1359))
    (slots267.zero_z 1360 1363 1361 f r (row_of_literal 1360 _ (by decide) RawRows.raw1360))
    (slots267.pos_z 1360 1363 1361 f r (row_of_literal 1360 _ (by decide) RawRows.raw1360))
    (slots267.inc_y 1361 1362 f r (row_of_literal 1361 _ (by decide) RawRows.raw1361) (Or.inl (by decide)))
    (slots267.jump 1362 1360 f r (row_of_literal 1362 _ (by decide) RawRows.raw1362))
    (slots267.jump 1363 1356 f r (row_of_literal 1363 _ (by decide) RawRows.raw1363))

theorem site1356 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1356:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1364:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1356Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1364Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1364 f r x y z) (slots720.atReg 1367 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1364 3 1367 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1364 1367 1365 f r (row_of_literal 1364 _ (by decide) RawRows.raw1364))
    (slots720.pos_x 1364 1367 1365 f r (row_of_literal 1364 _ (by decide) RawRows.raw1364))
    (slots720.inc_y 1365 1366 f r (row_of_literal 1365 _ (by decide) RawRows.raw1365) (Or.inl (by decide)))
    (slots720.jump 1366 1364 f r (row_of_literal 1366 _ (by decide) RawRows.raw1366))

theorem site1364 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1364:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1367:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1364Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1367Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1367 f r x y z) (slots617.atReg 1377 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1367 10 1377 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1367 1371 1368 f r (row_of_literal 1367 _ (by decide) RawRows.raw1367))
    (slots617.pos_y 1367 1371 1368 f r (row_of_literal 1367 _ (by decide) RawRows.raw1367))
    (slots617.inc_z 1368 1369 f r (row_of_literal 1368 _ (by decide) RawRows.raw1368) (Or.inl (by decide)))
    (slots617.inc_x 1369 1370 f r (row_of_literal 1369 _ (by decide) RawRows.raw1369) (Or.inl (by decide)))
    (slots617.jump 1370 1367 f r (row_of_literal 1370 _ (by decide) RawRows.raw1370))
    (slots617.zero_x 1371 1377 1372 f r (row_of_literal 1371 _ (by decide) RawRows.raw1371))
    (slots617.pos_x 1371 1377 1372 f r (row_of_literal 1371 _ (by decide) RawRows.raw1371))
    (slots617.inc_z 1372 1373 f r (row_of_literal 1372 _ (by decide) RawRows.raw1372) (Or.inl (by decide)))
    (slots617.zero_x 1373 1376 1374 f r (row_of_literal 1373 _ (by decide) RawRows.raw1373))
    (slots617.pos_x 1373 1376 1374 f r (row_of_literal 1373 _ (by decide) RawRows.raw1373))
    (slots617.inc_y 1374 1375 f r (row_of_literal 1374 _ (by decide) RawRows.raw1374) (Or.inl (by decide)))
    (slots617.jump 1375 1373 f r (row_of_literal 1375 _ (by decide) RawRows.raw1375))
    (slots617.jump 1376 1367 f r (row_of_literal 1376 _ (by decide) RawRows.raw1376))

theorem site1367 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1367:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1377:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1367Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1377Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1377 f r x y z) (slots710.atReg 1381 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1377 4 1381 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1377 1381 1378 f r (row_of_literal 1377 _ (by decide) RawRows.raw1377))
    (slots710.pos_x 1377 1381 1378 f r (row_of_literal 1377 _ (by decide) RawRows.raw1377))
    (slots710.inc_y 1378 1379 f r (row_of_literal 1378 _ (by decide) RawRows.raw1378) (Or.inl (by decide)))
    (slots710.inc_y 1379 1380 f r (row_of_literal 1379 _ (by decide) RawRows.raw1379) (Or.inl (by decide)))
    (slots710.jump 1380 1377 f r (row_of_literal 1380 _ (by decide) RawRows.raw1380))

theorem site1377 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1377:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1381:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1377Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1381 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1381:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1382:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1381 _ (row_of_literal 1381 _ (by decide) RawRows.raw1381)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1382Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1382 f r x y z) (slots160.atReg 1385 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1382 3 1385 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1382 1385 1383 f r (row_of_literal 1382 _ (by decide) RawRows.raw1382))
    (slots160.pos_x 1382 1385 1383 f r (row_of_literal 1382 _ (by decide) RawRows.raw1382))
    (slots160.inc_y 1383 1384 f r (row_of_literal 1383 _ (by decide) RawRows.raw1383) (Or.inl (by decide)))
    (slots160.jump 1384 1382 f r (row_of_literal 1384 _ (by decide) RawRows.raw1384))

theorem site1382 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1382:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1385:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1382Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1385Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1385 f r x y z) (slots210.atReg 1388 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1385 3 1388 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1385 1388 1386 f r (row_of_literal 1385 _ (by decide) RawRows.raw1385))
    (slots210.pos_x 1385 1388 1386 f r (row_of_literal 1385 _ (by decide) RawRows.raw1385))
    (slots210.inc_y 1386 1387 f r (row_of_literal 1386 _ (by decide) RawRows.raw1386) (Or.inl (by decide)))
    (slots210.jump 1387 1385 f r (row_of_literal 1387 _ (by decide) RawRows.raw1387))

theorem site1385 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1385:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1388:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1385Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1388Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1388 f r x y z) (slots617.atReg 1398 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1388 10 1398 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1388 1392 1389 f r (row_of_literal 1388 _ (by decide) RawRows.raw1388))
    (slots617.pos_y 1388 1392 1389 f r (row_of_literal 1388 _ (by decide) RawRows.raw1388))
    (slots617.inc_z 1389 1390 f r (row_of_literal 1389 _ (by decide) RawRows.raw1389) (Or.inl (by decide)))
    (slots617.inc_x 1390 1391 f r (row_of_literal 1390 _ (by decide) RawRows.raw1390) (Or.inl (by decide)))
    (slots617.jump 1391 1388 f r (row_of_literal 1391 _ (by decide) RawRows.raw1391))
    (slots617.zero_x 1392 1398 1393 f r (row_of_literal 1392 _ (by decide) RawRows.raw1392))
    (slots617.pos_x 1392 1398 1393 f r (row_of_literal 1392 _ (by decide) RawRows.raw1392))
    (slots617.inc_z 1393 1394 f r (row_of_literal 1393 _ (by decide) RawRows.raw1393) (Or.inl (by decide)))
    (slots617.zero_x 1394 1397 1395 f r (row_of_literal 1394 _ (by decide) RawRows.raw1394))
    (slots617.pos_x 1394 1397 1395 f r (row_of_literal 1394 _ (by decide) RawRows.raw1394))
    (slots617.inc_y 1395 1396 f r (row_of_literal 1395 _ (by decide) RawRows.raw1395) (Or.inl (by decide)))
    (slots617.jump 1396 1394 f r (row_of_literal 1396 _ (by decide) RawRows.raw1396))
    (slots617.jump 1397 1388 f r (row_of_literal 1397 _ (by decide) RawRows.raw1397))

theorem site1388 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1388:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1398:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1388Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1398Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1398 f r x y z) (slots720.atReg 1401 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1398 3 1401 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1398 1401 1399 f r (row_of_literal 1398 _ (by decide) RawRows.raw1398))
    (slots720.pos_x 1398 1401 1399 f r (row_of_literal 1398 _ (by decide) RawRows.raw1398))
    (slots720.inc_y 1399 1400 f r (row_of_literal 1399 _ (by decide) RawRows.raw1399) (Or.inl (by decide)))
    (slots720.jump 1400 1398 f r (row_of_literal 1400 _ (by decide) RawRows.raw1400))

theorem site1398 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1398:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1401:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1398Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1401Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1401 f r x y z) (slots461.atReg 1405 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1401 4 1405 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1401 1405 1402 f r (row_of_literal 1401 _ (by decide) RawRows.raw1401))
    (slots461.pos_x 1401 1405 1402 f r (row_of_literal 1401 _ (by decide) RawRows.raw1401))
    (slots461.inc_y 1402 1403 f r (row_of_literal 1402 _ (by decide) RawRows.raw1402) (Or.inl (by decide)))
    (slots461.inc_z 1403 1404 f r (row_of_literal 1403 _ (by decide) RawRows.raw1403) (Or.inl (by decide)))
    (slots461.jump 1404 1401 f r (row_of_literal 1404 _ (by decide) RawRows.raw1404))

theorem site1401 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1401:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1405:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1401Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site1405Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1405 f r x y z) (slots640.atReg 1408 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1405 3 1408 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1405 1408 1406 f r (row_of_literal 1405 _ (by decide) RawRows.raw1405))
    (slots640.pos_x 1405 1408 1406 f r (row_of_literal 1405 _ (by decide) RawRows.raw1405))
    (slots640.inc_y 1406 1407 f r (row_of_literal 1406 _ (by decide) RawRows.raw1406) (Or.inl (by decide)))
    (slots640.jump 1407 1405 f r (row_of_literal 1407 _ (by decide) RawRows.raw1407))

theorem site1405 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1405:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1408:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1405Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site1408Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1408 f r x y z) (slots160.atReg 1411 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1408 3 1411 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1408 1411 1409 f r (row_of_literal 1408 _ (by decide) RawRows.raw1408))
    (slots160.pos_x 1408 1411 1409 f r (row_of_literal 1408 _ (by decide) RawRows.raw1408))
    (slots160.inc_y 1409 1410 f r (row_of_literal 1409 _ (by decide) RawRows.raw1409) (Or.inl (by decide)))
    (slots160.jump 1410 1408 f r (row_of_literal 1410 _ (by decide) RawRows.raw1410))

theorem site1408 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1408:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1411:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1408Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1411Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1411 f r x y z) (slots210.atReg 1414 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1411 3 1414 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1411 1414 1412 f r (row_of_literal 1411 _ (by decide) RawRows.raw1411))
    (slots210.pos_x 1411 1414 1412 f r (row_of_literal 1411 _ (by decide) RawRows.raw1411))
    (slots210.inc_y 1412 1413 f r (row_of_literal 1412 _ (by decide) RawRows.raw1412) (Or.inl (by decide)))
    (slots210.jump 1413 1411 f r (row_of_literal 1413 _ (by decide) RawRows.raw1413))

theorem site1411 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1411:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1414:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1411Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1414Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1414 f r x y z) (slots617.atReg 1424 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1414 10 1424 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1414 1418 1415 f r (row_of_literal 1414 _ (by decide) RawRows.raw1414))
    (slots617.pos_y 1414 1418 1415 f r (row_of_literal 1414 _ (by decide) RawRows.raw1414))
    (slots617.inc_z 1415 1416 f r (row_of_literal 1415 _ (by decide) RawRows.raw1415) (Or.inl (by decide)))
    (slots617.inc_x 1416 1417 f r (row_of_literal 1416 _ (by decide) RawRows.raw1416) (Or.inl (by decide)))
    (slots617.jump 1417 1414 f r (row_of_literal 1417 _ (by decide) RawRows.raw1417))
    (slots617.zero_x 1418 1424 1419 f r (row_of_literal 1418 _ (by decide) RawRows.raw1418))
    (slots617.pos_x 1418 1424 1419 f r (row_of_literal 1418 _ (by decide) RawRows.raw1418))
    (slots617.inc_z 1419 1420 f r (row_of_literal 1419 _ (by decide) RawRows.raw1419) (Or.inl (by decide)))
    (slots617.zero_x 1420 1423 1421 f r (row_of_literal 1420 _ (by decide) RawRows.raw1420))
    (slots617.pos_x 1420 1423 1421 f r (row_of_literal 1420 _ (by decide) RawRows.raw1420))
    (slots617.inc_y 1421 1422 f r (row_of_literal 1421 _ (by decide) RawRows.raw1421) (Or.inl (by decide)))
    (slots617.jump 1422 1420 f r (row_of_literal 1422 _ (by decide) RawRows.raw1422))
    (slots617.jump 1423 1414 f r (row_of_literal 1423 _ (by decide) RawRows.raw1423))

theorem site1414 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1414:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1424:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1414Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1424Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1424 f r x y z) (slots720.atReg 1427 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1424 3 1427 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1424 1427 1425 f r (row_of_literal 1424 _ (by decide) RawRows.raw1424))
    (slots720.pos_x 1424 1427 1425 f r (row_of_literal 1424 _ (by decide) RawRows.raw1424))
    (slots720.inc_y 1425 1426 f r (row_of_literal 1425 _ (by decide) RawRows.raw1425) (Or.inl (by decide)))
    (slots720.jump 1426 1424 f r (row_of_literal 1426 _ (by decide) RawRows.raw1426))

theorem site1424 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1424:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1427:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1424Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1427Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 1427 f r x y z) (slots361.atReg 1431 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 1427 4 1431 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 1427 1431 1428 f r (row_of_literal 1427 _ (by decide) RawRows.raw1427))
    (slots361.pos_x 1427 1431 1428 f r (row_of_literal 1427 _ (by decide) RawRows.raw1427))
    (slots361.inc_y 1428 1429 f r (row_of_literal 1428 _ (by decide) RawRows.raw1428) (Or.inl (by decide)))
    (slots361.inc_z 1429 1430 f r (row_of_literal 1429 _ (by decide) RawRows.raw1429) (Or.inl (by decide)))
    (slots361.jump 1430 1427 f r (row_of_literal 1430 _ (by decide) RawRows.raw1430))

theorem site1427 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1427:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1431:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site1427Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site1431Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 1431 f r x y z) (slots630.atReg 1434 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 1431 3 1434 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 1431 1434 1432 f r (row_of_literal 1431 _ (by decide) RawRows.raw1431))
    (slots630.pos_x 1431 1434 1432 f r (row_of_literal 1431 _ (by decide) RawRows.raw1431))
    (slots630.inc_y 1432 1433 f r (row_of_literal 1432 _ (by decide) RawRows.raw1432) (Or.inl (by decide)))
    (slots630.jump 1433 1431 f r (row_of_literal 1433 _ (by decide) RawRows.raw1433))

theorem site1431 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1431:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1434:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site1431Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site1434Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1434 f r x y z) (slots267.atReg 1442 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1434 8 1442 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1434 1442 1435 f r (row_of_literal 1434 _ (by decide) RawRows.raw1434))
    (slots267.pos_x 1434 1442 1435 f r (row_of_literal 1434 _ (by decide) RawRows.raw1434))
    (slots267.inc_z 1435 1436 f r (row_of_literal 1435 _ (by decide) RawRows.raw1435) (Or.inl (by decide)))
    (slots267.zero_y 1436 1438 1437 f r (row_of_literal 1436 _ (by decide) RawRows.raw1436))
    (slots267.pos_y 1436 1438 1437 f r (row_of_literal 1436 _ (by decide) RawRows.raw1436))
    (slots267.jump 1437 1441 f r (row_of_literal 1437 _ (by decide) RawRows.raw1437))
    (slots267.zero_z 1438 1441 1439 f r (row_of_literal 1438 _ (by decide) RawRows.raw1438))
    (slots267.pos_z 1438 1441 1439 f r (row_of_literal 1438 _ (by decide) RawRows.raw1438))
    (slots267.inc_y 1439 1440 f r (row_of_literal 1439 _ (by decide) RawRows.raw1439) (Or.inl (by decide)))
    (slots267.jump 1440 1438 f r (row_of_literal 1440 _ (by decide) RawRows.raw1440))
    (slots267.jump 1441 1434 f r (row_of_literal 1441 _ (by decide) RawRows.raw1441))

theorem site1434 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1434:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1442:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1434Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1442Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1442 f r x y z) (slots720.atReg 1445 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1442 3 1445 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1442 1445 1443 f r (row_of_literal 1442 _ (by decide) RawRows.raw1442))
    (slots720.pos_x 1442 1445 1443 f r (row_of_literal 1442 _ (by decide) RawRows.raw1442))
    (slots720.inc_y 1443 1444 f r (row_of_literal 1443 _ (by decide) RawRows.raw1443) (Or.inl (by decide)))
    (slots720.jump 1444 1442 f r (row_of_literal 1444 _ (by decide) RawRows.raw1444))

theorem site1442 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1442:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1445:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1442Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1445Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1445 f r x y z) (slots617.atReg 1455 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1445 10 1455 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1445 1449 1446 f r (row_of_literal 1445 _ (by decide) RawRows.raw1445))
    (slots617.pos_y 1445 1449 1446 f r (row_of_literal 1445 _ (by decide) RawRows.raw1445))
    (slots617.inc_z 1446 1447 f r (row_of_literal 1446 _ (by decide) RawRows.raw1446) (Or.inl (by decide)))
    (slots617.inc_x 1447 1448 f r (row_of_literal 1447 _ (by decide) RawRows.raw1447) (Or.inl (by decide)))
    (slots617.jump 1448 1445 f r (row_of_literal 1448 _ (by decide) RawRows.raw1448))
    (slots617.zero_x 1449 1455 1450 f r (row_of_literal 1449 _ (by decide) RawRows.raw1449))
    (slots617.pos_x 1449 1455 1450 f r (row_of_literal 1449 _ (by decide) RawRows.raw1449))
    (slots617.inc_z 1450 1451 f r (row_of_literal 1450 _ (by decide) RawRows.raw1450) (Or.inl (by decide)))
    (slots617.zero_x 1451 1454 1452 f r (row_of_literal 1451 _ (by decide) RawRows.raw1451))
    (slots617.pos_x 1451 1454 1452 f r (row_of_literal 1451 _ (by decide) RawRows.raw1451))
    (slots617.inc_y 1452 1453 f r (row_of_literal 1452 _ (by decide) RawRows.raw1452) (Or.inl (by decide)))
    (slots617.jump 1453 1451 f r (row_of_literal 1453 _ (by decide) RawRows.raw1453))
    (slots617.jump 1454 1445 f r (row_of_literal 1454 _ (by decide) RawRows.raw1454))

theorem site1445 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1445:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1455:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1445Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1455Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1455 f r x y z) (slots710.atReg 1459 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1455 4 1459 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1455 1459 1456 f r (row_of_literal 1455 _ (by decide) RawRows.raw1455))
    (slots710.pos_x 1455 1459 1456 f r (row_of_literal 1455 _ (by decide) RawRows.raw1455))
    (slots710.inc_y 1456 1457 f r (row_of_literal 1456 _ (by decide) RawRows.raw1456) (Or.inl (by decide)))
    (slots710.inc_y 1457 1458 f r (row_of_literal 1457 _ (by decide) RawRows.raw1457) (Or.inl (by decide)))
    (slots710.jump 1458 1455 f r (row_of_literal 1458 _ (by decide) RawRows.raw1458))

theorem site1455 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1455:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1459:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1455Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1459 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1459:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1460:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1459 _ (row_of_literal 1459 _ (by decide) RawRows.raw1459)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1460Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1460 f r x y z) (slots160.atReg 1463 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1460 3 1463 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1460 1463 1461 f r (row_of_literal 1460 _ (by decide) RawRows.raw1460))
    (slots160.pos_x 1460 1463 1461 f r (row_of_literal 1460 _ (by decide) RawRows.raw1460))
    (slots160.inc_y 1461 1462 f r (row_of_literal 1461 _ (by decide) RawRows.raw1461) (Or.inl (by decide)))
    (slots160.jump 1462 1460 f r (row_of_literal 1462 _ (by decide) RawRows.raw1462))

theorem site1460 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1460:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1463:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1460Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1463Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1463 f r x y z) (slots210.atReg 1466 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1463 3 1466 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1463 1466 1464 f r (row_of_literal 1463 _ (by decide) RawRows.raw1463))
    (slots210.pos_x 1463 1466 1464 f r (row_of_literal 1463 _ (by decide) RawRows.raw1463))
    (slots210.inc_y 1464 1465 f r (row_of_literal 1464 _ (by decide) RawRows.raw1464) (Or.inl (by decide)))
    (slots210.jump 1465 1463 f r (row_of_literal 1465 _ (by decide) RawRows.raw1465))

theorem site1463 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1463:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1466:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1463Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1466Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1466 f r x y z) (slots617.atReg 1476 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1466 10 1476 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1466 1470 1467 f r (row_of_literal 1466 _ (by decide) RawRows.raw1466))
    (slots617.pos_y 1466 1470 1467 f r (row_of_literal 1466 _ (by decide) RawRows.raw1466))
    (slots617.inc_z 1467 1468 f r (row_of_literal 1467 _ (by decide) RawRows.raw1467) (Or.inl (by decide)))
    (slots617.inc_x 1468 1469 f r (row_of_literal 1468 _ (by decide) RawRows.raw1468) (Or.inl (by decide)))
    (slots617.jump 1469 1466 f r (row_of_literal 1469 _ (by decide) RawRows.raw1469))
    (slots617.zero_x 1470 1476 1471 f r (row_of_literal 1470 _ (by decide) RawRows.raw1470))
    (slots617.pos_x 1470 1476 1471 f r (row_of_literal 1470 _ (by decide) RawRows.raw1470))
    (slots617.inc_z 1471 1472 f r (row_of_literal 1471 _ (by decide) RawRows.raw1471) (Or.inl (by decide)))
    (slots617.zero_x 1472 1475 1473 f r (row_of_literal 1472 _ (by decide) RawRows.raw1472))
    (slots617.pos_x 1472 1475 1473 f r (row_of_literal 1472 _ (by decide) RawRows.raw1472))
    (slots617.inc_y 1473 1474 f r (row_of_literal 1473 _ (by decide) RawRows.raw1473) (Or.inl (by decide)))
    (slots617.jump 1474 1472 f r (row_of_literal 1474 _ (by decide) RawRows.raw1474))
    (slots617.jump 1475 1466 f r (row_of_literal 1475 _ (by decide) RawRows.raw1475))

theorem site1466 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1466:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1476:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1466Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1476Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1476 f r x y z) (slots720.atReg 1479 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1476 3 1479 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1476 1479 1477 f r (row_of_literal 1476 _ (by decide) RawRows.raw1476))
    (slots720.pos_x 1476 1479 1477 f r (row_of_literal 1476 _ (by decide) RawRows.raw1476))
    (slots720.inc_y 1477 1478 f r (row_of_literal 1477 _ (by decide) RawRows.raw1477) (Or.inl (by decide)))
    (slots720.jump 1478 1476 f r (row_of_literal 1478 _ (by decide) RawRows.raw1478))

theorem site1476 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1476:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1479:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1476Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1479Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1479 f r x y z) (slots461.atReg 1483 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1479 4 1483 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1479 1483 1480 f r (row_of_literal 1479 _ (by decide) RawRows.raw1479))
    (slots461.pos_x 1479 1483 1480 f r (row_of_literal 1479 _ (by decide) RawRows.raw1479))
    (slots461.inc_y 1480 1481 f r (row_of_literal 1480 _ (by decide) RawRows.raw1480) (Or.inl (by decide)))
    (slots461.inc_z 1481 1482 f r (row_of_literal 1481 _ (by decide) RawRows.raw1481) (Or.inl (by decide)))
    (slots461.jump 1482 1479 f r (row_of_literal 1482 _ (by decide) RawRows.raw1482))

theorem site1479 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1479:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1483:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1479Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


end PA192.ModelSearch.Register181.Certified
