module
public import Direct181Snapshots
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem chunk500 : Prefix 500 snap0 snap500 := checked _ _ _ (by decide) (by decide)
theorem chunk1000 : Prefix 500 snap500 snap1000 := checked _ _ _ (by decide) (by decide)
theorem chunk1500 : Prefix 500 snap1000 snap1500 := checked _ _ _ (by decide) (by decide)
theorem chunk2000 : Prefix 500 snap1500 snap2000 := checked _ _ _ (by decide) (by decide)
theorem chunk2500 : Prefix 500 snap2000 snap2500 := checked _ _ _ (by decide) (by decide)
theorem chunk3000 : Prefix 500 snap2500 snap3000 := checked _ _ _ (by decide) (by decide)
theorem chunk3500 : Prefix 500 snap3000 snap3500 := checked _ _ _ (by decide) (by decide)
theorem chunk4000 : Prefix 500 snap3500 snap4000 := checked _ _ _ (by decide) (by decide)
theorem chunk4500 : Prefix 500 snap4000 snap4500 := checked _ _ _ (by decide) (by decide)
theorem chunk5000 : Prefix 500 snap4500 snap5000 := checked _ _ _ (by decide) (by decide)
theorem chunk5500 : Prefix 500 snap5000 snap5500 := checked _ _ _ (by decide) (by decide)
theorem chunk6000 : Prefix 500 snap5500 snap6000 := checked _ _ _ (by decide) (by decide)
end Direct181.Boot
