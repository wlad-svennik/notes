module
public import Src181CmdEmit06
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter225 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1114:Nat):V) f (vector n 0 (emitAtom41 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1111 f n 0 0 c (d+u) (v+y) 0 (emitAtom41 n t s c u v y d w) w
  have d2 : ((0+(emitAtom41 n t s c u v y d w)):V)=(emitAtom41 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter224 f n t s c u v y d w).trans mid

theorem commandEmitAfter226 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1118:Nat):V) f (vector n (v+y) (emitAtom41 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1114 f n 0 (emitAtom41 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter225 f n t s c u v y d w).trans mid

theorem commandEmitAfter227 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1121:Nat):V) f (vector n (v+y) (emitAtom41 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1118 f n (v+y) (emitAtom41 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter226 f n t s c u v y d w).trans mid

theorem commandEmitAfter228 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1129:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (v+y) (emitAtom40 n t s c u v y d w) w)) := by
  have micro := site1121 f n (v+y) (emitAtom41 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom41 n t s c u v y d w))):V)=(v+y) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom41 n t s c u v y d w)):V)=(0+(emitAtom41 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom41 n t s c u v y d w))):V)=left (emitAtom41 n t s c u v y d w))).trans (by change left (cantor (v+y) (emitAtom40 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom41 n t s c u v y d w))):V)=(emitAtom40 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom41 n t s c u v y d w)):V)=(0+(emitAtom41 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom41 n t s c u v y d w))):V)=right (emitAtom41 n t s c u v y d w))).trans (by change right (cantor (v+y) (emitAtom40 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter227 f n t s c u v y d w).trans mid

theorem commandEmitAfter229 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1132:Nat):V) f (vector n (v+y) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1129 f n (v+y) 0 c (d+u) (v+y) (v+y) (emitAtom40 n t s c u v y d w) w
  have d2 : ((0+(emitAtom40 n t s c u v y d w)):V)=(emitAtom40 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter228 f n t s c u v y d w).trans mid

theorem commandEmitAfter230 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1142:Nat):V) f (vector n 0 (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom17 n t s c u v y d w) w)) := by
  have micro := site1132 f n (v+y) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (v+y))):V)=(emitAtom17 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (v+y))):V)=(0+(emitAtom17 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter229 f n t s c u v y d w).trans mid

theorem commandEmitAfter231 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1146:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1142 f n 0 (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom17 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom17 n t s c u v y d w))):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom17 n t s c u v y d w))):V)=(0+((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter230 f n t s c u v y d w).trans mid

theorem commandEmitAfter232 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1147:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1146 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w))+1):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter231 f n t s c u v y d w).trans mid

theorem commandEmitAfter233 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1148:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1147 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1)+1):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter232 f n t s c u v y d w).trans mid

theorem commandEmitAfter234 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1156:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) c (emitAtom39 n t s c u v y d w) w)) := by
  have micro := site1148 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom40 n t s c u v y d w))):V)=c := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom40 n t s c u v y d w)):V)=(0+(emitAtom40 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom40 n t s c u v y d w))):V)=left (emitAtom40 n t s c u v y d w))).trans (by change left (cantor c (emitAtom39 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom40 n t s c u v y d w))):V)=(emitAtom39 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom40 n t s c u v y d w)):V)=(0+(emitAtom40 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom40 n t s c u v y d w))):V)=right (emitAtom40 n t s c u v y d w))).trans (by change right (cantor c (emitAtom39 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter233 f n t s c u v y d w).trans mid

theorem commandEmitAfter235 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1159:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1156 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) c (emitAtom39 n t s c u v y d w) w
  have d2 : ((0+(emitAtom39 n t s c u v y d w)):V)=(emitAtom39 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter234 f n t s c u v y d w).trans mid

theorem commandEmitAfter236 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1169:Nat):V) f (vector n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom42 n t s c u v y d w) w)) := by
  have micro := site1159 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d7 : ((0+(cantor c ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2))):V)=(emitAtom42 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2))):V)=(0+(emitAtom42 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter235 f n t s c u v y d w).trans mid

theorem commandEmitAfter237 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1173:Nat):V) f (vector n ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1169 f n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom42 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom42 n t s c u v y d w))):V)=((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom42 n t s c u v y d w))):V)=(0+((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter236 f n t s c u v y d w).trans mid

theorem commandEmitAfter238 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1174:Nat):V) f (vector n ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1173 f n ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w))+1):V)=((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter237 f n t s c u v y d w).trans mid

theorem commandEmitAfter239 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1177:Nat):V) f (vector n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1174 f n ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1)):V)=((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter238 f n t s c u v y d w).trans mid

theorem commandEmitAfter240 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1180:Nat):V) f (vector n (emitAtom39 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1177 f n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom39 n t s c u v y d w)):V)=(emitAtom39 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter239 f n t s c u v y d w).trans mid

theorem commandEmitAfter241 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1190:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom43 n t s c u v y d w) w)) := by
  have micro := site1180 f n (emitAtom39 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w))):V)=(emitAtom43 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w))):V)=(0+(emitAtom43 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter240 f n t s c u v y d w).trans mid

theorem commandEmitAfter242 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1193:Nat):V) f (vector n 0 (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1190 f n 0 0 c (d+u) (v+y) 0 (emitAtom43 n t s c u v y d w) w
  have d2 : ((0+(emitAtom43 n t s c u v y d w)):V)=(emitAtom43 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter241 f n t s c u v y d w).trans mid

theorem commandEmitAfter243 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1197:Nat):V) f (vector n (d+u) (emitAtom43 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1193 f n 0 (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter242 f n t s c u v y d w).trans mid

theorem commandEmitAfter244 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1200:Nat):V) f (vector n (d+u) (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1197 f n (d+u) (emitAtom43 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter243 f n t s c u v y d w).trans mid

theorem commandEmitAfter245 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1203:Nat):V) f (vector n 0 (emitAtom43 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1200 f n (d+u) (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter244 f n t s c u v y d w).trans mid

theorem commandEmitAfter246 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1206:Nat):V) f (vector n (emitAtom43 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1203 f n 0 (emitAtom43 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom43 n t s c u v y d w)):V)=(emitAtom43 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter245 f n t s c u v y d w).trans mid

theorem commandEmitAfter247 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1216:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom44 n t s c u v y d w) w)) := by
  have micro := site1206 f n (emitAtom43 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom43 n t s c u v y d w))):V)=(emitAtom44 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom43 n t s c u v y d w))):V)=(0+(emitAtom44 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter246 f n t s c u v y d w).trans mid

theorem commandEmitAfter248 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1219:Nat):V) f (vector n 0 (emitAtom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1216 f n 0 0 c (d+u) (v+y) 0 (emitAtom44 n t s c u v y d w) w
  have d2 : ((0+(emitAtom44 n t s c u v y d w)):V)=(emitAtom44 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter247 f n t s c u v y d w).trans mid

theorem commandEmitAfter249 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1223:Nat):V) f (vector n (v+y) (emitAtom44 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1219 f n 0 (emitAtom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter248 f n t s c u v y d w).trans mid

theorem commandEmitAfter250 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1226:Nat):V) f (vector n (v+y) (emitAtom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1223 f n (v+y) (emitAtom44 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter249 f n t s c u v y d w).trans mid

theorem commandEmitAfter251 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1234:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom43 n t s c u v y d w) w)) := by
  have micro := site1226 f n (v+y) (emitAtom44 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom44 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom44 n t s c u v y d w)):V)=(0+(emitAtom44 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom44 n t s c u v y d w))):V)=left (emitAtom44 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom43 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom44 n t s c u v y d w))):V)=(emitAtom43 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom44 n t s c u v y d w)):V)=(0+(emitAtom44 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom44 n t s c u v y d w))):V)=right (emitAtom44 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom43 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter250 f n t s c u v y d w).trans mid

theorem commandEmitAfter252 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1237:Nat):V) f (vector n (v+y) (emitAtom43 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1234 f n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom43 n t s c u v y d w) w
  have d2 : ((0+(emitAtom43 n t s c u v y d w)):V)=(emitAtom43 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter251 f n t s c u v y d w).trans mid

theorem commandEmitAfter253 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1247:Nat):V) f (vector n 0 (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w)) := by
  have micro := site1237 f n (v+y) (emitAtom43 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (v+y))):V)=(emitAtom24 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (v+y))):V)=(0+(emitAtom24 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter252 f n t s c u v y d w).trans mid

theorem commandEmitAfter254 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1251:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1247 f n 0 (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=(0+((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter253 f n t s c u v y d w).trans mid

theorem commandEmitAfter255 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1252:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1251 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter254 f n t s c u v y d w).trans mid

theorem commandEmitAfter256 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1260:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w) w)) := by
  have micro := site1252 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom43 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom43 n t s c u v y d w))):V)=((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom43 n t s c u v y d w)):V)=(0+(emitAtom43 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom43 n t s c u v y d w))):V)=left (emitAtom43 n t s c u v y d w))).trans (by change left (cantor ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom43 n t s c u v y d w))):V)=(emitAtom39 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom43 n t s c u v y d w)):V)=(0+(emitAtom43 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom43 n t s c u v y d w))):V)=right (emitAtom43 n t s c u v y d w))).trans (by change right (cantor ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter255 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
