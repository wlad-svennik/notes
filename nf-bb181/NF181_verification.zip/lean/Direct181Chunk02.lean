module
public import Direct181Snapshots
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem chunk12500 : Prefix 500 snap12000 snap12500 := checked _ _ _ (by decide) (by decide)
theorem chunk13000 : Prefix 500 snap12500 snap13000 := checked _ _ _ (by decide) (by decide)
theorem chunk13500 : Prefix 500 snap13000 snap13500 := checked _ _ _ (by decide) (by decide)
theorem chunk14000 : Prefix 500 snap13500 snap14000 := checked _ _ _ (by decide) (by decide)
theorem chunk14500 : Prefix 500 snap14000 snap14500 := checked _ _ _ (by decide) (by decide)
theorem chunk15000 : Prefix 500 snap14500 snap15000 := checked _ _ _ (by decide) (by decide)
theorem chunk15500 : Prefix 500 snap15000 snap15500 := checked _ _ _ (by decide) (by decide)
theorem chunk16000 : Prefix 500 snap15500 snap16000 := checked _ _ _ (by decide) (by decide)
theorem chunk16439 : Prefix 439 snap16000 snap16439 := checked _ _ _ (by decide) (by decide)
theorem chunk16500 : Prefix 61 snap16439 snap16500 := checked _ _ _ (by decide) (by decide)
theorem chunk17000 : Prefix 500 snap16500 snap17000 := checked _ _ _ (by decide) (by decide)
theorem chunk17319 : Prefix 319 snap17000 snap17319 := checked _ _ _ (by decide) (by decide)
end Direct181.Boot
