import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1248_0 : checkWitness 1248 false false 8852 = true := by decide +kernel
private theorem w1248_2 : checkWitness 1248 true false 8848 = true := by decide +kernel
private theorem cases1248 : checkFour 1248 (8852,0,8848,0) = true := by
  simp only [checkFour, w1248_0, w1248_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1248 : Coverage 1248 1249 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1248)
private theorem w1249_0 : checkWitness 1249 false false 8848 = true := by decide +kernel
private theorem w1249_2 : checkWitness 1249 true false 8844 = true := by decide +kernel
private theorem cases1249 : checkFour 1249 (8848,0,8844,0) = true := by
  simp only [checkFour, w1249_0, w1249_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1249 : Coverage 1249 1250 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases1249)
private theorem w1250_0 : checkWitness 1250 false false 96 = true := by decide +kernel
private theorem w1250_2 : checkWitness 1250 true false 96 = true := by decide +kernel
private theorem cases1250 : checkFour 1250 (96,0,96,0) = true := by
  simp only [checkFour, w1250_0, w1250_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1250 : Coverage 1250 1251 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1250)
private theorem w1251_0 : checkWitness 1251 false false 8868 = true := by decide +kernel
private theorem w1251_2 : checkWitness 1251 true false 8864 = true := by decide +kernel
private theorem cases1251 : checkFour 1251 (8868,0,8864,0) = true := by
  simp only [checkFour, w1251_0, w1251_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1251 : Coverage 1251 1252 := checkList_sound (ws:=[(8868,0,8864,0)]) (by simpa only [checkList, Bool.and_true] using cases1251)
private theorem w1252_0 : checkWitness 1252 false false 488 = true := by decide +kernel
private theorem w1252_1 : checkWitness 1252 false true 4584 = true := by decide +kernel
private theorem w1252_2 : checkWitness 1252 true false 488 = true := by decide +kernel
private theorem w1252_3 : checkWitness 1252 true true 4584 = true := by decide +kernel
private theorem cases1252 : checkFour 1252 (488,4584,488,4584) = true := by
  simp only [checkFour, w1252_0, w1252_1, w1252_2, w1252_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1252 : Coverage 1252 1253 := checkList_sound (ws:=[(488,4584,488,4584)]) (by simpa only [checkList, Bool.and_true] using cases1252)
private theorem w1253_0 : checkWitness 1253 false false 8883 = true := by decide +kernel
private theorem w1253_2 : checkWitness 1253 true false 8879 = true := by decide +kernel
private theorem cases1253 : checkFour 1253 (8883,0,8879,0) = true := by
  simp only [checkFour, w1253_0, w1253_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1253 : Coverage 1253 1254 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1253)
private theorem w1254_0 : checkWitness 1254 false false 614 = true := by decide +kernel
private theorem w1254_1 : checkWitness 1254 false true 4710 = true := by decide +kernel
private theorem w1254_2 : checkWitness 1254 true false 605 = true := by decide +kernel
private theorem w1254_3 : checkWitness 1254 true true 4701 = true := by decide +kernel
private theorem cases1254 : checkFour 1254 (614,4710,605,4701) = true := by
  simp only [checkFour, w1254_0, w1254_1, w1254_2, w1254_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1254 : Coverage 1254 1255 := checkList_sound (ws:=[(614,4710,605,4701)]) (by simpa only [checkList, Bool.and_true] using cases1254)
private theorem w1255_0 : checkWitness 1255 false false 174 = true := by decide +kernel
private theorem w1255_2 : checkWitness 1255 true false 174 = true := by decide +kernel
private theorem cases1255 : checkFour 1255 (174,0,174,0) = true := by
  simp only [checkFour, w1255_0, w1255_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1255 : Coverage 1255 1256 := checkList_sound (ws:=[(174,0,174,0)]) (by simpa only [checkList, Bool.and_true] using cases1255)
private theorem w1256_0 : checkWitness 1256 false false 569 = true := by decide +kernel
private theorem w1256_1 : checkWitness 1256 false true 4657 = true := by decide +kernel
private theorem w1256_2 : checkWitness 1256 true false 569 = true := by decide +kernel
private theorem w1256_3 : checkWitness 1256 true true 4657 = true := by decide +kernel
private theorem cases1256 : checkFour 1256 (569,4657,569,4657) = true := by
  simp only [checkFour, w1256_0, w1256_1, w1256_2, w1256_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1256 : Coverage 1256 1257 := checkList_sound (ws:=[(569,4657,569,4657)]) (by simpa only [checkList, Bool.and_true] using cases1256)
private theorem w1257_0 : checkWitness 1257 false false 8898 = true := by decide +kernel
private theorem w1257_2 : checkWitness 1257 true false 8889 = true := by decide +kernel
private theorem cases1257 : checkFour 1257 (8898,0,8889,0) = true := by
  simp only [checkFour, w1257_0, w1257_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1257 : Coverage 1257 1258 := checkList_sound (ws:=[(8898,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1257)
private theorem w1258_0 : checkWitness 1258 false false 82 = true := by decide +kernel
private theorem w1258_2 : checkWitness 1258 true false 82 = true := by decide +kernel
private theorem cases1258 : checkFour 1258 (82,0,82,0) = true := by
  simp only [checkFour, w1258_0, w1258_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1258 : Coverage 1258 1259 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1258)
private theorem w1259_0 : checkWitness 1259 false false 74 = true := by decide +kernel
private theorem w1259_2 : checkWitness 1259 true false 74 = true := by decide +kernel
private theorem cases1259 : checkFour 1259 (74,0,74,0) = true := by
  simp only [checkFour, w1259_0, w1259_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1259 : Coverage 1259 1260 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1259)
private theorem w1260_0 : checkWitness 1260 false false 575 = true := by decide +kernel
private theorem w1260_1 : checkWitness 1260 false true 4667 = true := by decide +kernel
private theorem w1260_2 : checkWitness 1260 true false 575 = true := by decide +kernel
private theorem w1260_3 : checkWitness 1260 true true 4667 = true := by decide +kernel
private theorem cases1260 : checkFour 1260 (575,4667,575,4667) = true := by
  simp only [checkFour, w1260_0, w1260_1, w1260_2, w1260_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1260 : Coverage 1260 1261 := checkList_sound (ws:=[(575,4667,575,4667)]) (by simpa only [checkList, Bool.and_true] using cases1260)
private theorem w1261_0 : checkWitness 1261 false false 8836 = true := by decide +kernel
private theorem w1261_2 : checkWitness 1261 true false 8832 = true := by decide +kernel
private theorem cases1261 : checkFour 1261 (8836,0,8832,0) = true := by
  simp only [checkFour, w1261_0, w1261_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1261 : Coverage 1261 1262 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1261)
private theorem w1262_0 : checkWitness 1262 false false 74 = true := by decide +kernel
private theorem w1262_2 : checkWitness 1262 true false 74 = true := by decide +kernel
private theorem cases1262 : checkFour 1262 (74,0,74,0) = true := by
  simp only [checkFour, w1262_0, w1262_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1262 : Coverage 1262 1263 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1262)
private theorem w1263_0 : checkWitness 1263 false false 530 = true := by decide +kernel
private theorem w1263_1 : checkWitness 1263 false true 4626 = true := by decide +kernel
private theorem w1263_2 : checkWitness 1263 true false 530 = true := by decide +kernel
private theorem w1263_3 : checkWitness 1263 true true 4626 = true := by decide +kernel
private theorem cases1263 : checkFour 1263 (530,4626,530,4626) = true := by
  simp only [checkFour, w1263_0, w1263_1, w1263_2, w1263_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1263 : Coverage 1263 1264 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases1263)
private theorem w1264_0 : checkWitness 1264 false false 8871 = true := by decide +kernel
private theorem w1264_2 : checkWitness 1264 true false 8867 = true := by decide +kernel
private theorem cases1264 : checkFour 1264 (8871,0,8867,0) = true := by
  simp only [checkFour, w1264_0, w1264_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1264 : Coverage 1264 1265 := checkList_sound (ws:=[(8871,0,8867,0)]) (by simpa only [checkList, Bool.and_true] using cases1264)
private theorem w1265_0 : checkWitness 1265 false false 8906 = true := by decide +kernel
private theorem w1265_2 : checkWitness 1265 true false 8897 = true := by decide +kernel
private theorem cases1265 : checkFour 1265 (8906,0,8897,0) = true := by
  simp only [checkFour, w1265_0, w1265_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1265 : Coverage 1265 1266 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1265)
private theorem w1266_0 : checkWitness 1266 false false 92 = true := by decide +kernel
private theorem w1266_2 : checkWitness 1266 true false 92 = true := by decide +kernel
private theorem cases1266 : checkFour 1266 (92,0,92,0) = true := by
  simp only [checkFour, w1266_0, w1266_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1266 : Coverage 1266 1267 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1266)
private theorem w1267_0 : checkWitness 1267 false false 618 = true := by decide +kernel
private theorem w1267_1 : checkWitness 1267 false true 4710 = true := by decide +kernel
private theorem w1267_2 : checkWitness 1267 true false 609 = true := by decide +kernel
private theorem w1267_3 : checkWitness 1267 true true 4701 = true := by decide +kernel
private theorem cases1267 : checkFour 1267 (618,4710,609,4701) = true := by
  simp only [checkFour, w1267_0, w1267_1, w1267_2, w1267_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1267 : Coverage 1267 1268 := checkList_sound (ws:=[(618,4710,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases1267)
private theorem w1268_0 : checkWitness 1268 false false 8867 = true := by decide +kernel
private theorem w1268_2 : checkWitness 1268 true false 8863 = true := by decide +kernel
private theorem cases1268 : checkFour 1268 (8867,0,8863,0) = true := by
  simp only [checkFour, w1268_0, w1268_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1268 : Coverage 1268 1269 := checkList_sound (ws:=[(8867,0,8863,0)]) (by simpa only [checkList, Bool.and_true] using cases1268)
private theorem w1269_0 : checkWitness 1269 false false 612 = true := by decide +kernel
private theorem w1269_1 : checkWitness 1269 false true 4704 = true := by decide +kernel
private theorem w1269_2 : checkWitness 1269 true false 603 = true := by decide +kernel
private theorem w1269_3 : checkWitness 1269 true true 4695 = true := by decide +kernel
private theorem cases1269 : checkFour 1269 (612,4704,603,4695) = true := by
  simp only [checkFour, w1269_0, w1269_1, w1269_2, w1269_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1269 : Coverage 1269 1270 := checkList_sound (ws:=[(612,4704,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases1269)
private theorem w1270_0 : checkWitness 1270 false false 8836 = true := by decide +kernel
private theorem w1270_2 : checkWitness 1270 true false 8832 = true := by decide +kernel
private theorem cases1270 : checkFour 1270 (8836,0,8832,0) = true := by
  simp only [checkFour, w1270_0, w1270_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1270 : Coverage 1270 1271 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1270)
private theorem w1271_0 : checkWitness 1271 false false 80 = true := by decide +kernel
private theorem w1271_2 : checkWitness 1271 true false 80 = true := by decide +kernel
private theorem cases1271 : checkFour 1271 (80,0,80,0) = true := by
  simp only [checkFour, w1271_0, w1271_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1271 : Coverage 1271 1272 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1271)
private theorem w1272_0 : checkWitness 1272 false false 72 = true := by decide +kernel
private theorem w1272_2 : checkWitness 1272 true false 72 = true := by decide +kernel
private theorem cases1272 : checkFour 1272 (72,0,72,0) = true := by
  simp only [checkFour, w1272_0, w1272_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1272 : Coverage 1272 1273 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases1272)
private theorem w1273_0 : checkWitness 1273 false false 587 = true := by decide +kernel
private theorem w1273_1 : checkWitness 1273 false true 4667 = true := by decide +kernel
private theorem w1273_2 : checkWitness 1273 true false 587 = true := by decide +kernel
private theorem w1273_3 : checkWitness 1273 true true 4667 = true := by decide +kernel
private theorem cases1273 : checkFour 1273 (587,4667,587,4667) = true := by
  simp only [checkFour, w1273_0, w1273_1, w1273_2, w1273_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1273 : Coverage 1273 1274 := checkList_sound (ws:=[(587,4667,587,4667)]) (by simpa only [checkList, Bool.and_true] using cases1273)
private theorem w1274_0 : checkWitness 1274 false false 8852 = true := by decide +kernel
private theorem w1274_2 : checkWitness 1274 true false 8848 = true := by decide +kernel
private theorem cases1274 : checkFour 1274 (8852,0,8848,0) = true := by
  simp only [checkFour, w1274_0, w1274_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1274 : Coverage 1274 1275 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1274)
private theorem w1275_0 : checkWitness 1275 false false 8848 = true := by decide +kernel
private theorem w1275_2 : checkWitness 1275 true false 8844 = true := by decide +kernel
private theorem cases1275 : checkFour 1275 (8848,0,8844,0) = true := by
  simp only [checkFour, w1275_0, w1275_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1275 : Coverage 1275 1276 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases1275)
private theorem w1276_0 : checkWitness 1276 false false 86 = true := by decide +kernel
private theorem w1276_2 : checkWitness 1276 true false 86 = true := by decide +kernel
private theorem cases1276 : checkFour 1276 (86,0,86,0) = true := by
  simp only [checkFour, w1276_0, w1276_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1276 : Coverage 1276 1277 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1276)
private theorem w1277_0 : checkWitness 1277 false false 8848 = true := by decide +kernel
private theorem w1277_2 : checkWitness 1277 true false 8844 = true := by decide +kernel
private theorem cases1277 : checkFour 1277 (8848,0,8844,0) = true := by
  simp only [checkFour, w1277_0, w1277_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1277 : Coverage 1277 1278 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases1277)
private theorem w1278_0 : checkWitness 1278 false false 476 = true := by decide +kernel
private theorem w1278_1 : checkWitness 1278 false true 4572 = true := by decide +kernel
private theorem w1278_2 : checkWitness 1278 true false 476 = true := by decide +kernel
private theorem w1278_3 : checkWitness 1278 true true 4572 = true := by decide +kernel
private theorem cases1278 : checkFour 1278 (476,4572,476,4572) = true := by
  simp only [checkFour, w1278_0, w1278_1, w1278_2, w1278_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1278 : Coverage 1278 1279 := checkList_sound (ws:=[(476,4572,476,4572)]) (by simpa only [checkList, Bool.and_true] using cases1278)
private theorem w1279_0 : checkWitness 1279 false false 8871 = true := by decide +kernel
private theorem w1279_2 : checkWitness 1279 true false 8867 = true := by decide +kernel
private theorem cases1279 : checkFour 1279 (8871,0,8867,0) = true := by
  simp only [checkFour, w1279_0, w1279_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1279 : Coverage 1279 1280 := checkList_sound (ws:=[(8871,0,8867,0)]) (by simpa only [checkList, Bool.and_true] using cases1279)
theorem cover1248 : Coverage 1248 1280 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1248 one1249) (Coverage.join one1250 one1251)) (Coverage.join (Coverage.join one1252 one1253) (Coverage.join one1254 one1255))) (Coverage.join (Coverage.join (Coverage.join one1256 one1257) (Coverage.join one1258 one1259)) (Coverage.join (Coverage.join one1260 one1261) (Coverage.join one1262 one1263)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1264 one1265) (Coverage.join one1266 one1267)) (Coverage.join (Coverage.join one1268 one1269) (Coverage.join one1270 one1271))) (Coverage.join (Coverage.join (Coverage.join one1272 one1273) (Coverage.join one1274 one1275)) (Coverage.join (Coverage.join one1276 one1277) (Coverage.join one1278 one1279)))))
end NF181PA.Symbolic
