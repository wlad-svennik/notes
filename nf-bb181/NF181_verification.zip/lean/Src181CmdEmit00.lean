module
public import Src181EmitAtoms
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter1 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((48:Nat):V) f (vector n t s c u v y (emitAtom0 n t s c u v y d w) 0)) := by
  have micro := site0040 f n t s c u v 0 0 (emitAtom1 n t s c u v y d w)
  have d6 : ((left ((cantor 0 0)+(emitAtom1 n t s c u v y d w))):V)=y := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom1 n t s c u v y d w)):V)=(0+(emitAtom1 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom1 n t s c u v y d w))):V)=left (emitAtom1 n t s c u v y d w))).trans (by change left (cantor y (emitAtom0 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom1 n t s c u v y d w))):V)=(emitAtom0 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom1 n t s c u v y d w)):V)=(0+(emitAtom1 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom1 n t s c u v y d w))):V)=right (emitAtom1 n t s c u v y d w))).trans (by change right (cantor y (emitAtom0 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact mid

theorem commandEmitAfter2 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((51:Nat):V) f (vector n t s c u v y 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0048 f n t s c u v y (emitAtom0 n t s c u v y d w) 0
  have d8 : ((0+(emitAtom0 n t s c u v y d w)):V)=(emitAtom0 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl rfl d8)
  exact (commandEmitAfter1 f n t s c u v y d w).trans mid

theorem commandEmitAfter3 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((54:Nat):V) f (vector n t s c u (v+y) 0 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0051 f n t s c u v y 0 (emitAtom0 n t s c u v y d w)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter2 f n t s c u v y d w).trans mid

theorem commandEmitAfter4 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((57:Nat):V) f (vector n 0 s c u (v+y) t 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0054 f n t s c u (v+y) 0 0 (emitAtom0 n t s c u v y d w)
  have d6 : ((0+t):V)=t := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter3 f n t s c u v y d w).trans mid

theorem commandEmitAfter5 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((60:Nat):V) f (vector n s 0 c u (v+y) t 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0057 f n 0 s c u (v+y) t 0 (emitAtom0 n t s c u v y d w)
  have d1 : ((0+s):V)=s := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter4 f n t s c u v y d w).trans mid

theorem commandEmitAfter6 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((70:Nat):V) f (vector n 0 0 c u (v+y) 0 (emitAtom2 n t s c u v y d w) (emitAtom0 n t s c u v y d w))) := by
  have micro := site0060 f n s 0 c u (v+y) t 0 (emitAtom0 n t s c u v y d w)
  have d7 : ((0+(cantor t s)):V)=(emitAtom2 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor t s)):V)=(0+(emitAtom2 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter5 f n t s c u v y d w).trans mid

theorem commandEmitAfter7 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((73:Nat):V) f (vector n 0 (emitAtom2 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0070 f n 0 0 c u (v+y) 0 (emitAtom2 n t s c u v y d w) (emitAtom0 n t s c u v y d w)
  have d2 : ((0+(emitAtom2 n t s c u v y d w)):V)=(emitAtom2 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter6 f n t s c u v y d w).trans mid

theorem commandEmitAfter8 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((77:Nat):V) f (vector n c (emitAtom2 n t s c u v y d w) 0 u (v+y) c 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0073 f n 0 (emitAtom2 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w)
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter7 f n t s c u v y d w).trans mid

theorem commandEmitAfter9 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((80:Nat):V) f (vector n c (emitAtom2 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0077 f n c (emitAtom2 n t s c u v y d w) 0 u (v+y) c 0 (emitAtom0 n t s c u v y d w)
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter8 f n t s c u v y d w).trans mid

theorem commandEmitAfter10 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((83:Nat):V) f (vector n 0 (emitAtom2 n t s c u v y d w) c u (v+y) c 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0080 f n c (emitAtom2 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w)
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter9 f n t s c u v y d w).trans mid

theorem commandEmitAfter11 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((86:Nat):V) f (vector n (emitAtom2 n t s c u v y d w) 0 c u (v+y) c 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0083 f n 0 (emitAtom2 n t s c u v y d w) c u (v+y) c 0 (emitAtom0 n t s c u v y d w)
  have d1 : ((0+(emitAtom2 n t s c u v y d w)):V)=(emitAtom2 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter10 f n t s c u v y d w).trans mid

theorem commandEmitAfter12 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((96:Nat):V) f (vector n 0 0 c u (v+y) 0 (emitAtom3 n t s c u v y d w) (emitAtom0 n t s c u v y d w))) := by
  have micro := site0086 f n (emitAtom2 n t s c u v y d w) 0 c u (v+y) c 0 (emitAtom0 n t s c u v y d w)
  have d7 : ((0+(cantor c (emitAtom2 n t s c u v y d w))):V)=(emitAtom3 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c (emitAtom2 n t s c u v y d w))):V)=(0+(emitAtom3 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter11 f n t s c u v y d w).trans mid

theorem commandEmitAfter13 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((99:Nat):V) f (vector n 0 (emitAtom3 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0096 f n 0 0 c u (v+y) 0 (emitAtom3 n t s c u v y d w) (emitAtom0 n t s c u v y d w)
  have d2 : ((0+(emitAtom3 n t s c u v y d w)):V)=(emitAtom3 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter12 f n t s c u v y d w).trans mid

theorem commandEmitAfter14 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((103:Nat):V) f (vector n u (emitAtom3 n t s c u v y d w) c 0 (v+y) u 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0099 f n 0 (emitAtom3 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w)
  have d1 : ((0+u):V)=u := by ring
  have d6 : ((0+u):V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter13 f n t s c u v y d w).trans mid

theorem commandEmitAfter15 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((106:Nat):V) f (vector n u (emitAtom3 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0103 f n u (emitAtom3 n t s c u v y d w) c 0 (v+y) u 0 (emitAtom0 n t s c u v y d w)
  have d4 : ((0+u):V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter14 f n t s c u v y d w).trans mid

theorem commandEmitAfter16 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((114:Nat):V) f (vector n u 0 c u (v+y) c (emitAtom2 n t s c u v y d w) (emitAtom0 n t s c u v y d w))) := by
  have micro := site0106 f n u (emitAtom3 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w)
  have d6 : ((left ((cantor 0 0)+(emitAtom3 n t s c u v y d w))):V)=c := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom3 n t s c u v y d w)):V)=(0+(emitAtom3 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom3 n t s c u v y d w))):V)=left (emitAtom3 n t s c u v y d w))).trans (by change left (cantor c (emitAtom2 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom3 n t s c u v y d w))):V)=(emitAtom2 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom3 n t s c u v y d w)):V)=(0+(emitAtom3 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom3 n t s c u v y d w))):V)=right (emitAtom3 n t s c u v y d w))).trans (by change right (cantor c (emitAtom2 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter15 f n t s c u v y d w).trans mid

theorem commandEmitAfter17 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((117:Nat):V) f (vector n u (emitAtom2 n t s c u v y d w) c u (v+y) c 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0114 f n u 0 c u (v+y) c (emitAtom2 n t s c u v y d w) (emitAtom0 n t s c u v y d w)
  have d2 : ((0+(emitAtom2 n t s c u v y d w)):V)=(emitAtom2 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter16 f n t s c u v y d w).trans mid

theorem commandEmitAfter18 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((127:Nat):V) f (vector n 0 (emitAtom2 n t s c u v y d w) c u (v+y) 0 (emitAtom4 n t s c u v y d w) (emitAtom0 n t s c u v y d w))) := by
  have micro := site0117 f n u (emitAtom2 n t s c u v y d w) c u (v+y) c 0 (emitAtom0 n t s c u v y d w)
  have d7 : ((0+(cantor c u)):V)=(emitAtom4 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c u)):V)=(0+(emitAtom4 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter17 f n t s c u v y d w).trans mid

theorem commandEmitAfter19 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((131:Nat):V) f (vector n ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w))) := by
  have micro := site0127 f n 0 (emitAtom2 n t s c u v y d w) c u (v+y) 0 (emitAtom4 n t s c u v y d w) (emitAtom0 n t s c u v y d w)
  have d1 : ((0+(2*(emitAtom4 n t s c u v y d w))):V)=((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom4 n t s c u v y d w))):V)=(0+((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter18 f n t s c u v y d w).trans mid

theorem commandEmitAfter20 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((139:Nat):V) f (vector n ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c u (v+y) d w 0)) := by
  have micro := site0131 f n ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c u (v+y) 0 0 (emitAtom0 n t s c u v y d w)
  have d6 : ((left ((cantor 0 0)+(emitAtom0 n t s c u v y d w))):V)=d := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom0 n t s c u v y d w)):V)=(0+(emitAtom0 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom0 n t s c u v y d w))):V)=left (emitAtom0 n t s c u v y d w))).trans (by change left (cantor d w) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom0 n t s c u v y d w))):V)=w := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom0 n t s c u v y d w)):V)=(0+(emitAtom0 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom0 n t s c u v y d w))):V)=right (emitAtom0 n t s c u v y d w))).trans (by change right (cantor d w) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter19 f n t s c u v y d w).trans mid

theorem commandEmitAfter21 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((142:Nat):V) f (vector n ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c u (v+y) d 0 w)) := by
  have micro := site0139 f n ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c u (v+y) d w 0
  have d8 : ((0+w):V)=w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl rfl d8)
  exact (commandEmitAfter20 f n t s c u v y d w).trans mid

theorem commandEmitAfter22 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((145:Nat):V) f (vector n ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0142 f n ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c u (v+y) d 0 w
  have d4 : ((u+d):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter21 f n t s c u v y d w).trans mid

theorem commandEmitAfter23 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((148:Nat):V) f (vector n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) 0 w)) := by
  have micro := site0145 f n ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w))):V)=((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter22 f n t s c u v y d w).trans mid

theorem commandEmitAfter24 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((151:Nat):V) f (vector n (emitAtom2 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) 0 w)) := by
  have micro := site0148 f n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) 0 w
  have d1 : ((0+(emitAtom2 n t s c u v y d w)):V)=(emitAtom2 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter23 f n t s c u v y d w).trans mid

theorem commandEmitAfter25 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((161:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom5 n t s c u v y d w) w)) := by
  have micro := site0151 f n (emitAtom2 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w))):V)=(emitAtom5 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w))):V)=(0+(emitAtom5 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter24 f n t s c u v y d w).trans mid

theorem commandEmitAfter26 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((164:Nat):V) f (vector n 0 (emitAtom5 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0161 f n 0 0 c (d+u) (v+y) 0 (emitAtom5 n t s c u v y d w) w
  have d2 : ((0+(emitAtom5 n t s c u v y d w)):V)=(emitAtom5 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter25 f n t s c u v y d w).trans mid

theorem commandEmitAfter27 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((168:Nat):V) f (vector n (d+u) (emitAtom5 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0164 f n 0 (emitAtom5 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter26 f n t s c u v y d w).trans mid

theorem commandEmitAfter28 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((171:Nat):V) f (vector n (d+u) (emitAtom5 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0168 f n (d+u) (emitAtom5 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter27 f n t s c u v y d w).trans mid

theorem commandEmitAfter29 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((179:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) w)) := by
  have micro := site0171 f n (d+u) (emitAtom5 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom5 n t s c u v y d w))):V)=((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom5 n t s c u v y d w)):V)=(0+(emitAtom5 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom5 n t s c u v y d w))):V)=left (emitAtom5 n t s c u v y d w))).trans (by change left (cantor ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom5 n t s c u v y d w))):V)=(emitAtom2 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom5 n t s c u v y d w)):V)=(0+(emitAtom5 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom5 n t s c u v y d w))):V)=right (emitAtom5 n t s c u v y d w))).trans (by change right (cantor ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter28 f n t s c u v y d w).trans mid

theorem commandEmitAfter30 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((182:Nat):V) f (vector n (d+u) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) 0 w)) := by
  have micro := site0179 f n (d+u) 0 c (d+u) (v+y) ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) w
  have d2 : ((0+(emitAtom2 n t s c u v y d w)):V)=(emitAtom2 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter29 f n t s c u v y d w).trans mid

theorem commandEmitAfter31 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((192:Nat):V) f (vector n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom6 n t s c u v y d w) w)) := by
  have micro := site0182 f n (d+u) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (d+u))):V)=(emitAtom6 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (d+u))):V)=(0+(emitAtom6 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter30 f n t s c u v y d w).trans mid

theorem commandEmitAfter32 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((196:Nat):V) f (vector n ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0192 f n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom6 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom6 n t s c u v y d w))):V)=((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom6 n t s c u v y d w))):V)=(0+((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter31 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
