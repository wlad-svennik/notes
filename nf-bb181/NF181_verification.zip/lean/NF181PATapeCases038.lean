import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1216_0 : checkWitness 1216 false false 599 = true := by decide +kernel
private theorem w1216_1 : checkWitness 1216 false true 4683 = true := by decide +kernel
private theorem w1216_2 : checkWitness 1216 true false 599 = true := by decide +kernel
private theorem w1216_3 : checkWitness 1216 true true 4683 = true := by decide +kernel
private theorem cases1216 : checkFour 1216 (599,4683,599,4683) = true := by
  simp only [checkFour, w1216_0, w1216_1, w1216_2, w1216_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1216 : Coverage 1216 1217 := checkList_sound (ws:=[(599,4683,599,4683)]) (by simpa only [checkList, Bool.and_true] using cases1216)
private theorem w1217_0 : checkWitness 1217 false false 8852 = true := by decide +kernel
private theorem w1217_2 : checkWitness 1217 true false 8848 = true := by decide +kernel
private theorem cases1217 : checkFour 1217 (8852,0,8848,0) = true := by
  simp only [checkFour, w1217_0, w1217_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1217 : Coverage 1217 1218 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1217)
private theorem w1218_0 : checkWitness 1218 false false 96 = true := by decide +kernel
private theorem w1218_2 : checkWitness 1218 true false 96 = true := by decide +kernel
private theorem cases1218 : checkFour 1218 (96,0,96,0) = true := by
  simp only [checkFour, w1218_0, w1218_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1218 : Coverage 1218 1219 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1218)
private theorem w1219_0 : checkWitness 1219 false false 597 = true := by decide +kernel
private theorem w1219_1 : checkWitness 1219 false true 4689 = true := by decide +kernel
private theorem w1219_2 : checkWitness 1219 true false 588 = true := by decide +kernel
private theorem w1219_3 : checkWitness 1219 true true 4680 = true := by decide +kernel
private theorem cases1219 : checkFour 1219 (597,4689,588,4680) = true := by
  simp only [checkFour, w1219_0, w1219_1, w1219_2, w1219_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1219 : Coverage 1219 1220 := checkList_sound (ws:=[(597,4689,588,4680)]) (by simpa only [checkList, Bool.and_true] using cases1219)
private theorem w1220_0 : checkWitness 1220 false false 8894 = true := by decide +kernel
private theorem w1220_2 : checkWitness 1220 true false 8885 = true := by decide +kernel
private theorem cases1220 : checkFour 1220 (8894,0,8885,0) = true := by
  simp only [checkFour, w1220_0, w1220_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1220 : Coverage 1220 1221 := checkList_sound (ws:=[(8894,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1220)
private theorem w1221_0 : checkWitness 1221 false false 8840 = true := by decide +kernel
private theorem w1221_2 : checkWitness 1221 true false 8836 = true := by decide +kernel
private theorem cases1221 : checkFour 1221 (8840,0,8836,0) = true := by
  simp only [checkFour, w1221_0, w1221_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1221 : Coverage 1221 1222 := checkList_sound (ws:=[(8840,0,8836,0)]) (by simpa only [checkList, Bool.and_true] using cases1221)
private theorem w1222_0 : checkWitness 1222 false false 90 = true := by decide +kernel
private theorem w1222_2 : checkWitness 1222 true false 90 = true := by decide +kernel
private theorem cases1222 : checkFour 1222 (90,0,90,0) = true := by
  simp only [checkFour, w1222_0, w1222_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1222 : Coverage 1222 1223 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1222)
private theorem w1223_0 : checkWitness 1223 false false 624 = true := by decide +kernel
private theorem w1223_1 : checkWitness 1223 false true 4716 = true := by decide +kernel
private theorem w1223_2 : checkWitness 1223 true false 615 = true := by decide +kernel
private theorem w1223_3 : checkWitness 1223 true true 4707 = true := by decide +kernel
private theorem cases1223 : checkFour 1223 (624,4716,615,4707) = true := by
  simp only [checkFour, w1223_0, w1223_1, w1223_2, w1223_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1223 : Coverage 1223 1224 := checkList_sound (ws:=[(624,4716,615,4707)]) (by simpa only [checkList, Bool.and_true] using cases1223)
private theorem w1224_0 : checkWitness 1224 false false 8901 = true := by decide +kernel
private theorem w1224_2 : checkWitness 1224 true false 8892 = true := by decide +kernel
private theorem cases1224 : checkFour 1224 (8901,0,8892,0) = true := by
  simp only [checkFour, w1224_0, w1224_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1224 : Coverage 1224 1225 := checkList_sound (ws:=[(8901,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases1224)
private theorem w1225_0 : checkWitness 1225 false false 74 = true := by decide +kernel
private theorem w1225_2 : checkWitness 1225 true false 74 = true := by decide +kernel
private theorem cases1225 : checkFour 1225 (74,0,74,0) = true := by
  simp only [checkFour, w1225_0, w1225_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1225 : Coverage 1225 1226 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases1225)
private theorem w1226_0 : checkWitness 1226 false false 488 = true := by decide +kernel
private theorem w1226_1 : checkWitness 1226 false true 4584 = true := by decide +kernel
private theorem w1226_2 : checkWitness 1226 true false 488 = true := by decide +kernel
private theorem w1226_3 : checkWitness 1226 true true 4584 = true := by decide +kernel
private theorem cases1226 : checkFour 1226 (488,4584,488,4584) = true := by
  simp only [checkFour, w1226_0, w1226_1, w1226_2, w1226_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1226 : Coverage 1226 1227 := checkList_sound (ws:=[(488,4584,488,4584)]) (by simpa only [checkList, Bool.and_true] using cases1226)
private theorem w1227_0 : checkWitness 1227 false false 8883 = true := by decide +kernel
private theorem w1227_2 : checkWitness 1227 true false 8879 = true := by decide +kernel
private theorem cases1227 : checkFour 1227 (8883,0,8879,0) = true := by
  simp only [checkFour, w1227_0, w1227_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1227 : Coverage 1227 1228 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1227)
private theorem w1228_0 : checkWitness 1228 false false 614 = true := by decide +kernel
private theorem w1228_1 : checkWitness 1228 false true 4710 = true := by decide +kernel
private theorem w1228_2 : checkWitness 1228 true false 605 = true := by decide +kernel
private theorem w1228_3 : checkWitness 1228 true true 4701 = true := by decide +kernel
private theorem cases1228 : checkFour 1228 (614,4710,605,4701) = true := by
  simp only [checkFour, w1228_0, w1228_1, w1228_2, w1228_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1228 : Coverage 1228 1229 := checkList_sound (ws:=[(614,4710,605,4701)]) (by simpa only [checkList, Bool.and_true] using cases1228)
private theorem w1229_0 : checkWitness 1229 false false 172 = true := by decide +kernel
private theorem w1229_2 : checkWitness 1229 true false 172 = true := by decide +kernel
private theorem cases1229 : checkFour 1229 (172,0,172,0) = true := by
  simp only [checkFour, w1229_0, w1229_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1229 : Coverage 1229 1230 := checkList_sound (ws:=[(172,0,172,0)]) (by simpa only [checkList, Bool.and_true] using cases1229)
private theorem w1230_0 : checkWitness 1230 false false 569 = true := by decide +kernel
private theorem w1230_1 : checkWitness 1230 false true 4657 = true := by decide +kernel
private theorem w1230_2 : checkWitness 1230 true false 569 = true := by decide +kernel
private theorem w1230_3 : checkWitness 1230 true true 4657 = true := by decide +kernel
private theorem cases1230 : checkFour 1230 (569,4657,569,4657) = true := by
  simp only [checkFour, w1230_0, w1230_1, w1230_2, w1230_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1230 : Coverage 1230 1231 := checkList_sound (ws:=[(569,4657,569,4657)]) (by simpa only [checkList, Bool.and_true] using cases1230)
private theorem w1231_0 : checkWitness 1231 false false 8898 = true := by decide +kernel
private theorem w1231_2 : checkWitness 1231 true false 8889 = true := by decide +kernel
private theorem cases1231 : checkFour 1231 (8898,0,8889,0) = true := by
  simp only [checkFour, w1231_0, w1231_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1231 : Coverage 1231 1232 := checkList_sound (ws:=[(8898,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1231)
private theorem w1232_0 : checkWitness 1232 false false 92 = true := by decide +kernel
private theorem w1232_2 : checkWitness 1232 true false 92 = true := by decide +kernel
private theorem cases1232 : checkFour 1232 (92,0,92,0) = true := by
  simp only [checkFour, w1232_0, w1232_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1232 : Coverage 1232 1233 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1232)
private theorem w1233_0 : checkWitness 1233 false false 84 = true := by decide +kernel
private theorem w1233_2 : checkWitness 1233 true false 84 = true := by decide +kernel
private theorem cases1233 : checkFour 1233 (84,0,84,0) = true := by
  simp only [checkFour, w1233_0, w1233_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1233 : Coverage 1233 1234 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1233)
private theorem w1234_0 : checkWitness 1234 false false 575 = true := by decide +kernel
private theorem w1234_1 : checkWitness 1234 false true 4667 = true := by decide +kernel
private theorem w1234_2 : checkWitness 1234 true false 575 = true := by decide +kernel
private theorem w1234_3 : checkWitness 1234 true true 4667 = true := by decide +kernel
private theorem cases1234 : checkFour 1234 (575,4667,575,4667) = true := by
  simp only [checkFour, w1234_0, w1234_1, w1234_2, w1234_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1234 : Coverage 1234 1235 := checkList_sound (ws:=[(575,4667,575,4667)]) (by simpa only [checkList, Bool.and_true] using cases1234)
private theorem w1235_0 : checkWitness 1235 false false 8836 = true := by decide +kernel
private theorem w1235_2 : checkWitness 1235 true false 8832 = true := by decide +kernel
private theorem cases1235 : checkFour 1235 (8836,0,8832,0) = true := by
  simp only [checkFour, w1235_0, w1235_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1235 : Coverage 1235 1236 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1235)
private theorem w1236_0 : checkWitness 1236 false false 84 = true := by decide +kernel
private theorem w1236_2 : checkWitness 1236 true false 84 = true := by decide +kernel
private theorem cases1236 : checkFour 1236 (84,0,84,0) = true := by
  simp only [checkFour, w1236_0, w1236_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1236 : Coverage 1236 1237 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1236)
private theorem w1237_0 : checkWitness 1237 false false 530 = true := by decide +kernel
private theorem w1237_1 : checkWitness 1237 false true 4626 = true := by decide +kernel
private theorem w1237_2 : checkWitness 1237 true false 530 = true := by decide +kernel
private theorem w1237_3 : checkWitness 1237 true true 4626 = true := by decide +kernel
private theorem cases1237 : checkFour 1237 (530,4626,530,4626) = true := by
  simp only [checkFour, w1237_0, w1237_1, w1237_2, w1237_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1237 : Coverage 1237 1238 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases1237)
private theorem w1238_0 : checkWitness 1238 false false 8871 = true := by decide +kernel
private theorem w1238_2 : checkWitness 1238 true false 8867 = true := by decide +kernel
private theorem cases1238 : checkFour 1238 (8871,0,8867,0) = true := by
  simp only [checkFour, w1238_0, w1238_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1238 : Coverage 1238 1239 := checkList_sound (ws:=[(8871,0,8867,0)]) (by simpa only [checkList, Bool.and_true] using cases1238)
private theorem w1239_0 : checkWitness 1239 false false 8906 = true := by decide +kernel
private theorem w1239_2 : checkWitness 1239 true false 8897 = true := by decide +kernel
private theorem cases1239 : checkFour 1239 (8906,0,8897,0) = true := by
  simp only [checkFour, w1239_0, w1239_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1239 : Coverage 1239 1240 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1239)
private theorem w1240_0 : checkWitness 1240 false false 102 = true := by decide +kernel
private theorem w1240_2 : checkWitness 1240 true false 102 = true := by decide +kernel
private theorem cases1240 : checkFour 1240 (102,0,102,0) = true := by
  simp only [checkFour, w1240_0, w1240_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1240 : Coverage 1240 1241 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1240)
private theorem w1241_0 : checkWitness 1241 false false 618 = true := by decide +kernel
private theorem w1241_1 : checkWitness 1241 false true 4710 = true := by decide +kernel
private theorem w1241_2 : checkWitness 1241 true false 609 = true := by decide +kernel
private theorem w1241_3 : checkWitness 1241 true true 4701 = true := by decide +kernel
private theorem cases1241 : checkFour 1241 (618,4710,609,4701) = true := by
  simp only [checkFour, w1241_0, w1241_1, w1241_2, w1241_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1241 : Coverage 1241 1242 := checkList_sound (ws:=[(618,4710,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases1241)
private theorem w1242_0 : checkWitness 1242 false false 8867 = true := by decide +kernel
private theorem w1242_2 : checkWitness 1242 true false 8863 = true := by decide +kernel
private theorem cases1242 : checkFour 1242 (8867,0,8863,0) = true := by
  simp only [checkFour, w1242_0, w1242_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1242 : Coverage 1242 1243 := checkList_sound (ws:=[(8867,0,8863,0)]) (by simpa only [checkList, Bool.and_true] using cases1242)
private theorem w1243_0 : checkWitness 1243 false false 612 = true := by decide +kernel
private theorem w1243_1 : checkWitness 1243 false true 4704 = true := by decide +kernel
private theorem w1243_2 : checkWitness 1243 true false 603 = true := by decide +kernel
private theorem w1243_3 : checkWitness 1243 true true 4695 = true := by decide +kernel
private theorem cases1243 : checkFour 1243 (612,4704,603,4695) = true := by
  simp only [checkFour, w1243_0, w1243_1, w1243_2, w1243_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1243 : Coverage 1243 1244 := checkList_sound (ws:=[(612,4704,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases1243)
private theorem w1244_0 : checkWitness 1244 false false 8836 = true := by decide +kernel
private theorem w1244_2 : checkWitness 1244 true false 8832 = true := by decide +kernel
private theorem cases1244 : checkFour 1244 (8836,0,8832,0) = true := by
  simp only [checkFour, w1244_0, w1244_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1244 : Coverage 1244 1245 := checkList_sound (ws:=[(8836,0,8832,0)]) (by simpa only [checkList, Bool.and_true] using cases1244)
private theorem w1245_0 : checkWitness 1245 false false 90 = true := by decide +kernel
private theorem w1245_2 : checkWitness 1245 true false 90 = true := by decide +kernel
private theorem cases1245 : checkFour 1245 (90,0,90,0) = true := by
  simp only [checkFour, w1245_0, w1245_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1245 : Coverage 1245 1246 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1245)
private theorem w1246_0 : checkWitness 1246 false false 82 = true := by decide +kernel
private theorem w1246_2 : checkWitness 1246 true false 82 = true := by decide +kernel
private theorem cases1246 : checkFour 1246 (82,0,82,0) = true := by
  simp only [checkFour, w1246_0, w1246_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1246 : Coverage 1246 1247 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1246)
private theorem w1247_0 : checkWitness 1247 false false 579 = true := by decide +kernel
private theorem w1247_1 : checkWitness 1247 false true 4667 = true := by decide +kernel
private theorem w1247_2 : checkWitness 1247 true false 579 = true := by decide +kernel
private theorem w1247_3 : checkWitness 1247 true true 4667 = true := by decide +kernel
private theorem cases1247 : checkFour 1247 (579,4667,579,4667) = true := by
  simp only [checkFour, w1247_0, w1247_1, w1247_2, w1247_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1247 : Coverage 1247 1248 := checkList_sound (ws:=[(579,4667,579,4667)]) (by simpa only [checkList, Bool.and_true] using cases1247)
theorem cover1216 : Coverage 1216 1248 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1216 one1217) (Coverage.join one1218 one1219)) (Coverage.join (Coverage.join one1220 one1221) (Coverage.join one1222 one1223))) (Coverage.join (Coverage.join (Coverage.join one1224 one1225) (Coverage.join one1226 one1227)) (Coverage.join (Coverage.join one1228 one1229) (Coverage.join one1230 one1231)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1232 one1233) (Coverage.join one1234 one1235)) (Coverage.join (Coverage.join one1236 one1237) (Coverage.join one1238 one1239))) (Coverage.join (Coverage.join (Coverage.join one1240 one1241) (Coverage.join one1242 one1243)) (Coverage.join (Coverage.join one1244 one1245) (Coverage.join one1246 one1247)))))
end NF181PA.Symbolic
