module
public import Direct181Snapshots
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem chunk6500 : Prefix 500 snap6000 snap6500 := checked _ _ _ (by decide) (by decide)
theorem chunk7000 : Prefix 500 snap6500 snap7000 := checked _ _ _ (by decide) (by decide)
theorem chunk7500 : Prefix 500 snap7000 snap7500 := checked _ _ _ (by decide) (by decide)
theorem chunk8000 : Prefix 500 snap7500 snap8000 := checked _ _ _ (by decide) (by decide)
theorem chunk8500 : Prefix 500 snap8000 snap8500 := checked _ _ _ (by decide) (by decide)
theorem chunk9000 : Prefix 500 snap8500 snap9000 := checked _ _ _ (by decide) (by decide)
theorem chunk9500 : Prefix 500 snap9000 snap9500 := checked _ _ _ (by decide) (by decide)
theorem chunk10000 : Prefix 500 snap9500 snap10000 := checked _ _ _ (by decide) (by decide)
theorem chunk10500 : Prefix 500 snap10000 snap10500 := checked _ _ _ (by decide) (by decide)
theorem chunk11000 : Prefix 500 snap10500 snap11000 := checked _ _ _ (by decide) (by decide)
theorem chunk11500 : Prefix 500 snap11000 snap11500 := checked _ _ _ (by decide) (by decide)
theorem chunk12000 : Prefix 500 snap11500 snap12000 := checked _ _ _ (by decide) (by decide)
end Direct181.Boot
