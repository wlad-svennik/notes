module
public import NF181PAPacked
public import ModelExtract
public import ModelCommandDefinability
import Mathlib.Tactic.FinCases

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.Words NF181PA.Packed
namespace NF181PA.Commands
export PA192.ModelSearch.Compiler (cmdMP cmdMode cmdAX blank singleton literal lit_nil lit_cons)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3500000
set_option maxRecDepth 16000

noncomputable def deduction (d e : V) : V :=
  let b := param e + d
  state (if cache e=imp (top e) b then b else 0) (right (stack e)) (left (stack e)) 0
instance deductionDef : Language.DefinableFunction₂ ℒₒᵣ (deduction (V:=V)) := by
  apply Language.Definable.of_iff (Q:=fun v : Fin 3 → V =>
    let t:=top (v 2); let s:=stack (v 2); let h:=cache (v 2); let b:=param (v 2)+v 1
    (h=imp t b ∧ v 0=state b (right s) (left s) 0) ∨
    (h≠imp t b ∧ v 0=state 0 (right s) (left s) 0))
  · dsimp [top,stack,cache,param,state,imp]; definability
  · intro v; by_cases h : cache (v 2)=imp (top (v 2)) (param (v 2)+v 1) <;> simp [deduction,h]

theorem deduction_state (d t s h p : V) : deduction d (state t s h p) =
    state (if h=imp t (p+d) then p+d else 0) (right s) (left s) 0 := by
  simp [deduction,state,top,cache,stack,param]

noncomputable def axOn (args e : V) : V :=
  let u := pi₁ args
  let y := pi₁ (pi₂ args)
  let d := pi₁ (pi₂ (pi₂ args))
  let c := pi₂ (pi₂ (pi₂ args))
  pi₁ (axRaw u y d c (zeroBatches c 0) e)

/-- Foundation's definability API takes the six inputs as an indexed tuple. -/
instance axRawDef : Language.DefinableFunction ℒₒᵣ
    (fun v : Fin 6 → V => axRaw (v 0) (v 1) (v 2) (v 3) (v 4) (v 5)) := by
  let first (v : Fin 6 → V) := front8 ((param (v 5)+v 0)+v 2) (cache (v 5)+v 1)
    (v 3) (param (v 5)+v 0) (cantor (top (v 5)) (stack (v 5)))
  have fdef : Language.DefinableFunction ℒₒᵣ first := by
    dsimp only [first,param,cache,top,stack]
    apply Language.DefinableFunction₅.comp (F:=front8) <;> definability
  let start (v : Fin 6 → V) := packBatch (v 3) (first v) ((param (v 5)+v 0)+v 2) (cache (v 5)+v 1) (v 4)
  have sdef : Language.DefinableFunction ℒₒᵣ start := by
    dsimp only [start,packBatch,param,cache]
    apply Language.DefinableFunction₂.comp (F:=pair) (by definability)
    exact Language.DefinableFunction₂.comp (F:=pair) fdef (by definability)
  let out (v : Fin 6 → V) := iterate nextBatch (v 3) (start v)
  have odef : Language.DefinableFunction ℒₒᵣ out :=
    Language.DefinableFunction₂.comp (F:=iterate nextBatch) (by definability) sdef
  change Language.DefinableFunction ℒₒᵣ (fun v : Fin 6 → V => ⟪afterAX (body (out v)),fields (out v)⟫)
  unfold body fields
  apply Language.DefinableFunction₂.comp (F:=pair)
  · apply Language.DefinableFunction₁.comp (F:=afterAX)
    exact Language.DefinableFunction₁.comp (F:=pi₁) (Language.DefinableFunction₁.comp (F:=pi₂) odef)
  · repeat' apply Language.DefinableFunction₁.comp (F:=pi₂)
    exact odef
instance axOnDef : Language.DefinableFunction₂ ℒₒᵣ (axOn (V:=V)) := by
  let A (i : Fin 6) (v : Fin 2 → V) := ![pi₁ (v 0),pi₁ (pi₂ (v 0)),pi₁ (pi₂ (pi₂ (v 0))),
    pi₂ (pi₂ (pi₂ (v 0))),zeroBatches (pi₂ (pi₂ (pi₂ (v 0)))) 0,v 1] i
  have args (i : Fin 6) : Language.DefinableFunction ℒₒᵣ (A i) := by
    fin_cases i <;> dsimp [A] <;> definability
  apply Language.DefinableFunction₁.comp (F:=pi₁)
  exact Language.DefinableFunction.substitution (f:=A) (axRawDef (V:=V)) args

noncomputable def exec (cmd e : V) : V :=
  let tag := pi₁ cmd
  let a := pi₂ cmd
  chooseZero tag (mode a e) (chooseZero (tag-1) (deduction a e) (axOn a e))
instance execDef : Language.DefinableFunction₂ ℒₒᵣ (exec (V:=V)) := by
  unfold exec; definability

@[simp] theorem exec_mp (d e : V) : exec (cmdMP d) e = mode d e := by simp [exec,cmdMP,chooseZero]
@[simp] theorem exec_mode (d e : V) : exec (cmdMode d) e = deduction d e := by simp [exec,cmdMode,chooseZero]
@[simp] theorem exec_ax (u b d c e : V) : exec (cmdAX u b d c) e =
    pi₁ (axRaw u b d c (zeroBatches c 0) e) := by
  have two : (2:V)=1+1 := by norm_num
  have minus : (2:V)-1=1 := by rw [two]; simp
  simp [exec,cmdAX,chooseZero,minus,axOn]

noncomputable def nip : V := cmdMP 0
noncomputable def swap : V := cmdMP 1
@[simp] theorem nip_packed (t s h : V) : exec nip (state t s h 0)=state t (right s) (left s) 0 := by
  simp [nip,nip_state]
@[simp] theorem swap_packed (t s h : V) : exec swap (state t s h 0)=state h s t 0 := by
  simp [swap,swap_state]
@[simp] theorem blank_packed (t s h p : V) : exec blank (state t s h p)=
    state 0 (front6 p h 0 p (cantor t s)) (Pool.test h p) 0 := by simp [blank,ax_zero]

instance consNipDef : Language.DefinableFunction₁ ℒₒᵣ (cons (nip:V)) := by
  unfold nip cmdMP; definability
noncomputable def nips (n : V) := iterate (cons (nip : V)) n 0
instance nipsDef : Language.DefinableFunction₁ ℒₒᵣ (nips (V:=V)) := by unfold nips; definability
@[simp] theorem nips_zero : nips (0:V)=0 := by simp [nips]
theorem nips_succ (n : V) : nips (n+1) = cons nip (nips n) := iterate_succ _ _ _
theorem nip_add (a b s : V) : run exec (nips (a+b)) s = run exec (nips b) (run exec (nips a) s) := by
  have aux : ∀ n : V, ∀ p, run exec (nips (n+b)) p = run exec (nips b) (run exec (nips n) p) := by
    apply modelInduct
    · definability
    · simp
    · intro n ih p; rw [add_right_comm n 1 b,nips_succ,nips_succ,run_cons,run_cons,ih]
  exact aux a s
@[simp] theorem run_single (x s : V) : run exec (singleton x) s=exec x s := by simp [singleton]
end NF181PA.Commands
