module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site2741Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2741 f r x y z) (slots710.atReg 2745 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2741 4 2745 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2741 2745 2742 f r (row_of_literal 2741 _ (by decide) RawRows.raw2741))
    (slots710.pos_x 2741 2745 2742 f r (row_of_literal 2741 _ (by decide) RawRows.raw2741))
    (slots710.inc_y 2742 2743 f r (row_of_literal 2742 _ (by decide) RawRows.raw2742) (Or.inl (by decide)))
    (slots710.inc_y 2743 2744 f r (row_of_literal 2743 _ (by decide) RawRows.raw2743) (Or.inl (by decide)))
    (slots710.jump 2744 2741 f r (row_of_literal 2744 _ (by decide) RawRows.raw2744))

theorem site2741 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2741:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2745:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2741Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2745 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2745:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2746:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2745 _ (row_of_literal 2745 _ (by decide) RawRows.raw2745)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2746Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2746 f r x y z) (slots160.atReg 2749 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2746 3 2749 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2746 2749 2747 f r (row_of_literal 2746 _ (by decide) RawRows.raw2746))
    (slots160.pos_x 2746 2749 2747 f r (row_of_literal 2746 _ (by decide) RawRows.raw2746))
    (slots160.inc_y 2747 2748 f r (row_of_literal 2747 _ (by decide) RawRows.raw2747) (Or.inl (by decide)))
    (slots160.jump 2748 2746 f r (row_of_literal 2748 _ (by decide) RawRows.raw2748))

theorem site2746 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2746:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2749:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2746Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2749Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2749 f r x y z) (slots210.atReg 2752 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2749 3 2752 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2749 2752 2750 f r (row_of_literal 2749 _ (by decide) RawRows.raw2749))
    (slots210.pos_x 2749 2752 2750 f r (row_of_literal 2749 _ (by decide) RawRows.raw2749))
    (slots210.inc_y 2750 2751 f r (row_of_literal 2750 _ (by decide) RawRows.raw2750) (Or.inl (by decide)))
    (slots210.jump 2751 2749 f r (row_of_literal 2751 _ (by decide) RawRows.raw2751))

theorem site2749 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2749:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2752:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2749Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2752Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2752 f r x y z) (slots617.atReg 2762 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2752 10 2762 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2752 2756 2753 f r (row_of_literal 2752 _ (by decide) RawRows.raw2752))
    (slots617.pos_y 2752 2756 2753 f r (row_of_literal 2752 _ (by decide) RawRows.raw2752))
    (slots617.inc_z 2753 2754 f r (row_of_literal 2753 _ (by decide) RawRows.raw2753) (Or.inl (by decide)))
    (slots617.inc_x 2754 2755 f r (row_of_literal 2754 _ (by decide) RawRows.raw2754) (Or.inl (by decide)))
    (slots617.jump 2755 2752 f r (row_of_literal 2755 _ (by decide) RawRows.raw2755))
    (slots617.zero_x 2756 2762 2757 f r (row_of_literal 2756 _ (by decide) RawRows.raw2756))
    (slots617.pos_x 2756 2762 2757 f r (row_of_literal 2756 _ (by decide) RawRows.raw2756))
    (slots617.inc_z 2757 2758 f r (row_of_literal 2757 _ (by decide) RawRows.raw2757) (Or.inl (by decide)))
    (slots617.zero_x 2758 2761 2759 f r (row_of_literal 2758 _ (by decide) RawRows.raw2758))
    (slots617.pos_x 2758 2761 2759 f r (row_of_literal 2758 _ (by decide) RawRows.raw2758))
    (slots617.inc_y 2759 2760 f r (row_of_literal 2759 _ (by decide) RawRows.raw2759) (Or.inl (by decide)))
    (slots617.jump 2760 2758 f r (row_of_literal 2760 _ (by decide) RawRows.raw2760))
    (slots617.jump 2761 2752 f r (row_of_literal 2761 _ (by decide) RawRows.raw2761))

theorem site2752 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2752:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2762:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2752Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2762Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2762 f r x y z) (slots720.atReg 2765 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2762 3 2765 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2762 2765 2763 f r (row_of_literal 2762 _ (by decide) RawRows.raw2762))
    (slots720.pos_x 2762 2765 2763 f r (row_of_literal 2762 _ (by decide) RawRows.raw2762))
    (slots720.inc_y 2763 2764 f r (row_of_literal 2763 _ (by decide) RawRows.raw2763) (Or.inl (by decide)))
    (slots720.jump 2764 2762 f r (row_of_literal 2764 _ (by decide) RawRows.raw2764))

theorem site2762 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2762:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2765:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2762Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2765Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2765 f r x y z) (slots461.atReg 2769 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2765 4 2769 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2765 2769 2766 f r (row_of_literal 2765 _ (by decide) RawRows.raw2765))
    (slots461.pos_x 2765 2769 2766 f r (row_of_literal 2765 _ (by decide) RawRows.raw2765))
    (slots461.inc_y 2766 2767 f r (row_of_literal 2766 _ (by decide) RawRows.raw2766) (Or.inl (by decide)))
    (slots461.inc_z 2767 2768 f r (row_of_literal 2767 _ (by decide) RawRows.raw2767) (Or.inl (by decide)))
    (slots461.jump 2768 2765 f r (row_of_literal 2768 _ (by decide) RawRows.raw2768))

theorem site2765 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2765:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2769:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2765Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site2769Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2769 f r x y z) (slots640.atReg 2772 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2769 3 2772 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2769 2772 2770 f r (row_of_literal 2769 _ (by decide) RawRows.raw2769))
    (slots640.pos_x 2769 2772 2770 f r (row_of_literal 2769 _ (by decide) RawRows.raw2769))
    (slots640.inc_y 2770 2771 f r (row_of_literal 2770 _ (by decide) RawRows.raw2770) (Or.inl (by decide)))
    (slots640.jump 2771 2769 f r (row_of_literal 2771 _ (by decide) RawRows.raw2771))

theorem site2769 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2769:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2772:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2769Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site2772Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2772 f r x y z) (slots160.atReg 2775 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2772 3 2775 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2772 2775 2773 f r (row_of_literal 2772 _ (by decide) RawRows.raw2772))
    (slots160.pos_x 2772 2775 2773 f r (row_of_literal 2772 _ (by decide) RawRows.raw2772))
    (slots160.inc_y 2773 2774 f r (row_of_literal 2773 _ (by decide) RawRows.raw2773) (Or.inl (by decide)))
    (slots160.jump 2774 2772 f r (row_of_literal 2774 _ (by decide) RawRows.raw2774))

theorem site2772 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2772:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2775:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2772Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2775Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2775 f r x y z) (slots210.atReg 2778 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2775 3 2778 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2775 2778 2776 f r (row_of_literal 2775 _ (by decide) RawRows.raw2775))
    (slots210.pos_x 2775 2778 2776 f r (row_of_literal 2775 _ (by decide) RawRows.raw2775))
    (slots210.inc_y 2776 2777 f r (row_of_literal 2776 _ (by decide) RawRows.raw2776) (Or.inl (by decide)))
    (slots210.jump 2777 2775 f r (row_of_literal 2777 _ (by decide) RawRows.raw2777))

theorem site2775 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2775:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2778:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2775Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2778Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2778 f r x y z) (slots617.atReg 2788 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2778 10 2788 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2778 2782 2779 f r (row_of_literal 2778 _ (by decide) RawRows.raw2778))
    (slots617.pos_y 2778 2782 2779 f r (row_of_literal 2778 _ (by decide) RawRows.raw2778))
    (slots617.inc_z 2779 2780 f r (row_of_literal 2779 _ (by decide) RawRows.raw2779) (Or.inl (by decide)))
    (slots617.inc_x 2780 2781 f r (row_of_literal 2780 _ (by decide) RawRows.raw2780) (Or.inl (by decide)))
    (slots617.jump 2781 2778 f r (row_of_literal 2781 _ (by decide) RawRows.raw2781))
    (slots617.zero_x 2782 2788 2783 f r (row_of_literal 2782 _ (by decide) RawRows.raw2782))
    (slots617.pos_x 2782 2788 2783 f r (row_of_literal 2782 _ (by decide) RawRows.raw2782))
    (slots617.inc_z 2783 2784 f r (row_of_literal 2783 _ (by decide) RawRows.raw2783) (Or.inl (by decide)))
    (slots617.zero_x 2784 2787 2785 f r (row_of_literal 2784 _ (by decide) RawRows.raw2784))
    (slots617.pos_x 2784 2787 2785 f r (row_of_literal 2784 _ (by decide) RawRows.raw2784))
    (slots617.inc_y 2785 2786 f r (row_of_literal 2785 _ (by decide) RawRows.raw2785) (Or.inl (by decide)))
    (slots617.jump 2786 2784 f r (row_of_literal 2786 _ (by decide) RawRows.raw2786))
    (slots617.jump 2787 2778 f r (row_of_literal 2787 _ (by decide) RawRows.raw2787))

theorem site2778 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2778:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2788:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2778Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2788Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2788 f r x y z) (slots720.atReg 2791 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2788 3 2791 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2788 2791 2789 f r (row_of_literal 2788 _ (by decide) RawRows.raw2788))
    (slots720.pos_x 2788 2791 2789 f r (row_of_literal 2788 _ (by decide) RawRows.raw2788))
    (slots720.inc_y 2789 2790 f r (row_of_literal 2789 _ (by decide) RawRows.raw2789) (Or.inl (by decide)))
    (slots720.jump 2790 2788 f r (row_of_literal 2790 _ (by decide) RawRows.raw2790))

theorem site2788 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2788:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2791:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2788Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2791Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2791 f r x y z) (slots561.atReg 2795 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2791 4 2795 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2791 2795 2792 f r (row_of_literal 2791 _ (by decide) RawRows.raw2791))
    (slots561.pos_x 2791 2795 2792 f r (row_of_literal 2791 _ (by decide) RawRows.raw2791))
    (slots561.inc_y 2792 2793 f r (row_of_literal 2792 _ (by decide) RawRows.raw2792) (Or.inl (by decide)))
    (slots561.inc_z 2793 2794 f r (row_of_literal 2793 _ (by decide) RawRows.raw2793) (Or.inl (by decide)))
    (slots561.jump 2794 2791 f r (row_of_literal 2794 _ (by decide) RawRows.raw2794))

theorem site2791 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2791:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2795:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2791Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2795Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2795 f r x y z) (slots650.atReg 2798 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2795 3 2798 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2795 2798 2796 f r (row_of_literal 2795 _ (by decide) RawRows.raw2795))
    (slots650.pos_x 2795 2798 2796 f r (row_of_literal 2795 _ (by decide) RawRows.raw2795))
    (slots650.inc_y 2796 2797 f r (row_of_literal 2796 _ (by decide) RawRows.raw2796) (Or.inl (by decide)))
    (slots650.jump 2797 2795 f r (row_of_literal 2797 _ (by decide) RawRows.raw2797))

theorem site2795 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2795:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2798:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2795Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2798Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2798 f r x y z) (slots267.atReg 2806 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2798 8 2806 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2798 2806 2799 f r (row_of_literal 2798 _ (by decide) RawRows.raw2798))
    (slots267.pos_x 2798 2806 2799 f r (row_of_literal 2798 _ (by decide) RawRows.raw2798))
    (slots267.inc_z 2799 2800 f r (row_of_literal 2799 _ (by decide) RawRows.raw2799) (Or.inl (by decide)))
    (slots267.zero_y 2800 2802 2801 f r (row_of_literal 2800 _ (by decide) RawRows.raw2800))
    (slots267.pos_y 2800 2802 2801 f r (row_of_literal 2800 _ (by decide) RawRows.raw2800))
    (slots267.jump 2801 2805 f r (row_of_literal 2801 _ (by decide) RawRows.raw2801))
    (slots267.zero_z 2802 2805 2803 f r (row_of_literal 2802 _ (by decide) RawRows.raw2802))
    (slots267.pos_z 2802 2805 2803 f r (row_of_literal 2802 _ (by decide) RawRows.raw2802))
    (slots267.inc_y 2803 2804 f r (row_of_literal 2803 _ (by decide) RawRows.raw2803) (Or.inl (by decide)))
    (slots267.jump 2804 2802 f r (row_of_literal 2804 _ (by decide) RawRows.raw2804))
    (slots267.jump 2805 2798 f r (row_of_literal 2805 _ (by decide) RawRows.raw2805))

theorem site2798 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2798:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2806:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2798Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2806Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2806 f r x y z) (slots720.atReg 2809 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2806 3 2809 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2806 2809 2807 f r (row_of_literal 2806 _ (by decide) RawRows.raw2806))
    (slots720.pos_x 2806 2809 2807 f r (row_of_literal 2806 _ (by decide) RawRows.raw2806))
    (slots720.inc_y 2807 2808 f r (row_of_literal 2807 _ (by decide) RawRows.raw2807) (Or.inl (by decide)))
    (slots720.jump 2808 2806 f r (row_of_literal 2808 _ (by decide) RawRows.raw2808))

theorem site2806 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2806:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2809:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2806Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2809Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2809 f r x y z) (slots617.atReg 2819 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2809 10 2819 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2809 2813 2810 f r (row_of_literal 2809 _ (by decide) RawRows.raw2809))
    (slots617.pos_y 2809 2813 2810 f r (row_of_literal 2809 _ (by decide) RawRows.raw2809))
    (slots617.inc_z 2810 2811 f r (row_of_literal 2810 _ (by decide) RawRows.raw2810) (Or.inl (by decide)))
    (slots617.inc_x 2811 2812 f r (row_of_literal 2811 _ (by decide) RawRows.raw2811) (Or.inl (by decide)))
    (slots617.jump 2812 2809 f r (row_of_literal 2812 _ (by decide) RawRows.raw2812))
    (slots617.zero_x 2813 2819 2814 f r (row_of_literal 2813 _ (by decide) RawRows.raw2813))
    (slots617.pos_x 2813 2819 2814 f r (row_of_literal 2813 _ (by decide) RawRows.raw2813))
    (slots617.inc_z 2814 2815 f r (row_of_literal 2814 _ (by decide) RawRows.raw2814) (Or.inl (by decide)))
    (slots617.zero_x 2815 2818 2816 f r (row_of_literal 2815 _ (by decide) RawRows.raw2815))
    (slots617.pos_x 2815 2818 2816 f r (row_of_literal 2815 _ (by decide) RawRows.raw2815))
    (slots617.inc_y 2816 2817 f r (row_of_literal 2816 _ (by decide) RawRows.raw2816) (Or.inl (by decide)))
    (slots617.jump 2817 2815 f r (row_of_literal 2817 _ (by decide) RawRows.raw2817))
    (slots617.jump 2818 2809 f r (row_of_literal 2818 _ (by decide) RawRows.raw2818))

theorem site2809 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2809:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2819:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2809Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2819Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2819 f r x y z) (slots710.atReg 2823 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2819 4 2823 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2819 2823 2820 f r (row_of_literal 2819 _ (by decide) RawRows.raw2819))
    (slots710.pos_x 2819 2823 2820 f r (row_of_literal 2819 _ (by decide) RawRows.raw2819))
    (slots710.inc_y 2820 2821 f r (row_of_literal 2820 _ (by decide) RawRows.raw2820) (Or.inl (by decide)))
    (slots710.inc_y 2821 2822 f r (row_of_literal 2821 _ (by decide) RawRows.raw2821) (Or.inl (by decide)))
    (slots710.jump 2822 2819 f r (row_of_literal 2822 _ (by decide) RawRows.raw2822))

theorem site2819 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2819:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2823:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2819Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2823 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2823:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2824:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2823 _ (row_of_literal 2823 _ (by decide) RawRows.raw2823)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2824Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2824 f r x y z) (slots267.atReg 2832 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2824 8 2832 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2824 2832 2825 f r (row_of_literal 2824 _ (by decide) RawRows.raw2824))
    (slots267.pos_x 2824 2832 2825 f r (row_of_literal 2824 _ (by decide) RawRows.raw2824))
    (slots267.inc_z 2825 2826 f r (row_of_literal 2825 _ (by decide) RawRows.raw2825) (Or.inl (by decide)))
    (slots267.zero_y 2826 2828 2827 f r (row_of_literal 2826 _ (by decide) RawRows.raw2826))
    (slots267.pos_y 2826 2828 2827 f r (row_of_literal 2826 _ (by decide) RawRows.raw2826))
    (slots267.jump 2827 2831 f r (row_of_literal 2827 _ (by decide) RawRows.raw2827))
    (slots267.zero_z 2828 2831 2829 f r (row_of_literal 2828 _ (by decide) RawRows.raw2828))
    (slots267.pos_z 2828 2831 2829 f r (row_of_literal 2828 _ (by decide) RawRows.raw2828))
    (slots267.inc_y 2829 2830 f r (row_of_literal 2829 _ (by decide) RawRows.raw2829) (Or.inl (by decide)))
    (slots267.jump 2830 2828 f r (row_of_literal 2830 _ (by decide) RawRows.raw2830))
    (slots267.jump 2831 2824 f r (row_of_literal 2831 _ (by decide) RawRows.raw2831))

theorem site2824 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2824:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2832:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2824Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2832Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2832 f r x y z) (slots720.atReg 2835 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2832 3 2835 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2832 2835 2833 f r (row_of_literal 2832 _ (by decide) RawRows.raw2832))
    (slots720.pos_x 2832 2835 2833 f r (row_of_literal 2832 _ (by decide) RawRows.raw2832))
    (slots720.inc_y 2833 2834 f r (row_of_literal 2833 _ (by decide) RawRows.raw2833) (Or.inl (by decide)))
    (slots720.jump 2834 2832 f r (row_of_literal 2834 _ (by decide) RawRows.raw2834))

theorem site2832 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2832:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2835:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2832Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2835Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2835 f r x y z) (slots617.atReg 2845 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2835 10 2845 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2835 2839 2836 f r (row_of_literal 2835 _ (by decide) RawRows.raw2835))
    (slots617.pos_y 2835 2839 2836 f r (row_of_literal 2835 _ (by decide) RawRows.raw2835))
    (slots617.inc_z 2836 2837 f r (row_of_literal 2836 _ (by decide) RawRows.raw2836) (Or.inl (by decide)))
    (slots617.inc_x 2837 2838 f r (row_of_literal 2837 _ (by decide) RawRows.raw2837) (Or.inl (by decide)))
    (slots617.jump 2838 2835 f r (row_of_literal 2838 _ (by decide) RawRows.raw2838))
    (slots617.zero_x 2839 2845 2840 f r (row_of_literal 2839 _ (by decide) RawRows.raw2839))
    (slots617.pos_x 2839 2845 2840 f r (row_of_literal 2839 _ (by decide) RawRows.raw2839))
    (slots617.inc_z 2840 2841 f r (row_of_literal 2840 _ (by decide) RawRows.raw2840) (Or.inl (by decide)))
    (slots617.zero_x 2841 2844 2842 f r (row_of_literal 2841 _ (by decide) RawRows.raw2841))
    (slots617.pos_x 2841 2844 2842 f r (row_of_literal 2841 _ (by decide) RawRows.raw2841))
    (slots617.inc_y 2842 2843 f r (row_of_literal 2842 _ (by decide) RawRows.raw2842) (Or.inl (by decide)))
    (slots617.jump 2843 2841 f r (row_of_literal 2843 _ (by decide) RawRows.raw2843))
    (slots617.jump 2844 2835 f r (row_of_literal 2844 _ (by decide) RawRows.raw2844))

theorem site2835 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2835:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2845:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2835Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2845Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2845 f r x y z) (slots710.atReg 2849 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2845 4 2849 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2845 2849 2846 f r (row_of_literal 2845 _ (by decide) RawRows.raw2845))
    (slots710.pos_x 2845 2849 2846 f r (row_of_literal 2845 _ (by decide) RawRows.raw2845))
    (slots710.inc_y 2846 2847 f r (row_of_literal 2846 _ (by decide) RawRows.raw2846) (Or.inl (by decide)))
    (slots710.inc_y 2847 2848 f r (row_of_literal 2847 _ (by decide) RawRows.raw2847) (Or.inl (by decide)))
    (slots710.jump 2848 2845 f r (row_of_literal 2848 _ (by decide) RawRows.raw2848))

theorem site2845 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2845:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2849:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2845Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2849 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2849:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((39:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2849 _ (row_of_literal 2849 _ (by decide) RawRows.raw2849)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2850Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2850 f r x y z) (slots160.atReg 2853 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2850 3 2853 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2850 2853 2851 f r (row_of_literal 2850 _ (by decide) RawRows.raw2850))
    (slots160.pos_x 2850 2853 2851 f r (row_of_literal 2850 _ (by decide) RawRows.raw2850))
    (slots160.inc_y 2851 2852 f r (row_of_literal 2851 _ (by decide) RawRows.raw2851) (Or.inl (by decide)))
    (slots160.jump 2852 2850 f r (row_of_literal 2852 _ (by decide) RawRows.raw2852))

theorem site2850 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2850:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2853:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2850Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2853Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2853 f r x y z) (slots210.atReg 2856 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2853 3 2856 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2853 2856 2854 f r (row_of_literal 2853 _ (by decide) RawRows.raw2853))
    (slots210.pos_x 2853 2856 2854 f r (row_of_literal 2853 _ (by decide) RawRows.raw2853))
    (slots210.inc_y 2854 2855 f r (row_of_literal 2854 _ (by decide) RawRows.raw2854) (Or.inl (by decide)))
    (slots210.jump 2855 2853 f r (row_of_literal 2855 _ (by decide) RawRows.raw2855))

theorem site2853 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2853:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2856:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2853Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2856Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2856 f r x y z) (slots617.atReg 2866 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2856 10 2866 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2856 2860 2857 f r (row_of_literal 2856 _ (by decide) RawRows.raw2856))
    (slots617.pos_y 2856 2860 2857 f r (row_of_literal 2856 _ (by decide) RawRows.raw2856))
    (slots617.inc_z 2857 2858 f r (row_of_literal 2857 _ (by decide) RawRows.raw2857) (Or.inl (by decide)))
    (slots617.inc_x 2858 2859 f r (row_of_literal 2858 _ (by decide) RawRows.raw2858) (Or.inl (by decide)))
    (slots617.jump 2859 2856 f r (row_of_literal 2859 _ (by decide) RawRows.raw2859))
    (slots617.zero_x 2860 2866 2861 f r (row_of_literal 2860 _ (by decide) RawRows.raw2860))
    (slots617.pos_x 2860 2866 2861 f r (row_of_literal 2860 _ (by decide) RawRows.raw2860))
    (slots617.inc_z 2861 2862 f r (row_of_literal 2861 _ (by decide) RawRows.raw2861) (Or.inl (by decide)))
    (slots617.zero_x 2862 2865 2863 f r (row_of_literal 2862 _ (by decide) RawRows.raw2862))
    (slots617.pos_x 2862 2865 2863 f r (row_of_literal 2862 _ (by decide) RawRows.raw2862))
    (slots617.inc_y 2863 2864 f r (row_of_literal 2863 _ (by decide) RawRows.raw2863) (Or.inl (by decide)))
    (slots617.jump 2864 2862 f r (row_of_literal 2864 _ (by decide) RawRows.raw2864))
    (slots617.jump 2865 2856 f r (row_of_literal 2865 _ (by decide) RawRows.raw2865))

theorem site2856 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2856:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2866:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2856Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2866Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2866 f r x y z) (slots720.atReg 2869 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2866 3 2869 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2866 2869 2867 f r (row_of_literal 2866 _ (by decide) RawRows.raw2866))
    (slots720.pos_x 2866 2869 2867 f r (row_of_literal 2866 _ (by decide) RawRows.raw2866))
    (slots720.inc_y 2867 2868 f r (row_of_literal 2867 _ (by decide) RawRows.raw2867) (Or.inl (by decide)))
    (slots720.jump 2868 2866 f r (row_of_literal 2868 _ (by decide) RawRows.raw2868))

theorem site2866 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2866:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2869:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2866Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2869Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2869 f r x y z) (slots461.atReg 2873 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2869 4 2873 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2869 2873 2870 f r (row_of_literal 2869 _ (by decide) RawRows.raw2869))
    (slots461.pos_x 2869 2873 2870 f r (row_of_literal 2869 _ (by decide) RawRows.raw2869))
    (slots461.inc_y 2870 2871 f r (row_of_literal 2870 _ (by decide) RawRows.raw2870) (Or.inl (by decide)))
    (slots461.inc_z 2871 2872 f r (row_of_literal 2871 _ (by decide) RawRows.raw2871) (Or.inl (by decide)))
    (slots461.jump 2872 2869 f r (row_of_literal 2872 _ (by decide) RawRows.raw2872))

theorem site2869 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2869:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2873:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2869Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site2873Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2873 f r x y z) (slots640.atReg 2876 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2873 3 2876 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2873 2876 2874 f r (row_of_literal 2873 _ (by decide) RawRows.raw2873))
    (slots640.pos_x 2873 2876 2874 f r (row_of_literal 2873 _ (by decide) RawRows.raw2873))
    (slots640.inc_y 2874 2875 f r (row_of_literal 2874 _ (by decide) RawRows.raw2874) (Or.inl (by decide)))
    (slots640.jump 2875 2873 f r (row_of_literal 2875 _ (by decide) RawRows.raw2875))

theorem site2873 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2873:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2876:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2873Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site2876Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2876 f r x y z) (slots267.atReg 2884 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2876 8 2884 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2876 2884 2877 f r (row_of_literal 2876 _ (by decide) RawRows.raw2876))
    (slots267.pos_x 2876 2884 2877 f r (row_of_literal 2876 _ (by decide) RawRows.raw2876))
    (slots267.inc_z 2877 2878 f r (row_of_literal 2877 _ (by decide) RawRows.raw2877) (Or.inl (by decide)))
    (slots267.zero_y 2878 2880 2879 f r (row_of_literal 2878 _ (by decide) RawRows.raw2878))
    (slots267.pos_y 2878 2880 2879 f r (row_of_literal 2878 _ (by decide) RawRows.raw2878))
    (slots267.jump 2879 2883 f r (row_of_literal 2879 _ (by decide) RawRows.raw2879))
    (slots267.zero_z 2880 2883 2881 f r (row_of_literal 2880 _ (by decide) RawRows.raw2880))
    (slots267.pos_z 2880 2883 2881 f r (row_of_literal 2880 _ (by decide) RawRows.raw2880))
    (slots267.inc_y 2881 2882 f r (row_of_literal 2881 _ (by decide) RawRows.raw2881) (Or.inl (by decide)))
    (slots267.jump 2882 2880 f r (row_of_literal 2882 _ (by decide) RawRows.raw2882))
    (slots267.jump 2883 2876 f r (row_of_literal 2883 _ (by decide) RawRows.raw2883))

theorem site2876 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2876:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2884:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2876Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2884Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2884 f r x y z) (slots720.atReg 2887 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2884 3 2887 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2884 2887 2885 f r (row_of_literal 2884 _ (by decide) RawRows.raw2884))
    (slots720.pos_x 2884 2887 2885 f r (row_of_literal 2884 _ (by decide) RawRows.raw2884))
    (slots720.inc_y 2885 2886 f r (row_of_literal 2885 _ (by decide) RawRows.raw2885) (Or.inl (by decide)))
    (slots720.jump 2886 2884 f r (row_of_literal 2886 _ (by decide) RawRows.raw2886))

theorem site2884 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2884:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2887:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2884Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2887Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2887 f r x y z) (slots617.atReg 2897 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2887 10 2897 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2887 2891 2888 f r (row_of_literal 2887 _ (by decide) RawRows.raw2887))
    (slots617.pos_y 2887 2891 2888 f r (row_of_literal 2887 _ (by decide) RawRows.raw2887))
    (slots617.inc_z 2888 2889 f r (row_of_literal 2888 _ (by decide) RawRows.raw2888) (Or.inl (by decide)))
    (slots617.inc_x 2889 2890 f r (row_of_literal 2889 _ (by decide) RawRows.raw2889) (Or.inl (by decide)))
    (slots617.jump 2890 2887 f r (row_of_literal 2890 _ (by decide) RawRows.raw2890))
    (slots617.zero_x 2891 2897 2892 f r (row_of_literal 2891 _ (by decide) RawRows.raw2891))
    (slots617.pos_x 2891 2897 2892 f r (row_of_literal 2891 _ (by decide) RawRows.raw2891))
    (slots617.inc_z 2892 2893 f r (row_of_literal 2892 _ (by decide) RawRows.raw2892) (Or.inl (by decide)))
    (slots617.zero_x 2893 2896 2894 f r (row_of_literal 2893 _ (by decide) RawRows.raw2893))
    (slots617.pos_x 2893 2896 2894 f r (row_of_literal 2893 _ (by decide) RawRows.raw2893))
    (slots617.inc_y 2894 2895 f r (row_of_literal 2894 _ (by decide) RawRows.raw2894) (Or.inl (by decide)))
    (slots617.jump 2895 2893 f r (row_of_literal 2895 _ (by decide) RawRows.raw2895))
    (slots617.jump 2896 2887 f r (row_of_literal 2896 _ (by decide) RawRows.raw2896))

theorem site2887 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2887:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2897:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2887Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2897Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2897 f r x y z) (slots710.atReg 2901 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2897 4 2901 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2897 2901 2898 f r (row_of_literal 2897 _ (by decide) RawRows.raw2897))
    (slots710.pos_x 2897 2901 2898 f r (row_of_literal 2897 _ (by decide) RawRows.raw2897))
    (slots710.inc_y 2898 2899 f r (row_of_literal 2898 _ (by decide) RawRows.raw2898) (Or.inl (by decide)))
    (slots710.inc_y 2899 2900 f r (row_of_literal 2899 _ (by decide) RawRows.raw2899) (Or.inl (by decide)))
    (slots710.jump 2900 2897 f r (row_of_literal 2900 _ (by decide) RawRows.raw2900))

theorem site2897 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2897:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2901:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2897Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site2901Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2901 f r x y z) (slots160.atReg 2904 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2901 3 2904 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2901 2904 2902 f r (row_of_literal 2901 _ (by decide) RawRows.raw2901))
    (slots160.pos_x 2901 2904 2902 f r (row_of_literal 2901 _ (by decide) RawRows.raw2901))
    (slots160.inc_y 2902 2903 f r (row_of_literal 2902 _ (by decide) RawRows.raw2902) (Or.inl (by decide)))
    (slots160.jump 2903 2901 f r (row_of_literal 2903 _ (by decide) RawRows.raw2903))

theorem site2901 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2901:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2904:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2901Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2904Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2904 f r x y z) (slots650.atReg 2911 f r 0 ((x-y)+(y-x)) z) :=
  @Templates.differenceBlock V _ _ (fun j=>slots650.atReg (destination 2904 7 2911 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2904 2911 2905 f r (row_of_literal 2904 _ (by decide) RawRows.raw2904))
    (slots650.pos_x 2904 2911 2905 f r (row_of_literal 2904 _ (by decide) RawRows.raw2904))
    (slots650.zero_y 2905 2907 2906 f r (row_of_literal 2905 _ (by decide) RawRows.raw2905))
    (slots650.pos_y 2905 2907 2906 f r (row_of_literal 2905 _ (by decide) RawRows.raw2905))
    (slots650.jump 2906 2904 f r (row_of_literal 2906 _ (by decide) RawRows.raw2906))
    (slots650.inc_y 2907 2908 f r (row_of_literal 2907 _ (by decide) RawRows.raw2907) (Or.inl (by decide)))
    (slots650.zero_x 2908 2911 2909 f r (row_of_literal 2908 _ (by decide) RawRows.raw2908))
    (slots650.pos_x 2908 2911 2909 f r (row_of_literal 2908 _ (by decide) RawRows.raw2908))
    (slots650.inc_y 2909 2910 f r (row_of_literal 2909 _ (by decide) RawRows.raw2909) (Or.inl (by decide)))
    (slots650.jump 2910 2908 f r (row_of_literal 2910 _ (by decide) RawRows.raw2910))

theorem site2904 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2904:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2911:Nat):V) f (vector r0 r1 r2 r3 r4 ((r6-r5)+(r5-r6)) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2904Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


theorem site2911Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2911:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8)) (config ((2913:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2911 _ (row_of_literal 2911 _ (by decide) RawRows.raw2911)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]

theorem site2911Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2911:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+1) r6 r7 r8)) (config ((2912:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2911 _ (row_of_literal 2911 _ (by decide) RawRows.raw2911)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site2912 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2912:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2920:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2912 _ (row_of_literal 2912 _ (by decide) RawRows.raw2912)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2913Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2913 f r x y z) (slots461.atReg 2917 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2913 4 2917 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2913 2917 2914 f r (row_of_literal 2913 _ (by decide) RawRows.raw2913))
    (slots461.pos_x 2913 2917 2914 f r (row_of_literal 2913 _ (by decide) RawRows.raw2913))
    (slots461.inc_y 2914 2915 f r (row_of_literal 2914 _ (by decide) RawRows.raw2914) (Or.inl (by decide)))
    (slots461.inc_z 2915 2916 f r (row_of_literal 2915 _ (by decide) RawRows.raw2915) (Or.inl (by decide)))
    (slots461.jump 2916 2913 f r (row_of_literal 2916 _ (by decide) RawRows.raw2916))

theorem site2913 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2913:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2917:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2913Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site2917Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2917 f r x y z) (slots640.atReg 2920 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2917 3 2920 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2917 2920 2918 f r (row_of_literal 2917 _ (by decide) RawRows.raw2917))
    (slots640.pos_x 2917 2920 2918 f r (row_of_literal 2917 _ (by decide) RawRows.raw2917))
    (slots640.inc_y 2918 2919 f r (row_of_literal 2918 _ (by decide) RawRows.raw2918) (Or.inl (by decide)))
    (slots640.jump 2919 2917 f r (row_of_literal 2919 _ (by decide) RawRows.raw2919))

theorem site2917 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2917:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2920:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2917Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site2920Frame (f r : V) : ∀ x y z : V, Reach (slots401.atReg 2920 f r x y z) (slots401.atReg 2922 f r 0 y z) :=
  @Templates.clearBlock V _ _ (fun j=>slots401.atReg (destination 2920 2 2922 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots401.zero_x 2920 2922 2921 f r (row_of_literal 2920 _ (by decide) RawRows.raw2920))
    (slots401.pos_x 2920 2922 2921 f r (row_of_literal 2920 _ (by decide) RawRows.raw2920))
    (slots401.jump 2921 2920 f r (row_of_literal 2921 _ (by decide) RawRows.raw2921))

theorem site2920 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2920:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2922:Nat):V) f (vector r0 r1 r2 r3 0 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots401,vector,writeReg,pi₁_pair,pi₂_pair] using site2920Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r0 r1


private theorem site2922Frame (f r : V) : ∀ x y z : V, Reach (slots501.atReg 2922 f r x y z) (slots501.atReg 2924 f r 0 y z) :=
  @Templates.clearBlock V _ _ (fun j=>slots501.atReg (destination 2922 2 2924 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots501.zero_x 2922 2924 2923 f r (row_of_literal 2922 _ (by decide) RawRows.raw2922))
    (slots501.pos_x 2922 2924 2923 f r (row_of_literal 2922 _ (by decide) RawRows.raw2922))
    (slots501.jump 2923 2922 f r (row_of_literal 2923 _ (by decide) RawRows.raw2923))

theorem site2922 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2922:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2924:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots501,vector,writeReg,pi₁_pair,pi₂_pair] using site2922Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r0 r1


theorem site2924Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2924:Nat):V) f (vector r0 r1 r2 r3 0 r5 r6 r7 r8)) (config ((2951:Nat):V) f (vector r0 r1 r2 r3 0 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2924 _ (row_of_literal 2924 _ (by decide) RawRows.raw2924)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]

theorem site2924Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2924:Nat):V) f (vector r0 r1 r2 r3 (r4+1) r5 r6 r7 r8)) (config ((2925:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2924 _ (row_of_literal 2924 _ (by decide) RawRows.raw2924)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2925Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2925 f r x y z) (slots160.atReg 2928 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2925 3 2928 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2925 2928 2926 f r (row_of_literal 2925 _ (by decide) RawRows.raw2925))
    (slots160.pos_x 2925 2928 2926 f r (row_of_literal 2925 _ (by decide) RawRows.raw2925))
    (slots160.inc_y 2926 2927 f r (row_of_literal 2926 _ (by decide) RawRows.raw2926) (Or.inl (by decide)))
    (slots160.jump 2927 2925 f r (row_of_literal 2927 _ (by decide) RawRows.raw2927))

theorem site2925 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2925:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2928:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2925Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2928Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2928 f r x y z) (slots210.atReg 2931 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2928 3 2931 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2928 2931 2929 f r (row_of_literal 2928 _ (by decide) RawRows.raw2928))
    (slots210.pos_x 2928 2931 2929 f r (row_of_literal 2928 _ (by decide) RawRows.raw2928))
    (slots210.inc_y 2929 2930 f r (row_of_literal 2929 _ (by decide) RawRows.raw2929) (Or.inl (by decide)))
    (slots210.jump 2930 2928 f r (row_of_literal 2930 _ (by decide) RawRows.raw2930))

theorem site2928 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2928:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2931:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2928Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2931Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2931 f r x y z) (slots617.atReg 2941 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2931 10 2941 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2931 2935 2932 f r (row_of_literal 2931 _ (by decide) RawRows.raw2931))
    (slots617.pos_y 2931 2935 2932 f r (row_of_literal 2931 _ (by decide) RawRows.raw2931))
    (slots617.inc_z 2932 2933 f r (row_of_literal 2932 _ (by decide) RawRows.raw2932) (Or.inl (by decide)))
    (slots617.inc_x 2933 2934 f r (row_of_literal 2933 _ (by decide) RawRows.raw2933) (Or.inl (by decide)))
    (slots617.jump 2934 2931 f r (row_of_literal 2934 _ (by decide) RawRows.raw2934))
    (slots617.zero_x 2935 2941 2936 f r (row_of_literal 2935 _ (by decide) RawRows.raw2935))
    (slots617.pos_x 2935 2941 2936 f r (row_of_literal 2935 _ (by decide) RawRows.raw2935))
    (slots617.inc_z 2936 2937 f r (row_of_literal 2936 _ (by decide) RawRows.raw2936) (Or.inl (by decide)))
    (slots617.zero_x 2937 2940 2938 f r (row_of_literal 2937 _ (by decide) RawRows.raw2937))
    (slots617.pos_x 2937 2940 2938 f r (row_of_literal 2937 _ (by decide) RawRows.raw2937))
    (slots617.inc_y 2938 2939 f r (row_of_literal 2938 _ (by decide) RawRows.raw2938) (Or.inl (by decide)))
    (slots617.jump 2939 2937 f r (row_of_literal 2939 _ (by decide) RawRows.raw2939))
    (slots617.jump 2940 2931 f r (row_of_literal 2940 _ (by decide) RawRows.raw2940))

theorem site2931 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2931:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2941:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2931Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2941Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2941 f r x y z) (slots720.atReg 2944 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2941 3 2944 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2941 2944 2942 f r (row_of_literal 2941 _ (by decide) RawRows.raw2941))
    (slots720.pos_x 2941 2944 2942 f r (row_of_literal 2941 _ (by decide) RawRows.raw2941))
    (slots720.inc_y 2942 2943 f r (row_of_literal 2942 _ (by decide) RawRows.raw2942) (Or.inl (by decide)))
    (slots720.jump 2943 2941 f r (row_of_literal 2943 _ (by decide) RawRows.raw2943))

theorem site2941 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2941:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2944:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2941Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2944Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2944 f r x y z) (slots561.atReg 2948 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2944 4 2948 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2944 2948 2945 f r (row_of_literal 2944 _ (by decide) RawRows.raw2944))
    (slots561.pos_x 2944 2948 2945 f r (row_of_literal 2944 _ (by decide) RawRows.raw2944))
    (slots561.inc_y 2945 2946 f r (row_of_literal 2945 _ (by decide) RawRows.raw2945) (Or.inl (by decide)))
    (slots561.inc_z 2946 2947 f r (row_of_literal 2946 _ (by decide) RawRows.raw2946) (Or.inl (by decide)))
    (slots561.jump 2947 2944 f r (row_of_literal 2947 _ (by decide) RawRows.raw2947))

theorem site2944 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2944:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2948:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2944Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2948Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2948 f r x y z) (slots650.atReg 2951 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2948 3 2951 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2948 2951 2949 f r (row_of_literal 2948 _ (by decide) RawRows.raw2948))
    (slots650.pos_x 2948 2951 2949 f r (row_of_literal 2948 _ (by decide) RawRows.raw2948))
    (slots650.inc_y 2949 2950 f r (row_of_literal 2949 _ (by decide) RawRows.raw2949) (Or.inl (by decide)))
    (slots650.jump 2950 2948 f r (row_of_literal 2950 _ (by decide) RawRows.raw2950))

theorem site2948 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2948:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2951:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2948Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2951Frame (f r : V) : ∀ x y z : V, Reach (slots501.atReg 2951 f r x y z) (if x=3 then slots501.atReg 4095 f r 0 y z else slots501.atReg 2957 f r 0 y z) :=
  @Templates.goalBlock V _ _ (fun j=>slots501.atReg (destination 2951 6 2957 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots501.zero_x 2951 2955 2952 f r (row_of_literal 2951 _ (by decide) RawRows.raw2951))
    (slots501.pos_x 2951 2955 2952 f r (row_of_literal 2951 _ (by decide) RawRows.raw2951))
    (slots501.zero_x 2952 2955 2953 f r (row_of_literal 2952 _ (by decide) RawRows.raw2952))
    (slots501.pos_x 2952 2955 2953 f r (row_of_literal 2952 _ (by decide) RawRows.raw2952))
    (slots501.zero_x 2953 2955 2954 f r (row_of_literal 2953 _ (by decide) RawRows.raw2953))
    (slots501.pos_x 2953 2955 2954 f r (row_of_literal 2953 _ (by decide) RawRows.raw2953))
    (slots501.zero_x 2954 4095 2955 f r (row_of_literal 2954 _ (by decide) RawRows.raw2954))
    (slots501.pos_x 2954 4095 2955 f r (row_of_literal 2954 _ (by decide) RawRows.raw2954))
    (slots501.zero_x 2955 2957 2956 f r (row_of_literal 2955 _ (by decide) RawRows.raw2955))
    (slots501.pos_x 2955 2957 2956 f r (row_of_literal 2955 _ (by decide) RawRows.raw2955))
    (slots501.jump 2956 2955 f r (row_of_literal 2956 _ (by decide) RawRows.raw2956))

theorem site2951 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2951:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (if r5=3 then config ((4095:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8) else config ((2957:Nat):V) f (vector r0 r1 r2 r3 r4 0 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots501,vector,writeReg,pi₁_pair,pi₂_pair] using site2951Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r0 r1


private theorem site2957Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2957 f r x y z) (slots267.atReg 2965 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2957 8 2965 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2957 2965 2958 f r (row_of_literal 2957 _ (by decide) RawRows.raw2957))
    (slots267.pos_x 2957 2965 2958 f r (row_of_literal 2957 _ (by decide) RawRows.raw2957))
    (slots267.inc_z 2958 2959 f r (row_of_literal 2958 _ (by decide) RawRows.raw2958) (Or.inl (by decide)))
    (slots267.zero_y 2959 2961 2960 f r (row_of_literal 2959 _ (by decide) RawRows.raw2959))
    (slots267.pos_y 2959 2961 2960 f r (row_of_literal 2959 _ (by decide) RawRows.raw2959))
    (slots267.jump 2960 2964 f r (row_of_literal 2960 _ (by decide) RawRows.raw2960))
    (slots267.zero_z 2961 2964 2962 f r (row_of_literal 2961 _ (by decide) RawRows.raw2961))
    (slots267.pos_z 2961 2964 2962 f r (row_of_literal 2961 _ (by decide) RawRows.raw2961))
    (slots267.inc_y 2962 2963 f r (row_of_literal 2962 _ (by decide) RawRows.raw2962) (Or.inl (by decide)))
    (slots267.jump 2963 2961 f r (row_of_literal 2963 _ (by decide) RawRows.raw2963))
    (slots267.jump 2964 2957 f r (row_of_literal 2964 _ (by decide) RawRows.raw2964))

theorem site2957 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2957:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2965:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2957Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2965Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2965 f r x y z) (slots720.atReg 2968 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2965 3 2968 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2965 2968 2966 f r (row_of_literal 2965 _ (by decide) RawRows.raw2965))
    (slots720.pos_x 2965 2968 2966 f r (row_of_literal 2965 _ (by decide) RawRows.raw2965))
    (slots720.inc_y 2966 2967 f r (row_of_literal 2966 _ (by decide) RawRows.raw2966) (Or.inl (by decide)))
    (slots720.jump 2967 2965 f r (row_of_literal 2967 _ (by decide) RawRows.raw2967))

theorem site2965 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2965:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2968:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2965Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2968Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2968 f r x y z) (slots650.atReg 0 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2968 3 0 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2968 0 2969 f r (row_of_literal 2968 _ (by decide) RawRows.raw2968))
    (slots650.pos_x 2968 0 2969 f r (row_of_literal 2968 _ (by decide) RawRows.raw2968))
    (slots650.inc_y 2969 2970 f r (row_of_literal 2969 _ (by decide) RawRows.raw2969) (Or.inl (by decide)))
    (slots650.jump 2970 2968 f r (row_of_literal 2970 _ (by decide) RawRows.raw2970))

theorem site2968 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2968:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((0:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2968Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0

end PA192.ModelSearch.Register181.Certified
