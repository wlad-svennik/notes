module
public import Src181Atoms
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandTakeAfter1 (f n t s c u v y d w : V) : Reach (config ((2913:Nat):V) f (vector n 0 s c u 0 0 0 w)) (config ((2917:Nat):V) f (vector n u s c 0 0 u 0 w)) := by
  have micro := site2913 f n 0 s c u 0 0 0 w
  have d1 : (0+u:V)=u := by ring
  have d6 : (0+u:V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact mid

theorem commandTake (f n t s c u v y d w : V) : Reach (config ((2913:Nat):V) f (vector n 0 s c u 0 0 0 w)) (config ((2920:Nat):V) f (vector n u s c u 0 0 0 w)) := by
  have micro := site2917 f n u s c 0 0 u 0 w
  have d4 : (0+u:V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandTakeAfter1 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
