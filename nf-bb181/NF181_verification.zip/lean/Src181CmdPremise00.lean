module
public import Src181Atoms
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandPremiseAfter1 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2853:Nat):V) f (vector n 0 s c u v t 0 w)) := by
  have micro := site2850 f n t s c u v 0 0 w
  have d6 : (0+t:V)=t := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact mid

theorem commandPremiseAfter2 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2856:Nat):V) f (vector n s 0 c u v t 0 w)) := by
  have micro := site2853 f n 0 s c u v t 0 w
  have d1 : (0+s:V)=s := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandPremiseAfter1 f n t s c u v y d w).trans mid

theorem commandPremiseAfter3 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2866:Nat):V) f (vector n 0 0 c u v 0 (atom2 n t s c u v y d w) w)) := by
  have micro := site2856 f n s 0 c u v t 0 w
  have d7 : (0+(cantor t s):V)=atom2 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor t s):V)=0+(atom2 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandPremiseAfter2 f n t s c u v y d w).trans mid

theorem commandPremiseAfter4 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2869:Nat):V) f (vector n 0 (atom2 n t s c u v y d w) c u v 0 0 w)) := by
  have micro := site2866 f n 0 0 c u v 0 (atom2 n t s c u v y d w) w
  have d2 : (0+(atom2 n t s c u v y d w):V)=atom2 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandPremiseAfter3 f n t s c u v y d w).trans mid

theorem commandPremiseAfter5 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2873:Nat):V) f (vector n u (atom2 n t s c u v y d w) c 0 v u 0 w)) := by
  have micro := site2869 f n 0 (atom2 n t s c u v y d w) c u v 0 0 w
  have d1 : (0+u:V)=u := by ring
  have d6 : (0+u:V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandPremiseAfter4 f n t s c u v y d w).trans mid

theorem commandPremiseAfter6 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2876:Nat):V) f (vector n u (atom2 n t s c u v y d w) c u v 0 0 w)) := by
  have micro := site2873 f n u (atom2 n t s c u v y d w) c 0 v u 0 w
  have d4 : (0+u:V)=u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandPremiseAfter5 f n t s c u v y d w).trans mid

theorem commandPremiseAfter7 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2884:Nat):V) f (vector n u 0 c u v t s w)) := by
  have micro := site2876 f n u (atom2 n t s c u v y d w) c u v 0 0 w
  have d6 : (left ((cantor 0 0)+(atom2 n t s c u v y d w)):V)=t := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom2 n t s c u v y d w):V)=0+(atom2 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom2 n t s c u v y d w)):V)=left (atom2 n t s c u v y d w)).trans (by change left (cantor t s) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom2 n t s c u v y d w)):V)=s := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom2 n t s c u v y d w):V)=0+(atom2 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom2 n t s c u v y d w)):V)=right (atom2 n t s c u v y d w)).trans (by change right (cantor t s) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandPremiseAfter6 f n t s c u v y d w).trans mid

theorem commandPremiseAfter8 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2887:Nat):V) f (vector n u s c u v t 0 w)) := by
  have micro := site2884 f n u 0 c u v t s w
  have d2 : (0+s:V)=s := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandPremiseAfter7 f n t s c u v y d w).trans mid

theorem commandPremiseAfter9 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2897:Nat):V) f (vector n 0 s c u v 0 (atom94 n t s c u v y d w) w)) := by
  have micro := site2887 f n u s c u v t 0 w
  have d7 : (0+(cantor t u):V)=atom94 n t s c u v y d w := (congrArg₂ (·+·) (rfl) (rfl) : (0+(cantor t u):V)=0+(atom94 n t s c u v y d w)).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandPremiseAfter8 f n t s c u v y d w).trans mid

theorem commandPremiseAfter10 (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2901:Nat):V) f (vector n ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)) s c u v 0 0 w)) := by
  have micro := site2897 f n 0 s c u v 0 (atom94 n t s c u v y d w) w
  have d1 : (0+(2*(atom94 n t s c u v y d w)):V)=(atom94 n t s c u v y d w)+(atom94 n t s c u v y d w) := (congrArg₂ (·+·) (rfl) (by ring) : (0+(2*(atom94 n t s c u v y d w)):V)=0+((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandPremiseAfter9 f n t s c u v y d w).trans mid

theorem commandPremise (f n t s c u v y d w : V) : Reach (config ((2850:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2904:Nat):V) f (vector n 0 s c u v ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)) 0 w)) := by
  have micro := site2901 f n ((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)) s c u v 0 0 w
  have d6 : (0+((atom94 n t s c u v y d w)+(atom94 n t s c u v y d w)):V)=(atom94 n t s c u v y d w)+(atom94 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandPremiseAfter10 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
