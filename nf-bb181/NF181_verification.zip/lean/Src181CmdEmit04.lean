module
public import Src181CmdEmit03
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter129 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((661:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0660 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter128 f n t s c u v y d w).trans mid

theorem commandEmitAfter130 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((664:Nat):V) f (vector n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0661 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1)):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter129 f n t s c u v y d w).trans mid

theorem commandEmitAfter131 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((667:Nat):V) f (vector n (emitAtom22 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0664 f n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom22 n t s c u v y d w)):V)=(emitAtom22 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter130 f n t s c u v y d w).trans mid

theorem commandEmitAfter132 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((677:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom25 n t s c u v y d w) w)) := by
  have micro := site0667 f n (emitAtom22 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom22 n t s c u v y d w))):V)=(emitAtom25 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom22 n t s c u v y d w))):V)=(0+(emitAtom25 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter131 f n t s c u v y d w).trans mid

theorem commandEmitAfter133 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((680:Nat):V) f (vector n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0677 f n 0 0 c (d+u) (v+y) 0 (emitAtom25 n t s c u v y d w) w
  have d2 : ((0+(emitAtom25 n t s c u v y d w)):V)=(emitAtom25 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter132 f n t s c u v y d w).trans mid

theorem commandEmitAfter134 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((684:Nat):V) f (vector n (d+u) (emitAtom25 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0680 f n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter133 f n t s c u v y d w).trans mid

theorem commandEmitAfter135 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((687:Nat):V) f (vector n (d+u) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0684 f n (d+u) (emitAtom25 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter134 f n t s c u v y d w).trans mid

theorem commandEmitAfter136 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((690:Nat):V) f (vector n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0687 f n (d+u) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter135 f n t s c u v y d w).trans mid

theorem commandEmitAfter137 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((693:Nat):V) f (vector n (emitAtom25 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0690 f n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom25 n t s c u v y d w)):V)=(emitAtom25 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter136 f n t s c u v y d w).trans mid

theorem commandEmitAfter138 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((703:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom26 n t s c u v y d w) w)) := by
  have micro := site0693 f n (emitAtom25 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom25 n t s c u v y d w))):V)=(emitAtom26 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom25 n t s c u v y d w))):V)=(0+(emitAtom26 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter137 f n t s c u v y d w).trans mid

theorem commandEmitAfter139 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((706:Nat):V) f (vector n 0 (emitAtom26 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0703 f n 0 0 c (d+u) (v+y) 0 (emitAtom26 n t s c u v y d w) w
  have d2 : ((0+(emitAtom26 n t s c u v y d w)):V)=(emitAtom26 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter138 f n t s c u v y d w).trans mid

theorem commandEmitAfter140 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((710:Nat):V) f (vector n c (emitAtom26 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site0706 f n 0 (emitAtom26 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter139 f n t s c u v y d w).trans mid

theorem commandEmitAfter141 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((713:Nat):V) f (vector n c (emitAtom26 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0710 f n c (emitAtom26 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter140 f n t s c u v y d w).trans mid

theorem commandEmitAfter142 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((721:Nat):V) f (vector n c 0 c (d+u) (v+y) (d+u) (emitAtom25 n t s c u v y d w) w)) := by
  have micro := site0713 f n c (emitAtom26 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom26 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom26 n t s c u v y d w)):V)=(0+(emitAtom26 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom26 n t s c u v y d w))):V)=left (emitAtom26 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom25 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom26 n t s c u v y d w))):V)=(emitAtom25 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom26 n t s c u v y d w)):V)=(0+(emitAtom26 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom26 n t s c u v y d w))):V)=right (emitAtom26 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom25 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter141 f n t s c u v y d w).trans mid

theorem commandEmitAfter143 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((724:Nat):V) f (vector n c (emitAtom25 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0721 f n c 0 c (d+u) (v+y) (d+u) (emitAtom25 n t s c u v y d w) w
  have d2 : ((0+(emitAtom25 n t s c u v y d w)):V)=(emitAtom25 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter142 f n t s c u v y d w).trans mid

theorem commandEmitAfter144 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((734:Nat):V) f (vector n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom9 n t s c u v y d w) w)) := by
  have micro := site0724 f n c (emitAtom25 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) c)):V)=(emitAtom9 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) c)):V)=(0+(emitAtom9 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter143 f n t s c u v y d w).trans mid

theorem commandEmitAfter145 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((738:Nat):V) f (vector n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0734 f n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom9 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom9 n t s c u v y d w))):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom9 n t s c u v y d w))):V)=(0+((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter144 f n t s c u v y d w).trans mid

theorem commandEmitAfter146 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((739:Nat):V) f (vector n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0738 f n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w))+1):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter145 f n t s c u v y d w).trans mid

theorem commandEmitAfter147 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((742:Nat):V) f (vector n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0739 f n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1)):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter146 f n t s c u v y d w).trans mid

theorem commandEmitAfter148 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((745:Nat):V) f (vector n (emitAtom25 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0742 f n 0 (emitAtom25 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom25 n t s c u v y d w)):V)=(emitAtom25 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter147 f n t s c u v y d w).trans mid

theorem commandEmitAfter149 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((755:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom27 n t s c u v y d w) w)) := by
  have micro := site0745 f n (emitAtom25 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w))):V)=(emitAtom27 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w))):V)=(0+(emitAtom27 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter148 f n t s c u v y d w).trans mid

theorem commandEmitAfter150 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((758:Nat):V) f (vector n 0 (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0755 f n 0 0 c (d+u) (v+y) 0 (emitAtom27 n t s c u v y d w) w
  have d2 : ((0+(emitAtom27 n t s c u v y d w)):V)=(emitAtom27 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter149 f n t s c u v y d w).trans mid

theorem commandEmitAfter151 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((762:Nat):V) f (vector n c (emitAtom27 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site0758 f n 0 (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter150 f n t s c u v y d w).trans mid

theorem commandEmitAfter152 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((765:Nat):V) f (vector n c (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0762 f n c (emitAtom27 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter151 f n t s c u v y d w).trans mid

theorem commandEmitAfter153 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((768:Nat):V) f (vector n 0 (emitAtom27 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site0765 f n c (emitAtom27 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter152 f n t s c u v y d w).trans mid

theorem commandEmitAfter154 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((771:Nat):V) f (vector n (emitAtom27 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w)) := by
  have micro := site0768 f n 0 (emitAtom27 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d1 : ((0+(emitAtom27 n t s c u v y d w)):V)=(emitAtom27 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter153 f n t s c u v y d w).trans mid

theorem commandEmitAfter155 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((781:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom28 n t s c u v y d w) w)) := by
  have micro := site0771 f n (emitAtom27 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w
  have d7 : ((0+(cantor c (emitAtom27 n t s c u v y d w))):V)=(emitAtom28 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c (emitAtom27 n t s c u v y d w))):V)=(0+(emitAtom28 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter154 f n t s c u v y d w).trans mid

theorem commandEmitAfter156 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((784:Nat):V) f (vector n 0 (emitAtom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0781 f n 0 0 c (d+u) (v+y) 0 (emitAtom28 n t s c u v y d w) w
  have d2 : ((0+(emitAtom28 n t s c u v y d w)):V)=(emitAtom28 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter155 f n t s c u v y d w).trans mid

theorem commandEmitAfter157 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((788:Nat):V) f (vector n (v+y) (emitAtom28 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0784 f n 0 (emitAtom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter156 f n t s c u v y d w).trans mid

theorem commandEmitAfter158 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((791:Nat):V) f (vector n (v+y) (emitAtom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0788 f n (v+y) (emitAtom28 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter157 f n t s c u v y d w).trans mid

theorem commandEmitAfter159 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((799:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) c (emitAtom27 n t s c u v y d w) w)) := by
  have micro := site0791 f n (v+y) (emitAtom28 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom28 n t s c u v y d w))):V)=c := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom28 n t s c u v y d w)):V)=(0+(emitAtom28 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom28 n t s c u v y d w))):V)=left (emitAtom28 n t s c u v y d w))).trans (by change left (cantor c (emitAtom27 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom28 n t s c u v y d w))):V)=(emitAtom27 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom28 n t s c u v y d w)):V)=(0+(emitAtom28 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom28 n t s c u v y d w))):V)=right (emitAtom28 n t s c u v y d w))).trans (by change right (cantor c (emitAtom27 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter158 f n t s c u v y d w).trans mid

theorem commandEmitAfter160 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((802:Nat):V) f (vector n (v+y) (emitAtom27 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site0799 f n (v+y) 0 c (d+u) (v+y) c (emitAtom27 n t s c u v y d w) w
  have d2 : ((0+(emitAtom27 n t s c u v y d w)):V)=(emitAtom27 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter159 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
