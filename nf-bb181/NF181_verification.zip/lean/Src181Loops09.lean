module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site2232Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2232 f r x y z) (slots617.atReg 2242 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2232 10 2242 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2232 2236 2233 f r (row_of_literal 2232 _ (by decide) RawRows.raw2232))
    (slots617.pos_y 2232 2236 2233 f r (row_of_literal 2232 _ (by decide) RawRows.raw2232))
    (slots617.inc_z 2233 2234 f r (row_of_literal 2233 _ (by decide) RawRows.raw2233) (Or.inl (by decide)))
    (slots617.inc_x 2234 2235 f r (row_of_literal 2234 _ (by decide) RawRows.raw2234) (Or.inl (by decide)))
    (slots617.jump 2235 2232 f r (row_of_literal 2235 _ (by decide) RawRows.raw2235))
    (slots617.zero_x 2236 2242 2237 f r (row_of_literal 2236 _ (by decide) RawRows.raw2236))
    (slots617.pos_x 2236 2242 2237 f r (row_of_literal 2236 _ (by decide) RawRows.raw2236))
    (slots617.inc_z 2237 2238 f r (row_of_literal 2237 _ (by decide) RawRows.raw2237) (Or.inl (by decide)))
    (slots617.zero_x 2238 2241 2239 f r (row_of_literal 2238 _ (by decide) RawRows.raw2238))
    (slots617.pos_x 2238 2241 2239 f r (row_of_literal 2238 _ (by decide) RawRows.raw2238))
    (slots617.inc_y 2239 2240 f r (row_of_literal 2239 _ (by decide) RawRows.raw2239) (Or.inl (by decide)))
    (slots617.jump 2240 2238 f r (row_of_literal 2240 _ (by decide) RawRows.raw2240))
    (slots617.jump 2241 2232 f r (row_of_literal 2241 _ (by decide) RawRows.raw2241))

theorem site2232 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2232:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2242:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2232Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2242Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2242 f r x y z) (slots720.atReg 2245 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2242 3 2245 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2242 2245 2243 f r (row_of_literal 2242 _ (by decide) RawRows.raw2242))
    (slots720.pos_x 2242 2245 2243 f r (row_of_literal 2242 _ (by decide) RawRows.raw2242))
    (slots720.inc_y 2243 2244 f r (row_of_literal 2243 _ (by decide) RawRows.raw2243) (Or.inl (by decide)))
    (slots720.jump 2244 2242 f r (row_of_literal 2244 _ (by decide) RawRows.raw2244))

theorem site2242 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2242:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2245:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2242Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2245Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2245 f r x y z) (slots561.atReg 2249 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2245 4 2249 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2245 2249 2246 f r (row_of_literal 2245 _ (by decide) RawRows.raw2245))
    (slots561.pos_x 2245 2249 2246 f r (row_of_literal 2245 _ (by decide) RawRows.raw2245))
    (slots561.inc_y 2246 2247 f r (row_of_literal 2246 _ (by decide) RawRows.raw2246) (Or.inl (by decide)))
    (slots561.inc_z 2247 2248 f r (row_of_literal 2247 _ (by decide) RawRows.raw2247) (Or.inl (by decide)))
    (slots561.jump 2248 2245 f r (row_of_literal 2248 _ (by decide) RawRows.raw2248))

theorem site2245 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2245:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2249:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2245Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2249Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2249 f r x y z) (slots650.atReg 2252 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2249 3 2252 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2249 2252 2250 f r (row_of_literal 2249 _ (by decide) RawRows.raw2249))
    (slots650.pos_x 2249 2252 2250 f r (row_of_literal 2249 _ (by decide) RawRows.raw2249))
    (slots650.inc_y 2250 2251 f r (row_of_literal 2250 _ (by decide) RawRows.raw2250) (Or.inl (by decide)))
    (slots650.jump 2251 2249 f r (row_of_literal 2251 _ (by decide) RawRows.raw2251))

theorem site2249 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2249:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2252:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2249Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2252Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2252 f r x y z) (slots267.atReg 2260 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2252 8 2260 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2252 2260 2253 f r (row_of_literal 2252 _ (by decide) RawRows.raw2252))
    (slots267.pos_x 2252 2260 2253 f r (row_of_literal 2252 _ (by decide) RawRows.raw2252))
    (slots267.inc_z 2253 2254 f r (row_of_literal 2253 _ (by decide) RawRows.raw2253) (Or.inl (by decide)))
    (slots267.zero_y 2254 2256 2255 f r (row_of_literal 2254 _ (by decide) RawRows.raw2254))
    (slots267.pos_y 2254 2256 2255 f r (row_of_literal 2254 _ (by decide) RawRows.raw2254))
    (slots267.jump 2255 2259 f r (row_of_literal 2255 _ (by decide) RawRows.raw2255))
    (slots267.zero_z 2256 2259 2257 f r (row_of_literal 2256 _ (by decide) RawRows.raw2256))
    (slots267.pos_z 2256 2259 2257 f r (row_of_literal 2256 _ (by decide) RawRows.raw2256))
    (slots267.inc_y 2257 2258 f r (row_of_literal 2257 _ (by decide) RawRows.raw2257) (Or.inl (by decide)))
    (slots267.jump 2258 2256 f r (row_of_literal 2258 _ (by decide) RawRows.raw2258))
    (slots267.jump 2259 2252 f r (row_of_literal 2259 _ (by decide) RawRows.raw2259))

theorem site2252 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2252:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2260:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2252Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2260Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2260 f r x y z) (slots720.atReg 2263 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2260 3 2263 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2260 2263 2261 f r (row_of_literal 2260 _ (by decide) RawRows.raw2260))
    (slots720.pos_x 2260 2263 2261 f r (row_of_literal 2260 _ (by decide) RawRows.raw2260))
    (slots720.inc_y 2261 2262 f r (row_of_literal 2261 _ (by decide) RawRows.raw2261) (Or.inl (by decide)))
    (slots720.jump 2262 2260 f r (row_of_literal 2262 _ (by decide) RawRows.raw2262))

theorem site2260 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2260:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2263:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2260Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2263Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2263 f r x y z) (slots617.atReg 2273 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2263 10 2273 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2263 2267 2264 f r (row_of_literal 2263 _ (by decide) RawRows.raw2263))
    (slots617.pos_y 2263 2267 2264 f r (row_of_literal 2263 _ (by decide) RawRows.raw2263))
    (slots617.inc_z 2264 2265 f r (row_of_literal 2264 _ (by decide) RawRows.raw2264) (Or.inl (by decide)))
    (slots617.inc_x 2265 2266 f r (row_of_literal 2265 _ (by decide) RawRows.raw2265) (Or.inl (by decide)))
    (slots617.jump 2266 2263 f r (row_of_literal 2266 _ (by decide) RawRows.raw2266))
    (slots617.zero_x 2267 2273 2268 f r (row_of_literal 2267 _ (by decide) RawRows.raw2267))
    (slots617.pos_x 2267 2273 2268 f r (row_of_literal 2267 _ (by decide) RawRows.raw2267))
    (slots617.inc_z 2268 2269 f r (row_of_literal 2268 _ (by decide) RawRows.raw2268) (Or.inl (by decide)))
    (slots617.zero_x 2269 2272 2270 f r (row_of_literal 2269 _ (by decide) RawRows.raw2269))
    (slots617.pos_x 2269 2272 2270 f r (row_of_literal 2269 _ (by decide) RawRows.raw2269))
    (slots617.inc_y 2270 2271 f r (row_of_literal 2270 _ (by decide) RawRows.raw2270) (Or.inl (by decide)))
    (slots617.jump 2271 2269 f r (row_of_literal 2271 _ (by decide) RawRows.raw2271))
    (slots617.jump 2272 2263 f r (row_of_literal 2272 _ (by decide) RawRows.raw2272))

theorem site2263 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2263:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2273:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2263Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2273Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2273 f r x y z) (slots710.atReg 2277 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2273 4 2277 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2273 2277 2274 f r (row_of_literal 2273 _ (by decide) RawRows.raw2273))
    (slots710.pos_x 2273 2277 2274 f r (row_of_literal 2273 _ (by decide) RawRows.raw2273))
    (slots710.inc_y 2274 2275 f r (row_of_literal 2274 _ (by decide) RawRows.raw2274) (Or.inl (by decide)))
    (slots710.inc_y 2275 2276 f r (row_of_literal 2275 _ (by decide) RawRows.raw2275) (Or.inl (by decide)))
    (slots710.jump 2276 2273 f r (row_of_literal 2276 _ (by decide) RawRows.raw2276))

theorem site2273 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2273:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2277:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2273Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2277 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2277:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2278:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2277 _ (row_of_literal 2277 _ (by decide) RawRows.raw2277)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2278Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2278 f r x y z) (slots160.atReg 2281 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2278 3 2281 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2278 2281 2279 f r (row_of_literal 2278 _ (by decide) RawRows.raw2278))
    (slots160.pos_x 2278 2281 2279 f r (row_of_literal 2278 _ (by decide) RawRows.raw2278))
    (slots160.inc_y 2279 2280 f r (row_of_literal 2279 _ (by decide) RawRows.raw2279) (Or.inl (by decide)))
    (slots160.jump 2280 2278 f r (row_of_literal 2280 _ (by decide) RawRows.raw2280))

theorem site2278 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2278:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2281:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2278Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2281Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2281 f r x y z) (slots210.atReg 2284 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2281 3 2284 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2281 2284 2282 f r (row_of_literal 2281 _ (by decide) RawRows.raw2281))
    (slots210.pos_x 2281 2284 2282 f r (row_of_literal 2281 _ (by decide) RawRows.raw2281))
    (slots210.inc_y 2282 2283 f r (row_of_literal 2282 _ (by decide) RawRows.raw2282) (Or.inl (by decide)))
    (slots210.jump 2283 2281 f r (row_of_literal 2283 _ (by decide) RawRows.raw2283))

theorem site2281 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2281:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2284:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2281Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2284Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2284 f r x y z) (slots617.atReg 2294 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2284 10 2294 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2284 2288 2285 f r (row_of_literal 2284 _ (by decide) RawRows.raw2284))
    (slots617.pos_y 2284 2288 2285 f r (row_of_literal 2284 _ (by decide) RawRows.raw2284))
    (slots617.inc_z 2285 2286 f r (row_of_literal 2285 _ (by decide) RawRows.raw2285) (Or.inl (by decide)))
    (slots617.inc_x 2286 2287 f r (row_of_literal 2286 _ (by decide) RawRows.raw2286) (Or.inl (by decide)))
    (slots617.jump 2287 2284 f r (row_of_literal 2287 _ (by decide) RawRows.raw2287))
    (slots617.zero_x 2288 2294 2289 f r (row_of_literal 2288 _ (by decide) RawRows.raw2288))
    (slots617.pos_x 2288 2294 2289 f r (row_of_literal 2288 _ (by decide) RawRows.raw2288))
    (slots617.inc_z 2289 2290 f r (row_of_literal 2289 _ (by decide) RawRows.raw2289) (Or.inl (by decide)))
    (slots617.zero_x 2290 2293 2291 f r (row_of_literal 2290 _ (by decide) RawRows.raw2290))
    (slots617.pos_x 2290 2293 2291 f r (row_of_literal 2290 _ (by decide) RawRows.raw2290))
    (slots617.inc_y 2291 2292 f r (row_of_literal 2291 _ (by decide) RawRows.raw2291) (Or.inl (by decide)))
    (slots617.jump 2292 2290 f r (row_of_literal 2292 _ (by decide) RawRows.raw2292))
    (slots617.jump 2293 2284 f r (row_of_literal 2293 _ (by decide) RawRows.raw2293))

theorem site2284 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2284:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2294:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2284Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2294Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2294 f r x y z) (slots720.atReg 2297 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2294 3 2297 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2294 2297 2295 f r (row_of_literal 2294 _ (by decide) RawRows.raw2294))
    (slots720.pos_x 2294 2297 2295 f r (row_of_literal 2294 _ (by decide) RawRows.raw2294))
    (slots720.inc_y 2295 2296 f r (row_of_literal 2295 _ (by decide) RawRows.raw2295) (Or.inl (by decide)))
    (slots720.jump 2296 2294 f r (row_of_literal 2296 _ (by decide) RawRows.raw2296))

theorem site2294 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2294:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2297:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2294Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2297Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2297 f r x y z) (slots561.atReg 2301 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2297 4 2301 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2297 2301 2298 f r (row_of_literal 2297 _ (by decide) RawRows.raw2297))
    (slots561.pos_x 2297 2301 2298 f r (row_of_literal 2297 _ (by decide) RawRows.raw2297))
    (slots561.inc_y 2298 2299 f r (row_of_literal 2298 _ (by decide) RawRows.raw2298) (Or.inl (by decide)))
    (slots561.inc_z 2299 2300 f r (row_of_literal 2299 _ (by decide) RawRows.raw2299) (Or.inl (by decide)))
    (slots561.jump 2300 2297 f r (row_of_literal 2300 _ (by decide) RawRows.raw2300))

theorem site2297 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2297:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2301:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2297Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2301Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2301 f r x y z) (slots650.atReg 2304 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2301 3 2304 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2301 2304 2302 f r (row_of_literal 2301 _ (by decide) RawRows.raw2301))
    (slots650.pos_x 2301 2304 2302 f r (row_of_literal 2301 _ (by decide) RawRows.raw2301))
    (slots650.inc_y 2302 2303 f r (row_of_literal 2302 _ (by decide) RawRows.raw2302) (Or.inl (by decide)))
    (slots650.jump 2303 2301 f r (row_of_literal 2303 _ (by decide) RawRows.raw2303))

theorem site2301 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2301:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2304:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2301Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2304Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2304 f r x y z) (slots267.atReg 2312 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2304 8 2312 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2304 2312 2305 f r (row_of_literal 2304 _ (by decide) RawRows.raw2304))
    (slots267.pos_x 2304 2312 2305 f r (row_of_literal 2304 _ (by decide) RawRows.raw2304))
    (slots267.inc_z 2305 2306 f r (row_of_literal 2305 _ (by decide) RawRows.raw2305) (Or.inl (by decide)))
    (slots267.zero_y 2306 2308 2307 f r (row_of_literal 2306 _ (by decide) RawRows.raw2306))
    (slots267.pos_y 2306 2308 2307 f r (row_of_literal 2306 _ (by decide) RawRows.raw2306))
    (slots267.jump 2307 2311 f r (row_of_literal 2307 _ (by decide) RawRows.raw2307))
    (slots267.zero_z 2308 2311 2309 f r (row_of_literal 2308 _ (by decide) RawRows.raw2308))
    (slots267.pos_z 2308 2311 2309 f r (row_of_literal 2308 _ (by decide) RawRows.raw2308))
    (slots267.inc_y 2309 2310 f r (row_of_literal 2309 _ (by decide) RawRows.raw2309) (Or.inl (by decide)))
    (slots267.jump 2310 2308 f r (row_of_literal 2310 _ (by decide) RawRows.raw2310))
    (slots267.jump 2311 2304 f r (row_of_literal 2311 _ (by decide) RawRows.raw2311))

theorem site2304 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2304:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2312:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2304Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2312Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2312 f r x y z) (slots720.atReg 2315 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2312 3 2315 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2312 2315 2313 f r (row_of_literal 2312 _ (by decide) RawRows.raw2312))
    (slots720.pos_x 2312 2315 2313 f r (row_of_literal 2312 _ (by decide) RawRows.raw2312))
    (slots720.inc_y 2313 2314 f r (row_of_literal 2313 _ (by decide) RawRows.raw2313) (Or.inl (by decide)))
    (slots720.jump 2314 2312 f r (row_of_literal 2314 _ (by decide) RawRows.raw2314))

theorem site2312 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2312:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2315:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2312Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2315Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2315 f r x y z) (slots617.atReg 2325 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2315 10 2325 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2315 2319 2316 f r (row_of_literal 2315 _ (by decide) RawRows.raw2315))
    (slots617.pos_y 2315 2319 2316 f r (row_of_literal 2315 _ (by decide) RawRows.raw2315))
    (slots617.inc_z 2316 2317 f r (row_of_literal 2316 _ (by decide) RawRows.raw2316) (Or.inl (by decide)))
    (slots617.inc_x 2317 2318 f r (row_of_literal 2317 _ (by decide) RawRows.raw2317) (Or.inl (by decide)))
    (slots617.jump 2318 2315 f r (row_of_literal 2318 _ (by decide) RawRows.raw2318))
    (slots617.zero_x 2319 2325 2320 f r (row_of_literal 2319 _ (by decide) RawRows.raw2319))
    (slots617.pos_x 2319 2325 2320 f r (row_of_literal 2319 _ (by decide) RawRows.raw2319))
    (slots617.inc_z 2320 2321 f r (row_of_literal 2320 _ (by decide) RawRows.raw2320) (Or.inl (by decide)))
    (slots617.zero_x 2321 2324 2322 f r (row_of_literal 2321 _ (by decide) RawRows.raw2321))
    (slots617.pos_x 2321 2324 2322 f r (row_of_literal 2321 _ (by decide) RawRows.raw2321))
    (slots617.inc_y 2322 2323 f r (row_of_literal 2322 _ (by decide) RawRows.raw2322) (Or.inl (by decide)))
    (slots617.jump 2323 2321 f r (row_of_literal 2323 _ (by decide) RawRows.raw2323))
    (slots617.jump 2324 2315 f r (row_of_literal 2324 _ (by decide) RawRows.raw2324))

theorem site2315 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2315:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2325:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2315Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2325Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2325 f r x y z) (slots710.atReg 2329 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2325 4 2329 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2325 2329 2326 f r (row_of_literal 2325 _ (by decide) RawRows.raw2325))
    (slots710.pos_x 2325 2329 2326 f r (row_of_literal 2325 _ (by decide) RawRows.raw2325))
    (slots710.inc_y 2326 2327 f r (row_of_literal 2326 _ (by decide) RawRows.raw2326) (Or.inl (by decide)))
    (slots710.inc_y 2327 2328 f r (row_of_literal 2327 _ (by decide) RawRows.raw2327) (Or.inl (by decide)))
    (slots710.jump 2328 2325 f r (row_of_literal 2328 _ (by decide) RawRows.raw2328))

theorem site2325 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2325:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2329:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2325Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2329 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2329:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2330:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2329 _ (row_of_literal 2329 _ (by decide) RawRows.raw2329)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2330Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2330 f r x y z) (slots267.atReg 2338 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2330 8 2338 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2330 2338 2331 f r (row_of_literal 2330 _ (by decide) RawRows.raw2330))
    (slots267.pos_x 2330 2338 2331 f r (row_of_literal 2330 _ (by decide) RawRows.raw2330))
    (slots267.inc_z 2331 2332 f r (row_of_literal 2331 _ (by decide) RawRows.raw2331) (Or.inl (by decide)))
    (slots267.zero_y 2332 2334 2333 f r (row_of_literal 2332 _ (by decide) RawRows.raw2332))
    (slots267.pos_y 2332 2334 2333 f r (row_of_literal 2332 _ (by decide) RawRows.raw2332))
    (slots267.jump 2333 2337 f r (row_of_literal 2333 _ (by decide) RawRows.raw2333))
    (slots267.zero_z 2334 2337 2335 f r (row_of_literal 2334 _ (by decide) RawRows.raw2334))
    (slots267.pos_z 2334 2337 2335 f r (row_of_literal 2334 _ (by decide) RawRows.raw2334))
    (slots267.inc_y 2335 2336 f r (row_of_literal 2335 _ (by decide) RawRows.raw2335) (Or.inl (by decide)))
    (slots267.jump 2336 2334 f r (row_of_literal 2336 _ (by decide) RawRows.raw2336))
    (slots267.jump 2337 2330 f r (row_of_literal 2337 _ (by decide) RawRows.raw2337))

theorem site2330 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2330:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2338:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2330Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2338Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2338 f r x y z) (slots720.atReg 2341 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2338 3 2341 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2338 2341 2339 f r (row_of_literal 2338 _ (by decide) RawRows.raw2338))
    (slots720.pos_x 2338 2341 2339 f r (row_of_literal 2338 _ (by decide) RawRows.raw2338))
    (slots720.inc_y 2339 2340 f r (row_of_literal 2339 _ (by decide) RawRows.raw2339) (Or.inl (by decide)))
    (slots720.jump 2340 2338 f r (row_of_literal 2340 _ (by decide) RawRows.raw2340))

theorem site2338 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2338:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2341:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2338Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2341Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2341 f r x y z) (slots617.atReg 2351 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2341 10 2351 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2341 2345 2342 f r (row_of_literal 2341 _ (by decide) RawRows.raw2341))
    (slots617.pos_y 2341 2345 2342 f r (row_of_literal 2341 _ (by decide) RawRows.raw2341))
    (slots617.inc_z 2342 2343 f r (row_of_literal 2342 _ (by decide) RawRows.raw2342) (Or.inl (by decide)))
    (slots617.inc_x 2343 2344 f r (row_of_literal 2343 _ (by decide) RawRows.raw2343) (Or.inl (by decide)))
    (slots617.jump 2344 2341 f r (row_of_literal 2344 _ (by decide) RawRows.raw2344))
    (slots617.zero_x 2345 2351 2346 f r (row_of_literal 2345 _ (by decide) RawRows.raw2345))
    (slots617.pos_x 2345 2351 2346 f r (row_of_literal 2345 _ (by decide) RawRows.raw2345))
    (slots617.inc_z 2346 2347 f r (row_of_literal 2346 _ (by decide) RawRows.raw2346) (Or.inl (by decide)))
    (slots617.zero_x 2347 2350 2348 f r (row_of_literal 2347 _ (by decide) RawRows.raw2347))
    (slots617.pos_x 2347 2350 2348 f r (row_of_literal 2347 _ (by decide) RawRows.raw2347))
    (slots617.inc_y 2348 2349 f r (row_of_literal 2348 _ (by decide) RawRows.raw2348) (Or.inl (by decide)))
    (slots617.jump 2349 2347 f r (row_of_literal 2349 _ (by decide) RawRows.raw2349))
    (slots617.jump 2350 2341 f r (row_of_literal 2350 _ (by decide) RawRows.raw2350))

theorem site2341 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2341:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2351:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2341Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2351Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2351 f r x y z) (slots710.atReg 2355 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2351 4 2355 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2351 2355 2352 f r (row_of_literal 2351 _ (by decide) RawRows.raw2351))
    (slots710.pos_x 2351 2355 2352 f r (row_of_literal 2351 _ (by decide) RawRows.raw2351))
    (slots710.inc_y 2352 2353 f r (row_of_literal 2352 _ (by decide) RawRows.raw2352) (Or.inl (by decide)))
    (slots710.inc_y 2353 2354 f r (row_of_literal 2353 _ (by decide) RawRows.raw2353) (Or.inl (by decide)))
    (slots710.jump 2354 2351 f r (row_of_literal 2354 _ (by decide) RawRows.raw2354))

theorem site2351 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2351:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2355:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2351Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site2355Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2355 f r x y z) (slots160.atReg 2358 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2355 3 2358 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2355 2358 2356 f r (row_of_literal 2355 _ (by decide) RawRows.raw2355))
    (slots160.pos_x 2355 2358 2356 f r (row_of_literal 2355 _ (by decide) RawRows.raw2355))
    (slots160.inc_y 2356 2357 f r (row_of_literal 2356 _ (by decide) RawRows.raw2356) (Or.inl (by decide)))
    (slots160.jump 2357 2355 f r (row_of_literal 2357 _ (by decide) RawRows.raw2357))

theorem site2355 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2355:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2358:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2355Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2358Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2358 f r x y z) (slots210.atReg 2361 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2358 3 2361 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2358 2361 2359 f r (row_of_literal 2358 _ (by decide) RawRows.raw2358))
    (slots210.pos_x 2358 2361 2359 f r (row_of_literal 2358 _ (by decide) RawRows.raw2358))
    (slots210.inc_y 2359 2360 f r (row_of_literal 2359 _ (by decide) RawRows.raw2359) (Or.inl (by decide)))
    (slots210.jump 2360 2358 f r (row_of_literal 2360 _ (by decide) RawRows.raw2360))

theorem site2358 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2358:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2361:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2358Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2361Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2361 f r x y z) (slots617.atReg 2371 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2361 10 2371 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2361 2365 2362 f r (row_of_literal 2361 _ (by decide) RawRows.raw2361))
    (slots617.pos_y 2361 2365 2362 f r (row_of_literal 2361 _ (by decide) RawRows.raw2361))
    (slots617.inc_z 2362 2363 f r (row_of_literal 2362 _ (by decide) RawRows.raw2362) (Or.inl (by decide)))
    (slots617.inc_x 2363 2364 f r (row_of_literal 2363 _ (by decide) RawRows.raw2363) (Or.inl (by decide)))
    (slots617.jump 2364 2361 f r (row_of_literal 2364 _ (by decide) RawRows.raw2364))
    (slots617.zero_x 2365 2371 2366 f r (row_of_literal 2365 _ (by decide) RawRows.raw2365))
    (slots617.pos_x 2365 2371 2366 f r (row_of_literal 2365 _ (by decide) RawRows.raw2365))
    (slots617.inc_z 2366 2367 f r (row_of_literal 2366 _ (by decide) RawRows.raw2366) (Or.inl (by decide)))
    (slots617.zero_x 2367 2370 2368 f r (row_of_literal 2367 _ (by decide) RawRows.raw2367))
    (slots617.pos_x 2367 2370 2368 f r (row_of_literal 2367 _ (by decide) RawRows.raw2367))
    (slots617.inc_y 2368 2369 f r (row_of_literal 2368 _ (by decide) RawRows.raw2368) (Or.inl (by decide)))
    (slots617.jump 2369 2367 f r (row_of_literal 2369 _ (by decide) RawRows.raw2369))
    (slots617.jump 2370 2361 f r (row_of_literal 2370 _ (by decide) RawRows.raw2370))

theorem site2361 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2361:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2371:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2361Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2371Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2371 f r x y z) (slots720.atReg 2374 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2371 3 2374 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2371 2374 2372 f r (row_of_literal 2371 _ (by decide) RawRows.raw2371))
    (slots720.pos_x 2371 2374 2372 f r (row_of_literal 2371 _ (by decide) RawRows.raw2371))
    (slots720.inc_y 2372 2373 f r (row_of_literal 2372 _ (by decide) RawRows.raw2372) (Or.inl (by decide)))
    (slots720.jump 2373 2371 f r (row_of_literal 2373 _ (by decide) RawRows.raw2373))

theorem site2371 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2371:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2374:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2371Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2374Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2374 f r x y z) (slots461.atReg 2378 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2374 4 2378 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2374 2378 2375 f r (row_of_literal 2374 _ (by decide) RawRows.raw2374))
    (slots461.pos_x 2374 2378 2375 f r (row_of_literal 2374 _ (by decide) RawRows.raw2374))
    (slots461.inc_y 2375 2376 f r (row_of_literal 2375 _ (by decide) RawRows.raw2375) (Or.inl (by decide)))
    (slots461.inc_z 2376 2377 f r (row_of_literal 2376 _ (by decide) RawRows.raw2376) (Or.inl (by decide)))
    (slots461.jump 2377 2374 f r (row_of_literal 2377 _ (by decide) RawRows.raw2377))

theorem site2374 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2374:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2378:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2374Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site2378Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2378 f r x y z) (slots640.atReg 2381 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2378 3 2381 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2378 2381 2379 f r (row_of_literal 2378 _ (by decide) RawRows.raw2378))
    (slots640.pos_x 2378 2381 2379 f r (row_of_literal 2378 _ (by decide) RawRows.raw2378))
    (slots640.inc_y 2379 2380 f r (row_of_literal 2379 _ (by decide) RawRows.raw2379) (Or.inl (by decide)))
    (slots640.jump 2380 2378 f r (row_of_literal 2380 _ (by decide) RawRows.raw2380))

theorem site2378 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2378:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2381:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2378Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site2381Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2381 f r x y z) (slots160.atReg 2384 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2381 3 2384 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2381 2384 2382 f r (row_of_literal 2381 _ (by decide) RawRows.raw2381))
    (slots160.pos_x 2381 2384 2382 f r (row_of_literal 2381 _ (by decide) RawRows.raw2381))
    (slots160.inc_y 2382 2383 f r (row_of_literal 2382 _ (by decide) RawRows.raw2382) (Or.inl (by decide)))
    (slots160.jump 2383 2381 f r (row_of_literal 2383 _ (by decide) RawRows.raw2383))

theorem site2381 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2381:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2384:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2381Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2384Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2384 f r x y z) (slots210.atReg 2387 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2384 3 2387 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2384 2387 2385 f r (row_of_literal 2384 _ (by decide) RawRows.raw2384))
    (slots210.pos_x 2384 2387 2385 f r (row_of_literal 2384 _ (by decide) RawRows.raw2384))
    (slots210.inc_y 2385 2386 f r (row_of_literal 2385 _ (by decide) RawRows.raw2385) (Or.inl (by decide)))
    (slots210.jump 2386 2384 f r (row_of_literal 2386 _ (by decide) RawRows.raw2386))

theorem site2384 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2384:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2387:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2384Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2387Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2387 f r x y z) (slots617.atReg 2397 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2387 10 2397 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2387 2391 2388 f r (row_of_literal 2387 _ (by decide) RawRows.raw2387))
    (slots617.pos_y 2387 2391 2388 f r (row_of_literal 2387 _ (by decide) RawRows.raw2387))
    (slots617.inc_z 2388 2389 f r (row_of_literal 2388 _ (by decide) RawRows.raw2388) (Or.inl (by decide)))
    (slots617.inc_x 2389 2390 f r (row_of_literal 2389 _ (by decide) RawRows.raw2389) (Or.inl (by decide)))
    (slots617.jump 2390 2387 f r (row_of_literal 2390 _ (by decide) RawRows.raw2390))
    (slots617.zero_x 2391 2397 2392 f r (row_of_literal 2391 _ (by decide) RawRows.raw2391))
    (slots617.pos_x 2391 2397 2392 f r (row_of_literal 2391 _ (by decide) RawRows.raw2391))
    (slots617.inc_z 2392 2393 f r (row_of_literal 2392 _ (by decide) RawRows.raw2392) (Or.inl (by decide)))
    (slots617.zero_x 2393 2396 2394 f r (row_of_literal 2393 _ (by decide) RawRows.raw2393))
    (slots617.pos_x 2393 2396 2394 f r (row_of_literal 2393 _ (by decide) RawRows.raw2393))
    (slots617.inc_y 2394 2395 f r (row_of_literal 2394 _ (by decide) RawRows.raw2394) (Or.inl (by decide)))
    (slots617.jump 2395 2393 f r (row_of_literal 2395 _ (by decide) RawRows.raw2395))
    (slots617.jump 2396 2387 f r (row_of_literal 2396 _ (by decide) RawRows.raw2396))

theorem site2387 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2387:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2397:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2387Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2397Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2397 f r x y z) (slots720.atReg 2400 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2397 3 2400 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2397 2400 2398 f r (row_of_literal 2397 _ (by decide) RawRows.raw2397))
    (slots720.pos_x 2397 2400 2398 f r (row_of_literal 2397 _ (by decide) RawRows.raw2397))
    (slots720.inc_y 2398 2399 f r (row_of_literal 2398 _ (by decide) RawRows.raw2398) (Or.inl (by decide)))
    (slots720.jump 2399 2397 f r (row_of_literal 2399 _ (by decide) RawRows.raw2399))

theorem site2397 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2397:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2400:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2397Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2400Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2400 f r x y z) (slots561.atReg 2404 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2400 4 2404 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2400 2404 2401 f r (row_of_literal 2400 _ (by decide) RawRows.raw2400))
    (slots561.pos_x 2400 2404 2401 f r (row_of_literal 2400 _ (by decide) RawRows.raw2400))
    (slots561.inc_y 2401 2402 f r (row_of_literal 2401 _ (by decide) RawRows.raw2401) (Or.inl (by decide)))
    (slots561.inc_z 2402 2403 f r (row_of_literal 2402 _ (by decide) RawRows.raw2402) (Or.inl (by decide)))
    (slots561.jump 2403 2400 f r (row_of_literal 2403 _ (by decide) RawRows.raw2403))

theorem site2400 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2400:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2404:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2400Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2404Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2404 f r x y z) (slots650.atReg 2407 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2404 3 2407 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2404 2407 2405 f r (row_of_literal 2404 _ (by decide) RawRows.raw2404))
    (slots650.pos_x 2404 2407 2405 f r (row_of_literal 2404 _ (by decide) RawRows.raw2404))
    (slots650.inc_y 2405 2406 f r (row_of_literal 2405 _ (by decide) RawRows.raw2405) (Or.inl (by decide)))
    (slots650.jump 2406 2404 f r (row_of_literal 2406 _ (by decide) RawRows.raw2406))

theorem site2404 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2404:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2407:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2404Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2407Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2407 f r x y z) (slots267.atReg 2415 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2407 8 2415 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2407 2415 2408 f r (row_of_literal 2407 _ (by decide) RawRows.raw2407))
    (slots267.pos_x 2407 2415 2408 f r (row_of_literal 2407 _ (by decide) RawRows.raw2407))
    (slots267.inc_z 2408 2409 f r (row_of_literal 2408 _ (by decide) RawRows.raw2408) (Or.inl (by decide)))
    (slots267.zero_y 2409 2411 2410 f r (row_of_literal 2409 _ (by decide) RawRows.raw2409))
    (slots267.pos_y 2409 2411 2410 f r (row_of_literal 2409 _ (by decide) RawRows.raw2409))
    (slots267.jump 2410 2414 f r (row_of_literal 2410 _ (by decide) RawRows.raw2410))
    (slots267.zero_z 2411 2414 2412 f r (row_of_literal 2411 _ (by decide) RawRows.raw2411))
    (slots267.pos_z 2411 2414 2412 f r (row_of_literal 2411 _ (by decide) RawRows.raw2411))
    (slots267.inc_y 2412 2413 f r (row_of_literal 2412 _ (by decide) RawRows.raw2412) (Or.inl (by decide)))
    (slots267.jump 2413 2411 f r (row_of_literal 2413 _ (by decide) RawRows.raw2413))
    (slots267.jump 2414 2407 f r (row_of_literal 2414 _ (by decide) RawRows.raw2414))

theorem site2407 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2407:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2415:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2407Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2415Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2415 f r x y z) (slots720.atReg 2418 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2415 3 2418 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2415 2418 2416 f r (row_of_literal 2415 _ (by decide) RawRows.raw2415))
    (slots720.pos_x 2415 2418 2416 f r (row_of_literal 2415 _ (by decide) RawRows.raw2415))
    (slots720.inc_y 2416 2417 f r (row_of_literal 2416 _ (by decide) RawRows.raw2416) (Or.inl (by decide)))
    (slots720.jump 2417 2415 f r (row_of_literal 2417 _ (by decide) RawRows.raw2417))

theorem site2415 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2415:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2418:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2415Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2418Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2418 f r x y z) (slots617.atReg 2428 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2418 10 2428 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2418 2422 2419 f r (row_of_literal 2418 _ (by decide) RawRows.raw2418))
    (slots617.pos_y 2418 2422 2419 f r (row_of_literal 2418 _ (by decide) RawRows.raw2418))
    (slots617.inc_z 2419 2420 f r (row_of_literal 2419 _ (by decide) RawRows.raw2419) (Or.inl (by decide)))
    (slots617.inc_x 2420 2421 f r (row_of_literal 2420 _ (by decide) RawRows.raw2420) (Or.inl (by decide)))
    (slots617.jump 2421 2418 f r (row_of_literal 2421 _ (by decide) RawRows.raw2421))
    (slots617.zero_x 2422 2428 2423 f r (row_of_literal 2422 _ (by decide) RawRows.raw2422))
    (slots617.pos_x 2422 2428 2423 f r (row_of_literal 2422 _ (by decide) RawRows.raw2422))
    (slots617.inc_z 2423 2424 f r (row_of_literal 2423 _ (by decide) RawRows.raw2423) (Or.inl (by decide)))
    (slots617.zero_x 2424 2427 2425 f r (row_of_literal 2424 _ (by decide) RawRows.raw2424))
    (slots617.pos_x 2424 2427 2425 f r (row_of_literal 2424 _ (by decide) RawRows.raw2424))
    (slots617.inc_y 2425 2426 f r (row_of_literal 2425 _ (by decide) RawRows.raw2425) (Or.inl (by decide)))
    (slots617.jump 2426 2424 f r (row_of_literal 2426 _ (by decide) RawRows.raw2426))
    (slots617.jump 2427 2418 f r (row_of_literal 2427 _ (by decide) RawRows.raw2427))

theorem site2418 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2418:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2428:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2418Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2428Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2428 f r x y z) (slots710.atReg 2432 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2428 4 2432 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2428 2432 2429 f r (row_of_literal 2428 _ (by decide) RawRows.raw2428))
    (slots710.pos_x 2428 2432 2429 f r (row_of_literal 2428 _ (by decide) RawRows.raw2428))
    (slots710.inc_y 2429 2430 f r (row_of_literal 2429 _ (by decide) RawRows.raw2429) (Or.inl (by decide)))
    (slots710.inc_y 2430 2431 f r (row_of_literal 2430 _ (by decide) RawRows.raw2430) (Or.inl (by decide)))
    (slots710.jump 2431 2428 f r (row_of_literal 2431 _ (by decide) RawRows.raw2431))

theorem site2428 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2428:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2432:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2428Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2432 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2432:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2433:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2432 _ (row_of_literal 2432 _ (by decide) RawRows.raw2432)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2433Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2433 f r x y z) (slots267.atReg 2441 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2433 8 2441 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2433 2441 2434 f r (row_of_literal 2433 _ (by decide) RawRows.raw2433))
    (slots267.pos_x 2433 2441 2434 f r (row_of_literal 2433 _ (by decide) RawRows.raw2433))
    (slots267.inc_z 2434 2435 f r (row_of_literal 2434 _ (by decide) RawRows.raw2434) (Or.inl (by decide)))
    (slots267.zero_y 2435 2437 2436 f r (row_of_literal 2435 _ (by decide) RawRows.raw2435))
    (slots267.pos_y 2435 2437 2436 f r (row_of_literal 2435 _ (by decide) RawRows.raw2435))
    (slots267.jump 2436 2440 f r (row_of_literal 2436 _ (by decide) RawRows.raw2436))
    (slots267.zero_z 2437 2440 2438 f r (row_of_literal 2437 _ (by decide) RawRows.raw2437))
    (slots267.pos_z 2437 2440 2438 f r (row_of_literal 2437 _ (by decide) RawRows.raw2437))
    (slots267.inc_y 2438 2439 f r (row_of_literal 2438 _ (by decide) RawRows.raw2438) (Or.inl (by decide)))
    (slots267.jump 2439 2437 f r (row_of_literal 2439 _ (by decide) RawRows.raw2439))
    (slots267.jump 2440 2433 f r (row_of_literal 2440 _ (by decide) RawRows.raw2440))

theorem site2433 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2433:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2441:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2433Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2441Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2441 f r x y z) (slots720.atReg 2444 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2441 3 2444 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2441 2444 2442 f r (row_of_literal 2441 _ (by decide) RawRows.raw2441))
    (slots720.pos_x 2441 2444 2442 f r (row_of_literal 2441 _ (by decide) RawRows.raw2441))
    (slots720.inc_y 2442 2443 f r (row_of_literal 2442 _ (by decide) RawRows.raw2442) (Or.inl (by decide)))
    (slots720.jump 2443 2441 f r (row_of_literal 2443 _ (by decide) RawRows.raw2443))

theorem site2441 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2441:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2444:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2441Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2444Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2444 f r x y z) (slots617.atReg 2454 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2444 10 2454 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2444 2448 2445 f r (row_of_literal 2444 _ (by decide) RawRows.raw2444))
    (slots617.pos_y 2444 2448 2445 f r (row_of_literal 2444 _ (by decide) RawRows.raw2444))
    (slots617.inc_z 2445 2446 f r (row_of_literal 2445 _ (by decide) RawRows.raw2445) (Or.inl (by decide)))
    (slots617.inc_x 2446 2447 f r (row_of_literal 2446 _ (by decide) RawRows.raw2446) (Or.inl (by decide)))
    (slots617.jump 2447 2444 f r (row_of_literal 2447 _ (by decide) RawRows.raw2447))
    (slots617.zero_x 2448 2454 2449 f r (row_of_literal 2448 _ (by decide) RawRows.raw2448))
    (slots617.pos_x 2448 2454 2449 f r (row_of_literal 2448 _ (by decide) RawRows.raw2448))
    (slots617.inc_z 2449 2450 f r (row_of_literal 2449 _ (by decide) RawRows.raw2449) (Or.inl (by decide)))
    (slots617.zero_x 2450 2453 2451 f r (row_of_literal 2450 _ (by decide) RawRows.raw2450))
    (slots617.pos_x 2450 2453 2451 f r (row_of_literal 2450 _ (by decide) RawRows.raw2450))
    (slots617.inc_y 2451 2452 f r (row_of_literal 2451 _ (by decide) RawRows.raw2451) (Or.inl (by decide)))
    (slots617.jump 2452 2450 f r (row_of_literal 2452 _ (by decide) RawRows.raw2452))
    (slots617.jump 2453 2444 f r (row_of_literal 2453 _ (by decide) RawRows.raw2453))

theorem site2444 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2444:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2454:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2444Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2454Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2454 f r x y z) (slots710.atReg 2458 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2454 4 2458 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2454 2458 2455 f r (row_of_literal 2454 _ (by decide) RawRows.raw2454))
    (slots710.pos_x 2454 2458 2455 f r (row_of_literal 2454 _ (by decide) RawRows.raw2454))
    (slots710.inc_y 2455 2456 f r (row_of_literal 2455 _ (by decide) RawRows.raw2455) (Or.inl (by decide)))
    (slots710.inc_y 2456 2457 f r (row_of_literal 2456 _ (by decide) RawRows.raw2456) (Or.inl (by decide)))
    (slots710.jump 2457 2454 f r (row_of_literal 2457 _ (by decide) RawRows.raw2457))

theorem site2454 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2454:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2458:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2454Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site2458Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2458 f r x y z) (slots160.atReg 2461 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2458 3 2461 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2458 2461 2459 f r (row_of_literal 2458 _ (by decide) RawRows.raw2458))
    (slots160.pos_x 2458 2461 2459 f r (row_of_literal 2458 _ (by decide) RawRows.raw2458))
    (slots160.inc_y 2459 2460 f r (row_of_literal 2459 _ (by decide) RawRows.raw2459) (Or.inl (by decide)))
    (slots160.jump 2460 2458 f r (row_of_literal 2460 _ (by decide) RawRows.raw2460))

theorem site2458 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2458:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2461:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2458Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2461Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2461 f r x y z) (slots210.atReg 2464 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2461 3 2464 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2461 2464 2462 f r (row_of_literal 2461 _ (by decide) RawRows.raw2461))
    (slots210.pos_x 2461 2464 2462 f r (row_of_literal 2461 _ (by decide) RawRows.raw2461))
    (slots210.inc_y 2462 2463 f r (row_of_literal 2462 _ (by decide) RawRows.raw2462) (Or.inl (by decide)))
    (slots210.jump 2463 2461 f r (row_of_literal 2463 _ (by decide) RawRows.raw2463))

theorem site2461 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2461:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2464:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2461Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2464Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2464 f r x y z) (slots617.atReg 2474 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2464 10 2474 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2464 2468 2465 f r (row_of_literal 2464 _ (by decide) RawRows.raw2464))
    (slots617.pos_y 2464 2468 2465 f r (row_of_literal 2464 _ (by decide) RawRows.raw2464))
    (slots617.inc_z 2465 2466 f r (row_of_literal 2465 _ (by decide) RawRows.raw2465) (Or.inl (by decide)))
    (slots617.inc_x 2466 2467 f r (row_of_literal 2466 _ (by decide) RawRows.raw2466) (Or.inl (by decide)))
    (slots617.jump 2467 2464 f r (row_of_literal 2467 _ (by decide) RawRows.raw2467))
    (slots617.zero_x 2468 2474 2469 f r (row_of_literal 2468 _ (by decide) RawRows.raw2468))
    (slots617.pos_x 2468 2474 2469 f r (row_of_literal 2468 _ (by decide) RawRows.raw2468))
    (slots617.inc_z 2469 2470 f r (row_of_literal 2469 _ (by decide) RawRows.raw2469) (Or.inl (by decide)))
    (slots617.zero_x 2470 2473 2471 f r (row_of_literal 2470 _ (by decide) RawRows.raw2470))
    (slots617.pos_x 2470 2473 2471 f r (row_of_literal 2470 _ (by decide) RawRows.raw2470))
    (slots617.inc_y 2471 2472 f r (row_of_literal 2471 _ (by decide) RawRows.raw2471) (Or.inl (by decide)))
    (slots617.jump 2472 2470 f r (row_of_literal 2472 _ (by decide) RawRows.raw2472))
    (slots617.jump 2473 2464 f r (row_of_literal 2473 _ (by decide) RawRows.raw2473))

theorem site2464 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2464:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2474:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2464Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2474Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2474 f r x y z) (slots720.atReg 2477 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2474 3 2477 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2474 2477 2475 f r (row_of_literal 2474 _ (by decide) RawRows.raw2474))
    (slots720.pos_x 2474 2477 2475 f r (row_of_literal 2474 _ (by decide) RawRows.raw2474))
    (slots720.inc_y 2475 2476 f r (row_of_literal 2475 _ (by decide) RawRows.raw2475) (Or.inl (by decide)))
    (slots720.jump 2476 2474 f r (row_of_literal 2476 _ (by decide) RawRows.raw2476))

theorem site2474 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2474:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2477:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2474Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2477Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2477 f r x y z) (slots561.atReg 2481 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2477 4 2481 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2477 2481 2478 f r (row_of_literal 2477 _ (by decide) RawRows.raw2477))
    (slots561.pos_x 2477 2481 2478 f r (row_of_literal 2477 _ (by decide) RawRows.raw2477))
    (slots561.inc_y 2478 2479 f r (row_of_literal 2478 _ (by decide) RawRows.raw2478) (Or.inl (by decide)))
    (slots561.inc_z 2479 2480 f r (row_of_literal 2479 _ (by decide) RawRows.raw2479) (Or.inl (by decide)))
    (slots561.jump 2480 2477 f r (row_of_literal 2480 _ (by decide) RawRows.raw2480))

theorem site2477 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2477:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2481:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2477Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2481Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2481 f r x y z) (slots650.atReg 2484 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2481 3 2484 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2481 2484 2482 f r (row_of_literal 2481 _ (by decide) RawRows.raw2481))
    (slots650.pos_x 2481 2484 2482 f r (row_of_literal 2481 _ (by decide) RawRows.raw2481))
    (slots650.inc_y 2482 2483 f r (row_of_literal 2482 _ (by decide) RawRows.raw2482) (Or.inl (by decide)))
    (slots650.jump 2483 2481 f r (row_of_literal 2483 _ (by decide) RawRows.raw2483))

theorem site2481 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2481:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2484:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2481Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2484Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2484 f r x y z) (slots160.atReg 2487 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2484 3 2487 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2484 2487 2485 f r (row_of_literal 2484 _ (by decide) RawRows.raw2484))
    (slots160.pos_x 2484 2487 2485 f r (row_of_literal 2484 _ (by decide) RawRows.raw2484))
    (slots160.inc_y 2485 2486 f r (row_of_literal 2485 _ (by decide) RawRows.raw2485) (Or.inl (by decide)))
    (slots160.jump 2486 2484 f r (row_of_literal 2486 _ (by decide) RawRows.raw2486))

theorem site2484 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2484:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2487:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2484Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2487Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2487 f r x y z) (slots210.atReg 2490 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2487 3 2490 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2487 2490 2488 f r (row_of_literal 2487 _ (by decide) RawRows.raw2487))
    (slots210.pos_x 2487 2490 2488 f r (row_of_literal 2487 _ (by decide) RawRows.raw2487))
    (slots210.inc_y 2488 2489 f r (row_of_literal 2488 _ (by decide) RawRows.raw2488) (Or.inl (by decide)))
    (slots210.jump 2489 2487 f r (row_of_literal 2489 _ (by decide) RawRows.raw2489))

theorem site2487 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2487:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2490:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2487Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


end PA192.ModelSearch.Register181.Certified
