module
public import Src181Atoms
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

noncomputable def emitAtom0 (n t s c u v y d w : V) : V := cantor d w
noncomputable def emitAtom1 (n t s c u v y d w : V) : V := cantor y (emitAtom0 n t s c u v y d w)
noncomputable def emitAtom2 (n t s c u v y d w : V) : V := cantor t s
noncomputable def emitAtom3 (n t s c u v y d w : V) : V := cantor c (emitAtom2 n t s c u v y d w)
noncomputable def emitAtom4 (n t s c u v y d w : V) : V := cantor c u
noncomputable def emitAtom5 (n t s c u v y d w : V) : V := cantor ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (emitAtom2 n t s c u v y d w)
noncomputable def emitAtom6 (n t s c u v y d w : V) : V := cantor ((emitAtom4 n t s c u v y d w)+(emitAtom4 n t s c u v y d w)) (d+u)
noncomputable def emitAtom7 (n t s c u v y d w : V) : V := cantor ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) (emitAtom2 n t s c u v y d w)
noncomputable def emitAtom8 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom7 n t s c u v y d w)
noncomputable def emitAtom9 (n t s c u v y d w : V) : V := cantor (d+u) c
noncomputable def emitAtom10 (n t s c u v y d w : V) : V := cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom7 n t s c u v y d w)
noncomputable def emitAtom11 (n t s c u v y d w : V) : V := cantor (v+y) (emitAtom10 n t s c u v y d w)
noncomputable def emitAtom12 (n t s c u v y d w : V) : V := cantor (v+y) c
noncomputable def emitAtom13 (n t s c u v y d w : V) : V := cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) ((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w))
noncomputable def emitAtom14 (n t s c u v y d w : V) : V := cantor ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) ((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w))
noncomputable def emitAtom15 (n t s c u v y d w : V) : V := cantor ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) (emitAtom2 n t s c u v y d w)
noncomputable def emitAtom16 (n t s c u v y d w : V) : V := cantor (v+y) (emitAtom15 n t s c u v y d w)
noncomputable def emitAtom17 (n t s c u v y d w : V) : V := cantor (v+y) (v+y)
noncomputable def emitAtom18 (n t s c u v y d w : V) : V := cantor ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom15 n t s c u v y d w)
noncomputable def emitAtom19 (n t s c u v y d w : V) : V := cantor ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (d+u)
noncomputable def emitAtom20 (n t s c u v y d w : V) : V := cantor ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w)
noncomputable def emitAtom21 (n t s c u v y d w : V) : V := cantor ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (v+y)
noncomputable def emitAtom22 (n t s c u v y d w : V) : V := cantor ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w)
noncomputable def emitAtom23 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom22 n t s c u v y d w)
noncomputable def emitAtom24 (n t s c u v y d w : V) : V := cantor (d+u) (v+y)
noncomputable def emitAtom25 (n t s c u v y d w : V) : V := cantor ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom22 n t s c u v y d w)
noncomputable def emitAtom26 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom25 n t s c u v y d w)
noncomputable def emitAtom27 (n t s c u v y d w : V) : V := cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom25 n t s c u v y d w)
noncomputable def emitAtom28 (n t s c u v y d w : V) : V := cantor c (emitAtom27 n t s c u v y d w)
noncomputable def emitAtom29 (n t s c u v y d w : V) : V := cantor c (v+y)
noncomputable def emitAtom30 (n t s c u v y d w : V) : V := cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1)
noncomputable def emitAtom31 (n t s c u v y d w : V) : V := cantor ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) ((emitAtom30 n t s c u v y d w)+(emitAtom30 n t s c u v y d w))
noncomputable def emitAtom32 (n t s c u v y d w : V) : V := cantor ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) (emitAtom22 n t s c u v y d w)
noncomputable def emitAtom33 (n t s c u v y d w : V) : V := cantor 1 (emitAtom32 n t s c u v y d w)
noncomputable def emitAtom34 (n t s c u v y d w : V) : V := cantor 1 c
noncomputable def emitAtom35 (n t s c u v y d w : V) : V := cantor ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)
noncomputable def emitAtom36 (n t s c u v y d w : V) : V := cantor ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (d+u)
noncomputable def emitAtom37 (n t s c u v y d w : V) : V := cantor ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)
noncomputable def emitAtom38 (n t s c u v y d w : V) : V := cantor ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (v+y)
noncomputable def emitAtom39 (n t s c u v y d w : V) : V := cantor ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)
noncomputable def emitAtom40 (n t s c u v y d w : V) : V := cantor c (emitAtom39 n t s c u v y d w)
noncomputable def emitAtom41 (n t s c u v y d w : V) : V := cantor (v+y) (emitAtom40 n t s c u v y d w)
noncomputable def emitAtom42 (n t s c u v y d w : V) : V := cantor c ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2)
noncomputable def emitAtom43 (n t s c u v y d w : V) : V := cantor ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w)
noncomputable def emitAtom44 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom43 n t s c u v y d w)
noncomputable def emitAtom45 (n t s c u v y d w : V) : V := cantor ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1)
noncomputable def emitAtom46 (n t s c u v y d w : V) : V := cantor ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1)
noncomputable def emitAtom47 (n t s c u v y d w : V) : V := cantor ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)
noncomputable def emitAtom48 (n t s c u v y d w : V) : V := cantor c (emitAtom47 n t s c u v y d w)
noncomputable def emitAtom49 (n t s c u v y d w : V) : V := cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w)
noncomputable def emitAtom50 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom49 n t s c u v y d w)
noncomputable def emitAtom51 (n t s c u v y d w : V) : V := cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w)
noncomputable def emitAtom52 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom51 n t s c u v y d w)
noncomputable def emitAtom53 (n t s c u v y d w : V) : V := cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1)
noncomputable def emitAtom54 (n t s c u v y d w : V) : V := cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1)
noncomputable def emitAtom55 (n t s c u v y d w : V) : V := cantor ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) (emitAtom47 n t s c u v y d w)
noncomputable def emitAtom56 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom55 n t s c u v y d w)
noncomputable def emitAtom57 (n t s c u v y d w : V) : V := cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w)
noncomputable def emitAtom58 (n t s c u v y d w : V) : V := cantor c (emitAtom57 n t s c u v y d w)
noncomputable def emitAtom59 (n t s c u v y d w : V) : V := cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w)
noncomputable def emitAtom60 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom59 n t s c u v y d w)
noncomputable def emitAtom61 (n t s c u v y d w : V) : V := cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1)
noncomputable def emitAtom62 (n t s c u v y d w : V) : V := cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1)
noncomputable def emitAtom63 (n t s c u v y d w : V) : V := cantor ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) (emitAtom55 n t s c u v y d w)
noncomputable def emitAtom64 (n t s c u v y d w : V) : V := cantor 0 (emitAtom63 n t s c u v y d w)
noncomputable def emitAtom65 (n t s c u v y d w : V) : V := cantor (v+y) (emitAtom64 n t s c u v y d w)
noncomputable def emitAtom66 (n t s c u v y d w : V) : V := cantor 0 ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2)
noncomputable def emitAtom67 (n t s c u v y d w : V) : V := cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w)
noncomputable def emitAtom68 (n t s c u v y d w : V) : V := cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (d+u)
noncomputable def emitAtom69 (n t s c u v y d w : V) : V := cantor ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w)
noncomputable def emitAtom70 (n t s c u v y d w : V) : V := cantor ((emitAtom68 n t s c u v y d w)+(emitAtom68 n t s c u v y d w)+1) (v+y)
noncomputable def emitAtom71 (n t s c u v y d w : V) : V := cantor ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) (emitAtom63 n t s c u v y d w)
noncomputable def emitAtom72 (n t s c u v y d w : V) : V := cantor 0 (emitAtom71 n t s c u v y d w)
noncomputable def emitAtom73 (n t s c u v y d w : V) : V := cantor (v+y) (emitAtom72 n t s c u v y d w)
noncomputable def emitAtom74 (n t s c u v y d w : V) : V := cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w)
noncomputable def emitAtom75 (n t s c u v y d w : V) : V := cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (v+y)
noncomputable def emitAtom76 (n t s c u v y d w : V) : V := cantor ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w)
noncomputable def emitAtom77 (n t s c u v y d w : V) : V := cantor ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (v+y)
noncomputable def emitAtom78 (n t s c u v y d w : V) : V := cantor ((emitAtom70 n t s c u v y d w)+(emitAtom70 n t s c u v y d w)+1) ((emitAtom77 n t s c u v y d w)+(emitAtom77 n t s c u v y d w)+1)
noncomputable def emitAtom79 (n t s c u v y d w : V) : V := cantor ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) (emitAtom63 n t s c u v y d w)
noncomputable def emitAtom80 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom79 n t s c u v y d w)
noncomputable def emitAtom81 (n t s c u v y d w : V) : V := cantor ((emitAtom78 n t s c u v y d w)+(emitAtom78 n t s c u v y d w)) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1)
noncomputable def emitAtom82 (n t s c u v y d w : V) : V := cantor ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) (emitAtom63 n t s c u v y d w)
noncomputable def emitAtom83 (n t s c u v y d w : V) : V := cantor (v+y) (emitAtom82 n t s c u v y d w)
noncomputable def emitAtom84 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom83 n t s c u v y d w)
noncomputable def emitAtom85 (n t s c u v y d w : V) : V := cantor (v+y) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2)
noncomputable def emitAtom86 (n t s c u v y d w : V) : V := cantor ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w)
noncomputable def emitAtom87 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom86 n t s c u v y d w)
noncomputable def emitAtom88 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom87 n t s c u v y d w)
noncomputable def emitAtom89 (n t s c u v y d w : V) : V := cantor (d+u) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2)
noncomputable def emitAtom90 (n t s c u v y d w : V) : V := cantor ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1)
noncomputable def emitAtom91 (n t s c u v y d w : V) : V := cantor ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w)
noncomputable def emitAtom92 (n t s c u v y d w : V) : V := cantor (d+u) (emitAtom91 n t s c u v y d w)
noncomputable def emitAtom93 (n t s c u v y d w : V) : V := cantor ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1)

end PA192.ModelSearch.Register181.Commands
