import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2688_0 : checkWitness 2688 false false 635 = true := by decide +kernel
private theorem w2688_1 : checkWitness 2688 false true 4723 = true := by decide +kernel
private theorem w2688_2 : checkWitness 2688 true false 635 = true := by decide +kernel
private theorem w2688_3 : checkWitness 2688 true true 4723 = true := by decide +kernel
private theorem cases2688 : checkFour 2688 (635,4723,635,4723) = true := by
  simp only [checkFour, w2688_0, w2688_1, w2688_2, w2688_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2688 : Coverage 2688 2689 := checkList_sound (ws:=[(635,4723,635,4723)]) (by simpa only [checkList, Bool.and_true] using cases2688)
private theorem w2689_0 : checkWitness 2689 false false 8908 = true := by decide +kernel
private theorem w2689_2 : checkWitness 2689 true false 8904 = true := by decide +kernel
private theorem cases2689 : checkFour 2689 (8908,0,8904,0) = true := by
  simp only [checkFour, w2689_0, w2689_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2689 : Coverage 2689 2690 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases2689)
private theorem w2690_0 : checkWitness 2690 false false 8904 = true := by decide +kernel
private theorem w2690_2 : checkWitness 2690 true false 8900 = true := by decide +kernel
private theorem cases2690 : checkFour 2690 (8904,0,8900,0) = true := by
  simp only [checkFour, w2690_0, w2690_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2690 : Coverage 2690 2691 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases2690)
private theorem w2691_0 : checkWitness 2691 false false 68 = true := by decide +kernel
private theorem w2691_2 : checkWitness 2691 true false 68 = true := by decide +kernel
private theorem cases2691 : checkFour 2691 (68,0,68,0) = true := by
  simp only [checkFour, w2691_0, w2691_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2691 : Coverage 2691 2692 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2691)
private theorem w2692_0 : checkWitness 2692 false false 8924 = true := by decide +kernel
private theorem w2692_2 : checkWitness 2692 true false 8920 = true := by decide +kernel
private theorem cases2692 : checkFour 2692 (8924,0,8920,0) = true := by
  simp only [checkFour, w2692_0, w2692_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2692 : Coverage 2692 2693 := checkList_sound (ws:=[(8924,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases2692)
private theorem w2693_0 : checkWitness 2693 false false 8908 = true := by decide +kernel
private theorem w2693_2 : checkWitness 2693 true false 8904 = true := by decide +kernel
private theorem cases2693 : checkFour 2693 (8908,0,8904,0) = true := by
  simp only [checkFour, w2693_0, w2693_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2693 : Coverage 2693 2694 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases2693)
private theorem w2694_0 : checkWitness 2694 false false 536 = true := by decide +kernel
private theorem w2694_1 : checkWitness 2694 false true 4632 = true := by decide +kernel
private theorem w2694_2 : checkWitness 2694 true false 536 = true := by decide +kernel
private theorem w2694_3 : checkWitness 2694 true true 4632 = true := by decide +kernel
private theorem cases2694 : checkFour 2694 (536,4632,536,4632) = true := by
  simp only [checkFour, w2694_0, w2694_1, w2694_2, w2694_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2694 : Coverage 2694 2695 := checkList_sound (ws:=[(536,4632,536,4632)]) (by simpa only [checkList, Bool.and_true] using cases2694)
private theorem w2695_0 : checkWitness 2695 false false 8931 = true := by decide +kernel
private theorem w2695_2 : checkWitness 2695 true false 8927 = true := by decide +kernel
private theorem cases2695 : checkFour 2695 (8931,0,8927,0) = true := by
  simp only [checkFour, w2695_0, w2695_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2695 : Coverage 2695 2696 := checkList_sound (ws:=[(8931,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases2695)
private theorem w2696_0 : checkWitness 2696 false false 662 = true := by decide +kernel
private theorem w2696_1 : checkWitness 2696 false true 4758 = true := by decide +kernel
private theorem w2696_2 : checkWitness 2696 true false 653 = true := by decide +kernel
private theorem w2696_3 : checkWitness 2696 true true 4749 = true := by decide +kernel
private theorem cases2696 : checkFour 2696 (662,4758,653,4749) = true := by
  simp only [checkFour, w2696_0, w2696_1, w2696_2, w2696_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2696 : Coverage 2696 2697 := checkList_sound (ws:=[(662,4758,653,4749)]) (by simpa only [checkList, Bool.and_true] using cases2696)
private theorem w2697_0 : checkWitness 2697 false false 198 = true := by decide +kernel
private theorem w2697_2 : checkWitness 2697 true false 198 = true := by decide +kernel
private theorem cases2697 : checkFour 2697 (198,0,198,0) = true := by
  simp only [checkFour, w2697_0, w2697_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2697 : Coverage 2697 2698 := checkList_sound (ws:=[(198,0,198,0)]) (by simpa only [checkList, Bool.and_true] using cases2697)
private theorem w2698_0 : checkWitness 2698 false false 617 = true := by decide +kernel
private theorem w2698_1 : checkWitness 2698 false true 4705 = true := by decide +kernel
private theorem w2698_2 : checkWitness 2698 true false 617 = true := by decide +kernel
private theorem w2698_3 : checkWitness 2698 true true 4705 = true := by decide +kernel
private theorem cases2698 : checkFour 2698 (617,4705,617,4705) = true := by
  simp only [checkFour, w2698_0, w2698_1, w2698_2, w2698_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2698 : Coverage 2698 2699 := checkList_sound (ws:=[(617,4705,617,4705)]) (by simpa only [checkList, Bool.and_true] using cases2698)
private theorem w2699_0 : checkWitness 2699 false false 8946 = true := by decide +kernel
private theorem w2699_2 : checkWitness 2699 true false 8937 = true := by decide +kernel
private theorem cases2699 : checkFour 2699 (8946,0,8937,0) = true := by
  simp only [checkFour, w2699_0, w2699_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2699 : Coverage 2699 2700 := checkList_sound (ws:=[(8946,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases2699)
private theorem w2700_0 : checkWitness 2700 false false 58 = true := by decide +kernel
private theorem w2700_2 : checkWitness 2700 true false 58 = true := by decide +kernel
private theorem cases2700 : checkFour 2700 (58,0,58,0) = true := by
  simp only [checkFour, w2700_0, w2700_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2700 : Coverage 2700 2701 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2700)
private theorem w2701_0 : checkWitness 2701 false false 50 = true := by decide +kernel
private theorem w2701_2 : checkWitness 2701 true false 50 = true := by decide +kernel
private theorem cases2701 : checkFour 2701 (50,0,50,0) = true := by
  simp only [checkFour, w2701_0, w2701_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2701 : Coverage 2701 2702 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2701)
private theorem w2702_0 : checkWitness 2702 false false 623 = true := by decide +kernel
private theorem w2702_1 : checkWitness 2702 false true 4715 = true := by decide +kernel
private theorem w2702_2 : checkWitness 2702 true false 623 = true := by decide +kernel
private theorem w2702_3 : checkWitness 2702 true true 4715 = true := by decide +kernel
private theorem cases2702 : checkFour 2702 (623,4715,623,4715) = true := by
  simp only [checkFour, w2702_0, w2702_1, w2702_2, w2702_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2702 : Coverage 2702 2703 := checkList_sound (ws:=[(623,4715,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases2702)
private theorem w2703_0 : checkWitness 2703 false false 8884 = true := by decide +kernel
private theorem w2703_2 : checkWitness 2703 true false 8880 = true := by decide +kernel
private theorem cases2703 : checkFour 2703 (8884,0,8880,0) = true := by
  simp only [checkFour, w2703_0, w2703_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2703 : Coverage 2703 2704 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases2703)
private theorem w2704_0 : checkWitness 2704 false false 50 = true := by decide +kernel
private theorem w2704_2 : checkWitness 2704 true false 50 = true := by decide +kernel
private theorem cases2704 : checkFour 2704 (50,0,50,0) = true := by
  simp only [checkFour, w2704_0, w2704_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2704 : Coverage 2704 2705 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2704)
private theorem w2705_0 : checkWitness 2705 false false 578 = true := by decide +kernel
private theorem w2705_1 : checkWitness 2705 false true 4674 = true := by decide +kernel
private theorem w2705_2 : checkWitness 2705 true false 578 = true := by decide +kernel
private theorem w2705_3 : checkWitness 2705 true true 4674 = true := by decide +kernel
private theorem cases2705 : checkFour 2705 (578,4674,578,4674) = true := by
  simp only [checkFour, w2705_0, w2705_1, w2705_2, w2705_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2705 : Coverage 2705 2706 := checkList_sound (ws:=[(578,4674,578,4674)]) (by simpa only [checkList, Bool.and_true] using cases2705)
private theorem w2706_0 : checkWitness 2706 false false 8919 = true := by decide +kernel
private theorem w2706_2 : checkWitness 2706 true false 8915 = true := by decide +kernel
private theorem cases2706 : checkFour 2706 (8919,0,8915,0) = true := by
  simp only [checkFour, w2706_0, w2706_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2706 : Coverage 2706 2707 := checkList_sound (ws:=[(8919,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases2706)
private theorem w2707_0 : checkWitness 2707 false false 8954 = true := by decide +kernel
private theorem w2707_2 : checkWitness 2707 true false 8945 = true := by decide +kernel
private theorem cases2707 : checkFour 2707 (8954,0,8945,0) = true := by
  simp only [checkFour, w2707_0, w2707_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2707 : Coverage 2707 2708 := checkList_sound (ws:=[(8954,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2707)
private theorem w2708_0 : checkWitness 2708 false false 68 = true := by decide +kernel
private theorem w2708_2 : checkWitness 2708 true false 68 = true := by decide +kernel
private theorem cases2708 : checkFour 2708 (68,0,68,0) = true := by
  simp only [checkFour, w2708_0, w2708_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2708 : Coverage 2708 2709 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2708)
private theorem w2709_0 : checkWitness 2709 false false 666 = true := by decide +kernel
private theorem w2709_1 : checkWitness 2709 false true 4758 = true := by decide +kernel
private theorem w2709_2 : checkWitness 2709 true false 657 = true := by decide +kernel
private theorem w2709_3 : checkWitness 2709 true true 4749 = true := by decide +kernel
private theorem cases2709 : checkFour 2709 (666,4758,657,4749) = true := by
  simp only [checkFour, w2709_0, w2709_1, w2709_2, w2709_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2709 : Coverage 2709 2710 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases2709)
private theorem w2710_0 : checkWitness 2710 false false 8915 = true := by decide +kernel
private theorem w2710_2 : checkWitness 2710 true false 8911 = true := by decide +kernel
private theorem cases2710 : checkFour 2710 (8915,0,8911,0) = true := by
  simp only [checkFour, w2710_0, w2710_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2710 : Coverage 2710 2711 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases2710)
private theorem w2711_0 : checkWitness 2711 false false 660 = true := by decide +kernel
private theorem w2711_1 : checkWitness 2711 false true 4752 = true := by decide +kernel
private theorem w2711_2 : checkWitness 2711 true false 651 = true := by decide +kernel
private theorem w2711_3 : checkWitness 2711 true true 4743 = true := by decide +kernel
private theorem cases2711 : checkFour 2711 (660,4752,651,4743) = true := by
  simp only [checkFour, w2711_0, w2711_1, w2711_2, w2711_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2711 : Coverage 2711 2712 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases2711)
private theorem w2712_0 : checkWitness 2712 false false 8884 = true := by decide +kernel
private theorem w2712_2 : checkWitness 2712 true false 8880 = true := by decide +kernel
private theorem cases2712 : checkFour 2712 (8884,0,8880,0) = true := by
  simp only [checkFour, w2712_0, w2712_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2712 : Coverage 2712 2713 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases2712)
private theorem w2713_0 : checkWitness 2713 false false 56 = true := by decide +kernel
private theorem w2713_2 : checkWitness 2713 true false 56 = true := by decide +kernel
private theorem cases2713 : checkFour 2713 (56,0,56,0) = true := by
  simp only [checkFour, w2713_0, w2713_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2713 : Coverage 2713 2714 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2713)
private theorem w2714_0 : checkWitness 2714 false false 48 = true := by decide +kernel
private theorem w2714_2 : checkWitness 2714 true false 48 = true := by decide +kernel
private theorem cases2714 : checkFour 2714 (48,0,48,0) = true := by
  simp only [checkFour, w2714_0, w2714_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2714 : Coverage 2714 2715 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2714)
private theorem w2715_0 : checkWitness 2715 false false 627 = true := by decide +kernel
private theorem w2715_1 : checkWitness 2715 false true 4715 = true := by decide +kernel
private theorem w2715_2 : checkWitness 2715 true false 627 = true := by decide +kernel
private theorem w2715_3 : checkWitness 2715 true true 4715 = true := by decide +kernel
private theorem cases2715 : checkFour 2715 (627,4715,627,4715) = true := by
  simp only [checkFour, w2715_0, w2715_1, w2715_2, w2715_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2715 : Coverage 2715 2716 := checkList_sound (ws:=[(627,4715,627,4715)]) (by simpa only [checkList, Bool.and_true] using cases2715)
private theorem w2716_0 : checkWitness 2716 false false 8900 = true := by decide +kernel
private theorem w2716_2 : checkWitness 2716 true false 8896 = true := by decide +kernel
private theorem cases2716 : checkFour 2716 (8900,0,8896,0) = true := by
  simp only [checkFour, w2716_0, w2716_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2716 : Coverage 2716 2717 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases2716)
private theorem w2717_0 : checkWitness 2717 false false 8896 = true := by decide +kernel
private theorem w2717_2 : checkWitness 2717 true false 8892 = true := by decide +kernel
private theorem cases2717 : checkFour 2717 (8896,0,8892,0) = true := by
  simp only [checkFour, w2717_0, w2717_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2717 : Coverage 2717 2718 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases2717)
private theorem w2718_0 : checkWitness 2718 false false 62 = true := by decide +kernel
private theorem w2718_2 : checkWitness 2718 true false 62 = true := by decide +kernel
private theorem cases2718 : checkFour 2718 (62,0,62,0) = true := by
  simp only [checkFour, w2718_0, w2718_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2718 : Coverage 2718 2719 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2718)
private theorem w2719_0 : checkWitness 2719 false false 8920 = true := by decide +kernel
private theorem w2719_2 : checkWitness 2719 true false 8916 = true := by decide +kernel
private theorem cases2719 : checkFour 2719 (8920,0,8916,0) = true := by
  simp only [checkFour, w2719_0, w2719_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2719 : Coverage 2719 2720 := checkList_sound (ws:=[(8920,0,8916,0)]) (by simpa only [checkList, Bool.and_true] using cases2719)
theorem cover2688 : Coverage 2688 2720 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2688 one2689) (Coverage.join one2690 one2691)) (Coverage.join (Coverage.join one2692 one2693) (Coverage.join one2694 one2695))) (Coverage.join (Coverage.join (Coverage.join one2696 one2697) (Coverage.join one2698 one2699)) (Coverage.join (Coverage.join one2700 one2701) (Coverage.join one2702 one2703)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2704 one2705) (Coverage.join one2706 one2707)) (Coverage.join (Coverage.join one2708 one2709) (Coverage.join one2710 one2711))) (Coverage.join (Coverage.join (Coverage.join one2712 one2713) (Coverage.join one2714 one2715)) (Coverage.join (Coverage.join one2716 one2717) (Coverage.join one2718 one2719)))))
end NF181PA.Symbolic
