import NF181PATapeRows

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.PhysicalModel PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace NF181PA.Symbolic
open Atom
open Execute (bit)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 2000000
set_option maxRecDepth 10000

/-- Evaluate a finite list of symbolic segments, followed by an arithmetic
tail ray. The program's canonical frame descends exactly these segments. -/
noncomputable def prefixRay (v : Nat → V) (tail : V) : List Atom → V
  | [] => tail
  | .digit b :: w => bit b (prefixRay v tail w)
  | .many b i :: w => rep b (v i) (prefixRay v tail w)
  | .paired b i :: w => pairs b (v i) (prefixRay v tail w)
  | .tail i :: _ => v i

theorem prefix_append (v : Nat → V) (a b : List Atom) (z : V) :
    prefixRay v z (a++b) = prefixRay v (prefixRay v z b) a := by
  induction a with
  | nil => rfl
  | cons x w ih => cases x <;> simp [prefixRay,ih]

theorem word_eq_prefix (v : Nat → V) (w : List Atom) : word v w = prefixRay v 0 w := by
  induction w with
  | nil => rfl
  | cons a w ih => cases a <;> simp [word,prefixRay,ih]

private theorem rep_add (b : Bool) (a k tail : V) : rep b (a+k) tail = rep b a (rep b k tail) := by
  rw [add_comm,rep,iterate_add]; rfl

private theorem pairs_add (b : Bool) (a k tail : V) : pairs b (a+k) tail = pairs b a (pairs b k tail) := by
  rw [add_comm,pairs,iterate_add]; rfl

theorem prefix_digits (b : Bool) (m : Nat) (v : Nat→V) (tail : V) :
    prefixRay v tail (List.replicate m (.digit b)) = rep b (m:V) tail := by
  induction m with
  | zero => simp [prefixRay,rep]
  | succ m ih => simp only [List.replicate_succ,prefixRay,ih,Nat.cast_succ,rep,iterate_succ]

theorem prefix_pairs (m : Nat) (v : Nat→V) (tail : V) :
    prefixRay v tail (List.replicate m [Atom.digit false,.digit true]).flatten = pairs false (m:V) tail := by
  induction m with
  | zero => simp [prefixRay,pairs]
  | succ m ih =>
    simp only [List.replicate_succ,List.flatten_cons,prefix_append,ih,Nat.cast_succ,pairs,iterate_succ]
    rfl

private theorem zeros_end (m : Nat) : rep false (m:V) 0 = 0 := by
  induction m with
  | zero => simp [rep]
  | succ m ih =>
    simp only [Nat.cast_succ,rep,iterate_succ]
    change bit false (rep false (m:V) 0) = 0
    simp [ih,bit]

noncomputable def rayLit : List Bool → V → V
  | [],x => x
  | b::w,x => bit b (rayLit w x)
instance rayLitDef (w : List Bool) : Language.DefinableFunction₁ ℒₒᵣ (rayLit (V:=V) w) := by
  induction w with
  | nil => change Language.DefinableFunction₁ ℒₒᵣ (id : V → V); definability
  | cons b w ih => simp only [rayLit]; definability

theorem prefix_literal (w : List Bool) (v : Nat→V) (tail : V) :
    prefixRay v tail (w.map digit) = rayLit w tail := by
  induction w with
  | nil => rfl
  | cons b w ih => simp [prefixRay,rayLit,ih]

/-- Logical register value plus the mandatory two one-cells. A cold
register 0 instead represents -1 with a single one-cell. -/
noncomputable def count (c : Bool) (r : Nat → V) (i : Nat) : V :=
  if c && (i==0) then 1 else r i+2

noncomputable def file (ks : List Nat) (c : Bool) (r : Nat→V) (tail : V) : V :=
  ks.foldr (fun i s => bit false (rep true (count c r i) s)) tail

noncomputable def canonical (pc : Nat) (c : Bool) (rs : Nat→V) (g spare : V) : V :=
  let addr := NF181Data.addressBits pc
  pack 12 1 (rayLit addr (rep false (((40-addr.length:Nat):V)+g+10)
    (bit true (file NF181Data.registerOrder c rs (pairs false (24+spare) 0)))))

def isIncReg (pc i : Nat) : Bool :=
  match Direct181Source.Raw.program pc with | .inl (j,_) => j==i | _ => false
def isDecReg (pc i : Nat) : Bool :=
  match Direct181Source.Raw.program pc with | .inr (.inl (j,_,_,_)) => j==i | _ => false

/-- The single unconstrained parameter in a positive decrement is the
predecessor of the input. In a zero decrement the selected value is fixed. -/
noncomputable def regsFor (pc : Nat) (cold pos out : Bool) (v : Nat→V) (i : Nat) : V :=
  if cold && i==0 then 0 else
  if isDecReg pc i then (if pos then (if out then v i else v i+1) else 0)
  else if isIncReg pc i && out then v i+1 else v i

def coldFor (pc : Nat) (cold out : Bool) : Bool := cold && !(out && isIncReg pc 0)

private theorem iterate_one (f : V→V) [Language.DefinableFunction₁ ℒₒᵣ f] (x : V) :
    iterate f 1 x = f x := by simpa using iterate_succ f (0:V) x

private theorem field_raw (p i : Nat) (c z a : Bool) (v : Nat→V) (tail : V) :
    prefixRay v tail (field p c z a i) =
      bit false (rep true (count (coldFor p c a) (regsFor p c z a v) i) tail) := by
  cases he : Direct181Source.Raw.program p with
  | inl ins =>
    rcases ins with ⟨r,n⟩
    by_cases zero : i=0 <;> by_cases eq : r=i <;> by_cases rz : r=0
    all_goals cases c <;> cases z <;> cases a <;>
      simp [field,he,coldFor,regsFor,isIncReg,isDecReg,eq,zero,rz,count,prefix_append,prefixRay,
        prefix_digits,rep,←add_assoc,iterate_one,iterate_succ,show (2:V)=1+1 by norm_num,show (3:V)=1+1+1 by norm_num] <;> try subst_vars <;> simp_all [prefixRay,rep,iterate_succ,iterate_one]
  | inr ins =>
    cases ins with
    | inr n =>
      by_cases zero : i=0
      all_goals cases c <;> cases z <;> cases a <;>
        simp [field,he,coldFor,regsFor,isIncReg,isDecReg,zero,count,prefix_append,prefixRay,
          prefix_digits,rep,←add_assoc,iterate_one,iterate_succ,show (2:V)=1+1 by norm_num]
    | inl ins =>
      rcases ins with ⟨r,m,n,h⟩
      by_cases zero : i=0 <;> by_cases eq : r=i <;> by_cases rz : r=0
      all_goals cases c <;> cases z <;> cases a <;>
        simp [field,he,coldFor,regsFor,isIncReg,isDecReg,eq,zero,rz,count,prefix_append,prefixRay,
          prefix_digits,rep,←add_assoc,iterate_one,iterate_succ,show (2:V)=1+1 by norm_num,show (3:V)=1+1+1 by norm_num] <;> try subst_vars <;>
          simp_all [prefixRay,rep,iterate_succ,iterate_one,eq_comm]

private theorem file_raw (p : Nat) (ks : List Nat) (c z a : Bool) (v : Nat→V) (tail : V) :
    prefixRay v tail (ks.flatMap (field p c z a)) =
      file ks (coldFor p c a) (regsFor p c z a v) tail := by
  induction ks with
  | nil => rfl
  | cons i ks ih => rw [List.flatMap_cons,prefix_append,ih,field_raw]; rfl

theorem frame_correct (p : Nat) (c z a : Bool) (dg ds : Nat) (v : Nat→V) :
    (signedFrame p c z a dg ds).val v =
    canonical (if a then nextPc p z else p) (coldFor p c a) (regsFor p c z a v) (v 9 + (dg:V)) (v 10 + (ds:V)) := by
  unfold signedFrame Config.val rays canonical
  simp only [word_eq_prefix,prefix_append,prefixRay,prefix_literal,prefix_digits,prefix_pairs,zeros_end,file_raw]
  simp only [bit,Bool.toNat_true,Nat.cast_one,mul_zero,zero_add,Nat.cast_add,Nat.cast_ofNat]
  congr 1
  congr 1
  rw [←rep_add,←rep_add,←pairs_add]
  simp only [add_assoc,add_left_comm,add_comm]

#print axioms frame_correct
end NF181PA.Symbolic
