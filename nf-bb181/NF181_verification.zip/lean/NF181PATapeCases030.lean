import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w960_0 : checkWitness 960 false false 8862 = true := by decide +kernel
private theorem w960_2 : checkWitness 960 true false 8858 = true := by decide +kernel
private theorem cases960 : checkFour 960 (8862,0,8858,0) = true := by
  simp only [checkFour, w960_0, w960_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one960 : Coverage 960 961 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases960)
private theorem w961_0 : checkWitness 961 false false 86 = true := by decide +kernel
private theorem w961_2 : checkWitness 961 true false 86 = true := by decide +kernel
private theorem cases961 : checkFour 961 (86,0,86,0) = true := by
  simp only [checkFour, w961_0, w961_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one961 : Coverage 961 962 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases961)
private theorem w962_0 : checkWitness 962 false false 646 = true := by decide +kernel
private theorem w962_1 : checkWitness 962 false true 4734 = true := by decide +kernel
private theorem w962_2 : checkWitness 962 true false 637 = true := by decide +kernel
private theorem w962_3 : checkWitness 962 true true 4725 = true := by decide +kernel
private theorem cases962 : checkFour 962 (646,4734,637,4725) = true := by
  simp only [checkFour, w962_0, w962_1, w962_2, w962_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one962 : Coverage 962 963 := checkList_sound (ws:=[(646,4734,637,4725)]) (by simpa only [checkList, Bool.and_true] using cases962)
private theorem w963_0 : checkWitness 963 false false 8881 = true := by decide +kernel
private theorem w963_2 : checkWitness 963 true false 8877 = true := by decide +kernel
private theorem cases963 : checkFour 963 (8881,0,8877,0) = true := by
  simp only [checkFour, w963_0, w963_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one963 : Coverage 963 964 := checkList_sound (ws:=[(8881,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases963)
private theorem w964_0 : checkWitness 964 false false 76 = true := by decide +kernel
private theorem w964_2 : checkWitness 964 true false 76 = true := by decide +kernel
private theorem cases964 : checkFour 964 (76,0,76,0) = true := by
  simp only [checkFour, w964_0, w964_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one964 : Coverage 964 965 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases964)
private theorem w965_0 : checkWitness 965 false false 498 = true := by decide +kernel
private theorem w965_1 : checkWitness 965 false true 4594 = true := by decide +kernel
private theorem w965_2 : checkWitness 965 true false 498 = true := by decide +kernel
private theorem w965_3 : checkWitness 965 true true 4594 = true := by decide +kernel
private theorem cases965 : checkFour 965 (498,4594,498,4594) = true := by
  simp only [checkFour, w965_0, w965_1, w965_2, w965_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one965 : Coverage 965 966 := checkList_sound (ws:=[(498,4594,498,4594)]) (by simpa only [checkList, Bool.and_true] using cases965)
private theorem w966_0 : checkWitness 966 false false 8893 = true := by decide +kernel
private theorem w966_2 : checkWitness 966 true false 8889 = true := by decide +kernel
private theorem cases966 : checkFour 966 (8893,0,8889,0) = true := by
  simp only [checkFour, w966_0, w966_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one966 : Coverage 966 967 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases966)
private theorem w967_0 : checkWitness 967 false false 624 = true := by decide +kernel
private theorem w967_1 : checkWitness 967 false true 4720 = true := by decide +kernel
private theorem w967_2 : checkWitness 967 true false 615 = true := by decide +kernel
private theorem w967_3 : checkWitness 967 true true 4711 = true := by decide +kernel
private theorem cases967 : checkFour 967 (624,4720,615,4711) = true := by
  simp only [checkFour, w967_0, w967_1, w967_2, w967_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one967 : Coverage 967 968 := checkList_sound (ws:=[(624,4720,615,4711)]) (by simpa only [checkList, Bool.and_true] using cases967)
private theorem w968_0 : checkWitness 968 false false 178 = true := by decide +kernel
private theorem w968_2 : checkWitness 968 true false 178 = true := by decide +kernel
private theorem cases968 : checkFour 968 (178,0,178,0) = true := by
  simp only [checkFour, w968_0, w968_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one968 : Coverage 968 969 := checkList_sound (ws:=[(178,0,178,0)]) (by simpa only [checkList, Bool.and_true] using cases968)
private theorem w969_0 : checkWitness 969 false false 579 = true := by decide +kernel
private theorem w969_1 : checkWitness 969 false true 4667 = true := by decide +kernel
private theorem w969_2 : checkWitness 969 true false 579 = true := by decide +kernel
private theorem w969_3 : checkWitness 969 true true 4667 = true := by decide +kernel
private theorem cases969 : checkFour 969 (579,4667,579,4667) = true := by
  simp only [checkFour, w969_0, w969_1, w969_2, w969_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one969 : Coverage 969 970 := checkList_sound (ws:=[(579,4667,579,4667)]) (by simpa only [checkList, Bool.and_true] using cases969)
private theorem w970_0 : checkWitness 970 false false 8908 = true := by decide +kernel
private theorem w970_2 : checkWitness 970 true false 8899 = true := by decide +kernel
private theorem cases970 : checkFour 970 (8908,0,8899,0) = true := by
  simp only [checkFour, w970_0, w970_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one970 : Coverage 970 971 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases970)
private theorem w971_0 : checkWitness 971 false false 82 = true := by decide +kernel
private theorem w971_2 : checkWitness 971 true false 82 = true := by decide +kernel
private theorem cases971 : checkFour 971 (82,0,82,0) = true := by
  simp only [checkFour, w971_0, w971_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one971 : Coverage 971 972 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases971)
private theorem w972_0 : checkWitness 972 false false 74 = true := by decide +kernel
private theorem w972_2 : checkWitness 972 true false 74 = true := by decide +kernel
private theorem cases972 : checkFour 972 (74,0,74,0) = true := by
  simp only [checkFour, w972_0, w972_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one972 : Coverage 972 973 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases972)
private theorem w973_0 : checkWitness 973 false false 585 = true := by decide +kernel
private theorem w973_1 : checkWitness 973 false true 4677 = true := by decide +kernel
private theorem w973_2 : checkWitness 973 true false 585 = true := by decide +kernel
private theorem w973_3 : checkWitness 973 true true 4677 = true := by decide +kernel
private theorem cases973 : checkFour 973 (585,4677,585,4677) = true := by
  simp only [checkFour, w973_0, w973_1, w973_2, w973_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one973 : Coverage 973 974 := checkList_sound (ws:=[(585,4677,585,4677)]) (by simpa only [checkList, Bool.and_true] using cases973)
private theorem w974_0 : checkWitness 974 false false 8846 = true := by decide +kernel
private theorem w974_2 : checkWitness 974 true false 8842 = true := by decide +kernel
private theorem cases974 : checkFour 974 (8846,0,8842,0) = true := by
  simp only [checkFour, w974_0, w974_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one974 : Coverage 974 975 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases974)
private theorem w975_0 : checkWitness 975 false false 74 = true := by decide +kernel
private theorem w975_2 : checkWitness 975 true false 74 = true := by decide +kernel
private theorem cases975 : checkFour 975 (74,0,74,0) = true := by
  simp only [checkFour, w975_0, w975_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one975 : Coverage 975 976 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases975)
private theorem w976_0 : checkWitness 976 false false 540 = true := by decide +kernel
private theorem w976_1 : checkWitness 976 false true 4636 = true := by decide +kernel
private theorem w976_2 : checkWitness 976 true false 540 = true := by decide +kernel
private theorem w976_3 : checkWitness 976 true true 4636 = true := by decide +kernel
private theorem cases976 : checkFour 976 (540,4636,540,4636) = true := by
  simp only [checkFour, w976_0, w976_1, w976_2, w976_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one976 : Coverage 976 977 := checkList_sound (ws:=[(540,4636,540,4636)]) (by simpa only [checkList, Bool.and_true] using cases976)
private theorem w977_0 : checkWitness 977 false false 8881 = true := by decide +kernel
private theorem w977_2 : checkWitness 977 true false 8877 = true := by decide +kernel
private theorem cases977 : checkFour 977 (8881,0,8877,0) = true := by
  simp only [checkFour, w977_0, w977_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one977 : Coverage 977 978 := checkList_sound (ws:=[(8881,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases977)
private theorem w978_0 : checkWitness 978 false false 8916 = true := by decide +kernel
private theorem w978_2 : checkWitness 978 true false 8907 = true := by decide +kernel
private theorem cases978 : checkFour 978 (8916,0,8907,0) = true := by
  simp only [checkFour, w978_0, w978_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one978 : Coverage 978 979 := checkList_sound (ws:=[(8916,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases978)
private theorem w979_0 : checkWitness 979 false false 92 = true := by decide +kernel
private theorem w979_2 : checkWitness 979 true false 92 = true := by decide +kernel
private theorem cases979 : checkFour 979 (92,0,92,0) = true := by
  simp only [checkFour, w979_0, w979_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one979 : Coverage 979 980 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases979)
private theorem w980_0 : checkWitness 980 false false 628 = true := by decide +kernel
private theorem w980_1 : checkWitness 980 false true 4720 = true := by decide +kernel
private theorem w980_2 : checkWitness 980 true false 619 = true := by decide +kernel
private theorem w980_3 : checkWitness 980 true true 4711 = true := by decide +kernel
private theorem cases980 : checkFour 980 (628,4720,619,4711) = true := by
  simp only [checkFour, w980_0, w980_1, w980_2, w980_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one980 : Coverage 980 981 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases980)
private theorem w981_0 : checkWitness 981 false false 8877 = true := by decide +kernel
private theorem w981_2 : checkWitness 981 true false 8873 = true := by decide +kernel
private theorem cases981 : checkFour 981 (8877,0,8873,0) = true := by
  simp only [checkFour, w981_0, w981_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one981 : Coverage 981 982 := checkList_sound (ws:=[(8877,0,8873,0)]) (by simpa only [checkList, Bool.and_true] using cases981)
private theorem w982_0 : checkWitness 982 false false 622 = true := by decide +kernel
private theorem w982_1 : checkWitness 982 false true 4714 = true := by decide +kernel
private theorem w982_2 : checkWitness 982 true false 613 = true := by decide +kernel
private theorem w982_3 : checkWitness 982 true true 4705 = true := by decide +kernel
private theorem cases982 : checkFour 982 (622,4714,613,4705) = true := by
  simp only [checkFour, w982_0, w982_1, w982_2, w982_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one982 : Coverage 982 983 := checkList_sound (ws:=[(622,4714,613,4705)]) (by simpa only [checkList, Bool.and_true] using cases982)
private theorem w983_0 : checkWitness 983 false false 8846 = true := by decide +kernel
private theorem w983_2 : checkWitness 983 true false 8842 = true := by decide +kernel
private theorem cases983 : checkFour 983 (8846,0,8842,0) = true := by
  simp only [checkFour, w983_0, w983_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one983 : Coverage 983 984 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases983)
private theorem w984_0 : checkWitness 984 false false 80 = true := by decide +kernel
private theorem w984_2 : checkWitness 984 true false 80 = true := by decide +kernel
private theorem cases984 : checkFour 984 (80,0,80,0) = true := by
  simp only [checkFour, w984_0, w984_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one984 : Coverage 984 985 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases984)
private theorem w985_0 : checkWitness 985 false false 72 = true := by decide +kernel
private theorem w985_2 : checkWitness 985 true false 72 = true := by decide +kernel
private theorem cases985 : checkFour 985 (72,0,72,0) = true := by
  simp only [checkFour, w985_0, w985_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one985 : Coverage 985 986 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases985)
private theorem w986_0 : checkWitness 986 false false 589 = true := by decide +kernel
private theorem w986_1 : checkWitness 986 false true 4677 = true := by decide +kernel
private theorem w986_2 : checkWitness 986 true false 589 = true := by decide +kernel
private theorem w986_3 : checkWitness 986 true true 4677 = true := by decide +kernel
private theorem cases986 : checkFour 986 (589,4677,589,4677) = true := by
  simp only [checkFour, w986_0, w986_1, w986_2, w986_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one986 : Coverage 986 987 := checkList_sound (ws:=[(589,4677,589,4677)]) (by simpa only [checkList, Bool.and_true] using cases986)
private theorem w987_0 : checkWitness 987 false false 8862 = true := by decide +kernel
private theorem w987_2 : checkWitness 987 true false 8858 = true := by decide +kernel
private theorem cases987 : checkFour 987 (8862,0,8858,0) = true := by
  simp only [checkFour, w987_0, w987_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one987 : Coverage 987 988 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases987)
private theorem w988_0 : checkWitness 988 false false 8858 = true := by decide +kernel
private theorem w988_2 : checkWitness 988 true false 8854 = true := by decide +kernel
private theorem cases988 : checkFour 988 (8858,0,8854,0) = true := by
  simp only [checkFour, w988_0, w988_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one988 : Coverage 988 989 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases988)
private theorem w989_0 : checkWitness 989 false false 86 = true := by decide +kernel
private theorem w989_2 : checkWitness 989 true false 86 = true := by decide +kernel
private theorem cases989 : checkFour 989 (86,0,86,0) = true := by
  simp only [checkFour, w989_0, w989_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one989 : Coverage 989 990 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases989)
private theorem w990_0 : checkWitness 990 false false 8874 = true := by decide +kernel
private theorem w990_2 : checkWitness 990 true false 8870 = true := by decide +kernel
private theorem cases990 : checkFour 990 (8874,0,8870,0) = true := by
  simp only [checkFour, w990_0, w990_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one990 : Coverage 990 991 := checkList_sound (ws:=[(8874,0,8870,0)]) (by simpa only [checkList, Bool.and_true] using cases990)
private theorem w991_0 : checkWitness 991 false false 520 = true := by decide +kernel
private theorem w991_1 : checkWitness 991 false true 4616 = true := by decide +kernel
private theorem w991_2 : checkWitness 991 true false 520 = true := by decide +kernel
private theorem w991_3 : checkWitness 991 true true 4616 = true := by decide +kernel
private theorem cases991 : checkFour 991 (520,4616,520,4616) = true := by
  simp only [checkFour, w991_0, w991_1, w991_2, w991_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one991 : Coverage 991 992 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases991)
theorem cover0960 : Coverage 960 992 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one960 one961) (Coverage.join one962 one963)) (Coverage.join (Coverage.join one964 one965) (Coverage.join one966 one967))) (Coverage.join (Coverage.join (Coverage.join one968 one969) (Coverage.join one970 one971)) (Coverage.join (Coverage.join one972 one973) (Coverage.join one974 one975)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one976 one977) (Coverage.join one978 one979)) (Coverage.join (Coverage.join one980 one981) (Coverage.join one982 one983))) (Coverage.join (Coverage.join (Coverage.join one984 one985) (Coverage.join one986 one987)) (Coverage.join (Coverage.join one988 one989) (Coverage.join one990 one991)))))
end NF181PA.Symbolic
