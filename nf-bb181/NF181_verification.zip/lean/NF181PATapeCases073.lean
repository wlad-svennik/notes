import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2336_0 : checkWitness 2336 false false 70 = true := by decide +kernel
private theorem w2336_2 : checkWitness 2336 true false 70 = true := by decide +kernel
private theorem cases2336 : checkFour 2336 (70,0,70,0) = true := by
  simp only [checkFour, w2336_0, w2336_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2336 : Coverage 2336 2337 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2336)
private theorem w2337_0 : checkWitness 2337 false false 62 = true := by decide +kernel
private theorem w2337_2 : checkWitness 2337 true false 62 = true := by decide +kernel
private theorem cases2337 : checkFour 2337 (62,0,62,0) = true := by
  simp only [checkFour, w2337_0, w2337_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2337 : Coverage 2337 2338 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2337)
private theorem w2338_0 : checkWitness 2338 false false 609 = true := by decide +kernel
private theorem w2338_1 : checkWitness 2338 false true 4701 = true := by decide +kernel
private theorem w2338_2 : checkWitness 2338 true false 609 = true := by decide +kernel
private theorem w2338_3 : checkWitness 2338 true true 4701 = true := by decide +kernel
private theorem cases2338 : checkFour 2338 (609,4701,609,4701) = true := by
  simp only [checkFour, w2338_0, w2338_1, w2338_2, w2338_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2338 : Coverage 2338 2339 := checkList_sound (ws:=[(609,4701,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases2338)
private theorem w2339_0 : checkWitness 2339 false false 8870 = true := by decide +kernel
private theorem w2339_2 : checkWitness 2339 true false 8866 = true := by decide +kernel
private theorem cases2339 : checkFour 2339 (8870,0,8866,0) = true := by
  simp only [checkFour, w2339_0, w2339_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2339 : Coverage 2339 2340 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases2339)
private theorem w2340_0 : checkWitness 2340 false false 62 = true := by decide +kernel
private theorem w2340_2 : checkWitness 2340 true false 62 = true := by decide +kernel
private theorem cases2340 : checkFour 2340 (62,0,62,0) = true := by
  simp only [checkFour, w2340_0, w2340_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2340 : Coverage 2340 2341 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2340)
private theorem w2341_0 : checkWitness 2341 false false 564 = true := by decide +kernel
private theorem w2341_1 : checkWitness 2341 false true 4660 = true := by decide +kernel
private theorem w2341_2 : checkWitness 2341 true false 564 = true := by decide +kernel
private theorem w2341_3 : checkWitness 2341 true true 4660 = true := by decide +kernel
private theorem cases2341 : checkFour 2341 (564,4660,564,4660) = true := by
  simp only [checkFour, w2341_0, w2341_1, w2341_2, w2341_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2341 : Coverage 2341 2342 := checkList_sound (ws:=[(564,4660,564,4660)]) (by simpa only [checkList, Bool.and_true] using cases2341)
private theorem w2342_0 : checkWitness 2342 false false 8905 = true := by decide +kernel
private theorem w2342_2 : checkWitness 2342 true false 8901 = true := by decide +kernel
private theorem cases2342 : checkFour 2342 (8905,0,8901,0) = true := by
  simp only [checkFour, w2342_0, w2342_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2342 : Coverage 2342 2343 := checkList_sound (ws:=[(8905,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases2342)
private theorem w2343_0 : checkWitness 2343 false false 8940 = true := by decide +kernel
private theorem w2343_2 : checkWitness 2343 true false 8931 = true := by decide +kernel
private theorem cases2343 : checkFour 2343 (8940,0,8931,0) = true := by
  simp only [checkFour, w2343_0, w2343_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2343 : Coverage 2343 2344 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases2343)
private theorem w2344_0 : checkWitness 2344 false false 80 = true := by decide +kernel
private theorem w2344_2 : checkWitness 2344 true false 80 = true := by decide +kernel
private theorem cases2344 : checkFour 2344 (80,0,80,0) = true := by
  simp only [checkFour, w2344_0, w2344_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2344 : Coverage 2344 2345 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2344)
private theorem w2345_0 : checkWitness 2345 false false 652 = true := by decide +kernel
private theorem w2345_1 : checkWitness 2345 false true 4744 = true := by decide +kernel
private theorem w2345_2 : checkWitness 2345 true false 643 = true := by decide +kernel
private theorem w2345_3 : checkWitness 2345 true true 4735 = true := by decide +kernel
private theorem cases2345 : checkFour 2345 (652,4744,643,4735) = true := by
  simp only [checkFour, w2345_0, w2345_1, w2345_2, w2345_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2345 : Coverage 2345 2346 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases2345)
private theorem w2346_0 : checkWitness 2346 false false 8901 = true := by decide +kernel
private theorem w2346_2 : checkWitness 2346 true false 8897 = true := by decide +kernel
private theorem cases2346 : checkFour 2346 (8901,0,8897,0) = true := by
  simp only [checkFour, w2346_0, w2346_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2346 : Coverage 2346 2347 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases2346)
private theorem w2347_0 : checkWitness 2347 false false 646 = true := by decide +kernel
private theorem w2347_1 : checkWitness 2347 false true 4738 = true := by decide +kernel
private theorem w2347_2 : checkWitness 2347 true false 637 = true := by decide +kernel
private theorem w2347_3 : checkWitness 2347 true true 4729 = true := by decide +kernel
private theorem cases2347 : checkFour 2347 (646,4738,637,4729) = true := by
  simp only [checkFour, w2347_0, w2347_1, w2347_2, w2347_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2347 : Coverage 2347 2348 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases2347)
private theorem w2348_0 : checkWitness 2348 false false 8870 = true := by decide +kernel
private theorem w2348_2 : checkWitness 2348 true false 8866 = true := by decide +kernel
private theorem cases2348 : checkFour 2348 (8870,0,8866,0) = true := by
  simp only [checkFour, w2348_0, w2348_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2348 : Coverage 2348 2349 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases2348)
private theorem w2349_0 : checkWitness 2349 false false 68 = true := by decide +kernel
private theorem w2349_2 : checkWitness 2349 true false 68 = true := by decide +kernel
private theorem cases2349 : checkFour 2349 (68,0,68,0) = true := by
  simp only [checkFour, w2349_0, w2349_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2349 : Coverage 2349 2350 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2349)
private theorem w2350_0 : checkWitness 2350 false false 60 = true := by decide +kernel
private theorem w2350_2 : checkWitness 2350 true false 60 = true := by decide +kernel
private theorem cases2350 : checkFour 2350 (60,0,60,0) = true := by
  simp only [checkFour, w2350_0, w2350_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2350 : Coverage 2350 2351 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2350)
private theorem w2351_0 : checkWitness 2351 false false 633 = true := by decide +kernel
private theorem w2351_1 : checkWitness 2351 false true 4701 = true := by decide +kernel
private theorem w2351_2 : checkWitness 2351 true false 633 = true := by decide +kernel
private theorem w2351_3 : checkWitness 2351 true true 4701 = true := by decide +kernel
private theorem cases2351 : checkFour 2351 (633,4701,633,4701) = true := by
  simp only [checkFour, w2351_0, w2351_1, w2351_2, w2351_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2351 : Coverage 2351 2352 := checkList_sound (ws:=[(633,4701,633,4701)]) (by simpa only [checkList, Bool.and_true] using cases2351)
private theorem w2352_0 : checkWitness 2352 false false 8886 = true := by decide +kernel
private theorem w2352_2 : checkWitness 2352 true false 8882 = true := by decide +kernel
private theorem cases2352 : checkFour 2352 (8886,0,8882,0) = true := by
  simp only [checkFour, w2352_0, w2352_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2352 : Coverage 2352 2353 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases2352)
private theorem w2353_0 : checkWitness 2353 false false 8882 = true := by decide +kernel
private theorem w2353_2 : checkWitness 2353 true false 8878 = true := by decide +kernel
private theorem cases2353 : checkFour 2353 (8882,0,8878,0) = true := by
  simp only [checkFour, w2353_0, w2353_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2353 : Coverage 2353 2354 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases2353)
private theorem w2354_0 : checkWitness 2354 false false 74 = true := by decide +kernel
private theorem w2354_2 : checkWitness 2354 true false 74 = true := by decide +kernel
private theorem cases2354 : checkFour 2354 (74,0,74,0) = true := by
  simp only [checkFour, w2354_0, w2354_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2354 : Coverage 2354 2355 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2354)
private theorem w2355_0 : checkWitness 2355 false false 562 = true := by decide +kernel
private theorem w2355_1 : checkWitness 2355 false true 4658 = true := by decide +kernel
private theorem w2355_2 : checkWitness 2355 true false 562 = true := by decide +kernel
private theorem w2355_3 : checkWitness 2355 true true 4658 = true := by decide +kernel
private theorem cases2355 : checkFour 2355 (562,4658,562,4658) = true := by
  simp only [checkFour, w2355_0, w2355_1, w2355_2, w2355_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2355 : Coverage 2355 2356 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases2355)
private theorem w2356_0 : checkWitness 2356 false false 8978 = true := by decide +kernel
private theorem w2356_2 : checkWitness 2356 true false 8969 = true := by decide +kernel
private theorem cases2356 : checkFour 2356 (8978,0,8969,0) = true := by
  simp only [checkFour, w2356_0, w2356_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2356 : Coverage 2356 2357 := checkList_sound (ws:=[(8978,0,8969,0)]) (by simpa only [checkList, Bool.and_true] using cases2356)
private theorem w2357_0 : checkWitness 2357 false false 62 = true := by decide +kernel
private theorem w2357_2 : checkWitness 2357 true false 62 = true := by decide +kernel
private theorem cases2357 : checkFour 2357 (62,0,62,0) = true := by
  simp only [checkFour, w2357_0, w2357_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2357 : Coverage 2357 2358 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2357)
private theorem w2358_0 : checkWitness 2358 false false 560 = true := by decide +kernel
private theorem w2358_1 : checkWitness 2358 false true 4656 = true := by decide +kernel
private theorem w2358_2 : checkWitness 2358 true false 560 = true := by decide +kernel
private theorem w2358_3 : checkWitness 2358 true true 4656 = true := by decide +kernel
private theorem cases2358 : checkFour 2358 (560,4656,560,4656) = true := by
  simp only [checkFour, w2358_0, w2358_1, w2358_2, w2358_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2358 : Coverage 2358 2359 := checkList_sound (ws:=[(560,4656,560,4656)]) (by simpa only [checkList, Bool.and_true] using cases2358)
private theorem w2359_0 : checkWitness 2359 false false 8918 = true := by decide +kernel
private theorem w2359_2 : checkWitness 2359 true false 8914 = true := by decide +kernel
private theorem cases2359 : checkFour 2359 (8918,0,8914,0) = true := by
  simp only [checkFour, w2359_0, w2359_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2359 : Coverage 2359 2360 := checkList_sound (ws:=[(8918,0,8914,0)]) (by simpa only [checkList, Bool.and_true] using cases2359)
private theorem w2360_0 : checkWitness 2360 false false 64 = true := by decide +kernel
private theorem w2360_2 : checkWitness 2360 true false 64 = true := by decide +kernel
private theorem cases2360 : checkFour 2360 (64,0,64,0) = true := by
  simp only [checkFour, w2360_0, w2360_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2360 : Coverage 2360 2361 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2360)
private theorem w2361_0 : checkWitness 2361 false false 598 = true := by decide +kernel
private theorem w2361_1 : checkWitness 2361 false true 4694 = true := by decide +kernel
private theorem w2361_2 : checkWitness 2361 true false 598 = true := by decide +kernel
private theorem w2361_3 : checkWitness 2361 true true 4694 = true := by decide +kernel
private theorem cases2361 : checkFour 2361 (598,4694,598,4694) = true := by
  simp only [checkFour, w2361_0, w2361_1, w2361_2, w2361_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2361 : Coverage 2361 2362 := checkList_sound (ws:=[(598,4694,598,4694)]) (by simpa only [checkList, Bool.and_true] using cases2361)
private theorem w2362_0 : checkWitness 2362 false false 8939 = true := by decide +kernel
private theorem w2362_2 : checkWitness 2362 true false 8935 = true := by decide +kernel
private theorem cases2362 : checkFour 2362 (8939,0,8935,0) = true := by
  simp only [checkFour, w2362_0, w2362_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2362 : Coverage 2362 2363 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2362)
private theorem w2363_0 : checkWitness 2363 false false 8974 = true := by decide +kernel
private theorem w2363_2 : checkWitness 2363 true false 8965 = true := by decide +kernel
private theorem cases2363 : checkFour 2363 (8974,0,8965,0) = true := by
  simp only [checkFour, w2363_0, w2363_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2363 : Coverage 2363 2364 := checkList_sound (ws:=[(8974,0,8965,0)]) (by simpa only [checkList, Bool.and_true] using cases2363)
private theorem w2364_0 : checkWitness 2364 false false 88 = true := by decide +kernel
private theorem w2364_2 : checkWitness 2364 true false 88 = true := by decide +kernel
private theorem cases2364 : checkFour 2364 (88,0,88,0) = true := by
  simp only [checkFour, w2364_0, w2364_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2364 : Coverage 2364 2365 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases2364)
private theorem w2365_0 : checkWitness 2365 false false 686 = true := by decide +kernel
private theorem w2365_1 : checkWitness 2365 false true 4778 = true := by decide +kernel
private theorem w2365_2 : checkWitness 2365 true false 677 = true := by decide +kernel
private theorem w2365_3 : checkWitness 2365 true true 4769 = true := by decide +kernel
private theorem cases2365 : checkFour 2365 (686,4778,677,4769) = true := by
  simp only [checkFour, w2365_0, w2365_1, w2365_2, w2365_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2365 : Coverage 2365 2366 := checkList_sound (ws:=[(686,4778,677,4769)]) (by simpa only [checkList, Bool.and_true] using cases2365)
private theorem w2366_0 : checkWitness 2366 false false 8935 = true := by decide +kernel
private theorem w2366_2 : checkWitness 2366 true false 8931 = true := by decide +kernel
private theorem cases2366 : checkFour 2366 (8935,0,8931,0) = true := by
  simp only [checkFour, w2366_0, w2366_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2366 : Coverage 2366 2367 := checkList_sound (ws:=[(8935,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases2366)
private theorem w2367_0 : checkWitness 2367 false false 680 = true := by decide +kernel
private theorem w2367_1 : checkWitness 2367 false true 4772 = true := by decide +kernel
private theorem w2367_2 : checkWitness 2367 true false 671 = true := by decide +kernel
private theorem w2367_3 : checkWitness 2367 true true 4763 = true := by decide +kernel
private theorem cases2367 : checkFour 2367 (680,4772,671,4763) = true := by
  simp only [checkFour, w2367_0, w2367_1, w2367_2, w2367_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2367 : Coverage 2367 2368 := checkList_sound (ws:=[(680,4772,671,4763)]) (by simpa only [checkList, Bool.and_true] using cases2367)
theorem cover2336 : Coverage 2336 2368 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2336 one2337) (Coverage.join one2338 one2339)) (Coverage.join (Coverage.join one2340 one2341) (Coverage.join one2342 one2343))) (Coverage.join (Coverage.join (Coverage.join one2344 one2345) (Coverage.join one2346 one2347)) (Coverage.join (Coverage.join one2348 one2349) (Coverage.join one2350 one2351)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2352 one2353) (Coverage.join one2354 one2355)) (Coverage.join (Coverage.join one2356 one2357) (Coverage.join one2358 one2359))) (Coverage.join (Coverage.join (Coverage.join one2360 one2361) (Coverage.join one2362 one2363)) (Coverage.join (Coverage.join one2364 one2365) (Coverage.join one2366 one2367)))))
end NF181PA.Symbolic
