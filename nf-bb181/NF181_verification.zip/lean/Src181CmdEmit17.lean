module
public import Src181CmdEmit16
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter545 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2621:Nat):V) f (vector n (emitAtom86 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2618 f n 0 (emitAtom86 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom86 n t s c u v y d w)):V)=(emitAtom86 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter544 f n t s c u v y d w).trans mid

theorem commandEmitAfter546 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2631:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom87 n t s c u v y d w) w)) := by
  have micro := site2621 f n (emitAtom86 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom86 n t s c u v y d w))):V)=(emitAtom87 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom86 n t s c u v y d w))):V)=(0+(emitAtom87 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter545 f n t s c u v y d w).trans mid

theorem commandEmitAfter547 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2634:Nat):V) f (vector n 0 (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2631 f n 0 0 c (d+u) (v+y) 0 (emitAtom87 n t s c u v y d w) w
  have d2 : ((0+(emitAtom87 n t s c u v y d w)):V)=(emitAtom87 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter546 f n t s c u v y d w).trans mid

theorem commandEmitAfter548 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2638:Nat):V) f (vector n (d+u) (emitAtom87 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2634 f n 0 (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter547 f n t s c u v y d w).trans mid

theorem commandEmitAfter549 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2641:Nat):V) f (vector n (d+u) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2638 f n (d+u) (emitAtom87 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter548 f n t s c u v y d w).trans mid

theorem commandEmitAfter550 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2644:Nat):V) f (vector n 0 (emitAtom87 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2641 f n (d+u) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter549 f n t s c u v y d w).trans mid

theorem commandEmitAfter551 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2647:Nat):V) f (vector n (emitAtom87 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2644 f n 0 (emitAtom87 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom87 n t s c u v y d w)):V)=(emitAtom87 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter550 f n t s c u v y d w).trans mid

theorem commandEmitAfter552 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2657:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom88 n t s c u v y d w) w)) := by
  have micro := site2647 f n (emitAtom87 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom87 n t s c u v y d w))):V)=(emitAtom88 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom87 n t s c u v y d w))):V)=(0+(emitAtom88 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter551 f n t s c u v y d w).trans mid

theorem commandEmitAfter553 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2660:Nat):V) f (vector n 0 (emitAtom88 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2657 f n 0 0 c (d+u) (v+y) 0 (emitAtom88 n t s c u v y d w) w
  have d2 : ((0+(emitAtom88 n t s c u v y d w)):V)=(emitAtom88 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter552 f n t s c u v y d w).trans mid

theorem commandEmitAfter554 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2664:Nat):V) f (vector n (v+y) (emitAtom88 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2660 f n 0 (emitAtom88 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter553 f n t s c u v y d w).trans mid

theorem commandEmitAfter555 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2667:Nat):V) f (vector n (v+y) (emitAtom88 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2664 f n (v+y) (emitAtom88 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter554 f n t s c u v y d w).trans mid

theorem commandEmitAfter556 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2675:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom87 n t s c u v y d w) w)) := by
  have micro := site2667 f n (v+y) (emitAtom88 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom88 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom88 n t s c u v y d w)):V)=(0+(emitAtom88 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom88 n t s c u v y d w))):V)=left (emitAtom88 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom87 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom88 n t s c u v y d w))):V)=(emitAtom87 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom88 n t s c u v y d w)):V)=(0+(emitAtom88 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom88 n t s c u v y d w))):V)=right (emitAtom88 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom87 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter555 f n t s c u v y d w).trans mid

theorem commandEmitAfter557 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2678:Nat):V) f (vector n (v+y) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2675 f n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom87 n t s c u v y d w) w
  have d2 : ((0+(emitAtom87 n t s c u v y d w)):V)=(emitAtom87 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter556 f n t s c u v y d w).trans mid

theorem commandEmitAfter558 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2688:Nat):V) f (vector n 0 (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w)) := by
  have micro := site2678 f n (v+y) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (v+y))):V)=(emitAtom24 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (v+y))):V)=(0+(emitAtom24 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter557 f n t s c u v y d w).trans mid

theorem commandEmitAfter559 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2692:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2688 f n 0 (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=(0+((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter558 f n t s c u v y d w).trans mid

theorem commandEmitAfter560 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2693:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2692 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter559 f n t s c u v y d w).trans mid

theorem commandEmitAfter561 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2694:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2693 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1)+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter560 f n t s c u v y d w).trans mid

theorem commandEmitAfter562 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2702:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) 0 c (d+u) (v+y) (d+u) (emitAtom86 n t s c u v y d w) w)) := by
  have micro := site2694 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) (emitAtom87 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom87 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom87 n t s c u v y d w)):V)=(0+(emitAtom87 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom87 n t s c u v y d w))):V)=left (emitAtom87 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom86 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom87 n t s c u v y d w))):V)=(emitAtom86 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom87 n t s c u v y d w)):V)=(0+(emitAtom87 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom87 n t s c u v y d w))):V)=right (emitAtom87 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom86 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter561 f n t s c u v y d w).trans mid

theorem commandEmitAfter563 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2705:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) (emitAtom86 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2702 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) 0 c (d+u) (v+y) (d+u) (emitAtom86 n t s c u v y d w) w
  have d2 : ((0+(emitAtom86 n t s c u v y d w)):V)=(emitAtom86 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter562 f n t s c u v y d w).trans mid

theorem commandEmitAfter564 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2715:Nat):V) f (vector n 0 (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom89 n t s c u v y d w) w)) := by
  have micro := site2705 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2) (emitAtom86 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2))):V)=(emitAtom89 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+2))):V)=(0+(emitAtom89 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter563 f n t s c u v y d w).trans mid

theorem commandEmitAfter565 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2719:Nat):V) f (vector n ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)) (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2715 f n 0 (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom89 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom89 n t s c u v y d w))):V)=((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom89 n t s c u v y d w))):V)=(0+((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter564 f n t s c u v y d w).trans mid

theorem commandEmitAfter566 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2720:Nat):V) f (vector n ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1) (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2719 f n ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)) (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w))+1):V)=((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter565 f n t s c u v y d w).trans mid

theorem commandEmitAfter567 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2728:Nat):V) f (vector n ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) w)) := by
  have micro := site2720 f n ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1) (emitAtom86 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom86 n t s c u v y d w))):V)=((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom86 n t s c u v y d w)):V)=(0+(emitAtom86 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom86 n t s c u v y d w))):V)=left (emitAtom86 n t s c u v y d w))).trans (by change left (cantor ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom86 n t s c u v y d w))):V)=(emitAtom82 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom86 n t s c u v y d w)):V)=(0+(emitAtom86 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom86 n t s c u v y d w))):V)=right (emitAtom86 n t s c u v y d w))).trans (by change right (cantor ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter566 f n t s c u v y d w).trans mid

theorem commandEmitAfter568 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2731:Nat):V) f (vector n ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2728 f n ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) w
  have d2 : ((0+(emitAtom82 n t s c u v y d w)):V)=(emitAtom82 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter567 f n t s c u v y d w).trans mid

theorem commandEmitAfter569 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2741:Nat):V) f (vector n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom90 n t s c u v y d w) w)) := by
  have micro := site2731 f n ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1))):V)=(emitAtom90 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom85 n t s c u v y d w)+(emitAtom85 n t s c u v y d w)+1) ((emitAtom89 n t s c u v y d w)+(emitAtom89 n t s c u v y d w)+1))):V)=(0+(emitAtom90 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter568 f n t s c u v y d w).trans mid

theorem commandEmitAfter570 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2745:Nat):V) f (vector n ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2741 f n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom90 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom90 n t s c u v y d w))):V)=((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom90 n t s c u v y d w))):V)=(0+((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter569 f n t s c u v y d w).trans mid

theorem commandEmitAfter571 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2746:Nat):V) f (vector n ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2745 f n ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w))+1):V)=((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter570 f n t s c u v y d w).trans mid

theorem commandEmitAfter572 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2749:Nat):V) f (vector n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2746 f n ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1)):V)=((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter571 f n t s c u v y d w).trans mid

theorem commandEmitAfter573 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2752:Nat):V) f (vector n (emitAtom82 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2749 f n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom82 n t s c u v y d w)):V)=(emitAtom82 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter572 f n t s c u v y d w).trans mid

theorem commandEmitAfter574 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2762:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom91 n t s c u v y d w) w)) := by
  have micro := site2752 f n (emitAtom82 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w))):V)=(emitAtom91 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w))):V)=(0+(emitAtom91 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter573 f n t s c u v y d w).trans mid

theorem commandEmitAfter575 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2765:Nat):V) f (vector n 0 (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2762 f n 0 0 c (d+u) (v+y) 0 (emitAtom91 n t s c u v y d w) w
  have d2 : ((0+(emitAtom91 n t s c u v y d w)):V)=(emitAtom91 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter574 f n t s c u v y d w).trans mid

theorem commandEmitAfter576 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2769:Nat):V) f (vector n (d+u) (emitAtom91 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site2765 f n 0 (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter575 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
