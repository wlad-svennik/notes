import NF181PAReplay
import M6PA.Calibration.Foundation
import TrueValue
import ModelStartBound
import NF181Exact

open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.LiteralTM PA192.BusyBeaver

namespace NF181PA

/-- The standard direction uses the literal release's external NF calibration. -/
theorem runs_forever_of_con_nf (nf : Consistent 𝗡𝗙) :
    ¬Halts Direct181.Table.machine Direct181.Table.start :=
  fun stop => (consistent_iff_unprovable_bot.mp nf) (NFMachine181.halts_iff_nf_refutation.mp stop)

/-- Separately interface to the G2 premise. Its quantifier is object provability. -/
theorem no_negative_of_transfer (transfer : M6.PA.theory ⊢ (∼H181) 🡒 M6.PA.consistencySentence) :
    M6.PA.theory ⊬ ∼H181 :=
  M6.PA.unprovable_of_internal_consistency_implication _ inferInstance transfer

theorem independence_of_transfer (transfer : M6.PA.theory ⊢ (∼H181) 🡒 M6.PA.consistencySentence)
    (nf : Consistent 𝗡𝗙) :
    (M6.PA.theory ⊬ ∼H181) ∧ (M6.PA.theory ⊬ H181) ∧
    ∀ k : Nat, (M6.PA.theory ⊬ upper 181 k) ∧
       (M6.PA.theory ⊬ fixedUpper (0 : Fin 181) k) ∧ (M6.PA.theory ⊬ value 181 k) := by
  have nonhalt := runs_forever_of_con_nf nf
  have neg := no_negative_of_transfer transfer
  refine ⟨neg, ?_, ?_⟩
  · intro proof
    exact nonhalt (H181_standard.mp (models_iff.mp (models_of_provable (M:=Nat) inferInstance proof)))
  · intro k
    have noUpper : M6.PA.theory ⊬ upper 181 k := fun proof =>
      neg (pa_bound_implies_nonhalting k (fun stop => nonhalt ⟨k,stop⟩) ⨀ proof)
    exact ⟨noUpper,fun proof => noUpper (fixed_upper_implies_upper (0 : Fin 181) k ⨀ proof),
      no_value_of_no_upper noUpper⟩

theorem true_value_of_transfer (transfer : M6.PA.theory ⊢ (∼H181) 🡒 M6.PA.consistencySentence)
    (nf : Consistent 𝗡𝗙) :
    ∃ k : Nat, (Nat ⊧/![] (value 181 k)) ∧
      (M6.PA.theory ⊬ value 181 k) ∧ (M6.PA.theory ⊬ ∼(value 181 k)) := by
  obtain ⟨k,actual⟩ := exists_true_value 181
  exact ⟨k,actual,((independence_of_transfer transfer nf).2.2 k).2.2,
    true_value_unrefutable actual⟩

end NF181PA

#print axioms NF181PA.pa_no_halt_through
#print axioms NF181PA.pa_bound_implies_nonhalting
#print axioms NF181PA.pa_live_51111
#print axioms NF181PA.no_negative_of_transfer
#print axioms NF181PA.runs_forever_of_con_nf
#print axioms NF181PA.true_value_of_transfer
