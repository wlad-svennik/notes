module
public import Direct181Snapshots
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem chunk29500 : Prefix 500 snap29000 snap29500 := checked _ _ _ (by decide) (by decide)
theorem chunk30000 : Prefix 500 snap29500 snap30000 := checked _ _ _ (by decide) (by decide)
theorem chunk30500 : Prefix 500 snap30000 snap30500 := checked _ _ _ (by decide) (by decide)
theorem chunk31000 : Prefix 500 snap30500 snap31000 := checked _ _ _ (by decide) (by decide)
theorem chunk31500 : Prefix 500 snap31000 snap31500 := checked _ _ _ (by decide) (by decide)
theorem chunk32000 : Prefix 500 snap31500 snap32000 := checked _ _ _ (by decide) (by decide)
theorem chunk32500 : Prefix 500 snap32000 snap32500 := checked _ _ _ (by decide) (by decide)
theorem chunk33000 : Prefix 500 snap32500 snap33000 := checked _ _ _ (by decide) (by decide)
theorem chunk33500 : Prefix 500 snap33000 snap33500 := checked _ _ _ (by decide) (by decide)
theorem chunk34000 : Prefix 500 snap33500 snap34000 := checked _ _ _ (by decide) (by decide)
theorem chunk34500 : Prefix 500 snap34000 snap34500 := checked _ _ _ (by decide) (by decide)
theorem chunk35000 : Prefix 500 snap34500 snap35000 := checked _ _ _ (by decide) (by decide)
end Direct181.Boot
