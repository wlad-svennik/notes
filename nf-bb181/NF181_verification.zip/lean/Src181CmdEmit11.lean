module
public import Src181CmdEmit10
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter353 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1716:Nat):V) f (vector n (v+y) (emitAtom58 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1712 f n 0 (emitAtom58 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter352 f n t s c u v y d w).trans mid

theorem commandEmitAfter354 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1719:Nat):V) f (vector n (v+y) (emitAtom58 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1716 f n (v+y) (emitAtom58 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter353 f n t s c u v y d w).trans mid

theorem commandEmitAfter355 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1727:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) c (emitAtom57 n t s c u v y d w) w)) := by
  have micro := site1719 f n (v+y) (emitAtom58 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom58 n t s c u v y d w))):V)=c := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom58 n t s c u v y d w)):V)=(0+(emitAtom58 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom58 n t s c u v y d w))):V)=left (emitAtom58 n t s c u v y d w))).trans (by change left (cantor c (emitAtom57 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom58 n t s c u v y d w))):V)=(emitAtom57 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom58 n t s c u v y d w)):V)=(0+(emitAtom58 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom58 n t s c u v y d w))):V)=right (emitAtom58 n t s c u v y d w))).trans (by change right (cantor c (emitAtom57 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter354 f n t s c u v y d w).trans mid

theorem commandEmitAfter356 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1730:Nat):V) f (vector n (v+y) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1727 f n (v+y) 0 c (d+u) (v+y) c (emitAtom57 n t s c u v y d w) w
  have d2 : ((0+(emitAtom57 n t s c u v y d w)):V)=(emitAtom57 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter355 f n t s c u v y d w).trans mid

theorem commandEmitAfter357 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1740:Nat):V) f (vector n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom29 n t s c u v y d w) w)) := by
  have micro := site1730 f n (v+y) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d7 : ((0+(cantor c (v+y))):V)=(emitAtom29 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c (v+y))):V)=(0+(emitAtom29 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter356 f n t s c u v y d w).trans mid

theorem commandEmitAfter358 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1744:Nat):V) f (vector n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1740 f n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom29 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom29 n t s c u v y d w))):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom29 n t s c u v y d w))):V)=(0+((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter357 f n t s c u v y d w).trans mid

theorem commandEmitAfter359 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1745:Nat):V) f (vector n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1744 f n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w))+1):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter358 f n t s c u v y d w).trans mid

theorem commandEmitAfter360 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1748:Nat):V) f (vector n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1745 f n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1)):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter359 f n t s c u v y d w).trans mid

theorem commandEmitAfter361 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1751:Nat):V) f (vector n (emitAtom57 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1748 f n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom57 n t s c u v y d w)):V)=(emitAtom57 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter360 f n t s c u v y d w).trans mid

theorem commandEmitAfter362 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1761:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom59 n t s c u v y d w) w)) := by
  have micro := site1751 f n (emitAtom57 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w))):V)=(emitAtom59 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w))):V)=(0+(emitAtom59 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter361 f n t s c u v y d w).trans mid

theorem commandEmitAfter363 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1764:Nat):V) f (vector n 0 (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1761 f n 0 0 c (d+u) (v+y) 0 (emitAtom59 n t s c u v y d w) w
  have d2 : ((0+(emitAtom59 n t s c u v y d w)):V)=(emitAtom59 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter362 f n t s c u v y d w).trans mid

theorem commandEmitAfter364 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1768:Nat):V) f (vector n (d+u) (emitAtom59 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1764 f n 0 (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter363 f n t s c u v y d w).trans mid

theorem commandEmitAfter365 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1771:Nat):V) f (vector n (d+u) (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1768 f n (d+u) (emitAtom59 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter364 f n t s c u v y d w).trans mid

theorem commandEmitAfter366 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1774:Nat):V) f (vector n 0 (emitAtom59 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1771 f n (d+u) (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter365 f n t s c u v y d w).trans mid

theorem commandEmitAfter367 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1777:Nat):V) f (vector n (emitAtom59 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1774 f n 0 (emitAtom59 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom59 n t s c u v y d w)):V)=(emitAtom59 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter366 f n t s c u v y d w).trans mid

theorem commandEmitAfter368 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1787:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom60 n t s c u v y d w) w)) := by
  have micro := site1777 f n (emitAtom59 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom59 n t s c u v y d w))):V)=(emitAtom60 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom59 n t s c u v y d w))):V)=(0+(emitAtom60 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter367 f n t s c u v y d w).trans mid

theorem commandEmitAfter369 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1790:Nat):V) f (vector n 0 (emitAtom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1787 f n 0 0 c (d+u) (v+y) 0 (emitAtom60 n t s c u v y d w) w
  have d2 : ((0+(emitAtom60 n t s c u v y d w)):V)=(emitAtom60 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter368 f n t s c u v y d w).trans mid

theorem commandEmitAfter370 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1794:Nat):V) f (vector n (v+y) (emitAtom60 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1790 f n 0 (emitAtom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter369 f n t s c u v y d w).trans mid

theorem commandEmitAfter371 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1797:Nat):V) f (vector n (v+y) (emitAtom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1794 f n (v+y) (emitAtom60 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter370 f n t s c u v y d w).trans mid

theorem commandEmitAfter372 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1805:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom59 n t s c u v y d w) w)) := by
  have micro := site1797 f n (v+y) (emitAtom60 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom60 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom60 n t s c u v y d w)):V)=(0+(emitAtom60 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom60 n t s c u v y d w))):V)=left (emitAtom60 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom59 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom60 n t s c u v y d w))):V)=(emitAtom59 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom60 n t s c u v y d w)):V)=(0+(emitAtom60 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom60 n t s c u v y d w))):V)=right (emitAtom60 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom59 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter371 f n t s c u v y d w).trans mid

theorem commandEmitAfter373 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1808:Nat):V) f (vector n (v+y) (emitAtom59 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1805 f n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom59 n t s c u v y d w) w
  have d2 : ((0+(emitAtom59 n t s c u v y d w)):V)=(emitAtom59 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter372 f n t s c u v y d w).trans mid

theorem commandEmitAfter374 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1818:Nat):V) f (vector n 0 (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w)) := by
  have micro := site1808 f n (v+y) (emitAtom59 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (v+y))):V)=(emitAtom24 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (v+y))):V)=(0+(emitAtom24 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter373 f n t s c u v y d w).trans mid

theorem commandEmitAfter375 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1822:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1818 f n 0 (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=(0+((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter374 f n t s c u v y d w).trans mid

theorem commandEmitAfter376 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1823:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1822 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter375 f n t s c u v y d w).trans mid

theorem commandEmitAfter377 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1831:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w) w)) := by
  have micro := site1823 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom59 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom59 n t s c u v y d w))):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom59 n t s c u v y d w)):V)=(0+(emitAtom59 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom59 n t s c u v y d w))):V)=left (emitAtom59 n t s c u v y d w))).trans (by change left (cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom59 n t s c u v y d w))):V)=(emitAtom57 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom59 n t s c u v y d w)):V)=(0+(emitAtom59 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom59 n t s c u v y d w))):V)=right (emitAtom59 n t s c u v y d w))).trans (by change right (cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter376 f n t s c u v y d w).trans mid

theorem commandEmitAfter378 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1834:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1831 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w) w
  have d2 : ((0+(emitAtom57 n t s c u v y d w)):V)=(emitAtom57 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter377 f n t s c u v y d w).trans mid

theorem commandEmitAfter379 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1844:Nat):V) f (vector n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom61 n t s c u v y d w) w)) := by
  have micro := site1834 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(emitAtom61 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(0+(emitAtom61 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter378 f n t s c u v y d w).trans mid

theorem commandEmitAfter380 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1848:Nat):V) f (vector n ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1844 f n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom61 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom61 n t s c u v y d w))):V)=((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom61 n t s c u v y d w))):V)=(0+((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter379 f n t s c u v y d w).trans mid

theorem commandEmitAfter381 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1849:Nat):V) f (vector n ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1848 f n ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w))+1):V)=((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter380 f n t s c u v y d w).trans mid

theorem commandEmitAfter382 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1857:Nat):V) f (vector n ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w) w)) := by
  have micro := site1849 f n ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1) (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom57 n t s c u v y d w))):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom57 n t s c u v y d w)):V)=(0+(emitAtom57 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom57 n t s c u v y d w))):V)=left (emitAtom57 n t s c u v y d w))).trans (by change left (cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom57 n t s c u v y d w))):V)=(emitAtom55 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom57 n t s c u v y d w)):V)=(0+(emitAtom57 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom57 n t s c u v y d w))):V)=right (emitAtom57 n t s c u v y d w))).trans (by change right (cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter381 f n t s c u v y d w).trans mid

theorem commandEmitAfter383 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1860:Nat):V) f (vector n ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1857 f n ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w) w
  have d2 : ((0+(emitAtom55 n t s c u v y d w)):V)=(emitAtom55 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter382 f n t s c u v y d w).trans mid

theorem commandEmitAfter384 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1870:Nat):V) f (vector n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom62 n t s c u v y d w) w)) := by
  have micro := site1860 f n ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1))):V)=(emitAtom62 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) ((emitAtom61 n t s c u v y d w)+(emitAtom61 n t s c u v y d w)+1))):V)=(0+(emitAtom62 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter383 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
