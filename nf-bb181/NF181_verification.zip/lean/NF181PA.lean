module
public import H192Standard
public import ModelTrace
public import NF181TapeData

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM PA192.PhysicalModel

namespace NF181PA

/-- First-order PA formula over the literal 362 rows and the blank initial state. -/
def H181 : ArithmeticSentence := traceF Direct181.Table.machine Direct181.Table.start

/-- Semantics of the sentence for every PA model, including nonstandard times. -/
theorem H181_eval {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    (V ⊧/![] H181) ↔ ∃ t : V, state (rawRun Direct181.Table.machine Direct181.Table.start t) = (181 : V) :=
  traceF_iff_model_run _ _

theorem H181_standard :
    (Nat ⊧/![] H181) ↔ Halts Direct181.Table.machine Direct181.Table.start :=
  traceF_standard _ _

end NF181PA
