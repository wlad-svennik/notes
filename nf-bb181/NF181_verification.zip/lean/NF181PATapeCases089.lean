import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2848_0 : checkWitness 2848 false false 58 = true := by decide +kernel
private theorem w2848_2 : checkWitness 2848 true false 58 = true := by decide +kernel
private theorem cases2848 : checkFour 2848 (58,0,58,0) = true := by
  simp only [checkFour, w2848_0, w2848_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2848 : Coverage 2848 2849 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2848)
private theorem w2849_0 : checkWitness 2849 false false 28 = true := by decide +kernel
private theorem w2849_2 : checkWitness 2849 true false 28 = true := by decide +kernel
private theorem cases2849 : checkFour 2849 (28,0,28,0) = true := by
  simp only [checkFour, w2849_0, w2849_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2849 : Coverage 2849 2850 := checkList_sound (ws:=[(28,0,28,0)]) (by simpa only [checkList, Bool.and_true] using cases2849)
private theorem w2850_0 : checkWitness 2850 false false 598 = true := by decide +kernel
private theorem w2850_1 : checkWitness 2850 false true 4694 = true := by decide +kernel
private theorem w2850_2 : checkWitness 2850 true false 598 = true := by decide +kernel
private theorem w2850_3 : checkWitness 2850 true true 4694 = true := by decide +kernel
private theorem cases2850 : checkFour 2850 (598,4694,598,4694) = true := by
  simp only [checkFour, w2850_0, w2850_1, w2850_2, w2850_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2850 : Coverage 2850 2851 := checkList_sound (ws:=[(598,4694,598,4694)]) (by simpa only [checkList, Bool.and_true] using cases2850)
private theorem w2851_0 : checkWitness 2851 false false 8992 = true := by decide +kernel
private theorem w2851_2 : checkWitness 2851 true false 8983 = true := by decide +kernel
private theorem cases2851 : checkFour 2851 (8992,0,8983,0) = true := by
  simp only [checkFour, w2851_0, w2851_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2851 : Coverage 2851 2852 := checkList_sound (ws:=[(8992,0,8983,0)]) (by simpa only [checkList, Bool.and_true] using cases2851)
private theorem w2852_0 : checkWitness 2852 false false 40 = true := by decide +kernel
private theorem w2852_2 : checkWitness 2852 true false 40 = true := by decide +kernel
private theorem cases2852 : checkFour 2852 (40,0,40,0) = true := by
  simp only [checkFour, w2852_0, w2852_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2852 : Coverage 2852 2853 := checkList_sound (ws:=[(40,0,40,0)]) (by simpa only [checkList, Bool.and_true] using cases2852)
private theorem w2853_0 : checkWitness 2853 false false 574 = true := by decide +kernel
private theorem w2853_1 : checkWitness 2853 false true 4670 = true := by decide +kernel
private theorem w2853_2 : checkWitness 2853 true false 574 = true := by decide +kernel
private theorem w2853_3 : checkWitness 2853 true true 4670 = true := by decide +kernel
private theorem cases2853 : checkFour 2853 (574,4670,574,4670) = true := by
  simp only [checkFour, w2853_0, w2853_1, w2853_2, w2853_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2853 : Coverage 2853 2854 := checkList_sound (ws:=[(574,4670,574,4670)]) (by simpa only [checkList, Bool.and_true] using cases2853)
private theorem w2854_0 : checkWitness 2854 false false 8932 = true := by decide +kernel
private theorem w2854_2 : checkWitness 2854 true false 8928 = true := by decide +kernel
private theorem cases2854 : checkFour 2854 (8932,0,8928,0) = true := by
  simp only [checkFour, w2854_0, w2854_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2854 : Coverage 2854 2855 := checkList_sound (ws:=[(8932,0,8928,0)]) (by simpa only [checkList, Bool.and_true] using cases2854)
private theorem w2855_0 : checkWitness 2855 false false 42 = true := by decide +kernel
private theorem w2855_2 : checkWitness 2855 true false 42 = true := by decide +kernel
private theorem cases2855 : checkFour 2855 (42,0,42,0) = true := by
  simp only [checkFour, w2855_0, w2855_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2855 : Coverage 2855 2856 := checkList_sound (ws:=[(42,0,42,0)]) (by simpa only [checkList, Bool.and_true] using cases2855)
private theorem w2856_0 : checkWitness 2856 false false 612 = true := by decide +kernel
private theorem w2856_1 : checkWitness 2856 false true 4708 = true := by decide +kernel
private theorem w2856_2 : checkWitness 2856 true false 612 = true := by decide +kernel
private theorem w2856_3 : checkWitness 2856 true true 4708 = true := by decide +kernel
private theorem cases2856 : checkFour 2856 (612,4708,612,4708) = true := by
  simp only [checkFour, w2856_0, w2856_1, w2856_2, w2856_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2856 : Coverage 2856 2857 := checkList_sound (ws:=[(612,4708,612,4708)]) (by simpa only [checkList, Bool.and_true] using cases2856)
private theorem w2857_0 : checkWitness 2857 false false 8953 = true := by decide +kernel
private theorem w2857_2 : checkWitness 2857 true false 8949 = true := by decide +kernel
private theorem cases2857 : checkFour 2857 (8953,0,8949,0) = true := by
  simp only [checkFour, w2857_0, w2857_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2857 : Coverage 2857 2858 := checkList_sound (ws:=[(8953,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases2857)
private theorem w2858_0 : checkWitness 2858 false false 8988 = true := by decide +kernel
private theorem w2858_2 : checkWitness 2858 true false 8979 = true := by decide +kernel
private theorem cases2858 : checkFour 2858 (8988,0,8979,0) = true := by
  simp only [checkFour, w2858_0, w2858_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2858 : Coverage 2858 2859 := checkList_sound (ws:=[(8988,0,8979,0)]) (by simpa only [checkList, Bool.and_true] using cases2858)
private theorem w2859_0 : checkWitness 2859 false false 66 = true := by decide +kernel
private theorem w2859_2 : checkWitness 2859 true false 66 = true := by decide +kernel
private theorem cases2859 : checkFour 2859 (66,0,66,0) = true := by
  simp only [checkFour, w2859_0, w2859_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2859 : Coverage 2859 2860 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases2859)
private theorem w2860_0 : checkWitness 2860 false false 700 = true := by decide +kernel
private theorem w2860_1 : checkWitness 2860 false true 4792 = true := by decide +kernel
private theorem w2860_2 : checkWitness 2860 true false 691 = true := by decide +kernel
private theorem w2860_3 : checkWitness 2860 true true 4783 = true := by decide +kernel
private theorem cases2860 : checkFour 2860 (700,4792,691,4783) = true := by
  simp only [checkFour, w2860_0, w2860_1, w2860_2, w2860_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2860 : Coverage 2860 2861 := checkList_sound (ws:=[(700,4792,691,4783)]) (by simpa only [checkList, Bool.and_true] using cases2860)
private theorem w2861_0 : checkWitness 2861 false false 8949 = true := by decide +kernel
private theorem w2861_2 : checkWitness 2861 true false 8945 = true := by decide +kernel
private theorem cases2861 : checkFour 2861 (8949,0,8945,0) = true := by
  simp only [checkFour, w2861_0, w2861_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2861 : Coverage 2861 2862 := checkList_sound (ws:=[(8949,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2861)
private theorem w2862_0 : checkWitness 2862 false false 694 = true := by decide +kernel
private theorem w2862_1 : checkWitness 2862 false true 4786 = true := by decide +kernel
private theorem w2862_2 : checkWitness 2862 true false 685 = true := by decide +kernel
private theorem w2862_3 : checkWitness 2862 true true 4777 = true := by decide +kernel
private theorem cases2862 : checkFour 2862 (694,4786,685,4777) = true := by
  simp only [checkFour, w2862_0, w2862_1, w2862_2, w2862_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2862 : Coverage 2862 2863 := checkList_sound (ws:=[(694,4786,685,4777)]) (by simpa only [checkList, Bool.and_true] using cases2862)
private theorem w2863_0 : checkWitness 2863 false false 8918 = true := by decide +kernel
private theorem w2863_2 : checkWitness 2863 true false 8914 = true := by decide +kernel
private theorem cases2863 : checkFour 2863 (8918,0,8914,0) = true := by
  simp only [checkFour, w2863_0, w2863_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2863 : Coverage 2863 2864 := checkList_sound (ws:=[(8918,0,8914,0)]) (by simpa only [checkList, Bool.and_true] using cases2863)
private theorem w2864_0 : checkWitness 2864 false false 54 = true := by decide +kernel
private theorem w2864_2 : checkWitness 2864 true false 54 = true := by decide +kernel
private theorem cases2864 : checkFour 2864 (54,0,54,0) = true := by
  simp only [checkFour, w2864_0, w2864_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2864 : Coverage 2864 2865 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases2864)
private theorem w2865_0 : checkWitness 2865 false false 46 = true := by decide +kernel
private theorem w2865_2 : checkWitness 2865 true false 46 = true := by decide +kernel
private theorem cases2865 : checkFour 2865 (46,0,46,0) = true := by
  simp only [checkFour, w2865_0, w2865_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2865 : Coverage 2865 2866 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2865)
private theorem w2866_0 : checkWitness 2866 false false 659 = true := by decide +kernel
private theorem w2866_1 : checkWitness 2866 false true 4743 = true := by decide +kernel
private theorem w2866_2 : checkWitness 2866 true false 659 = true := by decide +kernel
private theorem w2866_3 : checkWitness 2866 true true 4743 = true := by decide +kernel
private theorem cases2866 : checkFour 2866 (659,4743,659,4743) = true := by
  simp only [checkFour, w2866_0, w2866_1, w2866_2, w2866_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2866 : Coverage 2866 2867 := checkList_sound (ws:=[(659,4743,659,4743)]) (by simpa only [checkList, Bool.and_true] using cases2866)
private theorem w2867_0 : checkWitness 2867 false false 8912 = true := by decide +kernel
private theorem w2867_2 : checkWitness 2867 true false 8908 = true := by decide +kernel
private theorem cases2867 : checkFour 2867 (8912,0,8908,0) = true := by
  simp only [checkFour, w2867_0, w2867_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2867 : Coverage 2867 2868 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases2867)
private theorem w2868_0 : checkWitness 2868 false false 46 = true := by decide +kernel
private theorem w2868_2 : checkWitness 2868 true false 46 = true := by decide +kernel
private theorem cases2868 : checkFour 2868 (46,0,46,0) = true := by
  simp only [checkFour, w2868_0, w2868_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2868 : Coverage 2868 2869 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2868)
private theorem w2869_0 : checkWitness 2869 false false 627 = true := by decide +kernel
private theorem w2869_1 : checkWitness 2869 false true 4723 = true := by decide +kernel
private theorem w2869_2 : checkWitness 2869 true false 627 = true := by decide +kernel
private theorem w2869_3 : checkWitness 2869 true true 4723 = true := by decide +kernel
private theorem cases2869 : checkFour 2869 (627,4723,627,4723) = true := by
  simp only [checkFour, w2869_0, w2869_1, w2869_2, w2869_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2869 : Coverage 2869 2870 := checkList_sound (ws:=[(627,4723,627,4723)]) (by simpa only [checkList, Bool.and_true] using cases2869)
private theorem w2870_0 : checkWitness 2870 false false 8980 = true := by decide +kernel
private theorem w2870_2 : checkWitness 2870 true false 8971 = true := by decide +kernel
private theorem cases2870 : checkFour 2870 (8980,0,8971,0) = true := by
  simp only [checkFour, w2870_0, w2870_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2870 : Coverage 2870 2871 := checkList_sound (ws:=[(8980,0,8971,0)]) (by simpa only [checkList, Bool.and_true] using cases2870)
private theorem w2871_0 : checkWitness 2871 false false 8926 = true := by decide +kernel
private theorem w2871_2 : checkWitness 2871 true false 8922 = true := by decide +kernel
private theorem cases2871 : checkFour 2871 (8926,0,8922,0) = true := by
  simp only [checkFour, w2871_0, w2871_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2871 : Coverage 2871 2872 := checkList_sound (ws:=[(8926,0,8922,0)]) (by simpa only [checkList, Bool.and_true] using cases2871)
private theorem w2872_0 : checkWitness 2872 false false 54 = true := by decide +kernel
private theorem w2872_2 : checkWitness 2872 true false 54 = true := by decide +kernel
private theorem cases2872 : checkFour 2872 (54,0,54,0) = true := by
  simp only [checkFour, w2872_0, w2872_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2872 : Coverage 2872 2873 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases2872)
private theorem w2873_0 : checkWitness 2873 false false 710 = true := by decide +kernel
private theorem w2873_1 : checkWitness 2873 false true 4798 = true := by decide +kernel
private theorem w2873_2 : checkWitness 2873 true false 701 = true := by decide +kernel
private theorem w2873_3 : checkWitness 2873 true true 4789 = true := by decide +kernel
private theorem cases2873 : checkFour 2873 (710,4798,701,4789) = true := by
  simp only [checkFour, w2873_0, w2873_1, w2873_2, w2873_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2873 : Coverage 2873 2874 := checkList_sound (ws:=[(710,4798,701,4789)]) (by simpa only [checkList, Bool.and_true] using cases2873)
private theorem w2874_0 : checkWitness 2874 false false 8945 = true := by decide +kernel
private theorem w2874_2 : checkWitness 2874 true false 8941 = true := by decide +kernel
private theorem cases2874 : checkFour 2874 (8945,0,8941,0) = true := by
  simp only [checkFour, w2874_0, w2874_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2874 : Coverage 2874 2875 := checkList_sound (ws:=[(8945,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2874)
private theorem w2875_0 : checkWitness 2875 false false 44 = true := by decide +kernel
private theorem w2875_2 : checkWitness 2875 true false 44 = true := by decide +kernel
private theorem cases2875 : checkFour 2875 (44,0,44,0) = true := by
  simp only [checkFour, w2875_0, w2875_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2875 : Coverage 2875 2876 := checkList_sound (ws:=[(44,0,44,0)]) (by simpa only [checkList, Bool.and_true] using cases2875)
private theorem w2876_0 : checkWitness 2876 false false 560 = true := by decide +kernel
private theorem w2876_1 : checkWitness 2876 false true 4656 = true := by decide +kernel
private theorem w2876_2 : checkWitness 2876 true false 560 = true := by decide +kernel
private theorem w2876_3 : checkWitness 2876 true true 4656 = true := by decide +kernel
private theorem cases2876 : checkFour 2876 (560,4656,560,4656) = true := by
  simp only [checkFour, w2876_0, w2876_1, w2876_2, w2876_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2876 : Coverage 2876 2877 := checkList_sound (ws:=[(560,4656,560,4656)]) (by simpa only [checkList, Bool.and_true] using cases2876)
private theorem w2877_0 : checkWitness 2877 false false 8955 = true := by decide +kernel
private theorem w2877_2 : checkWitness 2877 true false 8951 = true := by decide +kernel
private theorem cases2877 : checkFour 2877 (8955,0,8951,0) = true := by
  simp only [checkFour, w2877_0, w2877_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2877 : Coverage 2877 2878 := checkList_sound (ws:=[(8955,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases2877)
private theorem w2878_0 : checkWitness 2878 false false 686 = true := by decide +kernel
private theorem w2878_1 : checkWitness 2878 false true 4782 = true := by decide +kernel
private theorem w2878_2 : checkWitness 2878 true false 677 = true := by decide +kernel
private theorem w2878_3 : checkWitness 2878 true true 4773 = true := by decide +kernel
private theorem cases2878 : checkFour 2878 (686,4782,677,4773) = true := by
  simp only [checkFour, w2878_0, w2878_1, w2878_2, w2878_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2878 : Coverage 2878 2879 := checkList_sound (ws:=[(686,4782,677,4773)]) (by simpa only [checkList, Bool.and_true] using cases2878)
private theorem w2879_0 : checkWitness 2879 false false 210 = true := by decide +kernel
private theorem w2879_2 : checkWitness 2879 true false 210 = true := by decide +kernel
private theorem cases2879 : checkFour 2879 (210,0,210,0) = true := by
  simp only [checkFour, w2879_0, w2879_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2879 : Coverage 2879 2880 := checkList_sound (ws:=[(210,0,210,0)]) (by simpa only [checkList, Bool.and_true] using cases2879)
theorem cover2848 : Coverage 2848 2880 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2848 one2849) (Coverage.join one2850 one2851)) (Coverage.join (Coverage.join one2852 one2853) (Coverage.join one2854 one2855))) (Coverage.join (Coverage.join (Coverage.join one2856 one2857) (Coverage.join one2858 one2859)) (Coverage.join (Coverage.join one2860 one2861) (Coverage.join one2862 one2863)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2864 one2865) (Coverage.join one2866 one2867)) (Coverage.join (Coverage.join one2868 one2869) (Coverage.join one2870 one2871))) (Coverage.join (Coverage.join (Coverage.join one2872 one2873) (Coverage.join one2874 one2875)) (Coverage.join (Coverage.join one2876 one2877) (Coverage.join one2878 one2879)))))
end NF181PA.Symbolic
