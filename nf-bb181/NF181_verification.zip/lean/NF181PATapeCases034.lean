import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1088_0 : checkWitness 1088 false false 613 = true := by decide +kernel
private theorem w1088_1 : checkWitness 1088 false true 4705 = true := by decide +kernel
private theorem w1088_2 : checkWitness 1088 true false 604 = true := by decide +kernel
private theorem w1088_3 : checkWitness 1088 true true 4696 = true := by decide +kernel
private theorem cases1088 : checkFour 1088 (613,4705,604,4696) = true := by
  simp only [checkFour, w1088_0, w1088_1, w1088_2, w1088_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1088 : Coverage 1088 1089 := checkList_sound (ws:=[(613,4705,604,4696)]) (by simpa only [checkList, Bool.and_true] using cases1088)
private theorem w1089_0 : checkWitness 1089 false false 8910 = true := by decide +kernel
private theorem w1089_2 : checkWitness 1089 true false 8901 = true := by decide +kernel
private theorem cases1089 : checkFour 1089 (8910,0,8901,0) = true := by
  simp only [checkFour, w1089_0, w1089_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1089 : Coverage 1089 1090 := checkList_sound (ws:=[(8910,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases1089)
private theorem w1090_0 : checkWitness 1090 false false 8856 = true := by decide +kernel
private theorem w1090_2 : checkWitness 1090 true false 8852 = true := by decide +kernel
private theorem cases1090 : checkFour 1090 (8856,0,8852,0) = true := by
  simp only [checkFour, w1090_0, w1090_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1090 : Coverage 1090 1091 := checkList_sound (ws:=[(8856,0,8852,0)]) (by simpa only [checkList, Bool.and_true] using cases1090)
private theorem w1091_0 : checkWitness 1091 false false 82 = true := by decide +kernel
private theorem w1091_2 : checkWitness 1091 true false 82 = true := by decide +kernel
private theorem cases1091 : checkFour 1091 (82,0,82,0) = true := by
  simp only [checkFour, w1091_0, w1091_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1091 : Coverage 1091 1092 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1091)
private theorem w1092_0 : checkWitness 1092 false false 640 = true := by decide +kernel
private theorem w1092_1 : checkWitness 1092 false true 4732 = true := by decide +kernel
private theorem w1092_2 : checkWitness 1092 true false 631 = true := by decide +kernel
private theorem w1092_3 : checkWitness 1092 true true 4723 = true := by decide +kernel
private theorem cases1092 : checkFour 1092 (640,4732,631,4723) = true := by
  simp only [checkFour, w1092_0, w1092_1, w1092_2, w1092_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1092 : Coverage 1092 1093 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases1092)
private theorem w1093_0 : checkWitness 1093 false false 8917 = true := by decide +kernel
private theorem w1093_2 : checkWitness 1093 true false 8908 = true := by decide +kernel
private theorem cases1093 : checkFour 1093 (8917,0,8908,0) = true := by
  simp only [checkFour, w1093_0, w1093_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1093 : Coverage 1093 1094 := checkList_sound (ws:=[(8917,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases1093)
private theorem w1094_0 : checkWitness 1094 false false 66 = true := by decide +kernel
private theorem w1094_2 : checkWitness 1094 true false 66 = true := by decide +kernel
private theorem cases1094 : checkFour 1094 (66,0,66,0) = true := by
  simp only [checkFour, w1094_0, w1094_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1094 : Coverage 1094 1095 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases1094)
private theorem w1095_0 : checkWitness 1095 false false 506 = true := by decide +kernel
private theorem w1095_1 : checkWitness 1095 false true 4602 = true := by decide +kernel
private theorem w1095_2 : checkWitness 1095 true false 506 = true := by decide +kernel
private theorem w1095_3 : checkWitness 1095 true true 4602 = true := by decide +kernel
private theorem cases1095 : checkFour 1095 (506,4602,506,4602) = true := by
  simp only [checkFour, w1095_0, w1095_1, w1095_2, w1095_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1095 : Coverage 1095 1096 := checkList_sound (ws:=[(506,4602,506,4602)]) (by simpa only [checkList, Bool.and_true] using cases1095)
private theorem w1096_0 : checkWitness 1096 false false 8944 = true := by decide +kernel
private theorem w1096_2 : checkWitness 1096 true false 8935 = true := by decide +kernel
private theorem cases1096 : checkFour 1096 (8944,0,8935,0) = true := by
  simp only [checkFour, w1096_0, w1096_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1096 : Coverage 1096 1097 := checkList_sound (ws:=[(8944,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases1096)
private theorem w1097_0 : checkWitness 1097 false false 84 = true := by decide +kernel
private theorem w1097_2 : checkWitness 1097 true false 84 = true := by decide +kernel
private theorem cases1097 : checkFour 1097 (84,0,84,0) = true := by
  simp only [checkFour, w1097_0, w1097_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1097 : Coverage 1097 1098 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1097)
private theorem w1098_0 : checkWitness 1098 false false 526 = true := by decide +kernel
private theorem w1098_1 : checkWitness 1098 false true 4622 = true := by decide +kernel
private theorem w1098_2 : checkWitness 1098 true false 526 = true := by decide +kernel
private theorem w1098_3 : checkWitness 1098 true true 4622 = true := by decide +kernel
private theorem cases1098 : checkFour 1098 (526,4622,526,4622) = true := by
  simp only [checkFour, w1098_0, w1098_1, w1098_2, w1098_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1098 : Coverage 1098 1099 := checkList_sound (ws:=[(526,4622,526,4622)]) (by simpa only [checkList, Bool.and_true] using cases1098)
private theorem w1099_0 : checkWitness 1099 false false 8884 = true := by decide +kernel
private theorem w1099_2 : checkWitness 1099 true false 8880 = true := by decide +kernel
private theorem cases1099 : checkFour 1099 (8884,0,8880,0) = true := by
  simp only [checkFour, w1099_0, w1099_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1099 : Coverage 1099 1100 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases1099)
private theorem w1100_0 : checkWitness 1100 false false 86 = true := by decide +kernel
private theorem w1100_2 : checkWitness 1100 true false 86 = true := by decide +kernel
private theorem cases1100 : checkFour 1100 (86,0,86,0) = true := by
  simp only [checkFour, w1100_0, w1100_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1100 : Coverage 1100 1101 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1100)
private theorem w1101_0 : checkWitness 1101 false false 564 = true := by decide +kernel
private theorem w1101_1 : checkWitness 1101 false true 4660 = true := by decide +kernel
private theorem w1101_2 : checkWitness 1101 true false 564 = true := by decide +kernel
private theorem w1101_3 : checkWitness 1101 true true 4660 = true := by decide +kernel
private theorem cases1101 : checkFour 1101 (564,4660,564,4660) = true := by
  simp only [checkFour, w1101_0, w1101_1, w1101_2, w1101_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1101 : Coverage 1101 1102 := checkList_sound (ws:=[(564,4660,564,4660)]) (by simpa only [checkList, Bool.and_true] using cases1101)
private theorem w1102_0 : checkWitness 1102 false false 8905 = true := by decide +kernel
private theorem w1102_2 : checkWitness 1102 true false 8901 = true := by decide +kernel
private theorem cases1102 : checkFour 1102 (8905,0,8901,0) = true := by
  simp only [checkFour, w1102_0, w1102_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1102 : Coverage 1102 1103 := checkList_sound (ws:=[(8905,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases1102)
private theorem w1103_0 : checkWitness 1103 false false 8940 = true := by decide +kernel
private theorem w1103_2 : checkWitness 1103 true false 8931 = true := by decide +kernel
private theorem cases1103 : checkFour 1103 (8940,0,8931,0) = true := by
  simp only [checkFour, w1103_0, w1103_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1103 : Coverage 1103 1104 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases1103)
private theorem w1104_0 : checkWitness 1104 false false 110 = true := by decide +kernel
private theorem w1104_2 : checkWitness 1104 true false 110 = true := by decide +kernel
private theorem cases1104 : checkFour 1104 (110,0,110,0) = true := by
  simp only [checkFour, w1104_0, w1104_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1104 : Coverage 1104 1105 := checkList_sound (ws:=[(110,0,110,0)]) (by simpa only [checkList, Bool.and_true] using cases1104)
private theorem w1105_0 : checkWitness 1105 false false 652 = true := by decide +kernel
private theorem w1105_1 : checkWitness 1105 false true 4744 = true := by decide +kernel
private theorem w1105_2 : checkWitness 1105 true false 643 = true := by decide +kernel
private theorem w1105_3 : checkWitness 1105 true true 4735 = true := by decide +kernel
private theorem cases1105 : checkFour 1105 (652,4744,643,4735) = true := by
  simp only [checkFour, w1105_0, w1105_1, w1105_2, w1105_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1105 : Coverage 1105 1106 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases1105)
private theorem w1106_0 : checkWitness 1106 false false 8901 = true := by decide +kernel
private theorem w1106_2 : checkWitness 1106 true false 8897 = true := by decide +kernel
private theorem cases1106 : checkFour 1106 (8901,0,8897,0) = true := by
  simp only [checkFour, w1106_0, w1106_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1106 : Coverage 1106 1107 := checkList_sound (ws:=[(8901,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1106)
private theorem w1107_0 : checkWitness 1107 false false 646 = true := by decide +kernel
private theorem w1107_1 : checkWitness 1107 false true 4738 = true := by decide +kernel
private theorem w1107_2 : checkWitness 1107 true false 637 = true := by decide +kernel
private theorem w1107_3 : checkWitness 1107 true true 4729 = true := by decide +kernel
private theorem cases1107 : checkFour 1107 (646,4738,637,4729) = true := by
  simp only [checkFour, w1107_0, w1107_1, w1107_2, w1107_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1107 : Coverage 1107 1108 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases1107)
private theorem w1108_0 : checkWitness 1108 false false 8870 = true := by decide +kernel
private theorem w1108_2 : checkWitness 1108 true false 8866 = true := by decide +kernel
private theorem cases1108 : checkFour 1108 (8870,0,8866,0) = true := by
  simp only [checkFour, w1108_0, w1108_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1108 : Coverage 1108 1109 := checkList_sound (ws:=[(8870,0,8866,0)]) (by simpa only [checkList, Bool.and_true] using cases1108)
private theorem w1109_0 : checkWitness 1109 false false 98 = true := by decide +kernel
private theorem w1109_2 : checkWitness 1109 true false 98 = true := by decide +kernel
private theorem cases1109 : checkFour 1109 (98,0,98,0) = true := by
  simp only [checkFour, w1109_0, w1109_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1109 : Coverage 1109 1110 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1109)
private theorem w1110_0 : checkWitness 1110 false false 90 = true := by decide +kernel
private theorem w1110_2 : checkWitness 1110 true false 90 = true := by decide +kernel
private theorem cases1110 : checkFour 1110 (90,0,90,0) = true := by
  simp only [checkFour, w1110_0, w1110_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1110 : Coverage 1110 1111 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1110)
private theorem w1111_0 : checkWitness 1111 false false 611 = true := by decide +kernel
private theorem w1111_1 : checkWitness 1111 false true 4695 = true := by decide +kernel
private theorem w1111_2 : checkWitness 1111 true false 611 = true := by decide +kernel
private theorem w1111_3 : checkWitness 1111 true true 4695 = true := by decide +kernel
private theorem cases1111 : checkFour 1111 (611,4695,611,4695) = true := by
  simp only [checkFour, w1111_0, w1111_1, w1111_2, w1111_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1111 : Coverage 1111 1112 := checkList_sound (ws:=[(611,4695,611,4695)]) (by simpa only [checkList, Bool.and_true] using cases1111)
private theorem w1112_0 : checkWitness 1112 false false 8864 = true := by decide +kernel
private theorem w1112_2 : checkWitness 1112 true false 8860 = true := by decide +kernel
private theorem cases1112 : checkFour 1112 (8864,0,8860,0) = true := by
  simp only [checkFour, w1112_0, w1112_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1112 : Coverage 1112 1113 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases1112)
private theorem w1113_0 : checkWitness 1113 false false 90 = true := by decide +kernel
private theorem w1113_2 : checkWitness 1113 true false 90 = true := by decide +kernel
private theorem cases1113 : checkFour 1113 (90,0,90,0) = true := by
  simp only [checkFour, w1113_0, w1113_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1113 : Coverage 1113 1114 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1113)
private theorem w1114_0 : checkWitness 1114 false false 609 = true := by decide +kernel
private theorem w1114_1 : checkWitness 1114 false true 4701 = true := by decide +kernel
private theorem w1114_2 : checkWitness 1114 true false 600 = true := by decide +kernel
private theorem w1114_3 : checkWitness 1114 true true 4692 = true := by decide +kernel
private theorem cases1114 : checkFour 1114 (609,4701,600,4692) = true := by
  simp only [checkFour, w1114_0, w1114_1, w1114_2, w1114_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1114 : Coverage 1114 1115 := checkList_sound (ws:=[(609,4701,600,4692)]) (by simpa only [checkList, Bool.and_true] using cases1114)
private theorem w1115_0 : checkWitness 1115 false false 8906 = true := by decide +kernel
private theorem w1115_2 : checkWitness 1115 true false 8897 = true := by decide +kernel
private theorem cases1115 : checkFour 1115 (8906,0,8897,0) = true := by
  simp only [checkFour, w1115_0, w1115_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1115 : Coverage 1115 1116 := checkList_sound (ws:=[(8906,0,8897,0)]) (by simpa only [checkList, Bool.and_true] using cases1115)
private theorem w1116_0 : checkWitness 1116 false false 8852 = true := by decide +kernel
private theorem w1116_2 : checkWitness 1116 true false 8848 = true := by decide +kernel
private theorem cases1116 : checkFour 1116 (8852,0,8848,0) = true := by
  simp only [checkFour, w1116_0, w1116_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1116 : Coverage 1116 1117 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1116)
private theorem w1117_0 : checkWitness 1117 false false 84 = true := by decide +kernel
private theorem w1117_2 : checkWitness 1117 true false 84 = true := by decide +kernel
private theorem cases1117 : checkFour 1117 (84,0,84,0) = true := by
  simp only [checkFour, w1117_0, w1117_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1117 : Coverage 1117 1118 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1117)
private theorem w1118_0 : checkWitness 1118 false false 636 = true := by decide +kernel
private theorem w1118_1 : checkWitness 1118 false true 4728 = true := by decide +kernel
private theorem w1118_2 : checkWitness 1118 true false 627 = true := by decide +kernel
private theorem w1118_3 : checkWitness 1118 true true 4719 = true := by decide +kernel
private theorem cases1118 : checkFour 1118 (636,4728,627,4719) = true := by
  simp only [checkFour, w1118_0, w1118_1, w1118_2, w1118_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1118 : Coverage 1118 1119 := checkList_sound (ws:=[(636,4728,627,4719)]) (by simpa only [checkList, Bool.and_true] using cases1118)
private theorem w1119_0 : checkWitness 1119 false false 8913 = true := by decide +kernel
private theorem w1119_2 : checkWitness 1119 true false 8904 = true := by decide +kernel
private theorem cases1119 : checkFour 1119 (8913,0,8904,0) = true := by
  simp only [checkFour, w1119_0, w1119_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1119 : Coverage 1119 1120 := checkList_sound (ws:=[(8913,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases1119)
theorem cover1088 : Coverage 1088 1120 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1088 one1089) (Coverage.join one1090 one1091)) (Coverage.join (Coverage.join one1092 one1093) (Coverage.join one1094 one1095))) (Coverage.join (Coverage.join (Coverage.join one1096 one1097) (Coverage.join one1098 one1099)) (Coverage.join (Coverage.join one1100 one1101) (Coverage.join one1102 one1103)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1104 one1105) (Coverage.join one1106 one1107)) (Coverage.join (Coverage.join one1108 one1109) (Coverage.join one1110 one1111))) (Coverage.join (Coverage.join (Coverage.join one1112 one1113) (Coverage.join one1114 one1115)) (Coverage.join (Coverage.join one1116 one1117) (Coverage.join one1118 one1119)))))
end NF181PA.Symbolic
