import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1472_0 : checkWitness 1472 false false 622 = true := by decide +kernel
private theorem w1472_1 : checkWitness 1472 false true 4714 = true := by decide +kernel
private theorem w1472_2 : checkWitness 1472 true false 613 = true := by decide +kernel
private theorem w1472_3 : checkWitness 1472 true true 4705 = true := by decide +kernel
private theorem cases1472 : checkFour 1472 (622,4714,613,4705) = true := by
  simp only [checkFour, w1472_0, w1472_1, w1472_2, w1472_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1472 : Coverage 1472 1473 := checkList_sound (ws:=[(622,4714,613,4705)]) (by simpa only [checkList, Bool.and_true] using cases1472)
private theorem w1473_0 : checkWitness 1473 false false 8846 = true := by decide +kernel
private theorem w1473_2 : checkWitness 1473 true false 8842 = true := by decide +kernel
private theorem cases1473 : checkFour 1473 (8846,0,8842,0) = true := by
  simp only [checkFour, w1473_0, w1473_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1473 : Coverage 1473 1474 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1473)
private theorem w1474_0 : checkWitness 1474 false false 100 = true := by decide +kernel
private theorem w1474_2 : checkWitness 1474 true false 100 = true := by decide +kernel
private theorem cases1474 : checkFour 1474 (100,0,100,0) = true := by
  simp only [checkFour, w1474_0, w1474_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1474 : Coverage 1474 1475 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1474)
private theorem w1475_0 : checkWitness 1475 false false 92 = true := by decide +kernel
private theorem w1475_2 : checkWitness 1475 true false 92 = true := by decide +kernel
private theorem cases1475 : checkFour 1475 (92,0,92,0) = true := by
  simp only [checkFour, w1475_0, w1475_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1475 : Coverage 1475 1476 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1475)
private theorem w1476_0 : checkWitness 1476 false false 587 = true := by decide +kernel
private theorem w1476_1 : checkWitness 1476 false true 4671 = true := by decide +kernel
private theorem w1476_2 : checkWitness 1476 true false 587 = true := by decide +kernel
private theorem w1476_3 : checkWitness 1476 true true 4671 = true := by decide +kernel
private theorem cases1476 : checkFour 1476 (587,4671,587,4671) = true := by
  simp only [checkFour, w1476_0, w1476_1, w1476_2, w1476_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1476 : Coverage 1476 1477 := checkList_sound (ws:=[(587,4671,587,4671)]) (by simpa only [checkList, Bool.and_true] using cases1476)
private theorem w1477_0 : checkWitness 1477 false false 8840 = true := by decide +kernel
private theorem w1477_2 : checkWitness 1477 true false 8836 = true := by decide +kernel
private theorem cases1477 : checkFour 1477 (8840,0,8836,0) = true := by
  simp only [checkFour, w1477_0, w1477_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1477 : Coverage 1477 1478 := checkList_sound (ws:=[(8840,0,8836,0)]) (by simpa only [checkList, Bool.and_true] using cases1477)
private theorem w1478_0 : checkWitness 1478 false false 92 = true := by decide +kernel
private theorem w1478_2 : checkWitness 1478 true false 92 = true := by decide +kernel
private theorem cases1478 : checkFour 1478 (92,0,92,0) = true := by
  simp only [checkFour, w1478_0, w1478_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1478 : Coverage 1478 1479 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1478)
private theorem w1479_0 : checkWitness 1479 false false 555 = true := by decide +kernel
private theorem w1479_1 : checkWitness 1479 false true 4651 = true := by decide +kernel
private theorem w1479_2 : checkWitness 1479 true false 555 = true := by decide +kernel
private theorem w1479_3 : checkWitness 1479 true true 4651 = true := by decide +kernel
private theorem cases1479 : checkFour 1479 (555,4651,555,4651) = true := by
  simp only [checkFour, w1479_0, w1479_1, w1479_2, w1479_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1479 : Coverage 1479 1480 := checkList_sound (ws:=[(555,4651,555,4651)]) (by simpa only [checkList, Bool.and_true] using cases1479)
private theorem w1480_0 : checkWitness 1480 false false 8908 = true := by decide +kernel
private theorem w1480_2 : checkWitness 1480 true false 8899 = true := by decide +kernel
private theorem cases1480 : checkFour 1480 (8908,0,8899,0) = true := by
  simp only [checkFour, w1480_0, w1480_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1480 : Coverage 1480 1481 := checkList_sound (ws:=[(8908,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases1480)
private theorem w1481_0 : checkWitness 1481 false false 8854 = true := by decide +kernel
private theorem w1481_2 : checkWitness 1481 true false 8850 = true := by decide +kernel
private theorem cases1481 : checkFour 1481 (8854,0,8850,0) = true := by
  simp only [checkFour, w1481_0, w1481_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1481 : Coverage 1481 1482 := checkList_sound (ws:=[(8854,0,8850,0)]) (by simpa only [checkList, Bool.and_true] using cases1481)
private theorem w1482_0 : checkWitness 1482 false false 100 = true := by decide +kernel
private theorem w1482_2 : checkWitness 1482 true false 100 = true := by decide +kernel
private theorem cases1482 : checkFour 1482 (100,0,100,0) = true := by
  simp only [checkFour, w1482_0, w1482_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1482 : Coverage 1482 1483 := checkList_sound (ws:=[(100,0,100,0)]) (by simpa only [checkList, Bool.and_true] using cases1482)
private theorem w1483_0 : checkWitness 1483 false false 638 = true := by decide +kernel
private theorem w1483_1 : checkWitness 1483 false true 4726 = true := by decide +kernel
private theorem w1483_2 : checkWitness 1483 true false 629 = true := by decide +kernel
private theorem w1483_3 : checkWitness 1483 true true 4717 = true := by decide +kernel
private theorem cases1483 : checkFour 1483 (638,4726,629,4717) = true := by
  simp only [checkFour, w1483_0, w1483_1, w1483_2, w1483_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1483 : Coverage 1483 1484 := checkList_sound (ws:=[(638,4726,629,4717)]) (by simpa only [checkList, Bool.and_true] using cases1483)
private theorem w1484_0 : checkWitness 1484 false false 8873 = true := by decide +kernel
private theorem w1484_2 : checkWitness 1484 true false 8869 = true := by decide +kernel
private theorem cases1484 : checkFour 1484 (8873,0,8869,0) = true := by
  simp only [checkFour, w1484_0, w1484_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1484 : Coverage 1484 1485 := checkList_sound (ws:=[(8873,0,8869,0)]) (by simpa only [checkList, Bool.and_true] using cases1484)
private theorem w1485_0 : checkWitness 1485 false false 90 = true := by decide +kernel
private theorem w1485_2 : checkWitness 1485 true false 90 = true := by decide +kernel
private theorem cases1485 : checkFour 1485 (90,0,90,0) = true := by
  simp only [checkFour, w1485_0, w1485_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1485 : Coverage 1485 1486 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1485)
private theorem w1486_0 : checkWitness 1486 false false 472 = true := by decide +kernel
private theorem w1486_1 : checkWitness 1486 false true 4568 = true := by decide +kernel
private theorem w1486_2 : checkWitness 1486 true false 472 = true := by decide +kernel
private theorem w1486_3 : checkWitness 1486 true true 4568 = true := by decide +kernel
private theorem cases1486 : checkFour 1486 (472,4568,472,4568) = true := by
  simp only [checkFour, w1486_0, w1486_1, w1486_2, w1486_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1486 : Coverage 1486 1487 := checkList_sound (ws:=[(472,4568,472,4568)]) (by simpa only [checkList, Bool.and_true] using cases1486)
private theorem w1487_0 : checkWitness 1487 false false 8918 = true := by decide +kernel
private theorem w1487_2 : checkWitness 1487 true false 8909 = true := by decide +kernel
private theorem cases1487 : checkFour 1487 (8918,0,8909,0) = true := by
  simp only [checkFour, w1487_0, w1487_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1487 : Coverage 1487 1488 := checkList_sound (ws:=[(8918,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases1487)
private theorem w1488_0 : checkWitness 1488 false false 92 = true := by decide +kernel
private theorem w1488_2 : checkWitness 1488 true false 92 = true := by decide +kernel
private theorem cases1488 : checkFour 1488 (92,0,92,0) = true := by
  simp only [checkFour, w1488_0, w1488_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1488 : Coverage 1488 1489 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1488)
private theorem w1489_0 : checkWitness 1489 false false 500 = true := by decide +kernel
private theorem w1489_1 : checkWitness 1489 false true 4596 = true := by decide +kernel
private theorem w1489_2 : checkWitness 1489 true false 500 = true := by decide +kernel
private theorem w1489_3 : checkWitness 1489 true true 4596 = true := by decide +kernel
private theorem cases1489 : checkFour 1489 (500,4596,500,4596) = true := by
  simp only [checkFour, w1489_0, w1489_1, w1489_2, w1489_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1489 : Coverage 1489 1490 := checkList_sound (ws:=[(500,4596,500,4596)]) (by simpa only [checkList, Bool.and_true] using cases1489)
private theorem w1490_0 : checkWitness 1490 false false 8858 = true := by decide +kernel
private theorem w1490_2 : checkWitness 1490 true false 8854 = true := by decide +kernel
private theorem cases1490 : checkFour 1490 (8858,0,8854,0) = true := by
  simp only [checkFour, w1490_0, w1490_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1490 : Coverage 1490 1491 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1490)
private theorem w1491_0 : checkWitness 1491 false false 94 = true := by decide +kernel
private theorem w1491_2 : checkWitness 1491 true false 94 = true := by decide +kernel
private theorem cases1491 : checkFour 1491 (94,0,94,0) = true := by
  simp only [checkFour, w1491_0, w1491_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1491 : Coverage 1491 1492 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1491)
private theorem w1492_0 : checkWitness 1492 false false 538 = true := by decide +kernel
private theorem w1492_1 : checkWitness 1492 false true 4634 = true := by decide +kernel
private theorem w1492_2 : checkWitness 1492 true false 538 = true := by decide +kernel
private theorem w1492_3 : checkWitness 1492 true true 4634 = true := by decide +kernel
private theorem cases1492 : checkFour 1492 (538,4634,538,4634) = true := by
  simp only [checkFour, w1492_0, w1492_1, w1492_2, w1492_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1492 : Coverage 1492 1493 := checkList_sound (ws:=[(538,4634,538,4634)]) (by simpa only [checkList, Bool.and_true] using cases1492)
private theorem w1493_0 : checkWitness 1493 false false 8879 = true := by decide +kernel
private theorem w1493_2 : checkWitness 1493 true false 8875 = true := by decide +kernel
private theorem cases1493 : checkFour 1493 (8879,0,8875,0) = true := by
  simp only [checkFour, w1493_0, w1493_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1493 : Coverage 1493 1494 := checkList_sound (ws:=[(8879,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases1493)
private theorem w1494_0 : checkWitness 1494 false false 8914 = true := by decide +kernel
private theorem w1494_2 : checkWitness 1494 true false 8905 = true := by decide +kernel
private theorem cases1494 : checkFour 1494 (8914,0,8905,0) = true := by
  simp only [checkFour, w1494_0, w1494_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1494 : Coverage 1494 1495 := checkList_sound (ws:=[(8914,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases1494)
private theorem w1495_0 : checkWitness 1495 false false 118 = true := by decide +kernel
private theorem w1495_2 : checkWitness 1495 true false 118 = true := by decide +kernel
private theorem cases1495 : checkFour 1495 (118,0,118,0) = true := by
  simp only [checkFour, w1495_0, w1495_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1495 : Coverage 1495 1496 := checkList_sound (ws:=[(118,0,118,0)]) (by simpa only [checkList, Bool.and_true] using cases1495)
private theorem w1496_0 : checkWitness 1496 false false 626 = true := by decide +kernel
private theorem w1496_1 : checkWitness 1496 false true 4718 = true := by decide +kernel
private theorem w1496_2 : checkWitness 1496 true false 617 = true := by decide +kernel
private theorem w1496_3 : checkWitness 1496 true true 4709 = true := by decide +kernel
private theorem cases1496 : checkFour 1496 (626,4718,617,4709) = true := by
  simp only [checkFour, w1496_0, w1496_1, w1496_2, w1496_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1496 : Coverage 1496 1497 := checkList_sound (ws:=[(626,4718,617,4709)]) (by simpa only [checkList, Bool.and_true] using cases1496)
private theorem w1497_0 : checkWitness 1497 false false 8875 = true := by decide +kernel
private theorem w1497_2 : checkWitness 1497 true false 8871 = true := by decide +kernel
private theorem cases1497 : checkFour 1497 (8875,0,8871,0) = true := by
  simp only [checkFour, w1497_0, w1497_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1497 : Coverage 1497 1498 := checkList_sound (ws:=[(8875,0,8871,0)]) (by simpa only [checkList, Bool.and_true] using cases1497)
private theorem w1498_0 : checkWitness 1498 false false 620 = true := by decide +kernel
private theorem w1498_1 : checkWitness 1498 false true 4713 = true := by decide +kernel
private theorem w1498_2 : checkWitness 1498 true false 611 = true := by decide +kernel
private theorem w1498_3 : checkWitness 1498 true true 4704 = true := by decide +kernel
private theorem cases1498 : checkFour 1498 (620,4713,611,4704) = true := by
  simp only [checkFour, w1498_0, w1498_1, w1498_2, w1498_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1498 : Coverage 1498 1499 := checkList_sound (ws:=[(620,4713,611,4704)]) (by simpa only [checkList, Bool.and_true] using cases1498)
private theorem w1499_0 : checkWitness 1499 false false 8846 = true := by decide +kernel
private theorem w1499_2 : checkWitness 1499 true false 8842 = true := by decide +kernel
private theorem cases1499 : checkFour 1499 (8846,0,8842,0) = true := by
  simp only [checkFour, w1499_0, w1499_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1499 : Coverage 1499 1500 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1499)
private theorem w1500_0 : checkWitness 1500 false false 106 = true := by decide +kernel
private theorem w1500_2 : checkWitness 1500 true false 106 = true := by decide +kernel
private theorem cases1500 : checkFour 1500 (106,0,106,0) = true := by
  simp only [checkFour, w1500_0, w1500_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1500 : Coverage 1500 1501 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases1500)
private theorem w1501_0 : checkWitness 1501 false false 98 = true := by decide +kernel
private theorem w1501_2 : checkWitness 1501 true false 98 = true := by decide +kernel
private theorem cases1501 : checkFour 1501 (98,0,98,0) = true := by
  simp only [checkFour, w1501_0, w1501_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1501 : Coverage 1501 1502 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1501)
private theorem w1502_0 : checkWitness 1502 false false 585 = true := by decide +kernel
private theorem w1502_1 : checkWitness 1502 false true 4669 = true := by decide +kernel
private theorem w1502_2 : checkWitness 1502 true false 585 = true := by decide +kernel
private theorem w1502_3 : checkWitness 1502 true true 4669 = true := by decide +kernel
private theorem cases1502 : checkFour 1502 (585,4669,585,4669) = true := by
  simp only [checkFour, w1502_0, w1502_1, w1502_2, w1502_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1502 : Coverage 1502 1503 := checkList_sound (ws:=[(585,4669,585,4669)]) (by simpa only [checkList, Bool.and_true] using cases1502)
private theorem w1503_0 : checkWitness 1503 false false 8838 = true := by decide +kernel
private theorem w1503_2 : checkWitness 1503 true false 8834 = true := by decide +kernel
private theorem cases1503 : checkFour 1503 (8838,0,8834,0) = true := by
  simp only [checkFour, w1503_0, w1503_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1503 : Coverage 1503 1504 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1503)
theorem cover1472 : Coverage 1472 1504 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1472 one1473) (Coverage.join one1474 one1475)) (Coverage.join (Coverage.join one1476 one1477) (Coverage.join one1478 one1479))) (Coverage.join (Coverage.join (Coverage.join one1480 one1481) (Coverage.join one1482 one1483)) (Coverage.join (Coverage.join one1484 one1485) (Coverage.join one1486 one1487)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1488 one1489) (Coverage.join one1490 one1491)) (Coverage.join (Coverage.join one1492 one1493) (Coverage.join one1494 one1495))) (Coverage.join (Coverage.join (Coverage.join one1496 one1497) (Coverage.join one1498 one1499)) (Coverage.join (Coverage.join one1500 one1501) (Coverage.join one1502 one1503)))))
end NF181PA.Symbolic
