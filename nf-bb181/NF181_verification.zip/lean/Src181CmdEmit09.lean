module
public import Src181CmdEmit08
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter289 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1411:Nat):V) f (vector n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1408 f n (d+u) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter288 f n t s c u v y d w).trans mid

theorem commandEmitAfter290 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1414:Nat):V) f (vector n (emitAtom49 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1411 f n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom49 n t s c u v y d w)):V)=(emitAtom49 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter289 f n t s c u v y d w).trans mid

theorem commandEmitAfter291 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1424:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom50 n t s c u v y d w) w)) := by
  have micro := site1414 f n (emitAtom49 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom49 n t s c u v y d w))):V)=(emitAtom50 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom49 n t s c u v y d w))):V)=(0+(emitAtom50 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter290 f n t s c u v y d w).trans mid

theorem commandEmitAfter292 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1427:Nat):V) f (vector n 0 (emitAtom50 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1424 f n 0 0 c (d+u) (v+y) 0 (emitAtom50 n t s c u v y d w) w
  have d2 : ((0+(emitAtom50 n t s c u v y d w)):V)=(emitAtom50 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter291 f n t s c u v y d w).trans mid

theorem commandEmitAfter293 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1431:Nat):V) f (vector n c (emitAtom50 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site1427 f n 0 (emitAtom50 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter292 f n t s c u v y d w).trans mid

theorem commandEmitAfter294 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1434:Nat):V) f (vector n c (emitAtom50 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1431 f n c (emitAtom50 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter293 f n t s c u v y d w).trans mid

theorem commandEmitAfter295 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1442:Nat):V) f (vector n c 0 c (d+u) (v+y) (d+u) (emitAtom49 n t s c u v y d w) w)) := by
  have micro := site1434 f n c (emitAtom50 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom50 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom50 n t s c u v y d w)):V)=(0+(emitAtom50 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom50 n t s c u v y d w))):V)=left (emitAtom50 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom49 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom50 n t s c u v y d w))):V)=(emitAtom49 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom50 n t s c u v y d w)):V)=(0+(emitAtom50 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom50 n t s c u v y d w))):V)=right (emitAtom50 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom49 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter294 f n t s c u v y d w).trans mid

theorem commandEmitAfter296 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1445:Nat):V) f (vector n c (emitAtom49 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1442 f n c 0 c (d+u) (v+y) (d+u) (emitAtom49 n t s c u v y d w) w
  have d2 : ((0+(emitAtom49 n t s c u v y d w)):V)=(emitAtom49 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter295 f n t s c u v y d w).trans mid

theorem commandEmitAfter297 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1455:Nat):V) f (vector n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom9 n t s c u v y d w) w)) := by
  have micro := site1445 f n c (emitAtom49 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) c)):V)=(emitAtom9 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) c)):V)=(0+(emitAtom9 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter296 f n t s c u v y d w).trans mid

theorem commandEmitAfter298 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1459:Nat):V) f (vector n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1455 f n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom9 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom9 n t s c u v y d w))):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom9 n t s c u v y d w))):V)=(0+((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter297 f n t s c u v y d w).trans mid

theorem commandEmitAfter299 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1460:Nat):V) f (vector n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1459 f n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w))+1):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter298 f n t s c u v y d w).trans mid

theorem commandEmitAfter300 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1463:Nat):V) f (vector n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1460 f n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1)):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter299 f n t s c u v y d w).trans mid

theorem commandEmitAfter301 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1466:Nat):V) f (vector n (emitAtom49 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1463 f n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom49 n t s c u v y d w)):V)=(emitAtom49 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter300 f n t s c u v y d w).trans mid

theorem commandEmitAfter302 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1476:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom51 n t s c u v y d w) w)) := by
  have micro := site1466 f n (emitAtom49 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w))):V)=(emitAtom51 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w))):V)=(0+(emitAtom51 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter301 f n t s c u v y d w).trans mid

theorem commandEmitAfter303 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1479:Nat):V) f (vector n 0 (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1476 f n 0 0 c (d+u) (v+y) 0 (emitAtom51 n t s c u v y d w) w
  have d2 : ((0+(emitAtom51 n t s c u v y d w)):V)=(emitAtom51 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter302 f n t s c u v y d w).trans mid

theorem commandEmitAfter304 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1483:Nat):V) f (vector n (d+u) (emitAtom51 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1479 f n 0 (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter303 f n t s c u v y d w).trans mid

theorem commandEmitAfter305 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1486:Nat):V) f (vector n (d+u) (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1483 f n (d+u) (emitAtom51 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter304 f n t s c u v y d w).trans mid

theorem commandEmitAfter306 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1489:Nat):V) f (vector n 0 (emitAtom51 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1486 f n (d+u) (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter305 f n t s c u v y d w).trans mid

theorem commandEmitAfter307 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1492:Nat):V) f (vector n (emitAtom51 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1489 f n 0 (emitAtom51 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom51 n t s c u v y d w)):V)=(emitAtom51 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter306 f n t s c u v y d w).trans mid

theorem commandEmitAfter308 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1502:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom52 n t s c u v y d w) w)) := by
  have micro := site1492 f n (emitAtom51 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom51 n t s c u v y d w))):V)=(emitAtom52 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom51 n t s c u v y d w))):V)=(0+(emitAtom52 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter307 f n t s c u v y d w).trans mid

theorem commandEmitAfter309 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1505:Nat):V) f (vector n 0 (emitAtom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1502 f n 0 0 c (d+u) (v+y) 0 (emitAtom52 n t s c u v y d w) w
  have d2 : ((0+(emitAtom52 n t s c u v y d w)):V)=(emitAtom52 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter308 f n t s c u v y d w).trans mid

theorem commandEmitAfter310 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1509:Nat):V) f (vector n (v+y) (emitAtom52 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1505 f n 0 (emitAtom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter309 f n t s c u v y d w).trans mid

theorem commandEmitAfter311 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1512:Nat):V) f (vector n (v+y) (emitAtom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1509 f n (v+y) (emitAtom52 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter310 f n t s c u v y d w).trans mid

theorem commandEmitAfter312 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1520:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom51 n t s c u v y d w) w)) := by
  have micro := site1512 f n (v+y) (emitAtom52 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom52 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom52 n t s c u v y d w)):V)=(0+(emitAtom52 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom52 n t s c u v y d w))):V)=left (emitAtom52 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom51 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom52 n t s c u v y d w))):V)=(emitAtom51 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom52 n t s c u v y d w)):V)=(0+(emitAtom52 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom52 n t s c u v y d w))):V)=right (emitAtom52 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom51 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter311 f n t s c u v y d w).trans mid

theorem commandEmitAfter313 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1523:Nat):V) f (vector n (v+y) (emitAtom51 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1520 f n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom51 n t s c u v y d w) w
  have d2 : ((0+(emitAtom51 n t s c u v y d w)):V)=(emitAtom51 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter312 f n t s c u v y d w).trans mid

theorem commandEmitAfter314 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1533:Nat):V) f (vector n 0 (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w)) := by
  have micro := site1523 f n (v+y) (emitAtom51 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (v+y))):V)=(emitAtom24 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (v+y))):V)=(0+(emitAtom24 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter313 f n t s c u v y d w).trans mid

theorem commandEmitAfter315 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1537:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1533 f n 0 (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=(0+((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter314 f n t s c u v y d w).trans mid

theorem commandEmitAfter316 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1538:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1537 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter315 f n t s c u v y d w).trans mid

theorem commandEmitAfter317 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1546:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w) w)) := by
  have micro := site1538 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom51 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom51 n t s c u v y d w))):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom51 n t s c u v y d w)):V)=(0+(emitAtom51 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom51 n t s c u v y d w))):V)=left (emitAtom51 n t s c u v y d w))).trans (by change left (cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom51 n t s c u v y d w))):V)=(emitAtom49 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom51 n t s c u v y d w)):V)=(0+(emitAtom51 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom51 n t s c u v y d w))):V)=right (emitAtom51 n t s c u v y d w))).trans (by change right (cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter316 f n t s c u v y d w).trans mid

theorem commandEmitAfter318 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1549:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1546 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w) w
  have d2 : ((0+(emitAtom49 n t s c u v y d w)):V)=(emitAtom49 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter317 f n t s c u v y d w).trans mid

theorem commandEmitAfter319 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1559:Nat):V) f (vector n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom53 n t s c u v y d w) w)) := by
  have micro := site1549 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(emitAtom53 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(0+(emitAtom53 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter318 f n t s c u v y d w).trans mid

theorem commandEmitAfter320 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1563:Nat):V) f (vector n ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1559 f n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom53 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom53 n t s c u v y d w))):V)=((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom53 n t s c u v y d w))):V)=(0+((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter319 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
