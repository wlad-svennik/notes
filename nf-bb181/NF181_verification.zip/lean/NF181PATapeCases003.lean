import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w96_0 : checkWitness 96 false false 627 = true := by decide +kernel
private theorem w96_1 : checkWitness 96 false true 4711 = true := by decide +kernel
private theorem w96_2 : checkWitness 96 true false 627 = true := by decide +kernel
private theorem w96_3 : checkWitness 96 true true 4711 = true := by decide +kernel
private theorem cases96 : checkFour 96 (627,4711,627,4711) = true := by
  simp only [checkFour, w96_0, w96_1, w96_2, w96_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one96 : Coverage 96 97 := checkList_sound (ws:=[(627,4711,627,4711)]) (by simpa only [checkList, Bool.and_true] using cases96)
private theorem w97_0 : checkWitness 97 false false 8880 = true := by decide +kernel
private theorem w97_2 : checkWitness 97 true false 8876 = true := by decide +kernel
private theorem cases97 : checkFour 97 (8880,0,8876,0) = true := by
  simp only [checkFour, w97_0, w97_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one97 : Coverage 97 98 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases97)
private theorem w98_0 : checkWitness 98 false false 62 = true := by decide +kernel
private theorem w98_2 : checkWitness 98 true false 62 = true := by decide +kernel
private theorem cases98 : checkFour 98 (62,0,62,0) = true := by
  simp only [checkFour, w98_0, w98_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one98 : Coverage 98 99 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases98)
private theorem w99_0 : checkWitness 99 false false 595 = true := by decide +kernel
private theorem w99_1 : checkWitness 99 false true 4691 = true := by decide +kernel
private theorem w99_2 : checkWitness 99 true false 595 = true := by decide +kernel
private theorem w99_3 : checkWitness 99 true true 4691 = true := by decide +kernel
private theorem cases99 : checkFour 99 (595,4691,595,4691) = true := by
  simp only [checkFour, w99_0, w99_1, w99_2, w99_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one99 : Coverage 99 100 := checkList_sound (ws:=[(595,4691,595,4691)]) (by simpa only [checkList, Bool.and_true] using cases99)
private theorem w100_0 : checkWitness 100 false false 8948 = true := by decide +kernel
private theorem w100_2 : checkWitness 100 true false 8939 = true := by decide +kernel
private theorem cases100 : checkFour 100 (8948,0,8939,0) = true := by
  simp only [checkFour, w100_0, w100_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one100 : Coverage 100 101 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases100)
private theorem w101_0 : checkWitness 101 false false 8894 = true := by decide +kernel
private theorem w101_2 : checkWitness 101 true false 8890 = true := by decide +kernel
private theorem cases101 : checkFour 101 (8894,0,8890,0) = true := by
  simp only [checkFour, w101_0, w101_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one101 : Coverage 101 102 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases101)
private theorem w102_0 : checkWitness 102 false false 70 = true := by decide +kernel
private theorem w102_2 : checkWitness 102 true false 70 = true := by decide +kernel
private theorem cases102 : checkFour 102 (70,0,70,0) = true := by
  simp only [checkFour, w102_0, w102_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one102 : Coverage 102 103 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases102)
private theorem w103_0 : checkWitness 103 false false 678 = true := by decide +kernel
private theorem w103_1 : checkWitness 103 false true 4766 = true := by decide +kernel
private theorem w103_2 : checkWitness 103 true false 669 = true := by decide +kernel
private theorem w103_3 : checkWitness 103 true true 4757 = true := by decide +kernel
private theorem cases103 : checkFour 103 (678,4766,669,4757) = true := by
  simp only [checkFour, w103_0, w103_1, w103_2, w103_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one103 : Coverage 103 104 := checkList_sound (ws:=[(678,4766,669,4757)]) (by simpa only [checkList, Bool.and_true] using cases103)
private theorem w104_0 : checkWitness 104 false false 8913 = true := by decide +kernel
private theorem w104_2 : checkWitness 104 true false 8909 = true := by decide +kernel
private theorem cases104 : checkFour 104 (8913,0,8909,0) = true := by
  simp only [checkFour, w104_0, w104_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one104 : Coverage 104 105 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases104)
private theorem w105_0 : checkWitness 105 false false 60 = true := by decide +kernel
private theorem w105_2 : checkWitness 105 true false 60 = true := by decide +kernel
private theorem cases105 : checkFour 105 (60,0,60,0) = true := by
  simp only [checkFour, w105_0, w105_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one105 : Coverage 105 106 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases105)
private theorem w106_0 : checkWitness 106 false false 528 = true := by decide +kernel
private theorem w106_1 : checkWitness 106 false true 4624 = true := by decide +kernel
private theorem w106_2 : checkWitness 106 true false 528 = true := by decide +kernel
private theorem w106_3 : checkWitness 106 true true 4624 = true := by decide +kernel
private theorem cases106 : checkFour 106 (528,4624,528,4624) = true := by
  simp only [checkFour, w106_0, w106_1, w106_2, w106_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one106 : Coverage 106 107 := checkList_sound (ws:=[(528,4624,528,4624)]) (by simpa only [checkList, Bool.and_true] using cases106)
private theorem w107_0 : checkWitness 107 false false 8923 = true := by decide +kernel
private theorem w107_2 : checkWitness 107 true false 8919 = true := by decide +kernel
private theorem cases107 : checkFour 107 (8923,0,8919,0) = true := by
  simp only [checkFour, w107_0, w107_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one107 : Coverage 107 108 := checkList_sound (ws:=[(8923,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases107)
private theorem w108_0 : checkWitness 108 false false 654 = true := by decide +kernel
private theorem w108_1 : checkWitness 108 false true 4750 = true := by decide +kernel
private theorem w108_2 : checkWitness 108 true false 645 = true := by decide +kernel
private theorem w108_3 : checkWitness 108 true true 4741 = true := by decide +kernel
private theorem cases108 : checkFour 108 (654,4750,645,4741) = true := by
  simp only [checkFour, w108_0, w108_1, w108_2, w108_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one108 : Coverage 108 109 := checkList_sound (ws:=[(654,4750,645,4741)]) (by simpa only [checkList, Bool.and_true] using cases108)
private theorem w109_0 : checkWitness 109 false false 194 = true := by decide +kernel
private theorem w109_2 : checkWitness 109 true false 194 = true := by decide +kernel
private theorem cases109 : checkFour 109 (194,0,194,0) = true := by
  simp only [checkFour, w109_0, w109_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one109 : Coverage 109 110 := checkList_sound (ws:=[(194,0,194,0)]) (by simpa only [checkList, Bool.and_true] using cases109)
private theorem w110_0 : checkWitness 110 false false 609 = true := by decide +kernel
private theorem w110_1 : checkWitness 110 false true 4697 = true := by decide +kernel
private theorem w110_2 : checkWitness 110 true false 609 = true := by decide +kernel
private theorem w110_3 : checkWitness 110 true true 4697 = true := by decide +kernel
private theorem cases110 : checkFour 110 (609,4697,609,4697) = true := by
  simp only [checkFour, w110_0, w110_1, w110_2, w110_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one110 : Coverage 110 111 := checkList_sound (ws:=[(609,4697,609,4697)]) (by simpa only [checkList, Bool.and_true] using cases110)
private theorem w111_0 : checkWitness 111 false false 8938 = true := by decide +kernel
private theorem w111_2 : checkWitness 111 true false 8929 = true := by decide +kernel
private theorem cases111 : checkFour 111 (8938,0,8929,0) = true := by
  simp only [checkFour, w111_0, w111_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one111 : Coverage 111 112 := checkList_sound (ws:=[(8938,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases111)
private theorem w112_0 : checkWitness 112 false false 62 = true := by decide +kernel
private theorem w112_2 : checkWitness 112 true false 62 = true := by decide +kernel
private theorem cases112 : checkFour 112 (62,0,62,0) = true := by
  simp only [checkFour, w112_0, w112_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one112 : Coverage 112 113 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases112)
private theorem w113_0 : checkWitness 113 false false 54 = true := by decide +kernel
private theorem w113_2 : checkWitness 113 true false 54 = true := by decide +kernel
private theorem cases113 : checkFour 113 (54,0,54,0) = true := by
  simp only [checkFour, w113_0, w113_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one113 : Coverage 113 114 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases113)
private theorem w114_0 : checkWitness 114 false false 615 = true := by decide +kernel
private theorem w114_1 : checkWitness 114 false true 4707 = true := by decide +kernel
private theorem w114_2 : checkWitness 114 true false 615 = true := by decide +kernel
private theorem w114_3 : checkWitness 114 true true 4707 = true := by decide +kernel
private theorem cases114 : checkFour 114 (615,4707,615,4707) = true := by
  simp only [checkFour, w114_0, w114_1, w114_2, w114_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one114 : Coverage 114 115 := checkList_sound (ws:=[(615,4707,615,4707)]) (by simpa only [checkList, Bool.and_true] using cases114)
private theorem w115_0 : checkWitness 115 false false 8876 = true := by decide +kernel
private theorem w115_2 : checkWitness 115 true false 8872 = true := by decide +kernel
private theorem cases115 : checkFour 115 (8876,0,8872,0) = true := by
  simp only [checkFour, w115_0, w115_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one115 : Coverage 115 116 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases115)
private theorem w116_0 : checkWitness 116 false false 54 = true := by decide +kernel
private theorem w116_2 : checkWitness 116 true false 54 = true := by decide +kernel
private theorem cases116 : checkFour 116 (54,0,54,0) = true := by
  simp only [checkFour, w116_0, w116_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one116 : Coverage 116 117 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases116)
private theorem w117_0 : checkWitness 117 false false 570 = true := by decide +kernel
private theorem w117_1 : checkWitness 117 false true 4666 = true := by decide +kernel
private theorem w117_2 : checkWitness 117 true false 570 = true := by decide +kernel
private theorem w117_3 : checkWitness 117 true true 4666 = true := by decide +kernel
private theorem cases117 : checkFour 117 (570,4666,570,4666) = true := by
  simp only [checkFour, w117_0, w117_1, w117_2, w117_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one117 : Coverage 117 118 := checkList_sound (ws:=[(570,4666,570,4666)]) (by simpa only [checkList, Bool.and_true] using cases117)
private theorem w118_0 : checkWitness 118 false false 8911 = true := by decide +kernel
private theorem w118_2 : checkWitness 118 true false 8907 = true := by decide +kernel
private theorem cases118 : checkFour 118 (8911,0,8907,0) = true := by
  simp only [checkFour, w118_0, w118_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one118 : Coverage 118 119 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases118)
private theorem w119_0 : checkWitness 119 false false 8946 = true := by decide +kernel
private theorem w119_2 : checkWitness 119 true false 8937 = true := by decide +kernel
private theorem cases119 : checkFour 119 (8946,0,8937,0) = true := by
  simp only [checkFour, w119_0, w119_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one119 : Coverage 119 120 := checkList_sound (ws:=[(8946,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases119)
private theorem w120_0 : checkWitness 120 false false 72 = true := by decide +kernel
private theorem w120_2 : checkWitness 120 true false 72 = true := by decide +kernel
private theorem cases120 : checkFour 120 (72,0,72,0) = true := by
  simp only [checkFour, w120_0, w120_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one120 : Coverage 120 121 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases120)
private theorem w121_0 : checkWitness 121 false false 658 = true := by decide +kernel
private theorem w121_1 : checkWitness 121 false true 4750 = true := by decide +kernel
private theorem w121_2 : checkWitness 121 true false 649 = true := by decide +kernel
private theorem w121_3 : checkWitness 121 true true 4741 = true := by decide +kernel
private theorem cases121 : checkFour 121 (658,4750,649,4741) = true := by
  simp only [checkFour, w121_0, w121_1, w121_2, w121_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one121 : Coverage 121 122 := checkList_sound (ws:=[(658,4750,649,4741)]) (by simpa only [checkList, Bool.and_true] using cases121)
private theorem w122_0 : checkWitness 122 false false 8907 = true := by decide +kernel
private theorem w122_2 : checkWitness 122 true false 8903 = true := by decide +kernel
private theorem cases122 : checkFour 122 (8907,0,8903,0) = true := by
  simp only [checkFour, w122_0, w122_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one122 : Coverage 122 123 := checkList_sound (ws:=[(8907,0,8903,0)]) (by simpa only [checkList, Bool.and_true] using cases122)
private theorem w123_0 : checkWitness 123 false false 652 = true := by decide +kernel
private theorem w123_1 : checkWitness 123 false true 4744 = true := by decide +kernel
private theorem w123_2 : checkWitness 123 true false 643 = true := by decide +kernel
private theorem w123_3 : checkWitness 123 true true 4735 = true := by decide +kernel
private theorem cases123 : checkFour 123 (652,4744,643,4735) = true := by
  simp only [checkFour, w123_0, w123_1, w123_2, w123_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one123 : Coverage 123 124 := checkList_sound (ws:=[(652,4744,643,4735)]) (by simpa only [checkList, Bool.and_true] using cases123)
private theorem w124_0 : checkWitness 124 false false 8876 = true := by decide +kernel
private theorem w124_2 : checkWitness 124 true false 8872 = true := by decide +kernel
private theorem cases124 : checkFour 124 (8876,0,8872,0) = true := by
  simp only [checkFour, w124_0, w124_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one124 : Coverage 124 125 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases124)
private theorem w125_0 : checkWitness 125 false false 60 = true := by decide +kernel
private theorem w125_2 : checkWitness 125 true false 60 = true := by decide +kernel
private theorem cases125 : checkFour 125 (60,0,60,0) = true := by
  simp only [checkFour, w125_0, w125_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one125 : Coverage 125 126 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases125)
private theorem w126_0 : checkWitness 126 false false 52 = true := by decide +kernel
private theorem w126_2 : checkWitness 126 true false 52 = true := by decide +kernel
private theorem cases126 : checkFour 126 (52,0,52,0) = true := by
  simp only [checkFour, w126_0, w126_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one126 : Coverage 126 127 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases126)
private theorem w127_0 : checkWitness 127 false false 623 = true := by decide +kernel
private theorem w127_1 : checkWitness 127 false true 4707 = true := by decide +kernel
private theorem w127_2 : checkWitness 127 true false 623 = true := by decide +kernel
private theorem w127_3 : checkWitness 127 true true 4707 = true := by decide +kernel
private theorem cases127 : checkFour 127 (623,4707,623,4707) = true := by
  simp only [checkFour, w127_0, w127_1, w127_2, w127_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one127 : Coverage 127 128 := checkList_sound (ws:=[(623,4707,623,4707)]) (by simpa only [checkList, Bool.and_true] using cases127)
theorem cover0096 : Coverage 96 128 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one96 one97) (Coverage.join one98 one99)) (Coverage.join (Coverage.join one100 one101) (Coverage.join one102 one103))) (Coverage.join (Coverage.join (Coverage.join one104 one105) (Coverage.join one106 one107)) (Coverage.join (Coverage.join one108 one109) (Coverage.join one110 one111)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one112 one113) (Coverage.join one114 one115)) (Coverage.join (Coverage.join one116 one117) (Coverage.join one118 one119))) (Coverage.join (Coverage.join (Coverage.join one120 one121) (Coverage.join one122 one123)) (Coverage.join (Coverage.join one124 one125) (Coverage.join one126 one127)))))
end NF181PA.Symbolic
