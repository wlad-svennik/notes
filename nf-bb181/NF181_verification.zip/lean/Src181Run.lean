module
public import ModelSourceFields
public import ModelLiteralRegisters
public import NF181PARegisters

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.RegisterFields
set_option maxHeartbeats 3000000
set_option maxRecDepth 10000
namespace PA192.ModelSearch.Register181

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

export PA192.ModelSearch.RegisterSource (Instr config address cold registers vector readReg writeReg perform dispatch address_config cold_config registers_config readReg_other readReg_write)
noncomputable def step (s : V) := NF181PA.Registers.next s
instance stepDef : Language.DefinableFunction₁ ℒₒᵣ (step (V:=V)) := NF181PA.Registers.nextDef
abbrev program := NF181PA.Registers.program


def decoded : NF192.Emitter.Instruction → Instr
  | .inc r n => .inc r.val n
  | .dec r z n => .dec r.val z n
  | .decHalt r n => .dec r.val 4095 n
  | .jump n => .jump n
  | .halt => .inc 9 0

theorem row_of_literal (n : Nat) (i : NF192.Emitter.Instruction) (bound : n<2971)
    (h : Direct181Source.Literal.program n = i) : program[n]? = some (decoded i) := by
  apply (NF181PA.Registers.program_at ⟨n,bound⟩).trans
  unfold NF181PA.Registers.instruction Direct181Source.Raw.program
  rw [h]
  cases i <;> rfl

theorem step_at (i : Nat) (op : Instr) (h : program[i]?=some op) (f r : V) :
    step (config (i:V) f r)=perform op f r := by
  simpa [step,NF181PA.Registers.next] using RegisterSource.dispatch_get program i op h f r

@[simp] theorem step_terminal (f r : V) : step (config 4095 f r)=config 4095 f r := by
  simp only [step,NF181PA.Registers.next,address_config,cold_config,registers_config]
  apply RegisterSource.dispatch_falloff
  rw [NF181PA.Registers.program_length]
  have h : (2971 : Nat) ≤ 4095 := by decide
  exact_mod_cast h

/-- Internal source clock and exact literal source execution, including nonstandard times. -/
noncomputable def run (time initial : V) : V := iterate step time initial
instance runDef : Language.DefinableFunction₂ ℒₒᵣ (run (V:=V)) := by unfold run; infer_instance
@[simp] theorem run_zero (e : V) : run 0 e=e := iterate_zero step e
theorem run_succ (t e : V) : run (t+1) e=step (run t e) := iterate_succ step t e
theorem run_succ_left (t e : V) : run (t+1) e=run t (step e) := iterate_succ_left step t e
theorem run_add (a b e : V) : run (a+b) e=run b (run a e) := iterate_add step a e b

theorem run_terminal (f r : V) (t : V) : run t (config 4095 f r)=config 4095 f r := by
  induction t using modelInduct
  case defP => definability
  case zero => simp
  case step t ih => rw [run_succ,ih,step_terminal]

def sourceHalts (x : V) : Prop := ∃ t : V, address (run t x)=4095

end PA192.ModelSearch.Register181
#print axioms PA192.ModelSearch.Register181.step_at
#print axioms PA192.ModelSearch.Register181.run_terminal
