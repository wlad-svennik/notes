import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1504_0 : checkWitness 1504 false false 98 = true := by decide +kernel
private theorem w1504_2 : checkWitness 1504 true false 98 = true := by decide +kernel
private theorem cases1504 : checkFour 1504 (98,0,98,0) = true := by
  simp only [checkFour, w1504_0, w1504_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1504 : Coverage 1504 1505 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1504)
private theorem w1505_0 : checkWitness 1505 false false 583 = true := by decide +kernel
private theorem w1505_1 : checkWitness 1505 false true 4675 = true := by decide +kernel
private theorem w1505_2 : checkWitness 1505 true false 574 = true := by decide +kernel
private theorem w1505_3 : checkWitness 1505 true true 4666 = true := by decide +kernel
private theorem cases1505 : checkFour 1505 (583,4675,574,4666) = true := by
  simp only [checkFour, w1505_0, w1505_1, w1505_2, w1505_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1505 : Coverage 1505 1506 := checkList_sound (ws:=[(583,4675,574,4666)]) (by simpa only [checkList, Bool.and_true] using cases1505)
private theorem w1506_0 : checkWitness 1506 false false 8880 = true := by decide +kernel
private theorem w1506_2 : checkWitness 1506 true false 8871 = true := by decide +kernel
private theorem cases1506 : checkFour 1506 (8880,0,8871,0) = true := by
  simp only [checkFour, w1506_0, w1506_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1506 : Coverage 1506 1507 := checkList_sound (ws:=[(8880,0,8871,0)]) (by simpa only [checkList, Bool.and_true] using cases1506)
private theorem w1507_0 : checkWitness 1507 false false 8826 = true := by decide +kernel
private theorem w1507_2 : checkWitness 1507 true false 8822 = true := by decide +kernel
private theorem cases1507 : checkFour 1507 (8826,0,8822,0) = true := by
  simp only [checkFour, w1507_0, w1507_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1507 : Coverage 1507 1508 := checkList_sound (ws:=[(8826,0,8822,0)]) (by simpa only [checkList, Bool.and_true] using cases1507)
private theorem w1508_0 : checkWitness 1508 false false 92 = true := by decide +kernel
private theorem w1508_2 : checkWitness 1508 true false 92 = true := by decide +kernel
private theorem cases1508 : checkFour 1508 (92,0,92,0) = true := by
  simp only [checkFour, w1508_0, w1508_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1508 : Coverage 1508 1509 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1508)
private theorem w1509_0 : checkWitness 1509 false false 610 = true := by decide +kernel
private theorem w1509_1 : checkWitness 1509 false true 4702 = true := by decide +kernel
private theorem w1509_2 : checkWitness 1509 true false 601 = true := by decide +kernel
private theorem w1509_3 : checkWitness 1509 true true 4693 = true := by decide +kernel
private theorem cases1509 : checkFour 1509 (610,4702,601,4693) = true := by
  simp only [checkFour, w1509_0, w1509_1, w1509_2, w1509_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1509 : Coverage 1509 1510 := checkList_sound (ws:=[(610,4702,601,4693)]) (by simpa only [checkList, Bool.and_true] using cases1509)
private theorem w1510_0 : checkWitness 1510 false false 8887 = true := by decide +kernel
private theorem w1510_2 : checkWitness 1510 true false 8878 = true := by decide +kernel
private theorem cases1510 : checkFour 1510 (8887,0,8878,0) = true := by
  simp only [checkFour, w1510_0, w1510_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1510 : Coverage 1510 1511 := checkList_sound (ws:=[(8887,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases1510)
private theorem w1511_0 : checkWitness 1511 false false 76 = true := by decide +kernel
private theorem w1511_2 : checkWitness 1511 true false 76 = true := by decide +kernel
private theorem cases1511 : checkFour 1511 (76,0,76,0) = true := by
  simp only [checkFour, w1511_0, w1511_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1511 : Coverage 1511 1512 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1511)
private theorem w1512_0 : checkWitness 1512 false false 474 = true := by decide +kernel
private theorem w1512_1 : checkWitness 1512 false true 4570 = true := by decide +kernel
private theorem w1512_2 : checkWitness 1512 true false 474 = true := by decide +kernel
private theorem w1512_3 : checkWitness 1512 true true 4570 = true := by decide +kernel
private theorem cases1512 : checkFour 1512 (474,4570,474,4570) = true := by
  simp only [checkFour, w1512_0, w1512_1, w1512_2, w1512_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1512 : Coverage 1512 1513 := checkList_sound (ws:=[(474,4570,474,4570)]) (by simpa only [checkList, Bool.and_true] using cases1512)
private theorem w1513_0 : checkWitness 1513 false false 8869 = true := by decide +kernel
private theorem w1513_2 : checkWitness 1513 true false 8865 = true := by decide +kernel
private theorem cases1513 : checkFour 1513 (8869,0,8865,0) = true := by
  simp only [checkFour, w1513_0, w1513_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1513 : Coverage 1513 1514 := checkList_sound (ws:=[(8869,0,8865,0)]) (by simpa only [checkList, Bool.and_true] using cases1513)
private theorem w1514_0 : checkWitness 1514 false false 600 = true := by decide +kernel
private theorem w1514_1 : checkWitness 1514 false true 4696 = true := by decide +kernel
private theorem w1514_2 : checkWitness 1514 true false 591 = true := by decide +kernel
private theorem w1514_3 : checkWitness 1514 true true 4687 = true := by decide +kernel
private theorem cases1514 : checkFour 1514 (600,4696,591,4687) = true := by
  simp only [checkFour, w1514_0, w1514_1, w1514_2, w1514_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1514 : Coverage 1514 1515 := checkList_sound (ws:=[(600,4696,591,4687)]) (by simpa only [checkList, Bool.and_true] using cases1514)
private theorem w1515_0 : checkWitness 1515 false false 166 = true := by decide +kernel
private theorem w1515_2 : checkWitness 1515 true false 166 = true := by decide +kernel
private theorem cases1515 : checkFour 1515 (166,0,166,0) = true := by
  simp only [checkFour, w1515_0, w1515_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1515 : Coverage 1515 1516 := checkList_sound (ws:=[(166,0,166,0)]) (by simpa only [checkList, Bool.and_true] using cases1515)
private theorem w1516_0 : checkWitness 1516 false false 555 = true := by decide +kernel
private theorem w1516_1 : checkWitness 1516 false true 4643 = true := by decide +kernel
private theorem w1516_2 : checkWitness 1516 true false 555 = true := by decide +kernel
private theorem w1516_3 : checkWitness 1516 true true 4643 = true := by decide +kernel
private theorem cases1516 : checkFour 1516 (555,4643,555,4643) = true := by
  simp only [checkFour, w1516_0, w1516_1, w1516_2, w1516_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1516 : Coverage 1516 1517 := checkList_sound (ws:=[(555,4643,555,4643)]) (by simpa only [checkList, Bool.and_true] using cases1516)
private theorem w1517_0 : checkWitness 1517 false false 8884 = true := by decide +kernel
private theorem w1517_2 : checkWitness 1517 true false 8875 = true := by decide +kernel
private theorem cases1517 : checkFour 1517 (8884,0,8875,0) = true := by
  simp only [checkFour, w1517_0, w1517_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1517 : Coverage 1517 1518 := checkList_sound (ws:=[(8884,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases1517)
private theorem w1518_0 : checkWitness 1518 false false 94 = true := by decide +kernel
private theorem w1518_2 : checkWitness 1518 true false 94 = true := by decide +kernel
private theorem cases1518 : checkFour 1518 (94,0,94,0) = true := by
  simp only [checkFour, w1518_0, w1518_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1518 : Coverage 1518 1519 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1518)
private theorem w1519_0 : checkWitness 1519 false false 86 = true := by decide +kernel
private theorem w1519_2 : checkWitness 1519 true false 86 = true := by decide +kernel
private theorem cases1519 : checkFour 1519 (86,0,86,0) = true := by
  simp only [checkFour, w1519_0, w1519_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1519 : Coverage 1519 1520 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1519)
private theorem w1520_0 : checkWitness 1520 false false 561 = true := by decide +kernel
private theorem w1520_1 : checkWitness 1520 false true 4653 = true := by decide +kernel
private theorem w1520_2 : checkWitness 1520 true false 561 = true := by decide +kernel
private theorem w1520_3 : checkWitness 1520 true true 4653 = true := by decide +kernel
private theorem cases1520 : checkFour 1520 (561,4653,561,4653) = true := by
  simp only [checkFour, w1520_0, w1520_1, w1520_2, w1520_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1520 : Coverage 1520 1521 := checkList_sound (ws:=[(561,4653,561,4653)]) (by simpa only [checkList, Bool.and_true] using cases1520)
private theorem w1521_0 : checkWitness 1521 false false 8822 = true := by decide +kernel
private theorem w1521_2 : checkWitness 1521 true false 8818 = true := by decide +kernel
private theorem cases1521 : checkFour 1521 (8822,0,8818,0) = true := by
  simp only [checkFour, w1521_0, w1521_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1521 : Coverage 1521 1522 := checkList_sound (ws:=[(8822,0,8818,0)]) (by simpa only [checkList, Bool.and_true] using cases1521)
private theorem w1522_0 : checkWitness 1522 false false 86 = true := by decide +kernel
private theorem w1522_2 : checkWitness 1522 true false 86 = true := by decide +kernel
private theorem cases1522 : checkFour 1522 (86,0,86,0) = true := by
  simp only [checkFour, w1522_0, w1522_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1522 : Coverage 1522 1523 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1522)
private theorem w1523_0 : checkWitness 1523 false false 516 = true := by decide +kernel
private theorem w1523_1 : checkWitness 1523 false true 4612 = true := by decide +kernel
private theorem w1523_2 : checkWitness 1523 true false 516 = true := by decide +kernel
private theorem w1523_3 : checkWitness 1523 true true 4612 = true := by decide +kernel
private theorem cases1523 : checkFour 1523 (516,4612,516,4612) = true := by
  simp only [checkFour, w1523_0, w1523_1, w1523_2, w1523_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1523 : Coverage 1523 1524 := checkList_sound (ws:=[(516,4612,516,4612)]) (by simpa only [checkList, Bool.and_true] using cases1523)
private theorem w1524_0 : checkWitness 1524 false false 8857 = true := by decide +kernel
private theorem w1524_2 : checkWitness 1524 true false 8853 = true := by decide +kernel
private theorem cases1524 : checkFour 1524 (8857,0,8853,0) = true := by
  simp only [checkFour, w1524_0, w1524_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1524 : Coverage 1524 1525 := checkList_sound (ws:=[(8857,0,8853,0)]) (by simpa only [checkList, Bool.and_true] using cases1524)
private theorem w1525_0 : checkWitness 1525 false false 8892 = true := by decide +kernel
private theorem w1525_2 : checkWitness 1525 true false 8883 = true := by decide +kernel
private theorem cases1525 : checkFour 1525 (8892,0,8883,0) = true := by
  simp only [checkFour, w1525_0, w1525_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1525 : Coverage 1525 1526 := checkList_sound (ws:=[(8892,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1525)
private theorem w1526_0 : checkWitness 1526 false false 104 = true := by decide +kernel
private theorem w1526_2 : checkWitness 1526 true false 104 = true := by decide +kernel
private theorem cases1526 : checkFour 1526 (104,0,104,0) = true := by
  simp only [checkFour, w1526_0, w1526_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1526 : Coverage 1526 1527 := checkList_sound (ws:=[(104,0,104,0)]) (by simpa only [checkList, Bool.and_true] using cases1526)
private theorem w1527_0 : checkWitness 1527 false false 604 = true := by decide +kernel
private theorem w1527_1 : checkWitness 1527 false true 4696 = true := by decide +kernel
private theorem w1527_2 : checkWitness 1527 true false 595 = true := by decide +kernel
private theorem w1527_3 : checkWitness 1527 true true 4687 = true := by decide +kernel
private theorem cases1527 : checkFour 1527 (604,4696,595,4687) = true := by
  simp only [checkFour, w1527_0, w1527_1, w1527_2, w1527_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1527 : Coverage 1527 1528 := checkList_sound (ws:=[(604,4696,595,4687)]) (by simpa only [checkList, Bool.and_true] using cases1527)
private theorem w1528_0 : checkWitness 1528 false false 8853 = true := by decide +kernel
private theorem w1528_2 : checkWitness 1528 true false 8849 = true := by decide +kernel
private theorem cases1528 : checkFour 1528 (8853,0,8849,0) = true := by
  simp only [checkFour, w1528_0, w1528_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1528 : Coverage 1528 1529 := checkList_sound (ws:=[(8853,0,8849,0)]) (by simpa only [checkList, Bool.and_true] using cases1528)
private theorem w1529_0 : checkWitness 1529 false false 598 = true := by decide +kernel
private theorem w1529_1 : checkWitness 1529 false true 4690 = true := by decide +kernel
private theorem w1529_2 : checkWitness 1529 true false 589 = true := by decide +kernel
private theorem w1529_3 : checkWitness 1529 true true 4681 = true := by decide +kernel
private theorem cases1529 : checkFour 1529 (598,4690,589,4681) = true := by
  simp only [checkFour, w1529_0, w1529_1, w1529_2, w1529_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1529 : Coverage 1529 1530 := checkList_sound (ws:=[(598,4690,589,4681)]) (by simpa only [checkList, Bool.and_true] using cases1529)
private theorem w1530_0 : checkWitness 1530 false false 8822 = true := by decide +kernel
private theorem w1530_2 : checkWitness 1530 true false 8818 = true := by decide +kernel
private theorem cases1530 : checkFour 1530 (8822,0,8818,0) = true := by
  simp only [checkFour, w1530_0, w1530_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1530 : Coverage 1530 1531 := checkList_sound (ws:=[(8822,0,8818,0)]) (by simpa only [checkList, Bool.and_true] using cases1530)
private theorem w1531_0 : checkWitness 1531 false false 92 = true := by decide +kernel
private theorem w1531_2 : checkWitness 1531 true false 92 = true := by decide +kernel
private theorem cases1531 : checkFour 1531 (92,0,92,0) = true := by
  simp only [checkFour, w1531_0, w1531_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1531 : Coverage 1531 1532 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1531)
private theorem w1532_0 : checkWitness 1532 false false 84 = true := by decide +kernel
private theorem w1532_2 : checkWitness 1532 true false 84 = true := by decide +kernel
private theorem cases1532 : checkFour 1532 (84,0,84,0) = true := by
  simp only [checkFour, w1532_0, w1532_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1532 : Coverage 1532 1533 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1532)
private theorem w1533_0 : checkWitness 1533 false false 565 = true := by decide +kernel
private theorem w1533_1 : checkWitness 1533 false true 4653 = true := by decide +kernel
private theorem w1533_2 : checkWitness 1533 true false 565 = true := by decide +kernel
private theorem w1533_3 : checkWitness 1533 true true 4653 = true := by decide +kernel
private theorem cases1533 : checkFour 1533 (565,4653,565,4653) = true := by
  simp only [checkFour, w1533_0, w1533_1, w1533_2, w1533_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1533 : Coverage 1533 1534 := checkList_sound (ws:=[(565,4653,565,4653)]) (by simpa only [checkList, Bool.and_true] using cases1533)
private theorem w1534_0 : checkWitness 1534 false false 8838 = true := by decide +kernel
private theorem w1534_2 : checkWitness 1534 true false 8834 = true := by decide +kernel
private theorem cases1534 : checkFour 1534 (8838,0,8834,0) = true := by
  simp only [checkFour, w1534_0, w1534_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1534 : Coverage 1534 1535 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1534)
private theorem w1535_0 : checkWitness 1535 false false 8834 = true := by decide +kernel
private theorem w1535_2 : checkWitness 1535 true false 8830 = true := by decide +kernel
private theorem cases1535 : checkFour 1535 (8834,0,8830,0) = true := by
  simp only [checkFour, w1535_0, w1535_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1535 : Coverage 1535 1536 := checkList_sound (ws:=[(8834,0,8830,0)]) (by simpa only [checkList, Bool.and_true] using cases1535)
theorem cover1504 : Coverage 1504 1536 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1504 one1505) (Coverage.join one1506 one1507)) (Coverage.join (Coverage.join one1508 one1509) (Coverage.join one1510 one1511))) (Coverage.join (Coverage.join (Coverage.join one1512 one1513) (Coverage.join one1514 one1515)) (Coverage.join (Coverage.join one1516 one1517) (Coverage.join one1518 one1519)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1520 one1521) (Coverage.join one1522 one1523)) (Coverage.join (Coverage.join one1524 one1525) (Coverage.join one1526 one1527))) (Coverage.join (Coverage.join (Coverage.join one1528 one1529) (Coverage.join one1530 one1531)) (Coverage.join (Coverage.join one1532 one1533) (Coverage.join one1534 one1535)))))
end NF181PA.Symbolic
