import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2752_0 : checkWitness 2752 false false 610 = true := by decide +kernel
private theorem w2752_1 : checkWitness 2752 false true 4706 = true := by decide +kernel
private theorem w2752_2 : checkWitness 2752 true false 610 = true := by decide +kernel
private theorem w2752_3 : checkWitness 2752 true true 4706 = true := by decide +kernel
private theorem cases2752 : checkFour 2752 (610,4706,610,4706) = true := by
  simp only [checkFour, w2752_0, w2752_1, w2752_2, w2752_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2752 : Coverage 2752 2753 := checkList_sound (ws:=[(610,4706,610,4706)]) (by simpa only [checkList, Bool.and_true] using cases2752)
private theorem w2753_0 : checkWitness 2753 false false 8951 = true := by decide +kernel
private theorem w2753_2 : checkWitness 2753 true false 8947 = true := by decide +kernel
private theorem cases2753 : checkFour 2753 (8951,0,8947,0) = true := by
  simp only [checkFour, w2753_0, w2753_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2753 : Coverage 2753 2754 := checkList_sound (ws:=[(8951,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2753)
private theorem w2754_0 : checkWitness 2754 false false 8986 = true := by decide +kernel
private theorem w2754_2 : checkWitness 2754 true false 8977 = true := by decide +kernel
private theorem cases2754 : checkFour 2754 (8986,0,8977,0) = true := by
  simp only [checkFour, w2754_0, w2754_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2754 : Coverage 2754 2755 := checkList_sound (ws:=[(8986,0,8977,0)]) (by simpa only [checkList, Bool.and_true] using cases2754)
private theorem w2755_0 : checkWitness 2755 false false 82 = true := by decide +kernel
private theorem w2755_2 : checkWitness 2755 true false 82 = true := by decide +kernel
private theorem cases2755 : checkFour 2755 (82,0,82,0) = true := by
  simp only [checkFour, w2755_0, w2755_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2755 : Coverage 2755 2756 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2755)
private theorem w2756_0 : checkWitness 2756 false false 698 = true := by decide +kernel
private theorem w2756_1 : checkWitness 2756 false true 4790 = true := by decide +kernel
private theorem w2756_2 : checkWitness 2756 true false 689 = true := by decide +kernel
private theorem w2756_3 : checkWitness 2756 true true 4781 = true := by decide +kernel
private theorem cases2756 : checkFour 2756 (698,4790,689,4781) = true := by
  simp only [checkFour, w2756_0, w2756_1, w2756_2, w2756_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2756 : Coverage 2756 2757 := checkList_sound (ws:=[(698,4790,689,4781)]) (by simpa only [checkList, Bool.and_true] using cases2756)
private theorem w2757_0 : checkWitness 2757 false false 8947 = true := by decide +kernel
private theorem w2757_2 : checkWitness 2757 true false 8943 = true := by decide +kernel
private theorem cases2757 : checkFour 2757 (8947,0,8943,0) = true := by
  simp only [checkFour, w2757_0, w2757_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2757 : Coverage 2757 2758 := checkList_sound (ws:=[(8947,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases2757)
private theorem w2758_0 : checkWitness 2758 false false 692 = true := by decide +kernel
private theorem w2758_1 : checkWitness 2758 false true 4784 = true := by decide +kernel
private theorem w2758_2 : checkWitness 2758 true false 683 = true := by decide +kernel
private theorem w2758_3 : checkWitness 2758 true true 4775 = true := by decide +kernel
private theorem cases2758 : checkFour 2758 (692,4784,683,4775) = true := by
  simp only [checkFour, w2758_0, w2758_1, w2758_2, w2758_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2758 : Coverage 2758 2759 := checkList_sound (ws:=[(692,4784,683,4775)]) (by simpa only [checkList, Bool.and_true] using cases2758)
private theorem w2759_0 : checkWitness 2759 false false 8916 = true := by decide +kernel
private theorem w2759_2 : checkWitness 2759 true false 8912 = true := by decide +kernel
private theorem cases2759 : checkFour 2759 (8916,0,8912,0) = true := by
  simp only [checkFour, w2759_0, w2759_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2759 : Coverage 2759 2760 := checkList_sound (ws:=[(8916,0,8912,0)]) (by simpa only [checkList, Bool.and_true] using cases2759)
private theorem w2760_0 : checkWitness 2760 false false 70 = true := by decide +kernel
private theorem w2760_2 : checkWitness 2760 true false 70 = true := by decide +kernel
private theorem cases2760 : checkFour 2760 (70,0,70,0) = true := by
  simp only [checkFour, w2760_0, w2760_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2760 : Coverage 2760 2761 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2760)
private theorem w2761_0 : checkWitness 2761 false false 62 = true := by decide +kernel
private theorem w2761_2 : checkWitness 2761 true false 62 = true := by decide +kernel
private theorem cases2761 : checkFour 2761 (62,0,62,0) = true := by
  simp only [checkFour, w2761_0, w2761_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2761 : Coverage 2761 2762 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2761)
private theorem w2762_0 : checkWitness 2762 false false 657 = true := by decide +kernel
private theorem w2762_1 : checkWitness 2762 false true 4741 = true := by decide +kernel
private theorem w2762_2 : checkWitness 2762 true false 657 = true := by decide +kernel
private theorem w2762_3 : checkWitness 2762 true true 4741 = true := by decide +kernel
private theorem cases2762 : checkFour 2762 (657,4741,657,4741) = true := by
  simp only [checkFour, w2762_0, w2762_1, w2762_2, w2762_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2762 : Coverage 2762 2763 := checkList_sound (ws:=[(657,4741,657,4741)]) (by simpa only [checkList, Bool.and_true] using cases2762)
private theorem w2763_0 : checkWitness 2763 false false 8910 = true := by decide +kernel
private theorem w2763_2 : checkWitness 2763 true false 8906 = true := by decide +kernel
private theorem cases2763 : checkFour 2763 (8910,0,8906,0) = true := by
  simp only [checkFour, w2763_0, w2763_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2763 : Coverage 2763 2764 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases2763)
private theorem w2764_0 : checkWitness 2764 false false 62 = true := by decide +kernel
private theorem w2764_2 : checkWitness 2764 true false 62 = true := by decide +kernel
private theorem cases2764 : checkFour 2764 (62,0,62,0) = true := by
  simp only [checkFour, w2764_0, w2764_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2764 : Coverage 2764 2765 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2764)
private theorem w2765_0 : checkWitness 2765 false false 625 = true := by decide +kernel
private theorem w2765_1 : checkWitness 2765 false true 4721 = true := by decide +kernel
private theorem w2765_2 : checkWitness 2765 true false 625 = true := by decide +kernel
private theorem w2765_3 : checkWitness 2765 true true 4721 = true := by decide +kernel
private theorem cases2765 : checkFour 2765 (625,4721,625,4721) = true := by
  simp only [checkFour, w2765_0, w2765_1, w2765_2, w2765_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2765 : Coverage 2765 2766 := checkList_sound (ws:=[(625,4721,625,4721)]) (by simpa only [checkList, Bool.and_true] using cases2765)
private theorem w2766_0 : checkWitness 2766 false false 8978 = true := by decide +kernel
private theorem w2766_2 : checkWitness 2766 true false 8969 = true := by decide +kernel
private theorem cases2766 : checkFour 2766 (8978,0,8969,0) = true := by
  simp only [checkFour, w2766_0, w2766_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2766 : Coverage 2766 2767 := checkList_sound (ws:=[(8978,0,8969,0)]) (by simpa only [checkList, Bool.and_true] using cases2766)
private theorem w2767_0 : checkWitness 2767 false false 8924 = true := by decide +kernel
private theorem w2767_2 : checkWitness 2767 true false 8920 = true := by decide +kernel
private theorem cases2767 : checkFour 2767 (8924,0,8920,0) = true := by
  simp only [checkFour, w2767_0, w2767_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2767 : Coverage 2767 2768 := checkList_sound (ws:=[(8924,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases2767)
private theorem w2768_0 : checkWitness 2768 false false 70 = true := by decide +kernel
private theorem w2768_2 : checkWitness 2768 true false 70 = true := by decide +kernel
private theorem cases2768 : checkFour 2768 (70,0,70,0) = true := by
  simp only [checkFour, w2768_0, w2768_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2768 : Coverage 2768 2769 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2768)
private theorem w2769_0 : checkWitness 2769 false false 708 = true := by decide +kernel
private theorem w2769_1 : checkWitness 2769 false true 4796 = true := by decide +kernel
private theorem w2769_2 : checkWitness 2769 true false 699 = true := by decide +kernel
private theorem w2769_3 : checkWitness 2769 true true 4787 = true := by decide +kernel
private theorem cases2769 : checkFour 2769 (708,4796,699,4787) = true := by
  simp only [checkFour, w2769_0, w2769_1, w2769_2, w2769_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2769 : Coverage 2769 2770 := checkList_sound (ws:=[(708,4796,699,4787)]) (by simpa only [checkList, Bool.and_true] using cases2769)
private theorem w2770_0 : checkWitness 2770 false false 8943 = true := by decide +kernel
private theorem w2770_2 : checkWitness 2770 true false 8939 = true := by decide +kernel
private theorem cases2770 : checkFour 2770 (8943,0,8939,0) = true := by
  simp only [checkFour, w2770_0, w2770_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2770 : Coverage 2770 2771 := checkList_sound (ws:=[(8943,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2770)
private theorem w2771_0 : checkWitness 2771 false false 60 = true := by decide +kernel
private theorem w2771_2 : checkWitness 2771 true false 60 = true := by decide +kernel
private theorem cases2771 : checkFour 2771 (60,0,60,0) = true := by
  simp only [checkFour, w2771_0, w2771_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2771 : Coverage 2771 2772 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2771)
private theorem w2772_0 : checkWitness 2772 false false 572 = true := by decide +kernel
private theorem w2772_1 : checkWitness 2772 false true 4668 = true := by decide +kernel
private theorem w2772_2 : checkWitness 2772 true false 572 = true := by decide +kernel
private theorem w2772_3 : checkWitness 2772 true true 4668 = true := by decide +kernel
private theorem cases2772 : checkFour 2772 (572,4668,572,4668) = true := by
  simp only [checkFour, w2772_0, w2772_1, w2772_2, w2772_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2772 : Coverage 2772 2773 := checkList_sound (ws:=[(572,4668,572,4668)]) (by simpa only [checkList, Bool.and_true] using cases2772)
private theorem w2773_0 : checkWitness 2773 false false 8988 = true := by decide +kernel
private theorem w2773_2 : checkWitness 2773 true false 8979 = true := by decide +kernel
private theorem cases2773 : checkFour 2773 (8988,0,8979,0) = true := by
  simp only [checkFour, w2773_0, w2773_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2773 : Coverage 2773 2774 := checkList_sound (ws:=[(8988,0,8979,0)]) (by simpa only [checkList, Bool.and_true] using cases2773)
private theorem w2774_0 : checkWitness 2774 false false 62 = true := by decide +kernel
private theorem w2774_2 : checkWitness 2774 true false 62 = true := by decide +kernel
private theorem cases2774 : checkFour 2774 (62,0,62,0) = true := by
  simp only [checkFour, w2774_0, w2774_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2774 : Coverage 2774 2775 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2774)
private theorem w2775_0 : checkWitness 2775 false false 570 = true := by decide +kernel
private theorem w2775_1 : checkWitness 2775 false true 4666 = true := by decide +kernel
private theorem w2775_2 : checkWitness 2775 true false 570 = true := by decide +kernel
private theorem w2775_3 : checkWitness 2775 true true 4666 = true := by decide +kernel
private theorem cases2775 : checkFour 2775 (570,4666,570,4666) = true := by
  simp only [checkFour, w2775_0, w2775_1, w2775_2, w2775_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2775 : Coverage 2775 2776 := checkList_sound (ws:=[(570,4666,570,4666)]) (by simpa only [checkList, Bool.and_true] using cases2775)
private theorem w2776_0 : checkWitness 2776 false false 8928 = true := by decide +kernel
private theorem w2776_2 : checkWitness 2776 true false 8924 = true := by decide +kernel
private theorem cases2776 : checkFour 2776 (8928,0,8924,0) = true := by
  simp only [checkFour, w2776_0, w2776_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2776 : Coverage 2776 2777 := checkList_sound (ws:=[(8928,0,8924,0)]) (by simpa only [checkList, Bool.and_true] using cases2776)
private theorem w2777_0 : checkWitness 2777 false false 64 = true := by decide +kernel
private theorem w2777_2 : checkWitness 2777 true false 64 = true := by decide +kernel
private theorem cases2777 : checkFour 2777 (64,0,64,0) = true := by
  simp only [checkFour, w2777_0, w2777_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2777 : Coverage 2777 2778 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2777)
private theorem w2778_0 : checkWitness 2778 false false 608 = true := by decide +kernel
private theorem w2778_1 : checkWitness 2778 false true 4704 = true := by decide +kernel
private theorem w2778_2 : checkWitness 2778 true false 608 = true := by decide +kernel
private theorem w2778_3 : checkWitness 2778 true true 4704 = true := by decide +kernel
private theorem cases2778 : checkFour 2778 (608,4704,608,4704) = true := by
  simp only [checkFour, w2778_0, w2778_1, w2778_2, w2778_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2778 : Coverage 2778 2779 := checkList_sound (ws:=[(608,4704,608,4704)]) (by simpa only [checkList, Bool.and_true] using cases2778)
private theorem w2779_0 : checkWitness 2779 false false 8949 = true := by decide +kernel
private theorem w2779_2 : checkWitness 2779 true false 8945 = true := by decide +kernel
private theorem cases2779 : checkFour 2779 (8949,0,8945,0) = true := by
  simp only [checkFour, w2779_0, w2779_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2779 : Coverage 2779 2780 := checkList_sound (ws:=[(8949,0,8945,0)]) (by simpa only [checkList, Bool.and_true] using cases2779)
private theorem w2780_0 : checkWitness 2780 false false 8984 = true := by decide +kernel
private theorem w2780_2 : checkWitness 2780 true false 8975 = true := by decide +kernel
private theorem cases2780 : checkFour 2780 (8984,0,8975,0) = true := by
  simp only [checkFour, w2780_0, w2780_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2780 : Coverage 2780 2781 := checkList_sound (ws:=[(8984,0,8975,0)]) (by simpa only [checkList, Bool.and_true] using cases2780)
private theorem w2781_0 : checkWitness 2781 false false 88 = true := by decide +kernel
private theorem w2781_2 : checkWitness 2781 true false 88 = true := by decide +kernel
private theorem cases2781 : checkFour 2781 (88,0,88,0) = true := by
  simp only [checkFour, w2781_0, w2781_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2781 : Coverage 2781 2782 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases2781)
private theorem w2782_0 : checkWitness 2782 false false 696 = true := by decide +kernel
private theorem w2782_1 : checkWitness 2782 false true 4788 = true := by decide +kernel
private theorem w2782_2 : checkWitness 2782 true false 687 = true := by decide +kernel
private theorem w2782_3 : checkWitness 2782 true true 4779 = true := by decide +kernel
private theorem cases2782 : checkFour 2782 (696,4788,687,4779) = true := by
  simp only [checkFour, w2782_0, w2782_1, w2782_2, w2782_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2782 : Coverage 2782 2783 := checkList_sound (ws:=[(696,4788,687,4779)]) (by simpa only [checkList, Bool.and_true] using cases2782)
private theorem w2783_0 : checkWitness 2783 false false 8945 = true := by decide +kernel
private theorem w2783_2 : checkWitness 2783 true false 8941 = true := by decide +kernel
private theorem cases2783 : checkFour 2783 (8945,0,8941,0) = true := by
  simp only [checkFour, w2783_0, w2783_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2783 : Coverage 2783 2784 := checkList_sound (ws:=[(8945,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases2783)
theorem cover2752 : Coverage 2752 2784 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2752 one2753) (Coverage.join one2754 one2755)) (Coverage.join (Coverage.join one2756 one2757) (Coverage.join one2758 one2759))) (Coverage.join (Coverage.join (Coverage.join one2760 one2761) (Coverage.join one2762 one2763)) (Coverage.join (Coverage.join one2764 one2765) (Coverage.join one2766 one2767)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2768 one2769) (Coverage.join one2770 one2771)) (Coverage.join (Coverage.join one2772 one2773) (Coverage.join one2774 one2775))) (Coverage.join (Coverage.join (Coverage.join one2776 one2777) (Coverage.join one2778 one2779)) (Coverage.join (Coverage.join one2780 one2781) (Coverage.join one2782 one2783)))))
end NF181PA.Symbolic
