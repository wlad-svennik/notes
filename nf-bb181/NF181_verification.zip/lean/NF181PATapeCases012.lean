import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w384_0 : checkWitness 384 false false 8880 = true := by decide +kernel
private theorem w384_2 : checkWitness 384 true false 8876 = true := by decide +kernel
private theorem cases384 : checkFour 384 (8880,0,8876,0) = true := by
  simp only [checkFour, w384_0, w384_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one384 : Coverage 384 385 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases384)
private theorem w385_0 : checkWitness 385 false false 62 = true := by decide +kernel
private theorem w385_2 : checkWitness 385 true false 62 = true := by decide +kernel
private theorem cases385 : checkFour 385 (62,0,62,0) = true := by
  simp only [checkFour, w385_0, w385_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one385 : Coverage 385 386 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases385)
private theorem w386_0 : checkWitness 386 false false 574 = true := by decide +kernel
private theorem w386_1 : checkWitness 386 false true 4670 = true := by decide +kernel
private theorem w386_2 : checkWitness 386 true false 574 = true := by decide +kernel
private theorem w386_3 : checkWitness 386 true true 4670 = true := by decide +kernel
private theorem cases386 : checkFour 386 (574,4670,574,4670) = true := by
  simp only [checkFour, w386_0, w386_1, w386_2, w386_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one386 : Coverage 386 387 := checkList_sound (ws:=[(574,4670,574,4670)]) (by simpa only [checkList, Bool.and_true] using cases386)
private theorem w387_0 : checkWitness 387 false false 8915 = true := by decide +kernel
private theorem w387_2 : checkWitness 387 true false 8911 = true := by decide +kernel
private theorem cases387 : checkFour 387 (8915,0,8911,0) = true := by
  simp only [checkFour, w387_0, w387_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one387 : Coverage 387 388 := checkList_sound (ws:=[(8915,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases387)
private theorem w388_0 : checkWitness 388 false false 8950 = true := by decide +kernel
private theorem w388_2 : checkWitness 388 true false 8941 = true := by decide +kernel
private theorem cases388 : checkFour 388 (8950,0,8941,0) = true := by
  simp only [checkFour, w388_0, w388_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one388 : Coverage 388 389 := checkList_sound (ws:=[(8950,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases388)
private theorem w389_0 : checkWitness 389 false false 80 = true := by decide +kernel
private theorem w389_2 : checkWitness 389 true false 80 = true := by decide +kernel
private theorem cases389 : checkFour 389 (80,0,80,0) = true := by
  simp only [checkFour, w389_0, w389_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one389 : Coverage 389 390 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases389)
private theorem w390_0 : checkWitness 390 false false 662 = true := by decide +kernel
private theorem w390_1 : checkWitness 390 false true 4754 = true := by decide +kernel
private theorem w390_2 : checkWitness 390 true false 653 = true := by decide +kernel
private theorem w390_3 : checkWitness 390 true true 4745 = true := by decide +kernel
private theorem cases390 : checkFour 390 (662,4754,653,4745) = true := by
  simp only [checkFour, w390_0, w390_1, w390_2, w390_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one390 : Coverage 390 391 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases390)
private theorem w391_0 : checkWitness 391 false false 8911 = true := by decide +kernel
private theorem w391_2 : checkWitness 391 true false 8907 = true := by decide +kernel
private theorem cases391 : checkFour 391 (8911,0,8907,0) = true := by
  simp only [checkFour, w391_0, w391_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one391 : Coverage 391 392 := checkList_sound (ws:=[(8911,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases391)
private theorem w392_0 : checkWitness 392 false false 656 = true := by decide +kernel
private theorem w392_1 : checkWitness 392 false true 4748 = true := by decide +kernel
private theorem w392_2 : checkWitness 392 true false 647 = true := by decide +kernel
private theorem w392_3 : checkWitness 392 true true 4739 = true := by decide +kernel
private theorem cases392 : checkFour 392 (656,4748,647,4739) = true := by
  simp only [checkFour, w392_0, w392_1, w392_2, w392_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one392 : Coverage 392 393 := checkList_sound (ws:=[(656,4748,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases392)
private theorem w393_0 : checkWitness 393 false false 8880 = true := by decide +kernel
private theorem w393_2 : checkWitness 393 true false 8876 = true := by decide +kernel
private theorem cases393 : checkFour 393 (8880,0,8876,0) = true := by
  simp only [checkFour, w393_0, w393_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one393 : Coverage 393 394 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases393)
private theorem w394_0 : checkWitness 394 false false 68 = true := by decide +kernel
private theorem w394_2 : checkWitness 394 true false 68 = true := by decide +kernel
private theorem cases394 : checkFour 394 (68,0,68,0) = true := by
  simp only [checkFour, w394_0, w394_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one394 : Coverage 394 395 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases394)
private theorem w395_0 : checkWitness 395 false false 60 = true := by decide +kernel
private theorem w395_2 : checkWitness 395 true false 60 = true := by decide +kernel
private theorem cases395 : checkFour 395 (60,0,60,0) = true := by
  simp only [checkFour, w395_0, w395_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one395 : Coverage 395 396 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases395)
private theorem w396_0 : checkWitness 396 false false 627 = true := by decide +kernel
private theorem w396_1 : checkWitness 396 false true 4711 = true := by decide +kernel
private theorem w396_2 : checkWitness 396 true false 627 = true := by decide +kernel
private theorem w396_3 : checkWitness 396 true true 4711 = true := by decide +kernel
private theorem cases396 : checkFour 396 (627,4711,627,4711) = true := by
  simp only [checkFour, w396_0, w396_1, w396_2, w396_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one396 : Coverage 396 397 := checkList_sound (ws:=[(627,4711,627,4711)]) (by simpa only [checkList, Bool.and_true] using cases396)
private theorem w397_0 : checkWitness 397 false false 8896 = true := by decide +kernel
private theorem w397_2 : checkWitness 397 true false 8892 = true := by decide +kernel
private theorem cases397 : checkFour 397 (8896,0,8892,0) = true := by
  simp only [checkFour, w397_0, w397_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one397 : Coverage 397 398 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases397)
private theorem w398_0 : checkWitness 398 false false 8892 = true := by decide +kernel
private theorem w398_2 : checkWitness 398 true false 8888 = true := by decide +kernel
private theorem cases398 : checkFour 398 (8892,0,8888,0) = true := by
  simp only [checkFour, w398_0, w398_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one398 : Coverage 398 399 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases398)
private theorem w399_0 : checkWitness 399 false false 74 = true := by decide +kernel
private theorem w399_2 : checkWitness 399 true false 74 = true := by decide +kernel
private theorem cases399 : checkFour 399 (74,0,74,0) = true := by
  simp only [checkFour, w399_0, w399_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one399 : Coverage 399 400 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases399)
private theorem w400_0 : checkWitness 400 false false 548 = true := by decide +kernel
private theorem w400_1 : checkWitness 400 false true 4644 = true := by decide +kernel
private theorem w400_2 : checkWitness 400 true false 548 = true := by decide +kernel
private theorem w400_3 : checkWitness 400 true true 4644 = true := by decide +kernel
private theorem cases400 : checkFour 400 (548,4644,548,4644) = true := by
  simp only [checkFour, w400_0, w400_1, w400_2, w400_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one400 : Coverage 400 401 := checkList_sound (ws:=[(548,4644,548,4644)]) (by simpa only [checkList, Bool.and_true] using cases400)
private theorem w401_0 : checkWitness 401 false false 8972 = true := by decide +kernel
private theorem w401_2 : checkWitness 401 true false 8963 = true := by decide +kernel
private theorem cases401 : checkFour 401 (8972,0,8963,0) = true := by
  simp only [checkFour, w401_0, w401_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one401 : Coverage 401 402 := checkList_sound (ws:=[(8972,0,8963,0)]) (by simpa only [checkList, Bool.and_true] using cases401)
private theorem w402_0 : checkWitness 402 false false 70 = true := by decide +kernel
private theorem w402_2 : checkWitness 402 true false 70 = true := by decide +kernel
private theorem cases402 : checkFour 402 (70,0,70,0) = true := by
  simp only [checkFour, w402_0, w402_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one402 : Coverage 402 403 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases402)
private theorem w403_0 : checkWitness 403 false false 554 = true := by decide +kernel
private theorem w403_1 : checkWitness 403 false true 4650 = true := by decide +kernel
private theorem w403_2 : checkWitness 403 true false 554 = true := by decide +kernel
private theorem w403_3 : checkWitness 403 true true 4650 = true := by decide +kernel
private theorem cases403 : checkFour 403 (554,4650,554,4650) = true := by
  simp only [checkFour, w403_0, w403_1, w403_2, w403_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one403 : Coverage 403 404 := checkList_sound (ws:=[(554,4650,554,4650)]) (by simpa only [checkList, Bool.and_true] using cases403)
private theorem w404_0 : checkWitness 404 false false 8912 = true := by decide +kernel
private theorem w404_2 : checkWitness 404 true false 8908 = true := by decide +kernel
private theorem cases404 : checkFour 404 (8912,0,8908,0) = true := by
  simp only [checkFour, w404_0, w404_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one404 : Coverage 404 405 := checkList_sound (ws:=[(8912,0,8908,0)]) (by simpa only [checkList, Bool.and_true] using cases404)
private theorem w405_0 : checkWitness 405 false false 72 = true := by decide +kernel
private theorem w405_2 : checkWitness 405 true false 72 = true := by decide +kernel
private theorem cases405 : checkFour 405 (72,0,72,0) = true := by
  simp only [checkFour, w405_0, w405_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one405 : Coverage 405 406 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases405)
private theorem w406_0 : checkWitness 406 false false 592 = true := by decide +kernel
private theorem w406_1 : checkWitness 406 false true 4688 = true := by decide +kernel
private theorem w406_2 : checkWitness 406 true false 592 = true := by decide +kernel
private theorem w406_3 : checkWitness 406 true true 4688 = true := by decide +kernel
private theorem cases406 : checkFour 406 (592,4688,592,4688) = true := by
  simp only [checkFour, w406_0, w406_1, w406_2, w406_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one406 : Coverage 406 407 := checkList_sound (ws:=[(592,4688,592,4688)]) (by simpa only [checkList, Bool.and_true] using cases406)
private theorem w407_0 : checkWitness 407 false false 8933 = true := by decide +kernel
private theorem w407_2 : checkWitness 407 true false 8929 = true := by decide +kernel
private theorem cases407 : checkFour 407 (8933,0,8929,0) = true := by
  simp only [checkFour, w407_0, w407_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one407 : Coverage 407 408 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases407)
private theorem w408_0 : checkWitness 408 false false 8968 = true := by decide +kernel
private theorem w408_2 : checkWitness 408 true false 8959 = true := by decide +kernel
private theorem cases408 : checkFour 408 (8968,0,8959,0) = true := by
  simp only [checkFour, w408_0, w408_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one408 : Coverage 408 409 := checkList_sound (ws:=[(8968,0,8959,0)]) (by simpa only [checkList, Bool.and_true] using cases408)
private theorem w409_0 : checkWitness 409 false false 96 = true := by decide +kernel
private theorem w409_2 : checkWitness 409 true false 96 = true := by decide +kernel
private theorem cases409 : checkFour 409 (96,0,96,0) = true := by
  simp only [checkFour, w409_0, w409_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one409 : Coverage 409 410 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases409)
private theorem w410_0 : checkWitness 410 false false 680 = true := by decide +kernel
private theorem w410_1 : checkWitness 410 false true 4772 = true := by decide +kernel
private theorem w410_2 : checkWitness 410 true false 671 = true := by decide +kernel
private theorem w410_3 : checkWitness 410 true true 4763 = true := by decide +kernel
private theorem cases410 : checkFour 410 (680,4772,671,4763) = true := by
  simp only [checkFour, w410_0, w410_1, w410_2, w410_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one410 : Coverage 410 411 := checkList_sound (ws:=[(680,4772,671,4763)]) (by simpa only [checkList, Bool.and_true] using cases410)
private theorem w411_0 : checkWitness 411 false false 8929 = true := by decide +kernel
private theorem w411_2 : checkWitness 411 true false 8925 = true := by decide +kernel
private theorem cases411 : checkFour 411 (8929,0,8925,0) = true := by
  simp only [checkFour, w411_0, w411_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one411 : Coverage 411 412 := checkList_sound (ws:=[(8929,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases411)
private theorem w412_0 : checkWitness 412 false false 674 = true := by decide +kernel
private theorem w412_1 : checkWitness 412 false true 4766 = true := by decide +kernel
private theorem w412_2 : checkWitness 412 true false 665 = true := by decide +kernel
private theorem w412_3 : checkWitness 412 true true 4757 = true := by decide +kernel
private theorem cases412 : checkFour 412 (674,4766,665,4757) = true := by
  simp only [checkFour, w412_0, w412_1, w412_2, w412_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one412 : Coverage 412 413 := checkList_sound (ws:=[(674,4766,665,4757)]) (by simpa only [checkList, Bool.and_true] using cases412)
private theorem w413_0 : checkWitness 413 false false 8898 = true := by decide +kernel
private theorem w413_2 : checkWitness 413 true false 8894 = true := by decide +kernel
private theorem cases413 : checkFour 413 (8898,0,8894,0) = true := by
  simp only [checkFour, w413_0, w413_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one413 : Coverage 413 414 := checkList_sound (ws:=[(8898,0,8894,0)]) (by simpa only [checkList, Bool.and_true] using cases413)
private theorem w414_0 : checkWitness 414 false false 84 = true := by decide +kernel
private theorem w414_2 : checkWitness 414 true false 84 = true := by decide +kernel
private theorem cases414 : checkFour 414 (84,0,84,0) = true := by
  simp only [checkFour, w414_0, w414_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one414 : Coverage 414 415 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases414)
private theorem w415_0 : checkWitness 415 false false 76 = true := by decide +kernel
private theorem w415_2 : checkWitness 415 true false 76 = true := by decide +kernel
private theorem cases415 : checkFour 415 (76,0,76,0) = true := by
  simp only [checkFour, w415_0, w415_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one415 : Coverage 415 416 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases415)
theorem cover0384 : Coverage 384 416 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one384 one385) (Coverage.join one386 one387)) (Coverage.join (Coverage.join one388 one389) (Coverage.join one390 one391))) (Coverage.join (Coverage.join (Coverage.join one392 one393) (Coverage.join one394 one395)) (Coverage.join (Coverage.join one396 one397) (Coverage.join one398 one399)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one400 one401) (Coverage.join one402 one403)) (Coverage.join (Coverage.join one404 one405) (Coverage.join one406 one407))) (Coverage.join (Coverage.join (Coverage.join one408 one409) (Coverage.join one410 one411)) (Coverage.join (Coverage.join one412 one413) (Coverage.join one414 one415)))))
end NF181PA.Symbolic
