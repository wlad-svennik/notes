import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1440_0 : checkWitness 1440 false false 92 = true := by decide +kernel
private theorem w1440_2 : checkWitness 1440 true false 92 = true := by decide +kernel
private theorem cases1440 : checkFour 1440 (92,0,92,0) = true := by
  simp only [checkFour, w1440_0, w1440_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1440 : Coverage 1440 1441 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1440)
private theorem w1441_0 : checkWitness 1441 false false 84 = true := by decide +kernel
private theorem w1441_2 : checkWitness 1441 true false 84 = true := by decide +kernel
private theorem cases1441 : checkFour 1441 (84,0,84,0) = true := by
  simp only [checkFour, w1441_0, w1441_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1441 : Coverage 1441 1442 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1441)
private theorem w1442_0 : checkWitness 1442 false false 565 = true := by decide +kernel
private theorem w1442_1 : checkWitness 1442 false true 4657 = true := by decide +kernel
private theorem w1442_2 : checkWitness 1442 true false 565 = true := by decide +kernel
private theorem w1442_3 : checkWitness 1442 true true 4657 = true := by decide +kernel
private theorem cases1442 : checkFour 1442 (565,4657,565,4657) = true := by
  simp only [checkFour, w1442_0, w1442_1, w1442_2, w1442_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1442 : Coverage 1442 1443 := checkList_sound (ws:=[(565,4657,565,4657)]) (by simpa only [checkList, Bool.and_true] using cases1442)
private theorem w1443_0 : checkWitness 1443 false false 8826 = true := by decide +kernel
private theorem w1443_2 : checkWitness 1443 true false 8822 = true := by decide +kernel
private theorem cases1443 : checkFour 1443 (8826,0,8822,0) = true := by
  simp only [checkFour, w1443_0, w1443_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1443 : Coverage 1443 1444 := checkList_sound (ws:=[(8826,0,8822,0)]) (by simpa only [checkList, Bool.and_true] using cases1443)
private theorem w1444_0 : checkWitness 1444 false false 84 = true := by decide +kernel
private theorem w1444_2 : checkWitness 1444 true false 84 = true := by decide +kernel
private theorem cases1444 : checkFour 1444 (84,0,84,0) = true := by
  simp only [checkFour, w1444_0, w1444_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1444 : Coverage 1444 1445 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1444)
private theorem w1445_0 : checkWitness 1445 false false 520 = true := by decide +kernel
private theorem w1445_1 : checkWitness 1445 false true 4616 = true := by decide +kernel
private theorem w1445_2 : checkWitness 1445 true false 520 = true := by decide +kernel
private theorem w1445_3 : checkWitness 1445 true true 4616 = true := by decide +kernel
private theorem cases1445 : checkFour 1445 (520,4616,520,4616) = true := by
  simp only [checkFour, w1445_0, w1445_1, w1445_2, w1445_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1445 : Coverage 1445 1446 := checkList_sound (ws:=[(520,4616,520,4616)]) (by simpa only [checkList, Bool.and_true] using cases1445)
private theorem w1446_0 : checkWitness 1446 false false 8861 = true := by decide +kernel
private theorem w1446_2 : checkWitness 1446 true false 8857 = true := by decide +kernel
private theorem cases1446 : checkFour 1446 (8861,0,8857,0) = true := by
  simp only [checkFour, w1446_0, w1446_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1446 : Coverage 1446 1447 := checkList_sound (ws:=[(8861,0,8857,0)]) (by simpa only [checkList, Bool.and_true] using cases1446)
private theorem w1447_0 : checkWitness 1447 false false 8896 = true := by decide +kernel
private theorem w1447_2 : checkWitness 1447 true false 8887 = true := by decide +kernel
private theorem cases1447 : checkFour 1447 (8896,0,8887,0) = true := by
  simp only [checkFour, w1447_0, w1447_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1447 : Coverage 1447 1448 := checkList_sound (ws:=[(8896,0,8887,0)]) (by simpa only [checkList, Bool.and_true] using cases1447)
private theorem w1448_0 : checkWitness 1448 false false 102 = true := by decide +kernel
private theorem w1448_2 : checkWitness 1448 true false 102 = true := by decide +kernel
private theorem cases1448 : checkFour 1448 (102,0,102,0) = true := by
  simp only [checkFour, w1448_0, w1448_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1448 : Coverage 1448 1449 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1448)
private theorem w1449_0 : checkWitness 1449 false false 608 = true := by decide +kernel
private theorem w1449_1 : checkWitness 1449 false true 4700 = true := by decide +kernel
private theorem w1449_2 : checkWitness 1449 true false 599 = true := by decide +kernel
private theorem w1449_3 : checkWitness 1449 true true 4691 = true := by decide +kernel
private theorem cases1449 : checkFour 1449 (608,4700,599,4691) = true := by
  simp only [checkFour, w1449_0, w1449_1, w1449_2, w1449_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1449 : Coverage 1449 1450 := checkList_sound (ws:=[(608,4700,599,4691)]) (by simpa only [checkList, Bool.and_true] using cases1449)
private theorem w1450_0 : checkWitness 1450 false false 8857 = true := by decide +kernel
private theorem w1450_2 : checkWitness 1450 true false 8853 = true := by decide +kernel
private theorem cases1450 : checkFour 1450 (8857,0,8853,0) = true := by
  simp only [checkFour, w1450_0, w1450_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1450 : Coverage 1450 1451 := checkList_sound (ws:=[(8857,0,8853,0)]) (by simpa only [checkList, Bool.and_true] using cases1450)
private theorem w1451_0 : checkWitness 1451 false false 602 = true := by decide +kernel
private theorem w1451_1 : checkWitness 1451 false true 4694 = true := by decide +kernel
private theorem w1451_2 : checkWitness 1451 true false 593 = true := by decide +kernel
private theorem w1451_3 : checkWitness 1451 true true 4685 = true := by decide +kernel
private theorem cases1451 : checkFour 1451 (602,4694,593,4685) = true := by
  simp only [checkFour, w1451_0, w1451_1, w1451_2, w1451_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1451 : Coverage 1451 1452 := checkList_sound (ws:=[(602,4694,593,4685)]) (by simpa only [checkList, Bool.and_true] using cases1451)
private theorem w1452_0 : checkWitness 1452 false false 8826 = true := by decide +kernel
private theorem w1452_2 : checkWitness 1452 true false 8822 = true := by decide +kernel
private theorem cases1452 : checkFour 1452 (8826,0,8822,0) = true := by
  simp only [checkFour, w1452_0, w1452_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1452 : Coverage 1452 1453 := checkList_sound (ws:=[(8826,0,8822,0)]) (by simpa only [checkList, Bool.and_true] using cases1452)
private theorem w1453_0 : checkWitness 1453 false false 90 = true := by decide +kernel
private theorem w1453_2 : checkWitness 1453 true false 90 = true := by decide +kernel
private theorem cases1453 : checkFour 1453 (90,0,90,0) = true := by
  simp only [checkFour, w1453_0, w1453_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1453 : Coverage 1453 1454 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1453)
private theorem w1454_0 : checkWitness 1454 false false 82 = true := by decide +kernel
private theorem w1454_2 : checkWitness 1454 true false 82 = true := by decide +kernel
private theorem cases1454 : checkFour 1454 (82,0,82,0) = true := by
  simp only [checkFour, w1454_0, w1454_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1454 : Coverage 1454 1455 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1454)
private theorem w1455_0 : checkWitness 1455 false false 569 = true := by decide +kernel
private theorem w1455_1 : checkWitness 1455 false true 4657 = true := by decide +kernel
private theorem w1455_2 : checkWitness 1455 true false 569 = true := by decide +kernel
private theorem w1455_3 : checkWitness 1455 true true 4657 = true := by decide +kernel
private theorem cases1455 : checkFour 1455 (569,4657,569,4657) = true := by
  simp only [checkFour, w1455_0, w1455_1, w1455_2, w1455_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1455 : Coverage 1455 1456 := checkList_sound (ws:=[(569,4657,569,4657)]) (by simpa only [checkList, Bool.and_true] using cases1455)
private theorem w1456_0 : checkWitness 1456 false false 8842 = true := by decide +kernel
private theorem w1456_2 : checkWitness 1456 true false 8838 = true := by decide +kernel
private theorem cases1456 : checkFour 1456 (8842,0,8838,0) = true := by
  simp only [checkFour, w1456_0, w1456_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1456 : Coverage 1456 1457 := checkList_sound (ws:=[(8842,0,8838,0)]) (by simpa only [checkList, Bool.and_true] using cases1456)
private theorem w1457_0 : checkWitness 1457 false false 8838 = true := by decide +kernel
private theorem w1457_2 : checkWitness 1457 true false 8834 = true := by decide +kernel
private theorem cases1457 : checkFour 1457 (8838,0,8834,0) = true := by
  simp only [checkFour, w1457_0, w1457_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1457 : Coverage 1457 1458 := checkList_sound (ws:=[(8838,0,8834,0)]) (by simpa only [checkList, Bool.and_true] using cases1457)
private theorem w1458_0 : checkWitness 1458 false false 96 = true := by decide +kernel
private theorem w1458_2 : checkWitness 1458 true false 96 = true := by decide +kernel
private theorem cases1458 : checkFour 1458 (96,0,96,0) = true := by
  simp only [checkFour, w1458_0, w1458_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1458 : Coverage 1458 1459 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1458)
private theorem w1459_0 : checkWitness 1459 false false 8858 = true := by decide +kernel
private theorem w1459_2 : checkWitness 1459 true false 8854 = true := by decide +kernel
private theorem cases1459 : checkFour 1459 (8858,0,8854,0) = true := by
  simp only [checkFour, w1459_0, w1459_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1459 : Coverage 1459 1460 := checkList_sound (ws:=[(8858,0,8854,0)]) (by simpa only [checkList, Bool.and_true] using cases1459)
private theorem w1460_0 : checkWitness 1460 false false 480 = true := by decide +kernel
private theorem w1460_1 : checkWitness 1460 false true 4576 = true := by decide +kernel
private theorem w1460_2 : checkWitness 1460 true false 480 = true := by decide +kernel
private theorem w1460_3 : checkWitness 1460 true true 4576 = true := by decide +kernel
private theorem cases1460 : checkFour 1460 (480,4576,480,4576) = true := by
  simp only [checkFour, w1460_0, w1460_1, w1460_2, w1460_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1460 : Coverage 1460 1461 := checkList_sound (ws:=[(480,4576,480,4576)]) (by simpa only [checkList, Bool.and_true] using cases1460)
private theorem w1461_0 : checkWitness 1461 false false 8920 = true := by decide +kernel
private theorem w1461_2 : checkWitness 1461 true false 8911 = true := by decide +kernel
private theorem cases1461 : checkFour 1461 (8920,0,8911,0) = true := by
  simp only [checkFour, w1461_0, w1461_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1461 : Coverage 1461 1462 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases1461)
private theorem w1462_0 : checkWitness 1462 false false 86 = true := by decide +kernel
private theorem w1462_2 : checkWitness 1462 true false 86 = true := by decide +kernel
private theorem cases1462 : checkFour 1462 (86,0,86,0) = true := by
  simp only [checkFour, w1462_0, w1462_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1462 : Coverage 1462 1463 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1462)
private theorem w1463_0 : checkWitness 1463 false false 502 = true := by decide +kernel
private theorem w1463_1 : checkWitness 1463 false true 4598 = true := by decide +kernel
private theorem w1463_2 : checkWitness 1463 true false 502 = true := by decide +kernel
private theorem w1463_3 : checkWitness 1463 true true 4598 = true := by decide +kernel
private theorem cases1463 : checkFour 1463 (502,4598,502,4598) = true := by
  simp only [checkFour, w1463_0, w1463_1, w1463_2, w1463_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1463 : Coverage 1463 1464 := checkList_sound (ws:=[(502,4598,502,4598)]) (by simpa only [checkList, Bool.and_true] using cases1463)
private theorem w1464_0 : checkWitness 1464 false false 8860 = true := by decide +kernel
private theorem w1464_2 : checkWitness 1464 true false 8856 = true := by decide +kernel
private theorem cases1464 : checkFour 1464 (8860,0,8856,0) = true := by
  simp only [checkFour, w1464_0, w1464_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1464 : Coverage 1464 1465 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases1464)
private theorem w1465_0 : checkWitness 1465 false false 88 = true := by decide +kernel
private theorem w1465_2 : checkWitness 1465 true false 88 = true := by decide +kernel
private theorem cases1465 : checkFour 1465 (88,0,88,0) = true := by
  simp only [checkFour, w1465_0, w1465_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1465 : Coverage 1465 1466 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1465)
private theorem w1466_0 : checkWitness 1466 false false 540 = true := by decide +kernel
private theorem w1466_1 : checkWitness 1466 false true 4636 = true := by decide +kernel
private theorem w1466_2 : checkWitness 1466 true false 540 = true := by decide +kernel
private theorem w1466_3 : checkWitness 1466 true true 4636 = true := by decide +kernel
private theorem cases1466 : checkFour 1466 (540,4636,540,4636) = true := by
  simp only [checkFour, w1466_0, w1466_1, w1466_2, w1466_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1466 : Coverage 1466 1467 := checkList_sound (ws:=[(540,4636,540,4636)]) (by simpa only [checkList, Bool.and_true] using cases1466)
private theorem w1467_0 : checkWitness 1467 false false 8881 = true := by decide +kernel
private theorem w1467_2 : checkWitness 1467 true false 8877 = true := by decide +kernel
private theorem cases1467 : checkFour 1467 (8881,0,8877,0) = true := by
  simp only [checkFour, w1467_0, w1467_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1467 : Coverage 1467 1468 := checkList_sound (ws:=[(8881,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases1467)
private theorem w1468_0 : checkWitness 1468 false false 8916 = true := by decide +kernel
private theorem w1468_2 : checkWitness 1468 true false 8907 = true := by decide +kernel
private theorem cases1468 : checkFour 1468 (8916,0,8907,0) = true := by
  simp only [checkFour, w1468_0, w1468_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1468 : Coverage 1468 1469 := checkList_sound (ws:=[(8916,0,8907,0)]) (by simpa only [checkList, Bool.and_true] using cases1468)
private theorem w1469_0 : checkWitness 1469 false false 112 = true := by decide +kernel
private theorem w1469_2 : checkWitness 1469 true false 112 = true := by decide +kernel
private theorem cases1469 : checkFour 1469 (112,0,112,0) = true := by
  simp only [checkFour, w1469_0, w1469_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1469 : Coverage 1469 1470 := checkList_sound (ws:=[(112,0,112,0)]) (by simpa only [checkList, Bool.and_true] using cases1469)
private theorem w1470_0 : checkWitness 1470 false false 628 = true := by decide +kernel
private theorem w1470_1 : checkWitness 1470 false true 4720 = true := by decide +kernel
private theorem w1470_2 : checkWitness 1470 true false 619 = true := by decide +kernel
private theorem w1470_3 : checkWitness 1470 true true 4711 = true := by decide +kernel
private theorem cases1470 : checkFour 1470 (628,4720,619,4711) = true := by
  simp only [checkFour, w1470_0, w1470_1, w1470_2, w1470_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1470 : Coverage 1470 1471 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases1470)
private theorem w1471_0 : checkWitness 1471 false false 8877 = true := by decide +kernel
private theorem w1471_2 : checkWitness 1471 true false 8873 = true := by decide +kernel
private theorem cases1471 : checkFour 1471 (8877,0,8873,0) = true := by
  simp only [checkFour, w1471_0, w1471_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1471 : Coverage 1471 1472 := checkList_sound (ws:=[(8877,0,8873,0)]) (by simpa only [checkList, Bool.and_true] using cases1471)
theorem cover1440 : Coverage 1440 1472 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1440 one1441) (Coverage.join one1442 one1443)) (Coverage.join (Coverage.join one1444 one1445) (Coverage.join one1446 one1447))) (Coverage.join (Coverage.join (Coverage.join one1448 one1449) (Coverage.join one1450 one1451)) (Coverage.join (Coverage.join one1452 one1453) (Coverage.join one1454 one1455)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1456 one1457) (Coverage.join one1458 one1459)) (Coverage.join (Coverage.join one1460 one1461) (Coverage.join one1462 one1463))) (Coverage.join (Coverage.join (Coverage.join one1464 one1465) (Coverage.join one1466 one1467)) (Coverage.join (Coverage.join one1468 one1469) (Coverage.join one1470 one1471)))))
end NF181PA.Symbolic
