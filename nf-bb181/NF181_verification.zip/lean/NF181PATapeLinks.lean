import NF181PATapeFinite

namespace NF181PA.Links
open NF192.Source
set_option maxRecDepth 200000
set_option maxHeartbeats 0

def tag (p : Nat) (c : Bool) : Bool := !c || decide (p<3 ∨ 9<p)

def atTarget (p : Nat) (c : Bool) : Bool := decide (p<2971) && tag p c

def allowed (p : Nat) (op : Command) (c : Bool) : Bool :=
  !tag p c || match op with
    | .inl (r,n) => atTarget n (c && !(r==0))
    | .inr (.inr n) => atTarget n c
    | .inr (.inl (r,z,n,h)) => !(c && (r==0)) && (h || atTarget z c) && atTarget n c

def check : Nat → List NF192.Emitter.Instruction → Bool
  | _,[] => true
  | p,i::rest => allowed p (Direct181Source.Raw.asCommand i) false && allowed p (Direct181Source.Raw.asCommand i) true && check (p+1) rest

private theorem lists (ops : List NF192.Emitter.Instruction) (base : Nat) (ok : check base ops=true)
    (j : Nat) (lt : j<ops.length) (fallback : NF192.Emitter.Instruction) (c : Bool) :
    allowed (base+j) (Direct181Source.Raw.asCommand (ops.getD j fallback)) c = true := by
  induction ops generalizing base j with
  | nil => simp at lt
  | cons i rest ih =>
    simp only [check,Bool.and_eq_true] at ok
    cases j with
    | zero => cases c <;> simpa using (by first | exact ok.1.1 | exact ok.1.2)
    | succ j =>
      have bound : j<rest.length := by simpa using lt
      have h := ih (base+1) ok.2 j bound
      simpa [List.getD, Nat.succ_eq_add_one,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using h

private theorem pre : check 0 Direct181Source.Literal.pre=true := by decide +kernel
private theorem mid : check 40 Direct181Source.Literal.mid=true := by decide +kernel
private theorem post : check 2849 Direct181Source.Literal.post=true := by decide +kernel
private theorem lenpre : Direct181Source.Literal.pre.length=40 := by decide +kernel
private theorem lenmid : Direct181Source.Literal.mid.length=2809 := by decide +kernel
private theorem lenpost : Direct181Source.Literal.post.length=122 := by decide +kernel

theorem release_links (p : Fin 2971) (c : Bool) : allowed p.val (Direct181Source.Raw.program p.val) c=true := by
  have bound := p.isLt
  unfold Direct181Source.Raw.program Direct181Source.Literal.program
  split
  · rename_i lt
    simpa using lists Direct181Source.Literal.pre 0 pre p.val (by simpa [lenpre] using lt) .halt c
  · rename_i lo
    split
    · rename_i hi
      have h := lists Direct181Source.Literal.mid 40 mid (p.val-40) (by rw [lenmid]; omega) .halt c
      rw [show 40+(p.val-40)=p.val by omega] at h
      exact h
    · rename_i hi
      have h := lists Direct181Source.Literal.post 2849 post (p.val-2849) (by rw [lenpost]; omega) (.jump p.val) c
      rw [show 2849+(p.val-2849)=p.val by omega] at h
      exact h
#print axioms release_links
end NF181PA.Links
