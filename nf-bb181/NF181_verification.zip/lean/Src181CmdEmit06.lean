module
public import Src181CmdEmit05
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter193 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((965:Nat):V) f (vector n (d+u) (emitAtom35 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0962 f n (d+u) (emitAtom35 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter192 f n t s c u v y d w).trans mid

theorem commandEmitAfter194 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((973:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) w)) := by
  have micro := site0965 f n (d+u) (emitAtom35 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom35 n t s c u v y d w))):V)=((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom35 n t s c u v y d w)):V)=(0+(emitAtom35 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom35 n t s c u v y d w))):V)=left (emitAtom35 n t s c u v y d w))).trans (by change left (cantor ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom35 n t s c u v y d w))):V)=(emitAtom32 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom35 n t s c u v y d w)):V)=(0+(emitAtom35 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom35 n t s c u v y d w))):V)=right (emitAtom35 n t s c u v y d w))).trans (by change right (cantor ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter193 f n t s c u v y d w).trans mid

theorem commandEmitAfter195 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((976:Nat):V) f (vector n (d+u) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0973 f n (d+u) 0 c (d+u) (v+y) ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) w
  have d2 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter194 f n t s c u v y d w).trans mid

theorem commandEmitAfter196 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((986:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom36 n t s c u v y d w) w)) := by
  have micro := site0976 f n (d+u) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (d+u))):V)=(emitAtom36 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom34 n t s c u v y d w)+(emitAtom34 n t s c u v y d w)+1) (d+u))):V)=(0+(emitAtom36 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter195 f n t s c u v y d w).trans mid

theorem commandEmitAfter197 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((990:Nat):V) f (vector n ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0986 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom36 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom36 n t s c u v y d w))):V)=((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom36 n t s c u v y d w))):V)=(0+((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter196 f n t s c u v y d w).trans mid

theorem commandEmitAfter198 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((991:Nat):V) f (vector n ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0990 f n ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w))+1):V)=((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter197 f n t s c u v y d w).trans mid

theorem commandEmitAfter199 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((994:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0991 f n ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1)):V)=((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter198 f n t s c u v y d w).trans mid

theorem commandEmitAfter200 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((997:Nat):V) f (vector n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0994 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter199 f n t s c u v y d w).trans mid

theorem commandEmitAfter201 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1007:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom37 n t s c u v y d w) w)) := by
  have micro := site0997 f n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w))):V)=(emitAtom37 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w))):V)=(0+(emitAtom37 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter200 f n t s c u v y d w).trans mid

theorem commandEmitAfter202 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1010:Nat):V) f (vector n 0 (emitAtom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1007 f n 0 0 c (d+u) (v+y) 0 (emitAtom37 n t s c u v y d w) w
  have d2 : ((0+(emitAtom37 n t s c u v y d w)):V)=(emitAtom37 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter201 f n t s c u v y d w).trans mid

theorem commandEmitAfter203 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1014:Nat):V) f (vector n (v+y) (emitAtom37 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1010 f n 0 (emitAtom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter202 f n t s c u v y d w).trans mid

theorem commandEmitAfter204 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1017:Nat):V) f (vector n (v+y) (emitAtom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1014 f n (v+y) (emitAtom37 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter203 f n t s c u v y d w).trans mid

theorem commandEmitAfter205 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1025:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) w)) := by
  have micro := site1017 f n (v+y) (emitAtom37 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom37 n t s c u v y d w))):V)=((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom37 n t s c u v y d w)):V)=(0+(emitAtom37 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom37 n t s c u v y d w))):V)=left (emitAtom37 n t s c u v y d w))).trans (by change left (cantor ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom37 n t s c u v y d w))):V)=(emitAtom32 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom37 n t s c u v y d w)):V)=(0+(emitAtom37 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom37 n t s c u v y d w))):V)=right (emitAtom37 n t s c u v y d w))).trans (by change right (cantor ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter204 f n t s c u v y d w).trans mid

theorem commandEmitAfter206 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1028:Nat):V) f (vector n (v+y) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1025 f n (v+y) 0 c (d+u) (v+y) ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) w
  have d2 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter205 f n t s c u v y d w).trans mid

theorem commandEmitAfter207 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1038:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom38 n t s c u v y d w) w)) := by
  have micro := site1028 f n (v+y) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (v+y))):V)=(emitAtom38 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom36 n t s c u v y d w)+(emitAtom36 n t s c u v y d w)+1) (v+y))):V)=(0+(emitAtom38 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter206 f n t s c u v y d w).trans mid

theorem commandEmitAfter208 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1042:Nat):V) f (vector n ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1038 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom38 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom38 n t s c u v y d w))):V)=((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom38 n t s c u v y d w))):V)=(0+((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter207 f n t s c u v y d w).trans mid

theorem commandEmitAfter209 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1043:Nat):V) f (vector n ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1042 f n ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w))+1):V)=((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter208 f n t s c u v y d w).trans mid

theorem commandEmitAfter210 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1046:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1043 f n ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1)):V)=((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter209 f n t s c u v y d w).trans mid

theorem commandEmitAfter211 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1049:Nat):V) f (vector n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1046 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter210 f n t s c u v y d w).trans mid

theorem commandEmitAfter212 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1059:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom39 n t s c u v y d w) w)) := by
  have micro := site1049 f n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w))):V)=(emitAtom39 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w))):V)=(0+(emitAtom39 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter211 f n t s c u v y d w).trans mid

theorem commandEmitAfter213 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1062:Nat):V) f (vector n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1059 f n 0 0 c (d+u) (v+y) 0 (emitAtom39 n t s c u v y d w) w
  have d2 : ((0+(emitAtom39 n t s c u v y d w)):V)=(emitAtom39 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter212 f n t s c u v y d w).trans mid

theorem commandEmitAfter214 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1066:Nat):V) f (vector n c (emitAtom39 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site1062 f n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter213 f n t s c u v y d w).trans mid

theorem commandEmitAfter215 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1069:Nat):V) f (vector n c (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1066 f n c (emitAtom39 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter214 f n t s c u v y d w).trans mid

theorem commandEmitAfter216 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1072:Nat):V) f (vector n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1069 f n c (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter215 f n t s c u v y d w).trans mid

theorem commandEmitAfter217 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1075:Nat):V) f (vector n (emitAtom39 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w)) := by
  have micro := site1072 f n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d1 : ((0+(emitAtom39 n t s c u v y d w)):V)=(emitAtom39 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter216 f n t s c u v y d w).trans mid

theorem commandEmitAfter218 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1085:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom40 n t s c u v y d w) w)) := by
  have micro := site1075 f n (emitAtom39 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w
  have d7 : ((0+(cantor c (emitAtom39 n t s c u v y d w))):V)=(emitAtom40 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c (emitAtom39 n t s c u v y d w))):V)=(0+(emitAtom40 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter217 f n t s c u v y d w).trans mid

theorem commandEmitAfter219 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1088:Nat):V) f (vector n 0 (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1085 f n 0 0 c (d+u) (v+y) 0 (emitAtom40 n t s c u v y d w) w
  have d2 : ((0+(emitAtom40 n t s c u v y d w)):V)=(emitAtom40 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter218 f n t s c u v y d w).trans mid

theorem commandEmitAfter220 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1092:Nat):V) f (vector n (v+y) (emitAtom40 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1088 f n 0 (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter219 f n t s c u v y d w).trans mid

theorem commandEmitAfter221 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1095:Nat):V) f (vector n (v+y) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1092 f n (v+y) (emitAtom40 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter220 f n t s c u v y d w).trans mid

theorem commandEmitAfter222 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1098:Nat):V) f (vector n 0 (emitAtom40 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1095 f n (v+y) (emitAtom40 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter221 f n t s c u v y d w).trans mid

theorem commandEmitAfter223 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1101:Nat):V) f (vector n (emitAtom40 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site1098 f n 0 (emitAtom40 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d1 : ((0+(emitAtom40 n t s c u v y d w)):V)=(emitAtom40 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter222 f n t s c u v y d w).trans mid

theorem commandEmitAfter224 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1111:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom41 n t s c u v y d w) w)) := by
  have micro := site1101 f n (emitAtom40 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (emitAtom40 n t s c u v y d w))):V)=(emitAtom41 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (emitAtom40 n t s c u v y d w))):V)=(0+(emitAtom41 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter223 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
