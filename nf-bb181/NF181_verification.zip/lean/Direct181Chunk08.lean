module
public import Direct181Snapshots
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem chunk47500 : Prefix 500 snap47000 snap47500 := checked _ _ _ (by decide) (by decide)
theorem chunk48000 : Prefix 500 snap47500 snap48000 := checked _ _ _ (by decide) (by decide)
theorem chunk48500 : Prefix 500 snap48000 snap48500 := checked _ _ _ (by decide) (by decide)
theorem chunk49000 : Prefix 500 snap48500 snap49000 := checked _ _ _ (by decide) (by decide)
theorem chunk49500 : Prefix 500 snap49000 snap49500 := checked _ _ _ (by decide) (by decide)
theorem chunk50000 : Prefix 500 snap49500 snap50000 := checked _ _ _ (by decide) (by decide)
theorem chunk50500 : Prefix 500 snap50000 snap50500 := checked _ _ _ (by decide) (by decide)
theorem chunk51000 : Prefix 500 snap50500 snap51000 := checked _ _ _ (by decide) (by decide)
theorem chunk51111 : Prefix 111 snap51000 snap51111 := checked _ _ _ (by decide) (by decide)
end Direct181.Boot
