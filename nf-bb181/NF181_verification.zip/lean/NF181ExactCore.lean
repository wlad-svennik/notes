import NF182PAPoolNat
import NF181PAEightReverse
import NF181PARegisterHalting
import Moving186NF
namespace NFMachine181
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic NF210 NF181PA PA192.Literal
open scoped FFL.FirstOrder.Arithmetic

/-- Both implications use the same literal 362-row table. -/
theorem halts_iff_nf_refutation_of_coverage (cover : Symbolic.Coverage 0 2971) : TM.Halts Direct181.Table.machine Direct181.Table.start ↔ (𝗡𝗙 ⊢ ⊥) := by
  rw [←H181_standard,←Moving186.deriv_goal_iff_nf_refutation]
  have code : (goal : Nat) = NF192.Numerical.goal := goal_three.trans NF192.Numerical.goal_is_three.symm
  rw [←code]
  constructor
  · intro h
    exact NF182PA.Pool.derivation_of_pool (Reverse.halting_implies_pool cover h)
  · intro h
    exact Symbolic.tape_of_coverage cover
      (refutation_reaches_register_halt (NF182PA.Pool.pool_of_derivation h))
end NFMachine181
#print axioms NFMachine181.halts_iff_nf_refutation_of_coverage
