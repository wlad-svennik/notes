module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site1993Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1993 f r x y z) (slots710.atReg 1997 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1993 4 1997 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1993 1997 1994 f r (row_of_literal 1993 _ (by decide) RawRows.raw1993))
    (slots710.pos_x 1993 1997 1994 f r (row_of_literal 1993 _ (by decide) RawRows.raw1993))
    (slots710.inc_y 1994 1995 f r (row_of_literal 1994 _ (by decide) RawRows.raw1994) (Or.inl (by decide)))
    (slots710.inc_y 1995 1996 f r (row_of_literal 1995 _ (by decide) RawRows.raw1995) (Or.inl (by decide)))
    (slots710.jump 1996 1993 f r (row_of_literal 1996 _ (by decide) RawRows.raw1996))

theorem site1993 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1993:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1997:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1993Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1997 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1997:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1998:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1997 _ (row_of_literal 1997 _ (by decide) RawRows.raw1997)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1998Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1998 f r x y z) (slots160.atReg 2001 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1998 3 2001 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1998 2001 1999 f r (row_of_literal 1998 _ (by decide) RawRows.raw1998))
    (slots160.pos_x 1998 2001 1999 f r (row_of_literal 1998 _ (by decide) RawRows.raw1998))
    (slots160.inc_y 1999 2000 f r (row_of_literal 1999 _ (by decide) RawRows.raw1999) (Or.inl (by decide)))
    (slots160.jump 2000 1998 f r (row_of_literal 2000 _ (by decide) RawRows.raw2000))

theorem site1998 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1998:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2001:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1998Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2001Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2001 f r x y z) (slots210.atReg 2004 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2001 3 2004 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2001 2004 2002 f r (row_of_literal 2001 _ (by decide) RawRows.raw2001))
    (slots210.pos_x 2001 2004 2002 f r (row_of_literal 2001 _ (by decide) RawRows.raw2001))
    (slots210.inc_y 2002 2003 f r (row_of_literal 2002 _ (by decide) RawRows.raw2002) (Or.inl (by decide)))
    (slots210.jump 2003 2001 f r (row_of_literal 2003 _ (by decide) RawRows.raw2003))

theorem site2001 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2001:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2004:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2001Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2004Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2004 f r x y z) (slots617.atReg 2014 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2004 10 2014 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2004 2008 2005 f r (row_of_literal 2004 _ (by decide) RawRows.raw2004))
    (slots617.pos_y 2004 2008 2005 f r (row_of_literal 2004 _ (by decide) RawRows.raw2004))
    (slots617.inc_z 2005 2006 f r (row_of_literal 2005 _ (by decide) RawRows.raw2005) (Or.inl (by decide)))
    (slots617.inc_x 2006 2007 f r (row_of_literal 2006 _ (by decide) RawRows.raw2006) (Or.inl (by decide)))
    (slots617.jump 2007 2004 f r (row_of_literal 2007 _ (by decide) RawRows.raw2007))
    (slots617.zero_x 2008 2014 2009 f r (row_of_literal 2008 _ (by decide) RawRows.raw2008))
    (slots617.pos_x 2008 2014 2009 f r (row_of_literal 2008 _ (by decide) RawRows.raw2008))
    (slots617.inc_z 2009 2010 f r (row_of_literal 2009 _ (by decide) RawRows.raw2009) (Or.inl (by decide)))
    (slots617.zero_x 2010 2013 2011 f r (row_of_literal 2010 _ (by decide) RawRows.raw2010))
    (slots617.pos_x 2010 2013 2011 f r (row_of_literal 2010 _ (by decide) RawRows.raw2010))
    (slots617.inc_y 2011 2012 f r (row_of_literal 2011 _ (by decide) RawRows.raw2011) (Or.inl (by decide)))
    (slots617.jump 2012 2010 f r (row_of_literal 2012 _ (by decide) RawRows.raw2012))
    (slots617.jump 2013 2004 f r (row_of_literal 2013 _ (by decide) RawRows.raw2013))

theorem site2004 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2004:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2014:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2004Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2014Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2014 f r x y z) (slots720.atReg 2017 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2014 3 2017 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2014 2017 2015 f r (row_of_literal 2014 _ (by decide) RawRows.raw2014))
    (slots720.pos_x 2014 2017 2015 f r (row_of_literal 2014 _ (by decide) RawRows.raw2014))
    (slots720.inc_y 2015 2016 f r (row_of_literal 2015 _ (by decide) RawRows.raw2015) (Or.inl (by decide)))
    (slots720.jump 2016 2014 f r (row_of_literal 2016 _ (by decide) RawRows.raw2016))

theorem site2014 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2014:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2017:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2014Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2017Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 2017 f r x y z) (slots461.atReg 2021 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 2017 4 2021 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 2017 2021 2018 f r (row_of_literal 2017 _ (by decide) RawRows.raw2017))
    (slots461.pos_x 2017 2021 2018 f r (row_of_literal 2017 _ (by decide) RawRows.raw2017))
    (slots461.inc_y 2018 2019 f r (row_of_literal 2018 _ (by decide) RawRows.raw2018) (Or.inl (by decide)))
    (slots461.inc_z 2019 2020 f r (row_of_literal 2019 _ (by decide) RawRows.raw2019) (Or.inl (by decide)))
    (slots461.jump 2020 2017 f r (row_of_literal 2020 _ (by decide) RawRows.raw2020))

theorem site2017 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2017:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2021:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site2017Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site2021Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 2021 f r x y z) (slots640.atReg 2024 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 2021 3 2024 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 2021 2024 2022 f r (row_of_literal 2021 _ (by decide) RawRows.raw2021))
    (slots640.pos_x 2021 2024 2022 f r (row_of_literal 2021 _ (by decide) RawRows.raw2021))
    (slots640.inc_y 2022 2023 f r (row_of_literal 2022 _ (by decide) RawRows.raw2022) (Or.inl (by decide)))
    (slots640.jump 2023 2021 f r (row_of_literal 2023 _ (by decide) RawRows.raw2023))

theorem site2021 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2021:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2024:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site2021Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site2024Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2024 f r x y z) (slots267.atReg 2032 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2024 8 2032 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2024 2032 2025 f r (row_of_literal 2024 _ (by decide) RawRows.raw2024))
    (slots267.pos_x 2024 2032 2025 f r (row_of_literal 2024 _ (by decide) RawRows.raw2024))
    (slots267.inc_z 2025 2026 f r (row_of_literal 2025 _ (by decide) RawRows.raw2025) (Or.inl (by decide)))
    (slots267.zero_y 2026 2028 2027 f r (row_of_literal 2026 _ (by decide) RawRows.raw2026))
    (slots267.pos_y 2026 2028 2027 f r (row_of_literal 2026 _ (by decide) RawRows.raw2026))
    (slots267.jump 2027 2031 f r (row_of_literal 2027 _ (by decide) RawRows.raw2027))
    (slots267.zero_z 2028 2031 2029 f r (row_of_literal 2028 _ (by decide) RawRows.raw2028))
    (slots267.pos_z 2028 2031 2029 f r (row_of_literal 2028 _ (by decide) RawRows.raw2028))
    (slots267.inc_y 2029 2030 f r (row_of_literal 2029 _ (by decide) RawRows.raw2029) (Or.inl (by decide)))
    (slots267.jump 2030 2028 f r (row_of_literal 2030 _ (by decide) RawRows.raw2030))
    (slots267.jump 2031 2024 f r (row_of_literal 2031 _ (by decide) RawRows.raw2031))

theorem site2024 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2024:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2032:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2024Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2032Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2032 f r x y z) (slots720.atReg 2035 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2032 3 2035 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2032 2035 2033 f r (row_of_literal 2032 _ (by decide) RawRows.raw2032))
    (slots720.pos_x 2032 2035 2033 f r (row_of_literal 2032 _ (by decide) RawRows.raw2032))
    (slots720.inc_y 2033 2034 f r (row_of_literal 2033 _ (by decide) RawRows.raw2033) (Or.inl (by decide)))
    (slots720.jump 2034 2032 f r (row_of_literal 2034 _ (by decide) RawRows.raw2034))

theorem site2032 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2032:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2035:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2032Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2035Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2035 f r x y z) (slots617.atReg 2045 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2035 10 2045 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2035 2039 2036 f r (row_of_literal 2035 _ (by decide) RawRows.raw2035))
    (slots617.pos_y 2035 2039 2036 f r (row_of_literal 2035 _ (by decide) RawRows.raw2035))
    (slots617.inc_z 2036 2037 f r (row_of_literal 2036 _ (by decide) RawRows.raw2036) (Or.inl (by decide)))
    (slots617.inc_x 2037 2038 f r (row_of_literal 2037 _ (by decide) RawRows.raw2037) (Or.inl (by decide)))
    (slots617.jump 2038 2035 f r (row_of_literal 2038 _ (by decide) RawRows.raw2038))
    (slots617.zero_x 2039 2045 2040 f r (row_of_literal 2039 _ (by decide) RawRows.raw2039))
    (slots617.pos_x 2039 2045 2040 f r (row_of_literal 2039 _ (by decide) RawRows.raw2039))
    (slots617.inc_z 2040 2041 f r (row_of_literal 2040 _ (by decide) RawRows.raw2040) (Or.inl (by decide)))
    (slots617.zero_x 2041 2044 2042 f r (row_of_literal 2041 _ (by decide) RawRows.raw2041))
    (slots617.pos_x 2041 2044 2042 f r (row_of_literal 2041 _ (by decide) RawRows.raw2041))
    (slots617.inc_y 2042 2043 f r (row_of_literal 2042 _ (by decide) RawRows.raw2042) (Or.inl (by decide)))
    (slots617.jump 2043 2041 f r (row_of_literal 2043 _ (by decide) RawRows.raw2043))
    (slots617.jump 2044 2035 f r (row_of_literal 2044 _ (by decide) RawRows.raw2044))

theorem site2035 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2035:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2045:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2035Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2045Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2045 f r x y z) (slots710.atReg 2049 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2045 4 2049 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2045 2049 2046 f r (row_of_literal 2045 _ (by decide) RawRows.raw2045))
    (slots710.pos_x 2045 2049 2046 f r (row_of_literal 2045 _ (by decide) RawRows.raw2045))
    (slots710.inc_y 2046 2047 f r (row_of_literal 2046 _ (by decide) RawRows.raw2046) (Or.inl (by decide)))
    (slots710.inc_y 2047 2048 f r (row_of_literal 2047 _ (by decide) RawRows.raw2047) (Or.inl (by decide)))
    (slots710.jump 2048 2045 f r (row_of_literal 2048 _ (by decide) RawRows.raw2048))

theorem site2045 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2045:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2049:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2045Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2049 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2049:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2050:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2049 _ (row_of_literal 2049 _ (by decide) RawRows.raw2049)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2050Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2050 f r x y z) (slots160.atReg 2053 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2050 3 2053 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2050 2053 2051 f r (row_of_literal 2050 _ (by decide) RawRows.raw2050))
    (slots160.pos_x 2050 2053 2051 f r (row_of_literal 2050 _ (by decide) RawRows.raw2050))
    (slots160.inc_y 2051 2052 f r (row_of_literal 2051 _ (by decide) RawRows.raw2051) (Or.inl (by decide)))
    (slots160.jump 2052 2050 f r (row_of_literal 2052 _ (by decide) RawRows.raw2052))

theorem site2050 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2050:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2053:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2050Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2053Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2053 f r x y z) (slots210.atReg 2056 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2053 3 2056 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2053 2056 2054 f r (row_of_literal 2053 _ (by decide) RawRows.raw2053))
    (slots210.pos_x 2053 2056 2054 f r (row_of_literal 2053 _ (by decide) RawRows.raw2053))
    (slots210.inc_y 2054 2055 f r (row_of_literal 2054 _ (by decide) RawRows.raw2054) (Or.inl (by decide)))
    (slots210.jump 2055 2053 f r (row_of_literal 2055 _ (by decide) RawRows.raw2055))

theorem site2053 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2053:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2056:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2053Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2056Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2056 f r x y z) (slots617.atReg 2066 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2056 10 2066 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2056 2060 2057 f r (row_of_literal 2056 _ (by decide) RawRows.raw2056))
    (slots617.pos_y 2056 2060 2057 f r (row_of_literal 2056 _ (by decide) RawRows.raw2056))
    (slots617.inc_z 2057 2058 f r (row_of_literal 2057 _ (by decide) RawRows.raw2057) (Or.inl (by decide)))
    (slots617.inc_x 2058 2059 f r (row_of_literal 2058 _ (by decide) RawRows.raw2058) (Or.inl (by decide)))
    (slots617.jump 2059 2056 f r (row_of_literal 2059 _ (by decide) RawRows.raw2059))
    (slots617.zero_x 2060 2066 2061 f r (row_of_literal 2060 _ (by decide) RawRows.raw2060))
    (slots617.pos_x 2060 2066 2061 f r (row_of_literal 2060 _ (by decide) RawRows.raw2060))
    (slots617.inc_z 2061 2062 f r (row_of_literal 2061 _ (by decide) RawRows.raw2061) (Or.inl (by decide)))
    (slots617.zero_x 2062 2065 2063 f r (row_of_literal 2062 _ (by decide) RawRows.raw2062))
    (slots617.pos_x 2062 2065 2063 f r (row_of_literal 2062 _ (by decide) RawRows.raw2062))
    (slots617.inc_y 2063 2064 f r (row_of_literal 2063 _ (by decide) RawRows.raw2063) (Or.inl (by decide)))
    (slots617.jump 2064 2062 f r (row_of_literal 2064 _ (by decide) RawRows.raw2064))
    (slots617.jump 2065 2056 f r (row_of_literal 2065 _ (by decide) RawRows.raw2065))

theorem site2056 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2056:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2066:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2056Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2066Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2066 f r x y z) (slots720.atReg 2069 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2066 3 2069 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2066 2069 2067 f r (row_of_literal 2066 _ (by decide) RawRows.raw2066))
    (slots720.pos_x 2066 2069 2067 f r (row_of_literal 2066 _ (by decide) RawRows.raw2066))
    (slots720.inc_y 2067 2068 f r (row_of_literal 2067 _ (by decide) RawRows.raw2067) (Or.inl (by decide)))
    (slots720.jump 2068 2066 f r (row_of_literal 2068 _ (by decide) RawRows.raw2068))

theorem site2066 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2066:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2069:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2066Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2069Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2069 f r x y z) (slots561.atReg 2073 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2069 4 2073 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2069 2073 2070 f r (row_of_literal 2069 _ (by decide) RawRows.raw2069))
    (slots561.pos_x 2069 2073 2070 f r (row_of_literal 2069 _ (by decide) RawRows.raw2069))
    (slots561.inc_y 2070 2071 f r (row_of_literal 2070 _ (by decide) RawRows.raw2070) (Or.inl (by decide)))
    (slots561.inc_z 2071 2072 f r (row_of_literal 2071 _ (by decide) RawRows.raw2071) (Or.inl (by decide)))
    (slots561.jump 2072 2069 f r (row_of_literal 2072 _ (by decide) RawRows.raw2072))

theorem site2069 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2069:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2073:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2069Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2073Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2073 f r x y z) (slots650.atReg 2076 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2073 3 2076 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2073 2076 2074 f r (row_of_literal 2073 _ (by decide) RawRows.raw2073))
    (slots650.pos_x 2073 2076 2074 f r (row_of_literal 2073 _ (by decide) RawRows.raw2073))
    (slots650.inc_y 2074 2075 f r (row_of_literal 2074 _ (by decide) RawRows.raw2074) (Or.inl (by decide)))
    (slots650.jump 2075 2073 f r (row_of_literal 2075 _ (by decide) RawRows.raw2075))

theorem site2073 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2073:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2076:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2073Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2076Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2076 f r x y z) (slots267.atReg 2084 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2076 8 2084 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2076 2084 2077 f r (row_of_literal 2076 _ (by decide) RawRows.raw2076))
    (slots267.pos_x 2076 2084 2077 f r (row_of_literal 2076 _ (by decide) RawRows.raw2076))
    (slots267.inc_z 2077 2078 f r (row_of_literal 2077 _ (by decide) RawRows.raw2077) (Or.inl (by decide)))
    (slots267.zero_y 2078 2080 2079 f r (row_of_literal 2078 _ (by decide) RawRows.raw2078))
    (slots267.pos_y 2078 2080 2079 f r (row_of_literal 2078 _ (by decide) RawRows.raw2078))
    (slots267.jump 2079 2083 f r (row_of_literal 2079 _ (by decide) RawRows.raw2079))
    (slots267.zero_z 2080 2083 2081 f r (row_of_literal 2080 _ (by decide) RawRows.raw2080))
    (slots267.pos_z 2080 2083 2081 f r (row_of_literal 2080 _ (by decide) RawRows.raw2080))
    (slots267.inc_y 2081 2082 f r (row_of_literal 2081 _ (by decide) RawRows.raw2081) (Or.inl (by decide)))
    (slots267.jump 2082 2080 f r (row_of_literal 2082 _ (by decide) RawRows.raw2082))
    (slots267.jump 2083 2076 f r (row_of_literal 2083 _ (by decide) RawRows.raw2083))

theorem site2076 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2076:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2084:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2076Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2084Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2084 f r x y z) (slots720.atReg 2087 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2084 3 2087 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2084 2087 2085 f r (row_of_literal 2084 _ (by decide) RawRows.raw2084))
    (slots720.pos_x 2084 2087 2085 f r (row_of_literal 2084 _ (by decide) RawRows.raw2084))
    (slots720.inc_y 2085 2086 f r (row_of_literal 2085 _ (by decide) RawRows.raw2085) (Or.inl (by decide)))
    (slots720.jump 2086 2084 f r (row_of_literal 2086 _ (by decide) RawRows.raw2086))

theorem site2084 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2084:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2087:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2084Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2087Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2087 f r x y z) (slots617.atReg 2097 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2087 10 2097 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2087 2091 2088 f r (row_of_literal 2087 _ (by decide) RawRows.raw2087))
    (slots617.pos_y 2087 2091 2088 f r (row_of_literal 2087 _ (by decide) RawRows.raw2087))
    (slots617.inc_z 2088 2089 f r (row_of_literal 2088 _ (by decide) RawRows.raw2088) (Or.inl (by decide)))
    (slots617.inc_x 2089 2090 f r (row_of_literal 2089 _ (by decide) RawRows.raw2089) (Or.inl (by decide)))
    (slots617.jump 2090 2087 f r (row_of_literal 2090 _ (by decide) RawRows.raw2090))
    (slots617.zero_x 2091 2097 2092 f r (row_of_literal 2091 _ (by decide) RawRows.raw2091))
    (slots617.pos_x 2091 2097 2092 f r (row_of_literal 2091 _ (by decide) RawRows.raw2091))
    (slots617.inc_z 2092 2093 f r (row_of_literal 2092 _ (by decide) RawRows.raw2092) (Or.inl (by decide)))
    (slots617.zero_x 2093 2096 2094 f r (row_of_literal 2093 _ (by decide) RawRows.raw2093))
    (slots617.pos_x 2093 2096 2094 f r (row_of_literal 2093 _ (by decide) RawRows.raw2093))
    (slots617.inc_y 2094 2095 f r (row_of_literal 2094 _ (by decide) RawRows.raw2094) (Or.inl (by decide)))
    (slots617.jump 2095 2093 f r (row_of_literal 2095 _ (by decide) RawRows.raw2095))
    (slots617.jump 2096 2087 f r (row_of_literal 2096 _ (by decide) RawRows.raw2096))

theorem site2087 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2087:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2097:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2087Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2097Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2097 f r x y z) (slots710.atReg 2101 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2097 4 2101 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2097 2101 2098 f r (row_of_literal 2097 _ (by decide) RawRows.raw2097))
    (slots710.pos_x 2097 2101 2098 f r (row_of_literal 2097 _ (by decide) RawRows.raw2097))
    (slots710.inc_y 2098 2099 f r (row_of_literal 2098 _ (by decide) RawRows.raw2098) (Or.inl (by decide)))
    (slots710.inc_y 2099 2100 f r (row_of_literal 2099 _ (by decide) RawRows.raw2099) (Or.inl (by decide)))
    (slots710.jump 2100 2097 f r (row_of_literal 2100 _ (by decide) RawRows.raw2100))

theorem site2097 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2097:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2101:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2097Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2101 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2101:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2102:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2101 _ (row_of_literal 2101 _ (by decide) RawRows.raw2101)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2102Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2102 f r x y z) (slots160.atReg 2105 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2102 3 2105 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2102 2105 2103 f r (row_of_literal 2102 _ (by decide) RawRows.raw2102))
    (slots160.pos_x 2102 2105 2103 f r (row_of_literal 2102 _ (by decide) RawRows.raw2102))
    (slots160.inc_y 2103 2104 f r (row_of_literal 2103 _ (by decide) RawRows.raw2103) (Or.inl (by decide)))
    (slots160.jump 2104 2102 f r (row_of_literal 2104 _ (by decide) RawRows.raw2104))

theorem site2102 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2102:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2105:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2102Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2105Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2105 f r x y z) (slots210.atReg 2108 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2105 3 2108 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2105 2108 2106 f r (row_of_literal 2105 _ (by decide) RawRows.raw2105))
    (slots210.pos_x 2105 2108 2106 f r (row_of_literal 2105 _ (by decide) RawRows.raw2105))
    (slots210.inc_y 2106 2107 f r (row_of_literal 2106 _ (by decide) RawRows.raw2106) (Or.inl (by decide)))
    (slots210.jump 2107 2105 f r (row_of_literal 2107 _ (by decide) RawRows.raw2107))

theorem site2105 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2105:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2108:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2105Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2108Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2108 f r x y z) (slots617.atReg 2118 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2108 10 2118 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2108 2112 2109 f r (row_of_literal 2108 _ (by decide) RawRows.raw2108))
    (slots617.pos_y 2108 2112 2109 f r (row_of_literal 2108 _ (by decide) RawRows.raw2108))
    (slots617.inc_z 2109 2110 f r (row_of_literal 2109 _ (by decide) RawRows.raw2109) (Or.inl (by decide)))
    (slots617.inc_x 2110 2111 f r (row_of_literal 2110 _ (by decide) RawRows.raw2110) (Or.inl (by decide)))
    (slots617.jump 2111 2108 f r (row_of_literal 2111 _ (by decide) RawRows.raw2111))
    (slots617.zero_x 2112 2118 2113 f r (row_of_literal 2112 _ (by decide) RawRows.raw2112))
    (slots617.pos_x 2112 2118 2113 f r (row_of_literal 2112 _ (by decide) RawRows.raw2112))
    (slots617.inc_z 2113 2114 f r (row_of_literal 2113 _ (by decide) RawRows.raw2113) (Or.inl (by decide)))
    (slots617.zero_x 2114 2117 2115 f r (row_of_literal 2114 _ (by decide) RawRows.raw2114))
    (slots617.pos_x 2114 2117 2115 f r (row_of_literal 2114 _ (by decide) RawRows.raw2114))
    (slots617.inc_y 2115 2116 f r (row_of_literal 2115 _ (by decide) RawRows.raw2115) (Or.inl (by decide)))
    (slots617.jump 2116 2114 f r (row_of_literal 2116 _ (by decide) RawRows.raw2116))
    (slots617.jump 2117 2108 f r (row_of_literal 2117 _ (by decide) RawRows.raw2117))

theorem site2108 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2108:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2118:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2108Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2118Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2118 f r x y z) (slots720.atReg 2121 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2118 3 2121 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2118 2121 2119 f r (row_of_literal 2118 _ (by decide) RawRows.raw2118))
    (slots720.pos_x 2118 2121 2119 f r (row_of_literal 2118 _ (by decide) RawRows.raw2118))
    (slots720.inc_y 2119 2120 f r (row_of_literal 2119 _ (by decide) RawRows.raw2119) (Or.inl (by decide)))
    (slots720.jump 2120 2118 f r (row_of_literal 2120 _ (by decide) RawRows.raw2120))

theorem site2118 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2118:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2121:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2118Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2121Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2121 f r x y z) (slots160.atReg 2124 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2121 3 2124 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2121 2124 2122 f r (row_of_literal 2121 _ (by decide) RawRows.raw2121))
    (slots160.pos_x 2121 2124 2122 f r (row_of_literal 2121 _ (by decide) RawRows.raw2121))
    (slots160.inc_y 2122 2123 f r (row_of_literal 2122 _ (by decide) RawRows.raw2122) (Or.inl (by decide)))
    (slots160.jump 2123 2121 f r (row_of_literal 2123 _ (by decide) RawRows.raw2123))

theorem site2121 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2121:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2124:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2121Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2124Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2124 f r x y z) (slots210.atReg 2127 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2124 3 2127 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2124 2127 2125 f r (row_of_literal 2124 _ (by decide) RawRows.raw2124))
    (slots210.pos_x 2124 2127 2125 f r (row_of_literal 2124 _ (by decide) RawRows.raw2124))
    (slots210.inc_y 2125 2126 f r (row_of_literal 2125 _ (by decide) RawRows.raw2125) (Or.inl (by decide)))
    (slots210.jump 2126 2124 f r (row_of_literal 2126 _ (by decide) RawRows.raw2126))

theorem site2124 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2124:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2127:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2124Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2127Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2127 f r x y z) (slots617.atReg 2137 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2127 10 2137 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2127 2131 2128 f r (row_of_literal 2127 _ (by decide) RawRows.raw2127))
    (slots617.pos_y 2127 2131 2128 f r (row_of_literal 2127 _ (by decide) RawRows.raw2127))
    (slots617.inc_z 2128 2129 f r (row_of_literal 2128 _ (by decide) RawRows.raw2128) (Or.inl (by decide)))
    (slots617.inc_x 2129 2130 f r (row_of_literal 2129 _ (by decide) RawRows.raw2129) (Or.inl (by decide)))
    (slots617.jump 2130 2127 f r (row_of_literal 2130 _ (by decide) RawRows.raw2130))
    (slots617.zero_x 2131 2137 2132 f r (row_of_literal 2131 _ (by decide) RawRows.raw2131))
    (slots617.pos_x 2131 2137 2132 f r (row_of_literal 2131 _ (by decide) RawRows.raw2131))
    (slots617.inc_z 2132 2133 f r (row_of_literal 2132 _ (by decide) RawRows.raw2132) (Or.inl (by decide)))
    (slots617.zero_x 2133 2136 2134 f r (row_of_literal 2133 _ (by decide) RawRows.raw2133))
    (slots617.pos_x 2133 2136 2134 f r (row_of_literal 2133 _ (by decide) RawRows.raw2133))
    (slots617.inc_y 2134 2135 f r (row_of_literal 2134 _ (by decide) RawRows.raw2134) (Or.inl (by decide)))
    (slots617.jump 2135 2133 f r (row_of_literal 2135 _ (by decide) RawRows.raw2135))
    (slots617.jump 2136 2127 f r (row_of_literal 2136 _ (by decide) RawRows.raw2136))

theorem site2127 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2127:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2137:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2127Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2137Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2137 f r x y z) (slots720.atReg 2140 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2137 3 2140 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2137 2140 2138 f r (row_of_literal 2137 _ (by decide) RawRows.raw2137))
    (slots720.pos_x 2137 2140 2138 f r (row_of_literal 2137 _ (by decide) RawRows.raw2137))
    (slots720.inc_y 2138 2139 f r (row_of_literal 2138 _ (by decide) RawRows.raw2138) (Or.inl (by decide)))
    (slots720.jump 2139 2137 f r (row_of_literal 2139 _ (by decide) RawRows.raw2139))

theorem site2137 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2137:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2140:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2137Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2140Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2140 f r x y z) (slots561.atReg 2144 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2140 4 2144 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2140 2144 2141 f r (row_of_literal 2140 _ (by decide) RawRows.raw2140))
    (slots561.pos_x 2140 2144 2141 f r (row_of_literal 2140 _ (by decide) RawRows.raw2140))
    (slots561.inc_y 2141 2142 f r (row_of_literal 2141 _ (by decide) RawRows.raw2141) (Or.inl (by decide)))
    (slots561.inc_z 2142 2143 f r (row_of_literal 2142 _ (by decide) RawRows.raw2142) (Or.inl (by decide)))
    (slots561.jump 2143 2140 f r (row_of_literal 2143 _ (by decide) RawRows.raw2143))

theorem site2140 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2140:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2144:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2140Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2144Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2144 f r x y z) (slots650.atReg 2147 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2144 3 2147 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2144 2147 2145 f r (row_of_literal 2144 _ (by decide) RawRows.raw2144))
    (slots650.pos_x 2144 2147 2145 f r (row_of_literal 2144 _ (by decide) RawRows.raw2144))
    (slots650.inc_y 2145 2146 f r (row_of_literal 2145 _ (by decide) RawRows.raw2145) (Or.inl (by decide)))
    (slots650.jump 2146 2144 f r (row_of_literal 2146 _ (by decide) RawRows.raw2146))

theorem site2144 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2144:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2147:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2144Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2147Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2147 f r x y z) (slots160.atReg 2150 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2147 3 2150 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2147 2150 2148 f r (row_of_literal 2147 _ (by decide) RawRows.raw2147))
    (slots160.pos_x 2147 2150 2148 f r (row_of_literal 2147 _ (by decide) RawRows.raw2147))
    (slots160.inc_y 2148 2149 f r (row_of_literal 2148 _ (by decide) RawRows.raw2148) (Or.inl (by decide)))
    (slots160.jump 2149 2147 f r (row_of_literal 2149 _ (by decide) RawRows.raw2149))

theorem site2147 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2147:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2150:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2147Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2150Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2150 f r x y z) (slots210.atReg 2153 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2150 3 2153 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2150 2153 2151 f r (row_of_literal 2150 _ (by decide) RawRows.raw2150))
    (slots210.pos_x 2150 2153 2151 f r (row_of_literal 2150 _ (by decide) RawRows.raw2150))
    (slots210.inc_y 2151 2152 f r (row_of_literal 2151 _ (by decide) RawRows.raw2151) (Or.inl (by decide)))
    (slots210.jump 2152 2150 f r (row_of_literal 2152 _ (by decide) RawRows.raw2152))

theorem site2150 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2150:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2153:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2150Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site2153Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2153 f r x y z) (slots617.atReg 2163 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2153 10 2163 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2153 2157 2154 f r (row_of_literal 2153 _ (by decide) RawRows.raw2153))
    (slots617.pos_y 2153 2157 2154 f r (row_of_literal 2153 _ (by decide) RawRows.raw2153))
    (slots617.inc_z 2154 2155 f r (row_of_literal 2154 _ (by decide) RawRows.raw2154) (Or.inl (by decide)))
    (slots617.inc_x 2155 2156 f r (row_of_literal 2155 _ (by decide) RawRows.raw2155) (Or.inl (by decide)))
    (slots617.jump 2156 2153 f r (row_of_literal 2156 _ (by decide) RawRows.raw2156))
    (slots617.zero_x 2157 2163 2158 f r (row_of_literal 2157 _ (by decide) RawRows.raw2157))
    (slots617.pos_x 2157 2163 2158 f r (row_of_literal 2157 _ (by decide) RawRows.raw2157))
    (slots617.inc_z 2158 2159 f r (row_of_literal 2158 _ (by decide) RawRows.raw2158) (Or.inl (by decide)))
    (slots617.zero_x 2159 2162 2160 f r (row_of_literal 2159 _ (by decide) RawRows.raw2159))
    (slots617.pos_x 2159 2162 2160 f r (row_of_literal 2159 _ (by decide) RawRows.raw2159))
    (slots617.inc_y 2160 2161 f r (row_of_literal 2160 _ (by decide) RawRows.raw2160) (Or.inl (by decide)))
    (slots617.jump 2161 2159 f r (row_of_literal 2161 _ (by decide) RawRows.raw2161))
    (slots617.jump 2162 2153 f r (row_of_literal 2162 _ (by decide) RawRows.raw2162))

theorem site2153 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2153:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2163:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2153Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2163Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2163 f r x y z) (slots720.atReg 2166 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2163 3 2166 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2163 2166 2164 f r (row_of_literal 2163 _ (by decide) RawRows.raw2163))
    (slots720.pos_x 2163 2166 2164 f r (row_of_literal 2163 _ (by decide) RawRows.raw2163))
    (slots720.inc_y 2164 2165 f r (row_of_literal 2164 _ (by decide) RawRows.raw2164) (Or.inl (by decide)))
    (slots720.jump 2165 2163 f r (row_of_literal 2165 _ (by decide) RawRows.raw2165))

theorem site2163 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2163:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2166:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2163Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2166Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 2166 f r x y z) (slots561.atReg 2170 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 2166 4 2170 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 2166 2170 2167 f r (row_of_literal 2166 _ (by decide) RawRows.raw2166))
    (slots561.pos_x 2166 2170 2167 f r (row_of_literal 2166 _ (by decide) RawRows.raw2166))
    (slots561.inc_y 2167 2168 f r (row_of_literal 2167 _ (by decide) RawRows.raw2167) (Or.inl (by decide)))
    (slots561.inc_z 2168 2169 f r (row_of_literal 2168 _ (by decide) RawRows.raw2168) (Or.inl (by decide)))
    (slots561.jump 2169 2166 f r (row_of_literal 2169 _ (by decide) RawRows.raw2169))

theorem site2166 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2166:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2170:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site2166Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site2170Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 2170 f r x y z) (slots650.atReg 2173 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 2170 3 2173 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 2170 2173 2171 f r (row_of_literal 2170 _ (by decide) RawRows.raw2170))
    (slots650.pos_x 2170 2173 2171 f r (row_of_literal 2170 _ (by decide) RawRows.raw2170))
    (slots650.inc_y 2171 2172 f r (row_of_literal 2171 _ (by decide) RawRows.raw2171) (Or.inl (by decide)))
    (slots650.jump 2172 2170 f r (row_of_literal 2172 _ (by decide) RawRows.raw2172))

theorem site2170 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2170:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2173:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site2170Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site2173Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2173 f r x y z) (slots267.atReg 2181 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2173 8 2181 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2173 2181 2174 f r (row_of_literal 2173 _ (by decide) RawRows.raw2173))
    (slots267.pos_x 2173 2181 2174 f r (row_of_literal 2173 _ (by decide) RawRows.raw2173))
    (slots267.inc_z 2174 2175 f r (row_of_literal 2174 _ (by decide) RawRows.raw2174) (Or.inl (by decide)))
    (slots267.zero_y 2175 2177 2176 f r (row_of_literal 2175 _ (by decide) RawRows.raw2175))
    (slots267.pos_y 2175 2177 2176 f r (row_of_literal 2175 _ (by decide) RawRows.raw2175))
    (slots267.jump 2176 2180 f r (row_of_literal 2176 _ (by decide) RawRows.raw2176))
    (slots267.zero_z 2177 2180 2178 f r (row_of_literal 2177 _ (by decide) RawRows.raw2177))
    (slots267.pos_z 2177 2180 2178 f r (row_of_literal 2177 _ (by decide) RawRows.raw2177))
    (slots267.inc_y 2178 2179 f r (row_of_literal 2178 _ (by decide) RawRows.raw2178) (Or.inl (by decide)))
    (slots267.jump 2179 2177 f r (row_of_literal 2179 _ (by decide) RawRows.raw2179))
    (slots267.jump 2180 2173 f r (row_of_literal 2180 _ (by decide) RawRows.raw2180))

theorem site2173 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2173:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2181:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2173Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2181Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2181 f r x y z) (slots720.atReg 2184 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2181 3 2184 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2181 2184 2182 f r (row_of_literal 2181 _ (by decide) RawRows.raw2181))
    (slots720.pos_x 2181 2184 2182 f r (row_of_literal 2181 _ (by decide) RawRows.raw2181))
    (slots720.inc_y 2182 2183 f r (row_of_literal 2182 _ (by decide) RawRows.raw2182) (Or.inl (by decide)))
    (slots720.jump 2183 2181 f r (row_of_literal 2183 _ (by decide) RawRows.raw2183))

theorem site2181 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2181:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2184:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2181Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2184Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2184 f r x y z) (slots617.atReg 2194 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2184 10 2194 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2184 2188 2185 f r (row_of_literal 2184 _ (by decide) RawRows.raw2184))
    (slots617.pos_y 2184 2188 2185 f r (row_of_literal 2184 _ (by decide) RawRows.raw2184))
    (slots617.inc_z 2185 2186 f r (row_of_literal 2185 _ (by decide) RawRows.raw2185) (Or.inl (by decide)))
    (slots617.inc_x 2186 2187 f r (row_of_literal 2186 _ (by decide) RawRows.raw2186) (Or.inl (by decide)))
    (slots617.jump 2187 2184 f r (row_of_literal 2187 _ (by decide) RawRows.raw2187))
    (slots617.zero_x 2188 2194 2189 f r (row_of_literal 2188 _ (by decide) RawRows.raw2188))
    (slots617.pos_x 2188 2194 2189 f r (row_of_literal 2188 _ (by decide) RawRows.raw2188))
    (slots617.inc_z 2189 2190 f r (row_of_literal 2189 _ (by decide) RawRows.raw2189) (Or.inl (by decide)))
    (slots617.zero_x 2190 2193 2191 f r (row_of_literal 2190 _ (by decide) RawRows.raw2190))
    (slots617.pos_x 2190 2193 2191 f r (row_of_literal 2190 _ (by decide) RawRows.raw2190))
    (slots617.inc_y 2191 2192 f r (row_of_literal 2191 _ (by decide) RawRows.raw2191) (Or.inl (by decide)))
    (slots617.jump 2192 2190 f r (row_of_literal 2192 _ (by decide) RawRows.raw2192))
    (slots617.jump 2193 2184 f r (row_of_literal 2193 _ (by decide) RawRows.raw2193))

theorem site2184 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2184:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2194:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2184Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2194Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2194 f r x y z) (slots710.atReg 2198 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2194 4 2198 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2194 2198 2195 f r (row_of_literal 2194 _ (by decide) RawRows.raw2194))
    (slots710.pos_x 2194 2198 2195 f r (row_of_literal 2194 _ (by decide) RawRows.raw2194))
    (slots710.inc_y 2195 2196 f r (row_of_literal 2195 _ (by decide) RawRows.raw2195) (Or.inl (by decide)))
    (slots710.inc_y 2196 2197 f r (row_of_literal 2196 _ (by decide) RawRows.raw2196) (Or.inl (by decide)))
    (slots710.jump 2197 2194 f r (row_of_literal 2197 _ (by decide) RawRows.raw2197))

theorem site2194 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2194:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2198:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2194Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2198 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2198:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2199:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2198 _ (row_of_literal 2198 _ (by decide) RawRows.raw2198)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site2199 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2199:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2200:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2199 _ (row_of_literal 2199 _ (by decide) RawRows.raw2199)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2200Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 2200 f r x y z) (slots267.atReg 2208 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 2200 8 2208 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 2200 2208 2201 f r (row_of_literal 2200 _ (by decide) RawRows.raw2200))
    (slots267.pos_x 2200 2208 2201 f r (row_of_literal 2200 _ (by decide) RawRows.raw2200))
    (slots267.inc_z 2201 2202 f r (row_of_literal 2201 _ (by decide) RawRows.raw2201) (Or.inl (by decide)))
    (slots267.zero_y 2202 2204 2203 f r (row_of_literal 2202 _ (by decide) RawRows.raw2202))
    (slots267.pos_y 2202 2204 2203 f r (row_of_literal 2202 _ (by decide) RawRows.raw2202))
    (slots267.jump 2203 2207 f r (row_of_literal 2203 _ (by decide) RawRows.raw2203))
    (slots267.zero_z 2204 2207 2205 f r (row_of_literal 2204 _ (by decide) RawRows.raw2204))
    (slots267.pos_z 2204 2207 2205 f r (row_of_literal 2204 _ (by decide) RawRows.raw2204))
    (slots267.inc_y 2205 2206 f r (row_of_literal 2205 _ (by decide) RawRows.raw2205) (Or.inl (by decide)))
    (slots267.jump 2206 2204 f r (row_of_literal 2206 _ (by decide) RawRows.raw2206))
    (slots267.jump 2207 2200 f r (row_of_literal 2207 _ (by decide) RawRows.raw2207))

theorem site2200 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2200:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2208:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site2200Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site2208Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 2208 f r x y z) (slots720.atReg 2211 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 2208 3 2211 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 2208 2211 2209 f r (row_of_literal 2208 _ (by decide) RawRows.raw2208))
    (slots720.pos_x 2208 2211 2209 f r (row_of_literal 2208 _ (by decide) RawRows.raw2208))
    (slots720.inc_y 2209 2210 f r (row_of_literal 2209 _ (by decide) RawRows.raw2209) (Or.inl (by decide)))
    (slots720.jump 2210 2208 f r (row_of_literal 2210 _ (by decide) RawRows.raw2210))

theorem site2208 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2208:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2211:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site2208Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site2211Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 2211 f r x y z) (slots617.atReg 2221 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 2211 10 2221 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 2211 2215 2212 f r (row_of_literal 2211 _ (by decide) RawRows.raw2211))
    (slots617.pos_y 2211 2215 2212 f r (row_of_literal 2211 _ (by decide) RawRows.raw2211))
    (slots617.inc_z 2212 2213 f r (row_of_literal 2212 _ (by decide) RawRows.raw2212) (Or.inl (by decide)))
    (slots617.inc_x 2213 2214 f r (row_of_literal 2213 _ (by decide) RawRows.raw2213) (Or.inl (by decide)))
    (slots617.jump 2214 2211 f r (row_of_literal 2214 _ (by decide) RawRows.raw2214))
    (slots617.zero_x 2215 2221 2216 f r (row_of_literal 2215 _ (by decide) RawRows.raw2215))
    (slots617.pos_x 2215 2221 2216 f r (row_of_literal 2215 _ (by decide) RawRows.raw2215))
    (slots617.inc_z 2216 2217 f r (row_of_literal 2216 _ (by decide) RawRows.raw2216) (Or.inl (by decide)))
    (slots617.zero_x 2217 2220 2218 f r (row_of_literal 2217 _ (by decide) RawRows.raw2217))
    (slots617.pos_x 2217 2220 2218 f r (row_of_literal 2217 _ (by decide) RawRows.raw2217))
    (slots617.inc_y 2218 2219 f r (row_of_literal 2218 _ (by decide) RawRows.raw2218) (Or.inl (by decide)))
    (slots617.jump 2219 2217 f r (row_of_literal 2219 _ (by decide) RawRows.raw2219))
    (slots617.jump 2220 2211 f r (row_of_literal 2220 _ (by decide) RawRows.raw2220))

theorem site2211 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2211:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2221:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site2211Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site2221Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 2221 f r x y z) (slots710.atReg 2225 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 2221 4 2225 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 2221 2225 2222 f r (row_of_literal 2221 _ (by decide) RawRows.raw2221))
    (slots710.pos_x 2221 2225 2222 f r (row_of_literal 2221 _ (by decide) RawRows.raw2221))
    (slots710.inc_y 2222 2223 f r (row_of_literal 2222 _ (by decide) RawRows.raw2222) (Or.inl (by decide)))
    (slots710.inc_y 2223 2224 f r (row_of_literal 2223 _ (by decide) RawRows.raw2223) (Or.inl (by decide)))
    (slots710.jump 2224 2221 f r (row_of_literal 2224 _ (by decide) RawRows.raw2224))

theorem site2221 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2221:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2225:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site2221Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site2225 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2225:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2226:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2225 _ (row_of_literal 2225 _ (by decide) RawRows.raw2225)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site2226Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 2226 f r x y z) (slots160.atReg 2229 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 2226 3 2229 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 2226 2229 2227 f r (row_of_literal 2226 _ (by decide) RawRows.raw2226))
    (slots160.pos_x 2226 2229 2227 f r (row_of_literal 2226 _ (by decide) RawRows.raw2226))
    (slots160.inc_y 2227 2228 f r (row_of_literal 2227 _ (by decide) RawRows.raw2227) (Or.inl (by decide)))
    (slots160.jump 2228 2226 f r (row_of_literal 2228 _ (by decide) RawRows.raw2228))

theorem site2226 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2226:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2229:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site2226Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site2229Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 2229 f r x y z) (slots210.atReg 2232 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 2229 3 2232 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 2229 2232 2230 f r (row_of_literal 2229 _ (by decide) RawRows.raw2229))
    (slots210.pos_x 2229 2232 2230 f r (row_of_literal 2229 _ (by decide) RawRows.raw2229))
    (slots210.inc_y 2230 2231 f r (row_of_literal 2230 _ (by decide) RawRows.raw2230) (Or.inl (by decide)))
    (slots210.jump 2231 2229 f r (row_of_literal 2231 _ (by decide) RawRows.raw2231))

theorem site2229 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2229:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((2232:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site2229Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


end PA192.ModelSearch.Register181.Certified
