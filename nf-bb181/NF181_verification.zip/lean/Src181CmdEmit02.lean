module
public import Src181CmdEmit01
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter65 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((358:Nat):V) f (vector n ((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w)) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom7 n t s c u v y d w) w)) := by
  have micro := site0350 f n ((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w)) (emitAtom10 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom10 n t s c u v y d w))):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom10 n t s c u v y d w)):V)=(0+(emitAtom10 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom10 n t s c u v y d w))):V)=left (emitAtom10 n t s c u v y d w))).trans (by change left (cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom7 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom10 n t s c u v y d w))):V)=(emitAtom7 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom10 n t s c u v y d w)):V)=(0+(emitAtom10 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom10 n t s c u v y d w))):V)=right (emitAtom10 n t s c u v y d w))).trans (by change right (cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom7 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter64 f n t s c u v y d w).trans mid

theorem commandEmitAfter66 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((361:Nat):V) f (vector n ((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w)) (emitAtom7 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) 0 w)) := by
  have micro := site0358 f n ((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w)) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom7 n t s c u v y d w) w
  have d2 : ((0+(emitAtom7 n t s c u v y d w)):V)=(emitAtom7 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter65 f n t s c u v y d w).trans mid

theorem commandEmitAfter67 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((371:Nat):V) f (vector n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom13 n t s c u v y d w) w)) := by
  have micro := site0361 f n ((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w)) (emitAtom7 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) ((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w)))):V)=(emitAtom13 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) ((emitAtom12 n t s c u v y d w)+(emitAtom12 n t s c u v y d w)))):V)=(0+(emitAtom13 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter66 f n t s c u v y d w).trans mid

theorem commandEmitAfter68 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((375:Nat):V) f (vector n ((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w)) (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0371 f n 0 (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom13 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom13 n t s c u v y d w))):V)=((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom13 n t s c u v y d w))):V)=(0+((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter67 f n t s c u v y d w).trans mid

theorem commandEmitAfter69 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((383:Nat):V) f (vector n ((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w)) 0 c (d+u) (v+y) ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) w)) := by
  have micro := site0375 f n ((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w)) (emitAtom7 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom7 n t s c u v y d w))):V)=((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom7 n t s c u v y d w)):V)=(0+(emitAtom7 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom7 n t s c u v y d w))):V)=left (emitAtom7 n t s c u v y d w))).trans (by change left (cantor ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) (emitAtom2 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom7 n t s c u v y d w))):V)=(emitAtom2 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom7 n t s c u v y d w)):V)=(0+(emitAtom7 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom7 n t s c u v y d w))):V)=right (emitAtom7 n t s c u v y d w))).trans (by change right (cantor ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) (emitAtom2 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter68 f n t s c u v y d w).trans mid

theorem commandEmitAfter70 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((386:Nat):V) f (vector n ((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) 0 w)) := by
  have micro := site0383 f n ((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w)) 0 c (d+u) (v+y) ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) w
  have d2 : ((0+(emitAtom2 n t s c u v y d w)):V)=(emitAtom2 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter69 f n t s c u v y d w).trans mid

theorem commandEmitAfter71 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((396:Nat):V) f (vector n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom14 n t s c u v y d w) w)) := by
  have micro := site0386 f n ((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) ((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w)))):V)=(emitAtom14 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom6 n t s c u v y d w)+(emitAtom6 n t s c u v y d w)) ((emitAtom13 n t s c u v y d w)+(emitAtom13 n t s c u v y d w)))):V)=(0+(emitAtom14 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter70 f n t s c u v y d w).trans mid

theorem commandEmitAfter72 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((400:Nat):V) f (vector n ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0396 f n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom14 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom14 n t s c u v y d w))):V)=((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom14 n t s c u v y d w))):V)=(0+((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter71 f n t s c u v y d w).trans mid

theorem commandEmitAfter73 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((403:Nat):V) f (vector n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) 0 w)) := by
  have micro := site0400 f n ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) (emitAtom2 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w))):V)=((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter72 f n t s c u v y d w).trans mid

theorem commandEmitAfter74 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((406:Nat):V) f (vector n (emitAtom2 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) 0 w)) := by
  have micro := site0403 f n 0 (emitAtom2 n t s c u v y d w) c (d+u) (v+y) ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) 0 w
  have d1 : ((0+(emitAtom2 n t s c u v y d w)):V)=(emitAtom2 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter73 f n t s c u v y d w).trans mid

theorem commandEmitAfter75 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((416:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom15 n t s c u v y d w) w)) := by
  have micro := site0406 f n (emitAtom2 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) (emitAtom2 n t s c u v y d w))):V)=(emitAtom15 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) (emitAtom2 n t s c u v y d w))):V)=(0+(emitAtom15 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter74 f n t s c u v y d w).trans mid

theorem commandEmitAfter76 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((419:Nat):V) f (vector n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0416 f n 0 0 c (d+u) (v+y) 0 (emitAtom15 n t s c u v y d w) w
  have d2 : ((0+(emitAtom15 n t s c u v y d w)):V)=(emitAtom15 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter75 f n t s c u v y d w).trans mid

theorem commandEmitAfter77 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((423:Nat):V) f (vector n (v+y) (emitAtom15 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0419 f n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter76 f n t s c u v y d w).trans mid

theorem commandEmitAfter78 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((426:Nat):V) f (vector n (v+y) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0423 f n (v+y) (emitAtom15 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter77 f n t s c u v y d w).trans mid

theorem commandEmitAfter79 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((429:Nat):V) f (vector n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site0426 f n (v+y) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter78 f n t s c u v y d w).trans mid

theorem commandEmitAfter80 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((432:Nat):V) f (vector n (emitAtom15 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site0429 f n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d1 : ((0+(emitAtom15 n t s c u v y d w)):V)=(emitAtom15 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter79 f n t s c u v y d w).trans mid

theorem commandEmitAfter81 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((442:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom16 n t s c u v y d w) w)) := by
  have micro := site0432 f n (emitAtom15 n t s c u v y d w) 0 c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (emitAtom15 n t s c u v y d w))):V)=(emitAtom16 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (emitAtom15 n t s c u v y d w))):V)=(0+(emitAtom16 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter80 f n t s c u v y d w).trans mid

theorem commandEmitAfter82 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((445:Nat):V) f (vector n 0 (emitAtom16 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0442 f n 0 0 c (d+u) (v+y) 0 (emitAtom16 n t s c u v y d w) w
  have d2 : ((0+(emitAtom16 n t s c u v y d w)):V)=(emitAtom16 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter81 f n t s c u v y d w).trans mid

theorem commandEmitAfter83 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((449:Nat):V) f (vector n (v+y) (emitAtom16 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0445 f n 0 (emitAtom16 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter82 f n t s c u v y d w).trans mid

theorem commandEmitAfter84 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((452:Nat):V) f (vector n (v+y) (emitAtom16 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0449 f n (v+y) (emitAtom16 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter83 f n t s c u v y d w).trans mid

theorem commandEmitAfter85 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((460:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (v+y) (emitAtom15 n t s c u v y d w) w)) := by
  have micro := site0452 f n (v+y) (emitAtom16 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom16 n t s c u v y d w))):V)=(v+y) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom16 n t s c u v y d w)):V)=(0+(emitAtom16 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom16 n t s c u v y d w))):V)=left (emitAtom16 n t s c u v y d w))).trans (by change left (cantor (v+y) (emitAtom15 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom16 n t s c u v y d w))):V)=(emitAtom15 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom16 n t s c u v y d w)):V)=(0+(emitAtom16 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom16 n t s c u v y d w))):V)=right (emitAtom16 n t s c u v y d w))).trans (by change right (cantor (v+y) (emitAtom15 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter84 f n t s c u v y d w).trans mid

theorem commandEmitAfter86 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((463:Nat):V) f (vector n (v+y) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site0460 f n (v+y) 0 c (d+u) (v+y) (v+y) (emitAtom15 n t s c u v y d w) w
  have d2 : ((0+(emitAtom15 n t s c u v y d w)):V)=(emitAtom15 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter85 f n t s c u v y d w).trans mid

theorem commandEmitAfter87 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((473:Nat):V) f (vector n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom17 n t s c u v y d w) w)) := by
  have micro := site0463 f n (v+y) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (v+y))):V)=(emitAtom17 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (v+y))):V)=(0+(emitAtom17 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter86 f n t s c u v y d w).trans mid

theorem commandEmitAfter88 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((477:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0473 f n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom17 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom17 n t s c u v y d w))):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom17 n t s c u v y d w))):V)=(0+((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter87 f n t s c u v y d w).trans mid

theorem commandEmitAfter89 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((478:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0477 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w))+1):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter88 f n t s c u v y d w).trans mid

theorem commandEmitAfter90 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((479:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0478 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1)+1):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter89 f n t s c u v y d w).trans mid

theorem commandEmitAfter91 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((482:Nat):V) f (vector n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 w)) := by
  have micro := site0479 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2)):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter90 f n t s c u v y d w).trans mid

theorem commandEmitAfter92 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((485:Nat):V) f (vector n (emitAtom15 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 w)) := by
  have micro := site0482 f n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 w
  have d1 : ((0+(emitAtom15 n t s c u v y d w)):V)=(emitAtom15 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter91 f n t s c u v y d w).trans mid

theorem commandEmitAfter93 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((495:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom18 n t s c u v y d w) w)) := by
  have micro := site0485 f n (emitAtom15 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 w
  have d7 : ((0+(cantor ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom15 n t s c u v y d w))):V)=(emitAtom18 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom15 n t s c u v y d w))):V)=(0+(emitAtom18 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter92 f n t s c u v y d w).trans mid

theorem commandEmitAfter94 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((498:Nat):V) f (vector n 0 (emitAtom18 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0495 f n 0 0 c (d+u) (v+y) 0 (emitAtom18 n t s c u v y d w) w
  have d2 : ((0+(emitAtom18 n t s c u v y d w)):V)=(emitAtom18 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter93 f n t s c u v y d w).trans mid

theorem commandEmitAfter95 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((502:Nat):V) f (vector n (d+u) (emitAtom18 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0498 f n 0 (emitAtom18 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter94 f n t s c u v y d w).trans mid

theorem commandEmitAfter96 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((505:Nat):V) f (vector n (d+u) (emitAtom18 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0502 f n (d+u) (emitAtom18 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter95 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
