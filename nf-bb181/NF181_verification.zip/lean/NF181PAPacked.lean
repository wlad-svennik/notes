module
public import NF181PAPool
public import ModelPackedCommands

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields
open NF181PA.Pool (nativeB test)
namespace NF181PA.Packed
export PA192.ModelSearch.RegisterCommands (state top stack cache param mode nip_state swap_state mode_state_succ)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 5000000
set_option maxRecDepth 14000

noncomputable def front6 (a b c u bottom : V) : V :=
  cantor (row4 a b c) (cantor (row2 a b c) (cantor (nativeB a b c) (cantor (row6 a b c)
    (cantor (row3 a b) (cantor (row0 a b c u) bottom)))))
noncomputable def front8 (a b c u bottom : V) : V :=
  cantor (row8 a b) (cantor (test b a) (front6 a b c u bottom))
instance front6Def : Language.DefinableFunction₅ ℒₒᵣ (front6 (V:=V)) := by
  unfold front6 row6 row4 row2 nativeB row3 row0; definability
instance front8Def : Language.DefinableFunction₅ ℒₒᵣ (front8 (V:=V)) := by
  unfold front8 row8 test Pool.single front6 row6 row4 row2 nativeB row3 row0
  definability

noncomputable def packBatch (j body a b fields : V) : V := ⟪j,⟪body,⟪a,⟪b,fields⟫⟫⟫⟫
noncomputable def rank (v : V) := pi₁ v
noncomputable def body (v : V) := pi₁ (pi₂ v)
noncomputable def aval (v : V) := pi₁ (pi₂ (pi₂ v))
noncomputable def bval (v : V) := pi₁ (pi₂ (pi₂ (pi₂ v)))
noncomputable def fields (v : V) := pi₂ (pi₂ (pi₂ (pi₂ v)))

noncomputable def nextBatch (v : V) : V :=
  let j := rank v - 1
  let a := aval v + left (right (fields v))
  let b := bval v + left (fields v)
  packBatch j (front8 a b j (aval v) (body v)) a b (right (right (fields v)))

instance nextBatchDef : Language.DefinableFunction₁ ℒₒᵣ (nextBatch (V:=V)) := by
  unfold nextBatch packBatch rank aval bval body fields
  apply Language.DefinableFunction₂.comp (F:=pair) (by definability)
  apply Language.DefinableFunction₂.comp (F:=pair)
  · apply Language.DefinableFunction₅.comp (F:=front8) <;> definability
  · definability

theorem next_literal (j z a b y d w : V) :
    nextBatch (packBatch (j+1) z a b (cantor y (cantor d w))) =
      packBatch j (front8 (a+d) (b+y) j a z) (a+d) (b+y) w := by
  simp [nextBatch,packBatch,rank,body,aval,bval,fields]

/-- The consecutive complete batches at ranks j down to 1 used by a padded command. -/
noncomputable def pushRemaining (v : V) : V :=
  packBatch (rank v-1) (front8 (aval v) (bval v) (rank v) (aval v) (body v)) (aval v) (bval v) 0
instance pushRemainingDef : Language.DefinableFunction₁ ℒₒᵣ (pushRemaining (V:=V)) := by
  unfold pushRemaining packBatch rank body aval bval
  apply Language.DefinableFunction₂.comp (F:=pair) (by definability)
  apply Language.DefinableFunction₂.comp (F:=pair)
  · apply Language.DefinableFunction₅.comp (F:=front8) <;> definability
  · definability
noncomputable def higher (a b j z : V) := body (iterate pushRemaining j (packBatch j z a b 0))
instance higherDef : Language.DefinableFunction₄ ℒₒᵣ (higher (V:=V)) := by
  unfold higher body packBatch; definability

@[simp] theorem higher_zero (a b z : V) : higher a b 0 z = z := by simp [higher,packBatch,body]
theorem higher_succ (a b j z : V) :
    higher a b (j+1) z = higher a b j (front8 a b (j+1) a z) := by
  rw [higher,iterate_succ_left]
  simp [pushRemaining,rank,body,aval,bval,packBatch,higher]

theorem zero_batches_run : ∀ j : V, ∀ z a b w,
    iterate nextBatch (j+1) (packBatch (j+1) z a b (zeroBatches (j+1) w)) =
      packBatch 0 (front8 a b 0 a (higher a b j z)) a b w := by
  apply modelInduct
  · unfold higher body packBatch front8 row8 test Pool.single front6 row6 row4 row2 nativeB row3 row0; definability
  · intro z a b w
    rw [iterate_succ_left,zeroBatches_succ,next_literal]
    simp
  · intro j ih z a b w
    rw [iterate_succ_left,zeroBatches_succ,next_literal]
    simpa only [add_zero,higher_succ] using ih (front8 a b (j+1) a z) a b w

/-- A failed MP followed by NIP discards the last emitted row and sets the top to zero. -/
noncomputable def afterAX (z : V) := state 0 (right (right z)) (left (right z)) 0
instance afterAXDef : Language.DefinableFunction₁ ℒₒᵣ (afterAX (V:=V)) := by unfold afterAX state; definability

theorem last_ne (a b : V) : b ≠ imp (row8 a b) a := by
  have h₁ := imp_ge_right a b
  have h₂ : eqn a b ≤ row8 a b := imp_ge_right _ _
  have h₃ := imp_ge_left (row8 a b) a
  exact ne_of_lt (lt_of_lt_of_le (lt_of_le_of_lt h₁ (lt_succ_iff_le.mpr le_rfl)) (le_trans h₂ h₃))

noncomputable def axRaw (outer y d count rawTail e : V) : V :=
  let u := param e + outer
  let a := u + d
  let b := cache e + y
  let z := front8 a b count u (cantor (top e) (stack e))
  let out := iterate nextBatch count (packBatch count z a b rawTail)
  ⟪afterAX (body out),fields out⟫

theorem ax_zero (outer y d tail t s h p : V) :
    axRaw outer y d 0 tail (state t s h p) =
    ⟪state 0 (front6 ((p+outer)+d) (h+y) 0 (p+outer) (cantor t s))
       (test (h+y) ((p+outer)+d)) 0,tail⟫ := by
  simp [axRaw,body,fields,packBatch,afterAX,state,param,top,stack,cache,front8]

theorem ax_positive (outer y d j tail t s h p : V) :
    axRaw outer y d (j+1) (zeroBatches (j+1) tail) (state t s h p) =
    let u := p+outer
    let a := u+d
    let b := h+y
    let z := front8 a b (j+1) u (cantor t s)
    ⟪state 0 (front6 a b 0 a (higher a b j z)) (test b a) 0,tail⟫ := by
  simp only [axRaw,top,stack,cache,param,state,pi₁_pair,pi₂_pair]
  rw [zero_batches_run]
  simp [body,fields,packBatch,afterAX,front8,state]

end NF181PA.Packed
#print axioms NF181PA.Packed.ax_positive
