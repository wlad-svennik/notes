import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1024_0 : checkWitness 1024 false false 80 = true := by decide +kernel
private theorem w1024_2 : checkWitness 1024 true false 80 = true := by decide +kernel
private theorem cases1024 : checkFour 1024 (80,0,80,0) = true := by
  simp only [checkFour, w1024_0, w1024_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1024 : Coverage 1024 1025 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1024)
private theorem w1025_0 : checkWitness 1025 false false 603 = true := by decide +kernel
private theorem w1025_1 : checkWitness 1025 false true 4695 = true := by decide +kernel
private theorem w1025_2 : checkWitness 1025 true false 603 = true := by decide +kernel
private theorem w1025_3 : checkWitness 1025 true true 4695 = true := by decide +kernel
private theorem cases1025 : checkFour 1025 (603,4695,603,4695) = true := by
  simp only [checkFour, w1025_0, w1025_1, w1025_2, w1025_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1025 : Coverage 1025 1026 := checkList_sound (ws:=[(603,4695,603,4695)]) (by simpa only [checkList, Bool.and_true] using cases1025)
private theorem w1026_0 : checkWitness 1026 false false 8864 = true := by decide +kernel
private theorem w1026_2 : checkWitness 1026 true false 8860 = true := by decide +kernel
private theorem cases1026 : checkFour 1026 (8864,0,8860,0) = true := by
  simp only [checkFour, w1026_0, w1026_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1026 : Coverage 1026 1027 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases1026)
private theorem w1027_0 : checkWitness 1027 false false 80 = true := by decide +kernel
private theorem w1027_2 : checkWitness 1027 true false 80 = true := by decide +kernel
private theorem cases1027 : checkFour 1027 (80,0,80,0) = true := by
  simp only [checkFour, w1027_0, w1027_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1027 : Coverage 1027 1028 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases1027)
private theorem w1028_0 : checkWitness 1028 false false 558 = true := by decide +kernel
private theorem w1028_1 : checkWitness 1028 false true 4654 = true := by decide +kernel
private theorem w1028_2 : checkWitness 1028 true false 558 = true := by decide +kernel
private theorem w1028_3 : checkWitness 1028 true true 4654 = true := by decide +kernel
private theorem cases1028 : checkFour 1028 (558,4654,558,4654) = true := by
  simp only [checkFour, w1028_0, w1028_1, w1028_2, w1028_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1028 : Coverage 1028 1029 := checkList_sound (ws:=[(558,4654,558,4654)]) (by simpa only [checkList, Bool.and_true] using cases1028)
private theorem w1029_0 : checkWitness 1029 false false 8899 = true := by decide +kernel
private theorem w1029_2 : checkWitness 1029 true false 8895 = true := by decide +kernel
private theorem cases1029 : checkFour 1029 (8899,0,8895,0) = true := by
  simp only [checkFour, w1029_0, w1029_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1029 : Coverage 1029 1030 := checkList_sound (ws:=[(8899,0,8895,0)]) (by simpa only [checkList, Bool.and_true] using cases1029)
private theorem w1030_0 : checkWitness 1030 false false 8934 = true := by decide +kernel
private theorem w1030_2 : checkWitness 1030 true false 8925 = true := by decide +kernel
private theorem cases1030 : checkFour 1030 (8934,0,8925,0) = true := by
  simp only [checkFour, w1030_0, w1030_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1030 : Coverage 1030 1031 := checkList_sound (ws:=[(8934,0,8925,0)]) (by simpa only [checkList, Bool.and_true] using cases1030)
private theorem w1031_0 : checkWitness 1031 false false 98 = true := by decide +kernel
private theorem w1031_2 : checkWitness 1031 true false 98 = true := by decide +kernel
private theorem cases1031 : checkFour 1031 (98,0,98,0) = true := by
  simp only [checkFour, w1031_0, w1031_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1031 : Coverage 1031 1032 := checkList_sound (ws:=[(98,0,98,0)]) (by simpa only [checkList, Bool.and_true] using cases1031)
private theorem w1032_0 : checkWitness 1032 false false 646 = true := by decide +kernel
private theorem w1032_1 : checkWitness 1032 false true 4738 = true := by decide +kernel
private theorem w1032_2 : checkWitness 1032 true false 637 = true := by decide +kernel
private theorem w1032_3 : checkWitness 1032 true true 4729 = true := by decide +kernel
private theorem cases1032 : checkFour 1032 (646,4738,637,4729) = true := by
  simp only [checkFour, w1032_0, w1032_1, w1032_2, w1032_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1032 : Coverage 1032 1033 := checkList_sound (ws:=[(646,4738,637,4729)]) (by simpa only [checkList, Bool.and_true] using cases1032)
private theorem w1033_0 : checkWitness 1033 false false 8895 = true := by decide +kernel
private theorem w1033_2 : checkWitness 1033 true false 8891 = true := by decide +kernel
private theorem cases1033 : checkFour 1033 (8895,0,8891,0) = true := by
  simp only [checkFour, w1033_0, w1033_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1033 : Coverage 1033 1034 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1033)
private theorem w1034_0 : checkWitness 1034 false false 640 = true := by decide +kernel
private theorem w1034_1 : checkWitness 1034 false true 4732 = true := by decide +kernel
private theorem w1034_2 : checkWitness 1034 true false 631 = true := by decide +kernel
private theorem w1034_3 : checkWitness 1034 true true 4723 = true := by decide +kernel
private theorem cases1034 : checkFour 1034 (640,4732,631,4723) = true := by
  simp only [checkFour, w1034_0, w1034_1, w1034_2, w1034_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1034 : Coverage 1034 1035 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases1034)
private theorem w1035_0 : checkWitness 1035 false false 8864 = true := by decide +kernel
private theorem w1035_2 : checkWitness 1035 true false 8860 = true := by decide +kernel
private theorem cases1035 : checkFour 1035 (8864,0,8860,0) = true := by
  simp only [checkFour, w1035_0, w1035_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1035 : Coverage 1035 1036 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases1035)
private theorem w1036_0 : checkWitness 1036 false false 86 = true := by decide +kernel
private theorem w1036_2 : checkWitness 1036 true false 86 = true := by decide +kernel
private theorem cases1036 : checkFour 1036 (86,0,86,0) = true := by
  simp only [checkFour, w1036_0, w1036_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1036 : Coverage 1036 1037 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1036)
private theorem w1037_0 : checkWitness 1037 false false 78 = true := by decide +kernel
private theorem w1037_2 : checkWitness 1037 true false 78 = true := by decide +kernel
private theorem cases1037 : checkFour 1037 (78,0,78,0) = true := by
  simp only [checkFour, w1037_0, w1037_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1037 : Coverage 1037 1038 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1037)
private theorem w1038_0 : checkWitness 1038 false false 607 = true := by decide +kernel
private theorem w1038_1 : checkWitness 1038 false true 4695 = true := by decide +kernel
private theorem w1038_2 : checkWitness 1038 true false 607 = true := by decide +kernel
private theorem w1038_3 : checkWitness 1038 true true 4695 = true := by decide +kernel
private theorem cases1038 : checkFour 1038 (607,4695,607,4695) = true := by
  simp only [checkFour, w1038_0, w1038_1, w1038_2, w1038_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1038 : Coverage 1038 1039 := checkList_sound (ws:=[(607,4695,607,4695)]) (by simpa only [checkList, Bool.and_true] using cases1038)
private theorem w1039_0 : checkWitness 1039 false false 8880 = true := by decide +kernel
private theorem w1039_2 : checkWitness 1039 true false 8876 = true := by decide +kernel
private theorem cases1039 : checkFour 1039 (8880,0,8876,0) = true := by
  simp only [checkFour, w1039_0, w1039_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1039 : Coverage 1039 1040 := checkList_sound (ws:=[(8880,0,8876,0)]) (by simpa only [checkList, Bool.and_true] using cases1039)
private theorem w1040_0 : checkWitness 1040 false false 8876 = true := by decide +kernel
private theorem w1040_2 : checkWitness 1040 true false 8872 = true := by decide +kernel
private theorem cases1040 : checkFour 1040 (8876,0,8872,0) = true := by
  simp only [checkFour, w1040_0, w1040_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1040 : Coverage 1040 1041 := checkList_sound (ws:=[(8876,0,8872,0)]) (by simpa only [checkList, Bool.and_true] using cases1040)
private theorem w1041_0 : checkWitness 1041 false false 92 = true := by decide +kernel
private theorem w1041_2 : checkWitness 1041 true false 92 = true := by decide +kernel
private theorem cases1041 : checkFour 1041 (92,0,92,0) = true := by
  simp only [checkFour, w1041_0, w1041_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1041 : Coverage 1041 1042 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases1041)
private theorem w1042_0 : checkWitness 1042 false false 8900 = true := by decide +kernel
private theorem w1042_2 : checkWitness 1042 true false 8896 = true := by decide +kernel
private theorem cases1042 : checkFour 1042 (8900,0,8896,0) = true := by
  simp only [checkFour, w1042_0, w1042_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1042 : Coverage 1042 1043 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases1042)
private theorem w1043_0 : checkWitness 1043 false false 508 = true := by decide +kernel
private theorem w1043_1 : checkWitness 1043 false true 4604 = true := by decide +kernel
private theorem w1043_2 : checkWitness 1043 true false 508 = true := by decide +kernel
private theorem w1043_3 : checkWitness 1043 true true 4604 = true := by decide +kernel
private theorem cases1043 : checkFour 1043 (508,4604,508,4604) = true := by
  simp only [checkFour, w1043_0, w1043_1, w1043_2, w1043_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1043 : Coverage 1043 1044 := checkList_sound (ws:=[(508,4604,508,4604)]) (by simpa only [checkList, Bool.and_true] using cases1043)
private theorem w1044_0 : checkWitness 1044 false false 8932 = true := by decide +kernel
private theorem w1044_2 : checkWitness 1044 true false 8923 = true := by decide +kernel
private theorem cases1044 : checkFour 1044 (8932,0,8923,0) = true := by
  simp only [checkFour, w1044_0, w1044_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1044 : Coverage 1044 1045 := checkList_sound (ws:=[(8932,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases1044)
private theorem w1045_0 : checkWitness 1045 false false 70 = true := by decide +kernel
private theorem w1045_2 : checkWitness 1045 true false 70 = true := by decide +kernel
private theorem cases1045 : checkFour 1045 (70,0,70,0) = true := by
  simp only [checkFour, w1045_0, w1045_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1045 : Coverage 1045 1046 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases1045)
private theorem w1046_0 : checkWitness 1046 false false 514 = true := by decide +kernel
private theorem w1046_1 : checkWitness 1046 false true 4610 = true := by decide +kernel
private theorem w1046_2 : checkWitness 1046 true false 514 = true := by decide +kernel
private theorem w1046_3 : checkWitness 1046 true true 4610 = true := by decide +kernel
private theorem cases1046 : checkFour 1046 (514,4610,514,4610) = true := by
  simp only [checkFour, w1046_0, w1046_1, w1046_2, w1046_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1046 : Coverage 1046 1047 := checkList_sound (ws:=[(514,4610,514,4610)]) (by simpa only [checkList, Bool.and_true] using cases1046)
private theorem w1047_0 : checkWitness 1047 false false 8872 = true := by decide +kernel
private theorem w1047_2 : checkWitness 1047 true false 8868 = true := by decide +kernel
private theorem cases1047 : checkFour 1047 (8872,0,8868,0) = true := by
  simp only [checkFour, w1047_0, w1047_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1047 : Coverage 1047 1048 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases1047)
private theorem w1048_0 : checkWitness 1048 false false 72 = true := by decide +kernel
private theorem w1048_2 : checkWitness 1048 true false 72 = true := by decide +kernel
private theorem cases1048 : checkFour 1048 (72,0,72,0) = true := by
  simp only [checkFour, w1048_0, w1048_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1048 : Coverage 1048 1049 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases1048)
private theorem w1049_0 : checkWitness 1049 false false 552 = true := by decide +kernel
private theorem w1049_1 : checkWitness 1049 false true 4648 = true := by decide +kernel
private theorem w1049_2 : checkWitness 1049 true false 552 = true := by decide +kernel
private theorem w1049_3 : checkWitness 1049 true true 4648 = true := by decide +kernel
private theorem cases1049 : checkFour 1049 (552,4648,552,4648) = true := by
  simp only [checkFour, w1049_0, w1049_1, w1049_2, w1049_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1049 : Coverage 1049 1050 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases1049)
private theorem w1050_0 : checkWitness 1050 false false 8893 = true := by decide +kernel
private theorem w1050_2 : checkWitness 1050 true false 8889 = true := by decide +kernel
private theorem cases1050 : checkFour 1050 (8893,0,8889,0) = true := by
  simp only [checkFour, w1050_0, w1050_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1050 : Coverage 1050 1051 := checkList_sound (ws:=[(8893,0,8889,0)]) (by simpa only [checkList, Bool.and_true] using cases1050)
private theorem w1051_0 : checkWitness 1051 false false 8928 = true := by decide +kernel
private theorem w1051_2 : checkWitness 1051 true false 8919 = true := by decide +kernel
private theorem cases1051 : checkFour 1051 (8928,0,8919,0) = true := by
  simp only [checkFour, w1051_0, w1051_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1051 : Coverage 1051 1052 := checkList_sound (ws:=[(8928,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases1051)
private theorem w1052_0 : checkWitness 1052 false false 96 = true := by decide +kernel
private theorem w1052_2 : checkWitness 1052 true false 96 = true := by decide +kernel
private theorem cases1052 : checkFour 1052 (96,0,96,0) = true := by
  simp only [checkFour, w1052_0, w1052_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1052 : Coverage 1052 1053 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1052)
private theorem w1053_0 : checkWitness 1053 false false 640 = true := by decide +kernel
private theorem w1053_1 : checkWitness 1053 false true 4732 = true := by decide +kernel
private theorem w1053_2 : checkWitness 1053 true false 631 = true := by decide +kernel
private theorem w1053_3 : checkWitness 1053 true true 4723 = true := by decide +kernel
private theorem cases1053 : checkFour 1053 (640,4732,631,4723) = true := by
  simp only [checkFour, w1053_0, w1053_1, w1053_2, w1053_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1053 : Coverage 1053 1054 := checkList_sound (ws:=[(640,4732,631,4723)]) (by simpa only [checkList, Bool.and_true] using cases1053)
private theorem w1054_0 : checkWitness 1054 false false 8889 = true := by decide +kernel
private theorem w1054_2 : checkWitness 1054 true false 8885 = true := by decide +kernel
private theorem cases1054 : checkFour 1054 (8889,0,8885,0) = true := by
  simp only [checkFour, w1054_0, w1054_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1054 : Coverage 1054 1055 := checkList_sound (ws:=[(8889,0,8885,0)]) (by simpa only [checkList, Bool.and_true] using cases1054)
private theorem w1055_0 : checkWitness 1055 false false 634 = true := by decide +kernel
private theorem w1055_1 : checkWitness 1055 false true 4726 = true := by decide +kernel
private theorem w1055_2 : checkWitness 1055 true false 625 = true := by decide +kernel
private theorem w1055_3 : checkWitness 1055 true true 4717 = true := by decide +kernel
private theorem cases1055 : checkFour 1055 (634,4726,625,4717) = true := by
  simp only [checkFour, w1055_0, w1055_1, w1055_2, w1055_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1055 : Coverage 1055 1056 := checkList_sound (ws:=[(634,4726,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases1055)
theorem cover1024 : Coverage 1024 1056 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1024 one1025) (Coverage.join one1026 one1027)) (Coverage.join (Coverage.join one1028 one1029) (Coverage.join one1030 one1031))) (Coverage.join (Coverage.join (Coverage.join one1032 one1033) (Coverage.join one1034 one1035)) (Coverage.join (Coverage.join one1036 one1037) (Coverage.join one1038 one1039)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1040 one1041) (Coverage.join one1042 one1043)) (Coverage.join (Coverage.join one1044 one1045) (Coverage.join one1046 one1047))) (Coverage.join (Coverage.join (Coverage.join one1048 one1049) (Coverage.join one1050 one1051)) (Coverage.join (Coverage.join one1052 one1053) (Coverage.join one1054 one1055)))))
end NF181PA.Symbolic
