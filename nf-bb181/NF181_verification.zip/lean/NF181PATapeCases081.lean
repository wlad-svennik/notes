import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2592_0 : checkWitness 2592 false false 562 = true := by decide +kernel
private theorem w2592_1 : checkWitness 2592 false true 4658 = true := by decide +kernel
private theorem w2592_2 : checkWitness 2592 true false 562 = true := by decide +kernel
private theorem w2592_3 : checkWitness 2592 true true 4658 = true := by decide +kernel
private theorem cases2592 : checkFour 2592 (562,4658,562,4658) = true := by
  simp only [checkFour, w2592_0, w2592_1, w2592_2, w2592_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2592 : Coverage 2592 2593 := checkList_sound (ws:=[(562,4658,562,4658)]) (by simpa only [checkList, Bool.and_true] using cases2592)
private theorem w2593_0 : checkWitness 2593 false false 8920 = true := by decide +kernel
private theorem w2593_2 : checkWitness 2593 true false 8916 = true := by decide +kernel
private theorem cases2593 : checkFour 2593 (8920,0,8916,0) = true := by
  simp only [checkFour, w2593_0, w2593_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2593 : Coverage 2593 2594 := checkList_sound (ws:=[(8920,0,8916,0)]) (by simpa only [checkList, Bool.and_true] using cases2593)
private theorem w2594_0 : checkWitness 2594 false false 48 = true := by decide +kernel
private theorem w2594_2 : checkWitness 2594 true false 48 = true := by decide +kernel
private theorem cases2594 : checkFour 2594 (48,0,48,0) = true := by
  simp only [checkFour, w2594_0, w2594_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2594 : Coverage 2594 2595 := checkList_sound (ws:=[(48,0,48,0)]) (by simpa only [checkList, Bool.and_true] using cases2594)
private theorem w2595_0 : checkWitness 2595 false false 600 = true := by decide +kernel
private theorem w2595_1 : checkWitness 2595 false true 4696 = true := by decide +kernel
private theorem w2595_2 : checkWitness 2595 true false 600 = true := by decide +kernel
private theorem w2595_3 : checkWitness 2595 true true 4696 = true := by decide +kernel
private theorem cases2595 : checkFour 2595 (600,4696,600,4696) = true := by
  simp only [checkFour, w2595_0, w2595_1, w2595_2, w2595_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2595 : Coverage 2595 2596 := checkList_sound (ws:=[(600,4696,600,4696)]) (by simpa only [checkList, Bool.and_true] using cases2595)
private theorem w2596_0 : checkWitness 2596 false false 8941 = true := by decide +kernel
private theorem w2596_2 : checkWitness 2596 true false 8937 = true := by decide +kernel
private theorem cases2596 : checkFour 2596 (8941,0,8937,0) = true := by
  simp only [checkFour, w2596_0, w2596_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2596 : Coverage 2596 2597 := checkList_sound (ws:=[(8941,0,8937,0)]) (by simpa only [checkList, Bool.and_true] using cases2596)
private theorem w2597_0 : checkWitness 2597 false false 8976 = true := by decide +kernel
private theorem w2597_2 : checkWitness 2597 true false 8967 = true := by decide +kernel
private theorem cases2597 : checkFour 2597 (8976,0,8967,0) = true := by
  simp only [checkFour, w2597_0, w2597_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2597 : Coverage 2597 2598 := checkList_sound (ws:=[(8976,0,8967,0)]) (by simpa only [checkList, Bool.and_true] using cases2597)
private theorem w2598_0 : checkWitness 2598 false false 72 = true := by decide +kernel
private theorem w2598_2 : checkWitness 2598 true false 72 = true := by decide +kernel
private theorem cases2598 : checkFour 2598 (72,0,72,0) = true := by
  simp only [checkFour, w2598_0, w2598_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2598 : Coverage 2598 2599 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases2598)
private theorem w2599_0 : checkWitness 2599 false false 688 = true := by decide +kernel
private theorem w2599_1 : checkWitness 2599 false true 4780 = true := by decide +kernel
private theorem w2599_2 : checkWitness 2599 true false 679 = true := by decide +kernel
private theorem w2599_3 : checkWitness 2599 true true 4771 = true := by decide +kernel
private theorem cases2599 : checkFour 2599 (688,4780,679,4771) = true := by
  simp only [checkFour, w2599_0, w2599_1, w2599_2, w2599_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2599 : Coverage 2599 2600 := checkList_sound (ws:=[(688,4780,679,4771)]) (by simpa only [checkList, Bool.and_true] using cases2599)
private theorem w2600_0 : checkWitness 2600 false false 8937 = true := by decide +kernel
private theorem w2600_2 : checkWitness 2600 true false 8933 = true := by decide +kernel
private theorem cases2600 : checkFour 2600 (8937,0,8933,0) = true := by
  simp only [checkFour, w2600_0, w2600_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2600 : Coverage 2600 2601 := checkList_sound (ws:=[(8937,0,8933,0)]) (by simpa only [checkList, Bool.and_true] using cases2600)
private theorem w2601_0 : checkWitness 2601 false false 682 = true := by decide +kernel
private theorem w2601_1 : checkWitness 2601 false true 4774 = true := by decide +kernel
private theorem w2601_2 : checkWitness 2601 true false 673 = true := by decide +kernel
private theorem w2601_3 : checkWitness 2601 true true 4765 = true := by decide +kernel
private theorem cases2601 : checkFour 2601 (682,4774,673,4765) = true := by
  simp only [checkFour, w2601_0, w2601_1, w2601_2, w2601_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2601 : Coverage 2601 2602 := checkList_sound (ws:=[(682,4774,673,4765)]) (by simpa only [checkList, Bool.and_true] using cases2601)
private theorem w2602_0 : checkWitness 2602 false false 8906 = true := by decide +kernel
private theorem w2602_2 : checkWitness 2602 true false 8902 = true := by decide +kernel
private theorem cases2602 : checkFour 2602 (8906,0,8902,0) = true := by
  simp only [checkFour, w2602_0, w2602_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2602 : Coverage 2602 2603 := checkList_sound (ws:=[(8906,0,8902,0)]) (by simpa only [checkList, Bool.and_true] using cases2602)
private theorem w2603_0 : checkWitness 2603 false false 60 = true := by decide +kernel
private theorem w2603_2 : checkWitness 2603 true false 60 = true := by decide +kernel
private theorem cases2603 : checkFour 2603 (60,0,60,0) = true := by
  simp only [checkFour, w2603_0, w2603_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2603 : Coverage 2603 2604 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2603)
private theorem w2604_0 : checkWitness 2604 false false 52 = true := by decide +kernel
private theorem w2604_2 : checkWitness 2604 true false 52 = true := by decide +kernel
private theorem cases2604 : checkFour 2604 (52,0,52,0) = true := by
  simp only [checkFour, w2604_0, w2604_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2604 : Coverage 2604 2605 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2604)
private theorem w2605_0 : checkWitness 2605 false false 647 = true := by decide +kernel
private theorem w2605_1 : checkWitness 2605 false true 4731 = true := by decide +kernel
private theorem w2605_2 : checkWitness 2605 true false 647 = true := by decide +kernel
private theorem w2605_3 : checkWitness 2605 true true 4731 = true := by decide +kernel
private theorem cases2605 : checkFour 2605 (647,4731,647,4731) = true := by
  simp only [checkFour, w2605_0, w2605_1, w2605_2, w2605_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2605 : Coverage 2605 2606 := checkList_sound (ws:=[(647,4731,647,4731)]) (by simpa only [checkList, Bool.and_true] using cases2605)
private theorem w2606_0 : checkWitness 2606 false false 8900 = true := by decide +kernel
private theorem w2606_2 : checkWitness 2606 true false 8896 = true := by decide +kernel
private theorem cases2606 : checkFour 2606 (8900,0,8896,0) = true := by
  simp only [checkFour, w2606_0, w2606_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2606 : Coverage 2606 2607 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases2606)
private theorem w2607_0 : checkWitness 2607 false false 52 = true := by decide +kernel
private theorem w2607_2 : checkWitness 2607 true false 52 = true := by decide +kernel
private theorem cases2607 : checkFour 2607 (52,0,52,0) = true := by
  simp only [checkFour, w2607_0, w2607_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2607 : Coverage 2607 2608 := checkList_sound (ws:=[(52,0,52,0)]) (by simpa only [checkList, Bool.and_true] using cases2607)
private theorem w2608_0 : checkWitness 2608 false false 615 = true := by decide +kernel
private theorem w2608_1 : checkWitness 2608 false true 4711 = true := by decide +kernel
private theorem w2608_2 : checkWitness 2608 true false 615 = true := by decide +kernel
private theorem w2608_3 : checkWitness 2608 true true 4711 = true := by decide +kernel
private theorem cases2608 : checkFour 2608 (615,4711,615,4711) = true := by
  simp only [checkFour, w2608_0, w2608_1, w2608_2, w2608_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2608 : Coverage 2608 2609 := checkList_sound (ws:=[(615,4711,615,4711)]) (by simpa only [checkList, Bool.and_true] using cases2608)
private theorem w2609_0 : checkWitness 2609 false false 8968 = true := by decide +kernel
private theorem w2609_2 : checkWitness 2609 true false 8959 = true := by decide +kernel
private theorem cases2609 : checkFour 2609 (8968,0,8959,0) = true := by
  simp only [checkFour, w2609_0, w2609_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2609 : Coverage 2609 2610 := checkList_sound (ws:=[(8968,0,8959,0)]) (by simpa only [checkList, Bool.and_true] using cases2609)
private theorem w2610_0 : checkWitness 2610 false false 8914 = true := by decide +kernel
private theorem w2610_2 : checkWitness 2610 true false 8910 = true := by decide +kernel
private theorem cases2610 : checkFour 2610 (8914,0,8910,0) = true := by
  simp only [checkFour, w2610_0, w2610_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2610 : Coverage 2610 2611 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases2610)
private theorem w2611_0 : checkWitness 2611 false false 60 = true := by decide +kernel
private theorem w2611_2 : checkWitness 2611 true false 60 = true := by decide +kernel
private theorem cases2611 : checkFour 2611 (60,0,60,0) = true := by
  simp only [checkFour, w2611_0, w2611_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2611 : Coverage 2611 2612 := checkList_sound (ws:=[(60,0,60,0)]) (by simpa only [checkList, Bool.and_true] using cases2611)
private theorem w2612_0 : checkWitness 2612 false false 698 = true := by decide +kernel
private theorem w2612_1 : checkWitness 2612 false true 4786 = true := by decide +kernel
private theorem w2612_2 : checkWitness 2612 true false 689 = true := by decide +kernel
private theorem w2612_3 : checkWitness 2612 true true 4777 = true := by decide +kernel
private theorem cases2612 : checkFour 2612 (698,4786,689,4777) = true := by
  simp only [checkFour, w2612_0, w2612_1, w2612_2, w2612_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2612 : Coverage 2612 2613 := checkList_sound (ws:=[(698,4786,689,4777)]) (by simpa only [checkList, Bool.and_true] using cases2612)
private theorem w2613_0 : checkWitness 2613 false false 8933 = true := by decide +kernel
private theorem w2613_2 : checkWitness 2613 true false 8929 = true := by decide +kernel
private theorem cases2613 : checkFour 2613 (8933,0,8929,0) = true := by
  simp only [checkFour, w2613_0, w2613_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2613 : Coverage 2613 2614 := checkList_sound (ws:=[(8933,0,8929,0)]) (by simpa only [checkList, Bool.and_true] using cases2613)
private theorem w2614_0 : checkWitness 2614 false false 50 = true := by decide +kernel
private theorem w2614_2 : checkWitness 2614 true false 50 = true := by decide +kernel
private theorem cases2614 : checkFour 2614 (50,0,50,0) = true := by
  simp only [checkFour, w2614_0, w2614_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2614 : Coverage 2614 2615 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2614)
private theorem w2615_0 : checkWitness 2615 false false 580 = true := by decide +kernel
private theorem w2615_1 : checkWitness 2615 false true 4676 = true := by decide +kernel
private theorem w2615_2 : checkWitness 2615 true false 580 = true := by decide +kernel
private theorem w2615_3 : checkWitness 2615 true true 4676 = true := by decide +kernel
private theorem cases2615 : checkFour 2615 (580,4676,580,4676) = true := by
  simp only [checkFour, w2615_0, w2615_1, w2615_2, w2615_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2615 : Coverage 2615 2616 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases2615)
private theorem w2616_0 : checkWitness 2616 false false 8990 = true := by decide +kernel
private theorem w2616_2 : checkWitness 2616 true false 8981 = true := by decide +kernel
private theorem cases2616 : checkFour 2616 (8990,0,8981,0) = true := by
  simp only [checkFour, w2616_0, w2616_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2616 : Coverage 2616 2617 := checkList_sound (ws:=[(8990,0,8981,0)]) (by simpa only [checkList, Bool.and_true] using cases2616)
private theorem w2617_0 : checkWitness 2617 false false 56 = true := by decide +kernel
private theorem w2617_2 : checkWitness 2617 true false 56 = true := by decide +kernel
private theorem cases2617 : checkFour 2617 (56,0,56,0) = true := by
  simp only [checkFour, w2617_0, w2617_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2617 : Coverage 2617 2618 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2617)
private theorem w2618_0 : checkWitness 2618 false false 572 = true := by decide +kernel
private theorem w2618_1 : checkWitness 2618 false true 4668 = true := by decide +kernel
private theorem w2618_2 : checkWitness 2618 true false 572 = true := by decide +kernel
private theorem w2618_3 : checkWitness 2618 true true 4668 = true := by decide +kernel
private theorem cases2618 : checkFour 2618 (572,4668,572,4668) = true := by
  simp only [checkFour, w2618_0, w2618_1, w2618_2, w2618_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2618 : Coverage 2618 2619 := checkList_sound (ws:=[(572,4668,572,4668)]) (by simpa only [checkList, Bool.and_true] using cases2618)
private theorem w2619_0 : checkWitness 2619 false false 8930 = true := by decide +kernel
private theorem w2619_2 : checkWitness 2619 true false 8926 = true := by decide +kernel
private theorem cases2619 : checkFour 2619 (8930,0,8926,0) = true := by
  simp only [checkFour, w2619_0, w2619_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2619 : Coverage 2619 2620 := checkList_sound (ws:=[(8930,0,8926,0)]) (by simpa only [checkList, Bool.and_true] using cases2619)
private theorem w2620_0 : checkWitness 2620 false false 58 = true := by decide +kernel
private theorem w2620_2 : checkWitness 2620 true false 58 = true := by decide +kernel
private theorem cases2620 : checkFour 2620 (58,0,58,0) = true := by
  simp only [checkFour, w2620_0, w2620_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2620 : Coverage 2620 2621 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases2620)
private theorem w2621_0 : checkWitness 2621 false false 610 = true := by decide +kernel
private theorem w2621_1 : checkWitness 2621 false true 4706 = true := by decide +kernel
private theorem w2621_2 : checkWitness 2621 true false 610 = true := by decide +kernel
private theorem w2621_3 : checkWitness 2621 true true 4706 = true := by decide +kernel
private theorem cases2621 : checkFour 2621 (610,4706,610,4706) = true := by
  simp only [checkFour, w2621_0, w2621_1, w2621_2, w2621_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2621 : Coverage 2621 2622 := checkList_sound (ws:=[(610,4706,610,4706)]) (by simpa only [checkList, Bool.and_true] using cases2621)
private theorem w2622_0 : checkWitness 2622 false false 8951 = true := by decide +kernel
private theorem w2622_2 : checkWitness 2622 true false 8947 = true := by decide +kernel
private theorem cases2622 : checkFour 2622 (8951,0,8947,0) = true := by
  simp only [checkFour, w2622_0, w2622_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2622 : Coverage 2622 2623 := checkList_sound (ws:=[(8951,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases2622)
private theorem w2623_0 : checkWitness 2623 false false 8986 = true := by decide +kernel
private theorem w2623_2 : checkWitness 2623 true false 8977 = true := by decide +kernel
private theorem cases2623 : checkFour 2623 (8986,0,8977,0) = true := by
  simp only [checkFour, w2623_0, w2623_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2623 : Coverage 2623 2624 := checkList_sound (ws:=[(8986,0,8977,0)]) (by simpa only [checkList, Bool.and_true] using cases2623)
theorem cover2592 : Coverage 2592 2624 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2592 one2593) (Coverage.join one2594 one2595)) (Coverage.join (Coverage.join one2596 one2597) (Coverage.join one2598 one2599))) (Coverage.join (Coverage.join (Coverage.join one2600 one2601) (Coverage.join one2602 one2603)) (Coverage.join (Coverage.join one2604 one2605) (Coverage.join one2606 one2607)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2608 one2609) (Coverage.join one2610 one2611)) (Coverage.join (Coverage.join one2612 one2613) (Coverage.join one2614 one2615))) (Coverage.join (Coverage.join (Coverage.join one2616 one2617) (Coverage.join one2618 one2619)) (Coverage.join (Coverage.join one2620 one2621) (Coverage.join one2622 one2623)))))
end NF181PA.Symbolic
