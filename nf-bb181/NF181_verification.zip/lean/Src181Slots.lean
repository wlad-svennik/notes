module
public import Src181Chart
public import Src181Templates
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

def destination (pc size done halt i : Nat) := if i<size then pc+i else if i=size then done else halt

def slots086 : Slots := ⟨0,8,6,by decide,by decide,by decide⟩
def slots160 : Slots := ⟨1,6,0,by decide,by decide,by decide⟩
def slots210 : Slots := ⟨2,1,0,by decide,by decide,by decide⟩
def slots267 : Slots := ⟨2,6,7,by decide,by decide,by decide⟩
def slots361 : Slots := ⟨3,6,1,by decide,by decide,by decide⟩
def slots401 : Slots := ⟨4,0,1,by decide,by decide,by decide⟩
def slots461 : Slots := ⟨4,6,1,by decide,by decide,by decide⟩
def slots501 : Slots := ⟨5,0,1,by decide,by decide,by decide⟩
def slots561 : Slots := ⟨5,6,1,by decide,by decide,by decide⟩
def slots601 : Slots := ⟨6,0,1,by decide,by decide,by decide⟩
def slots617 : Slots := ⟨6,1,7,by decide,by decide,by decide⟩
def slots630 : Slots := ⟨6,3,0,by decide,by decide,by decide⟩
def slots640 : Slots := ⟨6,4,0,by decide,by decide,by decide⟩
def slots650 : Slots := ⟨6,5,0,by decide,by decide,by decide⟩
def slots710 : Slots := ⟨7,1,0,by decide,by decide,by decide⟩
def slots720 : Slots := ⟨7,2,0,by decide,by decide,by decide⟩
def slots780 : Slots := ⟨7,8,0,by decide,by decide,by decide⟩
def slots867 : Slots := ⟨8,6,7,by decide,by decide,by decide⟩
end PA192.ModelSearch.Register181.Certified
