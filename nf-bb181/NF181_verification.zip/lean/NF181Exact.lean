import NF181ExactCore
import NF181PATapeAll
namespace NFMachine181
open FFL FFL.FirstOrder NF210 NF181PA
/-- The released 181-state table halts on blank tape iff pure NF proves falsum. -/
theorem halts_iff_nf_refutation : TM.Halts Direct181.Table.machine Direct181.Table.start ↔ (𝗡𝗙 ⊢ ⊥) :=
  halts_iff_nf_refutation_of_coverage Symbolic.literal_table_coverage
end NFMachine181
#print axioms NFMachine181.halts_iff_nf_refutation
