module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site0485Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 485 f r x y z) (slots617.atReg 495 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 485 10 495 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 485 489 486 f r (row_of_literal 485 _ (by decide) RawRows.raw0485))
    (slots617.pos_y 485 489 486 f r (row_of_literal 485 _ (by decide) RawRows.raw0485))
    (slots617.inc_z 486 487 f r (row_of_literal 486 _ (by decide) RawRows.raw0486) (Or.inl (by decide)))
    (slots617.inc_x 487 488 f r (row_of_literal 487 _ (by decide) RawRows.raw0487) (Or.inl (by decide)))
    (slots617.jump 488 485 f r (row_of_literal 488 _ (by decide) RawRows.raw0488))
    (slots617.zero_x 489 495 490 f r (row_of_literal 489 _ (by decide) RawRows.raw0489))
    (slots617.pos_x 489 495 490 f r (row_of_literal 489 _ (by decide) RawRows.raw0489))
    (slots617.inc_z 490 491 f r (row_of_literal 490 _ (by decide) RawRows.raw0490) (Or.inl (by decide)))
    (slots617.zero_x 491 494 492 f r (row_of_literal 491 _ (by decide) RawRows.raw0491))
    (slots617.pos_x 491 494 492 f r (row_of_literal 491 _ (by decide) RawRows.raw0491))
    (slots617.inc_y 492 493 f r (row_of_literal 492 _ (by decide) RawRows.raw0492) (Or.inl (by decide)))
    (slots617.jump 493 491 f r (row_of_literal 493 _ (by decide) RawRows.raw0493))
    (slots617.jump 494 485 f r (row_of_literal 494 _ (by decide) RawRows.raw0494))

theorem site0485 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((485:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((495:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0485Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0495Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 495 f r x y z) (slots720.atReg 498 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 495 3 498 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 495 498 496 f r (row_of_literal 495 _ (by decide) RawRows.raw0495))
    (slots720.pos_x 495 498 496 f r (row_of_literal 495 _ (by decide) RawRows.raw0495))
    (slots720.inc_y 496 497 f r (row_of_literal 496 _ (by decide) RawRows.raw0496) (Or.inl (by decide)))
    (slots720.jump 497 495 f r (row_of_literal 497 _ (by decide) RawRows.raw0497))

theorem site0495 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((495:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((498:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0495Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0498Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 498 f r x y z) (slots461.atReg 502 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 498 4 502 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 498 502 499 f r (row_of_literal 498 _ (by decide) RawRows.raw0498))
    (slots461.pos_x 498 502 499 f r (row_of_literal 498 _ (by decide) RawRows.raw0498))
    (slots461.inc_y 499 500 f r (row_of_literal 499 _ (by decide) RawRows.raw0499) (Or.inl (by decide)))
    (slots461.inc_z 500 501 f r (row_of_literal 500 _ (by decide) RawRows.raw0500) (Or.inl (by decide)))
    (slots461.jump 501 498 f r (row_of_literal 501 _ (by decide) RawRows.raw0501))

theorem site0498 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((498:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((502:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0498Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site0502Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 502 f r x y z) (slots640.atReg 505 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 502 3 505 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 502 505 503 f r (row_of_literal 502 _ (by decide) RawRows.raw0502))
    (slots640.pos_x 502 505 503 f r (row_of_literal 502 _ (by decide) RawRows.raw0502))
    (slots640.inc_y 503 504 f r (row_of_literal 503 _ (by decide) RawRows.raw0503) (Or.inl (by decide)))
    (slots640.jump 504 502 f r (row_of_literal 504 _ (by decide) RawRows.raw0504))

theorem site0502 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((502:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((505:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0502Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site0505Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 505 f r x y z) (slots267.atReg 513 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 505 8 513 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 505 513 506 f r (row_of_literal 505 _ (by decide) RawRows.raw0505))
    (slots267.pos_x 505 513 506 f r (row_of_literal 505 _ (by decide) RawRows.raw0505))
    (slots267.inc_z 506 507 f r (row_of_literal 506 _ (by decide) RawRows.raw0506) (Or.inl (by decide)))
    (slots267.zero_y 507 509 508 f r (row_of_literal 507 _ (by decide) RawRows.raw0507))
    (slots267.pos_y 507 509 508 f r (row_of_literal 507 _ (by decide) RawRows.raw0507))
    (slots267.jump 508 512 f r (row_of_literal 508 _ (by decide) RawRows.raw0508))
    (slots267.zero_z 509 512 510 f r (row_of_literal 509 _ (by decide) RawRows.raw0509))
    (slots267.pos_z 509 512 510 f r (row_of_literal 509 _ (by decide) RawRows.raw0509))
    (slots267.inc_y 510 511 f r (row_of_literal 510 _ (by decide) RawRows.raw0510) (Or.inl (by decide)))
    (slots267.jump 511 509 f r (row_of_literal 511 _ (by decide) RawRows.raw0511))
    (slots267.jump 512 505 f r (row_of_literal 512 _ (by decide) RawRows.raw0512))

theorem site0505 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((505:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((513:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0505Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0513Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 513 f r x y z) (slots720.atReg 516 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 513 3 516 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 513 516 514 f r (row_of_literal 513 _ (by decide) RawRows.raw0513))
    (slots720.pos_x 513 516 514 f r (row_of_literal 513 _ (by decide) RawRows.raw0513))
    (slots720.inc_y 514 515 f r (row_of_literal 514 _ (by decide) RawRows.raw0514) (Or.inl (by decide)))
    (slots720.jump 515 513 f r (row_of_literal 515 _ (by decide) RawRows.raw0515))

theorem site0513 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((513:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((516:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0513Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0516Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 516 f r x y z) (slots617.atReg 526 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 516 10 526 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 516 520 517 f r (row_of_literal 516 _ (by decide) RawRows.raw0516))
    (slots617.pos_y 516 520 517 f r (row_of_literal 516 _ (by decide) RawRows.raw0516))
    (slots617.inc_z 517 518 f r (row_of_literal 517 _ (by decide) RawRows.raw0517) (Or.inl (by decide)))
    (slots617.inc_x 518 519 f r (row_of_literal 518 _ (by decide) RawRows.raw0518) (Or.inl (by decide)))
    (slots617.jump 519 516 f r (row_of_literal 519 _ (by decide) RawRows.raw0519))
    (slots617.zero_x 520 526 521 f r (row_of_literal 520 _ (by decide) RawRows.raw0520))
    (slots617.pos_x 520 526 521 f r (row_of_literal 520 _ (by decide) RawRows.raw0520))
    (slots617.inc_z 521 522 f r (row_of_literal 521 _ (by decide) RawRows.raw0521) (Or.inl (by decide)))
    (slots617.zero_x 522 525 523 f r (row_of_literal 522 _ (by decide) RawRows.raw0522))
    (slots617.pos_x 522 525 523 f r (row_of_literal 522 _ (by decide) RawRows.raw0522))
    (slots617.inc_y 523 524 f r (row_of_literal 523 _ (by decide) RawRows.raw0523) (Or.inl (by decide)))
    (slots617.jump 524 522 f r (row_of_literal 524 _ (by decide) RawRows.raw0524))
    (slots617.jump 525 516 f r (row_of_literal 525 _ (by decide) RawRows.raw0525))

theorem site0516 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((516:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((526:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0516Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0526Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 526 f r x y z) (slots710.atReg 530 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 526 4 530 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 526 530 527 f r (row_of_literal 526 _ (by decide) RawRows.raw0526))
    (slots710.pos_x 526 530 527 f r (row_of_literal 526 _ (by decide) RawRows.raw0526))
    (slots710.inc_y 527 528 f r (row_of_literal 527 _ (by decide) RawRows.raw0527) (Or.inl (by decide)))
    (slots710.inc_y 528 529 f r (row_of_literal 528 _ (by decide) RawRows.raw0528) (Or.inl (by decide)))
    (slots710.jump 529 526 f r (row_of_literal 529 _ (by decide) RawRows.raw0529))

theorem site0526 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((526:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((530:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0526Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site0530 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((530:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((531:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 530 _ (row_of_literal 530 _ (by decide) RawRows.raw0530)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site0531Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 531 f r x y z) (slots160.atReg 534 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 531 3 534 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 531 534 532 f r (row_of_literal 531 _ (by decide) RawRows.raw0531))
    (slots160.pos_x 531 534 532 f r (row_of_literal 531 _ (by decide) RawRows.raw0531))
    (slots160.inc_y 532 533 f r (row_of_literal 532 _ (by decide) RawRows.raw0532) (Or.inl (by decide)))
    (slots160.jump 533 531 f r (row_of_literal 533 _ (by decide) RawRows.raw0533))

theorem site0531 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((531:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((534:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0531Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0534Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 534 f r x y z) (slots210.atReg 537 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 534 3 537 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 534 537 535 f r (row_of_literal 534 _ (by decide) RawRows.raw0534))
    (slots210.pos_x 534 537 535 f r (row_of_literal 534 _ (by decide) RawRows.raw0534))
    (slots210.inc_y 535 536 f r (row_of_literal 535 _ (by decide) RawRows.raw0535) (Or.inl (by decide)))
    (slots210.jump 536 534 f r (row_of_literal 536 _ (by decide) RawRows.raw0536))

theorem site0534 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((534:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((537:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0534Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0537Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 537 f r x y z) (slots617.atReg 547 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 537 10 547 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 537 541 538 f r (row_of_literal 537 _ (by decide) RawRows.raw0537))
    (slots617.pos_y 537 541 538 f r (row_of_literal 537 _ (by decide) RawRows.raw0537))
    (slots617.inc_z 538 539 f r (row_of_literal 538 _ (by decide) RawRows.raw0538) (Or.inl (by decide)))
    (slots617.inc_x 539 540 f r (row_of_literal 539 _ (by decide) RawRows.raw0539) (Or.inl (by decide)))
    (slots617.jump 540 537 f r (row_of_literal 540 _ (by decide) RawRows.raw0540))
    (slots617.zero_x 541 547 542 f r (row_of_literal 541 _ (by decide) RawRows.raw0541))
    (slots617.pos_x 541 547 542 f r (row_of_literal 541 _ (by decide) RawRows.raw0541))
    (slots617.inc_z 542 543 f r (row_of_literal 542 _ (by decide) RawRows.raw0542) (Or.inl (by decide)))
    (slots617.zero_x 543 546 544 f r (row_of_literal 543 _ (by decide) RawRows.raw0543))
    (slots617.pos_x 543 546 544 f r (row_of_literal 543 _ (by decide) RawRows.raw0543))
    (slots617.inc_y 544 545 f r (row_of_literal 544 _ (by decide) RawRows.raw0544) (Or.inl (by decide)))
    (slots617.jump 545 543 f r (row_of_literal 545 _ (by decide) RawRows.raw0545))
    (slots617.jump 546 537 f r (row_of_literal 546 _ (by decide) RawRows.raw0546))

theorem site0537 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((537:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((547:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0537Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0547Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 547 f r x y z) (slots720.atReg 550 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 547 3 550 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 547 550 548 f r (row_of_literal 547 _ (by decide) RawRows.raw0547))
    (slots720.pos_x 547 550 548 f r (row_of_literal 547 _ (by decide) RawRows.raw0547))
    (slots720.inc_y 548 549 f r (row_of_literal 548 _ (by decide) RawRows.raw0548) (Or.inl (by decide)))
    (slots720.jump 549 547 f r (row_of_literal 549 _ (by decide) RawRows.raw0549))

theorem site0547 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((547:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((550:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0547Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0550Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 550 f r x y z) (slots561.atReg 554 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 550 4 554 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 550 554 551 f r (row_of_literal 550 _ (by decide) RawRows.raw0550))
    (slots561.pos_x 550 554 551 f r (row_of_literal 550 _ (by decide) RawRows.raw0550))
    (slots561.inc_y 551 552 f r (row_of_literal 551 _ (by decide) RawRows.raw0551) (Or.inl (by decide)))
    (slots561.inc_z 552 553 f r (row_of_literal 552 _ (by decide) RawRows.raw0552) (Or.inl (by decide)))
    (slots561.jump 553 550 f r (row_of_literal 553 _ (by decide) RawRows.raw0553))

theorem site0550 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((550:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((554:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0550Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site0554Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 554 f r x y z) (slots650.atReg 557 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 554 3 557 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 554 557 555 f r (row_of_literal 554 _ (by decide) RawRows.raw0554))
    (slots650.pos_x 554 557 555 f r (row_of_literal 554 _ (by decide) RawRows.raw0554))
    (slots650.inc_y 555 556 f r (row_of_literal 555 _ (by decide) RawRows.raw0555) (Or.inl (by decide)))
    (slots650.jump 556 554 f r (row_of_literal 556 _ (by decide) RawRows.raw0556))

theorem site0554 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((554:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((557:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0554Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site0557Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 557 f r x y z) (slots267.atReg 565 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 557 8 565 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 557 565 558 f r (row_of_literal 557 _ (by decide) RawRows.raw0557))
    (slots267.pos_x 557 565 558 f r (row_of_literal 557 _ (by decide) RawRows.raw0557))
    (slots267.inc_z 558 559 f r (row_of_literal 558 _ (by decide) RawRows.raw0558) (Or.inl (by decide)))
    (slots267.zero_y 559 561 560 f r (row_of_literal 559 _ (by decide) RawRows.raw0559))
    (slots267.pos_y 559 561 560 f r (row_of_literal 559 _ (by decide) RawRows.raw0559))
    (slots267.jump 560 564 f r (row_of_literal 560 _ (by decide) RawRows.raw0560))
    (slots267.zero_z 561 564 562 f r (row_of_literal 561 _ (by decide) RawRows.raw0561))
    (slots267.pos_z 561 564 562 f r (row_of_literal 561 _ (by decide) RawRows.raw0561))
    (slots267.inc_y 562 563 f r (row_of_literal 562 _ (by decide) RawRows.raw0562) (Or.inl (by decide)))
    (slots267.jump 563 561 f r (row_of_literal 563 _ (by decide) RawRows.raw0563))
    (slots267.jump 564 557 f r (row_of_literal 564 _ (by decide) RawRows.raw0564))

theorem site0557 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((557:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((565:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0557Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0565Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 565 f r x y z) (slots720.atReg 568 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 565 3 568 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 565 568 566 f r (row_of_literal 565 _ (by decide) RawRows.raw0565))
    (slots720.pos_x 565 568 566 f r (row_of_literal 565 _ (by decide) RawRows.raw0565))
    (slots720.inc_y 566 567 f r (row_of_literal 566 _ (by decide) RawRows.raw0566) (Or.inl (by decide)))
    (slots720.jump 567 565 f r (row_of_literal 567 _ (by decide) RawRows.raw0567))

theorem site0565 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((565:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((568:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0565Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0568Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 568 f r x y z) (slots617.atReg 578 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 568 10 578 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 568 572 569 f r (row_of_literal 568 _ (by decide) RawRows.raw0568))
    (slots617.pos_y 568 572 569 f r (row_of_literal 568 _ (by decide) RawRows.raw0568))
    (slots617.inc_z 569 570 f r (row_of_literal 569 _ (by decide) RawRows.raw0569) (Or.inl (by decide)))
    (slots617.inc_x 570 571 f r (row_of_literal 570 _ (by decide) RawRows.raw0570) (Or.inl (by decide)))
    (slots617.jump 571 568 f r (row_of_literal 571 _ (by decide) RawRows.raw0571))
    (slots617.zero_x 572 578 573 f r (row_of_literal 572 _ (by decide) RawRows.raw0572))
    (slots617.pos_x 572 578 573 f r (row_of_literal 572 _ (by decide) RawRows.raw0572))
    (slots617.inc_z 573 574 f r (row_of_literal 573 _ (by decide) RawRows.raw0573) (Or.inl (by decide)))
    (slots617.zero_x 574 577 575 f r (row_of_literal 574 _ (by decide) RawRows.raw0574))
    (slots617.pos_x 574 577 575 f r (row_of_literal 574 _ (by decide) RawRows.raw0574))
    (slots617.inc_y 575 576 f r (row_of_literal 575 _ (by decide) RawRows.raw0575) (Or.inl (by decide)))
    (slots617.jump 576 574 f r (row_of_literal 576 _ (by decide) RawRows.raw0576))
    (slots617.jump 577 568 f r (row_of_literal 577 _ (by decide) RawRows.raw0577))

theorem site0568 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((568:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((578:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0568Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0578Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 578 f r x y z) (slots710.atReg 582 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 578 4 582 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 578 582 579 f r (row_of_literal 578 _ (by decide) RawRows.raw0578))
    (slots710.pos_x 578 582 579 f r (row_of_literal 578 _ (by decide) RawRows.raw0578))
    (slots710.inc_y 579 580 f r (row_of_literal 579 _ (by decide) RawRows.raw0579) (Or.inl (by decide)))
    (slots710.inc_y 580 581 f r (row_of_literal 580 _ (by decide) RawRows.raw0580) (Or.inl (by decide)))
    (slots710.jump 581 578 f r (row_of_literal 581 _ (by decide) RawRows.raw0581))

theorem site0578 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((578:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((582:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0578Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site0582 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((582:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((583:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 582 _ (row_of_literal 582 _ (by decide) RawRows.raw0582)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site0583Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 583 f r x y z) (slots160.atReg 586 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 583 3 586 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 583 586 584 f r (row_of_literal 583 _ (by decide) RawRows.raw0583))
    (slots160.pos_x 583 586 584 f r (row_of_literal 583 _ (by decide) RawRows.raw0583))
    (slots160.inc_y 584 585 f r (row_of_literal 584 _ (by decide) RawRows.raw0584) (Or.inl (by decide)))
    (slots160.jump 585 583 f r (row_of_literal 585 _ (by decide) RawRows.raw0585))

theorem site0583 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((583:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((586:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0583Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0586Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 586 f r x y z) (slots210.atReg 589 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 586 3 589 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 586 589 587 f r (row_of_literal 586 _ (by decide) RawRows.raw0586))
    (slots210.pos_x 586 589 587 f r (row_of_literal 586 _ (by decide) RawRows.raw0586))
    (slots210.inc_y 587 588 f r (row_of_literal 587 _ (by decide) RawRows.raw0587) (Or.inl (by decide)))
    (slots210.jump 588 586 f r (row_of_literal 588 _ (by decide) RawRows.raw0588))

theorem site0586 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((586:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((589:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0586Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0589Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 589 f r x y z) (slots617.atReg 599 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 589 10 599 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 589 593 590 f r (row_of_literal 589 _ (by decide) RawRows.raw0589))
    (slots617.pos_y 589 593 590 f r (row_of_literal 589 _ (by decide) RawRows.raw0589))
    (slots617.inc_z 590 591 f r (row_of_literal 590 _ (by decide) RawRows.raw0590) (Or.inl (by decide)))
    (slots617.inc_x 591 592 f r (row_of_literal 591 _ (by decide) RawRows.raw0591) (Or.inl (by decide)))
    (slots617.jump 592 589 f r (row_of_literal 592 _ (by decide) RawRows.raw0592))
    (slots617.zero_x 593 599 594 f r (row_of_literal 593 _ (by decide) RawRows.raw0593))
    (slots617.pos_x 593 599 594 f r (row_of_literal 593 _ (by decide) RawRows.raw0593))
    (slots617.inc_z 594 595 f r (row_of_literal 594 _ (by decide) RawRows.raw0594) (Or.inl (by decide)))
    (slots617.zero_x 595 598 596 f r (row_of_literal 595 _ (by decide) RawRows.raw0595))
    (slots617.pos_x 595 598 596 f r (row_of_literal 595 _ (by decide) RawRows.raw0595))
    (slots617.inc_y 596 597 f r (row_of_literal 596 _ (by decide) RawRows.raw0596) (Or.inl (by decide)))
    (slots617.jump 597 595 f r (row_of_literal 597 _ (by decide) RawRows.raw0597))
    (slots617.jump 598 589 f r (row_of_literal 598 _ (by decide) RawRows.raw0598))

theorem site0589 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((589:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((599:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0589Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0599Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 599 f r x y z) (slots720.atReg 602 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 599 3 602 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 599 602 600 f r (row_of_literal 599 _ (by decide) RawRows.raw0599))
    (slots720.pos_x 599 602 600 f r (row_of_literal 599 _ (by decide) RawRows.raw0599))
    (slots720.inc_y 600 601 f r (row_of_literal 600 _ (by decide) RawRows.raw0600) (Or.inl (by decide)))
    (slots720.jump 601 599 f r (row_of_literal 601 _ (by decide) RawRows.raw0601))

theorem site0599 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((599:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((602:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0599Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0602Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 602 f r x y z) (slots461.atReg 606 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 602 4 606 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 602 606 603 f r (row_of_literal 602 _ (by decide) RawRows.raw0602))
    (slots461.pos_x 602 606 603 f r (row_of_literal 602 _ (by decide) RawRows.raw0602))
    (slots461.inc_y 603 604 f r (row_of_literal 603 _ (by decide) RawRows.raw0603) (Or.inl (by decide)))
    (slots461.inc_z 604 605 f r (row_of_literal 604 _ (by decide) RawRows.raw0604) (Or.inl (by decide)))
    (slots461.jump 605 602 f r (row_of_literal 605 _ (by decide) RawRows.raw0605))

theorem site0602 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((602:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((606:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0602Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site0606Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 606 f r x y z) (slots640.atReg 609 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 606 3 609 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 606 609 607 f r (row_of_literal 606 _ (by decide) RawRows.raw0606))
    (slots640.pos_x 606 609 607 f r (row_of_literal 606 _ (by decide) RawRows.raw0606))
    (slots640.inc_y 607 608 f r (row_of_literal 607 _ (by decide) RawRows.raw0607) (Or.inl (by decide)))
    (slots640.jump 608 606 f r (row_of_literal 608 _ (by decide) RawRows.raw0608))

theorem site0606 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((606:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((609:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0606Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site0609Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 609 f r x y z) (slots160.atReg 612 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 609 3 612 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 609 612 610 f r (row_of_literal 609 _ (by decide) RawRows.raw0609))
    (slots160.pos_x 609 612 610 f r (row_of_literal 609 _ (by decide) RawRows.raw0609))
    (slots160.inc_y 610 611 f r (row_of_literal 610 _ (by decide) RawRows.raw0610) (Or.inl (by decide)))
    (slots160.jump 611 609 f r (row_of_literal 611 _ (by decide) RawRows.raw0611))

theorem site0609 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((609:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((612:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0609Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0612Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 612 f r x y z) (slots210.atReg 615 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 612 3 615 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 612 615 613 f r (row_of_literal 612 _ (by decide) RawRows.raw0612))
    (slots210.pos_x 612 615 613 f r (row_of_literal 612 _ (by decide) RawRows.raw0612))
    (slots210.inc_y 613 614 f r (row_of_literal 613 _ (by decide) RawRows.raw0613) (Or.inl (by decide)))
    (slots210.jump 614 612 f r (row_of_literal 614 _ (by decide) RawRows.raw0614))

theorem site0612 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((612:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((615:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0612Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0615Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 615 f r x y z) (slots617.atReg 625 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 615 10 625 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 615 619 616 f r (row_of_literal 615 _ (by decide) RawRows.raw0615))
    (slots617.pos_y 615 619 616 f r (row_of_literal 615 _ (by decide) RawRows.raw0615))
    (slots617.inc_z 616 617 f r (row_of_literal 616 _ (by decide) RawRows.raw0616) (Or.inl (by decide)))
    (slots617.inc_x 617 618 f r (row_of_literal 617 _ (by decide) RawRows.raw0617) (Or.inl (by decide)))
    (slots617.jump 618 615 f r (row_of_literal 618 _ (by decide) RawRows.raw0618))
    (slots617.zero_x 619 625 620 f r (row_of_literal 619 _ (by decide) RawRows.raw0619))
    (slots617.pos_x 619 625 620 f r (row_of_literal 619 _ (by decide) RawRows.raw0619))
    (slots617.inc_z 620 621 f r (row_of_literal 620 _ (by decide) RawRows.raw0620) (Or.inl (by decide)))
    (slots617.zero_x 621 624 622 f r (row_of_literal 621 _ (by decide) RawRows.raw0621))
    (slots617.pos_x 621 624 622 f r (row_of_literal 621 _ (by decide) RawRows.raw0621))
    (slots617.inc_y 622 623 f r (row_of_literal 622 _ (by decide) RawRows.raw0622) (Or.inl (by decide)))
    (slots617.jump 623 621 f r (row_of_literal 623 _ (by decide) RawRows.raw0623))
    (slots617.jump 624 615 f r (row_of_literal 624 _ (by decide) RawRows.raw0624))

theorem site0615 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((615:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((625:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0615Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0625Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 625 f r x y z) (slots720.atReg 628 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 625 3 628 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 625 628 626 f r (row_of_literal 625 _ (by decide) RawRows.raw0625))
    (slots720.pos_x 625 628 626 f r (row_of_literal 625 _ (by decide) RawRows.raw0625))
    (slots720.inc_y 626 627 f r (row_of_literal 626 _ (by decide) RawRows.raw0626) (Or.inl (by decide)))
    (slots720.jump 627 625 f r (row_of_literal 627 _ (by decide) RawRows.raw0627))

theorem site0625 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((625:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((628:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0625Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0628Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 628 f r x y z) (slots561.atReg 632 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 628 4 632 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 628 632 629 f r (row_of_literal 628 _ (by decide) RawRows.raw0628))
    (slots561.pos_x 628 632 629 f r (row_of_literal 628 _ (by decide) RawRows.raw0628))
    (slots561.inc_y 629 630 f r (row_of_literal 629 _ (by decide) RawRows.raw0629) (Or.inl (by decide)))
    (slots561.inc_z 630 631 f r (row_of_literal 630 _ (by decide) RawRows.raw0630) (Or.inl (by decide)))
    (slots561.jump 631 628 f r (row_of_literal 631 _ (by decide) RawRows.raw0631))

theorem site0628 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((628:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((632:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site0628Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site0632Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 632 f r x y z) (slots650.atReg 635 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 632 3 635 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 632 635 633 f r (row_of_literal 632 _ (by decide) RawRows.raw0632))
    (slots650.pos_x 632 635 633 f r (row_of_literal 632 _ (by decide) RawRows.raw0632))
    (slots650.inc_y 633 634 f r (row_of_literal 633 _ (by decide) RawRows.raw0633) (Or.inl (by decide)))
    (slots650.jump 634 632 f r (row_of_literal 634 _ (by decide) RawRows.raw0634))

theorem site0632 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((632:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((635:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0632Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site0635Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 635 f r x y z) (slots267.atReg 643 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 635 8 643 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 635 643 636 f r (row_of_literal 635 _ (by decide) RawRows.raw0635))
    (slots267.pos_x 635 643 636 f r (row_of_literal 635 _ (by decide) RawRows.raw0635))
    (slots267.inc_z 636 637 f r (row_of_literal 636 _ (by decide) RawRows.raw0636) (Or.inl (by decide)))
    (slots267.zero_y 637 639 638 f r (row_of_literal 637 _ (by decide) RawRows.raw0637))
    (slots267.pos_y 637 639 638 f r (row_of_literal 637 _ (by decide) RawRows.raw0637))
    (slots267.jump 638 642 f r (row_of_literal 638 _ (by decide) RawRows.raw0638))
    (slots267.zero_z 639 642 640 f r (row_of_literal 639 _ (by decide) RawRows.raw0639))
    (slots267.pos_z 639 642 640 f r (row_of_literal 639 _ (by decide) RawRows.raw0639))
    (slots267.inc_y 640 641 f r (row_of_literal 640 _ (by decide) RawRows.raw0640) (Or.inl (by decide)))
    (slots267.jump 641 639 f r (row_of_literal 641 _ (by decide) RawRows.raw0641))
    (slots267.jump 642 635 f r (row_of_literal 642 _ (by decide) RawRows.raw0642))

theorem site0635 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((635:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((643:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0635Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0643Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 643 f r x y z) (slots720.atReg 646 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 643 3 646 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 643 646 644 f r (row_of_literal 643 _ (by decide) RawRows.raw0643))
    (slots720.pos_x 643 646 644 f r (row_of_literal 643 _ (by decide) RawRows.raw0643))
    (slots720.inc_y 644 645 f r (row_of_literal 644 _ (by decide) RawRows.raw0644) (Or.inl (by decide)))
    (slots720.jump 645 643 f r (row_of_literal 645 _ (by decide) RawRows.raw0645))

theorem site0643 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((643:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((646:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0643Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0646Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 646 f r x y z) (slots617.atReg 656 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 646 10 656 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 646 650 647 f r (row_of_literal 646 _ (by decide) RawRows.raw0646))
    (slots617.pos_y 646 650 647 f r (row_of_literal 646 _ (by decide) RawRows.raw0646))
    (slots617.inc_z 647 648 f r (row_of_literal 647 _ (by decide) RawRows.raw0647) (Or.inl (by decide)))
    (slots617.inc_x 648 649 f r (row_of_literal 648 _ (by decide) RawRows.raw0648) (Or.inl (by decide)))
    (slots617.jump 649 646 f r (row_of_literal 649 _ (by decide) RawRows.raw0649))
    (slots617.zero_x 650 656 651 f r (row_of_literal 650 _ (by decide) RawRows.raw0650))
    (slots617.pos_x 650 656 651 f r (row_of_literal 650 _ (by decide) RawRows.raw0650))
    (slots617.inc_z 651 652 f r (row_of_literal 651 _ (by decide) RawRows.raw0651) (Or.inl (by decide)))
    (slots617.zero_x 652 655 653 f r (row_of_literal 652 _ (by decide) RawRows.raw0652))
    (slots617.pos_x 652 655 653 f r (row_of_literal 652 _ (by decide) RawRows.raw0652))
    (slots617.inc_y 653 654 f r (row_of_literal 653 _ (by decide) RawRows.raw0653) (Or.inl (by decide)))
    (slots617.jump 654 652 f r (row_of_literal 654 _ (by decide) RawRows.raw0654))
    (slots617.jump 655 646 f r (row_of_literal 655 _ (by decide) RawRows.raw0655))

theorem site0646 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((646:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((656:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0646Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0656Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 656 f r x y z) (slots710.atReg 660 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 656 4 660 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 656 660 657 f r (row_of_literal 656 _ (by decide) RawRows.raw0656))
    (slots710.pos_x 656 660 657 f r (row_of_literal 656 _ (by decide) RawRows.raw0656))
    (slots710.inc_y 657 658 f r (row_of_literal 657 _ (by decide) RawRows.raw0657) (Or.inl (by decide)))
    (slots710.inc_y 658 659 f r (row_of_literal 658 _ (by decide) RawRows.raw0658) (Or.inl (by decide)))
    (slots710.jump 659 656 f r (row_of_literal 659 _ (by decide) RawRows.raw0659))

theorem site0656 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((656:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((660:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0656Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site0660 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((660:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((661:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 660 _ (row_of_literal 660 _ (by decide) RawRows.raw0660)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site0661Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 661 f r x y z) (slots160.atReg 664 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 661 3 664 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 661 664 662 f r (row_of_literal 661 _ (by decide) RawRows.raw0661))
    (slots160.pos_x 661 664 662 f r (row_of_literal 661 _ (by decide) RawRows.raw0661))
    (slots160.inc_y 662 663 f r (row_of_literal 662 _ (by decide) RawRows.raw0662) (Or.inl (by decide)))
    (slots160.jump 663 661 f r (row_of_literal 663 _ (by decide) RawRows.raw0663))

theorem site0661 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((661:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((664:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0661Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0664Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 664 f r x y z) (slots210.atReg 667 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 664 3 667 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 664 667 665 f r (row_of_literal 664 _ (by decide) RawRows.raw0664))
    (slots210.pos_x 664 667 665 f r (row_of_literal 664 _ (by decide) RawRows.raw0664))
    (slots210.inc_y 665 666 f r (row_of_literal 665 _ (by decide) RawRows.raw0665) (Or.inl (by decide)))
    (slots210.jump 666 664 f r (row_of_literal 666 _ (by decide) RawRows.raw0666))

theorem site0664 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((664:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((667:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0664Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0667Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 667 f r x y z) (slots617.atReg 677 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 667 10 677 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 667 671 668 f r (row_of_literal 667 _ (by decide) RawRows.raw0667))
    (slots617.pos_y 667 671 668 f r (row_of_literal 667 _ (by decide) RawRows.raw0667))
    (slots617.inc_z 668 669 f r (row_of_literal 668 _ (by decide) RawRows.raw0668) (Or.inl (by decide)))
    (slots617.inc_x 669 670 f r (row_of_literal 669 _ (by decide) RawRows.raw0669) (Or.inl (by decide)))
    (slots617.jump 670 667 f r (row_of_literal 670 _ (by decide) RawRows.raw0670))
    (slots617.zero_x 671 677 672 f r (row_of_literal 671 _ (by decide) RawRows.raw0671))
    (slots617.pos_x 671 677 672 f r (row_of_literal 671 _ (by decide) RawRows.raw0671))
    (slots617.inc_z 672 673 f r (row_of_literal 672 _ (by decide) RawRows.raw0672) (Or.inl (by decide)))
    (slots617.zero_x 673 676 674 f r (row_of_literal 673 _ (by decide) RawRows.raw0673))
    (slots617.pos_x 673 676 674 f r (row_of_literal 673 _ (by decide) RawRows.raw0673))
    (slots617.inc_y 674 675 f r (row_of_literal 674 _ (by decide) RawRows.raw0674) (Or.inl (by decide)))
    (slots617.jump 675 673 f r (row_of_literal 675 _ (by decide) RawRows.raw0675))
    (slots617.jump 676 667 f r (row_of_literal 676 _ (by decide) RawRows.raw0676))

theorem site0667 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((667:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((677:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0667Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0677Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 677 f r x y z) (slots720.atReg 680 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 677 3 680 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 677 680 678 f r (row_of_literal 677 _ (by decide) RawRows.raw0677))
    (slots720.pos_x 677 680 678 f r (row_of_literal 677 _ (by decide) RawRows.raw0677))
    (slots720.inc_y 678 679 f r (row_of_literal 678 _ (by decide) RawRows.raw0678) (Or.inl (by decide)))
    (slots720.jump 679 677 f r (row_of_literal 679 _ (by decide) RawRows.raw0679))

theorem site0677 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((677:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((680:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0677Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0680Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 680 f r x y z) (slots461.atReg 684 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 680 4 684 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 680 684 681 f r (row_of_literal 680 _ (by decide) RawRows.raw0680))
    (slots461.pos_x 680 684 681 f r (row_of_literal 680 _ (by decide) RawRows.raw0680))
    (slots461.inc_y 681 682 f r (row_of_literal 681 _ (by decide) RawRows.raw0681) (Or.inl (by decide)))
    (slots461.inc_z 682 683 f r (row_of_literal 682 _ (by decide) RawRows.raw0682) (Or.inl (by decide)))
    (slots461.jump 683 680 f r (row_of_literal 683 _ (by decide) RawRows.raw0683))

theorem site0680 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((680:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((684:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0680Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site0684Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 684 f r x y z) (slots640.atReg 687 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 684 3 687 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 684 687 685 f r (row_of_literal 684 _ (by decide) RawRows.raw0684))
    (slots640.pos_x 684 687 685 f r (row_of_literal 684 _ (by decide) RawRows.raw0684))
    (slots640.inc_y 685 686 f r (row_of_literal 685 _ (by decide) RawRows.raw0685) (Or.inl (by decide)))
    (slots640.jump 686 684 f r (row_of_literal 686 _ (by decide) RawRows.raw0686))

theorem site0684 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((684:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((687:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0684Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site0687Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 687 f r x y z) (slots160.atReg 690 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 687 3 690 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 687 690 688 f r (row_of_literal 687 _ (by decide) RawRows.raw0687))
    (slots160.pos_x 687 690 688 f r (row_of_literal 687 _ (by decide) RawRows.raw0687))
    (slots160.inc_y 688 689 f r (row_of_literal 688 _ (by decide) RawRows.raw0688) (Or.inl (by decide)))
    (slots160.jump 689 687 f r (row_of_literal 689 _ (by decide) RawRows.raw0689))

theorem site0687 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((687:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((690:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0687Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0690Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 690 f r x y z) (slots210.atReg 693 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 690 3 693 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 690 693 691 f r (row_of_literal 690 _ (by decide) RawRows.raw0690))
    (slots210.pos_x 690 693 691 f r (row_of_literal 690 _ (by decide) RawRows.raw0690))
    (slots210.inc_y 691 692 f r (row_of_literal 691 _ (by decide) RawRows.raw0691) (Or.inl (by decide)))
    (slots210.jump 692 690 f r (row_of_literal 692 _ (by decide) RawRows.raw0692))

theorem site0690 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((690:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((693:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0690Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0693Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 693 f r x y z) (slots617.atReg 703 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 693 10 703 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 693 697 694 f r (row_of_literal 693 _ (by decide) RawRows.raw0693))
    (slots617.pos_y 693 697 694 f r (row_of_literal 693 _ (by decide) RawRows.raw0693))
    (slots617.inc_z 694 695 f r (row_of_literal 694 _ (by decide) RawRows.raw0694) (Or.inl (by decide)))
    (slots617.inc_x 695 696 f r (row_of_literal 695 _ (by decide) RawRows.raw0695) (Or.inl (by decide)))
    (slots617.jump 696 693 f r (row_of_literal 696 _ (by decide) RawRows.raw0696))
    (slots617.zero_x 697 703 698 f r (row_of_literal 697 _ (by decide) RawRows.raw0697))
    (slots617.pos_x 697 703 698 f r (row_of_literal 697 _ (by decide) RawRows.raw0697))
    (slots617.inc_z 698 699 f r (row_of_literal 698 _ (by decide) RawRows.raw0698) (Or.inl (by decide)))
    (slots617.zero_x 699 702 700 f r (row_of_literal 699 _ (by decide) RawRows.raw0699))
    (slots617.pos_x 699 702 700 f r (row_of_literal 699 _ (by decide) RawRows.raw0699))
    (slots617.inc_y 700 701 f r (row_of_literal 700 _ (by decide) RawRows.raw0700) (Or.inl (by decide)))
    (slots617.jump 701 699 f r (row_of_literal 701 _ (by decide) RawRows.raw0701))
    (slots617.jump 702 693 f r (row_of_literal 702 _ (by decide) RawRows.raw0702))

theorem site0693 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((693:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((703:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0693Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0703Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 703 f r x y z) (slots720.atReg 706 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 703 3 706 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 703 706 704 f r (row_of_literal 703 _ (by decide) RawRows.raw0703))
    (slots720.pos_x 703 706 704 f r (row_of_literal 703 _ (by decide) RawRows.raw0703))
    (slots720.inc_y 704 705 f r (row_of_literal 704 _ (by decide) RawRows.raw0704) (Or.inl (by decide)))
    (slots720.jump 705 703 f r (row_of_literal 705 _ (by decide) RawRows.raw0705))

theorem site0703 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((703:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((706:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0703Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0706Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 706 f r x y z) (slots361.atReg 710 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 706 4 710 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 706 710 707 f r (row_of_literal 706 _ (by decide) RawRows.raw0706))
    (slots361.pos_x 706 710 707 f r (row_of_literal 706 _ (by decide) RawRows.raw0706))
    (slots361.inc_y 707 708 f r (row_of_literal 707 _ (by decide) RawRows.raw0707) (Or.inl (by decide)))
    (slots361.inc_z 708 709 f r (row_of_literal 708 _ (by decide) RawRows.raw0708) (Or.inl (by decide)))
    (slots361.jump 709 706 f r (row_of_literal 709 _ (by decide) RawRows.raw0709))

theorem site0706 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((706:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((710:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0706Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site0710Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 710 f r x y z) (slots630.atReg 713 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 710 3 713 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 710 713 711 f r (row_of_literal 710 _ (by decide) RawRows.raw0710))
    (slots630.pos_x 710 713 711 f r (row_of_literal 710 _ (by decide) RawRows.raw0710))
    (slots630.inc_y 711 712 f r (row_of_literal 711 _ (by decide) RawRows.raw0711) (Or.inl (by decide)))
    (slots630.jump 712 710 f r (row_of_literal 712 _ (by decide) RawRows.raw0712))

theorem site0710 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((710:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((713:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0710Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site0713Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 713 f r x y z) (slots267.atReg 721 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 713 8 721 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 713 721 714 f r (row_of_literal 713 _ (by decide) RawRows.raw0713))
    (slots267.pos_x 713 721 714 f r (row_of_literal 713 _ (by decide) RawRows.raw0713))
    (slots267.inc_z 714 715 f r (row_of_literal 714 _ (by decide) RawRows.raw0714) (Or.inl (by decide)))
    (slots267.zero_y 715 717 716 f r (row_of_literal 715 _ (by decide) RawRows.raw0715))
    (slots267.pos_y 715 717 716 f r (row_of_literal 715 _ (by decide) RawRows.raw0715))
    (slots267.jump 716 720 f r (row_of_literal 716 _ (by decide) RawRows.raw0716))
    (slots267.zero_z 717 720 718 f r (row_of_literal 717 _ (by decide) RawRows.raw0717))
    (slots267.pos_z 717 720 718 f r (row_of_literal 717 _ (by decide) RawRows.raw0717))
    (slots267.inc_y 718 719 f r (row_of_literal 718 _ (by decide) RawRows.raw0718) (Or.inl (by decide)))
    (slots267.jump 719 717 f r (row_of_literal 719 _ (by decide) RawRows.raw0719))
    (slots267.jump 720 713 f r (row_of_literal 720 _ (by decide) RawRows.raw0720))

theorem site0713 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((713:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((721:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0713Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0721Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 721 f r x y z) (slots720.atReg 724 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 721 3 724 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 721 724 722 f r (row_of_literal 721 _ (by decide) RawRows.raw0721))
    (slots720.pos_x 721 724 722 f r (row_of_literal 721 _ (by decide) RawRows.raw0721))
    (slots720.inc_y 722 723 f r (row_of_literal 722 _ (by decide) RawRows.raw0722) (Or.inl (by decide)))
    (slots720.jump 723 721 f r (row_of_literal 723 _ (by decide) RawRows.raw0723))

theorem site0721 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((721:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((724:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0721Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0724Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 724 f r x y z) (slots617.atReg 734 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 724 10 734 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 724 728 725 f r (row_of_literal 724 _ (by decide) RawRows.raw0724))
    (slots617.pos_y 724 728 725 f r (row_of_literal 724 _ (by decide) RawRows.raw0724))
    (slots617.inc_z 725 726 f r (row_of_literal 725 _ (by decide) RawRows.raw0725) (Or.inl (by decide)))
    (slots617.inc_x 726 727 f r (row_of_literal 726 _ (by decide) RawRows.raw0726) (Or.inl (by decide)))
    (slots617.jump 727 724 f r (row_of_literal 727 _ (by decide) RawRows.raw0727))
    (slots617.zero_x 728 734 729 f r (row_of_literal 728 _ (by decide) RawRows.raw0728))
    (slots617.pos_x 728 734 729 f r (row_of_literal 728 _ (by decide) RawRows.raw0728))
    (slots617.inc_z 729 730 f r (row_of_literal 729 _ (by decide) RawRows.raw0729) (Or.inl (by decide)))
    (slots617.zero_x 730 733 731 f r (row_of_literal 730 _ (by decide) RawRows.raw0730))
    (slots617.pos_x 730 733 731 f r (row_of_literal 730 _ (by decide) RawRows.raw0730))
    (slots617.inc_y 731 732 f r (row_of_literal 731 _ (by decide) RawRows.raw0731) (Or.inl (by decide)))
    (slots617.jump 732 730 f r (row_of_literal 732 _ (by decide) RawRows.raw0732))
    (slots617.jump 733 724 f r (row_of_literal 733 _ (by decide) RawRows.raw0733))

theorem site0724 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((724:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((734:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0724Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0734Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 734 f r x y z) (slots710.atReg 738 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 734 4 738 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 734 738 735 f r (row_of_literal 734 _ (by decide) RawRows.raw0734))
    (slots710.pos_x 734 738 735 f r (row_of_literal 734 _ (by decide) RawRows.raw0734))
    (slots710.inc_y 735 736 f r (row_of_literal 735 _ (by decide) RawRows.raw0735) (Or.inl (by decide)))
    (slots710.inc_y 736 737 f r (row_of_literal 736 _ (by decide) RawRows.raw0736) (Or.inl (by decide)))
    (slots710.jump 737 734 f r (row_of_literal 737 _ (by decide) RawRows.raw0737))

theorem site0734 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((734:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((738:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0734Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


end PA192.ModelSearch.Register181.Certified
