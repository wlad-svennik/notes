module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site1483Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1483 f r x y z) (slots640.atReg 1486 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1483 3 1486 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1483 1486 1484 f r (row_of_literal 1483 _ (by decide) RawRows.raw1483))
    (slots640.pos_x 1483 1486 1484 f r (row_of_literal 1483 _ (by decide) RawRows.raw1483))
    (slots640.inc_y 1484 1485 f r (row_of_literal 1484 _ (by decide) RawRows.raw1484) (Or.inl (by decide)))
    (slots640.jump 1485 1483 f r (row_of_literal 1485 _ (by decide) RawRows.raw1485))

theorem site1483 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1483:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1486:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1483Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site1486Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1486 f r x y z) (slots160.atReg 1489 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1486 3 1489 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1486 1489 1487 f r (row_of_literal 1486 _ (by decide) RawRows.raw1486))
    (slots160.pos_x 1486 1489 1487 f r (row_of_literal 1486 _ (by decide) RawRows.raw1486))
    (slots160.inc_y 1487 1488 f r (row_of_literal 1487 _ (by decide) RawRows.raw1487) (Or.inl (by decide)))
    (slots160.jump 1488 1486 f r (row_of_literal 1488 _ (by decide) RawRows.raw1488))

theorem site1486 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1486:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1489:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1486Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1489Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1489 f r x y z) (slots210.atReg 1492 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1489 3 1492 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1489 1492 1490 f r (row_of_literal 1489 _ (by decide) RawRows.raw1489))
    (slots210.pos_x 1489 1492 1490 f r (row_of_literal 1489 _ (by decide) RawRows.raw1489))
    (slots210.inc_y 1490 1491 f r (row_of_literal 1490 _ (by decide) RawRows.raw1490) (Or.inl (by decide)))
    (slots210.jump 1491 1489 f r (row_of_literal 1491 _ (by decide) RawRows.raw1491))

theorem site1489 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1489:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1492:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1489Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1492Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1492 f r x y z) (slots617.atReg 1502 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1492 10 1502 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1492 1496 1493 f r (row_of_literal 1492 _ (by decide) RawRows.raw1492))
    (slots617.pos_y 1492 1496 1493 f r (row_of_literal 1492 _ (by decide) RawRows.raw1492))
    (slots617.inc_z 1493 1494 f r (row_of_literal 1493 _ (by decide) RawRows.raw1493) (Or.inl (by decide)))
    (slots617.inc_x 1494 1495 f r (row_of_literal 1494 _ (by decide) RawRows.raw1494) (Or.inl (by decide)))
    (slots617.jump 1495 1492 f r (row_of_literal 1495 _ (by decide) RawRows.raw1495))
    (slots617.zero_x 1496 1502 1497 f r (row_of_literal 1496 _ (by decide) RawRows.raw1496))
    (slots617.pos_x 1496 1502 1497 f r (row_of_literal 1496 _ (by decide) RawRows.raw1496))
    (slots617.inc_z 1497 1498 f r (row_of_literal 1497 _ (by decide) RawRows.raw1497) (Or.inl (by decide)))
    (slots617.zero_x 1498 1501 1499 f r (row_of_literal 1498 _ (by decide) RawRows.raw1498))
    (slots617.pos_x 1498 1501 1499 f r (row_of_literal 1498 _ (by decide) RawRows.raw1498))
    (slots617.inc_y 1499 1500 f r (row_of_literal 1499 _ (by decide) RawRows.raw1499) (Or.inl (by decide)))
    (slots617.jump 1500 1498 f r (row_of_literal 1500 _ (by decide) RawRows.raw1500))
    (slots617.jump 1501 1492 f r (row_of_literal 1501 _ (by decide) RawRows.raw1501))

theorem site1492 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1492:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1502:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1492Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1502Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1502 f r x y z) (slots720.atReg 1505 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1502 3 1505 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1502 1505 1503 f r (row_of_literal 1502 _ (by decide) RawRows.raw1502))
    (slots720.pos_x 1502 1505 1503 f r (row_of_literal 1502 _ (by decide) RawRows.raw1502))
    (slots720.inc_y 1503 1504 f r (row_of_literal 1503 _ (by decide) RawRows.raw1503) (Or.inl (by decide)))
    (slots720.jump 1504 1502 f r (row_of_literal 1504 _ (by decide) RawRows.raw1504))

theorem site1502 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1502:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1505:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1502Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1505Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1505 f r x y z) (slots561.atReg 1509 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1505 4 1509 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1505 1509 1506 f r (row_of_literal 1505 _ (by decide) RawRows.raw1505))
    (slots561.pos_x 1505 1509 1506 f r (row_of_literal 1505 _ (by decide) RawRows.raw1505))
    (slots561.inc_y 1506 1507 f r (row_of_literal 1506 _ (by decide) RawRows.raw1506) (Or.inl (by decide)))
    (slots561.inc_z 1507 1508 f r (row_of_literal 1507 _ (by decide) RawRows.raw1507) (Or.inl (by decide)))
    (slots561.jump 1508 1505 f r (row_of_literal 1508 _ (by decide) RawRows.raw1508))

theorem site1505 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1505:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1509:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1505Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1509Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1509 f r x y z) (slots650.atReg 1512 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1509 3 1512 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1509 1512 1510 f r (row_of_literal 1509 _ (by decide) RawRows.raw1509))
    (slots650.pos_x 1509 1512 1510 f r (row_of_literal 1509 _ (by decide) RawRows.raw1509))
    (slots650.inc_y 1510 1511 f r (row_of_literal 1510 _ (by decide) RawRows.raw1510) (Or.inl (by decide)))
    (slots650.jump 1511 1509 f r (row_of_literal 1511 _ (by decide) RawRows.raw1511))

theorem site1509 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1509:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1512:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1509Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1512Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1512 f r x y z) (slots267.atReg 1520 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1512 8 1520 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1512 1520 1513 f r (row_of_literal 1512 _ (by decide) RawRows.raw1512))
    (slots267.pos_x 1512 1520 1513 f r (row_of_literal 1512 _ (by decide) RawRows.raw1512))
    (slots267.inc_z 1513 1514 f r (row_of_literal 1513 _ (by decide) RawRows.raw1513) (Or.inl (by decide)))
    (slots267.zero_y 1514 1516 1515 f r (row_of_literal 1514 _ (by decide) RawRows.raw1514))
    (slots267.pos_y 1514 1516 1515 f r (row_of_literal 1514 _ (by decide) RawRows.raw1514))
    (slots267.jump 1515 1519 f r (row_of_literal 1515 _ (by decide) RawRows.raw1515))
    (slots267.zero_z 1516 1519 1517 f r (row_of_literal 1516 _ (by decide) RawRows.raw1516))
    (slots267.pos_z 1516 1519 1517 f r (row_of_literal 1516 _ (by decide) RawRows.raw1516))
    (slots267.inc_y 1517 1518 f r (row_of_literal 1517 _ (by decide) RawRows.raw1517) (Or.inl (by decide)))
    (slots267.jump 1518 1516 f r (row_of_literal 1518 _ (by decide) RawRows.raw1518))
    (slots267.jump 1519 1512 f r (row_of_literal 1519 _ (by decide) RawRows.raw1519))

theorem site1512 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1512:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1520:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1512Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1520Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1520 f r x y z) (slots720.atReg 1523 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1520 3 1523 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1520 1523 1521 f r (row_of_literal 1520 _ (by decide) RawRows.raw1520))
    (slots720.pos_x 1520 1523 1521 f r (row_of_literal 1520 _ (by decide) RawRows.raw1520))
    (slots720.inc_y 1521 1522 f r (row_of_literal 1521 _ (by decide) RawRows.raw1521) (Or.inl (by decide)))
    (slots720.jump 1522 1520 f r (row_of_literal 1522 _ (by decide) RawRows.raw1522))

theorem site1520 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1520:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1523:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1520Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1523Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1523 f r x y z) (slots617.atReg 1533 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1523 10 1533 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1523 1527 1524 f r (row_of_literal 1523 _ (by decide) RawRows.raw1523))
    (slots617.pos_y 1523 1527 1524 f r (row_of_literal 1523 _ (by decide) RawRows.raw1523))
    (slots617.inc_z 1524 1525 f r (row_of_literal 1524 _ (by decide) RawRows.raw1524) (Or.inl (by decide)))
    (slots617.inc_x 1525 1526 f r (row_of_literal 1525 _ (by decide) RawRows.raw1525) (Or.inl (by decide)))
    (slots617.jump 1526 1523 f r (row_of_literal 1526 _ (by decide) RawRows.raw1526))
    (slots617.zero_x 1527 1533 1528 f r (row_of_literal 1527 _ (by decide) RawRows.raw1527))
    (slots617.pos_x 1527 1533 1528 f r (row_of_literal 1527 _ (by decide) RawRows.raw1527))
    (slots617.inc_z 1528 1529 f r (row_of_literal 1528 _ (by decide) RawRows.raw1528) (Or.inl (by decide)))
    (slots617.zero_x 1529 1532 1530 f r (row_of_literal 1529 _ (by decide) RawRows.raw1529))
    (slots617.pos_x 1529 1532 1530 f r (row_of_literal 1529 _ (by decide) RawRows.raw1529))
    (slots617.inc_y 1530 1531 f r (row_of_literal 1530 _ (by decide) RawRows.raw1530) (Or.inl (by decide)))
    (slots617.jump 1531 1529 f r (row_of_literal 1531 _ (by decide) RawRows.raw1531))
    (slots617.jump 1532 1523 f r (row_of_literal 1532 _ (by decide) RawRows.raw1532))

theorem site1523 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1523:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1533:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1523Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1533Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1533 f r x y z) (slots710.atReg 1537 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1533 4 1537 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1533 1537 1534 f r (row_of_literal 1533 _ (by decide) RawRows.raw1533))
    (slots710.pos_x 1533 1537 1534 f r (row_of_literal 1533 _ (by decide) RawRows.raw1533))
    (slots710.inc_y 1534 1535 f r (row_of_literal 1534 _ (by decide) RawRows.raw1534) (Or.inl (by decide)))
    (slots710.inc_y 1535 1536 f r (row_of_literal 1535 _ (by decide) RawRows.raw1535) (Or.inl (by decide)))
    (slots710.jump 1536 1533 f r (row_of_literal 1536 _ (by decide) RawRows.raw1536))

theorem site1533 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1533:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1537:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1533Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1537 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1537:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1538:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1537 _ (row_of_literal 1537 _ (by decide) RawRows.raw1537)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1538Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1538 f r x y z) (slots267.atReg 1546 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1538 8 1546 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1538 1546 1539 f r (row_of_literal 1538 _ (by decide) RawRows.raw1538))
    (slots267.pos_x 1538 1546 1539 f r (row_of_literal 1538 _ (by decide) RawRows.raw1538))
    (slots267.inc_z 1539 1540 f r (row_of_literal 1539 _ (by decide) RawRows.raw1539) (Or.inl (by decide)))
    (slots267.zero_y 1540 1542 1541 f r (row_of_literal 1540 _ (by decide) RawRows.raw1540))
    (slots267.pos_y 1540 1542 1541 f r (row_of_literal 1540 _ (by decide) RawRows.raw1540))
    (slots267.jump 1541 1545 f r (row_of_literal 1541 _ (by decide) RawRows.raw1541))
    (slots267.zero_z 1542 1545 1543 f r (row_of_literal 1542 _ (by decide) RawRows.raw1542))
    (slots267.pos_z 1542 1545 1543 f r (row_of_literal 1542 _ (by decide) RawRows.raw1542))
    (slots267.inc_y 1543 1544 f r (row_of_literal 1543 _ (by decide) RawRows.raw1543) (Or.inl (by decide)))
    (slots267.jump 1544 1542 f r (row_of_literal 1544 _ (by decide) RawRows.raw1544))
    (slots267.jump 1545 1538 f r (row_of_literal 1545 _ (by decide) RawRows.raw1545))

theorem site1538 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1538:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1546:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1538Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1546Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1546 f r x y z) (slots720.atReg 1549 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1546 3 1549 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1546 1549 1547 f r (row_of_literal 1546 _ (by decide) RawRows.raw1546))
    (slots720.pos_x 1546 1549 1547 f r (row_of_literal 1546 _ (by decide) RawRows.raw1546))
    (slots720.inc_y 1547 1548 f r (row_of_literal 1547 _ (by decide) RawRows.raw1547) (Or.inl (by decide)))
    (slots720.jump 1548 1546 f r (row_of_literal 1548 _ (by decide) RawRows.raw1548))

theorem site1546 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1546:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1549:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1546Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1549Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1549 f r x y z) (slots617.atReg 1559 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1549 10 1559 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1549 1553 1550 f r (row_of_literal 1549 _ (by decide) RawRows.raw1549))
    (slots617.pos_y 1549 1553 1550 f r (row_of_literal 1549 _ (by decide) RawRows.raw1549))
    (slots617.inc_z 1550 1551 f r (row_of_literal 1550 _ (by decide) RawRows.raw1550) (Or.inl (by decide)))
    (slots617.inc_x 1551 1552 f r (row_of_literal 1551 _ (by decide) RawRows.raw1551) (Or.inl (by decide)))
    (slots617.jump 1552 1549 f r (row_of_literal 1552 _ (by decide) RawRows.raw1552))
    (slots617.zero_x 1553 1559 1554 f r (row_of_literal 1553 _ (by decide) RawRows.raw1553))
    (slots617.pos_x 1553 1559 1554 f r (row_of_literal 1553 _ (by decide) RawRows.raw1553))
    (slots617.inc_z 1554 1555 f r (row_of_literal 1554 _ (by decide) RawRows.raw1554) (Or.inl (by decide)))
    (slots617.zero_x 1555 1558 1556 f r (row_of_literal 1555 _ (by decide) RawRows.raw1555))
    (slots617.pos_x 1555 1558 1556 f r (row_of_literal 1555 _ (by decide) RawRows.raw1555))
    (slots617.inc_y 1556 1557 f r (row_of_literal 1556 _ (by decide) RawRows.raw1556) (Or.inl (by decide)))
    (slots617.jump 1557 1555 f r (row_of_literal 1557 _ (by decide) RawRows.raw1557))
    (slots617.jump 1558 1549 f r (row_of_literal 1558 _ (by decide) RawRows.raw1558))

theorem site1549 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1549:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1559:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1549Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1559Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1559 f r x y z) (slots710.atReg 1563 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1559 4 1563 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1559 1563 1560 f r (row_of_literal 1559 _ (by decide) RawRows.raw1559))
    (slots710.pos_x 1559 1563 1560 f r (row_of_literal 1559 _ (by decide) RawRows.raw1559))
    (slots710.inc_y 1560 1561 f r (row_of_literal 1560 _ (by decide) RawRows.raw1560) (Or.inl (by decide)))
    (slots710.inc_y 1561 1562 f r (row_of_literal 1561 _ (by decide) RawRows.raw1561) (Or.inl (by decide)))
    (slots710.jump 1562 1559 f r (row_of_literal 1562 _ (by decide) RawRows.raw1562))

theorem site1559 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1559:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1563:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1559Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1563 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1563:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1564:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1563 _ (row_of_literal 1563 _ (by decide) RawRows.raw1563)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1564Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1564 f r x y z) (slots267.atReg 1572 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1564 8 1572 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1564 1572 1565 f r (row_of_literal 1564 _ (by decide) RawRows.raw1564))
    (slots267.pos_x 1564 1572 1565 f r (row_of_literal 1564 _ (by decide) RawRows.raw1564))
    (slots267.inc_z 1565 1566 f r (row_of_literal 1565 _ (by decide) RawRows.raw1565) (Or.inl (by decide)))
    (slots267.zero_y 1566 1568 1567 f r (row_of_literal 1566 _ (by decide) RawRows.raw1566))
    (slots267.pos_y 1566 1568 1567 f r (row_of_literal 1566 _ (by decide) RawRows.raw1566))
    (slots267.jump 1567 1571 f r (row_of_literal 1567 _ (by decide) RawRows.raw1567))
    (slots267.zero_z 1568 1571 1569 f r (row_of_literal 1568 _ (by decide) RawRows.raw1568))
    (slots267.pos_z 1568 1571 1569 f r (row_of_literal 1568 _ (by decide) RawRows.raw1568))
    (slots267.inc_y 1569 1570 f r (row_of_literal 1569 _ (by decide) RawRows.raw1569) (Or.inl (by decide)))
    (slots267.jump 1570 1568 f r (row_of_literal 1570 _ (by decide) RawRows.raw1570))
    (slots267.jump 1571 1564 f r (row_of_literal 1571 _ (by decide) RawRows.raw1571))

theorem site1564 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1564:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1572:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1564Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1572Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1572 f r x y z) (slots720.atReg 1575 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1572 3 1575 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1572 1575 1573 f r (row_of_literal 1572 _ (by decide) RawRows.raw1572))
    (slots720.pos_x 1572 1575 1573 f r (row_of_literal 1572 _ (by decide) RawRows.raw1572))
    (slots720.inc_y 1573 1574 f r (row_of_literal 1573 _ (by decide) RawRows.raw1573) (Or.inl (by decide)))
    (slots720.jump 1574 1572 f r (row_of_literal 1574 _ (by decide) RawRows.raw1574))

theorem site1572 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1572:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1575:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1572Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1575Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1575 f r x y z) (slots617.atReg 1585 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1575 10 1585 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1575 1579 1576 f r (row_of_literal 1575 _ (by decide) RawRows.raw1575))
    (slots617.pos_y 1575 1579 1576 f r (row_of_literal 1575 _ (by decide) RawRows.raw1575))
    (slots617.inc_z 1576 1577 f r (row_of_literal 1576 _ (by decide) RawRows.raw1576) (Or.inl (by decide)))
    (slots617.inc_x 1577 1578 f r (row_of_literal 1577 _ (by decide) RawRows.raw1577) (Or.inl (by decide)))
    (slots617.jump 1578 1575 f r (row_of_literal 1578 _ (by decide) RawRows.raw1578))
    (slots617.zero_x 1579 1585 1580 f r (row_of_literal 1579 _ (by decide) RawRows.raw1579))
    (slots617.pos_x 1579 1585 1580 f r (row_of_literal 1579 _ (by decide) RawRows.raw1579))
    (slots617.inc_z 1580 1581 f r (row_of_literal 1580 _ (by decide) RawRows.raw1580) (Or.inl (by decide)))
    (slots617.zero_x 1581 1584 1582 f r (row_of_literal 1581 _ (by decide) RawRows.raw1581))
    (slots617.pos_x 1581 1584 1582 f r (row_of_literal 1581 _ (by decide) RawRows.raw1581))
    (slots617.inc_y 1582 1583 f r (row_of_literal 1582 _ (by decide) RawRows.raw1582) (Or.inl (by decide)))
    (slots617.jump 1583 1581 f r (row_of_literal 1583 _ (by decide) RawRows.raw1583))
    (slots617.jump 1584 1575 f r (row_of_literal 1584 _ (by decide) RawRows.raw1584))

theorem site1575 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1575:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1585:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1575Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1585Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1585 f r x y z) (slots710.atReg 1589 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1585 4 1589 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1585 1589 1586 f r (row_of_literal 1585 _ (by decide) RawRows.raw1585))
    (slots710.pos_x 1585 1589 1586 f r (row_of_literal 1585 _ (by decide) RawRows.raw1585))
    (slots710.inc_y 1586 1587 f r (row_of_literal 1586 _ (by decide) RawRows.raw1586) (Or.inl (by decide)))
    (slots710.inc_y 1587 1588 f r (row_of_literal 1587 _ (by decide) RawRows.raw1587) (Or.inl (by decide)))
    (slots710.jump 1588 1585 f r (row_of_literal 1588 _ (by decide) RawRows.raw1588))

theorem site1585 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1585:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1589:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1585Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site1589Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1589 f r x y z) (slots160.atReg 1592 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1589 3 1592 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1589 1592 1590 f r (row_of_literal 1589 _ (by decide) RawRows.raw1589))
    (slots160.pos_x 1589 1592 1590 f r (row_of_literal 1589 _ (by decide) RawRows.raw1589))
    (slots160.inc_y 1590 1591 f r (row_of_literal 1590 _ (by decide) RawRows.raw1590) (Or.inl (by decide)))
    (slots160.jump 1591 1589 f r (row_of_literal 1591 _ (by decide) RawRows.raw1591))

theorem site1589 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1589:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1592:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1589Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1592Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1592 f r x y z) (slots210.atReg 1595 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1592 3 1595 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1592 1595 1593 f r (row_of_literal 1592 _ (by decide) RawRows.raw1592))
    (slots210.pos_x 1592 1595 1593 f r (row_of_literal 1592 _ (by decide) RawRows.raw1592))
    (slots210.inc_y 1593 1594 f r (row_of_literal 1593 _ (by decide) RawRows.raw1593) (Or.inl (by decide)))
    (slots210.jump 1594 1592 f r (row_of_literal 1594 _ (by decide) RawRows.raw1594))

theorem site1592 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1592:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1595:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1592Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1595Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1595 f r x y z) (slots617.atReg 1605 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1595 10 1605 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1595 1599 1596 f r (row_of_literal 1595 _ (by decide) RawRows.raw1595))
    (slots617.pos_y 1595 1599 1596 f r (row_of_literal 1595 _ (by decide) RawRows.raw1595))
    (slots617.inc_z 1596 1597 f r (row_of_literal 1596 _ (by decide) RawRows.raw1596) (Or.inl (by decide)))
    (slots617.inc_x 1597 1598 f r (row_of_literal 1597 _ (by decide) RawRows.raw1597) (Or.inl (by decide)))
    (slots617.jump 1598 1595 f r (row_of_literal 1598 _ (by decide) RawRows.raw1598))
    (slots617.zero_x 1599 1605 1600 f r (row_of_literal 1599 _ (by decide) RawRows.raw1599))
    (slots617.pos_x 1599 1605 1600 f r (row_of_literal 1599 _ (by decide) RawRows.raw1599))
    (slots617.inc_z 1600 1601 f r (row_of_literal 1600 _ (by decide) RawRows.raw1600) (Or.inl (by decide)))
    (slots617.zero_x 1601 1604 1602 f r (row_of_literal 1601 _ (by decide) RawRows.raw1601))
    (slots617.pos_x 1601 1604 1602 f r (row_of_literal 1601 _ (by decide) RawRows.raw1601))
    (slots617.inc_y 1602 1603 f r (row_of_literal 1602 _ (by decide) RawRows.raw1602) (Or.inl (by decide)))
    (slots617.jump 1603 1601 f r (row_of_literal 1603 _ (by decide) RawRows.raw1603))
    (slots617.jump 1604 1595 f r (row_of_literal 1604 _ (by decide) RawRows.raw1604))

theorem site1595 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1595:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1605:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1595Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1605Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1605 f r x y z) (slots720.atReg 1608 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1605 3 1608 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1605 1608 1606 f r (row_of_literal 1605 _ (by decide) RawRows.raw1605))
    (slots720.pos_x 1605 1608 1606 f r (row_of_literal 1605 _ (by decide) RawRows.raw1605))
    (slots720.inc_y 1606 1607 f r (row_of_literal 1606 _ (by decide) RawRows.raw1606) (Or.inl (by decide)))
    (slots720.jump 1607 1605 f r (row_of_literal 1607 _ (by decide) RawRows.raw1607))

theorem site1605 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1605:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1608:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1605Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1608Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1608 f r x y z) (slots461.atReg 1612 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1608 4 1612 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1608 1612 1609 f r (row_of_literal 1608 _ (by decide) RawRows.raw1608))
    (slots461.pos_x 1608 1612 1609 f r (row_of_literal 1608 _ (by decide) RawRows.raw1608))
    (slots461.inc_y 1609 1610 f r (row_of_literal 1609 _ (by decide) RawRows.raw1609) (Or.inl (by decide)))
    (slots461.inc_z 1610 1611 f r (row_of_literal 1610 _ (by decide) RawRows.raw1610) (Or.inl (by decide)))
    (slots461.jump 1611 1608 f r (row_of_literal 1611 _ (by decide) RawRows.raw1611))

theorem site1608 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1608:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1612:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1608Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site1612Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1612 f r x y z) (slots640.atReg 1615 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1612 3 1615 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1612 1615 1613 f r (row_of_literal 1612 _ (by decide) RawRows.raw1612))
    (slots640.pos_x 1612 1615 1613 f r (row_of_literal 1612 _ (by decide) RawRows.raw1612))
    (slots640.inc_y 1613 1614 f r (row_of_literal 1613 _ (by decide) RawRows.raw1613) (Or.inl (by decide)))
    (slots640.jump 1614 1612 f r (row_of_literal 1614 _ (by decide) RawRows.raw1614))

theorem site1612 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1612:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1615:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1612Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site1615Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1615 f r x y z) (slots160.atReg 1618 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1615 3 1618 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1615 1618 1616 f r (row_of_literal 1615 _ (by decide) RawRows.raw1615))
    (slots160.pos_x 1615 1618 1616 f r (row_of_literal 1615 _ (by decide) RawRows.raw1615))
    (slots160.inc_y 1616 1617 f r (row_of_literal 1616 _ (by decide) RawRows.raw1616) (Or.inl (by decide)))
    (slots160.jump 1617 1615 f r (row_of_literal 1617 _ (by decide) RawRows.raw1617))

theorem site1615 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1615:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1618:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1615Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1618Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1618 f r x y z) (slots210.atReg 1621 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1618 3 1621 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1618 1621 1619 f r (row_of_literal 1618 _ (by decide) RawRows.raw1618))
    (slots210.pos_x 1618 1621 1619 f r (row_of_literal 1618 _ (by decide) RawRows.raw1618))
    (slots210.inc_y 1619 1620 f r (row_of_literal 1619 _ (by decide) RawRows.raw1619) (Or.inl (by decide)))
    (slots210.jump 1620 1618 f r (row_of_literal 1620 _ (by decide) RawRows.raw1620))

theorem site1618 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1618:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1621:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1618Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1621Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1621 f r x y z) (slots617.atReg 1631 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1621 10 1631 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1621 1625 1622 f r (row_of_literal 1621 _ (by decide) RawRows.raw1621))
    (slots617.pos_y 1621 1625 1622 f r (row_of_literal 1621 _ (by decide) RawRows.raw1621))
    (slots617.inc_z 1622 1623 f r (row_of_literal 1622 _ (by decide) RawRows.raw1622) (Or.inl (by decide)))
    (slots617.inc_x 1623 1624 f r (row_of_literal 1623 _ (by decide) RawRows.raw1623) (Or.inl (by decide)))
    (slots617.jump 1624 1621 f r (row_of_literal 1624 _ (by decide) RawRows.raw1624))
    (slots617.zero_x 1625 1631 1626 f r (row_of_literal 1625 _ (by decide) RawRows.raw1625))
    (slots617.pos_x 1625 1631 1626 f r (row_of_literal 1625 _ (by decide) RawRows.raw1625))
    (slots617.inc_z 1626 1627 f r (row_of_literal 1626 _ (by decide) RawRows.raw1626) (Or.inl (by decide)))
    (slots617.zero_x 1627 1630 1628 f r (row_of_literal 1627 _ (by decide) RawRows.raw1627))
    (slots617.pos_x 1627 1630 1628 f r (row_of_literal 1627 _ (by decide) RawRows.raw1627))
    (slots617.inc_y 1628 1629 f r (row_of_literal 1628 _ (by decide) RawRows.raw1628) (Or.inl (by decide)))
    (slots617.jump 1629 1627 f r (row_of_literal 1629 _ (by decide) RawRows.raw1629))
    (slots617.jump 1630 1621 f r (row_of_literal 1630 _ (by decide) RawRows.raw1630))

theorem site1621 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1621:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1631:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1621Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1631Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1631 f r x y z) (slots720.atReg 1634 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1631 3 1634 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1631 1634 1632 f r (row_of_literal 1631 _ (by decide) RawRows.raw1631))
    (slots720.pos_x 1631 1634 1632 f r (row_of_literal 1631 _ (by decide) RawRows.raw1631))
    (slots720.inc_y 1632 1633 f r (row_of_literal 1632 _ (by decide) RawRows.raw1632) (Or.inl (by decide)))
    (slots720.jump 1633 1631 f r (row_of_literal 1633 _ (by decide) RawRows.raw1633))

theorem site1631 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1631:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1634:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1631Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1634Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 1634 f r x y z) (slots361.atReg 1638 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 1634 4 1638 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 1634 1638 1635 f r (row_of_literal 1634 _ (by decide) RawRows.raw1634))
    (slots361.pos_x 1634 1638 1635 f r (row_of_literal 1634 _ (by decide) RawRows.raw1634))
    (slots361.inc_y 1635 1636 f r (row_of_literal 1635 _ (by decide) RawRows.raw1635) (Or.inl (by decide)))
    (slots361.inc_z 1636 1637 f r (row_of_literal 1636 _ (by decide) RawRows.raw1636) (Or.inl (by decide)))
    (slots361.jump 1637 1634 f r (row_of_literal 1637 _ (by decide) RawRows.raw1637))

theorem site1634 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1634:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1638:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site1634Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site1638Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 1638 f r x y z) (slots630.atReg 1641 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 1638 3 1641 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 1638 1641 1639 f r (row_of_literal 1638 _ (by decide) RawRows.raw1638))
    (slots630.pos_x 1638 1641 1639 f r (row_of_literal 1638 _ (by decide) RawRows.raw1638))
    (slots630.inc_y 1639 1640 f r (row_of_literal 1639 _ (by decide) RawRows.raw1639) (Or.inl (by decide)))
    (slots630.jump 1640 1638 f r (row_of_literal 1640 _ (by decide) RawRows.raw1640))

theorem site1638 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1638:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1641:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site1638Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site1641Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1641 f r x y z) (slots267.atReg 1649 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1641 8 1649 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1641 1649 1642 f r (row_of_literal 1641 _ (by decide) RawRows.raw1641))
    (slots267.pos_x 1641 1649 1642 f r (row_of_literal 1641 _ (by decide) RawRows.raw1641))
    (slots267.inc_z 1642 1643 f r (row_of_literal 1642 _ (by decide) RawRows.raw1642) (Or.inl (by decide)))
    (slots267.zero_y 1643 1645 1644 f r (row_of_literal 1643 _ (by decide) RawRows.raw1643))
    (slots267.pos_y 1643 1645 1644 f r (row_of_literal 1643 _ (by decide) RawRows.raw1643))
    (slots267.jump 1644 1648 f r (row_of_literal 1644 _ (by decide) RawRows.raw1644))
    (slots267.zero_z 1645 1648 1646 f r (row_of_literal 1645 _ (by decide) RawRows.raw1645))
    (slots267.pos_z 1645 1648 1646 f r (row_of_literal 1645 _ (by decide) RawRows.raw1645))
    (slots267.inc_y 1646 1647 f r (row_of_literal 1646 _ (by decide) RawRows.raw1646) (Or.inl (by decide)))
    (slots267.jump 1647 1645 f r (row_of_literal 1647 _ (by decide) RawRows.raw1647))
    (slots267.jump 1648 1641 f r (row_of_literal 1648 _ (by decide) RawRows.raw1648))

theorem site1641 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1641:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1649:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1641Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1649Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1649 f r x y z) (slots720.atReg 1652 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1649 3 1652 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1649 1652 1650 f r (row_of_literal 1649 _ (by decide) RawRows.raw1649))
    (slots720.pos_x 1649 1652 1650 f r (row_of_literal 1649 _ (by decide) RawRows.raw1649))
    (slots720.inc_y 1650 1651 f r (row_of_literal 1650 _ (by decide) RawRows.raw1650) (Or.inl (by decide)))
    (slots720.jump 1651 1649 f r (row_of_literal 1651 _ (by decide) RawRows.raw1651))

theorem site1649 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1649:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1652:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1649Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1652Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1652 f r x y z) (slots617.atReg 1662 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1652 10 1662 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1652 1656 1653 f r (row_of_literal 1652 _ (by decide) RawRows.raw1652))
    (slots617.pos_y 1652 1656 1653 f r (row_of_literal 1652 _ (by decide) RawRows.raw1652))
    (slots617.inc_z 1653 1654 f r (row_of_literal 1653 _ (by decide) RawRows.raw1653) (Or.inl (by decide)))
    (slots617.inc_x 1654 1655 f r (row_of_literal 1654 _ (by decide) RawRows.raw1654) (Or.inl (by decide)))
    (slots617.jump 1655 1652 f r (row_of_literal 1655 _ (by decide) RawRows.raw1655))
    (slots617.zero_x 1656 1662 1657 f r (row_of_literal 1656 _ (by decide) RawRows.raw1656))
    (slots617.pos_x 1656 1662 1657 f r (row_of_literal 1656 _ (by decide) RawRows.raw1656))
    (slots617.inc_z 1657 1658 f r (row_of_literal 1657 _ (by decide) RawRows.raw1657) (Or.inl (by decide)))
    (slots617.zero_x 1658 1661 1659 f r (row_of_literal 1658 _ (by decide) RawRows.raw1658))
    (slots617.pos_x 1658 1661 1659 f r (row_of_literal 1658 _ (by decide) RawRows.raw1658))
    (slots617.inc_y 1659 1660 f r (row_of_literal 1659 _ (by decide) RawRows.raw1659) (Or.inl (by decide)))
    (slots617.jump 1660 1658 f r (row_of_literal 1660 _ (by decide) RawRows.raw1660))
    (slots617.jump 1661 1652 f r (row_of_literal 1661 _ (by decide) RawRows.raw1661))

theorem site1652 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1652:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1662:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1652Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1662Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1662 f r x y z) (slots710.atReg 1666 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1662 4 1666 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1662 1666 1663 f r (row_of_literal 1662 _ (by decide) RawRows.raw1662))
    (slots710.pos_x 1662 1666 1663 f r (row_of_literal 1662 _ (by decide) RawRows.raw1662))
    (slots710.inc_y 1663 1664 f r (row_of_literal 1663 _ (by decide) RawRows.raw1663) (Or.inl (by decide)))
    (slots710.inc_y 1664 1665 f r (row_of_literal 1664 _ (by decide) RawRows.raw1664) (Or.inl (by decide)))
    (slots710.jump 1665 1662 f r (row_of_literal 1665 _ (by decide) RawRows.raw1665))

theorem site1662 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1662:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1666:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1662Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1666 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1666:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1667:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1666 _ (row_of_literal 1666 _ (by decide) RawRows.raw1666)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1667Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1667 f r x y z) (slots160.atReg 1670 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1667 3 1670 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1667 1670 1668 f r (row_of_literal 1667 _ (by decide) RawRows.raw1667))
    (slots160.pos_x 1667 1670 1668 f r (row_of_literal 1667 _ (by decide) RawRows.raw1667))
    (slots160.inc_y 1668 1669 f r (row_of_literal 1668 _ (by decide) RawRows.raw1668) (Or.inl (by decide)))
    (slots160.jump 1669 1667 f r (row_of_literal 1669 _ (by decide) RawRows.raw1669))

theorem site1667 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1667:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1670:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1667Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1670Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1670 f r x y z) (slots210.atReg 1673 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1670 3 1673 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1670 1673 1671 f r (row_of_literal 1670 _ (by decide) RawRows.raw1670))
    (slots210.pos_x 1670 1673 1671 f r (row_of_literal 1670 _ (by decide) RawRows.raw1670))
    (slots210.inc_y 1671 1672 f r (row_of_literal 1671 _ (by decide) RawRows.raw1671) (Or.inl (by decide)))
    (slots210.jump 1672 1670 f r (row_of_literal 1672 _ (by decide) RawRows.raw1672))

theorem site1670 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1670:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1673:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1670Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1673Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1673 f r x y z) (slots617.atReg 1683 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1673 10 1683 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1673 1677 1674 f r (row_of_literal 1673 _ (by decide) RawRows.raw1673))
    (slots617.pos_y 1673 1677 1674 f r (row_of_literal 1673 _ (by decide) RawRows.raw1673))
    (slots617.inc_z 1674 1675 f r (row_of_literal 1674 _ (by decide) RawRows.raw1674) (Or.inl (by decide)))
    (slots617.inc_x 1675 1676 f r (row_of_literal 1675 _ (by decide) RawRows.raw1675) (Or.inl (by decide)))
    (slots617.jump 1676 1673 f r (row_of_literal 1676 _ (by decide) RawRows.raw1676))
    (slots617.zero_x 1677 1683 1678 f r (row_of_literal 1677 _ (by decide) RawRows.raw1677))
    (slots617.pos_x 1677 1683 1678 f r (row_of_literal 1677 _ (by decide) RawRows.raw1677))
    (slots617.inc_z 1678 1679 f r (row_of_literal 1678 _ (by decide) RawRows.raw1678) (Or.inl (by decide)))
    (slots617.zero_x 1679 1682 1680 f r (row_of_literal 1679 _ (by decide) RawRows.raw1679))
    (slots617.pos_x 1679 1682 1680 f r (row_of_literal 1679 _ (by decide) RawRows.raw1679))
    (slots617.inc_y 1680 1681 f r (row_of_literal 1680 _ (by decide) RawRows.raw1680) (Or.inl (by decide)))
    (slots617.jump 1681 1679 f r (row_of_literal 1681 _ (by decide) RawRows.raw1681))
    (slots617.jump 1682 1673 f r (row_of_literal 1682 _ (by decide) RawRows.raw1682))

theorem site1673 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1673:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1683:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1673Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1683Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1683 f r x y z) (slots720.atReg 1686 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1683 3 1686 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1683 1686 1684 f r (row_of_literal 1683 _ (by decide) RawRows.raw1683))
    (slots720.pos_x 1683 1686 1684 f r (row_of_literal 1683 _ (by decide) RawRows.raw1683))
    (slots720.inc_y 1684 1685 f r (row_of_literal 1684 _ (by decide) RawRows.raw1684) (Or.inl (by decide)))
    (slots720.jump 1685 1683 f r (row_of_literal 1685 _ (by decide) RawRows.raw1685))

theorem site1683 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1683:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1686:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1683Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1686Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 1686 f r x y z) (slots361.atReg 1690 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 1686 4 1690 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 1686 1690 1687 f r (row_of_literal 1686 _ (by decide) RawRows.raw1686))
    (slots361.pos_x 1686 1690 1687 f r (row_of_literal 1686 _ (by decide) RawRows.raw1686))
    (slots361.inc_y 1687 1688 f r (row_of_literal 1687 _ (by decide) RawRows.raw1687) (Or.inl (by decide)))
    (slots361.inc_z 1688 1689 f r (row_of_literal 1688 _ (by decide) RawRows.raw1688) (Or.inl (by decide)))
    (slots361.jump 1689 1686 f r (row_of_literal 1689 _ (by decide) RawRows.raw1689))

theorem site1686 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1686:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1690:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site1686Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site1690Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 1690 f r x y z) (slots630.atReg 1693 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 1690 3 1693 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 1690 1693 1691 f r (row_of_literal 1690 _ (by decide) RawRows.raw1690))
    (slots630.pos_x 1690 1693 1691 f r (row_of_literal 1690 _ (by decide) RawRows.raw1690))
    (slots630.inc_y 1691 1692 f r (row_of_literal 1691 _ (by decide) RawRows.raw1691) (Or.inl (by decide)))
    (slots630.jump 1692 1690 f r (row_of_literal 1692 _ (by decide) RawRows.raw1692))

theorem site1690 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1690:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1693:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site1690Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site1693Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1693 f r x y z) (slots160.atReg 1696 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1693 3 1696 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1693 1696 1694 f r (row_of_literal 1693 _ (by decide) RawRows.raw1693))
    (slots160.pos_x 1693 1696 1694 f r (row_of_literal 1693 _ (by decide) RawRows.raw1693))
    (slots160.inc_y 1694 1695 f r (row_of_literal 1694 _ (by decide) RawRows.raw1694) (Or.inl (by decide)))
    (slots160.jump 1695 1693 f r (row_of_literal 1695 _ (by decide) RawRows.raw1695))

theorem site1693 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1693:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1696:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1693Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1696Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1696 f r x y z) (slots210.atReg 1699 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1696 3 1699 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1696 1699 1697 f r (row_of_literal 1696 _ (by decide) RawRows.raw1696))
    (slots210.pos_x 1696 1699 1697 f r (row_of_literal 1696 _ (by decide) RawRows.raw1696))
    (slots210.inc_y 1697 1698 f r (row_of_literal 1697 _ (by decide) RawRows.raw1697) (Or.inl (by decide)))
    (slots210.jump 1698 1696 f r (row_of_literal 1698 _ (by decide) RawRows.raw1698))

theorem site1696 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1696:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1699:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1696Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1699Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1699 f r x y z) (slots617.atReg 1709 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1699 10 1709 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1699 1703 1700 f r (row_of_literal 1699 _ (by decide) RawRows.raw1699))
    (slots617.pos_y 1699 1703 1700 f r (row_of_literal 1699 _ (by decide) RawRows.raw1699))
    (slots617.inc_z 1700 1701 f r (row_of_literal 1700 _ (by decide) RawRows.raw1700) (Or.inl (by decide)))
    (slots617.inc_x 1701 1702 f r (row_of_literal 1701 _ (by decide) RawRows.raw1701) (Or.inl (by decide)))
    (slots617.jump 1702 1699 f r (row_of_literal 1702 _ (by decide) RawRows.raw1702))
    (slots617.zero_x 1703 1709 1704 f r (row_of_literal 1703 _ (by decide) RawRows.raw1703))
    (slots617.pos_x 1703 1709 1704 f r (row_of_literal 1703 _ (by decide) RawRows.raw1703))
    (slots617.inc_z 1704 1705 f r (row_of_literal 1704 _ (by decide) RawRows.raw1704) (Or.inl (by decide)))
    (slots617.zero_x 1705 1708 1706 f r (row_of_literal 1705 _ (by decide) RawRows.raw1705))
    (slots617.pos_x 1705 1708 1706 f r (row_of_literal 1705 _ (by decide) RawRows.raw1705))
    (slots617.inc_y 1706 1707 f r (row_of_literal 1706 _ (by decide) RawRows.raw1706) (Or.inl (by decide)))
    (slots617.jump 1707 1705 f r (row_of_literal 1707 _ (by decide) RawRows.raw1707))
    (slots617.jump 1708 1699 f r (row_of_literal 1708 _ (by decide) RawRows.raw1708))

theorem site1699 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1699:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1709:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1699Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1709Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1709 f r x y z) (slots720.atReg 1712 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1709 3 1712 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1709 1712 1710 f r (row_of_literal 1709 _ (by decide) RawRows.raw1709))
    (slots720.pos_x 1709 1712 1710 f r (row_of_literal 1709 _ (by decide) RawRows.raw1709))
    (slots720.inc_y 1710 1711 f r (row_of_literal 1710 _ (by decide) RawRows.raw1710) (Or.inl (by decide)))
    (slots720.jump 1711 1709 f r (row_of_literal 1711 _ (by decide) RawRows.raw1711))

theorem site1709 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1709:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1712:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1709Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1712Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1712 f r x y z) (slots561.atReg 1716 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1712 4 1716 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1712 1716 1713 f r (row_of_literal 1712 _ (by decide) RawRows.raw1712))
    (slots561.pos_x 1712 1716 1713 f r (row_of_literal 1712 _ (by decide) RawRows.raw1712))
    (slots561.inc_y 1713 1714 f r (row_of_literal 1713 _ (by decide) RawRows.raw1713) (Or.inl (by decide)))
    (slots561.inc_z 1714 1715 f r (row_of_literal 1714 _ (by decide) RawRows.raw1714) (Or.inl (by decide)))
    (slots561.jump 1715 1712 f r (row_of_literal 1715 _ (by decide) RawRows.raw1715))

theorem site1712 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1712:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1716:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1712Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1716Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1716 f r x y z) (slots650.atReg 1719 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1716 3 1719 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1716 1719 1717 f r (row_of_literal 1716 _ (by decide) RawRows.raw1716))
    (slots650.pos_x 1716 1719 1717 f r (row_of_literal 1716 _ (by decide) RawRows.raw1716))
    (slots650.inc_y 1717 1718 f r (row_of_literal 1717 _ (by decide) RawRows.raw1717) (Or.inl (by decide)))
    (slots650.jump 1718 1716 f r (row_of_literal 1718 _ (by decide) RawRows.raw1718))

theorem site1716 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1716:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1719:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1716Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1719Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1719 f r x y z) (slots267.atReg 1727 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1719 8 1727 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1719 1727 1720 f r (row_of_literal 1719 _ (by decide) RawRows.raw1719))
    (slots267.pos_x 1719 1727 1720 f r (row_of_literal 1719 _ (by decide) RawRows.raw1719))
    (slots267.inc_z 1720 1721 f r (row_of_literal 1720 _ (by decide) RawRows.raw1720) (Or.inl (by decide)))
    (slots267.zero_y 1721 1723 1722 f r (row_of_literal 1721 _ (by decide) RawRows.raw1721))
    (slots267.pos_y 1721 1723 1722 f r (row_of_literal 1721 _ (by decide) RawRows.raw1721))
    (slots267.jump 1722 1726 f r (row_of_literal 1722 _ (by decide) RawRows.raw1722))
    (slots267.zero_z 1723 1726 1724 f r (row_of_literal 1723 _ (by decide) RawRows.raw1723))
    (slots267.pos_z 1723 1726 1724 f r (row_of_literal 1723 _ (by decide) RawRows.raw1723))
    (slots267.inc_y 1724 1725 f r (row_of_literal 1724 _ (by decide) RawRows.raw1724) (Or.inl (by decide)))
    (slots267.jump 1725 1723 f r (row_of_literal 1725 _ (by decide) RawRows.raw1725))
    (slots267.jump 1726 1719 f r (row_of_literal 1726 _ (by decide) RawRows.raw1726))

theorem site1719 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1719:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1727:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1719Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1727Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1727 f r x y z) (slots720.atReg 1730 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1727 3 1730 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1727 1730 1728 f r (row_of_literal 1727 _ (by decide) RawRows.raw1727))
    (slots720.pos_x 1727 1730 1728 f r (row_of_literal 1727 _ (by decide) RawRows.raw1727))
    (slots720.inc_y 1728 1729 f r (row_of_literal 1728 _ (by decide) RawRows.raw1728) (Or.inl (by decide)))
    (slots720.jump 1729 1727 f r (row_of_literal 1729 _ (by decide) RawRows.raw1729))

theorem site1727 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1727:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1730:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1727Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1730Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1730 f r x y z) (slots617.atReg 1740 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1730 10 1740 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1730 1734 1731 f r (row_of_literal 1730 _ (by decide) RawRows.raw1730))
    (slots617.pos_y 1730 1734 1731 f r (row_of_literal 1730 _ (by decide) RawRows.raw1730))
    (slots617.inc_z 1731 1732 f r (row_of_literal 1731 _ (by decide) RawRows.raw1731) (Or.inl (by decide)))
    (slots617.inc_x 1732 1733 f r (row_of_literal 1732 _ (by decide) RawRows.raw1732) (Or.inl (by decide)))
    (slots617.jump 1733 1730 f r (row_of_literal 1733 _ (by decide) RawRows.raw1733))
    (slots617.zero_x 1734 1740 1735 f r (row_of_literal 1734 _ (by decide) RawRows.raw1734))
    (slots617.pos_x 1734 1740 1735 f r (row_of_literal 1734 _ (by decide) RawRows.raw1734))
    (slots617.inc_z 1735 1736 f r (row_of_literal 1735 _ (by decide) RawRows.raw1735) (Or.inl (by decide)))
    (slots617.zero_x 1736 1739 1737 f r (row_of_literal 1736 _ (by decide) RawRows.raw1736))
    (slots617.pos_x 1736 1739 1737 f r (row_of_literal 1736 _ (by decide) RawRows.raw1736))
    (slots617.inc_y 1737 1738 f r (row_of_literal 1737 _ (by decide) RawRows.raw1737) (Or.inl (by decide)))
    (slots617.jump 1738 1736 f r (row_of_literal 1738 _ (by decide) RawRows.raw1738))
    (slots617.jump 1739 1730 f r (row_of_literal 1739 _ (by decide) RawRows.raw1739))

theorem site1730 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1730:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1740:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1730Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


end PA192.ModelSearch.Register181.Certified
