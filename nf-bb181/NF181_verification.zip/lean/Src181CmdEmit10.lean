module
public import Src181CmdEmit09
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter321 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1564:Nat):V) f (vector n ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1563 f n ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w))+1):V)=((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter320 f n t s c u v y d w).trans mid

theorem commandEmitAfter322 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1572:Nat):V) f (vector n ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w) w)) := by
  have micro := site1564 f n ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom49 n t s c u v y d w))):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom49 n t s c u v y d w)):V)=(0+(emitAtom49 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom49 n t s c u v y d w))):V)=left (emitAtom49 n t s c u v y d w))).trans (by change left (cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom49 n t s c u v y d w))):V)=(emitAtom47 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom49 n t s c u v y d w)):V)=(0+(emitAtom49 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom49 n t s c u v y d w))):V)=right (emitAtom49 n t s c u v y d w))).trans (by change right (cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter321 f n t s c u v y d w).trans mid

theorem commandEmitAfter323 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1575:Nat):V) f (vector n ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1572 f n ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w) w
  have d2 : ((0+(emitAtom47 n t s c u v y d w)):V)=(emitAtom47 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter322 f n t s c u v y d w).trans mid

theorem commandEmitAfter324 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1585:Nat):V) f (vector n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom54 n t s c u v y d w) w)) := by
  have micro := site1575 f n ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1))):V)=(emitAtom54 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) ((emitAtom53 n t s c u v y d w)+(emitAtom53 n t s c u v y d w)+1))):V)=(0+(emitAtom54 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter323 f n t s c u v y d w).trans mid

theorem commandEmitAfter325 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1589:Nat):V) f (vector n ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1585 f n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom54 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom54 n t s c u v y d w))):V)=((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom54 n t s c u v y d w))):V)=(0+((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter324 f n t s c u v y d w).trans mid

theorem commandEmitAfter326 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1592:Nat):V) f (vector n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) 0 w)) := by
  have micro := site1589 f n ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w))):V)=((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter325 f n t s c u v y d w).trans mid

theorem commandEmitAfter327 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1595:Nat):V) f (vector n (emitAtom47 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) 0 w)) := by
  have micro := site1592 f n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) 0 w
  have d1 : ((0+(emitAtom47 n t s c u v y d w)):V)=(emitAtom47 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter326 f n t s c u v y d w).trans mid

theorem commandEmitAfter328 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1605:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom55 n t s c u v y d w) w)) := by
  have micro := site1595 f n (emitAtom47 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) 0 w
  have d7 : ((0+(cantor ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) (emitAtom47 n t s c u v y d w))):V)=(emitAtom55 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) (emitAtom47 n t s c u v y d w))):V)=(0+(emitAtom55 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter327 f n t s c u v y d w).trans mid

theorem commandEmitAfter329 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1608:Nat):V) f (vector n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1605 f n 0 0 c (d+u) (v+y) 0 (emitAtom55 n t s c u v y d w) w
  have d2 : ((0+(emitAtom55 n t s c u v y d w)):V)=(emitAtom55 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter328 f n t s c u v y d w).trans mid

theorem commandEmitAfter330 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1612:Nat):V) f (vector n (d+u) (emitAtom55 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1608 f n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter329 f n t s c u v y d w).trans mid

theorem commandEmitAfter331 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1615:Nat):V) f (vector n (d+u) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1612 f n (d+u) (emitAtom55 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter330 f n t s c u v y d w).trans mid

theorem commandEmitAfter332 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1618:Nat):V) f (vector n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1615 f n (d+u) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter331 f n t s c u v y d w).trans mid

theorem commandEmitAfter333 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1621:Nat):V) f (vector n (emitAtom55 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1618 f n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom55 n t s c u v y d w)):V)=(emitAtom55 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter332 f n t s c u v y d w).trans mid

theorem commandEmitAfter334 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1631:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom56 n t s c u v y d w) w)) := by
  have micro := site1621 f n (emitAtom55 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom55 n t s c u v y d w))):V)=(emitAtom56 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom55 n t s c u v y d w))):V)=(0+(emitAtom56 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter333 f n t s c u v y d w).trans mid

theorem commandEmitAfter335 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1634:Nat):V) f (vector n 0 (emitAtom56 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1631 f n 0 0 c (d+u) (v+y) 0 (emitAtom56 n t s c u v y d w) w
  have d2 : ((0+(emitAtom56 n t s c u v y d w)):V)=(emitAtom56 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter334 f n t s c u v y d w).trans mid

theorem commandEmitAfter336 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1638:Nat):V) f (vector n c (emitAtom56 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site1634 f n 0 (emitAtom56 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter335 f n t s c u v y d w).trans mid

theorem commandEmitAfter337 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1641:Nat):V) f (vector n c (emitAtom56 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1638 f n c (emitAtom56 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter336 f n t s c u v y d w).trans mid

theorem commandEmitAfter338 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1649:Nat):V) f (vector n c 0 c (d+u) (v+y) (d+u) (emitAtom55 n t s c u v y d w) w)) := by
  have micro := site1641 f n c (emitAtom56 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom56 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom56 n t s c u v y d w)):V)=(0+(emitAtom56 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom56 n t s c u v y d w))):V)=left (emitAtom56 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom55 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom56 n t s c u v y d w))):V)=(emitAtom55 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom56 n t s c u v y d w)):V)=(0+(emitAtom56 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom56 n t s c u v y d w))):V)=right (emitAtom56 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom55 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter337 f n t s c u v y d w).trans mid

theorem commandEmitAfter339 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1652:Nat):V) f (vector n c (emitAtom55 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site1649 f n c 0 c (d+u) (v+y) (d+u) (emitAtom55 n t s c u v y d w) w
  have d2 : ((0+(emitAtom55 n t s c u v y d w)):V)=(emitAtom55 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter338 f n t s c u v y d w).trans mid

theorem commandEmitAfter340 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1662:Nat):V) f (vector n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom9 n t s c u v y d w) w)) := by
  have micro := site1652 f n c (emitAtom55 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) c)):V)=(emitAtom9 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) c)):V)=(0+(emitAtom9 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter339 f n t s c u v y d w).trans mid

theorem commandEmitAfter341 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1666:Nat):V) f (vector n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1662 f n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom9 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom9 n t s c u v y d w))):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom9 n t s c u v y d w))):V)=(0+((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter340 f n t s c u v y d w).trans mid

theorem commandEmitAfter342 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1667:Nat):V) f (vector n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1666 f n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w))+1):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter341 f n t s c u v y d w).trans mid

theorem commandEmitAfter343 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1670:Nat):V) f (vector n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1667 f n ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1)):V)=((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter342 f n t s c u v y d w).trans mid

theorem commandEmitAfter344 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1673:Nat):V) f (vector n (emitAtom55 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1670 f n 0 (emitAtom55 n t s c u v y d w) c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom55 n t s c u v y d w)):V)=(emitAtom55 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter343 f n t s c u v y d w).trans mid

theorem commandEmitAfter345 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1683:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom57 n t s c u v y d w) w)) := by
  have micro := site1673 f n (emitAtom55 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w))):V)=(emitAtom57 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom9 n t s c u v y d w)+(emitAtom9 n t s c u v y d w)+1) (emitAtom55 n t s c u v y d w))):V)=(0+(emitAtom57 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter344 f n t s c u v y d w).trans mid

theorem commandEmitAfter346 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1686:Nat):V) f (vector n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1683 f n 0 0 c (d+u) (v+y) 0 (emitAtom57 n t s c u v y d w) w
  have d2 : ((0+(emitAtom57 n t s c u v y d w)):V)=(emitAtom57 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter345 f n t s c u v y d w).trans mid

theorem commandEmitAfter347 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1690:Nat):V) f (vector n c (emitAtom57 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site1686 f n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter346 f n t s c u v y d w).trans mid

theorem commandEmitAfter348 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1693:Nat):V) f (vector n c (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1690 f n c (emitAtom57 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter347 f n t s c u v y d w).trans mid

theorem commandEmitAfter349 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1696:Nat):V) f (vector n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1693 f n c (emitAtom57 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter348 f n t s c u v y d w).trans mid

theorem commandEmitAfter350 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1699:Nat):V) f (vector n (emitAtom57 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w)) := by
  have micro := site1696 f n 0 (emitAtom57 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d1 : ((0+(emitAtom57 n t s c u v y d w)):V)=(emitAtom57 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter349 f n t s c u v y d w).trans mid

theorem commandEmitAfter351 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1709:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom58 n t s c u v y d w) w)) := by
  have micro := site1699 f n (emitAtom57 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w
  have d7 : ((0+(cantor c (emitAtom57 n t s c u v y d w))):V)=(emitAtom58 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c (emitAtom57 n t s c u v y d w))):V)=(0+(emitAtom58 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter350 f n t s c u v y d w).trans mid

theorem commandEmitAfter352 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1712:Nat):V) f (vector n 0 (emitAtom58 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1709 f n 0 0 c (d+u) (v+y) 0 (emitAtom58 n t s c u v y d w) w
  have d2 : ((0+(emitAtom58 n t s c u v y d w)):V)=(emitAtom58 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter351 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
