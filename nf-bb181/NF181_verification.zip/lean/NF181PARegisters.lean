module
public import NF181Raw
public import ModelLiteralRegisters

@[expose] public section

/-! The signed nine-register source machine, with the exact instructions
from the 182-state program and coded configurations in any model of PA. -/
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace NF181PA.Registers
open PA192.ModelSearch.RegisterSource (Instr config address cold registers vector readReg writeReg perform dispatch)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

def instruction (p : Nat) : Instr :=
  match Direct181Source.Raw.program p with
  | .inl (r,n) => .inc r n
  | .inr (.inl (r,z,n,h)) => .dec r (if h then 4095 else z) n
  | .inr (.inr n) => .jump n

@[irreducible] def program : List Instr := (List.range 2971).map instruction
@[simp] theorem program_length : program.length=2971 := by unfold program; simp only [List.length_map,List.length_range]
private theorem get_range {α : Type} (t : Nat → α) (n j : Nat) (h : j<n) :
    getElem? ((List.range n).map t) j = some (t j) := by
  rw [List.getElem?_eq_getElem (by simpa using h)]
  simp only [List.getElem_map,List.getElem_range]

@[simp] theorem program_at (p : Fin 2971) : program[p.val]? = some (instruction p.val) := by
  unfold program
  exact get_range instruction _ _ p.isLt

noncomputable def next (s : V) := dispatch program (address s) (cold s) (registers s)
private theorem dispatch_config_def (ops : List Instr) :
    Language.DefinableFunction₁ ℒₒᵣ (fun s : V => dispatch ops (address s) (cold s) (registers s)) := by
  apply Language.DefinableFunction₃.comp (F:=dispatch ops) <;> infer_instance
instance nextDef : Language.DefinableFunction₁ ℒₒᵣ (next (V:=V)) := by
  unfold next
  exact dispatch_config_def (V:=V) program
theorem next_at (p : Fin 2971) (c r : V) :
    next (config (p.val:V) c r) = perform (instruction p.val) c r := by
  simp only [next,RegisterSource.address_config,RegisterSource.cold_config,RegisterSource.registers_config]
  exact RegisterSource.dispatch_get _ _ _ (program_at p) _ _

noncomputable def margin (V : Type) [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] : V :=
  config 111 1 (vector 0 0 0 2 0 0 0 1 0)
noncomputable def run (t : V) := iterate next t (margin V)
private theorem iterate_from_def (f : V → V) [Language.DefinableFunction₁ ℒₒᵣ f] (initial : V) :
    Language.DefinableFunction₁ ℒₒᵣ (fun t => iterate f t initial) := by
  definability
instance runDef : Language.DefinableFunction₁ ℒₒᵣ (run (V:=V)) := by
  unfold run
  exact iterate_from_def (V:=V) next (margin V)

@[simp] theorem run_zero : run (0:V) = margin V := iterate_zero next _
theorem run_succ (t : V) : run (t+1) = next (run t) := iterate_succ next t _

theorem next_terminal (s : V) (h : address s = 4095) : address (next s) = 4095 := by
  unfold next
  rw [h,RegisterSource.dispatch_falloff,RegisterSource.address_config]
  rw [program_length]
  exact_mod_cast (show (2971:Nat) ≤ 4095 by decide)

#print axioms next_terminal
#print axioms next_at
#print axioms runDef
end NF181PA.Registers
