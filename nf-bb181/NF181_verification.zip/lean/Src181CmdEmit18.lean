module
public import Src181CmdEmit17
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter577 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2772:Nat):V) f (vector n (d+u) (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2769 f n (d+u) (emitAtom91 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter576 f n t s c u v y d w).trans mid

theorem commandEmitAfter578 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2775:Nat):V) f (vector n 0 (emitAtom91 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2772 f n (d+u) (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter577 f n t s c u v y d w).trans mid

theorem commandEmitAfter579 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2778:Nat):V) f (vector n (emitAtom91 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2775 f n 0 (emitAtom91 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom91 n t s c u v y d w)):V)=(emitAtom91 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter578 f n t s c u v y d w).trans mid

theorem commandEmitAfter580 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2788:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom92 n t s c u v y d w) w)) := by
  have micro := site2778 f n (emitAtom91 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom91 n t s c u v y d w))):V)=(emitAtom92 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom91 n t s c u v y d w))):V)=(0+(emitAtom92 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter579 f n t s c u v y d w).trans mid

theorem commandEmitAfter581 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2791:Nat):V) f (vector n 0 (emitAtom92 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2788 f n 0 0 c (d+u) (v+y) 0 (emitAtom92 n t s c u v y d w) w
  have d2 : ((0+(emitAtom92 n t s c u v y d w)):V)=(emitAtom92 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter580 f n t s c u v y d w).trans mid

theorem commandEmitAfter582 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2795:Nat):V) f (vector n (v+y) (emitAtom92 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2791 f n 0 (emitAtom92 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter581 f n t s c u v y d w).trans mid

theorem commandEmitAfter583 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2798:Nat):V) f (vector n (v+y) (emitAtom92 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2795 f n (v+y) (emitAtom92 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter582 f n t s c u v y d w).trans mid

theorem commandEmitAfter584 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2806:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom91 n t s c u v y d w) w)) := by
  have micro := site2798 f n (v+y) (emitAtom92 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom92 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom92 n t s c u v y d w)):V)=(0+(emitAtom92 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom92 n t s c u v y d w))):V)=left (emitAtom92 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom91 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom92 n t s c u v y d w))):V)=(emitAtom91 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom92 n t s c u v y d w)):V)=(0+(emitAtom92 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom92 n t s c u v y d w))):V)=right (emitAtom92 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom91 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter583 f n t s c u v y d w).trans mid

theorem commandEmitAfter585 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2809:Nat):V) f (vector n (v+y) (emitAtom91 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site2806 f n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom91 n t s c u v y d w) w
  have d2 : ((0+(emitAtom91 n t s c u v y d w)):V)=(emitAtom91 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter584 f n t s c u v y d w).trans mid

theorem commandEmitAfter586 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2819:Nat):V) f (vector n 0 (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w)) := by
  have micro := site2809 f n (v+y) (emitAtom91 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (v+y))):V)=(emitAtom24 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (v+y))):V)=(0+(emitAtom24 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter585 f n t s c u v y d w).trans mid

theorem commandEmitAfter587 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2823:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2819 f n 0 (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=(0+((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter586 f n t s c u v y d w).trans mid

theorem commandEmitAfter588 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2824:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2823 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))+1):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter587 f n t s c u v y d w).trans mid

theorem commandEmitAfter589 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2832:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) w)) := by
  have micro := site2824 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom91 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom91 n t s c u v y d w))):V)=((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom91 n t s c u v y d w)):V)=(0+(emitAtom91 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom91 n t s c u v y d w))):V)=left (emitAtom91 n t s c u v y d w))).trans (by change left (cantor ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom91 n t s c u v y d w))):V)=(emitAtom82 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom91 n t s c u v y d w)):V)=(0+(emitAtom91 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom91 n t s c u v y d w))):V)=right (emitAtom91 n t s c u v y d w))).trans (by change right (cantor ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter588 f n t s c u v y d w).trans mid

theorem commandEmitAfter590 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2835:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2832 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) w
  have d2 : ((0+(emitAtom82 n t s c u v y d w)):V)=(emitAtom82 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter589 f n t s c u v y d w).trans mid

theorem commandEmitAfter591 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2845:Nat):V) f (vector n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom93 n t s c u v y d w) w)) := by
  have micro := site2835 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(emitAtom93 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom90 n t s c u v y d w)+(emitAtom90 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(0+(emitAtom93 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter590 f n t s c u v y d w).trans mid

theorem commandEmit (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2849:Nat):V) f (vector n ((emitAtom93 n t s c u v y d w)+(emitAtom93 n t s c u v y d w)) (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2845 f n 0 (emitAtom82 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom93 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom93 n t s c u v y d w))):V)=((emitAtom93 n t s c u v y d w)+(emitAtom93 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom93 n t s c u v y d w))):V)=(0+((emitAtom93 n t s c u v y d w)+(emitAtom93 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter591 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
