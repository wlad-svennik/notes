import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1984_0 : checkWitness 1984 false false 8885 = true := by decide +kernel
private theorem w1984_2 : checkWitness 1984 true false 8881 = true := by decide +kernel
private theorem cases1984 : checkFour 1984 (8885,0,8881,0) = true := by
  simp only [checkFour, w1984_0, w1984_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1984 : Coverage 1984 1985 := checkList_sound (ws:=[(8885,0,8881,0)]) (by simpa only [checkList, Bool.and_true] using cases1984)
private theorem w1985_0 : checkWitness 1985 false false 8920 = true := by decide +kernel
private theorem w1985_2 : checkWitness 1985 true false 8911 = true := by decide +kernel
private theorem cases1985 : checkFour 1985 (8920,0,8911,0) = true := by
  simp only [checkFour, w1985_0, w1985_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1985 : Coverage 1985 1986 := checkList_sound (ws:=[(8920,0,8911,0)]) (by simpa only [checkList, Bool.and_true] using cases1985)
private theorem w1986_0 : checkWitness 1986 false false 90 = true := by decide +kernel
private theorem w1986_2 : checkWitness 1986 true false 90 = true := by decide +kernel
private theorem cases1986 : checkFour 1986 (90,0,90,0) = true := by
  simp only [checkFour, w1986_0, w1986_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1986 : Coverage 1986 1987 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1986)
private theorem w1987_0 : checkWitness 1987 false false 632 = true := by decide +kernel
private theorem w1987_1 : checkWitness 1987 false true 4724 = true := by decide +kernel
private theorem w1987_2 : checkWitness 1987 true false 623 = true := by decide +kernel
private theorem w1987_3 : checkWitness 1987 true true 4715 = true := by decide +kernel
private theorem cases1987 : checkFour 1987 (632,4724,623,4715) = true := by
  simp only [checkFour, w1987_0, w1987_1, w1987_2, w1987_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1987 : Coverage 1987 1988 := checkList_sound (ws:=[(632,4724,623,4715)]) (by simpa only [checkList, Bool.and_true] using cases1987)
private theorem w1988_0 : checkWitness 1988 false false 8881 = true := by decide +kernel
private theorem w1988_2 : checkWitness 1988 true false 8877 = true := by decide +kernel
private theorem cases1988 : checkFour 1988 (8881,0,8877,0) = true := by
  simp only [checkFour, w1988_0, w1988_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1988 : Coverage 1988 1989 := checkList_sound (ws:=[(8881,0,8877,0)]) (by simpa only [checkList, Bool.and_true] using cases1988)
private theorem w1989_0 : checkWitness 1989 false false 626 = true := by decide +kernel
private theorem w1989_1 : checkWitness 1989 false true 4718 = true := by decide +kernel
private theorem w1989_2 : checkWitness 1989 true false 617 = true := by decide +kernel
private theorem w1989_3 : checkWitness 1989 true true 4709 = true := by decide +kernel
private theorem cases1989 : checkFour 1989 (626,4718,617,4709) = true := by
  simp only [checkFour, w1989_0, w1989_1, w1989_2, w1989_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1989 : Coverage 1989 1990 := checkList_sound (ws:=[(626,4718,617,4709)]) (by simpa only [checkList, Bool.and_true] using cases1989)
private theorem w1990_0 : checkWitness 1990 false false 8850 = true := by decide +kernel
private theorem w1990_2 : checkWitness 1990 true false 8846 = true := by decide +kernel
private theorem cases1990 : checkFour 1990 (8850,0,8846,0) = true := by
  simp only [checkFour, w1990_0, w1990_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1990 : Coverage 1990 1991 := checkList_sound (ws:=[(8850,0,8846,0)]) (by simpa only [checkList, Bool.and_true] using cases1990)
private theorem w1991_0 : checkWitness 1991 false false 78 = true := by decide +kernel
private theorem w1991_2 : checkWitness 1991 true false 78 = true := by decide +kernel
private theorem cases1991 : checkFour 1991 (78,0,78,0) = true := by
  simp only [checkFour, w1991_0, w1991_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1991 : Coverage 1991 1992 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1991)
private theorem w1992_0 : checkWitness 1992 false false 70 = true := by decide +kernel
private theorem w1992_2 : checkWitness 1992 true false 70 = true := by decide +kernel
private theorem cases1992 : checkFour 1992 (70,0,70,0) = true := by
  simp only [checkFour, w1992_0, w1992_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1992 : Coverage 1992 1993 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases1992)
private theorem w1993_0 : checkWitness 1993 false false 593 = true := by decide +kernel
private theorem w1993_1 : checkWitness 1993 false true 4681 = true := by decide +kernel
private theorem w1993_2 : checkWitness 1993 true false 593 = true := by decide +kernel
private theorem w1993_3 : checkWitness 1993 true true 4681 = true := by decide +kernel
private theorem cases1993 : checkFour 1993 (593,4681,593,4681) = true := by
  simp only [checkFour, w1993_0, w1993_1, w1993_2, w1993_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1993 : Coverage 1993 1994 := checkList_sound (ws:=[(593,4681,593,4681)]) (by simpa only [checkList, Bool.and_true] using cases1993)
private theorem w1994_0 : checkWitness 1994 false false 8866 = true := by decide +kernel
private theorem w1994_2 : checkWitness 1994 true false 8862 = true := by decide +kernel
private theorem cases1994 : checkFour 1994 (8866,0,8862,0) = true := by
  simp only [checkFour, w1994_0, w1994_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1994 : Coverage 1994 1995 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases1994)
private theorem w1995_0 : checkWitness 1995 false false 8862 = true := by decide +kernel
private theorem w1995_2 : checkWitness 1995 true false 8858 = true := by decide +kernel
private theorem cases1995 : checkFour 1995 (8862,0,8858,0) = true := by
  simp only [checkFour, w1995_0, w1995_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1995 : Coverage 1995 1996 := checkList_sound (ws:=[(8862,0,8858,0)]) (by simpa only [checkList, Bool.and_true] using cases1995)
private theorem w1996_0 : checkWitness 1996 false false 84 = true := by decide +kernel
private theorem w1996_2 : checkWitness 1996 true false 84 = true := by decide +kernel
private theorem cases1996 : checkFour 1996 (84,0,84,0) = true := by
  simp only [checkFour, w1996_0, w1996_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1996 : Coverage 1996 1997 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1996)
private theorem w1997_0 : checkWitness 1997 false false 8882 = true := by decide +kernel
private theorem w1997_2 : checkWitness 1997 true false 8878 = true := by decide +kernel
private theorem cases1997 : checkFour 1997 (8882,0,8878,0) = true := by
  simp only [checkFour, w1997_0, w1997_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1997 : Coverage 1997 1998 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases1997)
private theorem w1998_0 : checkWitness 1998 false false 504 = true := by decide +kernel
private theorem w1998_1 : checkWitness 1998 false true 4600 = true := by decide +kernel
private theorem w1998_2 : checkWitness 1998 true false 504 = true := by decide +kernel
private theorem w1998_3 : checkWitness 1998 true true 4600 = true := by decide +kernel
private theorem cases1998 : checkFour 1998 (504,4600,504,4600) = true := by
  simp only [checkFour, w1998_0, w1998_1, w1998_2, w1998_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1998 : Coverage 1998 1999 := checkList_sound (ws:=[(504,4600,504,4600)]) (by simpa only [checkList, Bool.and_true] using cases1998)
private theorem w1999_0 : checkWitness 1999 false false 8926 = true := by decide +kernel
private theorem w1999_2 : checkWitness 1999 true false 8917 = true := by decide +kernel
private theorem cases1999 : checkFour 1999 (8926,0,8917,0) = true := by
  simp only [checkFour, w1999_0, w1999_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1999 : Coverage 1999 2000 := checkList_sound (ws:=[(8926,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases1999)
private theorem w2000_0 : checkWitness 2000 false false 68 = true := by decide +kernel
private theorem w2000_2 : checkWitness 2000 true false 68 = true := by decide +kernel
private theorem cases2000 : checkFour 2000 (68,0,68,0) = true := by
  simp only [checkFour, w2000_0, w2000_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2000 : Coverage 2000 2001 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases2000)
private theorem w2001_0 : checkWitness 2001 false false 508 = true := by decide +kernel
private theorem w2001_1 : checkWitness 2001 false true 4604 = true := by decide +kernel
private theorem w2001_2 : checkWitness 2001 true false 508 = true := by decide +kernel
private theorem w2001_3 : checkWitness 2001 true true 4604 = true := by decide +kernel
private theorem cases2001 : checkFour 2001 (508,4604,508,4604) = true := by
  simp only [checkFour, w2001_0, w2001_1, w2001_2, w2001_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2001 : Coverage 2001 2002 := checkList_sound (ws:=[(508,4604,508,4604)]) (by simpa only [checkList, Bool.and_true] using cases2001)
private theorem w2002_0 : checkWitness 2002 false false 8866 = true := by decide +kernel
private theorem w2002_2 : checkWitness 2002 true false 8862 = true := by decide +kernel
private theorem cases2002 : checkFour 2002 (8866,0,8862,0) = true := by
  simp only [checkFour, w2002_0, w2002_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2002 : Coverage 2002 2003 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases2002)
private theorem w2003_0 : checkWitness 2003 false false 70 = true := by decide +kernel
private theorem w2003_2 : checkWitness 2003 true false 70 = true := by decide +kernel
private theorem cases2003 : checkFour 2003 (70,0,70,0) = true := by
  simp only [checkFour, w2003_0, w2003_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2003 : Coverage 2003 2004 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases2003)
private theorem w2004_0 : checkWitness 2004 false false 546 = true := by decide +kernel
private theorem w2004_1 : checkWitness 2004 false true 4642 = true := by decide +kernel
private theorem w2004_2 : checkWitness 2004 true false 546 = true := by decide +kernel
private theorem w2004_3 : checkWitness 2004 true true 4642 = true := by decide +kernel
private theorem cases2004 : checkFour 2004 (546,4642,546,4642) = true := by
  simp only [checkFour, w2004_0, w2004_1, w2004_2, w2004_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2004 : Coverage 2004 2005 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases2004)
private theorem w2005_0 : checkWitness 2005 false false 8887 = true := by decide +kernel
private theorem w2005_2 : checkWitness 2005 true false 8883 = true := by decide +kernel
private theorem cases2005 : checkFour 2005 (8887,0,8883,0) = true := by
  simp only [checkFour, w2005_0, w2005_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2005 : Coverage 2005 2006 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases2005)
private theorem w2006_0 : checkWitness 2006 false false 8922 = true := by decide +kernel
private theorem w2006_2 : checkWitness 2006 true false 8913 = true := by decide +kernel
private theorem cases2006 : checkFour 2006 (8922,0,8913,0) = true := by
  simp only [checkFour, w2006_0, w2006_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2006 : Coverage 2006 2007 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases2006)
private theorem w2007_0 : checkWitness 2007 false false 94 = true := by decide +kernel
private theorem w2007_2 : checkWitness 2007 true false 94 = true := by decide +kernel
private theorem cases2007 : checkFour 2007 (94,0,94,0) = true := by
  simp only [checkFour, w2007_0, w2007_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2007 : Coverage 2007 2008 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases2007)
private theorem w2008_0 : checkWitness 2008 false false 634 = true := by decide +kernel
private theorem w2008_1 : checkWitness 2008 false true 4726 = true := by decide +kernel
private theorem w2008_2 : checkWitness 2008 true false 625 = true := by decide +kernel
private theorem w2008_3 : checkWitness 2008 true true 4717 = true := by decide +kernel
private theorem cases2008 : checkFour 2008 (634,4726,625,4717) = true := by
  simp only [checkFour, w2008_0, w2008_1, w2008_2, w2008_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2008 : Coverage 2008 2009 := checkList_sound (ws:=[(634,4726,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases2008)
private theorem w2009_0 : checkWitness 2009 false false 8883 = true := by decide +kernel
private theorem w2009_2 : checkWitness 2009 true false 8879 = true := by decide +kernel
private theorem cases2009 : checkFour 2009 (8883,0,8879,0) = true := by
  simp only [checkFour, w2009_0, w2009_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2009 : Coverage 2009 2010 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases2009)
private theorem w2010_0 : checkWitness 2010 false false 628 = true := by decide +kernel
private theorem w2010_1 : checkWitness 2010 false true 4720 = true := by decide +kernel
private theorem w2010_2 : checkWitness 2010 true false 619 = true := by decide +kernel
private theorem w2010_3 : checkWitness 2010 true true 4711 = true := by decide +kernel
private theorem cases2010 : checkFour 2010 (628,4720,619,4711) = true := by
  simp only [checkFour, w2010_0, w2010_1, w2010_2, w2010_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2010 : Coverage 2010 2011 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases2010)
private theorem w2011_0 : checkWitness 2011 false false 8852 = true := by decide +kernel
private theorem w2011_2 : checkWitness 2011 true false 8848 = true := by decide +kernel
private theorem cases2011 : checkFour 2011 (8852,0,8848,0) = true := by
  simp only [checkFour, w2011_0, w2011_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2011 : Coverage 2011 2012 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases2011)
private theorem w2012_0 : checkWitness 2012 false false 82 = true := by decide +kernel
private theorem w2012_2 : checkWitness 2012 true false 82 = true := by decide +kernel
private theorem cases2012 : checkFour 2012 (82,0,82,0) = true := by
  simp only [checkFour, w2012_0, w2012_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2012 : Coverage 2012 2013 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2012)
private theorem w2013_0 : checkWitness 2013 false false 74 = true := by decide +kernel
private theorem w2013_2 : checkWitness 2013 true false 74 = true := by decide +kernel
private theorem cases2013 : checkFour 2013 (74,0,74,0) = true := by
  simp only [checkFour, w2013_0, w2013_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2013 : Coverage 2013 2014 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases2013)
private theorem w2014_0 : checkWitness 2014 false false 593 = true := by decide +kernel
private theorem w2014_1 : checkWitness 2014 false true 4677 = true := by decide +kernel
private theorem w2014_2 : checkWitness 2014 true false 593 = true := by decide +kernel
private theorem w2014_3 : checkWitness 2014 true true 4677 = true := by decide +kernel
private theorem cases2014 : checkFour 2014 (593,4677,593,4677) = true := by
  simp only [checkFour, w2014_0, w2014_1, w2014_2, w2014_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2014 : Coverage 2014 2015 := checkList_sound (ws:=[(593,4677,593,4677)]) (by simpa only [checkList, Bool.and_true] using cases2014)
private theorem w2015_0 : checkWitness 2015 false false 8846 = true := by decide +kernel
private theorem w2015_2 : checkWitness 2015 true false 8842 = true := by decide +kernel
private theorem cases2015 : checkFour 2015 (8846,0,8842,0) = true := by
  simp only [checkFour, w2015_0, w2015_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2015 : Coverage 2015 2016 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases2015)
theorem cover1984 : Coverage 1984 2016 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1984 one1985) (Coverage.join one1986 one1987)) (Coverage.join (Coverage.join one1988 one1989) (Coverage.join one1990 one1991))) (Coverage.join (Coverage.join (Coverage.join one1992 one1993) (Coverage.join one1994 one1995)) (Coverage.join (Coverage.join one1996 one1997) (Coverage.join one1998 one1999)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2000 one2001) (Coverage.join one2002 one2003)) (Coverage.join (Coverage.join one2004 one2005) (Coverage.join one2006 one2007))) (Coverage.join (Coverage.join (Coverage.join one2008 one2009) (Coverage.join one2010 one2011)) (Coverage.join (Coverage.join one2012 one2013) (Coverage.join one2014 one2015)))))
end NF181PA.Symbolic
