import NF181PAEightReverse
import NF181PARegisterHalting
import NF181PATapeCompiler
import NF182PAEightReverse
import NF182PARegisterHalting
import NF182PATapeKernel
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic
namespace NF181PA
theorem equivalent_in_PA_models_of_coverage {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
    (cover : Symbolic.Coverage 0 2971) :
    (V ⊧/![] H181) ↔ (V ⊧/![] NF182PA.H182) := by
  constructor
  · exact fun h => NF182PA.Symbolic.tape_of_register_halt
      (NF182PA.refutation_reaches_register_halt (Reverse.halting_implies_pool cover h))
  · exact fun h => Symbolic.tape_of_coverage cover
      (refutation_reaches_register_halt (NF182PA.Reverse.halting_implies_pool NF182PA.Symbolic.literal_table_coverage h))
end NF181PA
#print axioms NF181PA.equivalent_in_PA_models_of_coverage
