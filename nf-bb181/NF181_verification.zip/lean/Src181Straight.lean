module
public import Src181Commands
public import Src181RowPacking
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch.RegisterFields NF181PA.Packed NF181PA.Pool
namespace PA192.ModelSearch.Register181.Commands
set_option maxRecDepth 18000
set_option maxHeartbeats 12000000
set_option linter.unusedSimpArgs false
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
theorem emitPacked (f n t s c u v y d w : V) :
    let z := front8 (u+d) (v+y) c u (cantor t s)
    Reach (config (40:V) f (vector n t s c u v 0 0 (cantor y (cantor d w))))
      (config (2849:V) f (vector n (left z) (right z) c (u+d) (v+y) 0 0 w)) := by
  dsimp only
  rw [←emittedBody n t s c u v y d w,left_cantor,right_cantor]
  simpa only [emitAtom1,emitAtom0,Nat.cast_ofNat,add_comm d u] using commandEmit f n t s c u v y d w
end PA192.ModelSearch.Register181.Commands
#print axioms PA192.ModelSearch.Register181.Commands.emitPacked
