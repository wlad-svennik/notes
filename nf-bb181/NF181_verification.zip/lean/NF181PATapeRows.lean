import NF181PATapeFinite
import NF181PATapeSymbolic
import NF181Raw

/-! Compare a checked return with the expected canonical frame across every
one of the variable register and padding widths. -/
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.PhysicalModel PA192.ModelSearch.RegisterFields
namespace NF181PA.Symbolic
open Atom
open Gate (machine)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3600000
set_option maxRecDepth 12000

private theorem pushes_sound (d p : Bool) (k : Nat) (w : List Atom) (v : Nat → V) :
    word v (pushes d p k w) =
      (if p then pairs d (v k) (word v w) else rep d (v k) (word v w)) := by
  induction w generalizing d with
  | nil => cases p <;> rfl
  | cons a w ih =>
    cases a with
    | digit b =>
      by_cases h : d=b
      · subst b
        cases p
        · simp only [pushes,ite_true,word,ih]
          exact (iterate_succ (Execute.bit d) (v k) (word v w)).symm.trans
            (iterate_succ_left (Execute.bit d) (v k) (word v w))
        · simpa only [pushes,ite_true,ite_false,word,ih] using
             (pair_commute d (v k) (word v w)).symm
      · cases p <;> simp [pushes,h,word]
    | many b i => cases p <;> rfl
    | paired b i => cases p <;> rfl
    | tail i => cases p <;> rfl

theorem normal_sound (w : List Atom) (v : Nat → V) : word v (normal w) = word v w := by
  induction w with
  | nil => rfl
  | cons a w ih =>
    cases a with
    | digit b =>
      simp only [normal]
      split
      · rename_i h
        cases b <;> simp at h
        rw [h] at ih
        simp only [word] at ih ⊢
        rw [←ih]
        simp [Execute.bit]
      · exact congrArg (Execute.bit _) ih
    | tail i => rfl
    | many b k => simp [normal,pushes_sound,word,ih]
    | paired b k => simp [normal,pushes_sound,word,ih]

private theorem normalized_sound {c : Config} {q : State} {l r : List Atom}
    (h : normalized c = some (q,l,r)) (v : Nat → V) : c.val v = pack (q.val:V) (word v l) (word v r) := by
  rcases c with ⟨q0,d,s,o⟩
  cases d with
  | right => simp [normalized] at h; obtain ⟨rfl,rfl,rfl⟩ := h
             simp [Config.val,rays,normal_sound]
  | left =>
    cases s with
    | nil => contradiction
    | cons a s =>
      cases a with
      | digit b =>
        simp [normalized] at h; obtain ⟨rfl,rfl,rfl⟩ := h
        simp only [Config.val,rays,word,Execute.face_cons,normal_sound]
      | _ => contradiction

theorem returns_sound {c t : Config} (h : returns c t = true) (v : Nat → V) : c.val v=t.val v := by
  cases hc : normalized c with
  | none => simp [returns,hc] at h
  | some a =>
    cases ht : normalized t with
    | none => simp [returns,hc,ht] at h
    | some b =>
      have eq : a=b := by simpa [returns,hc,ht] using h
      subst b
      obtain ⟨q,l,r⟩ := a
      exact (normalized_sound hc v).trans (normalized_sound ht v).symm

theorem row_sound {pc : Nat} {cold pos : Bool} {fuel dg ds : Nat}
    (ok : checkRow pc cold pos fuel dg ds = true) (v : Nat → V) :
    if expectedHalt pc pos then
      ∃ t : V, Gate.onGate (iterate (rawStep machine) t ((signedFrame pc cold pos false 0 0).val v))
    else Execute.Path ((signedFrame pc cold pos false 0 0).val v) ((signedFrame pc cold pos true dg ds).val v) := by
  unfold checkRow at ok
  cases h : after fuel (signedFrame pc cold pos false 0 0) with
  | none => simp [h] at ok
  | some z =>
    obtain ⟨t,ht⟩ := after_sound h v
    cases e : expectedHalt pc pos
    · simp only [e,h,ite_false,Bool.false_eq_true] at ok ⊢
      exact ⟨t,ht.trans (returns_sound ok v)⟩
    · simp only [e,h,ite_true] at ok ⊢
      exact ⟨t,by rw [ht]; exact atGate_sound ok v⟩

#print axioms row_sound
end NF181PA.Symbolic
