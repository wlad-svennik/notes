module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

private theorem site0991Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 991 f r x y z) (slots160.atReg 994 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 991 3 994 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 991 994 992 f r (row_of_literal 991 _ (by decide) RawRows.raw0991))
    (slots160.pos_x 991 994 992 f r (row_of_literal 991 _ (by decide) RawRows.raw0991))
    (slots160.inc_y 992 993 f r (row_of_literal 992 _ (by decide) RawRows.raw0992) (Or.inl (by decide)))
    (slots160.jump 993 991 f r (row_of_literal 993 _ (by decide) RawRows.raw0993))

theorem site0991 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((991:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((994:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0991Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0994Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 994 f r x y z) (slots210.atReg 997 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 994 3 997 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 994 997 995 f r (row_of_literal 994 _ (by decide) RawRows.raw0994))
    (slots210.pos_x 994 997 995 f r (row_of_literal 994 _ (by decide) RawRows.raw0994))
    (slots210.inc_y 995 996 f r (row_of_literal 995 _ (by decide) RawRows.raw0995) (Or.inl (by decide)))
    (slots210.jump 996 994 f r (row_of_literal 996 _ (by decide) RawRows.raw0996))

theorem site0994 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((994:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((997:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0994Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0997Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 997 f r x y z) (slots617.atReg 1007 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 997 10 1007 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 997 1001 998 f r (row_of_literal 997 _ (by decide) RawRows.raw0997))
    (slots617.pos_y 997 1001 998 f r (row_of_literal 997 _ (by decide) RawRows.raw0997))
    (slots617.inc_z 998 999 f r (row_of_literal 998 _ (by decide) RawRows.raw0998) (Or.inl (by decide)))
    (slots617.inc_x 999 1000 f r (row_of_literal 999 _ (by decide) RawRows.raw0999) (Or.inl (by decide)))
    (slots617.jump 1000 997 f r (row_of_literal 1000 _ (by decide) RawRows.raw1000))
    (slots617.zero_x 1001 1007 1002 f r (row_of_literal 1001 _ (by decide) RawRows.raw1001))
    (slots617.pos_x 1001 1007 1002 f r (row_of_literal 1001 _ (by decide) RawRows.raw1001))
    (slots617.inc_z 1002 1003 f r (row_of_literal 1002 _ (by decide) RawRows.raw1002) (Or.inl (by decide)))
    (slots617.zero_x 1003 1006 1004 f r (row_of_literal 1003 _ (by decide) RawRows.raw1003))
    (slots617.pos_x 1003 1006 1004 f r (row_of_literal 1003 _ (by decide) RawRows.raw1003))
    (slots617.inc_y 1004 1005 f r (row_of_literal 1004 _ (by decide) RawRows.raw1004) (Or.inl (by decide)))
    (slots617.jump 1005 1003 f r (row_of_literal 1005 _ (by decide) RawRows.raw1005))
    (slots617.jump 1006 997 f r (row_of_literal 1006 _ (by decide) RawRows.raw1006))

theorem site0997 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((997:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1007:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0997Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1007Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1007 f r x y z) (slots720.atReg 1010 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1007 3 1010 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1007 1010 1008 f r (row_of_literal 1007 _ (by decide) RawRows.raw1007))
    (slots720.pos_x 1007 1010 1008 f r (row_of_literal 1007 _ (by decide) RawRows.raw1007))
    (slots720.inc_y 1008 1009 f r (row_of_literal 1008 _ (by decide) RawRows.raw1008) (Or.inl (by decide)))
    (slots720.jump 1009 1007 f r (row_of_literal 1009 _ (by decide) RawRows.raw1009))

theorem site1007 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1007:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1010:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1007Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1010Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1010 f r x y z) (slots561.atReg 1014 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1010 4 1014 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1010 1014 1011 f r (row_of_literal 1010 _ (by decide) RawRows.raw1010))
    (slots561.pos_x 1010 1014 1011 f r (row_of_literal 1010 _ (by decide) RawRows.raw1010))
    (slots561.inc_y 1011 1012 f r (row_of_literal 1011 _ (by decide) RawRows.raw1011) (Or.inl (by decide)))
    (slots561.inc_z 1012 1013 f r (row_of_literal 1012 _ (by decide) RawRows.raw1012) (Or.inl (by decide)))
    (slots561.jump 1013 1010 f r (row_of_literal 1013 _ (by decide) RawRows.raw1013))

theorem site1010 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1010:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1014:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1010Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1014Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1014 f r x y z) (slots650.atReg 1017 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1014 3 1017 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1014 1017 1015 f r (row_of_literal 1014 _ (by decide) RawRows.raw1014))
    (slots650.pos_x 1014 1017 1015 f r (row_of_literal 1014 _ (by decide) RawRows.raw1014))
    (slots650.inc_y 1015 1016 f r (row_of_literal 1015 _ (by decide) RawRows.raw1015) (Or.inl (by decide)))
    (slots650.jump 1016 1014 f r (row_of_literal 1016 _ (by decide) RawRows.raw1016))

theorem site1014 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1014:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1017:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1014Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1017Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1017 f r x y z) (slots267.atReg 1025 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1017 8 1025 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1017 1025 1018 f r (row_of_literal 1017 _ (by decide) RawRows.raw1017))
    (slots267.pos_x 1017 1025 1018 f r (row_of_literal 1017 _ (by decide) RawRows.raw1017))
    (slots267.inc_z 1018 1019 f r (row_of_literal 1018 _ (by decide) RawRows.raw1018) (Or.inl (by decide)))
    (slots267.zero_y 1019 1021 1020 f r (row_of_literal 1019 _ (by decide) RawRows.raw1019))
    (slots267.pos_y 1019 1021 1020 f r (row_of_literal 1019 _ (by decide) RawRows.raw1019))
    (slots267.jump 1020 1024 f r (row_of_literal 1020 _ (by decide) RawRows.raw1020))
    (slots267.zero_z 1021 1024 1022 f r (row_of_literal 1021 _ (by decide) RawRows.raw1021))
    (slots267.pos_z 1021 1024 1022 f r (row_of_literal 1021 _ (by decide) RawRows.raw1021))
    (slots267.inc_y 1022 1023 f r (row_of_literal 1022 _ (by decide) RawRows.raw1022) (Or.inl (by decide)))
    (slots267.jump 1023 1021 f r (row_of_literal 1023 _ (by decide) RawRows.raw1023))
    (slots267.jump 1024 1017 f r (row_of_literal 1024 _ (by decide) RawRows.raw1024))

theorem site1017 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1017:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1025:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1017Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1025Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1025 f r x y z) (slots720.atReg 1028 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1025 3 1028 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1025 1028 1026 f r (row_of_literal 1025 _ (by decide) RawRows.raw1025))
    (slots720.pos_x 1025 1028 1026 f r (row_of_literal 1025 _ (by decide) RawRows.raw1025))
    (slots720.inc_y 1026 1027 f r (row_of_literal 1026 _ (by decide) RawRows.raw1026) (Or.inl (by decide)))
    (slots720.jump 1027 1025 f r (row_of_literal 1027 _ (by decide) RawRows.raw1027))

theorem site1025 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1025:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1028:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1025Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1028Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1028 f r x y z) (slots617.atReg 1038 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1028 10 1038 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1028 1032 1029 f r (row_of_literal 1028 _ (by decide) RawRows.raw1028))
    (slots617.pos_y 1028 1032 1029 f r (row_of_literal 1028 _ (by decide) RawRows.raw1028))
    (slots617.inc_z 1029 1030 f r (row_of_literal 1029 _ (by decide) RawRows.raw1029) (Or.inl (by decide)))
    (slots617.inc_x 1030 1031 f r (row_of_literal 1030 _ (by decide) RawRows.raw1030) (Or.inl (by decide)))
    (slots617.jump 1031 1028 f r (row_of_literal 1031 _ (by decide) RawRows.raw1031))
    (slots617.zero_x 1032 1038 1033 f r (row_of_literal 1032 _ (by decide) RawRows.raw1032))
    (slots617.pos_x 1032 1038 1033 f r (row_of_literal 1032 _ (by decide) RawRows.raw1032))
    (slots617.inc_z 1033 1034 f r (row_of_literal 1033 _ (by decide) RawRows.raw1033) (Or.inl (by decide)))
    (slots617.zero_x 1034 1037 1035 f r (row_of_literal 1034 _ (by decide) RawRows.raw1034))
    (slots617.pos_x 1034 1037 1035 f r (row_of_literal 1034 _ (by decide) RawRows.raw1034))
    (slots617.inc_y 1035 1036 f r (row_of_literal 1035 _ (by decide) RawRows.raw1035) (Or.inl (by decide)))
    (slots617.jump 1036 1034 f r (row_of_literal 1036 _ (by decide) RawRows.raw1036))
    (slots617.jump 1037 1028 f r (row_of_literal 1037 _ (by decide) RawRows.raw1037))

theorem site1028 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1028:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1038:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1028Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1038Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1038 f r x y z) (slots710.atReg 1042 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1038 4 1042 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1038 1042 1039 f r (row_of_literal 1038 _ (by decide) RawRows.raw1038))
    (slots710.pos_x 1038 1042 1039 f r (row_of_literal 1038 _ (by decide) RawRows.raw1038))
    (slots710.inc_y 1039 1040 f r (row_of_literal 1039 _ (by decide) RawRows.raw1039) (Or.inl (by decide)))
    (slots710.inc_y 1040 1041 f r (row_of_literal 1040 _ (by decide) RawRows.raw1040) (Or.inl (by decide)))
    (slots710.jump 1041 1038 f r (row_of_literal 1041 _ (by decide) RawRows.raw1041))

theorem site1038 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1038:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1042:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1038Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1042 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1042:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1043:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1042 _ (row_of_literal 1042 _ (by decide) RawRows.raw1042)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1043Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1043 f r x y z) (slots160.atReg 1046 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1043 3 1046 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1043 1046 1044 f r (row_of_literal 1043 _ (by decide) RawRows.raw1043))
    (slots160.pos_x 1043 1046 1044 f r (row_of_literal 1043 _ (by decide) RawRows.raw1043))
    (slots160.inc_y 1044 1045 f r (row_of_literal 1044 _ (by decide) RawRows.raw1044) (Or.inl (by decide)))
    (slots160.jump 1045 1043 f r (row_of_literal 1045 _ (by decide) RawRows.raw1045))

theorem site1043 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1043:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1046:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1043Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1046Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1046 f r x y z) (slots210.atReg 1049 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1046 3 1049 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1046 1049 1047 f r (row_of_literal 1046 _ (by decide) RawRows.raw1046))
    (slots210.pos_x 1046 1049 1047 f r (row_of_literal 1046 _ (by decide) RawRows.raw1046))
    (slots210.inc_y 1047 1048 f r (row_of_literal 1047 _ (by decide) RawRows.raw1047) (Or.inl (by decide)))
    (slots210.jump 1048 1046 f r (row_of_literal 1048 _ (by decide) RawRows.raw1048))

theorem site1046 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1046:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1049:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1046Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1049Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1049 f r x y z) (slots617.atReg 1059 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1049 10 1059 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1049 1053 1050 f r (row_of_literal 1049 _ (by decide) RawRows.raw1049))
    (slots617.pos_y 1049 1053 1050 f r (row_of_literal 1049 _ (by decide) RawRows.raw1049))
    (slots617.inc_z 1050 1051 f r (row_of_literal 1050 _ (by decide) RawRows.raw1050) (Or.inl (by decide)))
    (slots617.inc_x 1051 1052 f r (row_of_literal 1051 _ (by decide) RawRows.raw1051) (Or.inl (by decide)))
    (slots617.jump 1052 1049 f r (row_of_literal 1052 _ (by decide) RawRows.raw1052))
    (slots617.zero_x 1053 1059 1054 f r (row_of_literal 1053 _ (by decide) RawRows.raw1053))
    (slots617.pos_x 1053 1059 1054 f r (row_of_literal 1053 _ (by decide) RawRows.raw1053))
    (slots617.inc_z 1054 1055 f r (row_of_literal 1054 _ (by decide) RawRows.raw1054) (Or.inl (by decide)))
    (slots617.zero_x 1055 1058 1056 f r (row_of_literal 1055 _ (by decide) RawRows.raw1055))
    (slots617.pos_x 1055 1058 1056 f r (row_of_literal 1055 _ (by decide) RawRows.raw1055))
    (slots617.inc_y 1056 1057 f r (row_of_literal 1056 _ (by decide) RawRows.raw1056) (Or.inl (by decide)))
    (slots617.jump 1057 1055 f r (row_of_literal 1057 _ (by decide) RawRows.raw1057))
    (slots617.jump 1058 1049 f r (row_of_literal 1058 _ (by decide) RawRows.raw1058))

theorem site1049 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1049:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1059:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1049Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1059Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1059 f r x y z) (slots720.atReg 1062 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1059 3 1062 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1059 1062 1060 f r (row_of_literal 1059 _ (by decide) RawRows.raw1059))
    (slots720.pos_x 1059 1062 1060 f r (row_of_literal 1059 _ (by decide) RawRows.raw1059))
    (slots720.inc_y 1060 1061 f r (row_of_literal 1060 _ (by decide) RawRows.raw1060) (Or.inl (by decide)))
    (slots720.jump 1061 1059 f r (row_of_literal 1061 _ (by decide) RawRows.raw1061))

theorem site1059 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1059:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1062:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1059Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1062Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 1062 f r x y z) (slots361.atReg 1066 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 1062 4 1066 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 1062 1066 1063 f r (row_of_literal 1062 _ (by decide) RawRows.raw1062))
    (slots361.pos_x 1062 1066 1063 f r (row_of_literal 1062 _ (by decide) RawRows.raw1062))
    (slots361.inc_y 1063 1064 f r (row_of_literal 1063 _ (by decide) RawRows.raw1063) (Or.inl (by decide)))
    (slots361.inc_z 1064 1065 f r (row_of_literal 1064 _ (by decide) RawRows.raw1064) (Or.inl (by decide)))
    (slots361.jump 1065 1062 f r (row_of_literal 1065 _ (by decide) RawRows.raw1065))

theorem site1062 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1062:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1066:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site1062Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site1066Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 1066 f r x y z) (slots630.atReg 1069 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 1066 3 1069 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 1066 1069 1067 f r (row_of_literal 1066 _ (by decide) RawRows.raw1066))
    (slots630.pos_x 1066 1069 1067 f r (row_of_literal 1066 _ (by decide) RawRows.raw1066))
    (slots630.inc_y 1067 1068 f r (row_of_literal 1067 _ (by decide) RawRows.raw1067) (Or.inl (by decide)))
    (slots630.jump 1068 1066 f r (row_of_literal 1068 _ (by decide) RawRows.raw1068))

theorem site1066 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1066:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1069:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site1066Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site1069Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1069 f r x y z) (slots160.atReg 1072 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1069 3 1072 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1069 1072 1070 f r (row_of_literal 1069 _ (by decide) RawRows.raw1069))
    (slots160.pos_x 1069 1072 1070 f r (row_of_literal 1069 _ (by decide) RawRows.raw1069))
    (slots160.inc_y 1070 1071 f r (row_of_literal 1070 _ (by decide) RawRows.raw1070) (Or.inl (by decide)))
    (slots160.jump 1071 1069 f r (row_of_literal 1071 _ (by decide) RawRows.raw1071))

theorem site1069 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1069:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1072:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1069Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1072Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1072 f r x y z) (slots210.atReg 1075 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1072 3 1075 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1072 1075 1073 f r (row_of_literal 1072 _ (by decide) RawRows.raw1072))
    (slots210.pos_x 1072 1075 1073 f r (row_of_literal 1072 _ (by decide) RawRows.raw1072))
    (slots210.inc_y 1073 1074 f r (row_of_literal 1073 _ (by decide) RawRows.raw1073) (Or.inl (by decide)))
    (slots210.jump 1074 1072 f r (row_of_literal 1074 _ (by decide) RawRows.raw1074))

theorem site1072 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1072:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1075:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1072Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1075Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1075 f r x y z) (slots617.atReg 1085 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1075 10 1085 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1075 1079 1076 f r (row_of_literal 1075 _ (by decide) RawRows.raw1075))
    (slots617.pos_y 1075 1079 1076 f r (row_of_literal 1075 _ (by decide) RawRows.raw1075))
    (slots617.inc_z 1076 1077 f r (row_of_literal 1076 _ (by decide) RawRows.raw1076) (Or.inl (by decide)))
    (slots617.inc_x 1077 1078 f r (row_of_literal 1077 _ (by decide) RawRows.raw1077) (Or.inl (by decide)))
    (slots617.jump 1078 1075 f r (row_of_literal 1078 _ (by decide) RawRows.raw1078))
    (slots617.zero_x 1079 1085 1080 f r (row_of_literal 1079 _ (by decide) RawRows.raw1079))
    (slots617.pos_x 1079 1085 1080 f r (row_of_literal 1079 _ (by decide) RawRows.raw1079))
    (slots617.inc_z 1080 1081 f r (row_of_literal 1080 _ (by decide) RawRows.raw1080) (Or.inl (by decide)))
    (slots617.zero_x 1081 1084 1082 f r (row_of_literal 1081 _ (by decide) RawRows.raw1081))
    (slots617.pos_x 1081 1084 1082 f r (row_of_literal 1081 _ (by decide) RawRows.raw1081))
    (slots617.inc_y 1082 1083 f r (row_of_literal 1082 _ (by decide) RawRows.raw1082) (Or.inl (by decide)))
    (slots617.jump 1083 1081 f r (row_of_literal 1083 _ (by decide) RawRows.raw1083))
    (slots617.jump 1084 1075 f r (row_of_literal 1084 _ (by decide) RawRows.raw1084))

theorem site1075 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1075:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1085:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1075Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1085Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1085 f r x y z) (slots720.atReg 1088 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1085 3 1088 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1085 1088 1086 f r (row_of_literal 1085 _ (by decide) RawRows.raw1085))
    (slots720.pos_x 1085 1088 1086 f r (row_of_literal 1085 _ (by decide) RawRows.raw1085))
    (slots720.inc_y 1086 1087 f r (row_of_literal 1086 _ (by decide) RawRows.raw1086) (Or.inl (by decide)))
    (slots720.jump 1087 1085 f r (row_of_literal 1087 _ (by decide) RawRows.raw1087))

theorem site1085 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1085:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1088:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1085Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1088Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1088 f r x y z) (slots561.atReg 1092 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1088 4 1092 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1088 1092 1089 f r (row_of_literal 1088 _ (by decide) RawRows.raw1088))
    (slots561.pos_x 1088 1092 1089 f r (row_of_literal 1088 _ (by decide) RawRows.raw1088))
    (slots561.inc_y 1089 1090 f r (row_of_literal 1089 _ (by decide) RawRows.raw1089) (Or.inl (by decide)))
    (slots561.inc_z 1090 1091 f r (row_of_literal 1090 _ (by decide) RawRows.raw1090) (Or.inl (by decide)))
    (slots561.jump 1091 1088 f r (row_of_literal 1091 _ (by decide) RawRows.raw1091))

theorem site1088 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1088:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1092:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1088Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1092Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1092 f r x y z) (slots650.atReg 1095 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1092 3 1095 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1092 1095 1093 f r (row_of_literal 1092 _ (by decide) RawRows.raw1092))
    (slots650.pos_x 1092 1095 1093 f r (row_of_literal 1092 _ (by decide) RawRows.raw1092))
    (slots650.inc_y 1093 1094 f r (row_of_literal 1093 _ (by decide) RawRows.raw1093) (Or.inl (by decide)))
    (slots650.jump 1094 1092 f r (row_of_literal 1094 _ (by decide) RawRows.raw1094))

theorem site1092 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1092:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1095:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1092Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1095Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1095 f r x y z) (slots160.atReg 1098 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1095 3 1098 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1095 1098 1096 f r (row_of_literal 1095 _ (by decide) RawRows.raw1095))
    (slots160.pos_x 1095 1098 1096 f r (row_of_literal 1095 _ (by decide) RawRows.raw1095))
    (slots160.inc_y 1096 1097 f r (row_of_literal 1096 _ (by decide) RawRows.raw1096) (Or.inl (by decide)))
    (slots160.jump 1097 1095 f r (row_of_literal 1097 _ (by decide) RawRows.raw1097))

theorem site1095 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1095:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1098:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1095Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1098Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1098 f r x y z) (slots210.atReg 1101 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1098 3 1101 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1098 1101 1099 f r (row_of_literal 1098 _ (by decide) RawRows.raw1098))
    (slots210.pos_x 1098 1101 1099 f r (row_of_literal 1098 _ (by decide) RawRows.raw1098))
    (slots210.inc_y 1099 1100 f r (row_of_literal 1099 _ (by decide) RawRows.raw1099) (Or.inl (by decide)))
    (slots210.jump 1100 1098 f r (row_of_literal 1100 _ (by decide) RawRows.raw1100))

theorem site1098 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1098:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1101:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1098Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1101Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1101 f r x y z) (slots617.atReg 1111 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1101 10 1111 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1101 1105 1102 f r (row_of_literal 1101 _ (by decide) RawRows.raw1101))
    (slots617.pos_y 1101 1105 1102 f r (row_of_literal 1101 _ (by decide) RawRows.raw1101))
    (slots617.inc_z 1102 1103 f r (row_of_literal 1102 _ (by decide) RawRows.raw1102) (Or.inl (by decide)))
    (slots617.inc_x 1103 1104 f r (row_of_literal 1103 _ (by decide) RawRows.raw1103) (Or.inl (by decide)))
    (slots617.jump 1104 1101 f r (row_of_literal 1104 _ (by decide) RawRows.raw1104))
    (slots617.zero_x 1105 1111 1106 f r (row_of_literal 1105 _ (by decide) RawRows.raw1105))
    (slots617.pos_x 1105 1111 1106 f r (row_of_literal 1105 _ (by decide) RawRows.raw1105))
    (slots617.inc_z 1106 1107 f r (row_of_literal 1106 _ (by decide) RawRows.raw1106) (Or.inl (by decide)))
    (slots617.zero_x 1107 1110 1108 f r (row_of_literal 1107 _ (by decide) RawRows.raw1107))
    (slots617.pos_x 1107 1110 1108 f r (row_of_literal 1107 _ (by decide) RawRows.raw1107))
    (slots617.inc_y 1108 1109 f r (row_of_literal 1108 _ (by decide) RawRows.raw1108) (Or.inl (by decide)))
    (slots617.jump 1109 1107 f r (row_of_literal 1109 _ (by decide) RawRows.raw1109))
    (slots617.jump 1110 1101 f r (row_of_literal 1110 _ (by decide) RawRows.raw1110))

theorem site1101 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1101:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1111:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1101Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1111Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1111 f r x y z) (slots720.atReg 1114 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1111 3 1114 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1111 1114 1112 f r (row_of_literal 1111 _ (by decide) RawRows.raw1111))
    (slots720.pos_x 1111 1114 1112 f r (row_of_literal 1111 _ (by decide) RawRows.raw1111))
    (slots720.inc_y 1112 1113 f r (row_of_literal 1112 _ (by decide) RawRows.raw1112) (Or.inl (by decide)))
    (slots720.jump 1113 1111 f r (row_of_literal 1113 _ (by decide) RawRows.raw1113))

theorem site1111 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1111:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1114:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1111Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1114Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1114 f r x y z) (slots561.atReg 1118 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1114 4 1118 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1114 1118 1115 f r (row_of_literal 1114 _ (by decide) RawRows.raw1114))
    (slots561.pos_x 1114 1118 1115 f r (row_of_literal 1114 _ (by decide) RawRows.raw1114))
    (slots561.inc_y 1115 1116 f r (row_of_literal 1115 _ (by decide) RawRows.raw1115) (Or.inl (by decide)))
    (slots561.inc_z 1116 1117 f r (row_of_literal 1116 _ (by decide) RawRows.raw1116) (Or.inl (by decide)))
    (slots561.jump 1117 1114 f r (row_of_literal 1117 _ (by decide) RawRows.raw1117))

theorem site1114 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1114:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1118:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1114Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1118Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1118 f r x y z) (slots650.atReg 1121 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1118 3 1121 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1118 1121 1119 f r (row_of_literal 1118 _ (by decide) RawRows.raw1118))
    (slots650.pos_x 1118 1121 1119 f r (row_of_literal 1118 _ (by decide) RawRows.raw1118))
    (slots650.inc_y 1119 1120 f r (row_of_literal 1119 _ (by decide) RawRows.raw1119) (Or.inl (by decide)))
    (slots650.jump 1120 1118 f r (row_of_literal 1120 _ (by decide) RawRows.raw1120))

theorem site1118 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1118:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1121:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1118Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1121Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1121 f r x y z) (slots267.atReg 1129 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1121 8 1129 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1121 1129 1122 f r (row_of_literal 1121 _ (by decide) RawRows.raw1121))
    (slots267.pos_x 1121 1129 1122 f r (row_of_literal 1121 _ (by decide) RawRows.raw1121))
    (slots267.inc_z 1122 1123 f r (row_of_literal 1122 _ (by decide) RawRows.raw1122) (Or.inl (by decide)))
    (slots267.zero_y 1123 1125 1124 f r (row_of_literal 1123 _ (by decide) RawRows.raw1123))
    (slots267.pos_y 1123 1125 1124 f r (row_of_literal 1123 _ (by decide) RawRows.raw1123))
    (slots267.jump 1124 1128 f r (row_of_literal 1124 _ (by decide) RawRows.raw1124))
    (slots267.zero_z 1125 1128 1126 f r (row_of_literal 1125 _ (by decide) RawRows.raw1125))
    (slots267.pos_z 1125 1128 1126 f r (row_of_literal 1125 _ (by decide) RawRows.raw1125))
    (slots267.inc_y 1126 1127 f r (row_of_literal 1126 _ (by decide) RawRows.raw1126) (Or.inl (by decide)))
    (slots267.jump 1127 1125 f r (row_of_literal 1127 _ (by decide) RawRows.raw1127))
    (slots267.jump 1128 1121 f r (row_of_literal 1128 _ (by decide) RawRows.raw1128))

theorem site1121 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1121:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1129:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1121Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1129Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1129 f r x y z) (slots720.atReg 1132 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1129 3 1132 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1129 1132 1130 f r (row_of_literal 1129 _ (by decide) RawRows.raw1129))
    (slots720.pos_x 1129 1132 1130 f r (row_of_literal 1129 _ (by decide) RawRows.raw1129))
    (slots720.inc_y 1130 1131 f r (row_of_literal 1130 _ (by decide) RawRows.raw1130) (Or.inl (by decide)))
    (slots720.jump 1131 1129 f r (row_of_literal 1131 _ (by decide) RawRows.raw1131))

theorem site1129 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1129:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1132:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1129Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1132Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1132 f r x y z) (slots617.atReg 1142 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1132 10 1142 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1132 1136 1133 f r (row_of_literal 1132 _ (by decide) RawRows.raw1132))
    (slots617.pos_y 1132 1136 1133 f r (row_of_literal 1132 _ (by decide) RawRows.raw1132))
    (slots617.inc_z 1133 1134 f r (row_of_literal 1133 _ (by decide) RawRows.raw1133) (Or.inl (by decide)))
    (slots617.inc_x 1134 1135 f r (row_of_literal 1134 _ (by decide) RawRows.raw1134) (Or.inl (by decide)))
    (slots617.jump 1135 1132 f r (row_of_literal 1135 _ (by decide) RawRows.raw1135))
    (slots617.zero_x 1136 1142 1137 f r (row_of_literal 1136 _ (by decide) RawRows.raw1136))
    (slots617.pos_x 1136 1142 1137 f r (row_of_literal 1136 _ (by decide) RawRows.raw1136))
    (slots617.inc_z 1137 1138 f r (row_of_literal 1137 _ (by decide) RawRows.raw1137) (Or.inl (by decide)))
    (slots617.zero_x 1138 1141 1139 f r (row_of_literal 1138 _ (by decide) RawRows.raw1138))
    (slots617.pos_x 1138 1141 1139 f r (row_of_literal 1138 _ (by decide) RawRows.raw1138))
    (slots617.inc_y 1139 1140 f r (row_of_literal 1139 _ (by decide) RawRows.raw1139) (Or.inl (by decide)))
    (slots617.jump 1140 1138 f r (row_of_literal 1140 _ (by decide) RawRows.raw1140))
    (slots617.jump 1141 1132 f r (row_of_literal 1141 _ (by decide) RawRows.raw1141))

theorem site1132 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1132:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1142:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1132Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1142Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1142 f r x y z) (slots710.atReg 1146 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1142 4 1146 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1142 1146 1143 f r (row_of_literal 1142 _ (by decide) RawRows.raw1142))
    (slots710.pos_x 1142 1146 1143 f r (row_of_literal 1142 _ (by decide) RawRows.raw1142))
    (slots710.inc_y 1143 1144 f r (row_of_literal 1143 _ (by decide) RawRows.raw1143) (Or.inl (by decide)))
    (slots710.inc_y 1144 1145 f r (row_of_literal 1144 _ (by decide) RawRows.raw1144) (Or.inl (by decide)))
    (slots710.jump 1145 1142 f r (row_of_literal 1145 _ (by decide) RawRows.raw1145))

theorem site1142 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1142:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1146:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1142Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1146 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1146:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1147:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1146 _ (row_of_literal 1146 _ (by decide) RawRows.raw1146)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site1147 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1147:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1148:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1147 _ (row_of_literal 1147 _ (by decide) RawRows.raw1147)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1148Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1148 f r x y z) (slots267.atReg 1156 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1148 8 1156 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1148 1156 1149 f r (row_of_literal 1148 _ (by decide) RawRows.raw1148))
    (slots267.pos_x 1148 1156 1149 f r (row_of_literal 1148 _ (by decide) RawRows.raw1148))
    (slots267.inc_z 1149 1150 f r (row_of_literal 1149 _ (by decide) RawRows.raw1149) (Or.inl (by decide)))
    (slots267.zero_y 1150 1152 1151 f r (row_of_literal 1150 _ (by decide) RawRows.raw1150))
    (slots267.pos_y 1150 1152 1151 f r (row_of_literal 1150 _ (by decide) RawRows.raw1150))
    (slots267.jump 1151 1155 f r (row_of_literal 1151 _ (by decide) RawRows.raw1151))
    (slots267.zero_z 1152 1155 1153 f r (row_of_literal 1152 _ (by decide) RawRows.raw1152))
    (slots267.pos_z 1152 1155 1153 f r (row_of_literal 1152 _ (by decide) RawRows.raw1152))
    (slots267.inc_y 1153 1154 f r (row_of_literal 1153 _ (by decide) RawRows.raw1153) (Or.inl (by decide)))
    (slots267.jump 1154 1152 f r (row_of_literal 1154 _ (by decide) RawRows.raw1154))
    (slots267.jump 1155 1148 f r (row_of_literal 1155 _ (by decide) RawRows.raw1155))

theorem site1148 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1148:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1156:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1148Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site1156Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1156 f r x y z) (slots720.atReg 1159 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1156 3 1159 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1156 1159 1157 f r (row_of_literal 1156 _ (by decide) RawRows.raw1156))
    (slots720.pos_x 1156 1159 1157 f r (row_of_literal 1156 _ (by decide) RawRows.raw1156))
    (slots720.inc_y 1157 1158 f r (row_of_literal 1157 _ (by decide) RawRows.raw1157) (Or.inl (by decide)))
    (slots720.jump 1158 1156 f r (row_of_literal 1158 _ (by decide) RawRows.raw1158))

theorem site1156 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1156:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1159:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1156Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1159Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1159 f r x y z) (slots617.atReg 1169 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1159 10 1169 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1159 1163 1160 f r (row_of_literal 1159 _ (by decide) RawRows.raw1159))
    (slots617.pos_y 1159 1163 1160 f r (row_of_literal 1159 _ (by decide) RawRows.raw1159))
    (slots617.inc_z 1160 1161 f r (row_of_literal 1160 _ (by decide) RawRows.raw1160) (Or.inl (by decide)))
    (slots617.inc_x 1161 1162 f r (row_of_literal 1161 _ (by decide) RawRows.raw1161) (Or.inl (by decide)))
    (slots617.jump 1162 1159 f r (row_of_literal 1162 _ (by decide) RawRows.raw1162))
    (slots617.zero_x 1163 1169 1164 f r (row_of_literal 1163 _ (by decide) RawRows.raw1163))
    (slots617.pos_x 1163 1169 1164 f r (row_of_literal 1163 _ (by decide) RawRows.raw1163))
    (slots617.inc_z 1164 1165 f r (row_of_literal 1164 _ (by decide) RawRows.raw1164) (Or.inl (by decide)))
    (slots617.zero_x 1165 1168 1166 f r (row_of_literal 1165 _ (by decide) RawRows.raw1165))
    (slots617.pos_x 1165 1168 1166 f r (row_of_literal 1165 _ (by decide) RawRows.raw1165))
    (slots617.inc_y 1166 1167 f r (row_of_literal 1166 _ (by decide) RawRows.raw1166) (Or.inl (by decide)))
    (slots617.jump 1167 1165 f r (row_of_literal 1167 _ (by decide) RawRows.raw1167))
    (slots617.jump 1168 1159 f r (row_of_literal 1168 _ (by decide) RawRows.raw1168))

theorem site1159 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1159:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1169:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1159Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1169Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 1169 f r x y z) (slots710.atReg 1173 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 1169 4 1173 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 1169 1173 1170 f r (row_of_literal 1169 _ (by decide) RawRows.raw1169))
    (slots710.pos_x 1169 1173 1170 f r (row_of_literal 1169 _ (by decide) RawRows.raw1169))
    (slots710.inc_y 1170 1171 f r (row_of_literal 1170 _ (by decide) RawRows.raw1170) (Or.inl (by decide)))
    (slots710.inc_y 1171 1172 f r (row_of_literal 1171 _ (by decide) RawRows.raw1171) (Or.inl (by decide)))
    (slots710.jump 1172 1169 f r (row_of_literal 1172 _ (by decide) RawRows.raw1172))

theorem site1169 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1169:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1173:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site1169Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


theorem site1173 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1173:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1174:Nat):V) f (vector r0 (r1+1) r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1173 _ (row_of_literal 1173 _ (by decide) RawRows.raw1173)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site1174Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1174 f r x y z) (slots160.atReg 1177 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1174 3 1177 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1174 1177 1175 f r (row_of_literal 1174 _ (by decide) RawRows.raw1174))
    (slots160.pos_x 1174 1177 1175 f r (row_of_literal 1174 _ (by decide) RawRows.raw1174))
    (slots160.inc_y 1175 1176 f r (row_of_literal 1175 _ (by decide) RawRows.raw1175) (Or.inl (by decide)))
    (slots160.jump 1176 1174 f r (row_of_literal 1176 _ (by decide) RawRows.raw1176))

theorem site1174 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1174:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1177:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1174Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1177Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1177 f r x y z) (slots210.atReg 1180 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1177 3 1180 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1177 1180 1178 f r (row_of_literal 1177 _ (by decide) RawRows.raw1177))
    (slots210.pos_x 1177 1180 1178 f r (row_of_literal 1177 _ (by decide) RawRows.raw1177))
    (slots210.inc_y 1178 1179 f r (row_of_literal 1178 _ (by decide) RawRows.raw1178) (Or.inl (by decide)))
    (slots210.jump 1179 1177 f r (row_of_literal 1179 _ (by decide) RawRows.raw1179))

theorem site1177 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1177:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1180:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1177Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1180Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1180 f r x y z) (slots617.atReg 1190 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1180 10 1190 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1180 1184 1181 f r (row_of_literal 1180 _ (by decide) RawRows.raw1180))
    (slots617.pos_y 1180 1184 1181 f r (row_of_literal 1180 _ (by decide) RawRows.raw1180))
    (slots617.inc_z 1181 1182 f r (row_of_literal 1181 _ (by decide) RawRows.raw1181) (Or.inl (by decide)))
    (slots617.inc_x 1182 1183 f r (row_of_literal 1182 _ (by decide) RawRows.raw1182) (Or.inl (by decide)))
    (slots617.jump 1183 1180 f r (row_of_literal 1183 _ (by decide) RawRows.raw1183))
    (slots617.zero_x 1184 1190 1185 f r (row_of_literal 1184 _ (by decide) RawRows.raw1184))
    (slots617.pos_x 1184 1190 1185 f r (row_of_literal 1184 _ (by decide) RawRows.raw1184))
    (slots617.inc_z 1185 1186 f r (row_of_literal 1185 _ (by decide) RawRows.raw1185) (Or.inl (by decide)))
    (slots617.zero_x 1186 1189 1187 f r (row_of_literal 1186 _ (by decide) RawRows.raw1186))
    (slots617.pos_x 1186 1189 1187 f r (row_of_literal 1186 _ (by decide) RawRows.raw1186))
    (slots617.inc_y 1187 1188 f r (row_of_literal 1187 _ (by decide) RawRows.raw1187) (Or.inl (by decide)))
    (slots617.jump 1188 1186 f r (row_of_literal 1188 _ (by decide) RawRows.raw1188))
    (slots617.jump 1189 1180 f r (row_of_literal 1189 _ (by decide) RawRows.raw1189))

theorem site1180 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1180:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1190:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1180Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1190Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1190 f r x y z) (slots720.atReg 1193 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1190 3 1193 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1190 1193 1191 f r (row_of_literal 1190 _ (by decide) RawRows.raw1190))
    (slots720.pos_x 1190 1193 1191 f r (row_of_literal 1190 _ (by decide) RawRows.raw1190))
    (slots720.inc_y 1191 1192 f r (row_of_literal 1191 _ (by decide) RawRows.raw1191) (Or.inl (by decide)))
    (slots720.jump 1192 1190 f r (row_of_literal 1192 _ (by decide) RawRows.raw1192))

theorem site1190 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1190:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1193:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1190Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1193Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 1193 f r x y z) (slots461.atReg 1197 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 1193 4 1197 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 1193 1197 1194 f r (row_of_literal 1193 _ (by decide) RawRows.raw1193))
    (slots461.pos_x 1193 1197 1194 f r (row_of_literal 1193 _ (by decide) RawRows.raw1193))
    (slots461.inc_y 1194 1195 f r (row_of_literal 1194 _ (by decide) RawRows.raw1194) (Or.inl (by decide)))
    (slots461.inc_z 1195 1196 f r (row_of_literal 1195 _ (by decide) RawRows.raw1195) (Or.inl (by decide)))
    (slots461.jump 1196 1193 f r (row_of_literal 1196 _ (by decide) RawRows.raw1196))

theorem site1193 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1193:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1197:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site1193Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site1197Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 1197 f r x y z) (slots640.atReg 1200 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 1197 3 1200 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 1197 1200 1198 f r (row_of_literal 1197 _ (by decide) RawRows.raw1197))
    (slots640.pos_x 1197 1200 1198 f r (row_of_literal 1197 _ (by decide) RawRows.raw1197))
    (slots640.inc_y 1198 1199 f r (row_of_literal 1198 _ (by decide) RawRows.raw1198) (Or.inl (by decide)))
    (slots640.jump 1199 1197 f r (row_of_literal 1199 _ (by decide) RawRows.raw1199))

theorem site1197 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1197:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1200:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site1197Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site1200Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 1200 f r x y z) (slots160.atReg 1203 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 1200 3 1203 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 1200 1203 1201 f r (row_of_literal 1200 _ (by decide) RawRows.raw1200))
    (slots160.pos_x 1200 1203 1201 f r (row_of_literal 1200 _ (by decide) RawRows.raw1200))
    (slots160.inc_y 1201 1202 f r (row_of_literal 1201 _ (by decide) RawRows.raw1201) (Or.inl (by decide)))
    (slots160.jump 1202 1200 f r (row_of_literal 1202 _ (by decide) RawRows.raw1202))

theorem site1200 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1200:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1203:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site1200Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site1203Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 1203 f r x y z) (slots210.atReg 1206 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 1203 3 1206 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 1203 1206 1204 f r (row_of_literal 1203 _ (by decide) RawRows.raw1203))
    (slots210.pos_x 1203 1206 1204 f r (row_of_literal 1203 _ (by decide) RawRows.raw1203))
    (slots210.inc_y 1204 1205 f r (row_of_literal 1204 _ (by decide) RawRows.raw1204) (Or.inl (by decide)))
    (slots210.jump 1205 1203 f r (row_of_literal 1205 _ (by decide) RawRows.raw1205))

theorem site1203 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1203:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1206:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site1203Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site1206Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 1206 f r x y z) (slots617.atReg 1216 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 1206 10 1216 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 1206 1210 1207 f r (row_of_literal 1206 _ (by decide) RawRows.raw1206))
    (slots617.pos_y 1206 1210 1207 f r (row_of_literal 1206 _ (by decide) RawRows.raw1206))
    (slots617.inc_z 1207 1208 f r (row_of_literal 1207 _ (by decide) RawRows.raw1207) (Or.inl (by decide)))
    (slots617.inc_x 1208 1209 f r (row_of_literal 1208 _ (by decide) RawRows.raw1208) (Or.inl (by decide)))
    (slots617.jump 1209 1206 f r (row_of_literal 1209 _ (by decide) RawRows.raw1209))
    (slots617.zero_x 1210 1216 1211 f r (row_of_literal 1210 _ (by decide) RawRows.raw1210))
    (slots617.pos_x 1210 1216 1211 f r (row_of_literal 1210 _ (by decide) RawRows.raw1210))
    (slots617.inc_z 1211 1212 f r (row_of_literal 1211 _ (by decide) RawRows.raw1211) (Or.inl (by decide)))
    (slots617.zero_x 1212 1215 1213 f r (row_of_literal 1212 _ (by decide) RawRows.raw1212))
    (slots617.pos_x 1212 1215 1213 f r (row_of_literal 1212 _ (by decide) RawRows.raw1212))
    (slots617.inc_y 1213 1214 f r (row_of_literal 1213 _ (by decide) RawRows.raw1213) (Or.inl (by decide)))
    (slots617.jump 1214 1212 f r (row_of_literal 1214 _ (by decide) RawRows.raw1214))
    (slots617.jump 1215 1206 f r (row_of_literal 1215 _ (by decide) RawRows.raw1215))

theorem site1206 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1206:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1216:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site1206Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site1216Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 1216 f r x y z) (slots720.atReg 1219 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 1216 3 1219 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 1216 1219 1217 f r (row_of_literal 1216 _ (by decide) RawRows.raw1216))
    (slots720.pos_x 1216 1219 1217 f r (row_of_literal 1216 _ (by decide) RawRows.raw1216))
    (slots720.inc_y 1217 1218 f r (row_of_literal 1217 _ (by decide) RawRows.raw1217) (Or.inl (by decide)))
    (slots720.jump 1218 1216 f r (row_of_literal 1218 _ (by decide) RawRows.raw1218))

theorem site1216 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1216:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1219:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site1216Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site1219Frame (f r : V) : ∀ x y z : V, Reach (slots561.atReg 1219 f r x y z) (slots561.atReg 1223 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots561.atReg (destination 1219 4 1223 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots561.zero_x 1219 1223 1220 f r (row_of_literal 1219 _ (by decide) RawRows.raw1219))
    (slots561.pos_x 1219 1223 1220 f r (row_of_literal 1219 _ (by decide) RawRows.raw1219))
    (slots561.inc_y 1220 1221 f r (row_of_literal 1220 _ (by decide) RawRows.raw1220) (Or.inl (by decide)))
    (slots561.inc_z 1221 1222 f r (row_of_literal 1221 _ (by decide) RawRows.raw1221) (Or.inl (by decide)))
    (slots561.jump 1222 1219 f r (row_of_literal 1222 _ (by decide) RawRows.raw1222))

theorem site1219 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1219:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1223:Nat):V) f (vector r0 (r1+r5) r2 r3 r4 0 (r6+r5) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots561,vector,writeReg,pi₁_pair,pi₂_pair] using site1219Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r5 r6 r1


private theorem site1223Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 1223 f r x y z) (slots650.atReg 1226 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 1223 3 1226 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 1223 1226 1224 f r (row_of_literal 1223 _ (by decide) RawRows.raw1223))
    (slots650.pos_x 1223 1226 1224 f r (row_of_literal 1223 _ (by decide) RawRows.raw1223))
    (slots650.inc_y 1224 1225 f r (row_of_literal 1224 _ (by decide) RawRows.raw1224) (Or.inl (by decide)))
    (slots650.jump 1225 1223 f r (row_of_literal 1225 _ (by decide) RawRows.raw1225))

theorem site1223 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1223:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1226:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site1223Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site1226Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 1226 f r x y z) (slots267.atReg 1234 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 1226 8 1234 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 1226 1234 1227 f r (row_of_literal 1226 _ (by decide) RawRows.raw1226))
    (slots267.pos_x 1226 1234 1227 f r (row_of_literal 1226 _ (by decide) RawRows.raw1226))
    (slots267.inc_z 1227 1228 f r (row_of_literal 1227 _ (by decide) RawRows.raw1227) (Or.inl (by decide)))
    (slots267.zero_y 1228 1230 1229 f r (row_of_literal 1228 _ (by decide) RawRows.raw1228))
    (slots267.pos_y 1228 1230 1229 f r (row_of_literal 1228 _ (by decide) RawRows.raw1228))
    (slots267.jump 1229 1233 f r (row_of_literal 1229 _ (by decide) RawRows.raw1229))
    (slots267.zero_z 1230 1233 1231 f r (row_of_literal 1230 _ (by decide) RawRows.raw1230))
    (slots267.pos_z 1230 1233 1231 f r (row_of_literal 1230 _ (by decide) RawRows.raw1230))
    (slots267.inc_y 1231 1232 f r (row_of_literal 1231 _ (by decide) RawRows.raw1231) (Or.inl (by decide)))
    (slots267.jump 1232 1230 f r (row_of_literal 1232 _ (by decide) RawRows.raw1232))
    (slots267.jump 1233 1226 f r (row_of_literal 1233 _ (by decide) RawRows.raw1233))

theorem site1226 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1226:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((1234:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site1226Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


end PA192.ModelSearch.Register181.Certified
