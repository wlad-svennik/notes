module
public import Src181Atoms
public import Src181Loops00
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandRefillColdAfter1 (n t s c u v y d w : V) : Reach (config ((2:Nat):V) 1 (vector n t s c u v 0 0 0)) (config ((3:Nat):V) 0 (vector 0 t s c u v 0 0 0)) := by
  have micro := site0002Cold n t s c u v 0 0 0
  exact micro

theorem commandRefillColdAfter2 (n t s c u v y d w : V) : Reach (config ((2:Nat):V) 1 (vector n t s c u v 0 0 0)) (config ((7:Nat):V) 0 (vector 0 t s c u v 0 0 0)) := by
  have micro := site0003 0 t s c u v 0 0 0
  have d6 : (0+0:V)=0 := by ring
  have d8 : (0+0:V)=0 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d8 rfl)
  exact (commandRefillColdAfter1 n t s c u v y d w).trans mid

theorem commandRefillCold (n t s c u v y d w : V) : Reach (config ((2:Nat):V) 1 (vector n t s c u v 0 0 0)) (config ((10:Nat):V) 0 (vector 0 t s c u v 0 0 0)) := by
  have micro := site0007 0 t s c u v 0 0 0
  have d0 : (0+0:V)=0 := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ d0 rfl rfl rfl rfl rfl rfl rfl rfl)
  exact (commandRefillColdAfter2 n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
