import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1120_0 : checkWitness 1120 false false 68 = true := by decide +kernel
private theorem w1120_2 : checkWitness 1120 true false 68 = true := by decide +kernel
private theorem cases1120 : checkFour 1120 (68,0,68,0) = true := by
  simp only [checkFour, w1120_0, w1120_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1120 : Coverage 1120 1121 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases1120)
private theorem w1121_0 : checkWitness 1121 false false 500 = true := by decide +kernel
private theorem w1121_1 : checkWitness 1121 false true 4596 = true := by decide +kernel
private theorem w1121_2 : checkWitness 1121 true false 500 = true := by decide +kernel
private theorem w1121_3 : checkWitness 1121 true true 4596 = true := by decide +kernel
private theorem cases1121 : checkFour 1121 (500,4596,500,4596) = true := by
  simp only [checkFour, w1121_0, w1121_1, w1121_2, w1121_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1121 : Coverage 1121 1122 := checkList_sound (ws:=[(500,4596,500,4596)]) (by simpa only [checkList, Bool.and_true] using cases1121)
private theorem w1122_0 : checkWitness 1122 false false 8895 = true := by decide +kernel
private theorem w1122_2 : checkWitness 1122 true false 8891 = true := by decide +kernel
private theorem cases1122 : checkFour 1122 (8895,0,8891,0) = true := by
  simp only [checkFour, w1122_0, w1122_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1122 : Coverage 1122 1123 := checkList_sound (ws:=[(8895,0,8891,0)]) (by simpa only [checkList, Bool.and_true] using cases1122)
private theorem w1123_0 : checkWitness 1123 false false 626 = true := by decide +kernel
private theorem w1123_1 : checkWitness 1123 false true 4722 = true := by decide +kernel
private theorem w1123_2 : checkWitness 1123 true false 617 = true := by decide +kernel
private theorem w1123_3 : checkWitness 1123 true true 4713 = true := by decide +kernel
private theorem cases1123 : checkFour 1123 (626,4722,617,4713) = true := by
  simp only [checkFour, w1123_0, w1123_1, w1123_2, w1123_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1123 : Coverage 1123 1124 := checkList_sound (ws:=[(626,4722,617,4713)]) (by simpa only [checkList, Bool.and_true] using cases1123)
private theorem w1124_0 : checkWitness 1124 false false 178 = true := by decide +kernel
private theorem w1124_2 : checkWitness 1124 true false 178 = true := by decide +kernel
private theorem cases1124 : checkFour 1124 (178,0,178,0) = true := by
  simp only [checkFour, w1124_0, w1124_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1124 : Coverage 1124 1125 := checkList_sound (ws:=[(178,0,178,0)]) (by simpa only [checkList, Bool.and_true] using cases1124)
private theorem w1125_0 : checkWitness 1125 false false 581 = true := by decide +kernel
private theorem w1125_1 : checkWitness 1125 false true 4669 = true := by decide +kernel
private theorem w1125_2 : checkWitness 1125 true false 581 = true := by decide +kernel
private theorem w1125_3 : checkWitness 1125 true true 4669 = true := by decide +kernel
private theorem cases1125 : checkFour 1125 (581,4669,581,4669) = true := by
  simp only [checkFour, w1125_0, w1125_1, w1125_2, w1125_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1125 : Coverage 1125 1126 := checkList_sound (ws:=[(581,4669,581,4669)]) (by simpa only [checkList, Bool.and_true] using cases1125)
private theorem w1126_0 : checkWitness 1126 false false 8910 = true := by decide +kernel
private theorem w1126_2 : checkWitness 1126 true false 8901 = true := by decide +kernel
private theorem cases1126 : checkFour 1126 (8910,0,8901,0) = true := by
  simp only [checkFour, w1126_0, w1126_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1126 : Coverage 1126 1127 := checkList_sound (ws:=[(8910,0,8901,0)]) (by simpa only [checkList, Bool.and_true] using cases1126)
private theorem w1127_0 : checkWitness 1127 false false 86 = true := by decide +kernel
private theorem w1127_2 : checkWitness 1127 true false 86 = true := by decide +kernel
private theorem cases1127 : checkFour 1127 (86,0,86,0) = true := by
  simp only [checkFour, w1127_0, w1127_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1127 : Coverage 1127 1128 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases1127)
private theorem w1128_0 : checkWitness 1128 false false 78 = true := by decide +kernel
private theorem w1128_2 : checkWitness 1128 true false 78 = true := by decide +kernel
private theorem cases1128 : checkFour 1128 (78,0,78,0) = true := by
  simp only [checkFour, w1128_0, w1128_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1128 : Coverage 1128 1129 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1128)
private theorem w1129_0 : checkWitness 1129 false false 587 = true := by decide +kernel
private theorem w1129_1 : checkWitness 1129 false true 4679 = true := by decide +kernel
private theorem w1129_2 : checkWitness 1129 true false 587 = true := by decide +kernel
private theorem w1129_3 : checkWitness 1129 true true 4679 = true := by decide +kernel
private theorem cases1129 : checkFour 1129 (587,4679,587,4679) = true := by
  simp only [checkFour, w1129_0, w1129_1, w1129_2, w1129_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1129 : Coverage 1129 1130 := checkList_sound (ws:=[(587,4679,587,4679)]) (by simpa only [checkList, Bool.and_true] using cases1129)
private theorem w1130_0 : checkWitness 1130 false false 8848 = true := by decide +kernel
private theorem w1130_2 : checkWitness 1130 true false 8844 = true := by decide +kernel
private theorem cases1130 : checkFour 1130 (8848,0,8844,0) = true := by
  simp only [checkFour, w1130_0, w1130_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1130 : Coverage 1130 1131 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases1130)
private theorem w1131_0 : checkWitness 1131 false false 78 = true := by decide +kernel
private theorem w1131_2 : checkWitness 1131 true false 78 = true := by decide +kernel
private theorem cases1131 : checkFour 1131 (78,0,78,0) = true := by
  simp only [checkFour, w1131_0, w1131_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1131 : Coverage 1131 1132 := checkList_sound (ws:=[(78,0,78,0)]) (by simpa only [checkList, Bool.and_true] using cases1131)
private theorem w1132_0 : checkWitness 1132 false false 542 = true := by decide +kernel
private theorem w1132_1 : checkWitness 1132 false true 4638 = true := by decide +kernel
private theorem w1132_2 : checkWitness 1132 true false 542 = true := by decide +kernel
private theorem w1132_3 : checkWitness 1132 true true 4638 = true := by decide +kernel
private theorem cases1132 : checkFour 1132 (542,4638,542,4638) = true := by
  simp only [checkFour, w1132_0, w1132_1, w1132_2, w1132_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1132 : Coverage 1132 1133 := checkList_sound (ws:=[(542,4638,542,4638)]) (by simpa only [checkList, Bool.and_true] using cases1132)
private theorem w1133_0 : checkWitness 1133 false false 8883 = true := by decide +kernel
private theorem w1133_2 : checkWitness 1133 true false 8879 = true := by decide +kernel
private theorem cases1133 : checkFour 1133 (8883,0,8879,0) = true := by
  simp only [checkFour, w1133_0, w1133_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1133 : Coverage 1133 1134 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1133)
private theorem w1134_0 : checkWitness 1134 false false 8918 = true := by decide +kernel
private theorem w1134_2 : checkWitness 1134 true false 8909 = true := by decide +kernel
private theorem cases1134 : checkFour 1134 (8918,0,8909,0) = true := by
  simp only [checkFour, w1134_0, w1134_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1134 : Coverage 1134 1135 := checkList_sound (ws:=[(8918,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases1134)
private theorem w1135_0 : checkWitness 1135 false false 96 = true := by decide +kernel
private theorem w1135_2 : checkWitness 1135 true false 96 = true := by decide +kernel
private theorem cases1135 : checkFour 1135 (96,0,96,0) = true := by
  simp only [checkFour, w1135_0, w1135_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1135 : Coverage 1135 1136 := checkList_sound (ws:=[(96,0,96,0)]) (by simpa only [checkList, Bool.and_true] using cases1135)
private theorem w1136_0 : checkWitness 1136 false false 630 = true := by decide +kernel
private theorem w1136_1 : checkWitness 1136 false true 4722 = true := by decide +kernel
private theorem w1136_2 : checkWitness 1136 true false 621 = true := by decide +kernel
private theorem w1136_3 : checkWitness 1136 true true 4713 = true := by decide +kernel
private theorem cases1136 : checkFour 1136 (630,4722,621,4713) = true := by
  simp only [checkFour, w1136_0, w1136_1, w1136_2, w1136_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1136 : Coverage 1136 1137 := checkList_sound (ws:=[(630,4722,621,4713)]) (by simpa only [checkList, Bool.and_true] using cases1136)
private theorem w1137_0 : checkWitness 1137 false false 8879 = true := by decide +kernel
private theorem w1137_2 : checkWitness 1137 true false 8875 = true := by decide +kernel
private theorem cases1137 : checkFour 1137 (8879,0,8875,0) = true := by
  simp only [checkFour, w1137_0, w1137_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1137 : Coverage 1137 1138 := checkList_sound (ws:=[(8879,0,8875,0)]) (by simpa only [checkList, Bool.and_true] using cases1137)
private theorem w1138_0 : checkWitness 1138 false false 624 = true := by decide +kernel
private theorem w1138_1 : checkWitness 1138 false true 4716 = true := by decide +kernel
private theorem w1138_2 : checkWitness 1138 true false 615 = true := by decide +kernel
private theorem w1138_3 : checkWitness 1138 true true 4707 = true := by decide +kernel
private theorem cases1138 : checkFour 1138 (624,4716,615,4707) = true := by
  simp only [checkFour, w1138_0, w1138_1, w1138_2, w1138_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1138 : Coverage 1138 1139 := checkList_sound (ws:=[(624,4716,615,4707)]) (by simpa only [checkList, Bool.and_true] using cases1138)
private theorem w1139_0 : checkWitness 1139 false false 8848 = true := by decide +kernel
private theorem w1139_2 : checkWitness 1139 true false 8844 = true := by decide +kernel
private theorem cases1139 : checkFour 1139 (8848,0,8844,0) = true := by
  simp only [checkFour, w1139_0, w1139_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1139 : Coverage 1139 1140 := checkList_sound (ws:=[(8848,0,8844,0)]) (by simpa only [checkList, Bool.and_true] using cases1139)
private theorem w1140_0 : checkWitness 1140 false false 84 = true := by decide +kernel
private theorem w1140_2 : checkWitness 1140 true false 84 = true := by decide +kernel
private theorem cases1140 : checkFour 1140 (84,0,84,0) = true := by
  simp only [checkFour, w1140_0, w1140_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1140 : Coverage 1140 1141 := checkList_sound (ws:=[(84,0,84,0)]) (by simpa only [checkList, Bool.and_true] using cases1140)
private theorem w1141_0 : checkWitness 1141 false false 76 = true := by decide +kernel
private theorem w1141_2 : checkWitness 1141 true false 76 = true := by decide +kernel
private theorem cases1141 : checkFour 1141 (76,0,76,0) = true := by
  simp only [checkFour, w1141_0, w1141_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1141 : Coverage 1141 1142 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases1141)
private theorem w1142_0 : checkWitness 1142 false false 591 = true := by decide +kernel
private theorem w1142_1 : checkWitness 1142 false true 4679 = true := by decide +kernel
private theorem w1142_2 : checkWitness 1142 true false 591 = true := by decide +kernel
private theorem w1142_3 : checkWitness 1142 true true 4679 = true := by decide +kernel
private theorem cases1142 : checkFour 1142 (591,4679,591,4679) = true := by
  simp only [checkFour, w1142_0, w1142_1, w1142_2, w1142_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1142 : Coverage 1142 1143 := checkList_sound (ws:=[(591,4679,591,4679)]) (by simpa only [checkList, Bool.and_true] using cases1142)
private theorem w1143_0 : checkWitness 1143 false false 8864 = true := by decide +kernel
private theorem w1143_2 : checkWitness 1143 true false 8860 = true := by decide +kernel
private theorem cases1143 : checkFour 1143 (8864,0,8860,0) = true := by
  simp only [checkFour, w1143_0, w1143_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1143 : Coverage 1143 1144 := checkList_sound (ws:=[(8864,0,8860,0)]) (by simpa only [checkList, Bool.and_true] using cases1143)
private theorem w1144_0 : checkWitness 1144 false false 8860 = true := by decide +kernel
private theorem w1144_2 : checkWitness 1144 true false 8856 = true := by decide +kernel
private theorem cases1144 : checkFour 1144 (8860,0,8856,0) = true := by
  simp only [checkFour, w1144_0, w1144_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1144 : Coverage 1144 1145 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases1144)
private theorem w1145_0 : checkWitness 1145 false false 90 = true := by decide +kernel
private theorem w1145_2 : checkWitness 1145 true false 90 = true := by decide +kernel
private theorem cases1145 : checkFour 1145 (90,0,90,0) = true := by
  simp only [checkFour, w1145_0, w1145_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1145 : Coverage 1145 1146 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1145)
private theorem w1146_0 : checkWitness 1146 false false 8884 = true := by decide +kernel
private theorem w1146_2 : checkWitness 1146 true false 8880 = true := by decide +kernel
private theorem cases1146 : checkFour 1146 (8884,0,8880,0) = true := by
  simp only [checkFour, w1146_0, w1146_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1146 : Coverage 1146 1147 := checkList_sound (ws:=[(8884,0,8880,0)]) (by simpa only [checkList, Bool.and_true] using cases1146)
private theorem w1147_0 : checkWitness 1147 false false 8886 = true := by decide +kernel
private theorem w1147_2 : checkWitness 1147 true false 8882 = true := by decide +kernel
private theorem cases1147 : checkFour 1147 (8886,0,8882,0) = true := by
  simp only [checkFour, w1147_0, w1147_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1147 : Coverage 1147 1148 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases1147)
private theorem w1148_0 : checkWitness 1148 false false 514 = true := by decide +kernel
private theorem w1148_1 : checkWitness 1148 false true 4610 = true := by decide +kernel
private theorem w1148_2 : checkWitness 1148 true false 514 = true := by decide +kernel
private theorem w1148_3 : checkWitness 1148 true true 4610 = true := by decide +kernel
private theorem cases1148 : checkFour 1148 (514,4610,514,4610) = true := by
  simp only [checkFour, w1148_0, w1148_1, w1148_2, w1148_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1148 : Coverage 1148 1149 := checkList_sound (ws:=[(514,4610,514,4610)]) (by simpa only [checkList, Bool.and_true] using cases1148)
private theorem w1149_0 : checkWitness 1149 false false 8909 = true := by decide +kernel
private theorem w1149_2 : checkWitness 1149 true false 8905 = true := by decide +kernel
private theorem cases1149 : checkFour 1149 (8909,0,8905,0) = true := by
  simp only [checkFour, w1149_0, w1149_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1149 : Coverage 1149 1150 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases1149)
private theorem w1150_0 : checkWitness 1150 false false 640 = true := by decide +kernel
private theorem w1150_1 : checkWitness 1150 false true 4736 = true := by decide +kernel
private theorem w1150_2 : checkWitness 1150 true false 631 = true := by decide +kernel
private theorem w1150_3 : checkWitness 1150 true true 4727 = true := by decide +kernel
private theorem cases1150 : checkFour 1150 (640,4736,631,4727) = true := by
  simp only [checkFour, w1150_0, w1150_1, w1150_2, w1150_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1150 : Coverage 1150 1151 := checkList_sound (ws:=[(640,4736,631,4727)]) (by simpa only [checkList, Bool.and_true] using cases1150)
private theorem w1151_0 : checkWitness 1151 false false 182 = true := by decide +kernel
private theorem w1151_2 : checkWitness 1151 true false 182 = true := by decide +kernel
private theorem cases1151 : checkFour 1151 (182,0,182,0) = true := by
  simp only [checkFour, w1151_0, w1151_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1151 : Coverage 1151 1152 := checkList_sound (ws:=[(182,0,182,0)]) (by simpa only [checkList, Bool.and_true] using cases1151)
theorem cover1120 : Coverage 1120 1152 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1120 one1121) (Coverage.join one1122 one1123)) (Coverage.join (Coverage.join one1124 one1125) (Coverage.join one1126 one1127))) (Coverage.join (Coverage.join (Coverage.join one1128 one1129) (Coverage.join one1130 one1131)) (Coverage.join (Coverage.join one1132 one1133) (Coverage.join one1134 one1135)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1136 one1137) (Coverage.join one1138 one1139)) (Coverage.join (Coverage.join one1140 one1141) (Coverage.join one1142 one1143))) (Coverage.join (Coverage.join (Coverage.join one1144 one1145) (Coverage.join one1146 one1147)) (Coverage.join (Coverage.join one1148 one1149) (Coverage.join one1150 one1151)))))
end NF181PA.Symbolic
