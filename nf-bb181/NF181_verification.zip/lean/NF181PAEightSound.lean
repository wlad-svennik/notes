module
public import NF181PAScanner

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields NF181PA.Packed NF181PA.Commands
open NF181PA
namespace NF181PA.Sound
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 3000000
set_option maxRecDepth 10000

def Prov (a : V) := Pool.Pr (∅ : V) a
instance provDef : Language.DefinablePred ℒₒᵣ (Prov (V:=V)) := by unfold Prov; definability

theorem provZero : Prov (0:V) := by
  apply Pool.leaf
  left
  have hz : row0 (0:V) 0 0 0 = 0 := by simp [row0,imp,cantor,triangle_zero]
  rw [←hz]
  exact Pool.ax_of_mem (not_lt_of_ge (le_refl (0:V))) (List.Mem.head _)

/-- The implicit all-zero extension of the encoded stack also has a proof. -/
def goodStack (z : V) : Prop := ∀ j : V, Prov (left (iterate right j z))
instance stackDef : Language.DefinablePred ℒₒᵣ (goodStack (V:=V)) := by unfold goodStack; definability

theorem head {z : V} (hz : goodStack z) : Prov (left z) := by simpa using hz 0
theorem tail {z : V} (hz : goodStack z) : goodStack (right z) := by
  intro j; simpa only [iterate_succ_left] using hz (j+1)
theorem push {t z : V} (ht : Prov t) (hz : goodStack z) : goodStack (cantor t z) := by
  intro j
  rcases eq_zero_or_pos j with rfl|h
  · simpa using ht
  · obtain ⟨k,rfl⟩ := eq_succ_of_pos h
    simpa only [iterate_succ_left,right_cantor] using hz k

theorem goodZero : goodStack (0:V) := by
  intro j
  have zz : cantor (0:V) 0=0 := by simp [cantor,triangle_zero]
  have rz : right (0:V)=0 := by simpa only [zz] using (right_cantor (0:V) 0)
  have lz : left (0:V)=0 := by simpa only [zz] using (left_cantor (0:V) 0)
  have zero : iterate right j (0:V)=0 := by
    induction j using modelInduct with
    | defP => definability
    | zero => simp
    | step i ih => rw [iterate_succ,ih,rz]
  simpa [zero,lz] using (provZero (V:=V))

def goodState (e : V) := Prov (top e) ∧ goodStack (stack e) ∧ Prov (cache e)
instance stateDef : Language.DefinablePred ℒₒᵣ (goodState (V:=V)) := by unfold goodState top stack cache; definability
@[simp] theorem good_state (t s h p : V) : goodState (state t s h p) ↔ Prov t ∧ goodStack s ∧ Prov h := by
  simp [goodState,top,stack,cache,state]

theorem goodFront (a b c u z : V) (hu : u≤a) (hz : goodStack z) : goodStack (front8 a b c u z) := by
  have leaf {v : V} (hm : v ∈ Pool.batch a b c u) : Prov v :=
    Pool.leaf (Or.inl (Pool.ax_of_mem (not_lt_of_ge hu) hm))
  have r0 : Prov (row0 a b c u) := leaf (.head _)
  have r1 : Prov (row3 a b) := leaf (.tail _ (.head _))
  have r2 : Prov (row6 a b c) := leaf (.tail _ (.tail _ (.head _)))
  have r3 : Prov (Pool.nativeB a b c) := leaf (.tail _ (.tail _ (.tail _ (.head _))))
  have r4 : Prov (row2 a b c) := leaf (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))
  have r5 : Prov (row4 a b c) := leaf (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))
  have r6 : Prov (Pool.test b a) := leaf (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))))
  have r7 : Prov (row8 a b) := leaf (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))))
  unfold front8 front6
  exact (push r7 (push r6 (push r5 (push r4 (push r3 (push r2 (push r1 (push r0 hz))))))))

theorem goodBatch (v : V) (h : goodStack (body v)) : goodStack (body (nextBatch v)) := by
  simpa only [nextBatch,packBatch,body,pi₂_pair,pi₁_pair] using
    goodFront (aval v+left (right (fields v))) (bval v+left (fields v)) (rank v-1) (aval v) (body v) le_self_add h

theorem goodIterBatch (v j : V) (h : goodStack (body v)) :
    goodStack (body (iterate nextBatch j v)) := by
  induction j using modelInduct with
  | defP => unfold body; definability
  | zero => simpa using h
  | step i ih => rw [iterate_succ]; exact goodBatch _ ih

theorem goodPop {z : V} (h : goodStack z) : goodState (afterAX z) :=
  (good_state ..).mpr ⟨provZero,tail (tail h),head (tail h)⟩

theorem goodAX (u b d c w e : V) (h : goodState e) : goodState (pi₁ (axRaw u b d c w e)) := by
  let p:=param e+u
  let z:=front8 (p+d) (cache e+b) c p (cantor (top e) (stack e))
  have first : goodStack z := goodFront _ _ _ _ _ le_self_add (push h.1 h.2.1)
  have initial : goodStack (body (packBatch c z (p+d) (cache e+b) w)) := by simpa [packBatch,body] using first
  simpa only [axRaw,pi₁_pair] using goodPop (goodIterBatch (packBatch c z (p+d) (cache e+b) w) c initial)

theorem goodMP (d e : V) (h : goodState e) : goodState (deduction d e) := by
  dsimp only [deduction]
  by_cases he : cache e = imp (top e) (param e+d)
  · rw [if_pos he]
    exact (good_state ..).mpr ⟨Pool.mp (he ▸ h.2.2) h.1,tail h.2.1,head h.2.1⟩
  · rw [if_neg he]
    exact (good_state ..).mpr ⟨provZero,tail h.2.1,head h.2.1⟩

theorem goodMode (d e : V) (h : goodState e) : goodState (mode d e) := by
  dsimp only [mode]
  split
  · exact (good_state ..).mpr ⟨h.1,tail h.2.1,head h.2.1⟩
  · exact (good_state ..).mpr ⟨h.2.2,h.2.1,h.1⟩

theorem goodAction (raw e : V) (h : goodState e) : goodState (Scanner.rawAction raw e) := by
  dsimp only [Scanner.rawAction,Scanner.rawAX,chooseZero]
  split
  · exact goodMode _ _ h
  split
  · exact goodMP _ _ h
  · exact goodAX _ _ _ _ _ _ h

theorem goodNext (a : V) (h : goodState (Scanner.dataState a)) : goodState (Scanner.dataState (Scanner.next a)) := by
  simpa only [Scanner.next,Scanner.fresh,Scanner.dataState,pi₂_pair] using goodAction (Scanner.input a) _ h

theorem observation_implies_pool (a j : V) (h : goodState (Scanner.dataState a))
    (hit : Scanner.observed (iterate Scanner.next j a)) : Pool.Pr (∅ : V) goal := by
  have sound : goodState (Scanner.dataState (iterate Scanner.next j a)) := by
    clear hit
    induction j using modelInduct with
    | defP => unfold Scanner.dataState; definability
    | zero => simpa using h
    | step i ih => rw [iterate_succ]; exact goodNext _ ih
  simpa only [Prov,goal_three,←hit.2] using sound.2.2

end NF181PA.Sound
#print axioms NF181PA.Sound.observation_implies_pool
