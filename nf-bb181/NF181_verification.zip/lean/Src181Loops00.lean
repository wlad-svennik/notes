module
public import Src181Slots
public import Src181Data

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option maxRecDepth 9000
set_option maxHeartbeats 2800000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Certified

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem site0000Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((0:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 0)) (config ((2:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 0)) := by
  apply Reach.once
  rw [step_at 0 _ (row_of_literal 0 _ (by decide) RawRows.raw0000)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]

theorem site0000Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((0:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 (r8+1))) (config ((1:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 0 _ (row_of_literal 0 _ (by decide) RawRows.raw0000)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site0001 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((1:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((10:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 1 _ (row_of_literal 1 _ (by decide) RawRows.raw0001)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site0002 (r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2:Nat):V) 0 (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3:Nat):V) 0 (vector (r0+1) r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2 _ (row_of_literal 2 _ (by decide) RawRows.raw0002)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]

theorem site0002Cold (r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((2:Nat):V) 1 (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((3:Nat):V) 0 (vector 0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 2 _ (row_of_literal 2 _ (by decide) RawRows.raw0002)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private def slots076 : Slots := ⟨0,7,6,by decide,by decide,by decide⟩
private theorem site0003Frame (r : V) : ∀ x y z : V, Reach (slots076.atReg 3 0 r x y z) (slots076.atReg 7 0 r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots076.atReg (destination 3 4 7 4095 j) 0 r) (fun _=>Slots.frameDef ..)
    (slots076.zero_x 3 7 4 0 r (row_of_literal 3 _ (by decide) RawRows.raw0003))
    (slots076.pos_x 3 7 4 0 r (row_of_literal 3 _ (by decide) RawRows.raw0003))
    (slots076.inc_y 4 5 0 r (row_of_literal 4 _ (by decide) RawRows.raw0004) (Or.inl (by decide)))
    (slots076.inc_z 5 6 0 r (row_of_literal 5 _ (by decide) RawRows.raw0005) (Or.inl (by decide)))
    (slots076.jump 6 3 0 r (row_of_literal 6 _ (by decide) RawRows.raw0006))

theorem site0003 (r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((3:Nat):V) 0 (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((7:Nat):V) 0 (vector 0 r1 r2 r3 r4 r5 (r6+r0) (r7+r0) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots076,vector,writeReg,pi₁_pair,pi₂_pair] using site0003Frame (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r0 r7 r6


private theorem site0007Frame (r : V) : ∀ x y z : V, Reach (slots601.atReg 7 0 r x y z) (slots601.atReg 10 0 r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots601.atReg (destination 7 3 10 4095 j) 0 r) (fun _=>Slots.frameDef ..)
    (slots601.zero_x 7 10 8 0 r (row_of_literal 7 _ (by decide) RawRows.raw0007))
    (slots601.pos_x 7 10 8 0 r (row_of_literal 7 _ (by decide) RawRows.raw0007))
    (slots601.inc_y 8 9 0 r (row_of_literal 8 _ (by decide) RawRows.raw0008) (Or.inr rfl))
    (slots601.jump 9 7 0 r (row_of_literal 9 _ (by decide) RawRows.raw0009))

theorem site0007 (r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((7:Nat):V) 0 (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((10:Nat):V) 0 (vector (r0+r6) r1 r2 r3 r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots601,vector,writeReg,pi₁_pair,pi₂_pair] using site0007Frame (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r0 r1


private theorem site0010Frame (f r : V) : ∀ x y z : V, Reach (slots867.atReg 10 f r x y z) (slots867.atReg 18 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots867.atReg (destination 10 8 18 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots867.zero_x 10 18 11 f r (row_of_literal 10 _ (by decide) RawRows.raw0010))
    (slots867.pos_x 10 18 11 f r (row_of_literal 10 _ (by decide) RawRows.raw0010))
    (slots867.inc_z 11 12 f r (row_of_literal 11 _ (by decide) RawRows.raw0011) (Or.inl (by decide)))
    (slots867.zero_y 12 14 13 f r (row_of_literal 12 _ (by decide) RawRows.raw0012))
    (slots867.pos_y 12 14 13 f r (row_of_literal 12 _ (by decide) RawRows.raw0012))
    (slots867.jump 13 17 f r (row_of_literal 13 _ (by decide) RawRows.raw0013))
    (slots867.zero_z 14 17 15 f r (row_of_literal 14 _ (by decide) RawRows.raw0014))
    (slots867.pos_z 14 17 15 f r (row_of_literal 14 _ (by decide) RawRows.raw0014))
    (slots867.inc_y 15 16 f r (row_of_literal 15 _ (by decide) RawRows.raw0015) (Or.inl (by decide)))
    (slots867.jump 16 14 f r (row_of_literal 16 _ (by decide) RawRows.raw0016))
    (slots867.jump 17 10 f r (row_of_literal 17 _ (by decide) RawRows.raw0017))

theorem site0010 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((10:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((18:Nat):V) f (vector r0 r1 r2 r3 r4 r5 (left (cantor r6 r7+r8)) (right (cantor r6 r7+r8)) 0)) := by
  simpa only [Slots.atReg,Slots.fill,slots867,vector,writeReg,pi₁_pair,pi₂_pair] using site0010Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r8 r6 r7


private theorem site0018Frame (f r : V) : ∀ x y z : V, Reach (slots780.atReg 18 f r x y z) (slots780.atReg 21 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots780.atReg (destination 18 3 21 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots780.zero_x 18 21 19 f r (row_of_literal 18 _ (by decide) RawRows.raw0018))
    (slots780.pos_x 18 21 19 f r (row_of_literal 18 _ (by decide) RawRows.raw0018))
    (slots780.inc_y 19 20 f r (row_of_literal 19 _ (by decide) RawRows.raw0019) (Or.inl (by decide)))
    (slots780.jump 20 18 f r (row_of_literal 20 _ (by decide) RawRows.raw0020))

theorem site0018 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((18:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((21:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 0 (r8+r7))) := by
  simpa only [Slots.atReg,Slots.fill,slots780,vector,writeReg,pi₁_pair,pi₂_pair] using site0018Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r8 r0


private theorem site0021Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 21 f r x y z) (slots630.atReg 24 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 21 3 24 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 21 24 22 f r (row_of_literal 21 _ (by decide) RawRows.raw0021))
    (slots630.pos_x 21 24 22 f r (row_of_literal 21 _ (by decide) RawRows.raw0021))
    (slots630.inc_y 22 23 f r (row_of_literal 22 _ (by decide) RawRows.raw0022) (Or.inl (by decide)))
    (slots630.jump 23 21 f r (row_of_literal 23 _ (by decide) RawRows.raw0023))

theorem site0021 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((21:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((24:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0021Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site0024Frame (f r : V) : ∀ x y z : V, Reach (slots867.atReg 24 f r x y z) (slots867.atReg 32 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots867.atReg (destination 24 8 32 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots867.zero_x 24 32 25 f r (row_of_literal 24 _ (by decide) RawRows.raw0024))
    (slots867.pos_x 24 32 25 f r (row_of_literal 24 _ (by decide) RawRows.raw0024))
    (slots867.inc_z 25 26 f r (row_of_literal 25 _ (by decide) RawRows.raw0025) (Or.inl (by decide)))
    (slots867.zero_y 26 28 27 f r (row_of_literal 26 _ (by decide) RawRows.raw0026))
    (slots867.pos_y 26 28 27 f r (row_of_literal 26 _ (by decide) RawRows.raw0026))
    (slots867.jump 27 31 f r (row_of_literal 27 _ (by decide) RawRows.raw0027))
    (slots867.zero_z 28 31 29 f r (row_of_literal 28 _ (by decide) RawRows.raw0028))
    (slots867.pos_z 28 31 29 f r (row_of_literal 28 _ (by decide) RawRows.raw0028))
    (slots867.inc_y 29 30 f r (row_of_literal 29 _ (by decide) RawRows.raw0029) (Or.inl (by decide)))
    (slots867.jump 30 28 f r (row_of_literal 30 _ (by decide) RawRows.raw0030))
    (slots867.jump 31 24 f r (row_of_literal 31 _ (by decide) RawRows.raw0031))

theorem site0024 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((24:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((32:Nat):V) f (vector r0 r1 r2 r3 r4 r5 (left (cantor r6 r7+r8)) (right (cantor r6 r7+r8)) 0)) := by
  simpa only [Slots.atReg,Slots.fill,slots867,vector,writeReg,pi₁_pair,pi₂_pair] using site0024Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r8 r6 r7


private theorem site0032Frame (f r : V) : ∀ x y z : V, Reach (slots780.atReg 32 f r x y z) (slots780.atReg 35 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots780.atReg (destination 32 3 35 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots780.zero_x 32 35 33 f r (row_of_literal 32 _ (by decide) RawRows.raw0032))
    (slots780.pos_x 32 35 33 f r (row_of_literal 32 _ (by decide) RawRows.raw0032))
    (slots780.inc_y 33 34 f r (row_of_literal 33 _ (by decide) RawRows.raw0033) (Or.inl (by decide)))
    (slots780.jump 34 32 f r (row_of_literal 34 _ (by decide) RawRows.raw0034))

theorem site0032 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((32:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((35:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 0 (r8+r7))) := by
  simpa only [Slots.atReg,Slots.fill,slots780,vector,writeReg,pi₁_pair,pi₂_pair] using site0032Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r8 r0


private theorem site0035Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 35 f r x y z) (slots640.atReg 38 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 35 3 38 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 35 38 36 f r (row_of_literal 35 _ (by decide) RawRows.raw0035))
    (slots640.pos_x 35 38 36 f r (row_of_literal 35 _ (by decide) RawRows.raw0035))
    (slots640.inc_y 36 37 f r (row_of_literal 36 _ (by decide) RawRows.raw0036) (Or.inl (by decide)))
    (slots640.jump 37 35 f r (row_of_literal 37 _ (by decide) RawRows.raw0037))

theorem site0035 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((35:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((38:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0035Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


theorem site0038Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((38:Nat):V) f (vector r0 r1 r2 0 r4 r5 r6 r7 r8)) (config ((2924:Nat):V) f (vector r0 r1 r2 0 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 38 _ (row_of_literal 38 _ (by decide) RawRows.raw0038)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]

theorem site0038Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((38:Nat):V) f (vector r0 r1 r2 (r3+1) r4 r5 r6 r7 r8)) (config ((39:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 38 _ (row_of_literal 38 _ (by decide) RawRows.raw0038)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


theorem site0039Zero (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((39:Nat):V) f (vector r0 r1 r2 0 r4 r5 r6 r7 r8)) (config ((2850:Nat):V) f (vector r0 r1 r2 0 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 39 _ (row_of_literal 39 _ (by decide) RawRows.raw0039)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]

theorem site0039Positive (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((39:Nat):V) f (vector r0 r1 r2 (r3+1) r4 r5 r6 r7 r8)) (config ((40:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) := by
  apply Reach.once
  rw [step_at 39 _ (row_of_literal 39 _ (by decide) RawRows.raw0039)]
  simp [decoded,perform,chooseZero,vector,readReg,writeReg]


private theorem site0040Frame (f r : V) : ∀ x y z : V, Reach (slots867.atReg 40 f r x y z) (slots867.atReg 48 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots867.atReg (destination 40 8 48 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots867.zero_x 40 48 41 f r (row_of_literal 40 _ (by decide) RawRows.raw0040))
    (slots867.pos_x 40 48 41 f r (row_of_literal 40 _ (by decide) RawRows.raw0040))
    (slots867.inc_z 41 42 f r (row_of_literal 41 _ (by decide) RawRows.raw0041) (Or.inl (by decide)))
    (slots867.zero_y 42 44 43 f r (row_of_literal 42 _ (by decide) RawRows.raw0042))
    (slots867.pos_y 42 44 43 f r (row_of_literal 42 _ (by decide) RawRows.raw0042))
    (slots867.jump 43 47 f r (row_of_literal 43 _ (by decide) RawRows.raw0043))
    (slots867.zero_z 44 47 45 f r (row_of_literal 44 _ (by decide) RawRows.raw0044))
    (slots867.pos_z 44 47 45 f r (row_of_literal 44 _ (by decide) RawRows.raw0044))
    (slots867.inc_y 45 46 f r (row_of_literal 45 _ (by decide) RawRows.raw0045) (Or.inl (by decide)))
    (slots867.jump 46 44 f r (row_of_literal 46 _ (by decide) RawRows.raw0046))
    (slots867.jump 47 40 f r (row_of_literal 47 _ (by decide) RawRows.raw0047))

theorem site0040 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((40:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((48:Nat):V) f (vector r0 r1 r2 r3 r4 r5 (left (cantor r6 r7+r8)) (right (cantor r6 r7+r8)) 0)) := by
  simpa only [Slots.atReg,Slots.fill,slots867,vector,writeReg,pi₁_pair,pi₂_pair] using site0040Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r8 r6 r7


private theorem site0048Frame (f r : V) : ∀ x y z : V, Reach (slots780.atReg 48 f r x y z) (slots780.atReg 51 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots780.atReg (destination 48 3 51 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots780.zero_x 48 51 49 f r (row_of_literal 48 _ (by decide) RawRows.raw0048))
    (slots780.pos_x 48 51 49 f r (row_of_literal 48 _ (by decide) RawRows.raw0048))
    (slots780.inc_y 49 50 f r (row_of_literal 49 _ (by decide) RawRows.raw0049) (Or.inl (by decide)))
    (slots780.jump 50 48 f r (row_of_literal 50 _ (by decide) RawRows.raw0050))

theorem site0048 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((48:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((51:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 0 (r8+r7))) := by
  simpa only [Slots.atReg,Slots.fill,slots780,vector,writeReg,pi₁_pair,pi₂_pair] using site0048Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r8 r0


private theorem site0051Frame (f r : V) : ∀ x y z : V, Reach (slots650.atReg 51 f r x y z) (slots650.atReg 54 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots650.atReg (destination 51 3 54 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots650.zero_x 51 54 52 f r (row_of_literal 51 _ (by decide) RawRows.raw0051))
    (slots650.pos_x 51 54 52 f r (row_of_literal 51 _ (by decide) RawRows.raw0051))
    (slots650.inc_y 52 53 f r (row_of_literal 52 _ (by decide) RawRows.raw0052) (Or.inl (by decide)))
    (slots650.jump 53 51 f r (row_of_literal 53 _ (by decide) RawRows.raw0053))

theorem site0051 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((51:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((54:Nat):V) f (vector r0 r1 r2 r3 r4 (r5+r6) 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots650,vector,writeReg,pi₁_pair,pi₂_pair] using site0051Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r5 r0


private theorem site0054Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 54 f r x y z) (slots160.atReg 57 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 54 3 57 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 54 57 55 f r (row_of_literal 54 _ (by decide) RawRows.raw0054))
    (slots160.pos_x 54 57 55 f r (row_of_literal 54 _ (by decide) RawRows.raw0054))
    (slots160.inc_y 55 56 f r (row_of_literal 55 _ (by decide) RawRows.raw0055) (Or.inl (by decide)))
    (slots160.jump 56 54 f r (row_of_literal 56 _ (by decide) RawRows.raw0056))

theorem site0054 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((54:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((57:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0054Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0057Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 57 f r x y z) (slots210.atReg 60 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 57 3 60 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 57 60 58 f r (row_of_literal 57 _ (by decide) RawRows.raw0057))
    (slots210.pos_x 57 60 58 f r (row_of_literal 57 _ (by decide) RawRows.raw0057))
    (slots210.inc_y 58 59 f r (row_of_literal 58 _ (by decide) RawRows.raw0058) (Or.inl (by decide)))
    (slots210.jump 59 57 f r (row_of_literal 59 _ (by decide) RawRows.raw0059))

theorem site0057 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((57:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((60:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0057Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0060Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 60 f r x y z) (slots617.atReg 70 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 60 10 70 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 60 64 61 f r (row_of_literal 60 _ (by decide) RawRows.raw0060))
    (slots617.pos_y 60 64 61 f r (row_of_literal 60 _ (by decide) RawRows.raw0060))
    (slots617.inc_z 61 62 f r (row_of_literal 61 _ (by decide) RawRows.raw0061) (Or.inl (by decide)))
    (slots617.inc_x 62 63 f r (row_of_literal 62 _ (by decide) RawRows.raw0062) (Or.inl (by decide)))
    (slots617.jump 63 60 f r (row_of_literal 63 _ (by decide) RawRows.raw0063))
    (slots617.zero_x 64 70 65 f r (row_of_literal 64 _ (by decide) RawRows.raw0064))
    (slots617.pos_x 64 70 65 f r (row_of_literal 64 _ (by decide) RawRows.raw0064))
    (slots617.inc_z 65 66 f r (row_of_literal 65 _ (by decide) RawRows.raw0065) (Or.inl (by decide)))
    (slots617.zero_x 66 69 67 f r (row_of_literal 66 _ (by decide) RawRows.raw0066))
    (slots617.pos_x 66 69 67 f r (row_of_literal 66 _ (by decide) RawRows.raw0066))
    (slots617.inc_y 67 68 f r (row_of_literal 67 _ (by decide) RawRows.raw0067) (Or.inl (by decide)))
    (slots617.jump 68 66 f r (row_of_literal 68 _ (by decide) RawRows.raw0068))
    (slots617.jump 69 60 f r (row_of_literal 69 _ (by decide) RawRows.raw0069))

theorem site0060 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((60:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((70:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0060Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0070Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 70 f r x y z) (slots720.atReg 73 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 70 3 73 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 70 73 71 f r (row_of_literal 70 _ (by decide) RawRows.raw0070))
    (slots720.pos_x 70 73 71 f r (row_of_literal 70 _ (by decide) RawRows.raw0070))
    (slots720.inc_y 71 72 f r (row_of_literal 71 _ (by decide) RawRows.raw0071) (Or.inl (by decide)))
    (slots720.jump 72 70 f r (row_of_literal 72 _ (by decide) RawRows.raw0072))

theorem site0070 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((70:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((73:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0070Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0073Frame (f r : V) : ∀ x y z : V, Reach (slots361.atReg 73 f r x y z) (slots361.atReg 77 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots361.atReg (destination 73 4 77 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots361.zero_x 73 77 74 f r (row_of_literal 73 _ (by decide) RawRows.raw0073))
    (slots361.pos_x 73 77 74 f r (row_of_literal 73 _ (by decide) RawRows.raw0073))
    (slots361.inc_y 74 75 f r (row_of_literal 74 _ (by decide) RawRows.raw0074) (Or.inl (by decide)))
    (slots361.inc_z 75 76 f r (row_of_literal 75 _ (by decide) RawRows.raw0075) (Or.inl (by decide)))
    (slots361.jump 76 73 f r (row_of_literal 76 _ (by decide) RawRows.raw0076))

theorem site0073 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((73:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((77:Nat):V) f (vector r0 (r1+r3) r2 0 r4 r5 (r6+r3) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots361,vector,writeReg,pi₁_pair,pi₂_pair] using site0073Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r3 r6 r1


private theorem site0077Frame (f r : V) : ∀ x y z : V, Reach (slots630.atReg 77 f r x y z) (slots630.atReg 80 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots630.atReg (destination 77 3 80 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots630.zero_x 77 80 78 f r (row_of_literal 77 _ (by decide) RawRows.raw0077))
    (slots630.pos_x 77 80 78 f r (row_of_literal 77 _ (by decide) RawRows.raw0077))
    (slots630.inc_y 78 79 f r (row_of_literal 78 _ (by decide) RawRows.raw0078) (Or.inl (by decide)))
    (slots630.jump 79 77 f r (row_of_literal 79 _ (by decide) RawRows.raw0079))

theorem site0077 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((77:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((80:Nat):V) f (vector r0 r1 r2 (r3+r6) r4 r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots630,vector,writeReg,pi₁_pair,pi₂_pair] using site0077Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r3 r0


private theorem site0080Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 80 f r x y z) (slots160.atReg 83 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 80 3 83 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 80 83 81 f r (row_of_literal 80 _ (by decide) RawRows.raw0080))
    (slots160.pos_x 80 83 81 f r (row_of_literal 80 _ (by decide) RawRows.raw0080))
    (slots160.inc_y 81 82 f r (row_of_literal 81 _ (by decide) RawRows.raw0081) (Or.inl (by decide)))
    (slots160.jump 82 80 f r (row_of_literal 82 _ (by decide) RawRows.raw0082))

theorem site0080 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((80:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((83:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0080Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0083Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 83 f r x y z) (slots210.atReg 86 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 83 3 86 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 83 86 84 f r (row_of_literal 83 _ (by decide) RawRows.raw0083))
    (slots210.pos_x 83 86 84 f r (row_of_literal 83 _ (by decide) RawRows.raw0083))
    (slots210.inc_y 84 85 f r (row_of_literal 84 _ (by decide) RawRows.raw0084) (Or.inl (by decide)))
    (slots210.jump 85 83 f r (row_of_literal 85 _ (by decide) RawRows.raw0085))

theorem site0083 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((83:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((86:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0083Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0086Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 86 f r x y z) (slots617.atReg 96 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 86 10 96 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 86 90 87 f r (row_of_literal 86 _ (by decide) RawRows.raw0086))
    (slots617.pos_y 86 90 87 f r (row_of_literal 86 _ (by decide) RawRows.raw0086))
    (slots617.inc_z 87 88 f r (row_of_literal 87 _ (by decide) RawRows.raw0087) (Or.inl (by decide)))
    (slots617.inc_x 88 89 f r (row_of_literal 88 _ (by decide) RawRows.raw0088) (Or.inl (by decide)))
    (slots617.jump 89 86 f r (row_of_literal 89 _ (by decide) RawRows.raw0089))
    (slots617.zero_x 90 96 91 f r (row_of_literal 90 _ (by decide) RawRows.raw0090))
    (slots617.pos_x 90 96 91 f r (row_of_literal 90 _ (by decide) RawRows.raw0090))
    (slots617.inc_z 91 92 f r (row_of_literal 91 _ (by decide) RawRows.raw0091) (Or.inl (by decide)))
    (slots617.zero_x 92 95 93 f r (row_of_literal 92 _ (by decide) RawRows.raw0092))
    (slots617.pos_x 92 95 93 f r (row_of_literal 92 _ (by decide) RawRows.raw0092))
    (slots617.inc_y 93 94 f r (row_of_literal 93 _ (by decide) RawRows.raw0093) (Or.inl (by decide)))
    (slots617.jump 94 92 f r (row_of_literal 94 _ (by decide) RawRows.raw0094))
    (slots617.jump 95 86 f r (row_of_literal 95 _ (by decide) RawRows.raw0095))

theorem site0086 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((86:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((96:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0086Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0096Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 96 f r x y z) (slots720.atReg 99 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 96 3 99 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 96 99 97 f r (row_of_literal 96 _ (by decide) RawRows.raw0096))
    (slots720.pos_x 96 99 97 f r (row_of_literal 96 _ (by decide) RawRows.raw0096))
    (slots720.inc_y 97 98 f r (row_of_literal 97 _ (by decide) RawRows.raw0097) (Or.inl (by decide)))
    (slots720.jump 98 96 f r (row_of_literal 98 _ (by decide) RawRows.raw0098))

theorem site0096 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((96:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((99:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0096Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0099Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 99 f r x y z) (slots461.atReg 103 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 99 4 103 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 99 103 100 f r (row_of_literal 99 _ (by decide) RawRows.raw0099))
    (slots461.pos_x 99 103 100 f r (row_of_literal 99 _ (by decide) RawRows.raw0099))
    (slots461.inc_y 100 101 f r (row_of_literal 100 _ (by decide) RawRows.raw0100) (Or.inl (by decide)))
    (slots461.inc_z 101 102 f r (row_of_literal 101 _ (by decide) RawRows.raw0101) (Or.inl (by decide)))
    (slots461.jump 102 99 f r (row_of_literal 102 _ (by decide) RawRows.raw0102))

theorem site0099 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((99:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((103:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0099Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site0103Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 103 f r x y z) (slots640.atReg 106 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 103 3 106 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 103 106 104 f r (row_of_literal 103 _ (by decide) RawRows.raw0103))
    (slots640.pos_x 103 106 104 f r (row_of_literal 103 _ (by decide) RawRows.raw0103))
    (slots640.inc_y 104 105 f r (row_of_literal 104 _ (by decide) RawRows.raw0104) (Or.inl (by decide)))
    (slots640.jump 105 103 f r (row_of_literal 105 _ (by decide) RawRows.raw0105))

theorem site0103 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((103:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((106:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0103Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site0106Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 106 f r x y z) (slots267.atReg 114 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 106 8 114 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 106 114 107 f r (row_of_literal 106 _ (by decide) RawRows.raw0106))
    (slots267.pos_x 106 114 107 f r (row_of_literal 106 _ (by decide) RawRows.raw0106))
    (slots267.inc_z 107 108 f r (row_of_literal 107 _ (by decide) RawRows.raw0107) (Or.inl (by decide)))
    (slots267.zero_y 108 110 109 f r (row_of_literal 108 _ (by decide) RawRows.raw0108))
    (slots267.pos_y 108 110 109 f r (row_of_literal 108 _ (by decide) RawRows.raw0108))
    (slots267.jump 109 113 f r (row_of_literal 109 _ (by decide) RawRows.raw0109))
    (slots267.zero_z 110 113 111 f r (row_of_literal 110 _ (by decide) RawRows.raw0110))
    (slots267.pos_z 110 113 111 f r (row_of_literal 110 _ (by decide) RawRows.raw0110))
    (slots267.inc_y 111 112 f r (row_of_literal 111 _ (by decide) RawRows.raw0111) (Or.inl (by decide)))
    (slots267.jump 112 110 f r (row_of_literal 112 _ (by decide) RawRows.raw0112))
    (slots267.jump 113 106 f r (row_of_literal 113 _ (by decide) RawRows.raw0113))

theorem site0106 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((106:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((114:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0106Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0114Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 114 f r x y z) (slots720.atReg 117 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 114 3 117 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 114 117 115 f r (row_of_literal 114 _ (by decide) RawRows.raw0114))
    (slots720.pos_x 114 117 115 f r (row_of_literal 114 _ (by decide) RawRows.raw0114))
    (slots720.inc_y 115 116 f r (row_of_literal 115 _ (by decide) RawRows.raw0115) (Or.inl (by decide)))
    (slots720.jump 116 114 f r (row_of_literal 116 _ (by decide) RawRows.raw0116))

theorem site0114 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((114:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((117:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0114Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0117Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 117 f r x y z) (slots617.atReg 127 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 117 10 127 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 117 121 118 f r (row_of_literal 117 _ (by decide) RawRows.raw0117))
    (slots617.pos_y 117 121 118 f r (row_of_literal 117 _ (by decide) RawRows.raw0117))
    (slots617.inc_z 118 119 f r (row_of_literal 118 _ (by decide) RawRows.raw0118) (Or.inl (by decide)))
    (slots617.inc_x 119 120 f r (row_of_literal 119 _ (by decide) RawRows.raw0119) (Or.inl (by decide)))
    (slots617.jump 120 117 f r (row_of_literal 120 _ (by decide) RawRows.raw0120))
    (slots617.zero_x 121 127 122 f r (row_of_literal 121 _ (by decide) RawRows.raw0121))
    (slots617.pos_x 121 127 122 f r (row_of_literal 121 _ (by decide) RawRows.raw0121))
    (slots617.inc_z 122 123 f r (row_of_literal 122 _ (by decide) RawRows.raw0122) (Or.inl (by decide)))
    (slots617.zero_x 123 126 124 f r (row_of_literal 123 _ (by decide) RawRows.raw0123))
    (slots617.pos_x 123 126 124 f r (row_of_literal 123 _ (by decide) RawRows.raw0123))
    (slots617.inc_y 124 125 f r (row_of_literal 124 _ (by decide) RawRows.raw0124) (Or.inl (by decide)))
    (slots617.jump 125 123 f r (row_of_literal 125 _ (by decide) RawRows.raw0125))
    (slots617.jump 126 117 f r (row_of_literal 126 _ (by decide) RawRows.raw0126))

theorem site0117 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((117:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((127:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0117Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0127Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 127 f r x y z) (slots710.atReg 131 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 127 4 131 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 127 131 128 f r (row_of_literal 127 _ (by decide) RawRows.raw0127))
    (slots710.pos_x 127 131 128 f r (row_of_literal 127 _ (by decide) RawRows.raw0127))
    (slots710.inc_y 128 129 f r (row_of_literal 128 _ (by decide) RawRows.raw0128) (Or.inl (by decide)))
    (slots710.inc_y 129 130 f r (row_of_literal 129 _ (by decide) RawRows.raw0129) (Or.inl (by decide)))
    (slots710.jump 130 127 f r (row_of_literal 130 _ (by decide) RawRows.raw0130))

theorem site0127 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((127:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((131:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0127Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site0131Frame (f r : V) : ∀ x y z : V, Reach (slots867.atReg 131 f r x y z) (slots867.atReg 139 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots867.atReg (destination 131 8 139 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots867.zero_x 131 139 132 f r (row_of_literal 131 _ (by decide) RawRows.raw0131))
    (slots867.pos_x 131 139 132 f r (row_of_literal 131 _ (by decide) RawRows.raw0131))
    (slots867.inc_z 132 133 f r (row_of_literal 132 _ (by decide) RawRows.raw0132) (Or.inl (by decide)))
    (slots867.zero_y 133 135 134 f r (row_of_literal 133 _ (by decide) RawRows.raw0133))
    (slots867.pos_y 133 135 134 f r (row_of_literal 133 _ (by decide) RawRows.raw0133))
    (slots867.jump 134 138 f r (row_of_literal 134 _ (by decide) RawRows.raw0134))
    (slots867.zero_z 135 138 136 f r (row_of_literal 135 _ (by decide) RawRows.raw0135))
    (slots867.pos_z 135 138 136 f r (row_of_literal 135 _ (by decide) RawRows.raw0135))
    (slots867.inc_y 136 137 f r (row_of_literal 136 _ (by decide) RawRows.raw0136) (Or.inl (by decide)))
    (slots867.jump 137 135 f r (row_of_literal 137 _ (by decide) RawRows.raw0137))
    (slots867.jump 138 131 f r (row_of_literal 138 _ (by decide) RawRows.raw0138))

theorem site0131 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((131:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((139:Nat):V) f (vector r0 r1 r2 r3 r4 r5 (left (cantor r6 r7+r8)) (right (cantor r6 r7+r8)) 0)) := by
  simpa only [Slots.atReg,Slots.fill,slots867,vector,writeReg,pi₁_pair,pi₂_pair] using site0131Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r8 r6 r7


private theorem site0139Frame (f r : V) : ∀ x y z : V, Reach (slots780.atReg 139 f r x y z) (slots780.atReg 142 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots780.atReg (destination 139 3 142 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots780.zero_x 139 142 140 f r (row_of_literal 139 _ (by decide) RawRows.raw0139))
    (slots780.pos_x 139 142 140 f r (row_of_literal 139 _ (by decide) RawRows.raw0139))
    (slots780.inc_y 140 141 f r (row_of_literal 140 _ (by decide) RawRows.raw0140) (Or.inl (by decide)))
    (slots780.jump 141 139 f r (row_of_literal 141 _ (by decide) RawRows.raw0141))

theorem site0139 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((139:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((142:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 0 (r8+r7))) := by
  simpa only [Slots.atReg,Slots.fill,slots780,vector,writeReg,pi₁_pair,pi₂_pair] using site0139Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r8 r0


private theorem site0142Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 142 f r x y z) (slots640.atReg 145 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 142 3 145 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 142 145 143 f r (row_of_literal 142 _ (by decide) RawRows.raw0142))
    (slots640.pos_x 142 145 143 f r (row_of_literal 142 _ (by decide) RawRows.raw0142))
    (slots640.inc_y 143 144 f r (row_of_literal 143 _ (by decide) RawRows.raw0143) (Or.inl (by decide)))
    (slots640.jump 144 142 f r (row_of_literal 144 _ (by decide) RawRows.raw0144))

theorem site0142 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((142:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((145:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0142Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site0145Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 145 f r x y z) (slots160.atReg 148 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 145 3 148 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 145 148 146 f r (row_of_literal 145 _ (by decide) RawRows.raw0145))
    (slots160.pos_x 145 148 146 f r (row_of_literal 145 _ (by decide) RawRows.raw0145))
    (slots160.inc_y 146 147 f r (row_of_literal 146 _ (by decide) RawRows.raw0146) (Or.inl (by decide)))
    (slots160.jump 147 145 f r (row_of_literal 147 _ (by decide) RawRows.raw0147))

theorem site0145 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((145:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((148:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0145Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0148Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 148 f r x y z) (slots210.atReg 151 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 148 3 151 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 148 151 149 f r (row_of_literal 148 _ (by decide) RawRows.raw0148))
    (slots210.pos_x 148 151 149 f r (row_of_literal 148 _ (by decide) RawRows.raw0148))
    (slots210.inc_y 149 150 f r (row_of_literal 149 _ (by decide) RawRows.raw0149) (Or.inl (by decide)))
    (slots210.jump 150 148 f r (row_of_literal 150 _ (by decide) RawRows.raw0150))

theorem site0148 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((148:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((151:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0148Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0151Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 151 f r x y z) (slots617.atReg 161 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 151 10 161 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 151 155 152 f r (row_of_literal 151 _ (by decide) RawRows.raw0151))
    (slots617.pos_y 151 155 152 f r (row_of_literal 151 _ (by decide) RawRows.raw0151))
    (slots617.inc_z 152 153 f r (row_of_literal 152 _ (by decide) RawRows.raw0152) (Or.inl (by decide)))
    (slots617.inc_x 153 154 f r (row_of_literal 153 _ (by decide) RawRows.raw0153) (Or.inl (by decide)))
    (slots617.jump 154 151 f r (row_of_literal 154 _ (by decide) RawRows.raw0154))
    (slots617.zero_x 155 161 156 f r (row_of_literal 155 _ (by decide) RawRows.raw0155))
    (slots617.pos_x 155 161 156 f r (row_of_literal 155 _ (by decide) RawRows.raw0155))
    (slots617.inc_z 156 157 f r (row_of_literal 156 _ (by decide) RawRows.raw0156) (Or.inl (by decide)))
    (slots617.zero_x 157 160 158 f r (row_of_literal 157 _ (by decide) RawRows.raw0157))
    (slots617.pos_x 157 160 158 f r (row_of_literal 157 _ (by decide) RawRows.raw0157))
    (slots617.inc_y 158 159 f r (row_of_literal 158 _ (by decide) RawRows.raw0158) (Or.inl (by decide)))
    (slots617.jump 159 157 f r (row_of_literal 159 _ (by decide) RawRows.raw0159))
    (slots617.jump 160 151 f r (row_of_literal 160 _ (by decide) RawRows.raw0160))

theorem site0151 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((151:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((161:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0151Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0161Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 161 f r x y z) (slots720.atReg 164 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 161 3 164 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 161 164 162 f r (row_of_literal 161 _ (by decide) RawRows.raw0161))
    (slots720.pos_x 161 164 162 f r (row_of_literal 161 _ (by decide) RawRows.raw0161))
    (slots720.inc_y 162 163 f r (row_of_literal 162 _ (by decide) RawRows.raw0162) (Or.inl (by decide)))
    (slots720.jump 163 161 f r (row_of_literal 163 _ (by decide) RawRows.raw0163))

theorem site0161 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((161:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((164:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0161Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0164Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 164 f r x y z) (slots461.atReg 168 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 164 4 168 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 164 168 165 f r (row_of_literal 164 _ (by decide) RawRows.raw0164))
    (slots461.pos_x 164 168 165 f r (row_of_literal 164 _ (by decide) RawRows.raw0164))
    (slots461.inc_y 165 166 f r (row_of_literal 165 _ (by decide) RawRows.raw0165) (Or.inl (by decide)))
    (slots461.inc_z 166 167 f r (row_of_literal 166 _ (by decide) RawRows.raw0166) (Or.inl (by decide)))
    (slots461.jump 167 164 f r (row_of_literal 167 _ (by decide) RawRows.raw0167))

theorem site0164 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((164:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((168:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0164Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site0168Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 168 f r x y z) (slots640.atReg 171 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 168 3 171 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 168 171 169 f r (row_of_literal 168 _ (by decide) RawRows.raw0168))
    (slots640.pos_x 168 171 169 f r (row_of_literal 168 _ (by decide) RawRows.raw0168))
    (slots640.inc_y 169 170 f r (row_of_literal 169 _ (by decide) RawRows.raw0169) (Or.inl (by decide)))
    (slots640.jump 170 168 f r (row_of_literal 170 _ (by decide) RawRows.raw0170))

theorem site0168 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((168:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((171:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0168Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site0171Frame (f r : V) : ∀ x y z : V, Reach (slots267.atReg 171 f r x y z) (slots267.atReg 179 f r 0 (left (cantor y z+x)) (right (cantor y z+x))) :=
  @Templates.unpairBlock V _ _ (fun j=>slots267.atReg (destination 171 8 179 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots267.zero_x 171 179 172 f r (row_of_literal 171 _ (by decide) RawRows.raw0171))
    (slots267.pos_x 171 179 172 f r (row_of_literal 171 _ (by decide) RawRows.raw0171))
    (slots267.inc_z 172 173 f r (row_of_literal 172 _ (by decide) RawRows.raw0172) (Or.inl (by decide)))
    (slots267.zero_y 173 175 174 f r (row_of_literal 173 _ (by decide) RawRows.raw0173))
    (slots267.pos_y 173 175 174 f r (row_of_literal 173 _ (by decide) RawRows.raw0173))
    (slots267.jump 174 178 f r (row_of_literal 174 _ (by decide) RawRows.raw0174))
    (slots267.zero_z 175 178 176 f r (row_of_literal 175 _ (by decide) RawRows.raw0175))
    (slots267.pos_z 175 178 176 f r (row_of_literal 175 _ (by decide) RawRows.raw0175))
    (slots267.inc_y 176 177 f r (row_of_literal 176 _ (by decide) RawRows.raw0176) (Or.inl (by decide)))
    (slots267.jump 177 175 f r (row_of_literal 177 _ (by decide) RawRows.raw0177))
    (slots267.jump 178 171 f r (row_of_literal 178 _ (by decide) RawRows.raw0178))

theorem site0171 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((171:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((179:Nat):V) f (vector r0 r1 0 r3 r4 r5 (left (cantor r6 r7+r2)) (right (cantor r6 r7+r2)) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots267,vector,writeReg,pi₁_pair,pi₂_pair] using site0171Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r6 r7


private theorem site0179Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 179 f r x y z) (slots720.atReg 182 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 179 3 182 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 179 182 180 f r (row_of_literal 179 _ (by decide) RawRows.raw0179))
    (slots720.pos_x 179 182 180 f r (row_of_literal 179 _ (by decide) RawRows.raw0179))
    (slots720.inc_y 180 181 f r (row_of_literal 180 _ (by decide) RawRows.raw0180) (Or.inl (by decide)))
    (slots720.jump 181 179 f r (row_of_literal 181 _ (by decide) RawRows.raw0181))

theorem site0179 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((179:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((182:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0179Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0182Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 182 f r x y z) (slots617.atReg 192 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 182 10 192 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 182 186 183 f r (row_of_literal 182 _ (by decide) RawRows.raw0182))
    (slots617.pos_y 182 186 183 f r (row_of_literal 182 _ (by decide) RawRows.raw0182))
    (slots617.inc_z 183 184 f r (row_of_literal 183 _ (by decide) RawRows.raw0183) (Or.inl (by decide)))
    (slots617.inc_x 184 185 f r (row_of_literal 184 _ (by decide) RawRows.raw0184) (Or.inl (by decide)))
    (slots617.jump 185 182 f r (row_of_literal 185 _ (by decide) RawRows.raw0185))
    (slots617.zero_x 186 192 187 f r (row_of_literal 186 _ (by decide) RawRows.raw0186))
    (slots617.pos_x 186 192 187 f r (row_of_literal 186 _ (by decide) RawRows.raw0186))
    (slots617.inc_z 187 188 f r (row_of_literal 187 _ (by decide) RawRows.raw0187) (Or.inl (by decide)))
    (slots617.zero_x 188 191 189 f r (row_of_literal 188 _ (by decide) RawRows.raw0188))
    (slots617.pos_x 188 191 189 f r (row_of_literal 188 _ (by decide) RawRows.raw0188))
    (slots617.inc_y 189 190 f r (row_of_literal 189 _ (by decide) RawRows.raw0189) (Or.inl (by decide)))
    (slots617.jump 190 188 f r (row_of_literal 190 _ (by decide) RawRows.raw0190))
    (slots617.jump 191 182 f r (row_of_literal 191 _ (by decide) RawRows.raw0191))

theorem site0182 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((182:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((192:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0182Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0192Frame (f r : V) : ∀ x y z : V, Reach (slots710.atReg 192 f r x y z) (slots710.atReg 196 f r 0 (y+2*x) z) :=
  @Templates.doubleBlock V _ _ (fun j=>slots710.atReg (destination 192 4 196 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots710.zero_x 192 196 193 f r (row_of_literal 192 _ (by decide) RawRows.raw0192))
    (slots710.pos_x 192 196 193 f r (row_of_literal 192 _ (by decide) RawRows.raw0192))
    (slots710.inc_y 193 194 f r (row_of_literal 193 _ (by decide) RawRows.raw0193) (Or.inl (by decide)))
    (slots710.inc_y 194 195 f r (row_of_literal 194 _ (by decide) RawRows.raw0194) (Or.inl (by decide)))
    (slots710.jump 195 192 f r (row_of_literal 195 _ (by decide) RawRows.raw0195))

theorem site0192 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((192:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((196:Nat):V) f (vector r0 (r1+2*r7) r2 r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots710,vector,writeReg,pi₁_pair,pi₂_pair] using site0192Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r1 r0


private theorem site0196Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 196 f r x y z) (slots160.atReg 199 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 196 3 199 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 196 199 197 f r (row_of_literal 196 _ (by decide) RawRows.raw0196))
    (slots160.pos_x 196 199 197 f r (row_of_literal 196 _ (by decide) RawRows.raw0196))
    (slots160.inc_y 197 198 f r (row_of_literal 197 _ (by decide) RawRows.raw0197) (Or.inl (by decide)))
    (slots160.jump 198 196 f r (row_of_literal 198 _ (by decide) RawRows.raw0198))

theorem site0196 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((196:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((199:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0196Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


private theorem site0199Frame (f r : V) : ∀ x y z : V, Reach (slots210.atReg 199 f r x y z) (slots210.atReg 202 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots210.atReg (destination 199 3 202 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots210.zero_x 199 202 200 f r (row_of_literal 199 _ (by decide) RawRows.raw0199))
    (slots210.pos_x 199 202 200 f r (row_of_literal 199 _ (by decide) RawRows.raw0199))
    (slots210.inc_y 200 201 f r (row_of_literal 200 _ (by decide) RawRows.raw0200) (Or.inl (by decide)))
    (slots210.jump 201 199 f r (row_of_literal 201 _ (by decide) RawRows.raw0201))

theorem site0199 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((199:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((202:Nat):V) f (vector r0 (r1+r2) 0 r3 r4 r5 r6 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots210,vector,writeReg,pi₁_pair,pi₂_pair] using site0199Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r2 r1 r0


private theorem site0202Frame (f r : V) : ∀ x y z : V, Reach (slots617.atReg 202 f r x y z) (slots617.atReg 212 f r 0 0 (z+cantor x y)) :=
  @Templates.pairBlock V _ _ (fun j=>slots617.atReg (destination 202 10 212 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots617.zero_y 202 206 203 f r (row_of_literal 202 _ (by decide) RawRows.raw0202))
    (slots617.pos_y 202 206 203 f r (row_of_literal 202 _ (by decide) RawRows.raw0202))
    (slots617.inc_z 203 204 f r (row_of_literal 203 _ (by decide) RawRows.raw0203) (Or.inl (by decide)))
    (slots617.inc_x 204 205 f r (row_of_literal 204 _ (by decide) RawRows.raw0204) (Or.inl (by decide)))
    (slots617.jump 205 202 f r (row_of_literal 205 _ (by decide) RawRows.raw0205))
    (slots617.zero_x 206 212 207 f r (row_of_literal 206 _ (by decide) RawRows.raw0206))
    (slots617.pos_x 206 212 207 f r (row_of_literal 206 _ (by decide) RawRows.raw0206))
    (slots617.inc_z 207 208 f r (row_of_literal 207 _ (by decide) RawRows.raw0207) (Or.inl (by decide)))
    (slots617.zero_x 208 211 209 f r (row_of_literal 208 _ (by decide) RawRows.raw0208))
    (slots617.pos_x 208 211 209 f r (row_of_literal 208 _ (by decide) RawRows.raw0208))
    (slots617.inc_y 209 210 f r (row_of_literal 209 _ (by decide) RawRows.raw0209) (Or.inl (by decide)))
    (slots617.jump 210 208 f r (row_of_literal 210 _ (by decide) RawRows.raw0210))
    (slots617.jump 211 202 f r (row_of_literal 211 _ (by decide) RawRows.raw0211))

theorem site0202 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((202:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((212:Nat):V) f (vector r0 0 r2 r3 r4 r5 0 (r7+cantor r6 r1) r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots617,vector,writeReg,pi₁_pair,pi₂_pair] using site0202Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r1 r7


private theorem site0212Frame (f r : V) : ∀ x y z : V, Reach (slots720.atReg 212 f r x y z) (slots720.atReg 215 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots720.atReg (destination 212 3 215 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots720.zero_x 212 215 213 f r (row_of_literal 212 _ (by decide) RawRows.raw0212))
    (slots720.pos_x 212 215 213 f r (row_of_literal 212 _ (by decide) RawRows.raw0212))
    (slots720.inc_y 213 214 f r (row_of_literal 213 _ (by decide) RawRows.raw0213) (Or.inl (by decide)))
    (slots720.jump 214 212 f r (row_of_literal 214 _ (by decide) RawRows.raw0214))

theorem site0212 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((212:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((215:Nat):V) f (vector r0 r1 (r2+r7) r3 r4 r5 r6 0 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots720,vector,writeReg,pi₁_pair,pi₂_pair] using site0212Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r7 r2 r0


private theorem site0215Frame (f r : V) : ∀ x y z : V, Reach (slots461.atReg 215 f r x y z) (slots461.atReg 219 f r 0 (y+x) (z+x)) :=
  @Templates.copyBlock V _ _ (fun j=>slots461.atReg (destination 215 4 219 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots461.zero_x 215 219 216 f r (row_of_literal 215 _ (by decide) RawRows.raw0215))
    (slots461.pos_x 215 219 216 f r (row_of_literal 215 _ (by decide) RawRows.raw0215))
    (slots461.inc_y 216 217 f r (row_of_literal 216 _ (by decide) RawRows.raw0216) (Or.inl (by decide)))
    (slots461.inc_z 217 218 f r (row_of_literal 217 _ (by decide) RawRows.raw0217) (Or.inl (by decide)))
    (slots461.jump 218 215 f r (row_of_literal 218 _ (by decide) RawRows.raw0218))

theorem site0215 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((215:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((219:Nat):V) f (vector r0 (r1+r4) r2 r3 0 r5 (r6+r4) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots461,vector,writeReg,pi₁_pair,pi₂_pair] using site0215Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r4 r6 r1


private theorem site0219Frame (f r : V) : ∀ x y z : V, Reach (slots640.atReg 219 f r x y z) (slots640.atReg 222 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots640.atReg (destination 219 3 222 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots640.zero_x 219 222 220 f r (row_of_literal 219 _ (by decide) RawRows.raw0219))
    (slots640.pos_x 219 222 220 f r (row_of_literal 219 _ (by decide) RawRows.raw0219))
    (slots640.inc_y 220 221 f r (row_of_literal 220 _ (by decide) RawRows.raw0220) (Or.inl (by decide)))
    (slots640.jump 221 219 f r (row_of_literal 221 _ (by decide) RawRows.raw0221))

theorem site0219 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((219:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((222:Nat):V) f (vector r0 r1 r2 r3 (r4+r6) r5 0 r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots640,vector,writeReg,pi₁_pair,pi₂_pair] using site0219Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r6 r4 r0


private theorem site0222Frame (f r : V) : ∀ x y z : V, Reach (slots160.atReg 222 f r x y z) (slots160.atReg 225 f r 0 (y+x) z) :=
  @Templates.transferBlock V _ _ (fun j=>slots160.atReg (destination 222 3 225 4095 j) f r) (fun _=>Slots.frameDef ..)
    (slots160.zero_x 222 225 223 f r (row_of_literal 222 _ (by decide) RawRows.raw0222))
    (slots160.pos_x 222 225 223 f r (row_of_literal 222 _ (by decide) RawRows.raw0222))
    (slots160.inc_y 223 224 f r (row_of_literal 223 _ (by decide) RawRows.raw0223) (Or.inl (by decide)))
    (slots160.jump 224 222 f r (row_of_literal 224 _ (by decide) RawRows.raw0224))

theorem site0222 (f r0 r1 r2 r3 r4 r5 r6 r7 r8 : V) : Reach (config ((222:Nat):V) f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8)) (config ((225:Nat):V) f (vector r0 0 r2 r3 r4 r5 (r6+r1) r7 r8)) := by
  simpa only [Slots.atReg,Slots.fill,slots160,vector,writeReg,pi₁_pair,pi₂_pair] using site0222Frame f (vector r0 r1 r2 r3 r4 r5 r6 r7 r8) r1 r6 r0


end PA192.ModelSearch.Register181.Certified
