module
public import Src181CmdEmit13
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter449 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2170:Nat):V) f (vector n (v+y) (emitAtom73 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2166 f n 0 (emitAtom73 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter448 f n t s c u v y d w).trans mid

theorem commandEmitAfter450 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2173:Nat):V) f (vector n (v+y) (emitAtom73 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2170 f n (v+y) (emitAtom73 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter449 f n t s c u v y d w).trans mid

theorem commandEmitAfter451 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2181:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (v+y) (emitAtom72 n t s c u v y d w) w)) := by
  have micro := site2173 f n (v+y) (emitAtom73 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom73 n t s c u v y d w))):V)=(v+y) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom73 n t s c u v y d w)):V)=(0+(emitAtom73 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom73 n t s c u v y d w))):V)=left (emitAtom73 n t s c u v y d w))).trans (by change left (cantor (v+y) (emitAtom72 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom73 n t s c u v y d w))):V)=(emitAtom72 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom73 n t s c u v y d w)):V)=(0+(emitAtom73 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom73 n t s c u v y d w))):V)=right (emitAtom73 n t s c u v y d w))).trans (by change right (cantor (v+y) (emitAtom72 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter450 f n t s c u v y d w).trans mid

theorem commandEmitAfter452 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2184:Nat):V) f (vector n (v+y) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w)) := by
  have micro := site2181 f n (v+y) 0 c (d+u) (v+y) (v+y) (emitAtom72 n t s c u v y d w) w
  have d2 : ((0+(emitAtom72 n t s c u v y d w)):V)=(emitAtom72 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter451 f n t s c u v y d w).trans mid

theorem commandEmitAfter453 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2194:Nat):V) f (vector n 0 (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom17 n t s c u v y d w) w)) := by
  have micro := site2184 f n (v+y) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) (v+y) 0 w
  have d7 : ((0+(cantor (v+y) (v+y))):V)=(emitAtom17 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (v+y) (v+y))):V)=(0+(emitAtom17 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter452 f n t s c u v y d w).trans mid

theorem commandEmitAfter454 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2198:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2194 f n 0 (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom17 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom17 n t s c u v y d w))):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom17 n t s c u v y d w))):V)=(0+((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter453 f n t s c u v y d w).trans mid

theorem commandEmitAfter455 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2199:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2198 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w))+1):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter454 f n t s c u v y d w).trans mid

theorem commandEmitAfter456 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2200:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2199 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+1)+1):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter455 f n t s c u v y d w).trans mid

theorem commandEmitAfter457 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2208:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) 0 (emitAtom71 n t s c u v y d w) w)) := by
  have micro := site2200 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom72 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom72 n t s c u v y d w))):V)=0 := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom72 n t s c u v y d w)):V)=(0+(emitAtom72 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom72 n t s c u v y d w))):V)=left (emitAtom72 n t s c u v y d w))).trans (by change left (cantor 0 (emitAtom71 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom72 n t s c u v y d w))):V)=(emitAtom71 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom72 n t s c u v y d w)):V)=(0+(emitAtom72 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom72 n t s c u v y d w))):V)=right (emitAtom72 n t s c u v y d w))).trans (by change right (cantor 0 (emitAtom71 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter456 f n t s c u v y d w).trans mid

theorem commandEmitAfter458 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2211:Nat):V) f (vector n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2208 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 c (d+u) (v+y) 0 (emitAtom71 n t s c u v y d w) w
  have d2 : ((0+(emitAtom71 n t s c u v y d w)):V)=(emitAtom71 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter457 f n t s c u v y d w).trans mid

theorem commandEmitAfter459 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2221:Nat):V) f (vector n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom66 n t s c u v y d w) w)) := by
  have micro := site2211 f n ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d7 : ((0+(cantor 0 ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2))):V)=(emitAtom66 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor 0 ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2))):V)=(0+(emitAtom66 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter458 f n t s c u v y d w).trans mid

theorem commandEmitAfter460 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2225:Nat):V) f (vector n ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2221 f n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom66 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom66 n t s c u v y d w))):V)=((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom66 n t s c u v y d w))):V)=(0+((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter459 f n t s c u v y d w).trans mid

theorem commandEmitAfter461 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2226:Nat):V) f (vector n ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2225 f n ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w))+1):V)=((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter460 f n t s c u v y d w).trans mid

theorem commandEmitAfter462 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2229:Nat):V) f (vector n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2226 f n ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1)):V)=((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter461 f n t s c u v y d w).trans mid

theorem commandEmitAfter463 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2232:Nat):V) f (vector n (emitAtom71 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2229 f n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom71 n t s c u v y d w)):V)=(emitAtom71 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter462 f n t s c u v y d w).trans mid

theorem commandEmitAfter464 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2242:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom74 n t s c u v y d w) w)) := by
  have micro := site2232 f n (emitAtom71 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w))):V)=(emitAtom74 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w))):V)=(0+(emitAtom74 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter463 f n t s c u v y d w).trans mid

theorem commandEmitAfter465 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2245:Nat):V) f (vector n 0 (emitAtom74 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2242 f n 0 0 c (d+u) (v+y) 0 (emitAtom74 n t s c u v y d w) w
  have d2 : ((0+(emitAtom74 n t s c u v y d w)):V)=(emitAtom74 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter464 f n t s c u v y d w).trans mid

theorem commandEmitAfter466 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2249:Nat):V) f (vector n (v+y) (emitAtom74 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2245 f n 0 (emitAtom74 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter465 f n t s c u v y d w).trans mid

theorem commandEmitAfter467 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2252:Nat):V) f (vector n (v+y) (emitAtom74 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2249 f n (v+y) (emitAtom74 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter466 f n t s c u v y d w).trans mid

theorem commandEmitAfter468 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2260:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) w)) := by
  have micro := site2252 f n (v+y) (emitAtom74 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom74 n t s c u v y d w))):V)=((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom74 n t s c u v y d w)):V)=(0+(emitAtom74 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom74 n t s c u v y d w))):V)=left (emitAtom74 n t s c u v y d w))).trans (by change left (cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom74 n t s c u v y d w))):V)=(emitAtom71 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom74 n t s c u v y d w)):V)=(0+(emitAtom74 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom74 n t s c u v y d w))):V)=right (emitAtom74 n t s c u v y d w))).trans (by change right (cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter467 f n t s c u v y d w).trans mid

theorem commandEmitAfter469 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2263:Nat):V) f (vector n (v+y) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2260 f n (v+y) 0 c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) w
  have d2 : ((0+(emitAtom71 n t s c u v y d w)):V)=(emitAtom71 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter468 f n t s c u v y d w).trans mid

theorem commandEmitAfter470 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2273:Nat):V) f (vector n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom75 n t s c u v y d w) w)) := by
  have micro := site2263 f n (v+y) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (v+y))):V)=(emitAtom75 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom66 n t s c u v y d w)+(emitAtom66 n t s c u v y d w)+1) (v+y))):V)=(0+(emitAtom75 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter469 f n t s c u v y d w).trans mid

theorem commandEmitAfter471 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2277:Nat):V) f (vector n ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2273 f n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom75 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom75 n t s c u v y d w))):V)=((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom75 n t s c u v y d w))):V)=(0+((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter470 f n t s c u v y d w).trans mid

theorem commandEmitAfter472 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2278:Nat):V) f (vector n ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2277 f n ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w))+1):V)=((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter471 f n t s c u v y d w).trans mid

theorem commandEmitAfter473 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2281:Nat):V) f (vector n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2278 f n ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1)):V)=((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter472 f n t s c u v y d w).trans mid

theorem commandEmitAfter474 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2284:Nat):V) f (vector n (emitAtom71 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2281 f n 0 (emitAtom71 n t s c u v y d w) c (d+u) (v+y) ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom71 n t s c u v y d w)):V)=(emitAtom71 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter473 f n t s c u v y d w).trans mid

theorem commandEmitAfter475 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2294:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom76 n t s c u v y d w) w)) := by
  have micro := site2284 f n (emitAtom71 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w))):V)=(emitAtom76 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w))):V)=(0+(emitAtom76 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter474 f n t s c u v y d w).trans mid

theorem commandEmitAfter476 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2297:Nat):V) f (vector n 0 (emitAtom76 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2294 f n 0 0 c (d+u) (v+y) 0 (emitAtom76 n t s c u v y d w) w
  have d2 : ((0+(emitAtom76 n t s c u v y d w)):V)=(emitAtom76 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter475 f n t s c u v y d w).trans mid

theorem commandEmitAfter477 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2301:Nat):V) f (vector n (v+y) (emitAtom76 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site2297 f n 0 (emitAtom76 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter476 f n t s c u v y d w).trans mid

theorem commandEmitAfter478 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2304:Nat):V) f (vector n (v+y) (emitAtom76 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site2301 f n (v+y) (emitAtom76 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter477 f n t s c u v y d w).trans mid

theorem commandEmitAfter479 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2312:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) w)) := by
  have micro := site2304 f n (v+y) (emitAtom76 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom76 n t s c u v y d w))):V)=((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom76 n t s c u v y d w)):V)=(0+(emitAtom76 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom76 n t s c u v y d w))):V)=left (emitAtom76 n t s c u v y d w))).trans (by change left (cantor ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom76 n t s c u v y d w))):V)=(emitAtom71 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom76 n t s c u v y d w)):V)=(0+(emitAtom76 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom76 n t s c u v y d w))):V)=right (emitAtom76 n t s c u v y d w))).trans (by change right (cantor ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter478 f n t s c u v y d w).trans mid

theorem commandEmitAfter480 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((2315:Nat):V) f (vector n (v+y) (emitAtom71 n t s c u v y d w) c (d+u) (v+y) ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) 0 w)) := by
  have micro := site2312 f n (v+y) 0 c (d+u) (v+y) ((emitAtom75 n t s c u v y d w)+(emitAtom75 n t s c u v y d w)+1) (emitAtom71 n t s c u v y d w) w
  have d2 : ((0+(emitAtom71 n t s c u v y d w)):V)=(emitAtom71 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter479 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
