module
public import Src181CmdEmit02
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter97 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((513:Nat):V) f (vector n (d+u) 0 c (d+u) (v+y) ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom15 n t s c u v y d w) w)) := by
  have micro := site0505 f n (d+u) (emitAtom18 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom18 n t s c u v y d w))):V)=((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom18 n t s c u v y d w)):V)=(0+(emitAtom18 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom18 n t s c u v y d w))):V)=left (emitAtom18 n t s c u v y d w))).trans (by change left (cantor ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom15 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom18 n t s c u v y d w))):V)=(emitAtom15 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom18 n t s c u v y d w)):V)=(0+(emitAtom18 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom18 n t s c u v y d w))):V)=right (emitAtom18 n t s c u v y d w))).trans (by change right (cantor ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom15 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter96 f n t s c u v y d w).trans mid

theorem commandEmitAfter98 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((516:Nat):V) f (vector n (d+u) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 w)) := by
  have micro := site0513 f n (d+u) 0 c (d+u) (v+y) ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (emitAtom15 n t s c u v y d w) w
  have d2 : ((0+(emitAtom15 n t s c u v y d w)):V)=(emitAtom15 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter97 f n t s c u v y d w).trans mid

theorem commandEmitAfter99 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((526:Nat):V) f (vector n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom19 n t s c u v y d w) w)) := by
  have micro := site0516 f n (d+u) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) 0 w
  have d7 : ((0+(cantor ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (d+u))):V)=(emitAtom19 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom17 n t s c u v y d w)+(emitAtom17 n t s c u v y d w)+2) (d+u))):V)=(0+(emitAtom19 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter98 f n t s c u v y d w).trans mid

theorem commandEmitAfter100 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((530:Nat):V) f (vector n ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0526 f n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom19 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom19 n t s c u v y d w))):V)=((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom19 n t s c u v y d w))):V)=(0+((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter99 f n t s c u v y d w).trans mid

theorem commandEmitAfter101 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((531:Nat):V) f (vector n ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0530 f n ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w))+1):V)=((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter100 f n t s c u v y d w).trans mid

theorem commandEmitAfter102 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((534:Nat):V) f (vector n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0531 f n ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1)):V)=((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter101 f n t s c u v y d w).trans mid

theorem commandEmitAfter103 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((537:Nat):V) f (vector n (emitAtom15 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0534 f n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom15 n t s c u v y d w)):V)=(emitAtom15 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter102 f n t s c u v y d w).trans mid

theorem commandEmitAfter104 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((547:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom20 n t s c u v y d w) w)) := by
  have micro := site0537 f n (emitAtom15 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w))):V)=(emitAtom20 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w))):V)=(0+(emitAtom20 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter103 f n t s c u v y d w).trans mid

theorem commandEmitAfter105 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((550:Nat):V) f (vector n 0 (emitAtom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0547 f n 0 0 c (d+u) (v+y) 0 (emitAtom20 n t s c u v y d w) w
  have d2 : ((0+(emitAtom20 n t s c u v y d w)):V)=(emitAtom20 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter104 f n t s c u v y d w).trans mid

theorem commandEmitAfter106 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((554:Nat):V) f (vector n (v+y) (emitAtom20 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0550 f n 0 (emitAtom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter105 f n t s c u v y d w).trans mid

theorem commandEmitAfter107 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((557:Nat):V) f (vector n (v+y) (emitAtom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0554 f n (v+y) (emitAtom20 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter106 f n t s c u v y d w).trans mid

theorem commandEmitAfter108 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((565:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w) w)) := by
  have micro := site0557 f n (v+y) (emitAtom20 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom20 n t s c u v y d w))):V)=((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom20 n t s c u v y d w)):V)=(0+(emitAtom20 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom20 n t s c u v y d w))):V)=left (emitAtom20 n t s c u v y d w))).trans (by change left (cantor ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom20 n t s c u v y d w))):V)=(emitAtom15 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom20 n t s c u v y d w)):V)=(0+(emitAtom20 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom20 n t s c u v y d w))):V)=right (emitAtom20 n t s c u v y d w))).trans (by change right (cantor ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter107 f n t s c u v y d w).trans mid

theorem commandEmitAfter109 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((568:Nat):V) f (vector n (v+y) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0565 f n (v+y) 0 c (d+u) (v+y) ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w) w
  have d2 : ((0+(emitAtom15 n t s c u v y d w)):V)=(emitAtom15 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter108 f n t s c u v y d w).trans mid

theorem commandEmitAfter110 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((578:Nat):V) f (vector n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom21 n t s c u v y d w) w)) := by
  have micro := site0568 f n (v+y) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (v+y))):V)=(emitAtom21 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom19 n t s c u v y d w)+(emitAtom19 n t s c u v y d w)+1) (v+y))):V)=(0+(emitAtom21 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter109 f n t s c u v y d w).trans mid

theorem commandEmitAfter111 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((582:Nat):V) f (vector n ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0578 f n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom21 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom21 n t s c u v y d w))):V)=((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom21 n t s c u v y d w))):V)=(0+((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter110 f n t s c u v y d w).trans mid

theorem commandEmitAfter112 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((583:Nat):V) f (vector n ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0582 f n ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w))+1):V)=((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter111 f n t s c u v y d w).trans mid

theorem commandEmitAfter113 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((586:Nat):V) f (vector n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0583 f n ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1)):V)=((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter112 f n t s c u v y d w).trans mid

theorem commandEmitAfter114 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((589:Nat):V) f (vector n (emitAtom15 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) 0 w)) := by
  have micro := site0586 f n 0 (emitAtom15 n t s c u v y d w) c (d+u) (v+y) ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom15 n t s c u v y d w)):V)=(emitAtom15 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter113 f n t s c u v y d w).trans mid

theorem commandEmitAfter115 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((599:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom22 n t s c u v y d w) w)) := by
  have micro := site0589 f n (emitAtom15 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w))):V)=(emitAtom22 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) (emitAtom15 n t s c u v y d w))):V)=(0+(emitAtom22 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter114 f n t s c u v y d w).trans mid

theorem commandEmitAfter116 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((602:Nat):V) f (vector n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0599 f n 0 0 c (d+u) (v+y) 0 (emitAtom22 n t s c u v y d w) w
  have d2 : ((0+(emitAtom22 n t s c u v y d w)):V)=(emitAtom22 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter115 f n t s c u v y d w).trans mid

theorem commandEmitAfter117 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((606:Nat):V) f (vector n (d+u) (emitAtom22 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site0602 f n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter116 f n t s c u v y d w).trans mid

theorem commandEmitAfter118 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((609:Nat):V) f (vector n (d+u) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0606 f n (d+u) (emitAtom22 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter117 f n t s c u v y d w).trans mid

theorem commandEmitAfter119 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((612:Nat):V) f (vector n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0609 f n (d+u) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter118 f n t s c u v y d w).trans mid

theorem commandEmitAfter120 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((615:Nat):V) f (vector n (emitAtom22 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0612 f n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d1 : ((0+(emitAtom22 n t s c u v y d w)):V)=(emitAtom22 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter119 f n t s c u v y d w).trans mid

theorem commandEmitAfter121 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((625:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom23 n t s c u v y d w) w)) := by
  have micro := site0615 f n (emitAtom22 n t s c u v y d w) 0 c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (emitAtom22 n t s c u v y d w))):V)=(emitAtom23 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (emitAtom22 n t s c u v y d w))):V)=(0+(emitAtom23 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter120 f n t s c u v y d w).trans mid

theorem commandEmitAfter122 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((628:Nat):V) f (vector n 0 (emitAtom23 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0625 f n 0 0 c (d+u) (v+y) 0 (emitAtom23 n t s c u v y d w) w
  have d2 : ((0+(emitAtom23 n t s c u v y d w)):V)=(emitAtom23 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter121 f n t s c u v y d w).trans mid

theorem commandEmitAfter123 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((632:Nat):V) f (vector n (v+y) (emitAtom23 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site0628 f n 0 (emitAtom23 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter122 f n t s c u v y d w).trans mid

theorem commandEmitAfter124 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((635:Nat):V) f (vector n (v+y) (emitAtom23 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0632 f n (v+y) (emitAtom23 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter123 f n t s c u v y d w).trans mid

theorem commandEmitAfter125 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((643:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom22 n t s c u v y d w) w)) := by
  have micro := site0635 f n (v+y) (emitAtom23 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom23 n t s c u v y d w))):V)=(d+u) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom23 n t s c u v y d w)):V)=(0+(emitAtom23 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom23 n t s c u v y d w))):V)=left (emitAtom23 n t s c u v y d w))).trans (by change left (cantor (d+u) (emitAtom22 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom23 n t s c u v y d w))):V)=(emitAtom22 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom23 n t s c u v y d w)):V)=(0+(emitAtom23 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom23 n t s c u v y d w))):V)=right (emitAtom23 n t s c u v y d w))).trans (by change right (cantor (d+u) (emitAtom22 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter124 f n t s c u v y d w).trans mid

theorem commandEmitAfter126 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((646:Nat):V) f (vector n (v+y) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w)) := by
  have micro := site0643 f n (v+y) 0 c (d+u) (v+y) (d+u) (emitAtom22 n t s c u v y d w) w
  have d2 : ((0+(emitAtom22 n t s c u v y d w)):V)=(emitAtom22 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter125 f n t s c u v y d w).trans mid

theorem commandEmitAfter127 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((656:Nat):V) f (vector n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w)) := by
  have micro := site0646 f n (v+y) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) (d+u) 0 w
  have d7 : ((0+(cantor (d+u) (v+y))):V)=(emitAtom24 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor (d+u) (v+y))):V)=(0+(emitAtom24 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter126 f n t s c u v y d w).trans mid

theorem commandEmitAfter128 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((660:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site0656 f n 0 (emitAtom22 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom24 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom24 n t s c u v y d w))):V)=(0+((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter127 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
