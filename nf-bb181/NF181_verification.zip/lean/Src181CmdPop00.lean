module
public import Src181Atoms
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandPopAfter1 (f n t s c u v y d w : V) : Reach (config ((2957:Nat):V) f (vector n t s c u 0 0 0 w)) (config ((2965:Nat):V) f (vector n t 0 c u 0 (atom95 n t s c u v y d w) (atom96 n t s c u v y d w) w)) := by
  have micro := site2957 f n t s c u 0 0 0 w
  have d6 : (left ((cantor 0 0)+s):V)=atom95 n t s c u v y d w := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+s:V)=0+s).trans (by ring)) : (left ((cantor 0 0)+s):V)=left s).trans (rfl)
  have d7 : (right ((cantor 0 0)+s):V)=atom96 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+s:V)=0+s).trans (by ring)) : (right ((cantor 0 0)+s):V)=right s).trans (rfl)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact mid

theorem commandPopAfter2 (f n t s c u v y d w : V) : Reach (config ((2957:Nat):V) f (vector n t s c u 0 0 0 w)) (config ((2968:Nat):V) f (vector n t (atom96 n t s c u v y d w) c u 0 (atom95 n t s c u v y d w) 0 w)) := by
  have micro := site2965 f n t 0 c u 0 (atom95 n t s c u v y d w) (atom96 n t s c u v y d w) w
  have d2 : (0+(atom96 n t s c u v y d w):V)=atom96 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandPopAfter1 f n t s c u v y d w).trans mid

theorem commandPop (f n t s c u v y d w : V) : Reach (config ((2957:Nat):V) f (vector n t s c u 0 0 0 w)) (config ((0:Nat):V) f (vector n t (atom96 n t s c u v y d w) c u (atom95 n t s c u v y d w) 0 0 w)) := by
  have micro := site2968 f n t (atom96 n t s c u v y d w) c u 0 (atom95 n t s c u v y d w) 0 w
  have d5 : (0+(atom95 n t s c u v y d w):V)=atom95 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandPopAfter2 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
