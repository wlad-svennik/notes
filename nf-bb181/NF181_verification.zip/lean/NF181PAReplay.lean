import NF181PA
import Direct181Frames
import NumericalBound


open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic FFL.Entailment
open scoped FFL.FirstOrder.Arithmetic
open NF210.TM PA192.LiteralTM PA192.BusyBeaver

namespace NF181PA

/-- Halting within a fixed standard number of steps. -/
def byStep (k : Nat) : ArithmeticSentence := beforeF Direct181.Table.machine Direct181.Table.start k

/-- A finite live prefix yields a proof in object PA that the selected
181-state table did not halt within that many ticks. -/
theorem pa_no_halt_through (k : Nat)
    (live : (run Direct181.Table.machine k (blank Direct181.Table.start)).state ≠ none) :
    M6.PA.theory ⊢ ∼(byStep k) := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff, LogicalConnective.HomClass.map_neg]
  intro h
  obtain ⟨j,hj,stop⟩ := before_implies_halts _ _ k (V:=V) h
  obtain ⟨d,rfl⟩ := Nat.exists_eq_add_of_le hj
  exact live (halting_persists _ _ j d stop)

/-- A proposed standard time bound for the whole class, together with the
literal k-step live replay, would allow PA to prove nonhalting. -/
theorem pa_bound_implies_nonhalting (k : Nat)
    (live : (run Direct181.Table.machine k (blank Direct181.Table.start)).state ≠ none) :
    M6.PA.theory ⊢ upper 181 k 🡒 ∼H181 := by
  apply Arithmetic.complete.{0} M6.PA.theory _
  intro V _ _
  simp only [models_iff, LogicalConnective.HomClass.map_imply, LogicalConnective.HomClass.map_neg]
  intro bound eventual
  have early := (upper_eval 181 k).mp bound Direct181.Table.machine Direct181.Table.start eventual
  obtain ⟨j,hj,stop⟩ := before_implies_halts _ _ k (V:=V) early
  obtain ⟨d,rfl⟩ := Nat.exists_eq_add_of_le hj
  exact live (halting_persists _ _ j d stop)

theorem pa_live_51111 : M6.PA.theory ⊢ ∼(byStep 51111) := by
  apply pa_no_halt_through
  rw [Direct181.Boot.blank_margin_frame]
  exact Option.some_ne_none _

end NF181PA
#print axioms NF181PA.pa_bound_implies_nonhalting
#print axioms NF181PA.pa_live_51111
