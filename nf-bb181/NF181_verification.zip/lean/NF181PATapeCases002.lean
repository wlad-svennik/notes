import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w64_0 : checkWitness 64 false false 670 = true := by decide +kernel
private theorem w64_1 : checkWitness 64 false true 4762 = true := by decide +kernel
private theorem w64_2 : checkWitness 64 true false 661 = true := by decide +kernel
private theorem w64_3 : checkWitness 64 true true 4753 = true := by decide +kernel
private theorem cases64 : checkFour 64 (670,4762,661,4753) = true := by
  simp only [checkFour, w64_0, w64_1, w64_2, w64_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one64 : Coverage 64 65 := checkList_sound (ws:=[(670,4762,661,4753)]) (by simpa only [checkList, Bool.and_true] using cases64)
private theorem w65_0 : checkWitness 65 false false 8919 = true := by decide +kernel
private theorem w65_2 : checkWitness 65 true false 8915 = true := by decide +kernel
private theorem cases65 : checkFour 65 (8919,0,8915,0) = true := by
  simp only [checkFour, w65_0, w65_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one65 : Coverage 65 66 := checkList_sound (ws:=[(8919,0,8915,0)]) (by simpa only [checkList, Bool.and_true] using cases65)
private theorem w66_0 : checkWitness 66 false false 664 = true := by decide +kernel
private theorem w66_1 : checkWitness 66 false true 4756 = true := by decide +kernel
private theorem w66_2 : checkWitness 66 true false 655 = true := by decide +kernel
private theorem w66_3 : checkWitness 66 true true 4747 = true := by decide +kernel
private theorem cases66 : checkFour 66 (664,4756,655,4747) = true := by
  simp only [checkFour, w66_0, w66_1, w66_2, w66_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one66 : Coverage 66 67 := checkList_sound (ws:=[(664,4756,655,4747)]) (by simpa only [checkList, Bool.and_true] using cases66)
private theorem w67_0 : checkWitness 67 false false 8888 = true := by decide +kernel
private theorem w67_2 : checkWitness 67 true false 8884 = true := by decide +kernel
private theorem cases67 : checkFour 67 (8888,0,8884,0) = true := by
  simp only [checkFour, w67_0, w67_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one67 : Coverage 67 68 := checkList_sound (ws:=[(8888,0,8884,0)]) (by simpa only [checkList, Bool.and_true] using cases67)
private theorem w68_0 : checkWitness 68 false false 64 = true := by decide +kernel
private theorem w68_2 : checkWitness 68 true false 64 = true := by decide +kernel
private theorem cases68 : checkFour 68 (64,0,64,0) = true := by
  simp only [checkFour, w68_0, w68_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one68 : Coverage 68 69 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases68)
private theorem w69_0 : checkWitness 69 false false 56 = true := by decide +kernel
private theorem w69_2 : checkWitness 69 true false 56 = true := by decide +kernel
private theorem cases69 : checkFour 69 (56,0,56,0) = true := by
  simp only [checkFour, w69_0, w69_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one69 : Coverage 69 70 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases69)
private theorem w70_0 : checkWitness 70 false false 629 = true := by decide +kernel
private theorem w70_1 : checkWitness 70 false true 4713 = true := by decide +kernel
private theorem w70_2 : checkWitness 70 true false 629 = true := by decide +kernel
private theorem w70_3 : checkWitness 70 true true 4713 = true := by decide +kernel
private theorem cases70 : checkFour 70 (629,4713,629,4713) = true := by
  simp only [checkFour, w70_0, w70_1, w70_2, w70_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one70 : Coverage 70 71 := checkList_sound (ws:=[(629,4713,629,4713)]) (by simpa only [checkList, Bool.and_true] using cases70)
private theorem w71_0 : checkWitness 71 false false 8882 = true := by decide +kernel
private theorem w71_2 : checkWitness 71 true false 8878 = true := by decide +kernel
private theorem cases71 : checkFour 71 (8882,0,8878,0) = true := by
  simp only [checkFour, w71_0, w71_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one71 : Coverage 71 72 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases71)
private theorem w72_0 : checkWitness 72 false false 56 = true := by decide +kernel
private theorem w72_2 : checkWitness 72 true false 56 = true := by decide +kernel
private theorem cases72 : checkFour 72 (56,0,56,0) = true := by
  simp only [checkFour, w72_0, w72_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one72 : Coverage 72 73 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases72)
private theorem w73_0 : checkWitness 73 false false 634 = true := by decide +kernel
private theorem w73_1 : checkWitness 73 false true 4730 = true := by decide +kernel
private theorem w73_2 : checkWitness 73 true false 634 = true := by decide +kernel
private theorem w73_3 : checkWitness 73 true true 4730 = true := by decide +kernel
private theorem cases73 : checkFour 73 (634,4730,634,4730) = true := by
  simp only [checkFour, w73_0, w73_1, w73_2, w73_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one73 : Coverage 73 74 := checkList_sound (ws:=[(634,4730,634,4730)]) (by simpa only [checkList, Bool.and_true] using cases73)
private theorem w74_0 : checkWitness 74 false false 8950 = true := by decide +kernel
private theorem w74_2 : checkWitness 74 true false 8941 = true := by decide +kernel
private theorem cases74 : checkFour 74 (8950,0,8941,0) = true := by
  simp only [checkFour, w74_0, w74_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one74 : Coverage 74 75 := checkList_sound (ws:=[(8950,0,8941,0)]) (by simpa only [checkList, Bool.and_true] using cases74)
private theorem w75_0 : checkWitness 75 false false 8896 = true := by decide +kernel
private theorem w75_2 : checkWitness 75 true false 8892 = true := by decide +kernel
private theorem cases75 : checkFour 75 (8896,0,8892,0) = true := by
  simp only [checkFour, w75_0, w75_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one75 : Coverage 75 76 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases75)
private theorem w76_0 : checkWitness 76 false false 64 = true := by decide +kernel
private theorem w76_2 : checkWitness 76 true false 64 = true := by decide +kernel
private theorem cases76 : checkFour 76 (64,0,64,0) = true := by
  simp only [checkFour, w76_0, w76_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one76 : Coverage 76 77 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases76)
private theorem w77_0 : checkWitness 77 false false 680 = true := by decide +kernel
private theorem w77_1 : checkWitness 77 false true 4768 = true := by decide +kernel
private theorem w77_2 : checkWitness 77 true false 671 = true := by decide +kernel
private theorem w77_3 : checkWitness 77 true true 4759 = true := by decide +kernel
private theorem cases77 : checkFour 77 (680,4768,671,4759) = true := by
  simp only [checkFour, w77_0, w77_1, w77_2, w77_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one77 : Coverage 77 78 := checkList_sound (ws:=[(680,4768,671,4759)]) (by simpa only [checkList, Bool.and_true] using cases77)
private theorem w78_0 : checkWitness 78 false false 8938 = true := by decide +kernel
private theorem w78_2 : checkWitness 78 true false 8934 = true := by decide +kernel
private theorem cases78 : checkFour 78 (8938,0,8934,0) = true := by
  simp only [checkFour, w78_0, w78_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one78 : Coverage 78 79 := checkList_sound (ws:=[(8938,0,8934,0)]) (by simpa only [checkList, Bool.and_true] using cases78)
private theorem w79_0 : checkWitness 79 false false 54 = true := by decide +kernel
private theorem w79_2 : checkWitness 79 true false 54 = true := by decide +kernel
private theorem cases79 : checkFour 79 (54,0,54,0) = true := by
  simp only [checkFour, w79_0, w79_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one79 : Coverage 79 80 := checkList_sound (ws:=[(54,0,54,0)]) (by simpa only [checkList, Bool.and_true] using cases79)
private theorem w80_0 : checkWitness 80 false false 550 = true := by decide +kernel
private theorem w80_1 : checkWitness 80 false true 4646 = true := by decide +kernel
private theorem w80_2 : checkWitness 80 true false 550 = true := by decide +kernel
private theorem w80_3 : checkWitness 80 true true 4646 = true := by decide +kernel
private theorem cases80 : checkFour 80 (550,4646,550,4646) = true := by
  simp only [checkFour, w80_0, w80_1, w80_2, w80_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one80 : Coverage 80 81 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases80)
private theorem w81_0 : checkWitness 81 false false 8960 = true := by decide +kernel
private theorem w81_2 : checkWitness 81 true false 8951 = true := by decide +kernel
private theorem cases81 : checkFour 81 (8960,0,8951,0) = true := by
  simp only [checkFour, w81_0, w81_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one81 : Coverage 81 82 := checkList_sound (ws:=[(8960,0,8951,0)]) (by simpa only [checkList, Bool.and_true] using cases81)
private theorem w82_0 : checkWitness 82 false false 56 = true := by decide +kernel
private theorem w82_2 : checkWitness 82 true false 56 = true := by decide +kernel
private theorem cases82 : checkFour 82 (56,0,56,0) = true := by
  simp only [checkFour, w82_0, w82_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one82 : Coverage 82 83 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases82)
private theorem w83_0 : checkWitness 83 false false 542 = true := by decide +kernel
private theorem w83_1 : checkWitness 83 false true 4638 = true := by decide +kernel
private theorem w83_2 : checkWitness 83 true false 542 = true := by decide +kernel
private theorem w83_3 : checkWitness 83 true true 4638 = true := by decide +kernel
private theorem cases83 : checkFour 83 (542,4638,542,4638) = true := by
  simp only [checkFour, w83_0, w83_1, w83_2, w83_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one83 : Coverage 83 84 := checkList_sound (ws:=[(542,4638,542,4638)]) (by simpa only [checkList, Bool.and_true] using cases83)
private theorem w84_0 : checkWitness 84 false false 8900 = true := by decide +kernel
private theorem w84_2 : checkWitness 84 true false 8896 = true := by decide +kernel
private theorem cases84 : checkFour 84 (8900,0,8896,0) = true := by
  simp only [checkFour, w84_0, w84_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one84 : Coverage 84 85 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases84)
private theorem w85_0 : checkWitness 85 false false 58 = true := by decide +kernel
private theorem w85_2 : checkWitness 85 true false 58 = true := by decide +kernel
private theorem cases85 : checkFour 85 (58,0,58,0) = true := by
  simp only [checkFour, w85_0, w85_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one85 : Coverage 85 86 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases85)
private theorem w86_0 : checkWitness 86 false false 580 = true := by decide +kernel
private theorem w86_1 : checkWitness 86 false true 4676 = true := by decide +kernel
private theorem w86_2 : checkWitness 86 true false 580 = true := by decide +kernel
private theorem w86_3 : checkWitness 86 true true 4676 = true := by decide +kernel
private theorem cases86 : checkFour 86 (580,4676,580,4676) = true := by
  simp only [checkFour, w86_0, w86_1, w86_2, w86_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one86 : Coverage 86 87 := checkList_sound (ws:=[(580,4676,580,4676)]) (by simpa only [checkList, Bool.and_true] using cases86)
private theorem w87_0 : checkWitness 87 false false 8921 = true := by decide +kernel
private theorem w87_2 : checkWitness 87 true false 8917 = true := by decide +kernel
private theorem cases87 : checkFour 87 (8921,0,8917,0) = true := by
  simp only [checkFour, w87_0, w87_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one87 : Coverage 87 88 := checkList_sound (ws:=[(8921,0,8917,0)]) (by simpa only [checkList, Bool.and_true] using cases87)
private theorem w88_0 : checkWitness 88 false false 8956 = true := by decide +kernel
private theorem w88_2 : checkWitness 88 true false 8947 = true := by decide +kernel
private theorem cases88 : checkFour 88 (8956,0,8947,0) = true := by
  simp only [checkFour, w88_0, w88_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one88 : Coverage 88 89 := checkList_sound (ws:=[(8956,0,8947,0)]) (by simpa only [checkList, Bool.and_true] using cases88)
private theorem w89_0 : checkWitness 89 false false 82 = true := by decide +kernel
private theorem w89_2 : checkWitness 89 true false 82 = true := by decide +kernel
private theorem cases89 : checkFour 89 (82,0,82,0) = true := by
  simp only [checkFour, w89_0, w89_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one89 : Coverage 89 90 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases89)
private theorem w90_0 : checkWitness 90 false false 668 = true := by decide +kernel
private theorem w90_1 : checkWitness 90 false true 4760 = true := by decide +kernel
private theorem w90_2 : checkWitness 90 true false 659 = true := by decide +kernel
private theorem w90_3 : checkWitness 90 true true 4751 = true := by decide +kernel
private theorem cases90 : checkFour 90 (668,4760,659,4751) = true := by
  simp only [checkFour, w90_0, w90_1, w90_2, w90_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one90 : Coverage 90 91 := checkList_sound (ws:=[(668,4760,659,4751)]) (by simpa only [checkList, Bool.and_true] using cases90)
private theorem w91_0 : checkWitness 91 false false 8917 = true := by decide +kernel
private theorem w91_2 : checkWitness 91 true false 8913 = true := by decide +kernel
private theorem cases91 : checkFour 91 (8917,0,8913,0) = true := by
  simp only [checkFour, w91_0, w91_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one91 : Coverage 91 92 := checkList_sound (ws:=[(8917,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases91)
private theorem w92_0 : checkWitness 92 false false 662 = true := by decide +kernel
private theorem w92_1 : checkWitness 92 false true 4754 = true := by decide +kernel
private theorem w92_2 : checkWitness 92 true false 653 = true := by decide +kernel
private theorem w92_3 : checkWitness 92 true true 4745 = true := by decide +kernel
private theorem cases92 : checkFour 92 (662,4754,653,4745) = true := by
  simp only [checkFour, w92_0, w92_1, w92_2, w92_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one92 : Coverage 92 93 := checkList_sound (ws:=[(662,4754,653,4745)]) (by simpa only [checkList, Bool.and_true] using cases92)
private theorem w93_0 : checkWitness 93 false false 8886 = true := by decide +kernel
private theorem w93_2 : checkWitness 93 true false 8882 = true := by decide +kernel
private theorem cases93 : checkFour 93 (8886,0,8882,0) = true := by
  simp only [checkFour, w93_0, w93_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one93 : Coverage 93 94 := checkList_sound (ws:=[(8886,0,8882,0)]) (by simpa only [checkList, Bool.and_true] using cases93)
private theorem w94_0 : checkWitness 94 false false 70 = true := by decide +kernel
private theorem w94_2 : checkWitness 94 true false 70 = true := by decide +kernel
private theorem cases94 : checkFour 94 (70,0,70,0) = true := by
  simp only [checkFour, w94_0, w94_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one94 : Coverage 94 95 := checkList_sound (ws:=[(70,0,70,0)]) (by simpa only [checkList, Bool.and_true] using cases94)
private theorem w95_0 : checkWitness 95 false false 62 = true := by decide +kernel
private theorem w95_2 : checkWitness 95 true false 62 = true := by decide +kernel
private theorem cases95 : checkFour 95 (62,0,62,0) = true := by
  simp only [checkFour, w95_0, w95_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one95 : Coverage 95 96 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases95)
theorem cover0064 : Coverage 64 96 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one64 one65) (Coverage.join one66 one67)) (Coverage.join (Coverage.join one68 one69) (Coverage.join one70 one71))) (Coverage.join (Coverage.join (Coverage.join one72 one73) (Coverage.join one74 one75)) (Coverage.join (Coverage.join one76 one77) (Coverage.join one78 one79)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one80 one81) (Coverage.join one82 one83)) (Coverage.join (Coverage.join one84 one85) (Coverage.join one86 one87))) (Coverage.join (Coverage.join (Coverage.join one88 one89) (Coverage.join one90 one91)) (Coverage.join (Coverage.join one92 one93) (Coverage.join one94 one95)))))
end NF181PA.Symbolic
