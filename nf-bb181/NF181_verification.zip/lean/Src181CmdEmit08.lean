module
public import Src181CmdEmit07
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandEmitAfter257 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1263:Nat):V) f (vector n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1260 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w) w
  have d2 : ((0+(emitAtom39 n t s c u v y d w)):V)=(emitAtom39 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter256 f n t s c u v y d w).trans mid

theorem commandEmitAfter258 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1273:Nat):V) f (vector n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom45 n t s c u v y d w) w)) := by
  have micro := site1263 f n ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(emitAtom45 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom42 n t s c u v y d w)+(emitAtom42 n t s c u v y d w)+1) ((emitAtom24 n t s c u v y d w)+(emitAtom24 n t s c u v y d w)+1))):V)=(0+(emitAtom45 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter257 f n t s c u v y d w).trans mid

theorem commandEmitAfter259 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1277:Nat):V) f (vector n ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1273 f n 0 (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom45 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom45 n t s c u v y d w))):V)=((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom45 n t s c u v y d w))):V)=(0+((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter258 f n t s c u v y d w).trans mid

theorem commandEmitAfter260 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1278:Nat):V) f (vector n ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1277 f n ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w))+1):V)=((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter259 f n t s c u v y d w).trans mid

theorem commandEmitAfter261 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1286:Nat):V) f (vector n ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) w)) := by
  have micro := site1278 f n ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1) (emitAtom39 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom39 n t s c u v y d w))):V)=((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom39 n t s c u v y d w)):V)=(0+(emitAtom39 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom39 n t s c u v y d w))):V)=left (emitAtom39 n t s c u v y d w))).trans (by change left (cantor ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom39 n t s c u v y d w))):V)=(emitAtom32 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom39 n t s c u v y d w)):V)=(0+(emitAtom39 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom39 n t s c u v y d w))):V)=right (emitAtom39 n t s c u v y d w))).trans (by change right (cantor ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter260 f n t s c u v y d w).trans mid

theorem commandEmitAfter262 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1289:Nat):V) f (vector n ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1286 f n ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1) 0 c (d+u) (v+y) ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) w
  have d2 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter261 f n t s c u v y d w).trans mid

theorem commandEmitAfter263 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1299:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom46 n t s c u v y d w) w)) := by
  have micro := site1289 f n ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1))):V)=(emitAtom46 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom38 n t s c u v y d w)+(emitAtom38 n t s c u v y d w)+1) ((emitAtom45 n t s c u v y d w)+(emitAtom45 n t s c u v y d w)+1))):V)=(0+(emitAtom46 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter262 f n t s c u v y d w).trans mid

theorem commandEmitAfter264 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1303:Nat):V) f (vector n ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1299 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom46 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom46 n t s c u v y d w))):V)=((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom46 n t s c u v y d w))):V)=(0+((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter263 f n t s c u v y d w).trans mid

theorem commandEmitAfter265 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1304:Nat):V) f (vector n ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1303 f n ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w))+1):V)=((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter264 f n t s c u v y d w).trans mid

theorem commandEmitAfter266 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1307:Nat):V) f (vector n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1304 f n ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1)):V)=((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter265 f n t s c u v y d w).trans mid

theorem commandEmitAfter267 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1310:Nat):V) f (vector n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1307 f n 0 (emitAtom32 n t s c u v y d w) c (d+u) (v+y) ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom32 n t s c u v y d w)):V)=(emitAtom32 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter266 f n t s c u v y d w).trans mid

theorem commandEmitAfter268 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1320:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom47 n t s c u v y d w) w)) := by
  have micro := site1310 f n (emitAtom32 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w))):V)=(emitAtom47 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) (emitAtom32 n t s c u v y d w))):V)=(0+(emitAtom47 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter267 f n t s c u v y d w).trans mid

theorem commandEmitAfter269 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1323:Nat):V) f (vector n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1320 f n 0 0 c (d+u) (v+y) 0 (emitAtom47 n t s c u v y d w) w
  have d2 : ((0+(emitAtom47 n t s c u v y d w)):V)=(emitAtom47 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter268 f n t s c u v y d w).trans mid

theorem commandEmitAfter270 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1327:Nat):V) f (vector n c (emitAtom47 n t s c u v y d w) 0 (d+u) (v+y) c 0 w)) := by
  have micro := site1323 f n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+c):V)=c := by ring
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter269 f n t s c u v y d w).trans mid

theorem commandEmitAfter271 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1330:Nat):V) f (vector n c (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1327 f n c (emitAtom47 n t s c u v y d w) 0 (d+u) (v+y) c 0 w
  have d3 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandEmitAfter270 f n t s c u v y d w).trans mid

theorem commandEmitAfter272 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1333:Nat):V) f (vector n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1330 f n c (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+c):V)=c := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter271 f n t s c u v y d w).trans mid

theorem commandEmitAfter273 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1336:Nat):V) f (vector n (emitAtom47 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w)) := by
  have micro := site1333 f n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d1 : ((0+(emitAtom47 n t s c u v y d w)):V)=(emitAtom47 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter272 f n t s c u v y d w).trans mid

theorem commandEmitAfter274 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1346:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom48 n t s c u v y d w) w)) := by
  have micro := site1336 f n (emitAtom47 n t s c u v y d w) 0 c (d+u) (v+y) c 0 w
  have d7 : ((0+(cantor c (emitAtom47 n t s c u v y d w))):V)=(emitAtom48 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c (emitAtom47 n t s c u v y d w))):V)=(0+(emitAtom48 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter273 f n t s c u v y d w).trans mid

theorem commandEmitAfter275 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1349:Nat):V) f (vector n 0 (emitAtom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1346 f n 0 0 c (d+u) (v+y) 0 (emitAtom48 n t s c u v y d w) w
  have d2 : ((0+(emitAtom48 n t s c u v y d w)):V)=(emitAtom48 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter274 f n t s c u v y d w).trans mid

theorem commandEmitAfter276 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1353:Nat):V) f (vector n (v+y) (emitAtom48 n t s c u v y d w) c (d+u) 0 (v+y) 0 w)) := by
  have micro := site1349 f n 0 (emitAtom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(v+y)):V)=(v+y) := by ring
  have d6 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter275 f n t s c u v y d w).trans mid

theorem commandEmitAfter277 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1356:Nat):V) f (vector n (v+y) (emitAtom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1353 f n (v+y) (emitAtom48 n t s c u v y d w) c (d+u) 0 (v+y) 0 w
  have d5 : ((0+(v+y)):V)=(v+y) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl d5 rfl rfl rfl)
  exact (commandEmitAfter276 f n t s c u v y d w).trans mid

theorem commandEmitAfter278 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1364:Nat):V) f (vector n (v+y) 0 c (d+u) (v+y) c (emitAtom47 n t s c u v y d w) w)) := by
  have micro := site1356 f n (v+y) (emitAtom48 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((left ((cantor 0 0)+(emitAtom48 n t s c u v y d w))):V)=c := ((congrArg left (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom48 n t s c u v y d w)):V)=(0+(emitAtom48 n t s c u v y d w)))).trans (by ring)) : ((left ((cantor 0 0)+(emitAtom48 n t s c u v y d w))):V)=left (emitAtom48 n t s c u v y d w))).trans (by change left (cantor c (emitAtom47 n t s c u v y d w)) = _; simp)
  have d7 : ((right ((cantor 0 0)+(emitAtom48 n t s c u v y d w))):V)=(emitAtom47 n t s c u v y d w) := ((congrArg right (((congrArg₂ (·+·) (by simp [cantor]) (rfl) : (((cantor 0 0)+(emitAtom48 n t s c u v y d w)):V)=(0+(emitAtom48 n t s c u v y d w)))).trans (by ring)) : ((right ((cantor 0 0)+(emitAtom48 n t s c u v y d w))):V)=right (emitAtom48 n t s c u v y d w))).trans (by change right (cantor c (emitAtom47 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandEmitAfter277 f n t s c u v y d w).trans mid

theorem commandEmitAfter279 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1367:Nat):V) f (vector n (v+y) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) c 0 w)) := by
  have micro := site1364 f n (v+y) 0 c (d+u) (v+y) c (emitAtom47 n t s c u v y d w) w
  have d2 : ((0+(emitAtom47 n t s c u v y d w)):V)=(emitAtom47 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter278 f n t s c u v y d w).trans mid

theorem commandEmitAfter280 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1377:Nat):V) f (vector n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom29 n t s c u v y d w) w)) := by
  have micro := site1367 f n (v+y) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) c 0 w
  have d7 : ((0+(cantor c (v+y))):V)=(emitAtom29 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor c (v+y))):V)=(0+(emitAtom29 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter279 f n t s c u v y d w).trans mid

theorem commandEmitAfter281 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1381:Nat):V) f (vector n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1377 f n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 (emitAtom29 n t s c u v y d w) w
  have d1 : ((0+(2*(emitAtom29 n t s c u v y d w))):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)) := ((congrArg₂ (·+·) (rfl) (by ring) : ((0+(2*(emitAtom29 n t s c u v y d w))):V)=(0+((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w))))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter280 f n t s c u v y d w).trans mid

theorem commandEmitAfter282 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1382:Nat):V) f (vector n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1381 f n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w))+1):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter281 f n t s c u v y d w).trans mid

theorem commandEmitAfter283 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1385:Nat):V) f (vector n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1382 f n ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d6 : ((0+((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1)):V)=((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter282 f n t s c u v y d w).trans mid

theorem commandEmitAfter284 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1388:Nat):V) f (vector n (emitAtom47 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w)) := by
  have micro := site1385 f n 0 (emitAtom47 n t s c u v y d w) c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w
  have d1 : ((0+(emitAtom47 n t s c u v y d w)):V)=(emitAtom47 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter283 f n t s c u v y d w).trans mid

theorem commandEmitAfter285 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1398:Nat):V) f (vector n 0 0 c (d+u) (v+y) 0 (emitAtom49 n t s c u v y d w) w)) := by
  have micro := site1388 f n (emitAtom47 n t s c u v y d w) 0 c (d+u) (v+y) ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) 0 w
  have d7 : ((0+(cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w))):V)=(emitAtom49 n t s c u v y d w) := ((congrArg₂ (·+·) (rfl) (rfl) : ((0+(cantor ((emitAtom29 n t s c u v y d w)+(emitAtom29 n t s c u v y d w)+1) (emitAtom47 n t s c u v y d w))):V)=(0+(emitAtom49 n t s c u v y d w)))).trans (by ring)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl d7 rfl)
  exact (commandEmitAfter284 f n t s c u v y d w).trans mid

theorem commandEmitAfter286 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1401:Nat):V) f (vector n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1398 f n 0 0 c (d+u) (v+y) 0 (emitAtom49 n t s c u v y d w) w
  have d2 : ((0+(emitAtom49 n t s c u v y d w)):V)=(emitAtom49 n t s c u v y d w) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl d2 rfl rfl rfl rfl rfl rfl)
  exact (commandEmitAfter285 f n t s c u v y d w).trans mid

theorem commandEmitAfter287 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1405:Nat):V) f (vector n (d+u) (emitAtom49 n t s c u v y d w) c 0 (v+y) (d+u) 0 w)) := by
  have micro := site1401 f n 0 (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w
  have d1 : ((0+(d+u)):V)=(d+u) := by ring
  have d6 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl d1 rfl rfl rfl rfl d6 rfl rfl)
  exact (commandEmitAfter286 f n t s c u v y d w).trans mid

theorem commandEmitAfter288 (f n t s c u v y d w : V) : Reach (config ((40:Nat):V) f (vector n t s c u v 0 0 (emitAtom1 n t s c u v y d w))) (config ((1408:Nat):V) f (vector n (d+u) (emitAtom49 n t s c u v y d w) c (d+u) (v+y) 0 0 w)) := by
  have micro := site1405 f n (d+u) (emitAtom49 n t s c u v y d w) c 0 (v+y) (d+u) 0 w
  have d4 : ((0+(d+u)):V)=(d+u) := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandEmitAfter287 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
