module
public import NF181PAEightEntry
public import NF181PARegisterHalting
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch PA192.ModelSearch.RegisterFields
open PA192.ModelSearch.Register181 (Reach address)
open PA192.ModelSearch.Register181.Commands (atS vm)
open NF181PA.Scanner NF181PA.ScannerSource NF181PA.Sound
namespace NF181PA.Reverse
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 4500000

private theorem view_live {a : V} (no : ¬Pool.Pr (∅ : V) goal) (good : goodState (dataState a)) :
    ¬observed a := by
  intro hit
  apply no
  simpa only [Prov,goal_three,←hit.2] using good.2.2

/-- A refutation-free pool gives a live literal-source checkpoint at or beyond every model clock. -/
theorem cofinalSource (no : ¬Pool.Pr (∅ : V) goal) (j : V) :
    ∃ a d : V, j≤d ∧ Register181.run d (origin V)=view a ∧ goodState (dataState a) := by
  induction j using modelInduct with
  | defP => unfold origin dataState; definability
  | zero =>
    obtain ⟨e,⟨t,ht⟩,good⟩ := signed_entry_sound (V:=V)
    exact ⟨fresh 0 0 e,t,zero_le,ht,by simpa [fresh,dataState] using good⟩
  | step j ih =>
    obtain ⟨a,t,le,ht,good⟩ := ih
    obtain ⟨u,hu⟩ := actualCommand (k:=index a) (raw:=input a) (e:=dataState a) (view_live no good)
    have pos : 0<u := lt_of_le_of_ne zero_le (fun eq => by
      rw [←eq,Register181.run_zero] at hu
      have h := congrArg Register181.address hu
      simp [vm24,vm,atS] at h)
    obtain ⟨v,hv⟩ := actualRefill (index a) (input a) (rawAction (input a) (dataState a))
    refine ⟨next a,t+u+v,le_trans (succ_le_iff_lt.mpr (lt_of_le_of_lt le (lt_add_of_pos_right _ pos))) le_self_add,?_,goodNext a good⟩
    rw [Register181.run_add,Register181.run_add,ht]
    change Register181.run v (Register181.run u (vm24 0 (index a) (dataState a) (input a)))=_
    rw [hu,hv]
    simp only [next,view_fresh,Scanner.control]

theorem sourceHalt_iff_pool :
    Register181.sourceHalts (origin V) ↔ Pool.Pr (∅ : V) goal := by
  constructor
  · rintro ⟨t,ht⟩
    by_contra no
    obtain ⟨a,c,tc,hc,_⟩ := cofinalSource no t
    obtain ⟨d,rfl⟩ := exists_add_of_le tc
    rw [Register181.run_add] at hc
    have frozen : ∀ n : V, address (Register181.run n (Register181.run t (origin V)))=4095 := by
      apply modelInduct
      · unfold origin; definability
      · simpa using ht
      · intro n ih
        rw [Register181.run_succ]
        exact Registers.next_terminal _ ih
    have impossible := frozen d
    rw [hc] at impossible
    norm_num [view,vm24,atS] at impossible
  · exact proof_halts_origin

end NF181PA.Reverse
#print axioms NF181PA.Reverse.sourceHalt_iff_pool
