module
public import Direct181Chunk00
public import Direct181Chunk01
public import Direct181Chunk02
public import Direct181Chunk03
public import Direct181Chunk04
public import Direct181Chunk05
public import Direct181Chunk06
public import Direct181Chunk07
public import Direct181Chunk08
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
theorem prefix500 : Prefix 500 snap0 snap500 := chunk500
theorem prefix1000 : Prefix 1000 snap0 snap1000 := @compose 500 500 snap0 snap500 snap1000 prefix500 chunk1000
theorem prefix1500 : Prefix 1500 snap0 snap1500 := @compose 1000 500 snap0 snap1000 snap1500 prefix1000 chunk1500
theorem prefix2000 : Prefix 2000 snap0 snap2000 := @compose 1500 500 snap0 snap1500 snap2000 prefix1500 chunk2000
theorem prefix2500 : Prefix 2500 snap0 snap2500 := @compose 2000 500 snap0 snap2000 snap2500 prefix2000 chunk2500
theorem prefix3000 : Prefix 3000 snap0 snap3000 := @compose 2500 500 snap0 snap2500 snap3000 prefix2500 chunk3000
theorem prefix3500 : Prefix 3500 snap0 snap3500 := @compose 3000 500 snap0 snap3000 snap3500 prefix3000 chunk3500
theorem prefix4000 : Prefix 4000 snap0 snap4000 := @compose 3500 500 snap0 snap3500 snap4000 prefix3500 chunk4000
theorem prefix4500 : Prefix 4500 snap0 snap4500 := @compose 4000 500 snap0 snap4000 snap4500 prefix4000 chunk4500
theorem prefix5000 : Prefix 5000 snap0 snap5000 := @compose 4500 500 snap0 snap4500 snap5000 prefix4500 chunk5000
theorem prefix5500 : Prefix 5500 snap0 snap5500 := @compose 5000 500 snap0 snap5000 snap5500 prefix5000 chunk5500
theorem prefix6000 : Prefix 6000 snap0 snap6000 := @compose 5500 500 snap0 snap5500 snap6000 prefix5500 chunk6000
theorem prefix6500 : Prefix 6500 snap0 snap6500 := @compose 6000 500 snap0 snap6000 snap6500 prefix6000 chunk6500
theorem prefix7000 : Prefix 7000 snap0 snap7000 := @compose 6500 500 snap0 snap6500 snap7000 prefix6500 chunk7000
theorem prefix7500 : Prefix 7500 snap0 snap7500 := @compose 7000 500 snap0 snap7000 snap7500 prefix7000 chunk7500
theorem prefix8000 : Prefix 8000 snap0 snap8000 := @compose 7500 500 snap0 snap7500 snap8000 prefix7500 chunk8000
theorem prefix8500 : Prefix 8500 snap0 snap8500 := @compose 8000 500 snap0 snap8000 snap8500 prefix8000 chunk8500
theorem prefix9000 : Prefix 9000 snap0 snap9000 := @compose 8500 500 snap0 snap8500 snap9000 prefix8500 chunk9000
theorem prefix9500 : Prefix 9500 snap0 snap9500 := @compose 9000 500 snap0 snap9000 snap9500 prefix9000 chunk9500
theorem prefix10000 : Prefix 10000 snap0 snap10000 := @compose 9500 500 snap0 snap9500 snap10000 prefix9500 chunk10000
theorem prefix10500 : Prefix 10500 snap0 snap10500 := @compose 10000 500 snap0 snap10000 snap10500 prefix10000 chunk10500
theorem prefix11000 : Prefix 11000 snap0 snap11000 := @compose 10500 500 snap0 snap10500 snap11000 prefix10500 chunk11000
theorem prefix11500 : Prefix 11500 snap0 snap11500 := @compose 11000 500 snap0 snap11000 snap11500 prefix11000 chunk11500
theorem prefix12000 : Prefix 12000 snap0 snap12000 := @compose 11500 500 snap0 snap11500 snap12000 prefix11500 chunk12000
theorem prefix12500 : Prefix 12500 snap0 snap12500 := @compose 12000 500 snap0 snap12000 snap12500 prefix12000 chunk12500
theorem prefix13000 : Prefix 13000 snap0 snap13000 := @compose 12500 500 snap0 snap12500 snap13000 prefix12500 chunk13000
theorem prefix13500 : Prefix 13500 snap0 snap13500 := @compose 13000 500 snap0 snap13000 snap13500 prefix13000 chunk13500
theorem prefix14000 : Prefix 14000 snap0 snap14000 := @compose 13500 500 snap0 snap13500 snap14000 prefix13500 chunk14000
theorem prefix14500 : Prefix 14500 snap0 snap14500 := @compose 14000 500 snap0 snap14000 snap14500 prefix14000 chunk14500
theorem prefix15000 : Prefix 15000 snap0 snap15000 := @compose 14500 500 snap0 snap14500 snap15000 prefix14500 chunk15000
theorem prefix15500 : Prefix 15500 snap0 snap15500 := @compose 15000 500 snap0 snap15000 snap15500 prefix15000 chunk15500
theorem prefix16000 : Prefix 16000 snap0 snap16000 := @compose 15500 500 snap0 snap15500 snap16000 prefix15500 chunk16000
theorem prefix16439 : Prefix 16439 snap0 snap16439 := @compose 16000 439 snap0 snap16000 snap16439 prefix16000 chunk16439
theorem prefix16500 : Prefix 16500 snap0 snap16500 := @compose 16439 61 snap0 snap16439 snap16500 prefix16439 chunk16500
theorem prefix17000 : Prefix 17000 snap0 snap17000 := @compose 16500 500 snap0 snap16500 snap17000 prefix16500 chunk17000
theorem prefix17319 : Prefix 17319 snap0 snap17319 := @compose 17000 319 snap0 snap17000 snap17319 prefix17000 chunk17319
theorem prefix17500 : Prefix 17500 snap0 snap17500 := @compose 17319 181 snap0 snap17319 snap17500 prefix17319 chunk17500
theorem prefix18000 : Prefix 18000 snap0 snap18000 := @compose 17500 500 snap0 snap17500 snap18000 prefix17500 chunk18000
theorem prefix18500 : Prefix 18500 snap0 snap18500 := @compose 18000 500 snap0 snap18000 snap18500 prefix18000 chunk18500
theorem prefix19000 : Prefix 19000 snap0 snap19000 := @compose 18500 500 snap0 snap18500 snap19000 prefix18500 chunk19000
theorem prefix19500 : Prefix 19500 snap0 snap19500 := @compose 19000 500 snap0 snap19000 snap19500 prefix19000 chunk19500
theorem prefix20000 : Prefix 20000 snap0 snap20000 := @compose 19500 500 snap0 snap19500 snap20000 prefix19500 chunk20000
theorem prefix20500 : Prefix 20500 snap0 snap20500 := @compose 20000 500 snap0 snap20000 snap20500 prefix20000 chunk20500
theorem prefix21000 : Prefix 21000 snap0 snap21000 := @compose 20500 500 snap0 snap20500 snap21000 prefix20500 chunk21000
theorem prefix21500 : Prefix 21500 snap0 snap21500 := @compose 21000 500 snap0 snap21000 snap21500 prefix21000 chunk21500
theorem prefix22000 : Prefix 22000 snap0 snap22000 := @compose 21500 500 snap0 snap21500 snap22000 prefix21500 chunk22000
theorem prefix22500 : Prefix 22500 snap0 snap22500 := @compose 22000 500 snap0 snap22000 snap22500 prefix22000 chunk22500
theorem prefix23000 : Prefix 23000 snap0 snap23000 := @compose 22500 500 snap0 snap22500 snap23000 prefix22500 chunk23000
theorem prefix23500 : Prefix 23500 snap0 snap23500 := @compose 23000 500 snap0 snap23000 snap23500 prefix23000 chunk23500
theorem prefix24000 : Prefix 24000 snap0 snap24000 := @compose 23500 500 snap0 snap23500 snap24000 prefix23500 chunk24000
theorem prefix24500 : Prefix 24500 snap0 snap24500 := @compose 24000 500 snap0 snap24000 snap24500 prefix24000 chunk24500
theorem prefix25000 : Prefix 25000 snap0 snap25000 := @compose 24500 500 snap0 snap24500 snap25000 prefix24500 chunk25000
theorem prefix25500 : Prefix 25500 snap0 snap25500 := @compose 25000 500 snap0 snap25000 snap25500 prefix25000 chunk25500
theorem prefix26000 : Prefix 26000 snap0 snap26000 := @compose 25500 500 snap0 snap25500 snap26000 prefix25500 chunk26000
theorem prefix26500 : Prefix 26500 snap0 snap26500 := @compose 26000 500 snap0 snap26000 snap26500 prefix26000 chunk26500
theorem prefix27000 : Prefix 27000 snap0 snap27000 := @compose 26500 500 snap0 snap26500 snap27000 prefix26500 chunk27000
theorem prefix27500 : Prefix 27500 snap0 snap27500 := @compose 27000 500 snap0 snap27000 snap27500 prefix27000 chunk27500
theorem prefix28000 : Prefix 28000 snap0 snap28000 := @compose 27500 500 snap0 snap27500 snap28000 prefix27500 chunk28000
theorem prefix28500 : Prefix 28500 snap0 snap28500 := @compose 28000 500 snap0 snap28000 snap28500 prefix28000 chunk28500
theorem prefix29000 : Prefix 29000 snap0 snap29000 := @compose 28500 500 snap0 snap28500 snap29000 prefix28500 chunk29000
theorem prefix29500 : Prefix 29500 snap0 snap29500 := @compose 29000 500 snap0 snap29000 snap29500 prefix29000 chunk29500
theorem prefix30000 : Prefix 30000 snap0 snap30000 := @compose 29500 500 snap0 snap29500 snap30000 prefix29500 chunk30000
theorem prefix30500 : Prefix 30500 snap0 snap30500 := @compose 30000 500 snap0 snap30000 snap30500 prefix30000 chunk30500
theorem prefix31000 : Prefix 31000 snap0 snap31000 := @compose 30500 500 snap0 snap30500 snap31000 prefix30500 chunk31000
theorem prefix31500 : Prefix 31500 snap0 snap31500 := @compose 31000 500 snap0 snap31000 snap31500 prefix31000 chunk31500
theorem prefix32000 : Prefix 32000 snap0 snap32000 := @compose 31500 500 snap0 snap31500 snap32000 prefix31500 chunk32000
theorem prefix32500 : Prefix 32500 snap0 snap32500 := @compose 32000 500 snap0 snap32000 snap32500 prefix32000 chunk32500
theorem prefix33000 : Prefix 33000 snap0 snap33000 := @compose 32500 500 snap0 snap32500 snap33000 prefix32500 chunk33000
theorem prefix33500 : Prefix 33500 snap0 snap33500 := @compose 33000 500 snap0 snap33000 snap33500 prefix33000 chunk33500
theorem prefix34000 : Prefix 34000 snap0 snap34000 := @compose 33500 500 snap0 snap33500 snap34000 prefix33500 chunk34000
theorem prefix34500 : Prefix 34500 snap0 snap34500 := @compose 34000 500 snap0 snap34000 snap34500 prefix34000 chunk34500
theorem prefix35000 : Prefix 35000 snap0 snap35000 := @compose 34500 500 snap0 snap34500 snap35000 prefix34500 chunk35000
theorem prefix35500 : Prefix 35500 snap0 snap35500 := @compose 35000 500 snap0 snap35000 snap35500 prefix35000 chunk35500
theorem prefix36000 : Prefix 36000 snap0 snap36000 := @compose 35500 500 snap0 snap35500 snap36000 prefix35500 chunk36000
theorem prefix36500 : Prefix 36500 snap0 snap36500 := @compose 36000 500 snap0 snap36000 snap36500 prefix36000 chunk36500
theorem prefix37000 : Prefix 37000 snap0 snap37000 := @compose 36500 500 snap0 snap36500 snap37000 prefix36500 chunk37000
theorem prefix37500 : Prefix 37500 snap0 snap37500 := @compose 37000 500 snap0 snap37000 snap37500 prefix37000 chunk37500
theorem prefix38000 : Prefix 38000 snap0 snap38000 := @compose 37500 500 snap0 snap37500 snap38000 prefix37500 chunk38000
theorem prefix38500 : Prefix 38500 snap0 snap38500 := @compose 38000 500 snap0 snap38000 snap38500 prefix38000 chunk38500
theorem prefix39000 : Prefix 39000 snap0 snap39000 := @compose 38500 500 snap0 snap38500 snap39000 prefix38500 chunk39000
theorem prefix39500 : Prefix 39500 snap0 snap39500 := @compose 39000 500 snap0 snap39000 snap39500 prefix39000 chunk39500
theorem prefix40000 : Prefix 40000 snap0 snap40000 := @compose 39500 500 snap0 snap39500 snap40000 prefix39500 chunk40000
theorem prefix40500 : Prefix 40500 snap0 snap40500 := @compose 40000 500 snap0 snap40000 snap40500 prefix40000 chunk40500
theorem prefix41000 : Prefix 41000 snap0 snap41000 := @compose 40500 500 snap0 snap40500 snap41000 prefix40500 chunk41000
theorem prefix41500 : Prefix 41500 snap0 snap41500 := @compose 41000 500 snap0 snap41000 snap41500 prefix41000 chunk41500
theorem prefix42000 : Prefix 42000 snap0 snap42000 := @compose 41500 500 snap0 snap41500 snap42000 prefix41500 chunk42000
theorem prefix42500 : Prefix 42500 snap0 snap42500 := @compose 42000 500 snap0 snap42000 snap42500 prefix42000 chunk42500
theorem prefix43000 : Prefix 43000 snap0 snap43000 := @compose 42500 500 snap0 snap42500 snap43000 prefix42500 chunk43000
theorem prefix43500 : Prefix 43500 snap0 snap43500 := @compose 43000 500 snap0 snap43000 snap43500 prefix43000 chunk43500
theorem prefix44000 : Prefix 44000 snap0 snap44000 := @compose 43500 500 snap0 snap43500 snap44000 prefix43500 chunk44000
theorem prefix44500 : Prefix 44500 snap0 snap44500 := @compose 44000 500 snap0 snap44000 snap44500 prefix44000 chunk44500
theorem prefix45000 : Prefix 45000 snap0 snap45000 := @compose 44500 500 snap0 snap44500 snap45000 prefix44500 chunk45000
theorem prefix45500 : Prefix 45500 snap0 snap45500 := @compose 45000 500 snap0 snap45000 snap45500 prefix45000 chunk45500
theorem prefix46000 : Prefix 46000 snap0 snap46000 := @compose 45500 500 snap0 snap45500 snap46000 prefix45500 chunk46000
theorem prefix46500 : Prefix 46500 snap0 snap46500 := @compose 46000 500 snap0 snap46000 snap46500 prefix46000 chunk46500
theorem prefix47000 : Prefix 47000 snap0 snap47000 := @compose 46500 500 snap0 snap46500 snap47000 prefix46500 chunk47000
theorem prefix47500 : Prefix 47500 snap0 snap47500 := @compose 47000 500 snap0 snap47000 snap47500 prefix47000 chunk47500
theorem prefix48000 : Prefix 48000 snap0 snap48000 := @compose 47500 500 snap0 snap47500 snap48000 prefix47500 chunk48000
theorem prefix48500 : Prefix 48500 snap0 snap48500 := @compose 48000 500 snap0 snap48000 snap48500 prefix48000 chunk48500
theorem prefix49000 : Prefix 49000 snap0 snap49000 := @compose 48500 500 snap0 snap48500 snap49000 prefix48500 chunk49000
theorem prefix49500 : Prefix 49500 snap0 snap49500 := @compose 49000 500 snap0 snap49000 snap49500 prefix49000 chunk49500
theorem prefix50000 : Prefix 50000 snap0 snap50000 := @compose 49500 500 snap0 snap49500 snap50000 prefix49500 chunk50000
theorem prefix50500 : Prefix 50500 snap0 snap50500 := @compose 50000 500 snap0 snap50000 snap50500 prefix50000 chunk50500
theorem prefix51000 : Prefix 51000 snap0 snap51000 := @compose 50500 500 snap0 snap50500 snap51000 prefix50500 chunk51000
theorem prefix51111 : Prefix 51111 snap0 snap51111 := @compose 51000 111 snap0 snap51000 snap51111 prefix51000 chunk51111
end Direct181.Boot
