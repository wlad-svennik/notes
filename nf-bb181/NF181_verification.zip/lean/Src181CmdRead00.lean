module
public import Src181Atoms
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandReadAfter1 (f n t s c u v y d w : V) : Reach (config ((10:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((18:Nat):V) f (vector n t s c u v y (atom0 n t s c u v y d w) 0)) := by
  have micro := site0010 f n t s c u v 0 0 (atom1 n t s c u v y d w)
  have d6 : (left ((cantor 0 0)+(atom1 n t s c u v y d w)):V)=y := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom1 n t s c u v y d w):V)=0+(atom1 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom1 n t s c u v y d w)):V)=left (atom1 n t s c u v y d w)).trans (by change left (cantor y (atom0 n t s c u v y d w)) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom1 n t s c u v y d w)):V)=atom0 n t s c u v y d w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom1 n t s c u v y d w):V)=0+(atom1 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom1 n t s c u v y d w)):V)=right (atom1 n t s c u v y d w)).trans (by change right (cantor y (atom0 n t s c u v y d w)) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact mid

theorem commandReadAfter2 (f n t s c u v y d w : V) : Reach (config ((10:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((21:Nat):V) f (vector n t s c u v y 0 (atom0 n t s c u v y d w))) := by
  have micro := site0018 f n t s c u v y (atom0 n t s c u v y d w) 0
  have d8 : (0+(atom0 n t s c u v y d w):V)=atom0 n t s c u v y d w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl rfl d8)
  exact (commandReadAfter1 f n t s c u v y d w).trans mid

theorem commandReadAfter3 (f n t s c u v y d w : V) : Reach (config ((10:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((24:Nat):V) f (vector n t s (c+y) u v 0 0 (atom0 n t s c u v y d w))) := by
  have micro := site0021 f n t s c u v y 0 (atom0 n t s c u v y d w)
  have d3 : (c+y:V)=c+y := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl d3 rfl rfl rfl rfl rfl)
  exact (commandReadAfter2 f n t s c u v y d w).trans mid

theorem commandReadAfter4 (f n t s c u v y d w : V) : Reach (config ((10:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((32:Nat):V) f (vector n t s (c+y) u v d w 0)) := by
  have micro := site0024 f n t s (c+y) u v 0 0 (atom0 n t s c u v y d w)
  have d6 : (left ((cantor 0 0)+(atom0 n t s c u v y d w)):V)=d := (congrArg left ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom0 n t s c u v y d w):V)=0+(atom0 n t s c u v y d w)).trans (by ring)) : (left ((cantor 0 0)+(atom0 n t s c u v y d w)):V)=left (atom0 n t s c u v y d w)).trans (by change left (cantor d w) = _; simp)
  have d7 : (right ((cantor 0 0)+(atom0 n t s c u v y d w)):V)=w := (congrArg right ((congrArg₂ (·+·) (by simp [cantor]) (rfl) : ((cantor 0 0)+(atom0 n t s c u v y d w):V)=0+(atom0 n t s c u v y d w)).trans (by ring)) : (right ((cantor 0 0)+(atom0 n t s c u v y d w)):V)=right (atom0 n t s c u v y d w)).trans (by change right (cantor d w) = _; simp)
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl d6 d7 rfl)
  exact (commandReadAfter3 f n t s c u v y d w).trans mid

theorem commandReadAfter5 (f n t s c u v y d w : V) : Reach (config ((10:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((35:Nat):V) f (vector n t s (c+y) u v d 0 w)) := by
  have micro := site0032 f n t s (c+y) u v d w 0
  have d8 : (0+w:V)=w := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl rfl rfl rfl rfl d8)
  exact (commandReadAfter4 f n t s c u v y d w).trans mid

theorem commandRead (f n t s c u v y d w : V) : Reach (config ((10:Nat):V) f (vector n t s c u v 0 0 (atom1 n t s c u v y d w))) (config ((38:Nat):V) f (vector n t s (c+y) (d+u) v 0 0 w)) := by
  have micro := site0035 f n t s (c+y) u v d 0 w
  have d4 : (u+d:V)=d+u := by ring
  have mid := Reach.endAt micro (vectorEq (V:=V) _ _ rfl rfl rfl rfl d4 rfl rfl rfl rfl)
  exact (commandReadAfter5 f n t s c u v y d w).trans mid

end PA192.ModelSearch.Register181.Commands
