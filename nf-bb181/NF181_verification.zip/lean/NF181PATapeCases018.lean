import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w576_0 : checkWitness 576 false false 74 = true := by decide +kernel
private theorem w576_2 : checkWitness 576 true false 74 = true := by decide +kernel
private theorem cases576 : checkFour 576 (74,0,74,0) = true := by
  simp only [checkFour, w576_0, w576_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one576 : Coverage 576 577 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases576)
private theorem w577_0 : checkWitness 577 false false 66 = true := by decide +kernel
private theorem w577_2 : checkWitness 577 true false 66 = true := by decide +kernel
private theorem cases577 : checkFour 577 (66,0,66,0) = true := by
  simp only [checkFour, w577_0, w577_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one577 : Coverage 577 578 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases577)
private theorem w578_0 : checkWitness 578 false false 621 = true := by decide +kernel
private theorem w578_1 : checkWitness 578 false true 4709 = true := by decide +kernel
private theorem w578_2 : checkWitness 578 true false 621 = true := by decide +kernel
private theorem w578_3 : checkWitness 578 true true 4709 = true := by decide +kernel
private theorem cases578 : checkFour 578 (621,4709,621,4709) = true := by
  simp only [checkFour, w578_0, w578_1, w578_2, w578_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one578 : Coverage 578 579 := checkList_sound (ws:=[(621,4709,621,4709)]) (by simpa only [checkList, Bool.and_true] using cases578)
private theorem w579_0 : checkWitness 579 false false 8894 = true := by decide +kernel
private theorem w579_2 : checkWitness 579 true false 8890 = true := by decide +kernel
private theorem cases579 : checkFour 579 (8894,0,8890,0) = true := by
  simp only [checkFour, w579_0, w579_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one579 : Coverage 579 580 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases579)
private theorem w580_0 : checkWitness 580 false false 8890 = true := by decide +kernel
private theorem w580_2 : checkWitness 580 true false 8886 = true := by decide +kernel
private theorem cases580 : checkFour 580 (8890,0,8886,0) = true := by
  simp only [checkFour, w580_0, w580_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one580 : Coverage 580 581 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases580)
private theorem w581_0 : checkWitness 581 false false 80 = true := by decide +kernel
private theorem w581_2 : checkWitness 581 true false 80 = true := by decide +kernel
private theorem cases581 : checkFour 581 (80,0,80,0) = true := by
  simp only [checkFour, w581_0, w581_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one581 : Coverage 581 582 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases581)
private theorem w582_0 : checkWitness 582 false false 8914 = true := by decide +kernel
private theorem w582_2 : checkWitness 582 true false 8910 = true := by decide +kernel
private theorem cases582 : checkFour 582 (8914,0,8910,0) = true := by
  simp only [checkFour, w582_0, w582_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one582 : Coverage 582 583 := checkList_sound (ws:=[(8914,0,8910,0)]) (by simpa only [checkList, Bool.and_true] using cases582)
private theorem w583_0 : checkWitness 583 false false 550 = true := by decide +kernel
private theorem w583_1 : checkWitness 583 false true 4646 = true := by decide +kernel
private theorem w583_2 : checkWitness 583 true false 550 = true := by decide +kernel
private theorem w583_3 : checkWitness 583 true true 4646 = true := by decide +kernel
private theorem cases583 : checkFour 583 (550,4646,550,4646) = true := by
  simp only [checkFour, w583_0, w583_1, w583_2, w583_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one583 : Coverage 583 584 := checkList_sound (ws:=[(550,4646,550,4646)]) (by simpa only [checkList, Bool.and_true] using cases583)
private theorem w584_0 : checkWitness 584 false false 8970 = true := by decide +kernel
private theorem w584_2 : checkWitness 584 true false 8961 = true := by decide +kernel
private theorem cases584 : checkFour 584 (8970,0,8961,0) = true := by
  simp only [checkFour, w584_0, w584_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one584 : Coverage 584 585 := checkList_sound (ws:=[(8970,0,8961,0)]) (by simpa only [checkList, Bool.and_true] using cases584)
private theorem w585_0 : checkWitness 585 false false 66 = true := by decide +kernel
private theorem w585_2 : checkWitness 585 true false 66 = true := by decide +kernel
private theorem cases585 : checkFour 585 (66,0,66,0) = true := by
  simp only [checkFour, w585_0, w585_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one585 : Coverage 585 586 := checkList_sound (ws:=[(66,0,66,0)]) (by simpa only [checkList, Bool.and_true] using cases585)
private theorem w586_0 : checkWitness 586 false false 552 = true := by decide +kernel
private theorem w586_1 : checkWitness 586 false true 4648 = true := by decide +kernel
private theorem w586_2 : checkWitness 586 true false 552 = true := by decide +kernel
private theorem w586_3 : checkWitness 586 true true 4648 = true := by decide +kernel
private theorem cases586 : checkFour 586 (552,4648,552,4648) = true := by
  simp only [checkFour, w586_0, w586_1, w586_2, w586_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one586 : Coverage 586 587 := checkList_sound (ws:=[(552,4648,552,4648)]) (by simpa only [checkList, Bool.and_true] using cases586)
private theorem w587_0 : checkWitness 587 false false 8910 = true := by decide +kernel
private theorem w587_2 : checkWitness 587 true false 8906 = true := by decide +kernel
private theorem cases587 : checkFour 587 (8910,0,8906,0) = true := by
  simp only [checkFour, w587_0, w587_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one587 : Coverage 587 588 := checkList_sound (ws:=[(8910,0,8906,0)]) (by simpa only [checkList, Bool.and_true] using cases587)
private theorem w588_0 : checkWitness 588 false false 68 = true := by decide +kernel
private theorem w588_2 : checkWitness 588 true false 68 = true := by decide +kernel
private theorem cases588 : checkFour 588 (68,0,68,0) = true := by
  simp only [checkFour, w588_0, w588_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one588 : Coverage 588 589 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases588)
private theorem w589_0 : checkWitness 589 false false 590 = true := by decide +kernel
private theorem w589_1 : checkWitness 589 false true 4686 = true := by decide +kernel
private theorem w589_2 : checkWitness 589 true false 590 = true := by decide +kernel
private theorem w589_3 : checkWitness 589 true true 4686 = true := by decide +kernel
private theorem cases589 : checkFour 589 (590,4686,590,4686) = true := by
  simp only [checkFour, w589_0, w589_1, w589_2, w589_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one589 : Coverage 589 590 := checkList_sound (ws:=[(590,4686,590,4686)]) (by simpa only [checkList, Bool.and_true] using cases589)
private theorem w590_0 : checkWitness 590 false false 8931 = true := by decide +kernel
private theorem w590_2 : checkWitness 590 true false 8927 = true := by decide +kernel
private theorem cases590 : checkFour 590 (8931,0,8927,0) = true := by
  simp only [checkFour, w590_0, w590_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one590 : Coverage 590 591 := checkList_sound (ws:=[(8931,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases590)
private theorem w591_0 : checkWitness 591 false false 8966 = true := by decide +kernel
private theorem w591_2 : checkWitness 591 true false 8957 = true := by decide +kernel
private theorem cases591 : checkFour 591 (8966,0,8957,0) = true := by
  simp only [checkFour, w591_0, w591_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one591 : Coverage 591 592 := checkList_sound (ws:=[(8966,0,8957,0)]) (by simpa only [checkList, Bool.and_true] using cases591)
private theorem w592_0 : checkWitness 592 false false 92 = true := by decide +kernel
private theorem w592_2 : checkWitness 592 true false 92 = true := by decide +kernel
private theorem cases592 : checkFour 592 (92,0,92,0) = true := by
  simp only [checkFour, w592_0, w592_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one592 : Coverage 592 593 := checkList_sound (ws:=[(92,0,92,0)]) (by simpa only [checkList, Bool.and_true] using cases592)
private theorem w593_0 : checkWitness 593 false false 678 = true := by decide +kernel
private theorem w593_1 : checkWitness 593 false true 4770 = true := by decide +kernel
private theorem w593_2 : checkWitness 593 true false 669 = true := by decide +kernel
private theorem w593_3 : checkWitness 593 true true 4761 = true := by decide +kernel
private theorem cases593 : checkFour 593 (678,4770,669,4761) = true := by
  simp only [checkFour, w593_0, w593_1, w593_2, w593_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one593 : Coverage 593 594 := checkList_sound (ws:=[(678,4770,669,4761)]) (by simpa only [checkList, Bool.and_true] using cases593)
private theorem w594_0 : checkWitness 594 false false 8927 = true := by decide +kernel
private theorem w594_2 : checkWitness 594 true false 8923 = true := by decide +kernel
private theorem cases594 : checkFour 594 (8927,0,8923,0) = true := by
  simp only [checkFour, w594_0, w594_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one594 : Coverage 594 595 := checkList_sound (ws:=[(8927,0,8923,0)]) (by simpa only [checkList, Bool.and_true] using cases594)
private theorem w595_0 : checkWitness 595 false false 672 = true := by decide +kernel
private theorem w595_1 : checkWitness 595 false true 4764 = true := by decide +kernel
private theorem w595_2 : checkWitness 595 true false 663 = true := by decide +kernel
private theorem w595_3 : checkWitness 595 true true 4755 = true := by decide +kernel
private theorem cases595 : checkFour 595 (672,4764,663,4755) = true := by
  simp only [checkFour, w595_0, w595_1, w595_2, w595_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one595 : Coverage 595 596 := checkList_sound (ws:=[(672,4764,663,4755)]) (by simpa only [checkList, Bool.and_true] using cases595)
private theorem w596_0 : checkWitness 596 false false 8896 = true := by decide +kernel
private theorem w596_2 : checkWitness 596 true false 8892 = true := by decide +kernel
private theorem cases596 : checkFour 596 (8896,0,8892,0) = true := by
  simp only [checkFour, w596_0, w596_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one596 : Coverage 596 597 := checkList_sound (ws:=[(8896,0,8892,0)]) (by simpa only [checkList, Bool.and_true] using cases596)
private theorem w597_0 : checkWitness 597 false false 80 = true := by decide +kernel
private theorem w597_2 : checkWitness 597 true false 80 = true := by decide +kernel
private theorem cases597 : checkFour 597 (80,0,80,0) = true := by
  simp only [checkFour, w597_0, w597_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one597 : Coverage 597 598 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases597)
private theorem w598_0 : checkWitness 598 false false 72 = true := by decide +kernel
private theorem w598_2 : checkWitness 598 true false 72 = true := by decide +kernel
private theorem cases598 : checkFour 598 (72,0,72,0) = true := by
  simp only [checkFour, w598_0, w598_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one598 : Coverage 598 599 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases598)
private theorem w599_0 : checkWitness 599 false false 637 = true := by decide +kernel
private theorem w599_1 : checkWitness 599 false true 4721 = true := by decide +kernel
private theorem w599_2 : checkWitness 599 true false 637 = true := by decide +kernel
private theorem w599_3 : checkWitness 599 true true 4721 = true := by decide +kernel
private theorem cases599 : checkFour 599 (637,4721,637,4721) = true := by
  simp only [checkFour, w599_0, w599_1, w599_2, w599_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one599 : Coverage 599 600 := checkList_sound (ws:=[(637,4721,637,4721)]) (by simpa only [checkList, Bool.and_true] using cases599)
private theorem w600_0 : checkWitness 600 false false 8890 = true := by decide +kernel
private theorem w600_2 : checkWitness 600 true false 8886 = true := by decide +kernel
private theorem cases600 : checkFour 600 (8890,0,8886,0) = true := by
  simp only [checkFour, w600_0, w600_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one600 : Coverage 600 601 := checkList_sound (ws:=[(8890,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases600)
private theorem w601_0 : checkWitness 601 false false 72 = true := by decide +kernel
private theorem w601_2 : checkWitness 601 true false 72 = true := by decide +kernel
private theorem cases601 : checkFour 601 (72,0,72,0) = true := by
  simp only [checkFour, w601_0, w601_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one601 : Coverage 601 602 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases601)
private theorem w602_0 : checkWitness 602 false false 605 = true := by decide +kernel
private theorem w602_1 : checkWitness 602 false true 4701 = true := by decide +kernel
private theorem w602_2 : checkWitness 602 true false 605 = true := by decide +kernel
private theorem w602_3 : checkWitness 602 true true 4701 = true := by decide +kernel
private theorem cases602 : checkFour 602 (605,4701,605,4701) = true := by
  simp only [checkFour, w602_0, w602_1, w602_2, w602_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one602 : Coverage 602 603 := checkList_sound (ws:=[(605,4701,605,4701)]) (by simpa only [checkList, Bool.and_true] using cases602)
private theorem w603_0 : checkWitness 603 false false 8958 = true := by decide +kernel
private theorem w603_2 : checkWitness 603 true false 8949 = true := by decide +kernel
private theorem cases603 : checkFour 603 (8958,0,8949,0) = true := by
  simp only [checkFour, w603_0, w603_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one603 : Coverage 603 604 := checkList_sound (ws:=[(8958,0,8949,0)]) (by simpa only [checkList, Bool.and_true] using cases603)
private theorem w604_0 : checkWitness 604 false false 8904 = true := by decide +kernel
private theorem w604_2 : checkWitness 604 true false 8900 = true := by decide +kernel
private theorem cases604 : checkFour 604 (8904,0,8900,0) = true := by
  simp only [checkFour, w604_0, w604_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one604 : Coverage 604 605 := checkList_sound (ws:=[(8904,0,8900,0)]) (by simpa only [checkList, Bool.and_true] using cases604)
private theorem w605_0 : checkWitness 605 false false 80 = true := by decide +kernel
private theorem w605_2 : checkWitness 605 true false 80 = true := by decide +kernel
private theorem cases605 : checkFour 605 (80,0,80,0) = true := by
  simp only [checkFour, w605_0, w605_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one605 : Coverage 605 606 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases605)
private theorem w606_0 : checkWitness 606 false false 688 = true := by decide +kernel
private theorem w606_1 : checkWitness 606 false true 4776 = true := by decide +kernel
private theorem w606_2 : checkWitness 606 true false 679 = true := by decide +kernel
private theorem w606_3 : checkWitness 606 true true 4767 = true := by decide +kernel
private theorem cases606 : checkFour 606 (688,4776,679,4767) = true := by
  simp only [checkFour, w606_0, w606_1, w606_2, w606_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one606 : Coverage 606 607 := checkList_sound (ws:=[(688,4776,679,4767)]) (by simpa only [checkList, Bool.and_true] using cases606)
private theorem w607_0 : checkWitness 607 false false 8923 = true := by decide +kernel
private theorem w607_2 : checkWitness 607 true false 8919 = true := by decide +kernel
private theorem cases607 : checkFour 607 (8923,0,8919,0) = true := by
  simp only [checkFour, w607_0, w607_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one607 : Coverage 607 608 := checkList_sound (ws:=[(8923,0,8919,0)]) (by simpa only [checkList, Bool.and_true] using cases607)
theorem cover0576 : Coverage 576 608 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one576 one577) (Coverage.join one578 one579)) (Coverage.join (Coverage.join one580 one581) (Coverage.join one582 one583))) (Coverage.join (Coverage.join (Coverage.join one584 one585) (Coverage.join one586 one587)) (Coverage.join (Coverage.join one588 one589) (Coverage.join one590 one591)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one592 one593) (Coverage.join one594 one595)) (Coverage.join (Coverage.join one596 one597) (Coverage.join one598 one599))) (Coverage.join (Coverage.join (Coverage.join one600 one601) (Coverage.join one602 one603)) (Coverage.join (Coverage.join one604 one605) (Coverage.join one606 one607)))))
end NF181PA.Symbolic
