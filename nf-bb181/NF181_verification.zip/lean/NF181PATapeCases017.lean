import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w544_0 : checkWitness 544 false false 8900 = true := by decide +kernel
private theorem w544_2 : checkWitness 544 true false 8896 = true := by decide +kernel
private theorem cases544 : checkFour 544 (8900,0,8896,0) = true := by
  simp only [checkFour, w544_0, w544_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one544 : Coverage 544 545 := checkList_sound (ws:=[(8900,0,8896,0)]) (by simpa only [checkList, Bool.and_true] using cases544)
private theorem w545_0 : checkWitness 545 false false 88 = true := by decide +kernel
private theorem w545_2 : checkWitness 545 true false 88 = true := by decide +kernel
private theorem cases545 : checkFour 545 (88,0,88,0) = true := by
  simp only [checkFour, w545_0, w545_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one545 : Coverage 545 546 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases545)
private theorem w546_0 : checkWitness 546 false false 80 = true := by decide +kernel
private theorem w546_2 : checkWitness 546 true false 80 = true := by decide +kernel
private theorem cases546 : checkFour 546 (80,0,80,0) = true := by
  simp only [checkFour, w546_0, w546_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one546 : Coverage 546 547 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases546)
private theorem w547_0 : checkWitness 547 false false 641 = true := by decide +kernel
private theorem w547_1 : checkWitness 547 false true 4725 = true := by decide +kernel
private theorem w547_2 : checkWitness 547 true false 641 = true := by decide +kernel
private theorem w547_3 : checkWitness 547 true true 4725 = true := by decide +kernel
private theorem cases547 : checkFour 547 (641,4725,641,4725) = true := by
  simp only [checkFour, w547_0, w547_1, w547_2, w547_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one547 : Coverage 547 548 := checkList_sound (ws:=[(641,4725,641,4725)]) (by simpa only [checkList, Bool.and_true] using cases547)
private theorem w548_0 : checkWitness 548 false false 8894 = true := by decide +kernel
private theorem w548_2 : checkWitness 548 true false 8890 = true := by decide +kernel
private theorem cases548 : checkFour 548 (8894,0,8890,0) = true := by
  simp only [checkFour, w548_0, w548_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one548 : Coverage 548 549 := checkList_sound (ws:=[(8894,0,8890,0)]) (by simpa only [checkList, Bool.and_true] using cases548)
private theorem w549_0 : checkWitness 549 false false 80 = true := by decide +kernel
private theorem w549_2 : checkWitness 549 true false 80 = true := by decide +kernel
private theorem cases549 : checkFour 549 (80,0,80,0) = true := by
  simp only [checkFour, w549_0, w549_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one549 : Coverage 549 550 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases549)
private theorem w550_0 : checkWitness 550 false false 639 = true := by decide +kernel
private theorem w550_1 : checkWitness 550 false true 4731 = true := by decide +kernel
private theorem w550_2 : checkWitness 550 true false 630 = true := by decide +kernel
private theorem w550_3 : checkWitness 550 true true 4722 = true := by decide +kernel
private theorem cases550 : checkFour 550 (639,4731,630,4722) = true := by
  simp only [checkFour, w550_0, w550_1, w550_2, w550_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one550 : Coverage 550 551 := checkList_sound (ws:=[(639,4731,630,4722)]) (by simpa only [checkList, Bool.and_true] using cases550)
private theorem w551_0 : checkWitness 551 false false 8936 = true := by decide +kernel
private theorem w551_2 : checkWitness 551 true false 8927 = true := by decide +kernel
private theorem cases551 : checkFour 551 (8936,0,8927,0) = true := by
  simp only [checkFour, w551_0, w551_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one551 : Coverage 551 552 := checkList_sound (ws:=[(8936,0,8927,0)]) (by simpa only [checkList, Bool.and_true] using cases551)
private theorem w552_0 : checkWitness 552 false false 8882 = true := by decide +kernel
private theorem w552_2 : checkWitness 552 true false 8878 = true := by decide +kernel
private theorem cases552 : checkFour 552 (8882,0,8878,0) = true := by
  simp only [checkFour, w552_0, w552_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one552 : Coverage 552 553 := checkList_sound (ws:=[(8882,0,8878,0)]) (by simpa only [checkList, Bool.and_true] using cases552)
private theorem w553_0 : checkWitness 553 false false 74 = true := by decide +kernel
private theorem w553_2 : checkWitness 553 true false 74 = true := by decide +kernel
private theorem cases553 : checkFour 553 (74,0,74,0) = true := by
  simp only [checkFour, w553_0, w553_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one553 : Coverage 553 554 := checkList_sound (ws:=[(74,0,74,0)]) (by simpa only [checkList, Bool.and_true] using cases553)
private theorem w554_0 : checkWitness 554 false false 666 = true := by decide +kernel
private theorem w554_1 : checkWitness 554 false true 4758 = true := by decide +kernel
private theorem w554_2 : checkWitness 554 true false 657 = true := by decide +kernel
private theorem w554_3 : checkWitness 554 true true 4749 = true := by decide +kernel
private theorem cases554 : checkFour 554 (666,4758,657,4749) = true := by
  simp only [checkFour, w554_0, w554_1, w554_2, w554_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one554 : Coverage 554 555 := checkList_sound (ws:=[(666,4758,657,4749)]) (by simpa only [checkList, Bool.and_true] using cases554)
private theorem w555_0 : checkWitness 555 false false 8943 = true := by decide +kernel
private theorem w555_2 : checkWitness 555 true false 8934 = true := by decide +kernel
private theorem cases555 : checkFour 555 (8943,0,8934,0) = true := by
  simp only [checkFour, w555_0, w555_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one555 : Coverage 555 556 := checkList_sound (ws:=[(8943,0,8934,0)]) (by simpa only [checkList, Bool.and_true] using cases555)
private theorem w556_0 : checkWitness 556 false false 58 = true := by decide +kernel
private theorem w556_2 : checkWitness 556 true false 58 = true := by decide +kernel
private theorem cases556 : checkFour 556 (58,0,58,0) = true := by
  simp only [checkFour, w556_0, w556_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one556 : Coverage 556 557 := checkList_sound (ws:=[(58,0,58,0)]) (by simpa only [checkList, Bool.and_true] using cases556)
private theorem w557_0 : checkWitness 557 false false 530 = true := by decide +kernel
private theorem w557_1 : checkWitness 557 false true 4626 = true := by decide +kernel
private theorem w557_2 : checkWitness 557 true false 530 = true := by decide +kernel
private theorem w557_3 : checkWitness 557 true true 4626 = true := by decide +kernel
private theorem cases557 : checkFour 557 (530,4626,530,4626) = true := by
  simp only [checkFour, w557_0, w557_1, w557_2, w557_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one557 : Coverage 557 558 := checkList_sound (ws:=[(530,4626,530,4626)]) (by simpa only [checkList, Bool.and_true] using cases557)
private theorem w558_0 : checkWitness 558 false false 8925 = true := by decide +kernel
private theorem w558_2 : checkWitness 558 true false 8921 = true := by decide +kernel
private theorem cases558 : checkFour 558 (8925,0,8921,0) = true := by
  simp only [checkFour, w558_0, w558_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one558 : Coverage 558 559 := checkList_sound (ws:=[(8925,0,8921,0)]) (by simpa only [checkList, Bool.and_true] using cases558)
private theorem w559_0 : checkWitness 559 false false 656 = true := by decide +kernel
private theorem w559_1 : checkWitness 559 false true 4752 = true := by decide +kernel
private theorem w559_2 : checkWitness 559 true false 647 = true := by decide +kernel
private theorem w559_3 : checkWitness 559 true true 4743 = true := by decide +kernel
private theorem cases559 : checkFour 559 (656,4752,647,4743) = true := by
  simp only [checkFour, w559_0, w559_1, w559_2, w559_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one559 : Coverage 559 560 := checkList_sound (ws:=[(656,4752,647,4743)]) (by simpa only [checkList, Bool.and_true] using cases559)
private theorem w560_0 : checkWitness 560 false false 192 = true := by decide +kernel
private theorem w560_2 : checkWitness 560 true false 192 = true := by decide +kernel
private theorem cases560 : checkFour 560 (192,0,192,0) = true := by
  simp only [checkFour, w560_0, w560_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one560 : Coverage 560 561 := checkList_sound (ws:=[(192,0,192,0)]) (by simpa only [checkList, Bool.and_true] using cases560)
private theorem w561_0 : checkWitness 561 false false 611 = true := by decide +kernel
private theorem w561_1 : checkWitness 561 false true 4699 = true := by decide +kernel
private theorem w561_2 : checkWitness 561 true false 611 = true := by decide +kernel
private theorem w561_3 : checkWitness 561 true true 4699 = true := by decide +kernel
private theorem cases561 : checkFour 561 (611,4699,611,4699) = true := by
  simp only [checkFour, w561_0, w561_1, w561_2, w561_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one561 : Coverage 561 562 := checkList_sound (ws:=[(611,4699,611,4699)]) (by simpa only [checkList, Bool.and_true] using cases561)
private theorem w562_0 : checkWitness 562 false false 8940 = true := by decide +kernel
private theorem w562_2 : checkWitness 562 true false 8931 = true := by decide +kernel
private theorem cases562 : checkFour 562 (8940,0,8931,0) = true := by
  simp only [checkFour, w562_0, w562_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one562 : Coverage 562 563 := checkList_sound (ws:=[(8940,0,8931,0)]) (by simpa only [checkList, Bool.and_true] using cases562)
private theorem w563_0 : checkWitness 563 false false 76 = true := by decide +kernel
private theorem w563_2 : checkWitness 563 true false 76 = true := by decide +kernel
private theorem cases563 : checkFour 563 (76,0,76,0) = true := by
  simp only [checkFour, w563_0, w563_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one563 : Coverage 563 564 := checkList_sound (ws:=[(76,0,76,0)]) (by simpa only [checkList, Bool.and_true] using cases563)
private theorem w564_0 : checkWitness 564 false false 68 = true := by decide +kernel
private theorem w564_2 : checkWitness 564 true false 68 = true := by decide +kernel
private theorem cases564 : checkFour 564 (68,0,68,0) = true := by
  simp only [checkFour, w564_0, w564_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one564 : Coverage 564 565 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases564)
private theorem w565_0 : checkWitness 565 false false 617 = true := by decide +kernel
private theorem w565_1 : checkWitness 565 false true 4709 = true := by decide +kernel
private theorem w565_2 : checkWitness 565 true false 617 = true := by decide +kernel
private theorem w565_3 : checkWitness 565 true true 4709 = true := by decide +kernel
private theorem cases565 : checkFour 565 (617,4709,617,4709) = true := by
  simp only [checkFour, w565_0, w565_1, w565_2, w565_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one565 : Coverage 565 566 := checkList_sound (ws:=[(617,4709,617,4709)]) (by simpa only [checkList, Bool.and_true] using cases565)
private theorem w566_0 : checkWitness 566 false false 8878 = true := by decide +kernel
private theorem w566_2 : checkWitness 566 true false 8874 = true := by decide +kernel
private theorem cases566 : checkFour 566 (8878,0,8874,0) = true := by
  simp only [checkFour, w566_0, w566_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one566 : Coverage 566 567 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases566)
private theorem w567_0 : checkWitness 567 false false 68 = true := by decide +kernel
private theorem w567_2 : checkWitness 567 true false 68 = true := by decide +kernel
private theorem cases567 : checkFour 567 (68,0,68,0) = true := by
  simp only [checkFour, w567_0, w567_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one567 : Coverage 567 568 := checkList_sound (ws:=[(68,0,68,0)]) (by simpa only [checkList, Bool.and_true] using cases567)
private theorem w568_0 : checkWitness 568 false false 572 = true := by decide +kernel
private theorem w568_1 : checkWitness 568 false true 4668 = true := by decide +kernel
private theorem w568_2 : checkWitness 568 true false 572 = true := by decide +kernel
private theorem w568_3 : checkWitness 568 true true 4668 = true := by decide +kernel
private theorem cases568 : checkFour 568 (572,4668,572,4668) = true := by
  simp only [checkFour, w568_0, w568_1, w568_2, w568_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one568 : Coverage 568 569 := checkList_sound (ws:=[(572,4668,572,4668)]) (by simpa only [checkList, Bool.and_true] using cases568)
private theorem w569_0 : checkWitness 569 false false 8913 = true := by decide +kernel
private theorem w569_2 : checkWitness 569 true false 8909 = true := by decide +kernel
private theorem cases569 : checkFour 569 (8913,0,8909,0) = true := by
  simp only [checkFour, w569_0, w569_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one569 : Coverage 569 570 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases569)
private theorem w570_0 : checkWitness 570 false false 8948 = true := by decide +kernel
private theorem w570_2 : checkWitness 570 true false 8939 = true := by decide +kernel
private theorem cases570 : checkFour 570 (8948,0,8939,0) = true := by
  simp only [checkFour, w570_0, w570_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one570 : Coverage 570 571 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases570)
private theorem w571_0 : checkWitness 571 false false 86 = true := by decide +kernel
private theorem w571_2 : checkWitness 571 true false 86 = true := by decide +kernel
private theorem cases571 : checkFour 571 (86,0,86,0) = true := by
  simp only [checkFour, w571_0, w571_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one571 : Coverage 571 572 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases571)
private theorem w572_0 : checkWitness 572 false false 660 = true := by decide +kernel
private theorem w572_1 : checkWitness 572 false true 4752 = true := by decide +kernel
private theorem w572_2 : checkWitness 572 true false 651 = true := by decide +kernel
private theorem w572_3 : checkWitness 572 true true 4743 = true := by decide +kernel
private theorem cases572 : checkFour 572 (660,4752,651,4743) = true := by
  simp only [checkFour, w572_0, w572_1, w572_2, w572_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one572 : Coverage 572 573 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases572)
private theorem w573_0 : checkWitness 573 false false 8909 = true := by decide +kernel
private theorem w573_2 : checkWitness 573 true false 8905 = true := by decide +kernel
private theorem cases573 : checkFour 573 (8909,0,8905,0) = true := by
  simp only [checkFour, w573_0, w573_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one573 : Coverage 573 574 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases573)
private theorem w574_0 : checkWitness 574 false false 654 = true := by decide +kernel
private theorem w574_1 : checkWitness 574 false true 4746 = true := by decide +kernel
private theorem w574_2 : checkWitness 574 true false 645 = true := by decide +kernel
private theorem w574_3 : checkWitness 574 true true 4737 = true := by decide +kernel
private theorem cases574 : checkFour 574 (654,4746,645,4737) = true := by
  simp only [checkFour, w574_0, w574_1, w574_2, w574_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one574 : Coverage 574 575 := checkList_sound (ws:=[(654,4746,645,4737)]) (by simpa only [checkList, Bool.and_true] using cases574)
private theorem w575_0 : checkWitness 575 false false 8878 = true := by decide +kernel
private theorem w575_2 : checkWitness 575 true false 8874 = true := by decide +kernel
private theorem cases575 : checkFour 575 (8878,0,8874,0) = true := by
  simp only [checkFour, w575_0, w575_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one575 : Coverage 575 576 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases575)
theorem cover0544 : Coverage 544 576 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one544 one545) (Coverage.join one546 one547)) (Coverage.join (Coverage.join one548 one549) (Coverage.join one550 one551))) (Coverage.join (Coverage.join (Coverage.join one552 one553) (Coverage.join one554 one555)) (Coverage.join (Coverage.join one556 one557) (Coverage.join one558 one559)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one560 one561) (Coverage.join one562 one563)) (Coverage.join (Coverage.join one564 one565) (Coverage.join one566 one567))) (Coverage.join (Coverage.join (Coverage.join one568 one569) (Coverage.join one570 one571)) (Coverage.join (Coverage.join one572 one573) (Coverage.join one574 one575)))))
end NF181PA.Symbolic
