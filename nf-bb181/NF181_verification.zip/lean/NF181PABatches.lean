module
public import NF181PAControl
public import Src181Straight
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch.RegisterFields NF181PA.Packed
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 15000
set_option maxHeartbeats 5000000
namespace PA192.ModelSearch.Register181.Commands
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem emitFields (f n t s c u v y d w : V) :
    let z := front8 (u+d) (v+y) c u (cantor t s)
    Reach (atS 40 f n t s c u v (cantor y (cantor d w)))
      (atS 2849 f n (left z) (right z) c (u+d) (v+y) w) := by
  simpa only [atS,Nat.cast_ofNat] using emitPacked f n t s c u v y d w

noncomputable def batchView (f n b : V) : V :=
  atS 39 f n (left (body b)) (right (body b)) (rank b) (aval b) (bval b) (fields b)

theorem entry_pack (f n j z a b w : V) :
    batchView f n (packBatch j z a b w) = atS 39 f n (left z) (right z) j a b w := by
  simp [batchView,packBatch,body,rank,aval,bval,fields]

theorem batchAfterOne (f n j z a b raw : V) :
    Reach (batchView f n (packBatch (j+1) z a b raw))
      (batchView f n (nextBatch (packBatch (j+1) z a b raw))) := by
  let y := left raw
  let d := left (right raw)
  let w := right (right raw)
  let z' := front8 (a+d) (b+y) j a z
  have plus := site0039Positive f n (left z) (right z) j a b 0 0 raw
  have step := emitFields f n (left z) (right z) j a b y d w
  dsimp only at step
  rw [show cantor y (cantor d w)=raw from pairUnpackTwo raw, pairUnpack z] at step
  have finish := site2849 f n (left z') (right z') j (a+d) (b+y) 0 0 w
  have nxt := next_literal j z a b y d w
  rw [show cantor y (cantor d w)=raw from pairUnpackTwo raw] at nxt
  rw [nxt,entry_pack,entry_pack]
  exact (plus.trans step).trans finish

/-- At rank zero the AX loop falls through MP. Its test always fails because
the top is the eighth row and the incoming cache is its second parameter. -/
theorem batchExit (f n z a b w : V) (last : left z = row8 a b) :
    Reach (batchView f n (packBatch 0 z a b w)) (vm 0 f n (afterAX z) w) := by
  have start := site0039Zero f n (left z) (right z) 0 a b 0 0 w
  have fail : b ≠ imp (left z) a := last ▸ last_ne a b
  rw [entry_pack]
  simpa only [afterAX,vm_state,atS,fail,ite_false] using start.trans (mpAndPop f n (left z) (right z) a b w)

theorem batchesRun (f n : V) : ∀ r : V, ∀ z a b raw,
    left z = row8 a b →
    Reach (batchView f n (packBatch r z a b raw))
      (vm 0 f n (afterAX (body (iterate nextBatch r (packBatch r z a b raw))))
        (fields (iterate nextBatch r (packBatch r z a b raw)))) := by
  apply modelInduct
  · unfold batchView atS packBatch rank body aval bval fields vm config vector top stack param cache
    unfold row8
    definability
  · intro z a b w head
    simpa only [iterate_zero,body,fields,packBatch,pi₁_pair,pi₂_pair] using batchExit f n z a b w head
  · intro j ih z a b raw _
    let y := left raw
    let d := left (right raw)
    let w := right (right raw)
    let z' := front8 (a+d) (b+y) j a z
    have next : nextBatch (packBatch (j+1) z a b raw) = packBatch j z' (a+d) (b+y) w := by
      have h := next_literal j z a b y d w
      rwa [show cantor y (cantor d w)=raw from pairUnpackTwo raw] at h
    have head : left z'=row8 (a+d) (b+y) := by simp [z',front8]
    have one := batchAfterOne f n j z a b raw
    rw [next] at one
    rw [iterate_succ_left,next]
    exact one.trans (ih z' (a+d) (b+y) w head)

theorem axTagged (f n t s p h outer y d c raw : V) :
    let z := axRaw outer y d c raw (state t s h p)
    Reach (atS 10 f n t s 0 p h (cantor (c+2) (cantor outer (cantor y (cantor d raw)))))
      (vm 0 f n (pi₁ z) (pi₂ z)) := by
  dsimp only
  let tail := cantor y (cantor d raw)
  let pp := p+outer
  let z := front8 (pp+d) (h+y) c pp (cantor t s)
  have read := readFields f n t s 0 p h (c+2) outer tail
  have guard := site0038Positive f n t s (c+1) pp h 0 0 tail
  have go : Reach (atS 38 f n t s (0+(c+2)) pp h tail) (atS 39 f n t s (c+1) pp h tail) := by
    simpa only [atS,zero_add,show c+1+1=c+2 by ring] using guard
  have first := site0039Positive f n t s c pp h 0 0 tail
  have emit := emitFields f n t s c pp h y d raw
  have back := site2849 f n (left z) (right z) c (pp+d) (h+y) 0 0 raw
  have seg := (((read.trans go).trans first).trans emit).trans back
  have run := batchesRun f n c z (pp+d) (h+y) raw (by simp [z,front8])
  rw [entry_pack] at run
  simpa only [axRaw,state,param,cache,top,stack,pi₁_pair,pi₂_pair,pp,z,tail] using seg.trans run

end PA192.ModelSearch.Register181.Commands
#print axioms PA192.ModelSearch.Register181.Commands.axTagged
