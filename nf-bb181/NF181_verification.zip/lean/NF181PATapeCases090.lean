import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2880_0 : checkWitness 2880 false false 641 = true := by decide +kernel
private theorem w2880_1 : checkWitness 2880 false true 4729 = true := by decide +kernel
private theorem w2880_2 : checkWitness 2880 true false 641 = true := by decide +kernel
private theorem w2880_3 : checkWitness 2880 true true 4729 = true := by decide +kernel
private theorem cases2880 : checkFour 2880 (641,4729,641,4729) = true := by
  simp only [checkFour, w2880_0, w2880_1, w2880_2, w2880_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2880 : Coverage 2880 2881 := checkList_sound (ws:=[(641,4729,641,4729)]) (by simpa only [checkList, Bool.and_true] using cases2880)
private theorem w2881_0 : checkWitness 2881 false false 8970 = true := by decide +kernel
private theorem w2881_2 : checkWitness 2881 true false 8961 = true := by decide +kernel
private theorem cases2881 : checkFour 2881 (8970,0,8961,0) = true := by
  simp only [checkFour, w2881_0, w2881_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2881 : Coverage 2881 2882 := checkList_sound (ws:=[(8970,0,8961,0)]) (by simpa only [checkList, Bool.and_true] using cases2881)
private theorem w2882_0 : checkWitness 2882 false false 46 = true := by decide +kernel
private theorem w2882_2 : checkWitness 2882 true false 46 = true := by decide +kernel
private theorem cases2882 : checkFour 2882 (46,0,46,0) = true := by
  simp only [checkFour, w2882_0, w2882_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2882 : Coverage 2882 2883 := checkList_sound (ws:=[(46,0,46,0)]) (by simpa only [checkList, Bool.and_true] using cases2882)
private theorem w2883_0 : checkWitness 2883 false false 38 = true := by decide +kernel
private theorem w2883_2 : checkWitness 2883 true false 38 = true := by decide +kernel
private theorem cases2883 : checkFour 2883 (38,0,38,0) = true := by
  simp only [checkFour, w2883_0, w2883_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2883 : Coverage 2883 2884 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases2883)
private theorem w2884_0 : checkWitness 2884 false false 647 = true := by decide +kernel
private theorem w2884_1 : checkWitness 2884 false true 4739 = true := by decide +kernel
private theorem w2884_2 : checkWitness 2884 true false 647 = true := by decide +kernel
private theorem w2884_3 : checkWitness 2884 true true 4739 = true := by decide +kernel
private theorem cases2884 : checkFour 2884 (647,4739,647,4739) = true := by
  simp only [checkFour, w2884_0, w2884_1, w2884_2, w2884_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2884 : Coverage 2884 2885 := checkList_sound (ws:=[(647,4739,647,4739)]) (by simpa only [checkList, Bool.and_true] using cases2884)
private theorem w2885_0 : checkWitness 2885 false false 8908 = true := by decide +kernel
private theorem w2885_2 : checkWitness 2885 true false 8904 = true := by decide +kernel
private theorem cases2885 : checkFour 2885 (8908,0,8904,0) = true := by
  simp only [checkFour, w2885_0, w2885_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2885 : Coverage 2885 2886 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases2885)
private theorem w2886_0 : checkWitness 2886 false false 38 = true := by decide +kernel
private theorem w2886_2 : checkWitness 2886 true false 38 = true := by decide +kernel
private theorem cases2886 : checkFour 2886 (38,0,38,0) = true := by
  simp only [checkFour, w2886_0, w2886_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2886 : Coverage 2886 2887 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases2886)
private theorem w2887_0 : checkWitness 2887 false false 602 = true := by decide +kernel
private theorem w2887_1 : checkWitness 2887 false true 4698 = true := by decide +kernel
private theorem w2887_2 : checkWitness 2887 true false 602 = true := by decide +kernel
private theorem w2887_3 : checkWitness 2887 true true 4698 = true := by decide +kernel
private theorem cases2887 : checkFour 2887 (602,4698,602,4698) = true := by
  simp only [checkFour, w2887_0, w2887_1, w2887_2, w2887_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2887 : Coverage 2887 2888 := checkList_sound (ws:=[(602,4698,602,4698)]) (by simpa only [checkList, Bool.and_true] using cases2887)
private theorem w2888_0 : checkWitness 2888 false false 8943 = true := by decide +kernel
private theorem w2888_2 : checkWitness 2888 true false 8939 = true := by decide +kernel
private theorem cases2888 : checkFour 2888 (8943,0,8939,0) = true := by
  simp only [checkFour, w2888_0, w2888_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2888 : Coverage 2888 2889 := checkList_sound (ws:=[(8943,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2888)
private theorem w2889_0 : checkWitness 2889 false false 8978 = true := by decide +kernel
private theorem w2889_2 : checkWitness 2889 true false 8969 = true := by decide +kernel
private theorem cases2889 : checkFour 2889 (8978,0,8969,0) = true := by
  simp only [checkFour, w2889_0, w2889_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2889 : Coverage 2889 2890 := checkList_sound (ws:=[(8978,0,8969,0)]) (by simpa only [checkList, Bool.and_true] using cases2889)
private theorem w2890_0 : checkWitness 2890 false false 56 = true := by decide +kernel
private theorem w2890_2 : checkWitness 2890 true false 56 = true := by decide +kernel
private theorem cases2890 : checkFour 2890 (56,0,56,0) = true := by
  simp only [checkFour, w2890_0, w2890_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2890 : Coverage 2890 2891 := checkList_sound (ws:=[(56,0,56,0)]) (by simpa only [checkList, Bool.and_true] using cases2890)
private theorem w2891_0 : checkWitness 2891 false false 690 = true := by decide +kernel
private theorem w2891_1 : checkWitness 2891 false true 4782 = true := by decide +kernel
private theorem w2891_2 : checkWitness 2891 true false 681 = true := by decide +kernel
private theorem w2891_3 : checkWitness 2891 true true 4773 = true := by decide +kernel
private theorem cases2891 : checkFour 2891 (690,4782,681,4773) = true := by
  simp only [checkFour, w2891_0, w2891_1, w2891_2, w2891_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2891 : Coverage 2891 2892 := checkList_sound (ws:=[(690,4782,681,4773)]) (by simpa only [checkList, Bool.and_true] using cases2891)
private theorem w2892_0 : checkWitness 2892 false false 8939 = true := by decide +kernel
private theorem w2892_2 : checkWitness 2892 true false 8935 = true := by decide +kernel
private theorem cases2892 : checkFour 2892 (8939,0,8935,0) = true := by
  simp only [checkFour, w2892_0, w2892_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2892 : Coverage 2892 2893 := checkList_sound (ws:=[(8939,0,8935,0)]) (by simpa only [checkList, Bool.and_true] using cases2892)
private theorem w2893_0 : checkWitness 2893 false false 684 = true := by decide +kernel
private theorem w2893_1 : checkWitness 2893 false true 4776 = true := by decide +kernel
private theorem w2893_2 : checkWitness 2893 true false 675 = true := by decide +kernel
private theorem w2893_3 : checkWitness 2893 true true 4767 = true := by decide +kernel
private theorem cases2893 : checkFour 2893 (684,4776,675,4767) = true := by
  simp only [checkFour, w2893_0, w2893_1, w2893_2, w2893_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2893 : Coverage 2893 2894 := checkList_sound (ws:=[(684,4776,675,4767)]) (by simpa only [checkList, Bool.and_true] using cases2893)
private theorem w2894_0 : checkWitness 2894 false false 8908 = true := by decide +kernel
private theorem w2894_2 : checkWitness 2894 true false 8904 = true := by decide +kernel
private theorem cases2894 : checkFour 2894 (8908,0,8904,0) = true := by
  simp only [checkFour, w2894_0, w2894_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2894 : Coverage 2894 2895 := checkList_sound (ws:=[(8908,0,8904,0)]) (by simpa only [checkList, Bool.and_true] using cases2894)
private theorem w2895_0 : checkWitness 2895 false false 44 = true := by decide +kernel
private theorem w2895_2 : checkWitness 2895 true false 44 = true := by decide +kernel
private theorem cases2895 : checkFour 2895 (44,0,44,0) = true := by
  simp only [checkFour, w2895_0, w2895_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2895 : Coverage 2895 2896 := checkList_sound (ws:=[(44,0,44,0)]) (by simpa only [checkList, Bool.and_true] using cases2895)
private theorem w2896_0 : checkWitness 2896 false false 36 = true := by decide +kernel
private theorem w2896_2 : checkWitness 2896 true false 36 = true := by decide +kernel
private theorem cases2896 : checkFour 2896 (36,0,36,0) = true := by
  simp only [checkFour, w2896_0, w2896_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2896 : Coverage 2896 2897 := checkList_sound (ws:=[(36,0,36,0)]) (by simpa only [checkList, Bool.and_true] using cases2896)
private theorem w2897_0 : checkWitness 2897 false false 655 = true := by decide +kernel
private theorem w2897_1 : checkWitness 2897 false true 4739 = true := by decide +kernel
private theorem w2897_2 : checkWitness 2897 true false 655 = true := by decide +kernel
private theorem w2897_3 : checkWitness 2897 true true 4739 = true := by decide +kernel
private theorem cases2897 : checkFour 2897 (655,4739,655,4739) = true := by
  simp only [checkFour, w2897_0, w2897_1, w2897_2, w2897_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2897 : Coverage 2897 2898 := checkList_sound (ws:=[(655,4739,655,4739)]) (by simpa only [checkList, Bool.and_true] using cases2897)
private theorem w2898_0 : checkWitness 2898 false false 8924 = true := by decide +kernel
private theorem w2898_2 : checkWitness 2898 true false 8920 = true := by decide +kernel
private theorem cases2898 : checkFour 2898 (8924,0,8920,0) = true := by
  simp only [checkFour, w2898_0, w2898_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2898 : Coverage 2898 2899 := checkList_sound (ws:=[(8924,0,8920,0)]) (by simpa only [checkList, Bool.and_true] using cases2898)
private theorem w2899_0 : checkWitness 2899 false false 8920 = true := by decide +kernel
private theorem w2899_2 : checkWitness 2899 true false 8916 = true := by decide +kernel
private theorem cases2899 : checkFour 2899 (8920,0,8916,0) = true := by
  simp only [checkFour, w2899_0, w2899_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2899 : Coverage 2899 2900 := checkList_sound (ws:=[(8920,0,8916,0)]) (by simpa only [checkList, Bool.and_true] using cases2899)
private theorem w2900_0 : checkWitness 2900 false false 50 = true := by decide +kernel
private theorem w2900_2 : checkWitness 2900 true false 50 = true := by decide +kernel
private theorem cases2900 : checkFour 2900 (50,0,50,0) = true := by
  simp only [checkFour, w2900_0, w2900_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2900 : Coverage 2900 2901 := checkList_sound (ws:=[(50,0,50,0)]) (by simpa only [checkList, Bool.and_true] using cases2900)
private theorem w2901_0 : checkWitness 2901 false false 616 = true := by decide +kernel
private theorem w2901_1 : checkWitness 2901 false true 4712 = true := by decide +kernel
private theorem w2901_2 : checkWitness 2901 true false 616 = true := by decide +kernel
private theorem w2901_3 : checkWitness 2901 true true 4712 = true := by decide +kernel
private theorem cases2901 : checkFour 2901 (616,4712,616,4712) = true := by
  simp only [checkFour, w2901_0, w2901_1, w2901_2, w2901_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2901 : Coverage 2901 2902 := checkList_sound (ws:=[(616,4712,616,4712)]) (by simpa only [checkList, Bool.and_true] using cases2901)
private theorem w2902_0 : checkWitness 2902 false false 8978 = true := by decide +kernel
private theorem w2902_2 : checkWitness 2902 true false 8969 = true := by decide +kernel
private theorem cases2902 : checkFour 2902 (8978,0,8969,0) = true := by
  simp only [checkFour, w2902_0, w2902_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2902 : Coverage 2902 2903 := checkList_sound (ws:=[(8978,0,8969,0)]) (by simpa only [checkList, Bool.and_true] using cases2902)
private theorem w2903_0 : checkWitness 2903 false false 32 = true := by decide +kernel
private theorem w2903_2 : checkWitness 2903 true false 32 = true := by decide +kernel
private theorem cases2903 : checkFour 2903 (32,0,32,0) = true := by
  simp only [checkFour, w2903_0, w2903_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2903 : Coverage 2903 2904 := checkList_sound (ws:=[(32,0,32,0)]) (by simpa only [checkList, Bool.and_true] using cases2903)
private theorem w2904_0 : checkWitness 2904 false false 704 = true := by decide +kernel
private theorem w2904_1 : checkWitness 2904 false true 4796 = true := by decide +kernel
private theorem w2904_2 : checkWitness 2904 true false 695 = true := by decide +kernel
private theorem w2904_3 : checkWitness 2904 true true 4787 = true := by decide +kernel
private theorem cases2904 : checkFour 2904 (704,4796,695,4787) = true := by
  simp only [checkFour, w2904_0, w2904_1, w2904_2, w2904_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2904 : Coverage 2904 2905 := checkList_sound (ws:=[(704,4796,695,4787)]) (by simpa only [checkList, Bool.and_true] using cases2904)
private theorem w2905_0 : checkWitness 2905 false false 669 = true := by decide +kernel
private theorem w2905_1 : checkWitness 2905 false true 4765 = true := by decide +kernel
private theorem w2905_2 : checkWitness 2905 true false 660 = true := by decide +kernel
private theorem w2905_3 : checkWitness 2905 true true 4756 = true := by decide +kernel
private theorem cases2905 : checkFour 2905 (669,4765,660,4756) = true := by
  simp only [checkFour, w2905_0, w2905_1, w2905_2, w2905_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2905 : Coverage 2905 2906 := checkList_sound (ws:=[(669,4765,660,4756)]) (by simpa only [checkList, Bool.and_true] using cases2905)
private theorem w2906_0 : checkWitness 2906 false false 44 = true := by decide +kernel
private theorem w2906_2 : checkWitness 2906 true false 44 = true := by decide +kernel
private theorem cases2906 : checkFour 2906 (44,0,44,0) = true := by
  simp only [checkFour, w2906_0, w2906_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2906 : Coverage 2906 2907 := checkList_sound (ws:=[(44,0,44,0)]) (by simpa only [checkList, Bool.and_true] using cases2906)
private theorem w2907_0 : checkWitness 2907 false false 8965 = true := by decide +kernel
private theorem w2907_2 : checkWitness 2907 true false 8956 = true := by decide +kernel
private theorem cases2907 : checkFour 2907 (8965,0,8956,0) = true := by
  simp only [checkFour, w2907_0, w2907_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2907 : Coverage 2907 2908 := checkList_sound (ws:=[(8965,0,8956,0)]) (by simpa only [checkList, Bool.and_true] using cases2907)
private theorem w2908_0 : checkWitness 2908 false false 698 = true := by decide +kernel
private theorem w2908_1 : checkWitness 2908 false true 4778 = true := by decide +kernel
private theorem w2908_2 : checkWitness 2908 true false 689 = true := by decide +kernel
private theorem w2908_3 : checkWitness 2908 true true 4769 = true := by decide +kernel
private theorem cases2908 : checkFour 2908 (698,4778,689,4769) = true := by
  simp only [checkFour, w2908_0, w2908_1, w2908_2, w2908_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2908 : Coverage 2908 2909 := checkList_sound (ws:=[(698,4778,689,4769)]) (by simpa only [checkList, Bool.and_true] using cases2908)
private theorem w2909_0 : checkWitness 2909 false false 8963 = true := by decide +kernel
private theorem w2909_2 : checkWitness 2909 true false 8954 = true := by decide +kernel
private theorem cases2909 : checkFour 2909 (8963,0,8954,0) = true := by
  simp only [checkFour, w2909_0, w2909_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2909 : Coverage 2909 2910 := checkList_sound (ws:=[(8963,0,8954,0)]) (by simpa only [checkList, Bool.and_true] using cases2909)
private theorem w2910_0 : checkWitness 2910 false false 38 = true := by decide +kernel
private theorem w2910_2 : checkWitness 2910 true false 38 = true := by decide +kernel
private theorem cases2910 : checkFour 2910 (38,0,38,0) = true := by
  simp only [checkFour, w2910_0, w2910_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2910 : Coverage 2910 2911 := checkList_sound (ws:=[(38,0,38,0)]) (by simpa only [checkList, Bool.and_true] using cases2910)
private theorem w2911_0 : checkWitness 2911 false false 667 = true := by decide +kernel
private theorem w2911_1 : checkWitness 2911 false true 4763 = true := by decide +kernel
private theorem w2911_2 : checkWitness 2911 true false 658 = true := by decide +kernel
private theorem w2911_3 : checkWitness 2911 true true 4754 = true := by decide +kernel
private theorem cases2911 : checkFour 2911 (667,4763,658,4754) = true := by
  simp only [checkFour, w2911_0, w2911_1, w2911_2, w2911_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2911 : Coverage 2911 2912 := checkList_sound (ws:=[(667,4763,658,4754)]) (by simpa only [checkList, Bool.and_true] using cases2911)
theorem cover2880 : Coverage 2880 2912 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2880 one2881) (Coverage.join one2882 one2883)) (Coverage.join (Coverage.join one2884 one2885) (Coverage.join one2886 one2887))) (Coverage.join (Coverage.join (Coverage.join one2888 one2889) (Coverage.join one2890 one2891)) (Coverage.join (Coverage.join one2892 one2893) (Coverage.join one2894 one2895)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2896 one2897) (Coverage.join one2898 one2899)) (Coverage.join (Coverage.join one2900 one2901) (Coverage.join one2902 one2903))) (Coverage.join (Coverage.join (Coverage.join one2904 one2905) (Coverage.join one2906 one2907)) (Coverage.join (Coverage.join one2908 one2909) (Coverage.join one2910 one2911)))))
end NF181PA.Symbolic
