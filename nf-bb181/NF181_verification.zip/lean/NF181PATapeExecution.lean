import NF181PAGate
import ModelSourceFields

/-! Arithmetic semantics of individual transitions and finite paths. -/
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open NF210.TM PA192.LiteralTM PA192.PhysicalModel
open PA192.ModelSearch PA192.ModelSearch.RegisterFields
namespace NF181PA.Execute
open Gate (machine)
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
set_option maxHeartbeats 1600000
set_option maxRecDepth 8000

def bit (b : Bool) (r : V) : V := 2*r+(b.toNat : V)
instance bitDef (b : Bool) : Language.DefinableFunction₁ ℒₒᵣ (bit (V:=V) b) := by
  unfold bit
  definability
theorem halves (b : Bool) (r : V) : bit b r / 2 = r ∧ bit b r % 2 = (b.toNat : V) := by
  apply pair_digit _ _ _ _ rfl
  cases b <;> simp

/-- Work in the left-facing boundary convention: the low digit of l is
scanned and r starts just to the right of it. -/
noncomputable def face (q : Direct181.Table.State) (l r : V) := pack (q.val : V) (l/2) (2*r+l%2)
instance faceDef (q : Direct181.Table.State) : Language.DefinableFunction₂ ℒₒᵣ (face (V:=V) q) := by
  unfold face
  definability
theorem face_cons (q : Direct181.Table.State) (b : Bool) (l r : V) :
    face q (bit b l) r = pack (q.val:V) l (bit b r) := by
  unfold face
  rw [(halves b l).1,(halves b l).2]
  rfl

def Path (i o : V) := ∃ t : V, iterate (rawStep machine) t i = o
instance pathDef : Language.DefinableRel ℒₒᵣ (Path (V:=V)) := by unfold Path; definability
protected theorem Path.trans {a b c : V} : Path a b → Path b c → Path a c := by
  rintro ⟨n,hn⟩ ⟨m,hm⟩
  exact ⟨n+m,by rw [iterate_add,hn,hm]⟩
private theorem one_step {a b : V} (h : rawStep machine a = b) : Path a b := by
  refine ⟨1,?_⟩
  simpa using (iterate_succ (rawStep machine) (0:V) a).trans (by simpa using h)

private theorem stepAt (q : Direct181.Table.State) (b : Bool) (l r : V) :
    rawStep machine (pack (q.val:V) l (bit b r)) = action (machine q b) (pack (q.val:V) l (bit b r)) := by
  rw [rawStep,state_pack,pick_mem _ q (by simp),switch_bit machine q b _ (by rw [right_pack,(halves b r).2])]
theorem toRight {q q' : Direct181.Table.State} {b w : Bool}
    (row : machine q b = ⟨w,.right,some q'⟩) (l r : V) :
    Path (pack (q.val:V) l (bit b r)) (pack (q'.val:V) (bit w l) r) := by
  apply one_step
  rw [stepAt,row]
  simp only [action,PA192.LiteralTM.control,Option.elim_some,left_pack,right_pack,nextL,nextR,(halves b r).1]
  rfl
theorem toLeft {q q' : Direct181.Table.State} {b w : Bool}
    (row : machine q b = ⟨w,.left,some q'⟩) (l r : V) :
    Path (pack (q.val:V) l (bit b r)) (face q' l (bit w r)) := by
  apply one_step
  rw [stepAt,row]
  simp only [action,PA192.LiteralTM.control,Option.elim_some,left_pack,right_pack,nextL,nextR,(halves b r).1]
  rfl
theorem fromLeft {q q' : Direct181.Table.State} {b w : Bool}
    (row : machine q b = ⟨w,.left,some q'⟩) (l r : V) :
    Path (face q (bit b l) r) (face q' l (bit w r)) := by
  rw [face_cons]
  exact toLeft row l r

end NF181PA.Execute
