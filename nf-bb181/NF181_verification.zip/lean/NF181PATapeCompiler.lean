import NF181PATapeCompilerProof
import NF181PATapeLinks
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.ModelSearch.RegisterSource (address)
namespace NF181PA.Symbolic
set_option maxHeartbeats 2500000

private theorem tag_iff (p : Nat) (c : Bool) : Links.tag p c=true ↔ legal p c := by
  cases c <;> simp [Links.tag,legal]

theorem table_safe : LinksSafe := by
  intro p c legalAt
  have h := Links.release_links p c
  have htag := (tag_iff _ _).mpr legalAt
  cases e : Direct181Source.Raw.program p.val with
  | inl ins =>
    rcases ins with ⟨j,n⟩
    cases c <;> simp_all [e,Links.allowed,Links.atTarget,isDecReg,expectedHalt,nextPc,coldFor,isIncReg,tag_iff]
  | inr ins =>
    cases ins with
    | inl ins =>
      rcases ins with ⟨j,n,m,b⟩
      cases c <;> cases b <;> simp_all [e,Links.allowed,Links.atTarget,isDecReg,expectedHalt,nextPc,coldFor,isIncReg,tag_iff]
      all_goals intro z <;> cases z <;> simp_all [tag_iff]
    | inr n => cases c <;> simp_all [e,Links.allowed,Links.atTarget,isDecReg,expectedHalt,nextPc,coldFor,isIncReg,tag_iff]

theorem tape_of_coverage {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔] (cover : Coverage 0 2971)
    (source : ∃ j : V, address (Registers.run j)=4095) : V ⊧/![] H181 :=
  tape_of_links_and_coverage table_safe cover source

#print axioms table_safe
#print axioms tape_of_coverage
end NF181PA.Symbolic
