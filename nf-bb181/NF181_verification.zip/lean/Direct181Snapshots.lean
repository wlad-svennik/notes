module
public import MachineBits
public import Direct181Table
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Direct181.Boot
open NF210 NF192 Direct181.Table
abbrev width : Nat := 256
abbrev anchor : Int := -32
abbrev Prefix (n : Nat) (a b : KernelBits.Configuration 181) : Prop :=
  ∀ (left : Int) (outside : TM.Tape), TM.run machine n (KernelBits.embed width left outside a) = KernelBits.embed width left outside b
theorem checked (n : Nat) (a b : KernelBits.Configuration 181) (i : a.head < width)
    (h : KernelBits.run machine width n a=some b) : Prefix n a b :=
  fun l t => (KernelBits.run_sound machine width l t n a b i h).2
theorem compose {s t : Nat} {a b c : KernelBits.Configuration 181} (f : Prefix s a b) (g : Prefix t b c) :
    Prefix (s+t) a c := by intro l t; rw [TM.run_add,f l t,g l t]
def snap0 : KernelBits.Configuration 181 := ⟨some (146:State),32,0⟩
def snap500 : KernelBits.Configuration 181 := ⟨some (147:State),52,78178627883106304⟩
def snap1000 : KernelBits.Configuration 181 := ⟨some (136:State),38,3293747868472442880⟩
def snap1500 : KernelBits.Configuration 181 := ⟨some (107:State),38,43480986924127092736⟩
def snap2000 : KernelBits.Configuration 181 := ⟨some (127:State),24,12667641433508664049664⟩
def snap2500 : KernelBits.Configuration 181 := ⟨some (142:State),54,107386400506481202954240⟩
def snap3000 : KernelBits.Configuration 181 := ⟨some (145:State),46,819283147799629974732800⟩
def snap3500 : KernelBits.Configuration 181 := ⟨some (127:State),24,819283160185001396404224⟩
def snap4000 : KernelBits.Configuration 181 := ⟨some (26:State),36,6172085569078632615247872⟩
def snap4500 : KernelBits.Configuration 181 := ⟨some (119:State),42,6904004927377514952654848⟩
def snap5000 : KernelBits.Configuration 181 := ⟨some (125:State),70,51284805135636178900353024⟩
def snap5500 : KernelBits.Configuration 181 := ⟨some (31:State),40,52493636082426280568422400⟩
def snap6000 : KernelBits.Configuration 181 := ⟨some (133:State),42,415171381971313684805320704⟩
def snap6500 : KernelBits.Configuration 181 := ⟨some (142:State),68,3306921752752848322269544448⟩
def snap7000 : KernelBits.Configuration 181 := ⟨some (125:State),40,3306921373279550317101318144⟩
def snap7500 : KernelBits.Configuration 181 := ⟨some (125:State),56,26421581863719638870316285952⟩
def snap8000 : KernelBits.Configuration 181 := ⟨some (137:State),58,211300190027390654765403734016⟩
def snap8500 : KernelBits.Configuration 181 := ⟨some (134:State),50,211300188509426511259390443520⟩
def snap9000 : KernelBits.Configuration 181 := ⟨some (2:State),40,1690251679193250190671824814080⟩
def snap9500 : KernelBits.Configuration 181 := ⟨some (152:State),62,1690251679191953154357099233280⟩
def snap10000 : KernelBits.Configuration 181 := ⟨some (127:State),24,1690251679193178133726326947840⟩
def snap10500 : KernelBits.Configuration 181 := ⟨some (6:State),36,1690250977247224289743429697536⟩
def snap11000 : KernelBits.Configuration 181 := ⟨some (132:State),68,13521706757669490182255638740992⟩
def snap11500 : KernelBits.Configuration 181 := ⟨some (47:State),34,13521703946512226483999034310656⟩
def snap12000 : KernelBits.Configuration 181 := ⟨some (128:State),36,108173026976961166577158324224000⟩
def snap12500 : KernelBits.Configuration 181 := ⟨some (142:State),108,865383177515716487792082596921344⟩
def snap13000 : KernelBits.Configuration 181 := ⟨some (142:State),78,865383132628948609036030094344192⟩
def snap13500 : KernelBits.Configuration 181 := ⟨some (142:State),64,6923063123803518497728697630457856⟩
def snap14000 : KernelBits.Configuration 181 := ⟨some (142:State),48,6923062944267240633830256144285696⟩
def snap14500 : KernelBits.Configuration 181 := ⟨some (142:State),48,55384500756834689598156753336270848⟩
def snap15000 : KernelBits.Configuration 181 := ⟨some (152:State),46,55384500756834689598156873595355136⟩
def snap15500 : KernelBits.Configuration 181 := ⟨some (33:State),36,55384500756834687292314113489764352⟩
def snap16000 : KernelBits.Configuration 181 := ⟨some (125:State),54,55384500756834689598156968084635648⟩
def snap16439 : KernelBits.Configuration 181 := ⟨some (12:State),31,55384500756834687292313999673131008⟩
def snap16500 : KernelBits.Configuration 181 := ⟨some (125:State),48,55384500756834689598156991706955776⟩
def snap17000 : KernelBits.Configuration 181 := ⟨some (132:State),54,55384500756813102295904621435027456⟩
def snap17319 : KernelBits.Configuration 181 := ⟨some (12:State),31,55384500756769918468028239173386240⟩
def snap17500 : KernelBits.Configuration 181 := ⟨some (120:State),44,55384500756769632543486300582313984⟩
def snap18000 : KernelBits.Configuration 181 := ⟨some (121:State),52,55384500756769927686896951278698496⟩
def snap18500 : KernelBits.Configuration 181 := ⟨some (119:State),54,55384500756769918468029613562920960⟩
def snap19000 : KernelBits.Configuration 181 := ⟨some (130:State),36,55384500756769927691278505115385856⟩
def snap19500 : KernelBits.Configuration 181 := ⟨some (105:State),42,55384500756767566507087092246380544⟩
def snap20000 : KernelBits.Configuration 181 := ⟨some (152:State),60,55384500756769927689343364650500096⟩
def snap20500 : KernelBits.Configuration 181 := ⟨some (119:State),46,55384500756769918468038409655943168⟩
def snap21000 : KernelBits.Configuration 181 := ⟨some (134:State),64,55384500756683578482295858983337984⟩
def snap21500 : KernelBits.Configuration 181 := ⟨some (125:State),54,443076001177870760459676249353093120⟩
def snap22000 : KernelBits.Configuration 181 := ⟨some (5:State),46,3544607993925575941505198934219292672⟩
def snap22500 : KernelBits.Configuration 181 := ⟨some (149:State),30,3544607993925233256340436078762655744⟩
def snap23000 : KernelBits.Configuration 181 := ⟨some (150:State),26,28356863921846009760066792301380239360⟩
def snap23500 : KernelBits.Configuration 181 := ⟨some (134:State),46,226854911304161256601377011321481986048⟩
def snap24000 : KernelBits.Configuration 181 := ⟨some (127:State),24,226854911304161256638270446692342956032⟩
def snap24500 : KernelBits.Configuration 181 := ⟨some (105:State),42,226854911301287483462869716607858376704⟩
def snap25000 : KernelBits.Configuration 181 := ⟨some (134:State),52,1814839290286331551561448175138248851456⟩
def snap25500 : KernelBits.Configuration 181 := ⟨some (134:State),62,1814839290274839189646658238439409844224⟩
def snap26000 : KernelBits.Configuration 181 := ⟨some (64:State),32,14518714322019714671971640128022775857152⟩
def snap26500 : KernelBits.Configuration 181 := ⟨some (119:State),52,14518714322019714671971640000479427035136⟩
def snap27000 : KernelBits.Configuration 181 := ⟨some (125:State),64,14518714322019714650573416452763882094592⟩
def snap27500 : KernelBits.Configuration 181 := ⟨some (125:State),34,116149714575845639954691837928422290489344⟩
def snap28000 : KernelBits.Configuration 181 := ⟨some (55:State),48,116149714575845639911305095585582448377856⟩
def snap28500 : KernelBits.Configuration 181 := ⟨some (31:State),56,929197716605819217046499673572799798050816⟩
def snap29000 : KernelBits.Configuration 181 := ⟨some (150:State),42,929197716605819217046499529105768001306624⟩
def snap29500 : KernelBits.Configuration 181 := ⟨some (125:State),68,929197716605819217047089822805064381628416⟩
def snap30000 : KernelBits.Configuration 181 := ⟨some (101:State),44,929197716605819217047089823368014335049728⟩
def snap30500 : KernelBits.Configuration 181 := ⟨some (101:State),44,929197716605773252996781971417606859522048⟩
def snap31000 : KernelBits.Configuration 181 := ⟨some (134:State),70,7433581732844202611915202088096602370605056⟩
def snap31500 : KernelBits.Configuration 181 := ⟨some (134:State),64,7433581732844019076249336531809883584987136⟩
def snap32000 : KernelBits.Configuration 181 := ⟨some (149:State),24,59468653862749284435917166726574680651595776⟩
def snap32500 : KernelBits.Configuration 181 := ⟨some (121:State),64,59468653862749284435919509433798644186742784⟩
def snap33000 : KernelBits.Configuration 181 := ⟨some (142:State),54,59468653862749284435574795114345384867004416⟩
def snap33500 : KernelBits.Configuration 181 := ⟨some (120:State),142,57610258429539356514077199277822644049674240⟩
def snap34000 : KernelBits.Configuration 181 := ⟨some (149:State),26,475749230901986005116671460433428228694081536⟩
def snap34500 : KernelBits.Configuration 181 := ⟨some (125:State),68,3805993847215898309955473120898508763844050944⟩
def snap35000 : KernelBits.Configuration 181 := ⟨some (125:State),32,3805993847215898309955473120899071713797472256⟩
def snap35500 : KernelBits.Configuration 181 := ⟨some (125:State),70,3805993847215896842952315772705190840310431744⟩
def snap36000 : KernelBits.Configuration 181 := ⟨some (31:State),58,30447950777727151785401499281062422885974409216⟩
def snap36500 : KernelBits.Configuration 181 := ⟨some (121:State),68,30447950777727151785401508430068770893794902016⟩
def snap37000 : KernelBits.Configuration 181 := ⟨some (152:State),70,30447950777727151785401508725203728224219037696⟩
def snap37500 : KernelBits.Configuration 181 := ⟨some (120:State),88,30447950777727141644108285309343827963565572096⟩
def snap38000 : KernelBits.Configuration 181 := ⟨some (120:State),56,30447950777727151780449748568066992199226621952⟩
def snap38500 : KernelBits.Configuration 181 := ⟨some (120:State),78,30447950777727151782837207056608560862369677312⟩
def snap39000 : KernelBits.Configuration 181 := ⟨some (172:State),38,243583606221817168341135055981699626337772240896⟩
def snap39500 : KernelBits.Configuration 181 := ⟨some (125:State),34,243583606221817168330877887086246879197862559744⟩
def snap40000 : KernelBits.Configuration 181 := ⟨some (125:State),32,1948668849774537254865440644667713209158583975936⟩
def snap40500 : KernelBits.Configuration 181 := ⟨some (121:State),74,1948668849774537254824412063533233003891756367872⟩
def snap41000 : KernelBits.Configuration 181 := ⟨some (142:State),156,15589350798196297855278302977691379411267757277184⟩
def snap41500 : KernelBits.Configuration 181 := ⟨some (118:State),98,15589350798196297855278302977691385603717244911616⟩
def snap42000 : KernelBits.Configuration 181 := ⟨some (172:State),38,15589350798196297855278302977691387116645244731392⟩
def snap42500 : KernelBits.Configuration 181 := ⟨some (130:State),36,15589350798196297855278302977691387187013988909056⟩
def snap43000 : KernelBits.Configuration 181 := ⟨some (149:State),30,15589350798196297855278302902133523654613711978496⟩
def snap43500 : KernelBits.Configuration 181 := ⟨some (134:State),52,15589350798196297855278302675459935995307950604288⟩
def snap44000 : KernelBits.Configuration 181 := ⟨some (142:State),52,124714806385570382475756549347089208772487534346240⟩
def snap44500 : KernelBits.Configuration 181 := ⟨some (120:State),80,124714806385570382313497272215644377529403301691392⟩
def snap45000 : KernelBits.Configuration 181 := ⟨some (149:State),26,124714806385570382475439636697032148607363591438336⟩
def snap45500 : KernelBits.Configuration 181 := ⟨some (125:State),84,124714806385570382313333158117780055767378309414912⟩
def snap46000 : KernelBits.Configuration 181 := ⟨some (125:State),48,997718451084563059165605877159572854947812107878400⟩
def snap46500 : KernelBits.Configuration 181 := ⟨some (31:State),68,997718451084563059165605877160163149350795929976832⟩
def snap47000 : KernelBits.Configuration 181 := ⟨some (121:State),68,997718451084563059165605876857046250450125601112064⟩
def snap47500 : KernelBits.Configuration 181 := ⟨some (120:State),106,997718451084563059152929370855059099836738294513664⟩
def snap48000 : KernelBits.Configuration 181 := ⟨some (145:State),60,7981747608676504471293833057925232506506990621556736⟩
def snap48500 : KernelBits.Configuration 181 := ⟨some (144:State),80,7981747608676504471105892538477874274302495050170368⟩
def snap49000 : KernelBits.Configuration 181 := ⟨some (142:State),72,7981747608676504471105892537268948453139753503555584⟩
def snap49500 : KernelBits.Configuration 181 := ⟨some (26:State),48,7981747608676504471104624886668720222753094381862912⟩
def snap50000 : KernelBits.Configuration 181 := ⟨some (125:State),58,63853980869412035765910786134212219471810996960493568⟩
def snap50500 : KernelBits.Configuration 181 := ⟨some (125:State),50,63853980869412035765910786131794367838211238145294336⟩
def snap51000 : KernelBits.Configuration 181 := ⟨some (119:State),76,63853980869412035765910129668149355622216364059525120⟩
def snap51111 : KernelBits.Configuration 181 := ⟨some (12:State),31,63853980869412035765910129668149355622216364059525120⟩
end Direct181.Boot
