import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w1696_0 : checkWitness 1696 false false 508 = true := by decide +kernel
private theorem w1696_1 : checkWitness 1696 false true 4604 = true := by decide +kernel
private theorem w1696_2 : checkWitness 1696 true false 508 = true := by decide +kernel
private theorem w1696_3 : checkWitness 1696 true true 4604 = true := by decide +kernel
private theorem cases1696 : checkFour 1696 (508,4604,508,4604) = true := by
  simp only [checkFour, w1696_0, w1696_1, w1696_2, w1696_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1696 : Coverage 1696 1697 := checkList_sound (ws:=[(508,4604,508,4604)]) (by simpa only [checkList, Bool.and_true] using cases1696)
private theorem w1697_0 : checkWitness 1697 false false 8866 = true := by decide +kernel
private theorem w1697_2 : checkWitness 1697 true false 8862 = true := by decide +kernel
private theorem cases1697 : checkFour 1697 (8866,0,8862,0) = true := by
  simp only [checkFour, w1697_0, w1697_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1697 : Coverage 1697 1698 := checkList_sound (ws:=[(8866,0,8862,0)]) (by simpa only [checkList, Bool.and_true] using cases1697)
private theorem w1698_0 : checkWitness 1698 false false 90 = true := by decide +kernel
private theorem w1698_2 : checkWitness 1698 true false 90 = true := by decide +kernel
private theorem cases1698 : checkFour 1698 (90,0,90,0) = true := by
  simp only [checkFour, w1698_0, w1698_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1698 : Coverage 1698 1699 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1698)
private theorem w1699_0 : checkWitness 1699 false false 546 = true := by decide +kernel
private theorem w1699_1 : checkWitness 1699 false true 4642 = true := by decide +kernel
private theorem w1699_2 : checkWitness 1699 true false 546 = true := by decide +kernel
private theorem w1699_3 : checkWitness 1699 true true 4642 = true := by decide +kernel
private theorem cases1699 : checkFour 1699 (546,4642,546,4642) = true := by
  simp only [checkFour, w1699_0, w1699_1, w1699_2, w1699_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1699 : Coverage 1699 1700 := checkList_sound (ws:=[(546,4642,546,4642)]) (by simpa only [checkList, Bool.and_true] using cases1699)
private theorem w1700_0 : checkWitness 1700 false false 8887 = true := by decide +kernel
private theorem w1700_2 : checkWitness 1700 true false 8883 = true := by decide +kernel
private theorem cases1700 : checkFour 1700 (8887,0,8883,0) = true := by
  simp only [checkFour, w1700_0, w1700_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1700 : Coverage 1700 1701 := checkList_sound (ws:=[(8887,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1700)
private theorem w1701_0 : checkWitness 1701 false false 8922 = true := by decide +kernel
private theorem w1701_2 : checkWitness 1701 true false 8913 = true := by decide +kernel
private theorem cases1701 : checkFour 1701 (8922,0,8913,0) = true := by
  simp only [checkFour, w1701_0, w1701_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1701 : Coverage 1701 1702 := checkList_sound (ws:=[(8922,0,8913,0)]) (by simpa only [checkList, Bool.and_true] using cases1701)
private theorem w1702_0 : checkWitness 1702 false false 114 = true := by decide +kernel
private theorem w1702_2 : checkWitness 1702 true false 114 = true := by decide +kernel
private theorem cases1702 : checkFour 1702 (114,0,114,0) = true := by
  simp only [checkFour, w1702_0, w1702_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1702 : Coverage 1702 1703 := checkList_sound (ws:=[(114,0,114,0)]) (by simpa only [checkList, Bool.and_true] using cases1702)
private theorem w1703_0 : checkWitness 1703 false false 634 = true := by decide +kernel
private theorem w1703_1 : checkWitness 1703 false true 4726 = true := by decide +kernel
private theorem w1703_2 : checkWitness 1703 true false 625 = true := by decide +kernel
private theorem w1703_3 : checkWitness 1703 true true 4717 = true := by decide +kernel
private theorem cases1703 : checkFour 1703 (634,4726,625,4717) = true := by
  simp only [checkFour, w1703_0, w1703_1, w1703_2, w1703_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1703 : Coverage 1703 1704 := checkList_sound (ws:=[(634,4726,625,4717)]) (by simpa only [checkList, Bool.and_true] using cases1703)
private theorem w1704_0 : checkWitness 1704 false false 8883 = true := by decide +kernel
private theorem w1704_2 : checkWitness 1704 true false 8879 = true := by decide +kernel
private theorem cases1704 : checkFour 1704 (8883,0,8879,0) = true := by
  simp only [checkFour, w1704_0, w1704_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1704 : Coverage 1704 1705 := checkList_sound (ws:=[(8883,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1704)
private theorem w1705_0 : checkWitness 1705 false false 628 = true := by decide +kernel
private theorem w1705_1 : checkWitness 1705 false true 4720 = true := by decide +kernel
private theorem w1705_2 : checkWitness 1705 true false 619 = true := by decide +kernel
private theorem w1705_3 : checkWitness 1705 true true 4711 = true := by decide +kernel
private theorem cases1705 : checkFour 1705 (628,4720,619,4711) = true := by
  simp only [checkFour, w1705_0, w1705_1, w1705_2, w1705_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1705 : Coverage 1705 1706 := checkList_sound (ws:=[(628,4720,619,4711)]) (by simpa only [checkList, Bool.and_true] using cases1705)
private theorem w1706_0 : checkWitness 1706 false false 8852 = true := by decide +kernel
private theorem w1706_2 : checkWitness 1706 true false 8848 = true := by decide +kernel
private theorem cases1706 : checkFour 1706 (8852,0,8848,0) = true := by
  simp only [checkFour, w1706_0, w1706_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1706 : Coverage 1706 1707 := checkList_sound (ws:=[(8852,0,8848,0)]) (by simpa only [checkList, Bool.and_true] using cases1706)
private theorem w1707_0 : checkWitness 1707 false false 102 = true := by decide +kernel
private theorem w1707_2 : checkWitness 1707 true false 102 = true := by decide +kernel
private theorem cases1707 : checkFour 1707 (102,0,102,0) = true := by
  simp only [checkFour, w1707_0, w1707_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1707 : Coverage 1707 1708 := checkList_sound (ws:=[(102,0,102,0)]) (by simpa only [checkList, Bool.and_true] using cases1707)
private theorem w1708_0 : checkWitness 1708 false false 94 = true := by decide +kernel
private theorem w1708_2 : checkWitness 1708 true false 94 = true := by decide +kernel
private theorem cases1708 : checkFour 1708 (94,0,94,0) = true := by
  simp only [checkFour, w1708_0, w1708_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1708 : Coverage 1708 1709 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1708)
private theorem w1709_0 : checkWitness 1709 false false 593 = true := by decide +kernel
private theorem w1709_1 : checkWitness 1709 false true 4677 = true := by decide +kernel
private theorem w1709_2 : checkWitness 1709 true false 593 = true := by decide +kernel
private theorem w1709_3 : checkWitness 1709 true true 4677 = true := by decide +kernel
private theorem cases1709 : checkFour 1709 (593,4677,593,4677) = true := by
  simp only [checkFour, w1709_0, w1709_1, w1709_2, w1709_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1709 : Coverage 1709 1710 := checkList_sound (ws:=[(593,4677,593,4677)]) (by simpa only [checkList, Bool.and_true] using cases1709)
private theorem w1710_0 : checkWitness 1710 false false 8846 = true := by decide +kernel
private theorem w1710_2 : checkWitness 1710 true false 8842 = true := by decide +kernel
private theorem cases1710 : checkFour 1710 (8846,0,8842,0) = true := by
  simp only [checkFour, w1710_0, w1710_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1710 : Coverage 1710 1711 := checkList_sound (ws:=[(8846,0,8842,0)]) (by simpa only [checkList, Bool.and_true] using cases1710)
private theorem w1711_0 : checkWitness 1711 false false 94 = true := by decide +kernel
private theorem w1711_2 : checkWitness 1711 true false 94 = true := by decide +kernel
private theorem cases1711 : checkFour 1711 (94,0,94,0) = true := by
  simp only [checkFour, w1711_0, w1711_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1711 : Coverage 1711 1712 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases1711)
private theorem w1712_0 : checkWitness 1712 false false 591 = true := by decide +kernel
private theorem w1712_1 : checkWitness 1712 false true 4683 = true := by decide +kernel
private theorem w1712_2 : checkWitness 1712 true false 582 = true := by decide +kernel
private theorem w1712_3 : checkWitness 1712 true true 4674 = true := by decide +kernel
private theorem cases1712 : checkFour 1712 (591,4683,582,4674) = true := by
  simp only [checkFour, w1712_0, w1712_1, w1712_2, w1712_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1712 : Coverage 1712 1713 := checkList_sound (ws:=[(591,4683,582,4674)]) (by simpa only [checkList, Bool.and_true] using cases1712)
private theorem w1713_0 : checkWitness 1713 false false 8888 = true := by decide +kernel
private theorem w1713_2 : checkWitness 1713 true false 8879 = true := by decide +kernel
private theorem cases1713 : checkFour 1713 (8888,0,8879,0) = true := by
  simp only [checkFour, w1713_0, w1713_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1713 : Coverage 1713 1714 := checkList_sound (ws:=[(8888,0,8879,0)]) (by simpa only [checkList, Bool.and_true] using cases1713)
private theorem w1714_0 : checkWitness 1714 false false 8834 = true := by decide +kernel
private theorem w1714_2 : checkWitness 1714 true false 8830 = true := by decide +kernel
private theorem cases1714 : checkFour 1714 (8834,0,8830,0) = true := by
  simp only [checkFour, w1714_0, w1714_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1714 : Coverage 1714 1715 := checkList_sound (ws:=[(8834,0,8830,0)]) (by simpa only [checkList, Bool.and_true] using cases1714)
private theorem w1715_0 : checkWitness 1715 false false 88 = true := by decide +kernel
private theorem w1715_2 : checkWitness 1715 true false 88 = true := by decide +kernel
private theorem cases1715 : checkFour 1715 (88,0,88,0) = true := by
  simp only [checkFour, w1715_0, w1715_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1715 : Coverage 1715 1716 := checkList_sound (ws:=[(88,0,88,0)]) (by simpa only [checkList, Bool.and_true] using cases1715)
private theorem w1716_0 : checkWitness 1716 false false 618 = true := by decide +kernel
private theorem w1716_1 : checkWitness 1716 false true 4710 = true := by decide +kernel
private theorem w1716_2 : checkWitness 1716 true false 609 = true := by decide +kernel
private theorem w1716_3 : checkWitness 1716 true true 4701 = true := by decide +kernel
private theorem cases1716 : checkFour 1716 (618,4710,609,4701) = true := by
  simp only [checkFour, w1716_0, w1716_1, w1716_2, w1716_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1716 : Coverage 1716 1717 := checkList_sound (ws:=[(618,4710,609,4701)]) (by simpa only [checkList, Bool.and_true] using cases1716)
private theorem w1717_0 : checkWitness 1717 false false 8895 = true := by decide +kernel
private theorem w1717_2 : checkWitness 1717 true false 8886 = true := by decide +kernel
private theorem cases1717 : checkFour 1717 (8895,0,8886,0) = true := by
  simp only [checkFour, w1717_0, w1717_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1717 : Coverage 1717 1718 := checkList_sound (ws:=[(8895,0,8886,0)]) (by simpa only [checkList, Bool.and_true] using cases1717)
private theorem w1718_0 : checkWitness 1718 false false 72 = true := by decide +kernel
private theorem w1718_2 : checkWitness 1718 true false 72 = true := by decide +kernel
private theorem cases1718 : checkFour 1718 (72,0,72,0) = true := by
  simp only [checkFour, w1718_0, w1718_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1718 : Coverage 1718 1719 := checkList_sound (ws:=[(72,0,72,0)]) (by simpa only [checkList, Bool.and_true] using cases1718)
private theorem w1719_0 : checkWitness 1719 false false 482 = true := by decide +kernel
private theorem w1719_1 : checkWitness 1719 false true 4578 = true := by decide +kernel
private theorem w1719_2 : checkWitness 1719 true false 482 = true := by decide +kernel
private theorem w1719_3 : checkWitness 1719 true true 4578 = true := by decide +kernel
private theorem cases1719 : checkFour 1719 (482,4578,482,4578) = true := by
  simp only [checkFour, w1719_0, w1719_1, w1719_2, w1719_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1719 : Coverage 1719 1720 := checkList_sound (ws:=[(482,4578,482,4578)]) (by simpa only [checkList, Bool.and_true] using cases1719)
private theorem w1720_0 : checkWitness 1720 false false 8877 = true := by decide +kernel
private theorem w1720_2 : checkWitness 1720 true false 8873 = true := by decide +kernel
private theorem cases1720 : checkFour 1720 (8877,0,8873,0) = true := by
  simp only [checkFour, w1720_0, w1720_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1720 : Coverage 1720 1721 := checkList_sound (ws:=[(8877,0,8873,0)]) (by simpa only [checkList, Bool.and_true] using cases1720)
private theorem w1721_0 : checkWitness 1721 false false 608 = true := by decide +kernel
private theorem w1721_1 : checkWitness 1721 false true 4704 = true := by decide +kernel
private theorem w1721_2 : checkWitness 1721 true false 599 = true := by decide +kernel
private theorem w1721_3 : checkWitness 1721 true true 4695 = true := by decide +kernel
private theorem cases1721 : checkFour 1721 (608,4704,599,4695) = true := by
  simp only [checkFour, w1721_0, w1721_1, w1721_2, w1721_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1721 : Coverage 1721 1722 := checkList_sound (ws:=[(608,4704,599,4695)]) (by simpa only [checkList, Bool.and_true] using cases1721)
private theorem w1722_0 : checkWitness 1722 false false 170 = true := by decide +kernel
private theorem w1722_2 : checkWitness 1722 true false 170 = true := by decide +kernel
private theorem cases1722 : checkFour 1722 (170,0,170,0) = true := by
  simp only [checkFour, w1722_0, w1722_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1722 : Coverage 1722 1723 := checkList_sound (ws:=[(170,0,170,0)]) (by simpa only [checkList, Bool.and_true] using cases1722)
private theorem w1723_0 : checkWitness 1723 false false 563 = true := by decide +kernel
private theorem w1723_1 : checkWitness 1723 false true 4651 = true := by decide +kernel
private theorem w1723_2 : checkWitness 1723 true false 563 = true := by decide +kernel
private theorem w1723_3 : checkWitness 1723 true true 4651 = true := by decide +kernel
private theorem cases1723 : checkFour 1723 (563,4651,563,4651) = true := by
  simp only [checkFour, w1723_0, w1723_1, w1723_2, w1723_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1723 : Coverage 1723 1724 := checkList_sound (ws:=[(563,4651,563,4651)]) (by simpa only [checkList, Bool.and_true] using cases1723)
private theorem w1724_0 : checkWitness 1724 false false 8892 = true := by decide +kernel
private theorem w1724_2 : checkWitness 1724 true false 8883 = true := by decide +kernel
private theorem cases1724 : checkFour 1724 (8892,0,8883,0) = true := by
  simp only [checkFour, w1724_0, w1724_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1724 : Coverage 1724 1725 := checkList_sound (ws:=[(8892,0,8883,0)]) (by simpa only [checkList, Bool.and_true] using cases1724)
private theorem w1725_0 : checkWitness 1725 false false 90 = true := by decide +kernel
private theorem w1725_2 : checkWitness 1725 true false 90 = true := by decide +kernel
private theorem cases1725 : checkFour 1725 (90,0,90,0) = true := by
  simp only [checkFour, w1725_0, w1725_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1725 : Coverage 1725 1726 := checkList_sound (ws:=[(90,0,90,0)]) (by simpa only [checkList, Bool.and_true] using cases1725)
private theorem w1726_0 : checkWitness 1726 false false 82 = true := by decide +kernel
private theorem w1726_2 : checkWitness 1726 true false 82 = true := by decide +kernel
private theorem cases1726 : checkFour 1726 (82,0,82,0) = true := by
  simp only [checkFour, w1726_0, w1726_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1726 : Coverage 1726 1727 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases1726)
private theorem w1727_0 : checkWitness 1727 false false 569 = true := by decide +kernel
private theorem w1727_1 : checkWitness 1727 false true 4661 = true := by decide +kernel
private theorem w1727_2 : checkWitness 1727 true false 569 = true := by decide +kernel
private theorem w1727_3 : checkWitness 1727 true true 4661 = true := by decide +kernel
private theorem cases1727 : checkFour 1727 (569,4661,569,4661) = true := by
  simp only [checkFour, w1727_0, w1727_1, w1727_2, w1727_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one1727 : Coverage 1727 1728 := checkList_sound (ws:=[(569,4661,569,4661)]) (by simpa only [checkList, Bool.and_true] using cases1727)
theorem cover1696 : Coverage 1696 1728 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1696 one1697) (Coverage.join one1698 one1699)) (Coverage.join (Coverage.join one1700 one1701) (Coverage.join one1702 one1703))) (Coverage.join (Coverage.join (Coverage.join one1704 one1705) (Coverage.join one1706 one1707)) (Coverage.join (Coverage.join one1708 one1709) (Coverage.join one1710 one1711)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one1712 one1713) (Coverage.join one1714 one1715)) (Coverage.join (Coverage.join one1716 one1717) (Coverage.join one1718 one1719))) (Coverage.join (Coverage.join (Coverage.join one1720 one1721) (Coverage.join one1722 one1723)) (Coverage.join (Coverage.join one1724 one1725) (Coverage.join one1726 one1727)))))
end NF181PA.Symbolic
