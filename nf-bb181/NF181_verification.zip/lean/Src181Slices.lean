module
public import NF181Raw
@[expose] public section
namespace PA192.ModelSearch.Register181.Slices
open NF192.Emitter Direct181Source.Literal
set_option maxHeartbeats 1000000
set_option maxRecDepth 7000
private def Slice (full part : List Instruction) (i : Nat) : Prop :=
  ∀ n, n<part.length → full[i+n]? = part[n]?

private theorem splitL {full a b : List Instruction} {i : Nat} (h : Slice full (a++b) i) : Slice full a i := by
  intro n lower
  exact (h n (by simp; omega)).trans (List.getElem?_append_left lower)

private theorem splitR {full a b : List Instruction} {i j : Nat} (eq : j=i+a.length)
    (h : Slice full (a++b) i) : Slice full b j := by
  intro n lower
  subst j
  have inside : a.length+n < (a++b).length := by simp [lower]
  rw [Nat.add_assoc]
  rw [h (a.length+n) inside,List.getElem?_append_right (by omega)]
  simp

private def empty_pre : List Instruction := []
private def remaining_pre0 := pre0 ++ empty_pre
private theorem begin_pre : Slice pre remaining_pre0 0 := fun j _ => by simp only [Nat.zero_add]; rfl
private theorem at_pre0 : Slice pre pre0 0 := splitL (b:=empty_pre) begin_pre
theorem literal_pre0 (j : Nat) (i : Instruction) (bound : j<40) (row : pre0[j]?=some i) : Direct181Source.Literal.program (0+j) = i := by
  have nlen : pre0.length=40 := rfl
  have atj := at_pre0 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show 0+j=0+j by omega,atj]
  rfl
private def empty_mid : List Instruction := []
private def remaining_mid58 := mid58 ++ empty_mid
private def remaining_mid57 := mid57 ++ remaining_mid58
private def remaining_mid56 := mid56 ++ remaining_mid57
private def remaining_mid55 := mid55 ++ remaining_mid56
private def remaining_mid54 := mid54 ++ remaining_mid55
private def remaining_mid53 := mid53 ++ remaining_mid54
private def remaining_mid52 := mid52 ++ remaining_mid53
private def remaining_mid51 := mid51 ++ remaining_mid52
private def remaining_mid50 := mid50 ++ remaining_mid51
private def remaining_mid49 := mid49 ++ remaining_mid50
private def remaining_mid48 := mid48 ++ remaining_mid49
private def remaining_mid47 := mid47 ++ remaining_mid48
private def remaining_mid46 := mid46 ++ remaining_mid47
private def remaining_mid45 := mid45 ++ remaining_mid46
private def remaining_mid44 := mid44 ++ remaining_mid45
private def remaining_mid43 := mid43 ++ remaining_mid44
private def remaining_mid42 := mid42 ++ remaining_mid43
private def remaining_mid41 := mid41 ++ remaining_mid42
private def remaining_mid40 := mid40 ++ remaining_mid41
private def remaining_mid39 := mid39 ++ remaining_mid40
private def remaining_mid38 := mid38 ++ remaining_mid39
private def remaining_mid37 := mid37 ++ remaining_mid38
private def remaining_mid36 := mid36 ++ remaining_mid37
private def remaining_mid35 := mid35 ++ remaining_mid36
private def remaining_mid34 := mid34 ++ remaining_mid35
private def remaining_mid33 := mid33 ++ remaining_mid34
private def remaining_mid32 := mid32 ++ remaining_mid33
private def remaining_mid31 := mid31 ++ remaining_mid32
private def remaining_mid30 := mid30 ++ remaining_mid31
private def remaining_mid29 := mid29 ++ remaining_mid30
private def remaining_mid28 := mid28 ++ remaining_mid29
private def remaining_mid27 := mid27 ++ remaining_mid28
private def remaining_mid26 := mid26 ++ remaining_mid27
private def remaining_mid25 := mid25 ++ remaining_mid26
private def remaining_mid24 := mid24 ++ remaining_mid25
private def remaining_mid23 := mid23 ++ remaining_mid24
private def remaining_mid22 := mid22 ++ remaining_mid23
private def remaining_mid21 := mid21 ++ remaining_mid22
private def remaining_mid20 := mid20 ++ remaining_mid21
private def remaining_mid19 := mid19 ++ remaining_mid20
private def remaining_mid18 := mid18 ++ remaining_mid19
private def remaining_mid17 := mid17 ++ remaining_mid18
private def remaining_mid16 := mid16 ++ remaining_mid17
private def remaining_mid15 := mid15 ++ remaining_mid16
private def remaining_mid14 := mid14 ++ remaining_mid15
private def remaining_mid13 := mid13 ++ remaining_mid14
private def remaining_mid12 := mid12 ++ remaining_mid13
private def remaining_mid11 := mid11 ++ remaining_mid12
private def remaining_mid10 := mid10 ++ remaining_mid11
private def remaining_mid9 := mid9 ++ remaining_mid10
private def remaining_mid8 := mid8 ++ remaining_mid9
private def remaining_mid7 := mid7 ++ remaining_mid8
private def remaining_mid6 := mid6 ++ remaining_mid7
private def remaining_mid5 := mid5 ++ remaining_mid6
private def remaining_mid4 := mid4 ++ remaining_mid5
private def remaining_mid3 := mid3 ++ remaining_mid4
private def remaining_mid2 := mid2 ++ remaining_mid3
private def remaining_mid1 := mid1 ++ remaining_mid2
private def remaining_mid0 := mid0 ++ remaining_mid1
private theorem begin_mid : Slice mid remaining_mid0 0 := fun j _ => by simp only [Nat.zero_add]; rfl
private theorem at_mid0 : Slice mid mid0 0 := splitL (b:=remaining_mid1) begin_mid
theorem literal_mid0 (j : Nat) (i : Instruction) (bound : j<48) (row : mid0[j]?=some i) : Direct181Source.Literal.program (40+j) = i := by
  have nlen : mid0.length=48 := rfl
  have atj := at_mid0 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (40+j)-40=0+j by omega,atj]
  rfl
private theorem next_mid0 : Slice mid remaining_mid1 48 := splitR (a:=mid0) (by rfl) begin_mid
private theorem at_mid1 : Slice mid mid1 48 := splitL (b:=remaining_mid2) next_mid0
theorem literal_mid1 (j : Nat) (i : Instruction) (bound : j<48) (row : mid1[j]?=some i) : Direct181Source.Literal.program (88+j) = i := by
  have nlen : mid1.length=48 := rfl
  have atj := at_mid1 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (88+j)-40=48+j by omega,atj]
  rfl
private theorem next_mid1 : Slice mid remaining_mid2 96 := splitR (a:=mid1) (by rfl) next_mid0
private theorem at_mid2 : Slice mid mid2 96 := splitL (b:=remaining_mid3) next_mid1
theorem literal_mid2 (j : Nat) (i : Instruction) (bound : j<48) (row : mid2[j]?=some i) : Direct181Source.Literal.program (136+j) = i := by
  have nlen : mid2.length=48 := rfl
  have atj := at_mid2 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (136+j)-40=96+j by omega,atj]
  rfl
private theorem next_mid2 : Slice mid remaining_mid3 144 := splitR (a:=mid2) (by rfl) next_mid1
private theorem at_mid3 : Slice mid mid3 144 := splitL (b:=remaining_mid4) next_mid2
theorem literal_mid3 (j : Nat) (i : Instruction) (bound : j<48) (row : mid3[j]?=some i) : Direct181Source.Literal.program (184+j) = i := by
  have nlen : mid3.length=48 := rfl
  have atj := at_mid3 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (184+j)-40=144+j by omega,atj]
  rfl
private theorem next_mid3 : Slice mid remaining_mid4 192 := splitR (a:=mid3) (by rfl) next_mid2
private theorem at_mid4 : Slice mid mid4 192 := splitL (b:=remaining_mid5) next_mid3
theorem literal_mid4 (j : Nat) (i : Instruction) (bound : j<48) (row : mid4[j]?=some i) : Direct181Source.Literal.program (232+j) = i := by
  have nlen : mid4.length=48 := rfl
  have atj := at_mid4 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (232+j)-40=192+j by omega,atj]
  rfl
private theorem next_mid4 : Slice mid remaining_mid5 240 := splitR (a:=mid4) (by rfl) next_mid3
private theorem at_mid5 : Slice mid mid5 240 := splitL (b:=remaining_mid6) next_mid4
theorem literal_mid5 (j : Nat) (i : Instruction) (bound : j<48) (row : mid5[j]?=some i) : Direct181Source.Literal.program (280+j) = i := by
  have nlen : mid5.length=48 := rfl
  have atj := at_mid5 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (280+j)-40=240+j by omega,atj]
  rfl
private theorem next_mid5 : Slice mid remaining_mid6 288 := splitR (a:=mid5) (by rfl) next_mid4
private theorem at_mid6 : Slice mid mid6 288 := splitL (b:=remaining_mid7) next_mid5
theorem literal_mid6 (j : Nat) (i : Instruction) (bound : j<48) (row : mid6[j]?=some i) : Direct181Source.Literal.program (328+j) = i := by
  have nlen : mid6.length=48 := rfl
  have atj := at_mid6 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (328+j)-40=288+j by omega,atj]
  rfl
private theorem next_mid6 : Slice mid remaining_mid7 336 := splitR (a:=mid6) (by rfl) next_mid5
private theorem at_mid7 : Slice mid mid7 336 := splitL (b:=remaining_mid8) next_mid6
theorem literal_mid7 (j : Nat) (i : Instruction) (bound : j<48) (row : mid7[j]?=some i) : Direct181Source.Literal.program (376+j) = i := by
  have nlen : mid7.length=48 := rfl
  have atj := at_mid7 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (376+j)-40=336+j by omega,atj]
  rfl
private theorem next_mid7 : Slice mid remaining_mid8 384 := splitR (a:=mid7) (by rfl) next_mid6
private theorem at_mid8 : Slice mid mid8 384 := splitL (b:=remaining_mid9) next_mid7
theorem literal_mid8 (j : Nat) (i : Instruction) (bound : j<48) (row : mid8[j]?=some i) : Direct181Source.Literal.program (424+j) = i := by
  have nlen : mid8.length=48 := rfl
  have atj := at_mid8 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (424+j)-40=384+j by omega,atj]
  rfl
private theorem next_mid8 : Slice mid remaining_mid9 432 := splitR (a:=mid8) (by rfl) next_mid7
private theorem at_mid9 : Slice mid mid9 432 := splitL (b:=remaining_mid10) next_mid8
theorem literal_mid9 (j : Nat) (i : Instruction) (bound : j<48) (row : mid9[j]?=some i) : Direct181Source.Literal.program (472+j) = i := by
  have nlen : mid9.length=48 := rfl
  have atj := at_mid9 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (472+j)-40=432+j by omega,atj]
  rfl
private theorem next_mid9 : Slice mid remaining_mid10 480 := splitR (a:=mid9) (by rfl) next_mid8
private theorem at_mid10 : Slice mid mid10 480 := splitL (b:=remaining_mid11) next_mid9
theorem literal_mid10 (j : Nat) (i : Instruction) (bound : j<48) (row : mid10[j]?=some i) : Direct181Source.Literal.program (520+j) = i := by
  have nlen : mid10.length=48 := rfl
  have atj := at_mid10 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (520+j)-40=480+j by omega,atj]
  rfl
private theorem next_mid10 : Slice mid remaining_mid11 528 := splitR (a:=mid10) (by rfl) next_mid9
private theorem at_mid11 : Slice mid mid11 528 := splitL (b:=remaining_mid12) next_mid10
theorem literal_mid11 (j : Nat) (i : Instruction) (bound : j<48) (row : mid11[j]?=some i) : Direct181Source.Literal.program (568+j) = i := by
  have nlen : mid11.length=48 := rfl
  have atj := at_mid11 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (568+j)-40=528+j by omega,atj]
  rfl
private theorem next_mid11 : Slice mid remaining_mid12 576 := splitR (a:=mid11) (by rfl) next_mid10
private theorem at_mid12 : Slice mid mid12 576 := splitL (b:=remaining_mid13) next_mid11
theorem literal_mid12 (j : Nat) (i : Instruction) (bound : j<48) (row : mid12[j]?=some i) : Direct181Source.Literal.program (616+j) = i := by
  have nlen : mid12.length=48 := rfl
  have atj := at_mid12 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (616+j)-40=576+j by omega,atj]
  rfl
private theorem next_mid12 : Slice mid remaining_mid13 624 := splitR (a:=mid12) (by rfl) next_mid11
private theorem at_mid13 : Slice mid mid13 624 := splitL (b:=remaining_mid14) next_mid12
theorem literal_mid13 (j : Nat) (i : Instruction) (bound : j<48) (row : mid13[j]?=some i) : Direct181Source.Literal.program (664+j) = i := by
  have nlen : mid13.length=48 := rfl
  have atj := at_mid13 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (664+j)-40=624+j by omega,atj]
  rfl
private theorem next_mid13 : Slice mid remaining_mid14 672 := splitR (a:=mid13) (by rfl) next_mid12
private theorem at_mid14 : Slice mid mid14 672 := splitL (b:=remaining_mid15) next_mid13
theorem literal_mid14 (j : Nat) (i : Instruction) (bound : j<48) (row : mid14[j]?=some i) : Direct181Source.Literal.program (712+j) = i := by
  have nlen : mid14.length=48 := rfl
  have atj := at_mid14 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (712+j)-40=672+j by omega,atj]
  rfl
private theorem next_mid14 : Slice mid remaining_mid15 720 := splitR (a:=mid14) (by rfl) next_mid13
private theorem at_mid15 : Slice mid mid15 720 := splitL (b:=remaining_mid16) next_mid14
theorem literal_mid15 (j : Nat) (i : Instruction) (bound : j<48) (row : mid15[j]?=some i) : Direct181Source.Literal.program (760+j) = i := by
  have nlen : mid15.length=48 := rfl
  have atj := at_mid15 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (760+j)-40=720+j by omega,atj]
  rfl
private theorem next_mid15 : Slice mid remaining_mid16 768 := splitR (a:=mid15) (by rfl) next_mid14
private theorem at_mid16 : Slice mid mid16 768 := splitL (b:=remaining_mid17) next_mid15
theorem literal_mid16 (j : Nat) (i : Instruction) (bound : j<48) (row : mid16[j]?=some i) : Direct181Source.Literal.program (808+j) = i := by
  have nlen : mid16.length=48 := rfl
  have atj := at_mid16 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (808+j)-40=768+j by omega,atj]
  rfl
private theorem next_mid16 : Slice mid remaining_mid17 816 := splitR (a:=mid16) (by rfl) next_mid15
private theorem at_mid17 : Slice mid mid17 816 := splitL (b:=remaining_mid18) next_mid16
theorem literal_mid17 (j : Nat) (i : Instruction) (bound : j<48) (row : mid17[j]?=some i) : Direct181Source.Literal.program (856+j) = i := by
  have nlen : mid17.length=48 := rfl
  have atj := at_mid17 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (856+j)-40=816+j by omega,atj]
  rfl
private theorem next_mid17 : Slice mid remaining_mid18 864 := splitR (a:=mid17) (by rfl) next_mid16
private theorem at_mid18 : Slice mid mid18 864 := splitL (b:=remaining_mid19) next_mid17
theorem literal_mid18 (j : Nat) (i : Instruction) (bound : j<48) (row : mid18[j]?=some i) : Direct181Source.Literal.program (904+j) = i := by
  have nlen : mid18.length=48 := rfl
  have atj := at_mid18 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (904+j)-40=864+j by omega,atj]
  rfl
private theorem next_mid18 : Slice mid remaining_mid19 912 := splitR (a:=mid18) (by rfl) next_mid17
private theorem at_mid19 : Slice mid mid19 912 := splitL (b:=remaining_mid20) next_mid18
theorem literal_mid19 (j : Nat) (i : Instruction) (bound : j<48) (row : mid19[j]?=some i) : Direct181Source.Literal.program (952+j) = i := by
  have nlen : mid19.length=48 := rfl
  have atj := at_mid19 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (952+j)-40=912+j by omega,atj]
  rfl
private theorem next_mid19 : Slice mid remaining_mid20 960 := splitR (a:=mid19) (by rfl) next_mid18
private theorem at_mid20 : Slice mid mid20 960 := splitL (b:=remaining_mid21) next_mid19
theorem literal_mid20 (j : Nat) (i : Instruction) (bound : j<48) (row : mid20[j]?=some i) : Direct181Source.Literal.program (1000+j) = i := by
  have nlen : mid20.length=48 := rfl
  have atj := at_mid20 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1000+j)-40=960+j by omega,atj]
  rfl
private theorem next_mid20 : Slice mid remaining_mid21 1008 := splitR (a:=mid20) (by rfl) next_mid19
private theorem at_mid21 : Slice mid mid21 1008 := splitL (b:=remaining_mid22) next_mid20
theorem literal_mid21 (j : Nat) (i : Instruction) (bound : j<48) (row : mid21[j]?=some i) : Direct181Source.Literal.program (1048+j) = i := by
  have nlen : mid21.length=48 := rfl
  have atj := at_mid21 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1048+j)-40=1008+j by omega,atj]
  rfl
private theorem next_mid21 : Slice mid remaining_mid22 1056 := splitR (a:=mid21) (by rfl) next_mid20
private theorem at_mid22 : Slice mid mid22 1056 := splitL (b:=remaining_mid23) next_mid21
theorem literal_mid22 (j : Nat) (i : Instruction) (bound : j<48) (row : mid22[j]?=some i) : Direct181Source.Literal.program (1096+j) = i := by
  have nlen : mid22.length=48 := rfl
  have atj := at_mid22 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1096+j)-40=1056+j by omega,atj]
  rfl
private theorem next_mid22 : Slice mid remaining_mid23 1104 := splitR (a:=mid22) (by rfl) next_mid21
private theorem at_mid23 : Slice mid mid23 1104 := splitL (b:=remaining_mid24) next_mid22
theorem literal_mid23 (j : Nat) (i : Instruction) (bound : j<48) (row : mid23[j]?=some i) : Direct181Source.Literal.program (1144+j) = i := by
  have nlen : mid23.length=48 := rfl
  have atj := at_mid23 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1144+j)-40=1104+j by omega,atj]
  rfl
private theorem next_mid23 : Slice mid remaining_mid24 1152 := splitR (a:=mid23) (by rfl) next_mid22
private theorem at_mid24 : Slice mid mid24 1152 := splitL (b:=remaining_mid25) next_mid23
theorem literal_mid24 (j : Nat) (i : Instruction) (bound : j<48) (row : mid24[j]?=some i) : Direct181Source.Literal.program (1192+j) = i := by
  have nlen : mid24.length=48 := rfl
  have atj := at_mid24 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1192+j)-40=1152+j by omega,atj]
  rfl
private theorem next_mid24 : Slice mid remaining_mid25 1200 := splitR (a:=mid24) (by rfl) next_mid23
private theorem at_mid25 : Slice mid mid25 1200 := splitL (b:=remaining_mid26) next_mid24
theorem literal_mid25 (j : Nat) (i : Instruction) (bound : j<48) (row : mid25[j]?=some i) : Direct181Source.Literal.program (1240+j) = i := by
  have nlen : mid25.length=48 := rfl
  have atj := at_mid25 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1240+j)-40=1200+j by omega,atj]
  rfl
private theorem next_mid25 : Slice mid remaining_mid26 1248 := splitR (a:=mid25) (by rfl) next_mid24
private theorem at_mid26 : Slice mid mid26 1248 := splitL (b:=remaining_mid27) next_mid25
theorem literal_mid26 (j : Nat) (i : Instruction) (bound : j<48) (row : mid26[j]?=some i) : Direct181Source.Literal.program (1288+j) = i := by
  have nlen : mid26.length=48 := rfl
  have atj := at_mid26 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1288+j)-40=1248+j by omega,atj]
  rfl
private theorem next_mid26 : Slice mid remaining_mid27 1296 := splitR (a:=mid26) (by rfl) next_mid25
private theorem at_mid27 : Slice mid mid27 1296 := splitL (b:=remaining_mid28) next_mid26
theorem literal_mid27 (j : Nat) (i : Instruction) (bound : j<48) (row : mid27[j]?=some i) : Direct181Source.Literal.program (1336+j) = i := by
  have nlen : mid27.length=48 := rfl
  have atj := at_mid27 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1336+j)-40=1296+j by omega,atj]
  rfl
private theorem next_mid27 : Slice mid remaining_mid28 1344 := splitR (a:=mid27) (by rfl) next_mid26
private theorem at_mid28 : Slice mid mid28 1344 := splitL (b:=remaining_mid29) next_mid27
theorem literal_mid28 (j : Nat) (i : Instruction) (bound : j<48) (row : mid28[j]?=some i) : Direct181Source.Literal.program (1384+j) = i := by
  have nlen : mid28.length=48 := rfl
  have atj := at_mid28 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1384+j)-40=1344+j by omega,atj]
  rfl
private theorem next_mid28 : Slice mid remaining_mid29 1392 := splitR (a:=mid28) (by rfl) next_mid27
private theorem at_mid29 : Slice mid mid29 1392 := splitL (b:=remaining_mid30) next_mid28
theorem literal_mid29 (j : Nat) (i : Instruction) (bound : j<48) (row : mid29[j]?=some i) : Direct181Source.Literal.program (1432+j) = i := by
  have nlen : mid29.length=48 := rfl
  have atj := at_mid29 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1432+j)-40=1392+j by omega,atj]
  rfl
private theorem next_mid29 : Slice mid remaining_mid30 1440 := splitR (a:=mid29) (by rfl) next_mid28
private theorem at_mid30 : Slice mid mid30 1440 := splitL (b:=remaining_mid31) next_mid29
theorem literal_mid30 (j : Nat) (i : Instruction) (bound : j<48) (row : mid30[j]?=some i) : Direct181Source.Literal.program (1480+j) = i := by
  have nlen : mid30.length=48 := rfl
  have atj := at_mid30 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1480+j)-40=1440+j by omega,atj]
  rfl
private theorem next_mid30 : Slice mid remaining_mid31 1488 := splitR (a:=mid30) (by rfl) next_mid29
private theorem at_mid31 : Slice mid mid31 1488 := splitL (b:=remaining_mid32) next_mid30
theorem literal_mid31 (j : Nat) (i : Instruction) (bound : j<48) (row : mid31[j]?=some i) : Direct181Source.Literal.program (1528+j) = i := by
  have nlen : mid31.length=48 := rfl
  have atj := at_mid31 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1528+j)-40=1488+j by omega,atj]
  rfl
private theorem next_mid31 : Slice mid remaining_mid32 1536 := splitR (a:=mid31) (by rfl) next_mid30
private theorem at_mid32 : Slice mid mid32 1536 := splitL (b:=remaining_mid33) next_mid31
theorem literal_mid32 (j : Nat) (i : Instruction) (bound : j<48) (row : mid32[j]?=some i) : Direct181Source.Literal.program (1576+j) = i := by
  have nlen : mid32.length=48 := rfl
  have atj := at_mid32 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1576+j)-40=1536+j by omega,atj]
  rfl
private theorem next_mid32 : Slice mid remaining_mid33 1584 := splitR (a:=mid32) (by rfl) next_mid31
private theorem at_mid33 : Slice mid mid33 1584 := splitL (b:=remaining_mid34) next_mid32
theorem literal_mid33 (j : Nat) (i : Instruction) (bound : j<48) (row : mid33[j]?=some i) : Direct181Source.Literal.program (1624+j) = i := by
  have nlen : mid33.length=48 := rfl
  have atj := at_mid33 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1624+j)-40=1584+j by omega,atj]
  rfl
private theorem next_mid33 : Slice mid remaining_mid34 1632 := splitR (a:=mid33) (by rfl) next_mid32
private theorem at_mid34 : Slice mid mid34 1632 := splitL (b:=remaining_mid35) next_mid33
theorem literal_mid34 (j : Nat) (i : Instruction) (bound : j<48) (row : mid34[j]?=some i) : Direct181Source.Literal.program (1672+j) = i := by
  have nlen : mid34.length=48 := rfl
  have atj := at_mid34 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1672+j)-40=1632+j by omega,atj]
  rfl
private theorem next_mid34 : Slice mid remaining_mid35 1680 := splitR (a:=mid34) (by rfl) next_mid33
private theorem at_mid35 : Slice mid mid35 1680 := splitL (b:=remaining_mid36) next_mid34
theorem literal_mid35 (j : Nat) (i : Instruction) (bound : j<48) (row : mid35[j]?=some i) : Direct181Source.Literal.program (1720+j) = i := by
  have nlen : mid35.length=48 := rfl
  have atj := at_mid35 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1720+j)-40=1680+j by omega,atj]
  rfl
private theorem next_mid35 : Slice mid remaining_mid36 1728 := splitR (a:=mid35) (by rfl) next_mid34
private theorem at_mid36 : Slice mid mid36 1728 := splitL (b:=remaining_mid37) next_mid35
theorem literal_mid36 (j : Nat) (i : Instruction) (bound : j<48) (row : mid36[j]?=some i) : Direct181Source.Literal.program (1768+j) = i := by
  have nlen : mid36.length=48 := rfl
  have atj := at_mid36 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1768+j)-40=1728+j by omega,atj]
  rfl
private theorem next_mid36 : Slice mid remaining_mid37 1776 := splitR (a:=mid36) (by rfl) next_mid35
private theorem at_mid37 : Slice mid mid37 1776 := splitL (b:=remaining_mid38) next_mid36
theorem literal_mid37 (j : Nat) (i : Instruction) (bound : j<48) (row : mid37[j]?=some i) : Direct181Source.Literal.program (1816+j) = i := by
  have nlen : mid37.length=48 := rfl
  have atj := at_mid37 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1816+j)-40=1776+j by omega,atj]
  rfl
private theorem next_mid37 : Slice mid remaining_mid38 1824 := splitR (a:=mid37) (by rfl) next_mid36
private theorem at_mid38 : Slice mid mid38 1824 := splitL (b:=remaining_mid39) next_mid37
theorem literal_mid38 (j : Nat) (i : Instruction) (bound : j<48) (row : mid38[j]?=some i) : Direct181Source.Literal.program (1864+j) = i := by
  have nlen : mid38.length=48 := rfl
  have atj := at_mid38 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1864+j)-40=1824+j by omega,atj]
  rfl
private theorem next_mid38 : Slice mid remaining_mid39 1872 := splitR (a:=mid38) (by rfl) next_mid37
private theorem at_mid39 : Slice mid mid39 1872 := splitL (b:=remaining_mid40) next_mid38
theorem literal_mid39 (j : Nat) (i : Instruction) (bound : j<48) (row : mid39[j]?=some i) : Direct181Source.Literal.program (1912+j) = i := by
  have nlen : mid39.length=48 := rfl
  have atj := at_mid39 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1912+j)-40=1872+j by omega,atj]
  rfl
private theorem next_mid39 : Slice mid remaining_mid40 1920 := splitR (a:=mid39) (by rfl) next_mid38
private theorem at_mid40 : Slice mid mid40 1920 := splitL (b:=remaining_mid41) next_mid39
theorem literal_mid40 (j : Nat) (i : Instruction) (bound : j<48) (row : mid40[j]?=some i) : Direct181Source.Literal.program (1960+j) = i := by
  have nlen : mid40.length=48 := rfl
  have atj := at_mid40 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (1960+j)-40=1920+j by omega,atj]
  rfl
private theorem next_mid40 : Slice mid remaining_mid41 1968 := splitR (a:=mid40) (by rfl) next_mid39
private theorem at_mid41 : Slice mid mid41 1968 := splitL (b:=remaining_mid42) next_mid40
theorem literal_mid41 (j : Nat) (i : Instruction) (bound : j<48) (row : mid41[j]?=some i) : Direct181Source.Literal.program (2008+j) = i := by
  have nlen : mid41.length=48 := rfl
  have atj := at_mid41 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2008+j)-40=1968+j by omega,atj]
  rfl
private theorem next_mid41 : Slice mid remaining_mid42 2016 := splitR (a:=mid41) (by rfl) next_mid40
private theorem at_mid42 : Slice mid mid42 2016 := splitL (b:=remaining_mid43) next_mid41
theorem literal_mid42 (j : Nat) (i : Instruction) (bound : j<48) (row : mid42[j]?=some i) : Direct181Source.Literal.program (2056+j) = i := by
  have nlen : mid42.length=48 := rfl
  have atj := at_mid42 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2056+j)-40=2016+j by omega,atj]
  rfl
private theorem next_mid42 : Slice mid remaining_mid43 2064 := splitR (a:=mid42) (by rfl) next_mid41
private theorem at_mid43 : Slice mid mid43 2064 := splitL (b:=remaining_mid44) next_mid42
theorem literal_mid43 (j : Nat) (i : Instruction) (bound : j<48) (row : mid43[j]?=some i) : Direct181Source.Literal.program (2104+j) = i := by
  have nlen : mid43.length=48 := rfl
  have atj := at_mid43 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2104+j)-40=2064+j by omega,atj]
  rfl
private theorem next_mid43 : Slice mid remaining_mid44 2112 := splitR (a:=mid43) (by rfl) next_mid42
private theorem at_mid44 : Slice mid mid44 2112 := splitL (b:=remaining_mid45) next_mid43
theorem literal_mid44 (j : Nat) (i : Instruction) (bound : j<48) (row : mid44[j]?=some i) : Direct181Source.Literal.program (2152+j) = i := by
  have nlen : mid44.length=48 := rfl
  have atj := at_mid44 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2152+j)-40=2112+j by omega,atj]
  rfl
private theorem next_mid44 : Slice mid remaining_mid45 2160 := splitR (a:=mid44) (by rfl) next_mid43
private theorem at_mid45 : Slice mid mid45 2160 := splitL (b:=remaining_mid46) next_mid44
theorem literal_mid45 (j : Nat) (i : Instruction) (bound : j<48) (row : mid45[j]?=some i) : Direct181Source.Literal.program (2200+j) = i := by
  have nlen : mid45.length=48 := rfl
  have atj := at_mid45 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2200+j)-40=2160+j by omega,atj]
  rfl
private theorem next_mid45 : Slice mid remaining_mid46 2208 := splitR (a:=mid45) (by rfl) next_mid44
private theorem at_mid46 : Slice mid mid46 2208 := splitL (b:=remaining_mid47) next_mid45
theorem literal_mid46 (j : Nat) (i : Instruction) (bound : j<48) (row : mid46[j]?=some i) : Direct181Source.Literal.program (2248+j) = i := by
  have nlen : mid46.length=48 := rfl
  have atj := at_mid46 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2248+j)-40=2208+j by omega,atj]
  rfl
private theorem next_mid46 : Slice mid remaining_mid47 2256 := splitR (a:=mid46) (by rfl) next_mid45
private theorem at_mid47 : Slice mid mid47 2256 := splitL (b:=remaining_mid48) next_mid46
theorem literal_mid47 (j : Nat) (i : Instruction) (bound : j<48) (row : mid47[j]?=some i) : Direct181Source.Literal.program (2296+j) = i := by
  have nlen : mid47.length=48 := rfl
  have atj := at_mid47 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2296+j)-40=2256+j by omega,atj]
  rfl
private theorem next_mid47 : Slice mid remaining_mid48 2304 := splitR (a:=mid47) (by rfl) next_mid46
private theorem at_mid48 : Slice mid mid48 2304 := splitL (b:=remaining_mid49) next_mid47
theorem literal_mid48 (j : Nat) (i : Instruction) (bound : j<48) (row : mid48[j]?=some i) : Direct181Source.Literal.program (2344+j) = i := by
  have nlen : mid48.length=48 := rfl
  have atj := at_mid48 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2344+j)-40=2304+j by omega,atj]
  rfl
private theorem next_mid48 : Slice mid remaining_mid49 2352 := splitR (a:=mid48) (by rfl) next_mid47
private theorem at_mid49 : Slice mid mid49 2352 := splitL (b:=remaining_mid50) next_mid48
theorem literal_mid49 (j : Nat) (i : Instruction) (bound : j<48) (row : mid49[j]?=some i) : Direct181Source.Literal.program (2392+j) = i := by
  have nlen : mid49.length=48 := rfl
  have atj := at_mid49 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2392+j)-40=2352+j by omega,atj]
  rfl
private theorem next_mid49 : Slice mid remaining_mid50 2400 := splitR (a:=mid49) (by rfl) next_mid48
private theorem at_mid50 : Slice mid mid50 2400 := splitL (b:=remaining_mid51) next_mid49
theorem literal_mid50 (j : Nat) (i : Instruction) (bound : j<48) (row : mid50[j]?=some i) : Direct181Source.Literal.program (2440+j) = i := by
  have nlen : mid50.length=48 := rfl
  have atj := at_mid50 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2440+j)-40=2400+j by omega,atj]
  rfl
private theorem next_mid50 : Slice mid remaining_mid51 2448 := splitR (a:=mid50) (by rfl) next_mid49
private theorem at_mid51 : Slice mid mid51 2448 := splitL (b:=remaining_mid52) next_mid50
theorem literal_mid51 (j : Nat) (i : Instruction) (bound : j<48) (row : mid51[j]?=some i) : Direct181Source.Literal.program (2488+j) = i := by
  have nlen : mid51.length=48 := rfl
  have atj := at_mid51 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2488+j)-40=2448+j by omega,atj]
  rfl
private theorem next_mid51 : Slice mid remaining_mid52 2496 := splitR (a:=mid51) (by rfl) next_mid50
private theorem at_mid52 : Slice mid mid52 2496 := splitL (b:=remaining_mid53) next_mid51
theorem literal_mid52 (j : Nat) (i : Instruction) (bound : j<48) (row : mid52[j]?=some i) : Direct181Source.Literal.program (2536+j) = i := by
  have nlen : mid52.length=48 := rfl
  have atj := at_mid52 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2536+j)-40=2496+j by omega,atj]
  rfl
private theorem next_mid52 : Slice mid remaining_mid53 2544 := splitR (a:=mid52) (by rfl) next_mid51
private theorem at_mid53 : Slice mid mid53 2544 := splitL (b:=remaining_mid54) next_mid52
theorem literal_mid53 (j : Nat) (i : Instruction) (bound : j<48) (row : mid53[j]?=some i) : Direct181Source.Literal.program (2584+j) = i := by
  have nlen : mid53.length=48 := rfl
  have atj := at_mid53 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2584+j)-40=2544+j by omega,atj]
  rfl
private theorem next_mid53 : Slice mid remaining_mid54 2592 := splitR (a:=mid53) (by rfl) next_mid52
private theorem at_mid54 : Slice mid mid54 2592 := splitL (b:=remaining_mid55) next_mid53
theorem literal_mid54 (j : Nat) (i : Instruction) (bound : j<48) (row : mid54[j]?=some i) : Direct181Source.Literal.program (2632+j) = i := by
  have nlen : mid54.length=48 := rfl
  have atj := at_mid54 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2632+j)-40=2592+j by omega,atj]
  rfl
private theorem next_mid54 : Slice mid remaining_mid55 2640 := splitR (a:=mid54) (by rfl) next_mid53
private theorem at_mid55 : Slice mid mid55 2640 := splitL (b:=remaining_mid56) next_mid54
theorem literal_mid55 (j : Nat) (i : Instruction) (bound : j<48) (row : mid55[j]?=some i) : Direct181Source.Literal.program (2680+j) = i := by
  have nlen : mid55.length=48 := rfl
  have atj := at_mid55 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2680+j)-40=2640+j by omega,atj]
  rfl
private theorem next_mid55 : Slice mid remaining_mid56 2688 := splitR (a:=mid55) (by rfl) next_mid54
private theorem at_mid56 : Slice mid mid56 2688 := splitL (b:=remaining_mid57) next_mid55
theorem literal_mid56 (j : Nat) (i : Instruction) (bound : j<48) (row : mid56[j]?=some i) : Direct181Source.Literal.program (2728+j) = i := by
  have nlen : mid56.length=48 := rfl
  have atj := at_mid56 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2728+j)-40=2688+j by omega,atj]
  rfl
private theorem next_mid56 : Slice mid remaining_mid57 2736 := splitR (a:=mid56) (by rfl) next_mid55
private theorem at_mid57 : Slice mid mid57 2736 := splitL (b:=remaining_mid58) next_mid56
theorem literal_mid57 (j : Nat) (i : Instruction) (bound : j<48) (row : mid57[j]?=some i) : Direct181Source.Literal.program (2776+j) = i := by
  have nlen : mid57.length=48 := rfl
  have atj := at_mid57 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2776+j)-40=2736+j by omega,atj]
  rfl
private theorem next_mid57 : Slice mid remaining_mid58 2784 := splitR (a:=mid57) (by rfl) next_mid56
private theorem at_mid58 : Slice mid mid58 2784 := splitL (b:=empty_mid) next_mid57
theorem literal_mid58 (j : Nat) (i : Instruction) (bound : j<25) (row : mid58[j]?=some i) : Direct181Source.Literal.program (2824+j) = i := by
  have nlen : mid58.length=25 := rfl
  have atj := at_mid58 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_pos (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2824+j)-40=2784+j by omega,atj]
  rfl
private def empty_post : List Instruction := []
private def remaining_post2 := post2 ++ empty_post
private def remaining_post1 := post1 ++ remaining_post2
private def remaining_post0 := post0 ++ remaining_post1
private theorem begin_post : Slice post remaining_post0 0 := fun j _ => by simp only [Nat.zero_add]; rfl
private theorem at_post0 : Slice post post0 0 := splitL (b:=remaining_post1) begin_post
theorem literal_post0 (j : Nat) (i : Instruction) (bound : j<48) (row : post0[j]?=some i) : Direct181Source.Literal.program (2849+j) = i := by
  have nlen : post0.length=48 := rfl
  have atj := at_post0 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_neg (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2849+j)-2849=0+j by omega,atj]
  rfl
private theorem next_post0 : Slice post remaining_post1 48 := splitR (a:=post0) (by rfl) begin_post
private theorem at_post1 : Slice post post1 48 := splitL (b:=remaining_post2) next_post0
theorem literal_post1 (j : Nat) (i : Instruction) (bound : j<48) (row : post1[j]?=some i) : Direct181Source.Literal.program (2897+j) = i := by
  have nlen : post1.length=48 := rfl
  have atj := at_post1 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_neg (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2897+j)-2849=48+j by omega,atj]
  rfl
private theorem next_post1 : Slice post remaining_post2 96 := splitR (a:=post1) (by rfl) next_post0
private theorem at_post2 : Slice post post2 96 := splitL (b:=empty_post) next_post1
theorem literal_post2 (j : Nat) (i : Instruction) (bound : j<26) (row : post2[j]?=some i) : Direct181Source.Literal.program (2945+j) = i := by
  have nlen : post2.length=26 := rfl
  have atj := at_post2 j (by rwa [nlen])
  rw [row] at atj
  unfold Direct181Source.Literal.program
  rw [if_neg (by omega), if_neg (by omega)]
  rw [List.getD_eq_getElem?_getD,show (2945+j)-2849=96+j by omega,atj]
  rfl
end PA192.ModelSearch.Register181.Slices
