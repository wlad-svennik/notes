module
public import Src181EmitAtoms
public import NF181PAPacked
@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal PA192.ModelSearch.RegisterFields NF181PA.Packed NF181PA.Pool
namespace PA192.ModelSearch.Register181.Commands
set_option maxRecDepth 18000
set_option maxHeartbeats 12000000
set_option linter.unusedSimpArgs false
variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
theorem emittedRow0 (n t s c u v y d w : V) : row0 (u+d) (v+y) c u = ((emitAtom14 n t s c u v y d w)+(emitAtom14 n t s c u v y d w)) := by
  simp only [row0,single,s_one,q,konst,eqn,app,witness,←twice_cantor,two_mul,emitAtom14,emitAtom13,emitAtom12,emitAtom9,emitAtom6,emitAtom4,add_assoc,add_comm,add_left_comm]

theorem emittedRow1 (n t s c u v y d w : V) : row3 (u+d) (v+y) = ((emitAtom21 n t s c u v y d w)+(emitAtom21 n t s c u v y d w)+1) := by
  simp only [row3,single,s_one,q,konst,eqn,app,witness,←twice_cantor,two_mul,emitAtom21,emitAtom19,emitAtom17,add_assoc,add_comm,add_left_comm]

theorem emittedRow2 (n t s c u v y d w : V) : row6 (u+d) (v+y) c = ((emitAtom31 n t s c u v y d w)+(emitAtom31 n t s c u v y d w)) := by
  simp only [row6,single,s_one,q,konst,eqn,app,witness,←twice_cantor,two_mul,emitAtom31,emitAtom30,emitAtom29,emitAtom24,emitAtom9,add_assoc,add_comm,add_left_comm]

theorem emittedRow3 (n t s c u v y d w : V) : nativeB (u+d) (v+y) c = ((emitAtom46 n t s c u v y d w)+(emitAtom46 n t s c u v y d w)+1) := by
  simp only [nativeB,single,s_one,q,konst,eqn,app,witness,←twice_cantor,two_mul,emitAtom46,emitAtom45,emitAtom42,emitAtom38,emitAtom36,emitAtom34,emitAtom24,emitAtom17,add_assoc,add_comm,add_left_comm]

theorem emittedRow4 (n t s c u v y d w : V) : row2 (u+d) (v+y) c = ((emitAtom54 n t s c u v y d w)+(emitAtom54 n t s c u v y d w)) := by
  simp only [row2,single,s_one,q,konst,eqn,app,witness,←twice_cantor,two_mul,emitAtom54,emitAtom53,emitAtom29,emitAtom24,emitAtom9,add_assoc,add_comm,add_left_comm]

theorem emittedRow5 (n t s c u v y d w : V) : row4 (u+d) (v+y) c = ((emitAtom62 n t s c u v y d w)+(emitAtom62 n t s c u v y d w)) := by
  simp only [row4,single,s_one,q,konst,eqn,app,witness,←twice_cantor,two_mul,emitAtom62,emitAtom61,emitAtom29,emitAtom24,emitAtom9,add_assoc,add_comm,add_left_comm]

theorem emittedRow6 (n t s c u v y d w : V) : test (v+y) (u+d) = ((emitAtom81 n t s c u v y d w)+(emitAtom81 n t s c u v y d w)) := by
  simp only [test,single,s_one,q,konst,eqn,app,witness,←twice_cantor,two_mul,emitAtom81,emitAtom78,emitAtom77,emitAtom75,emitAtom70,emitAtom68,emitAtom66,emitAtom24,emitAtom17,add_assoc,add_comm,add_left_comm]

theorem emittedRow7 (n t s c u v y d w : V) : row8 (u+d) (v+y) = ((emitAtom93 n t s c u v y d w)+(emitAtom93 n t s c u v y d w)) := by
  simp only [row8,single,s_one,q,konst,eqn,app,witness,←twice_cantor,two_mul,emitAtom93,emitAtom90,emitAtom89,emitAtom85,emitAtom24,add_assoc,add_comm,add_left_comm]

theorem emittedBody (n t s c u v y d w : V) :
  cantor ((emitAtom93 n t s c u v y d w)+(emitAtom93 n t s c u v y d w)) (emitAtom82 n t s c u v y d w) = front8 (u+d) (v+y) c u (cantor t s) := by
  simp only [front8,front6,emittedRow0 n t s c u v y d w,emittedRow1 n t s c u v y d w,emittedRow2 n t s c u v y d w,emittedRow3 n t s c u v y d w,emittedRow4 n t s c u v y d w,emittedRow5 n t s c u v y d w,emittedRow6 n t s c u v y d w,emittedRow7 n t s c u v y d w,emitAtom82,emitAtom63,emitAtom55,emitAtom47,emitAtom32,emitAtom22,emitAtom15,emitAtom2]

end PA192.ModelSearch.Register181.Commands
#print axioms PA192.ModelSearch.Register181.Commands.emittedBody
