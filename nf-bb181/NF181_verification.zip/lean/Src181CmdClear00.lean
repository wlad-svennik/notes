module
public import Src181Atoms
public import Src181Loops
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
open PA192.ModelSearch.Register181.Certified
set_option maxRecDepth 8000
set_option maxHeartbeats 2500000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PA192.ModelSearch.Register181.Commands

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]

theorem commandClearAfter1 (f n t s c u v y d w : V) : Reach (config ((2920:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2922:Nat):V) f (vector n t s c 0 v 0 0 w)) := by
  have micro := site2920 f n t s c u v 0 0 w
  exact micro

theorem commandClear (f n t s c u v y d w : V) : Reach (config ((2920:Nat):V) f (vector n t s c u v 0 0 w)) (config ((2924:Nat):V) f (vector n t s c 0 0 0 0 w)) := by
  have micro := site2922 f n t s c 0 v 0 0 w
  exact (commandClearAfter1 f n t s c u v y d w).trans micro

end PA192.ModelSearch.Register181.Commands
