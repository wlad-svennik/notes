import NF181PATapeBatchCheck
namespace NF181PA.Symbolic
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
private theorem w2144_0 : checkWitness 2144 false false 648 = true := by decide +kernel
private theorem w2144_1 : checkWitness 2144 false true 4740 = true := by decide +kernel
private theorem w2144_2 : checkWitness 2144 true false 639 = true := by decide +kernel
private theorem w2144_3 : checkWitness 2144 true true 4731 = true := by decide +kernel
private theorem cases2144 : checkFour 2144 (648,4740,639,4731) = true := by
  simp only [checkFour, w2144_0, w2144_1, w2144_2, w2144_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2144 : Coverage 2144 2145 := checkList_sound (ws:=[(648,4740,639,4731)]) (by simpa only [checkList, Bool.and_true] using cases2144)
private theorem w2145_0 : checkWitness 2145 false false 8925 = true := by decide +kernel
private theorem w2145_2 : checkWitness 2145 true false 8916 = true := by decide +kernel
private theorem cases2145 : checkFour 2145 (8925,0,8916,0) = true := by
  simp only [checkFour, w2145_0, w2145_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2145 : Coverage 2145 2146 := checkList_sound (ws:=[(8925,0,8916,0)]) (by simpa only [checkList, Bool.and_true] using cases2145)
private theorem w2146_0 : checkWitness 2146 false false 62 = true := by decide +kernel
private theorem w2146_2 : checkWitness 2146 true false 62 = true := by decide +kernel
private theorem cases2146 : checkFour 2146 (62,0,62,0) = true := by
  simp only [checkFour, w2146_0, w2146_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2146 : Coverage 2146 2147 := checkList_sound (ws:=[(62,0,62,0)]) (by simpa only [checkList, Bool.and_true] using cases2146)
private theorem w2147_0 : checkWitness 2147 false false 518 = true := by decide +kernel
private theorem w2147_1 : checkWitness 2147 false true 4614 = true := by decide +kernel
private theorem w2147_2 : checkWitness 2147 true false 518 = true := by decide +kernel
private theorem w2147_3 : checkWitness 2147 true true 4614 = true := by decide +kernel
private theorem cases2147 : checkFour 2147 (518,4614,518,4614) = true := by
  simp only [checkFour, w2147_0, w2147_1, w2147_2, w2147_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2147 : Coverage 2147 2148 := checkList_sound (ws:=[(518,4614,518,4614)]) (by simpa only [checkList, Bool.and_true] using cases2147)
private theorem w2148_0 : checkWitness 2148 false false 8952 = true := by decide +kernel
private theorem w2148_2 : checkWitness 2148 true false 8943 = true := by decide +kernel
private theorem cases2148 : checkFour 2148 (8952,0,8943,0) = true := by
  simp only [checkFour, w2148_0, w2148_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2148 : Coverage 2148 2149 := checkList_sound (ws:=[(8952,0,8943,0)]) (by simpa only [checkList, Bool.and_true] using cases2148)
private theorem w2149_0 : checkWitness 2149 false false 80 = true := by decide +kernel
private theorem w2149_2 : checkWitness 2149 true false 80 = true := by decide +kernel
private theorem cases2149 : checkFour 2149 (80,0,80,0) = true := by
  simp only [checkFour, w2149_0, w2149_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2149 : Coverage 2149 2150 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2149)
private theorem w2150_0 : checkWitness 2150 false false 534 = true := by decide +kernel
private theorem w2150_1 : checkWitness 2150 false true 4630 = true := by decide +kernel
private theorem w2150_2 : checkWitness 2150 true false 534 = true := by decide +kernel
private theorem w2150_3 : checkWitness 2150 true true 4630 = true := by decide +kernel
private theorem cases2150 : checkFour 2150 (534,4630,534,4630) = true := by
  simp only [checkFour, w2150_0, w2150_1, w2150_2, w2150_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2150 : Coverage 2150 2151 := checkList_sound (ws:=[(534,4630,534,4630)]) (by simpa only [checkList, Bool.and_true] using cases2150)
private theorem w2151_0 : checkWitness 2151 false false 8892 = true := by decide +kernel
private theorem w2151_2 : checkWitness 2151 true false 8888 = true := by decide +kernel
private theorem cases2151 : checkFour 2151 (8892,0,8888,0) = true := by
  simp only [checkFour, w2151_0, w2151_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2151 : Coverage 2151 2152 := checkList_sound (ws:=[(8892,0,8888,0)]) (by simpa only [checkList, Bool.and_true] using cases2151)
private theorem w2152_0 : checkWitness 2152 false false 82 = true := by decide +kernel
private theorem w2152_2 : checkWitness 2152 true false 82 = true := by decide +kernel
private theorem cases2152 : checkFour 2152 (82,0,82,0) = true := by
  simp only [checkFour, w2152_0, w2152_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2152 : Coverage 2152 2153 := checkList_sound (ws:=[(82,0,82,0)]) (by simpa only [checkList, Bool.and_true] using cases2152)
private theorem w2153_0 : checkWitness 2153 false false 572 = true := by decide +kernel
private theorem w2153_1 : checkWitness 2153 false true 4668 = true := by decide +kernel
private theorem w2153_2 : checkWitness 2153 true false 572 = true := by decide +kernel
private theorem w2153_3 : checkWitness 2153 true true 4668 = true := by decide +kernel
private theorem cases2153 : checkFour 2153 (572,4668,572,4668) = true := by
  simp only [checkFour, w2153_0, w2153_1, w2153_2, w2153_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2153 : Coverage 2153 2154 := checkList_sound (ws:=[(572,4668,572,4668)]) (by simpa only [checkList, Bool.and_true] using cases2153)
private theorem w2154_0 : checkWitness 2154 false false 8913 = true := by decide +kernel
private theorem w2154_2 : checkWitness 2154 true false 8909 = true := by decide +kernel
private theorem cases2154 : checkFour 2154 (8913,0,8909,0) = true := by
  simp only [checkFour, w2154_0, w2154_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2154 : Coverage 2154 2155 := checkList_sound (ws:=[(8913,0,8909,0)]) (by simpa only [checkList, Bool.and_true] using cases2154)
private theorem w2155_0 : checkWitness 2155 false false 8948 = true := by decide +kernel
private theorem w2155_2 : checkWitness 2155 true false 8939 = true := by decide +kernel
private theorem cases2155 : checkFour 2155 (8948,0,8939,0) = true := by
  simp only [checkFour, w2155_0, w2155_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2155 : Coverage 2155 2156 := checkList_sound (ws:=[(8948,0,8939,0)]) (by simpa only [checkList, Bool.and_true] using cases2155)
private theorem w2156_0 : checkWitness 2156 false false 106 = true := by decide +kernel
private theorem w2156_2 : checkWitness 2156 true false 106 = true := by decide +kernel
private theorem cases2156 : checkFour 2156 (106,0,106,0) = true := by
  simp only [checkFour, w2156_0, w2156_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2156 : Coverage 2156 2157 := checkList_sound (ws:=[(106,0,106,0)]) (by simpa only [checkList, Bool.and_true] using cases2156)
private theorem w2157_0 : checkWitness 2157 false false 660 = true := by decide +kernel
private theorem w2157_1 : checkWitness 2157 false true 4752 = true := by decide +kernel
private theorem w2157_2 : checkWitness 2157 true false 651 = true := by decide +kernel
private theorem w2157_3 : checkWitness 2157 true true 4743 = true := by decide +kernel
private theorem cases2157 : checkFour 2157 (660,4752,651,4743) = true := by
  simp only [checkFour, w2157_0, w2157_1, w2157_2, w2157_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2157 : Coverage 2157 2158 := checkList_sound (ws:=[(660,4752,651,4743)]) (by simpa only [checkList, Bool.and_true] using cases2157)
private theorem w2158_0 : checkWitness 2158 false false 8909 = true := by decide +kernel
private theorem w2158_2 : checkWitness 2158 true false 8905 = true := by decide +kernel
private theorem cases2158 : checkFour 2158 (8909,0,8905,0) = true := by
  simp only [checkFour, w2158_0, w2158_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2158 : Coverage 2158 2159 := checkList_sound (ws:=[(8909,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases2158)
private theorem w2159_0 : checkWitness 2159 false false 654 = true := by decide +kernel
private theorem w2159_1 : checkWitness 2159 false true 4746 = true := by decide +kernel
private theorem w2159_2 : checkWitness 2159 true false 645 = true := by decide +kernel
private theorem w2159_3 : checkWitness 2159 true true 4737 = true := by decide +kernel
private theorem cases2159 : checkFour 2159 (654,4746,645,4737) = true := by
  simp only [checkFour, w2159_0, w2159_1, w2159_2, w2159_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2159 : Coverage 2159 2160 := checkList_sound (ws:=[(654,4746,645,4737)]) (by simpa only [checkList, Bool.and_true] using cases2159)
private theorem w2160_0 : checkWitness 2160 false false 8878 = true := by decide +kernel
private theorem w2160_2 : checkWitness 2160 true false 8874 = true := by decide +kernel
private theorem cases2160 : checkFour 2160 (8878,0,8874,0) = true := by
  simp only [checkFour, w2160_0, w2160_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2160 : Coverage 2160 2161 := checkList_sound (ws:=[(8878,0,8874,0)]) (by simpa only [checkList, Bool.and_true] using cases2160)
private theorem w2161_0 : checkWitness 2161 false false 94 = true := by decide +kernel
private theorem w2161_2 : checkWitness 2161 true false 94 = true := by decide +kernel
private theorem cases2161 : checkFour 2161 (94,0,94,0) = true := by
  simp only [checkFour, w2161_0, w2161_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2161 : Coverage 2161 2162 := checkList_sound (ws:=[(94,0,94,0)]) (by simpa only [checkList, Bool.and_true] using cases2161)
private theorem w2162_0 : checkWitness 2162 false false 86 = true := by decide +kernel
private theorem w2162_2 : checkWitness 2162 true false 86 = true := by decide +kernel
private theorem cases2162 : checkFour 2162 (86,0,86,0) = true := by
  simp only [checkFour, w2162_0, w2162_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2162 : Coverage 2162 2163 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases2162)
private theorem w2163_0 : checkWitness 2163 false false 619 = true := by decide +kernel
private theorem w2163_1 : checkWitness 2163 false true 4703 = true := by decide +kernel
private theorem w2163_2 : checkWitness 2163 true false 619 = true := by decide +kernel
private theorem w2163_3 : checkWitness 2163 true true 4703 = true := by decide +kernel
private theorem cases2163 : checkFour 2163 (619,4703,619,4703) = true := by
  simp only [checkFour, w2163_0, w2163_1, w2163_2, w2163_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2163 : Coverage 2163 2164 := checkList_sound (ws:=[(619,4703,619,4703)]) (by simpa only [checkList, Bool.and_true] using cases2163)
private theorem w2164_0 : checkWitness 2164 false false 8872 = true := by decide +kernel
private theorem w2164_2 : checkWitness 2164 true false 8868 = true := by decide +kernel
private theorem cases2164 : checkFour 2164 (8872,0,8868,0) = true := by
  simp only [checkFour, w2164_0, w2164_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2164 : Coverage 2164 2165 := checkList_sound (ws:=[(8872,0,8868,0)]) (by simpa only [checkList, Bool.and_true] using cases2164)
private theorem w2165_0 : checkWitness 2165 false false 86 = true := by decide +kernel
private theorem w2165_2 : checkWitness 2165 true false 86 = true := by decide +kernel
private theorem cases2165 : checkFour 2165 (86,0,86,0) = true := by
  simp only [checkFour, w2165_0, w2165_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2165 : Coverage 2165 2166 := checkList_sound (ws:=[(86,0,86,0)]) (by simpa only [checkList, Bool.and_true] using cases2165)
private theorem w2166_0 : checkWitness 2166 false false 617 = true := by decide +kernel
private theorem w2166_1 : checkWitness 2166 false true 4709 = true := by decide +kernel
private theorem w2166_2 : checkWitness 2166 true false 608 = true := by decide +kernel
private theorem w2166_3 : checkWitness 2166 true true 4700 = true := by decide +kernel
private theorem cases2166 : checkFour 2166 (617,4709,608,4700) = true := by
  simp only [checkFour, w2166_0, w2166_1, w2166_2, w2166_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2166 : Coverage 2166 2167 := checkList_sound (ws:=[(617,4709,608,4700)]) (by simpa only [checkList, Bool.and_true] using cases2166)
private theorem w2167_0 : checkWitness 2167 false false 8914 = true := by decide +kernel
private theorem w2167_2 : checkWitness 2167 true false 8905 = true := by decide +kernel
private theorem cases2167 : checkFour 2167 (8914,0,8905,0) = true := by
  simp only [checkFour, w2167_0, w2167_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2167 : Coverage 2167 2168 := checkList_sound (ws:=[(8914,0,8905,0)]) (by simpa only [checkList, Bool.and_true] using cases2167)
private theorem w2168_0 : checkWitness 2168 false false 8860 = true := by decide +kernel
private theorem w2168_2 : checkWitness 2168 true false 8856 = true := by decide +kernel
private theorem cases2168 : checkFour 2168 (8860,0,8856,0) = true := by
  simp only [checkFour, w2168_0, w2168_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2168 : Coverage 2168 2169 := checkList_sound (ws:=[(8860,0,8856,0)]) (by simpa only [checkList, Bool.and_true] using cases2168)
private theorem w2169_0 : checkWitness 2169 false false 80 = true := by decide +kernel
private theorem w2169_2 : checkWitness 2169 true false 80 = true := by decide +kernel
private theorem cases2169 : checkFour 2169 (80,0,80,0) = true := by
  simp only [checkFour, w2169_0, w2169_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2169 : Coverage 2169 2170 := checkList_sound (ws:=[(80,0,80,0)]) (by simpa only [checkList, Bool.and_true] using cases2169)
private theorem w2170_0 : checkWitness 2170 false false 644 = true := by decide +kernel
private theorem w2170_1 : checkWitness 2170 false true 4736 = true := by decide +kernel
private theorem w2170_2 : checkWitness 2170 true false 635 = true := by decide +kernel
private theorem w2170_3 : checkWitness 2170 true true 4727 = true := by decide +kernel
private theorem cases2170 : checkFour 2170 (644,4736,635,4727) = true := by
  simp only [checkFour, w2170_0, w2170_1, w2170_2, w2170_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2170 : Coverage 2170 2171 := checkList_sound (ws:=[(644,4736,635,4727)]) (by simpa only [checkList, Bool.and_true] using cases2170)
private theorem w2171_0 : checkWitness 2171 false false 8921 = true := by decide +kernel
private theorem w2171_2 : checkWitness 2171 true false 8912 = true := by decide +kernel
private theorem cases2171 : checkFour 2171 (8921,0,8912,0) = true := by
  simp only [checkFour, w2171_0, w2171_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2171 : Coverage 2171 2172 := checkList_sound (ws:=[(8921,0,8912,0)]) (by simpa only [checkList, Bool.and_true] using cases2171)
private theorem w2172_0 : checkWitness 2172 false false 64 = true := by decide +kernel
private theorem w2172_2 : checkWitness 2172 true false 64 = true := by decide +kernel
private theorem cases2172 : checkFour 2172 (64,0,64,0) = true := by
  simp only [checkFour, w2172_0, w2172_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2172 : Coverage 2172 2173 := checkList_sound (ws:=[(64,0,64,0)]) (by simpa only [checkList, Bool.and_true] using cases2172)
private theorem w2173_0 : checkWitness 2173 false false 508 = true := by decide +kernel
private theorem w2173_1 : checkWitness 2173 false true 4604 = true := by decide +kernel
private theorem w2173_2 : checkWitness 2173 true false 508 = true := by decide +kernel
private theorem w2173_3 : checkWitness 2173 true true 4604 = true := by decide +kernel
private theorem cases2173 : checkFour 2173 (508,4604,508,4604) = true := by
  simp only [checkFour, w2173_0, w2173_1, w2173_2, w2173_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2173 : Coverage 2173 2174 := checkList_sound (ws:=[(508,4604,508,4604)]) (by simpa only [checkList, Bool.and_true] using cases2173)
private theorem w2174_0 : checkWitness 2174 false false 8903 = true := by decide +kernel
private theorem w2174_2 : checkWitness 2174 true false 8899 = true := by decide +kernel
private theorem cases2174 : checkFour 2174 (8903,0,8899,0) = true := by
  simp only [checkFour, w2174_0, w2174_2, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2174 : Coverage 2174 2175 := checkList_sound (ws:=[(8903,0,8899,0)]) (by simpa only [checkList, Bool.and_true] using cases2174)
private theorem w2175_0 : checkWitness 2175 false false 634 = true := by decide +kernel
private theorem w2175_1 : checkWitness 2175 false true 4730 = true := by decide +kernel
private theorem w2175_2 : checkWitness 2175 true false 625 = true := by decide +kernel
private theorem w2175_3 : checkWitness 2175 true true 4721 = true := by decide +kernel
private theorem cases2175 : checkFour 2175 (634,4730,625,4721) = true := by
  simp only [checkFour, w2175_0, w2175_1, w2175_2, w2175_3, Bool.or_true, Bool.and_true, Bool.true_and] <;> decide +kernel
private theorem one2175 : Coverage 2175 2176 := checkList_sound (ws:=[(634,4730,625,4721)]) (by simpa only [checkList, Bool.and_true] using cases2175)
theorem cover2144 : Coverage 2144 2176 := (Coverage.join (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2144 one2145) (Coverage.join one2146 one2147)) (Coverage.join (Coverage.join one2148 one2149) (Coverage.join one2150 one2151))) (Coverage.join (Coverage.join (Coverage.join one2152 one2153) (Coverage.join one2154 one2155)) (Coverage.join (Coverage.join one2156 one2157) (Coverage.join one2158 one2159)))) (Coverage.join (Coverage.join (Coverage.join (Coverage.join one2160 one2161) (Coverage.join one2162 one2163)) (Coverage.join (Coverage.join one2164 one2165) (Coverage.join one2166 one2167))) (Coverage.join (Coverage.join (Coverage.join one2168 one2169) (Coverage.join one2170 one2171)) (Coverage.join (Coverage.join one2172 one2173) (Coverage.join one2174 one2175)))))
end NF181PA.Symbolic
