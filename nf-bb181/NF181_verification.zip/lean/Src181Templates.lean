module
public import Src181Reach
import Mathlib.Tactic.Ring

@[expose] public section
open FFL FFL.FirstOrder FFL.FirstOrder.Arithmetic
open scoped FFL.FirstOrder.Arithmetic FFL.FirstOrder.Bounding
open PA192.Literal
set_option linter.style.haveILetI false
set_option linter.unusedVariables false
set_option maxRecDepth 7000
set_option maxHeartbeats 3500000
namespace PA192.ModelSearch.Register181.Templates

variable {V : Type} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗣𝗔]
variable (atPc : Nat → V → V → V → V) [defined : ∀ j, Language.DefinableFunction₃ ℒₒᵣ (atPc j)]

private theorem zeroOrSucc (x : V) : x=0 ∨ ∃ j : V, x=j+1 :=
  (eq_zero_or_pos x).imp_right eq_succ_of_pos

private theorem cancelSub (x y : V) : (x+1)-(y+1)=x-y := by
  rw [add_comm y 1,← Arithmetic.sub_sub]
  simp

theorem clearBlock
    (e0z : ∀ x y z : V, Reach (atPc 0 0 y z) (atPc 2 0 y z))
    (e0s : ∀ x y z : V, Reach (atPc 0 (x+1) y z) (atPc 1 x y z))
    (e1 : ∀ x y z : V, Reach (atPc 1 x y z) (atPc 0 x y z)) :
    ∀ x : V, ∀ y z, Reach (atPc 0 x y z) (atPc 2 0 y z) := by
  letI : Language.DefinableFunction₂ ℒₒᵣ (fun y z : V => atPc 2 0 y z) := by definability
  have h := affineLoop (atPc 0) (fun y z : V => atPc 2 0 y z) 0 0
    (fun y z=>e0z 0 y z) (fun x y z=>by
      simpa [add_assoc,show (1:V)+1=2 by ring] using (e0s x y z).trans (e1 x y z))
  simpa using h

theorem transferBlock
    (e0z : ∀ x y z : V, Reach (atPc 0 0 y z) (atPc 3 0 y z))
    (e0s : ∀ x y z : V, Reach (atPc 0 (x+1) y z) (atPc 1 x y z))
    (e1 : ∀ x y z : V, Reach (atPc 1 x y z) (atPc 2 x (y+1) z))
    (e2 : ∀ x y z : V, Reach (atPc 2 x y z) (atPc 0 x y z)) :
    ∀ x : V, ∀ y z, Reach (atPc 0 x y z) (atPc 3 0 (y+x) z) := by
  letI : Language.DefinableFunction₂ ℒₒᵣ (fun y z : V => atPc 3 0 y z) := by definability
  have h := affineLoop (atPc 0) (fun y z : V => atPc 3 0 y z) 1 0
    (fun y z=>e0z 0 y z) (fun x y z=>by
      simpa [add_assoc,show (1:V)+1=2 by ring] using ((e0s x y z).trans (e1 x y z)).trans (e2 x (y+1) z))
  simpa using h

theorem copyBlock
    (e0z : ∀ x y z : V, Reach (atPc 0 0 y z) (atPc 4 0 y z))
    (e0s : ∀ x y z : V, Reach (atPc 0 (x+1) y z) (atPc 1 x y z))
    (e1 : ∀ x y z : V, Reach (atPc 1 x y z) (atPc 2 x (y+1) z))
    (e2 : ∀ x y z : V, Reach (atPc 2 x y z) (atPc 3 x y (z+1)))
    (e3 : ∀ x y z : V, Reach (atPc 3 x y z) (atPc 0 x y z)) :
    ∀ x : V, ∀ y z, Reach (atPc 0 x y z) (atPc 4 0 (y+x) (z+x)) := by
  letI : Language.DefinableFunction₂ ℒₒᵣ (fun y z : V => atPc 4 0 y z) := by definability
  have h := affineLoop (atPc 0) (fun y z : V => atPc 4 0 y z) 1 1
    (fun y z=>e0z 0 y z) (fun x y z=>by
      simpa [add_assoc,show (1:V)+1=2 by ring] using (((e0s x y z).trans (e1 x y z)).trans (e2 x (y+1) z)).trans (e3 x (y+1) (z+1)))
  simpa using h

theorem doubleBlock
    (e0z : ∀ x y z : V, Reach (atPc 0 0 y z) (atPc 4 0 y z))
    (e0s : ∀ x y z : V, Reach (atPc 0 (x+1) y z) (atPc 1 x y z))
    (e1 : ∀ x y z : V, Reach (atPc 1 x y z) (atPc 2 x (y+1) z))
    (e2 : ∀ x y z : V, Reach (atPc 2 x y z) (atPc 3 x (y+1) z))
    (e3 : ∀ x y z : V, Reach (atPc 3 x y z) (atPc 0 x y z)) :
    ∀ x : V, ∀ y z, Reach (atPc 0 x y z) (atPc 4 0 (y+2*x) z) := by
  letI : Language.DefinableFunction₂ ℒₒᵣ (fun y z : V => atPc 4 0 y z) := by definability
  have h := affineLoop (atPc 0) (fun y z : V => atPc 4 0 y z) 2 0
    (fun y z=>e0z 0 y z) (fun x y z=>by
      simpa [add_assoc,show (1:V)+1=2 by ring] using (((e0s x y z).trans (e1 x y z)).trans (e2 x (y+1) z)).trans (e3 x ((y+1)+1) z))
  simpa using h

theorem unpairBlock
    (e0z : ∀ x y z : V, Reach (atPc 0 0 y z) (atPc 8 0 y z))
    (e0s : ∀ x y z : V, Reach (atPc 0 (x+1) y z) (atPc 1 x y z))
    (e1 : ∀ x y z : V, Reach (atPc 1 x y z) (atPc 2 x y (z+1)))
    (e2z : ∀ x y z : V, Reach (atPc 2 x 0 z) (atPc 4 x 0 z))
    (e2s : ∀ x y z : V, Reach (atPc 2 x (y+1) z) (atPc 3 x y z))
    (e3 : ∀ x y z : V, Reach (atPc 3 x y z) (atPc 7 x y z))
    (e4z : ∀ x y z : V, Reach (atPc 4 x y 0) (atPc 7 x y 0))
    (e4s : ∀ x y z : V, Reach (atPc 4 x y (z+1)) (atPc 5 x y z))
    (e5 : ∀ x y z : V, Reach (atPc 5 x y z) (atPc 6 x (y+1) z))
    (e6 : ∀ x y z : V, Reach (atPc 6 x y z) (atPc 4 x y z))
    (e7 : ∀ x y z : V, Reach (atPc 7 x y z) (atPc 0 x y z)) :
    ∀ n : V, ∀ y z, Reach (atPc 0 n y z) (atPc 8 0 (left (cantor y z+n)) (right (cantor y z+n))) := by
  letI : Language.DefinableFunction₂ ℒₒᵣ (fun y z : V => atPc 8 0 y z) := by definability
  apply diagonalLoop (atPc 0) (fun y z : V => atPc 8 0 y z) (fun y z=>e0z 0 y z)
  intro x y z
  rcases zeroOrSucc y with rfl|⟨j,rfl⟩
  · have sweep : ∀ n : V, ∀ a, Reach (atPc 4 x a n) (atPc 7 x (a+n) 0) := by
      apply modelInduct
      · definability
      · intro a; simpa using e4z x a 0
      · intro n ih a
        have h := ((e4s x a n).trans (e5 x a n)).trans (e6 x (a+1) n)
        simpa [add_assoc,add_comm (1:V) n] using h.trans (ih (a+1))
    have h := (((e0s x 0 z).trans (e1 x 0 z)).trans (e2z x 0 (z+1))).trans (sweep (z+1) 0)
    have h' : Reach (atPc 0 (x+1) 0 z) (atPc 7 x (z+1) 0) := by simpa using h
    simpa [diagonalNext] using h'.trans (e7 x (z+1) 0)
  · have h := (((e0s x (j+1) z).trans (e1 x (j+1) z)).trans (e2s x j (z+1))).trans (e3 x j (z+1))
    simpa [diagonalNext] using h.trans (e7 x j (z+1))

theorem pairBlock
    (e0z : ∀ x y z : V, Reach (atPc 0 x 0 z) (atPc 4 x 0 z))
    (e0s : ∀ x y z : V, Reach (atPc 0 x (y+1) z) (atPc 1 x y z))
    (e1 : ∀ x y z : V, Reach (atPc 1 x y z) (atPc 2 x y (z+1)))
    (e2 : ∀ x y z : V, Reach (atPc 2 x y z) (atPc 3 (x+1) y z))
    (e3 : ∀ x y z : V, Reach (atPc 3 x y z) (atPc 0 x y z))
    (e4z : ∀ x y z : V, Reach (atPc 4 0 y z) (atPc 10 0 y z))
    (e4s : ∀ x y z : V, Reach (atPc 4 (x+1) y z) (atPc 5 x y z))
    (e5 : ∀ x y z : V, Reach (atPc 5 x y z) (atPc 6 x y (z+1)))
    (e6z : ∀ x y z : V, Reach (atPc 6 0 y z) (atPc 9 0 y z))
    (e6s : ∀ x y z : V, Reach (atPc 6 (x+1) y z) (atPc 7 x y z))
    (e7 : ∀ x y z : V, Reach (atPc 7 x y z) (atPc 8 x (y+1) z))
    (e8 : ∀ x y z : V, Reach (atPc 8 x y z) (atPc 6 x y z))
    (e9 : ∀ x y z : V, Reach (atPc 9 x y z) (atPc 0 x y z)) :
    ∀ a t b : V, Reach (atPc 0 a t b) (atPc 10 0 0 (b+cantor a t)) := by
  have first : ∀ t : V, ∀ a b, Reach (atPc 0 a t b) (atPc 4 (a+t) 0 (b+t)) := by
    apply modelInduct
    · definability
    · intro a b; simpa using e0z a 0 b
    · intro t ih a b
      have h := (((e0s a t b).trans (e1 a t b)).trans (e2 a t (b+1))).trans (e3 (a+1) t (b+1))
      simpa [add_assoc,add_comm (1:V) t] using h.trans (ih (a+1) (b+1))
  have inner (b : V) : ∀ a : V, ∀ t, Reach (atPc 6 a t b) (atPc 9 0 (t+a) b) := by
    apply modelInduct
    · definability
    · intro t; simpa using e6z 0 t b
    · intro a ih t
      have h := ((e6s a t b).trans (e7 a t b)).trans (e8 a (t+1) b)
      simpa [add_assoc,add_comm (1:V) a] using h.trans (ih (t+1))
  have round (a t b r : V) (eq : a+t=r+1) : Reach (atPc 0 a t b) (atPc 0 0 r ((b+t)+1)) := by
    have h := first t a b
    rw [eq] at h
    have k := ((h.trans (e4s r 0 (b+t))).trans (e5 r 0 (b+t))).trans (inner ((b+t)+1) r 0)
    exact (by simpa using k : Reach (atPc 0 a t b) (atPc 9 0 r ((b+t)+1))).trans (e9 0 r ((b+t)+1))
  have restore (a t b r : V) (he : a+t=r+1) : (b+t)+1+cantor 0 r=b+cantor a t := by
    simp only [cantor,zero_add,he,triangle_succ]
    ring
  have tail : ∀ n : V, ∀ b, Reach (atPc 0 0 n b) (atPc 10 0 0 (b+cantor 0 n)) := by
    apply modelInduct
    · definability
    · intro b; simpa [cantor] using (e0z 0 0 b).trans (e4z 0 0 b)
    · intro n ih b
      have he : 0+(n+1)=n+1 := by simp
      exact (restore 0 (n+1) b n he) ▸ ((round 0 (n+1) b n he).trans (ih ((b+(n+1))+1)))
  intro a t b
  rcases zeroOrSucc a with rfl|⟨j,rfl⟩
  · exact tail t b
  · have he : j+1+t=(j+t)+1 := by ring
    exact (restore (j+1) t b (j+t) he) ▸ ((round (j+1) t b (j+t) he).trans (tail (j+t) ((b+t)+1)))

theorem differenceBlock
    (e0z : ∀ x y z : V, Reach (atPc 0 0 y z) (atPc 7 0 y z))
    (e0s : ∀ x y z : V, Reach (atPc 0 (x+1) y z) (atPc 1 x y z))
    (e1z : ∀ x y z : V, Reach (atPc 1 x 0 z) (atPc 3 x 0 z))
    (e1s : ∀ x y z : V, Reach (atPc 1 x (y+1) z) (atPc 2 x y z))
    (e2 : ∀ x y z : V, Reach (atPc 2 x y z) (atPc 0 x y z))
    (e3 : ∀ x y z : V, Reach (atPc 3 x y z) (atPc 4 x (y+1) z))
    (e4z : ∀ x y z : V, Reach (atPc 4 0 y z) (atPc 7 0 y z))
    (e4s : ∀ x y z : V, Reach (atPc 4 (x+1) y z) (atPc 5 x y z))
    (e5 : ∀ x y z : V, Reach (atPc 5 x y z) (atPc 6 x (y+1) z))
    (e6 : ∀ x y z : V, Reach (atPc 6 x y z) (atPc 4 x y z)) :
    ∀ a : V, ∀ b c, Reach (atPc 0 a b c) (atPc 7 0 ((a-b)+(b-a)) c) := by
  have inner (c : V) : ∀ a : V, ∀ b, Reach (atPc 4 a b c) (atPc 7 0 (b+a) c) := by
    apply modelInduct
    · definability
    · intro b; simpa using e4z 0 b c
    · intro a ih b
      have h := ((e4s a b c).trans (e5 a b c)).trans (e6 a (b+1) c)
      simpa [add_assoc,add_comm (1:V) a] using h.trans (ih (b+1))
  apply modelInduct
  · definability
  · intro b c; simpa using e0z 0 b c
  · intro a ih b c
    rcases zeroOrSucc b with rfl|⟨j,rfl⟩
    · have h := ((e0s a 0 c).trans (e1z a 0 c)).trans (e3 a 0 c)
      simpa [add_comm (1:V) a] using h.trans (inner c a (0+1))
    · have h := ((e0s a (j+1) c).trans (e1s a j c)).trans (e2 a j c)
      simpa only [cancelSub] using h.trans (ih j c)

theorem goalBlock
    (e0z : ∀ x y z : V, Reach (atPc 0 0 y z) (atPc 4 0 y z))
    (e0s : ∀ x y z : V, Reach (atPc 0 (x+1) y z) (atPc 1 x y z))
    (e1z : ∀ x y z : V, Reach (atPc 1 0 y z) (atPc 4 0 y z))
    (e1s : ∀ x y z : V, Reach (atPc 1 (x+1) y z) (atPc 2 x y z))
    (e2z : ∀ x y z : V, Reach (atPc 2 0 y z) (atPc 4 0 y z))
    (e2s : ∀ x y z : V, Reach (atPc 2 (x+1) y z) (atPc 3 x y z))
    (e3z : ∀ x y z : V, Reach (atPc 3 0 y z) (atPc 7 0 y z))
    (e3s : ∀ x y z : V, Reach (atPc 3 (x+1) y z) (atPc 4 x y z))
    (e4z : ∀ x y z : V, Reach (atPc 4 0 y z) (atPc 6 0 y z))
    (e4s : ∀ x y z : V, Reach (atPc 4 (x+1) y z) (atPc 5 x y z))
    (e5 : ∀ x y z : V, Reach (atPc 5 x y z) (atPc 4 x y z)) :
    ∀ x y z : V, Reach (atPc 0 x y z) (if x=3 then atPc 7 0 y z else atPc 6 0 y z) := by
  intro x y z
  have tail : ∀ a : V, Reach (atPc 4 a y z) (atPc 6 0 y z) := by
    apply modelInduct
    · definability
    · exact e4z 0 y z
    · intro a ih; exact ((e4s a y z).trans (e5 a y z)).trans ih
  rcases zeroOrSucc x with rfl|⟨a,rfl⟩
  · simpa using (e0z 0 y z).trans (tail 0)
  rcases zeroOrSucc a with rfl|⟨b,rfl⟩
  · simpa using ((e0s 0 y z).trans (e1z 0 y z)).trans (tail 0)
  rcases zeroOrSucc b with rfl|⟨c,rfl⟩
  · simpa [show (1:V)+1=2 by ring,show (2:V)≠3 by exact_mod_cast (show (2:Nat)≠3 by decide)] using (((e0s (0+1) y z).trans (e1s 0 y z)).trans (e2z 0 y z)).trans (tail 0)
  rcases zeroOrSucc c with rfl|⟨d,rfl⟩
  · simpa [show (1:V)+1+1=3 by ring] using (((e0s ((0+1)+1) y z).trans (e1s (0+1) y z)).trans (e2s 0 y z)).trans (e3z 0 y z)
  · have h := (((e0s (((d+1)+1)+1) y z).trans (e1s ((d+1)+1) y z)).trans (e2s (d+1) y z)).trans (e3s d y z)
    have ne : (((d+1)+1)+1)+1 ≠ 3 := by
      intro eq
      have lt : (3:V) < (((d+1)+1)+1)+1 := by
        have nn : (3:V)<4 := by exact_mod_cast (show (3:Nat)<4 by decide)
        have h := lt_of_lt_of_le nn (show (4:V)≤d+4 from le_add_self)
        have q : (((d+1)+1)+1)+1 = d+4 := by ring
        rw [q]; exact h
      exact (ne_of_lt lt) eq.symm
    simp only [ne,ite_false]
    exact h.trans (tail d)

end PA192.ModelSearch.Register181.Templates
#print axioms PA192.ModelSearch.Register181.Templates.pairBlock
