"""Replay startup, bind the literal register program, and optionally recheck the Lean kernel traces."""
from argparse import ArgumentParser
from gzip import decompress
from hashlib import sha256
from pathlib import Path
import csv
import json
import re
import shutil
import subprocess
import sys
import tempfile
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
TABLE = "82285467b36c5024038aeac32abd911d9db251143f98452b29cbbb2d2617e67c"
SOURCE = "ccef7921a6a9d784f4dcca6f79c74f5dc6b2db86cb235352a809f86134dcb838"
PA_ENDPOINTS = {
    "Direct181Frames": [
        "Direct181.Boot.blank_first_signed_frame",
        "Direct181.Boot.blank_signed_origin",
        "Direct181.Boot.blank_margin_frame",
    ],
    "Direct181PARefill": [
        "PA192.ModelSearch.Register181.Commands.refill0To24",
        "PA192.ModelSearch.Register181.Commands.reader24",
    ],
    "Direct181SourceIff": ["NF181PA.Reverse.sourceHalt_iff_pool"],
    "NF181PATapeKernel": ["NF181PA.Symbolic.tape_of_register_halt"],
    "NF181Exact": ["NFMachine181.halts_iff_nf_refutation"],
    "Direct181PATransfer": ["NF181PA.transfer_from_182", "NF181PA.transfer_to_182", "NF181PA.halting_equivalence"],
    "NF181PAInternalConsistency": ["NF181PA.internal_consistency"],
    "NF181PAIndependence": ["NF181PA.pa_independence", "NF181PA.true_value_independent"],
}

def check_pa_coverage(root, sites, expected_cases):
    physical = root / "physical"
    receipt = json.loads((physical / "pa-kernel-coverage.json").read_text())
    witness = physical / "pa-witnesses.csv"
    assert receipt["literal_machine_sha256"] == TABLE and receipt["source_sites_sha256"] == SOURCE
    assert receipt["witness_sha256"] == sha256(witness.read_bytes()).hexdigest()
    assert receipt["theorem"] == "NF181PA.Symbolic.literal_table_coverage"
    assert receipt["all_model_theorem"] == "NF181PA.Symbolic.tape_of_register_halt"
    assert set(receipt["axioms"]) == {"propext", "Classical.choice", "Quot.sound"}
    with witness.open() as stream:
        rows = list(csv.reader(stream))[1:]
    assert [int(row[0]) for row in rows] == list(range(receipt["source_addresses"])) == list(range(2971))
    assert len(receipt["shards"]) == receipt["checked_shards"] == 93
    cases = set()
    symbolic_steps = []
    for i, shard in enumerate(receipt["shards"]):
        source = root / "lean" / f"NF181PATapeCases{i:03}.lean"
        assert sha256(source.read_bytes()).hexdigest() == shard["generated_lean_sha256"]
        start, stop = shard["first"], shard["end_exclusive"]
        assert (start, stop) == (32 * i, min(32 * (i + 1), len(rows)))
        # Compare the arithmetic proof's branch arguments with the CSV and the
        # independently enumerated physical cases, including disabled branches.
        expected = []
        for row in rows[start:stop]:
            pc = int(row[0])
            for j, raw in enumerate(row[1:]):
                value = int(raw)
                if value:
                    cold, positive = j >= 2, j % 2 == 1
                    expected.append((str(pc), str(cold).lower(), str(positive).lower(), raw))
                    symbolic_steps.append(value % 4096)
                    zero_branch = sites[pc][1] == "CD" and not positive
                    cases.add((pc, cold, zero_branch))
        actual = re.findall(r": checkWitness (\d+) (false|true) (false|true) (\d+) = true", source.read_text())
        assert actual == expected, source.name
    assert cases == expected_cases and len(symbolic_steps) == receipt["enabled_branches"] == 7794
    assert sum(symbolic_steps) == receipt["symbolic_steps"] == 3963508
    assert max(symbolic_steps) == receipt["max_symbolic_steps"]

def verify(root, kernel=None, jobs=2):
    def digest(data):
        return sha256(data).hexdigest()
    for entry in (root / "SHA256SUMS").read_text().splitlines():
        expected, name = entry.split("  ", 1)
        assert digest((root / name).read_bytes()) == expected, name
    table = (root / "NF181.tm").read_bytes()
    source = (root / "source.sites.json").read_bytes()
    assert digest(table) == TABLE and digest(source) == SOURCE
    with ZipFile(root / "NF182_PA_verification.zip") as baseline:
        older = json.loads(baseline.read("source.sites.json"))
        old_table = baseline.read("NF182.tm").decode().splitlines()
    lean_literal = (root/"lean/Direct181Table.lean").read_text()
    match = re.search(r"def raw : List String := (\[.*?\])\s*theorem literal_exact", lean_literal, re.S)
    names = re.search(r"def names : Array String := #(\[.*?\])", lean_literal, re.S)
    starting_index = int(re.search(r"def start : State := (\d+)", lean_literal)[1])
    assert match and names and "".join(json.loads(match[1])) == table.decode().split("\n",1)[1]
    assert json.loads(names[1])[starting_index] == "k:64"
    subprocess.run([sys.executable,root/"physical/check_registers.py",root/"source.sites.json",root/"lean/NF181Literal.lean"],check=True)
    sites = json.loads(source)
    assert len(sites) == len(older) == 2971
    assert [(i,before,after) for i,(before,after) in enumerate(zip(older,sites)) if before != after] == [(4,["00011010","CI",8],["00011010","CI",7])]
    def read(lines):
        assert lines[0] == "#! start k:64"
        entries = {}
        for line in lines[1:]:
            q,b,w,d,z = line.split()
            assert (q,b) not in entries and b in ("0","1") and w in ("0","1") and d in ("R","L")
            entries[q,b] = w,d,z
        return entries
    old, new = read(old_table), read(table.decode().splitlines())
    assert set(old)-set(new) == {("d:51","0"),("d:51","1")}
    assert {k:new[k] for k in new if old[k]!=new[k]} == {("d:50","0"):("0","R","d:7"),("d:7","1"):("1","R","d:52")}
    reached = {"k:64"}
    while True:
        more = {new[q,b][2] for q in reached for b in ("0","1")} - {"halt"}
        if more <= reached: break
        reached |= more
    assert len(reached) == 181 and len(new) == 362
    assert [k for k,(_,_,z) in new.items() if z=="halt"] == [("k:302","1")]
    cert = json.loads(decompress((root/"physical/traces.json.gz").read_bytes()))
    expected = {(p,c,z) for p,(_,op,arg) in enumerate(sites) for c in (False,True)
                if not(c and op=="CD" and arg==0) for z in ((False,True) if op=="CD" else (False,))}
    cases = [(t["pc"],t["cold"],t["zero"]) for t in cert["traces"]]
    assert len(cases)==len(expected)==7794 and set(cases)==expected
    check_pa_coverage(root, sites, expected)
    receipt = json.loads((root/"physical/kernel.json").read_bytes())
    assert receipt["trace_sha256"] == digest((root/"physical/traces.json.gz").read_bytes())
    assert cert["table"] == receipt["table"] == TABLE and cert["source"] == receipt["source"] == SOURCE
    assert receipt["branch_theorems"] == len(expected)
    cursor = 0
    intervals = sorted(receipt["intervals"], key=lambda s: s["first_pc"])
    for item in intervals:
        assert item["first_pc"] == cursor
        assert cursor < item["past_last_pc"] <= len(sites)
        assert item["branches"] == sum(cursor <= pc < item["past_last_pc"] for pc, _, _ in expected)
        assert re.fullmatch(r"[0-9a-f]{64}", item["export_sha256"])
        assert "accepts the solution" in item["kernel"]
        cursor = item["past_last_pc"]
    assert cursor == len(sites)
    with tempfile.TemporaryDirectory() as temp:
        folder=Path(temp)
        (folder/"candidate.tm").write_bytes(table)
        (folder/"source.sites.json").write_bytes(source)
        subprocess.run([sys.executable,root/"physical/replay_blank.py",folder],check=True)
        if kernel:
            generated = folder / "kernel.json"
            chunk = intervals[0]["past_last_pc"]
            subprocess.run([sys.executable, root/"physical/checks/check_all.py", folder,
                            root/"physical/traces.json.gz", generated, "--chunk", str(chunk),
                            "--jobs", str(jobs), "--checker", kernel], check=True)
            replayed = json.loads(generated.read_bytes())
            keys = ("first_pc", "past_last_pc", "branches", "export_sha256")
            if [[row[k] for k in keys] for row in replayed["intervals"]] != [[row[k] for k in keys] for row in intervals]:
                raise ValueError("Regenerated kernel exports differ from the release receipt")
    print(f"{len(reached)} reachable working states, {len(sites)} register instructions, {len(cases)} physical branches.")

def rebuild_pa(root,jobs):
    folder=root/"pa-build"
    folder.mkdir(exist_ok=True)
    with ZipFile(root/"NF182_PA_verification.zip") as z:
        z.extractall(folder)
    for p in (root/"lean").rglob("*.lean"):
        dst=folder/"src"/p.relative_to(root/"lean")
        if dst.exists() and dst.read_bytes()!=p.read_bytes():
            raise RuntimeError(f"proof source collision at {dst}")
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,dst)
    subprocess.run(["lake","exe","cache","get"],cwd=folder,check=True)
    # The baseline driver audits the named declarations in each compilation
    # receipt, then imports the built modules and checks their axioms again.
    driver = "\n".join([
        "import json, sys",
        "from replay import EXPECT, main",
        "EXPECT.update(json.loads(sys.argv.pop(1)))",
        "main()",
    ])
    subprocess.run(
        ["lake", "env", sys.executable, "-c", driver, json.dumps(PA_ENDPOINTS),
         "-j", str(jobs), *PA_ENDPOINTS],
        cwd=folder, check=True,
    )

if __name__ == "__main__":
    p=ArgumentParser(description=__doc__)
    p.add_argument("--kernel",metavar="LEANCHECKER",help="rebuild the independent raw transition proofs")
    p.add_argument("--pa",action="store_true",help="rebuild the end-to-end proof with the pinned Lean and Lake dependencies")
    p.add_argument("-j","--jobs",type=int,default=2)
    args=p.parse_args()
    if args.jobs<1:p.error("jobs must be positive")
    verify(ROOT,args.kernel,args.jobs)
    if args.pa:rebuild_pa(ROOT,args.jobs)
