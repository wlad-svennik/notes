"""Replay the ordinary blank startup of the 181-state table using unbounded integer coordinates."""

import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path


TABLE_HASH = "82285467b36c5024038aeac32abd911d9db251143f98452b29cbbb2d2617e67c"
SOURCE_HASH = "ccef7921a6a9d784f4dcca6f79c74f5dc6b2db86cb235352a809f86134dcb838"
REGISTER_ORDER = (2, 8, 1, 4, 3, 7, 0, 5, 6)


@dataclass
class Frame:
    pc: int
    head: int
    header: int
    registers: list[int]
    spares: int

    def tape(self, source):
        marks = {self.head - 1, self.header}
        path = source[self.pc][0]
        marks.update(self.head + i for i, bit in enumerate(path) if bit == "1")
        cursor = self.header + 2
        lengths = [self.registers[i] + 2 for i in REGISTER_ORDER] + [1] * self.spares
        for length in lengths:
            assert length >= 1
            marks.update(range(cursor, cursor + length))
            cursor += length + 1
        return marks

    def advance(self, source, addresses):
        path, kind, operand = source[self.pc]

        def cut(word, bit):
            last = word.rindex(bit)
            return word[:last]

        if kind == "CI":
            self.registers[operand] += 1
            self.spares += 1
        elif kind == "CD":
            value = self.registers[operand]
            assert value >= 0
            if value == 0:
                assert not path.endswith("1")
                path = cut(path, "0")
            else:
                self.registers[operand] -= 1
                self.header += 1
        else:
            assert kind in ("CB", "CC")
            for _ in range(operand):
                path = cut(path, "1" if kind == "CC" else "0")
        if kind != "CC":
            if "0" in path:
                path = cut(path, "0") + "1"
            else:
                self.head -= 1
                path = ""
        while path not in addresses:
            path += "0"
        self.pc = addresses[path]


def replay(folder):
    table_bytes = (folder / "candidate.tm").read_bytes()
    source_bytes = (folder / "source.sites.json").read_bytes()
    assert sha256(table_bytes).hexdigest() == TABLE_HASH
    assert sha256(source_bytes).hexdigest() == SOURCE_HASH
    source = json.loads(source_bytes)
    addresses = {path: i for i, (path, _, _) in enumerate(source)}
    rows = table_bytes.decode().splitlines()
    assert rows[0] == "#! start k:64"
    table = {}
    for row in rows[1:]:
        state, bit, written, direction, target = row.split()
        key = state, int(bit)
        assert key not in table and direction in ("L", "R")
        table[key] = int(written), 1 if direction == "R" else -1, target
    assert len(table) == 362
    state, head, clock, tape = "k:64", 0, 0, set()

    def tick():
        nonlocal state, head, clock
        written, step, state = table[state, int(head in tape)]
        if written:
            tape.add(head)
        else:
            tape.discard(head)
        head += step
        clock += 1

    def matches(frame, expected):
        return state == "d:0" and head == frame.head and tape == expected

    for limit, frame in [
        (16439, Frame(38, -1, 29, [-1, 0, 0, 4, 0, 0, 0, 0, 0], 12)),
        (17319, Frame(40, -1, 31, [-1, 0, 0, 2, 0, 0, 0, 0, 0], 12)),
    ]:
        while clock < limit:
            tick()
        assert matches(frame, frame.tape(source))

    for _ in range(80):
        frame.advance(source, addresses)
        expected = frame.tape(source)
        while True:
            tick()
            assert clock <= 51111
            if matches(frame, expected):
                break

    assert clock == 51111
    assert frame == Frame(111, -1, 50, [-1, 0, 0, 2, 0, 0, 0, 1, 0], 32)
    print("Verified blank startup to PC38 at 16,439 and PC40 at 17,319.")
    print("Verified 80 consecutive register steps from PC40 to PC111 at 51,111.")
    print("PC111 has head -1, gap 51 and 32 zero spares.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    replay(parser.parse_args().folder)
