#!/usr/bin/env python3
"""Compare the published register tree to the exact Lean instruction literal."""
import argparse
from bisect import bisect_left
from hashlib import sha256
import json
from pathlib import Path
import re


SOURCE_HASH = "ccef7921a6a9d784f4dcca6f79c74f5dc6b2db86cb235352a809f86134dcb838"
HALT = 4095


def source_instructions(data):
    rows = json.loads(data)
    paths = [path for path, _, _ in rows]
    if len(rows) != 2971 or paths != sorted(set(paths)):
        raise ValueError("expected the 2971 leaves in ordinal order")

    def jump(path, side, count):
        # On the selected ancestor, CB exits the subtree and CC re-enters it.
        for i in range(len(path) - 1, -1, -1):
            if path[i] == side:
                count -= 1
                if count == 0:
                    prefix = path[:i]
                    key = prefix + "2" if side == "0" else prefix
                    return bisect_left(paths, key) % len(rows)
        raise ValueError(f"unbound {side}-edge from {path}")

    instructions = []
    gates = []
    for pc, (path, op, arg) in enumerate(rows):
        nxt = (pc + 1) % len(rows)
        if op == "CI":
            instruction = ("inc", arg, nxt)
        elif op == "CD":
            zero = jump(path, "0", 1)
            if path.endswith("1"):
                # The signed CD's zero arm halts. Keep the underlying tree edge
                # for the check below; Src181Run.decoded assigns ordinal 4095.
                gates.append((pc, arg, zero, nxt))
                instruction = ("decHalt", arg, nxt)
            else:
                instruction = ("dec", arg, zero, nxt)
        elif op in ("CB", "CC"):
            instruction = ("jump", jump(path, "0" if op == "CB" else "1", arg))
        else:
            raise ValueError(f"unknown opcode {op!r} at PC {pc}")
        instructions.append(instruction)
    if gates != [(2954, 5, 2957, 2955)]:
        raise ValueError(f"unexpected signed zero branches: {gates}")
    return instructions


def lean_instructions(text):
    # Read the named lists in the order used by their flatten definitions.
    chunks = dict(re.findall(
        r"^def ((?:pre|mid|post)\d+) : List Instruction := \[([^\]]*)\]$",
        text, re.MULTILINE,
    ))
    instructions = []
    for section, expected_size in [("pre", 40), ("mid", 2809), ("post", 122)]:
        match = re.search(
            rf"^def {section} : List Instruction := \[([^\]]+)\]\.flatten$",
            text, re.MULTILINE,
        )
        if match is None:
            raise ValueError(f"missing definition of {section}")
        start = len(instructions)
        for name in match[1].split(","):
            for expression in chunks.pop(name.strip()).split(","):
                instr = re.fullmatch(r"\.(inc|dec|decHalt|jump)\s+([\d\s]+)", expression.strip())
                if instr is None:
                    raise ValueError(f"invalid instruction {expression!r}")
                instructions.append((instr[1], *map(int, instr[2].split())))
        if len(instructions) - start != expected_size:
            raise ValueError(f"wrong length for {section}")
    if chunks:
        raise ValueError(f"unused Lean chunks: {sorted(chunks)}")

    dispatch = re.search(r"^def program \(pc : Nat\) : Instruction :=\n([^\n]+)", text, re.MULTILINE)
    expected = "if pc < 40 then pre.getD pc .halt else if pc < 2849 then mid.getD (pc-40) .halt else post.getD (pc-2849) (.jump pc)"
    if dispatch is None or " ".join(dispatch[1].split()) != expected:
        raise ValueError("unexpected Lean address dispatch")
    return instructions


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="published source.sites.json")
    parser.add_argument("literal", type=Path, help="NF181Literal.lean")
    args = parser.parse_args()
    data = args.source.read_bytes()
    if sha256(data).hexdigest() != SOURCE_HASH:
        raise ValueError("source.sites.json does not match the published NF181 digest")
    source = source_instructions(data)
    literal = lean_instructions(args.literal.read_text())
    for pc, (wanted, found) in enumerate(zip(source, literal, strict=True)):
        if wanted != found:
            raise ValueError(f"PC {pc}: source gives {wanted!r}, Lean has {found!r}")
    print(json.dumps({"register_instructions": len(literal), "source_sha256": SOURCE_HASH,
                      "signed_gate": {"pc": 2954, "register": 5, "tree_zero": 2957,
                                      "halt_ordinal": HALT, "positive": 2955}}))


if __name__ == "__main__":
    main()
