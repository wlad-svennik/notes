"""Run 48 deterministic whole-tape examples at every instruction address."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import os
import subprocess

here = Path(__file__).resolve().parent
root = here.parent
header, *rows = (root / "NF181.tm").read_text().splitlines()
states = sorted({row.split()[0] for row in rows})
indices = {state: i for i, state in enumerate([*states, "halt"])}
arcs = {}
for row in rows:
    q, symbol, written, move, target = row.split()
    arcs[q, int(symbol)] = int(written), (1 if move == "R" else -1), indices[target]
with TemporaryDirectory() as tmp:
    folder = Path(tmp)
    program = folder / "source.txt"
    table = folder / "tape.txt"
    program.write_text("".join(f"{path} {op} {r}\n" for path, op, r in json.loads((root / "source.sites.json").read_text())))
    with table.open("w") as f:
        print(len(states), indices[header.split()[-1]], indices["d:0"], indices["k:302"], file=f)
        for q in states:
            for symbol in (0, 1):
                print(*arcs[q, symbol], file=f)
    binary = folder / "replay"
    subprocess.run([os.environ.get("CXX", "c++"), "-std=c++17", "-O3", here / "replay_examples.cpp", "-o", binary], check=True)
    result = subprocess.check_output([binary, program, table], text=True).strip()
    assert result == "142592 full successor tapes, 16 halts, 95344106 literal transitions", result
    print(result)
