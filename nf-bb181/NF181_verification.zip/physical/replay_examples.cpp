#include "frame.hpp"
int main(int argc,char **argv){
    Source source(argv[1]); Machine machine(argv[2]);
    std::mt19937 random(181);
    long long ticks=0;
    int live_cases = 0;
    int halt_cases = 0;
    for(int pc=0;pc<static_cast<int>(source.rows.size());++pc){
        auto row=source.rows.at(pc);
        for(int variant=0;variant<48;++variant){
            Frame frame{pc,center,center+51+int(random()%34),{},vector<int>(24+random()%20,0)};
            for(int &value:frame.regs)value=random()%14;
            if(variant%8==0)frame.regs.fill(0);
            if(variant%8==1)frame.regs.fill(1);
            if(row.op=="CD")frame.regs[row.a]=variant%3==0?0:1+random()%9;
            if(variant%2 && !(row.op=="CD" && row.a==0))frame.regs[0]=-1;
            Run run{machine.d0,frame.h,encode(source,frame)};
            ticks+=complete(source,machine,run,frame);
            if (run.q == machine.n) ++halt_cases;
            else ++live_cases;
        }
    }
    std::cout << live_cases << " full successor tapes, " << halt_cases << " halts, "
              << ticks << " literal transitions\n";
}
