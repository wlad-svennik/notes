"""Rebuild all non-Mathlib modules from the pinned sources in this directory."""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
IMPORT = re.compile(r'^\s*(?:(?:public|meta|private)\s+)*import\s+(?:all\s+)?([\w.]+)', re.M)
AUDIT = re.compile(r"'([^']+)' depends on axioms: \[([^\]]*)\]",re.S)
AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}
TARGETS = ['C193.counting_model_of_nonderivability', 'NF193.Upper.Splice.Operations.chart',
           'C193.proves_2165', 'C193.old_2165_implies_goal', 'ScalarFold.yields_same_theorems']

def paths(module):
    return Path(*module.split('.'))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', default='lean')
    parser.add_argument('--build',type=Path, default=ROOT/'build')
    parser.add_argument('--jobs', type=int, default=2)
    args=parser.parse_args()
    if args.jobs<1:parser.error('--jobs must be positive')
    exe=shutil.which(args.lean)
    if exe is None:parser.error('Lean was not found')
    version=subprocess.check_output([exe,'--version'],text=True).strip()
    if '4.35.0' not in version:parser.error('Expected Lean 4.35.0')
    pins=json.loads((ROOT/'source-sha256.json').read_text())
    external=set(json.loads((ROOT/'external-imports.json').read_text()))
    src=ROOT/'src';build=args.build.resolve();build.mkdir(exist_ok=True,parents=True)
    graph={}
    for module,h in pins.items():
        f=src/paths(module).with_suffix('.lean');v=f.read_bytes()
        if hashlib.sha256(v).hexdigest()!=h:raise ValueError(f'Mismatch in {module}')
        deps=set(IMPORT.findall(v.decode()))
        if deps - external - pins.keys():raise ValueError(f'Unresolved imports in {module}: {deps-external-pins.keys()}')
        graph[module]=deps & pins.keys()
    env=dict(os.environ,LEAN_PATH=os.pathsep.join([str(build),os.getenv('LEAN_PATH','')]))
    def compile_one(module):
        f=paths(module); o=build/f.with_suffix('.olean');o.parent.mkdir(exist_ok=True,parents=True)
        log=build/(module+'.log')
        with log.open('w')as handle:
            proc=subprocess.run([exe,'-j','1','-s','131072','-o',str(o),str(f.with_suffix('.lean'))],cwd=src,env=env,stdout=handle,stderr=subprocess.STDOUT)
        s=log.read_text()
        if proc.returncode or 'uses \'sorry\'' in s or 'sorryAx' in s:raise RuntimeError(f'{module} failed\n{s[-2000:]}')
        return {n:[v.strip() for v in j.split(',')]for n,j in AUDIT.findall(s)}
    todo=set(graph); running={};checks={}
    with concurrent.futures.ThreadPoolExecutor(args.jobs) as workers:
        while todo:
            ready=sorted(m for m in todo-running.keys() if not graph[m]&todo)
            for m in ready[:args.jobs-len(running)]:running[m]=workers.submit(compile_one,m)
            if not running:raise ValueError('Cyclic imports')
            done,_=concurrent.futures.wait(running.values(),return_when=concurrent.futures.FIRST_COMPLETED)
            for m,f in list(running.items()):
                if f in done:
                    checks.update(f.result());del running[m];todo.remove(m);print(f'{len(pins)-len(todo)}/{len(pins)} {m}',flush=True)
    for t in TARGETS:
        if t not in checks or not set(checks[t])<=AXIOMS:raise ValueError(f'Unexpected assumptions for {t}')
    (build/'receipt.json').write_text(json.dumps({'lean':version,'modules':len(pins),'audits':checks},indent=2)+'\n')
    print('Verified all target audits.',flush=True)
if __name__=='__main__':main()
