# J-point calibration companion

The 192- and 193-state J-point tables share the numerical calculus in this archive. `Calibration.md` gives its axioms, the explicit comparisons with the older raw calculus, the model-strength argument, and the scope of each proof. The computational half, including the exact transition table, is in `NF_AxCount_Jpoint_192_Verification.zip` or the corresponding 193-state archive.

## Mathematical endpoints

| Theorem | Conclusion |
|---|---|
| `C193.not_deriv_iff_ground_model` and `C193.ground_model_iff_chart` | The failure to derive goal 3 is equivalent to the existence of a J-point chart. |
| `NF193.Upper.Splice.Operations.chart` | The prescribed internal successor rows, characteristic rows, fixed-point data, and final abstractor of the given splice realize a J-point chart. |
| `C193.counting_model_of_nonderivability` | Nonderivability constructs an NFU model with Dedekind Infinity and full Rosser Counting on its own natural numbers. |
| `Counting192J.nonhalting_implies_counting_model` | The same model conclusion follows directly from nonhalting of the indicated blank 192-state machine. |
| `ScalarFold.yields_same_theorems` | The optional fresh-variable rewrite of the older Counting axiom preserves every old numerical conclusion. |

The two pairs of explicit old/J-point separation theorems are also supplied. The pure-NF chart constructor uses the mathematical graph-prescription argument, and the calibration through Cℶ uses the v15 manuscript claims of R. Gutin and E. Glazer. The manuscript excerpt identifies their status and metatheory.

## Replay the mathematical proofs

Use Python 3 and Lean 4.35.0 (`eb6cafb7290e8bd5f2937522d8d804f58f02bafc`). The archive bundles every project, NF/FunctionNF/NFU-interpretation and Foundation source on the replay path. `source-sha256.json` identifies every module by its exact file contents. Mathlib is pinned to `56a005855ea17e0b0958f73ec801ae140b0a1679`, with all package revisions in `lake-manifest.json`. `external-imports.json` lists the external modules needed from Lean and the pinned Mathlib environment. The Foundation sources retain their notices and the Apache 2.0 license under `references/`.

From the extracted directory in a configured Lean/Elan environment, run

```sh
lake exe cache get
lake env python3 replay.py --jobs 3
```

Lake obtains package sources and cached Mathlib objects. A matching existing Mathlib environment can instead run `python3 replay.py --lean /path/to/lean --jobs 3`, with its package object directories exported in `LEAN_PATH`. `replay.py` checks all bundled source hashes, rebuilds the 121 modules into `build`, records the theorem audits in `build/receipt.json`, and rejects a proof with `sorry`. The mathematical endpoints use at most `propext`, `Classical.choice` and `Quot.sound`.

## Link the literal 192-state machine

First run the 192-state machine archive’s normal replay to its absolute build directory, called `MACHINE_BUILD` below. Keep the companion’s `build` directory from the preceding step. In a shell at the root of this companion, run

```sh
COMPANION_BUILD="$PWD/build"
MACHINE_BUILD=/absolute/path/to/the/192-state/lean-build
lake env sh -c 'LEAN_PATH="$1:$2:$LEAN_PATH" lean -o "$1/Counting192JCalibration.olean" machine/Counting192JCalibration.lean' sh "$COMPANION_BUILD" "$MACHINE_BUILD"
```

The file `machine/Counting192JCalibration.lean` composes the verified machine endpoint and the NFU model theorem. The complete audit includes the finite native-decide checks used by the machine archive. The purely mathematical model construction contributes only the standard Lean axioms listed above.

## Included verification receipts

The files in `receipts/` record the clean 121-module replay and the axiom audit of the composed machine theorem. The verified 192-state table has SHA-256 `34698929dc83de04608eabd889ca898f34a23800c483b03386922ca51e8f25ee`. `SHA256SUMS` identifies the checksums of the companion files.
