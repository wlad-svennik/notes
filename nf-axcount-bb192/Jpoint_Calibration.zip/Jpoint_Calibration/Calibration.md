# The J-point calculus in the 192- and 193-state tables

The blank tape enumerates commands that build precisely the derivable natural-number formula codes. The primitive term is `J = 0`, application is written by juxtaposition, the tester is `Q = JJ = 1`, and the abstractor is `B = H(Q,J) = 4`. The designated halt goal is the equation `Q = J`, with formula code 3. Write `Kx = H(x,x)`.

The fixed-point test returns Q for success and J for failure. The abstraction and constant laws are `Bfgx = f(Kx)(gx)` and `(Kx)y = x`. The additional Counting law is **(J(Jx))y = Jx for all x and y**. The calculus also includes application congruence in each argument, Euclidean equality, the extensionality-witness schema and the dominated instances of Łukasiewicz’s implication axiom. H is a syntactic constructor. Its diagonal K has a derived substitution law.

## Exact algebraic endpoint

In a chart, equality means actual equality of elements. Application is extensional, the two test outcomes are distinct, and QB ≠ JB. The last requirement explains why B can occupy its designated separating-witness slot. The Lean theorems `C193.not_deriv_iff_ground_model` and `C193.ground_model_iff_chart` identify nonderivability of formula 3 with existence of a chart. The forward map takes the quotient of numerical term codes. The reverse map chooses Kx on the diagonal, B in the distinguished slot, and a separating argument for each other pair of unequal elements.

The old 199-state calculus gives the same numerals different denotations. Formula 2165, a Counting instance with x = 0 and y = 1, witnesses the difference. The new calculus proves it. An old proof of it would prove the old goal. The reverse separation uses 10,782,656,132,388, an instance of the old positive tester schema. The old calculus derives it, while any J-point proof of it yields the J-point goal. `C193.proves_2165`, `C193.old_2165_implies_goal`, `C193.old_proves_positive_example` and `C193.jpoint_positive_example_implies_goal` formalize both witnesses. Consequently, if both machines run forever, each one finds a numerical theorem the other cannot derive.

## Counting lower bound

Let D be the range of J. For a ∈ D, the Counting law and extensionality give Ja = Ka. Evaluation at J recovers a from Ja. Hence J restricts to a represented injection D → D. The tester Q = JJ belongs to D. It is nonconstant because testing KQ and KJ at Q gives the distinct values Q and J. Every Ja for a ∈ D is constant. Consequently Q is a point missing from the image of this injection.

In the interpreted FunctionNF model, the homogeneous graph a ↦ {(Ja)J} restricts to the singleton graph on D. Thus D is strongly Cantorian. The supplied arbitrary-Boolean FunctionNF interpretation, the proper injection and the represented singleton graph give a model of **NFU with Dedekind Infinity and full Rosser Counting**, including T(n) = n for every natural number of that model. `C193.counting_model_of_nonderivability` formalizes this implication using the original interpretation libraries.

## Pure NF with Counting supplies a chart

This upper construction uses the full FunctionNF graph chart for pure NF, the strongly Cantorian internal natural numbers supplied by AxCount, homogeneous label slices of full size, and the usual Cantor–Bernstein completion of a partial labelling. The Lean theorem `NF193.Upper.Splice.Operations.chart` checks the algebraic construction from the represented rows and the final chart’s constant and abstraction operations. Its chain index is arbitrary and can be the naturals of a nonstandard model.

Choose distinct reserved labels Q and J, and an injective homogeneous family C(w) for all sets w in a slice disjoint from those labels. Prescribe the row of C(w) to send x to Q if x ∈ w, and to J otherwise. Choose a strongly Cantorian chain of distinct labels aₙ, indexed by the internal naturals, with a₀ = Q and a₁ = C(V). Choose the remaining labels in a spare slice. Prescribe the row of aₙ₊₁ to be the constant at aₙ. At n = 0 this agrees with the characteristic row prescribed for C(V). All subsequent constant rows take values outside {Q,J}. Strong Cantorianity of the indexing family gives the represented graph of the prescriptions at the required types.

Give Q and J distinct finite-range, fixed-point-free placeholder rows, each with a value outside {Q,J}. For example, choose two disjoint fresh pairs and, for each pair b,c, send b to c and every other argument to b. The assigned rows are distinct. A fresh label slice remains on the domain side. On the row side, characteristic functions on two new output markers give a homogeneous full family disjoint from the prescriptions after discarding the constant and finitely many exceptional rows. The full-chart completion extends the assignment to an extensional full labelling e.

In the old labelling form the represented tester row U(f) = C(Fix(e(f))). It has no fixed point. If U(f) = f = C(w), then J ∈ w is equivalent to e(C(w))(J) = J, which in turn is equivalent to J ∉ w. Its range contains the predicates of every singleton, by taking f to be constant. It differs from each reserved characteristic, constant and placeholder row.

The represented successor row F sends aₙ to aₙ₊₁, with value Q outside the chain. Its graph is represented by the strongly Cantorian chain and this default branch. It has no fixed point and its range is infinite. It differs from U at Q, where F(Q) = C(V) and U(Q) = C(∅). Thus the old labels of U and F and the placeholders Q and J are four distinct labels outside the positive-index chain and the characteristic labels.

Swap the labels of Q and U, and swap the labels of J and F. Every relabelled row has empty fixed-point set, so the swaps preserve the fixed-point set at every label. Each characteristic row stays fixed. In the new application Q realizes the tester, J realizes the successor, and JJ = Q. Each Jx lies on the chain. Evaluating its successor at any argument returns it, proving the pointwise Counting law.

Let B be the native abstraction combinator of this final chart. It fixes K²v for every v, whereas Q has no fixed point. The identity B(K²v) = K²v also rules out B = Ka, since that would imply a a a = v for every v. Hence B lies outside the chain and JB = Q. The value QB is a characteristic label distinct from Q, giving QB ≠ JB. The remaining separating witnesses may now be chosen as usual.

## Consistency comparison with the original machine

Ran Gutin’s supplied *Choice and Consistency Strength in NF and NFU*, v15, provides the mathematical comparison. Proposition 17.11 (p. 89) and Proposition 17.13 (p. 91) identify the consistency strength of bare NFU with Dedekind Infinity and AxCount with that of Cℶ over PRA. Theorem 21.1 (p. 127), first row, identifies the consistency strength of pure NF + AxCount with the same Cℶ. Here Cℶ is Zermelo set theory with Choice plus, for each standard natural n, the existence of ℶ_{ℶ_n}. The manuscript presents these as written research claims, self-audited and awaiting independent verification. See `references/Counting_comparisons_v15_excerpt.pdf`.

Taking those comparisons and the pure-NF chart construction above, the two implications close. Consistency of pure NF + AxCount supplies a model and hence a J-point chart, which makes the machine run forever. Conversely a nonhalting J-point table yields the displayed NFU model, and therefore consistency of the bare NFU Counting theory. The two draft comparisons give consistency of pure NF + AxCount. With the original machine’s chart calibration, this also identifies their nonhalting conditions at the level of consistency strength. The closed equations exhibited above continue to distinguish their numeral-level proof sets.

The Lean companion certifies the abstract-chart equivalence and the lower model, and it certifies the final algebraic splice in the upper construction from its displayed hypotheses. The graph-prescription construction in pure NF and the two PRA comparisons use the mathematical arguments described above. No axiom-preserving direct interpretation from an arbitrary J-point chart to the old chart is used in this deduction.
