module
public import NumericalEmitterCode

@[expose] public section

/-! The small reusable arithmetic blocks and their contracts, adapted from the earlier NF210 register proof. In seq188 this machine increments register 7 before register 6. Neither order changes the simultaneous-copy result. -/

set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

namespace NF192.Emitter.Literal

def seq196 : Code := .seq (.inc 8) (.inc 6)
def seq195 : Code := .seq (seq196) (.cont 2)
def seq194 : Code := .seq (.dec 0) (seq195)
def seq204 : Code := .seq (.inc 0) (.cont 2)
def seq203 : Code := .seq (.dec 6) (seq204)
def seq138 : Code := .seq (.dec 6) (.br 1)
def seq185 : Code := .seq (.inc 6) (.cont 2)
def seq211 : Code := .seq (.dec 7) (seq185)
def seq137 : Code := .seq (seq138) (seq211)
def seq155 : Code := .seq (.inc 7) (seq137)
def seq154 : Code := .seq (seq155) (.cont 2)
def seq115 : Code := .seq (.dec 8) (seq154)
def seq210 : Code := .seq (.inc 8) (.cont 2)
def seq209 : Code := .seq (.dec 7) (seq210)
def seq158 : Code := .seq (seq115) (seq209)
def seq202 : Code := .seq (.inc 3) (.cont 2)
def seq201 : Code := .seq (.dec 6) (seq202)
def seq206 : Code := .seq (.inc 4) (.cont 2)
def seq205 : Code := .seq (.dec 6) (seq206)
def seq175 : Code := .seq (seq158) (seq205)
def seq191 : Code := .seq (.inc 5) (.cont 2)
def seq207 : Code := .seq (.dec 6) (seq191)
def seq176 : Code := .seq (seq158) (seq207)
def seq216 : Code := .seq (.dec 1) (seq185)
def seq186 : Code := .seq (.inc 1) (.cont 2)
def seq217 : Code := .seq (.dec 2) (seq186)
def seq188 : Code := .seq (.inc 7) (.inc 6)
def seq187 : Code := .seq (seq188) (.cont 2)
def seq215 : Code := .seq (.dec 1) (seq187)
def seq208 : Code := .seq (.dec 6) (seq186)
def seq165 : Code := .seq (.inc 7) (seq208)
def seq164 : Code := .seq (seq165) (.cont 3)
def seq163 : Code := .seq (.dec 6) (seq164)
def seq162 : Code := .seq (seq215) (seq163)
def seq213 : Code := .seq (.inc 2) (.cont 2)
def seq212 : Code := .seq (.dec 7) (seq213)
def seq173 : Code := .seq (seq162) (seq212)
def seq172 : Code := .seq (seq217) (seq173)
def seq171 : Code := .seq (seq216) (seq172)
def seq190 : Code := .seq (.inc 6) (.inc 1)
def seq189 : Code := .seq (seq190) (.cont 2)
def seq193 : Code := .seq (.dec 3) (seq189)
def seq169 : Code := .seq (seq193) (seq201)
def seq168 : Code := .seq (seq171) (seq169)
def seq198 : Code := .seq (.dec 4) (seq189)
def seq167 : Code := .seq (seq198) (seq205)
def seq166 : Code := .seq (seq171) (seq167)
def seq116 : Code := .seq (.dec 2) (seq154)
def seq160 : Code := .seq (seq116) (seq212)
def seq159 : Code := .seq (.inc 1) (.inc 1)
def seq220 : Code := .seq (seq159) (.cont 2)
def seq117 : Code := .seq (.dec 7) (seq220)
def seq120 : Code := .seq (seq162) (seq117)
def seq119 : Code := .seq (seq160) (seq120)
def seq200 : Code := .seq (.dec 5) (seq189)
def seq122 : Code := .seq (seq200) (seq207)
def seq121 : Code := .seq (seq171) (seq122)
def seq223 : Code := .seq (.dec 3) (.cont 1)
def seq224 : Code := .seq (.dec 4) (.cont 1)
def seq199 : Code := .seq (.dec 5) (.cont 1)
def seq180 : Code := .seq (seq119) (seq159)
def seq214 : Code := .seq (.dec 1) (.cont 1)

end NF192.Emitter.Literal

namespace NF192.Emitter

def clearCode (r : Register) : Code := .seq (.dec r) (.cont 1)

def transferCode (r q : Register) : Code := .seq (.dec r) (.seq (.inc q) (.cont 2))

def copyCode (r q j : Register) : Code :=
  .seq (.dec r) (.seq (.seq (.inc q) (.inc j)) (.cont 2))

theorem clear_eval (r : Register) (s : Registers) :
    Eval (clearCode r) s .normal (s.set r 0) := by
  generalize hs : s r = n
  induction n generalizing s with
  | zero =>
      have he := Eval.seq_br_left (b := .cont 1) (Eval.dec_zero r s hs)
      have hz : s.set r 0 = s := by simpa only [hs] using Registers.set_self s r
      simpa only [clearCode,hz] using he
  | succ n ih =>
      have ha := Eval.dec_pos r s (by omega)
      have hb := Eval.cont 1 (s.set r (s r - 1))
      have hc := ih (s.set r (s r - 1)) (by simp [hs])
      simpa only [clearCode,Registers.set_set] using Eval.seq_loop ha hb hc

theorem transfer_eval (r q : Register) (hne : r ≠ q) (s : Registers) :
    Eval (transferCode r q) s .normal ((s.set r 0).add q (s r)) := by
  generalize hs : s r = n
  induction n generalizing s with
  | zero =>
      have he := Eval.seq_br_left (b := .seq (.inc q) (.cont 2)) (Eval.dec_zero r s hs)
      have hz : s.set r 0 = s := by simpa only [hs] using Registers.set_self s r
      simpa only [transferCode,hz,Registers.add_zero] using he
  | succ n ih =>
      let t := (s.set r n).add q 1
      have ha : Eval (.dec r) s .normal (s.set r n) := by
        simpa only [hs,Nat.add_sub_cancel] using Eval.dec_pos r s (by omega)
      have hb : Eval (.seq (.inc q) (.cont 2)) (s.set r n) (.cont 1) t :=
        Eval.seq_cont_right_more (n := 0) (Eval.inc q _) (Eval.cont 2 _)
      have ht : t r = n := by simp [t,Registers.add,hne]
      have hc := ih t ht
      have he : (t.set r 0).add q n = (s.set r 0).add q (n+1) := by
        funext j
        by_cases hr : j = r
        · subst j
          simp [t,Registers.set,Registers.add,hne]
        · by_cases hq : j = q
          · subst j
            simp [t,Registers.set,Registers.add,Ne.symm hne]
            omega
          · simp [t,Registers.set,Registers.add,hr,hq,Ne.symm hne]
      rw [he] at hc
      exact Eval.seq_loop ha hb hc

theorem copy_eval (r q j : Register) (hrq : r ≠ q) (hrj : r ≠ j) (s : Registers) :
    Eval (copyCode r q j) s .normal (((s.set r 0).add q (s r)).add j (s r)) := by
  generalize hs : s r = n
  induction n generalizing s with
  | zero =>
      have he := Eval.seq_br_left
        (b := .seq (.seq (.inc q) (.inc j)) (.cont 2)) (Eval.dec_zero r s hs)
      have hz : s.set r 0 = s := by simpa only [hs] using Registers.set_self s r
      simpa only [copyCode,hz,Registers.add_zero] using he
  | succ n ih =>
      let t := ((s.set r n).add q 1).add j 1
      have ha : Eval (.dec r) s .normal (s.set r n) := by
        simpa only [hs,Nat.add_sub_cancel] using Eval.dec_pos r s (by omega)
      have hb : Eval (.seq (.seq (.inc q) (.inc j)) (.cont 2))
          (s.set r n) (.cont 1) t :=
        Eval.seq_cont_right_more (n := 0)
          (Eval.seq_normal (Eval.inc q _) (Eval.inc j _)) (Eval.cont 2 _)
      have ht : t r = n := by simp [t,Registers.add,hrq,hrj]
      have hc := ih t ht
      have he : ((t.set r 0).add q n).add j n =
          ((s.set r 0).add q (n+1)).add j (n+1) := by
        funext k
        by_cases hqj : q = j
        · subst j
          by_cases hk : k = r
          · subst k
            simp [t,Registers.set,Registers.add,hrq]
          · by_cases hq : k = q
            · subst k
              simp [t,Registers.set,Registers.add,Ne.symm hrq]
              omega
            · simp [t,Registers.set,Registers.add,hk,hq,Ne.symm hrq]
        · by_cases hk : k = r
          · subst k
            simp [t,Registers.set,Registers.add,hrq,hrj]
          · by_cases hq : k = q
            · subst k
              simp [t,Registers.set,Registers.add,hqj,Ne.symm hrq]
              omega
            · by_cases hj : k = j
              · subst k
                simp [t,Registers.set,Registers.add,Ne.symm hqj,Ne.symm hrj]
                omega
              · simp [t,Registers.set,Registers.add,hk,hq,hj,Ne.symm hrq]
      rw [he] at hc
      exact Eval.seq_loop ha hb hc

/-- A convenient named order for symbolic register contracts. -/
def Registers.mk9 (n t s c d h a b p : Nat) : Registers := fun r =>
  match r.val with
  | 0 => n | 1 => t | 2 => s | 3 => c | 4 => d
  | 5 => h | 6 => a | 7 => b | _ => p

theorem register_cases (r : Register) :
    r = 0 ∨ r = 1 ∨ r = 2 ∨ r = 3 ∨ r = 4 ∨ r = 5 ∨ r = 6 ∨ r = 7 ∨ r = 8 := by
  simp only [Fin.ext_iff]
  omega

end NF192.Emitter

namespace NF192.Emitter

open Registers

@[simp] theorem mk9_get_0 (n t s c d h a b p : Nat) :
    mk9 n t s c d h a b p 0 = n := rfl

@[simp] theorem mk9_set_0 (n t s c d h a b p value : Nat) :
    (mk9 n t s c d h a b p).set 0 value = mk9 value t s c d h a b p := by
  funext r
  rcases register_cases r with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

@[simp] theorem mk9_get_1 (n t s c d h a b p : Nat) :
    mk9 n t s c d h a b p 1 = t := rfl

@[simp] theorem mk9_set_1 (n t s c d h a b p value : Nat) :
    (mk9 n t s c d h a b p).set 1 value = mk9 n value s c d h a b p := by
  funext r
  rcases register_cases r with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

@[simp] theorem mk9_get_2 (n t s c d h a b p : Nat) :
    mk9 n t s c d h a b p 2 = s := rfl

@[simp] theorem mk9_set_2 (n t s c d h a b p value : Nat) :
    (mk9 n t s c d h a b p).set 2 value = mk9 n t value c d h a b p := by
  funext r
  rcases register_cases r with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

@[simp] theorem mk9_get_3 (n t s c d h a b p : Nat) :
    mk9 n t s c d h a b p 3 = c := rfl

@[simp] theorem mk9_set_3 (n t s c d h a b p value : Nat) :
    (mk9 n t s c d h a b p).set 3 value = mk9 n t s value d h a b p := by
  funext r
  rcases register_cases r with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

@[simp] theorem mk9_get_4 (n t s c d h a b p : Nat) :
    mk9 n t s c d h a b p 4 = d := rfl

@[simp] theorem mk9_set_4 (n t s c d h a b p value : Nat) :
    (mk9 n t s c d h a b p).set 4 value = mk9 n t s c value h a b p := by
  funext r
  rcases register_cases r with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

@[simp] theorem mk9_get_5 (n t s c d h a b p : Nat) :
    mk9 n t s c d h a b p 5 = h := rfl

@[simp] theorem mk9_set_5 (n t s c d h a b p value : Nat) :
    (mk9 n t s c d h a b p).set 5 value = mk9 n t s c d value a b p := by
  funext r
  rcases register_cases r with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

@[simp] theorem mk9_get_6 (n t s c d h a b p : Nat) :
    mk9 n t s c d h a b p 6 = a := rfl

@[simp] theorem mk9_set_6 (n t s c d h a b p value : Nat) :
    (mk9 n t s c d h a b p).set 6 value = mk9 n t s c d h value b p := by
  funext r
  rcases register_cases r with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

@[simp] theorem mk9_get_7 (n t s c d h a b p : Nat) :
    mk9 n t s c d h a b p 7 = b := rfl

@[simp] theorem mk9_set_7 (n t s c d h a b p value : Nat) :
    (mk9 n t s c d h a b p).set 7 value = mk9 n t s c d h a value p := by
  funext r
  rcases register_cases r with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

@[simp] theorem mk9_get_8 (n t s c d h a b p : Nat) :
    mk9 n t s c d h a b p 8 = p := rfl

@[simp] theorem mk9_set_8 (n t s c d h a b p value : Nat) :
    (mk9 n t s c d h a b p).set 8 value = mk9 n t s c d h a b value := by
  funext r
  rcases register_cases r with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl

theorem seq199_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq199 (mk9 n t s c d h a b p) .normal (mk9 n t s c d 0 a b p) := by
  change Eval (clearCode 5) _ _ _
  simpa [Registers.add] using clear_eval 5  (mk9 n t s c d h a b p)

theorem seq214_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq214 (mk9 n t s c d h a b p) .normal (mk9 n 0 s c d h a b p) := by
  change Eval (clearCode 1) _ _ _
  simpa [Registers.add] using clear_eval 1  (mk9 n t s c d h a b p)

theorem seq223_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq223 (mk9 n t s c d h a b p) .normal (mk9 n t s 0 d h a b p) := by
  change Eval (clearCode 3) _ _ _
  simpa [Registers.add] using clear_eval 3  (mk9 n t s c d h a b p)

theorem seq224_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq224 (mk9 n t s c d h a b p) .normal (mk9 n t s c 0 h a b p) := by
  change Eval (clearCode 4) _ _ _
  simpa [Registers.add] using clear_eval 4  (mk9 n t s c d h a b p)

theorem seq201_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq201 (mk9 n t s c d h a b p) .normal (mk9 n t s (c+a) d h 0 b p) := by
  change Eval (transferCode 6 3) _ _ _
  simpa [Registers.add] using transfer_eval 6 3 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq203_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq203 (mk9 n t s c d h a b p) .normal (mk9 (n+a) t s c d h 0 b p) := by
  change Eval (transferCode 6 0) _ _ _
  simpa [Registers.add] using transfer_eval 6 0 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq205_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq205 (mk9 n t s c d h a b p) .normal (mk9 n t s c (d+a) h 0 b p) := by
  change Eval (transferCode 6 4) _ _ _
  simpa [Registers.add] using transfer_eval 6 4 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq207_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq207 (mk9 n t s c d h a b p) .normal (mk9 n t s c d (h+a) 0 b p) := by
  change Eval (transferCode 6 5) _ _ _
  simpa [Registers.add] using transfer_eval 6 5 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq208_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq208 (mk9 n t s c d h a b p) .normal (mk9 n (t+a) s c d h 0 b p) := by
  change Eval (transferCode 6 1) _ _ _
  simpa [Registers.add] using transfer_eval 6 1 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq209_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq209 (mk9 n t s c d h a b p) .normal (mk9 n t s c d h a 0 (p+b)) := by
  change Eval (transferCode 7 8) _ _ _
  simpa [Registers.add] using transfer_eval 7 8 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq211_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq211 (mk9 n t s c d h a b p) .normal (mk9 n t s c d h (a+b) 0 p) := by
  change Eval (transferCode 7 6) _ _ _
  simpa [Registers.add] using transfer_eval 7 6 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq212_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq212 (mk9 n t s c d h a b p) .normal (mk9 n t (s+b) c d h a 0 p) := by
  change Eval (transferCode 7 2) _ _ _
  simpa [Registers.add] using transfer_eval 7 2 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq216_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq216 (mk9 n t s c d h a b p) .normal (mk9 n 0 s c d h (a+t) b p) := by
  change Eval (transferCode 1 6) _ _ _
  simpa [Registers.add] using transfer_eval 1 6 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq217_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq217 (mk9 n t s c d h a b p) .normal (mk9 n (t+s) 0 c d h a b p) := by
  change Eval (transferCode 2 1) _ _ _
  simpa [Registers.add] using transfer_eval 2 1 (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq117_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq117 (mk9 n t s c d h a b p) .normal (mk9 n ((t+b)+b) s c d h a 0 p) := by
  change Eval (copyCode 7 1 1) _ _ _
  simpa [Registers.add] using copy_eval 7 1 1 (by decide +kernel) (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq193_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq193 (mk9 n t s c d h a b p) .normal (mk9 n (t+c) s 0 d h (a+c) b p) := by
  change Eval (copyCode 3 6 1) _ _ _
  simpa [Registers.add] using copy_eval 3 6 1 (by decide +kernel) (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq194_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq194 (mk9 n t s c d h a b p) .normal (mk9 0 t s c d h (a+n) b (p+n)) := by
  change Eval (copyCode 0 8 6) _ _ _
  simpa [Registers.add] using copy_eval 0 8 6 (by decide +kernel) (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq198_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq198 (mk9 n t s c d h a b p) .normal (mk9 n (t+d) s c 0 h (a+d) b p) := by
  change Eval (copyCode 4 6 1) _ _ _
  simpa [Registers.add] using copy_eval 4 6 1 (by decide +kernel) (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq200_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq200 (mk9 n t s c d h a b p) .normal (mk9 n (t+h) s c d 0 (a+h) b p) := by
  change Eval (copyCode 5 6 1) _ _ _
  simpa [Registers.add] using copy_eval 5 6 1 (by decide +kernel) (by decide +kernel) (mk9 n t s c d h a b p)

theorem seq215_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq215 (mk9 n t s c d h a b p) .normal (mk9 n 0 s c d h (a+t) (b+t) p) := by
  change Eval (copyCode 1 7 6) _ _ _
  simpa [Registers.add] using copy_eval 1 7 6 (by decide +kernel) (by decide +kernel) (mk9 n t s c d h a b p)

end NF192.Emitter

namespace NF192.Emitter

open Registers NF192.Numerical

/-- One literal inverse-pairing pass moves to the next Cantor diagonal point. -/
theorem seq155_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq155 (mk9 n t s c d h a b p) .normal
      (mk9 n t s c d h (Cantor.next (a,b)).1 (Cantor.next (a,b)).2 p) := by
  have hi : Eval (.inc 7) (mk9 n t s c d h a b p) .normal
      (mk9 n t s c d h a (b+1) p) := by
    simpa [Registers.add] using Eval.inc 7 (mk9 n t s c d h a b p)
  by_cases ha : a = 0
  · subst a
    have hd := Eval.dec_zero 6 (mk9 n t s c d h 0 (b+1) p) (by rfl)
    have hl : Eval Literal.seq138 (mk9 n t s c d h 0 (b+1) p) .normal
        (mk9 n t s c d h 0 (b+1) p) := Eval.seq_br_left hd
    have hr := seq211_eval n t s c d h 0 (b+1) p
    have he := Eval.seq_normal hi (Eval.seq_normal hl hr)
    simpa [Literal.seq155,Literal.seq137,Cantor.next] using he
  · have hd : Eval (.dec 6) (mk9 n t s c d h a (b+1) p) .normal
        (mk9 n t s c d h (a-1) (b+1) p) := by
      simpa using Eval.dec_pos 6 (mk9 n t s c d h a (b+1) p) (by simp; omega)
    have hl : Eval Literal.seq138 (mk9 n t s c d h a (b+1) p) (.br 1)
        (mk9 n t s c d h (a-1) (b+1) p) :=
      Eval.seq_br_right hd (Eval.br 1 _)
    have hr : Eval Literal.seq137 (mk9 n t s c d h a (b+1) p) .normal
        (mk9 n t s c d h (a-1) (b+1) p) := Eval.seq_br_left hl
    simpa [Literal.seq155,Cantor.next,ha] using Eval.seq_normal hi hr

theorem seq115_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq115 (mk9 n t s c d h a b p) .normal
      (mk9 n t s c d h (Cantor.unpair (pair a b+p)).1
        (Cantor.unpair (pair a b+p)).2 0) := by
  induction p generalizing a b with
  | zero =>
      have he := Eval.seq_br_left (b := Literal.seq154)
        (Eval.dec_zero 8 (mk9 n t s c d h a b 0) (by rfl))
      simpa only [Literal.seq115,Nat.add_zero,Cantor.unpair_pair] using he
  | succ p ih =>
      have hd : Eval (.dec 8) (mk9 n t s c d h a b (p+1)) .normal
          (mk9 n t s c d h a b p) := by
        simpa using Eval.dec_pos 8 (mk9 n t s c d h a b (p+1)) (by simp)
      have hb : Eval Literal.seq154 (mk9 n t s c d h a b p) (.cont 1)
          (mk9 n t s c d h (Cantor.next (a,b)).1 (Cantor.next (a,b)).2 p) :=
        Eval.seq_cont_right_more (n := 0) (seq155_eval n t s c d h a b p)
          (Eval.cont 2 _)
      have hc := ih (Cantor.next (a,b)).1 (Cantor.next (a,b)).2
      have he : pair (Cantor.next (a,b)).1 (Cantor.next (a,b)).2 + p =
          pair a b + (p+1) := by rw [Cantor.pair_next]; dsimp only; omega
      rw [he] at hc
      exact Eval.seq_loop hd hb hc

theorem seq116_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq116 (mk9 n t s c d h a b p) .normal
      (mk9 n t 0 c d h (Cantor.unpair (pair a b+s)).1
        (Cantor.unpair (pair a b+s)).2 p) := by
  induction s generalizing a b with
  | zero =>
      have he := Eval.seq_br_left (b := Literal.seq154)
        (Eval.dec_zero 2 (mk9 n t 0 c d h a b p) (by rfl))
      simpa only [Literal.seq116,Nat.add_zero,Cantor.unpair_pair] using he
  | succ s ih =>
      have hd : Eval (.dec 2) (mk9 n t (s+1) c d h a b p) .normal
          (mk9 n t s c d h a b p) := by
        simpa using Eval.dec_pos 2 (mk9 n t (s+1) c d h a b p) (by simp)
      have hb : Eval Literal.seq154 (mk9 n t s c d h a b p) (.cont 1)
          (mk9 n t s c d h (Cantor.next (a,b)).1 (Cantor.next (a,b)).2 p) :=
        Eval.seq_cont_right_more (n := 0) (seq155_eval n t s c d h a b p)
          (Eval.cont 2 _)
      have hc := ih (Cantor.next (a,b)).1 (Cantor.next (a,b)).2
      have he : pair (Cantor.next (a,b)).1 (Cantor.next (a,b)).2 + s =
          pair a b + (s+1) := by rw [Cantor.pair_next]; dsimp only; omega
      rw [he] at hc
      exact Eval.seq_loop hd hb hc

theorem cantor_pair_descent (a b : Nat) (h : 0 < a+b) :
    pair a b = b + 1 + pair 0 (a+b-1) := by
  have hn : a+b = (a+b-1)+1 := by omega
  rw [Cantor.pair_eq,Cantor.pair_eq,Nat.zero_add]
  have he : Cantor.triangle (a+b) = Cantor.triangle (a+b-1) + (a+b-1) + 1 :=
    (congrArg Cantor.triangle hn).trans (Cantor.triangle_succ (a+b-1))
  rw [he]
  omega

/-- The literal pairing helper drains both inputs and adds their pair to scratch2. -/
theorem seq162_eval (n t s c d h a b p : Nat) :
    Eval Literal.seq162 (mk9 n t s c d h a b p) .normal
      (mk9 n 0 s c d h 0 (b+pair a t) p) := by
  generalize hr : a+t = rank
  induction rank using Nat.strongRecOn generalizing a t b with
  | ind rank ih =>
      have hl := seq215_eval n t s c d h a b p
      by_cases hz : a+t = 0
      · have ha : a = 0 := by omega
        have ht : t = 0 := by omega
        subst a
        subst t
        have hd := Eval.dec_zero 6 (mk9 n 0 s c d h 0 b p) (by rfl)
        have he : Eval Literal.seq163 (mk9 n 0 s c d h 0 b p) .normal
            (mk9 n 0 s c d h 0 b p) := Eval.seq_br_left hd
        simpa [Literal.seq162,pair] using Eval.seq_normal hl he
      · have hd : Eval (.dec 6) (mk9 n 0 s c d h (a+t) (b+t) p) .normal
            (mk9 n 0 s c d h (a+t-1) (b+t) p) := by
          simpa using Eval.dec_pos 6 (mk9 n 0 s c d h (a+t) (b+t) p) (by simp; omega)
        have hi : Eval (.inc 7) (mk9 n 0 s c d h (a+t-1) (b+t) p) .normal
            (mk9 n 0 s c d h (a+t-1) (b+t+1) p) := by
          simpa [Registers.add] using Eval.inc 7 (mk9 n 0 s c d h (a+t-1) (b+t) p)
        have ht := seq208_eval n 0 s c d h (a+t-1) (b+t+1) p
        have he₁ : Eval Literal.seq165 (mk9 n 0 s c d h (a+t-1) (b+t) p) .normal
            (mk9 n (a+t-1) s c d h 0 (b+t+1) p) := by
          simpa only [Literal.seq165,Nat.zero_add] using Eval.seq_normal hi ht
        have he₂ : Eval Literal.seq164 (mk9 n 0 s c d h (a+t-1) (b+t) p) (.cont 2)
            (mk9 n (a+t-1) s c d h 0 (b+t+1) p) :=
          Eval.seq_cont_right_more (n := 1) he₁ (Eval.cont 3 _)
        have he₃ : Eval Literal.seq163 (mk9 n 0 s c d h (a+t) (b+t) p) (.cont 1)
            (mk9 n (a+t-1) s c d h 0 (b+t+1) p) :=
          Eval.seq_cont_right_more (n := 0) hd he₂
        have hc := ih (a+t-1) (by omega) (a+t-1) 0 (b+t+1) (by omega)
        have hp := cantor_pair_descent a t (by omega)
        have hv : b+t+1+pair 0 (a+t-1) = b+pair a t := by omega
        rw [hv] at hc
        exact Eval.seq_loop hl he₃ hc

end NF192.Emitter

namespace NF192.Emitter

open Registers NF192.Numerical

theorem pair_zero_zero : pair 0 0 = 0 := rfl

def ctor (k x y : Nat) : Nat := 2 * pair x y + k

theorem pair_twice (x y : Nat) : pair x y + pair x y = ctor 0 x y := by
  unfold ctor; omega

theorem ctor_inc1 (k x y : Nat) : ctor k x y + 1 = ctor (k+1) x y := by
  unfold ctor; omega

theorem ctor_inc2 (k x y : Nat) : ctor k x y + 2 = ctor (k+2) x y := by
  unfold ctor; omega

theorem ctor_inc3 (k x y : Nat) : ctor k x y + 3 = ctor (k+3) x y := by
  unfold ctor; omega

theorem ctor_inc4 (k x y : Nat) : ctor k x y + 4 = ctor (k+4) x y := by
  unfold ctor; omega

theorem seq158_normal (n t s c d h p : Nat) :
    Eval Literal.seq158 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n t s c d h (Cantor.unpair p).1 0 (Cantor.unpair p).2) := by
  have h0 : Eval Literal.seq115 (mk9 n t s c d h 0 0 p) .normal (mk9 n t s c d h (Cantor.unpair p).1 (Cantor.unpair p).2 0) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq115_eval n t s c d h 0 0 p
  have h1 : Eval Literal.seq209 (mk9 n t s c d h (Cantor.unpair p).1 (Cantor.unpair p).2 0) .normal (mk9 n t s c d h (Cantor.unpair p).1 0 (Cantor.unpair p).2) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq209_eval n t s c d h (Cantor.unpair p).1 (Cantor.unpair p).2 0
  have h2 : Eval Literal.seq158 (mk9 n t s c d h 0 0 p) .normal (mk9 n t s c d h (Cantor.unpair p).1 0 (Cantor.unpair p).2) := by
    exact Eval.seq_normal h0 h1
  exact h2

theorem seq160_normal (n t s c d h p : Nat) :
    Eval Literal.seq160 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n t (Cantor.unpair s).2 c d h (Cantor.unpair s).1 0 p) := by
  have h0 : Eval Literal.seq116 (mk9 n t s c d h 0 0 p) .normal (mk9 n t 0 c d h (Cantor.unpair s).1 (Cantor.unpair s).2 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq116_eval n t s c d h 0 0 p
  have h1 : Eval Literal.seq212 (mk9 n t 0 c d h (Cantor.unpair s).1 (Cantor.unpair s).2 p) .normal (mk9 n t (Cantor.unpair s).2 c d h (Cantor.unpair s).1 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq212_eval n t 0 c d h (Cantor.unpair s).1 (Cantor.unpair s).2 p
  have h2 : Eval Literal.seq160 (mk9 n t s c d h 0 0 p) .normal (mk9 n t (Cantor.unpair s).2 c d h (Cantor.unpair s).1 0 p) := by
    exact Eval.seq_normal h0 h1
  exact h2

theorem seq175_normal (n t s c d h p : Nat) :
    Eval Literal.seq175 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n t s c (d+(Cantor.unpair p).1) h 0 0 (Cantor.unpair p).2) := by
  have h0 : Eval Literal.seq158 (mk9 n t s c d h 0 0 p) .normal (mk9 n t s c d h (Cantor.unpair p).1 0 (Cantor.unpair p).2) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq158_normal n t s c d h p
  have h1 : Eval Literal.seq205 (mk9 n t s c d h (Cantor.unpair p).1 0 (Cantor.unpair p).2) .normal (mk9 n t s c (d+(Cantor.unpair p).1) h 0 0 (Cantor.unpair p).2) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq205_eval n t s c d h (Cantor.unpair p).1 0 (Cantor.unpair p).2
  have h2 : Eval Literal.seq175 (mk9 n t s c d h 0 0 p) .normal (mk9 n t s c (d+(Cantor.unpair p).1) h 0 0 (Cantor.unpair p).2) := by
    exact Eval.seq_normal h0 h1
  exact h2

theorem seq176_normal (n t s c d h p : Nat) :
    Eval Literal.seq176 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n t s c d (h+(Cantor.unpair p).1) 0 0 (Cantor.unpair p).2) := by
  have h0 : Eval Literal.seq158 (mk9 n t s c d h 0 0 p) .normal (mk9 n t s c d h (Cantor.unpair p).1 0 (Cantor.unpair p).2) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq158_normal n t s c d h p
  have h1 : Eval Literal.seq207 (mk9 n t s c d h (Cantor.unpair p).1 0 (Cantor.unpair p).2) .normal (mk9 n t s c d (h+(Cantor.unpair p).1) 0 0 (Cantor.unpair p).2) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq207_eval n t s c d h (Cantor.unpair p).1 0 (Cantor.unpair p).2
  have h2 : Eval Literal.seq176 (mk9 n t s c d h 0 0 p) .normal (mk9 n t s c d (h+(Cantor.unpair p).1) 0 0 (Cantor.unpair p).2) := by
    exact Eval.seq_normal h0 h1
  exact h2

theorem seq171_normal (n t s c d h p : Nat) :
    Eval Literal.seq171 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n 0 (pair t s) c d h 0 0 p) := by
  have h0 : Eval Literal.seq216 (mk9 n t s c d h 0 0 p) .normal (mk9 n 0 s c d h t 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq216_eval n t s c d h 0 0 p
  have h1 : Eval Literal.seq217 (mk9 n 0 s c d h t 0 p) .normal (mk9 n s 0 c d h t 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq217_eval n 0 s c d h t 0 p
  have h2 : Eval Literal.seq162 (mk9 n s 0 c d h t 0 p) .normal (mk9 n 0 0 c d h 0 (pair t s) p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq162_eval n s 0 c d h t 0 p
  have h3 : Eval Literal.seq212 (mk9 n 0 0 c d h 0 (pair t s) p) .normal (mk9 n 0 (pair t s) c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq212_eval n 0 0 c d h 0 (pair t s) p
  have h4 : Eval Literal.seq173 (mk9 n s 0 c d h t 0 p) .normal (mk9 n 0 (pair t s) c d h 0 0 p) := by
    exact Eval.seq_normal h2 h3
  have h5 : Eval Literal.seq172 (mk9 n 0 s c d h t 0 p) .normal (mk9 n 0 (pair t s) c d h 0 0 p) := by
    exact Eval.seq_normal h1 h4
  have h6 : Eval Literal.seq171 (mk9 n t s c d h 0 0 p) .normal (mk9 n 0 (pair t s) c d h 0 0 p) := by
    exact Eval.seq_normal h0 h5
  exact h6

theorem seq166_normal (n t s c d h p : Nat) :
    Eval Literal.seq166 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n d (pair t s) c d h 0 0 p) := by
  have h0 : Eval Literal.seq171 (mk9 n t s c d h 0 0 p) .normal (mk9 n 0 (pair t s) c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq171_normal n t s c d h p
  have h1 : Eval Literal.seq198 (mk9 n 0 (pair t s) c d h 0 0 p) .normal (mk9 n d (pair t s) c 0 h d 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq198_eval n 0 (pair t s) c d h 0 0 p
  have h2 : Eval Literal.seq205 (mk9 n d (pair t s) c 0 h d 0 p) .normal (mk9 n d (pair t s) c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq205_eval n d (pair t s) c 0 h d 0 p
  have h3 : Eval Literal.seq167 (mk9 n 0 (pair t s) c d h 0 0 p) .normal (mk9 n d (pair t s) c d h 0 0 p) := by
    exact Eval.seq_normal h1 h2
  have h4 : Eval Literal.seq166 (mk9 n t s c d h 0 0 p) .normal (mk9 n d (pair t s) c d h 0 0 p) := by
    exact Eval.seq_normal h0 h3
  exact h4

theorem seq121_normal (n t s c d h p : Nat) :
    Eval Literal.seq121 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n h (pair t s) c d h 0 0 p) := by
  have h0 : Eval Literal.seq171 (mk9 n t s c d h 0 0 p) .normal (mk9 n 0 (pair t s) c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq171_normal n t s c d h p
  have h1 : Eval Literal.seq200 (mk9 n 0 (pair t s) c d h 0 0 p) .normal (mk9 n h (pair t s) c d 0 h 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq200_eval n 0 (pair t s) c d h 0 0 p
  have h2 : Eval Literal.seq207 (mk9 n h (pair t s) c d 0 h 0 p) .normal (mk9 n h (pair t s) c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq207_eval n h (pair t s) c d 0 h 0 p
  have h3 : Eval Literal.seq122 (mk9 n 0 (pair t s) c d h 0 0 p) .normal (mk9 n h (pair t s) c d h 0 0 p) := by
    exact Eval.seq_normal h1 h2
  have h4 : Eval Literal.seq121 (mk9 n t s c d h 0 0 p) .normal (mk9 n h (pair t s) c d h 0 0 p) := by
    exact Eval.seq_normal h0 h3
  exact h4

theorem seq168_normal (n t s c d h p : Nat) :
    Eval Literal.seq168 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n c (pair t s) c d h 0 0 p) := by
  have h0 : Eval Literal.seq171 (mk9 n t s c d h 0 0 p) .normal (mk9 n 0 (pair t s) c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq171_normal n t s c d h p
  have h1 : Eval Literal.seq193 (mk9 n 0 (pair t s) c d h 0 0 p) .normal (mk9 n c (pair t s) 0 d h c 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq193_eval n 0 (pair t s) c d h 0 0 p
  have h2 : Eval Literal.seq201 (mk9 n c (pair t s) 0 d h c 0 p) .normal (mk9 n c (pair t s) c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq201_eval n c (pair t s) 0 d h c 0 p
  have h3 : Eval Literal.seq169 (mk9 n 0 (pair t s) c d h 0 0 p) .normal (mk9 n c (pair t s) c d h 0 0 p) := by
    exact Eval.seq_normal h1 h2
  have h4 : Eval Literal.seq168 (mk9 n t s c d h 0 0 p) .normal (mk9 n c (pair t s) c d h 0 0 p) := by
    exact Eval.seq_normal h0 h3
  exact h4

theorem seq119_normal (n t s c d h p : Nat) :
    Eval Literal.seq119 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n (ctor 0 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h 0 0 p) := by
  have h0 : Eval Literal.seq160 (mk9 n t s c d h 0 0 p) .normal (mk9 n t (Cantor.unpair s).2 c d h (Cantor.unpair s).1 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq160_normal n t s c d h p
  have h1 : Eval Literal.seq162 (mk9 n t (Cantor.unpair s).2 c d h (Cantor.unpair s).1 0 p) .normal (mk9 n 0 (Cantor.unpair s).2 c d h 0 (pair (Cantor.unpair s).1 t) p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq162_eval n t (Cantor.unpair s).2 c d h (Cantor.unpair s).1 0 p
  have h2 : Eval Literal.seq117 (mk9 n 0 (Cantor.unpair s).2 c d h 0 (pair (Cantor.unpair s).1 t) p) .normal (mk9 n (ctor 0 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq117_eval n 0 (Cantor.unpair s).2 c d h 0 (pair (Cantor.unpair s).1 t) p
  have h3 : Eval Literal.seq120 (mk9 n t (Cantor.unpair s).2 c d h (Cantor.unpair s).1 0 p) .normal (mk9 n (ctor 0 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h 0 0 p) := by
    exact Eval.seq_normal h1 h2
  have h4 : Eval Literal.seq119 (mk9 n t s c d h 0 0 p) .normal (mk9 n (ctor 0 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h 0 0 p) := by
    exact Eval.seq_normal h0 h3
  exact h4

theorem seq159_normal (n t s c d h p : Nat) :
    Eval Literal.seq159 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n ((t+1)+1) s c d h 0 0 p) := by
  have h0 : Eval (.inc 1) (mk9 n t s c d h 0 0 p) .normal (mk9 n (t+1) s c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using Eval.inc 1 (mk9 n t s c d h 0 0 p)
  have h1 : Eval (.inc 1) (mk9 n (t+1) s c d h 0 0 p) .normal (mk9 n ((t+1)+1) s c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using Eval.inc 1 (mk9 n (t+1) s c d h 0 0 p)
  have h2 : Eval Literal.seq159 (mk9 n t s c d h 0 0 p) .normal (mk9 n ((t+1)+1) s c d h 0 0 p) := by
    exact Eval.seq_normal h0 h1
  exact h2

theorem seq180_normal (n t s c d h p : Nat) :
    Eval Literal.seq180 (mk9 n t s c d h 0 0 p) .normal
      (mk9 n (ctor 2 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h 0 0 p) := by
  have h0 : Eval Literal.seq119 (mk9 n t s c d h 0 0 p) .normal (mk9 n (ctor 0 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq119_normal n t s c d h p
  have h1 : Eval Literal.seq159 (mk9 n (ctor 0 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h 0 0 p) .normal (mk9 n (ctor 2 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h 0 0 p) := by
    simpa only [Registers.add, mk9_get_0, mk9_get_1, mk9_get_2, mk9_get_3,
      mk9_get_4, mk9_get_5, mk9_get_6, mk9_get_7, mk9_get_8,
      mk9_set_0, mk9_set_1, mk9_set_2, mk9_set_3, mk9_set_4,
      mk9_set_5, mk9_set_6, mk9_set_7, mk9_set_8,
      pair_zero_zero, Nat.zero_add, Nat.add_zero, Cantor.unpair_pair, Cantor.unpair,
      pair_twice, ctor_inc1, ctor_inc2, ctor_inc3, ctor_inc4]
      using seq159_normal n (ctor 0 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h p
  have h2 : Eval Literal.seq180 (mk9 n t s c d h 0 0 p) .normal (mk9 n (ctor 2 (Cantor.unpair s).1 t) (Cantor.unpair s).2 c d h 0 0 p) := by
    exact Eval.seq_normal h0 h1
  exact h2


end NF192.Emitter
