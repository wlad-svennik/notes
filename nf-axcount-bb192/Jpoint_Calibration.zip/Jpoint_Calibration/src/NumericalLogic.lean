module
public import DominatedImplication
public import NumericalCodes

@[expose] public section

/-!
# The exact numerical proof calculus

There are nine axiom families: one restricted implicational schema and eight
nonlogical schemas. Modus ponens is the only other constructor. There is no
separate truth axiom. Goal and implication apply to numerical formula codes,
including the identity `imp 0 0 = 0`.

The countable completeness argument adapts NF210.Deduction and
NF210.GroundValuation. Its only propositional inputs now come from applying
the representation-independent, restricted implication proof to these codes.
-/

namespace NF192.Numerical

inductive Deriv : Nat → Prop where
  | logical (a b c u : Nat) (dominated : u ≤ a) :
      Deriv (imp (imp (imp c u) a) (imp (imp a c) (imp b c)))
  | fixedPointTrue (a b : Nat) :
      Deriv (imp (eqn (app a b) b) (eqn s (app (app q a) b)))
  | congrRight (a b c : Nat) :
      Deriv (imp (eqn c b) (eqn (app a c) (app a b)))
  | constant (a b : Nat) : Deriv (eqn (app (konst b) a) b)
  | congrLeft (a b c : Nat) :
      Deriv (imp (eqn a c) (eqn (app c b) (app a b)))
  | abstraction (a b c : Nat) :
      Deriv (eqn (app (app (app B c) a) b) (app (app c (konst b)) (app a b)))
  | euclidean (a b c : Nat) :
      Deriv (imp (eqn a b) (imp (eqn a c) (eqn c b)))
  | fixedPointFalse (a b : Nat) :
      Deriv (imp (imp (eqn (app a b) b) goal) (eqn B (app (app q a) b)))
  | extensionality (a b : Nat) :
      Deriv (imp (eqn (app b (witness a b)) (app a (witness a b))) (eqn a b))
  | mp {a b : Nat} : Deriv (imp a b) → Deriv a → Deriv b

/-- The all-zero restricted instance already proves zero. -/
theorem deriv_zero : Deriv 0 := Deriv.logical 0 0 0 0 (Nat.le_refl _)

open SetTheory.BusyBeaver.ZFC

private def language : DominatedImplication.Language Nat where
  imp := imp
  below := Nat.le
  refl := Nat.le_refl
  grow_left := fun y h => Nat.le_trans h (imp_ge_left _ y)
  grow_right := fun x h => Nat.le_trans h (imp_ge_right x _)

private theorem restricted : DominatedImplication.Restricted language Deriv where
  mp := Deriv.mp
  rho8 := Deriv.logical

theorem logic_weakening (a b : Nat) : Deriv (imp a (imp b a)) :=
  DominatedImplication.k restricted a b

theorem logic_distribution (a b c : Nat) :
    Deriv (imp (imp a (imp b c)) (imp (imp a b) (imp a c))) :=
  DominatedImplication.s restricted a b c

theorem logic_peirce (a b : Nat) : Deriv (imp (imp (imp a b) a) a) :=
  DominatedImplication.peirce restricted a b

theorem logic_composition (a b c : Nat) :
    Deriv (imp (imp a b) (imp (imp b c) (imp a c))) :=
  DominatedImplication.composition restricted a b c

theorem logic_identity (a : Nat) : Deriv (imp a a) :=
  .mp (.mp (logic_distribution a (imp a a) a) (logic_weakening a (imp a a)))
    (logic_weakening a a)

inductive From (assumptions : Nat → Prop) : Nat → Prop where
  | proved {p : Nat} : Deriv p → From assumptions p
  | assumption {p : Nat} : assumptions p → From assumptions p
  | mp {p q : Nat} : From assumptions (imp p q) → From assumptions p → From assumptions q

namespace From

theorem weaken {Γ : Nat → Prop} {p : Nat} (q : Nat)
    (h : From Γ p) : From Γ (imp q p) :=
  From.mp (From.proved (logic_weakening p q)) h

theorem deduction {Γ : Nat → Prop} {p q : Nat}
    (h : From (fun r => Γ r ∨ r = p) q) : From Γ (imp p q) := by
  induction h with
  | proved hd => exact weaken p (From.proved hd)
  | @assumption r ha =>
      cases ha with
      | inl hΓ => exact weaken p (From.assumption hΓ)
      | inr hr =>
          subst r
          exact From.proved (logic_identity p)
  | @mp a b _ _ major minor =>
      exact From.mp
        (From.mp (From.proved (logic_distribution p a b)) major) minor

theorem no_assumptions {p : Nat} (h : From (fun _ => False) p) : Deriv p := by
  induction h with
  | proved hd => exact hd
  | assumption hf => exact False.elim hf
  | mp _ _ major minor => exact Deriv.mp major minor

theorem no_assumptions_iff {p : Nat} : From (fun _ => False) p ↔ Deriv p :=
  ⟨no_assumptions, From.proved⟩

end From

namespace From

theorem monotone {Γ Δ : Nat → Prop} (hΓ : ∀ p, Γ p → Δ p)
    {p : Nat} (h : From Γ p) : From Δ p := by
  induction h with
  | proved h => exact .proved h
  | assumption h => exact .assumption (hΓ _ h)
  | mp _ _ major minor => exact .mp major minor

theorem imp_trans {Γ : Nat → Prop} {p q r : Nat}
    (hpq : From Γ (imp p q)) (hqr : From Γ (imp q r)) : From Γ (imp p r) :=
  .mp (.mp (.proved (logic_composition p q r)) hpq) hqr

end From

structure Valuation where
  holds : Nat → Prop
  implication : ∀ p q, holds (imp p q) ↔ (holds p → holds q)
  sound : ∀ p, Deriv p → holds p
  goal_false : ¬ holds goal

namespace Lindenbaum

noncomputable section
open Classical

def extend (Γ : Nat → Prop) (p : Nat) : Nat → Prop := fun q => Γ q ∨ q = p

def stage : Nat → Nat → Prop
  | 0 => fun _ => False
  | n + 1 =>
      if From (extend (stage n) n) goal then stage n else extend (stage n) n

theorem stage_consistent (h : ¬ Deriv goal) (n : Nat) : ¬ From (stage n) goal := by
  induction n with
  | zero => exact fun hg => h (From.no_assumptions hg)
  | succ n ih =>
      by_cases bad : From (extend (stage n) n) goal
      · simpa only [stage, if_pos bad] using ih
      · simpa only [stage, if_neg bad] using bad

theorem stage_step (n p : Nat) (h : stage n p) : stage (n + 1) p := by
  by_cases bad : From (extend (stage n) n) goal
  · simpa only [stage, if_pos bad] using h
  · simp only [stage, if_neg bad, extend]
    exact Or.inl h

theorem stage_mono {m n : Nat} (h : m ≤ n) (p : Nat) : stage m p → stage n p := by
  induction n with
  | zero =>
      have hm : m = 0 := by omega
      subst m
      exact id
  | succ n ih =>
      by_cases hm : m ≤ n
      · exact fun hp => stage_step n p (ih hm hp)
      · have he : m = n + 1 := by omega
        subst m
        exact id

def assumptions (p : Nat) : Prop := ∃ n, stage n p

theorem stage_into_assumptions (n p : Nat) (h : stage n p) : assumptions p :=
  ⟨n, h⟩

theorem bounded {p : Nat} (h : From assumptions p) : ∃ n, From (stage n) p := by
  induction h with
  | proved h => exact ⟨0, .proved h⟩
  | assumption h =>
      obtain ⟨n, hn⟩ := h
      exact ⟨n, .assumption hn⟩
  | mp _ _ major minor =>
      obtain ⟨m, hm⟩ := major
      obtain ⟨n, hn⟩ := minor
      exact ⟨max m n,
        .mp (From.monotone (stage_mono (Nat.le_max_left m n)) hm)
            (From.monotone (stage_mono (Nat.le_max_right m n)) hn)⟩

def holds (p : Nat) : Prop := From assumptions p

theorem goal_false (h : ¬ Deriv goal) : ¬ holds goal := by
  intro hg
  obtain ⟨n, hn⟩ := bounded hg
  exact stage_consistent h n hn

theorem rejection {p : Nat} (hp : ¬ holds p) : holds (imp p goal) := by
  have bad : From (extend (stage p) p) goal := by
    apply Classical.byContradiction
    intro hn
    have inserted : stage (p + 1) p := by
      rw [stage, if_neg hn]
      exact Or.inr rfl
    exact hp (.assumption ⟨p + 1, inserted⟩)
  exact From.monotone (stage_into_assumptions p) (From.deduction bad)

theorem explosion (h : ¬ Deriv goal) (q : Nat) : holds (imp goal q) := by
  apply Classical.byContradiction
  intro hn
  have hg : holds goal := .mp (.proved (logic_peirce goal q)) (rejection hn)
  exact goal_false h hg

theorem implication (h : ¬ Deriv goal) (p q : Nat) :
    holds (imp p q) ↔ (holds p → holds q) := by
  constructor
  · exact fun hmajor hminor => .mp hmajor hminor
  · intro hpq
    by_cases hp : holds p
    · exact From.weaken p (hpq hp)
    · exact From.imp_trans (rejection hp) (explosion h q)

def valuation (h : ¬ Deriv goal) : Valuation where
  holds := holds
  implication := implication h
  sound := fun _ hp => .proved hp
  goal_false := goal_false h

end
end Lindenbaum

theorem not_deriv_goal_iff_valuation : ¬ Deriv goal ↔ Nonempty Valuation := by
  constructor
  · exact fun h => ⟨Lindenbaum.valuation h⟩
  · rintro ⟨v⟩ h
    exact v.goal_false (v.sound goal h)

end NF192.Numerical
