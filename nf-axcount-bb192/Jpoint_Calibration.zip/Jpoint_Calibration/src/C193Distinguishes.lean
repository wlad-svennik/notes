module
public import C193Logic
public import C201Model
@[expose] public section
namespace C193
open NF192 NF192.Ground NF192.Numerical NF192.Emitter
/-- A concrete raw atom separates the presentations whenever the old calculus is consistent. -/
theorem proves_2165 : Deriv 2165 := by
  have h : Deriv (countingRow 0 1) := Deriv.row (a:=0) (b:=0) (c:=1) (u:=0)
    (Nat.le_refl 0) (by simp [rowList])
  exact h

theorem old_2165_implies_goal (d : C201.Deriv 2165) : C201.Deriv goal := by
  apply Classical.byContradiction
  intro no
  obtain ⟨r, hr, hg⟩ := C201.not_deriv_iff_ground_model.mp no
  let R := (C201.hold_iff_rows r).mp hr
  let A := R.toChart hg
  have parsed : r (app (app q s) s) s :=
    (evaluate_eqn r (app (app q s) s) s).mp (C201.evaluate_deriv hr d)
  have rawEq := R.obj_eq_iff.mpr parsed
  have truth : R.obj s = A.K A.J := R.s_eq_kb hg
  change A.app (A.app A.q (R.obj s)) (R.obj s) = R.obj s at rawEq
  rw [truth] at rawEq
  have miss : A.app (A.K A.J) (A.K A.J) ≠ A.K A.J := by
    rw [A.k_app]
    exact Ne.symm A.distinct
  exact A.distinct (rawEq.symm.trans (A.q_false _ _ miss))
end C193
#print axioms C193.proves_2165
#print axioms C193.old_2165_implies_goal
