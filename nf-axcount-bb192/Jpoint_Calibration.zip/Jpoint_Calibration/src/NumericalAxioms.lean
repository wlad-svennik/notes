module
public import NumericalLogic

@[expose] public section

/-! The stack order and equality orientations of the literal AX batch. -/

namespace NF192.Emitter

open Numerical

def row0 (a b c u : Nat) := imp (imp (imp c u) a) (imp (imp a c) (imp b c))
def row1 (a b : Nat) := imp (eqn (app a b) b) (eqn s (app (app q a) b))
def row2 (a b c : Nat) := imp (eqn c b) (eqn (app a c) (app a b))
def row4 (a b : Nat) := eqn (app (konst b) a) b
def row3 (a b c : Nat) := imp (eqn a c) (eqn (app c b) (app a b))
def row5 (a b c : Nat) := eqn (app (app (app B c) a) b) (app (app c (konst b)) (app a b))
def row6 (a b c : Nat) := imp (eqn a b) (imp (eqn a c) (eqn c b))
def row7 (a b : Nat) := imp (imp (eqn (app a b) b) goal) (eqn B (app (app q a) b))
def row9 (a b : Nat) := imp (eqn (app b (witness a b)) (app a (witness a b))) (eqn a b)

def rowList (a b c u : Nat) : List Nat :=
  [row0 a b c u, row1 a b, row2 a b c, row4 a b, row3 a b c,
   row5 a b c, row6 a b c, row7 a b, row9 a b]

theorem rows_derivable (a b c u : Nat) (h : u ≤ a) :
    ∀ k ∈ rowList a b c u, Deriv k := by
  intro k hk
  simp only [rowList, List.mem_cons, List.not_mem_nil, or_false] at hk
  rcases hk with e | e | e | e | e | e | e | e | e <;> subst k
  · exact .logical a b c u h
  · exact .fixedPointTrue a b
  · exact .congrRight a b c
  · exact .constant a b
  · exact .congrLeft a b c
  · exact .abstraction a b c
  · exact .euclidean a b c
  · exact .fixedPointFalse a b
  · exact .extensionality a b

end NF192.Emitter
