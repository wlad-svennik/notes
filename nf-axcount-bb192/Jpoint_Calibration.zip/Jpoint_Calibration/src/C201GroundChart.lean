module
public import GroundRows
public import NormalizedBasis

@[expose] public section

/-! Calibration of the nine signed schemas of the 201-state q0/J3/B183 calculus.
The signature uses q, application, and an arbitrary Skolem separator H.
Its derived terms s and b are respectively T and J. The abstraction head
is app (app b q) q, so the false tester return and the abstractor have distinct roles. -/
namespace NF201.GroundChart
open NF192.Ground
universe u

structure Chart (A : Type u) where
  app : A → A → A
  K : A → A
  J : A
  B : A
  q : A
  b_eq : B = app (app J q) q
  k_app : ∀ (x y : A), app (K x) y = x
  b_app : ∀ (x y z : A), app (app (app B x) y) z = app (app x (K z)) (app y z)
  ext : ∀ {f g : A}, (∀ x, app f x = app g x) → f = g
  q_true : ∀ (f x : A), app f x = x → app (app q f) x = K J
  q_false : ∀ (f x : A), app f x ≠ x → app (app q f) x = J
  scalar : ∀ x, app (app J (app J x)) q = app J x
  distinct : K J ≠ J

namespace Chart

variable {A : Type u} (S : Chart A)

local infixl:70 " ⬝ " => S.app

/-- A tester with these distinct outputs cannot itself have a fixed point. -/
theorem q_no_fixed (x : A) : S.q ⬝ x ≠ x := by
  intro eq
  have atB := congrArg (fun t => t ⬝ S.J) eq
  by_cases fixed : x ⬝ S.J = S.J
  · exact S.distinct ((S.q_true x S.J fixed).symm.trans (atB.trans fixed))
  · exact fixed (atB.symm.trans (S.q_false x S.J fixed))

/-- Every test performed by q q fails. -/
theorem qq_eq_kj : S.q ⬝ S.q = S.K S.J := by
  apply S.ext
  intro x
  exact (S.q_false S.q x (S.q_no_fixed x)).trans (S.k_app S.J x).symm

theorem qq_ne_q : S.q ⬝ S.q ≠ S.q := S.q_no_fixed S.q


end Chart
structure Rows {X : Type u} (S : Signature X) (r : X → X → Prop) : Prop where
  positive : ∀ (a b : X), r (S.app a b) b → r S.s (S.app (S.app S.q a) b)
  argCongr : ∀ (a b c : X), r c b → r (S.app a c) (S.app a b)
  kLaw : ∀ (a b : X), r (S.app (S.k b) a) b
  funCongr : ∀ (a b c : X), r a c → r (S.app c b) (S.app a b)
  bLaw : ∀ (a b c : X), r (S.app (S.app (S.app (S.app (S.app S.b S.q) S.q) c) a) b)
    (S.app (S.app c (S.k b)) (S.app a b))
  scalar : ∀ a, r (S.app (S.app S.b (S.app S.b a)) S.q) (S.app S.b a)
  euclid : ∀ (a b c : X), r a b → r a c → r c b
  negative : ∀ (a b : X), (r (S.app a b) b → r S.s S.q) →
    r S.b (S.app (S.app S.q a) b)
  ext : ∀ (a b : X), r (S.app b (S.h a b)) (S.app a (S.h a b)) → r a b

namespace Rows

variable {X : Type u} {S : Signature X} {r : X → X → Prop} (R : Rows S r)

include R

theorem rel_refl (a : X) : r a a :=
  R.euclid _ a a (R.kLaw S.q a) (R.kLaw S.q a)

theorem rel_symm {a b : X} (h : r a b) : r b a :=
  R.euclid a a b (R.rel_refl a) h

theorem rel_trans {a b c : X} (hab : r a b) (hbc : r b c) : r a c :=
  R.euclid b c a hbc (R.rel_symm hab)

theorem app_congr {a b c d : X} (hac : r a c) (hbd : r b d) :
    r (S.app a b) (S.app c d) :=
  R.rel_trans (R.rel_symm (R.funCongr a b c hac)) (R.argCongr c d b hbd)

theorem k_congr {a b : X} (hab : r a b) : r (S.k a) (S.k b) := by
  let d := S.h (S.k a) (S.k b)
  have h : r (S.app (S.k a) d) (S.app (S.k b) d) :=
    R.rel_trans (R.rel_trans (R.kLaw d a) hab) (R.rel_symm (R.kLaw d b))
  exact R.ext (S.k a) (S.k b) (R.rel_symm h)

def setoid : Setoid X where
  r := r
  iseqv := ⟨R.rel_refl, R.rel_symm, R.rel_trans⟩

def Carrier : Type u := Quotient R.setoid

def obj (a : X) : R.Carrier := Quotient.mk R.setoid a

theorem obj_eq_iff {a b : X} : R.obj a = R.obj b ↔ r a b :=
  ⟨fun h => Quotient.exact h, fun h => Quotient.sound (s := R.setoid) h⟩

def appObj (a b : R.Carrier) : R.Carrier :=
  Quotient.liftOn₂ a b (fun x y => R.obj (S.app x y))
    (fun _ _ _ _ hx hy => Quotient.sound (s := R.setoid) (R.app_congr hx hy))

def kObj (a : R.Carrier) : R.Carrier :=
  Quotient.liftOn a (fun x => R.obj (S.k x))
    (fun _ _ h => Quotient.sound (s := R.setoid) (R.k_congr h))

theorem app_obj (a b : X) : R.appObj (R.obj a) (R.obj b) = R.obj (S.app a b) := rfl

theorem k_obj (a : X) : R.kObj (R.obj a) = R.obj (S.k a) := rfl

theorem kObj_app (a b : R.Carrier) : R.appObj (R.kObj a) b = a := by
  refine Quotient.inductionOn₂ a b ?_
  intro x y
  exact R.obj_eq_iff.mpr (R.kLaw y x)

theorem bObj_app (x y z : R.Carrier) :
    R.appObj (R.appObj (R.appObj (R.obj (S.app (S.app S.b S.q) S.q)) x) y) z =
    R.appObj (R.appObj x (R.kObj z)) (R.appObj y z) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn z ?_
  intro c
  exact R.obj_eq_iff.mpr (R.bLaw b c a)

theorem appObj_ext {a b : R.Carrier} (h : ∀ x, R.appObj a x = R.appObj b x) :
    a = b := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  exact R.obj_eq_iff.mpr
    (R.ext x y (R.rel_symm (R.obj_eq_iff.mp (h (R.obj (S.h x y))))))

theorem positiveObj (a b : R.Carrier) (h : R.appObj a b = b) :
    R.appObj (R.appObj (R.obj S.q) a) b = R.obj S.s := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  exact (R.obj_eq_iff.mpr (R.positive x y (R.obj_eq_iff.mp h))).symm

theorem negativeObj (a b : R.Carrier) (h : R.appObj a b ≠ b) :
    R.appObj (R.appObj (R.obj S.q) a) b = R.obj S.b := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  have hn : r (S.app x y) y → r S.s S.q := fun e => (h (R.obj_eq_iff.mpr e)).elim
  exact (R.obj_eq_iff.mpr (R.negative x y hn)).symm

/-- Distinct tester outputs follow from the original goal; there is no
separate nontriviality axiom on the ground relation. -/
theorem s_ne_b (hg : ¬ r S.s S.q) : R.obj S.s ≠ R.obj S.b := by
  intro he
  have tester_const (a x : R.Carrier) :
      R.appObj (R.appObj (R.obj S.q) a) x = R.obj S.s := by
    by_cases h : R.appObj a x = x
    · exact R.positiveObj a x h
    · exact (R.negativeObj a x h).trans he.symm
  have qa (a : R.Carrier) : R.appObj (R.obj S.q) a = R.kObj (R.obj S.s) :=
    R.appObj_ext (fun x => (tester_const a x).trans (R.kObj_app _ _).symm)
  have hs : R.obj S.s = R.kObj (R.obj S.s) := qa (R.obj S.q)
  have hq : R.obj S.q = R.kObj (R.obj S.s) :=
    R.appObj_ext (fun x => ((qa x).trans hs.symm).trans (R.kObj_app _ _).symm)
  exact hg (R.obj_eq_iff.mp (hs.trans hq.symm))

theorem q_no_fixed (hg : ¬ r S.s S.q) (x : R.Carrier) :
    R.appObj (R.obj S.q) x ≠ x := by
  intro hx
  by_cases h : R.appObj x (R.obj S.b) = R.obj S.b
  · have eq : R.appObj x (R.obj S.b) = R.obj S.s := by
      simpa only [hx] using R.positiveObj x (R.obj S.b) h
    exact R.s_ne_b hg (eq.symm.trans h)
  · apply h
    simpa only [hx] using R.negativeObj x (R.obj S.b) h

theorem s_eq_kb (hg : ¬ r S.s S.q) : R.obj S.s = R.kObj (R.obj S.b) :=
  R.appObj_ext (fun x =>
    (R.negativeObj (R.obj S.q) x (R.q_no_fixed hg x)).trans (R.kObj_app _ _).symm)

end Rows

namespace Rows

variable {X : Type u} {S : Signature X} {r : X → X → Prop} (R : Rows S r)

def toChart (hg : ¬ r S.s S.q) : Chart R.Carrier where
  app := R.appObj
  K := R.kObj
  J := R.obj S.b
  B := R.obj (S.app (S.app S.b S.q) S.q)
  b_eq := rfl
  q := R.obj S.q
  k_app := R.kObj_app
  b_app := R.bObj_app
  ext := R.appObj_ext
  q_true := fun f x h => (R.positiveObj f x h).trans (R.s_eq_kb hg)
  q_false := R.negativeObj
  scalar := fun x => Quotient.inductionOn x (fun a => R.obj_eq_iff.mpr (R.scalar a))
  distinct := fun h => R.s_ne_b hg ((R.s_eq_kb hg).trans h)

end Rows

namespace Interpretation

variable {M : Type u} (A : Chart M)

/-- Unequal functions have a concrete distinguishing argument. -/
theorem exists_separator {a b : M} (hn : a ≠ b) :
    ∃ x, A.app a x ≠ A.app b x := by
  apply Classical.byContradiction
  intro h
  apply hn
  apply A.ext
  intro x
  apply Classical.byContradiction
  intro hx
  exact h ⟨x, hx⟩

/-- A single object-level operation realizes both diagonal K and
the witness required by the last schema. -/
noncomputable def witness (a b : M) : M := by
  classical
  exact if h : a = b then A.K a else Classical.choose (exists_separator A h)

theorem witness_diag (a : M) : witness A a a = A.K a := by
  classical
  simp [witness]

theorem witness_ext (a b : M)
    (h : A.app b (witness A a b) = A.app a (witness A a b)) : a = b := by
  classical
  by_cases e : a = b
  · exact e
  · have hn := Classical.choose_spec (exists_separator A e)
    exact False.elim (hn (by simpa only [witness, dite_eq_right e] using h.symm))

noncomputable def eval : Term → M
  | .q => A.q
  | .app a b => A.app (eval a) (eval b)
  | .h a b => witness A (eval a) (eval b)

theorem eval_k (a : Term) : eval A (Term.signature.k a) = A.K (eval A a) :=
  witness_diag A _

theorem eval_s : eval A Term.signature.s = A.K A.J := A.qq_eq_kj

theorem eval_b : eval A Term.signature.b = A.J := by
  change A.app (A.app A.q A.q) A.q = A.J
  rw [A.qq_eq_kj, A.k_app]

theorem goal_false : eval A Term.signature.s ≠ eval A Term.signature.q :=
  A.qq_ne_q

def EqualValue (a b : Term) : Prop := eval A a = eval A b

theorem rows : Rows Term.signature (EqualValue A) where
  positive := by
    intro a b h
    change eval A Term.signature.s = A.app (A.app A.q (eval A a)) (eval A b)
    exact (eval_s A).trans (A.q_true _ _ h).symm
  argCongr := by
    intro a b c h
    exact congrArg (A.app (eval A a)) h
  kLaw := by
    intro a b
    change A.app (eval A (Term.signature.k b)) (eval A a) = eval A b
    rw [eval_k, A.k_app]
  funCongr := by
    intro a b c h
    exact congrArg (fun z => A.app z (eval A b)) h.symm
  bLaw := by
    intro a b c
    change A.app (A.app (A.app (A.app (A.app (eval A Term.signature.b) A.q) A.q) (eval A c)) (eval A a)) (eval A b) =
      A.app (A.app (eval A c) (eval A (Term.signature.k b))) (A.app (eval A a) (eval A b))
    rw [eval_b, eval_k, ← A.b_eq, A.b_app]
  scalar := by
    intro a
    change A.app (A.app (eval A Term.signature.b) (A.app (eval A Term.signature.b) (eval A a))) A.q = A.app (eval A Term.signature.b) (eval A a)
    rw [eval_b, A.scalar]
  euclid := by
    intro a b c h₁ h₂
    exact h₂.symm.trans h₁
  negative := by
    intro a b h
    have hn : A.app (eval A a) (eval A b) ≠ eval A b :=
      fun e => goal_false A (h e)
    change eval A Term.signature.b = A.app (A.app A.q (eval A a)) (eval A b)
    exact (eval_b A).trans (A.q_false _ _ hn).symm
  ext := by
    intro a b h
    exact witness_ext A (eval A a) (eval A b) h

end Interpretation

/-- Every normalized algebra yields a countervaluation of the exact closed
ground schemes, with goal `qq = q` false. -/
theorem term_countermodel {M : Type u} (A : Chart M) :
    ∃ r : Term → Term → Prop, Rows Term.signature r ∧ ¬ r Term.signature.s Term.signature.q :=
  ⟨Interpretation.EqualValue A, Interpretation.rows A, Interpretation.goal_false A⟩

/-- Uniform equisatisfiability at the universe of the ground terms. -/
theorem term_countermodel_iff :
    (∃ r : Term → Term → Prop, Rows Term.signature r ∧ ¬ r Term.signature.s Term.signature.q) ↔
      ∃ M : Type, Nonempty (Chart M) := by
  constructor
  · rintro ⟨r, R, hg⟩
    exact ⟨R.Carrier, ⟨R.toChart hg⟩⟩
  · rintro ⟨M, ⟨A⟩⟩
    exact term_countermodel A

end NF201.GroundChart

#print axioms NF201.GroundChart.term_countermodel_iff
