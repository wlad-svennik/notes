module
public import NumericalEmitterMacros

@[expose] public section

/-!
# The countdown's actual sequence of axiom-emitter macros

The tuple below omits the two scratch registers, which start and finish each
macro at zero. `macro_eval` proves the specified transformation in the
primitive register semantics for arbitrary naturals.
-/

set_option maxHeartbeats 0
set_option maxRecDepth 50000

namespace NF192.Emitter

open NF192.Numerical Registers

inductive Macro where
  | push0 | push3 | push4 | push5 | incTop | read4 | read5
  | imp | ap | eqn | witness | clear4 | clear5


def Macro.block : Macro → Code
  | .push0 => Literal.seq171
  | .push3 => Literal.seq168
  | .push4 => Literal.seq166
  | .push5 => Literal.seq121
  | .incTop => .inc 1
  | .read4 => Literal.seq175
  | .read5 => Literal.seq176
  | .imp => Literal.seq119
  | .ap | .eqn => .seq Literal.seq119 (.inc 1)
  | .witness => Literal.seq180
  | .clear4 => Literal.seq224
  | .clear5 => Literal.seq199

structure Frame where
  counter : Nat
  top : Nat
  stack : Nat
  c : Nat
  a : Nat
  b : Nat
  input : Nat

def Frame.regs (f : Frame) : Registers :=
  mk9 f.counter f.top f.stack f.c f.a f.b 0 0 f.input

def Frame.push (f : Frame) (x : Nat) : Frame :=
  { f with top := x, stack := pair f.top f.stack }

def Frame.combine (f : Frame) (tag : Nat) : Frame :=
  { f with top := ctor tag (Cantor.unpair f.stack).1 f.top, stack := (Cantor.unpair f.stack).2 }

def Frame.apply (f : Frame) : Macro → Frame
  | .push0 => f.push 0
  | .push3 => f.push f.c
  | .push4 => f.push f.a
  | .push5 => f.push f.b
  | .incTop => { f with top := f.top + 1 }
  | .read4 => { f with a := f.a + (Cantor.unpair f.input).1, input := (Cantor.unpair f.input).2 }
  | .read5 => { f with b := f.b + (Cantor.unpair f.input).1, input := (Cantor.unpair f.input).2 }
  | .imp => f.combine 0
  | .ap | .eqn => f.combine 1
  | .witness => f.combine 2
  | .clear4 => { f with a := 0 }
  | .clear5 => { f with b := 0 }

theorem macro_eval (m : Macro) (f : Frame) :
    Eval m.block f.regs .normal (f.apply m).regs := by
  obtain ⟨n,t,st,c,a,b,p⟩ := f
  cases m with
  | push0 => exact seq171_normal n t st c a b p
  | push3 => exact seq168_normal n t st c a b p
  | push4 => exact seq166_normal n t st c a b p
  | push5 => exact seq121_normal n t st c a b p
  | incTop =>
      simpa only [Macro.block, Frame.regs, Frame.apply, Registers.add, mk9_get_1, mk9_set_1]
        using Eval.inc 1 (mk9 n t st c a b 0 0 p)
  | read4 => exact seq175_normal n t st c a b p
  | read5 => exact seq176_normal n t st c a b p
  | imp => exact seq119_normal n t st c a b p
  | ap | eqn =>
      apply Eval.seq_normal (seq119_normal n t st c a b p)
      simpa only [Frame.regs, Frame.apply, Frame.combine, Registers.add, mk9_get_1,
        mk9_set_1, ctor_inc1] using Eval.inc 1
          (mk9 n (ctor 0 (Cantor.unpair st).1 t) (Cantor.unpair st).2 c a b 0 0 p)
  | witness => exact seq180_normal n t st c a b p
  | clear4 => exact seq224_eval n t st c a b 0 0 p
  | clear5 => exact seq199_eval n t st c a b 0 0 p

def sequence : Macro → List Macro → Code
  | m, [] => m.block
  | m, h :: t => .seq m.block (sequence h t)

theorem sequence_eval (m : Macro) (tail : List Macro) (f : Frame) :
    Eval (sequence m tail) f.regs .normal (tail.foldl Frame.apply (f.apply m)).regs := by
  induction tail generalizing m f with
  | nil => exact macro_eval m f
  | cons h t ih => exact Eval.seq_normal (macro_eval m f) (ih h (f.apply m))

end NF192.Emitter
