module
public import Init

@[expose] public section

/-! The eight nonlogical schemas emitted by the 192-state countdown machine.
Variables range over closed object codes.  In particular, `h` is a syntactic
symbol; no congruence premise for `h` is present. -/

set_option maxHeartbeats 20000000

namespace NF192.Ground

universe u

structure Signature (X : Type u) where
  q : X
  app : X → X → X
  h : X → X → X

namespace Signature

variable {X : Type u} (S : Signature X)

def k (a : X) : X := S.h a a
def s : X := S.app S.q S.q
def b : X := S.app S.s S.q

end Signature

/-- Satisfaction of the eight schemes, in their source order and orientation.
The designated goal is the atom `r S.s S.q`. -/
structure Rows {X : Type u} (S : Signature X) (r : X → X → Prop) : Prop where
  positive : ∀ (a b : X), r (S.app a b) b → r S.s (S.app (S.app S.q a) b)
  argCongr : ∀ (a b c : X), r c b → r (S.app a c) (S.app a b)
  kLaw : ∀ (a b : X), r (S.app (S.k b) a) b
  funCongr : ∀ (a b c : X), r a c → r (S.app c b) (S.app a b)
  bLaw : ∀ (a b c : X), r (S.app (S.app (S.app S.b c) a) b)
    (S.app (S.app c (S.k b)) (S.app a b))
  euclid : ∀ (a b c : X), r a b → r a c → r c b
  negative : ∀ (a b : X), (r (S.app a b) b → r S.s S.q) →
    r S.b (S.app (S.app S.q a) b)
  ext : ∀ (a b : X), r (S.app b (S.h a b)) (S.app a (S.h a b)) → r a b

set_option maxHeartbeats 0 in
inductive Term : Type where
  | q : Term
  | app : Term → Term → Term
  | h : Term → Term → Term


def Term.signature : Signature Term := ⟨.q, .app, .h⟩

namespace Rows

variable {X : Type u} {S : Signature X} {r : X → X → Prop} (R : Rows S r)

include R

theorem rel_refl (a : X) : r a a :=
  R.euclid _ a a (R.kLaw S.q a) (R.kLaw S.q a)

theorem rel_symm {a b : X} (h : r a b) : r b a :=
  R.euclid a a b (R.rel_refl a) h

theorem rel_trans {a b c : X} (hab : r a b) (hbc : r b c) : r a c :=
  R.euclid b c a hbc (R.rel_symm hab)

theorem app_congr {a b c d : X} (hac : r a c) (hbd : r b d) :
    r (S.app a b) (S.app c d) :=
  R.rel_trans (R.rel_symm (R.funCongr a b c hac)) (R.argCongr c d b hbd)

theorem k_congr {a b : X} (hab : r a b) : r (S.k a) (S.k b) := by
  let d := S.h (S.k a) (S.k b)
  have h : r (S.app (S.k a) d) (S.app (S.k b) d) :=
    R.rel_trans (R.rel_trans (R.kLaw d a) hab) (R.rel_symm (R.kLaw d b))
  exact R.ext (S.k a) (S.k b) (R.rel_symm h)

def setoid : Setoid X where
  r := r
  iseqv := ⟨R.rel_refl, R.rel_symm, R.rel_trans⟩

def Carrier : Type u := Quotient R.setoid

def obj (a : X) : R.Carrier := Quotient.mk R.setoid a

theorem obj_eq_iff {a b : X} : R.obj a = R.obj b ↔ r a b :=
  ⟨fun h => Quotient.exact h, fun h => Quotient.sound (s := R.setoid) h⟩

def appObj (a b : R.Carrier) : R.Carrier :=
  Quotient.liftOn₂ a b (fun x y => R.obj (S.app x y))
    (fun _ _ _ _ hx hy => Quotient.sound (s := R.setoid) (R.app_congr hx hy))

def kObj (a : R.Carrier) : R.Carrier :=
  Quotient.liftOn a (fun x => R.obj (S.k x))
    (fun _ _ h => Quotient.sound (s := R.setoid) (R.k_congr h))

theorem app_obj (a b : X) : R.appObj (R.obj a) (R.obj b) = R.obj (S.app a b) := rfl

theorem k_obj (a : X) : R.kObj (R.obj a) = R.obj (S.k a) := rfl

theorem kObj_app (a b : R.Carrier) : R.appObj (R.kObj a) b = a := by
  refine Quotient.inductionOn₂ a b ?_
  intro x y
  exact R.obj_eq_iff.mpr (R.kLaw y x)

theorem bObj_app (x y z : R.Carrier) :
    R.appObj (R.appObj (R.appObj (R.obj S.b) x) y) z =
    R.appObj (R.appObj x (R.kObj z)) (R.appObj y z) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn z ?_
  intro c
  exact R.obj_eq_iff.mpr (R.bLaw b c a)

theorem appObj_ext {a b : R.Carrier} (h : ∀ x, R.appObj a x = R.appObj b x) :
    a = b := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  exact R.obj_eq_iff.mpr
    (R.ext x y (R.rel_symm (R.obj_eq_iff.mp (h (R.obj (S.h x y))))))

theorem positiveObj (a b : R.Carrier) (h : R.appObj a b = b) :
    R.appObj (R.appObj (R.obj S.q) a) b = R.obj S.s := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  exact (R.obj_eq_iff.mpr (R.positive x y (R.obj_eq_iff.mp h))).symm

theorem negativeObj (a b : R.Carrier) (h : R.appObj a b ≠ b) :
    R.appObj (R.appObj (R.obj S.q) a) b = R.obj S.b := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  have hn : r (S.app x y) y → r S.s S.q := fun e => (h (R.obj_eq_iff.mpr e)).elim
  exact (R.obj_eq_iff.mpr (R.negative x y hn)).symm

/-- Distinct tester outputs follow from the original goal; there is no
separate nontriviality axiom on the ground relation. -/
theorem s_ne_b (hg : ¬ r S.s S.q) : R.obj S.s ≠ R.obj S.b := by
  intro he
  have tester_const (a x : R.Carrier) :
      R.appObj (R.appObj (R.obj S.q) a) x = R.obj S.s := by
    by_cases h : R.appObj a x = x
    · exact R.positiveObj a x h
    · exact (R.negativeObj a x h).trans he.symm
  have qa (a : R.Carrier) : R.appObj (R.obj S.q) a = R.kObj (R.obj S.s) :=
    R.appObj_ext (fun x => (tester_const a x).trans (R.kObj_app _ _).symm)
  have hs : R.obj S.s = R.kObj (R.obj S.s) := qa (R.obj S.q)
  have hq : R.obj S.q = R.kObj (R.obj S.s) :=
    R.appObj_ext (fun x => ((qa x).trans hs.symm).trans (R.kObj_app _ _).symm)
  exact hg (R.obj_eq_iff.mp (hs.trans hq.symm))

theorem q_no_fixed (hg : ¬ r S.s S.q) (x : R.Carrier) :
    R.appObj (R.obj S.q) x ≠ x := by
  intro hx
  by_cases h : R.appObj x (R.obj S.b) = R.obj S.b
  · have eq : R.appObj x (R.obj S.b) = R.obj S.s := by
      simpa only [hx] using R.positiveObj x (R.obj S.b) h
    exact R.s_ne_b hg (eq.symm.trans h)
  · apply h
    simpa only [hx] using R.negativeObj x (R.obj S.b) h

theorem s_eq_kb (hg : ¬ r S.s S.q) : R.obj S.s = R.kObj (R.obj S.b) :=
  R.appObj_ext (fun x =>
    (R.negativeObj (R.obj S.q) x (R.q_no_fixed hg x)).trans (R.kObj_app _ _).symm)

end Rows

end NF192.Ground
