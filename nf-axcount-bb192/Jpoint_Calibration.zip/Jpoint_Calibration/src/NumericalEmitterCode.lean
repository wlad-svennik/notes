module
public import NumericalCodes

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 25000

/-! Register-block semantics and its compilation theorem, adapted from NF210.SourceSemantics and NF210.SourceCompilation. The additional decHalt case models the selected countdown source. -/

namespace NF192.Emitter

abbrev Register := Fin 9
abbrev Registers := Register → Nat

namespace Registers

def set (s : Registers) (r : Register) (n : Nat) : Registers :=
  fun q => if q = r then n else s q

def add (s : Registers) (r : Register) (n : Nat) : Registers := s.set r (s r + n)

@[simp] theorem set_same (s : Registers) (r : Register) (n : Nat) :
    s.set r n r = n := by simp [set]

@[simp] theorem set_other (s : Registers) (r q : Register) (n : Nat) (h : q ≠ r) :
    s.set r n q = s q := by simp [set,h]

@[simp] theorem set_set (s : Registers) (r : Register) (m n : Nat) :
    (s.set r m).set r n = s.set r n := by
  funext q
  by_cases h : q = r <;> simp [set,h]

theorem set_comm (s : Registers) (r q : Register) (m n : Nat) (h : r ≠ q) :
    (s.set r m).set q n = (s.set q n).set r m := by
  funext j
  by_cases hj : j = r
  · subst j
    simp [set,h]
  · by_cases hk : j = q <;> simp [set,hj,hk,Ne.symm h]

@[simp] theorem set_self (s : Registers) (r : Register) : s.set r (s r) = s := by
  funext q
  by_cases h : q = r <;> simp [set,h]

@[simp] theorem add_zero (s : Registers) (r : Register) : s.add r 0 = s := by
  simp [add]

@[simp] theorem add_add (s : Registers) (r : Register) (m n : Nat) :
    (s.add r m).add r n = s.add r (m+n) := by simp [add,Nat.add_assoc]

end Registers

inductive Code where
  | inc : Register → Code
  | dec : Register → Code
  | br : Nat → Code
  | cont : Nat → Code
  | halt : Code
  | seq : Code → Code → Code


inductive Flow where
  | normal
  | br : Nat → Flow
  | cont : Nat → Flow
  | halt


/-- Finite big-step execution, including observable nonlocal exits. -/
inductive Eval : Code → Registers → Flow → Registers → Prop where
  | inc (r : Register) (s : Registers) : Eval (.inc r) s .normal (s.add r 1)
  | dec_pos (r : Register) (s : Registers) (h : 0 < s r) :
      Eval (.dec r) s .normal (s.set r (s r - 1))
  | dec_zero (r : Register) (s : Registers) (h : s r = 0) : Eval (.dec r) s (.br 1) s
  | br (n : Nat) (s : Registers) : Eval (.br n) s (.br n) s
  | cont (n : Nat) (s : Registers) : Eval (.cont n) s (.cont n) s
  | halt (s : Registers) : Eval .halt s .halt s
  | seq_normal {a b : Code} {s t u : Registers} :
      Eval a s .normal t → Eval b t .normal u → Eval (.seq a b) s .normal u
  | seq_br_left {a b : Code} {s t : Registers} :
      Eval a s (.br 1) t → Eval (.seq a b) s .normal t
  | seq_br_left_more {a b : Code} {s t : Registers} {n : Nat} :
      Eval a s (.br (n+2)) t → Eval (.seq a b) s (.br (n+1)) t
  | seq_cont_left {a b : Code} {s t : Registers} {n : Nat} :
      Eval a s (.cont n) t → Eval (.seq a b) s (.cont n) t
  | seq_halt_left {a b : Code} {s t : Registers} :
      Eval a s .halt t → Eval (.seq a b) s .halt t
  | seq_br_right {a b : Code} {s t u : Registers} {n : Nat} :
      Eval a s .normal t → Eval b t (.br n) u → Eval (.seq a b) s (.br n) u
  | seq_cont_right_more {a b : Code} {s t u : Registers} {n : Nat} :
      Eval a s .normal t → Eval b t (.cont (n+2)) u →
      Eval (.seq a b) s (.cont (n+1)) u
  | seq_halt_right {a b : Code} {s t u : Registers} :
      Eval a s .normal t → Eval b t .halt u → Eval (.seq a b) s .halt u
  | seq_loop {a b : Code} {s t u v : Registers} {flow : Flow} :
      Eval a s .normal t → Eval b t (.cont 1) u →
      Eval (.seq a b) u flow v → Eval (.seq a b) s flow v

inductive Instruction where
  | inc : Register → Nat → Instruction
  | dec : Register → Nat → Nat → Instruction
  | decHalt : Register → Nat → Instruction
  | jump : Nat → Instruction
  | halt : Instruction


structure Config where
  pc : Nat
  registers : Registers

def step (program : Nat → Instruction) (s : Config) : Option Config :=
  match program s.pc with
  | .inc r next => some ⟨next,s.registers.add r 1⟩
  | .dec r onZero onPositive =>
      if s.registers r = 0 then some ⟨onZero,s.registers⟩
      else some ⟨onPositive,s.registers.set r (s.registers r - 1)⟩
  | .decHalt r next =>
      if s.registers r = 0 then none else some ⟨next,s.registers.set r (s.registers r - 1)⟩
  | .jump next => some ⟨next,s.registers⟩
  | .halt => none

def run (program : Nat → Instruction) : Nat → Config → Option Config
  | 0,s => some s
  | n+1,s => (step program s).bind (run program n)

theorem run_add (program : Nat → Instruction) (n m : Nat) (s : Config) :
    run program (n+m) s = (run program n s).bind (run program m) := by
  induction n generalizing s with
  | zero => simp only [Nat.zero_add,run,Option.bind_some]
  | succ n ih =>
      rw [Nat.succ_add,run,run]
      cases hs : step program s with
      | none => rfl
      | some t => simpa only [Option.bind_some] using ih t

def Reaches (program : Nat → Instruction) (s : Config) (out : Option Config) : Prop :=
  ∃ ticks, 0 < ticks ∧ run program ticks s = out

theorem Reaches.one {program : Nat → Instruction} {s : Config} {out : Option Config}
    (h : step program s = out) : Reaches program s out := by
  refine ⟨1,by decide,?_⟩
  simp only [run,h]
  cases out <;> rfl

theorem Reaches.trans {program : Nat → Instruction} {s t : Config} {out : Option Config}
    (h₁ : Reaches program s (some t)) (h₂ : Reaches program t out) :
    Reaches program s out := by
  obtain ⟨n,hn,h₁⟩ := h₁
  obtain ⟨m,hm,h₂⟩ := h₂
  refine ⟨n+m,by omega,?_⟩
  rw [run_add,h₁,Option.bind_some,h₂]

def Code.size : Code → Nat
  | .seq a b => a.size + b.size
  | _ => 1

theorem Code.size_positive (code : Code) : 0 < code.size := by
  induction code <;> simp_all [Code.size] <;> omega

/-- Compile the binary control convention to primitive leaf ordinals. -/
def compile (code : Code) (base finish : Nat) (breaks continues : List Nat) :
    List Instruction :=
  match code with
  | .inc r => [.inc r finish]
  | .dec r => [.dec r (breaks[0]?.getD 0) finish]
  | .br n => [.jump (breaks[n-1]?.getD 0)]
  | .cont n => [.jump (continues[n-1]?.getD 0)]
  | .halt => [.halt]
  | .seq a b =>
      compile a base (base+a.size) (finish::breaks) continues ++
      compile b (base+a.size) finish breaks (base::continues)

theorem compile_length (code : Code) (base finish : Nat) (breaks continues : List Nat) :
    (compile code base finish breaks continues).length = code.size := by
  induction code generalizing base finish breaks continues <;>
    simp_all [compile,Code.size]

/-- Every listed primitive instruction agrees with the ambient CFG. -/
def Embedded (program : Nat → Instruction) (code : Code)
    (base finish : Nat) (breaks continues : List Nat) : Prop :=
  ∀ i, (hi : i < code.size) →
    program (base+i) = (compile code base finish breaks continues)[i]'(by
      simpa only [compile_length] using hi)

def target (flow : Flow) (finish : Nat) (breaks continues : List Nat)
    (registers : Registers) : Option Config :=
  match flow with
  | .normal => some ⟨finish,registers⟩
  | .br n => some ⟨breaks[n-1]?.getD 0,registers⟩
  | .cont n => some ⟨continues[n-1]?.getD 0,registers⟩
  | .halt => none

end NF192.Emitter

namespace NF192.Emitter

theorem Embedded.left {program : Nat → Instruction} {a b : Code}
    {base finish : Nat} {breaks continues : List Nat}
    (h : Embedded program (.seq a b) base finish breaks continues) :
    Embedded program a base (base+a.size) (finish::breaks) continues := by
  intro i hi
  have he := h i (show i < (Code.seq a b).size by simp only [Code.size]; omega)
  simp only [compile] at he
  rw [List.getElem_append_left (by simpa only [compile_length] using hi)] at he
  exact he

theorem Embedded.right {program : Nat → Instruction} {a b : Code}
    {base finish : Nat} {breaks continues : List Nat}
    (h : Embedded program (.seq a b) base finish breaks continues) :
    Embedded program b (base+a.size) finish breaks (base::continues) := by
  intro i hi
  have he := h (a.size+i) (show a.size+i < (Code.seq a b).size by
    simp only [Code.size]; omega)
  simp only [compile] at he
  rw [List.getElem_append_right (by simp only [compile_length]; omega)] at he
  simpa only [compile_length,Nat.add_sub_cancel_left,Nat.add_assoc] using he

theorem Eval.compiled {code : Code} {s t : Registers} {flow : Flow}
    (h : Eval code s flow t) (program : Nat → Instruction)
    (base finish : Nat) (breaks continues : List Nat)
    (he : Embedded program code base finish breaks continues) :
    Reaches program ⟨base,s⟩ (target flow finish breaks continues t) := by
  induction h generalizing base finish breaks continues with
  | inc r s =>
      have hp := he 0 (by simp [Code.size])
      simp only [Nat.add_zero,compile,List.getElem_cons_zero] at hp
      exact Reaches.one (by simp only [step,hp,target])
  | dec_pos r s hs =>
      have hp := he 0 (by simp [Code.size])
      simp only [Nat.add_zero,compile,List.getElem_cons_zero] at hp
      have hn : s r ≠ 0 := by omega
      exact Reaches.one (by simp only [step,hp,target,if_neg hn])
  | dec_zero r s hs =>
      have hp := he 0 (by simp [Code.size])
      simp only [Nat.add_zero,compile,List.getElem_cons_zero] at hp
      exact Reaches.one (by simp only [step,hp,target,hs,ite_true])
  | br n s =>
      have hp := he 0 (by simp [Code.size])
      simp only [Nat.add_zero,compile,List.getElem_cons_zero] at hp
      exact Reaches.one (by simp only [step,hp,target])
  | cont n s =>
      have hp := he 0 (by simp [Code.size])
      simp only [Nat.add_zero,compile,List.getElem_cons_zero] at hp
      exact Reaches.one (by simp only [step,hp,target])
  | halt s =>
      have hp := he 0 (by simp [Code.size])
      simp only [Nat.add_zero,compile,List.getElem_cons_zero] at hp
      exact Reaches.one (by simp only [step,hp,target])
  | seq_normal ha hb ia ib =>
      have h₁ := ia _ _ _ _ he.left
      have h₂ := ib _ _ _ _ he.right
      simpa only [target] using h₁.trans h₂
  | seq_br_left ha ia =>
      simpa only [target,Nat.sub_self,List.getElem?_cons_zero,Option.getD_some] using
        ia _ _ _ _ he.left
  | seq_br_left_more ha ia =>
      have h₁ := ia _ _ _ _ he.left
      simpa [target,Nat.add_sub_assoc] using h₁
  | seq_cont_left ha ia =>
      have h₁ := ia _ _ _ _ he.left
      simpa only [target] using h₁
  | seq_halt_left ha ia =>
      have h₁ := ia _ _ _ _ he.left
      simpa only [target] using h₁
  | seq_br_right ha hb ia ib =>
      have h₁ := ia _ _ _ _ he.left
      have h₂ := ib _ _ _ _ he.right
      simpa only [target] using h₁.trans h₂
  | seq_cont_right_more ha hb ia ib =>
      have hb' := ib _ _ _ _ he.right
      simp [target,Nat.add_sub_assoc] at hb'
      have h₁ := ia _ _ _ _ he.left
      simpa [target] using h₁.trans hb'
  | seq_halt_right ha hb ia ib =>
      have h₁ := ia _ _ _ _ he.left
      have h₂ := ib _ _ _ _ he.right
      simpa only [target] using h₁.trans h₂
  | seq_loop ha hb hc ia ib ic =>
      have hb' := ib _ _ _ _ he.right
      simp only [target,Nat.sub_self,List.getElem?_cons_zero,Option.getD_some] at hb'
      exact ((ia _ _ _ _ he.left).trans hb').trans (ic _ _ _ _ he)

end NF192.Emitter
