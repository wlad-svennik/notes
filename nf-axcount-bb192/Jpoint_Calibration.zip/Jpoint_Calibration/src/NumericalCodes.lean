module
public import Init

@[expose] public section

/-!
# The concrete term and formula codes of the 192-state countdown machine

All naturals serve both syntactic sorts. The arithmetic proof of the Cantor
bijection is adapted from NF210.Propositional and NF210.Cantor in the earlier
formalization. This machine has a single primitive object, at code zero.
-/

namespace NF192.Numerical

def pair (x y : Nat) : Nat := (x + y) * (x + y + 1) / 2 + y
def imp (x y : Nat) : Nat := 2 * pair x y
def eqn (x y : Nat) : Nat := 2 * pair x y + 1
def app (x y : Nat) : Nat := 2 * pair x y + 1
def witness (x y : Nat) : Nat := 2 * pair x y + 2
def konst (x : Nat) : Nat := witness x x
def q : Nat := 0
def s : Nat := app q q
def B : Nat := app s q
def goal : Nat := eqn s q

theorem s_is_one : s = 1 := rfl
theorem B_is_three : B = 3 := rfl
theorem goal_is_three : goal = 3 := rfl
theorem zero_is_self_implication : imp 0 0 = 0 := rfl

theorem triangular_ge (n : Nat) : n ≤ n * (n + 1) / 2 := by
  cases n with
  | zero => decide
  | succ n =>
      apply (Nat.le_div_iff_mul_le (by decide : 0 < 2)).mpr
      exact Nat.mul_le_mul_left (n + 1) (by omega)

theorem pair_ge_left (x y : Nat) : x ≤ pair x y := by
  have h := triangular_ge (x + y)
  unfold pair
  omega

theorem pair_ge_right (x y : Nat) : y ≤ pair x y := by
  unfold pair
  omega

theorem imp_ge_left (x y : Nat) : x ≤ imp x y := by
  have h := pair_ge_left x y
  unfold imp
  omega

theorem imp_ge_right (x y : Nat) : y ≤ imp x y := by
  have h := pair_ge_right x y
  unfold imp
  omega

namespace Cantor

def triangle (n : Nat) : Nat := n * (n + 1) / 2

theorem triangle_zero : triangle 0 = 0 := rfl

theorem triangle_succ (n : Nat) : triangle (n + 1) = triangle n + n + 1 := by
  have he : (n + 1) * (n + 1 + 1) = n * (n + 1) + 2 * (n + 1) := by
    simp only [Nat.add_mul, Nat.mul_add, Nat.one_mul, Nat.mul_one]
    omega
  unfold triangle
  rw [he, Nat.add_mul_div_left _ _ (by decide : 0 < 2)]
  omega

theorem triangle_mono {m n : Nat} (h : m ≤ n) : triangle m ≤ triangle n := by
  induction n with
  | zero =>
      have hm : m = 0 := by omega
      subst m
      exact Nat.le_refl _
  | succ n ih =>
      by_cases hm : m ≤ n
      · have ht := ih hm
        rw [triangle_succ]
        omega
      · have he : m = n + 1 := by omega
        subst m
        exact Nat.le_refl _

theorem triangle_strict_mono {m n : Nat} (h : m < n) : triangle m < triangle n := by
  have ht := triangle_mono (show m + 1 ≤ n by omega)
  rw [triangle_succ] at ht
  omega

theorem pair_eq (x y : Nat) : pair x y = triangle (x + y) + y := rfl

theorem pair_lower (x y : Nat) : triangle (x + y) ≤ pair x y := by
  rw [pair_eq]
  omega

theorem pair_upper (x y : Nat) : pair x y < triangle (x + y + 1) := by
  rw [pair_eq, triangle_succ]
  omega

theorem pair_injective {x y u v : Nat} (h : pair x y = pair u v) : x = u ∧ y = v := by
  have sums : x + y = u + v := by
    have hl := pair_lower x y
    have hu := pair_upper x y
    have kl := pair_lower u v
    have ku := pair_upper u v
    by_cases hlt : x + y < u + v
    · have ht := triangle_mono (show x + y + 1 ≤ u + v by omega)
      omega
    · by_cases hgt : u + v < x + y
      · have ht := triangle_mono (show u + v + 1 ≤ x + y by omega)
        omega
      · omega
  rw [pair_eq, pair_eq, sums] at h
  omega

def next (p : Nat × Nat) : Nat × Nat :=
  if p.1 = 0 then (p.2 + 1, 0) else (p.1 - 1, p.2 + 1)

theorem pair_next (p : Nat × Nat) : pair (next p).1 (next p).2 = pair p.1 p.2 + 1 := by
  rcases p with ⟨a,b⟩
  by_cases ha : a = 0
  · subst a
    simpa [next, pair_eq] using triangle_succ b
  · have hs : a - 1 + (b + 1) = a + b := by omega
    simp [next, ha, pair_eq, hs, Nat.add_assoc]

def unpair : Nat → Nat × Nat
  | 0 => (0,0)
  | n + 1 => next (unpair n)

theorem pair_unpair (n : Nat) : pair (unpair n).1 (unpair n).2 = n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [unpair, pair_next, ih]

theorem unpair_pair (x y : Nat) : unpair (pair x y) = (x,y) := by
  have h := pair_injective (pair_unpair (pair x y))
  exact Prod.ext h.1 h.2

theorem unpair_left_le (n : Nat) : (unpair n).1 ≤ n := by
  have h := pair_ge_left (unpair n).1 (unpair n).2
  simpa only [pair_unpair] using h

theorem unpair_right_le (n : Nat) : (unpair n).2 ≤ n := by
  have h := pair_ge_right (unpair n).1 (unpair n).2
  simpa only [pair_unpair] using h

theorem pair_zero_iff (x y : Nat) : pair x y = 0 ↔ x = 0 ∧ y = 0 := by
  constructor
  · intro h
    exact pair_injective (show pair x y = pair 0 0 from h)
  · rintro ⟨rfl,rfl⟩
    rfl

end Cantor
end NF192.Numerical
