module
public import C193Model
public import ArbitraryBooleanCounting
@[expose] public section
namespace NF193.Chart
open FFL.FirstOrder
theorem has_counting_model {V : Type} (A : NF193.Chart V) : RangeNFU.HasCountingModel := by
  letI : ArbitraryBoolean.Basis V :=
    ⟨A.app,A.K,A.B,A.tester,A.tester,A.J,A.k_app,A.b_app,A.ext,A.positive,A.negative,A.goal⟩
  have gap := A.proper_image.2.2
  exact ArbitraryBoolean.countingModel A.J A.J (fun x => A.pointwise x A.J)
    ⟨A.tester,gap.1,gap.2⟩
end NF193.Chart
theorem C193.counting_model_of_nonderivability (h : ¬ C193.Deriv NF192.Numerical.goal) :
    RangeNFU.HasCountingModel := by
  obtain ⟨_, ⟨A⟩⟩ := C193.ground_model_iff_chart.mp (C193.not_deriv_iff_ground_model.mp h)
  exact A.has_counting_model
#print axioms C193.counting_model_of_nonderivability
