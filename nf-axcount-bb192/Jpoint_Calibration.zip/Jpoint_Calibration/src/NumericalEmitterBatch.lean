module
public import NumericalEmitter
public import NumericalAxioms

@[expose] public section

/-! Each expression is read from the emitter's chronological postfix token
stream. The effect lemmas hold for every substitution and every older proof
stack. The first row reads its saved u before reading the increment for a. -/

set_option maxHeartbeats 0
set_option maxRecDepth 50000
namespace NF192.Emitter

open NF192.Numerical

def tokens0 : List Macro :=
  [.push3, .push4, .read4, .imp, .push4, .imp, .push4, .push3, .imp, .push5, .push3, .imp, .imp, .imp]

def tokens1 : List Macro :=
  [.push4, .push5, .ap, .push5, .eqn, .push0, .incTop, .push0, .push4, .ap, .push5, .ap, .eqn, .imp]

def tokens2 : List Macro :=
  [.push3, .push5, .eqn, .push4, .push3, .ap, .push4, .push5, .ap, .eqn, .imp]

def tokens4 : List Macro :=
  [.push5, .push5, .witness, .push4, .ap, .push5, .eqn]

def tokens3 : List Macro :=
  [.push4, .push3, .eqn, .push3, .push5, .ap, .push4, .push5, .ap, .eqn, .imp]

def tokens5 : List Macro :=
  [.push0, .incTop, .incTop, .incTop, .push3, .ap, .push4, .ap, .push5, .ap, .push3, .push5, .push5, .witness, .ap, .push4, .push5, .ap, .ap, .eqn]

def tokens6 : List Macro :=
  [.push4, .push5, .eqn, .push4, .push3, .eqn, .push3, .push5, .eqn, .imp, .imp]

def tokens7 : List Macro :=
  [.push4, .push5, .ap, .push5, .eqn, .push0, .incTop, .incTop, .incTop, .imp, .push0, .incTop, .incTop, .incTop, .push0, .push4, .ap, .push5, .ap, .eqn, .imp]

def tokens9 : List Macro :=
  [.push5, .push4, .push5, .witness, .ap, .push4, .push4, .push5, .witness, .ap, .eqn, .push4, .push5, .eqn, .imp]

theorem effect0 (n t stack c u b delta tail : Nat) :
    tokens0.foldl Frame.apply ⟨n,t,stack,c,u,b,pair delta tail⟩ = ⟨n,row0 (u+delta) b c u,pair t stack,c,u+delta,b,tail⟩ := by
  simp only [tokens0, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row0, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

theorem effect1 (n t stack c a b tail : Nat) :
    tokens1.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,row1 a b,pair t stack,c,a,b,tail⟩ := by
  simp only [tokens1, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row1, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

theorem effect2 (n t stack c a b tail : Nat) :
    tokens2.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,row2 a b c,pair t stack,c,a,b,tail⟩ := by
  simp only [tokens2, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row2, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

theorem effect4 (n t stack c a b tail : Nat) :
    tokens4.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,row4 a b,pair t stack,c,a,b,tail⟩ := by
  simp only [tokens4, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row4, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

theorem effect3 (n t stack c a b tail : Nat) :
    tokens3.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,row3 a b c,pair t stack,c,a,b,tail⟩ := by
  simp only [tokens3, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row3, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

theorem effect5 (n t stack c a b tail : Nat) :
    tokens5.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,row5 a b c,pair t stack,c,a,b,tail⟩ := by
  simp only [tokens5, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row5, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

theorem effect6 (n t stack c a b tail : Nat) :
    tokens6.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,row6 a b c,pair t stack,c,a,b,tail⟩ := by
  simp only [tokens6, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row6, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

theorem effect7 (n t stack c a b tail : Nat) :
    tokens7.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,row7 a b,pair t stack,c,a,b,tail⟩ := by
  simp only [tokens7, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row7, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

theorem effect9 (n t stack c a b tail : Nat) :
    tokens9.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ = ⟨n,row9 a b,pair t stack,c,a,b,tail⟩ := by
  simp only [tokens9, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row9, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

def rowTokens : List Macro :=
  tokens0 ++ tokens1 ++ tokens2 ++ tokens4 ++ tokens3 ++ tokens5 ++ tokens6 ++ tokens7 ++ tokens9

def suffix : List Macro := rowTokens ++ [.clear4,.clear5]
def batchCode : Code := sequence .read5 suffix

/-- Write a succession of conclusions to the top, saving each previous top in
the machine's Cantor-encoded stack. -/
def save (f : Frame) (values : List Nat) : Frame := values.foldl Frame.push f

theorem batch_effect (n t stack c u v y delta tail : Nat) :
    suffix.foldl Frame.apply (Frame.apply ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩ .read5) =
      save ⟨n,t,stack,c,0,0,tail⟩ (rowList (u+delta) (v+y) c u) := by
  simp only [suffix, rowTokens, List.foldl_append, Frame.apply, Cantor.unpair_pair]
  rw [effect0, effect1, effect2, effect4, effect3, effect5, effect6, effect7, effect9]
  rfl

theorem batch_eval (n t stack c u v y delta tail : Nat) :
    Eval batchCode (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩) .normal
      (save ⟨n,t,stack,c,0,0,tail⟩ (rowList (u+delta) (v+y) c u)).regs := by
  rw [← batch_effect n t stack c u v y delta tail]
  exact sequence_eval .read5 suffix _

theorem all_nine_derivable (c u v y delta : Nat) :
    ∀ x ∈ rowList (u+delta) (v+y) c u, Deriv x :=
  rows_derivable _ _ _ _ (by omega)

end NF192.Emitter
