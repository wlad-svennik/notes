module

public import Foundation.FirstOrder.LK.Completeness.CounterModel
public import Foundation.Vorspiel.ExistsUnique

@[expose] public section
set_option autoImplicit true
/-!
# (Direct) Interpretation
-/

namespace FFL.FirstOrder

@[ext]
structure DirectTranslation {L₁ : Language} [L₁.Eq] (T : Theory L₁) [𝗘𝗤 _ ⪯ T] (L₂ : Language)
    [L₂.Eq] where
  domain : Semiformula.Operator L₁ 1
  rel {k} : L₂.Rel k → Semiformula.Operator L₁ k
  func {k} : L₂.Func k → Semiformula.Operator L₁ (k + 1)
  domain_nonempty :
    T ⊢ “∃ x, %domain x”
  func_defined {k} (f : L₂.Func k) :
    T ⊢ ∀¹* “(⋀ i, %domain #(i : Fin k)) → ∃! y, %domain y ∧ %(func f) y ⋯”
  preserve_eq :
    T ⊢ “∀ x y, %domain x → %domain y → (%(rel Language.Eq.eq) x y ↔ x = y)”

namespace DirectTranslation

variable {L₁ L₂ : Language} [L₁.Eq] [L₂.Eq] {T : Theory L₁} [𝗘𝗤 _ ⪯ T]

variable (π : DirectTranslation T L₂)

def fal (φ : Semiformula L₁ ξ (n + 1)) : Semiformula L₁ ξ n := ∀¹[π.domain.operator ![#0]] φ

def exs (φ : Semiformula L₁ ξ (n + 1)) : Semiformula L₁ ξ n := ∃¹[π.domain.operator ![#0]] φ

notation:64 "∀_[" π "] " ψ => fal π ψ
notation:64 "∃_[" π "] " ψ => exs π ψ

@[simp] lemma neg_fal (φ : Semiformula L₁ ξ (n + 1)) : ∼(∀_[π] φ) = ∃_[π] ∼φ := by simp [fal, exs]

@[simp] lemma neg_exs (φ : Semiformula L₁ ξ (n + 1)) : ∼(∃_[π] φ) = ∀_[π] ∼φ := by simp [fal, exs]

def varEqual : Semiterm L₂ ξ n → Semiformula L₁ ξ (n + 1)
  |                     #x => “z. z = #x.succ”
  |                     &x => “z. z = &x”
  | .func (arity := k) f v =>
    ∀¹^[k] (
      (Matrix.conj fun i ↦
        π.domain.operator ![#(i.addCast (n + 1))] ⋏
        Rew.subst (#(i.addCast (n + 1)) :> fun j ↦ #((j.addNat 1).addNat k)) ▹ varEqual (v i))
      🡒 (π.func f).operator
        (#((0 : Fin (n + 1)).addNat k) :> fun i ↦ #(i.addCast (n + 1)))
    )

def translateRel {k} (r : L₂.Rel k) (v : Fin k → Semiterm L₂ ξ n) : Semiformula L₁ ξ n :=
  ∀¹^[k] (
    (Matrix.conj fun i ↦
      π.domain.operator ![#(i.addCast n)] ⋏
      Rew.subst (#(i.addCast n) :> fun j ↦ #(j.addNat k)) ▹ π.varEqual (v i))
    🡒 (π.rel r).operator (fun i ↦ #(i.addCast n))
  )

def translateAux {n} : Semiformula L₂ ξ n → Semiformula L₁ ξ n
  | .rel r v  => π.translateRel r v
  | .nrel r v => ∼π.translateRel r v
  |         ⊤ => ⊤
  |         ⊥ => ⊥
  |     φ ⋏ ψ => translateAux φ ⋏ translateAux ψ
  |     φ ⋎ ψ => translateAux φ ⋎ translateAux ψ
  |      ∀¹ φ => ∀_[π] translateAux φ
  |      ∃¹ φ => ∃_[π] translateAux φ

lemma translateAux_neg {n : ℕ} (φ : Semiformula L₂ ξ n) :
    π.translateAux (∼φ) = ∼π.translateAux φ := by
  induction φ using Semiformula.rec' <;> simp [translateAux, *]

def translate : Semiformula L₂ ξ n →ˡᶜ Semiformula L₁ ξ n where
  toTr := π.translateAux
  map_top' := rfl
  map_bot' := rfl
  map_and' := fun _ _ ↦ rfl
  map_or' := fun _ _ ↦ rfl
  map_neg' := by simp [translateAux_neg]
  map_imply' := by simp [Semiformula.imp_eq, translateAux, translateAux_neg, ←Semiformula.neg_eq]

variable {π}

lemma translate_rel {k} (R : L₂.Rel k) (v : Fin k → Semiterm L₂ ξ n) :
    π.translate (Semiformula.rel R v) = π.translateRel R v := rfl

lemma translate_nrel {k} (R : L₂.Rel k) (v : Fin k → Semiterm L₂ ξ n) :
    π.translate (Semiformula.nrel R v) = ∼π.translateRel R v := rfl

lemma translate_all (φ : Semiformula L₂ ξ (n + 1)) :
    π.translate (∀¹ φ) = ∀_[π] π.translate φ := rfl

lemma translate_ex (φ : Semiformula L₂ ξ (n + 1)) :
    π.translate (∃¹ φ) = ∃_[π] π.translate φ := rfl

section semantics

open Semiformula

variable {M : Type*} [Tarski.Structure L₁ M]

variable (π)

def Dom (x : M) : Prop := π.domain.val ![x]

variable {π}

lemma dom_iff {x : M} : π.Dom x ↔ π.domain.val ![x] := iff_of_eq rfl

lemma domain_exists [Nonempty M] [M↓[L₁] ⊧* T] : ∃ x : M, π.Dom x := by
  simpa [models_iff] using! models_of_provable (M := M) inferInstance π.domain_nonempty

variable (π M)

@[pp_using_anonymous_constructor, ext]
structure Model where
  val : M
  dom : π.Dom val

variable {π M}

attribute [coe] Model.val

instance : CoeOut (π.Model M) M := ⟨Model.val⟩

namespace Model

@[simp] lemma pval_sub_domain (x : π.Model M) : π.domain.val ![(x : M)] := x.dom

instance [Nonempty M] [M↓[L₁] ⊧* T] : Nonempty (π.Model M) := by
  rcases π.domain_exists (M := M) with ⟨x, hx⟩; exact ⟨⟨x, hx⟩⟩

@[simp] lemma coe_mem_domain (x : π.Model M) : π.Dom (x : M) := x.dom

@[simp] lemma val_mk (x : M) (hx : π.Dom x) : ↑(⟨x, hx⟩ : π.Model M) = x := rfl

@[simp] lemma eta (x : π.Model M) (h : π.Dom (x : M)) : (⟨(x : M), h⟩ : π.Model M) = x := rfl

@[simp] lemma val_inj_iff {x y : π.Model M} : x.val = y.val ↔ x = y :=
  ⟨fun h ↦ by ext; exact h, by rintro rfl; rfl⟩

@[simp] lemma val_mk_eq_iff {x y : M} {hx : π.Dom x} {hy : π.Dom y} :
    (⟨x, hx⟩ : π.Model M) = (⟨y, hy⟩ : π.Model M) ↔ x = y := by simp

lemma forall_iff {P : π.Model M → Prop} :
    (∀ x, P x) ↔ ∀ x hx, P ⟨x, hx⟩ :=
  ⟨fun h x hx ↦ h ⟨x, hx⟩, fun h ⟨x, hx⟩ ↦ h x hx⟩

lemma exists_iff {P : π.Model M → Prop} :
    (∃ x, P x) ↔ ∃ x hx, P ⟨x, hx⟩ :=
  ⟨fun ⟨⟨x, hx⟩, h⟩ ↦ ⟨x, hx, h⟩, fun ⟨x, hx, h⟩ ↦ ⟨⟨x, hx⟩, h⟩⟩

@[simp] lemma eval_fal {φ : Semiformula L₁ ξ (n + 1)} :
    Semiformula.Eval (M := M) e ε (∀_[π] φ) ↔
      ∀ x : π.Model M, Semiformula.Eval (M := M) (x :> e) ε φ := by
  simp [fal, forall_iff, Dom]

@[simp] lemma eval_exs {φ : Semiformula L₁ ξ (n + 1)} :
    Semiformula.Eval (M := M) e ε (∃_[π] φ) ↔
      ∃ x : π.Model M, Semiformula.Eval (M := M) (x :> e) ε φ := by
  simp [exs, exists_iff, Dom]

variable [Nonempty M] [M↓[L₁] ⊧* T] [Tarski.Structure.Eq L₁ M]

lemma func_existsUnique_on_dom {k} (f : L₂.Func k) :
    ∀ (v : Fin k → M), (∀ i, π.Dom (v i)) → ∃! y, π.Dom y ∧ (π.func f).val (y :> v) := by
  simpa [Dom, models_iff, Function.comp_def, Matrix.constant_eq_singleton] using
    models_of_provable (M := M) inferInstance (π.func_defined f)

lemma func_existsUnique {k} (f : L₂.Func k) (v : Fin k → π.Model M) :
    ∃! y : π.Model M, (π.func f).val ((y : M) :> fun i ↦ (v i : M)) := by
  have : ∃! y, π.Dom y ∧ (π.func f).val (y :> fun i ↦ (v i : M)) :=
    func_existsUnique_on_dom (π := π) f (fun i ↦ (v i : M)) (fun i ↦ by simp)
  rcases this.exists with ⟨y, hy, Hy⟩
  exact ExistsUnique.intro ⟨y, hy⟩ (by simpa using Hy)
    fun z Hz ↦ by
      rcases show y = ↑z from this.unique ⟨hy, Hy⟩ ⟨z.dom, Hz⟩
      simp

variable (π M)

noncomputable instance struc : Tarski.Structure L₂ (π.Model M) where
  rel _ R v := (π.rel R).val fun i ↦ (v i : M)
  func _ f v := Classical.choose! (func_existsUnique (π := π) f v)

variable {π M}

lemma rel_iff {k} (r : L₂.Rel k) (v : Fin k → π.Model M) :
    Tarski.Structure.rel r v ↔ (π.rel r).val (fun i ↦ (v i : M)) := iff_of_eq rfl

@[simp] lemma eq_iff' {a b : π.Model M} :
    (π.rel Language.Eq.eq).val ![(a : M), (b : M)] ↔ a = b := by
  have : M↓[L₁] ⊧* T := inferInstance
  have : ∀ x y : M, π.Dom x → π.Dom y → ((π.rel Language.Eq.eq).val ![x, y] ↔ x = y) := by
    simpa [models_iff, Matrix.comp_vecCons', Matrix.constant_eq_singleton, ←dom_iff]
      using models_of_provable this π.preserve_eq
  simpa using this a b

@[simp] lemma eq_iff (v : Fin 2 → π.Model M) :
    Tarski.Structure.rel (Language.Eq.eq : L₂.Rel 2) v ↔ v 0 = v 1 := by
  simp [Model.rel_iff]
  simp [Matrix.fun_eq_vec_two (v := fun i ↦ (v i : M))]

instance : Tarski.Structure.Eq L₂ (π.Model M) where
  eq a b := by simp [Operator.val, Operator.Eq.sentence_eq, eval_rel]

lemma func_iff {k} {f : L₂.Func k} {y : π.Model M} {v : Fin k → π.Model M} :
    y = Tarski.Structure.func f v ↔ (π.func f).val (↑y :> fun i ↦ (v i : M)) :=
  Classical.choose!_eq_iff_right _

lemma func_iff' {k} {f : L₂.Func k} {y : M} {v : Fin k → π.Model M} :
    y = Tarski.Structure.func f v ↔ π.Dom y ∧ (π.func f).val (y :> fun i ↦ (v i : M)) := by
  constructor
  · rintro rfl; simp [←func_iff]
  · intro h
    exact (func_existsUnique_on_dom f (fun i ↦ (v i : M)) (by simp)).unique h (by simp [←func_iff])

@[simp] lemma eval_func {k} (f : L₂.Func k) (v : Fin k → π.Model M) :
    (π.func f).val (↑(Tarski.Structure.func f v) :> fun i ↦ (v i : M)) := by simp [←func_iff]

lemma eval_varEqual_iff {t : Semiterm L₂ ξ n} {ε : ξ → π.Model M} {y : π.Model M}
    {x : Fin n → π.Model M} :
    Semiformula.Eval (M := M) (y :> fun i ↦ x i) (fun x ↦ ε x) (π.varEqual t) ↔
      y = t.val (M := π.Model M) x ε := by
  match t with
  |                     #_ => simp [varEqual]
  |                     &_ => simp [varEqual]
  | .func (arity := k) f v =>
    suffices
        (∀ w : Fin k → M,
          (∀ i, π.Dom (w i) ∧
            Semiformula.Eval (M := M) (w i :> fun i ↦ x i) (fun x ↦ ε x) (π.varEqual (v i))) →
            (π.func f).val ((y : M) :> w)) ↔
      (π.func f).val ((y : M) :> fun i ↦ ((v i).val (M := π.Model M) x ε : M)) by
        simpa [varEqual, Matrix.comp_vecCons', Matrix.constant_eq_singleton,
          Semiterm.val_func, Semiterm.val_rew, func_iff, ←dom_iff, Function.comp_def]
    constructor
    · intro h; apply h
      intro i
      simp [eval_varEqual_iff (t := v i)]
    · intro h w hw
      suffices w = fun i ↦ ↑((v i).val (M := π.Model M) x ε) by rcases this; exact h
      ext i
      let w' : π.Model M := ⟨w i, (hw i).1⟩
      have : Semiformula.Eval (M := M) (w' :> fun i ↦ x i) (fun x ↦ ε x) (π.varEqual (v i)) := by
        simp [w', hw]
      simpa [w'] using congr_arg Model.val (eval_varEqual_iff.mp this)

lemma eval_translateRel_iff {n k} {ε : ξ → π.Model M} (e : Fin n → π.Model M) (R : L₂.Rel k)
    (v : Fin k → Semiterm L₂ ξ n) :
    Semiformula.Eval (M := M) (fun i ↦ e i) (fun i ↦ ε i) (π.translateRel R v) ↔
      Tarski.Structure.rel R fun i ↦ (v i).val (M := π.Model M) e ε := by
  suffices
    (∀ w, (∀ i, π.Dom (w i) ∧
        Semiformula.Eval (M := M) (w i :> fun i ↦ ↑(e i)) (fun i ↦ ↑(ε i)) (π.varEqual (v i))) →
      (π.rel R).val w) ↔
    (π.rel R).val (fun i ↦ ((v i).val (M := π.Model M) e ε : M)) by
      simpa [translateRel, Matrix.comp_vecCons', rel_iff,
        Matrix.constant_eq_singleton, Semiterm.val_rew, ←dom_iff, Function.comp_def]
  constructor
  · intro h
    exact h (fun i ↦ ↑((v i).val (M := π.Model M) e ε)) (fun i ↦ by simp [eval_varEqual_iff])
  · intro h w hw
    suffices w = fun i ↦ ↑((v i).val (M := π.Model M) e ε) by rcases this; exact h
    ext i
    let w' : π.Model M := ⟨w i, (hw i).1⟩
    have : Semiformula.Eval (M := M) (w' :> fun i ↦ e i) (fun x ↦ ε x) (π.varEqual (v i)) := by
      simp [w', hw]
    simpa [w'] using congr_arg Model.val (eval_varEqual_iff.mp this)

lemma eval_translate_iff {φ : Semiformula L₂ ξ n} {ε : ξ → π.Model M} {e : Fin n → π.Model M} :
    Semiformula.Eval (M := M) (fun i ↦ e i) (fun i ↦ ε i) (π.translate φ) ↔ φ.Eval e ε := by
  match φ with
  |  .rel R v => simp [translate_rel, eval_rel, eval_translateRel_iff, Function.comp_def]
  | .nrel R v => simp [translate_nrel, eval_nrel, eval_translateRel_iff, Function.comp_def]
  |         ⊤ => simp
  |         ⊥ => simp
  |     φ ⋏ ψ => simp [eval_translate_iff (φ := φ), eval_translate_iff (φ := ψ)]
  |     φ ⋎ ψ => simp [eval_translate_iff (φ := φ), eval_translate_iff (φ := ψ)]
  |      ∀¹ φ =>
    simpa [translate_all, Matrix.comp_vecCons'] using
      (forall_congr' fun a : π.Model M ↦ eval_translate_iff (φ := φ) (e := a :> e) (ε := ε))
  |      ∃¹ φ =>
    simpa [translate_ex, Matrix.comp_vecCons'] using
      (exists_congr fun a : π.Model M ↦ eval_translate_iff (φ := φ) (e := a :> e) (ε := ε))

lemma evalb_translate_iff {φ : Semisentence L₂ n} {e : Fin n → π.Model M} :
    M ⊧/(fun i ↦ e i) (π.translate φ) ↔ (π.Model M) ⊧/e φ := by
  simp [←eval_translate_iff, Empty.eq_elim]

lemma evalb_cons_translate_iff {φ : Semisentence L₂ (n + 1)} {x : π.Model M}
    {e : Fin n → π.Model M} :
    M ⊧/(x :> fun i ↦ e i) (π.translate φ) ↔ (π.Model M) ⊧/(x :> e) φ := by
  simp [←eval_translate_iff, Empty.eq_elim, Matrix.comp_vecCons']

lemma evalb_singleton_translate_iff {φ : Semisentence L₂ 1} {x : π.Model M} :
    M ⊧/![x] (π.translate φ) ↔ (π.Model M) ⊧/![x] φ := by
  simp [←eval_translate_iff, Empty.eq_elim, Matrix.constant_eq_singleton]

lemma evalb_doubleton_translate_iff {φ : Semisentence L₂ 2} {x y : π.Model M} :
    M ⊧/![x, y] (π.translate φ) ↔ (π.Model M) ⊧/![x, y] φ := by
  simp [←eval_translate_iff, Empty.eq_elim, Matrix.constant_eq_singleton, Matrix.comp_vecCons']

lemma translate_iff {σ : Sentence L₂} :
    M↓[L₁] ⊧ π.translate σ ↔ (π.Model M)↓[L₂] ⊧ σ := by
  simpa [models_iff, Matrix.empty_eq, Empty.eq_elim] using
    eval_translate_iff (M := M) (π := π) (ε := Empty.elim) (e := ![]) (φ := σ)

end Model

end semantics

variable (T)

protected def id : DirectTranslation T L₁ where
  domain := ⟨⊤⟩
  rel R := ⟨Semiformula.rel R (#·)⟩
  func f := ⟨“z. z = !!(Semiterm.func f (#·.succ))”⟩
  domain_nonempty := by
    apply Theory.Proof.complete_on_eq_models.{_, 0}
    intro M _ _ _ _
    simp [models_iff, Semiformula.Operator.val]
  func_defined {k} f := by
    apply Theory.Proof.complete_on_eq_models.{_, 0}
    intro M _ _ _ _
    simp [models_iff, Semiformula.Operator.val, Semiformula.Operator.Eq.sentence_eq,
      Matrix.comp_vecCons',
      Matrix.constant_eq_singleton, Function.comp_def]
  preserve_eq := by
    apply Theory.Proof.complete_on_eq_models.{_, 0}
    intro M _ _ _ _
    simp [models_iff, Semiformula.Operator.val, Semiformula.Operator.Eq.sentence_eq]

lemma id_func_def :
    (DirectTranslation.id T).func f = ⟨“z. z = !!(Semiterm.func f (#·.succ))”⟩ := rfl

lemma id_rel_def : (DirectTranslation.id T).rel R = ⟨Semiformula.rel R (#·)⟩ := rfl

variable {T}

section semantics

open DirectTranslation Semiformula

variable {M : Type*} [Tarski.Structure L₁ M]

@[simp] lemma id_Dom (x : M) : (DirectTranslation.id T).Dom x := by
  simp [dom_iff, DirectTranslation.id, Operator.val]

variable [Nonempty M] [M↓[L₁] ⊧* T] [Tarski.Structure.Eq L₁ M]

@[simp] lemma id_val_eq
    {ε : ξ → (DirectTranslation.id T).Model M} {e : Fin n → (DirectTranslation.id T).Model M}
    {t : Semiterm L₁ ξ n} :
    t.val (M := (DirectTranslation.id T).Model M) e ε =
      t.val (M := M) (fun x ↦ e x) (fun x ↦ ε x) := by
  match t with
  |        #x => simp
  |        &x => simp
  | .func f v =>
    have : ∀ i, (v i).val (M := (DirectTranslation.id T).Model M) e ε =
        (v i).val (M := M) (fun x ↦ e x) (fun x ↦ ε x) := fun i ↦
      id_val_eq (t := v i) (e := e) (ε := ε)
    symm
    simp [Semiterm.val_func, Model.func_iff', id_func_def, Operator.val,
      Operator.Eq.sentence_eq, eval_rel, this, Function.comp_def]

@[simp] lemma id_models_iff
    {ε : ξ → (DirectTranslation.id T).Model M} {e : Fin n → (DirectTranslation.id T).Model M}
    {φ : Semiformula L₁ ξ n} :
    Semiformula.Eval (M := (DirectTranslation.id T).Model M) e ε φ ↔
      Semiformula.Eval (M := M) (fun x ↦ e x) (fun x ↦ ε x) φ := by
  match φ with
  |  .rel R v => simp [eval_rel, Model.rel_iff, id_rel_def, Operator.val, Function.comp_def]
  | .nrel R v =>
    simp [eval_nrel, eval_rel, Model.rel_iff, id_rel_def, Operator.val, Function.comp_def]
  |         ⊤ => simp
  |         ⊥ => simp
  |     φ ⋏ ψ => simp [id_models_iff (φ := φ), id_models_iff (φ := ψ)]
  |     φ ⋎ ψ => simp [id_models_iff (φ := φ), id_models_iff (φ := ψ)]
  |      ∀¹ φ =>
    simp [id_models_iff (φ := φ), Model.forall_iff, Matrix.comp_vecCons']
  |      ∃¹ φ =>
    simp [id_models_iff (φ := φ), Model.exists_iff, Matrix.comp_vecCons']

end semantics

end DirectTranslation

class DirectInterpretation {L₁ L₂ : Language} [L₁.Eq] [L₂.Eq]
    (T : Theory L₁) [𝗘𝗤 _ ⪯ T] (U : Theory L₂) where
  trln : DirectTranslation T L₂
  interpret_theory : ∀ φ ∈ U, T ⊢ trln.translate φ

infix:50 " ⊳ " => DirectInterpretation

abbrev InterpretedBy {L₁ L₂ : Language} [L₁.Eq] [L₂.Eq] (U : Theory L₂) (T : Theory L₁)
    [𝗘𝗤 _ ⪯ T] := T ⊳ U

infix:50 " ⊲ " => InterpretedBy

class MutualDirectInterpretation {L₁ L₂ : Language} [L₁.Eq] [L₂.Eq] (T : Theory L₁) [𝗘𝗤 _ ⪯ T]
    (U : Theory L₂) [𝗘𝗤 _ ⪯ U] where
  r : T ⊳ U
  l : T ⊲ U

infix:50 " ⋈ " => MutualDirectInterpretation

namespace DirectInterpretation

open DirectTranslation

section

variable {L₁ L₂ : Language} [L₁.Eq] [L₂.Eq] {T : Theory L₁} [𝗘𝗤 _ ⪯ T] {U : Theory L₂} (π : T ⊳ U)

@[coe] abbrev translate (φ : Semiformula L₂ ξ n) : Semiformula L₁ ξ n := π.trln.translate φ

abbrev Model (M : Type*) [Tarski.Structure L₁ M] : Type _ := π.trln.Model M

instance {L₁ L₂ : Language} [L₁.Eq] [L₂.Eq] (T : Theory L₁) [𝗘𝗤 _ ⪯ T] (U : Theory L₂) :
    CoeFun (DirectInterpretation T U) (fun _ ↦ Sentence L₂ → Sentence L₁) :=
  ⟨fun π ↦ π.translate⟩

open Classical in
instance model_models_theory {M : Type v} [Nonempty M] [Tarski.Structure L₁ M]
    [Tarski.Structure.Eq L₁ M] (hT : M↓[L₁] ⊧* T) :
    (π.Model M)↓[L₂] ⊧* U :=
  models_theory_iff.mpr fun {σ} hσ ↦
    Model.translate_iff.mp <| models_of_provable hT (π.interpret_theory σ hσ)

/-- The soundness of a direct interpretation. -/
lemma sound : U ⊢ σ → T ⊢ π σ := fun h ↦
  Theory.Proof.complete_on_eq_models.{_, 0} _ fun _ _ _ _ hT ↦
    Model.translate_iff.mpr <| models_of_provable (π.model_models_theory hT) h

end

abbrev ofWeakerThan {L : Language} [L.Eq] (T U : Theory L) [𝗘𝗤 _ ⪯ T] [U ⪯ T] : U ⊲ T where
  trln := DirectTranslation.id T
  interpret_theory φ hφ := by
    apply Theory.Proof.complete_on_eq_models.{_, 0}
    intro M _ _ _ hT
    have : U ⪯ T := inferInstance
    exact Model.translate_iff.mpr <| by
      suffices M ⊧/![] φ by simpa [models_iff, Empty.eq_elim, Matrix.empty_eq]
      have : T ⊢ φ := Entailment.weakerThan_iff.mp this (Entailment.by_axm (by simp [hφ]))
      exact models_of_provable hT this

protected instance refl {L : Language} [L.Eq] (T : Theory L) [𝗘𝗤 _ ⪯ T] : T ⊳ T := ofWeakerThan T T

section composition

variable {L₁ L₂ L₃ : Language} [L₁.Eq] [L₂.Eq] [L₃.Eq] {T₁ : Theory L₁} {T₂ : Theory L₂}
    {T₃ : Theory L₃} [𝗘𝗤 _ ⪯ T₁] [𝗘𝗤 _ ⪯ T₂] [𝗘𝗤 _ ⪯ T₃]

abbrev translateOperator (π : T₁ ⊳ T₂) (o : Semiformula.Operator L₂ k) :
    Semiformula.Operator L₁ k := ⟨π.translate o.sentence⟩

def compDirectTranslation (τ : DirectTranslation T₂ L₃) (π : T₁ ⊳ T₂) :
    DirectTranslation T₁ L₃ where
  domain := π.trln.domain.and (π.translateOperator τ.domain)
  domain_nonempty := by
    simpa [translate_ex, exs, Semiformula.Operator.operator,
      Semiformula.Operator.and, Rewriting.emb]
      using! π.sound τ.domain_nonempty
  rel R := π.translateOperator (τ.rel R)
  func {k} f := π.translateOperator (τ.func f)
  func_defined {k} f := by
    apply Theory.Proof.complete_on_eq_models.{_, 0}
    intro M _ _ _ hT
    apply models_iff.mpr
    suffices
      ∀ w,
      (∀ i, π.trln.Dom (w i) ∧ M ⊧/![w i] (π.translate τ.domain.sentence)) →
        ∃! x,
          (π.trln.Dom x ∧ M ⊧/![x] (π.translate τ.domain.sentence)) ∧
            M ⊧/(x :> w) (π.translate (τ.func f).sentence) by
      simpa [Matrix.constant_eq_singleton, Model.eval_translate_iff, ←dom_iff]
    intro w hw
    have iT₂ : (π.Model M)↓[L₂] ⊧* T₂ := π.model_models_theory hT
    let w' : Fin k → π.Model M := fun i ↦ ⟨w i, (hw i).1⟩
    obtain ⟨y, hy, hu⟩ := Model.func_existsUnique_on_dom (π := τ) f w' (fun i ↦
      Model.evalb_singleton_translate_iff.mp (hw i).2)
    apply ExistsUnique.intro (y : M)
    · rw [show w = (fun i ↦ (w' i : M)) from rfl]
      simpa [Dom, Model.evalb_cons_translate_iff, Model.evalb_singleton_translate_iff,
        ←Semiformula.Operator.val.eq_def] using And.intro y.dom hy
    · rintro z ⟨⟨hz, hhz⟩, hf⟩
      exact congrArg Model.val (hu ⟨z, hz⟩ ⟨Model.evalb_singleton_translate_iff.mp hhz,
        Model.evalb_cons_translate_iff.mp hf⟩)
  preserve_eq := by
    apply Theory.Proof.complete_on_eq_models.{_, 0}
    intro M _ _ _ hT
    apply models_iff.mpr
    have : (π.Model M)↓[L₂] ⊧* T₂ := π.model_models_theory hT
    suffices
      ∀ (x y : M),
        π.trln.Dom x → M ⊧/![x] (π.translate τ.domain.sentence) →
        π.trln.Dom y → M ⊧/![y] (π.translate τ.domain.sentence) →
          (M ⊧/![x, y] (π.translate (τ.rel Language.Eq.eq).sentence) ↔ x = y) by
      simpa [Matrix.comp_vecCons', Matrix.constant_eq_singleton, Model.eval_translate_iff, ←dom_iff]
    intro x y hx hhx hy hhy
    simpa [Semiformula.Operator.val, ←Model.evalb_doubleton_translate_iff,
      ←Model.val_inj_iff] using
      (Model.eq_iff' (π := τ) (M := π.Model M)
        (a := ⟨⟨x, hx⟩, Model.evalb_singleton_translate_iff.mp hhx⟩)
        (b := ⟨⟨y, hy⟩, Model.evalb_singleton_translate_iff.mp hhy⟩))

@[simp] lemma compDirectTranslation_domain_def (τ : DirectTranslation T₂ L₃) (π : T₁ ⊳ T₂) :
    (compDirectTranslation τ π).domain = π.trln.domain.and (π.translateOperator τ.domain) := rfl

@[simp] lemma compDirectTranslation_func_def (τ : DirectTranslation T₂ L₃) (π : T₁ ⊳ T₂)
    (f : L₃.Func k) :
    (compDirectTranslation τ π).func f = π.translateOperator (τ.func f) := rfl

@[simp] lemma compDirectTranslation_rel_def (τ : DirectTranslation T₂ L₃) (π : T₁ ⊳ T₂)
    (R : L₃.Rel k) :
    (compDirectTranslation τ π).rel R = π.translateOperator (τ.rel R) := rfl

section semantics

open Semiformula

variable (τ : DirectTranslation T₂ L₃) (π : T₁ ⊳ T₂)
    {M : Type*} [Nonempty M] [Tarski.Structure L₁ M] [Tarski.Structure.Eq L₁ M] [M↓[L₁] ⊧* T₁]

omit [𝗘𝗤 L₂ ⪯ T₂] in
@[simp] lemma translateOperator_val_iff (o : Semiformula.Operator L₂ k) (e : Fin k → π.Model M) :
    (π.translateOperator o).val (fun i ↦ (e i : M)) ↔ o.val e := by
  simpa [translateOperator, Semiformula.Operator.val] using
    Model.evalb_translate_iff (π := π.trln) (e := e) (φ := o.sentence)

lemma compDirectTranslation_Dom_iff {x : M} :
    (compDirectTranslation τ π).Dom x ↔ (∃ z : τ.Model (π.Model M), x = z) := by
  simp [Dom, Model.exists_iff, Operator.val, Operator.and,
    ←Model.evalb_singleton_translate_iff, and_comm]

lemma val_compDirectTranslation_Model_equiv {t : Semiterm L₃ ξ n}
    {ε : ξ → (compDirectTranslation τ π).Model M} {ε' : ξ → τ.Model (π.Model M)}
    (hε : ∀ x, (ε x : M) = ε' x)
    {e : Fin n → (compDirectTranslation τ π).Model M} {e' : Fin n → τ.Model (π.Model M)}
    (he : ∀ x, (e x : M) = e' x) :
    (t.val (M := (compDirectTranslation τ π).Model M) e ε : M) =
      t.val (M := τ.Model (π.Model M)) e' ε' := by
  match t with
  |        #x => simp [he]
  |        &x => simp [hε]
  | .func f v =>
    have ih : ∀ i, ((v i).val (M := (compDirectTranslation τ π).Model M) e ε : M) =
        (v i).val (M := τ.Model (π.Model M)) e' ε' :=
      fun i ↦ val_compDirectTranslation_Model_equiv hε he
    suffices
      (↑(Tarski.Structure.func f fun i ↦ (v i).val (M := τ.Model (π.Model M)) e' ε') : M) =
      (Tarski.Structure.func f fun i ↦ (v i).val (M := (compDirectTranslation τ π).Model M) e ε) by
      symm; simpa [Semiterm.val_func]
    apply Model.func_iff'.mpr
    constructor
    · simp [compDirectTranslation_Dom_iff]
    · simpa [Operator.val, Model.evalb_cons_translate_iff, ih] using
        (Model.eval_func (π := τ) f (fun i ↦ (v i).val e' ε'))

lemma eval_compDirectTranslation_Model_equiv {φ : Semiformula L₃ ξ n}
    {ε : ξ → (compDirectTranslation τ π).Model M} {ε' : ξ → τ.Model (π.Model M)}
    (hε : ∀ x, (ε x : M) = ε' x)
    {e : Fin n → (compDirectTranslation τ π).Model M} {e' : Fin n → τ.Model (π.Model M)}
    (he : ∀ x, (e x : M) = e' x) :
    φ.Eval e ε ↔ φ.Eval e' ε' := by
  match φ with
  | .rel R v | .nrel R v =>
    have ih : ∀ i, ((v i).val (M := (compDirectTranslation τ π).Model M) e ε : M) =
        (v i).val (M := τ.Model (π.Model M)) e' ε' :=
      fun i ↦ val_compDirectTranslation_Model_equiv τ π hε he
    simp [eval_rel, eval_nrel, Model.rel_iff, translateOperator_val_iff, ih]
  | ⊤ => simp
  | ⊥ => simp
  | φ ⋏ ψ => simp [eval_compDirectTranslation_Model_equiv (φ := φ) hε he,
      eval_compDirectTranslation_Model_equiv (φ := ψ) hε he]
  | φ ⋎ ψ => simp [eval_compDirectTranslation_Model_equiv (φ := φ) hε he,
      eval_compDirectTranslation_Model_equiv (φ := ψ) hε he]
  | ∀¹ φ =>
    simp only [eval_all, Nat.succ_eq_add_one]
    constructor
    · intro h x
      apply (eval_compDirectTranslation_Model_equiv hε ?_).mp <| h
          ⟨x, by simp [compDirectTranslation_Dom_iff]⟩
      intro i; cases i using Fin.cases <;> simp [he]
    · intro h x
      rcases (compDirectTranslation_Dom_iff τ π).mp x.dom with ⟨z, hz⟩
      apply (eval_compDirectTranslation_Model_equiv hε ?_).mpr (h z)
      · intro i; cases i using Fin.cases <;> simp [he, hz]
  | ∃¹ φ =>
    simp only [eval_ex, Nat.succ_eq_add_one]
    constructor
    · rintro ⟨x, hx⟩
      rcases (compDirectTranslation_Dom_iff τ π).mp x.dom with ⟨z, hz⟩
      refine ⟨z, ?_⟩
      apply (eval_compDirectTranslation_Model_equiv hε ?_).mp hx
      intro i; cases i using Fin.cases <;> simp [he, hz]
    · rintro ⟨x, hx⟩
      refine ⟨⟨x, by simp [compDirectTranslation_Dom_iff]⟩, ?_⟩
      apply (eval_compDirectTranslation_Model_equiv hε ?_).mpr hx
      intro i; cases i using Fin.cases <;> simp [he]

instance compDirectTranslation_Model_equiv :
    (compDirectTranslation τ π).Model M ≡ₑ[L₃] τ.Model (π.Model M) := .mk <| fun {φ} ↦ by
  simp only [models_iff]
  constructor
  · intro h
    apply (eval_compDirectTranslation_Model_equiv τ π (by simp) (by simp)).mp h
  · intro h
    exact (eval_compDirectTranslation_Model_equiv τ π (by simp) (by simp)).mpr h

end semantics

protected abbrev comp (τ : T₂ ⊳ T₃) (π : T₁ ⊳ T₂) : T₁ ⊳ T₃ where
  trln := compDirectTranslation τ.trln π
  interpret_theory φ hφ := by
    apply Theory.Proof.complete_on_eq_models.{_, 0}
    intro M _ _ _ hT
    apply models_iff.mpr
    suffices (τ.Model (π.Model M))↓[L₃] ⊧ φ by
      apply Model.translate_iff.mpr <| (compDirectTranslation_Model_equiv τ.trln π).models.mpr this
    have : (τ.Model (π.Model M))↓[L₃] ⊧* T₃ := inferInstance
    exact models_theory_iff.mp this _ hφ

end composition

end DirectInterpretation

namespace MutualDirectInterpretation

variable {L₁ L₂ L₃ : Language} [L₁.Eq] [L₂.Eq] [L₃.Eq] {T₁ : Theory L₁} {T₂ : Theory L₂}
    {T₃ : Theory L₃} [𝗘𝗤 _ ⪯ T₁] [𝗘𝗤 _ ⪯ T₂] [𝗘𝗤 _ ⪯ T₃]

protected instance refl (T : Theory L₁) [𝗘𝗤 _ ⪯ T] : T ⋈ T :=
  ⟨DirectInterpretation.refl T, DirectInterpretation.refl T⟩

protected abbrev symm (π : T₁ ⋈ T₂) : T₂ ⋈ T₁ := ⟨π.l, π.r⟩

protected abbrev trans (π : T₁ ⋈ T₂) (τ : T₂ ⋈ T₃) : T₁ ⋈ T₃ := ⟨τ.r.comp π.r, π.l.comp τ.l⟩

end MutualDirectInterpretation

end FFL.FirstOrder
