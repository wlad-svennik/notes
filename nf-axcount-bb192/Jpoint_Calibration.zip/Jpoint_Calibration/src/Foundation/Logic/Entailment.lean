module

public import Foundation.Logic.Semantics
public import Foundation.Vorspiel.AdjunctiveSet

/-!
# Basic definitions and properties of proof system related notions

This file defines a characterization of the system/proof/provability/calculus of formulae.
Also defines soundness and completeness.

## Main Definitions
* `FFL.Entailment S F`: a general framework of deductive system `S` for formulae `F`.
* `FFL.Entailment.Inconsistent 𝓢`: a proposition that states that all formulae in `F` is provable
  from `𝓢`.
* `FFL.Entailment.Consistent 𝓢`: a proposition that states that `𝓢` is not inconsistent.
* `FFL.Entailment.Sound 𝓢 𝓜`: provability from `𝓢` implies satisfiability on `𝓜`.
* `FFL.Entailment.Complete 𝓢 𝓜`: satisfiability on `𝓜` implies provability from `𝓢`.

## Notation
* `𝓢 ⊢ φ`: a proposition that states `φ` is provable from `𝓢`.
* `𝓢 ⊬ φ`: a proposition that states `φ` is not provable from `𝓢`.
* `𝓢 ⊢* T`: a proposition that states each formulae in `T` is provable from `𝓢`.

-/


@[expose] public section

namespace FFL

/-- Entailment relation on proof system `S` and formula `F` -/
class Entailment (S : Type*) (F : outParam Type*) where
  Entails : S → F → Prop

infix:45 " ⊢ " => Entailment.Entails

namespace Entailment

variable {F : Type*} {S T U : Type*} [Entailment S F] [Entailment T F] [Entailment U F]

section

variable (𝓢 : S)

/-- Abbreviation for unprovability. -/
abbrev Unprovable (φ : F) : Prop := ¬𝓢 ⊢ φ

infix:45 " ⊬ " => Unprovable

/-- Proposition for existance of proofs of set of formulae. -/
def ProvableSet (s : Set F) : Prop := ∀ {φ}, φ ∈ s → 𝓢 ⊢ φ

infix:45 " ⊢* " => ProvableSet

/-- Set of all provable formulae. -/
def theory : Set F := {φ | 𝓢 ⊢ φ}

end

@[grind ⇒] lemma cast {𝓢 : S} {φ ψ : F} (b : 𝓢 ⊢ φ) (e : φ = ψ := by simp) : 𝓢 ⊢ ψ := e ▸ b

/-- Provability strength relation of proof systems -/
class WeakerThan (𝓢 : S) (𝓣 : T) : Prop where
  subset : theory 𝓢 ⊆ theory 𝓣

infix:40 " ⪯ " => WeakerThan

/-- Strict provability strength relation of proof systems -/
class StrictlyWeakerThan (𝓢 : S) (𝓣 : T) : Prop where
   weakerThan : 𝓢 ⪯ 𝓣
   notWT : ¬𝓣 ⪯ 𝓢

infix:40 " ⪱ " => StrictlyWeakerThan

/-- Provability equivalence relation of proof systems -/
class Equiv (𝓢 : S) (𝓣 : T) : Prop where
  eq : theory 𝓢 = theory 𝓣

infix:40 " ≊ " => Equiv

/-! ### Provability strength -/

section WeakerThan

variable {𝓢 : S} {𝓣 : T} {𝓤 : U}

@[instance, simp, refl] protected lemma WeakerThan.refl (𝓢 : S) : 𝓢 ⪯ 𝓢 := ⟨Set.Subset.refl _⟩

lemma WeakerThan.wk (h : 𝓢 ⪯ 𝓣) {φ} : 𝓢 ⊢ φ → 𝓣 ⊢ φ := @h.subset φ

lemma WeakerThan.pbl [h : 𝓢 ⪯ 𝓣] {φ} : 𝓢 ⊢ φ → 𝓣 ⊢ φ := @h.subset φ

@[trans] lemma WeakerThan.trans : 𝓢 ⪯ 𝓣 → 𝓣 ⪯ 𝓤 → 𝓢 ⪯ 𝓤 :=
  fun w₁ w₂ ↦ ⟨Set.Subset.trans w₁.subset w₂.subset⟩

instance : Trans (α := S) (β := T) (γ := U) (· ⪯ ·) (· ⪯ ·) (· ⪯ ·) where
  trans := WeakerThan.trans

lemma weakerThan_iff : 𝓢 ⪯ 𝓣 ↔ (∀ {φ}, 𝓢 ⊢ φ → 𝓣 ⊢ φ) :=
  ⟨fun h _ hf ↦ h.subset hf, fun h ↦ ⟨fun _ hf ↦ h hf⟩⟩

lemma not_weakerThan_iff : ¬𝓢 ⪯ 𝓣 ↔ (∃ φ, 𝓢 ⊢ φ ∧ 𝓣 ⊬ φ) := by simp [weakerThan_iff, Unprovable];

lemma strictlyWeakerThan_iff : 𝓢 ⪱ 𝓣 ↔ (∀ {φ}, 𝓢 ⊢ φ → 𝓣 ⊢ φ) ∧ (∃ φ, 𝓢 ⊬ φ ∧ 𝓣 ⊢ φ) := by
  constructor
  · rintro ⟨wt, nwt⟩
    exact ⟨weakerThan_iff.mp wt, by
      rcases not_weakerThan_iff.mp nwt with ⟨φ, ht, hs⟩; exact ⟨φ, hs, ht⟩⟩
  · rintro ⟨h, φ, hs, ht⟩
    exact ⟨weakerThan_iff.mpr h, not_weakerThan_iff.mpr ⟨φ, ht, hs⟩⟩

lemma swt_of_swt_of_wt : 𝓢 ⪱ 𝓣 → 𝓣 ⪯ 𝓤 → 𝓢 ⪱ 𝓤 := by
  rintro ⟨h₁, nh₁⟩ h₂
  constructor
  · exact WeakerThan.trans h₁ h₂
  · intro h
    exact nh₁ (WeakerThan.trans h₂ h)

lemma swt_of_wt_of_swt : 𝓢 ⪯ 𝓣 → 𝓣 ⪱ 𝓤 → 𝓢 ⪱ 𝓤 := by
  rintro h₁ ⟨h₂, nh₂⟩
  constructor
  · exact WeakerThan.trans h₁ h₂
  · intro h
    exact nh₂ (WeakerThan.trans h h₁)

instance [𝓢 ⪱ 𝓣] : 𝓢 ⪯ 𝓣 := StrictlyWeakerThan.weakerThan

lemma StrictlyWeakerThan.trans : 𝓢 ⪱ 𝓣 → 𝓣 ⪱ 𝓤 → 𝓢 ⪱ 𝓤 :=
  fun h₁ h₂ ↦ swt_of_swt_of_wt h₁ h₂.weakerThan

instance : Trans (α := S) (β := T) (γ := U) (· ⪱ ·) (· ⪯ ·) (· ⪱ ·) where
  trans := swt_of_swt_of_wt

instance : Trans (α := S) (β := T) (γ := U) (· ⪯ ·) (· ⪱ ·) (· ⪱ ·) where
  trans := swt_of_wt_of_swt

instance : Trans (α := S) (β := T) (γ := U) (· ⪱ ·) (· ⪱ ·) (· ⪱ ·) where
  trans := StrictlyWeakerThan.trans

lemma weakening (h : 𝓢 ⪯ 𝓣) {φ} : 𝓢 ⊢ φ → 𝓣 ⊢ φ := weakerThan_iff.mp h

lemma StrictlyWeakerThan.of_unprovable_provable {𝓢 : S} {𝓣 : T} [𝓢 ⪯ 𝓣] {φ : F}
    (hS : 𝓢 ⊬ φ) (hT : 𝓣 ⊢ φ) : 𝓢 ⪱ 𝓣 := ⟨inferInstance, fun h ↦ hS (h.wk hT)⟩

lemma Equiv.iff : 𝓢 ≊ 𝓣 ↔ (∀ φ, 𝓢 ⊢ φ ↔ 𝓣 ⊢ φ) :=
  ⟨fun e ↦ by simpa [Set.ext_iff, theory] using e.eq,
    fun e ↦ ⟨by simpa [Set.ext_iff, theory] using e⟩⟩

@[instance, simp, refl] protected lemma Equiv.refl (𝓢 : S) : 𝓢 ≊ 𝓢 := ⟨rfl⟩

@[symm, grind .] lemma Equiv.symm : 𝓢 ≊ 𝓣 → 𝓣 ≊ 𝓢 := fun e ↦ ⟨Eq.symm e.eq⟩

@[trans] lemma Equiv.trans : 𝓢 ≊ 𝓣 → 𝓣 ≊ 𝓤 → 𝓢 ≊ 𝓤 := fun e₁ e₂ ↦ ⟨Eq.trans e₁.eq e₂.eq⟩

@[grind =]
lemma Equiv.antisymm_iff : 𝓢 ≊ 𝓣 ↔ 𝓢 ⪯ 𝓣 ∧ 𝓣 ⪯ 𝓢 := by
  constructor
  · intro e
    exact ⟨⟨Set.Subset.antisymm_iff.mp e.eq |>.1⟩, ⟨Set.Subset.antisymm_iff.mp e.eq |>.2⟩⟩
  · rintro ⟨w₁, w₂⟩
    exact ⟨Set.Subset.antisymm w₁.subset w₂.subset⟩

alias ⟨_, Equiv.antisymm⟩ := Equiv.antisymm_iff

@[grind ->] lemma Equiv.le : 𝓢 ≊ 𝓣 → 𝓢 ⪯ 𝓣 := fun e ↦ ⟨by rw [e.eq]⟩

instance : Trans (α := S) (β := T) (γ := U) (· ≊ ·) (· ≊ ·) (· ≊ ·) where
  trans := Equiv.trans

instance : Trans (α := S) (β := T) (γ := U) (· ≊ ·) (· ⪯ ·) (· ⪯ ·) where
  trans h₁ h₂ := WeakerThan.trans h₁.le h₂

instance : Trans (α := S) (β := T) (γ := U) (· ≊ ·) (· ≊ ·) (· ⪯ ·) where
  trans h₁ h₂ := WeakerThan.trans h₁.le h₂.le

instance : Trans (α := S) (β := T) (γ := U) (· ⪯ ·) (· ≊ ·) (· ⪯ ·) where
  trans h₁ h₂ := WeakerThan.trans h₁ h₂.le

instance : Trans (α := S) (β := T) (γ := U) (· ≊ ·) (· ⪱ ·) (· ⪱ ·) where
  trans h₁ h₂ := swt_of_wt_of_swt h₁.le h₂

instance : Trans (α := S) (β := T) (γ := U) (· ⪱ ·) (· ≊ ·) (· ⪱ ·) where
  trans h₁ h₂ := swt_of_swt_of_wt h₁ h₂.le

@[grind =]
lemma iff_strictlyWeakerThan_weakerThan_not_equiv : 𝓢 ⪱ 𝓣 ↔ 𝓢 ⪯ 𝓣 ∧ ¬(𝓢 ≊ 𝓣) := by
  constructor
  · rintro ⟨_, _⟩; grind;
  · rintro ⟨_, _⟩; constructor <;> grind;

class Incomparable (𝓢 : S) (𝓣 : T) where
  notWT₁ : ¬𝓢 ⪯ 𝓣
  notWT₂ : ¬𝓣 ⪯ 𝓢

lemma Incomparable.of_unprovable
  (h₁ : ∃ φ, 𝓢 ⊢ φ ∧ 𝓣 ⊬ φ)
  (h₂ : ∃ ψ, 𝓣 ⊢ ψ ∧ 𝓢 ⊬ ψ)
  : Incomparable (𝓢 : S) (𝓣 : T) := by
  constructor <;>
  · apply Entailment.not_weakerThan_iff.mpr;
    assumption;

end WeakerThan

/-! ### Consistency and inconsistency -/

@[simp] lemma provableSet_theory (𝓢 : S) : 𝓢 ⊢* theory 𝓢 := fun hf ↦ hf

def Inconsistent (𝓢 : S) : Prop := ∀ φ, 𝓢 ⊢ φ

class Consistent (𝓢 : S) : Prop where
  not_inconsistent : ¬Inconsistent 𝓢

lemma inconsistent_def {𝓢 : S} :
    Inconsistent 𝓢 ↔ ∀ φ, 𝓢 ⊢ φ := by simp [Inconsistent]

lemma inconsistent_iff_theory_eq {𝓢 : S} :
    Inconsistent 𝓢 ↔ theory 𝓢 = Set.univ := by
  simp [Inconsistent, Set.ext_iff, theory]

@[simp] lemma not_inconsistent_iff_consistent {𝓢 : S} :
    ¬Inconsistent 𝓢 ↔ Consistent 𝓢 :=
  ⟨fun h ↦ ⟨h⟩, by rintro ⟨h⟩; exact h⟩

alias ⟨_, Consistent.not_inc⟩ := not_inconsistent_iff_consistent

@[simp] lemma not_consistent_iff_inconsistent {𝓢 : S} :
    ¬Consistent 𝓢 ↔ Inconsistent 𝓢 := by simp [←not_inconsistent_iff_consistent]

alias ⟨_, Inconsistent.not_con⟩ := not_consistent_iff_inconsistent

lemma consistent_iff_exists_unprovable {𝓢 : S} :
    Consistent 𝓢 ↔ ∃ φ, 𝓢 ⊬ φ := by
  simp [←not_inconsistent_iff_consistent, inconsistent_def]

alias ⟨Consistent.exists_unprovable, _⟩ := consistent_iff_exists_unprovable

lemma Consistent.of_unprovable {𝓢 : S} {φ} (h : 𝓢 ⊬ φ) : Consistent 𝓢 :=
  ⟨fun hp ↦ h (hp φ)⟩

lemma inconsistent_iff_theory_eq_univ {𝓢 : S} :
    Inconsistent 𝓢 ↔ theory 𝓢 = Set.univ := by simp [inconsistent_def, theory, Set.ext_iff]

alias ⟨Inconsistent.theory_eq, _⟩ := inconsistent_iff_theory_eq_univ

lemma Inconsistent.of_ge {𝓢 : S} {𝓣 : T} (h𝓢 : Inconsistent 𝓢) (h : 𝓢 ⪯ 𝓣) : Inconsistent 𝓣 :=
  fun φ ↦ h.subset (h𝓢 φ)

lemma Consistent.of_le {𝓢 : S} {𝓣 : T} (h𝓢 : Consistent 𝓢) (h : 𝓣 ⪯ 𝓢) : Consistent 𝓣 :=
  ⟨fun H ↦ not_consistent_iff_inconsistent.mpr (H.of_ge h) h𝓢⟩

variable (S)

class DeductiveExplosion [LogicalNeutral F] where
  dexp {𝓢 : S} : 𝓢 ⊢ ⊥ → (φ : F) → 𝓢 ⊢ φ

variable {S}

section

variable [LogicalNeutral F] [DeductiveExplosion S]

lemma inconsistent_iff_provable_bot {𝓢 : S} :
    Inconsistent 𝓢 ↔ 𝓢 ⊢ ⊥ := ⟨fun h ↦ h ⊥, fun h φ ↦ DeductiveExplosion.dexp h φ⟩

alias ⟨_, inconsistent_of_provable⟩ := inconsistent_iff_provable_bot

lemma consistent_iff_unprovable_bot {𝓢 : S} :
    Consistent 𝓢 ↔ 𝓢 ⊬ ⊥ := by
  simp [inconsistent_iff_provable_bot, ←not_inconsistent_iff_consistent]

@[simp, grind .] lemma Consistent.not_bot {𝓢 : S} [Consistent 𝓢] : 𝓢 ⊬ ⊥ :=
  consistent_iff_unprovable_bot.mp inferInstance

end

/-! ### Completeness and incompleteness -/

section

variable [Tilde F] (𝓢 : S)

/-- `𝓢` is complete if, for every formula, either it or its negation is provable by `𝓢`. -/
class Complete : Prop where
  con : ∀ φ, 𝓢 ⊢ φ ∨ 𝓢 ⊢ ∼φ

/-- A formula `φ` is independent from `𝓢` if, neither it nor its negation is provable by `𝓢`. -/
def Independent (φ : F) : Prop := 𝓢 ⊬ φ ∧ 𝓢 ⊬ ∼φ

/-- A proof system is incomplete if and only if there exists a formula that is both unprovable
and irrefutable. -/
class Incomplete : Prop where
  indep : ∃ φ, Independent 𝓢 φ

variable {𝓢 : S} {𝓣 : T}

lemma complete_def : Complete 𝓢 ↔ ∀ φ, 𝓢 ⊢ φ ∨ 𝓢 ⊢ ∼φ :=
  ⟨fun h ↦ h.con, Complete.mk⟩

lemma incomplete_def : Incomplete 𝓢 ↔ ∃ φ, Independent 𝓢 φ :=
  ⟨fun h ↦ h.indep, Incomplete.mk⟩

omit [Tilde F] in
lemma Equiv.unprovable (e : 𝓢 ≊ 𝓣) {φ : F} : 𝓢 ⊬ φ ↔ 𝓣 ⊬ φ :=
  not_congr <| Equiv.iff.mp e φ

lemma Equiv.incomplete (e : 𝓢 ≊ 𝓣) : Incomplete 𝓢 → Incomplete 𝓣 := by
  rintro ⟨φ, hφ⟩
  exact ⟨φ, e.unprovable.mp hφ.1, e.unprovable.mp hφ.2⟩

lemma Equiv.incomplete_iff (e : 𝓢 ≊ 𝓣) : Incomplete 𝓢 ↔ Incomplete 𝓣 :=
  ⟨e.incomplete, e.symm.incomplete⟩

@[simp] lemma not_complete_iff_incomplete : ¬Complete 𝓢 ↔ Incomplete 𝓢 := by
  simp [complete_def, incomplete_def, Independent, not_or]

@[simp] lemma not_incomplete_iff_complete : ¬Incomplete 𝓢 ↔ Complete 𝓢 :=
  Iff.symm <| iff_not_comm.mp not_complete_iff_incomplete.symm

instance consistent_of_incomplete [h : Incomplete 𝓢] : Consistent 𝓢 :=
  consistent_iff_exists_unprovable.mpr <| by rcases h.indep with ⟨φ, hφ⟩; exact ⟨φ, hφ.1⟩

end

/-! ### Axiomatized provability -/

variable (S T)

class Axiomatized [AdjunctiveSet F S] where
  prfAxm {𝓢 : S} : 𝓢 ⊢* AdjunctiveSet.set 𝓢
  weakening {𝓢 𝓣 : S} (h : 𝓢 ⊆ 𝓣 := by simp) {φ : F} : 𝓢 ⊢ φ → 𝓣 ⊢ φ

alias wk := Axiomatized.weakening

class StrongCut [AdjunctiveSet F T] where
  cut {𝓢 : S} {𝓣 : T} {φ} : 𝓢 ⊢* AdjunctiveSet.set 𝓣 → 𝓣 ⊢ φ → 𝓢 ⊢ φ

variable {S T}

section Axiomatized

namespace Axiomatized

variable [AdjunctiveSet F S] [Axiomatized S] {𝓢 𝓣 : S} {φ ψ : F}

lemma by_axm {𝓢 : S} (h : φ ∈ 𝓢) : 𝓢 ⊢ φ := prfAxm (by simp [h])

@[simp] lemma provable_refl (𝓢 : S) : 𝓢 ⊢* AdjunctiveSet.set 𝓢 := prfAxm

lemma axm_subset (𝓢 : S) : AdjunctiveSet.set 𝓢 ⊆ theory 𝓢 := fun _ hp ↦ provable_refl 𝓢 hp

@[simp] protected lemma adjoin (φ : F) (𝓢 : S) : adjoin φ 𝓢 ⊢ φ := prfAxm (by simp)

lemma le_of_subset (h : 𝓢 ⊆ 𝓣) : 𝓢 ⪯ 𝓣 := ⟨fun _ ↦ weakening h⟩

abbrev weakerThanOfSubset (h : 𝓢 ⊆ 𝓣) : 𝓢 ⪯ 𝓣 := ⟨fun _ ↦ weakening h⟩

theorem to_adjoin {𝓢 : S} : 𝓢 ⊢ ψ → adjoin φ 𝓢 ⊢ ψ := weakening

end Axiomatized

alias by_axm := Axiomatized.by_axm

section axiomatized

variable [AdjunctiveSet F S] [AdjunctiveSet F T] [Axiomatized S]

def FiniteAxiomatizable (𝓢 : S) : Prop := ∃ 𝓕 : S, AdjunctiveSet.Finite 𝓕 ∧ 𝓕 ≊ 𝓢

lemma Consistent.of_subset {𝓢 𝓣 : S} (h𝓢 : Consistent 𝓢) (h : 𝓣 ⊆ 𝓢) : Consistent 𝓣 :=
  h𝓢.of_le (Axiomatized.le_of_subset h)

lemma Inconsistent.of_supset {𝓢 𝓣 : S} (h𝓢 : Inconsistent 𝓢) (h : 𝓢 ⊆ 𝓣) : Inconsistent 𝓣 :=
  h𝓢.of_ge (Axiomatized.le_of_subset h)

end axiomatized

abbrev WeakerThan.ofAxm! [AdjunctiveSet F S] [StrongCut S S] {𝓢₁ 𝓢₂ : S}
    (B : 𝓢₂ ⊢* AdjunctiveSet.set 𝓢₁) : 𝓢₁ ⪯ 𝓢₂ := ⟨fun _ b ↦ StrongCut.cut B b⟩

abbrev WeakerThan.ofSubset [AdjunctiveSet F S] [Axiomatized S] {𝓢 𝓣 : S} (h : 𝓢 ⊆ 𝓣) : 𝓢 ⪯ 𝓣 :=
  ⟨fun _ ↦ Axiomatized.weakening h⟩

/-! ### Compactness -/

variable (S)

class Compact [AdjunctiveSet F S] where
  finite_provable {𝓢 : S} {φ : F} : 𝓢 ⊢ φ → ∃ 𝓕 : S, 𝓕 ⊆ 𝓢 ∧ AdjunctiveSet.Finite 𝓕 ∧ 𝓕 ⊢ φ

variable {S}

end Axiomatized

end Entailment

namespace Entailment

variable {S : Type*} {F : Type*} [LogicalConnective F] [LogicalNeutral F] [Entailment S F]

section

variable [DeductiveExplosion S] [AdjunctiveSet F S] [Axiomatized S] [Compact S]

omit [LogicalConnective F] in
lemma inconsistent_compact {𝓢 : S} :
    Inconsistent 𝓢 ↔ ∃ 𝓕 : S, 𝓕 ⊆ 𝓢 ∧ AdjunctiveSet.Finite 𝓕 ∧ Inconsistent 𝓕 :=
  ⟨fun H ↦ by
    rcases Compact.finite_provable (H ⊥) with ⟨𝓕, h𝓕, fin, h⟩
    exact ⟨𝓕, h𝓕, fin, inconsistent_of_provable h⟩, by
    rintro ⟨𝓕, h𝓕, _, H⟩; exact H.of_supset h𝓕⟩

omit [LogicalConnective F] in
lemma consistent_compact {𝓢 : S} :
    Consistent 𝓢 ↔ ∀ 𝓕 : S, 𝓕 ⊆ 𝓢 → AdjunctiveSet.Finite 𝓕 → Consistent 𝓕 := by
  simp [←not_inconsistent_iff_consistent, inconsistent_compact (𝓢 := 𝓢)]

end

/-! ### Deduction theorem -/

variable (S)

class Deduction [Adjoin F S] where
  ofInsert {φ ψ : F} {𝓢 : S} : adjoin φ 𝓢 ⊢ ψ → 𝓢 ⊢ φ 🡒 ψ
  inv {φ ψ : F} {𝓢 : S} : 𝓢 ⊢ φ 🡒 ψ → adjoin φ 𝓢 ⊢ ψ

variable {S}

section deduction

variable [Adjoin F S] [Deduction S] {𝓢 : S} {φ ψ : F}

alias deduction := Deduction.ofInsert

omit [LogicalNeutral F] in
lemma deduction_iff : adjoin φ 𝓢 ⊢ ψ ↔ 𝓢 ⊢ φ 🡒 ψ := ⟨deduction, Deduction.inv⟩

end deduction

end Entailment

/-! ### Soundness and Completeness -/

section

variable {S : Type*} {F : Type*} [Entailment S F] {M : Type*} [Semantics M F]

class Sound (𝓢 : S) (𝓜 : M) : Prop where
  sound : ∀ {φ : F}, 𝓢 ⊢ φ → 𝓜 ⊧ φ

class Complete (𝓢 : S) (𝓜 : M) : Prop where
  complete : ∀ {φ : F}, 𝓜 ⊧ φ → 𝓢 ⊢ φ

namespace Sound

section

variable {𝓢 𝓣 : S} {𝓜 𝓝 : M} [Sound 𝓢 𝓜] [Sound 𝓣 𝓝]

lemma not_provable_of_countermodel {φ : F} (hp : 𝓜 ⊭ φ) : 𝓢 ⊬ φ :=
  fun b ↦ hp (Sound.sound b)

lemma consistent_of_meaningful : Semantics.Meaningful 𝓜 → Entailment.Consistent 𝓢 :=
  fun H ↦ ⟨fun h ↦ by rcases H with ⟨φ, hf⟩; exact hf (Sound.sound (h φ))⟩

lemma consistent_of_model [LogicalNeutral F] [Semantics.Bot M] (𝓜 : M) [Sound 𝓢 𝓜] :
    Entailment.Consistent 𝓢 := consistent_of_meaningful (𝓜 := 𝓜) inferInstance

lemma modelsSet_of_prfSet {T : Set F} (b : 𝓢 ⊢* T) : 𝓜 ⊧* T :=
  ⟨fun _ hf ↦ sound (b hf)⟩

end

section

variable {𝓢 : S} {T : Set F} [Sound 𝓢 (Semantics.models M T)]

lemma consequence_of_provable {φ : F} : 𝓢 ⊢ φ → T ⊨[M] φ := sound

lemma consistent_of_satisfiable [∀ 𝓜 : M, Semantics.Meaningful 𝓜] :
    Semantics.Satisfiable M T → Entailment.Consistent 𝓢 :=
  fun H ↦ consistent_of_meaningful (Semantics.meaningful_iff_satisfiableSet.mp H)

end

end Sound

namespace Complete

section

variable {𝓢 : S} {𝓜 : M} [Complete 𝓢 𝓜]

lemma exists_countermodel_of_not_provable {φ : F} (h : 𝓢 ⊬ φ) : 𝓜 ⊭ φ := by
  contrapose! h;
  simpa using Complete.complete (𝓢 := 𝓢) h;

lemma meaningful_of_consistent : Entailment.Consistent 𝓢 → Semantics.Meaningful 𝓜 := by
  contrapose
  suffices (∀ (φ : F), 𝓜 ⊧ φ) → Entailment.Inconsistent 𝓢 by
    simpa [Semantics.not_meaningful_iff, Entailment.not_consistent_iff_inconsistent]
  exact fun h φ ↦ Complete.complete (h φ)

end

section

variable {𝓢 : S} {s : Set F} [Complete 𝓢 (Semantics.models M s)]

lemma provable_of_consequence {φ : F} : s ⊨[M] φ → 𝓢 ⊢ φ := complete

lemma provable_iff_consequence [Sound 𝓢 (Semantics.models M s)] {φ : F} : s ⊨[M] φ ↔ 𝓢 ⊢ φ :=
  ⟨complete, Sound.sound⟩


section

variable [∀ 𝓜 : M, Semantics.Meaningful 𝓜]

lemma satisfiable_of_consistent :
    Entailment.Consistent 𝓢 → Semantics.Satisfiable M s :=
  fun H ↦ Semantics.meaningful_iff_satisfiableSet.mpr (meaningful_of_consistent H)

lemma inconsistent_of_unsatisfiable :
    ¬Semantics.Satisfiable M s → Entailment.Inconsistent 𝓢 := by
  contrapose; simpa [←Entailment.not_consistent_iff_inconsistent] using satisfiable_of_consistent

lemma consistent_iff_satisfiable [Sound 𝓢 (Semantics.models M s)] :
    Entailment.Consistent 𝓢 ↔ Semantics.Satisfiable M s :=
  ⟨satisfiable_of_consistent, Sound.consistent_of_satisfiable⟩

end

lemma weakerthan_of_models {𝓣 : S} {t : Set F} [Sound 𝓣 (Semantics.models M t)]
    (H : ∀ 𝓜 : M, 𝓜 ⊧* s → 𝓜 ⊧* t) : 𝓣 ⪯ 𝓢 :=
  Entailment.weakerThan_iff.mpr <| fun h ↦ provable_of_consequence <|
    fun 𝓜 h𝓜 ↦ Sound.consequence_of_provable (M := M) (T := t) h (H 𝓜 h𝓜)

end

end Complete

end

namespace Entailment

variable (S : Type*) {F G : Type*} [Entailment S F]

structure Pullback (f : G → F) : Type _ where
  forget : S

variable {S}

abbrev pullback (𝓢 : S) (f : G → F) : Pullback S f := ⟨𝓢⟩

instance (f : G → F) : Entailment (Pullback S f) G where
  Entails := fun 𝓢 φ ↦ 𝓢.forget ⊢ f φ

namespace Pullback

section basics

variable {f : G → F}

omit [Entailment S F] in
@[simp] lemma pullback_forget (𝓢 : S) : (pullback 𝓢 f).forget = 𝓢 := rfl

@[simp] lemma provable_iff {𝓢 : S} {φ : G} : pullback 𝓢 f ⊢ φ ↔ 𝓢 ⊢ f φ := by rfl

@[simp] lemma unprovable_iff {𝓢 : S} {φ : G} : pullback 𝓢 f ⊬ φ ↔ 𝓢 ⊬ f φ := by rfl

@[simp] lemma provableSet_iff {𝓢 : S} {s : Set G} : pullback 𝓢 f ⊢* s ↔ 𝓢 ⊢* f '' s := by
  simp [ProvableSet]

@[simp] lemma theory_eq (𝓢 : S) : theory (pullback 𝓢 f) = f ⁻¹' theory 𝓢 := rfl

lemma weakerThan (𝓢 𝓣 : S) (h : 𝓢 ⪯ 𝓣) : pullback 𝓢 f ⪯ pullback 𝓣 f := by
  simp_all [Entailment.weakerThan_iff]

lemma inconsistent {𝓢 : S} : Inconsistent 𝓢 → Inconsistent (pullback 𝓢 f) := by
  simp_all [Inconsistent]

lemma consistent {𝓢 : S} : Consistent (pullback 𝓢 f) → Consistent 𝓢 := by
  contrapose; simpa using inconsistent

end basics

end Pullback

end Entailment

end FFL

end
