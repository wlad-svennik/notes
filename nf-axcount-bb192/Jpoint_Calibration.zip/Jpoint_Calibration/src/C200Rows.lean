module
public import C201Rows
public import NumericalEmitterBatch
public import NumericalSemantics

@[expose] public section

/-! Register effects for the two changed row sequences, with the literal
register assignment and postfix stream taken from the portable source check. -/
set_option maxHeartbeats 0
set_option maxRecDepth 50000
namespace C200
open NF192 NF192.Numerical NF192.Emitter

def scalarRow (a : Nat) : Nat := (eqn (app (app B (app B a)) q) (app B a))

def scalarRowTokens : List Macro := [.push0, .incTop, .incTop, .incTop, .push0, .incTop, .incTop, .incTop, .push4, .ap, .ap, .push0, .ap, .push0, .incTop, .incTop, .incTop, .push4, .ap, .eqn]

theorem scalarRow_effect (n t stack c a b tail : Nat) :
  scalarRowTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
    ⟨n,scalarRow a,pair t stack,c,a,b,tail⟩ := by
  simp only [scalarRowTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
      Cantor.unpair_pair, ctor, scalarRow, imp, eqn, app, witness, B_is_three, s_is_one, q, Nat.add_zero] <;> rfl

def nativeBRow (a b c : Nat) : Nat := (eqn (app (app (app (app (app B q) q) c) a) b) (app (app c (witness b b)) (app a b)))

def nativeBRowTokens : List Macro := [.push0, .incTop, .incTop, .incTop, .push0, .ap, .push0, .ap, .push3, .ap, .push4, .ap, .push5, .ap, .push3, .push5, .push5, .witness, .ap, .push4, .push5, .ap, .ap, .eqn]

theorem nativeBRow_effect (n t stack c a b tail : Nat) :
  nativeBRowTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
    ⟨n,nativeBRow a b c,pair t stack,c,a,b,tail⟩ := by
  simp only [nativeBRowTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
      Cantor.unpair_pair, ctor, nativeBRow, imp, eqn, app, witness, B_is_three, s_is_one, q, Nat.add_zero] <;> rfl

def rowList (a b c u : Nat) : List Nat :=
  [row0 a b c u, row1 a b, nativeBRow a b c, row4 a b, row6 a b c, row7 a b, scalarRow a, row3 a b c, row9 a b, row2 a b c]

def suffix : List Macro := tokens0 ++ tokens1 ++ nativeBRowTokens ++ tokens4 ++ tokens6 ++ tokens7 ++ scalarRowTokens ++ tokens3 ++ tokens9 ++ tokens2 ++ [.clear4,.clear5]

def batchCode : Code := sequence .read5 suffix

theorem batch_effect (n t stack c u v y delta tail : Nat) :
    suffix.foldl Frame.apply (Frame.apply ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩ .read5) =
      save ⟨n,t,stack,c,0,0,tail⟩ (rowList (u+delta) (v+y) c u) := by
  simp only [suffix, List.foldl_append, Frame.apply, Cantor.unpair_pair]
  rw [effect0, effect1, nativeBRow_effect, effect4, effect6, effect7, scalarRow_effect, effect3, effect9, effect2]
  rfl

theorem batch_eval (n t stack c u v y delta tail : Nat) :
    Eval batchCode (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩) .normal
      (save ⟨n,t,stack,c,0,0,tail⟩ (rowList (u+delta) (v+y) c u)).regs := by
  rw [← batch_effect n t stack c u v y delta tail]
  exact sequence_eval .read5 suffix _

inductive Deriv : Nat → Prop where
  | row {a b c u x : Nat} (h : u ≤ a) (hx : x ∈ rowList a b c u) : Deriv x
  | mp {a b : Nat} : Deriv (imp a b) → Deriv a → Deriv b

theorem deriv_zero : Deriv 0 := .row (a:=0) (b:=0) (c:=0) (u:=0) (Nat.le_refl _) (.head _)

theorem row_membership_iff (a b c u x : Nat) :
    x ∈ rowList a b c u ↔ x ∈ C201.rowList a b c u := by
  simp [rowList, C201.rowList, scalarRow, C201.scalarRow, nativeBRow, C201.nativeBRow,
        or_assoc, or_comm, or_left_comm]

theorem deriv_iff_reference (x : Nat) : Deriv x ↔ C201.Deriv x := by
  constructor
  · intro h
    induction h with
    | row h hx => exact .row h ((row_membership_iff _ _ _ _ _).mp hx)
    | mp _ _ h₁ h₂ => exact .mp h₁ h₂
  · intro h
    induction h with
    | row h hx => exact .row h ((row_membership_iff _ _ _ _ _).mpr hx)
    | mp _ _ h₁ h₂ => exact .mp h₁ h₂

end C200
#print axioms C200.deriv_iff_reference
#print axioms C200.scalarRow_effect
#print axioms C200.batch_eval
