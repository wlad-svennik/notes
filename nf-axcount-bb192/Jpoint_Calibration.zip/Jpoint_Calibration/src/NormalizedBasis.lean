module
public import Init

@[expose] public section

/-! The normalized fixed-point tester of the 192-state NF calculus and the
closed term that converts its outputs to the CombNF convention. -/

set_option autoImplicit false
set_option maxHeartbeats 8000000

universe u

namespace NF192

/-- The algebra recovered when the machine's goal is false. Application is
extensional. The fixed-point test returns K(B) on success and B on failure. -/
structure NormalizedBasis (A : Type u) where
  app : A → A → A
  K : A → A
  B : A
  q : A
  k_app : ∀ (x y : A), app (K x) y = x
  b_app : ∀ (x y z : A), app (app (app B x) y) z = app (app x (K z)) (app y z)
  ext : ∀ {f g : A}, (∀ x, app f x = app g x) → f = g
  q_true : ∀ (f x : A), app f x = x → app (app q f) x = K B
  q_false : ∀ (f x : A), app f x ≠ x → app (app q f) x = B
  distinct : K B ≠ B

namespace NormalizedBasis

variable {A : Type u} (S : NormalizedBasis A)

local infixl:70 " ⬝ " => S.app

/-- A tester with these distinct outputs cannot itself have a fixed point. -/
theorem q_no_fixed (x : A) : S.q ⬝ x ≠ x := by
  intro eq
  have atB := congrArg (fun t => t ⬝ S.B) eq
  by_cases fixed : x ⬝ S.B = S.B
  · exact S.distinct ((S.q_true x S.B fixed).symm.trans (atB.trans fixed))
  · exact fixed (atB.symm.trans (S.q_false x S.B fixed))

/-- Every test performed by q q fails. -/
theorem qq_eq_kb : S.q ⬝ S.q = S.K S.B := by
  apply S.ext
  intro x
  exact (S.q_false S.q x (S.q_no_fixed x)).trans (S.k_app S.B x).symm

theorem qq_ne_q : S.q ⬝ S.q ≠ S.q := S.q_no_fixed S.q

/-- From an equality of constant functions, recover equality of their values. -/
theorem k_inj {x y : A} (h : S.K x = S.K y) : x = y := by
  have hx := congrArg (fun f => f ⬝ S.B) h
  simpa only [S.k_app] using hx

/-- Testing the lifted f on K(x) tests exactly whether f fixes x. -/
theorem lift_apply (f x : A) : S.B ⬝ S.K f ⬝ S.K x = S.K (f ⬝ x) := by
  apply S.ext
  intro z
  simp only [S.b_app, S.k_app]

theorem lift_fixed_iff (f x : A) :
    S.B ⬝ S.K f ⬝ S.K x = S.K x ↔ f ⬝ x = x := by
  rw [S.lift_apply]
  exact ⟨S.k_inj, congrArg S.K⟩

/-- The value chosen for the false return in CombNF is B B. -/
theorem bb_apply (x y z : A) :
    (S.B ⬝ S.B) ⬝ x ⬝ y ⬝ z = y ⬝ ((x ⬝ y) ⬝ z) := by
  simp only [S.b_app, S.k_app]

theorem b_ne_bb : S.B ≠ S.B ⬝ S.B := by
  intro eq
  -- B on (K(Ku), Kv, z) gives u, whereas B B on the same arguments gives v.
  have collapse (u v : A) : u = v := by
    have h := congrArg (fun t => t ⬝ S.K (S.K u) ⬝ S.K v ⬝ S.B) eq
    change S.B ⬝ S.K (S.K u) ⬝ S.K v ⬝ S.B =
      (S.B ⬝ S.B) ⬝ S.K (S.K u) ⬝ S.K v ⬝ S.B at h
    rw [S.bb_apply] at h
    simpa only [S.b_app, S.k_app] using h
  exact S.distinct (collapse (S.K S.B) S.B)

/-- A closed term. Its subexpressions only use the given B, q, K and application.
The lifting of the fixed-point test is expressed entirely inside the algebra. -/
def archiveQ : A :=
  let I := S.B ⬝ (S.B ⬝ S.B ⬝ S.B) ⬝ S.B
  let J := S.B ⬝ S.K (S.B ⬝ S.K S.B) ⬝ I
  let L := S.B ⬝ S.K (S.B ⬝ S.K S.q) ⬝ J
  let M := S.B ⬝ (S.B ⬝ S.K S.B ⬝ L) ⬝ S.K I
  S.B ⬝ (S.B ⬝ S.K S.B ⬝ M) ⬝ S.K (S.K S.B)

/-- The closed expression above reduces by just the B and K equations. -/
theorem archiveQ_apply (f x : A) :
    S.archiveQ ⬝ f ⬝ x = S.q ⬝ (S.B ⬝ S.K f) ⬝ S.K x ⬝ S.B := by
  simp only [archiveQ, S.b_app, S.k_app]

theorem archiveQ_true (f x : A) (h : f ⬝ x = x) : S.archiveQ ⬝ f ⬝ x = S.B := by
  rw [S.archiveQ_apply, S.q_true _ _ ((S.lift_fixed_iff f x).2 h), S.k_app]

theorem archiveQ_false (f x : A) (h : f ⬝ x ≠ x) : S.archiveQ ⬝ f ⬝ x = S.B ⬝ S.B := by
  rw [S.archiveQ_apply, S.q_false _ _ (fun fixed => h ((S.lift_fixed_iff f x).1 fixed))]

end NormalizedBasis
end NF192
