module
public import ProofCommands

@[expose] public section

/-! Uniform finite words building each derivable formula from any entering
proof stack. The proof follows the actual preserving-MP and automatic-NIP AX
protocol of the 3,089-leaf program. -/

set_option maxHeartbeats 8000000
set_option maxRecDepth 4096

namespace NF192.ProofSearch

open Numerical Emitter

def nips : Nat → List Command
  | 0 => []
  | n+1 => .mode 0 :: nips n

private theorem nips_over (pre tail : List Nat) (t c : Nat) :
    ∃ w, run (nips pre.length) ⟨t, pre ++ tail, c, 0⟩ = ⟨t, tail, w, 0⟩ := by
  induction pre generalizing c with
  | nil => exact ⟨c, rfl⟩
  | cons a pre ih => exact ih a

private theorem nips_to (pre tail : List Nat) (x t c : Nat) :
    run (nips (pre.length+1)) ⟨t, pre ++ x :: tail, c, 0⟩ = ⟨t, tail, x, 0⟩ := by
  induction pre generalizing c with
  | nil => rfl
  | cons a pre ih => exact ih a

private theorem split_at_member {x : Nat} {as : List Nat} (h : x ∈ as) :
    ∃ pre post, as = pre ++ x :: post := by
  induction as with
  | nil => contradiction
  | cons a as ih =>
    rcases List.mem_cons.mp h with rfl | h'
    · exact ⟨[], as, rfl⟩
    · obtain ⟨pre,post,eq⟩ := ih h'
      exact ⟨a :: pre, post, congrArg (List.cons a) eq⟩

/-- Extract any of the pushed rows while preserving the previous top and all
of its stack. The single word depends on the selected position only. -/
theorem extract_rows (zs : List Nat) (x : Nat) (h : x ∈ zs) (hlen : 2 ≤ zs.length) :
    ∃ word, ∀ s : State, ∃ c, run word (afterAX s zs) = ⟨x, s.top :: s.stack, c, 0⟩ := by
  have mem := List.mem_reverse.mpr h
  have len : 2 ≤ zs.reverse.length := by simpa using hlen
  generalize e : zs.reverse = rev at mem len
  rcases rev with _ | ⟨t, rest⟩
  · contradiction
  rcases rest with _ | ⟨c,front⟩
  · simp at len
  have H (s : State) : afterAX s zs = ⟨t, front ++ s.top :: s.stack, c, 0⟩ := by
    simp only [afterAX, e, List.headD_cons, List.tail_cons]
  rcases List.mem_cons.mp mem with ht | h'
  · subst x
    refine ⟨nips front.length, fun s => ?_⟩
    rw [H]
    exact nips_over front _ _ _
  rcases List.mem_cons.mp h' with hc | hp
  · subst x
    refine ⟨.mode 1 :: nips front.length, fun s => ?_⟩
    rw [H]
    exact nips_over front _ _ _
  obtain ⟨pre,post,hp'⟩ := split_at_member hp
  refine ⟨nips (pre.length+1) ++ (.mode 1 :: nips post.length), fun s => ?_⟩
  rw [H, hp', List.append_assoc, run_append]
  rw [show (x :: post) ++ s.top :: s.stack = x :: (post ++ s.top :: s.stack) from rfl]
  rw [nips_to]
  exact nips_over post _ _ _

def resetWord : List Command := .ax 0 0 0 [] :: (nips 7 ++ [.mp 0])

def recoverWord : List Command := .ax 0 0 0 [] :: (nips 8 ++ [.mode 1])

private theorem nine_shape (s : State) :
    ∃ z y rest, (rows 0 0 0 [] s).reverse = z :: y :: rest ∧ rest.length = 7 := by
  have length : (rows 0 0 0 [] s).reverse.length = 9 := by
    rw [List.length_reverse, rows_length]
    rfl
  generalize h : (rows 0 0 0 [] s).reverse = zs at length
  rcases zs with _ | ⟨z, zs⟩
  · contradiction
  rcases zs with _ | ⟨y,rest⟩
  · simp at length
  refine ⟨z, y, rest, rfl, ?_⟩
  simp only [List.length_cons] at length
  omega

/-- One blank batch and seven NIPs discard the emitted rows. MP(0) clears the
top and cache whether the comparison succeeds or fails. -/
theorem reset_results (s : State) :
    run resetWord s = ⟨0, s.top :: s.stack, 0, 0⟩ := by
  obtain ⟨z,y,rest,hr,hl⟩ := nine_shape s
  change run (nips 7 ++ [.mp 0]) (afterAX s _) = _
  simp only [afterAX, hr, List.headD_cons, List.tail_cons]
  rw [run_append, ← hl]
  obtain ⟨w,eq⟩ := nips_over rest (s.top :: s.stack) z y
  rw [eq]
  simp only [run, step, Nat.zero_add, ite_self]

/-- A blank batch resets R4 even after successful MP has left its consequent
there. The subsequent eight NIPs and SWAP restore the incoming top and stack. -/
theorem recover_results (s : State) :
    ∃ c, run recoverWord s = ⟨s.top, s.stack, c, 0⟩ := by
  obtain ⟨z,y,rest,hr,hl⟩ := nine_shape s
  refine ⟨z, ?_⟩
  change run (nips 8 ++ [.mode 1]) (afterAX s _) = _
  simp only [afterAX, hr, List.headD_cons, List.tail_cons]
  rw [run_append, show 8 = rest.length+1 by omega, nips_to]
  rfl

def Builds (x : Nat) (word : List Command) : Prop :=
  ∀ (t : Nat) (stack : List Nat) (cache : Nat), ∃ c,
    run word ⟨t, stack, cache, 0⟩ = ⟨x, t :: stack, c, 0⟩

/-- Starting with a zero cache, the first AX batch hits every allowed instance
with u≤a by choosing the additive field δ=a−u and selector c+2. -/
theorem builds_row {a b c u x : Nat} (hu : u ≤ a) (hx : x ∈ rowList a b c u) :
    ∃ word, Builds x word := by
  let rest : List (Nat × Nat) := List.replicate c (0,0)
  let zs := rowList a b c u ++ tailRows rest
  have length : 2 ≤ zs.length := by
    change 2 ≤ (rowList a b c u ++ tailRows rest).length
    rw [List.length_append, show (rowList a b c u).length = 9 from rfl]
    omega
  have hrow : x ∈ zs := List.mem_append_left _ hx
  obtain ⟨extract, he⟩ := extract_rows zs x hrow length
  let ax := Command.ax u b (a-u) rest
  refine ⟨resetWord ++ (ax :: (extract ++ [.mode 0])), ?_⟩
  intro t stack cache
  let saved : State := ⟨0, t :: stack, 0, 0⟩
  have rs : rows u b (a-u) rest saved = zs := by
    simp only [rows, saved, zs, rest, List.length_replicate, Nat.zero_add,
      show u+(a-u)=a by omega]
  obtain ⟨c', hc'⟩ := he saved
  refine ⟨0, ?_⟩
  rw [run_append, reset_results]
  change run (extract ++ [.mode 0]) (afterAX saved (rows u b (a-u) rest saved)) = _
  rw [rs, run_append, hc']
  rfl

theorem builds_mp {a b : Nat} {minor major : List Command}
    (hm : Builds a minor) (hM : Builds (imp a b) major) :
    Builds b (minor ++ major ++ [.mode 0, .mode 1, .mp b] ++ recoverWord) := by
  intro t stack cache
  obtain ⟨c1, e1⟩ := hm t stack cache
  obtain ⟨c2, e2⟩ := hM a (t :: stack) c1
  rw [run_append, run_append, run_append, e1, e2]
  have e : run [.mode 0, .mode 1, .mp b]
      ⟨imp a b, a :: t :: stack, c2, 0⟩ = ⟨b, t :: stack, 0, b⟩ := by
    simp [run, step]
  rw [e]
  exact recover_results _

/-- Every numerical derivation has one finite word that works uniformly on
every incoming top, cache and finite stack at parameter zero. -/
theorem deriv_buildable {x : Nat} (d : Deriv x) : ∃ word, Builds x word := by
  induction d with
  | logical a b c u h => exact builds_row (a:=a) (b:=b) (c:=c) (u:=u) h (by simp [rowList,row0])
  | fixedPointTrue a b => exact builds_row (a:=a) (b:=b) (c:=0) (u:=0) (Nat.zero_le _) (by simp [rowList,row1])
  | congrRight a b c => exact builds_row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [rowList,row2])
  | constant a b => exact builds_row (a:=a) (b:=b) (c:=0) (u:=0) (Nat.zero_le _) (by simp [rowList,row4])
  | congrLeft a b c => exact builds_row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [rowList,row3])
  | abstraction a b c => exact builds_row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [rowList,row5])
  | euclidean a b c => exact builds_row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [rowList,row6])
  | fixedPointFalse a b => exact builds_row (a:=a) (b:=b) (c:=0) (u:=0) (Nat.zero_le _) (by simp [rowList,row7])
  | extensionality a b => exact builds_row (a:=a) (b:=b) (c:=0) (u:=0) (Nat.zero_le _) (by simp [rowList,row9])
  | mp _ _ major minor =>
    obtain ⟨m,h⟩ := major
    obtain ⟨n,k⟩ := minor
    exact ⟨_, builds_mp k h⟩

/-- If the goal is provable, a single finite word halts from every command
boundary, even when an earlier candidate left a nonzero parameter. -/
theorem exists_detecting_word (d : Deriv goal) :
    ∃ cs : List Command, ∀ s, checkedRun cs s = none := by
  obtain ⟨w,hw⟩ := deriv_buildable d
  let front := resetWord ++ w
  refine ⟨front ++ [.mode 1, .mode 0], fun s => ?_⟩
  rw [checkedRun_append]
  cases h : checkedRun front s with
  | none => rfl
  | some t =>
    have e := checkedRun_survives h
    obtain ⟨c,hr⟩ := hw 0 (s.top :: s.stack) 0
    rw [show run front s = ⟨goal,0::s.top::s.stack,c,0⟩ by
      rw [show front = resetWord ++ w from rfl, run_append, reset_results]; exact hr] at e
    subst t
    change checkedRun [.mode 1, .mode 0] ⟨goal,0::s.top::s.stack,c,0⟩ = none
    by_cases hc : c = goal
    · simp [checkedRun, observes, hc]
    · simp [checkedRun, observes, step, hc]

theorem detects_iff_derives {s : State} (hs : s.Sound) :
    (∃ cs : List Command, checkedRun cs s = none) ↔ Deriv goal := by
  constructor
  · rintro ⟨cs,h⟩
    exact detects_only_goal hs h
  · intro h
    obtain ⟨cs,k⟩ := exists_detecting_word h
    exact ⟨cs,k s⟩

end NF192.ProofSearch

#print axioms NF192.ProofSearch.exists_detecting_word
#print axioms NF192.ProofSearch.detects_iff_derives
