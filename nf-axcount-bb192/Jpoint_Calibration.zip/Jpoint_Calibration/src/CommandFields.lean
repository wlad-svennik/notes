module
public import Init

@[expose] public section
set_option maxHeartbeats 0

namespace NF192.ProofSearch

/-- One fully read command of the plain 3,089-site countdown program.
The selector is decoded from the number of additional AX batches. -/
inductive Command : Type where
  | mp (field : Nat)
  | mode (field : Nat)
  | ax (outer firstB firstDelta : Nat) (rest : List (Nat × Nat))


namespace Command

/-- The exact sequence of ordinary inverse-Cantor fields for this command. -/
def fields : Command → List Nat
  | .mp d => [0, d]
  | .mode d => [1, d]
  | .ax u b δ rest => (rest.length + 2) :: u :: b :: δ ::
      rest.flatMap (fun p => [p.1, p.2])

end Command
end NF192.ProofSearch
