module
public import NumericalSemantics
public import GroundAlgebra

@[expose] public section

/-!
# Equivalence of the literal numerical theory with the normalized basis

A syntax tree can be used as a convenient domain for soundness, but the
machine quantifies over all naturals. The decoder below sends *every*
natural to a term and commutes with all three literal constructors.
-/

set_option maxHeartbeats 20000000

namespace NF192.Numerical

open Ground

def termStep (n : Nat) (previous : ∀ m, m < n → Term) : Term :=
  if h0 : n = 0 then .q else
  let p := Cantor.unpair ((n - 1) / 2)
  let a := previous p.1 (by have h := Cantor.unpair_left_le ((n-1)/2); dsimp [p]; omega)
  let b := previous p.2 (by have h := Cantor.unpair_right_le ((n-1)/2); dsimp [p]; omega)
  if n % 2 = 1 then .app a b else .h a b

noncomputable def decodeTerm (n : Nat) : Term := Nat.lt_wfRel.wf.fix termStep n

theorem decodeTerm_unfold (n : Nat) : decodeTerm n = termStep n (fun m _ => decodeTerm m) :=
  WellFounded.fix_eq _ _ _

@[simp] theorem decodeTerm_q : decodeTerm q = Term.q := by
  rw [decodeTerm_unfold]; rfl

@[simp] theorem decodeTerm_app (a b : Nat) :
    decodeTerm (app a b) = .app (decodeTerm a) (decodeTerm b) := by
  have h0 : app a b ≠ 0 := by unfold app; omega
  have hm : app a b % 2 = 1 := by unfold app; omega
  have hd : (app a b - 1) / 2 = pair a b := by unfold app; omega
  rw [decodeTerm_unfold]
  simp only [termStep, dif_neg h0, if_pos hm, hd, Cantor.unpair_pair]

@[simp] theorem decodeTerm_witness (a b : Nat) :
    decodeTerm (witness a b) = .h (decodeTerm a) (decodeTerm b) := by
  have h0 : witness a b ≠ 0 := by unfold witness; omega
  have hm : witness a b % 2 ≠ 1 := by unfold witness; omega
  have hd : (witness a b - 1) / 2 = pair a b := by unfold witness; omega
  rw [decodeTerm_unfold]
  simp only [termStep, dif_neg h0, if_neg hm, hd, Cantor.unpair_pair]

def encodeTerm : Term → Nat
  | .q => q
  | .app a b => app (encodeTerm a) (encodeTerm b)
  | .h a b => witness (encodeTerm a) (encodeTerm b)

theorem decode_encode (t : Term) : decodeTerm (encodeTerm t) = t := by
  induction t with
  | q => exact decodeTerm_q
  | app _ _ ia ib => simp only [encodeTerm, decodeTerm_app, ia, ib]
  | h _ _ ia ib => simp only [encodeTerm, decodeTerm_witness, ia, ib]

private def pulled (r : Term → Term → Prop) (a b : Nat) : Prop :=
  r (decodeTerm a) (decodeTerm b)

private theorem pulled_rows {r : Term → Term → Prop} (R : Rows Term.signature r) :
    Rows AsSignature (pulled r) := by
  constructor
  all_goals
    simp only [pulled, AsSignature, Signature.k, Signature.s, Signature.b,
      decodeTerm_app, decodeTerm_witness, decodeTerm_q]
  · exact fun a b => R.positive _ _
  · exact fun a b c => R.argCongr _ _ _
  · exact fun a b => R.kLaw _ _
  · exact fun a b c => R.funCongr _ _ _
  · exact fun a b c => R.bLaw _ _ _
  · exact fun a b c => R.euclid _ _ _
  · exact fun a b => R.negative _ _
  · exact fun a b => R.ext _ _

theorem term_countermodel_to_nat
    (h : ∃ r : Term → Term → Prop, Rows Term.signature r ∧
      ¬ r Term.signature.s Term.signature.q) : NatCountermodel := by
  obtain ⟨r, R, hg⟩ := h
  refine ⟨pulled r, pulled_rows R, ?_⟩
  simpa only [pulled, AsSignature, Signature.s, Term.signature,
    decodeTerm_app, decodeTerm_q] using hg

universe u

/-- Soundness is universe-polymorphic for the supplied normalized algebra. -/
theorem not_deriv_goal_of_basis {A : Type u} (N : NormalizedBasis A) :
    ¬ Deriv goal :=
  not_deriv_goal_iff_rows.mpr (term_countermodel_to_nat (Ground.term_countermodel N))

/-- Failure to derive the numerical goal constructs a small model on a
quotient of natural numbers. All axioms and MP in `Deriv` are literal. -/
theorem not_deriv_goal_iff_basis : ¬ Deriv goal ↔ ∃ A : Type, Nonempty (NormalizedBasis A) := by
  constructor
  · intro hd
    obtain ⟨r, R, hg⟩ := not_deriv_goal_iff_rows.mp hd
    exact ⟨R.Carrier, ⟨R.toBasis hg⟩⟩
  · rintro ⟨A, ⟨N⟩⟩
    exact not_deriv_goal_of_basis N

#print axioms not_deriv_goal_iff_basis

end NF192.Numerical
