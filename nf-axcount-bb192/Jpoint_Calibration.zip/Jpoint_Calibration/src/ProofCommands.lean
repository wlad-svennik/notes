module
public import CommandFields
public import NumericalAxioms

@[expose] public section

/-! Deterministic command semantics of the plain countdown source. The numerical
pair-stack representation is connected to finite lists below. In an AX command
the last pushed row becomes TOP, the penultimate is popped into CACHE by the
automatic NIP, and the earlier rows remain on the stack in reverse order.
The goal test for that automatic NIP receives zero, since AX first clears CACHE. -/

set_option maxHeartbeats 8000000

namespace NF192.ProofSearch

open Numerical Emitter

structure State where
  top : Nat
  stack : List Nat
  cache : Nat
  param : Nat

/-- After the first AX batch the four arithmetic auxiliaries are reset. -/
def tailRows : List (Nat × Nat) → List Nat
  | [] => []
  | (b, δ) :: rest => rowList δ b rest.length 0 ++ tailRows rest

def rows (u b δ : Nat) (rest : List (Nat × Nat)) (s : State) : List Nat :=
  rowList (s.param + u + δ) (s.cache + b) rest.length (s.param + u) ++ tailRows rest

/-- Consume the automatic final NIP after pushing the AX rows. -/
def afterAX (s : State) (chronological : List Nat) : State :=
  let zs := chronological.reverse
  ⟨zs.headD 0, zs.tail.tail ++ s.top :: s.stack, zs.tail.headD 0, 0⟩

/-- Step with goal observation suppressed; a successful checked step agrees
with this execution. A failed MP leaves the proposed consequent in R4. -/
def step (cmd : Command) (s : State) : State :=
  match cmd with
  | .mp d =>
    let b := s.param + d
    ⟨if s.cache = imp s.top b then b else 0, s.stack, 0, b⟩
  | .mode d =>
    match s.param + d with
    | 0 => ⟨s.top, s.stack.tail, s.stack.headD 0, 0⟩
    | w+1 => ⟨s.cache, s.stack, s.top, w⟩
  | .ax u b δ rest => afterAX s (rows u b δ rest s)

/-- SWAP (positive MODE) threads through NIP and checks the old cache too. -/
def observes (cmd : Command) (s : State) : Bool :=
  match cmd with
  | .mode _ => s.cache == goal
  | _ => false

def run : List Command → State → State
  | [], s => s
  | c :: cs, s => run cs (step c s)

def checkedRun : List Command → State → Option State
  | [], s => some s
  | c :: cs, s => if observes c s then none else checkedRun cs (step c s)

theorem run_append (u v : List Command) (s : State) :
    run (u ++ v) s = run v (run u s) := by
  induction u generalizing s with
  | nil => rfl
  | cons c cs ih => exact ih (step c s)

theorem checkedRun_append (u v : List Command) (s : State) :
    checkedRun (u ++ v) s = (checkedRun u s).bind (checkedRun v) := by
  induction u generalizing s with
  | nil => rfl
  | cons c cs ih =>
    by_cases h : observes c s = true <;> simp [checkedRun, h, ih]

theorem checkedRun_survives {cs : List Command} {s t : State}
    (h : checkedRun cs s = some t) : t = run cs s := by
  induction cs generalizing s with
  | nil => exact (Option.some.inj h).symm
  | cons c cs ih =>
    by_cases e : observes c s = true
    · simp [checkedRun, e] at h
    · exact ih (by simpa [checkedRun, e] using h)

def State.Sound (s : State) : Prop :=
  Deriv s.top ∧ (∀ x ∈ s.stack, Deriv x) ∧ Deriv s.cache

private theorem tailRows_sound (rest : List (Nat × Nat)) : ∀ x ∈ tailRows rest, Deriv x := by
  induction rest with
  | nil => simp [tailRows]
  | cons p rest ih =>
    rcases p with ⟨b,d⟩
    intro x hx
    rcases List.mem_append.mp hx with h | h
    · exact rows_derivable d b _ 0 (Nat.zero_le _) x h
    · exact ih x h

theorem rows_sound (u b d : Nat) (rest : List (Nat × Nat)) (s : State) :
    ∀ x ∈ rows u b d rest s, Deriv x := by
  intro x hx
  rcases List.mem_append.mp hx with h | h
  · exact rows_derivable _ _ _ _ (Nat.le_add_right _ _) x h
  · exact tailRows_sound rest x h

theorem rows_length (u b d : Nat) (rest : List (Nat × Nat)) (s : State) :
    (rows u b d rest s).length = 9 + (tailRows rest).length := by
  simp only [rows, List.length_append]
  rfl

private theorem head_sound {xs : List Nat} (h : ∀ x ∈ xs, Deriv x) :
    Deriv (xs.headD 0) := by
  cases xs with
  | nil => exact deriv_zero
  | cons x xs => exact h x (by simp)

private theorem tail_sound {xs : List Nat} (h : ∀ x ∈ xs, Deriv x) :
    ∀ x ∈ xs.tail, Deriv x := by
  intro x hx
  cases xs with
  | nil => exact False.elim (List.not_mem_nil hx)
  | cons a xs => exact h _ (List.mem_cons_of_mem a hx)

theorem step_sound (c : Command) (s : State) (h : s.Sound) : (step c s).Sound := by
  obtain ⟨ht, hs, hc⟩ := h
  cases c with
  | mp d =>
    refine ⟨?_, hs, deriv_zero⟩
    change Deriv (if s.cache = imp s.top (s.param+d) then s.param+d else 0)
    split
    next eq => exact Deriv.mp (eq ▸ hc) ht
    next => exact deriv_zero
  | mode d =>
    cases hw : s.param+d with
    | zero =>
      simpa only [step, hw, State.Sound] using
        (show Deriv s.top ∧ (∀ x ∈ s.stack.tail, Deriv x) ∧ Deriv (s.stack.headD 0)
          from ⟨ht, tail_sound hs, head_sound hs⟩)
    | succ n =>
      simpa only [step, hw, State.Sound] using
        (show Deriv s.cache ∧ (∀ x ∈ s.stack, Deriv x) ∧ Deriv s.top from ⟨hc, hs, ht⟩)
  | ax u b d rest =>
    let zs := (rows u b d rest s).reverse
    have hz : ∀ x ∈ zs, Deriv x := fun x hx =>
      rows_sound u b d rest s x (List.mem_reverse.mp hx)
    refine ⟨head_sound hz, ?_, head_sound (tail_sound hz)⟩
    intro x hx
    rcases List.mem_append.mp hx with hx | hx
    · exact tail_sound (tail_sound hz) x hx
    · rcases List.mem_cons.mp hx with e | e
      · exact e ▸ ht
      · exact hs x e

theorem detects_only_goal {cs : List Command} {s : State} (hs : s.Sound)
    (h : checkedRun cs s = none) : Deriv goal := by
  induction cs generalizing s with
  | nil => contradiction
  | cons c cs ih =>
    by_cases o : observes c s = true
    · cases c with
      | mp d => simp [observes] at o
      | ax u b d rest => simp [observes] at o
      | mode d =>
        have e : s.cache = goal := by simpa only [observes, beq_iff_eq] using o
        exact e ▸ hs.2.2
    · exact ih (step_sound c s hs) (by simpa [checkedRun, o] using h)

/-- Encode the mathematical stack into the machine's Cantor register. The
empty list and an empty tail of zeros are observationally indistinguishable. -/
def pack : List Nat → Nat
  | [] => 0
  | x :: xs => pair x (pack xs)

theorem pop_pack (xs : List Nat) : Cantor.unpair (pack xs) = (xs.headD 0, pack xs.tail) := by
  cases xs with
  | nil => rfl
  | cons x xs => exact Cantor.unpair_pair _ _

end NF192.ProofSearch
