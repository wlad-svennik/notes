module
public import ArbitraryBooleanFNF
public import RangeNFU
@[expose] public section

namespace FFL.FirstOrder.ArbitraryBoolean

/-- The FNF structure has exactly the starting application, allowing the
existing range and proper-map theorems to use the original parameters. -/
theorem countingModel {V : Type} [S : Basis V] (j p : V)
    (cancel : ∀ x, S.app (S.app j (S.app j x)) p = S.app j x)
    (gap : ∃ t, (∃ v, S.app j v = t) ∧
      ∀ x, (∃ a, S.app j a = x) → S.app j x ≠ t) : RangeNFU.HasCountingModel := by
  letI : Nonempty V := ⟨S.B⟩
  letI : Tarski.Structure ℒλ V := ArbitraryBoolean.fnStructure
  letI : Tarski.Structure.Eq ℒλ V := ⟨fun _ _ => Iff.rfl⟩
  letI : V↓[ℒλ] ⊧* 𝗙𝗡𝗙 := fnModel_models
  obtain ⟨d,_,strong,inj⟩ := FNF.JJ203.exists_strong_dedekind j p cancel gap
  obtain ⟨M,h,c,f,t,F,g⟩ := FNF.CountSet.model_with_strong_dedekind d strong inj
  exact ⟨V,inferInstance,M,h,c,d,f,t,F,g⟩

end FFL.FirstOrder.ArbitraryBoolean
#print axioms FFL.FirstOrder.ArbitraryBoolean.countingModel
