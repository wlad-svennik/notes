module
public import NormalizedBasis
public import CombTheory
@[expose] public section



set_option autoImplicit false

namespace NF192.NormalizedBasis

open FFL FFL.FirstOrder

variable {A : Type} (S : NF192.NormalizedBasis A)

/-- Interpret the actual function symbols of the uploaded CombNF language. -/
def combFunc : {n : Nat} → Language.Comb.Func n → (Fin n → A) → A
  | _, .cB, _ => S.B
  | _, .cR, _ => S.app S.B S.B
  | _, .cQ, _ => S.archiveQ
  | _, .K, v => S.K (v 0)
  | _, .app, v => S.app (v 0) (v 1)

/-- On the same carrier, use ordinary equality and the interpreted symbols. -/
def combStructure : Tarski.Structure ℒᴄ A where
  func := fun {_} f v => S.combFunc f v
  rel := fun {_} r => match r with
    | .eq => fun v => v 0 = v 1

include S in
theorem comb_consistent : Entailment.Consistent 𝗖𝗡𝗙 := by
  letI : Nonempty A := ⟨S.B⟩
  letI : Tarski.Structure ℒᴄ A := S.combStructure
  letI : Tarski.Structure.Eq ℒᴄ A := ⟨fun _ _ => Iff.rfl⟩
  letI : A↓[ℒᴄ] ⊧* 𝗖𝗡𝗙 := CNF.models_of
    S.k_app S.b_app S.archiveQ_true S.archiveQ_false (fun _ _ h => S.ext h) S.b_ne_bb
  exact consistent_of_model 𝗖𝗡𝗙 A

end NF192.NormalizedBasis
