module
public import C193GroundChart
@[expose] public section
namespace NF193.Upper
universe u v
/-- The reserved labels Q and J, and the old labels U and F of the represented
tester and successor, are pairwise distinct. -/
structure Splice (V : Type u) (I : Type v) where
  base : I
  next : I → I
  root_or_next : ∀ i, i=base ∨ ∃ k, i=next k
  old : V → V → V
  old_ext : ∀ {a b}, (∀ x, old a x = old b x) → a = b
  Q : V
  J : V
  U : V
  F : V
  chain : I → V
  qu : Q≠U
  qj : Q≠J
  qf : Q≠F
  uj : U≠J
  uf : U≠F
  jf : J≠F
  fixed_free : ∀ x, x=Q ∨ x=U ∨ x=J ∨ x=F → ∀ y, old x y≠y
  tester_yes : ∀ f x, old f x=x → old (old U f) x=Q
  tester_no : ∀ f x, old f x≠x → old (old U f) x=J
  tester_output_stable : ∀ f, ¬ (old U f=Q ∨ old U f=U ∨ old U f=J ∨ old U f=F)
  zero : chain base=Q
  chain_stable : ∀ n, ¬ (chain (next n)=Q ∨ chain (next n)=U ∨ chain (next n)=J ∨ chain (next n)=F)
  chain_const : ∀ n y, old (chain (next n)) y=chain n
  succ : ∀ n, old F (chain n)=chain (next n)
  default : ∀ x, (∀ n, x≠chain n) → old F x=Q
namespace Splice
variable {V : Type u} {I : Type v} (S : Splice V I)
def active (x : V) : Prop := x=S.Q ∨ x=S.U ∨ x=S.J ∨ x=S.F
noncomputable def ren (x : V) : V := by
  classical
  exact if x=S.Q then S.U else if x=S.U then S.Q else if x=S.J then S.F else if x=S.F then S.J else x
theorem renQ : S.ren S.Q=S.U := by classical simp [ren]
theorem renU : S.ren S.U=S.Q := by classical simp [ren,S.qu.symm]
theorem renJ : S.ren S.J=S.F := by classical simp [ren,S.qj.symm,S.uj.symm]
theorem renF : S.ren S.F=S.J := by classical simp [ren,S.qf.symm,S.uf.symm,S.jf.symm]
theorem ren_other {x : V} (h : ¬ S.active x) : S.ren x=x := by
  classical
  simp only [active,not_or] at h
  simp only [ren,ite_eq_right h.1,ite_eq_right h.2.1,ite_eq_right h.2.2.1,ite_eq_right h.2.2.2]
theorem ren_involutive (x : V) : S.ren (S.ren x)=x := by
  by_cases h : S.active x
  · rcases h with rfl|rfl|rfl|rfl <;> simp only [renQ,renU,renJ,renF]
  · rw [S.ren_other h,S.ren_other h]
noncomputable def app (f x : V) := S.old (S.ren f) x
theorem app_ext {a b} (h : ∀ x, S.app a x=S.app b x) : a=b := by
  have e := S.old_ext h
  exact (S.ren_involutive a).symm.trans ((congrArg S.ren e).trans (S.ren_involutive b))
theorem fixed_preserved (f x : V) : S.app f x=x ↔ S.old f x=x := by
  by_cases h : S.active f
  · have n := S.fixed_free f h x
    have hh : S.active (S.ren f) := by
      rcases h with rfl|rfl|rfl|rfl <;> simp [active,renQ,renU,renJ,renF]
    exact ⟨fun p => (S.fixed_free _ hh x p).elim,fun p => (n p).elim⟩
  · simp only [app,S.ren_other h]
theorem tester_row (f : V) : S.app S.Q f=S.old S.U f := by simp only [app,renQ]
theorem operator_row (x : V) : S.app S.J x=S.old S.F x := by simp only [app,renJ]
theorem yes (f x : V) (h : S.app f x=x) : S.app (S.app S.Q f) x=S.Q := by
  rw [tester_row,app,S.ren_other (S.tester_output_stable f)]
  exact S.tester_yes f x ((S.fixed_preserved f x).mp h)
theorem no (f x : V) (h : S.app f x≠x) : S.app (S.app S.Q f) x=S.J := by
  rw [tester_row,app,S.ren_other (S.tester_output_stable f)]
  exact S.tester_no f x (fun e => h ((S.fixed_preserved f x).mpr e))
theorem j_not_chain (n : I) : S.J≠S.chain n := by
  rcases S.root_or_next n with e|⟨k,e⟩
  · rw [e,S.zero]; exact S.qj.symm
  · rw [e]; exact fun z => S.chain_stable k (.inr (.inr (.inl z.symm)))
theorem self : S.app S.J S.J=S.Q := (S.operator_row _).trans (S.default _ S.j_not_chain)
theorem advance (n : I) : S.app S.J (S.chain n)=S.chain (S.next n) :=
  (S.operator_row _).trans (S.succ n)
theorem read (n : I) (x : V) : S.app (S.chain (S.next n)) x=S.chain n := by
  rw [app,S.ren_other (S.chain_stable n),S.chain_const]
theorem range (x : V) : ∃ n, S.app S.J x=S.chain n := by
  classical
  by_cases h : ∃ n, x=S.chain n
  · obtain ⟨n,rfl⟩ := h; exact ⟨S.next n,S.advance n⟩
  · exact ⟨S.base,(S.operator_row _).trans ((S.default _ (fun n e => h ⟨n,e⟩)).trans S.zero.symm)⟩
theorem pointwise (x y : V) : S.app (S.app S.J (S.app S.J x)) y=S.app S.J x := by
  obtain ⟨n,hn⟩ := S.range x
  rw [hn,S.advance,S.read]
/-- These are the native constant and abstraction operations of the relabelled
full function chart. No separating argument for the designated B slot is assumed. -/
structure Operations (S : Splice V I) where
  K : V → V
  B : V
  k : ∀ a x, S.app (K a) x=a
  b : ∀ f g x, S.app (S.app (S.app B f) g) x=S.app (S.app f (K x)) (S.app g x)
namespace Operations
variable {S} (A : Operations S)
local infixl:70 " ⬝ " => S.app
theorem b_double (v : V) : A.B ⬝ A.K (A.K v)=A.K (A.K v) := by
  apply S.app_ext; intro x; apply S.app_ext; intro y; simp only [A.b,A.k]
theorem b_not_const (v : V) : A.B ≠ A.K v := by
  intro e
  have all (w : V) : v ⬝ v ⬝ v=w := by
    have p := congrArg (fun f => f ⬝ v ⬝ v) (A.b_double w)
    simpa only [e,A.k] using p
  exact S.qj ((all S.Q).symm.trans (all S.J))
theorem b_not_chain (n : I) : A.B ≠ S.chain n := by
  rcases S.root_or_next n with e|⟨k,e⟩
  · rw [e,S.zero]; intro eq
    have h := A.b_double S.Q
    rw [eq] at h
    exact S.fixed_free S.Q (.inl rfl) _ ((S.fixed_preserved _ _).mp h)
  · rw [e]; intro z
    exact A.b_not_const (S.chain k) (S.app_ext (fun x => (z ▸ S.read k x).trans (A.k _ _).symm))
theorem separates : S.Q ⬝ A.B ≠ S.J ⬝ A.B := by
  have eq := (S.operator_row A.B).trans (S.default A.B A.b_not_chain)
  rw [eq,S.tester_row]
  exact fun h => S.tester_output_stable _ (.inl h)
noncomputable def chart : NF193.Chart V where
  app := S.app
  K := A.K
  J := S.J
  B := A.B
  k_app := A.k
  b_app := A.b
  ext := S.app_ext
  positive := by intro f x e; rw [S.self]; exact S.yes _ _ e
  negative := by intro f x e; rw [S.self]; exact S.no _ _ e
  pointwise := S.pointwise
  goal := S.self ▸ S.qj
  separates := by rw [S.self]; exact A.separates
end Operations
end Splice
end NF193.Upper
#print axioms NF193.Upper.Splice.Operations.chart
