module
public import SourceFields
public import ProofWords

@[expose] public section

/-! Halting of the unbounded command enumerator for the exact numeral 3.
The initial candidate index and all retained sound proof registers can be
arbitrary. The command scanner here acts at source command boundaries.
The literal register instruction stream and binary table are separate layers.
The batch/stream proof adapts NF210/SearchEnumeration.lean to this source. -/

set_option maxHeartbeats 2000000

namespace NF192.ProofSearch

open Numerical SourceFields

def candidate (n : Nat) : List Command :=
  (parse n).1 :: if h : (parse n).2 = 0 then [] else candidate ((parse n).2 - 1)
termination_by n
decreasing_by have := parse_decreases n; omega

theorem candidate_ne_nil (n : Nat) : candidate n ≠ [] := by
  rw [candidate]
  intro h
  cases h

theorem candidate_prefix {cs : List Command} {n t : Nat} (h : Matches cs n t) :
    candidate n = cs ++ candidate t := by
  induction h with
  | nil => rfl
  | @cons c cs a b t head _ ih =>
    rw [candidate]
    simpa only [head, Nat.succ_ne_zero, ↓reduceDIte, Nat.add_sub_cancel, List.cons_append]
      using congrArg (List.cons c) ih

def one (c : Command) (s : State) : Option State :=
  if observes c s then none else some (step c s)

theorem checkedRun_cons (c : Command) (cs : List Command) (s : State) :
    checkedRun (c::cs) s = (one c s).bind (checkedRun cs) := by
  by_cases h : observes c s = true <;> simp [checkedRun, one, h]

def scan (start : Nat) (s : State) : Nat → Option State
  | 0 => some s
  | k+1 => (scan start s k).bind (checkedRun (candidate (start+k)))

theorem scan_eventually_halts (d : Deriv goal) (start : Nat) (s : State) :
    ∃ k, scan start s k = none := by
  obtain ⟨cs, universal⟩ := exists_detecting_word d
  obtain ⟨n, hn, hword⟩ := cofinal cs start
  have idx : start + (n-start) = n := by omega
  refine ⟨(n-start)+1, ?_⟩
  rw [scan,idx,candidate_prefix hword]
  cases h : scan start s (n-start) with
  | none => rfl
  | some old =>
    simp only [Option.bind_some, checkedRun_append, universal, Option.bind_none]

structure StreamState where
  next : Nat
  cursor : Nat
  proof : State

def streamStep (s : StreamState) : Option StreamState :=
  let fresh := s.cursor = 0
  let input := if fresh then s.next else s.cursor-1
  let next := if fresh then s.next+1 else s.next
  let parsed := parse input
  (one parsed.1 s.proof).map (fun result => ⟨next,parsed.2,result⟩)

def streamRun : Nat → StreamState → Option StreamState
  | 0,s => some s
  | n+1,s => (streamStep s).bind (streamRun n)

theorem stream_run_add (n m : Nat) (s : StreamState) :
    streamRun (n+m) s = (streamRun n s).bind (streamRun m) := by
  induction n generalizing s with
  | zero => simp only [Nat.zero_add, streamRun, Option.bind_some]
  | succ n ih =>
    rw [Nat.succ_add, streamRun, streamRun]
    cases h : streamStep s with
    | none => rfl
    | some t => simpa only [Option.bind_some] using ih t

theorem stream_continued (n next : Nat) (s : State) :
    streamStep ⟨next,n+1,s⟩ =
      (one (parse n).1 s).map (fun t => ⟨next,(parse n).2,t⟩) := by
  simp [streamStep]

theorem stream_candidate (n next : Nat) (s : State) :
    streamRun (candidate n).length ⟨next,n+1,s⟩ =
      (checkedRun (candidate n) s).map (fun t => ⟨next,0,t⟩) := by
  induction n using Nat.strongRecOn generalizing s with
  | ind n ih =>
    rw [candidate]
    simp only [List.length_cons, streamRun, stream_continued, checkedRun_cons]
    cases hs : one (parse n).1 s with
    | none => rfl
    | some t =>
      simp only [Option.map_some, Option.bind_some]
      by_cases hz : (parse n).2 = 0
      · simp [hz, streamRun, checkedRun]
      · simp only [hz, ↓reduceDIte]
        have hlt : (parse n).2 - 1 < n := by
          have hle := parse_decreases n
          omega
        have he : (parse n).2 = ((parse n).2-1)+1 := by omega
        rw [he]
        exact ih ((parse n).2-1) hlt t

theorem stream_fresh (n : Nat) (s : State) :
    streamStep ⟨n,0,s⟩ = streamStep ⟨n+1,n+1,s⟩ := by simp [streamStep]

theorem stream_candidate_fresh (n : Nat) (s : State) :
    streamRun (candidate n).length ⟨n,0,s⟩ =
      (checkedRun (candidate n) s).map (fun t => ⟨n+1,0,t⟩) := by
  have he := stream_candidate n (n+1) s
  have hn := List.length_pos_iff.mpr (candidate_ne_nil n)
  obtain ⟨m,hm⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : (candidate n).length ≠ 0)
  rw [hm, streamRun, stream_fresh]
  simpa only [hm, streamRun] using he

theorem scan_reached (start : Nat) (s : State) (k : Nat) :
    ∃ ticks, streamRun ticks ⟨start,0,s⟩ = (scan start s k).map (fun t => ⟨start+k,0,t⟩) := by
  induction k with
  | zero => exact ⟨0,rfl⟩
  | succ n ih =>
    obtain ⟨ticks,ht⟩ := ih
    refine ⟨ticks+(candidate (start+n)).length, ?_⟩
    rw [stream_run_add, ht, scan]
    cases hs : scan start s n with
    | none => rfl
    | some s => exact stream_candidate_fresh (start+n) s

def StreamSound : Option StreamState → Prop
  | none => Deriv goal
  | some s => s.proof.Sound

theorem stream_step_sound (s : StreamState) (hs : s.proof.Sound) :
    StreamSound (streamStep s) := by
  simp only [streamStep]
  generalize parse (if s.cursor = 0 then s.next else s.cursor-1) = parsed
  rcases parsed with ⟨c, tail⟩
  by_cases o : observes c s.proof = true
  · have halt : checkedRun [c] s.proof = none := by simp [checkedRun, o]
    simpa [one, o, StreamSound] using detects_only_goal hs halt
  · simpa [one, o, StreamSound] using step_sound c s.proof hs

theorem stream_run_sound (ticks : Nat) (s : StreamState) (hs : s.proof.Sound) :
    StreamSound (streamRun ticks s) := by
  induction ticks generalizing s with
  | zero => exact hs
  | succ n ih =>
    have hc := stream_step_sound s hs
    cases he : streamStep s with
    | none => simpa only [streamRun, he, Option.bind_none] using hc
    | some t =>
      have ht : t.proof.Sound := by simpa only [he, StreamSound] using hc
      simpa only [streamRun, he, Option.bind_some] using ih t ht

/-- For every sound entry at a refill boundary, the successive natural
candidates halt exactly when the nine-family calculus derives numeral 3. -/
theorem stream_halting_iff_goal (start : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, streamRun ticks ⟨start,0,s⟩ = none) ↔ Deriv goal := by
  constructor
  · rintro ⟨ticks, ht⟩
    simpa only [ht, StreamSound] using stream_run_sound ticks ⟨start,0,s⟩ hs
  · intro h
    obtain ⟨k,hk⟩ := scan_eventually_halts h start s
    obtain ⟨ticks,ht⟩ := scan_reached start s k
    exact ⟨ticks, by simpa only [hk, Option.map_none] using ht⟩

end NF192.ProofSearch

#print axioms NF192.ProofSearch.stream_halting_iff_goal
