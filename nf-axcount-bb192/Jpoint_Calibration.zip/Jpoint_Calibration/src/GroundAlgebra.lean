module
public import GroundRows
public import NormalizedBasis

@[expose] public section

/-! A goal-falsifying model of the exact ground schemas is equivalent to a
normalized algebra.  The quotient direction works for arbitrary object codes;
the converse specializes the freely generated terms by evaluation. -/

namespace NF192.Ground

universe u

namespace Rows

variable {X : Type u} {S : Signature X} {r : X → X → Prop} (R : Rows S r)

def toBasis (hg : ¬ r S.s S.q) : NF192.NormalizedBasis R.Carrier where
  app := R.appObj
  K := R.kObj
  B := R.obj S.b
  q := R.obj S.q
  k_app := R.kObj_app
  b_app := R.bObj_app
  ext := R.appObj_ext
  q_true := fun f x h => (R.positiveObj f x h).trans (R.s_eq_kb hg)
  q_false := R.negativeObj
  distinct := fun h => R.s_ne_b hg ((R.s_eq_kb hg).trans h)

end Rows

namespace Interpretation

variable {M : Type u} (A : NF192.NormalizedBasis M)

/-- Unequal functions have a concrete distinguishing argument. -/
theorem exists_separator {a b : M} (hn : a ≠ b) :
    ∃ x, A.app a x ≠ A.app b x := by
  apply Classical.byContradiction
  intro h
  apply hn
  apply A.ext
  intro x
  apply Classical.byContradiction
  intro hx
  exact h ⟨x, hx⟩

/-- A single object-level operation realizes both diagonal K and
the witness required by the last schema. -/
noncomputable def witness (a b : M) : M := by
  classical
  exact if h : a = b then A.K a else Classical.choose (exists_separator A h)

theorem witness_diag (a : M) : witness A a a = A.K a := by
  classical
  simp [witness]

theorem witness_ext (a b : M)
    (h : A.app b (witness A a b) = A.app a (witness A a b)) : a = b := by
  classical
  by_cases e : a = b
  · exact e
  · have hn := Classical.choose_spec (exists_separator A e)
    exact False.elim (hn (by simpa only [witness, dif_neg e] using h.symm))

noncomputable def eval : Term → M
  | .q => A.q
  | .app a b => A.app (eval a) (eval b)
  | .h a b => witness A (eval a) (eval b)

theorem eval_k (a : Term) : eval A (Term.signature.k a) = A.K (eval A a) :=
  witness_diag A _

theorem eval_s : eval A Term.signature.s = A.K A.B := A.qq_eq_kb

theorem eval_b : eval A Term.signature.b = A.B := by
  change A.app (A.app A.q A.q) A.q = A.B
  rw [A.qq_eq_kb, A.k_app]

theorem goal_false : eval A Term.signature.s ≠ eval A Term.signature.q :=
  A.qq_ne_q

def EqualValue (a b : Term) : Prop := eval A a = eval A b

theorem rows : Rows Term.signature (EqualValue A) where
  positive := by
    intro a b h
    change eval A Term.signature.s = A.app (A.app A.q (eval A a)) (eval A b)
    exact (eval_s A).trans (A.q_true _ _ h).symm
  argCongr := by
    intro a b c h
    exact congrArg (A.app (eval A a)) h
  kLaw := by
    intro a b
    change A.app (eval A (Term.signature.k b)) (eval A a) = eval A b
    rw [eval_k, A.k_app]
  funCongr := by
    intro a b c h
    exact congrArg (fun z => A.app z (eval A b)) h.symm
  bLaw := by
    intro a b c
    change A.app (A.app (A.app (eval A Term.signature.b) (eval A c)) (eval A a)) (eval A b) =
      A.app (A.app (eval A c) (eval A (Term.signature.k b))) (A.app (eval A a) (eval A b))
    rw [eval_b, eval_k, A.b_app]
  euclid := by
    intro a b c h₁ h₂
    exact h₂.symm.trans h₁
  negative := by
    intro a b h
    have hn : A.app (eval A a) (eval A b) ≠ eval A b :=
      fun e => goal_false A (h e)
    change eval A Term.signature.b = A.app (A.app A.q (eval A a)) (eval A b)
    exact (eval_b A).trans (A.q_false _ _ hn).symm
  ext := by
    intro a b h
    exact witness_ext A (eval A a) (eval A b) h

end Interpretation

/-- Every normalized algebra yields a countervaluation of the exact closed
ground schemes, with goal `qq = q` false. -/
theorem term_countermodel {M : Type u} (A : NF192.NormalizedBasis M) :
    ∃ r : Term → Term → Prop, Rows Term.signature r ∧ ¬ r Term.signature.s Term.signature.q :=
  ⟨Interpretation.EqualValue A, Interpretation.rows A, Interpretation.goal_false A⟩

/-- Uniform equisatisfiability at the universe of the ground terms. -/
theorem term_countermodel_iff :
    (∃ r : Term → Term → Prop, Rows Term.signature r ∧ ¬ r Term.signature.s Term.signature.q) ↔
      ∃ M : Type, Nonempty (NF192.NormalizedBasis M) := by
  constructor
  · rintro ⟨r, R, hg⟩
    exact ⟨R.Carrier, ⟨R.toBasis hg⟩⟩
  · rintro ⟨M, ⟨A⟩⟩
    exact term_countermodel A

end NF192.Ground
