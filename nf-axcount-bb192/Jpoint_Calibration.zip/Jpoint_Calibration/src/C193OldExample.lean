module
public import C193Model
public import C201Rows
@[expose] public section
namespace C193
open NF192 NF192.Ground NF192.Numerical NF192.Emitter

/-- This is the old positive fixed-point axiom instantiated at f = (0 1), x = 1. -/
theorem old_proves_positive_example : C201.Deriv 10782656132388 := by
  have h : C201.Deriv (row1 (app q s) s) :=
    C201.Deriv.row (a := app q s) (b := s) (c := 0) (u := 0)
      (Nat.zero_le _) (by simp [C201.rowList])
  exact h

private theorem jQ_ne_Q {V : Type} (A : NF193.Chart V) :
    A.app A.J (A.app A.J A.J) ≠ A.app A.J A.J := by
  let Q := A.app A.J A.J
  intro same
  have const : ∀ y, A.app Q y = Q := by
    intro y
    have h := A.pointwise A.J y
    rw [same] at h
    exact h
  have miss : A.app (A.K A.J) Q ≠ Q := by
    rw [A.k_app]
    exact Ne.symm A.goal
  have bad := A.negative (A.K A.J) Q miss
  change A.app (A.app Q (A.K A.J)) Q = A.J at bad
  rw [const, const] at bad
  exact A.goal bad

theorem jpoint_positive_example_implies_goal (d : C193.Deriv 10782656132388) :
    C193.Deriv goal := by
  apply Classical.byContradiction
  intro no
  obtain ⟨r, hr, hg⟩ := C193.not_deriv_iff_ground_model.mp no
  let R := (C193.hold_iff_rows r).mp hr
  let A := R.toChart hg
  have h : evaluate r (row1 (app q s) s) := C193.evaluate_deriv hr d
  have prem : r (app (app q s) s) s := R.scalar q s
  have eq := (evaluate_imp r _ _).mp h ((evaluate_eqn r _ _).mpr prem)
  have raw := R.obj_eq_iff.mpr ((evaluate_eqn r _ _).mp eq)
  change (A.app A.J A.J) = A.app (A.app A.J (A.app A.J (A.app A.J A.J))) (A.app A.J A.J) at raw
  rw [A.pointwise] at raw
  exact jQ_ne_Q A raw.symm
end C193
#print axioms C193.old_proves_positive_example
#print axioms C193.jpoint_positive_example_implies_goal
