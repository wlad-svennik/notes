module
public import C201Logic
@[expose] public section
namespace ScalarFold
open NF192 NF192.Emitter NF192.Numerical

def folded (a b : Nat) : Nat := imp (eqn (app B a) b) (eqn (app (app B b) q) b)

def common (a b c u : Nat) : List Nat := [row0 a b c u,row1 a b,C201.nativeBRow a b c,row2 a b c,
  row3 a b c,row9 a b,row6 a b c,row7 a b,row4 a b]

def rowList (a b c u : Nat) : List Nat := [row0 a b c u,row1 a b,C201.nativeBRow a b c,row2 a b c,
  row3 a b c,row9 a b,row6 a b c,row7 a b,folded a b,row4 a b]

inductive Deriv : Nat → Prop where
  | row {a b c u x : Nat} : u ≤ a → x ∈ rowList a b c u → Deriv x
  | mp {a b : Nat} : Deriv (imp a b) → Deriv a → Deriv b

structure EqRules (R : Nat → Prop) : Prop where
  mp {p q} : R (imp p q) → R p → R q
  commonRow {a b c u n} : u ≤ a → n ∈ common a b c u → R n

namespace EqRules
variable {R : Nat → Prop} (r : EqRules R)
include r

theorem euclid {x y z} (xy : R (eqn x y)) (xz : R (eqn x z)) : R (eqn z y) := by
  have row : R (row6 x y z) := r.commonRow (a:=x) (b:=y) (c:=z) (u:=0) (Nat.zero_le _) (by simp [common])
  exact r.mp (r.mp row xy) xz

theorem refl (x) : R (eqn x x) := by
  have k : R (row4 0 x) := r.commonRow (a:=0) (b:=x) (c:=0) (u:=0) (Nat.zero_le _) (by simp [common])
  exact r.euclid k k

theorem symm {x y} (xy : R (eqn x y)) : R (eqn y x) := r.euclid (r.refl x) xy

theorem trans {x y z} (xy : R (eqn x y)) (yz : R (eqn y z)) : R (eqn x z) :=
  r.euclid yz (r.symm xy)

theorem arg {a b} (f) (ab : R (eqn a b)) : R (eqn (app f a) (app f b)) := by
  have law : R (row2 f b a) := r.commonRow (a:=f) (b:=b) (c:=a) (u:=0) (Nat.zero_le _) (by simp [common])
  exact r.mp law ab

theorem funarg {a b} (z) (ab : R (eqn a b)) : R (eqn (app a z) (app b z)) := by
  have law : R (row3 b z a) := r.commonRow (a:=b) (b:=z) (c:=a) (u:=0) (Nat.zero_le _) (by simp [common])
  exact r.mp law (r.symm ab)
end EqRules

theorem common_iff_old (a b c u n) : n ∈ C201.rowList a b c u ↔ n ∈ common a b c u ∨ n = C201.scalarRow a := by
  simp [common,C201.rowList,or_comm,or_assoc,or_left_comm]

theorem common_iff_new (a b c u n) : n ∈ rowList a b c u ↔ n ∈ common a b c u ∨ n = folded a b := by
  simp [common,rowList,or_comm,or_assoc,or_left_comm]

theorem oldFromRules (Γ : Nat → Prop) : EqRules (C201.From Γ) where
  mp := C201.From.mp
  commonRow := fun hu h => .proved (.row hu ((common_iff_old _ _ _ _ _).mpr (.inl h)))

theorem newRules : EqRules Deriv where
  mp := Deriv.mp
  commonRow := fun hu h => .row hu ((common_iff_new _ _ _ _ _).mpr (.inl h))

theorem old_proves_folded (a b : Nat) : C201.Deriv (folded a b) := by
  let Γ := fun n => False ∨ n = eqn (app B a) b
  let r := oldFromRules Γ
  have p : C201.From Γ (eqn (app B a) b) := .assumption (.inr rfl)
  have s : C201.From Γ (C201.scalarRow a) := .proved (.row (u:=0) (b:=0) (c:=0) (Nat.zero_le _)
    ((common_iff_old _ _ _ _ _).mpr (.inr rfl)))
  apply C201.From.no_assumptions
  apply C201.From.deduction
  exact r.trans (r.symm (r.funarg q (r.arg B p))) (r.trans s p)

theorem new_proves_scalar (a : Nat) : Deriv (C201.scalarRow a) := by
  have f : Deriv (folded a (app B a)) := .row (u:=0) (c:=0) (Nat.zero_le _)
    ((common_iff_new _ _ _ _ _).mpr (.inr rfl))
  exact .mp f (newRules.refl _)

theorem yields_same_theorems (n : Nat) : Deriv n ↔ C201.Deriv n := by
  constructor
  · intro p
    induction p with
    | @row a b c u x h hx =>
      rcases (common_iff_new _ _ _ _ _).mp hx with hc | rfl
      · exact .row h ((common_iff_old _ _ _ _ _).mpr (.inl hc))
      · exact old_proves_folded a b
    | mp _ _ major minor => exact .mp major minor
  · intro p
    induction p with
    | @row a b c u x h hx =>
      rcases (common_iff_old _ _ _ _ _).mp hx with hc | rfl
      · exact .row h ((common_iff_new _ _ _ _ _).mpr (.inl hc))
      · exact new_proves_scalar a
    | mp _ _ major minor => exact .mp major minor
end ScalarFold
#print axioms ScalarFold.yields_same_theorems
