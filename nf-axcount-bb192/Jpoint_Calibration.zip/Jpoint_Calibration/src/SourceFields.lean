module
public import NumericalCodes
public import CommandFields

@[expose] public section

/-! Cantor-field reader for the 3,089-node countdown source. Its outer
selector values 0 and 1 request MP and MODE. The selector c+2 requests
c+1 AX batches. The selector and outer parameter are always read. Each AX
batch then consumes a pair of fields. A positive continuation buffer is
decremented once between successive commands. The literal register programs
implementing these numerical readers are a separate verification step. -/

set_option maxHeartbeats 0

namespace NF192.SourceFields

open Numerical Numerical.Cantor ProofSearch

def encodeBatch (b : Nat × Nat) (tail : Nat) := pair b.1 (pair b.2 tail)

def readBatch (n : Nat) : (Nat × Nat) × Nat :=
  let (b,n) := unpair n
  let (d,n) := unpair n
  ((b,d),n)

theorem readBatch_encode (b : Nat × Nat) (tail : Nat) :
    readBatch (encodeBatch b tail) = (b,tail) := by
  cases b
  simp only [readBatch, encodeBatch, unpair_pair]

def encodeBatches : List (Nat × Nat) → Nat → Nat
  | [], tail => tail
  | b :: bs, tail => encodeBatch b (encodeBatches bs tail)

def readBatches : Nat → Nat → List (Nat × Nat) × Nat
  | 0,n => ([],n)
  | k+1,n =>
    let (b,n) := readBatch n
    let (bs,tail) := readBatches k n
    (b::bs,tail)

theorem readBatches_encode (bs : List (Nat × Nat)) (tail : Nat) :
    readBatches bs.length (encodeBatches bs tail) = (bs,tail) := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp only [List.length_cons, encodeBatches, readBatches, readBatch_encode, ih]

def assemble : Command → Nat → Nat
  | .mp u, t => pair 0 (pair u t)
  | .mode u, t => pair 1 (pair u t)
  | .ax u b d more, t =>
    pair (more.length+2) (pair u (encodeBatch (b,d) (encodeBatches more t)))

def parse (n : Nat) : Command × Nat :=
  let (s,n) := unpair n
  let (u,n) := unpair n
  match s with
  | 0 => (.mp u,n)
  | 1 => (.mode u,n)
  | k+2 =>
    let (first,n) := readBatch n
    let (more,n) := readBatches k n
    (.ax u first.1 first.2 more,n)

theorem parse_assemble (c : Command) (tail : Nat) :
    parse (assemble c tail) = (c,tail) := by
  cases c <;> simp only [assemble, parse, unpair_pair, readBatch_encode, readBatches_encode]

theorem readBatch_decreases (n : Nat) : (readBatch n).2 ≤ n := by
  exact Nat.le_trans (unpair_right_le _) (unpair_right_le _)

theorem readBatches_decreases (count n : Nat) : (readBatches count n).2 ≤ n := by
  induction count generalizing n with
  | zero => exact Nat.le_refl _
  | succ k ih =>
    exact Nat.le_trans (ih (readBatch n).2) (readBatch_decreases n)

theorem parse_decreases (n : Nat) : (parse n).2 ≤ n := by
  have outer := Nat.le_trans (unpair_right_le (unpair n).2) (unpair_right_le n)
  generalize ha : unpair n = a at *
  generalize hb : unpair a.2 = b at *
  cases a with
  | mk tag t =>
    cases b with
    | mk u rest =>
      change rest ≤ n at outer
      change unpair t = (u,rest) at hb
      simp only [parse, ha, hb]
      cases tag with
      | zero => exact outer
      | succ tag =>
        cases tag with
        | zero => exact outer
        | succ k =>
          exact Nat.le_trans (readBatches_decreases k _) (Nat.le_trans (readBatch_decreases rest) outer)

theorem tail_le_assemble (c : Command) (t : Nat) : t ≤ assemble c t := by
  have h := parse_decreases (assemble c t)
  rw [parse_assemble] at h
  exact h

def encode : List Command → Nat → Nat
  | [], tail => tail
  | c :: cs, tail => assemble c (encode cs tail + 1)

/-- `Matches` records each guard as well as the field reads, and leaves the
rest of the candidate available to the ordinary command loop. -/
inductive Matches : List Command → Nat → Nat → Prop where
  | nil (tail : Nat) : Matches [] tail tail
  | cons {c cs a b t} :
    parse a = (c,b+1) → Matches cs b t → Matches (c::cs) a t

theorem matches_encoding (cs : List Command) (t : Nat) : Matches cs (encode cs t) t := by
  induction cs with
  | nil => exact .nil _
  | cons c cs ih => exact .cons (parse_assemble c _) ih

theorem tail_le_encoding (cs : List Command) (t : Nat) : t ≤ encode cs t := by
  induction cs with
  | nil => exact Nat.le_refl _
  | cons c cs ih =>
    exact Nat.le_trans (Nat.le_succ_of_le ih) (tail_le_assemble c _)

/-- Beyond any attained counter value, a candidate starts with the prescribed
finite word, for arbitrary desired parameters including zero. -/
theorem cofinal (cs : List Command) (bound : Nat) :
    ∃ input, bound < input ∧ Matches cs input (bound+1) :=
  ⟨encode cs (bound+1), tail_le_encoding cs (bound+1), matches_encoding cs (bound+1)⟩

/-- Every continuation in an arbitrary candidate decreases its cursor.
This gives a termination measure independently of whether the candidate
encodes a useful proof word. -/
theorem continuation_strict {input next : Nat} {c : Command}
    (h : parse input = (c,next+1)) : next < input := by
  have k := parse_decreases input
  rw [h] at k
  exact k

end NF192.SourceFields

#print axioms NF192.SourceFields.cofinal
#print axioms NF192.SourceFields.continuation_strict
