module
public import FnTheory
@[expose] public section

/-! A fixed-point tester with any two distinct values gives a FunctionNF model
on the original carrier. The equality selector is q(Kx)y. The normal terms
used for stratified bracket abstraction keep B, q and both Boolean values as
separate constants. -/
namespace FFL.FirstOrder.ArbitraryBoolean
open JensenNFU.TFm (scons scons_zero scons_succ)
open FNF (LTm HasLev)

class Basis (M : Type) where
  app : M → M → M
  K : M → M
  B : M
  q : M
  yes : M
  no : M
  k_app : ∀ a x, app (K a) x = a
  b_app : ∀ f g x, app (app (app B f) g) x = app (app f (K x)) (app g x)
  ext : ∀ {f g}, (∀ x, app f x=app g x) → f=g
  trueAt : ∀ f x, app f x=x → app (app q f) x=yes
  falseAt : ∀ f x, app f x≠x → app (app q f) x=no
  distinct : yes≠no

/-- A variable or one of the four constants. -/
inductive Atom : Type
  | var (i : ℕ) : Atom
  | cB : Atom
  | cT : Atom
  | cR : Atom
  | cQ : Atom

/-- Normal terms: applications of leaves `K^m(a)`. -/
inductive NT : Type
  | leaf (m : ℕ) (a : Atom) : NT
  | app (s t : NT) : NT

/-- The identity `B (B B B) B`, as a normal term. -/
def iT : NT :=
  .app (.app (.leaf 0 .cB) (.app (.app (.leaf 0 .cB) (.leaf 0 .cB)) (.leaf 0 .cB))) (.leaf 0 .cB)

/-- `K` applied to a normal term, pushed down to the leaves. -/
def kpush : NT → NT
  | .leaf m a => .leaf (m + 1) a
  | .app s t => .app (.app (.leaf 0 .cB) (kpush s)) (kpush t)

/-- Abstraction of variable `0`, occurring as `K^j` of itself at the root. The other variables
move down by one. -/
def abs : ℕ → NT → NT
  | _, .leaf _ (.var 0) => iT
  | _, .leaf m (.var (i + 1)) => .leaf (m + 1) (.var i)
  | _, .leaf m .cB => .leaf (m + 1) .cB
  | _, .leaf m .cT => .leaf (m + 1) .cT
  | _, .leaf m .cR => .leaf (m + 1) .cR
  | _, .leaf m .cQ => .leaf (m + 1) .cQ
  | j, .app s t => .app (.app (.leaf 0 .cB) (abs (j + 1) s)) (abs j t)

/-- Every occurrence of variable `0` is under the right number of `K`s. -/
def Good : ℕ → NT → Prop
  | j, .leaf m (.var 0) => m = j
  | _, .leaf _ (.var (_ + 1)) => True
  | _, .leaf _ .cB => True
  | _, .leaf _ .cT => True
  | _, .leaf _ .cR => True
  | _, .leaf _ .cQ => True
  | j, .app s t => Good (j + 1) s ∧ Good j t

/-- Levels of normal terms: `K` raises the level by one. -/
def NLev : (ℕ → ℕ) → NT → ℕ → Prop
  | γ, .leaf m (.var i), ℓ => γ i + m = ℓ
  | _, .leaf _ .cB, _ => True
  | _, .leaf _ .cT, _ => True
  | _, .leaf _ .cR, _ => True
  | _, .leaf _ .cQ, _ => True
  | γ, .app s t, ℓ => NLev γ s (ℓ + 1) ∧ NLev γ t ℓ

/-- The translation of λ-terms. -/
def tr : LTm → NT
  | .var i => .leaf 0 (.var i)
  | .app s t => .app (tr s) (tr t)
  | .lam t => abs 0 (tr t)
  | .eqt s t => .app (.app (.leaf 0 .cQ) (kpush (tr s))) (tr t)
  | .tt => .leaf 0 .cT
  | .ff => .leaf 0 .cR

theorem nlev_iT (γ : ℕ → ℕ) (L : ℕ) : NLev γ iT L := by simp [iT, NLev]

theorem nlev_good (T : NT) : ∀ (j ℓ k : ℕ) (γ : ℕ → ℕ), NLev (scons k γ) T ℓ → k + j = ℓ →
    Good j T := by
  induction T with
  | leaf m a =>
    intro j ℓ k γ h e
    cases a with
    | var i =>
      cases i with
      | zero =>
        have h' : k + m = ℓ := h
        show m = j
        omega
      | succ i => trivial
    | cB => trivial
    | cT => trivial
    | cR => trivial
    | cQ => trivial
  | app s t ihs iht =>
    intro j ℓ k γ h e
    exact ⟨ihs (j + 1) (ℓ + 1) k γ h.1 (by omega), iht j ℓ k γ h.2 e⟩

theorem nlev_abs (T : NT) : ∀ (j ℓ k : ℕ) (γ : ℕ → ℕ), NLev (scons k γ) T ℓ → k + j = ℓ →
    NLev γ (abs j T) (ℓ + 1) := by
  induction T with
  | leaf m a =>
    intro j ℓ k γ h e
    cases a with
    | var i =>
      cases i with
      | zero => exact nlev_iT γ (ℓ + 1)
      | succ i =>
        have h' : γ i + m = ℓ := h
        show γ i + (m + 1) = ℓ + 1
        omega
    | cB => trivial
    | cT => trivial
    | cR => trivial
    | cQ => trivial
  | app s t ihs iht =>
    intro j ℓ k γ h e
    exact ⟨⟨trivial, ihs (j + 1) (ℓ + 1) k γ h.1 (by omega)⟩, iht j ℓ k γ h.2 e⟩

theorem nlev_kpush (T : NT) : ∀ (ℓ : ℕ) (γ : ℕ → ℕ), NLev γ T ℓ → NLev γ (kpush T) (ℓ + 1) := by
  induction T with
  | leaf m a =>
    intro ℓ γ h
    cases a with
    | var i =>
      have h' : γ i + m = ℓ := h
      show γ i + (m + 1) = ℓ + 1
      omega
    | cB => trivial
    | cT => trivial
    | cR => trivial
    | cQ => trivial
  | app s t ihs iht =>
    intro ℓ γ h
    exact ⟨⟨trivial, ihs (ℓ + 1) γ h.1⟩, iht ℓ γ h.2⟩

/-- The translation of a stratified λ-term has the same level. -/
theorem nlev_tr (t : LTm) : ∀ (γ : ℕ → ℕ) (ℓ : ℕ), HasLev γ t ℓ → NLev γ (tr t) ℓ := by
  induction t with
  | var i => intro γ ℓ h; exact (show γ i + 0 = ℓ from h)
  | app s t ihs iht => intro γ ℓ h; exact ⟨ihs γ (ℓ + 1) h.1, iht γ ℓ h.2⟩
  | lam t ih =>
    intro γ ℓ h
    obtain ⟨k, rfl, hk⟩ := h
    exact nlev_abs (tr t) 0 k k γ (ih (scons k γ) k hk) rfl
  | eqt s t ihs iht =>
    intro γ ℓ h
    exact ⟨⟨trivial, nlev_kpush (tr s) ℓ γ (ihs γ ℓ h.1)⟩, iht γ ℓ h.2⟩
  | tt => intro γ ℓ _; trivial
  | ff => intro γ ℓ _; trivial

variable {M : Type} [S : Basis M]
local infixl:70 " ⬝ " => S.app
local notation "Bc" => S.B
local notation "Kf" => S.K
local notation "Qc" => S.q
local notation "Tc" => S.yes
local notation "Rc" => S.no

def fnFunc : {k : ℕ} → Language.Fn.Func k → (Fin k → M) → M
  | _, .tt, _ => S.yes
  | _, .ff, _ => S.no
  | _, .app, v => S.app (v 0) (v 1)
  | _, .eqt, v => S.app (S.app S.q (S.K (v 0))) (v 1)

def fnStructure : Tarski.Structure ℒλ M where
  func := fun {_} f v => fnFunc f v
  rel := fun {_} r => match r with
    | .eq => fun v => v 0 = v 1

attribute [local instance] fnStructure
local instance : Tarski.Structure.Eq ℒλ M := ⟨fun _ _ => Iff.rfl⟩
local instance : Nonempty M := ⟨S.B⟩

/-- The identity `B (B B B) B`. -/
def Ic : M := Bc ⬝ (Bc ⬝ Bc ⬝ Bc) ⬝ Bc

theorem i_app (z : M) : (Ic : M) ⬝ z = z := by
  simp only [Ic, S.b_app, S.k_app]

/-- `K` applied `m` times. -/
def kpow : ℕ → M → M
  | 0, x => x
  | m + 1, x => Kf (kpow m x)

/-- The value of an atom. -/
def aval (env : ℕ → M) : Atom → M
  | .var i => env i
  | .cB => Bc
  | .cT => Tc
  | .cR => Rc
  | .cQ => Qc

/-- The value of a normal term. -/
def nval (env : ℕ → M) : NT → M
  | .leaf m a => kpow m (aval env a)
  | .app s t => nval env s ⬝ nval env t

theorem nval_iT (env : ℕ → M) : nval env iT = Ic := rfl

theorem nval_kpush (env : ℕ → M) (T : NT) : nval env (kpush T) = Kf (nval env T) := by
  induction T with
  | leaf m a => rfl
  | app s t ihs iht =>
    show Bc ⬝ nval env (kpush s) ⬝ nval env (kpush t) = Kf (nval env s ⬝ nval env t)
    rw [ihs, iht]
    exact S.ext fun z => by simp only [S.b_app, S.k_app]

/-- **Abstraction.** -/
theorem abs_spec (T : NT) : ∀ j, Good j T → ∀ (env : ℕ → M) (x : M),
    nval env (abs j T) ⬝ kpow j x = nval (scons x env) T := by
  induction T with
  | leaf m a =>
    intro j h env x
    cases a with
    | var i =>
      cases i with
      | zero =>
        have e : m = j := h
        subst e
        show nval env iT ⬝ kpow m x = kpow m x
        rw [nval_iT, i_app]
      | succ i =>
        show Kf (kpow m (env i)) ⬝ kpow j x = kpow m (env i)
        rw [S.k_app]
    | cB => show Kf (kpow m Bc) ⬝ kpow j x = kpow m Bc; rw [S.k_app]
    | cT => show Kf (kpow m Tc) ⬝ kpow j x = kpow m Tc; rw [S.k_app]
    | cR => show Kf (kpow m Rc) ⬝ kpow j x = kpow m Rc; rw [S.k_app]
    | cQ => show Kf (kpow m Qc) ⬝ kpow j x = kpow m Qc; rw [S.k_app]
  | app s t ihs iht =>
    intro j h env x
    show Bc ⬝ nval env (abs (j + 1) s) ⬝ nval env (abs j t) ⬝ kpow j x =
      nval (scons x env) s ⬝ nval (scons x env) t
    rw [S.b_app, iht j h.2 env x]
    have := ihs (j + 1) h.1 env x
    rw [show kpow (j + 1) x = Kf (kpow j x) from rfl] at this
    rw [this]

/-- The equality test `q · K(a) · b`. -/
def EqC (a b : M) : M := Qc ⬝ Kf a ⬝ b

/-- **Every stratified λ-term has a value**, namely the value of its translation. -/
theorem den_tr (t : LTm) : ∀ (γ : ℕ → ℕ) (ℓ : ℕ), HasLev γ t ℓ → ∀ env : ℕ → M,
    FNF.Den t env (nval env (tr t)) := by
  induction t with
  | var i => intro γ ℓ _ env; rfl
  | app s t ihs iht =>
    intro γ ℓ h env
    exact ⟨_, _, ihs γ (ℓ + 1) h.1 env, iht γ ℓ h.2 env, rfl⟩
  | lam t ih =>
    intro γ ℓ h env x
    obtain ⟨k, -, hk⟩ := h
    refine ⟨_, ih (scons k γ) k hk (scons x env), ?_⟩
    exact abs_spec (tr t) 0 (nlev_good (tr t) 0 k k γ (nlev_tr t (scons k γ) k hk) rfl) env x
  | eqt s t ihs iht =>
    intro γ ℓ h env
    refine ⟨_, _, ihs γ ℓ h.1 env, iht γ ℓ h.2 env, ?_⟩
    show Qc ⬝ nval env (kpush (tr s)) ⬝ nval env (tr t) = EqC _ _
    rw [nval_kpush]
    rfl
  | tt => intro γ ℓ _ env; rfl
  | ff => intro γ ℓ _ env; rfl


theorem fnModel_models : M↓[ℒλ] ⊧* 𝗙𝗡𝗙 := by
  refine FNF.models_of ?_ ?_ ?_ ?_ ?_
  · intro f g h; exact S.ext h
  · intro a; exact S.trueAt (S.K a) a (S.k_app a a)
  · intro a b ne; exact S.falseAt (S.K a) b (by rw [S.k_app]; exact ne)
  · exact S.distinct
  · intro t γ ℓ ht env; exact ⟨nval env (tr t),den_tr t γ ℓ ht env⟩

end FFL.FirstOrder.ArbitraryBoolean
#print axioms FFL.FirstOrder.ArbitraryBoolean.fnModel_models
