module
public import CountWitness
public import JJ203Range
public import NormalizedToComb
public import CombModelCore
@[expose] public section


set_option autoImplicit false
namespace RangeNFU
open FFL FFL.FirstOrder

def HasCountingModel : Prop :=
  ∃ V : Type, ∃ nh : Nonempty V, letI := nh
  ∃ M : NFUCut.Model V, ∃ h : Fact M.Infinity, letI := h
  (∀ n : M.Num, M.T n = n) ∧ ∃ d f t F, FNF.CountSet.ProperMap M d f t F

theorem from_gap {V : Type} (N : NF192.NormalizedBasis V) (j q : V)
    (cancel : ∀ x, N.app (N.app j (N.app j x)) q = N.app j x)
    (hole : ∃ t, (∃ v, N.app j v = t) ∧ ∀ x, (∃ a, N.app j a = x) → N.app j x ≠ t) : HasCountingModel := by
  letI : Nonempty V := ⟨N.B⟩
  letI : Tarski.Structure ℒᴄ V := N.combStructure
  letI : Tarski.Structure.Eq ℒᴄ V := ⟨fun _ _ => Iff.rfl⟩
  letI : V↓[ℒᴄ] ⊧* 𝗖𝗡𝗙 := CNF.models_of
    N.k_app N.b_app N.archiveQ_true N.archiveQ_false (fun _ _ h => N.ext h) N.b_ne_bb
  let W := CNFOnly.fnOfComb.Model V
  letI : W↓[ℒλ] ⊧* 𝗙𝗡𝗙 := CNFOnly.fnModel_models
  let J : W := CNFOnly.toModel j
  let Q : W := CNFOnly.toModel q
  have app (a b : W) : ((FNF.App a b : W) : V) = N.app (a : V) (b : V) := (CNFOnly.app_iff a b _).mp rfl
  have convert (a : V) : ((CNFOnly.toModel a : W) : V) = a := rfl
  have coeJ : (J : V) = j := rfl
  have coeQ : (Q : V) = q := rfl
  have hm (a : W) (x : V) (h : N.app j x = (a : V)) :
      FNF.App J (CNFOnly.toModel x : W) = a := CNFOnly.coe_inj (by change _ = (a : V); rw [app,coeJ]; exact h)
  have gap : ∃ t : W, (∃ x, FNF.App J x = t) ∧ ∀ x, (∃ a, FNF.App J a = x) → FNF.App J x ≠ t := by
    obtain ⟨t,⟨v,hv⟩,miss⟩ := hole
    refine ⟨CNFOnly.toModel t,⟨CNFOnly.toModel v,hm _ v hv⟩,?_⟩
    rintro x ⟨a,ha⟩ e
    apply miss (x : V)
    · refine ⟨(a : V),?_⟩
      simpa only [app,coeJ,convert] using congrArg (fun c : W => (c : V)) ha
    · simpa only [app,coeJ,convert] using congrArg (fun c : W => (c : V)) e
  obtain ⟨d,_,strong,inj⟩ := FNF.JJ203.exists_strong_dedekind J Q
    (fun x => CNFOnly.coe_inj (by simpa only [app,coeJ,coeQ] using cancel (x : V))) gap
  obtain ⟨M,h,c,f,t,F,g⟩ := FNF.CountSet.model_with_strong_dedekind d strong inj
  exact ⟨W,inferInstance,M,h,c,d,f,t,F,g⟩

end RangeNFU
#print axioms RangeNFU.from_gap
