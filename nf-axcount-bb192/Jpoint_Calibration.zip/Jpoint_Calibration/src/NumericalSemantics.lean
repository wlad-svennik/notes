module
public import NumericalLogic
public import GroundRows

@[expose] public section

/-!
# From the eight numerical equality families to a countervaluation and back

The formula evaluator treats the exceptional equation `imp 0 0 = 0`
directly. For every other implication, the actual Cantor children are smaller.
An equality atom is always an odd code. No logical interpretation of term
application or of the extensionality-witness symbol is presupposed.
-/

set_option maxHeartbeats 20000000

namespace NF192.Numerical

open Ground

def AsSignature : Signature Nat where
  q := q
  app := app
  h := witness

def Valuation.rel (v : Valuation) (a b : Nat) : Prop := v.holds (eqn a b)

theorem Valuation.rows (v : Valuation) : Rows AsSignature v.rel where
  positive a b := (v.implication _ _).mp (v.sound _ (.fixedPointTrue a b))
  argCongr a b c := (v.implication _ _).mp (v.sound _ (.congrRight a b c))
  kLaw a b := v.sound _ (.constant a b)
  funCongr a b c := (v.implication _ _).mp (v.sound _ (.congrLeft a b c))
  bLaw a b c := v.sound _ (.abstraction a b c)
  euclid a b c hab hac :=
    (v.implication _ _).mp ((v.implication _ _).mp (v.sound _ (.euclidean a b c)) hab) hac
  negative a b h :=
    (v.implication _ _).mp (v.sound _ (.fixedPointFalse a b)) ((v.implication _ _).mpr h)
  ext a b := (v.implication _ _).mp (v.sound _ (.extensionality a b))

/-- Structural evaluation on literal formula codes, with arbitrary equality
atoms. No preservation assumptions on the binary predicate are needed here. -/
def evalStep (r : Nat → Nat → Prop) (n : Nat)
    (previous : ∀ m, m < n → Prop) : Prop :=
  if h0 : n = 0 then True else
  if he : n % 2 = 0 then
    let p := Cantor.unpair (n / 2)
    previous p.1 (by have h := Cantor.unpair_left_le (n / 2); dsimp [p]; omega) →
      previous p.2 (by have h := Cantor.unpair_right_le (n / 2); dsimp [p]; omega)
  else
    let p := Cantor.unpair (n / 2)
    r p.1 p.2

noncomputable def evaluate (r : Nat → Nat → Prop) (n : Nat) : Prop :=
  Nat.lt_wfRel.wf.fix (evalStep r) n

private theorem evaluate_unfold (r : Nat → Nat → Prop) (n : Nat) :
    evaluate r n = evalStep r n (fun x _ => evaluate r x) :=
  WellFounded.fix_eq _ _ _

@[simp] theorem evaluate_zero (r : Nat → Nat → Prop) : evaluate r 0 ↔ True := by
  rw [evaluate_unfold]
  simp [evalStep]

theorem evaluate_imp (r : Nat → Nat → Prop) (a b : Nat) :
    evaluate r (imp a b) ↔ (evaluate r a → evaluate r b) := by
  by_cases hz : pair a b = 0
  · obtain ⟨rfl, rfl⟩ := (Cantor.pair_zero_iff a b).mp hz
    change evaluate r 0 ↔ (evaluate r 0 → evaluate r 0)
    simp
  · have hn : imp a b ≠ 0 := by unfold imp; omega
    have he : imp a b % 2 = 0 := by unfold imp; omega
    have hd : imp a b / 2 = pair a b := by unfold imp; omega
    rw [evaluate_unfold]
    simp only [evalStep, dif_neg hn, dif_pos he, hd, Cantor.unpair_pair]

theorem evaluate_eqn (r : Nat → Nat → Prop) (a b : Nat) :
    evaluate r (eqn a b) ↔ r a b := by
  have hn : eqn a b ≠ 0 := by unfold eqn; omega
  have he : eqn a b % 2 ≠ 0 := by unfold eqn; omega
  have hd : eqn a b / 2 = pair a b := by unfold eqn; omega
  rw [evaluate_unfold]
  simp only [evalStep, dif_neg hn, dif_neg he, hd, Cantor.unpair_pair]

theorem evaluate_derivation {r : Nat → Nat → Prop} (R : Rows AsSignature r)
    {n : Nat} (d : Deriv n) : evaluate r n := by
  induction d with
  | logical a b c u _ =>
      simp only [evaluate_imp]
      intro hca hac _
      by_cases hc : evaluate r c
      · exact hc
      · exact hac (hca (fun hc' => (hc hc').elim))
  | fixedPointTrue a b =>
      simpa only [evaluate_imp, evaluate_eqn, AsSignature, Signature.s, Signature.k, Signature.b, s, B, konst] using R.positive a b
  | congrRight a b c =>
      simpa only [evaluate_imp, evaluate_eqn, AsSignature, Signature.s, Signature.k, Signature.b, s, B, konst] using R.argCongr a b c
  | constant a b =>
      simpa only [evaluate_eqn, AsSignature, Signature.s, Signature.k, Signature.b, s, B, konst] using R.kLaw a b
  | congrLeft a b c =>
      simpa only [evaluate_imp, evaluate_eqn, AsSignature, Signature.s, Signature.k, Signature.b, s, B, konst] using R.funCongr a b c
  | abstraction a b c =>
      simpa only [evaluate_eqn, AsSignature, Signature.s, Signature.k, Signature.b, s, B, konst] using R.bLaw a b c
  | euclidean a b c =>
      simpa only [evaluate_imp, evaluate_eqn, AsSignature, Signature.s, Signature.k, Signature.b, s, B, konst] using R.euclid a b c
  | fixedPointFalse a b =>
      simpa only [evaluate_imp, goal, evaluate_eqn, AsSignature, Signature.s, Signature.k, Signature.b, s, B, konst] using R.negative a b
  | extensionality a b =>
      simpa only [evaluate_imp, evaluate_eqn, AsSignature, Signature.s, Signature.k, Signature.b, s, B, konst] using R.ext a b
  | @mp a b _ _ major minor =>
      exact (evaluate_imp r a b).mp major minor

def NatCountermodel : Prop :=
  ∃ r : Nat → Nat → Prop, Rows AsSignature r ∧ ¬ r AsSignature.s AsSignature.q

theorem not_deriv_goal_iff_rows : ¬ Deriv goal ↔ NatCountermodel := by
  constructor
  · intro h
    let v := Lindenbaum.valuation h
    exact ⟨v.rel, v.rows, v.goal_false⟩
  · rintro ⟨r, R, hg⟩ d
    exact hg ((evaluate_eqn r s q).mp (evaluate_derivation R d))

end NF192.Numerical
