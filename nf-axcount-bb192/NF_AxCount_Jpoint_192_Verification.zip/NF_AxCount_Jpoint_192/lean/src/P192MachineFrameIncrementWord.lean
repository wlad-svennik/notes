module
public import P192MachineFrameCarryGeometry
public import P192MachineControlKernelExecute

@[expose] public section
namespace P192.Frame
open NF210 NF210.TM KernelRightShift KernelArithmetic KernelExecute

/-- The four trailing blanks consumed by CI become the selected register's added unit,
one new zero spare, and one remaining blank. -/
theorem increment_word (pc extra value : Nat) (earlier following : List Nat) :
    ∃ t, WordRun seekState (Carry.entryState false)
      (Carry.prefixAt pc false ++ [false,false] ++ List.replicate (extra+1) true ++ blocks earlier ++
        [false,false] ++ List.replicate value true ++ blocks following ++ List.replicate 4 false)
      (Carry.initialWord pc false ++ List.replicate (extra+1) true ++
        blocks (earlier ++ (value+1) :: (following ++ [0])) ++ List.replicate 1 false)
      ((Carry.prefixAt pc false).length + 2 : Int) (Carry.startHead pc : Int) t := by
  let front := Carry.prefixAt pc false
  have h := (KernelExecute.increment_execute extra value earlier following).context front []
  have head : (front.length : Int) + (-1) = (Carry.startHead pc : Int) := by
    simp [front,Carry.prefixAt_length,Carry.startHead,Carry.before]
    omega
  rw [head] at h
  refine ⟨(markedInput (extra+1) value earlier following).length+1+
    ([false,false] ++ increasedOutput (extra+1) value earlier following).length, ?_⟩
  have four : List.replicate 4 false = [false,false,false,false] := rfl
  have one : List.replicate 1 false = [false] := rfl
  rw [four,one]
  have bits : (List.replicate (if false then 1 else 2) false) = [false,false] := rfl
  simpa [front,Carry.initialWord,bits,markedInput,shiftInput,increasedOutput,
    KernelFiles.blocks_append,blocks,List.append_assoc,Carry.entryState,
    KernelReverse.searchEndState] using h

end P192.Frame
