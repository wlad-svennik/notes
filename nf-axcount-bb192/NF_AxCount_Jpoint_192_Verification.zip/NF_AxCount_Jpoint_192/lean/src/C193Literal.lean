module
public import C193Rows
public import NumericalEmitterChecking
@[expose] public section
/-! The input is the 3351-site register CFG decoded from the 196-state source file, split
at the exact entry and exit ordinals of the changed AX block. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace C193.Literal
open NF192.Numerical NF192.Emitter
def pre0 : List Instruction := [
  .dec 8 2 1, .jump 10, .inc 0 3, .dec 0 7 4, .inc 8 5, .inc 6 6,
  .jump 3, .dec 6 10 8, .inc 0 9, .jump 7, .dec 8 18 11, .inc 7 12,
  .dec 6 14 13, .jump 17, .dec 7 17 15, .inc 6 16, .jump 14, .jump 10,
  .dec 7 21 19, .inc 8 20, .jump 18, .dec 6 24 22, .inc 3 23, .jump 21,
  .dec 8 32 25, .inc 7 26, .dec 6 28 27, .jump 31, .dec 7 31 29, .inc 6 30,
  .jump 28, .jump 24, .dec 7 35 33, .inc 8 34, .jump 32, .dec 6 38 36,
  .inc 4 37, .jump 35, .dec 3 3304 39, .dec 3 3230 40]
def pre : List Instruction := [pre0].flatten
def mid0 : List Instruction := [
  .dec 8 48 41, .inc 7 42, .dec 6 44 43, .jump 47, .dec 7 47 45, .inc 6 46,
  .jump 44, .jump 40, .dec 7 51 49, .inc 8 50, .jump 48, .dec 6 54 52,
  .inc 5 53, .jump 51, .dec 1 57 55, .inc 6 56, .jump 54, .dec 2 60 58,
  .inc 1 59, .jump 57, .dec 1 64 61, .inc 7 62, .inc 6 63, .jump 60,
  .dec 6 70 65, .inc 7 66, .dec 6 69 67, .inc 1 68, .jump 66, .jump 60,
  .dec 7 73 71, .inc 2 72, .jump 70, .dec 3 77 74, .inc 6 75, .inc 1 76,
  .jump 73, .dec 6 80 78, .inc 3 79, .jump 77, .dec 1 83 81, .inc 6 82,
  .jump 80, .dec 2 86 84, .inc 1 85, .jump 83, .dec 1 90 87, .inc 7 88]
def mid1 : List Instruction := [
  .inc 6 89, .jump 86, .dec 6 96 91, .inc 7 92, .dec 6 95 93, .inc 1 94,
  .jump 92, .jump 86, .dec 7 99 97, .inc 2 98, .jump 96, .dec 4 103 100,
  .inc 6 101, .inc 1 102, .jump 99, .dec 6 106 104, .inc 4 105, .jump 103,
  .dec 2 114 107, .inc 7 108, .dec 6 110 109, .jump 113, .dec 7 113 111, .inc 6 112,
  .jump 110, .jump 106, .dec 7 117 115, .inc 2 116, .jump 114, .dec 1 121 118,
  .inc 7 119, .inc 6 120, .jump 117, .dec 6 127 122, .inc 7 123, .dec 6 126 124,
  .inc 1 125, .jump 123, .jump 117, .dec 7 131 128, .inc 1 129, .inc 1 130,
  .jump 127, .dec 8 139 132, .inc 7 133, .dec 6 135 134, .jump 138, .dec 7 138 136]
def mid2 : List Instruction := [
  .inc 6 137, .jump 135, .jump 131, .dec 7 142 140, .inc 8 141, .jump 139,
  .dec 6 145 143, .inc 4 144, .jump 142, .dec 1 148 146, .inc 6 147, .jump 145,
  .dec 2 151 149, .inc 1 150, .jump 148, .dec 1 155 152, .inc 7 153, .inc 6 154,
  .jump 151, .dec 6 161 156, .inc 7 157, .dec 6 160 158, .inc 1 159, .jump 157,
  .jump 151, .dec 7 164 162, .inc 2 163, .jump 161, .dec 4 168 165, .inc 6 166,
  .inc 1 167, .jump 164, .dec 6 171 169, .inc 4 170, .jump 168, .dec 2 179 172,
  .inc 7 173, .dec 6 175 174, .jump 178, .dec 7 178 176, .inc 6 177, .jump 175,
  .jump 171, .dec 7 182 180, .inc 2 181, .jump 179, .dec 1 186 183, .inc 7 184]
def mid3 : List Instruction := [
  .inc 6 185, .jump 182, .dec 6 192 187, .inc 7 188, .dec 6 191 189, .inc 1 190,
  .jump 188, .jump 182, .dec 7 196 193, .inc 1 194, .inc 1 195, .jump 192,
  .dec 1 199 197, .inc 6 198, .jump 196, .dec 2 202 200, .inc 1 201, .jump 199,
  .dec 1 206 203, .inc 7 204, .inc 6 205, .jump 202, .dec 6 212 207, .inc 7 208,
  .dec 6 211 209, .inc 1 210, .jump 208, .jump 202, .dec 7 215 213, .inc 2 214,
  .jump 212, .dec 4 219 216, .inc 6 217, .inc 1 218, .jump 215, .dec 6 222 220,
  .inc 4 221, .jump 219, .dec 1 225 223, .inc 6 224, .jump 222, .dec 2 228 226,
  .inc 1 227, .jump 225, .dec 1 232 229, .inc 7 230, .inc 6 231, .jump 228]
def mid4 : List Instruction := [
  .dec 6 238 233, .inc 7 234, .dec 6 237 235, .inc 1 236, .jump 234, .jump 228,
  .dec 7 241 239, .inc 2 240, .jump 238, .dec 3 245 242, .inc 6 243, .inc 1 244,
  .jump 241, .dec 6 248 246, .inc 3 247, .jump 245, .dec 2 256 249, .inc 7 250,
  .dec 6 252 251, .jump 255, .dec 7 255 253, .inc 6 254, .jump 252, .jump 248,
  .dec 7 259 257, .inc 2 258, .jump 256, .dec 1 263 260, .inc 7 261, .inc 6 262,
  .jump 259, .dec 6 269 264, .inc 7 265, .dec 6 268 266, .inc 1 267, .jump 265,
  .jump 259, .dec 7 273 270, .inc 1 271, .inc 1 272, .jump 269, .dec 1 276 274,
  .inc 6 275, .jump 273, .dec 2 279 277, .inc 1 278, .jump 276, .dec 1 283 280]
def mid5 : List Instruction := [
  .inc 7 281, .inc 6 282, .jump 279, .dec 6 289 284, .inc 7 285, .dec 6 288 286,
  .inc 1 287, .jump 285, .jump 279, .dec 7 292 290, .inc 2 291, .jump 289,
  .dec 5 296 293, .inc 6 294, .inc 1 295, .jump 292, .dec 6 299 297, .inc 5 298,
  .jump 296, .dec 1 302 300, .inc 6 301, .jump 299, .dec 2 305 303, .inc 1 304,
  .jump 302, .dec 1 309 306, .inc 7 307, .inc 6 308, .jump 305, .dec 6 315 310,
  .inc 7 311, .dec 6 314 312, .inc 1 313, .jump 311, .jump 305, .dec 7 318 316,
  .inc 2 317, .jump 315, .dec 3 322 319, .inc 6 320, .inc 1 321, .jump 318,
  .dec 6 325 323, .inc 3 324, .jump 322, .dec 2 333 326, .inc 7 327, .dec 6 329 328]
def mid6 : List Instruction := [
  .jump 332, .dec 7 332 330, .inc 6 331, .jump 329, .jump 325, .dec 7 336 334,
  .inc 2 335, .jump 333, .dec 1 340 337, .inc 7 338, .inc 6 339, .jump 336,
  .dec 6 346 341, .inc 7 342, .dec 6 345 343, .inc 1 344, .jump 342, .jump 336,
  .dec 7 350 347, .inc 1 348, .inc 1 349, .jump 346, .dec 2 358 351, .inc 7 352,
  .dec 6 354 353, .jump 357, .dec 7 357 355, .inc 6 356, .jump 354, .jump 350,
  .dec 7 361 359, .inc 2 360, .jump 358, .dec 1 365 362, .inc 7 363, .inc 6 364,
  .jump 361, .dec 6 371 366, .inc 7 367, .dec 6 370 368, .inc 1 369, .jump 367,
  .jump 361, .dec 7 375 372, .inc 1 373, .inc 1 374, .jump 371, .dec 2 383 376]
def mid7 : List Instruction := [
  .inc 7 377, .dec 6 379 378, .jump 382, .dec 7 382 380, .inc 6 381, .jump 379,
  .jump 375, .dec 7 386 384, .inc 2 385, .jump 383, .dec 1 390 387, .inc 7 388,
  .inc 6 389, .jump 386, .dec 6 396 391, .inc 7 392, .dec 6 395 393, .inc 1 394,
  .jump 392, .jump 386, .dec 7 400 397, .inc 1 398, .inc 1 399, .jump 396,
  .dec 1 403 401, .inc 6 402, .jump 400, .dec 2 406 404, .inc 1 405, .jump 403,
  .dec 1 410 407, .inc 7 408, .inc 6 409, .jump 406, .dec 6 416 411, .inc 7 412,
  .dec 6 415 413, .inc 1 414, .jump 412, .jump 406, .dec 7 419 417, .inc 2 418,
  .jump 416, .dec 4 423 420, .inc 6 421, .inc 1 422, .jump 419, .dec 6 426 424]
def mid8 : List Instruction := [
  .inc 4 425, .jump 423, .dec 1 429 427, .inc 6 428, .jump 426, .dec 2 432 430,
  .inc 1 431, .jump 429, .dec 1 436 433, .inc 7 434, .inc 6 435, .jump 432,
  .dec 6 442 437, .inc 7 438, .dec 6 441 439, .inc 1 440, .jump 438, .jump 432,
  .dec 7 445 443, .inc 2 444, .jump 442, .dec 5 449 446, .inc 6 447, .inc 1 448,
  .jump 445, .dec 6 452 450, .inc 5 451, .jump 449, .dec 2 460 453, .inc 7 454,
  .dec 6 456 455, .jump 459, .dec 7 459 457, .inc 6 458, .jump 456, .jump 452,
  .dec 7 463 461, .inc 2 462, .jump 460, .dec 1 467 464, .inc 7 465, .inc 6 466,
  .jump 463, .dec 6 473 468, .inc 7 469, .dec 6 472 470, .inc 1 471, .jump 469]
def mid9 : List Instruction := [
  .jump 463, .dec 7 477 474, .inc 1 475, .inc 1 476, .jump 473, .inc 1 478,
  .dec 1 481 479, .inc 6 480, .jump 478, .dec 2 484 482, .inc 1 483, .jump 481,
  .dec 1 488 485, .inc 7 486, .inc 6 487, .jump 484, .dec 6 494 489, .inc 7 490,
  .dec 6 493 491, .inc 1 492, .jump 490, .jump 484, .dec 7 497 495, .inc 2 496,
  .jump 494, .dec 5 501 498, .inc 6 499, .inc 1 500, .jump 497, .dec 6 504 502,
  .inc 5 503, .jump 501, .dec 2 512 505, .inc 7 506, .dec 6 508 507, .jump 511,
  .dec 7 511 509, .inc 6 510, .jump 508, .jump 504, .dec 7 515 513, .inc 2 514,
  .jump 512, .dec 1 519 516, .inc 7 517, .inc 6 518, .jump 515, .dec 6 525 520]
def mid10 : List Instruction := [
  .inc 7 521, .dec 6 524 522, .inc 1 523, .jump 521, .jump 515, .dec 7 529 526,
  .inc 1 527, .inc 1 528, .jump 525, .inc 1 530, .dec 1 533 531, .inc 6 532,
  .jump 530, .dec 2 536 534, .inc 1 535, .jump 533, .dec 1 540 537, .inc 7 538,
  .inc 6 539, .jump 536, .dec 6 546 541, .inc 7 542, .dec 6 545 543, .inc 1 544,
  .jump 542, .jump 536, .dec 7 549 547, .inc 2 548, .jump 546, .inc 1 550,
  .dec 1 553 551, .inc 6 552, .jump 550, .dec 2 556 554, .inc 1 555, .jump 553,
  .dec 1 560 557, .inc 7 558, .inc 6 559, .jump 556, .dec 6 566 561, .inc 7 562,
  .dec 6 565 563, .inc 1 564, .jump 562, .jump 556, .dec 7 569 567, .inc 2 568]
def mid11 : List Instruction := [
  .jump 566, .inc 1 570, .dec 1 573 571, .inc 6 572, .jump 570, .dec 2 576 574,
  .inc 1 575, .jump 573, .dec 1 580 577, .inc 7 578, .inc 6 579, .jump 576,
  .dec 6 586 581, .inc 7 582, .dec 6 585 583, .inc 1 584, .jump 582, .jump 576,
  .dec 7 589 587, .inc 2 588, .jump 586, .dec 4 593 590, .inc 6 591, .inc 1 592,
  .jump 589, .dec 6 596 594, .inc 4 595, .jump 593, .dec 2 604 597, .inc 7 598,
  .dec 6 600 599, .jump 603, .dec 7 603 601, .inc 6 602, .jump 600, .jump 596,
  .dec 7 607 605, .inc 2 606, .jump 604, .dec 1 611 608, .inc 7 609, .inc 6 610,
  .jump 607, .dec 6 617 612, .inc 7 613, .dec 6 616 614, .inc 1 615, .jump 613]
def mid12 : List Instruction := [
  .jump 607, .dec 7 621 618, .inc 1 619, .inc 1 620, .jump 617, .inc 1 622,
  .dec 1 625 623, .inc 6 624, .jump 622, .dec 2 628 626, .inc 1 627, .jump 625,
  .dec 1 632 629, .inc 7 630, .inc 6 631, .jump 628, .dec 6 638 633, .inc 7 634,
  .dec 6 637 635, .inc 1 636, .jump 634, .jump 628, .dec 7 641 639, .inc 2 640,
  .jump 638, .dec 5 645 642, .inc 6 643, .inc 1 644, .jump 641, .dec 6 648 646,
  .inc 5 647, .jump 645, .dec 2 656 649, .inc 7 650, .dec 6 652 651, .jump 655,
  .dec 7 655 653, .inc 6 654, .jump 652, .jump 648, .dec 7 659 657, .inc 2 658,
  .jump 656, .dec 1 663 660, .inc 7 661, .inc 6 662, .jump 659, .dec 6 669 664]
def mid13 : List Instruction := [
  .inc 7 665, .dec 6 668 666, .inc 1 667, .jump 665, .jump 659, .dec 7 673 670,
  .inc 1 671, .inc 1 672, .jump 669, .inc 1 674, .dec 2 682 675, .inc 7 676,
  .dec 6 678 677, .jump 681, .dec 7 681 679, .inc 6 680, .jump 678, .jump 674,
  .dec 7 685 683, .inc 2 684, .jump 682, .dec 1 689 686, .inc 7 687, .inc 6 688,
  .jump 685, .dec 6 695 690, .inc 7 691, .dec 6 694 692, .inc 1 693, .jump 691,
  .jump 685, .dec 7 699 696, .inc 1 697, .inc 1 698, .jump 695, .inc 1 700,
  .dec 2 708 701, .inc 7 702, .dec 6 704 703, .jump 707, .dec 7 707 705, .inc 6 706,
  .jump 704, .jump 700, .dec 7 711 709, .inc 2 710, .jump 708, .dec 1 715 712]
def mid14 : List Instruction := [
  .inc 7 713, .inc 6 714, .jump 711, .dec 6 721 716, .inc 7 717, .dec 6 720 718,
  .inc 1 719, .jump 717, .jump 711, .dec 7 725 722, .inc 1 723, .inc 1 724,
  .jump 721, .dec 1 728 726, .inc 6 727, .jump 725, .dec 2 731 729, .inc 1 730,
  .jump 728, .dec 1 735 732, .inc 7 733, .inc 6 734, .jump 731, .dec 6 741 736,
  .inc 7 737, .dec 6 740 738, .inc 1 739, .jump 737, .jump 731, .dec 7 744 742,
  .inc 2 743, .jump 741, .inc 1 745, .inc 1 746, .inc 1 747, .inc 1 748,
  .dec 1 751 749, .inc 6 750, .jump 748, .dec 2 754 752, .inc 1 753, .jump 751,
  .dec 1 758 755, .inc 7 756, .inc 6 757, .jump 754, .dec 6 764 759, .inc 7 760]
def mid15 : List Instruction := [
  .dec 6 763 761, .inc 1 762, .jump 760, .jump 754, .dec 7 767 765, .inc 2 766,
  .jump 764, .dec 3 771 768, .inc 6 769, .inc 1 770, .jump 767, .dec 6 774 772,
  .inc 3 773, .jump 771, .dec 2 782 775, .inc 7 776, .dec 6 778 777, .jump 781,
  .dec 7 781 779, .inc 6 780, .jump 778, .jump 774, .dec 7 785 783, .inc 2 784,
  .jump 782, .dec 1 789 786, .inc 7 787, .inc 6 788, .jump 785, .dec 6 795 790,
  .inc 7 791, .dec 6 794 792, .inc 1 793, .jump 791, .jump 785, .dec 7 799 796,
  .inc 1 797, .inc 1 798, .jump 795, .inc 1 800, .dec 1 803 801, .inc 6 802,
  .jump 800, .dec 2 806 804, .inc 1 805, .jump 803, .dec 1 810 807, .inc 7 808]
def mid16 : List Instruction := [
  .inc 6 809, .jump 806, .dec 6 816 811, .inc 7 812, .dec 6 815 813, .inc 1 814,
  .jump 812, .jump 806, .dec 7 819 817, .inc 2 818, .jump 816, .dec 4 823 820,
  .inc 6 821, .inc 1 822, .jump 819, .dec 6 826 824, .inc 4 825, .jump 823,
  .dec 2 834 827, .inc 7 828, .dec 6 830 829, .jump 833, .dec 7 833 831, .inc 6 832,
  .jump 830, .jump 826, .dec 7 837 835, .inc 2 836, .jump 834, .dec 1 841 838,
  .inc 7 839, .inc 6 840, .jump 837, .dec 6 847 842, .inc 7 843, .dec 6 846 844,
  .inc 1 845, .jump 843, .jump 837, .dec 7 851 848, .inc 1 849, .inc 1 850,
  .jump 847, .inc 1 852, .dec 1 855 853, .inc 6 854, .jump 852, .dec 2 858 856]
def mid17 : List Instruction := [
  .inc 1 857, .jump 855, .dec 1 862 859, .inc 7 860, .inc 6 861, .jump 858,
  .dec 6 868 863, .inc 7 864, .dec 6 867 865, .inc 1 866, .jump 864, .jump 858,
  .dec 7 871 869, .inc 2 870, .jump 868, .dec 5 875 872, .inc 6 873, .inc 1 874,
  .jump 871, .dec 6 878 876, .inc 5 877, .jump 875, .dec 2 886 879, .inc 7 880,
  .dec 6 882 881, .jump 885, .dec 7 885 883, .inc 6 884, .jump 882, .jump 878,
  .dec 7 889 887, .inc 2 888, .jump 886, .dec 1 893 890, .inc 7 891, .inc 6 892,
  .jump 889, .dec 6 899 894, .inc 7 895, .dec 6 898 896, .inc 1 897, .jump 895,
  .jump 889, .dec 7 903 900, .inc 1 901, .inc 1 902, .jump 899, .inc 1 904]
def mid18 : List Instruction := [
  .dec 1 907 905, .inc 6 906, .jump 904, .dec 2 910 908, .inc 1 909, .jump 907,
  .dec 1 914 911, .inc 7 912, .inc 6 913, .jump 910, .dec 6 920 915, .inc 7 916,
  .dec 6 919 917, .inc 1 918, .jump 916, .jump 910, .dec 7 923 921, .inc 2 922,
  .jump 920, .dec 3 927 924, .inc 6 925, .inc 1 926, .jump 923, .dec 6 930 928,
  .inc 3 929, .jump 927, .dec 1 933 931, .inc 6 932, .jump 930, .dec 2 936 934,
  .inc 1 935, .jump 933, .dec 1 940 937, .inc 7 938, .inc 6 939, .jump 936,
  .dec 6 946 941, .inc 7 942, .dec 6 945 943, .inc 1 944, .jump 942, .jump 936,
  .dec 7 949 947, .inc 2 948, .jump 946, .dec 5 953 950, .inc 6 951, .inc 1 952]
def mid19 : List Instruction := [
  .jump 949, .dec 6 956 954, .inc 5 955, .jump 953, .dec 1 959 957, .inc 6 958,
  .jump 956, .dec 2 962 960, .inc 1 961, .jump 959, .dec 1 966 963, .inc 7 964,
  .inc 6 965, .jump 962, .dec 6 972 967, .inc 7 968, .dec 6 971 969, .inc 1 970,
  .jump 968, .jump 962, .dec 7 975 973, .inc 2 974, .jump 972, .dec 5 979 976,
  .inc 6 977, .inc 1 978, .jump 975, .dec 6 982 980, .inc 5 981, .jump 979,
  .dec 2 990 983, .inc 7 984, .dec 6 986 985, .jump 989, .dec 7 989 987, .inc 6 988,
  .jump 986, .jump 982, .dec 7 993 991, .inc 2 992, .jump 990, .dec 1 997 994,
  .inc 7 995, .inc 6 996, .jump 993, .dec 6 1003 998, .inc 7 999, .dec 6 1002 1000]
def mid20 : List Instruction := [
  .inc 1 1001, .jump 999, .jump 993, .dec 7 1007 1004, .inc 1 1005, .inc 1 1006,
  .jump 1003, .inc 1 1008, .inc 1 1009, .dec 2 1017 1010, .inc 7 1011, .dec 6 1013 1012,
  .jump 1016, .dec 7 1016 1014, .inc 6 1015, .jump 1013, .jump 1009, .dec 7 1020 1018,
  .inc 2 1019, .jump 1017, .dec 1 1024 1021, .inc 7 1022, .inc 6 1023, .jump 1020,
  .dec 6 1030 1025, .inc 7 1026, .dec 6 1029 1027, .inc 1 1028, .jump 1026, .jump 1020,
  .dec 7 1034 1031, .inc 1 1032, .inc 1 1033, .jump 1030, .inc 1 1035, .dec 1 1038 1036,
  .inc 6 1037, .jump 1035, .dec 2 1041 1039, .inc 1 1040, .jump 1038, .dec 1 1045 1042,
  .inc 7 1043, .inc 6 1044, .jump 1041, .dec 6 1051 1046, .inc 7 1047, .dec 6 1050 1048]
def mid21 : List Instruction := [
  .inc 1 1049, .jump 1047, .jump 1041, .dec 7 1054 1052, .inc 2 1053, .jump 1051,
  .dec 4 1058 1055, .inc 6 1056, .inc 1 1057, .jump 1054, .dec 6 1061 1059, .inc 4 1060,
  .jump 1058, .dec 1 1064 1062, .inc 6 1063, .jump 1061, .dec 2 1067 1065, .inc 1 1066,
  .jump 1064, .dec 1 1071 1068, .inc 7 1069, .inc 6 1070, .jump 1067, .dec 6 1077 1072,
  .inc 7 1073, .dec 6 1076 1074, .inc 1 1075, .jump 1073, .jump 1067, .dec 7 1080 1078,
  .inc 2 1079, .jump 1077, .dec 5 1084 1081, .inc 6 1082, .inc 1 1083, .jump 1080,
  .dec 6 1087 1085, .inc 5 1086, .jump 1084, .dec 2 1095 1088, .inc 7 1089, .dec 6 1091 1090,
  .jump 1094, .dec 7 1094 1092, .inc 6 1093, .jump 1091, .jump 1087, .dec 7 1098 1096]
def mid22 : List Instruction := [
  .inc 2 1097, .jump 1095, .dec 1 1102 1099, .inc 7 1100, .inc 6 1101, .jump 1098,
  .dec 6 1108 1103, .inc 7 1104, .dec 6 1107 1105, .inc 1 1106, .jump 1104, .jump 1098,
  .dec 7 1112 1109, .inc 1 1110, .inc 1 1111, .jump 1108, .inc 1 1113, .dec 2 1121 1114,
  .inc 7 1115, .dec 6 1117 1116, .jump 1120, .dec 7 1120 1118, .inc 6 1119, .jump 1117,
  .jump 1113, .dec 7 1124 1122, .inc 2 1123, .jump 1121, .dec 1 1128 1125, .inc 7 1126,
  .inc 6 1127, .jump 1124, .dec 6 1134 1129, .inc 7 1130, .dec 6 1133 1131, .inc 1 1132,
  .jump 1130, .jump 1124, .dec 7 1138 1135, .inc 1 1136, .inc 1 1137, .jump 1134,
  .inc 1 1139, .dec 2 1147 1140, .inc 7 1141, .dec 6 1143 1142, .jump 1146, .dec 7 1146 1144]
def mid23 : List Instruction := [
  .inc 6 1145, .jump 1143, .jump 1139, .dec 7 1150 1148, .inc 2 1149, .jump 1147,
  .dec 1 1154 1151, .inc 7 1152, .inc 6 1153, .jump 1150, .dec 6 1160 1155, .inc 7 1156,
  .dec 6 1159 1157, .inc 1 1158, .jump 1156, .jump 1150, .dec 7 1164 1161, .inc 1 1162,
  .inc 1 1163, .jump 1160, .inc 1 1165, .dec 1 1168 1166, .inc 6 1167, .jump 1165,
  .dec 2 1171 1169, .inc 1 1170, .jump 1168, .dec 1 1175 1172, .inc 7 1173, .inc 6 1174,
  .jump 1171, .dec 6 1181 1176, .inc 7 1177, .dec 6 1180 1178, .inc 1 1179, .jump 1177,
  .jump 1171, .dec 7 1184 1182, .inc 2 1183, .jump 1181, .dec 3 1188 1185, .inc 6 1186,
  .inc 1 1187, .jump 1184, .dec 6 1191 1189, .inc 3 1190, .jump 1188, .dec 1 1194 1192]
def mid24 : List Instruction := [
  .inc 6 1193, .jump 1191, .dec 2 1197 1195, .inc 1 1196, .jump 1194, .dec 1 1201 1198,
  .inc 7 1199, .inc 6 1200, .jump 1197, .dec 6 1207 1202, .inc 7 1203, .dec 6 1206 1204,
  .inc 1 1205, .jump 1203, .jump 1197, .dec 7 1210 1208, .inc 2 1209, .jump 1207,
  .dec 5 1214 1211, .inc 6 1212, .inc 1 1213, .jump 1210, .dec 6 1217 1215, .inc 5 1216,
  .jump 1214, .dec 2 1225 1218, .inc 7 1219, .dec 6 1221 1220, .jump 1224, .dec 7 1224 1222,
  .inc 6 1223, .jump 1221, .jump 1217, .dec 7 1228 1226, .inc 2 1227, .jump 1225,
  .dec 1 1232 1229, .inc 7 1230, .inc 6 1231, .jump 1228, .dec 6 1238 1233, .inc 7 1234,
  .dec 6 1237 1235, .inc 1 1236, .jump 1234, .jump 1228, .dec 7 1242 1239, .inc 1 1240]
def mid25 : List Instruction := [
  .inc 1 1241, .jump 1238, .inc 1 1243, .dec 1 1246 1244, .inc 6 1245, .jump 1243,
  .dec 2 1249 1247, .inc 1 1248, .jump 1246, .dec 1 1253 1250, .inc 7 1251, .inc 6 1252,
  .jump 1249, .dec 6 1259 1254, .inc 7 1255, .dec 6 1258 1256, .inc 1 1257, .jump 1255,
  .jump 1249, .dec 7 1262 1260, .inc 2 1261, .jump 1259, .dec 4 1266 1263, .inc 6 1264,
  .inc 1 1265, .jump 1262, .dec 6 1269 1267, .inc 4 1268, .jump 1266, .dec 1 1272 1270,
  .inc 6 1271, .jump 1269, .dec 2 1275 1273, .inc 1 1274, .jump 1272, .dec 1 1279 1276,
  .inc 7 1277, .inc 6 1278, .jump 1275, .dec 6 1285 1280, .inc 7 1281, .dec 6 1284 1282,
  .inc 1 1283, .jump 1281, .jump 1275, .dec 7 1288 1286, .inc 2 1287, .jump 1285]
def mid26 : List Instruction := [
  .dec 3 1292 1289, .inc 6 1290, .inc 1 1291, .jump 1288, .dec 6 1295 1293, .inc 3 1294,
  .jump 1292, .dec 2 1303 1296, .inc 7 1297, .dec 6 1299 1298, .jump 1302, .dec 7 1302 1300,
  .inc 6 1301, .jump 1299, .jump 1295, .dec 7 1306 1304, .inc 2 1305, .jump 1303,
  .dec 1 1310 1307, .inc 7 1308, .inc 6 1309, .jump 1306, .dec 6 1316 1311, .inc 7 1312,
  .dec 6 1315 1313, .inc 1 1314, .jump 1312, .jump 1306, .dec 7 1320 1317, .inc 1 1318,
  .inc 1 1319, .jump 1316, .inc 1 1321, .dec 1 1324 1322, .inc 6 1323, .jump 1321,
  .dec 2 1327 1325, .inc 1 1326, .jump 1324, .dec 1 1331 1328, .inc 7 1329, .inc 6 1330,
  .jump 1327, .dec 6 1337 1332, .inc 7 1333, .dec 6 1336 1334, .inc 1 1335, .jump 1333]
def mid27 : List Instruction := [
  .jump 1327, .dec 7 1340 1338, .inc 2 1339, .jump 1337, .dec 4 1344 1341, .inc 6 1342,
  .inc 1 1343, .jump 1340, .dec 6 1347 1345, .inc 4 1346, .jump 1344, .dec 1 1350 1348,
  .inc 6 1349, .jump 1347, .dec 2 1353 1351, .inc 1 1352, .jump 1350, .dec 1 1357 1354,
  .inc 7 1355, .inc 6 1356, .jump 1353, .dec 6 1363 1358, .inc 7 1359, .dec 6 1362 1360,
  .inc 1 1361, .jump 1359, .jump 1353, .dec 7 1366 1364, .inc 2 1365, .jump 1363,
  .dec 5 1370 1367, .inc 6 1368, .inc 1 1369, .jump 1366, .dec 6 1373 1371, .inc 5 1372,
  .jump 1370, .dec 2 1381 1374, .inc 7 1375, .dec 6 1377 1376, .jump 1380, .dec 7 1380 1378,
  .inc 6 1379, .jump 1377, .jump 1373, .dec 7 1384 1382, .inc 2 1383, .jump 1381]
def mid28 : List Instruction := [
  .dec 1 1388 1385, .inc 7 1386, .inc 6 1387, .jump 1384, .dec 6 1394 1389, .inc 7 1390,
  .dec 6 1393 1391, .inc 1 1392, .jump 1390, .jump 1384, .dec 7 1398 1395, .inc 1 1396,
  .inc 1 1397, .jump 1394, .inc 1 1399, .dec 2 1407 1400, .inc 7 1401, .dec 6 1403 1402,
  .jump 1406, .dec 7 1406 1404, .inc 6 1405, .jump 1403, .jump 1399, .dec 7 1410 1408,
  .inc 2 1409, .jump 1407, .dec 1 1414 1411, .inc 7 1412, .inc 6 1413, .jump 1410,
  .dec 6 1420 1415, .inc 7 1416, .dec 6 1419 1417, .inc 1 1418, .jump 1416, .jump 1410,
  .dec 7 1424 1421, .inc 1 1422, .inc 1 1423, .jump 1420, .inc 1 1425, .dec 2 1433 1426,
  .inc 7 1427, .dec 6 1429 1428, .jump 1432, .dec 7 1432 1430, .inc 6 1431, .jump 1429]
def mid29 : List Instruction := [
  .jump 1425, .dec 7 1436 1434, .inc 2 1435, .jump 1433, .dec 1 1440 1437, .inc 7 1438,
  .inc 6 1439, .jump 1436, .dec 6 1446 1441, .inc 7 1442, .dec 6 1445 1443, .inc 1 1444,
  .jump 1442, .jump 1436, .dec 7 1450 1447, .inc 1 1448, .inc 1 1449, .jump 1446,
  .dec 1 1453 1451, .inc 6 1452, .jump 1450, .dec 2 1456 1454, .inc 1 1455, .jump 1453,
  .dec 1 1460 1457, .inc 7 1458, .inc 6 1459, .jump 1456, .dec 6 1466 1461, .inc 7 1462,
  .dec 6 1465 1463, .inc 1 1464, .jump 1462, .jump 1456, .dec 7 1469 1467, .inc 2 1468,
  .jump 1466, .dec 4 1473 1470, .inc 6 1471, .inc 1 1472, .jump 1469, .dec 6 1476 1474,
  .inc 4 1475, .jump 1473, .dec 1 1479 1477, .inc 6 1478, .jump 1476, .dec 2 1482 1480]
def mid30 : List Instruction := [
  .inc 1 1481, .jump 1479, .dec 1 1486 1483, .inc 7 1484, .inc 6 1485, .jump 1482,
  .dec 6 1492 1487, .inc 7 1488, .dec 6 1491 1489, .inc 1 1490, .jump 1488, .jump 1482,
  .dec 7 1495 1493, .inc 2 1494, .jump 1492, .dec 3 1499 1496, .inc 6 1497, .inc 1 1498,
  .jump 1495, .dec 6 1502 1500, .inc 3 1501, .jump 1499, .dec 2 1510 1503, .inc 7 1504,
  .dec 6 1506 1505, .jump 1509, .dec 7 1509 1507, .inc 6 1508, .jump 1506, .jump 1502,
  .dec 7 1513 1511, .inc 2 1512, .jump 1510, .dec 1 1517 1514, .inc 7 1515, .inc 6 1516,
  .jump 1513, .dec 6 1523 1518, .inc 7 1519, .dec 6 1522 1520, .inc 1 1521, .jump 1519,
  .jump 1513, .dec 7 1527 1524, .inc 1 1525, .inc 1 1526, .jump 1523, .inc 1 1528]
def mid31 : List Instruction := [
  .dec 1 1531 1529, .inc 6 1530, .jump 1528, .dec 2 1534 1532, .inc 1 1533, .jump 1531,
  .dec 1 1538 1535, .inc 7 1536, .inc 6 1537, .jump 1534, .dec 6 1544 1539, .inc 7 1540,
  .dec 6 1543 1541, .inc 1 1542, .jump 1540, .jump 1534, .dec 7 1547 1545, .inc 2 1546,
  .jump 1544, .dec 3 1551 1548, .inc 6 1549, .inc 1 1550, .jump 1547, .dec 6 1554 1552,
  .inc 3 1553, .jump 1551, .dec 1 1557 1555, .inc 6 1556, .jump 1554, .dec 2 1560 1558,
  .inc 1 1559, .jump 1557, .dec 1 1564 1561, .inc 7 1562, .inc 6 1563, .jump 1560,
  .dec 6 1570 1565, .inc 7 1566, .dec 6 1569 1567, .inc 1 1568, .jump 1566, .jump 1560,
  .dec 7 1573 1571, .inc 2 1572, .jump 1570, .dec 5 1577 1574, .inc 6 1575, .inc 1 1576]
def mid32 : List Instruction := [
  .jump 1573, .dec 6 1580 1578, .inc 5 1579, .jump 1577, .dec 2 1588 1581, .inc 7 1582,
  .dec 6 1584 1583, .jump 1587, .dec 7 1587 1585, .inc 6 1586, .jump 1584, .jump 1580,
  .dec 7 1591 1589, .inc 2 1590, .jump 1588, .dec 1 1595 1592, .inc 7 1593, .inc 6 1594,
  .jump 1591, .dec 6 1601 1596, .inc 7 1597, .dec 6 1600 1598, .inc 1 1599, .jump 1597,
  .jump 1591, .dec 7 1605 1602, .inc 1 1603, .inc 1 1604, .jump 1601, .inc 1 1606,
  .dec 1 1609 1607, .inc 6 1608, .jump 1606, .dec 2 1612 1610, .inc 1 1611, .jump 1609,
  .dec 1 1616 1613, .inc 7 1614, .inc 6 1615, .jump 1612, .dec 6 1622 1617, .inc 7 1618,
  .dec 6 1621 1619, .inc 1 1620, .jump 1618, .jump 1612, .dec 7 1625 1623, .inc 2 1624]
def mid33 : List Instruction := [
  .jump 1622, .dec 4 1629 1626, .inc 6 1627, .inc 1 1628, .jump 1625, .dec 6 1632 1630,
  .inc 4 1631, .jump 1629, .dec 1 1635 1633, .inc 6 1634, .jump 1632, .dec 2 1638 1636,
  .inc 1 1637, .jump 1635, .dec 1 1642 1639, .inc 7 1640, .inc 6 1641, .jump 1638,
  .dec 6 1648 1643, .inc 7 1644, .dec 6 1647 1645, .inc 1 1646, .jump 1644, .jump 1638,
  .dec 7 1651 1649, .inc 2 1650, .jump 1648, .dec 5 1655 1652, .inc 6 1653, .inc 1 1654,
  .jump 1651, .dec 6 1658 1656, .inc 5 1657, .jump 1655, .dec 2 1666 1659, .inc 7 1660,
  .dec 6 1662 1661, .jump 1665, .dec 7 1665 1663, .inc 6 1664, .jump 1662, .jump 1658,
  .dec 7 1669 1667, .inc 2 1668, .jump 1666, .dec 1 1673 1670, .inc 7 1671, .inc 6 1672]
def mid34 : List Instruction := [
  .jump 1669, .dec 6 1679 1674, .inc 7 1675, .dec 6 1678 1676, .inc 1 1677, .jump 1675,
  .jump 1669, .dec 7 1683 1680, .inc 1 1681, .inc 1 1682, .jump 1679, .inc 1 1684,
  .dec 2 1692 1685, .inc 7 1686, .dec 6 1688 1687, .jump 1691, .dec 7 1691 1689, .inc 6 1690,
  .jump 1688, .jump 1684, .dec 7 1695 1693, .inc 2 1694, .jump 1692, .dec 1 1699 1696,
  .inc 7 1697, .inc 6 1698, .jump 1695, .dec 6 1705 1700, .inc 7 1701, .dec 6 1704 1702,
  .inc 1 1703, .jump 1701, .jump 1695, .dec 7 1709 1706, .inc 1 1707, .inc 1 1708,
  .jump 1705, .inc 1 1710, .dec 2 1718 1711, .inc 7 1712, .dec 6 1714 1713, .jump 1717,
  .dec 7 1717 1715, .inc 6 1716, .jump 1714, .jump 1710, .dec 7 1721 1719, .inc 2 1720]
def mid35 : List Instruction := [
  .jump 1718, .dec 1 1725 1722, .inc 7 1723, .inc 6 1724, .jump 1721, .dec 6 1731 1726,
  .inc 7 1727, .dec 6 1730 1728, .inc 1 1729, .jump 1727, .jump 1721, .dec 7 1735 1732,
  .inc 1 1733, .inc 1 1734, .jump 1731, .dec 1 1738 1736, .inc 6 1737, .jump 1735,
  .dec 2 1741 1739, .inc 1 1740, .jump 1738, .dec 1 1745 1742, .inc 7 1743, .inc 6 1744,
  .jump 1741, .dec 6 1751 1746, .inc 7 1747, .dec 6 1750 1748, .inc 1 1749, .jump 1747,
  .jump 1741, .dec 7 1754 1752, .inc 2 1753, .jump 1751, .dec 4 1758 1755, .inc 6 1756,
  .inc 1 1757, .jump 1754, .dec 6 1761 1759, .inc 4 1760, .jump 1758, .dec 1 1764 1762,
  .inc 6 1763, .jump 1761, .dec 2 1767 1765, .inc 1 1766, .jump 1764, .dec 1 1771 1768]
def mid36 : List Instruction := [
  .inc 7 1769, .inc 6 1770, .jump 1767, .dec 6 1777 1772, .inc 7 1773, .dec 6 1776 1774,
  .inc 1 1775, .jump 1773, .jump 1767, .dec 7 1780 1778, .inc 2 1779, .jump 1777,
  .dec 5 1784 1781, .inc 6 1782, .inc 1 1783, .jump 1780, .dec 6 1787 1785, .inc 5 1786,
  .jump 1784, .dec 2 1795 1788, .inc 7 1789, .dec 6 1791 1790, .jump 1794, .dec 7 1794 1792,
  .inc 6 1793, .jump 1791, .jump 1787, .dec 7 1798 1796, .inc 2 1797, .jump 1795,
  .dec 1 1802 1799, .inc 7 1800, .inc 6 1801, .jump 1798, .dec 6 1808 1803, .inc 7 1804,
  .dec 6 1807 1805, .inc 1 1806, .jump 1804, .jump 1798, .dec 7 1812 1809, .inc 1 1810,
  .inc 1 1811, .jump 1808, .inc 1 1813, .dec 1 1816 1814, .inc 6 1815, .jump 1813]
def mid37 : List Instruction := [
  .dec 2 1819 1817, .inc 1 1818, .jump 1816, .dec 1 1823 1820, .inc 7 1821, .inc 6 1822,
  .jump 1819, .dec 6 1829 1824, .inc 7 1825, .dec 6 1828 1826, .inc 1 1827, .jump 1825,
  .jump 1819, .dec 7 1832 1830, .inc 2 1831, .jump 1829, .dec 4 1836 1833, .inc 6 1834,
  .inc 1 1835, .jump 1832, .dec 6 1839 1837, .inc 4 1838, .jump 1836, .dec 1 1842 1840,
  .inc 6 1841, .jump 1839, .dec 2 1845 1843, .inc 1 1844, .jump 1842, .dec 1 1849 1846,
  .inc 7 1847, .inc 6 1848, .jump 1845, .dec 6 1855 1850, .inc 7 1851, .dec 6 1854 1852,
  .inc 1 1853, .jump 1851, .jump 1845, .dec 7 1858 1856, .inc 2 1857, .jump 1855,
  .dec 3 1862 1859, .inc 6 1860, .inc 1 1861, .jump 1858, .dec 6 1865 1863, .inc 3 1864]
def mid38 : List Instruction := [
  .jump 1862, .dec 2 1873 1866, .inc 7 1867, .dec 6 1869 1868, .jump 1872, .dec 7 1872 1870,
  .inc 6 1871, .jump 1869, .jump 1865, .dec 7 1876 1874, .inc 2 1875, .jump 1873,
  .dec 1 1880 1877, .inc 7 1878, .inc 6 1879, .jump 1876, .dec 6 1886 1881, .inc 7 1882,
  .dec 6 1885 1883, .inc 1 1884, .jump 1882, .jump 1876, .dec 7 1890 1887, .inc 1 1888,
  .inc 1 1889, .jump 1886, .inc 1 1891, .dec 1 1894 1892, .inc 6 1893, .jump 1891,
  .dec 2 1897 1895, .inc 1 1896, .jump 1894, .dec 1 1901 1898, .inc 7 1899, .inc 6 1900,
  .jump 1897, .dec 6 1907 1902, .inc 7 1903, .dec 6 1906 1904, .inc 1 1905, .jump 1903,
  .jump 1897, .dec 7 1910 1908, .inc 2 1909, .jump 1907, .dec 3 1914 1911, .inc 6 1912]
def mid39 : List Instruction := [
  .inc 1 1913, .jump 1910, .dec 6 1917 1915, .inc 3 1916, .jump 1914, .dec 1 1920 1918,
  .inc 6 1919, .jump 1917, .dec 2 1923 1921, .inc 1 1922, .jump 1920, .dec 1 1927 1924,
  .inc 7 1925, .inc 6 1926, .jump 1923, .dec 6 1933 1928, .inc 7 1929, .dec 6 1932 1930,
  .inc 1 1931, .jump 1929, .jump 1923, .dec 7 1936 1934, .inc 2 1935, .jump 1933,
  .dec 5 1940 1937, .inc 6 1938, .inc 1 1939, .jump 1936, .dec 6 1943 1941, .inc 5 1942,
  .jump 1940, .dec 2 1951 1944, .inc 7 1945, .dec 6 1947 1946, .jump 1950, .dec 7 1950 1948,
  .inc 6 1949, .jump 1947, .jump 1943, .dec 7 1954 1952, .inc 2 1953, .jump 1951,
  .dec 1 1958 1955, .inc 7 1956, .inc 6 1957, .jump 1954, .dec 6 1964 1959, .inc 7 1960]
def mid40 : List Instruction := [
  .dec 6 1963 1961, .inc 1 1962, .jump 1960, .jump 1954, .dec 7 1968 1965, .inc 1 1966,
  .inc 1 1967, .jump 1964, .inc 1 1969, .dec 2 1977 1970, .inc 7 1971, .dec 6 1973 1972,
  .jump 1976, .dec 7 1976 1974, .inc 6 1975, .jump 1973, .jump 1969, .dec 7 1980 1978,
  .inc 2 1979, .jump 1977, .dec 1 1984 1981, .inc 7 1982, .inc 6 1983, .jump 1980,
  .dec 6 1990 1985, .inc 7 1986, .dec 6 1989 1987, .inc 1 1988, .jump 1986, .jump 1980,
  .dec 7 1994 1991, .inc 1 1992, .inc 1 1993, .jump 1990, .dec 2 2002 1995, .inc 7 1996,
  .dec 6 1998 1997, .jump 2001, .dec 7 2001 1999, .inc 6 2000, .jump 1998, .jump 1994,
  .dec 7 2005 2003, .inc 2 2004, .jump 2002, .dec 1 2009 2006, .inc 7 2007, .inc 6 2008]
def mid41 : List Instruction := [
  .jump 2005, .dec 6 2015 2010, .inc 7 2011, .dec 6 2014 2012, .inc 1 2013, .jump 2011,
  .jump 2005, .dec 7 2019 2016, .inc 1 2017, .inc 1 2018, .jump 2015, .dec 1 2022 2020,
  .inc 6 2021, .jump 2019, .dec 2 2025 2023, .inc 1 2024, .jump 2022, .dec 1 2029 2026,
  .inc 7 2027, .inc 6 2028, .jump 2025, .dec 6 2035 2030, .inc 7 2031, .dec 6 2034 2032,
  .inc 1 2033, .jump 2031, .jump 2025, .dec 7 2038 2036, .inc 2 2037, .jump 2035,
  .dec 4 2042 2039, .inc 6 2040, .inc 1 2041, .jump 2038, .dec 6 2045 2043, .inc 4 2044,
  .jump 2042, .dec 1 2048 2046, .inc 6 2047, .jump 2045, .dec 2 2051 2049, .inc 1 2050,
  .jump 2048, .dec 1 2055 2052, .inc 7 2053, .inc 6 2054, .jump 2051, .dec 6 2061 2056]
def mid42 : List Instruction := [
  .inc 7 2057, .dec 6 2060 2058, .inc 1 2059, .jump 2057, .jump 2051, .dec 7 2064 2062,
  .inc 2 2063, .jump 2061, .dec 5 2068 2065, .inc 6 2066, .inc 1 2067, .jump 2064,
  .dec 6 2071 2069, .inc 5 2070, .jump 2068, .dec 2 2079 2072, .inc 7 2073, .dec 6 2075 2074,
  .jump 2078, .dec 7 2078 2076, .inc 6 2077, .jump 2075, .jump 2071, .dec 7 2082 2080,
  .inc 2 2081, .jump 2079, .dec 1 2086 2083, .inc 7 2084, .inc 6 2085, .jump 2082,
  .dec 6 2092 2087, .inc 7 2088, .dec 6 2091 2089, .inc 1 2090, .jump 2088, .jump 2082,
  .dec 7 2096 2093, .inc 1 2094, .inc 1 2095, .jump 2092, .inc 1 2097, .dec 1 2100 2098,
  .inc 6 2099, .jump 2097, .dec 2 2103 2101, .inc 1 2102, .jump 2100, .dec 1 2107 2104]
def mid43 : List Instruction := [
  .inc 7 2105, .inc 6 2106, .jump 2103, .dec 6 2113 2108, .inc 7 2109, .dec 6 2112 2110,
  .inc 1 2111, .jump 2109, .jump 2103, .dec 7 2116 2114, .inc 2 2115, .jump 2113,
  .dec 5 2120 2117, .inc 6 2118, .inc 1 2119, .jump 2116, .dec 6 2123 2121, .inc 5 2122,
  .jump 2120, .dec 2 2131 2124, .inc 7 2125, .dec 6 2127 2126, .jump 2130, .dec 7 2130 2128,
  .inc 6 2129, .jump 2127, .jump 2123, .dec 7 2134 2132, .inc 2 2133, .jump 2131,
  .dec 1 2138 2135, .inc 7 2136, .inc 6 2137, .jump 2134, .dec 6 2144 2139, .inc 7 2140,
  .dec 6 2143 2141, .inc 1 2142, .jump 2140, .jump 2134, .dec 7 2148 2145, .inc 1 2146,
  .inc 1 2147, .jump 2144, .inc 1 2149, .dec 1 2152 2150, .inc 6 2151, .jump 2149]
def mid44 : List Instruction := [
  .dec 2 2155 2153, .inc 1 2154, .jump 2152, .dec 1 2159 2156, .inc 7 2157, .inc 6 2158,
  .jump 2155, .dec 6 2165 2160, .inc 7 2161, .dec 6 2164 2162, .inc 1 2163, .jump 2161,
  .jump 2155, .dec 7 2168 2166, .inc 2 2167, .jump 2165, .inc 1 2169, .inc 1 2170,
  .inc 1 2171, .dec 2 2179 2172, .inc 7 2173, .dec 6 2175 2174, .jump 2178, .dec 7 2178 2176,
  .inc 6 2177, .jump 2175, .jump 2171, .dec 7 2182 2180, .inc 2 2181, .jump 2179,
  .dec 1 2186 2183, .inc 7 2184, .inc 6 2185, .jump 2182, .dec 6 2192 2187, .inc 7 2188,
  .dec 6 2191 2189, .inc 1 2190, .jump 2188, .jump 2182, .dec 7 2196 2193, .inc 1 2194,
  .inc 1 2195, .jump 2192, .dec 1 2199 2197, .inc 6 2198, .jump 2196, .dec 2 2202 2200]
def mid45 : List Instruction := [
  .inc 1 2201, .jump 2199, .dec 1 2206 2203, .inc 7 2204, .inc 6 2205, .jump 2202,
  .dec 6 2212 2207, .inc 7 2208, .dec 6 2211 2209, .inc 1 2210, .jump 2208, .jump 2202,
  .dec 7 2215 2213, .inc 2 2214, .jump 2212, .dec 1 2218 2216, .inc 6 2217, .jump 2215,
  .dec 2 2221 2219, .inc 1 2220, .jump 2218, .dec 1 2225 2222, .inc 7 2223, .inc 6 2224,
  .jump 2221, .dec 6 2231 2226, .inc 7 2227, .dec 6 2230 2228, .inc 1 2229, .jump 2227,
  .jump 2221, .dec 7 2234 2232, .inc 2 2233, .jump 2231, .inc 1 2235, .dec 1 2238 2236,
  .inc 6 2237, .jump 2235, .dec 2 2241 2239, .inc 1 2240, .jump 2238, .dec 1 2245 2242,
  .inc 7 2243, .inc 6 2244, .jump 2241, .dec 6 2251 2246, .inc 7 2247, .dec 6 2250 2248]
def mid46 : List Instruction := [
  .inc 1 2249, .jump 2247, .jump 2241, .dec 7 2254 2252, .inc 2 2253, .jump 2251,
  .dec 4 2258 2255, .inc 6 2256, .inc 1 2257, .jump 2254, .dec 6 2261 2259, .inc 4 2260,
  .jump 2258, .dec 2 2269 2262, .inc 7 2263, .dec 6 2265 2264, .jump 2268, .dec 7 2268 2266,
  .inc 6 2267, .jump 2265, .jump 2261, .dec 7 2272 2270, .inc 2 2271, .jump 2269,
  .dec 1 2276 2273, .inc 7 2274, .inc 6 2275, .jump 2272, .dec 6 2282 2277, .inc 7 2278,
  .dec 6 2281 2279, .inc 1 2280, .jump 2278, .jump 2272, .dec 7 2286 2283, .inc 1 2284,
  .inc 1 2285, .jump 2282, .inc 1 2287, .dec 1 2290 2288, .inc 6 2289, .jump 2287,
  .dec 2 2293 2291, .inc 1 2292, .jump 2290, .dec 1 2297 2294, .inc 7 2295, .inc 6 2296]
def mid47 : List Instruction := [
  .jump 2293, .dec 6 2303 2298, .inc 7 2299, .dec 6 2302 2300, .inc 1 2301, .jump 2299,
  .jump 2293, .dec 7 2306 2304, .inc 2 2305, .jump 2303, .dec 5 2310 2307, .inc 6 2308,
  .inc 1 2309, .jump 2306, .dec 6 2313 2311, .inc 5 2312, .jump 2310, .dec 2 2321 2314,
  .inc 7 2315, .dec 6 2317 2316, .jump 2320, .dec 7 2320 2318, .inc 6 2319, .jump 2317,
  .jump 2313, .dec 7 2324 2322, .inc 2 2323, .jump 2321, .dec 1 2328 2325, .inc 7 2326,
  .inc 6 2327, .jump 2324, .dec 6 2334 2329, .inc 7 2330, .dec 6 2333 2331, .inc 1 2332,
  .jump 2330, .jump 2324, .dec 7 2338 2335, .inc 1 2336, .inc 1 2337, .jump 2334,
  .inc 1 2339, .dec 2 2347 2340, .inc 7 2341, .dec 6 2343 2342, .jump 2346, .dec 7 2346 2344]
def mid48 : List Instruction := [
  .inc 6 2345, .jump 2343, .jump 2339, .dec 7 2350 2348, .inc 2 2349, .jump 2347,
  .dec 1 2354 2351, .inc 7 2352, .inc 6 2353, .jump 2350, .dec 6 2360 2355, .inc 7 2356,
  .dec 6 2359 2357, .inc 1 2358, .jump 2356, .jump 2350, .dec 7 2364 2361, .inc 1 2362,
  .inc 1 2363, .jump 2360, .inc 1 2365, .dec 2 2373 2366, .inc 7 2367, .dec 6 2369 2368,
  .jump 2372, .dec 7 2372 2370, .inc 6 2371, .jump 2369, .jump 2365, .dec 7 2376 2374,
  .inc 2 2375, .jump 2373, .dec 1 2380 2377, .inc 7 2378, .inc 6 2379, .jump 2376,
  .dec 6 2386 2381, .inc 7 2382, .dec 6 2385 2383, .inc 1 2384, .jump 2382, .jump 2376,
  .dec 7 2390 2387, .inc 1 2388, .inc 1 2389, .jump 2386, .dec 1 2393 2391, .inc 6 2392]
def mid49 : List Instruction := [
  .jump 2390, .dec 2 2396 2394, .inc 1 2395, .jump 2393, .dec 1 2400 2397, .inc 7 2398,
  .inc 6 2399, .jump 2396, .dec 6 2406 2401, .inc 7 2402, .dec 6 2405 2403, .inc 1 2404,
  .jump 2402, .jump 2396, .dec 7 2409 2407, .inc 2 2408, .jump 2406, .dec 5 2413 2410,
  .inc 6 2411, .inc 1 2412, .jump 2409, .dec 6 2416 2414, .inc 5 2415, .jump 2413,
  .dec 1 2419 2417, .inc 6 2418, .jump 2416, .dec 2 2422 2420, .inc 1 2421, .jump 2419,
  .dec 1 2426 2423, .inc 7 2424, .inc 6 2425, .jump 2422, .dec 6 2432 2427, .inc 7 2428,
  .dec 6 2431 2429, .inc 1 2430, .jump 2428, .jump 2422, .dec 7 2435 2433, .inc 2 2434,
  .jump 2432, .dec 5 2439 2436, .inc 6 2437, .inc 1 2438, .jump 2435, .dec 6 2442 2440]
def mid50 : List Instruction := [
  .inc 5 2441, .jump 2439, .dec 2 2450 2443, .inc 7 2444, .dec 6 2446 2445, .jump 2449,
  .dec 7 2449 2447, .inc 6 2448, .jump 2446, .jump 2442, .dec 7 2453 2451, .inc 2 2452,
  .jump 2450, .dec 1 2457 2454, .inc 7 2455, .inc 6 2456, .jump 2453, .dec 6 2463 2458,
  .inc 7 2459, .dec 6 2462 2460, .inc 1 2461, .jump 2459, .jump 2453, .dec 7 2467 2464,
  .inc 1 2465, .inc 1 2466, .jump 2463, .inc 1 2468, .inc 1 2469, .dec 1 2472 2470,
  .inc 6 2471, .jump 2469, .dec 2 2475 2473, .inc 1 2474, .jump 2472, .dec 1 2479 2476,
  .inc 7 2477, .inc 6 2478, .jump 2475, .dec 6 2485 2480, .inc 7 2481, .dec 6 2484 2482,
  .inc 1 2483, .jump 2481, .jump 2475, .dec 7 2488 2486, .inc 2 2487, .jump 2485]
def mid51 : List Instruction := [
  .dec 4 2492 2489, .inc 6 2490, .inc 1 2491, .jump 2488, .dec 6 2495 2493, .inc 4 2494,
  .jump 2492, .dec 2 2503 2496, .inc 7 2497, .dec 6 2499 2498, .jump 2502, .dec 7 2502 2500,
  .inc 6 2501, .jump 2499, .jump 2495, .dec 7 2506 2504, .inc 2 2505, .jump 2503,
  .dec 1 2510 2507, .inc 7 2508, .inc 6 2509, .jump 2506, .dec 6 2516 2511, .inc 7 2512,
  .dec 6 2515 2513, .inc 1 2514, .jump 2512, .jump 2506, .dec 7 2520 2517, .inc 1 2518,
  .inc 1 2519, .jump 2516, .inc 1 2521, .dec 1 2524 2522, .inc 6 2523, .jump 2521,
  .dec 2 2527 2525, .inc 1 2526, .jump 2524, .dec 1 2531 2528, .inc 7 2529, .inc 6 2530,
  .jump 2527, .dec 6 2537 2532, .inc 7 2533, .dec 6 2536 2534, .inc 1 2535, .jump 2533]
def mid52 : List Instruction := [
  .jump 2527, .dec 7 2540 2538, .inc 2 2539, .jump 2537, .dec 5 2544 2541, .inc 6 2542,
  .inc 1 2543, .jump 2540, .dec 6 2547 2545, .inc 5 2546, .jump 2544, .dec 2 2555 2548,
  .inc 7 2549, .dec 6 2551 2550, .jump 2554, .dec 7 2554 2552, .inc 6 2553, .jump 2551,
  .jump 2547, .dec 7 2558 2556, .inc 2 2557, .jump 2555, .dec 1 2562 2559, .inc 7 2560,
  .inc 6 2561, .jump 2558, .dec 6 2568 2563, .inc 7 2564, .dec 6 2567 2565, .inc 1 2566,
  .jump 2564, .jump 2558, .dec 7 2572 2569, .inc 1 2570, .inc 1 2571, .jump 2568,
  .inc 1 2573, .dec 1 2576 2574, .inc 6 2575, .jump 2573, .dec 2 2579 2577, .inc 1 2578,
  .jump 2576, .dec 1 2583 2580, .inc 7 2581, .inc 6 2582, .jump 2579, .dec 6 2589 2584]
def mid53 : List Instruction := [
  .inc 7 2585, .dec 6 2588 2586, .inc 1 2587, .jump 2585, .jump 2579, .dec 7 2592 2590,
  .inc 2 2591, .jump 2589, .dec 1 2595 2593, .inc 6 2594, .jump 2592, .dec 2 2598 2596,
  .inc 1 2597, .jump 2595, .dec 1 2602 2599, .inc 7 2600, .inc 6 2601, .jump 2598,
  .dec 6 2608 2603, .inc 7 2604, .dec 6 2607 2605, .inc 1 2606, .jump 2604, .jump 2598,
  .dec 7 2611 2609, .inc 2 2610, .jump 2608, .dec 1 2614 2612, .inc 6 2613, .jump 2611,
  .dec 2 2617 2615, .inc 1 2616, .jump 2614, .dec 1 2621 2618, .inc 7 2619, .inc 6 2620,
  .jump 2617, .dec 6 2627 2622, .inc 7 2623, .dec 6 2626 2624, .inc 1 2625, .jump 2623,
  .jump 2617, .dec 7 2630 2628, .inc 2 2629, .jump 2627, .dec 5 2634 2631, .inc 6 2632]
def mid54 : List Instruction := [
  .inc 1 2633, .jump 2630, .dec 6 2637 2635, .inc 5 2636, .jump 2634, .dec 2 2645 2638,
  .inc 7 2639, .dec 6 2641 2640, .jump 2644, .dec 7 2644 2642, .inc 6 2643, .jump 2641,
  .jump 2637, .dec 7 2648 2646, .inc 2 2647, .jump 2645, .dec 1 2652 2649, .inc 7 2650,
  .inc 6 2651, .jump 2648, .dec 6 2658 2653, .inc 7 2654, .dec 6 2657 2655, .inc 1 2656,
  .jump 2654, .jump 2648, .dec 7 2662 2659, .inc 1 2660, .inc 1 2661, .jump 2658,
  .inc 1 2663, .dec 2 2671 2664, .inc 7 2665, .dec 6 2667 2666, .jump 2670, .dec 7 2670 2668,
  .inc 6 2669, .jump 2667, .jump 2663, .dec 7 2674 2672, .inc 2 2673, .jump 2671,
  .dec 1 2678 2675, .inc 7 2676, .inc 6 2677, .jump 2674, .dec 6 2684 2679, .inc 7 2680]
def mid55 : List Instruction := [
  .dec 6 2683 2681, .inc 1 2682, .jump 2680, .jump 2674, .dec 7 2688 2685, .inc 1 2686,
  .inc 1 2687, .jump 2684, .inc 1 2689, .dec 1 2692 2690, .inc 6 2691, .jump 2689,
  .dec 2 2695 2693, .inc 1 2694, .jump 2692, .dec 1 2699 2696, .inc 7 2697, .inc 6 2698,
  .jump 2695, .dec 6 2705 2700, .inc 7 2701, .dec 6 2704 2702, .inc 1 2703, .jump 2701,
  .jump 2695, .dec 7 2708 2706, .inc 2 2707, .jump 2705, .dec 3 2712 2709, .inc 6 2710,
  .inc 1 2711, .jump 2708, .dec 6 2715 2713, .inc 3 2714, .jump 2712, .dec 2 2723 2716,
  .inc 7 2717, .dec 6 2719 2718, .jump 2722, .dec 7 2722 2720, .inc 6 2721, .jump 2719,
  .jump 2715, .dec 7 2726 2724, .inc 2 2725, .jump 2723, .dec 1 2730 2727, .inc 7 2728]
def mid56 : List Instruction := [
  .inc 6 2729, .jump 2726, .dec 6 2736 2731, .inc 7 2732, .dec 6 2735 2733, .inc 1 2734,
  .jump 2732, .jump 2726, .dec 7 2740 2737, .inc 1 2738, .inc 1 2739, .jump 2736,
  .inc 1 2741, .dec 1 2744 2742, .inc 6 2743, .jump 2741, .dec 2 2747 2745, .inc 1 2746,
  .jump 2744, .dec 1 2751 2748, .inc 7 2749, .inc 6 2750, .jump 2747, .dec 6 2757 2752,
  .inc 7 2753, .dec 6 2756 2754, .inc 1 2755, .jump 2753, .jump 2747, .dec 7 2760 2758,
  .inc 2 2759, .jump 2757, .dec 1 2763 2761, .inc 6 2762, .jump 2760, .dec 2 2766 2764,
  .inc 1 2765, .jump 2763, .dec 1 2770 2767, .inc 7 2768, .inc 6 2769, .jump 2766,
  .dec 6 2776 2771, .inc 7 2772, .dec 6 2775 2773, .inc 1 2774, .jump 2772, .jump 2766]
def mid57 : List Instruction := [
  .dec 7 2779 2777, .inc 2 2778, .jump 2776, .dec 5 2783 2780, .inc 6 2781, .inc 1 2782,
  .jump 2779, .dec 6 2786 2784, .inc 5 2785, .jump 2783, .dec 2 2794 2787, .inc 7 2788,
  .dec 6 2790 2789, .jump 2793, .dec 7 2793 2791, .inc 6 2792, .jump 2790, .jump 2786,
  .dec 7 2797 2795, .inc 2 2796, .jump 2794, .dec 1 2801 2798, .inc 7 2799, .inc 6 2800,
  .jump 2797, .dec 6 2807 2802, .inc 7 2803, .dec 6 2806 2804, .inc 1 2805, .jump 2803,
  .jump 2797, .dec 7 2811 2808, .inc 1 2809, .inc 1 2810, .jump 2807, .inc 1 2812,
  .dec 2 2820 2813, .inc 7 2814, .dec 6 2816 2815, .jump 2819, .dec 7 2819 2817, .inc 6 2818,
  .jump 2816, .jump 2812, .dec 7 2823 2821, .inc 2 2822, .jump 2820, .dec 1 2827 2824]
def mid58 : List Instruction := [
  .inc 7 2825, .inc 6 2826, .jump 2823, .dec 6 2833 2828, .inc 7 2829, .dec 6 2832 2830,
  .inc 1 2831, .jump 2829, .jump 2823, .dec 7 2837 2834, .inc 1 2835, .inc 1 2836,
  .jump 2833, .inc 1 2838, .dec 1 2841 2839, .inc 6 2840, .jump 2838, .dec 2 2844 2842,
  .inc 1 2843, .jump 2841, .dec 1 2848 2845, .inc 7 2846, .inc 6 2847, .jump 2844,
  .dec 6 2854 2849, .inc 7 2850, .dec 6 2853 2851, .inc 1 2852, .jump 2850, .jump 2844,
  .dec 7 2857 2855, .inc 2 2856, .jump 2854, .dec 5 2861 2858, .inc 6 2859, .inc 1 2860,
  .jump 2857, .dec 6 2864 2862, .inc 5 2863, .jump 2861, .dec 1 2867 2865, .inc 6 2866,
  .jump 2864, .dec 2 2870 2868, .inc 1 2869, .jump 2867, .dec 1 2874 2871, .inc 7 2872]
def mid59 : List Instruction := [
  .inc 6 2873, .jump 2870, .dec 6 2880 2875, .inc 7 2876, .dec 6 2879 2877, .inc 1 2878,
  .jump 2876, .jump 2870, .dec 7 2883 2881, .inc 2 2882, .jump 2880, .dec 4 2887 2884,
  .inc 6 2885, .inc 1 2886, .jump 2883, .dec 6 2890 2888, .inc 4 2889, .jump 2887,
  .dec 1 2893 2891, .inc 6 2892, .jump 2890, .dec 2 2896 2894, .inc 1 2895, .jump 2893,
  .dec 1 2900 2897, .inc 7 2898, .inc 6 2899, .jump 2896, .dec 6 2906 2901, .inc 7 2902,
  .dec 6 2905 2903, .inc 1 2904, .jump 2902, .jump 2896, .dec 7 2909 2907, .inc 2 2908,
  .jump 2906, .dec 5 2913 2910, .inc 6 2911, .inc 1 2912, .jump 2909, .dec 6 2916 2914,
  .inc 5 2915, .jump 2913, .dec 2 2924 2917, .inc 7 2918, .dec 6 2920 2919, .jump 2923]
def mid60 : List Instruction := [
  .dec 7 2923 2921, .inc 6 2922, .jump 2920, .jump 2916, .dec 7 2927 2925, .inc 2 2926,
  .jump 2924, .dec 1 2931 2928, .inc 7 2929, .inc 6 2930, .jump 2927, .dec 6 2937 2932,
  .inc 7 2933, .dec 6 2936 2934, .inc 1 2935, .jump 2933, .jump 2927, .dec 7 2941 2938,
  .inc 1 2939, .inc 1 2940, .jump 2937, .inc 1 2942, .inc 1 2943, .dec 2 2951 2944,
  .inc 7 2945, .dec 6 2947 2946, .jump 2950, .dec 7 2950 2948, .inc 6 2949, .jump 2947,
  .jump 2943, .dec 7 2954 2952, .inc 2 2953, .jump 2951, .dec 1 2958 2955, .inc 7 2956,
  .inc 6 2957, .jump 2954, .dec 6 2964 2959, .inc 7 2960, .dec 6 2963 2961, .inc 1 2962,
  .jump 2960, .jump 2954, .dec 7 2968 2965, .inc 1 2966, .inc 1 2967, .jump 2964]
def mid61 : List Instruction := [
  .inc 1 2969, .dec 1 2972 2970, .inc 6 2971, .jump 2969, .dec 2 2975 2973, .inc 1 2974,
  .jump 2972, .dec 1 2979 2976, .inc 7 2977, .inc 6 2978, .jump 2975, .dec 6 2985 2980,
  .inc 7 2981, .dec 6 2984 2982, .inc 1 2983, .jump 2981, .jump 2975, .dec 7 2988 2986,
  .inc 2 2987, .jump 2985, .dec 4 2992 2989, .inc 6 2990, .inc 1 2991, .jump 2988,
  .dec 6 2995 2993, .inc 4 2994, .jump 2992, .dec 1 2998 2996, .inc 6 2997, .jump 2995,
  .dec 2 3001 2999, .inc 1 3000, .jump 2998, .dec 1 3005 3002, .inc 7 3003, .inc 6 3004,
  .jump 3001, .dec 6 3011 3006, .inc 7 3007, .dec 6 3010 3008, .inc 1 3009, .jump 3007,
  .jump 3001, .dec 7 3014 3012, .inc 2 3013, .jump 3011, .dec 4 3018 3015, .inc 6 3016]
def mid62 : List Instruction := [
  .inc 1 3017, .jump 3014, .dec 6 3021 3019, .inc 4 3020, .jump 3018, .dec 1 3024 3022,
  .inc 6 3023, .jump 3021, .dec 2 3027 3025, .inc 1 3026, .jump 3024, .dec 1 3031 3028,
  .inc 7 3029, .inc 6 3030, .jump 3027, .dec 6 3037 3032, .inc 7 3033, .dec 6 3036 3034,
  .inc 1 3035, .jump 3033, .jump 3027, .dec 7 3040 3038, .inc 2 3039, .jump 3037,
  .dec 5 3044 3041, .inc 6 3042, .inc 1 3043, .jump 3040, .dec 6 3047 3045, .inc 5 3046,
  .jump 3044, .dec 2 3055 3048, .inc 7 3049, .dec 6 3051 3050, .jump 3054, .dec 7 3054 3052,
  .inc 6 3053, .jump 3051, .jump 3047, .dec 7 3058 3056, .inc 2 3057, .jump 3055,
  .dec 1 3062 3059, .inc 7 3060, .inc 6 3061, .jump 3058, .dec 6 3068 3063, .inc 7 3064]
def mid63 : List Instruction := [
  .dec 6 3067 3065, .inc 1 3066, .jump 3064, .jump 3058, .dec 7 3072 3069, .inc 1 3070,
  .inc 1 3071, .jump 3068, .inc 1 3073, .inc 1 3074, .dec 2 3082 3075, .inc 7 3076,
  .dec 6 3078 3077, .jump 3081, .dec 7 3081 3079, .inc 6 3080, .jump 3078, .jump 3074,
  .dec 7 3085 3083, .inc 2 3084, .jump 3082, .dec 1 3089 3086, .inc 7 3087, .inc 6 3088,
  .jump 3085, .dec 6 3095 3090, .inc 7 3091, .dec 6 3094 3092, .inc 1 3093, .jump 3091,
  .jump 3085, .dec 7 3099 3096, .inc 1 3097, .inc 1 3098, .jump 3095, .inc 1 3100,
  .dec 2 3108 3101, .inc 7 3102, .dec 6 3104 3103, .jump 3107, .dec 7 3107 3105, .inc 6 3106,
  .jump 3104, .jump 3100, .dec 7 3111 3109, .inc 2 3110, .jump 3108, .dec 1 3115 3112]
def mid64 : List Instruction := [
  .inc 7 3113, .inc 6 3114, .jump 3111, .dec 6 3121 3116, .inc 7 3117, .dec 6 3120 3118,
  .inc 1 3119, .jump 3117, .jump 3111, .dec 7 3125 3122, .inc 1 3123, .inc 1 3124,
  .jump 3121, .inc 1 3126, .dec 1 3129 3127, .inc 6 3128, .jump 3126, .dec 2 3132 3130,
  .inc 1 3131, .jump 3129, .dec 1 3136 3133, .inc 7 3134, .inc 6 3135, .jump 3132,
  .dec 6 3142 3137, .inc 7 3138, .dec 6 3141 3139, .inc 1 3140, .jump 3138, .jump 3132,
  .dec 7 3145 3143, .inc 2 3144, .jump 3142, .dec 4 3149 3146, .inc 6 3147, .inc 1 3148,
  .jump 3145, .dec 6 3152 3150, .inc 4 3151, .jump 3149, .dec 1 3155 3153, .inc 6 3154,
  .jump 3152, .dec 2 3158 3156, .inc 1 3157, .jump 3155, .dec 1 3162 3159, .inc 7 3160]
def mid65 : List Instruction := [
  .inc 6 3161, .jump 3158, .dec 6 3168 3163, .inc 7 3164, .dec 6 3167 3165, .inc 1 3166,
  .jump 3164, .jump 3158, .dec 7 3171 3169, .inc 2 3170, .jump 3168, .dec 5 3175 3172,
  .inc 6 3173, .inc 1 3174, .jump 3171, .dec 6 3178 3176, .inc 5 3177, .jump 3175,
  .dec 2 3186 3179, .inc 7 3180, .dec 6 3182 3181, .jump 3185, .dec 7 3185 3183, .inc 6 3184,
  .jump 3182, .jump 3178, .dec 7 3189 3187, .inc 2 3188, .jump 3186, .dec 1 3193 3190,
  .inc 7 3191, .inc 6 3192, .jump 3189, .dec 6 3199 3194, .inc 7 3195, .dec 6 3198 3196,
  .inc 1 3197, .jump 3195, .jump 3189, .dec 7 3203 3200, .inc 1 3201, .inc 1 3202,
  .jump 3199, .inc 1 3204, .dec 2 3212 3205, .inc 7 3206, .dec 6 3208 3207, .jump 3211]
def mid66 : List Instruction := [
  .dec 7 3211 3209, .inc 6 3210, .jump 3208, .jump 3204, .dec 7 3215 3213, .inc 2 3214,
  .jump 3212, .dec 1 3219 3216, .inc 7 3217, .inc 6 3218, .jump 3215, .dec 6 3225 3220,
  .inc 7 3221, .dec 6 3224 3222, .inc 1 3223, .jump 3221, .jump 3215, .dec 7 3229 3226,
  .inc 1 3227, .inc 1 3228, .jump 3225]
def mid : List Instruction := [mid0, mid1, mid2, mid3, mid4, mid5, mid6, mid7, mid8, mid9, mid10, mid11, mid12, mid13, mid14, mid15, mid16, mid17, mid18, mid19, mid20, mid21, mid22, mid23, mid24, mid25, mid26, mid27, mid28, mid29, mid30, mid31, mid32, mid33, mid34, mid35, mid36, mid37, mid38, mid39, mid40, mid41, mid42, mid43, mid44, mid45, mid46, mid47, mid48, mid49, mid50, mid51, mid52, mid53, mid54, mid55, mid56, mid57, mid58, mid59, mid60, mid61, mid62, mid63, mid64, mid65, mid66].flatten
def post0 : List Instruction := [
  .jump 39, .dec 1 3233 3231, .inc 6 3232, .jump 3230, .dec 2 3236 3234, .inc 1 3235,
  .jump 3233, .dec 1 3240 3237, .inc 7 3238, .inc 6 3239, .jump 3236, .dec 6 3246 3241,
  .inc 7 3242, .dec 6 3245 3243, .inc 1 3244, .jump 3242, .jump 3236, .dec 7 3249 3247,
  .inc 2 3248, .jump 3246, .dec 4 3253 3250, .inc 6 3251, .inc 1 3252, .jump 3249,
  .dec 6 3256 3254, .inc 4 3255, .jump 3253, .dec 2 3264 3257, .inc 7 3258, .dec 6 3260 3259,
  .jump 3263, .dec 7 3263 3261, .inc 6 3262, .jump 3260, .jump 3256, .dec 7 3267 3265,
  .inc 2 3266, .jump 3264, .dec 1 3271 3268, .inc 7 3269, .inc 6 3270, .jump 3267,
  .dec 6 3277 3272, .inc 7 3273, .dec 6 3276 3274, .inc 1 3275, .jump 3273, .jump 3267]
def post1 : List Instruction := [
  .dec 7 3281 3278, .inc 1 3279, .inc 1 3280, .jump 3277, .dec 1 3284 3282, .inc 6 3283,
  .jump 3281, .dec 6 3291 3285, .dec 5 3287 3286, .jump 3284, .inc 5 3288, .dec 6 3291 3289,
  .inc 5 3290, .jump 3288, .dec 5 3293 3292, .jump 3300, .dec 4 3297 3294, .inc 6 3295,
  .inc 1 3296, .jump 3293, .dec 6 3300 3298, .inc 4 3299, .jump 3297, .dec 4 3302 3301,
  .jump 3300, .dec 5 3304 3303, .jump 3302, .dec 4 3331 3305, .dec 1 3308 3306, .inc 6 3307,
  .jump 3305, .dec 2 3311 3309, .inc 1 3310, .jump 3308, .dec 1 3315 3312, .inc 7 3313,
  .inc 6 3314, .jump 3311, .dec 6 3321 3316, .inc 7 3317, .dec 6 3320 3318, .inc 1 3319,
  .jump 3317, .jump 3311, .dec 7 3324 3322, .inc 2 3323, .jump 3321, .dec 5 3328 3325]
def post2 : List Instruction := [
  .inc 6 3326, .inc 1 3327, .jump 3324, .dec 6 3331 3329, .inc 5 3330, .jump 3328,
  .dec 5 3335 3332, .dec 5 3335 3333, .dec 5 3335 3334, .decHalt 5 3335, .dec 5 3337 3336, .jump 3335,
  .dec 2 3345 3338, .inc 7 3339, .dec 6 3341 3340, .jump 3344, .dec 7 3344 3342, .inc 6 3343,
  .jump 3341, .jump 3337, .dec 7 3348 3346, .inc 2 3347, .jump 3345, .dec 6 0 3349,
  .inc 5 3350, .jump 3348]
def post : List Instruction := [post0, post1, post2].flatten
def program (pc : Nat) : Instruction :=
  if pc < 40 then pre.getD pc .halt else if pc < 3229 then mid.getD (pc-40) .halt else post.getD (pc-3229) (.jump pc)

theorem mid_eq_compile : mid = compile C193.batchCode 40 3229 [] [] := by rfl

theorem mid_length : mid.length = 3189 := by decide

theorem batch_embedded : Embedded program C193.batchCode 40 3229 [] [] := by
  intro i hi
  have eqsize : C193.batchCode.size = 3189 := by rw [← compile_length C193.batchCode 40 3229 [] [], ← mid_eq_compile, mid_length]
  have ha : ¬ 40+i < 40 := by omega
  have hb : 40+i < 3229 := by omega
  simp only [program,if_neg ha,if_pos hb,Nat.add_sub_cancel_left]
  rw [mid_eq_compile, List.getD_eq_getElem?_getD, List.getElem?_eq_getElem (by simpa only [compile_length] using hi)]
  rfl

theorem selected_batch (n t stack c u v y delta tail : Nat) :
    Reaches program ⟨40,Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩⟩
      (some ⟨3229,(save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (C193.rowList (u+delta) (v+y) c u)).regs⟩) :=
  (C193.batch_eval n t stack c u v y delta tail).compiled program 40 3229 [] [] batch_embedded

end C193.Literal
#print axioms C193.Literal.selected_batch
