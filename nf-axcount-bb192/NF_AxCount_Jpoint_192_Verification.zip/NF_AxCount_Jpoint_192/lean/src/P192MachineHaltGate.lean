module
public import P192MachineControlKernelExecute
public import P192MachineSourceBounds
@[expose] public section

/-! The offset-one zero decrement with the selected table's conditional
halt. The entire variable-length register/file shift and undo are included. -/
namespace P192.HaltGate
open NF210 NF210.TM CS192.Table
open P192.KernelRightShift P192.KernelFiles P192.KernelExecute

def zeroInput (gap : Nat) (earlier : List Nat) (tail : List Bool) :=
  [false, false] ++ shiftInput (gap+1) earlier ++ [true, false] ++ tail
def zeroOutput (gap : Nat) (earlier : List Nat) (tail : List Bool) :=
  ([false] ++ P192.KernelFiles.terminatedRuns ((gap+1)::earlier) ++ [true]) ++ [true, false] ++ tail
def zeroTime (gap : Nat) (earlier : List Nat) :=
  (shiftInput (gap+1) earlier).length + 3 + ([false,false] ++ shiftOutput (gap+1) earlier).length
def gateState (bit : Bool) : Option State :=
  if bit then none else some P192.KernelReverse.searchEndState

theorem row (bit : Bool) :
    machine P192.KernelReverse.undoEndState bit = ⟨false,.left,gateState bit⟩ := by
  cases bit <;> decide

/-- The gate inspects the source bit immediately to the left of the two
phase bits. It halts exactly when that bit is one. The equality specifies
the head and all tape cells in either branch, at every file size. -/
theorem zero_decrement_gate (gap : Nat) (earlier : List Nat) (tail : List Bool)
    (anchor : Int) (outside : Tape) :
    run machine (zeroTime gap earlier + 1)
      (configuration shiftState (anchor+2) (wordTape anchor (zeroInput gap earlier tail) outside)) =
    ⟨gateState (outside (anchor-1)), anchor-2,
      writeTape (wordTape anchor (zeroOutput gap earlier tail) outside) (anchor-1) false⟩ := by
  have core := (zero_decrement_execute gap earlier tail).exact_run anchor outside
  change run machine (zeroTime gap earlier)
    (configuration shiftState (anchor+2) (wordTape anchor (zeroInput gap earlier tail) outside)) =
    configuration P192.KernelReverse.undoEndState (anchor+(-1))
      (wordTape anchor (zeroOutput gap earlier tail) outside) at core
  have pos : anchor+(-1) = anchor-1 := by omega
  rw [pos] at core
  have bit := wordTape_outside anchor (anchor-1) (zeroOutput gap earlier tail) outside (Or.inl (by omega))
  rw [run_succ, core]
  simp only [step,configuration,bit,row,moveHead]
  congr 1 <;> omega

theorem zero_decrement_halts_iff (gap : Nat) (earlier : List Nat) (tail : List Bool)
    (anchor : Int) (outside : Tape) :
    (run machine (zeroTime gap earlier + 1)
      (configuration shiftState (anchor+2) (wordTape anchor (zeroInput gap earlier tail) outside))).state
        = none ↔ outside (anchor-1) = true := by
  rw [zero_decrement_gate]
  cases h : outside (anchor-1) <;> simp [gateState]

theorem address_bit_iff (pc : Nat) (valid : pc < Source.siteCount)
    (decrement : (Source.siteAt pc).op = Source.Primitive.dec) :
    ((Source.siteAt pc).address % 2 == 1) = true ↔ pc = 3334 := by
  have observed := congrArg (fun xs : List Nat => pc ∈ xs) Source.unique_conditional_halt
  simpa [List.mem_filter,valid,decrement] using Iff.of_eq observed

/-- The machine halts on the execute/return phase of a logical-zero
decrement exactly at address 3334, for arbitrary gap and register magnitudes. -/
theorem zero_decrement_halts_at_3334 (pc : Nat) (valid : pc < Source.siteCount)
    (decrement : (Source.siteAt pc).op = Source.Primitive.dec)
    (gap : Nat) (earlier : List Nat) (tail : List Bool) (anchor : Int) (outside : Tape)
    (address : outside (anchor-1) = ((Source.siteAt pc).address % 2 == 1)) :
    (run machine (zeroTime gap earlier + 1)
      (configuration shiftState (anchor+2) (wordTape anchor (zeroInput gap earlier tail) outside))).state
        = none ↔ pc = 3334 := by
  rw [zero_decrement_halts_iff, address]
  exact address_bit_iff pc valid decrement

#print axioms zero_decrement_gate
#print axioms zero_decrement_halts_at_3334
end P192.HaltGate
