module
public import P192MachineSource
public meta import P192MachineSource

@[expose] public section

/-! Bounds for the register and every outgoing edge of the literal source program. -/
namespace P192.Frame
open Source
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def validTargets : Source.Command → Prop
  | .inl (r, d) => r < 9 ∧ d < siteCount
  | .inr (.inl (r, z, p, _)) => r < 9 ∧ z < siteCount ∧ p < siteCount
  | .inr (.inr d) => d < siteCount

instance (c : Source.Command) : Decidable (validTargets c) := by
  rcases c with ⟨r,d⟩ | ⟨r,z,p,b⟩ | d <;> unfold validTargets <;> infer_instance

private theorem all_targets : (List.range siteCount).all (fun i => decide (validTargets (Source.program i))) = true := by native_decide
theorem targets_valid (pc : Nat) (h : pc < siteCount) : validTargets (Source.program pc) :=
  of_decide_eq_true ((List.all_eq_true.mp all_targets) pc (List.mem_range.mpr h))
theorem inc_target_valid {pc r d : Nat} (h : pc < siteCount)
    (step : program pc = Command.inc r d) : r < 9 ∧ d < siteCount := by
  have bound := targets_valid pc h
  rw [step] at bound
  exact bound

theorem dec_targets_valid {pc r z p : Nat} {b : Bool} (h : pc < siteCount)
    (step : program pc = Command.dec r z p b) : r < 9 ∧ z < siteCount ∧ p < siteCount := by
  have bound := targets_valid pc h
  rw [step] at bound
  exact bound

theorem jump_target_valid {pc d : Nat} (h : pc < siteCount)
    (step : program pc = Command.jump d) : d < siteCount := by
  have bound := targets_valid pc h
  rw [step] at bound
  exact bound

#print axioms targets_valid
end P192.Frame
