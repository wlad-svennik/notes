module
public import P192MachineControlKernelContracts
public import P192MachineControlKernelSelectors

@[expose] public section

namespace P192.SelectorRoundtrip

open NF210 NF210.TM
open CS192.Table (State machine)
open P192.KernelRightShift P192.KernelSelectors

private def oneZeroState : State := ⟨160, by decide⟩

private theorem back_ones (n : Nat) : LeftRun returnState returnState
    (List.replicate n true) (List.replicate n true) :=
  (LeftRun.one (by decide)).repeat n

private theorem back_one_zero : LeftRun returnState returnState [true,false] [true,false] := by
  have z : LeftRun returnState oneZeroState [false] [false] := LeftRun.one (by decide)
  have o : LeftRun oneZeroState returnState [true] [true] := LeftRun.one (by decide)
  exact z.trans o

private theorem back_separator (extra : Nat) : LeftRun returnState returnState
    (List.replicate (extra+1) true ++ [false]) (List.replicate (extra+1) true ++ [false]) := by
  simpa only [List.replicate_succ' (n := extra), List.append_assoc, List.cons_append,
    List.nil_append] using back_one_zero.trans (back_ones extra)

/-- On the return sweep an isolated register delimiter advances the zero detector once.
The next unary one resets it. Every stored value, including zero, supplies that one. -/
theorem rewind_selection (extra : Nat) (earlier : List Nat) :
    LeftRun returnState returnState (selectionInput (extra+1) earlier)
      (selectionInput (extra+1) earlier) := by
  induction earlier generalizing extra with
  | nil => simpa [selectionInput, blocks] using back_separator extra
  | cons v vs ih =>
    simpa only [selectionInput, blocks, List.append_assoc, List.cons_append, List.nil_append]
      using (ih v).trans (back_separator extra)

/-- Starting at the terminal phase one-bit, select and mark a register and return to the
first phase bit. The trailing list and exterior tape are arbitrary, as are all field lengths. -/
theorem select_mark_and_rewind (extra : Nat) (earlier : List Nat) (inside : earlier.length < 9)
    (tail : List Bool) :
    let walked := selectionInput (extra+1) earlier
    WordRun (selectorState earlier.length) returnState (walked ++ true :: tail)
      (walked ++ false :: tail) 0 (-1) (walked.length + 1 + walked.length) := by
  dsimp only
  constructor
  · simp
  · intro anchor outside
    rw [TM.run_add, Int.add_zero, select_and_mark_exact _ _ inside]
    exact (rewind_selection extra earlier).with_suffix anchor (false :: tail) outside

#print axioms select_mark_and_rewind

end P192.SelectorRoundtrip
