module
public import C193Control
public import C193SearchCore
public import NumericalAXBatches
public import SourceRoundtrip
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace C193.Register
open C193
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers NF192.SourceFields
open NF192.ProofSearch (Command pack pop_pack)
def lastParams (a b : Nat) : List (Nat × Nat) → Nat × Nat
  | [] => (a,b)
  | (y,d)::rest => lastParams (a+d) (b+y) rest

private theorem contains_last (r : List (Nat × Nat)) (a b u : Nat) :
    ∃ pre, C193.rowList a b r.length u ++ C193.tailRows a b r =
      pre ++ [C193.lastRow (lastParams a b r).1 (lastParams a b r).2] := by
  induction r generalizing a b u with
  | nil =>
    exact ⟨(C193.rowList a b 0 u).take 9, rfl⟩
  | cons w r ih =>
    obtain ⟨y,d⟩ := w
    obtain ⟨pre,h⟩ := ih (a+d) (b+y) a
    refine ⟨C193.rowList a b (r.length+1) u ++ pre, ?_⟩
    simp only [C193.tailRows,lastParams,List.length_cons,List.append_assoc]
    rw [h]

theorem payload_afterAX (s : C193.State) (xs : List Nat) (x : Nat)
    (hx : ∃ pre, xs = pre ++ [x]) :
    pushRows (s.top,pack s.stack) xs = (x,pack (xs.reverse.tail ++ s.top :: s.stack)) := by
  obtain ⟨pre,rfl⟩ := hx
  rw [pushRows_lists]
  simp [C193.afterAX, List.reverse_append, asPayload]

variable (embedded : Embedded actual C193.batchCode 40 3229 [] [])
include embedded

theorem one_ax_then_guard (n c u v y d tail : Nat) (ts : Nat × Nat) :
    Moves (atFrame 40 (frameWith n ts c u v (encodeBatch (y,d) tail)))
      (atFrame 39 (frameWith n (pushRows ts (C193.rowList (u+d) (v+y) c u)) c (u+d) (v+y) tail)) := by
  have first := ax_program_of_embedding embedded n ts.1 ts.2 c u v y d tail
  change Moves (atFrame 40 (frameWith n ts c u v (encodeBatch (y,d) tail)))
    (atFrame 3229 (save (frameWith n ts c (u+d) (v+y) tail) (C193.rowList (u+d) (v+y) c u))) at first
  rw [save_frameWith] at first
  exact first.trans (jump_at _ _ _ row3229_cmd)

theorem remaining_ax_batches (rest : List (Nat×Nat)) (n tail a b : Nat) (ts : Nat×Nat) :
    Moves (atFrame 39 (frameWith n ts rest.length a b (encodeBatches rest tail)))
      (atFrame 3230 (frameWith n (pushRows ts (C193.tailRows a b rest)) 0
         (lastParams a b rest).1 (lastParams a b rest).2 tail)) := by
  induction rest generalizing a b ts with
  | nil => exact mode_entry n ts.1 ts.2 a b tail
  | cons w rest ih =>
      obtain ⟨y,d⟩ := w
      have h₁ := ax_entry n ts.1 ts.2 rest.length a b (encodeBatches ((y,d)::rest) tail)
      have h₂ := one_ax_then_guard embedded n rest.length a b y d (encodeBatches rest tail) ts
      have h₃ := ih (a+d) (b+y) (pushRows ts (C193.rowList (a+d) (b+y) rest.length a))
      simpa only [C193.tailRows, lastParams, pushRows_append, frameWith, List.length_cons] using (h₁.trans (h₂.trans h₃))

theorem ax_command (n u y d : Nat) (rest : List (Nat×Nat)) (tail : Nat) (s : C193.State) :
    Moves (atFrame 40 ⟨n,s.top,pack s.stack,rest.length,s.param+u,s.cache,
      encodeBatch (y,d) (encodeBatches rest tail)⟩)
      (atFrame 0 ⟨n,0,pack (C193.afterAX s (C193.rows u y d rest s)).stack,0,0,(C193.afterAX s (C193.rows u y d rest s)).cache,tail⟩) := by
  let ts := (s.top, pack s.stack)
  let a := s.param+u+d
  let b := s.cache+y
  let out := lastParams a b rest
  let xs := C193.rows u y d rest s
  have first := one_ax_then_guard embedded n rest.length (s.param+u) s.cache y d (encodeBatches rest tail) ts
  have other := remaining_ax_batches embedded rest n tail a b (pushRows ts (C193.rowList a b rest.length (s.param+u)))
  have use := first.trans other
  rw [← pushRows_append] at use
  change Moves _ (atFrame 3230 (frameWith n (pushRows ts xs) 0 out.1 out.2 tail)) at use
  have hp := payload_afterAX s xs (C193.lastRow out.1 out.2) (contains_last rest a b (s.param+u))
  rw [show ts = (s.top,pack s.stack) from rfl, hp] at use
  have mp := mp_correct n (C193.lastRow out.1 out.2) (pack (xs.reverse.tail ++ s.top :: s.stack)) 0 out.1 out.2 tail
  rw [if_neg (C193.imp_last_ne_cache out.1 out.2)] at mp
  rw [pop_pack] at mp
  exact use.trans mp
end C193.Register
