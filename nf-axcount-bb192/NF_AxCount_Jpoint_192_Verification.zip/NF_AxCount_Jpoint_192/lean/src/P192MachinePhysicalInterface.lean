module
public import P192MachineFrameWords
public import P192MachineSource

@[expose] public section

namespace P192.Physical

open NF210 NF210.TM P192.Frame

/-- Bounds established once on the blank tape and preserved at every source
instruction boundary. A cold register can have raw value zero. -/
structure Good (f : Layout) : Prop where
  inRange : f.pc < 3351
  margin : 55 ≤ f.gap
  nine : f.stored.size = 9

/-- A complete nonhalting instruction gives a new valid frame and the exact
physical value of every register, including those it did not address. -/
structure Effect (g : Layout) (pc : Nat) (raw : Nat → Nat) : Prop where
  good : Good g
  target : g.pc = pc
  values : ∀ j : Fin 9, g.storedAt j.val = raw j.val

def Returns (f : Layout) (pc : Nat) (raw : Nat → Nat) : Prop :=
  ∃ g ticks, 0 < ticks ∧ run CS192.Table.machine ticks f.config = g.config ∧ Effect g pc raw

/-- Literal binary behavior of each arithmetic opcode on an arbitrary
valid canonical frame. Stored value one represents logical zero. -/
structure Arithmetic : Prop where
  inc : ∀ f (r : Fin 9) n, Good f → Source.program f.pc = Source.Command.inc r.val n →
    Returns f n (Source.setReg f.storedAt r.val (f.storedAt r.val + 1))
  positive : ∀ f (r : Fin 9) z n halt, Good f →
    Source.program f.pc = Source.Command.dec r.val z n halt → 2 ≤ f.storedAt r.val →
    Returns f n (Source.setReg f.storedAt r.val (f.storedAt r.val - 1))
  zero : ∀ f (r : Fin 9) z n, Good f →
    Source.program f.pc = Source.Command.dec r.val z n false → f.storedAt r.val = 1 →
    Returns f z f.storedAt
  halt : ∀ f (r : Fin 9) z n, Good f →
    Source.program f.pc = Source.Command.dec r.val z n true → f.storedAt r.val = 1 →
    ∃ ticks, 0 < ticks ∧ (run CS192.Table.machine ticks f.config).state = none

end P192.Physical
