module
public import P192MachineControlKernelLeft

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-! Finite execution composition for assembling complete runtime contracts. -/

namespace P192.KernelExecution

open NF210 NF210.TM
open CS192.Table (machine)

def Reaches (before after : Configuration 192) : Prop :=
  ∃ steps, TM.run machine steps before = after

def Progress (before after : Configuration 192) : Prop :=
  ∃ steps, 0 < steps ∧ TM.run machine steps before = after

theorem Reaches.refl (configuration : Configuration 192) : Reaches configuration configuration :=
  ⟨0, rfl⟩

theorem Reaches.of_run {before after : Configuration 192} {steps : Nat}
    (execution : TM.run machine steps before = after) : Reaches before after :=
  ⟨steps, execution⟩

theorem Reaches.step (configuration : Configuration 192) :
    Reaches configuration (TM.step machine configuration) := ⟨1, rfl⟩

theorem Reaches.of_step {before after : Configuration 192}
    (execution : TM.step machine before = after) : Reaches before after :=
  ⟨1, execution⟩

theorem Reaches.trans {before middle after : Configuration 192}
    (first : Reaches before middle) (second : Reaches middle after) : Reaches before after := by
  rcases first with ⟨firstTime, firstRun⟩
  rcases second with ⟨secondTime, secondRun⟩
  refine ⟨firstTime + secondTime, ?_⟩
  rw [TM.run_add, firstRun, secondRun]

theorem Progress.of_run {before after : Configuration 192} {steps : Nat}
    (positive : 0 < steps) (execution : TM.run machine steps before = after) : Progress before after :=
  ⟨steps, positive, execution⟩

theorem Progress.of_step {before after : Configuration 192}
    (execution : TM.step machine before = after) : Progress before after :=
  ⟨1, by decide, execution⟩

theorem Progress.reaches {before after : Configuration 192}
    (execution : Progress before after) : Reaches before after := by
  rcases execution with ⟨steps, _, exactRun⟩
  exact ⟨steps, exactRun⟩

theorem Progress.trans {before middle after : Configuration 192}
    (first : Progress before middle) (second : Reaches middle after) : Progress before after := by
  rcases first with ⟨firstTime, positive, firstRun⟩
  rcases second with ⟨secondTime, secondRun⟩
  refine ⟨firstTime + secondTime, by omega, ?_⟩
  rw [TM.run_add, firstRun, secondRun]

theorem Reaches.trans_progress {before middle after : Configuration 192}
    (first : Reaches before middle) (second : Progress middle after) : Progress before after := by
  rcases first with ⟨firstTime, firstRun⟩
  rcases second with ⟨secondTime, positive, secondRun⟩
  refine ⟨firstTime + secondTime, by omega, ?_⟩
  rw [TM.run_add, firstRun, secondRun]

end P192.KernelExecution
