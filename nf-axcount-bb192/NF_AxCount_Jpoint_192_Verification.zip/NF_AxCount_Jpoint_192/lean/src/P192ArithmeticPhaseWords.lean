module
public import P192ArithmeticPhaseComplete
public import P192MachinePaddedWord

@[expose] public section

namespace P192.Phase

open NF210 NF210.TM P192.KernelRightShift

@[simp] theorem path_length (s : Source.Site) : (path s).length = s.depth := by simp [path]

@[simp] theorem input_length (s : Source.Site) (ph : Nat) :
    (inputWord s ph).length = s.depth + 3 := by
  cases ph with
  | zero => simp [inputWord]
  | succ ph => cases ph <;> simp [inputWord] <;> omega

@[simp] theorem output_length (s : Source.Site) (ph : Nat) :
    (outputWord s ph).length = s.depth + 3 := by simp [outputWord]

/-- Every source arithmetic instruction has its concrete decoder contract, at
an arbitrary physical location and with an unrestricted exterior tape. -/
theorem word_dispatch (i ph : Nat) (hi : i < 3351) (hp : ph < 4)
    (active : enabled (Source.siteAt i) ph = true) :
    let s := Source.siteAt i
    WordRun CS192.Table.decoderRoot (target s ph) (inputWord s ph) (outputWord s ph)
      (initialHead s ph : Int) (finalHead s ph : Int) (elapsed i ph) := by
  dsimp only
  have both : Obligation i ph false ∧ Obligation i ph true := of_decide_eq_true
    (by simpa only [checkOne,active,ite_true] using all_checked i ph hi hp)
  have cond (b : Bool) : Obligation i ph b := by cases b <;> first | exact both.1 | exact both.2
  have hw : (inputWord (Source.siteAt i) ph).length + 1 = width (Source.siteAt i) := by
    simp [width]
  apply BitsWord.padded_word_run
  · simp
  · rw [hw]; exact both.1.2.1
  · intro b
    rw [hw]
    exact (cond b).2.2

theorem duration_positive (i ph : Nat) (hi : i < 3351) (hp : ph < 4)
    (active : enabled (Source.siteAt i) ph = true) : 0 < elapsed i ph := by
  have both : Obligation i ph false ∧ Obligation i ph true := of_decide_eq_true
    (by simpa only [checkOne,active,ite_true] using all_checked i ph hi hp)
  exact both.1.1

end P192.Phase

#print axioms P192.Phase.word_dispatch
