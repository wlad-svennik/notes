module
public import P192MachineControlCarryCase
public import P192MachineFrameWords

@[expose] public section
namespace P192.Carry

open NF210 NF210.TM Frame KernelRightShift

/-- The first physical field delimiter is already included in `ready` and
`restored`. This is the untouched register tape immediately following it. -/
def payloadTail (f : Frame.Layout) := (blocks f.values).drop 1

theorem blocks_payloadTail (f : Frame.Layout) :
    blocks f.values = false :: payloadTail f := by
  cases hv : f.values with
  | nil =>
    have h : f.values.length ≥ 9 := by simp [Frame.Layout.values,registerOrder]
    simp [hv] at h
  | cons n ns => simp [payloadTail,hv,blocks]

theorem prefixAt_length (pc : Nat) (moved : Bool) :
    (prefixAt pc moved).length = before moved + 1 + (addressBits pc).length := by
  simp [prefixAt, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm]

theorem initialWord_length (pc : Nat) (zero : Bool) :
    (initialWord pc zero).length = 9 + (addressBits pc).length + (if zero then 1 else 2) := by
  simp only [initialWord,List.length_append,prefixAt_length,List.length_replicate]
  rfl

/-- Place the canonical successor after an increment, positive decrement, or
zero decrement. The register contents, including any appended spares, are
arbitrary. A one-cell change of root only changes the leading guard count. -/
theorem restored_payload (pc : Nat) (zero : Bool) (extra : Nat) (f : Layout)
    (hpc : f.pc = nextPc pc zero)
    (header : (initialWord pc zero).length+extra = before (shifted pc zero)+1+f.gap) :
    restored pc zero extra ++ payloadTail f =
      List.replicate (before (shifted pc zero)) false ++ f.word := by
  rw [Layout.word_kernel]
  simp only [restored]
  rw [prefixAt_length, ←hpc,header]
  have gap : before (shifted pc zero)+1+f.gap-
      (before (shifted pc zero)+1+(addressBits f.pc).length) = f.gapWidth := by
    unfold Frame.Layout.gapWidth
    omega
  rw [gap,blocks_payloadTail]
  simp only [prefixAt,Frame.Layout.prefix,List.append_assoc,List.cons_append,List.nil_append]

/-- Configurations on the restored word, including any trailing zero
guards used by a shift routine, are exactly canonical source configurations. -/
theorem restored_config (a : Int) (pc : Nat) (zero : Bool) (extra : Nat) (f : Layout)
    (trailing : Nat) (hpc : f.pc = nextPc pc zero)
    (head : a + ((before (shifted pc zero)+1:Nat):Int) = f.head)
    (header : (initialWord pc zero).length+extra = before (shifted pc zero)+1+f.gap) :
    configuration 13 (a + ((before (shifted pc zero)+1:Nat):Int))
      (wordTape a ((restored pc zero extra ++ payloadTail f) ++ List.replicate trailing false)
        blankOutside) = f.config := by
  rw [restored_payload pc zero extra f hpc header, head]
  have pos : a = f.head-1-(before (shifted pc zero):Int) := by omega
  rw [pos, ←Layout.tape_padded]
  rfl

end P192.Carry
