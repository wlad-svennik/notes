module
public import P192MachineControlKernelRightShift

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-!
# Reusable exact finite-word reasoning for the literal runtime

All surrounding tape remains arbitrary. These lemmas extend the word and
execution framework without adding any machine-correctness hypothesis.
-/

namespace P192.KernelRightShift

open NF210 NF210.TM
open CS192.Table (State machine)

theorem writeTape_read (tape : Tape) (position : Int) :
    writeTape tape position (tape position) = tape := by
  funext p
  by_cases same : p = position <;> simp [writeTape, same]

theorem step_read {first last : State} {read write : Bool} {direction : Direction}
    (row : machine first read = ⟨write, direction, some last⟩)
    (head : Int) (tape : Tape) (cell : tape head = read) :
    TM.step machine (configuration first head tape) =
      configuration last (moveHead direction head) (writeTape tape head write) := by
  simp only [TM.step, configuration, cell, row]

theorem step_preserve {first last : State} {read : Bool} {direction : Direction}
    (row : machine first read = ⟨read, direction, some last⟩)
    (head : Int) (tape : Tape) (cell : tape head = read) :
    TM.step machine (configuration first head tape) =
      configuration last (moveHead direction head) tape := by
  rw [step_read row head tape cell, ← cell, writeTape_read]

theorem wordTape_append_head (anchor : Int) (front rest : List Bool)
    (symbol : Bool) (outside : Tape) :
    wordTape anchor (front ++ symbol :: rest) outside
      (anchor + (front.length : Int)) = symbol := by
  rw [wordTape_append]
  rw [wordTape_commute anchor (anchor + (front.length : Int)) front (symbol :: rest)
    outside (Int.le_refl _)]
  simp

theorem wordTape_get (anchor : Int) (word : List Bool) (outside : Tape)
    (index : Nat) (inside : index < word.length) :
    wordTape anchor word outside (anchor + (index : Int)) = word[index] := by
  induction word generalizing anchor index with
  | nil => simp at inside
  | cons first rest ih =>
    cases index with
    | zero => simp
    | succ index =>
      have different : anchor + ((index + 1 : Nat) : Int) ≠ anchor := by omega
      simp only [wordTape_cons, writeTape_away _ _ _ _ different, List.getElem_cons_succ]
      have positions : anchor + ((index + 1 : Nat) : Int) =
          anchor + 1 + (index : Int) := by omega
      rw [positions]
      exact ih (anchor + 1) index (by simpa using inside)

theorem wordTape_set (anchor : Int) (word : List Bool) (outside : Tape)
    (index : Nat) (inside : index < word.length) (symbol : Bool) :
    writeTape (wordTape anchor word outside) (anchor + (index : Int)) symbol =
      wordTape anchor (word.set index symbol) outside := by
  induction word generalizing anchor index with
  | nil => simp at inside
  | cons first rest ih =>
    cases index with
    | zero => simp [writeTape_overwrite]
    | succ index =>
      have different : anchor + ((index + 1 : Nat) : Int) ≠ anchor := by omega
      simp only [wordTape_cons, List.set_cons_succ]
      rw [writeTape_commute _ _ _ _ _ different]
      have positions : anchor + ((index + 1 : Nat) : Int) =
          anchor + 1 + (index : Int) := by omega
      rw [positions, ih (anchor + 1) index (by simpa using inside)]

theorem writeTape_append_head (anchor : Int) (front rest : List Bool)
    (old symbol : Bool) (outside : Tape) :
    writeTape (wordTape anchor (front ++ old :: rest) outside)
      (anchor + (front.length : Int)) symbol =
      wordTape anchor (front ++ symbol :: rest) outside := by
  rw [wordTape_set anchor (front ++ old :: rest) outside front.length (by simp)]
  simp

theorem step_word {first last : State} {read write : Bool} {direction : Direction}
    (row : machine first read = ⟨write, direction, some last⟩)
    (anchor : Int) (word : List Bool) (outside : Tape)
    (index : Nat) (inside : index < word.length) (cell : word[index] = read) :
    TM.step machine (configuration first (anchor + (index : Int)) (wordTape anchor word outside)) =
      configuration last (moveHead direction (anchor + (index : Int)))
        (wordTape anchor (word.set index write) outside) := by
  simp only [TM.step, configuration, wordTape_get anchor word outside index inside, cell, row]
  rw [wordTape_set anchor word outside index inside write]

/-- The recurring right-left-left three-step branch, with its exact two-cell effect. -/
theorem turn_triplet {first second third last : State} {x y u v w : Bool}
    (row₁ : machine first x = ⟨u, .right, some second⟩)
    (row₂ : machine second y = ⟨v, .left, some third⟩)
    (row₃ : machine third u = ⟨w, .left, some last⟩)
    (anchor : Int) (outside : Tape) :
    TM.run machine 3 (configuration first anchor (wordTape anchor [x, y] outside)) =
      configuration last (anchor - 1) (wordTape anchor [w, v] outside) := by
  have one : TM.step machine (configuration first anchor (wordTape anchor [x, y] outside)) =
      configuration second (anchor + 1) (wordTape anchor [u, y] outside) := by
    simpa [moveHead] using step_word row₁ anchor [x, y] outside 0 (by simp) rfl
  have two : TM.step machine (configuration second (anchor + 1) (wordTape anchor [u, y] outside)) =
      configuration third anchor (wordTape anchor [u, v] outside) := by
    simpa [moveHead] using step_word row₂ anchor [u, y] outside 1 (by simp) rfl
  have three : TM.step machine (configuration third anchor (wordTape anchor [u, v] outside)) =
      configuration last (anchor - 1) (wordTape anchor [w, v] outside) := by
    simpa [moveHead] using step_word row₃ anchor [u, v] outside 0 (by simp) rfl
  simp only [show 3 = (2 : Nat) + 1 from rfl, TM.run_succ, TM.run_zero]
  rw [one, two, three]

theorem RightRun.repeat {state : State} {read write : Bool}
    (one : RightRun state state [read] [write]) (count : Nat) :
    RightRun state state (List.replicate count read) (List.replicate count write) := by
  induction count with
  | zero => exact RightRun.nil state
  | succ count ih => exact one.trans ih

theorem RightRun.with_suffix {first last : State} {input output : List Bool}
    (certificate : RightRun first last input output)
    (anchor : Int) (suffix : List Bool) (outside : Tape) :
    TM.run machine input.length
      (configuration first anchor (wordTape anchor (input ++ suffix) outside)) =
      configuration last (anchor + (input.length : Int))
        (wordTape anchor (output ++ suffix) outside) := by
  rw [wordTape_append, certificate.exact_run, wordTape_append, ← certificate.same_length]

/-- A rightward routine can be used at any word boundary inside a larger frame. -/
theorem RightRun.context {first last : State} {input output : List Bool}
    (certificate : RightRun first last input output)
    (anchor : Int) (front suffix : List Bool) (outside : Tape) :
    TM.run machine input.length
      (configuration first (anchor + (front.length : Int))
        (wordTape anchor (front ++ input ++ suffix) outside)) =
      configuration last (anchor + (front.length : Int) + (input.length : Int))
        (wordTape anchor (front ++ output ++ suffix) outside) := by
  rw [List.append_assoc, wordTape_append]
  rw [wordTape_commute anchor (anchor + (front.length : Int)) front (input ++ suffix) outside
    (Int.le_refl _)]
  rw [certificate.with_suffix]
  rw [← wordTape_commute anchor (anchor + (front.length : Int)) front (output ++ suffix) outside
    (Int.le_refl _)]
  rw [← wordTape_append, ← List.append_assoc]

theorem run_succ_first (time : Nat) (configuration : TM.Configuration 192) :
    TM.run machine (time + 1) configuration =
      TM.run machine time (TM.step machine configuration) := by
  have order : time + 1 = 1 + time := by omega
  rw [order, TM.run_add]
  rfl

#print axioms step_word
#print axioms RightRun.context

end P192.KernelRightShift
