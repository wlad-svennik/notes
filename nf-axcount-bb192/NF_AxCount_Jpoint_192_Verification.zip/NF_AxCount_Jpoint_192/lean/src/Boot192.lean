module
public import MachineBits
public import Table192

@[expose] public section

/-! The literal blank-tape computation, in the original NF210 integer-tape
semantics. Each intermediate bit mask is only a proposed certificate.
The Lean kernel checks every transition against CS192.Table.machine. -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace CS192.Boot
open NF210 CS192.Table NF192
abbrev width : Nat := 256
abbrev Prefix (duration : Nat) (first last : KernelBits.Configuration 192) : Prop :=
  ∀ (anchor : Int) (outside : TM.Tape),
    TM.run machine duration (KernelBits.embed width anchor outside first) =
      KernelBits.embed width anchor outside last

theorem checked (duration : Nat) (first last : KernelBits.Configuration 192)
    (hi : first.head < width) (h : KernelBits.run machine width duration first = some last) :
    Prefix duration first last := fun a t =>
  (KernelBits.run_sound machine width a t duration first last hi h).2

theorem compose {s t : Nat} {a b c : KernelBits.Configuration 192}
    (first : Prefix s a b) (second : Prefix t b c) : Prefix (s+t) a c := by
  intro anchor outside
  rw [TM.run_add, first anchor outside, second anchor outside]

def snap0 : KernelBits.Configuration 192 := ⟨some (176 : State), 10, 0⟩
def snap500 : KernelBits.Configuration 192 := ⟨some (149 : State), 18, 18979254528⟩
def snap1000 : KernelBits.Configuration 192 := ⟨some (90 : State), 14, 785282887936⟩
def snap1500 : KernelBits.Configuration 192 := ⟨some (151 : State), 22, 102725647986944⟩
def snap2000 : KernelBits.Configuration 192 := ⟨some (157 : State), 2, 3011404977991936⟩
def snap2500 : KernelBits.Configuration 192 := ⟨some (169 : State), 18, 25602912956772608⟩
def snap3000 : KernelBits.Configuration 192 := ⟨some (150 : State), 32, 190828723144782080⟩
def snap3500 : KernelBits.Configuration 192 := ⟨some (155 : State), 18, 195314734881188096⟩
def snap4000 : KernelBits.Configuration 192 := ⟨some (155 : State), 12, 1646043049995970816⟩
def snap4500 : KernelBits.Configuration 192 := ⟨some (155 : State), 36, 1646007861060184320⟩
def snap5000 : KernelBits.Configuration 192 := ⟨some (174 : State), 18, 12515480746090670336⟩
def snap5500 : KernelBits.Configuration 192 := ⟨some (160 : State), 30, 12227227751567042816⟩
def snap6000 : KernelBits.Configuration 192 := ⟨some (34 : State), 26, 98984525734409906432⟩
def snap6500 : KernelBits.Configuration 192 := ⟨some (157 : State), 2, 788431585491384379648⟩
def snap7000 : KernelBits.Configuration 192 := ⟨some (167 : State), 70, 6299396287038625130752⟩
def snap7500 : KernelBits.Configuration 192 := ⟨some (164 : State), 20, 6299396106083065637120⟩
def snap8000 : KernelBits.Configuration 192 := ⟨some (163 : State), 34, 50377891070220627978496⟩
def snap8500 : KernelBits.Configuration 192 := ⟨some (167 : State), 68, 402987403677284761315584⟩
def snap9000 : KernelBits.Configuration 192 := ⟨some (155 : State), 14, 402987403677267583330560⟩
def snap9500 : KernelBits.Configuration 192 := ⟨some (155 : State), 26, 402987402551384856303872⟩
def snap10000 : KernelBits.Configuration 192 := ⟨some (172 : State), 30, 402987236320310661711104⟩
def snap10500 : KernelBits.Configuration 192 := ⟨some (33 : State), 24, 3223826112191521217328384⟩
def snap11000 : KernelBits.Configuration 192 := ⟨some (9 : State), 14, 3223825443085266288907520⟩
def snap11500 : KernelBits.Configuration 192 := ⟨some (155 : State), 22, 25790464000648088553252096⟩
def snap12000 : KernelBits.Configuration 192 := ⟨some (171 : State), 48, 25790461324866558153954560⟩
def snap12500 : KernelBits.Configuration 192 := ⟨some (155 : State), 56, 206323409114948280443192576⟩
def snap13000 : KernelBits.Configuration 192 := ⟨some (176 : State), 20, 206323416855349336410625280⟩
def snap13500 : KernelBits.Configuration 192 := ⟨some (179 : State), 8, 1650586799220683259101824256⟩
def snap14000 : KernelBits.Configuration 192 := ⟨some (181 : State), 70, 1650587334894263930093245696⟩
def snap14500 : KernelBits.Configuration 192 := ⟨some (150 : State), 40, 13204693679546034410661840128⟩
def snap15000 : KernelBits.Configuration 192 := ⟨some (33 : State), 34, 13204693974693939074618633472⟩
def snap15500 : KernelBits.Configuration 192 := ⟨some (180 : State), 4, 13204693974693939040258891008⟩
def snap16000 : KernelBits.Configuration 192 := ⟨some (164 : State), 16, 13204693974693939040258945792⟩
def snap16500 : KernelBits.Configuration 192 := ⟨some (162 : State), 24, 13204693974688792776085048064⟩
def snap16817 : KernelBits.Configuration 192 := ⟨some (13 : State), 9, 13204693974678496949202594560⟩
def snap17000 : KernelBits.Configuration 192 := ⟨some (23 : State), 16, 13204693974678428779481148160⟩
def snap17500 : KernelBits.Configuration 192 := ⟨some (151 : State), 24, 13204693974678499148209105664⟩
def snap18000 : KernelBits.Configuration 192 := ⟨some (33 : State), 32, 13204693974678496957792824064⟩
def snap18500 : KernelBits.Configuration 192 := ⟨some (171 : State), 26, 13204693974678499148163230464⟩
def snap19000 : KernelBits.Configuration 192 := ⟨some (151 : State), 42, 13204693974678494750225771264⟩
def snap19500 : KernelBits.Configuration 192 := ⟨some (179 : State), 2, 13204693974678496949232249600⟩
def snap20000 : KernelBits.Configuration 192 := ⟨some (71 : State), 14, 13204693974678499148211464960⟩
def snap20500 : KernelBits.Configuration 192 := ⟨some (160 : State), 6, 13204693679510006713098218240⟩
def snap21000 : KernelBits.Configuration 192 := ⟨some (150 : State), 52, 105637550634830179323871537920⟩
def snap21500 : KernelBits.Configuration 192 := ⟨some (150 : State), 36, 845100401383631586323226471168⟩
def snap22000 : KernelBits.Configuration 192 := ⟨some (167 : State), 86, 6760803204022886695877657012992⟩
def snap22500 : KernelBits.Configuration 192 := ⟨some (172 : State), 56, 54086425615349115523879403825920⟩
def snap23000 : KernelBits.Configuration 192 := ⟨some (151 : State), 38, 54086425615349115523604773382912⟩
def snap23500 : KernelBits.Configuration 192 := ⟨some (33 : State), 30, 54086425614663954589150402095872⟩
def snap24000 : KernelBits.Configuration 192 := ⟨some (34 : State), 36, 432691404887755287065918940949248⟩
def snap24500 : KernelBits.Configuration 192 := ⟨some (149 : State), 40, 432691404885015294466506646399744⟩
def snap25000 : KernelBits.Configuration 192 := ⟨some (151 : State), 32, 3461531239037445705442236916083456⟩
def snap25500 : KernelBits.Configuration 192 := ⟨some (182 : State), 38, 3461531239037445705442241118776064⟩
def snap26000 : KernelBits.Configuration 192 := ⟨some (157 : State), 2, 3461531239037445700234954145049344⟩
def snap26500 : KernelBits.Configuration 192 := ⟨some (33 : State), 36, 27692249912225160587952712628611840⟩
def snap27000 : KernelBits.Configuration 192 := ⟨some (139 : State), 16, 27692249912225160577608369728432896⟩
def snap27500 : KernelBits.Configuration 192 := ⟨some (34 : State), 36, 221537999297575763951897577688181504⟩
def snap28000 : KernelBits.Configuration 192 := ⟨some (66 : State), 10, 221537999297575763951897508884818688⟩
def snap28500 : KernelBits.Configuration 192 := ⟨some (69 : State), 12, 221537999297575763952038245869857536⟩
def snap29000 : KernelBits.Configuration 192 := ⟨some (155 : State), 54, 221537999297556874486106766886349568⟩
def snap29500 : KernelBits.Configuration 192 := ⟨some (160 : State), 30, 221537999297564657694521503381760768⟩
def snap30000 : KernelBits.Configuration 192 := ⟨some (175 : State), 44, 1772303994380045559862900273819462400⟩
def snap30500 : KernelBits.Configuration 192 := ⟨some (159 : State), 50, 1772303994380001801550788696355416832⟩
def snap31000 : KernelBits.Configuration 192 := ⟨some (164 : State), 42, 14178431955039330586413666040487914240⟩
def snap31500 : KernelBits.Configuration 192 := ⟨some (155 : State), 24, 14178431955039330586413661645259975424⟩
def snap32000 : KernelBits.Configuration 192 := ⟨some (164 : State), 38, 14178431955039330586330908276179643136⟩
def snap32500 : KernelBits.Configuration 192 := ⟨some (149 : State), 34, 113427455640313277344195173870030072576⟩
def snap33000 : KernelBits.Configuration 192 := ⟨some (172 : State), 80, 907419645122503831375950126854922611456⟩
def snap33500 : KernelBits.Configuration 192 := ⟨some (150 : State), 46, 907419645122503831375661896484408044288⟩
def snap34000 : KernelBits.Configuration 192 := ⟨some (150 : State), 62, 907419645122503226911723016655100750592⟩
def snap34500 : KernelBits.Configuration 192 := ⟨some (176 : State), 52, 907419645122503480434550193676149369600⟩
def snap35000 : KernelBits.Configuration 192 := ⟨some (160 : State), 74, 7259357160980019961404015278660699597568⟩
def snap35500 : KernelBits.Configuration 192 := ⟨some (157 : State), 2, 7259357160980022379255654507925625678592⟩
def snap36000 : KernelBits.Configuration 192 := ⟨some (175 : State), 42, 7259357160980022379255654507925223025408⟩
def snap36500 : KernelBits.Configuration 192 := ⟨some (179 : State), 6, 7259357160980022379255654507925961222912⟩
def snap37000 : KernelBits.Configuration 192 := ⟨some (179 : State), 4, 7259357160980022378644277347711400061696⟩
def snap37500 : KernelBits.Configuration 192 := ⟨some (189 : State), 20, 58074857287840168080600508950289847724800⟩
def snap38000 : KernelBits.Configuration 192 := ⟨some (34 : State), 36, 58074857287840168078155004813100218362624⟩
def snap38500 : KernelBits.Configuration 192 := ⟨some (167 : State), 64, 464598858302721322742805643664988264770304⟩
def snap39000 : KernelBits.Configuration 192 := ⟨some (139 : State), 16, 464598858302721322723916177733511160310528⟩
def snap39500 : KernelBits.Configuration 192 := ⟨some (104 : State), 22, 464598858302721322733023591087159997934336⟩
def snap40000 : KernelBits.Configuration 192 := ⟨some (155 : State), 48, 3716790866421770538158012146399351770753792⟩
def snap40500 : KernelBits.Configuration 192 := ⟨some (124 : State), 18, 3716790866421770538158012128384953420655360⟩
def snap41000 : KernelBits.Configuration 192 := ⟨some (155 : State), 10, 3716790866421770538158012128384953437432576⟩
def snap41500 : KernelBits.Configuration 192 := ⟨some (149 : State), 48, 3716790866421770538158012128384953416461056⟩
def snap42000 : KernelBits.Configuration 192 := ⟨some (33 : State), 36, 3716790866421770538158012074341895360523008⟩
def snap42500 : KernelBits.Configuration 192 := ⟨some (167 : State), 124, 29734326931374164217890870415470411484801792⟩
def snap43000 : KernelBits.Configuration 192 := ⟨some (155 : State), 26, 29734326931374164179205244187802276954680064⟩
def snap43500 : KernelBits.Configuration 192 := ⟨some (171 : State), 72, 29734326931374164217890870415470410813713152⟩
def snap44000 : KernelBits.Configuration 192 := ⟨some (175 : State), 36, 29734326931374164217851742493389467992500992⟩
def snap44500 : KernelBits.Configuration 192 := ⟨some (34 : State), 32, 237874615450993313590432614602940769128196864⟩
def snap45000 : KernelBits.Configuration 192 := ⟨some (166 : State), 28, 237874615450993313590432614674998355113061120⟩
def snap45500 : KernelBits.Configuration 192 := ⟨some (172 : State), 54, 237874615450993313590432614530883168480045824⟩
def snap46000 : KernelBits.Configuration 192 := ⟨some (176 : State), 36, 237874615450993313590281498803431339061455616⟩
def snap46500 : KernelBits.Configuration 192 := ⟨some (180 : State), 4, 1902996923607946508239229454499538543465245440⟩
def snap47000 : KernelBits.Configuration 192 := ⟨some (87 : State), 24, 1902996923607946508194420942897289818962963200⟩
def snap47500 : KernelBits.Configuration 192 := ⟨some (150 : State), 42, 1902996923607946508194420942032598689534749440⟩
def snap48000 : KernelBits.Configuration 192 := ⟨some (157 : State), 2, 1902996923607946508194118711154155784309615360⟩
def snap48500 : KernelBits.Configuration 192 := ⟨some (164 : State), 54, 15223975388863572064855286152808648513867262720⟩
def snap49000 : KernelBits.Configuration 192 := ⟨some (149 : State), 36, 15223975388863572064855286152790634116699958016⟩
def snap49500 : KernelBits.Configuration 192 := ⟨some (33 : State), 58, 15223975388863572064855129640237619223939296000⟩
def snap50000 : KernelBits.Configuration 192 := ⟨some (176 : State), 78, 15223975388863572064545644630992734898928003840⟩
def snap50500 : KernelBits.Configuration 192 := ⟨some (155 : State), 40, 121791803110908576517619795372804843582843562752⟩
def snap51000 : KernelBits.Configuration 192 := ⟨some (66 : State), 10, 121791803110908576517619482345392970788645415680⟩
def snap51500 : KernelBits.Configuration 192 := ⟨some (172 : State), 116, 974334424887268612137260928125054162105162574592⟩
def snap52000 : KernelBits.Configuration 192 := ⟨some (159 : State), 70, 974334424887268612137260928125054162111068154624⟩
def snap52500 : KernelBits.Configuration 192 := ⟨some (164 : State), 46, 974334424887268612137260928122748389472242805504⟩
def snap53000 : KernelBits.Configuration 192 := ⟨some (104 : State), 22, 974334424887268612137260928122748319103582513920⟩
def snap53500 : KernelBits.Configuration 192 := ⟨some (149 : State), 40, 974334424887268612137260928122748319103574125312⟩
def snap54000 : KernelBits.Configuration 192 := ⟨some (34 : State), 58, 974334424887268612137260928123036549479759391488⟩
def snap54500 : KernelBits.Configuration 192 := ⟨some (150 : State), 78, 974334424887268612136951421527930564784956943104⟩
def snap55000 : KernelBits.Configuration 192 := ⟨some (155 : State), 34, 974334424887268612137078963201899908162418682624⟩
def snap55500 : KernelBits.Configuration 192 := ⟨some (179 : State), 8, 7794675399098148897088903345068022786595520555776⟩
def snap56000 : KernelBits.Configuration 192 := ⟨some (34 : State), 62, 7794675399098148897088186408882386806978251107072⟩
def snap56500 : KernelBits.Configuration 192 := ⟨some (181 : State), 104, 7794675399098148903850856912517656673182087949056⟩
def snap57000 : KernelBits.Configuration 192 := ⟨some (155 : State), 48, 62357403192785191176694287466041665932361465113344⟩
def snap57500 : KernelBits.Configuration 192 := ⟨some (33 : State), 40, 62357403192785191176694287466032442562524573117184⟩
def snap58000 : KernelBits.Configuration 192 := ⟨some (172 : State), 36, 62357403192785191176694287464695053614980835617536⟩
def snap58195 : KernelBits.Configuration 192 := ⟨some (13 : State), 9, 62357403192785191176694287464676606870907730045696⟩

theorem chunk500 : Prefix 500 snap0 snap500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank500 : Prefix 500 snap0 snap500 := chunk500
theorem chunk1000 : Prefix 500 snap500 snap1000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank1000 : Prefix 1000 snap0 snap1000 := @compose 500 500 snap0 snap500 snap1000 fromBlank500 chunk1000
theorem chunk1500 : Prefix 500 snap1000 snap1500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank1500 : Prefix 1500 snap0 snap1500 := @compose 1000 500 snap0 snap1000 snap1500 fromBlank1000 chunk1500
theorem chunk2000 : Prefix 500 snap1500 snap2000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank2000 : Prefix 2000 snap0 snap2000 := @compose 1500 500 snap0 snap1500 snap2000 fromBlank1500 chunk2000
theorem chunk2500 : Prefix 500 snap2000 snap2500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank2500 : Prefix 2500 snap0 snap2500 := @compose 2000 500 snap0 snap2000 snap2500 fromBlank2000 chunk2500
theorem chunk3000 : Prefix 500 snap2500 snap3000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank3000 : Prefix 3000 snap0 snap3000 := @compose 2500 500 snap0 snap2500 snap3000 fromBlank2500 chunk3000
theorem chunk3500 : Prefix 500 snap3000 snap3500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank3500 : Prefix 3500 snap0 snap3500 := @compose 3000 500 snap0 snap3000 snap3500 fromBlank3000 chunk3500
theorem chunk4000 : Prefix 500 snap3500 snap4000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank4000 : Prefix 4000 snap0 snap4000 := @compose 3500 500 snap0 snap3500 snap4000 fromBlank3500 chunk4000
theorem chunk4500 : Prefix 500 snap4000 snap4500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank4500 : Prefix 4500 snap0 snap4500 := @compose 4000 500 snap0 snap4000 snap4500 fromBlank4000 chunk4500
theorem chunk5000 : Prefix 500 snap4500 snap5000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank5000 : Prefix 5000 snap0 snap5000 := @compose 4500 500 snap0 snap4500 snap5000 fromBlank4500 chunk5000
theorem chunk5500 : Prefix 500 snap5000 snap5500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank5500 : Prefix 5500 snap0 snap5500 := @compose 5000 500 snap0 snap5000 snap5500 fromBlank5000 chunk5500
theorem chunk6000 : Prefix 500 snap5500 snap6000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank6000 : Prefix 6000 snap0 snap6000 := @compose 5500 500 snap0 snap5500 snap6000 fromBlank5500 chunk6000
theorem chunk6500 : Prefix 500 snap6000 snap6500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank6500 : Prefix 6500 snap0 snap6500 := @compose 6000 500 snap0 snap6000 snap6500 fromBlank6000 chunk6500
theorem chunk7000 : Prefix 500 snap6500 snap7000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank7000 : Prefix 7000 snap0 snap7000 := @compose 6500 500 snap0 snap6500 snap7000 fromBlank6500 chunk7000
theorem chunk7500 : Prefix 500 snap7000 snap7500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank7500 : Prefix 7500 snap0 snap7500 := @compose 7000 500 snap0 snap7000 snap7500 fromBlank7000 chunk7500
theorem chunk8000 : Prefix 500 snap7500 snap8000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank8000 : Prefix 8000 snap0 snap8000 := @compose 7500 500 snap0 snap7500 snap8000 fromBlank7500 chunk8000
theorem chunk8500 : Prefix 500 snap8000 snap8500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank8500 : Prefix 8500 snap0 snap8500 := @compose 8000 500 snap0 snap8000 snap8500 fromBlank8000 chunk8500
theorem chunk9000 : Prefix 500 snap8500 snap9000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank9000 : Prefix 9000 snap0 snap9000 := @compose 8500 500 snap0 snap8500 snap9000 fromBlank8500 chunk9000
theorem chunk9500 : Prefix 500 snap9000 snap9500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank9500 : Prefix 9500 snap0 snap9500 := @compose 9000 500 snap0 snap9000 snap9500 fromBlank9000 chunk9500
theorem chunk10000 : Prefix 500 snap9500 snap10000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank10000 : Prefix 10000 snap0 snap10000 := @compose 9500 500 snap0 snap9500 snap10000 fromBlank9500 chunk10000
theorem chunk10500 : Prefix 500 snap10000 snap10500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank10500 : Prefix 10500 snap0 snap10500 := @compose 10000 500 snap0 snap10000 snap10500 fromBlank10000 chunk10500
theorem chunk11000 : Prefix 500 snap10500 snap11000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank11000 : Prefix 11000 snap0 snap11000 := @compose 10500 500 snap0 snap10500 snap11000 fromBlank10500 chunk11000
theorem chunk11500 : Prefix 500 snap11000 snap11500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank11500 : Prefix 11500 snap0 snap11500 := @compose 11000 500 snap0 snap11000 snap11500 fromBlank11000 chunk11500
theorem chunk12000 : Prefix 500 snap11500 snap12000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank12000 : Prefix 12000 snap0 snap12000 := @compose 11500 500 snap0 snap11500 snap12000 fromBlank11500 chunk12000
theorem chunk12500 : Prefix 500 snap12000 snap12500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank12500 : Prefix 12500 snap0 snap12500 := @compose 12000 500 snap0 snap12000 snap12500 fromBlank12000 chunk12500
theorem chunk13000 : Prefix 500 snap12500 snap13000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank13000 : Prefix 13000 snap0 snap13000 := @compose 12500 500 snap0 snap12500 snap13000 fromBlank12500 chunk13000
theorem chunk13500 : Prefix 500 snap13000 snap13500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank13500 : Prefix 13500 snap0 snap13500 := @compose 13000 500 snap0 snap13000 snap13500 fromBlank13000 chunk13500
theorem chunk14000 : Prefix 500 snap13500 snap14000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank14000 : Prefix 14000 snap0 snap14000 := @compose 13500 500 snap0 snap13500 snap14000 fromBlank13500 chunk14000
theorem chunk14500 : Prefix 500 snap14000 snap14500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank14500 : Prefix 14500 snap0 snap14500 := @compose 14000 500 snap0 snap14000 snap14500 fromBlank14000 chunk14500
theorem chunk15000 : Prefix 500 snap14500 snap15000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank15000 : Prefix 15000 snap0 snap15000 := @compose 14500 500 snap0 snap14500 snap15000 fromBlank14500 chunk15000
theorem chunk15500 : Prefix 500 snap15000 snap15500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank15500 : Prefix 15500 snap0 snap15500 := @compose 15000 500 snap0 snap15000 snap15500 fromBlank15000 chunk15500
theorem chunk16000 : Prefix 500 snap15500 snap16000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank16000 : Prefix 16000 snap0 snap16000 := @compose 15500 500 snap0 snap15500 snap16000 fromBlank15500 chunk16000
theorem chunk16500 : Prefix 500 snap16000 snap16500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank16500 : Prefix 16500 snap0 snap16500 := @compose 16000 500 snap0 snap16000 snap16500 fromBlank16000 chunk16500
theorem chunk16817 : Prefix 317 snap16500 snap16817 := checked _ _ _ (by decide) (by decide)
theorem fromBlank16817 : Prefix 16817 snap0 snap16817 := @compose 16500 317 snap0 snap16500 snap16817 fromBlank16500 chunk16817
theorem chunk17000 : Prefix 183 snap16817 snap17000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank17000 : Prefix 17000 snap0 snap17000 := @compose 16817 183 snap0 snap16817 snap17000 fromBlank16817 chunk17000
theorem chunk17500 : Prefix 500 snap17000 snap17500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank17500 : Prefix 17500 snap0 snap17500 := @compose 17000 500 snap0 snap17000 snap17500 fromBlank17000 chunk17500
theorem chunk18000 : Prefix 500 snap17500 snap18000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank18000 : Prefix 18000 snap0 snap18000 := @compose 17500 500 snap0 snap17500 snap18000 fromBlank17500 chunk18000
theorem chunk18500 : Prefix 500 snap18000 snap18500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank18500 : Prefix 18500 snap0 snap18500 := @compose 18000 500 snap0 snap18000 snap18500 fromBlank18000 chunk18500
theorem chunk19000 : Prefix 500 snap18500 snap19000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank19000 : Prefix 19000 snap0 snap19000 := @compose 18500 500 snap0 snap18500 snap19000 fromBlank18500 chunk19000
theorem chunk19500 : Prefix 500 snap19000 snap19500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank19500 : Prefix 19500 snap0 snap19500 := @compose 19000 500 snap0 snap19000 snap19500 fromBlank19000 chunk19500
theorem chunk20000 : Prefix 500 snap19500 snap20000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank20000 : Prefix 20000 snap0 snap20000 := @compose 19500 500 snap0 snap19500 snap20000 fromBlank19500 chunk20000
theorem chunk20500 : Prefix 500 snap20000 snap20500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank20500 : Prefix 20500 snap0 snap20500 := @compose 20000 500 snap0 snap20000 snap20500 fromBlank20000 chunk20500
theorem chunk21000 : Prefix 500 snap20500 snap21000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank21000 : Prefix 21000 snap0 snap21000 := @compose 20500 500 snap0 snap20500 snap21000 fromBlank20500 chunk21000
theorem chunk21500 : Prefix 500 snap21000 snap21500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank21500 : Prefix 21500 snap0 snap21500 := @compose 21000 500 snap0 snap21000 snap21500 fromBlank21000 chunk21500
theorem chunk22000 : Prefix 500 snap21500 snap22000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank22000 : Prefix 22000 snap0 snap22000 := @compose 21500 500 snap0 snap21500 snap22000 fromBlank21500 chunk22000
theorem chunk22500 : Prefix 500 snap22000 snap22500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank22500 : Prefix 22500 snap0 snap22500 := @compose 22000 500 snap0 snap22000 snap22500 fromBlank22000 chunk22500
theorem chunk23000 : Prefix 500 snap22500 snap23000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank23000 : Prefix 23000 snap0 snap23000 := @compose 22500 500 snap0 snap22500 snap23000 fromBlank22500 chunk23000
theorem chunk23500 : Prefix 500 snap23000 snap23500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank23500 : Prefix 23500 snap0 snap23500 := @compose 23000 500 snap0 snap23000 snap23500 fromBlank23000 chunk23500
theorem chunk24000 : Prefix 500 snap23500 snap24000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank24000 : Prefix 24000 snap0 snap24000 := @compose 23500 500 snap0 snap23500 snap24000 fromBlank23500 chunk24000
theorem chunk24500 : Prefix 500 snap24000 snap24500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank24500 : Prefix 24500 snap0 snap24500 := @compose 24000 500 snap0 snap24000 snap24500 fromBlank24000 chunk24500
theorem chunk25000 : Prefix 500 snap24500 snap25000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank25000 : Prefix 25000 snap0 snap25000 := @compose 24500 500 snap0 snap24500 snap25000 fromBlank24500 chunk25000
theorem chunk25500 : Prefix 500 snap25000 snap25500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank25500 : Prefix 25500 snap0 snap25500 := @compose 25000 500 snap0 snap25000 snap25500 fromBlank25000 chunk25500
theorem chunk26000 : Prefix 500 snap25500 snap26000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank26000 : Prefix 26000 snap0 snap26000 := @compose 25500 500 snap0 snap25500 snap26000 fromBlank25500 chunk26000
theorem chunk26500 : Prefix 500 snap26000 snap26500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank26500 : Prefix 26500 snap0 snap26500 := @compose 26000 500 snap0 snap26000 snap26500 fromBlank26000 chunk26500
theorem chunk27000 : Prefix 500 snap26500 snap27000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank27000 : Prefix 27000 snap0 snap27000 := @compose 26500 500 snap0 snap26500 snap27000 fromBlank26500 chunk27000
theorem chunk27500 : Prefix 500 snap27000 snap27500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank27500 : Prefix 27500 snap0 snap27500 := @compose 27000 500 snap0 snap27000 snap27500 fromBlank27000 chunk27500
theorem chunk28000 : Prefix 500 snap27500 snap28000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank28000 : Prefix 28000 snap0 snap28000 := @compose 27500 500 snap0 snap27500 snap28000 fromBlank27500 chunk28000
theorem chunk28500 : Prefix 500 snap28000 snap28500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank28500 : Prefix 28500 snap0 snap28500 := @compose 28000 500 snap0 snap28000 snap28500 fromBlank28000 chunk28500
theorem chunk29000 : Prefix 500 snap28500 snap29000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank29000 : Prefix 29000 snap0 snap29000 := @compose 28500 500 snap0 snap28500 snap29000 fromBlank28500 chunk29000
theorem chunk29500 : Prefix 500 snap29000 snap29500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank29500 : Prefix 29500 snap0 snap29500 := @compose 29000 500 snap0 snap29000 snap29500 fromBlank29000 chunk29500
theorem chunk30000 : Prefix 500 snap29500 snap30000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank30000 : Prefix 30000 snap0 snap30000 := @compose 29500 500 snap0 snap29500 snap30000 fromBlank29500 chunk30000
theorem chunk30500 : Prefix 500 snap30000 snap30500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank30500 : Prefix 30500 snap0 snap30500 := @compose 30000 500 snap0 snap30000 snap30500 fromBlank30000 chunk30500
theorem chunk31000 : Prefix 500 snap30500 snap31000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank31000 : Prefix 31000 snap0 snap31000 := @compose 30500 500 snap0 snap30500 snap31000 fromBlank30500 chunk31000
theorem chunk31500 : Prefix 500 snap31000 snap31500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank31500 : Prefix 31500 snap0 snap31500 := @compose 31000 500 snap0 snap31000 snap31500 fromBlank31000 chunk31500
theorem chunk32000 : Prefix 500 snap31500 snap32000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank32000 : Prefix 32000 snap0 snap32000 := @compose 31500 500 snap0 snap31500 snap32000 fromBlank31500 chunk32000
theorem chunk32500 : Prefix 500 snap32000 snap32500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank32500 : Prefix 32500 snap0 snap32500 := @compose 32000 500 snap0 snap32000 snap32500 fromBlank32000 chunk32500
theorem chunk33000 : Prefix 500 snap32500 snap33000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank33000 : Prefix 33000 snap0 snap33000 := @compose 32500 500 snap0 snap32500 snap33000 fromBlank32500 chunk33000
theorem chunk33500 : Prefix 500 snap33000 snap33500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank33500 : Prefix 33500 snap0 snap33500 := @compose 33000 500 snap0 snap33000 snap33500 fromBlank33000 chunk33500
theorem chunk34000 : Prefix 500 snap33500 snap34000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank34000 : Prefix 34000 snap0 snap34000 := @compose 33500 500 snap0 snap33500 snap34000 fromBlank33500 chunk34000
theorem chunk34500 : Prefix 500 snap34000 snap34500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank34500 : Prefix 34500 snap0 snap34500 := @compose 34000 500 snap0 snap34000 snap34500 fromBlank34000 chunk34500
theorem chunk35000 : Prefix 500 snap34500 snap35000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank35000 : Prefix 35000 snap0 snap35000 := @compose 34500 500 snap0 snap34500 snap35000 fromBlank34500 chunk35000
theorem chunk35500 : Prefix 500 snap35000 snap35500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank35500 : Prefix 35500 snap0 snap35500 := @compose 35000 500 snap0 snap35000 snap35500 fromBlank35000 chunk35500
theorem chunk36000 : Prefix 500 snap35500 snap36000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank36000 : Prefix 36000 snap0 snap36000 := @compose 35500 500 snap0 snap35500 snap36000 fromBlank35500 chunk36000
theorem chunk36500 : Prefix 500 snap36000 snap36500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank36500 : Prefix 36500 snap0 snap36500 := @compose 36000 500 snap0 snap36000 snap36500 fromBlank36000 chunk36500
theorem chunk37000 : Prefix 500 snap36500 snap37000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank37000 : Prefix 37000 snap0 snap37000 := @compose 36500 500 snap0 snap36500 snap37000 fromBlank36500 chunk37000
theorem chunk37500 : Prefix 500 snap37000 snap37500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank37500 : Prefix 37500 snap0 snap37500 := @compose 37000 500 snap0 snap37000 snap37500 fromBlank37000 chunk37500
theorem chunk38000 : Prefix 500 snap37500 snap38000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank38000 : Prefix 38000 snap0 snap38000 := @compose 37500 500 snap0 snap37500 snap38000 fromBlank37500 chunk38000
theorem chunk38500 : Prefix 500 snap38000 snap38500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank38500 : Prefix 38500 snap0 snap38500 := @compose 38000 500 snap0 snap38000 snap38500 fromBlank38000 chunk38500
theorem chunk39000 : Prefix 500 snap38500 snap39000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank39000 : Prefix 39000 snap0 snap39000 := @compose 38500 500 snap0 snap38500 snap39000 fromBlank38500 chunk39000
theorem chunk39500 : Prefix 500 snap39000 snap39500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank39500 : Prefix 39500 snap0 snap39500 := @compose 39000 500 snap0 snap39000 snap39500 fromBlank39000 chunk39500
theorem chunk40000 : Prefix 500 snap39500 snap40000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank40000 : Prefix 40000 snap0 snap40000 := @compose 39500 500 snap0 snap39500 snap40000 fromBlank39500 chunk40000
theorem chunk40500 : Prefix 500 snap40000 snap40500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank40500 : Prefix 40500 snap0 snap40500 := @compose 40000 500 snap0 snap40000 snap40500 fromBlank40000 chunk40500
theorem chunk41000 : Prefix 500 snap40500 snap41000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank41000 : Prefix 41000 snap0 snap41000 := @compose 40500 500 snap0 snap40500 snap41000 fromBlank40500 chunk41000
theorem chunk41500 : Prefix 500 snap41000 snap41500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank41500 : Prefix 41500 snap0 snap41500 := @compose 41000 500 snap0 snap41000 snap41500 fromBlank41000 chunk41500
theorem chunk42000 : Prefix 500 snap41500 snap42000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank42000 : Prefix 42000 snap0 snap42000 := @compose 41500 500 snap0 snap41500 snap42000 fromBlank41500 chunk42000
theorem chunk42500 : Prefix 500 snap42000 snap42500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank42500 : Prefix 42500 snap0 snap42500 := @compose 42000 500 snap0 snap42000 snap42500 fromBlank42000 chunk42500
theorem chunk43000 : Prefix 500 snap42500 snap43000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank43000 : Prefix 43000 snap0 snap43000 := @compose 42500 500 snap0 snap42500 snap43000 fromBlank42500 chunk43000
theorem chunk43500 : Prefix 500 snap43000 snap43500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank43500 : Prefix 43500 snap0 snap43500 := @compose 43000 500 snap0 snap43000 snap43500 fromBlank43000 chunk43500
theorem chunk44000 : Prefix 500 snap43500 snap44000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank44000 : Prefix 44000 snap0 snap44000 := @compose 43500 500 snap0 snap43500 snap44000 fromBlank43500 chunk44000
theorem chunk44500 : Prefix 500 snap44000 snap44500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank44500 : Prefix 44500 snap0 snap44500 := @compose 44000 500 snap0 snap44000 snap44500 fromBlank44000 chunk44500
theorem chunk45000 : Prefix 500 snap44500 snap45000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank45000 : Prefix 45000 snap0 snap45000 := @compose 44500 500 snap0 snap44500 snap45000 fromBlank44500 chunk45000
theorem chunk45500 : Prefix 500 snap45000 snap45500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank45500 : Prefix 45500 snap0 snap45500 := @compose 45000 500 snap0 snap45000 snap45500 fromBlank45000 chunk45500
theorem chunk46000 : Prefix 500 snap45500 snap46000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank46000 : Prefix 46000 snap0 snap46000 := @compose 45500 500 snap0 snap45500 snap46000 fromBlank45500 chunk46000
theorem chunk46500 : Prefix 500 snap46000 snap46500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank46500 : Prefix 46500 snap0 snap46500 := @compose 46000 500 snap0 snap46000 snap46500 fromBlank46000 chunk46500
theorem chunk47000 : Prefix 500 snap46500 snap47000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank47000 : Prefix 47000 snap0 snap47000 := @compose 46500 500 snap0 snap46500 snap47000 fromBlank46500 chunk47000
theorem chunk47500 : Prefix 500 snap47000 snap47500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank47500 : Prefix 47500 snap0 snap47500 := @compose 47000 500 snap0 snap47000 snap47500 fromBlank47000 chunk47500
theorem chunk48000 : Prefix 500 snap47500 snap48000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank48000 : Prefix 48000 snap0 snap48000 := @compose 47500 500 snap0 snap47500 snap48000 fromBlank47500 chunk48000
theorem chunk48500 : Prefix 500 snap48000 snap48500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank48500 : Prefix 48500 snap0 snap48500 := @compose 48000 500 snap0 snap48000 snap48500 fromBlank48000 chunk48500
theorem chunk49000 : Prefix 500 snap48500 snap49000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank49000 : Prefix 49000 snap0 snap49000 := @compose 48500 500 snap0 snap48500 snap49000 fromBlank48500 chunk49000
theorem chunk49500 : Prefix 500 snap49000 snap49500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank49500 : Prefix 49500 snap0 snap49500 := @compose 49000 500 snap0 snap49000 snap49500 fromBlank49000 chunk49500
theorem chunk50000 : Prefix 500 snap49500 snap50000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank50000 : Prefix 50000 snap0 snap50000 := @compose 49500 500 snap0 snap49500 snap50000 fromBlank49500 chunk50000
theorem chunk50500 : Prefix 500 snap50000 snap50500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank50500 : Prefix 50500 snap0 snap50500 := @compose 50000 500 snap0 snap50000 snap50500 fromBlank50000 chunk50500
theorem chunk51000 : Prefix 500 snap50500 snap51000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank51000 : Prefix 51000 snap0 snap51000 := @compose 50500 500 snap0 snap50500 snap51000 fromBlank50500 chunk51000
theorem chunk51500 : Prefix 500 snap51000 snap51500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank51500 : Prefix 51500 snap0 snap51500 := @compose 51000 500 snap0 snap51000 snap51500 fromBlank51000 chunk51500
theorem chunk52000 : Prefix 500 snap51500 snap52000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank52000 : Prefix 52000 snap0 snap52000 := @compose 51500 500 snap0 snap51500 snap52000 fromBlank51500 chunk52000
theorem chunk52500 : Prefix 500 snap52000 snap52500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank52500 : Prefix 52500 snap0 snap52500 := @compose 52000 500 snap0 snap52000 snap52500 fromBlank52000 chunk52500
theorem chunk53000 : Prefix 500 snap52500 snap53000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank53000 : Prefix 53000 snap0 snap53000 := @compose 52500 500 snap0 snap52500 snap53000 fromBlank52500 chunk53000
theorem chunk53500 : Prefix 500 snap53000 snap53500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank53500 : Prefix 53500 snap0 snap53500 := @compose 53000 500 snap0 snap53000 snap53500 fromBlank53000 chunk53500
theorem chunk54000 : Prefix 500 snap53500 snap54000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank54000 : Prefix 54000 snap0 snap54000 := @compose 53500 500 snap0 snap53500 snap54000 fromBlank53500 chunk54000
theorem chunk54500 : Prefix 500 snap54000 snap54500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank54500 : Prefix 54500 snap0 snap54500 := @compose 54000 500 snap0 snap54000 snap54500 fromBlank54000 chunk54500
theorem chunk55000 : Prefix 500 snap54500 snap55000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank55000 : Prefix 55000 snap0 snap55000 := @compose 54500 500 snap0 snap54500 snap55000 fromBlank54500 chunk55000
theorem chunk55500 : Prefix 500 snap55000 snap55500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank55500 : Prefix 55500 snap0 snap55500 := @compose 55000 500 snap0 snap55000 snap55500 fromBlank55000 chunk55500
theorem chunk56000 : Prefix 500 snap55500 snap56000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank56000 : Prefix 56000 snap0 snap56000 := @compose 55500 500 snap0 snap55500 snap56000 fromBlank55500 chunk56000
theorem chunk56500 : Prefix 500 snap56000 snap56500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank56500 : Prefix 56500 snap0 snap56500 := @compose 56000 500 snap0 snap56000 snap56500 fromBlank56000 chunk56500
theorem chunk57000 : Prefix 500 snap56500 snap57000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank57000 : Prefix 57000 snap0 snap57000 := @compose 56500 500 snap0 snap56500 snap57000 fromBlank56500 chunk57000
theorem chunk57500 : Prefix 500 snap57000 snap57500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank57500 : Prefix 57500 snap0 snap57500 := @compose 57000 500 snap0 snap57000 snap57500 fromBlank57000 chunk57500
theorem chunk58000 : Prefix 500 snap57500 snap58000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank58000 : Prefix 58000 snap0 snap58000 := @compose 57500 500 snap0 snap57500 snap58000 fromBlank57500 chunk58000
theorem chunk58195 : Prefix 195 snap58000 snap58195 := checked _ _ _ (by decide) (by decide)
theorem fromBlank58195 : Prefix 58195 snap0 snap58195 := @compose 58000 195 snap0 snap58000 snap58195 fromBlank58000 chunk58195
theorem embed_start : KernelBits.embed width (-10) (fun _ => false) snap0 = TM.blank start := by
  show TM.Configuration.mk _ _ _ = TM.Configuration.mk _ _ _
  congr 1
  funext p
  simp [KernelBits.tape, snap0]

theorem blank_first_ax : TM.run machine 16817 (TM.blank start) = KernelBits.embed width (-10) (fun _ => false) snap16817 := by
  rw [← embed_start]
  exact fromBlank16817 _ _
#print axioms blank_first_ax
theorem blank_safe_gap : TM.run machine 58195 (TM.blank start) = KernelBits.embed width (-10) (fun _ => false) snap58195 := by
  rw [← embed_start]
  exact fromBlank58195 _ _
#print axioms blank_safe_gap
end CS192.Boot
