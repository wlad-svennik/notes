module
public import Table192
@[expose] public section
namespace CS192.Table
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-- The author-provided file order includes every working state. -/
theorem literalOrder_contains : ∀ q : Fin 192, q ∈ literalOrder := by decide +kernel
/-- The author-provided file order lists every working state exactly once. -/
theorem literalOrder_nodup : literalOrder.Nodup := by decide +kernel
end CS192.Table
#print axioms CS192.Table.literalOrder_contains
#print axioms CS192.Table.literalOrder_nodup
