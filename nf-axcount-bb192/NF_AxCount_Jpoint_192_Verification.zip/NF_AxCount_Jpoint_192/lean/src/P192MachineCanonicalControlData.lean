module
public import P192MachineCanonicalControlMasks
public meta import P192MachineCanonicalControlMasks


@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P192.CanonicalControl
open Control Frame
theorem checked (pc : Nat) (hi : pc < 3351) : maskCheck pc = true := by
  have all_ok : checkRange 0 3351 = true := by native_decide
  exact checked_in_range all_ok (by omega) (by omega)
theorem data_for (pc : Nat) (hi : pc < 3351) :
    (addressBits pc).length ≤ 44 ∧
    BitsWord.encode (windowWord pc) = pathMask (Source.siteAt pc).address ∧
    (isControl (Source.siteAt pc) = true → Source.destination (targetAddress (Source.siteAt pc)) < 3351) :=
  of_decide_eq_true (checked pc hi)

theorem positive_prefixes : controlCases.all (fun c => decide (0 < c.prefixSteps)) = true := by native_decide

end P192.CanonicalControl
