module
public import C193Cold
public import C193Origin
@[expose] public section
namespace C193.Register
open NF192 NF192.Emitter NF192.Emitter.Registers
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def margin192 : Emitter.Config := ⟨118, mk9 0 0 0 2 0 0 0 1 0⟩
def first192 := Emitter.run frozen 98 origin

theorem frozen_steps192 : first192 = some margin192 := by
  have hp : first192.map Emitter.Config.pc = some margin192.pc := by decide +kernel
  have hr : ∀ i : Fin 9, first192.map (fun c => c.registers i) = some (margin192.registers i) := by
    decide +kernel
  cases h : first192 with
  | none => simp [h] at hp
  | some c =>
    rw [h] at hp
    have reg : c.registers = margin192.registers := by
      funext i
      simpa only [h,Option.map_some,Option.some.injEq] using hr i
    have pc : c.pc = margin192.pc := by simpa only [Option.map_some,Option.some.injEq] using hp
    apply congrArg some
    cases c with
    | mk p rs =>
      change p = 118 at pc
      change rs = _ at reg
      cases pc
      cases reg
      rfl

theorem advance_steps192 : bootstrapAdvance 98 (true,liftConfig origin) = (true,liftConfig margin192) :=
  frozen_run 98 frozen_steps192


end C193.Register
#print axioms C193.Register.advance_steps192
