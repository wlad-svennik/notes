module
public import P192MachineControlKernelArithmetic
public import P192MachineControlKernelContracts
@[expose] public section

/-! The offset-one machine's literal endpoint distinguishes logical zero
(physical value one), logical positive (physical value at least two), and
the blank tail reached by increment. -/

namespace P192.KernelExecute
open NF210 NF210.TM
open CS192.Table (State machine)
open P192.KernelRightShift P192.KernelArithmetic

theorem append_spare_contract :
    WordRun endState KernelReverse.searchState [false, false] [true, false] 0 (-1) 1 := by
  have first : LeftRun endState KernelReverse.searchState [false] [true] :=
    LeftRun.one (by decide)
  simpa using first.asWordRun.context [] [false]

theorem zero_probe_contract :
    WordRun endState KernelReverse.undoState [true, false] [true, false] 0 (-1) 3 := by
  constructor
  · rfl
  · intro a t
    have left : a - 1 = a + (-1) := by omega
    simpa only [Int.add_zero, left] using
      turn_triplet (first := endState) (second := probeState)
        (third := KernelReverse.undoState) (last := KernelReverse.undoState)
        (x := true) (y := false) (u := true) (v := false) (w := true)
        (by decide) (by decide) (by decide) a t

theorem positive_probe_contract :
    WordRun endState KernelReverse.searchState [true, true] [true, true] 0 (-1) 3 := by
  constructor
  · rfl
  · intro a t
    have left : a - 1 = a + (-1) := by omega
    simpa only [Int.add_zero, left] using
      turn_triplet (first := endState) (second := probeState)
        (third := KernelReverse.searchState) (last := KernelReverse.searchState)
        (x := true) (y := true) (u := true) (v := true) (w := true)
        (by decide) (by decide) (by decide) a t

end P192.KernelExecute
