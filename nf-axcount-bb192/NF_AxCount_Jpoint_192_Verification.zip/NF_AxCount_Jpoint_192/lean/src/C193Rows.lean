module
public import C196Rows
public import C193SearchCore
@[expose] public section
namespace C193
open NF192 NF192.Numerical NF192.Emitter
def suffix : List Macro := C196.logicalTokens ++ positiveRowTokens ++ nativeBRowTokens ++ tokens2 ++ tokens3 ++ tokens6 ++ negativeRowTokens ++ tokens4 ++ countingRowTokens ++ tokens9

def batchCode : Code := sequence .read5 suffix

theorem batch_effect (n t stack c u v y delta tail : Nat) :
    suffix.foldl Frame.apply (Frame.apply ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩ .read5) =
      save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (C193.rowList (u+delta) (v+y) c u) := by
  simp only [suffix, List.foldl_append, Frame.apply, Cantor.unpair_pair]
  rw [C196.logicalEffect, positiveRow_effect, nativeBRow_effect, effect2, effect3, effect6, negativeRow_effect, effect4, countingRow_effect, effect9]
  rfl

theorem batch_eval (n t stack c u v y delta tail : Nat) :
    Eval batchCode (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩) .normal
      (save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (C193.rowList (u+delta) (v+y) c u)).regs := by
  rw [← batch_effect n t stack c u v y delta tail]
  exact sequence_eval .read5 suffix _


end C193
