module
public import P192MachinePrepareComplete
public import P192MachineRegisterSelection
public import P192MachineControlKernelArithmetic
public import P192MachineControlCarryCase
@[expose] public section

/-! Complete canonical-to-operation execution for every CI and CD site,
including the displaced 01 decoder return after selection. -/
namespace P192.Ingress
open NF210 NF210.TM CS192.Table P192.KernelRightShift
set_option maxHeartbeats 14000000

def execState (s : Source.Site) : State :=
  if s.op == Source.Primitive.inc then KernelArithmetic.seekState else shiftState

def execWord (f : Frame.Layout) (r : Fin 9) (pad : Nat) : List Bool :=
  Carry.prefixAt f.pc false ++ [false,false] ++ List.replicate (f.gapWidth-1) true ++
    blocks (f.beforeReg r) ++ [false,false] ++ List.replicate (f.storedAt r.val) true ++
    blocks (f.afterReg r) ++ List.replicate pad false

def execConfig (f : Frame.Layout) (r : Fin 9) (pad : Nat) : Configuration 192 :=
  configuration (execState (Source.siteAt f.pc))
    ((f.head-9) + ((Carry.prefixAt f.pc false).length : Int) + 2)
    (wordTape (f.head-9) (execWord f r pad) Frame.blankOutside)

def elapsed (i extra : Nat) (earlier : List Nat) :=
  Prepare.totalTime i extra + RegisterSelection.elapsed i (extra+1) earlier +
    Phase.elapsed i (ArithmeticReturn.nextPhase (Source.siteAt i) true)

theorem elapsed_pos (i extra : Nat) (earlier : List Nat) : 0 < elapsed i extra earlier := by
  simp only [elapsed,Prepare.totalTime,Prepare.prepTime]
  omega

theorem phase2_word (i : Nat) (inside : i < 3351)
    (active : Phase.enabled (Source.siteAt i) 0 = true) (suffix : List Bool) :
    let s := Source.siteAt i
    WordRun decoderRoot (execState s)
      (ArithmeticReturn.stageWord s true ++ suffix) (Carry.prefixAt i false ++ [false,false] ++ suffix)
      (ArithmeticReturn.finalHead s true : Int) (((Carry.prefixAt i false).length : Int)+2)
      (Phase.elapsed i (ArithmeticReturn.nextPhase s true)) := by
  let s := Source.siteAt i
  have a2 : Phase.enabled (Source.siteAt i) 2 = true := by simpa [Phase.enabled] using active
  have last : ((Carry.prefixAt i false).length : Int)+2 = (8 + ((Source.siteAt i).depth : Int)) + 3 := by
    simp [Carry.prefixAt,Carry.before,Frame.addressBits]
    omega
  dsimp only
  rw [last]
  cases option3 : Phase.enabled (Source.siteAt i) 3 with
  | false =>
    have d := (Phase.word_dispatch i 2 inside (by decide) a2).context ArithmeticReturn.guard suffix
    simpa [s,ArithmeticReturn.stageWord,ArithmeticReturn.nextPhase,option3,ArithmeticReturn.guard,
      ArithmeticReturn.finalHead,Phase.inputWord,Phase.outputWord,Phase.initialHead,Phase.finalHead,
      Phase.target,execState,KernelArithmetic.seekState,shiftState,Carry.prefixAt,Carry.before,
      Frame.addressBits,Phase.path,List.append_assoc,Int.add_comm,Int.add_left_comm,Int.add_assoc] using d
  | true =>
    have d := (Phase.word_dispatch i 3 inside (by decide) option3).context ArithmeticReturn.guard suffix
    simpa [s,ArithmeticReturn.stageWord,ArithmeticReturn.nextPhase,option3,ArithmeticReturn.guard,
      ArithmeticReturn.finalHead,Phase.inputWord,Phase.outputWord,Phase.initialHead,Phase.finalHead,
      Phase.target,execState,KernelArithmetic.seekState,shiftState,Carry.prefixAt,Carry.before,
      Frame.addressBits,Phase.path,List.append_assoc,Int.add_comm,Int.add_left_comm,Int.add_assoc] using d

private theorem filled_header (extra : Nat) (xs : List Bool) :
    List.replicate (extra+2) true ++ true :: xs =
      true :: true :: (List.replicate (extra+1) true ++ xs) := by
  change List.replicate (extra+2) true ++ ([true] ++ xs) = _
  rw [← List.append_assoc, ← List.replicate_succ']
  simp [List.replicate_succ]

theorem full_word (i extra : Nat) (earlier : List Nat) (tail : List Bool) (inside : i < 3351)
    (active : Phase.enabled (Source.siteAt i) 0 = true)
    (rank : earlier.length = RegisterSelection.physical (Source.siteAt i).argument) :
    let s := Source.siteAt i
    WordRun decoderRoot (execState s)
      (Prepare.guardedWord s extra (blocks earlier ++ false :: true :: tail) false)
      (Carry.prefixAt i false ++ [false,false] ++ RegisterSelection.payload (extra+1) earlier false tail)
      9 (((Carry.prefixAt i false).length : Int)+2) (elapsed i extra earlier) := by
  let s := Source.siteAt i
  have h := Prepare.prepared_word i extra (blocks earlier ++ false :: true :: tail) inside active
  have equal :
      Prepare.guardedWord s extra (blocks earlier ++ false :: true :: tail) true =
      ArithmeticReturn.stageWord s false ++ RegisterSelection.payload (extra+1) earlier true tail := by
    simp [Prepare.guardedWord,Prepare.frameWord,ArithmeticReturn.stageWord,ArithmeticReturn.guard,
      RegisterSelection.payload,Phase.inputWord,List.append_assoc,filled_header]
  change WordRun _ _ _ (Prepare.guardedWord s extra _ true) _ _ _ at h
  rw [equal] at h
  exact (h.trans (RegisterSelection.full_selection i inside active (extra+1) earlier rank tail)).trans
    (phase2_word i inside active (RegisterSelection.payload (extra+1) earlier false tail))

/-- A complete execution from the actual infinite canonical frame reaches
the operand's physical operation state. Trailing blank padding may be
selected independently by a subsequent word contract. -/
theorem from_canonical (f : Frame.Layout) (r : Fin 9) (pad : Nat) (inside : f.pc < 3351)
    (active : Phase.enabled (Source.siteAt f.pc) 0 = true)
    (room : 2 ≤ f.gapWidth) (reg : r.val = (Source.siteAt f.pc).argument) :
    ∃ t, 0 < t ∧ TM.run machine t f.config = execConfig f r pad := by
  let extra := f.gapWidth-2
  let earlier := f.beforeReg r
  let suffix := List.replicate (f.storedAt r.val) true ++ blocks (f.afterReg r) ++ List.replicate pad false
  let s := Source.siteAt f.pc
  have physical : ∀ v : Fin 9, Frame.registerOrder.idxOf v.val = RegisterSelection.physical v.val := by decide
  have rank : earlier.length = RegisterSelection.physical (Source.siteAt f.pc).argument := by
    rw [←reg]; exact (f.beforeReg_length r).trans (physical r)
  have raw := (full_word f.pc extra earlier suffix inside active rank).exact_run (f.head-9) Frame.blankOutside
  have gap : extra+2 = f.gapWidth := by dsimp [extra]; omega
  have hdr : extra+1 = f.gapWidth-1 := by dsimp [extra]; omega
  have entry :
      wordTape (f.head-9) (Prepare.guardedWord s extra (blocks earlier ++ false::true::suffix) false)
        Frame.blankOutside = f.tape := by
    have h := (f.tape_padded 8 pad).symm
    rw [f.word_split r] at h
    have anchor : f.head-1-8 = f.head-9 := by omega
    change wordTape (f.head-1-8) _ _ = _ at h
    rw [anchor] at h
    simpa [Prepare.guardedWord,Prepare.frameWord,s,earlier,suffix,gap,Frame.Layout.prefix,
      Frame.addressBits,Phase.path,List.replicate_succ,List.append_assoc] using h
  have output : Carry.prefixAt f.pc false ++ [false,false] ++ RegisterSelection.payload (extra+1) earlier false suffix
      = execWord f r pad := by
    simp [execWord,RegisterSelection.payload,earlier,suffix,hdr,List.append_assoc]
  have goal := raw
  change TM.run machine _ (configuration decoderRoot _ _) = configuration _ _ _ at goal
  rw [show f.head-9+9 = f.head by omega,entry,output] at goal
  refine ⟨elapsed f.pc extra earlier,elapsed_pos _ _ _,?_⟩
  simpa [execConfig,Frame.Layout.config,configuration,Int.add_assoc] using goal

#print axioms full_word
#print axioms from_canonical
end P192.Ingress
