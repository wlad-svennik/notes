module
public import P192MachineSource
public meta import P192MachineSource
public import C193Raw
public meta import C193Raw
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P192.Source
/-- Every raw decoded register command is compared to the total CFG used by the logic proof. -/
private theorem agreement : (List.range siteCount).all (fun i => decide (program i = C193.Raw.program i)) = true := by native_decide
theorem eq_raw (pc : Nat) (h : pc < siteCount) : program pc = C193.Raw.program pc := of_decide_eq_true ((List.all_eq_true.mp agreement) pc (List.mem_range.mpr h))
end P192.Source
#print axioms P192.Source.eq_raw
