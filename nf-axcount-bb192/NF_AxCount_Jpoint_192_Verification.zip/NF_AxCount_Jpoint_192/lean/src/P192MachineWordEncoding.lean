module
public import Init

@[expose] public section

namespace P192.BitsWord

/-- The first symbol of the physical tape occupies bit zero. -/
def encode : List Bool → Nat
  | [] => 0
  | b :: bs => b.toNat + 2 * encode bs

end P192.BitsWord
