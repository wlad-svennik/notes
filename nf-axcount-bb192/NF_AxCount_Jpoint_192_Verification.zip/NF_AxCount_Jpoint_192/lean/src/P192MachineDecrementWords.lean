module
public import P192MachineControlKernelExecute
public import P192MachineControlCarryCase

@[expose] public section

namespace P192.Decrement

open NF210 NF210.TM KernelRightShift KernelFiles
set_option maxHeartbeats 0

/-- From the sentinel/address prefix to the entire marked unary file. The final blank
exposes the separator after the last stored register even when there are no spares. -/
def operative (pc headerExtra val : Nat) (earlier following : List Nat) : List Bool :=
  Carry.prefixAt pc false ++ [false,false] ++ shiftInput (headerExtra+1) earlier ++
    List.replicate val true ++ blocks following ++ [false]

/-- The gap and effective header are already in their final positions. -/
def carryInput (pc : Nat) (zero : Bool) (headerExtra : Nat) (vals : List Nat) : List Bool :=
  Carry.initialWord pc zero ++ List.replicate (headerExtra+2) true ++ blocks vals ++ [false]

def executeTime (headerExtra : Nat) (earlier : List Nat) : Nat :=
  (shiftInput (headerExtra+1) earlier).length + 3 +
    ([false,false] ++ shiftOutput (headerExtra+1) earlier).length

def execHead (pc : Nat) : Int := ((Carry.prefixAt pc false).length : Int) + 2

private theorem carry_head (pc : Nat) :
    ((Carry.prefixAt pc false).length : Int) + (-1) = (Carry.startHead pc : Int) := by
  simp [Carry.prefixAt,Carry.startHead,Carry.before]; omega

/-- A positive logical register has stored value k+2. It is decremented once;
the prepared header moves one cell right. Every other block is preserved. -/
theorem positive (pc headerExtra k : Nat) (earlier following : List Nat) :
    WordRun shiftState (Carry.entryState false) (operative pc headerExtra (k+2) earlier following)
      (carryInput pc false headerExtra (earlier ++ (k+1) :: following))
      (execHead pc) (Carry.startHead pc : Int) (executeTime headerExtra earlier) := by
  let tail := List.replicate k true ++ blocks following ++ [false]
  have h := (KernelExecute.positive_decrement_execute headerExtra earlier tail).context
    (Carry.prefixAt pc false) []
  rw [carry_head] at h
  simpa [operative,carryInput,executeTime,execHead,Carry.initialWord,Carry.entryState,
    KernelReverse.searchEndState,shiftOutput,KernelFiles.blocks_append,blocks,tail,
    List.replicate_succ (n := k+1),List.replicate_succ (n := k),List.append_assoc] using h

/-- A zero logical register has stored value 1, represented by two ones. The
reverse shift restores it, all preceding blocks, and the original header. -/
theorem zero (pc headerExtra : Nat) (earlier following : List Nat) :
    WordRun shiftState (Carry.entryState true) (operative pc headerExtra 1 earlier following)
      (carryInput pc true headerExtra (earlier ++ 1 :: following))
      (execHead pc) (Carry.startHead pc : Int) (executeTime headerExtra earlier) := by
  have h := (KernelExecute.zero_decrement_execute headerExtra earlier (terminatedRuns following)).context
    (Carry.prefixAt pc false) []
  rw [carry_head, KernelExecute.undo_file_restored] at h
  simpa [operative,carryInput,executeTime,execHead,Carry.initialWord,Carry.entryState,
    KernelReverse.undoEndState,KernelFiles.blocks_append,blocks,KernelFiles.blocks_terminated,
    List.replicate_succ (n := headerExtra+1),List.append_assoc] using h

theorem carryInput_ready (pc : Nat) (zero : Bool) (headerExtra : Nat) (vals : List Nat) :
    carryInput pc zero headerExtra vals = Carry.ready pc zero (headerExtra+1) ++ terminatedRuns vals := by
  simp [carryInput,Carry.ready,List.append_assoc,KernelFiles.blocks_terminated]

#print axioms positive
#print axioms zero

end P192.Decrement
