module
public import P192MachineWordEncoding
public import MachineBits
public import P192MachineControlKernelWord

@[expose] public section

namespace P192.BitsWord

open NF210.TM P192.KernelRightShift

theorem encode_get (xs : List Bool) (i : Nat) (hi : i < xs.length) :
    (encode xs).testBit i = xs[i] := by
  induction xs generalizing i with
  | nil => simp at hi
  | cons b xs ih =>
    cases i with
    | zero =>
      cases b <;> simp [encode, Nat.testBit_eq_decide_div_mod_eq]
    | succ i =>
      rw [Nat.testBit_succ]
      have h : encode (b :: xs) / 2 = encode xs := by
        cases b <;> simp [encode] <;> omega
      rw [h]
      exact ih i (by simpa using hi)

/-- Bit-mask cylinders and finite-word cylinders denote precisely the same
two-way tape, including all cells outside the displayed word. -/
theorem tape_encode (xs : List Bool) (a : Int) (t : Tape) :
    NF192.KernelBits.tape xs.length a t (encode xs) = wordTape a xs t := by
  funext p
  by_cases h : 0 ≤ p - a ∧ p - a < (xs.length : Int)
  · let i := (p-a).toNat
    have hi : i < xs.length := by dsimp [i]; omega
    have hp : p = a + (i:Int) := by dsimp [i]; omega
    rw [hp, NF192.KernelBits.tape_read _ _ _ hi, wordTape_get _ _ _ _ hi, encode_get xs i hi]
  · rw [wordTape_outside _ _ _ _ (by omega)]
    simp only [NF192.KernelBits.tape, if_neg h]

end P192.BitsWord
