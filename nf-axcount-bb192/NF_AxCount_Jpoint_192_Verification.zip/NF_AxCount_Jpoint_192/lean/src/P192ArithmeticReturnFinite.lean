module
public import P192ArithmeticPhases
public meta import P192ArithmeticPhases

@[expose] public section

namespace P192.ArithmeticReturn
open NF210 NF210.TM

def returnState : CS192.Table.State := 155
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def guard : List Bool := List.replicate 8 false

/-- A completed selection returns to phase 01, possibly at its displaced CD ingress.
Gap preparation returns to the ordinary decoder root for phase 11. -/
def nextPhase (s : Source.Site) (selected : Bool) : Nat :=
  if selected then (if Phase.enabled s 3 then 3 else 2) else 1

def stageWord (s : Source.Site) (selected : Bool) : List Bool :=
  guard ++ Phase.inputWord s (if selected then 2 else 1)

def initialHead (s : Source.Site) (selected : Bool) : Nat := 8 + s.depth + selected.toNat

def finalHead (s : Source.Site) (selected : Bool) : Nat := 8 + Phase.initialHead s (nextPhase s selected)

def duration (s : Source.Site) (selected : Bool) : Nat :=
  if selected then (if Phase.enabled s 3 then 7 else s.depth + 16) else s.depth + 15

abbrev Spec (s : Source.Site) (selected : Bool) : Prop :=
  let word := stageWord s selected
  let bits := BitsWord.encode word
  initialHead s selected < word.length ∧
    NF192.KernelBits.run CS192.Table.machine word.length (duration s selected)
      ⟨some returnState, initialHead s selected, bits⟩ =
        some ⟨some CS192.Table.decoderRoot, finalHead s selected, bits⟩

def check (i : Nat) : Bool :=
  let s := Source.siteAt i
  if Phase.enabled s 0 then decide (s.argument < 9 ∧ Spec s false ∧ Spec s true) else true

def checkRange (lo size : Nat) : Bool := (List.range size).all fun j => check (lo+j)

theorem checked_in_range {lo size i : Nat} (ok : checkRange lo size = true)
    (lower : lo ≤ i) (upper : i < lo+size) : check i = true := by
  have h := List.all_eq_true.mp ok (i-lo) (List.mem_range.mpr (by omega))
  simpa only [show lo+(i-lo) = i by omega] using h

theorem things_checked {i : Nat} (active : Phase.enabled (Source.siteAt i) 0 = true)
    (ok : check i = true) : let s := Source.siteAt i
    s.argument < 9 ∧ Spec s false ∧ Spec s true :=
  of_decide_eq_true (by simpa only [check, active, ite_true] using ok)


theorem all_checked (i : Nat) (hi : i < 3351) : check i = true := by
  have done : checkRange 0 3351 = true := by native_decide
  exact checked_in_range done (by omega) hi

theorem all_finite_returns (i : Nat) (hi : i < 3351)
    (active : Phase.enabled (Source.siteAt i) 0 = true) :
    (Source.siteAt i).argument < 9 ∧ Spec (Source.siteAt i) false ∧ Spec (Source.siteAt i) true :=
  things_checked active (all_checked i hi)

#print axioms all_finite_returns
end P192.ArithmeticReturn
