module
public import P192ArithmeticPhases
public meta import P192ArithmeticPhases
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P192.Phase
open NF210 NF210.TM
theorem all_checked (i ph : Nat) (hi : i < 3351) (hp : ph < 4) : checkOne i ph = true := by
  have checked : checkRange 0 3351 = true := by native_decide
  exact checked_in_range checked (by omega) (by omega) hp
/-- Every active arithmetic decoder phase is a literal run on every
two-sided tape with the stated finite prefix at any origin. -/
theorem all_arithmetic_dispatch (i ph : Nat) (hi : i < 3351) (hp : ph < 4)
    (active : enabled (Source.siteAt i) ph = true) (anchor : Int) (outside : Tape) (endBit : Bool := false) :
    let s := Source.siteAt i
    TM.run CS192.Table.machine (elapsed i ph) (NF192.KernelBits.embed (width s) anchor outside (entry s ph endBit)) =
      NF192.KernelBits.embed (width s) anchor outside (finish s ph endBit) :=
  dispatch_of_checked active (all_checked i ph hi hp) anchor outside endBit

end P192.Phase

#print axioms P192.Phase.all_arithmetic_dispatch
