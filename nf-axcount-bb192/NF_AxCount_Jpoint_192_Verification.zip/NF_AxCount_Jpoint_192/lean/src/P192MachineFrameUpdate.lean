module
public import P192MachineFrameWords

@[expose] public section

/-! Changing one source register changes exactly the corresponding physical
unary block, and newly appended spare blocks are always at the far right. -/
namespace P192.Frame

def Layout.updateStored (f : Layout) (r : Fin 9) (value : Nat) (more : List Nat) : Layout :=
  {f with stored := f.stored.setIfInBounds r.val value, spares := f.spares ++ more}

theorem Layout.updated_size (f : Layout) (r : Fin 9) (v : Nat) (more : List Nat) :
    (f.updateStored r v more).stored.size = f.stored.size := Array.size_setIfInBounds

theorem Layout.updated_self (f : Layout) (r : Fin 9) (v : Nat) (more : List Nat)
    (size : f.stored.size = 9) : (f.updateStored r v more).storedAt r.val = v := by
  simp only [Layout.updateStored,Layout.storedAt,
    Array.getElem?_setIfInBounds_self_of_lt (a := v) (by rw [size]; exact r.isLt), Option.getD_some]

theorem Layout.updated_other (f : Layout) (r : Fin 9) (v : Nat) (more : List Nat)
    (j : Nat) (h : r.val ≠ j) :
    (f.updateStored r v more).storedAt j = f.storedAt j := by
  simp only [Layout.updateStored,Layout.storedAt,Array.getElem?_setIfInBounds_ne h]

private theorem unique_rank (r : Fin 9) :
    let k := registerOrder.idxOf r.val
    r.val ∉ registerOrder.take k ∧ r.val ∉ registerOrder.drop (k+1) := by
  have all : ∀ r : Fin 9, r.val ∉ registerOrder.take (registerOrder.idxOf r.val) ∧
      r.val ∉ registerOrder.drop (registerOrder.idxOf r.val+1) := by decide
  exact all r

theorem Layout.beforeReg_keys (f : Layout) (r : Fin 9) :
    f.beforeReg r = (registerOrder.take (registerOrder.idxOf r.val)).map f.storedAt := by
  have h : registerOrder.idxOf r.val < registerOrder.length := (physical_rank r).1
  simp only [Layout.beforeReg,Layout.values, List.map_take]
  exact List.take_append_of_le_length (by simpa only [List.length_map] using Nat.le_of_lt h)

theorem Layout.afterReg_keys (f : Layout) (r : Fin 9) :
    f.afterReg r = (registerOrder.drop (registerOrder.idxOf r.val+1)).map f.storedAt ++ f.spares := by
  have h : registerOrder.idxOf r.val < registerOrder.length := (physical_rank r).1
  simp only [Layout.afterReg,Layout.values, List.map_drop]
  exact List.drop_append_of_le_length (by simp only [List.length_map]; omega)

private theorem map_update_away (f : Layout) (r : Fin 9) (v : Nat) (more keys : List Nat)
    (different : r.val ∉ keys) :
    keys.map (f.updateStored r v more).storedAt = keys.map f.storedAt := by
  apply List.map_congr_left
  intro j hj
  apply f.updated_other
  rintro rfl
  exact different hj

theorem Layout.updateBefore (f : Layout) (r : Fin 9) (v : Nat) (more : List Nat) :
    (f.updateStored r v more).beforeReg r = f.beforeReg r := by
  rw [Layout.beforeReg_keys, Layout.beforeReg_keys]
  exact map_update_away f r v more _ (unique_rank r).1

theorem Layout.updateAfter (f : Layout) (r : Fin 9) (v : Nat) (more : List Nat) :
    (f.updateStored r v more).afterReg r = f.afterReg r ++ more := by
  rw [Layout.afterReg_keys, Layout.afterReg_keys,
    map_update_away f r v more _ (unique_rank r).2, List.append_assoc]
  rfl

theorem Layout.updateValues (f : Layout) (r : Fin 9) (v : Nat) (more : List Nat)
    (size : f.stored.size = 9) :
    (f.updateStored r v more).values = f.beforeReg r ++ v :: (f.afterReg r ++ more) := by
  rw [(f.updateStored r v more).values_split r, f.updated_self r v more size,
    f.updateBefore, f.updateAfter]

end P192.Frame
