module
public import P192MachineCanonicalControlData
public import P192MachineFrameWords

@[expose] public section

namespace P192.CanonicalControl

open NF210 NF210.TM P192.Control P192.Frame P192.KernelRightShift

set_option maxHeartbeats 0
set_option maxRecDepth 100000

def fileTape (f : Layout) : Tape :=
  wordTape f.header (true :: blocks f.values) blankOutside

theorem file_header (f : Layout) : fileTape f f.header = true := by
  simp [fileTape]

theorem file_first_separator (f : Layout) : fileTape f (f.header+1) = false := by
  unfold fileTape
  rw [wordTape_cons,writeTape_away _ _ _ _ (by omega)]
  change wordTape (f.header+1) (false :: _) blankOutside (f.header+1) = false
  simp

theorem file_before (f : Layout) (p : Int) (h : p < f.header) : fileTape f p = false :=
  wordTape_outside _ _ _ blankOutside (Or.inl h)

theorem zeros_before (a : Int) (n : Nat) (payload : List Bool) :
    wordTape a (List.replicate n false)
      (wordTape (a + (n:Int)) payload blankOutside) =
    wordTape (a + (n:Int)) payload blankOutside := by
  rw [wordTape_commute _ _ _ _ blankOutside (by simp),blank_run]

theorem canonical_window (f : Layout) (hi : f.pc < 3351) (room : 45 ≤ f.gap) :
    f.config = rootWindow (f.head-9) (fileTape f) (pathMask (Source.siteAt f.pc).address) := by
  obtain ⟨depth,mask,_⟩ := data_for f.pc hi
  have len : (windowWord f.pc).length = width := by
    simp only [windowWord,List.length_append,List.length_replicate,List.length_cons]
    unfold width
    omega
  have splitGap : f.gapWidth = (45-(addressBits f.pc).length)+(f.gap-45) := by
    unfold Layout.gapWidth
    omega
  have words :
      List.replicate 8 false ++ f.word =
        windowWord f.pc ++ (List.replicate (f.gap-45) false ++ (true :: blocks f.values)) := by
    rw [f.word_kernel,splitGap,← List.replicate_append_replicate]
    simp only [windowWord,Layout.prefix,List.append_assoc]
  have tapeEq : f.tape = NF192.KernelBits.tape width (f.head-9) (fileTape f) (pathMask (Source.siteAt f.pc).address) := by
    rw [← mask,← len,BitsWord.tape_encode,f.tape_padded 8 0]
    simp only [List.replicate_zero,List.append_nil,show f.head-1-(8:Nat) = f.head-9 by omega,words]
    rw [wordTape_append,wordTape_append,len]
    have a : f.head-9+(width:Nat)+(List.replicate (f.gap-45) false).length = f.header := by
      simp only [List.length_replicate,Layout.header]
      unfold width
      omega
    change wordTape (f.head-9) (windowWord f.pc)
      (wordTape (f.head-9+(width:Nat)) (List.replicate (f.gap-45) false)
        (wordTape (f.head-9+(width:Nat)+((List.replicate (f.gap-45) false).length : Int))
          (true :: blocks f.values) blankOutside)) = _
    simp only [List.length_replicate] at a ⊢
    rw [zeros_before,a]
    rfl
  change Configuration.mk (some CS192.Table.decoderRoot) f.head f.tape =
    Configuration.mk (some 13) (f.head-9+(9:Nat)) _
  rw [tapeEq, show f.head-9+(9:Nat) = f.head by omega]
  rfl

theorem case_positive {c : Case} (pre : 0 < c.prefixSteps) (ok : verified c = true)
    (anchor header : Int) (outside : Tape)
    (space : anchor + (width:Int) < header) (head1 : outside header = true)
    (head0 : outside (header+1) = false)
    (gap : ∀ p, anchor + (width:Int) ≤ p → p < header → outside p = false) :
    ∃ d, 0 < d ∧ run CS192.Table.machine d (rootWindow anchor outside c.input) =
      rootWindow anchor outside c.output := by
  have runOK := (Bool.and_eq_true_iff.mp (Bool.and_eq_true_iff.mp ok).1).1
  cases h : c.isBranch with
  | false => exact ⟨_,pre,cont_semantics h runOK anchor outside⟩
  | true => exact ⟨_,by omega,branch_semantics literalRows h runOK anchor header outside space head1 head0 gap⟩

/-- Every jump has a strictly positive run between canonical source frames,
preserving the register payload, position, gap, and all spare slots. -/
theorem control_step (f : Layout) (hi : f.pc < 3351) (room : 46 ≤ f.gap)
    (active : isControl (Source.siteAt f.pc) = true) :
    ∃ next ticks, next < 3351 ∧ Source.program f.pc = Source.Command.jump next ∧ 0 < ticks ∧
      run CS192.Table.machine ticks f.config = ({f with pc := next} : Layout).config := by
  let s := Source.siteAt f.pc
  let next := Source.destination (targetAddress s)
  let out : Layout := { f with pc := next }
  have hn : next < 3351 := (data_for f.pc hi).2.2 active
  have mem : f.pc ∈ controlCases.map Case.pc := by
    rw [coverage]
    exact List.mem_filter.mpr ⟨List.mem_range.mpr hi,active⟩
  obtain ⟨c,inc,hpc⟩ := List.mem_map.mp mem
  have ok := List.all_eq_true.mp cases_verified _ inc
  obtain ⟨localOK,goalOK⟩ := Bool.and_eq_true_iff.mp ok
  have agree := of_decide_eq_true (Bool.and_eq_true_iff.mp localOK).2
  obtain ⟨_,_,source,_⟩ := agree
  have src : c.input = pathMask s.address := by simpa only [hpc,s] using source
  have dest : c.output = pathMask (Source.siteAt next).address := by
    simpa only [destinationMatches,beq_iff_eq,hpc,next,s] using goalOK
  have pre := of_decide_eq_true (List.all_eq_true.mp positive_prefixes _ inc)
  have room' : f.head-9+(width:Nat) < f.header := by unfold width Layout.header; omega
  obtain ⟨ticks,pos,step⟩ := case_positive pre ok (f.head-9) f.header (fileTape f) room'
    (file_header f) (file_first_separator f) (fun p _ h => file_before f p h)
  have bound : f.pc < Source.siteCount := hi
  have op : s.op = 2 ∨ s.op = 3 := by
    change ((s.op == 2) || (s.op == 3)) = true at active
    simpa only [Bool.or_eq_true,beq_iff_eq] using active
  have jump : Source.program f.pc = Source.Command.jump next := by
    simp only [Source.program,ite_eq_left bound]
    change Source.decode s = Source.Command.jump (Source.destination (targetAddress s))
    rcases op with h | h <;> simp [Source.decode,targetAddress,h,Source.Primitive.inc,Source.Primitive.dec,Source.Primitive.brk]
  refine ⟨next,ticks,hn,jump,pos,?_⟩
  rw [canonical_window f hi (by omega),canonical_window out hn (by change 45 ≤ f.gap; omega)]
  have hf : fileTape out = fileTape f := rfl
  rw [hf]
  simpa only [src,dest,out,s] using step

end P192.CanonicalControl

#print axioms P192.CanonicalControl.control_step
