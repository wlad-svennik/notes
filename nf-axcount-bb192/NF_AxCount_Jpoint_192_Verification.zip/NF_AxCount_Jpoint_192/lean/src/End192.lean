module
public import C192PhysicalProtocol
public import Table192
public import Margin192
@[expose] public section
namespace CS192
open NF192 NF210 C192 C192.Physical C193.Register
def PhysicalRealization := Realizes Table.machine Table.start 58195 (true,Emitter.liftConfig margin192)
theorem blank_iff_origin (h : PhysicalRealization) :
    TM.Halts Table.machine Table.start ↔ BootstrapHalts (true, Emitter.liftConfig origin) :=
  common_margin_origin advance_steps192 h
end CS192
#print axioms CS192.blank_iff_origin
