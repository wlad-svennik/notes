module
public import P192MachineControlCases
public import Table192
public import P192MachineSource

@[expose] public section

/-! Relate each checked finite tape mask to its source address. The
sentinel is bit 8, and the path starts at bit 9. -/

namespace P192.Control
open NF210 NF210.TM

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem literalRows : ScannerRows CS192.Table.machine where
  seekZero := rfl
  seekOne := rfl
  header := rfl
  restore := rfl
  retreat := rfl
  pivotZero := rfl
  pivotOne := rfl
  eraseZero := rfl
  eraseOne := rfl

theorem literal_scan_gap (t : Tape) (first last header : Int)
    (h₁ : last < first) (h₂ : first ≤ header) (sp : last+1 < header)
    (atLast : t last = true) (atHeader : t header = true)
    (afterHeader : t (header+1) = false) (gap : ∀ p, last < p → p < header → t p = false) :
    run CS192.Table.machine ((header-first).toNat + 3 + 3*((header-last-2).toNat+1))
      (cfg 174 first t) = cfg 155 last t :=
  literalRows.scan_gap t first last header h₁ h₂ sp atLast atHeader afterHeader gap

/-- Translate a sentinel-prefixed source address to the binary tape window. -/
def pathMask (address : Nat) : Nat :=
  let rev := (List.range address.log2).foldl
    (fun acc j => 2*acc + (if address.testBit j then 1 else 0)) 0
  2^8 + 2^9 * rev

def isControl (s : Source.Site) : Bool := s.op == 2 || s.op == 3

def targetAddress (s : Source.Site) : Nat :=
  if s.op == 2 then Source.plus (Source.cut false s.argument s.address)
  else Source.cut true s.argument s.address

/-- All finite-run claims are checked separately from these syntactic
bindings to the selected 3,089 source sites. -/
def sourceMatches (c : Case) : Bool :=
  let s := Source.siteAt c.pc
  decide (isControl s = true ∧ c.isBranch = (s.op == 2) ∧
    c.input = pathMask s.address ∧ c.output = pathMask (targetAddress s))

/-- The destination selected by the source decoder is a full leaf; the suffix
added after the target prefix consists of zero bits and has the same tape mask. -/
def destinationMatches (c : Case) : Bool :=
  let s := Source.siteAt c.pc
  c.output == pathMask (Source.siteAt (Source.destination (targetAddress s))).address

def verified (c : Case) : Bool := (passes CS192.Table.machine c && sourceMatches c) && destinationMatches c

theorem case_correct {c : Case} (ok : verified c = true)
    (anchor header : Int) (outside : Tape)
    (space : anchor + (width:Int) < header) (head1 : outside header = true)
    (head0 : outside (header+1) = false)
    (gap : ∀ p, anchor + (width:Int) ≤ p → p < header → outside p = false) :
    ∃ duration, run CS192.Table.machine duration
      (rootWindow anchor outside (pathMask (Source.siteAt c.pc).address)) =
      rootWindow anchor outside (pathMask (targetAddress (Source.siteAt c.pc))) := by
  obtain ⟨localOK, _⟩ := Bool.and_eq_true_iff.mp ok
  obtain ⟨runOK, agrees⟩ := Bool.and_eq_true_iff.mp localOK
  have h := of_decide_eq_true agrees
  obtain ⟨_, _, source, target⟩ := h
  rw [← source, ← target]
  cases mode : c.isBranch with
  | false => exact ⟨_, cont_semantics mode runOK anchor outside⟩
  | true => exact ⟨_, branch_semantics literalRows mode runOK anchor header outside space head1 head0 gap⟩


theorem case_source_step {c : Case} (hi : c.pc < 3351) (ok : verified c = true)
    (anchor header : Int) (outside : Tape) (space : anchor + (width:Int) < header)
    (head1 : outside header = true) (head0 : outside (header+1) = false)
    (gap : ∀ p, anchor+(width:Int) ≤ p → p < header → outside p = false) :
    ∃ next duration, Source.program c.pc = Source.Command.jump next ∧
      run CS192.Table.machine duration (rootWindow anchor outside (pathMask (Source.siteAt c.pc).address)) =
        rootWindow anchor outside (pathMask (Source.siteAt next).address) := by
  obtain ⟨localOK, destinationOK⟩ := Bool.and_eq_true_iff.mp ok
  obtain ⟨_, agrees⟩ := Bool.and_eq_true_iff.mp localOK
  obtain ⟨eligible, _, _, outEq⟩ := of_decide_eq_true agrees
  have nextEq : c.output = pathMask (Source.siteAt (Source.destination
      (targetAddress (Source.siteAt c.pc)))).address :=
    beq_iff_eq.mp destinationOK
  let s := Source.siteAt c.pc
  let next := Source.destination (targetAddress s)
  have mode : s.op = 2 ∨ s.op = 3 := by
    change ((s.op == 2) || (s.op == 3)) = true at eligible
    simpa only [Bool.or_eq_true, beq_iff_eq] using eligible
  have jump : Source.program c.pc = Source.Command.jump next := by
    have hpc : c.pc < Source.siteCount := hi
    simp only [Source.program, ite_eq_left hpc]
    change Source.decode s = Source.Command.jump (Source.destination (targetAddress s))
    rcases mode with op | op <;> simp [Source.decode, targetAddress, op, Source.Primitive.inc,
      Source.Primitive.dec, Source.Primitive.brk]
  obtain ⟨d, hd⟩ := case_correct ok anchor header outside space head1 head0 gap
  exact ⟨next, d, jump, hd.trans (congrArg (rootWindow anchor outside) (outEq.symm.trans nextEq))⟩

end P192.Control
