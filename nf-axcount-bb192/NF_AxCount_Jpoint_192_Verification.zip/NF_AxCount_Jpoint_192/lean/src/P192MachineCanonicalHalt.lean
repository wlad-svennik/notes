module
public import P192MachineHaltWord
public import P192MachineIngress

@[expose] public section
set_option maxRecDepth 200000

/-! Full canonical-frame halt at the selected countdown machine's unique
odd decrement, including unbounded source fields, decoder preparation,
register selection, operand shift, undo and final literal halt transition. -/

namespace P192.HaltGate
open NF210 NF210.TM CS192.Table KernelRightShift

set_option maxHeartbeats 0

theorem from_canonical_3334 (f : Frame.Layout) (pc : f.pc = 3334)
    (zero : f.storedAt 5 = 1) (room : 2 ≤ f.gapWidth) :
    ∃ t, 0 < t ∧ (TM.run machine t f.config).state = none := by
  let r : Fin 9 := 5
  have inside : f.pc < 3351 := pc ▸ (by decide)
  have enabled : Phase.enabled (Source.siteAt f.pc) 0 = true := pc ▸ (by decide)
  have arg : r.val = (Source.siteAt f.pc).argument := pc ▸ (by decide)
  obtain ⟨t,positive,ingress⟩ := Ingress.from_canonical f r 1 inside enabled room arg
  let earlier := f.beforeReg r
  let later := f.afterReg r
  let gap := f.gapWidth-2
  have gapEq : gap+1 = f.gapWidth-1 := by dsimp [gap]; omega
  have stored : f.storedAt r.val = 1 := zero
  have word : Ingress.execWord f r 1 = Decrement.operative 3334 gap 1 earlier later := by
    simp only [Ingress.execWord, Decrement.operative, shiftInput, pc, gapEq, stored,
      List.replicate_one, earlier, later, List.append_assoc]
  have state : Ingress.execState (Source.siteAt f.pc) = shiftState := pc ▸ (by decide)
  have h := odd_operand_halts gap earlier later (f.head-9) Frame.blankOutside
  refine ⟨t+(zeroTime gap earlier+1),by omega,?_⟩
  rw [TM.run_add,ingress]
  unfold Ingress.execConfig
  rw [state,word,pc]
  exact h

end P192.HaltGate

namespace P192.Frame
open NF210 NF210.TM

/-- Source odd zero-decrement realizes a positive number of actual steps
ending in HALT on arbitrary register contents and spare-field lengths. -/
theorem Layout.decrement_halt_step (f : Layout) (r : Fin 9) (inside : f.pc < 3351)
    (dec : (Source.siteAt f.pc).op = Source.Primitive.dec)
    (arg : r.val = (Source.siteAt f.pc).argument)
    (odd : (Source.siteAt f.pc).address % 2 = 1)
    (zero : f.storedAt r.val = 1) (room : 2 ≤ f.gapWidth) :
    ∃ t, 0 < t ∧ (TM.run CS192.Table.machine t f.config).state = none := by
  have pc := (HaltGate.address_bit_iff f.pc inside dec).1 (by simp [odd])
  have reg : r.val = 5 := arg.trans (pc ▸ (by decide))
  rw [reg] at zero
  exact HaltGate.from_canonical_3334 f pc zero room

#print axioms Layout.decrement_halt_step
end P192.Frame
