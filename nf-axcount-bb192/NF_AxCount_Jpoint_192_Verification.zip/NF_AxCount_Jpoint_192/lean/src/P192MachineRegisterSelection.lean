module
public import P192ArithmeticPhaseWords
public import P192MachineArithmeticReturnComplete

@[expose] public section

/-! Selecting a register on the prepared production tape, from one decoder entry to the next.
The first phase bit and the first unit of the selected register are the two bits cleared. -/
namespace P192.RegisterSelection

open NF210 NF210.TM P192.KernelRightShift P192.KernelSelectors
open P192.ArithmeticReturn (stageWord)
set_option maxHeartbeats 0

/-- Physical position in the left-to-right order [R2,R8,R1,R4,R3,R7,R0,R5,R6]. -/
def physical (reg : Nat) : Nat := (#[6,2,0,4,3,7,8,5,1] : Array Nat)[reg]?.getD 9

theorem physical_spec (reg : Nat) (inside : reg < 9) :
    Phase.selector reg = selectorState (physical reg) ∧ physical reg < 9 := by
  have checked : ∀ r : Fin 9, Phase.selector r = selectorState (physical r) ∧ physical r < 9 := by
    decide
  exact checked ⟨reg, inside⟩

/-- Cells following the two phase bits, with the selected block's first unit exposed. -/
def payload (extra : Nat) (earlier : List Nat) (selectedUnit : Bool) (tail : List Bool) : List Bool :=
  List.replicate extra true ++ blocks earlier ++ false :: selectedUnit :: tail

def elapsed (i extra : Nat) (earlier : List Nat) : Nat :=
  let walked := selectionInput (extra+1) earlier
  Phase.elapsed i 1 + (walked.length + 1 + walked.length) +
    ArithmeticReturn.duration (Source.siteAt i) true

/-- The register index is the argument read at this literal source PC. `tail` includes
all remaining units and every subsequent block. No bound is imposed on that suffix,
on the prepared gap, or on any value passed by the selector. -/
theorem full_selection (i : Nat) (inside : i < 3351)
    (active : Phase.enabled (Source.siteAt i) 0 = true)
    (extra : Nat) (earlier : List Nat)
    (rank : earlier.length = physical (Source.siteAt i).argument) (tail : List Bool) :
    let s := Source.siteAt i
    WordRun CS192.Table.decoderRoot CS192.Table.decoderRoot
      (stageWord s false ++ payload extra earlier true tail)
      (stageWord s true ++ payload extra earlier false tail)
      9 (ArithmeticReturn.finalHead s true : Int) (elapsed i extra earlier) := by
  let s := Source.siteAt i
  let front := ArithmeticReturn.guard ++ (true :: Phase.path s) ++ [false]
  have active1 : Phase.enabled s 1 = true := by simpa [s,Phase.enabled] using active
  have ok := ArithmeticReturn.things_checked active (ArithmeticReturn.all_checked i inside)
  have phys := physical_spec s.argument ok.1
  have selected : Phase.selector s.argument = selectorState earlier.length := by rw [rank]; exact phys.1
  have rankOk : earlier.length < 9 := by rw [rank]; exact phys.2
  have forwardRaw := (Phase.word_dispatch i 1 inside (by decide) active1).context ArithmeticReturn.guard
    (payload extra earlier true tail)
  have forward : WordRun CS192.Table.decoderRoot (selectorState earlier.length)
      (stageWord s false ++ payload extra earlier true tail)
      (stageWord s true ++ payload extra earlier true tail)
      9 ((s.depth : Int) + 10) (Phase.elapsed i 1) := by
    rw [← selected]
    change WordRun CS192.Table.decoderRoot (Phase.selector s.argument) _ _ _ _ _ at forwardRaw
    have headEq : 2 + (8 + ((Source.siteAt i).depth : Int)) = 10 + (Source.siteAt i).depth := by omega
    simpa [headEq,stageWord,Phase.initialHead,Phase.finalHead,Phase.inputWord,Phase.outputWord,ArithmeticReturn.guard,s,
      Int.add_assoc,Int.add_comm,Int.add_left_comm] using forwardRaw
  have frontLen : (front.length : Int) = s.depth + 10 := by simp [front,ArithmeticReturn.guard]; omega
  have wordEq (b : Bool) :
      front ++ (selectionInput (extra+1) earlier ++ b :: tail) ++ [] =
        stageWord s true ++ payload extra earlier b tail := by
    simp [front, selectionInput, stageWord, Phase.inputWord, payload, List.replicate_succ,
      List.append_assoc]
  have markRaw := (SelectorRoundtrip.select_mark_and_rewind extra earlier rankOk tail).context front []
  rw [wordEq true, wordEq false, frontLen] at markRaw
  have mark : WordRun (selectorState earlier.length) returnState
      (stageWord s true ++ payload extra earlier true tail)
      (stageWord s true ++ payload extra earlier false tail)
      ((s.depth : Int) + 10) (ArithmeticReturn.initialHead s true : Int)
      ((selectionInput (extra+1) earlier).length + 1 + (selectionInput (extra+1) earlier).length) := by
    have endpoint : (s.depth : Int) + 10 + (-1) = (ArithmeticReturn.initialHead s true : Int) := by
      simp [ArithmeticReturn.initialHead]; omega
    simpa only [Int.add_zero,endpoint] using markRaw
  have backRaw := (ArithmeticReturn.all_returns i inside active true).context []
    (payload extra earlier false tail)
  have back : WordRun returnState CS192.Table.decoderRoot
      (stageWord s true ++ payload extra earlier false tail)
      (stageWord s true ++ payload extra earlier false tail)
      (ArithmeticReturn.initialHead s true : Int) (ArithmeticReturn.finalHead s true : Int)
      (ArithmeticReturn.duration s true) := by simpa using backRaw
  exact (forward.trans mark).trans back

#print axioms full_selection

end P192.RegisterSelection
