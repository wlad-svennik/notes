module
public import Boot192
public import MachineFrame
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace CS192.Calibration
open NF192 NF210
structure Layout where
  head : Int
  address : List Bool
  gap : Nat
  registers : List Nat
  spares : List Nat

def Layout.word (f : Layout) : List Bool :=
  (true :: f.address) ++ List.replicate (f.gap-f.address.length) false ++
    (true :: ((Frame.registerOrder.map (fun r => f.registers[r]?.getD 0)) ++ f.spares).flatMap Frame.field)
def Layout.config (f : Layout) : TM.Configuration 192 :=
  ⟨some Table.decoderRoot,f.head,Frame.cells (f.head-1) f.word⟩

theorem snapshot_eq (sn : KernelBits.Configuration 192) (f : Layout)
    (hs : sn.state = some Table.decoderRoot) (hh : (-10 : Int) + (sn.head : Int) = f.head)
    (lo : -10 ≤ f.head-1) (hi : f.head-1+(f.word.length : Int) ≤ -10+(Boot.width : Int))
    (hword : ∀ i : Fin Boot.width, sn.bits.testBit i = Frame.cells (f.head-1) f.word (-10+(i.val:Int))) :
    KernelBits.embed Boot.width (-10) (fun _ => false) sn = f.config := by
  have ht := Frame.packed_eq_cells lo hi hword
  change TM.Configuration.mk sn.state ((-10:Int)+(sn.head:Int)) _ = TM.Configuration.mk (some Table.decoderRoot) f.head _
  rw [hs,hh,ht]
def firstAX : Layout := ⟨-1, [true, false, true, false, true, false, false, false, false], 32, [0, 1, 1, 3, 1, 1, 1, 1, 1], List.replicate 12 0⟩
theorem firstAX_frame : TM.run Table.machine 16817 (TM.blank Table.start) = firstAX.config := by
  rw [CS192.Boot.blank_first_ax]
  apply snapshot_eq <;> decide +kernel
#print axioms firstAX_frame
def safe : Layout := ⟨-1, [true, false, true, false, true, false, true, false, false, true, false, true, false, true, true, false, false, true, false], 55, [0, 1, 1, 3, 1, 1, 1, 2, 1], List.replicate 36 0⟩
theorem safe_frame : TM.run Table.machine 58195 (TM.blank Table.start) = safe.config := by
  rw [CS192.Boot.blank_safe_gap]
  apply snapshot_eq <;> decide +kernel
#print axioms safe_frame
end CS192.Calibration
