module
public import P192MachineArithmeticReturns
public meta import P192MachineArithmeticReturns
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P192.ArithmeticReturn
open P192.KernelRightShift P192.KernelSelectors
theorem all_returns (i : Nat) (inside : i < 3351)
    (active : Phase.enabled (Source.siteAt i) 0 = true) (selected : Bool) :
    let s := Source.siteAt i
    let w := stageWord s selected
    KernelRightShift.WordRun KernelSelectors.returnState CS192.Table.decoderRoot w w
      (initialHead s selected : Int) (finalHead s selected : Int) (duration s selected) := by
  apply checked_return
  have ok := things_checked active (all_checked i inside)
  cases selected
  · exact ok.2.1
  · exact ok.2.2

#print axioms all_returns

end P192.ArithmeticReturn
