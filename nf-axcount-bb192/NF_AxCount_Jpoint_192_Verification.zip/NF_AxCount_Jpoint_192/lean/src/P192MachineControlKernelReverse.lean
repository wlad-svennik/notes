module
public import P192MachineControlKernelLeft

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-!
# Unbounded reverse shift and reverse delimiter search

These are sections 4.2 and 4.3 of the arithmetic kernel proof, checked against
the selected 192-state rows. Each routine crosses arbitrary positive unary runs and
an arbitrary number of register blocks, stopping at the leading double zero.
`values` are listed in the order encountered from the right; reversing the
displayed right-shift words expresses the actual physical tape order.
-/

namespace P192.KernelReverse

open NF210 NF210.TM
open CS192.Table (State machine)
open P192.KernelRightShift

def undoState : State := ⟨182, by decide⟩
def undoPairState : State := ⟨152, by decide⟩
def undoEndState : State := ⟨161, by decide⟩
def searchState : State := ⟨172, by decide⟩
def searchPairState : State := ⟨167, by decide⟩
def searchEndState : State := ⟨166, by decide⟩

theorem state_names :
    CS192.Table.name undoState = "k:97" ∧
    CS192.Table.name undoPairState = "k:113" ∧
    CS192.Table.name undoEndState = "k:302" ∧
    CS192.Table.name searchState = "k:54" ∧
    CS192.Table.name searchPairState = "k:40" ∧
    CS192.Table.name searchEndState = "k:4" := by decide

theorem undo_ones (count : Nat) :
    LeftRun undoState undoState (List.replicate count true) (List.replicate count true) :=
  (LeftRun.one (by decide)).repeat count

theorem undo_one_zero : LeftRun undoState undoState [true, false] [false, true] := by
  have right : LeftRun undoState undoPairState [false] [true] := LeftRun.one (by decide)
  have left : LeftRun undoPairState undoState [true] [false] := LeftRun.one (by decide)
  exact right.trans left

theorem undo_zero_zero : LeftRun undoState undoEndState [false, false] [false, true] := by
  have right : LeftRun undoState undoPairState [false] [true] := LeftRun.one (by decide)
  have left : LeftRun undoPairState undoEndState [false] [false] := LeftRun.one (by decide)
  exact right.trans left

/-- Exact reverse shift for unbounded unary runs and register lists. -/
theorem undo_shift (initialRun : Nat) (values : List Nat) :
    LeftRun undoState undoEndState
      (shiftInput initialRun values).reverse (shiftOutput initialRun values).reverse := by
  induction values generalizing initialRun with
  | nil =>
    have certificate := (undo_ones initialRun).trans undo_zero_zero
    simp only [shiftInput, shiftOutput, blocks, List.reverse_append, List.reverse_cons,
      List.reverse_nil, List.reverse_replicate, List.append_assoc, List.nil_append,
      List.cons_append] at certificate ⊢
    simpa only [List.replicate_succ, List.nil_append, List.cons_append] using certificate
  | cons value rest ih =>
    have certificate := (undo_ones initialRun).trans (undo_one_zero.trans (ih value))
    simp only [shiftInput, shiftOutput, blocks, List.reverse_append, List.reverse_cons,
      List.reverse_nil, List.reverse_replicate, List.append_assoc, List.nil_append,
      List.cons_append] at certificate ⊢
    simpa only [List.replicate_succ (n := initialRun), List.replicate_succ' (n := value),
      List.append_assoc, List.nil_append, List.cons_append] using certificate

theorem search_ones (count : Nat) :
    LeftRun searchState searchState (List.replicate count true) (List.replicate count true) :=
  (LeftRun.one (by decide)).repeat count

theorem search_one_zero : LeftRun searchState searchState [true, false] [true, false] := by
  have right : LeftRun searchState searchPairState [false] [false] := LeftRun.one (by decide)
  have left : LeftRun searchPairState searchState [true] [true] := LeftRun.one (by decide)
  exact right.trans left

theorem search_zero_zero : LeftRun searchState searchEndState [false, false] [false, false] := by
  have right : LeftRun searchState searchPairState [false] [false] := LeftRun.one (by decide)
  have left : LeftRun searchPairState searchEndState [false] [false] := LeftRun.one (by decide)
  exact right.trans left

/-- Find the leading double zero without changing a single tape cell. -/
theorem find_double_zero (initialRun : Nat) (values : List Nat) :
    LeftRun searchState searchEndState
      (shiftInput initialRun values).reverse (shiftInput initialRun values).reverse := by
  induction values generalizing initialRun with
  | nil =>
    have certificate := (search_ones initialRun).trans search_zero_zero
    simpa [shiftInput, blocks, List.append_assoc] using certificate
  | cons value rest ih =>
    have certificate := (search_ones initialRun).trans (search_one_zero.trans (ih value))
    simp only [shiftInput, blocks, List.reverse_append, List.reverse_cons,
      List.reverse_nil, List.reverse_replicate, List.append_assoc, List.nil_append,
      List.cons_append] at certificate ⊢
    simpa only [List.replicate_succ' (n := value), List.append_assoc,
      List.nil_append, List.cons_append] using certificate

theorem undo_shift_exact (initialRun : Nat) (values : List Nat)
    (anchor : Int) (outside : Tape) :
    TM.run machine (shiftInput initialRun values).length
      (configuration undoState (anchor + ((shiftInput initialRun values).length : Int) - 1)
        (wordTape anchor (shiftInput initialRun values).reverse outside)) =
      configuration undoEndState (anchor - 1)
        (wordTape anchor (shiftOutput initialRun values).reverse outside) := by
  simpa using (undo_shift initialRun values).exact_run anchor outside

theorem find_double_zero_exact (initialRun : Nat) (values : List Nat)
    (anchor : Int) (outside : Tape) :
    TM.run machine (shiftInput initialRun values).length
      (configuration searchState (anchor + ((shiftInput initialRun values).length : Int) - 1)
        (wordTape anchor (shiftInput initialRun values).reverse outside)) =
      configuration searchEndState (anchor - 1)
        (wordTape anchor (shiftInput initialRun values).reverse outside) := by
  simpa using (find_double_zero initialRun values).exact_run anchor outside

#print axioms undo_shift_exact
#print axioms find_double_zero_exact

end P192.KernelReverse
