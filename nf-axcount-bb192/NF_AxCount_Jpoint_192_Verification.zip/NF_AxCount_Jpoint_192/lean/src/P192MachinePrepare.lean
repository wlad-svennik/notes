module
public import P192MachineControlKernelSelectors
public import P192MachineControlKernelContracts
@[expose] public section

/-! Preparation of any arithmetic instruction: after its 00 decoder phase,
fill the entire blank gap with ones and return the head to the final source
address bit in state k:2. Both tape exteriors are arbitrary. -/
namespace P192.Prepare
open NF210 NF210.TM CS192.Table
open P192.KernelRightShift P192.KernelSelectors
set_option maxHeartbeats 0
abbrev incSetup : State := 169
abbrev decSetup : State := 158

theorem names : name incSetup = "k:49" ∧ name decSetup = "k:24" := by decide

def setupState (isInc : Bool) : State := if isInc then incSetup else decSetup

theorem setup_zero (isInc : Bool) :
    machine (setupState isInc) false = ⟨false,.left,some prepareState⟩ := by
  cases isInc <;> decide

def sourceGap (gap : Nat) (b : Bool) := List.replicate gap b ++ [true]

theorem setup_rewind (isInc : Bool) (gap : Nat) (room : 2 ≤ gap) :
    WordRun (setupState isInc) returnState (sourceGap gap false) (sourceGap gap true)
      1 (-1) (1 + (gap+1) + gap) := by
  constructor
  · simp [sourceGap]
  · intro anchor outside
    have inside : 1 < (sourceGap gap false).length := by simp [sourceGap]; omega
    have second' : ∀ (g : Nat), wordTape anchor (sourceGap (g+2) false) outside (anchor+1) = false := by
      intro g
      change wordTape anchor (false :: false :: _) outside (anchor+1) = false
      rw [wordTape_cons, writeTape_away _ anchor (anchor+1) _ (by omega)]
      simp
    have g : gap = (gap-2)+2 := by omega
    have read : wordTape anchor (sourceGap gap false) outside (anchor+1) = false := by
      simpa only [← g] using second' (gap-2)
    have first := step_preserve (setup_zero isInc) (anchor+1) _ read
    have head0 : moveHead .left (anchor+1) = anchor := by simp [moveHead]
    rw [head0] at first
    have returned : LeftRun returnState returnState [true] [true] := LeftRun.one (by decide)
    have rewind := (returned.repeat gap).with_suffix anchor [true] outside
    simp only [List.length_replicate] at rewind
    rw [TM.run_add, TM.run_add]
    simp only [TM.run_succ, TM.run_zero] at first ⊢
    rw [first]
    unfold sourceGap
    rw [← TM.run_succ, prepare_exact, rewind]
    rfl

#print axioms setup_rewind
end P192.Prepare
