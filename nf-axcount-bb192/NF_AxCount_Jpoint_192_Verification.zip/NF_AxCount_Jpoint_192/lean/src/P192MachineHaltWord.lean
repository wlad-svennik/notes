module
public import P192MachineHaltGate
public import P192MachineDecrementWords
public import P192MachineFrameWords

@[expose] public section
set_option maxRecDepth 200000

namespace P192.HaltGate
open NF210 NF210.TM CS192.Table KernelRightShift KernelFiles

set_option maxHeartbeats 0

/-- At the unique odd decrement the last input address bit is one. This is
the actual bit read by the gate after restoring a logically zero register. -/
theorem odd_prefix_read (a : Int) (outside : Tape) :
    wordTape a (Carry.prefixAt 3334 false) outside
      (a+((Carry.prefixAt 3334 false).length:Int)-1) = true := by
  let word := Carry.prefixAt 3334 false
  have pos : 0 < word.length := by decide
  have i : word.length-1 < word.length := by omega
  have off : a+(word.length:Int)-1 = a+((word.length-1:Nat):Int) := by omega
  change wordTape a word outside (a+(word.length:Int)-1) = true
  rw [off, wordTape_get _ _ _ _ i]
  have cell : (Carry.prefixAt 3334 false)[(Carry.prefixAt 3334 false).length-1]? = some true := by decide
  change word[word.length-1]? = some true at cell
  simpa only [List.getElem?_eq_getElem i, Option.some.injEq] using cell

/-- Complete zero execution, whole-tape restoration, and final gate from
the marked operand of source site 3334. All register fields and both tape
exteriors are arbitrary. -/
theorem odd_operand_halts (gap : Nat) (earlier later : List Nat) (a : Int) (outside : Tape) :
    (TM.run machine (zeroTime gap earlier + 1)
      (configuration shiftState (a+((Carry.prefixAt 3334 false).length:Int)+2)
        (wordTape a (Decrement.operative 3334 gap 1 earlier later) outside))).state = none := by
  let front := Carry.prefixAt 3334 false
  let anchor := a+(front.length:Int)
  let background := wordTape a front outside
  have bit : background (anchor-1) = ((Source.siteAt 3334).address % 2 == 1) := by
    have h := odd_prefix_read a outside
    exact h.trans (by decide)
  have halt := (zero_decrement_halts_at_3334 3334 (by decide) (by decide)
    gap earlier (terminatedRuns later) anchor background bit).2 rfl
  have eq : Decrement.operative 3334 gap 1 earlier later =
      front ++ zeroInput gap earlier (terminatedRuns later) := by
    simp [Decrement.operative,front,zeroInput,List.append_assoc,blocks_terminated]
  rw [eq,wordTape_append,wordTape_commute _ _ _ _ _ (Int.le_refl _)]
  exact halt

end P192.HaltGate
