module
public import P192MachineControlScan
public import MachineBits

@[expose] public section

/-! A finite execution certificate is lifted to a cylinder of arbitrary
two-sided tapes. A branch case has two finite pieces connected by the
arbitrarily long scan proved in MachineControlScan. Coordinates in the
54-cell local window run from −9 to 44 relative to the decoder root. -/

namespace P192.Control

open NF210 NF210.TM
set_option autoImplicit false
set_option maxHeartbeats 0

structure Case where
  pc : Nat
  isBranch : Bool
  input : Nat
  output : Nat
  prefixSteps : Nat
  marker : Nat
  returnSteps : Nat

abbrev width : Nat := 54
abbrev entry : Nat := 9

def loc (q : State) (h bits : Nat) : NF192.KernelBits.Configuration 192 := ⟨some q, h, bits⟩

def CCRun (M : Machine 192) (c : Case) : Prop :=
  NF192.KernelBits.run M width c.prefixSteps (loc 13 entry c.input) = some (loc 13 entry c.output)

def CBRun (M : Machine 192) (c : Case) : Prop :=
  c.marker + 1 < width ∧ c.output.testBit c.marker = true ∧
  c.output < 2^(c.marker+1) ∧
  NF192.KernelBits.run M width c.prefixSteps (loc 13 entry c.input) =
    some (loc 174 (c.marker+1) c.output) ∧
  NF192.KernelBits.run M width c.returnSteps (loc 155 c.marker c.output) =
    some (loc 13 entry c.output)

instance (M : Machine 192) (c : Case) : Decidable (CCRun M c) := by
  unfold CCRun
  infer_instance

instance (M : Machine 192) (c : Case) : Decidable (CBRun M c) := by
  unfold CBRun
  infer_instance

def passes (M : Machine 192) (c : Case) : Bool :=
  if c.isBranch then decide (CBRun M c) else decide (CCRun M c)

abbrev tapeWindow (anchor : Int) (outside : Tape) (bits : Nat) : Tape :=
  NF192.KernelBits.tape width anchor outside bits

def rootWindow (anchor : Int) (outside : Tape) (bits : Nat) : Config :=
  NF192.KernelBits.embed width anchor outside (loc 13 entry bits)

theorem cont_semantics {M : Machine 192} {c : Case} (hc : c.isBranch = false)
    (ok : passes M c = true) (anchor : Int) (outside : Tape) :
    run M c.prefixSteps (rootWindow anchor outside c.input) =
      rootWindow anchor outside c.output := by
  have runOK : CCRun M c := of_decide_eq_true (by simpa [passes, hc] using ok)
  exact (NF192.KernelBits.run_sound M width anchor outside c.prefixSteps _ _
    (by decide : entry < width) runOK).2

def scanTime (anchor header : Int) (c : Case) : Nat :=
  (header-(anchor+(c.marker:Int)+1)).toNat + 3 + 3*((header-(anchor+(c.marker:Int))-2).toNat+1)

/-- In a physical production frame the header is at least 55 cells to the
right of origin. Only 45 cells to its right are needed here. The suffix
outside this finite gap is arbitrary. -/
theorem branch_semantics {M : Machine 192} (rows : ScannerRows M)
    {c : Case} (hc : c.isBranch = true) (ok : passes M c = true)
    (anchor header : Int) (outside : Tape)
    (separated : anchor + (width : Int) < header)
    (atHeader : outside header = true) (afterHeader : outside (header+1) = false)
    (exteriorGap : ∀ p, anchor + (width : Int) ≤ p → p < header → outside p = false) :
    run M (c.prefixSteps + scanTime anchor header c + c.returnSteps)
      (rootWindow anchor outside c.input) = rootWindow anchor outside c.output := by
  have checked : CBRun M c := of_decide_eq_true (by simpa [passes, hc] using ok)
  obtain ⟨markerBound, markerOne, maskBound, preRun, postRun⟩ := checked
  have markLt : c.marker < width := by omega
  let t := tapeWindow anchor outside c.output
  let last := anchor + (c.marker : Int)
  have prefixRaw := (NF192.KernelBits.run_sound M width anchor outside c.prefixSteps _ _
    (by decide : entry < width) preRun).2
  have hprefix : run M c.prefixSteps (rootWindow anchor outside c.input) = cfg 174 (last+1) t := by
    change run M c.prefixSteps (rootWindow anchor outside c.input) =
      cfg 174 (anchor + ((c.marker+1 : Nat) : Int)) t at prefixRaw
    rw [prefixRaw]
    congr 1
    dsimp [last]
    omega
  have horigin : run M c.returnSteps (cfg 155 last t) = rootWindow anchor outside c.output :=
    (NF192.KernelBits.run_sound M width anchor outside c.returnSteps _ _ markLt postRun).2
  have hat : t last = true := (NF192.KernelBits.tape_read width c.marker c.output markLt anchor outside).trans markerOne
  have above (p : Int) (hp : anchor + (width:Int) ≤ p) : t p = outside p := by
    have hn : ¬ (0 ≤ p-anchor ∧ p-anchor < (width:Int)) := by omega
    simp only [t, tapeWindow, NF192.KernelBits.tape, if_neg hn]
  have gap (p : Int) (h₁ : last < p) (h₂ : p < header) : t p = false := by
    by_cases beyond : anchor+(width:Int) ≤ p
    · exact (above _ beyond).trans (exteriorGap _ beyond h₂)
    · have inWindow : 0 ≤ p - anchor ∧ p - anchor < (width:Int) := by
        dsimp [last] at h₁
        omega
      have greater : c.marker+1 ≤ (p-anchor).toNat := by dsimp [last] at h₁; omega
      have bound : c.output < 2^(p-anchor).toNat :=
        Nat.lt_of_lt_of_le maskBound (Nat.pow_le_pow_right (by decide : 0 < 2) greater)
      simpa only [t, tapeWindow, NF192.KernelBits.tape, if_pos inWindow] using Nat.testBit_lt_two_pow bound
  have hscan : run M (scanTime anchor header c) (cfg 174 (last+1) t) = cfg 155 last t :=
    rows.scan_gap t (last+1) last header (by omega) (by dsimp [last]; omega)
      (by dsimp [last]; omega) hat ((above _ (by omega)).trans atHeader)
      ((above _ (by omega)).trans afterHeader) gap
  rw [run_add, run_add, hprefix, hscan, horigin]

end P192.Control
