"""Rebuild the registered Counting 192 theorems from the source files in this archive."""
import argparse
import concurrent.futures
import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
STANDARD_MODULES = {"Init", "Std", "Lean"}
IMPORT = re.compile(r"^(?:(?:public|meta) )*import ([\w.]+)", re.M)
AUDIT = re.compile(r"'([^']+)' depends on axioms: \[([^\]]*)\]", re.S)


def relative_file(module, extension):
    return Path(*module.split(".")).with_suffix(extension)


def dependency_graph(targets, upstream_builds):
    pins = json.loads((HERE / "receipts/sources.json").read_text())
    graph, sources = {}, {}

    def visit(module):
        if module in graph or module in STANDARD_MODULES:
            return
        name = relative_file(module, ".lean")
        source = HERE / "src" / name
        working_dir = HERE / "src"
        if not source.is_file():
            working_dir = HERE / "upstream"
            source = working_dir / name
            if any((folder / relative_file(module, ".olean")).is_file() for folder in upstream_builds):
                return
        if module not in pins:
            raise ValueError(f"Missing source fingerprint for {module}")
        if hashlib.sha256(source.read_bytes()).hexdigest() != pins[module]:
            raise ValueError(f"Source fingerprint mismatch for {module}")
        sources[module] = working_dir
        graph[module] = set(IMPORT.findall(source.read_text()))
        for dependency in graph[module]:
            visit(dependency)

    for module in targets:
        visit(module)
    return graph, sources


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", default="lean")
    parser.add_argument("--jobs", type=int, default=3)
    parser.add_argument("--build", type=Path, default=Path("lean-build"))
    parser.add_argument("--target", action="append", help="Repeat to override the public theorem modules.")
    parser.add_argument("--prebuilt", type=Path, action="append", default=[],
                        help="Optional trusted directory of compiled upstream dependencies.")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    lean = shutil.which(args.lean)
    if lean is None:
        parser.error("Lean executable was not found")
    version = subprocess.check_output([lean, "--version"], text=True).strip()
    if "4.35.0" not in version:
        parser.error(f"Expected Lean 4.35.0, found {version}")
    build = args.build.resolve()
    build.mkdir(exist_ok=True, parents=True)
    upstream = [p.resolve() for p in args.prebuilt]
    env = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, [build, *upstream])))
    targets = args.target or ["Counting192J", "Table192Order"]
    graph, sources = dependency_graph(targets, upstream)
    audits = {}

    def compile_module(module):
        target = build / relative_file(module, ".olean")
        target.parent.mkdir(exist_ok=True, parents=True)
        log = build / (module + ".log")
        cmd = [lean, "-j", "1", "-s", "131072", "-o", str(target), str(relative_file(module, ".lean"))]
        with log.open("w") as handle:
            result = subprocess.run(cmd, cwd=sources[module], env=env, stdout=handle, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f"{module} failed. See {log}")
        output = log.read_text()
        if "sorryAx" in output or "uses 'sorry'" in output:
            raise ValueError(f"Unresolved proof in {module}")
        return {name: [a.strip() for a in assumptions.split(",")] for name, assumptions in AUDIT.findall(output)}

    remaining = set(graph)
    running = {}
    with concurrent.futures.ThreadPoolExecutor(args.jobs) as workers:
        while remaining:
            ready = sorted(m for m in remaining - running.keys() if not graph[m] & remaining)
            for module in ready[:args.jobs - len(running)]:
                running[module] = workers.submit(compile_module, module)
            if not running:
                raise ValueError("The import graph contains a cycle")
            completed, _ = concurrent.futures.wait(running.values(), return_when=concurrent.futures.FIRST_COMPLETED)
            for module, future in list(running.items()):
                if future in completed:
                    audits[module] = future.result()
                    remaining.remove(module)
                    del running[module]
                    print(f"{len(graph) - len(remaining)}/{len(graph)} {module}", flush=True)
    report = dict(lean=version, theorem_modules=targets, axiom_audits=audits)
    (build / "replay.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
