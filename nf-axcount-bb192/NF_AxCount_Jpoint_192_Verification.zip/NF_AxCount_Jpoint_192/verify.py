"""Reconstruct the complete 192-state table, compare the Lean literals, and run the physical decoder tests."""
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "checks"))
from physical import check

TABLE = "34698929dc83de04608eabd889ca898f34a23800c483b03386922ca51e8f25ee"
PARENT = "18ec8262ccf9a52101ea2152c40b30c97eab8fa1a259d3396d6c9719bf4b8662"
SOURCE = "49925d5fe4f7d283aeb87edae1e26659f09582919a2a62bf9a9155478d99c922"

OLDSOURCE = "ccfe427de701a5ced94c231c6203ccc19dde0e7682c25ecfaf1502e9b2fadac5"

LAYOUT = "61a0cc922c6fc4c793c2d620d0e1d60e50ee21d16e44fbbf00700e5d007e8925"
REDIRECTS = "8cab749a50f3975fb38d13eb89797eaa53dcb6ab08c9a427fce8470fdc1a5e6c"

def require(condition, message):
    if not condition:
        raise ValueError(message)

def pinned(path, expected):
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected, "SHA-256 mismatch for " + path.name)
    return data

def register_program(sites):
    intervals = {}
    for i, (path, op, operand) in enumerate(sites):
        for j in range(len(path)+1):
            prefix = path[:j]
            lo, _ = intervals.get(prefix, (i,i))
            intervals[prefix] = (lo,i+1)
    n = len(sites)
    program = []
    for i, (path, op, operand) in enumerate(sites):
        def branch(bit, count):
            matches = [k for k in range(len(path)-1,-1,-1) if path[k] == bit]
            lo, hi = intervals[path[:matches[count-1]]]
            return lo if bit == "1" else hi % n
        if op == "CI":
            instruction = (op, operand, ((i+1) % n,))
        elif op == "CD":
            instruction = (op, operand, (branch("0",1), (i+1) % n))
        else:
            instruction = ("jump", None, (branch("0" if op == "CB" else "1",operand),))
        program.append(instruction)
    return program

def local_block(program, start, stop):
    body = []
    for op, operand, successors in program[start:stop]:
        require(all(start <= x <= stop for x in successors), "Nonlocal macro exit")
        body.append((op, operand, tuple(x-start for x in successors)))
    return body

def transitions(lines):
    arcs = {}
    for line in lines:
        if line and not line.startswith("#"):
            q,b,w,m,z = line.split()
            require((q,int(b)) not in arcs, "Duplicate transition")
            arcs[q,int(b)] = (w,m,z)
    return arcs

def main():
    if not __debug__:
        raise RuntimeError("Run with normal Python, because the physical decoder tests use assertions.")
    candidate = ROOT / "candidate.tm"
    reference = ROOT / "reference" / "counting196.tm"
    source = ROOT / "source.sites.json"
    original = pinned(reference, PARENT).decode().splitlines()
    signed = json.loads(pinned(source, SOURCE))
    raw = pinned(candidate, TABLE)
    old_sites = json.loads(pinned(ROOT / "reference/counting196.sites.json", OLDSOURCE))
    require(len(old_sites)==3443 and len(signed)==3351, "Unexpected source size")
    prior_graph = register_program(old_sites)
    present_graph = register_program(signed)
    require(len(old_sites) == 3443 and len(signed)==3351, "Source lengths")
    def shift(x):
        return x-92 if x>=3321 else x
    for old_pc in list(range(40))+list(range(3321,3443)):
        op, reg, succ = prior_graph[old_pc]
        require(present_graph[shift(old_pc)] == (op,reg,tuple(shift(v) for v in succ)),
                "Outer register code differs at " + str(old_pc))
    layout = transitions(pinned(ROOT / "reference/jpoint195.tm", LAYOUT).decode().splitlines())
    require(len(layout)==390, "Wrong 195-state J-point layout")
    changes = json.loads(pinned(ROOT / "reference/redirects.json", REDIRECTS))
    for q,b,w,d,t,ww,dd,tt in changes:
        require(layout[q,b] == (w,d,t), "Incorrect starting transition")
        layout[q,b] = (ww,dd,tt)
    reachable = set()
    pending = ["k:64"]
    while pending:
        state = pending.pop()
        if state in reachable or state == "halt":
            continue
        reachable.add(state)
        pending.extend(layout[state,b][2] for b in (0,1))
    actual = transitions(raw.decode().splitlines())
    require({k:v for k,v in layout.items() if k[0] in reachable} == actual,
            "Reachable transitions disagree with the published table")
    header = (ROOT / "lean/src/Table192.lean").read_text()
    dec = json.JSONDecoder()
    labels, _ = dec.raw_decode("[" + header.split("def stateNames : Array String := #[",1)[1])
    literals, _ = dec.raw_decode(header.split("def literalRows : List String := ",1)[1])
    start = int(re.search(r"def start : State := (\d+)",header)[1])
    require(len(labels) == len(set(labels)) == 192, "Invalid state count")
    require(raw == ("#! start "+labels[start]+"\n"+"".join(literals)).encode(), "Lean literal mismatch")
    body = header[header.index("def instructionPair"):header.index("def machine")]
    pairs = re.findall(r"⟨(true|false), \.(left|right), (none|some \(\d+ : State\))⟩",body)
    require(len(pairs) == len(literals) == 384, "Incomplete transition function")
    literalset = set(literals)
    require(len(literalset)==384,"Duplicate transition")
    for i,(bit,where,target) in enumerate(pairs):
        dest = "halt" if target == "none" else labels[int(re.search(r"\d+",target)[0])]
        expected = f"{labels[i//2]} {i%2} {int(bit=='true')} {'L' if where=='left' else 'R'} {dest}\n"
        require(expected in literalset, "Wrong literal at transition "+str(i))
    data = (ROOT / "lean/src/P192MachineSourceData.lean").read_text()
    block = data.split("def packedSites : Array Nat := #[",1)[1].split("]",1)[0]
    words = [int(w,16) for w in re.findall(r"0x[0-9a-f]+",block)]
    ops = {"CI":0,"CD":1,"CB":2,"CC":3}
    require(len(signed)==3351 and len(words)==(len(signed)+15)//16,"Incorrect source length")
    for i,(path,op,reg) in enumerate(signed):
        val = (int("1"+path,2)<<6) | (reg<<2) | ops[op]
        require((words[i//16]>>(64*(i%16))) % (1<<64) == val, "Wrong source instruction "+str(i))
    cnt, rightmost = check(source,candidate,ROOT / "reference/NF192.tm",max(len(p) for p,_,_ in signed)+14)
    require(cnt=={'arithmetic': 6945, 'shifted': 67, 'break': 65, 'continue': 971} and rightmost==34, "Unexpected decoder coverage")
    print("Verified 192 states, 384 transitions, the literal register source, and the decoder tests.")
if __name__ == "__main__":
    main()
