# J-point calculus in 192 working states

The two-symbol table in `candidate.tm` uses 192 working states, 384 transitions and a separate halt. From the blank tape it halts exactly when the ten-row J-point calculus derives its goal, Q = J, which has code 3. Its program has 3,351 register instructions.

## Calculus

J is the primitive constant (code 0), Q = JJ has code 1, and B = H(Q,J) has code 4. Application associates to the left. Write Kx = H(x,x) and G for the formula Q = J. The changed rows are

| Role | Axiom |
|---|---|
| Fixed point | fx = x → Q = Qfx |
| Failure of a fixed point | ((fx = x) → G) → J = Qfx |
| Composition | Bfgx = (f(Kx))(gx) |
| Counting | (J(Jx))y = Jx |

The remaining rows give the Łukasiewicz implication axiom, left and right application congruence, the Euclidean equality rule, K and witness extensionality. The finite axiom generator uses the numerical restriction u ≤ a on its variables. The only inference rule is modus ponens. All formula orientations, number encodings and the exact order of rows are fixed in `lean/src/C193ChartRows.lean` and `lean/src/C193SearchCore.lean`.

## Formal results

| Lean theorem | Content |
|---|---|
| `Counting192J.halts_iff_jpoint_goal` | The literal physical machine halts from the blank tape exactly when the J-point calculus derives 3. |
| `Counting192J.buildable_iff_jpoint_derivable` | The register proof search builds precisely the formulas derivable in this calculus. |
| `Counting192J.nonhalting_iff_jpoint_chart` | Blank-tape nonhalting is equivalent to existence of an extensional applicative algebra satisfying the precise J-point chart in `C193GroundChart.lean`. |
| `C193.proves_2165` and `C193.old_2165_implies_goal` | J-point derives 2165. If the old calculus derives 2165, it derives its halting goal. |
| `C193.old_proves_positive_example` and `C193.jpoint_positive_example_implies_goal` | The old calculus derives 10782656132388. If J-point derives that formula, it derives its halting goal. |

These results establish the distinction between the raw numerical proof systems. The package verifies its own chart criterion. Equality of its blank-tape halting behavior with the original 199-state machine requires a further interpretation theorem. The Lean audit records eleven finite native-evaluator checks in the table-to-goal theorem, together with propositional extensionality, classical choice and quotient soundness.

## Reproduce

With Python 3, a C++17 compiler and Lean 4.35.0, run

```sh
python3 verify.py
python3 independent/run.py candidate.tm source.sites.json reference/counting196.tm --output replay.json
python3 lean/replay.py --lean /path/to/lean --jobs 4 --build lean-build
```

The verification script reconstructs the 192-state table from a retained 195-state J-point layout and 9 named transition changes. It compares all transitions and register addresses with the Lean literals. The full-tape simulator exercised 24 configurations at each of 3,351 program addresses, for 80,424 cases and 46,881,765 individual binary steps. The parallel proof-word and model statements cover unbounded execution.

| File | SHA-256 |
|---|---|
| `candidate.tm` | `34698929dc83de04608eabd889ca898f34a23800c483b03386922ca51e8f25ee` |
| `source.sites.json` | `49925d5fe4f7d283aeb87edae1e26659f09582919a2a62bf9a9155478d99c922` |
