"""Independent semantic audit of the explicit K/S register program.

The exact CFG audit binds unchanged code to the 198-state reference.  Finite
execution checks are regressions, not universal proofs.  The preserved leaf and
implication macro implementations have their original universal certificates.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from math import isqrt
from pathlib import Path

DEFAULT = Path(__file__).resolve().parents[1] / "ks_compilation" / "basis"


def decode_tree(rows):
    """Decode source control flow independently of the bundled graph.py."""
    paths = [r[0] for r in rows]
    assert paths == sorted(set(paths))
    boundaries = {}
    for pc, path in enumerate(paths):
        assert path and set(path) <= {"0", "1"}
        for n in range(len(path) + 1):
            prefix = path[:n]
            if prefix not in boundaries:
                boundaries[prefix] = [pc, pc + 1]
            boundaries[prefix][1] = pc + 1
    leaves = set(paths)
    for node in boundaries:
        assert (node + "0" in boundaries) == (node + "1" in boundaries)
        assert (node + "0" in boundaries) == (node not in leaves)
    out = []
    for pc, (path, op, arg) in enumerate(rows):
        fall = (pc + 1) % len(rows)
        if op == "CI":
            out.append([op, arg, fall])
            continue
        root = path
        direction = "1" if op == "CC" else "0"
        for _ in range(arg if op in ("CB", "CC") else 1):
            pos = root.rfind(direction)
            assert pos >= 0
            root = root[:pos]
        start, end = boundaries[root]
        if op == "CD":
            out.append([op, arg, fall, None if path.endswith("1") else end % len(rows)])
        elif op == "CC":
            out.append(["J", start])
        else:
            assert op == "CB"
            out.append(["J", end % len(rows)])
    return out


def run(program, registers, start, stop, limit=2_000_000):
    r = list(registers)
    pc = start
    steps = 0
    while pc != stop:
        if pc is None:
            return None
        assert steps < limit, ("step limit", start, stop, registers, pc)
        row = program[pc]
        if row[0] == "J":
            pc = row[1]
        elif row[0] == "CI":
            r[row[1]] += 1
            pc = row[2]
        else:
            assert row[0] == "CD"
            if r[row[1]]:
                r[row[1]] -= 1
                pc = row[2]
            else:
                pc = row[3]
        steps += 1
    return r


def pair(a, b):
    return (a+b)*(a+b+1)//2+b


def unpair(n):
    d = (isqrt(8*n+1)-1)//2
    b = n-d*(d+1)//2
    return d-b, b


def imp(a, b):
    return 2*pair(a, b)


def symbolic_formula(tokens):
    stack = []
    for token in tokens:
        if token in "abc":
            stack.append(token)
        else:
            assert token == "P" and len(stack) >= 2
            q = stack.pop()
            p = stack.pop()
            stack.append(("imp", p, q))
    assert len(stack) == 1
    return stack[0]


def relocate(row, mapping):
    if row[0] == "J":
        return ["J", mapping(row[1])]
    return row[:2] + [mapping(x) for x in row[2:]]


def audit(directory):
    reference_path = directory / "reference-198.sites.json"
    raw = reference_path.read_bytes()
    # This is the later, verified SWAP-only shortened 198-state source, not the
    # original 4,366-instruction release.  Bind its two changes explicitly below.
    assert hashlib.sha256(raw).hexdigest() == "fdb3fde1f2690cdbf37e164ecf128f6f3d8d8a2a0f173e7de2bd8d4929affa6e"
    reference = decode_tree(json.loads(raw))
    original_path = Path(__file__).resolve().parent / "references/original198.sites.json"
    original_bytes = original_path.read_bytes()
    assert hashlib.sha256(original_bytes).hexdigest() == "a3e512b0f9886a6230f22634a7ec84a2a4b9d7aa8ec0dd001219023cf86c820a"
    original = decode_tree(json.loads(original_bytes))
    def shorten(pc):
        if pc is None or pc < 4304:
            return pc
        assert pc != 4304
        return pc-1
    for pc, row in enumerate(original):
        if pc in (4303, 4304, 4305, 4319):
            continue
        assert reference[shorten(pc)] == relocate(row, shorten)
    assert reference[4303] == ["CD", 6, 4304, 4305]
    assert reference[4304] == ["J", 4302]
    assert reference[4318] == ["CD", 4, 4319, 4349]
    print("Reference binding: original 198 source plus exact MODE loop fold and zero-parameter observer bypass.")
    artifact = json.loads((directory / "register-program.json").read_bytes())
    program = artifact["instructions"]
    assert artifact["entry"] == 0 and artifact["initial_registers"] == [3]+[0]*8

    # The old row's only input-reading macro is r.  Both new rows omit it.
    old_tokens = "caPraPacPbcPPP"
    size = {"a": 26, "b": 26, "c": 26, "P": 25, "r": 14}
    templates = {}
    old_end = 42
    for token in old_tokens:
        templates.setdefault(token, (old_end, old_end+size[token]))
        old_end += size[token]
    rows = ["abaPP", "abcPPabPacPPP"]
    a, b, c = "a", "b", "c"
    I = lambda p, q: ("imp", p, q)
    assert symbolic_formula(rows[0]) == I(a, I(b, a))
    assert symbolic_formula(rows[1]) == I(I(a, I(b, c)), I(I(a, b), I(a, c)))
    new_end = 42 + sum(size[t] for row in rows for t in row)
    shift = new_end - old_end
    assert len(program) == len(reference)+shift == 4479

    def outside(pc):
        if pc is None or pc <= 42:
            return pc
        assert pc >= old_end, ("entry into removed logical row", pc)
        return pc+shift

    retained = list(range(42)) + list(range(old_end, len(reference)))
    for old_pc in retained:
        new_pc = old_pc if old_pc < 42 else old_pc+shift
        assert program[new_pc] == relocate(reference[old_pc], outside)

    copies = []
    pos = 42
    for row in rows:
        for token in row:
            left, right = templates[token]
            for k in range(right-left):
                def local(pc):
                    assert pc is not None and left <= pc <= right
                    return pos+pc-left
                assert program[pos+k] == relocate(reference[left+k], local)
            copies.append((token, pos, pos+right-left))
            pos += right-left
    assert pos == new_end
    assert sum(None in row for row in program) == 1
    print(f"Exact CFG: {len(retained)} retained instructions and {len(copies)} complete macro copies; all branches agree.")
    print("Rows: K, S, then all eight original nonlogical rows; no fourth field read remains.")

    # Check macro boundaries directly in the literal program, without symbolic
    # acceleration.  This catches wrongly relocated jumps and stack corruption.
    macro_cases = 0
    for token, start, stop in copies:
        for top, tail, aa, bb, cc in itertools.product(range(3), range(3), range(2), range(2), range(2)):
            if token == "P":
                regs = [9, top, pair(aa, tail), cc, bb, 7, 0, 0, 17]
                expected = [9, imp(aa, top), tail, cc, bb, 7, 0, 0, 17]
            else:
                regs = [9, top, tail, cc, aa, bb, 0, 0, 17]
                value = {"a": aa, "b": bb, "c": cc}[token]
                expected = [9, value, pair(top, tail), cc, aa, bb, 0, 0, 17]
            assert run(program, regs, start, stop) == expected, (token, start, regs)
            macro_cases += 1
    print(f"Literal new-macro executions: {macro_cases}; exact older-stack preservation and no cursor consumption.")

    # Command prefix decoding is identical for all outgoing branches, so two
    # fields means two fields even on nonzero carried rank / saved parameter.
    prefix_cases = 0
    for cursor, epoch, rank, param in itertools.product(range(40), range(12), (0, 1, 7), (0, 2)):
        regs = [epoch, 5, 13, rank, param, 17, 0, 0, cursor]
        if cursor:
            tag, rest = unpair(cursor-1)
            imm, tail = unpair(rest)
            expected = [epoch, 5, 13, rank+tag, param+imm, 17, 0, 0, tail]
        else:
            imm, tail = unpair(epoch)
            expected = [epoch+1, 5, 13, rank, param+imm, 17, 0, 0, tail]
        assert run(program, regs, 0, 37) == expected
        prefix_cases += 1
    print(f"Literal parser cases: {prefix_cases}, including fresh epochs and both carried values.")

    # Non-AX command tail.  Force both successful and failed detachments and
    # arbitrary stack heads, plus the explicit 57-loading SWAP regression.
    tail_cases = 0
    for rank, top, head, tail, param, cache in itertools.product((0, 1), range(5), range(3), range(3), range(4), range(14)):
        regs = [9, top, pair(head, tail), rank, param, cache, 0, 0, 17]
        actual = run(program, regs, 37, 0)
        if rank == 0 and param > 0 and cache == 3:
            expected = None
        elif rank == 0 and param > 0:
            expected = [9, cache, pair(head, tail), 0, param-1, top, 0, 0, 17]
        else:
            result = top if rank == 0 else param if cache == imp(top, param) else 0
            expected = [9, result, tail, 0, 0, head, 0, 0, 17]
        assert actual == expected, (regs, actual, expected)
        tail_cases += 1
    loaded = run(program, [9, 0, pair(7, 2), 0, 1, 57, 0, 0, 17], 37, 0)
    assert loaded == [9, 57, pair(7, 2), 0, 0, 0, 0, 0, 17]
    detached = run(program, [9, 1, pair(7, 2), 1, 3, imp(1, 3), 0, 0, 17], 37, 0)
    assert detached == [9, 3, 2, 0, 0, 7, 0, 0, 17]
    swapped = run(program, [9, 3, 2, 0, 1, 7, 0, 0, 17], 37, 0)
    assert swapped == [9, 7, 2, 0, 0, 3, 0, 0, 17]
    swapped[4] = 1
    assert run(program, swapped, 37, 0) is None
    print(f"Literal NIP / SWAP / MODE cases: {tail_cases+4}; K-row 57 loads, valid MP derives 3, and observation halts.")


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("directory", nargs="?", type=Path, default=DEFAULT)
    audit(cli.parse_args().directory)
