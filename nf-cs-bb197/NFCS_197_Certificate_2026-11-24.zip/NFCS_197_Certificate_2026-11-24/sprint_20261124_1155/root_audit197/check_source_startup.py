"""Independent source, invariant and literal-startup checks for loop197.

This checker deliberately imports no compiler, source transformation, invariant
producer, or physical trace interpreter.  The phase proof is a separate artifact.
"""
from collections import Counter
from pathlib import Path
import hashlib
import json
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ORDER = (2, 8, 1, 4, 3, 7, 0, 5, 6)
EXPECTED_TABLE = '948492f1d299acb09b0d3464c5de7ef6e5d510bc09398324a9610c65f52cbbf3'
EXPECTED_OLD_SOURCE = 'fdb3fde1f2690cdbf37e164ecf128f6f3d8d8a2a0f173e7de2bd8d4929affa6e'
EXPECTED_SOURCE = 'cccaeda909358991cb3a1f8882d97abcab8ab7bb3f8d503ec3030c475ba82ae8'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def decode(rows):
    """Reconstruct the full binary tree, then jump through explicit ancestors."""
    leaf = {p: pc for pc, (p, _, _) in enumerate(rows)}
    assert len(leaf) == len(rows)
    assert list(leaf) == sorted(leaf)
    span = {}

    def visit(prefix):
        if prefix in leaf:
            pc = leaf[prefix]
            span[prefix] = (pc, pc + 1)
            return span[prefix]
        assert any(p.startswith(prefix + '0') for p in leaf)
        assert any(p.startswith(prefix + '1') for p in leaf)
        a, b = visit(prefix + '0'), visit(prefix + '1')
        assert a[1] == b[0]
        span[prefix] = (a[0], b[1])
        return span[prefix]

    assert visit('') == (0, len(rows))
    edges = []
    for pc, (p, op, arg) in enumerate(rows):
        nxt = (pc + 1) % len(rows)
        if op in ('CI', 'M65'):
            edges.append((nxt,))
        elif op == 'CD':
            assert 0 <= arg < 9
            edges.append((nxt, None if p[-1] == '1' else span[p[:-1]][1] % len(rows)))
        elif op in ('CC', 'CB'):
            direction = '1' if op == 'CC' else '0'
            choices = [p[:i] for i, bit in enumerate(p) if bit == direction]
            assert 0 < arg <= len(choices)
            root = choices[-arg]
            edges.append((span[root][0 if op == 'CC' else 1] % len(rows),))
        else:
            raise AssertionError((pc, op))
    return edges, span


def check_collapse(old, new):
    old_edges, old_span = decode(old)
    new_edges, _ = decode(new)
    old_pc = {p: pc for pc, (p, _, _) in enumerate(old)}
    old_to_new = [None] * len(old)
    new_to_old = []
    macros = []
    for pc, (p, op, arg) in enumerate(new):
        if op != 'M65':
            origin = old_pc[p]
            assert old[origin] == new[pc]
            assert old_to_new[origin] is None
            old_to_new[origin] = pc
            new_to_old.append(origin)
            continue
        assert arg == 0
        start, end = old_span[p]
        assert end - start == 3
        assert old[start:end] == [[p+'0', 'CD', 6], [p+'10', 'CI', 5], [p+'11', 'CC', 2]]
        assert old_edges[start] == (start+1, end % len(old))
        assert old_edges[start+1] == (start+2,)
        assert old_edges[start+2] == (start,)
        for q in range(start, end):
            assert old_to_new[q] is None
            old_to_new[q] = pc
        new_to_old.append(start)
        macros.append({'pc': pc, 'path': p, 'old_head': start,
                       'old_body': [start+1, start+2], 'old_exit': end % len(old)})
    assert all(pc is not None for pc in old_to_new)
    assert len(macros) == 29 and len(old)-len(new) == 58
    assert len(set(new_to_old)) == len(new)
    macro_by_head = {m['old_head']: m for m in macros}
    interiors = {q: m for m in macros for q in m['old_body']}
    outside_entry_checks = 0
    for origin, exits in enumerate(old_edges):
        for dest in exits:
            if dest in interiors:
                m = interiors[dest]
                assert origin in (m['old_head'], *m['old_body'])
                outside_entry_checks += 1
    edge_checks = 0
    for pc, origin in enumerate(new_to_old):
        exits = (macro_by_head[origin]['old_exit'],) if origin in macro_by_head else old_edges[origin]
        mapped = tuple(None if q is None else old_to_new[q] for q in exits)
        assert mapped == new_edges[pc], (pc, origin, mapped, new_edges[pc])
        edge_checks += len(mapped)
    return {'old_to_new': old_to_new, 'new_to_old': new_to_old,
            'macros': macros, 'old_edges': old_edges, 'new_edges': new_edges,
            'control_edges_checked': edge_checks, 'interior_incoming_edges_checked': outside_entry_checks}


def check_invariant(raw, rows, source_sha, edges, macros):
    cert = json.loads(raw)
    assert cert['source_sha256'] == source_sha
    threshold = cert['threshold']
    assert threshold == 15
    facts = cert['masks']
    assert len(facts) == len(rows)
    assert cert['initial'] == [3] + [0]*8
    assert all(facts[0][r] & (1 << v) for r, v in enumerate(cert['initial']))
    classes = lambda mask: [v for v in range(threshold+1) if (mask >> v) & 1]
    bits = lambda values: sum(1 << v for v in set(values))
    count = 0
    halt_count = 0
    for pc, (_, op, reg) in enumerate(rows):
        values = facts[pc]
        if values == [0]*9:
            continue
        assert len(values) == 9 and all(0 < m < (1 << (threshold+1)) for m in values)
        images = []
        if op in ('CC', 'CB'):
            images.append((edges[pc][0], values))
        elif op == 'M65':
            image = values.copy()
            image[5] = bits(min(threshold, a+b) for a in classes(values[5]) for b in classes(values[6]))
            image[6] = 1
            images.append((edges[pc][0], image))
        elif op == 'CI':
            image = values.copy()
            image[reg] = bits(min(threshold, v+1) for v in classes(values[reg]))
            images.append((edges[pc][0], image))
        else:
            assert op == 'CD'
            if values[reg] & 1:
                image = values.copy()
                image[reg] = 1
                images.append((edges[pc][1], image))
            positives = [v for v in classes(values[reg]) if v > 0]
            if positives:
                image = values.copy()
                # The top class denotes every n>=threshold: its predecessor
                # may be threshold-1 or remain in the top class.
                image[reg] = bits([v-1 for v in positives] + ([threshold] if threshold in positives else []))
                images.append((edges[pc][0], image))
        for dest, image in images:
            if dest is None:
                halt_count += 1
                continue
            assert all(a & ~b == 0 for a, b in zip(image, facts[dest])), (pc, dest)
            count += 1
    for m in macros:
        pc = m['pc']
        assert facts[pc][0] and not facts[pc][0] & 1
        assert facts[pc][7] == 1
        assert facts[pc][6 if pc == 39 else 5] == 1
    assert macros[0]['pc'] == 39
    assert cert['macro_entries'] == [{'pc': m['pc'], 'path': m['path'], 'masks': facts[m['pc']]} for m in macros]
    return {'invariant_sha256': sha(raw), 'threshold': threshold,
            'initial_included': True, 'inductive_nonhalt_edges': count,
            'admitted_halt_edges': halt_count, 'reachable_pcs': sum(v != [0]*9 for v in facts),
            'natural_registers_inductive': True, 'macro_heads': len(macros),
            'all_macro_R0_positive_R7_zero': True,
            'ordinary_28_macro_R5_zero': True, 'exceptional_PC39_R6_zero': True}


def read_table(raw):
    lines = raw.decode().splitlines()
    assert lines[0].startswith('#! start ')
    start = lines[0][9:]
    table = {}
    for line in lines[1:]:
        q, b, w, direction, dest = line.split()
        assert b in ('0','1') and w in ('0','1') and direction in ('L','R')
        key = q, int(b)
        assert key not in table
        table[key] = int(w), 1 if direction == 'R' else -1, dest
    states = {q for q, _ in table}
    assert start in states
    assert all((q, b) in table for q in states for b in (0,1))
    assert all(dest == 'halt' or dest in states for _, _, dest in table.values())
    return start, table, states


def check_table_change(old_raw, new_raw):
    old_start, old, _ = read_table(old_raw)
    start, table, states = read_table(new_raw)
    assert start == old_start and len(states) == 197
    rename = lambda q: 'd:39' if q == 'd:160' else q
    expected = {(q,b): (w,d,rename(dest)) for (q,b),(w,d,dest) in old.items() if q != 'd:160'}
    w,d,dest = old['d:160',1]
    expected['d:39',1] = w,d,rename(dest)
    assert old['d:160',0] == old['d:39',0]
    assert table == expected
    return {'states': len(states), 'transition_arms': len(table),
            'exact_quotient_checked': True, 'deleted_state': 'd:160', 'survivor': 'd:39',
            'survivor_1_arm_from': 'd:160', 'start': start}


def blank_startup(raw, rows):
    state, table, _ = read_table(raw)
    leaves = {p: pc for pc, (p, _, _) in enumerate(rows)}
    maxdepth = max(map(len, leaves))
    tape, head = set(), 0
    coverage = Counter()

    def parse():
        if not tape or min(tape) != head-1:
            return None
        path, cursor = '', head
        while path not in leaves:
            if len(path) >= maxdepth:
                return None
            path += '1' if cursor in tape else '0'
            cursor += 1
        last = max(tape)
        while cursor <= last and cursor not in tape:
            cursor += 1
        if cursor > last or cursor+1 in tape:
            return None
        header = cursor
        cursor += 2
        fields = []
        while cursor <= last:
            start = cursor
            while cursor in tape:
                cursor += 1
            if cursor == start:
                return None
            fields.append(cursor-start)
            cursor += 1
        if len(fields) < 9 or any(n < 2 for n in fields[:9]) or any(n != 1 for n in fields[9:]):
            return None
        registers = [0]*9
        for i, r in enumerate(ORDER):
            registers[r] = fields[i]-2
        return {'pc': leaves[path], 'path': path, 'head': head, 'header': header,
                'gap': header-head, 'registers': registers, 'zero_spares': len(fields)-9}

    for steps in range(1, 3_000_001):
        bit = int(head in tape)
        coverage[state,bit] += 1
        write, move, state = table[state,bit]
        if write: tape.add(head)
        else: tape.discard(head)
        head += move
        assert state != 'halt', ('startup_halt', steps)
        if state == 'd:0':
            frame = parse()
            if frame is not None and frame['pc'] == 0 and frame['registers'] == [3]+[0]*8:
                assert frame['gap'] >= 49 and frame['zero_spares'] >= 24
                return {'steps': steps, 'frame': frame, 'ones': sorted(tape),
                        'literal_coverage': [[q,b,n] for (q,b),n in sorted(coverage.items())]}
    raise AssertionError('No admitted blank startup within the explicit step budget')


def main():
    # A portable copy can supply all four reference files in this directory.
    defaults = [ROOT/'deliverables/reference_snapshot/baseline198/source.sites.json',
                ROOT/'sprint_20261124_1155/native/loop197_m65/source.sites.json',
                ROOT/'continuation/macro_invariants/invariant.json',
                ROOT/'sprint_20261124_1155/native/loop197_m65/candidate.tm',
                ROOT/'deliverables/reference_snapshot/baseline198/candidate.tm']
    names = ['primitive-source.sites.json','source.sites.json','invariant.json','candidate.tm','baseline198.tm']
    paths = [HERE/name if (HERE/name).exists() else fallback for name,fallback in zip(names,defaults)]
    if len(sys.argv) > 1:
        assert len(sys.argv) == 6
        paths = list(map(Path, sys.argv[1:]))
    raw_old, raw_new, raw_inv, raw_table, raw_baseline = [p.read_bytes() for p in paths]
    assert sha(raw_old) == EXPECTED_OLD_SOURCE and sha(raw_new) == EXPECTED_SOURCE
    assert sha(raw_table) == EXPECTED_TABLE
    old, new = json.loads(raw_old), json.loads(raw_new)
    correspondence = check_collapse(old,new)
    invariant = check_invariant(raw_inv,new,sha(raw_new),correspondence['new_edges'],correspondence['macros'])
    table_change = check_table_change(raw_baseline,raw_table)
    startup = blank_startup(raw_table,new)
    assert startup['steps'] == 72014
    assert startup['frame']['gap'] == 49 and startup['frame']['zero_spares'] == 31
    receipt = {'status': 'source_invariant_and_startup_passed_physical_phase_proof_separate',
               'table_sha256': sha(raw_table), 'primitive_source_sha256': sha(raw_old),
               'macro_source_sha256': sha(raw_new), 'checker_sha256': sha(Path(__file__).read_bytes()),
               'primitive_sites': len(old), 'macro_sites': len(new),
               'macro_count': len(correspondence['macros']), 'table_change': table_change,
               'invariant': invariant,
               'source_control_edges_checked': correspondence['control_edges_checked'],
               'interior_incoming_edges_checked': correspondence['interior_incoming_edges_checked'],
               'startup': {k:v for k,v in startup.items() if k not in ('ones','literal_coverage')}}
    for name, raw in zip(names,[raw_old,raw_new,raw_inv,raw_table,raw_baseline]):
        (HERE/name).write_bytes(raw)
    (HERE/'source-correspondence.json').write_text(json.dumps(correspondence,separators=(',',':'))+'\n')
    (HERE/'startup.json').write_text(json.dumps(startup,indent=2)+'\n')
    (HERE/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    main()
