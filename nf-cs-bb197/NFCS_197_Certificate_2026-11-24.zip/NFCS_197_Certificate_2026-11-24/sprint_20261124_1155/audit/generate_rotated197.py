"""Produce complete ordinary and rotated-M65 symbolic action traces.

This is a trace producer. check_rotated197.py reconstructs every endpoint
and replays the actions without importing this producer or its engine.
"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / "loop197_m65"
PRIMITIVE = OUT / "primitive"
sys.path.insert(0, str(ROOT / "semantic_audit"))
from audit_ks_program import decode_tree


def main():
    sys.argv = [sys.argv[0], str(PRIMITIVE)]
    path = ROOT / "logic_basis/joint_invariants/symbolic_joint.py"
    spec = importlib.util.spec_from_file_location("rotated197_engine", path)
    engine = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = engine
    spec.loader.exec_module(engine)
    source = json.loads((PRIMITIVE / "source.sites.json").read_bytes())
    cfg = decode_tree(source)
    heads = [pc for pc in range(len(cfg) - 2)
             if cfg[pc:pc+3] == [["CD", 6, pc+1, (pc+3) % len(cfg)],
                                ["CI", 5, pc+2], ["J", pc]]]
    assert len(heads) == 29
    interiors = {pc for head in heads for pc in range(head, head+3)}
    old_frame, old_transfer = engine.frame, engine.transfer
    pumps, pump_indices, traces = [], {}, []
    start = time.monotonic()

    def save(pc, mode, zero, runs, actions, result):
        assert result[0] in ("live", "halt"), (pc, mode, zero, result)
        instructions = []
        for action in actions:
            if action[0] == "steps":
                instructions.append(action[1])
            elif action[0] == "rotate":
                instructions.append(0)
            else:
                assert action[0] == "pump"
                pump = action[1]
                if pump not in pump_indices:
                    pump_indices[pump] = len(pumps)
                    pumps.append(pump)
                instructions.append(-pump_indices[pump]-1)
        traces.append({"pc": pc, "mode": mode, "zero": zero,
                       "runs": runs, "clock": result[1], "actions": instructions})

    for pc, (_, op, reg) in enumerate(source):
        if pc in interiors:
            continue
        for zero in ((False, True) if op == "CD" else (False,)):
            runs = [(1, True)] * 9
            if op == "CD":
                runs[reg] = (1, False) if zero else (2, True)
            actions = []
            result = engine.branch(pc, zero, False, actions, runs)
            save(pc, "ordinary", zero, runs, actions, result)
    ordinary_count = len(traces)
    print("ordinary", ordinary_count, "seconds", round(time.monotonic()-start, 2), flush=True)

    for head in heads:
        # Entry CD6 remains an ordinary source instruction. Its zero
        # branch permits arbitrary R5, including the exceptional first head.
        for zero in (False, True):
            runs = [(1, True)] * 9
            runs[0], runs[7] = (2, True), (1, False)
            runs[6] = (1, False) if zero else (2, True)
            if not zero:
                runs[5] = (1, False)
            actions = []
            result = engine.branch(head, zero, False, actions, runs)
            save(head, "entry", zero, runs, actions, result)

        # With an initially empty destination the old CI5 now only changes
        # the instruction address, deferring the increment to the tail.
        pc = head+1
        old_instruction = engine.sites[pc]
        engine.sites[pc] = [old_instruction[0], "NOP", 0]
        engine.transfer = lambda index, zero, target=head+2: (target, False)
        runs = [(1, True)] * 9
        runs[0], runs[5], runs[7] = (2, True), (1, False), (1, False)
        actions = []
        result = engine.branch(pc, False, False, actions, runs)
        save(pc, "defer", False, runs, actions, result)
        engine.sites[pc], engine.transfer = old_instruction, old_transfer

        # The rotated tail accepts any destination value. Each positive
        # donor phase increments it, decrements donor, and returns here.
        # On zero donor the deferred increment is performed before exit.
        pc = head+2
        old_instruction = engine.sites[pc]
        engine.sites[pc] = [old_instruction[0], "CI", 5]
        for zero in (False, True):
            dest = (head+3) % len(source) if zero else pc
            shifted = zero and dest == 0
            engine.transfer = lambda index, branch_zero, dest=dest, shifted=shifted: (dest, shifted)
            runs = [(1, True)] * 9
            runs[0], runs[7] = (2, True), (1, False)
            runs[6] = (1, False) if zero else (2, True)
            calls = [0]

            def phase_frame(index, rr, spare_offset=0, gap_offset=0):
                calls[0] += 1
                rr = list(rr)
                if calls[0] == 2 and not zero:
                    rr[6] = (rr[6][0]-1, rr[6][1])
                    gap_offset += 1
                return old_frame(index, rr, spare_offset, gap_offset)

            engine.frame = phase_frame
            actions = []
            # The temporary producer opcode CI5 builds precisely the
            # desired R5+1, spare+1 endpoint. The independent checker
            # reconstructs this contract directly from mode='tail'.
            result = engine.branch(pc, False, False, actions, runs)
            save(pc, "tail", zero, runs, actions, result)
            engine.frame = old_frame
        engine.sites[pc], engine.transfer = old_instruction, old_transfer
    cert = {
        "format": "nf-symbolic-rotated-m65-v1",
        "table_sha256": engine.TABLE_HASH,
        "primitive_source_sha256": engine.PROGRAM_HASH,
        "collapsed_source_sha256": hashlib.sha256((OUT / "source.sites.json").read_bytes()).hexdigest(),
        "base_gap": engine.GAP,
        "macro_heads": heads,
        "ordinary_domains": ordinary_count,
        "phase_domains": len(traces)-ordinary_count,
        "pumps": [{"q": q, "dir": direction, "context": context,
                   "unit": unit, "output": output, "ticks": ticks}
                  for q, direction, context, unit, output, ticks in pumps],
        "traces": traces,
    }
    raw = gzip.compress(json.dumps(cert, separators=(",", ":")).encode(), mtime=0)
    (OUT / "rotated-traces.gz").write_bytes(raw)
    print(json.dumps({"table_sha256": engine.TABLE_HASH,
                      "trace_sha256": hashlib.sha256(raw).hexdigest(),
                      "ordinary_domains": ordinary_count,
                      "phase_domains": len(traces)-ordinary_count,
                      "pumps": len(pumps), "bytes": len(raw),
                      "seconds": round(time.monotonic()-start, 3)}), flush=True)


if __name__ == "__main__":
    main()
