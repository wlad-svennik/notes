"""Independently replay the complete 197-state rotated-M65 certificate.

No trace producer or symbolic engine is imported. Every endpoint, domain,
source edge, pump, and loop guard is reconstructed here. The 29 tail cycles
are completed by the natural-number induction stated in Rotated197.md.
"""
from collections import Counter, deque
from pathlib import Path
import gzip
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
DIRECTORY = Path(__file__).resolve().parent / "loop197_m65"
sys.path.insert(0, str(ROOT / "semantic_audit"))
from audit_ks_program import decode_tree

ORDER = (2, 8, 1, 4, 3, 7, 0, 5, 6)
TABLE_SHA = "948492f1d299acb09b0d3464c5de7ef6e5d510bc09398324a9610c65f52cbbf3"
OLD_SHA = "fdb3fde1f2690cdbf37e164ecf128f6f3d8d8a2a0f173e7de2bd8d4929affa6e"
SOURCE_SHA = "cccaeda909358991cb3a1f8882d97abcab8ab7bb3f8d503ec3030c475ba82ae8"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def normal(ray):
    out = []
    for token in ray:
        if isinstance(token, str):
            out.append(token)
            continue
        index, word = token
        moved = []
        while out and isinstance(out[-1], str) and out[-1] == word[-1]:
            bit = out.pop()
            moved.append(bit)
            word = bit+word[:-1]
        out.append((index, word))
        out.extend(reversed(moved))
    while out and out[-1] == "0":
        out.pop()
    return out


def source_check(old, source):
    graph = decode_tree(old)
    n = len(old)
    heads = [i for i in range(n-2)
             if graph[i:i+3] == [["CD", 6, i+1, (i+3) % n],
                                ["CI", 5, i+2], ["J", i]]]
    assert len(heads) == 29
    removed = {i for h in heads for i in (h+1, h+2)}
    retained = [i for i in range(n) if i not in removed]
    mapping = {oldpc: newpc for newpc, oldpc in enumerate(retained)}
    assert len(source) == len(retained) == 4307
    collapsed = decode_tree([[p, "CI", 0] if op == "M65" else [p, op, r]
                             for p, op, r in source])
    for newpc, oldpc in enumerate(retained):
        if oldpc in heads:
            prefix = old[oldpc][0][:-1]
            assert [row[0] for row in old[oldpc:oldpc+3]] == [prefix+"0", prefix+"10", prefix+"11"]
            assert source[newpc] == [prefix, "M65", 0]
            assert collapsed[newpc] == ["CI", 0, mapping[(oldpc+3) % n]]
            collapsed[newpc] = ["M65", 0, mapping[(oldpc+3) % n]]
            for caller, instruction in enumerate(graph):
                if oldpc <= caller < oldpc+3:
                    continue
                destinations = instruction[1:] if instruction[0] == "J" else instruction[2:]
                assert not any(d in (oldpc+1, oldpc+2) for d in destinations)
        else:
            assert source[newpc] == old[oldpc]
            instruction = graph[oldpc]
            cut = 1 if instruction[0] == "J" else 2
            expected = instruction[:cut] + [None if d is None else mapping[d] for d in instruction[cut:]]
            assert collapsed[newpc] == expected
    return graph, collapsed, heads, mapping


def invariant_check(source, graph, heads, mapping):
    path = ROOT / "sprint_20261124_1155/root_audit197/invariant.json"
    raw = path.read_bytes()
    facts = json.loads(raw)
    assert facts["source_sha256"] == SOURCE_SHA
    assert facts["initial"] == [3]+[0]*8
    threshold, masks = facts["threshold"], facts["masks"]
    assert threshold == 15 and len(masks) == len(source)
    assert all(masks[0][r] & (1 << min(value, threshold)) for r, value in enumerate(facts["initial"]))
    top = 1 << threshold
    edges = 0
    for pc, values in enumerate(masks):
        if values is None or not any(values):
            continue
        assert len(values) == 9 and all(0 < m < 2*top for m in values)
        instruction = graph[pc]
        op = instruction[0]
        images = []
        if op == "J":
            images.append((instruction[1], list(values)))
        elif op == "M65":
            total = 0
            for a in range(threshold+1):
                if not values[5] >> a & 1:
                    continue
                for b in range(threshold+1):
                    if values[6] >> b & 1:
                        total |= 1 << min(threshold, a+b)
            image = list(values)
            image[5], image[6] = total, 1
            images.append((instruction[2], image))
        else:
            r = instruction[1]
            if op == "CI":
                image = list(values)
                image[r] = ((values[r] << 1) & (2*top-1)) | (values[r] & top)
                images.append((instruction[2], image))
            else:
                assert op == "CD"
                if values[r] & 1:
                    image = list(values)
                    image[r] = 1
                    images.append((instruction[3], image))
                if values[r] & ~1:
                    image = list(values)
                    image[r] = (values[r] >> 1) | (values[r] & top)
                    images.append((instruction[2], image))
        for dest, image in images:
            if dest is not None:
                assert masks[dest] is not None
                assert all(a & ~b == 0 for a, b in zip(image, masks[dest])), (pc, dest)
                edges += 1
    for head in heads:
        values = masks[mapping[head]]
        assert values is not None and not values[0] & 1 and values[7] == 1
        assert values[6] == 1 if head == 39 else values[5] == 1
    return {"sha256": digest(raw), "threshold": threshold,
            "nonhalt_closure_edges": edges, "macro_guards": len(heads)}


def audit(directory=DIRECTORY):
    started = time.monotonic()
    table_raw = (directory / "candidate.tm").read_bytes()
    old_raw = (directory / "primitive/source.sites.json").read_bytes()
    source_raw = (directory / "source.sites.json").read_bytes()
    cert_raw = (directory / "rotated-traces.gz").read_bytes()
    assert digest(table_raw) == TABLE_SHA
    assert digest(old_raw) == OLD_SHA and digest(source_raw) == SOURCE_SHA
    old, source = json.loads(old_raw), json.loads(source_raw)
    graph, collapsed, heads, mapping = source_check(old, source)
    invariant = invariant_check(source, collapsed, heads, mapping)
    cert = json.loads(gzip.decompress(cert_raw))
    assert cert["format"] == "nf-symbolic-rotated-m65-v1"
    assert cert["table_sha256"] == TABLE_SHA
    assert cert["primitive_source_sha256"] == OLD_SHA
    assert cert["collapsed_source_sha256"] == SOURCE_SHA
    assert cert["macro_heads"] == heads
    assert cert["base_gap"] == 49
    excluded = {pc for h in heads for pc in range(h, h+3)}
    expected_domains = {(pc, "ordinary", zero)
                        for pc, (_, op, _) in enumerate(old) if pc not in excluded
                        for zero in ((False, True) if op == "CD" else (False,))}
    ordinary_count = len(expected_domains)
    for h in heads:
        expected_domains.update({(h, "entry", False), (h, "entry", True),
                                 (h+1, "defer", False),
                                 (h+2, "tail", False), (h+2, "tail", True)})
    observed = Counter((t["pc"], t["mode"], t["zero"]) for t in cert["traces"])
    assert set(observed) == expected_domains and all(n == 1 for n in observed.values())
    assert ordinary_count == cert["ordinary_domains"] == 5605
    assert len(expected_domains)-ordinary_count == cert["phase_domains"] == 145
    lines = table_raw.decode().splitlines()
    assert lines[0] == "#! start k:64"
    rows = [line.split() for line in lines[1:]]
    names = sorted({row[0] for row in rows})
    assert len(names) == 197 and len(rows) == 394
    ids = {name: i for i, name in enumerate(names)}
    table = [None] * (2*len(names))
    for q, b, w, d, target in rows:
        assert b in ("0", "1") and w in ("0", "1") and d in ("L", "R")
        assert target in ids or target == "halt"
        index = 2*ids[q]+int(b)
        assert table[index] is None
        table[index] = (w, 1 if d == "R" else -1, ids.get(target, -1))
    assert all(row is not None for row in table)
    root = ids["d:0"]
    pumps = cert["pumps"]
    pump_edges = []
    for p in pumps:
        assert set(p) == {"q", "dir", "context", "unit", "output", "ticks"}
        q, direction, context, unit, output, ticks = [p[key] for key in ("q", "dir", "context", "unit", "output", "ticks")]
        assert 0 <= q < len(names) and direction in (-1, 1)
        assert unit and len(output) == len(unit) and set(context+unit+output) <= {"0", "1"}
        assert isinstance(ticks, int) and ticks > 0
        tape, head, state, edges = list(context+unit), len(context), q, set()
        for _ in range(ticks):
            assert state >= 0 and 0 <= head < len(tape)
            bit = int(tape[head])
            edges.add((state, bit))
            write, move, state = table[2*state+bit]
            tape[head] = write
            head += move*direction
        assert head == len(tape) and state == q and "".join(tape) == output+context
        pump_edges.append(edges)

    def frame(pc, runs, gap_extra=0, spare_extra=0):
        path = old[pc][0]
        padding = 49+gap_extra-len(path)
        assert padding >= 8
        word = list("1"+path+"0"*(padding-5))+[(9, "0")]+list("000001")
        for r in ORDER:
            minimum, variable = runs[r]
            assert minimum >= 1 and isinstance(variable, bool)
            word.extend("0"+"1"*minimum)
            if variable:
                word.append((r, "1"))
            word.append("1")
        word.extend("01"*12)
        word.append((10, "01"))
        word.extend("01"*(12+spare_extra))
        return [word[0]], word[1:]

    literal_steps = pump_uses = rotations = halts = 0
    used_edges = set()
    per_phase_edges = {}
    for number, trace in enumerate(cert["traces"]):
        pc, mode, zero = trace["pc"], trace["mode"], trace["zero"]
        assert isinstance(zero, bool)
        runs = [(1, True)] * 9
        row = graph[pc]
        gap_extra = spare_extra = 0
        if mode in ("ordinary", "entry"):
            if mode == "entry":
                assert pc in heads
                runs[0], runs[7] = (2, True), (1, False)
                if not zero:
                    runs[5] = (1, False)
            if row[0] == "J":
                assert not zero
                dest = row[1]
            elif row[0] == "CI":
                assert not zero
                dest = row[2]
                spare_extra = 1
            else:
                assert row[0] == "CD"
                runs[row[1]] = (1, False) if zero else (2, True)
                dest = row[3] if zero else row[2]
                gap_extra = int(not zero)
            after_runs = list(runs)
            if row[0] == "CI":
                minimum, variable = after_runs[row[1]]
                after_runs[row[1]] = (minimum+1, variable)
            elif row[0] == "CD" and not zero:
                minimum, variable = after_runs[row[1]]
                after_runs[row[1]] = (minimum-1, variable)
            shifted = dest == 0 and old[pc][1] != "CC"
        elif mode == "defer":
            assert pc-1 in heads and not zero
            runs[0], runs[5], runs[7] = (2, True), (1, False), (1, False)
            after_runs, dest, shifted = list(runs), pc+1, False
        else:
            assert mode == "tail" and pc-2 in heads
            runs[0], runs[7] = (2, True), (1, False)
            runs[6] = (1, False) if zero else (2, True)
            after_runs = list(runs)
            after_runs[5] = (2, True)
            if not zero:
                after_runs[6] = (1, True)
            dest = (pc+1) % len(old) if zero else pc
            shifted = zero and dest == 0
            spare_extra, gap_extra = 1, int(not zero)
        gap_extra += int(shifted)
        assert trace["runs"] == [list(run) for run in runs]
        left, right = map(deque, frame(pc, runs))
        position, clock = [0]*12, [0]*12
        orientation, state, local_edges = 1, root, set()
        for action in trace["actions"]:
            assert isinstance(action, int)
            if action > 0:
                for _ in range(action):
                    assert state >= 0
                    ahead, behind = (right, left) if orientation == 1 else (left, right)
                    bit = ahead.popleft() if ahead else "0"
                    assert isinstance(bit, str)
                    local_edges.add((state, int(bit)))
                    write, move, state = table[2*state+int(bit)]
                    clock[0] += 1
                    position[0] += move
                    if move == orientation:
                        behind.appendleft(write)
                    else:
                        ahead.appendleft(write)
                        orientation = -orientation
                literal_steps += action
                continue
            ahead, behind = (right, left) if orientation == 1 else (left, right)
            assert ahead and isinstance(ahead[0], tuple)
            index, unit = ahead.popleft()
            assert 0 <= index <= 10
            if action == 0:
                assert ahead and ahead[0] == unit[0]
                bit = ahead.popleft()
                ahead.appendleft((index, unit[1:]+bit))
                ahead.appendleft(bit)
                rotations += 1
                continue
            pump_index = -action-1
            p = pumps[pump_index]
            local_edges.update(pump_edges[pump_index])
            assert (state, orientation, unit) == (p["q"], p["dir"], p["unit"])
            for expected in reversed(p["context"]):
                assert (behind.popleft() if behind else "0") == expected
            behind.appendleft((index, p["output"][::-1]))
            for bit in p["context"]:
                behind.appendleft(bit)
            clock[index+1] += p["ticks"]
            position[index+1] += len(unit)*orientation
            pump_uses += 1
        assert clock == trace["clock"], (number, "clock")
        assert clock[0] > 0 and all(value >= 0 for value in clock)
        used_edges.update(local_edges)
        if mode != "ordinary":
            per_phase_edges[f"{pc}/{mode}/{int(zero)}"] = [[names[q], bit] for q, bit in sorted(local_edges)]
        if dest is None:
            assert state == -1
            halts += 1
            continue
        assert state == root and position == [-int(shifted)]+[0]*11, (number, "head")
        if orientation == -1:
            bit = left.popleft() if left else "0"
            assert isinstance(bit, str)
            right.appendleft(bit)
        target_left, target_right = frame(dest, after_runs, gap_extra, spare_extra)
        assert normal(left) == normal(target_left), (number, "left endpoint")
        assert normal(right) == normal(target_right), (number, "right endpoint")

    # Startup is replayed literally, including every bit of its final tape.
    boot_path = ROOT / "deliverables/reference_snapshot/baseline198/boot.json"
    boot = json.loads(boot_path.read_bytes())["final"]
    tape, state, head, boot_edges = set(), ids["k:64"], 0, set()
    for _ in range(boot["step"]):
        assert state >= 0
        bit = int(head in tape)
        boot_edges.add((state, bit))
        write, move, state = table[2*state+bit]
        (tape.add if write == "1" else tape.discard)(head)
        head += move
    assert state == root and head == boot["head"] and sorted(tape) == boot["ones"]
    assert boot["frame"]["registers"] == [3]+[0]*8
    assert boot["frame"]["ordinal"] == 0 and boot["frame"]["gap"] == 49
    assert len(boot["frame"]["spares"]) == 31 and not any(boot["frame"]["spares"])
    all_edges = used_edges | boot_edges
    result = {
        "format": "nf-independent-rotated-m65-receipt-v1",
        "table_sha256": TABLE_SHA, "states": len(names), "binary_rows": len(rows),
        "primitive_source_sha256": OLD_SHA, "collapsed_source_sha256": SOURCE_SHA,
        "trace_sha256": digest(cert_raw), "checker_sha256": digest(Path(__file__).read_bytes()),
        "complete_ordinary_natural_domains": ordinary_count,
        "complete_guarded_phase_domains": len(cert["traces"])-ordinary_count,
        "macro_heads": len(heads), "pumps_checked": len(pumps),
        "literal_steps_replayed": literal_steps, "pump_applications": pump_uses,
        "word_rotations": rotations, "halting_ordinary_branches": halts,
        "source_invariant": invariant,
        "startup_steps": boot["step"], "startup_head": head,
        "startup_gap": boot["frame"]["gap"], "startup_zero_spares": 31,
        "covered_states_with_startup": len({q for q, bit in all_edges}),
        "covered_arms_with_startup": len(all_edges),
        "macro_contract": "R5+=R6; R6=0; gap+=old_R6+wrap; spares+=old_R6; head-=wrap",
        "proof": "Rotated197.md; induction on the natural donor at each rotated tail",
        "status": "all finite universal phase certificates, source guards, and literal startup independently checked",
        "seconds": round(time.monotonic()-started, 3),
    }
    (directory / "independent-receipt.json").write_text(json.dumps(result, indent=2)+"\n")
    (directory / "phase-edge-coverage.json").write_text(json.dumps(per_phase_edges, separators=(",", ":"))+"\n")
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    audit(Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else DIRECTORY)
