"""Build and freshly replay the compact, portable 197-state certificate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'deliverables'
SPRINT = 'sprint_20261124_1155'
AUDIT = f'{SPRINT}/audit'
PREFIX = 'NFCS_197_Certificate_2026-11-24'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    frozen_path = ROOT/AUDIT/'loop197_m65/manifest.json'
    frozen = json.loads(frozen_path.read_bytes())
    for relative, entry in frozen['files'].items():
        raw=(ROOT/relative).read_bytes()
        assert len(raw)==entry['bytes'] and digest(raw)==entry['sha256'],relative
    selected=set(frozen['files'])|set(frozen['dependencies'])
    selected.add(frozen_path.relative_to(ROOT).as_posix())
    selected.update(p.relative_to(ROOT).as_posix() for p in (ROOT/SPRINT/'root_audit197').iterdir() if p.is_file())
    selected.update(['deliverables/reference_snapshot/Ground-calibration.md',
                     'deliverables/reference_snapshot/Parent-calibration.md',
                     'deliverables/build_197_certificate.py',
                     'deliverables/verify_bundle.py'])
    readme = '''NF+CS: COMPLETE 197-STATE PHYSICAL CERTIFICATE
R. Gutin and E. Glazer
24 November 2026

The machine has 197 working states over a binary tape alphabet, begins on
blank tape in state k:64, and has one distinguished halting target. This
package independently verifies its implementation of the same calibrated
numerical source search as the earlier 198-state machine.

Table SHA-256:
948492f1d299acb09b0d3464c5de7ef6e5d510bc09398324a9610c65f52cbbf3

Read sprint_20261124_1155/audit/Rotated197.md for the full phase contracts,
natural-number loop induction, source guards, resource accounting, exact
state change, and calibration boundary. This is a universal symbolic
certificate, not a claim based only on bounded sample executions.

From this extracted directory, with Python 3 and its standard library:

  python3 sprint_20261124_1155/root_audit197/check_source_startup.py
  python3 sprint_20261124_1155/audit/check_rotated197.py

The first command independently reconstructs all 29 exact source collapses,
checks the threshold invariant, verifies the literal table quotient, and
executes blank startup. The second independently replays 5,605 ordinary
natural domains and 145 guarded phase domains using 20 literal pump lemmas.
It reconstructs every symbolic endpoint and checks the source guards and
blank startup. The written induction composes these phases into all29
unbounded transfers. Both commands write fresh receipts in their own
directories. The physical proof needs no third-party package, compiler,
network connection, or Lean installation.

The BUNDLE_MANIFEST.json file binds every included byte before replay.
Replaying regenerates receipts, including elapsed-time fields, so those
generated receipt bytes may differ afterward. The original certificate,
table, source, invariant, and checker files must remain unchanged.

The full historical research checkpoint contains the earlier machines,
broader VM experiments, and calibration artifacts. This compact package
preserves the calibration distinction explained in Ground-calibration.md:
it does not claim a new Lean kernel run or a stronger NF/NFU/CS comparison.
'''
    files={relative:(ROOT/relative).read_bytes() for relative in sorted(selected)}
    files['README.txt']=readme.encode()
    inventory=[{'path':p,'bytes':len(raw),'sha256':digest(raw)} for p,raw in sorted(files.items())]
    manifest={'format':'nfcs-compact-universal-certificate-v1',
              'created_utc':datetime.now(timezone.utc).isoformat(),
              'credits':['R. Gutin','E. Glazer'],
              'best_verified_working_states':197,
              'record_table_sha256':'948492f1d299acb09b0d3464c5de7ef6e5d510bc09398324a9610c65f52cbbf3',
              'files':inventory}
    output=OUT/(PREFIX+'.zip')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for relative,raw in files.items():archive.writestr(PREFIX+'/'+relative,raw)
        archive.writestr(PREFIX+'/BUNDLE_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    check=subprocess.run([sys.executable,str(OUT/'verify_bundle.py'),str(output)],capture_output=True,text=True)
    assert check.returncode==0,check.stdout+check.stderr
    temporary=Path(tempfile.mkdtemp(prefix='nfcs197-replay-'))
    with zipfile.ZipFile(output) as archive:archive.extractall(temporary)
    extracted=temporary/PREFIX
    results=[]
    for relative in [f'{SPRINT}/root_audit197/check_source_startup.py',f'{AUDIT}/check_rotated197.py']:
        run=subprocess.run([sys.executable,relative],cwd=extracted,capture_output=True,text=True,timeout=120)
        result={'command':['python3',relative],'returncode':run.returncode,
                'stdout':run.stdout,'stderr':run.stderr}
        results.append(result)
        assert run.returncode==0,result
    summary={'created_utc':datetime.now(timezone.utc).isoformat(),
             'archive':str(output),'archive_bytes':output.stat().st_size,
             'archive_sha256':digest(output.read_bytes()),'files':len(inventory)+1,
             'manifest_verification':json.loads(check.stdout),'fresh_extraction':str(extracted),
             'checks':results,'status':'all_checks_passed'}
    (OUT/'197-relocation-receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
    # Freeze a standard manifest for the larger historical archive as well.
    accepted=ROOT/SPRINT/'accepted';accepted.mkdir(exist_ok=True)
    accepted_manifest={'format':'nfcs-accepted-machine-evidence-v1',
                       'credits':['R. Gutin','E. Glazer'],
                       'claims':[{'label':'rotated197','states':197,
                                  'table_sha256':manifest['record_table_sha256'],
                                  'status':'complete universal physical certificate and source refinement',
                                  'calibration':'unchanged existing numerical NF+CS calibration; no fresh Lean run'}],
                       'files':[e for e in inventory if e['path']!='README.txt'],
                       'reproduction_commands':[['python3',f'{SPRINT}/root_audit197/check_source_startup.py'],
                                                ['python3',f'{AUDIT}/check_rotated197.py']]}
    (accepted/'manifest.json').write_text(json.dumps(accepted_manifest,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='checks'},indent=2))


if __name__=='__main__':main()
