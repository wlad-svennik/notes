"""Verify archive hashes without extracting or executing research code."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

archive_path = Path(sys.argv[1])
with zipfile.ZipFile(archive_path) as archive:
    manifests = [n for n in archive.namelist() if n.endswith('/BUNDLE_MANIFEST.json')]
    assert len(manifests) == 1
    manifest_name = manifests[0]
    prefix = manifest_name.removesuffix('BUNDLE_MANIFEST.json')
    manifest = json.loads(archive.read(manifest_name))
    names = {prefix+e['path'] for e in manifest['files']} | {manifest_name}
    assert len(names) == len(archive.namelist()) and names == set(archive.namelist())
    for entry in manifest['files']:
        data = archive.read(prefix+entry['path'])
        assert len(data) == entry['bytes'], entry['path']
        assert hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
    print(json.dumps({'archive': str(archive_path), 'verified_files': len(manifest['files']),
                      'best_verified_working_states': manifest['best_verified_working_states']}))
