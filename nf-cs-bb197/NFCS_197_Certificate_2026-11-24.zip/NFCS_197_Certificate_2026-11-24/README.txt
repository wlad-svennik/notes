NF+CS: COMPLETE 197-STATE PHYSICAL CERTIFICATE
R. Gutin and E. Glazer
24 November 2026

The machine has 197 working states over a binary tape alphabet, begins on
blank tape in state k:64, and has one distinguished halting target. This
package independently verifies its implementation of the same calibrated
numerical source search as the earlier 198-state machine.

Table SHA-256:
948492f1d299acb09b0d3464c5de7ef6e5d510bc09398324a9610c65f52cbbf3

Read sprint_20261124_1155/audit/Rotated197.md for the full phase contracts,
natural-number loop induction, source guards, resource accounting, exact
state change, and calibration boundary. This is a universal symbolic
certificate, not a claim based only on bounded sample executions.

From this extracted directory, with Python 3 and its standard library:

  python3 sprint_20261124_1155/root_audit197/check_source_startup.py
  python3 sprint_20261124_1155/audit/check_rotated197.py

The first command independently reconstructs all 29 exact source collapses,
checks the threshold invariant, verifies the literal table quotient, and
executes blank startup. The second independently replays 5,605 ordinary
natural domains and 145 guarded phase domains using 20 literal pump lemmas.
It reconstructs every symbolic endpoint and checks the source guards and
blank startup. The written induction composes these phases into all29
unbounded transfers. Both commands write fresh receipts in their own
directories. The physical proof needs no third-party package, compiler,
network connection, or Lean installation.

The BUNDLE_MANIFEST.json file binds every included byte before replay.
Replaying regenerates receipts, including elapsed-time fields, so those
generated receipt bytes may differ afterward. The original certificate,
table, source, invariant, and checker files must remain unchanged.

The full historical research checkpoint contains the earlier machines,
broader VM experiments, and calibration artifacts. This compact package
preserves the calibration distinction explained in Ground-calibration.md:
it does not claim a new Lean kernel run or a stronger NF/NFU/CS comparison.
