"""Check the register control graph against the published guarded 187-state source."""
from bisect import bisect_left
import hashlib,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def decode(rows):
    ends={}
    for i,(path,op,arg) in enumerate(rows):
        for j in range(len(path)+1):
            lo=ends.get(path[:j],(i,i))[0];ends[path[:j]]=(lo,i+1)
    N=len(rows);result=[]
    for i,(path,op,arg) in enumerate(rows):
        following=(i+1)%N
        if op=='CI':result.append(('CI',arg,following));continue
        if op=='CD'and path[-1]=='1':result.append(('CD',arg,-1,following));continue
        side='1'if op=='CC'else'0';j=len(path)
        for _ in range(1 if op=='CD' else arg):
            j=path.rindex(side,0,j)
        branch=ends[path[:j]][int(side=='0')]%N
        result.append(('CD',arg,branch,following)if op=='CD'else('J',branch))
    return result
def project(i):
    if i<39:return i
    if i<=50:return 39
    if i<=3520:return i-11
    return i-10
def relocated(op):
    k=1 if op[0]=='J'else 2
    return (*op[:k],*(project(v)for v in op[k:]))
def main(base,candidate):
    o=decode(json.loads(base.read_bytes()));n=decode(json.loads(candidate.read_bytes()))
    assert len(o)==3642 and len(n)==3632
    assert o[3520]==('J',38)
    assert n[3509:3511]==[('CD',5,3511,3510),('J',38)]
    for i,op in enumerate(o):
        if i==3520 or 39<=i<50:continue
        assert n[project(i)]==relocated(op),(i,op,n[project(i)])
    assert o[38]==('CD',3,3521,39)
    assert n[38:42]==[('CD',3,3511,39),('CD',6,42,40),('CI',5,41),('J',39)]
    return sha(base),sha(candidate)
if __name__=='__main__':
    args=list(map(Path,sys.argv[1:]))
    if not args:args=[HERE/'Published187.sites.json',HERE/'source.sites.json']
    print('Verified every register control destination. SHA-256',*main(*args),sep='\n')
