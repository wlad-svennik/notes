#include "frame.hpp"

int main(int argc, char **argv) {
    if (argc != 3) return 2;
    try {
        Source source(argv[1]);
        Machine machine(argv[2]);
        long long ticks = 0;
        for (int pc = 0; pc < static_cast<int>(source.rows.size()); ++pc) {
            const Row &row = source.rows[pc];
            for (int variant = 0; variant < 4; ++variant) {
                Frame frame{pc, center, center + 55 + variant, {}, vector<int>(28 + variant, 0)};
                for (int i = 0; i < 9; ++i)
                    frame.regs[i] = variant < 2 ? variant : (variant + i) % 6;
                if (variant == 3 && !(row.op == "CD" && row.a == 0))
                    frame.regs[0] = -1;
                Run run{machine.d0, center, encode(source, frame)};
                ticks += complete(source, machine, run, frame);
            }
        }
        cout << 4 * source.rows.size() << " concrete register cases passed, "
             << ticks << " binary transitions\n";
    } catch (const exception &error) {
        cerr << error.what() << "\n";
        return 1;
    }
}
