import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank186.Boot
open NF210 NF192 Blank186.Table
theorem chunk25900 : Prefix 700 snap25200 snap25900 := checked _ _ _ (by decide) (by decide)
theorem chunk26600 : Prefix 700 snap25900 snap26600 := checked _ _ _ (by decide) (by decide)
theorem chunk27300 : Prefix 700 snap26600 snap27300 := checked _ _ _ (by decide) (by decide)
theorem chunk28000 : Prefix 700 snap27300 snap28000 := checked _ _ _ (by decide) (by decide)
theorem chunk28700 : Prefix 700 snap28000 snap28700 := checked _ _ _ (by decide) (by decide)
theorem chunk29400 : Prefix 700 snap28700 snap29400 := checked _ _ _ (by decide) (by decide)
theorem chunk30100 : Prefix 700 snap29400 snap30100 := checked _ _ _ (by decide) (by decide)
theorem chunk30800 : Prefix 700 snap30100 snap30800 := checked _ _ _ (by decide) (by decide)
theorem chunk31500 : Prefix 700 snap30800 snap31500 := checked _ _ _ (by decide) (by decide)
theorem chunk32200 : Prefix 700 snap31500 snap32200 := checked _ _ _ (by decide) (by decide)
theorem chunk32900 : Prefix 700 snap32200 snap32900 := checked _ _ _ (by decide) (by decide)
theorem chunk33600 : Prefix 700 snap32900 snap33600 := checked _ _ _ (by decide) (by decide)
end Blank186.Boot
