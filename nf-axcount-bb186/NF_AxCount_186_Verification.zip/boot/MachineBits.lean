module
public import NF210.MachineSemantics
@[expose] public section

/-!
# A bit-packed finite evaluator with a checked ordinary-TM semantics

The vector evaluator remains available. This evaluator uses a natural number
for the finite window, so proof reduction does not repeatedly rebuild a vector
for every cell write. Its soundness is proved for arbitrary outside tape; the
only concrete execution checks below the final interface are kernel reduction.
-/

namespace NF192.KernelBits

open NF210 NF210.TM

variable {states : Nat}

def writeBit (bits index : Nat) (symbol : Bool) : Nat :=
  if bits.testBit index = symbol then bits else bits ^^^ (1 <<< index)

theorem mask_bit (index position : Nat) :
    (1 <<< index : Nat).testBit position = decide (index = position) := by
  simp [Nat.shiftLeft_eq, Nat.testBit_two_pow]

theorem writeBit_spec (bits index position : Nat) (symbol : Bool) :
    (writeBit bits index symbol).testBit position =
      if index = position then symbol else bits.testBit position := by
  by_cases same : index = position
  · subst position
    by_cases already : bits.testBit index = symbol
    · simp [writeBit, already]
    · simp only [writeBit, ite_eq_right already, Nat.testBit_xor, mask_bit, decide_true, ite_true]
      cases cell : bits.testBit index <;> cases symbol <;> simp_all
  · by_cases already : bits.testBit index = symbol
    · simp [writeBit, already, same]
    · rw [writeBit, ite_eq_right already, Nat.testBit_xor, mask_bit]
      simp [same]

structure Configuration (states : Nat) where
  state : Option (Fin states)
  head : Nat
  bits : Nat
  deriving DecidableEq, Repr

def step (machine : Machine states) (width : Nat)
    (before : Configuration states) : Option (Configuration states) :=
  if before.head < width then
    match before.state with
    | none => some before
    | some state =>
      let instruction := machine state (before.bits.testBit before.head)
      let bits := writeBit before.bits before.head instruction.write
      match instruction.move with
      | .left =>
        if 0 < before.head then
          some {state := instruction.next, head := before.head - 1, bits := bits}
        else none
      | .right =>
        if before.head + 1 < width then
          some {state := instruction.next, head := before.head + 1, bits := bits}
        else none
  else none

def run (machine : Machine states) (width : Nat) : Nat → Configuration states → Option (Configuration states)
  | 0, before => some before
  | time + 1, before => (run machine width time before).bind (step machine width)

def tape (width : Nat) (anchor : Int) (outside : Tape) (bits : Nat) : Tape :=
  fun position =>
    if 0 ≤ position - anchor ∧ position - anchor < (width : Int) then
      bits.testBit (position - anchor).toNat
    else outside position

def embed (width : Nat) (anchor : Int) (outside : Tape)
    (configuration : Configuration states) : TM.Configuration states :=
  {state := configuration.state, head := anchor + (configuration.head : Int),
   tape := tape width anchor outside configuration.bits}

theorem tape_read (width index bits : Nat) (inside : index < width) (anchor : Int) (outside : Tape) :
    tape width anchor outside bits (anchor + (index : Int)) = bits.testBit index := by
  have bounded : 0 ≤ anchor + (index : Int) - anchor ∧
      anchor + (index : Int) - anchor < (width : Int) := by omega
  have same : (anchor + (index : Int) - anchor).toNat = index := by omega
  simp only [tape, ite_eq_left bounded, same]

theorem tape_write (width index bits : Nat) (inside : index < width)
    (anchor : Int) (outside : Tape) (symbol : Bool) :
    tape width anchor outside (writeBit bits index symbol) =
      writeTape (tape width anchor outside bits) (anchor + (index : Int)) symbol := by
  funext position
  by_cases same : position = anchor + (index : Int)
  · subst position
    rw [tape_read width index _ inside, writeTape_at, writeBit_spec]
    simp
  · by_cases bounded : 0 ≤ position - anchor ∧ position - anchor < (width : Int)
    · have different : index ≠ (position - anchor).toNat := by omega
      simp only [tape, ite_eq_left bounded, writeTape, ite_eq_right same,
        writeBit_spec, ite_eq_right different]
    · simp only [tape, ite_eq_right bounded, writeTape, ite_eq_right same]

theorem step_sound (machine : Machine states) (width : Nat) (anchor : Int) (outside : Tape)
    (before after : Configuration states) (inside : before.head < width)
    (accepted : step machine width before = some after) :
    after.head < width ∧
      TM.step machine (embed width anchor outside before) = embed width anchor outside after := by
  cases current : before.state with
  | none =>
    have same : before = after := by
      simpa only [step, ite_eq_left inside, current, Option.some.injEq] using accepted
    subst after
    exact ⟨inside, by simp only [TM.step, embed, current]⟩
  | some state =>
    let instruction := machine state (before.bits.testBit before.head)
    cases direction : instruction.move with
    | left =>
      by_cases positive : 0 < before.head
      · have result : after =
            {state := instruction.next, head := before.head - 1,
             bits := writeBit before.bits before.head instruction.write} := by
          simpa only [step, ite_eq_left inside, current, instruction, direction,
            ite_eq_left positive, Option.some.injEq] using accepted.symm
        rw [result]
        constructor
        · change before.head - 1 < width
          omega
        · simp only [TM.step, embed, current, tape_read width before.head before.bits inside]
          change TM.Configuration.mk instruction.next
            (moveHead instruction.move (anchor + (before.head : Int)))
            (writeTape (tape width anchor outside before.bits)
              (anchor + (before.head : Int)) instruction.write) = _
          rw [← tape_write width before.head before.bits inside anchor outside instruction.write, direction]
          simp only [moveHead]
          congr 1
          omega
      · simp only [step, ite_eq_left inside, current, instruction, direction,
          ite_eq_right positive] at accepted
        contradiction
    | right =>
      by_cases bounded : before.head + 1 < width
      · have result : after =
            {state := instruction.next, head := before.head + 1,
             bits := writeBit before.bits before.head instruction.write} := by
          simpa only [step, ite_eq_left inside, current, instruction, direction,
            ite_eq_left bounded, Option.some.injEq] using accepted.symm
        rw [result]
        constructor
        · exact bounded
        · simp only [TM.step, embed, current, tape_read width before.head before.bits inside]
          change TM.Configuration.mk instruction.next
            (moveHead instruction.move (anchor + (before.head : Int)))
            (writeTape (tape width anchor outside before.bits)
              (anchor + (before.head : Int)) instruction.write) = _
          rw [← tape_write width before.head before.bits inside anchor outside instruction.write, direction]
          simp only [moveHead]
          congr 1
          omega
      · simp only [step, ite_eq_left inside, current, instruction, direction,
          ite_eq_right bounded] at accepted
        contradiction

theorem run_sound (machine : Machine states) (width : Nat) (anchor : Int) (outside : Tape)
    (duration : Nat) (before after : Configuration states) (inside : before.head < width)
    (accepted : run machine width duration before = some after) :
    after.head < width ∧
      TM.run machine duration (embed width anchor outside before) = embed width anchor outside after := by
  induction duration generalizing after with
  | zero =>
    have same : before = after := by simpa only [run, Option.some.injEq] using accepted
    subst after
    exact ⟨inside, rfl⟩
  | succ duration ih =>
    cases previous : run machine width duration before with
    | none =>
      simp only [run, previous, Option.bind_none] at accepted
      contradiction
    | some middle =>
      have last : step machine width middle = some after := by
        simpa only [run, previous, Option.bind_some] using accepted
      have first := ih middle previous
      have second := step_sound machine width anchor outside middle after first.1 last
      refine ⟨second.1, ?_⟩
      rw [TM.run_succ, first.2, second.2]

end NF192.KernelBits
