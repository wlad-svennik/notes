import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank186.Boot
open NF210 NF192 Blank186.Table
theorem chunk75311 : Prefix 411 snap74900 snap75311 := checked _ _ _ (by decide) (by decide)
end Blank186.Boot
