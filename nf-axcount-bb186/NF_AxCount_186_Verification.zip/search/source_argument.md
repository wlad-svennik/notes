# The 186-state census source

This argument concerns the binary table with SHA-256 `d28dadaca7c74e79bec2f2b5f0fc2f2a08275439a2c1b8b64632d932d023eab2` and the 3,632-site register program with SHA-256 `0fd0378211283f28bdd10a279aa8c96184be2f43ea20d16390222630f7cf1799`. Program counters below start at zero.

## Literal register program

Run `python3 search/check_source.py` from the extracted directory. The standalone copy also accepts explicit `--parent` and `--machine` paths. The checker authenticates the released parent register program, the candidate register program and the candidate table. It compares every retained register operation and the destinations of its positive, zero, and unconditional branches. It checks the entry, fallthrough and loop jumps of the modified AX code separately.

The old 14-instruction reader at parent PCs 39–52 was an unpair into R6 followed by transfer from R6 to R5. The new program retains only the transfer at 39–41. The parent register proof's AX-entry invariant sets R6 and R7 to zero, and its nine-row emitter restores those scratch registers to zero. Thus this transfer has no register effect. Every remaining AX batch consumes one input field, the nonnegative addition to R4 made by the original inner reader. Its nine schemas are exactly the parent's since the entire emitting word, parent PCs 53–3519, has matching operations and internal jump destinations at new PCs 42–3508.

At site 3509, positive R5 loses one unit and the jump at 3510 enters the batch test at 38. Zero R5 exits to 3511. Site 38 decrements positive R3 and enters another batch, or exits to 3511 on zero. The parent compiled outer fields, arithmetic constructors, MODE comparison, proof-stack operations, and sole goal test retain their control flow.

## Exact AX counter transition

A command reads selector \(s\) and outer increment \(u_0\); its incoming R3 carry is \(r\). If \(s+r\) is 0 or 1 it takes the ordinary MP or MODE arm and exits with carry zero. If \(s+r\ge2\), write \(C=s+r-2\) and let \(B\) be the entry cache. At batch index \(i=0,\ldots,\min(B,C)\) the emitted row parameters are

\[
  b=B-i,\qquad c=C-i,\qquad a=u+\delta,
\]

where \(u\) is the current R4, initially the incoming parameter plus \(u_0\), and \(\delta\) is that batch's raw field. R4 becomes \(a\) for the next batch. The final carry is \(C-\min(C,B)\). This follows by inspecting 3509 and 38. The source always emits the batch before either exit test. The outgoing comparison cache before the common post-AX code is at most the final emitted \(b\).

Write \(z\) for the final extensionality formula. The original bound \(b<\operatorname{imp}(z,a)\) still excludes accidental MODE detachment on the AX return. Indeed, \(z\) is an implication with consequent \(\operatorname{eqn}(a,b)\), which exceeds \(b\). Every implication dominates both its arguments. The post-AX normal form is therefore the original `afterAX` on the chronological concatenation of all emitted rows. Its TOP and parameter are zero. It drops the last emitted formula, places the penultimate formula in the cache, and puts all preceding formulas in reverse order above the incoming TOP and stack. Every batch has nine formulas, and its penultimate formula is the positive-valued marker `testRow b a`. In particular it is at least 1 for every pair of inputs.

Soundness can use the full parent calculus. Each emitted formula, including the discarded last formula, is an instance of a parent schema. The other actions only detach a syntactically matching implication, move proved formulas, or supply the theorem 0. Thus an arbitrary carry can change the action selected and the number of fields consumed while preserving the invariant that TOP, every stack entry, and the cache are derivable. The single stop tests cache code 3.

## One finite word for each required row

Start at a command boundary with carry zero. The parent sweep consists of AX with selector 2 and zero fields, followed by seven nips. It emits exactly nine formulas for every incoming cache and parameter, including cache zero. It leaves TOP zero with the incoming TOP pushed and leaves parameter zero. Two sweeps followed by MODE 0 give exactly TOP zero, cache zero, parameter zero, carry zero, and the original TOP pushed once; the two sweep cache values do not affect this result. This is the original `reset_results` calculation, with one zero inner field for each one-batch AX. The reset is uniform over every incoming proof payload.

From that normalized state, a one-batch AX with outer field \(v\) and inner field zero emits the K-law formula \(h=\operatorname{eqn}((K0)v,0)\) in its second position. Its raw natural code is at least \(v\), by monotonicity of the Cantor pair in each argument. Its position, and the number of rows to remove around it, are fixed. Use the parent `extract_rows` nips and swap to select it, restore the saved proof prefix, and swap \(h\) into cache with `MP 1`. The usual final nip in a `Builds` word places cache zero before that swap. Thus the new TOP is a known zero, \(h\) is the cache, and the original TOP and stack remain available below. Any accidental early observation of 3 has already met the detecting condition. The unchecked run gives the stated state in every case.

For prescribed \(a,b,c,u\) with \(u\le a\), take \(v=b\), set \(i=h-b\), and use outer selector \(i+c+2\) and outer parameter increment \(u\). Supply zero at all batches before \(i\), supply \(a-u\) at batch \(i\), and use zero for subsequent batch fields. The retained-cache and counter formulas give exactly \((a,b,c,u)\) at index \(i\). The program reaches that index since both entry counters are at least \(i\). The number of fields actually consumed is fixed by these known counters. A continuation can be placed immediately after them.

The first seven rows of the selected batch remain on the stack even if it is the final batch. To recover a row when there is carry \(r>0\), issue AX commands with selector 2 and all fields zero. For each such command the new carry is \(r-\min(r,B')\), where \(B'\) is its entry cache. The previous AX has installed a positive marker, and each cleanup AX installs another. Carry consequently drops at least one per cleanup until it reaches zero. Each cleanup only pushes a known finite block above the older stack. The mandatory stack operations can then be counted from the explicit batch counts. Nip to the chosen row, swap it to TOP, and nip the remaining known rows above the saved prefix. This is the list argument of `nips_to`, `nips_over` and `extract_rows`; it works at any indexed stack occurrence. The extra known TOP zero left by the seed swap is also nipped. None of these counts uses the incoming proof-stack content.

The eighth, penultimate marker depends on \(a,b\) alone. Always choose \(c=0\) for that family. The selected occurrence is the last batch's cache, with carry zero. A swap followed by the known nips extracts it without exposing it to a cleanup AX.

For the ninth, extensionality family with \(b>0\), choose \(c=1\). The selected batch has at least one successor batch, so all nine rows of the selected batch enter the stack. The last batch has \(c=0\) and its new carry is zero. The indexed extraction applies to the ninth row as well. No step needs the ninth family with second argument zero.

Each selected row can therefore be built by a fixed finite raw word that puts it on TOP, preserves the incoming TOP and stack underneath, and finishes with carry and parameter zero. The seed, the entire schedule of batch counts, and all cleanup lengths depend only on the chosen row parameters. Raw concatenation pairs fields in reverse order and adds the ordinary single continuation unit at each physical command boundary. The resulting word accepts any required following payload.

Clean-boundary MP and MODE still implement the parent's two-premise composition. Compose the row constructors recursively by the parent `builds_mp` argument. If 3 has a proof, prefix the resulting constructor by the uniform reset and append `MP 1, MP 0` as in the parent's `exists_detecting_word`. This gives one fixed finite encoded suffix that detects 3 from every clean command boundary, including arbitrary incoming TOP, stack, cache and parameter.

`CensusSelector.lean` checks the closed batch count, carry and row-index formulas, the growing K seed and the strict decrease in a cleanup. `CensusStack.lean` checks the return comparison and parent-calculus soundness of AX batches. `CensusExtract.lean` checks the two-sweep reset for arbitrary nine-row lists and the two indexed extraction calculations. These lemmas use the same MP, MODE, nip and post-AX stack definitions as the parent.

## The missing orientation of extensionality

`CensusLogic.lean` defines a Hilbert calculus retaining rows 1–8 for every parameter and extensionality for positive second argument. Its last list entry duplicates the always-present K row at second argument zero. Modus ponens is the sole inference. Its propositional axiom is unchanged, including the dominated parameter condition.

`CensusChart.lean` proves `NF180Counting.CensusLogic.goal_iff_full`: code 3 is derivable in this calculus exactly when it is derivable in the released full NF+AxCount calculus. The proof does not identify the two raw Skolem witnesses. On the natural-number presentation take

\[
  H'(x,y)=\begin{cases}H(0,x)&y=0,\\H(x,y)&y>0.\end{cases}
\]

The diagonal operation \(H'(x,x)=H(x,x)\) is unchanged. The K and Euclidean laws give reflexivity and symmetry of the canonical equality relation before any use of extensionality. For \(x>0,y=0\), apply symmetry to the proposed equality of their applications to \(H(0,x)\), apply the available extensionality row for \((0,x)\), and use symmetry again. For \(x=y=0\), use reflexivity. This supplies every extensionality row for the revised signature, and the other algebraic rows use only its diagonal. Taking the quotient then gives the parent's marked chart and the same guarded Counting law. In the reverse direction each census axiom is already a parent axiom. Lean reports only `propext`, `Classical.choice`, and `Quot.sound` for the equivalence.

## Scope of this argument

The raw detector's equivalence to the full calculus combines this source analysis with two separate certificates: (i) the signed tape-to-register simulation from blank and (ii) occurrence of a clean universal detecting suffix in the actual fresh-integer enumeration despite possible carry. The source comparison, row realizability, and chart argument above are independent of the enumeration synchronizer. The final manuscript-level comparison of the parent guarded calculus with pure NF+AxCount retains the original v15 assumptions and status.
