"""Independent bounded spot checks directly on integer cursors, including misaligned batch reads."""
from functools import lru_cache
from math import isqrt
import itertools
MARKER=((0,1),(1,0),(0,1),(1,0),(0,2),(2,1,3))
def pair(a,b):return (a+b)*(a+b+1)//2+b
@lru_cache(None)
def unpair(x):
    s=(isqrt(8*x+1)-1)//2
    b=x-s*(s+1)//2
    return s-b,b
def encode(fields,rest):
    for v in reversed(fields):rest=pair(v,rest)
    return rest+1
def run_cases(tail):
    cursor=tail;boundaries=[cursor]
    for fields in reversed(MARKER):
        cursor=encode(fields,cursor);boundaries.append(cursor)
    boundaries=set(boundaries)
    # Large enough for all cursor bounds. Tests cover exact small caches and a deliberately conservative choice of large markers.
    big=32*(cursor+100)**4;small=100
    cache_values=(0,1,2,3,6,12,33,small,big)
    def batch(rank,cache,p,large):
        need=rank-1;done=min(need,cache+1);remaining=done
        while p and remaining:
            _,p=unpair(p);remaining-=1
        h=big if large or cache>big//2 and done<big//4 else small
        return need-done,h,p
    @lru_cache(None)
    def check(r,h,p,stage):
        if not p:return (not r) if stage==1 else h>=r
        if not r and p in boundaries:return True
        assert p>0
        rank,q=unpair(p-1);_,q=unpair(q);rank+=r
        if rank<2:return all(check(0,v,q,stage)for v in cache_values)
        rn,m,q=batch(rank,h,q,False)
        return check(rn,m,q,stage)and (m==big or check(rn,big,q,stage))
    trials=0
    for stage,tag in ((1,1),(2,2)):
        for r,h in itertools.product([*range(16),23,57,103,1000,10000],cache_values):
            if stage==1 and h<r:continue
            p=cursor-tag
            if r<2:ok=all(check(0,v,p,stage)for v in cache_values)
            else:
                rn,h,q=batch(r,h,p,True);ok=check(rn,h,q,stage)
            assert ok,(stage,r,h,tail)
            trials+=1
    return trials
if __name__=='__main__':
    print(sum(run_cases(q)for q in (1,2,7,15,57,91,203)),'integer-cursor spot checks passed')
