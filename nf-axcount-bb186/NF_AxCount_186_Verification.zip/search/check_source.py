"""Bind the census register program to the released 187-state register program."""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT_HASH = "8b40258cf8dde548d30f625804432d1c26c1668350a2a326e4c28e89837f1330"
SOURCE_HASH = "0fd0378211283f28bdd10a279aa8c96184be2f43ea20d16390222630f7cf1799"
TABLE_HASH = "d28dadaca7c74e79bec2f2b5f0fc2f2a08275439a2c1b8b64632d932d023eab2"

def load(path, expected):
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected, path
    return data

def edges(rows):
    span = {}
    for pc, (address, _, _) in enumerate(rows):
        for i in range(len(address) + 1):
            span.setdefault(address[:i], [pc, pc+1])[1] = pc+1
    def target(address, symbol, count):
        for _ in range(count):
            i = address.rfind(symbol)
            assert i >= 0
            address = address[:i]
        return span[address]
    count = len(rows)
    result = []
    for pc, (address, op, arg) in enumerate(rows):
        nxt = (pc + 1) % count
        if op == "CI":
            result.append((nxt,))
        elif op == "CD":
            zero = None if address.endswith("1") else target(address, "0", 1)[1] % count
            result.append((nxt, zero))
        elif op == "CB":
            result.append((target(address, "0", arg)[1] % count,))
        elif op == "CC":
            result.append((target(address, "1", arg)[0],))
        else:
            raise AssertionError(op)
    return result

def entered(pc):
    if pc is None or pc < 39: return pc
    if pc == 39: return 39
    if 50 <= pc <= 3520: return pc - 11
    if pc > 3520: return pc - 10
    raise AssertionError(("unexpected entry to deleted read",pc))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--parent", type=Path, default=HERE.parent/"Published187.sites.json")
    ap.add_argument("--machine", type=Path, default=HERE.parent)
    args=ap.parse_args()
    prior=json.loads(load(args.parent, PARENT_HASH))
    rows=json.loads(load(args.machine/"source.sites.json", SOURCE_HASH))
    table=load(args.machine/"candidate.tm",TABLE_HASH).decode().splitlines()
    assert table[0]=="#! start k:74"
    components=[r.split() for r in table[1:]]
    arms=Counter(q for q,*_ in components)
    assert len(arms)==186 and set(arms.values())=={2}
    assert len(prior)==3642 and len(rows)==3632
    e0,e1=edges(prior),edges(rows)
    for i,(address,op,arg) in enumerate(prior):
        if 39<=i<50 or i==3520: continue
        j=entered(i)
        assert rows[j][1:]==[op,arg],(i,j)
        assert e1[j]==tuple(map(entered,e0[i])),(i,j,e0[i],e1[j])
    assert [(r[1:],e1[i])for i,r in enumerate(rows)if 39<=i<=41]==[
        (["CD",6],(40,42)),(["CI",5],(41,)),(["CC",2],(39,))]
    assert rows[3509][1:]==["CD",5] and e1[3509]==(3510,3511)
    assert rows[3510][1:]==["CC",3] and e1[3510]==(38,)
    assert rows[38][1:]==["CD",3] and e1[38]==(39,3511)
    assert [r[1:] for r in rows[42:3509]]==[r[1:] for r in prior[53:3520]]
    print("186 states, 372 transitions, 3632 source sites. Matched every retained operation and successor.")
    print("The AX begins with the empty-scratch transfer at 39. Native row emission runs at 42..3508.")
    print("CD5 at 3509 sends a positive cache through 3510 to 38 and a zero cache to 3511.")

if __name__=="__main__": main()
