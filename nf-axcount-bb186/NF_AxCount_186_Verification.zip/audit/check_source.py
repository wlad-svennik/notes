"""Bind the nine-row certificate and raw command prefix to the released counting programs."""
import argparse
import hashlib
import io
import json
from itertools import product
from math import isqrt
from pathlib import Path
from zipfile import ZipFile, is_zipfile

PARENT_ARCHIVE='5ee48c1dea054b2ea3694f034dde2e9a7d4934c8f33a13e857747f25fd418440'
PARENT_SOURCE='8b40258cf8dde548d30f625804432d1c26c1668350a2a326e4c28e89837f1330'
SOURCE='0fd0378211283f28bdd10a279aa8c96184be2f43ea20d16390222630f7cf1799'
TABLE='d28dadaca7c74e79bec2f2b5f0fc2f2a08275439a2c1b8b64632d932d023eab2'
EXCERPT='37fe2364061b86c1ac7ea40461bd82fa6983e48644beab4e0cc6de35943ff94b'

def sha(data):return hashlib.sha256(data).hexdigest()

def read_parent(path):
    if not is_zipfile(path):return path.read_bytes(),None
    assert sha(path.read_bytes()) == PARENT_ARCHIVE
    with ZipFile(path) as z:
        src=z.read('source.sites.json')
        with ZipFile(io.BytesIO(z.read('upstream/NF180_verification.zip'))) as prior:
            pure=json.loads(prior.read('source.sites.json'))
        with ZipFile(io.BytesIO(z.read('upstream/Jpoint_Calibration.zip'))) as calibration:
            pdf=calibration.read('Jpoint_Calibration/references/Counting_comparisons_v15_excerpt.pdf')
        assert sha(pdf)==EXCERPT
        row=json.loads(z.read('calculus/row.json'))
    assert row['old_instruction_offset']==582
    ops=[]
    for token in row['word']:
        start,end=row['representatives'][token]
        ops.extend(r[1:] for r in pure[start:end])
    assert len(ops)==672
    return src,ops

def instructions(data):
    rows=json.loads(data); leaves=[i[0] for i in rows]; bounds={}
    assert leaves==sorted(set(leaves))
    for pc,path in enumerate(leaves):
        assert path and not(set(path)-{'0','1'})
        for k in range(len(path)+1):bounds.setdefault(path[:k],[pc,pc])[1]=pc+1
    tips=set(leaves)
    assert all((p+'0' in bounds)==(p not in tips) and (p+'1' in bounds)==(p not in tips) for p in bounds)
    edges=[]
    def climb(p,ch,count):
        for _ in range(count):
            a=p.rfind(ch); assert a>=0; p=p[:a]
        return p
    for pc,(path,op,arg) in enumerate(rows):
        fall=(pc+1)%len(rows)
        if op=='CI':dst=(fall,)
        elif op=='CD':dst=(fall,None if path.endswith('1') else bounds[climb(path,'0',1)][1]%len(rows))
        elif op=='CB':dst=(bounds[climb(path,'0',arg)][1]%len(rows),)
        else:
            assert op=='CC';dst=(bounds[climb(path,'1',arg)][0],)
        edges.append(dst)
    return rows,edges

def shifted(pc):
    if pc is None or pc<=39:return pc
    if 50<=pc<=3520:return pc-11
    assert pc>3520;return pc-10

def unpair(n):
    s=(isqrt(8*n+1)-1)//2;r=n-s*(s+1)//2
    return s-r,r

def prefix_trial(rows,edges,reg):
    epoch,top,stack,rank,param,cache,_,_,cursor=reg
    regs=reg[:];pc=0
    while pc!=37:
        _,op,r=rows[pc];dst=edges[pc]
        if op=='CD' and not regs[r]:pc=dst[1];continue
        if op=='CD':regs[r]-=1
        elif op=='CI':regs[r]+=1
        pc=dst[0]
    if cursor:
        tag,after=unpair(cursor-1);imm,tail=unpair(after);n=epoch
    else:
        tag=0;imm,tail=unpair(epoch);n=epoch+1
    assert regs==[n,top,stack,rank+tag,param+imm,cache,0,0,tail]

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('directory',type=Path);cli.add_argument('parent',type=Path);args=cli.parse_args()
    data=(args.directory/'source.sites.json').read_bytes();raw=(args.directory/'candidate.tm').read_bytes()
    previous,guard=read_parent(args.parent)
    assert (sha(previous),sha(data),sha(raw))==(PARENT_SOURCE,SOURCE,TABLE)
    old,oldedge=instructions(previous);new,edge=instructions(data)
    assert len(old)==3642 and len(new)==3632
    retained=0
    for i,row in enumerate(old):
        if 39<=i<50 or i==3520:continue
        k=shifted(i); assert new[k][1:]==row[1:] and edge[k]==tuple(map(shifted,oldedge[i]));retained+=1
    assert retained==3630
    cuts={37:('CD',3,(38,3585)),38:('CD',3,(39,3511)),39:('CD',6,(40,42)),40:('CI',5,(41,)),41:('CC',2,(39,)),3509:('CD',5,(3510,3511)),3510:('CC',3,(38,))}
    cuts.update({i:('CD',5,(i+1,3616 if i<3615 else None)) for i in range(3612,3616)})
    assert all((*new[i][1:],edge[i])==s for i,s in cuts.items())
    assert [i for i,v in enumerate(edge) if None in v]==[3615]
    assert [r[1:] for r in new[42:3509]]==[r[1:] for r in old[53:3520]]
    if guard is not None:assert [r[1:] for r in new[571:1243]]==guard
    print('Authenticated both sources and the 186 table; 3,630 retained operations and their successors, all 3,467 emitter operations, and the unique zero-branch stop at 3615 agree.')
    if guard is not None:print('Reconstructed all 672 operations of the guarded counting formula at 571–1242 from the published macros. Authenticated the published v15 excerpt.')
    count=0
    for cursor,n,r,p in product(range(64),range(32),(0,1,2,7),(0,1,11)):
        prefix_trial(new,edge,[n,7,11,r,p,23,0,0,cursor]);count+=1
    print(f'{count:,} literal command-prefix tests passed, including fresh epochs, nonzero rank and nonzero parameter.')

if __name__=='__main__':main()
