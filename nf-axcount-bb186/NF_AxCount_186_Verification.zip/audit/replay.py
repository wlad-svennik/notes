"""Check the supplementary nine-row and enumerator theorems against the verified 186 logic cache."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('objects',type=Path,help='object directory produced by the 186-state logic/replay.py')
parser.add_argument('--build',type=Path,default=Path(__file__).resolve().parent/'.replay')
parser.add_argument('--lean',default='lean')
args=parser.parse_args()
objects=args.objects.resolve(); out=args.build.resolve();out.mkdir(exist_ok=True,parents=True)
for n in ('CensusChart','CensusSelector','EpochBounds','MarkerArithmetic','MarkerEnumeration'):
    if not (objects/(n+'.olean')).is_file():parser.error(f'{objects} lacks the release module {n}')
version=subprocess.check_output([args.lean,'--version'],text=True).strip()
if 'version 4.35.0' not in version:parser.error('use the Lean 4.35.0 and mathlib environment from the 186 verification archive')
root=Path(__file__).resolve().parent; src=root/'src'
paths=[str(out),str(objects),*(p for p in os.environ.get('LEAN_PATH','').split(os.pathsep) if p)]
env=dict(os.environ,LEAN_PATH=os.pathsep.join(paths))
entries={}
for n in ['CountWordAudit','GlobalBudget','PhaseCases','PhaseRealization','PhaseExhaustion','CursorStep','MarkerReplay']:
    p=src/(n+'.lean');target=out/(n+'.olean')
    run=subprocess.run([args.lean,'-j','1','-s','131072','-o',str(target),p.name],cwd=src,env=env,text=True,capture_output=True)
    report=run.stdout+run.stderr;(out/(n+'.log')).write_text(report)
    if run.returncode or 'sorryAx' in report or "uses 'sorry'" in report:raise SystemExit(n+' failed\n'+report)
    entries[n]={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'axiom_reports':[s for s in report.splitlines() if 'axioms' in s]}
    print('checked',n,flush=True)
(out/'receipt.json').write_text(json.dumps({'lean':version,'modules':entries},indent=2)+'\n')
