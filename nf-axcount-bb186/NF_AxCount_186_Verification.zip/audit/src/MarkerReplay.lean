import CursorStep
import PhaseExhaustion
namespace NF180Counting.CensusMarker
open NF192.Numerical NF192.Numerical.Cantor CacheBound Phase

def encodePrefix : List Field → Nat → Nat
  | [], tail => tail
  | f::fs, tail => pair f.digit (encodePrefix fs tail + bitN f.targetEnd)

private theorem encoded_ge (fs : List Field) (tail : Nat) : tail ≤ encodePrefix fs tail := by
  induction fs with
  | nil => exact Nat.le_refl _
  | cons f fs ih => exact Nat.le_trans ih (Nat.le_trans (Nat.le_add_right _ _) (pair_ge_right _ _))

def atClean : Control → Prop | .tag 0 _ => True | _ => False

/-- Read the *numerical* cursor directly at each step. All payload caches and unused parameters
are universally quantified. The hypotheses on a branch are exactly the global rank bound. -/
def safeRaw (D : Nat) (allow : Bool) : List Field → Nat → Nat → Control → Prop
  | [],_,_,_ => False
  | f::fs,tail,n,c =>
    let (v,rest) := unpair n
    if rest = 0 then ∀ r h, finalBudget D v c → exhausted v c r h → goodExit allow r h
    else ∀ (ended : Bool) c', budgetAt D c → Step v c ended c' →
      (f.targetEnd=true ∧ rest-bitN ended=encodePrefix fs tail ∧ atClean c') ∨
        safeRaw D allow fs tail (rest-bitN ended) c'

private theorem got_alignment {endBit e p c D} (h : aligned endBit e p=true) (repr : Real D p c) :
    endBit=true ∧ e=0 ∧ atClean c := by
  cases repr <;> try contradiction
  case tag r k h hk =>
    cases r with
    | zero => simpa [aligned,atClean] using h
    | succ => contradiction

private theorem cast_bit (b : Bool) : (bitN b : Int) = (if b then 1 else 0) := by cases b <;> rfl
private theorem bit_step (b : Bool) : bitN b ≤ 1 := by cases b <;> decide

/-- Whole-list bridge from the published universal Boolean checker to actual Cantor cursor
arithmetic and the literal batch counts. The end-of-epoch bound is only imposed on a branch
that actually uses it. -/
theorem covered_safe {D : Nat} (hD : 22≤D) (allow : Bool) (fs : List Field) (tail : Nat) :
    ∀ (e : Int) (p : Phase) (n : Nat) (c : Control),
    (fs.length : Int)+1 ≤ (tail : Int)+e →
    cursorAt n (encodePrefix fs tail) e → Real D p c → covered allow fs e p=true →
    safeRaw D allow fs tail n c := by
  induction fs with
  | nil => intro e p n c _ _ _ h; contradiction
  | cons f fs ih =>
    intro e p n c slack enc repr cert
    have len : ((f::fs).length : Int) = (fs.length : Int)+1 := by simp
    have low : 1 ≤ (encodePrefix fs tail : Int)+e := by
      have := encoded_ge fs tail
      omega
    let a := (f.digit : Int)-e
    by_cases neg : a<0
    · have hc : a = -1 ∧ crossing allow p = true := by
        simpa only [covered,show (f.digit : Int)-e<0 from neg,ite_true,Bool.and_eq_true,beq_iff_eq] using cert
      have raw := overflow_cursor_step n f.digit (encodePrefix fs tail) e f.targetEnd enc hc.1
      simp only [safeRaw,raw,ite_true]
      intro r h bud out
      exact crossing_realization hD repr bud out hc.2
    · have ha : 0≤a := by omega
      have st := regular_cursor_step n f.digit (encodePrefix fs tail) e f.targetEnd false enc low ha
      have nr : (unpair n).2 ≠ 0 := by omega
      let shift := e+(bitN f.targetEnd : Int)
      let cont (e' : Int) (p' : Phase) := aligned f.targetEnd e' p' || covered allow fs e' p'
      have hc : regular a.toNat p (cont shift) (cont (shift-1))=true := by
        simpa only [covered,show ¬(f.digit : Int)-e<0 from neg,ite_false,shift,cast_bit,cont,a] using cert
      change (if (unpair n).2=0 then _ else _) ; rw [if_neg nr]
      intro ended c' bud act
      rw [st.1] at act
      obtain ⟨p',ret,rep⟩ := regular_realization repr bud act (cont shift) (cont (shift-1)) hc
      let e' := shift-(bitN ended : Int)
      have rc : cont e' p' = true := by cases ended <;> simpa [e',bitN] using ret
      have raw := (regular_cursor_step n f.digit (encodePrefix fs tail) e f.targetEnd ended enc low ha).2.2
      rcases Bool.or_eq_true_iff.mp rc with hit | todo
      · obtain ⟨ft,ez,clean⟩ := got_alignment hit rep
        left; refine ⟨ft,?_,clean⟩
        change cursorAt _ _ e' at raw
        rw [ez] at raw; unfold cursorAt at raw; omega
      · right
        apply ih e' p' _ c' _ raw rep todo
        have bb := bit_step ended
        dsimp only [e',shift]; omega
end NF180Counting.CensusMarker
#print axioms NF180Counting.CensusMarker.covered_safe

namespace NF180Counting.CensusMarker
open NF192.Numerical NF180Counting.CensusLogic CacheBound Phase

attribute [local irreducible] safeRaw covered encodePrefix
set_option maxHeartbeats 1000000
set_option maxRecDepth 8000

/-- The two adjacent predecessor epochs, for arbitrary incoming arithmetic ranks. The old R0
labels are P(K,z+1)-j. Ordinary forced commands expose z-j; a forced AX begins reading its
batch fields at z+1-j. The latter's final first coordinate A is at least its outer immediate. -/
theorem two_predecessors (D K tail r h A newH : Nat) (hD : 22≤D) (pad : 100≤tail)
    (budget : r≤D) (large : 2*D ≤ K^16) (imm : K≤A) :
    let z := encodePrefix markerFields tail
    let plan := literalAX r h
    let m := testRow plan.lastB A
    (safeRaw D true markerFields tail (z-2) (.tag 0 newH) ∧
     safeRaw D true markerFields tail (z-1) (.data plan.fields plan.carry m)) ∧
    (safeRaw D false markerFields tail (z-1) (.tag 0 newH) ∧
     (h≥r → safeRaw D false markerFields tail z (.data plan.fields plan.carry m))) := by
  dsimp only
  have bound := encoded_ge markerFields tail
  have hl : markerFields.length=13 := rfl
  have big : 2*D ≤ testRow (literalAX r h).lastB A :=
    Nat.le_trans large (Nat.le_trans (Nat.pow_le_pow_left imm _) (NF180Counting.EpochBounds.marker_grows _ _))
  have off2 : cursorAt (encodePrefix markerFields tail-2) (encodePrefix markerFields tail) (-2) := by unfold cursorAt; omega
  have off1 : cursorAt (encodePrefix markerFields tail-1) (encodePrefix markerFields tail) (-1) := by unfold cursorAt; omega
  have off0 : cursorAt (encodePrefix markerFields tail) (encodePrefix markerFields tail) 0 := by unfold cursorAt; omega
  have residual : (literalAX r h).carry ≤ D := by simp only [literalAX]; omega
  have s₂ := second_predecessor_exhausted_or_aligned
  have s₁ := first_predecessor_exhausted_or_aligned
  simp only [Bool.and_eq_true,decide_eq_true_eq] at s₁ s₂
  have sl2 : (markerFields.length : Int)+1 ≤ (tail:Int)+(-2) := by omega
  have sl1 : (markerFields.length : Int)+1 ≤ (tail:Int)+(-1) := by omega
  have sl0 : (markerFields.length : Int)+1 ≤ (tail:Int)+0 := by omega
  refine ⟨⟨?_,?_⟩,⟨?_,?_⟩⟩
  · exact covered_safe hD true markerFields tail (-2) (.tag 0 unknown) _ _ sl2 off2 (.tag 0 unknown newH trivial) s₂.1
  · exact covered_safe hD true markerFields tail (-1) .firstFields _ _ sl1 off1 (.first _ _ _ (Nat.zero_lt_succ _) residual big) s₂.2
  · exact covered_safe hD false markerFields tail (-1) (.tag 0 unknown) _ _ sl1 off1 (.tag 0 unknown newH trivial) s₁.1
  · intro hr
    have clear : (literalAX r h).carry = 0 := by simp only [literalAX]; omega
    rw [clear]
    exact covered_safe hD false markerFields tail 0 .drainFields _ _ sl0 off0 (.bigData _ _ (Nat.zero_lt_succ _) big) s₁.2
end NF180Counting.CensusMarker
#print axioms NF180Counting.CensusMarker.two_predecessors
