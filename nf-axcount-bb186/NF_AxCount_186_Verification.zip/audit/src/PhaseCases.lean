import MarkerEnumeration
import EpochBounds
namespace NF180Counting.CensusMarker
open NF192.Numerical NF180Counting.CensusLogic
open CacheBound Phase

structure Plan where
  fields : Nat
  carry : Nat
  lastB : Nat

def literalAX (tag h : Nat) : Plan :=
  let q := tag-2
  let spent := min q h
  ⟨spent+1,q-spent,h-spent⟩

def boundedCache (D : Nat) : CacheBound → Nat → Prop
  | unknown, _ => True
  | marker, h => 22 ≤ h
  | huge, h => 2*D ≤ h

theorem fresh_mark_small (b a : Nat) : 22 ≤ testRow b a := by
  have h₀ : 2 ≤ witness b b := by unfold witness; omega
  have h₁ : 3 ≤ app q (witness b b) := by
    have h := imp_ge_right q (witness b b); unfold app imp at *; omega
  have h₂ : 13 ≤ single b a := by
    change 13 ≤ 2*pair (app q (witness b b)) a+1
    have hn : 3 ≤ app q (witness b b)+a := by omega
    have t := Cantor.triangle_mono hn
    change 6 ≤ (app q (witness b b)+a)*(app q (witness b b)+a+1)/2 at t
    change 13 ≤ 2 * ((app q (witness b b)+a)*(app q (witness b b)+a+1)/2+a)+1
    omega
  have h₃ := Cantor.triangle_mono (show 13 ≤ single b a+b by omega)
  change 91 ≤ (single b a+b)*(single b a+b+1)/2 at h₃
  have h₄ := imp_ge_left (eqn (single b a) b) (eqn (single b b) b)
  have h₅ := imp_ge_left (imp (eqn (single b a) b) (eqn (single b b) b)) (eqn a b)
  change 22 ≤ imp (imp (eqn (single b a) b) (eqn (single b b) b)) (eqn a b)
  have he : 22 ≤ eqn (single b a) b := by unfold eqn pair; omega
  exact Nat.le_trans he (Nat.le_trans h₄ h₅)

theorem marker_double (b a : Nat) : 2*b ≤ testRow b a := by
  have h := imp_ge_right (imp (eqn (single b a) b) (eqn (single b b) b)) (eqn a b)
  change 2*b ≤ imp (imp (eqn (single b a) b) (eqn (single b b) b)) (eqn a b)
  have hq : 2*b ≤ eqn a b := by unfold eqn; have pe := pair_ge_right a b; omega
  omega

/-- The actual final marker preserves a single fixed huge-cache threshold. -/
theorem huge_invariant {D tag h : Nat} (ht : tag ≤ D) (hh : 2*D ≤ h) (a : Nat) :
    (literalAX tag h).carry = 0 ∧ h ≤ testRow (literalAX tag h).lastB a := by
  have le : tag-2 ≤ h := by omega
  simp only [literalAX,Nat.min_eq_left le,Nat.sub_self,true_and]
  have hd := marker_double (h-(tag-2)) a
  omega

/-- The set of schedules in regular's exact-tag branch contains the actual literal batch loop,
including CD5 failure exactly on the final batch. -/
theorem immediate_realized {D tag h : Nat} (bound : CacheBound)
    (hbound : boundedCache D bound h) (budget : tag ≤ D)
    (fax : 2 ≤ tag) (next finish : Phase → Bool) (v : Nat)
    (cert : regular v (immediate tag bound) next finish = true) :
    next (fields (literalAX tag h).fields bound (literalAX tag h).carry) = true := by
  have hn : ¬ tag ≤ 1 := by omega
  simp only [regular,if_neg hn,Bool.and_eq_true,decide_eq_true_eq] at cert
  obtain ⟨h22,keep⟩ := cert
  cases bound with
  | unknown =>
    have mem : min (tag-2) h ∈ List.range (tag-1) := List.mem_range.mpr (by omega)
    exact List.all_eq_true.mp keep _ mem
  | marker =>
    change 22 ≤ h at hbound
    have hq : tag-2 ≤ h := by omega
    simp [literalAX,hq,Nat.min_eq_left hq,show tag-2+1=tag-1 by omega] at *
    exact keep
  | huge =>
    change 2*D ≤ h at hbound
    have hq : tag-2 ≤ h := by omega
    simp [literalAX,hq,Nat.min_eq_left hq,show tag-2+1=tag-1 by omega] at *
    exact keep

/-- Actual post-cache after a bounded normal AX covers the marker class emitted by the
checker. For unknown/marker input this also dominates any residual allowed by t≤22. -/
theorem finish_realized {D tag h : Nat} (bound : CacheBound)
    (hbound : boundedCache D bound h) (budget : tag≤D) (short : tag≤22) (a : Nat) :
    boundedCache D (if bound == huge then huge else marker) (testRow (literalAX tag h).lastB a) ∧
    (literalAX tag h).carry ≤ testRow (literalAX tag h).lastB a := by
  have hs := fresh_mark_small (literalAX tag h).lastB a
  have hr : (literalAX tag h).carry ≤ 22 := by simp only [literalAX]; omega
  refine ⟨?_,by omega⟩
  cases bound with
  | huge =>
    change 2*D ≤ testRow _ a
    exact Nat.le_trans hbound (huge_invariant budget hbound a).2
  | marker => exact hs
  | unknown => exact hs
end NF180Counting.CensusMarker
#print axioms NF180Counting.CensusMarker.huge_invariant
#print axioms NF180Counting.CensusMarker.immediate_realized
#print axioms NF180Counting.CensusMarker.finish_realized
