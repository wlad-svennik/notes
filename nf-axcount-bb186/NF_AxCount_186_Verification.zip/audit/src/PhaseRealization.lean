import PhaseCases
namespace NF180Counting.CensusMarker
open NF192.Numerical NF180Counting.CensusLogic CacheBound Phase

private theorem both {a b : Bool} (h : (a && b) = true) : a = true ∧ b = true := by
  simpa only [Bool.and_eq_true] using h

inductive Control where
  | tag (r h : Nat) | arg (t h : Nat) | data (remaining r finalH : Nat)

/-- Every option for the final first coordinate is admitted. The real source chooses it from
its R4 additions. On ordinary non-AX commands every numerical cache is admitted. -/
inductive Step (v : Nat) : Control → Bool → Control → Prop where
  | tag (r h : Nat) : Step v (.tag r h) false (.arg (r+v) h)
  | ordinary (t h newH : Nat) (ht : t≤1) : Step v (.arg t h) true (.tag 0 newH)
  | ax (t h a : Nat) (ht : 2≤t) : Step v (.arg t h) false
      (.data (literalAX t h).fields (literalAX t h).carry (testRow (literalAX t h).lastB a))
  | more (n r h : Nat) : Step v (.data (n+2) r h) false (.data (n+1) r h)
  | last (r h : Nat) : Step v (.data 1 r h) true (.tag r h)

inductive Real (D : Nat) : Phase → Control → Prop where
  | tag (r : Nat) (k : CacheBound) (h : Nat) (hk : boundedCache D k h) : Real D (.tag r k) (.tag r h)
  | arg (t : Nat) (k : CacheBound) (h : Nat) (hk : boundedCache D k h) : Real D (.immediate t k) (.arg t h)
  | fields (n r h : Nat) (k : CacheBound) (hn : 0<n) (hr : r≤22)
      (hk : boundedCache D (if k == huge then huge else marker) h) : Real D (.fields n k r) (.data n r h)
  | first (n r h : Nat) (hn : 0<n) (hr : r≤D) (hh : 2*D≤h) : Real D .firstFields (.data n r h)
  | prior (r h : Nat) (hr : 0<r) (hh : 2*D≤h) : Real D .tagR (.tag r h)
  | bigArg (t h : Nat) (ht : 2≤t) (hh : 2*D≤h) : Real D .drainImmediate (.arg t h)
  | bigData (n h : Nat) (hn : 0<n) (hh : 2*D≤h) : Real D .drainFields (.data n 0 h)

def budgetAt (D : Nat) : Control → Prop | .arg t _ => t≤D | _ => True

/-- Every actual scalar control transition on the current diagonal is present in the finite
marker's universal branch calculation. No assumption bounds the number of AX fields by 22. -/
theorem regular_realization {D v : Nat} {p : Phase} {c c' : Control} {ended : Bool}
    (h : Real D p c) (budget : budgetAt D c) (act : Step v c ended c')
    (next finish : Phase → Bool) (cert : regular v p next finish = true) :
    ∃ p', (if ended then finish p' else next p') = true ∧ Real D p' c' := by
  cases h with
  | tag r k h hk => cases act; exact ⟨_,by simpa [regular,Nat.add_comm] using cert,Real.arg _ _ _ hk⟩
  | arg t k h hk =>
    cases act with
    | ordinary _ _ nh ht => exact ⟨_,by simpa [regular,ht] using cert,Real.tag _ unknown _ trivial⟩
    | ax _ _ a ht =>
      have short : t≤22 := by
        have hn : ¬ t≤1 := by omega
        simp only [regular,if_neg hn,Bool.and_eq_true,decide_eq_true_eq] at cert
        exact cert.1
      have hc : (literalAX t h).carry ≤ 22 := by simp only [literalAX]; omega
      exact ⟨_,immediate_realized k hk budget ht next finish v cert,
        Real.fields _ _ _ k (Nat.zero_lt_succ _) hc (finish_realized k hk budget short a).1⟩
  | fields n r h k hn hr hk =>
    cases act with
    | more j _ _ => exact ⟨_,by simpa [regular] using cert,Real.fields _ _ _ _ (Nat.zero_lt_succ _) hr hk⟩
    | last => exact ⟨_,by simpa [regular] using cert,Real.tag _ _ _ hk⟩
  | first n r h hn hr hh =>
    cases act with
    | more j _ _ => exact ⟨_,(both (both cert).1).1,Real.first _ _ _ (Nat.zero_lt_succ _) hr hh⟩
    | last =>
      by_cases z : r=0
      · subst r; exact ⟨_,(both (both cert).1).2,Real.tag _ huge _ hh⟩
      · exact ⟨_,(both cert).2,Real.prior _ _ (by omega) hh⟩
  | prior r h hr hh =>
    cases act
    by_cases sm : r+v≤1
    · have hv : v=0 := by omega
      have ht : r+v=1 := by omega
      rw [ht]
      exact ⟨_,by simpa [regular,hv] using (both cert).2,Real.arg _ huge _ hh⟩
    · exact ⟨_,(both cert).1,Real.bigArg _ _ (by omega) hh⟩
  | bigArg t h ht hh =>
    cases act with
    | ordinary _ _ _ hsm => omega
    | ax _ _ a _ =>
      obtain ⟨zero,newH⟩ := huge_invariant budget hh a
      rw [zero]
      exact ⟨_,cert,Real.bigData _ _ (Nat.zero_lt_succ _) (Nat.le_trans hh newH)⟩
  | bigData n h hn hh =>
    cases act with
    | more j _ _ => exact ⟨_,(both cert).1,Real.bigData _ _ (Nat.zero_lt_succ _) hh⟩
    | last => exact ⟨_,(both cert).2,Real.tag _ huge _ hh⟩
end NF180Counting.CensusMarker
#print axioms NF180Counting.CensusMarker.regular_realization
