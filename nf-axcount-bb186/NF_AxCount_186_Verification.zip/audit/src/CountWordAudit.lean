import CensusChart
import CensusSelector

namespace NF180Counting.CountWordAudit
open NF192.Emitter NF192.Numerical

structure State where
  top : Nat
  stack : List Nat
  cache : Nat
  param : Nat

def nip (s : State) : State := ⟨s.top, s.stack.tail, s.stack.headD 0, 0⟩
def swap (s : State) : State := ⟨s.cache,s.stack,s.top,0⟩
def mode (b : Nat) (s : State) : State := nip ⟨if s.cache = imp s.top (s.param+b) then s.param+b else 0,s.stack,0,0⟩
def after (s : State) (rows : List Nat) : State := nip ⟨0,rows.reverse.tail ++ s.top :: s.stack,0,0⟩
def nips : Nat → State → State
  | 0, s => s
  | n+1, s => nips n (nip s)

def FullSound (s : State) := GuardedLogic.Deriv s.top ∧ (∀ x ∈ s.stack, GuardedLogic.Deriv x) ∧ GuardedLogic.Deriv s.cache

theorem readHead {xs : List Nat} (h : ∀ x ∈ xs, GuardedLogic.Deriv x) : GuardedLogic.Deriv (xs.headD 0) := by
  cases xs with
  | nil => exact GuardedLogic.deriv_zero
  | cons x xs => exact h x (by simp)

theorem nip_sound {s : State} (h : FullSound s) : FullSound (nip s) :=
  ⟨h.1,fun x hx => h.2.1 x (List.mem_of_mem_tail hx),readHead h.2.1⟩

theorem mode_sound {s : State} (b : Nat) (h : FullSound s) : FullSound (mode b s) := by
  apply nip_sound
  refine ⟨?_,h.2.1,GuardedLogic.deriv_zero⟩
  dsimp
  split
  next e => exact GuardedLogic.Deriv.mp (e ▸ h.2.2) h.1
  next => exact GuardedLogic.deriv_zero

theorem mode_resets_param (b : Nat) (s : State) : (mode b s).param = 0 := rfl

def mp (d : Nat) (s : State) : State :=
  match s.param+d with
  | 0 => nip s
  | k+1 => ⟨s.cache,s.stack,s.top,k⟩

theorem mp_sound (d : Nat) {s : State} (hs : FullSound s) : FullSound (mp d s) := by
  unfold mp
  split
  · exact nip_sound hs
  · exact ⟨hs.2.2,hs.2.1,hs.1⟩

theorem batch_sound (a b c u : Nat) (hu : u ≤ a) :
    ∀ x ∈ GuardedLogic.rowList a b c u, GuardedLogic.Deriv x := fun _ h => .row hu h

theorem after_sound (s : State) (rs : List Nat) (hs : FullSound s)
    (hr : ∀ x ∈ rs, GuardedLogic.Deriv x) : FullSound (after s rs) := by
  apply nip_sound
  refine ⟨GuardedLogic.deriv_zero,?_,GuardedLogic.deriv_zero⟩
  intro x hx
  rcases List.mem_append.mp hx with h | h
  · exact hr _ (List.mem_reverse.mp (List.mem_of_mem_tail h))
  · rcases List.mem_cons.mp h with eq | h
    · simpa only [eq] using hs.1
    · exact hs.2.1 _ h

theorem unmatchable (a b k : Nat) (hk : k ≤ b) : k ≠ imp (row9 a b) a := by
  have h₁ := imp_ge_right (eqn (app b (witness a b)) (app a (witness a b))) (eqn a b)
  have h₂ := imp_ge_left (row9 a b) a
  change eqn a b ≤ row9 a b at h₁
  have h₃ := pair_ge_right a b
  unfold eqn at h₁
  omega

private theorem pop (pre tail : List Nat) (t k : Nat) :
    ∃ d, nips pre.length ⟨t,pre++tail,k,0⟩ = ⟨t,tail,d,0⟩ := by
  induction pre generalizing k with
  | nil => exact ⟨k,rfl⟩
  | cons a pre ih => exact ih a

theorem popThrough (pre tail : List Nat) (x top k : Nat) :
    nips (pre.length+1) ⟨top,pre++x::tail,k,0⟩ = ⟨top,tail,x,0⟩ := by
  induction pre generalizing k with
  | nil => rfl
  | cons a pre ih => exact ih a

/-- Last nip removes the seed's extra zero, recovering known cache zero. -/
theorem selectStack (pre post : List Nat) (x top k : Nat) (tail : List Nat) :
    nips (post.length+1) (swap (nips (pre.length+1)
      ⟨top,pre++x::(post++0::tail),k,0⟩)) = ⟨x,tail,0,0⟩ := by
  rw [popThrough]; exact popThrough post tail 0 x top

theorem selectCache (post : List Nat) (x top : Nat) (tail : List Nat) :
    nips (post.length+1) (swap ⟨top,post++0::tail,x,0⟩) = ⟨x,tail,0,0⟩ :=
  popThrough post tail 0 x top

/-- Nine actual rows require seven explicit nips. -/
theorem sweep (s : State) (a b c u : Nat) : ∃ d,
    nips 7 (after s (GuardedLogic.rowList a b c u)) = ⟨0,s.top::s.stack,d,0⟩ := by
  exact ⟨row0 a b c u,rfl⟩

theorem reset (s : State) (a b c u a' b' c' u' : Nat) :
    let t := nips 7 (after s (GuardedLogic.rowList a b c u))
    let v := nips 7 (after t (GuardedLogic.rowList a' b' c' u'))
    mode 0 v = ⟨0,s.top::s.stack,0,0⟩ := by
  obtain ⟨d,he⟩ := sweep s a b c u
  obtain ⟨e,hf⟩ := sweep ⟨0,s.top::s.stack,d,0⟩ a' b' c' u'
  dsimp only
  rw [he,hf]; simp [mode,nip]

/-- Positions in the second-row K-seed batch. Six nips reach the second row.
Two nips after the first swap remove row zero and the saved known zero. -/
theorem seed (b : Nat) (tail : List Nat) :
    let s := after ⟨0,tail,0,0⟩ (GuardedLogic.rowList b 0 0 b)
    swap (nips 2 (swap (nips 6 s))) = ⟨0,tail,row4 b 0,0⟩ := rfl

theorem composeMP (a b k : Nat) (t : Nat) (stack : List Nat) :
    mode b (swap (nip ⟨imp a b,a::0::t::stack,k,0⟩)) = ⟨b,t::stack,0,0⟩ := by
  simp [mode,swap,nip]

/-- The final two MP commands inspect their incoming cache. -/
theorem observe (s : State) (h : s.top = goal) : (swap s).cache = goal := h

def marker (b a : Nat) := GuardedLogic.testRow b a

theorem marker_pos (b a : Nat) : 0 < marker b a := by
  exact Nat.lt_of_lt_of_le (show 0 < eqn a b by simp [eqn]) (imp_ge_right _ _)

/-- A complete cleanup schedule records the precise number of zero batch fields read
by each AX command. AX also places a known prefix ahead of the older payload. -/
inductive Cleanup : Nat → Nat → List Nat → Prop where
  | done (h : Nat) : Cleanup h 0 []
  | step {h r : Nat} (pos : 0 < r) (fields : List Nat)
      (tail : Cleanup (marker (h-min h r) 0) (r-min h r) fields) :
      Cleanup h r ((min h r+1)::fields)

theorem cleanup_schedule (r h : Nat) (pos : 0 < h) : ∃ fields, Cleanup h r fields ∧ fields.length ≤ r := by
  induction r using Nat.strong_induction_on generalizing h with
  | h r ih =>
    by_cases hz : r = 0
    · subst r; exact ⟨[],.done _,by simp⟩
    · have less : r-min h r < r := by omega
      obtain ⟨fields,nxt,bnd⟩ := ih _ less (marker (h-min h r) 0) (marker_pos _ _)
      exact ⟨_ , .step (by omega) fields nxt,by simp; omega⟩

/-- All nine rows of every nonfinal batch survive the final return. -/
theorem lastShape (s : State) (history : List Nat) (a b c u : Nat) :
    after s (history ++ GuardedLogic.rowList a b c u) =
      ⟨0, ((GuardedLogic.rowList a b c u).take 7).reverse ++
        history.reverse ++ s.top :: s.stack, GuardedLogic.testRow b a, 0⟩ := by
  simp [after,GuardedLogic.rowList,nip,List.reverse_append]

/-- The raw selector reaches the prescribed batch. Positive b with c=1
places the extensionality target one full batch before the return. -/
theorem target_coordinates (b c : Nat) :
    let h := row4 b 0
    let i := h-b
    i ≤ min h (i+c) ∧ h-i=b ∧ (i+c)-i=c ∧
      min h (i+c) = i+min b c ∧ (i+c)-h = c-b ∧
      (0<b → min h (i+1)=i+1) := by
  dsimp only
  have := NF180Counting.CensusSelector.seed_bound b
  omega

def packFields : List Nat → Nat → Nat
  | [], tail => tail
  | field :: fields, tail => pair field (packFields fields tail)

def readFields : Nat → Nat → List Nat × Nat
  | 0, w => ([],w)
  | n+1,w =>
    let (f,rest) := Cantor.unpair w
    let (fs,t) := readFields n rest
    (f::fs,t)

theorem unpackFields (fields : List Nat) (tail : Nat) :
    readFields fields.length (packFields fields tail) = (fields,tail) := by
  induction fields with
  | nil => rfl
  | cons f fs ih => simp only [List.length_cons,packFields,readFields,Cantor.unpair_pair,ih]

/-- The fixed command schedule can be followed by any continuation. The cursor
subtraction at each real command boundary removes exactly the inserted unit. -/
def packWord : List (List Nat) → Nat → Nat
  | [], w => w
  | fs :: more,w => packFields fs (packWord more w + 1)

def readWord : List Nat → Nat → List (List Nat) × Nat
  | [], w => ([],w)
  | n :: more,w =>
    let (fs,t) := readFields n w
    let (rest,end_) := readWord more (t-1)
    (fs::rest,end_)

theorem arbitrary_continuation (word : List (List Nat)) (t : Nat) :
    readWord (word.map List.length) (packWord word t) = (word,t) := by
  induction word with
  | nil => rfl
  | cons fs rest ih => simp [packWord,readWord,unpackFields,ih]

/-- The countdown parser uses exactly the numerical marker in the certified phase
analysis, including the degenerate zero-cache batch. -/
theorem marker_matches (a b : Nat) : marker b a = CensusLogic.testRow b a := rfl

/-- The machine's reduced and full guarded calculi have the same non-refuting charts. -/
theorem nonderivability_iff_chart : ¬ CensusLogic.Deriv goal ↔ GuardedLogic.HasGuardedChart :=
  (not_congr CensusLogic.goal_iff_full).trans GuardedLogic.nonderivability_iff_guarded_chart

/-- The lower interpretation yields NFU with Dedekind Infinity and full Counting. -/
theorem nonderivability_yields_counting (h : ¬ CensusLogic.Deriv goal) : RangeNFU.HasCountingModel :=
  GuardedLogic.nonderivability_yields_counting ((not_congr CensusLogic.goal_iff_full).mp h)

end NF180Counting.CountWordAudit
#print axioms NF180Counting.CountWordAudit.after_sound
#print axioms NF180Counting.CountWordAudit.unmatchable
#print axioms NF180Counting.CountWordAudit.reset
#print axioms NF180Counting.CountWordAudit.seed
#print axioms NF180Counting.CountWordAudit.selectStack
#print axioms NF180Counting.CountWordAudit.composeMP
#print axioms NF180Counting.CountWordAudit.cleanup_schedule
#print axioms NF180Counting.CountWordAudit.lastShape
#print axioms NF180Counting.CountWordAudit.target_coordinates
#print axioms NF180Counting.CountWordAudit.arbitrary_continuation
#print axioms NF180Counting.CountWordAudit.nonderivability_iff_chart
#print axioms NF180Counting.CountWordAudit.nonderivability_yields_counting
