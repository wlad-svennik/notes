import MarkerArithmetic
import MarkerEnumeration

namespace NF180Counting.CensusMarker
open NF192.Numerical NF192.Numerical.Cantor

/-- The actual integer on the tape corresponds to the signed discrepancy e at a raw field. -/
def cursorAt (n encoded : Nat) (e : Int) : Prop := (n : Int) = (encoded : Int) + e

def bitN (p : Bool) : Nat := if p then 1 else 0

/-- Stay on one Cantor diagonal, with an actual command boundary and a target boundary chosen
independently. The raw command-end decrement is justified by the positive actual right tail. -/
theorem regular_cursor_step (n x rest : Nat) (bias : Int) (targetEnd actualEnd : Bool)
    (h : cursorAt n (pair x (rest + bitN targetEnd)) bias)
    (hlow : 1 ≤ (rest : Int) + bias)
    (hdigit : 0 ≤ (x : Int) - bias) :
    (unpair n).1 = ((x : Int)-bias).toNat ∧ 0 < (unpair n).2 ∧
    cursorAt ((unpair n).2 - bitN actualEnd) rest
      (bias + (bitN targetEnd : Int) - (bitN actualEnd : Int)) := by
  unfold cursorAt at *
  generalize hd : bitN targetEnd = d at *
  have hbit : bitN actualEnd ≤ 1 := by cases actualEnd <;> decide
  cases bias with
  | ofNat e =>
    change (n : Int) = (pair x (rest+d) : Int) + (e : Int) at h
    change 1 ≤ (rest : Int) + (e : Int) at hlow
    change 0 ≤ (x : Int) - (e : Int) at hdigit
    have eqn : n = pair x (rest+d)+e := by omega
    have he : e ≤ x := by omega
    rw [eqn,decode_positive x (rest+d) e he]
    change x-e = ((x:Int)-(e:Int)).toNat ∧ 0 < rest+d+e ∧ ((rest+d+e-bitN actualEnd : Nat) : Int) = (rest:Int)+((e:Int)+(d:Int)-(bitN actualEnd:Int))
    constructor <;> omega
  | negSucc e =>
    have he : e+1 ≤ rest+d := by omega
    have eqn : n = pair x (rest+d)-(e+1) := by omega
    rw [eqn,decode_negative x (rest+d) (e+1) he]
    simp only [Prod.fst,Prod.snd]
    constructor <;> omega

/-- Crossing the diagonal consumes the entire foreign right tail, including any encoded W. -/
theorem overflow_cursor_step (n x rest : Nat) (bias : Int) (endBit : Bool)
    (h : cursorAt n (pair x (rest + bitN endBit)) bias)
    (escape : (x : Int)-bias = -1) :
    unpair n = (x+(rest+bitN endBit)+1,0) := by
  unfold cursorAt at h
  have hn : n = pair x (rest+bitN endBit)+(x+1) := by omega
  rw [hn,decode_overflow]

end NF180Counting.CensusMarker
#print axioms NF180Counting.CensusMarker.regular_cursor_step
#print axioms NF180Counting.CensusMarker.overflow_cursor_step
