# The census calculus and its Lean replay

Run `python3 ../search/check_source.py` here to compare the 186-state register source against the released 187-state source. Every retained primitive and jump destination is checked. The mathematical argument for constructing finite proof words is in `../search/source_argument.md`.

The incremental verifier runs on Linux or macOS with Python 3.11 or later. The local `src` tree contains all project imports used by the proof. Sources inherited from the 187-state release come from its calculus mirror and its archived J-point calibration. `sources.json` records the dependencies and SHA-256 of every bundled module. The external Lean and mathlib versions are pinned in `environment`.

Use Lean 4.35.0 and mathlib commit `56a005855ea17e0b0958f73ec801ae140b0a1679`. With that environment available, run the following from this directory.

```sh
python replay.py --build .replay --jobs 4 --check-manifest
```

The checked release mode verifies all source bytes against the shipped manifest. For active edits, omit `--check-manifest`. Lean then reports the current imports of edited sources, and replay rebuilds the changed modules and their dependents. The default persistent directory is `.replay`. To rebuild every bundled project module, add `--clean`.

An existing verified 187-state object directory can seed the first run.

```sh
python replay.py --build .replay --parent-cache /path/to/187/objects --check-manifest
```

The supplied parent fingerprint binds 171 inherited modules to source, transitive dependencies, the external toolchain, and their object-file digests. Each matching object is copied to the current cache. An absent object, an artifact mismatch or an environment mismatch triggers compilation from the bundled source. The package contains the sources needed for this fallback.

Each replay validates the Lean binary and version, compiler options, pinned Lake manifests, and the external compiled Lean libraries, including private interfaces and interpreted code. It caches SHA-256 file reads by device, inode, byte count, modification time and change time. A per-directory lock isolates concurrent callers, and finished objects and receipts are replaced atomically. A successful run writes counts for compiled, seeded and reused modules to `receipt.json` in the build directory.

To obtain the pinned external dependencies in a new checkout, use the included Lake environment.

```sh
cd environment
lake exe cache get
lake env python ../replay.py --build ../.replay --jobs 4 --check-manifest
```

| File | Main conclusion |
| --- | --- |
| CensusLogic.lean | A countervaluation exists whenever the census calculus does not derive code 3. |
| CensusChart.lean | The census calculus and the guarded 187-state calculus derive code 3 in precisely the same cases. |
| CensusSelector.lean | The batch visits any prescribed raw pair of parameters; positive-cache cleanup strictly lowers the carry. |
| CensusStack.lean | The common AX return comparison fails as required, and its emitted stack stays sound. |
| CensusExtract.lean | Two one-batch sweeps reset arbitrary proof data, and nips and swaps extract a chosen stack occurrence. |
| EpochBounds.lean | The marker dominates both the incoming numerical parameter and the finite epoch debt estimates. |
| MarkerArithmetic.lean | The raw Cantor field and predecessor identities used by synchronization hold. |
| MarkerEnumeration.lean | The finite synchronization-marker branch analysis exhausts its abstract continuations. |

Refer to the enclosing verification bundle for the binary table checker, the signed tape proof, and the full source enumeration argument.
