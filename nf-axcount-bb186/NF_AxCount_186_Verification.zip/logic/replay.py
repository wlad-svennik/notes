"""Incrementally check the census Lean sources and every imported project module."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
FLAGS = ['-j', '1', '-s', '131072']
# Keep every artifact Lean can use for an import or for evaluation of imported code.
MODULE_ENDINGS = ('.olean', '.olean.private', '.olean.server', '.ir')
EXTERNAL_ENDINGS = MODULE_ENDINGS + ('.so', '.dylib', '.dll', '.plugin')
SCHEMA = 2

def digest(data):
    return hashlib.sha256(data).hexdigest()

def packed(obj):
    return json.dumps(obj,sort_keys=True,separators=(',', ':')).encode()

def read_json(path, default):
    try:
        return json.loads(path.read_bytes())
    except (FileNotFoundError, ValueError):
        return default

def commit(path, data):
    path.parent.mkdir(exist_ok=True,parents=True)
    with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as f:
        temp=Path(f.name)
        f.write(data)
    os.replace(temp,path)

class FileHashes:
    """Read the file again if its filesystem identity or either timestamp changed."""
    def __init__(self,path):
        self.path=path
        self.records=read_json(path,{})
    def get(self,path):
        st=path.stat()
        mark=[st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns]
        key=str(path)
        saved=self.records.get(key)
        if not saved or saved[0]!=mark:
            with path.open('rb') as f:
                saved=[mark, hashlib.file_digest(f,'sha256').hexdigest()]
            self.records[key]=saved
        return saved[1]
    def save(self):
        commit(self.path,packed(self.records))

def module_path(name):
    return Path(*name.split('.'))

def products(root,name,hashes):
    prefix=root/module_path(name)
    found={}
    for ending in MODULE_ENDINGS:
        p=prefix.with_suffix(ending)
        if p.is_file():
            found[ending]=hashes.get(p)
    return found

def copy_products(src,dest,name,found):
    for ending in MODULE_ENDINGS:
        rel=module_path(name).with_suffix(ending)
        path=dest/rel
        if ending not in found:
            path.unlink(missing_ok=True)
            continue
        path.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as temp:
            tmppath=Path(temp.name)
            with (src/rel).open('rb') as f: shutil.copyfileobj(f,temp)
        os.replace(tmppath,path)

def external_id(lean,version,library_paths,hashes):
    prefix=Path(subprocess.check_output([lean,'--print-prefix'],text=True).strip())
    records=[('lean',hashes.get(Path(lean).resolve())),('version',version),('flags',FLAGS)]
    for name in ('lean-toolchain','lakefile.toml','lake-manifest.json'):
        records.append(('locked/'+name,hashes.get(ROOT/'environment'/name)))
    roots=[prefix/'lib/lean',*library_paths]
    for i,base in enumerate(roots):
        if not base.is_dir():
            records.append((i,'absent'))
            continue
        for directory,_,files in os.walk(base):
            for name in sorted(files):
                if not (name.endswith(EXTERNAL_ENDINGS) or '.so.' in name): continue
                pp=Path(directory)/name
                records.append((i,str(pp.relative_to(base)),hashes.get(pp)))
    return digest(packed([records[:6], sorted(records[6:],key=lambda x:(x[0],x[1]))]))

def run(args):
    lean=shutil.which(args.lean)
    if not lean: raise SystemExit('Lean 4.35.0 was not found.')
    version=subprocess.check_output([lean,'--version'],text=True).strip()
    if '4.35.0' not in version: raise SystemExit('Use the pinned Lean 4.35.0 environment.')
    manifest=(ROOT/'sources.json').read_bytes()
    graph=json.loads(manifest)
    out=args.build.resolve();out.mkdir(exist_ok=True,parents=True)
    handle=(out/'replay.lock').open('a')
    fcntl.flock(handle,fcntl.LOCK_EX)
    hashes=FileHashes(out/'file-hashes.json')
    libs=[Path(x).resolve() for x in os.environ.get('LEAN_PATH','').split(os.pathsep) if x and Path(x).resolve()!=out]
    env=dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,[out,*libs])))
    identity=external_id(lean,version,libs,hashes)
    hashes.save()
    keys={};sources={}
    location=ROOT/'src'
    snapshot=tempfile.TemporaryDirectory(dir=out,prefix='sources-')
    srcroot=Path(snapshot.name)
    known_sources={}
    for original in location.rglob('*.lean'):
        rel=original.relative_to(location); path=srcroot/rel
        path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(original.read_bytes())
        known_sources[str(rel.with_suffix('')).replace(os.sep,'.')]=path
    srcenv=dict(env,LEAN_SRC_PATH=os.pathsep.join([str(srcroot),*[str(lb.parents[3]) for lb in libs if len(lb.parents)>3],os.environ.get('LEAN_SRC_PATH','')]))
    for n,path in known_sources.items():
        if n not in graph:
            if args.check_manifest: raise SystemExit(f'Unreleased source {n}')
            graph[n]={'sha256':'','imports':[]}
        record=graph[n];actual=digest(path.read_bytes())
        if actual!=record['sha256']:
            if args.check_manifest: raise SystemExit(f'Source digest mismatch for {n}')
            result=subprocess.run([lean,'--src-deps',str(path)],cwd=srcroot,env=srcenv,text=True,capture_output=True)
            if result.returncode: raise RuntimeError(result.stderr)
            deps=set()
            for line in result.stdout.splitlines():
                dep=Path(line).resolve()
                if dep.is_relative_to(srcroot):deps.add(str(dep.relative_to(srcroot).with_suffix('')).replace(os.sep,'.'))
            record['imports']=sorted(deps)
        sources[n]=actual
    missing=set(graph)-set(sources)
    if missing: raise SystemExit('Missing project sources: '+', '.join(sorted(missing)))
    old=read_json(out/'incremental.json',{})
    seed=read_json(ROOT/'parent-cache.json',{})
    seed_valid=(not args.clean and args.parent_cache and seed.get('environment')==identity)
    records={};status={'compiled':0,'reused':0,'seeded':0}
    def task(n):
        depkeys=[(d,keys[d]) for d in sorted(graph[n]['imports'])]
        key=digest(packed([SCHEMA,identity,sources[n],depkeys]))
        saved=old.get(n,{})
        if not args.clean and saved.get('key')==key and '.olean' in saved.get('products',{}) and products(out,n,hashes)==saved['products']:
            return key,saved,'reused'
        parent=seed.get('modules',{}).get(n,{})
        if seed_valid and parent.get('key')==key and '.olean' in parent.get('products',{}) and products(args.parent_cache,n,hashes)==parent['products']:
            copy_products(args.parent_cache,out,n,parent['products'])
            return key,dict(key=key,products=products(out,n,hashes)),'seeded'
        with tempfile.TemporaryDirectory(dir=out) as tmp:
            td=Path(tmp)
            rel=module_path(n).with_suffix('.olean')
            target=td/rel;target.parent.mkdir(exist_ok=True,parents=True)
            log=out/(n+'.log')
            with log.open('w') as f:
                ret=subprocess.run([lean,*FLAGS,'-o',str(target),str(module_path(n).with_suffix('.lean'))],cwd=srcroot,env=env,stdout=f,stderr=subprocess.STDOUT)
            txt=log.read_text()
            if ret.returncode or "uses 'sorry'" in txt or 'sorryAx' in txt: raise RuntimeError(n+'\n'+txt[-4000:])
            fs=products(td,n,hashes)
            if '.olean' not in fs:raise RuntimeError(n+' compiler produced no olean')
            copy_products(td,out,n,fs)
        return key,dict(key=key,products=products(out,n,hashes)),'compiled'
    pending=set(graph);active={}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        while pending or active:
            ready=sorted(n for n in pending if all(d in keys for d in graph[n]['imports']))
            for n in ready[:args.jobs-len(active)]:
                pending.remove(n);active[pool.submit(task,n)]=n
            if not active:raise ValueError('cyclic module imports')
            finished,_=wait(active,return_when=FIRST_COMPLETED)
            for job in finished:
                n=active.pop(job);key,record,kind=job.result();keys[n]=key;records[n]=record;status[kind]+=1
                if kind=='compiled': print('compiled '+n,flush=True)
    hashes.save()
    commit(out/'incremental.json',packed(records))
    report={'verified':len(graph),'source_manifest':digest(manifest),'environment':identity,**status,'modules':records}
    commit(out/'receipt.json',json.dumps(report,indent=1,sort_keys=True).encode()+b'\n')
    print('PASS',len(graph),'modules;',', '.join(f'{v} {k}' for k,v in status.items()),flush=True)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build',type=Path,default=ROOT/'.replay',help='persistent object and dependency cache')
    p.add_argument('--jobs',type=int,default=4)
    p.add_argument('--lean',default='lean')
    p.add_argument('--clean',action='store_true',help='recompile all project modules, bypassing old and parent objects')
    p.add_argument('--parent-cache',type=Path,help='optional authenticated parent object directory; unmatched modules recompile')
    p.add_argument('--check-manifest',action='store_true',help='also require the released source digests (omit when editing)')
    a=p.parse_args()
    if a.jobs<1:p.error('positive job count required')
    run(a)
