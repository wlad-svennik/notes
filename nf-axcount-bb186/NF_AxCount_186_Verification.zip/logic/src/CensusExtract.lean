import ConditionalSearchWords
namespace NF180Counting.CensusExtract
open NF180Counting.GuardedLogic
open NF192.ProofSearch (Command)

private theorem pop (pre tail : List Nat) (top cache : Nat) :
    ∃ d, run (nips pre.length) ⟨top,pre++tail,cache,0⟩ = ⟨top,tail,d,0⟩ := by
  induction pre generalizing cache with
  | nil => exact ⟨cache,rfl⟩
  | cons a pre ih => exact ih a

private theorem popThrough (pre tail : List Nat) (x top cache : Nat) :
    run (nips (pre.length+1)) ⟨top,pre++x::tail,cache,0⟩ = ⟨top,tail,x,0⟩ := by
  induction pre generalizing cache with
  | nil => rfl
  | cons a pre ih => exact ih a

/-- A cleanup AX may add any known stack prefix before the selected occurrence. -/
theorem selectStack (pre post : List Nat) (x : Nat) :
    ∃ w : List Command, ∀ (top cache : Nat) (tail : List Nat), ∃ d,
      run w ⟨top,pre++x::(post++tail),cache,0⟩ = ⟨x,tail,d,0⟩ := by
  refine ⟨nips (pre.length+1) ++ (.mp 1 :: nips post.length),?_⟩
  intro top cache tail
  rw [run_append,popThrough]
  exact pop post tail x top

theorem selectCache (post : List Nat) (x : Nat) :
    ∃ w : List Command, ∀ (top : Nat) (tail : List Nat), ∃ d,
      run w ⟨top,post++tail,x,0⟩ = ⟨x,tail,d,0⟩ := by
  refine ⟨.mp 1 :: nips post.length,?_⟩
  intro top tail
  exact pop post tail x top

theorem sweepAny (s : State) (zs : List Nat) (h : zs.length=9) :
    ∃ d, run (nips 7) (afterAX s zs) = ⟨0,s.top::s.stack,d,0⟩ := by
  let front := zs.reverse.tail
  have len : front.length = 8 := by simp [front,h]
  change ∃ d, run (nips 7) (nip ⟨0,front++s.top::s.stack,0,0⟩) = _
  cases hf : front with
  | nil => simp [hf] at len
  | cons k rest =>
    have hlen : rest.length = 7 := by simp [hf] at len; omega
    simp only [nip,List.cons_append,List.tail_cons,List.headD_cons]
    rw [← hlen]
    exact pop rest _ _ _

theorem twoSweeps (s : State) (first second : List Nat) (l : first.length=9) (m : second.length=9) :
    let t := run (nips 7) (afterAX s first)
    let z := run (nips 7) (afterAX t second)
    step (.mode 0) z = ⟨0,s.top::s.stack,0,0⟩ := by
  obtain ⟨c,h⟩ := sweepAny s first l
  obtain ⟨d,k⟩ := sweepAny ⟨0,s.top::s.stack,c,0⟩ second m
  dsimp only
  rw [h,k]
  simp [step,nip]

end NF180Counting.CensusExtract
#print axioms NF180Counting.CensusExtract.twoSweeps
#print axioms NF180Counting.CensusExtract.selectStack
