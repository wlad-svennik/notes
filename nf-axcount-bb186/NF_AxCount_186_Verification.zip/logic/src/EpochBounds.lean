import CensusLogic

namespace NF180Counting.EpochBounds
open NF192.Numerical
open NF180Counting.CensusLogic

theorem selector_budget (x y : Nat) : x+y ≤ pair x y := by
  have h := triangular_ge (x+y)
  unfold pair
  omega

private theorem twice_pair_ge_square (x y : Nat) :
    (x+y)^2 ≤ 2 * pair x y := by
  unfold pair
  generalize x+y = n
  cases n with
  | zero => simp
  | succ m =>
    simp only [Nat.pow_succ, Nat.pow_zero, Nat.one_mul, Nat.add_mul, Nat.mul_add, Nat.one_mul, Nat.mul_one]
    omega

private theorem left_sq (x y : Nat) : x^2 ≤ imp x y := by
  exact Nat.le_trans (Nat.pow_le_pow_left (Nat.le_add_right x y) 2) (twice_pair_ge_square x y)
private theorem right_sq (x y : Nat) : y^2 ≤ imp x y := by
  exact Nat.le_trans (Nat.pow_le_pow_left (Nat.le_add_left y x) 2) (twice_pair_ge_square x y)

theorem marker_grows (b a : Nat) : a^16 ≤ testRow b a := by
  have h1 : a^2 ≤ single b a := by
    exact Nat.le_trans (right_sq _ _) (Nat.le_succ _)
  have h2 : (a^2)^2 ≤ eqn (single b a) b :=
    Nat.le_trans (Nat.pow_le_pow_left h1 2) (Nat.le_trans (left_sq _ _) (Nat.le_succ _))
  have h3 := Nat.le_trans (Nat.pow_le_pow_left h2 2) (left_sq _ (eqn (single b b) b))
  have h4 := Nat.le_trans (Nat.pow_le_pow_left h3 2) (left_sq _ (eqn a b))
  simpa [testRow, ← Nat.pow_mul] using h4

theorem marker_keeps_cache (b a : Nat) : b ≤ testRow b a := by
  exact Nat.le_trans (show b ≤ eqn a b from Nat.le_trans (imp_ge_right a b) (Nat.le_succ _)) (imp_ge_right _ _)
private theorem imp_mono {a b c d : Nat} (h : a ≤ c) (j : b ≤ d) :
    imp a b ≤ imp c d := by
  unfold imp
  apply Nat.mul_le_mul_left
  simp only [Cantor.pair_eq]
  exact Nat.add_le_add (Cantor.triangle_mono (Nat.add_le_add h j)) j

private theorem app_mono {a b c d : Nat} (h : a ≤ c) (j : b ≤ d) :
    app a b ≤ app c d := Nat.succ_le_succ (imp_mono h j)

private theorem single_mono {a b c d : Nat} (h : a ≤ c) (j : b ≤ d) :
    single a b ≤ single c d := by
  have hw : witness a a ≤ witness c c := Nat.add_le_add_right (imp_mono h h) 2
  exact app_mono (app_mono (Nat.le_refl _) hw) j

theorem marker_floor (b a : Nat) : 1614700370257423492 ≤ testRow b a := by
  have z (n : Nat) : 0 ≤ n := Nat.zero_le n
  have m (k l : Nat) : eqn (single 0 0) 0 ≤ eqn (single k l) k :=
    app_mono (single_mono (z _) (z _)) (z _)
  exact Nat.le_trans (show 1614700370257423492 ≤ testRow 0 0 by decide)
    (imp_mono (imp_mono (m b a) (m b b)) (app_mono (z a) (z b)))

end NF180Counting.EpochBounds
#print axioms NF180Counting.EpochBounds.marker_grows
#print axioms NF180Counting.EpochBounds.marker_keeps_cache
#print axioms NF180Counting.EpochBounds.marker_floor
