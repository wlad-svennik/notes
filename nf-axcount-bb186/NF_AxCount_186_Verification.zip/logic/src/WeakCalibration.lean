import WeakTester
open FFL FFL.FirstOrder
namespace NF196.Weak
variable {V : Type} (A : NF188.Relabel.Basis V) (W J : V)
local infixl:71 " ⬝ " => A.app
def diag (x y : V) : V := W ⬝ A.K x ⬝ y
def norm : V := A.B ⬝ A.K (A.B ⬝ A.K (W ⬝ A.K J)) ⬝ full A W
theorem norm_law (f x : V) : norm A W J ⬝ f ⬝ x = diag A W J (diag A W (f ⬝ x) x) := by
  simp only [norm,diag,A.b_app,A.k_app,full_law]
def weakBasis (off : ∀ x y, x≠y → diag A W x y=J)
    (on : ∀ x, diag A W x x≠J) : ArbitraryBoolean.Basis V where
  app := A.app
  K := A.K
  B := A.B
  q := norm A W J
  yes := J
  no := diag A W J J
  k_app := A.k_app
  b_app := A.b_app
  ext := A.ext
  trueAt f x h := by rw [norm_law,h]; exact off _ _ (on x).symm
  falseAt f x h := by rw [norm_law,off _ _ h]
  distinct := (on J).symm

theorem weak_nonconstant (hsep : W≠J) (off : ∀ x y, x≠y → diag A W x y=J)
    (on : ∀ x, diag A W x x≠J) (a : V) : W≠A.K a := by
  intro same
  have eq : diag A W W W=diag A W J W := by
    simp only [diag,same,A.k_app]
  exact on W (eq.trans (off _ _ hsep.symm))

theorem consistent (off : ∀ x y, x≠y → diag A W x y=J)
    (on : ∀ x, diag A W x x≠J) : Entailment.Consistent 𝗡𝗙 := by
  letI : ArbitraryBoolean.Basis V := weakBasis A W J off on
  letI : Nonempty V := ⟨A.B⟩
  letI : Tarski.Structure ℒλ V := ArbitraryBoolean.fnStructure
  letI : Tarski.Structure.Eq ℒλ V := ⟨fun _ _ => Iff.rfl⟩
  letI : V↓[ℒλ] ⊧* 𝗙𝗡𝗙 := ArbitraryBoolean.fnModel_models
  have con := consistent_of_model 𝗙𝗡𝗙 V
  rw [Entailment.consistent_iff_unprovable_bot] at con ⊢
  intro h
  apply con
  simpa using DirectInterpretation.sound FNF.fnInterpretsNF h

theorem counting (hsep : (J ⬝ J) ≠ J)
    (off : ∀ x y, x≠y → diag A (J ⬝ J) x y=J)
    (on : ∀ x, diag A (J ⬝ J) x x≠J)
    (pointwise : ∀ x y, (J ⬝ (J ⬝ x)) ⬝ y=J ⬝ x) : RangeNFU.HasCountingModel := by
  letI : ArbitraryBoolean.Basis V := weakBasis A (J ⬝ J) J off on
  apply ArbitraryBoolean.countingModel J J (fun x => pointwise x J)
  refine ⟨J ⬝ J,⟨J,rfl⟩,?_⟩
  rintro x ⟨a,rfl⟩ e
  change A.app J (A.app J a) = A.app J J at e
  apply weak_nonconstant A (J ⬝ J) J hsep off on (J ⬝ a)
  apply A.ext
  intro z
  rw [← e,pointwise,A.k_app]

theorem fullClause {T : V} (distinct : T≠J)
    (h : ∀ f x, ((W ⬝ f ⬝ x=J) → (diag A W x x=J)) → f ⬝ x=x) :
    (∀ x y, x≠y → diag A W x y=J) ∧ (∀ x, diag A W x x≠J) := by
  classical
  have both (x y : V) (ne : x≠y) : diag A W x y=J ∧ diag A W y y≠J := by
    by_contra n
    apply ne
    rw [← A.k_app x y]
    apply h
    intro a
    by_contra b
    exact n ⟨a,b⟩
  constructor
  · exact fun x y ne => (both x y ne).1
  · intro y
    by_cases e : J=y
    · exact (both T y (e ▸ distinct)).2
    · exact (both J y e).2

theorem of_native (A : NF188.Chart V) :
  let B : NF188.Relabel.Basis V := ⟨A.app,A.K,A.B,A.k_app,A.b_app,A.ext⟩
  ∀ f x, ((B.app (B.app A.tester f) x=A.J) → (diag B A.tester x x=A.J)) → B.app f x=x := by
  dsimp only
  intro f x h
  by_contra ne
  have e := h (A.negative f x ne)
  have p := A.positive (A.K x) x (A.k_app _ _)
  apply A.goal
  exact p.symm.trans e
end NF196.Weak
#print axioms NF196.Weak.fullClause
#print axioms NF196.Weak.consistent
#print axioms NF196.Weak.counting
