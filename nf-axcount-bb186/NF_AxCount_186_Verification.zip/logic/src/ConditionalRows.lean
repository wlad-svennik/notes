import ConditionalModel

namespace NF180Counting.Conditional

theorem implication_row_iff {V : Type} (app : V → V → V) (s : V → Prop) :
    (∀ b c d, (s b → app b c = app b d) → app b c = app b d) ↔
      ∀ b, NC app b → s b := by
  classical
  constructor
  · intro row b nc
    obtain ⟨c,d,ne⟩ := nc
    by_contra h
    exact ne (row b c d (fun hs => (h hs).elim))
  · intro row b c d premise
    by_contra ne
    exact ne (premise (row b ⟨c,d,ne⟩))

theorem counting_model_of_implication_row {V : Type} (A : VariableMarkerNF.Marked V)
    (row : ∀ b c d,
      (A.app (A.app A.J (A.app A.J b)) A.J = A.app A.J b → A.app b c = A.app b d) →
       A.app b c = A.app b d) : RangeNFU.HasCountingModel := by
  exact counting_model A ((implication_row_iff _ _).mp row)

end NF180Counting.Conditional
#print axioms NF180Counting.Conditional.counting_model_of_implication_row
