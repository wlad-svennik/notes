module
public import C188Logic
public import C188GroundChart
@[expose] public section
set_option maxHeartbeats 0
namespace C188
open NF192 NF192.Ground NF192.Numerical NF192.Emitter

private theorem instance_row {r} (hr : RowsHold r) (a b c : Nat) {x : Nat}
    (hx : x ∈ rowList a b c 0) : evaluate r x := hr a b c 0 (Nat.zero_le _) x hx

theorem hold_iff_rows (r : Nat → Nat → Prop) : RowsHold r ↔ NF188.Rows AsSignature r := by
  constructor
  · intro hr
    have pos (a b) := instance_row hr a b 0 (x:=positiveRow a b) (by simp [rowList])
    have arg (a b c) := instance_row hr a b c (x:=row2 a b c) (by simp [rowList])
    have con (a b) := instance_row hr a b 0 (x:=row4 a b) (by simp [rowList])
    have fnc (a b c) := instance_row hr a b c (x:=row3 a b c) (by simp [rowList])
    have abs (a b c) := instance_row hr a b c (x:=nativeBRow a b c) (by simp [rowList])
    have euc (a b c) := instance_row hr a b c (x:=row6 a b c) (by simp [rowList])
    have neg (a b) := instance_row hr a b 0 (x:=negativeRow a b) (by simp [rowList])
    have ext (a b) := instance_row hr a b 0 (x:=row9 a b) (by simp [rowList])
    simp only [positiveRow,row2,row4,row3,nativeBRow,row6,negativeRow,row9,evaluate_imp,evaluate_eqn,goal] at *
    exact ⟨pos,arg,con,fnc,abs,euc,neg,ext⟩
  · intro R a b c u _ x hx
    simp only [rowList, List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with hx|hx|hx|hx|hx|hx|hx|hx|hx <;> subst x
    · simp only [row0,evaluate_imp]
      intro hca hac _
      by_cases hc : evaluate r c
      · exact hc
      · exact hac (hca (fun hc' => (hc hc').elim))
    all_goals simp only [positiveRow,row2,row4,row3,nativeBRow,row6,negativeRow,row9,goal,evaluate_imp,evaluate_eqn]
    · exact R.positive a b
    · exact R.bLaw a b c
    · exact R.argCongr a b c
    · exact R.funCongr a b c
    · exact R.euclid a b c
    · exact R.negative a b
    · exact R.kLaw a b
    · exact R.ext a b

private def pull (r : Term → Term → Prop) (a b : Nat) : Prop := r (decodeTerm a) (decodeTerm b)
private theorem pull_rows {r : Term → Term → Prop} (R : NF188.Rows Term.signature r) :
    NF188.Rows AsSignature (pull r) := by
  constructor
  all_goals
    simp only [pull, AsSignature, Signature.k, Signature.s, Signature.b,
      decodeTerm_app, decodeTerm_witness, decodeTerm_q]
  · exact fun a b => R.positive _ _
  · exact fun a b c => R.argCongr _ _ _
  · exact fun a b => R.kLaw _ _
  · exact fun a b c => R.funCongr _ _ _
  · exact fun a b c => R.bLaw _ _ _
  · exact fun a b c => R.euclid _ _ _
  · exact fun a b => R.negative _ _
  · exact fun a b => R.ext _ _

theorem ground_model_iff_chart :
    (∃ r, RowsHold r ∧ ¬ r s q) ↔ ∃ M : Type, Nonempty (NF188.Chart M) := by
  constructor
  · rintro ⟨r,h,hg⟩
    let R := (hold_iff_rows r).mp h
    exact ⟨R.Carrier, ⟨R.toChart hg⟩⟩
  · rintro ⟨M,⟨A⟩⟩
    let r := A.relation
    have R := A.term_rows
    have hg : ¬ r Term.signature.s Term.signature.q := A.goal
    refine ⟨pull r,(hold_iff_rows _).mpr (pull_rows R),?_⟩
    simpa only [pull,s,AsSignature,Signature.s,Term.signature,decodeTerm_app,decodeTerm_q] using hg

end C188
#print axioms C188.ground_model_iff_chart
