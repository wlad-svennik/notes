import NumericalEmitterBatch
set_option maxHeartbeats 0
set_option maxRecDepth 30000

namespace NF180Counting.GuardedEmitter
open NF192.Numerical NF192.Emitter

def readback (b : Nat) : Nat := eqn (app (app q (app q b)) q) (app q b)
def agrees (b c d : Nat) : Nat := eqn (app b c) (app b d)
def row (b c d : Nat) : Nat := imp (imp (readback b) (agrees b c d)) (agrees b c d)
def tokens : List Macro :=
  [.push0,.push0,.push4,.ap,.ap,.push0,.ap,.push0,.push4,.ap,.eqn,
   .push4,.push3,.ap,.push4,.push5,.ap,.eqn,.imp,
   .push4,.push3,.ap,.push4,.push5,.ap,.eqn,.imp]

theorem effect (n t stack c b d tail : Nat) :
    tokens.foldl Frame.apply ⟨n,t,stack,c,b,d,tail⟩ =
      ⟨n,row b c d,pair t stack,c,b,d,tail⟩ := by
  simp only [tokens,List.foldl_cons,List.foldl_nil,Frame.apply,Frame.push,Frame.combine,
    Cantor.unpair_pair,ctor,row,readback,agrees,imp,eqn,app,q]
  rfl

private theorem register_effect_from_fold (m : Macro) (tail : List Macro) (f g : Frame)
    (e : (m :: tail).foldl Frame.apply f = g) :
    Eval (sequence m tail) f.regs .normal g.regs := by
  cases e
  exact sequence_eval m tail f

theorem register_effect (n t stack c b d tail : Nat) :
    Eval (sequence .push0 tokens.tail) (Frame.regs ⟨n,t,stack,c,b,d,tail⟩) .normal
      (Frame.regs ⟨n,row b c d,pair t stack,c,b,d,tail⟩) := by
  exact register_effect_from_fold .push0 tokens.tail ⟨n,t,stack,c,b,d,tail⟩ ⟨n,row b c d,pair t stack,c,b,d,tail⟩
    (effect n t stack c b d tail)
end NF180Counting.GuardedEmitter
#print axioms NF180Counting.GuardedEmitter.register_effect
