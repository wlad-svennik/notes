import Init

namespace NF180Counting.CensusMarker

inductive CacheBound where
  | unknown | marker | huge
  deriving DecidableEq, Repr

inductive Phase where
  | tag (carry : Nat) (cache : CacheBound)
  | immediate (tag : Nat) (cache : CacheBound)
  | fields (count : Nat) (cache : CacheBound) (carry : Nat)
  | firstFields | tagR | drainImmediate | drainFields
  deriving DecidableEq, Repr

open Phase CacheBound
structure Field where
  digit : Nat
  targetEnd : Bool
  deriving Repr

/-- The exact thirteen independently audited scalar reads. -/
def markerFields : List Field :=
  [⟨0,false⟩,⟨1,true⟩,⟨1,false⟩,⟨0,true⟩,⟨0,false⟩,⟨1,true⟩,
   ⟨1,false⟩,⟨0,true⟩,⟨0,false⟩,⟨2,true⟩,⟨2,false⟩,⟨1,false⟩,⟨3,true⟩]

/-- At a crossing the current scalar may be large and all remaining scalars are zero.
The flag selects the first predecessor's postcondition (cache covers rank). -/
def crossing (residueOK : Bool) : Phase → Bool
  | tag _ h => h == huge
  | firstFields => residueOK
  | tagR | drainImmediate | drainFields => true
  | immediate t h => t ≤ 22 && (residueOK || t ≤ 2 || h != unknown)
  | fields _ _ r => residueOK || r == 0

/-- Universal safety of all abstract successors. The final two predicates are the
continuations after a field that continues or finishes the actual command. -/
def regular (a : Nat) (p : Phase) (next finish : Phase → Bool) : Bool :=
  match p with
  | firstFields => next firstFields && finish (tag 0 huge) && finish tagR
  | drainFields => next drainFields && finish (tag 0 huge)
  | tagR => next drainImmediate && (a != 0 || next (immediate 1 huge))
  | drainImmediate => next drainFields
  | tag r h => next (immediate (a+r) h)
  | immediate t h =>
    if t ≤ 1 then finish (tag 0 unknown)
    else t ≤ 22 && (if h == unknown then
      (List.range (t-1)).all fun i => next (fields (i+1) unknown (t-2-i))
      else next (fields (t-1) h 0))
  | fields n h r => if n > 1 then next (fields (n-1) h r)
      else finish (tag r (if h == huge then huge else marker))

/-- A zero-bias, zero-carry command boundary is already aligned to the target word. -/
def aligned (boundary : Bool) (bias : Int) : Phase → Bool
  | tag 0 _ => boundary && bias == 0
  | _ => false

def covered (residueOK : Bool) : List Field → Int → Phase → Bool
  | [], _, _ => false
  | f :: rest, bias, ph =>
    let a := (f.digit : Int) - bias
    if a < 0 then a == -1 && crossing residueOK ph
    else
      let e := bias + (if f.targetEnd then 1 else 0)
      let continuation (e' : Int) (p : Phase) :=
        aligned f.targetEnd e' p || covered residueOK rest e' p
      regular a.toNat ph (continuation e) (continuation (e-1))

set_option maxRecDepth 64000 in
set_option maxHeartbeats 2000000 in
theorem second_predecessor_exhausted_or_aligned :
    covered true markerFields (-2) (tag 0 unknown) &&
    covered true markerFields (-1) firstFields = true := by decide

set_option maxRecDepth 64000 in
set_option maxHeartbeats 2000000 in
theorem first_predecessor_exhausted_or_aligned :
    covered false markerFields (-1) (tag 0 unknown) &&
    covered false markerFields 0 drainFields = true := by decide

end NF180Counting.CensusMarker
#print axioms NF180Counting.CensusMarker.second_predecessor_exhausted_or_aligned
#print axioms NF180Counting.CensusMarker.first_predecessor_exhausted_or_aligned
