import NF188FiniteRows
import NFInterpretsComb
import C188RelabelBasis

namespace FFL.FirstOrder.SetTheory.NFFn.NF188Finite
open Classical
noncomputable section
variable {V : Type} [SetStructure V] [Nonempty V] [hT : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙]
def oldApp (f x : V) : V := Classical.choose (app_total f x)
theorem oldApp_spec (f x : V) : AppR f x (oldApp f x) := Classical.choose_spec (app_total f x)
theorem oldApp_iff (f x y : V) : AppR f x y ↔ oldApp f x = y :=
  ⟨fun h=> app_fun (oldApp_spec f x) h, fun e=> e ▸ oldApp_spec f x⟩
def oldK (v : V) : V := Classical.choose (exists_k v)
theorem oldK_spec (v : V) : KR v (oldK v) := Classical.choose_spec (exists_k v)
def oldB : V := Classical.choose (exists_b (V:=V))
theorem oldB_spec : IsB (oldB : V) := Classical.choose_spec exists_b

def oldBasis : NF188.Relabel.Basis V where
  app := oldApp
  K := oldK
  B := oldB
  k_app x y := (oldK_spec x y _).mp (oldApp_spec _ _)
  b_app f g x := (app_fun (oldApp_spec _ _) <| b_spec oldB_spec (oldK_spec x)
    (oldApp_spec _ _) (oldApp_spec _ _) (oldApp_spec _ _) (oldApp_spec _ _) (oldApp_spec _ _)).symm
  ext {_ _} h := app_ext fun x y hx => (oldApp_iff _ _ y).mpr ((h x).symm.trans ((oldApp_iff _ _ _).mp hx))


end
end FFL.FirstOrder.SetTheory.NFFn.NF188Finite
#print axioms FFL.FirstOrder.SetTheory.NFFn.NF188Finite.oldBasis
