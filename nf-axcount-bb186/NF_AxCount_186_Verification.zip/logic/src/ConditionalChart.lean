import ConditionalDerivation
namespace NF180Counting.GuardedLogic
open NF192 NF192.Numerical NF192.Ground NF192.Emitter
private def pull (r : Term → Term → Prop) (a b : Nat) : Prop := r (decodeTerm a) (decodeTerm b)
private theorem pull_rows {r : Term → Term → Prop} (R : VariableMarkerNF.Rows Term.signature r) :
    VariableMarkerNF.Rows AsSignature (pull r) := by
  constructor
  all_goals
    simp only [pull, AsSignature, Signature.k, Signature.s,
      decodeTerm_app, decodeTerm_witness, decodeTerm_q]
  · exact fun a b c => R.argCongr _ _ _
  · exact fun a b => R.kLaw _ _
  · exact fun a b c => R.funCongr _ _ _
  · exact fun a b c => R.bLaw _ _ _
  · exact fun a b c => R.euclid _ _ _
  · exact fun a b => R.test _ _
  · exact fun a b => R.ext _ _


/-- Every marked chart with the guarded law refutes derivability of the native goal. -/
theorem nonderivability_of_guarded_chart {V : Type} (A : VariableMarkerNF.Marked V)
    (h : ∀ b c d, (A.app (A.app A.J (A.app A.J b)) A.J = A.app A.J b → A.app b c = A.app b d) → A.app b c = A.app b d) : ¬ Deriv goal := by
  apply not_deriv_iff_ground_model.mpr
  let r := A.relation
  have original := (GuardedNative.hold_iff_rows _).mpr (pull_rows A.term_rows)
  have ng : ¬ r Term.signature.s Term.signature.q := by
    change A.eval Term.signature.s ≠ A.J
    rw [A.eval_s]
    exact A.proper
  refine ⟨pull r, ?_, ?_⟩
  · intro a b c u hu x hx
    by_cases old : x ∈ Moving186.rowList a b c u
    · exact original a b c u hu x old
    · have same : x = GuardedEmitter.row a c b := by
        cases hx with
        | head => exact (old (.head _)).elim
        | tail _ rest =>
          cases rest with
          | head => exact (old (.tail _ (.head _))).elim
          | tail _ rest =>
            cases rest with
            | head => rfl
            | tail _ retained => exact (old (.tail _ (.tail _ retained))).elim
      subst x
      simp only [GuardedEmitter.row,GuardedEmitter.readback,GuardedEmitter.agrees,evaluate_imp,evaluate_eqn,
        pull,r,VariableMarkerNF.Marked.relation,decodeTerm_app,decodeTerm_q,VariableMarkerNF.Marked.eval]
      exact h _ _ _
  · simpa only [pull,s,AsSignature,Signature.s,Term.signature,decodeTerm_app,decodeTerm_q] using ng
theorem nonderivability_iff_guarded_chart : ¬ Deriv goal ↔ HasGuardedChart :=
  ⟨guarded_chart_of_nonderivability, fun ⟨_,A,h⟩ => nonderivability_of_guarded_chart A h⟩

end NF180Counting.GuardedLogic
#print axioms NF180Counting.GuardedLogic.nonderivability_of_guarded_chart

#print axioms NF180Counting.GuardedLogic.nonderivability_iff_guarded_chart
