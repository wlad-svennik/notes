import NumericalCodes

namespace NF180Counting.CensusMarker
open NF192.Numerical NF192.Numerical.Cantor

/-- The shifted field is still on the same increasing Cantor diagonal. -/
theorem shift_positive (x b d : Nat) (hd : d ≤ x) :
    pair x b + d = pair (x-d) (b+d) := by
  have h : (x-d)+(b+d) = x+b := by omega
  simp only [pair_eq, h]; omega

/-- The shift can also pass through genuinely negative command-boundary offsets. -/
theorem shift_negative (x b d : Nat) (hd : d ≤ b) :
    pair x b - d = pair (x+d) (b-d) := by
  have h : (x+d)+(b-d) = x+b := by omega
  simp only [pair_eq, h]; omega

/-- The next diagonal has actual right tail zero. -/
theorem shift_overflow (x b : Nat) :
    pair x b + (x+1) = pair (x+b+1) 0 := by
  simp only [pair_eq, Nat.add_zero, triangle_succ]; omega

theorem decode_positive (x b d : Nat) (h : d ≤ x) :
    unpair (pair x b + d) = (x-d,b+d) := by
  rw [shift_positive x b d h,unpair_pair]

theorem decode_negative (x b d : Nat) (h : d ≤ b) :
    unpair (pair x b - d) = (x+d,b-d) := by
  rw [shift_negative x b d h,unpair_pair]

theorem decode_overflow (x b : Nat) : unpair (pair x b + (x+1)) = (x+b+1,0) := by
  rw [shift_overflow,unpair_pair]

/-- Both predecessors retain the freely chosen large immediate. -/
theorem predecessor (k z j : Nat) (hj : j ≤ z+1) :
    unpair (pair k (z+1) - j) = (k+j,z+1-j) := decode_negative k (z+1) j hj

end NF180Counting.CensusMarker
#print axioms NF180Counting.CensusMarker.decode_positive
#print axioms NF180Counting.CensusMarker.decode_negative
#print axioms NF180Counting.CensusMarker.decode_overflow
#print axioms NF180Counting.CensusMarker.predecessor
