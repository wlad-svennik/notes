import NF188OldBasis
import ChoppedFour
import NF188Tester

open FFL FFL.FirstOrder FFL.FirstOrder.SetTheory
open Classical
namespace NF196.Compact
open NFFn NFFn.NF188Finite
open JensenNFU.TFm (scons scons_zero scons_succ)
open DirectTranslation

def IsConstant {V : Type} [SetStructure V] (f : V) : Prop := ∃ x, KR x f
def select {V : Type} [SetStructure V] (u b f w : V) : Prop :=
  (IsConstant f ∧ AppR u f w) ∨ (¬ IsConstant f ∧ w=b)
def constN {γ : Nat → Nat} (i : Nat) (hi : γ i=12) :
    NDef γ (fun _ _ e => IsConstant (e i)) :=
  (NDef.ex 11 (NDef.ofS kD ![0,i+1] 3 (fun j => by fin_cases j <;> simp [hi]))).congr 
    (fun _ _ _ => Iff.rfl)
def selN {γ : Nat → Nat} (u b f w : Nat) (hu : γ u=13) (hb : γ b=12) (hf : γ f=12) (hw : γ w=12) :
    NDef γ (fun _ _ e => select (e u) (e b) (e f) (e w)) :=
  let k := constN f hf
  let a := NDef.ofS appD ![u,f,w] 4 (fun i => by fin_cases i <;> simp [hu,hf,hw])
  let e := NDef.ofS (SDef.eq (τ:=![12,12]) 0 1) ![w,b] 0 (fun i => by fin_cases i <;> simp [hw,hb])
  ((k.and a).or (k.not.and e)).congr (fun _ _ _ => Iff.rfl)

variable {V : Type} [SetStructure V] [Nonempty V] [ht : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙]
theorem selector (u b : V) : ∃ p, ∀ f w, AppR p f w ↔ select u b f w := by
  obtain ⟨G,hG⟩ := (NDef.ex (γ:=scons 12 (scons 13 (fun _ => 12))) 12 (NDef.ex 12
    ((NDef.ofS prD ![2,1,0] 4 (fun i => by fin_cases i <;> rfl)).and
     (selN 3 4 1 0 rfl rfl rfl rfl)))).comprehension (scons u (fun _ => b))
  apply app_of_graph (G:=select u b) hG
  · intro f
    by_cases c : IsConstant f
    · exact ⟨_,Or.inl ⟨c,oldApp_spec u f⟩⟩
    · exact ⟨b,Or.inr ⟨c,rfl⟩⟩
  · intro f w z a d
    rcases a with ⟨c,e⟩|⟨c,e⟩ <;> rcases d with ⟨k,g⟩|⟨k,g⟩
    · exact app_fun e g
    · exact (k c).elim
    · exact (c k).elim
    · exact e.trans g.symm

structure Chart (V : Type) extends NF188.Relabel.Basis V where
  J : V
  letter : app J J = B
  proper : B ≠ J
  off : ∀ x y, x≠y → app (app J (K x)) y=B
  on : ∀ x, app (app J (K x)) x≠B

private theorem identity {V : Type} (A : NF188.Relabel.Basis V) : ∃ i, ∀ x : V, A.app i x=x := by
  open NF188.Relabel.Syntax in
    exact ⟨val A A.B (fun _=>A.B) idT, fun x => by simp only [idT,con,val,kpow,valAtom,A.b_app,A.k_app]⟩

theorem in_model (V : Type) [SetStructure V] [Nonempty V] [hT : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙] :
    Nonempty (Chart V) := by
  let A : NF188.Relabel.Basis V := oldBasis
  let B := A.B
  obtain ⟨d,hd⟩ := NF188.Pure.four_labels V
  have ds : d 0≠d 1 := fun e => (by decide : (0 : Fin 4)≠1) (hd e)
  obtain ⟨yes,yes_ne⟩ : ∃ x : V, x≠B := by
    by_cases e : d 0=B
    · exact ⟨d 1,fun k=>ds (e.trans k.symm)⟩
    · exact ⟨d 0,e⟩
  obtain ⟨U,hU⟩ := TaggedFixedPoint.exists_tester yes B
  obtain ⟨j,hj⟩ := selector U B
  have tested (x y : V) := ((hU (A.K x) _).mp (oldApp_spec U _) y _).mp (oldApp_spec (oldApp U (A.K x)) y)
  have ka (x y : V) : AppR (A.K x) y y ↔ x=y := by
    rw [oldApp_iff]; change A.app (A.K x) y=y ↔ x=y; rw [A.k_app]
  have chooses (x : V) : A.app j (A.K x) = oldApp U (A.K x) := by
    apply (oldApp_iff _ _ _).mp
    exact (hj _ _).mpr (Or.inl ⟨⟨x,oldK_spec x⟩,oldApp_spec _ _⟩)
  have on (x : V) : A.app (A.app j (A.K x)) x=yes := by
    rw [chooses]; exact ((tested x x).resolve_right (fun z=>z.1 ((ka x x).mpr rfl))).2
  have off (x y : V) (ne : x≠y) : A.app (A.app j (A.K x)) y=B := by
    rw [chooses]; exact ((tested x y).resolve_left (fun z=>ne ((ka x y).mp z.1))).2
  have j_nc : ¬ IsConstant j := by
    rintro ⟨v,h⟩
    have hjK (x : V) : A.app j (A.K x)=v := (h _ _).mp (oldApp_spec j _)
    apply yes_ne
    have p := on (d 0)
    have n := off (d 1) (d 0) ds.symm
    rw [hjK] at p n
    exact p.symm.trans n
  have fallback (f : V) (n : ¬IsConstant f) : A.app j f=B :=
    (oldApp_iff _ _ _).mp ((hj f B).mpr (Or.inr ⟨n,rfl⟩))
  obtain ⟨i,idlaw⟩ := identity A
  have i_nc : ¬IsConstant i := by
    rintro ⟨v,h⟩
    have k (x : V) : x=v := (idlaw x).symm.trans ((h _ _).mp (oldApp_spec i x))
    exact ds ((k _).trans (k _).symm)
  have bi : A.app B i=A.K i := by
    apply A.ext; intro f; rw [A.k_app]
    apply A.ext; intro x
    simp only [B,A.b_app,idlaw,A.k_app]
  have b_nonconst (v : V) : B≠A.K v := by
    intro e
    have fix (x : V) : A.app B (A.K (A.K x))=A.K (A.K x) := by
      apply A.ext; intro y; apply A.ext; intro z
      simp only [B,A.b_app,A.k_app]
    have same (x : V) : v=A.K (A.K x) := by simpa only [e,A.k_app] using fix x
    have both := congrArg (fun z => A.app (A.app z B) B) ((same (d 0)).symm.trans (same (d 1)))
    exact ds (by simpa only [A.k_app] using both)
  have bj : B≠j := by
    intro e
    apply b_nonconst i
    exact (fallback i i_nc).symm.trans (by rw [← e]; exact bi)
  exact ⟨{
    toBasis := A
    J := j
    letter := fallback j j_nc
    proper := bj
    off := off
    on := fun x => by rw [on]; exact yes_ne }⟩

theorem of_consistent (h : Entailment.Consistent 𝗡𝗙) : ∃ V : Type, Nonempty (Chart V) := by
  by_contra no
  apply (Entailment.consistent_iff_unprovable_bot.mp h)
  apply SetTheory.complete.{0}
  intro V _ _ _
  exact (no ⟨V,in_model V⟩).elim
end NF196.Compact
#print axioms NF196.Compact.of_consistent
