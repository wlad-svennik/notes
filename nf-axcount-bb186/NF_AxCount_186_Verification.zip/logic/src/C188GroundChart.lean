module
public import GroundRows
@[expose] public section
namespace NF188
open NF192.Ground
universe u
/-- The native q is jj and its two literal outputs are q and j. B occupies the
syntactic witness slot H(q,j), hence the required difference at that argument. -/
structure Chart (V : Type u) where
  app : V → V → V
  K : V → V
  J : V
  B : V
  k_app : ∀ x y, app (K x) y=x
  b_app : ∀ f g x, app (app (app B f) g) x=app (app f (K x)) (app g x)
  ext : ∀ {f g}, (∀ x, app f x=app g x) → f=g
  positive : ∀ f x, app f x=x → app (app (app J J) f) x=app J J
  negative : ∀ f x, app f x≠x → app (app (app J J) f) x=J
  goal : app J J ≠ J
  separates : app (app J J) B ≠ app J B
structure Rows {X : Type u} (S : Signature X) (r : X → X → Prop) : Prop where
  positive : ∀ a b, r (S.app a b) b → r S.s (S.app (S.app S.s a) b)
  argCongr : ∀ a b c, r c b → r (S.app a c) (S.app a b)
  kLaw : ∀ a b, r (S.app (S.k b) a) b
  funCongr : ∀ a b c, r a c → r (S.app c b) (S.app a b)
  bLaw : ∀ a b c, r (S.app (S.app (S.app (S.h S.s S.q) c) a) b)
    (S.app (S.app c (S.k b)) (S.app a b))
  euclid : ∀ a b c, r a b → r a c → r c b
  negative : ∀ a b, (r (S.app a b) b → r S.s S.q) → r S.q (S.app (S.app S.s a) b)
  ext : ∀ a b, r (S.app b (S.h a b)) (S.app a (S.h a b)) → r a b
namespace Rows
variable {X : Type u} {S : Signature X} {r : X → X → Prop} (R : Rows S r)
include R
theorem rel_refl (a : X) : r a a :=
  R.euclid _ a a (R.kLaw S.q a) (R.kLaw S.q a)

theorem rel_symm {a b : X} (h : r a b) : r b a :=
  R.euclid a a b (R.rel_refl a) h

theorem rel_trans {a b c : X} (hab : r a b) (hbc : r b c) : r a c :=
  R.euclid b c a hbc (R.rel_symm hab)

theorem app_congr {a b c d : X} (hac : r a c) (hbd : r b d) :
    r (S.app a b) (S.app c d) :=
  R.rel_trans (R.rel_symm (R.funCongr a b c hac)) (R.argCongr c d b hbd)

theorem k_congr {a b : X} (hab : r a b) : r (S.k a) (S.k b) := by
  let d := S.h (S.k a) (S.k b)
  have h : r (S.app (S.k a) d) (S.app (S.k b) d) :=
    R.rel_trans (R.rel_trans (R.kLaw d a) hab) (R.rel_symm (R.kLaw d b))
  exact R.ext (S.k a) (S.k b) (R.rel_symm h)

def setoid : Setoid X where
  r := r
  iseqv := ⟨R.rel_refl, R.rel_symm, R.rel_trans⟩

def Carrier : Type u := Quotient R.setoid

def obj (a : X) : R.Carrier := Quotient.mk R.setoid a

theorem obj_eq_iff {a b : X} : R.obj a = R.obj b ↔ r a b :=
  ⟨fun h => Quotient.exact h, fun h => Quotient.sound (s := R.setoid) h⟩

def appObj (a b : R.Carrier) : R.Carrier :=
  Quotient.liftOn₂ a b (fun x y => R.obj (S.app x y))
    (fun _ _ _ _ hx hy => Quotient.sound (s := R.setoid) (R.app_congr hx hy))

def kObj (a : R.Carrier) : R.Carrier :=
  Quotient.liftOn a (fun x => R.obj (S.k x))
    (fun _ _ h => Quotient.sound (s := R.setoid) (R.k_congr h))

theorem app_obj (a b : X) : R.appObj (R.obj a) (R.obj b) = R.obj (S.app a b) := rfl

theorem k_obj (a : X) : R.kObj (R.obj a) = R.obj (S.k a) := rfl

theorem kObj_app (a b : R.Carrier) : R.appObj (R.kObj a) b = a := by
  refine Quotient.inductionOn₂ a b ?_
  intro x y
  exact R.obj_eq_iff.mpr (R.kLaw y x)

theorem bObj_app (x y z : R.Carrier) :
    R.appObj (R.appObj (R.appObj (R.obj (S.h S.s S.q)) x) y) z =
    R.appObj (R.appObj x (R.kObj z)) (R.appObj y z) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn z ?_
  intro c
  exact R.obj_eq_iff.mpr (R.bLaw b c a)

theorem appObj_ext {a b : R.Carrier} (h : ∀ x, R.appObj a x = R.appObj b x) :
    a = b := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  exact R.obj_eq_iff.mpr
    (R.ext x y (R.rel_symm (R.obj_eq_iff.mp (h (R.obj (S.h x y))))))

theorem positiveObj (a b : R.Carrier) (h : R.appObj a b = b) :
    R.appObj (R.appObj (R.obj S.s) a) b = R.obj S.s := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  exact (R.obj_eq_iff.mpr (R.positive x y (R.obj_eq_iff.mp h))).symm

theorem negativeObj (a b : R.Carrier) (h : R.appObj a b ≠ b) :
    R.appObj (R.appObj (R.obj S.s) a) b = R.obj S.q := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  have hn : r (S.app x y) y → r S.s S.q := fun e => (h (R.obj_eq_iff.mpr e)).elim
  exact (R.obj_eq_iff.mpr (R.negative x y hn)).symm


def toChart (h : ¬r S.s S.q) : Chart R.Carrier where
  app := R.appObj
  K := R.kObj
  J := R.obj S.q
  B := R.obj (S.h S.s S.q)
  k_app := R.kObj_app
  b_app := R.bObj_app
  ext := R.appObj_ext
  positive := R.positiveObj
  negative := R.negativeObj
  goal := fun e => h (R.obj_eq_iff.mp e)
  separates := fun e => h (R.ext _ _ (R.rel_symm (R.obj_eq_iff.mp e)))
end Rows
namespace Chart
variable {V : Type u} (A : Chart V)
local infixl:70 " ⬝ " => A.app
def tester := A.J ⬝ A.J
theorem tester_nonconstant (v : V) : A.tester ≠ A.K v := by
  intro h
  have pos := A.positive (A.K A.tester) A.tester (A.k_app _ _)
  have neg := A.negative (A.K A.J) A.tester (by rw [A.k_app]; exact Ne.symm A.goal)
  change (A.tester ⬝ A.K A.tester) ⬝ A.tester=A.tester at pos
  change (A.tester ⬝ A.K A.J) ⬝ A.tester=A.J at neg
  have flat (f : V) : A.tester ⬝ f = v := h ▸ A.k_app v f
  rw [flat] at pos neg
  exact A.goal (pos.symm.trans neg)
theorem exists_separator {a b : V} (ne : a≠b) : ∃ x, a ⬝ x ≠ b ⬝ x := by
  apply Classical.byContradiction
  intro no
  exact ne (A.ext (fun x => Classical.byContradiction (fun nx => no ⟨x,nx⟩)))
noncomputable def witness (a b : V) : V := by
  classical
  exact if h : a=b then A.K a else if a=A.tester ∧ b=A.J then A.B else Classical.choose (A.exists_separator h)
theorem witness_diag (a : V) : A.witness a a = A.K a := by classical simp [witness]
theorem witness_native : A.witness A.tester A.J = A.B := by
  classical
  simp [witness, show A.tester ≠ A.J from A.goal]
theorem witness_ext (a b : V) (h : b ⬝ A.witness a b = a ⬝ A.witness a b) : a=b := by
  classical
  by_cases e : a=b
  · exact e
  by_cases ab : a=A.tester ∧ b=A.J
  · obtain ⟨rfl,rfl⟩ := ab
    exact (A.separates (by rw [witness_native] at h; exact h.symm)).elim
  · have sep := Classical.choose_spec (A.exists_separator e)
    exact (sep (by simpa only [witness,dif_neg e,if_neg ab] using h.symm)).elim
noncomputable def eval : Term → V
 | .q => A.J
 | .app x y => A.app (eval x) (eval y)
 | .h x y => A.witness (eval x) (eval y)
def relation (a b : Term) := A.eval a=A.eval b
theorem term_rows : Rows Term.signature A.relation := by
  constructor
  · intro a b h; exact (A.positive _ _ h).symm
  · intro a b c e; exact congrArg (A.app (A.eval a)) e
  · intro x y; change A.app (A.witness _ _) _ = _; rw [witness_diag,A.k_app]
  · intro a b c h; exact congrArg (fun x => A.app x (A.eval b)) h.symm
  · intro a b c
    change (((A.witness A.tester A.J ⬝ _) ⬝ _) ⬝ _) = (_ ⬝ A.witness _ _) ⬝ _
    rw [witness_native,witness_diag,A.b_app]
    rfl
  · intro a b c e d; exact d.symm.trans e
  · intro a b h; exact (A.negative _ _ (fun e => A.goal (h e))).symm
  · intro a b h; exact A.witness_ext _ _ h
end Chart
end NF188
#print axioms NF188.Rows.toChart
#print axioms NF188.Chart.term_rows
