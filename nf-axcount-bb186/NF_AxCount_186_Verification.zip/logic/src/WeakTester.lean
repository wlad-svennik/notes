import C188RelabelBasis
import ChoppedChartNF
import ArbitraryBooleanCounting
open FFL FFL.FirstOrder

namespace NF196.Weak
open NF188.Relabel
open NF188.Relabel.Syntax

variable {V : Type} (A : Basis V) (W : V)
local infixl:71 " ⬝ " => A.app
local infixl:75 " ◆ " => Term.app
private theorem val_id' (e : Nat → V) (x : V) : val A W e idT ⬝ x=x := by
  simp only [idT,con,val,kpow,valAtom,A.b_app,A.k_app]
private theorem val_abs' (s : Term) : ∀ j, good j s=true → ∀ (e : Nat→V) (x : V),
    val A W e (abs j s) ⬝ kpow A j x = val A W (cons x e) s := by
  induction s with
  | leaf m a =>
    intro j h e x
    cases a with
    | var i =>
      cases i with
      | zero =>
        have eq : m=j := beq_iff_eq.mp h
        subst j; exact val_id' A W e _
      | succ i => exact A.k_app _ _
    | b => exact A.k_app _ _
    | p => exact A.k_app _ _
  | app s t hs ht =>
    intro j h e x
    obtain ⟨g,k⟩ : good (j+1) s=true ∧ good j t=true := by simpa only [good,Bool.and_eq_true] using h
    change A.B ⬝ val A W e (abs (j+1) s) ⬝ val A W e (abs j t) ⬝ kpow A j x = _
    rw [A.b_app,ht j k e x]
    exact congrArg (fun f=>A.app f (val A W (cons x e) t)) (hs (j+1) g e x)

-- W(K(fx))x, with the K propagated to the leaves and f at de Bruijn index 1.
def body : Term := con .p ◆ (con .b ◆ .leaf 1 (.var 1) ◆ .leaf 1 (.var 0)) ◆ con (.var 0)
def full : V := val A W (fun _=>W) (abs 0 (abs 0 body))

theorem full_law (f x : V) : full A W ⬝ f ⬝ x = W ⬝ A.K (f ⬝ x) ⬝ x := by
  have h := val_abs' A W (abs 0 body) 0 (by decide) (fun _=>W) f
  have k := val_abs' A W body 0 (by decide) (cons f (fun _=>W)) x
  have eq : A.B ⬝ A.K f ⬝ A.K x = A.K (f ⬝ x) := by
    apply A.ext; intro z; simp only [A.b_app,A.k_app]
  change full A W ⬝ f = _ at h
  rw [h]; change val A W (cons f fun _=>W) (abs 0 body) ⬝ x=_
  rw [show val A W (cons f fun _=>W) (abs 0 body) ⬝ x = _ from k]
  change W ⬝ (A.B ⬝ A.K f ⬝ A.K x) ⬝ x = _
  rw [eq]

def strongBasis (T F : V) (positive : ∀ x, W ⬝ A.K x ⬝ x = T)
    (negative : ∀ x y, x≠y → W ⬝ A.K x ⬝ y = F) (sep : T≠F) :
    ArbitraryBoolean.Basis V where
  app := A.app
  K := A.K
  B := A.B
  q := full A W
  yes := T
  no := F
  k_app := A.k_app
  b_app := A.b_app
  ext := A.ext
  trueAt f x h := by rw [full_law,h,positive]
  falseAt f x h := by rw [full_law,negative _ _ h]
  distinct := sep

theorem merged_iff (T F : V) (sep : T≠F) :
    (∀ x y, ((W ⬝ A.K x ⬝ y=F) → ((W ⬝ A.K x ⬝ x=T) → x=y)) → x=y) ↔
    ((∀ x, W ⬝ A.K x ⬝ x=T) ∧ (∀ x y, x≠y → W ⬝ A.K x ⬝ y=F)) := by
  classical
  constructor
  · intro h
    have both (x y : V) (ne : x≠y) :
        W ⬝ A.K x ⬝ y=F ∧ W ⬝ A.K x ⬝ x=T := by
      by_contra n; apply ne; apply h; intro a b; exact False.elim (n ⟨a,b⟩)
    constructor
    · intro x
      by_cases e : x=T
      · exact (both x F (e ▸ sep)).2
      · exact (both x T e).2
    · intro x y hi; exact (both x y hi).1
  · rintro ⟨p,n⟩ x y h; by_cases e : x=y
    · exact e
    · exact h (n x y e) (p x)
end NF196.Weak
#print axioms NF196.Weak.strongBasis
#print axioms NF196.Weak.merged_iff
