import CountingModel

namespace NF180Counting.Conditional

variable {V : Type} (A : VariableMarkerNF.Marked V)
local infixl:75 " ⋆ " => A.app
local notation "β" => A.B
local notation "κ" => A.K
local notation "j" => A.J

def NC {W : Type} (ap : W → W → W) (f : W) := ∃ c d, ap f c ≠ ap f d
def Dom {W : Type} (ap : W → W → W) (f y : W) :=
  NC ap y ∧ ∃ b, NC ap b ∧ ap f b = y

private theorem nk (a : V) : β ≠ κ a := by
  have fix (x : V) : β ⋆ κ (κ x) = κ (κ x) := by
    apply A.ext; intro y; apply A.ext; intro z
    simp only [A.b_app,A.k_app]
  intro h
  have flat (x : V) : a=κ (κ x) := by simpa only [h,A.k_app] using fix x
  have e := congrArg (fun y => y ⋆ j ⋆ j) ((flat β).symm.trans (flat j))
  exact A.proper (by simpa only [A.k_app] using e)

private theorem not_nc {x : V} (h : ¬NC A.app x) : x = κ (x ⋆ j) := by
  apply A.ext; intro z; rw [A.k_app]
  exact Classical.byContradiction (fun ne => h ⟨z,j,ne⟩)

private theorem third : ∃ z, β ≠ z ∧ j ≠ z := by
  classical
  by_cases ne : j ≠ κ β
  · exact ⟨_,nk A β,ne⟩
  · refine ⟨κ j,nk A j,?_⟩
    intro h
    have b := (Classical.not_not.mp ne).symm.trans h
    have e := congrArg (fun x => x ⋆ j) b
    exact A.proper (by simpa only [A.k_app] using e)

theorem domain_properties (scalar : ∀ b, NC A.app b → j ⋆ (j ⋆ b) ⋆ j = j ⋆ b) :
    (∀ y, Dom A.app j y → Dom A.app j (j ⋆ y)) ∧
    (∀ y, Dom A.app j y → j ⋆ y ⋆ j = y) ∧
    (∃ t, Dom A.app j t ∧ ∀ x, Dom A.app j x → j ⋆ x ≠ t) := by
  classical
  have jnc : NC A.app j := by
    by_contra h
    have h0 := not_nc A h
    obtain ⟨v,bv,jv⟩ := third A
    have eb := A.off β v bv
    have ej := A.off j v jv
    have eq : j ⋆ κ β = j ⋆ κ j := by calc
      _ = κ (j ⋆ j) ⋆ κ β := congrArg (fun s => s ⋆ κ β) h0
      _ = κ (j ⋆ j) ⋆ κ j := (A.k_app _ _).trans (A.k_app _ _).symm
      _ = _ := congrArg (fun s => s ⋆ κ j) h0.symm
    exact A.proper (eb.symm.trans ((congrArg (fun z => z ⋆ v) eq).trans ej))
  have bj : β ⋆ j ≠ j := by
    intro e
    have h := congrArg (fun x => x ⋆ κ j ⋆ β) e
    rw [A.b_app,A.k_app,A.off β j A.proper, A.off j β A.proper.symm] at h
    exact A.proper h
  have out : ¬ ∃ b, NC A.app b ∧ j ⋆ b = j := by
    rintro ⟨b,h,e⟩
    have k := scalar b h
    rw [e,A.letter] at k
    exact bj k
  have read (y : V) (h : Dom A.app j y) : j ⋆ y ⋆ j = y := by
    obtain ⟨_,b,hb,rfl⟩ := h; exact scalar b hb
  have close (y : V) (h : Dom A.app j y) : Dom A.app j (j ⋆ y) := by
    refine ⟨?_,y,h.1,rfl⟩
    by_contra no
    have flat := not_nc A no
    rw [read y h] at flat
    have ej : y ≠ j := by rintro rfl; exact out h.2
    have k := scalar y h.1
    rw [flat,A.off y j ej] at k
    obtain ⟨c,d,n⟩ := h.1
    exact n (calc
      y ⋆ c = κ y ⋆ c := congrArg (fun z => z ⋆ c) k
      _ = κ y ⋆ d := (A.k_app _ _).trans (A.k_app _ _).symm
      _ = y ⋆ d := congrArg (fun z => z ⋆ d) k.symm)
  refine ⟨close,read,?_⟩
  by_contra! surj
  have back (y : V) (h : Dom A.app j y) : Dom A.app j (y ⋆ j) := by
    obtain ⟨x,hx,rfl⟩ := surj y h
    rwa [read x hx]
  have bnc : NC A.app β := Classical.byContradiction (fun no => nk A _ (not_nc A no))
  have root : Dom A.app j β := ⟨bnc,j,jnc,A.letter⟩
  have rewind := back _ (back _ (back _ root))
  rw [A.b_app,A.letter,A.off j β A.proper.symm] at rewind
  exact out rewind.2

end NF180Counting.Conditional
#print axioms NF180Counting.Conditional.domain_properties
