import Moving186Logic
import MovingRows
set_option maxHeartbeats 0
namespace NF180Counting.GuardedNative
open NF192 NF192.Ground NF192.Numerical NF192.Emitter

private theorem instance_row {r} (hr : Moving186.RowsHold r) (a b c : Nat) {x : Nat}
    (hx : x ∈ Moving186.rowList a b c 0) : evaluate r x := hr a b c 0 (Nat.zero_le _) x hx

theorem hold_iff_rows (r : Nat → Nat → Prop) : Moving186.RowsHold r ↔ VariableMarkerNF.Rows AsSignature r := by
  constructor
  · intro hr
    have arg (a b c) := instance_row hr a b c (x:=row2 a b c) (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))
    have con (a b) := instance_row hr a b 0 (x:=row4 a b) (.tail _ (.head _))
    have fnc (a b c) := instance_row hr a b c (x:=row3 a b c) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))
    have abs (a b c) := instance_row hr a b c (x:=Moving186.bRow a b c) (.tail _ (.tail _ (.tail _ (.head _))))
    have euc (a b c) := instance_row hr a b c (x:=row6 a b c) (.tail _ (.tail _ (.head _)))
    have neg (a b) := instance_row hr a b 0 (x:=Moving186.testRow b a) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))))
    have ext (a b) := instance_row hr a b 0 (x:=row9 a b) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))))
    simp only [Moving186.single,row2,row4,row3,Moving186.bRow,row6,Moving186.testRow,row9,evaluate_imp,evaluate_eqn] at arg con fnc abs euc neg ext
    exact ⟨arg,con,fnc,abs,euc,(fun x y => neg y x),ext⟩
  · intro R a b c u _ x hx
    simp only [Moving186.rowList, List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with hx|hx|hx|hx|hx|hx|hx|hx <;> subst x
    · simp only [row0,evaluate_imp]
      intro hca hac _
      by_cases hc : evaluate r c
      · exact hc
      · exact hac (hca (fun hc' => (hc hc').elim))
    all_goals simp only [Moving186.single,row2,row4,row3,Moving186.bRow,row6,Moving186.testRow,row9,evaluate_imp,evaluate_eqn]
    · exact R.kLaw a b
    · exact R.euclid a b c
    · exact R.bLaw a b c
    · exact R.argCongr a b c
    · exact R.funCongr a b c
    · exact R.test b a
    · exact R.ext a b

end NF180Counting.GuardedNative
