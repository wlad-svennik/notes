import Init

namespace NF180Counting

/-- D is the variable marker of the 180-state calculus. -/
theorem anchor_iff {V : Type u} (app D : V → V → V) (X : V)
    (off : ∀ a b, a ≠ b → D a b = a) (on_ : ∀ a, D a a ≠ a) :
    app (app (app X X) X) X = D X (app X X) ↔
      app X X ≠ X ∧ app (app (app X X) X) X = X := by
  constructor
  · intro h
    have ne : app X X ≠ X := by
      intro bad
      rw [bad, bad, bad] at h
      exact on_ X h.symm
    exact ⟨ne, h.trans (off _ _ ne.symm)⟩
  · rintro ⟨ne,h⟩
    exact h.trans (off _ _ ne.symm).symm

/-- The two added rows yield a proper self-injection on the range of X. -/
theorem range_gap {V : Type u} (app D : V → V → V) (X : V)
    (off : ∀ a b, a ≠ b → D a b = a) (on_ : ∀ a, D a a ≠ a)
    (scalar : ∀ a, app (app X (app X a)) X = app X a)
    (anchor : app (app (app X X) X) X = D X (app X X)) :
    ∃ t, (∃ z, app X z = t) ∧ ∀ x, (∃ z, app X z = x) → app X x ≠ t := by
  classical
  obtain ⟨ne, neg⟩ := (anchor_iff app D X off on_).mp anchor
  let Q := app X X
  let R (a : V) := ∃ z, app X z = a
  let E (a : V) := ∃ x, R x ∧ app X x = a
  have cancel {a : V} (h : R a) : app (app X a) X = a := by
    obtain ⟨z,rfl⟩ := h
    exact scalar z
  have back {y : V} (h : E y) : R (app y X) := by
    obtain ⟨x,hx,rfl⟩ := h
    rw [cancel hx]; exact hx
  have outside : ¬ R X := by
    intro hx
    exact ne ((congrArg (fun y => app y X) (cancel hx)).symm.trans neg)
  by_cases hq : E Q
  · refine ⟨app Q X, back hq, ?_⟩
    intro x hx eq_
    exact outside (neg ▸ back (show E (app Q X) from ⟨x, hx, eq_⟩))
  · exact ⟨Q, ⟨X,rfl⟩, fun x hx eq_ => hq ⟨x, hx, eq_⟩⟩

/-- In a J-point chart the two new rows hold for its counting letter X,
provided the new variable marker has its advertised off-diagonal values. -/
theorem rows_of_jpoint {V : Type u} (app D : V → V → V) (X : V)
    (off : ∀ a b, a ≠ b → D a b = a) (proper : app X X ≠ X)
    (negative : ∀ f x, app f x ≠ x → app (app (app X X) f) x = X)
    (pointwise : ∀ x z, app (app X (app X x)) z = app X x) :
    (∀ a, app (app X (app X a)) X = app X a) ∧
    app (app (app X X) X) X = D X (app X X) :=
  ⟨fun a => pointwise a X, (negative X X proper).trans (off _ _ proper.symm).symm⟩

/-- The J-point counting letter is not a constant row. -/
theorem nonconstant_of_jpoint {V : Type u} (ap : V → V → V) (K : V → V) (X : V)
    (k : ∀ a b, ap (K a) b = a) (ne : ap X X ≠ X)
    (negative : ∀ f x, ap f x ≠ x → ap (ap (ap X X) f) x = X)
    (pointwise : ∀ x z, ap (ap X (ap X x)) z = ap X x) :
    ¬ ∃ c, ∀ t, ap X t = c := by
  rintro ⟨c,h⟩
  let Q := ap X X
  have hQ (t : V) : ap Q t = Q := by
    have e := pointwise X t
    rw [show ap X (ap X X) = ap X X from (h _).trans (h _).symm] at e
    exact e
  have no := negative (K X) Q (fun eq_ => ne (eq_.symm.trans (k X Q)))
  change ap (ap Q (K X)) Q=X at no
  rw [hQ, hQ] at no
  exact ne no

/-- The patch at one nonconstant label makes X the distinguishing argument
for B and j and preserves jj = B. The "represented" hypothesis gives the
three branches of the full-chart comprehension written out in the note. -/
theorem patch_at_X {V : Type u} (ap : V → V → V) (K : V → V)
    (B j X s : V) (g : V → V)
    (k : ∀ a b, ap (K a) b = a)
    (markers : ∀ a, ap j (K a) = g a)
    (off : ∀ a b, a ≠ b → ap (g a) b = a)
    (on_ : ∀ a, ap (g a) a ≠ a)
    (third : ∀ a b : V, ∃ t, a ≠ t ∧ b ≠ t)
    (ne : ap X X ≠ X) (atX : ap j X = s)
    (sQ : s ≠ ap X X) (sB : s ≠ ap B X)
    (otherwise : ∀ f, (¬ ∃ t, f = K t) → f ≠ X → ap j f = B) :
    ap j j = B ∧ B ≠ j ∧ ap B X ≠ ap j X ∧
      (∀ a b, a ≠ b → ap (ap j (K a)) b = a) ∧
      ∀ a, ap (ap j (K a)) a ≠ a := by
  have nc : ¬ ∃ a, j = K a := by
    rintro ⟨a,eq_⟩
    obtain ⟨t,h₁,h₂⟩ := third (ap X X) X
    have flat (b : V) : g b = a := (markers b).symm.trans (eq_ ▸ k a (K b))
    have l := off _ _ h₁
    have r := off _ _ h₂
    rw [flat] at l r
    exact ne (l.symm.trans r)
  have jX : j ≠ X := fun eq_ => sQ (atX.symm.trans (congrArg (fun t => ap t X) eq_))
  have separated : ap B X ≠ ap j X := fun eq_ => sB (atX.symm.trans eq_.symm)
  refine ⟨otherwise j nc jX, fun eq_ => separated (congrArg (fun t => ap t X) eq_), separated, ?_, ?_⟩
  · intro a b h
    rw [markers]; exact off a b h
  · intro a
    rw [markers]; exact on_ a

end NF180Counting
#print axioms NF180Counting.range_gap
#print axioms NF180Counting.rows_of_jpoint
#print axioms NF180Counting.nonconstant_of_jpoint
#print axioms NF180Counting.patch_at_X
