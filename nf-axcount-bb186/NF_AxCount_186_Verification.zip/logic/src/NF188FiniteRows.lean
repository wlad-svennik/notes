import NFFn

namespace FFL.FirstOrder.SetTheory.NFFn
open Classical
noncomputable section

namespace NF188Finite
/-- A finite case analysis on whether the argument equals one of finitely many parameters. -/
inductive Expr (n : ℕ) where
  | input
  | val (i : Fin n)
  | test (i : Fin n) (yes no : Expr n)

def value {V : Type} {n : ℕ} (e : Fin n → V) (x : V) : Expr n → V
  | .input => x
  | .val i => e i
  | .test i yes no => if x = e i then value e x yes else value e x no

private def args {V : Type} {n : ℕ} (v : Fin (n+3) → V) (i : Fin n) := v i.succ.succ.succ

private def exprD {n : ℕ} (e : Expr n) :
    SDef (8 :> (8 :> (8 :> (fun _ : Fin n => 8))))
      (fun _ _ v => v 0 = value (args v) (v 1) e) := by
  induction e with
  | input => exact SDef.eq 0 1
  | val i => exact SDef.eq 0 i.succ.succ.succ
  | test i yes no yh nh =>
    let h := @SDef.eq (n+3) (8 :> (8 :> (8 :> (fun _ : Fin n => 8)))) 1 i.succ.succ.succ rfl
    apply ((h.and yh).or (h.not.and nh)).congr
    intro V st v
    change (v 1 = args v i ∧ _ ∨ v 1 ≠ args v i ∧ _) ↔ _
    by_cases hit : v 1 = args v i <;> simp [value,hit]

/-- In pure NF's intrinsic graph application, every finite switch is an actual function row. -/
theorem exists_row {V : Type} [SetStructure V] [Nonempty V] [hT : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙]
    {n : ℕ} (e : Fin n → V) (t : Expr n) :
    ∃ p : V, ∀ x y, AppR p x y ↔ y = value e x t := by
  let form := SDef.ex (τ := (8 :> (fun _ : Fin n => 8))) 8 (SDef.ex 8
      ((prD.comp ![2,1,0] 0).and (exprD t)))
  obtain ⟨F,hF⟩ := form.comprehension e
  apply app_of_graph (F:=F) (G:=fun x y => y = value e x t) hF
  · exact fun x => ⟨_,rfl⟩
  · exact fun _ _ _ h h' => h.trans h'.symm

theorem exists_swap {V : Type} [SetStructure V] [Nonempty V] [V↓[ℒₛₑₜ] ⊧* 𝗡𝗙] (a b : V) :
    ∃ p : V, ∀ x y, AppR p x y ↔ y = (if x=a then b else if x=b then a else x) :=
  exists_row ![a,b] (.test 0 (.val 1) (.test 1 (.val 0) .input))

theorem exists_cycle {V : Type} [SetStructure V] [Nonempty V] [V↓[ℒₛₑₜ] ⊧* 𝗡𝗙] (a b c : V) :
    ∃ p : V, ∀ x y, AppR p x y ↔ y = (if x=a then b else if x=b then c else a) :=
  exists_row ![a,b,c] (.test 0 (.val 1) (.test 1 (.val 2) (.val 0)))

end NF188Finite
end
end FFL.FirstOrder.SetTheory.NFFn
#print axioms FFL.FirstOrder.SetTheory.NFFn.NF188Finite.exists_swap
