import NFFn
open FFL FFL.FirstOrder
namespace NF188.Pure
open FFL.FirstOrder.SetTheory
theorem four_labels (V : Type) [SetStructure V] [Nonempty V] [V↓[ℒₛₑₜ] ⊧* 𝗡𝗙] :
    ∃ d : Fin 4 → V, Function.Injective d := by
  obtain ⟨z,hz⟩ := Hin.exists_zero (V:=V)
  choose f hf using (NFFn.sg_total (V:=V))
  have hi : Function.Injective f := by
    intro x y e
    have hx : NFFn.Sg x (f y) := by rw [←e]; exact hf x
    exact NFFn.sg_inj hx (hf y)
  have hn (x : V) : f x ≠ z := fun e => NFFn.sg_ne_zero (hf x) (by rw [e]; exact hz)
  let a : Nat → V := Nat.rec z (fun _ y => f y)
  have inject : ∀ n m, a n=a m → n=m := by
    intro n; induction n with
    | zero =>
      intro m; cases m with
      | zero => exact fun _ => rfl
      | succ m => exact fun e => False.elim (hn (a m) e.symm)
    | succ n ih =>
      intro m; cases m with
      | zero => exact fun e => False.elim (hn (a n) e)
      | succ m => exact fun e => congrArg Nat.succ (ih _ (hi e))
  exact ⟨fun i => a i.val,fun _ _ e=>Fin.ext (inject _ _ e)⟩
end NF188.Pure
#print axioms NF188.Pure.four_labels
