import CensusChart

namespace NF180Counting.CensusSelector
open NF192 NF192.Numerical NF192.Emitter

/-- Pairs (cache, remaining batches) seen at the row emitter in one AX command. -/
def visits : Nat → Nat → List (Nat × Nat)
  | 0, c => [(0,c)]
  | b+1, 0 => [(b+1,0)]
  | b+1, c+1 => (b+1,c+1) :: visits b c

theorem head_mem (b c : Nat) : (b,c) ∈ visits b c := by
  cases b <;> cases c <;> simp [visits]

theorem target_mem (b c i : Nat) : (b,c) ∈ visits (b+i) (c+i) := by
  induction i with
  | zero => simpa using head_mem b c
  | succ i ih => exact List.mem_cons_of_mem _ ih

theorem number_visited (b c : Nat) : (visits b c).length = min b c+1 := by
  induction b generalizing c with
  | zero => simp [visits]
  | succ b ih =>
    cases c with
    | zero => simp [visits]
    | succ c => simp [visits,ih] <;> omega

/-- R3 on exiting the instructions at 3509 and 38. -/
def carry : Nat → Nat → Nat
  | 0,c => c
  | _+1,0 => 0
  | b+1,c+1 => carry b c

theorem carry_eq (b c : Nat) : carry b c = c-b := by
  induction b generalizing c with
  | zero => rfl
  | succ b ih =>
    cases c with
    | zero => simp [carry]
    | succ c => simpa [carry] using ih c

theorem cleanup_strict (b c : Nat) (hb : 0 < b) (hc : 0 < c) : carry b c < c := by
  rw [carry_eq]; omega

theorem seed_bound (n : Nat) : n ≤ row4 n 0 := by
  apply Nat.le_trans _ (show app (konst 0) n ≤ eqn (app (konst 0) n) 0 by
    unfold eqn; have := pair_ge_left (app (konst 0) n) 0; omega)
  unfold app
  have := pair_ge_right (konst 0) n
  omega

theorem selected (a b c u : Nat) (le_ : u ≤ a) :
    let seed := row4 b 0
    let i := seed-b
    (b,c) ∈ visits seed (c+i) ∧ u + (a-u) = a := by
  dsimp only
  have sb := seed_bound b
  have eq : b+(row4 b 0-b)=row4 b 0 := by omega
  have h := target_mem b c (row4 b 0-b)
  rw [eq] at h
  exact ⟨h,by omega⟩

theorem marker_pos (b a : Nat) : 0 < CensusLogic.testRow b a := by
  exact Nat.lt_of_lt_of_le (show 0 < eqn a b by simp [eqn])
    (imp_ge_right _ _)

end NF180Counting.CensusSelector
#print axioms NF180Counting.CensusSelector.selected
#print axioms NF180Counting.CensusSelector.cleanup_strict
