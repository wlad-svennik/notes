import C188Model
import ArbitraryBooleanFNF
import FnInterpretsNFU
open FFL FFL.FirstOrder
namespace NF188.Chart
/-- The bare J-point chart interprets FunctionNF. Its membership construction has an
internally non-finite universe, sufficient for Jensen NFU + Infinity to interpret NF. -/
theorem consistent_nf {V : Type} (A : NF188.Chart V) : Entailment.Consistent 𝗡𝗙 := by
  letI : ArbitraryBoolean.Basis V :=
    ⟨A.app,A.K,A.B,A.tester,A.tester,A.J,A.k_app,A.b_app,A.ext,A.positive,A.negative,A.goal⟩
  letI : Nonempty V := ⟨A.B⟩
  letI : Tarski.Structure ℒλ V := ArbitraryBoolean.fnStructure
  letI : Tarski.Structure.Eq ℒλ V := ⟨fun _ _ => Iff.rfl⟩
  letI : V↓[ℒλ] ⊧* 𝗙𝗡𝗙 := ArbitraryBoolean.fnModel_models
  have con := consistent_of_model 𝗙𝗡𝗙 V
  rw [Entailment.consistent_iff_unprovable_bot] at con ⊢
  intro h
  apply con
  simpa using DirectInterpretation.sound FNF.fnInterpretsNF h
end NF188.Chart
theorem C188.consistent_nf_of_nonderivability (h : ¬ C188.Deriv NF192.Numerical.goal) :
    Entailment.Consistent 𝗡𝗙 := by
  obtain ⟨V,⟨A⟩⟩ := C188.ground_model_iff_chart.mp (C188.not_deriv_iff_ground_model.mp h)
  exact A.consistent_nf
#print axioms C188.consistent_nf_of_nonderivability
