module
public import C188GroundChart
@[expose] public section

namespace NF188.Relabel
universe u

/-- An extensional old application algebra with constant functions and the stratified abstractor. -/
structure Basis (V : Type u) where
  app : V → V → V
  K : V → V
  B : V
  k_app : ∀ x y, app (K x) y=x
  b_app : ∀ f g x, app (app (app B f) g) x=app (app f (K x)) (app g x)
  ext : ∀ {f g}, (∀ x, app f x = app g x) → f = g
namespace Syntax
inductive Atom
  | var (i : Nat) | b | p
inductive Term
  | leaf (m : Nat) (a : Atom)
  | app (s t : Term)
def con (a : Atom) : Term := .leaf 0 a
local infixl:75 " ◆ " => Term.app
def idT : Term := con .b ◆ (con .b ◆ con .b ◆ con .b) ◆ con .b
def abs : Nat → Term → Term
  | _, .leaf _ (.var 0) => idT
  | _, .leaf m (.var (i+1)) => .leaf (m+1) (.var i)
  | _, .leaf m .b => .leaf (m+1) .b
  | _, .leaf m .p => .leaf (m+1) .p
  | j, .app s t => con .b ◆ abs (j+1) s ◆ abs j t
def good : Nat → Term → Bool
  | j, .leaf m (.var 0) => m == j
  | _, .leaf _ _ => true
  | j, .app s t => good (j+1) s && good j t

variable {V : Type u} (A : Basis V) (p : V)
local infixl:75 " ⬝ " => A.app
def kpow : Nat → V → V
  | 0,x => x
  | m+1,x => A.K (kpow m x)
def valAtom (e : Nat → V) : Atom → V
  | .var i => e i
  | .b => A.B
  | .p => p
def val (e : Nat → V) : Term → V
  | .leaf m a => kpow A m (valAtom A p e a)
  | .app s t => val e s ⬝ val e t
def cons (x : V) (e : Nat → V) : Nat → V
  | 0 => x
  | n+1 => e n
private theorem val_id (e : Nat → V) (x : V) : val A p e idT ⬝ x = x := by
  simp only [idT,con,val,kpow,valAtom,A.b_app,A.k_app]
private theorem val_abs (s : Term) : ∀ j, good j s = true → ∀ (e : Nat → V) (x : V),
    val A p e (abs j s) ⬝ kpow A j x = val A p (cons x e) s := by
  induction s with
  | leaf m a =>
    intro j h e x
    cases a with
    | var i =>
      cases i with
      | zero =>
        have eq : m = j := beq_iff_eq.mp h
        subst j
        exact val_id A p e (kpow A m x)
      | succ i => exact A.k_app _ _
    | b => exact A.k_app _ _
    | p => exact A.k_app _ _
  | app s t ihs iht =>
    intro j h e x
    obtain ⟨hs,ht⟩ : good (j+1) s = true ∧ good j t = true := by
      simpa only [good,Bool.and_eq_true] using h
    change A.B ⬝ val A p e (abs (j+1) s) ⬝ val A p e (abs j t) ⬝ kpow A j x = _
    rw [A.b_app,iht j ht e x]
    exact congrArg (fun f => A.app f (val A p (cons x e) t)) (ihs (j+1) hs e x)

-- f, g, x have indices 2, 1, 0 inside the innermost abstraction.
def body : Term :=
  (con .p ◆ ((con .p ◆ con (.var 2)) ◆ (con .p ◆ .leaf 1 (.var 0)))) ◆
    ((con .p ◆ con (.var 1)) ◆ con (.var 0))
def middle : Term := con .p ◆ abs 0 body
def outer : Term := con .p ◆ abs 0 middle

def abstractor : V := p ⬝ val A p (fun _ => p) (abs 0 outer)

theorem abstractor_law (ih : ∀ x, p ⬝ (p ⬝ x) = x) (f g x : V) :
    (p ⬝ ((p ⬝ ((p ⬝ abstractor A p) ⬝ f)) ⬝ g)) ⬝ x =
    (p ⬝ ((p ⬝ f) ⬝ (p ⬝ A.K x))) ⬝ ((p ⬝ g) ⬝ x) := by
  let e := fun _ : Nat => p
  have hf := val_abs A p outer 0 (by decide) e f
  have hg := val_abs A p middle 0 (by decide) (cons f e) g
  have hx := val_abs A p body 0 (by decide) (cons g (cons f e)) x
  change val A p e (abs 0 outer) ⬝ f = p ⬝ val A p (cons f e) (abs 0 middle) at hf
  change val A p (cons f e) (abs 0 middle) ⬝ g = p ⬝ val A p (cons g (cons f e)) (abs 0 body) at hg
  change val A p (cons g (cons f e)) (abs 0 body) ⬝ x = _ at hx
  simp only [abstractor,ih]
  rw [hf,ih,hg,ih,hx]
  rfl

end Syntax

/-- A represented involution of a function chart preserves its stratified abstraction basis. -/
def Basis.relabel {V : Type u} (A : Basis V) (p : V)
    (ih : ∀ x, A.app p (A.app p x) = x) : Basis V where
  app f x := A.app (A.app p f) x
  K x := A.app p (A.K x)
  B := Syntax.abstractor A p
  k_app x y := by rw [ih,A.k_app]
  b_app := Syntax.abstractor_law A p ih
  ext {_ _} h := by
    have eq := A.ext h
    simpa only [ih] using congrArg (A.app p) eq

end NF188.Relabel
#print axioms NF188.Relabel.Basis.relabel
