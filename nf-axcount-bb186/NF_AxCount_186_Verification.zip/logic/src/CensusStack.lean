import ConditionalSearchWords

namespace NF180Counting.CensusStack
open NF192.Numerical NF192.Emitter NF180Counting.GuardedLogic

/-- Even after CD5, numeric-mode fallthrough cannot detach a formula from the final row. -/
theorem numeric_return_mismatch (a b h : Nat) (hc : h ≤ b) : h ≠ imp (lastRow a b) a := by
  have h1 := imp_ge_right (eqn (app b (witness a b)) (app a (witness a b))) (eqn a b)
  have h2 := imp_ge_left (lastRow a b) a
  change eqn a b ≤ lastRow a b at h1
  have hp := pair_ge_right a b
  unfold eqn at h1
  omega

/-- For arbitrary natural counters and arbitrarily many batches, afterAX preserves the entire
old proof stack and places only actual proved entries in its other observable positions. -/
theorem after_rows_sound (s : State) (rows : List Nat) (hs : s.Sound)
    (hr : ∀ x ∈ rows, GuardedLogic.Deriv x) : (afterAX s rows).Sound := by
  apply nip_sound
  refine ⟨deriv_zero,?_,deriv_zero⟩
  intro x hx
  rcases List.mem_append.mp hx with h | h
  · exact hr _ (List.mem_reverse.mp (List.mem_of_mem_tail h))
  · rcases List.mem_cons.mp h with h | h
    · simpa only [h] using hs.1
    · exact hs.2.1 _ h

/-- The chronological source emits only old-calculus axioms for arbitrary batch histories. -/
theorem batches_sound (params : List (Nat × Nat × Nat × Nat))
    (h : ∀ p ∈ params, p.2.2.2 ≤ p.1) :
    ∀ x ∈ params.flatMap (fun p : Nat × Nat × Nat × Nat => GuardedLogic.rowList p.1 p.2.1 p.2.2.1 p.2.2.2), GuardedLogic.Deriv x := by
  intro x hx
  obtain ⟨p,pm,xm⟩ := List.mem_flatMap.mp hx
  exact .row (h p pm) xm
end NF180Counting.CensusStack
#print axioms NF180Counting.CensusStack.numeric_return_mismatch
#print axioms NF180Counting.CensusStack.after_rows_sound
#print axioms NF180Counting.CensusStack.batches_sound
