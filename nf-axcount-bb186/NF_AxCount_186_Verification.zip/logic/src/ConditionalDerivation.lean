import ConditionalLogic
import ConditionalRows
import ConditionalNativeRows

namespace NF180Counting.GuardedLogic
open NF192 NF192.Numerical NF192.Ground NF192.Emitter

private theorem original_rows {r} (h : RowsHold r) : Moving186.RowsHold r := by
  intro a b c u hu x hx
  apply h a b c u hu x
  cases hx with
  | head => exact .head _
  | tail _ rest =>
    cases rest with
    | head => exact .tail _ (.head _)
    | tail _ retained => exact .tail _ (.tail _ (.tail _ retained))

def HasGuardedChart : Prop := ∃ (V : Type) (A : VariableMarkerNF.Marked V), ∀ b c d,
    (A.app (A.app A.J (A.app A.J b)) A.J = A.app A.J b → A.app b c = A.app b d) →
       A.app b c = A.app b d

theorem guarded_chart_of_nonderivability (h : ¬ Deriv goal) : HasGuardedChart := by
  obtain ⟨r,hr,ng⟩ := not_deriv_iff_ground_model.mp h
  let R := (GuardedNative.hold_iff_rows r).mp (original_rows hr)
  let A := R.toMarked ng
  refine ⟨R.Carrier, A, ?_⟩
  intro x y z
  revert y z
  refine Quotient.inductionOn x ?_
  intro b y
  refine Quotient.inductionOn y ?_
  intro c z
  refine Quotient.inductionOn z ?_
  intro d
  have ax := hr b d c 0 (Nat.zero_le b) (GuardedEmitter.row b c d) (.tail _ (.tail _ (.head _)))
  simp only [GuardedEmitter.row,GuardedEmitter.readback,GuardedEmitter.agrees,evaluate_imp,evaluate_eqn] at ax
  change (R.obj (app (app q (app q b)) q)=R.obj (app q b) →
    R.obj (app b c)=R.obj (app b d)) → R.obj (app b c)=R.obj (app b d)
  simpa only [R.obj_eq_iff] using ax

theorem nonderivability_yields_counting (h : ¬ Deriv goal) : RangeNFU.HasCountingModel := by
  obtain ⟨_, A, row⟩ := guarded_chart_of_nonderivability h
  exact Conditional.counting_model_of_implication_row A row

end NF180Counting.GuardedLogic
#print axioms NF180Counting.GuardedLogic.nonderivability_yields_counting
