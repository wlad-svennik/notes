module
public import C200Rows
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 50000
namespace C188
open NF192 NF192.Numerical NF192.Emitter

def positiveRow (a b : Nat) : Nat :=
  imp (eqn (app a b) b) (eqn 1 (app (app 1 a) b))
def positiveRowTokens : List Macro :=
  [.push4, .push5, .ap, .push5, .eqn, .push0, .incTop, .push0, .incTop, .push4, .ap, .push5, .ap, .eqn, .imp]
theorem positiveRow_effect (n t stack c a b tail : Nat) :
    positiveRowTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
      ⟨n,positiveRow a b,pair t stack,c,a,b,tail⟩ := by
  simp only [positiveRowTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push,
    Frame.combine, Cantor.unpair_pair, ctor, positiveRow, imp, eqn, app, witness, goal, B_is_three, s_is_one, q, Nat.add_zero] <;> rfl

def nativeBRow (a b c : Nat) : Nat :=
  eqn (app (app (app 4 c) a) b) (app (app c (witness b b)) (app a b))
def nativeBRowTokens : List Macro :=
  [.push0, .incTop, .incTop, .incTop, .incTop, .push3, .ap, .push4, .ap, .push5, .ap, .push3, .push5, .push5, .witness, .ap, .push4, .push5, .ap, .ap, .eqn]
theorem nativeBRow_effect (n t stack c a b tail : Nat) :
    nativeBRowTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
      ⟨n,nativeBRow a b c,pair t stack,c,a,b,tail⟩ := by
  simp only [nativeBRowTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push,
    Frame.combine, Cantor.unpair_pair, ctor, nativeBRow, imp, eqn, app, witness, goal, B_is_three, s_is_one, q, Nat.add_zero] <;> rfl

def negativeRow (a b : Nat) : Nat :=
  imp (imp (eqn (app a b) b) goal) (eqn 0 (app (app 1 a) b))
def negativeRowTokens : List Macro :=
  [.push4, .push5, .ap, .push5, .eqn, .push0, .incTop, .incTop, .incTop, .imp, .push0, .push0, .incTop, .push4, .ap, .push5, .ap, .eqn, .imp]
theorem negativeRow_effect (n t stack c a b tail : Nat) :
    negativeRowTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
      ⟨n,negativeRow a b,pair t stack,c,a,b,tail⟩ := by
  simp only [negativeRowTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push,
    Frame.combine, Cantor.unpair_pair, ctor, negativeRow, imp, eqn, app, witness, goal, B_is_three, s_is_one, q, Nat.add_zero] <;> rfl

end C188
