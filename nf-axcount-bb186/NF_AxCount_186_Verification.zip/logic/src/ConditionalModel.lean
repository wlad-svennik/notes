import ConditionalAlgebra
import JJ203Range
open FFL FFL.FirstOrder
namespace NF180Counting.Conditional
open FFL.FirstOrder.FNF FFL.FirstOrder.FNF.CountSet
open JensenNFU.TFm (scons)
noncomputable section
variable {M : Type} [Tarski.Structure ℒλ M] [Tarski.Structure.Eq ℒλ M] [Nonempty M] [M↓[ℒλ] ⊧* 𝗙𝗡𝗙]
local infixl:70 " ⬝ " => App

def nonconstB : BT [1] (fun v : Nat → M => NC App (v 0)) := by
  refine (BT.ex (Γ := [1]) 0 (BT.ex 0 (BT.ex 0 (BT.ex 0
    ((BT.app 4 3 1 0 rfl rfl rfl).and ((BT.app 4 2 0 0 rfl rfl rfl).and (BT.eq 1 0 0 rfl rfl).not)))))).congr ?_
  intro v
  refine ⟨?_,?_⟩
  · rintro ⟨c,d,u,w,eu,ew,ne⟩
    exact ⟨c,d,fun e => ne (eu.symm.trans (e.trans ew))⟩
  · rintro ⟨c,d,ne⟩
    exact ⟨c,d,_,_,rfl,rfl,ne⟩

theorem represented (j : M) : ∃ d : M, IsSet d ∧ ∀ y, Mem y d ↔ Dom App j y := by
  let p : BT [1,2] (fun v : Nat → M => Dom App (v 1) (v 0)) :=
    (nonconstB.sub [0] 0).and (BT.ex 1 ((nonconstB.sub [0] 0).and (BT.app 2 0 1 1 rfl rfl rfl)))
  exact p.set (fun _ => j)

private theorem graph (d j : M) : ∃ f : M, IsSet f ∧ ∀ p,
    Mem p f ↔ ∃ x y, p = kp x y ∧ Mem x d ∧ j ⬝ x = y := by
  exact (BT.ex (Γ := [2,1,1]) 0 (BT.ex 0 ((kpB.sub [2,1,0] 0).and
    ((BT.mem 1 3 0 rfl rfl).and (BT.app 4 1 0 0 rfl rfl rfl))))).set (scons d (fun _ => j))

private theorem liftGraph (d j q : M) : ∃ g : M, IsSet g ∧ ∀ p,
    Mem p g ↔ ∃ x y w t, p = kp x y ∧ Mem x d ∧ j ⬝ x = w ∧ w ⬝ q = t ∧ y = sing t := by
  exact (BT.ex (Γ := [3,2,2,0]) 1 (BT.ex 1 (BT.ex 1 (BT.ex 0 ((kpB.sub [4,3,2] 1).and
   ((BT.mem 3 5 1 rfl rfl).and ((BT.app 6 3 1 1 rfl rfl rfl).and
    ((BT.app 1 7 0 0 rfl rfl rfl).and (singB.sub [2,0] 0))))))))).set (scons d (scons j (fun _ => q)))

theorem conditional_set (j : M)
    (closed : ∀ y, Dom App j y → Dom App j (j ⬝ y))
    (read : ∀ y, Dom App j y → j ⬝ y ⬝ j = y)
    (gap : ∃ t, Dom App j t ∧ ∀ x, Dom App j x → j ⬝ x ≠ t) :
    ∃ d : M, IsSet d ∧ Strong d ∧ Dedekind d := by
  obtain ⟨d,hd,range⟩ := represented j
  have member {x : M} (hx : Mem x d) : Mem (j ⬝ x) d := (range _).mpr (closed _ ((range _).mp hx))
  have cancel {x : M} (hx : Mem x d) : j ⬝ x ⬝ j = x := read x ((range x).mp hx)
  obtain ⟨g,hg,lift⟩ := liftGraph d j j
  have strong : Strong d := by
    refine ⟨g,hg,fun p => ?_⟩
    rw [lift]
    constructor
    · rintro ⟨x,y,_,_,pair,mem,rfl,rfl,rfl⟩
      exact ⟨x,mem,by simpa only [cancel mem] using pair⟩
    · rintro ⟨x,h,rfl⟩
      exact ⟨x,sing x,j ⬝ x,x,rfl,h,rfl,cancel h,rfl⟩
  obtain ⟨f,hf,graph⟩ := graph d j
  have appgraph (a b : M) : Ap f a b ↔ Mem a d ∧ j ⬝ a = b := by
    change Mem (kp a b) f ↔ _
    rw [graph]
    constructor
    · rintro ⟨x,y,p,mem,val⟩
      obtain ⟨rfl,rfl⟩ := kp_inj p
      exact ⟨mem,val⟩
    · rintro ⟨mem,val⟩
      exact ⟨a,b,rfl,mem,val⟩
  have inj : Inj f d d := by
    constructor
    · intro x y h
      obtain ⟨mem,rfl⟩ := (appgraph _ _).mp h
      exact ⟨mem,member mem⟩
    · exact fun x hx => ⟨_,(appgraph _ _).mpr ⟨hx,rfl⟩⟩
    · intro x y z ha hb
      exact ((appgraph _ _).mp ha).2.symm.trans ((appgraph _ _).mp hb).2
    · intro x y z hx hy
      obtain ⟨mx,ex⟩ := (appgraph _ _).mp hx
      obtain ⟨my,ey⟩ := (appgraph _ _).mp hy
      exact (cancel mx).symm.trans ((congrArg (fun a => a ⬝ j) (ex.trans ey.symm)).trans (cancel my))
  obtain ⟨t,rt,missing⟩ := gap
  refine ⟨d,hd,strong,f,t,hf,inj,(range t).mpr rt,?_⟩
  intro x atX
  obtain ⟨hx,e⟩ := (appgraph x t).mp atX
  exact missing x ((range x).mp hx) e
end

theorem counting_model {V : Type} (A : VariableMarkerNF.Marked V)
    (row : ∀ b, NC A.app b → A.app (A.app A.J (A.app A.J b)) A.J = A.app A.J b) : RangeNFU.HasCountingModel := by
  let S := A.toBasis
  let J := A.J
  let r := VariableMarker.reference S J
  let s := VariableMarker.diag S J r r
  have off (x y : V) : x ≠ y → VariableMarker.diag S J x y = x := A.off x y
  have on_ (x : V) : VariableMarker.diag S J x x ≠ x := A.on x
  have n : s ≠ r := A.on r
  obtain ⟨a,na⟩ := A.exists_sep n
  obtain ⟨b,nb⟩ := A.exists_sep na
  obtain ⟨c,nc⟩ := A.exists_sep nb
  obtain ⟨d,nd⟩ := A.exists_sep nc
  let W := VariableMarker.weak S J a b c d
  let yes := S.app (S.app (S.app (S.app s a) b) c) d
  have fixedOff (x y : V) (h : x ≠ y) : NF196.Weak.diag S W x y = yes := by
    change S.app (S.app (VariableMarker.weak S J a b c d) (S.K x)) y = _
    rw [VariableMarker.weak_apply, VariableMarker.probe_eq S J off h]
  have fixedOn (x : V) : NF196.Weak.diag S W x x ≠ yes := by
    change S.app (S.app (VariableMarker.weak S J a b c d) (S.K x)) x ≠ _
    rw [VariableMarker.weak_apply, off _ _ (Ne.symm (VariableMarker.probe_ne S J on_ x))]
    exact nd.symm
  letI : ArbitraryBoolean.Basis V := NF196.Weak.weakBasis S W yes fixedOff fixedOn
  letI : Nonempty V := ⟨A.B⟩
  letI : Tarski.Structure ℒλ V := ArbitraryBoolean.fnStructure
  letI : Tarski.Structure.Eq ℒλ V := ⟨fun _ _ => Iff.rfl⟩
  letI : V↓[ℒλ] ⊧* 𝗙𝗡𝗙 := ArbitraryBoolean.fnModel_models
  obtain ⟨closed,read,gap⟩ := domain_properties A row
  obtain ⟨d,_,strong,inj⟩ := conditional_set A.J closed read gap
  obtain ⟨M,h,c,f,t,F,g⟩ := FNF.CountSet.model_with_strong_dedekind d strong inj
  exact ⟨V,inferInstance,M,h,c,d,f,t,F,g⟩

end NF180Counting.Conditional
#print axioms NF180Counting.Conditional.counting_model
