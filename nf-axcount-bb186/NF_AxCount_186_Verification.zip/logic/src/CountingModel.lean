import CountingExtension
import VariableDetector
import MovingRows
import ArbitraryBooleanCounting
open FFL FFL.FirstOrder
namespace NF180Counting

/-- The model has Dedekind Infinity and full internal Rosser Counting. -/
theorem has_counting_model {V : Type} (A : VariableMarkerNF.Marked V) (X : V)
    (scalar : ∀ a, A.app (A.app X (A.app X a)) X = A.app X a)
    (anchor : A.app (A.app (A.app X X) X) X =
      A.app (A.app A.J (A.K X)) (A.app X X)) :
    RangeNFU.HasCountingModel := by
  let S := A.toBasis
  let J := A.J
  let r := VariableMarker.reference S J
  let s := VariableMarker.diag S J r r
  have off (x y : V) : x ≠ y → VariableMarker.diag S J x y = x := A.off x y
  have on_ (x : V) : VariableMarker.diag S J x x ≠ x := A.on x
  have n : s ≠ r := A.on r
  obtain ⟨a,na⟩ := A.exists_sep n
  obtain ⟨b,nb⟩ := A.exists_sep na
  obtain ⟨c,nc⟩ := A.exists_sep nb
  obtain ⟨d,nd⟩ := A.exists_sep nc
  let W := VariableMarker.weak S J a b c d
  let yes := S.app (S.app (S.app (S.app s a) b) c) d
  have fixedOff (x y : V) (h : x ≠ y) : NF196.Weak.diag S W x y = yes := by
    change S.app (S.app (VariableMarker.weak S J a b c d) (S.K x)) y = _
    rw [VariableMarker.weak_apply, VariableMarker.probe_eq S J off h]
  have fixedOn (x : V) : NF196.Weak.diag S W x x ≠ yes := by
    change S.app (S.app (VariableMarker.weak S J a b c d) (S.K x)) x ≠ _
    rw [VariableMarker.weak_apply, off _ _ (Ne.symm (VariableMarker.probe_ne S J on_ x))]
    exact nd.symm
  letI : ArbitraryBoolean.Basis V := NF196.Weak.weakBasis S W yes fixedOff fixedOn
  exact ArbitraryBoolean.countingModel X X scalar
    (range_gap A.app (VariableMarker.diag S J) X off on_ scalar anchor)
end NF180Counting
#print axioms NF180Counting.has_counting_model
