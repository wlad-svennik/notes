# A 186-state inconsistency search for NF + AxCount

R. Gutin and E. Glazer

Start `candidate.tm` in state `k:74` on the all-zero, two-way infinite binary tape. Its 372 instructions specify both bits for each of 186 working states. The only transition to the separate halt state reads 1 in `k:302`. Each row gives the current state, read bit, write bit, head motion, and next state.

The machine halts exactly when the earlier 187-state guarded machine can derive its refutation goal, formula code 3. This gives a one-state improvement for pure NF with Rosser’s full Axiom of Counting under the mathematical calibration used for the 187-state machine. The equivalence concerns ordinary natural-number computation. The complete equivalence is a written argument supported by the individual kernel-checked results below.

## How the state was saved

The AX loop emits nine formulas at a time. The older machine reads two additional fields from its encoded input in each batch. The new loop reads one field and obtains the other parameter from the proof cache, counting it down once per batch. This reduces the register program from 3,642 to 3,632 instructions and its compiled binary table from 187 to 186 working states.

Every emitted row is still an instance of a sound schema. To recover a prescribed row, the proof search first puts a sufficiently large known theorem code in the cache, then runs the two counters down to the required values. For the missing orientation of extensionality when the second argument is zero, the model construction uses the separating witness for the reversed pair. The two witnesses need not agree. The file `search/source_argument.md` gives the construction and its use inside a proof.

The cache can reach zero before the other counter. The remaining counter can then change how the next command is parsed. A fixed six-command prefix ensures that the enumeration reaches each detecting proof word from a clean boundary. The argument examines the target enumeration counter and its two immediate predecessors, and covers unbounded incoming counter values. See `search/MarkerProof.md` and `search/marker_certificate.py`.

## Trying the next state reduction

Use the fast screen with each candidate binary table and its matching register source. To compile the fixture runner once and reuse it:

```
c++ -O2 -std=c++17 screen/probe.cpp -o probe
python3 screen.py candidate.tm source.sites.json --probe ./probe
```

The screen counts graph-reachable states, runs the table from blank, and compares complete successor tapes against the register source on four concrete inputs for every instruction. On the 186-state table it checked 14,528 cases and 7,716,766 binary steps in 0.44 seconds after the fixture runner was built. A rejected 185-state merge reached a normal boot boundary and then failed at register instruction 3510. Passing this screen gives a candidate for the unbounded check.

When only the decoder changes, the register source hash tells you whether the mathematical proof from the previous table applies directly. A change to the register source calls for revisiting the affected source lemmas. Rebuild the physical proof for a new record before reporting it as fully checked. The expensive configurations below are opt-in.

## Verification and replay

From the extracted directory, run:

```
python3 check.py
```

This needs Python 3.10 or later. It checks the table and source hashes, graph reachability, branch coverage in the receipt, the literal blank-tape run, the register control-flow diff, and the two predecessor case analyses. The quick check reads the physical proof receipts. A complete physical rebuild took 7 minutes 50 seconds on the reference run, including the blank-tape proof. To rebuild the physical branch certificates and the Lean blank-tape proof, put Lean 4.35.0 and its `leanchecker-paranoid` executable on PATH, then run:

```
python3 check.py --kernel
```

The binary machine reaches register instruction 0 with R0 = 3 and the other eight registers zero after 75,311 steps. The physical instruction proofs cover all 9,526 branch cases, with induction over arbitrarily long register and spare fields. Graph reachability is counted from the designated start state. The physical refinement is obtained by joining the matching full-tape boundaries, as in the preceding release. Every nonhalting branch takes a positive number of binary steps.

For an incremental logic check, run `python3 logic/replay.py --jobs 4 --check-manifest` in the pinned Lean/mathlib environment described in `logic/README.md`. The cache persists between runs, and `--clean` requests a full project rebuild. The timed unchanged replay reused all 179 modules in 2.12 seconds. A controlled source edit to the selector module recompiled that one module and reused the other 178 in 5.44 seconds. The first replay using the matching parent cache checked all eight new modules in two minutes.

The `logic/` directory contains the Lean proofs for equivalence of goal derivability between the two calculi, the counter used to select an axiom, the arithmetic of shifted cursor reads, growth of the cache marker, and the finite enumeration of the six prefix commands. The correspondence between the literal register code and the axiom extraction and synchronization arguments is given in the two written proofs in `search/`. The chart comparison for pure NF + AxCount uses the preceding full-chart construction and the v15 comparison results, Proposition 17.13 and Theorem 21.1. The written chart assumptions are recorded in `PriorCountingUpper.md`. [Earlier guarded machine and calibration](https://github.com/wlad-svennik/notes/tree/main/nf-axcount-bb187)

Table SHA-256: `d28dadaca7c74e79bec2f2b5f0fc2f2a08275439a2c1b8b64632d932d023eab2`.

## Independent audit

The published edition includes fresh matching proofs for every signed case and a separate comparison of all 4,764 warm branch statements with the literal table and source. The seven supplementary Lean modules cover the nine-row stack operations, global rank budget, actual Cantor cursor and the two predecessor epochs. See [the source audit and replay instructions](audit/Audit.md).
