"""Small named-term writer for Lean 4.35's public kernel export encoding.

It emits kernel terms only. The external reference kernel and nanoda decide
whether a term actually has its proposed type. The prelude contains exactly
Lean's ordinary inductive declarations for Eq and Nat, with their recursors.
"""
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
import sys

sys.setrecursionlimit(10000)
BASE = Path(__file__).with_name('eq_nat_prelude.ndjson')
BASE_HASH = 'e5d422d25746ba5eb85d2cde01df2e6701c577881be08934fa38a362d342b0ac'


class Term:
    """A Lean syntax node with a structurally correct, cached tuple hash."""
    __slots__ = ('parts', 'hash_value')

    def __init__(self, parts):
        self.parts = parts
        self.hash_value = hash(parts)

    def __hash__(self):
        return self.hash_value

    def __eq__(self, other):
        if self is other:
            return True
        if isinstance(other, Term):
            return self.hash_value == other.hash_value and self.parts == other.parts
        return self.parts == other

    def __getitem__(self, index):
        return self.parts[index]

@lru_cache(maxsize=80000)
def term(*parts):
    return Term(parts)


def V(name):
    return term('var', name)


def C(name, *universes):
    return term('const', name, universes)


def num(i):
    return term('num', i)


def ap(fn, *args):
    for arg in args:
        fn = term('app', fn, arg)
    return fn


def bind(tag, params, body):
    for name, typ in reversed(params):
        body = term(tag, name, typ, body)
    return body


def lam(params, body):
    return bind('lam', params, body)


def pi(params, body):
    return bind('forallE', params, body)


def arrow(*types):
    return pi([('_', t) for t in types[:-1]], types[-1])


class Export:
    """Serialize names, closed terms and declarations to an NDJSON file."""
    def __init__(self, target):
        self.f = target
        self.name_ids = {'': 0}
        self.names = {0: ''}
        self.exprs = {}
        self.next_name = 1
        self.next_expr = 0
        prelude = BASE.read_bytes()
        if sha256(prelude).hexdigest() != BASE_HASH:
            raise ValueError('Eq/Nat prelude digest')
        for line in prelude.splitlines():
            r = json.loads(line)
            self.f.write(line + b'\n')
            if 'in' in r:
                e = r.get('str') or r.get('num')
                part = str(e.get('str', e.get('i')))
                name = (self.names[e['pre']] + '.' if e['pre'] else '') + part
                self.names[r['in']] = name
                self.name_ids[name] = r['in']
                self.next_name = r['in'] + 1
            if 'ie' in r:
                i = r.pop('ie')
                self.exprs[self.key(r)] = i
                self.next_expr = i + 1

    @staticmethod
    def key(data):
        # The NF178 donor's canonical fast path. Only the two exact app-record
        # shapes enter here, yielding the same bytes as sorted compact JSON.
        app = data.get('app')
        if type(app) is dict and len(app) == 2:
            arg, fn = app.get('arg'), app.get('fn')
            if type(arg) is int and type(fn) is int:
                if len(data) == 1:
                    return '{"app":{"arg":%d,"fn":%d}}' % (arg, fn)
                index = data.get('ie')
                if len(data) == 2 and type(index) is int:
                    return '{"app":{"arg":%d,"fn":%d},"ie":%d}' % (arg, fn, index)
        return json.dumps(data, sort_keys=True, ensure_ascii=False, separators=(',', ':'))

    def row(self, data):
        self.f.write(self.key(data).encode() + b'\n')

    def name(self, name):
        if name not in self.name_ids:
            prefix, _, part = name.rpartition('.')
            parent = self.name(prefix)
            i = self.next_name
            self.next_name += 1
            self.row({'in': i, 'str': {'pre': parent, 'str': part}})
            self.name_ids[name] = i
        return self.name_ids[name]

    @lru_cache(None)
    def expr(self, t, ctx=()):
        tag = t[0]
        if tag == 'var':
            obj = {'bvar': ctx[::-1].index(t[1])}
        elif tag == 'sort':
            obj = {'sort': {0: 0, 1: 3, 'u': 2}[t[1]]}
        elif tag == 'const':
            obj = {'const': {'name': self.name(t[1]), 'us': [{0: 0, 1: 3, 'u': 2}[u] for u in t[2]]}}
        elif tag == 'num':
            obj = {'natVal': str(t[1])}
        elif tag == 'app':
            obj = {'app': {'fn': self.expr(t[1], ctx), 'arg': self.expr(t[2], ctx)}}
        elif tag in ('lam', 'forallE'):
            obj = {tag: {'binderInfo': 'default', 'type': self.expr(t[2], ctx),
                         'name': self.name(t[1]), 'body': self.expr(t[3], ctx + (t[1],))}}
        else:
            raise ValueError(tag)
        key = self.key(obj)
        if key not in self.exprs:
            i = self.next_expr
            self.next_expr += 1
            self.row({'ie': i, **obj})
            self.exprs[key] = i
        return self.exprs[key]

    def declare(self, name, params, typ, body, *, theorem=False):
        i = self.name(name)
        decl = {'all': [i], 'levelParams': [], 'name': i, 'type': self.expr(pi(params, typ)),
                'value': self.expr(lam(params, body))}
        if theorem:
            self.row({'thm': decl})
        else:
            self.row({'def': {**decl, 'hints': {'regular': 1}, 'safety': 'safe'}})
        self.expr.cache_clear()
        return C(name)
