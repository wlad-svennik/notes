from collections import deque
from hashlib import sha256
from pathlib import Path
import gzip,json,subprocess,sys
root=Path(__file__).resolve().parent
if not __debug__:
    raise RuntimeError('Run the verifier with Python assertions enabled.')
manifest=root/'SHA256SUMS'
if manifest.exists():
    for line in manifest.read_text().splitlines():
        expected,name=line.split('  ',1)
        assert sha256((root/name).read_bytes()).hexdigest()==expected,name
table=root/'candidate.tm'; lines=table.read_text().splitlines()
table_hash=sha256(table.read_bytes()).hexdigest();source_hash=sha256((root/'source.sites.json').read_bytes()).hexdigest()
assert table_hash=='d28dadaca7c74e79bec2f2b5f0fc2f2a08275439a2c1b8b64632d932d023eab2'
assert source_hash=='0fd0378211283f28bdd10a279aa8c96184be2f43ea20d16390222630f7cf1799'
assert lines[0]=='#! start k:74'
rows={}
for line in lines[1:]:
 q,r,w,d,t=line.split();assert r in '01' and w in '01' and d in ('L','R')and(q,r)not in rows
 rows[q,r]=(w,d,t)
states={q for q,b in rows}; assert len(states)==186 and len(rows)==372
assert all((q,b)in rows for q in states for b in '01')
assert [k for k,x in rows.items()if x[2]=='halt']==[('k:302','1')]
todo=deque(['k:74']); seen=set()
while todo:
 q=todo.pop()
 if q in seen or q=='halt':continue
 seen.add(q);todo.extend(rows[q,b][2]for b in '01')
assert seen==states
receipt=json.loads((root/'kernel.json').read_text());assert receipt['table']==table_hash and receipt['source']==source_hash and receipt['branch_theorems']==9526
traces=json.loads(gzip.decompress((root/'traces.gz').read_bytes()));assert len(traces['traces'])==9526 and len(traces['pumps'])==20
boot=json.loads((root/'bootstrap.json').read_text());z=boot['final']
assert boot['table_sha256']==table_hash and boot['source_sha256']==source_hash and z['step']==75311 and z['frame']['registers']==[3]+[0]*8
sys.path.insert(0,str(root/'boot'))
from discover import native
replay=native(table,root/'source.sites.json',80000,0)
assert replay==boot
assert receipt['trace_sha256']==sha256((root/'traces.gz').read_bytes()).hexdigest()
intervals=receipt['intervals']
assert intervals[0]['first_pc']==0 and intervals[-1]['past_last_pc']==3632
assert all(a['past_last_pc']==b['first_pc'] for a,b in zip(intervals,intervals[1:]))
assert sum(v['branches'] for v in intervals)==9526 and all('accepts the solution' in v['kernel'] for v in intervals)
subprocess.run([sys.executable,root/'check_binding.py',root],check=True)
subprocess.run([sys.executable,root/'audit/check_source.py',root,root/'Published187.sites.json'],check=True)
for file in ('check_source.py','marker_certificate.py','test_sync.py'):
    subprocess.run([sys.executable,root/'search'/file],check=True)
print('186 reachable working states, 372 transitions, 3,632 source instructions, 9,526 physical branch proofs')
print('Blank tape reaches instruction 0 with epoch counter 3 at step 75,311.')
if '--kernel' in sys.argv:
 subprocess.run(['bash',root/'boot/compile.sh'],check=True)
 import tempfile
 with tempfile.TemporaryDirectory() as d:
  dst=Path(d)
  subprocess.run([sys.executable,root/'physical/symbolic_frames.py',root,'--write',dst/'traces.gz'],check=True)
  subprocess.run([sys.executable,root/'physical/check_all.py',root,dst/'traces.gz',dst/'receipt.json','--jobs','3','--chunk','128'],check=True)
