# A single guarded readback law for the native NF180 letter

Use the full FunctionNF chart construction from a model of pure NF with Rosser's AxCount, with its represented homogeneous row labelling, disjoint full label slices, and strongly Cantorian internal naturals. These are the full-chart and completion hypotheses of the previous J-point calibration. The following variant does not constrain the rows of all images of the primitive J. Its additional law is

    b has a nonconstant row  ⇒  (J(Jb))J = Jb.

A row is nonconstant when its values differ at two arguments. The original eight NF180 schemas retain their literal vocabulary and the abstraction head remains B=JJ.

## A represented reader

Reserve distinct labels a_n for all internal naturals n, indexed homogeneously in a spare slice. Write q=a_0, u=a_1 and v=a_2. Choose a spare value e outside this entire slice. At a_{n+1} put the two-valued row with value a_n everywhere except at the sentinel a_1, where it has value e. Give q a provisional two-valued row, distinct from these. This can be done by giving it a different exceptional argument and a different default. Strong Cantorianity of the natural-number index allows these prescriptions at the displayed relative types.

Reserve a homogeneous injective family of labels P(t) for all objects t in another full slice. Give each P(t) a distinct row of finite range containing three fixed values. A concrete choice uses a further homogeneous full slice Z(s). On Z(s), return marker m_0 or m_1 according as s belongs to t or does not. At three fixed arguments outside this slice return m_0,m_1,m_2 respectively, and use m_0 elsewhere. The three-valued rows are distinct by extensionality of pure NF, nonconstant, and distinct from all prescribed two-valued rows. Infinitely many fresh labels and a full homogeneous family of unused rows remain, for instance by tagging two new membership-test output markers together with distinct fixed sentinels. The usual full-chart Cantor–Bernstein completion gives a labelling E.

In this labelling the following homogeneous function is represented as a row with some label h:

    U(z) = { t | E(z)(P(t)) = u }.

Indeed, the type of z is one above the type of t, so this comprehension has the type of z. It is surjective. For any object w take a represented row returning u on P(t) for t∈w, and v on the other P(t), with an arbitrary default elsewhere. Its label z realizes U(z)=w. In particular h is distinct from q, the positive chain labels, and the P(t), all of which have finite-range rows.

Swap the rows labelled by h and q. Write application in the resulting chart by juxtaposition. The P(t) and the positive chain rows have not moved. The new row of q is surjective. The new row of h is the provisional two-valued row. Whenever z differs from h and q, the reader still satisfies

    qz = { t | z(P(t)) = u }.

## The native letter

Let K and B be the native constant and abstraction operations of the resulting full chart. Thus (Kx)y=x and (Bf)yz=(f(Kz))(yz). The row of B fixes K²x for every x, so has infinite range. Consequently B differs from every chain label of positive index, each P(t), and h. It also differs from q. For every x, K²x is an unchanged constant row (both relabelled rows were nonconstant). The reader q(K²x) is either the empty or the universal set, whereas B(K²x)=K²x takes infinitely many distinct values.

Choose a represented homogeneous fixed-point-free map μ on values, for instance mapping a fixed value r to s≠r and every other value to r. Let g_x be the unique label whose row has value x at all arguments other than x, and value μ(x) at x. The map Kx↦g_x is represented homogeneously. The labels g_x are distinct by evaluating two of their rows away from both exceptions.

Define J to be the label of the following represented row.

| Argument | Value |
| --- | --- |
| Kx | g_x |
| B | q |
| a_n for internal n≥0 | a_{n+1} |
| P(t) | u when t∈B and v otherwise |
| every other argument | B |

The cases have disjoint domains. The chain and probes are nonconstant, B has infinite range, and B differs from q. The branch on B and the default are homogeneous. For stratified comprehension use separate parameters B₀ and B₁, instantiated by the same object B after comprehension. B₀ occurs in the test on the argument and B₁ in the membership test one type above t. The shift on the strongly Cantorian chain supplies the term at the required type independently of the membership parameter.

J has infinite range through the g_x. It has a proper range: choose a row with exactly four distinct values. Its label cannot be a g_x, a positive chain label, B or q. These exhaust the possible outputs of J. Hence J differs from the surjective reader q, every finite-range reserved label, and h. Moreover J≠B: B fixes K²x, whereas J(K²x)=g_{Kx} is nonconstant. J itself is nonconstant, so the default clause applies to it, giving JJ=B. The constant-input clause gives exactly the old compact data laws J(Ka)b=a for b≠a and J(Ka)a≠a.

The reader equation at z=J now gives qJ=B. If b is nonconstant, Jb is B or some a_n. If Jb=B then (J(Jb))J=qJ=B. If Jb=a_n then (J(Jb))J is the value of a_{n+1} at J, namely a_n because J differs from the sentinel a_1. This proves the guarded readback law for all internal arguments. The chart supplies H on the diagonal as K and uses the usual extensional separating argument off the diagonal. No distinguished off-diagonal H slot occurs in this presentation.

## Lower interpretation and machine

The Lean modules ConditionalAlgebra.lean and ConditionalModel.lean prove that the guarded law on a native marked chart supplies a model of NFU with Dedekind Infinity and full AxCount. The represented strongly Cantorian proper-injection domain is the intersection of the nonconstant rows with J's image of the nonconstant rows. As in the J-point calibration, conversion of NFU consistency to consistency of pure NF with AxCount uses the written Gutin v15 comparisons. The upper argument above is mathematical; it has not been formalized in Lean. The native 187-state matrix implements the implication-only guarded axiom whose equality and implication constructor codes are checked in ConditionalEmitter.lean.
