"""Exhaust the shifted parses of the six-command marker for the pure NF census register machine.

This finite certificate uses only integer comparisons on small numbers. See
MarkerProof.md for the concretization of its two abstract cache bounds.
"""
from typing import NamedTuple


PREFIX = ((0, 1), (1, 0), (0, 1), (1, 0), (0, 2), (2, 1, 3))
SMALL_TAG_LIMIT = 22
UNKNOWN, MARKER, HUGE = 'unknown', 'marker', 'huge'


class State(NamedTuple):
    bias: int
    role: str
    count: int = 0
    cache: str = UNKNOWN
    residue: int = 0


def successors(s, digit, target_end, allow_residue):
    """Empty list certifies exhaustion of the previous epoch at this field."""
    e, phase, count, h, rem = s
    value = digit - e
    if value < 0:
        assert value == -1, ('uncovered carry across Cantor diagonal', s, digit)
        # Actual right tail is zero. The command finishes on zero-filled fields.
        if phase == 'tag':
            # The escaped field can be a very large tag. Its AX must finish.
            assert h == HUGE
        elif phase == 'tagR' or phase == 'drainImmediate' or phase == 'drainFields':
            assert h == HUGE
        elif phase == 'firstFields':
            # The fresh huge marker covers every remaining batch.
            assert allow_residue
        elif phase == 'fields':
            assert allow_residue or rem == 0
        elif phase == 'immediate':
            assert count <= SMALL_TAG_LIMIT
            assert allow_residue or count <= 2 or h != UNKNOWN
        else:
            raise AssertionError(phase)
        return []

    def next_field(role, c=0, cache=h, residue=0):
        return State(e + target_end, role, c, cache, residue)

    def end_command(residue=0, cache=UNKNOWN):
        return State(e + target_end - 1, 'tag', residue, cache)

    if phase in ('firstFields', 'drainFields'):
        # Both cover an arbitrary positive number of payload fields. The first
        # forced AX may have hit the CD5 exit; a dominating-cache AX cannot.
        steps = [next_field(phase), end_command(0, HUGE)]
        if phase == 'firstFields':
            steps.append(State(e + target_end - 1, 'tagR', 0, HUGE))
        return steps
    if phase == 'tagR':
        # Actual carry is positive but unbounded. Sum=1 only if value=0.
        steps = [next_field('drainImmediate')]
        if value == 0:
            steps.append(next_field('immediate', 1))
        return steps
    if phase == 'drainImmediate':
        return [next_field('drainFields')]
    if phase == 'tag':
        return [next_field('immediate', count + value)]
    if phase == 'immediate':
        if count <= 1:
            return [end_command()]
        assert count <= SMALL_TAG_LIMIT
        if h in (HUGE, MARKER):
            return [next_field('fields', count - 1)]
        return [next_field('fields', k, UNKNOWN, count - 1 - k)
                for k in range(1, count)]
    if phase == 'fields':
        if count > 1:
            return [next_field('fields', count - 1, h, rem)]
        return [end_command(rem, HUGE if h == HUGE else MARKER)]
    raise AssertionError(phase)


def prove(j):
    assert j in (1, 2)
    # When the forced tag acts as MP or MODE its two fields are complete.
    # Otherwise its next field is its first AX delta.
    states = {State(-j, 'tag'), State(1-j, 'firstFields' if j == 2 else 'drainFields', 0, HUGE)}
    report = []
    largest_bias = 0
    for command in PREFIX:
        exits = aligned = 0
        for position, digit in enumerate(command, 1):
            end = position == len(command)
            following = set()
            for s in states:
                largest_bias = max(largest_bias, abs(s.bias))
                new = successors(s, digit, end, j == 2)
                exits += not new
                following.update(new)
            states = following
        next_states = set()
        for s in states:
            if s.role == 'tag' and s.bias == 0 and s.count == 0:
                aligned += 1
            else:
                next_states.add(s)
        states = next_states
        report.append((len(states), aligned, exits))
    assert not states, ('uncovered paths', j, states)
    assert largest_bias < 32
    return report, largest_bias


if __name__ == '__main__':
    for j in (2, 1):
        result, bias = prove(j)
        print('predecessor', j, '(pending, aligned, exhausted) by command:', result,
              'maximum absolute bias:', bias)
