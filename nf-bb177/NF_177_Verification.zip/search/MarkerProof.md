# Reaching a prescribed proof word in the 177-state pure NF machine

This is a standard-natural-number argument for the pure NF census register source used in `NF_177.tm`. The theorem `NF180Counting.CensusMarker.two_predecessors` in `logic/src/MarkerReplay.lean` applies the finite case analysis to numerical Cantor cursors. The theorem uses the batch counts, effective-rank bound, and marker estimate below. The finite case analysis is executable in `marker_certificate.py` and in the kernel-checked `search/MarkerEnumeration.lean`. Its only inputs are the thirteen fields printed below. `test_sync.py` independently checks examples on integer cursors. The initial rank and cache may be arbitrary natural numbers.

## Register semantics and the required word

Write `r` for R3, `h` for R5 and `P(x,y)=(x+y)(x+y+1)/2+y` for Cantor pairing. At a command boundary, reading tag `s` adds it to `r`. The immediate `u` is the next field. A total tag `t=r+s` of 0 or 1 executes MP or MODE and leaves rank zero. For this lemma their payload and outgoing cache can be arbitrary. For `t≥2`, put `q=t−2`. AX reads `k=min(q,h)+1` further fields, one per emitted batch. It leaves rank `q+1−k` and puts the penultimate row of the last batch into cache. This row is `M(b,a)=testRow b a`, where `b=h+1−k` and `a` is at least `u`. In particular, a successful AX starting with `h≥q` ends with zero rank and last-row parameter `b=h−q`. A command finishes by subtracting 1 from its remaining cursor when positive. Remaining cursor zero ends the epoch. Batch reads on cursor zero supply zero indefinitely.

Suppose a proposed inconsistency has a **fixed finite proof command word** that produces a halt from any sound proof payload at rank zero. Let `W` be its raw encoding, with an arbitrary fixed large tail after its last inspected field. The proof-word construction must guarantee its required raw batch-field counts in all such starting payloads. One can append the tail by setting the final command's encoded continuation to `T+1` for any `T≥100`. Only the finitely many commands through the goal observation matter. Every right tail of the six-command prefix is consequently at least 100.

## The three epochs

Prepend these fields to `W`. Parentheses mark commands.

```
(0,1) (1,0) (0,1) (1,0) (0,2) (2,1,3)
```

Let `z` be the raw integer for this prefixed word. At each command end insert the usual `+1` on its continuation before pairing the fields of that command. Here an epoch is labelled by the incoming R0 at refill. At PC 0 with R8 zero and R0 equal to m, the refill stores m in the cursor register and increments R0 to m+1. Take `n=P(K,z+1)` with `K` sufficiently large. The initial forced command at epoch `n−j`, for `j=0,1,2`, has tag zero, immediate `K+j` and remaining cursor `z+1−j`. This follows from `n−j=P(K+j,z+1−j)` and the fresh-epoch input `P(0,n−j)`. If the preceding epoch ever halts, the desired conclusion holds already. Otherwise every epoch is reached, since each nonfinal command decreases its unread cursor and each command finishes after finitely many batches.

**Goal of the three-epoch argument.** At `n−2`, from any initial rank/cache, either the parser aligns to the proof word or its outgoing `h` covers its outgoing `r`. At `n−1`, from `h≥r`, either it aligns or its outgoing rank is zero. At `n` the forced tag and the six prescribed commands then preserve zero rank. The parser reaches `W`. Alignment in either predecessor is equally good, since after alignment every remaining prefix command preserves zero rank from arbitrary cache. In particular its sole tag-2 command always reads exactly one trailing batch field.

## Two cache bounds

For all epochs through `n`, the total of all raw tags in epoch `m` is at most `m`. The first tag is zero and the subsequent selectors are read from nested right tails of `m`. The inequality `P(x,y)≥x+y`, applied each time a field is removed, bounds their sum. A command never increases rank above its previous rank plus its tag. Beginning from a fixed starting rank `r₀`, each effective `r+s` through epoch `n` is therefore less than `D=r₀+(n+2)²+1`. This bound also covers a large tag exposed by crossing a pairing diagonal.

The elementary lower bounds on double Cantor pairing give `M(b,a)≥a¹⁶` and `M(b,a)≥b`. The first follows by successively squaring through `single b a`, `eqn (single b a) b`, the inner implication, and the outer implication. Monotonicity gives `M(b,a)≥M(0,0)=1614700370257423492`. With `z` fixed, `n=P(K,z+1)` grows quadratically in `K`, so choose `K` above the starting epoch and large enough that `K¹⁶>100D`. The theorem `GlobalBudget.choose_epoch` supplies the explicit witness `K=z+r₀+first+10000`, where `first` is the starting epoch. A tag-zero forced AX stores a marker above `100D` even on early exit, since `a≥K`. In fact `M(b,a)≥2b` because its consequent is `eqn a b=2P(a,b)+1`. Thus for `h≥2D` and `q≤D` a complete AX yields `M(h−q,a)≥2(h−q)≥h`. This proves the fixed threshold `2D` used for a `huge` cache throughout the certificate. A `marker` cache only asserts the general lower bound `M(0,0)>22`. An `unknown` cache ranges over all natural numbers. An MP or MODE step always forgets the previous cache bound.

## Exhausting the shifted parses

Suppose the next prescribed raw field is `x`, followed by right tail `B`. Write the actual unread cursor as `P(x,B)+e`. While `x−e≥0`, the actual field and tail are exactly `x−e,B+e`. This follows by staying on the same Cantor diagonal. The smallest `B` exceeds the largest absolute bias, which the checker computes as 2. Add one to `e` at a prescribed command end, and subtract one at an actual command end. If `e=x+1`, then `P(x,B)+e=P(x+B+1,0)`. Thus the actual field is `x+B+1` and all remaining actual fields, including any still due to the current batch loop, are zero. There can be no further actual command in this epoch. The checker rejects any branch that crosses the diagonal by more than one.

The following phase descriptions specify the actual configurations represented at the next field. Numeric rank/count fields in the code have the stated meaning only in their phase.

| Phase | Concrete meaning |
| --- | --- |
| `tag` | At the next actual tag with the stored exact carry and cache bound. |
| `immediate` | About to read the immediate of an actual command with the stored total tag and cache bound. |
| `fields` | With at least one AX field left, the number of fields left and the rank on eventual exit are both exact. |
| `firstFields` | In the forced AX at `n−2`, with at least one field remaining. It will produce a huge cache. The outgoing rank can be zero or positive. |
| `tagR` | At the next tag with positive, otherwise unbounded rank and huge cache. |
| `drainImmediate` | About to read the immediate of an AX known to finish all batches using its huge cache. |
| `drainFields` | At least one field remains in an AX known to exit at rank zero with a huge cache. Includes the forced AX at `n−1` when its incoming `h≥r`. |

For the initial ordinary command, the first prefix field starts in `tag` at bias `−j`, with rank zero and unknown cache. For an initial AX the first prefix field starts at bias `1−j`. Its payload has not yet undergone the command-end subtraction. That creates exactly the two starting phases for each predecessor. At each field, `successors` allows *every* concrete next phase. In particular, it allows either continuation or completion after each field of an unbounded AX. Where the incoming cache is unknown and the total tag `t≥2` is exact, it enumerates `k=1,…,t−1`, with residual `t−1−k`. All such exact tags are checked against 22. A `tagR` can give one ordinary MODE precisely when the actual field is zero and the carried rank is one. Every other case there is covered by the large-cache draining AX.

On a diagonal crossing, `successors` checks that a tag about to be read has a huge enough cache for its newly exposed large value. In the other phases it checks the already-known total tag, remaining rank or forced-marker condition. In the first predecessor finite pending AX rank is below the marker lower bound, so its ending cache covers its residue. In the second predecessor the checker requires rank zero after finishing fields on the exhausted tail. Ordinary commands leave rank zero in either predecessor. In particular, crossing the diagonal **at an immediate or batch field** does not execute the escaped large value as a selector.

At the end of a prescribed command the checker accepts any `tag` state at exact carry zero and bias zero. Both parsers have then reached the same next raw command with rank zero. This is the alignment conclusion in the three-epoch argument. All other states continue through the case analysis.

| Predecessor | Pending states after the six successive commands | Largest absolute bias |
| --- | --- | --- |
| `n−2` | 6, 8, 5, 3, 1, 0 | 2 |
| `n−1` | 3, 2, 1, 0, 0, 0 | 1 |

No state survives the six commands without either exhaustion under its prescribed postcondition or alignment. To reproduce the exhaustive computation, run `python3 marker_certificate.py`. For independent bounded checks using integer Cantor unpair rather than bias transitions, run `python3 test_sync.py`.
