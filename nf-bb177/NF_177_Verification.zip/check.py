"""Check the 177-state NF release, or rebuild its Lean physical certificates."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
TABLE = ROOT / 'candidate.tm'
SOURCE = ROOT / 'source.sites.json'
TABLE_SHA = 'a4968d492f38586a33882f80869a2f1a8e0628eeb6b3284fdfc02a22ec8a59df'
SOURCE_SHA = '76afdc3a7d4f37fbf056a7f84c84930fdd7c31a9d02e65ecfaddbd26510db54b'

def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

def read_rows(path):
    header, *lines = path.read_text().splitlines()
    assert header == '#! start k:74'
    rows = {}
    for line in lines:
        q, b, w, direction, target = line.split()
        assert b in ('0','1') and w in ('0','1') and direction in ('L','R')
        assert (q,b) not in rows
        rows[q,b] = w,direction,target
    return rows

def check_graph(rows):
    states = {q for q,b in rows}
    assert len(states)==177 and len(rows)==354
    assert {key for key,edge in rows.items() if edge[2]=='halt'} == {('k:302','1')}
    todo, seen = ['k:74'], set()
    while todo:
        q = todo.pop()
        if q=='halt' or q in seen: continue
        seen.add(q)
        todo.extend(rows[q,b][2] for b in '01')
    assert seen==states

def check_merge():
    old, new = 'aux:new:1','rg-fresh:841041b200ff'
    parent = read_rows(ROOT/'Intermediate178.tm')
    expected = {(q,b):(w,d,new if dest==old else dest)
                for (q,b),(w,d,dest) in parent.items() if q!=old}
    expected[new,'0'] = '0','R','a:CD:5'
    expected[new,'1'] = '0','L','k:10'
    rows=read_rows(TABLE)
    assert rows==expected
    check_graph(rows)

def check_receipt():
    program=json.loads(SOURCE.read_bytes())
    assert len(program)==2960
    trace=json.loads(gzip.decompress((ROOT/'traces.gz').read_bytes()))
    expected={(i,cold,zero) for i,(_,op,reg) in enumerate(program)
              for cold in (False,True) if not(cold and op=='CD' and reg==0)
              for zero in ((False,True) if op=='CD' else (False,))}
    actual=[(r['pc'],r['cold'],r['zero']) for r in trace['traces']]
    assert set(actual)==expected and len(actual)==len(expected)==7766
    assert len(trace['pumps'])==20 and trace['table']==TABLE_SHA and trace['source']==SOURCE_SHA
    receipt=json.loads((ROOT/'kernel.json').read_bytes())
    assert receipt['table']==TABLE_SHA and receipt['source']==SOURCE_SHA
    assert receipt['trace_sha256']==sha(ROOT/'traces.gz') and receipt['branch_theorems']==7766
    pos=0
    for item in receipt['intervals']:
        assert pos==item['first_pc'] < item['past_last_pc'] <= len(program)
        assert item['branches']==sum(pos<=i<item['past_last_pc'] for i,cold,zero in expected)
        assert 'kernel accepts the solution' in item['kernel']
        pos=item['past_last_pc']
    assert pos==len(program)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--kernel',action='store_true')
    ap.add_argument('--jobs',type=int,default=3)
    args=ap.parse_args()
    if not __debug__ or args.jobs < 1: raise ValueError('Enable Python assertions and use a positive job count.')
    for entry in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest,name=entry.split('  ',1)
        assert sha(ROOT/name)==digest,name
    assert sha(TABLE)==TABLE_SHA and sha(SOURCE)==SOURCE_SHA
    check_merge()
    check_receipt()
    sys.path.insert(0,str(ROOT/'boot'))
    from discover import native
    anchor = native(TABLE,SOURCE,80000,0)
    assert anchor==json.loads((ROOT/'bootstrap.json').read_bytes())
    last = anchor['final']
    assert last['step']==74071 and last['frame']['registers']==[3]+[0]*8
    subprocess.run([sys.executable,ROOT/'check_source.py',ROOT/'Original178.sites.json',SOURCE,TABLE],check=True)
    for script in ('check_binding.py','search/marker_certificate.py','search/test_sync.py'):
        subprocess.run([sys.executable,ROOT/script],cwd=ROOT,check=True)
    print('177 working states, 354 transitions, 2,960 register instructions, 7,766 certified physical cases.')
    print('Blank tape reaches register instruction 0 with counter 3 and eight zeros at step 74,071.')
    if args.kernel:
        subprocess.run(['bash',ROOT/'boot/compile.sh'],check=True)
        with tempfile.TemporaryDirectory() as folder:
            traces = Path(folder)/'traces.gz'
            receipt = Path(folder)/'receipt.json'
            subprocess.run([sys.executable,ROOT/'physical/symbolic_frames.py',ROOT,'--write',traces],check=True)
            subprocess.run([sys.executable,ROOT/'physical/check_all.py',ROOT,traces,receipt,'--jobs',str(args.jobs),'--chunk','128'],check=True)

if __name__=='__main__':
    main()
