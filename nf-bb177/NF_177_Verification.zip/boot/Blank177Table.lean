import NF210.MachineSemantics
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank177.Table
open NF210.TM
abbrev State := Fin 177
def start : State := 140
def names : Array String := #["a:CD:5", "a:CD:6", "a:CD:7", "a:CI:0", "a:CI:1", "a:CI:2", "a:CI:3", "a:CI:4", "a:CI:5", "a:CI:6", "a:CI:7", "a:CI:8", "d:0", "d:101", "d:102", "d:104", "d:105", "d:109", "d:118", "d:12", "d:13", "d:130", "d:134", "d:14", "d:142", "d:143", "d:144", "d:145", "d:146", "d:147", "d:148", "d:149", "d:15", "d:150", "d:151", "d:152", "d:153", "d:154", "d:155", "d:157", "d:158", "d:159", "d:16", "d:160", "d:161", "d:163", "d:164", "d:165", "d:17", "d:18", "d:19", "d:20", "d:22", "d:23", "d:24", "d:25", "d:26", "d:28", "d:29", "d:31", "d:32", "d:39", "d:40", "d:43", "d:44", "d:45", "d:46", "d:47", "d:49", "d:50", "d:51", "d:52", "d:53", "d:54", "d:55", "d:56", "d:57", "d:59", "d:60", "d:61", "d:62", "d:63", "d:64", "d:65", "d:67", "d:68", "d:69", "d:70", "d:71", "d:73", "d:74", "d:75", "d:76", "d:77", "d:78", "d:79", "d:8", "d:80", "d:83", "d:85", "d:87", "d:97", "d:98", "d:99", "fresh:4", "fresh:5", "fresh:6", "g:013460a16426", "g:2d599279071e", "g:dbe067bd3065", "k16share:0", "k16share:1", "k:0", "k:10", "k:113", "k:15", "k:198", "k:2", "k:22", "k:23", "k:24", "k:25", "k:3", "k:302", "k:32", "k:33", "k:35", "k:36", "k:4", "k:40", "k:48", "k:49", "k:5", "k:51", "k:54", "k:55", "k:6", "k:60", "k:64", "k:66", "k:74", "k:75", "k:9", "k:94", "k:97", "n:0", "n:10", "n:11", "n:12", "n:8", "n:9", "new:1", "purenew:0", "purenew:1", "purenew:10", "purenew:11", "purenew:12", "purenew:13", "purenew:14", "purenew:15", "purenew:16", "purenew:17", "purenew:18", "purenew:19", "purenew:2", "purenew:3", "purenew:4", "purenew:5", "purenew:6", "purenew:7", "purenew:8", "purenew:9", "rg-fresh:17f3b04d308d", "rg-fresh:61facaad8d63", "rg-fresh:841041b200ff", "rootinside", "rootleft"]
def name (q : State) := names[q.val]?.getD ""
def pair (q : State) : Instruction 177 × Instruction 177 :=
  if q.val < 88 then
    if q.val < 44 then
      if q.val < 22 then
        if q.val < 11 then
          if q.val < 5 then
            if q.val < 2 then
              if q.val < 1 then
                (⟨false, .right, some (120:State)⟩,⟨false, .right, some (135:State)⟩)
              else
                (⟨false, .left, some (49:State)⟩,⟨true, .left, some (79:State)⟩)
            else
              if q.val < 3 then
                (⟨false, .right, some (120:State)⟩,⟨false, .right, some (125:State)⟩)
              else
                if q.val < 4 then
                  (⟨false, .left, some (86:State)⟩,⟨false, .left, some (137:State)⟩)
                else
                  (⟨false, .right, some (131:State)⟩,⟨false, .right, some (121:State)⟩)
          else
            if q.val < 8 then
              if q.val < 6 then
                (⟨false, .left, some (62:State)⟩,⟨false, .right, some (133:State)⟩)
              else
                if q.val < 7 then
                  (⟨false, .left, some (86:State)⟩,⟨false, .right, some (124:State)⟩)
                else
                  (⟨false, .left, some (62:State)⟩,⟨false, .right, some (130:State)⟩)
            else
              if q.val < 9 then
                (⟨false, .left, some (79:State)⟩,⟨true, .left, some (83:State)⟩)
              else
                if q.val < 10 then
                  (⟨false, .right, some (131:State)⟩,⟨false, .right, some (137:State)⟩)
                else
                  (⟨false, .left, some (79:State)⟩,⟨true, .left, some (49:State)⟩)
        else
          if q.val < 16 then
            if q.val < 13 then
              if q.val < 12 then
                (⟨false, .left, some (86:State)⟩,⟨false, .right, some (127:State)⟩)
              else
                (⟨false, .right, some (176:State)⟩,⟨true, .right, some (175:State)⟩)
            else
              if q.val < 14 then
                (⟨false, .left, some (146:State)⟩,⟨true, .right, some (15:State)⟩)
              else
                if q.val < 15 then
                  (⟨false, .right, some (81:State)⟩,⟨true, .right, some (102:State)⟩)
                else
                  (⟨false, .right, some (99:State)⟩,⟨true, .right, some (103:State)⟩)
          else
            if q.val < 19 then
              if q.val < 17 then
                (⟨false, .left, some (99:State)⟩,⟨true, .left, some (17:State)⟩)
              else
                if q.val < 18 then
                  (⟨false, .right, some (14:State)⟩,⟨true, .right, some (99:State)⟩)
                else
                  (⟨false, .right, some (95:State)⟩,⟨true, .right, some (100:State)⟩)
            else
              if q.val < 20 then
                (⟨false, .right, some (20:State)⟩,⟨true, .right, some (51:State)⟩)
              else
                if q.val < 21 then
                  (⟨false, .right, some (11:State)⟩,⟨true, .right, some (23:State)⟩)
                else
                  (⟨false, .right, some (4:State)⟩,⟨true, .right, some (100:State)⟩)
      else
        if q.val < 33 then
          if q.val < 27 then
            if q.val < 24 then
              if q.val < 23 then
                (⟨false, .right, some (99:State)⟩,⟨true, .right, some (17:State)⟩)
              else
                (⟨false, .right, some (32:State)⟩,⟨false, .left, some (110:State)⟩)
            else
              if q.val < 25 then
                (⟨false, .right, some (99:State)⟩,⟨true, .right, some (21:State)⟩)
              else
                if q.val < 26 then
                  (⟨false, .right, some (26:State)⟩,⟨true, .right, some (27:State)⟩)
                else
                  (⟨false, .left, some (101:State)⟩,⟨true, .right, some (24:State)⟩)
          else
            if q.val < 30 then
              if q.val < 28 then
                (⟨false, .left, some (15:State)⟩,⟨true, .right, some (90:State)⟩)
              else
                if q.val < 29 then
                  (⟨false, .right, some (29:State)⟩,⟨true, .right, some (30:State)⟩)
                else
                  (⟨false, .right, some (7:State)⟩,⟨false, .left, some (111:State)⟩)
            else
              if q.val < 31 then
                (⟨false, .right, some (0:State)⟩,⟨false, .left, some (117:State)⟩)
              else
                if q.val < 32 then
                  (⟨false, .right, some (33:State)⟩,⟨true, .right, some (34:State)⟩)
                else
                  (⟨false, .right, some (10:State)⟩,⟨true, .right, some (42:State)⟩)
        else
          if q.val < 38 then
            if q.val < 35 then
              if q.val < 34 then
                (⟨false, .right, some (7:State)⟩,⟨true, .right, some (95:State)⟩)
              else
                (⟨false, .right, some (35:State)⟩,⟨true, .right, some (98:State)⟩)
            else
              if q.val < 36 then
                (⟨false, .right, some (36:State)⟩,⟨true, .right, some (30:State)⟩)
              else
                if q.val < 37 then
                  (⟨false, .right, some (0:State)⟩,⟨true, .right, some (37:State)⟩)
                else
                  (⟨false, .right, some (0:State)⟩,⟨true, .right, some (38:State)⟩)
          else
            if q.val < 41 then
              if q.val < 39 then
                (⟨false, .left, some (28:State)⟩,⟨true, .right, some (0:State)⟩)
              else
                if q.val < 40 then
                  (⟨false, .right, some (90:State)⟩,⟨true, .right, some (40:State)⟩)
                else
                  (⟨false, .right, some (41:State)⟩,⟨true, .right, some (46:State)⟩)
            else
              if q.val < 42 then
                (⟨false, .right, some (65:State)⟩,⟨true, .right, some (43:State)⟩)
              else
                if q.val < 43 then
                  (⟨false, .right, some (48:State)⟩,⟨true, .right, some (49:State)⟩)
                else
                  (⟨false, .right, some (1:State)⟩,⟨true, .right, some (44:State)⟩)
    else
      if q.val < 66 then
        if q.val < 55 then
          if q.val < 49 then
            if q.val < 46 then
              if q.val < 45 then
                (⟨false, .right, some (174:State)⟩,⟨true, .right, some (45:State)⟩)
              else
                (⟨false, .right, some (8:State)⟩,⟨true, .right, some (61:State)⟩)
            else
              if q.val < 47 then
                (⟨false, .right, some (47:State)⟩,⟨true, .right, some (28:State)⟩)
              else
                if q.val < 48 then
                  (⟨false, .right, some (62:State)⟩,⟨true, .right, some (82:State)⟩)
                else
                  (⟨false, .right, some (1:State)⟩,⟨false, .left, some (151:State)⟩)
          else
            if q.val < 52 then
              if q.val < 50 then
                (⟨false, .right, some (2:State)⟩,⟨true, .right, some (50:State)⟩)
              else
                if q.val < 51 then
                  (⟨false, .right, some (9:State)⟩,⟨false, .left, some (110:State)⟩)
                else
                  (⟨false, .right, some (2:State)⟩,⟨true, .right, some (96:State)⟩)
            else
              if q.val < 53 then
                (⟨false, .right, some (53:State)⟩,⟨true, .right, some (55:State)⟩)
              else
                if q.val < 54 then
                  (⟨false, .right, some (1:State)⟩,⟨true, .right, some (54:State)⟩)
                else
                  (⟨false, .right, some (6:State)⟩,⟨false, .left, some (111:State)⟩)
        else
          if q.val < 60 then
            if q.val < 57 then
              if q.val < 56 then
                (⟨false, .right, some (19:State)⟩,⟨true, .right, some (56:State)⟩)
              else
                (⟨false, .right, some (1:State)⟩,⟨true, .right, some (29:State)⟩)
            else
              if q.val < 58 then
                (⟨false, .right, some (58:State)⟩,⟨true, .right, some (31:State)⟩)
              else
                if q.val < 59 then
                  (⟨false, .right, some (6:State)⟩,⟨true, .right, some (59:State)⟩)
                else
                  (⟨false, .right, some (60:State)⟩,⟨true, .right, some (39:State)⟩)
          else
            if q.val < 63 then
              if q.val < 61 then
                (⟨false, .right, some (6:State)⟩,⟨true, .right, some (173:State)⟩)
              else
                if q.val < 62 then
                  (⟨false, .right, some (1:State)⟩,⟨true, .right, some (62:State)⟩)
                else
                  (⟨false, .left, some (44:State)⟩,⟨false, .left, some (151:State)⟩)
            else
              if q.val < 64 then
                (⟨false, .right, some (64:State)⟩,⟨true, .right, some (77:State)⟩)
              else
                if q.val < 65 then
                  (⟨false, .right, some (65:State)⟩,⟨true, .right, some (66:State)⟩)
                else
                  (⟨false, .right, some (3:State)⟩,⟨true, .right, some (50:State)⟩)
      else
        if q.val < 77 then
          if q.val < 71 then
            if q.val < 68 then
              if q.val < 67 then
                (⟨false, .right, some (67:State)⟩,⟨true, .right, some (68:State)⟩)
              else
                (⟨false, .right, some (5:State)⟩,⟨true, .right, some (10:State)⟩)
            else
              if q.val < 69 then
                (⟨false, .right, some (69:State)⟩,⟨true, .right, some (76:State)⟩)
              else
                if q.val < 70 then
                  (⟨false, .right, some (70:State)⟩,⟨true, .right, some (72:State)⟩)
                else
                  (⟨false, .right, some (3:State)⟩,⟨true, .right, some (71:State)⟩)
          else
            if q.val < 74 then
              if q.val < 72 then
                (⟨false, .right, some (10:State)⟩,⟨true, .right, some (1:State)⟩)
              else
                if q.val < 73 then
                  (⟨false, .right, some (1:State)⟩,⟨true, .right, some (73:State)⟩)
                else
                  (⟨false, .right, some (74:State)⟩,⟨false, .left, some (50:State)⟩)
            else
              if q.val < 75 then
                (⟨false, .right, some (10:State)⟩,⟨true, .right, some (75:State)⟩)
              else
                if q.val < 76 then
                  (⟨false, .left, some (55:State)⟩,⟨true, .right, some (10:State)⟩)
                else
                  (⟨false, .right, some (2:State)⟩,⟨true, .right, some (86:State)⟩)
        else
          if q.val < 82 then
            if q.val < 79 then
              if q.val < 78 then
                (⟨false, .right, some (78:State)⟩,⟨true, .right, some (53:State)⟩)
              else
                (⟨false, .right, some (6:State)⟩,⟨true, .right, some (79:State)⟩)
            else
              if q.val < 80 then
                (⟨false, .right, some (9:State)⟩,⟨true, .right, some (80:State)⟩)
              else
                if q.val < 81 then
                  (⟨false, .right, some (4:State)⟩,⟨false, .left, some (136:State)⟩)
                else
                  (⟨false, .right, some (64:State)⟩,⟨true, .right, some (82:State)⟩)
          else
            if q.val < 85 then
              if q.val < 83 then
                (⟨false, .right, some (83:State)⟩,⟨true, .right, some (56:State)⟩)
              else
                if q.val < 84 then
                  (⟨false, .left, some (28:State)⟩,⟨true, .right, some (79:State)⟩)
                else
                  (⟨false, .right, some (85:State)⟩,⟨true, .right, some (87:State)⟩)
            else
              if q.val < 86 then
                (⟨false, .right, some (86:State)⟩,⟨true, .right, some (76:State)⟩)
              else
                if q.val < 87 then
                  (⟨false, .right, some (5:State)⟩,⟨true, .left, some (75:State)⟩)
                else
                  (⟨false, .right, some (69:State)⟩,⟨true, .right, some (88:State)⟩)
  else
    if q.val < 132 then
      if q.val < 110 then
        if q.val < 99 then
          if q.val < 93 then
            if q.val < 90 then
              if q.val < 89 then
                (⟨false, .right, some (2:State)⟩,⟨true, .right, some (8:State)⟩)
              else
                (⟨false, .right, some (90:State)⟩,⟨true, .right, some (91:State)⟩)
            else
              if q.val < 91 then
                (⟨false, .left, some (13:State)⟩,⟨true, .right, some (84:State)⟩)
              else
                if q.val < 92 then
                  (⟨false, .right, some (92:State)⟩,⟨true, .right, some (94:State)⟩)
                else
                  (⟨false, .left, some (13:State)⟩,⟨true, .right, some (93:State)⟩)
          else
            if q.val < 96 then
              if q.val < 94 then
                (⟨false, .right, some (94:State)⟩,⟨true, .right, some (95:State)⟩)
              else
                if q.val < 95 then
                  (⟨false, .right, some (63:State)⟩,⟨true, .right, some (84:State)⟩)
                else
                  (⟨false, .right, some (97:State)⟩,⟨true, .right, some (61:State)⟩)
            else
              if q.val < 97 then
                (⟨false, .right, some (11:State)⟩,⟨false, .left, some (151:State)⟩)
              else
                if q.val < 98 then
                  (⟨false, .right, some (64:State)⟩,⟨true, .right, some (83:State)⟩)
                else
                  (⟨false, .left, some (103:State)⟩,⟨true, .left, some (93:State)⟩)
        else
          if q.val < 104 then
            if q.val < 101 then
              if q.val < 100 then
                (⟨false, .left, some (91:State)⟩,⟨true, .right, some (18:State)⟩)
              else
                (⟨false, .right, some (84:State)⟩,⟨true, .right, some (4:State)⟩)
            else
              if q.val < 102 then
                (⟨false, .right, some (102:State)⟩,⟨true, .right, some (18:State)⟩)
              else
                if q.val < 103 then
                  (⟨false, .left, some (17:State)⟩,⟨true, .right, some (100:State)⟩)
                else
                  (⟨false, .right, some (100:State)⟩,⟨true, .right, some (84:State)⟩)
          else
            if q.val < 107 then
              if q.val < 105 then
                (⟨false, .right, some (16:State)⟩,⟨true, .right, some (101:State)⟩)
              else
                if q.val < 106 then
                  (⟨false, .right, some (167:State)⟩,⟨true, .right, some (148:State)⟩)
                else
                  (⟨false, .right, some (104:State)⟩,⟨true, .right, some (105:State)⟩)
            else
              if q.val < 108 then
                (⟨false, .right, some (96:State)⟩,⟨true, .right, some (109:State)⟩)
              else
                if q.val < 109 then
                  (⟨false, .right, some (3:State)⟩,⟨true, .right, some (48:State)⟩)
                else
                  (⟨false, .right, some (70:State)⟩,⟨true, .right, some (108:State)⟩)
      else
        if q.val < 121 then
          if q.val < 115 then
            if q.val < 112 then
              if q.val < 111 then
                (⟨true, .left, some (111:State)⟩,⟨false, .left, some (117:State)⟩)
              else
                (⟨true, .left, some (28:State)⟩,⟨false, .right, some (111:State)⟩)
            else
              if q.val < 113 then
                (⟨true, .right, some (143:State)⟩,⟨true, .right, some (112:State)⟩)
              else
                if q.val < 114 then
                  (⟨false, .left, some (110:State)⟩,⟨false, .right, some (113:State)⟩)
                else
                  (⟨false, .left, some (123:State)⟩,⟨false, .left, some (144:State)⟩)
          else
            if q.val < 118 then
              if q.val < 116 then
                (⟨false, .left, some (119:State)⟩,⟨true, .left, some (117:State)⟩)
              else
                if q.val < 117 then
                  (⟨false, .left, some (144:State)⟩,⟨true, .left, some (129:State)⟩)
                else
                  (⟨false, .left, some (122:State)⟩,⟨true, .left, some (117:State)⟩)
            else
              if q.val < 119 then
                (⟨false, .right, some (125:State)⟩,⟨true, .right, some (118:State)⟩)
              else
                if q.val < 120 then
                  (⟨false, .left, some (141:State)⟩,⟨true, .left, some (117:State)⟩)
                else
                  (⟨false, .left, some (126:State)⟩,⟨false, .right, some (112:State)⟩)
        else
          if q.val < 126 then
            if q.val < 123 then
              if q.val < 122 then
                (⟨false, .right, some (127:State)⟩,⟨true, .right, some (121:State)⟩)
              else
                (⟨false, .left, some (132:State)⟩,⟨true, .left, some (117:State)⟩)
            else
              if q.val < 124 then
                (⟨false, .left, some (128:State)⟩,⟨false, .left, none⟩)
              else
                if q.val < 125 then
                  (⟨false, .right, some (130:State)⟩,⟨true, .right, some (124:State)⟩)
                else
                  (⟨false, .right, some (124:State)⟩,⟨true, .right, some (125:State)⟩)
          else
            if q.val < 129 then
              if q.val < 127 then
                (⟨true, .right, some (126:State)⟩,⟨true, .left, some (117:State)⟩)
              else
                if q.val < 128 then
                  (⟨false, .right, some (133:State)⟩,⟨true, .right, some (127:State)⟩)
                else
                  (⟨true, .right, some (136:State)⟩,⟨false, .left, some (128:State)⟩)
            else
              if q.val < 130 then
                (⟨false, .left, some (128:State)⟩,⟨true, .left, some (134:State)⟩)
              else
                if q.val < 131 then
                  (⟨false, .right, some (121:State)⟩,⟨true, .right, some (130:State)⟩)
                else
                  (⟨false, .left, some (126:State)⟩,⟨false, .right, some (140:State)⟩)
    else
      if q.val < 154 then
        if q.val < 143 then
          if q.val < 137 then
            if q.val < 134 then
              if q.val < 133 then
                (⟨false, .left, some (142:State)⟩,⟨true, .left, some (117:State)⟩)
              else
                (⟨false, .right, some (110:State)⟩,⟨true, .right, some (133:State)⟩)
            else
              if q.val < 135 then
                (⟨false, .left, some (129:State)⟩,⟨true, .left, some (134:State)⟩)
              else
                if q.val < 136 then
                  (⟨false, .right, some (118:State)⟩,⟨true, .right, some (135:State)⟩)
                else
                  (⟨false, .right, some (136:State)⟩,⟨false, .right, some (113:State)⟩)
          else
            if q.val < 140 then
              if q.val < 138 then
                (⟨true, .left, some (38:State)⟩,⟨true, .right, some (137:State)⟩)
              else
                if q.val < 139 then
                  (⟨false, .right, some (140:State)⟩,⟨true, .right, some (138:State)⟩)
                else
                  (⟨true, .left, some (134:State)⟩,⟨true, .right, some (116:State)⟩)
            else
              if q.val < 141 then
                (⟨true, .right, some (112:State)⟩,⟨true, .right, some (138:State)⟩)
              else
                if q.val < 142 then
                  (⟨false, .right, some (141:State)⟩,⟨true, .right, some (12:State)⟩)
                else
                  (⟨false, .left, some (115:State)⟩,⟨true, .left, some (117:State)⟩)
        else
          if q.val < 148 then
            if q.val < 145 then
              if q.val < 144 then
                (⟨false, .right, some (139:State)⟩,⟨false, .right, some (112:State)⟩)
              else
                (⟨true, .left, some (114:State)⟩,⟨true, .left, some (144:State)⟩)
            else
              if q.val < 146 then
                (⟨false, .right, some (55:State)⟩,⟨true, .right, some (89:State)⟩)
              else
                if q.val < 147 then
                  (⟨false, .right, some (150:State)⟩,⟨true, .right, some (17:State)⟩)
                else
                  (⟨false, .right, some (27:State)⟩,⟨true, .right, some (146:State)⟩)
          else
            if q.val < 151 then
              if q.val < 149 then
                (⟨false, .right, some (147:State)⟩,⟨true, .right, some (15:State)⟩)
              else
                if q.val < 150 then
                  (⟨false, .right, some (21:State)⟩,⟨true, .right, some (99:State)⟩)
                else
                  (⟨false, .right, some (149:State)⟩,⟨true, .right, some (13:State)⟩)
            else
              if q.val < 152 then
                (⟨false, .left, some (128:State)⟩,⟨false, .left, some (117:State)⟩)
              else
                if q.val < 153 then
                  (⟨false, .right, some (98:State)⟩,⟨true, .right, some (16:State)⟩)
                else
                  (⟨false, .right, some (145:State)⟩,⟨true, .right, some (152:State)⟩)
      else
        if q.val < 165 then
          if q.val < 159 then
            if q.val < 156 then
              if q.val < 155 then
                (⟨false, .right, some (168:State)⟩,⟨true, .right, some (18:State)⟩)
              else
                (⟨false, .right, some (171:State)⟩,⟨true, .right, some (154:State)⟩)
            else
              if q.val < 157 then
                (⟨false, .right, some (95:State)⟩,⟨true, .right, some (103:State)⟩)
              else
                if q.val < 158 then
                  (⟨false, .right, some (155:State)⟩,⟨true, .right, some (156:State)⟩)
                else
                  (⟨false, .right, some (98:State)⟩,⟨true, .right, some (157:State)⟩)
          else
            if q.val < 162 then
              if q.val < 160 then
                (⟨false, .right, some (166:State)⟩,⟨true, .right, some (158:State)⟩)
              else
                if q.val < 161 then
                  (⟨false, .right, some (159:State)⟩,⟨true, .right, some (90:State)⟩)
                else
                  (⟨false, .right, some (165:State)⟩,⟨true, .right, some (160:State)⟩)
            else
              if q.val < 163 then
                (⟨false, .right, some (61:State)⟩,⟨true, .right, some (161:State)⟩)
              else
                if q.val < 164 then
                  (⟨false, .right, some (162:State)⟩,⟨true, .right, some (26:State)⟩)
                else
                  (⟨false, .right, some (90:State)⟩,⟨true, .right, some (153:State)⟩)
        else
          if q.val < 171 then
            if q.val < 168 then
              if q.val < 166 then
                (⟨false, .left, some (93:State)⟩,⟨true, .right, some (164:State)⟩)
              else
                if q.val < 167 then
                  (⟨false, .right, some (169:State)⟩,⟨true, .right, some (22:State)⟩)
                else
                  (⟨false, .left, some (171:State)⟩,⟨true, .right, some (16:State)⟩)
            else
              if q.val < 169 then
                (⟨false, .right, some (167:State)⟩,⟨true, .right, some (21:State)⟩)
              else
                if q.val < 170 then
                  (⟨false, .left, some (155:State)⟩,⟨true, .right, some (101:State)⟩)
                else
                  (⟨false, .right, some (106:State)⟩,⟨true, .right, some (169:State)⟩)
          else
            if q.val < 174 then
              if q.val < 172 then
                (⟨false, .left, some (92:State)⟩,⟨true, .right, some (170:State)⟩)
              else
                if q.val < 173 then
                  (⟨false, .right, some (163:State)⟩,⟨true, .right, some (25:State)⟩)
                else
                  (⟨false, .right, some (172:State)⟩,⟨true, .right, some (174:State)⟩)
            else
              if q.val < 175 then
                (⟨false, .right, some (0:State)⟩,⟨false, .left, some (113:State)⟩)
              else
                if q.val < 176 then
                  (⟨false, .right, some (52:State)⟩,⟨true, .right, some (57:State)⟩)
                else
                  (⟨false, .right, some (107:State)⟩,⟨true, .right, some (19:State)⟩)
def machine (q : State) (b : Bool) : Instruction 177 := if b then (pair q).2 else (pair q).1
def row (q : State) (b : Bool) : String :=
  let a := machine q b
  name q ++ " " ++ (if b then "1" else "0") ++ " " ++
    (if a.write then "1" else "0") ++ " " ++ (if a.move = .right then "R" else "L") ++ " " ++
    (a.next.map name).getD "halt" ++ "\n"
def rendered0 : List String := [row (0:State) false, row (0:State) true, row (1:State) false, row (1:State) true, row (2:State) false, row (2:State) true, row (3:State) false, row (3:State) true]
def raw0 : List String := ["a:CD:5 0 0 R k:24\n", "a:CD:5 1 0 R k:55\n", "a:CD:6 0 0 L d:18\n", "a:CD:6 1 1 L d:61\n", "a:CD:7 0 0 R k:24\n", "a:CD:7 1 0 R k:33\n", "a:CI:0 0 0 L d:69\n", "a:CI:0 1 0 L k:60\n"]
theorem verified0 : rendered0 = raw0 := by decide +kernel
def rendered1 : List String := [row (4:State) false, row (4:State) true, row (5:State) false, row (5:State) true, row (6:State) false, row (6:State) true, row (7:State) false, row (7:State) true]
def raw1 : List String := ["a:CI:1 0 0 R k:49\n", "a:CI:1 1 0 R k:25\n", "a:CI:2 0 0 L d:40\n", "a:CI:2 1 0 R k:51\n", "a:CI:3 0 0 L d:69\n", "a:CI:3 1 0 R k:32\n", "a:CI:4 0 0 L d:40\n", "a:CI:4 1 0 R k:48\n"]
theorem verified1 : rendered1 = raw1 := by decide +kernel
def rendered2 : List String := [row (8:State) false, row (8:State) true, row (9:State) false, row (9:State) true, row (10:State) false, row (10:State) true, row (11:State) false, row (11:State) true]
def raw2 : List String := ["a:CI:5 0 0 L d:61\n", "a:CI:5 1 1 L d:65\n", "a:CI:6 0 0 R k:49\n", "a:CI:6 1 0 R k:60\n", "a:CI:7 0 0 L d:61\n", "a:CI:7 1 1 L d:18\n", "a:CI:8 0 0 L d:69\n", "a:CI:8 1 0 R k:36\n"]
theorem verified2 : rendered2 = raw2 := by decide +kernel
def rendered3 : List String := [row (12:State) false, row (12:State) true, row (13:State) false, row (13:State) true, row (14:State) false, row (14:State) true, row (15:State) false, row (15:State) true]
def raw3 : List String := ["d:0 0 0 R rootleft\n", "d:0 1 1 R rootinside\n", "d:101 0 0 L n:10\n", "d:101 1 1 R d:104\n", "d:102 0 0 R d:63\n", "d:102 1 1 R d:98\n", "d:104 0 0 R d:85\n", "d:104 1 1 R d:99\n"]
theorem verified3 : rendered3 = raw3 := by decide +kernel
def rendered4 : List String := [row (16:State) false, row (16:State) true, row (17:State) false, row (17:State) true, row (18:State) false, row (18:State) true, row (19:State) false, row (19:State) true]
def raw4 : List String := ["d:105 0 0 L d:85\n", "d:105 1 1 L d:109\n", "d:109 0 0 R d:102\n", "d:109 1 1 R d:85\n", "d:118 0 0 R d:79\n", "d:118 1 1 R d:87\n", "d:12 0 0 R d:13\n", "d:12 1 1 R d:20\n"]
theorem verified4 : rendered4 = raw4 := by decide +kernel
def rendered5 : List String := [row (20:State) false, row (20:State) true, row (21:State) false, row (21:State) true, row (22:State) false, row (22:State) true, row (23:State) false, row (23:State) true]
def raw5 : List String := ["d:13 0 0 R a:CI:8\n", "d:13 1 1 R d:14\n", "d:130 0 0 R a:CI:1\n", "d:130 1 1 R d:87\n", "d:134 0 0 R d:85\n", "d:134 1 1 R d:109\n", "d:14 0 0 R d:15\n", "d:14 1 0 L k16share:0\n"]
theorem verified5 : rendered5 = raw5 := by decide +kernel
def rendered6 : List String := [row (24:State) false, row (24:State) true, row (25:State) false, row (25:State) true, row (26:State) false, row (26:State) true, row (27:State) false, row (27:State) true]
def raw6 : List String := ["d:142 0 0 R d:85\n", "d:142 1 1 R d:130\n", "d:143 0 0 R d:144\n", "d:143 1 1 R d:145\n", "d:144 0 0 L d:97\n", "d:144 1 1 R d:142\n", "d:145 0 0 L d:104\n", "d:145 1 1 R d:74\n"]
theorem verified6 : rendered6 = raw6 := by decide +kernel
def rendered7 : List String := [row (28:State) false, row (28:State) true, row (29:State) false, row (29:State) true, row (30:State) false, row (30:State) true, row (31:State) false, row (31:State) true]
def raw7 : List String := ["d:146 0 0 R d:147\n", "d:146 1 1 R d:148\n", "d:147 0 0 R a:CI:4\n", "d:147 1 0 L k16share:1\n", "d:148 0 0 R a:CD:5\n", "d:148 1 0 L k:2\n", "d:149 0 0 R d:150\n", "d:149 1 1 R d:151\n"]
theorem verified7 : rendered7 = raw7 := by decide +kernel
def rendered8 : List String := [row (32:State) false, row (32:State) true, row (33:State) false, row (33:State) true, row (34:State) false, row (34:State) true, row (35:State) false, row (35:State) true]
def raw8 : List String := ["d:15 0 0 R a:CI:7\n", "d:15 1 1 R d:16\n", "d:150 0 0 R a:CI:4\n", "d:150 1 1 R d:79\n", "d:151 0 0 R d:152\n", "d:151 1 1 R d:83\n", "d:152 0 0 R d:153\n", "d:152 1 1 R d:148\n"]
theorem verified8 : rendered8 = raw8 := by decide +kernel
def rendered9 : List String := [row (36:State) false, row (36:State) true, row (37:State) false, row (37:State) true, row (38:State) false, row (38:State) true, row (39:State) false, row (39:State) true]
def raw9 : List String := ["d:153 0 0 R a:CD:5\n", "d:153 1 1 R d:154\n", "d:154 0 0 R a:CD:5\n", "d:154 1 1 R d:155\n", "d:155 0 0 L d:146\n", "d:155 1 1 R a:CD:5\n", "d:157 0 0 R d:74\n", "d:157 1 1 R d:158\n"]
theorem verified9 : rendered9 = raw9 := by decide +kernel
def rendered10 : List String := [row (40:State) false, row (40:State) true, row (41:State) false, row (41:State) true, row (42:State) false, row (42:State) true, row (43:State) false, row (43:State) true]
def raw10 : List String := ["d:158 0 0 R d:159\n", "d:158 1 1 R d:164\n", "d:159 0 0 R d:45\n", "d:159 1 1 R d:160\n", "d:16 0 0 R d:17\n", "d:16 1 1 R d:18\n", "d:160 0 0 R a:CD:6\n", "d:160 1 1 R d:161\n"]
theorem verified10 : rendered10 = raw10 := by decide +kernel
def rendered11 : List String := [row (44:State) false, row (44:State) true, row (45:State) false, row (45:State) true, row (46:State) false, row (46:State) true, row (47:State) false, row (47:State) true]
def raw11 : List String := ["d:161 0 0 R rg-fresh:841041b200ff\n", "d:161 1 1 R d:163\n", "d:163 0 0 R a:CI:5\n", "d:163 1 1 R d:39\n", "d:164 0 0 R d:165\n", "d:164 1 1 R d:146\n", "d:165 0 0 R d:40\n", "d:165 1 1 R d:64\n"]
theorem verified11 : rendered11 = raw11 := by decide +kernel
def rendered12 : List String := [row (48:State) false, row (48:State) true, row (49:State) false, row (49:State) true, row (50:State) false, row (50:State) true, row (51:State) false, row (51:State) true]
def raw12 : List String := ["d:17 0 0 R a:CD:6\n", "d:17 1 0 L new:1\n", "d:18 0 0 R a:CD:7\n", "d:18 1 1 R d:19\n", "d:19 0 0 R a:CI:6\n", "d:19 1 0 L k16share:0\n", "d:20 0 0 R a:CD:7\n", "d:20 1 1 R d:8\n"]
theorem verified12 : rendered12 = raw12 := by decide +kernel
def rendered13 : List String := [row (52:State) false, row (52:State) true, row (53:State) false, row (53:State) true, row (54:State) false, row (54:State) true, row (55:State) false, row (55:State) true]
def raw13 : List String := ["d:22 0 0 R d:23\n", "d:22 1 1 R d:25\n", "d:23 0 0 R a:CD:6\n", "d:23 1 1 R d:24\n", "d:24 0 0 R a:CI:3\n", "d:24 1 0 L k16share:1\n", "d:25 0 0 R d:12\n", "d:25 1 1 R d:26\n"]
theorem verified13 : rendered13 = raw13 := by decide +kernel
def rendered14 : List String := [row (56:State) false, row (56:State) true, row (57:State) false, row (57:State) true, row (58:State) false, row (58:State) true, row (59:State) false, row (59:State) true]
def raw14 : List String := ["d:26 0 0 R a:CD:6\n", "d:26 1 1 R d:147\n", "d:28 0 0 R d:29\n", "d:28 1 1 R d:149\n", "d:29 0 0 R a:CI:3\n", "d:29 1 1 R d:31\n", "d:31 0 0 R d:32\n", "d:31 1 1 R d:157\n"]
theorem verified14 : rendered14 = raw14 := by decide +kernel
def rendered15 : List String := [row (60:State) false, row (60:State) true, row (61:State) false, row (61:State) true, row (62:State) false, row (62:State) true, row (63:State) false, row (63:State) true]
def raw15 : List String := ["d:32 0 0 R a:CI:3\n", "d:32 1 1 R rg-fresh:61facaad8d63\n", "d:39 0 0 R a:CD:6\n", "d:39 1 1 R d:40\n", "d:40 0 0 L d:161\n", "d:40 1 0 L new:1\n", "d:43 0 0 R d:44\n", "d:43 1 1 R d:59\n"]
theorem verified15 : rendered15 = raw15 := by decide +kernel
def rendered16 : List String := [row (64:State) false, row (64:State) true, row (65:State) false, row (65:State) true, row (66:State) false, row (66:State) true, row (67:State) false, row (67:State) true]
def raw16 : List String := ["d:44 0 0 R d:45\n", "d:44 1 1 R d:46\n", "d:45 0 0 R a:CI:0\n", "d:45 1 1 R d:19\n", "d:46 0 0 R d:47\n", "d:46 1 1 R d:49\n", "d:47 0 0 R a:CI:2\n", "d:47 1 1 R a:CI:7\n"]
theorem verified16 : rendered16 = raw16 := by decide +kernel
def rendered17 : List String := [row (68:State) false, row (68:State) true, row (69:State) false, row (69:State) true, row (70:State) false, row (70:State) true, row (71:State) false, row (71:State) true]
def raw17 : List String := ["d:49 0 0 R d:50\n", "d:49 1 1 R d:57\n", "d:50 0 0 R d:51\n", "d:50 1 1 R d:53\n", "d:51 0 0 R a:CI:0\n", "d:51 1 1 R d:52\n", "d:52 0 0 R a:CI:7\n", "d:52 1 1 R a:CD:6\n"]
theorem verified17 : rendered17 = raw17 := by decide +kernel
def rendered18 : List String := [row (72:State) false, row (72:State) true, row (73:State) false, row (73:State) true, row (74:State) false, row (74:State) true, row (75:State) false, row (75:State) true]
def raw18 : List String := ["d:53 0 0 R a:CD:6\n", "d:53 1 1 R d:54\n", "d:54 0 0 R d:55\n", "d:54 1 0 L d:19\n", "d:55 0 0 R a:CI:7\n", "d:55 1 1 R d:56\n", "d:56 0 0 L d:25\n", "d:56 1 1 R a:CI:7\n"]
theorem verified18 : rendered18 = raw18 := by decide +kernel
def rendered19 : List String := [row (76:State) false, row (76:State) true, row (77:State) false, row (77:State) true, row (78:State) false, row (78:State) true, row (79:State) false, row (79:State) true]
def raw19 : List String := ["d:57 0 0 R a:CD:7\n", "d:57 1 1 R d:69\n", "d:59 0 0 R d:60\n", "d:59 1 1 R d:23\n", "d:60 0 0 R a:CI:3\n", "d:60 1 1 R d:61\n", "d:61 0 0 R a:CI:6\n", "d:61 1 1 R d:62\n"]
theorem verified19 : rendered19 = raw19 := by decide +kernel
def rendered20 : List String := [row (80:State) false, row (80:State) true, row (81:State) false, row (81:State) true, row (82:State) false, row (82:State) true, row (83:State) false, row (83:State) true]
def raw20 : List String := ["d:62 0 0 R a:CI:1\n", "d:62 1 0 L k:6\n", "d:63 0 0 R d:44\n", "d:63 1 1 R d:64\n", "d:64 0 0 R d:65\n", "d:64 1 1 R d:26\n", "d:65 0 0 L d:146\n", "d:65 1 1 R d:61\n"]
theorem verified20 : rendered20 = raw20 := by decide +kernel
def rendered21 : List String := [row (84:State) false, row (84:State) true, row (85:State) false, row (85:State) true, row (86:State) false, row (86:State) true, row (87:State) false, row (87:State) true]
def raw21 : List String := ["d:67 0 0 R d:68\n", "d:67 1 1 R d:70\n", "d:68 0 0 R d:69\n", "d:68 1 1 R d:57\n", "d:69 0 0 R a:CI:2\n", "d:69 1 1 L d:56\n", "d:70 0 0 R d:50\n", "d:70 1 1 R d:71\n"]
theorem verified21 : rendered21 = raw21 := by decide +kernel
def rendered22 : List String := [row (88:State) false, row (88:State) true, row (89:State) false, row (89:State) true, row (90:State) false, row (90:State) true, row (91:State) false, row (91:State) true]
def raw22 : List String := ["d:71 0 0 R a:CD:7\n", "d:71 1 1 R a:CI:5\n", "d:73 0 0 R d:74\n", "d:73 1 1 R d:75\n", "d:74 0 0 L d:101\n", "d:74 1 1 R d:67\n", "d:75 0 0 R d:76\n", "d:75 1 1 R d:78\n"]
theorem verified22 : rendered22 = raw22 := by decide +kernel
def rendered23 : List String := [row (92:State) false, row (92:State) true, row (93:State) false, row (93:State) true, row (94:State) false, row (94:State) true, row (95:State) false, row (95:State) true]
def raw23 : List String := ["d:76 0 0 L d:101\n", "d:76 1 1 R d:77\n", "d:77 0 0 R d:78\n", "d:77 1 1 R d:79\n", "d:78 0 0 R d:43\n", "d:78 1 1 R d:67\n", "d:79 0 0 R d:80\n", "d:79 1 1 R d:39\n"]
theorem verified23 : rendered23 = raw23 := by decide +kernel
def rendered24 : List String := [row (96:State) false, row (96:State) true, row (97:State) false, row (97:State) true, row (98:State) false, row (98:State) true, row (99:State) false, row (99:State) true]
def raw24 : List String := ["d:8 0 0 R a:CI:8\n", "d:8 1 0 L new:1\n", "d:80 0 0 R d:44\n", "d:80 1 1 R d:65\n", "d:83 0 0 L d:99\n", "d:83 1 1 L d:77\n", "d:85 0 0 L d:75\n", "d:85 1 1 R d:118\n"]
theorem verified24 : rendered24 = raw24 := by decide +kernel
def rendered25 : List String := [row (100:State) false, row (100:State) true, row (101:State) false, row (101:State) true, row (102:State) false, row (102:State) true, row (103:State) false, row (103:State) true]
def raw25 : List String := ["d:87 0 0 R d:67\n", "d:87 1 1 R a:CI:1\n", "d:97 0 0 R d:98\n", "d:97 1 1 R d:118\n", "d:98 0 0 L d:109\n", "d:98 1 1 R d:87\n", "d:99 0 0 R d:87\n", "d:99 1 1 R d:67\n"]
theorem verified25 : rendered25 = raw25 := by decide +kernel
def rendered26 : List String := [row (104:State) false, row (104:State) true, row (105:State) false, row (105:State) true, row (106:State) false, row (106:State) true, row (107:State) false, row (107:State) true]
def raw26 : List String := ["fresh:4 0 0 R d:105\n", "fresh:4 1 1 R d:97\n", "fresh:5 0 0 R purenew:5\n", "fresh:5 1 1 R n:12\n", "fresh:6 0 0 R fresh:4\n", "fresh:6 1 1 R fresh:5\n", "g:013460a16426 0 0 R d:8\n", "g:013460a16426 1 1 R g:dbe067bd3065\n"]
theorem verified26 : rendered26 = raw26 := by decide +kernel
def rendered27 : List String := [row (108:State) false, row (108:State) true, row (109:State) false, row (109:State) true, row (110:State) false, row (110:State) true, row (111:State) false, row (111:State) true]
def raw27 : List String := ["g:2d599279071e 0 0 R a:CI:0\n", "g:2d599279071e 1 1 R d:17\n", "g:dbe067bd3065 0 0 R d:51\n", "g:dbe067bd3065 1 1 R g:2d599279071e\n", "k16share:0 0 1 L k16share:1\n", "k16share:0 1 0 L k:2\n", "k16share:1 0 1 L d:146\n", "k16share:1 1 0 R k16share:1\n"]
theorem verified27 : rendered27 = raw27 := by decide +kernel
def rendered28 : List String := [row (112:State) false, row (112:State) true, row (113:State) false, row (113:State) true, row (114:State) false, row (114:State) true, row (115:State) false, row (115:State) true]
def raw28 : List String := ["k:0 0 1 R k:94\n", "k:0 1 1 R k:0\n", "k:10 0 0 L k16share:0\n", "k:10 1 0 R k:10\n", "k:113 0 0 L k:302\n", "k:113 1 0 L k:97\n", "k:15 0 0 L k:23\n", "k:15 1 1 L k:2\n"]
theorem verified28 : rendered28 = raw28 := by decide +kernel
def rendered29 : List String := [row (116:State) false, row (116:State) true, row (117:State) false, row (117:State) true, row (118:State) false, row (118:State) true, row (119:State) false, row (119:State) true]
def raw29 : List String := ["k:198 0 0 L k:97\n", "k:198 1 1 L k:40\n", "k:2 0 0 L k:3\n", "k:2 1 1 L k:2\n", "k:22 0 0 R k:33\n", "k:22 1 1 R k:22\n", "k:23 0 0 L k:75\n", "k:23 1 1 L k:2\n"]
theorem verified29 : rendered29 = raw29 := by decide +kernel
def rendered30 : List String := [row (120:State) false, row (120:State) true, row (121:State) false, row (121:State) true, row (122:State) false, row (122:State) true, row (123:State) false, row (123:State) true]
def raw30 : List String := ["k:24 0 0 L k:35\n", "k:24 1 0 R k:0\n", "k:25 0 0 R k:36\n", "k:25 1 1 R k:25\n", "k:3 0 0 L k:5\n", "k:3 1 1 L k:2\n", "k:302 0 0 L k:4\n", "k:302 1 0 L halt\n"]
theorem verified30 : rendered30 = raw30 := by decide +kernel
def rendered31 : List String := [row (124:State) false, row (124:State) true, row (125:State) false, row (125:State) true, row (126:State) false, row (126:State) true, row (127:State) false, row (127:State) true]
def raw31 : List String := ["k:32 0 0 R k:48\n", "k:32 1 1 R k:32\n", "k:33 0 0 R k:32\n", "k:33 1 1 R k:33\n", "k:35 0 1 R k:35\n", "k:35 1 1 L k:2\n", "k:36 0 0 R k:51\n", "k:36 1 1 R k:36\n"]
theorem verified31 : rendered31 = raw31 := by decide +kernel
def rendered32 : List String := [row (128:State) false, row (128:State) true, row (129:State) false, row (129:State) true, row (130:State) false, row (130:State) true, row (131:State) false, row (131:State) true]
def raw32 : List String := ["k:4 0 1 R k:6\n", "k:4 1 0 L k:4\n", "k:40 0 0 L k:4\n", "k:40 1 1 L k:54\n", "k:48 0 0 R k:25\n", "k:48 1 1 R k:48\n", "k:49 0 0 L k:35\n", "k:49 1 0 R k:74\n"]
theorem verified32 : rendered32 = raw32 := by decide +kernel
def rendered33 : List String := [row (132:State) false, row (132:State) true, row (133:State) false, row (133:State) true, row (134:State) false, row (134:State) true, row (135:State) false, row (135:State) true]
def raw33 : List String := ["k:5 0 0 L k:9\n", "k:5 1 1 L k:2\n", "k:51 0 0 R k16share:0\n", "k:51 1 1 R k:51\n", "k:54 0 0 L k:40\n", "k:54 1 1 L k:54\n", "k:55 0 0 R k:22\n", "k:55 1 1 R k:55\n"]
theorem verified33 : rendered33 = raw33 := by decide +kernel
def rendered34 : List String := [row (136:State) false, row (136:State) true, row (137:State) false, row (137:State) true, row (138:State) false, row (138:State) true, row (139:State) false, row (139:State) true]
def raw34 : List String := ["k:6 0 0 R k:6\n", "k:6 1 0 R k:10\n", "k:60 0 1 L d:155\n", "k:60 1 1 R k:60\n", "k:64 0 0 R k:74\n", "k:64 1 1 R k:64\n", "k:66 0 1 L k:54\n", "k:66 1 1 R k:198\n"]
theorem verified34 : rendered34 = raw34 := by decide +kernel
def rendered35 : List String := [row (140:State) false, row (140:State) true, row (141:State) false, row (141:State) true, row (142:State) false, row (142:State) true, row (143:State) false, row (143:State) true]
def raw35 : List String := ["k:74 0 1 R k:0\n", "k:74 1 1 R k:64\n", "k:75 0 0 R k:75\n", "k:75 1 1 R d:0\n", "k:9 0 0 L k:15\n", "k:9 1 1 L k:2\n", "k:94 0 0 R k:66\n", "k:94 1 0 R k:0\n"]
theorem verified35 : rendered35 = raw35 := by decide +kernel
def rendered36 : List String := [row (144:State) false, row (144:State) true, row (145:State) false, row (145:State) true, row (146:State) false, row (146:State) true, row (147:State) false, row (147:State) true]
def raw36 : List String := ["k:97 0 1 L k:113\n", "k:97 1 1 L k:97\n", "n:0 0 0 R d:25\n", "n:0 1 1 R d:73\n", "n:10 0 0 R n:9\n", "n:10 1 1 R d:109\n", "n:11 0 0 R d:145\n", "n:11 1 1 R n:10\n"]
theorem verified36 : rendered36 = raw36 := by decide +kernel
def rendered37 : List String := [row (148:State) false, row (148:State) true, row (149:State) false, row (149:State) true, row (150:State) false, row (150:State) true, row (151:State) false, row (151:State) true]
def raw37 : List String := ["n:12 0 0 R n:11\n", "n:12 1 1 R d:104\n", "n:8 0 0 R d:130\n", "n:8 1 1 R d:85\n", "n:9 0 0 R n:8\n", "n:9 1 1 R d:101\n", "new:1 0 0 L k:4\n", "new:1 1 0 L k:2\n"]
theorem verified37 : rendered37 = raw37 := by decide +kernel
def rendered38 : List String := [row (152:State) false, row (152:State) true, row (153:State) false, row (153:State) true, row (154:State) false, row (154:State) true, row (155:State) false, row (155:State) true]
def raw38 : List String := ["purenew:0 0 0 R d:83\n", "purenew:0 1 1 R d:105\n", "purenew:1 0 0 R n:0\n", "purenew:1 1 1 R purenew:0\n", "purenew:10 0 0 R purenew:6\n", "purenew:10 1 1 R d:118\n", "purenew:11 0 0 R purenew:9\n", "purenew:11 1 1 R purenew:10\n"]
theorem verified38 : rendered38 = raw38 := by decide +kernel
def rendered39 : List String := [row (156:State) false, row (156:State) true, row (157:State) false, row (157:State) true, row (158:State) false, row (158:State) true, row (159:State) false, row (159:State) true]
def raw39 : List String := ["purenew:12 0 0 R d:79\n", "purenew:12 1 1 R d:99\n", "purenew:13 0 0 R purenew:11\n", "purenew:13 1 1 R purenew:12\n", "purenew:14 0 0 R d:83\n", "purenew:14 1 1 R purenew:13\n", "purenew:15 0 0 R purenew:4\n", "purenew:15 1 1 R purenew:14\n"]
theorem verified39 : rendered39 = raw39 := by decide +kernel
def rendered40 : List String := [row (160:State) false, row (160:State) true, row (161:State) false, row (161:State) true, row (162:State) false, row (162:State) true, row (163:State) false, row (163:State) true]
def raw40 : List String := ["purenew:16 0 0 R purenew:15\n", "purenew:16 1 1 R d:74\n", "purenew:17 0 0 R purenew:3\n", "purenew:17 1 1 R purenew:16\n", "purenew:18 0 0 R d:39\n", "purenew:18 1 1 R purenew:17\n", "purenew:19 0 0 R purenew:18\n", "purenew:19 1 1 R d:144\n"]
theorem verified40 : rendered40 = raw40 := by decide +kernel
def rendered41 : List String := [row (164:State) false, row (164:State) true, row (165:State) false, row (165:State) true, row (166:State) false, row (166:State) true, row (167:State) false, row (167:State) true]
def raw41 : List String := ["purenew:2 0 0 R d:74\n", "purenew:2 1 1 R purenew:1\n", "purenew:3 0 0 L d:77\n", "purenew:3 1 1 R purenew:2\n", "purenew:4 0 0 R purenew:7\n", "purenew:4 1 1 R d:134\n", "purenew:5 0 0 L purenew:9\n", "purenew:5 1 1 R d:105\n"]
theorem verified41 : rendered41 = raw41 := by decide +kernel
def rendered42 : List String := [row (168:State) false, row (168:State) true, row (169:State) false, row (169:State) true, row (170:State) false, row (170:State) true, row (171:State) false, row (171:State) true]
def raw42 : List String := ["purenew:6 0 0 R purenew:5\n", "purenew:6 1 1 R d:130\n", "purenew:7 0 0 L purenew:11\n", "purenew:7 1 1 R d:97\n", "purenew:8 0 0 R fresh:6\n", "purenew:8 1 1 R purenew:7\n", "purenew:9 0 0 L d:76\n", "purenew:9 1 1 R purenew:8\n"]
theorem verified42 : rendered42 = raw42 := by decide +kernel
def rendered43 : List String := [row (172:State) false, row (172:State) true, row (173:State) false, row (173:State) true, row (174:State) false, row (174:State) true, row (175:State) false, row (175:State) true]
def raw43 : List String := ["rg-fresh:17f3b04d308d 0 0 R purenew:19\n", "rg-fresh:17f3b04d308d 1 1 R d:143\n", "rg-fresh:61facaad8d63 0 0 R rg-fresh:17f3b04d308d\n", "rg-fresh:61facaad8d63 1 1 R rg-fresh:841041b200ff\n", "rg-fresh:841041b200ff 0 0 R a:CD:5\n", "rg-fresh:841041b200ff 1 0 L k:10\n", "rootinside 0 0 R d:22\n", "rootinside 1 1 R d:28\n"]
theorem verified43 : rendered43 = raw43 := by decide +kernel
def rendered44 : List String := [row (176:State) false, row (176:State) true]
def raw44 : List String := ["rootleft 0 0 R g:013460a16426\n", "rootleft 1 1 R d:12\n"]
theorem verified44 : rendered44 = raw44 := by decide +kernel
def rendered : List String := rendered0 ++ rendered1 ++ rendered2 ++ rendered3 ++ rendered4 ++ rendered5 ++ rendered6 ++ rendered7 ++ rendered8 ++ rendered9 ++ rendered10 ++ rendered11 ++ rendered12 ++ rendered13 ++ rendered14 ++ rendered15 ++ rendered16 ++ rendered17 ++ rendered18 ++ rendered19 ++ rendered20 ++ rendered21 ++ rendered22 ++ rendered23 ++ rendered24 ++ rendered25 ++ rendered26 ++ rendered27 ++ rendered28 ++ rendered29 ++ rendered30 ++ rendered31 ++ rendered32 ++ rendered33 ++ rendered34 ++ rendered35 ++ rendered36 ++ rendered37 ++ rendered38 ++ rendered39 ++ rendered40 ++ rendered41 ++ rendered42 ++ rendered43 ++ rendered44
def raw : List String := raw0 ++ raw1 ++ raw2 ++ raw3 ++ raw4 ++ raw5 ++ raw6 ++ raw7 ++ raw8 ++ raw9 ++ raw10 ++ raw11 ++ raw12 ++ raw13 ++ raw14 ++ raw15 ++ raw16 ++ raw17 ++ raw18 ++ raw19 ++ raw20 ++ raw21 ++ raw22 ++ raw23 ++ raw24 ++ raw25 ++ raw26 ++ raw27 ++ raw28 ++ raw29 ++ raw30 ++ raw31 ++ raw32 ++ raw33 ++ raw34 ++ raw35 ++ raw36 ++ raw37 ++ raw38 ++ raw39 ++ raw40 ++ raw41 ++ raw42 ++ raw43 ++ raw44
theorem literal_exact : rendered = raw := by
  unfold rendered raw
  rw [verified0, verified1, verified2, verified3, verified4, verified5, verified6, verified7, verified8, verified9, verified10, verified11, verified12, verified13, verified14, verified15, verified16, verified17, verified18, verified19, verified20, verified21, verified22, verified23, verified24, verified25, verified26, verified27, verified28, verified29, verified30, verified31, verified32, verified33, verified34, verified35, verified36, verified37, verified38, verified39, verified40, verified41, verified42, verified43, verified44]
theorem start_header : name start = "k:74" := by decide +kernel
#print axioms literal_exact
#print axioms start_header
end Blank177.Table
