import ScannerSnapshots
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank177.Boot
open NF210 NF192 Blank177.Table
theorem chunk67200 : Prefix 700 snap66500 snap67200 := checked _ _ _ (by decide) (by decide)
theorem chunk67900 : Prefix 700 snap67200 snap67900 := checked _ _ _ (by decide) (by decide)
theorem chunk68600 : Prefix 700 snap67900 snap68600 := checked _ _ _ (by decide) (by decide)
theorem chunk69300 : Prefix 700 snap68600 snap69300 := checked _ _ _ (by decide) (by decide)
theorem chunk70000 : Prefix 700 snap69300 snap70000 := checked _ _ _ (by decide) (by decide)
theorem chunk70700 : Prefix 700 snap70000 snap70700 := checked _ _ _ (by decide) (by decide)
theorem chunk71400 : Prefix 700 snap70700 snap71400 := checked _ _ _ (by decide) (by decide)
theorem chunk72100 : Prefix 700 snap71400 snap72100 := checked _ _ _ (by decide) (by decide)
theorem chunk72800 : Prefix 700 snap72100 snap72800 := checked _ _ _ (by decide) (by decide)
theorem chunk73500 : Prefix 700 snap72800 snap73500 := checked _ _ _ (by decide) (by decide)
theorem chunk74071 : Prefix 571 snap73500 snap74071 := checked _ _ _ (by decide) (by decide)
end Blank177.Boot
