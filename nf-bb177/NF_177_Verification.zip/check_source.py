"""Check the 177-state source against the published pure NF178 source."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

PARENT_SOURCE = "7bacb7672e2df5f580588cc493b52c62bb0574de94c3a374d28e07195beccd47"
NEW_SOURCE = "76afdc3a7d4f37fbf056a7f84c84930fdd7c31a9d02e65ecfaddbd26510db54b"
NEW_TABLE = "a4968d492f38586a33882f80869a2f1a8e0628eeb6b3284fdfc02a22ec8a59df"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def instructions(data):
    rows = json.loads(data)
    spans = {}
    leaves = set()
    for i, (address, _, _) in enumerate(rows):
        assert address and set(address) <= {"0", "1"}
        assert address not in leaves
        leaves.add(address)
        for n in range(len(address) + 1):
            spans.setdefault(address[:n], [i, i])[1] = i + 1
    assert [a for a, _, _ in rows] == sorted(leaves)
    for node in spans:
        if node in leaves:
            assert node + "0" not in spans and node + "1" not in spans
        else:
            assert node + "0" in spans and node + "1" in spans
    edges = []
    for i, (address, op, arg) in enumerate(rows):
        seq = (i + 1) % len(rows)
        prefix = address
        if op == "CI":
            edges.append((seq,))
            continue
        char = "1" if op == "CC" else "0"
        for _ in range(arg if op in {"CC", "CB"} else 1):
            j = prefix.rfind(char)
            assert j >= 0
            prefix = prefix[:j]
        if op == "CD":
            edges.append((seq, None if address.endswith("1") else spans[prefix][1] % len(rows)))
        elif op == "CC":
            edges.append((spans[prefix][0],))
        else:
            assert op == "CB"
            edges.append((spans[prefix][1] % len(rows),))
    return rows, edges


def map_entry(pc):
    if pc is None or pc < 39:
        return pc
    if pc == 39:
        return 39
    if 50 <= pc <= 2848:
        return pc - 11
    assert pc > 2848
    return pc - 10


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("parent", type=Path, help="NF178 verification ZIP or extracted source.sites.json")
    parser.add_argument("source", type=Path)
    parser.add_argument("table", type=Path)
    args = parser.parse_args()
    if zipfile.is_zipfile(args.parent):
        with zipfile.ZipFile(args.parent) as archive:
            parent = archive.read("source.sites.json")
    else:
        parent = args.parent.read_bytes()
    new = args.source.read_bytes()
    raw = args.table.read_bytes()
    assert digest(parent) == PARENT_SOURCE and digest(new) == NEW_SOURCE and digest(raw) == NEW_TABLE
    old, prev = instructions(parent)
    rows, nexts = instructions(new)
    assert (len(old), len(rows)) == (2970, 2960)
    matched = 0
    for i, (_, op, arg) in enumerate(old):
        if 39 <= i < 50 or i == 2848:
            continue
        j = map_entry(i)
        assert rows[j][1:] == [op, arg]
        assert nexts[j] == tuple(map_entry(t) for t in prev[i])
        matched += 1
    assert matched == 2958
    assert [r[1:] for r in rows[42:2837]] == [r[1:] for r in old[53:2848]]
    for i, op, k, targets in [
        (38, "CD", 3, (39, 2839)),
        (39, "CD", 6, (40, 42)),
        (40, "CI", 5, (41,)),
        (41, "CC", 2, (39,)),
        (2837, "CD", 5, (2838, 2839)),
        (2838, "CC", 3, (38,)),
    ]:
        assert rows[i][1:] == [op, k] and nexts[i] == targets
    header, *body = raw.decode().splitlines()
    assert header == "#! start k:74"
    table = {}
    for line in body:
        q, b, w, direction, dest = line.split()
        assert b in {"0", "1"} and w in {"0", "1"} and direction in {"L", "R"}
        assert (q, b) not in table and q != "halt"
        table[q, b] = dest
    reachable = set()
    todo = ["k:74"]
    while todo:
        q = todo.pop()
        if q != "halt" and q not in reachable:
            reachable.add(q)
            todo.extend((table[q, "0"], table[q, "1"]))
    assert len(body) == len(table) == 354 and len(reachable) == 177
    assert reachable == {q for q, _ in table} and "halt" in table.values()
    print("177 reachable states and 354 transitions. The source has 2,960 instruction sites.")
    print("Verified against the released pure-NF source: all 2,958 retained operations and all their control successors agree under relocation.")
    print("All 2,795 pure-NF axiom-emission instructions agree. The new batch-end decrement at 2837 exits on zero and otherwise returns via 2838 to the rank counter at 38.")


if __name__ == "__main__":
    main()
