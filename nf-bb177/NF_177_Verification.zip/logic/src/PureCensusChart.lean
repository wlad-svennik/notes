import PureCensus
import Moving186NF

set_option maxHeartbeats 1800000
namespace PureCensus
open NF192 NF192.Ground NF192.Numerical NF192.Emitter

def separatingSignature : Signature Nat where
  q := q
  app := app
  h := fun a b => if b = 0 then witness b a else witness a b

private theorem diagonal (x : Nat) : separatingSignature.k x = witness x x := by
  simp [Signature.k,separatingSignature]

theorem repairedRows {r : Nat → Nat → Prop} (hr : RowsHold r) :
    VariableMarkerNF.Rows separatingSignature r := by
  have rows (a b c : Nat) {x : Nat} (h : x ∈ rowList a b c 0) := hr a b c 0 (Nat.zero_le _) x h
  have hcon (a b : Nat) := rows a b 0 (x:=row4 a b) (by simp [rowList])
  have heuc (a b c : Nat) := rows a b c (x:=row6 a b c) (by simp [rowList])
  have harg (a b c : Nat) := rows a b c (x:=row2 a b c) (by simp [rowList])
  have hfun (a b c : Nat) := rows a b c (x:=row3 a b c) (by simp [rowList])
  have habs (a b c : Nat) := rows a b c (x:=bRow a b c) (by simp [rowList])
  have htest (a b : Nat) := rows a b 0 (x:=testRow b a) (by simp [rowList])
  have hext (a b : Nat) (hb : b ≠ 0) := rows a b 0 (x:=row9 a b) (by simp [rowList,hb])
  simp only [row4,row6,row2,row3,bRow,testRow,single,row9,evaluate_imp,evaluate_eqn] at hcon heuc harg hfun habs htest hext
  have refl_ (a : Nat) : r a a := heuc _ a a (hcon 0 a) (hcon 0 a)
  have symm_ {a b : Nat} (h : r a b) : r b a := heuc a a b (refl_ a) h
  constructor
  · exact harg
  · intro a b
    change r (app (separatingSignature.k b) a) b
    rw [diagonal]
    exact hcon a b
  · exact hfun
  · intro a b c
    change r (app (app (app s c) a) b) (app (app c (separatingSignature.k b)) (app a b))
    rw [diagonal]
    exact habs a b c
  · exact heuc
  · intro x y
    simpa only [separatingSignature,Signature.k,ite_self] using htest y x
  · intro a b h
    by_cases hb : b = 0
    · subst b
      by_cases ha : a = 0
      · subst a; exact refl_ 0
      · apply symm_
        apply hext 0 a ha
        apply symm_
        simpa [separatingSignature] using h
    · apply hext a b hb
      simpa only [separatingSignature,if_neg hb] using h

theorem chart_of_no_goal (h : ¬ Deriv goal) : ∃ M : Type, Nonempty (VariableMarkerNF.Marked M) := by
  obtain ⟨r,hr,hg⟩ := not_deriv_iff_ground_model.mp h
  let R := repairedRows hr
  exact ⟨R.Carrier,⟨R.toMarked hg⟩⟩

theorem full_of_census {x : Nat} (d : Deriv x) : Moving186.Deriv x := by
  induction d with
  | @row a b c u x hu mem =>
    apply Moving186.Deriv.row (a:=a) (b:=b) (c:=c) (u:=u) hu
    by_cases h : b = 0 <;>
      simp [rowList,Moving186.rowList,bRow,Moving186.bRow,testRow,Moving186.testRow,single,Moving186.single,h] at mem ⊢ <;> tauto
  | mp _ _ m n => exact .mp m n

theorem goal_iff_full : Deriv goal ↔ Moving186.Deriv goal := by
  refine ⟨full_of_census,?_⟩
  intro full
  by_contra empty
  exact Moving186.not_deriv_iff_ground_model.mpr (Moving186.ground_model_iff_chart.mpr (chart_of_no_goal empty)) full

open FFL FFL.FirstOrder

theorem goal_iff_nf_refutation : Deriv goal ↔ (𝗡𝗙 ⊢ ⊥) :=
  goal_iff_full.trans Moving186.deriv_goal_iff_nf_refutation

end PureCensus
#print axioms PureCensus.goal_iff_full

#print axioms PureCensus.goal_iff_nf_refutation
