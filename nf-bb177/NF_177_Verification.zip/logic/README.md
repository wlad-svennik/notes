# Pure NF calibration for the 177-state machine

Lean checks `PureCensus.goal_iff_nf_refutation`, the equivalence between derivability of numerical goal 3 in the reduced eight-row calculus and derivability of falsity in Quine’s pure New Foundations. The intermediate theorem `PureCensus.goal_iff_full` identifies goal derivability with the parent machine’s eight-row calculus. `PureCensus.repairedRows` supplies the missing orientation of extensionality when the second coordinate is zero, using equality symmetry and the retained opposite orientation.

`source_argument.md` gives the standard-natural argument connecting the signed source program to the reduced calculus. The binary startup and universal instruction checks are supplied elsewhere in the enclosing archive. The Lean endpoints in this directory concern the calculus. The source-to-calculus proof also uses the mathematical argument in that document.

## Replay

Run from this directory on Linux or macOS with Python 3.11 or later. The 187 project modules under `src` have a complete project-level import closure. The lockfiles under `environment` specify Lean 4.35.0 and mathlib revision `56a005855ea17e0b0958f73ec801ae140b0a1679`. With `elan` installed and access to the dependencies listed in the Lake manifest, provision the external packages and invoke the replay under Lake.

```sh
cd environment
lake exe cache get
lake env python3 ../replay.py --build ../.replay --check-manifest --jobs 4
```

If the external Lean toolchain and mathlib libraries are already available on `PATH` and `LEAN_PATH`, run directly from this directory.

```sh
python3 replay.py --build .replay --check-manifest --jobs 4
```

An existing verified object cache from the 186-state counting release can supply 175 byte-identical shared dependencies. Point to the directory containing its compiled `.olean` files.

```sh
python3 replay.py --build .replay --check-manifest --jobs 4 --parent-cache /path/to/186/objects
```

The verifier checks the source hashes and dependency graph against `sources.json`. It authenticates eligible parent objects against `parent-cache.json` and recompiles any missing or mismatched objects. The external toolchain and library fingerprints also participate in each cache key. `--clean` rebuilds all bundled project modules. A successful run writes `receipt.json` in the chosen build directory.

## Contents

| Module | Result |
| --- | --- |
| `PureCensus` | A nonderivation of goal 3 yields a ground countermodel satisfying all reduced rows. |
| `PureCensusChart` | The reduced calculus derives goal 3 exactly when pure NF proves falsity. |
| `Moving186NF` | The predecessor’s marked chart calibrates its eight-row calculus to pure NF. |
| `CensusSelector` | The selected batch reaches the prescribed parameter and cleanup lowers a positive carry. |
| `EpochBounds` | The penultimate marker meets the growth and cache bounds used in synchronization. |
| `PureWordAudit` | AX produces sound formulas in the parent calculus. Exact stack operations select all the required axiom families. Proof words admit any prescribed continuation. |
| `GlobalBudget` | Bounds the cumulative rank and provides an explicit sufficiently large epoch. |
| `CursorStep`, `PhaseCases`, `PhaseRealization`, `PhaseExhaustion` and `MarkerReplay` | Translate the finite case check into a statement about numerical Cantor cursors, including early batch exits and crossing a pairing diagonal. |
| `MarkerArithmetic` and `MarkerEnumeration` | The Cantor decoding and predecessor alternatives used in the synchronization argument hold. |

`receipts` contains the original calculus replay, the expanded replay, and Lean reports for the proof-word and cursor theorems. The reports list each endpoint’s axioms.
