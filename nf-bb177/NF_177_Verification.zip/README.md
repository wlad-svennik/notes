# A 177-state binary Turing machine for pure NF

R. Gutin and E. Glazer

Run `candidate.tm` from `k:74` on a blank, two-way infinite binary tape. It halts exactly when Quine’s New Foundations proves a contradiction. This is the ordinary blank-tape halting claim. The argument combines kernel-checked results with a written proof that the encoded search reaches every required refutation.

## Where the state went

The 178-state pure-NF register program read two additional fields for each batch of eight axioms. The new program reads one field and counts down the stored proof code to supply the other parameter. This is the change used for the 186-state NF + AxCount machine. It shortens the pure-NF program from 2,970 instructions to 2,960. The first compilation still takes 178 binary states and is included as `Intermediate178.tm`.

In that compilation, `aux:new:1` and `rg-fresh:841041b200ff` can share a single state. On zero it writes zero, moves right and enters `a:CD:5`. On one it writes zero, moves left and enters `k:10`. Redirecting the incoming edges and using those two transitions gives exactly the supplied 177-state table. The quick verifier reconstructs this last change and compares every row.

## What was checked

* Every working state is reachable in the transition graph. The table has 354 transitions. Its only halt arm is `k:302` reading one.
* Beginning on blank tape, the table reaches instruction 0 with counter 3 and eight zero registers at step 74,071. The full tape configuration at this point and an earlier checkpoint are checked in Lean.
* The physical instruction certificate has 7,766 signed branch cases and 20 induction rules for arbitrary field lengths. A separate finite screen runs 11,840 concrete cases against the literal table.
* `check_source.py` compares the new register code with the published 178-state source. The 2,795 instructions that emit the pure NF axioms agree under relocation.
* `PureCensus.goal_iff_nf_refutation` identifies derivability of code 3 in the reduced calculus with a refutation in pure NF. The written source-to-calculus argument uses six nips per reset sweep and preserves the counting machine’s numerical marker. The Lean theorem `NF180Counting.CensusMarker.two_predecessors` checks that the six-command prefix either aligns the numerical cursor or leaves the required rank and cache for the next epoch. The module `PureWordAudit` checks the reset, axiom extraction and assembly operations used by a fixed proof word. See [the source argument](logic/source_argument.md) and [the synchronization proof](search/MarkerProof.md).

The independent checker `check_binding.py` compares every transition with the startup theorem’s table, replays the complete blank configurations, and compares all 3,884 warm instruction statements against the source register operations and tape layouts. Each nonterminal branch ends at a live warm frame. The exterior rays are blank and the address gap and spare capacity never decrease. Halting persists, so a branch with a live endpoint could not have halted earlier. The positive branch durations cover every finite physical time along an infinite register computation.

The literal machine criterion follows by putting these results together. The correspondence between the two tape representations, the interpretation of the retained register blocks as proof commands and the induction constructing a full detecting word are set out as ordinary mathematical arguments. Each cited Lean theorem has the scope given above.

The earlier pure-NF source and mathematical calibration are available in the [178-state release](https://github.com/wlad-svennik/notes/tree/main/nf-bb178).

## Replay

Run `python3 check.py` in the extracted directory for the fast check. To rebuild the 7,766 physical proof cases and the blank-tape proof, put Lean 4.35.0 and `leanchecker-paranoid` on PATH and run `python3 check.py --kernel`. The arithmetic of the scanner marker uses Lean and Init only. From `search/` set `LEAN_PATH=.` and compile `NumericalCodes`, `MarkerArithmetic`, `MarkerEnumeration`, `EpochBounds`, and `GlobalBudget` in that order. The pure NF theorem has separate replay instructions in `logic/`.

To screen further candidates cheaply, compile the fixture runner once and reuse it:

```
c++ -O2 -std=c++17 screen/probe.cpp -o probe
python3 screen.py candidate.tm source.sites.json --probe ./probe
```

Binary table SHA-256: `a4968d492f38586a33882f80869a2f1a8e0628eeb6b3284fdfc02a22ec8a59df`.
