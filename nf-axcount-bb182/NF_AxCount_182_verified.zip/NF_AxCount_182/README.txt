NF + FULL AXIOM OF COUNTING: VERIFIED 182-STATE REDUCTION
R. Gutin and E. Glazer
25 November 2026

Result
------
The literal binary machine in machine/candidate.tm has 182 working states
and a separate halt state. It uses a two-way infinite tape, blank symbol 0,
start state k:74, and 364 transition rows. It implements the unchanged
3,397-site proof-enumeration program of the 183-state release.

The reduction redirects two transitions and removes d:39. It is justified
by 30 universally verified transfer-loop rotations and one borrowed
increment, with independently proved source-entry guards. See
Reduction_proof.txt for the complete mathematical explanation and the
precise inherited NF+full-AxCount calibration scope.

Reproduce
---------
From this directory:

    python3 verify.py

This checks the exact rebuild from the 183-state release, independently
replays all 4,485 unbounded phase domains and the exact blank startup,
regenerates the trace byte-for-byte, recomputes the source invariant,
checks every phase endpoint/domain formula, and freshly regenerates and
kernel-checks16 arithmetic induction theorems.

To additionally regenerate and freshly kernel-check all physical phase
proofs and every blank-start transition:

    python3 verify.py --kernel

Python's standard library and the included Linux kernel executable suffice.
No Lean frontend, Mathlib installation, network, or compiler is needed.
An explicit matching checker can be supplied with --checker PATH. The
checker is authenticated by SHA-256. --jobs controls physical kernel replay
parallelism; default 2. Replay outputs are temporary. --output PATH saves
the final verification receipt.

Files
-----
machine/                  Literal table, unchanged source, phase trace,
                          exact boot and independent physical receipts.
rebuild.py                Exact byte-bound183-to -182 reconstruction,
                          including the authenticated earlier rebuild.
audit/                    Independent physical checker, separate trace
                          producer, row coverage and deterministic replay.
source/                   Two independently checked outer invariants,
                          literal CFG/ingress audit and phase-interface check.
arithmetic/               Sixteen Nat.rec induction theorems, raw export,
                          independent source binding and portable kernel replay.
kernel/                   Full physical proof-term generators, fresh71-part
                          phase receipt,34-part boot receipt and checker.
reference/NF_AxCount_183/  Complete prior release and inherited mathematical
                          calibration documents and uploaded proof adapters.
Reduction_proof.txt       Written loop induction and whole-program composition.
Novelty_check.txt         Dated public-record search and its limits.
MANIFEST.json             SHA-256 for every frozen release file.

Verification figures
--------------------
Working states                              182
Binary transition rows                      364
Source instructions, unchanged              3,397
Ordinary natural input domains              4,334
Guarded rotated-loop domains                  150
Borrowed-jump domain                            1
Total unbounded physical domains            4,485
Independently checked one-unit pump laws        20
Literal symbolic transitions checked    2,151,725
Pump applications                         105,694
Word rotations                              1,119
Transition rows covered                       364 / 364
Exact blank-start transitions              67,998
Fresh physical kernel theorem batches          71
Fresh blank-start kernel segments              34
Fresh arithmetic induction theorems             16
Rotated source transfer loops                  30
Borrowed source transfer loop                   1
Closed loops in the source analysis           791
Reachable outer analysis vertices           1,565
Inductive nonhalting source images          1,832

Blank startup reaches source PC0 with R1=1 and the other eight registers 0,
frame head -4, gap 55, and 30 zero spare fields. Every marked tape cell is
checked. The entire blank run was also replayed in the standalone kernel.

Identity
--------
Table SHA-256:
  d99fe0163acc608b1bed679e9c72a941bd05d37c285e6db0a12cb111eca25e7b
Source SHA-256:
  222bb33545c28307c2a358760ed9857f6897d43ef1bae010919a0abca7e2b8f4
Trace SHA-256:
  524d0c803171630be065173596b3a199eca8d795b9acb58327345dfae993918f
Kernel executable SHA-256:
  cd9a6ddb5fbf8f649c789dc905236e1ddee9fb32a323c141a4e63478f72e47b6

Proof scope
-----------
The new implementation reduction has fresh unbounded physical checks,
source invariants, arithmetic induction, exact startup, and independent
reproduction. It preserves the source and its full internal counting law.

The whole-program composition is explicitly written and supported by these
components. The inherited designated full-chart construction and complete
numerical proof-enumeration/model comparison retain their written status.
The package does not claim a single end-to-end Lean theorem from the NF
axioms to the halting behavior of this table. The complete inherited
qualification is in
reference/NF_AxCount_183/proof_connection/Calibration_Audit.txt.

The earlier physical/kernel proofs and the uploaded interpretation reports
are preserved with their original provenance. Historical reports are not
relabeled as fresh replays of their full dependency closure.

The finite discovery receipt is historical search evidence. It is not the
admission criterion. The complete unbounded and source checks listed above
are what establish the reduction. No global lower bound on state count or
claim that 181 states are impossible is made.
