"""Independent, standard-library check of the outer-loop invariant artifact.

No producer, imported CFG, or abstract-analysis implementation is used.
"""
from pathlib import Path
import argparse,hashlib,json

def main():
    ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('invariant',type=Path);ap.add_argument('--receipt',type=Path);a=ap.parse_args()
    raw=a.source.read_bytes();s=json.loads(raw);r=json.loads(a.invariant.read_bytes());assert hashlib.sha256(raw).hexdigest()==r['source_sha256']
    paths=[x[0] for x in s];assert paths==sorted(set(paths));n=len(s);pc={p:i for i,p in enumerate(paths)}
    nodes=set()
    for p in paths:
        assert set(p)<=set('01')
        nodes.update(p[:k] for k in range(len(p)+1))
    for p in nodes:
        if p in pc:assert p+'0' not in nodes and p+'1' not in nodes
        else:assert p+'0' in nodes and p+'1' in nodes
    def first(p):
        while p not in pc:
            assert p in nodes;p+='0'
        return pc[p]
    def advance(p):
        k=p.rfind('0')
        return ('',1) if k<0 else (p[:k]+'1',0)
    def cut(p,side,k):
        for _ in range(k):
            j=p.rfind(side);assert j>=0;p=p[:j]
        return p
    edges={}
    for i,(p,op,k) in enumerate(s):
        assert op in ('CI','CD','CC','CB')
        if op in ('CI','CD'):q,w=advance(p);edges[i,False]=(first(q),w)
        elif op=='CC':edges[i,False]=(first(cut(p,'1',k)),0)
        else:q,w=advance(cut(p,'0',k));edges[i,False]=(first(q),w)
        if op=='CD':
            if p.endswith('1'):edges[i,True]=None
            else:q,w=advance(cut(p,'0',1));edges[i,True]=(first(q),w)
    loops=r['loops'];heads={m['head']:m for m in loops};assert len(heads)==len(loops)
    interiors=set();covered=set()
    for m in loops:
        h=m['head'];end=h+m['span'];donor=m['donor'];dest=m['destinations']
        assert donor not in dest and m['span']==len(dest)+2
        assert s[h][1:]==['CD',donor] and [s[i][1:] for i in range(h+1,end-1)]==[['CI',j] for j in dest] and s[end-1][1]=='CC'
        assert edges[h,False]==(h+1,0) and edges[h,True]==(end%n,int(end==n)) and edges[end-1,False]==(h,0)
        assert all(edges[i,False]==(i+1,0) for i in range(h+1,end-1))
        assert m['exit']==end%n and m['wrap']==int(end==n)
        assert all(e is None or not(h<e[0]<end) or h<=i<end for (i,z),e in edges.items())
        assert covered.isdisjoint(range(h,end));covered.update(range(h,end));interiors.update(range(h+1,end))
    threshold=r['threshold'];assert isinstance(threshold,int) and threshold>0
    values=r['values'];assert len(values)==n
    def atoms(mask):
        assert isinstance(mask,int) and 0<mask<(1<<(threshold+1))
        return {i for i in range(threshold+1) if (mask>>i)&1}
    vv=[None if v is None else [atoms(m) for m in v] for v in values]
    assert len(vv[0])==9 and all((1 if j==1 else 0) in vv[0][j] for j in range(9))
    checks=0;zero_dest=0
    for i,v in enumerate(vv):
        if v is None:continue
        assert i not in interiors and len(v)==9
        images=[]
        if i in heads:
            m=heads[i];donor=m['donor'];out=[set(x) for x in v]
            for target in set(m['destinations']):
                multiplicity=m['destinations'].count(target)
                out[target]={min(threshold,x+multiplicity*y) for x in v[target] for y in v[donor]}
            out[donor]={0};images.append((m['exit'],out))
            assert m['entry_masks']==values[i]
            guard=all(v[j]=={0} for j in m['destinations']);assert m['destinations_zero']==guard;zero_dest+=guard
        else:
            _,op,k=s[i]
            if op in ('CC','CB'):images.append((edges[i,False][0],v))
            elif op=='CI':
                out=[set(x) for x in v];out[k]={min(threshold,x+1) for x in v[k]};images.append((edges[i,False][0],out))
            else:
                if 0 in v[k] and edges[i,True] is not None:
                    out=[set(x) for x in v];out[k]={0};images.append((edges[i,True][0],out))
                positive=v[k]-{0}
                if positive:
                    out=[set(x) for x in v];out[k]=set()
                    for x in positive:out[k].update({threshold-1,threshold} if x==threshold else {x-1})
                    images.append((edges[i,False][0],out))
        for dest,out in images:
            assert vv[dest] is not None and all(x<=y for x,y in zip(out,vv[dest]));checks+=1
    assert checks==r['inductive_edges'] and zero_dest==r['zero_destination_loops']
    receipt={'status':'PASS','source_sha256':hashlib.sha256(raw).hexdigest(),'invariant_sha256':hashlib.sha256(a.invariant.read_bytes()).hexdigest(),'source_sites':n,'closed_loops':len(loops),'outer_vertices':sum(v is not None for v in vv),'inductive_images':checks,'zero_destination_loops':zero_dest,'scope':'Independent literal CFG, closed-loop pattern and ingress, initial inclusion, and unbounded threshold-class inductiveness.'}
    if a.receipt:a.receipt.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__':main()
