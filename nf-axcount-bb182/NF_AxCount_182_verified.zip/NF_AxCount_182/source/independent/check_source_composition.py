"""Independent literal source, ingress, outer invariant, and startup audit.

Standard library only. No imported generator, CFG, phase interpreter, or
symbolic-trace implementation is used. Physical phase behavior is a separate
certificate; this audit establishes the source-side hypotheses for composition.
"""
from pathlib import Path
from collections import deque,Counter
import argparse,hashlib,json

EXPECTED_HEADS=(281,427,453,558,636,792,1018,1167,1439,1517,1543,1648,1778,1934,2141,2219,2341,2367,2498,2569,2595,2674,2726,2829,2906,2958,3089,3220,3374,3394)
BORROW=3334
SOURCE_SHA='222bb33545c28307c2a358760ed9857f6897d43ef1bae010919a0abca7e2b8f4'
TABLE_SHA='d99fe0163acc608b1bed679e9c72a941bd05d37c285e6db0a12cb111eca25e7b'
BASELINE_SHA='bb6603f5a5e9848c3125ce1c861ff5f6bbdb3db383bdbc65ad487fba1feb0b52'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def table(path):
 text=Path(path).read_text().splitlines();assert text[0].startswith('#! start ')
 start=text[0].split()[-1];out={}
 for l in text[1:]:
  q,b,w,d,j=l.split();b=int(b);w=int(w);assert b in (0,1)and w in(0,1)and d in('L','R');assert(q,b)not in out
  out[q,b]=(w,1 if d=='R'else -1,j)
 states={q for q,b in out};assert len(out)==2*len(states)and all((q,b)in out for q in states for b in(0,1))
 assert all(j=='halt'or j in states for w,d,j in out.values())and start in states
 reached={start};todo=[start]
 while todo:
  q=todo.pop()
  for b in(0,1):
   j=out[q,b][2]
   if j!='halt'and j not in reached:reached.add(j);todo.append(j)
 assert reached==states
 return start,out,states

def source_flow(rows):
 n=len(rows);words=[x[0]for x in rows];assert words==sorted(set(words))
 spans={}
 for i,w in enumerate(words):
  assert w and set(w)<=set('01')
  for k in range(len(w)+1):
   p=w[:k]
   if p not in spans:spans[p]=[i,i+1]
   else:spans[p][1]=i+1
 leaves=set(words)
 for p in spans:
  assert(p+'0'in spans)==(p+'1'in spans)==(p not in leaves)
 def delete(p,bit,count):
  for _ in range(count):
   at=p.rfind(bit);assert at>=0;p=p[:at]
  return p
 edges={}
 for i,(p,op,k)in enumerate(rows):
  assert op in('CI','CD','CC','CB')and isinstance(k,int)
  if op in('CI','CD'):edges[i,False]=((i+1)%n,int(i+1==n))
  elif op=='CC':assert 1<=k;edges[i,False]=(spans[delete(p,'1',k)][0],0)
  else:
   assert 1<=k;right=spans[delete(p,'0',k)][1];edges[i,False]=(right%n,int(right==n))
  if op=='CD':
   assert 0<=k<9
   if p.endswith('1'):edges[i,True]=None
   else:right=spans[delete(p,'0',1)][1];edges[i,True]=(right%n,int(right==n))
  if op=='CI':assert 0<=k<9
 return edges

def loops_from_source(rows,edges):
 n=len(rows);incoming=[[]for _ in rows]
 for (pc,z),e in edges.items():
  if e is not None:incoming[e[0]].append((pc,z,e[1]))
 loops=[];occupied=set()
 for h,(_,op,donor)in enumerate(rows):
  if op!='CD':continue
  end=h+1;receivers=[]
  while end<n and rows[end][1]=='CI':receivers.append(rows[end][2]);end+=1
  if end>=n or rows[end][1]!='CC'or donor in receivers:continue
  if edges[h,False]!=(h+1,0)or edges[h,True]!=((end+1)%n,int(end+1==n))or edges[end,False]!=(h,0):continue
  if any(edges[j,False]!=(j+1,0)for j in range(h+1,end)):continue
  if any(not h<=p<=end for j in range(h+1,end+1)for p,z,w in incoming[j]):continue
  block=set(range(h,end+1));assert not(block&occupied);occupied|=block
  loops.append({'head':h,'end':end,'donor':donor,'receivers':receivers,'exit':(end+1)%n,'wrap':int(end+1==n)})
 return loops,incoming

def abstract_invariant(rows,edges,loops,threshold):
 n=len(rows);heads={m['head']:m for m in loops};interiors={j for m in loops for j in range(m['head']+1,m['end']+1)}
 # Atom t is the whole unbounded interval [t,infinity), not a test value.
 atoms=lambda bits:[i for i in range(threshold+1)if bits&(1<<i)]
 def encode(vals):
  z=0
  for x in vals:z|=1<<x
  return z
 def increase(bits):return encode(min(threshold,x+1)for x in atoms(bits))
 def decrease(bits):
  out=set()
  for x in atoms(bits):
   if not x:continue
   out.update((threshold-1,threshold)if x==threshold else(x-1,))
  return encode(out)
 def add(a,b,k):return encode(min(threshold,x+k*y)for x in atoms(a)for y in atoms(b))
 def successors(pc,v):
  if pc in heads:
   m=heads[pc];out=list(v)
   for r,multiplicity in Counter(m['receivers']).items():out[r]=add(v[r],v[m['donor']],multiplicity)
   out[m['donor']]=1
   yield m['exit'],tuple(out)
   return
  p,op,k=rows[pc]
  if op in('CB','CC'):yield edges[pc,False][0],v
  elif op=='CI':
   out=list(v);out[k]=increase(v[k]);yield edges[pc,False][0],tuple(out)
  else:
   if v[k]&1 and edges[pc,True]is not None:
    out=list(v);out[k]=1;yield edges[pc,True][0],tuple(out)
   if v[k]&~1:
    out=list(v);out[k]=decrease(v[k]);yield edges[pc,False][0],tuple(out)
 values=[None]*n;values[0]=tuple(2 if r==1 else 1 for r in range(9));pending=deque([0]);scheduled={0}
 while pending:
  pc=pending.popleft();scheduled.remove(pc);assert pc not in interiors
  for dest,image in successors(pc,values[pc]):
   assert dest not in interiors
   new=image if values[dest]is None else tuple(x|y for x,y in zip(values[dest],image))
   if new!=values[dest]:
    values[dest]=new
    if dest not in scheduled:pending.append(dest);scheduled.add(dest)
 checks=0
 for pc,v in enumerate(values):
  if v is None:continue
  assert pc not in interiors
  for dest,image in successors(pc,v):assert values[dest]is not None and all((x&~y)==0 for x,y in zip(image,values[dest]));checks+=1
 assert all(values[0][r]&(2 if r==1 else 1)for r in range(9))
 return values,checks

def blank(start,t,source,steps,expected):
 q=start;h=0;ones=set()
 for tick in range(steps):
  assert q!='halt',('premature halt',tick)
  b=int(h in ones);w,d,q=t[q,b]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d
 assert q=='d:0'
 gap=55;spares=30;want={h-1};p=source[0][0]
 want.update(h+i for i,b in enumerate(p)if b=='1');want.add(h+gap);pos=h+gap+2
 for r in(2,8,1,4,3,7,0,5,6):
  want.update(range(pos,pos+expected[r]+2));pos+=expected[r]+3
 for _ in range(spares):want.add(pos);pos+=2
 assert ones==want
 return {'status':'PASS','steps':steps,'control':q,'head':h,'gap':gap,'spares':spares,'registers':expected,'ones_count':len(ones),'table_sha256':TABLE_SHA}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--candidate-dir',type=Path,required=True);ap.add_argument('--baseline-table',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--threshold',type=int,default=2);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 C=a.candidate_dir;assert sha(C/'candidate.tm')==TABLE_SHA and sha(C/'source.sites.json')==SOURCE_SHA and sha(a.baseline_table)==BASELINE_SHA
 start,t,states=table(C/'candidate.tm');bs,bt,bstate=table(a.baseline_table);assert start==bs=='k:74'and len(states)==182 and len(bstate)==183 and bstate-states=={'d:39'}
 changes={k:(bt[k],v)for k,v in t.items()if bt[k]!=v}
 assert changes=={('d:163',1):((1,1,'d:39'),(1,1,'d:17')),('d:79',1):((1,1,'d:39'),(1,1,'d:160'))}
 rows=json.loads((C/'source.sites.json').read_bytes());edges=source_flow(rows);loops,incoming=loops_from_source(rows,edges);values,checks=abstract_invariant(rows,edges,loops,a.threshold)
 targets=[m for m in loops if m['donor']==3 and m['receivers']==[4]];assert [m['head']for m in targets]==sorted([*EXPECTED_HEADS,BORROW])
 assert len(loops)==791 and checks==1832 and sum(x is not None for x in values)==1565
 evidence=[]
 for m in targets:
  h=m['head'];assert m['end']==h+2
  external={j:[p for p,z,w in incoming[j]if not h<=p<=h+2]for j in(h+1,h+2)};assert all(not x for x in external.values())
  masks=values[h];assert masks is not None
  if h!=BORROW:assert masks[4]==1 and masks[7]==1 and masks[1]&1==0,('guard failed',h,masks)
  else:assert rows[h-1][1:]==['CI',4]and edges[h-1,False]==(h,0)and masks[4]==2 and masks[7]==1 and masks[1]&1==0
  evidence.append(m|{'entry_masks':masks,'external_interior_ingress':external,'head_ingress':incoming[h],'kind':'borrow'if h==BORROW else'rotated'})
 inv={'source_sha256':SOURCE_SHA,'threshold':a.threshold,'atom_meaning':'singleton 0..t-1; final atom all naturals >=t','values':values,'loops':loops,'inductive_images':checks,'initial_registers':[0,1,0,0,0,0,0,0,0]};(a.out/'outer-invariant-independent.json').write_text(json.dumps(inv,indent=2)+'\n')
 b=blank(start,t,rows,67998,[0,1,0,0,0,0,0,0,0]);(a.out/'blank-audit.json').write_text(json.dumps(b,indent=2)+'\n')
 receipt={'status':'PASS_SOURCE_STRUCTURE_INGRESS_GUARDS_AND_STARTUP','source_sha256':SOURCE_SHA,'candidate_sha256':TABLE_SHA,'baseline_sha256':BASELINE_SHA,'working_states':182,'source_sites':len(rows),'independent_closed_loop_summaries':len(loops),'reachable_outer_vertices':sum(v is not None for v in values),'inductive_images':checks,'abstract_threshold':a.threshold,'rotated_loops':len(EXPECTED_HEADS),'borrow_head':BORROW,'guard_summary':{'rotated_outer_R4':0,'rotated_outer_R7':0,'rotated_outer_R1':'>=1','borrow_outer_R4':1},'removed_control':'d:39','changed_transitions':[{'source':q,'symbol':b,'old':old,'new':new}for(q,b),(old,new)in sorted(changes.items())],'loop_evidence':evidence,'startup_receipt':'blank-audit.json','invariant_receipt':'outer-invariant-independent.json','scope':'Source-side structural and inductive proof plus independent exact startup. Physical phase contracts and their unbounded replay/kernel acceptance are separate requirements.'}
 (a.out/'source-audit.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='loop_evidence'},sort_keys=True))
if __name__=='__main__':main()
