"""Reproduce the complete 182-state reduction audit from this directory.

Default: exact rebuild, independent unbounded replay and trace regeneration,
independent source guards and interface, and fresh arithmetic kernel proof.
--kernel additionally regenerates and kernel-checks every physical phase and
every blank-start transition. All replay outputs go to a temporary directory.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from rebuild import rebuilt

ROOT=Path(__file__).resolve().parent


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--kernel',action='store_true')
    p.add_argument('--checker',type=Path)
    p.add_argument('--jobs',type=int,default=2)
    p.add_argument('--output',type=Path)
    a=p.parse_args()
    assert a.jobs>0
    checker=(a.checker or ROOT/'kernel/bin/leanchecker-paranoid').resolve()
    assert checker.exists()
    checker_sha=digest(checker)
    assert checker_sha=='cd9a6ddb5fbf8f649c789dc905236e1ddee9fb32a323c141a4e63478f72e47b6'
    if (ROOT/'MANIFEST.json').exists():
        manifest=json.loads((ROOT/'MANIFEST.json').read_text())
        for name,expected in manifest['files'].items():
            assert digest(ROOT/name)==expected,('changed release file',name)
    raw,source=rebuilt()
    assert raw==(ROOT/'machine/candidate.tm').read_bytes()
    assert source==(ROOT/'machine/source.sites.json').read_bytes()
    for name in ('candidate.tm','source.sites.json','boot.json','traces.gz'):
        assert (ROOT/'audit/inputs'/name).read_bytes()==(ROOT/'machine'/name).read_bytes()
    assert source==(ROOT/'arithmetic/source.sites.json').read_bytes()
    assert (ROOT/'arithmetic/phase_contracts.py').read_bytes()==(ROOT/'kernel/engine/phase_contracts.py').read_bytes()
    env=dict(os.environ,COUNTER_ROLE='1',LEAN_CHECKER=str(checker),PYTHONDONTWRITEBYTECODE='1')
    def run(argv):
        proc=subprocess.run([str(x) for x in argv],env=env,text=True,capture_output=True)
        if proc.returncode:
            raise RuntimeError(('replay failed',argv,proc.stdout,proc.stderr))
        return proc.stdout
    with tempfile.TemporaryDirectory(prefix='nf-axcount182-release-') as temp:
        work=Path(temp)
        shutil.copytree(ROOT/'audit',work/'audit')
        physical=json.loads(run([sys.executable,work/'audit/verify.py']))
        print('PASS: 4,485 unbounded physical domains, exact blank startup, all 364 rows, byte-identical trace regeneration.',flush=True)
        independent=ROOT/'source/independent'
        source_result=json.loads(run([sys.executable,independent/'check_source_composition.py',
            '--candidate-dir',ROOT/'machine','--baseline-table',ROOT/'reference/NF_AxCount_183/machine/candidate.tm',
            '--out',work/'source']))
        for name in ('source-audit.json','outer-invariant-independent.json','blank-audit.json'):
            assert json.loads((work/'source'/name).read_bytes())==json.loads((independent/'results'/name).read_bytes())
        phase_interface=json.loads(run([sys.executable,independent/'check_phase_interface.py',
            '--source',ROOT/'machine/source.sites.json','--phase-spec',ROOT/'kernel/engine/phase_contracts.py',
            '--out',work/'phase-interface.json']))
        assert phase_interface==json.loads((independent/'results/phase-interface-audit.json').read_bytes())
        outer=json.loads(run([sys.executable,ROOT/'source/check_outer_invariant.py',
            ROOT/'machine/source.sites.json',ROOT/'source/outer-invariant.json']))
        print('PASS: independent source CFG, all loop ingress restrictions, all 30 guards, and exact affine phase interface.',flush=True)
        arithmetic=json.loads(run([sys.executable,ROOT/'arithmetic/verify_arithmetic.py']))
        print('PASS: 16 regenerated arithmetic induction theorems accepted by the Lean kernel.',flush=True)
        if a.kernel:
            print('Regenerating and kernel-checking all physical phase proof terms...',flush=True)
            run([sys.executable,ROOT/'kernel/engine/check_all.py',ROOT/'machine',ROOT/'machine/traces.gz',
                 work/'phases.json','--jobs',str(a.jobs),'--chunk','48','--checker',checker])
            assert json.loads((work/'phases.json').read_bytes())==json.loads((ROOT/'kernel/phases.json').read_bytes())
            print('PASS: all 4,485 physical phase theorems freshly accepted.',flush=True)
            run([sys.executable,ROOT/'kernel/boot_segments.py',ROOT/'kernel/engine',ROOT/'machine',
                 work/'boot','--jobs',str(a.jobs),'--segment','2048','--checker',checker])
            assert json.loads((work/'boot/verified.json').read_bytes())==json.loads((ROOT/'kernel/boot/verified.json').read_bytes())
            print('PASS: all 67,998 blank-start transitions freshly accepted in 34 matching kernel segments.',flush=True)
    result={'status':'PASS_VERIFIED_182_STATE_REDUCTION','working_states':182,'binary_rows':364,
            'halt_state_separate':True,'source_sites_unchanged':3397,
            'table_sha256':digest(ROOT/'machine/candidate.tm'),'source_sha256':digest(ROOT/'machine/source.sites.json'),
            'trace_sha256':digest(ROOT/'machine/traces.gz'),'physical_domains':physical['domains'],
            'pumps':physical['pumps'],'boot_steps':physical['boot_steps'],
            'all_rows_covered':physical['all_rows_covered'],'rotated_loops':source_result['rotated_loops'],
            'source_inductive_images':source_result['inductive_images'],
            'arithmetic_kernel_theorems':arithmetic['theorem_count'],
            'fresh_complete_physical_kernel_replay':a.kernel,'kernel_checker_sha256':checker_sha,
            'scope':'Exact implementation reduction preserving the unchanged source and its inherited NF+full AxCount calibration; written whole-program composition and inherited full-chart/model comparison retain their documented scope.'}
    if a.output:a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
