"""Reconstruct the 182-state table from the authenticated 183-state release."""
from collections import deque
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT=Path(__file__).resolve().parent
OLD_SHA='bb6603f5a5e9848c3125ce1c861ff5f6bbdb3db383bdbc65ad487fba1feb0b52'
NEW_SHA='d99fe0163acc608b1bed679e9c72a941bd05d37c285e6db0a12cb111eca25e7b'
SOURCE_SHA='222bb33545c28307c2a358760ed9857f6897d43ef1bae010919a0abca7e2b8f4'


def rebuilt():
    oldroot=ROOT/'reference'/'NF_AxCount_183'
    spec=importlib.util.spec_from_file_location('authenticated183rebuild',oldroot/'rebuild.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    raw,source=module.rebuilt()
    assert raw==(oldroot/'machine'/'candidate.tm').read_bytes()
    assert source==(oldroot/'machine'/'source.sites.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==OLD_SHA
    assert hashlib.sha256(source).hexdigest()==SOURCE_SHA
    rows={}
    for line in raw.decode().splitlines()[1:]:
        q,b,w,d,j=line.split();assert (q,b) not in rows
        rows[q,b]=(w,d,j)
    for edge,target in [(('d:163','1'),'d:17'),(('d:79','1'),'d:160')]:
        assert rows[edge]==('1','R','d:39')
        rows[edge]=('1','R',target)
    assert all(j!='d:39' for edge,(_,_,j) in rows.items() if edge[0]!='d:39')
    del rows['d:39','0'];del rows['d:39','1']
    names={q for q,_ in rows}
    assert len(names)==182 and len(rows)==364
    assert all((q,b) in rows for q in names for b in ('0','1'))
    assert {j for _,_,j in rows.values()}-names=={'halt'}
    seen={'k:74'};queue=deque(seen)
    while queue:
        q=queue.popleft()
        for b in ('0','1'):
            j=rows[q,b][2]
            if j!='halt' and j not in seen:seen.add(j);queue.append(j)
    assert seen==names
    raw=('#! start k:74\n'+''.join(' '.join((*edge,*rows[edge]))+'\n' for edge in sorted(rows))).encode()
    assert hashlib.sha256(raw).hexdigest()==NEW_SHA
    return raw,source


if __name__=='__main__':
    raw,source=rebuilt()
    assert raw==(ROOT/'machine'/'candidate.tm').read_bytes()
    assert source==(ROOT/'machine'/'source.sites.json').read_bytes()
    print(json.dumps({'status':'PASS','working_states':182,'binary_rows':364,
                      'halt_separate':True,'start':'k:74','blank_symbol':0,
                      'table_sha256':NEW_SHA,'source_sha256':SOURCE_SHA,
                      'unchanged_source_sites':3397,'changed_rows':2,'deleted_states':['d:39']},sort_keys=True))
