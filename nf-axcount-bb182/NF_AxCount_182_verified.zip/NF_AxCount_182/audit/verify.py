"""Verify the portable phase audit, including deterministic trace regeneration."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile

HERE=Path(__file__).resolve().parent
manifest=json.loads((HERE/'manifest.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,item in manifest['files'].items():
    assert sha(HERE/name)==item['sha256'],('file hash',name)
saved=json.loads((HERE/'receipts/independent-phase-receipt.json').read_text())
with tempfile.TemporaryDirectory(prefix='nf-axcount182-audit-') as temporary:
    work=Path(temporary)
    for p in(HERE/'inputs').iterdir():
        if p.is_file():shutil.copy2(p,work/p.name)
    replay=subprocess.run([sys.executable,str(HERE/'check_phases.py'),str(work)],
                          capture_output=True,text=True,check=True)
    actual=json.loads(replay.stdout)
    for key,value in saved.items():
        if key!='seconds':assert actual[key]==value,('replay field',key,actual[key],value)
    for name in('phase-edge-coverage.json','all-edge-coverage.json'):
        assert (work/name).read_bytes()==(HERE/'receipts'/name).read_bytes(),name
    regen=work/'regenerated.gz'
    generated=subprocess.run([sys.executable,str(HERE/'generate_phases.py'),str(work),
                              '--out',str(regen)],capture_output=True,text=True,check=True)
    assert sha(regen)==saved['trace_sha256']
    assert regen.read_bytes()==(HERE/'inputs/traces.gz').read_bytes()
receipt={'status':'PASS','checked_manifest_files':len(manifest['files']),
         'states':actual['states'],'domains':actual['domains'],'pumps':actual['pumps'],
         'boot_steps':actual['boot_steps'],'all_rows_covered':actual['used_combined_rows'],
         'trace_regenerated_byte_identically':True,'trace_sha256':actual['trace_sha256'],
         'table_sha256':actual['table_sha256'],'source_sha256':actual['source_sha256']}
(HERE/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
