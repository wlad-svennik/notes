"""Generate all warm physical phase traces for the literal 182-state table.

Trace generation is untrusted. check_phases.py independently reconstructs
every domain and endpoint and replays the emitted literal/pumping actions.
"""
from pathlib import Path
import argparse, gzip, hashlib, importlib.util, json, sys, time

HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('machine',type=Path)
ap.add_argument('--out',type=Path)
a=ap.parse_args()
folder=a.machine.resolve()
out=a.out or folder/'traces.gz'
sys.argv=[sys.argv[0],str(folder)]
sp=importlib.util.spec_from_file_location('physical_phase_engine',HERE/'symbolic_phase_engine.py')
engine=importlib.util.module_from_spec(sp)
sys.modules[sp.name]=engine
sp.loader.exec_module(engine)
import producer_contracts as C
edges=C.structure(engine.sites)
domains=sorted(C.expected_domains(engine.sites))
pumps=[]
pump_index={}
traces=[]
began=time.monotonic()
for index,(pc,mode,zero) in enumerate(domains):
    tr={'pc':pc,'mode':mode,'zero':zero,'cold':False}
    runs,after,dest,wrap,gap,spares=C.shape(engine.sites,edges,tr)
    actions=[]
    result=engine.branch(pc,zero,False,actions,runs,(dest,wrap,after,spares,gap))
    assert result[0] in ('live','halt'),(pc,mode,zero,result)
    instructions=[]
    for act in actions:
        if act[0]=='steps':instructions.append(act[1])
        elif act[0]=='rotate':instructions.append(0)
        else:
            assert act[0]=='pump'
            item=act[1]
            if item not in pump_index:
                pump_index[item]=len(pumps)
                pumps.append(item)
            instructions.append(-1-pump_index[item])
    tr.update(runs=runs,actions=instructions,clock=result[1])
    traces.append(tr)
    if index%250==0:
        print(json.dumps({'domains':len(traces),'total':len(domains),'last':[pc,mode,zero],
                          'seconds':time.monotonic()-began}),flush=True)
cert={'format':'nf-symbolic-phases-v1','table':engine.TABLE_HASH,
      'source':engine.PROGRAM_HASH,'base_gap':engine.GAP,
      'heads':list(C.HEADS),'borrow_head':C.BORROW_HEAD,
      'pumps':[dict(q=q,dir=d,context=c,unit=u,output=v,ticks=n)
               for q,d,c,u,v,n in pumps],'traces':traces}
raw=gzip.compress(json.dumps(cert,separators=(',',':')).encode(),mtime=0)
out.write_bytes(raw)
receipt={'status':'GENERATED_PENDING_INDEPENDENT_REPLAY','domains':len(traces),
         'pumps':len(pumps),'table_sha256':engine.TABLE_HASH,'source_sha256':engine.PROGRAM_HASH,
         'trace_sha256':hashlib.sha256(raw).hexdigest(),'trace':str(out),
         'seconds':time.monotonic()-began}
(out.parent/'phase-generation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
