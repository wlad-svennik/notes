NF + FULL AXIOM OF COUNTING: 182-STATE PHYSICAL PHASE AUDIT
25 November 2026

This folder is a self-contained independent physical audit of the literal
182-working-state binary machine, with a separate halt state. It contains
364 transitions and the unchanged 3,397-instruction counted source.

Table SHA256:
  d99fe0163acc608b1bed679e9c72a941bd05d37c285e6db0a12cb111eca25e7b
Source SHA256:
  222bb33545c28307c2a358760ed9857f6897d43ef1bae010919a0abca7e2b8f4
Trace SHA256:
  524d0c803171630be065173596b3a199eca8d795b9acb58327345dfae993918f

Replay

From this folder, run:

  python3 verify.py

Only Python's standard library is required. The verifier checks every saved
input/code/receipt hash, replays the complete symbolic phase certificate and
exact blank start in a temporary directory, compares both edge-coverage files,
and regenerates the compressed trace byte-for-byte. It does not modify the
saved inputs or receipts. verification.json records the fresh result.

To run the checker directly against the enclosing release's machine folder:

  python3 audit/check_phases.py machine

To regenerate the phase traces in a separate output file:

  python3 audit/generate_phases.py machine --out /tmp/phase-traces.gz

The checker and producer have separate endpoint implementations. The producer
uses producer_contracts.py and symbolic_phase_engine.py. The checker imports
only independent_frames.py, the independent exact dyadic-polynomial tape-ray
checker; it never imports either producer component. It reconstructs every
phase domain and endpoint from the literal source and the specified transfer
transformation. The release's independent Lean-kernel replay is separate.

Physical result

All 4,485 warm phase domains and 20 unbounded pumping rules pass. The replay
contains 2,151,725 literal symbolic steps, 105,694 pump uses and 1,119 justified
word rotations. Exactly one domain is halting. All 364 transition rows occur
in warm symbolic proofs; the blank prefix uses 235 rows. The separate exact
blank execution takes 67,998 steps and reaches source PC 0 with R1=1, all other
registers zero, header gap 55 and 30 spare fields. Its complete final tape is
checked, not just its register values.

phase-edge-coverage.json records the named transition rows used in each
nonordinary phase. all-edge-coverage.json lists warm, blank and combined row
coverage and the empty uncovered-row set. Their hashes are bound by the
manifest and verified on fresh replay.

Why the source interface has phases

Two retained transition targets are changed relative to the 183-state table:

  d:163 /1: 1 R d:39  becomes 1 R d:17
  d:79  /1: 1 R d:39  becomes 1 R d:160

The now-unreachable control d:39 is removed. The resulting machine implements
30 closed R3-to-R4 transfer loops with a deferred increment. Entry CD3 keeps
its ordinary behavior. For positive R3 and empty R4, the following old CI4
address becomes a no-op that advances to the tail. Each positive tail then
increments R4, decrements R3 and repeats at the tail; the zero tail performs
the deferred final increment and exits. Thus n donor units still transfer
exactly, with the same final resources. The last loop's exit wraps to PC 0.

The exceptional head 3334 uses a different already-known phase: PC 3335 is a
no-op returning to the preceding ordinary CI4 at 3333, so PC 3336 is bypassed.
This borrows the same increment body while retaining arbitrary initial R4.

The guarded physical modes are:

  ordinary: all natural registers, with the usual CD zero/positive split;
  entry: R1>0 and R7=0, and R4=0 on the positive donor branch;
  defer: R1>0, R7=0, R4=0;
  tail: R1>0, R7=0, with independent R3 zero/positive cases;
  borrow: all natural registers, no register/resource change, target 3333.

Each symbolic run variable ranges independently over ALL natural numbers.
Every action is either literal transition execution, an independently checked
one-unit pumping rule extended by natural induction, or a valid fixed-word
rotation. Head displacement, positive time, all register fields, the complete
header/spare region and both infinite tape rays are checked at the endpoint.

Scope

This audit establishes the displayed physical phase contracts and exact blank
startup. The source-level proof that the phase guards always hold, the transfer
induction (including the borrowed body and final wrap), and the existing
NF+full-AxCount source/model correspondence are separate release obligations.
The accompanying release supplies those source proofs and fresh kernel checks.
No finite test fixture is used as a substitute for an unbounded phase proof.

The transformation follows the deferred-transfer mechanism in the supplied
NFCS 197 proof body, transported here to the counted source's R3/R4 registers
and combined with the borrowed increment at 3333. The source bytes themselves
are unchanged. This folder does not claim a single end-to-end Lean theorem
connecting the NF model theory to machine halting.
