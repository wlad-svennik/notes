Arithmetic support for the 182-state NF+full AxCount machine

This component proves the new physical transfer phases have the same
arithmetic outputs as the unchanged register source. It does not change
the logical calculus or the NF+full AxCount model bridge.

Contents:
- RotatedTransfer_Proof.txt: natural induction, exact resource counts, and
  the source3334 borrow explanation.
- generate.py, rotated_transfer.ndjson/json, check.py, receipt.json:
  sixteen freshly accepted Nat.rec theorems, with all recursive arithmetic
  definitions explicit and no extra arithmetic axioms.
- check_source.py, source.sites.json, phase_contracts.py, source_receipt.json:
  independent source CFG reconstruction and154 exact affine phase checks;
  thirty rotated transfers, one arbitrary-destination borrow, one wrap.
- verify_arithmetic.py, manifest.json: read-only portable regeneration,
  hash verification, phase audit and Lean reference-kernel replay.

Replay after integration as NF_AxCount_182/arithmetic:

  python arithmetic/verify_arithmetic.py

The checker is found at ../kernel/bin/leanchecker-paranoid relative to
this directory. For a standalone copy, set LEAN_CHECKER to the exact
checker binary; its SHA-256 is enforced. A local leanchecker-paranoid
is also accepted as fallback. Python3.12 and the checker are sufficient;
no Lean frontend, network, solver, or native build is required.

The arithmetic proof is uniform for every natural donor and destination.
The physical admission still has to recognize the stated phases on the
actual binary table and establish guarded phase entries; those are the
separate physical/source certificates in the complete release.
