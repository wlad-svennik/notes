Twenty-four equivalent shorter Counting rows: source-only groundwork

This directory preserves the source transformations and the exact limited
pricing attempts. None of these new rows is in the verified 183-state table.

The representative row is Fa=b -> (Fb)T=b, with F=TT. Its numerical word is
Z1AI1BI1Z1BI1ZI1BI1I, using 20 macro tokens versus the incumbent's 22.
The 24 forms permute distinct coordinates A,B,C and independently reverse
the premise and conclusion equalities. Their algebraic equivalence proofs
are supplied elsewhere in the consolidated deliverable by the theory audit.

Generation and source checking
-----------------------------
From the release root, run:

  python3 counting_row_sources/build_graph_rows.py counting_row_sources/generated

This reads only the included reference/AxCount184 files. It reconstructs
the incumbent macro syntax tree, substitutes each row, removes two macro
leaves and contracts unary tree nodes. It rechecks every complete macro's
local control flow against the reference vocabulary, parses the complete
new emitter word, and checks all 162 exterior instructions and exits.
It then applies the same register permutation as the verified 183 machine.

Each generated source has 3,339 instructions versus 3,397 in the incumbent.
The emitter has 178 macro tokens versus 180. All ten chronological rows
remain present and in the same order. The output contains 24 source files
and local audit records. The checked reference manifest is graph_rows.json;
source_generation_and_pricing.json records all 24 exact source hashes.

These audits concern the literal source macro behavior. They do not by
themselves certify a compiled binary table or the proof-word census transfer.

Actual pricing scope
--------------------
Only graph_AB_00 was submitted to the compiler. Four attempts were run:

  cut 1101010111101011, limit182, keep8, 30,000-call cap: cap reached.
  cut 11010101111, limit182, keep16, 40,000-call cap: cap reached.
  cut 1101010111101, limit192, keep8, 60,000-call cap: cap reached.
  cut 1101010111101, limit192, keep8, 200,000-call cap: completed its
      heuristic beam search after 84,363 calls; no candidate was emitted.

All used seed0, permissive3, counter1 and an 800 MiB RSS guard. The exact
unmodified receipts are in pricing_receipts. The other 23 source variants
were generated and checked but were not priced. The absence of a candidate
is not an impossibility result or a lower bound on the achievable state count.

Portable reproduction of the final actual attempt
-------------------------------------------------
From the release root, after source generation above:

  g++ -O3 -shared -fPIC counting_row_sources/compiler/strict.cpp -o counting_row_sources/compiler/strict.so

  python3 counting_row_sources/compiler/compile.py --donor machine --source counting_row_sources/generated/rows/graph_AB_00/source.sites.json --cut 1101010111101 --limit 192 --keep 8 --permissive 3 --counter 1 --max-rss-mb 800 --max-calls 200000 --out counting_row_sources/repriced_AB_00

The compiler and C++ source are the exact files used in the recorded run.
The .so binary, generated caches and partial search trees are omitted.
The compiler is a discovery heuristic: any emitted table needs independent
blank-start and unbounded physical verification before it can be accepted.
