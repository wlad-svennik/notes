from collections import deque

def graph(rows):
    spans = {}
    addresses = [p for p, _, _ in rows]
    assert addresses == sorted(set(addresses))
    for i, p in enumerate(addresses):
        for j in range(len(p)+1):
            spans.setdefault(p[:j], [i, i])[1] = i+1
    leaves = set(addresses)
    for p in spans:
        assert (p+"0" in spans) == (p+"1" in spans) == (p not in leaves)
    result = []
    for i, (p, op, k) in enumerate(rows):
        nxt = (i+1) % len(rows)
        if op == "H":
            result.append((None,))
            continue
        if op == "CI":
            result.append((nxt,))
            continue
        side = "1" if op == "CC" else "0"
        root = p
        for _ in range(k if op in ("CB","CC") else 1):
            root = root[:root.rindex(side)]
        left, right = spans[root]
        if op == "CD":
            result.append((nxt, None if p.endswith("1") else right % len(rows)))
        elif op == "CC":
            result.append((left,))
        else:
            assert op == "CB"
            result.append((right % len(rows),))
    return result


def transfers(rows, edges, pc, values):
    # A mask describes the possible values 0, 1, 2, and 3 or more.
    _, op, k = rows[pc]
    if op in ("CC", "CB"):
        yield edges[pc][0], values
        return
    if op == "H":
        yield None, values
        return
    old = values[k]
    if op == "CI":
        inc = ((old << 1) & 15) | (old & 8)
        yield edges[pc][0], values[:k]+(inc,)+values[k+1:]
    else:
        if old & 1:
            yield edges[pc][1], values[:k]+(1,)+values[k+1:]
        if old & 14:
            dec = (old >> 1) | (old & 8)
            yield edges[pc][0], values[:k]+(dec,)+values[k+1:]


def invariant(rows, edges, counter=0):
    values = [None]*len(rows)
    values[0] = tuple(8 if j==counter else 1 for j in range(9))
    queue = deque([0])
    while queue:
        pc = queue.popleft()
        for dest, image in transfers(rows, edges, pc, values[pc]):
            if dest is None:
                continue
            old = values[dest]
            joined = image if old is None else tuple(a|b for a,b in zip(image,old))
            if old != joined:
                values[dest] = joined
                queue.append(dest)
    # Independent inductiveness check, including the initial counter value 3.
    assert values[0][counter]&8 and all(mask&1 for j,mask in enumerate(values[0]) if j!=counter)
    for i, v in enumerate(values):
        if v is not None:
            for dest, im in transfers(rows, edges, i, v):
                assert dest is None or all((y & ~z)==0 for y,z in zip(im,values[dest]))
    return values


