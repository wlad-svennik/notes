"""Portable native decoder recompiler for the literal 174-state NF table.

Discovery only: every exported table still needs frame and boot verification.
Native compatibility uses three complete natural-register fixtures, keeping
the exact source address. Beam pruning is explicitly heuristic.
"""
from pathlib import Path
import argparse,ctypes,json,hashlib,collections,itertools,random,time,resource,gzip
from functools import lru_cache

HERE=Path(__file__).resolve().parent
U=ctypes.c_ulonglong
A=lambda a:(ctypes.c_int*len(a))(*a)

def tree(rows):
 if len(rows)==1 and rows[0][0]=='':return tuple(rows[0][1:])
 assert rows and all(r[0] for r in rows)
 return tuple(tree([(p[1:],o,k) for p,o,k in rows if p[0]==b])for b in '01')

def linear(t,p):
 if isinstance(t[0],str):return[(p,*t)]
 return linear(t[0],p+'0')+linear(t[1],p+'1')

class Compiler:
 def __init__(self,donor,source=None,cut='1',limit=173,keep=16,seed=0,permissive=0,forbid=None,invariant=False,counter=1,frame_gap=0,max_rss_mb=0,max_new_states=0,max_calls=0,resource_frame=False,initial_masks=None,zero_patterns=None,new_noise=0,oracle_root=None,effective_cfg=None,native_cache=None):
  self.max_rss_mb=max_rss_mb;self.max_new_states=max_new_states;self.max_calls=max_calls;self.calls=0
  self.leaf_misses={};self.diagnostics={}
  self.opt.cache_clear()
  self.donor=Path(donor);self.rows=json.loads(Path(source).read_bytes())if source else json.loads((self.donor/'source.sites.json').read_bytes())
  self.literal_rows=self.rows;self.effective=json.loads(Path(effective_cfg).read_bytes())if effective_cfg else None;self.custom_edges=None
  if self.effective is not None:
   assert not zero_patterns,'separate zero-pattern certificate currently requires ordinary structured control flow'
   assert [r[0]for r in self.effective['sites']]==[r[0]for r in self.rows],'effective-CFG address mismatch'
   self.rows=self.effective['sites'];self.custom_edges={(int(pc),bool(z)):target for pc,z,target in self.effective['edges']}
   assert len(self.custom_edges)==len(self.effective['edges']),'duplicate effective edge'
   for pc,(_,op,k)in enumerate(self.rows):
    for z in ((False,True)if op=='CD'else(False,)):
     assert(pc,z)in self.custom_edges,('missing effective edge',pc,z)
     target=self.custom_edges[pc,z]
     assert target is None or(len(target)==2 and 0<=target[0]<len(self.rows)and isinstance(target[1],int)and target[1]>=0)
  self.tab={}
  for l in(self.donor/'candidate.tm').read_text().splitlines()[1:]:
   q,b,w,d,j=l.split();self.tab[q,b]=(w,d,j)
  self.names=sorted({q for q,b in self.tab});self.N=len(self.names);self.ix={q:i for i,q in enumerate(self.names+['halt'])}
  self.orig=json.loads((self.donor/'source.sites.json').read_bytes());self.cut=cut
  if(self.donor/'effective-cfg.json').exists():
   donor_effective=json.loads((self.donor/'effective-cfg.json').read_bytes())
   assert [r[0]for r in self.orig]==[r[0]for r in donor_effective['sites']],'donor effective-CFG address mismatch'
   self.orig=donor_effective['sites']
  self.G={q for q in self.names if q.startswith(('a:','k:','k16share:','new:','scan:'))}
  if(self.donor/'native-gates.json').exists():self.G.update(json.loads((self.donor/'native-gates.json').read_bytes()))
  self.resource_frame=resource_frame
  self.resource_gap=frame_gap or 55
  library=HERE/('strict_resource.so'if resource_frame else'strict_mask.so'if invariant or self.effective is not None else'strict.so');self.L=ctypes.CDLL(str(library))
  self.live=None;self.bounds=None;self.zero_certificate=None;self.seed=seed;self.new_noise=new_noise
  assert 0<=new_noise<=1.5
  self.initial_masks=tuple(map(int,initial_masks.split(',')))if initial_masks else tuple(15 if j==counter else 1 for j in range(9))
  assert len(self.initial_masks)==9 and all(0<m<16 for m in self.initial_masks)
  if invariant or zero_patterns or self.effective is not None:
   from cfg import graph,transfers
   if self.effective is None:edges=graph(self.rows)
   else:edges=[tuple(None if self.custom_edges[i,z]is None else self.custom_edges[i,z][0]for z in ((False,True)if op=='CD'else(False,)))for i,(_,op,k)in enumerate(self.rows)]
   values=[None]*len(self.rows);values[0]=self.initial_masks;queue=collections.deque([0])
   while queue:
    pc=queue.popleft()
    for dest,im in transfers(self.rows,edges,pc,values[pc]):
     if dest is None:continue
     old=values[dest];joined=im if old is None else tuple(a|b for a,b in zip(old,im))
     if old!=joined:values[dest]=joined;queue.append(dest)
   if self.effective is not None:
    supplied=[tuple(v)if v is not None else None for v in self.effective['invariant_masks']];assert len(supplied)==len(values)
    for pc,(calculated,declared)in enumerate(zip(values,supplied)):
     assert calculated is None or(declared is not None and len(declared)==9 and all(0<m<16 for m in declared)and all(x&~y==0 for x,y in zip(calculated,declared))),('effective invariant excludes reached category',pc)
    values=supplied
   for i,v in enumerate(values):
    if v is not None:
     for dest,im in transfers(self.rows,edges,i,v):assert dest is None or all((y&~z)==0 for y,z in zip(im,values[dest]))
   if zero_patterns:
    cert=json.loads(Path(zero_patterns).read_bytes());raw_source=Path(source)if source else self.donor/'source.sites.json'
    assert cert['source_sha256']==hashlib.sha256(raw_source.read_bytes()).hexdigest(),'zero-pattern source hash mismatch'
    assert tuple(cert['initial_masks'])==self.initial_masks,'zero-pattern initial masks mismatch'
    zs=[int(v,16)for v in cert['patterns']];assert len(zs)==len(self.rows)
    initial=[0]
    for j,m in enumerate(self.initial_masks):initial=[p|b for p in initial for b in ([0]if m&1 else[])+([1<<j]if m&14 else[])]
    assert all(zs[0]&(1<<p)for p in initial)
    marginals=[];checked=0
    for pc,z in enumerate(zs):
     assert 0<=z and z.bit_length()<=512
     marginal=[0]*9;_,op,k=self.rows[pc]
     while z:
      lo=z&-z;p=lo.bit_length()-1;z^=lo
      for j in range(9):marginal[j]|=14 if p&(1<<j)else 1
      if op=='CI':images=[(edges[pc][0],p|(1<<k))]
      elif op=='CD':images=[(edges[pc][0],p),(edges[pc][0],p&~(1<<k))]if p&(1<<k)else[(edges[pc][1],p)]
      else:images=[(edges[pc][0],p)]
      for dest,q in images:assert dest is None or zs[dest]&(1<<q),(pc,p,dest,q)
      checked+=len(images)
     marginals.append(marginal)
    for i,(v,m)in enumerate(zip(values,marginals)):
     joined=tuple(x&y for x,y in zip(v,m))if v is not None else None
     values[i]=joined if joined and all(joined)else None
    self.zero_certificate=cert;self.zero_checked_edges=checked
   self.bounds={p:v for (p,o,k),v in zip(self.rows,values)};self.live={p for p,v in self.bounds.items()if v is not None}
  self.matrix=A([z for q in self.names for b in '01'for w,d,j in[self.tab[q,b]]for z in(int(w),1 if d=='R'else -1,self.ix[j])])
  self.gate=A([int(q in self.G)for q in self.names]);self.vec=A([0]*self.N)
  self.val=lambda p:U(int(('1'+p)[::-1],2));self.opid=lambda o,k:{'CI':0,'CD':12,'CC':24,'CB':36,'H':48}[o]+k
  self.L.init(self.N,self.matrix,self.gate,-1)
  for i,(p,o,k)in enumerate(self.orig):self.L.record(self.val(p),len(p),i,self.opid(o,k),self.ix['d:0'])
  if(self.donor/'native-references.json').exists():
   for reference in json.loads((self.donor/'native-references.json').read_bytes()):
    for i,(p,o,k)in enumerate(reference['rows']):self.L.record(self.val(p),len(p),i,self.opid(o,k),self.ix[reference['root']])
  if(self.donor/'native-hypotheses.json').exists():
   for hypothesis in json.loads((self.donor/'native-hypotheses.json').read_bytes()):
    for op,k in hypothesis['operations']:
     self.L.hypothesis(self.ix[hypothesis['state']],hypothesis.get('offset',1),self.opid(op,k))
  sp={};used=collections.defaultdict(set)
  for i,(p,o,k)in enumerate(self.orig):
   for j in range(len(p)+1):sp.setdefault(p[:j],[i,i])[1]=i+1
   for tail in'01':
    tape='1'+p+tail*70;h=1;q='d:0'
    for _ in range(120):
     if q=='halt'or q in self.G or h<0 or h>=len(tape):break
     b=tape[h];used[q,b].add((i,h));w,d,q=self.tab[q,b]
     if w!=b:break
     h+=1 if d=='R'else-1
  self.starts={}
  for ed,uses in used.items():
   hs={h for i,h in uses};pcs={i for i,h in uses};lo=min(pcs);hi=max(pcs)+1
   if len(hs)!=1:continue
   h=next(iter(hs));p=self.orig[lo][0][:h]
   if p and sp[p]==[lo,hi]and len(pcs)==hi-lo and len(p)==h and ed[1]==p[-1]:self.starts[p]=ed
  if cut!='root'and cut not in self.starts:raise ValueError(('not a single physical cut',cut))
  self.edge=self.starts[cut]if cut!='root'else None
  self.edges={self.edge}if self.edge is not None else{('d:0','0'),('d:0','1')}
  self.out=self.close('k:74',self.edges);self.budget=limit-len(self.out);self.limit=limit;self.keep=keep
  self.bits={q:frozenset(self.ix[t]for t in self.close(q,self.edges)-self.out)for q in self.names}
  self.alias={tuple(self.tab[q,b]for b in'01'):q for q in self.names if all(q!=e[0]for e in self.edges)};self.add={};self.counter=self.N
  rng=random.Random(seed);self.weights={j:1+(rng.random()-.5)*.7 if seed else 1 for j in range(self.N)}
  self.forbid=self.ix[forbid]if forbid else None
  self.L.init(self.N,self.matrix,self.gate,2*self.ix[self.edge[0]]+int(self.edge[1])if self.edge is not None else-1);self.L.strictconfig(self.ix['d:0'],permissive)
  if oracle_root is not None:
   if oracle_root=='auto':
    matches=[r['root']for r in json.loads((self.donor/'native-references.json').read_bytes())if r['rows']==self.rows]
    assert len(matches)==1,('need unique source-matching oracle root',matches)
    oracle_root=matches[0]
   self.L.setoracle(-2 if oracle_root=='reject'else self.ix[oracle_root])
  self.oracle_root=oracle_root
  if self.edge is None:self.L.blockroot(self.ix['d:0'])
  if frame_gap or resource_frame:self.L.framegap(frame_gap or 55)
  if self.bounds is not None:
   for p,v in self.bounds.items():
    if v is not None:self.L.setbounds(self.val(p),len(p),A(v))
  if self.custom_edges is not None:
   for(pc,z),target in self.custom_edges.items():
    p=self.rows[pc][0];dest=self.rows[target[0]][0]if target is not None else''
    self.L.setedge(self.val(p),len(p),int(z),self.val(dest),len(dest),target[1]if target is not None else 0,int(target is None))
  self.native_cache_path=Path(native_cache)if native_cache else None;self.native_cache={};self.native_hits=0;self.native_misses=0
  if self.native_cache_path is not None:
   profile={'table':hashlib.sha256((self.donor/'candidate.tm').read_bytes()).hexdigest(),'source':self.rows,'native_source':self.orig,'bounds':self.bounds,'edges':self.effective['edges']if self.effective is not None else None,'cut':self.cut,'permissive':permissive,'frame_gap':frame_gap,'resource':resource_frame,'oracle_root':self.oracle_root,'library':hashlib.sha256(library.read_bytes()).hexdigest()}
   for filename in ('native-gates.json','native-references.json','native-hypotheses.json'):
    if(self.donor/filename).exists():profile[filename]=hashlib.sha256((self.donor/filename).read_bytes()).hexdigest()
   self.native_fingerprint=hashlib.sha256(json.dumps(profile,sort_keys=True,separators=(',',':')).encode()).hexdigest()
   if self.native_cache_path.exists():
    with gzip.open(self.native_cache_path,'rt')as f:
     header=json.loads(next(f))
     if header.get('fingerprint')==self.native_fingerprint:
      for line in f:
       p,mask,values=json.loads(line);self.native_cache[p,mask]=tuple(values)
 def save_native_cache(self):
  if self.native_cache_path is None:return
  path=self.native_cache_path;path.parent.mkdir(parents=True,exist_ok=True);tmp=Path(str(path)+'.part')
  with gzip.open(tmp,'wt',compresslevel=3)as f:
   f.write(json.dumps({'format':'nf-native-options-v1','fingerprint':self.native_fingerprint})+'\n')
   for(p,mask),values in self.native_cache.items():f.write(json.dumps([p,mask,values],separators=(',',':'))+'\n')
  tmp.replace(path)
 def close(self,q,edge=None,table=None):
  table=table or self.tab;seen=set();todo=[q];edges=edge if isinstance(edge,set)else{edge}
  while todo:
   r=todo.pop()
   if r=='halt'or r in seen:continue
   seen.add(r);todo.extend(table[r,b][2]for b in'01'if(r,b)not in edges)
  return seen
 def score(self,s):return sum(self.weights.get(x,1)for x in s)
 @lru_cache(maxsize=300000)
 def opt(self,p,t,mask):
  self.calls+=1
  if self.max_calls and self.calls>self.max_calls:raise RuntimeError('SEARCH_BUDGET calls')
  if self.max_new_states and len(self.add)>self.max_new_states:raise RuntimeError('SEARCH_BUDGET generated states')
  if self.max_rss_mb and self.calls%500==0 and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>self.max_rss_mb*1024:raise RuntimeError('SEARCH_BUDGET memory')
  h=len(p);b=int(p[-1]);opts={};raw_accepts=0;cached=self.native_cache.get((p,mask));record=[]
  if cached is None:
   self.native_misses+=1;rows=linear(t,p)
   if self.live is not None:rows=[r for r in rows if r[0]in self.live]
   for i,(r,o,k)in enumerate(rows):self.L.site(i,self.val(r),len(r),self.opid(o,k))
  else:self.native_hits+=1
  sub=[]
  for w in(b,1-b):
   delta=mask^((w^b)<<h)
   for di,step in[('R',1),('L',-1)]:
    if cached is None:
     n=self.L.strictmask(0,len(rows),h+step,U(delta),self.vec);accepted=sum(1<<j for j in self.vec[:n]);record.append(accepted)
    else:accepted=cached[len(record)];record.append(accepted)
    raw_accepts+=accepted.bit_count()
    while accepted:
     bit=accepted&-accepted;j=bit.bit_length()-1;accepted^=bit
     q=self.names[j];v=self.bits[q]
     if len(v)<=self.budget and(self.forbid is None or self.forbid not in v):opts[str(w),di,q]=v
   if delta.bit_count()<=1 and not isinstance(t[0],str):sub.append((str(w),delta))
  if self.native_cache_path is not None and cached is None:self.native_cache[p,mask]=tuple(record)
  for w,delta in sub:
   left=self.opt(p+'0',t[0],delta);right=self.opt(p+'1',t[1],delta)
   for(a,x),(c,y)in itertools.product(left,right):
    v=x|y
    if len(v)>self.budget:continue
    q=self.alias.get((a,c))
    if q is None:
     q='s'+hashlib.sha256(repr((a,c)).encode()).hexdigest()[:12]
     self.alias[a,c]=q;self.add[q]=a,c;self.bits[q]=frozenset([self.counter])
     if self.new_noise:self.weights[self.counter]=1+self.new_noise*(int(hashlib.sha256(f'{self.seed}:{q}'.encode()).hexdigest()[:13],16)/16**13-.5)
     self.counter+=1
    v=v|self.bits[q]
    if len(v)<=self.budget and(self.forbid is None or self.forbid not in v):opts[w,'R',q]=v
  if not opts:
   if isinstance(t[0],str):self.leaf_misses.setdefault(p,{'operation':t,'zero_compatibility_masks':0,'over_budget_masks':0})['over_budget_masks'if raw_accepts else'zero_compatibility_masks']+=1
   return()
  best=sorted(opts.items(),key=lambda z:(self.score(z[1]),len(z[1]),z[0][1]!='R',z[0]))
  low=min(len(z[1])for z in best);out=[];groups=collections.Counter()
  for a,s in best:
   if len(s)>low+5 or groups[s]>=4:continue
   out.append((a,s));groups[s]+=1
   if len(out)>=self.keep:break
  return tuple(out)
 def run(self,outdir):
  if self.budget<0:return[]
  K=self.cut;hist=[]
  if K=='root':
   left=self.opt('0',tree([(p[1:],o,k)for p,o,k in self.rows if p.startswith('0')]),0)
   right=self.opt('1',tree([(p[1:],o,k)for p,o,k in self.rows if p.startswith('1')]),0)
   self.diagnostics={'left_options':len(left),'right_options':len(right),'left_minimum_in_beam':min((len(x)for a,x in left),default=None),'right_minimum_in_beam':min((len(x)for a,x in right),default=None),'joined_minimum_in_beams':min((len(x|y)for a,x in left for b,y in right),default=None)}
   choices=[]
   for(a,x),(b,y)in itertools.product(left,right):
    if len(x|y)<=self.budget:choices.append(({('d:0','0'):a,('d:0','1'):b},x|y))
   choices=sorted(choices,key=lambda z:(self.score(z[1]),len(z[1])))[:self.keep]
  else:
   t=tree([(p[len(K):],o,k)for p,o,k in self.rows if p.startswith(K)])
   choices=[({self.edge:act},mask)for act,mask in self.opt(K,t,0)]
  for patch,mask in choices:
   table=dict(self.tab);table.update(patch);todo=[act[2]for act in patch.values()];added=set()
   while todo:
    r=todo.pop()
    if r not in self.add or r in added:continue
    added.add(r)
    for b,a in zip('01',self.add[r]):table[r,b]=a;todo.append(a[2])
   names=self.close('k:74',table=table)
   raw='#! start k:74\n'+''.join(f'{q} {b} {w} {d} {j}\n'for q in sorted(names)for b in'01'for w,d,j in[table[q,b]])
   if len(names)>self.limit:continue
   sha=hashlib.sha256(raw.encode()).hexdigest();dest=Path(outdir)/f'{len(names)}-{sha[:14]}';dest.mkdir(parents=True,exist_ok=True)
   (dest/'candidate.tm').write_text(raw);(dest/'source.sites.json').write_text(json.dumps(self.literal_rows if self.effective is not None else self.rows,separators=(',',':')))
   if self.effective is not None:(dest/'effective-cfg.json').write_text(json.dumps(self.effective,separators=(',',':')))
   (dest/'discovery.json').write_text(json.dumps({'cut':self.cut,'edge':self.edge,'donor':str(self.donor),'states':len(names),'sha256':sha,'contract':'three natural-register fixtures, exact address, heuristic beam; unverified'},indent=2))
   if self.resource_frame:(dest/'resource-profile.json').write_text(json.dumps({'minimum_gap':self.resource_gap,'minimum_spares':24,'required':'same semantic source PC and nine registers; exact canonical tape; full symbolic replay required'},indent=2))
   if self.bounds is not None:
    (dest/'invariant.json').write_text(json.dumps(self.bounds,separators=(',',':')))
    (dest/'invariant-entry.json').write_text(json.dumps({'initial_masks':self.initial_masks,'mask_categories':['0','1','2','>=3']},indent=2))
   if self.zero_certificate is not None:(dest/'zero-patterns.json').write_text(json.dumps(self.zero_certificate,separators=(',',':')))
   hist.append(str(dest))
  return hist

def main():
 a=argparse.ArgumentParser();a.add_argument('--donor',required=True);a.add_argument('--source');a.add_argument('--cut',default='1');a.add_argument('--limit',type=int,default=173);a.add_argument('--keep',type=int,default=16);a.add_argument('--seed',type=int,default=0);a.add_argument('--permissive',type=int,default=0);a.add_argument('--forbid');a.add_argument('--out',required=True);a.add_argument('--invariant',action='store_true');a.add_argument('--counter',type=int,default=1);a.add_argument('--frame-gap',type=int,default=0);a.add_argument('--max-rss-mb',type=int,default=900);a.add_argument('--max-new-states',type=int,default=0);a.add_argument('--max-calls',type=int,default=0);a.add_argument('--resource',action='store_true');a.add_argument('--initial-masks');a.add_argument('--zero-patterns');a.add_argument('--new-noise',type=float,default=0);a.add_argument('--oracle-root');a.add_argument('--effective-cfg');a.add_argument('--native-cache');args=a.parse_args();t=time.monotonic()
 c=Compiler(args.donor,args.source,args.cut,args.limit,args.keep,args.seed,args.permissive,args.forbid,args.invariant,args.counter,args.frame_gap,args.max_rss_mb,args.max_new_states,args.max_calls,args.resource,args.initial_masks,args.zero_patterns,args.new_noise,args.oracle_root,args.effective_cfg,args.native_cache)
 print('start',vars(args),'exterior',len(c.out),'budget',c.budget,flush=True)
 try:
  result=c.run(args.out);status='complete'
 except RuntimeError as e:
  if not str(e).startswith('SEARCH_BUDGET'):raise
  result=[];status=str(e)
 c.save_native_cache()
 receipt={'status':status,'native_cache_hits':c.native_hits,'native_cache_misses':c.native_misses,'results':result,'seconds':time.monotonic()-t,'cache':str(c.opt.cache_info()),'new':len(c.add),'calls':c.calls,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'arguments':vars(args),'root_diagnostics':c.diagnostics,'leafs_with_rejected_mask_attempts':len(c.leaf_misses),'rejected_leaf_masks_sample':dict(list(c.leaf_misses.items())[:20])}
 out=Path(args.out);out.mkdir(parents=True,exist_ok=True);(out/'compiler-receipt.json').write_text(json.dumps(receipt,indent=2))
 print(status,json.dumps(result),'seconds',round(time.monotonic()-t,3),'cache',str(c.opt.cache_info()),'new',len(c.add),flush=True)
if __name__=='__main__':main()
