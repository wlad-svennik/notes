#include<cstdint>
#include<set>
#include<array>
#include<algorithm>
using U=unsigned long long;
struct E{int w,d,q;};E table[1024][2];int gate[1024],n0,bl,blocked_root=-1;struct Site{U x;int len,op;};Site sites[4000];std::set<std::array<long long,4>> matches[64][2];
std::array<long long,4> run(U x,int len,int q,int h,int b,int forbid,U start=0,int modify=0){
 U old=x;if(b)x|=~0ULL<<(len+1);old=x; x^=start;
 for(int t=0;t<130;t++){if(h<0||h>=62||q>=n0)return {-300,0,0,0};if(q==blocked_root)return {-300,0,0,0};if(gate[q]){U delta=x^old;
  if(len>47 || (delta>>(len+14)))return{-300,0,0,0};long long desc=delta<<(48-len);
  return {q,h-len,desc,0};}int c=x>>h&1;if(forbid>=0&&2*q+c==forbid)return{-300,0,0,0};auto e=table[q][c];x=(x&~(1ull<<h))|((U)e.w<<h);h+=e.d;q=e.q;}
 return{-300,0,0,0};}
extern "C" {
void init(int n,int*tab,int*g,int forbidden){n0=n;bl=forbidden;blocked_root=-1;std::copy(g,g+n,gate);for(int q=0;q<n;q++)for(int b=0;b<2;b++){auto v=tab+6*q+3*b;table[q][b]={v[0],v[1],v[2]};}}
void blockroot(int q){blocked_root=q;}
void hypothesis(int q,int off,int op){for(int b=0;b<2;b++)matches[op][b].insert({q,off,0,0});}
void record(U x,int len,int i,int op,int q){for(int b=0;b<2;b++)matches[op][b].insert(run(x,len,q,1,b,-1));}
void site(int i,U x,int len,int op){sites[i]={x,len,op};}
int compatible(int l,int r,int h,int*out){int count=0;for(int q=0;q<n0;q++){bool ok=true;for(int i=l;i<r&&ok;i++){auto s=sites[i];for(int b=0;b<2;b++)if(!matches[s.op][b].count(run(s.x,s.len,q,h,b,bl))){ok=false;break;}}
if(ok)out[count++]=q;}return count;}int compatw(int l,int r,int h,int p,int toggle,int*out){int count=0;for(int q=0;q<n0;q++){bool ok=true;for(int i=l;i<r&&ok;i++){auto s=sites[i];for(int b=0;b<2;b++)if(!matches[s.op][b].count(run(s.x,s.len,q,h,b,bl,toggle?(1ULL<<p):0,0))){ok=false;break;}}
if(ok)out[count++]=q;}return count;}
int compatmask(int l,int r,int h,U toggle,int*out){int count=0;for(int q=0;q<n0;q++){bool ok=true;for(int i=l;i<r&&ok;i++){auto s=sites[i];for(int b=0;b<2;b++)if(!matches[s.op][b].count(run(s.x,s.len,q,h,b,bl,toggle,0))){ok=false;break;}}
if(ok)out[count++]=q;}return count;}
}
#include <tuple>
#include <map>
#include <unordered_map>
#include <cstring>
#include <cstdio>
// Calibrate entry to a primitive against a native register frame with this
// particular address. Gate state and head offset alone omit the address bits
// read after entering a primitive. The final independent screen is stronger.
struct Tape {
    std::array<U,6> v{};
    int bit(int i)const{return (v[i>>6]>>(i&63))&1;}
    void put(int i,int b){if(b)v[i>>6]|=1ull<<(i&63);else v[i>>6]&=~(1ull<<(i&63));}
    bool operator==(const Tape& b)const{return v==b.v;}
};
int decl_root,decl_halt; int relax=0;int oracle_root=-1;
static constexpr int base0=48;
int reg_order[9]={2,8,1,4,3,7,0,5,6};
struct Frame {Tape t;int header,spares;};
Frame encode(U x,int len,int h,int header,const std::array<int,9>& rr,int spares){
    Frame f{{},header,spares};f.t.put(h-1,1);
    for(int k=0;k<len;k++)f.t.put(h+k,(x>>(k+1))&1);
    f.t.put(header,1);int i=header+2;
    for(int k:reg_order){for(int a=0;a<rr[k]+2;a++)f.t.put(i++,1);i++;}
    for(int a=0;a<spares;a++){f.t.put(i++,1);i++;}
    return f;
}
int trim(U &x,int &l,int c,int n){
    for(int k=0;k<n;k++){
        while(l>0&&((x>>l)&1)!=c)l--;
        if(l<=0)return 0;l--;x&=(1ull<<(l+1))-1;
    }
    return 1;
}
int minimum_frame_gap=0;
struct Trial {Tape start,end;int rhead;bool halt,legal;};
struct EdgeContract{U x;int len,wrap,halt;};
std::map<std::tuple<U,int,int>,EdgeContract> edge_contracts;
Trial testcase(const Site &s,int variant){
    int h=base0,header=base0+std::max(s.len+8,minimum_frame_gap)+(variant%2);
    std::array<int,9>rs{};for(int i=0;i<9;i++)rs[i]=variant<2?variant:(i+2*variant)%4;
    int spares=7;auto init=encode(s.x,s.len,h,header,rs,spares);
    int op=s.op/12,k=s.op%12;bool halt=false,ok=true;
    U x=s.x;int len=s.len;
    auto advance=[&](){
        if(trim(x,len,0,1)){len++;x|=1ull<<len;}
        else{x=1;len=0;h--;}
    };
    auto custom=edge_contracts.find({s.x,s.len,int(op==1&&rs[k]==0)});
    if(custom!=edge_contracts.end()){
        bool zero=op==1&&rs[k]==0;
        if(op==0){rs[k]++;spares++;}
        if(op==1&&!zero){rs[k]--;header++;}
        auto e=custom->second;halt=e.halt;
        if(!halt){x=e.x;len=e.len;h-=e.wrap;}
    }else{
    if(op==4)halt=true;
    if(op==0){rs[k]++;spares++;advance();}
    if(op==1){
        if(rs[k]){rs[k]--;header++;advance();}
        else if((x>>len)&1)halt=true;
        else {ok=trim(x,len,0,1);advance();}
    }
    if(op==2)ok=trim(x,len,1,k);
    if(op==3){ok=trim(x,len,0,k);advance();}
    }
    auto fin=encode(x,len,h,header,rs,spares);
    return {init.t,fin.t,h,halt,ok};
}
using Key=std::array<long long,9>;
struct Keyhash {
    size_t operator()(const Key& t)const{
        U a=0xef3971302d5b4329ull;
        for(U x:t){a^=x+0x9e3779b97f4a7c15ull+(a<<6)+(a>>2);}
        return a;
    }
};
std::unordered_map<Key,bool,Keyhash> ccache;
std::map<std::array<long long,3>,std::array<Trial,3>> trials;
bool calibrate(const Site& s,const std::array<long long,4>& sig,const std::array<long long,4>& alt){
    if(ccache.size()>=200000)ccache.clear();
    auto [q,off,desc,unused]=sig;if(q<0||q>=n0)return false;
    Key k{(long long)s.x,s.len,s.op,q,off,desc,alt[0],alt[1],alt[2]};auto v=ccache.find(k);
    if(v!=ccache.end())return v->second;
    std::array<long long,3> sitekey{(long long)s.x,s.len,s.op};auto it=trials.find(sitekey);
    if(it==trials.end())it=trials.emplace(sitekey,std::array<Trial,3>{testcase(s,0),testcase(s,1),testcase(s,2)}).first;
    bool all=true;
    for(const auto& tr:it->second){
        if(!tr.legal){all=false;break;}
        int st=q,head=base0+s.len+off-1;
        Tape t=tr.start;
        auto apply=[&](U d){
            while(d){int k=__builtin_ctzll(d);d&=d-1;int z=base0+s.len+k-48-1;t.put(z,!t.bit(z));}
        };apply(desc);
        bool passed=false;
        for(int i=0;i<3500;i++){
            if(st>=n0){passed=tr.halt;break;}
            if(st==decl_root){
                if(!tr.halt&&head==tr.rhead&&t==tr.end){passed=true;break;}
                bool same=head==base0;
                for(int k=0;k<s.len&&same;k++)same=t.bit(head+k)==int((s.x>>(k+1))&1);
                if(!same&&oracle_root==-2)break;
                if(!same&&oracle_root>=0)st=oracle_root;
                if(same){
                    const auto& now=t.bit(head+s.len)?alt:sig;
                    st=now[0];head=base0+s.len+now[1]-1;
                    if(st<0||st>=n0||head<0||head>=384)break;
                    apply(now[2]);
                }
            }
            if(head<0||head>=384)break;
            int b=t.bit(head);
            auto e=table[st][b];t.put(head,e.w);head+=e.d;st=e.q;
        }
        if(!passed){all=false;break;}
    }
    ccache[k]=all;return all;
}
extern "C" {
void framegap(int n){minimum_frame_gap=n;ccache.clear();trials.clear();}
void setedge(U x,int len,int zero,U dest,int dlen,int wrap,int halt){edge_contracts[{x,len,zero}]={dest,dlen,wrap,halt};ccache.clear();trials.clear();}
void setoracle(int root){oracle_root=root;ccache.clear();}
void strictconfig(int root,int permissive){decl_root=root;relax=permissive;oracle_root=-1;edge_contracts.clear();ccache.clear();trials.clear();}
bool phase_prefilter(const Site&s,const std::array<long long,4>&sig,int bit){
    bool zero_only=false;
    auto match=[&](int op){for(auto old:matches[op][bit])if(old[0]==sig[0]&&(relax==3||zero_only||old[1]==sig[1]))return true;return false;};
    if(match(s.op))return true;
    if(zero_only)for(int op=24;op<48;op++)if(match(op))return true;
    return false;
}
int strictmask(int l,int r,int h,U toggle,int*out){
    int count=0;
    for(int q=0;q<n0;q++){
        bool ok=true;
        for(int i=l;i<r&&ok;i++){
            auto s=sites[i];auto sig=run(s.x,s.len,q,h,0,bl,toggle,0);
            if(!relax&&!matches[s.op][0].count(sig)){ok=false;break;}
            if(relax>=2&&!phase_prefilter(s,sig,0)){ok=false;break;}
            auto alt=run(s.x,s.len,q,h,1,bl,toggle,0);
            if(!relax&&!matches[s.op][1].count(alt)){ok=false;break;}
            if(relax>=2&&!phase_prefilter(s,alt,1)){ok=false;break;}
            if(!calibrate(s,sig,alt)){ok=false;break;}
        }
        if(ok)out[count++]=q;
    }
    return count;
}
}
