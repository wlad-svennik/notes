"""Preserve the incumbent macro tree while substituting an equivalent image row."""
from pathlib import Path
import sys,json,os,functools,itertools
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
OUTPUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'generated'
OUTPUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(BASE/'reference/AxCount184/runtime'))
import audit_staged as audit

def tree(rows):
    if len(rows)==1 and rows[0][0]=='':return tuple(rows[0][1:])
    return tuple(tree([(p[1:],o,k) for p,o,k in rows if p.startswith(b)]) for b in '01')

def emit(t,p=''):
    if isinstance(t[0],str):return [[p,*t]]
    return emit(t[0],p+'0')+emit(t[1],p+'1')

def map_tree(t,path,replace):
    if path in replace:return replace[path]
    if isinstance(t[0],str):return t
    a,b=(map_tree(t[k],path+str(k),replace) for k in (0,1))
    return b if a is None else a if b is None else (a,b)

def align(old,new):
    # Only substitutions and deletions: choose a smallest-edit leaf alignment.
    @functools.lru_cache(None)
    def dp(i,j):
        if j==len(new):return (len(old)-i,tuple(None for _ in old[i:]))
        if len(old)-i<len(new)-j:return (100000,())
        a,seq=dp(i+1,j+1);best=(a+(old[i]!=new[j]),(new[j],)+seq)
        if len(old)-i>len(new)-j:
            a,seq=dp(i+1,j);candidate=(a+1,(None,)+seq)
            if candidate[0]<best[0]:best=candidate
        return best
    return dp(0,0)

rows=json.loads((BASE/'reference/AxCount184/machine/source.sites.json').read_bytes())
ref=json.loads((BASE/'reference/AxCount184/reference/Ax186/source.sites.json').read_bytes())
vocab=audit.vocabulary(ref);word,g=audit.decode(rows,vocab);lo,hi=audit.scope(rows)
at=lo;macros={};positions=[]
for token in word:
    n=audit.LENS[token];chunk=rows[at:at+n];prefix=os.path.commonprefix([r[0] for r in chunk]);assert sum(p.startswith(prefix) for p,o,k in rows)==n
    macros.setdefault(token,tree([[p[len(prefix):],o,k] for p,o,k in chunk]));positions.append(prefix);at+=n
original='Z1AI1AABI1I1ZI1ABI1I1I';offset=word.index(original);full=tree(rows)
manifest=[]
for x,y in itertools.permutations('ABC',2):
    fx='Z1'+x+'I1';fy='Z1'+y+'I1';ryt=fy+'ZI1'
    for revprem,revcon in itertools.product((False,True),repeat=2):
        premise=(y+fx if revprem else fx+y)+'I1'
        conclusion=(y+ryt if revcon else ryt+y)+'I1'
        new=premise+conclusion+'I';cost,aligned=align(original,new)
        assert len(new)==20 and len(aligned)==22
        replacements={positions[offset+i]:None if c is None else macros[c] for i,c in enumerate(aligned)}
        fresh=emit(map_tree(full,'',replacements));parsed,edges=audit.decode(fresh,vocab)
        assert parsed==word[:offset]+new+word[offset+len(original):]
        # All instructions exterior to the axiom emitter have identical local CFG.
        nlo,nhi=audit.scope(fresh);assert nlo==lo
        def tr(i):
            if i is None:return None
            if i<=lo:return i
            assert i>=hi;return i+nhi-hi
        for i in list(range(lo))+list(range(hi,len(rows))):
            assert rows[i][1:]==fresh[tr(i)][1:]
            assert tuple(map(tr,g[i]))==edges[tr(i)]
        perm=[1,5,2,0,6,4,3,7,8]
        mapped=[[p,o,perm[k] if o in('CI','CD') else k]for p,o,k in fresh]
        name=f'graph_{x}{y}_{int(revprem)}{int(revcon)}';d=OUTPUT/'rows'/name;d.mkdir(parents=True,exist_ok=True)
        (d/'source.sites.json').write_text(json.dumps(mapped,separators=(',',':'))+'\n')
        rec={'name':name,'row':new,'source_sites':len(mapped),'macro_tokens':len(parsed),'leaf_edit_cost':cost,'old_row':original,'same_exterior_sites':len(rows)-(hi-lo),'all_macros_cfg_checked':True}
        (d/'source-audit.json').write_text(json.dumps(rec,indent=2)+'\n');manifest.append(rec)
(OUTPUT/'graph_rows.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
