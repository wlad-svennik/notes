"""Check the exact rebuild, source conjugacy, blank boot and every symbolic branch."""
from pathlib import Path
import argparse,gzip,json,os,subprocess,sys,tempfile
from rebuild import rebuilt

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--regenerate',action='store_true',help='also regenerate every symbolic trace')
parser.add_argument('--reference',action='store_true',help='also replay the inherited 184-state release audit')
parser.add_argument('--kernel',type=Path,help='also regenerate and check all branches and all blank-start steps in this Lean checker')
args=parser.parse_args()
table,source=rebuilt()
assert table==(ROOT/'machine/candidate.tm').read_bytes()
assert source==(ROOT/'machine/source.sites.json').read_bytes()
env={**os.environ,'COUNTER_ROLE':'1'}
with tempfile.TemporaryDirectory() as temp:
    machine=Path(temp)
    for f in ('candidate.tm','source.sites.json','traces.gz'):
        (machine/f).write_bytes((ROOT/'machine'/f).read_bytes())
    subprocess.run([sys.executable,ROOT/'runtime/boot_any.py',machine,'450000','1','1'],check=True,env=env)
    assert json.loads((machine/'boot.json').read_bytes())==json.loads((ROOT/'machine/boot.json').read_bytes())
    result=subprocess.check_output([sys.executable,ROOT/'runtime/check_frames.py',machine,'--counter','1'],text=True,env=env)
    assert json.loads(result)==json.loads((ROOT/'machine/receipt.json').read_bytes())
    print(result.strip(),flush=True)
    if args.regenerate:
        output=machine/'regenerated.gz'
        subprocess.run([sys.executable,ROOT/'runtime/symbolic_counter.py',machine,'--write',output],check=True,env=env)
        assert gzip.decompress(output.read_bytes())==gzip.decompress((machine/'traces.gz').read_bytes())
    if args.kernel:
        checker=str(args.kernel.resolve())
        branch_receipt=machine/'branches.json'
        subprocess.run([sys.executable,ROOT/'kernel/engine/check_all.py',machine,machine/'traces.gz',branch_receipt,'--jobs','3','--chunk','64','--checker',checker],check=True,env=env)
        assert json.loads(branch_receipt.read_bytes())==json.loads((ROOT/'kernel/branches.json').read_bytes())
        boot_receipts=machine/'boot'
        subprocess.run([sys.executable,ROOT/'kernel/boot_segments.py',ROOT/'kernel/engine',machine,boot_receipts,'--jobs','2','--segment','2048','--checker',checker],check=True,env=env)
        assert json.loads((boot_receipts/'verified.json').read_bytes())==json.loads((ROOT/'kernel/boot/verified.json').read_bytes())
if args.reference:
    subprocess.run([sys.executable,ROOT/'reference/AxCount184/verify.py'],check=True)
print('PASS: exact 183-state rebuild, source permutation, blank initialization and 8,910 unbounded branches')
