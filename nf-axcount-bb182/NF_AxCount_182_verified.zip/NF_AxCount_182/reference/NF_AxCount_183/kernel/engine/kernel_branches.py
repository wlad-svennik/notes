"""Construct full register-branch proof terms for the literal NF192 machine.

The certificate is only a hint to this program. The external Lean kernel
checks the complete raw computation and all unbounded repetitions. No axioms
are accepted. Each generated theorem quantifies over its integer parameters
and two arbitrary exterior tape rays beyond explicit blank margins.
"""
from argparse import ArgumentParser
from dataclasses import dataclass
from functools import lru_cache
from gzip import decompress
import json
from pathlib import Path
from kernel_pumps import (STATE_COUNT,CERT, CONFIG, EQ, F, HERE, K, NAT, PRE, REFL, STACK, Z, ONE, V,
                         ap, arithmetic, arrow, lam, local_rules, num, physical, pumping,
                         raw_table, word, words_and_composition)
from export_syntax import Export
import symbolic_frames as discover

ROOT = discover.ids['d:0']
PAD_L, PAD_R = 64, 64
DATA = json.loads(decompress(CERT.read_bytes()))
TRANS = raw_table()
if DATA['source']!=discover.PROGRAM_HASH or DATA['table']!=discover.TABLE_HASH:
    raise ValueError('trace to machine/source binding')


@dataclass(frozen=True)
class Tail:
    name: str


A, B = Tail('leftRay'), Tail('rightRay')


def lit(t): return isinstance(t, str)
def var(i): return V('x'+str(i))
def control_of(c):return ap(c,Z,Z)


def cfg(q,d,a,b): return F('cfg',num(q),num(d),a,b)
def itr(f,n,x): return F('iterate',STACK,f,n,x)
def run(n,c): return F('iterate',CONFIG,K('step'),n,c)
def congr(ty,out,f,a,b,pr): return F('congr',ty,out,f,a,b,pr)
def trans(ty,a,b,c,p,q): return F('trans',ty,a,b,c,p,q)


@lru_cache(None)
def put(bits):return lam([('w',STACK)],word(bits,V('w')))


@lru_cache(maxsize=20000)
def material(ray):
    assert isinstance(ray[-1],Tail)
    e=V(ray[-1].name)
    for t in reversed(ray[:-1]):
        if lit(t): e=F('push',num(int(t)),e)
        else: e=itr(put(t[1]),var(t[0]),e)
    return e


def slide(u,m,v,n,tail):
    """u^n m -> m v^n for arbitrary stack tails, by kernel word induction."""
    assert u+m==m+v
    witness=lam([('w',STACK)],REFL(STACK,word(u+m,V('w'))))
    return F('powerSlide',STACK,put(u),put(v),put(m),witness,n,tail)


def normalized_support(e):
    c=V('c');q=ap(c,Z,Z);d=ap(c,ONE,Z);ahead=ap(c,num(2));behind=ap(c,num(3))
    norm=F('chooseZero',CONFIG,d,c,F('cfg',q,Z,F('push',ap(ahead,Z),behind),F('tail',ahead)))
    e.declare(PRE+'norm',[('c',CONFIG)],CONFIG,norm)


def branch_shape(t):
    i,cold,zero=t['pc'],t['cold'],t['zero']; _,kind,r=discover.sites[i]
    runs=[(1,True) for _ in range(9)]
    if cold:runs[discover.COUNTER]=(0,False)
    if kind=='CD':runs[r]=(1,False) if zero else (2,True)
    def arr(word):
        return tuple(t if lit(t) else (t.index,t.word) for t in word)
    start=arr(discover.frame(i,runs));dest,special=discover.transfer(i,zero)
    inp=(start[1:]+('0',)*PAD_R+(B,),('1',)+('0',)*PAD_L+(A,))
    if dest is None:return inp,None
    rr=list(runs)
    if kind=='CI':rr[r]=(rr[r][0]+1,rr[r][1])
    if kind=='CD' and not zero:rr[r]=(rr[r][0]-1,rr[r][1])
    end=arr(discover.frame(dest,rr,int(kind=='CI'),int((kind=='CD' and not zero) or special)))
    # The same arbitrary outer rays occupy the same actual physical positions.
    return inp,(end[1:]+('0',)*(PAD_R-3*int(kind=='CI'))+(B,),
                ('1',)+('0',)*(PAD_L-int(special))+(A,))


def ray_equality(left,right):
    assert left[-1]==right[-1]
    def split(ray):
        text='';pos=[]
        for t in ray[:-1]:
            if lit(t):text+=t
            else:pos.append((len(text),t))
        return text,pos
    base,ls=split(left);base2,rs=split(right)
    assert base==base2 and len(ls)==len(rs)
    pieces=[];end=0
    for (a,(idx,u)),(b,(j,v)) in zip(ls,rs):
        assert idx==j
        start=min(a,b);stop=max(a,b)
        assert start>=end
        pieces += [('fixed',base[end:start]),('vary',idx,u,v,base[start:stop],a<=b)]
        end=stop
    pieces.append(('fixed',base[end:]));l=r=V(left[-1].name);proof=None
    for piece in reversed(pieces):
        if piece[0]=='fixed':
            s=piece[1]
            if s:
                if proof is not None:proof=congr(STACK,STACK,put(s),l,r,proof)
                l,r=word(s,l),word(s,r)
            continue
        _,idx,u,v,m,forward=piece;n=var(idx)
        if forward:
            leftfn=lambda t:itr(put(u),n,word(m,t))
            rightfn=lambda t:word(m,itr(put(v),n,t))
            one=slide(u,m,v,n,l) if m or u!=v else None
        else:
            leftfn=lambda t:word(m,itr(put(u),n,t))
            rightfn=lambda t:itr(put(v),n,word(m,t))
            one=F('symm',STACK,rightfn(l),leftfn(l),slide(v,m,u,n,l)) if m or u!=v else None
        ll,mm,rr=leftfn(l),rightfn(l),rightfn(r)
        two=congr(STACK,STACK,lam([('w',STACK)],rightfn(V('w'))),l,r,proof) if proof is not None else None
        proof=trans(STACK,ll,mm,rr,one,two) if one is not None and two is not None else one or two
        l,r=ll,rr
    # l/r may differ from material(left/right) by reducible function application.
    return proof or REFL(STACK,l)


@dataclass(frozen=True)
class Block:
    ticks:tuple
    inp:tuple
    out:tuple
    proof:tuple


def merge(items):
    if len(items)==1:return items[0]
    j=len(items)//2;a,b=merge(items[:j]),merge(items[j:]);assert a.out==b.inp
    total=F('plus',a.ticks,b.ticks)
    proof=F('chain',CONFIG,K('step'),a.ticks,b.ticks,a.inp,a.out,b.out,a.proof,b.proof)
    return Block(total,a.inp,b.out,proof)



def simulate(q,d,ahead,behind,count):
    for _ in range(count):
        bit,ahead=ahead[0],ahead[1:]
        if not lit(bit) or q==STATE_COUNT:raise ValueError('outside fixed window',q,d,bit)
        q,w,m=TRANS[q,int(bit)];w=str(w)
        if m==d:behind=(w,)+behind
        else:ahead,behind,d=behind,(w,)+ahead,m
    return q,d,ahead,behind


def window(q,d,a,b,k):
    # Determine exactly which input cells are observed, by raw machine replay
    # in local integer coordinates. The initial direction is the positive axis.
    pos=0; seen={};must_a=must_b=0; direction=d
    for _ in range(k):
        if pos in seen:bit=seen[pos]
        elif pos>=0:
            bit=a[pos];must_a=max(must_a,pos+1)
        else:
            bit=b[-pos-1];must_b=max(must_b,-pos)
        assert lit(bit) and q!=STATE_COUNT
        q,w,move=TRANS[q,int(bit)];seen[pos]=str(w);pos+=(1 if move==direction else -1)
    wa=a[:must_a];wb=b[:must_b]
    assert all(lit(z) for z in wa+wb)
    return wa,wb


class LiteralProver:
    def __init__(self,export):self.e=export;self.cache={}

    def use(self,q,d,a,b,k):
        wa,wb=window(q,d,a,b,k);key=(q,d,wa,wb,k)
        if key not in self.cache:
            x=wa+(Tail('U'),);y=wb+(Tail('V'),)
            start=cfg(q,d,material(x),material(y))
            nq,nd,na,nb=simulate(q,d,x,y,k)
            end=cfg(nq,nd,material(na),material(nb))
            if k<=3:
                proof=REFL(CONFIG,end)
            else:
                split=k//2
                mq,md,ma,mb=simulate(q,d,x,y,split);mid=cfg(mq,md,material(ma),material(mb))
                p=self.use(q,d,x,y,split)
                r=self.use(mq,md,ma,mb,k-split)
                proof=F('chain',CONFIG,K('step'),num(split),num(k-split),start,mid,end,p,r)
            name='rawWindow'+str(len(self.cache))
            self.e.declare(PRE+name,[('U',STACK),('V',STACK)],EQ(CONFIG,run(num(k),start),end),proof,theorem=True)
            self.cache[key]=name
        return F(self.cache[key],material(a[len(wa):]),material(b[len(wb):]))


def raw_actions(t,literals):
    (ahead,behind),goal=branch_shape(t)
    q,d=ROOT,0
    state=lambda:cfg(q,d,material(ahead),material(behind))
    blocks=[]
    for act in t['actions']:
        start=state()
        if act>0:
            proof=literals.use(q,d,ahead,behind,act)
            q,d,ahead,behind=simulate(q,d,ahead,behind,act)
            expected=state();cost=num(act)
        elif act<0:
            j=-1-act;p=DATA['pumps'][j];assert (q,d)==(p['q'],int(p['dir']==-1))
            (idx,w),ahead=ahead[0],ahead[1:]
            assert w==p['unit']
            carry=tuple(reversed(p['context']));assert behind[:len(carry)]==carry
            tail=behind[len(carry):]
            proof=F('sweep'+str(j),var(idx),material(tail),material(ahead))
            behind=carry+((idx,p['output'][::-1]),)+tail
            cost=F('clock',num(p['ticks']),var(idx));expected=state()
        else:
            (idx,w),first,tail=ahead[0],ahead[1],ahead[2:];assert first==w[0]
            r=w[1:]+first
            before=material(ahead);p=slide(w,first,r,var(idx),material(tail))
            ahead=(first,(idx,r))+tail;after=material(ahead)
            proof=congr(STACK,CONFIG,lam([('w',STACK)],cfg(q,d,V('w'),material(behind))),before,after,p)
            cost=Z;expected=state()
        blocks.append(Block(cost,start,expected,proof))
    full=merge(blocks)
    if goal is None:
        assert q==STATE_COUNT
        project=lam([('w',CONFIG)],control_of(V('w')))
        return EQ(NAT,control_of(run(full.ticks,full.inp)),num(STATE_COUNT)),congr(CONFIG,NAT,project,
               run(full.ticks,full.inp),full.out,full.proof)
    assert q==ROOT
    if d:
        head=ahead[0];assert lit(head)
        ahead,behind=(head,)+behind,ahead[1:]
    ar,br=map(material,goal);al,bl=material(ahead),material(behind)
    p1=ray_equality(ahead,goal[0]);p2=ray_equality(behind,goal[1]);
    first=cfg(q,0,al,bl);mid=cfg(q,0,ar,bl);last=cfg(q,0,ar,br)
    front=congr(STACK,CONFIG,lam([('w',STACK)],cfg(q,0,V('w'),bl)),al,ar,p1)
    back=congr(STACK,CONFIG,lam([('w',STACK)],cfg(q,0,ar,V('w'))),bl,br,p2)
    ep=trans(CONFIG,first,mid,last,front,back)
    actual=run(full.ticks,full.inp)
    proof=trans(CONFIG,F('norm',actual),first,last,congr(CONFIG,CONFIG,K('norm'),actual,full.out,full.proof),ep)
    return EQ(CONFIG,F('norm',actual),last),proof


def generate(args):
    with args.output.open('wb') as out:
        e=Export(out);arithmetic(e);pumping(e);words_and_composition(e);physical(e);local_rules(e);normalized_support(e)
        literals=LiteralProver(e)
        subset=[t for t in DATA['traces'] if args.lo<=t['pc']<args.hi]
        if args.cold is not None:subset=[t for t in subset if t['cold']==bool(args.cold)]
        if args.zero is not None:subset=[t for t in subset if t['zero']==bool(args.zero)]
        pars=[('x'+str(i),NAT) for i in range(11)]+[(A.name,STACK),(B.name,STACK)]
        for index,t in enumerate(subset):
            typ,pf=raw_actions(t,literals)
            name='branch_'+str(t['pc'])+'_'+str(int(t['cold']))+'_'+str(int(t['zero']))
            e.declare(PRE+name,pars,typ,pf,theorem=True)
        print('kernel branch theorems',len(subset),'window lemmas',len(literals.cache),'bytes',args.output.stat().st_size,flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path)
    parser.add_argument('--lo',type=int,default=0)
    parser.add_argument('--hi',type=int,default=1)
    parser.add_argument('--cold',type=int,choices=[0,1])
    parser.add_argument('--zero',type=int,choices=[0,1])
    generate(parser.parse_args())
