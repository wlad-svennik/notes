import CountingCalibration
import ArbitraryBooleanFNF

set_option autoImplicit false

/-! The adapter from the old numerical-chart Boolean basis to the uploaded
counting proof body. This file additionally needs `ArbitraryBooleanFNF.lean`
from the inherited machine logic sources. Source prepared, not freshly built. -/

namespace FFL.FirstOrder.NFMachineCalibration

open SetTheory

theorem consistent_nfc_of_boolean_readback {V : Type}
    [S : ArbitraryBoolean.Basis V] (j q : V)
    (readback : ∀ x, S.app (S.app j (S.app j x)) q = S.app j x)
    (gap : ∃ t, (∃ v, S.app j v = t) ∧
      ∀ x, (∃ a, S.app j a = x) → S.app j x ≠ t) :
    Entailment.Consistent 𝗡𝗙𝗖 := by
  letI : Nonempty V := ⟨S.B⟩
  letI : Tarski.Structure ℒλ V := ArbitraryBoolean.fnStructure
  letI : Tarski.Structure.Eq ℒλ V := ⟨fun _ _ => Iff.rfl⟩
  letI : V↓[ℒλ] ⊧* 𝗙𝗡𝗙 := ArbitraryBoolean.fnModel_models
  exact consistent_nfc_of_readback j q readback gap

end FFL.FirstOrder.NFMachineCalibration

#print axioms FFL.FirstOrder.NFMachineCalibration.consistent_nfc_of_boolean_readback
