"""Inventory the local dependency closure and recorded proof evidence.

This is a source audit, not a Lean typechecker. It explicitly records that the
uploaded project and the two new adapter files were not rebuilt in this run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('proof_project', type=Path, help='Extracted nf-interp folder containing standalone and check')
ROOT = parser.parse_args().proof_project.resolve()
HERE = Path(__file__).resolve().parent
PROJECT = ROOT / 'standalone'


def strip_comments(source: str) -> str:
    out = []
    depth = 0
    i = 0
    in_string = False
    while i < len(source):
        if depth:
            if source.startswith('/-', i):
                depth += 1
                i += 2
            elif source.startswith('-/', i):
                depth -= 1
                i += 2
            else:
                if source[i] == '\n':
                    out.append('\n')
                i += 1
        elif in_string:
            if source[i] == '\\':
                i += 2
            elif source[i] == '"':
                in_string = False
                out.append('"')
                i += 1
            else:
                if source[i] == '\n':
                    out.append('\n')
                i += 1
        elif source.startswith('/-', i):
            depth = 1
            i += 2
        elif source.startswith('--', i):
            j = source.find('\n', i)
            i = len(source) if j < 0 else j
        elif source[i] == '"':
            in_string = True
            out.append('"')
            i += 1
        else:
            out.append(source[i])
            i += 1
    return ''.join(out)


def main() -> None:
    pending = ['NFUCountInterp', 'NFInterpretsFnCount']
    checked = {}
    external = set()
    suspicious = []
    copies_differ = []
    while pending:
        module = pending.pop()
        if module in checked or module in external:
            continue
        relative = Path(module.replace('.', '/') + '.lean')
        p = PROJECT / relative
        if not p.exists():
            external.add(module)
            continue
        data = p.read_bytes()
        source = strip_comments(data.decode())
        checked[module] = hashlib.sha256(data).hexdigest()
        parallel_copy = ROOT / relative
        if parallel_copy.exists() and parallel_copy.read_bytes() != data:
            copies_differ.append(str(relative))
        for line in source.splitlines():
            matched = re.match(r'^\s*(?:public\s+)?import\s+(.+)$', line)
            if matched:
                pending.extend(matched.group(1).split())
        for n, line in enumerate(source.splitlines(), 1):
            if re.search(r'\b(sorry|admit|sorryAx)\b', line) or re.match(
                r'^\s*(?:(?:private|protected|noncomputable|unsafe)\s+)*axiom\b', line
            ):
                suspicious.append({'module': module, 'line': n, 'text': line.strip()})
    logs = {}
    for name in (
        'check/leanchecker_results_count_2026-11-23.txt',
        'check/leanchecker_results_interp_2026-11-25.txt',
        'check/count_audit_output.txt',
        'check/count_mh_audit_output.txt',
        'check/nanoda_count_output.txt',
    ):
        p = ROOT / name
        logs[name] = hashlib.sha256(p.read_bytes()).hexdigest()
    result = {
        'kind': 'source_inventory_and_archived_evidence',
        'fresh_project_build': False,
        'fresh_adapter_build': False,
        'entry_modules': ['NFUCountInterp', 'NFInterpretsFnCount'],
        'local_modules': len(checked),
        'module_sha256': dict(sorted(checked.items())),
        'external_imports': sorted(external),
        'local_sorry_or_axiom_declarations': suspicious,
        'root_standalone_differences': copies_differ,
        'archived_evidence_sha256': logs,
    }
    (HERE / 'uploaded_source_audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('module_sha256', 'archived_evidence_sha256')}, indent=2))


if __name__ == '__main__':
    main()
