import NFUCountInterp
import NFInterpretsFnCount

set_option autoImplicit false

/-!
# The uploaded counting proofs as endpoints for the machine calibration

This file deliberately distinguishes the first-order theory interpretation from
the special full function chart used by the 184/183-state numerical calculus.
It imports the uploaded project, not any manuscript-level consistency premise.

Status: source prepared on 2026-11-25; the dependency project was not rebuilt in
this session because its Lean frontend, Mathlib and Foundation were unavailable.
The archive includes its own earlier build/kernel reports. They are not a fresh
check of this new file.
-/

namespace FFL.FirstOrder.NFMachineCalibration

open SetTheory FNF

/-- Counted FunctionNF interprets pure NF with Rosser Counting. -/
def fncInterpretsNFC : 𝗙𝗡𝗙𝗖 ⊳ 𝗡𝗙𝗖 :=
  DirectInterpretation.comp SetTheory.nfuicInterpretsNFC FNF.fncInterpretsNFUIC

/-- The two counted theories are mutually interpretable by the supplied maps. -/
def nfcFNCMutual : 𝗡𝗙𝗖 ⋈ 𝗙𝗡𝗙𝗖 where
  r := SetTheory.NFFn.nfcInterpretsFNC
  l := fncInterpretsNFC

/-- Explicit consistency endpoints; no separately assumed NFU-to-NF bridge. -/
theorem consistent_nfc_iff_fnfc :
    Entailment.Consistent 𝗡𝗙𝗖 ↔ Entailment.Consistent 𝗙𝗡𝗙𝗖 :=
  ⟨consistent_of_interprets SetTheory.NFFn.nfcInterpretsFNC,
    consistent_of_interprets fncInterpretsNFC⟩

section model

variable {M : Type} [Tarski.Structure ℒλ M] [Tarski.Structure.Eq ℒλ M]
  [Nonempty M] [hM : M↓[ℒλ] ⊧* 𝗙𝗡𝗙]

local infixl:70 " ⬝ " => FNF.App

/-- The machine's readback equation and a missing range point give a strongly
Cantorian Dedekind-infinite set. This is the `JJ203Range` argument, now expressed
against the uploaded `CountSet` API rather than an old external endpoint. -/
theorem strong_dedekind_of_readback (j q : M)
    (readback : ∀ a, (j ⬝ (j ⬝ a)) ⬝ q = j ⬝ a)
    (gap : ∃ t, (∃ x, j ⬝ x = t) ∧
      ∀ x, (∃ a, j ⬝ a = x) → j ⬝ x ≠ t) :
    ∃ d : M, IsSet d ∧ CountSet.Strong d ∧ CountSet.Dedekind d := by
  obtain ⟨d, hd, range⟩ : ∃ d : M, IsSet d ∧ ∀ a, Mem a d ↔ ∃ b, j ⬝ b = a :=
    (BT.ex (Γ := [0, 1]) 0 (BT.app 2 0 1 0 rfl rfl rfl)).set (fun _ => j)
  have member (x : M) : Mem (j ⬝ x) d := (range _).mpr ⟨x, rfl⟩
  have cancel {x : M} (hx : Mem x d) : (j ⬝ x) ⬝ q = x := by
    obtain ⟨a, rfl⟩ := (range x).mp hx
    exact readback a
  obtain ⟨g, hg, lift⟩ := CountSet.liftGraph d j q
  have strong : CountSet.Strong d := by
    refine ⟨g, hg, fun p => ?_⟩
    rw [lift]
    constructor
    · rintro ⟨x, y, _, _, pair, mem, rfl, rfl, rfl⟩
      exact ⟨x, mem, by simpa only [cancel mem] using pair⟩
    · rintro ⟨x, h, rfl⟩
      exact ⟨x, sing x, j ⬝ x, x, rfl, h, rfl, cancel h, rfl⟩
  obtain ⟨f, hf, graph⟩ := CountSet.graph d j
  have appgraph (a b : M) : Ap f a b ↔ Mem a d ∧ j ⬝ a = b := by
    change Mem (kp a b) f ↔ _
    rw [graph]
    constructor
    · rintro ⟨x, y, p, mem, val⟩
      obtain ⟨rfl, rfl⟩ := kp_inj p
      exact ⟨mem, val⟩
    · rintro ⟨mem, val⟩
      exact ⟨a, b, rfl, mem, val⟩
  have inj : Inj f d d := by
    constructor
    · intro x y h
      obtain ⟨mem, rfl⟩ := (appgraph _ _).mp h
      exact ⟨mem, member x⟩
    · exact fun x hx => ⟨_, (appgraph _ _).mpr ⟨hx, rfl⟩⟩
    · intro x y z ha hb
      exact ((appgraph _ _).mp ha).2.symm.trans ((appgraph _ _).mp hb).2
    · intro x y z hx hy
      obtain ⟨mx, ex⟩ := (appgraph _ _).mp hx
      obtain ⟨my, ey⟩ := (appgraph _ _).mp hy
      exact (cancel mx).symm.trans
        ((congrArg (fun a => a ⬝ q) (ex.trans ey.symm)).trans (cancel my))
  obtain ⟨t, rt, missing⟩ := gap
  refine ⟨d, hd, strong, f, t, hf, inj, (range t).mpr rt, ?_⟩
  intro x atX
  obtain ⟨hx, e⟩ := (appgraph x t).mp atX
  exact missing x ((range x).mp hx) e

/-- These premises imply full internal Rosser Counting, via the exact uploaded
Church-counting equivalence. No restriction to standard numerals occurs. -/
theorem church_counting_of_readback (j q : M)
    (readback : ∀ a, (j ⬝ (j ⬝ a)) ⬝ q = j ⬝ a)
    (gap : ∃ t, (∃ x, j ⬝ x = t) ∧
      ∀ x, (∃ a, j ⬝ a = x) → j ⬝ x ≠ t) : CountChurch M := by
  obtain ⟨d, _, strong, ded⟩ := strong_dedekind_of_readback j q readback gap
  exact FNF.countChurch_iff_counting.mpr
    (FNF.counting_of_T (FNF.T_eq_of_strong_dedekind d strong ded))

theorem models_fnfc_of_readback (j q : M)
    (readback : ∀ a, (j ⬝ (j ⬝ a)) ⬝ q = j ⬝ a)
    (gap : ∃ t, (∃ x, j ⬝ x = t) ∧
      ∀ x, (∃ a, j ⬝ a = x) → j ⬝ x ≠ t) : M↓[ℒλ] ⊧* 𝗙𝗡𝗙𝗖 := by
  refine models_theory_iff.mpr fun φ hφ => ?_
  rcases hφ with hφ | hφ
  · exact models_theory_iff.mp hM φ hφ
  · have e : φ = FNF.Axiom.count := hφ
    rw [e]
    exact FNF.models_count_iff.mpr (church_counting_of_readback j q readback gap)

/-- The precise endpoint needed after extracting the extensional function
model, readback and gap from the numerical countermodel. -/
theorem consistent_nfc_of_readback (j q : M)
    (readback : ∀ a, (j ⬝ (j ⬝ a)) ⬝ q = j ⬝ a)
    (gap : ∃ t, (∃ x, j ⬝ x = t) ∧
      ∀ x, (∃ a, j ⬝ a = x) → j ⬝ x ≠ t) :
    Entailment.Consistent 𝗡𝗙𝗖 := by
  letI : M↓[ℒλ] ⊧* 𝗙𝗡𝗙𝗖 := models_fnfc_of_readback j q readback gap
  exact consistent_of_interprets fncInterpretsNFC (consistent_of_model 𝗙𝗡𝗙𝗖 M)

end model

end FFL.FirstOrder.NFMachineCalibration

#print axioms FFL.FirstOrder.NFMachineCalibration.fncInterpretsNFC
#print axioms FFL.FirstOrder.NFMachineCalibration.consistent_nfc_iff_fnfc
#print axioms FFL.FirstOrder.NFMachineCalibration.strong_dedekind_of_readback
#print axioms FFL.FirstOrder.NFMachineCalibration.church_counting_of_readback
#print axioms FFL.FirstOrder.NFMachineCalibration.consistent_nfc_of_readback
