"""Reproduce the 183-state table by a byte-bound common-backend patch."""
from pathlib import Path
import hashlib,json

ROOT=Path(__file__).resolve().parent
PERMUTATION=[1,5,2,0,6,4,3,7,8]

def table(path):
    rows={}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):continue
        q,b,w,d,j=line.split()
        assert (q,b) not in rows
        rows[q,b]=(w,d,j)
    return rows

def rebuilt():
    old=table(ROOT/'reference/NF175/candidate.tm')
    new=table(ROOT/'reference/NF174/candidate.tm')
    base=table(ROOT/'reference/AxCount184/machine/candidate.tm')
    for edge in sorted(set(old)|set(new)):
        if old.get(edge)==new.get(edge):continue
        assert base.get(edge)==old.get(edge),('patch context mismatch',edge)
        if edge in new:base[edge]=new[edge]
        else:del base[edge]
    names={q for q,b in base}
    assert len(names)==183 and len(base)==366
    assert {j for w,d,j in base.values()}-names=={'halt'}
    text='#! start k:74\n'+''.join(' '.join((*edge,*base[edge]))+'\n' for edge in sorted(base))
    rows=json.loads((ROOT/'reference/AxCount184/machine/source.sites.json').read_bytes())
    mapped=[[p,op,PERMUTATION[arg] if op in ('CI','CD') else arg] for p,op,arg in rows]
    source=json.dumps(mapped,separators=(',',':'))+'\n'
    return text.encode(),source.encode()

if __name__=='__main__':
    table_bytes,source_bytes=rebuilt()
    assert table_bytes==(ROOT/'machine/candidate.tm').read_bytes()
    assert source_bytes==(ROOT/'machine/source.sites.json').read_bytes()
    print(json.dumps({'states':183,'source_sites':3397,'table_sha256':hashlib.sha256(table_bytes).hexdigest(),'source_sha256':hashlib.sha256(source_bytes).hexdigest(),'register_permutation':PERMUTATION},sort_keys=True))
