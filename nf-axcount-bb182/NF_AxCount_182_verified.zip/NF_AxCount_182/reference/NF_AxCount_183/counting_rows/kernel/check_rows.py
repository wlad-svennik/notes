"""Regenerate and kernel-check the 24 exact counting-row equivalences."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--checker', default='leanchecker-paranoid')
args = parser.parse_args()
here = Path(__file__).resolve().parent
checker = Path(shutil.which(args.checker) or args.checker).resolve()
if not checker.is_file():
    raise SystemExit('Pass --checker /absolute/path/to/leanchecker-paranoid')
proof = here / 'row_equivalences.ndjson'
generated = subprocess.run([sys.executable, here / 'generate_rows.py', proof],
    check=True, capture_output=True, text=True)
checked = subprocess.run([checker, '--from-export', proof],
    check=True, capture_output=True, text=True)
log = checked.stdout + checked.stderr
if 'Lean default kernel accepts the solution' not in log:
    raise RuntimeError(log)
(here / 'kernel.log').write_text(log)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipt = dict(status='accepted', checker_name=checker.name,
    checker_sha256=sha(checker), export_sha256=sha(proof),
    theorem_count=50, equivalent_20_token_rows=24,
    kernel_output=log.strip(),
    source_sha256={name: sha(here/name) for name in
        ['generate_rows.py', 'check_rows.py', 'export_syntax.py', 'eq_nat_prelude.ndjson']},
    scope='Pure equality equivalence of every image-binding counting row with the existing alias-head law. It does not assert a smaller physical state count or complete NF+AxCount calibration.')
(here / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
