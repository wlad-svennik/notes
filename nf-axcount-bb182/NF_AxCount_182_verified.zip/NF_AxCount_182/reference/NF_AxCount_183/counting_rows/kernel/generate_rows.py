"""Emit exact Lean kernel proofs for the 24 image-binding counting rows.

No Lean frontend, machine files, NF axioms, or counting assumptions are used.
Only the ordinary Eq/Nat inductive prelude is loaded by export_syntax.
Every new declaration is a theorem proved by equality recursion.
"""
import hashlib
import itertools
import json
from pathlib import Path
import sys

from export_syntax import C, V, Export, ap, arrow, lam, pi

OUT = Path(sys.argv[1] if len(sys.argv) > 1 else 'row_equivalences.ndjson')
TYPE = ('sort', 1)
U = V('U')
F, T = V('F'), V('T')
PREFIX = 'NFCountingRows.'
sig = [('U', TYPE), ('apply', arrow(U, U, U)), ('F', U), ('T', U)]
coords = [('a', U), ('b', U), ('c', U)]
app = lambda x, y: ap(V('apply'), x, y)
eq = lambda x, y: ap(C('Eq', 1), U, x, y)
refl = lambda x: ap(C('Eq.refl', 1), U, x)
read = lambda x: eq(app(app(F, app(F, x)), T), app(F, x))
law_type = pi([('x', U)], read(V('x')))


def symm(x, y, proof):
    motive = lam([('sym_y', U), ('sym_h', eq(x, V('sym_y')))], eq(V('sym_y'), x))
    return ap(C('Eq.rec', 0, 1), U, x, motive, refl(x), y, proof)


def app_word(x, y):
    return x + y + 'I1'


def equality_word(x, y):
    return x + y + 'I1'


rows = []
theorems = []
with OUT.open('wb') as stream:
    export = Export(stream)

    def put(name, params, typ, body):
        full = PREFIX + name
        export.declare(full, sig + params, typ, body, theorem=True)
        theorems.append(full)

    # Bind the existing 22-token row to the same unconditional law.
    a, b = V('a'), V('b')
    alias_result = eq(app(app(a, app(a, b)), T), app(a, b))
    alias_type = pi([('a', U), ('b', U), ('bind', eq(F, a))], alias_result)
    put('aliasHead_to_readback', [('old', alias_type)], law_type,
        lam([('x', U)], ap(V('old'), F, V('x'), refl(F))))
    motive = lam([('alias_value', U), ('alias_eq', eq(F, V('alias_value')))],
        eq(app(app(V('alias_value'), app(V('alias_value'), b)), T),
           app(V('alias_value'), b)))
    proof = ap(C('Eq.rec', 0, 1), U, F, motive, ap(V('law'), b), a, V('bind'))
    put('readback_to_aliasHead', [('law', law_type)], alias_type,
        lam([('a', U), ('b', U), ('bind', eq(F, a))], proof))

    for x_name, y_name in itertools.permutations('abc', 2):
        x, y = V(x_name), V(y_name)
        fx = app(F, x)
        left = app(app(F, y), T)
        for premise_reverse, conclusion_reverse in itertools.product((False, True), repeat=2):
            name = f'image_{x_name}_{y_name}_{int(premise_reverse)}_{int(conclusion_reverse)}'
            premise = eq(y, fx) if premise_reverse else eq(fx, y)
            result = eq(y, left) if conclusion_reverse else eq(left, y)
            row_type = pi(coords + [('bind', premise)], result)
            bind = symm(y, fx, V('bind')) if premise_reverse else V('bind')
            motive = lam([('image_value', U), ('image_eq', eq(fx, V('image_value')))],
                eq(app(app(F, V('image_value')), T), V('image_value')))
            proof = ap(C('Eq.rec', 0, 1), U, fx, motive, ap(V('law'), x), y, bind)
            if conclusion_reverse:
                proof = symm(left, y, proof)
            put('readback_to_' + name, [('law', law_type)], row_type,
                lam(coords + [('bind', premise)], proof))

            # Instantiate the premise with a reflexive equality.
            fresh = V('readback_arg')
            image = app(F, fresh)
            assignments = {x_name: fresh, y_name: image}
            args = [assignments.get(n, F) for n, _ in coords]
            proof = ap(V('row'), *args, refl(image))
            target_left = app(app(F, image), T)
            if conclusion_reverse:
                proof = symm(image, target_left, proof)
            put(name + '_to_readback', [('row', row_type)], law_type,
                lam([('readback_arg', U)], proof))

            wx, wy = x_name.upper(), y_name.upper()
            wfx, wleft = app_word('Z1', wx), app_word(app_word('Z1', wy), 'Z')
            wpremise = equality_word(wy, wfx) if premise_reverse else equality_word(wfx, wy)
            wresult = equality_word(wy, wleft) if conclusion_reverse else equality_word(wleft, wy)
            word = wpremise + wresult + 'I'
            assert len(word) == 20
            rows.append(dict(name=name, x=x_name, y=y_name,
                premise_reverse=premise_reverse, conclusion_reverse=conclusion_reverse,
                word=word, tokens=len(word),
                theorems=[PREFIX + 'readback_to_' + name, PREFIX + name + '_to_readback']))

manifest = dict(export_sha256=hashlib.sha256(OUT.read_bytes()).hexdigest(),
    export_bytes=OUT.stat().st_size, theorem_count=len(theorems),
    theorems=theorems, rows=rows,
    claim='Each of 24 image-binding 20-token rows is equivalent to the existing 22-token alias-head row, through the common unconditional readback law.',
    logical_assumptions='Arbitrary type U, binary application, and designated objects F,T. No set theory or Counting axioms.')
OUT.with_suffix('.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k:v for k,v in manifest.items() if k not in ('theorems','rows')}))
