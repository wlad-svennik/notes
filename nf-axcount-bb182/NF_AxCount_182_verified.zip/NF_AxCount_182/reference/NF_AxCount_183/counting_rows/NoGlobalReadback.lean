import CountSet

/-!
The tempting shortening (F x) T = x is inconsistent with FunctionNF.
It turns the represented graph from CountSet.liftGraph into a singleton map
on the entire universe, contradicting FnSets.cantor.
This source has not been replayed in Lean in the present workspace.
-/

set_option autoImplicit false

namespace FFL.FirstOrder.FNF

variable {M : Type} [Tarski.Structure ℒλ M] [Tarski.Structure.Eq ℒλ M] [Nonempty M]
  [M↓[ℒλ] ⊧* 𝗙𝗡𝗙]

local infixl:70 " ⬝ " => App

theorem no_global_readback (F T : M) : ¬ (∀ x, (F ⬝ x) ⬝ T = x) := by
  intro read
  obtain ⟨g, _, hmem⟩ := CountSet.liftGraph (pow (univ : M)) F T
  have spec (a b : M) : Ap g a b ↔ Mem a (pow (univ : M)) ∧ b = sing a := by
    change Mem (kp a b) g ↔ _
    rw [hmem]
    constructor
    · rintro ⟨x, y, w, t, hp, hx, rfl, rfl, rfl⟩
      have hp' : kp a b = kp x (sing x) := by simpa only [read] using hp
      obtain ⟨rfl, hb⟩ := kp_inj hp'
      exact ⟨hx, hb⟩
    · rintro ⟨ha, rfl⟩
      exact ⟨a, sing a, F ⬝ a, a, rfl, ha, rfl, read a, rfl⟩
  have inj : Inj g (pow (univ : M)) (simg (univ : M)) := by
    constructor
    · intro a b h
      obtain ⟨ha, rfl⟩ := (spec a b).mp h
      exact ⟨ha, mem_simg_sing.mpr (mem_univ a)⟩
    · intro a ha
      exact ⟨sing a, (spec a (sing a)).mpr ⟨ha, rfl⟩⟩
    · intro a b c hb hc
      exact ((spec a b).mp hb).2.trans ((spec a c).mp hc).2.symm
    · intro a b c ha hb
      exact sing_inj (((spec a c).mp ha).2.symm.trans ((spec b c).mp hb).2)
  exact cantor (univ : M) ⟨g, inj⟩

end FFL.FirstOrder.FNF

#print axioms FFL.FirstOrder.FNF.no_global_readback
