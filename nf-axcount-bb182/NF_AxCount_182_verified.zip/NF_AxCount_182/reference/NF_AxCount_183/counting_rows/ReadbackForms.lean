import Init

/-!
Pure equality facts used to refactor the fifth NF+AxCount axiom row.
No counting, set theory, extensionality, or nontriviality is assumed here.
The compiler's application and equality both use postfix I1; implication uses I.
This readable source has not been elaborated by a Lean frontend in this workspace.
Equivalent explicit proof terms, including all 24 coordinate/orientation variants,
have been freshly accepted by Lean's default kernel; see kernel/receipt.json.
-/

set_option autoImplicit false

namespace NFCounting.ReadbackForms

variable {V : Type} (app : V → V → V) (F T : V)

def Readback : Prop := ∀ x, app (app F (app F x)) T = app F x

def AliasHead : Prop :=
  ∀ a b, F = a → app (app a (app a b)) T = app a b

def AliasImage : Prop :=
  ∀ a b, app F a = b → app (app F b) T = b

def AliasImageRev : Prop :=
  ∀ a b, b = app F a → app (app F b) T = b

theorem aliasHead_iff_readback : AliasHead app F T ↔ Readback app F T := by
  constructor
  · intro h x
    exact h F x rfl
  · intro h a b e
    cases e
    exact h b

theorem aliasImage_iff_readback : AliasImage app F T ↔ Readback app F T := by
  constructor
  · intro h x
    exact h x (app F x) rfl
  · intro h a b e
    cases e
    exact h a

theorem aliasImageRev_iff_readback : AliasImageRev app F T ↔ Readback app F T := by
  constructor
  · intro h x
    exact h x (app F x) rfl
  · intro h a b e
    cases e
    exact h a

theorem aliasHead_iff_aliasImage : AliasHead app F T ↔ AliasImage app F T :=
  (aliasHead_iff_readback app F T).trans (aliasImage_iff_readback app F T).symm

end NFCounting.ReadbackForms

#print axioms NFCounting.ReadbackForms.aliasHead_iff_aliasImage
