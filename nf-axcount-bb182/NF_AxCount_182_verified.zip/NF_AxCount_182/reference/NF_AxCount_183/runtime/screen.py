"""Screen a related binary table and its register source before commissioning formal proofs."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from time import monotonic

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'boot'))
from discover import native, read_table

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('table', nargs='?', type=Path, default=ROOT / 'candidate.tm')
parser.add_argument('program', nargs='?', type=Path, default=ROOT / 'source.sites.json')
parser.add_argument('--probe', type=Path, help='previously compiled concrete fixture runner')
parser.add_argument('--boot-cap', type=int, default=500000)
parser.add_argument('--skip-boot',action='store_true',help='caller separately checks the exact boot and counter register')
args = parser.parse_args()
start = monotonic()
machine, _ = read_table(args.table)
todo = [machine.state]
reachable = set()
while todo:
    state = todo.pop()
    if state == 'halt' or state in reachable:
        continue
    reachable.add(state)
    todo.extend(machine.table[state, b][2] for b in (0, 1))
print(f'{len(reachable)} graph-reachable working states, {len(machine.table)} transitions', flush=True)
if not args.skip_boot:
    anchor = native(args.table, args.program, args.boot_cap, 0)['final']
    print(f'Blank-tape scanner at step {anchor["step"]}, registers {anchor["frame"]["registers"]}', flush=True)

with TemporaryDirectory() as folder:
    work = Path(folder)
    source, table = work/'source.txt', work/'table.txt'
    rows = json.loads(args.program.read_bytes())
    with source.open('w') as out:
        for address, op, index in rows:
            print(address, op, index, file=out)
    names = sorted({name for name, bit in machine.table})
    ids = {name: i for i, name in enumerate(names + ['halt'])}
    with table.open('w') as out:
        print(len(names), ids[machine.state], ids['d:0'], ids.get('k:302', -1), file=out)
        for q in names:
            for b in (0, 1):
                write, shift, dest = machine.table[q, b]
                print(write, shift, ids[dest], file=out)
    probe = args.probe
    if probe is None:
        probe = work/'probe'
        subprocess.run([os.environ.get('CXX', 'c++'), '-O2', '-std=c++17',
                        ROOT/'screen/probe.cpp', '-o', probe], check=True)
    subprocess.run([probe.resolve(), source, table], check=True)
print(f'Candidate screen took {monotonic() - start:.2f} seconds.')
