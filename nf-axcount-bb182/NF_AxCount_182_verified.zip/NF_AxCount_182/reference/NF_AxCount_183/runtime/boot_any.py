from pathlib import Path
import sys,json,hashlib
D=Path(sys.argv[1]);cap=int(sys.argv[2])if len(sys.argv)>2 else 300000
lines=(D/'candidate.tm').read_text().splitlines();T={(q,int(b)):(int(w),1 if d=='R'else-1,r)for l in lines[1:]for q,b,w,d,r in[l.split()]};q=lines[0].split()[-1];h=0;t=set();rows=json.loads((D/'source.sites.json').read_bytes());pc0=rows[0][0]
counter=int(sys.argv[3])if len(sys.argv)>3 else 0
expected=[0]*9;expected[counter]=int(sys.argv[4])
def check():
 if not t or h-1 not in t or min(t)!=h-1:return
 if ''.join(str(int(h+j in t))for j in range(len(pc0)))!=pc0:return
 j=h+len(pc0);right=max(t)
 while j<=right and j not in t:j+=1
 if j>right or j+1 in t or j-h<49:return
 gap=j-h;j+=2;vals=[]
 while j<=right:
  begin=j
  while j in t:j+=1
  if j==begin:return
  vals.append(j-begin-2);j+=1
 if len(vals)<9 or any(a!=-1 for a in vals[9:]):return
 order=[2,8,1,4,3,7,0,5,6];rs=[0]*9
 for k,v in zip(order,vals):rs[k]=v
 if rs!=expected:return
 return gap,len(vals)-9
for step in range(cap+1):
 if q=='d:0':
  ok=check()
  if ok:
   result=dict(steps=step,head=h,gap=ok[0],spares=ok[1],registers=expected,ones=sorted(t),table_sha256=hashlib.sha256((D/'candidate.tm').read_bytes()).hexdigest());(D/'boot.json').write_text(json.dumps(result,separators=(',',':')));print('verified',step,h,ok,'ones',len(t));break
 if q=='halt':print('halt before epoch',step);sys.exit(2)
 b=int(h in t);w,d,q=T[q,b];t.discard(h)
 if w:t.add(h)
 h+=d
else:print('no epoch within cap',cap);sys.exit(3)
