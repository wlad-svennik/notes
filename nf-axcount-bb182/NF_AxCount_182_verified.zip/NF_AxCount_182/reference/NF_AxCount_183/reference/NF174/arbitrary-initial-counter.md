# Calibration from an arbitrary finite warm counter

## Statement

Consider the literal pure-NF census source, entered at the same clean scanner/refill control point used by the verified blank boot. Let its counter register R0 contain any fixed natural number N, and let registers R1,...,R8 be zero. Assume the associated binary frame satisfies the already verified frame preconditions for the particular table: scanner state and head position, tape encoding, header gap, and spare cells. Then the ensuing computation halts if and only if the same pure-NF goal is derivable. The numerical value N need not equal 3. In particular, warm counters 1, 4, and 6 are admissible under the same frame and control-point hypotheses.

This statement changes only the initial enumerated epoch. It does not assert that an arbitrary program counter or an inadequately spaced binary frame is a valid entry.

## Exact source evidence

The formal command-boundary model in `logic/src/SourceEnumeration.lean` already quantifies over arbitrary `start : Nat` in `scan_eventually_halts` and `stream_halting_iff_goal`. The latter assumes only that the initial proof state is sound. `logic/src/SourceFields.lean` proves `cofinal(cs,bound)` for every bound, not just a particular initial index.

Those formal command-boundary statements are not by themselves the complete binary-to-literal-moving-census bridge. The applicable bridge for this machine is the separate standard-natural argument in `search/MarkerProof.md`, together with its checked finite marker analysis. That argument explicitly allows an arbitrary starting epoch and fixed initial rank r0. Its assumptions do not prescribe counter 3.

All cited paths are relative to `/workspace/scratch/d8762c1c27df/work/NF_177_Verification`.

## Completeness argument with the new initial counter

Fix a derivation of the goal and the associated finite detecting command word W. Its proof-word construction works from every sound proof payload at rank zero. Prefix W by the six synchronization commands from `MarkerProof.md`, and call the resulting raw encoding z. Its final continuation may be padded so that every relevant right tail is at least 100.

Choose K large enough that K exceeds N+3 and that, for n=P(K,z+1),

    K^16 > 100 D,       D = r0 + (n+2)^2 + 1.

Such a K exists: with z fixed, n grows quadratically in K, whereas the left side has degree16. Here r0=0 for the stated clean entry. Taking K>N+3 also ensures that all three epochs n−2, n−1, and n lie beyond the initial epoch.

If the machine has not already halted, it reaches every one of those epochs. Every command performs finitely many batches, each nonfinal command strictly decreases its remaining cursor, and each completed epoch advances the natural counter. Beginning at N rather than 3 only removes finitely many earlier epochs.

The rank bound used by the marker proof remains valid. The total of raw tags during epoch m is at most m, so the contribution from epochs N through n is bounded by the contribution from epochs 0 through n. Therefore the same deliberately generous bound D applies; no subtraction or correction term is needed.

The three-epoch analysis now applies unchanged. At n−2 it aligns with the prescribed word or leaves a cache covering the residual rank. At n−1 it aligns or leaves zero rank. At n the forced command and the six prescribed commands preserve zero rank and reach W. W then observes the goal. Earlier alignment or an earlier halt is already sufficient.

## Soundness

The initial all-zero proof payload is sound because numerical zero is a theorem of the retained calculus. The proof-register soundness invariant and the goal-observation argument do not depend on the counter's finite starting value. Hence starting later cannot introduce a spurious refutation. Combined with the previous completeness argument, this proves the stated equivalence.

## What is and is not newly verified here

The extension in the initial natural counter is already present in the hypotheses of the existing formal enumerator and in the literal marker argument. No new exhaustive search is needed for that extension. Each moved-selector host must still separately establish that its blank computation reaches the stated clean control point with a valid binary frame, and that its subsequent primitive or invariant-restricted simulation obligations hold. This note does not replace those table-specific checks and does not assert a new state-count improvement.
