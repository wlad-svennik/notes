"""Independent proof checker for the nf-symbolic-frames-v1 register simulation.

Pass a directory containing candidate.tm, source.sites.json and traces.gz.
The endpoint equality decision represents each binary ray by its exact dyadic
fraction as a multivariate polynomial in powers of the unknown run lengths.
This checker does not import the compiler, trace writer, or source CFG library.
"""
import argparse
from collections import deque
from fractions import Fraction
from functools import lru_cache
import gzip
from hashlib import sha256
import json
from pathlib import Path

ORDER=(2,8,1,4,3,7,0,5,6)
NVAR=11

def read_table(data):
    lines=data.decode().splitlines()
    assert lines[0].startswith('#! start ')
    start=lines[0].split()[-1]
    rows=[line.split() for line in lines[1:] if line.strip()]
    names=sorted({r[0] for r in rows})
    assert 'halt' not in names and start in names and len(rows)==2*len(names)
    ids={name:i for i,name in enumerate(names)}
    ids['halt']=-1
    t={}
    for q,b,w,d,j in rows:
        key=(ids[q],b)
        assert key not in t and b in ('0','1') and w in ('0','1') and d in ('L','R')
        t[key]=(w,{'L':-1,'R':1}[d],ids[j])
    seen={ids[start]}
    q=deque(seen)
    while q:
        state=q.popleft()
        for b in '01':
            j=t[state,b][2]
            if j>=0 and j not in seen:seen.add(j);q.append(j)
    assert len(seen)==len(names)
    return t,ids,ids[start]

def flow(sites):
    paths=[r[0] for r in sites]
    assert paths==sorted(set(paths))
    spans={}
    for i,p in enumerate(paths):
        for j in range(len(p)+1):spans.setdefault(p[:j],[i,i])[1]=i+1
    leaves=set(paths)
    assert all((p+'0' in spans)==(p+'1' in spans)==(p not in leaves) for p in spans)
    edges={}
    for pc,(p,op,k) in enumerate(sites):
        assert op in ('CI','CD','CB','CC')
        for zero in ((False,True) if op=='CD' else (False,)):
            if zero and p.endswith('1'): edges[pc,zero]=None;continue
            if op=='CI' or (op=='CD' and not zero):
                dest=pc+1
            elif op=='CD': dest=spans[p[:p.rindex('0')]][1]
            else:
                bit='1' if op=='CC' else '0'
                for _ in range(k):p=p[:p.rindex(bit)]
                dest=spans[p][0 if op=='CC' else 1]
            edges[pc,zero]=(dest%len(sites),int(dest==len(sites)))
    return edges

def exact_boot(path,t,ids,start,sites,base_gap):
    rec=json.loads(path.read_bytes())
    if not {'head','steps','ones','gap','registers','spares'}<=set(rec):return None
    q=start;head=0;ones=set()
    for _ in range(rec['steps']):
        w,d,q=t[q,str(int(head in ones))]
        if w=='1':ones.add(head)
        else:ones.discard(head)
        head+=d
    assert (q,head,sorted(ones))==(ids['d:0'],rec['head'],rec['ones'])
    regs=rec['registers']; g=rec['gap']; s=rec['spares']
    spares=[0]*s if isinstance(s,int) else s
    assert g>=base_gap and len(spares)>=24 and all(v==0 for v in spares)
    p=sites[rec.get('ordinal',0)][0]
    word='1'+p+'0'*(g-len(p))+'1'
    word+=''.join('0'+'1'*(regs[j]+2) for j in ORDER)
    word+=''.join('0'+'1'*(v+1) for v in spares)
    assert {head-1+i for i,b in enumerate(word) if b=='1'}==ones
    return rec['steps']

def frame(site,regs,gap,extra_spares):
    # Each tuple (variable,word) denotes word repeated n[variable] times.
    p=site[0]
    assert gap-len(p)>=5
    word=list('1'+p+'0'*(gap-len(p)-5))+[(9,'0')]+list('000001')
    for j in ORDER:
        val,variable=regs[j]
        word.extend('0'+'1'*(1+val))
        if variable:word.append((j,'1'))
        word.append('1')
    word+=list('01'*12)+[(10,'01')]+list('01'*(12+extra_spares))
    return word

@lru_cache(maxsize=20000)
def ray_value(ray):
    # The nearest bit is the coefficient of 1/2. Trailing implicit zeroes disappear.
    result={}
    scale=Fraction(1); variables=0; i=0
    while i<len(ray):
        token=ray[i]
        if isinstance(token,str):
            j=i+1
            while j<len(ray) and isinstance(ray[j],str):j+=1
            bits=''.join(ray[i:j])
            denominator=1<<len(bits)
            value=scale*int(bits,2)/denominator
            result[variables]=result.get(variables,0)+value
            scale/=denominator
            i=j
        else:
            num,word=token
            assert not (variables>>num)&1 and len(word)==(2 if num==10 else 1)
            c=scale*Fraction(int(word,2),(1<<len(word))-1)
            result[variables]=result.get(variables,0)+c
            variables|=1<<num
            result[variables]=result.get(variables,0)-c
            i+=1
    return tuple(sorted((v,c) for v,c in result.items() if c))

def check_pump(table,rule):
    q=rule['q']; d=rule['dir']; c=rule['context']; u=rule['unit']; v=rule['output']
    assert d in (-1,1) and len(u)==len(v)>0 and all(b in '01' for b in c+u+v)
    tape=list(c+u); h=len(c); state=q
    for _ in range(rule['ticks']):
        assert 0<=h<len(tape) and state>=0
        w,move,state=table[state,tape[h]]
        tape[h]=w;h+=move*d
    assert (h,state,''.join(tape))==(len(tape),q,v+c)

def take(ray):
    return ray.popleft() if ray else '0'

def replay(table,ids,sites,edges,gap,rules,tr,counter=0):
    i,zero,cold=tr['pc'],tr['zero'],tr['cold']
    p,op,a=sites[i]
    vals=[(0,True)]*9
    if cold:vals[counter]=(-1,False)
    if op=='CD':vals[a]=(0,False) if zero else (1,True)
    w=frame(sites[i],vals,gap,0)
    sides={-1:deque(w[:1]),1:deque(w[1:])}
    state=ids['d:0']; facing=1
    h=[0]*(NVAR+1);clock=h.copy()
    for action in tr['actions']:
        assert state>=0
        if action>0:
            for _ in range(action):
                ahead=sides[facing]
                b=take(ahead)
                assert isinstance(b,str) and state>=0
                w,move,state=table[state,b]
                h[0]+=move;clock[0]+=1
                if move==facing:sides[-facing].appendleft(w)
                else:ahead.appendleft(w);facing=move
        elif action==0:
            side=sides[facing]
            ix,unit=side.popleft()
            lit=side.popleft()
            assert lit==unit[0]
            side.extendleft(((ix,unit[1:]+lit),lit))
        else:
            rule=rules[-1-action]
            assert (state,facing)==(rule['q'],rule['dir'])
            ix,unit=sides[facing].popleft()
            assert unit==rule['unit']
            tail=sides[-facing]; c=rule['context']
            for b in c[::-1]:assert take(tail)==b
            tail.appendleft((ix,rule['output'][::-1]))
            tail.extendleft(c)
            h[ix+1]+=facing*len(unit);clock[ix+1]+=rule['ticks']
    assert clock[0]>0 and tr['clock']==clock
    out=edges[i,zero]
    if out is None:assert state==-1;return
    pc,wrap=out
    assert state==ids['d:0'] and h==[-wrap]+[0]*NVAR
    delta=int(op=='CI')-int(op=='CD' and not zero)
    if op in ('CI','CD'):vals[a]=(vals[a][0]+delta,vals[a][1])
    after=frame(sites[pc],vals,gap+wrap+int(delta<0),int(delta>0))
    if facing<0:
        b=take(sides[-1]);assert isinstance(b,str);sides[1].appendleft(b)
    assert ray_value(tuple(sides[-1]))==ray_value(tuple(after[:1]))
    assert ray_value(tuple(sides[1]))==ray_value(tuple(after[1:]))

def audit(folder,trace='traces.gz',counter=0):
    tb=(folder/'candidate.tm').read_bytes();so=(folder/'source.sites.json').read_bytes()
    table,ids,start=read_table(tb)
    sites=json.loads(so);edges=flow(sites)
    cert=json.loads(gzip.decompress((folder/trace).read_bytes()))
    assert cert['format']=='nf-symbolic-frames-v1'
    assert (cert['table'],cert['source'])==(sha256(tb).hexdigest(),sha256(so).hexdigest())
    rules=cert['pumps']
    for r in rules:check_pump(table,r)
    expected={(i,z,c) for i,z in edges for c in (False,True)
              if not (c and sites[i][1:] == ['CD',counter])}
    for tr in cert['traces']:
        key=(tr['pc'],tr['zero'],tr['cold'])
        expected.remove(key)
        try: replay(table,ids,sites,edges,cert['base_gap'],rules,tr,counter)
        except Exception as err:raise AssertionError(('symbolic branch',key)) from err
    assert not expected
    boot=exact_boot(folder/'boot.json',table,ids,start,sites,cert['base_gap']) if (folder/'boot.json').exists() else None
    return dict(states=len(table)//2,source_sites=len(sites),branches=len(cert['traces']),pumps=len(rules),
                boot_steps=boot,table_sha256=sha256(tb).hexdigest(),source_sha256=sha256(so).hexdigest())

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('folder',type=Path);ap.add_argument('--trace',default='traces.gz')
    ap.add_argument('--counter',type=int,default=0);args=ap.parse_args()
    print(json.dumps(audit(args.folder,args.trace,args.counter),sort_keys=True))
