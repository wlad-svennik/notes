"""Bind a staged AxCount emitter to its source graph, the 175 donor and the numerical rows."""
import argparse, hashlib, json
from pathlib import Path
from functools import lru_cache

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def graph(rows):
 ranges={}
 for pc,(a,_,_) in enumerate(rows):
  for j in range(len(a)+1):ranges.setdefault(a[:j],[pc,pc])[1]=pc+1
 def jump(p,b,n,side):
  for _ in range(n):p=p[:p.rindex(b)]
  return ranges[p][side]%len(rows)
 out=[]
 for i,(p,o,k)in enumerate(rows):
  nxt=(i+1)%len(rows)
  if o=='CI':succ=(nxt,)
  elif o=='CD':succ=(nxt,None if p.endswith('1')else jump(p,'0',1,1))
  elif o=='CC':succ=(jump(p,'1',k,0),)
  elif o=='CB':succ=(jump(p,'0',k,1),)
  else:raise ValueError(o)
  out.append(succ)
 return out

def local(rows,g,a,b):
 return tuple((o,k,tuple(None if j is None else j-a for j in g[a+i]))for i,(p,o,k)in enumerate(rows[a:b]))
# Names and primitive operation spans in one 186-release batch, checked against full normalized CFGs below.
SEEDS={'D':(39,42),'C':(42,68),'A':(68,94),'I':(94,119),'V':(119,130),'W':(130,133),'B':(210,236)}
BASEWORD='DCAIVWAIACIBCIIIBBI11AI1BI1ZZAI1I1ZI1ZAI1I1ACI1ABI1I1IACI1ABI1I1IABI1ACI1CBI1IIZ1CI1AI1BI1CBBI11I1ABI1I1I1CBI1ACI1ABI1I1IACI1CBI1ABI1I1IZBBI11I1AI1BI1ZBBI11I1BI1BI1IABI1IBABI11I1AABI11I1I1ABI1I'
LENS={'D':3,'A':26,'B':26,'C':26,'I':25,'V':11,'W':3,'1':1,'Z':19}

def scope(rows):
 ii=[i for i,(p,_,_)in enumerate(rows)if p.startswith('1101010')];assert ii==list(range(ii[0],1+ii[-1]));return ii[0],ii[-1]+1

def vocabulary(base):
 g=graph(base);i=scope(base)[0];d={}
 for v in BASEWORD:
  size=LENS[v];pattern=local(base,g,i,i+size)
  assert v not in d or d[v]==pattern,(v,i);d[v]=pattern;i+=size
 assert i==scope(base)[1]
 assert all(0<=j<=len(z)for z in d.values()for _,_,succ in z for j in succ)
 return d

def decode(rows,vocab):
 g=graph(rows);lo,hi=scope(rows);at=lo;w=[]
 while at<hi:
  matches=[v for v,pat in vocab.items() if at+len(pat)<=hi and local(rows,g,at,at+len(pat))==pat]
  assert matches,(at,rows[at]);v=max(matches,key=lambda v:len(vocab[v]));w.append(v);at+=len(vocab[v]);
 return ''.join(w),g

def terms(w):
 def read(i):
  while w[i]in '1VW':i-=1
  return read(read(i-1)-1)if w[i]=='I'else i
 out=[];h=len(w)
 while h>0 and not(h==1 and w[0]=='D'):
  l=read(h-1);out.append(w[l:h]);h=l
 return out[::-1]

def norm(w):
 # (base,offset) records the nonconstant part and a natural offset. Move all offsets of I's
 # right argument to its left by I(x,y+c)=I(x+c,y)+2c. Fold closed integrals numerically.
 stack=[]
 for a in w:
  if a in 'ZABC':stack.append((None,0)if a=='Z'else(a,0))
  elif a=='1':x,n=stack.pop();stack.append((x,n+1))
  elif a=='I':
   y,b=stack.pop();x,c=stack.pop();
   if x is None and y is None:n=b+c;stack.append((None,n*(n+1)+2*b))
   else:stack.append((('I',x,b+c,y),2*b))
  else:raise ValueError(a)
 assert len(stack)==1
 return stack[0]

def audit(d,nf,base):
 def read(p):return json.loads((p/'source.sites.json').read_bytes())
 ss,nn,bb=map(read,(d,nf,base));v=vocabulary(bb);word,es=decode(ss,v);ref,en=decode(nn,v);slo,shi=scope(ss);nlo,nhi=scope(nn);assert slo==nlo
 def tr(i):
  if i is None:return None
  if i<=nlo:return i
  assert i>=nhi;return i+shi-nhi
 for i in list(range(nlo))+list(range(nhi,len(nn))):
  assert nn[i][1:]==ss[tr(i)][1:]and tuple(map(tr,en[i]))==es[tr(i)]
 r0=terms(ref);rr=terms(word);assert r0[0]==rr[0]=='CAIVWAIACIBCIII';kel='BBI11AI1BI1';assert kel==r0[2] and r0[1]=='Z';last=r0[-2:];assert rr[-2:]==last
 btag=next(z for z in r0 if z.startswith('Z1C'));expected_b=norm('Z111'+btag[2:]);fixed=[z for z in r0[1:]if z not in ('Z',btag)];cf=[z for z in rr[1:]if z!='Z'];counting={norm('Z1Z1'+x+'I1I1ZI1Z1'+x+'I1I1'):(x,0)for x in 'ABC'};counting.update({norm('Z1'+x+'I1Z1Z1'+x+'I1I1ZI1I1'):(x,1)for x in 'ABC'})
 mods=[z for z in cf if z not in fixed];assert sorted(z for z in cf if z in fixed)==sorted(fixed);assert len(mods)==2;alias_row="Z1AI1AABI1I1ZI1ABI1I1I"
 # E(F,A) -> E((A(AB))T,AB). The same variable A supplies all F occurrences.
 # One comparison suffices because norm() checks the full arithmetic expression.
 counting[norm(alias_row)]=("B",0,"F=A")
 newb,bread=next((u,t)for u in mods for t in mods if t!=u and norm(u)==expected_b and norm(t)in counting)
 assert rr.index(kel) in (1,2) and (rr.index(kel)==1 or rr[1]=='Z')
 return dict(source_sha256=digest(d/'source.sites.json'),reference_sha256=digest(nf/'source.sites.json'),table_sha256=digest(d/'candidate.tm'),source_sites=len(ss),emitter=[slo,shi],macro_tokens=len(word),ordered_rows=rr,unchanged_exterior_sites=len(nn)-(nhi-nlo),readback_parameter=list(counting[norm(bread)]),logical_zero_rows=rr.count('Z'),abstraction_numeral=3,goal_numeral=3)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('machine',type=Path);a.add_argument('nf175',type=Path);a.add_argument('ax186',type=Path);v=a.parse_args();print(json.dumps(audit(v.machine,v.nf175,v.ax186),sort_keys=True))
