"""Generate closed Lean kernel proofs of the algebra in the separated counting presentation."""
import hashlib,json,os,sys
from pathlib import Path
engine,machine,out=[Path(x).resolve() for x in sys.argv[1:]]
os.environ['NF_TABLE']=str(machine/'candidate.tm');os.environ['NF_TRACES']=str(machine/'traces.gz')
sys.path.insert(0,str(engine))
from kernel_pumps import *
CARRIER=V('Carrier')
BOT=pi([('PropVar',PROP)],V('PropVar'))
def neg(prop):return arrow(prop,BOT)
def at(x,*xs):
    for y in xs:x=('app',x,y)
    return x
def box(x):return 'K',x
def value(x):
    if isinstance(x,str):return V(x)
    if x[0]=='K':return ap(V('kon'),value(x[1]))
    return ap(V('apply'),value(x[1]),value(x[2]))
def claim(x,y):return EQ(CARRIER,value(x),value(y))
def no(x,y):return neg(claim(x,y))
def point(names):return [(n,CARRIER) for n in names]
def law(name,*a):return ap(V(name),*(value(x) for x in a))
SLOT='argHole'
def subst(p,x):
    if isinstance(p,str):return x if p==SLOT else p
    return tuple([p[0],*[subst(v,x) for v in p[1:]]])
def cert(x,y,h):return x,y,h
def congr(context,t):
    x,y,h=t
    return cert(subst(context,x),subst(context,y),
                F('congr',CARRIER,CARRIER,lam([(SLOT,CARRIER)],value(context)),value(x),value(y),h))
def reverse(t):
    x,y,h=t;return cert(y,x,F('symm',CARRIER,value(x),value(y),h))
def compose(*ts):
    x,y,h=ts[0]
    for b,z,k in ts[1:]:
        assert y==b,(y,b)
        h=F('trans',CARRIER,value(x),value(y),value(z),h,k);y=z
    return cert(x,y,h)
def kapp(x,y):return cert(at(box(x),y),x,law('Klaw',x,y))
def bapp(f,g,x):return cert(at('B',f,g,x),at(f,box(x),at(g,x)),law('Blaw',f,g,x))
def read(x):return cert(at('F',at('F',x),'T'),at('F',x),law('readback',x))
def off(x,y,ne):return cert(at('T',box(x),y),x,ap(law('off',x,y),ne))
TT=cert(at('T','T'),'F',V('TT'))
FT=cert(at('F','T'),'B',V('FT'))
sig=[('Carrier',TYPE),('apply',arrow(CARRIER,CARRIER,CARRIER)),('kon',arrow(CARRIER,CARRIER))]+point(['B','T','F'])
sig+=[('Klaw',pi(point(['x','y']),claim(at(box('x'),'y'),'x'))),
      ('Blaw',pi(point(['f','g','x']),claim(at('B','f','g','x'),at('f',box('x'),at('g','x'))))),
      ('ext',pi(point(['x','y'])+[('each',pi(point(['p']),claim(at('x','p'),at('y','p'))))],claim('x','y'))),
      ('off',pi(point(['x','y'])+[('distinct',no('x','y'))],claim(at('T',box('x'),'y'),'x'))),
      ('on',pi(point(['x']),no(at('T',box('x'),'x'),'x'))),('TT',claim(at('T','T'),'F')),
      ('FT',claim(at('F','T'),'B')),('separate',no('F','T')),
      ('readback',pi(point(['x']),claim(at('F',at('F','x'),'T'),at('F','x'))))]
def hyp(n,*args):return F(n,*(V(s) for s,_ in sig),*args)
def ne_rev(x,y,proof):
    return lam([('contra',claim(y,x))],ap(proof,reverse(cert(y,x,V('contra')))[2]))
def declare(n,extra,typ,pf):e.declare(PRE+n,sig+extra,typ,pf,theorem=True)
def ext(x,y,var,equality):
    assert equality[:2]==(at(x,var),at(y,var))
    return cert(x,y,ap(law('ext',x,y),lam(point([var]),equality[2])))
def internal_ex(name,test):return pi([('targetProp',PROP),('use',pi(point([name])+[('witnessEq',test)],V('targetProp')))],V('targetProp'))
with out.open('wb') as stream:
    e=Export(stream);arithmetic(e)
    x,y,z='x','y','z';kx=box(x);kk=box(kx)
    lhs=compose(bapp(kk,y,z),congr(at(SLOT,at(y,z)),kapp(kx,box(z))),kapp(x,at(y,z)))
    rhs=compose(congr(at(SLOT,z),kapp(kx,y)),kapp(x,z))
    eqz=compose(lhs,reverse(rhs))
    eqy=ext(at('B',kk,y),at(kk,y),z,eqz)
    bk=ext(at('B',kk),kk,y,eqy)
    declare('countFixK2',point([x]),claim(*bk[:2]),bk[2])
    kt=box('T');kkt=box(kt)
    test=congr(at(SLOT,kkt,kt),cert('B','T',V('wrong')))
    bkn=compose(congr(at(SLOT,kt),cert(at('B',kkt),kkt,hyp('countFixK2',value('T')))),kapp(kt,kt))
    dispute=compose(reverse(test),bkn)
    declare('countBneT',[],no('B','T'),lam([('wrong',claim('B','T'))],ap(law('on',kt),dispute[2])))
    bne=hyp('countBneT');tnb=ne_rev('B','T',bne)
    left=compose(bapp('T',kt,'B'),congr(at('T',box('B'),SLOT),kapp('T','B')),off('B','T',bne))
    right=off('T','B',tnb)
    bad=congr(at(SLOT,kt,'B'),cert(at('B','T'),'T',V('wrong')))
    contradiction=compose(reverse(left),bad,right)
    declare('countBTneT',[],no(at('B','T'),'T'),lam([('wrong',claim(at('B','T'),'T'))],ap(bne,contradiction[2])))
    fx=at('F',x);fy=at('F',y);fz=at('F',z)
    bad=cert(fx,'T',V('wrong'));rt=compose(reverse(congr(at(SLOT,'T'),FT)),reverse(congr(at('F',SLOT,'T'),bad)),read(x),bad)
    declare('countToutside',point([x]),no(fx,'T'),lam([('wrong',claim(fx,'T'))],ap(hyp('countBTneT'),rt[2])))
    h=cert(at('F',fx),at('F',fy),V('same'));inj=compose(reverse(read(x)),congr(at(SLOT,'T'),h),read(y))
    declare('countInjection',point([x,y])+[('same',claim(*h[:2]))],claim(fx,fy),inj[2])
    triple=compose(bapp('T','T','T'),congr(at('T',kt,SLOT),TT),off('T','F',ne_rev('F','T',V('separate'))))
    declare('countThirdIsT',[],claim(*triple[:2]),triple[2])
    def prev(z,x,assumption):
        h=cert(at('F',at('F',x)),at('F',z),V(assumption))
        return compose(reverse(congr(at(SLOT,'T'),h)),read(x))
    b0=compose(reverse(congr(at(SLOT,'T'),FT)),prev('T',x,'pred1'))
    b1=compose(congr(at(SLOT,'T'),b0),prev(x,y,'pred2'))
    b2=compose(congr(at(SLOT,'T'),b1),prev(y,z,'pred3'))
    fzt=compose(reverse(b2),triple)
    ps=[('pred1',claim(at('F',fx),at('F','T'))),('pred2',claim(at('F',fy),fx)),('pred3',claim(at('F',fz),fy))]
    declare('countNoThreePreimages',point([x,y,z])+ps,BOT,ap(hyp('countToutside',value(z)),fzt[2]))
    def exists_predecessor(obj):
        return internal_ex('v',claim(at('F',at('F','v')),at('F',obj)))
    onto=pi(point(['obj']),exists_predecessor('obj'))
    result=hyp('countNoThreePreimages',value(x),value(y),value(z),*(V(n) for n,t in ps))
    for i,(obj,v) in reversed(list(enumerate([('T',x),(x,y),(y,z)]))):
        result=ap(V('onto'),value(obj),BOT,lam(point([v])+[ps[i]],result))
    declare('countNotOnto',[],neg(onto),lam([('onto',onto)],result))
print(json.dumps(dict(sha256=hashlib.sha256(out.read_bytes()).hexdigest(),bytes=out.stat().st_size,
    theorems=['countFixK2','countBneT','countBTneT','countToutside','countInjection','countThirdIsT','countNoThreePreimages','countNotOnto'])))
