# Unconditional Counting with the tester at code zero

The numerical language of the 186-state machine already contains all the terms needed for a shorter Counting schema. Let the primitive object at code zero be T, put F = TT, and use B = FT as the native abstraction head. The corresponding term codes are 0, 1 and 3. The distinguished false goal remains the formula F = T at formula code 3. Term and formula codes have overlapping sorts.

Retain constant functions, the two application congruences, Euclidean equality, the logical axiom, extensionality and the variable tester at T. The B equation uses the new term at code 3. Replace the guarded Counting axiom by the single unconditional equation

\[
 (F(Fx))T = Fx\quad\text{for every }x.
\]

In chronological postfix notation the original Counting row has 38 tokens. The new row uses 19 with `Z1Z1AI1I1ZI1Z1AI1I1`, where `Z1` writes the numeral 1. The abstraction row begins with `Z111` in place of `Z1`. The canonical combined edit saves 17 macro tokens. Each token costs a variable number of physical states.

## The implementation at 184 states

The fifth chronological row of the released machine uses the universally quantified two-variable formula

\[
 F=a \;\Longrightarrow\; (a(ab))T=ab.
\]

Its postfix word is `Z1AI1AABI1I1ZI1ABI1I1I`, with A and B the numerical parameters a and b. In any extensional quotient satisfying the old equality schemata this formula follows from unconditional readback by substitution under F=a. Conversely take a=F and detach with reflexivity. The paired K and Euclidean rows derive F=F even before quotient extraction. No extra symbol is added to the object language. The upper and lower proofs below apply literally to the resulting condition. The released B row starts `Z1ZI1`, a direct construction of the ground numeral 3; the literal logical row still consumes the same one input field. See `Census_transfer.md` for the source and ten-row reachability proof.

## The lower interpretation

In a classical countervaluation for the designated goal, F and T are distinct. Use the original equality, K, congruence and extensionality schemata to form the extensional quotient with application, constant operation K and native B law. The free choice of representatives in the last extensionality slot with second coordinate zero still works because the remaining schemata use only the diagonal of the witness H. As in the parent, the tester row and nontriviality imply (T(Kx))y = x for y distinct from x, and (T(Kx))x differs from x. In the quotient F = TT, B = FT and F ≠ T.

The B law and extensionality give B(K²x) = K²x. Indeed, for every y,z both sides at y and then z have value x. B and T consequently differ. Equality would imply (T(K²x))(Kx) = Kx, contrary to the tester diagonal law. Also BT differs from T. Assuming them equal and evaluating both at KT and B gives B on the left and T on the right, using the two off-diagonal laws and B ≠ T.

Put D = im(F). The new equation gives (Fy)T = y for all y in D. F takes D into D and is injective there. T lies outside D because (FT)T = T would give BT = T. Meanwhile B = FT belongs to D. If F mapped D onto D, D would be closed under y ↦ yT, since each y would be Fv for some v in D. Applying this operation three times to B gives

\[
 ((BT)T)T = (T(KT))(TT) = T,
\]

where TT = F differs from T. This contradicts T outside D.

The conversion to NFU with Dedekind Infinity and full internal Rosser Counting uses the existing theorem `ArbitraryBoolean.countingModel F T`. Its two algebraic premises are precisely the new equation and the existence of a missing point for F on its image, established above. To supply its Boolean basis, start with the extensional B,K basis and the variable tester at T. The weak-tester construction in `VariableDetector.lean` and `CountingModel.lean` uses the tester's two laws and extensional separation. It chooses four successive separating arguments after finding unequal tester values. `NF196.Weak.weakBasis` on the resulting fixed-value tester gives the required Boolean basis with exactly the original application. This argument avoids imposing the old `Marked.letter` equation TT=B on the new chart. The independent Lean-kernel check of the new proper-injection algebra is in the accompanying lower-proof receipt.

## The upper interpretation

Start with the full function chart obtained from a model of pure NF with AxCount in `PriorCountingUpper.md`, through the construction and swap of the surjective reader q. Use its chain labels a₀=q,a₁,a₂,… indexed by the internal naturals, its fixed distinct probe labels P(t) and its marker values u=a₁ and v=a₂. A positive chain row aₙ₊₁ has default value aₙ, with its exceptional argument at a₁. The identity

\[
 qz=\{t:z(P(t))=u\}
\]

holds for all z distinct from q and the other swapped label h. B and K are the native operations of this completed chart. B has infinite range, differs from q, all positive chain labels and all constant rows, and fixes K²x for every x. These are exactly the preliminary facts proved in the parent upper construction and precede its choice of tester.

Choose F as the represented row with value q at B, value aₙ₊₁ at aₙ for each internal n≥0, and value B elsewhere. The prescribed slices do not overlap. The strong Cantorianity of the index represents the one-step chain assignment. The B used as an argument and the B used as an output may be supplied as two independent parameters instantiated by the same object. Its range is contained in B, q and the positive chain labels. In particular F differs from B. Each K²x is a constant row, so F(K²x)=B for every x whereas B(K²x)=K²x varies with x.

Use the two-valued rows gₓ from the parent construction. Its row returns x at every argument different from x, and a fixed-point-free value μ(x) at x. The gₓ are pairwise distinct and Kx↦gₓ is represented homogeneously. Now choose T as the represented row with T(Kx)=gₓ, with T(P(t))=u when t∈B and v otherwise, and with value F everywhere else. Constant and probe inputs are disjoint. This is a direct stratified prescription after F and B have been fixed. The first clause makes T infinite-range. It differs from every finite-range probe, positive chain label and h. T differs from B because T(K²x) is nonconstant while B(K²x)=K²x is constant. T misses B in its range: F differs from B, the gₓ are two-valued, and u,v label two-valued rows. Thus T differs from the surjective q.

T also differs from F. Each gₓ is two-valued, so differs from B and q. For x≠a₁ it differs from every positive chain label. To see this, equality of two default-plus-exception rows forces their default values equal by evaluating away from both exceptions. If the exceptions then differ, their values at x disagree. Only the positive chain labels have exception a₁. The value T(Kx)=gₓ for x≠a₁ therefore lies outside the range of F. This supplies the required goal inequality F≠T.

The default clause for T applies at T itself, giving TT=F. The default clause for F applies at T, giving FT=B. The probe prescription and the reader identity give qT=B. Since T differs from a₁, each chain row satisfies aₙ₊₁T=aₙ. For Fx=B, the desired output is F(B)T=qT=B. For Fx=aₙ, including a₀=q, the desired output is F(aₙ)T=aₙ₊₁T=aₙ. This proves the unconditional equation everywhere. The constant-input clause of T gives the original tester laws.

Interpret numerical application by this chart, H on equal inputs by K, and H on unequal inputs by any separating witness. Soundness precludes a derivation of goal 3. In the converse direction the preceding quotient and lower interpretation give the NFU model with full Counting. The final passage between the pure and urelement theories retains Proposition 17.13 and Theorem 21.1 of *Choice and Consistency Strength in NF and NFU*, version 15, and the parent full-chart construction. Those inputs remain manuscript-level hypotheses of the reduction. This new upper construction is a written mathematical argument.

The row count, K seed, marker, final row, field consumption and specified cache bounds of the original census schedule are all preserved for the canonical 38→19-token replacement. The census proof transports once a literal emitter has been bound to these nine schemata. The physical state count of an actual compiled table requires a separate certificate.
