"""Verify literal source edits, the blank computation, all signed frames and the scalar algebra export."""
from pathlib import Path
import argparse,gzip,hashlib,json,os,shutil,subprocess,sys,tempfile
R=Path(__file__).resolve().parent;M=R/'machine';V=R/'runtime';sys.path.insert(0,str(V))
from audit_staged import audit

def main():
 p=argparse.ArgumentParser();p.add_argument('--regenerate',action='store_true',help='regenerate all physical traces and compare their bytes');p.add_argument('--kernel',type=Path,help='Lean 4.35 leanchecker-paranoid executable for independent algebra proof replay');a=p.parse_args()
 assert hashlib.sha256((M/'candidate.tm').read_bytes()).hexdigest()=='447c2b9cff59b24c446a763d5b192fa06b13a83898375f400408878f1aa64b12'
 assert audit(M,R/'reference/NF175',R/'reference/Ax186')==json.loads((M/'source-audit.json').read_bytes())
 got=subprocess.check_output([sys.executable,V/'check_frames.py',M],text=True);assert json.loads(got)==json.loads((M/'receipt.json').read_bytes());print(got.strip(),flush=True)
 with tempfile.TemporaryDirectory()as tmp:
  root=Path(tmp);out=root/'algebra.ndjson';res=subprocess.check_output([sys.executable,R/'lower/check_lower.py',R/'lower/engine',M,out],text=True);assert json.loads(res)==json.loads((R/'lower/receipt.json').read_bytes());print(res.strip(),flush=True)
  if a.kernel:
   subprocess.run([str(a.kernel.resolve()),'--from-export',str(out)],check=True)
  if a.regenerate:
   output=root/'traces.gz';subprocess.run([sys.executable,V/'replay_symbolic.py',M,'--write',output],check=True);assert output.read_bytes()==(M/'traces.gz').read_bytes()
if __name__=='__main__':main()
