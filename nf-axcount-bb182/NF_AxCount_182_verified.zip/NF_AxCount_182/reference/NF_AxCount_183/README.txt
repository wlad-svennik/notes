NF+AxCount staged calculus: 183 working states
Inherited mathematical development: R. Gutin and E. Glazer

Consolidated release, 25 November 2026. Read RESULTS.txt for the new connection
to the uploaded nf-interp proof body and the exact verification limits.
proof_connection contains the updated calibration audit and adapter sources;
counting_rows contains 50 freshly kernel-checked equivalence proofs for a
family of shorter counting rows. The accepted machine still uses its original
counting row. Historical files under reference are preserved verbatim.

The literal binary table machine/candidate.tm has 183 working states and
366 transitions, with a separate uncounted halt. Start in k:74 on a blank
two-way infinite tape, blank symbol 0.

The reduction transfers the common selector/decoder modification from the
175-to-174 pure-NF improvement into the 184-state AxCount table. The axiom
emitter, counting law, formula encoding and source control-flow addresses
are preserved exactly under register permutation [1,5,2,0,6,4,3,7,8].
The counting law remains F=a -> (a(ab))T=ab, with F=TT and B=FT.

The table reaches PC zero after exactly 67,432 steps with physical R1=1,
every other register zero, a header gap of 55 and 30 zero spare blocks.
Warm_counter_transfer.md explains why the changed initial counter preserves
the existing source enumeration criterion.

Verification obtained in this session:
* Exact rebuild from included 184-, 175- and 174-state tables.
* Exact source conjugacy: all 3,397 instruction addresses and control edges.
* Complete blank configuration, including all nonblank tape cells.
* Independent symbolic replay of all 8,910 signed primitive branches and
  20 induction rules for unbounded tape repetitions.
* 13,588 concrete register fixtures, 7,191,036 physical transitions.
* Fresh Lean-kernel replay of all 8,910 branch theorems in 54 contiguous
  source intervals, including their unbounded induction rules.
* Fresh Lean-kernel replay of all 67,432 blank-start steps in 33 contiguous
  segments whose literal endpoint configurations agree.

Run `python3 verify.py` with Python 3.10 or later. Run `python3 verify.py
--regenerate --reference` to regenerate the unbounded traces and rerun the
included predecessor audit. Add `--kernel /path/to/leanchecker-paranoid`
to regenerate every new Lean proof export and check it in an external
Lean 4.35 kernel. The raw term generator handles the counter permutation
explicitly; verify.py sets the correct counter index automatically.
The inherited 184-state algebra and theory-calibration material is included
unchanged under reference/AxCount184. The source-level census and its final
comparison with full NF+AxCount remain the written arguments identified
there; the new kernel replay concerns the physical simulation and startup.

The uploaded NFUCountInterp.lean now supplies the formal NFUIC-to-NFC
interpretation previously cited only from the manuscript. The special chart
construction and the source-to-proof enumeration still have the written-proof
status described in proof_connection/Calibration_Audit.txt. The two new Lean
adapter sources were reviewed but not elaborated in this session; the archive's
original dependency project was not rebuilt. The physical reduction itself
preserves the predecessor's calculus exactly.

SHA256 of machine/candidate.tm:
bb6603f5a5e9848c3125ce1c861ff5f6bbdb3db383bdbc65ad487fba1feb0b52
