"""Separate pairs of controls with consistent binary tape inputs, counting raw steps."""
from pathlib import Path
from collections import Counter, deque
from itertools import combinations
import hashlib
import json

here=Path(__file__).resolve().parent
path=here.parent/'NF178.tm'
_,*lines=path.read_text().splitlines()
names=sorted({line.split()[0] for line in lines}); ids={s:k for k,s in enumerate(names)}
rows={}
for line in lines:
    q,b,w,d,t=line.split()
    rows[ids[q],int(b)]=int(w),1 if d=='R' else -1,ids.get(t,-1)


def distinguish(left,right,max_depth):
    # While both machines have the same observations they share one tape and head.
    # 'known' tracks previously visited cells, 'ones' is their current contents.
    origin=32
    queue=deque([(left,right,origin,0,0,0)])
    seen=set()
    while queue:
        a,b,h,known,ones,depth=queue.popleft()
        if (a,b,h,known,ones) in seen or depth>=max_depth:
            continue
        seen.add((a,b,h,known,ones))
        cell=1<<h
        for digit in ([int(bool(ones&cell))] if known&cell else (0,1)):
            w,d,t=rows[a,digit]; ww,dd,u=rows[b,digit]
            if w!=ww or d!=dd or (t==-1)!=(u==-1):
                return depth+1
            if t!=u:
                queue.append((t,u,h+d,known|cell,ones|cell if w else ones&~cell,depth+1))
    return None


if __name__=='__main__':
    by_depth=Counter()
    unresolved=[]
    for i,j in combinations(range(len(names)),2):
        k=distinguish(i,j,24)
        if k is None: unresolved.append([names[i],names[j]])
        else: by_depth[k]+=1
    print(json.dumps(dict(table_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),max_depth=24,total_pairs=len(names)*(len(names)-1)//2,
                          shortest_difference_by_raw_steps=dict(sorted(by_depth.items())),unresolved=unresolved),indent=2))
