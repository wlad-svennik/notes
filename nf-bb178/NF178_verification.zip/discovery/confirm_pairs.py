"""Independently replay one finite distinguishing tape for every pair of 178 controls."""
import json
from collections import Counter,deque
from itertools import combinations
from pathlib import Path
from actual_pairs import distinguish, rows, names, here


def witness(a,b,limit):
    # Keep a literal initial tape plus the shared updates made by both machines.
    queue=deque([(a,b,0,{}, {},0)])
    while queue:
        q,r,h,initial,updated,d=queue.popleft()
        if d>=limit:continue
        bits=(updated[h],) if h in updated else (0,1)
        for bit in bits:
            left=rows[q,bit];right=rows[r,bit]
            tape=initial if h in updated else {**initial,h:bit}
            signals=lambda edge:(edge[0],edge[1],edge[2]<0)
            if signals(left)!=signals(right):
                return d+1,tape
            w,move,to=left; other=right[-1]
            if to!=other:queue.append((to,other,h+move,tape,{**updated,h:w},d+1))
    raise AssertionError((names[a],names[b]))


def replay(q,initial,limit):
    cells={i for i,x in initial.items() if x}
    h=0;out=[]
    for _ in range(limit):
        digit=int(h in cells)
        w,move,q=rows[q,digit]
        (cells.add if w else cells.discard)(h)
        out.append((w,move,q<0))
        h+=move
        if q<0:break
    return out


def main():
    times=Counter(); examples=[]
    for a,b in combinations(range(178),2):
        n,t=witness(a,b,8)
        u,v=replay(a,t,n),replay(b,t,n)
        assert u[:-1]==v[:-1] and u[-1]!=v[-1]
        times[n]+=1
        if n==8:examples.append([names[a],names[b],sorted(i for i,bit in t.items()if bit),u[-1],v[-1]])
    assert sum(times.values())==15753
    print(json.dumps({'compared':15753,'maximum':max(times),'longest_examples':examples,'steps':dict(sorted(times.items()))},indent=2))


if __name__=='__main__':main()
