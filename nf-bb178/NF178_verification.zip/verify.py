"""Replay the literal blank-tape table and its proof-search instruction coverage."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
EXPECTED_TABLE="46cde5a5de2b1ef86094baa9940cd61153c0c1cb45cdc9339fa642b3c7625efc"
EXPECTED_SOURCE="7bacb7672e2df5f580588cc493b52c62bb0574de94c3a374d28e07195beccd47"

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def graph(table):
    first,*lines=table.read_text().splitlines()
    if first!="#! start k:74":raise ValueError("wrong start")
    arcs={}
    names={l.split()[0] for l in lines}
    for line in lines:
        q,r,w,d,nxt=line.split()
        if r not in ("0","1") or w not in ("0","1") or d not in ("L","R") or (q,r) in arcs:
            raise ValueError(line)
        if nxt not in names|{"halt"}:raise ValueError(nxt)
        arcs[q,r]=nxt
    assert len(arcs)==356 and len(names)==178
    assert [k for k,v in arcs.items() if v=="halt"]==[("k:302","1")]
    seen=set();todo=["k:74"]
    while todo:
        q=todo.pop()
        if q in seen or q=="halt":continue
        seen.add(q);todo.extend(arcs[q,b] for b in ("0","1"))
    assert seen==names

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kernel",action="store_true",help="Regenerate and kernel-check every signed branch")
    parser.add_argument("--examples",action="store_true",help="Run supplementary full-tape C++ examples")
    parser.add_argument("--jobs",type=int,default=2)
    args=parser.parse_args()
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        h,p=line.split('  ',1)
        if digest(ROOT/p)!=h:raise ValueError(p)
    table=ROOT/'NF178.tm';source=ROOT/'source.sites.json'
    assert digest(table)==EXPECTED_TABLE and digest(source)==EXPECTED_SOURCE
    graph(table)
    assert len(json.loads(source.read_bytes()))==2970
    print("178 reachable working states, one halt edge, 2,970 original source instructions.",flush=True)
    check=ROOT/'physical-checks'
    with tempfile.TemporaryDirectory()as temp:
        tmp=Path(temp);shutil.copyfile(table,tmp/'candidate.tm');shutil.copyfile(source,tmp/source.name)
        def py(script,*a,**kw):
            return subprocess.run([sys.executable,check/script,*map(str,a)],check=True,**kw)
        py('replay_start.py',tmp,'--seed',0)
        assert json.loads((tmp/'seed0-frames.json').read_bytes())==json.loads((ROOT/'evidence/blank-frames.json').read_bytes())
        py('symbolic_frames.py',tmp,'--write',tmp/'traces.gz')
        orig=json.loads(gzip.decompress((ROOT/'evidence/signed-branches.json.gz').read_bytes()))
        now=json.loads(gzip.decompress((tmp/'traces.gz').read_bytes()))
        assert orig==now
        if args.examples:
            py('prepare.py',tmp)
            subprocess.run(['c++','-std=c++17','-O3',str(check/'replay_examples.cpp'),'-o',str(tmp/'examples')],check=True)
            subprocess.run([tmp/'examples',tmp/'source.txt',tmp/'table.txt'],check=True)
        if args.kernel:
            py('check_all.py',tmp,tmp/'traces.gz',tmp/'receipt.json','--jobs',args.jobs,'--chunk',json.loads((ROOT/'evidence/raw-kernel.json').read_text())['intervals'][0]['past_last_pc'])
            generated=json.loads((tmp/'receipt.json').read_bytes())
            assert generated['branch_theorems']==7792
            saved=ROOT/'evidence/raw-kernel.json'
            if saved.exists():
                a=json.loads(saved.read_bytes())
                assert [x['export_sha256'] for x in a['intervals']]==[x['export_sha256'] for x in generated['intervals']]
    print("Replay complete.",flush=True)
if __name__=='__main__':main()
