import Std

/-! The local 200-to-199 reduction. A tape is arbitrary on both sides, with
cell zero in each side stream adjacent to the head. Both runs start at the
same absolute head position and return to exactly the same configuration. -/
namespace NFCS.LastState

inductive Action where
  | R (write : Bool) (next : String)
  | L (write : Bool) (next : String)
deriving DecidableEq

structure Row where
  state : String
  bit : Bool
  action : Action
deriving DecidableEq

def oldRows : List Row := [
  ⟨"d:20", true, .R true "d:21"⟩,
  ⟨"d:21", false, .R false "a:CI:8"⟩,
  ⟨"d:21", true, .L false "k16share:0"⟩,
  ⟨"k16share:0", true, .L false "k:2"⟩]

def newRows : List Row := [
  ⟨"d:20", true, .R true "d:8"⟩,
  ⟨"d:8", false, .R false "a:CI:8"⟩,
  ⟨"d:8", true, .L false "new:1"⟩,
  ⟨"new:1", true, .L false "k:2"⟩]

abbrev Table := String → Bool → Action

def Agrees (d : Table) (rows : List Row) : Prop :=
  ∀ r ∈ rows, d r.state r.bit = r.action

structure Config where
  state : String
  head : Int
  left : Nat → Bool
  read : Bool
  right : Nat → Bool

def push (b : Bool) (s : Nat → Bool) : Nat → Bool
  | 0 => b
  | n+1 => s n

def tick (d : Table) (c : Config) : Config :=
  match d c.state c.read with
  | .R b q => ⟨q,c.head+1,push b c.left,c.right 0,fun i => c.right (i+1)⟩
  | .L b q => ⟨q,c.head-1,(fun i => c.left (i+1)),c.left 0,push b c.right⟩

def run (d : Table) : Nat → Config → Config
  | 0, c => c
  | n+1, c => run d n (tick d c)

/-- Reading one at the redirected transition, a zero next door rejoins
in two ticks at a:CI:8. A one next door rejoins in three ticks at k:2.
Equality includes both infinite tape halves and the absolute head position. -/
theorem rejoin (old new : Table) (o : Agrees old oldRows) (n : Agrees new newRows)
    (h : Int) (l r : Nat → Bool) :
    let c : Config := ⟨"d:20", h, l, true, r⟩
    let ticks := if r 0 then 3 else 2
    run old ticks c = run new ticks c ∧
      (run new ticks c).state = (if r 0 then "k:2" else "a:CI:8") := by
  have o1 : old "d:20" true = .R true "d:21" := o ⟨"d:20", true, .R true "d:21"⟩ (by decide +kernel)
  have o2 : old "d:21" false = .R false "a:CI:8" := o ⟨"d:21", false, .R false "a:CI:8"⟩ (by decide +kernel)
  have o3 : old "d:21" true = .L false "k16share:0" := o ⟨"d:21", true, .L false "k16share:0"⟩ (by decide +kernel)
  have o4 : old "k16share:0" true = .L false "k:2" := o ⟨"k16share:0", true, .L false "k:2"⟩ (by decide +kernel)
  have n1 : new "d:20" true = .R true "d:8" := n ⟨"d:20", true, .R true "d:8"⟩ (by decide +kernel)
  have n2 : new "d:8" false = .R false "a:CI:8" := n ⟨"d:8", false, .R false "a:CI:8"⟩ (by decide +kernel)
  have n3 : new "d:8" true = .L false "new:1" := n ⟨"d:8", true, .L false "new:1"⟩ (by decide +kernel)
  have n4 : new "new:1" true = .L false "k:2" := n ⟨"new:1", true, .L false "k:2"⟩ (by decide +kernel)
  cases bit : r 0 <;> simp [bit, run, tick, push, o1, o2, o3, o4, n1, n2, n3, n4]

end NFCS.LastState

#print axioms NFCS.LastState.rejoin
