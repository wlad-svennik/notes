"""Bind the local Lean row literals and verify the complete 200-to-199 table edit."""
from pathlib import Path
import re
import sys


def read_table(path):
    lines = Path(path).read_text().splitlines()
    header, *body = lines
    assert header == "#! start k:64"
    table = {}
    for line in body:
        state, bit, write, move, target = line.split()
        assert bit in {"0", "1"} and write in {"0", "1"} and move in {"L", "R"}
        assert (state, bit) not in table
        table[state, bit] = (write, move, target)
    return table


def lean_rows(source, name):
    block = source.split(f"def {name} : List Row := [", 1)[1].split("]", 1)[0]
    pattern = r'⟨"([^"]+)", (false|true), \.([LR]) (false|true) "([^"]+)"⟩'
    out = {}
    for line in block.strip().splitlines():
        state, bit, move, write, target = re.fullmatch(pattern, line.strip().rstrip(",")).groups()
        out[state, str(int(bit == "true"))] = (str(int(write == "true")), move, target)
    assert len(out) == 4
    return out


def check(old_path, new_path):
    source = Path(__file__).with_name("LastState.lean").read_text()
    old, new = read_table(old_path), read_table(new_path)
    for table, name, n in [(old, "oldRows", 200), (new, "newRows", 199)]:
        assert len(table) == 2 * n
        for key, action in lean_rows(source, name).items():
            assert table[key] == action, (name, key)
    assert set(old) - set(new) == {("d:21", "0"), ("d:21", "1")}
    assert not set(new) - set(old)
    assert {key for key in new if old[key] != new[key]} == {("d:20", "1")}
    assert {key for key, action in old.items() if action[2] == "d:21"} == {("d:20", "1")}
    print("200 → 199 verified. All eight Lean rows agree, and the sole incoming edge to d:21 is the sole redirected edge.")


if __name__ == "__main__":
    check(*sys.argv[1:])
