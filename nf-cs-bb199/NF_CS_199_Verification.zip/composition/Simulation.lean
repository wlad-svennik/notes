import Std

/-! A source step may take any positive finite number of physical steps.
The relation describes complete register frames. The physical halt predicate
may forget the final tape and head, and must be preserved by physical steps. -/

namespace NFCS.Simulation

universe u v
variable {S : Type u} {P : Type v}

/-- Compute `n` transitions from a state. -/
def run {X : Type _} (step : X → X) : Nat → X → X
  | 0, x => x
  | n+1, x => run step n (step x)

theorem run_add {X : Type _} (step : X → X) (a b : Nat) (x : X) :
    run step (a+b) x = run step b (run step a x) := by
  induction a generalizing x with
  | zero => simp only [Nat.zero_add,run]
  | succ a ih => simpa only [Nat.succ_add,run] using ih (step x)

/-- A completed source run is absorbing after its first `none`. -/
def advance (next : S → Option S) (x : Option S) : Option S := x.bind next

/-- A matching pair consists of a live source state and its complete frame,
or a halted source and a halted physical computation. -/
def Matches (frame : S → P → Prop) (halted : P → Prop) : Option S → P → Prop
  | some s, p => frame s p
  | none, p => halted p

structure Certificate (next : S → Option S) (tick : P → P)
    (frame : S → P → Prop) (halted : P → Prop) : Prop where
  live : ∀ {s p}, frame s p → ¬ halted p
  absorbing : ∀ {p}, halted p → halted (tick p)
  instruction : ∀ {s p}, frame s p →
    ∃ m, 0 < m ∧ Matches frame halted (next s) (run tick m p)

variable {next : S → Option S} {tick : P → P}
    {frame : S → P → Prop} {halted : P → Prop}

private theorem matched_step (cert : Certificate next tick frame halted)
    {s : Option S} {p : P} (matchNow : Matches frame halted s p) :
    ∃ m, 0 < m ∧ Matches frame halted (advance next s) (run tick m p) := by
  cases s with
  | some s => exact cert.instruction matchNow
  | none => exact ⟨1, by decide, cert.absorbing matchNow⟩

/-- After n source steps there is a matching physical boundary at least n
physical steps later. Positive durations give this lower bound without any
uniform upper bound on instruction cost. -/
theorem finite_boundaries (cert : Certificate next tick frame halted)
    (n : Nat) {s : Option S} {p : P} (matchNow : Matches frame halted s p) :
    ∃ m, n ≤ m ∧ Matches frame halted (run (advance next) n s) (run tick m p) := by
  induction n generalizing s p with
  | zero => exact ⟨0, Nat.le_refl 0, matchNow⟩
  | succ n ih =>
    obtain ⟨first,pos,h⟩ := matched_step cert matchNow
    obtain ⟨tail,le,done⟩ := ih h
    refine ⟨first+tail,by omega,?_⟩
    rw [run_add tick first tail p]
    exact done

theorem stays_halted (cert : Certificate next tick frame halted) {p : P}
    (h : halted p) (n : Nat) : halted (run tick n p) := by
  induction n generalizing p with
  | zero => exact h
  | succ n ih => exact ih (cert.absorbing h)

/-- A multi-step startup followed by positive-duration complete instruction
simulation gives the ordinary halting criterion, including a possible
physical halt at an intermediate tick of an instruction or of startup. -/
theorem blank_halts_iff_source (cert : Certificate next tick frame halted)
    (blank : P) (start : S)
    (startup : ∃ startTime, frame start (run tick startTime blank)) :
    (∃ t, halted (run tick t blank)) ↔
    (∃ n, run (advance next) n (some start) = none) := by
  obtain ⟨startTime,boot⟩ := startup
  have initial : Matches frame halted (some start) (run tick startTime blank) := boot
  constructor
  · rintro ⟨t,atHalt⟩
    obtain ⟨m,le,boundary⟩ := finite_boundaries cert t initial
    rw [←run_add tick startTime m blank] at boundary
    have later : halted (run tick (startTime+m) blank) := by
      obtain ⟨d,hd⟩ := Nat.exists_eq_add_of_le (show t ≤ startTime+m by omega)
      rw [hd,run_add]
      exact stays_halted cert atHalt d
    refine ⟨t,?_⟩
    cases h : run (advance next) t (some start) with
    | none => rfl
    | some s =>
      rw [h] at boundary
      exact False.elim (cert.live boundary later)
  · rintro ⟨n,atHalt⟩
    obtain ⟨m,_,boundary⟩ := finite_boundaries cert n initial
    rw [atHalt,←run_add tick startTime m blank] at boundary
    exact ⟨startTime+m,boundary⟩

end NFCS.Simulation

#print axioms NFCS.Simulation.blank_halts_iff_source
