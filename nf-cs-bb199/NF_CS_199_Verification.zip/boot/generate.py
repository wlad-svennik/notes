"""Generate literal-table, quotient and blank-start proof inputs from the transition files."""
import argparse
from hashlib import sha256
import json
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('new',type=Path)
parser.add_argument('out',type=Path)
args=parser.parse_args()
out=args.out
out.mkdir(exist_ok=True)
def literal(path,n,expected):
    raw=path.read_bytes()
    assert sha256(raw).hexdigest()==expected
    lines=raw.decode().splitlines()
    start=lines[0].split()[-1]
    rows={}
    for line in lines[1:]:
        q,b,w,d,target=line.split()
        assert (q,int(b)) not in rows
        rows[q,int(b)]=(int(w),d,target)
    names=sorted({q for q,b in rows})
    assert len(names)==n and len(rows)==2*n and start=='k:64'
    ids={q:i for i,q in enumerate(names)}
    def tran(q,b):
        w,d,v=rows[q,b]
        return '⟨'+('true' if w else 'false')+', .'+('right' if d=='R' else 'left')+', '+('none' if v=='halt' else f'some ({ids[v]}:State)')+'⟩'
    def balanced(l,r,depth):
        pad='  '*depth
        if r==l+1:
            return pad+'('+tran(names[l],0)+','+tran(names[l],1)+')'
        m=(l+r)//2
        return pad+f'if q.val < {m} then\n'+balanced(l,m,depth+1)+'\n'+pad+'else\n'+balanced(m,r,depth+1)
    src=f'''import NF210.MachineSemantics
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank{n}.Table
open NF210.TM
abbrev State := Fin {n}
def start : State := {ids[start]}
def names : Array String := #'''+json.dumps(names)+'''
def name (q : State) := names[q.val]?.getD ""
def pair (q : State) : Instruction '''+str(n)+' × Instruction '+str(n)+' :=\n'+balanced(0,n,1)+f'''
def machine (q : State) (b : Bool) : Instruction {n} := if b then (pair q).2 else (pair q).1
def row (q : State) (b : Bool) : String :=
  let a := machine q b
  name q ++ " " ++ (if b then "1" else "0") ++ " " ++
    (if a.write then "1" else "0") ++ " " ++ (if a.move = .right then "R" else "L") ++ " " ++
    (a.next.map name).getD "halt" ++ "\\n"
def rendered : List String := (List.finRange {n}).flatMap fun q => [row q false,row q true]
def raw : List String := [\n'''+',\n'.join(json.dumps(x+'\n')for x in lines[1:])+''']
theorem literal_exact : rendered = raw := by decide +kernel
#print axioms literal_exact
end Blank'''+str(n)+'.Table\n'
    from bind_rows import audit
    (out/f'Blank{n}Table.lean').write_text(audit(src,n,lines[1:]))
    return names,rows,start

meta=json.loads((out/'inputs.json').read_bytes())
n=meta['states']
names,table,q=literal(args.new,n,meta['table'])
targets=tuple(meta['ticks'])
moments=sorted({*range(0,targets[-1],700),*targets})
want=set(moments);sn={}
h,b=32,0
for t in range(targets[-1]+1):
    assert 0<=h<512 and q!='halt'
    if t in want:sn[t]=(names.index(q),h,b)
    read=b>>h&1
    w,d,q=table[q,read];b^=(w^read)<<h;h+=1 if d=='R' else -1
head='''set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Blank178.Boot
open NF210 NF192 Blank178.Table
'''
src='import MachineBits\nimport Blank178Table\n'+head+'''abbrev width : Nat := 512
abbrev anchor : Int := -32
abbrev Prefix (n : Nat) (a b : KernelBits.Configuration 178) : Prop :=
  ∀ (left : Int) (outside : TM.Tape), TM.run machine n (KernelBits.embed width left outside a) = KernelBits.embed width left outside b
theorem checked (n : Nat) (a b : KernelBits.Configuration 178) (i : a.head < width)
    (h : KernelBits.run machine width n a=some b) : Prefix n a b :=
  fun l t => (KernelBits.run_sound machine width l t n a b i h).2
theorem compose {s t : Nat} {a b c : KernelBits.Configuration 178} (f : Prefix s a b) (g : Prefix t b c) :
    Prefix (s+t) a c := by intro l t; rw [TM.run_add,f l t,g l t]
'''
for t,(q,h,b)in sn.items():src+=f'def snap{t} : KernelBits.Configuration 178 := ⟨some ({q}:State),{h},{b}⟩\n'
(out/'ScannerSnapshots.lean').write_text(src+'end Blank178.Boot\n')
modules=[]
for pos in range(0,len(moments)-1,12):
    name=f'ScannerChunk{pos//12:02}'
    modules.append(name)
    src='import ScannerSnapshots\n'+head
    for a,b in zip(moments[pos:pos+12],moments[pos+1:pos+13]):
        src+=f'theorem chunk{b} : Prefix {b-a} snap{a} snap{b} := checked _ _ _ (by decide) (by decide)\n'
    (out/(name+'.lean')).write_text(src+'end Blank178.Boot\n')
src=''.join('import '+m+'\n' for m in modules)+head
for a,b in zip(moments,moments[1:]):
    term=f'@compose {a} {b-a} snap0 snap{a} snap{b} prefix{a} chunk{b}' if a else f'chunk{b}'
    src+=f'theorem prefix{b} : Prefix {b} snap0 snap{b} := {term}\n'
(out/'ScannerPrefix.lean').write_text(src+'end Blank178.Boot\n')
for t in targets:print(t,sn[t])

# Replace the template's state count consistently in all generated commands.
for name in ['ScannerSnapshots','ScannerPrefix',*modules]:
    p=out/(name+'.lean')
    p.write_text(p.read_text().replace('178',str(n)) if n==178 else
                 p.read_text().replace('Blank178',f'Blank{n}').replace('Configuration 178','Configuration '+str(n)))
