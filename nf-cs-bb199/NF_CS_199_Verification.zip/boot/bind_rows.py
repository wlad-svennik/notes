"""Generate a literal table audit in small blocks to keep Lean's memory bounded."""
import json
def audit(source,n,lines):
    s=source[:source.index('def rendered :')]
    labels=[]
    for start in range(0,len(lines),8):
        end=min(len(lines),start+8);i=start//8;labels.append(i)
        calls=', '.join(f'row ({j//2}:State) '+('true'if j%2 else'false')for j in range(start,end))
        literals=', '.join(json.dumps(t+'\n')for t in lines[start:end])
        s+=f'def rendered{i} : List String := [{calls}]\ndef raw{i} : List String := [{literals}]\n'
        s+=f'theorem verified{i} : rendered{i} = raw{i} := by decide +kernel\n'
    def concat(name):return ' ++ '.join(f'{name}{i}'for i in labels)
    s+=f'def rendered : List String := {concat("rendered")}\ndef raw : List String := {concat("raw")}\n'
    s+='theorem literal_exact : rendered = raw := by\n  unfold rendered raw\n  rw ['+', '.join(f'verified{i}'for i in labels)+']\n'
    s+=f'theorem start_header : name start = "k:64" := by decide +kernel\n#print axioms literal_exact\n#print axioms start_header\nend Blank{n}.Table\n'
    return s
