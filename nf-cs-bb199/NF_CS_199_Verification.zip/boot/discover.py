"""Replay either the printed K211 bootstrap or the native countdown compiler's physical boot."""
import argparse
import hashlib
import json
import re
from pathlib import Path

REGISTER_ORDER = (2, 8, 1, 4, 3, 7, 0, 5, 6)
AX_SEED = [-1, 0, 0, 2, 0, 0, 0, 0, 0]


class Run:
    def __init__(self, table, start):
        self.table = table
        self.state = start
        self.head = 0
        self.step = 0
        self.ones = set()

    def tick(self):
        w, displacement, state = self.table[self.state, int(self.head in self.ones)]
        if w:
            self.ones.add(self.head)
        else:
            self.ones.discard(self.head)
        self.head += displacement
        self.state = state
        self.step += 1

    def snapshot(self):
        return dict(step=self.step, state=self.state, head=self.head, ones=sorted(self.ones))


def read_table(path, k211=False):
    data = path.read_bytes()
    table = {}
    start = None
    for line in data.decode('ascii').splitlines():
        if line.startswith('#! start '):
            start = line.split()[-1]
        elif line and not line.startswith('#'):
            if k211:
                q, *terms = line.split()
                assert len(terms) == 2
                rows = [(str(bit), *re.fullmatch(r'([01])([LR])([0-9]+)', term).groups())
                        for bit, term in enumerate(terms)]
            else:
                q, *fields = line.split()
                rows = [fields]
            for bit, w, move, target in rows:
                assert bit in ('0','1') and w in ('0','1') and move in ('L','R')
                key = (q, int(bit))
                assert key not in table
                table[key] = int(w), (1 if move == 'R' else -1), target
    states = {q for q, bit in table}
    assert len(table) == 2 * len(states)
    terminal = '211' if k211 else 'halt'
    assert {t for w, m, t in table.values()} - states == {terminal}
    if k211:
        assert states == {str(i) for i in range(211)}
        start = '0'
    assert start in states
    return Run(table, start), hashlib.sha256(data).hexdigest()


def make_frame(head, path, header, logical, spares):
    bits = {head - 1, header} | {head + i for i, digit in enumerate(path) if digit == '1'}
    pos = header + 2
    blocks = [logical[r] + 1 for r in REGISTER_ORDER] + list(spares)
    for block in blocks:
        bits.update(range(pos, pos + block + 1))
        pos += block + 2
    return bits


def decode(run, leaves, depth):
    head, ones = run.head, run.ones
    if not ones or min(ones) != head - 1:
        return None
    path = ''
    while path not in leaves:
        if len(path) >= depth:
            return None
        path += str(int(head + len(path) in ones))
    header = min((b for b in ones if b >= head + len(path)), default=None)
    if header is None or header + 1 in ones:
        return None
    pos = header + 2
    end = max(ones)
    blocks = []
    while pos <= end:
        if pos not in ones:
            return None
        stop = pos + 1
        while stop in ones:
            stop += 1
        blocks.append(stop - pos - 1)
        pos = stop + 1
    if len(blocks) < 9:
        return None
    regs = [0] * 9
    for r, n in zip(REGISTER_ORDER, blocks):
        regs[r] = n - 1
    if make_frame(head, path, header, regs, blocks[9:]) != ones:
        return None
    return dict(ordinal=leaves[path], path=path, registers=regs, header=header,
                gap=header-head, spares=blocks[9:])


def cut(path, digit, count):
    for _ in range(count):
        idx = path.rfind(digit)
        if idx < 0:
            raise ValueError(f'cannot cut {digit} in {path}')
        path = path[:idx]
    return path


def advance(path):
    idx = path.rfind('0')
    return (0, path[:idx] + '1') if idx >= 0 else (-1, '')



def warm_start(run, table_sha, source_sha, rows, leaves, depth, cap):
    endpoints = []
    while run.step < cap:
        run.tick()
        if run.state == 'halt':
            raise ValueError(f'Halt during startup at tick {run.step}')
        if run.state != 'd:0' or run.head-1 not in run.ones:
            continue
        frame = decode(run, leaves, depth)
        if not frame or frame['ordinal'] != 0 or frame['registers'][0] < 0:
            continue
        if any(frame['registers'][1:]) or any(frame['spares']):
            continue
        full = dict(**run.snapshot(),frame=frame)
        if not endpoints:
            endpoints.append(full)
        if frame['gap'] >= 49 and len(frame['spares']) >= 24:
            return dict(table_sha256=table_sha,source_sha256=source_sha,states=len(run.table)//2,
                        binary_rows=len(run.table),source_sites=len(rows),depth=depth,
                        warm_anchor=endpoints[0],final=full,decoder_margin=49)
    raise ValueError(f'No warm empty scanner boundary by tick {cap}')


def native(table_path, source_path, cap, primitive_cap):
    r, table_sha = read_table(table_path)
    data = source_path.read_bytes()
    source_sha = hashlib.sha256(data).hexdigest()
    rows = json.loads(data)
    leaves = {p:i for i,(p,op,v) in enumerate(rows)}
    depth = max(map(len, leaves))
    assert len(leaves) == len(rows)
    if len(rows)==4377 and rows[0][0]=='0000':
        return warm_start(r,table_sha,source_sha,rows,leaves,depth,cap)
    ax_pc = 39 if len(rows)==4377 else 40
    while r.step < cap:
        r.tick()
        if r.state == 'halt':
            raise ValueError(f'early halt at {r.step}')
        if r.state != 'd:0':
            continue
        f = decode(r, leaves, depth)
        if f and f['ordinal'] == ax_pc and f['registers'] == AX_SEED:
            break
    else:
        raise ValueError(f'AX seed absent through step {cap}')
    anchor = dict(**r.snapshot(), frame=f)
    gap, pc, header = f['gap'], f['ordinal'], f['header']
    regs, spares = f['registers'][:], f['spares'][:]
    counts = {}
    checkpoints = []
    while gap < 49 or len(spares) < 24:
        path, op, operand = rows[pc]
        assert r.ones == make_frame(r.head, path, header, regs, spares)
        if op == 'CI':
            regs[operand] += 1
            spares.append(0)
            delta, path = advance(path)
        elif op == 'CD':
            assert regs[operand] >= 0
            if regs[operand] == 0:
                path = cut(path,'0',1)
            else:
                regs[operand] -= 1
                header += 1
            delta, path = advance(path)
        elif op == 'CB':
            delta, path = advance(cut(path,'0',operand))
        elif op == 'CC':
            delta, path = 0, cut(path,'1',operand)
        else:
            raise ValueError(f'early halt in source op {pc}, {op}')
        prev = pc
        next_head = r.head + delta
        while path not in leaves:
            assert len(path) < depth
            path += '0'
        pc = leaves[path]
        expected = make_frame(next_head, path, header, regs, spares)
        begin = r.step
        while r.step - begin < primitive_cap:
            r.tick()
            if r.state == 'halt':
                raise ValueError(f'early halt after source operation {prev}')
            if r.state == 'd:0' and r.head == next_head and r.ones == expected:
                break
        else:
            raise ValueError(f'no full-tape match for {prev}→{pc} at {begin}')
        gap = header - r.head
        counts[op] = counts.get(op,0) + 1
        checkpoints.append([prev, pc, r.step])
        if r.step >= cap:
            raise ValueError('boot bridge exceeded cap')
    final = decode(r, leaves, depth)
    assert final is not None and final['ordinal'] == pc and final['registers'] == regs
    assert regs[0] == -1 and min(regs[1:]) >= 0
    return dict(table_sha256=table_sha, source_sha256=source_sha, states=len(r.table)//2,
                binary_rows=len(r.table), source_sites=len(rows), depth=depth, cold_anchor=anchor,
                decoder_margin=49, final=dict(**r.snapshot(), frame=final),
                primitives=counts, checked_source_steps=checkpoints)


def k211(path):
    r, table_sha = read_table(path, k211=True)
    for _ in range(613447):
        r.tick()
    assert (r.state, r.head, len(r.ones), min(r.ones), max(r.ones)) == ('22', -5, 350, -6, 707)
    return dict(table_sha256=table_sha, states=len(r.table)//2, binary_rows=len(r.table), final=r.snapshot())


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('table', type=Path)
    p.add_argument('--source', type=Path, help='native source.sites.json, default two directories above the table')
    p.add_argument('--k211', action='store_true')
    p.add_argument('--cap', type=int, default=1000000)
    p.add_argument('--primitive-cap', type=int, default=100000)
    p.add_argument('--out', type=Path)
    a = p.parse_args()
    record = k211(a.table) if a.k211 else native(a.table, a.source or a.table.parents[1]/'source.sites.json', a.cap, a.primitive_cap)
    if a.out:
        a.out.write_text(json.dumps(record, indent=2)+'\n')
    end = record['final']
    print(json.dumps(dict(states=record['states'], rows=record['binary_rows'],
                          steps=end['step'], state=end['state'], head=end['head'],
                          ones=len(end['ones']), pc=end.get('frame',{}).get('ordinal'),
                          primitive_checks=len(record.get('checked_source_steps',[])), output=str(a.out))))
