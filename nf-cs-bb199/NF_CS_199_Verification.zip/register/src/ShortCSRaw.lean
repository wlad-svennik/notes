module
public import ShortCSProgram
public import MachineCountdown
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace ShortCS.Raw
open NF192 NF192.Source

def asCommand : NF192.Emitter.Instruction → Command
  | .inc r next => .inc r.val next
  | .dec r z next => .dec r.val z next false
  | .decHalt r next => .dec r.val 4363 next true
  | .jump next => .jump next
  | .halt => .inc 9 0

def program (pc : Nat) : Command := asCommand (ShortCS.Literal.program pc)
def step : Config → Config
  | some (pc,rs) => execute (program pc) rs
  | none => none

def advance : Nat → Config → Config
  | 0, s => s
  | n+1, s => advance n (step s)

theorem advance_add (i j : Nat) (s : Config) :
    advance (i+j) s = advance j (advance i s) := by
  induction i generalizing s with
  | zero => simp [advance]
  | succ i ih => simp only [Nat.succ_add, advance, ih]
theorem countdown_row_4358 : program 4357 = Command.dec 5 4361 4358 false := by decide
theorem countdown_row_4359 : program 4358 = Command.dec 5 4361 4359 false := by decide
theorem countdown_row_4360 : program 4359 = Command.dec 5 4361 4360 false := by decide
theorem countdown_row_4361 : program 4360 = Command.dec 5 4363 4361 true := by decide
theorem countdown_row_4362 : program 4361 = Command.dec 5 4363 4362 false := by decide
theorem countdown_row_4363 : program 4362 = Command.jump 4361 := by decide

private theorem dec_pos {pc target zero : Nat} {hlt : Bool}
    (instruction : program pc = Command.dec 5 zero target hlt) (n : Nat) (rs : Registers) :
    step (goalConfig pc (n+1) rs) = goalConfig target n rs := by
  simp [step, goalConfig, execute, instruction]

private theorem dec_zero {pc target pos : Nat}
    (instruction : program pc = Command.dec 5 target pos false) (rs : Registers) :
    step (goalConfig pc 0 rs) = goalConfig target 0 rs := by
  simp [step, goalConfig, execute, instruction]

private theorem dec_stop {pc zero pos : Nat}
    (instruction : program pc = Command.dec 5 zero pos true) (rs : Registers) :
    step (goalConfig pc 0 rs) = Config.halted := by
  simp [step, goalConfig, execute, instruction]

private theorem jump_step {pc target : Nat} (instruction : program pc = Command.jump target)
    (n : Nat) (rs : Registers) :
    step (goalConfig pc n rs) = goalConfig target n rs := by
  simp [step, goalConfig, execute, instruction]

/-- Every iteration of the clear loop consumes one unit in exactly two steps. -/
theorem clear_all (n : Nat) (rs : Registers) :
    advance (2*n+1) (goalConfig 4361 n rs) = goalConfig 4363 0 rs := by
  induction n with
  | zero =>
    exact dec_zero countdown_row_4362 rs
  | succ k ih =>
    have ticks : 2*(k+1)+1 = 2 + (2*k+1) := by omega
    rw [ticks, advance_add]
    have iteration : advance 2 (goalConfig 4361 (k+1) rs) = goalConfig 4361 k rs := by
      change step (step (goalConfig 4361 (k+1) rs)) = goalConfig 4361 k rs
      rw [dec_pos countdown_row_4362, jump_step countdown_row_4363]
    rw [iteration]
    exact ih

theorem countdown_correct (n : Nat) (rs : Registers) :
    advance (countdownDuration n) (goalConfig 4357 n rs) =
    (if n = 3 then Config.halted else goalConfig 4363 0 rs) := by
  cases n with
  | zero =>
    change step (step (goalConfig 4357 0 rs)) = goalConfig 4363 0 rs
    rw [dec_zero countdown_row_4358, dec_zero countdown_row_4362]
  | succ n =>
    cases n with
    | zero =>
      change step (step (step (goalConfig 4357 1 rs))) = goalConfig 4363 0 rs
      rw [dec_pos countdown_row_4358, dec_zero countdown_row_4359, dec_zero countdown_row_4362]
    | succ n =>
      cases n with
      | zero =>
        change step (step (step (step (goalConfig 4357 2 rs)))) = goalConfig 4363 0 rs
        rw [dec_pos countdown_row_4358, dec_pos countdown_row_4359,
          dec_zero countdown_row_4360, dec_zero countdown_row_4362]
      | succ n =>
        cases n with
        | zero =>
          change step (step (step (step (goalConfig 4357 3 rs)))) = Config.halted
          rw [dec_pos countdown_row_4358, dec_pos countdown_row_4359,
            dec_pos countdown_row_4360, dec_stop countdown_row_4361]
        | succ k =>
          have neq : k.succ.succ.succ.succ ≠ 3 := by omega
          rw [ite_eq_right neq]
          change advance (4+(2*k+1)) (goalConfig 4357 (k+4) rs) = goalConfig 4363 0 rs
          rw [advance_add 4 (2*k+1)]
          have first : advance 4 (goalConfig 4357 (k+4) rs) = goalConfig 4361 k rs := by
            change step (step (step (step (goalConfig 4357 (k+4) rs)))) = goalConfig 4361 k rs
            rw [dec_pos countdown_row_4358, dec_pos countdown_row_4359,
              dec_pos countdown_row_4360, dec_pos countdown_row_4361]
          rw [first, clear_all]

theorem countdown_halts_iff (n : Nat) (rs : Registers) :
    advance (countdownDuration n) (goalConfig 4357 n rs) = Config.halted ↔ n = 3 := by
  rw [countdown_correct]
  by_cases h : n = 3 <;> simp [h, goalConfig]


end ShortCS.Raw
#print axioms ShortCS.Raw.countdown_correct
