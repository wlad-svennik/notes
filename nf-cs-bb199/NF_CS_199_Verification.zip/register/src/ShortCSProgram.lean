module
public import NumericalEmitterBatch
public import NumericalEmitterChecking
@[expose] public section
/-! The input is the 4378-site register CFG decoded from the first-coordinate source file, split
at the exact entry and exit ordinals of the changed AX block. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace ShortCS.Literal
open NF192.Numerical NF192.Emitter
def pre0 : List Instruction := [
  .dec 8 2 1, .jump 9, .dec 0 6 3, .inc 7 4, .inc 6 5, .jump 2,
  .inc 0 7, .dec 6 9 8, .jump 6, .dec 8 17 10, .inc 7 11, .dec 6 13 12,
  .jump 16, .dec 7 16 14, .inc 6 15, .jump 13, .jump 9, .dec 7 20 18,
  .inc 8 19, .jump 17, .dec 6 23 21, .inc 3 22, .jump 20, .dec 8 31 24,
  .inc 7 25, .dec 6 27 26, .jump 30, .dec 7 30 28, .inc 6 29, .jump 27,
  .jump 23, .dec 7 34 32, .inc 8 33, .jump 31, .dec 6 37 35, .inc 4 36,
  .jump 34, .dec 3 4330 38, .dec 3 4256 39]
def pre : List Instruction := [pre0].flatten
def mid0 : List Instruction := [
  .dec 8 47 40, .inc 7 41, .dec 6 43 42, .jump 46, .dec 7 46 44, .inc 6 45,
  .jump 43, .jump 39, .dec 7 50 48, .inc 8 49, .jump 47, .dec 6 53 51,
  .inc 5 52, .jump 50, .dec 1 56 54, .inc 6 55, .jump 53, .dec 2 59 57,
  .inc 1 58, .jump 56, .dec 1 63 60, .inc 7 61, .inc 6 62, .jump 59,
  .dec 6 69 64, .inc 7 65, .dec 6 68 66, .inc 1 67, .jump 65, .jump 59,
  .dec 7 72 70, .inc 2 71, .jump 69, .dec 3 76 73, .inc 6 74, .inc 1 75,
  .jump 72, .dec 6 79 77, .inc 3 78, .jump 76, .dec 1 82 80, .inc 6 81,
  .jump 79, .dec 2 85 83, .inc 1 84, .jump 82, .dec 1 89 86, .inc 7 87]
def mid1 : List Instruction := [
  .inc 6 88, .jump 85, .dec 6 95 90, .inc 7 91, .dec 6 94 92, .inc 1 93,
  .jump 91, .jump 85, .dec 7 98 96, .inc 2 97, .jump 95, .dec 4 102 99,
  .inc 6 100, .inc 1 101, .jump 98, .dec 6 105 103, .inc 4 104, .jump 102,
  .dec 2 113 106, .inc 7 107, .dec 6 109 108, .jump 112, .dec 7 112 110, .inc 6 111,
  .jump 109, .jump 105, .dec 7 116 114, .inc 2 115, .jump 113, .dec 1 120 117,
  .inc 7 118, .inc 6 119, .jump 116, .dec 6 126 121, .inc 7 122, .dec 6 125 123,
  .inc 1 124, .jump 122, .jump 116, .dec 7 130 127, .inc 1 128, .inc 1 129,
  .jump 126, .dec 8 138 131, .inc 7 132, .dec 6 134 133, .jump 137, .dec 7 137 135]
def mid2 : List Instruction := [
  .inc 6 136, .jump 134, .jump 130, .dec 7 141 139, .inc 8 140, .jump 138,
  .dec 6 144 142, .inc 4 143, .jump 141, .dec 1 147 145, .inc 6 146, .jump 144,
  .dec 2 150 148, .inc 1 149, .jump 147, .dec 1 154 151, .inc 7 152, .inc 6 153,
  .jump 150, .dec 6 160 155, .inc 7 156, .dec 6 159 157, .inc 1 158, .jump 156,
  .jump 150, .dec 7 163 161, .inc 2 162, .jump 160, .dec 4 167 164, .inc 6 165,
  .inc 1 166, .jump 163, .dec 6 170 168, .inc 4 169, .jump 167, .dec 2 178 171,
  .inc 7 172, .dec 6 174 173, .jump 177, .dec 7 177 175, .inc 6 176, .jump 174,
  .jump 170, .dec 7 181 179, .inc 2 180, .jump 178, .dec 1 185 182, .inc 7 183]
def mid3 : List Instruction := [
  .inc 6 184, .jump 181, .dec 6 191 186, .inc 7 187, .dec 6 190 188, .inc 1 189,
  .jump 187, .jump 181, .dec 7 195 192, .inc 1 193, .inc 1 194, .jump 191,
  .dec 1 198 196, .inc 6 197, .jump 195, .dec 2 201 199, .inc 1 200, .jump 198,
  .dec 1 205 202, .inc 7 203, .inc 6 204, .jump 201, .dec 6 211 206, .inc 7 207,
  .dec 6 210 208, .inc 1 209, .jump 207, .jump 201, .dec 7 214 212, .inc 2 213,
  .jump 211, .dec 4 218 215, .inc 6 216, .inc 1 217, .jump 214, .dec 6 221 219,
  .inc 4 220, .jump 218, .dec 1 224 222, .inc 6 223, .jump 221, .dec 2 227 225,
  .inc 1 226, .jump 224, .dec 1 231 228, .inc 7 229, .inc 6 230, .jump 227]
def mid4 : List Instruction := [
  .dec 6 237 232, .inc 7 233, .dec 6 236 234, .inc 1 235, .jump 233, .jump 227,
  .dec 7 240 238, .inc 2 239, .jump 237, .dec 3 244 241, .inc 6 242, .inc 1 243,
  .jump 240, .dec 6 247 245, .inc 3 246, .jump 244, .dec 2 255 248, .inc 7 249,
  .dec 6 251 250, .jump 254, .dec 7 254 252, .inc 6 253, .jump 251, .jump 247,
  .dec 7 258 256, .inc 2 257, .jump 255, .dec 1 262 259, .inc 7 260, .inc 6 261,
  .jump 258, .dec 6 268 263, .inc 7 264, .dec 6 267 265, .inc 1 266, .jump 264,
  .jump 258, .dec 7 272 269, .inc 1 270, .inc 1 271, .jump 268, .dec 1 275 273,
  .inc 6 274, .jump 272, .dec 2 278 276, .inc 1 277, .jump 275, .dec 1 282 279]
def mid5 : List Instruction := [
  .inc 7 280, .inc 6 281, .jump 278, .dec 6 288 283, .inc 7 284, .dec 6 287 285,
  .inc 1 286, .jump 284, .jump 278, .dec 7 291 289, .inc 2 290, .jump 288,
  .dec 5 295 292, .inc 6 293, .inc 1 294, .jump 291, .dec 6 298 296, .inc 5 297,
  .jump 295, .dec 1 301 299, .inc 6 300, .jump 298, .dec 2 304 302, .inc 1 303,
  .jump 301, .dec 1 308 305, .inc 7 306, .inc 6 307, .jump 304, .dec 6 314 309,
  .inc 7 310, .dec 6 313 311, .inc 1 312, .jump 310, .jump 304, .dec 7 317 315,
  .inc 2 316, .jump 314, .dec 3 321 318, .inc 6 319, .inc 1 320, .jump 317,
  .dec 6 324 322, .inc 3 323, .jump 321, .dec 2 332 325, .inc 7 326, .dec 6 328 327]
def mid6 : List Instruction := [
  .jump 331, .dec 7 331 329, .inc 6 330, .jump 328, .jump 324, .dec 7 335 333,
  .inc 2 334, .jump 332, .dec 1 339 336, .inc 7 337, .inc 6 338, .jump 335,
  .dec 6 345 340, .inc 7 341, .dec 6 344 342, .inc 1 343, .jump 341, .jump 335,
  .dec 7 349 346, .inc 1 347, .inc 1 348, .jump 345, .dec 2 357 350, .inc 7 351,
  .dec 6 353 352, .jump 356, .dec 7 356 354, .inc 6 355, .jump 353, .jump 349,
  .dec 7 360 358, .inc 2 359, .jump 357, .dec 1 364 361, .inc 7 362, .inc 6 363,
  .jump 360, .dec 6 370 365, .inc 7 366, .dec 6 369 367, .inc 1 368, .jump 366,
  .jump 360, .dec 7 374 371, .inc 1 372, .inc 1 373, .jump 370, .dec 2 382 375]
def mid7 : List Instruction := [
  .inc 7 376, .dec 6 378 377, .jump 381, .dec 7 381 379, .inc 6 380, .jump 378,
  .jump 374, .dec 7 385 383, .inc 2 384, .jump 382, .dec 1 389 386, .inc 7 387,
  .inc 6 388, .jump 385, .dec 6 395 390, .inc 7 391, .dec 6 394 392, .inc 1 393,
  .jump 391, .jump 385, .dec 7 399 396, .inc 1 397, .inc 1 398, .jump 395,
  .dec 1 402 400, .inc 6 401, .jump 399, .dec 2 405 403, .inc 1 404, .jump 402,
  .dec 1 409 406, .inc 7 407, .inc 6 408, .jump 405, .dec 6 415 410, .inc 7 411,
  .dec 6 414 412, .inc 1 413, .jump 411, .jump 405, .dec 7 418 416, .inc 2 417,
  .jump 415, .dec 5 422 419, .inc 6 420, .inc 1 421, .jump 418, .dec 6 425 423]
def mid8 : List Instruction := [
  .inc 5 424, .jump 422, .dec 1 428 426, .inc 6 427, .jump 425, .dec 2 431 429,
  .inc 1 430, .jump 428, .dec 1 435 432, .inc 7 433, .inc 6 434, .jump 431,
  .dec 6 441 436, .inc 7 437, .dec 6 440 438, .inc 1 439, .jump 437, .jump 431,
  .dec 7 444 442, .inc 2 443, .jump 441, .dec 5 448 445, .inc 6 446, .inc 1 447,
  .jump 444, .dec 6 451 449, .inc 5 450, .jump 448, .dec 2 459 452, .inc 7 453,
  .dec 6 455 454, .jump 458, .dec 7 458 456, .inc 6 457, .jump 455, .jump 451,
  .dec 7 462 460, .inc 2 461, .jump 459, .dec 1 466 463, .inc 7 464, .inc 6 465,
  .jump 462, .dec 6 472 467, .inc 7 468, .dec 6 471 469, .inc 1 470, .jump 468]
def mid9 : List Instruction := [
  .jump 462, .dec 7 476 473, .inc 1 474, .inc 1 475, .jump 472, .inc 1 477,
  .inc 1 478, .dec 1 481 479, .inc 6 480, .jump 478, .dec 2 484 482, .inc 1 483,
  .jump 481, .dec 1 488 485, .inc 7 486, .inc 6 487, .jump 484, .dec 6 494 489,
  .inc 7 490, .dec 6 493 491, .inc 1 492, .jump 490, .jump 484, .dec 7 497 495,
  .inc 2 496, .jump 494, .dec 4 501 498, .inc 6 499, .inc 1 500, .jump 497,
  .dec 6 504 502, .inc 4 503, .jump 501, .dec 2 512 505, .inc 7 506, .dec 6 508 507,
  .jump 511, .dec 7 511 509, .inc 6 510, .jump 508, .jump 504, .dec 7 515 513,
  .inc 2 514, .jump 512, .dec 1 519 516, .inc 7 517, .inc 6 518, .jump 515]
def mid10 : List Instruction := [
  .dec 6 525 520, .inc 7 521, .dec 6 524 522, .inc 1 523, .jump 521, .jump 515,
  .dec 7 529 526, .inc 1 527, .inc 1 528, .jump 525, .inc 1 530, .dec 1 533 531,
  .inc 6 532, .jump 530, .dec 2 536 534, .inc 1 535, .jump 533, .dec 1 540 537,
  .inc 7 538, .inc 6 539, .jump 536, .dec 6 546 541, .inc 7 542, .dec 6 545 543,
  .inc 1 544, .jump 542, .jump 536, .dec 7 549 547, .inc 2 548, .jump 546,
  .dec 5 553 550, .inc 6 551, .inc 1 552, .jump 549, .dec 6 556 554, .inc 5 555,
  .jump 553, .dec 2 564 557, .inc 7 558, .dec 6 560 559, .jump 563, .dec 7 563 561,
  .inc 6 562, .jump 560, .jump 556, .dec 7 567 565, .inc 2 566, .jump 564]
def mid11 : List Instruction := [
  .dec 1 571 568, .inc 7 569, .inc 6 570, .jump 567, .dec 6 577 572, .inc 7 573,
  .dec 6 576 574, .inc 1 575, .jump 573, .jump 567, .dec 7 581 578, .inc 1 579,
  .inc 1 580, .jump 577, .inc 1 582, .dec 1 585 583, .inc 6 584, .jump 582,
  .dec 2 588 586, .inc 1 587, .jump 585, .dec 1 592 589, .inc 7 590, .inc 6 591,
  .jump 588, .dec 6 598 593, .inc 7 594, .dec 6 597 595, .inc 1 596, .jump 594,
  .jump 588, .dec 7 601 599, .inc 2 600, .jump 598, .inc 1 602, .dec 1 605 603,
  .inc 6 604, .jump 602, .dec 2 608 606, .inc 1 607, .jump 605, .dec 1 612 609,
  .inc 7 610, .inc 6 611, .jump 608, .dec 6 618 613, .inc 7 614, .dec 6 617 615]
def mid12 : List Instruction := [
  .inc 1 616, .jump 614, .jump 608, .dec 7 621 619, .inc 2 620, .jump 618,
  .dec 3 625 622, .inc 6 623, .inc 1 624, .jump 621, .dec 6 628 626, .inc 3 627,
  .jump 625, .dec 2 636 629, .inc 7 630, .dec 6 632 631, .jump 635, .dec 7 635 633,
  .inc 6 634, .jump 632, .jump 628, .dec 7 639 637, .inc 2 638, .jump 636,
  .dec 1 643 640, .inc 7 641, .inc 6 642, .jump 639, .dec 6 649 644, .inc 7 645,
  .dec 6 648 646, .inc 1 647, .jump 645, .jump 639, .dec 7 653 650, .inc 1 651,
  .inc 1 652, .jump 649, .inc 1 654, .dec 1 657 655, .inc 6 656, .jump 654,
  .dec 2 660 658, .inc 1 659, .jump 657, .dec 1 664 661, .inc 7 662, .inc 6 663]
def mid13 : List Instruction := [
  .jump 660, .dec 6 670 665, .inc 7 666, .dec 6 669 667, .inc 1 668, .jump 666,
  .jump 660, .dec 7 673 671, .inc 2 672, .jump 670, .dec 4 677 674, .inc 6 675,
  .inc 1 676, .jump 673, .dec 6 680 678, .inc 4 679, .jump 677, .dec 2 688 681,
  .inc 7 682, .dec 6 684 683, .jump 687, .dec 7 687 685, .inc 6 686, .jump 684,
  .jump 680, .dec 7 691 689, .inc 2 690, .jump 688, .dec 1 695 692, .inc 7 693,
  .inc 6 694, .jump 691, .dec 6 701 696, .inc 7 697, .dec 6 700 698, .inc 1 699,
  .jump 697, .jump 691, .dec 7 705 702, .inc 1 703, .inc 1 704, .jump 701,
  .inc 1 706, .dec 1 709 707, .inc 6 708, .jump 706, .dec 2 712 710, .inc 1 711]
def mid14 : List Instruction := [
  .jump 709, .dec 1 716 713, .inc 7 714, .inc 6 715, .jump 712, .dec 6 722 717,
  .inc 7 718, .dec 6 721 719, .inc 1 720, .jump 718, .jump 712, .dec 7 725 723,
  .inc 2 724, .jump 722, .dec 5 729 726, .inc 6 727, .inc 1 728, .jump 725,
  .dec 6 732 730, .inc 5 731, .jump 729, .dec 2 740 733, .inc 7 734, .dec 6 736 735,
  .jump 739, .dec 7 739 737, .inc 6 738, .jump 736, .jump 732, .dec 7 743 741,
  .inc 2 742, .jump 740, .dec 1 747 744, .inc 7 745, .inc 6 746, .jump 743,
  .dec 6 753 748, .inc 7 749, .dec 6 752 750, .inc 1 751, .jump 749, .jump 743,
  .dec 7 757 754, .inc 1 755, .inc 1 756, .jump 753, .inc 1 758, .dec 1 761 759]
def mid15 : List Instruction := [
  .inc 6 760, .jump 758, .dec 2 764 762, .inc 1 763, .jump 761, .dec 1 768 765,
  .inc 7 766, .inc 6 767, .jump 764, .dec 6 774 769, .inc 7 770, .dec 6 773 771,
  .inc 1 772, .jump 770, .jump 764, .dec 7 777 775, .inc 2 776, .jump 774,
  .dec 3 781 778, .inc 6 779, .inc 1 780, .jump 777, .dec 6 784 782, .inc 3 783,
  .jump 781, .dec 1 787 785, .inc 6 786, .jump 784, .dec 2 790 788, .inc 1 789,
  .jump 787, .dec 1 794 791, .inc 7 792, .inc 6 793, .jump 790, .dec 6 800 795,
  .inc 7 796, .dec 6 799 797, .inc 1 798, .jump 796, .jump 790, .dec 7 803 801,
  .inc 2 802, .jump 800, .dec 5 807 804, .inc 6 805, .inc 1 806, .jump 803]
def mid16 : List Instruction := [
  .dec 6 810 808, .inc 5 809, .jump 807, .dec 1 813 811, .inc 6 812, .jump 810,
  .dec 2 816 814, .inc 1 815, .jump 813, .dec 1 820 817, .inc 7 818, .inc 6 819,
  .jump 816, .dec 6 826 821, .inc 7 822, .dec 6 825 823, .inc 1 824, .jump 822,
  .jump 816, .dec 7 829 827, .inc 2 828, .jump 826, .dec 5 833 830, .inc 6 831,
  .inc 1 832, .jump 829, .dec 6 836 834, .inc 5 835, .jump 833, .dec 2 844 837,
  .inc 7 838, .dec 6 840 839, .jump 843, .dec 7 843 841, .inc 6 842, .jump 840,
  .jump 836, .dec 7 847 845, .inc 2 846, .jump 844, .dec 1 851 848, .inc 7 849,
  .inc 6 850, .jump 847, .dec 6 857 852, .inc 7 853, .dec 6 856 854, .inc 1 855]
def mid17 : List Instruction := [
  .jump 853, .jump 847, .dec 7 861 858, .inc 1 859, .inc 1 860, .jump 857,
  .inc 1 862, .inc 1 863, .dec 2 871 864, .inc 7 865, .dec 6 867 866, .jump 870,
  .dec 7 870 868, .inc 6 869, .jump 867, .jump 863, .dec 7 874 872, .inc 2 873,
  .jump 871, .dec 1 878 875, .inc 7 876, .inc 6 877, .jump 874, .dec 6 884 879,
  .inc 7 880, .dec 6 883 881, .inc 1 882, .jump 880, .jump 874, .dec 7 888 885,
  .inc 1 886, .inc 1 887, .jump 884, .inc 1 889, .dec 1 892 890, .inc 6 891,
  .jump 889, .dec 2 895 893, .inc 1 894, .jump 892, .dec 1 899 896, .inc 7 897,
  .inc 6 898, .jump 895, .dec 6 905 900, .inc 7 901, .dec 6 904 902, .inc 1 903]
def mid18 : List Instruction := [
  .jump 901, .jump 895, .dec 7 908 906, .inc 2 907, .jump 905, .dec 4 912 909,
  .inc 6 910, .inc 1 911, .jump 908, .dec 6 915 913, .inc 4 914, .jump 912,
  .dec 1 918 916, .inc 6 917, .jump 915, .dec 2 921 919, .inc 1 920, .jump 918,
  .dec 1 925 922, .inc 7 923, .inc 6 924, .jump 921, .dec 6 931 926, .inc 7 927,
  .dec 6 930 928, .inc 1 929, .jump 927, .jump 921, .dec 7 934 932, .inc 2 933,
  .jump 931, .dec 5 938 935, .inc 6 936, .inc 1 937, .jump 934, .dec 6 941 939,
  .inc 5 940, .jump 938, .dec 2 949 942, .inc 7 943, .dec 6 945 944, .jump 948,
  .dec 7 948 946, .inc 6 947, .jump 945, .jump 941, .dec 7 952 950, .inc 2 951]
def mid19 : List Instruction := [
  .jump 949, .dec 1 956 953, .inc 7 954, .inc 6 955, .jump 952, .dec 6 962 957,
  .inc 7 958, .dec 6 961 959, .inc 1 960, .jump 958, .jump 952, .dec 7 966 963,
  .inc 1 964, .inc 1 965, .jump 962, .inc 1 967, .dec 2 975 968, .inc 7 969,
  .dec 6 971 970, .jump 974, .dec 7 974 972, .inc 6 973, .jump 971, .jump 967,
  .dec 7 978 976, .inc 2 977, .jump 975, .dec 1 982 979, .inc 7 980, .inc 6 981,
  .jump 978, .dec 6 988 983, .inc 7 984, .dec 6 987 985, .inc 1 986, .jump 984,
  .jump 978, .dec 7 992 989, .inc 1 990, .inc 1 991, .jump 988, .inc 1 993,
  .dec 2 1001 994, .inc 7 995, .dec 6 997 996, .jump 1000, .dec 7 1000 998, .inc 6 999]
def mid20 : List Instruction := [
  .jump 997, .jump 993, .dec 7 1004 1002, .inc 2 1003, .jump 1001, .dec 1 1008 1005,
  .inc 7 1006, .inc 6 1007, .jump 1004, .dec 6 1014 1009, .inc 7 1010, .dec 6 1013 1011,
  .inc 1 1012, .jump 1010, .jump 1004, .dec 7 1018 1015, .inc 1 1016, .inc 1 1017,
  .jump 1014, .inc 1 1019, .dec 1 1022 1020, .inc 6 1021, .jump 1019, .dec 2 1025 1023,
  .inc 1 1024, .jump 1022, .dec 1 1029 1026, .inc 7 1027, .inc 6 1028, .jump 1025,
  .dec 6 1035 1030, .inc 7 1031, .dec 6 1034 1032, .inc 1 1033, .jump 1031, .jump 1025,
  .dec 7 1038 1036, .inc 2 1037, .jump 1035, .dec 3 1042 1039, .inc 6 1040, .inc 1 1041,
  .jump 1038, .dec 6 1045 1043, .inc 3 1044, .jump 1042, .dec 1 1048 1046, .inc 6 1047]
def mid21 : List Instruction := [
  .jump 1045, .dec 2 1051 1049, .inc 1 1050, .jump 1048, .dec 1 1055 1052, .inc 7 1053,
  .inc 6 1054, .jump 1051, .dec 6 1061 1056, .inc 7 1057, .dec 6 1060 1058, .inc 1 1059,
  .jump 1057, .jump 1051, .dec 7 1064 1062, .inc 2 1063, .jump 1061, .dec 5 1068 1065,
  .inc 6 1066, .inc 1 1067, .jump 1064, .dec 6 1071 1069, .inc 5 1070, .jump 1068,
  .dec 2 1079 1072, .inc 7 1073, .dec 6 1075 1074, .jump 1078, .dec 7 1078 1076, .inc 6 1077,
  .jump 1075, .jump 1071, .dec 7 1082 1080, .inc 2 1081, .jump 1079, .dec 1 1086 1083,
  .inc 7 1084, .inc 6 1085, .jump 1082, .dec 6 1092 1087, .inc 7 1088, .dec 6 1091 1089,
  .inc 1 1090, .jump 1088, .jump 1082, .dec 7 1096 1093, .inc 1 1094, .inc 1 1095]
def mid22 : List Instruction := [
  .jump 1092, .inc 1 1097, .dec 1 1100 1098, .inc 6 1099, .jump 1097, .dec 2 1103 1101,
  .inc 1 1102, .jump 1100, .dec 1 1107 1104, .inc 7 1105, .inc 6 1106, .jump 1103,
  .dec 6 1113 1108, .inc 7 1109, .dec 6 1112 1110, .inc 1 1111, .jump 1109, .jump 1103,
  .dec 7 1116 1114, .inc 2 1115, .jump 1113, .dec 4 1120 1117, .inc 6 1118, .inc 1 1119,
  .jump 1116, .dec 6 1123 1121, .inc 4 1122, .jump 1120, .dec 1 1126 1124, .inc 6 1125,
  .jump 1123, .dec 2 1129 1127, .inc 1 1128, .jump 1126, .dec 1 1133 1130, .inc 7 1131,
  .inc 6 1132, .jump 1129, .dec 6 1139 1134, .inc 7 1135, .dec 6 1138 1136, .inc 1 1137,
  .jump 1135, .jump 1129, .dec 7 1142 1140, .inc 2 1141, .jump 1139, .dec 3 1146 1143]
def mid23 : List Instruction := [
  .inc 6 1144, .inc 1 1145, .jump 1142, .dec 6 1149 1147, .inc 3 1148, .jump 1146,
  .dec 2 1157 1150, .inc 7 1151, .dec 6 1153 1152, .jump 1156, .dec 7 1156 1154, .inc 6 1155,
  .jump 1153, .jump 1149, .dec 7 1160 1158, .inc 2 1159, .jump 1157, .dec 1 1164 1161,
  .inc 7 1162, .inc 6 1163, .jump 1160, .dec 6 1170 1165, .inc 7 1166, .dec 6 1169 1167,
  .inc 1 1168, .jump 1166, .jump 1160, .dec 7 1174 1171, .inc 1 1172, .inc 1 1173,
  .jump 1170, .inc 1 1175, .dec 1 1178 1176, .inc 6 1177, .jump 1175, .dec 2 1181 1179,
  .inc 1 1180, .jump 1178, .dec 1 1185 1182, .inc 7 1183, .inc 6 1184, .jump 1181,
  .dec 6 1191 1186, .inc 7 1187, .dec 6 1190 1188, .inc 1 1189, .jump 1187, .jump 1181]
def mid24 : List Instruction := [
  .dec 7 1194 1192, .inc 2 1193, .jump 1191, .dec 4 1198 1195, .inc 6 1196, .inc 1 1197,
  .jump 1194, .dec 6 1201 1199, .inc 4 1200, .jump 1198, .dec 1 1204 1202, .inc 6 1203,
  .jump 1201, .dec 2 1207 1205, .inc 1 1206, .jump 1204, .dec 1 1211 1208, .inc 7 1209,
  .inc 6 1210, .jump 1207, .dec 6 1217 1212, .inc 7 1213, .dec 6 1216 1214, .inc 1 1215,
  .jump 1213, .jump 1207, .dec 7 1220 1218, .inc 2 1219, .jump 1217, .dec 5 1224 1221,
  .inc 6 1222, .inc 1 1223, .jump 1220, .dec 6 1227 1225, .inc 5 1226, .jump 1224,
  .dec 2 1235 1228, .inc 7 1229, .dec 6 1231 1230, .jump 1234, .dec 7 1234 1232, .inc 6 1233,
  .jump 1231, .jump 1227, .dec 7 1238 1236, .inc 2 1237, .jump 1235, .dec 1 1242 1239]
def mid25 : List Instruction := [
  .inc 7 1240, .inc 6 1241, .jump 1238, .dec 6 1248 1243, .inc 7 1244, .dec 6 1247 1245,
  .inc 1 1246, .jump 1244, .jump 1238, .dec 7 1252 1249, .inc 1 1250, .inc 1 1251,
  .jump 1248, .inc 1 1253, .dec 2 1261 1254, .inc 7 1255, .dec 6 1257 1256, .jump 1260,
  .dec 7 1260 1258, .inc 6 1259, .jump 1257, .jump 1253, .dec 7 1264 1262, .inc 2 1263,
  .jump 1261, .dec 1 1268 1265, .inc 7 1266, .inc 6 1267, .jump 1264, .dec 6 1274 1269,
  .inc 7 1270, .dec 6 1273 1271, .inc 1 1272, .jump 1270, .jump 1264, .dec 7 1278 1275,
  .inc 1 1276, .inc 1 1277, .jump 1274, .inc 1 1279, .dec 2 1287 1280, .inc 7 1281,
  .dec 6 1283 1282, .jump 1286, .dec 7 1286 1284, .inc 6 1285, .jump 1283, .jump 1279]
def mid26 : List Instruction := [
  .dec 7 1290 1288, .inc 2 1289, .jump 1287, .dec 1 1294 1291, .inc 7 1292, .inc 6 1293,
  .jump 1290, .dec 6 1300 1295, .inc 7 1296, .dec 6 1299 1297, .inc 1 1298, .jump 1296,
  .jump 1290, .dec 7 1304 1301, .inc 1 1302, .inc 1 1303, .jump 1300, .dec 1 1307 1305,
  .inc 6 1306, .jump 1304, .dec 2 1310 1308, .inc 1 1309, .jump 1307, .dec 1 1314 1311,
  .inc 7 1312, .inc 6 1313, .jump 1310, .dec 6 1320 1315, .inc 7 1316, .dec 6 1319 1317,
  .inc 1 1318, .jump 1316, .jump 1310, .dec 7 1323 1321, .inc 2 1322, .jump 1320,
  .dec 4 1327 1324, .inc 6 1325, .inc 1 1326, .jump 1323, .dec 6 1330 1328, .inc 4 1329,
  .jump 1327, .dec 1 1333 1331, .inc 6 1332, .jump 1330, .dec 2 1336 1334, .inc 1 1335]
def mid27 : List Instruction := [
  .jump 1333, .dec 1 1340 1337, .inc 7 1338, .inc 6 1339, .jump 1336, .dec 6 1346 1341,
  .inc 7 1342, .dec 6 1345 1343, .inc 1 1344, .jump 1342, .jump 1336, .dec 7 1349 1347,
  .inc 2 1348, .jump 1346, .dec 3 1353 1350, .inc 6 1351, .inc 1 1352, .jump 1349,
  .dec 6 1356 1354, .inc 3 1355, .jump 1353, .dec 2 1364 1357, .inc 7 1358, .dec 6 1360 1359,
  .jump 1363, .dec 7 1363 1361, .inc 6 1362, .jump 1360, .jump 1356, .dec 7 1367 1365,
  .inc 2 1366, .jump 1364, .dec 1 1371 1368, .inc 7 1369, .inc 6 1370, .jump 1367,
  .dec 6 1377 1372, .inc 7 1373, .dec 6 1376 1374, .inc 1 1375, .jump 1373, .jump 1367,
  .dec 7 1381 1378, .inc 1 1379, .inc 1 1380, .jump 1377, .inc 1 1382, .dec 1 1385 1383]
def mid28 : List Instruction := [
  .inc 6 1384, .jump 1382, .dec 2 1388 1386, .inc 1 1387, .jump 1385, .dec 1 1392 1389,
  .inc 7 1390, .inc 6 1391, .jump 1388, .dec 6 1398 1393, .inc 7 1394, .dec 6 1397 1395,
  .inc 1 1396, .jump 1394, .jump 1388, .dec 7 1401 1399, .inc 2 1400, .jump 1398,
  .dec 3 1405 1402, .inc 6 1403, .inc 1 1404, .jump 1401, .dec 6 1408 1406, .inc 3 1407,
  .jump 1405, .dec 1 1411 1409, .inc 6 1410, .jump 1408, .dec 2 1414 1412, .inc 1 1413,
  .jump 1411, .dec 1 1418 1415, .inc 7 1416, .inc 6 1417, .jump 1414, .dec 6 1424 1419,
  .inc 7 1420, .dec 6 1423 1421, .inc 1 1422, .jump 1420, .jump 1414, .dec 7 1427 1425,
  .inc 2 1426, .jump 1424, .dec 5 1431 1428, .inc 6 1429, .inc 1 1430, .jump 1427]
def mid29 : List Instruction := [
  .dec 6 1434 1432, .inc 5 1433, .jump 1431, .dec 2 1442 1435, .inc 7 1436, .dec 6 1438 1437,
  .jump 1441, .dec 7 1441 1439, .inc 6 1440, .jump 1438, .jump 1434, .dec 7 1445 1443,
  .inc 2 1444, .jump 1442, .dec 1 1449 1446, .inc 7 1447, .inc 6 1448, .jump 1445,
  .dec 6 1455 1450, .inc 7 1451, .dec 6 1454 1452, .inc 1 1453, .jump 1451, .jump 1445,
  .dec 7 1459 1456, .inc 1 1457, .inc 1 1458, .jump 1455, .inc 1 1460, .dec 1 1463 1461,
  .inc 6 1462, .jump 1460, .dec 2 1466 1464, .inc 1 1465, .jump 1463, .dec 1 1470 1467,
  .inc 7 1468, .inc 6 1469, .jump 1466, .dec 6 1476 1471, .inc 7 1472, .dec 6 1475 1473,
  .inc 1 1474, .jump 1472, .jump 1466, .dec 7 1479 1477, .inc 2 1478, .jump 1476]
def mid30 : List Instruction := [
  .dec 4 1483 1480, .inc 6 1481, .inc 1 1482, .jump 1479, .dec 6 1486 1484, .inc 4 1485,
  .jump 1483, .dec 1 1489 1487, .inc 6 1488, .jump 1486, .dec 2 1492 1490, .inc 1 1491,
  .jump 1489, .dec 1 1496 1493, .inc 7 1494, .inc 6 1495, .jump 1492, .dec 6 1502 1497,
  .inc 7 1498, .dec 6 1501 1499, .inc 1 1500, .jump 1498, .jump 1492, .dec 7 1505 1503,
  .inc 2 1504, .jump 1502, .dec 5 1509 1506, .inc 6 1507, .inc 1 1508, .jump 1505,
  .dec 6 1512 1510, .inc 5 1511, .jump 1509, .dec 2 1520 1513, .inc 7 1514, .dec 6 1516 1515,
  .jump 1519, .dec 7 1519 1517, .inc 6 1518, .jump 1516, .jump 1512, .dec 7 1523 1521,
  .inc 2 1522, .jump 1520, .dec 1 1527 1524, .inc 7 1525, .inc 6 1526, .jump 1523]
def mid31 : List Instruction := [
  .dec 6 1533 1528, .inc 7 1529, .dec 6 1532 1530, .inc 1 1531, .jump 1529, .jump 1523,
  .dec 7 1537 1534, .inc 1 1535, .inc 1 1536, .jump 1533, .inc 1 1538, .dec 2 1546 1539,
  .inc 7 1540, .dec 6 1542 1541, .jump 1545, .dec 7 1545 1543, .inc 6 1544, .jump 1542,
  .jump 1538, .dec 7 1549 1547, .inc 2 1548, .jump 1546, .dec 1 1553 1550, .inc 7 1551,
  .inc 6 1552, .jump 1549, .dec 6 1559 1554, .inc 7 1555, .dec 6 1558 1556, .inc 1 1557,
  .jump 1555, .jump 1549, .dec 7 1563 1560, .inc 1 1561, .inc 1 1562, .jump 1559,
  .inc 1 1564, .dec 2 1572 1565, .inc 7 1566, .dec 6 1568 1567, .jump 1571, .dec 7 1571 1569,
  .inc 6 1570, .jump 1568, .jump 1564, .dec 7 1575 1573, .inc 2 1574, .jump 1572]
def mid32 : List Instruction := [
  .dec 1 1579 1576, .inc 7 1577, .inc 6 1578, .jump 1575, .dec 6 1585 1580, .inc 7 1581,
  .dec 6 1584 1582, .inc 1 1583, .jump 1581, .jump 1575, .dec 7 1589 1586, .inc 1 1587,
  .inc 1 1588, .jump 1585, .dec 1 1592 1590, .inc 6 1591, .jump 1589, .dec 2 1595 1593,
  .inc 1 1594, .jump 1592, .dec 1 1599 1596, .inc 7 1597, .inc 6 1598, .jump 1595,
  .dec 6 1605 1600, .inc 7 1601, .dec 6 1604 1602, .inc 1 1603, .jump 1601, .jump 1595,
  .dec 7 1608 1606, .inc 2 1607, .jump 1605, .dec 4 1612 1609, .inc 6 1610, .inc 1 1611,
  .jump 1608, .dec 6 1615 1613, .inc 4 1614, .jump 1612, .dec 1 1618 1616, .inc 6 1617,
  .jump 1615, .dec 2 1621 1619, .inc 1 1620, .jump 1618, .dec 1 1625 1622, .inc 7 1623]
def mid33 : List Instruction := [
  .inc 6 1624, .jump 1621, .dec 6 1631 1626, .inc 7 1627, .dec 6 1630 1628, .inc 1 1629,
  .jump 1627, .jump 1621, .dec 7 1634 1632, .inc 2 1633, .jump 1631, .dec 5 1638 1635,
  .inc 6 1636, .inc 1 1637, .jump 1634, .dec 6 1641 1639, .inc 5 1640, .jump 1638,
  .dec 2 1649 1642, .inc 7 1643, .dec 6 1645 1644, .jump 1648, .dec 7 1648 1646, .inc 6 1647,
  .jump 1645, .jump 1641, .dec 7 1652 1650, .inc 2 1651, .jump 1649, .dec 1 1656 1653,
  .inc 7 1654, .inc 6 1655, .jump 1652, .dec 6 1662 1657, .inc 7 1658, .dec 6 1661 1659,
  .inc 1 1660, .jump 1658, .jump 1652, .dec 7 1666 1663, .inc 1 1664, .inc 1 1665,
  .jump 1662, .inc 1 1667, .dec 1 1670 1668, .inc 6 1669, .jump 1667, .dec 2 1673 1671]
def mid34 : List Instruction := [
  .inc 1 1672, .jump 1670, .dec 1 1677 1674, .inc 7 1675, .inc 6 1676, .jump 1673,
  .dec 6 1683 1678, .inc 7 1679, .dec 6 1682 1680, .inc 1 1681, .jump 1679, .jump 1673,
  .dec 7 1686 1684, .inc 2 1685, .jump 1683, .dec 4 1690 1687, .inc 6 1688, .inc 1 1689,
  .jump 1686, .dec 6 1693 1691, .inc 4 1692, .jump 1690, .dec 1 1696 1694, .inc 6 1695,
  .jump 1693, .dec 2 1699 1697, .inc 1 1698, .jump 1696, .dec 1 1703 1700, .inc 7 1701,
  .inc 6 1702, .jump 1699, .dec 6 1709 1704, .inc 7 1705, .dec 6 1708 1706, .inc 1 1707,
  .jump 1705, .jump 1699, .dec 7 1712 1710, .inc 2 1711, .jump 1709, .dec 3 1716 1713,
  .inc 6 1714, .inc 1 1715, .jump 1712, .dec 6 1719 1717, .inc 3 1718, .jump 1716]
def mid35 : List Instruction := [
  .dec 2 1727 1720, .inc 7 1721, .dec 6 1723 1722, .jump 1726, .dec 7 1726 1724, .inc 6 1725,
  .jump 1723, .jump 1719, .dec 7 1730 1728, .inc 2 1729, .jump 1727, .dec 1 1734 1731,
  .inc 7 1732, .inc 6 1733, .jump 1730, .dec 6 1740 1735, .inc 7 1736, .dec 6 1739 1737,
  .inc 1 1738, .jump 1736, .jump 1730, .dec 7 1744 1741, .inc 1 1742, .inc 1 1743,
  .jump 1740, .inc 1 1745, .dec 1 1748 1746, .inc 6 1747, .jump 1745, .dec 2 1751 1749,
  .inc 1 1750, .jump 1748, .dec 1 1755 1752, .inc 7 1753, .inc 6 1754, .jump 1751,
  .dec 6 1761 1756, .inc 7 1757, .dec 6 1760 1758, .inc 1 1759, .jump 1757, .jump 1751,
  .dec 7 1764 1762, .inc 2 1763, .jump 1761, .dec 3 1768 1765, .inc 6 1766, .inc 1 1767]
def mid36 : List Instruction := [
  .jump 1764, .dec 6 1771 1769, .inc 3 1770, .jump 1768, .dec 1 1774 1772, .inc 6 1773,
  .jump 1771, .dec 2 1777 1775, .inc 1 1776, .jump 1774, .dec 1 1781 1778, .inc 7 1779,
  .inc 6 1780, .jump 1777, .dec 6 1787 1782, .inc 7 1783, .dec 6 1786 1784, .inc 1 1785,
  .jump 1783, .jump 1777, .dec 7 1790 1788, .inc 2 1789, .jump 1787, .dec 5 1794 1791,
  .inc 6 1792, .inc 1 1793, .jump 1790, .dec 6 1797 1795, .inc 5 1796, .jump 1794,
  .dec 2 1805 1798, .inc 7 1799, .dec 6 1801 1800, .jump 1804, .dec 7 1804 1802, .inc 6 1803,
  .jump 1801, .jump 1797, .dec 7 1808 1806, .inc 2 1807, .jump 1805, .dec 1 1812 1809,
  .inc 7 1810, .inc 6 1811, .jump 1808, .dec 6 1818 1813, .inc 7 1814, .dec 6 1817 1815]
def mid37 : List Instruction := [
  .inc 1 1816, .jump 1814, .jump 1808, .dec 7 1822 1819, .inc 1 1820, .inc 1 1821,
  .jump 1818, .inc 1 1823, .dec 2 1831 1824, .inc 7 1825, .dec 6 1827 1826, .jump 1830,
  .dec 7 1830 1828, .inc 6 1829, .jump 1827, .jump 1823, .dec 7 1834 1832, .inc 2 1833,
  .jump 1831, .dec 1 1838 1835, .inc 7 1836, .inc 6 1837, .jump 1834, .dec 6 1844 1839,
  .inc 7 1840, .dec 6 1843 1841, .inc 1 1842, .jump 1840, .jump 1834, .dec 7 1848 1845,
  .inc 1 1846, .inc 1 1847, .jump 1844, .dec 2 1856 1849, .inc 7 1850, .dec 6 1852 1851,
  .jump 1855, .dec 7 1855 1853, .inc 6 1854, .jump 1852, .jump 1848, .dec 7 1859 1857,
  .inc 2 1858, .jump 1856, .dec 1 1863 1860, .inc 7 1861, .inc 6 1862, .jump 1859]
def mid38 : List Instruction := [
  .dec 6 1869 1864, .inc 7 1865, .dec 6 1868 1866, .inc 1 1867, .jump 1865, .jump 1859,
  .dec 7 1873 1870, .inc 1 1871, .inc 1 1872, .jump 1869, .dec 1 1876 1874, .inc 6 1875,
  .jump 1873, .dec 2 1879 1877, .inc 1 1878, .jump 1876, .dec 1 1883 1880, .inc 7 1881,
  .inc 6 1882, .jump 1879, .dec 6 1889 1884, .inc 7 1885, .dec 6 1888 1886, .inc 1 1887,
  .jump 1885, .jump 1879, .dec 7 1892 1890, .inc 2 1891, .jump 1889, .inc 1 1893,
  .dec 1 1896 1894, .inc 6 1895, .jump 1893, .dec 2 1899 1897, .inc 1 1898, .jump 1896,
  .dec 1 1903 1900, .inc 7 1901, .inc 6 1902, .jump 1899, .dec 6 1909 1904, .inc 7 1905,
  .dec 6 1908 1906, .inc 1 1907, .jump 1905, .jump 1899, .dec 7 1912 1910, .inc 2 1911]
def mid39 : List Instruction := [
  .jump 1909, .dec 1 1915 1913, .inc 6 1914, .jump 1912, .dec 2 1918 1916, .inc 1 1917,
  .jump 1915, .dec 1 1922 1919, .inc 7 1920, .inc 6 1921, .jump 1918, .dec 6 1928 1923,
  .inc 7 1924, .dec 6 1927 1925, .inc 1 1926, .jump 1924, .jump 1918, .dec 7 1931 1929,
  .inc 2 1930, .jump 1928, .dec 5 1935 1932, .inc 6 1933, .inc 1 1934, .jump 1931,
  .dec 6 1938 1936, .inc 5 1937, .jump 1935, .dec 1 1941 1939, .inc 6 1940, .jump 1938,
  .dec 2 1944 1942, .inc 1 1943, .jump 1941, .dec 1 1948 1945, .inc 7 1946, .inc 6 1947,
  .jump 1944, .dec 6 1954 1949, .inc 7 1950, .dec 6 1953 1951, .inc 1 1952, .jump 1950,
  .jump 1944, .dec 7 1957 1955, .inc 2 1956, .jump 1954, .dec 5 1961 1958, .inc 6 1959]
def mid40 : List Instruction := [
  .inc 1 1960, .jump 1957, .dec 6 1964 1962, .inc 5 1963, .jump 1961, .dec 2 1972 1965,
  .inc 7 1966, .dec 6 1968 1967, .jump 1971, .dec 7 1971 1969, .inc 6 1970, .jump 1968,
  .jump 1964, .dec 7 1975 1973, .inc 2 1974, .jump 1972, .dec 1 1979 1976, .inc 7 1977,
  .inc 6 1978, .jump 1975, .dec 6 1985 1980, .inc 7 1981, .dec 6 1984 1982, .inc 1 1983,
  .jump 1981, .jump 1975, .dec 7 1989 1986, .inc 1 1987, .inc 1 1988, .jump 1985,
  .inc 1 1990, .inc 1 1991, .dec 2 1999 1992, .inc 7 1993, .dec 6 1995 1994, .jump 1998,
  .dec 7 1998 1996, .inc 6 1997, .jump 1995, .jump 1991, .dec 7 2002 2000, .inc 2 2001,
  .jump 1999, .dec 1 2006 2003, .inc 7 2004, .inc 6 2005, .jump 2002, .dec 6 2012 2007]
def mid41 : List Instruction := [
  .inc 7 2008, .dec 6 2011 2009, .inc 1 2010, .jump 2008, .jump 2002, .dec 7 2016 2013,
  .inc 1 2014, .inc 1 2015, .jump 2012, .inc 1 2017, .dec 1 2020 2018, .inc 6 2019,
  .jump 2017, .dec 2 2023 2021, .inc 1 2022, .jump 2020, .dec 1 2027 2024, .inc 7 2025,
  .inc 6 2026, .jump 2023, .dec 6 2033 2028, .inc 7 2029, .dec 6 2032 2030, .inc 1 2031,
  .jump 2029, .jump 2023, .dec 7 2036 2034, .inc 2 2035, .jump 2033, .dec 4 2040 2037,
  .inc 6 2038, .inc 1 2039, .jump 2036, .dec 6 2043 2041, .inc 4 2042, .jump 2040,
  .dec 2 2051 2044, .inc 7 2045, .dec 6 2047 2046, .jump 2050, .dec 7 2050 2048, .inc 6 2049,
  .jump 2047, .jump 2043, .dec 7 2054 2052, .inc 2 2053, .jump 2051, .dec 1 2058 2055]
def mid42 : List Instruction := [
  .inc 7 2056, .inc 6 2057, .jump 2054, .dec 6 2064 2059, .inc 7 2060, .dec 6 2063 2061,
  .inc 1 2062, .jump 2060, .jump 2054, .dec 7 2068 2065, .inc 1 2066, .inc 1 2067,
  .jump 2064, .inc 1 2069, .dec 2 2077 2070, .inc 7 2071, .dec 6 2073 2072, .jump 2076,
  .dec 7 2076 2074, .inc 6 2075, .jump 2073, .jump 2069, .dec 7 2080 2078, .inc 2 2079,
  .jump 2077, .dec 1 2084 2081, .inc 7 2082, .inc 6 2083, .jump 2080, .dec 6 2090 2085,
  .inc 7 2086, .dec 6 2089 2087, .inc 1 2088, .jump 2086, .jump 2080, .dec 7 2094 2091,
  .inc 1 2092, .inc 1 2093, .jump 2090, .inc 1 2095, .dec 1 2098 2096, .inc 6 2097,
  .jump 2095, .dec 2 2101 2099, .inc 1 2100, .jump 2098, .dec 1 2105 2102, .inc 7 2103]
def mid43 : List Instruction := [
  .inc 6 2104, .jump 2101, .dec 6 2111 2106, .inc 7 2107, .dec 6 2110 2108, .inc 1 2109,
  .jump 2107, .jump 2101, .dec 7 2114 2112, .inc 2 2113, .jump 2111, .inc 1 2115,
  .dec 1 2118 2116, .inc 6 2117, .jump 2115, .dec 2 2121 2119, .inc 1 2120, .jump 2118,
  .dec 1 2125 2122, .inc 7 2123, .inc 6 2124, .jump 2121, .dec 6 2131 2126, .inc 7 2127,
  .dec 6 2130 2128, .inc 1 2129, .jump 2127, .jump 2121, .dec 7 2134 2132, .inc 2 2133,
  .jump 2131, .dec 1 2137 2135, .inc 6 2136, .jump 2134, .dec 2 2140 2138, .inc 1 2139,
  .jump 2137, .dec 1 2144 2141, .inc 7 2142, .inc 6 2143, .jump 2140, .dec 6 2150 2145,
  .inc 7 2146, .dec 6 2149 2147, .inc 1 2148, .jump 2146, .jump 2140, .dec 7 2153 2151]
def mid44 : List Instruction := [
  .inc 2 2152, .jump 2150, .dec 5 2157 2154, .inc 6 2155, .inc 1 2156, .jump 2153,
  .dec 6 2160 2158, .inc 5 2159, .jump 2157, .dec 1 2163 2161, .inc 6 2162, .jump 2160,
  .dec 2 2166 2164, .inc 1 2165, .jump 2163, .dec 1 2170 2167, .inc 7 2168, .inc 6 2169,
  .jump 2166, .dec 6 2176 2171, .inc 7 2172, .dec 6 2175 2173, .inc 1 2174, .jump 2172,
  .jump 2166, .dec 7 2179 2177, .inc 2 2178, .jump 2176, .dec 5 2183 2180, .inc 6 2181,
  .inc 1 2182, .jump 2179, .dec 6 2186 2184, .inc 5 2185, .jump 2183, .dec 2 2194 2187,
  .inc 7 2188, .dec 6 2190 2189, .jump 2193, .dec 7 2193 2191, .inc 6 2192, .jump 2190,
  .jump 2186, .dec 7 2197 2195, .inc 2 2196, .jump 2194, .dec 1 2201 2198, .inc 7 2199]
def mid45 : List Instruction := [
  .inc 6 2200, .jump 2197, .dec 6 2207 2202, .inc 7 2203, .dec 6 2206 2204, .inc 1 2205,
  .jump 2203, .jump 2197, .dec 7 2211 2208, .inc 1 2209, .inc 1 2210, .jump 2207,
  .inc 1 2212, .inc 1 2213, .dec 2 2221 2214, .inc 7 2215, .dec 6 2217 2216, .jump 2220,
  .dec 7 2220 2218, .inc 6 2219, .jump 2217, .jump 2213, .dec 7 2224 2222, .inc 2 2223,
  .jump 2221, .dec 1 2228 2225, .inc 7 2226, .inc 6 2227, .jump 2224, .dec 6 2234 2229,
  .inc 7 2230, .dec 6 2233 2231, .inc 1 2232, .jump 2230, .jump 2224, .dec 7 2238 2235,
  .inc 1 2236, .inc 1 2237, .jump 2234, .inc 1 2239, .dec 1 2242 2240, .inc 6 2241,
  .jump 2239, .dec 2 2245 2243, .inc 1 2244, .jump 2242, .dec 1 2249 2246, .inc 7 2247]
def mid46 : List Instruction := [
  .inc 6 2248, .jump 2245, .dec 6 2255 2250, .inc 7 2251, .dec 6 2254 2252, .inc 1 2253,
  .jump 2251, .jump 2245, .dec 7 2258 2256, .inc 2 2257, .jump 2255, .dec 5 2262 2259,
  .inc 6 2260, .inc 1 2261, .jump 2258, .dec 6 2265 2263, .inc 5 2264, .jump 2262,
  .dec 2 2273 2266, .inc 7 2267, .dec 6 2269 2268, .jump 2272, .dec 7 2272 2270, .inc 6 2271,
  .jump 2269, .jump 2265, .dec 7 2276 2274, .inc 2 2275, .jump 2273, .dec 1 2280 2277,
  .inc 7 2278, .inc 6 2279, .jump 2276, .dec 6 2286 2281, .inc 7 2282, .dec 6 2285 2283,
  .inc 1 2284, .jump 2282, .jump 2276, .dec 7 2290 2287, .inc 1 2288, .inc 1 2289,
  .jump 2286, .inc 1 2291, .dec 2 2299 2292, .inc 7 2293, .dec 6 2295 2294, .jump 2298]
def mid47 : List Instruction := [
  .dec 7 2298 2296, .inc 6 2297, .jump 2295, .jump 2291, .dec 7 2302 2300, .inc 2 2301,
  .jump 2299, .dec 1 2306 2303, .inc 7 2304, .inc 6 2305, .jump 2302, .dec 6 2312 2307,
  .inc 7 2308, .dec 6 2311 2309, .inc 1 2310, .jump 2308, .jump 2302, .dec 7 2316 2313,
  .inc 1 2314, .inc 1 2315, .jump 2312, .inc 1 2317, .dec 2 2325 2318, .inc 7 2319,
  .dec 6 2321 2320, .jump 2324, .dec 7 2324 2322, .inc 6 2323, .jump 2321, .jump 2317,
  .dec 7 2328 2326, .inc 2 2327, .jump 2325, .dec 1 2332 2329, .inc 7 2330, .inc 6 2331,
  .jump 2328, .dec 6 2338 2333, .inc 7 2334, .dec 6 2337 2335, .inc 1 2336, .jump 2334,
  .jump 2328, .dec 7 2342 2339, .inc 1 2340, .inc 1 2341, .jump 2338, .dec 1 2345 2343]
def mid48 : List Instruction := [
  .inc 6 2344, .jump 2342, .dec 2 2348 2346, .inc 1 2347, .jump 2345, .dec 1 2352 2349,
  .inc 7 2350, .inc 6 2351, .jump 2348, .dec 6 2358 2353, .inc 7 2354, .dec 6 2357 2355,
  .inc 1 2356, .jump 2354, .jump 2348, .dec 7 2361 2359, .inc 2 2360, .jump 2358,
  .dec 4 2365 2362, .inc 6 2363, .inc 1 2364, .jump 2361, .dec 6 2368 2366, .inc 4 2367,
  .jump 2365, .dec 1 2371 2369, .inc 6 2370, .jump 2368, .dec 2 2374 2372, .inc 1 2373,
  .jump 2371, .dec 1 2378 2375, .inc 7 2376, .inc 6 2377, .jump 2374, .dec 6 2384 2379,
  .inc 7 2380, .dec 6 2383 2381, .inc 1 2382, .jump 2380, .jump 2374, .dec 7 2387 2385,
  .inc 2 2386, .jump 2384, .dec 5 2391 2388, .inc 6 2389, .inc 1 2390, .jump 2387]
def mid49 : List Instruction := [
  .dec 6 2394 2392, .inc 5 2393, .jump 2391, .dec 2 2402 2395, .inc 7 2396, .dec 6 2398 2397,
  .jump 2401, .dec 7 2401 2399, .inc 6 2400, .jump 2398, .jump 2394, .dec 7 2405 2403,
  .inc 2 2404, .jump 2402, .dec 1 2409 2406, .inc 7 2407, .inc 6 2408, .jump 2405,
  .dec 6 2415 2410, .inc 7 2411, .dec 6 2414 2412, .inc 1 2413, .jump 2411, .jump 2405,
  .dec 7 2419 2416, .inc 1 2417, .inc 1 2418, .jump 2415, .inc 1 2420, .dec 2 2428 2421,
  .inc 7 2422, .dec 6 2424 2423, .jump 2427, .dec 7 2427 2425, .inc 6 2426, .jump 2424,
  .jump 2420, .dec 7 2431 2429, .inc 2 2430, .jump 2428, .dec 1 2435 2432, .inc 7 2433,
  .inc 6 2434, .jump 2431, .dec 6 2441 2436, .inc 7 2437, .dec 6 2440 2438, .inc 1 2439]
def mid50 : List Instruction := [
  .jump 2437, .jump 2431, .dec 7 2445 2442, .inc 1 2443, .inc 1 2444, .jump 2441,
  .dec 1 2448 2446, .inc 6 2447, .jump 2445, .dec 2 2451 2449, .inc 1 2450, .jump 2448,
  .dec 1 2455 2452, .inc 7 2453, .inc 6 2454, .jump 2451, .dec 6 2461 2456, .inc 7 2457,
  .dec 6 2460 2458, .inc 1 2459, .jump 2457, .jump 2451, .dec 7 2464 2462, .inc 2 2463,
  .jump 2461, .dec 1 2467 2465, .inc 6 2466, .jump 2464, .dec 2 2470 2468, .inc 1 2469,
  .jump 2467, .dec 1 2474 2471, .inc 7 2472, .inc 6 2473, .jump 2470, .dec 6 2480 2475,
  .inc 7 2476, .dec 6 2479 2477, .inc 1 2478, .jump 2476, .jump 2470, .dec 7 2483 2481,
  .inc 2 2482, .jump 2480, .dec 1 2486 2484, .inc 6 2485, .jump 2483, .dec 2 2489 2487]
def mid51 : List Instruction := [
  .inc 1 2488, .jump 2486, .dec 1 2493 2490, .inc 7 2491, .inc 6 2492, .jump 2489,
  .dec 6 2499 2494, .inc 7 2495, .dec 6 2498 2496, .inc 1 2497, .jump 2495, .jump 2489,
  .dec 7 2502 2500, .inc 2 2501, .jump 2499, .dec 4 2506 2503, .inc 6 2504, .inc 1 2505,
  .jump 2502, .dec 6 2509 2507, .inc 4 2508, .jump 2506, .dec 2 2517 2510, .inc 7 2511,
  .dec 6 2513 2512, .jump 2516, .dec 7 2516 2514, .inc 6 2515, .jump 2513, .jump 2509,
  .dec 7 2520 2518, .inc 2 2519, .jump 2517, .dec 1 2524 2521, .inc 7 2522, .inc 6 2523,
  .jump 2520, .dec 6 2530 2525, .inc 7 2526, .dec 6 2529 2527, .inc 1 2528, .jump 2526,
  .jump 2520, .dec 7 2534 2531, .inc 1 2532, .inc 1 2533, .jump 2530, .inc 1 2535]
def mid52 : List Instruction := [
  .dec 2 2543 2536, .inc 7 2537, .dec 6 2539 2538, .jump 2542, .dec 7 2542 2540, .inc 6 2541,
  .jump 2539, .jump 2535, .dec 7 2546 2544, .inc 2 2545, .jump 2543, .dec 1 2550 2547,
  .inc 7 2548, .inc 6 2549, .jump 2546, .dec 6 2556 2551, .inc 7 2552, .dec 6 2555 2553,
  .inc 1 2554, .jump 2552, .jump 2546, .dec 7 2560 2557, .inc 1 2558, .inc 1 2559,
  .jump 2556, .inc 1 2561, .inc 1 2562, .dec 1 2565 2563, .inc 6 2564, .jump 2562,
  .dec 2 2568 2566, .inc 1 2567, .jump 2565, .dec 1 2572 2569, .inc 7 2570, .inc 6 2571,
  .jump 2568, .dec 6 2578 2573, .inc 7 2574, .dec 6 2577 2575, .inc 1 2576, .jump 2574,
  .jump 2568, .dec 7 2581 2579, .inc 2 2580, .jump 2578, .dec 3 2585 2582, .inc 6 2583]
def mid53 : List Instruction := [
  .inc 1 2584, .jump 2581, .dec 6 2588 2586, .inc 3 2587, .jump 2585, .dec 2 2596 2589,
  .inc 7 2590, .dec 6 2592 2591, .jump 2595, .dec 7 2595 2593, .inc 6 2594, .jump 2592,
  .jump 2588, .dec 7 2599 2597, .inc 2 2598, .jump 2596, .dec 1 2603 2600, .inc 7 2601,
  .inc 6 2602, .jump 2599, .dec 6 2609 2604, .inc 7 2605, .dec 6 2608 2606, .inc 1 2607,
  .jump 2605, .jump 2599, .dec 7 2613 2610, .inc 1 2611, .inc 1 2612, .jump 2609,
  .inc 1 2614, .dec 1 2617 2615, .inc 6 2616, .jump 2614, .dec 2 2620 2618, .inc 1 2619,
  .jump 2617, .dec 1 2624 2621, .inc 7 2622, .inc 6 2623, .jump 2620, .dec 6 2630 2625,
  .inc 7 2626, .dec 6 2629 2627, .inc 1 2628, .jump 2626, .jump 2620, .dec 7 2633 2631]
def mid54 : List Instruction := [
  .inc 2 2632, .jump 2630, .dec 4 2637 2634, .inc 6 2635, .inc 1 2636, .jump 2633,
  .dec 6 2640 2638, .inc 4 2639, .jump 2637, .dec 1 2643 2641, .inc 6 2642, .jump 2640,
  .dec 2 2646 2644, .inc 1 2645, .jump 2643, .dec 1 2650 2647, .inc 7 2648, .inc 6 2649,
  .jump 2646, .dec 6 2656 2651, .inc 7 2652, .dec 6 2655 2653, .inc 1 2654, .jump 2652,
  .jump 2646, .dec 7 2659 2657, .inc 2 2658, .jump 2656, .dec 3 2663 2660, .inc 6 2661,
  .inc 1 2662, .jump 2659, .dec 6 2666 2664, .inc 3 2665, .jump 2663, .dec 2 2674 2667,
  .inc 7 2668, .dec 6 2670 2669, .jump 2673, .dec 7 2673 2671, .inc 6 2672, .jump 2670,
  .jump 2666, .dec 7 2677 2675, .inc 2 2676, .jump 2674, .dec 1 2681 2678, .inc 7 2679]
def mid55 : List Instruction := [
  .inc 6 2680, .jump 2677, .dec 6 2687 2682, .inc 7 2683, .dec 6 2686 2684, .inc 1 2685,
  .jump 2683, .jump 2677, .dec 7 2691 2688, .inc 1 2689, .inc 1 2690, .jump 2687,
  .inc 1 2692, .dec 1 2695 2693, .inc 6 2694, .jump 2692, .dec 2 2698 2696, .inc 1 2697,
  .jump 2695, .dec 1 2702 2699, .inc 7 2700, .inc 6 2701, .jump 2698, .dec 6 2708 2703,
  .inc 7 2704, .dec 6 2707 2705, .inc 1 2706, .jump 2704, .jump 2698, .dec 7 2711 2709,
  .inc 2 2710, .jump 2708, .dec 4 2715 2712, .inc 6 2713, .inc 1 2714, .jump 2711,
  .dec 6 2718 2716, .inc 4 2717, .jump 2715, .dec 1 2721 2719, .inc 6 2720, .jump 2718,
  .dec 2 2724 2722, .inc 1 2723, .jump 2721, .dec 1 2728 2725, .inc 7 2726, .inc 6 2727]
def mid56 : List Instruction := [
  .jump 2724, .dec 6 2734 2729, .inc 7 2730, .dec 6 2733 2731, .inc 1 2732, .jump 2730,
  .jump 2724, .dec 7 2737 2735, .inc 2 2736, .jump 2734, .dec 4 2741 2738, .inc 6 2739,
  .inc 1 2740, .jump 2737, .dec 6 2744 2742, .inc 4 2743, .jump 2741, .dec 1 2747 2745,
  .inc 6 2746, .jump 2744, .dec 2 2750 2748, .inc 1 2749, .jump 2747, .dec 1 2754 2751,
  .inc 7 2752, .inc 6 2753, .jump 2750, .dec 6 2760 2755, .inc 7 2756, .dec 6 2759 2757,
  .inc 1 2758, .jump 2756, .jump 2750, .dec 7 2763 2761, .inc 2 2762, .jump 2760,
  .dec 4 2767 2764, .inc 6 2765, .inc 1 2766, .jump 2763, .dec 6 2770 2768, .inc 4 2769,
  .jump 2767, .dec 1 2773 2771, .inc 6 2772, .jump 2770, .dec 2 2776 2774, .inc 1 2775]
def mid57 : List Instruction := [
  .jump 2773, .dec 1 2780 2777, .inc 7 2778, .inc 6 2779, .jump 2776, .dec 6 2786 2781,
  .inc 7 2782, .dec 6 2785 2783, .inc 1 2784, .jump 2782, .jump 2776, .dec 7 2789 2787,
  .inc 2 2788, .jump 2786, .dec 4 2793 2790, .inc 6 2791, .inc 1 2792, .jump 2789,
  .dec 6 2796 2794, .inc 4 2795, .jump 2793, .dec 1 2799 2797, .inc 6 2798, .jump 2796,
  .dec 2 2802 2800, .inc 1 2801, .jump 2799, .dec 1 2806 2803, .inc 7 2804, .inc 6 2805,
  .jump 2802, .dec 6 2812 2807, .inc 7 2808, .dec 6 2811 2809, .inc 1 2810, .jump 2808,
  .jump 2802, .dec 7 2815 2813, .inc 2 2814, .jump 2812, .dec 3 2819 2816, .inc 6 2817,
  .inc 1 2818, .jump 2815, .dec 6 2822 2820, .inc 3 2821, .jump 2819, .dec 2 2830 2823]
def mid58 : List Instruction := [
  .inc 7 2824, .dec 6 2826 2825, .jump 2829, .dec 7 2829 2827, .inc 6 2828, .jump 2826,
  .jump 2822, .dec 7 2833 2831, .inc 2 2832, .jump 2830, .dec 1 2837 2834, .inc 7 2835,
  .inc 6 2836, .jump 2833, .dec 6 2843 2838, .inc 7 2839, .dec 6 2842 2840, .inc 1 2841,
  .jump 2839, .jump 2833, .dec 7 2847 2844, .inc 1 2845, .inc 1 2846, .jump 2843,
  .inc 1 2848, .dec 1 2851 2849, .inc 6 2850, .jump 2848, .dec 2 2854 2852, .inc 1 2853,
  .jump 2851, .dec 1 2858 2855, .inc 7 2856, .inc 6 2857, .jump 2854, .dec 6 2864 2859,
  .inc 7 2860, .dec 6 2863 2861, .inc 1 2862, .jump 2860, .jump 2854, .dec 7 2867 2865,
  .inc 2 2866, .jump 2864, .dec 4 2871 2868, .inc 6 2869, .inc 1 2870, .jump 2867]
def mid59 : List Instruction := [
  .dec 6 2874 2872, .inc 4 2873, .jump 2871, .dec 1 2877 2875, .inc 6 2876, .jump 2874,
  .dec 2 2880 2878, .inc 1 2879, .jump 2877, .dec 1 2884 2881, .inc 7 2882, .inc 6 2883,
  .jump 2880, .dec 6 2890 2885, .inc 7 2886, .dec 6 2889 2887, .inc 1 2888, .jump 2886,
  .jump 2880, .dec 7 2893 2891, .inc 2 2892, .jump 2890, .dec 3 2897 2894, .inc 6 2895,
  .inc 1 2896, .jump 2893, .dec 6 2900 2898, .inc 3 2899, .jump 2897, .dec 2 2908 2901,
  .inc 7 2902, .dec 6 2904 2903, .jump 2907, .dec 7 2907 2905, .inc 6 2906, .jump 2904,
  .jump 2900, .dec 7 2911 2909, .inc 2 2910, .jump 2908, .dec 1 2915 2912, .inc 7 2913,
  .inc 6 2914, .jump 2911, .dec 6 2921 2916, .inc 7 2917, .dec 6 2920 2918, .inc 1 2919]
def mid60 : List Instruction := [
  .jump 2917, .jump 2911, .dec 7 2925 2922, .inc 1 2923, .inc 1 2924, .jump 2921,
  .inc 1 2926, .dec 2 2934 2927, .inc 7 2928, .dec 6 2930 2929, .jump 2933, .dec 7 2933 2931,
  .inc 6 2932, .jump 2930, .jump 2926, .dec 7 2937 2935, .inc 2 2936, .jump 2934,
  .dec 1 2941 2938, .inc 7 2939, .inc 6 2940, .jump 2937, .dec 6 2947 2942, .inc 7 2943,
  .dec 6 2946 2944, .inc 1 2945, .jump 2943, .jump 2937, .dec 7 2951 2948, .inc 1 2949,
  .inc 1 2950, .jump 2947, .inc 1 2952, .inc 1 2953, .dec 2 2961 2954, .inc 7 2955,
  .dec 6 2957 2956, .jump 2960, .dec 7 2960 2958, .inc 6 2959, .jump 2957, .jump 2953,
  .dec 7 2964 2962, .inc 2 2963, .jump 2961, .dec 1 2968 2965, .inc 7 2966, .inc 6 2967]
def mid61 : List Instruction := [
  .jump 2964, .dec 6 2974 2969, .inc 7 2970, .dec 6 2973 2971, .inc 1 2972, .jump 2970,
  .jump 2964, .dec 7 2978 2975, .inc 1 2976, .inc 1 2977, .jump 2974, .inc 1 2979,
  .dec 1 2982 2980, .inc 6 2981, .jump 2979, .dec 2 2985 2983, .inc 1 2984, .jump 2982,
  .dec 1 2989 2986, .inc 7 2987, .inc 6 2988, .jump 2985, .dec 6 2995 2990, .inc 7 2991,
  .dec 6 2994 2992, .inc 1 2993, .jump 2991, .jump 2985, .dec 7 2998 2996, .inc 2 2997,
  .jump 2995, .dec 4 3002 2999, .inc 6 3000, .inc 1 3001, .jump 2998, .dec 6 3005 3003,
  .inc 4 3004, .jump 3002, .dec 2 3013 3006, .inc 7 3007, .dec 6 3009 3008, .jump 3012,
  .dec 7 3012 3010, .inc 6 3011, .jump 3009, .jump 3005, .dec 7 3016 3014, .inc 2 3015]
def mid62 : List Instruction := [
  .jump 3013, .dec 1 3020 3017, .inc 7 3018, .inc 6 3019, .jump 3016, .dec 6 3026 3021,
  .inc 7 3022, .dec 6 3025 3023, .inc 1 3024, .jump 3022, .jump 3016, .dec 7 3030 3027,
  .inc 1 3028, .inc 1 3029, .jump 3026, .inc 1 3031, .dec 1 3034 3032, .inc 6 3033,
  .jump 3031, .dec 2 3037 3035, .inc 1 3036, .jump 3034, .dec 1 3041 3038, .inc 7 3039,
  .inc 6 3040, .jump 3037, .dec 6 3047 3042, .inc 7 3043, .dec 6 3046 3044, .inc 1 3045,
  .jump 3043, .jump 3037, .dec 7 3050 3048, .inc 2 3049, .jump 3047, .dec 4 3054 3051,
  .inc 6 3052, .inc 1 3053, .jump 3050, .dec 6 3057 3055, .inc 4 3056, .jump 3054,
  .dec 2 3065 3058, .inc 7 3059, .dec 6 3061 3060, .jump 3064, .dec 7 3064 3062, .inc 6 3063]
def mid63 : List Instruction := [
  .jump 3061, .jump 3057, .dec 7 3068 3066, .inc 2 3067, .jump 3065, .dec 1 3072 3069,
  .inc 7 3070, .inc 6 3071, .jump 3068, .dec 6 3078 3073, .inc 7 3074, .dec 6 3077 3075,
  .inc 1 3076, .jump 3074, .jump 3068, .dec 7 3082 3079, .inc 1 3080, .inc 1 3081,
  .jump 3078, .inc 1 3083, .dec 2 3091 3084, .inc 7 3085, .dec 6 3087 3086, .jump 3090,
  .dec 7 3090 3088, .inc 6 3089, .jump 3087, .jump 3083, .dec 7 3094 3092, .inc 2 3093,
  .jump 3091, .dec 1 3098 3095, .inc 7 3096, .inc 6 3097, .jump 3094, .dec 6 3104 3099,
  .inc 7 3100, .dec 6 3103 3101, .inc 1 3102, .jump 3100, .jump 3094, .dec 7 3108 3105,
  .inc 1 3106, .inc 1 3107, .jump 3104, .inc 1 3109, .dec 1 3112 3110, .inc 6 3111]
def mid64 : List Instruction := [
  .jump 3109, .dec 2 3115 3113, .inc 1 3114, .jump 3112, .dec 1 3119 3116, .inc 7 3117,
  .inc 6 3118, .jump 3115, .dec 6 3125 3120, .inc 7 3121, .dec 6 3124 3122, .inc 1 3123,
  .jump 3121, .jump 3115, .dec 7 3128 3126, .inc 2 3127, .jump 3125, .dec 4 3132 3129,
  .inc 6 3130, .inc 1 3131, .jump 3128, .dec 6 3135 3133, .inc 4 3134, .jump 3132,
  .dec 1 3138 3136, .inc 6 3137, .jump 3135, .dec 2 3141 3139, .inc 1 3140, .jump 3138,
  .dec 1 3145 3142, .inc 7 3143, .inc 6 3144, .jump 3141, .dec 6 3151 3146, .inc 7 3147,
  .dec 6 3150 3148, .inc 1 3149, .jump 3147, .jump 3141, .dec 7 3154 3152, .inc 2 3153,
  .jump 3151, .dec 4 3158 3155, .inc 6 3156, .inc 1 3157, .jump 3154, .dec 6 3161 3159]
def mid65 : List Instruction := [
  .inc 4 3160, .jump 3158, .dec 1 3164 3162, .inc 6 3163, .jump 3161, .dec 2 3167 3165,
  .inc 1 3166, .jump 3164, .dec 1 3171 3168, .inc 7 3169, .inc 6 3170, .jump 3167,
  .dec 6 3177 3172, .inc 7 3173, .dec 6 3176 3174, .inc 1 3175, .jump 3173, .jump 3167,
  .dec 7 3180 3178, .inc 2 3179, .jump 3177, .dec 4 3184 3181, .inc 6 3182, .inc 1 3183,
  .jump 3180, .dec 6 3187 3185, .inc 4 3186, .jump 3184, .dec 1 3190 3188, .inc 6 3189,
  .jump 3187, .dec 2 3193 3191, .inc 1 3192, .jump 3190, .dec 1 3197 3194, .inc 7 3195,
  .inc 6 3196, .jump 3193, .dec 6 3203 3198, .inc 7 3199, .dec 6 3202 3200, .inc 1 3201,
  .jump 3199, .jump 3193, .dec 7 3206 3204, .inc 2 3205, .jump 3203, .dec 3 3210 3207]
def mid66 : List Instruction := [
  .inc 6 3208, .inc 1 3209, .jump 3206, .dec 6 3213 3211, .inc 3 3212, .jump 3210,
  .dec 2 3221 3214, .inc 7 3215, .dec 6 3217 3216, .jump 3220, .dec 7 3220 3218, .inc 6 3219,
  .jump 3217, .jump 3213, .dec 7 3224 3222, .inc 2 3223, .jump 3221, .dec 1 3228 3225,
  .inc 7 3226, .inc 6 3227, .jump 3224, .dec 6 3234 3229, .inc 7 3230, .dec 6 3233 3231,
  .inc 1 3232, .jump 3230, .jump 3224, .dec 7 3238 3235, .inc 1 3236, .inc 1 3237,
  .jump 3234, .inc 1 3239, .dec 1 3242 3240, .inc 6 3241, .jump 3239, .dec 2 3245 3243,
  .inc 1 3244, .jump 3242, .dec 1 3249 3246, .inc 7 3247, .inc 6 3248, .jump 3245,
  .dec 6 3255 3250, .inc 7 3251, .dec 6 3254 3252, .inc 1 3253, .jump 3251, .jump 3245]
def mid67 : List Instruction := [
  .dec 7 3258 3256, .inc 2 3257, .jump 3255, .dec 4 3262 3259, .inc 6 3260, .inc 1 3261,
  .jump 3258, .dec 6 3265 3263, .inc 4 3264, .jump 3262, .dec 1 3268 3266, .inc 6 3267,
  .jump 3265, .dec 2 3271 3269, .inc 1 3270, .jump 3268, .dec 1 3275 3272, .inc 7 3273,
  .inc 6 3274, .jump 3271, .dec 6 3281 3276, .inc 7 3277, .dec 6 3280 3278, .inc 1 3279,
  .jump 3277, .jump 3271, .dec 7 3284 3282, .inc 2 3283, .jump 3281, .dec 3 3288 3285,
  .inc 6 3286, .inc 1 3287, .jump 3284, .dec 6 3291 3289, .inc 3 3290, .jump 3288,
  .dec 2 3299 3292, .inc 7 3293, .dec 6 3295 3294, .jump 3298, .dec 7 3298 3296, .inc 6 3297,
  .jump 3295, .jump 3291, .dec 7 3302 3300, .inc 2 3301, .jump 3299, .dec 1 3306 3303]
def mid68 : List Instruction := [
  .inc 7 3304, .inc 6 3305, .jump 3302, .dec 6 3312 3307, .inc 7 3308, .dec 6 3311 3309,
  .inc 1 3310, .jump 3308, .jump 3302, .dec 7 3316 3313, .inc 1 3314, .inc 1 3315,
  .jump 3312, .inc 1 3317, .dec 2 3325 3318, .inc 7 3319, .dec 6 3321 3320, .jump 3324,
  .dec 7 3324 3322, .inc 6 3323, .jump 3321, .jump 3317, .dec 7 3328 3326, .inc 2 3327,
  .jump 3325, .dec 1 3332 3329, .inc 7 3330, .inc 6 3331, .jump 3328, .dec 6 3338 3333,
  .inc 7 3334, .dec 6 3337 3335, .inc 1 3336, .jump 3334, .jump 3328, .dec 7 3342 3339,
  .inc 1 3340, .inc 1 3341, .jump 3338, .inc 1 3343, .inc 1 3344, .dec 2 3352 3345,
  .inc 7 3346, .dec 6 3348 3347, .jump 3351, .dec 7 3351 3349, .inc 6 3350, .jump 3348]
def mid69 : List Instruction := [
  .jump 3344, .dec 7 3355 3353, .inc 2 3354, .jump 3352, .dec 1 3359 3356, .inc 7 3357,
  .inc 6 3358, .jump 3355, .dec 6 3365 3360, .inc 7 3361, .dec 6 3364 3362, .inc 1 3363,
  .jump 3361, .jump 3355, .dec 7 3369 3366, .inc 1 3367, .inc 1 3368, .jump 3365,
  .inc 1 3370, .dec 1 3373 3371, .inc 6 3372, .jump 3370, .dec 2 3376 3374, .inc 1 3375,
  .jump 3373, .dec 1 3380 3377, .inc 7 3378, .inc 6 3379, .jump 3376, .dec 6 3386 3381,
  .inc 7 3382, .dec 6 3385 3383, .inc 1 3384, .jump 3382, .jump 3376, .dec 7 3389 3387,
  .inc 2 3388, .jump 3386, .dec 4 3393 3390, .inc 6 3391, .inc 1 3392, .jump 3389,
  .dec 6 3396 3394, .inc 4 3395, .jump 3393, .dec 2 3404 3397, .inc 7 3398, .dec 6 3400 3399]
def mid70 : List Instruction := [
  .jump 3403, .dec 7 3403 3401, .inc 6 3402, .jump 3400, .jump 3396, .dec 7 3407 3405,
  .inc 2 3406, .jump 3404, .dec 1 3411 3408, .inc 7 3409, .inc 6 3410, .jump 3407,
  .dec 6 3417 3412, .inc 7 3413, .dec 6 3416 3414, .inc 1 3415, .jump 3413, .jump 3407,
  .dec 7 3421 3418, .inc 1 3419, .inc 1 3420, .jump 3417, .inc 1 3422, .dec 1 3425 3423,
  .inc 6 3424, .jump 3422, .dec 2 3428 3426, .inc 1 3427, .jump 3425, .dec 1 3432 3429,
  .inc 7 3430, .inc 6 3431, .jump 3428, .dec 6 3438 3433, .inc 7 3434, .dec 6 3437 3435,
  .inc 1 3436, .jump 3434, .jump 3428, .dec 7 3441 3439, .inc 2 3440, .jump 3438,
  .dec 4 3445 3442, .inc 6 3443, .inc 1 3444, .jump 3441, .dec 6 3448 3446, .inc 4 3447]
def mid71 : List Instruction := [
  .jump 3445, .dec 2 3456 3449, .inc 7 3450, .dec 6 3452 3451, .jump 3455, .dec 7 3455 3453,
  .inc 6 3454, .jump 3452, .jump 3448, .dec 7 3459 3457, .inc 2 3458, .jump 3456,
  .dec 1 3463 3460, .inc 7 3461, .inc 6 3462, .jump 3459, .dec 6 3469 3464, .inc 7 3465,
  .dec 6 3468 3466, .inc 1 3467, .jump 3465, .jump 3459, .dec 7 3473 3470, .inc 1 3471,
  .inc 1 3472, .jump 3469, .inc 1 3474, .dec 2 3482 3475, .inc 7 3476, .dec 6 3478 3477,
  .jump 3481, .dec 7 3481 3479, .inc 6 3480, .jump 3478, .jump 3474, .dec 7 3485 3483,
  .inc 2 3484, .jump 3482, .dec 1 3489 3486, .inc 7 3487, .inc 6 3488, .jump 3485,
  .dec 6 3495 3490, .inc 7 3491, .dec 6 3494 3492, .inc 1 3493, .jump 3491, .jump 3485]
def mid72 : List Instruction := [
  .dec 7 3499 3496, .inc 1 3497, .inc 1 3498, .jump 3495, .inc 1 3500, .dec 2 3508 3501,
  .inc 7 3502, .dec 6 3504 3503, .jump 3507, .dec 7 3507 3505, .inc 6 3506, .jump 3504,
  .jump 3500, .dec 7 3511 3509, .inc 2 3510, .jump 3508, .dec 1 3515 3512, .inc 7 3513,
  .inc 6 3514, .jump 3511, .dec 6 3521 3516, .inc 7 3517, .dec 6 3520 3518, .inc 1 3519,
  .jump 3517, .jump 3511, .dec 7 3525 3522, .inc 1 3523, .inc 1 3524, .jump 3521,
  .inc 1 3526, .inc 1 3527, .dec 2 3535 3528, .inc 7 3529, .dec 6 3531 3530, .jump 3534,
  .dec 7 3534 3532, .inc 6 3533, .jump 3531, .jump 3527, .dec 7 3538 3536, .inc 2 3537,
  .jump 3535, .dec 1 3542 3539, .inc 7 3540, .inc 6 3541, .jump 3538, .dec 6 3548 3543]
def mid73 : List Instruction := [
  .inc 7 3544, .dec 6 3547 3545, .inc 1 3546, .jump 3544, .jump 3538, .dec 7 3552 3549,
  .inc 1 3550, .inc 1 3551, .jump 3548, .inc 1 3553, .dec 2 3561 3554, .inc 7 3555,
  .dec 6 3557 3556, .jump 3560, .dec 7 3560 3558, .inc 6 3559, .jump 3557, .jump 3553,
  .dec 7 3564 3562, .inc 2 3563, .jump 3561, .dec 1 3568 3565, .inc 7 3566, .inc 6 3567,
  .jump 3564, .dec 6 3574 3569, .inc 7 3570, .dec 6 3573 3571, .inc 1 3572, .jump 3570,
  .jump 3564, .dec 7 3578 3575, .inc 1 3576, .inc 1 3577, .jump 3574, .inc 1 3579,
  .dec 1 3582 3580, .inc 6 3581, .jump 3579, .dec 2 3585 3583, .inc 1 3584, .jump 3582,
  .dec 1 3589 3586, .inc 7 3587, .inc 6 3588, .jump 3585, .dec 6 3595 3590, .inc 7 3591]
def mid74 : List Instruction := [
  .dec 6 3594 3592, .inc 1 3593, .jump 3591, .jump 3585, .dec 7 3598 3596, .inc 2 3597,
  .jump 3595, .dec 3 3602 3599, .inc 6 3600, .inc 1 3601, .jump 3598, .dec 6 3605 3603,
  .inc 3 3604, .jump 3602, .dec 1 3608 3606, .inc 6 3607, .jump 3605, .dec 2 3611 3609,
  .inc 1 3610, .jump 3608, .dec 1 3615 3612, .inc 7 3613, .inc 6 3614, .jump 3611,
  .dec 6 3621 3616, .inc 7 3617, .dec 6 3620 3618, .inc 1 3619, .jump 3617, .jump 3611,
  .dec 7 3624 3622, .inc 2 3623, .jump 3621, .dec 5 3628 3625, .inc 6 3626, .inc 1 3627,
  .jump 3624, .dec 6 3631 3629, .inc 5 3630, .jump 3628, .dec 2 3639 3632, .inc 7 3633,
  .dec 6 3635 3634, .jump 3638, .dec 7 3638 3636, .inc 6 3637, .jump 3635, .jump 3631]
def mid75 : List Instruction := [
  .dec 7 3642 3640, .inc 2 3641, .jump 3639, .dec 1 3646 3643, .inc 7 3644, .inc 6 3645,
  .jump 3642, .dec 6 3652 3647, .inc 7 3648, .dec 6 3651 3649, .inc 1 3650, .jump 3648,
  .jump 3642, .dec 7 3656 3653, .inc 1 3654, .inc 1 3655, .jump 3652, .inc 1 3657,
  .dec 1 3660 3658, .inc 6 3659, .jump 3657, .dec 2 3663 3661, .inc 1 3662, .jump 3660,
  .dec 1 3667 3664, .inc 7 3665, .inc 6 3666, .jump 3663, .dec 6 3673 3668, .inc 7 3669,
  .dec 6 3672 3670, .inc 1 3671, .jump 3669, .jump 3663, .dec 7 3676 3674, .inc 2 3675,
  .jump 3673, .dec 4 3680 3677, .inc 6 3678, .inc 1 3679, .jump 3676, .dec 6 3683 3681,
  .inc 4 3682, .jump 3680, .dec 2 3691 3684, .inc 7 3685, .dec 6 3687 3686, .jump 3690]
def mid76 : List Instruction := [
  .dec 7 3690 3688, .inc 6 3689, .jump 3687, .jump 3683, .dec 7 3694 3692, .inc 2 3693,
  .jump 3691, .dec 1 3698 3695, .inc 7 3696, .inc 6 3697, .jump 3694, .dec 6 3704 3699,
  .inc 7 3700, .dec 6 3703 3701, .inc 1 3702, .jump 3700, .jump 3694, .dec 7 3708 3705,
  .inc 1 3706, .inc 1 3707, .jump 3704, .inc 1 3709, .dec 1 3712 3710, .inc 6 3711,
  .jump 3709, .dec 2 3715 3713, .inc 1 3714, .jump 3712, .dec 1 3719 3716, .inc 7 3717,
  .inc 6 3718, .jump 3715, .dec 6 3725 3720, .inc 7 3721, .dec 6 3724 3722, .inc 1 3723,
  .jump 3721, .jump 3715, .dec 7 3728 3726, .inc 2 3727, .jump 3725, .dec 4 3732 3729,
  .inc 6 3730, .inc 1 3731, .jump 3728, .dec 6 3735 3733, .inc 4 3734, .jump 3732]
def mid77 : List Instruction := [
  .dec 1 3738 3736, .inc 6 3737, .jump 3735, .dec 2 3741 3739, .inc 1 3740, .jump 3738,
  .dec 1 3745 3742, .inc 7 3743, .inc 6 3744, .jump 3741, .dec 6 3751 3746, .inc 7 3747,
  .dec 6 3750 3748, .inc 1 3749, .jump 3747, .jump 3741, .dec 7 3754 3752, .inc 2 3753,
  .jump 3751, .dec 5 3758 3755, .inc 6 3756, .inc 1 3757, .jump 3754, .dec 6 3761 3759,
  .inc 5 3760, .jump 3758, .dec 2 3769 3762, .inc 7 3763, .dec 6 3765 3764, .jump 3768,
  .dec 7 3768 3766, .inc 6 3767, .jump 3765, .jump 3761, .dec 7 3772 3770, .inc 2 3771,
  .jump 3769, .dec 1 3776 3773, .inc 7 3774, .inc 6 3775, .jump 3772, .dec 6 3782 3777,
  .inc 7 3778, .dec 6 3781 3779, .inc 1 3780, .jump 3778, .jump 3772, .dec 7 3786 3783]
def mid78 : List Instruction := [
  .inc 1 3784, .inc 1 3785, .jump 3782, .inc 1 3787, .dec 2 3795 3788, .inc 7 3789,
  .dec 6 3791 3790, .jump 3794, .dec 7 3794 3792, .inc 6 3793, .jump 3791, .jump 3787,
  .dec 7 3798 3796, .inc 2 3797, .jump 3795, .dec 1 3802 3799, .inc 7 3800, .inc 6 3801,
  .jump 3798, .dec 6 3808 3803, .inc 7 3804, .dec 6 3807 3805, .inc 1 3806, .jump 3804,
  .jump 3798, .dec 7 3812 3809, .inc 1 3810, .inc 1 3811, .jump 3808, .inc 1 3813,
  .dec 2 3821 3814, .inc 7 3815, .dec 6 3817 3816, .jump 3820, .dec 7 3820 3818, .inc 6 3819,
  .jump 3817, .jump 3813, .dec 7 3824 3822, .inc 2 3823, .jump 3821, .dec 1 3828 3825,
  .inc 7 3826, .inc 6 3827, .jump 3824, .dec 6 3834 3829, .inc 7 3830, .dec 6 3833 3831]
def mid79 : List Instruction := [
  .inc 1 3832, .jump 3830, .jump 3824, .dec 7 3838 3835, .inc 1 3836, .inc 1 3837,
  .jump 3834, .inc 4 3839, .dec 2 3847 3840, .inc 7 3841, .dec 6 3843 3842, .jump 3846,
  .dec 7 3846 3844, .inc 6 3845, .jump 3843, .jump 3839, .dec 7 3850 3848, .inc 2 3849,
  .jump 3847, .dec 1 3854 3851, .inc 7 3852, .inc 6 3853, .jump 3850, .dec 6 3860 3855,
  .inc 7 3856, .dec 6 3859 3857, .inc 1 3858, .jump 3856, .jump 3850, .dec 7 3864 3861,
  .inc 1 3862, .inc 1 3863, .jump 3860, .dec 1 3867 3865, .inc 6 3866, .jump 3864,
  .dec 2 3870 3868, .inc 1 3869, .jump 3867, .dec 1 3874 3871, .inc 7 3872, .inc 6 3873,
  .jump 3870, .dec 6 3880 3875, .inc 7 3876, .dec 6 3879 3877, .inc 1 3878, .jump 3876]
def mid80 : List Instruction := [
  .jump 3870, .dec 7 3883 3881, .inc 2 3882, .jump 3880, .dec 5 3887 3884, .inc 6 3885,
  .inc 1 3886, .jump 3883, .dec 6 3890 3888, .inc 5 3889, .jump 3887, .dec 1 3893 3891,
  .inc 6 3892, .jump 3890, .dec 2 3896 3894, .inc 1 3895, .jump 3893, .dec 1 3900 3897,
  .inc 7 3898, .inc 6 3899, .jump 3896, .dec 6 3906 3901, .inc 7 3902, .dec 6 3905 3903,
  .inc 1 3904, .jump 3902, .jump 3896, .dec 7 3909 3907, .inc 2 3908, .jump 3906,
  .dec 4 3913 3910, .inc 6 3911, .inc 1 3912, .jump 3909, .dec 6 3916 3914, .inc 4 3915,
  .jump 3913, .dec 1 3919 3917, .inc 6 3918, .jump 3916, .dec 2 3922 3920, .inc 1 3921,
  .jump 3919, .dec 1 3926 3923, .inc 7 3924, .inc 6 3925, .jump 3922, .dec 6 3932 3927]
def mid81 : List Instruction := [
  .inc 7 3928, .dec 6 3931 3929, .inc 1 3930, .jump 3928, .jump 3922, .dec 7 3935 3933,
  .inc 2 3934, .jump 3932, .dec 5 3939 3936, .inc 6 3937, .inc 1 3938, .jump 3935,
  .dec 6 3942 3940, .inc 5 3941, .jump 3939, .dec 2 3950 3943, .inc 7 3944, .dec 6 3946 3945,
  .jump 3949, .dec 7 3949 3947, .inc 6 3948, .jump 3946, .jump 3942, .dec 7 3953 3951,
  .inc 2 3952, .jump 3950, .dec 1 3957 3954, .inc 7 3955, .inc 6 3956, .jump 3953,
  .dec 6 3963 3958, .inc 7 3959, .dec 6 3962 3960, .inc 1 3961, .jump 3959, .jump 3953,
  .dec 7 3967 3964, .inc 1 3965, .inc 1 3966, .jump 3963, .inc 1 3968, .inc 1 3969,
  .dec 2 3977 3970, .inc 7 3971, .dec 6 3973 3972, .jump 3976, .dec 7 3976 3974, .inc 6 3975]
def mid82 : List Instruction := [
  .jump 3973, .jump 3969, .dec 7 3980 3978, .inc 2 3979, .jump 3977, .dec 1 3984 3981,
  .inc 7 3982, .inc 6 3983, .jump 3980, .dec 6 3990 3985, .inc 7 3986, .dec 6 3989 3987,
  .inc 1 3988, .jump 3986, .jump 3980, .dec 7 3994 3991, .inc 1 3992, .inc 1 3993,
  .jump 3990, .inc 1 3995, .dec 1 3998 3996, .inc 6 3997, .jump 3995, .dec 2 4001 3999,
  .inc 1 4000, .jump 3998, .dec 1 4005 4002, .inc 7 4003, .inc 6 4004, .jump 4001,
  .dec 6 4011 4006, .inc 7 4007, .dec 6 4010 4008, .inc 1 4009, .jump 4007, .jump 4001,
  .dec 7 4014 4012, .inc 2 4013, .jump 4011, .dec 4 4018 4015, .inc 6 4016, .inc 1 4017,
  .jump 4014, .dec 6 4021 4019, .inc 4 4020, .jump 4018, .dec 1 4024 4022, .inc 6 4023]
def mid83 : List Instruction := [
  .jump 4021, .dec 2 4027 4025, .inc 1 4026, .jump 4024, .dec 1 4031 4028, .inc 7 4029,
  .inc 6 4030, .jump 4027, .dec 6 4037 4032, .inc 7 4033, .dec 6 4036 4034, .inc 1 4035,
  .jump 4033, .jump 4027, .dec 7 4040 4038, .inc 2 4039, .jump 4037, .dec 4 4044 4041,
  .inc 6 4042, .inc 1 4043, .jump 4040, .dec 6 4047 4045, .inc 4 4046, .jump 4044,
  .dec 1 4050 4048, .inc 6 4049, .jump 4047, .dec 2 4053 4051, .inc 1 4052, .jump 4050,
  .dec 1 4057 4054, .inc 7 4055, .inc 6 4056, .jump 4053, .dec 6 4063 4058, .inc 7 4059,
  .dec 6 4062 4060, .inc 1 4061, .jump 4059, .jump 4053, .dec 7 4066 4064, .inc 2 4065,
  .jump 4063, .dec 5 4070 4067, .inc 6 4068, .inc 1 4069, .jump 4066, .dec 6 4073 4071]
def mid84 : List Instruction := [
  .inc 5 4072, .jump 4070, .dec 2 4081 4074, .inc 7 4075, .dec 6 4077 4076, .jump 4080,
  .dec 7 4080 4078, .inc 6 4079, .jump 4077, .jump 4073, .dec 7 4084 4082, .inc 2 4083,
  .jump 4081, .dec 1 4088 4085, .inc 7 4086, .inc 6 4087, .jump 4084, .dec 6 4094 4089,
  .inc 7 4090, .dec 6 4093 4091, .inc 1 4092, .jump 4090, .jump 4084, .dec 7 4098 4095,
  .inc 1 4096, .inc 1 4097, .jump 4094, .inc 1 4099, .inc 1 4100, .dec 2 4108 4101,
  .inc 7 4102, .dec 6 4104 4103, .jump 4107, .dec 7 4107 4105, .inc 6 4106, .jump 4104,
  .jump 4100, .dec 7 4111 4109, .inc 2 4110, .jump 4108, .dec 1 4115 4112, .inc 7 4113,
  .inc 6 4114, .jump 4111, .dec 6 4121 4116, .inc 7 4117, .dec 6 4120 4118, .inc 1 4119]
def mid85 : List Instruction := [
  .jump 4117, .jump 4111, .dec 7 4125 4122, .inc 1 4123, .inc 1 4124, .jump 4121,
  .inc 1 4126, .dec 2 4134 4127, .inc 7 4128, .dec 6 4130 4129, .jump 4133, .dec 7 4133 4131,
  .inc 6 4132, .jump 4130, .jump 4126, .dec 7 4137 4135, .inc 2 4136, .jump 4134,
  .dec 1 4141 4138, .inc 7 4139, .inc 6 4140, .jump 4137, .dec 6 4147 4142, .inc 7 4143,
  .dec 6 4146 4144, .inc 1 4145, .jump 4143, .jump 4137, .dec 7 4151 4148, .inc 1 4149,
  .inc 1 4150, .jump 4147, .inc 1 4152, .dec 1 4155 4153, .inc 6 4154, .jump 4152,
  .dec 2 4158 4156, .inc 1 4157, .jump 4155, .dec 1 4162 4159, .inc 7 4160, .inc 6 4161,
  .jump 4158, .dec 6 4168 4163, .inc 7 4164, .dec 6 4167 4165, .inc 1 4166, .jump 4164]
def mid86 : List Instruction := [
  .jump 4158, .dec 7 4171 4169, .inc 2 4170, .jump 4168, .dec 4 4175 4172, .inc 6 4173,
  .inc 1 4174, .jump 4171, .dec 6 4178 4176, .inc 4 4177, .jump 4175, .dec 1 4181 4179,
  .inc 6 4180, .jump 4178, .dec 2 4184 4182, .inc 1 4183, .jump 4181, .dec 1 4188 4185,
  .inc 7 4186, .inc 6 4187, .jump 4184, .dec 6 4194 4189, .inc 7 4190, .dec 6 4193 4191,
  .inc 1 4192, .jump 4190, .jump 4184, .dec 7 4197 4195, .inc 2 4196, .jump 4194,
  .dec 5 4201 4198, .inc 6 4199, .inc 1 4200, .jump 4197, .dec 6 4204 4202, .inc 5 4203,
  .jump 4201, .dec 2 4212 4205, .inc 7 4206, .dec 6 4208 4207, .jump 4211, .dec 7 4211 4209,
  .inc 6 4210, .jump 4208, .jump 4204, .dec 7 4215 4213, .inc 2 4214, .jump 4212]
def mid87 : List Instruction := [
  .dec 1 4219 4216, .inc 7 4217, .inc 6 4218, .jump 4215, .dec 6 4225 4220, .inc 7 4221,
  .dec 6 4224 4222, .inc 1 4223, .jump 4221, .jump 4215, .dec 7 4229 4226, .inc 1 4227,
  .inc 1 4228, .jump 4225, .inc 1 4230, .dec 2 4238 4231, .inc 7 4232, .dec 6 4234 4233,
  .jump 4237, .dec 7 4237 4235, .inc 6 4236, .jump 4234, .jump 4230, .dec 7 4241 4239,
  .inc 2 4240, .jump 4238, .dec 1 4245 4242, .inc 7 4243, .inc 6 4244, .jump 4241,
  .dec 6 4251 4246, .inc 7 4247, .dec 6 4250 4248, .inc 1 4249, .jump 4247, .jump 4241,
  .dec 7 4255 4252, .inc 1 4253, .inc 1 4254, .jump 4251]
def mid : List Instruction := [mid0, mid1, mid2, mid3, mid4, mid5, mid6, mid7, mid8, mid9, mid10, mid11, mid12, mid13, mid14, mid15, mid16, mid17, mid18, mid19, mid20, mid21, mid22, mid23, mid24, mid25, mid26, mid27, mid28, mid29, mid30, mid31, mid32, mid33, mid34, mid35, mid36, mid37, mid38, mid39, mid40, mid41, mid42, mid43, mid44, mid45, mid46, mid47, mid48, mid49, mid50, mid51, mid52, mid53, mid54, mid55, mid56, mid57, mid58, mid59, mid60, mid61, mid62, mid63, mid64, mid65, mid66, mid67, mid68, mid69, mid70, mid71, mid72, mid73, mid74, mid75, mid76, mid77, mid78, mid79, mid80, mid81, mid82, mid83, mid84, mid85, mid86, mid87].flatten
def post0 : List Instruction := [
  .jump 38, .dec 1 4259 4257, .inc 6 4258, .jump 4256, .dec 2 4262 4260, .inc 1 4261,
  .jump 4259, .dec 1 4266 4263, .inc 7 4264, .inc 6 4265, .jump 4262, .dec 6 4272 4267,
  .inc 7 4268, .dec 6 4271 4269, .inc 1 4270, .jump 4268, .jump 4262, .dec 7 4275 4273,
  .inc 2 4274, .jump 4272, .dec 4 4279 4276, .inc 6 4277, .inc 1 4278, .jump 4275,
  .dec 6 4282 4280, .inc 4 4281, .jump 4279, .dec 2 4290 4283, .inc 7 4284, .dec 6 4286 4285,
  .jump 4289, .dec 7 4289 4287, .inc 6 4288, .jump 4286, .jump 4282, .dec 7 4293 4291,
  .inc 2 4292, .jump 4290, .dec 1 4297 4294, .inc 7 4295, .inc 6 4296, .jump 4293,
  .dec 6 4303 4298, .inc 7 4299, .dec 6 4302 4300, .inc 1 4301, .jump 4299, .jump 4293]
def post1 : List Instruction := [
  .dec 7 4307 4304, .inc 1 4305, .inc 1 4306, .jump 4303, .dec 1 4310 4308, .inc 6 4309,
  .jump 4307, .dec 6 4317 4311, .dec 5 4313 4312, .jump 4310, .inc 5 4314, .dec 6 4317 4315,
  .inc 5 4316, .jump 4314, .dec 5 4319 4318, .jump 4326, .dec 4 4323 4320, .inc 6 4321,
  .inc 1 4322, .jump 4319, .dec 6 4326 4324, .inc 4 4325, .jump 4323, .dec 4 4328 4327,
  .jump 4326, .dec 5 4330 4329, .jump 4328, .dec 4 4357 4331, .dec 1 4334 4332, .inc 6 4333,
  .jump 4331, .dec 2 4337 4335, .inc 1 4336, .jump 4334, .dec 1 4341 4338, .inc 7 4339,
  .inc 6 4340, .jump 4337, .dec 6 4347 4342, .inc 7 4343, .dec 6 4346 4344, .inc 1 4345,
  .jump 4343, .jump 4337, .dec 7 4350 4348, .inc 2 4349, .jump 4347, .dec 5 4354 4351]
def post2 : List Instruction := [
  .inc 6 4352, .inc 1 4353, .jump 4350, .dec 6 4357 4355, .inc 5 4356, .jump 4354,
  .dec 5 4361 4358, .dec 5 4361 4359, .dec 5 4361 4360, .decHalt 5 4361, .dec 5 4363 4362, .jump 4361,
  .dec 2 4371 4364, .inc 7 4365, .dec 6 4367 4366, .jump 4370, .dec 7 4370 4368, .inc 6 4369,
  .jump 4367, .jump 4363, .dec 7 4374 4372, .inc 2 4373, .jump 4371, .dec 6 0 4375,
  .inc 5 4376, .jump 4374]
def post : List Instruction := [post0, post1, post2].flatten
def program (pc : Nat) : Instruction :=
  if pc < 39 then pre.getD pc .halt else if pc < 4255 then mid.getD (pc-39) .halt else post.getD (pc-4255) (.jump pc)

end ShortCS.Literal
