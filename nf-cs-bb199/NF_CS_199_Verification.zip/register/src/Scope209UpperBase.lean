import Scope209Ground
import PositiveWitness
import RPRCore
set_option maxHeartbeats 1500000
set_option maxRecDepth 10000
namespace Scope209.Upper
open NF192.Ground NF192.Numerical NF192.Emitter
open Classical
noncomputable section
private def raw : Term → PositiveWitness.Term
  | .q => .zero
  | .app a b => .app (raw a) (raw b)
  | .h a b => .h (raw a) (raw b)
private theorem raw_succ (n : Nat) : raw (decodeTerm (n+1)) ≠ .zero := by
  rw [decodeTerm_unfold]
  simp only [termStep, Nat.add_one_ne_zero, ↓reduceDIte]
  split <;> simp [raw]
structure Chart (V : Type) where
  J : V
  B : V
  app : V → V → V
  K : V → V
  witness : V → V → V
  k_app : ∀ a x, app (K a) x = a
  b_app : ∀ f g x, app (app (app B f) g) x = app (app f (K x)) (app g x)
  letter : app J J = B
  proper : B ≠ J
  off : ∀ x y, x ≠ y → app (app J (K x)) y = B
  on : ∀ x, app (app J (K x)) x ≠ B
  witness_ext : ∀ a b, app b (witness a b) = app a (witness a b) → a=b
variable {V : Type} (A : Chart V) (w : V → V)
private def obj (n : Nat) : V :=
  PositiveWitness.ev A.J A.app A.K w A.witness (raw (decodeTerm n))
local notation "v" => obj A w
private theorem obj_app (a b : Nat) : v (app a b) = A.app (v a) (v b) := by
  simp only [obj,decodeTerm_app,raw]; rfl
private theorem obj_k (a : Nat) : v (witness a a) = A.K (v a) := by
  simp only [obj,decodeTerm_witness,raw,PositiveWitness.diag]
private theorem obj_q : v 0 = A.J := by
  change v q = A.J
  simp only [obj,decodeTerm_q,raw]; rfl
private theorem obj_s : v 1 = A.B := by
  change v (app 0 0) = A.B
  rw [obj_app,obj_q,A.letter]
private theorem obj_w (d : Nat) : v (witness 0 (d+1)) = w (v (d+1)) := by
  change v (witness q (d+1)) = w (v (d+1))
  simp only [obj,decodeTerm_witness,decodeTerm_q,raw]
  apply PositiveWitness.dedicated
  exact raw_succ d
private theorem obj_ext (d b : Nat) (e : A.app (v b) (v (witness (d+1) b)) = A.app (v (d+1)) (v (witness (d+1) b))) : v (d+1) = v b := by
  simp only [obj,decodeTerm_witness,raw] at e ⊢
  exact PositiveWitness.restrictedExt _ _ _ _ _ A.witness_ext _ _ (raw_succ d) e

def LocalLaw : Prop := ∀ s : V, ∃ x, RPRCore.Law A.app A.K s s x id
private def rel (a b : Nat) : Prop := v a = v b
private theorem allRows (law : ∀ s, RPRCore.Law A.app A.K s s (w s) id) : Scope209.RowsHold (rel A w) := by
  intro a b c u bound x hx
  simp only [Scope209.rowList,List.mem_cons,List.not_mem_nil,or_false] at hx
  rcases hx with e|e|e|e|e|e|e|e|e <;> subst x
  · simp only [row0,evaluate_imp]
    intro hca hac _
    by_cases hc : evaluate (rel A w) c
    · exact hc
    · exact hac (hca (fun h => False.elim (hc h)))
  · change evaluate _ (eqn (app (witness b b) a) b)
    simpa only [evaluate_eqn,rel,obj_app,obj_k] using A.k_app (v b) (v a)
  · change evaluate _ (imp (eqn a b) (imp (eqn a c) (eqn c b)))
    simp only [evaluate_eqn,evaluate_imp,rel]; exact fun e f => f.symm.trans e
  · change evaluate _ (imp (imp (eqn 1 (app (app 0 (witness b b)) a)) (eqn 1 (app (app 0 (witness b b)) b))) (eqn a b))
    simp only [evaluate_imp,evaluate_eqn,rel,obj_app,obj_k,obj_q,obj_s]
    intro h
    by_cases eq : v a = v b
    · exact eq
    · exact False.elim (A.on (v b) (h (A.off (v b) (v a) (fun e => eq e.symm)).symm).symm)
  · change evaluate _ (eqn (app (app (app 1 c) a) b) (app (app c (witness b b)) (app a b)))
    simpa only [evaluate_eqn,rel,obj_app,obj_k,obj_s] using A.b_app (v c) (v a) (v b)
  · change evaluate _ (imp (eqn c b) (eqn (app a c) (app a b)))
    simp only [evaluate_imp,evaluate_eqn,rel,obj_app]; exact congrArg (A.app (v a))
  · change evaluate _ (imp (eqn a c) (eqn (app c b) (app a b)))
    simp only [evaluate_imp,evaluate_eqn,rel,obj_app]; exact fun e => congrArg (fun t => A.app t (v b)) e.symm
  · let S := a+1
    let R (t : Nat) := app S (witness t t)
    let P (t : Nat) := app S (app (app t S) S)
    change evaluate _ (imp (eqn (witness 0 S) c) (imp (eqn (app S c) (R (P (R (app S c))))) (eqn (app (app c b) c) (app S b))))
    simp only [evaluate_imp,evaluate_eqn,rel,R,P,S,obj_app,obj_k,obj_w]
    intro bind eq
    rw [←bind] at eq ⊢
    exact law (v (a+1)) (v b) eq.symm
  · change evaluate _ (row9 (a+1) b)
    simp only [row9,evaluate_imp,evaluate_eqn,rel,obj_app]
    exact obj_ext A w a b

theorem model_of_local_chart (law : LocalLaw A) : ∃ r, Scope209.RowsHold r ∧ ¬ r s q := by
  let choose := fun x => Classical.choose (law x)
  refine ⟨rel A choose,allRows A choose (fun x => Classical.choose_spec (law x)),?_⟩
  intro eq
  change obj A choose 1 = obj A choose 0 at eq
  rw [obj_s,obj_q] at eq
  exact A.proper eq

theorem nonderivable_of_local_chart (law : LocalLaw A) : ¬ Scope209.Deriv goal :=
  Scope209.not_deriv_iff_ground_model.mpr (model_of_local_chart A law)

/-- A lift is required only when every RPR sample succeeds on the range. -/
theorem nonderivable_of_lifts
    (lift : ∀ s : V,
      (∀ x, RPRCore.Sample A.app A.K s s (A.app s x) = A.app s x) →
      ∃ w, ∀ x, A.app (A.app w x) w = A.app s x) : ¬ Scope209.Deriv goal :=
  nonderivable_of_local_chart A (fun s => RPRCore.upperChoice A.app A.K s s id (lift s))
end
end Scope209.Upper
#print axioms Scope209.Upper.nonderivable_of_lifts
