namespace RPRCore
universe u
variable {V : Type u} (op : V → V → V) (K : V → V)
local infixl:70 " ⬝ " => op
def R (s a : V) := s ⬝ K a
def P (J s a : V) := s ⬝ (a ⬝ J ⬝ J)
def Sample (J s a : V) := R op K s (P op J s (R op K s a))
def Law (J s w : V) (read : V → V) : Prop :=
  ∀ x, Sample op K J s (s ⬝ w) = s ⬝ w → (w ⬝ x) ⬝ read w = s ⬝ x

/-- Both maps giving the two signed-grade cardinal inequalities are injective
    on the range. No choice operation is required for this cancellation. -/
theorem upperInjections (J s : V)
    (h : ∀ x, Sample op K J s (s ⬝ x) = s ⬝ x) (x y : V) :
    (R op K s (s ⬝ x) = R op K s (s ⬝ y) → s ⬝ x = s ⬝ y) ∧
    (P op J s (R op K s (s ⬝ x)) = P op J s (R op K s (s ⬝ y)) →
      s ⬝ x = s ⬝ y) := by
  constructor
  · intro e
    exact (h x).symm.trans ((congrArg (fun a => R op K s (P op J s a)) e).trans (h y))
  · intro e
    exact (h x).symm.trans ((congrArg (R op K s) e).trans (h y))

/-- A full chart's choice of either a failed sample or a local lift satisfies
    the literal rule simultaneously for every input x. -/
theorem upperChoice (J s : V) (read : V → V)
    (lift : (∀ x, Sample op K J s (s ⬝ x) = s ⬝ x) →
      ∃ w, ∀ x, (w ⬝ x) ⬝ read w = s ⬝ x) : ∃ w, Law op K J s w read := by
  classical
  by_cases h : ∀ x, Sample op K J s (s ⬝ x) = s ⬝ x
  · obtain ⟨w,hw⟩ := lift h
    exact ⟨w,fun x _ => hw x⟩
  · obtain ⟨w,hw⟩ : ∃ x, Sample op K J s (s ⬝ x) ≠ s ⬝ x := by
      exact Classical.byContradiction fun ne => h fun x => Classical.byContradiction fun bad => ne ⟨x,bad⟩
    exact ⟨w,fun _ ha => False.elim (hw ha)⟩

def k2 (b : V) := K (K b)

/-- B is the field of singleton predicates. The written proof constructs
    this single s by stratified characteristic abstraction. The statement
    below checks what the proof search's law then implies about that s. -/
theorem lowerLift (J s : V) (read : V → V) (B : V → Prop) (p g : V → V)
    (kLaw : ∀ b x, K b ⬝ x = b)
    (gp : ∀ b, B b → g (p b) = b) (pg : ∀ b, B b → p (g b) = b)
    (pIn : ∀ b, B b → B (p b)) (gIn : ∀ b, B b → B (g b))
    (left : ∀ b, B b → s ⬝ b = k2 K (p (p b)))
    (right : ∀ b, B b → s ⬝ K (k2 K b) = k2 K (g b))
    (range : ∀ x, ∃ b, B b ∧ s ⬝ x = k2 K b)
    (witness : ∃ w, Law op K J s w read) :
    ∃ w, ∀ x, (w ⬝ x) ⬝ read w = s ⬝ x := by
  obtain ⟨w,hw⟩ := witness
  obtain ⟨b,hb,wb⟩ := range w
  have r (a : V) (ha : B a) : R op K s (k2 K a) = k2 K (g a) := right a ha
  have pp (a : V) (ha : B a) : P op J s (k2 K a) = k2 K (p (p a)) := by
    change s ⬝ (K (K a) ⬝ J ⬝ J) = _
    rw [kLaw,kLaw,left a ha]
  have sample : Sample op K J s (s ⬝ w) = s ⬝ w := by
    rw [wb]; unfold Sample
    rw [r b hb,pp (g b) (gIn b hb),pg b hb,r (p b) (pIn b hb),gp b hb]
  exact ⟨w,fun x => hw x sample⟩

end RPRCore
#print axioms RPRCore.upperInjections
#print axioms RPRCore.upperChoice
#print axioms RPRCore.lowerLift
