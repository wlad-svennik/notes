namespace PositiveWitness
universe u

/-- The three raw constructor shapes of the compact ground syntax. The blank
    constant is code 0, while both binary constructors always have positive codes. -/
inductive Term where
  | zero
  | app (f x : Term)
  | h (a b : Term)
deriving DecidableEq

variable {V : Type u} (J : V) (op : V → V → V) (K select : V → V)
variable (sep : V → V → V)

/-- Meaning of the raw witness symbol depends on its syntax. -/
noncomputable def ev : Term → V
  | .zero => J
  | .app f x => op (ev f) (ev x)
  | .h a b =>
    if a=b then K (ev a)
    else if a=.zero then select (ev b)
    else sep (ev a) (ev b)

theorem diag (s : Term) :
    ev J op K select sep (.h s s) = K (ev J op K select sep s) := by
  rw [ev,if_pos rfl]

theorem dedicated (s : Term) (positive : s ≠ .zero) :
    ev J op K select sep (.h .zero s) = select (ev J op K select sep s) := by
  rw [ev,if_neg positive.symm,if_pos rfl]

theorem restrictedExt
    (separates : ∀ a b, op b (sep a b)=op a (sep a b) → a=b)
    (a b : Term) (positive : a≠.zero)
    (e : op (ev J op K select sep b) (ev J op K select sep (.h a b)) =
         op (ev J op K select sep a) (ev J op K select sep (.h a b))) :
    ev J op K select sep a = ev J op K select sep b := by
  by_cases h : a=b
  · rw [h]
  · rw [ev,if_neg h,if_neg positive] at e
    exact separates _ _ e

/-- A representative beginning with application is always positive and has
    the same value. Raw positivity thus imposes no restriction on a quotient object. -/
theorem paddedRep (kLaw : ∀ a x, op (K a) x = a) (a : Term) :
    ∃ t : Term, t ≠ .zero ∧ ev J op K select sep t = ev J op K select sep a := by
  refine ⟨.app (.h a a) .zero, ?_, ?_⟩
  · intro h
    cases h
  · change op (ev J op K select sep (.h a a)) J = _
    rw [diag,kLaw]

end PositiveWitness
#print axioms PositiveWitness.dedicated
#print axioms PositiveWitness.restrictedExt
#print axioms PositiveWitness.paddedRep
