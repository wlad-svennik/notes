module
public import FirstCSSearchCore
public import ShortCSColdCore
public import ShortCSLiteral
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace ShortCS.Register
open FirstCS
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers
theorem batch_embedded : Embedded actual FirstCS.batchCode 39 4255 [] [] := actual_eq ▸ ShortCS.Literal.batch_embedded
theorem frozen_ax : Embedded frozen FirstCS.batchCode 39 4255 [] [] :=
  frozen_placement batch_embedded (by decide)

end ShortCS.Register
