import Init

namespace Literal209

inductive Op where | Z | C | D | E | A | H | I

def pair (x y : Nat) := (x+y)*(x+y+1)/2 + y
def ctor (i x y : Nat) := 2*pair x y + i
abbrev ap := ctor 1
abbrev h := ctor 2
abbrev eqn := ctor 1
abbrev imp := ctor 0
def k (v : Nat) := h v v

def step (c d e : Nat) (st : List Nat) (op : Op) : List Nat :=
  match op with
  | .Z => 0::st | .C => c::st | .D => d::st | .E => e::st
  | .A | .H | .I => match st with
    | b::a::s => ctor (match op with | .A => 1 | .H => 2 | _ => 0) a b :: s
    | _ => []

def R (s t : Nat) := ap s (k t)
def P (s t : Nat) := ap s (ap (ap t s) s)
def rpr (s t : Nat) := R s (P s (R s t))

def strength (c s x : Nat) :=
  imp (eqn (h 0 s) c)
    (imp (eqn (ap s c) (rpr s (ap s c))) (eqn (ap (ap c x) c) (ap s x)))
def ext (s x : Nat) :=
  imp (eqn (ap x (h s x)) (ap s (h s x))) (eqn s x)

def combined : List Op := [.Z, .D, .H, .C, .A, .D, .C, .A, .D, .D, .D, .D, .C, .A, .D, .C, .A, .H, .A, .D, .A, .D, .A, .A, .D, .D, .D, .C, .A, .D, .C, .A, .H, .A, .D, .A, .D, .A, .A, .H, .A, .A, .C, .E, .A, .C, .A, .D, .E, .A, .A, .I, .I, .E, .D, .E, .H, .A, .D, .D, .E, .H, .A, .A, .D, .E, .A, .I]

/-- The scoped increment is reflected by d+1. The final extensionality
    formula sits above the strength formula on the proof-search stack. -/
theorem exact_final_block (c d x : Nat) (rest : List Nat) :
    combined.foldl (step c (d+1) x) rest =
      ext (d+1) x :: strength c (d+1) x :: rest := by rfl

/-- Instantiate the auxiliary parameter with exactly the raw witness code.
    The H operation is used on independently named raw representatives. -/
theorem extract {V : Type} (obj : Nat → V) (app : V → V → V) (K : V → V)
    (cover : ∀ v, ∃ a, obj a = v)
    (positive : ∀ v, ∃ d, obj (d+1) = v)
    (appVal : ∀ a b, obj (ap a b) = app (obj a) (obj b))
    (kVal : ∀ a, obj (k a) = K (obj a))
    (raw : ∀ c d x,
      let s := d+1
      obj (h 0 s) = obj c →
      obj (ap s c) = obj (rpr s (ap s c)) →
      obj (ap (ap c x) c) = obj (ap s x)) :
    ∀ s, ∃ w, ∀ x,
      let r := fun v => app s (K v)
      let p := fun v => app s (app (app v s) s)
      r (p (r (app s w))) = app s w → app (app w x) w = app s x := by
  intro s
  obtain ⟨d, rfl⟩ := positive s
  let w := h 0 (d+1)
  refine ⟨obj w, ?_⟩
  intro x
  obtain ⟨a, rfl⟩ := cover x
  dsimp only
  intro probe
  have g : obj (ap (d+1) w) = obj (rpr (d+1) (ap (d+1) w)) := by
    simpa only [rpr, R, P, appVal, kVal] using probe.symm
  simpa only [appVal] using raw w d a rfl g

end Literal209
#print axioms Literal209.exact_final_block
#print axioms Literal209.extract
