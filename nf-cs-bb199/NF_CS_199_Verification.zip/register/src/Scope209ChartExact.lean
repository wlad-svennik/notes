import Scope209Light
import Scope209UpperBase
namespace Scope209
open NF192.Numerical
noncomputable section
private theorem separates {V : Type} (A : Light.Chart V) (a b : V) :
    ∃ z, A.app b z = A.app a z → a=b := by
  classical
  by_cases he : a=b
  · exact ⟨A.J,fun _ => he⟩
  · have diff : ∃ z, A.app b z ≠ A.app a z := by
      apply Classical.byContradiction
      intro h
      apply he
      apply A.ext
      intro z
      apply Eq.symm
      exact Classical.byContradiction fun e => h ⟨z,e⟩
    obtain ⟨z, hz⟩ := diff
    exact ⟨z,fun he => False.elim (hz he)⟩

private def completeChart {V : Type} (A : Light.Chart V) : Upper.Chart V where
  J := A.J
  B := A.B
  app := A.app
  K := A.K
  witness := fun a b => Classical.choose (separates A a b)
  k_app := A.const
  b_app := A.combine
  letter := A.letter
  proper := A.proper
  off := A.off
  on := A.on
  witness_ext := fun a b => Classical.choose_spec (separates A a b)

/-- Exact consistency calibration of the nine ground schemata at the
    level of the extensional RPR application charts. -/
theorem nonderivable_iff_chart_exists :
    (¬ Deriv goal) ↔ ∃ V : Type, ∃ A : Upper.Chart V, Upper.LocalLaw A := by
  constructor
  · intro hn
    obtain ⟨V,A,h⟩ := Light.chart_of_nonderiv hn
    exact ⟨V,completeChart A,h⟩
  · rintro ⟨V,A,h⟩
    exact Upper.nonderivable_of_local_chart A h

end
end Scope209
#print axioms Scope209.nonderivable_iff_chart_exists
