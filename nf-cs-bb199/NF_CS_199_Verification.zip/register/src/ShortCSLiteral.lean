module
public import ShortCSProgram
public import FirstCSRows
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace ShortCS.Literal
open NF192.Numerical NF192.Emitter
theorem mid_eq_compile : mid = compile FirstCS.batchCode 39 4255 [] [] := by rfl

theorem mid_length : mid.length = 4216 := by decide

theorem batch_embedded : Embedded program FirstCS.batchCode 39 4255 [] [] := by
  intro i hi
  have eqsize : FirstCS.batchCode.size = 4216 := by rw [← compile_length FirstCS.batchCode 39 4255 [] [], ← mid_eq_compile, mid_length]
  have ha : ¬ 39+i < 39 := by omega
  have hb : 39+i < 4255 := by omega
  simp only [program,if_neg ha,if_pos hb,Nat.add_sub_cancel_left]
  rw [mid_eq_compile, List.getD_eq_getElem?_getD, List.getElem?_eq_getElem (by simpa only [compile_length] using hi)]
  rfl

theorem selected_batch (n t stack c u v y delta tail : Nat) :
    Reaches program ⟨39,Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩⟩
      (some ⟨4255,(save ⟨n,t,stack,c,u+delta+1,v+y,tail⟩ (FirstCS.rowList (u+delta) (v+y) c u)).regs⟩) :=
  (FirstCS.batch_eval n t stack c u v y delta tail).compiled program 39 4255 [] [] batch_embedded

end ShortCS.Literal
#print axioms ShortCS.Literal.selected_batch
