import FirstCSSearch

/-! The first command of a new epoch has outer selector zero. Its parameter and
continuation still range over every Cantor pair. A fixed detecting word can
therefore be placed immediately after this forced command at arbitrarily late
epochs, independent of the proof state left by previous epochs. -/
namespace ForcedCantorian

open NF192.Numerical NF192.SourceFields
open NF192.ProofSearch (Command candidate candidate_prefix candidate_ne_nil)
open FirstCS (StreamState State checkedRun one StreamSound Deriv)
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000

def step (s : StreamState) : Option StreamState :=
  if s.cursor = 0 then
    FirstCS.streamStep ⟨s.next+1, pair 0 s.next + 1, s.proof⟩
  else FirstCS.streamStep s

def run : Nat → StreamState → Option StreamState
  | 0,s => some s
  | n+1,s => (step s).bind (run n)

theorem continued (n next : Nat) (s : State) :
    step ⟨next,n+1,s⟩ = (one (parse n).1 s).map (fun t => ⟨next,(parse n).2,t⟩) := by
  simpa [step] using FirstCS.stream_continued n next s

theorem fresh (n : Nat) (s : State) :
    step ⟨n,0,s⟩ = step ⟨n+1,pair 0 n+1,s⟩ := by simp [step]

theorem run_add (n m : Nat) (s : StreamState) :
    run (n+m) s = (run n s).bind (run m) := by
  induction n generalizing s with
  | zero => simp [run]
  | succ n ih =>
    rw [Nat.succ_add, run, run]
    cases h : step s with
    | none => rfl
    | some t => simpa only [Option.bind_some] using ih t

theorem continued_candidate (n next : Nat) (s : State) :
    run (candidate n).length ⟨next,n+1,s⟩ =
      (checkedRun (candidate n) s).map (fun t => ⟨next,0,t⟩) := by
  induction n using Nat.strongRecOn generalizing s with
  | ind n ih =>
    rw [candidate]
    simp only [List.length_cons, run, continued, FirstCS.checkedRun_cons]
    cases hs : one (parse n).1 s with
    | none => rfl
    | some t =>
      simp only [Option.map_some, Option.bind_some]
      by_cases hz : (parse n).2 = 0
      · simp [hz, run, checkedRun]
      · simp only [hz, ↓reduceDIte]
        have hlt : (parse n).2 - 1 < n := by
          have hle := parse_decreases n
          omega
        have he : (parse n).2 = ((parse n).2-1)+1 := by omega
        rw [he]
        exact ih ((parse n).2-1) hlt t

theorem fresh_candidate (n : Nat) (s : State) :
    run (candidate (pair 0 n)).length ⟨n,0,s⟩ =
      (checkedRun (candidate (pair 0 n)) s).map (fun t => ⟨n+1,0,t⟩) := by
  have he := continued_candidate (pair 0 n) (n+1) s
  have hn := List.length_pos_iff.mpr (candidate_ne_nil (pair 0 n))
  obtain ⟨m,hm⟩ := Nat.exists_eq_succ_of_ne_zero
    (by omega : (candidate (pair 0 n)).length ≠ 0)
  rw [hm, run, fresh]
  simpa only [hm, run] using he

/-- Every finite command list is the prefix of a residual stream following
the forced MP 0, at an epoch strictly above the supplied bound. -/
theorem forced_cofinal (cs : List Command) (start : Nat) :
    ∃ n, start < n ∧ Matches (.mp 0 :: cs) (pair 0 n) (start+1) := by
  obtain ⟨u,hu,hm⟩ := cofinal cs start
  let n := pair 0 (u+1)
  have le : u+1 ≤ n := by
    have h := Cantor.unpair_right_le n
    simpa [n,Cantor.unpair_pair] using h
  refine ⟨n,by omega,Matches.cons ?_ hm⟩
  exact parse_assemble (.mp 0) (u+1)

def scan (start : Nat) (s : State) : Nat → Option State
  | 0 => some s
  | k+1 => (scan start s k).bind (checkedRun (candidate (pair 0 (start+k))))

theorem scan_reached (start : Nat) (s : State) (k : Nat) :
    ∃ ticks, run ticks ⟨start,0,s⟩ = (scan start s k).map (fun t => ⟨start+k,0,t⟩) := by
  induction k with
  | zero => exact ⟨0,rfl⟩
  | succ n ih =>
    obtain ⟨ticks,ht⟩ := ih
    refine ⟨ticks+(candidate (pair 0 (start+n))).length, ?_⟩
    rw [run_add, ht, scan]
    cases hs : scan start s n with
    | none => rfl
    | some t => exact fresh_candidate (start+n) t

theorem scan_eventually_halts (d : FirstCS.Deriv goal) (start : Nat) (s : State) :
    ∃ k, scan start s k = none := by
  obtain ⟨cs,all⟩ := FirstCS.exists_detecting_word d
  obtain ⟨n,hn,hm⟩ := forced_cofinal cs start
  have idx : start+(n-start) = n := by omega
  refine ⟨(n-start)+1, ?_⟩
  rw [scan,idx,candidate_prefix hm]
  cases hs : scan start s (n-start) with
  | none => rfl
  | some t =>
    simp only [Option.bind_some, FirstCS.checkedRun_append, FirstCS.checkedRun_cons]
    cases h : one (.mp 0) t with
    | none => rfl
    | some u => simp [all]

theorem step_sound (s : StreamState) (hs : s.proof.Sound) : StreamSound (step s) := by
  unfold step
  split
  · exact FirstCS.stream_step_sound _ hs
  · exact FirstCS.stream_step_sound _ hs

theorem run_sound (k : Nat) (s : StreamState) (hs : s.proof.Sound) :
    StreamSound (run k s) := by
  induction k generalizing s with
  | zero => exact hs
  | succ k ih =>
    have h := step_sound s hs
    cases e : step s with
    | none => simpa only [run,e,Option.bind_none] using h
    | some t =>
      have ht : t.proof.Sound := by simpa only [e, StreamSound] using h
      simpa only [run,e,Option.bind_some] using ih t ht

theorem halts_iff_goal (n : Nat) (s : State) (hs : s.Sound) :
    (∃ k, run k ⟨n,0,s⟩ = none) ↔ FirstCS.Deriv goal := by
  constructor
  · rintro ⟨k,h⟩
    simpa only [h, StreamSound] using run_sound k ⟨n,0,s⟩ hs
  · intro h
    obtain ⟨m,hn⟩ := scan_eventually_halts h n s
    obtain ⟨t,ht⟩ := scan_reached n s m
    exact ⟨t,by simpa only [hn, Option.map_none] using ht⟩

end ForcedCantorian
#print axioms ForcedCantorian.forced_cofinal
#print axioms ForcedCantorian.halts_iff_goal
