import FirstSlotGround
import ReadPoint204
import Scope209ChartExact
namespace FirstCalibration
open NF192.Numerical
open NF192.Emitter (row9)
open FirstSlot (RowsHold rowList)
open Scope209.Light (Signature Rows Chart)
private theorem atRow {r} (hr : RowsHold r) (a b c : Nat) (i : Fin 9) :
    evaluate r ((rowList a b c 0)[i.val]'(by
      simpa only [rowList,List.length_cons,List.length_nil] using i.isLt)) :=
  hr a b c 0 (Nat.zero_le _) _ (List.getElem_mem ..)

private def pad (b : Nat) := app (witness b b) 0
private def slot (a b : Nat) := if a=b then witness a b else if a=0 then witness (pad a) b else witness a b
private abbrev sig : Signature Nat := ⟨0,app,slot⟩
private theorem diag (a : Nat) : sig.k a = witness a a := by simp [Signature.k,sig,slot]

private theorem rows_of_scoped {r} (hr : RowsHold r) : Rows sig r := by
  have k (a b : Nat) : r (app (witness b b) a) b := (evaluate_eqn r (app (witness b b) a) b).mp (atRow hr a b 0 1)
  have eu (a b c : Nat) : r a b → r a c → r c b := by
    have v := atRow hr a b c 5
    change evaluate r (imp (eqn a b) (imp (eqn a c) (eqn c b))) at v
    simpa only [evaluate_imp, evaluate_eqn] using v
  have refl (a : Nat) : r a a := eu _ _ _ (k 0 a) (k 0 a)
  have sym {a b : Nat} (v : r a b) : r b a := eu _ _ _ (refl a) v
  have tr {a b c : Nat} (v : r a b) (w : r b c) : r a c := eu _ _ _ w (sym v)
  have fc (a b c : Nat) : r a c → r (app c b) (app a b) := by
    have v := atRow hr a b c 4
    change evaluate r (imp (eqn a c) (eqn (app c b) (app a b))) at v
    simpa only [evaluate_imp,evaluate_eqn] using v
  have ext (a b : Nat) :
      r (app b (witness (a+1) b)) (app (a+1) (witness (a+1) b)) → r (a+1) b := by
    have v := atRow hr a b 0 8
    change evaluate r (row9 (a+1) b) at v
    simpa only [row9,evaluate_imp,evaluate_eqn] using v
  constructor
  · intro a b c
    have v := atRow hr a b c 3
    change evaluate r (imp (eqn c b) (eqn (app a c) (app a b))) at v
    simpa only [evaluate_imp,evaluate_eqn] using v
  · intro a b
    rw [diag]
    exact k _ _
  · exact fc
  · intro a b c
    rw [diag]
    exact (evaluate_eqn r (app (app (app 1 c) a) b) (app (app c (witness b b)) (app a b))).mp (atRow hr a b c 2)
  · exact eu
  · intro x y premise
    have v := atRow hr y x 0 6
    let t := fun i j => app (app 0 (witness i i)) j
    change evaluate r (imp (imp (eqn 1 (t x y)) (eqn 1 (t x x))) (eqn y x)) at v
    simp only [evaluate_imp,evaluate_eqn] at v
    simp only [diag] at premise
    exact sym (v (fun e => sym (premise (sym e))))
  · intro a b given
    by_cases same : a=b
    · subst b; exact refl a
    · change r (app b (slot a b)) (app a (slot a b)) at given
      cases a with
      | succ j => exact ext j b (by simpa [slot,same] using given)
      | zero =>
        have padEq : r (pad 0) 0 := k 0 0
        simp [slot,same] at given
        have hp : r (app b (witness (pad 0) b)) (app (pad 0) (witness (pad 0) b)) :=
          tr given (fc (pad 0) _ 0 padEq)
        obtain ⟨j,eq⟩ : ∃ j, pad 0=j+1 := ⟨_,rfl⟩
        rw [eq] at hp padEq
        exact tr (sym padEq) (ext j b hp)

noncomputable section
private theorem separates {V : Type} (A : Chart V) (a b : V) :
    ∃ z, A.app b z = A.app a z → a=b := by
  classical
  by_cases he : a=b
  · exact ⟨A.J,fun _ => he⟩
  · have diff : ∃ z, A.app b z ≠ A.app a z := by
      apply Classical.byContradiction
      intro h
      apply he
      apply A.ext
      intro z
      apply Eq.symm
      exact Classical.byContradiction fun e => h ⟨z,e⟩
    obtain ⟨z, hz⟩ := diff
    exact ⟨z,fun he => False.elim (hz he)⟩

private def completeChart {V : Type} (A : Chart V) : Scope209.Upper.Chart V where
  J := A.J
  B := A.B
  app := A.app
  K := A.K
  witness := fun a b => Classical.choose (separates A a b)
  k_app := A.const
  b_app := A.combine
  letter := A.letter
  proper := A.proper
  off := A.off
  on := A.on
  witness_ext := fun a b => Classical.choose_spec (separates A a b)


theorem original_chart_of_nonderiv (hn : ¬FirstSlot.Deriv goal) :
    ∃ V : Type, ∃ A : Scope209.Upper.Chart V, Scope209.Upper.LocalLaw A := by
  obtain ⟨rel, hr, hg⟩ := FirstSlot.not_deriv_iff_ground_model.mp hn
  let rows := rows_of_scoped hr
  let A := completeChart (rows.toChart hg)
  refine ⟨rows.Carrier,A,fun s => ?_⟩
  obtain ⟨a,rfl⟩ : ∃ a, rows.obj a = s := Quotient.exists_rep _
  let w := witness 0 (app 0 a)
  apply CantorianReadPoint.changeRead A.app A.K A.B A.k_app A.b_app _ _ (fun _ => rows.obj a) id
  refine ⟨rows.obj w,?_⟩
  intro u
  obtain ⟨x,rfl⟩ : ∃ x, rows.obj x = u := Quotient.exists_rep _
  intro probe
  have v := atRow hr a x w 7
  change evaluate rel (imp (eqn w w)
      (imp (eqn (app a w) (Literal209.rpr a (app a w)))
        (eqn (app (app w x) a) (app a x)))) at v
  simp only [evaluate_imp,evaluate_eqn] at v
  apply rows.obj_eq_iff.mpr
  apply v (rows.rel_refl _)
  apply rows.obj_eq_iff.mp
  have valA (i j : Nat) : rows.obj (Literal209.ap i j) = A.app (rows.obj i) (rows.obj j) := rfl
  have valK (i : Nat) : rows.obj (Literal209.k i) = A.K (rows.obj i) := by
    change rows.obj (witness i i) = rows.obj (sig.k i)
    rw [diag]
  change rows.obj (Literal209.ap a w) = rows.obj (Literal209.rpr a (Literal209.ap a w))
  simp only [Literal209.rpr,Literal209.R,Literal209.P,valA,valK]
  exact probe.symm
end
end FirstCalibration
