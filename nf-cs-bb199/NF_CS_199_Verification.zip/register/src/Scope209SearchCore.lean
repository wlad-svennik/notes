module
public import Eight187Seed
public import SourceEnumeration
@[expose] public section
set_option maxRecDepth 4096
set_option maxHeartbeats 8000000
namespace Scope209
open NF192.Numerical NF192.Emitter
open NF192.ProofSearch (Command)
def lastRow (a b : Nat) := NF192.Emitter.row9 (a+1) b
def rowList (a b c u : Nat) : List Nat := [
  row0 a b c u,
  (app (app (witness b b) a) b),
  (imp (app a b) (imp (app a c) (app c b))),
  (imp (imp (app 1 (app (app 0 (witness b b)) a)) (app 1 (app (app 0 (witness b b)) b))) (app a b)),
  (app (app (app (app 1 c) a) b) (app (app c (witness b b)) (app a b))),
  (imp (app c b) (app (app a c) (app a b))),
  (imp (app a c) (app (app c b) (app a b))),
  (imp (app (witness 0 (a+1)) c) (imp (app (app (a+1) c) (app (a+1) (witness (app (a+1) (app (app (app (a+1) (witness (app (a+1) c) (app (a+1) c))) (a+1)) (a+1))) (app (a+1) (app (app (app (a+1) (witness (app (a+1) c) (app (a+1) c))) (a+1)) (a+1)))))) (app (app (app c b) c) (app (a+1) b)))),
  lastRow a b]
inductive Deriv : Nat → Prop where
  | row {a b c u x : Nat} : u ≤ a → x ∈ rowList a b c u → Deriv x
  | mp {x y : Nat} : Deriv (imp x y) → Deriv x → Deriv y
theorem last_row_split (a b c u : Nat) :
    rowList a b c u = (rowList a b c u).take 8 ++ [lastRow a b] := rfl
theorem deriv_zero : Deriv 0 :=
  .row (a:=0) (b:=0) (c:=0) (u:=0) (by decide) (List.mem_cons_self ..)
structure State where
  top : Nat
  stack : List Nat
  cache : Nat
  param : Nat
def tailRows (a b : Nat) : List (Nat × Nat) → List Nat
  | [] => []
  | (y,d) :: rs => rowList (a+d) (b+y) rs.length a ++ tailRows (a+d+1) (b+y) rs
def rows (u b δ : Nat) (rest : List (Nat × Nat)) (s : State) : List Nat :=
  let a := s.param+u+δ
  let v := s.cache+b
  rowList a v rest.length (s.param+u) ++ tailRows (a+1) v rest
def nip (s : State) : State := ⟨s.top,s.stack.tail,s.stack.headD 0,0⟩
def afterAX (s : State) (zs : List Nat) : State :=
  nip ⟨0,zs.reverse.tail ++ s.top :: s.stack,0,0⟩
def step (cmd : Command) (s : State) : State :=
  match cmd with
  | .mode d =>
    let b := s.param+d
    nip ⟨if s.cache = imp s.top b then b else 0,s.stack,0,0⟩
  | .mp d =>
    match s.param+d with
    | 0 => ⟨s.top,s.stack.tail,s.stack.headD 0,0⟩
    | w+1 => ⟨s.cache,s.stack,s.top,w⟩
  | .ax u b δ rest => afterAX s (rows u b δ rest s)
def observes (cmd : Command) (s : State) : Bool :=
  match cmd with
  | .mp _ => s.cache == goal
  | _ => false
def State.Sound (s : State) : Prop :=
  Deriv s.top ∧ (∀ x ∈ s.stack, Deriv x) ∧ Deriv s.cache
theorem imp_last_ne_cache (a b : Nat) : b ≠ imp (lastRow a b) (a+1) := by
  have h1 := pair_ge_right (a+1) b
  have h2 := imp_ge_right (eqn (app b (witness (a+1) b)) (app (a+1) (witness (a+1) b))) (eqn (a+1) b)
  have h3 := imp_ge_left (lastRow a b) (a+1)
  change b ≠ imp (lastRow a b) (a+1)
  change _ ≤ lastRow a b at h2
  unfold eqn at h2
  omega
theorem tailRows_sound (a b : Nat) (rest : List (Nat × Nat)) : ∀ x ∈ tailRows a b rest, Deriv x := by
  induction rest generalizing a b with
  | nil => simp [tailRows]
  | cons t rest ih =>
    obtain ⟨y,d⟩ := t
    intro x hx
    rcases List.mem_append.mp hx with h|h
    · exact .row (Nat.le_add_right _ _) h
    · exact ih _ _ _ h
theorem rows_sound (u b d : Nat) (rest : List (Nat × Nat)) (s : State) :
    ∀ x ∈ rows u b d rest s, Deriv x := by
  intro x hx
  rcases List.mem_append.mp hx with h|h
  · exact .row (Nat.le_add_right _ _) h
  · exact tailRows_sound _ _ _ _ h
end Scope209
