import ShortCSRegister
import ForcedCantorian
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace ShortCS.Register
open FirstCS NF192 NF192.Numerical NF192.Emitter NF192.SourceFields
open NF192.ProofSearch (Command pack)
def boundary (s : StreamState) : Source.Config :=
  frame 0 s.next s.proof.top (pack s.proof.stack) 0 s.proof.param s.proof.cache 0 0 s.cursor

def embed : Option StreamState → Source.Config
  | none => Source.Config.halted
  | some s => boundary s

def Valid : Option StreamState → Prop
  | none => True
  | some s => 0 < s.next

theorem valid_step (s : StreamState) (hs : 0 < s.next) : Valid (ForcedCantorian.step s) := by
  rcases s with ⟨n,k,e⟩
  cases k with
  | zero =>
    rw [ForcedCantorian.fresh,ForcedCantorian.continued]
    cases one _ e <;> simp [Valid]
  | succ k =>
    rw [ForcedCantorian.continued]
    cases one _ e <;> simp [Valid] <;> exact hs

theorem halted_absorbing (ticks : Nat) : Raw.advance ticks Source.Config.halted = Source.Config.halted := by
  induction ticks with
  | zero => rfl
  | succ k ih => exact ih

/-- Every source command has positive duration on both checked outcomes. -/
def StepSimulation : Prop :=
  ∀ s : StreamState, 0 < s.next → Visits (boundary s) (embed (ForcedCantorian.step s))

theorem realize_run (oneCmd : StepSimulation) (k : Nat) (s : StreamState) (hs : 0 < s.next) :
    ∃ ticks, k ≤ ticks ∧ Raw.advance ticks (boundary s) = embed (ForcedCantorian.run k s) := by
  induction k generalizing s with
  | zero => exact ⟨0,Nat.le_refl 0,rfl⟩
  | succ k ih =>
    obtain ⟨ticks,pos,hr⟩ := oneCmd s hs
    cases he : ForcedCantorian.step s with
    | none =>
      rw [he] at hr
      refine ⟨ticks+k, by omega, ?_⟩
      rw [Raw.advance_add, hr]
      exact halted_absorbing k
        |>.trans (by simp only [ForcedCantorian.run, he, Option.bind_none]; rfl)
    | some t =>
      have ht : 0 < t.next := by
        have := valid_step _ hs
        simpa only [he, Valid] using this
      obtain ⟨tail, htail, hres⟩ := ih t ht
      refine ⟨ticks+tail, by omega, ?_⟩
      rw [Raw.advance_add, hr, he]
      simpa only [ForcedCantorian.run, he, Option.bind_some, embed] using hres

/-- The converse covers a halt at an arbitrary instruction tick. Reaching at
least that many literal ticks forces the abstract command execution to have
observed the absorbing halt too. -/
theorem source_halts_iff_stream (oneCmd : StepSimulation) (s : StreamState) (hs : 0 < s.next) :
    (∃ ticks, Raw.advance ticks (boundary s) = Source.Config.halted) ↔
    (∃ k, ForcedCantorian.run k s = none) := by
  constructor
  · rintro ⟨ticks,halt⟩
    obtain ⟨dt,hle,hr⟩ := realize_run oneCmd ticks s hs
    have large : Raw.advance dt (boundary s) = Source.Config.halted := by
      rw [show dt = ticks+(dt-ticks) by omega, Raw.advance_add, halt, halted_absorbing]
    rw [large] at hr
    refine ⟨ticks,?_⟩
    cases he : ForcedCantorian.run ticks s with
    | none => rfl
    | some out =>
      rw [he] at hr
      cases hr
  · rintro ⟨k,hk⟩
    obtain ⟨ticks,_,hr⟩ := realize_run oneCmd k s hs
    exact ⟨ticks,by simpa only [hk,embed] using hr⟩


theorem parse_forced (x : Nat) : parse (pair 0 x) = (.mp (Cantor.unpair x).1, (Cantor.unpair x).2) := by
  obtain ⟨u,v,h⟩ := show ∃ u v, x = pair u v from ⟨_,_,(Cantor.pair_unpair x).symm⟩
  subst x
  simp only [Cantor.unpair_pair]
  exact parse_assemble (.mp u) v

theorem after_as_boundary (n k : Nat) (res : Option State) :
    after n k res = embed (res.map (fun t => (⟨n,k,t⟩ : StreamState))) := by cases res <;> rfl

theorem literal_step : StepSimulation := by
  rintro ⟨next,k,s⟩ hn
  cases k with
  | zero =>
    rw [ForcedCantorian.fresh,ForcedCantorian.continued,parse_forced]
    exact (after_as_boundary _ _ _) ▸ command_fresh next s
  | succ k =>
    rw [ForcedCantorian.continued]
    exact (after_as_boundary _ _ _) ▸ command_continued next k s

theorem halts_iff_goal_pos (n : Nat) (hn : 0 < n) (s : State) (hs : s.Sound) :
    (∃ ticks, Raw.advance ticks (atFrame 0 (registers n 0 s)) = Source.Config.halted) ↔ FirstCS.Deriv goal :=
  (source_halts_iff_stream literal_step ⟨n,0,s⟩ hn).trans (ForcedCantorian.halts_iff_goal n s hs)

end ShortCS.Register
#print axioms ShortCS.Register.halts_iff_goal_pos
