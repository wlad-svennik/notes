module
public import FirstCSSearchCore
public import C196Rows
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace FirstCS
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers

def strength (c a b : Nat) := (imp (app (witness 0 (app 0 a)) c) (imp (app (app a c) (app a (witness (app a (app (app (app a (witness (app a c) (app a c))) a) a)) (app a (app (app (app a (witness (app a c) (app a c))) a) a))))) (app (app (app c b) a) (app a b))))

def strengthTokens : List Macro := [.push0, .push0, .push4, .ap, .witness, .push3, .ap, .push4, .push3, .ap, .push4, .push4, .push4, .push4, .push3, .ap, .push4, .push3, .ap, .witness, .ap, .push4, .ap, .push4, .ap, .ap, .push4, .push4, .push4, .push3, .ap, .push4, .push3, .ap, .witness, .ap, .push4, .ap, .push4, .ap, .ap, .witness, .ap, .ap, .push3, .push5, .ap, .push4, .ap, .push4, .push5, .ap, .ap, .imp, .imp]

theorem strength_effect (n t stack c a b tail : Nat) :
    strengthTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
      ⟨n,strength c a b,pair t stack,c,a,b,tail⟩ := by
  simp only [strengthTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push,
    Frame.combine, Cantor.unpair_pair, ctor, strength, imp, app, witness]
  <;> rfl

def preTokens : List Macro := C196.logicalTokens ++ tokens4 ++ Eight187.Seed.bTokens ++ tokens2 ++ tokens3 ++ tokens6 ++ Eight187.Seed.testTokens
def preCode := sequence .read5 preTokens

def frontTokens : List Macro := strengthTokens.dropLast
def bump (f : Frame) : Frame := { f with a := f.a + 1 }
def middle := Code.seq (sequence .push0 frontTokens.tail) (Code.seq (.inc 4) (sequence .imp tokens9))
def batchCode := Code.seq preCode middle

theorem increment4 (f : Frame) : Eval (.inc 4) f.regs .normal (bump f).regs := by
  cases f with | mk n t st c a b i =>
    simpa only [bump, Frame.regs, Registers.add, mk9_get_4, mk9_set_4] using
      Eval.inc 4 (mk9 n t st c a b 0 0 i)

private theorem middle_parts (first : Macro) (xs : List Macro) (ops : List Macro)
    (e : ops = first :: xs) (f : Frame) :
    Eval (.seq (sequence first xs) (.seq (.inc 4) (sequence .imp tokens9))) f.regs .normal
      (tokens9.foldl Frame.apply (bump ((ops.foldl Frame.apply f).apply .imp))).regs := by
  subst ops
  let v := xs.foldl Frame.apply (f.apply first)
  have comm (z : Frame) : (bump z).apply .imp = bump (z.apply .imp) := rfl
  have last := sequence_eval .imp tokens9 (bump v)
  rw [comm] at last
  exact Eval.seq_normal (sequence_eval first xs f)
    (Eval.seq_normal (increment4 v) last)

theorem middle_run (f : Frame) : Eval middle f.regs .normal
    (tokens9.foldl Frame.apply (bump (strengthTokens.foldl Frame.apply f))).regs := by
  have decomp : strengthTokens = frontTokens ++ [.imp] := rfl
  rw [decomp, List.foldl_append]
  exact middle_parts .push0 frontTokens.tail frontTokens rfl f

theorem batch_eval (n t st c u v y d tail : Nat) :
    Eval batchCode (Frame.regs ⟨n,t,st,c,u,v,pair y (pair d tail)⟩) .normal
       (save ⟨n,t,st,c,u+d+1,v+y,tail⟩ (FirstCS.rowList (u+d) (v+y) c u)).regs := by
  let f : Frame := ⟨n,t,st,c,u,v,pair y (pair d tail)⟩
  have h := Eval.seq_normal (sequence_eval .read5 preTokens f)
    (middle_run (preTokens.foldl Frame.apply (f.apply .read5)))
  simp only [preTokens, List.foldl_append, f, Frame.apply, Cantor.unpair_pair] at h
  rw [C196.logicalEffect, effect4, Eight187.Seed.effectB, effect2, effect3, effect6,
    Eight187.Seed.effectTest, strength_effect] at h
  simp only [bump] at h
  rw [effect9] at h
  exact h
end FirstCS
#print axioms FirstCS.batch_eval
