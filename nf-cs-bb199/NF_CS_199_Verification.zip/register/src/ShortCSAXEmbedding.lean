module
public import FirstCSSearchCore
public import ShortCSColdCore
public import FirstCSRows
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace ShortCS.Register
open FirstCS
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers
theorem ax_program_of_embedding
    (embedded : Embedded actual FirstCS.batchCode 39 4255 [] [])
    (n t stack c u v y delta tail : Nat) :
    ∃ ticks, 0 < ticks ∧
      Raw.advance ticks
        (Source.Config.active 39 (liftRegisters (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩))) =
        Source.Config.active 4255 (liftRegisters ((save ⟨n,t,stack,c,u+delta+1,v+y,tail⟩
          (FirstCS.rowList (u+delta) (v+y) c u)).regs)) := by
  obtain ⟨ticks, ht, hrun⟩ := (FirstCS.batch_eval n t stack c u v y delta tail).compiled
    actual 39 4255 [] [] embedded
  exact ⟨ticks, ht, actual_run ticks hrun⟩
end ShortCS.Register
#print axioms ShortCS.Register.ax_program_of_embedding
