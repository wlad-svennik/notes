module
public import Eight187Seed
public import SourceEnumeration
@[expose] public section
set_option maxRecDepth 4096
set_option maxHeartbeats 8000000
namespace FirstSlot
open NF192.Numerical NF192.Emitter
open NF192.ProofSearch (Command)
def lastRow (a b : Nat) := NF192.Emitter.row9 (a+1) b
def rowList (a b c u : Nat) : List Nat := [
  row0 a b c u,
  (app (app (witness b b) a) b),
  (app (app (app (app 1 c) a) b) (app (app c (witness b b)) (app a b))),
  (imp (app c b) (app (app a c) (app a b))),
  (imp (app a c) (app (app c b) (app a b))),
  (imp (app a b) (imp (app a c) (app c b))),
  (imp (imp (app 1 (app (app 0 (witness b b)) a)) (app 1 (app (app 0 (witness b b)) b))) (app a b)),
  (imp (app (witness 0 (app 0 a)) c) (imp (app (app a c) (app a (witness (app a (app (app (app a (witness (app a c) (app a c))) a) a)) (app a (app (app (app a (witness (app a c) (app a c))) a) a))))) (app (app (app c b) a) (app a b)))),
  lastRow a b]
inductive Deriv : Nat → Prop where
  | row {a b c u x : Nat} : u ≤ a → x ∈ rowList a b c u → Deriv x
  | mp {x y : Nat} : Deriv (imp x y) → Deriv x → Deriv y
theorem deriv_zero : Deriv 0 :=
  .row (a:=0) (b:=0) (c:=0) (u:=0) (by decide) (List.mem_cons_self ..)
end FirstSlot
