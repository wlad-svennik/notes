import Scope209UpperBase
namespace CantorianReadPoint
open RPRCore
universe u
variable {V : Type u} (op : V → V → V) (K : V → V) (B : V)
local infixl:70 " ⬝ " => op
variable (hk : ∀ a x : V, op (K a) x = a)
variable (hb : ∀ f g x : V, op (op (op B f) g) x = op (op f (K x)) (op g x))

/-- Constantify every row of w by reading its value at z. -/
def replacement (w z : V) : V :=
  B ⬝ K (B ⬝ B ⬝ K (K z)) ⬝ w

include hk hb
theorem replacement_apply (w z x y : V) :
    replacement op K B w z ⬝ x ⬝ y = w ⬝ x ⬝ z := by
  simp only [replacement, hb, hk]

/-- Local RPR existence is unchanged by the read chosen in the conclusion. -/
theorem changeRead (j s : V) (first second : V → V)
    (available : ∃ w, Law op K j s w first) : ∃ w, Law op K j s w second := by
  apply upperChoice
  intro ok
  obtain ⟨w,hw⟩ := available
  refine ⟨replacement op K B w (first w),fun x => ?_⟩
  rw [replacement_apply op K B hk hb]
  exact hw x (ok w)

theorem read_iff (j s : V) (first second : V → V) :
    (∃ w, Law op K j s w first) ↔ ∃ w, Law op K j s w second :=
  ⟨changeRead op K B hk hb j s first second, changeRead op K B hk hb j s second first⟩
end CantorianReadPoint
#print axioms CantorianReadPoint.read_iff
