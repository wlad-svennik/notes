import Scope209Ground
import Literal209
set_option maxHeartbeats 2000000
set_option maxRecDepth 24000
namespace Scope209.Light
open NF192.Numerical NF192.Emitter
structure Signature (X : Type) where
  q : X
  app : X → X → X
  h : X → X → X

namespace Signature

variable {X : Type} (S : Signature X)

def k (a : X) : X := S.h a a
def s : X := S.app S.q S.q
def b : X := S.app S.s S.q

end Signature

structure Chart (V : Type) where
  app : V → V → V
  K : V → V
  B : V
  J : V
  const : ∀ a b, app (K a) b = a
  combine : ∀ a b c, app (app (app B a) b) c = app (app a (K c)) (app b c)
  ext : ∀ {a b}, (∀ x, app a x = app b x) → a=b
  letter : app J J = B
  proper : B ≠ J
  off : ∀ x y, x ≠ y → app (app J (K x)) y = B
  on : ∀ x, app (app J (K x)) x ≠ B

structure Rows {X : Type} (S : Signature X) (r : X → X → Prop) : Prop where
  argCongr : ∀ a b c, r c b → r (S.app a c) (S.app a b)
  kLaw : ∀ a b, r (S.app (S.k b) a) b
  funCongr : ∀ a b c, r a c → r (S.app c b) (S.app a b)
  bLaw : ∀ a b c, r (S.app (S.app (S.app (S.s) c) a) b)
    (S.app (S.app c (S.k b)) (S.app a b))
  euclid : ∀ a b c, r a b → r a c → r c b
  test : ∀ x y, (r (S.app (S.app S.q (S.k x)) y) S.s → r (S.app (S.app S.q (S.k x)) x) S.s) → r x y
  ext : ∀ a b, r (S.app b (S.h a b)) (S.app a (S.h a b)) → r a b
namespace Rows
variable {X : Type} {S : Signature X} {r : X → X → Prop} (R : Rows S r)
include R
theorem rel_refl (a : X) : r a a :=
  R.euclid _ a a (R.kLaw S.q a) (R.kLaw S.q a)

theorem rel_symm {a b : X} (h : r a b) : r b a :=
  R.euclid a a b (R.rel_refl a) h

theorem rel_trans {a b c : X} (hab : r a b) (hbc : r b c) : r a c :=
  R.euclid b c a hbc (R.rel_symm hab)

theorem app_congr {a b c d : X} (hac : r a c) (hbd : r b d) :
    r (S.app a b) (S.app c d) :=
  R.rel_trans (R.rel_symm (R.funCongr a b c hac)) (R.argCongr c d b hbd)

theorem k_congr {a b : X} (hab : r a b) : r (S.k a) (S.k b) := by
  let d := S.h (S.k a) (S.k b)
  have h : r (S.app (S.k a) d) (S.app (S.k b) d) :=
    R.rel_trans (R.rel_trans (R.kLaw d a) hab) (R.rel_symm (R.kLaw d b))
  exact R.ext (S.k a) (S.k b) (R.rel_symm h)

def setoid : Setoid X where
  r := r
  iseqv := ⟨R.rel_refl, R.rel_symm, R.rel_trans⟩

def Carrier : Type := Quotient R.setoid

def obj (a : X) : R.Carrier := Quotient.mk R.setoid a

theorem obj_eq_iff {a b : X} : R.obj a = R.obj b ↔ r a b :=
  ⟨fun h => Quotient.exact h, fun h => Quotient.sound (s := R.setoid) h⟩

def appObj (a b : R.Carrier) : R.Carrier :=
  Quotient.liftOn₂ a b (fun x y => R.obj (S.app x y))
    (fun _ _ _ _ hx hy => Quotient.sound (s := R.setoid) (R.app_congr hx hy))

def kObj (a : R.Carrier) : R.Carrier :=
  Quotient.liftOn a (fun x => R.obj (S.k x))
    (fun _ _ h => Quotient.sound (s := R.setoid) (R.k_congr h))

theorem app_obj (a b : X) : R.appObj (R.obj a) (R.obj b) = R.obj (S.app a b) := rfl

theorem k_obj (a : X) : R.kObj (R.obj a) = R.obj (S.k a) := rfl

theorem kObj_app (a b : R.Carrier) : R.appObj (R.kObj a) b = a := by
  refine Quotient.inductionOn₂ a b ?_
  intro x y
  exact R.obj_eq_iff.mpr (R.kLaw y x)

theorem bObj_app (x y z : R.Carrier) :
    R.appObj (R.appObj (R.appObj (R.obj (S.s)) x) y) z =
    R.appObj (R.appObj x (R.kObj z)) (R.appObj y z) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn z ?_
  intro c
  exact R.obj_eq_iff.mpr (R.bLaw b c a)

theorem appObj_ext {a b : R.Carrier} (h : ∀ x, R.appObj a x = R.appObj b x) :
    a = b := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  exact R.obj_eq_iff.mpr
    (R.ext x y (R.rel_symm (R.obj_eq_iff.mp (h (R.obj (S.h x y))))))

theorem testObj (x y : R.Carrier) :
    (R.appObj (R.appObj (R.obj S.q) (R.kObj x)) y = R.obj S.s →
     R.appObj (R.appObj (R.obj S.q) (R.kObj x)) x = R.obj S.s) → x=y := by
  revert y
  refine Quotient.inductionOn x ?_
  intro a y
  refine Quotient.inductionOn y ?_
  intro b h
  apply R.obj_eq_iff.mpr
  apply R.test
  intro e
  exact R.obj_eq_iff.mp (h (R.obj_eq_iff.mpr e))

def toChart (h : ¬r S.s S.q) : Chart R.Carrier := by
  let J := R.obj S.q
  let B := R.obj S.s
  let test := fun x y => R.appObj (R.appObj J (R.kObj x)) y
  have ne : B ≠ J := fun e => h (R.obj_eq_iff.mp e)
  have beh (x y : R.Carrier) (diff : x ≠ y) : test x y = B ∧ test x x ≠ B := by
    constructor
    · exact Classical.byContradiction (fun bad => diff (R.testObj x y (fun e => False.elim (bad e))))
    · intro on
      exact diff (R.testObj x y (fun _ => on))
  refine ⟨R.appObj, R.kObj, B, J, R.kObj_app, R.bObj_app, (fun h => R.appObj_ext h), rfl, ne,
    (fun x y diff => (beh x y diff).1), ?_⟩
  intro x
  by_cases e : x = B
  · exact (beh x J (fun h => ne (e.symm.trans h))).2
  · exact (beh x B e).2
end Rows
private theorem atRow {r} (hr : RowsHold r) (a b c : Nat) (i : Fin 9) :
    evaluate r ((rowList a b c 0)[i.val]'(by
      simpa only [rowList,List.length_cons,List.length_nil] using i.isLt)) :=
  hr a b c 0 (Nat.zero_le _) _ (List.getElem_mem ..)

private abbrev padded (a : Nat) := app (witness a a) 0
private def slot (a b : Nat) :=
  if a=b then witness a b else if a=0 then witness (padded a) b else witness a b
private abbrev sig : Signature Nat := ⟨0,app,slot⟩
private theorem diag (a : Nat) : sig.k a = witness a a := by
  simp [Signature.k,slot]

private theorem rows_of_scoped {r} (hr : RowsHold r) : Rows sig r := by
  have k (a b : Nat) : r (app (witness b b) a) b := (evaluate_eqn r (app (witness b b) a) b).mp (atRow hr a b 0 1)
  have eu (a b c : Nat) : r a b → r a c → r c b := by
    have v := atRow hr a b c 2
    change evaluate r (imp (eqn a b) (imp (eqn a c) (eqn c b))) at v
    simpa only [evaluate_imp, evaluate_eqn] using v
  have refl (a : Nat) : r a a := eu _ _ _ (k 0 a) (k 0 a)
  have sym {a b : Nat} (v : r a b) : r b a := eu _ _ _ (refl a) v
  have tr {a b c : Nat} (v : r a b) (w : r b c) : r a c := eu _ _ _ w (sym v)
  have fc (a b c : Nat) : r a c → r (app c b) (app a b) := by
    have v := atRow hr a b c 6
    change evaluate r (imp (eqn a c) (eqn (app c b) (app a b))) at v
    simpa only [evaluate_imp,evaluate_eqn] using v
  have ext (a b : Nat) :
      r (app b (witness (a+1) b)) (app (a+1) (witness (a+1) b)) → r (a+1) b := by
    have v := atRow hr a b 0 8
    change evaluate r (row9 (a+1) b) at v
    simpa only [row9,evaluate_imp,evaluate_eqn] using v
  constructor
  · intro a b c
    have v := atRow hr a b c 5
    change evaluate r (imp (eqn c b) (eqn (app a c) (app a b))) at v
    simpa only [evaluate_imp,evaluate_eqn] using v
  · intro a b
    rw [diag]
    exact k _ _
  · exact fc
  · intro a b c
    rw [diag]
    exact (evaluate_eqn r (app (app (app 1 c) a) b) (app (app c (witness b b)) (app a b))).mp (atRow hr a b c 4)
  · exact eu
  · intro x y premise
    have v := atRow hr y x 0 3
    let t := fun i j => app (app 0 (witness i i)) j
    change evaluate r (imp (imp (eqn 1 (t x y)) (eqn 1 (t x x))) (eqn y x)) at v
    simp only [evaluate_imp,evaluate_eqn] at v
    simp only [diag] at premise
    exact sym (v (fun e => sym (premise (sym e))))
  · intro a b given
    by_cases same : a=b
    · subst b
      exact refl a
    · change r (app b (slot a b)) (app a (slot a b)) at given
      cases a with
      | succ j =>
        apply ext j b
        simpa [slot,same] using given
      | zero =>
        have pad : r (padded 0) 0 := k 0 0
        simp [slot,same] at given
        have atPad : r (app b (witness (padded 0) b)) (app (padded 0) (witness (padded 0) b)) :=
          tr given (fc _ _ _ pad)
        have lex : ∃ j, padded 0 = j+1 := by exact ⟨_,rfl⟩
        obtain ⟨j,hj⟩ := lex
        rw [hj] at atPad pad
        exact tr (sym pad) (ext j b atPad)

theorem chart_of_nonderiv (hn : ¬Deriv goal) :
    ∃ M : Type, ∃ A : Chart M,
      ∀ u, ∃ w, ∀ x,
        let r := fun t => A.app u (A.K t)
        let p := fun t => A.app u (A.app (A.app t u) u)
        r (p (r (A.app u w))) = A.app u w → A.app (A.app w x) w = A.app u x := by
  obtain ⟨rel, hr, hg⟩ := not_deriv_iff_ground_model.mp hn
  let rows := rows_of_scoped hr
  refine ⟨rows.Carrier,rows.toChart hg,?_⟩
  have all : ∀ v : rows.Carrier, ∃ a, rows.obj a = v := Quotient.exists_rep
  have pos (v : rows.Carrier) : ∃ d, rows.obj (d+1) = v := by
    obtain ⟨a,rfl⟩ := all v
    have pad : rel (padded a) a := by
      have o := rows.kLaw 0 a
      simpa only [diag] using o
    exact ⟨_,rows.obj_eq_iff.mpr pad⟩
  change ∀ u, ∃ w, ∀ x,
    let r := fun t => rows.appObj u (rows.kObj t)
    let p := fun t => rows.appObj u (rows.appObj (rows.appObj t u) u)
    r (p (r (rows.appObj u w))) = rows.appObj u w → rows.appObj (rows.appObj w x) w = rows.appObj u x
  apply Literal209.extract rows.obj rows.appObj rows.kObj all pos
  · intro a b
    rfl
  · intro a
    change rows.obj (witness a a) = rows.obj (sig.k a)
    rw [diag]
  · intro c d x
    dsimp only
    have v := atRow hr d x c 7
    change evaluate rel (imp (eqn (witness 0 (d+1)) c)
      (imp (eqn (app (d+1) c) (Literal209.rpr (d+1) (app (d+1) c)))
        (eqn (app (app c x) c) (app (d+1) x)))) at v
    simp only [evaluate_imp,evaluate_eqn] at v
    intro hc hp
    exact rows.obj_eq_iff.mpr (v (rows.obj_eq_iff.mp hc) (rows.obj_eq_iff.mp hp))

end Scope209.Light
#print axioms Scope209.Light.chart_of_nonderiv
