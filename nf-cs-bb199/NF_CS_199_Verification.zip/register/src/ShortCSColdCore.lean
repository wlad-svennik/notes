module
public import FirstCSSearchCore
public import ShortCSOuter
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace ShortCS.Register
open FirstCS
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers
def usesCounter : Instruction → Bool
  | .inc r _ | .dec r _ _ | .decHalt r _ => r.val == 0
  | _ => false

def frozen (pc : Nat) : Instruction :=
  if usesCounter (actual pc) then .halt else actual pc

theorem frozen_placement {code : Code} {pc last : Nat}
    (he : Embedded actual code pc last [] [])
    (hfree : (compile code pc last [] []).all (fun op => !(usesCounter op)) = true) :
    Embedded frozen code pc last [] [] := by
  intro i hi
  have hidx : i < (compile code pc last [] []).length := by simpa only [compile_length] using hi
  have hm := List.getElem_mem hidx
  have h := (List.all_eq_true.mp hfree) _ hm
  have hv : usesCounter (actual (pc+i)) = false := by simpa [he i hi] using h
  rw [frozen, if_neg (by simp [hv])]
  exact he i hi

/-- Warm is the ordinary source semantics. Cold indicates the single exceptional
value of register 0. A decrement of that negative value is outside the interface. -/
def bootstrapStep (s : Bool × Source.Config) : Bool × Source.Config :=
  if s.1 then
    match s.2 with
    | none => (true,none)
    | some (pc,rs) =>
      if usesCounter (actual pc) then
        match Raw.program pc with
        | .inl (_,next) => (false,Source.Config.active next (Source.setReg rs 0 0))
        | _ => (true,none)
      else (true,Raw.step s.2)
  else (false,Raw.step s.2)

def bootstrapAdvance : Nat → (Bool × Source.Config) → Bool × Source.Config
  | 0,s => s
  | n+1,s => bootstrapAdvance n (bootstrapStep s)

theorem bootstrapAdvance_add (a b : Nat) (s : Bool × Source.Config) :
    bootstrapAdvance (a+b) s = bootstrapAdvance b (bootstrapAdvance a s) := by
  induction a generalizing s with
  | zero => simp [bootstrapAdvance]
  | succ a ih => simp only [Nat.succ_add, bootstrapAdvance, ih]

theorem frozen_step {s t : Config} (h : NF192.Emitter.step frozen s = some t) :
    bootstrapStep (true,liftConfig s) = (true,liftConfig t) := by
  have ok : usesCounter (actual s.pc) = false := by
    cases ht : usesCounter (actual s.pc) with
    | false => rfl
    | true => simp [NF192.Emitter.step, frozen, ht] at h
  have ha : NF192.Emitter.step actual s = some t := by simpa only [NF192.Emitter.step, frozen, ok, Bool.false_eq_true, if_false] using h
  have he := actual_step ha
  simpa only [bootstrapStep, liftConfig, Source.Config.active, ok, Bool.false_eq_true, if_false,
    Bool.true_eq, if_true] using congrArg (fun x => (true, x)) he

theorem frozen_run (n : Nat) {s t : Config} (h : NF192.Emitter.run frozen n s = some t) :
    bootstrapAdvance n (true,liftConfig s) = (true,liftConfig t) := by
  induction n generalizing s with
  | zero => exact congrArg (fun x => (true,liftConfig x)) (Option.some.inj h)
  | succ n ih =>
      cases hs : NF192.Emitter.step frozen s with
      | none => simp [NF192.Emitter.run, hs] at h
      | some u =>
          have rest : NF192.Emitter.run frozen n u = some t := by simpa only [NF192.Emitter.run, hs, Option.bind_some] using h
          exact (congrArg (bootstrapAdvance n) (frozen_step hs)).trans (ih rest)


end ShortCS.Register
