import ShortCSTransfer
import FirstSlotExact
namespace ShortCSRegisterBridge
open NF192 NF192.Numerical
open ShortCS.Register
def emptyProof : FirstCS.State := ⟨0,[],0,0⟩
theorem empty_sound : emptyProof.Sound :=
  ⟨FirstCS.deriv_zero, by simp [emptyProof], FirstCS.deriv_zero⟩
def warmOrigin := atFrame 0 ⟨3,0,0,0,0,0,0⟩
theorem source_halts_iff_original :
    (∃ n, ShortCS.Raw.advance n warmOrigin = Source.Config.halted) ↔ Scope209.Deriv goal := by
  exact (halts_iff_goal_pos 3 (by decide) emptyProof empty_sound).trans FirstCalibration.goal_iff_original
end ShortCSRegisterBridge
#print axioms ShortCSRegisterBridge.source_halts_iff_original
