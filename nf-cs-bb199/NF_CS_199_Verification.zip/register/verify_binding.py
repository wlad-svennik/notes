"""Bind the signed source file to every Lean register instruction, independently of address relabelling."""
from pathlib import Path
from hashlib import sha256
import json
import re
import sys
here = Path(__file__).resolve().parent
def physical(sites):
 starts={};exits={}; N=len(sites)
 for i,(a,*_) in enumerate(sites):
  for j in range(len(a)+1):
   k=a[:j];starts.setdefault(k,i);exits[k]=(i+1)%N
 result=[]
 for i,(a,op,n) in enumerate(sites):
  nxt=(i+1)%N
  if op=='CI':v=('inc',n,nxt)
  elif op=='CD' and a.endswith('1'):v=('decHalt',n,nxt)
  else:
   side='1' if op=='CC' else '0';j=len(a)
   for _ in range(1 if op=='CD' else n):j=a.rindex(side,0,j)
   t=(starts if op=='CC' else exits)[a[:j]]
   v=('dec',n,t,nxt) if op=='CD' else ('jump',t)
  result.append(v)
 return result
def savedcmd(cmd):return '.'+' '.join(map(str,cmd))

def main():
 p = Path(sys.argv[1]) if len(sys.argv)>1 else here/'source.sites.json'
 raw=p.read_bytes()
 if len(sys.argv)==1:
  assert sha256(raw).hexdigest()=='7dadff2a8e765846abc8e008b6082b8ffedd3cf3e3782bfc2b8037339c26b757'
 program=json.loads(raw)
 paths=[addr for addr,*_ in program]
 assert len(set(paths))==len(paths)==4377 and paths==sorted(paths)
 assert all(set(x)<=set('01') and x and not (b.startswith(x)) for x,b in zip(paths, paths[1:]))
 depth=max(map(len,paths))
 assert sum(2**(depth-len(x)) for x in paths)==2**depth
 cfg=list(map(savedcmd,physical(program)))
 lean=(here/'src/ShortCSProgram.lean').read_text()
 blocks=re.findall(r'^def (pre\d+|mid\d+|post\d+) : List Instruction := \[(.*?)\]$',lean,re.M|re.S)
 allops=[]
 for name in ('pre','mid','post'):
  blockref=re.search(r'^def '+name+r' : List Instruction := \[(.*?)\]\.flatten$',lean,re.M).group(1).split(', ')
  selected=[(n,v) for n,v in blocks if n.startswith(name)]
  if blockref!=[n for n,_ in selected]:raise ValueError('Literal block order changed')
  for _,txt in selected:
   allops.extend(re.findall(r'\.(?:inc|decHalt|dec|jump) \d+(?: \d+){0,2}',txt))
 assert cfg==allops and cfg[3]=='.inc 7 4' and cfg[3838]=='.inc 4 3839'
 assert 'if pc < 39 then pre.getD pc .halt else if pc < 4255 then mid.getD (pc-39) .halt else post.getD (pc-4255) (.jump pc)' in lean
 print(f'All {len(cfg)} register instructions bound to signed source SHA-256 {sha256(raw).hexdigest()}.')
if __name__=='__main__':
 if not __debug__:raise SystemExit('Run without Python optimization.')
 main()
