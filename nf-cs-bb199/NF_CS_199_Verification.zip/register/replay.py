from pathlib import Path
import json, os, re, sys, subprocess, shutil, concurrent.futures
here=Path(__file__).resolve().parent
source=here/'src'

build=here/'build'
build.mkdir(exist_ok=True)
lean=os.getenv('LEAN','lean')
if '4.35.0' not in subprocess.check_output([lean,'--version'],text=True):raise ValueError('Expected Lean 4.35.0')
env=dict(os.environ,LEAN_PATH=str(build))
deps={}
def add(m):
 if m in ('Init','Std') or m in deps:return
 p=source/(m.replace('.','/')+'.lean')
 if not p.exists():raise ValueError('Missing dependency: '+m)
 sub=re.findall(r'^\s*(?:public )?import (?:all )?([\w.]+)',p.read_text(),re.M)
 deps[m]=sub
 for n in sub:add(n)
for item in sys.argv[1:] or ['ShortCSRegisterBridge']:add(item)
def compile(m):
 f=Path(m.replace('.','/'))
 dest=build/f.with_suffix('.olean')
 dest.parent.mkdir(parents=True,exist_ok=True)
 src=source/f.with_suffix('.lean')
 if dest.exists() and dest.stat().st_mtime >= max([src.stat().st_mtime]+[(build/Path(n.replace('.','/')).with_suffix('.olean')).stat().st_mtime for n in deps[m] if n in deps]):return True
 with (build/(m+'.log')).open('w')as log:
  r=subprocess.run([lean,'-j','1','-s','131072','-o',dest,str(f.with_suffix('.lean'))],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(m,r.returncode,flush=True)
 logtext=(build/(m+'.log')).read_text()
 return not r.returncode and "sorryAx" not in logtext and "uses 'sorry'" not in logtext
with concurrent.futures.ThreadPoolExecutor(int(os.getenv("JOBS","3"))) as pool:
 done={'Init','Std'}; running={};todo=set(deps);failed=set()
 while todo or running:
  for m in sorted(todo):
   if set(deps[m])&failed:failed.add(m);todo.remove(m);continue
   if len(running)<int(os.getenv("JOBS","3")) and set(deps[m])<=done:running[pool.submit(compile,m)]=m;todo.remove(m)
  if not running:
   if todo:continue
   break
  fs,_=concurrent.futures.wait(running,return_when=concurrent.futures.FIRST_COMPLETED)
  for f in fs:
   m=running.pop(f)
   if f.result():done.add(m)
   else:failed.add(m)
 if failed:raise SystemExit('failed: '+repr(sorted(failed)))
