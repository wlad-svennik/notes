"""Validate the printed two-symbol table, complete startup, register source, and physical receipts."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import argparse,gzip,json,os,shutil,subprocess,sys,tempfile

BASE=Path(__file__).resolve().parent

def run(*args, **kw):
    return subprocess.run(list(map(str,args)),check=True,**kw)

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--examples',action='store_true',help='Check complete successor tapes against register operations in C++')
    parser.add_argument('--kernel',action='store_true',help='Regenerate symbolic certificates and recheck all branches in Lean')
    parser.add_argument('--blank-lean',action='store_true',help='Replay blank-tape proof in Lean')
    parser.add_argument('--register-lean',action='store_true',help='Rebuild the source-to-calculus theorems')
    parser.add_argument('--jobs',type=int,default=2)
    a=parser.parse_args()
    if not __debug__ or a.jobs<1:
        raise SystemExit('Use normal Python and a positive job count')
    for line in (BASE/'SHA256SUMS').read_text().splitlines():
        expected,name=line.split('  ',1)
        assert digest(BASE/name)==expected,name
    meta=json.loads((BASE/'machine.json').read_bytes())
    table=BASE/meta['file']
    source=BASE/'source.sites.json'
    assert digest(table)==meta['table_sha256'] and digest(source)==meta['source_sha256']
    start,*rows=table.read_text().splitlines()
    assert start=='#! start k:64'
    literal={}
    for line in rows:
        q,r,w,d,z=line.split()
        key=(q,int(r))
        assert key not in literal and r in ('0','1') and w in ('0','1') and d in ('L','R')
        literal[key]=(int(w),d,z)
    live=set()
    todo=['k:64']
    while todo:
        q=todo.pop()
        if q=='halt' or q in live: continue
        live.add(q)
        todo.extend(literal[q,b][2] for b in (0,1))
    assert len(live)==meta['states'] and len(literal)==2*len(live)
    assert [(q,b) for (q,b),(_,_,z) in literal.items() if z=='halt']==[('k:302',1)]
    with ZipFile(BASE/'upstream/Cantorian_204_and_203.zip') as z:
        prefix='Cantorian_204_and_203/first-coordinate-204/'
        old_source=json.loads(z.read(prefix+'source.sites.json'))
        sites=json.loads(source.read_bytes())
        profile=meta['source_profile']
        if profile=='short':
            def rotate(p):
                return next(new+p[2:] for old,new in [('00','0'),('01','10'),('10','110'),('11','111')] if p.startswith(old))
            assert sites[:9]==[['0000','CD',8],['0001','CB',1],['00100','CD',0],['001010','CI',7],['0010110','CI',6],['0010111','CC',3],['00110','CI',0],['001110','CD',6],['001111','CC',2]]
            assert sites[9:]==[[rotate(p),op,r] for p,op,r in old_source[10:]]
        else:
            assert len(sites)==len(old_source)
            source_edits=[[i,old,new] for i,(old,new) in enumerate(zip(old_source,sites)) if old!=new]
            assert source_edits==([] if profile=='original' else [[4,['00011010','CI',8],['00011010','CI',7]]])
        old=z.read(prefix+'candidate.tm').decode().splitlines()[1:]
    oldrows={tuple(s[:2]):tuple(s[2:]) for s in map(str.split,old)}
    patch=json.loads((BASE/'edits.json').read_bytes())
    for q,b,v in patch:
        if v is None:del oldrows[q,str(b)]
        else:oldrows[q,str(b)]=tuple(v)
    rebuilt='#! start k:64\n'+''.join(' '.join(k+v)+'\n' for k,v in sorted(oldrows.items()))
    assert rebuilt.encode()==table.read_bytes()
    run(sys.executable,BASE/'register/verify_binding.py',source)
    assert (BASE/'register/source.sites.json').read_bytes()==source.read_bytes()
    if profile=='short':
        with ZipFile(BASE/'calibration/NFCS_Calibration.zip') as calibration:
            assert calibration.testzip() is None
            assert digest(BASE/'calibration/NFCS_Calibration.zip')=='8811d94f42b08a015e34b63a4d7fe619483fabfc6158abd18a9a6ae1d973ec3d'
            assert (BASE/'Calibration.md').read_bytes()==calibration.read('README.md')
            for module,expected_hash in json.loads(calibration.read('source-sha256.json')).items():
                name='src/'+module.replace('.','/')+'.lean'
                assert sha256(calibration.read(name)).hexdigest()==expected_hash,name
            formula=calibration.read('receipts/NFCSFormula.log').decode().splitlines()
            endpoints={'NFCS.Pure.Formula.models_iff_CS','NFCS.Pure.Formula.source_nonhalting_of_consistent','NFCS.Pure.Formula.inconsistent_of_source_halts'}
            assert set(formula)=={f"'{endpoint}' depends on axioms: [propext, choice, Quot.sound]" for endpoint in endpoints}
            assert calibration.read('src/ShortCSRegisterBridge.lean')==(BASE/'register/src/ShortCSRegisterBridge.lean').read_bytes()
            assert b'NFCS.Machine201.a0_of_source_nonhalting' in calibration.read('receipts/RPR201.log')
            upper=calibration.read('receipts/PureCSUpperEnd.log')
            assert b'NFCS.Pure.source201_nonhalting_of_model' in upper and b'sorryAx' not in upper and b'error' not in upper
    assert 'NFCS.Simulation.blank_halts_iff_source' in (BASE/'composition/Simulation.log').read_text()
    if meta['states']==199:
        comp=BASE/'composition'
        run(sys.executable,comp/'verify_last_state.py',comp/'NF_CS_200.tm',table)
    phy=BASE/'physical'
    receipts=BASE/'receipts'
    trace=receipts/'traces.gz'
    cert=json.loads(gzip.decompress(trace.read_bytes()))
    kernel=json.loads((receipts/'kernel.json').read_bytes())
    assert kernel['table']==cert['table']==digest(table)
    assert kernel['source']==cert['source']==digest(source) and kernel['trace_sha256']==digest(trace)
    sites=json.loads(source.read_bytes())
    expected={(i,c,z) for i,(_,op,r) in enumerate(sites) for c in (False,True)
              if not(c and op=='CD' and r==0) for z in ((False,True) if op=='CD' else (False,))}
    seen={(t['pc'],t['cold'],t['zero']) for t in cert['traces']}
    assert seen==expected and len(seen)==len(cert['traces'])==kernel['branch_theorems']==(11470 if profile=='short' else 11472)
    assert len(cert['pumps'])==20 and all(min(t['clock'])>=0 and t['clock'][0]>0 for t in cert['traces'])
    pos=0
    for chunk in kernel['intervals']:
        hi=chunk['past_last_pc']
        assert chunk['first_pc']==pos<hi and 'accepts the solution' in chunk['kernel']
        assert sum(pos<=i<hi for i,_,_ in expected)==chunk['branches']
        pos=hi
    assert pos==len(sites)==(4377 if profile=='short' else 4378)
    with tempfile.TemporaryDirectory() as tmp:
        work=Path(tmp)
        machine=work/'machine';machine.mkdir()
        shutil.copyfile(table,machine/'candidate.tm');shutil.copyfile(source,machine/source.name)
        boot=json.loads((receipts/'bootstrap.json').read_bytes())
        fresh=work/'bootstrap.json'
        run(sys.executable,BASE/'boot/discover.py',table,'--source',source,'--out',fresh)
        assert json.loads(fresh.read_bytes())==boot
        if profile=='short':
            f=boot['final']['frame']
            assert f['ordinal']==0 and f['registers']==[meta['counter']]+[0]*8
        else:
            f=boot['cold_anchor']['frame']
            assert f['ordinal']==40 and f['registers']==[-1,0,0,2,0,0,0,0,0]
        f=boot['final']['frame']
        assert f['gap']>=cert['base_gap'] and len(f['spares'])>=24 and not any(f['spares'])
        if a.examples:
            run(sys.executable,phy/'prepare.py',machine)
            exe=work/'examples'
            run(os.getenv('CXX','c++'),'-std=c++17','-O3',phy/'replay_examples.cpp','-o',exe)
            rep=run(exe,machine/'source.txt',machine/'table.txt',capture_output=True,text=True).stdout.strip()
            assert rep==meta['examples'],rep
            print(rep)
        if a.kernel:
            fresh=work/'fresh.gz'
            run(sys.executable,phy/'symbolic_frames.py',machine,'--write',fresh)
            assert gzip.decompress(fresh.read_bytes())==gzip.decompress(trace.read_bytes())
            run(sys.executable,phy/'check_all.py',machine,fresh,work/'kernel.json','--jobs',a.jobs)
        if a.blank_lean:
            dest=work/'boot'
            shutil.copytree(BASE/'boot',dest)
            run(sys.executable,dest/'generate.py',table,dest)
            for f in (BASE/'boot').glob('*.lean'):
                assert f.read_bytes()==(dest/f.name).read_bytes(),f.name
            run('bash',dest/'compile.sh',env=dict(os.environ,JOBS=str(a.jobs)))
        if a.register_lean:
            dest=work/'register'
            shutil.copytree(BASE/'register',dest)
            run(sys.executable,dest/'replay.py')
            run('lean',BASE/'composition/Simulation.lean',cwd=work)
            if meta['states']==199:
                run('lean',BASE/'composition/LastState.lean',cwd=work)
    print(f"{len(live)} reachable working states, {len(literal)} rows, {len(sites)} source instructions, {len(seen)} signed cases.")
if __name__=='__main__':main()
