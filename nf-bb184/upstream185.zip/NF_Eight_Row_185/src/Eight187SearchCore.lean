module
public import Eight187Seed
public import SourceEnumeration
@[expose] public section
set_option maxRecDepth 4096
set_option maxHeartbeats 8000000
namespace Eight187
open NF192.Numerical NF192.Emitter
open NF192.ProofSearch (Command)
abbrev lastRow := NF192.Emitter.row9
abbrev rowList := Eight187.Seed.eight
inductive Deriv : Nat → Prop where
  | row {a b c u x : Nat} : u ≤ a → x ∈ rowList a b c u → Deriv x
  | mp {x y : Nat} : Deriv (imp x y) → Deriv x → Deriv y
theorem last_row_split (a b c u : Nat) :
    rowList a b c u = (rowList a b c u).take 7 ++ [lastRow a b] := rfl
theorem deriv_zero : Deriv 0 :=
  .row (a:=0) (b:=0) (c:=0) (u:=0) (by decide) (List.mem_cons_self ..)
structure State where
  top : Nat
  stack : List Nat
  cache : Nat
  param : Nat
def tailRows (a b : Nat) : List (Nat × Nat) → List Nat
  | [] => []
  | (y,d) :: rs => rowList (a+d) (b+y) rs.length a ++ tailRows (a+d) (b+y) rs
def rows (u b δ : Nat) (rest : List (Nat × Nat)) (s : State) : List Nat :=
  let a := s.param+u+δ
  let v := s.cache+b
  rowList a v rest.length (s.param+u) ++ tailRows a v rest
def nip (s : State) : State := ⟨s.top,s.stack.tail,s.stack.headD 0,0⟩
def afterAX (s : State) (zs : List Nat) : State :=
  nip ⟨0,zs.reverse.tail ++ s.top :: s.stack,0,0⟩
def step (cmd : Command) (s : State) : State :=
  match cmd with
  | .mode d =>
    let b := s.param+d
    nip ⟨if s.cache = imp s.top b then b else 0,s.stack,0,0⟩
  | .mp d =>
    match s.param+d with
    | 0 => ⟨s.top,s.stack.tail,s.stack.headD 0,0⟩
    | w+1 => ⟨s.cache,s.stack,s.top,w⟩
  | .ax u b δ rest => afterAX s (rows u b δ rest s)
def observes (cmd : Command) (s : State) : Bool :=
  match cmd with
  | .mp _ => s.cache == goal
  | _ => false
def State.Sound (s : State) : Prop :=
  Deriv s.top ∧ (∀ x ∈ s.stack, Deriv x) ∧ Deriv s.cache
theorem imp_last_ne_cache (a b : Nat) : b ≠ imp (lastRow a b) a := by
  have h1 := pair_ge_right a b
  have h2 := imp_ge_right (eqn (app b (witness a b)) (app a (witness a b))) (eqn a b)
  have h3 := imp_ge_left (lastRow a b) a
  change b ≠ imp (lastRow a b) a
  change _ ≤ lastRow a b at h2
  unfold eqn at h2
  omega
theorem tailRows_sound (a b : Nat) (rest : List (Nat × Nat)) : ∀ x ∈ tailRows a b rest, Deriv x := by
  induction rest generalizing a b with
  | nil => simp [tailRows]
  | cons t rest ih =>
    obtain ⟨y,d⟩ := t
    intro x hx
    rcases List.mem_append.mp hx with h|h
    · exact .row (Nat.le_add_right _ _) h
    · exact ih _ _ _ h
theorem rows_sound (u b d : Nat) (rest : List (Nat × Nat)) (s : State) :
    ∀ x ∈ rows u b d rest s, Deriv x := by
  intro x hx
  rcases List.mem_append.mp hx with h|h
  · exact .row (Nat.le_add_right _ _) h
  · exact tailRows_sound _ _ _ _ h
end Eight187
