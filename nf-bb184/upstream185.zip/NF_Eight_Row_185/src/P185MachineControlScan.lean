module
public import NF210.MachineSemantics

@[expose] public section

/-! Unbounded cleanup of a branch instruction. The literal countdown table
fixes these seven state numbers. The nine transitions below suffice on every
two-sided tape, for every header position and every gap length. -/

namespace P185.Control

open NF210.TM

set_option autoImplicit false
set_option maxHeartbeats 0

abbrev State := Fin 185
abbrev Config := Configuration 185

def cfg (q : State) (h : Int) (t : Tape) : Config := ⟨some q, h, t⟩

/-- The active state sequence in the selected table is k:6, k:10,
k16share:0, k16share:1, d:137, d:138/d:139, k:2. -/
structure ScannerRows (M : Machine 185) : Prop where
  seekZero : M 149 false = ⟨false, .right, some 149⟩
  seekOne : M 149 true = ⟨false, .right, some 126⟩
  header : M 126 false = ⟨false, .left, some 123⟩
  restore : M 123 false = ⟨true, .left, some 124⟩
  retreat : M 124 false = ⟨true, .left, some 32⟩
  pivotZero : M 32 false = ⟨false, .right, some 33⟩
  pivotOne : M 32 true = ⟨true, .right, some 34⟩
  eraseZero : M 33 true = ⟨false, .left, some 124⟩
  eraseOne : M 34 true = ⟨false, .left, some 130⟩

variable {M : Machine 185}

private theorem write_same {t : Tape} {h : Int} {b : Bool} (read : t h = b) :
    writeTape t h b = t := by
  funext p
  by_cases eq : p = h
  · subst p
    exact (writeTape_at _ _ _).trans read.symm
  · exact writeTape_away _ _ _ _ eq

private theorem write_restore {t : Tape} {h : Int} {b : Bool} (w : Bool)
    (read : t h = b) : writeTape (writeTape t h w) h b = t := by
  funext p
  by_cases eq : p = h
  · subst p
    exact (writeTape_at _ _ _).trans read.symm
  · exact (writeTape_away _ _ _ _ eq).trans (writeTape_away _ _ _ _ eq)

private theorem one {q v : State} {p : Int} {t : Tape} {r w : Bool} {dir : Direction}
    (cell : t p = r) (row : M q r = ⟨w, dir, some v⟩) :
    step M (cfg q p t) = cfg v (moveHead dir p) (writeTape t p w) := by
  simp only [step, cfg, cell, row]

private theorem identity_step {q v : State} {p : Int} {t : Tape} {r : Bool} {dir : Direction}
    (cell : t p = r) (row : M q r = ⟨r, dir, some v⟩) :
    step M (cfg q p t) = cfg v (moveHead dir p) t := by
  rw [one cell row, write_same cell]

private theorem three {a b c d : Config}
    (h₁ : step M a = b) (h₂ : step M b = c) (h₃ : step M c = d) :
    run M 3 a = d := by
  change step M (step M (step M a)) = d
  rw [h₁, h₂, h₃]

namespace ScannerRows

variable (R : ScannerRows M)
include R

theorem seek_zeros (t : Tape) (first : Int) (n : Nat)
    (gap : ∀ i : Nat, i < n → t (first + (i : Int)) = false) :
    run M n (cfg 149 first t) = cfg 149 (first + (n : Int)) t := by
  induction n with
  | zero => simp
  | succ n ih =>
    have before := ih (fun i hi => gap i (Nat.lt_succ_of_lt hi))
    have advance := identity_step (gap n (Nat.lt_succ_self _)) R.seekZero
    rw [run_succ, before, advance]
    simp only [moveHead, Direction.left, Direction.right]
    congr 1 <;> omega

theorem restore_header (t : Tape) (h : Int) (atHeader : t h = true)
    (afterHeader : t (h + 1) = false) :
    run M 3 (cfg 149 h t) = cfg 124 (h - 1) t := by
  let wiped := writeTape t h false
  have h₁ : step M (cfg 149 h t) = cfg 126 (h + 1) wiped :=
    one atHeader R.seekOne
  have clear : wiped (h + 1) = false :=
    (writeTape_away _ _ _ _ (by omega)).trans afterHeader
  have h₂ : step M (cfg 126 (h + 1) wiped) = cfg 123 h wiped := by
    rw [identity_step clear R.header]
    simp only [moveHead, Direction.left, Direction.right]
    congr 1 <;> omega
  have h₃ : step M (cfg 123 h wiped) = cfg 124 (h - 1) t := by
    rw [one (show wiped h = false from writeTape_at _ _ _) R.restore]
    change cfg 124 (h - 1) (writeTape (writeTape t h false) h true) = _
    rw [write_restore false atHeader]
  exact three h₁ h₂ h₃

/-- Three steps move one cell to the left. A 1 at the destination changes
control to the origin decoder. The temporary marker is erased in both cases. -/
theorem retreat_one (t : Tape) (h : Int) (b : Bool) (here : t h = false)
    (left : t (h - 1) = b) :
    run M 3 (cfg 124 h t) = cfg (if b then 130 else 124) (h - 1) t := by
  let marked := writeTape t h true
  have h₁ : step M (cfg 124 h t) = cfg 32 (h - 1) marked := one here R.retreat
  have atLeft : marked (h - 1) = b :=
    (writeTape_away _ _ _ _ (by omega)).trans left
  have h₂ : step M (cfg 32 (h - 1) marked) = cfg (if b then 34 else 33) h marked := by
    cases b with
    | false =>
      rw [identity_step atLeft R.pivotZero]
      simp only [moveHead, Direction.left, Direction.right]
      congr 1 <;> omega
    | true =>
      rw [identity_step atLeft R.pivotOne]
      simp only [moveHead, Direction.left, Direction.right]
      congr 1 <;> omega
  have atMarker : marked h = true := writeTape_at _ _ _
  have h₃ : step M (cfg (if b then 34 else 33) h marked) =
      cfg (if b then 130 else 124) (h - 1) t := by
    cases b with
    | false =>
      change step M (cfg 33 h marked) = cfg 124 (h - 1) t
      rw [one atMarker R.eraseZero]
      change cfg 124 (h - 1) (writeTape (writeTape t h true) h false) = _
      rw [write_restore true here]
    | true =>
      change step M (cfg 34 h marked) = cfg 130 (h - 1) t
      rw [one atMarker R.eraseOne]
      change cfg 130 (h - 1) (writeTape (writeTape t h true) h false) = _
      rw [write_restore true here]
  exact three h₁ h₂ h₃

theorem retreat_zeros (t : Tape) (last : Int) (n : Nat)
    (stop : t last = true)
    (gap : ∀ i : Nat, i ≤ n → t (last + (i : Int) + 1) = false) :
    run M (3 * (n + 1)) (cfg 124 (last + (n : Int) + 1) t) = cfg 130 last t := by
  induction n with
  | zero =>
    have oneBack := R.retreat_one t (last+1) true (by simpa using gap 0 (by decide))
      (by simpa using stop)
    simpa using oneBack
  | succ n ih =>
    let h := last + ((n+1 : Nat) : Int) + 1
    have here : t h = false := gap (n+1) (Nat.le_refl _)
    have eq : h - 1 = last + (n : Int) + 1 := by dsimp [h]; omega
    have atLeft : t (h-1) = false := by rw [eq]; exact gap n (Nat.le_succ _)
    have hback : run M 3 (cfg 124 h t) = cfg 124 (last+(n:Int)+1) t := by
      have stepBack := R.retreat_one t h false here atLeft
      change run M 3 (cfg 124 h t) = cfg 124 (h - 1) t at stepBack
      rw [eq] at stepBack
      exact stepBack
    have rest := ih (fun i hi => gap i (Nat.le.step hi))
    have time : 3 * (n+1+1) = 3 + 3 * (n+1) := by omega
    rw [time, run_add, hback, rest]

/-- Complete gap protocol including the header visit. Positions strictly
between the final prefix 1 and the header are zero. Every other tape cell
is arbitrary except the header's second symbol. The whole tape is restored. -/
theorem scan_gap (t : Tape) (first last header : Int)
    (order : last < first) (beforeHeader : first ≤ header)
    (space : last + 1 < header) (atLast : t last = true)
    (atHeader : t header = true) (afterHeader : t (header + 1) = false)
    (zeros : ∀ p, last < p → p < header → t p = false) :
    run M ((header-first).toNat + 3 + 3 * ((header-last-2).toNat + 1))
      (cfg 149 first t) = cfg 130 last t := by
  have h₁ : run M (header-first).toNat (cfg 149 first t) = cfg 149 header t := by
    have hh : first + ((header-first).toNat : Int) = header := by omega
    rw [R.seek_zeros t first _ (fun i hi => zeros _ (by omega) (by omega)), hh]
  have h₂ := R.restore_header t header atHeader afterHeader
  have l := R.retreat_zeros t last (header-last-2).toNat atLast
    (fun i hi => zeros _ (by omega) (by omega))
  have pos : last + ((header-last-2).toNat : Int) + 1 = header-1 := by omega
  rw [pos] at l
  rw [run_add, run_add, h₁, h₂, l]

end ScannerRows
end P185.Control
