module
public import C200Rows
@[expose] public section
namespace C196
open C200 NF192 NF192.Numerical NF192.Emitter
def logicalTokens : List Macro :=
  [.push3, .push4, .imp, .read4, .push4, .imp, .push4, .push3, .imp, .push5, .push3, .imp, .imp, .imp]

theorem logicalEffect (n t stack c u b delta tail : Nat) :
    logicalTokens.foldl Frame.apply ⟨n,t,stack,c,u,b,pair delta tail⟩ = ⟨n,row0 (u+delta) b c u,pair t stack,c,u+delta,b,tail⟩ := by
  simp only [logicalTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push, Frame.combine,
    Cantor.unpair_pair, ctor, row0, imp, eqn, app, konst, witness, goal_is_three,
    B_is_three, s_is_one, q, Nat.add_zero]
  <;> rfl

def suffix : List Macro := logicalTokens ++ tokens1 ++ nativeBRowTokens ++ tokens4 ++ tokens6 ++ tokens7 ++ scalarRowTokens ++ tokens3 ++ tokens9 ++ tokens2

def batchCode : Code := sequence .read5 suffix

theorem batch_effect (n t stack c u v y delta tail : Nat) :
    suffix.foldl Frame.apply (Frame.apply ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩ .read5) =
      save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (C200.rowList (u+delta) (v+y) c u) := by
  simp only [suffix, List.foldl_append, Frame.apply, Cantor.unpair_pair]
  rw [logicalEffect, effect1, nativeBRow_effect, effect4, effect6, effect7, scalarRow_effect, effect3, effect9, effect2]
  rfl

theorem batch_eval (n t stack c u v y delta tail : Nat) :
    Eval batchCode (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩) .normal
      (save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (C200.rowList (u+delta) (v+y) c u)).regs := by
  rw [← batch_effect n t stack c u v y delta tail]
  exact sequence_eval .read5 suffix _


end C196
