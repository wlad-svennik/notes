module
public import P185MachineControlCarryCase
public import P185CarryFinite
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P185.Carry
open KernelRightShift

/-- Each bounded certificate supplies the two traces for the ends of the carry.
The cleanup between them has arbitrary length and arbitrary surrounding tape. -/
theorem all_arithmetic_returns (pc : Nat) (hi : pc < 2959) (zero : Bool)
    (hs : selected pc zero = true) (extra : Nat) (space : 52 ≤ (initialWord pc zero).length+extra) :
    ∃ t, WordRun (entryState zero) 13 (ready pc zero extra) (restored pc zero extra)
      (startHead pc) (before (shifted pc zero)+1 : Nat) t := by
  let h := FiniteCarry.field pc zero
  let c : Case := ⟨pc, zero, nextPc pc zero, shifted pc zero, h%256, (h >>> 8)%256, h >>> 16⟩
  have finite := FiniteCarry.all_finite_carries pc hi zero hs
  have valid : Valid c := ⟨rfl, rfl, finite⟩
  exact case_return (c := c) (decide_eq_true valid) extra space

#print axioms all_arithmetic_returns
end P185.Carry
