module
public import P185MachineSource
public meta import P185MachineSource

@[expose] public section

namespace P185.Source
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def leavesTile : Bool :=
  lowKey (siteAt 0) == 2^44 &&
  highKey (siteAt (siteCount-1)) == 2^45 &&
  (List.range siteCount).all fun i =>
    let s := siteAt i
    s.address > 0 && s.depth == Nat.log2 s.address && s.depth ≤ 44 &&
      (i+1 == siteCount || highKey s == lowKey (siteAt (i+1)))

theorem complete_ordered_prefix_code : leavesTile = true := by native_decide


theorem unique_conditional_halt :
    (List.range siteCount).filter (fun i =>
      let s := siteAt i
      s.op == Primitive.dec && s.address % 2 == 1) = [2942] := by native_decide

#print axioms unique_conditional_halt
end P185.Source
