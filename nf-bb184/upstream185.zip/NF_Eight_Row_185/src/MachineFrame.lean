module
public import MachineBoot
public import MachineSource

@[expose] public section

/-! The register frame on the infinite integer tape. The first tape bit is
the sentinel immediately left of the head. The source address continues to
the right, followed by the gap and its header. In the payload each natural
n is encoded by a zero and then n + 1 one-bits. Registers are ordered by
the physical register selector of this table. Remaining fields are spares. -/
namespace NF192.Frame

open NF210 NF192

def registerOrder : List Nat := [2,8,1,4,3,7,0,5,6]

def addressBits (pc : Nat) : List Bool :=
  let site := Source.siteAt pc
  (List.range site.depth).map fun i => site.address.testBit (site.depth - (i+1))

structure Layout where
  head : Int
  pc : Nat
  gap : Nat
  stored : Array Nat
  spares : List Nat
  deriving Inhabited

def Layout.header (f : Layout) : Int := f.head + (f.gap : Int)
def Layout.logical (f : Layout) (r : Nat) : Int := (f.stored[r]?.getD 0 : Int) - 1
def field (n : Nat) : List Bool := false :: List.replicate (n+1) true
def Layout.word (f : Layout) : List Bool :=
  let address := addressBits f.pc
  let values := registerOrder.map (fun r => f.stored[r]?.getD 0) ++ f.spares
  (true :: address) ++ List.replicate (f.gap-address.length) false ++
    (true :: values.flatMap field)

def cells (left : Int) (word : List Bool) (p : Int) : Bool :=
  if p < left then false else word[(p-left).toNat]?.getD false

def Layout.tape (f : Layout) : TM.Tape := cells (f.head-1) f.word
def Layout.config (f : Layout) : TM.Configuration 192 :=
  ⟨some Selected.decoderRoot,f.head,f.tape⟩

theorem cells_before {left p : Int} (word : List Bool) (h : p < left) :
    cells left word p = false := by simp [cells,h]

theorem cells_after {left p : Int} (word : List Bool) (h : left + (word.length : Int) ≤ p) :
    cells left word p = false := by
  have hr : ¬ p < left := by omega
  have hn : word.length ≤ (p-left).toNat := by omega
  simp [cells,hr,List.getElem?_eq_none hn]

/-- Finite bit equality identifies the complete tape, including every cell
outside the checked window. -/
theorem packed_eq_cells {width : Nat} {anchor left : Int} {bits : Nat} {word : List Bool}
    (lo : anchor ≤ left) (hi : left + (word.length : Int) ≤ anchor + (width : Int))
    (hMatches : ∀ i : Fin width, bits.testBit i = cells left word (anchor + (i : Nat))) :
    KernelBits.tape width anchor (fun _ => false) bits = cells left word := by
  funext p
  by_cases h : 0 ≤ p-anchor ∧ p-anchor < (width : Int)
  · let i : Fin width := ⟨(p-anchor).toNat, by omega⟩
    have hp : p = anchor + (i.val : Int) := by dsimp [i]; omega
    rw [hp,KernelBits.tape_read width i.val bits i.isLt]
    exact hMatches i
  · simp only [KernelBits.tape,ite_eq_right h]
    by_cases before : p < left
    · exact (cells_before word before).symm
    · apply (cells_after word _).symm
      omega

theorem snapshot_eq (s : KernelBits.Configuration 192) (f : Layout)
    (q : s.state = some Selected.decoderRoot) (h : (-10 : Int) + (s.head : Int) = f.head)
    (lo : -10 ≤ f.head - 1)
    (hi : f.head - 1 + (f.word.length : Int) ≤ -10 + (Boot.width : Int))
    (agree : ∀ i : Fin Boot.width,
      s.bits.testBit i = cells (f.head-1) f.word (-10 + (i.val : Int))) :
    KernelBits.embed Boot.width (-10) (fun _ => false) s = f.config := by
  have ht := packed_eq_cells lo hi agree
  change TM.Configuration.mk s.state ((-10 : Int) + (s.head : Int)) _ =
    TM.Configuration.mk (some Selected.decoderRoot) f.head (cells (f.head-1) f.word)
  rw [q,h,ht]

def firstAX : Layout :=
  ⟨-1,40,32,#[0,1,1,3,1,1,1,1,1],List.replicate 12 0⟩

def firstMargin : Layout :=
  ⟨-1,91,42,#[0,1,1,3,1,1,1,3,1],List.replicate 24 0⟩

set_option maxRecDepth 10000
set_option maxHeartbeats 0

theorem blank_first_frame : TM.run Selected.machine 16813 (TM.blank Selected.start) =
    firstAX.config := by
  rw [Boot.blank_first_axiom]
  apply snapshot_eq <;> decide +kernel

theorem blank_margin_frame : TM.run Selected.machine 33911 (TM.blank Selected.start) =
    firstMargin.config := by
  rw [Boot.blank_decoder_margin]
  apply snapshot_eq <;> decide +kernel

theorem offset_at_margin :
    (List.range 9).map firstMargin.logical = [-1,0,0,2,0,0,0,2,0] ∧
    firstMargin.header = 41 ∧ firstMargin.gap = 42 ∧ firstMargin.spares.length = 24 := by
  decide +kernel

theorem offset_at_first_axiom :
    (List.range 9).map firstAX.logical = [-1,0,0,2,0,0,0,0,0] ∧
    firstAX.header = 31 ∧ firstAX.gap = 32 ∧ firstAX.spares.length = 12 := by
  decide +kernel

/-- The decoder's last ten exterior gap cells are zero at the second
anchor; the header itself is a one followed by a zero. -/
theorem margin_header :
    (∀ p : Int, 31 ≤ p → p < 41 → firstMargin.tape p = false) ∧
    firstMargin.tape 41 = true ∧ firstMargin.tape 42 = false := by
  have ten : ∀ i : Fin 10, firstMargin.tape (31 + (i.val : Int)) = false := by decide +kernel
  refine ⟨?_,by decide +kernel,by decide +kernel⟩
  intro p hlo hhi
  let i : Fin 10 := ⟨(p-31).toNat,by omega⟩
  have hp : p = 31 + (i.val : Int) := by dsimp [i]; omega
  exact hp ▸ ten i

end NF192.Frame

#print axioms NF192.Frame.blank_first_frame
#print axioms NF192.Frame.blank_margin_frame
#print axioms NF192.Frame.margin_header
