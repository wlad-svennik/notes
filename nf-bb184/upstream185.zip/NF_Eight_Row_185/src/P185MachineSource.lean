module
public import P185MachineSourceData

@[expose] public section

/-! Source register semantics for the literal 3,446-leaf layout.
The address decoder uses the complete leaf intervals in binary prefix
order. A zero decrement halts precisely at an odd-address decrement;
the binary machine's uniform realization of this protocol is a separate theorem. -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace P185.Source

abbrev Registers := Nat → Nat
def setReg (rs : Registers) (r value : Nat) : Registers :=
  fun s => if s = r then value else rs s

/-- Increment, decrement with separate zero/positive exits, or an unconditional jump. -/
abbrev Command := Sum (Nat × Nat) (Sum (Nat × Nat × Nat × Bool) Nat)
namespace Command
@[match_pattern] abbrev inc (r next : Nat) : Command := .inl (r,next)
@[match_pattern] abbrev dec (r zero positive : Nat) (haltZero : Bool) : Command :=
  .inr (.inl (r,zero,positive,haltZero))
@[match_pattern] abbrev jump (next : Nat) : Command := .inr (.inr next)
end Command

abbrev Config := Option (Nat × Registers)
namespace Config
@[match_pattern] abbrev active (pc : Nat) (registers : Registers) : Config := some (pc,registers)
@[match_pattern] abbrev halted : Config := none
end Config

/-- Fixed 44-bit comparison keys are valid for all paths in this table. -/
def lowKey (s : Site) : Nat := s.address <<< (44 - s.depth)
def highKey (s : Site) : Nat := (s.address+1) <<< (44 - s.depth)

/-- Search for the first leaf whose address begins with a given prefix.
A shorter prefix and its leftmost descendant have equal lower keys. -/
def searchLeaf (key : Nat) : Nat → Nat → Nat → Nat
  | 0, lo, _ => lo
  | fuel+1, lo, hi =>
    if lo < hi then
      let mid := (lo+hi)/2
      if lowKey (siteAt mid) < key then searchLeaf key fuel (mid+1) hi
      else searchLeaf key fuel lo mid
    else lo

def destination (pathCode : Nat) : Nat :=
  searchLeaf (pathCode <<< (44 - Nat.log2 pathCode)) 13 0 siteCount

/-- Remove trailing bits until the requested bit is visible, or reach root. -/
def findBit (wanted : Bool) : Nat → Nat → Nat
  | 0, p => p
  | fuel+1, p =>
    if p ≤ 1 || (p % 2 == 1) == wanted then p else findBit wanted fuel (p/2)

def cutOnce (p : Nat) (wanted : Bool) : Nat := max 1 ((findBit wanted 45 p)/2)
def cut (wanted : Bool) : Nat → Nat → Nat
  | 0, p => p
  | n+1, p => cut wanted n (cutOnce p wanted)

def plus (p : Nat) : Nat :=
  let stopped := findBit false 45 p
  if stopped ≤ 1 then 1 else stopped+1

def decode (s : Site) : Command :=
  let p := s.address
  if s.op == Primitive.inc then Command.inc s.argument (destination (plus p))
  else if s.op == Primitive.dec then Command.dec s.argument (destination (plus (cutOnce p false)))
                      (destination (plus p)) (p % 2 == 1)
  else if s.op == Primitive.brk then Command.jump (destination (plus (cut false s.argument p)))
  else Command.jump (destination (cut true s.argument p))

/-- An out-of-range ordinal loops; no valid source edge uses this case. -/
def program (pc : Nat) : Command :=
  if pc < siteCount then decode (siteAt pc) else Command.jump pc

def execute (c : Command) (rs : Registers) : Config :=
  match c with
  | .inl (r,next) => Config.active next (setReg rs r (rs r+1))
  | .inr (.inl (r,zero,positive,haltZero)) =>
    match rs r with
    | 0 => if haltZero then Config.halted else Config.active zero rs
    | n+1 => Config.active positive (setReg rs r n)
  | .inr (.inr next) => Config.active next rs

def step : Config → Config
  | some (pc,rs) => execute (program pc) rs
  | none => none

def advance : Nat → Config → Config
  | 0, s => s
  | n+1, s => advance n (step s)

theorem advance_add (i j : Nat) (s : Config) :
    advance (i+j) s = advance j (advance i s) := by
  induction i generalizing s with
  | zero => simp [advance]
  | succ i ih => simp only [Nat.succ_add, advance, ih]

end P185.Source
