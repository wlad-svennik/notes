module
public import C196Rows
public import Eight187SearchCore
@[expose] public section
namespace Eight187
open NF192 NF192.Numerical NF192.Emitter
def suffix : List Macro := C196.logicalTokens ++ tokens4 ++ Eight187.Seed.bTokens ++ tokens2 ++ tokens3 ++ tokens6 ++ Eight187.Seed.testTokens ++ tokens9

def batchCode : Code := sequence .read5 suffix

theorem batch_effect (n t stack c u v y delta tail : Nat) :
    suffix.foldl Frame.apply (Frame.apply ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩ .read5) =
      save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (Eight187.rowList (u+delta) (v+y) c u) := by
  simp only [suffix, List.foldl_append, Frame.apply, Cantor.unpair_pair]
  rw [C196.logicalEffect, effect4, Eight187.Seed.effectB, effect2, effect3, effect6, Eight187.Seed.effectTest, effect9]
  rfl

theorem batch_eval (n t stack c u v y delta tail : Nat) :
    Eval batchCode (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩) .normal
      (save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (Eight187.rowList (u+delta) (v+y) c u)).regs := by
  rw [← batch_effect n t stack c u v y delta tail]
  exact sequence_eval .read5 suffix _


end Eight187
