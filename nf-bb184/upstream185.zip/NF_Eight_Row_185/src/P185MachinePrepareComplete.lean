module
public import P185MachinePrepare
public import P185MachineArithmeticReturnComplete
public import P185ArithmeticPhaseWords
public import P185MachineFrameWords
@[expose] public section

namespace P185.Prepare
open NF210 NF210.TM CS185.Table
open P185.KernelRightShift P185.KernelSelectors
set_option maxHeartbeats 7000000

def frameWord (s : Source.Site) (extra : Nat) (tail : List Bool) (filled : Bool) :=
  (true :: Phase.path s) ++ List.replicate (extra+2) filled ++ true :: tail

def prepTime (i extra : Nat) := Phase.elapsed i 0 + (1 + ((extra+2)+1) + (extra+2))

theorem initial_decode_and_sweep (i extra : Nat) (tail : List Bool) (inside : i < 2959)
    (enabled : Phase.enabled (Source.siteAt i) 0 = true) :
    let s := Source.siteAt i
    WordRun decoderRoot returnState (frameWord s extra tail false) (frameWord s extra tail true)
      1 (s.depth : Int) (prepTime i extra) := by
  let s := Source.siteAt i
  let b := s.op == Source.Primitive.inc
  let pre := true :: Phase.path s
  have first : WordRun decoderRoot (setupState b) (frameWord s extra tail false) (frameWord s extra tail false)
      1 ((s.depth : Int)+2) (Phase.elapsed i 0) := by
    have raw := (Phase.word_dispatch i 0 inside (by decide) enabled).context []
      (List.replicate extra false ++ true::tail)
    simpa [s,b,frameWord,setupState,incSetup,decSetup,Phase.inputWord,Phase.outputWord,
      Phase.initialHead,Phase.finalHead,Phase.target,List.replicate_succ,List.append_assoc] using raw
  have second : WordRun (setupState b) returnState (frameWord s extra tail false) (frameWord s extra tail true)
      ((s.depth:Int)+2) (s.depth:Int) (1 + ((extra+2)+1) + (extra+2)) := by
    have raw := (setup_rewind b (extra+2) (by omega)).context pre tail
    have a : (pre.length : Int)+1 = (s.depth:Int)+2 := by simp [pre]; omega
    have z : (pre.length : Int)+(-1) = (s.depth:Int) := by simp [pre]; omega
    rw [a,z] at raw
    simpa [pre,sourceGap,frameWord,List.append_assoc] using raw
  exact first.trans second

def guardedWord (s : Source.Site) (extra : Nat) (tail : List Bool) (b : Bool) :=
  List.replicate 8 false ++ frameWord s extra tail b

def totalTime (i extra : Nat) := prepTime i extra + ArithmeticReturn.duration (Source.siteAt i) false

/-- All arithmetic sites and arbitrary physical registers/spares. The normal
00 phase becomes 11 and re-enters the true decoder root at the original head. -/
theorem prepared_word (i extra : Nat) (tail : List Bool) (inside : i < 2959)
    (enabled : Phase.enabled (Source.siteAt i) 0 = true) :
    let s := Source.siteAt i
    WordRun decoderRoot decoderRoot (guardedWord s extra tail false) (guardedWord s extra tail true)
      9 9 (totalTime i extra) := by
  let s := Source.siteAt i
  have sweep : WordRun decoderRoot returnState (guardedWord s extra tail false) (guardedWord s extra tail true)
      9 (8+(s.depth:Int)) (prepTime i extra) := by
    simpa [s,guardedWord] using
      (initial_decode_and_sweep i extra tail inside enabled).context (List.replicate 8 false) []
  have origin : WordRun returnState decoderRoot (guardedWord s extra tail true) (guardedWord s extra tail true)
      (8+(s.depth:Int)) 9 (ArithmeticReturn.duration s false) := by
    have raw := (ArithmeticReturn.all_returns i inside enabled false).context []
      (List.replicate extra true ++ true::tail)
    simpa [s,guardedWord,frameWord,ArithmeticReturn.stageWord,ArithmeticReturn.guard,
      ArithmeticReturn.initialHead,ArithmeticReturn.finalHead,ArithmeticReturn.nextPhase,
      Phase.inputWord,Phase.initialHead,List.replicate_succ,List.append_assoc] using raw
  exact sweep.trans origin

def preparedTape (f : Frame.Layout) : Tape :=
  wordTape (f.head-1) (f.prefix ++ List.replicate f.gapWidth true ++ true::blocks f.values) Frame.blankOutside
def preparedConfig (f : Frame.Layout) : Configuration 185 :=
  configuration decoderRoot f.head (preparedTape f)

/-- Initial preparation directly from the canonical infinite tape, for
every arithmetic location and every legal space between address and header. -/
theorem from_canonical (f : Frame.Layout) (inside : f.pc < 2959)
    (enabled : Phase.enabled (Source.siteAt f.pc) 0 = true) (room : 2 ≤ f.gapWidth) :
    TM.run machine (totalTime f.pc (f.gapWidth-2)) f.config = preparedConfig f := by
  let s := Source.siteAt f.pc
  have size : (f.gapWidth-2)+2 = f.gapWidth := by omega
  have goal := (prepared_word f.pc (f.gapWidth-2) (blocks f.values) inside enabled).exact_run
    (f.head-1-8) Frame.blankOutside
  have pos : f.head-1-8+9 = f.head := by omega
  rw [pos] at goal
  have entry : wordTape (f.head-1-8) (guardedWord s (f.gapWidth-2) (blocks f.values) false) Frame.blankOutside
      = f.tape := by
    have h := (f.tape_padded 8 0).symm
    rw [f.word_kernel] at h
    simpa [guardedWord,frameWord,s,size,Frame.Layout.prefix,Frame.addressBits,Phase.path,List.append_assoc] using h
  have exit : wordTape (f.head-1-8) (guardedWord s (f.gapWidth-2) (blocks f.values) true) Frame.blankOutside
      = preparedTape f := by
    have h := Frame.pad_word (f.head-1) (f.prefix ++ List.replicate f.gapWidth true ++ true::blocks f.values) 8 0
    simpa [guardedWord,frameWord,s,size,preparedTape,Frame.Layout.prefix,Frame.addressBits,
      Phase.path,List.append_assoc] using h
  change TM.run machine _ (configuration decoderRoot f.head f.tape) = configuration decoderRoot f.head (preparedTape f)
  rw [←entry,←exit]
  exact goal

#print axioms prepared_word
#print axioms from_canonical
end P185.Prepare
