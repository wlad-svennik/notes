module
public import Eight187Cold
public import Eight187Origin
@[expose] public section
namespace Eight187.Register
open NF192 NF192.Emitter NF192.Emitter.Registers
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def margin185 : Emitter.Config := ⟨118, mk9 0 0 0 2 0 0 0 1 0⟩
def first185 := Emitter.run frozen 98 origin

theorem frozen_steps185 : first185 = some margin185 := by
  have hp : first185.map Emitter.Config.pc = some margin185.pc := by decide +kernel
  have hr : ∀ i : Fin 9, first185.map (fun c => c.registers i) = some (margin185.registers i) := by
    decide +kernel
  cases h : first185 with
  | none => simp [h] at hp
  | some c =>
    rw [h] at hp
    have reg : c.registers = margin185.registers := by
      funext i
      simpa only [h,Option.map_some,Option.some.injEq] using hr i
    have pc : c.pc = margin185.pc := by simpa only [Option.map_some,Option.some.injEq] using hp
    apply congrArg some
    cases c with
    | mk p rs =>
      change p = 118 at pc
      change rs = _ at reg
      cases pc
      cases reg
      rfl

theorem advance_steps185 : bootstrapAdvance 98 (true,liftConfig origin) = (true,liftConfig margin185) :=
  frozen_run 98 frozen_steps185


end Eight187.Register
#print axioms Eight187.Register.advance_steps185
