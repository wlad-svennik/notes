module
public import NumericalEmitterMachine

@[expose] public section

/-! A finite pointwise checker for placing any structured register block
inside the literal source. Equality includes every instruction argument. -/
set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Emitter

deriving instance DecidableEq for Instruction

def matchesCode (pc : Nat) : List Instruction → Bool
  | [] => true
  | i :: is => decide (actual pc = i) && matchesCode (pc+1) is

theorem matchesCode_spec (pc : Nat) (xs : List Instruction) (yes : matchesCode pc xs = true)
    (i : Nat) (hi : i < xs.length) : actual (pc+i) = xs[i] := by
  induction xs generalizing pc i with
  | nil => simp at hi
  | cons x xs ih =>
      change (decide (actual pc = x) && matchesCode (pc+1) xs) = true at yes
      have hh : decide (actual pc = x) = true ∧ matchesCode (pc+1) xs = true := by simpa only [Bool.and_eq_true_iff] using yes
      cases i with
      | zero => simpa using (of_decide_eq_true hh.1 : actual pc = x)
      | succ j =>
          have hj : j < xs.length := by simpa using hi
          have he := ih (pc+1) hh.2 j hj
          simpa only [List.getElem_cons_succ, Nat.add_assoc, Nat.add_comm 1 j, Nat.succ_eq_add_one] using he

theorem embedded_of_matches (code : Code) (pc last : Nat)
    (check : matchesCode pc (compile code pc last [] []) = true) :
    Embedded actual code pc last [] [] := by
  intro i hi
  exact matchesCode_spec pc _ check i (by simpa only [compile_length] using hi)

end NF192.Emitter
