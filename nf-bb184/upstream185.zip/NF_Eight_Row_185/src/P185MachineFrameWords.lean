module
public import P185MachineFrame
public import P185MachineControlKernelFiles
public import P185MachineBitsWord

@[expose] public section

/-! Canonical two-way tape geometry shared by the decoded arithmetic phases.
Physical slots follow the wiring of this exact transition table. The
logical-to-physical permutation and the attachment of arbitrary spare slots
are explicit. The finite word may be padded on both sides by any number of
zero cells without changing the represented infinite tape. -/

namespace P185.Frame

open NF210 NF210.TM KernelRightShift

def blankOutside : Tape := fun _ => false

theorem cells_wordTape (left : Int) (xs : List Bool) :
    cells left xs = wordTape left xs blankOutside := by
  funext p
  by_cases inside : left ≤ p ∧ p < left + (xs.length : Int)
  · let i := (p-left).toNat
    have hi : i < xs.length := by dsimp [i]; omega
    have hp : p = left+(i : Int) := by dsimp [i]; omega
    rw [hp, wordTape_get _ _ _ _ hi]
    have np : ¬left+(i:Int) < left := by omega
    have e : (left+(i:Int)-left).toNat = i := by omega
    simp only [cells, ite_eq_right np,e,List.getElem?_eq_getElem hi, Option.getD_some]
  · rw [wordTape_outside _ _ _ _ (by omega)]
    by_cases before : p < left
    · exact cells_before xs before
    · exact cells_after xs (by omega)

theorem Layout.tape_wordTape (f : Layout) :
    f.tape = wordTape (f.head-1) f.word blankOutside := cells_wordTape _ _

theorem blank_run (a : Int) (n : Nat) :
    wordTape a (List.replicate n false) blankOutside = blankOutside := by
  induction n generalizing a with
  | zero => rfl
  | succ n ih =>
    rw [List.replicate_succ, wordTape_cons, ih]
    exact writeTape_read blankOutside a

/-- Surround a zero-background word with any finite number of guards. -/
theorem pad_word (a : Int) (xs : List Bool) (before after : Nat) :
    wordTape (a-(before:Int))
      (List.replicate before false ++ xs ++ List.replicate after false) blankOutside =
    wordTape a xs blankOutside := by
  rw [wordTape_append, blank_run, wordTape_append]
  have h : a-(before:Int)+((List.replicate before false).length:Int) = a := by simp
  rw [h, wordTape_commute _ a _ xs blankOutside (by omega), blank_run]

theorem Layout.tape_padded (f : Layout) (before after : Nat) :
    f.tape = wordTape (f.head-1-(before:Int))
      (List.replicate before false ++ f.word ++ List.replicate after false) blankOutside :=
  f.tape_wordTape.trans (pad_word _ _ _ _).symm

def Layout.storedAt (f : Layout) (r : Nat) : Nat := f.stored[r]?.getD 0

def Layout.values (f : Layout) := registerOrder.map f.storedAt ++ f.spares

def Layout.prefix (f : Layout) : List Bool :=
  true :: addressBits f.pc

def Layout.gapWidth (f : Layout) : Nat := f.gap - (addressBits f.pc).length

theorem fields_blocks (xs : List Nat) : xs.flatMap field = blocks xs := by
  induction xs with
  | nil => rfl
  | cons a rest ih =>
    simp only [List.flatMap_cons, field, List.cons_append, ih, blocks]

theorem Layout.word_kernel (f : Layout) :
    f.word = f.prefix ++ List.replicate f.gapWidth false ++ (true :: blocks f.values) := by
  change f.prefix ++ List.replicate f.gapWidth false ++ (true :: f.values.flatMap field) = _
  rw [fields_blocks]

theorem physical_rank (r : Fin 9) :
    let k := registerOrder.idxOf r.val
    k < 9 ∧ registerOrder[k]? = some r.val := by
  have check : ∀ i : Fin 9, registerOrder.idxOf i.val < 9 ∧
      registerOrder[registerOrder.idxOf i.val]? = some i.val := by decide
  exact check r

def Layout.beforeReg (f : Layout) (r : Fin 9) :=
  f.values.take (registerOrder.idxOf r.val)

def Layout.afterReg (f : Layout) (r : Fin 9) :=
  f.values.drop (registerOrder.idxOf r.val + 1)

theorem Layout.values_split (f : Layout) (r : Fin 9) :
    f.values = f.beforeReg r ++ f.storedAt r.val :: f.afterReg r := by
  let k := registerOrder.idxOf r.val
  have hk : k < registerOrder.length := (physical_rank r).1
  have kv : k < f.values.length := by
    simp only [Layout.values,List.length_append,List.length_map]; omega
  have lookup : registerOrder[k] = r.val := by
    have e := (physical_rank r).2
    rwa [List.getElem?_eq_getElem hk,Option.some.injEq] at e
  have val : f.values[k] = f.storedAt r.val := by
    rw [show f.values[k] = (registerOrder.map f.storedAt)[k]'(by simpa only [List.length_map]) from
      List.getElem_append_left (by simpa only [List.length_map])]
    rw [List.getElem_map,lookup]
  change f.values = f.values.take k ++ f.storedAt r.val :: f.values.drop (k+1)
  rw [←val, List.getElem_cons_drop kv, List.take_append_drop]

theorem Layout.beforeReg_length (f : Layout) (r : Fin 9) :
    (f.beforeReg r).length = registerOrder.idxOf r.val := by
  have hk : registerOrder.idxOf r.val < registerOrder.length := (physical_rank r).1
  simp only [Layout.beforeReg,List.length_take,Layout.values,List.length_append,List.length_map]
  omega

theorem Layout.word_split (f : Layout) (r : Fin 9) :
    f.word = f.prefix ++ List.replicate f.gapWidth false ++
      (true :: (blocks (f.beforeReg r) ++
        (false :: (List.replicate (f.storedAt r.val+1) true ++ blocks (f.afterReg r))))) := by
  rw [f.word_kernel, f.values_split r, KernelFiles.blocks_append,blocks]

end P185.Frame
