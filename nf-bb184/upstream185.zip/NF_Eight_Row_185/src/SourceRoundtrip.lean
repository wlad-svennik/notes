module
public import SourceFields

@[expose] public section

/-! Every natural cursor is exactly the encoding of the command and
remaining input returned by the actual plain-field parser. -/
namespace NF192.SourceFields
open Numerical Numerical.Cantor ProofSearch

theorem encode_readBatch (n : Nat) : encodeBatch (readBatch n).1 (readBatch n).2 = n := by
  simp only [encodeBatch, readBatch, pair_unpair]

theorem readBatches_length (k n : Nat) : (readBatches k n).1.length = k := by
  induction k generalizing n with
  | zero => rfl
  | succ k ih => simp only [readBatches, List.length_cons, ih]

theorem encode_readBatches (k n : Nat) :
    encodeBatches (readBatches k n).1 (readBatches k n).2 = n := by
  induction k generalizing n with
  | zero => rfl
  | succ k ih => simp only [readBatches, encodeBatches, ih, encode_readBatch]

theorem assemble_parse (n : Nat) : assemble (parse n).1 (parse n).2 = n := by
  obtain ⟨tag, rem, decomp⟩ : ∃ tag rem, n = pair tag rem :=
    ⟨(unpair n).1, (unpair n).2, (pair_unpair n).symm⟩
  subst n
  obtain ⟨field, raw, decomp⟩ : ∃ field raw, rem = pair field raw :=
    ⟨(unpair rem).1, (unpair rem).2, (pair_unpair rem).symm⟩
  subst rem
  cases tag with
  | zero => simp only [parse, unpair_pair, assemble]
  | succ tag =>
    cases tag with
    | zero => simp only [parse, unpair_pair, assemble]
    | succ k =>
      simp only [parse, unpair_pair, assemble, readBatches_length, encode_readBatches]
      change pair (k+2) (pair field (encodeBatch (readBatch raw).1 (readBatch raw).2)) = _
      rw [encode_readBatch]

end NF192.SourceFields
