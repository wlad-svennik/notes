module
public import P185MachineBitsWord
public import P185MachineControlKernelContracts

@[expose] public section

namespace P185.BitsWord

open NF210 NF210.TM P185.KernelRightShift

/-- Padding a finite word with the symbol already present leaves its tape unchanged. -/
theorem word_with_boundary (xs : List Bool) (a : Int) (t : Tape) :
    wordTape a (xs ++ [t (a + (xs.length : Int))]) t = wordTape a xs t := by
  rw [wordTape_append]
  congr 1
  funext p
  change (if p = a + (xs.length : Int) then t (a + (xs.length : Int)) else t p) = t p
  split <;> simp_all

/-- One scratch bit at the right of a calculation can be taken from any outside
tape when both starting values give the same finite-word transformation. -/
theorem padded_word_run (q q' : CS185.Table.State) (xs ys : List Bool)
    (h h' duration : Nat) (same : xs.length = ys.length) (inside : h < xs.length + 1)
    (check : ∀ b : Bool, NF192.KernelBits.run CS185.Table.machine (xs.length + 1) duration
      ⟨some q,h,encode (xs ++ [b])⟩ = some ⟨some q',h',encode (ys ++ [b])⟩) :
    WordRun q q' xs ys (h : Int) (h' : Int) duration := by
  refine ⟨same, ?_⟩
  intro anchor outside
  let b := outside (anchor + (xs.length : Int))
  have applyRun := (NF192.KernelBits.run_sound CS185.Table.machine _ anchor outside _ _ _ inside (check b)).2
  have left : NF192.KernelBits.tape (xs.length + 1) anchor outside (encode (xs ++ [b])) =
      wordTape anchor xs outside := by
    rw [show xs.length + 1 = (xs ++ [b]).length by simp, tape_encode]
    exact word_with_boundary xs anchor outside
  have right : NF192.KernelBits.tape (xs.length + 1) anchor outside (encode (ys ++ [b])) =
      wordTape anchor ys outside := by
    rw [show xs.length + 1 = (ys ++ [b]).length by simp [same], tape_encode]
    simpa only [b,same] using word_with_boundary ys anchor outside
  simpa only [NF192.KernelBits.embed, configuration, left, right] using applyRun

end P185.BitsWord
