module
public import MachineBits
public import Table185
public import P185MachinePhaseData
public import P185MachineWordEncoding

@[expose] public section

/-! Bit-level decoder contracts for each arithmetic operation in the frozen
countdown program. Cell zero of the finite window is the left sentinel at
origin minus one. A spare cell immediately after the phase tag may hold either symbol.
The complete exterior tape is arbitrary. -/

namespace P185.Phase

open NF210 NF210.TM
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def enabled (s : Source.Site) (phase : Nat) : Bool :=
  (s.op == Source.Primitive.inc || s.op == Source.Primitive.dec) &&
    (phase < 3 || (phase == 3 && s.op == Source.Primitive.dec && s.depth ≥ 5 && s.address % 32 == 0))

def width (s : Source.Site) : Nat := s.depth + 4

/-- Physical address, most significant branch first. -/
def path (s : Source.Site) : List Bool :=
  (List.range s.depth).map fun i => s.address.testBit (s.depth - (i+1))

def inputWord (s : Source.Site) (phase : Nat) : List Bool :=
  (true :: path s) ++
    (match phase with | 0 => [false, false] | 1 => [true, true] | _ => [false, true])

def outputWord (s : Source.Site) (phase : Nat) : List Bool :=
  (true :: path s) ++ [false, phase == 1]

def initialHead (s : Source.Site) (phase : Nat) : Nat :=
  if phase == 3 then s.depth-4 else 1

def finalHead (s : Source.Site) (phase : Nat) : Nat :=
  if phase < 2 then s.depth+2 else s.depth+3

def entry (s : Source.Site) (phase : Nat) (endBit : Bool := false) : NF192.KernelBits.Configuration 185 :=
  ⟨some CS185.Table.decoderRoot, initialHead s phase,
    BitsWord.encode (inputWord s phase ++ [endBit])⟩

def selector (r : Nat) : CS185.Table.State :=
  (#[131,134,146,137,143,148,150,138,140] : Array CS185.Table.State)[r]?.getD 0

def target (s : Source.Site) (phase : Nat) : CS185.Table.State :=
  match phase with
  | 0 => if s.op == Source.Primitive.inc then 144 else 133
  | 1 => selector s.argument
  | _ => if s.op == Source.Primitive.inc then 151 else 125

def finish (s : Source.Site) (phase : Nat) (endBit : Bool := false) : NF192.KernelBits.Configuration 185 :=
  ⟨some (target s phase), finalHead s phase,
    BitsWord.encode (outputWord s phase ++ [endBit])⟩

abbrev Obligation (i phase : Nat) (endBit : Bool) : Prop :=
  let s := Source.siteAt i
  0 < elapsed i phase ∧ (entry s phase endBit).head < width s ∧
    NF192.KernelBits.run CS185.Table.machine (width s) (elapsed i phase) (entry s phase endBit) =
      some (finish s phase endBit)

def checkOne (i phase : Nat) : Bool :=
  if enabled (Source.siteAt i) phase then decide (Obligation i phase false ∧ Obligation i phase true)
  else elapsed i phase == 0

def checkRange (lo size : Nat) : Bool :=
  (List.range size).all fun j => (List.range 4).all fun phase => checkOne (lo+j) phase

theorem checked_in_range {lo size i phase : Nat} (ok : checkRange lo size = true)
    (lower : lo ≤ i) (upper : i < lo+size) (hp : phase < 4) : checkOne i phase = true := by
  have hj : i-lo < size := by omega
  have h := List.all_eq_true.mp ok (i-lo) (List.mem_range.mpr hj)
  have g := List.all_eq_true.mp h phase (List.mem_range.mpr hp)
  simpa only [show lo+(i-lo) = i by omega] using g

theorem dispatch_of_checked {i phase : Nat} (active : enabled (Source.siteAt i) phase = true)
    (ok : checkOne i phase = true) (anchor : Int) (outside : Tape) (endBit : Bool := false) :
    let s := Source.siteAt i
    TM.run CS185.Table.machine (elapsed i phase) (NF192.KernelBits.embed (width s) anchor outside (entry s phase endBit)) =
      NF192.KernelBits.embed (width s) anchor outside (finish s phase endBit) := by
  have both : Obligation i phase false ∧ Obligation i phase true :=
    of_decide_eq_true (by simpa only [checkOne, active, ite_true] using ok)
  have h : Obligation i phase endBit := by cases endBit <;> first | exact both.1 | exact both.2
  exact (NF192.KernelBits.run_sound CS185.Table.machine _ anchor outside _ _ _ h.2.1 h.2.2).2

end P185.Phase
