module
public import C185PhysicalProtocol
public import Table185
public import Margin185
@[expose] public section
namespace CS185
open NF192 NF210 C185 C185.Physical Eight187.Register
def PhysicalRealization := Realizes Table.machine Table.start 59905 (true,Emitter.liftConfig margin185)
theorem blank_iff_origin (h : PhysicalRealization) :
    TM.Halts Table.machine Table.start ↔ BootstrapHalts (true, Emitter.liftConfig origin) :=
  common_margin_origin advance_steps185 h
end CS185
#print axioms CS185.blank_iff_origin
