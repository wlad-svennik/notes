module
public import MachineSource

@[expose] public section

/-! Complete countdown theorem for every possible value of register 5 and
every assignment of the other registers, with the exact six source locations. -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace NF192.Source

theorem countdown_row_2996 : program 2996 = Command.dec 5 3000 2997 false := by decide
theorem countdown_row_2997 : program 2997 = Command.dec 5 3000 2998 false := by decide
theorem countdown_row_2998 : program 2998 = Command.dec 5 3000 2999 false := by decide
theorem countdown_row_2999 : program 2999 = Command.dec 5 3002 3000 true := by decide
theorem countdown_row_3000 : program 3000 = Command.dec 5 3002 3001 false := by decide
theorem countdown_row_3001 : program 3001 = Command.jump 3000 := by decide

@[simp] theorem setReg_self (rs : Registers) (r v : Nat) :
    setReg rs r v r = v := by simp [setReg]

@[simp] theorem setReg_overwrite (rs : Registers) (r a b : Nat) :
    setReg (setReg rs r a) r b = setReg rs r b := by
  funext i
  by_cases h : i = r <;> simp [setReg, h]

def goalConfig (pc n : Nat) (rs : Registers) : Config :=
  Config.active pc (setReg rs 5 n)

private theorem dec_pos {pc target zero : Nat} {hlt : Bool}
    (instruction : program pc = Command.dec 5 zero target hlt) (n : Nat) (rs : Registers) :
    step (goalConfig pc (n+1) rs) = goalConfig target n rs := by
  simp [step, goalConfig, execute, instruction]

private theorem dec_zero {pc target pos : Nat}
    (instruction : program pc = Command.dec 5 target pos false) (rs : Registers) :
    step (goalConfig pc 0 rs) = goalConfig target 0 rs := by
  simp [step, goalConfig, execute, instruction]

private theorem dec_stop {pc zero pos : Nat}
    (instruction : program pc = Command.dec 5 zero pos true) (rs : Registers) :
    step (goalConfig pc 0 rs) = Config.halted := by
  simp [step, goalConfig, execute, instruction]

private theorem jump_step {pc target : Nat} (instruction : program pc = Command.jump target)
    (n : Nat) (rs : Registers) :
    step (goalConfig pc n rs) = goalConfig target n rs := by
  simp [step, goalConfig, execute, instruction]

/-- Every iteration of the clear loop consumes one unit in exactly two steps. -/
theorem clear_all (n : Nat) (rs : Registers) :
    advance (2*n+1) (goalConfig 3000 n rs) = goalConfig 3002 0 rs := by
  induction n with
  | zero =>
    exact dec_zero countdown_row_3000 rs
  | succ k ih =>
    have ticks : 2*(k+1)+1 = 2 + (2*k+1) := by omega
    rw [ticks, advance_add]
    have iteration : advance 2 (goalConfig 3000 (k+1) rs) = goalConfig 3000 k rs := by
      change step (step (goalConfig 3000 (k+1) rs)) = goalConfig 3000 k rs
      rw [dec_pos countdown_row_3000, jump_step countdown_row_3001]
    rw [iteration]
    exact ih

def countdownDuration : Nat → Nat
  | 0 => 2
  | 1 => 3
  | 2 => 4
  | 3 => 4
  | k+4 => 4 + (2*k+1)

/-- At the exact source goal entry the machine halts iff the input is 3;
every other value reaches the first subsequent instruction with R5 cleared. -/
theorem countdown_correct (n : Nat) (rs : Registers) :
    advance (countdownDuration n) (goalConfig 2996 n rs) =
    (if n = 3 then Config.halted else goalConfig 3002 0 rs) := by
  cases n with
  | zero =>
    change step (step (goalConfig 2996 0 rs)) = goalConfig 3002 0 rs
    rw [dec_zero countdown_row_2996, dec_zero countdown_row_3000]
  | succ n =>
    cases n with
    | zero =>
      change step (step (step (goalConfig 2996 1 rs))) = goalConfig 3002 0 rs
      rw [dec_pos countdown_row_2996, dec_zero countdown_row_2997, dec_zero countdown_row_3000]
    | succ n =>
      cases n with
      | zero =>
        change step (step (step (step (goalConfig 2996 2 rs)))) = goalConfig 3002 0 rs
        rw [dec_pos countdown_row_2996, dec_pos countdown_row_2997,
          dec_zero countdown_row_2998, dec_zero countdown_row_3000]
      | succ n =>
        cases n with
        | zero =>
          change step (step (step (step (goalConfig 2996 3 rs)))) = Config.halted
          rw [dec_pos countdown_row_2996, dec_pos countdown_row_2997,
            dec_pos countdown_row_2998, dec_stop countdown_row_2999]
        | succ k =>
          have neq : k.succ.succ.succ.succ ≠ 3 := by omega
          rw [ite_eq_right neq]
          change advance (4+(2*k+1)) (goalConfig 2996 (k+4) rs) = goalConfig 3002 0 rs
          rw [advance_add 4 (2*k+1)]
          have first : advance 4 (goalConfig 2996 (k+4) rs) = goalConfig 3000 k rs := by
            change step (step (step (step (goalConfig 2996 (k+4) rs)))) = goalConfig 3000 k rs
            rw [dec_pos countdown_row_2996, dec_pos countdown_row_2997,
              dec_pos countdown_row_2998, dec_pos countdown_row_2999]
          rw [first, clear_all]

theorem countdown_halts_iff (n : Nat) (rs : Registers) :
    advance (countdownDuration n) (goalConfig 2996 n rs) = Config.halted ↔ n = 3 := by
  rw [countdown_correct]
  by_cases h : n = 3 <;> simp [h, goalConfig]

#print axioms countdown_correct
#print axioms countdown_halts_iff

end NF192.Source
