module
public import Table185

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-!
# An unbounded unary-file transformation of the literal kernel

This proves section 4.1 of the recovered arithmetic-kernel proof directly
against the frozen selected 185-state transition table. The initial unary run and
the number and values of subsequent registers are arbitrary natural numbers.
Every theorem quantifies over an arbitrary surrounding two-way tape.

Starting in `k:0` on

  `1^u (0 1^(v₁+1)) ... (0 1^(vₜ+1)) 0 0`,

the machine reaches `k:66`, immediately to the right of that word, with

  `1^(u+1) (0 1^(v₁+1)) ... (0 1^(vₜ+1)) 0`.

It takes exactly as many transitions as the input word has cells. This is
an induction over the run length and register list, not finite sampling.
-/

namespace P185.KernelRightShift

open NF210 NF210.TM
open CS185.Table (State machine)

def shiftState : State := ⟨125, by decide⟩
def pairState : State := ⟨156, by decide⟩
def endState : State := ⟨152, by decide⟩

theorem shiftState_name : CS185.Table.name shiftState = "k:0" := by decide
theorem pairState_name : CS185.Table.name pairState = "k:94" := by decide
theorem endState_name : CS185.Table.name endState = "k:66" := by decide

/-- Replace a finite word, preserving the given tape at every other cell. -/
def wordTape (anchor : Int) : List Bool → Tape → Tape
  | [], outside => outside
  | symbol :: rest, outside =>
    writeTape (wordTape (anchor + 1) rest outside) anchor symbol

@[simp] theorem wordTape_nil (anchor : Int) (outside : Tape) :
    wordTape anchor [] outside = outside := rfl

@[simp] theorem wordTape_cons (anchor : Int) (symbol : Bool)
    (rest : List Bool) (outside : Tape) :
    wordTape anchor (symbol :: rest) outside =
      writeTape (wordTape (anchor + 1) rest outside) anchor symbol := rfl

theorem writeTape_overwrite (tape : Tape) (position : Int) (first second : Bool) :
    writeTape (writeTape tape position first) position second =
      writeTape tape position second := by
  funext p
  by_cases same : p = position <;> simp [writeTape, same]

theorem writeTape_commute (tape : Tape) (p q : Int) (x y : Bool)
    (different : p ≠ q) :
    writeTape (writeTape tape q y) p x =
      writeTape (writeTape tape p x) q y := by
  funext position
  by_cases at_p : position = p
  · subst position
    simp [writeTape, different]
  · by_cases at_q : position = q
    · subst position
      simp [writeTape, Ne.symm different]
    · simp [writeTape, at_p, at_q]

theorem writeTape_before_word (anchor position : Int) (word : List Bool)
    (outside : Tape) (symbol : Bool) (before : position < anchor) :
    writeTape (wordTape anchor word outside) position symbol =
      wordTape anchor word (writeTape outside position symbol) := by
  induction word generalizing anchor with
  | nil => rfl
  | cons first rest ih =>
    simp only [wordTape_cons]
    rw [writeTape_commute _ position anchor symbol first (by omega)]
    rw [ih (anchor + 1) (by omega)]

theorem wordTape_append (anchor : Int) (front suffix : List Bool) (outside : Tape) :
    wordTape anchor (front ++ suffix) outside =
      wordTape anchor front
        (wordTape (anchor + (front.length : Int)) suffix outside) := by
  induction front generalizing anchor with
  | nil => simp
  | cons first rest ih =>
    simp only [List.cons_append, wordTape_cons, List.length_cons]
    rw [ih]
    have positions : anchor + 1 + (rest.length : Int) =
        anchor + ((rest.length + 1 : Nat) : Int) := by omega
    rw [positions]

theorem wordTape_commute (left right : Int) (front suffix : List Bool)
    (outside : Tape) (separate : left + (front.length : Int) ≤ right) :
    wordTape left front (wordTape right suffix outside) =
      wordTape right suffix (wordTape left front outside) := by
  induction front generalizing left with
  | nil => simp
  | cons first rest ih =>
    simp only [wordTape_cons]
    rw [ih (left + 1) (by simp only [List.length_cons] at separate; omega)]
    exact writeTape_before_word right left suffix
      (wordTape (left + 1) rest outside) first
      (by simp only [List.length_cons] at separate; omega)

/-- Precise preservation of every cell outside the displayed word. -/
theorem wordTape_outside (anchor position : Int) (word : List Bool) (outside : Tape)
    (away : position < anchor ∨ anchor + (word.length : Int) ≤ position) :
    wordTape anchor word outside position = outside position := by
  induction word generalizing anchor with
  | nil => rfl
  | cons first rest ih =>
    simp only [List.length_cons] at away
    have different : position ≠ anchor := by omega
    simp only [wordTape_cons, writeTape_away _ _ _ _ different]
    apply ih
    omega

def configuration (state : State) (head : Int) (tape : Tape) : TM.Configuration 185 :=
  { state := some state, head := head, tape := tape }

/-- An exact finite-word transformation valid in arbitrary surroundings. -/
structure RightRun (first last : State) (input output : List Bool) : Prop where
  same_length : input.length = output.length
  exact_run : ∀ (anchor : Int) (outside : Tape),
    TM.run machine input.length (configuration first anchor (wordTape anchor input outside)) =
      configuration last (anchor + (input.length : Int)) (wordTape anchor output outside)

theorem RightRun.nil (state : State) : RightRun state state [] [] := by
  constructor
  · rfl
  · intros; simp

/-- Composition preserves the exact tape effect, including both outside regions. -/
theorem RightRun.trans {first middle last : State}
    {input₁ output₁ input₂ output₂ : List Bool}
    (one : RightRun first middle input₁ output₁)
    (two : RightRun middle last input₂ output₂) :
    RightRun first last (input₁ ++ input₂) (output₁ ++ output₂) := by
  constructor
  · simp only [List.length_append, one.same_length, two.same_length]
  · intro anchor outside
    rw [List.length_append, TM.run_add, wordTape_append]
    rw [one.exact_run]
    rw [wordTape_commute anchor (anchor + (input₁.length : Int)) output₁ input₂ outside
      (by rw [one.same_length]; exact Int.le_refl _)]
    rw [two.exact_run]
    rw [← wordTape_commute anchor (anchor + (input₁.length : Int)) output₁ output₂ outside
      (by rw [one.same_length]; exact Int.le_refl _)]
    have positions : anchor + (input₁.length : Int) + (input₂.length : Int) =
        anchor + ((input₁.length + input₂.length : Nat) : Int) := by omega
    rw [positions]
    rw [wordTape_append, ← one.same_length]

/-- A literal right-moving transition yields a universal one-cell certificate. -/
theorem RightRun.one {first last : State} {read write : Bool}
    (row : machine first read = ⟨write, .right, some last⟩) :
    RightRun first last [read] [write] := by
  constructor
  · rfl
  · intro anchor outside
    simp only [List.length_singleton, TM.run_succ, TM.run_zero, TM.step,
      configuration, wordTape_cons, wordTape_nil, writeTape_at, row,
      moveHead, writeTape_overwrite]
    rfl

theorem scan_one : RightRun shiftState shiftState [true] [true] :=
  RightRun.one (by decide)

theorem shift_zero_one : RightRun shiftState shiftState [false, true] [true, false] := by
  have first : RightRun shiftState pairState [false] [true] :=
    RightRun.one (by decide)
  have second : RightRun pairState shiftState [true] [false] :=
    RightRun.one (by decide)
  exact first.trans second

theorem shift_zero_zero : RightRun shiftState endState [false, false] [true, false] := by
  have first : RightRun shiftState pairState [false] [true] :=
    RightRun.one (by decide)
  have second : RightRun pairState endState [false] [false] :=
    RightRun.one (by decide)
  exact first.trans second

/-- The unary scan is proved for every natural run length. -/
theorem scan_ones (count : Nat) :
    RightRun shiftState shiftState (List.replicate count true) (List.replicate count true) := by
  induction count with
  | zero => exact RightRun.nil shiftState
  | succ count ih => exact scan_one.trans ih

/-- Physical register blocks have a zero separator and value-plus-one ones. -/
def blocks : List Nat → List Bool
  | [] => []
  | value :: rest => false :: (List.replicate (value + 1) true ++ blocks rest)

def shiftInput (initialRun : Nat) (values : List Nat) : List Bool :=
  List.replicate initialRun true ++ blocks values ++ [false, false]

def shiftOutput (initialRun : Nat) (values : List Nat) : List Bool :=
  List.replicate (initialRun + 1) true ++ blocks values ++ [false]

/-- Exact unbounded right shift, including zero-valued registers. -/
theorem right_shift (initialRun : Nat) (values : List Nat) :
    RightRun shiftState endState (shiftInput initialRun values) (shiftOutput initialRun values) := by
  induction values generalizing initialRun with
  | nil =>
    have certificate := (scan_ones initialRun).trans shift_zero_zero
    simpa [shiftInput, shiftOutput, blocks, List.replicate_succ', List.append_assoc]
      using certificate
  | cons value rest ih =>
    have tail := shift_zero_one.trans (ih value)
    have certificate := (scan_ones initialRun).trans tail
    simpa only [shiftInput, shiftOutput, blocks, List.replicate_succ' (n := initialRun),
      List.replicate_succ (n := value), List.append_assoc, List.cons_append, List.nil_append]
      using certificate

/-- Explicit ordinary-TM statement with every length and every surrounding tape free. -/
theorem right_shift_exact (initialRun : Nat) (values : List Nat)
    (anchor : Int) (outside : Tape) :
    TM.run machine (shiftInput initialRun values).length
      (configuration shiftState anchor (wordTape anchor (shiftInput initialRun values) outside)) =
    configuration endState (anchor + ((shiftInput initialRun values).length : Int))
      (wordTape anchor (shiftOutput initialRun values) outside) :=
  (right_shift initialRun values).exact_run anchor outside

#print axioms right_shift_exact

end P185.KernelRightShift
