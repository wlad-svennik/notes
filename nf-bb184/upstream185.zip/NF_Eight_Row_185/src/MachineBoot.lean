module
public import MachineBits
public import MachineTable

@[expose] public section

/-! The literal blank-tape computation, in the original NF210 integer-tape
semantics. Each intermediate bit mask is only a proposed certificate.
The Lean kernel checks every transition against NF192.Selected.machine. -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace NF192.Boot
open NF210 NF192.Selected
abbrev width : Nat := 131
abbrev Prefix (duration : Nat) (first last : KernelBits.Configuration 192) : Prop :=
  ∀ (anchor : Int) (outside : TM.Tape),
    TM.run machine duration (KernelBits.embed width anchor outside first) =
      KernelBits.embed width anchor outside last

theorem checked (duration : Nat) (first last : KernelBits.Configuration 192)
    (hi : first.head < width) (h : KernelBits.run machine width duration first = some last) :
    Prefix duration first last := fun a t =>
  (KernelBits.run_sound machine width a t duration first last hi h).2

theorem compose {s t : Nat} {a b c : KernelBits.Configuration 192}
    (first : Prefix s a b) (second : Prefix t b c) : Prefix (s+t) a c := by
  intro anchor outside
  rw [TM.run_add, first anchor outside, second anchor outside]

def snap0 : KernelBits.Configuration 192 := ⟨some (185 : State), 10, 0⟩
def snap500 : KernelBits.Configuration 192 := ⟨some (158 : State), 18, 18979254528⟩
def snap1000 : KernelBits.Configuration 192 := ⟨some (117 : State), 14, 785282887936⟩
def snap1500 : KernelBits.Configuration 192 := ⟨some (160 : State), 22, 102725647986944⟩
def snap2000 : KernelBits.Configuration 192 := ⟨some (166 : State), 2, 3011404977991936⟩
def snap2500 : KernelBits.Configuration 192 := ⟨some (178 : State), 18, 25602912956772608⟩
def snap3000 : KernelBits.Configuration 192 := ⟨some (159 : State), 32, 190828723144782080⟩
def snap3500 : KernelBits.Configuration 192 := ⟨some (164 : State), 18, 195314734881188096⟩
def snap4000 : KernelBits.Configuration 192 := ⟨some (164 : State), 12, 1646043049995970816⟩
def snap4500 : KernelBits.Configuration 192 := ⟨some (164 : State), 36, 1646007861060184320⟩
def snap5000 : KernelBits.Configuration 192 := ⟨some (183 : State), 18, 12515480746090670336⟩
def snap5500 : KernelBits.Configuration 192 := ⟨some (169 : State), 30, 12227227751567042816⟩
def snap6000 : KernelBits.Configuration 192 := ⟨some (51 : State), 26, 98984525734409906432⟩
def snap6500 : KernelBits.Configuration 192 := ⟨some (166 : State), 2, 788431585491384379648⟩
def snap7000 : KernelBits.Configuration 192 := ⟨some (176 : State), 70, 6299396287038625130752⟩
def snap7500 : KernelBits.Configuration 192 := ⟨some (173 : State), 20, 6299396106083065637120⟩
def snap8000 : KernelBits.Configuration 192 := ⟨some (172 : State), 34, 50377891070220627978496⟩
def snap8500 : KernelBits.Configuration 192 := ⟨some (176 : State), 68, 402987403677284761315584⟩
def snap9000 : KernelBits.Configuration 192 := ⟨some (164 : State), 14, 402987403677267583330560⟩
def snap9500 : KernelBits.Configuration 192 := ⟨some (164 : State), 26, 402987402551384856303872⟩
def snap10000 : KernelBits.Configuration 192 := ⟨some (181 : State), 30, 402987236320310661711104⟩
def snap10500 : KernelBits.Configuration 192 := ⟨some (50 : State), 24, 3223826112191521217328384⟩
def snap11000 : KernelBits.Configuration 192 := ⟨some (9 : State), 14, 3223825443085266288907520⟩
def snap11500 : KernelBits.Configuration 192 := ⟨some (164 : State), 22, 25790464000648088553252096⟩
def snap12000 : KernelBits.Configuration 192 := ⟨some (180 : State), 48, 25790461324866558153954560⟩
def snap12500 : KernelBits.Configuration 192 := ⟨some (164 : State), 56, 206323409114948280443192576⟩
def snap13000 : KernelBits.Configuration 192 := ⟨some (185 : State), 20, 206323416855349336410625280⟩
def snap13500 : KernelBits.Configuration 192 := ⟨some (188 : State), 8, 1650586799220683259101824256⟩
def snap14000 : KernelBits.Configuration 192 := ⟨some (190 : State), 70, 1650587334894263930093245696⟩
def snap14500 : KernelBits.Configuration 192 := ⟨some (159 : State), 40, 13204693679546034410661840128⟩
def snap15000 : KernelBits.Configuration 192 := ⟨some (50 : State), 34, 13204693974693939074618633472⟩
def snap15500 : KernelBits.Configuration 192 := ⟨some (189 : State), 4, 13204693974693939040258891008⟩
def snap16000 : KernelBits.Configuration 192 := ⟨some (173 : State), 16, 13204693974693939040258945792⟩
def snap16500 : KernelBits.Configuration 192 := ⟨some (171 : State), 24, 13204693974688792776085015296⟩
def snap16813 : KernelBits.Configuration 192 := ⟨some (13 : State), 9, 13204693974678496949202602752⟩
def snap17000 : KernelBits.Configuration 192 := ⟨some (159 : State), 42, 13204693974678428779477486336⟩
def snap17500 : KernelBits.Configuration 192 := ⟨some (50 : State), 32, 13204693974678496957792668416⟩
def snap18000 : KernelBits.Configuration 192 := ⟨some (164 : State), 8, 13204693974678496949203782400⟩
def snap18500 : KernelBits.Configuration 192 := ⟨some (188 : State), 8, 13204693974678490351882357504⟩
def snap19000 : KernelBits.Configuration 192 := ⟨some (87 : State), 12, 13204693974678496949388331776⟩
def snap19500 : KernelBits.Configuration 192 := ⟨some (84 : State), 10, 13204693974678499148076043008⟩
def snap20000 : KernelBits.Configuration 192 := ⟨some (188 : State), 4, 13204693974642470351082244864⟩
def snap20500 : KernelBits.Configuration 192 := ⟨some (176 : State), 90, 105637550634830179323618675456⟩
def snap21000 : KernelBits.Configuration 192 := ⟨some (181 : State), 32, 845100401383775701510403541760⟩
def snap21500 : KernelBits.Configuration 192 := ⟨some (50 : State), 28, 845100401383693985807770733312⟩
def snap22000 : KernelBits.Configuration 192 := ⟨some (50 : State), 26, 6760803204022886687081931885312⟩
def snap22500 : KernelBits.Configuration 192 := ⟨some (91 : State), 16, 54086425615349115515083796138752⟩
def snap23000 : KernelBits.Configuration 192 := ⟨some (164 : State), 32, 54086425615349115523879603948288⟩
def snap23500 : KernelBits.Configuration 192 := ⟨some (91 : State), 16, 54086425614663954606740351372032⟩
def snap24000 : KernelBits.Configuration 192 := ⟨some (164 : State), 36, 432691404887755287083442335009536⟩
def snap24500 : KernelBits.Configuration 192 := ⟨some (189 : State), 4, 432691404885015294501690929203968⟩
def snap25000 : KernelBits.Configuration 192 := ⟨some (2 : State), 26, 3461531239037445705407056833563392⟩
def snap25500 : KernelBits.Configuration 192 := ⟨some (173 : State), 38, 3461531239037445705407331623389952⟩
def snap26000 : KernelBits.Configuration 192 := ⟨some (171 : State), 58, 3461531239037445700305322624830208⟩
def snap26500 : KernelBits.Configuration 192 := ⟨some (164 : State), 40, 27692249912225160588022943770102528⟩
def snap27000 : KernelBits.Configuration 192 := ⟨some (171 : State), 60, 27692249912225160577749106952391424⟩
def snap27500 : KernelBits.Configuration 192 := ⟨some (173 : State), 44, 221537999297575763951915100991015680⟩
def snap28000 : KernelBits.Configuration 192 := ⟨some (180 : State), 38, 221537999297575763952038246108777216⟩
def snap28500 : KernelBits.Configuration 192 := ⟨some (159 : State), 42, 221537999297575763916009447244319488⟩
def snap29000 : KernelBits.Configuration 192 := ⟨some (176 : State), 48, 221537999297564805268474094941260544⟩
def snap29500 : KernelBits.Configuration 192 := ⟨some (176 : State), 100, 1772303994380045559862900272749759232⟩
def snap30000 : KernelBits.Configuration 192 := ⟨some (159 : State), 72, 1772303994379968744985408606695475968⟩
def snap30500 : KernelBits.Configuration 192 := ⟨some (181 : State), 116, 14178431955039330586414224564481575680⟩
def snap31000 : KernelBits.Configuration 192 := ⟨some (164 : State), 8, 14178431955039028354959320930810219264⟩
def snap31500 : KernelBits.Configuration 192 := ⟨some (169 : State), 20, 14178431955039330586270109406067837696⟩
def snap32000 : KernelBits.Configuration 192 := ⟨some (185 : State), 34, 14178431955039329996036223539285740288⟩
def snap32500 : KernelBits.Configuration 192 := ⟨some (169 : State), 62, 113427455640312672881286492451058633472⟩
def snap33000 : KernelBits.Configuration 192 := ⟨some (173 : State), 38, 907419645122503831375949001237145471744⟩
def snap33500 : KernelBits.Configuration 192 := ⟨some (84 : State), 10, 907419645122503831375950126862308625152⟩
def snap33911 : KernelBits.Configuration 192 := ⟨some (13 : State), 9, 907419645122503481615139562602340961024⟩
theorem chunk500 : Prefix 500 snap0 snap500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk1000 : Prefix 500 snap500 snap1000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk1500 : Prefix 500 snap1000 snap1500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk2000 : Prefix 500 snap1500 snap2000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk2500 : Prefix 500 snap2000 snap2500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk3000 : Prefix 500 snap2500 snap3000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk3500 : Prefix 500 snap3000 snap3500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk4000 : Prefix 500 snap3500 snap4000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk4500 : Prefix 500 snap4000 snap4500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk5000 : Prefix 500 snap4500 snap5000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk5500 : Prefix 500 snap5000 snap5500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk6000 : Prefix 500 snap5500 snap6000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk6500 : Prefix 500 snap6000 snap6500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk7000 : Prefix 500 snap6500 snap7000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk7500 : Prefix 500 snap7000 snap7500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk8000 : Prefix 500 snap7500 snap8000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk8500 : Prefix 500 snap8000 snap8500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk9000 : Prefix 500 snap8500 snap9000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk9500 : Prefix 500 snap9000 snap9500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk10000 : Prefix 500 snap9500 snap10000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk10500 : Prefix 500 snap10000 snap10500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk11000 : Prefix 500 snap10500 snap11000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk11500 : Prefix 500 snap11000 snap11500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk12000 : Prefix 500 snap11500 snap12000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk12500 : Prefix 500 snap12000 snap12500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk13000 : Prefix 500 snap12500 snap13000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk13500 : Prefix 500 snap13000 snap13500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk14000 : Prefix 500 snap13500 snap14000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk14500 : Prefix 500 snap14000 snap14500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk15000 : Prefix 500 snap14500 snap15000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk15500 : Prefix 500 snap15000 snap15500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk16000 : Prefix 500 snap15500 snap16000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk16500 : Prefix 500 snap16000 snap16500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk16813 : Prefix 313 snap16500 snap16813 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk17000 : Prefix 187 snap16813 snap17000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk17500 : Prefix 500 snap17000 snap17500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk18000 : Prefix 500 snap17500 snap18000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk18500 : Prefix 500 snap18000 snap18500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk19000 : Prefix 500 snap18500 snap19000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk19500 : Prefix 500 snap19000 snap19500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk20000 : Prefix 500 snap19500 snap20000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk20500 : Prefix 500 snap20000 snap20500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk21000 : Prefix 500 snap20500 snap21000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk21500 : Prefix 500 snap21000 snap21500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk22000 : Prefix 500 snap21500 snap22000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk22500 : Prefix 500 snap22000 snap22500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk23000 : Prefix 500 snap22500 snap23000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk23500 : Prefix 500 snap23000 snap23500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk24000 : Prefix 500 snap23500 snap24000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk24500 : Prefix 500 snap24000 snap24500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk25000 : Prefix 500 snap24500 snap25000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk25500 : Prefix 500 snap25000 snap25500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk26000 : Prefix 500 snap25500 snap26000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk26500 : Prefix 500 snap26000 snap26500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk27000 : Prefix 500 snap26500 snap27000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk27500 : Prefix 500 snap27000 snap27500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk28000 : Prefix 500 snap27500 snap28000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk28500 : Prefix 500 snap28000 snap28500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk29000 : Prefix 500 snap28500 snap29000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk29500 : Prefix 500 snap29000 snap29500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk30000 : Prefix 500 snap29500 snap30000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk30500 : Prefix 500 snap30000 snap30500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk31000 : Prefix 500 snap30500 snap31000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk31500 : Prefix 500 snap31000 snap31500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk32000 : Prefix 500 snap31500 snap32000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk32500 : Prefix 500 snap32000 snap32500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk33000 : Prefix 500 snap32500 snap33000 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk33500 : Prefix 500 snap33000 snap33500 :=
  checked _ _ _ (by decide) (by decide)
theorem chunk33911 : Prefix 411 snap33500 snap33911 :=
  checked _ _ _ (by decide) (by decide)
theorem assembled1000 : Prefix 1000 snap0 snap1000 :=
  @compose 500 500 snap0 snap500 snap1000 chunk500 chunk1000
theorem assembled1500 : Prefix 1500 snap0 snap1500 :=
  @compose 1000 500 snap0 snap1000 snap1500 assembled1000 chunk1500
theorem assembled2000 : Prefix 2000 snap0 snap2000 :=
  @compose 1500 500 snap0 snap1500 snap2000 assembled1500 chunk2000
theorem assembled2500 : Prefix 2500 snap0 snap2500 :=
  @compose 2000 500 snap0 snap2000 snap2500 assembled2000 chunk2500
theorem assembled3000 : Prefix 3000 snap0 snap3000 :=
  @compose 2500 500 snap0 snap2500 snap3000 assembled2500 chunk3000
theorem assembled3500 : Prefix 3500 snap0 snap3500 :=
  @compose 3000 500 snap0 snap3000 snap3500 assembled3000 chunk3500
theorem assembled4000 : Prefix 4000 snap0 snap4000 :=
  @compose 3500 500 snap0 snap3500 snap4000 assembled3500 chunk4000
theorem assembled4500 : Prefix 4500 snap0 snap4500 :=
  @compose 4000 500 snap0 snap4000 snap4500 assembled4000 chunk4500
theorem assembled5000 : Prefix 5000 snap0 snap5000 :=
  @compose 4500 500 snap0 snap4500 snap5000 assembled4500 chunk5000
theorem assembled5500 : Prefix 5500 snap0 snap5500 :=
  @compose 5000 500 snap0 snap5000 snap5500 assembled5000 chunk5500
theorem assembled6000 : Prefix 6000 snap0 snap6000 :=
  @compose 5500 500 snap0 snap5500 snap6000 assembled5500 chunk6000
theorem assembled6500 : Prefix 6500 snap0 snap6500 :=
  @compose 6000 500 snap0 snap6000 snap6500 assembled6000 chunk6500
theorem assembled7000 : Prefix 7000 snap0 snap7000 :=
  @compose 6500 500 snap0 snap6500 snap7000 assembled6500 chunk7000
theorem assembled7500 : Prefix 7500 snap0 snap7500 :=
  @compose 7000 500 snap0 snap7000 snap7500 assembled7000 chunk7500
theorem assembled8000 : Prefix 8000 snap0 snap8000 :=
  @compose 7500 500 snap0 snap7500 snap8000 assembled7500 chunk8000
theorem assembled8500 : Prefix 8500 snap0 snap8500 :=
  @compose 8000 500 snap0 snap8000 snap8500 assembled8000 chunk8500
theorem assembled9000 : Prefix 9000 snap0 snap9000 :=
  @compose 8500 500 snap0 snap8500 snap9000 assembled8500 chunk9000
theorem assembled9500 : Prefix 9500 snap0 snap9500 :=
  @compose 9000 500 snap0 snap9000 snap9500 assembled9000 chunk9500
theorem assembled10000 : Prefix 10000 snap0 snap10000 :=
  @compose 9500 500 snap0 snap9500 snap10000 assembled9500 chunk10000
theorem assembled10500 : Prefix 10500 snap0 snap10500 :=
  @compose 10000 500 snap0 snap10000 snap10500 assembled10000 chunk10500
theorem assembled11000 : Prefix 11000 snap0 snap11000 :=
  @compose 10500 500 snap0 snap10500 snap11000 assembled10500 chunk11000
theorem assembled11500 : Prefix 11500 snap0 snap11500 :=
  @compose 11000 500 snap0 snap11000 snap11500 assembled11000 chunk11500
theorem assembled12000 : Prefix 12000 snap0 snap12000 :=
  @compose 11500 500 snap0 snap11500 snap12000 assembled11500 chunk12000
theorem assembled12500 : Prefix 12500 snap0 snap12500 :=
  @compose 12000 500 snap0 snap12000 snap12500 assembled12000 chunk12500
theorem assembled13000 : Prefix 13000 snap0 snap13000 :=
  @compose 12500 500 snap0 snap12500 snap13000 assembled12500 chunk13000
theorem assembled13500 : Prefix 13500 snap0 snap13500 :=
  @compose 13000 500 snap0 snap13000 snap13500 assembled13000 chunk13500
theorem assembled14000 : Prefix 14000 snap0 snap14000 :=
  @compose 13500 500 snap0 snap13500 snap14000 assembled13500 chunk14000
theorem assembled14500 : Prefix 14500 snap0 snap14500 :=
  @compose 14000 500 snap0 snap14000 snap14500 assembled14000 chunk14500
theorem assembled15000 : Prefix 15000 snap0 snap15000 :=
  @compose 14500 500 snap0 snap14500 snap15000 assembled14500 chunk15000
theorem assembled15500 : Prefix 15500 snap0 snap15500 :=
  @compose 15000 500 snap0 snap15000 snap15500 assembled15000 chunk15500
theorem assembled16000 : Prefix 16000 snap0 snap16000 :=
  @compose 15500 500 snap0 snap15500 snap16000 assembled15500 chunk16000
theorem assembled16500 : Prefix 16500 snap0 snap16500 :=
  @compose 16000 500 snap0 snap16000 snap16500 assembled16000 chunk16500
theorem assembled16813 : Prefix 16813 snap0 snap16813 :=
  @compose 16500 313 snap0 snap16500 snap16813 assembled16500 chunk16813
theorem part16813 : Prefix 16813 snap0 snap16813 := assembled16813
theorem assembled17500 : Prefix 687 snap16813 snap17500 :=
  @compose 187 500 snap16813 snap17000 snap17500 chunk17000 chunk17500
theorem assembled18000 : Prefix 1187 snap16813 snap18000 :=
  @compose 687 500 snap16813 snap17500 snap18000 assembled17500 chunk18000
theorem assembled18500 : Prefix 1687 snap16813 snap18500 :=
  @compose 1187 500 snap16813 snap18000 snap18500 assembled18000 chunk18500
theorem assembled19000 : Prefix 2187 snap16813 snap19000 :=
  @compose 1687 500 snap16813 snap18500 snap19000 assembled18500 chunk19000
theorem assembled19500 : Prefix 2687 snap16813 snap19500 :=
  @compose 2187 500 snap16813 snap19000 snap19500 assembled19000 chunk19500
theorem assembled20000 : Prefix 3187 snap16813 snap20000 :=
  @compose 2687 500 snap16813 snap19500 snap20000 assembled19500 chunk20000
theorem assembled20500 : Prefix 3687 snap16813 snap20500 :=
  @compose 3187 500 snap16813 snap20000 snap20500 assembled20000 chunk20500
theorem assembled21000 : Prefix 4187 snap16813 snap21000 :=
  @compose 3687 500 snap16813 snap20500 snap21000 assembled20500 chunk21000
theorem assembled21500 : Prefix 4687 snap16813 snap21500 :=
  @compose 4187 500 snap16813 snap21000 snap21500 assembled21000 chunk21500
theorem assembled22000 : Prefix 5187 snap16813 snap22000 :=
  @compose 4687 500 snap16813 snap21500 snap22000 assembled21500 chunk22000
theorem assembled22500 : Prefix 5687 snap16813 snap22500 :=
  @compose 5187 500 snap16813 snap22000 snap22500 assembled22000 chunk22500
theorem assembled23000 : Prefix 6187 snap16813 snap23000 :=
  @compose 5687 500 snap16813 snap22500 snap23000 assembled22500 chunk23000
theorem assembled23500 : Prefix 6687 snap16813 snap23500 :=
  @compose 6187 500 snap16813 snap23000 snap23500 assembled23000 chunk23500
theorem assembled24000 : Prefix 7187 snap16813 snap24000 :=
  @compose 6687 500 snap16813 snap23500 snap24000 assembled23500 chunk24000
theorem assembled24500 : Prefix 7687 snap16813 snap24500 :=
  @compose 7187 500 snap16813 snap24000 snap24500 assembled24000 chunk24500
theorem assembled25000 : Prefix 8187 snap16813 snap25000 :=
  @compose 7687 500 snap16813 snap24500 snap25000 assembled24500 chunk25000
theorem assembled25500 : Prefix 8687 snap16813 snap25500 :=
  @compose 8187 500 snap16813 snap25000 snap25500 assembled25000 chunk25500
theorem assembled26000 : Prefix 9187 snap16813 snap26000 :=
  @compose 8687 500 snap16813 snap25500 snap26000 assembled25500 chunk26000
theorem assembled26500 : Prefix 9687 snap16813 snap26500 :=
  @compose 9187 500 snap16813 snap26000 snap26500 assembled26000 chunk26500
theorem assembled27000 : Prefix 10187 snap16813 snap27000 :=
  @compose 9687 500 snap16813 snap26500 snap27000 assembled26500 chunk27000
theorem assembled27500 : Prefix 10687 snap16813 snap27500 :=
  @compose 10187 500 snap16813 snap27000 snap27500 assembled27000 chunk27500
theorem assembled28000 : Prefix 11187 snap16813 snap28000 :=
  @compose 10687 500 snap16813 snap27500 snap28000 assembled27500 chunk28000
theorem assembled28500 : Prefix 11687 snap16813 snap28500 :=
  @compose 11187 500 snap16813 snap28000 snap28500 assembled28000 chunk28500
theorem assembled29000 : Prefix 12187 snap16813 snap29000 :=
  @compose 11687 500 snap16813 snap28500 snap29000 assembled28500 chunk29000
theorem assembled29500 : Prefix 12687 snap16813 snap29500 :=
  @compose 12187 500 snap16813 snap29000 snap29500 assembled29000 chunk29500
theorem assembled30000 : Prefix 13187 snap16813 snap30000 :=
  @compose 12687 500 snap16813 snap29500 snap30000 assembled29500 chunk30000
theorem assembled30500 : Prefix 13687 snap16813 snap30500 :=
  @compose 13187 500 snap16813 snap30000 snap30500 assembled30000 chunk30500
theorem assembled31000 : Prefix 14187 snap16813 snap31000 :=
  @compose 13687 500 snap16813 snap30500 snap31000 assembled30500 chunk31000
theorem assembled31500 : Prefix 14687 snap16813 snap31500 :=
  @compose 14187 500 snap16813 snap31000 snap31500 assembled31000 chunk31500
theorem assembled32000 : Prefix 15187 snap16813 snap32000 :=
  @compose 14687 500 snap16813 snap31500 snap32000 assembled31500 chunk32000
theorem assembled32500 : Prefix 15687 snap16813 snap32500 :=
  @compose 15187 500 snap16813 snap32000 snap32500 assembled32000 chunk32500
theorem assembled33000 : Prefix 16187 snap16813 snap33000 :=
  @compose 15687 500 snap16813 snap32500 snap33000 assembled32500 chunk33000
theorem assembled33500 : Prefix 16687 snap16813 snap33500 :=
  @compose 16187 500 snap16813 snap33000 snap33500 assembled33000 chunk33500
theorem assembled33911 : Prefix 17098 snap16813 snap33911 :=
  @compose 16687 411 snap16813 snap33500 snap33911 assembled33500 chunk33911
theorem part33911 : Prefix 17098 snap16813 snap33911 := assembled33911

theorem embed_start : KernelBits.embed width (-10) (fun _ => false) snap0 = TM.blank start := by
  show TM.Configuration.mk _ _ _ = TM.Configuration.mk _ _ _
  congr 1
  funext p
  simp [KernelBits.tape, snap0]

theorem blank_first_axiom : TM.run machine 16813 (TM.blank start) =
    KernelBits.embed width (-10) (fun _ => false) snap16813 := by
  rw [← embed_start]
  exact part16813 _ _

theorem blank_decoder_margin : TM.run machine 33911 (TM.blank start) =
    KernelBits.embed width (-10) (fun _ => false) snap33911 := by
  rw [← embed_start]
  exact compose part16813 part33911 _ _

theorem blank_lives_through (time : Nat) (h : time ≤ 33911) :
    (TM.run machine time (TM.blank start)).state ≠ none := by
  intro halted
  have stopped := TM.halting_persists machine start time (33911-time) halted
  have restore : time + (33911-time) = 33911 := by omega
  rw [restore, blank_decoder_margin] at stopped
  simp [KernelBits.embed, snap33911] at stopped

#print axioms blank_first_axiom
#print axioms blank_decoder_margin
#print axioms blank_lives_through

end NF192.Boot
