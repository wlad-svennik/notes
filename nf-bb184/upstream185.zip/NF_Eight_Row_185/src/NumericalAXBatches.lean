module
public import NumericalOuter
public import ProofCommands

@[expose] public section

/-! Iterating the real emitter clears the parameter and cache between batches,
decreases register 3, and reaches the automatic NIP with exactly the proof stack
described by ProofSearch.rows. -/

set_option maxHeartbeats 0
set_option maxRecDepth 50000

namespace NF192.Emitter

open Numerical SourceFields ProofSearch

def frameWith (n : Nat) (ts : Nat × Nat) (c a b p : Nat) : Frame :=
  ⟨n,ts.1,ts.2,c,a,b,p⟩

def pushPair (ts : Nat × Nat) (x : Nat) : Nat × Nat := (x, pair ts.1 ts.2)

def pushRows (ts : Nat × Nat) (xs : List Nat) : Nat × Nat := xs.foldl pushPair ts

theorem pushRows_append (ts : Nat × Nat) (xs ys : List Nat) :
    pushRows ts (xs++ys) = pushRows (pushRows ts xs) ys := by
  simp only [pushRows, List.foldl_append]

theorem save_frameWith (n : Nat) (ts : Nat × Nat) (c a b p : Nat) (xs : List Nat) :
    save (frameWith n ts c a b p) xs = frameWith n (pushRows ts xs) c a b p := by
  induction xs generalizing ts with
  | nil => rfl
  | cons x xs ih => exact ih (pushPair ts x)

def asPayload (xs : List Nat) : Nat × Nat := (xs.headD 0, ProofSearch.pack xs.tail)

theorem pushRows_lists (xs : List Nat) (top : Nat) (stack : List Nat) :
    pushRows (top, ProofSearch.pack stack) xs = asPayload (xs.reverse ++ top::stack) := by
  induction xs generalizing top stack with
  | nil => rfl
  | cons x xs ih =>
      have h := ih x (top::stack)
      simpa only [pushRows, List.foldl_cons, pushPair, ProofSearch.pack, List.reverse_cons,
        List.append_assoc, List.cons_append, List.nil_append] using h

theorem payload_afterAX (s : ProofSearch.State) (xs : List Nat) (h : 2 ≤ xs.length) :
    pushRows (s.top, ProofSearch.pack s.stack) xs =
      ((afterAX s xs).top, pair (afterAX s xs).cache (ProofSearch.pack (afterAX s xs).stack)) := by
  rw [pushRows_lists]
  have len : 2 ≤ xs.reverse.length := by simpa only [List.length_reverse] using h
  cases he : xs.reverse with
  | nil => simp [he] at len
  | cons a rest =>
      cases rest with
      | nil => simp [he] at len
      | cons b tail => simp [afterAX, he, asPayload, ProofSearch.pack]

variable (embedded : Embedded actual batchCode 40 2968 [] [])
include embedded

theorem one_ax_then_guard (n c u v y d tail : Nat) (ts : Nat × Nat) :
    Moves (atFrame 40 (frameWith n ts c u v (encodeBatch (y,d) tail)))
      (atFrame 39 (frameWith n (pushRows ts (rowList (u+d) (v+y) c u)) c 0 0 tail)) := by
  have first := ax_program_of_embedding embedded n ts.1 ts.2 c u v y d tail
  change Moves (atFrame 40 (frameWith n ts c u v (encodeBatch (y,d) tail)))
    (atFrame 2968 (save (frameWith n ts c 0 0 tail) (rowList (u+d) (v+y) c u))) at first
  rw [save_frameWith] at first
  exact first.trans (jump_at _ _ _ row2968_cmd)

theorem remaining_ax_batches (rest : List (Nat×Nat)) (n tail : Nat) (ts : Nat×Nat) :
    Moves (atFrame 39 (frameWith n ts rest.length 0 0 (encodeBatches rest tail)))
      (atFrame 2969 (frameWith n (pushRows ts (tailRows rest)) 0 0 0 tail)) := by
  induction rest generalizing ts with
  | nil => exact mode_entry n ts.1 ts.2 0 0 tail
  | cons w rest ih =>
      obtain ⟨y,d⟩ := w
      have h₁ := ax_entry n ts.1 ts.2 rest.length 0 0 (encodeBatches ((y,d)::rest) tail)
      have h₂ := one_ax_then_guard embedded n rest.length 0 0 y d (encodeBatches rest tail) ts
      simp only [Nat.zero_add] at h₂
      have h₃ := ih (pushRows ts (rowList d y rest.length 0))
      simpa only [tailRows, pushRows_append, frameWith, List.length_cons] using (h₁.trans (h₂.trans h₃))

/-- The exact endpoint already isolates the top, cached formula and stack
required by the subsequent automatic NIP. -/
theorem ax_batches_of_embedding (n u y d : Nat) (rest : List (Nat×Nat)) (tail : Nat) (s : ProofSearch.State) :
    Moves (atFrame 40 ⟨n,s.top,ProofSearch.pack s.stack,rest.length,s.param+u,s.cache,
      encodeBatch (y,d) (encodeBatches rest tail)⟩)
      (atFrame 2969 ⟨n,(afterAX s (rows u y d rest s)).top,
        pair (afterAX s (rows u y d rest s)).cache (ProofSearch.pack (afterAX s (rows u y d rest s)).stack),
        0,0,0,tail⟩) := by
  let ts := (s.top, ProofSearch.pack s.stack)
  have first := one_ax_then_guard embedded n rest.length (s.param+u) s.cache y d (encodeBatches rest tail) ts
  have other := remaining_ax_batches embedded rest n tail
    (pushRows ts (rowList (s.param+u+d) (s.cache+y) rest.length (s.param+u)))
  have h := first.trans other
  rw [← pushRows_append] at h
  change Moves _ (atFrame 2969 (frameWith n (pushRows ts (rows u y d rest s)) 0 0 0 tail)) at h
  have ht : 2 ≤ (rows u y d rest s).length := by rw [rows_length]; omega
  rw [show ts = (s.top, ProofSearch.pack s.stack) from rfl, payload_afterAX s _ ht] at h
  exact h

end NF192.Emitter
