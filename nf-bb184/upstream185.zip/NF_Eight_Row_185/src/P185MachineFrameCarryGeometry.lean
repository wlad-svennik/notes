module
public import P185MachineControlCarryWords
public import P185MachineFrameUpdate

@[expose] public section
set_option maxRecDepth 200000

namespace P185.Frame
open NF210 NF210.TM KernelRightShift

/-- Canonical arithmetic return with the restored register payload ready for cleanup. -/
def Layout.carryConfig (f : Layout) (zero : Bool) (extra : Nat)
    (values : List Nat) (pad : Nat) : Configuration 185 :=
  configuration (Carry.entryState zero) (f.head-9 + (Carry.startHead f.pc : Int))
    (wordTape (f.head-9) (Carry.initialWord f.pc zero ++ List.replicate (extra+1) true ++
      blocks values ++ List.replicate pad false) blankOutside)

/-- The zero branch at the last branching leaf moves the control origin one cell left.
A positive decrement shifts the payload header one cell right. -/
def Layout.afterCarry (f : Layout) (zero : Bool) (bump : Nat)
    (regs : Array Nat) (spares : List Nat) : Layout :=
  let moved := (Carry.shifted f.pc zero).toNat
  ⟨f.head-(moved : Int),Carry.nextPc f.pc zero,f.gap+bump+moved,regs,spares⟩

theorem Layout.carry_restore_of_run (f : Layout) (zero : Bool) (extra bump : Nat)
    (regs : Array Nat) (spares : List Nat)
    (height : (Carry.initialWord f.pc zero).length+extra = 9 + f.gap + bump)
    {t : Nat} (ret : WordRun (Carry.entryState zero) 13 (Carry.ready f.pc zero extra)
      (Carry.restored f.pc zero extra) (Carry.startHead f.pc)
      (Carry.before (Carry.shifted f.pc zero)+1 : Nat) t) (pad : Nat := 1) :
    TM.run CS185.Table.machine t
      (f.carryConfig zero extra (f.afterCarry zero bump regs spares).values pad) =
      (f.afterCarry zero bump regs spares).config := by
  let dest := f.afterCarry zero bump regs spares
  let payload := Carry.payloadTail dest
  let origin := f.head-9
  have h := (ret.context [] (payload ++ List.replicate pad false)).exact_run origin blankOutside
  simp only [List.nil_append,List.length_nil,Int.natCast_zero,Int.zero_add] at h
  have initial : f.carryConfig zero extra dest.values pad =
      configuration (Carry.entryState zero) (origin+(Carry.startHead f.pc : Int))
      (wordTape origin (Carry.ready f.pc zero extra ++ (payload ++ List.replicate pad false))
        blankOutside) := by
    unfold Layout.carryConfig
    rw [Carry.blocks_payloadTail dest]
    simp [Carry.ready,payload,origin,List.append_assoc]
  rw [initial,h]
  rw [←List.append_assoc]
  apply Carry.restored_config
  · rfl
  · change (f.head-9)+((Carry.before (Carry.shifted f.pc zero)+1 : Nat) : Int) =
      f.head-((Carry.shifted f.pc zero).toNat : Int)
    cases Carry.shifted f.pc zero <;> simp [Carry.before] <;> omega
  · change (Carry.initialWord f.pc zero).length+extra = Carry.before (Carry.shifted f.pc zero)+1+
      (f.gap+bump+(Carry.shifted f.pc zero).toNat)
    rw [height]
    cases Carry.shifted f.pc zero <;> simp [Carry.before] <;> omega

theorem Layout.carry_geometry_inc (f : Layout) (room : 2 ≤ f.gapWidth) :
    (Carry.initialWord f.pc false).length+(f.gapWidth-2) = 9+f.gap+0 := by
  rw [Carry.initialWord_length]
  simp only [Bool.false_eq_true,ite_false]
  unfold Layout.gapWidth at *
  omega

theorem Layout.carry_geometry_pos (f : Layout) (room : 2 ≤ f.gapWidth) :
    (Carry.initialWord f.pc false).length+(f.gapWidth-1) = 9+f.gap+1 := by
  rw [Carry.initialWord_length]
  simp only [Bool.false_eq_true,ite_false]
  unfold Layout.gapWidth at *
  omega

theorem Layout.carry_geometry_zero (f : Layout) (room : 2 ≤ f.gapWidth) :
    (Carry.initialWord f.pc true).length+(f.gapWidth-1) = 9+f.gap+0 := by
  rw [Carry.initialWord_length]
  simp only [ite_true]
  unfold Layout.gapWidth at *
  omega

end P185.Frame
