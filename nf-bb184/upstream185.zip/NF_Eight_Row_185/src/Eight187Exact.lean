import Eight187SearchCore
import EightOrientation
import CompactModel
open NF192.Numerical NF192.Emitter C196Compact

namespace Eight187

private theorem literal_row {a b c u z : Nat} (hu : u ≤ a) (hv : z ∈ C196EightSeed.eight a b c u) :
    Deriv z := Deriv.row hu hv

private theorem rulesLiteral : EightOrientation.Rules Deriv where
  mp := Deriv.mp
  rho a b c u hu := literal_row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196EightSeed.eight])
  k a b := literal_row (a:=a) (b:=b) (c:=0) (u:=0) (Nat.zero_le _) (by simp [C196EightSeed.eight])
  e a b c := literal_row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [C196EightSeed.eight])

private theorem rulesCompact : EightOrientation.Rules C196Compact.Deriv where
  mp := C196Compact.Deriv.mp
  rho a b c u hu := C196Compact.Deriv.row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196Compact.rowList])
  k a b := C196Compact.Deriv.row (a:=a) (b:=b) (c:=0) (u:=0) (Nat.zero_le _) (by simp [C196Compact.rowList])
  e a b c := C196Compact.Deriv.row (a:=a) (b:=b) (c:=c) (u:=0) (Nat.zero_le _) (by simp [C196Compact.rowList])

private theorem row_to_compact {a b c u z : Nat} (hu : u ≤ a) (hz : z ∈ rowList a b c u) :
    C196Compact.Deriv z := by
  change z ∈ C196EightSeed.eight a b c u at hz
  simp only [C196EightSeed.eight,List.mem_cons,List.not_mem_nil,or_false] at hz
  rcases hz with hz|hz|hz|hz|hz|hz|hz|hz <;> subst z
  · exact .row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196Compact.rowList])
  · exact .row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196Compact.rowList])
  · exact .row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196Compact.rowList])
  · exact .row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196Compact.rowList])
  · exact .row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196Compact.rowList])
  · exact .row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196Compact.rowList])
  · exact rulesCompact.toSeed b a (.row (a:=b) (b:=a) (c:=0) (u:=0) (Nat.zero_le _) (by simp [C196Compact.rowList]))
  · exact .row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196Compact.rowList])

private theorem row_of_compact {a b c u z : Nat} (hu : u ≤ a) (hz : z ∈ C196Compact.rowList a b c u) :
    Deriv z := by
  simp only [C196Compact.rowList,List.mem_cons,List.not_mem_nil,or_false] at hz
  rcases hz with hz|hz|hz|hz|hz|hz|hz|hz <;> subst z
  · exact literal_row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196EightSeed.eight])
  · exact literal_row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196EightSeed.eight])
  · exact literal_row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196EightSeed.eight])
  · exact literal_row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196EightSeed.eight])
  · exact literal_row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196EightSeed.eight])
  · exact rulesLiteral.fromSeed a b (literal_row (a:=b) (b:=a) (c:=0) (u:=0) (Nat.zero_le _) (by simp [C196EightSeed.eight]))
  · exact literal_row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196EightSeed.eight])
  · exact literal_row (a:=a) (b:=b) (c:=c) (u:=u) hu (by simp [C196EightSeed.eight])

theorem deriv_iff_compact (p : Nat) : Deriv p ↔ C196Compact.Deriv p := by
  constructor
  · intro deriv
    induction deriv with
    | row hu hx => exact row_to_compact hu hx
    | mp _ _ major minor => exact .mp major minor
  · intro deriv
    induction deriv with
    | row hu hx => exact row_of_compact hu hx
    | mp _ _ major minor => exact .mp major minor

open FFL FFL.FirstOrder in
theorem deriv_goal_iff_nf_refutation : Deriv goal ↔ (𝗡𝗙 ⊢ ⊥) :=
  (deriv_iff_compact goal).trans C196Compact.deriv_goal_iff_nf_refutation

end Eight187
#print axioms Eight187.deriv_iff_compact
#print axioms Eight187.deriv_goal_iff_nf_refutation
