module
public import Table185
@[expose] public section
namespace CS185.Table
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-- The author-provided file order includes every working state. -/
theorem literalOrder_contains : ∀ q : Fin 185, q ∈ literalOrder := by decide +kernel
/-- The author-provided file order lists every working state exactly once. -/
theorem literalOrder_nodup : literalOrder.Nodup := by decide +kernel
end CS185.Table
#print axioms CS185.Table.literalOrder_contains
#print axioms CS185.Table.literalOrder_nodup
