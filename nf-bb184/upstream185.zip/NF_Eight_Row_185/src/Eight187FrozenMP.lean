module
public import Eight187ColdCore

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Eight187.Register.Frozen
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers
private def embeddedCheck (code : Code) (base finish : Nat) : Bool :=
  matchesCode base (compile code base finish [] [])

private theorem block_run {code : Code} {s t : Registers} {base finish : Nat}
    (hc : embeddedCheck code base finish = true) (he : Eval code s .normal t)
    (hf : (compile code base finish [] []).all (fun op => !(usesCounter op)) = true := by decide) :
    Reaches frozen ⟨base,s⟩ (some ⟨finish,t⟩) :=
  he.compiled _ _ _ _ _ (frozen_placement (embedded_of_matches code base finish hc) hf)
private theorem push4_checked : embeddedCheck NF192.Emitter.Literal.seq166 2838 2864 = true := by decide
private theorem imp_checked : embeddedCheck NF192.Emitter.Literal.seq119 2864 2889 = true := by decide
private theorem move16_checked : embeddedCheck NF192.Emitter.Literal.seq216 2889 2892 = true := by decide
private theorem move65_checked : embeddedCheck NF192.Emitter.Literal.seq207 2896 2899 = true := by decide
private theorem copy4_checked : embeddedCheck NF192.Emitter.Literal.seq167 2901 2908 = true := by decide
private theorem clear5_checked : embeddedCheck NF192.Emitter.Literal.seq199 2910 2912 = true := by decide
private theorem push5_checked : embeddedCheck NF192.Emitter.Literal.seq121 2913 2939 = true := by decide
private theorem unpair2_checked : embeddedCheck NF192.Emitter.Literal.seq160 2945 2956 = true := by decide
private theorem pop5_checked : embeddedCheck NF192.Emitter.Literal.seq207 2956 0 = true := by decide

private theorem actual_2912 : frozen 2912 = .dec 4 2939 2913 :=
  by decide
private theorem actual_2892 : frozen 2892 = .dec 6 2899 2893 := by decide
private theorem actual_2893 : frozen 2893 = .dec 5 2895 2894 := by decide
private theorem actual_2894 : frozen 2894 = .jump 2892 := by decide
private theorem actual_2895 : frozen 2895 = .inc 5 2896 := by decide
private theorem actual_2899 : frozen 2899 = .dec 5 2901 2900 := by decide
private theorem actual_2900 : frozen 2900 = .jump 2908 := by decide

/-- This prefix constructs the *numerical implication* from TOP and parameter,
restores the original stack, and moves the implication into register 6. -/
private theorem mp_prefix (n t sp c d h input : Nat) :
    Reaches frozen ⟨2838,mk9 n t sp c d h 0 0 input⟩
      (some ⟨2892,mk9 n 0 sp c d h (imp t d) 0 input⟩) := by
  have h1 := block_run push4_checked (seq166_normal n t sp c d h input)
  have h2 := block_run imp_checked (seq119_normal n d (pair t sp) c d h input)
  simp only [Cantor.unpair_pair] at h2
  have h3 := block_run move16_checked (seq216_eval n (imp t d) sp c d h 0 0 input)
  simp only [Nat.zero_add] at h3
  exact (h1.trans h2).trans h3

/-- Absolute difference defined by stripping one unit from both registers. -/
def residual : Nat → Nat → Nat
  | 0, y => y
  | x+1, 0 => x+1
  | x+1, y+1 => residual x y

private theorem residual_zero (a b : Nat) : residual a b = 0 ↔ a = b := by
  induction a generalizing b with
  | zero => simp [residual, eq_comm]
  | succ a ih =>
    cases b with
    | zero => simp [residual]
    | succ b => simp only [residual, Nat.succ.injEq, ih]

/-- The 7-slot comparator runs on all two-register inputs, leaving their
absolute difference in CACHE and clearing scratch 6. -/
private theorem compare_all (n sp c d input a b : Nat) :
    Reaches frozen ⟨2892,mk9 n 0 sp c d b a 0 input⟩
      (some ⟨2899,mk9 n 0 sp c d (residual a b) 0 0 input⟩) := by
  induction a generalizing b with
  | zero =>
    apply Reaches.one
    simp [NF192.Emitter.step, actual_2892, residual]
  | succ a ih =>
    have first : Reaches frozen ⟨2892,mk9 n 0 sp c d b (a+1) 0 input⟩
        (some ⟨2893,mk9 n 0 sp c d b a 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step, actual_2892]
    cases b with
    | zero =>
      have second : Reaches frozen ⟨2893,mk9 n 0 sp c d 0 a 0 input⟩
          (some ⟨2895,mk9 n 0 sp c d 0 a 0 input⟩) := by
        apply Reaches.one
        simp [NF192.Emitter.step,actual_2893]
      have third : Reaches frozen ⟨2895,mk9 n 0 sp c d 0 a 0 input⟩
          (some ⟨2896,mk9 n 0 sp c d 1 a 0 input⟩) := by
        apply Reaches.one
        simp [NF192.Emitter.step,actual_2895,Registers.add]
      have fourth := block_run move65_checked (seq207_eval n 0 sp c d 1 a 0 input)
      simpa only [residual,Nat.add_comm 1 a] using (((first.trans second).trans third).trans fourth)
    | succ b =>
      have second : Reaches frozen ⟨2893,mk9 n 0 sp c d (b+1) a 0 input⟩
          (some ⟨2894,mk9 n 0 sp c d b a 0 input⟩) := by
        apply Reaches.one
        simp [NF192.Emitter.step,actual_2893]
      have third : Reaches frozen ⟨2894,mk9 n 0 sp c d b a 0 input⟩
          (some ⟨2892,mk9 n 0 sp c d b a 0 input⟩) := by
        apply Reaches.one
        simp [NF192.Emitter.step,actual_2894]
      exact ((first.trans second).trans third).trans (ih b)

private theorem clear4_checked : embeddedCheck NF192.Emitter.Literal.seq224 2908 2910 = true := by decide

private theorem cleanup (n t sp c d h input : Nat) :
    Reaches frozen ⟨2908,mk9 n t sp c d h 0 0 input⟩ (some ⟨2912,mk9 n t sp c 0 0 0 0 input⟩) := by
  have a := block_run clear4_checked (seq224_eval n t sp c d h 0 0 input)
  have b := block_run clear5_checked (seq199_eval n t sp c 0 h 0 0 input)
  exact a.trans b

private theorem mp_suffix (n sp c d input h : Nat) :
    Reaches frozen ⟨2899,mk9 n 0 sp c d h 0 0 input⟩
      (some ⟨2912,mk9 n (if h = 0 then d else 0) sp c 0 0 0 0 input⟩) := by
  cases h with
  | zero =>
    have a : Reaches frozen ⟨2899,mk9 n 0 sp c d 0 0 0 input⟩
        (some ⟨2901,mk9 n 0 sp c d 0 0 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step, actual_2899]
    have b : Eval NF192.Emitter.Literal.seq167 (mk9 n 0 sp c d 0 0 0 input) .normal
        (mk9 n d sp c d 0 0 0 input) := by
      have h1 := seq198_eval n 0 sp c d 0 0 0 input
      have h2 := seq205_eval n d sp c 0 0 d 0 input
      simp only [Nat.zero_add] at h1 h2
      exact Eval.seq_normal h1 h2
    exact (a.trans (block_run copy4_checked b)).trans
      (cleanup n d sp c d 0 input)
  | succ k =>
    have a : Reaches frozen ⟨2899,mk9 n 0 sp c d (k+1) 0 0 input⟩
        (some ⟨2900,mk9 n 0 sp c d k 0 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step,actual_2899]
    have b : Reaches frozen ⟨2900,mk9 n 0 sp c d k 0 0 input⟩
        (some ⟨2908,mk9 n 0 sp c d k 0 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step,actual_2900]
    exact (a.trans b).trans (cleanup n 0 sp c d k input)

/-- Literal MP (ordinal 2838) preserves the parameter on both branches,
clears cache, and succeeds exactly on the encoded implication. -/
theorem mp_to_mode (n t sp c d h input : Nat) :
    Reaches frozen ⟨2838,mk9 n t sp c d h 0 0 input⟩
      (some ⟨2912,mk9 n (if h = imp t d then d else 0) sp c 0 0 0 0 input⟩) := by
  have h₁ := mp_prefix n t sp c d h input
  have h₂ := compare_all n sp c d input (imp t d) h
  have h₃ := mp_suffix n sp c d input (residual (imp t d) h)
  have k := (h₁.trans h₂).trans h₃
  rw [show (if residual (imp t d) h = 0 then d else 0) =
      (if h = imp t d then d else 0) by
        by_cases e : h = imp t d
        · simp only [ite_eq_left e, ite_eq_left ((residual_zero _ _).2 e.symm)]
        · simp only [ite_eq_right e, ite_eq_right (fun hz => e ((residual_zero _ _).1 hz).symm)]] at k
  exact k

private theorem fastZero (pc next other : Nat) (r : Register) (rs : Registers)
    (hz : rs r = 0) (h : frozen pc = .dec r next other) :
    Reaches frozen ⟨pc,rs⟩ (some ⟨next,rs⟩) := Reaches.one (by simp [NF192.Emitter.step,h,hz])

private theorem frozenPop (n t sp c input : Nat) :
    Reaches frozen ⟨2912,mk9 n t sp c 0 0 0 0 input⟩
      (some ⟨0,mk9 n t (Cantor.unpair sp).2 c 0 (Cantor.unpair sp).1 0 0 input⟩) := by
  apply (fastZero 2912 2939 2913 4 _ rfl (by decide)).trans
  apply (fastZero 2939 2943 2940 5 _ rfl (by decide)).trans
  apply (fastZero 2943 2945 2944 5 _ rfl (by decide)).trans
  have ha : embeddedCheck NF192.Emitter.Literal.seq160 2945 2956 = true := by decide
  have hb : embeddedCheck NF192.Emitter.Literal.seq207 2956 0 = true := by decide
  have first := block_run ha (seq160_normal n t sp c 0 0 input)
  have second := block_run hb (seq207_eval n t (Cantor.unpair sp).2 c 0 0 (Cantor.unpair sp).1 0 input)
  simp only [Nat.zero_add] at second
  exact first.trans second

theorem mp_reaches (n t sp c d h input : Nat) :
    Reaches frozen ⟨2838,mk9 n t sp c d h 0 0 input⟩
      (some ⟨0,mk9 n (if h = imp t d then d else 0) (Cantor.unpair sp).2 c 0 (Cantor.unpair sp).1 0 0 input⟩) :=
  (mp_to_mode n t sp c d h input).trans (frozenPop _ _ _ _ _)

end Eight187.Register.Frozen
