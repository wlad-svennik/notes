module
public import NF210.MachineSemantics

@[expose] public section

/-! The exact selected 192-state table, numbered by lexicographic state name.
The rendering theorem compares every source row. The SHA-256 is provenance. -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace NF192.Selected
open NF210.TM

abbrev State := Fin 192
def start : State := 185
def decoderRoot : State := 13
def haltGate : State := 170
def stateNames : Array String := #[
  "a:CD:1",
  "a:CD:5",
  "a:CD:6",
  "a:CD:7",
  "a:CI:0",
  "a:CI:1",
  "a:CI:2",
  "a:CI:3",
  "a:CI:4",
  "a:CI:5",
  "a:CI:6",
  "a:CI:7",
  "a:CI:8",
  "d:0",
  "d:1",
  "d:10",
  "d:100",
  "d:102",
  "d:103",
  "d:105",
  "d:107",
  "d:108",
  "d:109",
  "d:11",
  "d:110",
  "d:111",
  "d:112",
  "d:113",
  "d:114",
  "d:115",
  "d:117",
  "d:118",
  "d:119",
  "d:12",
  "d:120",
  "d:121",
  "d:123",
  "d:124",
  "d:125",
  "d:126",
  "d:127",
  "d:128",
  "d:129",
  "d:13",
  "d:130",
  "d:131",
  "d:133",
  "d:134",
  "d:135",
  "d:136",
  "d:137",
  "d:138",
  "d:139",
  "d:14",
  "d:140",
  "d:141",
  "d:142",
  "d:143",
  "d:144",
  "d:145",
  "d:146",
  "d:148",
  "d:149",
  "d:15",
  "d:150",
  "d:151",
  "d:152",
  "d:153",
  "d:154",
  "d:155",
  "d:156",
  "d:157",
  "d:16",
  "d:17",
  "d:18",
  "d:19",
  "d:2",
  "d:20",
  "d:21",
  "d:22",
  "d:23",
  "d:24",
  "d:25",
  "d:26",
  "d:28",
  "d:29",
  "d:3",
  "d:30",
  "d:31",
  "d:32",
  "d:33",
  "d:34",
  "d:35",
  "d:36",
  "d:37",
  "d:38",
  "d:39",
  "d:4",
  "d:40",
  "d:41",
  "d:42",
  "d:43",
  "d:44",
  "d:45",
  "d:46",
  "d:47",
  "d:49",
  "d:5",
  "d:50",
  "d:51",
  "d:52",
  "d:53",
  "d:54",
  "d:55",
  "d:56",
  "d:57",
  "d:59",
  "d:6",
  "d:60",
  "d:61",
  "d:62",
  "d:63",
  "d:64",
  "d:65",
  "d:66",
  "d:67",
  "d:68",
  "d:69",
  "d:7",
  "d:70",
  "d:71",
  "d:73",
  "d:74",
  "d:75",
  "d:76",
  "d:77",
  "d:78",
  "d:79",
  "d:8",
  "d:80",
  "d:82",
  "d:83",
  "d:84",
  "d:85",
  "d:86",
  "d:87",
  "d:88",
  "d:89",
  "d:90",
  "d:91",
  "d:92",
  "d:93",
  "d:94",
  "d:96",
  "d:97",
  "d:98",
  "d:99",
  "k16share:0",
  "k16share:1",
  "k:0",
  "k:10",
  "k:113",
  "k:15",
  "k:198",
  "k:2",
  "k:22",
  "k:23",
  "k:24",
  "k:25",
  "k:3",
  "k:302",
  "k:32",
  "k:33",
  "k:35",
  "k:36",
  "k:4",
  "k:40",
  "k:48",
  "k:49",
  "k:5",
  "k:51",
  "k:54",
  "k:55",
  "k:6",
  "k:60",
  "k:64",
  "k:66",
  "k:74",
  "k:75",
  "k:9",
  "k:94",
  "k:97"
]

theorem stateNames_size : stateNames.size = 192 := by decide
theorem stateNames_distinct : stateNames.toList.Pairwise (fun a b => a ≠ b) := by decide

def name (q : State) : String :=
  stateNames[q.val]'(by simpa only [stateNames_size] using q.isLt)

/-- A balanced decision tree evaluates quickly inside the kernel. -/
def instructionPair (q : State) : Instruction 192 × Instruction 192 :=
  if q.val < 96 then
    if q.val < 48 then
      if q.val < 24 then
        if q.val < 12 then
          if q.val < 6 then
            if q.val < 3 then
              if q.val < 1 then
                (⟨false, .left, some (130 : State)⟩, ⟨true, .left, some (35 : State)⟩) -- a:CD:1
              else
                if q.val < 2 then
                  (⟨false, .right, some (167 : State)⟩, ⟨false, .right, some (182 : State)⟩) -- a:CD:5
                else
                  (⟨false, .left, some (74 : State)⟩, ⟨true, .left, some (119 : State)⟩) -- a:CD:6
            else
              if q.val < 4 then
                (⟨false, .right, some (167 : State)⟩, ⟨false, .right, some (172 : State)⟩) -- a:CD:7
              else
                if q.val < 5 then
                  (⟨false, .left, some (98 : State)⟩, ⟨false, .right, some (165 : State)⟩) -- a:CI:0
                else
                  (⟨false, .right, some (178 : State)⟩, ⟨false, .right, some (168 : State)⟩) -- a:CI:1
          else
            if q.val < 9 then
              if q.val < 7 then
                (⟨false, .left, some (98 : State)⟩, ⟨false, .right, some (180 : State)⟩) -- a:CI:2
              else
                if q.val < 8 then
                  (⟨false, .left, some (98 : State)⟩, ⟨false, .right, some (171 : State)⟩) -- a:CI:3
                else
                  (⟨false, .left, some (98 : State)⟩, ⟨false, .right, some (177 : State)⟩) -- a:CI:4
            else
              if q.val < 10 then
                (⟨false, .left, some (119 : State)⟩, ⟨true, .left, some (123 : State)⟩) -- a:CI:5
              else
                if q.val < 11 then
                  (⟨false, .right, some (178 : State)⟩, ⟨false, .right, some (184 : State)⟩) -- a:CI:6
                else
                  (⟨false, .left, some (119 : State)⟩, ⟨true, .left, some (77 : State)⟩) -- a:CI:7
        else
          if q.val < 18 then
            if q.val < 15 then
              if q.val < 13 then
                (⟨false, .left, some (98 : State)⟩, ⟨false, .right, some (174 : State)⟩) -- a:CI:8
              else
                if q.val < 14 then
                  (⟨false, .right, some (14 : State)⟩, ⟨true, .right, some (84 : State)⟩) -- d:0
                else
                  (⟨false, .right, some (76 : State)⟩, ⟨true, .right, some (79 : State)⟩) -- d:1
            else
              if q.val < 16 then
                (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (23 : State)⟩) -- d:10
              else
                if q.val < 17 then
                  (⟨false, .right, some (145 : State)⟩, ⟨true, .right, some (125 : State)⟩) -- d:100
                else
                  (⟨false, .right, some (18 : State)⟩, ⟨true, .right, some (19 : State)⟩) -- d:102
          else
            if q.val < 21 then
              if q.val < 19 then
                (⟨false, .left, some (142 : State)⟩, ⟨true, .left, some (26 : State)⟩) -- d:103
              else
                if q.val < 20 then
                  (⟨false, .right, some (143 : State)⟩, ⟨true, .right, some (16 : State)⟩) -- d:105
                else
                  (⟨false, .right, some (21 : State)⟩, ⟨true, .right, some (26 : State)⟩) -- d:107
            else
              if q.val < 22 then
                (⟨false, .right, some (22 : State)⟩, ⟨true, .right, some (19 : State)⟩) -- d:108
              else
                if q.val < 23 then
                  (⟨false, .right, some (24 : State)⟩, ⟨true, .right, some (25 : State)⟩) -- d:109
                else
                  (⟨false, .right, some (4 : State)⟩, ⟨false, .left, some (157 : State)⟩) -- d:11
      else
        if q.val < 36 then
          if q.val < 30 then
            if q.val < 27 then
              if q.val < 25 then
                (⟨false, .right, some (5 : State)⟩, ⟨true, .right, some (155 : State)⟩) -- d:110
              else
                if q.val < 26 then
                  (⟨false, .right, some (18 : State)⟩, ⟨true, .right, some (143 : State)⟩) -- d:111
                else
                  (⟨false, .right, some (27 : State)⟩, ⟨true, .right, some (155 : State)⟩) -- d:112
            else
              if q.val < 28 then
                (⟨false, .right, some (28 : State)⟩, ⟨true, .right, some (156 : State)⟩) -- d:113
              else
                if q.val < 29 then
                  (⟨false, .right, some (102 : State)⟩, ⟨true, .right, some (29 : State)⟩) -- d:114
                else
                  (⟨false, .right, some (5 : State)⟩, ⟨true, .right, some (0 : State)⟩) -- d:115
          else
            if q.val < 33 then
              if q.val < 31 then
                (⟨false, .right, some (31 : State)⟩, ⟨true, .right, some (32 : State)⟩) -- d:117
              else
                if q.val < 32 then
                  (⟨false, .right, some (101 : State)⟩, ⟨true, .right, some (18 : State)⟩) -- d:118
                else
                  (⟨false, .right, some (34 : State)⟩, ⟨true, .right, some (36 : State)⟩) -- d:119
            else
              if q.val < 34 then
                (⟨false, .right, some (43 : State)⟩, ⟨true, .right, some (77 : State)⟩) -- d:12
              else
                if q.val < 35 then
                  (⟨false, .right, some (35 : State)⟩, ⟨true, .right, some (132 : State)⟩) -- d:120
                else
                  (⟨false, .right, some (5 : State)⟩, ⟨true, .right, some (145 : State)⟩) -- d:121
        else
          if q.val < 42 then
            if q.val < 39 then
              if q.val < 37 then
                (⟨false, .right, some (37 : State)⟩, ⟨true, .right, some (140 : State)⟩) -- d:123
              else
                if q.val < 38 then
                  (⟨false, .right, some (35 : State)⟩, ⟨true, .right, some (38 : State)⟩) -- d:124
                else
                  (⟨false, .right, some (143 : State)⟩, ⟨true, .right, some (25 : State)⟩) -- d:125
            else
              if q.val < 40 then
                (⟨false, .right, some (40 : State)⟩, ⟨true, .right, some (50 : State)⟩) -- d:126
              else
                if q.val < 41 then
                  (⟨false, .right, some (28 : State)⟩, ⟨true, .right, some (41 : State)⟩) -- d:127
                else
                  (⟨false, .right, some (125 : State)⟩, ⟨true, .right, some (42 : State)⟩) -- d:128
          else
            if q.val < 45 then
              if q.val < 43 then
                (⟨false, .right, some (44 : State)⟩, ⟨true, .right, some (47 : State)⟩) -- d:129
              else
                if q.val < 44 then
                  (⟨false, .right, some (12 : State)⟩, ⟨true, .right, some (53 : State)⟩) -- d:13
                else
                  (⟨false, .right, some (28 : State)⟩, ⟨true, .right, some (45 : State)⟩) -- d:130
            else
              if q.val < 46 then
                (⟨false, .right, some (153 : State)⟩, ⟨true, .right, some (48 : State)⟩) -- d:131
              else
                if q.val < 47 then
                  (⟨false, .right, some (143 : State)⟩, ⟨true, .right, some (35 : State)⟩) -- d:133
                else
                  (⟨false, .right, some (48 : State)⟩, ⟨true, .right, some (49 : State)⟩) -- d:134
    else
      if q.val < 72 then
        if q.val < 60 then
          if q.val < 54 then
            if q.val < 51 then
              if q.val < 49 then
                (⟨false, .left, some (142 : State)⟩, ⟨true, .right, some (46 : State)⟩) -- d:135
              else
                if q.val < 50 then
                  (⟨false, .right, some (145 : State)⟩, ⟨true, .right, some (132 : State)⟩) -- d:136
                else
                  (⟨false, .right, some (51 : State)⟩, ⟨true, .right, some (52 : State)⟩) -- d:137
            else
              if q.val < 52 then
                (⟨false, .right, some (8 : State)⟩, ⟨false, .left, some (158 : State)⟩) -- d:138
              else
                if q.val < 53 then
                  (⟨false, .right, some (1 : State)⟩, ⟨false, .left, some (164 : State)⟩) -- d:139
                else
                  (⟨false, .right, some (63 : State)⟩, ⟨false, .left, some (157 : State)⟩) -- d:14
          else
            if q.val < 57 then
              if q.val < 55 then
                (⟨false, .right, some (55 : State)⟩, ⟨true, .right, some (56 : State)⟩) -- d:140
              else
                if q.val < 56 then
                  (⟨false, .right, some (8 : State)⟩, ⟨true, .right, some (137 : State)⟩) -- d:141
                else
                  (⟨false, .right, some (57 : State)⟩, ⟨true, .right, some (141 : State)⟩) -- d:142
            else
              if q.val < 58 then
                (⟨false, .right, some (58 : State)⟩, ⟨true, .right, some (52 : State)⟩) -- d:143
              else
                if q.val < 59 then
                  (⟨false, .right, some (1 : State)⟩, ⟨true, .right, some (59 : State)⟩) -- d:144
                else
                  (⟨false, .right, some (1 : State)⟩, ⟨true, .right, some (60 : State)⟩) -- d:145
        else
          if q.val < 66 then
            if q.val < 63 then
              if q.val < 61 then
                (⟨false, .right, some (1 : State)⟩, ⟨true, .right, some (1 : State)⟩) -- d:146
              else
                if q.val < 62 then
                  (⟨false, .right, some (132 : State)⟩, ⟨true, .right, some (62 : State)⟩) -- d:148
                else
                  (⟨false, .right, some (64 : State)⟩, ⟨true, .right, some (69 : State)⟩) -- d:149
            else
              if q.val < 64 then
                (⟨false, .right, some (11 : State)⟩, ⟨true, .right, some (72 : State)⟩) -- d:15
              else
                if q.val < 65 then
                  (⟨false, .right, some (103 : State)⟩, ⟨true, .right, some (65 : State)⟩) -- d:150
                else
                  (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (66 : State)⟩) -- d:151
          else
            if q.val < 69 then
              if q.val < 67 then
                (⟨false, .right, some (67 : State)⟩, ⟨true, .right, some (68 : State)⟩) -- d:152
              else
                if q.val < 68 then
                  (⟨false, .right, some (1 : State)⟩, ⟨false, .left, some (157 : State)⟩) -- d:153
                else
                  (⟨false, .right, some (9 : State)⟩, ⟨true, .right, some (96 : State)⟩) -- d:154
            else
              if q.val < 70 then
                (⟨false, .right, some (70 : State)⟩, ⟨true, .right, some (52 : State)⟩) -- d:155
              else
                if q.val < 71 then
                  (⟨false, .right, some (71 : State)⟩, ⟨true, .right, some (122 : State)⟩) -- d:156
                else
                  (⟨false, .right, some (1 : State)⟩, ⟨false, .left, some (170 : State)⟩) -- d:157
      else
        if q.val < 84 then
          if q.val < 78 then
            if q.val < 75 then
              if q.val < 73 then
                (⟨false, .right, some (73 : State)⟩, ⟨true, .right, some (74 : State)⟩) -- d:16
              else
                if q.val < 74 then
                  (⟨false, .right, some (2 : State)⟩, ⟨false, .left, some (170 : State)⟩) -- d:17
                else
                  (⟨false, .right, some (3 : State)⟩, ⟨true, .right, some (75 : State)⟩) -- d:18
            else
              if q.val < 76 then
                (⟨false, .right, some (10 : State)⟩, ⟨false, .left, some (157 : State)⟩) -- d:19
              else
                if q.val < 77 then
                  (⟨false, .right, some (86 : State)⟩, ⟨true, .right, some (33 : State)⟩) -- d:2
                else
                  (⟨false, .right, some (3 : State)⟩, ⟨true, .right, some (78 : State)⟩) -- d:20
          else
            if q.val < 81 then
              if q.val < 79 then
                (⟨false, .right, some (12 : State)⟩, ⟨false, .left, some (157 : State)⟩) -- d:21
              else
                if q.val < 80 then
                  (⟨false, .right, some (80 : State)⟩, ⟨true, .right, some (82 : State)⟩) -- d:22
                else
                  (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (81 : State)⟩) -- d:23
            else
              if q.val < 82 then
                (⟨false, .right, some (7 : State)⟩, ⟨false, .left, some (157 : State)⟩) -- d:24
              else
                if q.val < 83 then
                  (⟨false, .right, some (33 : State)⟩, ⟨true, .right, some (83 : State)⟩) -- d:25
                else
                  (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (51 : State)⟩) -- d:26
        else
          if q.val < 90 then
            if q.val < 87 then
              if q.val < 85 then
                (⟨false, .right, some (85 : State)⟩, ⟨true, .right, some (61 : State)⟩) -- d:28
              else
                if q.val < 86 then
                  (⟨false, .right, some (7 : State)⟩, ⟨true, .right, some (87 : State)⟩) -- d:29
                else
                  (⟨false, .right, some (97 : State)⟩, ⟨true, .right, some (107 : State)⟩) -- d:3
            else
              if q.val < 88 then
                (⟨false, .right, some (88 : State)⟩, ⟨false, .left, some (23 : State)⟩) -- d:30
              else
                if q.val < 89 then
                  (⟨false, .right, some (89 : State)⟩, ⟨true, .right, some (54 : State)⟩) -- d:31
                else
                  (⟨false, .right, some (7 : State)⟩, ⟨true, .right, some (90 : State)⟩) -- d:32
          else
            if q.val < 93 then
              if q.val < 91 then
                (⟨false, .right, some (91 : State)⟩, ⟨false, .left, some (157 : State)⟩) -- d:33
              else
                if q.val < 92 then
                  (⟨false, .right, some (92 : State)⟩, ⟨true, .right, some (146 : State)⟩) -- d:34
                else
                  (⟨false, .right, some (33 : State)⟩, ⟨true, .right, some (93 : State)⟩) -- d:35
            else
              if q.val < 94 then
                (⟨false, .right, some (94 : State)⟩, ⟨true, .right, some (140 : State)⟩) -- d:36
              else
                if q.val < 95 then
                  (⟨false, .right, some (95 : State)⟩, ⟨true, .right, some (131 : State)⟩) -- d:37
                else
                  (⟨false, .right, some (96 : State)⟩, ⟨true, .right, some (99 : State)⟩) -- d:38
  else
    if q.val < 144 then
      if q.val < 120 then
        if q.val < 108 then
          if q.val < 102 then
            if q.val < 99 then
              if q.val < 97 then
                (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (98 : State)⟩) -- d:39
              else
                if q.val < 98 then
                  (⟨false, .right, some (12 : State)⟩, ⟨false, .left, some (170 : State)⟩) -- d:4
                else
                  (⟨false, .left, some (66 : State)⟩, ⟨false, .left, some (157 : State)⟩) -- d:40
            else
              if q.val < 100 then
                (⟨false, .right, some (100 : State)⟩, ⟨true, .right, some (124 : State)⟩) -- d:41
              else
                if q.val < 101 then
                  (⟨false, .right, some (101 : State)⟩, ⟨true, .right, some (121 : State)⟩) -- d:42
                else
                  (⟨false, .right, some (102 : State)⟩, ⟨true, .right, some (116 : State)⟩) -- d:43
          else
            if q.val < 105 then
              if q.val < 103 then
                (⟨false, .right, some (103 : State)⟩, ⟨true, .right, some (104 : State)⟩) -- d:44
              else
                if q.val < 104 then
                  (⟨false, .right, some (0 : State)⟩, ⟨true, .right, some (75 : State)⟩) -- d:45
                else
                  (⟨false, .right, some (105 : State)⟩, ⟨true, .right, some (106 : State)⟩) -- d:46
            else
              if q.val < 106 then
                (⟨false, .right, some (6 : State)⟩, ⟨true, .right, some (11 : State)⟩) -- d:47
              else
                if q.val < 107 then
                  (⟨false, .right, some (108 : State)⟩, ⟨true, .right, some (115 : State)⟩) -- d:49
                else
                  (⟨false, .right, some (4 : State)⟩, ⟨true, .right, some (117 : State)⟩) -- d:5
        else
          if q.val < 114 then
            if q.val < 111 then
              if q.val < 109 then
                (⟨false, .right, some (109 : State)⟩, ⟨true, .right, some (111 : State)⟩) -- d:50
              else
                if q.val < 110 then
                  (⟨false, .right, some (0 : State)⟩, ⟨true, .right, some (110 : State)⟩) -- d:51
                else
                  (⟨false, .right, some (11 : State)⟩, ⟨true, .right, some (2 : State)⟩) -- d:52
            else
              if q.val < 112 then
                (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (112 : State)⟩) -- d:53
              else
                if q.val < 113 then
                  (⟨false, .right, some (113 : State)⟩, ⟨false, .left, some (23 : State)⟩) -- d:54
                else
                  (⟨false, .right, some (11 : State)⟩, ⟨true, .right, some (114 : State)⟩) -- d:55
          else
            if q.val < 117 then
              if q.val < 115 then
                (⟨false, .left, some (82 : State)⟩, ⟨true, .right, some (11 : State)⟩) -- d:56
              else
                if q.val < 116 then
                  (⟨false, .right, some (3 : State)⟩, ⟨true, .right, some (127 : State)⟩) -- d:57
                else
                  (⟨false, .right, some (118 : State)⟩, ⟨true, .right, some (80 : State)⟩) -- d:59
            else
              if q.val < 118 then
                (⟨false, .right, some (128 : State)⟩, ⟨true, .right, some (15 : State)⟩) -- d:6
              else
                if q.val < 119 then
                  (⟨false, .right, some (7 : State)⟩, ⟨true, .right, some (119 : State)⟩) -- d:60
                else
                  (⟨false, .right, some (10 : State)⟩, ⟨true, .right, some (120 : State)⟩) -- d:61
      else
        if q.val < 132 then
          if q.val < 126 then
            if q.val < 123 then
              if q.val < 121 then
                (⟨false, .right, some (5 : State)⟩, ⟨false, .left, some (23 : State)⟩) -- d:62
              else
                if q.val < 122 then
                  (⟨false, .right, some (102 : State)⟩, ⟨true, .right, some (122 : State)⟩) -- d:63
                else
                  (⟨false, .right, some (123 : State)⟩, ⟨true, .right, some (83 : State)⟩) -- d:64
            else
              if q.val < 124 then
                (⟨false, .left, some (50 : State)⟩, ⟨true, .right, some (119 : State)⟩) -- d:65
              else
                if q.val < 125 then
                  (⟨false, .right, some (82 : State)⟩, ⟨true, .right, some (125 : State)⟩) -- d:66
                else
                  (⟨false, .right, some (126 : State)⟩, ⟨true, .right, some (129 : State)⟩) -- d:67
          else
            if q.val < 129 then
              if q.val < 127 then
                (⟨false, .right, some (127 : State)⟩, ⟨true, .right, some (115 : State)⟩) -- d:68
              else
                if q.val < 128 then
                  (⟨false, .right, some (6 : State)⟩, ⟨true, .left, some (114 : State)⟩) -- d:69
                else
                  (⟨false, .right, some (4 : State)⟩, ⟨true, .right, some (138 : State)⟩) -- d:7
            else
              if q.val < 130 then
                (⟨false, .right, some (108 : State)⟩, ⟨true, .right, some (130 : State)⟩) -- d:70
              else
                if q.val < 131 then
                  (⟨false, .right, some (3 : State)⟩, ⟨true, .right, some (9 : State)⟩) -- d:71
                else
                  (⟨false, .right, some (132 : State)⟩, ⟨true, .right, some (133 : State)⟩) -- d:73
        else
          if q.val < 138 then
            if q.val < 135 then
              if q.val < 133 then
                (⟨false, .left, some (17 : State)⟩, ⟨true, .right, some (125 : State)⟩) -- d:74
              else
                if q.val < 134 then
                  (⟨false, .right, some (134 : State)⟩, ⟨true, .right, some (136 : State)⟩) -- d:75
                else
                  (⟨false, .right, some (121 : State)⟩, ⟨true, .right, some (135 : State)⟩) -- d:76
            else
              if q.val < 136 then
                (⟨false, .right, some (136 : State)⟩, ⟨true, .right, some (137 : State)⟩) -- d:77
              else
                if q.val < 137 then
                  (⟨false, .right, some (101 : State)⟩, ⟨true, .right, some (125 : State)⟩) -- d:78
                else
                  (⟨false, .right, some (139 : State)⟩, ⟨true, .right, some (96 : State)⟩) -- d:79
          else
            if q.val < 141 then
              if q.val < 139 then
                (⟨false, .right, some (12 : State)⟩, ⟨true, .right, some (2 : State)⟩) -- d:8
              else
                if q.val < 140 then
                  (⟨false, .right, some (102 : State)⟩, ⟨true, .right, some (123 : State)⟩) -- d:80
                else
                  (⟨false, .right, some (141 : State)⟩, ⟨true, .right, some (142 : State)⟩) -- d:82
            else
              if q.val < 142 then
                (⟨false, .left, some (16 : State)⟩, ⟨true, .left, some (135 : State)⟩) -- d:83
              else
                if q.val < 143 then
                  (⟨false, .right, some (143 : State)⟩, ⟨true, .right, some (144 : State)⟩) -- d:84
                else
                  (⟨false, .left, some (133 : State)⟩, ⟨true, .right, some (144 : State)⟩) -- d:85
    else
      if q.val < 168 then
        if q.val < 156 then
          if q.val < 150 then
            if q.val < 147 then
              if q.val < 145 then
                (⟨false, .right, some (137 : State)⟩, ⟨true, .right, some (145 : State)⟩) -- d:86
              else
                if q.val < 146 then
                  (⟨false, .right, some (125 : State)⟩, ⟨true, .right, some (5 : State)⟩) -- d:87
                else
                  (⟨false, .right, some (147 : State)⟩, ⟨true, .right, some (39 : State)⟩) -- d:88
            else
              if q.val < 148 then
                (⟨false, .right, some (148 : State)⟩, ⟨true, .right, some (30 : State)⟩) -- d:89
              else
                if q.val < 149 then
                  (⟨false, .right, some (102 : State)⟩, ⟨true, .right, some (149 : State)⟩) -- d:90
                else
                  (⟨false, .right, some (150 : State)⟩, ⟨true, .right, some (20 : State)⟩) -- d:91
          else
            if q.val < 153 then
              if q.val < 151 then
                (⟨false, .right, some (151 : State)⟩, ⟨true, .right, some (18 : State)⟩) -- d:92
              else
                if q.val < 152 then
                  (⟨false, .right, some (152 : State)⟩, ⟨true, .right, some (17 : State)⟩) -- d:93
                else
                  (⟨false, .right, some (5 : State)⟩, ⟨true, .right, some (154 : State)⟩) -- d:94
            else
              if q.val < 154 then
                (⟨false, .right, some (154 : State)⟩, ⟨true, .right, some (16 : State)⟩) -- d:96
              else
                if q.val < 155 then
                  (⟨false, .left, some (44 : State)⟩, ⟨true, .left, some (22 : State)⟩) -- d:97
                else
                  (⟨false, .right, some (156 : State)⟩, ⟨true, .right, some (144 : State)⟩) -- d:98
        else
          if q.val < 162 then
            if q.val < 159 then
              if q.val < 157 then
                (⟨false, .left, some (133 : State)⟩, ⟨true, .right, some (145 : State)⟩) -- d:99
              else
                if q.val < 158 then
                  (⟨true, .left, some (158 : State)⟩, ⟨false, .left, some (164 : State)⟩) -- k16share:0
                else
                  (⟨true, .left, some (50 : State)⟩, ⟨false, .right, some (158 : State)⟩) -- k16share:1
            else
              if q.val < 160 then
                (⟨true, .right, some (190 : State)⟩, ⟨true, .right, some (159 : State)⟩) -- k:0
              else
                if q.val < 161 then
                  (⟨false, .left, some (157 : State)⟩, ⟨false, .right, some (160 : State)⟩) -- k:10
                else
                  (⟨false, .left, some (170 : State)⟩, ⟨false, .left, some (191 : State)⟩) -- k:113
          else
            if q.val < 165 then
              if q.val < 163 then
                (⟨false, .left, some (166 : State)⟩, ⟨true, .left, some (164 : State)⟩) -- k:15
              else
                if q.val < 164 then
                  (⟨false, .left, some (191 : State)⟩, ⟨true, .left, some (181 : State)⟩) -- k:198
                else
                  (⟨false, .left, some (169 : State)⟩, ⟨true, .left, some (164 : State)⟩) -- k:2
            else
              if q.val < 166 then
                (⟨false, .right, some (172 : State)⟩, ⟨true, .right, some (165 : State)⟩) -- k:22
              else
                if q.val < 167 then
                  (⟨false, .left, some (188 : State)⟩, ⟨true, .left, some (164 : State)⟩) -- k:23
                else
                  (⟨false, .left, some (173 : State)⟩, ⟨false, .right, some (159 : State)⟩) -- k:24
      else
        if q.val < 180 then
          if q.val < 174 then
            if q.val < 171 then
              if q.val < 169 then
                (⟨false, .right, some (174 : State)⟩, ⟨true, .right, some (168 : State)⟩) -- k:25
              else
                if q.val < 170 then
                  (⟨false, .left, some (179 : State)⟩, ⟨true, .left, some (164 : State)⟩) -- k:3
                else
                  (⟨false, .left, some (175 : State)⟩, ⟨false, .left, none⟩) -- k:302
            else
              if q.val < 172 then
                (⟨false, .right, some (177 : State)⟩, ⟨true, .right, some (171 : State)⟩) -- k:32
              else
                if q.val < 173 then
                  (⟨false, .right, some (171 : State)⟩, ⟨true, .right, some (172 : State)⟩) -- k:33
                else
                  (⟨true, .right, some (173 : State)⟩, ⟨true, .left, some (164 : State)⟩) -- k:35
          else
            if q.val < 177 then
              if q.val < 175 then
                (⟨false, .right, some (180 : State)⟩, ⟨true, .right, some (174 : State)⟩) -- k:36
              else
                if q.val < 176 then
                  (⟨true, .right, some (183 : State)⟩, ⟨false, .left, some (175 : State)⟩) -- k:4
                else
                  (⟨false, .left, some (175 : State)⟩, ⟨true, .left, some (181 : State)⟩) -- k:40
            else
              if q.val < 178 then
                (⟨false, .right, some (168 : State)⟩, ⟨true, .right, some (177 : State)⟩) -- k:48
              else
                if q.val < 179 then
                  (⟨false, .left, some (173 : State)⟩, ⟨false, .right, some (185 : State)⟩) -- k:49
                else
                  (⟨false, .left, some (189 : State)⟩, ⟨true, .left, some (164 : State)⟩) -- k:5
        else
          if q.val < 186 then
            if q.val < 183 then
              if q.val < 181 then
                (⟨false, .right, some (157 : State)⟩, ⟨true, .right, some (180 : State)⟩) -- k:51
              else
                if q.val < 182 then
                  (⟨false, .left, some (176 : State)⟩, ⟨true, .left, some (181 : State)⟩) -- k:54
                else
                  (⟨false, .right, some (165 : State)⟩, ⟨true, .right, some (182 : State)⟩) -- k:55
            else
              if q.val < 184 then
                (⟨false, .right, some (183 : State)⟩, ⟨false, .right, some (160 : State)⟩) -- k:6
              else
                if q.val < 185 then
                  (⟨false, .right, some (182 : State)⟩, ⟨true, .right, some (184 : State)⟩) -- k:60
                else
                  (⟨false, .right, some (187 : State)⟩, ⟨true, .right, some (185 : State)⟩) -- k:64
          else
            if q.val < 189 then
              if q.val < 187 then
                (⟨true, .left, some (181 : State)⟩, ⟨true, .right, some (163 : State)⟩) -- k:66
              else
                if q.val < 188 then
                  (⟨true, .right, some (159 : State)⟩, ⟨true, .right, some (185 : State)⟩) -- k:74
                else
                  (⟨false, .right, some (188 : State)⟩, ⟨true, .right, some (13 : State)⟩) -- k:75
            else
              if q.val < 190 then
                (⟨false, .left, some (162 : State)⟩, ⟨true, .left, some (164 : State)⟩) -- k:9
              else
                if q.val < 191 then
                  (⟨false, .right, some (186 : State)⟩, ⟨false, .right, some (159 : State)⟩) -- k:94
                else
                  (⟨true, .left, some (161 : State)⟩, ⟨true, .left, some (191 : State)⟩) -- k:97

def machine (q : State) (read : Bool) : Instruction 192 :=
  if read then (instructionPair q).2 else (instructionPair q).1

def renderBit (b : Bool) : String := if b then "1" else "0"
def renderDirection : Direction → String | .left => "L" | .right => "R"
def renderTarget : Option State → String | none => "halt" | some q => name q

def renderRow (q : State) (read : Bool) : String :=
  let row := machine q read
  name q ++ " " ++ renderBit read ++ " " ++ renderBit row.write ++ " " ++
    renderDirection row.move ++ " " ++ renderTarget row.next ++ "\n"

def serializedRows : List String :=
  (List.finRange 192).flatMap fun q => [renderRow q false, renderRow q true]

def literalRows : List String := [
  "a:CD:1 0 0 L d:71\n",
  "a:CD:1 1 1 L d:121\n",
  "a:CD:5 0 0 R k:24\n",
  "a:CD:5 1 0 R k:55\n",
  "a:CD:6 0 0 L d:18\n",
  "a:CD:6 1 1 L d:61\n",
  "a:CD:7 0 0 R k:24\n",
  "a:CD:7 1 0 R k:33\n",
  "a:CI:0 0 0 L d:40\n",
  "a:CI:0 1 0 R k:22\n",
  "a:CI:1 0 0 R k:49\n",
  "a:CI:1 1 0 R k:25\n",
  "a:CI:2 0 0 L d:40\n",
  "a:CI:2 1 0 R k:51\n",
  "a:CI:3 0 0 L d:40\n",
  "a:CI:3 1 0 R k:32\n",
  "a:CI:4 0 0 L d:40\n",
  "a:CI:4 1 0 R k:48\n",
  "a:CI:5 0 0 L d:61\n",
  "a:CI:5 1 1 L d:65\n",
  "a:CI:6 0 0 R k:49\n",
  "a:CI:6 1 0 R k:60\n",
  "a:CI:7 0 0 L d:61\n",
  "a:CI:7 1 1 L d:20\n",
  "a:CI:8 0 0 L d:40\n",
  "a:CI:8 1 0 R k:36\n",
  "d:0 0 0 R d:1\n",
  "d:0 1 1 R d:28\n",
  "d:1 0 0 R d:2\n",
  "d:1 1 1 R d:22\n",
  "d:10 0 0 R a:CD:6\n",
  "d:10 1 1 R d:11\n",
  "d:100 0 0 R d:87\n",
  "d:100 1 1 R d:67\n",
  "d:102 0 0 R d:103\n",
  "d:102 1 1 R d:105\n",
  "d:103 0 0 L d:84\n",
  "d:103 1 1 L d:112\n",
  "d:105 0 0 R d:85\n",
  "d:105 1 1 R d:100\n",
  "d:107 0 0 R d:108\n",
  "d:107 1 1 R d:112\n",
  "d:108 0 0 R d:109\n",
  "d:108 1 1 R d:105\n",
  "d:109 0 0 R d:110\n",
  "d:109 1 1 R d:111\n",
  "d:11 0 0 R a:CI:0\n",
  "d:11 1 0 L k16share:0\n",
  "d:110 0 0 R a:CI:1\n",
  "d:110 1 1 R d:98\n",
  "d:111 0 0 R d:103\n",
  "d:111 1 1 R d:85\n",
  "d:112 0 0 R d:113\n",
  "d:112 1 1 R d:98\n",
  "d:113 0 0 R d:114\n",
  "d:113 1 1 R d:99\n",
  "d:114 0 0 R d:44\n",
  "d:114 1 1 R d:115\n",
  "d:115 0 0 R a:CI:1\n",
  "d:115 1 1 R a:CD:1\n",
  "d:117 0 0 R d:118\n",
  "d:117 1 1 R d:119\n",
  "d:118 0 0 R d:43\n",
  "d:118 1 1 R d:103\n",
  "d:119 0 0 R d:120\n",
  "d:119 1 1 R d:123\n",
  "d:12 0 0 R d:13\n",
  "d:12 1 1 R d:20\n",
  "d:120 0 0 R d:121\n",
  "d:120 1 1 R d:74\n",
  "d:121 0 0 R a:CI:1\n",
  "d:121 1 1 R d:87\n",
  "d:123 0 0 R d:124\n",
  "d:123 1 1 R d:82\n",
  "d:124 0 0 R d:121\n",
  "d:124 1 1 R d:125\n",
  "d:125 0 0 R d:85\n",
  "d:125 1 1 R d:111\n",
  "d:126 0 0 R d:127\n",
  "d:126 1 1 R d:137\n",
  "d:127 0 0 R d:114\n",
  "d:127 1 1 R d:128\n",
  "d:128 0 0 R d:67\n",
  "d:128 1 1 R d:129\n",
  "d:129 0 0 R d:130\n",
  "d:129 1 1 R d:134\n",
  "d:13 0 0 R a:CI:8\n",
  "d:13 1 1 R d:14\n",
  "d:130 0 0 R d:114\n",
  "d:130 1 1 R d:131\n",
  "d:131 0 0 R d:96\n",
  "d:131 1 1 R d:135\n",
  "d:133 0 0 R d:85\n",
  "d:133 1 1 R d:121\n",
  "d:134 0 0 R d:135\n",
  "d:134 1 1 R d:136\n",
  "d:135 0 0 L d:84\n",
  "d:135 1 1 R d:133\n",
  "d:136 0 0 R d:87\n",
  "d:136 1 1 R d:74\n",
  "d:137 0 0 R d:138\n",
  "d:137 1 1 R d:139\n",
  "d:138 0 0 R a:CI:4\n",
  "d:138 1 0 L k16share:1\n",
  "d:139 0 0 R a:CD:5\n",
  "d:139 1 0 L k:2\n",
  "d:14 0 0 R d:15\n",
  "d:14 1 0 L k16share:0\n",
  "d:140 0 0 R d:141\n",
  "d:140 1 1 R d:142\n",
  "d:141 0 0 R a:CI:4\n",
  "d:141 1 1 R d:79\n",
  "d:142 0 0 R d:143\n",
  "d:142 1 1 R d:83\n",
  "d:143 0 0 R d:144\n",
  "d:143 1 1 R d:139\n",
  "d:144 0 0 R a:CD:5\n",
  "d:144 1 1 R d:145\n",
  "d:145 0 0 R a:CD:5\n",
  "d:145 1 1 R d:146\n",
  "d:146 0 0 R a:CD:5\n",
  "d:146 1 1 R a:CD:5\n",
  "d:148 0 0 R d:74\n",
  "d:148 1 1 R d:149\n",
  "d:149 0 0 R d:150\n",
  "d:149 1 1 R d:155\n",
  "d:15 0 0 R a:CI:7\n",
  "d:15 1 1 R d:16\n",
  "d:150 0 0 R d:45\n",
  "d:150 1 1 R d:151\n",
  "d:151 0 0 R a:CD:6\n",
  "d:151 1 1 R d:152\n",
  "d:152 0 0 R d:153\n",
  "d:152 1 1 R d:154\n",
  "d:153 0 0 R a:CD:5\n",
  "d:153 1 0 L k16share:0\n",
  "d:154 0 0 R a:CI:5\n",
  "d:154 1 1 R d:39\n",
  "d:155 0 0 R d:156\n",
  "d:155 1 1 R d:139\n",
  "d:156 0 0 R d:157\n",
  "d:156 1 1 R d:64\n",
  "d:157 0 0 R a:CD:5\n",
  "d:157 1 0 L k:302\n",
  "d:16 0 0 R d:17\n",
  "d:16 1 1 R d:18\n",
  "d:17 0 0 R a:CD:6\n",
  "d:17 1 0 L k:302\n",
  "d:18 0 0 R a:CD:7\n",
  "d:18 1 1 R d:19\n",
  "d:19 0 0 R a:CI:6\n",
  "d:19 1 0 L k16share:0\n",
  "d:2 0 0 R d:3\n",
  "d:2 1 1 R d:12\n",
  "d:20 0 0 R a:CD:7\n",
  "d:20 1 1 R d:21\n",
  "d:21 0 0 R a:CI:8\n",
  "d:21 1 0 L k16share:0\n",
  "d:22 0 0 R d:23\n",
  "d:22 1 1 R d:25\n",
  "d:23 0 0 R a:CD:6\n",
  "d:23 1 1 R d:24\n",
  "d:24 0 0 R a:CI:3\n",
  "d:24 1 0 L k16share:0\n",
  "d:25 0 0 R d:12\n",
  "d:25 1 1 R d:26\n",
  "d:26 0 0 R a:CD:6\n",
  "d:26 1 1 R d:138\n",
  "d:28 0 0 R d:29\n",
  "d:28 1 1 R d:148\n",
  "d:29 0 0 R a:CI:3\n",
  "d:29 1 1 R d:30\n",
  "d:3 0 0 R d:4\n",
  "d:3 1 1 R d:5\n",
  "d:30 0 0 R d:31\n",
  "d:30 1 0 L d:11\n",
  "d:31 0 0 R d:32\n",
  "d:31 1 1 R d:140\n",
  "d:32 0 0 R a:CI:3\n",
  "d:32 1 1 R d:33\n",
  "d:33 0 0 R d:34\n",
  "d:33 1 0 L k16share:0\n",
  "d:34 0 0 R d:35\n",
  "d:34 1 1 R d:88\n",
  "d:35 0 0 R d:12\n",
  "d:35 1 1 R d:36\n",
  "d:36 0 0 R d:37\n",
  "d:36 1 1 R d:82\n",
  "d:37 0 0 R d:38\n",
  "d:37 1 1 R d:73\n",
  "d:38 0 0 R d:39\n",
  "d:38 1 1 R d:41\n",
  "d:39 0 0 R a:CD:6\n",
  "d:39 1 1 R d:40\n",
  "d:4 0 0 R a:CI:8\n",
  "d:4 1 0 L k:302\n",
  "d:40 0 0 L d:152\n",
  "d:40 1 0 L k16share:0\n",
  "d:41 0 0 R d:42\n",
  "d:41 1 1 R d:66\n",
  "d:42 0 0 R d:43\n",
  "d:42 1 1 R d:63\n",
  "d:43 0 0 R d:44\n",
  "d:43 1 1 R d:59\n",
  "d:44 0 0 R d:45\n",
  "d:44 1 1 R d:46\n",
  "d:45 0 0 R a:CD:1\n",
  "d:45 1 1 R d:19\n",
  "d:46 0 0 R d:47\n",
  "d:46 1 1 R d:49\n",
  "d:47 0 0 R a:CI:2\n",
  "d:47 1 1 R a:CI:7\n",
  "d:49 0 0 R d:50\n",
  "d:49 1 1 R d:57\n",
  "d:5 0 0 R a:CI:0\n",
  "d:5 1 1 R d:6\n",
  "d:50 0 0 R d:51\n",
  "d:50 1 1 R d:53\n",
  "d:51 0 0 R a:CD:1\n",
  "d:51 1 1 R d:52\n",
  "d:52 0 0 R a:CI:7\n",
  "d:52 1 1 R a:CD:6\n",
  "d:53 0 0 R a:CD:6\n",
  "d:53 1 1 R d:54\n",
  "d:54 0 0 R d:55\n",
  "d:54 1 0 L d:11\n",
  "d:55 0 0 R a:CI:7\n",
  "d:55 1 1 R d:56\n",
  "d:56 0 0 L d:25\n",
  "d:56 1 1 R a:CI:7\n",
  "d:57 0 0 R a:CD:7\n",
  "d:57 1 1 R d:69\n",
  "d:59 0 0 R d:60\n",
  "d:59 1 1 R d:23\n",
  "d:6 0 0 R d:7\n",
  "d:6 1 1 R d:10\n",
  "d:60 0 0 R a:CI:3\n",
  "d:60 1 1 R d:61\n",
  "d:61 0 0 R a:CI:6\n",
  "d:61 1 1 R d:62\n",
  "d:62 0 0 R a:CI:1\n",
  "d:62 1 0 L d:11\n",
  "d:63 0 0 R d:44\n",
  "d:63 1 1 R d:64\n",
  "d:64 0 0 R d:65\n",
  "d:64 1 1 R d:26\n",
  "d:65 0 0 L d:137\n",
  "d:65 1 1 R d:61\n",
  "d:66 0 0 R d:25\n",
  "d:66 1 1 R d:67\n",
  "d:67 0 0 R d:68\n",
  "d:67 1 1 R d:70\n",
  "d:68 0 0 R d:69\n",
  "d:68 1 1 R d:57\n",
  "d:69 0 0 R a:CI:2\n",
  "d:69 1 1 L d:56\n",
  "d:7 0 0 R a:CI:0\n",
  "d:7 1 1 R d:8\n",
  "d:70 0 0 R d:50\n",
  "d:70 1 1 R d:71\n",
  "d:71 0 0 R a:CD:7\n",
  "d:71 1 1 R a:CI:5\n",
  "d:73 0 0 R d:74\n",
  "d:73 1 1 R d:75\n",
  "d:74 0 0 L d:102\n",
  "d:74 1 1 R d:67\n",
  "d:75 0 0 R d:76\n",
  "d:75 1 1 R d:78\n",
  "d:76 0 0 R d:63\n",
  "d:76 1 1 R d:77\n",
  "d:77 0 0 R d:78\n",
  "d:77 1 1 R d:79\n",
  "d:78 0 0 R d:43\n",
  "d:78 1 1 R d:67\n",
  "d:79 0 0 R d:80\n",
  "d:79 1 1 R d:39\n",
  "d:8 0 0 R a:CI:8\n",
  "d:8 1 1 R a:CD:6\n",
  "d:80 0 0 R d:44\n",
  "d:80 1 1 R d:65\n",
  "d:82 0 0 R d:83\n",
  "d:82 1 1 R d:84\n",
  "d:83 0 0 L d:100\n",
  "d:83 1 1 L d:77\n",
  "d:84 0 0 R d:85\n",
  "d:84 1 1 R d:86\n",
  "d:85 0 0 L d:75\n",
  "d:85 1 1 R d:86\n",
  "d:86 0 0 R d:79\n",
  "d:86 1 1 R d:87\n",
  "d:87 0 0 R d:67\n",
  "d:87 1 1 R a:CI:1\n",
  "d:88 0 0 R d:89\n",
  "d:88 1 1 R d:126\n",
  "d:89 0 0 R d:90\n",
  "d:89 1 1 R d:117\n",
  "d:90 0 0 R d:44\n",
  "d:90 1 1 R d:91\n",
  "d:91 0 0 R d:92\n",
  "d:91 1 1 R d:107\n",
  "d:92 0 0 R d:93\n",
  "d:92 1 1 R d:103\n",
  "d:93 0 0 R d:94\n",
  "d:93 1 1 R d:102\n",
  "d:94 0 0 R a:CI:1\n",
  "d:94 1 1 R d:97\n",
  "d:96 0 0 R d:97\n",
  "d:96 1 1 R d:100\n",
  "d:97 0 0 L d:130\n",
  "d:97 1 1 L d:109\n",
  "d:98 0 0 R d:99\n",
  "d:98 1 1 R d:86\n",
  "d:99 0 0 L d:75\n",
  "d:99 1 1 R d:87\n",
  "k16share:0 0 1 L k16share:1\n",
  "k16share:0 1 0 L k:2\n",
  "k16share:1 0 1 L d:137\n",
  "k16share:1 1 0 R k16share:1\n",
  "k:0 0 1 R k:94\n",
  "k:0 1 1 R k:0\n",
  "k:10 0 0 L k16share:0\n",
  "k:10 1 0 R k:10\n",
  "k:113 0 0 L k:302\n",
  "k:113 1 0 L k:97\n",
  "k:15 0 0 L k:23\n",
  "k:15 1 1 L k:2\n",
  "k:198 0 0 L k:97\n",
  "k:198 1 1 L k:54\n",
  "k:2 0 0 L k:3\n",
  "k:2 1 1 L k:2\n",
  "k:22 0 0 R k:33\n",
  "k:22 1 1 R k:22\n",
  "k:23 0 0 L k:75\n",
  "k:23 1 1 L k:2\n",
  "k:24 0 0 L k:35\n",
  "k:24 1 0 R k:0\n",
  "k:25 0 0 R k:36\n",
  "k:25 1 1 R k:25\n",
  "k:3 0 0 L k:5\n",
  "k:3 1 1 L k:2\n",
  "k:302 0 0 L k:4\n",
  "k:302 1 0 L halt\n",
  "k:32 0 0 R k:48\n",
  "k:32 1 1 R k:32\n",
  "k:33 0 0 R k:32\n",
  "k:33 1 1 R k:33\n",
  "k:35 0 1 R k:35\n",
  "k:35 1 1 L k:2\n",
  "k:36 0 0 R k:51\n",
  "k:36 1 1 R k:36\n",
  "k:4 0 1 R k:6\n",
  "k:4 1 0 L k:4\n",
  "k:40 0 0 L k:4\n",
  "k:40 1 1 L k:54\n",
  "k:48 0 0 R k:25\n",
  "k:48 1 1 R k:48\n",
  "k:49 0 0 L k:35\n",
  "k:49 1 0 R k:64\n",
  "k:5 0 0 L k:9\n",
  "k:5 1 1 L k:2\n",
  "k:51 0 0 R k16share:0\n",
  "k:51 1 1 R k:51\n",
  "k:54 0 0 L k:40\n",
  "k:54 1 1 L k:54\n",
  "k:55 0 0 R k:22\n",
  "k:55 1 1 R k:55\n",
  "k:6 0 0 R k:6\n",
  "k:6 1 0 R k:10\n",
  "k:60 0 0 R k:55\n",
  "k:60 1 1 R k:60\n",
  "k:64 0 0 R k:74\n",
  "k:64 1 1 R k:64\n",
  "k:66 0 1 L k:54\n",
  "k:66 1 1 R k:198\n",
  "k:74 0 1 R k:0\n",
  "k:74 1 1 R k:64\n",
  "k:75 0 0 R k:75\n",
  "k:75 1 1 R d:0\n",
  "k:9 0 0 L k:15\n",
  "k:9 1 1 L k:2\n",
  "k:94 0 0 R k:66\n",
  "k:94 1 0 R k:0\n",
  "k:97 0 1 L k:113\n",
  "k:97 1 1 L k:97\n"
]

theorem rows_match_literal : serializedRows = literalRows := by decide

def serializedTable : String := "#! start " ++ name start ++ "\n" ++ String.join serializedRows
def literalTable : String := "#! start k:64\n" ++ String.join literalRows

theorem table_matches_literal : serializedTable = literalTable := by
  have h : "#! start " ++ name start ++ "\n" = "#! start k:64\n" := by decide
  simp only [serializedTable, literalTable, rows_match_literal, h]

def sourceSHA256 : String := "ee1391964b35c7ad2f0db90305a84e09c6523f73f3dce6c4f31a182aa270d565"
theorem binary_row_count : serializedRows.length = 384 := by decide

theorem state_names : name start = "k:64" ∧ name decoderRoot = "d:0" ∧ name haltGate = "k:302" := by decide

/-- The whole transition table has exactly one edge entering halt. -/
theorem unique_halt : ∀ (q : State) (b : Bool),
    (machine q b).next = none ↔ q = haltGate ∧ b = true := by decide

def graphRun : State → List Bool → Option State
  | q, [] => some q
  | q, b :: bs => (machine q b).next.bind fun q' => graphRun q' bs

def graphPaths : Array (List Bool) := #[
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, true, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, false, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, true, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, true, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false, true, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false, true, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false, true, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, true, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, true, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, true, false, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, false, true, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, false, true, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, false, true, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, true, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, true, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, false, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, false, false, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, false, true, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, false, false, false, true, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, true, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, true, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, true, false, true, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, false, true, false, false, true, false, true, false, false, true, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, false, true, true],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, true, true, true, false, false, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, false],
  [false, false],
  [false, false, false, false, false, false, false, false, true],
  [false, false, false, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false],
  [false, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, true],
  [false, false, false, false, false, false, false, false, true, false, false, false, true, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, true, false],
  [false, false, false, false, false, false, false, false, true, false, true, false],
  [false, false, false, false, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, true, false, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, true, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, true, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, true, false, false],
  [false, false, false, false, false, false, false],
  [false, false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, true],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, true, false, false, false],
  [false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, true, false, true],
  [false, false, false, false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false, true],
  [],
  [false, false, false, false],
  [false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false],
  [false, false, false, false, false, false, false, false, true, false, true, false, false, false],
  [false, false, false],
  [false, false, false, false, true, false]
]
theorem graphPaths_size : graphPaths.size = 192 := by decide
def pathTo (q : State) : List Bool :=
  graphPaths[q.val]'(by simpa only [graphPaths_size] using q.isLt)

/-- Every declared state lies on a directed path from the start. -/
theorem all_graph_reachable : ∀ q, graphRun start (pathTo q) = some q := by decide

#print axioms table_matches_literal
#print axioms unique_halt
#print axioms all_graph_reachable

end NF192.Selected
