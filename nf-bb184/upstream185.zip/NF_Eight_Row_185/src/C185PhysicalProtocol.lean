module
public import Margin185
public import BinarySimulation
@[expose] public section
namespace C185.Physical
open NF192 NF210 NF192.Emitter NF192.Numerical NF192.BinarySimulation Eight187.Register
abbrev Signed := Bool × Source.Config
abbrev FrameRelation (n : Nat) := Bool → Relation n

def Related {n : Nat} (R : FrameRelation n) (s : Signed) (b : TM.Configuration n) : Prop :=
  BinarySimulation.Related (R s.1) s.2 b

structure Protocol {n : Nat} (M : TM.Machine n) (R : FrameRelation n) : Prop where
  live : ∀ cold s b, R cold s b → b.state ≠ none
  instruction : ∀ cold s b, R cold s b →
    ∃ ticks, 0 < ticks ∧ Related R (bootstrapStep (cold,some s)) (TM.run M ticks b)

theorem Protocol.one {n : Nat} {M : TM.Machine n} {R : FrameRelation n}
    (sim : Protocol M R) {s : Signed} {b : TM.Configuration n} (h : Related R s b) :
    ∃ ticks, 0 < ticks ∧ Related R (bootstrapStep s) (TM.run M ticks b) := by
  rcases s with ⟨cold,s⟩
  cases s with
  | some p => exact sim.instruction cold p b h
  | none =>
    have halt : b.state = none := h
    refine ⟨1,by decide,?_⟩
    rw [TM.run_of_halted M b halt]
    cases cold <;> exact halt

theorem Protocol.realize {n : Nat} {M : TM.Machine n} {R : FrameRelation n}
    (sim : Protocol M R) (k : Nat) {s : Signed} {b : TM.Configuration n} (entry : Related R s b) :
    ∃ ticks, k ≤ ticks ∧ Related R (bootstrapAdvance k s) (TM.run M ticks b) := by
  induction k generalizing s b with
  | zero => exact ⟨0,Nat.le_refl _,entry⟩
  | succ k ih =>
    obtain ⟨a,ha,hstep⟩ := sim.one entry
    obtain ⟨d,hd,hend⟩ := ih hstep
    exact ⟨a+d,by omega,by rw [TM.run_add]; exact hend⟩

theorem Protocol.halts_iff {n : Nat} {M : TM.Machine n} {R : FrameRelation n}
    (sim : Protocol M R) {s : Signed} {b : TM.Configuration n} (entry : Related R s b) :
    BinarySimulation.HaltsFrom M b ↔ BootstrapHalts s := by
  constructor
  · rintro ⟨k,hk⟩
    obtain ⟨d,hd,hend⟩ := sim.realize k entry
    have stopped : (TM.run M d b).state = none := by
      rw [←show k+(d-k)=d by omega,TM.run_add,TM.run_of_halted M _ hk]
      exact hk
    cases hs : (bootstrapAdvance k s).2 with
    | none => exact ⟨k,hs⟩
    | some p =>
      unfold Related at hend
      rw [hs] at hend
      exact False.elim (sim.live _ _ _ hend stopped)
  · rintro ⟨k,hk⟩
    obtain ⟨d,_,hend⟩ := sim.realize k entry
    unfold Related at hend
    rw [hk] at hend
    exact ⟨d,hend⟩


/-- A positive-step physical simulation starting at a specified actual initial state and run length. -/
def Realizes {n : Nat} (M : TM.Machine n) (start : Fin n) (cut : Nat) (s : Signed) : Prop :=
  ∃ R : FrameRelation n, Protocol M R ∧ Related R s (TM.run M cut (TM.blank start))

theorem blank_iff_signed_of_realizes {n : Nat} {M : TM.Machine n} {start : Fin n} {cut : Nat} {s : Signed}
    (h : Realizes M start cut s) : TM.Halts M start ↔ BootstrapHalts s := by
  obtain ⟨R,sim,entry⟩ := h
  exact (BinarySimulation.prefix_iff M (TM.blank start) cut).trans (sim.halts_iff entry)

theorem common_margin_origin {n : Nat} {M : TM.Machine n} {start : Fin n} {cut count : Nat}
    {margin : Emitter.Config} (link : bootstrapAdvance count (true,liftConfig origin) = (true,liftConfig margin))
    (realized : Realizes M start cut (true,liftConfig margin)) :
    TM.Halts M start ↔ BootstrapHalts (true,liftConfig origin) :=
  (blank_iff_signed_of_realizes realized).trans (bootstrap_halts_at link).symm
end C185.Physical
#print axioms C185.Physical.common_margin_origin
