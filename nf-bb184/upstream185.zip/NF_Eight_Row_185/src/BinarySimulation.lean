module
public import MachineSource
public import NF210.MachineSemantics

@[expose] public section

/-! Finite positive instruction simulations for the literal source and
ordinary integer-tape machine. The relation retains arbitrary geometry and
may restrict reachability. A halted source configuration corresponds to
every halted binary configuration, independently of its final tape. -/
namespace NF192.BinarySimulation

open NF210

universe u
variable {n : Nat}

abbrev Running := Nat × Source.Registers
abbrev Relation (n : Nat) := Running → TM.Configuration n → Prop

def Related (R : Relation n) : Source.Config → TM.Configuration n → Prop
  | none,b => b.state = none
  | some s,b => R s b

def HaltsFrom (M : TM.Machine n) (b : TM.Configuration n) : Prop :=
  ∃ ticks, (TM.run M ticks b).state = none

/-- One complete source instruction, including its zero-decrement halt,
is implemented by a strictly positive binary run. -/
structure Protocol (M : TM.Machine n) (R : Relation n) : Prop where
  live : ∀ s b, R s b → b.state ≠ none
  instruction : ∀ s b, R s b →
    ∃ ticks, 0 < ticks ∧ Related R (Source.step (some s)) (TM.run M ticks b)

theorem halted_source (ticks : Nat) : Source.advance ticks none = none := by
  induction ticks with
  | zero => rfl
  | succ k ih => exact ih

theorem Protocol.one {M : TM.Machine n} {R : Relation n} (sim : Protocol M R)
    {s : Source.Config} {b : TM.Configuration n} (h : Related R s b) :
    ∃ ticks, 0 < ticks ∧ Related R (Source.step s) (TM.run M ticks b) := by
  cases s with
  | some a => exact sim.instruction a b h
  | none =>
    have halt : b.state = none := h
    refine ⟨1,by decide,?_⟩
    change (TM.run M 1 b).state = none
    rw [TM.run_of_halted M b halt]
    exact halt

/-- After k source instructions, the related binary machine has executed
at least k transitions. This quantitative fact also gives reflection. -/
theorem Protocol.realize {M : TM.Machine n} {R : Relation n} (sim : Protocol M R)
    (k : Nat) {s : Source.Config} {b : TM.Configuration n} (entry : Related R s b) :
    ∃ ticks, k ≤ ticks ∧ Related R (Source.advance k s) (TM.run M ticks b) := by
  induction k generalizing s b with
  | zero => exact ⟨0,Nat.le_refl _,entry⟩
  | succ k ih =>
    obtain ⟨a,ha,hstep⟩ := sim.one entry
    obtain ⟨d,hd,hend⟩ := ih hstep
    refine ⟨a+d,by omega,?_⟩
    rw [TM.run_add]
    exact hend

theorem Protocol.halts_iff {M : TM.Machine n} {R : Relation n} (sim : Protocol M R)
    {s : Source.Config} {b : TM.Configuration n} (entry : Related R s b) :
    HaltsFrom M b ↔ ∃ k, Source.advance k s = none := by
  constructor
  · rintro ⟨k,hk⟩
    obtain ⟨d,hd,hr⟩ := sim.realize k entry
    have late : (TM.run M d b).state = none := by
      have add : k+(d-k)=d := by omega
      rw [←add,TM.run_add,TM.run_of_halted M _ hk]
      exact hk
    cases hsource : Source.advance k s with
    | none => exact ⟨k,hsource⟩
    | some active =>
      rw [hsource] at hr
      exact False.elim (sim.live active _ hr late)
  · rintro ⟨k,hk⟩
    obtain ⟨d,_,hr⟩ := sim.realize k entry
    rw [hk] at hr
    exact ⟨d,hr⟩

/-- An exact finite startup prefix preserves and reflects eventual halting,
even if an earlier step already entered the absorbing halt. -/
theorem prefix_iff (M : TM.Machine n) (b : TM.Configuration n) (warm : Nat) :
    HaltsFrom M b ↔ HaltsFrom M (TM.run M warm b) := by
  constructor
  · rintro ⟨k,hk⟩
    refine ⟨k,?_⟩
    rw [←TM.run_add,Nat.add_comm warm k,TM.run_add,TM.run_of_halted M _ hk]
    exact hk
  · rintro ⟨k,hk⟩
    exact ⟨warm+k,by simpa only [TM.run_add] using hk⟩

/-- Compose startup from the blank tape, positive instruction simulation,
and an independently proved calibration of the chosen source entry. -/
theorem blank_iff_of_calibration {M : TM.Machine n} {R : Relation n}
    (sim : Protocol M R) (start : Fin n) (warm : Nat) (s : Source.Config) {P : Prop}
    (entry : Related R s (TM.run M warm (TM.blank start)))
    (source : (∃ k, Source.advance k s = none) ↔ P) :
    TM.Halts M start ↔ P :=
  (prefix_iff M (TM.blank start) warm).trans ((sim.halts_iff entry).trans source)

end NF192.BinarySimulation

#print axioms NF192.BinarySimulation.Protocol.halts_iff
#print axioms NF192.BinarySimulation.blank_iff_of_calibration
