import CompactEquivalence
open NF192.Ground
namespace NF196.Compact
structure Rows {X : Type} (S : Signature X) (r : X → X → Prop) : Prop where
  argCongr : ∀ a b c, r c b → r (S.app a c) (S.app a b)
  kLaw : ∀ a b, r (S.app (S.k b) a) b
  funCongr : ∀ a b c, r a c → r (S.app c b) (S.app a b)
  bLaw : ∀ a b c, r (S.app (S.app (S.app (S.s) c) a) b)
    (S.app (S.app c (S.k b)) (S.app a b))
  euclid : ∀ a b c, r a b → r a c → r c b
  test : ∀ x y, (r (S.app (S.app S.q (S.k x)) y) S.s → r (S.app (S.app S.q (S.k x)) x) S.s) → r x y
  ext : ∀ a b, r (S.app b (S.h a b)) (S.app a (S.h a b)) → r a b
namespace Rows
variable {X : Type} {S : Signature X} {r : X → X → Prop} (R : Rows S r)
include R
theorem rel_refl (a : X) : r a a :=
  R.euclid _ a a (R.kLaw S.q a) (R.kLaw S.q a)

theorem rel_symm {a b : X} (h : r a b) : r b a :=
  R.euclid a a b (R.rel_refl a) h

theorem rel_trans {a b c : X} (hab : r a b) (hbc : r b c) : r a c :=
  R.euclid b c a hbc (R.rel_symm hab)

theorem app_congr {a b c d : X} (hac : r a c) (hbd : r b d) :
    r (S.app a b) (S.app c d) :=
  R.rel_trans (R.rel_symm (R.funCongr a b c hac)) (R.argCongr c d b hbd)

theorem k_congr {a b : X} (hab : r a b) : r (S.k a) (S.k b) := by
  let d := S.h (S.k a) (S.k b)
  have h : r (S.app (S.k a) d) (S.app (S.k b) d) :=
    R.rel_trans (R.rel_trans (R.kLaw d a) hab) (R.rel_symm (R.kLaw d b))
  exact R.ext (S.k a) (S.k b) (R.rel_symm h)

def setoid : Setoid X where
  r := r
  iseqv := ⟨R.rel_refl, R.rel_symm, R.rel_trans⟩

def Carrier : Type := Quotient R.setoid

def obj (a : X) : R.Carrier := Quotient.mk R.setoid a

theorem obj_eq_iff {a b : X} : R.obj a = R.obj b ↔ r a b :=
  ⟨fun h => Quotient.exact h, fun h => Quotient.sound (s := R.setoid) h⟩

def appObj (a b : R.Carrier) : R.Carrier :=
  Quotient.liftOn₂ a b (fun x y => R.obj (S.app x y))
    (fun _ _ _ _ hx hy => Quotient.sound (s := R.setoid) (R.app_congr hx hy))

def kObj (a : R.Carrier) : R.Carrier :=
  Quotient.liftOn a (fun x => R.obj (S.k x))
    (fun _ _ h => Quotient.sound (s := R.setoid) (R.k_congr h))

theorem app_obj (a b : X) : R.appObj (R.obj a) (R.obj b) = R.obj (S.app a b) := rfl

theorem k_obj (a : X) : R.kObj (R.obj a) = R.obj (S.k a) := rfl

theorem kObj_app (a b : R.Carrier) : R.appObj (R.kObj a) b = a := by
  refine Quotient.inductionOn₂ a b ?_
  intro x y
  exact R.obj_eq_iff.mpr (R.kLaw y x)

theorem bObj_app (x y z : R.Carrier) :
    R.appObj (R.appObj (R.appObj (R.obj (S.s)) x) y) z =
    R.appObj (R.appObj x (R.kObj z)) (R.appObj y z) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn z ?_
  intro c
  exact R.obj_eq_iff.mpr (R.bLaw b c a)

theorem appObj_ext {a b : R.Carrier} (h : ∀ x, R.appObj a x = R.appObj b x) :
    a = b := by
  revert h
  refine Quotient.inductionOn₂ a b ?_
  intro x y h
  exact R.obj_eq_iff.mpr
    (R.ext x y (R.rel_symm (R.obj_eq_iff.mp (h (R.obj (S.h x y))))))

def basis : NF188.Relabel.Basis R.Carrier :=
  ⟨R.appObj,R.kObj,R.obj S.s,R.kObj_app,R.bObj_app,R.appObj_ext⟩

theorem testObj (x y : R.Carrier) :
    (NF196.Weak.diag R.basis (R.obj S.q) x y=R.obj S.s →
      NF196.Weak.diag R.basis (R.obj S.q) x x=R.obj S.s) → x=y := by
  revert y
  refine Quotient.inductionOn x ?_
  intro a y
  refine Quotient.inductionOn y ?_
  intro b h
  apply R.obj_eq_iff.mpr
  apply R.test
  intro e
  exact R.obj_eq_iff.mp (h (R.obj_eq_iff.mpr e))

def toChart (h : ¬r S.s S.q) : Chart R.Carrier := by
  let ne : R.obj S.s≠R.obj S.q := fun e => h (R.obj_eq_iff.mp e)
  obtain ⟨off,on⟩ := (partial_iff R.basis (R.obj S.q) (R.obj S.s) ne.symm).mp R.testObj
  exact {toBasis := R.basis,J := R.obj S.q,letter := rfl,proper := ne,off := off,on := on}
end Rows

namespace Chart
variable {V : Type} (A : Chart V)
local infixl:70 " ⬝ " => A.app
theorem exists_sep {x y : V} (ne : x≠y) : ∃ t, x ⬝ t≠y ⬝ t := by
  by_contra! n
  exact ne (A.ext n)
noncomputable def witness (x y : V) : V := by
  classical exact if h : x=y then A.K x else Classical.choose (A.exists_sep h)
theorem witness_diag (x : V) : A.witness x x=A.K x := by classical simp [witness]
theorem witness_ext (x y : V) (h : y ⬝ A.witness x y=x ⬝ A.witness x y) : x=y := by
  classical
  by_contra n
  exact (Classical.choose_spec (A.exists_sep n)) (by simpa only [witness,dif_neg n] using h.symm)
noncomputable def eval : Term → V
  | .q => A.J
  | .app f x => A.app (eval f) (eval x)
  | .h x y => A.witness (eval x) (eval y)
def relation (a b : Term) := A.eval a=A.eval b
theorem eval_s : A.eval Term.signature.s=A.B := A.letter
theorem term_rows : Rows Term.signature A.relation := by
  constructor
  · intro a b c e; exact congrArg (A.app (A.eval a)) e
  · intro x y; change A.app (A.witness _ _) _ = _; rw [witness_diag,A.k_app]
  · intro a b c h; exact congrArg (fun x => A.app x (A.eval b)) h.symm
  · intro a b c
    change (((A.eval Term.signature.s ⬝ _) ⬝ _) ⬝ _) = (_ ⬝ A.witness _ _) ⬝ _
    rw [eval_s,witness_diag,A.b_app]
    rfl
  · intro a b c e d; exact d.symm.trans e
  · intro x y h
    apply (partial_iff A.toBasis A.J A.B A.proper.symm).mpr ⟨A.off,A.on⟩
    change ((A.J ⬝ A.K (A.eval x)) ⬝ A.eval y = A.B) → (A.J ⬝ A.K (A.eval x)) ⬝ A.eval x = A.B
    change ((A.J ⬝ A.witness (A.eval x) (A.eval x)) ⬝ A.eval y = A.eval Term.signature.s) →
      (A.J ⬝ A.witness (A.eval x) (A.eval x)) ⬝ A.eval x = A.eval Term.signature.s at h
    simpa only [witness_diag,eval_s] using h
  · intro a b h; exact A.witness_ext _ _ h
end Chart
end NF196.Compact
#print axioms NF196.Compact.Rows.toChart
#print axioms NF196.Compact.Chart.term_rows
