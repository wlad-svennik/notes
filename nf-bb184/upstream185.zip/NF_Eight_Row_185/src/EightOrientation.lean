import EightSeed
import DominatedImplication
open SetTheory.BusyBeaver.ZFC NF192.Numerical NF192.Emitter C196Compact

namespace EightOrientation

private def lang : DominatedImplication.Language Nat where
  imp := imp
  below := Nat.le
  refl := Nat.le_refl
  grow_left := fun y h => Nat.le_trans h (imp_ge_left _ y)
  grow_right := fun x h => Nat.le_trans h (imp_ge_right x _)

structure Rules (D : Nat → Prop) : Prop where
  mp : ∀ {x y}, D (imp x y) → D x → D y
  rho : ∀ a b c u, u ≤ a → D (row0 a b c u)
  k : ∀ a b, D (row4 a b)
  e : ∀ a b c, D (row6 a b c)

namespace Rules
variable {D : Nat → Prop} (h : Rules D)
include h

private theorem restrict : DominatedImplication.Restricted lang D where
  mp := h.mp
  rho8 := h.rho

private theorem join {u v w : Nat} (x : D (imp u v)) (y : D (imp v w)) : D (imp u w) :=
  h.mp (h.mp (DominatedImplication.composition h.restrict u v w) x) y

private theorem mapImp {a b c d : Nat} (left : D (imp c a)) (right : D (imp b d)) :
    D (imp (imp a b) (imp c d)) := by
  have contra : D (imp (imp a b) (imp c b)) :=
    h.mp (DominatedImplication.composition h.restrict c a b) left
  have weak : D (imp c (imp b d)) :=
    h.mp (DominatedImplication.k h.restrict (imp b d) c) right
  have post : D (imp (imp c b) (imp c d)) :=
    h.mp (DominatedImplication.s h.restrict c b d) weak
  exact h.join contra post

private theorem reverse (x y : Nat) : D (imp (eqn x y) (eqn y x)) := by
  have k : D (eqn (app (konst x) 0) x) := h.k 0 x
  have refl : D (eqn x x) := h.mp (h.mp (h.e _ x x) k) k
  exact h.mp (h.e x x y) refl

theorem toSeed (x y : Nat) (v : D (testRow x y)) : D (C196EightSeed.test x y) :=
  h.mp (h.mapImp (h.mapImp (h.reverse _ _) (h.reverse _ _)) (h.reverse _ _)) v

theorem fromSeed (x y : Nat) (v : D (C196EightSeed.test x y)) : D (testRow x y) :=
  h.mp (h.mapImp (h.mapImp (h.reverse _ _) (h.reverse _ _)) (h.reverse _ _)) v

end Rules
end EightOrientation
#print axioms EightOrientation.Rules.toSeed
