module
public import P185MachineControlKernelExecution

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-!
# Whole-word contracts with arbitrary internal head positions

This adds no machine assumptions. A contract is an exact execution theorem
with a fixed finite word replaced, arbitrary outside tape, arbitrary integer
translation, and explicit initial/final head offsets and duration.
-/

namespace P185.KernelRightShift

open NF210 NF210.TM
open CS185.Table (State machine)
open P185.KernelExecution

structure WordRun (first last : State) (input output : List Bool)
    (initial final : Int) (duration : Nat) : Prop where
  same_length : input.length = output.length
  exact_run : ∀ (anchor : Int) (outside : Tape),
    TM.run machine duration
      (configuration first (anchor + initial) (wordTape anchor input outside)) =
      configuration last (anchor + final) (wordTape anchor output outside)

theorem WordRun.trans {first middle last : State} {input intermediate output : List Bool}
    {initial middleHead final : Int} {firstTime secondTime : Nat}
    (one : WordRun first middle input intermediate initial middleHead firstTime)
    (two : WordRun middle last intermediate output middleHead final secondTime) :
    WordRun first last input output initial final (firstTime + secondTime) := by
  constructor
  · exact one.same_length.trans two.same_length
  · intro anchor outside
    rw [TM.run_add, one.exact_run, two.exact_run]

theorem WordRun.context {first last : State} {input output : List Bool}
    {initial final : Int} {duration : Nat}
    (certificate : WordRun first last input output initial final duration)
    (front suffix : List Bool) :
    WordRun first last (front ++ input ++ suffix) (front ++ output ++ suffix)
      ((front.length : Int) + initial) ((front.length : Int) + final) duration := by
  constructor
  · simp only [List.length_append, certificate.same_length]
  · intro anchor outside
    have firstPosition : anchor + ((front.length : Int) + initial) =
        anchor + (front.length : Int) + initial := by omega
    have lastPosition : anchor + ((front.length : Int) + final) =
        anchor + (front.length : Int) + final := by omega
    rw [firstPosition, lastPosition, List.append_assoc, wordTape_append]
    rw [wordTape_commute anchor (anchor + (front.length : Int)) front (input ++ suffix)
      outside (Int.le_refl _)]
    rw [wordTape_append, certificate.exact_run]
    rw [certificate.same_length]
    rw [← wordTape_append]
    rw [← wordTape_commute anchor (anchor + (front.length : Int)) front (output ++ suffix)
      outside (Int.le_refl _)]
    rw [← wordTape_append, ← List.append_assoc]

theorem RightRun.asWordRun {first last : State} {input output : List Bool}
    (certificate : RightRun first last input output) :
    WordRun first last input output 0 (input.length : Int) input.length := by
  constructor
  · exact certificate.same_length
  · intro anchor outside
    simpa using certificate.exact_run anchor outside

theorem LeftRun.asWordRun {first last : State} {input output : List Bool}
    (certificate : LeftRun first last input output) :
    WordRun first last input output ((input.length : Int) - 1) (-1) input.length := by
  constructor
  · exact certificate.same_length
  · intro anchor outside
    have firstPosition : anchor + (input.length : Int) - 1 =
        anchor + ((input.length : Int) - 1) := by omega
    have lastPosition : anchor - 1 = anchor + (-1) := by omega
    simpa only [firstPosition, lastPosition] using certificate.exact_run anchor outside

theorem WordRun.reaches {first last : State} {input output : List Bool}
    {initial final : Int} {duration : Nat}
    (certificate : WordRun first last input output initial final duration)
    (anchor : Int) (outside : Tape) :
    Reaches (configuration first (anchor + initial) (wordTape anchor input outside))
      (configuration last (anchor + final) (wordTape anchor output outside)) :=
  Reaches.of_run (certificate.exact_run anchor outside)

theorem WordRun.progress {first last : State} {input output : List Bool}
    {initial final : Int} {duration : Nat}
    (certificate : WordRun first last input output initial final duration)
    (positive : 0 < duration) (anchor : Int) (outside : Tape) :
    Progress (configuration first (anchor + initial) (wordTape anchor input outside))
      (configuration last (anchor + final) (wordTape anchor output outside)) :=
  Progress.of_run positive (certificate.exact_run anchor outside)

#print axioms WordRun.context

end P185.KernelRightShift
