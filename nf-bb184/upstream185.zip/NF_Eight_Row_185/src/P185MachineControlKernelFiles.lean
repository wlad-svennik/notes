module
public import P185MachineControlKernelReverse

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-! Physical-order unary-file forms for the proved reverse routines. -/

namespace P185.KernelFiles

open P185.KernelRightShift

/-- Positive one-runs with their trailing separators, in physical left-to-right order. -/
def terminatedRuns : List Nat → List Bool
  | [] => []
  | value :: rest => List.replicate (value + 1) true ++ false :: terminatedRuns rest

theorem blocks_append (left right : List Nat) :
    blocks (left ++ right) = blocks left ++ blocks right := by
  induction left with
  | nil => rfl
  | cons value rest ih => simp [blocks, ih, List.append_assoc]

theorem blocks_terminated (values : List Nat) :
    blocks values ++ [false] = false :: terminatedRuns values := by
  induction values with
  | nil => rfl
  | cons value rest ih => simp [blocks, terminatedRuns, List.append_assoc, ih]

theorem header_terminated (headerExtra : Nat) (values : List Nat) :
    List.replicate (headerExtra + 1) true ++ blocks values ++ [false] =
      terminatedRuns (headerExtra :: values) := by
  rw [List.append_assoc, blocks_terminated]
  rfl

theorem reverse_blocks (values : List Nat) :
    (blocks values.reverse).reverse = terminatedRuns values := by
  induction values with
  | nil => rfl
  | cons value rest ih =>
    rw [List.reverse_cons, blocks_append, List.reverse_append, ih]
    simp [blocks, terminatedRuns, List.append_assoc]

theorem reverse_input (values : List Nat) :
    (shiftInput 0 values.reverse).reverse = [false, false] ++ terminatedRuns values := by
  simp [shiftInput, reverse_blocks]

theorem reverse_output (values : List Nat) :
    (shiftOutput 0 values.reverse).reverse = [false] ++ terminatedRuns values ++ [true] := by
  simp [shiftOutput, reverse_blocks]

/-- The reverse search in physical register order. -/
theorem find_file (values : List Nat) :
    LeftRun KernelReverse.searchState KernelReverse.searchEndState
      ([false, false] ++ terminatedRuns values) ([false, false] ++ terminatedRuns values) := by
  simpa only [reverse_input] using KernelReverse.find_double_zero 0 values.reverse

/-- The undo operation in physical register order. -/
theorem undo_file (values : List Nat) :
    LeftRun KernelReverse.undoState KernelReverse.undoEndState
      ([false, false] ++ terminatedRuns values) ([false] ++ terminatedRuns values ++ [true]) := by
  simpa only [reverse_input, reverse_output] using KernelReverse.undo_shift 0 values.reverse

#print axioms find_file
#print axioms undo_file

end P185.KernelFiles
