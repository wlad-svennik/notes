module
public import P185MachineSource
public meta import P185MachineSource
public import Eight187Raw
public meta import Eight187Raw
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P185.Source
/-- Every raw decoded register command is compared to the total CFG used by the logic proof. -/
private theorem agreement : (List.range siteCount).all (fun i => decide (program i = Eight187.Raw.program i)) = true := by native_decide
theorem eq_raw (pc : Nat) (h : pc < siteCount) : program pc = Eight187.Raw.program pc := of_decide_eq_true ((List.all_eq_true.mp agreement) pc (List.mem_range.mpr h))
end P185.Source
#print axioms P185.Source.eq_raw
