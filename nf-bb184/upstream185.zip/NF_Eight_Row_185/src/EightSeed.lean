import CompactModel
import NumericalEmitterBatch
namespace C196EightSeed
open NF192.Numerical NF192.Emitter C196Compact SetTheory.BusyBeaver.ZFC

def test (x y : Nat) := imp (imp (eqn s (single x y)) (eqn s (single x x))) (eqn y x)
def testTokens : List Macro :=
 [.push0,.incTop,.push0,.push5,.push5,.witness,.ap,.push4,.ap,.eqn,
  .push0,.incTop,.push0,.push5,.push5,.witness,.ap,.push5,.ap,.eqn,
  .imp,.push4,.push5,.eqn,.imp]
def bTokens : List Macro :=
 [.push0,.incTop,.push3,.ap,.push4,.ap,.push5,.ap,.push3,.push5,.push5,
  .witness,.ap,.push4,.push5,.ap,.ap,.eqn]

theorem effectTest (n t stack c a b tail : Nat) :
    testTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
    ⟨n,test b a,pair t stack,c,a,b,tail⟩ := by
  simp only [testTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push,
    Frame.combine,Cantor.unpair_pair,ctor,test,single,s_is_one,q,imp,eqn,app,witness]
  <;> rfl

theorem effectB (n t stack c a b tail : Nat) :
    bTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
    ⟨n,bRow a b c,pair t stack,c,a,b,tail⟩ := by
  simp only [bTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push,
    Frame.combine,Cantor.unpair_pair,ctor,bRow,s_is_one,q,imp,eqn,app,witness]
  <;> rfl

def eight (a b c u : Nat) := [row0 a b c u,row4 a b,bRow a b c,row2 a b c,
  row3 a b c,row6 a b c,test b a,row9 a b]
def hold (r : Nat → Nat → Prop) : Prop :=
  ∀ a b c u, u ≤ a → ∀ x ∈ eight a b c u, evaluate r x

theorem exchange {r : Nat → Nat → Prop} (sym : ∀ x y, r x y → r y x) (x y : Nat) :
    evaluate r (test x y) ↔ evaluate r (testRow x y) := by
  simp only [test,testRow,evaluate_imp,evaluate_eqn]
  constructor
  · intro h k
    exact sym _ _ (h (fun g => sym _ _ (k (sym _ _ g))))
  · intro h k
    exact sym _ _ (h (fun g => sym _ _ (k (sym _ _ g))))

theorem holds_iff (r : Nat → Nat → Prop) : hold r ↔ RowsHold r := by
  constructor
  · intro h
    have k (a b : Nat) : r (app (konst b) a) b := by
      have := h a b 0 0 (Nat.zero_le _) (row4 a b) (by simp [eight])
      simpa only [row4,evaluate_eqn] using this
    have e (a b c : Nat) : r a b → r a c → r c b := by
      have := h a b c 0 (Nat.zero_le _) (row6 a b c) (by simp [eight])
      simpa only [row6,evaluate_imp,evaluate_eqn] using this
    have refl (a : Nat) : r a a := e _ _ _ (k 0 a) (k 0 a)
    have sym (a b : Nat) (z : r a b) : r b a := e a a b (refl a) z
    intro a b c u hu x hx
    simp only [C196Compact.rowList,List.mem_cons,List.not_mem_nil,or_false] at hx
    rcases hx with hx|hx|hx|hx|hx|hx|hx|hx <;> subst x
    · exact h a b c u hu _ (by simp [eight])
    · exact h a b c u hu _ (by simp [eight])
    · exact h a b c u hu _ (by simp [eight])
    · exact h a b c u hu _ (by simp [eight])
    · exact h a b c u hu _ (by simp [eight])
    · exact (exchange sym a b).mp (h b a c 0 (Nat.zero_le _) _ (by simp [eight]))
    · exact h a b c u hu _ (by simp [eight])
    · exact h a b c u hu _ (by simp [eight])
  · intro h
    have R := (hold_iff_rows r).mp h
    have sym (a b : Nat) (z : r a b) : r b a := R.rel_symm z
    intro a b c u hu x hx
    simp only [eight,List.mem_cons,List.not_mem_nil,or_false] at hx
    rcases hx with hx|hx|hx|hx|hx|hx|hx|hx <;> subst x
    · exact h a b c u hu _ (by simp [C196Compact.rowList])
    · exact h a b c u hu _ (by simp [C196Compact.rowList])
    · exact h a b c u hu _ (by simp [C196Compact.rowList])
    · exact h a b c u hu _ (by simp [C196Compact.rowList])
    · exact h a b c u hu _ (by simp [C196Compact.rowList])
    · exact h a b c u hu _ (by simp [C196Compact.rowList])
    · exact (exchange sym b a).mpr (h b a c 0 (Nat.zero_le _) _ (by simp [C196Compact.rowList]))
    · exact h a b c u hu _ (by simp [C196Compact.rowList])
end C196EightSeed
#print axioms C196EightSeed.holds_iff
