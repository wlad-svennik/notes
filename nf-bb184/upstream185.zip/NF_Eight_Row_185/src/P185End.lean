module
public import P185Signed
public meta import P185Signed
public import P185MachineOpcode
public meta import P185MachineOpcode
public import P185MachineCanonicalControl
public meta import P185MachineCanonicalControl
public import P185MachinePhysicalArithmetic
public meta import P185MachinePhysicalArithmetic
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P185.Physical
open NF210 NF210.TM P185.Frame Eight187.Register
private theorem realize_return (cold : Bool) (f : Layout) (rs : NF192.Source.Registers)
    {warm : Bool} {pc : Nat} {us raw : Nat → Nat}
    (future : CanWarm (cold,NF192.Source.Config.active f.pc rs))
    (st : bootstrapStep (cold,NF192.Source.Config.active f.pc rs) = (warm,NF192.Source.Config.active pc us))
    (ret : Returns f pc raw) (val : ∀ j : Fin 9, raw j.val = rawValue warm us j.val) :
    ∃ ticks, 0 < ticks ∧ C185.Physical.Related Rel
      (bootstrapStep (cold,NF192.Source.Config.active f.pc rs)) (TM.run CS185.Table.machine ticks f.config) := by
  obtain ⟨g,ticks,pos,trace,good,target,vals⟩ := ret
  have h := future.step
  rw [st] at h
  refine ⟨ticks,pos,?_⟩
  rw [trace,st]
  exact ⟨g,⟨good,target,fun j => (vals j).trans (val j),h⟩,rfl⟩

theorem protocol (arith : Arithmetic) : C185.Physical.Protocol CS185.Table.machine Rel := by
  constructor
  · rintro cold s _ ⟨f,_,rfl⟩
    exact Option.some_ne_none _
  · rintro cold ⟨pc,rs⟩ _ ⟨f,⟨good,hpc,raw,warm⟩,rfl⟩
    change f.pc = pc at hpc
    subst pc
    change ∃ ticks, 0 < ticks ∧ C185.Physical.Related Rel
      (bootstrapStep (cold,NF192.Source.Config.active f.pc rs)) (TM.run CS185.Table.machine ticks f.config)
    have agree := P185.Source.eq_raw f.pc good.inRange
    cases op : P185.Source.program f.pc with
    | inl v =>
      rcases v with ⟨r,n⟩
      have bounds := (Opcode.inc good.inRange op).2.1
      let reg : Fin 9 := ⟨r,bounds⟩
      exact realize_return cold f rs warm (inc_step cold f.pc n reg rs (agree.symm.trans op))
        (arith.inc f reg n good op) (inc_values cold reg rs f raw)
    | inr v =>
      cases v with
      | inr n =>
        have ctrl := Opcode.jump good.inRange op
        obtain ⟨next,ticks,bound,cmd,pos,trace⟩ :=
          CanonicalControl.control_step f good.inRange (by have := good.margin; omega) ctrl
        have eq : next = n := by simpa only [op,Sum.inr.injEq] using cmd.symm
        subst next
        let g := {f with pc := n}
        have ret : Returns f n f.storedAt :=
          ⟨g,ticks,pos,trace,⟨⟨bound,good.margin,good.nine⟩,rfl,fun _ => rfl⟩⟩
        exact realize_return cold f rs warm (jump_step cold f.pc n rs (agree.symm.trans op)) ret raw
      | inl d =>
        rcases d with ⟨r,z,n,halt⟩
        let reg : Fin 9 := ⟨r,(Opcode.dec good.inRange op).2.1⟩
        have allowed : cold = true → reg.val ≠ 0 := by
          intro yes
          subst cold
          exact dec_cold_impossible f.pc z n reg halt rs (agree.symm.trans op) warm
        have rv : f.storedAt reg.val = rs reg.val + 1 := by
          rw [raw reg]
          cases cold <;> simp_all [rawValue]
        have exe := dec_step cold f.pc z n reg halt rs (agree.symm.trans op) allowed
        cases hr : rs reg.val with
        | zero =>
          have zero : f.storedAt reg.val = 1 := by omega
          cases halt with
          | false =>
            have st : bootstrapStep (cold,NF192.Source.Config.active f.pc rs) =
                (cold,NF192.Source.Config.active z rs) := by
              simpa only [NF192.Source.execute,hr,Bool.false_eq_true,ite_false] using exe
            exact realize_return cold f rs warm st (arith.zero f reg z n good op zero) raw
          | true =>
            have st : bootstrapStep (cold,NF192.Source.Config.active f.pc rs) =
                (cold,NF192.Source.Config.halted) := by
              simpa only [NF192.Source.execute,hr,ite_true] using exe
            obtain ⟨ticks,pos,stop⟩ := arith.halt f reg z n good op zero
            exact ⟨ticks,pos,st ▸ stop⟩
        | succ k =>
          have pos : 2 ≤ f.storedAt reg.val := by omega
          have st : bootstrapStep (cold,NF192.Source.Config.active f.pc rs) =
              (cold,NF192.Source.Config.active n (NF192.Source.setReg rs reg.val k)) := by
            simpa only [NF192.Source.execute,hr] using exe
          exact realize_return cold f rs warm st (arith.positive f reg z n halt good op pos)
            (dec_values cold reg rs f k hr allowed raw)


theorem realizes : CS185.PhysicalRealization := ⟨Rel,protocol arithmetic,margin_entry⟩

theorem signed_halts_iff :
    TM.Halts CS185.Table.machine CS185.Table.start ↔ BootstrapHalts (true, NF192.Emitter.liftConfig origin) :=
  CS185.blank_iff_origin realizes
end P185.Physical
#print axioms P185.Physical.realizes
#print axioms P185.Physical.signed_halts_iff
