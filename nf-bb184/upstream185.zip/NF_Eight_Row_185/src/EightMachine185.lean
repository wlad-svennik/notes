import P185End
import Eight187Cold
namespace NFMachine185
open NF210 NF192.Numerical

theorem halts_iff_eight_row_goal :
    TM.Halts CS185.Table.machine CS185.Table.start ↔ Eight187.Deriv goal :=
  P185.Physical.signed_halts_iff.trans Eight187.Register.signed_source_halts_iff_goal
end NFMachine185
#print axioms NFMachine185.halts_iff_eight_row_goal
