module
public import NumericalEmitterBatch
public import C188ChartRows
@[expose] public section
namespace Eight187.Seed
open NF192.Numerical NF192.Emitter SetTheory.BusyBeaver.ZFC
def single (x y : Nat) := app (app q (witness x x)) y
def bRow (a b c : Nat) := eqn (app (app (app s c) a) b) (app (app c (witness b b)) (app a b))
def test (x y : Nat) := imp (imp (eqn s (single x y)) (eqn s (single x x))) (eqn y x)
def testTokens : List Macro :=
 [.push0,.incTop,.push0,.push5,.push5,.witness,.ap,.push4,.ap,.eqn,
  .push0,.incTop,.push0,.push5,.push5,.witness,.ap,.push5,.ap,.eqn,
  .imp,.push4,.push5,.eqn,.imp]
def bTokens : List Macro :=
 [.push0,.incTop,.push3,.ap,.push4,.ap,.push5,.ap,.push3,.push5,.push5,
  .witness,.ap,.push4,.push5,.ap,.ap,.eqn]

theorem effectTest (n t stack c a b tail : Nat) :
    testTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
    ⟨n,test b a,pair t stack,c,a,b,tail⟩ := by
  simp only [testTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push,
    Frame.combine,Cantor.unpair_pair,ctor,test,single,s_is_one,q,imp,eqn,app,witness]
  <;> rfl

theorem effectB (n t stack c a b tail : Nat) :
    bTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
    ⟨n,bRow a b c,pair t stack,c,a,b,tail⟩ := by
  simp only [bTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push,
    Frame.combine,Cantor.unpair_pair,ctor,bRow,s_is_one,q,imp,eqn,app,witness]
  <;> rfl

def eight (a b c u : Nat) := [row0 a b c u,row4 a b,bRow a b c,row2 a b c,
  row3 a b c,row6 a b c,test b a,row9 a b]
end Eight187.Seed
