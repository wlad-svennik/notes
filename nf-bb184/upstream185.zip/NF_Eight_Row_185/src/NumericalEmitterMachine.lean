module
public import NumericalEmitterBatch
public import MachineSource

@[expose] public section

/-! Comparison of the structured AX proof with the full ordinal-addressed
countdown source. Invalid register indices map to a stop in the structured
interpreter. A successful run therefore never relies on such an index. -/

set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace NF192.Emitter

open NF192.Numerical

def readCommand : Source.Command → Instruction
  | .inl (r, next) => if hr : r < 9 then .inc ⟨r,hr⟩ next else .halt
  | .inr (.inl (r,z,p,h)) =>
      if hr : r < 9 then if h then .decHalt ⟨r,hr⟩ p else .dec ⟨r,hr⟩ z p else .halt
  | .inr (.inr next) => .jump next

def actual (pc : Nat) : Instruction := readCommand (Source.program pc)

def liftRegisters (rs : Registers) : Source.Registers :=
  fun i => if h : i < 9 then rs ⟨i,h⟩ else 0

def liftConfig (cfg : Config) : Source.Config := Source.Config.active cfg.pc (liftRegisters cfg.registers)

theorem liftRegisters_at (rs : Registers) (i : Register) : liftRegisters rs i.val = rs i := by
  simp only [liftRegisters, dif_pos i.isLt]

theorem liftRegisters_set (rs : Registers) (j : Register) (n : Nat) :
    Source.setReg (liftRegisters rs) j.val n = liftRegisters (rs.set j n) := by
  funext i
  by_cases hi : i < 9
  · by_cases h : i = j.val
    · subst i
      simp [Source.setReg, liftRegisters, Registers.set, j.isLt]
    · have hn : (⟨i,hi⟩ : Register) ≠ j := fun e => h (congrArg Fin.val e)
      simp [Source.setReg, liftRegisters, Registers.set, hi, h, hn]
  · have h : i ≠ j.val := fun e => hi (e ▸ j.isLt)
    simp [Source.setReg, liftRegisters, hi, h]

/-- One successful structured instruction takes the same step in the selected source. -/
theorem actual_step {s t : Config} (hs : step actual s = some t) :
    Source.step (liftConfig s) = liftConfig t := by
  obtain ⟨pc, rs⟩ := s
  cases hc : Source.program pc with
  | inl inc =>
      obtain ⟨r, next⟩ := inc
      by_cases hr : r < 9
      · simp only [step, actual, hc, readCommand, dif_pos hr, Option.some.injEq] at hs
        subst t
        change Source.execute (Source.program pc) (liftRegisters rs) = _
        rw [hc]
        simp only [Source.execute, liftConfig, Registers.add]
        rw [show liftRegisters rs r = rs ⟨r,hr⟩ from liftRegisters_at rs ⟨r,hr⟩]
        rw [show Source.setReg (liftRegisters rs) r (rs ⟨r,hr⟩+1) =
          liftRegisters (rs.set ⟨r,hr⟩ (rs ⟨r,hr⟩+1)) from liftRegisters_set rs ⟨r,hr⟩ _]
      · simp [step, actual, hc, readCommand, hr] at hs
  | inr cmd =>
      cases cmd with
      | inr next =>
          simp only [step, actual, hc, readCommand, Option.some.injEq] at hs
          subst t
          change Source.execute (Source.program pc) (liftRegisters rs) = _
          rw [hc]
          rfl
      | inl dec =>
          obtain ⟨r, z, p, flag⟩ := dec
          by_cases hr : r < 9
          · have get : liftRegisters rs r = rs ⟨r,hr⟩ := liftRegisters_at rs ⟨r,hr⟩
            cases hv : rs ⟨r,hr⟩ with
            | zero =>
                cases flag <;> simp [step, actual, hc, readCommand, hr, hv] at hs
                subst t
                change Source.execute (Source.program pc) (liftRegisters rs) = _
                rw [hc]
                simp [Source.execute, get, hv, liftConfig]
            | succ n =>
                have put := liftRegisters_set rs ⟨r,hr⟩ n
                cases flag <;> simp [step, actual, hc, readCommand, hr, hv] at hs <;> subst t
                all_goals
                  change Source.execute (Source.program pc) (liftRegisters rs) = _
                  rw [hc]
                  simp [Source.execute, liftConfig, get, hv, put]
          · simp [step, actual, hc, readCommand, hr] at hs

theorem actual_run (n : Nat) {s t : Config} (h : run actual n s = some t) :
    Source.advance n (liftConfig s) = liftConfig t := by
  induction n generalizing s with
  | zero =>
      have e : s = t := Option.some.inj h
      subst t
      rfl
  | succ n ih =>
      cases hs : step actual s with
      | none => simp [run, hs] at h
      | some u =>
          have rest : run actual n u = some t := by simpa only [run, hs, Option.bind_some] using h
          exact (congrArg (Source.advance n) (actual_step hs)).trans (ih rest)

/-- Any checked embedding of this emitter code supplies the all-input AX batch step. -/
theorem ax_program_of_embedding
    (embedded : Embedded actual batchCode 40 2968 [] [])
    (n t stack c u v y delta tail : Nat) :
    ∃ ticks, 0 < ticks ∧
      Source.advance ticks
        (Source.Config.active 40 (liftRegisters (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩))) =
        Source.Config.active 2968 (liftRegisters ((save ⟨n,t,stack,c,0,0,tail⟩
          (rowList (u+delta) (v+y) c u)).regs)) := by
  obtain ⟨ticks, ht, hrun⟩ := (batch_eval n t stack c u v y delta tail).compiled
    actual 40 2968 [] [] embedded
  exact ⟨ticks, ht, actual_run ticks hrun⟩

end NF192.Emitter
