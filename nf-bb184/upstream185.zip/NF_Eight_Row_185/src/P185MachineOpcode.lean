module
public import P185MachineControlCarryCase
public import P185MachineArithmeticReturnComplete

@[expose] public section

/-! Opcode inversion for the selected four-operation packed source. The
arithmetic register bound comes from the verified physical selector table. -/
namespace P185.Opcode

private theorem op_lt (pc : Nat) : (Source.siteAt pc).op < 4 :=
  Nat.mod_lt _ (by decide)

private theorem inc_op (s : Source.Site) {r n : Nat} (h : Source.decode s = Source.Command.inc r n) :
    s.op = 0 := by
  by_cases hi : s.op = 0
  · exact hi
  by_cases hd : s.op = 1 <;> by_cases hb : s.op = 2 <;>
    simp [Source.decode,Source.Primitive.inc,Source.Primitive.dec,Source.Primitive.brk,hi,hd,hb] at h

private theorem dec_op (s : Source.Site) {r z n : Nat} {flag : Bool}
    (h : Source.decode s = Source.Command.dec r z n flag) : s.op = 1 := by
  by_cases hd : s.op = 1
  · exact hd
  by_cases hi : s.op = 0 <;> by_cases hb : s.op = 2 <;>
    simp [Source.decode,Source.Primitive.inc,Source.Primitive.dec,Source.Primitive.brk,hi,hd,hb] at h

private theorem register_bound {pc : Nat} (valid : pc < Source.siteCount)
    (hop : (Source.siteAt pc).op = 0 ∨ (Source.siteAt pc).op = 1) :
    (Source.siteAt pc).argument < 9 := by
  have active : Phase.enabled (Source.siteAt pc) 0 = true := by
    simpa [Phase.enabled,Source.Primitive.inc,Source.Primitive.dec] using hop
  exact (ArithmeticReturn.things_checked active (ArithmeticReturn.all_checked pc valid)).1

theorem inc {pc r n : Nat} (valid : pc < Source.siteCount)
    (atPc : Source.program pc = Source.Command.inc r n) :
    r = (Source.siteAt pc).argument ∧ r < 9 ∧ (Source.siteAt pc).op = 0 ∧ n = Carry.nextPc pc false := by
  have hd : Source.decode (Source.siteAt pc) = Source.Command.inc r n := by
    simpa only [Source.program,ite_eq_left valid] using atPc
  have h := inc_op _ hd
  have e : (Source.siteAt pc).argument = r ∧
      Source.destination (Source.plus (Source.siteAt pc).address) = n := by
    simpa [Source.decode, Source.Primitive.inc,h] using hd
  exact ⟨e.1.symm, e.1 ▸ register_bound valid (Or.inl h), h, e.2.symm⟩

theorem dec {pc r z n : Nat} {flag : Bool} (valid : pc < Source.siteCount)
    (atPc : Source.program pc = Source.Command.dec r z n flag) :
    r = (Source.siteAt pc).argument ∧ r < 9 ∧ (Source.siteAt pc).op = 1 ∧
    n = Carry.nextPc pc false ∧ z = Carry.nextPc pc true ∧ flag = ((Source.siteAt pc).address % 2 == 1) := by
  have hd : Source.decode (Source.siteAt pc) = Source.Command.dec r z n flag := by
    simpa only [Source.program,ite_eq_left valid] using atPc
  have h := dec_op _ hd
  have e : (Source.siteAt pc).argument = r ∧
      Source.destination (Source.plus (Source.cutOnce (Source.siteAt pc).address false)) = z ∧
      Source.destination (Source.plus (Source.siteAt pc).address) = n ∧
      ((Source.siteAt pc).address % 2 == 1) = flag := by
    simpa [Source.decode, Source.Primitive.inc, Source.Primitive.dec,h] using hd
  exact ⟨e.1.symm,e.1 ▸ register_bound valid (Or.inr h),h,e.2.2.1.symm,e.2.1.symm,e.2.2.2.symm⟩

private theorem control_tag (x : Nat) (bound : x < 4) (h₀ : x ≠ 0) (h₁ : x ≠ 1) :
    x = 2 ∨ x = 3 := by omega

theorem jump {pc n : Nat} (valid : pc < Source.siteCount)
    (atPc : Source.program pc = Source.Command.jump n) : Control.isControl (Source.siteAt pc) = true := by
  have hd : Source.decode (Source.siteAt pc) = Source.Command.jump n := by
    simpa only [Source.program,ite_eq_left valid] using atPc
  have bound := op_lt pc
  by_cases hi : (Source.siteAt pc).op = 0
  · simp [Source.decode,Source.Primitive.inc,hi] at hd
  by_cases hc : (Source.siteAt pc).op = 1
  · simp [Source.decode,Source.Primitive.inc,Source.Primitive.dec,hc] at hd
  have ht := control_tag (Source.siteAt pc).op bound hi hc
  rcases ht with h | h <;> simp [Control.isControl,h]

end P185.Opcode

#print axioms P185.Opcode.inc
#print axioms P185.Opcode.dec
#print axioms P185.Opcode.jump
