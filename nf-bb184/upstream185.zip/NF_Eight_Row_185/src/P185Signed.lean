module
public import P185MachinePhysicalInterface
public meta import P185MachinePhysicalInterface
public import P185SignedSource
public meta import P185SignedSource
public import End185
public meta import End185
public import BootFrame185
public meta import BootFrame185
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P185.Physical
open NF210 NF210.TM P185.Frame Eight187.Register
/-- The checked signed startup reaches a warm boundary. This permits exactly
the exceptional initial increment and rules out a decrement at minus one. -/
def CanWarm (s : C185.Physical.Signed) : Prop :=
  ∃ k t, bootstrapAdvance k s = (false,t)

theorem CanWarm.step {s : C185.Physical.Signed} (h : CanWarm s) : CanWarm (bootstrapStep s) := by
  rcases s with ⟨cold,c⟩
  cases cold with
  | false => exact ⟨0,Eight187.Raw.step c,rfl⟩
  | true =>
    obtain ⟨k,t,ht⟩ := h
    cases k with
    | zero => cases ht
    | succ k => exact ⟨k,t,ht⟩

theorem cold_halt_never_warms : ¬ CanWarm (true,NF192.Source.Config.halted) := by
  rintro ⟨k,t,h⟩
  rw [bootstrap_absorbing] at h
  cases h

def rawValue (cold : Bool) (rs : NF192.Source.Registers) (r : Nat) : Nat :=
  if cold && (r == 0) then 0 else rs r+1

/-- Register semantics only depends on the nine physical selectors. -/
def Rep (cold : Bool) (s : NF192.BinarySimulation.Running) (f : Layout) : Prop :=
  Good f ∧ f.pc = s.1 ∧ (∀ j : Fin 9, f.storedAt j.val = rawValue cold s.2 j.val) ∧
    CanWarm (cold,some s)

def Rel (cold : Bool) (s : NF192.BinarySimulation.Running) (b : Configuration 185) : Prop :=
  ∃ f, Rep cold s f ∧ b = f.config

theorem inc_step (c : Bool) (pc n : Nat) (r : Fin 9) (rs : NF192.Source.Registers)
    (op : Eight187.Raw.program pc = NF192.Source.Command.inc r.val n) :
    bootstrapStep (c,NF192.Source.Config.active pc rs) =
      (c && !(r.val == 0),NF192.Source.Config.active n
        (NF192.Source.setReg rs r.val (if c && (r.val == 0) then 0 else rs r.val+1))) := by
  cases c <;> by_cases h : r.val = 0 <;>
    simp [bootstrapStep,Eight187.Register.actual,NF192.Emitter.readCommand,usesCounter,Eight187.Raw.step,NF192.Source.execute,op,r.isLt,h]

theorem inc_values (c : Bool) (r : Fin 9) (rs : NF192.Source.Registers) (f : Layout)
    (h : ∀ j : Fin 9, f.storedAt j.val = rawValue c rs j.val) (j : Fin 9) :
    NF192.Source.setReg f.storedAt r.val (f.storedAt r.val+1) j.val =
      rawValue (c && !(r.val == 0)) (NF192.Source.setReg rs r.val
        (if c && (r.val == 0) then 0 else rs r.val+1)) j.val := by
  by_cases e : j.val = r.val
  · have eq : j = r := Fin.ext e
    subst j
    simp only [NF192.Source.setReg,ite_true, h r]
    cases c <;> by_cases z : r.val = 0 <;> simp [NF192.Source.setReg,rawValue,z]
  · cases c <;> by_cases z : r.val = 0 <;>
      simp [NF192.Source.setReg,h,rawValue,z,e] <;> grind

theorem dec_cold_impossible (pc z n : Nat) (r : Fin 9) (halt : Bool)
    (rs : NF192.Source.Registers) (op : Eight187.Raw.program pc = NF192.Source.Command.dec r.val z n halt)
    (warm : CanWarm (true,NF192.Source.Config.active pc rs)) : r.val ≠ 0 := by
  intro zero
  have fix : bootstrapStep (true,NF192.Source.Config.active pc rs) = (true,NF192.Source.Config.halted) := by
    cases halt <;> simp [bootstrapStep,Eight187.Register.actual,NF192.Emitter.readCommand,usesCounter,op,r.isLt,zero]
  have bad := warm.step
  rw [fix] at bad
  exact cold_halt_never_warms bad

theorem dec_step (c : Bool) (pc z n : Nat) (r : Fin 9) (halt : Bool) (rs : NF192.Source.Registers)
    (op : Eight187.Raw.program pc = NF192.Source.Command.dec r.val z n halt)
    (allowed : c = true → r.val ≠ 0) :
    bootstrapStep (c,NF192.Source.Config.active pc rs) =
      (c,NF192.Source.execute (NF192.Source.Command.dec r.val z n halt) rs) := by
  cases c with
  | false => simp [bootstrapStep,Eight187.Raw.step,op]
  | true =>
    have hr := allowed rfl
    cases halt <;> simp [bootstrapStep,Eight187.Register.actual,NF192.Emitter.readCommand,usesCounter,op,r.isLt,hr,Eight187.Raw.step]

theorem dec_values (c : Bool) (r : Fin 9) (rs : NF192.Source.Registers) (f : Layout) (k : Nat)
    (pos : rs r.val = k+1) (allowed : c = true → r.val ≠ 0)
    (h : ∀ j : Fin 9, f.storedAt j.val = rawValue c rs j.val) (j : Fin 9) :
    NF192.Source.setReg f.storedAt r.val (f.storedAt r.val-1) j.val =
      rawValue c (NF192.Source.setReg rs r.val k) j.val := by
  by_cases e : j.val = r.val
  · have eq : j = r := Fin.ext e
    subst j
    cases c with
    | false => simp [NF192.Source.setReg,rawValue,h,pos]
    | true => simp [NF192.Source.setReg,rawValue,h,pos,allowed rfl]
  · simp only [NF192.Source.setReg,if_neg e,h]
    unfold rawValue
    simp [NF192.Source.setReg,e]

theorem jump_step (c : Bool) (pc n : Nat) (rs : NF192.Source.Registers)
    (op : Eight187.Raw.program pc = NF192.Source.Command.jump n) :
    bootstrapStep (c,NF192.Source.Config.active pc rs) = (c,NF192.Source.Config.active n rs) := by
  cases c <;> simp [bootstrapStep,Eight187.Register.actual,NF192.Emitter.readCommand,usesCounter,Eight187.Raw.step,NF192.Source.execute,op]


/-- Cold-origin progress supplies the cold-register invariant even at a later concrete margin. -/
theorem canWarm_margin : CanWarm (true,NF192.Emitter.liftConfig margin185) := by
  obtain ⟨k,_,w⟩ := signed_startup_boundary
  have w' : bootstrapAdvance k (true,NF192.Emitter.liftConfig origin) = _ := w
  refine ⟨k,Eight187.Raw.advance 98 (atFrame 0 (registers 0 0 firstBoundaryProof)),?_⟩
  rw [← advance_steps185,← bootstrapAdvance_add,Nat.add_comm,bootstrapAdvance_add,w',bootstrap_warm]

def firstMargin : Layout := ⟨-1,118,55,#[0,1,1,3,1,1,1,2,1],List.replicate 36 0⟩

theorem from_safe : firstMargin.config = CS185.Calibration.safe.config := by rfl

theorem margin_entry : C185.Physical.Related Rel (true,NF192.Emitter.liftConfig margin185)
    (TM.run CS185.Table.machine 59905 (TM.blank CS185.Table.start)) := by
  rw [CS185.Calibration.safe_frame,← from_safe]
  refine ⟨firstMargin,⟨?_,rfl,?_,canWarm_margin⟩,rfl⟩
  · exact ⟨by decide, by decide, by decide⟩
  · change ∀ j : Fin 9, firstMargin.storedAt j.val =
      rawValue true (NF192.Emitter.liftRegisters margin185.registers) j.val
    decide +kernel
end P185.Physical
#print axioms P185.Physical.margin_entry
