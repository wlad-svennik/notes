module
public import BootFrame185
public import P185MachineSource

@[expose] public section

/-! The register frame on the infinite integer tape. The first tape bit is
the sentinel immediately left of the head. The source address continues to
the right, followed by the gap and its header. In the payload each natural
n is encoded by a zero and then n + 1 one-bits. Registers are ordered by
the physical register selector of this table. Remaining fields are spares. -/
namespace P185.Frame

open NF210 P185

def registerOrder : List Nat := [2,8,1,4,3,7,0,5,6]

def addressBits (pc : Nat) : List Bool :=
  let site := Source.siteAt pc
  (List.range site.depth).map fun i => site.address.testBit (site.depth - (i+1))

structure Layout where
  head : Int
  pc : Nat
  gap : Nat
  stored : Array Nat
  spares : List Nat
  deriving Inhabited

def Layout.header (f : Layout) : Int := f.head + (f.gap : Int)
def Layout.logical (f : Layout) (r : Nat) : Int := (f.stored[r]?.getD 0 : Int) - 1
def field (n : Nat) : List Bool := false :: List.replicate (n+1) true
def Layout.word (f : Layout) : List Bool :=
  let address := addressBits f.pc
  let values := registerOrder.map (fun r => f.stored[r]?.getD 0) ++ f.spares
  (true :: address) ++ List.replicate (f.gap-address.length) false ++
    (true :: values.flatMap field)

def cells (left : Int) (word : List Bool) (p : Int) : Bool :=
  if p < left then false else word[(p-left).toNat]?.getD false

def Layout.tape (f : Layout) : TM.Tape := cells (f.head-1) f.word
def Layout.config (f : Layout) : TM.Configuration 185 :=
  ⟨some CS185.Table.decoderRoot,f.head,f.tape⟩

theorem cells_before {left p : Int} (word : List Bool) (h : p < left) :
    cells left word p = false := by simp [cells,h]

theorem cells_after {left p : Int} (word : List Bool) (h : left + (word.length : Int) ≤ p) :
    cells left word p = false := by
  have hr : ¬ p < left := by omega
  have hn : word.length ≤ (p-left).toNat := by omega
  simp [cells,hr,List.getElem?_eq_none hn]

/-- Finite bit equality identifies the complete tape, including every cell
outside the checked window. -/
theorem packed_eq_cells {width : Nat} {anchor left : Int} {bits : Nat} {word : List Bool}
    (lo : anchor ≤ left) (hi : left + (word.length : Int) ≤ anchor + (width : Int))
    (hMatches : ∀ i : Fin width, bits.testBit i = cells left word (anchor + (i : Nat))) :
    NF192.KernelBits.tape width anchor (fun _ => false) bits = cells left word := by
  funext p
  by_cases h : 0 ≤ p-anchor ∧ p-anchor < (width : Int)
  · let i : Fin width := ⟨(p-anchor).toNat, by omega⟩
    have hp : p = anchor + (i.val : Int) := by dsimp [i]; omega
    rw [hp,NF192.KernelBits.tape_read width i.val bits i.isLt]
    exact hMatches i
  · simp only [NF192.KernelBits.tape,ite_eq_right h]
    by_cases before : p < left
    · exact (cells_before word before).symm
    · apply (cells_after word _).symm
      omega

end P185.Frame
