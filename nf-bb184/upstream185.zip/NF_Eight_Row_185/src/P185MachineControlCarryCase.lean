module
public import P185MachineControlCarry
public import P185MachineFrame

@[expose] public section

namespace P185.Carry
open NF210 NF210.TM KernelRightShift

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- A proposal for the bounded carry and bounded origin return. The
unbounded interval between them has no recorded length. -/
structure Case where
  pc : Nat
  zero : Bool
  next : Nat
  shifted : Bool
  marker : Nat
  carrySteps : Nat
  originSteps : Nat

def selected (pc : Nat) (zero : Bool) : Bool :=
  let s := Source.siteAt pc
  if zero then (s.op == 1) && (s.address % 2 == 0)
  else (s.op == 0) || (s.op == 1)

def nextPc (pc : Nat) (zero : Bool) : Nat :=
  let p := (Source.siteAt pc).address
  Source.destination (Source.plus (if zero then Source.cutOnce p false else p))

def shifted (pc : Nat) (zero : Bool) : Bool := zero && (pc == 2956)

def before (moved : Bool) : Nat := if moved then 7 else 8

def entryState (zero : Bool) : CS185.Table.State := if zero then 136 else 141

def prefixAt (pc : Nat) (moved : Bool) : List Bool :=
  List.replicate (before moved) false ++ true :: Frame.addressBits pc

def initialWord (pc : Nat) (zero : Bool) : List Bool :=
  prefixAt pc false ++ List.replicate (if zero then 1 else 2) false

def startHead (pc : Nat) : Nat := 8 + (Frame.addressBits pc).length

def Case.input (c : Case) := initialWord c.pc c.zero
def Case.target (c : Case) := prefixAt c.next c.shifted
def Case.front (c : Case) := c.target.take c.marker
def Case.zeros (c : Case) := c.input.length - c.marker - 1
def Case.output (c : Case) := c.front ++ [true] ++ List.replicate c.zeros false

def Valid (c : Case) : Prop :=
  c.next = nextPc c.pc c.zero ∧ c.shifted = shifted c.pc c.zero ∧
  c.front.length = c.marker ∧ c.zeros > 0 ∧ c.input.length = c.output.length ∧
  startHead c.pc < c.input.length ∧ c.marker < c.output.length ∧
  c.target = c.front ++ [true] ++ List.replicate (c.target.length-c.marker-1) false ∧
  c.target.length ≤ 52 ∧
  NF192.KernelBits.run CS185.Table.machine c.input.length c.carrySteps
    (Control.loc (entryState c.zero) (startHead c.pc) (BitsWord.encode c.input)) =
      some (Control.loc 149 (c.marker+1) (BitsWord.encode c.output)) ∧
  NF192.KernelBits.run CS185.Table.machine c.output.length c.originSteps
    (Control.loc 130 c.marker (BitsWord.encode c.output)) =
      some (Control.loc 13 (before c.shifted+1) (BitsWord.encode c.output))

instance (c : Case) : Decidable (Valid c) := by unfold Valid; infer_instance
def verified (c : Case) := decide (Valid c)

def ready (pc : Nat) (zero : Bool) (extra : Nat) : List Bool :=
  initialWord pc zero ++ List.replicate (extra+1) true ++ [false]

def restored (pc : Nat) (zero : Bool) (extra : Nat) : List Bool :=
  let target := prefixAt (nextPc pc zero) (shifted pc zero)
  target ++ List.replicate ((initialWord pc zero).length+extra-target.length) false ++ [true,false]

/-- Complete carry/zero-return to the canonical successor. The body of the
register file beyond the first delimiter is arbitrary surrounding tape. -/
theorem case_return {c : Case} (ok : verified c = true) (extra : Nat)
    (space : 52 ≤ (initialWord c.pc c.zero).length+extra) :
    ∃ t, WordRun (entryState c.zero) 13 (ready c.pc c.zero extra) (restored c.pc c.zero extra)
      (startHead c.pc) (before (shifted c.pc c.zero)+1 : Nat) t := by
  obtain ⟨next, moved, marker, nonempty, equal, inside, insideOut, target, targetBd, pre, post⟩ :=
    of_decide_eq_true ok
  have carry := finite_word equal inside pre
  have origin := finite_word rfl insideOut post
  have first := carry.context [] (List.replicate (extra+1) true ++ [false])
  have mid := (cleanup c.zeros extra nonempty).context c.front []
  have last := origin.context [] (List.replicate extra false ++ [true,false])
  simp only [List.nil_append, List.length_nil, Int.natCast_zero, Int.zero_add] at first last
  simp only [List.append_nil, marker] at mid
  have same : c.output ++ (List.replicate (extra+1) true ++ [false]) =
      c.front ++ (true :: List.replicate c.zeros false ++ List.replicate (extra+1) true ++ [false]) := by
    simp only [Case.output, List.append_assoc, List.singleton_append, List.cons_append, List.nil_append]
  have same' : c.output ++ (List.replicate extra false ++ [true,false]) =
      c.front ++ (true :: List.replicate (c.zeros+extra) false ++ [true,false]) := by
    simp only [Case.output, List.append_assoc, List.singleton_append, List.cons_append,
      List.nil_append, ←List.replicate_append_replicate, List.append_assoc]
  rw [same] at first
  rw [same'] at last
  simp only [Int.natCast_add,Int.natCast_one,Int.add_zero] at first mid
  have h := (first.trans mid).trans last
  refine ⟨c.carrySteps + (c.zeros+extra+3 + 3*(c.zeros+extra)) + c.originSteps, ?_⟩
  have geom : c.input.length = c.marker+1+c.zeros := by
    rw [equal, Case.output]
    simp [marker,Nat.add_assoc]; omega
  have enough : c.target.length ≤ c.input.length+extra := Nat.le_trans targetBd space
  have minLen : c.marker+1 ≤ c.target.length := by
    have len := congrArg List.length target
    simp only [List.length_append,List.length_singleton,List.length_replicate,marker] at len
    omega
  have amounts : c.zeros+extra = c.target.length-c.marker-1 + (c.input.length+extra-c.target.length) := by omega
  have output_eq : c.front ++ (true :: List.replicate (c.zeros+extra) false ++ [true,false]) =
      c.target ++ List.replicate (c.input.length+extra-c.target.length) false ++ [true,false] := by
    have changeTarget := congrArg (fun w : List Bool => w ++ List.replicate
      (c.input.length+extra-c.target.length) false ++ [true,false]) target
    apply Eq.trans _ changeTarget.symm
    rw [amounts, ←List.replicate_append_replicate]
    simp only [List.append_assoc, List.singleton_append, List.cons_append, List.nil_append]
  rw [output_eq] at h
  simpa only [ready, restored, Case.input, Case.target, next, moved, List.append_assoc] using h
end P185.Carry
