module
public import P185ArithmeticReturnFinite
public import P185MachineBitsWord
public import P185MachineSelectorRoundtrip
@[expose] public section
namespace P185.ArithmeticReturn
open NF210 NF210.TM P185.KernelRightShift
theorem checked_return {s : Source.Site} {selected : Bool} (h : Spec s selected) :
    let word := stageWord s selected
    WordRun returnState CS185.Table.decoderRoot word word (initialHead s selected : Int)
      (finalHead s selected : Int) (duration s selected) := by
  dsimp only
  constructor
  · rfl
  · intro anchor outside
    have run := (NF192.KernelBits.run_sound CS185.Table.machine _ anchor outside _ _ _ h.1 h.2).2
    simpa only [NF192.KernelBits.embed, BitsWord.tape_encode, configuration] using run

end P185.ArithmeticReturn
