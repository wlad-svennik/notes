module
public import P185MachineBitsWord
public import P185MachineControlFrame
public import P185MachineControlKernelContracts
public import P185MachineControlKernelControl

@[expose] public section

/-! The cleanup after an arithmetic instruction. Its prepared workspace has
arbitrary length and its exterior may contain arbitrary registers and spares.
Both the outbound erasure and the return to the last address marker are proved
by induction on the unbounded run lengths. -/

namespace P185.Carry

open NF210 NF210.TM
open CS185.Table (State machine)
open P185.KernelRightShift
open P185.KernelControl

set_option maxHeartbeats 0
set_option autoImplicit false

theorem finite_word {q r : State} {input output : List Bool} {i j t : Nat}
    (len : input.length = output.length) (bound : i < input.length)
    (ok : NF192.KernelBits.run machine input.length t
      ⟨some q,i,BitsWord.encode input⟩ = some ⟨some r,j,BitsWord.encode output⟩) :
    WordRun q r input output i j t := by
  refine ⟨len, fun a out => ?_⟩
  have run := (NF192.KernelBits.run_sound machine input.length a out t _ _ bound ok).2
  change TM.run machine t (configuration q (a+i)
      (NF192.KernelBits.tape input.length a out (BitsWord.encode input))) =
    configuration r (a+j) (NF192.KernelBits.tape input.length a out (BitsWord.encode output)) at run
  rw [BitsWord.tape_encode, len, BitsWord.tape_encode] at run
  exact run

theorem erase_run (zeros extra : Nat) : WordRun zeroScanState returnState
    (List.replicate zeros false ++ List.replicate (extra+1) true ++ [false])
    (List.replicate (zeros+extra) false ++ [true,false])
    0 ((zeros+extra:Int)-1) (zeros+extra+3) := by
  constructor
  · simp; omega
  · intro a t
    simpa only [Int.add_zero, Int.natCast_add, Int.add_sub_assoc] using cleanup_exact zeros extra a t

theorem retreat_run (n : Nat) :
    WordRun returnState 130 (true :: List.replicate (n+1) false ++ [true,false])
      (true :: List.replicate (n+1) false ++ [true,false]) (n+1:Nat) 0 (3*(n+1)) := by
  refine ⟨rfl, ?_⟩
  intro a outside
  let word := true :: List.replicate (n+1) false ++ [true,false]
  let t := wordTape a word outside
  have atLast : t a = true := by simp [t,word]
  have gap (i : Nat) (hi : i ≤ n) : t (a+(i:Int)+1) = false := by
    have hidx : i+1 < word.length := by simp [word]; omega
    have hpos : a+(i:Int)+1 = a+((i+1:Nat):Int) := by omega
    rw [hpos, show t = wordTape a word outside from rfl, wordTape_get _ _ _ _ hidx]
    simp only [word]
    rw [List.getElem_append_left (by simp; omega), List.getElem_cons_succ, List.getElem_replicate]
  have h := Control.literalRows.retreat_zeros t a n atLast gap
  have pos : a + (n:Int) + 1 = a+((n+1:Nat):Int) := by omega
  rw [pos] at h
  rw [Int.add_zero]
  exact h

/-- One variable-length interval covers both the positive and zero exits. -/
theorem cleanup (zeros extra : Nat) (space : 0 < zeros) :
    WordRun zeroScanState 130
      (true :: List.replicate zeros false ++ List.replicate (extra+1) true ++ [false])
      (true :: List.replicate (zeros+extra) false ++ [true,false])
      1 0 (zeros+extra+3 + 3*(zeros+extra)) := by
  have erase := (erase_run zeros extra).context [true] []
  simp only [List.singleton_append, List.cons_append, List.append_nil, List.length_singleton,
    Int.natCast_one, Int.add_zero] at erase
  have pos : 1 + ((zeros+extra:Int)-1) = ((zeros+extra:Nat):Int) := by omega
  rw [pos] at erase
  obtain ⟨n, hn⟩ : ∃ n, zeros+extra = n+1 := ⟨zeros+extra-1,by omega⟩
  have retreat := retreat_run n
  rw [← hn] at retreat
  exact erase.trans retreat

end P185.Carry
