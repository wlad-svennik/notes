module
public import Eight187ColdCore
@[expose] public section
namespace Eight187.Register
open NF192 NF192.Emitter NF192.Emitter.Registers
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def origin : Emitter.Config := ⟨40,mk9 0 0 0 2 0 0 0 0 0⟩

end Eight187.Register
