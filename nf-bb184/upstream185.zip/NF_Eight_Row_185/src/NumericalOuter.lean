module
public import NumericalEmitterChecking
public import SourceFields

@[expose] public section

/-! The ordinary outer counter and two field readers of the selected literal
countdown source. The refill increments register zero before making a copy. -/
set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Emitter

open NF192.Numerical Registers

def Moves (s t : Source.Config) : Prop := ∃ n, 0 < n ∧ Source.advance n s = t

theorem Moves.one {s t : Source.Config} (h : Source.step s = t) : Moves s t := ⟨1,by decide,h⟩
theorem Moves.trans {s t u : Source.Config} (a : Moves s t) (b : Moves t u) : Moves s u := by
  obtain ⟨n, pn, hn⟩ := a
  obtain ⟨m, pm, hm⟩ := b
  exact ⟨n+m, by omega, by rw [Source.advance_add, hn, hm]⟩

def atFrame (pc : Nat) (f : Frame) : Source.Config := Source.Config.active pc (liftRegisters f.regs)

theorem move_compiled {code : Code} {s t : Registers} {p z : Nat}
    (h : Eval code s .normal t) (e : Embedded actual code p z [] []) :
    Moves (Source.Config.active p (liftRegisters s)) (Source.Config.active z (liftRegisters t)) := by
  obtain ⟨n, pos, hl⟩ := h.compiled actual p z [] [] e
  exact ⟨n, pos, actual_run n hl⟩

def firstRead : Code := .seq Literal.seq158 Literal.seq201

def twoReads : Code := .seq firstRead Literal.seq175

theorem twoReads_spec (n t stack c a b selector field tail : Nat) :
    Eval twoReads (mk9 n t stack c a b 0 0 (pair selector (pair field tail))) .normal
      (mk9 n t stack (c+selector) (a+field) b 0 0 tail) := by
  have r₁ := seq158_normal n t stack c a b (pair selector (pair field tail))
  simp only [Cantor.unpair_pair] at r₁
  have r₂ := seq201_eval n t stack c a b selector 0 (pair field tail)
  have r₃ := seq175_normal n t stack (c+selector) a b (pair field tail)
  simp only [Cantor.unpair_pair] at r₃
  exact Eval.seq_normal (Eval.seq_normal r₁ r₂) r₃

theorem twoReads_placement : Embedded actual twoReads 10 38 [] [] :=
  embedded_of_matches _ _ _ (by decide)

theorem outer_read_fields (n t stack c a b selector field tail : Nat) :
    Moves (atFrame 10 ⟨n,t,stack,c,a,b,pair selector (pair field tail)⟩)
      (atFrame 38 ⟨n,t,stack,c+selector,a+field,b,tail⟩) :=
  move_compiled (twoReads_spec n t stack c a b selector field tail) twoReads_placement

def refillBlock : Code := .seq (.inc 0) (.seq Literal.seq194 Literal.seq203)

theorem refillBlock_spec (n t stack c a b : Nat) :
    Eval refillBlock (mk9 n t stack c a b 0 0 0) .normal
      (mk9 (n+1) t stack c a b 0 0 (n+1)) := by
  have inc : Eval (.inc 0) (mk9 n t stack c a b 0 0 0) .normal
      (mk9 (n+1) t stack c a b 0 0 0) := by
    simpa only [Registers.add, mk9_get_0, mk9_set_0] using
      Eval.inc 0 (mk9 n t stack c a b 0 0 0)
  have h₁ := seq194_eval (n+1) t stack c a b 0 0 0
  have h₂ := seq203_eval 0 t stack c a b (n+1) 0 (n+1)
  simp only [Nat.zero_add] at h₁ h₂
  exact Eval.seq_normal inc (Eval.seq_normal h₁ h₂)

theorem refill_placement : Embedded actual refillBlock 2 10 [] [] :=
  embedded_of_matches _ _ _ (by decide)

theorem refill_copy (n t stack c a b : Nat) :
    Moves (atFrame 2 ⟨n,t,stack,c,a,b,0⟩) (atFrame 10 ⟨n+1,t,stack,c,a,b,n+1⟩) :=
  move_compiled (refillBlock_spec n t stack c a b) refill_placement

theorem row0_cmd : Source.program 0 = Source.Command.dec 8 2 1 false := by decide
theorem row1_cmd : Source.program 1 = Source.Command.jump 10 := by decide
theorem row38_cmd : Source.program 38 = Source.Command.dec 3 3017 39 false := by decide
theorem row39_cmd : Source.program 39 = Source.Command.dec 3 2969 40 false := by decide
theorem row2968_cmd : Source.program 2968 = Source.Command.jump 39 := by decide

theorem jump_at (pc n : Nat) (f : Frame) (h : Source.program pc = Source.Command.jump n) :
    Moves (atFrame pc f) (atFrame n f) := by
  apply Moves.one
  change Source.execute (Source.program pc) _ = _
  rw [h]
  rfl

theorem outer_fresh (n t stack c a b : Nat) :
    Moves (atFrame 0 ⟨n,t,stack,c,a,b,0⟩) (atFrame 10 ⟨n+1,t,stack,c,a,b,n+1⟩) := by
  apply Moves.trans _ (refill_copy n t stack c a b)
  apply Moves.one
  simp only [atFrame, Source.step, row0_cmd]
  rfl

theorem outer_continued (n t stack c a b p : Nat) :
    Moves (atFrame 0 ⟨n,t,stack,c,a,b,p+1⟩) (atFrame 10 ⟨n,t,stack,c,a,b,p⟩) := by
  apply Moves.trans _ (jump_at 1 10 _ row1_cmd)
  apply Moves.one
  simp only [atFrame, Source.step, row0_cmd]
  change Source.Config.active 1 (Source.setReg (liftRegisters (mk9 n t stack c a b 0 0 (p+1))) 8 p) = _
  exact congrArg (Source.Config.active 1) ((liftRegisters_set _ (8 : Register) p).trans
    (congrArg liftRegisters (mk9_set_8 n t stack c a b 0 0 (p+1) p)))

theorem dispatch_mp (n t stack a b p : Nat) :
    Moves (atFrame 38 ⟨n,t,stack,0,a,b,p⟩) (atFrame 3017 ⟨n,t,stack,0,a,b,p⟩) := by
  apply Moves.one
  simp only [atFrame, Source.step, row38_cmd]
  rfl

theorem dispatch_positive (n t stack c a b p : Nat) :
    Moves (atFrame 38 ⟨n,t,stack,c+1,a,b,p⟩) (atFrame 39 ⟨n,t,stack,c,a,b,p⟩) := by
  apply Moves.one
  simp only [atFrame, Source.step, row38_cmd]
  change Source.Config.active 39 (Source.setReg (liftRegisters (mk9 n t stack (c+1) a b 0 0 p)) 3 c) = _
  exact congrArg (Source.Config.active 39) ((liftRegisters_set _ (3 : Register) c).trans
    (congrArg liftRegisters (mk9_set_3 n t stack (c+1) a b 0 0 p c)))

theorem mode_entry (n t stack a b p : Nat) :
    Moves (atFrame 39 ⟨n,t,stack,0,a,b,p⟩) (atFrame 2969 ⟨n,t,stack,0,a,b,p⟩) := by
  apply Moves.one
  simp only [atFrame, Source.step, row39_cmd]
  rfl

theorem ax_entry (n t stack c a b p : Nat) :
    Moves (atFrame 39 ⟨n,t,stack,c+1,a,b,p⟩) (atFrame 40 ⟨n,t,stack,c,a,b,p⟩) := by
  apply Moves.one
  simp only [atFrame, Source.step, row39_cmd]
  change Source.Config.active 40 (Source.setReg (liftRegisters (mk9 n t stack (c+1) a b 0 0 p)) 3 c) = _
  exact congrArg (Source.Config.active 40) ((liftRegisters_set _ (3 : Register) c).trans
    (congrArg liftRegisters (mk9_set_3 n t stack (c+1) a b 0 0 p c)))

end NF192.Emitter
