import WeakCalibration
import CompactNF

open FFL FFL.FirstOrder
namespace NF196.Compact
open NF196.Weak

theorem partial_iff {V : Type} (A : NF188.Relabel.Basis V) (W F : V) (different : W≠F) :
    (∀ x y, (diag A W x y=F → diag A W x x=F) → x=y) ↔
    ((∀ x y, x≠y → diag A W x y=F) ∧ (∀ x, diag A W x x≠F)) := by
  classical
  constructor
  · intro h
    have b (x y : V) (ne : x≠y) : diag A W x y=F ∧ diag A W x x≠F := by
      by_contra no
      apply ne
      apply h
      intro g
      by_contra k
      exact no ⟨g,k⟩
    constructor
    · exact fun x y ne => (b x y ne).1
    · intro x
      by_cases e : x=W
      · exact (b x F (e ▸ different)).2
      · exact (b x W e).2
  · rintro ⟨p,q⟩ x y h
    by_contra ne
    exact q x (h (p x y ne))

theorem exact_plain : Entailment.Consistent 𝗡𝗙 ↔ ∃ V : Type, Nonempty (Chart V) := by
  refine ⟨of_consistent,?_⟩
  rintro ⟨V,⟨A⟩⟩
  exact Weak.consistent A.toBasis A.J A.B A.off A.on

theorem clause_exact_plain : Entailment.Consistent 𝗡𝗙 ↔
    ∃ (V : Type) (A : NF188.Relabel.Basis V) (j : V), A.app j j=A.B ∧ A.B≠j ∧
      ∀ x y, (diag A j x y=A.B → diag A j x x=A.B) → x=y := by
  rw [exact_plain]
  constructor
  · rintro ⟨V,⟨C⟩⟩
    exact ⟨V,C.toBasis,C.J,C.letter,C.proper,(partial_iff _ _ _ C.proper.symm).mpr ⟨C.off,C.on⟩⟩
  · rintro ⟨V,A,j,l,d,s⟩
    obtain ⟨off,on⟩ := (partial_iff A j A.B d.symm).mp s
    exact ⟨V,⟨{toBasis := A, J := j,letter := l,proper := d,off := off,on := on}⟩⟩
end NF196.Compact
#print axioms NF196.Compact.clause_exact_plain
