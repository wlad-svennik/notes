module
public import P185MachineControlKernelEndpoint
@[expose] public section

/-! Full execute phase of all three offset-one operations in the selected
185-state table. The input file has any number of preceding/following unary
blocks of arbitrary lengths. The conclusions identify the precise tape and
head at the normal carry (k:4) or zero-return (k:302) continuation. -/

namespace P185.KernelExecute
open NF210 NF210.TM
open CS185.Table (State machine)
open P185.KernelRightShift P185.KernelFiles P185.KernelArithmetic
set_option maxHeartbeats 0
theorem increased_file (headerExtra value : Nat) (earlier following : List Nat) :
    increasedOutput (headerExtra + 1) value earlier following =
      terminatedRuns (headerExtra :: (earlier ++ (value + 1) :: following)) := by
  rw [← header_terminated]
  simp [increasedOutput, blocks_append, blocks, List.append_assoc, Nat.add_assoc]

theorem shifted_file (headerExtra : Nat) (earlier : List Nat) :
    shiftOutput (headerExtra + 1) earlier = terminatedRuns ((headerExtra + 1) :: earlier) := by
  exact header_terminated (headerExtra + 1) earlier

theorem undo_file_restored (headerExtra : Nat) (earlier : List Nat) :
    [false] ++ terminatedRuns ((headerExtra + 1) :: earlier) ++ [true] =
      [false, true] ++ List.replicate (headerExtra + 1) true ++ blocks earlier ++ [false, true] := by
  rw [← header_terminated]
  simp [List.replicate_succ, List.append_assoc]

/-- Increment includes appending a new physical-zero spare and the full reverse search. -/
theorem increment_execute (headerExtra value : Nat) (earlier following : List Nat) :
    WordRun seekState KernelReverse.searchEndState
      ([false, false] ++ markedInput (headerExtra + 1) value earlier following ++ [false, false])
      ([false, false] ++ increasedOutput (headerExtra + 1) value earlier following ++ [true, false])
      2 (-1)
      ((markedInput (headerExtra + 1) value earlier following).length + 1 +
        ([false, false] ++ increasedOutput (headerExtra + 1) value earlier following).length) := by
  let input := markedInput (headerExtra + 1) value earlier following
  let output := increasedOutput (headerExtra + 1) value earlier following
  let front := [false, false] ++ output
  have lengths : input.length = output.length := (increment_shift (headerExtra + 1) value earlier following).same_length
  have forward : WordRun seekState endState ([false, false] ++ input ++ [false, false])
      (front ++ [false, false]) 2 (2 + (input.length : Int)) input.length := by
    simpa [input, output, front] using
      (increment_shift (headerExtra + 1) value earlier following).asWordRun.context [false, false] [false, false]
  have append : WordRun endState KernelReverse.searchState (front ++ [false, false])
      (front ++ [true, false]) (2 + (input.length : Int)) ((front.length : Int) - 1) 1 := by
    have position : (front.length : Int) = 2 + (input.length : Int) := by
      dsimp [front]
      rw [lengths]
      omega
    simpa [position, Int.sub_eq_add_neg] using append_spare_contract.context front []
  have search : LeftRun KernelReverse.searchState KernelReverse.searchEndState front front := by
    dsimp [front, output]
    rw [increased_file]
    exact find_file (headerExtra :: (earlier ++ (value + 1) :: following))
  have backward : WordRun KernelReverse.searchState KernelReverse.searchEndState
      (front ++ [true, false]) (front ++ [true, false])
      ((front.length : Int) - 1) (-1) front.length := by
    simpa using search.asWordRun.context [] [true, false]
  exact (forward.trans append).trans backward

/-- A positive target keeps its remaining unary run and shifts the header right by one. -/
theorem positive_decrement_execute (headerExtra : Nat) (earlier : List Nat) (tail : List Bool) :
    WordRun shiftState KernelReverse.searchEndState
      ([false, false] ++ shiftInput (headerExtra + 1) earlier ++ true :: true :: tail)
      ([false, false] ++ shiftOutput (headerExtra + 1) earlier ++ true :: true :: tail)
      2 (-1)
      ((shiftInput (headerExtra + 1) earlier).length + 3 +
        ([false, false] ++ shiftOutput (headerExtra + 1) earlier).length) := by
  let input := shiftInput (headerExtra + 1) earlier
  let output := shiftOutput (headerExtra + 1) earlier
  let front := [false, false] ++ output
  have lengths : input.length = output.length := (right_shift (headerExtra + 1) earlier).same_length
  have forward : WordRun shiftState endState ([false, false] ++ input ++ true :: true :: tail)
      (front ++ true :: true :: tail) 2 (2 + (input.length : Int)) input.length := by
    simpa [input, output, front] using
      (right_shift (headerExtra + 1) earlier).asWordRun.context [false, false] (true :: true :: tail)
  have probe : WordRun endState KernelReverse.searchState (front ++ true :: true :: tail)
      (front ++ true :: true :: tail) (2 + (input.length : Int)) ((front.length : Int) - 1) 3 := by
    have position : (front.length : Int) = 2 + (input.length : Int) := by
      dsimp [front]
      rw [lengths]
      omega
    simpa [position, List.append_assoc, Int.sub_eq_add_neg] using
      positive_probe_contract.context front tail
  have search : LeftRun KernelReverse.searchState KernelReverse.searchEndState front front := by
    dsimp [front, output]
    rw [shifted_file]
    exact find_file ((headerExtra + 1) :: earlier)
  have backward : WordRun KernelReverse.searchState KernelReverse.searchEndState
      (front ++ true :: true :: tail) (front ++ true :: true :: tail)
      ((front.length : Int) - 1) (-1) front.length := by
    simpa using search.asWordRun.context [] (true :: true :: tail)
  exact (forward.trans probe).trans backward

/-- The zero branch restores every shifted register and the selected zero register itself. -/
theorem zero_decrement_execute (headerExtra : Nat) (earlier : List Nat) (tail : List Bool) :
    WordRun shiftState KernelReverse.undoEndState
      ([false, false] ++ shiftInput (headerExtra + 1) earlier ++ [true, false] ++ tail)
      (([false] ++ terminatedRuns ((headerExtra + 1) :: earlier) ++ [true]) ++ [true, false] ++ tail)
      2 (-1)
      ((shiftInput (headerExtra + 1) earlier).length + 3 +
        ([false, false] ++ shiftOutput (headerExtra + 1) earlier).length) := by
  let input := shiftInput (headerExtra + 1) earlier
  let output := shiftOutput (headerExtra + 1) earlier
  let front := [false, false] ++ output
  let restored := [false] ++ terminatedRuns ((headerExtra + 1) :: earlier) ++ [true]
  have lengths : input.length = output.length := (right_shift (headerExtra + 1) earlier).same_length
  have forward : WordRun shiftState endState ([false, false] ++ input ++ [true, false] ++ tail)
      (front ++ [true, false] ++ tail) 2 (2 + (input.length : Int)) input.length := by
    simpa [input, output, front, List.append_assoc] using
      (right_shift (headerExtra + 1) earlier).asWordRun.context [false, false] ([true, false] ++ tail)
  have probe : WordRun endState KernelReverse.undoState (front ++ [true, false] ++ tail)
      (front ++ [true, false] ++ tail) (2 + (input.length : Int)) ((front.length : Int) - 1) 3 := by
    have position : (front.length : Int) = 2 + (input.length : Int) := by
      dsimp [front]
      rw [lengths]
      omega
    simpa [position, Int.sub_eq_add_neg] using zero_probe_contract.context front tail
  have undo : LeftRun KernelReverse.undoState KernelReverse.undoEndState front restored := by
    dsimp [front, output, restored]
    rw [shifted_file]
    exact undo_file ((headerExtra + 1) :: earlier)
  have backward : WordRun KernelReverse.undoState KernelReverse.undoEndState
      (front ++ [true, false] ++ tail) (restored ++ [true, false] ++ tail)
      ((front.length : Int) - 1) (-1) front.length := by
    simpa [List.append_assoc] using undo.asWordRun.context [] ([true, false] ++ tail)
  exact (forward.trans probe).trans backward

#print axioms increment_execute
#print axioms positive_decrement_execute
#print axioms zero_decrement_execute

end P185.KernelExecute
