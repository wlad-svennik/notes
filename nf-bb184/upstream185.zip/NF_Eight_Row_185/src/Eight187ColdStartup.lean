module
public import Eight187ColdBatches
public import Eight187FrozenMP
public import Eight187SearchWords
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Eight187.Register
open Eight187
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers
open NF192.ProofSearch (pack)
theorem frozenDecZero (pc yes no : Nat) (r : Register) (rs : Registers)
    (op : frozen pc = .dec r yes no) (hz : rs r = 0) :
    Reaches frozen ⟨pc,rs⟩ (some ⟨yes,rs⟩) := by
  apply Reaches.one
  simp [NF192.Emitter.step, op, hz]

theorem frozen_mp_to_refill (ts : Nat × Nat) :
    Reaches frozen (coldFrame 2838 0 ts)
      (some ⟨2, mk9 0 0 (Cantor.unpair ts.2).2 0 0 (Cantor.unpair ts.2).1 0 0 0⟩) := by
  have h := Frozen.mp_reaches 0 ts.1 ts.2 0 0 0 0
  simp only [ite_self] at h
  exact h.trans (frozenDecZero 0 2 1 8 _ (by decide) rfl)

def startProof : Eight187.State := ⟨0,[],0,0⟩

def startupRows : List Nat := rows 0 0 0 [(0,0),(0,0)] startProof

def startupProof : Eight187.State := afterAX startProof startupRows

def beforeNipStack : List Nat := startupRows.reverse.tail ++ startProof.top :: startProof.stack

theorem startupPayload_matches : startupPayload.2 = pack beforeNipStack := by
  let xs := startupRows
  have hh : startupPayload = pushRows (startProof.top, pack startProof.stack) xs := by
    simp only [startupPayload, coldPayload, xs, startupRows, rows, tailRows, startProof,
      List.length_cons, List.length_nil, Nat.zero_add, List.append_nil, pack, pushRows_append]
  rw [hh, pushRows_lists]
  change pack ((xs.reverse ++ startProof.top :: startProof.stack).tail) =
    pack (xs.reverse.tail ++ startProof.top :: startProof.stack)
  have ne : xs.reverse ≠ [] := by
    intro h
    have zero : xs.length = 0 := by simpa using congrArg List.length h
    simp [xs, startupRows, rows, tailRows, Eight187.rowList,Eight187.Seed.eight, startProof] at zero
  cases e : xs.reverse with
  | nil => exact False.elim (ne e)
  | cons a l => rfl

theorem startupProof_sound : startupProof.Sound := by
  exact Eight187.step_sound (.ax 0 0 0 [(0,0),(0,0)]) startProof
    ⟨deriv_zero, by simp [startProof], deriv_zero⟩

theorem frozen_prefix :
    Reaches frozen (coldFrame 40 2 (0,0))
      (some ⟨2,mk9 0 startupProof.top (pack startupProof.stack) 0 0 startupProof.cache 0 0 0⟩) := by
  have h := frozen_three_batches.trans (frozen_mp_to_refill startupPayload)
  rw [startupPayload_matches, NF192.ProofSearch.pop_pack] at h
  exact h

theorem first_increment (top stack cache : Nat) :
    bootstrapStep (true,atFrame 2 ⟨0,top,stack,0,0,cache,0⟩) =
      (false,atFrame 3 ⟨0,top,stack,0,0,cache,0⟩) := by
  have inst : Raw.program 2 = Source.Command.inc 0 3 := by decide
  have finst : actual 2 = .inc 0 3 := by decide
  have same : Source.setReg (liftRegisters (mk9 0 top stack 0 0 cache 0 0 0)) 0 0 =
      liftRegisters (mk9 0 top stack 0 0 cache 0 0 0) :=
    (liftRegisters_set _ (0 : Register) 0).trans (congrArg liftRegisters (mk9_set_0 _ _ _ _ _ _ _ _ _ _))
  simp only [bootstrapStep, atFrame, Frame.regs, Source.Config.active, finst, inst, usesCounter,
    Bool.true_eq, if_true, same] <;> rfl

theorem warm_skip (top stack cache : Nat) :
    bootstrapAdvance 3 (true,atFrame 2 ⟨0,top,stack,0,0,cache,0⟩) =
      (false,atFrame 10 ⟨0,top,stack,0,0,cache,0⟩) := by
  let f : Frame := ⟨0,top,stack,0,0,cache,0⟩
  have three : Raw.program 3 = Source.Command.dec 0 7 4 false := by decide
  have seven : Raw.program 7 = Source.Command.dec 6 10 8 false := by decide
  have c₃ : Raw.step (atFrame 3 f) = atFrame 7 f := by
    simp only [atFrame, Raw.step, three]
    rfl
  have c₇ : Raw.step (atFrame 7 f) = atFrame 10 f := by
    simp only [atFrame, Raw.step, seven]
    rfl
  have h := first_increment top stack cache
  change bootstrapStep (bootstrapStep (bootstrapStep (true,atFrame 2 f))) = _
  rw [show bootstrapStep (true,atFrame 2 f) = (false,atFrame 3 f) from h]
  change (false, Raw.step (Raw.step (atFrame 3 f))) = _
  rw [c₃,c₇]

/-- From the first AX, with logical R0=-1, to a natural-register state at
ordinal 10 with logical R0=0. -/
theorem signed_startup :
    ∃ n, 0 < n ∧ bootstrapAdvance n (true,atFrame 40 ⟨0,0,0,2,0,0,0⟩) =
      (false,atFrame 10 ⟨0,startupProof.top,pack startupProof.stack,0,0,startupProof.cache,0⟩) := by
  obtain ⟨n, hn, h⟩ := frozen_prefix
  have left := frozen_run n h
  change bootstrapAdvance n (true,atFrame 40 ⟨0,0,0,2,0,0,0⟩) =
    (true,atFrame 2 ⟨0,startupProof.top,pack startupProof.stack,0,0,startupProof.cache,0⟩) at left
  exact ⟨n+3, by omega, by rw [bootstrapAdvance_add,left,warm_skip]⟩

#print axioms signed_startup
end Eight187.Register
