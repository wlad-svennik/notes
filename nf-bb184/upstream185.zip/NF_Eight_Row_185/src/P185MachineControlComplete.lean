module
public import P185CtrlWitness
public meta import P185CtrlWitness

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P185.Control
theorem cases_verified : controlCases.all verified = true := by native_decide
theorem coverage : controlCases.map Case.pc = (List.range 2959).filter (fun i => isControl (Source.siteAt i)) := by native_decide
theorem all_control_steps (i : Nat) (hi : i < 2959) (h : isControl (Source.siteAt i) = true) :
    ∃ c ∈ controlCases, c.pc = i ∧ verified c = true := by
  have hm : i ∈ (List.range 2959).filter (fun j => isControl (Source.siteAt j)) :=
    List.mem_filter.mpr ⟨List.mem_range.mpr hi, h⟩
  rw [← coverage] at hm
  obtain ⟨c,hc,he⟩ := List.mem_map.mp hm
  exact ⟨c,hc,he,List.all_eq_true.mp cases_verified c hc⟩
end P185.Control
#print axioms P185.Control.all_control_steps
