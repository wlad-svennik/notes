module
public import P185MachineCanonicalControlMasks
public meta import P185MachineCanonicalControlMasks


@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace P185.CanonicalControl
open Control Frame
theorem checked (pc : Nat) (hi : pc < 2959) : maskCheck pc = true := by
  have all_ok : checkRange 0 2959 = true := by native_decide
  exact checked_in_range all_ok (by omega) (by omega)
theorem data_for (pc : Nat) (hi : pc < 2959) :
    (addressBits pc).length ≤ 44 ∧
    BitsWord.encode (windowWord pc) = pathMask (Source.siteAt pc).address ∧
    (isControl (Source.siteAt pc) = true → Source.destination (targetAddress (Source.siteAt pc)) < 2959) :=
  of_decide_eq_true (checked pc hi)

theorem positive_prefixes : controlCases.all (fun c => decide (0 < c.prefixSteps)) = true := by native_decide

end P185.CanonicalControl
