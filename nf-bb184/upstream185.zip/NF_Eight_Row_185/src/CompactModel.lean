import CompactLogic
import CompactRows
set_option maxHeartbeats 0
namespace C196Compact
open NF192 NF192.Ground NF192.Numerical NF192.Emitter

private theorem instance_row {r} (hr : RowsHold r) (a b c : Nat) {x : Nat}
    (hx : x ∈ rowList a b c 0) : evaluate r x := hr a b c 0 (Nat.zero_le _) x hx

theorem hold_iff_rows (r : Nat → Nat → Prop) : RowsHold r ↔ NF196.Compact.Rows AsSignature r := by
  constructor
  · intro hr
    have arg (a b c) := instance_row hr a b c (x:=row2 a b c) (by simp [rowList])
    have con (a b) := instance_row hr a b 0 (x:=row4 a b) (by simp [rowList])
    have fnc (a b c) := instance_row hr a b c (x:=row3 a b c) (by simp [rowList])
    have abs (a b c) := instance_row hr a b c (x:=bRow a b c) (by simp [rowList])
    have euc (a b c) := instance_row hr a b c (x:=row6 a b c) (by simp [rowList])
    have neg (a b) := instance_row hr a b 0 (x:=testRow a b) (by simp [rowList])
    have ext (a b) := instance_row hr a b 0 (x:=row9 a b) (by simp [rowList])
    simp only [single,row2,row4,row3,bRow,row6,testRow,row9,evaluate_imp,evaluate_eqn] at *
    exact ⟨arg,con,fnc,abs,euc,neg,ext⟩
  · intro R a b c u _ x hx
    simp only [rowList, List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with hx|hx|hx|hx|hx|hx|hx|hx <;> subst x
    · simp only [row0,evaluate_imp]
      intro hca hac _
      by_cases hc : evaluate r c
      · exact hc
      · exact hac (hca (fun hc' => (hc hc').elim))
    all_goals simp only [single,row2,row4,row3,bRow,row6,testRow,row9,evaluate_imp,evaluate_eqn]
    · exact R.bLaw a b c
    · exact R.argCongr a b c
    · exact R.funCongr a b c
    · exact R.euclid a b c
    · exact R.test a b
    · exact R.kLaw a b
    · exact R.ext a b

private def pull (r : Term → Term → Prop) (a b : Nat) : Prop := r (decodeTerm a) (decodeTerm b)
private theorem pull_rows {r : Term → Term → Prop} (R : NF196.Compact.Rows Term.signature r) :
    NF196.Compact.Rows AsSignature (pull r) := by
  constructor
  all_goals
    simp only [pull, AsSignature, Signature.k, Signature.s,
      decodeTerm_app, decodeTerm_witness, decodeTerm_q]
  · exact fun a b c => R.argCongr _ _ _
  · exact fun a b => R.kLaw _ _
  · exact fun a b c => R.funCongr _ _ _
  · exact fun a b c => R.bLaw _ _ _
  · exact fun a b c => R.euclid _ _ _
  · exact fun a b => R.test _ _
  · exact fun a b => R.ext _ _

theorem ground_model_iff_chart :
    (∃ r, RowsHold r ∧ ¬ r s q) ↔ ∃ M : Type, Nonempty (NF196.Compact.Chart M) := by
  constructor
  · rintro ⟨r,h,hg⟩
    let R := (hold_iff_rows r).mp h
    exact ⟨R.Carrier, ⟨R.toChart hg⟩⟩
  · rintro ⟨M,⟨A⟩⟩
    let r := A.relation
    have R := A.term_rows
    have hg : ¬ r Term.signature.s Term.signature.q := by change A.eval Term.signature.s ≠ A.J; rw [A.eval_s]; exact A.proper
    refine ⟨pull r,(hold_iff_rows _).mpr (pull_rows R),?_⟩
    simpa only [pull,s,AsSignature,Signature.s,Term.signature,decodeTerm_app,decodeTerm_q] using hg

open FFL FFL.FirstOrder
theorem not_deriv_goal_iff_consistent : ¬ Deriv goal ↔ Entailment.Consistent 𝗡𝗙 := by
  rw [not_deriv_iff_ground_model,ground_model_iff_chart,NF196.Compact.exact_plain]

theorem deriv_goal_iff_nf_refutation : Deriv goal ↔ (𝗡𝗙 ⊢ ⊥) := by
  classical
  have e := not_congr not_deriv_goal_iff_consistent
  rw [not_not,Entailment.consistent_iff_unprovable_bot,not_not] at e
  exact e
end C196Compact
#print axioms C196Compact.ground_model_iff_chart

#print axioms C196Compact.not_deriv_goal_iff_consistent

#print axioms C196Compact.deriv_goal_iff_nf_refutation
