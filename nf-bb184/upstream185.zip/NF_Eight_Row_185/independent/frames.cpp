#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using Reg = array<int,9>;
const array<int,9> order = {2,8,1,4,3,7,0,5,6};
const int center=1024, cells=4096;
void check(bool b,const string& why){if(!b)throw runtime_error(why);}
struct Tape {
 array<uint64_t,cells/64> words{};
 int read(int p)const{check(0<=p&&p<cells,"tape bounds");return (words[p/64]>>(p%64))&1;}
 void write(int p,int b){check(0<=p&&p<cells,"tape bounds");uint64_t bit=uint64_t(1)<<(p%64);if(b) words[p/64]|=bit;else words[p/64]&=~bit;}
 bool operator==(const Tape& t)const{return words==t.words;}
};
struct Arc{int write,dir,to;};
struct Machine{
 int n,start,d0,gate;vector<array<Arc,2>> table;
 explicit Machine(const string& path){ifstream f(path);check(bool(f>>n>>start>>d0>>gate),"table header");table.resize(n);int terminal=0;
 for(int q=0;q<n;q++)for(int b=0;b<2;b++){auto&e=table[q][b];check(bool(f>>e.write>>e.dir>>e.to),"missing transition");check((e.write==0||e.write==1)&&(e.dir==-1||e.dir==1)&&0<=e.to&&e.to<=n,"invalid transition");if(e.to==n){check(q==gate&&b==1,"unexpected halt transition");terminal++;}}check(terminal==1,"halt transition count");}
};
struct Run{int q,h;Tape tape;long long ticks=0;int prev=-1,saw=-1;
 void tick(const Machine&m){check(q<m.n,"tick past halt");prev=q;saw=tape.read(h);auto a=m.table[q][saw];tape.write(h,a.write);h+=a.dir;q=a.to;ticks++;}
};
struct Row{string path,op;int a;};
struct Source{vector<Row>rows;map<string,int>Pc;int depth=0,goal=-1;
 explicit Source(const string&p){ifstream f(p);Row r;while(f>>r.path>>r.op>>r.a){int i=rows.size();check(Pc.emplace(r.path,i).second,"duplicate source path");rows.push_back(r);depth=max<int>(depth,r.path.size());if(r.op=="CD"&&r.path.back()=='1'){check(goal==-1,"two halt source sites");goal=i;}}check(!rows.empty()&&goal>=0,"source empty or missing goal");}
 int first(string p)const{while(!Pc.count(p)){p+='0';check(int(p.size())<=depth,"missing fallthrough");}return Pc.at(p);}
};
struct Frame{int pc,h,header;Reg regs;vector<int>spares;};
Tape encode(const Source&s,const Frame&f){Tape t;t.write(f.h-1,1);int x=f.h;for(char b:s.rows.at(f.pc).path)t.write(x++,b-'0');t.write(f.header,1);x=f.header+2;
 auto emit=[&](int n){check(n>=0,"negative block encoding");for(int j=0;j<n+1;j++)t.write(x++,1);x++;};for(int r:order)emit(f.regs[r]+1);for(int v:f.spares)emit(v);return t;}
bool decode(const Source&s,const Run&r,Frame&f){int amin=-1,amax=-1;for(int h=0;h<cells;h++)if(r.tape.read(h)){if(amin<0)amin=h;amax=h;}if(amin!=r.h-1)return false;string path;int c=r.h;while(!s.Pc.count(path)){if(int(path.size())==s.depth)return false;path+=char('0'+r.tape.read(c++));}while(c<=amax&&!r.tape.read(c))c++;if(c>amax||r.tape.read(c+1))return false;f.pc=s.Pc.at(path);f.h=r.h;f.header=c;c+=2;vector<int>blocks;while(c<=amax){int a=c;while(r.tape.read(c))c++;if(a==c)return false;blocks.push_back(c-a-1);c++;}if(blocks.size()<9)return false;for(int i=0;i<9;i++)f.regs[order[i]]=blocks[i]-1;f.spares.assign(blocks.begin()+9,blocks.end());return encode(s,f)==r.tape;}
string cut(string p,char side,int n){while(n--){auto k=p.rfind(side);check(k!=string::npos,"invalid source jump");p.resize(k);}return p;}
void advance(string&p,int&h){auto k=p.rfind('0');if(k==string::npos){p.clear();h--;}else p=p.substr(0,k)+'1';}
// Return false precisely for the distinguished zero-goal decrement.
bool source_step(const Source&s,Frame&f){auto row=s.rows[f.pc];string p=row.path;
 if(row.op=="CI"){f.regs[row.a]++;f.spares.push_back(0);advance(p,f.h);}
 else if(row.op=="CD"){check(f.regs[row.a]>=0,"uninitialized decrement");if(f.regs[row.a]==0){if(p.back()=='1')return false;p=cut(p,'0',1);}else{f.regs[row.a]--;f.header++;}advance(p,f.h);}
 else if(row.op=="CC")p=cut(p,'1',row.a);else if(row.op=="CB"){p=cut(p,'0',row.a);advance(p,f.h);}else throw runtime_error("invalid opcode");f.pc=s.first(p);return true;}
struct Stats{long long trials=0,steps=0,halts=0,goalpos=0,one=0,zero=0;int maximum=0;map<string,int>ops;};
int complete(const Source&s,const Machine&m,Run&r,Frame&f,bool allowhalt=true){int pc=f.pc;bool live=source_step(s,f);auto expected=live?encode(s,f):Tape{};for(int t=1;t<=250000;t++){r.tick(m);if(r.q==m.n){check(allowhalt&&!live&&pc==s.goal&&r.prev==m.gate&&r.saw==1,"unexpected halt at PC "+to_string(pc));return t;}if(live&&r.q==m.d0&&r.h==f.h&&r.tape==expected)return t;}throw runtime_error("full successor absent at PC "+to_string(pc));}
int main(int ac,char**av){try{Source s(av[1]);Machine m(av[2]),ref(av[3]);int reps=stoi(av[4]);check(m.n==185&&ref.n==196,"state count");check(reps>=9,"too few frames");Reg seed{-1,0,0,2,0,0,0,0,0};Stats stat;mt19937 rng(0x200C0DE);long long goal_replay_steps=0;int goal_checks=0,goal_zero_matches=0;int regmax=0;
 for(int pc=0;pc<int(s.rows.size());pc++)for(int j=0;j<reps;j++){
  Reg reg;for(auto&v:reg){v=j<=2?j:j==3?int(rng()%32):j==4?0:int(rng()%(2+(j%10)*2));}if(j>=4&&s.rows[pc].op=="CD")reg[s.rows[pc].a]=(j%2?1+int(rng()%18):0);for(int v:reg)regmax=max(regmax,v);
  vector<int>sp;int cnt=j<3?j:j==3?32:1+rng()%12;while(cnt--)sp.push_back(j<=2?0:rng()%8);
  Frame f{pc,center,center+s.depth+11+(j%4)*9,reg,sp};Run r{m.d0,center,encode(s,f)};auto begin=r;auto copy=f;int t=complete(s,m,r,f);
  stat.trials++;stat.steps+=t;stat.maximum=max(stat.maximum,t);stat.ops[s.rows[pc].op]++;if(s.rows[pc].op=="CD"){if(!reg[s.rows[pc].a])stat.zero++;else stat.one++;}
  if(r.q==m.n)stat.halts++;else if(pc==s.goal)stat.goalpos++;
  if(pc==s.goal){Source previous(av[5]);copy.pc=previous.goal;Run old{ref.d0,copy.h,encode(previous,copy)};int ot=complete(previous,ref,old,copy);
 check((old.q==ref.n)==(r.q==m.n),"goal decision differs from incumbent");
 for(int cell=0;cell<cells;cell++)if(cell<center-1||cell>=center+max(previous.depth,s.depth)+1)check(old.tape.read(cell)==r.tape.read(cell),"goal register tape differs from incumbent");
 if(r.q==m.n){check(old.h-center-(int)previous.rows[previous.goal].path.size()==r.h-center-(int)s.rows[s.goal].path.size(),"halt head offset differs");}goal_replay_steps+=ot;goal_checks++;if(r.q==m.n)goal_zero_matches++;}
 }
 Run boot{m.start,center,{}};Frame f;for(;;){boot.tick(m);check(boot.q!=m.n&&boot.ticks<=1000000,"blank anchor missing");if(boot.q==m.d0&&decode(s,boot,f)&&f.pc==40&&f.regs==seed)break;}auto anchor=boot.ticks;int apc=f.pc,anchorhead=f.h-center,ah=f.header-center;int checked=0;
 while(f.header-f.h<=s.depth+10){complete(s,m,boot,f,false);checked++;check(checked<2000,"blank bridge too long");}
 Frame ff;check(decode(s,boot,ff)&&ff.pc==f.pc&&ff.regs==f.regs&&f.regs[0]==-1,"cold endpoint mismatch");int bp=f.pc,bh=f.h-center,gap=f.header-f.h;long long bridge=boot.ticks;
 for(int i=0;i<240;i++){complete(s,m,boot,f,false);}Frame extra;check(decode(s,boot,extra)&&extra.pc==f.pc&&extra.regs==f.regs,"extra cold endpoint mismatch");
 cout<<"{\n  \"working_states\": "<<m.n<<", \"transitions\": "<<2*m.n<<", \"source_PCs\": "<<s.rows.size()<<", \"depth\": "<<s.depth<<",\n  \"fixtures_per_PC\": "<<reps<<", \"frames\": "<<stat.trials<<", \"literal_steps\": "<<stat.steps<<", \"longest_primitive\": "<<stat.maximum<<", \"max_test_register\": "<<regmax<<",\n  \"CI\": "<<stat.ops["CI"]<<", \"CD_positive\": "<<stat.one<<", \"CD_zero\": "<<stat.zero<<", \"CC\": "<<stat.ops["CC"]<<", \"CB\": "<<stat.ops["CB"]<<",\n  \"halt_PC\": "<<s.goal<<", \"halt_gate_frames\": "<<stat.halts<<", \"positive_goal_fallthrough_frames\": "<<stat.goalpos<<", \"incumbent_goal_matches\": "<<goal_checks<<", \"incumbent_halting_register_tapes_matched\": "<<goal_zero_matches<<", \"incumbent_goal_test_steps\": "<<goal_replay_steps<<",\n  \"blank_anchor\": {\"step\": "<<anchor<<", \"pc\": "<<apc<<", \"head\": "<<anchorhead<<", \"header\": "<<ah<<"},\n  \"blank_bridge\": {\"step\": "<<bridge<<", \"pc\": "<<bp<<", \"head\": "<<bh<<", \"gap\": "<<gap<<", \"exact_primitive_returns\": "<<checked<<"},\n  \"extended_blank_replay\": {\"step\": "<<boot.ticks<<", \"pc\": "<<f.pc<<", \"head\": "<<f.h-center<<", \"additional_primitive_returns\": 240}\n}\n";return 0;
 }catch(exception&e){cerr<<e.what()<<'\n';return 1;}}
