# Pure Quine NF in 185 working states

`candidate.tm` is a deterministic two-symbol Turing machine with 185 working states, 370 transitions and a separate halt. Its start state is `k:64` and its tape starts blank. Lean 4.35.0 proves

```lean
NFMachine185.halts_iff_nf_refutation :
  TM.Halts CS185.Table.machine CS185.Table.start ↔ (𝗡𝗙 ⊢ ⊥)
```

The left side refers to this literal transition table. The right side says that pure Quine NF proves a contradiction. The proof covers unbounded execution in both directions. The designated equation is (JJ) = J, with numerical code 3. The file `NF_Eight_Row_185.wiki` gives all eight schemata in the order and equality orientation emitted by this table.

The single partial equality test replaces the previous two tester rows and assigns the abstraction role to JJ. The register proof search builds precisely the formulas derivable in its emitted calculus. It uses 2,959 register instructions. An 188-state layout for that program was reduced through 187 and 186 states to 185 while preserving the complete register control graph. The selected table has SHA-256 `5504746071e10a0555754b55efc2da348ebfb1f8e8ab5bc7af474eaad81f60fe`.

## Reproduction

Extract this directory, then use Python 3, a C++17 compiler and the pinned Lean 4.35.0 toolchain. The Lake manifest pins the external Mathlib dependencies. Run

```sh
sha256sum -c SHA256SUMS
python3 descent/replay.py
python3 verify.py
python3 independent/run.py candidate.tm source.sites.json reference/counting196.tm --fixtures 48 --output /tmp/nf185-frames.json
lake exe cache get
lake env python3 replay.py --jobs 3 --build /tmp/nf185-proof
```

`verify.py` compares the machine's bytes with the Lean literal, checks every transition against the executable Lean definition, unpacks the addresses for all 2,959 instructions, and tests the physical decoder. The independent simulator checked 142,032 complete tape frames and 86,806,365 literal steps, including zero and positive registers at the unique halting instruction. The separate blank-tape boot certificate reaches the formal register simulation at step 59,905.

The source replay covers 268 bundled Lean modules. The main theorem uses propositional extensionality, classical choice, quotient soundness, and eleven finite native checks of the transition and address tables. The pure eight-schema calibration and the register-to-goal theorem each use only the three standard Lean assumptions. The module prefix Eight187 identifies the shared 2,959-instruction register program first used by a 187-state layout. The physical machine is CS185.Table.machine.

## The proof chain

| Module | Result |
|---|---|
| `Eight187Search.lean` | Completeness of finite proof-word enumeration |
| `Eight187Cold.lean` | Signed register halting exactly when the emitted goal has a derivation |
| `P185End.lean` | Unbounded simulation of the signed register program by the literal binary table |
| `Eight187Exact.lean` | Every formula has the same derivability in the emitted variant and its eight-schema reference calculus |
| `CompactModel.lean` | The reference calculus derives the goal exactly when pure NF proves bottom |
| `NF185Exact.lean` | The direct, blank-tape halting theorem above |

## Independent proof replay

The second build checked the source fingerprints and dependency closure of 159 modules from the independently replayed 188-state calibration and 187-state verification packages. It recompiled the other 109 modules, including the 185-state physical proof, register proof search, and final pure NF theorem. Its exact audit is in `receipts/NF185Exact-independent.log`. The default public replay command rebuilds all 268 project modules from source.

The optional `comparison` directory proves that the 185-state and original 187-state machines have different raw numerical consequence sets. Assuming pure NF is consistent, the old positive tester instance and the new abstraction instance supplied there separate the two sets in opposite directions. Both machines still recognize precisely formal refutations of pure NF. The comparison README gives the commands to replay its five additional sources.
