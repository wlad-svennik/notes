"""Reconstruct the complete 185-state table, compare the Lean literals, and run the physical decoder tests."""
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "checks"))
from physical import check

TABLE = '5504746071e10a0555754b55efc2da348ebfb1f8e8ab5bc7af474eaad81f60fe'
PARENT = "18ec8262ccf9a52101ea2152c40b30c97eab8fa1a259d3396d6c9719bf4b8662"
SOURCE = '5475cceee03b081dee3eddb77bd721c7130d81cff98be6b98a79272ca912f7ce'


def require(condition, message):
    if not condition:
        raise ValueError(message)

def pinned(path, expected):
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected, "SHA-256 mismatch for " + path.name)
    return data

def main():
    if not __debug__:
        raise RuntimeError("Run with normal Python, because the physical decoder tests use assertions.")
    candidate = ROOT / "candidate.tm"
    reference = ROOT / "reference" / "counting196.tm"
    source = ROOT / "source.sites.json"
    pinned(reference, PARENT)
    signed = json.loads(pinned(source, SOURCE))
    raw = pinned(candidate, TABLE)
    header = (ROOT / "src/Table185.lean").read_text()
    dec = json.JSONDecoder()
    labels, _ = dec.raw_decode("[" + header.split("def stateNames : Array String := #[",1)[1])
    literals, _ = dec.raw_decode(header.split("def literalRows : List String := ",1)[1])
    start = int(re.search(r"def start : State := (\d+)",header)[1])
    require(len(labels) == len(set(labels)) == 185, "Invalid state count")
    require(raw == ("#! start "+labels[start]+"\n"+"".join(literals)).encode(), "Lean literal mismatch")
    body = header[header.index("def instructionPair"):header.index("def machine")]
    pairs = re.findall(r"⟨(true|false), \.(left|right), (none|some \(\d+ : State\))⟩",body)
    require(len(pairs) == len(literals) == 370, "Incomplete transition function")
    literalset = set(literals)
    require(len(literalset)==370,"Duplicate transition")
    for i,(bit,where,target) in enumerate(pairs):
        dest = "halt" if target == "none" else labels[int(re.search(r"\d+",target)[0])]
        expected = f"{labels[i//2]} {i%2} {int(bit=='true')} {'L' if where=='left' else 'R'} {dest}\n"
        require(expected in literalset, "Wrong literal at transition "+str(i))
    data = (ROOT / "src/P185MachineSourceData.lean").read_text()
    block = data.split("def packedSites : Array Nat := #[",1)[1].split("]",1)[0]
    words = [int(w,16) for w in re.findall(r"0x[0-9a-f]+",block)]
    ops = {"CI":0,"CD":1,"CB":2,"CC":3}
    require(len(signed)==2959 and len(words)==(len(signed)+15)//16,"Incorrect source length")
    for i,(path,op,reg) in enumerate(signed):
        val = (int("1"+path,2)<<6) | (reg<<2) | ops[op]
        require((words[i//16]>>(64*(i%16))) % (1<<64) == val, "Wrong source instruction "+str(i))
    cnt, rightmost = check(source,candidate,ROOT / "reference/NF192.tm",max(len(p) for p,_,_ in signed)+14)
    require(cnt=={'arithmetic': 6129, 'shifted': 57, 'break': 58, 'continue': 858} and rightmost==37, "Unexpected decoder coverage")
    print("Verified 185 states, 370 transitions, the literal register source, and the decoder tests.")
if __name__ == "__main__":
    main()
