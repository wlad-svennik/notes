# Reconstructing the 185-state table

Run `python3 replay.py` here. It starts from the 188-state layout of the same eight-schema calculus, applies the retained symbolic transition edits, removes graph-unreachable states, and compares the literal bytes at 187, 186 and 185 states. Pass a new filename to keep the final table.

The 188-state seed in this directory implements the eight-schema register program. The historical 188-state pure NF table in the separate research handoff under `data188-plain` implements the nine-schema register program. The verification package separately proves the 185-state table's unbounded blank-tape equivalence to a refutation of pure NF.
