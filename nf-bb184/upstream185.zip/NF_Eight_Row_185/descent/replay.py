"""Reconstruct the three literal reductions from the bundled 188-state seed."""
from pathlib import Path
import hashlib
import json
import sys

home = Path(__file__).resolve().parent
data = (home / 'start188.tm').read_bytes()
for stage in json.loads((home / 'edits.json').read_text()):
    if hashlib.sha256(data).hexdigest() != stage['from_sha256']:
        raise ValueError('Incorrect parent checksum')
    lines = data.decode().splitlines()
    header = lines[0]
    start = header.split()[-1]
    arcs = {}
    for line in lines[1:]:
        q, b, w, d, t = line.split()
        arcs[q, int(b)] = [int(w), d, t]
    for change in stage['edits']:
        key = (change['state'], change['read'])
        if arcs[key] != change['before']:
            raise ValueError('Incorrect parent transition at ' + str(key))
        arcs[key] = change['after']
    live = {start}
    pending = [start]
    for q in pending:
        for bit in (0, 1):
            target = arcs[q, bit][2]
            if target != 'halt' and target not in live:
                live.add(target)
                pending.append(target)
    if sorted({q for q, _ in arcs} - live) != stage['removed'] or len(live) != stage['to_states']:
        raise ValueError('Reachability mismatch')
    text = [header]
    for q in sorted(live):
        for bit in (0, 1):
            w, d, t = arcs[q, bit]
            text.append(f'{q} {bit} {w} {d} {t}')
    data = ('\n'.join(text) + '\n').encode()
    if hashlib.sha256(data).hexdigest() != stage['to_sha256']:
        raise ValueError('Child checksum mismatch')
    print(stage['to_states'], stage['to_sha256'])
if len(sys.argv) == 2:
    with Path(sys.argv[1]).open('xb') as out:
        out.write(data)
