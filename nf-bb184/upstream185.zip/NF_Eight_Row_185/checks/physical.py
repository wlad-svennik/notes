"""Replay the countdown decoder's source-specific phase and control identities.

The parametric register-arithmetic theorem is inherited from NF192. These checks
test the literal transitions at all source addresses used by that interface.
"""
import argparse
from collections import Counter
from pathlib import Path
import json
from blank_replay import read_table, advance, cut


def move(table, config):
    q, head, ones = config
    bit, direction, nxt = table[q, int(head in ones)]
    updated = (ones | {head}) if bit else (ones - {head})
    return nxt, head + direction, updated


def bounded(table, start, end, left, right):
    seen = set()
    reads = []
    current = start
    while not reads or current != end:
        state, head, ones = current
        assert left <= head < right and state != 'halt'
        assert (state, int(head in ones)) != ('k:302', 1)
        key = state, head, frozenset(ones)
        assert key not in seen and len(reads) < 1024
        seen.add(key)
        reads.append(head)
        current = move(table, current)
    return reads


def ones_at(path, offset=0):
    return {offset-1} | {offset+i for i, c in enumerate(path) if c == '1'}


def after(table, start, steps):
    for _ in range(steps):
        start = move(table, start)
    return start


def check(program, candidate, parent, margin):
    rows = json.loads(program.read_text())
    table = read_table(candidate)[0].table
    old = read_table(parent)[0].table
    keys = {k for k in old.keys() | table.keys() if k[0].startswith('k')}
    donor_edge = 'k16share:1', 0
    assert all(old.get(k) == table.get(k) for k in keys - {donor_edge})
    donor = table[donor_edge][2]
    assert table[donor_edge] == (1, -1, donor)
    assert after(table, (donor, 0, {1}), 2) == ('k16share:1', 0, set())
    assert after(table, (donor, 0, {0, 1}), 2) == ('k:2', 0, {0})
    assert {k for k,v in table.items() if v[2]=='halt'} == {('k:302',1)}
    assert rows[0] == ['00000','CD',8]
    assert [i for i,(p,op,r) in enumerate(rows) if op=='CD' and p.endswith('1')] == [2942]
    assert all('000000' not in p and not (op=='CI' and p.endswith('00000')) for p,op,r in rows)
    selector = ['k:22','k:25','k:51','k:32','k:48','k:55','k:60','k:33','k:36']
    depth = max(len(p) for p, _, _ in rows)
    assert margin >= depth+11
    counts = Counter()
    largest = -1
    for address, op, operand in rows:
        n = len(address)
        base = ones_at(address)
        if op in ('CD','CI'):
            for phase in ('00','11','01'):
                ones = ones_at(address+phase)
                if phase == '00':
                    target = ('k:49' if op=='CI' else 'k:24', n+1, ones)
                elif phase == '11':
                    target = selector[operand], n+1, ones-{n}
                else:
                    target = ('k:64' if op=='CI' else 'k:0', n+2, ones-{n+1})
                bounded(table, ('d:0',0,ones), target, -1,n+2)
                counts['arithmetic'] += 1
            if op == 'CD' and address.endswith('00000'):
                ones = ones_at(address+'01')
                bounded(table, ('d:0',n-5,ones), ('k:0',n+2,ones-{n+1}), -1,n+2)
                counts['shifted'] += 1
        elif op == 'CC':
            want = ones_at(cut(address,'1',operand))
            touched=bounded(table, ('d:0',0,base), ('d:0',0,want), -8,depth+1)
            largest=max(largest,max(touched))
            counts['continue'] += 1
        elif op=='CB':
            delta,path=advance(cut(address,'0',operand))
            want=ones_at(path,delta)
            c=('d:0',0,base)
            seen=set()
            while c[0]!='k:6':
                q,h,ones=c
                assert -2<=h<n+2 and (q,int(h in ones))!=('k:302',1)
                key=q,h,frozenset(ones)
                assert key not in seen
                seen.add(key)
                c=move(table,c)
            assert c[2]==want and all(j<c[1] for j in want)
            bounded(table,('k:2',max(want),want),('d:0',delta,want),delta-9,depth+1)
            counts['break'] += 1
        else:
            raise ValueError(op)
    assert largest < margin
    return dict(counts),largest

if __name__=='__main__':
    root=Path(__file__).resolve().parent.parent
    expected=json.loads((root/'combinator/kernel_check.json').read_text())
    counts,ceiling=check(root/'combinator/source.sites.json',root/'combinator/machine.tm',
                          root/'checks/NF192.tm',expected['full_margin'])
    names={'arithmetic':'arithmetic_phase_identities','shifted':'shifted_decrement_identities',
           'continue':'control_continue_identities','break':'control_break_prefixes'}
    assert all(counts[k]==expected[v] for k,v in names.items())
    assert ceiling==expected['max_control_right_read']
    print(json.dumps(counts))
