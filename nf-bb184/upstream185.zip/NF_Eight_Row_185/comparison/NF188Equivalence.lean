import NF188PureUpper
import ChoppedChartNF

namespace NF188.Pure
open FFL FFL.FirstOrder
theorem consistent_iff_chart : Entailment.Consistent 𝗡𝗙 ↔ ∃ V : Type, Nonempty (Chart V) :=
  ⟨chart_of_consistent,fun ⟨_,⟨A⟩⟩=> A.consistent_nf⟩

theorem consistent_iff_nonderivable_goal :
    Entailment.Consistent 𝗡𝗙 ↔ ¬ C188.Deriv NF192.Numerical.goal :=
  consistent_iff_chart.trans (C188.not_deriv_iff_ground_model.trans C188.ground_model_iff_chart).symm

end NF188.Pure

#print axioms NF188.Pure.consistent_iff_nonderivable_goal
