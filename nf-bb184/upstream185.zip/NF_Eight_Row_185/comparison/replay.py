"""Replay the comparison after rebuilding the main machine package."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

here = Path(__file__).resolve().parent
build = Path(sys.argv[1]).resolve()
if not (build / 'Eight187Exact.olean').is_file():
    raise ValueError('Use the completed main verification build as the argument')
sources = json.loads((here / 'extra-sources.json').read_text())
imports = re.compile(r'^\s*(?:(?:public|meta|private)\s+)*import\s+(?:all\s+)?([\w.]+)', re.M)
env = dict(os.environ, LEAN_PATH=os.pathsep.join([str(build), os.getenv('LEAN_PATH','')]))
pending = set(sources)
while pending:
    previous = len(pending)
    for name in sorted(pending):
        source = here / Path(*name.split('.')).with_suffix('.lean')
        if hashlib.sha256(source.read_bytes()).hexdigest() != sources[name]:
            raise ValueError('Source mismatch in ' + name)
        if pending.intersection(imports.findall(source.read_text())):
            continue
        rel = source.relative_to(here)
        obj = build / rel.with_suffix('.olean')
        obj.parent.mkdir(exist_ok=True, parents=True)
        text = subprocess.check_output(['lean', '-j1', '-s', '131072', '-o', str(obj), str(rel)], cwd=here, env=env, text=True)
        if 'sorryAx' in text or "uses 'sorry'" in text:
            raise ValueError('Unresolved proof in ' + name)
        if name == 'RawSeparation' and 'depends on axioms: [propext, Classical.choice, Quot.sound]' not in text:
            raise ValueError('Unexpected axiom audit in ' + name)
        pending.remove(name)
        print(name, flush=True)
    if len(pending) == previous:
        raise ValueError('Cannot order the remaining modules')
