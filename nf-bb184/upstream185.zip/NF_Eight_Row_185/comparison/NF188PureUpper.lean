import NF188OldBasis
import ChoppedFour
import NF188Tester
import ChoppedSwap

noncomputable section
open Classical
open FFL FFL.FirstOrder FFL.FirstOrder.SetTheory
namespace NF188.Pure
open NFFn NFFn.NF188Finite

/-- The intrinsic graph application of each standard pure-NF model gives an exact nine-row chart. -/
theorem chart_of_model (V : Type) [SetStructure V] [Nonempty V] [hT : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙] :
    Nonempty (Chart V) := by
  let A : Relabel.Basis V := oldBasis
  obtain ⟨d,hd⟩ := four_labels V
  obtain ⟨q,hq⟩ := exists_cycle (d 0) (d 1) (d 2)
  obtain ⟨u,hu⟩ := TaggedFixedPoint.exists_tester q (oldK q)
  have tests (f x : V) := ((hu f _).mp (oldApp_spec u f) x _).mp (oldApp_spec (oldApp u f) x)
  let S : Upper.Seed V := {
    old := oldApp
    K := oldK
    constant := A.k_app
    ext := A.ext
    Q := q
    U := u
    d := d
    inj := hd
    cycle := fun x => (hq x _).mp (oldApp_spec q x)
    yes := by
      intro f x eq
      exact (tests f x).resolve_right (fun h => h.1 ((oldApp_iff _ _ _).mpr eq)) |>.2
    no := by
      intro f x ne
      exact (tests f x).resolve_left (fun h => ne ((oldApp_iff _ _ _).mp h.1)) |>.2 }
  obtain ⟨p,hp⟩ := exists_swap q u
  have represents (x : V) : A.app p x = S.swap x := (hp x _).mp (oldApp_spec p x)
  have square (x : V) : A.app p (A.app p x)=x := by rw [represents,represents,S.invol]
  let B := Relabel.Syntax.abstractor A p
  refine ⟨S.chart B (fun f g x => ?_)⟩
  have h := Relabel.Syntax.abstractor_law A p square f g x
  have sameApp : S.old = A.app := rfl
  have sameK : S.K = A.K := rfl
  simpa only [represents,Upper.Seed.app,Upper.Seed.K',sameApp,sameK,B] using h

theorem chart_of_consistent (h : Entailment.Consistent 𝗡𝗙) : ∃ V : Type, Nonempty (Chart V) := by
  by_contra no
  have bot : 𝗡𝗙 ⊢ (⊥ : Sentence ℒₛₑₜ) := by
    apply SetTheory.complete.{0}
    intro V _ _ _
    exact False.elim (no ⟨V,chart_of_model V⟩)
  exact (Entailment.consistent_iff_unprovable_bot.mp h) bot

end NF188.Pure
end
#print axioms NF188.Pure.chart_of_consistent
