module
public import C188RelabelBasis
public import C188GroundChart
@[expose] public section
namespace Eight187.Separation
section NewAlgebra
variable {V : Type} (A : NF188.Relabel.Basis V) (J : V) (neq : A.B ≠ J)
include J neq
local infixl:72 " ⬝ " => A.app

theorem b_ne_constant (v : V) : A.B ≠ A.K v := by
  intro flat
  have line (y : V) : y=(v ⬝ J) ⬝ J := by
    have eq := congrArg (fun k => ((k ⬝ A.K (A.K y)) ⬝ J) ⬝ J) flat
    simpa only [A.b_app,A.k_app] using eq
  exact neq ((line A.B).trans (line J).symm)

theorem positive_impossible :
    A.B ≠ (A.B ⬝ A.K (A.K (A.K J))) ⬝ A.K (A.K J) := by
  intro p
  apply b_ne_constant A J neq (A.K J)
  apply p.trans
  apply A.ext
  intro x
  simp only [A.b_app,A.k_app]
end NewAlgebra

section OldAlgebra
variable {V : Type} (A : NF188.Chart V)
local infixl:72 " ⬝ " => A.app
theorem b_impossible (h :
    ((((A.J ⬝ A.J) ⬝ A.K (A.K (A.K A.J))) ⬝ A.K (A.K A.J)) ⬝ A.K A.J) =
    (A.K (A.K (A.K A.J)) ⬝ A.K (A.K A.J)) ⬝ (A.K (A.K A.J) ⬝ A.K A.J)) : False := by
  have eq := A.positive (A.K (A.K (A.K A.J))) (A.K (A.K A.J)) (A.k_app ..)
  simp only [eq,A.k_app] at h
  have atJ := congrArg (fun t => t ⬝ A.J) h
  have posK := A.positive (A.K A.J) A.J (A.k_app ..)
  exact A.goal (by simpa only [posK,A.k_app] using atJ)
end OldAlgebra

end Eight187.Separation
