# Comparing the two pure NF proof searches

Assume pure NF is consistent. Let J be the primitive term, z = KJ, g = Kz and f = Kg. The old positive tester row at (f,g) is derivable in the nine-schema calculus used by the 187-state machine. The 185-state calculus cannot derive it. Conversely the new abstraction row applied to f, g and z is an axiom of the 185-state calculus. The 187-state calculus cannot derive it. Both formulas use the same natural-number syntax. The exact decimal codes are in `RawSeparation.lean`. Both programs still halt on exactly the same mathematical condition.

The theorem `Eight187.Separation.incomparable` formalizes these two examples. Run the following after the main replay from the root of this verification package.

```sh
lake env python3 comparison/replay.py /tmp/nf185-proof
```

The comparison reuses that build and checks its extra source files in dependency order. Its theorem audit uses propositional extensionality, classical choice and quotient soundness.
