module
public import C188GroundChart
public import Mathlib.Data.Fintype.Pigeonhole
public import Mathlib.Tactic.FinCases
@[expose] public section
namespace NF188.Upper
open Function
noncomputable section
open Classical
/-- The old evaluators of the NF function chart. The fixed-point tester U can have any pair of
distinct named results. Q is a fixed-point-free three-valued row. -/
structure Seed (V : Type) where
  old : V → V → V
  K : V → V
  constant : ∀ a x, old (K a) x = a
  ext : ∀ {f g}, (∀x, old f x = old g x) → f = g
  Q : V
  U : V
  d : Fin 4 → V
  inj : Injective d
  cycle : ∀ x, old Q x = if x=d 0 then d 1 else if x=d 1 then d 2 else d 0
  yes : ∀ f x, old f x=x → old (old U f) x=Q
  no : ∀ f x, old f x≠x → old (old U f) x=K Q

private theorem wider {V : Type} {n m : Nat} (lt : m<n) (f : Fin n → V) (hi : Injective f)
    (g : Fin m → V) (cover : ∀ i, ∃ j, f i=g j) : False := by
  choose k hk using cover
  have inj : Injective k := fun i j h => hi ((hk i).trans ((congrArg g h).trans (hk j).symm))
  have le := Fintype.card_le_of_injective k inj
  simp only [Fintype.card_fin] at le
  omega
namespace Seed
variable {V : Type} (S : Seed V)
local infixl:71 " ∘₀ " => S.old
abbrev J := S.K S.Q
theorem qfree (x : V) : S.Q ∘₀ x ≠ x := by
  rw [S.cycle]; split_ifs with h k
  · rw [h]; exact fun e => (by decide : (1:Fin 4)≠0) (S.inj e)
  · rw [k]; exact fun e => (by decide : (2:Fin 4)≠1) (S.inj e)
  · exact Ne.symm h
theorem qj : S.Q ≠ S.J := fun e => S.qfree S.Q ((congrArg (fun z => S.old z S.Q) e).trans (S.constant S.Q S.Q))
theorem ufree (f : V) : S.U ∘₀ f ≠ f := by
  intro e; by_cases h : f ∘₀ S.J = S.J
  · exact S.qj ((S.yes f S.J h).symm.trans ((congrArg (fun g => g ∘₀ S.J) e).trans h))
  · exact h ((congrArg (fun g => g ∘₀ S.J) e).symm.trans (S.no f S.J h))
theorem u_constants : Injective (fun x => S.U ∘₀ S.K x) := by
  intro x y e; by_contra ne
  have hpos := S.yes (S.K x) x (S.constant x x)
  have hneg := S.no (S.K y) x (by rw [S.constant]; exact Ne.symm ne)
  exact S.qj (hpos.symm.trans ((congrArg (fun g => g ∘₀ x) e).trans hneg))
theorem qu : S.Q ≠ S.U := by
  intro eq
  apply wider (by decide : 3<4) _ (S.u_constants.comp S.inj) (fun j : Fin 3 => S.d j.castSucc)
  intro i; change ∃ j : Fin 3, S.U ∘₀ S.K (S.d i)=S.d j.castSucc
  rw [←eq,S.cycle]; split_ifs
  · exact ⟨1,rfl⟩
  · exact ⟨2,rfl⟩
  · exact ⟨0,rfl⟩
theorem outputs (f x : V) : S.U ∘₀ f ∘₀ x = S.Q ∨ S.U ∘₀ f ∘₀ x=S.J := by
  by_cases h : f ∘₀ x=x
  · exact Or.inl (S.yes _ _ h)
  · exact Or.inr (S.no _ _ h)
def marker : Fin 2 → V := fun i => if i=0 then S.Q else S.J
theorem marker_cover (f x : V) : ∃ n : Fin 2, S.U ∘₀ f ∘₀ x = S.marker n := by
  rcases S.outputs f x with h|h
  · exact ⟨0,h⟩
  · exact ⟨1,h⟩
theorem named (f : V) : S.U ∘₀ f ≠ S.Q ∧ S.U ∘₀ f ≠ S.U := by
  constructor
  · intro eq
    apply wider (by decide : 2<3) (fun j : Fin 3 => S.d j.castSucc)
      (S.inj.comp (Fin.castSucc_injective 3)) S.marker
    have hn (i j : Fin 4) (h : i≠j) : S.d i≠S.d j := fun e => h (S.inj e)
    have h (x : V) := S.marker_cover f x
    rw [eq] at h
    intro i
    fin_cases i
    · simpa [S.cycle,hn 2 0 (by decide),hn 2 1 (by decide)] using h (S.d 2)
    · simpa [S.cycle] using h (S.d 0)
    · simpa [S.cycle,hn 1 0 (by decide)] using h (S.d 1)
  · intro eq
    apply wider (by decide : 2<4) _ (S.u_constants.comp S.inj) S.marker
    intro i; have h := S.marker_cover f (S.K (S.d i)); rw [eq] at h; exact h
def swap (x : V) := if x=S.Q then S.U else if x=S.U then S.Q else x
theorem swapQ : S.swap S.Q=S.U := by simp [swap]
theorem swapU : S.swap S.U=S.Q := by simp [swap,Ne.symm S.qu]
theorem stable {x : V} (q : x≠S.Q) (u : x≠S.U) : S.swap x=x := by simp [swap,q,u]
theorem invol : Involutive S.swap := by
  intro x; by_cases q : x=S.Q
  · rw [q,S.swapQ,S.swapU]
  · by_cases u : x=S.U
    · rw [u,S.swapU,S.swapQ]
    · rw [S.stable q u,S.stable q u]
def app (f x : V) := S.old (S.swap f) x
def K' (x : V) := S.swap (S.K x)
theorem k' (a x : V) : S.app (S.K' a) x=a := by rw [app,K',S.invol,S.constant]
theorem ext' {f g : V} (h : ∀ x, S.app f x=S.app g x) : f=g :=
  S.invol.injective (S.ext h)
theorem fixed (f x : V) : S.app f x=x ↔ S.old f x=x := by
  by_cases q : f=S.Q
  · rw [q,app,S.swapQ]; exact iff_of_false (S.ufree _) (S.qfree _)
  · by_cases u : f=S.U
    · rw [u,app,S.swapU]; exact iff_of_false (S.qfree _) (S.ufree _)
    · rw [app,S.stable q u]
theorem jrow (x : V) : S.app S.J x=S.Q := by
  have uq : S.J≠S.U := fun e=> S.ufree S.Q ((congrArg (fun z => S.old z S.Q) e).symm.trans (S.constant S.Q S.Q))
  rw [app,S.stable (Ne.symm S.qj) uq,S.constant]
theorem test (f x : V) : S.app (S.app S.Q f) x=S.old (S.old S.U f) x := by
  unfold app; rw [S.swapQ,S.stable (S.named f).1 (S.named f).2]
def chart (B : V) (abstract : ∀ f g x,
    S.app (S.app (S.app B f) g) x=S.app (S.app f (S.K' x)) (S.app g x)) : NF188.Chart V where
  app := S.app
  K := S.K'
  J := S.J
  B := B
  k_app := S.k'
  b_app := abstract
  ext := S.ext'
  positive f x h := by rw [S.jrow,S.test]; exact S.yes f x ((S.fixed f x).mp h)
  negative f x h := by rw [S.jrow,S.test]; exact S.no f x (fun e=> h ((S.fixed f x).mpr e))
  goal := by rw [S.jrow]; exact S.qj
  separates := by rw [S.jrow,S.jrow,app,S.swapQ]; exact (S.named B).1
end Seed
end
end NF188.Upper
#print axioms NF188.Upper.Seed.chart
