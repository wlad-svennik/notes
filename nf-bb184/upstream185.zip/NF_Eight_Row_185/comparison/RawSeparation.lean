import Eight187Exact
import RawSeparationAlgebra
import NF188Equivalence

open FFL FFL.FirstOrder NF192.Numerical

namespace Eight187.Separation
abbrev z := konst q
abbrev g := konst z
abbrev f := konst g
def oldOnly := C188.positiveRow f g
def newOnly := C196Compact.bRow g z f

theorem display_codes :
    oldOnly = 15328184172221404828357668267846290046169481793638343600 ∧
    newOnly = 15328184172221404928029648163073479155155481423270243945 := by decide

theorem old_proves : C188.Deriv oldOnly :=
  .row (a:=f) (b:=g) (c:=0) (u:=0) (Nat.zero_le _) (.tail _ (.head _))

theorem new_proves : Eight187.Deriv newOnly := (Eight187.deriv_iff_compact _).mpr
  (.row (a:=g) (b:=z) (c:=f) (u:=0) (Nat.zero_le _) (.tail _ (.head _)))

theorem new_cannot_prove_old (consistent : Entailment.Consistent 𝗡𝗙) :
    ¬ Eight187.Deriv oldOnly := by
  obtain ⟨r,hr,hg⟩ := C196Compact.not_deriv_iff_ground_model.mp
    (C196Compact.not_deriv_goal_iff_consistent.mpr consistent)
  let R := (C196Compact.hold_iff_rows r).mp hr
  intro p
  have vc := C196Compact.evaluate_deriv hr ((Eight187.deriv_iff_compact _).mp p)
  have ep : r (app f g) g → r s (app (app s f) g) := by
    simpa only [oldOnly,C188.positiveRow,← s_is_one,evaluate_imp,evaluate_eqn] using vc
  have eq := R.obj_eq_iff.mpr (ep (R.kLaw g g))
  let A := R.toChart hg
  exact positive_impossible A.toBasis A.J A.proper eq

theorem old_cannot_prove_new (consistent : Entailment.Consistent 𝗡𝗙) :
    ¬ C188.Deriv newOnly := by
  obtain ⟨r,hr,hg⟩ := C188.not_deriv_iff_ground_model.mp
    (NF188.Pure.consistent_iff_nonderivable_goal.mp consistent)
  let R := (C188.hold_iff_rows r).mp hr
  intro p
  have vc := C188.evaluate_deriv hr p
  have v : r (app (app (app s f) g) z) (app (app f (konst z)) (app g z)) :=
    (evaluate_eqn r _ _).mp vc
  have eq := R.obj_eq_iff.mpr v
  exact b_impossible (R.toChart hg) eq

/-- The unchanged raw numeral language separates these two equiconsistent proof systems. -/
theorem incomparable (h : Entailment.Consistent 𝗡𝗙) :
    (C188.Deriv oldOnly ∧ ¬ Eight187.Deriv oldOnly) ∧
    (Eight187.Deriv newOnly ∧ ¬ C188.Deriv newOnly) :=
  ⟨⟨old_proves,new_cannot_prove_old h⟩,⟨new_proves,old_cannot_prove_new h⟩⟩
end Eight187.Separation
#print axioms Eight187.Separation.incomparable
