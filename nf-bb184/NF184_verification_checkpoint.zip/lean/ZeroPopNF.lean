import ZeroPop
import Eight187Exact
namespace ZeroPop
open FFL FFL.FirstOrder
theorem scanner_iff_nf_refutation (start : Nat) (s : State) (hs : s.Sound) :
    (∃ t, streamRun t ⟨start,0,s⟩ = none) ↔ (𝗡𝗙 ⊢ ⊥) :=
  (stream_halting_iff_goal start s hs).trans Eight187.deriv_goal_iff_nf_refutation
end ZeroPop
#print axioms ZeroPop.scanner_iff_nf_refutation
