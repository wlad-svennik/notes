import Moving184Cold
import Moving186NF

namespace Moving184.Register
open FFL FFL.FirstOrder
theorem signed_source_halts_iff_nf_refutation :
    BootstrapHalts (true,atFrame 40 ⟨0,0,0,2,0,0,0⟩) ↔ (𝗡𝗙 ⊢ ⊥) :=
  signed_source_halts_iff_goal.trans Moving186.deriv_goal_iff_nf_refutation
end Moving184.Register
#print axioms Moving184.Register.signed_source_halts_iff_nf_refutation
