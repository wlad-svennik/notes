import CompactRows
open NF192.Ground NF196.Compact
namespace ObservationRows
variable {V : Type} (S : Signature V) (R : V → V → Prop)
def diag (x y : V) := S.app (S.app S.q (S.k x)) y
structure Probe : Prop where
  funCongr : ∀ a b c, R a c → R (S.app c b) (S.app a b)
  kLaw : ∀ a b, R (S.app (S.k b) a) b
  bLaw : ∀ a b c, R (S.app (S.app (S.app S.s c) a) b) (S.app (S.app c (S.k b)) (S.app a b))
  transport : ∀ x y f, R x y → R S.s (S.app f y) → R S.s (S.app f x)
  test : ∀ x y, (R S.s (diag S x y) → R S.s (diag S x x)) → R y x
  ext : ∀ a b, R (S.app b (S.h a b)) (S.app a (S.h a b)) → R a b

namespace Probe
variable {S R} (T : Probe S R)
include T
theorem refl (a : V) : R a a := T.test _ _ id
theorem sym {a b : V} (p : R a b) : R b a :=
  T.test a b (T.transport _ _ _ p)
theorem trans {a b c : V} (ab : R a b) (bc : R b c) : R a c :=
  T.test c a (fun h => T.transport _ _ _ (T.sym bc) (T.transport _ _ _ (T.sym ab) h))

private theorem composition (f g x : V) :
    R (S.app (S.app (S.app S.s (S.k f)) g) x) (S.app f (S.app g x)) :=
  T.trans (T.bLaw g x (S.k f)) (T.sym (T.funCongr _ (S.app g x) _ (T.kLaw (S.k x) f)))

theorem argument {x y : V} (p : R x y) (g : V) : R (S.app g x) (S.app g y) := by
  let f := S.app S.q (S.k (S.app g y))
  apply T.test (S.app g y) (S.app g x)
  intro hx
  change R S.s (S.app f (S.app g x)) at hx
  change R S.s (S.app f (S.app g y))
  have px := T.trans hx (T.sym (T.composition f g x))
  have py := T.transport _ _ _ (T.sym p) px
  exact T.trans py (T.composition f g y)

theorem toRows : NF196.Compact.Rows S R where
  argCongr := fun a _ _ h => T.argument h a
  funCongr := T.funCongr
  kLaw := T.kLaw
  bLaw := T.bLaw
  euclid := fun _ _ _ p q => T.trans (T.sym q) p
  test := fun x y h => T.sym (T.test x y (fun p => T.sym (h (T.sym p))))
  ext := T.ext

end Probe
theorem ofRows (T : NF196.Compact.Rows S R) : Probe S R where
  funCongr := T.funCongr
  kLaw := T.kLaw
  bLaw := T.bLaw
  transport := fun x y f p q => T.rel_trans q (T.rel_symm (T.argCongr f y x p))
  test := fun x y h => T.rel_symm (T.test x y (fun p => T.rel_symm (h (T.rel_symm p))))
  ext := T.ext
theorem equivalent : Probe S R ↔ NF196.Compact.Rows S R := ⟨Probe.toRows,ofRows _ _⟩
end ObservationRows
#print axioms ObservationRows.equivalent
