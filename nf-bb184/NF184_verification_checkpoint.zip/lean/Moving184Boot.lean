import MachineBits
import Moving184Table



/-! The literal blank-tape computation, in the original NF210 integer-tape
semantics. Each intermediate bit mask is only a proposed certificate.
The Lean kernel checks every transition against Moving184.Table.machine. -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace Moving184.Boot
open NF210 Moving184.Table NF192
abbrev width : Nat := 256
abbrev Prefix (duration : Nat) (first last : KernelBits.Configuration 184) : Prop :=
  ∀ (anchor : Int) (outside : TM.Tape),
    TM.run machine duration (KernelBits.embed width anchor outside first) =
      KernelBits.embed width anchor outside last

theorem checked (duration : Nat) (first last : KernelBits.Configuration 184)
    (hi : first.head < width) (h : KernelBits.run machine width duration first = some last) :
    Prefix duration first last := fun a t =>
  (KernelBits.run_sound machine width a t duration first last hi h).2

theorem compose {s t : Nat} {a b c : KernelBits.Configuration 184}
    (first : Prefix s a b) (second : Prefix t b c) : Prefix (s+t) a c := by
  intro anchor outside
  rw [TM.run_add, first anchor outside, second anchor outside]

def snap0 : KernelBits.Configuration 184 := ⟨some (149 : State), 10, 0⟩
def snap500 : KernelBits.Configuration 184 := ⟨some (155 : State), 24, 18974781696⟩
def snap1000 : KernelBits.Configuration 184 := ⟨some (34 : State), 22, 785287082240⟩
def snap1500 : KernelBits.Configuration 184 := ⟨some (149 : State), 24, 10366674858240⟩
def snap2000 : KernelBits.Configuration 184 := ⟨some (148 : State), 16, 3020201071014144⟩
def snap2500 : KernelBits.Configuration 184 := ⟨some (124 : State), 20, 25602913022832896⟩
def snap3000 : KernelBits.Configuration 184 := ⟨some (138 : State), 48, 195332323980243200⟩
def snap3500 : KernelBits.Configuration 184 := ⟨some (137 : State), 22, 195332326937274624⟩
def snap4000 : KernelBits.Configuration 184 := ⟨some (123 : State), 38, 1471539834696804608⟩
def snap4500 : KernelBits.Configuration 184 := ⟨some (133 : State), 6, 1646043044895533312⟩
def snap5000 : KernelBits.Configuration 184 := ⟨some (128 : State), 18, 12227250369938893056⟩
def snap5500 : KernelBits.Configuration 184 := ⟨some (14 : State), 10, 12515458126646061312⟩
def snap6000 : KernelBits.Configuration 184 := ⟨some (128 : State), 40, 98984500604488493312⟩
def snap6500 : KernelBits.Configuration 184 := ⟨some (124 : State), 24, 788431585491368257792⟩
def snap7000 : KernelBits.Configuration 184 := ⟨some (57 : State), 18, 788431495017898158336⟩
def snap7500 : KernelBits.Configuration 184 := ⟨some (152 : State), 4, 6299396005563649861888⟩
def snap8000 : KernelBits.Configuration 184 := ⟨some (34 : State), 32, 50377891070216333928704⟩
def snap8500 : KernelBits.Configuration 184 := ⟨some (130 : State), 2, 50377890708326683748608⟩
def snap9000 : KernelBits.Configuration 184 := ⟨some (128 : State), 44, 402987402551384855914752⟩
def snap9500 : KernelBits.Configuration 184 := ⟨some (124 : State), 24, 402987403677284746402048⟩
def snap10000 : KernelBits.Configuration 184 := ⟨some (137 : State), 34, 402987403677284763165952⟩
def snap10500 : KernelBits.Configuration 184 := ⟨some (133 : State), 44, 402987235757360708293888⟩
def snap11000 : KernelBits.Configuration 184 := ⟨some (128 : State), 30, 3223824959270050936636672⟩
def snap11500 : KernelBits.Configuration 184 := ⟨some (123 : State), 54, 3223825438581735380948224⟩
def snap12000 : KernelBits.Configuration 184 := ⟨some (123 : State), 60, 25790459019023548940256512⟩
def snap12500 : KernelBits.Configuration 184 := ⟨some (140 : State), 40, 206323427561692354152699136⟩
def snap13000 : KernelBits.Configuration 184 := ⟨some (124 : State), 16, 206323416859852936037995776⟩
def snap13500 : KernelBits.Configuration 184 := ⟨some (124 : State), 32, 1650586873007659549645092096⟩
def snap14000 : KernelBits.Configuration 184 := ⟨some (122 : State), 36, 1650586830202874738690233600⟩
def snap14500 : KernelBits.Configuration 184 := ⟨some (34 : State), 36, 13204693974693939108978373888⟩
def snap15000 : KernelBits.Configuration 184 := ⟨some (34 : State), 36, 13204693974693939108978363648⟩
def snap15500 : KernelBits.Configuration 184 := ⟨some (137 : State), 34, 13204693974693939057438731520⟩
def snap16000 : KernelBits.Configuration 184 := ⟨some (148 : State), 20, 13204693974693939590014672128⟩
def snap16500 : KernelBits.Configuration 184 := ⟨some (135 : State), 26, 13204693974693939590014690048⟩
def snap17000 : KernelBits.Configuration 184 := ⟨some (128 : State), 22, 13204693974670778377575566080⟩
def snap17265 : KernelBits.Configuration 184 := ⟨some (13 : State), 9, 13204693974678496949202594560⟩
theorem chunk500 : Prefix 500 snap0 snap500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank500 : Prefix 500 snap0 snap500 := chunk500
theorem chunk1000 : Prefix 500 snap500 snap1000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank1000 : Prefix 1000 snap0 snap1000 := @compose 500 500 snap0 snap500 snap1000 fromBlank500 chunk1000
theorem chunk1500 : Prefix 500 snap1000 snap1500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank1500 : Prefix 1500 snap0 snap1500 := @compose 1000 500 snap0 snap1000 snap1500 fromBlank1000 chunk1500
theorem chunk2000 : Prefix 500 snap1500 snap2000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank2000 : Prefix 2000 snap0 snap2000 := @compose 1500 500 snap0 snap1500 snap2000 fromBlank1500 chunk2000
theorem chunk2500 : Prefix 500 snap2000 snap2500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank2500 : Prefix 2500 snap0 snap2500 := @compose 2000 500 snap0 snap2000 snap2500 fromBlank2000 chunk2500
theorem chunk3000 : Prefix 500 snap2500 snap3000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank3000 : Prefix 3000 snap0 snap3000 := @compose 2500 500 snap0 snap2500 snap3000 fromBlank2500 chunk3000
theorem chunk3500 : Prefix 500 snap3000 snap3500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank3500 : Prefix 3500 snap0 snap3500 := @compose 3000 500 snap0 snap3000 snap3500 fromBlank3000 chunk3500
theorem chunk4000 : Prefix 500 snap3500 snap4000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank4000 : Prefix 4000 snap0 snap4000 := @compose 3500 500 snap0 snap3500 snap4000 fromBlank3500 chunk4000
theorem chunk4500 : Prefix 500 snap4000 snap4500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank4500 : Prefix 4500 snap0 snap4500 := @compose 4000 500 snap0 snap4000 snap4500 fromBlank4000 chunk4500
theorem chunk5000 : Prefix 500 snap4500 snap5000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank5000 : Prefix 5000 snap0 snap5000 := @compose 4500 500 snap0 snap4500 snap5000 fromBlank4500 chunk5000
theorem chunk5500 : Prefix 500 snap5000 snap5500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank5500 : Prefix 5500 snap0 snap5500 := @compose 5000 500 snap0 snap5000 snap5500 fromBlank5000 chunk5500
theorem chunk6000 : Prefix 500 snap5500 snap6000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank6000 : Prefix 6000 snap0 snap6000 := @compose 5500 500 snap0 snap5500 snap6000 fromBlank5500 chunk6000
theorem chunk6500 : Prefix 500 snap6000 snap6500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank6500 : Prefix 6500 snap0 snap6500 := @compose 6000 500 snap0 snap6000 snap6500 fromBlank6000 chunk6500
theorem chunk7000 : Prefix 500 snap6500 snap7000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank7000 : Prefix 7000 snap0 snap7000 := @compose 6500 500 snap0 snap6500 snap7000 fromBlank6500 chunk7000
theorem chunk7500 : Prefix 500 snap7000 snap7500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank7500 : Prefix 7500 snap0 snap7500 := @compose 7000 500 snap0 snap7000 snap7500 fromBlank7000 chunk7500
theorem chunk8000 : Prefix 500 snap7500 snap8000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank8000 : Prefix 8000 snap0 snap8000 := @compose 7500 500 snap0 snap7500 snap8000 fromBlank7500 chunk8000
theorem chunk8500 : Prefix 500 snap8000 snap8500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank8500 : Prefix 8500 snap0 snap8500 := @compose 8000 500 snap0 snap8000 snap8500 fromBlank8000 chunk8500
theorem chunk9000 : Prefix 500 snap8500 snap9000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank9000 : Prefix 9000 snap0 snap9000 := @compose 8500 500 snap0 snap8500 snap9000 fromBlank8500 chunk9000
theorem chunk9500 : Prefix 500 snap9000 snap9500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank9500 : Prefix 9500 snap0 snap9500 := @compose 9000 500 snap0 snap9000 snap9500 fromBlank9000 chunk9500
theorem chunk10000 : Prefix 500 snap9500 snap10000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank10000 : Prefix 10000 snap0 snap10000 := @compose 9500 500 snap0 snap9500 snap10000 fromBlank9500 chunk10000
theorem chunk10500 : Prefix 500 snap10000 snap10500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank10500 : Prefix 10500 snap0 snap10500 := @compose 10000 500 snap0 snap10000 snap10500 fromBlank10000 chunk10500
theorem chunk11000 : Prefix 500 snap10500 snap11000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank11000 : Prefix 11000 snap0 snap11000 := @compose 10500 500 snap0 snap10500 snap11000 fromBlank10500 chunk11000
theorem chunk11500 : Prefix 500 snap11000 snap11500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank11500 : Prefix 11500 snap0 snap11500 := @compose 11000 500 snap0 snap11000 snap11500 fromBlank11000 chunk11500
theorem chunk12000 : Prefix 500 snap11500 snap12000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank12000 : Prefix 12000 snap0 snap12000 := @compose 11500 500 snap0 snap11500 snap12000 fromBlank11500 chunk12000
theorem chunk12500 : Prefix 500 snap12000 snap12500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank12500 : Prefix 12500 snap0 snap12500 := @compose 12000 500 snap0 snap12000 snap12500 fromBlank12000 chunk12500
theorem chunk13000 : Prefix 500 snap12500 snap13000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank13000 : Prefix 13000 snap0 snap13000 := @compose 12500 500 snap0 snap12500 snap13000 fromBlank12500 chunk13000
theorem chunk13500 : Prefix 500 snap13000 snap13500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank13500 : Prefix 13500 snap0 snap13500 := @compose 13000 500 snap0 snap13000 snap13500 fromBlank13000 chunk13500
theorem chunk14000 : Prefix 500 snap13500 snap14000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank14000 : Prefix 14000 snap0 snap14000 := @compose 13500 500 snap0 snap13500 snap14000 fromBlank13500 chunk14000
theorem chunk14500 : Prefix 500 snap14000 snap14500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank14500 : Prefix 14500 snap0 snap14500 := @compose 14000 500 snap0 snap14000 snap14500 fromBlank14000 chunk14500
theorem chunk15000 : Prefix 500 snap14500 snap15000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank15000 : Prefix 15000 snap0 snap15000 := @compose 14500 500 snap0 snap14500 snap15000 fromBlank14500 chunk15000
theorem chunk15500 : Prefix 500 snap15000 snap15500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank15500 : Prefix 15500 snap0 snap15500 := @compose 15000 500 snap0 snap15000 snap15500 fromBlank15000 chunk15500
theorem chunk16000 : Prefix 500 snap15500 snap16000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank16000 : Prefix 16000 snap0 snap16000 := @compose 15500 500 snap0 snap15500 snap16000 fromBlank15500 chunk16000
theorem chunk16500 : Prefix 500 snap16000 snap16500 := checked _ _ _ (by decide) (by decide)
theorem fromBlank16500 : Prefix 16500 snap0 snap16500 := @compose 16000 500 snap0 snap16000 snap16500 fromBlank16000 chunk16500
theorem chunk17000 : Prefix 500 snap16500 snap17000 := checked _ _ _ (by decide) (by decide)
theorem fromBlank17000 : Prefix 17000 snap0 snap17000 := @compose 16500 500 snap0 snap16500 snap17000 fromBlank16500 chunk17000
theorem chunk17265 : Prefix 265 snap17000 snap17265 := checked _ _ _ (by decide) (by decide)
theorem fromBlank17265 : Prefix 17265 snap0 snap17265 := @compose 17000 265 snap0 snap17000 snap17265 fromBlank17000 chunk17265
theorem embed_start : KernelBits.embed width (-10) (fun _ => false) snap0 = TM.blank start := by
  show TM.Configuration.mk _ _ _ = TM.Configuration.mk _ _ _
  congr 1
  funext p
  simp [KernelBits.tape, snap0]

theorem blank_first_ax : TM.run machine 17265 (TM.blank start) = KernelBits.embed width (-10) (fun _ => false) snap17265 := by
  rw [← embed_start]
  exact fromBlank17265 _ _
#print axioms blank_first_ax
end Moving184.Boot
