import Moving184SearchCore

set_option maxHeartbeats 8000000
set_option maxRecDepth 100000
namespace Moving184
open NF192.Numerical NF192.Emitter

open NF192.ProofSearch (Command candidate candidate_prefix candidate_ne_nil)
open NF192.SourceFields
def run : List Command → State → State
  | [], s => s
  | c :: cs, s => run cs (step c s)

def checkedRun : List Command → State → Option State
  | [], s => some s
  | c :: cs, s => if observes c s then none else checkedRun cs (step c s)

theorem run_append (u v : List Command) (s : State) :
    run (u ++ v) s = run v (run u s) := by
  induction u generalizing s with
  | nil => rfl
  | cons c cs ih => exact ih (step c s)

theorem checkedRun_append (u v : List Command) (s : State) :
    checkedRun (u ++ v) s = (checkedRun u s).bind (checkedRun v) := by
  induction u generalizing s with
  | nil => rfl
  | cons c cs ih =>
    by_cases h : observes c s = true <;> simp [checkedRun, h, ih]

theorem checkedRun_survives {cs : List Command} {s t : State}
    (h : checkedRun cs s = some t) : t = run cs s := by
  induction cs generalizing s with
  | nil => exact (Option.some.inj h).symm
  | cons c cs ih =>
    by_cases e : observes c s = true
    · simp [checkedRun, e] at h
    · exact ih (by simpa [checkedRun, e] using h)

private theorem head_sound {xs : List Nat} (h : ∀ x ∈ xs, Deriv x) :
    Deriv (xs.headD 0) := by
  cases xs with
  | nil => exact deriv_zero
  | cons x xs => exact h x (by simp)

private theorem tail_sound {xs : List Nat} (h : ∀ x ∈ xs, Deriv x) :
    ∀ x ∈ xs.tail, Deriv x := by
  intro x hx
  cases xs with
  | nil => exact False.elim (List.not_mem_nil hx)
  | cons a xs => exact h _ (List.mem_cons_of_mem a hx)

theorem nip_sound (s : State) (h : s.Sound) : (nip s).Sound :=
  ⟨h.1,tail_sound h.2.1,head_sound h.2.1⟩
theorem step_sound (c : Command) (s : State) (h : s.Sound) : (step c s).Sound := by
  obtain ⟨ht,hs,hc⟩ := h
  cases c with
  | mode d =>
    apply nip_sound
    refine ⟨?_,hs,deriv_zero⟩
    change Deriv (if s.cache = imp s.top (s.param+d) then s.param+d else 0)
    split
    next eq => exact Deriv.mp (eq ▸ hc) ht
    next => exact deriv_zero
  | mp d =>
    cases hw : s.param+d with
    | zero => exact (by simpa only [step,hw,State.Sound] using
        (show Deriv s.top ∧ (∀ x ∈ s.stack.tail, Deriv x) ∧ Deriv (s.stack.headD 0) from
          ⟨ht,tail_sound hs,head_sound hs⟩))
    | succ j => simpa only [step,hw,State.Sound] using (show Deriv s.cache ∧ (∀ x ∈ s.stack, Deriv x) ∧ Deriv s.top from ⟨hc,hs,ht⟩)
  | ax u b d rest =>
    apply nip_sound
    refine ⟨deriv_zero,?_,deriv_zero⟩
    intro x hx
    rcases List.mem_append.mp hx with h|h
    · exact rows_sound u b d rest s x (List.mem_reverse.mp (List.mem_of_mem_tail h))
    · rcases List.mem_cons.mp h with rfl|h
      · exact ht
      · exact hs x h
theorem detects_only_goal {cs : List Command} {s : State} (hs : s.Sound)
    (h : checkedRun cs s = none) : Deriv goal := by
  induction cs generalizing s with
  | nil => contradiction
  | cons c cs ih =>
    by_cases o : observes c s = true
    · cases c with
      | mode d => simp [observes] at o
      | ax u b d rest => simp [observes] at o
      | mp d =>
        have e : s.cache = goal := by simpa only [observes, beq_iff_eq] using o
        exact e ▸ hs.2.2
    · exact ih (step_sound c s hs) (by simpa [checkedRun, o] using h)




def nips : Nat → List Command
  | 0 => []
  | n+1 => .mp 0 :: nips n

private theorem nips_over (pre tail : List Nat) (t c : Nat) :
    ∃ w, run (nips pre.length) ⟨t, pre ++ tail, c, 0⟩ = ⟨t, tail, w, 0⟩ := by
  induction pre generalizing c with
  | nil => exact ⟨c, rfl⟩
  | cons a pre ih => exact ih a

private theorem nips_to (pre tail : List Nat) (x t c : Nat) :
    run (nips (pre.length+1)) ⟨t, pre ++ x :: tail, c, 0⟩ = ⟨t, tail, x, 0⟩ := by
  induction pre generalizing c with
  | nil => rfl
  | cons a pre ih => exact ih a

private theorem split_at_member {x : Nat} {as : List Nat} (h : x ∈ as) :
    ∃ pre post, as = pre ++ x :: post := by
  induction as with
  | nil => contradiction
  | cons a as ih =>
    rcases List.mem_cons.mp h with rfl | h'
    · exact ⟨[], as, rfl⟩
    · obtain ⟨pre,post,eq⟩ := ih h'
      exact ⟨a :: pre, post, congrArg (List.cons a) eq⟩


theorem extract_rows (zs : List Nat) (x : Nat) (h : x ∈ zs.reverse.tail) :
    ∃ word, ∀ s : State, ∃ c, run word (afterAX s zs) = ⟨x,s.top :: s.stack,c,0⟩ := by
  generalize er : zs.reverse.tail = rs at h
  cases rs with
  | nil => cases h
  | cons first rs =>
    have H (s : State) : afterAX s zs = ⟨0,rs ++ s.top :: s.stack,first,0⟩ := by
      simp [afterAX,nip,er]
    rcases List.mem_cons.mp h with e|h
    · subst x
      refine ⟨.mp 1 :: nips rs.length,fun s => ?_⟩
      rw [H]
      exact nips_over rs _ _ _
    · obtain ⟨pre,post,he⟩ := split_at_member h
      refine ⟨nips (pre.length+1) ++ (.mp 1 :: nips post.length),fun s => ?_⟩
      rw [H,he,List.append_assoc,List.cons_append,run_append,nips_to]
      exact nips_over post _ _ _
def sweep : List Command := .ax 0 0 0 [] :: nips 6
theorem sweep_results (s : State) : ∃ c, run sweep s = ⟨0,s.top::s.stack,c,0⟩ := by
  let front := (rows 0 0 0 [] s).reverse.tail
  have len : front.length = 7 := by simp [front,rows,tailRows,rowList,Moving186.rowList]
  change ∃ c, run (nips 6) (nip ⟨0,front ++ s.top::s.stack,0,0⟩) = _
  cases hf : front with
  | nil => simp [hf] at len
  | cons k rest =>
    have hlen : rest.length = 6 := by simp [hf] at len; omega
    simp only [nip,List.cons_append,List.tail_cons,List.headD_cons]
    rw [←hlen]
    exact nips_over rest _ _ _
def resetWord : List Command := sweep ++ sweep ++ [.mode 0]
theorem reset_results (s : State) :
    run resetWord s = ⟨0,s.top :: s.stack,0,0⟩ := by
  obtain ⟨c,h⟩ := sweep_results s
  obtain ⟨d,k⟩ := sweep_results ⟨0,s.top::s.stack,c,0⟩
  simp only [resetWord,run_append,h,k,run,step,nip,Nat.zero_add,ite_self,List.tail_cons,List.headD_cons]
def Builds (x : Nat) (word : List Command) : Prop :=
  ∀ (t : Nat) (stack : List Nat) (cache : Nat), ∃ c,
    run word ⟨t,stack,cache,0⟩ = ⟨x,t::stack,c,0⟩
private theorem member_retained (l r : List Nat) {x : Nat} (hx : x ∈ l) (hr : r ≠ []) :
    x ∈ (l ++ r).reverse.tail := by
  rw [List.reverse_append]
  cases he : r.reverse with
  | nil =>
    have eq := congrArg List.reverse he
    simp only [List.reverse_reverse,List.reverse_nil] at eq
    exact False.elim (hr eq)
  | cons t ts =>
    simp only [List.cons_append,List.tail_cons]
    exact List.mem_append_right ts (List.mem_reverse.mpr hx)
theorem builds_emitted {a b c u x : Nat} (hu : u ≤ a)
    (hx : x ∈ (rowList a b c u).take 7 ∨ 0 < c ∧ x ∈ rowList a b c u) :
    ∃ word, Builds x word := by
  let rest : List (Nat × Nat) := List.replicate c (0,0)
  let zs := rowList a b c u ++ tailRows a b rest
  have hrow : x ∈ zs.reverse.tail := by
    rcases hx with hf|⟨hc,hf⟩
    · have shape : rowList a b c u = (rowList a b c u).take 7 ++ [lastRow a b] := rfl
      change x ∈ (rowList a b c u ++ _).reverse.tail
      exact (show x ∈ ((rowList a b c u).take 7 ++ ([lastRow a b] ++ tailRows a b rest)).reverse.tail from
        member_retained _ _ hf (by simp))
    · apply member_retained _ _ hf
      cases c with
      | zero => omega
      | succ k => simp [rest,List.replicate_succ,tailRows,rowList,Moving186.rowList]
  obtain ⟨extract,he⟩ := extract_rows zs x hrow
  let ax := Command.ax u b (a-u) rest
  refine ⟨resetWord ++ (ax :: (extract ++ [.mp 0])), ?_⟩
  intro t stack cache
  let saved : State := ⟨0,t::stack,0,0⟩
  have rs : rows u b (a-u) rest saved = zs := by
    simp only [rows,saved,zs,rest,List.length_replicate,Nat.zero_add,show u+(a-u)=a by omega]
  obtain ⟨c',hc'⟩ := he saved
  refine ⟨0,?_⟩
  rw [run_append,reset_results]
  change run (extract ++ [.mp 0]) (afterAX saved (rows u b (a-u) rest saved)) = _
  rw [rs,run_append,hc']
  rfl
theorem builds_mp {a b : Nat} {minor major : List Command}
    (hm : Builds a minor) (hM : Builds (imp a b) major) :
    Builds b (resetWord ++ minor ++ major ++ [.mp 0,.mp 1,.mode b]) := by
  intro t stack cache
  obtain ⟨c1,e1⟩ := hm 0 (t::stack) 0
  obtain ⟨c2,e2⟩ := hM a (0::t::stack) c1
  refine ⟨0,?_⟩
  rw [run_append,run_append,run_append,reset_results,e1,e2]
  simp [run,step,nip]
end Moving184
