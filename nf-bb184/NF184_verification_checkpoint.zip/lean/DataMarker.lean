import CompactNF

set_option autoImplicit false
namespace FFL.FirstOrder.SetTheory.NFFn
open JensenNFU.TFm (scons scons_zero scons_succ)
open DirectTranslation
namespace DataMarker
open NF188Finite
variable {V : Type} [SetStructure V]

def test (yes no f x y : V) : Prop :=
  (AppR f x x ∧ ((x=yes ∧ y=no) ∨ (x≠yes ∧ y=yes))) ∨ (¬ AppR f x x ∧ AppR f x y)
def atRow (yes no f w : V) : Prop :=
  ∀ x y, AppR w x y ↔ test yes no f x y

private def equalN {γ : ℕ → ℕ} (a b : ℕ) (ha : γ a=11) (hb : γ b=11) :
    NDef γ (fun _ _ e => e a = e b) :=
  (NDef.ofS (SDef.eq (τ:=![11,11]) 0 1) ![a,b] 0
    (fun i => by fin_cases i <;> simp [ha,hb])).congr (fun _ _ _ => Iff.rfl)

def testN {γ : ℕ → ℕ} (p n f x y : ℕ)
    (hp : γ p=11) (hn : γ n=11) (hf : γ f=12) (hx : γ x=11) (hy : γ y=11) :
    NDef γ (fun _ _ e => test (e p) (e n) (e f) (e x) (e y)) :=
  let hit := NDef.ofS appD ![f,x,x] 3 (fun i => by fin_cases i <;> simp [hf,hx])
  let ep := equalN x p hx hp
  let ey := equalN y p hy hp
  let en := equalN y n hy hn
  let fx := NDef.ofS appD ![f,x,y] 3 (fun i => by fin_cases i <;> simp [hf,hx,hy])
  ((hit.and ((ep.and en).or (ep.not.and ey))).or (hit.not.and fx)).congr
    (fun _ _ _ => Iff.rfl)

def rowN {γ : ℕ → ℕ} (p n f w : ℕ)
    (hp : γ p=11) (hn : γ n=11) (hf : γ f=12) (hw : γ w=12) :
    NDef γ (fun _ _ e => atRow (e p) (e n) (e f) (e w)) :=
  (NDef.all 11 (NDef.all 11 ((NDef.ofS appD ![w+2,1,0] 3
    (fun i => by fin_cases i <;> simp [hw])).iff
    (testN (p+2) (n+2) (f+2) 1 0 hp hn hf rfl rfl)))).congr (fun _ _ _ => Iff.rfl)

variable [Nonempty V] [hT : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙]
theorem exists_row (yes no f : V) : ∃ w, atRow yes no f w := by
  obtain ⟨F,hF⟩ := (NDef.ex (γ:=scons 11 (scons 12 (fun _ => 11))) 11 (NDef.ex 11
    ((NDef.ofS prD ![2,1,0] 3 (fun i => by fin_cases i <;> rfl)).and
     (testN 4 5 3 1 0 rfl rfl rfl rfl rfl)))).comprehension (scons f (scons yes (fun _ => no)))
  refine app_of_graph (G:=test yes no f) hF ?_ ?_
  · intro x
    by_cases h : AppR f x x
    · by_cases e : x = yes
      · exact ⟨no,Or.inl ⟨h,Or.inl ⟨e,rfl⟩⟩⟩
      · exact ⟨yes,Or.inl ⟨h,Or.inr ⟨e,rfl⟩⟩⟩
    · exact ⟨oldApp f x,Or.inr ⟨h,oldApp_spec _ _⟩⟩
  · intro x y z hy hz
    rcases hy with ⟨h,k⟩ | ⟨h,k⟩ <;> rcases hz with ⟨e,j⟩ | ⟨e,j⟩
    · rcases k with ⟨_,rfl⟩ | ⟨_,rfl⟩ <;> rcases j with ⟨_,rfl⟩ | ⟨_,rfl⟩ <;> tauto
    · exact (e h).elim
    · exact (h e).elim
    · exact app_fun k j

/-- Every model of pure NF contains an applicative fixed-point tester for any
two selected answers in its canonical full function chart. -/
theorem exists_tester (yes no : V) : ∃ u, ∀ f w, AppR u f w ↔ atRow yes no f w := by
  obtain ⟨F,hF⟩ := (NDef.ex (γ:=scons 12 (fun _ => 11)) 12 (NDef.ex 12
    ((NDef.ofS prD ![2,1,0] 4 (fun i => by fin_cases i <;> rfl)).and
      (rowN 3 4 1 0 rfl rfl rfl rfl)))).comprehension (scons yes (fun _ => no))
  refine app_of_graph (G:=atRow yes no) hF (exists_row yes no) ?_
  intro f w w' h h'
  exact app_ext fun x y a => (h' x y).mpr ((h x y).mp a)

end DataMarker
end FFL.FirstOrder.SetTheory.NFFn
#print axioms FFL.FirstOrder.SetTheory.NFFn.DataMarker.exists_tester
