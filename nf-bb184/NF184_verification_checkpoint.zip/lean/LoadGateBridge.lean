module
public import LoadGateListing
@[expose] public section
namespace Load187Literal
open NF192.Source
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false
def step : Config → Config
  | some (pc,rs) => execute (program pc) rs
  | none => none

def advance : Nat → Config → Config
  | 0, s => s
  | n+1, s => advance n (step s)

theorem advance_add (i j : Nat) (s : Config) :
    advance (i+j) s = advance j (advance i s) := by
  induction i generalizing s with
  | zero => simp [advance]
  | succ i ih => simp only [Nat.succ_add, advance, ih]
theorem gate_row_2914 : program 2914 = Command.dec 5 2918 2915 false := by decide
theorem gate_row_2915 : program 2915 = Command.dec 5 2918 2916 false := by decide
theorem gate_row_2916 : program 2916 = Command.dec 5 2918 2917 false := by decide
theorem gate_row_2917 : program 2917 = Command.dec 5 0 2918 true := by decide
theorem gate_row_2918 : program 2918 = Command.dec 5 2920 2919 false := by decide
theorem gate_row_2919 : program 2919 = Command.jump 2918 := by decide

private theorem dec_pos {pc target zero : Nat} {hlt : Bool}
    (instruction : program pc = Command.dec 5 zero target hlt) (n : Nat) (rs : Registers) :
    step (goalConfig pc (n+1) rs) = goalConfig target n rs := by
  simp [step, goalConfig, execute, instruction]

private theorem dec_zero {pc target pos : Nat}
    (instruction : program pc = Command.dec 5 target pos false) (rs : Registers) :
    step (goalConfig pc 0 rs) = goalConfig target 0 rs := by
  simp [step, goalConfig, execute, instruction]

private theorem dec_stop {pc zero pos : Nat}
    (instruction : program pc = Command.dec 5 zero pos true) (rs : Registers) :
    step (goalConfig pc 0 rs) = Config.halted := by
  simp [step, goalConfig, execute, instruction]

private theorem jump_step {pc target : Nat} (instruction : program pc = Command.jump target)
    (n : Nat) (rs : Registers) :
    step (goalConfig pc n rs) = goalConfig target n rs := by
  simp [step, goalConfig, execute, instruction]

/-- Every iteration of the clear loop consumes one unit in exactly two steps. -/
theorem clear_all (n : Nat) (rs : Registers) :
    advance (2*n+1) (goalConfig 2918 n rs) = goalConfig 2920 0 rs := by
  induction n with
  | zero =>
    exact dec_zero gate_row_2918 rs
  | succ k ih =>
    have ticks : 2*(k+1)+1 = 2 + (2*k+1) := by omega
    rw [ticks, advance_add]
    have iteration : advance 2 (goalConfig 2918 (k+1) rs) = goalConfig 2918 k rs := by
      change step (step (goalConfig 2918 (k+1) rs)) = goalConfig 2918 k rs
      rw [dec_pos gate_row_2918, jump_step gate_row_2919]
    rw [iteration]
    exact ih

theorem countdown_correct (n : Nat) (rs : Registers) :
    advance (countdownDuration n) (goalConfig 2914 n rs) =
    (if n = 3 then Config.halted else goalConfig 2920 0 rs) := by
  cases n with
  | zero =>
    change step (step (goalConfig 2914 0 rs)) = goalConfig 2920 0 rs
    rw [dec_zero gate_row_2914, dec_zero gate_row_2918]
  | succ n =>
    cases n with
    | zero =>
      change step (step (step (goalConfig 2914 1 rs))) = goalConfig 2920 0 rs
      rw [dec_pos gate_row_2914, dec_zero gate_row_2915, dec_zero gate_row_2918]
    | succ n =>
      cases n with
      | zero =>
        change step (step (step (step (goalConfig 2914 2 rs)))) = goalConfig 2920 0 rs
        rw [dec_pos gate_row_2914, dec_pos gate_row_2915,
          dec_zero gate_row_2916, dec_zero gate_row_2918]
      | succ n =>
        cases n with
        | zero =>
          change step (step (step (step (goalConfig 2914 3 rs)))) = Config.halted
          rw [dec_pos gate_row_2914, dec_pos gate_row_2915,
            dec_pos gate_row_2916, dec_stop gate_row_2917]
        | succ k =>
          have neq : k.succ.succ.succ.succ ≠ 3 := by omega
          rw [ite_eq_right neq]
          change advance (4+(2*k+1)) (goalConfig 2914 (k+4) rs) = goalConfig 2920 0 rs
          rw [advance_add 4 (2*k+1)]
          have first : advance 4 (goalConfig 2914 (k+4) rs) = goalConfig 2918 k rs := by
            change step (step (step (step (goalConfig 2914 (k+4) rs)))) = goalConfig 2918 k rs
            rw [dec_pos gate_row_2914, dec_pos gate_row_2915,
              dec_pos gate_row_2916, dec_pos gate_row_2917]
          rw [first, clear_all]


def frame (pc t c : Nat) (rs : Registers) := goalConfig pc c (setReg rs 1 t)
private theorem set_top (rs : Registers) (t c v : Nat) :
    setReg (setReg (setReg rs 1 t) 5 c) 1 v = setReg (setReg rs 1 v) 5 c := by
  funext i
  by_cases a : i = 1 <;> by_cases b : i = 5 <;> simp_all [setReg]
private theorem top (rs : Registers) (t c : Nat) : setReg (setReg rs 1 t) 5 c 1 = t := by simp [setReg]
private theorem row2912 : program 2912 = .dec 1 2920 2913 false := by decide
private theorem row2913 : program 2913 = .inc 1 2914 := by decide
private theorem row2920 : program 2920 = .dec 5 2923 2921 false := by decide
private theorem row2921 : program 2921 = .inc 1 2922 := by decide
private theorem row2922 : program 2922 = .jump 2920 := by decide
private theorem load_all (c t : Nat) (rs : Registers) :
    advance (3*c+1) (frame 2920 t c rs) = frame 2923 (t+c) 0 rs := by
  induction c generalizing t with
  | zero => simpa [frame,advance] using dec_zero row2920 (setReg rs 1 t)
  | succ c ih =>
    rw [show 3*(c+1)+1=3+(3*c+1) by omega,advance_add]
    have loop : advance 3 (frame 2920 t (c+1) rs) = frame 2920 (t+1) c rs := by
      simp only [advance]
      simp only [frame,goalConfig,step,row2920,row2921,row2922,execute,setReg_self,top,setReg_overwrite,set_top]
    rw [loop,ih]; congr 1; omega

/-- The exact eleven-PC gate, for arbitrary natural top and cache and all values of every other register. -/
theorem gate_correct (t c : Nat) (rs : Registers) :
    ∃ n, 0<n ∧ advance n (frame 2912 t c rs) =
      (if t ≠ 0 ∧ c = 3 then Config.halted else frame 2923 (if t = 0 then c else t) 0 rs) := by
  cases t with
  | zero =>
    refine ⟨1+(3*c+1),by omega,?_⟩
    rw [advance_add]
    have enter : advance 1 (frame 2912 0 c rs) = frame 2920 0 c rs := by
      simp only [advance]
      simp [frame,goalConfig,step,row2912,execute,top]
    rw [enter,load_all]
    simp
  | succ t =>
    have enter : advance 2 (frame 2912 (t+1) c rs) = frame 2914 (t+1) c rs := by
      simp only [advance]
      simp only [frame,goalConfig,step,row2912,row2913,execute,top,set_top]
    have hit := countdown_correct c (setReg rs 1 (t+1))
    by_cases hc : c = 3
    · refine ⟨2+countdownDuration c,by omega,?_⟩
      rw [advance_add,enter]; simpa [frame,hc] using hit
    · refine ⟨2+(countdownDuration c+1),by omega,?_⟩
      rw [advance_add,enter,advance_add]
      change advance 1 (advance _ (goalConfig _ _ _)) = _
      rw [hit,if_neg hc]
      simpa [frame,hc,advance] using dec_zero row2920 (setReg rs 1 (t+1))
end Load187Literal
#print axioms Load187Literal.gate_correct
