import WeakCalibration
open NF188.Relabel
open NF188.Relabel.Syntax
namespace VariableMarker
universe u
variable {V : Type u} (A : Basis V) (J : V)
local infixl:70 " ⬝ " => A.app
local infixl:75 " ◆ " => Term.app
theorem ident (e : Nat → V) (v : V) : val A J e idT ⬝ v = v := by
  simp only [idT,con,val,kpow,valAtom,A.b_app,A.k_app]
theorem beta (s : Term) : ∀ j, good j s = true → ∀ (e : Nat→V) (x : V),
    val A J e (abs j s) ⬝ kpow A j x = val A J (cons x e) s := by
  induction s with
  | leaf m a =>
    intro j h e x
    cases a with
    | var i =>
      cases i with
      | zero =>
        have eq : m=j := beq_iff_eq.mp h
        subst j; exact ident A J e _
      | succ i => exact A.k_app _ _
    | b => exact A.k_app _ _
    | p => exact A.k_app _ _
  | app s t hs ht =>
    intro j h e x
    obtain ⟨g,k⟩ : good (j+1) s=true ∧ good j t=true := by simpa only [good,Bool.and_eq_true] using h
    change A.B ⬝ val A J e (abs (j+1) s) ⬝ val A J e (abs j t) ⬝ kpow A j x = _
    rw [A.b_app,ht j k e x]
    exact congrArg (fun f=>A.app f (val A J (cons x e) t)) (hs (j+1) g e x)
def lift : Term → Term
  | .leaf n a => .leaf (n+1) a
  | .app a b => con .b ◆ lift a ◆ lift b
theorem val_lift (s : Term) (e : Nat → V) : val A J e (lift s)=A.K (val A J e s) := by
  induction s with
  | leaf _ _ => rfl
  | app a b ha hb =>
    apply A.ext; intro z
    simp only [lift,con,val,kpow,valAtom,A.b_app,A.k_app] at *
    rw [ha,hb,A.k_app,A.k_app]
def vr (i : Nat) : Term := con (.var i)
def pBody := lift (lift (vr 0 ◆ lift (vr 2) ◆ vr 1))
def pairingCode := abs 4 (abs 3 (abs 0 pBody))
def pairing := val A J (fun _ => J) pairingCode
def pair (x y : V) := pairing A J ⬝ kpow A 4 x ⬝ kpow A 3 y
theorem pair_apply (x y f : V) :
    pair A J x y ⬝ f = kpow A 2 ((f ⬝ A.K x) ⬝ y) := by
  unfold pair pairing pairingCode
  rw [beta A J _ 4 (by decide),beta A J _ 3 (by decide)]
  change val A J _ (abs 0 pBody) ⬝ kpow A 0 f = _
  rw [beta A J _ 0 (by decide)]
  simp [pBody,val_lift,vr,con,val,valAtom,kpow,cons]
theorem k_inj {x y : V} (eq : A.K x = A.K y) : x=y := by
  have h := congrArg (fun t=>A.app t A.B) eq
  simpa only [A.k_app] using h
theorem pair_inj {x y u v : V} (h : pair A J x y=pair A J u v) : x=u ∧ y=v := by
  let i := val A J (fun _=>J) idT
  have hi (x : V) : i ⬝ x=x := ident A J _ x
  have p := congrArg (fun t => t ⬝ i) h
  have q := congrArg (fun t => t ⬝ A.K i) h
  change pair A J x y ⬝ i = pair A J u v ⬝ i at p
  change pair A J x y ⬝ A.K i = pair A J u v ⬝ A.K i at q
  simp only [pair_apply,hi,A.k_app,kpow] at p q
  exact ⟨k_inj A (k_inj A p), k_inj A (k_inj A q)⟩
end VariableMarker
#print axioms VariableMarker.pair_inj
