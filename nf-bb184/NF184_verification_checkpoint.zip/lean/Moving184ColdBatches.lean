import Moving184SearchCore
import Moving184ColdCore
import NumericalAXBatches

set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Moving184.Register
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers
open NF192.ProofSearch (pack)
def coldFrame (pc c : Nat) (ts : Nat×Nat) : Config :=
  ⟨pc, (frameWith 0 ts c 0 0 0).regs⟩

def coldPayload (c : Nat) (ts : Nat×Nat) : Nat×Nat :=
  pushRows ts (Moving184.rowList 0 0 c 0)

theorem frozenJump (pc next : Nat) (rs : Registers) (h : frozen pc = .jump next) :
    Reaches frozen ⟨pc,rs⟩ (some ⟨next,rs⟩) :=
  Reaches.one (by simp only [NF192.Emitter.step, h])

theorem frozen_batch (c : Nat) (ts : Nat×Nat) :
    Reaches frozen (coldFrame 40 c ts) (some (coldFrame 39 c (coldPayload c ts))) := by
  have h := (Moving184.batch_eval 0 ts.1 ts.2 c 0 0 0 0 0).compiled frozen 40 2849 [] [] frozen_ax
  change Reaches frozen (coldFrame 40 c ts)
    (some ⟨2849, (save (frameWith 0 ts c 0 0 0) (Moving184.rowList 0 0 c 0)).regs⟩) at h
  rw [save_frameWith] at h
  exact h.trans (frozenJump 2849 39 _ (by decide))

private theorem guard_for_program (program : Nat → Instruction)
    (instruction : program 39 = .dec 3 2850 40) (c : Nat) (ts : Nat×Nat) :
    Reaches program (coldFrame 39 (c+1) ts) (some (coldFrame 40 c ts)) := by
  apply Reaches.one
  simp only [NF192.Emitter.step, coldFrame, frameWith, Frame.regs, instruction, mk9_get_3,
    Nat.add_one_ne_zero, ite_false, Nat.add_sub_cancel, mk9_set_3]

private theorem zero_guard_for_program (program : Nat → Instruction)
    (instruction : program 39 = .dec 3 2850 40) (ts : Nat×Nat) :
    Reaches program (coldFrame 39 0 ts) (some (coldFrame 2850 0 ts)) := by
  apply Reaches.one
  simp only [NF192.Emitter.step,coldFrame,frameWith,Frame.regs,instruction,mk9_get_3,ite_true]

private theorem guard_instruction : frozen 39 = .dec 3 2850 40 := by decide

theorem frozen_guard (c : Nat) (ts : Nat×Nat) :
    Reaches frozen (coldFrame 39 (c+1) ts) (some (coldFrame 40 c ts)) :=
  guard_for_program frozen guard_instruction c ts

theorem frozen_guard_zero (ts : Nat×Nat) :
    Reaches frozen (coldFrame 39 0 ts) (some (coldFrame 2850 0 ts)) :=
  zero_guard_for_program frozen guard_instruction ts

def startupPayload : Nat×Nat := coldPayload 0 (coldPayload 1 (coldPayload 2 (0,0)))

theorem frozen_three_batches :
    Reaches frozen (coldFrame 40 2 (0,0)) (some (coldFrame 2850 0 startupPayload)) := by
  apply (frozen_batch 2 (0,0)).trans
  apply (frozen_guard 1 _).trans
  apply (frozen_batch 1 _).trans
  apply (frozen_guard 0 _).trans
  apply (frozen_batch 0 _).trans
  exact frozen_guard_zero _

end Moving184.Register
