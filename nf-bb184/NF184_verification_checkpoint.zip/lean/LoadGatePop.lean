module
public import LoadGateBridge
public import Eight187Outer
public import C200Rows
@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Load187Literal.Register
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers
def actual (pc : Nat) : Instruction := readCommand (Load187Literal.program pc)
theorem actual_step {s t : Config} (hs : NF192.Emitter.step actual s = some t) :
    Load187Literal.step (liftConfig s) = liftConfig t := by
  obtain ⟨pc, rs⟩ := s
  cases hc : Load187Literal.program pc with
  | inl inc =>
      obtain ⟨r, next⟩ := inc
      by_cases hr : r < 9
      · simp only [NF192.Emitter.step, actual, hc, readCommand, dif_pos hr, Option.some.injEq] at hs
        subst t
        change Source.execute (Load187Literal.program pc) (liftRegisters rs) = _
        rw [hc]
        simp only [Source.execute, liftConfig, Registers.add]
        rw [show liftRegisters rs r = rs ⟨r,hr⟩ from liftRegisters_at rs ⟨r,hr⟩]
        rw [show Source.setReg (liftRegisters rs) r (rs ⟨r,hr⟩+1) =
          liftRegisters (rs.set ⟨r,hr⟩ (rs ⟨r,hr⟩+1)) from liftRegisters_set rs ⟨r,hr⟩ _]
      · simp [NF192.Emitter.step, actual, hc, readCommand, hr] at hs
  | inr cmd =>
      cases cmd with
      | inr next =>
          simp only [NF192.Emitter.step, actual, hc, readCommand, Option.some.injEq] at hs
          subst t
          change Source.execute (Load187Literal.program pc) (liftRegisters rs) = _
          rw [hc]
          rfl
      | inl dec =>
          obtain ⟨r, z, p, flag⟩ := dec
          by_cases hr : r < 9
          · have get : liftRegisters rs r = rs ⟨r,hr⟩ := liftRegisters_at rs ⟨r,hr⟩
            cases hv : rs ⟨r,hr⟩ with
            | zero =>
                cases flag <;> simp [NF192.Emitter.step, actual, hc, readCommand, hr, hv] at hs
                subst t
                change Source.execute (Load187Literal.program pc) (liftRegisters rs) = _
                rw [hc]
                simp [Source.execute, get, hv, liftConfig]
            | succ n =>
                have put := liftRegisters_set rs ⟨r,hr⟩ n
                cases flag <;> simp [NF192.Emitter.step, actual, hc, readCommand, hr, hv] at hs <;> subst t
                all_goals
                  change Source.execute (Load187Literal.program pc) (liftRegisters rs) = _
                  rw [hc]
                  simp [Source.execute, liftConfig, get, hv, put]
          · simp [NF192.Emitter.step, actual, hc, readCommand, hr] at hs

theorem actual_run (n : Nat) {s t : Config} (h : NF192.Emitter.run actual n s = some t) :
    Load187Literal.advance n (liftConfig s) = liftConfig t := by
  induction n generalizing s with
  | zero =>
      have e : s = t := Option.some.inj h
      subst t
      rfl
  | succ n ih =>
      cases hs : NF192.Emitter.step actual s with
      | none => simp [NF192.Emitter.run, hs] at h
      | some u =>
          have rest : NF192.Emitter.run actual n u = some t := by simpa only [NF192.Emitter.run, hs, Option.bind_some] using h
          exact (congrArg (Load187Literal.advance n) (actual_step hs)).trans (ih rest)

def matchesCode (pc : Nat) : List Instruction → Bool
  | [] => true
  | i :: is => decide (actual pc = i) && matchesCode (pc+1) is

theorem matchesCode_spec (pc : Nat) (xs : List Instruction) (yes : matchesCode pc xs = true)
    (i : Nat) (hi : i < xs.length) : actual (pc+i) = xs[i] := by
  induction xs generalizing pc i with
  | nil => simp at hi
  | cons x xs ih =>
      change (decide (actual pc = x) && matchesCode (pc+1) xs) = true at yes
      have hh : decide (actual pc = x) = true ∧ matchesCode (pc+1) xs = true := by simpa only [Bool.and_eq_true_iff] using yes
      cases i with
      | zero => simpa using (of_decide_eq_true hh.1 : actual pc = x)
      | succ j =>
          have hj : j < xs.length := by simpa using hi
          have he := ih (pc+1) hh.2 j hj
          simpa only [List.getElem_cons_succ, Nat.add_assoc, Nat.add_comm 1 j, Nat.succ_eq_add_one] using he

theorem embedded_of_matches (code : Code) (pc last : Nat)
    (check : matchesCode pc (compile code pc last [] []) = true) :
    Embedded actual code pc last [] [] := by
  intro i hi
  exact matchesCode_spec pc _ check i (by simpa only [compile_length] using hi)
def Moves (s t : Source.Config) : Prop := ∃ n, 0 < n ∧ Load187Literal.advance n s = t

theorem Moves.trans {s t u : Source.Config} (a : Moves s t) (b : Moves t u) : Moves s u := by
  obtain ⟨n, pn, hn⟩ := a
  obtain ⟨m, pm, hm⟩ := b
  exact ⟨n+m,by omega, by rw [Load187Literal.advance_add,hn,hm]⟩
def embeddedCheck (code : Code) (base finish : Nat) : Bool :=
  matchesCode base (compile code base finish [] [])

theorem block_run {code : Code} {s t : Registers} {base finish : Nat}
    (hc : embeddedCheck code base finish = true) (he : Eval code s .normal t) :
    Reaches actual ⟨base,s⟩ (some ⟨finish,t⟩) :=
  he.compiled _ _ _ _ _ (embedded_of_matches code base finish hc)

/-- The source actually runs between these two configurations in positive time. -/
abbrev Visits := Moves

theorem toVisits {s t : Config} (h : Reaches actual s (some t)) :
    Visits (liftConfig s) (liftConfig t) := by
  obtain ⟨n,hn,hr⟩ := h
  exact ⟨n,hn,actual_run n hr⟩

/-- Raw source frame, including the counter, arbitrary residual input and all
nine physical register values lifted to the source-step representation. -/
def frame (pc n t sp c d h a b input : Nat) : Source.Config :=
  Source.Config.active pc (liftRegisters (mk9 n t sp c d h a b input))

private theorem unpair2_checked : embeddedCheck NF192.Emitter.Literal.seq160 2923 2934 = true := by decide
private theorem pop5_checked : embeddedCheck NF192.Emitter.Literal.seq207 2934 0 = true := by decide

private theorem pop_run (n t sp c d input : Nat) :
    Reaches actual ⟨2923,mk9 n t sp c d 0 0 0 input⟩
      (some ⟨0,mk9 n t (Cantor.unpair sp).2 c d (Cantor.unpair sp).1 0 0 input⟩) := by
  have first := block_run unpair2_checked (seq160_normal n t sp c d 0 input)
  have second := block_run pop5_checked
    (seq207_eval n t (Cantor.unpair sp).2 c d 0 (Cantor.unpair sp).1 0 input)
  simp only [Nat.zero_add] at second
  exact first.trans second

private theorem raw_frame (pc n t sp c d h input : Nat) :
    Load187Literal.frame pc t h (liftRegisters (mk9 n t sp c d h 0 0 input)) =
      frame pc n t sp c d h 0 0 input := by
  unfold Load187Literal.frame Source.goalConfig frame
  rw [show Source.setReg (liftRegisters (mk9 n t sp c d h 0 0 input)) 1 t =
      liftRegisters ((mk9 n t sp c d h 0 0 input).set 1 t) from liftRegisters_set (mk9 n t sp c d h 0 0 input) 1 t,mk9_set_1]
  rw [show Source.setReg (liftRegisters (mk9 n t sp c d h 0 0 input)) 5 h =
      liftRegisters ((mk9 n t sp c d h 0 0 input).set 5 h) from liftRegisters_set (mk9 n t sp c d h 0 0 input) 5 h,mk9_set_5]

private theorem frame_reset (pc n t t' sp c d h input : Nat) :
    Load187Literal.frame pc t' 0 (liftRegisters (mk9 n t sp c d h 0 0 input)) =
      frame pc n t' sp c d 0 0 0 input := by
  unfold Load187Literal.frame Source.goalConfig frame
  rw [show Source.setReg (liftRegisters (mk9 n t sp c d h 0 0 input)) 1 t' =
      liftRegisters ((mk9 n t sp c d h 0 0 input).set 1 t') from liftRegisters_set (mk9 n t sp c d h 0 0 input) 1 t',mk9_set_1]
  rw [show Source.setReg (liftRegisters (mk9 n t' sp c d h 0 0 input)) 5 0 =
      liftRegisters ((mk9 n t' sp c d h 0 0 input).set 5 0) from liftRegisters_set (mk9 n t' sp c d h 0 0 input) 5 0,mk9_set_5]

/-- The complete revised tag-zero command, including the real Cantor stack pop and the return to PC zero. -/
theorem mode_correct (n t sp c d h input : Nat) :
    Visits (frame 2912 n t sp c d h 0 0 input)
      (if t ≠ 0 ∧ h = goal then Source.Config.halted
       else frame 0 n (if t = 0 then h else t) (Cantor.unpair sp).2 c d (Cantor.unpair sp).1 0 0 input) := by
  obtain ⟨k,hk,res⟩ := Load187Literal.gate_correct t h (liftRegisters (mk9 n t sp c d h 0 0 input))
  rw [raw_frame,frame_reset] at res
  rw [←goal_is_three] at res
  by_cases hit : t ≠ 0 ∧ h = goal
  · rw [ite_eq_left hit]
    exact ⟨k,hk,by simpa only [ite_eq_left hit] using res⟩
  · rw [ite_eq_right hit]
    have preVisit : Visits (frame 2912 n t sp c d h 0 0 input) (frame 2923 n (if t = 0 then h else t) sp c d 0 0 0 input) :=
      ⟨k,hk,by simpa only [ite_eq_right hit] using res⟩
    exact preVisit.trans (toVisits (pop_run n _ sp c d input))
end Load187Literal.Register
#print axioms Load187Literal.Register.mode_correct
