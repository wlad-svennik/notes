import ObservedSevenLogic
import ObservationRows
import CompactModel
namespace ObservedSeven
open NF192 NF192.Numerical NF192.Emitter

private theorem instance_row {r} (hr : RowsHold r) (a b c : Nat) {x : Nat}
    (hx : x ∈ rowList a b c 0) : evaluate r x := hr a b c 0 (Nat.zero_le _) x hx

theorem hold_iff_rows (r : Nat → Nat → Prop) : RowsHold r ↔ NF196.Compact.Rows AsSignature r := by
  constructor
  · intro hr
    have funC (a b c) := instance_row hr a b c (x:=row3 a b c) (by simp [rowList])
    have con (a b) := instance_row hr a b 0 (x:=row4 a b) (by simp [rowList])
    have abs (a b c) := instance_row hr a b c (x:=bRow a b c) (by simp [rowList])
    have ob (x y f) := instance_row hr f y x (x:=observe x y f) (by simp [rowList])
    have tst (a b) := instance_row hr b a 0 (x:=testRow a b) (by simp [rowList])
    have ext (a b) := instance_row hr a b 0 (x:=row9 a b) (by simp [rowList])
    simp only [row3,row4,bRow,observe,single,testRow,row9,evaluate_imp,evaluate_eqn] at *
    have symm {a b : Nat} (hab : r a b) : r b a := tst a b (ob a b _ hab)
    apply (ObservationRows.equivalent AsSignature r).mp
    exact ⟨funC,con,abs,fun x y f h p => symm (ob x y f h (symm p)),
      fun x y h => tst x y (fun p => symm (h (symm p))),ext⟩
  · intro T a b c u _ x hx
    simp only [rowList, List.mem_cons,List.not_mem_nil,or_false] at hx
    rcases hx with h|h|h|h|h|h|h <;> subst x
    · simp only [row0,evaluate_imp]
      intro p q _
      by_cases e : evaluate r c
      · exact e
      · exact q (p (fun z => (e z).elim))
    all_goals simp only [row3,row4,bRow,observe,single,testRow,row9,evaluate_imp,evaluate_eqn]
    · exact fun p => T.rel_symm (T.test _ _ p)
    · exact T.bLaw _ _ _
    · exact fun p q => T.rel_trans (T.argCongr a b c p) q
    · exact T.funCongr _ _ _
    · exact T.kLaw _ _
    · exact T.ext _ _

theorem same_models (r : Nat → Nat → Prop) : RowsHold r ↔ C196Compact.RowsHold r :=
  (hold_iff_rows r).trans (C196Compact.hold_iff_rows r).symm
open FFL FFL.FirstOrder
theorem goal_iff_nf_refutation : Deriv goal ↔ (𝗡𝗙 ⊢ ⊥) := by
  classical
  apply Iff.trans _ C196Compact.deriv_goal_iff_nf_refutation
  apply Classical.byContradiction
  intro hn
  have iffne : (¬ Deriv goal) ↔ (¬ C196Compact.Deriv goal) := by
    rw [not_deriv_iff_ground_model,C196Compact.not_deriv_iff_ground_model]
    exact exists_congr (fun r => and_congr_left' (same_models r))
  exact hn (not_iff_not.mp iffne)
end ObservedSeven
#print axioms ObservedSeven.goal_iff_nf_refutation
