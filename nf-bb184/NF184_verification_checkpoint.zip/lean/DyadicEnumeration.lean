module
public import SourceEnumeration
public import Mathlib.Tactic.Ring
public import Mathlib.Tactic.Positivity
@[expose] public section
namespace DyadicEnumeration
open NF192.Numerical NF192.SourceFields NF192.ProofSearch

/-- Moving the free tail by a power of two times an odd number has an exact
power-of-two effect on its encoding. Each Cantor pairing consumes one bit. -/
def Lift (f : Nat → Nat) : Prop := ∃ depth : Nat, ∀ k x a : Nat, ∃ b : Nat,
  f (x + 2^(k+depth) * (2*a+1)) = f x + 2^k * (2*b+1)

private theorem lift_id : Lift (fun x => x) := by
  refine ⟨0, fun k x a => ⟨a, ?_⟩⟩
  simp
private theorem lift_succ {f : Nat → Nat} (h : Lift f) : Lift (fun x => f x+1) := by
  obtain ⟨depth,H⟩ := h
  refine ⟨depth, fun k x a => ?_⟩
  obtain ⟨b,hb⟩ := H k x a
  exact ⟨b, by dsimp; rw [hb]; omega⟩

private theorem pair_shift (a x h : Nat) :
    pair a (x + 2*h) = pair a x + h*(2*(a+x+h+1)+1) := by
  have e : (a+(x+2*h))*(a+(x+2*h)+1) =
      (a+x)*(a+x+1) + 2*(h*(2*(a+x+h)+1)) := by ring
  unfold pair
  rw [e, Nat.add_mul_div_left _ _ (by decide : 0 < 2)]
  ring
private theorem lift_pair (v : Nat) {f : Nat → Nat} (h : Lift f) : Lift (fun x => pair v (f x)) := by
  obtain ⟨depth,H⟩ := h
  refine ⟨depth+1, fun k x a => ?_⟩
  obtain ⟨b,hb⟩ := H (k+1) x a
  have e : k+(depth+1) = k+1+depth := by omega
  let z := 2^k*(2*b+1)
  have h' : f (x + 2^(k+(depth+1))*(2*a+1)) = f x + 2*z := by
    rw [e,hb,pow_succ]; dsimp [z]; ring
  let d := v+f x+z+1
  refine ⟨2*b*d+b+d,?_⟩
  dsimp only
  rw [h',pair_shift]; dsimp [d,z]; ring

private theorem lift_batch (b : Nat × Nat) {f : Nat → Nat} (h : Lift f) :
    Lift (fun x => encodeBatch b (f x)) := lift_pair _ (lift_pair _ h)
private theorem lift_batches (bs : List (Nat × Nat)) {f : Nat → Nat} (h : Lift f) :
    Lift (fun x => encodeBatches bs (f x)) := by
  induction bs with
  | nil => exact h
  | cons a rest ih => exact lift_batch _ ih
private theorem lift_assemble (c : Command) {f : Nat → Nat} (h : Lift f) :
    Lift (fun x => assemble c (f x)) := by
  cases c with
  | mp d => exact lift_pair _ (lift_pair _ h)
  | mode d => exact lift_pair _ (lift_pair _ h)
  | ax u b d rs => exact lift_pair _ (lift_pair _ (lift_batch _ (lift_batches _ h)))

theorem encoding_lifts (cs : List Command) : Lift (encode cs) := by
  induction cs with
  | nil => exact lift_id
  | cons c cs ih => exact lift_assemble c (lift_succ ih)

private theorem two_slots (x m : Nat) (hm : 0 < m) :
    x % (2*m) = x % m ∨ x % (2*m) = x % m + m := by
  have ht := Nat.mod_lt x (show 0 < 2*m by omega)
  have hh := Nat.mod_mul_left_mod x 2 m
  by_cases h : x % (2*m) < m
  · exact Or.inl ((Nat.mod_eq_of_lt h).symm.trans hh)
  · have hz := Nat.mod_eq_sub_mod (a:=x%(2*m)) (b:=m) (by omega)
    rw [Nat.mod_eq_of_lt (show x % (2*m) - m < m by omega)] at hz
    right; omega

private theorem toggle (x m : Nat) (hm : 0<m) :
    (x+m)%(2*m) = if x%(2*m)<m then x%(2*m)+m else x%(2*m)-m := by
  rw [Nat.add_mod, Nat.mod_eq_of_lt (show m < 2*m by omega)]
  split
  next h => exact Nat.mod_eq_of_lt (by omega)
  next h =>
    have ht := Nat.mod_lt x (show 0 < 2*m by omega)
    rw [Nat.mod_eq_sub_mod (a:=x%(2*m)+m) (b:=2*m) (by omega)]
    rw [Nat.mod_eq_of_lt (by omega)]
    omega

private theorem lift_residue {f : Nat → Nat} (H : Lift f) (k r bound : Nat) :
    ∃ x, bound ≤ x ∧ f x % (2^k) = r % (2^k) := by
  obtain ⟨depth,h⟩ := H
  induction k with
  | zero => exact ⟨bound, le_rfl, by simp only [pow_zero, Nat.mod_one]⟩
  | succ k ih =>
    obtain ⟨x,lb,hx⟩ := ih
    let m : Nat := 2^k
    have hm : 0 < m := by dsimp [m]; positivity
    change f x % m = r % m at hx
    change ∃ y, bound ≤ y ∧ f y % (m*2) = r % (m*2)
    rw [Nat.mul_comm m 2]
    by_cases he : f x % (2*m) = r % (2*m)
    · exact ⟨x,lb,he⟩
    · obtain ⟨b,hb⟩ := h k x 0
      refine ⟨x + 2^(k+depth)*(2*0+1), by omega, ?_⟩
      rw [hb]; change (f x + m*(2*b+1))%(2*m) = _
      rw [show f x + m*(2*b+1) = (f x+m)+b*(2*m) by ring, Nat.add_mul_mod_self_right]
      have l := two_slots (f x) m hm
      have rr := two_slots r m hm
      have sm := Nat.mod_lt r hm
      rw [toggle _ _ hm]; split <;> omega

/-- Every prescribed finite proof-command prefix occurs arbitrarily far out
in every arithmetic progression whose step is a power of two. -/
theorem cofinal_dyadic (cs : List Command) (k residue bound : Nat) :
    ∃ input tail, bound < input ∧ input % (2^k) = residue % (2^k) ∧ Matches cs input tail := by
  obtain ⟨t,bt,ht⟩ := lift_residue (encoding_lifts cs) k residue (bound+1)
  exact ⟨encode cs t,t, Nat.lt_of_lt_of_le (by omega : bound < t) (tail_le_encoding cs t),ht,matches_encoding cs t⟩
end DyadicEnumeration
#print axioms DyadicEnumeration.cofinal_dyadic
