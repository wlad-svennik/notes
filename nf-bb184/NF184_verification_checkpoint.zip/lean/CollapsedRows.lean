module
public import Eight187SearchCore
public import NumericalModel
@[expose] public section
namespace CollapsedRows
open NF192.Ground NF192.Numerical NF192.Emitter
inductive E where | z | s | o deriving DecidableEq
def application : E → E → E
 | .z, .z => .s | .z, .s => .z | .z, .o => .o
 | .s, .z => .s | .s, .s => .s | .s, .o => .o
 | .o, .z => .z | .o, .s => .o | .o, .o => .z
def witness' : E → E → E
 | .z,.z => .o | .z,.s => .s | .s,.z => .s | .s,.s => .s | _,_ => .z
def rel : E → E → Prop
 | .z,.s | .s,.z => False | _,_ => True
def val : Term → E | .q => .z | .app a b => application (val a) (val b) | .h a b => witness' (val a) (val b)
noncomputable def value (x : Nat) := val (decodeTerm x)
noncomputable def valid (x : Nat) := evaluate (fun a b => rel (value a) (value b)) x

def logic (u a b : Nat) := imp (imp (imp u u) a) (imp (imp a a) (imp b a))
def rows (a b u : Nat) :=
 [logic u a b,row4 a b,Eight187.Seed.bRow a b a,row2 a b a,row3 a b a,
  row6 a b a,Eight187.Seed.test b a,row9 a b]
inductive Deriv : Nat → Prop where
 | row {a b u x} : x ∈ rows a b u → Deriv x
 | mp {a b} : Deriv (imp a b) → Deriv a → Deriv b

theorem row_valid {a b u x : Nat} (h : x ∈ rows a b u) : valid x := by
  simp only [rows, List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h|h|h|h|h <;> subst x
  · simp only [valid, logic,evaluate_imp]
    intro ha _ _; exact ha id
  all_goals simp only [valid,row4,Eight187.Seed.bRow,row2,row3,row6,row9,Eight187.Seed.test,Eight187.Seed.single,
    evaluate_imp,evaluate_eqn,s,value,decodeTerm_app,decodeTerm_q,decodeTerm_witness,val,konst]
  all_goals cases val (decodeTerm a) <;> cases val (decodeTerm b) <;> simp [rel,application,witness']

theorem no_goal (p : Deriv goal) : False := by
 have v {x} (k : Deriv x) : valid x := by
   induction k with
   | row h => exact row_valid h
   | mp _ _ a b => exact (evaluate_imp ..).mp a b
 simpa [valid,goal,evaluate_eqn,s,value,decodeTerm_app,decodeTerm_q,val,application,rel] using v p
end CollapsedRows
#print axioms CollapsedRows.no_goal
