import NF210.MachineSemantics
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Moving184.Table
open NF210.TM
abbrev State := Fin 184
def start : State := 149
def stateNames : Array String := #["a:CD:1", "a:CD:5", "a:CD:6", "a:CD:7", "a:CI:0", "a:CI:1", "a:CI:2", "a:CI:3", "a:CI:4", "a:CI:5", "a:CI:6", "a:CI:7", "a:CI:8", "d:0", "d:1", "d:10", "d:101", "d:102", "d:104", "d:105", "d:109", "d:11", "d:118", "d:12", "d:127", "d:13", "d:130", "d:134", "d:14", "d:142", "d:143", "d:144", "d:145", "d:146", "d:147", "d:148", "d:149", "d:15", "d:150", "d:151", "d:152", "d:153", "d:154", "d:155", "d:157", "d:158", "d:159", "d:16", "d:160", "d:161", "d:162", "d:163", "d:164", "d:165", "d:166", "d:17", "d:18", "d:19", "d:2", "d:20", "d:21", "d:22", "d:23", "d:24", "d:25", "d:26", "d:28", "d:29", "d:3", "d:31", "d:32", "d:33", "d:39", "d:40", "d:43", "d:44", "d:45", "d:46", "d:47", "d:49", "d:5", "d:50", "d:51", "d:52", "d:53", "d:54", "d:55", "d:56", "d:57", "d:59", "d:6", "d:60", "d:61", "d:62", "d:63", "d:64", "d:65", "d:67", "d:68", "d:69", "d:7", "d:70", "d:71", "d:73", "d:74", "d:75", "d:76", "d:77", "d:78", "d:79", "d:8", "d:80", "d:83", "d:85", "d:87", "d:97", "d:98", "d:99", "fresh:4", "fresh:5", "fresh:6", "k16share:0", "k16share:1", "k:0", "k:10", "k:113", "k:15", "k:198", "k:2", "k:22", "k:23", "k:24", "k:25", "k:3", "k:302", "k:32", "k:33", "k:35", "k:36", "k:4", "k:40", "k:48", "k:49", "k:5", "k:51", "k:54", "k:55", "k:6", "k:60", "k:64", "k:66", "k:74", "k:75", "k:9", "k:94", "k:97", "n:0", "n:10", "n:11", "n:12", "n:8", "n:9", "purenew:0", "purenew:1", "purenew:10", "purenew:11", "purenew:12", "purenew:13", "purenew:14", "purenew:15", "purenew:16", "purenew:17", "purenew:18", "purenew:19", "purenew:2", "purenew:20", "purenew:21", "purenew:3", "purenew:4", "purenew:5", "purenew:6", "purenew:7", "purenew:8", "purenew:9"]
theorem stateNames_size : stateNames.size = 184 := by decide


def name (q : State) : String :=
  stateNames[q.val]'(by simpa only [stateNames_size] using q.isLt)

/-- A balanced decision tree evaluates quickly inside the kernel. -/
def instructionPair (q : State) : Instruction 184 × Instruction 184 :=
  if q.val < 92 then
    if q.val < 46 then
      if q.val < 23 then
        if q.val < 11 then
          if q.val < 5 then
            if q.val < 2 then
              if q.val < 1 then
                (⟨false, .left, some (102 : State)⟩, ⟨true, .left, some (26 : State)⟩)
              else
                (⟨false, .right, some (131 : State)⟩, ⟨false, .right, some (146 : State)⟩)
            else
              if q.val < 3 then
                (⟨false, .left, some (54 : State)⟩, ⟨true, .left, some (92 : State)⟩)
              else
                if q.val < 4 then
                  (⟨false, .left, some (96 : State)⟩, ⟨false, .left, some (146 : State)⟩)
                else
                  (⟨false, .left, some (110 : State)⟩, ⟨false, .left, some (148 : State)⟩)
          else
            if q.val < 8 then
              if q.val < 6 then
                (⟨false, .right, some (142 : State)⟩, ⟨false, .right, some (132 : State)⟩)
              else
                if q.val < 7 then
                  (⟨false, .left, some (73 : State)⟩, ⟨false, .left, some (132 : State)⟩)
                else
                  (⟨false, .left, some (100 : State)⟩, ⟨false, .left, some (129 : State)⟩)
            else
              if q.val < 9 then
                (⟨false, .left, some (73 : State)⟩, ⟨false, .right, some (141 : State)⟩)
              else
                if q.val < 10 then
                  (⟨false, .left, some (92 : State)⟩, ⟨true, .left, some (96 : State)⟩)
                else
                  (⟨false, .right, some (142 : State)⟩, ⟨false, .right, some (148 : State)⟩)
        else
          if q.val < 17 then
            if q.val < 14 then
              if q.val < 12 then
                (⟨false, .left, some (92 : State)⟩, ⟨true, .left, some (56 : State)⟩)
              else
                if q.val < 13 then
                  (⟨false, .left, some (99 : State)⟩, ⟨false, .right, some (138 : State)⟩)
                else
                  (⟨false, .right, some (14 : State)⟩, ⟨true, .right, some (66 : State)⟩)
            else
              if q.val < 15 then
                (⟨false, .right, some (58 : State)⟩, ⟨true, .right, some (61 : State)⟩)
              else
                if q.val < 16 then
                  (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (21 : State)⟩)
                else
                  (⟨false, .left, some (157 : State)⟩, ⟨true, .right, some (18 : State)⟩)
          else
            if q.val < 20 then
              if q.val < 18 then
                (⟨false, .right, some (94 : State)⟩, ⟨true, .right, some (116 : State)⟩)
              else
                if q.val < 19 then
                  (⟨false, .right, some (113 : State)⟩, ⟨true, .left, some (167 : State)⟩)
                else
                  (⟨false, .left, some (113 : State)⟩, ⟨true, .left, some (20 : State)⟩)
            else
              if q.val < 21 then
                (⟨false, .right, some (17 : State)⟩, ⟨true, .right, some (113 : State)⟩)
              else
                if q.val < 22 then
                  (⟨false, .right, some (4 : State)⟩, ⟨false, .left, some (121 : State)⟩)
                else
                  (⟨false, .right, some (109 : State)⟩, ⟨true, .left, some (29 : State)⟩)
      else
        if q.val < 34 then
          if q.val < 28 then
            if q.val < 25 then
              if q.val < 24 then
                (⟨false, .right, some (25 : State)⟩, ⟨true, .right, some (59 : State)⟩)
              else
                (⟨false, .left, some (107 : State)⟩, ⟨true, .left, some (180 : State)⟩)
            else
              if q.val < 26 then
                (⟨false, .right, some (12 : State)⟩, ⟨true, .right, some (28 : State)⟩)
              else
                if q.val < 27 then
                  (⟨false, .right, some (5 : State)⟩, ⟨true, .right, some (114 : State)⟩)
                else
                  (⟨false, .left, some (16 : State)⟩, ⟨true, .left, some (158 : State)⟩)
          else
            if q.val < 31 then
              if q.val < 29 then
                (⟨false, .right, some (37 : State)⟩, ⟨false, .left, some (121 : State)⟩)
              else
                if q.val < 30 then
                  (⟨false, .left, some (16 : State)⟩, ⟨true, .right, some (26 : State)⟩)
                else
                  (⟨false, .right, some (31 : State)⟩, ⟨true, .right, some (32 : State)⟩)
            else
              if q.val < 32 then
                (⟨false, .left, some (115 : State)⟩, ⟨true, .right, some (29 : State)⟩)
              else
                if q.val < 33 then
                  (⟨false, .left, some (18 : State)⟩, ⟨true, .right, some (104 : State)⟩)
                else
                  (⟨false, .right, some (34 : State)⟩, ⟨true, .right, some (35 : State)⟩)
        else
          if q.val < 40 then
            if q.val < 37 then
              if q.val < 35 then
                (⟨false, .right, some (8 : State)⟩, ⟨false, .left, some (122 : State)⟩)
              else
                if q.val < 36 then
                  (⟨false, .right, some (1 : State)⟩, ⟨false, .left, some (128 : State)⟩)
                else
                  (⟨false, .right, some (38 : State)⟩, ⟨true, .right, some (39 : State)⟩)
            else
              if q.val < 38 then
                (⟨false, .right, some (11 : State)⟩, ⟨true, .right, some (47 : State)⟩)
              else
                if q.val < 39 then
                  (⟨false, .right, some (8 : State)⟩, ⟨true, .right, some (109 : State)⟩)
                else
                  (⟨false, .right, some (40 : State)⟩, ⟨true, .right, some (112 : State)⟩)
          else
            if q.val < 43 then
              if q.val < 41 then
                (⟨false, .right, some (41 : State)⟩, ⟨true, .right, some (35 : State)⟩)
              else
                if q.val < 42 then
                  (⟨false, .right, some (1 : State)⟩, ⟨true, .right, some (42 : State)⟩)
                else
                  (⟨false, .left, some (33 : State)⟩, ⟨true, .right, some (43 : State)⟩)
            else
              if q.val < 44 then
                (⟨false, .right, some (1 : State)⟩, ⟨true, .right, some (1 : State)⟩)
              else
                if q.val < 45 then
                  (⟨false, .right, some (104 : State)⟩, ⟨true, .right, some (45 : State)⟩)
                else
                  (⟨false, .right, some (46 : State)⟩, ⟨true, .right, some (52 : State)⟩)
    else
      if q.val < 69 then
        if q.val < 57 then
          if q.val < 51 then
            if q.val < 48 then
              if q.val < 47 then
                (⟨false, .right, some (76 : State)⟩, ⟨true, .right, some (48 : State)⟩)
              else
                (⟨false, .right, some (55 : State)⟩, ⟨true, .right, some (56 : State)⟩)
            else
              if q.val < 49 then
                (⟨false, .left, some (89 : State)⟩, ⟨true, .right, some (49 : State)⟩)
              else
                if q.val < 50 then
                  (⟨false, .right, some (50 : State)⟩, ⟨true, .right, some (51 : State)⟩)
                else
                  (⟨false, .left, some (53 : State)⟩, ⟨false, .left, some (121 : State)⟩)
          else
            if q.val < 54 then
              if q.val < 52 then
                (⟨false, .right, some (9 : State)⟩, ⟨true, .right, some (72 : State)⟩)
              else
                if q.val < 53 then
                  (⟨false, .right, some (53 : State)⟩, ⟨true, .right, some (33 : State)⟩)
                else
                  (⟨false, .right, some (54 : State)⟩, ⟨true, .left, some (17 : State)⟩)
            else
              if q.val < 55 then
                (⟨false, .left, some (40 : State)⟩, ⟨true, .left, some (47 : State)⟩)
              else
                if q.val < 56 then
                  (⟨false, .right, some (2 : State)⟩, ⟨false, .left, some (134 : State)⟩)
                else
                  (⟨false, .right, some (3 : State)⟩, ⟨true, .right, some (57 : State)⟩)
        else
          if q.val < 63 then
            if q.val < 60 then
              if q.val < 58 then
                (⟨false, .left, some (96 : State)⟩, ⟨false, .left, some (121 : State)⟩)
              else
                if q.val < 59 then
                  (⟨false, .right, some (68 : State)⟩, ⟨true, .right, some (23 : State)⟩)
                else
                  (⟨false, .right, some (3 : State)⟩, ⟨true, .right, some (60 : State)⟩)
            else
              if q.val < 61 then
                (⟨false, .right, some (12 : State)⟩, ⟨false, .left, some (35 : State)⟩)
              else
                if q.val < 62 then
                  (⟨false, .right, some (62 : State)⟩, ⟨true, .right, some (64 : State)⟩)
                else
                  (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (63 : State)⟩)
          else
            if q.val < 66 then
              if q.val < 64 then
                (⟨false, .right, some (7 : State)⟩, ⟨false, .left, some (122 : State)⟩)
              else
                if q.val < 65 then
                  (⟨false, .right, some (23 : State)⟩, ⟨true, .right, some (65 : State)⟩)
                else
                  (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (34 : State)⟩)
            else
              if q.val < 67 then
                (⟨false, .right, some (67 : State)⟩, ⟨true, .right, some (36 : State)⟩)
              else
                if q.val < 68 then
                  (⟨false, .left, some (69 : State)⟩, ⟨true, .right, some (69 : State)⟩)
                else
                  (⟨false, .right, some (110 : State)⟩, ⟨true, .right, some (80 : State)⟩)
      else
        if q.val < 80 then
          if q.val < 74 then
            if q.val < 71 then
              if q.val < 70 then
                (⟨false, .right, some (70 : State)⟩, ⟨true, .right, some (44 : State)⟩)
              else
                (⟨false, .right, some (7 : State)⟩, ⟨true, .right, some (71 : State)⟩)
            else
              if q.val < 72 then
                (⟨false, .right, some (176 : State)⟩, ⟨true, .left, some (72 : State)⟩)
              else
                if q.val < 73 then
                  (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (73 : State)⟩)
                else
                  (⟨false, .left, some (49 : State)⟩, ⟨false, .left, some (121 : State)⟩)
          else
            if q.val < 77 then
              if q.val < 75 then
                (⟨false, .right, some (75 : State)⟩, ⟨true, .right, some (89 : State)⟩)
              else
                if q.val < 76 then
                  (⟨false, .left, some (45 : State)⟩, ⟨true, .right, some (77 : State)⟩)
                else
                  (⟨false, .left, some (81 : State)⟩, ⟨true, .right, some (57 : State)⟩)
            else
              if q.val < 78 then
                (⟨false, .right, some (78 : State)⟩, ⟨true, .right, some (79 : State)⟩)
              else
                if q.val < 79 then
                  (⟨false, .left, some (98 : State)⟩, ⟨true, .right, some (11 : State)⟩)
                else
                  (⟨false, .left, some (97 : State)⟩, ⟨true, .right, some (88 : State)⟩)
        else
          if q.val < 86 then
            if q.val < 83 then
              if q.val < 81 then
                (⟨false, .right, some (4 : State)⟩, ⟨true, .right, some (90 : State)⟩)
              else
                if q.val < 82 then
                  (⟨false, .right, some (82 : State)⟩, ⟨true, .right, some (84 : State)⟩)
                else
                  (⟨false, .right, some (0 : State)⟩, ⟨true, .right, some (83 : State)⟩)
            else
              if q.val < 84 then
                (⟨false, .right, some (11 : State)⟩, ⟨true, .right, some (2 : State)⟩)
              else
                if q.val < 85 then
                  (⟨false, .right, some (2 : State)⟩, ⟨true, .right, some (85 : State)⟩)
                else
                  (⟨false, .right, some (86 : State)⟩, ⟨false, .left, some (57 : State)⟩)
          else
            if q.val < 89 then
              if q.val < 87 then
                (⟨false, .right, some (11 : State)⟩, ⟨true, .right, some (87 : State)⟩)
              else
                if q.val < 88 then
                  (⟨false, .left, some (64 : State)⟩, ⟨true, .right, some (11 : State)⟩)
                else
                  (⟨false, .left, some (23 : State)⟩, ⟨true, .right, some (99 : State)⟩)
            else
              if q.val < 90 then
                (⟨false, .right, some (91 : State)⟩, ⟨true, .right, some (62 : State)⟩)
              else
                if q.val < 91 then
                  (⟨false, .right, some (100 : State)⟩, ⟨true, .right, some (15 : State)⟩)
                else
                  (⟨false, .left, some (66 : State)⟩, ⟨true, .right, some (92 : State)⟩)
  else
    if q.val < 138 then
      if q.val < 115 then
        if q.val < 103 then
          if q.val < 97 then
            if q.val < 94 then
              if q.val < 93 then
                (⟨false, .right, some (10 : State)⟩, ⟨true, .right, some (93 : State)⟩)
              else
                (⟨false, .left, some (29 : State)⟩, ⟨false, .left, some (124 : State)⟩)
            else
              if q.val < 95 then
                (⟨false, .right, some (75 : State)⟩, ⟨true, .right, some (95 : State)⟩)
              else
                if q.val < 96 then
                  (⟨false, .right, some (96 : State)⟩, ⟨true, .right, some (65 : State)⟩)
                else
                  (⟨false, .left, some (33 : State)⟩, ⟨true, .right, some (92 : State)⟩)
          else
            if q.val < 100 then
              if q.val < 98 then
                (⟨false, .right, some (98 : State)⟩, ⟨true, .right, some (101 : State)⟩)
              else
                if q.val < 99 then
                  (⟨false, .right, some (99 : State)⟩, ⟨true, .right, some (88 : State)⟩)
                else
                  (⟨false, .right, some (6 : State)⟩, ⟨true, .left, some (87 : State)⟩)
            else
              if q.val < 101 then
                (⟨false, .right, some (4 : State)⟩, ⟨true, .right, some (110 : State)⟩)
              else
                if q.val < 102 then
                  (⟨false, .right, some (81 : State)⟩, ⟨true, .right, some (102 : State)⟩)
                else
                  (⟨false, .left, some (47 : State)⟩, ⟨true, .right, some (9 : State)⟩)
        else
          if q.val < 109 then
            if q.val < 106 then
              if q.val < 104 then
                (⟨false, .right, some (104 : State)⟩, ⟨true, .right, some (105 : State)⟩)
              else
                if q.val < 105 then
                  (⟨false, .left, some (16 : State)⟩, ⟨true, .right, some (97 : State)⟩)
                else
                  (⟨false, .right, some (106 : State)⟩, ⟨true, .right, some (108 : State)⟩)
            else
              if q.val < 107 then
                (⟨false, .left, some (103 : State)⟩, ⟨true, .right, some (107 : State)⟩)
              else
                if q.val < 108 then
                  (⟨false, .right, some (108 : State)⟩, ⟨true, .right, some (109 : State)⟩)
                else
                  (⟨false, .right, some (74 : State)⟩, ⟨true, .right, some (97 : State)⟩)
          else
            if q.val < 112 then
              if q.val < 110 then
                (⟨false, .right, some (111 : State)⟩, ⟨true, .right, some (72 : State)⟩)
              else
                if q.val < 111 then
                  (⟨false, .right, some (12 : State)⟩, ⟨true, .right, some (2 : State)⟩)
                else
                  (⟨false, .left, some (113 : State)⟩, ⟨true, .right, some (96 : State)⟩)
            else
              if q.val < 113 then
                (⟨false, .left, some (117 : State)⟩, ⟨true, .left, some (107 : State)⟩)
              else
                if q.val < 114 then
                  (⟨false, .left, some (105 : State)⟩, ⟨true, .right, some (22 : State)⟩)
                else
                  (⟨false, .right, some (97 : State)⟩, ⟨true, .right, some (5 : State)⟩)
      else
        if q.val < 126 then
          if q.val < 120 then
            if q.val < 117 then
              if q.val < 116 then
                (⟨false, .right, some (116 : State)⟩, ⟨true, .left, some (162 : State)⟩)
              else
                (⟨false, .left, some (20 : State)⟩, ⟨true, .right, some (114 : State)⟩)
            else
              if q.val < 118 then
                (⟨false, .right, some (114 : State)⟩, ⟨true, .left, some (32 : State)⟩)
              else
                if q.val < 119 then
                  (⟨false, .right, some (19 : State)⟩, ⟨true, .left, some (178 : State)⟩)
                else
                  (⟨false, .right, some (24 : State)⟩, ⟨true, .right, some (159 : State)⟩)
          else
            if q.val < 123 then
              if q.val < 121 then
                (⟨false, .right, some (118 : State)⟩, ⟨true, .right, some (119 : State)⟩)
              else
                if q.val < 122 then
                  (⟨true, .left, some (122 : State)⟩, ⟨false, .left, some (128 : State)⟩)
                else
                  (⟨true, .left, some (33 : State)⟩, ⟨false, .right, some (122 : State)⟩)
            else
              if q.val < 124 then
                (⟨true, .right, some (154 : State)⟩, ⟨true, .right, some (123 : State)⟩)
              else
                if q.val < 125 then
                  (⟨false, .left, some (121 : State)⟩, ⟨false, .right, some (124 : State)⟩)
                else
                  (⟨false, .left, some (134 : State)⟩, ⟨false, .left, some (155 : State)⟩)
        else
          if q.val < 132 then
            if q.val < 129 then
              if q.val < 127 then
                (⟨false, .left, some (130 : State)⟩, ⟨true, .left, some (128 : State)⟩)
              else
                if q.val < 128 then
                  (⟨false, .left, some (155 : State)⟩, ⟨true, .left, some (145 : State)⟩)
                else
                  (⟨false, .left, some (133 : State)⟩, ⟨true, .left, some (128 : State)⟩)
            else
              if q.val < 130 then
                (⟨false, .right, some (136 : State)⟩, ⟨true, .right, some (129 : State)⟩)
              else
                if q.val < 131 then
                  (⟨false, .left, some (152 : State)⟩, ⟨true, .left, some (128 : State)⟩)
                else
                  (⟨false, .left, some (137 : State)⟩, ⟨false, .right, some (123 : State)⟩)
          else
            if q.val < 135 then
              if q.val < 133 then
                (⟨false, .right, some (138 : State)⟩, ⟨true, .right, some (132 : State)⟩)
              else
                if q.val < 134 then
                  (⟨false, .left, some (143 : State)⟩, ⟨true, .left, some (128 : State)⟩)
                else
                  (⟨false, .left, some (139 : State)⟩, ⟨false, .left, none⟩)
            else
              if q.val < 136 then
                (⟨false, .right, some (141 : State)⟩, ⟨true, .right, some (135 : State)⟩)
              else
                if q.val < 137 then
                  (⟨false, .right, some (135 : State)⟩, ⟨true, .right, some (136 : State)⟩)
                else
                  (⟨true, .right, some (137 : State)⟩, ⟨true, .left, some (128 : State)⟩)
    else
      if q.val < 161 then
        if q.val < 149 then
          if q.val < 143 then
            if q.val < 140 then
              if q.val < 139 then
                (⟨false, .right, some (144 : State)⟩, ⟨true, .right, some (138 : State)⟩)
              else
                (⟨true, .right, some (147 : State)⟩, ⟨false, .left, some (139 : State)⟩)
            else
              if q.val < 141 then
                (⟨false, .left, some (139 : State)⟩, ⟨true, .left, some (145 : State)⟩)
              else
                if q.val < 142 then
                  (⟨false, .right, some (132 : State)⟩, ⟨true, .right, some (141 : State)⟩)
                else
                  (⟨false, .left, some (137 : State)⟩, ⟨false, .right, some (149 : State)⟩)
          else
            if q.val < 146 then
              if q.val < 144 then
                (⟨false, .left, some (153 : State)⟩, ⟨true, .left, some (128 : State)⟩)
              else
                if q.val < 145 then
                  (⟨false, .right, some (121 : State)⟩, ⟨true, .right, some (144 : State)⟩)
                else
                  (⟨false, .left, some (140 : State)⟩, ⟨true, .left, some (145 : State)⟩)
            else
              if q.val < 147 then
                (⟨false, .right, some (129 : State)⟩, ⟨true, .right, some (146 : State)⟩)
              else
                if q.val < 148 then
                  (⟨false, .right, some (147 : State)⟩, ⟨false, .right, some (124 : State)⟩)
                else
                  (⟨false, .right, some (146 : State)⟩, ⟨true, .right, some (148 : State)⟩)
        else
          if q.val < 155 then
            if q.val < 152 then
              if q.val < 150 then
                (⟨false, .right, some (151 : State)⟩, ⟨true, .right, some (149 : State)⟩)
              else
                if q.val < 151 then
                  (⟨true, .left, some (145 : State)⟩, ⟨true, .right, some (127 : State)⟩)
                else
                  (⟨true, .right, some (123 : State)⟩, ⟨true, .right, some (149 : State)⟩)
            else
              if q.val < 153 then
                (⟨false, .right, some (152 : State)⟩, ⟨true, .right, some (13 : State)⟩)
              else
                if q.val < 154 then
                  (⟨false, .left, some (126 : State)⟩, ⟨true, .left, some (128 : State)⟩)
                else
                  (⟨false, .right, some (150 : State)⟩, ⟨false, .right, some (123 : State)⟩)
          else
            if q.val < 158 then
              if q.val < 156 then
                (⟨true, .left, some (125 : State)⟩, ⟨true, .left, some (155 : State)⟩)
              else
                if q.val < 157 then
                  (⟨false, .right, some (64 : State)⟩, ⟨true, .right, some (103 : State)⟩)
                else
                  (⟨false, .right, some (161 : State)⟩, ⟨true, .right, some (20 : State)⟩)
            else
              if q.val < 159 then
                (⟨false, .right, some (32 : State)⟩, ⟨true, .right, some (157 : State)⟩)
              else
                if q.val < 160 then
                  (⟨false, .right, some (158 : State)⟩, ⟨true, .right, some (18 : State)⟩)
                else
                  (⟨false, .right, some (26 : State)⟩, ⟨true, .right, some (113 : State)⟩)
      else
        if q.val < 172 then
          if q.val < 166 then
            if q.val < 163 then
              if q.val < 162 then
                (⟨false, .right, some (160 : State)⟩, ⟨true, .right, some (16 : State)⟩)
              else
                (⟨false, .left, some (169 : State)⟩, ⟨true, .right, some (19 : State)⟩)
            else
              if q.val < 164 then
                (⟨false, .right, some (156 : State)⟩, ⟨true, .right, some (162 : State)⟩)
              else
                if q.val < 165 then
                  (⟨false, .right, some (180 : State)⟩, ⟨true, .right, some (22 : State)⟩)
                else
                  (⟨false, .right, some (183 : State)⟩, ⟨true, .right, some (164 : State)⟩)
          else
            if q.val < 169 then
              if q.val < 167 then
                (⟨false, .left, some (173 : State)⟩, ⟨true, .right, some (117 : State)⟩)
              else
                if q.val < 168 then
                  (⟨false, .right, some (165 : State)⟩, ⟨true, .right, some (166 : State)⟩)
                else
                  (⟨false, .right, some (112 : State)⟩, ⟨true, .right, some (167 : State)⟩)
            else
              if q.val < 170 then
                (⟨false, .right, some (178 : State)⟩, ⟨true, .right, some (168 : State)⟩)
              else
                if q.val < 171 then
                  (⟨false, .right, some (169 : State)⟩, ⟨true, .right, some (104 : State)⟩)
                else
                  (⟨false, .right, some (177 : State)⟩, ⟨true, .right, some (170 : State)⟩)
        else
          if q.val < 178 then
            if q.val < 175 then
              if q.val < 173 then
                (⟨false, .right, some (72 : State)⟩, ⟨true, .right, some (171 : State)⟩)
              else
                if q.val < 174 then
                  (⟨false, .right, some (172 : State)⟩, ⟨true, .right, some (31 : State)⟩)
                else
                  (⟨false, .right, some (104 : State)⟩, ⟨true, .right, some (163 : State)⟩)
            else
              if q.val < 176 then
                (⟨false, .right, some (23 : State)⟩, ⟨true, .right, some (173 : State)⟩)
              else
                if q.val < 177 then
                  (⟨false, .right, some (175 : State)⟩, ⟨true, .right, some (30 : State)⟩)
                else
                  (⟨false, .left, some (107 : State)⟩, ⟨true, .right, some (174 : State)⟩)
          else
            if q.val < 181 then
              if q.val < 179 then
                (⟨false, .right, some (181 : State)⟩, ⟨true, .right, some (27 : State)⟩)
              else
                if q.val < 180 then
                  (⟨false, .left, some (183 : State)⟩, ⟨true, .right, some (19 : State)⟩)
                else
                  (⟨false, .right, some (179 : State)⟩, ⟨true, .right, some (26 : State)⟩)
            else
              if q.val < 182 then
                (⟨false, .left, some (165 : State)⟩, ⟨true, .right, some (115 : State)⟩)
              else
                if q.val < 183 then
                  (⟨false, .right, some (120 : State)⟩, ⟨true, .right, some (181 : State)⟩)
                else
                  (⟨false, .left, some (29 : State)⟩, ⟨true, .right, some (182 : State)⟩)
def machine (q : State) (read : Bool) : Instruction 184 :=
  if read then (instructionPair q).2 else (instructionPair q).1

def renderBit (b : Bool) : String := if b then "1" else "0"
def renderDirection : Direction → String | .left => "L" | .right => "R"
def renderTarget : Option State → String | none => "halt" | some q => name q

def renderRow (q : State) (read : Bool) : String :=
  let row := machine q read
  name q ++ " " ++ renderBit read ++ " " ++ renderBit row.write ++ " " ++
    renderDirection row.move ++ " " ++ renderTarget row.next ++ "\n"

def literalOrder : List State := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183]
theorem literalOrder_size : literalOrder.length = 184 := by decide +kernel

def serializedRows : List String :=
  literalOrder.flatMap fun q => [renderRow q false, renderRow q true]

def literalRows : List String := [
"a:CD:1 0 0 L d:71\n",
"a:CD:1 1 1 L d:130\n",
"a:CD:5 0 0 R k:24\n",
"a:CD:5 1 0 R k:55\n",
"a:CD:6 0 0 L d:166\n",
"a:CD:6 1 1 L d:61\n",
"a:CD:7 0 0 L d:65\n",
"a:CD:7 1 0 L k:55\n",
"a:CI:0 0 0 L d:8\n",
"a:CI:0 1 0 L k:60\n",
"a:CI:1 0 0 R k:49\n",
"a:CI:1 1 0 R k:25\n",
"a:CI:2 0 0 L d:40\n",
"a:CI:2 1 0 L k:25\n",
"a:CI:3 0 0 L d:7\n",
"a:CI:3 1 0 L k:22\n",
"a:CI:4 0 0 L d:40\n",
"a:CI:4 1 0 R k:48\n",
"a:CI:5 0 0 L d:61\n",
"a:CI:5 1 1 L d:65\n",
"a:CI:6 0 0 R k:49\n",
"a:CI:6 1 0 R k:60\n",
"a:CI:7 0 0 L d:61\n",
"a:CI:7 1 1 L d:18\n",
"a:CI:8 0 0 L d:69\n",
"a:CI:8 1 0 R k:36\n",
"d:0 0 0 R d:1\n",
"d:0 1 1 R d:28\n",
"d:1 0 0 R d:2\n",
"d:1 1 1 R d:22\n",
"d:10 0 0 R a:CD:6\n",
"d:10 1 1 R d:11\n",
"d:101 0 0 L n:10\n",
"d:101 1 1 R d:104\n",
"d:102 0 0 R d:63\n",
"d:102 1 1 R d:98\n",
"d:104 0 0 R d:85\n",
"d:104 1 1 L purenew:13\n",
"d:105 0 0 L d:85\n",
"d:105 1 1 L d:109\n",
"d:109 0 0 R d:102\n",
"d:109 1 1 R d:85\n",
"d:11 0 0 R a:CI:0\n",
"d:11 1 0 L k16share:0\n",
"d:118 0 0 R d:79\n",
"d:118 1 1 L d:142\n",
"d:12 0 0 R d:13\n",
"d:12 1 1 R d:20\n",
"d:127 0 0 L d:77\n",
"d:127 1 1 L purenew:6\n",
"d:13 0 0 R a:CI:8\n",
"d:13 1 1 R d:14\n",
"d:130 0 0 R a:CI:1\n",
"d:130 1 1 R d:87\n",
"d:134 0 0 L d:101\n",
"d:134 1 1 L n:11\n",
"d:14 0 0 R d:15\n",
"d:14 1 0 L k16share:0\n",
"d:142 0 0 L d:101\n",
"d:142 1 1 R d:130\n",
"d:143 0 0 R d:144\n",
"d:143 1 1 R d:145\n",
"d:144 0 0 L d:97\n",
"d:144 1 1 R d:142\n",
"d:145 0 0 L d:104\n",
"d:145 1 1 R d:74\n",
"d:146 0 0 R d:147\n",
"d:146 1 1 R d:148\n",
"d:147 0 0 R a:CI:4\n",
"d:147 1 0 L k16share:1\n",
"d:148 0 0 R a:CD:5\n",
"d:148 1 0 L k:2\n",
"d:149 0 0 R d:150\n",
"d:149 1 1 R d:151\n",
"d:15 0 0 R a:CI:7\n",
"d:15 1 1 R d:16\n",
"d:150 0 0 R a:CI:4\n",
"d:150 1 1 R d:79\n",
"d:151 0 0 R d:152\n",
"d:151 1 1 R d:83\n",
"d:152 0 0 R d:153\n",
"d:152 1 1 R d:148\n",
"d:153 0 0 R a:CD:5\n",
"d:153 1 1 R d:154\n",
"d:154 0 0 L d:146\n",
"d:154 1 1 R d:155\n",
"d:155 0 0 R a:CD:5\n",
"d:155 1 1 R a:CD:5\n",
"d:157 0 0 R d:74\n",
"d:157 1 1 R d:158\n",
"d:158 0 0 R d:159\n",
"d:158 1 1 R d:164\n",
"d:159 0 0 R d:45\n",
"d:159 1 1 R d:160\n",
"d:16 0 0 R d:17\n",
"d:16 1 1 R d:18\n",
"d:160 0 0 L d:59\n",
"d:160 1 1 R d:161\n",
"d:161 0 0 R d:162\n",
"d:161 1 1 R d:163\n",
"d:162 0 0 L d:165\n",
"d:162 1 0 L k16share:0\n",
"d:163 0 0 R a:CI:5\n",
"d:163 1 1 R d:39\n",
"d:164 0 0 R d:165\n",
"d:164 1 1 R d:146\n",
"d:165 0 0 R d:166\n",
"d:165 1 1 L d:102\n",
"d:166 0 0 L d:152\n",
"d:166 1 1 L d:16\n",
"d:17 0 0 R a:CD:6\n",
"d:17 1 0 L k:302\n",
"d:18 0 0 R a:CD:7\n",
"d:18 1 1 R d:19\n",
"d:19 0 0 L d:65\n",
"d:19 1 0 L k16share:0\n",
"d:2 0 0 R d:3\n",
"d:2 1 1 R d:12\n",
"d:20 0 0 R a:CD:7\n",
"d:20 1 1 R d:21\n",
"d:21 0 0 R a:CI:8\n",
"d:21 1 0 L d:148\n",
"d:22 0 0 R d:23\n",
"d:22 1 1 R d:25\n",
"d:23 0 0 R a:CD:6\n",
"d:23 1 1 R d:24\n",
"d:24 0 0 R a:CI:3\n",
"d:24 1 0 L k16share:1\n",
"d:25 0 0 R d:12\n",
"d:25 1 1 R d:26\n",
"d:26 0 0 R a:CD:6\n",
"d:26 1 1 R d:147\n",
"d:28 0 0 R d:29\n",
"d:28 1 1 R d:149\n",
"d:29 0 0 L d:31\n",
"d:29 1 1 R d:31\n",
"d:3 0 0 R d:8\n",
"d:3 1 1 R d:5\n",
"d:31 0 0 R d:32\n",
"d:31 1 1 R d:157\n",
"d:32 0 0 R a:CI:3\n",
"d:32 1 1 R d:33\n",
"d:33 0 0 R purenew:21\n",
"d:33 1 1 L d:39\n",
"d:39 0 0 R a:CD:6\n",
"d:39 1 1 R d:40\n",
"d:40 0 0 L d:161\n",
"d:40 1 0 L k16share:0\n",
"d:43 0 0 R d:44\n",
"d:43 1 1 R d:59\n",
"d:44 0 0 L d:158\n",
"d:44 1 1 R d:46\n",
"d:45 0 0 L d:50\n",
"d:45 1 1 R d:19\n",
"d:46 0 0 R d:47\n",
"d:46 1 1 R d:49\n",
"d:47 0 0 L d:68\n",
"d:47 1 1 R a:CI:7\n",
"d:49 0 0 L d:67\n",
"d:49 1 1 R d:57\n",
"d:5 0 0 R a:CI:0\n",
"d:5 1 1 R d:6\n",
"d:50 0 0 R d:51\n",
"d:50 1 1 R d:53\n",
"d:51 0 0 R a:CD:1\n",
"d:51 1 1 R d:52\n",
"d:52 0 0 R a:CI:7\n",
"d:52 1 1 R a:CD:6\n",
"d:53 0 0 R a:CD:6\n",
"d:53 1 1 R d:54\n",
"d:54 0 0 R d:55\n",
"d:54 1 0 L d:19\n",
"d:55 0 0 R a:CI:7\n",
"d:55 1 1 R d:56\n",
"d:56 0 0 L d:25\n",
"d:56 1 1 R a:CI:7\n",
"d:57 0 0 L d:12\n",
"d:57 1 1 R d:69\n",
"d:59 0 0 R d:60\n",
"d:59 1 1 R d:23\n",
"d:6 0 0 R d:7\n",
"d:6 1 1 R d:10\n",
"d:60 0 0 L d:28\n",
"d:60 1 1 R d:61\n",
"d:61 0 0 R a:CI:6\n",
"d:61 1 1 R d:62\n",
"d:62 0 0 L d:142\n",
"d:62 1 0 L k:10\n",
"d:63 0 0 R d:44\n",
"d:63 1 1 R d:64\n",
"d:64 0 0 R d:65\n",
"d:64 1 1 R d:26\n",
"d:65 0 0 L d:146\n",
"d:65 1 1 R d:61\n",
"d:67 0 0 R d:68\n",
"d:67 1 1 R d:70\n",
"d:68 0 0 R d:69\n",
"d:68 1 1 R d:57\n",
"d:69 0 0 R a:CI:2\n",
"d:69 1 1 L d:56\n",
"d:7 0 0 R a:CI:0\n",
"d:7 1 1 R d:8\n",
"d:70 0 0 R d:50\n",
"d:70 1 1 R d:71\n",
"d:71 0 0 L d:16\n",
"d:71 1 1 R a:CI:5\n",
"d:73 0 0 R d:74\n",
"d:73 1 1 R d:75\n",
"d:74 0 0 L d:101\n",
"d:74 1 1 R d:67\n",
"d:75 0 0 R d:76\n",
"d:75 1 1 R d:78\n",
"d:76 0 0 L d:73\n",
"d:76 1 1 R d:77\n",
"d:77 0 0 R d:78\n",
"d:77 1 1 R d:79\n",
"d:78 0 0 R d:43\n",
"d:78 1 1 R d:67\n",
"d:79 0 0 R d:80\n",
"d:79 1 1 R d:39\n",
"d:8 0 0 R a:CI:8\n",
"d:8 1 1 R a:CD:6\n",
"d:80 0 0 L d:85\n",
"d:80 1 1 R d:65\n",
"d:83 0 0 L d:99\n",
"d:83 1 1 L d:77\n",
"d:85 0 0 L d:75\n",
"d:85 1 1 R d:118\n",
"d:87 0 0 R d:67\n",
"d:87 1 1 R a:CI:1\n",
"d:97 0 0 R d:98\n",
"d:97 1 1 L purenew:0\n",
"d:98 0 0 L d:109\n",
"d:98 1 1 R d:87\n",
"d:99 0 0 R d:87\n",
"d:99 1 1 L d:145\n",
"fresh:4 0 0 R d:105\n",
"fresh:4 1 1 L purenew:4\n",
"fresh:5 0 0 R d:127\n",
"fresh:5 1 1 R n:12\n",
"fresh:6 0 0 R fresh:4\n",
"fresh:6 1 1 R fresh:5\n",
"k16share:0 0 1 L k16share:1\n",
"k16share:0 1 0 L k:2\n",
"k16share:1 0 1 L d:146\n",
"k16share:1 1 0 R k16share:1\n",
"k:0 0 1 R k:94\n",
"k:0 1 1 R k:0\n",
"k:10 0 0 L k16share:0\n",
"k:10 1 0 R k:10\n",
"k:113 0 0 L k:302\n",
"k:113 1 0 L k:97\n",
"k:15 0 0 L k:23\n",
"k:15 1 1 L k:2\n",
"k:198 0 0 L k:97\n",
"k:198 1 1 L k:54\n",
"k:2 0 0 L k:3\n",
"k:2 1 1 L k:2\n",
"k:22 0 0 R k:33\n",
"k:22 1 1 R k:22\n",
"k:23 0 0 L k:75\n",
"k:23 1 1 L k:2\n",
"k:24 0 0 L k:35\n",
"k:24 1 0 R k:0\n",
"k:25 0 0 R k:36\n",
"k:25 1 1 R k:25\n",
"k:3 0 0 L k:5\n",
"k:3 1 1 L k:2\n",
"k:302 0 0 L k:4\n",
"k:302 1 0 L halt\n",
"k:32 0 0 R k:48\n",
"k:32 1 1 R k:32\n",
"k:33 0 0 R k:32\n",
"k:33 1 1 R k:33\n",
"k:35 0 1 R k:35\n",
"k:35 1 1 L k:2\n",
"k:36 0 0 R k:51\n",
"k:36 1 1 R k:36\n",
"k:4 0 1 R k:6\n",
"k:4 1 0 L k:4\n",
"k:40 0 0 L k:4\n",
"k:40 1 1 L k:54\n",
"k:48 0 0 R k:25\n",
"k:48 1 1 R k:48\n",
"k:49 0 0 L k:35\n",
"k:49 1 0 R k:64\n",
"k:5 0 0 L k:9\n",
"k:5 1 1 L k:2\n",
"k:51 0 0 R k16share:0\n",
"k:51 1 1 R k:51\n",
"k:54 0 0 L k:40\n",
"k:54 1 1 L k:54\n",
"k:55 0 0 R k:22\n",
"k:55 1 1 R k:55\n",
"k:6 0 0 R k:6\n",
"k:6 1 0 R k:10\n",
"k:60 0 0 R k:55\n",
"k:60 1 1 R k:60\n",
"k:64 0 0 R k:74\n",
"k:64 1 1 R k:64\n",
"k:66 0 1 L k:54\n",
"k:66 1 1 R k:198\n",
"k:74 0 1 R k:0\n",
"k:74 1 1 R k:64\n",
"k:75 0 0 R k:75\n",
"k:75 1 1 R d:0\n",
"k:9 0 0 L k:15\n",
"k:9 1 1 L k:2\n",
"k:94 0 0 R k:66\n",
"k:94 1 0 R k:0\n",
"k:97 0 1 L k:113\n",
"k:97 1 1 L k:97\n",
"n:0 0 0 R d:25\n",
"n:0 1 1 R d:73\n",
"n:10 0 0 R n:9\n",
"n:10 1 1 R d:109\n",
"n:11 0 0 R d:145\n",
"n:11 1 1 R n:10\n",
"n:12 0 0 R n:11\n",
"n:12 1 1 R d:104\n",
"n:8 0 0 R d:130\n",
"n:8 1 1 R d:85\n",
"n:9 0 0 R n:8\n",
"n:9 1 1 R d:101\n",
"purenew:0 0 0 L purenew:15\n",
"purenew:0 1 1 R d:105\n",
"purenew:1 0 0 R n:0\n",
"purenew:1 1 1 R purenew:0\n",
"purenew:10 0 0 R purenew:6\n",
"purenew:10 1 1 R d:118\n",
"purenew:11 0 0 R purenew:9\n",
"purenew:11 1 1 R purenew:10\n",
"purenew:12 0 0 L purenew:19\n",
"purenew:12 1 1 R d:99\n",
"purenew:13 0 0 R purenew:11\n",
"purenew:13 1 1 R purenew:12\n",
"purenew:14 0 0 R d:83\n",
"purenew:14 1 1 R purenew:13\n",
"purenew:15 0 0 R purenew:4\n",
"purenew:15 1 1 R purenew:14\n",
"purenew:16 0 0 R purenew:15\n",
"purenew:16 1 1 R d:74\n",
"purenew:17 0 0 R purenew:3\n",
"purenew:17 1 1 R purenew:16\n",
"purenew:18 0 0 R d:39\n",
"purenew:18 1 1 R purenew:17\n",
"purenew:19 0 0 R purenew:18\n",
"purenew:19 1 1 R d:144\n",
"purenew:2 0 0 R d:74\n",
"purenew:2 1 1 R purenew:1\n",
"purenew:20 0 0 R d:12\n",
"purenew:20 1 1 R purenew:19\n",
"purenew:21 0 0 R purenew:20\n",
"purenew:21 1 1 R d:143\n",
"purenew:3 0 0 L d:77\n",
"purenew:3 1 1 R purenew:2\n",
"purenew:4 0 0 R purenew:7\n",
"purenew:4 1 1 R d:134\n",
"purenew:5 0 0 L purenew:9\n",
"purenew:5 1 1 R d:105\n",
"purenew:6 0 0 R purenew:5\n",
"purenew:6 1 1 R d:130\n",
"purenew:7 0 0 L purenew:11\n",
"purenew:7 1 1 R d:97\n",
"purenew:8 0 0 R fresh:6\n",
"purenew:8 1 1 R purenew:7\n",
"purenew:9 0 0 L d:142\n",
"purenew:9 1 1 R purenew:8\n"]
theorem serialized_exact : serializedRows = literalRows := by decide +kernel
#print axioms serialized_exact
end Moving184.Table
