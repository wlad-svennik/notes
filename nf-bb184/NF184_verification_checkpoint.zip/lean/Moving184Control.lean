import Moving184Outer
import C200Rows

set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Moving184.Register
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers
private def embeddedCheck (code : Code) (base finish : Nat) : Bool :=
  matchesCode base (compile code base finish [] [])

private theorem block_run {code : Code} {s t : Registers} {base finish : Nat}
    (hc : embeddedCheck code base finish = true) (he : Eval code s .normal t) :
    Reaches actual ⟨base,s⟩ (some ⟨finish,t⟩) :=
  he.compiled _ _ _ _ _ (embedded_of_matches code base finish hc)

/-- The source actually runs between these two configurations in positive time. -/
abbrev Visits := Moves

private theorem toVisits {s t : Config} (h : Reaches actual s (some t)) :
    Visits (liftConfig s) (liftConfig t) := by
  obtain ⟨n,hn,hr⟩ := h
  exact ⟨n,hn,actual_run n hr⟩

/-- Raw source frame, including the counter, arbitrary residual input and all
nine physical register values lifted to the source-step representation. -/
def frame (pc n t sp c d h a b input : Nat) : Source.Config :=
  Source.Config.active pc (liftRegisters (mk9 n t sp c d h a b input))

private theorem push4_checked : embeddedCheck NF192.Emitter.Literal.seq166 2850 2876 = true := by decide
private theorem imp_checked : embeddedCheck NF192.Emitter.Literal.seq119 2876 2901 = true := by decide
private theorem move16_checked : embeddedCheck NF192.Emitter.Literal.seq216 2901 2904 = true := by decide
private theorem move65_checked : embeddedCheck NF192.Emitter.Literal.seq207 2908 2911 = true := by decide
private theorem copy4_checked : embeddedCheck NF192.Emitter.Literal.seq167 2913 2920 = true := by decide
private theorem clear5_checked : embeddedCheck NF192.Emitter.Literal.seq199 2922 2924 = true := by decide
private theorem push5_checked : embeddedCheck NF192.Emitter.Literal.seq121 2925 2951 = true := by decide
private theorem unpair2_checked : embeddedCheck NF192.Emitter.Literal.seq160 2957 2968 = true := by decide
private theorem pop5_checked : embeddedCheck NF192.Emitter.Literal.seq207 2968 0 = true := by decide

private theorem actual_2924 : actual 2924 = .dec 4 2951 2925 :=
  by decide
private theorem actual_2904 : actual 2904 = .dec 6 2911 2905 := by decide
private theorem actual_2905 : actual 2905 = .dec 5 2907 2906 := by decide
private theorem actual_2906 : actual 2906 = .jump 2904 := by decide
private theorem actual_2907 : actual 2907 = .inc 5 2908 := by decide
private theorem actual_2911 : actual 2911 = .dec 5 2913 2912 := by decide
private theorem actual_2912 : actual 2912 = .jump 2920 := by decide

/-- This prefix constructs the *numerical implication* from TOP and parameter,
restores the original stack, and moves the implication into register 6. -/
private theorem mp_prefix (n t sp c d h input : Nat) :
    Reaches actual ⟨2850,mk9 n t sp c d h 0 0 input⟩
      (some ⟨2904,mk9 n 0 sp c d h (imp t d) 0 input⟩) := by
  have h1 := block_run push4_checked (seq166_normal n t sp c d h input)
  have h2 := block_run imp_checked (seq119_normal n d (pair t sp) c d h input)
  simp only [Cantor.unpair_pair] at h2
  have h3 := block_run move16_checked (seq216_eval n (imp t d) sp c d h 0 0 input)
  simp only [Nat.zero_add] at h3
  exact (h1.trans h2).trans h3

/-- Absolute difference defined by stripping one unit from both registers. -/
def residual : Nat → Nat → Nat
  | 0, y => y
  | x+1, 0 => x+1
  | x+1, y+1 => residual x y

private theorem residual_zero (a b : Nat) : residual a b = 0 ↔ a = b := by
  induction a generalizing b with
  | zero => simp [residual, eq_comm]
  | succ a ih =>
    cases b with
    | zero => simp [residual]
    | succ b => simp only [residual, Nat.succ.injEq, ih]

/-- The 7-slot comparator runs on all two-register inputs, leaving their
absolute difference in CACHE and clearing scratch 6. -/
private theorem compare_all (n sp c d input a b : Nat) :
    Reaches actual ⟨2904,mk9 n 0 sp c d b a 0 input⟩
      (some ⟨2911,mk9 n 0 sp c d (residual a b) 0 0 input⟩) := by
  induction a generalizing b with
  | zero =>
    apply Reaches.one
    simp [NF192.Emitter.step, actual_2904, residual]
  | succ a ih =>
    have first : Reaches actual ⟨2904,mk9 n 0 sp c d b (a+1) 0 input⟩
        (some ⟨2905,mk9 n 0 sp c d b a 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step, actual_2904]
    cases b with
    | zero =>
      have second : Reaches actual ⟨2905,mk9 n 0 sp c d 0 a 0 input⟩
          (some ⟨2907,mk9 n 0 sp c d 0 a 0 input⟩) := by
        apply Reaches.one
        simp [NF192.Emitter.step,actual_2905]
      have third : Reaches actual ⟨2907,mk9 n 0 sp c d 0 a 0 input⟩
          (some ⟨2908,mk9 n 0 sp c d 1 a 0 input⟩) := by
        apply Reaches.one
        simp [NF192.Emitter.step,actual_2907,Registers.add]
      have fourth := block_run move65_checked (seq207_eval n 0 sp c d 1 a 0 input)
      simpa only [residual,Nat.add_comm 1 a] using (((first.trans second).trans third).trans fourth)
    | succ b =>
      have second : Reaches actual ⟨2905,mk9 n 0 sp c d (b+1) a 0 input⟩
          (some ⟨2906,mk9 n 0 sp c d b a 0 input⟩) := by
        apply Reaches.one
        simp [NF192.Emitter.step,actual_2905]
      have third : Reaches actual ⟨2906,mk9 n 0 sp c d b a 0 input⟩
          (some ⟨2904,mk9 n 0 sp c d b a 0 input⟩) := by
        apply Reaches.one
        simp [NF192.Emitter.step,actual_2906]
      exact ((first.trans second).trans third).trans (ih b)

private theorem clear4_checked : embeddedCheck NF192.Emitter.Literal.seq224 2920 2922 = true := by decide

private theorem cleanup (n t sp c d h input : Nat) :
    Reaches actual ⟨2920,mk9 n t sp c d h 0 0 input⟩ (some ⟨2924,mk9 n t sp c 0 0 0 0 input⟩) := by
  have a := block_run clear4_checked (seq224_eval n t sp c d h 0 0 input)
  have b := block_run clear5_checked (seq199_eval n t sp c 0 h 0 0 input)
  exact a.trans b

private theorem mp_suffix (n sp c d input h : Nat) :
    Reaches actual ⟨2911,mk9 n 0 sp c d h 0 0 input⟩
      (some ⟨2924,mk9 n (if h = 0 then d else 0) sp c 0 0 0 0 input⟩) := by
  cases h with
  | zero =>
    have a : Reaches actual ⟨2911,mk9 n 0 sp c d 0 0 0 input⟩
        (some ⟨2913,mk9 n 0 sp c d 0 0 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step, actual_2911]
    have b : Eval NF192.Emitter.Literal.seq167 (mk9 n 0 sp c d 0 0 0 input) .normal
        (mk9 n d sp c d 0 0 0 input) := by
      have h1 := seq198_eval n 0 sp c d 0 0 0 input
      have h2 := seq205_eval n d sp c 0 0 d 0 input
      simp only [Nat.zero_add] at h1 h2
      exact Eval.seq_normal h1 h2
    exact (a.trans (block_run copy4_checked b)).trans
      (cleanup n d sp c d 0 input)
  | succ k =>
    have a : Reaches actual ⟨2911,mk9 n 0 sp c d (k+1) 0 0 input⟩
        (some ⟨2912,mk9 n 0 sp c d k 0 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step,actual_2911]
    have b : Reaches actual ⟨2912,mk9 n 0 sp c d k 0 0 input⟩
        (some ⟨2920,mk9 n 0 sp c d k 0 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step,actual_2912]
    exact (a.trans b).trans (cleanup n 0 sp c d k input)

/-- Literal MP (ordinal 2850) preserves the parameter on both branches,
clears cache, and succeeds exactly on the encoded implication. -/
theorem mp_to_mode (n t sp c d h input : Nat) :
    Reaches actual ⟨2850,mk9 n t sp c d h 0 0 input⟩
      (some ⟨2924,mk9 n (if h = imp t d then d else 0) sp c 0 0 0 0 input⟩) := by
  have h₁ := mp_prefix n t sp c d h input
  have h₂ := compare_all n sp c d input (imp t d) h
  have h₃ := mp_suffix n sp c d input (residual (imp t d) h)
  have k := (h₁.trans h₂).trans h₃
  rw [show (if residual (imp t d) h = 0 then d else 0) =
      (if h = imp t d then d else 0) by
        by_cases e : h = imp t d
        · simp only [ite_eq_left e, ite_eq_left ((residual_zero _ _).2 e.symm)]
        · simp only [ite_eq_right e, ite_eq_right (fun hz => e ((residual_zero _ _).1 hz).symm)]] at k
  exact k

private theorem pop_run (n t sp c d input : Nat) :
    Reaches actual ⟨2957,mk9 n t sp c d 0 0 0 input⟩
      (some ⟨0,mk9 n t (Cantor.unpair sp).2 c d (Cantor.unpair sp).1 0 0 input⟩) := by
  have first := block_run unpair2_checked (seq160_normal n t sp c d 0 input)
  have second := block_run pop5_checked
    (seq207_eval n t (Cantor.unpair sp).2 c d 0 (Cantor.unpair sp).1 0 input)
  simp only [Nat.zero_add] at second
  exact first.trans second

private theorem frame_goalConfig (pc n t sp c d h h' input : Nat) :
    Source.goalConfig pc h' (liftRegisters (mk9 n t sp c d h 0 0 input)) =
      frame pc n t sp c d h' 0 0 input := by
  unfold Source.goalConfig frame
  rw [show Source.setReg (liftRegisters (mk9 n t sp c d h 0 0 input)) 5 h' =
      liftRegisters ((mk9 n t sp c d h 0 0 input).set 5 h') from
        liftRegisters_set (mk9 n t sp c d h 0 0 input) 5 h']
  rw [mk9_set_5]

/-- NIP tests the incoming cache and, on survival, pops even an empty
Cantor stack according to its zero convention. -/
theorem nip_correct (n t sp c d h input : Nat) :
    Visits (frame 2951 n t sp c d h 0 0 input)
      (if h = goal then Source.Config.halted
       else frame 0 n t (Cantor.unpair sp).2 c d (Cantor.unpair sp).1 0 0 input) := by
  have count := Raw.countdown_correct h (liftRegisters (mk9 n t sp c d h 0 0 input))
  rw [frame_goalConfig, frame_goalConfig] at count
  have pos : 0 < Source.countdownDuration h := by
    cases h with | zero => decide | succ h =>
      cases h with | zero => decide | succ h =>
        cases h with | zero => decide | succ h =>
          cases h <;> simp [Source.countdownDuration] <;> omega
  by_cases hit : h = goal
  · rw [ite_eq_left hit]
    exact ⟨_,pos,by simpa only [ite_eq_left (hit.trans goal_is_three)] using count⟩
  · rw [ite_eq_right hit]
    have hn : h ≠ 3 := fun eq => hit (eq.trans goal_is_three.symm)
    have k : Visits (frame 2951 n t sp c d h 0 0 input) (frame 2957 n t sp c d 0 0 0 input) :=
      ⟨_,pos,by simpa only [ite_eq_right hn] using count⟩
    exact k.trans (toVisits (pop_run n t sp c d input))

/-- MODE has precisely the deterministic NIP/SWAP semantics at *every*
natural parameter, including proposed words with mode values greater than one. -/
theorem mode_correct (n t sp c param cache input : Nat) :
    Visits (frame 2924 n t sp c param cache 0 0 input)
      (if cache = goal then Source.Config.halted else
       match param with
       | 0 => frame 0 n t (Cantor.unpair sp).2 c 0 (Cantor.unpair sp).1 0 0 input
       | p+1 => frame 0 n cache sp c p t 0 0 input) := by
  cases param with
  | zero =>
    have entry : Reaches actual ⟨2924,mk9 n t sp c 0 cache 0 0 input⟩
        (some ⟨2951,mk9 n t sp c 0 cache 0 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step,actual_2924]
    exact (toVisits entry).trans (nip_correct n t sp c 0 cache input)
  | succ p =>
    have entry : Reaches actual ⟨2924,mk9 n t sp c (p+1) cache 0 0 input⟩
        (some ⟨2925,mk9 n t sp c p cache 0 0 input⟩) := by
      apply Reaches.one
      simp [NF192.Emitter.step,actual_2924]
    have push := block_run push5_checked (seq121_normal n t sp c p cache input)
    have clear := nip_correct n cache (pair t sp) c p cache input
    rw [Cantor.unpair_pair] at clear
    exact (toVisits (entry.trans push)).trans clear

/-- The unconditional fall-through observes the cleared cache and pops the saved stack. -/
theorem mp_correct (n t sp c d h input : Nat) :
    Visits (frame 2850 n t sp c d h 0 0 input)
      (frame 0 n (if h = imp t d then d else 0) (Cantor.unpair sp).2 c 0 (Cantor.unpair sp).1 0 0 input) := by
  have cleanup := toVisits (mp_to_mode n t sp c d h input)
  have finish := mode_correct n (if h = imp t d then d else 0) sp c 0 0 input
  change Visits (frame 2850 n t sp c d h 0 0 input) (frame 2924 n (if h = imp t d then d else 0) sp c 0 0 0 0 input) at cleanup
  simp only [goal_is_three, show (0 = 3) = False by decide, ite_false] at finish
  exact cleanup.trans finish

end Moving184.Register
#print axioms Moving184.Register.mp_correct
#print axioms Moving184.Register.mode_correct
