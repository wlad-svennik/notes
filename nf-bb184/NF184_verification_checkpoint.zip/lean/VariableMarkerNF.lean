import DataMarker
import MarkerSignature
open FFL FFL.FirstOrder FFL.FirstOrder.SetTheory
open Classical
namespace VariableMarkerNF
open NFFn NFFn.NF188Finite NF196.Compact
open DirectTranslation
theorem in_model (V : Type) [SetStructure V] [Nonempty V] [hT : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙] :
    Nonempty (Marked V) := by
  let A : NF188.Relabel.Basis V := oldBasis
  let B := A.B
  obtain ⟨d,hd⟩ := NF188.Pure.four_labels V
  have ds : d 0≠d 1 := fun e => (by decide : (0 : Fin 4)≠1) (hd e)
  obtain ⟨U,hU⟩ := DataMarker.exists_tester (d 0) (d 1)
  obtain ⟨j,hj⟩ := selector U B
  have tested (x y : V) := ((hU (A.K x) _).mp (oldApp_spec U _) y _).mp (oldApp_spec (oldApp U (A.K x)) y)
  have ka (x y : V) : AppR (A.K x) y y ↔ x=y := by
    rw [oldApp_iff]; change A.app (A.K x) y=y ↔ x=y; rw [A.k_app]
  have chooses (x : V) : A.app j (A.K x) = oldApp U (A.K x) := by
    apply (oldApp_iff _ _ _).mp
    exact (hj _ _).mpr (Or.inl ⟨⟨x,oldK_spec x⟩,oldApp_spec _ _⟩)
  have on (x : V) : A.app (A.app j (A.K x)) x ≠ x := by
    rw [chooses]
    intro he
    have v := ((tested x x).resolve_right (fun z => z.1 ((ka x x).mpr rfl))).2
    rcases v with ⟨e,k⟩|⟨e,k⟩
    · exact ds (e.symm.trans (he.symm.trans k))
    · exact e (he.symm.trans k)
  have off (x y : V) (ne : x≠y) : A.app (A.app j (A.K x)) y=x := by
    rw [chooses]
    have v := ((tested x y).resolve_left (fun z => ne ((ka x y).mp z.1))).2
    have k := (oldApp_iff _ _ _).mp v
    exact k.symm.trans (A.k_app x y)
  have j_nc : ¬ IsConstant j := by
    rintro ⟨v,h⟩
    have hjK (x : V) : A.app j (A.K x)=v := (h _ _).mp (oldApp_spec j _)
    have fa := off (d 0) (d 2) (fun e => (by decide : (0:Fin 4) ≠ 2) (hd e))
    have fb := off (d 1) (d 2) (fun e => (by decide : (1:Fin 4) ≠ 2) (hd e))
    rw [hjK] at fa fb
    exact ds (fa.symm.trans fb)
  have fallback (f : V) (n : ¬IsConstant f) : A.app j f=B :=
    (oldApp_iff _ _ _).mp ((hj f B).mpr (Or.inr ⟨n,rfl⟩))
  let i := NF188.Relabel.Syntax.val A B (fun _ => B) NF188.Relabel.Syntax.idT
  have idlaw (x : V) : A.app i x=x := by
    simp only [i,NF188.Relabel.Syntax.idT,NF188.Relabel.Syntax.con,NF188.Relabel.Syntax.val,
      NF188.Relabel.Syntax.kpow,NF188.Relabel.Syntax.valAtom,A.b_app,A.k_app]
  have i_nc : ¬IsConstant i := by
    rintro ⟨v,h⟩
    have k (x : V) : x=v := (idlaw x).symm.trans ((h _ _).mp (oldApp_spec i x))
    exact ds ((k _).trans (k _).symm)
  have bi : A.app B i=A.K i := by
    apply A.ext; intro f; rw [A.k_app]
    apply A.ext; intro x
    simp only [B,A.b_app,idlaw,A.k_app]
  have b_nonconst (v : V) : B≠A.K v := by
    intro e
    have fix (x : V) : A.app B (A.K (A.K x))=A.K (A.K x) := by
      apply A.ext; intro y; apply A.ext; intro z
      simp only [B,A.b_app,A.k_app]
    have same (x : V) : v=A.K (A.K x) := by simpa only [e,A.k_app] using fix x
    have both := congrArg (fun z => A.app (A.app z B) B) ((same (d 0)).symm.trans (same (d 1)))
    exact ds (by simpa only [A.k_app] using both)
  have bj : B≠j := by
    intro e
    apply b_nonconst i
    exact (fallback i i_nc).symm.trans (by rw [← e]; exact bi)
  exact ⟨{
    toBasis := A
    J := j
    letter := fallback j j_nc
    proper := bj
    off := off
    on := on }⟩

theorem of_consistent (h : Entailment.Consistent 𝗡𝗙) : ∃ V : Type, Nonempty (Marked V) := by
  by_contra no
  apply (Entailment.consistent_iff_unprovable_bot.mp h)
  apply SetTheory.complete.{0}
  intro V _ _ _
  exact (no ⟨V,in_model V⟩).elim
end VariableMarkerNF
#print axioms VariableMarkerNF.of_consistent
