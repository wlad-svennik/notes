import Moving184RegisterAX
import Moving184Search
import NumericalAXBatches
import SourceRoundtrip
import C201Logic
import C201Model

set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Moving184.Register
open Moving184
open NF192 NF192.Numerical NF192.Emitter NF192.Emitter.Registers NF192.SourceFields
open NF192.ProofSearch (Command pack pop_pack candidate candidate_prefix candidate_ne_nil)
def boundary (s : StreamState) : Source.Config :=
  frame 0 (s.next-1) s.proof.top (pack s.proof.stack) 0 s.proof.param s.proof.cache 0 0 s.cursor

def embed : Option StreamState → Source.Config
  | none => Source.Config.halted
  | some s => boundary s

def Valid : Option StreamState → Prop
  | none => True
  | some s => 0 < s.next

theorem valid_step {s : StreamState} (hs : 0 < s.next) : Valid (streamStep s) := by
  simp only [streamStep]
  generalize one _ s.proof = out
  cases out with
  | none => trivial
  | some t =>
    change 0 < (if s.cursor = 0 then s.next + 1 else s.next)
    split <;> omega

theorem halted_absorbing (ticks : Nat) : Raw.advance ticks Source.Config.halted = Source.Config.halted := by
  induction ticks with
  | zero => rfl
  | succ k ih => exact ih

/-- Every source command has positive duration on both checked outcomes. -/
def StepSimulation : Prop :=
  ∀ s : StreamState, 0 < s.next → Visits (boundary s) (embed (streamStep s))

theorem realize_run (oneCmd : StepSimulation) (k : Nat) (s : StreamState) (hs : 0 < s.next) :
    ∃ ticks, k ≤ ticks ∧ Raw.advance ticks (boundary s) = embed (streamRun k s) := by
  induction k generalizing s with
  | zero => exact ⟨0,Nat.le_refl 0,rfl⟩
  | succ k ih =>
    obtain ⟨ticks,pos,hr⟩ := oneCmd s hs
    cases he : streamStep s with
    | none =>
      rw [he] at hr
      refine ⟨ticks+k, by omega, ?_⟩
      rw [Raw.advance_add, hr]
      exact halted_absorbing k
        |>.trans (by simp only [streamRun, he, Option.bind_none]; rfl)
    | some t =>
      have ht : 0 < t.next := by
        have := valid_step hs
        simpa only [he, Valid] using this
      obtain ⟨tail, htail, hres⟩ := ih t ht
      refine ⟨ticks+tail, by omega, ?_⟩
      rw [Raw.advance_add, hr, he]
      simpa only [streamRun, he, Option.bind_some, embed] using hres

/-- The converse covers a halt at an arbitrary instruction tick. Reaching at
least that many literal ticks forces the abstract command execution to have
observed the absorbing halt too. -/
theorem source_halts_iff_stream (oneCmd : StepSimulation) (s : StreamState) (hs : 0 < s.next) :
    (∃ ticks, Raw.advance ticks (boundary s) = Source.Config.halted) ↔
    (∃ k, streamRun k s = none) := by
  constructor
  · rintro ⟨ticks,halt⟩
    obtain ⟨dt,hle,hr⟩ := realize_run oneCmd ticks s hs
    have large : Raw.advance dt (boundary s) = Source.Config.halted := by
      rw [show dt = ticks+(dt-ticks) by omega, Raw.advance_add, halt, halted_absorbing]
    rw [large] at hr
    refine ⟨ticks,?_⟩
    cases he : streamRun ticks s with
    | none => rfl
    | some out =>
      rw [he] at hr
      cases hr
  · rintro ⟨k,hk⟩
    obtain ⟨ticks,_,hr⟩ := realize_run oneCmd k s hs
    exact ⟨ticks,by simpa only [hk,embed] using hr⟩

theorem source_halts_iff_goal (oneCmd : StepSimulation) (n : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, Raw.advance ticks (boundary ⟨n+1,0,s⟩) = Source.Config.halted) ↔
    Moving184.Deriv Numerical.goal :=
  (source_halts_iff_stream oneCmd ⟨n+1,0,s⟩ (Nat.zero_lt_succ n)).trans
    (stream_halting_iff_goal (n+1) s hs)
def registers (n cursor : Nat) (s : State) : Frame :=
  ⟨n,s.top,pack s.stack,0,s.param,s.cache,cursor⟩

def after (n cursor : Nat) : Option State → Source.Config
  | none => Source.Config.halted
  | some s => atFrame 0 (registers n cursor s)

theorem selected_mode (n d tail : Nat) (s : State) :
    Moves (atFrame 2850 ⟨n,s.top,pack s.stack,0,s.param+d,s.cache,tail⟩)
      (after n tail (one (.mode d) s)) := by
  have k := mp_correct n s.top (pack s.stack) 0 (s.param+d) s.cache tail
  rw [pop_pack] at k
  exact k

theorem selected_mp (n d tail : Nat) (s : State) :
    Moves (atFrame 2924 ⟨n,s.top,pack s.stack,0,s.param+d,s.cache,tail⟩)
      (after n tail (one (.mp d) s)) := by
  have hm := mode_correct n s.top (pack s.stack) 0 (s.param+d) s.cache tail
  rw [pop_pack] at hm
  by_cases hit : s.cache = goal
  · simpa only [hit, one, observes, beq_self_eq_true, ite_true, after, ite_eq_left, atFrame, frame, Frame.regs, Visits] using hm
  · have nohit : (s.cache == goal) = false := beq_eq_false_iff_ne.mpr hit
    cases hn : s.param+d with
    | zero => simpa only [one, observes, nohit, Bool.false_eq_true, ite_false, after, Moving184.step, hn,
        ite_eq_right hit, registers, atFrame, frame, Frame.regs] using hm
    | succ k => simpa only [one, observes, nohit, Bool.false_eq_true, ite_false, after, Moving184.step, hn,
        ite_eq_right hit, registers, atFrame, frame, Frame.regs] using hm

/-- All the AX batches, their loop branches, and the automatic final NIP. -/
def AxSimulation : Prop := ∀ (n u b d tail : Nat) (rest : List (Nat × Nat)) (s : State),
  Moves (atFrame 40 ⟨n,s.top,pack s.stack,rest.length,s.param+u,s.cache,
              encodeBatch (b,d) (encodeBatches rest tail)⟩)
    (after n tail (one (.ax u b d rest) s))

theorem command_encoded (ax : AxSimulation) (n : Nat) (c : Command)
    (tail : Nat) (s : State) :
    Moves (atFrame 10 (registers n (assemble c tail) s)) (after n tail (one c s)) := by
  cases c with
  | mp d =>
    have rd := outer_read_fields n s.top (pack s.stack) 0 s.param s.cache 0 d tail
    exact (rd.trans (dispatch_mp _ _ _ _ _ _)).trans (selected_mp n d tail s)
  | mode d =>
    have rd := outer_read_fields n s.top (pack s.stack) 0 s.param s.cache 1 d tail
    exact ((rd.trans (dispatch_positive _ _ _ 0 _ _ _)).trans (mode_entry _ _ _ _ _ _)).trans
      (selected_mode n d tail s)
  | ax u b d rest =>
    have rd := outer_read_fields n s.top (pack s.stack) 0 s.param s.cache (rest.length+2) u
      (encodeBatch (b,d) (encodeBatches rest tail))
    rw [Nat.zero_add] at rd
    exact ((rd.trans (dispatch_positive _ _ _ (rest.length+1) _ _ _)).trans
      (ax_entry _ _ _ rest.length _ _ _)).trans (ax n u b d tail rest s)

theorem command_arbitrary (ax : AxSimulation) (n raw : Nat) (s : State) :
    Moves (atFrame 10 (registers n raw s)) (after n (parse raw).2 (one (parse raw).1 s)) := by
  have h := command_encoded ax n (parse raw).1 (parse raw).2 s
  rwa [assemble_parse] at h

theorem after_embed (n cursor : Nat) (res : Option State) :
    after n cursor res = embed (res.map (fun s => (⟨n+1,cursor,s⟩ : StreamState))) := by
  cases res <;> rfl

theorem step_simulation (ax : AxSimulation) : StepSimulation := by
  rintro ⟨next,cursor,s⟩ hn
  cases next with
  | zero => contradiction
  | succ n =>
    cases cursor with
    | zero =>
      have ref := outer_fresh n s.top (pack s.stack) 0 s.param s.cache
      have act := command_arbitrary ax (n+1) (n+1) s
      rw [after_embed] at act
      exact ref.trans act
    | succ k =>
      have ref := outer_continued n s.top (pack s.stack) 0 s.param s.cache k
      have act := command_arbitrary ax n k s
      rw [after_embed] at act
      exact ref.trans act
theorem selected_ax : AxSimulation := by
  intro n u b d tail rest s
  exact ax_command batch_embedded n u b d rest tail s

theorem literal_step : StepSimulation := step_simulation selected_ax

theorem command_boundary_halts_iff (n : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, Raw.advance ticks (boundary ⟨n+1,0,s⟩) = Source.Config.halted) ↔ Moving184.Deriv goal :=
  source_halts_iff_goal literal_step n s hs

/-- Starting in a continued candidate also suffices. Either it already observes
the goal, or its finite tail reaches the next ordinary refill. -/
theorem stream_halts_any_cursor (next cursor : Nat) (s : State) (hs : s.Sound) :
    (∃ k, streamRun k ⟨next,cursor,s⟩ = none) ↔ Moving184.Deriv goal := by
  constructor
  · rintro ⟨k,hk⟩
    have h := stream_run_sound k ⟨next,cursor,s⟩ hs
    simpa only [hk,StreamSound] using h
  · intro d
    cases cursor with
    | zero => exact (stream_halting_iff_goal next s hs).2 d
    | succ p =>
      let k := (candidate p).length
      have hc := stream_candidate p next s
      cases he : checkedRun (candidate p) s with
      | none =>
        exact ⟨k, by simpa only [he, Option.map_none] using hc⟩
      | some t =>
        have ht : streamRun k ⟨next,p+1,s⟩ = some ⟨next,0,t⟩ := by
          simpa only [he,Option.map_some] using hc
        have sound : t.Sound := by
          have h := stream_run_sound k ⟨next,p+1,s⟩ hs
          simpa only [ht,StreamSound] using h
        obtain ⟨ticks,done⟩ := (stream_halting_iff_goal next t sound).2 d
        exact ⟨k+ticks,by rw [stream_run_add, ht]; exact done⟩

/-- Every physically representable sound command boundary, regardless of its
register-zero counter, context stack, cache, parameter or residual cursor. -/
theorem literal_source_iff_goal (n cursor : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, Raw.advance ticks (atFrame 0 (registers n cursor s)) = Source.Config.halted) ↔
    Moving184.Deriv goal :=
  (source_halts_iff_stream literal_step ⟨n+1,cursor,s⟩ (Nat.zero_lt_succ n)).trans
    (stream_halts_any_cursor (n+1) cursor s hs)

def emptyState : State := ⟨0,[],0,0⟩

theorem empty_sound : emptyState.Sound := ⟨Moving184.deriv_zero, by simp [emptyState], Moving184.deriv_zero⟩

theorem literal_zero_iff_goal :
    (∃ ticks, Raw.advance ticks (atFrame 0 (registers 0 0 emptyState)) = Source.Config.halted) ↔
    Moving184.Deriv goal := literal_source_iff_goal 0 0 emptyState empty_sound

end Moving184.Register
#print axioms Moving184.Register.literal_source_iff_goal
