module
public import Eight187Search
public import Mathlib.Tactic.Ring
public import Mathlib.Tactic.Linarith
@[expose] public section
namespace ProgressionEnumeration
open NF192.Numerical NF192.SourceFields NF192.ProofSearch

private theorem triangular_even (z : Nat) : (2*z)*(2*z+1)/2 = z*(2*z+1) := by
  rw [show (2*z)*(2*z+1)=z*(2*z+1)*2 by ring, Nat.mul_div_cancel _ (by decide : 0<2)]
private theorem triangular_odd (z : Nat) : (2*z+1)*(2*z+1+1)/2 = z*(2*z+3)+1 := by
  rw [show (2*z+1)*(2*z+1+1)=(z*(2*z+3)+1)*2 by ring, Nat.mul_div_cancel _ (by decide : 0<2)]

/-- Selecting the freely chosen left field lets a Cantor pair keep the right
field unchanged modulo m, or add one to it. -/
private theorem pair_choice (m t : Nat) (hm : 0<m) (e : Nat) (he : e ≤ 1) :
    ∃ v k, pair v t = t+e+m*k := by
  let z := m*(t+1)
  have hzt : t ≤ 2*z := by dsimp [z]; nlinarith
  refine ⟨2*z-t+e,?_⟩
  have hs : 2*z-t+e+t = 2*z+e := by omega
  unfold pair; rw [hs]
  rcases Nat.eq_zero_or_pos e with rfl|h
  · refine ⟨(t+1)*(2*z+1),?_⟩
    rw [Nat.add_zero, triangular_even]; dsimp [z]; ring
  · have eq : e=1 := by omega
    subst e; refine ⟨(t+1)*(2*z+3),?_⟩
    rw [triangular_odd]; dsimp [z]; ring

private theorem so_many (m t n k : Nat) (hm : 0<m) (hk : k ≤ n) :
    ∃ bs : List (Nat × Nat), bs.length = n ∧ ∃ q, encodeBatches bs t = t+k+m*q := by
  induction n generalizing k with
  | zero =>
    have hh : k=0 := by omega
    exact ⟨[],rfl,0,by simp [encodeBatches,hh]⟩
  | succ n ih =>
    let b := min 1 k
    have hb : b ≤ 1 := Nat.min_le_left ..
    have hbk : b ≤ k := Nat.min_le_right ..
    have hkn : k-b ≤ n := by dsimp [b]; omega
    obtain ⟨bs,hlen,q,hq⟩ := ih (k-b) hkn
    obtain ⟨v,r,hr⟩ := pair_choice m (encodeBatches bs t) hm b hb
    obtain ⟨w,s,hs⟩ := pair_choice m (pair v (encodeBatches bs t)) hm 0 (by decide)
    refine ⟨(w,v)::bs,by simp [hlen],q+r+s,?_⟩
    change pair w (pair v (encodeBatches bs t)) = _
    rw [hs,hr,hq]; simp only [Nat.mul_add]; omega

/-- An arithmetic progression of candidate indices with any positive step
contains a word beginning with one AX command followed by any prescribed
finite list of commands. The proof state after that AX can be arbitrary. -/
theorem cofinal_progression (cs : List Command) (m residue bound : Nat) (hm : 0<m) :
    ∃ input u b d rest tail, bound < input ∧ input % m = residue % m ∧
      Matches (.ax u b d rest :: cs) input tail := by
  let t := encode cs (bound+1)+1
  let M := 2*m
  have hM : 0<M := by dsimp [M]; omega
  let a := residue % M
  have ha : a < M := Nat.mod_lt _ hM
  have ht : t % M < M := Nat.mod_lt _ hM
  let tag := 3*M + (M-a)
  let L := tag-2
  let k := a+M - (t%M)
  have hk : k ≤ L := by dsimp [k,L,tag,M] at *; omega
  obtain ⟨bs,hlen,q,hq⟩ := so_many M t L k hM hk
  obtain ⟨d,i,hi⟩ := pair_choice M (encodeBatches bs t) hM 0 (by decide)
  obtain ⟨b,j,hj⟩ := pair_choice M (pair d (encodeBatches bs t)) hM 0 (by decide)
  obtain ⟨u,l,hl⟩ := pair_choice M (pair b (pair d (encodeBatches bs t))) hM 0 (by decide)
  let y := pair u (pair b (pair d (encodeBatches bs t)))
  let big := t/M + 1 + q+i+j+l
  have hst : t+k = a+M*(t/M+1) := by
    have h := Nat.mod_add_div t M
    dsimp [k]; rw [Nat.mul_add,Nat.mul_one]; omega
  have hy : y=a+M*big := by
    dsimp [y,big]; rw [hl,hj,hi,hq]; simp only [Nat.add_zero,Nat.mul_add,Nat.mul_one] at *; omega
  have htag : bs.length+2=tag := by rw [hlen]; dsimp [L,tag,M] at *; omega
  have hu : tag+a=4*M := by dsimp [tag]; omega
  have hsum : tag+y=2*(m*(4+big)) := by rw [hy,← Nat.add_assoc,hu]; dsimp [M]; ring
  have pairformula : pair tag y = y + m*((4+big)*(2*(m*(4+big))+1)) := by
    unfold pair; rw [hsum,triangular_even]; ring
  let c := Command.ax u b d bs
  refine ⟨encode (c::cs) (bound+1),u,b,d,bs,bound+1,tail_le_encoding _ _,?_,matches_encoding (c::cs) _⟩
  change pair (bs.length+2) y %m = residue%m
  rw [htag,pairformula, Nat.add_mul_mod_self_left,hy]
  have key : M*big= (2*big)*m := by dsimp [M]; ring
  rw [key,Nat.add_mul_mod_self_right]
  exact Nat.mod_mul_left_mod residue 2 m
end ProgressionEnumeration
#print axioms ProgressionEnumeration.cofinal_progression
