import Moving184Margin
import Moving186NF
namespace Moving184.Register
open NF192 NF192.Emitter FFL FFL.FirstOrder
theorem signed_halts_iff_nf_refutation :
    BootstrapHalts (true,liftConfig origin) ↔ (𝗡𝗙 ⊢ ⊥) :=
  signed_source_halts_iff_goal.trans Moving186.deriv_goal_iff_nf_refutation
theorem margin_halts_iff_nf_refutation :
    BootstrapHalts (true,liftConfig margin184) ↔ (𝗡𝗙 ⊢ ⊥) :=
  margin_halts_iff_goal.trans Moving186.deriv_goal_iff_nf_refutation
end Moving184.Register
#print axioms Moving184.Register.signed_halts_iff_nf_refutation
#print axioms Moving184.Register.margin_halts_iff_nf_refutation
