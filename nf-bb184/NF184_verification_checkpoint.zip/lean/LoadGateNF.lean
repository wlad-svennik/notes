import LoadGate
import Eight187Exact
namespace LoadGate
open FFL FFL.FirstOrder
theorem scanner_iff_nf_refutation (start : Nat) (s : State) (hs : s.Sound) :
    (∃ t, streamRun t ⟨start,0,s⟩ = none) ↔ (𝗡𝗙 ⊢ ⊥) :=
  (stream_halting_iff_goal start s hs).trans Eight187.deriv_goal_iff_nf_refutation
end LoadGate
#print axioms LoadGate.scanner_iff_nf_refutation
