module
public import FilteredImplication
public import Eight187SearchCore
@[expose] public section
set_option maxRecDepth 8192
set_option maxHeartbeats 8000000
namespace PositiveMinor
open NF192.Numerical NF192.Emitter
open NF192.Numerical.Cantor
inductive Proof : Nat → Prop where
  | row {a b c u x : Nat} : u ≤ a → x ∈ Eight187.rowList a b c u → Proof x
  | mp {x y : Nat} : 0 < x → Proof (imp x y) → Proof x → Proof y

abbrev P := {x : Nat // 0 < x}
private def arr (x y : P) : P := ⟨imp x y, Nat.lt_of_lt_of_le x.property (imp_ge_left ..)⟩
private abbrev Prov (x : P) := Proof x.val
private def L : FilteredImplication.Language P := ⟨arr,fun x y => x.val ≤ y.val,fun _ => Nat.le_refl _,
  fun _ h => Nat.le_trans h (imp_ge_left ..),fun _ h => Nat.le_trans h (imp_ge_right ..)⟩
private theorem mp {a b : P} (h : Prov (arr a b)) (k : Prov a) : Prov b :=
  Proof.mp a.property h k
private theorem rules : FilteredImplication.Restricted L Prov where
  mp := fun p q => mp p q
  rho8 := fun a b c u h => Proof.row (a:=a.val) (b:=b.val) (c:=c.val) (u:=u.val) h (List.mem_cons_self ..)
private theorem ident (a : P) : Prov (arr a a) :=
  mp (mp (FilteredImplication.s rules a (arr a a) a) (FilteredImplication.k rules a (arr a a)))
    (FilteredImplication.k rules a a)
private theorem trans {x y z : P} (p : Prov (arr x y)) (q : Prov (arr y z)) : Prov (arr x z) :=
  mp (mp (FilteredImplication.composition rules x y z) p) q
private def E (x y : P) := Prov (arr x y) ∧ Prov (arr y x)
private def setoid : Setoid P where
  r := E
  iseqv := ⟨fun x => ⟨ident x,ident x⟩, fun h => ⟨h.2,h.1⟩,fun h k => ⟨trans h.1 k.1,trans k.2 h.2⟩⟩
private theorem contra {a b : P} (p : Prov (arr a b)) (c : P) : Prov (arr (arr b c) (arr a c)) :=
  mp (FilteredImplication.composition rules a b c) p
private theorem respects {a b c d : P} (h : E a b) (k : E c d) : E (arr a c) (arr b d) :=
  ⟨trans (contra h.2 c) (FilteredImplication.lift_right rules k.1 b),
   trans (contra h.1 d) (FilteredImplication.lift_right rules k.2 a)⟩
private abbrev Q := Quotient setoid
private def mk (x : P) : Q := Quotient.mk setoid x
private def arrow (x y : Q) : Q :=
  Quotient.liftOn₂ x y (fun a b => mk (arr a b)) (fun _ _ _ _ h k => Quotient.sound (respects h k))
private theorem arrow_mk (x y : P) : arrow (mk x) (mk y) = mk (arr x y) := rfl
private def valid : Q → Prop := Quotient.lift Prov (fun _ _ h => propext ⟨mp h.1,mp h.2⟩)
private theorem applyQ (x y : Q) : valid (arrow x y) → valid x → valid y := by
  induction x using Quotient.inductionOn with | _ a =>
    induction y using Quotient.inductionOn with | _ b => exact mp

private def atomT : P := ⟨row4 0 0, by decide⟩
private theorem topPf : Prov atomT := by
  apply Proof.row (a:=0) (b:=0) (c:=0) (u:=0) (by decide)
  simp [atomT, Eight187.rowList,Eight187.Seed.eight]
private theorem topId : mk atomT = arrow (mk atomT) (mk atomT) := by
  apply Quotient.sound
  exact ⟨FilteredImplication.k rules atomT atomT, mp (FilteredImplication.k rules atomT (arr atomT atomT)) topPf⟩
private def tr (n : Nat) : Q :=
  if z : n = 0 then mk atomT
  else if n % 2 = 1 then mk ⟨n,by omega⟩
  else arrow (tr (unpair (n/2)).1) (tr (unpair (n/2)).2)
termination_by n
decreasing_by
  all_goals first | exact Nat.lt_of_le_of_lt (unpair_left_le _) (by omega) | exact Nat.lt_of_le_of_lt (unpair_right_le _) (by omega)
private theorem tr_eqn (x y : Nat) : tr (eqn x y) = mk ⟨eqn x y, by unfold eqn; omega⟩ := by
  rw [tr]
  simp [eqn]
private theorem tr_imp (x y : Nat) : tr (imp x y) = arrow (tr x) (tr y) := by
  by_cases hz : pair x y = 0
  · obtain ⟨rfl,rfl⟩ := (pair_zero_iff ..).mp hz
    change tr 0 = arrow (tr 0) (tr 0)
    rw [tr]; exact topId
  · rw [tr]
    have nz : 2 * pair x y ≠ 0 := by omega
    simp [imp, nz, unpair_pair]

private theorem rhoQ (a b c u : Q) :
    valid (arrow (arrow (arrow c u) a) (arrow (arrow a c) (arrow b c))) := by
  induction a using Quotient.inductionOn with | _ a =>
    induction b using Quotient.inductionOn with | _ b =>
      induction c using Quotient.inductionOn with | _ c =>
        induction u using Quotient.inductionOn with | _ u =>
          exact FilteredImplication.rho8_all rules a b c u

private theorem soundRow {a b c u x : Nat} (hu : u ≤ a)
    (h : x ∈ Eight187.rowList a b c u) : valid (tr x) := by
  have base : Proof x := Proof.row hu h
  simp only [Eight187.rowList,Eight187.Seed.eight,List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h|h|h|h|h <;> subst x
  · simpa only [row0,tr_imp] using rhoQ (tr a) (tr b) (tr c) (tr u)
  all_goals
    simp only [row4,Eight187.Seed.bRow,row2,row3,row6,Eight187.Seed.test,row9,tr_imp,tr_eqn,arrow_mk]
    exact base

private theorem valid_of_deriv {x : Nat} (h : Eight187.Deriv x) : valid (tr x) := by
  induction h with
  | row hu hr => exact soundRow hu hr
  | @mp a b _ _ ha hb =>
    rw [tr_imp] at ha
    exact applyQ _ _ ha hb

theorem of_equation {a b : Nat} (h : Eight187.Deriv (eqn a b)) : Proof (eqn a b) := by
  have p := valid_of_deriv h
  rw [tr_eqn] at p
  exact p

theorem toDeriv {x : Nat} (h : Proof x) : Eight187.Deriv x := by
  induction h with
  | row hu hr => exact .row hu hr
  | mp hp _ _ p q => exact .mp p q

theorem goal_iff : Proof goal ↔ Eight187.Deriv goal := ⟨toDeriv, of_equation⟩

/-- A derivation in which every axiom and every conclusion is strictly positive. -/
inductive PositiveProof : Nat → Prop where
  | row {a b c u x : Nat} : 0 < x → u ≤ a → x ∈ Eight187.rowList a b c u → PositiveProof x
  | mp {x y : Nat} : 0 < y → PositiveProof (imp x y) → PositiveProof x → PositiveProof y

theorem allPositive {x : Nat} (h : Proof x) (hx : 0 < x) : PositiveProof x := by
  induction h with
  | row hu hr => exact .row hx hu hr
  | @mp a b ha _ _ hm hn => exact .mp hx (hm (Nat.lt_of_lt_of_le ha (imp_ge_left ..))) (hn ha)

theorem PositiveProof.toDeriv {x : Nat} (h : PositiveProof x) : Eight187.Deriv x := by
  induction h with
  | row _ hu hr => exact .row hu hr
  | mp _ _ _ p q => exact .mp p q

theorem all_positive_goal_iff : PositiveProof goal ↔ Eight187.Deriv goal :=
  ⟨PositiveProof.toDeriv, fun h => allPositive (of_equation h) (by decide)⟩

/-- The emitter and modus ponens suffice using only formula codes at least two. -/
inductive AboveOne : Nat → Prop where
  | row {a b c u x : Nat} : 1 < x → u ≤ a → x ∈ Eight187.rowList a b c u → AboveOne x
  | mp {x y : Nat} : 1 < y → AboveOne (imp x y) → AboveOne x → AboveOne y

private theorem imp_big (x y : P) : 1 < imp x y := by
  have h := pair_ge_left x.val y.val
  have hp := x.property
  unfold imp
  omega
private theorem guardedRules : FilteredImplication.Restricted L (fun x => AboveOne x.val) where
  mp := fun {_a b c} p q => AboveOne.mp (imp_big b c) p q
  rho8 := fun a b c u h => AboveOne.row (a:=a.val) (b:=b.val) (c:=c.val) (u:=u.val)
    (imp_big (arr (arr c u) a) (arr (arr a c) (arr b c))) h (List.mem_cons_self ..)

private theorem all_rows_ne_one {a b c u x : Nat} (h : x ∈ Eight187.rowList a b c u) : x ≠ 1 := by
  have himp (v w : Nat) : imp v w ≠ 1 := by unfold imp; omega
  have heq (v w t : Nat) : eqn (app v w) t ≠ 1 := by
    have h := pair_ge_left (app v w) t
    unfold eqn app at *
    omega
  simp only [Eight187.rowList,Eight187.Seed.eight,List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h|h|h|h|h <;> subst x <;> first | exact himp _ _ | exact heq _ _ _

private theorem posOfProof {x : Nat} (h : PositiveProof x) : 0 < x := by
  cases h with | row h _ _ => exact h | mp h _ _ => exact h
private theorem prefixed {x : Nat} (h : PositiveProof x) : AboveOne (imp atomT.val x) := by
  induction h with
  | @row a b c u x pos hu hr =>
      let v : P := ⟨x,pos⟩
      have ne := all_rows_ne_one hr
      exact AboveOne.mp (imp_big atomT v) (FilteredImplication.k guardedRules v atomT)
        (.row (x:=x) (a:=a) (b:=b) (c:=c) (u:=u) (by omega) hu hr)
  | @mp a b pb major minor ihmaj ihmin =>
      let v : P := ⟨a,posOfProof minor⟩
      let w : P := ⟨b,pb⟩
      exact AboveOne.mp (imp_big atomT w)
        (AboveOne.mp (imp_big (arr atomT v) (arr atomT w)) (FilteredImplication.s guardedRules atomT v w) ihmaj) ihmin

private theorem bigTop : AboveOne atomT.val := by
  apply AboveOne.row (a:=0) (b:=0) (c:=0) (u:=0) (by decide) (by decide)
  simp [atomT,Eight187.rowList,Eight187.Seed.eight]

theorem AboveOne.toDeriv {x : Nat} (h : AboveOne x) : Eight187.Deriv x := by
  induction h with
  | row _ hu hr => exact .row hu hr
  | mp _ _ _ p q => exact .mp p q

theorem above_one_goal_iff : AboveOne goal ↔ Eight187.Deriv goal :=
  ⟨AboveOne.toDeriv, fun h => .mp (by decide) (prefixed (all_positive_goal_iff.mpr h)) bigTop⟩
end PositiveMinor
#print axioms PositiveMinor.goal_iff
#print axioms PositiveMinor.all_positive_goal_iff

#print axioms PositiveMinor.above_one_goal_iff
