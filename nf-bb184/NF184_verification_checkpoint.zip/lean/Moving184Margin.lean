import Moving184Cold


namespace Moving184.Register
open NF192 NF192.Emitter NF192.Emitter.Registers
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def origin : Emitter.Config := ⟨40,mk9 0 0 0 2 0 0 0 0 0⟩
def margin184 : Emitter.Config := ⟨111, mk9 0 0 0 2 0 0 0 1 0⟩
def first184 := Emitter.run frozen 80 origin

theorem frozen_steps184 : first184 = some margin184 := by
  have hp : first184.map Emitter.Config.pc = some margin184.pc := by decide +kernel
  have hr : ∀ i : Fin 9, first184.map (fun c => c.registers i) = some (margin184.registers i) := by
    decide +kernel
  cases h : first184 with
  | none => simp [h] at hp
  | some c =>
    rw [h] at hp
    have reg : c.registers = margin184.registers := by
      funext i
      simpa only [h,Option.map_some,Option.some.injEq] using hr i
    have pc : c.pc = margin184.pc := by simpa only [Option.map_some,Option.some.injEq] using hp
    apply congrArg some
    cases c with
    | mk p rs =>
      change p = 111 at pc
      change rs = _ at reg
      cases pc
      cases reg
      rfl

theorem advance_steps184 : bootstrapAdvance 80 (true,liftConfig origin) = (true,liftConfig margin184) :=
  frozen_run 80 frozen_steps184


end Moving184.Register
#print axioms Moving184.Register.advance_steps184

namespace Moving184.Register
open NF192 NF192.Emitter NF192.Numerical
theorem margin_halts_iff_goal :
    BootstrapHalts (true, liftConfig margin184) ↔ Moving186.Deriv goal :=
  (bootstrap_halts_at advance_steps184).symm.trans signed_source_halts_iff_goal
end Moving184.Register
#print axioms Moving184.Register.margin_halts_iff_goal
