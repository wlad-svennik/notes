import CompactNF
namespace VariableMarkerNF
structure Marked (V : Type) extends NF188.Relabel.Basis V where
  J : V
  letter : app J J=B
  proper : B≠J
  off : ∀ x y, x≠y → app (app J (K x)) y=x
  on : ∀ x, app (app J (K x)) x≠x
end VariableMarkerNF
