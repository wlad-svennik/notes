module
public import FilteredImplication
public import Eight187SearchCore
@[expose] public section

namespace RestrictedConsequences
open NF192.Numerical NF192.Emitter

/-- The predicate restricts only the conclusion of a detachment. Each of the
eight axiom rows remains available with its original parameter bound. -/
inductive Proof (allowed : Nat → Prop) : Nat → Prop where
  | row {a b c u x} : u ≤ a → x ∈ Eight187.rowList a b c u → Proof allowed x
  | mp {x y} : allowed y → Proof allowed (imp x y) → Proof allowed x → Proof allowed y

private def L : FilteredImplication.Language Nat :=
  ⟨imp,(· ≤ ·),Nat.le_refl,fun _ h => Nat.le_trans h (imp_ge_left ..),
    fun _ h => Nat.le_trans h (imp_ge_right ..)⟩

variable {allowed : Nat → Prop}

private theorem rules (ha : ∀ a b, allowed (imp a b)) :
    FilteredImplication.Restricted L (Proof allowed) where
  mp := fun p q => Proof.mp (ha _ _) p q
  rho8 := fun a b c u h => Proof.row (a:=a) (b:=b) (c:=c) (u:=u) h (List.mem_cons_self ..)

theorem transport (ha : ∀ a b, allowed (imp a b)) {x}
    (h : Eight187.Deriv x) : Proof allowed (imp 0 x) := by
  induction h with
  | row hu hx => exact Proof.mp (ha _ _) (FilteredImplication.k (rules ha) _ _) (.row hu hx)
  | @mp a b _ _ hmaj hmin =>
    exact Proof.mp (ha _ _) (Proof.mp (ha _ _) (FilteredImplication.s (rules ha) 0 a b) hmaj) hmin

theorem forget {x} (h : Proof allowed x) : Eight187.Deriv x := by
  induction h with
  | row hu hx => exact .row hu hx
  | mp _ _ _ maj min => exact .mp maj min

theorem iff_of_allowed (ha : ∀ a b, allowed (imp a b)) {x} (hx : allowed x) :
    Proof allowed x ↔ Eight187.Deriv x := by
  have z : Proof allowed 0 := .row (a:=0) (b:=0) (c:=0) (u:=0) (by decide) (List.mem_cons_self ..)
  exact ⟨forget,fun h => Proof.mp hx (transport ha h) z⟩

/-- A scanner may request just the even conclusions of modus ponens if it
looks for formula 18, which is the implication from 0 to the old goal. -/
theorem even_goal : Proof (fun n => n % 2 = 0) 18 ↔ Eight187.Deriv goal := by
  have h18 : imp 0 goal = 18 := by decide
  have hzero : Eight187.Deriv 0 := .row (a:=0) (b:=0) (c:=0) (u:=0) (by decide) (List.mem_cons_self ..)
  rw [← h18]
  exact ⟨fun h => .mp (forget h) hzero, transport (fun a b => by simp [imp])⟩

/-- For a machine that retains the old goal tape, goal is the only odd
conclusion that its detachment instruction need be allowed to produce. -/
theorem even_or_goal : Proof (fun n => n % 2 = 0 ∨ n = goal) goal ↔ Eight187.Deriv goal :=
  iff_of_allowed (fun a b => Or.inl (by simp [imp])) (Or.inr rfl)
end RestrictedConsequences
#print axioms RestrictedConsequences.even_goal
#print axioms RestrictedConsequences.even_or_goal
