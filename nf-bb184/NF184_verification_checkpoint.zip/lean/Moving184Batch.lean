import Moving186Logic
import Eight187Rows
namespace Moving184
open NF192 NF192.Numerical NF192.Emitter SetTheory.BusyBeaver.ZFC
def testTokens : List Macro := [.push0,.push5,.push5,.witness,.ap,.push4,.ap,.push5,.ap,.push0,.push5,.push5,.witness,.ap,.push5,.ap,.push5,.ap,.imp,.push4,.push5,.ap,.imp]
theorem effectTest (n t stack c a b tail : Nat) :
    testTokens.foldl Frame.apply ⟨n,t,stack,c,a,b,tail⟩ =
    ⟨n,Moving186.testRow b a,pair t stack,c,a,b,tail⟩ := by
  simp only [testTokens, List.foldl_cons, List.foldl_nil, Frame.apply, Frame.push,
    Frame.combine,Cantor.unpair_pair,ctor,Moving186.testRow,Moving186.single,s_is_one,q,imp,eqn,app,witness]
  <;> rfl
def suffix : List Macro := C196.logicalTokens ++ tokens4 ++ tokens6 ++ Eight187.Seed.bTokens ++ tokens2 ++ tokens3 ++ testTokens ++ tokens9
def batchCode : Code := sequence .read5 suffix
theorem batch_effect (n t stack c u v y delta tail : Nat) :
    suffix.foldl Frame.apply (Frame.apply ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩ .read5) =
      save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (Moving186.rowList (u+delta) (v+y) c u) := by
  simp only [suffix, List.foldl_append, Frame.apply, Cantor.unpair_pair]
  rw [C196.logicalEffect, effect4, effect6, Eight187.Seed.effectB, effect2, effect3, effectTest, effect9]
  rfl
theorem batch_eval (n t stack c u v y delta tail : Nat) :
    Eval batchCode (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩) .normal
      (save ⟨n,t,stack,c,u+delta,v+y,tail⟩ (Moving186.rowList (u+delta) (v+y) c u)).regs := by
  rw [← batch_effect n t stack c u v y delta tail]
  exact sequence_eval .read5 suffix _
end Moving184
#print axioms Moving184.batch_eval
