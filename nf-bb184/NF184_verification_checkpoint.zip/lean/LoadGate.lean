module
public import PositiveMinor
public import SourceEnumeration
@[expose] public section
set_option maxRecDepth 4096
set_option maxHeartbeats 8000000
namespace LoadGate
open NF192.Numerical NF192.Emitter
open NF192.ProofSearch (Command)
abbrev lastRow := NF192.Emitter.row9
abbrev rowList := Eight187.Seed.eight
abbrev Deriv := Eight187.Deriv
theorem last_row_split (a b c u : Nat) :
    rowList a b c u = (rowList a b c u).take 7 ++ [lastRow a b] := rfl
theorem deriv_zero : Deriv 0 :=
  .row (a:=0) (b:=0) (c:=0) (u:=0) (by decide) (List.mem_cons_self ..)
structure State where
  top : Nat
  stack : List Nat
  cache : Nat
  param : Nat
def tailRows (a b : Nat) : List (Nat × Nat) → List Nat
  | [] => []
  | (y,d) :: rs => rowList (a+d) (b+y) rs.length a ++ tailRows (a+d) (b+y) rs
def rows (u b δ : Nat) (rest : List (Nat × Nat)) (s : State) : List Nat :=
  let a := s.param+u+δ
  let v := s.cache+b
  rowList a v rest.length (s.param+u) ++ tailRows a v rest
def nip (s : State) : State := ⟨s.top,s.stack.tail,s.stack.headD 0,0⟩
def afterAX (s : State) (zs : List Nat) : State :=
  nip ⟨0,zs.reverse.tail ++ s.top :: s.stack,0,0⟩
def step (cmd : Command) (s : State) : State :=
  match cmd with
  | .mode d => let b := s.param+d; nip ⟨if s.cache = imp s.top b then b else 0,s.stack,0,0⟩
  | .mp d => ⟨if s.top = 0 then s.cache else s.top,s.stack.tail,s.stack.headD 0,s.param+d⟩
  | .ax u b δ rest => afterAX s (rows u b δ rest s)
def observes (cmd : Command) (s : State) : Bool :=
  match cmd with
  | .mp _ => s.top != 0 && s.cache == goal
  | _ => false
def State.Sound (s : State) : Prop :=
  Deriv s.top ∧ (∀ x ∈ s.stack, Deriv x) ∧ Deriv s.cache
theorem imp_last_ne_cache (a b t : Nat) : b ≠ imp (lastRow a b) t := by
  have h1 := pair_ge_right a b
  have h2 := imp_ge_right (eqn (app b (witness a b)) (app a (witness a b))) (eqn a b)
  have h3 := imp_ge_left (lastRow a b) t
  change b ≠ imp (lastRow a b) t
  change _ ≤ lastRow a b at h2
  unfold eqn at h2
  omega
theorem tailRows_sound (a b : Nat) (rest : List (Nat × Nat)) : ∀ x ∈ tailRows a b rest, Deriv x := by
  induction rest generalizing a b with
  | nil => simp [tailRows]
  | cons t rest ih =>
    obtain ⟨y,d⟩ := t
    intro x hx
    rcases List.mem_append.mp hx with h|h
    · exact .row (Nat.le_add_right _ _) h
    · exact ih _ _ _ h
theorem rows_sound (u b d : Nat) (rest : List (Nat × Nat)) (s : State) :
    ∀ x ∈ rows u b d rest s, Deriv x := by
  intro x hx
  rcases List.mem_append.mp hx with h|h
  · exact .row (Nat.le_add_right _ _) h
  · exact tailRows_sound _ _ _ _ h

set_option maxRecDepth 100000
open NF192.ProofSearch (Command candidate candidate_prefix candidate_ne_nil)
open NF192.SourceFields
def run : List Command → State → State
  | [], s => s
  | c :: cs, s => run cs (step c s)

def checkedRun : List Command → State → Option State
  | [], s => some s
  | c :: cs, s => if observes c s then none else checkedRun cs (step c s)

theorem run_append (u v : List Command) (s : State) :
    run (u ++ v) s = run v (run u s) := by
  induction u generalizing s with
  | nil => rfl
  | cons c cs ih => exact ih (step c s)

theorem checkedRun_append (u v : List Command) (s : State) :
    checkedRun (u ++ v) s = (checkedRun u s).bind (checkedRun v) := by
  induction u generalizing s with
  | nil => rfl
  | cons c cs ih =>
    by_cases h : observes c s = true <;> simp [checkedRun, h, ih]

theorem checkedRun_survives {cs : List Command} {s t : State}
    (h : checkedRun cs s = some t) : t = run cs s := by
  induction cs generalizing s with
  | nil => exact (Option.some.inj h).symm
  | cons c cs ih =>
    by_cases e : observes c s = true
    · simp [checkedRun, e] at h
    · exact ih (by simpa [checkedRun, e] using h)

private theorem head_sound {xs : List Nat} (h : ∀ x ∈ xs, Deriv x) :
    Deriv (xs.headD 0) := by
  cases xs with
  | nil => exact deriv_zero
  | cons x xs => exact h x (by simp)

private theorem tail_sound {xs : List Nat} (h : ∀ x ∈ xs, Deriv x) :
    ∀ x ∈ xs.tail, Deriv x := by
  intro x hx
  cases xs with
  | nil => exact False.elim (List.not_mem_nil hx)
  | cons a xs => exact h _ (List.mem_cons_of_mem a hx)

theorem nip_sound (s : State) (h : s.Sound) : (nip s).Sound :=
  ⟨h.1,tail_sound h.2.1,head_sound h.2.1⟩
theorem step_sound (c : Command) (s : State) (h : s.Sound) : (step c s).Sound := by
  obtain ⟨ht,hs,hc⟩ := h
  cases c with
  | mode d =>
    apply nip_sound
    refine ⟨?_,hs,deriv_zero⟩
    change Deriv (if s.cache = imp s.top (s.param+d) then s.param+d else 0)
    split
    next e => exact Eight187.Deriv.mp (e ▸ hc) ht
    next => exact deriv_zero
  | mp d =>
    refine ⟨?_,tail_sound hs,head_sound hs⟩
    change Deriv (if s.top = 0 then s.cache else s.top)
    split <;> assumption
  | ax u b d rs =>
    apply nip_sound
    refine ⟨deriv_zero,?_,deriv_zero⟩
    intro x hx
    rcases List.mem_append.mp hx with hr|hr
    · exact rows_sound _ _ _ _ _ _ (List.mem_reverse.mp (List.mem_of_mem_tail hr))
    · rcases List.mem_cons.mp hr with rfl|h
      · exact ht
      · exact hs x h
theorem detects_only_goal {cs : List Command} {s : State} (hs : s.Sound)
    (h : checkedRun cs s = none) : Deriv goal := by
  induction cs generalizing s with
  | nil => contradiction
  | cons c cs ih =>
    by_cases o : observes c s = true
    · cases c with
      | mode d => simp [observes] at o
      | ax u b d rest => simp [observes] at o
      | mp d =>
        have e : s.cache = goal := by simpa [observes] using (show s.cache = goal from (by simpa [observes] using o : s.top ≠ 0 ∧ s.cache = goal).2)
        exact e ▸ hs.2.2
    · exact ih (step_sound c s hs) (by simpa [checkedRun, o] using h)




def nips : Nat → List Command
  | 0 => []
  | n+1 => .mp 0 :: nips n
def drops : Nat → List Command
  | 0 => []
  | n+1 => .mode 0 :: drops n

theorem nips_over (pre tail : List Nat) (t c : Nat) (ht : t ≠ 0) :
    ∃ w, run (nips pre.length) ⟨t, pre ++ tail, c, 0⟩ = ⟨t, tail, w, 0⟩ := by
  induction pre generalizing c with
  | nil => exact ⟨c, rfl⟩
  | cons a pre ih => simpa [nips,run,step,nip,ht] using ih a

theorem drops_to (pre tail : List Nat) (t c x : Nat) :
    run (drops (pre.length+1)) ⟨t, pre ++ x :: tail, c, 0⟩ = ⟨0, tail, x, 0⟩ := by
  induction pre generalizing t c with
  | nil => simp [drops,run,step,nip]
  | cons a pre ih => simpa [drops,run,step,nip] using ih 0 a

private theorem split_at_member {x : Nat} {as : List Nat} (h : x ∈ as) :
    ∃ pre post, as = pre ++ x :: post := by
  induction as with
  | nil => contradiction
  | cons a as ih =>
    rcases List.mem_cons.mp h with rfl | h'
    · exact ⟨[], as, rfl⟩
    · obtain ⟨pre,post,eq⟩ := ih h'
      exact ⟨a :: pre, post, congrArg (List.cons a) eq⟩


private theorem load_cons (x : Nat) (post tail : List Nat) (v : Nat) (hx : x ≠ 0) :
    ∃ c, run (.mp 0 :: nips post.length) ⟨0,post ++ v::tail,x,0⟩ = ⟨x,tail,c,0⟩ := by
  cases post with
  | nil => exact ⟨v,rfl⟩
  | cons h t =>
    have H := nips_over (t ++ [v]) tail x h hx
    simpa [run,step,List.append_assoc] using H

theorem extract_rows (zs : List Nat) (x : Nat) (hx : x ≠ 0) (h : x ∈ zs.reverse.tail) :
    ∃ word, ∀ s : State, ∃ c, run word (afterAX s zs) = ⟨x,s.stack,c,0⟩ := by
  generalize er : zs.reverse.tail = rs at h
  cases rs with
  | nil => cases h
  | cons first rs =>
    have H (s : State) : afterAX s zs = ⟨0,rs ++ s.top :: s.stack,first,0⟩ := by simp [afterAX,nip,er]
    rcases List.mem_cons.mp h with e|h
    · subst x
      exact ⟨.mp 0 :: nips rs.length,fun s => H s ▸ load_cons _ _ _ _ hx⟩
    · obtain ⟨pre,post,he⟩ := split_at_member h
      refine ⟨drops (pre.length+1) ++ (.mp 0 :: nips post.length),fun s => ?_⟩
      rw [H,he,List.append_assoc,List.cons_append,run_append,drops_to]
      exact load_cons _ _ _ _ hx

def sweep : List Command := .ax 0 0 0 [] :: drops 6
theorem sweep_results (s : State) : ∃ w, run sweep s = ⟨0,s.top::s.stack,w,0⟩ := by
  simp [sweep,rows,tailRows,rowList,Eight187.Seed.eight,run,step,nip,drops,afterAX]

def reset : List Command := sweep ++ sweep ++ [.mode 0]
theorem reset_results (s : State) : run reset s = ⟨0,s.top::s.stack,0,0⟩ := by
  obtain ⟨c,h⟩ := sweep_results s
  obtain ⟨d,k⟩ := sweep_results ⟨0,s.top::s.stack,c,0⟩
  simp only [reset,run_append,h,k,run,step,nip,Nat.zero_add,ite_self,List.tail_cons,List.headD_cons]

def Builds (x : Nat) (word : List Command) : Prop :=
  ∀ (t : Nat) (stack : List Nat) (cache : Nat), ∃ c,
    run word ⟨t,stack,cache,0⟩ = ⟨x,t::stack,c,0⟩
private theorem member_retained (l r : List Nat) {x : Nat} (hx : x ∈ l) (hr : r ≠ []) :
    x ∈ (l ++ r).reverse.tail := by
  rw [List.reverse_append]
  cases he : r.reverse with
  | nil =>
    have eq := congrArg List.reverse he
    simp only [List.reverse_reverse,List.reverse_nil] at eq
    exact False.elim (hr eq)
  | cons t ts =>
    simp only [List.cons_append,List.tail_cons]
    exact List.mem_append_right ts (List.mem_reverse.mpr hx)
theorem builds_emitted {a b c u x : Nat} (xp : 0 < x) (hu : u ≤ a)
    (hx : x ∈ (rowList a b c u).take 7 ∨ 0 < c ∧ x ∈ rowList a b c u) :
    ∃ word, Builds x word := by
  let rest : List (Nat × Nat) := List.replicate c (0,0)
  let zs := rowList a b c u ++ tailRows a b rest
  have hrow : x ∈ zs.reverse.tail := by
    rcases hx with hf|⟨hc,hf⟩
    · have shape : rowList a b c u = (rowList a b c u).take 7 ++ [lastRow a b] := rfl
      change x ∈ (rowList a b c u ++ _).reverse.tail
      exact (show x ∈ ((rowList a b c u).take 7 ++ ([lastRow a b] ++ tailRows a b rest)).reverse.tail from
        member_retained _ _ hf (by simp))
    · apply member_retained _ _ hf
      cases c with
      | zero => omega
      | succ k => simp [rest,List.replicate_succ,tailRows,rowList,Eight187.Seed.eight]
  obtain ⟨extract,he⟩ := extract_rows zs x (by omega) hrow
  let ax := Command.ax u b (a-u) rest
  refine ⟨reset ++ (ax :: extract), ?_⟩
  intro t stack cache
  let saved : State := ⟨0,t::stack,0,0⟩
  have rs : rows u b (a-u) rest saved = zs := by
    simp only [rows,saved,zs,rest,List.length_replicate,Nat.zero_add,show u+(a-u)=a by omega]
  rw [run_append,reset_results]
  change ∃ c, run extract (afterAX saved (rows u b (a-u) rest saved)) = _
  rw [rs]
  exact he saved

theorem builds_mp {a b : Nat} {minor major : List Command}
    (ha : 0 < a) (hb : 0 < b) (hm : Builds a minor) (hM : Builds (imp a b) major) :
    Builds b (reset ++ major ++ minor ++ [.mp 0,.mode b]) := by
  intro t stack cache
  obtain ⟨c1,e1⟩ := hM 0 (t::stack) 0
  obtain ⟨c2,e2⟩ := hm (imp a b) (0::t::stack) c1
  refine ⟨0,?_⟩
  rw [run_append,run_append,run_append,reset_results,e1,e2]
  simp [run,step,nip,Nat.ne_of_gt ha,Nat.ne_of_gt hb]

open NF192.Numerical NF192.Emitter
open NF192.ProofSearch (Command candidate candidate_prefix candidate_ne_nil)
open NF192.SourceFields
theorem builds_row {a b c u x : Nat} (xp : 0 < x) (hu : u ≤ a) (hx : x ∈ rowList a b c u) :
    ∃ word, Builds x word := by
  have shape := last_row_split a b c u
  rw [shape] at hx
  rcases List.mem_append.mp hx with front|last
  · exact builds_emitted xp hu (.inl front)
  · have eq : x = lastRow a b := by simpa using last
    subst x
    apply builds_emitted (a:=a) (b:=b) (c:=1) (u:=u) xp hu
    exact .inr ⟨by decide, by simp [rowList,Eight187.Seed.eight]⟩
theorem deriv_buildable {x : Nat} (d : PositiveMinor.PositiveProof x) : ∃ word, Builds x word := by
  induction d with
  | row hp hu hx => exact builds_row hp hu hx
  | @mp a b hb hdM hdm major minor =>
    have ha : 0 < a := by cases hdm with | row h _ _ => exact h | mp h _ _ => exact h
    obtain ⟨m,h⟩ := major
    obtain ⟨n,k⟩ := minor
    exact ⟨_,builds_mp ha hb k h⟩

theorem exists_detecting_word (d : Deriv goal) :
    ∃ cs : List Command, ∀ s, checkedRun cs s = none := by
  obtain ⟨w,hw⟩ := deriv_buildable (PositiveMinor.all_positive_goal_iff.mpr d)
  let front := reset ++ w ++ w
  refine ⟨front ++ [.mp 0,.mp 0],fun s => ?_⟩
  rw [checkedRun_append]
  cases h : checkedRun front s with
  | none => rfl
  | some t =>
    have e := checkedRun_survives h
    obtain ⟨c,h1⟩ := hw 0 (s.top::s.stack) 0
    obtain ⟨c',h2⟩ := hw goal (0::s.top::s.stack) c
    rw [show run front s = ⟨goal,goal::0::s.top::s.stack,c',0⟩ by simp only [front,run_append,reset_results,h1,h2]] at e
    subst t
    by_cases hc : c' = goal <;> simp [checkedRun,observes,step,nip,hc,show goal ≠ 0 by decide]

theorem detects_iff_derives {s : State} (hs : s.Sound) :
    (∃ cs : List Command, checkedRun cs s = none) ↔ Deriv goal := by
  constructor
  · rintro ⟨cs,h⟩
    exact detects_only_goal hs h
  · intro h
    obtain ⟨cs,k⟩ := exists_detecting_word h
    exact ⟨cs,k s⟩
def one (c : Command) (s : State) : Option State :=
  if observes c s then none else some (step c s)

theorem checkedRun_cons (c : Command) (cs : List Command) (s : State) :
    checkedRun (c::cs) s = (one c s).bind (checkedRun cs) := by
  by_cases h : observes c s = true <;> simp [checkedRun, one, h]

def scan (start : Nat) (s : State) : Nat → Option State
  | 0 => some s
  | k+1 => (scan start s k).bind (checkedRun (candidate (start+k)))

theorem scan_eventually_halts (d : Deriv goal) (start : Nat) (s : State) :
    ∃ k, scan start s k = none := by
  obtain ⟨cs, universal⟩ := exists_detecting_word d
  obtain ⟨n, hn, hword⟩ := cofinal cs start
  have idx : start + (n-start) = n := by omega
  refine ⟨(n-start)+1, ?_⟩
  rw [scan,idx,candidate_prefix hword]
  cases h : scan start s (n-start) with
  | none => rfl
  | some old =>
    simp only [Option.bind_some, checkedRun_append, universal, Option.bind_none]

structure StreamState where
  next : Nat
  cursor : Nat
  proof : State

def streamStep (s : StreamState) : Option StreamState :=
  let fresh := s.cursor = 0
  let input := if fresh then s.next else s.cursor-1
  let next := if fresh then s.next+1 else s.next
  let parsed := parse input
  (one parsed.1 s.proof).map (fun result => ⟨next,parsed.2,result⟩)

def streamRun : Nat → StreamState → Option StreamState
  | 0,s => some s
  | n+1,s => (streamStep s).bind (streamRun n)

theorem stream_run_add (n m : Nat) (s : StreamState) :
    streamRun (n+m) s = (streamRun n s).bind (streamRun m) := by
  induction n generalizing s with
  | zero => simp only [Nat.zero_add, streamRun, Option.bind_some]
  | succ n ih =>
    rw [Nat.succ_add, streamRun, streamRun]
    cases h : streamStep s with
    | none => rfl
    | some t => simpa only [Option.bind_some] using ih t

theorem stream_continued (n next : Nat) (s : State) :
    streamStep ⟨next,n+1,s⟩ =
      (one (parse n).1 s).map (fun t => ⟨next,(parse n).2,t⟩) := by
  simp [streamStep]

theorem stream_candidate (n next : Nat) (s : State) :
    streamRun (candidate n).length ⟨next,n+1,s⟩ =
      (checkedRun (candidate n) s).map (fun t => ⟨next,0,t⟩) := by
  induction n using Nat.strongRecOn generalizing s with
  | ind n ih =>
    rw [candidate]
    simp only [List.length_cons, streamRun, stream_continued, checkedRun_cons]
    cases hs : one (parse n).1 s with
    | none => rfl
    | some t =>
      simp only [Option.map_some, Option.bind_some]
      by_cases hz : (parse n).2 = 0
      · simp [hz, streamRun, checkedRun]
      · simp only [hz, ↓reduceDIte]
        have hlt : (parse n).2 - 1 < n := by
          have hle := parse_decreases n
          omega
        have he : (parse n).2 = ((parse n).2-1)+1 := by omega
        rw [he]
        exact ih ((parse n).2-1) hlt t

theorem stream_fresh (n : Nat) (s : State) :
    streamStep ⟨n,0,s⟩ = streamStep ⟨n+1,n+1,s⟩ := by simp [streamStep]

theorem stream_candidate_fresh (n : Nat) (s : State) :
    streamRun (candidate n).length ⟨n,0,s⟩ =
      (checkedRun (candidate n) s).map (fun t => ⟨n+1,0,t⟩) := by
  have he := stream_candidate n (n+1) s
  have hn := List.length_pos_iff.mpr (candidate_ne_nil n)
  obtain ⟨m,hm⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : (candidate n).length ≠ 0)
  rw [hm, streamRun, stream_fresh]
  simpa only [hm, streamRun] using he

theorem scan_reached (start : Nat) (s : State) (k : Nat) :
    ∃ ticks, streamRun ticks ⟨start,0,s⟩ = (scan start s k).map (fun t => ⟨start+k,0,t⟩) := by
  induction k with
  | zero => exact ⟨0,rfl⟩
  | succ n ih =>
    obtain ⟨ticks,ht⟩ := ih
    refine ⟨ticks+(candidate (start+n)).length, ?_⟩
    rw [stream_run_add, ht, scan]
    cases hs : scan start s n with
    | none => rfl
    | some s => exact stream_candidate_fresh (start+n) s

def StreamSound : Option StreamState → Prop
  | none => Deriv goal
  | some s => s.proof.Sound

theorem stream_step_sound (s : StreamState) (hs : s.proof.Sound) :
    StreamSound (streamStep s) := by
  simp only [streamStep]
  generalize parse (if s.cursor = 0 then s.next else s.cursor-1) = parsed
  rcases parsed with ⟨c, tail⟩
  by_cases o : observes c s.proof = true
  · have halt : checkedRun [c] s.proof = none := by simp [checkedRun, o]
    simpa [one, o, StreamSound] using detects_only_goal hs halt
  · simpa [one, o, StreamSound] using step_sound c s.proof hs

theorem stream_run_sound (ticks : Nat) (s : StreamState) (hs : s.proof.Sound) :
    StreamSound (streamRun ticks s) := by
  induction ticks generalizing s with
  | zero => exact hs
  | succ n ih =>
    have hc := stream_step_sound s hs
    cases he : streamStep s with
    | none => simpa only [streamRun, he, Option.bind_none] using hc
    | some t =>
      have ht : t.proof.Sound := by simpa only [he, StreamSound] using hc
      simpa only [streamRun, he, Option.bind_some] using ih t ht

/-- For every sound entry at a refill boundary, the successive natural
candidates halt exactly when the nine-family calculus derives numeral 3. -/
theorem stream_halting_iff_goal (start : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, streamRun ticks ⟨start,0,s⟩ = none) ↔ Deriv goal := by
  constructor
  · rintro ⟨ticks, ht⟩
    simpa only [ht, StreamSound] using stream_run_sound ticks ⟨start,0,s⟩ hs
  · intro h
    obtain ⟨k,hk⟩ := scan_eventually_halts h start s
    obtain ⟨ticks,ht⟩ := scan_reached start s k
    exact ⟨ticks, by simpa only [hk, Option.map_none] using ht⟩


end LoadGate
#print axioms LoadGate.stream_halting_iff_goal
