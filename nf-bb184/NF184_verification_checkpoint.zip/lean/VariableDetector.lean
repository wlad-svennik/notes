import VariableSyntax
open NF188.Relabel NF188.Relabel.Syntax FFL FFL.FirstOrder
namespace VariableMarker
variable {V : Type} (A : Basis V) (J : V)
local infixl:70 " ⬝ " => A.app
local infixl:75 " ◆ " => Term.app
def up : Nat → Term → Term
  | 0,s => s
  | n+1,s => lift (up n s)
theorem val_up (n : Nat) (s : Term) (e : Nat → V) :
    val A J e (up n s)=kpow A n (val A J e s) := by
  induction n with | zero => rfl | succ n ih => simp only [up,val_lift,ih,kpow]
def diag (x y : V) := J ⬝ A.K x ⬝ y
def down (z : V) := z ⬝ J ⬝ J ⬝ J
def downSrc := vr 0 ◆ con .p ◆ con .p ◆ con .p
def refBody := vr 1 ◆ up 4 downSrc ◆ up 3 downSrc
def reference := val A J (fun _ => pairing A J) (abs 0 refBody)
theorem ref_apply (v : V) : reference A J ⬝ v = pair A J (down A J v) (down A J v) := by
  change val A J _ (abs 0 refBody) ⬝ kpow A 0 v=_
  rw [beta A J _ 0 (by decide)]
  simp [refBody,val,val_up,downSrc,vr,con,valAtom,down,pair,cons,kpow]
def env (a b c d : V) := cons (reference A J) (cons (pairing A J)
  (cons a (cons b (cons c (fun _ => d)))))
def hBody := con .p ◆ lift (vr 3 ◆ vr 0) ◆ (vr 4 ◆ up 4 (vr 2) ◆ up 3 (vr 1))
def probe (x y : V) := val A J (cons y (cons x (env A J J J J J))) (abs 0 hBody)
theorem h_apply (a b c d x y z : V) :
    val A J (cons y (cons x (env A J a b c d))) (abs 0 hBody) ⬝ z =
    diag A J (reference A J ⬝ z) (pair A J x y) := by
  change val A J _ (abs 0 hBody) ⬝ kpow A 0 z=_
  rw [beta A J _ 0 (by decide)]
  simp [hBody,val,val_up,val_lift,vr,con,valAtom,diag,pair,cons,env,kpow]
theorem probe_apply (x y z : V) :
    probe A J x y ⬝ z = diag A J (reference A J ⬝ z) (pair A J x y) :=
  h_apply A J J J J J x y z
def wBody := con .p ◆ lift (vr 2) ◆ abs 0 hBody ◆ vr 4 ◆ vr 5 ◆ vr 6 ◆ vr 7
def weak (a b c d : V) := val A J (env A J a b c d) (abs 1 (abs 0 wBody))
theorem weak_apply (a b c d x y : V) :
    weak A J a b c d ⬝ A.K x ⬝ y =
      diag A J (reference A J) (probe A J x y) ⬝ a ⬝ b ⬝ c ⬝ d := by
  unfold weak
  change val A J _ (abs 1 _) ⬝ kpow A 1 x ⬝ kpow A 0 y = _
  rw [beta A J _ 1 (by decide),beta A J _ 0 (by decide)]
  have eh : val A J (cons y (cons x (env A J a b c d))) (abs 0 hBody) = probe A J x y := by
    apply A.ext
    intro z
    exact (h_apply A J _ _ _ _ _ _ _).trans (probe_apply A J _ _ _).symm
  simp only [env] at eh
  simp only [wBody,val,val_lift,vr,con,kpow,valAtom,env,cons,diag]
  rw [eh]

variable (off : ∀ x y : V, x ≠ y → diag A J x y=x)
variable (on : ∀ x : V, diag A J x x ≠ x)
include off in
theorem probe_eq {x y : V} (h : x≠y) : probe A J x y=reference A J := by
  apply A.ext; intro z
  rw [probe_apply]
  apply off
  rw [ref_apply]
  intro e
  have k := pair_inj A J e
  exact h (k.1.symm.trans k.2)
include on in
theorem probe_ne (x : V) : probe A J x x ≠ reference A J := by
  intro eq
  have v := congrArg (fun t => A.app t (kpow A 3 x)) eq
  change probe A J x x ⬝ kpow A 3 x = reference A J ⬝ kpow A 3 x at v
  simp only [probe_apply,ref_apply,down,kpow,A.k_app] at v
  exact on _ v
private theorem sep {u v : V} (h : u≠v) : ∃ s, A.app u s ≠ A.app v s := by
  classical
  by_contra! no
  exact h (A.ext no)
include A J off on in
/-- The variable-marker test suffices for pure NF, with no named truth values. -/
theorem consistent : Entailment.Consistent 𝗡𝗙 := by
  let r := reference A J
  let s := diag A J r r
  have n : s ≠ r := on _
  obtain ⟨a,na⟩ := sep A n
  obtain ⟨b,nb⟩ := sep A na
  obtain ⟨c,nc⟩ := sep A nb
  obtain ⟨d,nd⟩ := sep A nc
  apply NF196.Weak.consistent A (weak A J a b c d) (s ⬝ a ⬝ b ⬝ c ⬝ d)
  · intro x y h
    change weak A J a b c d ⬝ A.K x ⬝ y=_
    rw [weak_apply,probe_eq A J off h]
  · intro x
    change weak A J a b c d ⬝ A.K x ⬝ x≠_
    rw [weak_apply, off _ _ (Ne.symm (probe_ne A J on x))]
    exact nd.symm
end VariableMarker
#print axioms VariableMarker.consistent
