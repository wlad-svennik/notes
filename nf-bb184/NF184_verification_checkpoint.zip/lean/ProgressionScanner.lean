import ProgressionEnumeration
import Eight187Exact
namespace ProgressionEnumeration
open NF192.Numerical NF192.SourceFields
open NF192.ProofSearch (Command candidate candidate_prefix)
open Eight187

/-- At a refill a machine may also change its proof registers, provided the
new proof state is sound. Each candidate word then runs normally. -/
def scanProgression (start stride : Nat) (refill : Nat → State → State) (initial : State) :
    Nat → Option State
  | 0 => some initial
  | i+1 => (scanProgression start stride refill initial i).bind (fun s =>
      checkedRun (candidate (start+stride*i)) (refill i s))

private def Good : Option State → Prop
  | none => Eight187.Deriv goal
  | some s => s.Sound
private theorem commands_good (cs : List Command) (s : State) (hs : s.Sound) :
    Good (checkedRun cs s) := by
  induction cs generalizing s with
  | nil => exact hs
  | cons cmd cs ih =>
    cases h : observes cmd s with
    | false => simpa [checkedRun,h] using ih _ (step_sound cmd s hs)
    | true =>
      have H : checkedRun [cmd] s = none := by simp [checkedRun,h]
      simpa [checkedRun,h,Good] using detects_only_goal hs H
private theorem scan_good {start stride : Nat} {refill : Nat → State → State} {s : State}
    (hs : s.Sound) (hr : ∀ i t, t.Sound → (refill i t).Sound) (k : Nat) :
    Good (scanProgression start stride refill s k) := by
  induction k with
  | zero => exact hs
  | succ i ih =>
    rw [scanProgression]; cases h : scanProgression start stride refill s i with
    | none => simpa [h] using ih
    | some z => exact commands_good _ _ (hr i z (by simpa [h, Good] using ih))

open FFL FFL.FirstOrder in
theorem progression_scanner_iff_nf_refutation (start stride : Nat) (hpos : 0<stride)
    (refill : Nat → State → State) (hsf : ∀ i s, s.Sound → (refill i s).Sound)
    (s : State) (hs : s.Sound) :
    (∃ ticks, scanProgression start stride refill s ticks = none) ↔ (𝗡𝗙 ⊢ ⊥) := by
  rw [← Eight187.deriv_goal_iff_nf_refutation]
  constructor
  · rintro ⟨k,h⟩
    simpa [h,Good] using scan_good (start:=start) (stride:=stride) hs hsf k
  · intro d
    obtain ⟨cs,det⟩ := exists_detecting_word d
    obtain ⟨n,u,b,v,rs,t,hn,hr,matchword⟩ := cofinal_progression cs stride start start hpos
    let i := n/stride - start/stride
    have ei : start+stride*i = n := by
      dsimp [i]; rw [Nat.mul_sub]
      have a := Nat.mod_add_div n stride
      have b' := Nat.mod_add_div start stride
      omega
    refine ⟨i+1,?_⟩
    rw [scanProgression,ei,candidate_prefix matchword]
    cases ho : scanProgression start stride refill s i with
    | none => rfl
    | some z =>
      simp only [Option.bind_some, List.cons_append]
      change checkedRun (cs ++ candidate t) (step (.ax u b v rs) (refill i z)) = none
      rw [checkedRun_append,det]; rfl
end ProgressionEnumeration
#print axioms ProgressionEnumeration.progression_scanner_iff_nf_refutation
