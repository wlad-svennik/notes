#include "frame.hpp"
int main(int argc,char**argv){try{Source src(argv[1]);Machine bin(argv[2]);Run raw{bin.start,center,{}};Reg seed{-1,0,0,2,0,0,0,0,0}; Frame f;
 for(int k=0;;k++){raw.tick(bin);check(raw.q!=bin.n&&k<600000,"initial frame missing");if(raw.q==bin.d0&&decode(src,raw,f)&&f.pc==40&&f.regs==seed)break;}
 int first=raw.ticks,gap0=f.header-f.h;
 int rows=0;for(;;){if(f.header-f.h>=src.depth+12&&f.spares.size()>=24&&find_if(f.spares.begin(),f.spares.end(),[](int v){return v!=0;})==f.spares.end())break;complete(src,bin,raw,f,false);check(++rows<3000,"canonical frame not reached");}
 Frame tf;check(decode(src,raw,tf)&&tf.pc==f.pc&&tf.regs==f.regs&&tf.spares==f.spares,"noncanonical endpoint");cout<<"{\"start_pc\":40,\"start_step\":"<<first<<",\"start_gap\":"<<gap0<<",\"register_steps\":"<<rows<<",\"covered_pc\":"<<f.pc<<",\"covered_step\":"<<raw.ticks<<",\"head\":"<<raw.h-center<<",\"gap\":"<<f.header-f.h<<",\"zero_spares\":"<<f.spares.size()<<",\"registers\":[";for(int i=0;i<9;i++){if(i)cout<<",";cout<<f.regs[i];}cout<<"]}\n";return 0;}catch(exception&e){cerr<<e.what()<<endl;return 1;}}
