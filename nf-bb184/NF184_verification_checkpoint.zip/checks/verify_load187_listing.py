"""Check every encoded Lean register instruction against the saved prefix-tree source."""
import argparse
import json
import re
from pathlib import Path

def verify(source, lean):
    rows = json.loads(source.read_text())
    assert len(rows) == 2937
    assert [p for p, op, arg in rows] == sorted(p for p, op, arg in rows)
    bounds = {}
    for i, (p, _, _) in enumerate(rows):
        for k in range(len(p) + 1):
            bounds.setdefault(p[:k], [i, i + 1])[1] = i + 1
    chunks = [int(x, 16) for x in re.findall(r'0x[0-9a-f]+', lean.read_text())]
    assert len(chunks) == (len(rows) + 31) // 32
    for i, (p, op, arg) in enumerate(rows):
        nxt = (i + 1) % len(rows)
        target = p
        if op != 'CI':
            side = '1' if op == 'CC' else '0'
            for _ in range(1 if op == 'CD' else arg):
                target = target[:target.rindex(side)]
        if op == 'CI':
            code = 4 * (arg + 16 * nxt)
        elif op == 'CD':
            if p.endswith('1'):
                code = 3 + 4 * (arg + 16 * nxt)
            else:
                zero = bounds[target][1] % len(rows)
                code = 1 + 4 * (arg + 16 * (nxt + 4096 * zero))
        else:
            jump = bounds[target][0 if op == 'CC' else 1] % len(rows)
            code = 2 + 4 * jump
        actual = (chunks[i // 32] >> (30 * (i % 32))) % (2 ** 30)
        assert actual == code, (i, rows[i], actual, code)
    print(f'All {len(rows)} Lean instructions reproduce the decoded literal source.')

if __name__ == '__main__':
    args = argparse.ArgumentParser()
    args.add_argument('source', type=Path)
    args.add_argument('lean', type=Path)
    x = args.parse_args()
    verify(x.source, x.lean)
