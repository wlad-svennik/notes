#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using Reg = array<int,9>;
const array<int,9> order = {2,8,1,4,3,7,0,5,6};
const int center=1024, cells=4096;
void check(bool b,const string& why){if(!b)throw runtime_error(why);}
struct Tape {
 array<uint64_t,cells/64> words{};
 int read(int p)const{check(0<=p&&p<cells,"tape bounds");return (words[p/64]>>(p%64))&1;}
 void write(int p,int b){check(0<=p&&p<cells,"tape bounds");uint64_t bit=uint64_t(1)<<(p%64);if(b) words[p/64]|=bit;else words[p/64]&=~bit;}
 bool operator==(const Tape& t)const{return words==t.words;}
};
struct Arc{int write,dir,to;};
struct Machine{
 int n,start,d0,gate;vector<array<Arc,2>> table;
 explicit Machine(const string& path){ifstream f(path);check(bool(f>>n>>start>>d0>>gate),"table header");table.resize(n);int terminal=0;
 for(int q=0;q<n;q++)for(int b=0;b<2;b++){auto&e=table[q][b];check(bool(f>>e.write>>e.dir>>e.to),"missing transition");check((e.write==0||e.write==1)&&(e.dir==-1||e.dir==1)&&0<=e.to&&e.to<=n,"invalid transition");if(e.to==n){check(q==gate&&b==1,"unexpected halt transition");terminal++;}}check(terminal<=1,"halt transition count");}
};
struct Run{int q,h;Tape tape;long long ticks=0;int prev=-1,saw=-1;
 void tick(const Machine&m){check(q<m.n,"tick past halt");prev=q;saw=tape.read(h);auto a=m.table[q][saw];tape.write(h,a.write);h+=a.dir;q=a.to;ticks++;}
};
struct Row{string path,op;int a;};
struct Source{vector<Row>rows;map<string,int>Pc;int depth=0,goal=-1;
 explicit Source(const string&p){ifstream f(p);Row r;while(f>>r.path>>r.op>>r.a){int i=rows.size();check(Pc.emplace(r.path,i).second,"duplicate source path");rows.push_back(r);depth=max<int>(depth,r.path.size());if(r.op=="CD"&&r.path.back()=='1'){check(goal==-1,"two halt source sites");goal=i;}}check(!rows.empty()&&goal>=0,"source empty or missing goal");}
 int first(string p)const{while(!Pc.count(p)){p+='0';check(int(p.size())<=depth,"missing fallthrough");}return Pc.at(p);}
};
struct Frame{int pc,h,header;Reg regs;vector<int>spares;};
Tape encode(const Source&s,const Frame&f){Tape t;t.write(f.h-1,1);int x=f.h;for(char b:s.rows.at(f.pc).path)t.write(x++,b-'0');t.write(f.header,1);x=f.header+2;
 auto emit=[&](int n){check(n>=0,"negative block encoding");for(int j=0;j<n+1;j++)t.write(x++,1);x++;};for(int r:order)emit(f.regs[r]+1);for(int v:f.spares)emit(v);return t;}
bool decode(const Source&s,const Run&r,Frame&f){int amin=-1,amax=-1;for(int h=0;h<cells;h++)if(r.tape.read(h)){if(amin<0)amin=h;amax=h;}if(amin!=r.h-1)return false;string path;int c=r.h;while(!s.Pc.count(path)){if(int(path.size())==s.depth)return false;path+=char('0'+r.tape.read(c++));}while(c<=amax&&!r.tape.read(c))c++;if(c>amax||r.tape.read(c+1))return false;f.pc=s.Pc.at(path);f.h=r.h;f.header=c;c+=2;vector<int>blocks;while(c<=amax){int a=c;while(r.tape.read(c))c++;if(a==c)return false;blocks.push_back(c-a-1);c++;}if(blocks.size()<9)return false;for(int i=0;i<9;i++)f.regs[order[i]]=blocks[i]-1;f.spares.assign(blocks.begin()+9,blocks.end());return encode(s,f)==r.tape;}
string cut(string p,char side,int n){while(n--){auto k=p.rfind(side);check(k!=string::npos,"invalid source jump");p.resize(k);}return p;}
void advance(string&p,int&h){auto k=p.rfind('0');if(k==string::npos){p.clear();h--;}else p=p.substr(0,k)+'1';}
// Return false precisely for the distinguished zero-goal decrement.
bool source_step(const Source&s,Frame&f){auto row=s.rows[f.pc];string p=row.path;
 if(row.op=="CI"){f.regs[row.a]++;f.spares.push_back(0);advance(p,f.h);}
 else if(row.op=="CD"){check(f.regs[row.a]>=0,"uninitialized decrement");if(f.regs[row.a]==0){if(p.back()=='1')return false;p=cut(p,'0',1);}else{f.regs[row.a]--;f.header++;}advance(p,f.h);}
 else if(row.op=="CC")p=cut(p,'1',row.a);else if(row.op=="CB"){p=cut(p,'0',row.a);advance(p,f.h);}else throw runtime_error("invalid opcode");f.pc=s.first(p);return true;}
struct Stats{long long trials=0,steps=0,halts=0,goalpos=0,one=0,zero=0;int maximum=0;map<string,int>ops;};
int complete(const Source&s,const Machine&m,Run&r,Frame&f,bool allowhalt=true){int pc=f.pc;bool live=source_step(s,f);auto expected=live?encode(s,f):Tape{};for(int t=1;t<=250000;t++){r.tick(m);if(r.q==m.n){check(allowhalt&&!live&&pc==s.goal&&r.prev==m.gate&&r.saw==1,"unexpected halt at PC "+to_string(pc));return t;}if(live&&r.q==m.d0&&r.h==f.h&&r.tape==expected)return t;}throw runtime_error("full successor absent at PC "+to_string(pc));}

