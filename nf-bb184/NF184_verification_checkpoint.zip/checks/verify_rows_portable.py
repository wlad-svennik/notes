"""Check the full register-source binding against the pinned NF192 Lean emitter.
Run normally or with python -O. Explicit checks, including emitted macro comparisons,
remain active in both modes. Requires Python 3.8+ and only its standard library.
"""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile


def check(condition, message):
    if not condition:
        raise ValueError(message)



def lean_blocks(archive):
    literal = archive.read("proof/NumericalEmitterMacros.lean").decode()
    emitter = archive.read("proof/NumericalEmitter.lean").decode()
    blocks = {}
    ops = {"inc": "CI", "dec": "CD", "br": "CB", "cont": "CC"}

    def term(s):
        if s in blocks:
            return blocks[s]
        op, arg = s[1:].split()
        return ops[op], int(arg)

    for name, left, right in re.findall(r"def (seq\d+) : Code := \.seq \(([^)]+)\) \(([^)]+)\)", literal):
        blocks[name] = term(left), term(right)
    named = {tok: blocks[code] for tok, code in
             re.findall(r"\| \.(\w+) => Literal\.(seq\d+)", emitter)}
    named["incTop"] = "CI", 1
    named["ap"] = named["eqn"] = named["imp"], named["incTop"]
    return named

def flatten(node, path=""):
    if isinstance(node[0], str):
        yield [path, *node]
    else:
        yield from flatten(node[0], path+"0")
        yield from flatten(node[1], path+"1")

def graph(rows, *, isolated=False):
    n = len(rows)
    bounds = {}
    paths = [p for p, op, r in rows]
    check(paths == sorted(set(paths)), "input paths are not distinct and sorted")
    for i, path in enumerate(paths):
        for j in range(len(path)+1):
            k = path[:j]
            if k not in bounds:
                bounds[k] = [i, i+1]
            else:
                bounds[k][1] = i+1
    check(len(bounds) == 2*n-1, "input is not a complete binary tree")

    def resolve(path, side, distance):
        for at in range(len(path)-1, -1, -1):
            if path[at] == side:
                distance -= 1
                if distance == 0:
                    first, stop = bounds[path[:at]]
                    return first if side == "1" else (stop if isolated else stop%n)
        raise ValueError(f"unbound jump {path} {side} {distance}")

    result = []
    for i, (path, op, r) in enumerate(rows):
        nxt = i+1 if isolated else (i+1)%n
        if op == "CI":
            result.append((op,r,(nxt,)))
        elif op == "CD":
            result.append((op,r,(resolve(path,"0",1), nxt)))
        elif op in ("CB", "CC"):
            side = "0" if op == "CB" else "1"
            result.append((op,r,(resolve(path,side,r),)))
        else:
            raise ValueError(op)
    return result

PINS={
    'proof/NumericalEmitterMacros.lean':'00c7eb9b9d3be4fd0dab8d7cb1073f9688794c45e944ba77d7a2d27c3354c942',
    'proof/NumericalEmitter.lean':'312f28ec08b3d48749db64075a31765d2fefe7c0f5f99510ab817c1d57cd2ea7',
    'proof/NumericalEmitterBatch.lean':'09f9537f8855de3c7e6de7687e7a70e8645ecfb24c4f318476259c84da388c16',
    'machine/countdown.sites.json':'b991565b82033c133e1f2b4618dfe32d1e7ff1ef02e8e18620a2dfdccb5307aa'
}
OP={'ap':'ap','h':'h','eq':'eq','imp':'imp','A':'ap','H':'h','E':'eq','I':'imp'}
TAG={'ap':1,'h':2,'eq':1,'imp':0}
MAC={'ap':'ap','h':'witness','eq':'eqn','imp':'imp'}
CODES={'q':0,'T':1,'B':3,'G':3}
LIMIT=2000


def folded(tag,a,b):
    if type(a) is int and type(b) is int and a<=LIMIT and b<=LIMIT:
        v=(a+b)*(a+b+1)+2*b+tag
        if v<=LIMIT:
            return v
    return (tag,a,b)


def emit(ast, env, costs):
    if isinstance(ast,str):
        if ast in CODES:
            k=CODES[ast]
            return k,['push0']+['incTop']*k
        check(ast in env, f'unknown variable {ast}')
        return ('var',ast), ['push'+str(env[ast])]
    check(isinstance(ast,list) and len(ast)==3 and ast[0] in OP, f'invalid literal AST {ast}')
    op=OP[ast[0]]
    lv,left=emit(ast[1],env,costs)
    rv,right=emit(ast[2],env,costs)
    result=folded(TAG[op],lv,rv)
    tokens=left+right+[MAC[op]]
    if type(result) is int and costs['push0'] + result < sum(costs[t] for t in tokens):
        tokens=['push0']+['incTop']*result
    return result,tokens


def effect(tokens, env):
    sentinel=('original buried stack',)
    stack=[sentinel]
    reverse={'push'+str(v):('var',k) for k,v in env.items()}
    reverse['push0']=0
    tags={'ap':1,'eqn':1,'imp':0,'witness':2}
    for tok in tokens:
        if tok in reverse:stack.append(reverse[tok])
        elif tok=='incTop':
            check(type(stack[-1]) is int, 'nonliteral direct INC')
            stack[-1]+=1
        else:
            check(tok in tags and len(stack)>2,'invalid stack program')
            right,left=stack.pop(),stack.pop()
            stack.append(folded(tags[tok],left,right))
    check(len(stack)==2 and stack[0]==sentinel, 'the incoming stack is not preserved')
    return stack[1]


def normalized(rows, isolated=False):
    output=[]
    for op,reg,target in graph(rows,isolated=isolated):
        output.append((op, reg if op in ('CI','CD') else None, target))
    return output


def verify(args):
    with ZipFile(args.base) as archive:
        for name,h in PINS.items():
            check(sha256(archive.read(name)).hexdigest()==h,'baseline hash mismatch: '+name)
        old=json.loads(archive.read('machine/countdown.sites.json'))
        macros=lean_blocks(archive)
        spec=archive.read('proof/NumericalEmitterBatch.lean').decode()
    raw_source=args.source.read_bytes()
    raw_table=args.table.read_bytes()
    new=json.loads(raw_source)
    oldg,newg=normalized(old),normalized(new)
    signatures={tok:normalized(list(flatten(code)),True) for tok,code in macros.items()}
    costs={k:len(v) for k,v in signatures.items()}
    rows=json.loads(args.spec.read_text())
    check(isinstance(rows,list) and bool(rows),'expected an ordered nonempty list of rows')
    old_text=re.search(r'def tokens9 : List Macro :=\s*\[([^\]]+)\]',spec).group(1)
    old_tokens=re.findall(r'\.(\w+)',old_text)
    old_start=2964-sum(costs[t] for t in old_tokens)

    def span(g,pos,tokens):
        for t in tokens:
            code=signatures[t]
            for j,(op,r,targets) in enumerate(code):
                check(g[pos+j]==(op,r,tuple(pos+a for a in targets)),f'macro {t} differs at site {pos+j}')
            pos+=len(code)
        return pos
    check(span(oldg,old_start,old_tokens)==2964,'incorrect original-row boundary')
    next_site=old_start
    receipts=[]
    for row in rows:
        regs=row['registers']
        check(isinstance(regs,dict) and all(type(v) is int and v in (3,4,5) for v in regs.values())
              and len(regs)==len(set(regs.values())), 'invalid register map')
        abstract_syntax,tokens=emit(row['ast'],regs,costs)
        check(effect(tokens,regs)==abstract_syntax,'symbolic stack polynomial mismatch')
        end=span(newg,next_site,tokens)
        receipts.append(dict(label=row.get('label','row'),start=next_site,stop=end,
                             sites=end-next_site,registers=regs,macros=tokens))
        next_site=end
    shift=next_site-2964
    check(len(newg)==len(oldg)+shift,'unexpected source size')
    def actual(i):
        if i<=old_start:return i
        check(i>=2964, f'outside code targets changed row at old site {i}')
        return i+shift
    survivors=[*range(old_start),*range(2964,len(old))]
    for i in survivors:
        op,r,targets=oldg[i]
        check(newg[actual(i)]==(op,r,tuple(actual(t) for t in targets)),f'inherited CFG at {i}')
    fingerprints={a:sha256(v).hexdigest() for a,v in [('table',raw_table),('source',raw_source),('row_spec',args.spec.read_bytes())]}
    if args.expect_source:
        check(fingerprints['source']==args.expect_source,'candidate source SHA-256 mismatch')
    if args.expect_table:
        check(fingerprints['table']==args.expect_table,'candidate table SHA-256 mismatch')
    return dict(passed=True,sha256=fingerprints,baseline_files=PINS,
                old_sites=len(oldg),new_sites=len(newg),retained_sites=len(survivors),
                original_row9=[old_start,2964],rows=receipts,
                scope='Exact source-level polynomial/stack and resolved control verification for the provided per-row specification. Table hash identifies the separately audited machine. This check does not establish physical execution.')


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    for field in ('base','source','table','spec'):
        ap.add_argument('--'+field,type=Path,required=True)
    ap.add_argument('--expect-source');ap.add_argument('--expect-table')
    ap.add_argument('--out',type=Path)
    a=ap.parse_args();out=verify(a);data=json.dumps(out,indent=2)+'\n'
    if a.out:a.out.write_text(data)
    print(data,end='')
