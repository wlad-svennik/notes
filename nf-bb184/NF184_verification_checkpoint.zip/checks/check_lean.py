"""Compile the new Lean modules against the built upstream185 release."""
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
root=Path(__file__).resolve().parents[1]
upstream=Path(sys.argv[1]).resolve()
if not (upstream/'Eight187Exact.olean').exists():
    raise SystemExit('Pass the upstream185 build directory containing Eight187Exact.olean.')
files={f.stem:f for f in (root/'lean').glob('*.lean')}
done=set()
with tempfile.TemporaryDirectory() as folder:
    env=dict(os.environ,LEAN_PATH=os.pathsep.join([folder,str(upstream),os.environ.get('LEAN_PATH','')]))
    def build(name):
        if name in done:return
        path=files[name]
        for mod in re.findall(r'^(?:public )?import ([\w.]+)',path.read_text(),flags=re.M):
            if mod in files:build(mod)
        cmd=['lean','-j1','-s','131072','-o',str(Path(folder)/(name+'.olean')),path.name]
        x=subprocess.run(cmd,cwd=path.parent,capture_output=True,text=True,env=env)
        log=x.stdout+x.stderr
        print(name,log,flush=True)
        if x.returncode or re.search(r'\bsorryAx\b|declaration uses .sorry.|\berror:',log):raise SystemExit('Lean replay failed in '+name)
        done.add(name)
    for name in sorted(files):build(name)
