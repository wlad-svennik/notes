def convert_table(source, destination):
    lines = source.read_text().splitlines()
    start = next(line.split()[-1] for line in lines if line.startswith('#! start '))
    arcs = [line.split() for line in lines if line.strip() and not line.startswith('#')]
    names = sorted({row[0] for row in arcs})
    ids = {name: index for index, name in enumerate([*names, 'halt'])}
    transitions = {}
    for state, bit, write, direction, target in arcs:
        if (state, bit) in transitions:
            raise ValueError(f'Duplicate transition for {(state, bit)}')
        if bit not in ('0', '1') or write not in ('0', '1') or direction not in ('L', 'R'):
            raise ValueError(f'Invalid transition for {(state, bit)}')
        transitions[state, bit] = (int(write), -1 if direction == 'L' else 1, ids[target])
    if len(transitions) != 2 * len(names) or 'halt' in names:
        raise ValueError('Incomplete table or transitions from the halting state')
    with destination.open('w') as out:
        print(len(names), ids[start], ids['d:0'], ids['k:302'], file=out)
        for state in names:
            for bit in ('0', '1'):
                print(*transitions[state, bit], file=out)


