"""Verify archived files, working-state reachability and optional full symbolic replay."""
from pathlib import Path
from hashlib import sha256
import gzip,json,sys,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
sums=root/'SHA256SUMS'
if sums.exists():
    for l in sums.read_text().splitlines():
        h,n=l.split('  ',1)
        if sha256((root/n).read_bytes()).hexdigest()!=h:raise ValueError(n)
for d in sorted((root/'machines').iterdir()):
    f=d/'candidate.tm';s=f.read_text().splitlines();tab={}
    for row in s[1:]:
        q,b,w,m,z=row.split()
        if (q,b) in tab or b not in ('0','1') or w not in ('0','1') or m not in ('L','R'):raise ValueError(row)
        tab[q,b]=z
    if {q for q,b in tab}!=set(q for q,b in tab if b=='0') or len({q for q,b in tab})*2!=len(tab):raise ValueError('table size')
    live=set();todo=[s[0].split()[-1]]
    while todo:
        q=todo.pop()
        if q=='halt' or q in live:continue
        live.add(q);todo.extend([tab[q,'0'],tab[q,'1']])
    if len(live)*2!=len(tab):raise ValueError('unreachable listed state')
    print(d.name,len(live),'reachable working states',flush=True)
    cert=d/'traces.json.gz'
    if cert.exists():
        rec=json.loads(gzip.decompress(cert.read_bytes()))
        if sha256(f.read_bytes()).hexdigest()!=rec['table'] or sha256((d/'source.sites.json').read_bytes()).hexdigest()!=rec['source']:raise ValueError('trace input mismatch')
        if '--frames' in sys.argv:
            with tempfile.TemporaryDirectory() as tmp:
                target=Path(tmp)/'traces.gz'
                subprocess.run([sys.executable,root/'checks/symbolic_frames.py',d,'--write',target],check=True)
                if gzip.decompress(target.read_bytes())!=gzip.decompress(cert.read_bytes()):raise ValueError('trace replay mismatch')
