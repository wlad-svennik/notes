"""Bind each executable AX register instruction to the public emitter source.

Usage: python register_binding.py CANDIDATE_JSON UPSTREAM185_ZIP
"""
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import sys
from verify_rows_portable import PINS, check, flatten, graph, lean_blocks

ORDER=[9,2,6,5,1,3,7,8]
WORDS=[
    "VCDIRDIDCIECIII",
    "EEHDAEA",
    "DEADCACEAII",
    "Z+CADAEACEEHADEAAA",
    "CEADCADEAAI",
    "DCACEADEAAI",
    "ZEEHADAEAZEEHAEAEAIDEAI",
    "EDEHADDEHAADEAI",
]
TOKENS=dict(C="push3",D="push4",E="push5",Z="push0",I="imp",A="ap",H="witness",V="read5",R="read4")
TOKENS["+"]="incTop"

def full(rows):
    normalized=[]
    for (path,_,_), (op,r,qs) in zip(rows,graph(rows)):
        if op=="CD" and path.endswith("1"):
            normalized.append(("halt-if-zero",r,(None,qs[1])))
        elif op in ("CC","CB"):
            normalized.append(("jump",0,qs))
        else:
            normalized.append((op,r,qs))
    return normalized

def run(candidate,upstream):
    with ZipFile(Path(__file__).parent/"NF192_emitter_reference.zip") as z:
        for path,digest in PINS.items():
            check(sha256(z.read(path)).hexdigest()==digest,path)
        macros=lean_blocks(z)
    with ZipFile(upstream) as z:
        oldrows=json.loads(z.read("NF_Eight_Row_185/source.sites.json"))
    newrows=json.loads(candidate.read_bytes())
    new=full(newrows);old=full(oldrows);pos=40;boundaries=[]
    for slot,word in zip(ORDER,WORDS):
        start=pos
        for char in word:
            code=graph(list(flatten(macros[TOKENS[char]])),isolated=True)
            for j,(op,r,edges) in enumerate(code):
                if op in ("CC","CB"):op,r="jump",0
                expected=(op,r,tuple(pos+t for t in edges))
                check(new[pos+j]==expected,f"macro {TOKENS[char]} PC {pos+j}: {new[pos+j]} != {expected}")
            pos+=len(code)
        boundaries.append((slot,word,start,pos))
    oldend=2837
    change=pos-oldend
    check(len(new)==len(old)+change,"source length")
    def lift(i):
        if i is None:return None
        if i<=40:return i
        check(i>=oldend,f"unexplained entry into AX body {i}")
        return i+change
    for i in [*range(40),*range(oldend,len(old))]:
        o,r,t=old[i]
        check(new[lift(i)]==(o,r,tuple(map(lift,t))),f"external instruction at PC {i}")
    check(WORDS[-1]=="EDEHADDEHAADEAI" and "C" not in WORDS[-1],"extensionality last")
    return dict(source_sha256=sha256(candidate.read_bytes()).hexdigest(),register_instructions=len(new),rows=boundaries,exact_macro_instructions=pos-40,unchanged_prefix=40,unchanged_suffix=len(old)-oldend,only_zero_halt=[i for i,(op,_,_) in enumerate(new)if op=="halt-if-zero"],new_ax_start=40,new_ax_end_exclusive=pos,old_ax_end_exclusive=oldend)
if __name__=="__main__":
    print(json.dumps(run(Path(sys.argv[1]),Path(sys.argv[2])),indent=2))
