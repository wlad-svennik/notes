"""Reproduce the finite blank-to-covered-frame link for the 184 table."""
import json
from pathlib import Path
import subprocess
import tempfile
from table import convert_table
here=Path(__file__).resolve().parent
machine=here.parent/'machines/variable184'
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    rows=json.loads((machine/'source.sites.json').read_bytes())
    (tmp/'addr').write_text(''.join(f'{p} {o} {r}\n' for p,o,r in rows))
    convert_table(machine/'candidate.tm',tmp/'table')
    subprocess.run(['c++','-std=c++20','-O2',here/'blank_bridge.cpp','-o',tmp/'boot'],check=True)
    receipt=json.loads(subprocess.check_output([tmp/'boot',tmp/'addr',tmp/'table']))
    if receipt!=json.loads((machine/'blank.json').read_bytes()):raise ValueError('bootstrap mismatch')
    print(json.dumps(receipt))
