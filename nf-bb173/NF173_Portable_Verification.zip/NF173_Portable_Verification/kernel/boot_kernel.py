"""Generate a closed Lean kernel proof of the blank-to-register-frame computation."""
import argparse,hashlib,json,os,sys
from pathlib import Path
args=argparse.ArgumentParser()
args.add_argument('engine',type=Path)
args.add_argument('machine',type=Path)
args.add_argument('output',type=Path)
args.add_argument('--steps',type=int)
args.add_argument('--interval',type=int,nargs=2,metavar=('FIRST','STOP'))
args.add_argument('--chunk',type=int,default=8)
a=args.parse_args()
os.environ['NF_TABLE']=str(a.machine/'candidate.tm');os.environ['NF_TRACES']=str(a.machine/'traces.gz')
sys.path.insert(0,str(a.engine))
from kernel_pumps import *
tb=(a.machine/'candidate.tm').read_bytes()
cert=json.loads((a.machine/'boot.json').read_bytes())
if sha256(tb).hexdigest()!=cert['table_sha256']:raise RuntimeError('bootstrap table mismatch')
lines=tb.decode().splitlines(); names=sorted({line.split()[0] for line in lines[1:]})
ids={q:i for i,q in enumerate(names)}
arcs={(ids[q],int(b)):(int(w),{'L':-1,'R':1}[di],ids.get(j,-1))
      for line in lines[1:] for q,b,w,di,j in [line.split()]}
ticks=cert['steps'] if a.steps is None else a.steps
def scan():
    h=lo=hi=0;q=ids[lines[0].split()[-1]];di=1;ones=set()
    for i in range(ticks+1):
        if not i%a.chunk or i==ticks:yield i,h,q,di,tuple(sorted(ones)),lo,hi
        if i==ticks:break
        w,di,q=arcs[q,int(h in ones)]
        assert q>=0
        if w:ones.add(h)
        else:ones.discard(h)
        h+=di;lo=min(lo,h);hi=max(hi,h)
T=list(scan()); _,last_h,last_q,last_di,last_ones,lo,hi=T[-1]
if a.steps is None:
    assert (last_h,last_q,list(last_ones))==(cert['head'],ids['d:0'],cert['ones'])
lo-=2;hi+=2
first,stop=(0,ticks) if a.interval is None else a.interval
assert 0<=first<stop<=ticks and first%a.chunk==0 and (stop%a.chunk==0 or stop==ticks)
T=[row for row in T if first<=row[0]<=stop]
assert T[0][0]==first and T[-1][0]==stop
def snapshot_digest(row):
    return sha256(json.dumps(row[:5],separators=(',',':')).encode()).hexdigest()
zeroRay=lam([('zeroIndex',NAT)],Z)
def conf(j):
    i,h,q,di,ones,_,_=T[j];ones=set(ones)
    # Our fixed finite segment leaves the outer infinite zero rays untouched.
    ahead=range(h,hi+1) if di==1 else range(h,lo-1,-1)
    behind=range(h-1,lo-1,-1) if di==1 else range(h+1,hi+1)
    ray=lambda segment:word(''.join('1' if x in ones else '0' for x in segment),zeroRay)
    return F('cfg',num(q),num(int(di<0)),ray(ahead),ray(behind))
def assert_zero(e,n,name):
    # Prove each fixed all-zero initial ray really is zero at every index.
    i=V('i');ray=word('0'*n,zeroRay)
    empty=lam([('i',NAT)],REFL(NAT,Z))
    e.declare(PRE+name+'0',[],pi([('i',NAT)],EQ(NAT,ap(zeroRay,i),Z)),empty,theorem=True)
    for k in range(1,n+1):
        r=word('0'*k,zeroRay)
        pred=K(name+str(k-1))
        mot=lam([('j',NAT)],EQ(NAT,ap(r,V('j')),Z))
        proof=NREC(0,mot,REFL(NAT,Z),lam([('j',NAT),('IH',ap(mot,V('j')))],ap(pred,V('j'))),i)
        e.declare(PRE+name+str(k),[('i',NAT)],EQ(NAT,ap(r,i),Z),proof,theorem=True)
run=lambda t,z:F('iterate',CONFIG,K('step'),t,z)
with a.output.open('wb') as stream:
    e=Export(stream);arithmetic(e);pumping(e);words_and_composition(e);physical(e)
    assert_zero(e,max(hi+1,-lo),'startRay')
    for idx in range(len(T)):e.declare(PRE+'snap'+str(idx),[],CONFIG,conf(idx))
    def snap(i):return K('snap'+str(i))
    front=[]
    for i in range(len(T)-1):
        d=T[i+1][0]-T[i][0]
        e.declare(PRE+'hop'+str(i),[],EQ(CONFIG,run(num(d),snap(i)),snap(i+1)),REFL(CONFIG,snap(i+1)),theorem=True)
        front.append((i,i+1,num(d),K('hop'+str(i))))
    roundno=0
    while len(front)>1:
        nf=[]
        for k in range(0,len(front),2):
            if k+1==len(front):nf.append(front[k]);continue
            i,j,di,pa=front[k];jj,l,dj,pb=front[k+1];assert jj==j
            span=F('plus',di,dj)
            lemma='join'+str(roundno)+'_'+str(k)
            th=F('chain',CONFIG,K('step'),di,dj,snap(i),snap(j),snap(l),pa,pb)
            e.declare(PRE+lemma,[],EQ(CONFIG,run(span,snap(i)),snap(l)),th,theorem=True)
            nf.append((i,l,span,K(lemma)))
        front=nf;roundno+=1
    i,j,clock,theorem=front[0]
    e.declare(PRE+'boot',[],EQ(CONFIG,run(clock,snap(i)),snap(j)),theorem,theorem=True)
print(json.dumps(dict(ticks=stop-first,first=first,stop=stop,snapshots=len(T),span=[lo,hi],
                      initial_snapshot=snapshot_digest(T[0]),final_snapshot=snapshot_digest(T[-1]),
                      final_direction=T[-1][3],final_head=T[-1][1],table_sha256=sha256(tb).hexdigest(),export_sha256=sha256(a.output.read_bytes()).hexdigest())))
