"""Generate and kernel-check every signed register branch of one literal table."""
import argparse
import concurrent.futures
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('machine', type=Path)
parser.add_argument('traces', type=Path)
parser.add_argument('receipt', type=Path)
parser.add_argument('--jobs', type=int, default=2)
parser.add_argument('--chunk', type=int, default=48)
parser.add_argument('--checker', default='leanchecker-paranoid')
args = parser.parse_args()
machine = args.machine.resolve()
traces = args.traces.resolve()
sites = json.loads((machine/'source.sites.json').read_bytes())
table = machine/'candidate.tm'
data = json.loads(gzip.decompress(traces.read_bytes()))
def sha(content):
    return hashlib.sha256(content).hexdigest()
if sha(table.read_bytes())!=data['table'] or sha((machine/'source.sites.json').read_bytes())!=data['source']:
    raise ValueError('table/source hash mismatch')
from phase_contracts import expected_domains, structure
structure(sites)
expected=expected_domains(sites)
rows=[(t['pc'],t['mode'],t['zero']) for t in data['traces']]
if set(rows)!=expected or len(rows)!=len(expected):
    raise ValueError('duplicate or missing phase domain')
assert all(not t.get('cold',False) for t in data['traces'])

env=dict(os.environ,NF_TABLE=str(table),NF_TRACES=str(traces))
def check(lo):
    hi=min(lo+args.chunk,len(sites))
    with tempfile.TemporaryDirectory() as folder:
        proof=Path(folder)/'proof.ndjson'
        generated=subprocess.run([sys.executable,HERE/'kernel_branches.py',machine,proof,'--lo',str(lo),'--hi',str(hi)],env=env,check=True,capture_output=True,text=True)
        checked=subprocess.run([args.checker,'--from-export',proof],env=env,check=True,capture_output=True,text=True)
        report=checked.stdout+checked.stderr
        if 'accepts the solution' not in report: raise RuntimeError(report)
        print(f'{lo}..{hi}: {generated.stdout.strip()}; {report.strip()}',flush=True)
        return dict(first_pc=lo,past_last_pc=hi,export_sha256=sha(proof.read_bytes()),
                    branches=sum(lo<=r[0]<hi for r in rows),kernel=report.strip())
if args.chunk<=0 or args.jobs<=0: raise ValueError('positive chunk and job counts required')
with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
    result=list(pool.map(check,range(0,len(sites),args.chunk)))
args.receipt.write_text(json.dumps(dict(table=data['table'],source=data['source'],trace_sha256=sha(traces.read_bytes()),
    branch_theorems=sum(r['branches'] for r in result),intervals=result),indent=2)+'\n')
