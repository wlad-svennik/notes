"""Regenerate every phase proof with bounded memory and individually pinned receipts."""
from pathlib import Path
import argparse, gzip, hashlib, json, os, subprocess, sys, tempfile
from phase_contracts import structure, expected_domains
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('machine',type=Path);p.add_argument('traces',type=Path);p.add_argument('receipt',type=Path)
p.add_argument('--checker',type=Path,required=True);p.add_argument('--chunk',type=int,default=8)
p.add_argument('--resume',action='store_true');a=p.parse_args();assert a.chunk>0
machine=a.machine.resolve();trace=a.traces.resolve();checker=a.checker.resolve();out=a.receipt.resolve();out.parent.mkdir(parents=True,exist_ok=True)
intervals=out.with_suffix('.intervals');intervals.mkdir(exist_ok=True)
rows=json.loads((machine/'source.sites.json').read_bytes());cert=json.loads(gzip.decompress(trace.read_bytes()))
assert cert['table']==sha(machine/'candidate.tm') and cert['source']==sha(machine/'source.sites.json')
structure(rows);want=expected_domains(rows);actual=[(r['pc'],r['mode'],r['zero'])for r in cert['traces']]
assert set(actual)==want and len(actual)==len(want) and all(not r.get('cold',False)for r in cert['traces'])
engines={q.name:sha(q)for q in HERE.iterdir()if q.is_file()and(q.suffix=='.py'or q.name=='eq_nat_prelude.ndjson')}
pin={'table':cert['table'],'source':cert['source'],'traces':sha(trace),'checker':sha(checker),'engine':engines}
env=dict(os.environ,NF_TABLE=str(machine/'candidate.tm'),NF_TRACES=str(trace),COUNTER_ROLE='1',PYTHONDONTWRITEBYTECODE='1')
result=[]
for lo in range(0,len(rows),a.chunk):
 hi=min(lo+a.chunk,len(rows));path=intervals/f'{lo}-{hi}.json';number=sum(lo<=r[0]<hi for r in actual)
 if path.exists() and a.resume:
  item=json.loads(path.read_bytes());assert item['inputs']==pin and item['first_pc']==lo and item['past_last_pc']==hi and item['branches']==number and 'accepts the solution'in item['kernel'];print(f'{lo}..{hi}: validated prior interval receipt',flush=True)
 else:
  with tempfile.TemporaryDirectory(prefix='nf173-kernel-chunk-')as d:
   proof=Path(d)/'proof.ndjson'
   generated=subprocess.run([sys.executable,str(HERE/'kernel_branches.py'),str(machine),str(proof),'--lo',str(lo),'--hi',str(hi)],env=env,check=True,capture_output=True,text=True)
   checked=subprocess.run([str(checker),'--from-export',str(proof)],env=env,check=True,capture_output=True,text=True)
   message=checked.stdout+checked.stderr;assert 'accepts the solution'in message
   item={'inputs':pin,'first_pc':lo,'past_last_pc':hi,'branches':number,'export_sha256':sha(proof),'kernel':message.strip(),'generator_report':generated.stdout.strip()}
   path.write_text(json.dumps(item,indent=2)+'\n')
   print(f'{lo}..{hi}: {generated.stdout.strip()}; {message.strip()}',flush=True)
 result.append(item)
assert sum(r['branches']for r in result)==len(want)
out.write_text(json.dumps({'table':cert['table'],'source':cert['source'],'trace_sha256':sha(trace),'branch_theorems':len(want),'intervals':result},indent=2)+'\n')
print('PASS all phase theorems freshly generated and checked, except explicitly validated resume receipts when requested.',flush=True)
