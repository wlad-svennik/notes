"""Independently kernel-check contiguous exact boot segments and join their literal endpoints."""
import argparse,concurrent.futures,hashlib,json,subprocess,tempfile,sys
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('engine',type=Path);ap.add_argument('machine',type=Path);ap.add_argument('out',type=Path);ap.add_argument('--checker',required=True);ap.add_argument('--jobs',type=int,default=3);ap.add_argument('--segment',type=int,default=1024)
a=ap.parse_args();here=Path(__file__).resolve().parent; a.out.mkdir(exist_ok=True,parents=True)
total=json.loads((a.machine/'boot.json').read_text())['steps']
def check(i):
    j=min(i+a.segment,total);receipt=a.out/f'{i}-{j}.json'
    if receipt.exists():
        rec=json.loads(receipt.read_text());assert 'accepts' in rec['kernel'];return rec
    with tempfile.TemporaryDirectory() as f:
        path=Path(f)/'proof.ndjson'
        run=subprocess.run([sys.executable,here/'boot_kernel.py',a.engine,a.machine,path,'--interval',str(i),str(j)],capture_output=True,check=True,text=True)
        rec=json.loads(run.stdout)
        proc=subprocess.run([a.checker,'--from-export',path],capture_output=True,check=True,text=True)
        rec['kernel']=(proc.stdout+proc.stderr).strip();assert 'accepts the solution' in rec['kernel']
        receipt.write_text(json.dumps(rec)+'\n')
        print(i,j,rec['kernel'],flush=True)
        return rec
with concurrent.futures.ThreadPoolExecutor(a.jobs) as pool:data=list(pool.map(check,range(0,total,a.segment)))
assert all(x['stop']==y['first'] and x['final_snapshot']==y['initial_snapshot'] for x,y in zip(data,data[1:]))
assert all(x['span']==data[0]['span'] and x['table_sha256']==data[0]['table_sha256'] for x in data)
assert sum(x['ticks'] for x in data)==total and data[0]['first']==0
(a.out/'verified.json').write_text(json.dumps(dict(table_sha256=data[0]['table_sha256'],ticks=total,segments=len(data),segments_sha256=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest(),intervals=data),indent=2)+'\n')
