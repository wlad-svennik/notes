"""Symbolic macro simulation of a literal binary proof-search table.

Literal bits and independent powers of fixed binary words form the tape. A
finite window trace carrying an identical boundary context across one copy
of a word certifies all copy counts by natural-number induction.
"""
from __future__ import annotations

import argparse
import bisect
import gzip
from collections import Counter, deque
from dataclasses import dataclass
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
from time import monotonic
import sys
import os
COUNTER=int(os.environ.get("COUNTER_ROLE","0"))

if len(sys.argv)<2:
    raise SystemExit("Usage: python3 symbolic_frames.py MACHINE_DIR [--write TRACE.gz]")
MACHINE_DIR = Path(sys.argv.pop(1)).resolve()
TABLE_HASH = sha256((MACHINE_DIR/'candidate.tm').read_bytes()).hexdigest()
PROGRAM_HASH = sha256((MACHINE_DIR/'source.sites.json').read_bytes()).hexdigest()
REGISTER_ORDER = (2, 8, 1, 4, 3, 7, 0, 5, 6)
NVAR = 11

@dataclass(frozen=True, slots=True)
class Repetition:
    index: int
    word: str

def flip(t):
    if isinstance(t, str):
        return t
    return Repetition(t.index, t.word[::-1])

def get(file, digest):
    data=(MACHINE_DIR/file).read_bytes()
    if sha256(data).hexdigest()!=digest:
        raise ValueError(f'wrong {file}')
    return data

lines=get('candidate.tm', TABLE_HASH).decode().splitlines()
names=sorted({line.split()[0] for line in lines[1:]})
ids={q:i for i,q in enumerate(names)}
matrix=[None]*(2*len(names))
for line in lines[1:]:
    q,b,w,d,p=line.split()
    if b not in ('0','1') or w not in ('0','1') or d not in ('L','R') or (p not in ids and p!='halt'):
        raise ValueError(line)
    if matrix[2*ids[q]+int(b)] is not None:
        raise ValueError('duplicate transition')
    matrix[2*ids[q]+int(b)]=(w, 1 if d=='R' else -1, ids.get(p,-1))
if None in matrix or lines[0] not in ('#! start k:74',):
    raise ValueError('table size or start')
sites=json.loads(get('source.sites.json', PROGRAM_HASH))
paths=[int('1'+p,2) for p,_,_ in sites]
width=max(p.bit_length() for p in paths)
keys=[p<<(width-p.bit_length()) for p in paths]
if keys!=sorted(keys) or len(set(keys))!=len(keys):
    raise ValueError('unordered or repeated addresses')
GAP = 49

def transfer(i,zero):
    p=paths[i]
    _,op,arg=sites[i]
    def cut(p,side):
        while p>1 and p%2!=side: p>>=1
        if p<=1:
            raise ValueError(('illegal branch',i,side))
        return p>>1
    if op=='CD' and zero and p%2: return None,False
    if op=='CD' and zero: p=cut(p,0)
    if op in ('CC','CB'):
        for _ in range(arg): p=cut(p,int(op=='CC'))
    shifted=False
    if op!='CC':
        while p>1 and p%2: p>>=1
        if p==1: shifted=True
        else: p+=1
    k=bisect.bisect_left(keys,p<<(width-p.bit_length()))
    if k>=len(paths) or paths[k]>>(paths[k].bit_length()-p.bit_length())!=p:
        raise ValueError(('no destination',i,p))
    return k,shifted

def frame(i,runs,spare_offset=0,gap_offset=0):
    path=sites[i][0]
    gap=GAP+gap_offset-len(path)
    assert gap>=8
    out=list('1'+path+'0'*(gap-5))+[Repetition(9,'0')]+list('000001')
    for r in REGISTER_ORDER:
        minimum,var=runs[r]
        # Field word is 0 followed by stored+1 many ones. Place the
        # varying run between mandatory boundary cells where available.
        assert minimum>=0
        out+=list('0'+'1'*minimum)
        if var: out.append(Repetition(r,'1'))
        out.append('1')
    out+=list('01'*12)+[Repetition(10,'01')]+list('01'*(12+spare_offset))
    return out

def poscoeff():
    return [0]*(1+NVAR)

def rays(word):
    # Root d:0 starts one cell after the first bit.
    return list(reversed(word[:1])), list(word[1:])

def literal_context(ray, limit):
    context=[]
    for z in ray:
        if not isinstance(z,str):
            break
        context.append(z)
        if len(context)==limit:
            break
    else:
        context+=['0']*(limit-len(context))
    return ''.join(context[::-1])

@lru_cache(maxsize=20000)
def pump(q,direction,context,unit):
    # Try progressively larger behind-head contexts, retaining the
    # shortest explicit invariant C with C u -> v C.
    for k in range(len(context)+1):
        c=context[-k:] if k else ''
        tmp=list(c+unit)
        pos=k
        state=q
        for step in range(1,1000):
            write,move,state=matrix[2*state+int(tmp[pos])]
            tmp[pos]=write
            pos+=move*direction
            if state<0 or pos<0:
                break
            if pos==len(tmp):
                if state==q and ''.join(tmp[len(unit):])==c:
                    return c,''.join(tmp[:len(unit)]),step
                break
    return None

def canon(ray):
    """Move each fixed-word power left across compatible literal bits."""
    out=[]
    for t in ray:
        if isinstance(t,str):
            out.append(t)
        else:
            right=[]
            w=t.word
            while out and isinstance(out[-1],str) and out[-1]==w[-1]:
                bit=out.pop()
                right.append(bit)
                w=bit+w[:-1]
            out.append(Repetition(t.index,w))
            out.extend(reversed(right))
    while out and out[-1]=='0':
        out.pop()
    return out

def split_at_head(left,right,orient):
    if orient==1:
        return list(left),list(right)
    # At a leftward crossing, head is the first element of left.
    # Our endpoints always have a known first bit (the address begins
    # after the guard), so this reorientation does not split powers.
    ll=deque(left); bit=ll.popleft() if ll else '0'
    if not isinstance(bit,str):
        raise RuntimeError(('endpoint head on unpeeled repetition',bit))
    return list(ll),[bit]+list(right)

def branch(i,zero=False,cold=False,trace=None,runs_override=None,endpoint=None):
    path,kind,arg=sites[i]
    runs=[(1,True) for j in range(9)]
    if cold: runs[COUNTER]=(0,False)
    if kind=='CD':
        if cold and arg==COUNTER: return ('excluded',)
        runs[arg]=(1,False) if zero else (2,True)
    if runs_override is not None: runs=list(runs_override)
    before=frame(i,runs)
    dest,shifted=transfer(i,zero) if endpoint is None else endpoint[:2]
    goal_left=goal_right=None
    displacement=-int(shifted)
    if dest is not None:
        if endpoint is None:
            rr=list(runs)
            if kind=='CI': rr[arg]=(rr[arg][0]+1,rr[arg][1])
            if kind=='CD' and not zero: rr[arg]=(rr[arg][0]-1,rr[arg][1])
            spare_offset=int(kind=='CI')
            gap_offset=int(kind=='CD' and not zero)+int(shifted)
        else:
            rr,spare_offset,gap_offset=endpoint[2:]
        after=frame(dest,rr,spare_offset,gap_offset)
        goal_left,goal_right=map(canon,rays(after))
    left,right=map(deque,rays(before))
    orient=1; position=poscoeff(); time=poscoeff(); used=[]
    q=ids['d:0']
    for step in range(3000):
        if q<0:
            if dest is None: return ('halt',time,tuple(used))
            return ('early halt',dest)
        if step and q==ids['d:0']:
            if dest is not None:
                atleft,atright=split_at_head(left,right,orient)
                # Absolute position tracked relative to the initial head.
                if position==[displacement]+[0]*NVAR and canon(atleft)==goal_left and canon(atright)==goal_right:
                    return ('live',time,tuple(used))
            # d:0 is also an internal return state. Only a matching full
            # boundary is a success.
        ahead,behind=(right,left) if orient==1 else (left,right)
        token=ahead[0] if ahead else '0'
        if not isinstance(token,str):
            c=literal_context(behind,12)
            proof=pump(q,orient,c,token.word)
            if not proof and len(ahead)>1 and ahead[1]==token.word[0]:
                # u^n x = x (rot(u))^n when u starts with x.
                ahead.popleft(); known=ahead.popleft()
                ahead.appendleft(Repetition(token.index,token.word[1:]+known))
                ahead.appendleft(known)
                if trace is not None: trace.append(("rotate",))
                continue
            if not proof:
                return ('stuck',names[q],orient,token,c,tuple(list(ahead)[:12]),step)
            ctx,result,n=proof
            # Transform left context C and u^n into v^n C, mirroring
            # words in the behind ray.
            ahead.popleft()
            for _ in ctx:
                if behind: behind.popleft()
            behind.appendleft(Repetition(token.index,result[::-1]))
            for bit in ctx: behind.appendleft(bit)
            time[token.index+1]+=n; position[token.index+1]+=len(token.word)*orient
            used.append((q,orient,ctx,token.word,result,n))
            if trace is not None: trace.append(("pump",used[-1]))
            continue
        if trace is not None:
            if trace and trace[-1][0]=="steps": trace[-1]=("steps",trace[-1][1]+1)
            else: trace.append(("steps",1))
        bit=ahead.popleft() if ahead else '0'
        write,move,q=matrix[2*q+int(bit)]
        time[0]+=1;position[0]+=move
        if move==orient: behind.appendleft(write)
        else:
            ahead.appendleft(write)
            orient=-orient
    return ('overflow',)

def write_certificate(output):
    pumps = []
    pump_indices = {}
    traces = []
    for cold in (False,True):
        for pc,(_,kind,arg) in enumerate(sites):
            for zero in ((False,True) if kind=="CD" else (False,)):
                if cold and kind=="CD" and arg==COUNTER: continue
                history=[]
                result=branch(pc,zero,cold,history)
                if result[0] not in ("live","halt"):
                    raise RuntimeError((pc,cold,zero,result))
                instructions=[]
                for act in history:
                    if act[0]=="steps":
                        instructions.append(act[1])
                    elif act[0]=="rotate":
                        instructions.append(0)
                    else:
                        item=act[1]
                        if item not in pump_indices:
                            pump_indices[item]=len(pumps)
                            pumps.append(item)
                        instructions.append(-1-pump_indices[item])
                traces.append({"pc":pc,"cold":cold,"zero":zero,"actions":instructions,"clock":result[1]})
    cert={"format":"nf-symbolic-frames-v1","table":TABLE_HASH,"source":PROGRAM_HASH,
          "base_gap":GAP,"pumps":[{"q":q,"dir":d,"context":c,"unit":u,"output":v,"ticks":n}
                   for q,d,c,u,v,n in pumps],"traces":traces}
    payload=json.dumps(cert,separators=(",",":")).encode()
    raw=gzip.compress(payload,compresslevel=9,mtime=0)
    output.write_bytes(raw)
    print(json.dumps({"branches":len(traces),"pumps":len(pumps),"actions":sum(len(t["actions"]) for t in traces),
        "uncompressed_bytes":len(payload),"compressed_bytes":len(raw),"sha256":sha256(raw).hexdigest()}))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--limit',type=int,default=len(sites))
    parser.add_argument('--pc',type=int)
    parser.add_argument('--cold',action='store_true')
    parser.add_argument('--write',type=Path)
    args=parser.parse_args()
    if args.write:
        write_certificate(args.write)
        return
    start=monotonic(); counts=Counter(); fail=Counter(); examples={}
    indices=[args.pc] if args.pc is not None else range(args.limit)
    for i in indices:
        path,op,arg=sites[i]
        for zero in ([False,True] if op=='CD' else [False]):
            res=branch(i,zero=zero,cold=args.cold)
            counts[res[0]]+=1
            if res[0] not in ('live','halt','excluded'):
                key=res[:3] if res[0]=='stuck' else res[:1]
                fail[key]+=1;examples.setdefault(key,(i,zero,res))
            if args.pc is not None: print(i,zero,res[:2],res[2:5] if res[0]=='stuck' else '')
    print('seconds',round(monotonic()-start,3),'counts',counts)
    for key,v in fail.most_common(12): print(v,examples[key])

if __name__=='__main__': main()
