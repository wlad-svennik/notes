"""Independent universal physical replay for pure NF173 phases.

Does not import the producer, producer contracts, or symbolic engine.  Tape
ray equality uses the baseline independent exact dyadic-polynomial checker.
Source reachability of the displayed phase guards is a separate obligation.
"""
from collections import Counter, deque
from pathlib import Path
import argparse, gzip, hashlib, json, time
import independent_frames as F

TABLE_SHA='ca0c0924b4f4008b19fd2b63f5c07b244c4573ad338dcd5b8267cf2e7a02990a'
SOURCE_SHA='ce0fb9873e0546d3c691c50ed7f1ec1f04729e5fc961bc6e24f825a35e1cb702'
BORROW=2913

def digest(raw): return hashlib.sha256(raw).hexdigest()

def reconstruct_source(sites):
    edges=F.flow(sites)
    n=len(sites)
    heads=[]
    for h in range(n-2):
        if sites[h][1:]!=['CD',3] or sites[h+1][1:]!=['CI',4] or sites[h+2][1]!='CC':
            continue
        wanted={(h,False):(h+1,0),(h,True):((h+3)%n,int(h+3==n)),
                (h+1,False):(h+2,0),(h+2,False):(h,0)}
        if all(edges[k]==v for k,v in wanted.items()): heads.append(h)
    assert len(heads)==29 and BORROW in heads
    for h in heads:
        for (caller,_),target in edges.items():
            if target is not None and target[0] in (h+1,h+2):
                assert caller in (h,h+1,h+2)
    assert sites[BORROW-1][1:]==['CI',4]
    assert edges[BORROW-1,False]==(BORROW,0)
    heads.remove(BORROW)
    excluded={pc for h in heads for pc in (h,h+1,h+2)}|{BORROW+1,BORROW+2}
    domains={(pc,'ordinary',zero) for pc,(_,op,_) in enumerate(sites) if pc not in excluded
             for zero in ((False,True) if op=='CD' else (False,))}
    for h in heads:
        domains.update(((h,'entry',False),(h,'entry',True),(h+1,'defer',False),
                        (h+2,'tail',False),(h+2,'tail',True)))
    domains.add((BORROW+1,'borrow',False))
    return edges,heads,domains

def contract(sites,edges,heads,tr):
    """Natural register values are offset plus an independent natural variable."""
    pc,mode,zero=tr['pc'],tr['mode'],tr['zero']
    assert type(zero) is bool and tr['cold'] is False
    values=[(0,True)]*9
    gap=spares=wrap=0
    op,arg=sites[pc][1:]
    if mode in ('ordinary','entry'):
        if mode=='entry':
            assert pc in heads
            values[1]=(1,True)
            values[7]=(0,False)
            if not zero:values[4]=(0,False)
        assert not zero or op=='CD'
        if op=='CD':values[arg]=(0,False) if zero else (1,True)
        after=list(values)
        if op=='CI':
            after[arg]=(values[arg][0]+1,values[arg][1]);spares=1
        elif op=='CD' and not zero:
            after[arg]=(values[arg][0]-1,values[arg][1]);gap=1
        edge=edges[pc,zero]
        dest,wrap=(None,0) if edge is None else edge
    elif mode=='defer':
        assert pc-1 in heads and not zero
        values[1]=(1,True)
        values[4]=values[7]=(0,False)
        after=list(values)
        dest=pc+1
    elif mode=='tail':
        assert pc-2 in heads
        values[1]=(1,True)
        values[7]=(0,False)
        values[3]=(0,False) if zero else (1,True)
        after=list(values)
        after[4]=(1,True)
        if not zero:
            after[3]=(0,True);gap=1
        spares=1
        dest=(pc+1)%len(sites) if zero else pc
        wrap=int(zero and pc+1==len(sites))
    elif mode=='borrow':
        assert pc==BORROW+1 and not zero
        after=list(values)
        dest=BORROW-1
    else:raise AssertionError(mode)
    assert tr['runs']==[[v+1,b] for v,b in values]
    return values,after,dest,wrap,gap+wrap,spares

def check(folder,trace_name='traces.gz'):
    began=time.monotonic()
    tb=(folder/'candidate.tm').read_bytes()
    so=(folder/'source.sites.json').read_bytes()
    trace_raw=(folder/trace_name).read_bytes()
    assert digest(tb)==TABLE_SHA and digest(so)==SOURCE_SHA
    table,ids,start=F.read_table(tb)
    assert len(table)==346 and len(ids)==174
    names={i:q for q,i in ids.items()}
    sites=json.loads(so)
    edges,heads,domains=reconstruct_source(sites)
    cert=json.loads(gzip.decompress(trace_raw))
    assert cert['format']=='nf-symbolic-phases-v1'
    assert cert['table']==TABLE_SHA and cert['source']==SOURCE_SHA
    assert cert['base_gap']==49 and cert['heads']==heads and cert['borrow_head']==BORROW
    observed=Counter((t['pc'],t['mode'],t['zero']) for t in cert['traces'])
    assert set(observed)==domains and all(c==1 for c in observed.values())
    assert len(domains)==3932
    pumps=cert['pumps']
    pump_edges=[]
    for p in pumps:
        assert set(p)=={'q','dir','context','unit','output','ticks'}
        assert type(p['ticks']) is int and p['ticks']>0
        F.check_pump(table,p)
        tape=list(p['context']+p['unit'])
        h=len(p['context']);q=p['q'];seen=set()
        for _ in range(p['ticks']):
            seen.add((q,tape[h]))
            w,d,q=table[q,tape[h]];tape[h]=w;h+=d*p['dir']
        pump_edges.append(seen)
    literal_steps=pump_uses=rotations=halts=0
    used_edges=set()
    phase_edges={}
    total_modes=Counter()
    for number,tr in enumerate(cert['traces']):
        pc,mode,zero=tr['pc'],tr['mode'],tr['zero']
        values,after,dest,wrap,gap,spares=contract(sites,edges,heads,tr)
        word=F.frame(sites[pc],values,cert['base_gap'],0)
        sides={-1:deque(word[:1]),1:deque(word[1:])}
        state=ids['d:0'];facing=1
        position=[0]*12;clock=[0]*12;local=set()
        for action in tr['actions']:
            assert type(action) is int and state>=0
            if action>0:
                for _ in range(action):
                    ahead=sides[facing]
                    bit=F.take(ahead)
                    assert isinstance(bit,str) and state>=0
                    local.add((state,bit))
                    write,move,state=table[state,bit]
                    position[0]+=move;clock[0]+=1
                    if move==facing:sides[-facing].appendleft(write)
                    else:ahead.appendleft(write);facing=move
                literal_steps+=action
            elif action==0:
                side=sides[facing]
                ix,unit=side.popleft()
                assert 0<=ix<=10
                bit=side.popleft()
                assert bit==unit[0]
                side.extendleft(((ix,unit[1:]+bit),bit))
                rotations+=1
            else:
                pi=-1-action
                assert 0<=pi<len(pumps)
                rule=pumps[pi]
                assert (state,facing)==(rule['q'],rule['dir'])
                ix,unit=sides[facing].popleft()
                assert 0<=ix<=10 and unit==rule['unit']
                tail=sides[-facing]
                for b in reversed(rule['context']):assert F.take(tail)==b
                tail.appendleft((ix,rule['output'][::-1]))
                tail.extendleft(rule['context'])
                position[ix+1]+=facing*len(unit)
                clock[ix+1]+=rule['ticks']
                local.update(pump_edges[pi]);pump_uses+=1
        assert clock==tr['clock'] and clock[0]>0 and all(c>=0 for c in clock)
        used_edges.update(local);total_modes[mode]+=1
        if mode!='ordinary':
            phase_edges[f'{pc}/{mode}/{int(zero)}']=[[names[q],int(b)] for q,b in sorted(local)]
        if dest is None:
            assert state==-1
            halts+=1
            continue
        assert state==ids['d:0'] and position==[-wrap]+[0]*11,(number,'head')
        expected=F.frame(sites[dest],after,cert['base_gap']+gap,spares)
        if facing<0:
            bit=F.take(sides[-1]);assert isinstance(bit,str);sides[1].appendleft(bit)
        assert F.ray_value(tuple(sides[-1]))==F.ray_value(tuple(expected[:1])),(number,'left ray')
        assert F.ray_value(tuple(sides[1]))==F.ray_value(tuple(expected[1:])),(number,'right ray')
    boot_steps=F.exact_boot(folder/'boot.json',table,ids,start,sites,cert['base_gap'])
    boot=json.loads((folder/'boot.json').read_bytes())
    assert boot_steps==67998 and boot['registers']==[0,1,0,0,0,0,0,0,0]
    assert boot['gap']==55 and boot['spares']==30
    tape=set();q=start;h=0;boot_edges=set()
    for _ in range(boot_steps):
        bit=str(int(h in tape));boot_edges.add((q,bit))
        w,d,q=table[q,bit]
        if w=='1':tape.add(h)
        else:tape.discard(h)
        h+=d
    assert q==ids['d:0'] and h==boot['head'] and sorted(tape)==boot['ones']
    all_edges=used_edges|boot_edges
    named=lambda edges:[[names[q],int(b)] for q,b in sorted(edges)]
    edge_receipt={'table_sha256':TABLE_SHA,'source_sha256':SOURCE_SHA,
                  'trace_sha256':digest(trace_raw),
                  'warm_rows':named(used_edges),'blank_rows':named(boot_edges),
                  'combined_rows':named(all_edges),
                  'uncovered_rows':named(set(table)-all_edges)}
    (folder/'all-edge-coverage.json').write_text(json.dumps(edge_receipt,indent=2)+'\n')
    receipt={'status':'PASS','scope':'Universal warm physical phase contracts and exact blank boot; source phase-guard reachability and source/phase arithmetic correspondence are separate obligations.',
             'states':len(table)//2,'rows':len(table),'source_sites':len(sites),
             'domains':len(domains),'modes':dict(total_modes),'transfer_heads':heads,'borrow_head':BORROW,
             'pumps':len(pumps),'literal_symbolic_steps':literal_steps,'pump_uses':pump_uses,
             'rotations':rotations,'halting_domains':halts,'boot_steps':boot_steps,
             'used_warm_rows':len(used_edges),'used_blank_rows':len(boot_edges),'used_combined_rows':len(all_edges),
             'table_sha256':TABLE_SHA,'source_sha256':SOURCE_SHA,'trace_sha256':digest(trace_raw),
             'checker_sha256':digest(Path(__file__).read_bytes()),
             'ray_checker_sha256':digest((Path(__file__).parent/'independent_frames.py').read_bytes()),
             'seconds':time.monotonic()-began}
    (folder/'phase-edge-coverage.json').write_text(json.dumps(phase_edges,indent=2)+'\n')
    (folder/'independent-phase-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('folder',type=Path)
    ap.add_argument('--trace',default='traces.gz')
    a=ap.parse_args()
    print(json.dumps(check(a.folder,a.trace),indent=2))
