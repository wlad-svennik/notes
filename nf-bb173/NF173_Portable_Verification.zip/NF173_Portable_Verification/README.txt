PURE NF: PORTABLE 173-STATE IMPLEMENTATION AUDIT
R. Gutin and E. Glazer

Run with Python 3.10 or newer:

    python3 verify.py

This independently replays all 3,932 natural-input physical domains, checks the
source guard fixed point and every changed-phase interface, reconstructs the
literal two-target patch, verifies all blank-start transitions, and regenerates
the physical certificate byte for byte. It also freshly kernel-checks the 16
generic natural-induction arithmetic theorems. It requires no third-party Python
packages, Lean frontend, or network access.

For fresh standalone Lean-kernel replay of every physical phase and every
blank-start transition:

    python3 verify.py --kernel

The supplied Linux x86-64 kernel executable is hash-pinned. If supplying another
copy of the same executable, use --checker /absolute/path/leanchecker-paranoid.
The full check uses one worker and proof chunks of eight source PCs to limit memory. Temporary
raw exports are deleted after verification; their hashes and accepted theorem
counts are retained in kernel/phases.json and kernel/boot/verified.json.

Files
-----
machine/: exact 173-state table, unchanged source, startup frame and trace.
reference/: exact 174-state predecessor table and identical source.
physical/: producer and independent checker; no producer contract is trusted
           by the independent replay.
arithmetic/: generic transfer-loop natural-induction proof and source binding.
source/: independent source CFG, ingress/guard fixed point and interface audit.
kernel/: raw proof exporters, equality/natural-number prelude, pinned checker,
         complete accepted physical/bootstrap receipts.
Verification_Scope.txt: all-natural scope, arithmetic composition interface,
                        inherited pure-NF calibration boundary.

The table starts at k:74 on a two-way infinite all-zero binary tape. There are
173 working states, 346 transition arms, and a separate halting state. It reaches
the canonical source PC0 frame in 67,998 transitions with R1=1, all other
registers zero, gap 55 and 30 zero spare fields.

The change preserves the literal source and its inherited pure-NF calibration.
It imports no Axiom of Counting. Generic loop arithmetic induction and the
whole-program written composition are provided in arithmetic/ and Composition_Proof.txt. This audit does not claim a single end-to-end Lean theorem connecting
the entire literal machine to Quine's NF; that inherited formalization boundary
is stated in Verification_Scope.txt.
