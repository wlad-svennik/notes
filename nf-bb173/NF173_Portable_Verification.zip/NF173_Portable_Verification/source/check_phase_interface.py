"""Check the exported phase specification against independent affine formulas.

The finitely many source PCs are enumerated, but every register domain/output
is compared as an exact affine-natural expression, not by testing register
values. Physical realization of these formulas is certified separately.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json
from check_source_composition import source_flow,EXPECTED_HEADS,BORROW,SOURCE_SHA,TABLE_SHA

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--phase-spec',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();assert digest(a.source)==SOURCE_SHA
 rows=json.loads(a.source.read_bytes());edges=source_flow(rows);n=len(rows)
 spec=importlib.util.spec_from_file_location('checked_external_phase_spec',a.phase_spec);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 assert tuple(mod.HEADS)==EXPECTED_HEADS and mod.BORROW_HEAD==BORROW
 excluded={j for h in EXPECTED_HEADS for j in range(h,h+3)}|{BORROW+1,BORROW+2}
 expected={(pc,'ordinary',z)for pc,(_,op,k)in enumerate(rows)if pc not in excluded for z in((False,True)if op=='CD'else(False,))}
 for h in EXPECTED_HEADS:expected|={(h,'entry',False),(h,'entry',True),(h+1,'defer',False),(h+2,'tail',False),(h+2,'tail',True)}
 expected.add((BORROW+1,'borrow',False));assert set(mod.expected_domains(rows))==expected
 assert mod.structure(rows)==edges
 phase_edges={};by_mode={};checks=0
 for pc,mode,zero in sorted(expected):
  inp=[(1,True)for _ in range(9)];wrap=gap=spare=0
  if mode in('ordinary','entry'):
   _,op,k=rows[pc]
   if mode=='entry':
    inp[1]=(2,True);inp[7]=(1,False)
    if not zero:inp[4]=(1,False)
   if op=='CD':inp[k]=(1,False)if zero else(2,True)
   out=list(inp);edge=edges[pc,zero];dest,wrap=(None,0)if edge is None else edge
   if op=='CI':out[k]=(inp[k][0]+1,inp[k][1]);spare=1
   elif op=='CD'and not zero:out[k]=(inp[k][0]-1,inp[k][1]);gap=1
  elif mode=='defer':
   inp[1]=(2,True);inp[4]=inp[7]=(1,False);out=list(inp);dest=pc+1
  elif mode=='tail':
   inp[1]=(2,True);inp[7]=(1,False);inp[3]=(1,False)if zero else(2,True);out=list(inp)
   out[4]=(2,True);spare=1
   if zero:dest=(pc+1)%n;wrap=int(pc+1==n)
   else:out[3]=(1,True);dest=pc;gap=1
  else:assert mode=='borrow';out=list(inp);dest=BORROW-1
  want=(inp,out,dest,wrap,gap+wrap,spare)
  actual=mod.shape(rows,edges,{'pc':pc,'zero':zero,'mode':mode,'cold':False});assert actual==want,(pc,mode,zero,actual,want)
  by_mode[mode]=by_mode.get(mode,0)+1;checks+=1;phase_edges.setdefault(pc,set()).add(dest)
 # This overapproximates control reachability by allowing every registered
 # zero/positive branch. In particular, the dropped ordinary CC is unreachable.
 seen={0};todo=[0]
 while todo:
  pc=todo.pop()
  for dest in phase_edges.get(pc,set()):
   if dest is not None and dest not in seen:seen.add(dest);todo.append(dest)
 assert BORROW+2 not in seen
 assert all(pc in phase_edges for pc in seen)
 receipt={'status':'PASS_EXACT_PHASE_INTERFACE','source_sha256':SOURCE_SHA,'candidate_sha256':TABLE_SHA,'phase_spec_sha256':digest(a.phase_spec),'checked_affine_domains':checks,'by_mode':by_mode,'reachable_phase_PCs_overapprox':len(seen),'unreachable_borrow_tail_PC':BORROW+2,'ordinary_borrowed_increment_PC':BORROW-1,'ordinary_borrowed_increment_domain':'all nine registers independently arbitrary naturals; no old outer-invariant guard','scope':'Exact comparison of affine-natural phase input/output domains, endpoints, wrap, and resource deltas for every expected source-domain packet; independent source-side specification check, not physical replay.'}
 a.out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__':main()
