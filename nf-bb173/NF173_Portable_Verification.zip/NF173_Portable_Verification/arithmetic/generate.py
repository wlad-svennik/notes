"""Natural induction for a delayed-increment transfer and exact operation counts."""
from pathlib import Path
import hashlib,json
from export_syntax import C,V,Export,ap,arrow,lam,pi
HERE=Path(__file__).resolve().parent
OUT=HERE/'rotated_transfer.ndjson'
P='NFMachineRotatedTransfer.'
N=C('Nat');Z=C('Nat.zero');S=lambda x:ap(C('Nat.succ'),x)
Q=lambda x,y:ap(C('Eq',1),N,x,y)
Refl=lambda x:ap(C('Eq.refl',1),N,x)
n=V('n');d=V('d');k=V('k');ih=V('ih');g=V('g');s=V('s');w=V('w')
def call(name,*args):return ap(C(P+name),*args)
def trans(x,y,z,h,j):
    mot=lam([('ty',N),('th',Q(y,V('ty')))],Q(x,V('ty')))
    return ap(C('Eq.rec',0,1),N,y,mot,h,z,j)
def cong(x,y,h,f):
    mot=lam([('cy',N),('ch',Q(x,V('cy')))],Q(f(x),f(V('cy'))))
    return ap(C('Eq.rec',0,1),N,x,mot,Refl(f(x)),y,h)
def rec_nat(base,step,arg):
    return ap(C('Nat.rec',1),lam([('rk',N)],N),base,step,arg)
def rec_fn(base,step,arg):
    return ap(C('Nat.rec',1),lam([('rk',N)],arrow(N,N)),base,step,arg)
def induction(motive,base,step,arg):return ap(C('Nat.rec',0),motive,base,step,arg)
defs=[];theorems=[]
with OUT.open('wb') as stream:
    e=Export(stream)
    def define(name,params,typ,body):
        defs.append(P+name);e.declare(P+name,params,typ,body)
    def theorem(name,params,typ,proof):
        theorems.append(P+name);e.declare(P+name,params,typ,proof,theorem=True)

    # Ordinary addition is specified by add(a,0)=a; add(a,n+1)=succ(add(a,n)).
    define('add',[('a',N),('b',N)],N,
           rec_nat(V('a'),lam([('k',N),('ih',N)],S(ih)),V('b')))
    idfn=lam([('d',N)],d)
    shiftstep=lam([('k',N),('ih',arrow(N,N)),('d',N)],ap(ih,S(d)))
    # Standard source loop: decrement a positive donor, then increment destination.
    define('standard',[('n',N),('d',N)],N,ap(rec_fn(idfn,shiftstep,n),d))
    # Tail carries one pending increment, so even its zero case increments once.
    define('tail',[('n',N),('d',N)],N,ap(rec_fn(lam([('d',N)],S(d)),shiftstep,n),d))
    # Positive head decrements once, defers the increment, then invokes tail.
    headstep=lam([('k',N),('ih',arrow(N,N)),('d',N)],call('tail',k,d))
    define('rotated',[('n',N),('d',N)],N,ap(rec_fn(idfn,headstep,n),d))
    define('tailRemaining',[('n',N)],N,rec_nat(Z,lam([('k',N),('ih',N)],ih),n))
    define('rotatedRemaining',[('n',N)],N,
           rec_nat(Z,lam([('k',N),('ih',N)],call('tailRemaining',k)),n))
    define('tailIncrements',[('n',N)],N,rec_nat(S(Z),lam([('k',N),('ih',N)],S(ih)),n))
    define('tailDecrements',[('n',N)],N,rec_nat(Z,lam([('k',N),('ih',N)],S(ih)),n))
    define('rotatedIncrements',[('n',N)],N,
           rec_nat(Z,lam([('k',N),('ih',N)],call('tailIncrements',k)),n))
    define('rotatedDecrements',[('n',N)],N,
           rec_nat(Z,lam([('k',N),('ih',N)],S(call('tailDecrements',k))),n))
    define('rotatedGap',[('n',N),('g',N),('w',N)],N,
           call('add',call('add',g,call('rotatedDecrements',n)),w))
    define('rotatedSpares',[('n',N),('s',N)],N,
           call('add',s,call('rotatedIncrements',n)))

    # The step invokes the induction hypothesis at destination+1.
    mot=lam([('n',N)],pi([('d',N)],Q(call('standard',n,S(d)),S(call('standard',n,d)))))
    base=lam([('d',N)],Refl(S(d)))
    step=lam([('n',N),('ih',ap(mot,n)),('d',N)],ap(ih,S(d)))
    theorem('standard_commutes_succ',[],pi([('n',N),('d',N)],Q(call('standard',n,S(d)),S(call('standard',n,d)))),
            lam([('n',N)],induction(mot,base,step,n)))

    mot=lam([('n',N)],pi([('d',N)],Q(call('standard',n,d),call('add',d,n))))
    base=lam([('d',N)],Refl(d))
    p=call('standard_commutes_succ',n,d)
    j=cong(call('standard',n,d),call('add',d,n),ap(ih,d),S)
    p=trans(call('standard',n,S(d)),S(call('standard',n,d)),S(call('add',d,n)),p,j)
    step=lam([('n',N),('ih',ap(mot,n)),('d',N)],p)
    theorem('standard_is_add',[],pi([('n',N),('d',N)],Q(call('standard',n,d),call('add',d,n))),
            lam([('n',N)],induction(mot,base,step,n)))

    mot=lam([('n',N)],pi([('d',N)],Q(call('tail',n,d),call('standard',n,S(d)))))
    base=lam([('d',N)],Refl(S(d)))
    step=lam([('n',N),('ih',ap(mot,n)),('d',N)],ap(ih,S(d)))
    theorem('tail_is_one_pending_increment',[],pi([('n',N),('d',N)],Q(call('tail',n,d),call('standard',n,S(d)))),
            lam([('n',N)],induction(mot,base,step,n)))
    p=trans(call('tail',n,d),call('standard',n,S(d)),call('add',d,S(n)),
            call('tail_is_one_pending_increment',n,d),call('standard_is_add',S(n),d))
    theorem('tail_output',[('n',N),('d',N)],Q(call('tail',n,d),call('add',d,S(n))),p)

    mot=lam([('n',N)],pi([('d',N)],Q(call('rotated',n,d),call('standard',n,d))))
    base=lam([('d',N)],Refl(d))
    step=lam([('n',N),('ih',ap(mot,n)),('d',N)],call('tail_is_one_pending_increment',n,d))
    theorem('rotated_equals_standard',[],pi([('n',N),('d',N)],Q(call('rotated',n,d),call('standard',n,d))),
            lam([('n',N)],induction(mot,base,step,n)))
    p=trans(call('rotated',n,d),call('standard',n,d),call('add',d,n),
            call('rotated_equals_standard',n,d),call('standard_is_add',n,d))
    theorem('rotated_output',[('n',N),('d',N)],Q(call('rotated',n,d),call('add',d,n)),p)

    mot=lam([('n',N)],Q(call('add',Z,n),n))
    step=lam([('n',N),('ih',ap(mot,n))],cong(call('add',Z,n),n,ih,S))
    theorem('zero_add',[],pi([('n',N)],Q(call('add',Z,n),n)),
            lam([('n',N)],induction(mot,Refl(Z),step,n)))
    p=trans(call('rotated',n,Z),call('add',Z,n),n,call('rotated_output',n,Z),call('zero_add',n))
    theorem('rotated_empty_destination_output',[('n',N)],Q(call('rotated',n,Z),n),p)

    for name,target in [('tailRemaining',lambda n:Z),('tailIncrements',S),('tailDecrements',lambda n:n)]:
        mot=lam([('n',N)],Q(call(name,n),target(n)))
        base=Refl(target(Z))
        proof=ih if name=='tailRemaining' else cong(call(name,n),target(n),ih,S)
        step=lam([('n',N),('ih',ap(mot,n))],proof)
        theorem(name+'_exact',[],pi([('n',N)],Q(call(name,n),target(n))),lam([('n',N)],induction(mot,base,step,n)))

    for name,target in [('rotatedRemaining',lambda n:Z),('rotatedIncrements',lambda n:n),('rotatedDecrements',lambda n:n)]:
        mot=lam([('n',N)],Q(call(name,n),target(n)))
        base=Refl(Z)
        if name=='rotatedRemaining':proof=call('tailRemaining_exact',n)
        elif name=='rotatedIncrements':proof=call('tailIncrements_exact',n)
        else:proof=cong(call('tailDecrements',n),n,call('tailDecrements_exact',n),S)
        step=lam([('n',N),('ih',ap(mot,n))],proof)
        theorem(name+'_exact',[],pi([('n',N)],Q(call(name,n),target(n))),lam([('n',N)],induction(mot,base,step,n)))

    p=cong(call('rotatedDecrements',n),n,call('rotatedDecrements_exact',n),lambda a:call('add',call('add',g,a),w))
    theorem('rotated_gap_exact',[('n',N),('g',N),('w',N)],Q(call('rotatedGap',n,g,w),call('add',call('add',g,n),w)),p)
    p=cong(call('rotatedIncrements',n),n,call('rotatedIncrements_exact',n),lambda a:call('add',s,a))
    theorem('rotated_spares_exact',[('n',N),('s',N)],Q(call('rotatedSpares',n,s),call('add',s,n)),p)

manifest={'definitions':defs,'theorems':theorems,'theorem_count':len(theorems),
          'export_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'export_bytes':OUT.stat().st_size,
          'statement':'For every natural donor n and destination d, the rotated/deferred-increment transfer equals the standard transfer and outputs d+n; with empty destination it outputs n. Exactly n positive decrements and n increments occur. Gap/spare expressions agree including one common terminal wrap.',
          'scope':'Recursive arithmetic phase semantics and operation counts only. Candidate binary-table binding and recognition of these phases on tapes remain separate physical proof obligations.'}
OUT.with_suffix('.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
