"""Read-only portable replay of source binding and all arithmetic kernel terms."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    manifest=json.loads((HERE/'manifest.json').read_text())
    for rel,expected in manifest['sha256'].items():assert digest(HERE/rel)==expected,rel
    checker=Path(os.environ.get('LEAN_CHECKER',str(HERE.parent/'kernel/bin/leanchecker-paranoid')))
    if not checker.exists() and (HERE/'leanchecker-paranoid').exists():checker=HERE/'leanchecker-paranoid'
    assert digest(checker)==manifest['checker_sha256']
    spec=importlib.util.spec_from_file_location('independent_arithmetic_source_check',HERE/'check_source.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    source_receipt=module.audit(HERE/'source.sites.json',HERE/'phase_contracts.py')
    assert json.loads(json.dumps(source_receipt))==json.loads((HERE/'source_receipt.json').read_text())
    env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'}
    with tempfile.TemporaryDirectory(prefix='nf-rotated-transfer-') as tmp:
        work=Path(tmp)
        for name in ('generate.py','export_syntax.py','eq_nat_prelude.ndjson'):shutil.copy2(HERE/name,work/name)
        generated=subprocess.run([sys.executable,str(work/'generate.py')],text=True,capture_output=True,env=env)
        assert generated.returncode==0,generated.stderr
        export=work/'rotated_transfer.ndjson'
        assert digest(export)==manifest['kernel_export_sha256']
        run=subprocess.run([str(checker),'--from-export',str(export)],text=True,capture_output=True)
        assert run.returncode==0 and 'Lean default kernel accepts the solution' in run.stdout,(run.stdout,run.stderr)
    return {'status':'accepted','theorem_count':manifest['theorem_count'],
            'kernel_export_sha256':manifest['kernel_export_sha256'],'checker_sha256':manifest['checker_sha256'],
            'source_sha256':source_receipt['source_sha256'],'phase_contract_sha256':source_receipt['phase_contract_sha256'],
            'phase_cases':source_receipt['phase_contract_cases'],'rotated_heads':len(source_receipt['rotated_heads']),
            'borrow_head':source_receipt['borrow_head'],'scope':manifest['scope']}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);args=p.parse_args()
    result=main();text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if args.output:args.output.write_text(text)
    print(text,end='')
