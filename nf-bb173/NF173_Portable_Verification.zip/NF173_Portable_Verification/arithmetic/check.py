from pathlib import Path
import subprocess,hashlib,json,os
HERE=Path(__file__).resolve().parent
shared_checker=HERE.parent/'kernel/bin/leanchecker-paranoid'
default_checker=shared_checker if shared_checker.exists() else HERE/'leanchecker-paranoid'
checker=Path(os.environ.get('LEAN_CHECKER',str(default_checker)))
export=HERE/'rotated_transfer.ndjson'
expected='cd9a6ddb5fbf8f649c789dc905236e1ddee9fb32a323c141a4e63478f72e47b6'
assert hashlib.sha256(checker.read_bytes()).hexdigest()==expected
manifest=json.loads(export.with_suffix('.json').read_text())
assert hashlib.sha256(export.read_bytes()).hexdigest()==manifest['export_sha256']
run=subprocess.run([str(checker),'--from-export',str(export)],text=True,capture_output=True)
(HERE/'kernel.log').write_text(run.stdout+run.stderr)
receipt=dict(checker_sha256=expected,export_sha256=manifest['export_sha256'],returncode=run.returncode,stdout=run.stdout.strip(),theorem_count=manifest['theorem_count'])
(HERE/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert run.returncode==0 and 'Lean default kernel accepts the solution' in run.stdout
print(json.dumps(receipt,indent=2))
