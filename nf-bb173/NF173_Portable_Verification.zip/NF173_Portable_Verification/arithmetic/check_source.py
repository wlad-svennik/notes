"""Independent source-loop and phase-recurrence binding for the Nat induction."""
from pathlib import Path
import argparse,ast,hashlib,importlib.util,json
HERE=Path(__file__).resolve().parent
BASELINE='ce0fb9873e0546d3c691c50ed7f1ec1f04729e5fc961bc6e24f825a35e1cb702'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def edges(sites):
    n=len(sites);ranges={}
    for pc,(path,_,_) in enumerate(sites):
        for j in range(len(path)+1):ranges.setdefault(path[:j],[pc,pc])[1]=pc+1
    def cut(path,bit,k):
        for _ in range(k):path=path[:path.rindex(bit)]
        return path
    out={}
    for pc,(path,op,arg) in enumerate(sites):
        if op=='CI':out[pc,False]=((pc+1)%n,int(pc+1==n))
        elif op=='CD':
            out[pc,False]=((pc+1)%n,int(pc+1==n))
            if path.endswith('1'):out[pc,True]=None
            else:
                end=ranges[cut(path,'0',1)][1];out[pc,True]=(end%n,int(end==n))
        elif op=='CC':out[pc,False]=(ranges[cut(path,'1',arg)][0],0)
        elif op=='CB':
            end=ranges[cut(path,'0',arg)][1];out[pc,False]=(end%n,int(end==n))
        else:raise AssertionError(op)
    return out

def load_contract(path):
    tree=ast.parse(path.read_text());constants={}
    for node in tree.body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            name=node.targets[0].id
            if name in ('HEADS','BORROW_HEAD'):constants[name]=ast.literal_eval(node.value)
    spec=importlib.util.spec_from_file_location('reviewed_phase_contract',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return constants,module

def audit(source,contracts):
    assert digest(source)==BASELINE
    sites=json.loads(source.read_text());flow=edges(sites);n=len(sites)
    found=[]
    for h in range(n-2):
        if sites[h][1:]==['CD',3] and sites[h+1][1:]==['CI',4] and sites[h+2][1]=='CC':
            if (flow[h,False],flow[h+1,False],flow[h+2,False],flow[h,True])==(
                (h+1,0),(h+2,0),(h,0),((h+3)%n,int(h+3==n))):found.append(h)
    assert len(found)==29 and 2913 in found and 2973 in found
    ingress=[]
    for h in found:
        incoming=[(pc,zero,dest) for (pc,zero),dest in flow.items() if dest is not None and dest[0] in (h+1,h+2)]
        assert all(h<=pc<=h+2 for pc,_,_ in incoming)
        ingress.append({'head':h,'body_ingress_edges':incoming})
    assert sites[2912][1:]==['CI',4] and flow[2912,False]==(2913,0)
    assert sites[2914][1:]==['CI',4] and flow[2914,False]==(2915,0)
    assert flow[2915,False]==(2913,0) and flow[2913,True]==(2916,0)
    assert [(h,flow[h,True]) for h in found if flow[h,True][1]]==[(2973,(0,1))]

    constants,module=load_contract(contracts)
    heads=tuple(h for h in found if h!=2913)
    assert tuple(constants['HEADS'])==heads and constants['BORROW_HEAD']==2913
    assert module.structure(sites)==flow
    cases=0
    def check(pc,mode,zero,runs,after,dest,wrap,gap,spares):
        nonlocal cases
        actual=module.shape(sites,flow,{'pc':pc,'mode':mode,'zero':zero})
        expected=(runs,after,dest,wrap,gap,spares)
        assert actual==expected,(pc,mode,zero,actual,expected)
        cases+=1
    for h in heads:
        end,w=flow[h,True]
        for zero in (False,True):
            runs=[(1,True)]*9;runs[1]=(2,True);runs[7]=(1,False)
            runs[3]=(1,False) if zero else (2,True)
            if not zero:runs[4]=(1,False)
            after=list(runs)
            if not zero:after[3]=(1,True)
            check(h,'entry',zero,runs,after,end if zero else h+1,w if zero else 0,w if zero else 1,0)
        runs=[(1,True)]*9;runs[1]=(2,True);runs[4]=runs[7]=(1,False)
        check(h+1,'defer',False,runs,list(runs),h+2,0,0,0)
        for zero in (False,True):
            runs=[(1,True)]*9;runs[1]=(2,True);runs[7]=(1,False)
            runs[3]=(1,False) if zero else (2,True)
            after=list(runs);after[4]=(2,True)
            if not zero:after[3]=(1,True)
            check(h+2,'tail',zero,runs,after,end if zero else h+2,w if zero else 0,w if zero else 1,1)
    runs=[(1,True)]*9;after=list(runs);after[4]=(2,True)
    check(2912,'ordinary',False,runs,after,2913,0,0,1)
    for zero in (False,True):
        runs=[(1,True)]*9;runs[3]=(1,False) if zero else (2,True)
        after=list(runs)
        if not zero:after[3]=(1,True)
        check(2913,'ordinary',zero,runs,after,2916 if zero else 2914,0,0 if zero else 1,0)
    runs=[(1,True)]*9
    check(2914,'borrow',False,runs,list(runs),2912,0,0,0)
    assert cases==144
    return {'source_sha256':digest(source),'phase_contract_sha256':digest(contracts),
            'rotated_heads':list(heads),'borrow_head':2913,'literal_loop_count':len(found),
            'phase_contract_cases':cases,'sole_wrap_head':2973,'borrow_destination_domain':'arbitrary natural, including internal2912 visits',
            'body_ingress':ingress,
            'scope':'Literal source/CFG and exact affine phase contracts checked. No binary table or tape trace is checked by this script.',
            'kernel_export_sha256':digest(HERE/'rotated_transfer.ndjson')}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=HERE/'source.sites.json');p.add_argument('--contracts',type=Path,default=HERE/'phase_contracts.py');a=p.parse_args()
    receipt=audit(a.source,a.contracts)
    (HERE/'source_receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='body_ingress'},sort_keys=True))
