"""Independent endpoint specification for the 173-state physical phases.

This file reconstructs contracts from the literal source. It never accepts
an endpoint or a register domain supplied by a discovery trace.
"""

HEADS = (281, 427, 453, 558, 636, 792, 1018, 1096, 1122, 1227, 1357, 1513, 1720, 1798, 1920, 1946, 2077, 2148, 2174, 2253, 2305, 2408, 2485, 2537, 2668, 2799, 2953, 2973)
BORROW_HEAD = 2913


def flow(sites):
    paths = [s[0] for s in sites]
    assert paths == sorted(set(paths))
    leaves = {p:i for i,p in enumerate(paths)}
    nodes = {p[:j] for p in paths for j in range(len(p)+1)}
    for p in nodes:
        assert ((p+'0' in nodes), (p+'1' in nodes)) == ((False,False) if p in leaves else (True,True))
    def first(p):
        while p not in leaves:
            assert p in nodes
            p += '0'
        return leaves[p]
    def next_path(p):
        j=p.rfind('0')
        return ('',1) if j<0 else (p[:j]+'1',0)
    def cut(p,bit,k):
        for _ in range(k):
            j=p.rfind(bit)
            assert j>=0
            p=p[:j]
        return p
    out={}
    for pc,(p,op,arg) in enumerate(sites):
        assert op in ('CI','CD','CC','CB')
        if op in ('CI','CD'):
            q,w=next_path(p);out[pc,False]=(first(q),w)
        elif op=='CC':out[pc,False]=(first(cut(p,'1',arg)),0)
        else:q,w=next_path(cut(p,'0',arg));out[pc,False]=(first(q),w)
        if op=='CD':
            if p.endswith('1'):out[pc,True]=None
            else:q,w=next_path(cut(p,'0',1));out[pc,True]=(first(q),w)
    return out


def structure(sites):
    edges=flow(sites);n=len(sites)
    found=[]
    for h in range(n-2):
        if sites[h][1:]==['CD',3] and sites[h+1][1:]==['CI',4] and sites[h+2][1]=='CC':
            if edges[h,False]==(h+1,0) and edges[h,True]==((h+3)%n,int(h+3==n)) and edges[h+1,False]==(h+2,0) and edges[h+2,False]==(h,0):
                found.append(h)
    assert found==sorted([*HEADS,BORROW_HEAD])
    for h in found:
        for (pc,_),e in edges.items():
            if e is not None and e[0] in (h+1,h+2):assert h<=pc<=h+2
    assert sites[BORROW_HEAD-1][1:]==['CI',4]
    assert edges[BORROW_HEAD-1,False]==(BORROW_HEAD,0)
    return edges


def shape(sites,edges,trace):
    """Return runs, output runs, destination, wrap, gap delta, spare delta.

    A run (m,True) represents register m-1+x; (m,False) represents m-1.
    All x are independent natural numbers.
    """
    pc,zero=trace['pc'],trace['zero']
    assert isinstance(zero,bool) and not trace.get('cold',False)
    mode=trace.get('mode','ordinary')
    runs=[(1,True)]*9
    op,arg=sites[pc][1:]
    gap=spares=wrap=0
    if mode in ('ordinary','entry'):
        if mode=='entry':
            assert pc in HEADS
            runs[1]=(2,True);runs[7]=(1,False)
            if not zero:runs[4]=(1,False)
        else:
            assert pc not in {j for h in HEADS for j in range(h,h+3)}
            assert pc not in (BORROW_HEAD+1,BORROW_HEAD+2)
        assert not zero or op=='CD'
        if op=='CD':runs[arg]=(1,False) if zero else (2,True)
        after=list(runs);edge=edges[pc,zero]
        dest,wrap=(None,0) if edge is None else edge
        if op=='CI':
            m,v=after[arg];after[arg]=(m+1,v);spares=1
        elif op=='CD' and not zero:
            m,v=after[arg];after[arg]=(m-1,v);gap=1
    elif mode=='defer':
        assert pc-1 in HEADS and not zero
        runs[1]=(2,True);runs[4]=runs[7]=(1,False)
        after=list(runs);dest=pc+1
    elif mode=='tail':
        assert pc-2 in HEADS
        runs[1]=(2,True);runs[7]=(1,False)
        runs[3]=(1,False) if zero else (2,True)
        after=list(runs);after[4]=(2,True)
        if not zero:after[3]=(1,True)
        dest=(pc+1)%len(sites) if zero else pc
        wrap=int(zero and pc+1==len(sites));gap=int(not zero);spares=1
    elif mode=='borrow':
        assert pc==BORROW_HEAD+1 and not zero
        after=list(runs);dest=BORROW_HEAD-1
    else:raise AssertionError(('unrecognized phase',mode))
    return runs,after,dest,wrap,gap+wrap,spares


def expected_domains(sites):
    excluded={pc for h in HEADS for pc in range(h,h+3)}|{BORROW_HEAD+1,BORROW_HEAD+2}
    domains={(pc,'ordinary',z) for pc,(_,op,_) in enumerate(sites) if pc not in excluded
             for z in ((False,True) if op=='CD' else (False,))}
    for h in HEADS:
        domains.update({(h,'entry',False),(h,'entry',True),(h+1,'defer',False),
                        (h+2,'tail',False),(h+2,'tail',True)})
    domains.add((BORROW_HEAD+1,'borrow',False))
    return domains
