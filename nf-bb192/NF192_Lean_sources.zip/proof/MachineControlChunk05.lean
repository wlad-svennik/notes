module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases05_00 : List Case := [
  ⟨1027, false, 1042893568, 237587200, 62, 0, 0⟩,
  ⟨1031, false, 254364416, 19483392, 54, 0, 0⟩,
  ⟨1034, false, 61426432, 11094784, 50, 0, 0⟩,
  ⟨1037, false, 409553664, 6900480, 56, 0, 0⟩,
  ⟨1040, false, 879315712, 74009344, 60, 0, 0⟩,
  ⟨1044, false, 7724419840, 208227072, 66, 0, 0⟩,
  ⟨1049, false, 31883610880, 6113807104, 70, 0, 0⟩,
  ⟨1050, false, 3966323456, 208227072, 62, 0, 0⟩
]

theorem cases05_00_verified : cases05_00.all verified = true := by decide

def cases05_01 : List Case := [
  ⟨1053, false, 2087275264, 476662528, 64, 0, 0⟩,
  ⟨1057, false, 510216960, 40454912, 56, 0, 0⟩,
  ⟨1060, false, 124340992, 23677696, 52, 0, 0⟩,
  ⟨1064, true, 2833861376, 417942272, 32, 28, 35⟩,
  ⟨1067, false, 8202570496, 1760119552, 68, 0, 0⟩,
  ⟨1068, false, 417942272, 15289088, 60, 0, 0⟩,
  ⟨1071, false, 485051136, 82397952, 60, 0, 0⟩,
  ⟨1075, false, 1927891712, 48843520, 62, 0, 0⟩
]

theorem cases05_01_verified : cases05_01.all verified = true := by decide

def cases05_02 : List Case := [
  ⟨1080, false, 7967689472, 1525238528, 66, 0, 0⟩,
  ⟨1081, false, 988367616, 48843520, 58, 0, 0⟩,
  ⟨1085, false, 1055476480, 115952384, 60, 0, 0⟩,
  ⟨1090, false, 1629047552, 18434816, 60, 0, 0⟩,
  ⟨1093, false, 3508095744, 286870272, 64, 0, 0⟩,
  ⟨1097, false, 30888512256, 823741184, 70, 0, 0⟩,
  ⟨1102, false, 127525276416, 24446061312, 74, 0, 0⟩,
  ⟨1103, false, 15856126720, 823741184, 66, 0, 0⟩
]

theorem cases05_02_verified : cases05_02.all verified = true := by decide

def cases05_03 : List Case := [
  ⟨1106, false, 8339933952, 1897483008, 68, 0, 0⟩,
  ⟨1110, false, 3910748928, 152652544, 62, 0, 0⟩,
  ⟨1113, false, 2031700736, 421088000, 66, 0, 0⟩,
  ⟨1117, true, 22634121984, 3306769152, 33, 31, 38⟩,
  ⟨1120, false, 65583794944, 14044187392, 72, 0, 0⟩,
  ⟨1121, false, 3306769152, 85543680, 64, 0, 0⟩,
  ⟨1124, false, 3843640064, 622414592, 64, 0, 0⟩,
  ⟨1128, false, 15386364672, 353979136, 66, 0, 0⟩
]

theorem cases05_03_verified : cases05_03.all verified = true := by decide

def cases05_04 : List Case := [
  ⟨1133, false, 63704746752, 12165139200, 70, 0, 0⟩,
  ⟨1134, false, 7870171904, 353979136, 62, 0, 0⟩,
  ⟨1138, false, 8407042816, 890850048, 64, 0, 0⟩,
  ⟨1142, false, 3273214720, 51989248, 60, 0, 0⟩,
  ⟨1145, false, 7031311104, 588860160, 64, 0, 0⟩,
  ⟨1149, false, 61792144128, 1662601984, 70, 0, 0⟩,
  ⟨1154, false, 255065672448, 48907242240, 74, 0, 0⟩,
  ⟨1155, false, 31727373056, 1662601984, 66, 0, 0⟩
]

theorem cases05_04_verified : cases05_04.all verified = true := by decide

def cases05_05 : List Case := [
  ⟨1158, false, 16694987520, 3810085632, 68, 0, 0⟩,
  ⟨1162, false, 4078521088, 320424704, 60, 0, 0⟩,
  ⟨1165, false, 991513344, 186206976, 56, 0, 0⟩,
  ⟨1169, true, 22667676416, 3340323584, 33, 31, 38⟩,
  ⟨1172, false, 65617349376, 14077741824, 72, 0, 0⟩,
  ⟨1173, false, 3340323584, 119098112, 64, 0, 0⟩,
  ⟨1176, false, 3877194496, 655969024, 64, 0, 0⟩,
  ⟨1180, false, 15419919104, 387533568, 66, 0, 0⟩
]

theorem cases05_05_verified : cases05_05.all verified = true := by decide

def cases05_06 : List Case := [
  ⟨1185, false, 63738301184, 12198693632, 70, 0, 0⟩,
  ⟨1186, false, 7903726336, 387533568, 62, 0, 0⟩,
  ⟨1190, false, 8440597248, 924404480, 64, 0, 0⟩,
  ⟨1194, false, 815352576, 10046208, 60, 0, 0⟩,
  ⟨1197, false, 1754876672, 144263936, 64, 0, 0⟩,
  ⟨1201, false, 15445084928, 412699392, 70, 0, 0⟩,
  ⟨1206, false, 63763467008, 12223859456, 74, 0, 0⟩,
  ⟨1207, false, 7928892160, 412699392, 66, 0, 0⟩
]

theorem cases05_06_verified : cases05_06.all verified = true := by decide

def cases05_07 : List Case := [
  ⟨1210, false, 4170795776, 949570304, 68, 0, 0⟩,
  ⟨1214, false, 1956203264, 77155072, 62, 0, 0⟩,
  ⟨1217, false, 1016679168, 211372800, 66, 0, 0⟩,
  ⟨1220, false, 1654213376, 43600640, 62, 0, 0⟩,
  ⟨1223, false, 3533261568, 312036096, 66, 0, 0⟩,
  ⟨1227, false, 30913678080, 848907008, 72, 0, 0⟩,
  ⟨1232, false, 127550442240, 24471227136, 76, 0, 0⟩,
  ⟨1233, false, 15881292544, 848907008, 68, 0, 0⟩
]

theorem cases05_07_verified : cases05_07.all verified = true := by decide

def cases05 : List Case := cases05_00 ++ cases05_01 ++ cases05_02 ++ cases05_03 ++ cases05_04 ++ cases05_05 ++ cases05_06 ++ cases05_07

theorem cases05_verified : cases05.all verified = true := by
  simp only [cases05, List.all_append, cases05_00_verified, cases05_01_verified, cases05_02_verified, cases05_03_verified, cases05_04_verified, cases05_05_verified, cases05_06_verified, cases05_07_verified, Bool.and_self]

end NF192.Control
