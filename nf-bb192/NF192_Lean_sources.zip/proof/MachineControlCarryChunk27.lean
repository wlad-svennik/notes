module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases27_00 : List Case := [
  ⟨2589, true, 2592, false, 26, 5, 33⟩,
  ⟨2590, false, 2591, false, 31, 1, 38⟩,
  ⟨2592, false, 2593, false, 27, 1, 34⟩,
  ⟨2592, true, 2596, false, 25, 3, 32⟩,
  ⟨2593, false, 2594, false, 28, 1, 35⟩,
  ⟨2594, false, 2595, false, 29, 1, 36⟩,
  ⟨2596, false, 2597, false, 26, 1, 33⟩,
  ⟨2596, true, 2599, false, 24, 3, 31⟩]
theorem carryCases27_00_verified : carryCases27_00.all verified = true := by decide

def carryCases27_01 : List Case := [
  ⟨2597, false, 2598, false, 27, 1, 34⟩,
  ⟨2599, false, 2600, false, 29, 1, 36⟩,
  ⟨2599, true, 2602, false, 28, 2, 35⟩,
  ⟨2600, false, 2601, false, 30, 1, 37⟩,
  ⟨2602, false, 2603, false, 30, 1, 37⟩,
  ⟨2602, true, 2605, false, 29, 2, 36⟩,
  ⟨2603, false, 2604, false, 31, 1, 38⟩,
  ⟨2605, false, 2606, false, 32, 1, 39⟩]
theorem carryCases27_01_verified : carryCases27_01.all verified = true := by decide

def carryCases27_02 : List Case := [
  ⟨2605, true, 2609, false, 31, 2, 38⟩,
  ⟨2606, false, 2607, false, 33, 1, 40⟩,
  ⟨2607, false, 2608, false, 34, 1, 41⟩,
  ⟨2609, false, 2610, false, 32, 1, 39⟩,
  ⟨2609, true, 2615, false, 30, 3, 37⟩,
  ⟨2610, false, 2611, false, 34, 1, 41⟩,
  ⟨2611, false, 2612, false, 35, 1, 42⟩,
  ⟨2611, true, 2614, false, 33, 3, 40⟩]
theorem carryCases27_02_verified : carryCases27_02.all verified = true := by decide

def carryCases27_03 : List Case := [
  ⟨2612, false, 2613, false, 36, 1, 43⟩,
  ⟨2615, false, 2616, false, 31, 1, 38⟩,
  ⟨2615, true, 2618, false, 27, 5, 34⟩,
  ⟨2616, false, 2617, false, 32, 1, 39⟩,
  ⟨2618, false, 2619, false, 29, 1, 36⟩,
  ⟨2618, true, 2622, false, 28, 2, 35⟩,
  ⟨2619, false, 2620, false, 30, 1, 37⟩,
  ⟨2620, false, 2621, false, 31, 1, 38⟩]
theorem carryCases27_03_verified : carryCases27_03.all verified = true := by decide

def carryCases27_04 : List Case := [
  ⟨2622, false, 2623, false, 29, 1, 36⟩,
  ⟨2622, true, 2625, false, 26, 4, 33⟩,
  ⟨2623, false, 2624, false, 30, 1, 37⟩,
  ⟨2625, false, 2626, false, 31, 1, 38⟩,
  ⟨2625, true, 2628, false, 30, 2, 37⟩,
  ⟨2626, false, 2627, false, 32, 1, 39⟩,
  ⟨2628, false, 2629, false, 32, 1, 39⟩,
  ⟨2628, true, 2631, false, 31, 2, 38⟩]
theorem carryCases27_04_verified : carryCases27_04.all verified = true := by decide

def carryCases27_05 : List Case := [
  ⟨2629, false, 2630, false, 33, 1, 40⟩,
  ⟨2631, false, 2632, false, 34, 1, 41⟩,
  ⟨2631, true, 2635, false, 33, 2, 40⟩,
  ⟨2632, false, 2633, false, 35, 1, 42⟩,
  ⟨2633, false, 2634, false, 36, 1, 43⟩,
  ⟨2635, false, 2636, false, 34, 1, 41⟩,
  ⟨2635, true, 2641, false, 32, 3, 39⟩,
  ⟨2636, false, 2637, false, 36, 1, 43⟩]
theorem carryCases27_05_verified : carryCases27_05.all verified = true := by decide

def carryCases27_06 : List Case := [
  ⟨2637, false, 2638, false, 37, 1, 44⟩,
  ⟨2637, true, 2640, false, 35, 3, 42⟩,
  ⟨2638, false, 2639, false, 38, 1, 45⟩,
  ⟨2641, false, 2642, false, 33, 1, 40⟩,
  ⟨2641, true, 2644, false, 29, 5, 36⟩,
  ⟨2642, false, 2643, false, 34, 1, 41⟩,
  ⟨2644, false, 2645, false, 30, 1, 37⟩,
  ⟨2644, true, 2648, false, 28, 3, 35⟩]
theorem carryCases27_06_verified : carryCases27_06.all verified = true := by decide

def carryCases27_07 : List Case := [
  ⟨2645, false, 2646, false, 31, 1, 38⟩,
  ⟨2646, false, 2647, false, 32, 1, 39⟩,
  ⟨2648, false, 2649, false, 29, 1, 36⟩,
  ⟨2648, true, 2651, false, 27, 3, 34⟩,
  ⟨2649, false, 2650, false, 30, 1, 37⟩,
  ⟨2651, false, 2652, false, 31, 1, 38⟩,
  ⟨2651, true, 2659, false, 30, 2, 37⟩,
  ⟨2652, false, 2653, false, 33, 1, 40⟩]
theorem carryCases27_07_verified : carryCases27_07.all verified = true := by decide

def carryCases27_08 : List Case := [
  ⟨2653, false, 2654, false, 35, 1, 42⟩,
  ⟨2653, true, 2655, false, 34, 2, 41⟩,
  ⟨2655, false, 2656, false, 35, 1, 42⟩,
  ⟨2655, true, 2658, false, 32, 4, 39⟩,
  ⟨2656, false, 2657, false, 36, 1, 43⟩,
  ⟨2659, false, 2660, false, 31, 1, 38⟩,
  ⟨2659, true, 2662, false, 29, 3, 36⟩,
  ⟨2660, false, 2661, false, 32, 1, 39⟩]
theorem carryCases27_08_verified : carryCases27_08.all verified = true := by decide

def carryCases27_09 : List Case := [
  ⟨2662, false, 2663, false, 32, 1, 39⟩,
  ⟨2662, true, 2666, false, 31, 2, 38⟩,
  ⟨2663, false, 2664, false, 33, 1, 40⟩,
  ⟨2664, false, 2665, false, 34, 1, 41⟩,
  ⟨2666, false, 2667, false, 32, 1, 39⟩,
  ⟨2666, true, 2672, false, 30, 3, 37⟩,
  ⟨2667, false, 2668, false, 34, 1, 41⟩,
  ⟨2668, false, 2669, false, 35, 1, 42⟩]
theorem carryCases27_09_verified : carryCases27_09.all verified = true := by decide

def carryCases27_10 : List Case := [
  ⟨2668, true, 2671, false, 33, 3, 40⟩,
  ⟨2669, false, 2670, false, 36, 1, 43⟩,
  ⟨2672, false, 2673, false, 31, 1, 38⟩,
  ⟨2672, true, 2676, false, 28, 4, 35⟩,
  ⟨2673, false, 2674, false, 32, 1, 39⟩,
  ⟨2674, false, 2675, false, 33, 1, 40⟩,
  ⟨2676, false, 2677, false, 25, 4, 32⟩,
  ⟨2677, false, 2678, false, 26, 1, 33⟩]
theorem carryCases27_10_verified : carryCases27_10.all verified = true := by decide

def carryCases27_11 : List Case := [
  ⟨2678, false, 2679, false, 30, 1, 37⟩,
  ⟨2678, true, 2686, false, 29, 2, 36⟩,
  ⟨2679, false, 2680, false, 32, 1, 39⟩,
  ⟨2680, false, 2681, false, 34, 1, 41⟩,
  ⟨2680, true, 2682, false, 33, 2, 40⟩,
  ⟨2682, false, 2683, false, 34, 1, 41⟩,
  ⟨2682, true, 2685, false, 31, 4, 38⟩,
  ⟨2683, false, 2684, false, 35, 1, 42⟩]
theorem carryCases27_11_verified : carryCases27_11.all verified = true := by decide

def carryCases27 : List Case := carryCases27_00 ++ carryCases27_01 ++ carryCases27_02 ++ carryCases27_03 ++ carryCases27_04 ++ carryCases27_05 ++ carryCases27_06 ++ carryCases27_07 ++ carryCases27_08 ++ carryCases27_09 ++ carryCases27_10 ++ carryCases27_11
theorem carryCases27_verified : carryCases27.all verified = true := by
  simp only [carryCases27, List.all_append, carryCases27_00_verified, carryCases27_01_verified, carryCases27_02_verified, carryCases27_03_verified, carryCases27_04_verified, carryCases27_05_verified, carryCases27_06_verified, carryCases27_07_verified, carryCases27_08_verified, carryCases27_09_verified, carryCases27_10_verified, carryCases27_11_verified, Bool.and_self]
theorem carryCases27_covered : carryCases27.map (fun c => key c.pc c.zero) = keysBetween 5179 193 := by decide
theorem carryCases27_count : carryCases27.length = 96 := by decide
end NF192.Carry
