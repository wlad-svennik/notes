module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases04_00 : List Case := [
  ⟨820, false, 2085178112, 474565376, 66, 0, 0⟩,
  ⟨824, false, 977881856, 38357760, 60, 0, 0⟩,
  ⟨827, false, 508119808, 105466624, 64, 0, 0⟩,
  ⟨830, false, 826886912, 21580544, 60, 0, 0⟩,
  ⟨833, false, 1766411008, 155798272, 64, 0, 0⟩,
  ⟨837, false, 15456619264, 424233728, 70, 0, 0⟩,
  ⟨842, false, 63775001344, 12235393792, 74, 0, 0⟩,
  ⟨843, false, 7940426496, 424233728, 66, 0, 0⟩
]

theorem cases04_00_verified : cases04_00.all verified = true := by decide

def cases04_01 : List Case := [
  ⟨846, false, 4182330112, 961104640, 68, 0, 0⟩,
  ⟨850, false, 1967737600, 88689408, 62, 0, 0⟩,
  ⟨853, false, 1028213504, 222907136, 60, 0, 0⟩,
  ⟨857, true, 11329424128, 1665747712, 34, 30, 37⟩,
  ⟨860, false, 32804260608, 7034456832, 72, 0, 0⟩,
  ⟨861, false, 1665747712, 55134976, 64, 0, 0⟩,
  ⟨864, false, 1934183168, 323570432, 64, 0, 0⟩,
  ⟨868, false, 7705545472, 189352704, 66, 0, 0⟩
]

theorem cases04_01_verified : cases04_01.all verified = true := by decide

def cases04_02 : List Case := [
  ⟨873, false, 31864736512, 6094932736, 70, 0, 0⟩,
  ⟨874, false, 3947449088, 189352704, 62, 0, 0⟩,
  ⟨878, false, 4215884544, 457788160, 64, 0, 0⟩,
  ⟨882, false, 818498304, 13191936, 58, 0, 0⟩,
  ⟨885, false, 1758022400, 147409664, 62, 0, 0⟩,
  ⟨889, false, 15448230656, 415845120, 68, 0, 0⟩,
  ⟨894, false, 63766612736, 12227005184, 72, 0, 0⟩,
  ⟨895, false, 7932037888, 415845120, 64, 0, 0⟩
]

theorem cases04_02_verified : cases04_02.all verified = true := by decide

def cases04_03 : List Case := [
  ⟨898, false, 4173941504, 952716032, 66, 0, 0⟩,
  ⟨902, false, 1959348992, 80300800, 60, 0, 0⟩,
  ⟨905, false, 1019824896, 214518528, 64, 0, 0⟩,
  ⟨908, false, 3267971840, 46746368, 60, 0, 0⟩,
  ⟨911, false, 7026068224, 583617280, 64, 0, 0⟩,
  ⟨915, false, 61786901248, 1657359104, 70, 0, 0⟩,
  ⟨920, false, 255060429568, 48901999360, 74, 0, 0⟩,
  ⟨921, false, 31722130176, 1657359104, 66, 0, 0⟩
]

theorem cases04_03_verified : cases04_03.all verified = true := by decide

def cases04_04 : List Case := [
  ⟨924, false, 16689744640, 3804842752, 68, 0, 0⟩,
  ⟨928, false, 4073278208, 315181824, 60, 0, 0⟩,
  ⟨931, false, 986270464, 180964096, 56, 0, 0⟩,
  ⟨935, true, 22662433536, 3335080704, 33, 31, 38⟩,
  ⟨938, false, 65612106496, 14072498944, 72, 0, 0⟩,
  ⟨939, false, 3335080704, 113855232, 64, 0, 0⟩,
  ⟨942, false, 3871951616, 650726144, 64, 0, 0⟩,
  ⟨946, false, 15414676224, 382290688, 66, 0, 0⟩
]

theorem cases04_04_verified : cases04_04.all verified = true := by decide

def cases04_05 : List Case := [
  ⟨951, false, 63733058304, 12193450752, 70, 0, 0⟩,
  ⟨952, false, 7898483456, 382290688, 62, 0, 0⟩,
  ⟨956, false, 8435354368, 919161600, 64, 0, 0⟩,
  ⟨961, true, 11304258304, 1640581888, 32, 30, 37⟩,
  ⟨964, false, 32779094784, 7009291008, 70, 0, 0⟩,
  ⟨965, false, 1640581888, 29969152, 62, 0, 0⟩,
  ⟨968, false, 1909017344, 298404608, 62, 0, 0⟩,
  ⟨972, false, 7680379648, 164186880, 64, 0, 0⟩
]

theorem cases04_05_verified : cases04_05.all verified = true := by decide

def cases04_06 : List Case := [
  ⟨977, false, 31839570688, 6069766912, 68, 0, 0⟩,
  ⟨978, false, 3922283264, 164186880, 60, 0, 0⟩,
  ⟨982, false, 4190718720, 432622336, 62, 0, 0⟩,
  ⟨987, true, 5700668160, 868829952, 31, 29, 36⟩,
  ⟨990, false, 16438086400, 3553184512, 68, 0, 0⟩,
  ⟨991, false, 868829952, 63523584, 60, 0, 0⟩,
  ⟨994, false, 1003047680, 197741312, 60, 0, 0⟩,
  ⟨998, false, 3888728832, 130632448, 62, 0, 0⟩
]

theorem cases04_06_verified : cases04_06.all verified = true := by decide

def cases04_07 : List Case := [
  ⟨1003, false, 15968324352, 3083422464, 66, 0, 0⟩,
  ⟨1004, false, 2009680640, 130632448, 58, 0, 0⟩,
  ⟨1008, false, 2143898368, 264850176, 60, 0, 0⟩,
  ⟨1011, false, 204032768, 2706176, 54, 0, 0⟩,
  ⟨1014, false, 438913792, 36260608, 58, 0, 0⟩,
  ⟨1018, false, 3861465856, 103369472, 64, 0, 0⟩,
  ⟨1023, false, 15941061376, 3056159488, 68, 0, 0⟩,
  ⟨1024, false, 1982417664, 103369472, 60, 0, 0⟩
]

theorem cases04_07_verified : cases04_07.all verified = true := by decide

def cases04 : List Case := cases04_00 ++ cases04_01 ++ cases04_02 ++ cases04_03 ++ cases04_04 ++ cases04_05 ++ cases04_06 ++ cases04_07

theorem cases04_verified : cases04.all verified = true := by
  simp only [cases04, List.all_append, cases04_00_verified, cases04_01_verified, cases04_02_verified, cases04_03_verified, cases04_04_verified, cases04_05_verified, cases04_06_verified, cases04_07_verified, Bool.and_self]

end NF192.Control
