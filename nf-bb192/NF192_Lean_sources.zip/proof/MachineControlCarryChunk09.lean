module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases09_00 : List Case := [
  ⟨862, false, 863, false, 29, 1, 36⟩,
  ⟨862, true, 865, false, 27, 3, 34⟩,
  ⟨863, false, 864, false, 30, 1, 37⟩,
  ⟨865, false, 866, false, 30, 1, 37⟩,
  ⟨865, true, 869, false, 29, 2, 36⟩,
  ⟨866, false, 867, false, 31, 1, 38⟩,
  ⟨867, false, 868, false, 32, 1, 39⟩,
  ⟨869, false, 870, false, 30, 1, 37⟩]
theorem carryCases09_00_verified : carryCases09_00.all verified = true := by decide

def carryCases09_01 : List Case := [
  ⟨869, true, 875, false, 28, 3, 35⟩,
  ⟨870, false, 871, false, 32, 1, 39⟩,
  ⟨871, false, 872, false, 33, 1, 40⟩,
  ⟨871, true, 874, false, 31, 3, 38⟩,
  ⟨872, false, 873, false, 34, 1, 41⟩,
  ⟨875, false, 876, false, 29, 1, 36⟩,
  ⟨875, true, 879, false, 26, 4, 33⟩,
  ⟨876, false, 877, false, 30, 1, 37⟩]
theorem carryCases09_01_verified : carryCases09_01.all verified = true := by decide

def carryCases09_02 : List Case := [
  ⟨877, false, 878, false, 31, 1, 38⟩,
  ⟨879, false, 880, false, 23, 4, 30⟩,
  ⟨880, false, 881, false, 28, 1, 35⟩,
  ⟨880, true, 883, false, 27, 2, 34⟩,
  ⟨881, false, 882, false, 29, 1, 36⟩,
  ⟨883, false, 884, false, 29, 1, 36⟩,
  ⟨883, true, 886, false, 28, 2, 35⟩,
  ⟨884, false, 885, false, 30, 1, 37⟩]
theorem carryCases09_02_verified : carryCases09_02.all verified = true := by decide

def carryCases09_03 : List Case := [
  ⟨886, false, 887, false, 31, 1, 38⟩,
  ⟨886, true, 890, false, 30, 2, 37⟩,
  ⟨887, false, 888, false, 32, 1, 39⟩,
  ⟨888, false, 889, false, 33, 1, 40⟩,
  ⟨890, false, 891, false, 31, 1, 38⟩,
  ⟨890, true, 896, false, 29, 3, 36⟩,
  ⟨891, false, 892, false, 33, 1, 40⟩,
  ⟨892, false, 893, false, 34, 1, 41⟩]
theorem carryCases09_03_verified : carryCases09_03.all verified = true := by decide

def carryCases09_04 : List Case := [
  ⟨892, true, 895, false, 32, 3, 39⟩,
  ⟨893, false, 894, false, 35, 1, 42⟩,
  ⟨896, false, 897, false, 30, 1, 37⟩,
  ⟨896, true, 899, false, 26, 5, 33⟩,
  ⟨897, false, 898, false, 31, 1, 38⟩,
  ⟨899, false, 900, false, 28, 1, 35⟩,
  ⟨899, true, 903, false, 27, 2, 34⟩,
  ⟨900, false, 901, false, 29, 1, 36⟩]
theorem carryCases09_04_verified : carryCases09_04.all verified = true := by decide

def carryCases09_05 : List Case := [
  ⟨901, false, 902, false, 30, 1, 37⟩,
  ⟨903, false, 904, false, 28, 1, 35⟩,
  ⟨903, true, 906, false, 25, 4, 32⟩,
  ⟨904, false, 905, false, 29, 1, 36⟩,
  ⟨906, false, 907, false, 30, 1, 37⟩,
  ⟨906, true, 909, false, 29, 2, 36⟩,
  ⟨907, false, 908, false, 31, 1, 38⟩,
  ⟨909, false, 910, false, 31, 1, 38⟩]
theorem carryCases09_05_verified : carryCases09_05.all verified = true := by decide

def carryCases09_06 : List Case := [
  ⟨909, true, 912, false, 30, 2, 37⟩,
  ⟨910, false, 911, false, 32, 1, 39⟩,
  ⟨912, false, 913, false, 33, 1, 40⟩,
  ⟨912, true, 916, false, 32, 2, 39⟩,
  ⟨913, false, 914, false, 34, 1, 41⟩,
  ⟨914, false, 915, false, 35, 1, 42⟩,
  ⟨916, false, 917, false, 33, 1, 40⟩,
  ⟨916, true, 922, false, 31, 3, 38⟩]
theorem carryCases09_06_verified : carryCases09_06.all verified = true := by decide

def carryCases09_07 : List Case := [
  ⟨917, false, 918, false, 35, 1, 42⟩,
  ⟨918, false, 919, false, 36, 1, 43⟩,
  ⟨918, true, 921, false, 34, 3, 41⟩,
  ⟨919, false, 920, false, 37, 1, 44⟩,
  ⟨922, false, 923, false, 32, 1, 39⟩,
  ⟨922, true, 925, false, 28, 5, 35⟩,
  ⟨923, false, 924, false, 33, 1, 40⟩,
  ⟨925, false, 926, false, 29, 1, 36⟩]
theorem carryCases09_07_verified : carryCases09_07.all verified = true := by decide

def carryCases09_08 : List Case := [
  ⟨925, true, 929, false, 27, 3, 34⟩,
  ⟨926, false, 927, false, 30, 1, 37⟩,
  ⟨927, false, 928, false, 31, 1, 38⟩,
  ⟨929, false, 930, false, 28, 1, 35⟩,
  ⟨929, true, 932, false, 26, 3, 33⟩,
  ⟨930, false, 931, false, 29, 1, 36⟩,
  ⟨932, false, 933, false, 30, 1, 37⟩,
  ⟨932, true, 940, false, 29, 2, 36⟩]
theorem carryCases09_08_verified : carryCases09_08.all verified = true := by decide

def carryCases09_09 : List Case := [
  ⟨933, false, 934, false, 32, 1, 39⟩,
  ⟨934, false, 935, false, 34, 1, 41⟩,
  ⟨934, true, 936, false, 33, 2, 40⟩,
  ⟨936, false, 937, false, 34, 1, 41⟩,
  ⟨936, true, 939, false, 31, 4, 38⟩,
  ⟨937, false, 938, false, 35, 1, 42⟩,
  ⟨940, false, 941, false, 30, 1, 37⟩,
  ⟨940, true, 943, false, 28, 3, 35⟩]
theorem carryCases09_09_verified : carryCases09_09.all verified = true := by decide

def carryCases09_10 : List Case := [
  ⟨941, false, 942, false, 31, 1, 38⟩,
  ⟨943, false, 944, false, 31, 1, 38⟩,
  ⟨943, true, 947, false, 30, 2, 37⟩,
  ⟨944, false, 945, false, 32, 1, 39⟩,
  ⟨945, false, 946, false, 33, 1, 40⟩,
  ⟨947, false, 948, false, 31, 1, 38⟩,
  ⟨947, true, 953, false, 29, 3, 36⟩,
  ⟨948, false, 949, false, 33, 1, 40⟩]
theorem carryCases09_10_verified : carryCases09_10.all verified = true := by decide

def carryCases09_11 : List Case := [
  ⟨949, false, 950, false, 34, 1, 41⟩,
  ⟨949, true, 952, false, 32, 3, 39⟩,
  ⟨950, false, 951, false, 35, 1, 42⟩,
  ⟨953, false, 954, false, 30, 1, 37⟩,
  ⟨953, true, 957, false, 27, 4, 34⟩,
  ⟨954, false, 955, false, 31, 1, 38⟩,
  ⟨955, false, 956, false, 32, 1, 39⟩,
  ⟨957, false, 958, false, 24, 4, 31⟩]
theorem carryCases09_11_verified : carryCases09_11.all verified = true := by decide

def carryCases09 : List Case := carryCases09_00 ++ carryCases09_01 ++ carryCases09_02 ++ carryCases09_03 ++ carryCases09_04 ++ carryCases09_05 ++ carryCases09_06 ++ carryCases09_07 ++ carryCases09_08 ++ carryCases09_09 ++ carryCases09_10 ++ carryCases09_11
theorem carryCases09_verified : carryCases09.all verified = true := by
  simp only [carryCases09, List.all_append, carryCases09_00_verified, carryCases09_01_verified, carryCases09_02_verified, carryCases09_03_verified, carryCases09_04_verified, carryCases09_05_verified, carryCases09_06_verified, carryCases09_07_verified, carryCases09_08_verified, carryCases09_09_verified, carryCases09_10_verified, carryCases09_11_verified, Bool.and_self]
theorem carryCases09_covered : carryCases09.map (fun c => key c.pc c.zero) = keysBetween 1724 192 := by decide
theorem carryCases09_count : carryCases09.length = 96 := by decide
end NF192.Carry
