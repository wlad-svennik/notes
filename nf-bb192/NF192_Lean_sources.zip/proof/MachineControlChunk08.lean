module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases08_00 : List Case := [
  ⟨1653, false, 2113489664, 234441472, 60, 0, 0⟩,
  ⟨1657, false, 25512704, 346880, 46, 0, 0⟩,
  ⟨1660, false, 54872832, 4541184, 50, 0, 0⟩,
  ⟨1664, false, 482691840, 12929792, 56, 0, 0⟩,
  ⟨1669, false, 1992641280, 382028544, 60, 0, 0⟩,
  ⟨1670, false, 247810816, 12929792, 52, 0, 0⟩,
  ⟨1673, false, 130370304, 29707008, 54, 0, 0⟩,
  ⟨1677, false, 61164288, 2444032, 48, 0, 0⟩
]

theorem cases08_00_verified : cases08_00.all verified = true := by decide

def cases08_01 : List Case := [
  ⟨1680, false, 31804160, 6638336, 46, 0, 0⟩,
  ⟨1683, false, 102058752, 1395456, 52, 0, 0⟩,
  ⟨1686, false, 219499264, 18172672, 56, 0, 0⟩,
  ⟨1690, false, 1930775296, 51727104, 62, 0, 0⟩,
  ⟨1695, false, 7970573056, 1528122112, 66, 0, 0⟩,
  ⟨1696, false, 991251200, 51727104, 58, 0, 0⟩,
  ⟨1699, false, 521489152, 118835968, 60, 0, 0⟩,
  ⟨1703, false, 127224576, 9784064, 52, 0, 0⟩
]

theorem cases08_01_verified : cases08_01.all verified = true := by decide

def cases08_02 : List Case := [
  ⟨1706, false, 30755584, 5589760, 48, 0, 0⟩,
  ⟨1709, false, 204819200, 3492608, 54, 0, 0⟩,
  ⟨1712, false, 439700224, 37047040, 58, 0, 0⟩,
  ⟨1716, false, 3862252288, 104155904, 64, 0, 0⟩,
  ⟨1721, false, 15941847808, 3056945920, 68, 0, 0⟩,
  ⟨1722, false, 1983204096, 104155904, 60, 0, 0⟩,
  ⟨1725, false, 1043680000, 238373632, 62, 0, 0⟩,
  ⟨1729, false, 255150848, 20269824, 54, 0, 0⟩
]

theorem cases08_02_verified : cases08_02.all verified = true := by decide

def cases08_03 : List Case := [
  ⟨1732, false, 62212864, 11881216, 50, 0, 0⟩,
  ⟨1736, true, 1416973056, 209013504, 31, 27, 34⟩,
  ⟨1739, false, 4101327616, 880102144, 66, 0, 0⟩,
  ⟨1740, false, 209013504, 7686912, 58, 0, 0⟩,
  ⟨1743, false, 242567936, 41241344, 58, 0, 0⟩,
  ⟨1747, false, 963988224, 24464128, 60, 0, 0⟩,
  ⟨1752, false, 3983887104, 762661632, 64, 0, 0⟩,
  ⟨1753, false, 494226176, 24464128, 56, 0, 0⟩
]

theorem cases08_03_verified : cases08_03.all verified = true := by decide

def cases08_04 : List Case := [
  ⟨1757, false, 527780608, 58018560, 58, 0, 0⟩,
  ⟨1763, true, 1414351616, 206392064, 29, 27, 34⟩,
  ⟨1766, false, 4098706176, 877480704, 64, 0, 0⟩,
  ⟨1767, false, 206392064, 5065472, 56, 0, 0⟩,
  ⟨1770, false, 239946496, 38619904, 56, 0, 0⟩,
  ⟨1774, false, 961366784, 21842688, 58, 0, 0⟩,
  ⟨1779, false, 3981265664, 760040192, 62, 0, 0⟩,
  ⟨1780, false, 491604736, 21842688, 54, 0, 0⟩
]

theorem cases08_04_verified : cases08_04.all verified = true := by decide

def cases08_05 : List Case := [
  ⟨1784, false, 525159168, 55397120, 56, 0, 0⟩,
  ⟨1788, false, 204294912, 2968320, 56, 0, 0⟩,
  ⟨1791, false, 439175936, 36522752, 60, 0, 0⟩,
  ⟨1795, false, 3861728000, 103631616, 66, 0, 0⟩,
  ⟨1800, false, 15941323520, 3056421632, 70, 0, 0⟩,
  ⟨1801, false, 1982679808, 103631616, 62, 0, 0⟩,
  ⟨1804, false, 1043155712, 237849344, 64, 0, 0⟩,
  ⟨1808, false, 489507584, 19745536, 58, 0, 0⟩
]

theorem cases08_05_verified : cases08_05.all verified = true := by decide

def cases08_06 : List Case := [
  ⟨1811, false, 254626560, 53299968, 62, 0, 0⟩,
  ⟨1814, false, 816663296, 11356928, 58, 0, 0⟩,
  ⟨1817, false, 1756187392, 145574656, 62, 0, 0⟩,
  ⟨1821, false, 15446395648, 414010112, 68, 0, 0⟩,
  ⟨1826, false, 63764777728, 12225170176, 72, 0, 0⟩,
  ⟨1827, false, 7930202880, 414010112, 64, 0, 0⟩,
  ⟨1830, false, 4172106496, 950881024, 66, 0, 0⟩,
  ⟨1834, false, 1017989888, 78465792, 58, 0, 0⟩
]

theorem cases08_06_verified : cases08_06.all verified = true := by decide

def cases08_07 : List Case := [
  ⟨1837, false, 246237952, 44911360, 54, 0, 0⟩,
  ⟨1841, true, 5665278720, 833440512, 33, 29, 36⟩,
  ⟨1844, false, 16402696960, 3517795072, 70, 0, 0⟩,
  ⟨1845, false, 833440512, 28134144, 62, 0, 0⟩,
  ⟨1848, false, 967658240, 162351872, 62, 0, 0⟩,
  ⟨1852, false, 3853339392, 95243008, 64, 0, 0⟩,
  ⟨1857, false, 15932934912, 3048033024, 68, 0, 0⟩,
  ⟨1858, false, 1974291200, 95243008, 60, 0, 0⟩
]

theorem cases08_07_verified : cases08_07.all verified = true := by decide

def cases08 : List Case := cases08_00 ++ cases08_01 ++ cases08_02 ++ cases08_03 ++ cases08_04 ++ cases08_05 ++ cases08_06 ++ cases08_07

theorem cases08_verified : cases08.all verified = true := by
  simp only [cases08, List.all_append, cases08_00_verified, cases08_01_verified, cases08_02_verified, cases08_03_verified, cases08_04_verified, cases08_05_verified, cases08_06_verified, cases08_07_verified, Bool.and_self]

end NF192.Control
