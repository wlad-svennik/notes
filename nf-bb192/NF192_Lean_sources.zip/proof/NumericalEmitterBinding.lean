module
public import NumericalEmitterChecking

@[expose] public section

/-!
# Finite binding to the actual decoded countdown CFG

The reflexive checks compare the compiler's expected instructions against
the address decoder for the exact 3,089 uploaded primitive rows. Every field
of every instruction, including the conditional halt bit, enters the key.
-/

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Emitter

open NF192.Numerical

theorem batch_size : batchCode.size = 2928 := by decide

theorem check_all_slots : matchesCode 40 (compile batchCode 40 2968 [] []) = true := by decide

theorem batch_embedded : Embedded actual batchCode 40 2968 [] [] :=
  embedded_of_matches _ _ _ check_all_slots

/-- For arbitrary Cantor fields, old top and old stack, the literal source
takes a positive finite number of steps from ordinal 40 to ordinal 2968.
It has emitted exactly the nine rows and cleared registers 4 and 5. -/
theorem selected_ax_batch (n t stack c u v y delta tail : Nat) :
    ∃ ticks, 0 < ticks ∧
      Source.advance ticks
        (Source.Config.active 40 (liftRegisters (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩))) =
        Source.Config.active 2968 (liftRegisters ((save ⟨n,t,stack,c,0,0,tail⟩
          (rowList (u+delta) (v+y) c u)).regs)) :=
  ax_program_of_embedding batch_embedded n t stack c u v y delta tail

#print axioms selected_ax_batch

end NF192.Emitter
