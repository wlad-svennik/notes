module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases13_00 : List Case := [
  ⟨1245, false, 1246, false, 32, 1, 39⟩,
  ⟨1246, false, 1247, false, 34, 1, 41⟩,
  ⟨1246, true, 1248, false, 33, 2, 40⟩,
  ⟨1248, false, 1249, false, 34, 1, 41⟩,
  ⟨1248, true, 1251, false, 31, 4, 38⟩,
  ⟨1249, false, 1250, false, 35, 1, 42⟩,
  ⟨1252, false, 1253, false, 30, 1, 37⟩,
  ⟨1252, true, 1255, false, 28, 3, 35⟩]
theorem carryCases13_00_verified : carryCases13_00.all verified = true := by decide

def carryCases13_01 : List Case := [
  ⟨1253, false, 1254, false, 31, 1, 38⟩,
  ⟨1255, false, 1256, false, 31, 1, 38⟩,
  ⟨1255, true, 1259, false, 30, 2, 37⟩,
  ⟨1256, false, 1257, false, 32, 1, 39⟩,
  ⟨1257, false, 1258, false, 33, 1, 40⟩,
  ⟨1259, false, 1260, false, 31, 1, 38⟩,
  ⟨1259, true, 1265, false, 29, 3, 36⟩,
  ⟨1260, false, 1261, false, 33, 1, 40⟩]
theorem carryCases13_01_verified : carryCases13_01.all verified = true := by decide

def carryCases13_02 : List Case := [
  ⟨1261, false, 1262, false, 34, 1, 41⟩,
  ⟨1261, true, 1264, false, 32, 3, 39⟩,
  ⟨1262, false, 1263, false, 35, 1, 42⟩,
  ⟨1265, false, 1266, false, 30, 1, 37⟩,
  ⟨1265, true, 1269, false, 27, 4, 34⟩,
  ⟨1266, false, 1267, false, 31, 1, 38⟩,
  ⟨1267, false, 1268, false, 32, 1, 39⟩,
  ⟨1269, false, 1270, false, 24, 4, 31⟩]
theorem carryCases13_02_verified : carryCases13_02.all verified = true := by decide

def carryCases13_03 : List Case := [
  ⟨1270, false, 1271, false, 28, 1, 35⟩,
  ⟨1270, true, 1273, false, 27, 2, 34⟩,
  ⟨1271, false, 1272, false, 29, 1, 36⟩,
  ⟨1273, false, 1274, false, 29, 1, 36⟩,
  ⟨1273, true, 1276, false, 28, 2, 35⟩,
  ⟨1274, false, 1275, false, 30, 1, 37⟩,
  ⟨1276, false, 1277, false, 31, 1, 38⟩,
  ⟨1276, true, 1280, false, 30, 2, 37⟩]
theorem carryCases13_03_verified : carryCases13_03.all verified = true := by decide

def carryCases13_04 : List Case := [
  ⟨1277, false, 1278, false, 32, 1, 39⟩,
  ⟨1278, false, 1279, false, 33, 1, 40⟩,
  ⟨1280, false, 1281, false, 31, 1, 38⟩,
  ⟨1280, true, 1286, false, 29, 3, 36⟩,
  ⟨1281, false, 1282, false, 33, 1, 40⟩,
  ⟨1282, false, 1283, false, 34, 1, 41⟩,
  ⟨1282, true, 1285, false, 32, 3, 39⟩,
  ⟨1283, false, 1284, false, 35, 1, 42⟩]
theorem carryCases13_04_verified : carryCases13_04.all verified = true := by decide

def carryCases13_05 : List Case := [
  ⟨1286, false, 1287, false, 30, 1, 37⟩,
  ⟨1286, true, 1289, false, 26, 5, 33⟩,
  ⟨1287, false, 1288, false, 31, 1, 38⟩,
  ⟨1289, false, 1290, false, 28, 1, 35⟩,
  ⟨1289, true, 1293, false, 27, 2, 34⟩,
  ⟨1290, false, 1291, false, 29, 1, 36⟩,
  ⟨1291, false, 1292, false, 30, 1, 37⟩,
  ⟨1293, false, 1294, false, 28, 1, 35⟩]
theorem carryCases13_05_verified : carryCases13_05.all verified = true := by decide

def carryCases13_06 : List Case := [
  ⟨1293, true, 1296, false, 25, 4, 32⟩,
  ⟨1294, false, 1295, false, 29, 1, 36⟩,
  ⟨1296, false, 1297, false, 30, 1, 37⟩,
  ⟨1296, true, 1299, false, 29, 2, 36⟩,
  ⟨1297, false, 1298, false, 31, 1, 38⟩,
  ⟨1299, false, 1300, false, 31, 1, 38⟩,
  ⟨1299, true, 1302, false, 30, 2, 37⟩,
  ⟨1300, false, 1301, false, 32, 1, 39⟩]
theorem carryCases13_06_verified : carryCases13_06.all verified = true := by decide

def carryCases13_07 : List Case := [
  ⟨1302, false, 1303, false, 33, 1, 40⟩,
  ⟨1302, true, 1306, false, 32, 2, 39⟩,
  ⟨1303, false, 1304, false, 34, 1, 41⟩,
  ⟨1304, false, 1305, false, 35, 1, 42⟩,
  ⟨1306, false, 1307, false, 33, 1, 40⟩,
  ⟨1306, true, 1312, false, 31, 3, 38⟩,
  ⟨1307, false, 1308, false, 35, 1, 42⟩,
  ⟨1308, false, 1309, false, 36, 1, 43⟩]
theorem carryCases13_07_verified : carryCases13_07.all verified = true := by decide

def carryCases13_08 : List Case := [
  ⟨1308, true, 1311, false, 34, 3, 41⟩,
  ⟨1309, false, 1310, false, 37, 1, 44⟩,
  ⟨1312, false, 1313, false, 32, 1, 39⟩,
  ⟨1312, true, 1315, false, 28, 5, 35⟩,
  ⟨1313, false, 1314, false, 33, 1, 40⟩,
  ⟨1315, false, 1316, false, 29, 1, 36⟩,
  ⟨1315, true, 1319, false, 27, 3, 34⟩,
  ⟨1316, false, 1317, false, 30, 1, 37⟩]
theorem carryCases13_08_verified : carryCases13_08.all verified = true := by decide

def carryCases13_09 : List Case := [
  ⟨1317, false, 1318, false, 31, 1, 38⟩,
  ⟨1319, false, 1320, false, 28, 1, 35⟩,
  ⟨1319, true, 1322, false, 26, 3, 33⟩,
  ⟨1320, false, 1321, false, 29, 1, 36⟩,
  ⟨1322, false, 1323, false, 30, 1, 37⟩,
  ⟨1322, true, 1330, false, 29, 2, 36⟩,
  ⟨1323, false, 1324, false, 32, 1, 39⟩,
  ⟨1324, false, 1325, false, 34, 1, 41⟩]
theorem carryCases13_09_verified : carryCases13_09.all verified = true := by decide

def carryCases13_10 : List Case := [
  ⟨1324, true, 1326, false, 33, 2, 40⟩,
  ⟨1326, false, 1327, false, 34, 1, 41⟩,
  ⟨1326, true, 1329, false, 31, 4, 38⟩,
  ⟨1327, false, 1328, false, 35, 1, 42⟩,
  ⟨1330, false, 1331, false, 30, 1, 37⟩,
  ⟨1330, true, 1333, false, 28, 3, 35⟩,
  ⟨1331, false, 1332, false, 31, 1, 38⟩,
  ⟨1333, false, 1334, false, 31, 1, 38⟩]
theorem carryCases13_10_verified : carryCases13_10.all verified = true := by decide

def carryCases13_11 : List Case := [
  ⟨1333, true, 1337, false, 30, 2, 37⟩,
  ⟨1334, false, 1335, false, 32, 1, 39⟩,
  ⟨1335, false, 1336, false, 33, 1, 40⟩,
  ⟨1337, false, 1338, false, 31, 1, 38⟩,
  ⟨1337, true, 1343, false, 29, 3, 36⟩,
  ⟨1338, false, 1339, false, 33, 1, 40⟩,
  ⟨1339, false, 1340, false, 34, 1, 41⟩,
  ⟨1339, true, 1342, false, 32, 3, 39⟩]
theorem carryCases13_11_verified : carryCases13_11.all verified = true := by decide

def carryCases13 : List Case := carryCases13_00 ++ carryCases13_01 ++ carryCases13_02 ++ carryCases13_03 ++ carryCases13_04 ++ carryCases13_05 ++ carryCases13_06 ++ carryCases13_07 ++ carryCases13_08 ++ carryCases13_09 ++ carryCases13_10 ++ carryCases13_11
theorem carryCases13_verified : carryCases13.all verified = true := by
  simp only [carryCases13, List.all_append, carryCases13_00_verified, carryCases13_01_verified, carryCases13_02_verified, carryCases13_03_verified, carryCases13_04_verified, carryCases13_05_verified, carryCases13_06_verified, carryCases13_07_verified, carryCases13_08_verified, carryCases13_09_verified, carryCases13_10_verified, carryCases13_11_verified, Bool.and_self]
theorem carryCases13_covered : carryCases13.map (fun c => key c.pc c.zero) = keysBetween 2490 190 := by decide
theorem carryCases13_count : carryCases13.length = 96 := by decide
end NF192.Carry
