module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases22_00 : List Case := [
  ⟨2109, false, 2110, false, 35, 1, 42⟩,
  ⟨2110, false, 2111, false, 36, 1, 43⟩,
  ⟨2110, true, 2113, false, 34, 3, 41⟩,
  ⟨2111, false, 2112, false, 37, 1, 44⟩,
  ⟨2114, false, 2115, false, 32, 1, 39⟩,
  ⟨2114, true, 2117, false, 28, 5, 35⟩,
  ⟨2115, false, 2116, false, 33, 1, 40⟩,
  ⟨2117, false, 2118, false, 29, 1, 36⟩]
theorem carryCases22_00_verified : carryCases22_00.all verified = true := by decide

def carryCases22_01 : List Case := [
  ⟨2117, true, 2121, false, 27, 3, 34⟩,
  ⟨2118, false, 2119, false, 30, 1, 37⟩,
  ⟨2119, false, 2120, false, 31, 1, 38⟩,
  ⟨2121, false, 2122, false, 28, 1, 35⟩,
  ⟨2121, true, 2124, false, 26, 3, 33⟩,
  ⟨2122, false, 2123, false, 29, 1, 36⟩,
  ⟨2124, false, 2125, false, 30, 1, 37⟩,
  ⟨2124, true, 2132, false, 29, 2, 36⟩]
theorem carryCases22_01_verified : carryCases22_01.all verified = true := by decide

def carryCases22_02 : List Case := [
  ⟨2125, false, 2126, false, 32, 1, 39⟩,
  ⟨2126, false, 2127, false, 34, 1, 41⟩,
  ⟨2126, true, 2128, false, 33, 2, 40⟩,
  ⟨2128, false, 2129, false, 34, 1, 41⟩,
  ⟨2128, true, 2131, false, 31, 4, 38⟩,
  ⟨2129, false, 2130, false, 35, 1, 42⟩,
  ⟨2132, false, 2133, false, 30, 1, 37⟩,
  ⟨2132, true, 2135, false, 28, 3, 35⟩]
theorem carryCases22_02_verified : carryCases22_02.all verified = true := by decide

def carryCases22_03 : List Case := [
  ⟨2133, false, 2134, false, 31, 1, 38⟩,
  ⟨2135, false, 2136, false, 31, 1, 38⟩,
  ⟨2135, true, 2139, false, 30, 2, 37⟩,
  ⟨2136, false, 2137, false, 32, 1, 39⟩,
  ⟨2137, false, 2138, false, 33, 1, 40⟩,
  ⟨2139, false, 2140, false, 31, 1, 38⟩,
  ⟨2139, true, 2145, false, 29, 3, 36⟩,
  ⟨2140, false, 2141, false, 33, 1, 40⟩]
theorem carryCases22_03_verified : carryCases22_03.all verified = true := by decide

def carryCases22_04 : List Case := [
  ⟨2141, false, 2142, false, 34, 1, 41⟩,
  ⟨2141, true, 2144, false, 32, 3, 39⟩,
  ⟨2142, false, 2143, false, 35, 1, 42⟩,
  ⟨2145, false, 2146, false, 30, 1, 37⟩,
  ⟨2145, true, 2149, false, 27, 4, 34⟩,
  ⟨2146, false, 2147, false, 31, 1, 38⟩,
  ⟨2147, false, 2148, false, 32, 1, 39⟩,
  ⟨2149, false, 2150, false, 21, 7, 28⟩]
theorem carryCases22_04_verified : carryCases22_04.all verified = true := by decide

def carryCases22_05 : List Case := [
  ⟨2150, false, 2151, false, 26, 1, 33⟩,
  ⟨2150, true, 2158, false, 25, 2, 32⟩,
  ⟨2151, false, 2152, false, 28, 1, 35⟩,
  ⟨2152, false, 2153, false, 30, 1, 37⟩,
  ⟨2152, true, 2154, false, 29, 2, 36⟩,
  ⟨2154, false, 2155, false, 30, 1, 37⟩,
  ⟨2154, true, 2157, false, 27, 4, 34⟩,
  ⟨2155, false, 2156, false, 31, 1, 38⟩]
theorem carryCases22_05_verified : carryCases22_05.all verified = true := by decide

def carryCases22_06 : List Case := [
  ⟨2158, false, 2159, false, 26, 1, 33⟩,
  ⟨2158, true, 2161, false, 24, 3, 31⟩,
  ⟨2159, false, 2160, false, 27, 1, 34⟩,
  ⟨2161, false, 2162, false, 27, 1, 34⟩,
  ⟨2161, true, 2165, false, 26, 2, 33⟩,
  ⟨2162, false, 2163, false, 28, 1, 35⟩,
  ⟨2163, false, 2164, false, 29, 1, 36⟩,
  ⟨2165, false, 2166, false, 27, 1, 34⟩]
theorem carryCases22_06_verified : carryCases22_06.all verified = true := by decide

def carryCases22_07 : List Case := [
  ⟨2165, true, 2171, false, 25, 3, 32⟩,
  ⟨2166, false, 2167, false, 29, 1, 36⟩,
  ⟨2167, false, 2168, false, 30, 1, 37⟩,
  ⟨2167, true, 2170, false, 28, 3, 35⟩,
  ⟨2168, false, 2169, false, 31, 1, 38⟩,
  ⟨2171, false, 2172, false, 26, 1, 33⟩,
  ⟨2171, true, 2175, false, 23, 4, 30⟩,
  ⟨2172, false, 2173, false, 27, 1, 34⟩]
theorem carryCases22_07_verified : carryCases22_07.all verified = true := by decide

def carryCases22_08 : List Case := [
  ⟨2173, false, 2174, false, 28, 1, 35⟩,
  ⟨2175, false, 2176, false, 26, 1, 33⟩,
  ⟨2175, true, 2183, false, 25, 2, 32⟩,
  ⟨2176, false, 2177, false, 28, 1, 35⟩,
  ⟨2177, false, 2178, false, 30, 1, 37⟩,
  ⟨2177, true, 2179, false, 29, 2, 36⟩,
  ⟨2179, false, 2180, false, 30, 1, 37⟩,
  ⟨2179, true, 2182, false, 27, 4, 34⟩]
theorem carryCases22_08_verified : carryCases22_08.all verified = true := by decide

def carryCases22_09 : List Case := [
  ⟨2180, false, 2181, false, 31, 1, 38⟩,
  ⟨2183, false, 2184, false, 26, 1, 33⟩,
  ⟨2183, true, 2186, false, 24, 3, 31⟩,
  ⟨2184, false, 2185, false, 27, 1, 34⟩,
  ⟨2186, false, 2187, false, 27, 1, 34⟩,
  ⟨2186, true, 2190, false, 26, 2, 33⟩,
  ⟨2187, false, 2188, false, 28, 1, 35⟩,
  ⟨2188, false, 2189, false, 29, 1, 36⟩]
theorem carryCases22_09_verified : carryCases22_09.all verified = true := by decide

def carryCases22_10 : List Case := [
  ⟨2190, false, 2191, false, 27, 1, 34⟩,
  ⟨2190, true, 2196, false, 25, 3, 32⟩,
  ⟨2191, false, 2192, false, 29, 1, 36⟩,
  ⟨2192, false, 2193, false, 30, 1, 37⟩,
  ⟨2192, true, 2195, false, 28, 3, 35⟩,
  ⟨2193, false, 2194, false, 31, 1, 38⟩,
  ⟨2196, false, 2197, false, 26, 1, 33⟩,
  ⟨2196, true, 2200, false, 22, 5, 29⟩]
theorem carryCases22_10_verified : carryCases22_10.all verified = true := by decide

def carryCases22_11 : List Case := [
  ⟨2197, false, 2198, false, 27, 1, 34⟩,
  ⟨2198, false, 2199, false, 28, 1, 35⟩,
  ⟨2200, false, 2201, false, 27, 1, 34⟩,
  ⟨2200, true, 2203, false, 26, 2, 33⟩,
  ⟨2201, false, 2202, false, 28, 1, 35⟩,
  ⟨2203, false, 2204, false, 28, 1, 35⟩,
  ⟨2203, true, 2206, false, 27, 2, 34⟩,
  ⟨2204, false, 2205, false, 29, 1, 36⟩]
theorem carryCases22_11_verified : carryCases22_11.all verified = true := by decide

def carryCases22 : List Case := carryCases22_00 ++ carryCases22_01 ++ carryCases22_02 ++ carryCases22_03 ++ carryCases22_04 ++ carryCases22_05 ++ carryCases22_06 ++ carryCases22_07 ++ carryCases22_08 ++ carryCases22_09 ++ carryCases22_10 ++ carryCases22_11
theorem carryCases22_verified : carryCases22.all verified = true := by
  simp only [carryCases22, List.all_append, carryCases22_00_verified, carryCases22_01_verified, carryCases22_02_verified, carryCases22_03_verified, carryCases22_04_verified, carryCases22_05_verified, carryCases22_06_verified, carryCases22_07_verified, carryCases22_08_verified, carryCases22_09_verified, carryCases22_10_verified, carryCases22_11_verified, Bool.and_self]
theorem carryCases22_covered : carryCases22.map (fun c => key c.pc c.zero) = keysBetween 4218 194 := by decide
theorem carryCases22_count : carryCases22.length = 96 := by decide
end NF192.Carry
