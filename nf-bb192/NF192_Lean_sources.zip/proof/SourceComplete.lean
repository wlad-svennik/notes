module
public import SourceCommands
public import NumericalAXBatches
public import NumericalEmitterBinding

@[expose] public section

/-! Unconditional literal-program proof. The 2,928-instruction AX embedding,
the multi-batch loop, MP, MODE, input reads and refill branches all refer
to the same selected 3,089-site source. The remaining low-level obligation
for the binary machine is the physical simulation of this source run. -/

namespace NF192.SourceSimulation

open Emitter CommandBlocks ProofSearch Numerical

theorem selected_ax : AxSimulation := by
  intro n u b d tail rest s
  let out := afterAX s (rows u b d rest s)
  have h₁ := ax_batches_of_embedding batch_embedded n u b d rest tail s
  have h₂ := mode_correct n out.top (pair out.cache (pack out.stack)) 0 0 0 tail
  simp only [Cantor.unpair_pair, show (0 : Nat) ≠ goal by decide, ite_false] at h₂
  exact h₁.trans h₂

theorem literal_step : StepSimulation := step_simulation selected_ax

theorem command_boundary_halts_iff (n : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, Source.advance ticks (boundary ⟨n+1,0,s⟩) = Source.Config.halted) ↔ Deriv goal :=
  source_halts_iff_goal literal_step n s hs

/-- Starting in a continued candidate also suffices. Either it already observes
the goal, or its finite tail reaches the next ordinary refill. -/
theorem stream_halts_any_cursor (next cursor : Nat) (s : State) (hs : s.Sound) :
    (∃ k, streamRun k ⟨next,cursor,s⟩ = none) ↔ Deriv goal := by
  constructor
  · rintro ⟨k,hk⟩
    have h := stream_run_sound k ⟨next,cursor,s⟩ hs
    simpa only [hk,StreamSound] using h
  · intro d
    cases cursor with
    | zero => exact (stream_halting_iff_goal next s hs).2 d
    | succ p =>
      let k := (candidate p).length
      have hc := stream_candidate p next s
      cases he : checkedRun (candidate p) s with
      | none =>
        exact ⟨k, by simpa only [he, Option.map_none] using hc⟩
      | some t =>
        have ht : streamRun k ⟨next,p+1,s⟩ = some ⟨next,0,t⟩ := by
          simpa only [he,Option.map_some] using hc
        have sound : t.Sound := by
          have h := stream_run_sound k ⟨next,p+1,s⟩ hs
          simpa only [ht,StreamSound] using h
        obtain ⟨ticks,done⟩ := (stream_halting_iff_goal next t sound).2 d
        exact ⟨k+ticks,by rw [stream_run_add, ht]; exact done⟩

/-- Every physically representable sound command boundary, regardless of its
register-zero counter, context stack, cache, parameter or residual cursor. -/
theorem literal_source_iff_goal (n cursor : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, Source.advance ticks (atFrame 0 (registers n cursor s)) = Source.Config.halted) ↔
    Deriv goal :=
  (source_halts_iff_stream literal_step ⟨n+1,cursor,s⟩ (Nat.zero_lt_succ n)).trans
    (stream_halts_any_cursor (n+1) cursor s hs)

def emptyState : State := ⟨0,[],0,0⟩

theorem empty_sound : emptyState.Sound := ⟨deriv_zero, by simp [emptyState], deriv_zero⟩

theorem literal_zero_iff_goal :
    (∃ ticks, Source.advance ticks (atFrame 0 (registers 0 0 emptyState)) = Source.Config.halted) ↔
    Deriv goal := literal_source_iff_goal 0 0 emptyState empty_sound

end NF192.SourceSimulation

#print axioms NF192.SourceSimulation.literal_step
#print axioms NF192.SourceSimulation.literal_source_iff_goal
#print axioms NF192.SourceSimulation.literal_zero_iff_goal
