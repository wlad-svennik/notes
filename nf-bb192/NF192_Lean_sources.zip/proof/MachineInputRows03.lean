module
public import MachineInputData
@[expose] public section
namespace NF192.Input
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem rowBlock36 : computedBlock 36 = literalBlock 36 := by decide
theorem rowBlock37 : computedBlock 37 = literalBlock 37 := by decide
theorem rowBlock38 : computedBlock 38 = literalBlock 38 := by decide
theorem rowBlock39 : computedBlock 39 = literalBlock 39 := by decide
theorem rowBlock40 : computedBlock 40 = literalBlock 40 := by decide
theorem rowBlock41 : computedBlock 41 = literalBlock 41 := by decide
theorem rowBlock42 : computedBlock 42 = literalBlock 42 := by decide
theorem rowBlock43 : computedBlock 43 = literalBlock 43 := by decide
theorem rowBlock44 : computedBlock 44 = literalBlock 44 := by decide
theorem rowBlock45 : computedBlock 45 = literalBlock 45 := by decide
theorem rowBlock46 : computedBlock 46 = literalBlock 46 := by decide
theorem rowBlock47 : computedBlock 47 = literalBlock 47 := by decide
end NF192.Input
