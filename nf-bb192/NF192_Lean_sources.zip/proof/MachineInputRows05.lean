module
public import MachineInputData
@[expose] public section
namespace NF192.Input
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem rowBlock60 : computedBlock 60 = literalBlock 60 := by decide
theorem rowBlock61 : computedBlock 61 = literalBlock 61 := by decide
theorem rowBlock62 : computedBlock 62 = literalBlock 62 := by decide
theorem rowBlock63 : computedBlock 63 = literalBlock 63 := by decide
theorem rowBlock64 : computedBlock 64 = literalBlock 64 := by decide
theorem rowBlock65 : computedBlock 65 = literalBlock 65 := by decide
theorem rowBlock66 : computedBlock 66 = literalBlock 66 := by decide
theorem rowBlock67 : computedBlock 67 = literalBlock 67 := by decide
theorem rowBlock68 : computedBlock 68 = literalBlock 68 := by decide
theorem rowBlock69 : computedBlock 69 = literalBlock 69 := by decide
theorem rowBlock70 : computedBlock 70 = literalBlock 70 := by decide
theorem rowBlock71 : computedBlock 71 = literalBlock 71 := by decide
end NF192.Input
