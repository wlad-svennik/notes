module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases14_00 : List Case := [
  ⟨1340, false, 1341, false, 35, 1, 42⟩,
  ⟨1343, false, 1344, false, 30, 1, 37⟩,
  ⟨1343, true, 1347, false, 27, 4, 34⟩,
  ⟨1344, false, 1345, false, 31, 1, 38⟩,
  ⟨1345, false, 1346, false, 32, 1, 39⟩,
  ⟨1347, false, 1348, false, 22, 6, 29⟩,
  ⟨1348, false, 1349, false, 27, 1, 34⟩,
  ⟨1348, true, 1351, false, 26, 2, 33⟩]
theorem carryCases14_00_verified : carryCases14_00.all verified = true := by decide

def carryCases14_01 : List Case := [
  ⟨1349, false, 1350, false, 28, 1, 35⟩,
  ⟨1351, false, 1352, false, 28, 1, 35⟩,
  ⟨1351, true, 1354, false, 27, 2, 34⟩,
  ⟨1352, false, 1353, false, 29, 1, 36⟩,
  ⟨1354, false, 1355, false, 30, 1, 37⟩,
  ⟨1354, true, 1358, false, 29, 2, 36⟩,
  ⟨1355, false, 1356, false, 31, 1, 38⟩,
  ⟨1356, false, 1357, false, 32, 1, 39⟩]
theorem carryCases14_01_verified : carryCases14_01.all verified = true := by decide

def carryCases14_02 : List Case := [
  ⟨1358, false, 1359, false, 30, 1, 37⟩,
  ⟨1358, true, 1364, false, 28, 3, 35⟩,
  ⟨1359, false, 1360, false, 32, 1, 39⟩,
  ⟨1360, false, 1361, false, 33, 1, 40⟩,
  ⟨1360, true, 1363, false, 31, 3, 38⟩,
  ⟨1361, false, 1362, false, 34, 1, 41⟩,
  ⟨1364, false, 1365, false, 29, 1, 36⟩,
  ⟨1364, true, 1367, false, 25, 5, 32⟩]
theorem carryCases14_02_verified : carryCases14_02.all verified = true := by decide

def carryCases14_03 : List Case := [
  ⟨1365, false, 1366, false, 30, 1, 37⟩,
  ⟨1367, false, 1368, false, 27, 1, 34⟩,
  ⟨1367, true, 1371, false, 26, 2, 33⟩,
  ⟨1368, false, 1369, false, 28, 1, 35⟩,
  ⟨1369, false, 1370, false, 29, 1, 36⟩,
  ⟨1371, false, 1372, false, 27, 1, 34⟩,
  ⟨1371, true, 1374, false, 24, 4, 31⟩,
  ⟨1372, false, 1373, false, 28, 1, 35⟩]
theorem carryCases14_03_verified : carryCases14_03.all verified = true := by decide

def carryCases14_04 : List Case := [
  ⟨1374, false, 1375, false, 29, 1, 36⟩,
  ⟨1374, true, 1377, false, 28, 2, 35⟩,
  ⟨1375, false, 1376, false, 30, 1, 37⟩,
  ⟨1377, false, 1378, false, 30, 1, 37⟩,
  ⟨1377, true, 1380, false, 29, 2, 36⟩,
  ⟨1378, false, 1379, false, 31, 1, 38⟩,
  ⟨1380, false, 1381, false, 32, 1, 39⟩,
  ⟨1380, true, 1384, false, 31, 2, 38⟩]
theorem carryCases14_04_verified : carryCases14_04.all verified = true := by decide

def carryCases14_05 : List Case := [
  ⟨1381, false, 1382, false, 33, 1, 40⟩,
  ⟨1382, false, 1383, false, 34, 1, 41⟩,
  ⟨1384, false, 1385, false, 32, 1, 39⟩,
  ⟨1384, true, 1390, false, 30, 3, 37⟩,
  ⟨1385, false, 1386, false, 34, 1, 41⟩,
  ⟨1386, false, 1387, false, 35, 1, 42⟩,
  ⟨1386, true, 1389, false, 33, 3, 40⟩,
  ⟨1387, false, 1388, false, 36, 1, 43⟩]
theorem carryCases14_05_verified : carryCases14_05.all verified = true := by decide

def carryCases14_06 : List Case := [
  ⟨1390, false, 1391, false, 31, 1, 38⟩,
  ⟨1390, true, 1393, false, 27, 5, 34⟩,
  ⟨1391, false, 1392, false, 32, 1, 39⟩,
  ⟨1393, false, 1394, false, 28, 1, 35⟩,
  ⟨1393, true, 1397, false, 26, 3, 33⟩,
  ⟨1394, false, 1395, false, 29, 1, 36⟩,
  ⟨1395, false, 1396, false, 30, 1, 37⟩,
  ⟨1397, false, 1398, false, 27, 1, 34⟩]
theorem carryCases14_06_verified : carryCases14_06.all verified = true := by decide

def carryCases14_07 : List Case := [
  ⟨1397, true, 1400, false, 25, 3, 32⟩,
  ⟨1398, false, 1399, false, 28, 1, 35⟩,
  ⟨1400, false, 1401, false, 29, 1, 36⟩,
  ⟨1400, true, 1408, false, 28, 2, 35⟩,
  ⟨1401, false, 1402, false, 31, 1, 38⟩,
  ⟨1402, false, 1403, false, 33, 1, 40⟩,
  ⟨1402, true, 1404, false, 32, 2, 39⟩,
  ⟨1404, false, 1405, false, 33, 1, 40⟩]
theorem carryCases14_07_verified : carryCases14_07.all verified = true := by decide

def carryCases14_08 : List Case := [
  ⟨1404, true, 1407, false, 30, 4, 37⟩,
  ⟨1405, false, 1406, false, 34, 1, 41⟩,
  ⟨1408, false, 1409, false, 29, 1, 36⟩,
  ⟨1408, true, 1411, false, 27, 3, 34⟩,
  ⟨1409, false, 1410, false, 30, 1, 37⟩,
  ⟨1411, false, 1412, false, 30, 1, 37⟩,
  ⟨1411, true, 1415, false, 29, 2, 36⟩,
  ⟨1412, false, 1413, false, 31, 1, 38⟩]
theorem carryCases14_08_verified : carryCases14_08.all verified = true := by decide

def carryCases14_09 : List Case := [
  ⟨1413, false, 1414, false, 32, 1, 39⟩,
  ⟨1415, false, 1416, false, 30, 1, 37⟩,
  ⟨1415, true, 1421, false, 28, 3, 35⟩,
  ⟨1416, false, 1417, false, 32, 1, 39⟩,
  ⟨1417, false, 1418, false, 33, 1, 40⟩,
  ⟨1417, true, 1420, false, 31, 3, 38⟩,
  ⟨1418, false, 1419, false, 34, 1, 41⟩,
  ⟨1421, false, 1422, false, 29, 1, 36⟩]
theorem carryCases14_09_verified : carryCases14_09.all verified = true := by decide

def carryCases14_10 : List Case := [
  ⟨1421, true, 1425, false, 26, 4, 33⟩,
  ⟨1422, false, 1423, false, 30, 1, 37⟩,
  ⟨1423, false, 1424, false, 31, 1, 38⟩,
  ⟨1425, false, 1426, false, 23, 4, 30⟩,
  ⟨1426, false, 1427, false, 28, 1, 35⟩,
  ⟨1426, true, 1434, false, 27, 2, 34⟩,
  ⟨1427, false, 1428, false, 30, 1, 37⟩,
  ⟨1428, false, 1429, false, 32, 1, 39⟩]
theorem carryCases14_10_verified : carryCases14_10.all verified = true := by decide

def carryCases14_11 : List Case := [
  ⟨1428, true, 1430, false, 31, 2, 38⟩,
  ⟨1430, false, 1431, false, 32, 1, 39⟩,
  ⟨1430, true, 1433, false, 29, 4, 36⟩,
  ⟨1431, false, 1432, false, 33, 1, 40⟩,
  ⟨1434, false, 1435, false, 28, 1, 35⟩,
  ⟨1434, true, 1437, false, 26, 3, 33⟩,
  ⟨1435, false, 1436, false, 29, 1, 36⟩,
  ⟨1437, false, 1438, false, 29, 1, 36⟩]
theorem carryCases14_11_verified : carryCases14_11.all verified = true := by decide

def carryCases14 : List Case := carryCases14_00 ++ carryCases14_01 ++ carryCases14_02 ++ carryCases14_03 ++ carryCases14_04 ++ carryCases14_05 ++ carryCases14_06 ++ carryCases14_07 ++ carryCases14_08 ++ carryCases14_09 ++ carryCases14_10 ++ carryCases14_11
theorem carryCases14_verified : carryCases14.all verified = true := by
  simp only [carryCases14, List.all_append, carryCases14_00_verified, carryCases14_01_verified, carryCases14_02_verified, carryCases14_03_verified, carryCases14_04_verified, carryCases14_05_verified, carryCases14_06_verified, carryCases14_07_verified, carryCases14_08_verified, carryCases14_09_verified, carryCases14_10_verified, carryCases14_11_verified, Bool.and_self]
theorem carryCases14_covered : carryCases14.map (fun c => key c.pc c.zero) = keysBetween 2680 195 := by decide
theorem carryCases14_count : carryCases14.length = 96 := by decide
end NF192.Carry
