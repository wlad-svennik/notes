module
public import MachineControlCarryCase

@[expose] public section
namespace NF192.Carry
open KernelRightShift

def key (pc : Nat) (zero : Bool) := 2*pc + zero.toNat

def keysBetween (lo size : Nat) : List Nat :=
  ((List.range size).map (fun j => lo+j)).filter (fun k => selected (k/2) (k%2 == 1))

theorem from_block (cs : List Case) (lo size : Nat)
    (checked : cs.all verified = true)
    (covered : cs.map (fun c => key c.pc c.zero) = keysBetween lo size)
    (pc : Nat) (zero : Bool) (hs : selected pc zero = true)
    (lower : lo ≤ key pc zero) (upper : key pc zero < lo+size)
    (extra : Nat) (space : 40 ≤ (initialWord pc zero).length+extra) :
    ∃ t, WordRun (entryState zero) 13 (ready pc zero extra) (restored pc zero extra)
      (startHead pc) (before (shifted pc zero)+1 : Nat) t := by
  have keyDiv : key pc zero / 2 = pc := by cases zero <;> simp [key] <;> omega
  have keyMod : (key pc zero % 2 == 1) = zero := by cases zero <;> simp [key] <;> omega
  have mem : key pc zero ∈ cs.map (fun c => key c.pc c.zero) := by
    rw [covered]
    apply List.mem_filter.mpr
    refine ⟨List.mem_map.mpr ⟨key pc zero-lo, List.mem_range.mpr (by omega), by omega⟩,?_⟩
    simpa only [keyDiv,keyMod] using hs
  obtain ⟨c,hc,eq⟩ := List.mem_map.mp mem
  have pcEq : c.pc = pc := by
    cases h : c.zero <;> cases zero <;> simp [key,h] at eq <;> omega
  have zeroEq : c.zero = zero := by
    cases h : c.zero <;> cases zero <;> simp_all [key]
  rw [←pcEq,←zeroEq] at space ⊢
  exact case_return (List.all_eq_true.mp checked _ hc) extra space

end NF192.Carry
