module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases05_00 : List Case := [
  ⟨478, false, 479, false, 25, 1, 32⟩,
  ⟨478, true, 481, false, 24, 2, 31⟩,
  ⟨479, false, 480, false, 26, 1, 33⟩,
  ⟨481, false, 482, false, 26, 1, 33⟩,
  ⟨481, true, 484, false, 25, 2, 32⟩,
  ⟨482, false, 483, false, 27, 1, 34⟩,
  ⟨484, false, 485, false, 28, 1, 35⟩,
  ⟨484, true, 488, false, 27, 2, 34⟩]
theorem carryCases05_00_verified : carryCases05_00.all verified = true := by decide

def carryCases05_01 : List Case := [
  ⟨485, false, 486, false, 29, 1, 36⟩,
  ⟨486, false, 487, false, 30, 1, 37⟩,
  ⟨488, false, 489, false, 28, 1, 35⟩,
  ⟨488, true, 494, false, 26, 3, 33⟩,
  ⟨489, false, 490, false, 30, 1, 37⟩,
  ⟨490, false, 491, false, 31, 1, 38⟩,
  ⟨490, true, 493, false, 29, 3, 36⟩,
  ⟨491, false, 492, false, 32, 1, 39⟩]
theorem carryCases05_01_verified : carryCases05_01.all verified = true := by decide

def carryCases05_02 : List Case := [
  ⟨494, false, 495, false, 27, 1, 34⟩,
  ⟨494, true, 497, false, 23, 5, 30⟩,
  ⟨495, false, 496, false, 28, 1, 35⟩,
  ⟨497, false, 498, false, 24, 1, 31⟩,
  ⟨497, true, 501, false, 22, 3, 29⟩,
  ⟨498, false, 499, false, 25, 1, 32⟩,
  ⟨499, false, 500, false, 26, 1, 33⟩,
  ⟨501, false, 502, false, 23, 1, 30⟩]
theorem carryCases05_02_verified : carryCases05_02.all verified = true := by decide

def carryCases05_03 : List Case := [
  ⟨501, true, 504, false, 21, 3, 28⟩,
  ⟨502, false, 503, false, 24, 1, 31⟩,
  ⟨504, false, 505, false, 25, 1, 32⟩,
  ⟨504, true, 512, false, 24, 2, 31⟩,
  ⟨505, false, 506, false, 27, 1, 34⟩,
  ⟨506, false, 507, false, 29, 1, 36⟩,
  ⟨506, true, 508, false, 28, 2, 35⟩,
  ⟨508, false, 509, false, 29, 1, 36⟩]
theorem carryCases05_03_verified : carryCases05_03.all verified = true := by decide

def carryCases05_04 : List Case := [
  ⟨508, true, 511, false, 26, 4, 33⟩,
  ⟨509, false, 510, false, 30, 1, 37⟩,
  ⟨512, false, 513, false, 25, 1, 32⟩,
  ⟨512, true, 515, false, 23, 3, 30⟩,
  ⟨513, false, 514, false, 26, 1, 33⟩,
  ⟨515, false, 516, false, 26, 1, 33⟩,
  ⟨515, true, 519, false, 25, 2, 32⟩,
  ⟨516, false, 517, false, 27, 1, 34⟩]
theorem carryCases05_04_verified : carryCases05_04.all verified = true := by decide

def carryCases05_05 : List Case := [
  ⟨517, false, 518, false, 28, 1, 35⟩,
  ⟨519, false, 520, false, 26, 1, 33⟩,
  ⟨519, true, 525, false, 24, 3, 31⟩,
  ⟨520, false, 521, false, 28, 1, 35⟩,
  ⟨521, false, 522, false, 29, 1, 36⟩,
  ⟨521, true, 524, false, 27, 3, 34⟩,
  ⟨522, false, 523, false, 30, 1, 37⟩,
  ⟨525, false, 526, false, 25, 1, 32⟩]
theorem carryCases05_05_verified : carryCases05_05.all verified = true := by decide

def carryCases05_06 : List Case := [
  ⟨525, true, 529, false, 22, 4, 29⟩,
  ⟨526, false, 527, false, 26, 1, 33⟩,
  ⟨527, false, 528, false, 27, 1, 34⟩,
  ⟨529, false, 530, false, 16, 7, 23⟩,
  ⟨530, false, 531, false, 21, 1, 28⟩,
  ⟨530, true, 533, false, 20, 2, 27⟩,
  ⟨531, false, 532, false, 22, 1, 29⟩,
  ⟨533, false, 534, false, 22, 1, 29⟩]
theorem carryCases05_06_verified : carryCases05_06.all verified = true := by decide

def carryCases05_07 : List Case := [
  ⟨533, true, 536, false, 21, 2, 28⟩,
  ⟨534, false, 535, false, 23, 1, 30⟩,
  ⟨536, false, 537, false, 24, 1, 31⟩,
  ⟨536, true, 540, false, 23, 2, 30⟩,
  ⟨537, false, 538, false, 25, 1, 32⟩,
  ⟨538, false, 539, false, 26, 1, 33⟩,
  ⟨540, false, 541, false, 24, 1, 31⟩,
  ⟨540, true, 546, false, 22, 3, 29⟩]
theorem carryCases05_07_verified : carryCases05_07.all verified = true := by decide

def carryCases05_08 : List Case := [
  ⟨541, false, 542, false, 26, 1, 33⟩,
  ⟨542, false, 543, false, 27, 1, 34⟩,
  ⟨542, true, 545, false, 25, 3, 32⟩,
  ⟨543, false, 544, false, 28, 1, 35⟩,
  ⟨546, false, 547, false, 23, 1, 30⟩,
  ⟨546, true, 549, false, 19, 5, 26⟩,
  ⟨547, false, 548, false, 24, 1, 31⟩,
  ⟨549, false, 550, false, 23, 1, 30⟩]
theorem carryCases05_08_verified : carryCases05_08.all verified = true := by decide

def carryCases05_09 : List Case := [
  ⟨550, false, 551, false, 28, 1, 35⟩,
  ⟨550, true, 553, false, 27, 2, 34⟩,
  ⟨551, false, 552, false, 29, 1, 36⟩,
  ⟨553, false, 554, false, 29, 1, 36⟩,
  ⟨553, true, 556, false, 28, 2, 35⟩,
  ⟨554, false, 555, false, 30, 1, 37⟩,
  ⟨556, false, 557, false, 31, 1, 38⟩,
  ⟨556, true, 560, false, 30, 2, 37⟩]
theorem carryCases05_09_verified : carryCases05_09.all verified = true := by decide

def carryCases05_10 : List Case := [
  ⟨557, false, 558, false, 32, 1, 39⟩,
  ⟨558, false, 559, false, 33, 1, 40⟩,
  ⟨560, false, 561, false, 31, 1, 38⟩,
  ⟨560, true, 566, false, 29, 3, 36⟩,
  ⟨561, false, 562, false, 33, 1, 40⟩,
  ⟨562, false, 563, false, 34, 1, 41⟩,
  ⟨562, true, 565, false, 32, 3, 39⟩,
  ⟨563, false, 564, false, 35, 1, 42⟩]
theorem carryCases05_10_verified : carryCases05_10.all verified = true := by decide

def carryCases05_11 : List Case := [
  ⟨566, false, 567, false, 30, 1, 37⟩,
  ⟨566, true, 569, false, 26, 5, 33⟩,
  ⟨567, false, 568, false, 31, 1, 38⟩,
  ⟨569, false, 570, false, 31, 1, 38⟩,
  ⟨569, true, 572, false, 30, 2, 37⟩,
  ⟨570, false, 571, false, 32, 1, 39⟩,
  ⟨572, false, 573, false, 32, 1, 39⟩,
  ⟨572, true, 575, false, 31, 2, 38⟩]
theorem carryCases05_11_verified : carryCases05_11.all verified = true := by decide

def carryCases05 : List Case := carryCases05_00 ++ carryCases05_01 ++ carryCases05_02 ++ carryCases05_03 ++ carryCases05_04 ++ carryCases05_05 ++ carryCases05_06 ++ carryCases05_07 ++ carryCases05_08 ++ carryCases05_09 ++ carryCases05_10 ++ carryCases05_11
theorem carryCases05_verified : carryCases05.all verified = true := by
  simp only [carryCases05, List.all_append, carryCases05_00_verified, carryCases05_01_verified, carryCases05_02_verified, carryCases05_03_verified, carryCases05_04_verified, carryCases05_05_verified, carryCases05_06_verified, carryCases05_07_verified, carryCases05_08_verified, carryCases05_09_verified, carryCases05_10_verified, carryCases05_11_verified, Bool.and_self]
theorem carryCases05_covered : carryCases05.map (fun c => key c.pc c.zero) = keysBetween 956 190 := by decide
theorem carryCases05_count : carryCases05.length = 96 := by decide
end NF192.Carry
