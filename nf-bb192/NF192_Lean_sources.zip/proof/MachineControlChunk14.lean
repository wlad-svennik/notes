module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases14_00 : List Case := [
  ⟨2905, false, 16693021440, 3808119552, 70, 0, 0⟩,
  ⟨2909, false, 4076555008, 318458624, 62, 0, 0⟩,
  ⟨2912, false, 989547264, 184240896, 58, 0, 0⟩,
  ⟨2916, true, 22665710336, 3338357504, 35, 31, 38⟩,
  ⟨2919, false, 65615383296, 14075775744, 74, 0, 0⟩,
  ⟨2920, false, 3338357504, 117132032, 66, 0, 0⟩,
  ⟨2923, false, 3875228416, 654002944, 66, 0, 0⟩,
  ⟨2927, false, 15417953024, 385567488, 68, 0, 0⟩
]

theorem cases14_00_verified : cases14_00.all verified = true := by decide

def cases14_01 : List Case := [
  ⟨2932, false, 63736335104, 12196727552, 72, 0, 0⟩,
  ⟨2933, false, 7901760256, 385567488, 64, 0, 0⟩,
  ⟨2937, false, 8438631168, 922438400, 66, 0, 0⟩,
  ⟨2942, true, 2851818240, 435899136, 30, 28, 35⟩,
  ⟨2945, false, 8220527360, 1778076416, 66, 0, 0⟩,
  ⟨2946, false, 435899136, 33245952, 58, 0, 0⟩,
  ⟨2949, false, 503008000, 100354816, 58, 0, 0⟩,
  ⟨2953, false, 1945848576, 66800384, 60, 0, 0⟩
]

theorem cases14_01_verified : cases14_01.all verified = true := by decide

def cases14_02 : List Case := [
  ⟨2958, false, 7985646336, 1543195392, 64, 0, 0⟩,
  ⟨2959, false, 1006324480, 66800384, 56, 0, 0⟩,
  ⟨2963, false, 1073433344, 133909248, 58, 0, 0⟩,
  ⟨2965, false, 1526528, 477952, 40, 0, 0⟩,
  ⟨2967, false, 2050816, 1002240, 38, 0, 0⟩,
  ⟨2968, false, 51968, 2816, 28, 0, 0⟩,
  ⟨2972, false, 1616640, 43776, 38, 0, 0⟩,
  ⟨2975, false, 3451648, 305920, 42, 0, 0⟩
]

theorem cases14_02_verified : cases14_02.all verified = true := by decide

def cases14_03 : List Case := [
  ⟨2979, false, 30190336, 830208, 48, 0, 0⟩,
  ⟨2984, false, 124562176, 23898880, 52, 0, 0⟩,
  ⟨2985, false, 15510272, 830208, 44, 0, 0⟩,
  ⟨2988, false, 8170240, 1878784, 46, 0, 0⟩,
  ⟨2992, false, 2009856, 174848, 38, 0, 0⟩,
  ⟨2995, false, 502528, 109312, 34, 0, 0⟩,
  ⟨3001, false, 224000, 92928, 32, 0, 0⟩,
  ⟨3005, true, 5565184, 846592, 23, 19, 26⟩
]

theorem cases14_03_verified : cases14_03.all verified = true := by decide

def cases14_04 : List Case := [
  ⟨3008, false, 16050944, 3468032, 50, 0, 0⟩,
  ⟨3009, false, 846592, 60160, 42, 0, 0⟩,
  ⟨3012, false, 977664, 191232, 42, 0, 0⟩,
  ⟨3015, false, 518912, 125696, 36, 0, 0⟩,
  ⟨3016, false, 6912, 256, 32, 0, 0⟩,
  ⟨3019, false, 100096, 1792, 36, 0, 0⟩,
  ⟨3022, false, 214784, 18176, 40, 0, 0⟩,
  ⟨3026, false, 1885952, 50944, 46, 0, 0⟩
]

theorem cases14_04_verified : cases14_04.all verified = true := by decide

def cases14_05 : List Case := [
  ⟨3031, false, 7784192, 1492736, 50, 0, 0⟩,
  ⟨3032, false, 968448, 50944, 42, 0, 0⟩,
  ⟨3035, false, 509696, 116480, 44, 0, 0⟩,
  ⟨3039, false, 239360, 9984, 38, 0, 0⟩,
  ⟨3042, false, 124672, 26368, 42, 0, 0⟩,
  ⟨3046, true, 694016, 104192, 18, 16, 23⟩,
  ⟨3049, false, 2004736, 431872, 42, 0, 0⟩,
  ⟨3050, false, 104192, 5888, 34, 0, 0⟩
]

theorem cases14_05_verified : cases14_05.all verified = true := by decide

def cases14_06 : List Case := [
  ⟨3053, false, 120576, 22272, 34, 0, 0⟩,
  ⟨3057, false, 472832, 14080, 36, 0, 0⟩,
  ⟨3062, false, 1947392, 374528, 40, 0, 0⟩,
  ⟨3063, false, 243456, 14080, 32, 0, 0⟩,
  ⟨3067, false, 259840, 30464, 34, 0, 0⟩,
  ⟨3070, false, 52992, 3840, 28, 0, 0⟩,
  ⟨3073, false, 93952, 12032, 40, 0, 0⟩,
  ⟨3077, false, 519936, 126720, 34, 0, 0⟩
]

theorem cases14_06_verified : cases14_06.all verified = true := by decide

def cases14_07 : List Case := [
  ⟨3079, true, 40704, 16128, 9, 13, 20⟩,
  ⟨3083, false, 483072, 24320, 34, 0, 0⟩,
  ⟨3086, false, 253696, 57088, 38, 0, 0⟩,
  ⟨3088, false, 32512, 16128, 26, 0, 0⟩
]

theorem cases14_07_verified : cases14_07.all verified = true := by decide

def cases14 : List Case := cases14_00 ++ cases14_01 ++ cases14_02 ++ cases14_03 ++ cases14_04 ++ cases14_05 ++ cases14_06 ++ cases14_07

theorem cases14_verified : cases14.all verified = true := by
  simp only [cases14, List.all_append, cases14_00_verified, cases14_01_verified, cases14_02_verified, cases14_03_verified, cases14_04_verified, cases14_05_verified, cases14_06_verified, cases14_07_verified, Bool.and_self]

end NF192.Control
