import NFInterpretsComb
import NormalizedBasis

set_option autoImplicit false

/-!
# The machine's normalized basis in New Foundations

The parameters `t` and `b` are independent variables in the two stratified
graph comprehensions. Only after constructing the curried tester do we
specialize them to the previously constructed objects `K B` and `B`.
-/

namespace FFL.FirstOrder.SetTheory.NFFn.Normalized

open JensenNFU.TFm (scons)
open DirectTranslation

section Graph

variable {V : Type} [SetStructure V]

/-- The output graph at a given function and argument. -/
def Outputs (t b f x y : V) : Prop :=
  (AppR f x x ∧ y = t) ∨ (¬ AppR f x x ∧ y = b)

/-- The inner function obtained by binding the argument of the test. -/
def SectionGraph (t b f g : V) : Prop :=
  ∀ x y, AppR g x y ↔ Outputs t b f x y

end Graph

private def eqAt {γ : ℕ → ℕ} (i j : ℕ) (hi : γ i = 11) (hj : γ j = 11) :
    NDef γ (fun _ _ env => env i = env j) :=
  (NDef.ofS (SDef.eq (τ := ![0, 0]) 0 1) ![i, j] 11
    (fun n => by fin_cases n <;> simp [hi, hj])).congr fun _ _ _ => Iff.rfl

/-- The pair components and both output parameters have the same type. -/
private def outputsDef {γ : ℕ → ℕ} (t b f x y : ℕ)
    (ht : γ t = 11) (hb : γ b = 11) (hf : γ f = 12)
    (hx : γ x = 11) (hy : γ y = 11) :
    NDef γ (fun _ _ v => Outputs (v t) (v b) (v f) (v x) (v y)) :=
  let fixed := NDef.ofS (γ := γ) appD ![f, x, x] 3 (fun i => by fin_cases i <;> simp [hf, hx])
  ((fixed.and (eqAt y t hy ht)).or
    (fixed.not.and (eqAt y b hy hb))).congr fun _ _ _ => Iff.rfl

private def sectionDef {γ : ℕ → ℕ} (t b f g : ℕ)
    (ht : γ t = 11) (hb : γ b = 11) (hf : γ f = 12) (hg : γ g = 12) :
    NDef γ (fun _ _ v => SectionGraph (v t) (v b) (v f) (v g)) :=
  (NDef.all 11 (NDef.all 11
    ((NDef.ofS appD ![g + 2, 1, 0] 3 (fun i => by fin_cases i <;> simp [hg])).iff
      (outputsDef (t + 2) (b + 2) (f + 2) 1 0 ht hb hf rfl rfl)))).congr
    fun _ _ _ => Iff.rfl

section Model

variable {V : Type} [SetStructure V] [Nonempty V] [hT : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙]

private theorem outputs_total (t b f x : V) : ∃ y, Outputs t b f x y := by
  by_cases h : AppR f x x
  · exact ⟨t, Or.inl ⟨h, rfl⟩⟩
  · exact ⟨b, Or.inr ⟨h, rfl⟩⟩

private theorem outputs_unique {t b f x y y' : V}
    (h : Outputs t b f x y) (h' : Outputs t b f x y') : y = y' := by
  rcases h with ⟨p, h⟩ | ⟨p, h⟩ <;> rcases h' with ⟨p', h'⟩ | ⟨p', h'⟩
  · exact h.trans h'.symm
  · exact (p' p).elim
  · exact (p p').elim
  · exact h.trans h'.symm

/-- Comprehend the graph in the argument for fixed `f`, `t` and `b`. -/
private theorem exists_section (t b f : V) : ∃ g, SectionGraph t b f g := by
  obtain ⟨F, hF⟩ := (NDef.ex (γ := scons 11 (scons 12 (fun _ => 11))) 11
    (NDef.ex 11 ((NDef.ofS prD ![2, 1, 0] 3 (fun i => by fin_cases i <;> rfl)).and
      (outputsDef 4 5 3 1 0 rfl rfl rfl rfl rfl)))).comprehension
      (scons f (scons t (fun _ => b)))
  exact app_of_graph (G := Outputs t b f) hF (outputs_total t b f)
    (fun _ _ _ h h' => outputs_unique h h')

private theorem section_unique {t b f g g' : V}
    (h : SectionGraph t b f g) (h' : SectionGraph t b f g') : g = g' :=
  app_ext fun x y hxy => (h' x y).mpr ((h x y).mp hxy)

/-- A second stratified comprehension curries the section as an NF object. -/
theorem exists_tester (t b : V) :
    ∃ q : V, ∀ f g, AppR q f g ↔ SectionGraph t b f g := by
  obtain ⟨F, hF⟩ := (NDef.ex (γ := scons 12 (fun _ => 11)) 12 (NDef.ex 12
    ((NDef.ofS prD ![2, 1, 0] 4 (fun i => by fin_cases i <;> rfl)).and
      (sectionDef 3 4 1 0 rfl rfl rfl rfl)))).comprehension (scons t (fun _ => b))
  exact app_of_graph (G := SectionGraph t b) hF (exists_section t b)
    (fun _ _ _ h h' => section_unique h h')

local notation "N" => Comb.combTranslation.Model V

/-- Transfer the parametric tester to the archive's application algebra. -/
theorem exists_application_tester (t b : N) :
    ∃ q : N, (∀ f x : N, CNF.App f x = x → CNF.App (CNF.App q f) x = t) ∧
      (∀ f x : N, CNF.App f x ≠ x → CNF.App (CNF.App q f) x = b) := by
  obtain ⟨q, hq⟩ := exists_tester (t : V) (b : V)
  let q' : N := Comb.toModel q
  have happ (a x : N) : AppR (a : V) (x : V) ((CNF.App a x : N) : V) :=
    (Comb.app_iff a x _).mp rfl
  have hout (f x : N) :
      Outputs (t : V) (b : V) (f : V) (x : V) ((CNF.App (CNF.App q' f) x : N) : V) :=
    (((hq _ _).mp (happ q' f)) _ _).mp (happ (CNF.App q' f) x)
  refine ⟨q', ?_, ?_⟩
  · intro f x hf
    have hfix := (Comb.app_iff f x x).mp hf.symm
    rcases hout f x with ⟨_, h⟩ | ⟨h, _⟩
    · exact Comb.coe_inj h
    · exact (h hfix).elim
  · intro f x hf
    rcases hout f x with ⟨h, _⟩ | ⟨_, h⟩
    · exact (hf ((Comb.app_iff f x x).mpr h).symm).elim
    · exact Comb.coe_inj h

/-- Per the B law, `B = K B` forces every object to equal `B`. -/
private theorem true_ne_false : CNF.Kf (CNF.Bc : N) ≠ CNF.Bc := by
  have hm := Comb.combModel_models (M := V)
  intro e
  have constB (x : N) : CNF.App CNF.Bc x = CNF.Bc := by
    calc
      _ = CNF.App (CNF.Kf CNF.Bc) x := congrArg (fun f : N => CNF.App f x) e.symm
      _ = _ := CNF.k_app hm _ _
  have collapse (a : N) : CNF.Bc = a := by
    calc
      CNF.Bc = CNF.App (CNF.App (CNF.App CNF.Bc (CNF.Kf (CNF.Kf a))) CNF.Bc) CNF.Bc := by
        simp only [constB]
      _ = CNF.App (CNF.App (CNF.Kf (CNF.Kf a)) (CNF.Kf CNF.Bc)) (CNF.App CNF.Bc CNF.Bc) :=
        CNF.b_app hm _ _ _
      _ = a := by simp only [CNF.k_app hm]
  exact CNF.b_ne_r hm (collapse CNF.Rc)

/-- Every model of NF carries the exact normalized basis used by the machine. -/
noncomputable def ofNF : _root_.NF192.NormalizedBasis N := by
  have hm := Comb.combModel_models (M := V)
  let h := exists_application_tester (V := V) (CNF.Kf (CNF.Bc : N)) CNF.Bc
  exact {
    app := CNF.App
    K := CNF.Kf
    B := CNF.Bc
    q := Classical.choose h
    k_app := CNF.k_app hm
    b_app := CNF.b_app hm
    ext := fun hfg => CNF.c_ext hm hfg
    q_true := (Classical.choose_spec h).1
    q_false := (Classical.choose_spec h).2
    distinct := true_ne_false
  }

end Model

end FFL.FirstOrder.SetTheory.NFFn.Normalized

#print axioms FFL.FirstOrder.SetTheory.NFFn.Normalized.ofNF
