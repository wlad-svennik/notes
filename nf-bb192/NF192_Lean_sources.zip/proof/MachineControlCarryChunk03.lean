module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases03_00 : List Case := [
  ⟨285, false, 286, false, 33, 1, 40⟩,
  ⟨285, true, 288, false, 31, 3, 38⟩,
  ⟨286, false, 287, false, 34, 1, 41⟩,
  ⟨289, false, 290, false, 29, 1, 36⟩,
  ⟨289, true, 292, false, 25, 5, 32⟩,
  ⟨290, false, 291, false, 30, 1, 37⟩,
  ⟨292, false, 293, false, 26, 1, 33⟩,
  ⟨292, true, 296, false, 24, 3, 31⟩]
theorem carryCases03_00_verified : carryCases03_00.all verified = true := by decide

def carryCases03_01 : List Case := [
  ⟨293, false, 294, false, 27, 1, 34⟩,
  ⟨294, false, 295, false, 28, 1, 35⟩,
  ⟨296, false, 297, false, 25, 1, 32⟩,
  ⟨296, true, 299, false, 21, 5, 28⟩,
  ⟨297, false, 298, false, 26, 1, 33⟩,
  ⟨299, false, 300, false, 25, 1, 32⟩,
  ⟨299, true, 302, false, 24, 2, 31⟩,
  ⟨300, false, 301, false, 26, 1, 33⟩]
theorem carryCases03_01_verified : carryCases03_01.all verified = true := by decide

def carryCases03_02 : List Case := [
  ⟨302, false, 303, false, 26, 1, 33⟩,
  ⟨302, true, 305, false, 25, 2, 32⟩,
  ⟨303, false, 304, false, 27, 1, 34⟩,
  ⟨305, false, 306, false, 28, 1, 35⟩,
  ⟨305, true, 309, false, 27, 2, 34⟩,
  ⟨306, false, 307, false, 29, 1, 36⟩,
  ⟨307, false, 308, false, 30, 1, 37⟩,
  ⟨309, false, 310, false, 28, 1, 35⟩]
theorem carryCases03_02_verified : carryCases03_02.all verified = true := by decide

def carryCases03_03 : List Case := [
  ⟨309, true, 315, false, 26, 3, 33⟩,
  ⟨310, false, 311, false, 30, 1, 37⟩,
  ⟨311, false, 312, false, 31, 1, 38⟩,
  ⟨311, true, 314, false, 29, 3, 36⟩,
  ⟨312, false, 313, false, 32, 1, 39⟩,
  ⟨315, false, 316, false, 27, 1, 34⟩,
  ⟨315, true, 318, false, 23, 5, 30⟩,
  ⟨316, false, 317, false, 28, 1, 35⟩]
theorem carryCases03_03_verified : carryCases03_03.all verified = true := by decide

def carryCases03_04 : List Case := [
  ⟨318, false, 319, false, 25, 1, 32⟩,
  ⟨318, true, 322, false, 24, 2, 31⟩,
  ⟨319, false, 320, false, 26, 1, 33⟩,
  ⟨320, false, 321, false, 27, 1, 34⟩,
  ⟨322, false, 323, false, 25, 1, 32⟩,
  ⟨322, true, 325, false, 22, 4, 29⟩,
  ⟨323, false, 324, false, 26, 1, 33⟩,
  ⟨325, false, 326, false, 25, 1, 32⟩]
theorem carryCases03_04_verified : carryCases03_04.all verified = true := by decide

def carryCases03_05 : List Case := [
  ⟨325, true, 333, false, 24, 2, 31⟩,
  ⟨326, false, 327, false, 27, 1, 34⟩,
  ⟨327, false, 328, false, 29, 1, 36⟩,
  ⟨327, true, 329, false, 28, 2, 35⟩,
  ⟨329, false, 330, false, 29, 1, 36⟩,
  ⟨329, true, 332, false, 26, 4, 33⟩,
  ⟨330, false, 331, false, 30, 1, 37⟩,
  ⟨333, false, 334, false, 25, 1, 32⟩]
theorem carryCases03_05_verified : carryCases03_05.all verified = true := by decide

def carryCases03_06 : List Case := [
  ⟨333, true, 336, false, 23, 3, 30⟩,
  ⟨334, false, 335, false, 26, 1, 33⟩,
  ⟨336, false, 337, false, 26, 1, 33⟩,
  ⟨336, true, 340, false, 25, 2, 32⟩,
  ⟨337, false, 338, false, 27, 1, 34⟩,
  ⟨338, false, 339, false, 28, 1, 35⟩,
  ⟨340, false, 341, false, 26, 1, 33⟩,
  ⟨340, true, 346, false, 24, 3, 31⟩]
theorem carryCases03_06_verified : carryCases03_06.all verified = true := by decide

def carryCases03_07 : List Case := [
  ⟨341, false, 342, false, 28, 1, 35⟩,
  ⟨342, false, 343, false, 29, 1, 36⟩,
  ⟨342, true, 345, false, 27, 3, 34⟩,
  ⟨343, false, 344, false, 30, 1, 37⟩,
  ⟨346, false, 347, false, 25, 1, 32⟩,
  ⟨346, true, 350, false, 18, 8, 25⟩,
  ⟨347, false, 348, false, 26, 1, 33⟩,
  ⟨348, false, 349, false, 27, 1, 34⟩]
theorem carryCases03_07_verified : carryCases03_07.all verified = true := by decide

def carryCases03_08 : List Case := [
  ⟨350, false, 351, false, 23, 1, 30⟩,
  ⟨350, true, 358, false, 22, 2, 29⟩,
  ⟨351, false, 352, false, 25, 1, 32⟩,
  ⟨352, false, 353, false, 27, 1, 34⟩,
  ⟨352, true, 354, false, 26, 2, 33⟩,
  ⟨354, false, 355, false, 27, 1, 34⟩,
  ⟨354, true, 357, false, 24, 4, 31⟩,
  ⟨355, false, 356, false, 28, 1, 35⟩]
theorem carryCases03_08_verified : carryCases03_08.all verified = true := by decide

def carryCases03_09 : List Case := [
  ⟨358, false, 359, false, 23, 1, 30⟩,
  ⟨358, true, 361, false, 21, 3, 28⟩,
  ⟨359, false, 360, false, 24, 1, 31⟩,
  ⟨361, false, 362, false, 24, 1, 31⟩,
  ⟨361, true, 365, false, 23, 2, 30⟩,
  ⟨362, false, 363, false, 25, 1, 32⟩,
  ⟨363, false, 364, false, 26, 1, 33⟩,
  ⟨365, false, 366, false, 24, 1, 31⟩]
theorem carryCases03_09_verified : carryCases03_09.all verified = true := by decide

def carryCases03_10 : List Case := [
  ⟨365, true, 371, false, 22, 3, 29⟩,
  ⟨366, false, 367, false, 26, 1, 33⟩,
  ⟨367, false, 368, false, 27, 1, 34⟩,
  ⟨367, true, 370, false, 25, 3, 32⟩,
  ⟨368, false, 369, false, 28, 1, 35⟩,
  ⟨371, false, 372, false, 23, 1, 30⟩,
  ⟨371, true, 375, false, 20, 4, 27⟩,
  ⟨372, false, 373, false, 24, 1, 31⟩]
theorem carryCases03_10_verified : carryCases03_10.all verified = true := by decide

def carryCases03_11 : List Case := [
  ⟨373, false, 374, false, 25, 1, 32⟩,
  ⟨375, false, 376, false, 23, 1, 30⟩,
  ⟨375, true, 383, false, 22, 2, 29⟩,
  ⟨376, false, 377, false, 25, 1, 32⟩,
  ⟨377, false, 378, false, 27, 1, 34⟩,
  ⟨377, true, 379, false, 26, 2, 33⟩,
  ⟨379, false, 380, false, 27, 1, 34⟩,
  ⟨379, true, 382, false, 24, 4, 31⟩]
theorem carryCases03_11_verified : carryCases03_11.all verified = true := by decide

def carryCases03 : List Case := carryCases03_00 ++ carryCases03_01 ++ carryCases03_02 ++ carryCases03_03 ++ carryCases03_04 ++ carryCases03_05 ++ carryCases03_06 ++ carryCases03_07 ++ carryCases03_08 ++ carryCases03_09 ++ carryCases03_10 ++ carryCases03_11
theorem carryCases03_verified : carryCases03.all verified = true := by
  simp only [carryCases03, List.all_append, carryCases03_00_verified, carryCases03_01_verified, carryCases03_02_verified, carryCases03_03_verified, carryCases03_04_verified, carryCases03_05_verified, carryCases03_06_verified, carryCases03_07_verified, carryCases03_08_verified, carryCases03_09_verified, carryCases03_10_verified, carryCases03_11_verified, Bool.and_self]
theorem carryCases03_covered : carryCases03.map (fun c => key c.pc c.zero) = keysBetween 570 190 := by decide
theorem carryCases03_count : carryCases03.length = 96 := by decide
end NF192.Carry
