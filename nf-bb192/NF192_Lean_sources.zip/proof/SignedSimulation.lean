module
public import BinarySimulation
public import StartupCalibration

@[expose] public section

/-! Positive binary blocks for both the exceptional signed counter and
ordinary source configurations, with a single entry at the checked margin. -/
namespace NF192.SignedSimulation

open NF210 NF192.Emitter NF192.Numerical NF192.BinarySimulation

abbrev Signed := Bool × Source.Config
abbrev FrameRelation (n : Nat) := Bool → Relation n

def Related {n : Nat} (R : FrameRelation n) (s : Signed) (b : TM.Configuration n) : Prop :=
  BinarySimulation.Related (R s.1) s.2 b

structure Protocol {n : Nat} (M : TM.Machine n) (R : FrameRelation n) : Prop where
  live : ∀ cold s b, R cold s b → b.state ≠ none
  instruction : ∀ cold s b, R cold s b →
    ∃ ticks, 0 < ticks ∧ Related R (bootstrapStep (cold,some s)) (TM.run M ticks b)

theorem Protocol.one {n : Nat} {M : TM.Machine n} {R : FrameRelation n}
    (sim : Protocol M R) {s : Signed} {b : TM.Configuration n} (h : Related R s b) :
    ∃ ticks, 0 < ticks ∧ Related R (bootstrapStep s) (TM.run M ticks b) := by
  rcases s with ⟨cold,s⟩
  cases s with
  | some p => exact sim.instruction cold p b h
  | none =>
    have halt : b.state = none := h
    refine ⟨1,by decide,?_⟩
    rw [TM.run_of_halted M b halt]
    cases cold <;> exact halt

theorem Protocol.realize {n : Nat} {M : TM.Machine n} {R : FrameRelation n}
    (sim : Protocol M R) (k : Nat) {s : Signed} {b : TM.Configuration n} (entry : Related R s b) :
    ∃ ticks, k ≤ ticks ∧ Related R (bootstrapAdvance k s) (TM.run M ticks b) := by
  induction k generalizing s b with
  | zero => exact ⟨0,Nat.le_refl _,entry⟩
  | succ k ih =>
    obtain ⟨a,ha,hstep⟩ := sim.one entry
    obtain ⟨d,hd,hend⟩ := ih hstep
    exact ⟨a+d,by omega,by rw [TM.run_add]; exact hend⟩

theorem Protocol.halts_iff {n : Nat} {M : TM.Machine n} {R : FrameRelation n}
    (sim : Protocol M R) {s : Signed} {b : TM.Configuration n} (entry : Related R s b) :
    BinarySimulation.HaltsFrom M b ↔ BootstrapHalts s := by
  constructor
  · rintro ⟨k,hk⟩
    obtain ⟨d,hd,hend⟩ := sim.realize k entry
    have stopped : (TM.run M d b).state = none := by
      rw [←show k+(d-k)=d by omega,TM.run_add,TM.run_of_halted M _ hk]
      exact hk
    cases hs : (bootstrapAdvance k s).2 with
    | none => exact ⟨k,hs⟩
    | some p =>
      unfold Related at hend
      rw [hs] at hend
      exact False.elim (sim.live _ _ _ hend stopped)
  · rintro ⟨k,hk⟩
    obtain ⟨d,_,hend⟩ := sim.realize k entry
    unfold Related at hend
    rw [hk] at hend
    exact ⟨d,hend⟩

/-- All startup, source search and halt reflection are discharged.
The two explicit premises select the binary instruction invariant and its
entry on the full canonical tape at the 33,911-step startup margin. -/
theorem blank_halts_iff_goal_of_protocol {R : FrameRelation 192}
    (sim : Protocol Selected.machine R)
    (entry : Related R (true,liftConfig StartupCalibration.margin) Frame.firstMargin.config) :
    TM.Halts Selected.machine Selected.start ↔ Deriv goal := by
  have pre := BinarySimulation.prefix_iff Selected.machine (TM.blank Selected.start) 33911
  rw [Frame.blank_margin_frame] at pre
  exact pre.trans ((sim.halts_iff entry).trans StartupCalibration.signed_margin_halts_iff_goal)

end NF192.SignedSimulation

#print axioms NF192.SignedSimulation.Protocol.halts_iff
#print axioms NF192.SignedSimulation.blank_halts_iff_goal_of_protocol
