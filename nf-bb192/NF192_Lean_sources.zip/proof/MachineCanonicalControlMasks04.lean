module
public import MachineCanonicalControlMasks

@[expose] public section
namespace NF192.CanonicalControl
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem mask2048 : checkRange 2048 32 = true := by decide +kernel
theorem mask2080 : checkRange 2080 32 = true := by decide +kernel
theorem mask2112 : checkRange 2112 32 = true := by decide +kernel
theorem mask2144 : checkRange 2144 32 = true := by decide +kernel
theorem mask2176 : checkRange 2176 32 = true := by decide +kernel
theorem mask2208 : checkRange 2208 32 = true := by decide +kernel
theorem mask2240 : checkRange 2240 32 = true := by decide +kernel
theorem mask2272 : checkRange 2272 32 = true := by decide +kernel
theorem mask2304 : checkRange 2304 32 = true := by decide +kernel
theorem mask2336 : checkRange 2336 32 = true := by decide +kernel
theorem mask2368 : checkRange 2368 32 = true := by decide +kernel
theorem mask2400 : checkRange 2400 32 = true := by decide +kernel
theorem mask2432 : checkRange 2432 32 = true := by decide +kernel
theorem mask2464 : checkRange 2464 32 = true := by decide +kernel
theorem mask2496 : checkRange 2496 32 = true := by decide +kernel
theorem mask2528 : checkRange 2528 32 = true := by decide +kernel
end NF192.CanonicalControl
