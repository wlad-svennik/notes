module
public import NumericalEmitterBinding
public import NumericalAXBatches

@[expose] public section

/-!
# The initial negative counter

At the first AX entry logical register 0 is -1. A cold configuration stores a
zero in its place and interprets that coordinate as -1 until the first
opcode that increments it. Forbidding accesses to register 0 inside a block
proves the same positive finite trace for the cold state. The flag is dropped
precisely on that first increment, with natural value zero.
-/

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Emitter

open NF192.Numerical Registers

def usesCounter : Instruction → Bool
  | .inc r _ | .dec r _ _ | .decHalt r _ => r.val == 0
  | _ => false

def frozen (pc : Nat) : Instruction :=
  if usesCounter (actual pc) then .halt else actual pc

theorem frozen_placement {code : Code} {pc last : Nat}
    (he : Embedded actual code pc last [] [])
    (hfree : (compile code pc last [] []).all (fun op => !(usesCounter op)) = true) :
    Embedded frozen code pc last [] [] := by
  intro i hi
  have hidx : i < (compile code pc last [] []).length := by simpa only [compile_length] using hi
  have hm := List.getElem_mem hidx
  have h := (List.all_eq_true.mp hfree) _ hm
  have hv : usesCounter (actual (pc+i)) = false := by simpa [he i hi] using h
  rw [frozen, if_neg (by simp [hv])]
  exact he i hi

theorem frozen_ax : Embedded frozen batchCode 40 2968 [] [] :=
  frozen_placement batch_embedded (by decide)

/-- Warm is the ordinary source semantics. Cold indicates the single exceptional
value of register 0. A decrement of that negative value is outside the interface. -/
def bootstrapStep (s : Bool × Source.Config) : Bool × Source.Config :=
  if s.1 then
    match s.2 with
    | none => (true,none)
    | some (pc,rs) =>
      if usesCounter (actual pc) then
        match Source.program pc with
        | .inl (_,next) => (false,Source.Config.active next (Source.setReg rs 0 0))
        | _ => (true,none)
      else (true,Source.step s.2)
  else (false,Source.step s.2)

def bootstrapAdvance : Nat → (Bool × Source.Config) → Bool × Source.Config
  | 0,s => s
  | n+1,s => bootstrapAdvance n (bootstrapStep s)

theorem bootstrapAdvance_add (a b : Nat) (s : Bool × Source.Config) :
    bootstrapAdvance (a+b) s = bootstrapAdvance b (bootstrapAdvance a s) := by
  induction a generalizing s with
  | zero => simp [bootstrapAdvance]
  | succ a ih => simp only [Nat.succ_add, bootstrapAdvance, ih]

theorem frozen_step {s t : Config} (h : step frozen s = some t) :
    bootstrapStep (true,liftConfig s) = (true,liftConfig t) := by
  have ok : usesCounter (actual s.pc) = false := by
    cases ht : usesCounter (actual s.pc) with
    | false => rfl
    | true => simp [step, frozen, ht] at h
  have ha : step actual s = some t := by simpa only [step, frozen, ok, Bool.false_eq_true, if_false] using h
  have he := actual_step ha
  simpa only [bootstrapStep, liftConfig, Source.Config.active, ok, Bool.false_eq_true, if_false,
    Bool.true_eq, if_true] using congrArg (fun x => (true, x)) he

theorem frozen_run (n : Nat) {s t : Config} (h : run frozen n s = some t) :
    bootstrapAdvance n (true,liftConfig s) = (true,liftConfig t) := by
  induction n generalizing s with
  | zero => exact congrArg (fun x => (true,liftConfig x)) (Option.some.inj h)
  | succ n ih =>
      cases hs : step frozen s with
      | none => simp [run, hs] at h
      | some u =>
          have rest : run frozen n u = some t := by simpa only [run, hs, Option.bind_some] using h
          exact (congrArg (bootstrapAdvance n) (frozen_step hs)).trans (ih rest)

def coldFrame (pc c : Nat) (ts : Nat×Nat) : Config :=
  ⟨pc, (frameWith 0 ts c 0 0 0).regs⟩

def coldPayload (c : Nat) (ts : Nat×Nat) : Nat×Nat :=
  pushRows ts (rowList 0 0 c 0)

theorem frozenJump (pc next : Nat) (rs : Registers) (h : frozen pc = .jump next) :
    Reaches frozen ⟨pc,rs⟩ (some ⟨next,rs⟩) :=
  Reaches.one (by simp only [step, h])

theorem frozen_batch (c : Nat) (ts : Nat×Nat) :
    Reaches frozen (coldFrame 40 c ts) (some (coldFrame 39 c (coldPayload c ts))) := by
  have h := (batch_eval 0 ts.1 ts.2 c 0 0 0 0 0).compiled frozen 40 2968 [] [] frozen_ax
  change Reaches frozen (coldFrame 40 c ts)
    (some ⟨2968, (save (frameWith 0 ts c 0 0 0) (rowList 0 0 c 0)).regs⟩) at h
  rw [save_frameWith] at h
  exact h.trans (frozenJump 2968 39 _ (by decide))

theorem frozen_guard (c : Nat) (ts : Nat×Nat) :
    Reaches frozen (coldFrame 39 (c+1) ts) (some (coldFrame 40 c ts)) := by
  have h : frozen 39 = .dec 3 2969 40 := by decide
  apply Reaches.one
  simp only [step, coldFrame, frameWith, Frame.regs, h, mk9_get_3, Nat.add_one_ne_zero,
    if_false, Nat.add_sub_cancel, mk9_set_3]

theorem frozen_guard_zero (ts : Nat×Nat) :
    Reaches frozen (coldFrame 39 0 ts) (some (coldFrame 2969 0 ts)) := by
  have h : frozen 39 = .dec 3 2969 40 := by decide
  apply Reaches.one
  simp [step, coldFrame, frameWith, Frame.regs, h, mk9_get_3]

def startupPayload : Nat×Nat := coldPayload 0 (coldPayload 1 (coldPayload 2 (0,0)))

theorem frozen_three_batches :
    Reaches frozen (coldFrame 40 2 (0,0)) (some (coldFrame 2969 0 startupPayload)) := by
  apply (frozen_batch 2 (0,0)).trans
  apply (frozen_guard 1 _).trans
  apply (frozen_batch 1 _).trans
  apply (frozen_guard 0 _).trans
  apply (frozen_batch 0 _).trans
  exact frozen_guard_zero _

end NF192.Emitter
