module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block0000 : checkRange 0 32 = true := by decide +kernel
theorem block0032 : checkRange 32 32 = true := by decide +kernel
theorem block0064 : checkRange 64 32 = true := by decide +kernel
theorem block0096 : checkRange 96 32 = true := by decide +kernel
theorem block0128 : checkRange 128 32 = true := by decide +kernel
theorem block0160 : checkRange 160 32 = true := by decide +kernel
theorem block0192 : checkRange 192 32 = true := by decide +kernel
theorem block0224 : checkRange 224 32 = true := by decide +kernel

end NF192.Phase
