module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases29_00 : List Case := [
  ⟨2782, false, 2783, false, 30, 1, 37⟩,
  ⟨2782, true, 2790, false, 29, 2, 36⟩,
  ⟨2783, false, 2784, false, 32, 1, 39⟩,
  ⟨2784, false, 2785, false, 34, 1, 41⟩,
  ⟨2784, true, 2786, false, 33, 2, 40⟩,
  ⟨2786, false, 2787, false, 34, 1, 41⟩,
  ⟨2786, true, 2789, false, 31, 4, 38⟩,
  ⟨2787, false, 2788, false, 35, 1, 42⟩]
theorem carryCases29_00_verified : carryCases29_00.all verified = true := by decide

def carryCases29_01 : List Case := [
  ⟨2790, false, 2791, false, 30, 1, 37⟩,
  ⟨2790, true, 2793, false, 28, 3, 35⟩,
  ⟨2791, false, 2792, false, 31, 1, 38⟩,
  ⟨2793, false, 2794, false, 31, 1, 38⟩,
  ⟨2793, true, 2797, false, 30, 2, 37⟩,
  ⟨2794, false, 2795, false, 32, 1, 39⟩,
  ⟨2795, false, 2796, false, 33, 1, 40⟩,
  ⟨2797, false, 2798, false, 31, 1, 38⟩]
theorem carryCases29_01_verified : carryCases29_01.all verified = true := by decide

def carryCases29_02 : List Case := [
  ⟨2797, true, 2803, false, 29, 3, 36⟩,
  ⟨2798, false, 2799, false, 33, 1, 40⟩,
  ⟨2799, false, 2800, false, 34, 1, 41⟩,
  ⟨2799, true, 2802, false, 32, 3, 39⟩,
  ⟨2800, false, 2801, false, 35, 1, 42⟩,
  ⟨2803, false, 2804, false, 30, 1, 37⟩,
  ⟨2803, true, 2807, false, 27, 4, 34⟩,
  ⟨2804, false, 2805, false, 31, 1, 38⟩]
theorem carryCases29_02_verified : carryCases29_02.all verified = true := by decide

def carryCases29_03 : List Case := [
  ⟨2805, false, 2806, false, 32, 1, 39⟩,
  ⟨2807, false, 2808, false, 24, 4, 31⟩,
  ⟨2808, false, 2809, false, 25, 1, 32⟩,
  ⟨2809, false, 2810, false, 29, 1, 36⟩,
  ⟨2809, true, 2817, false, 28, 2, 35⟩,
  ⟨2810, false, 2811, false, 31, 1, 38⟩,
  ⟨2811, false, 2812, false, 33, 1, 40⟩,
  ⟨2811, true, 2813, false, 32, 2, 39⟩]
theorem carryCases29_03_verified : carryCases29_03.all verified = true := by decide

def carryCases29_04 : List Case := [
  ⟨2813, false, 2814, false, 33, 1, 40⟩,
  ⟨2813, true, 2816, false, 30, 4, 37⟩,
  ⟨2814, false, 2815, false, 34, 1, 41⟩,
  ⟨2817, false, 2818, false, 29, 1, 36⟩,
  ⟨2817, true, 2820, false, 27, 3, 34⟩,
  ⟨2818, false, 2819, false, 30, 1, 37⟩,
  ⟨2820, false, 2821, false, 30, 1, 37⟩,
  ⟨2820, true, 2824, false, 29, 2, 36⟩]
theorem carryCases29_04_verified : carryCases29_04.all verified = true := by decide

def carryCases29_05 : List Case := [
  ⟨2821, false, 2822, false, 31, 1, 38⟩,
  ⟨2822, false, 2823, false, 32, 1, 39⟩,
  ⟨2824, false, 2825, false, 30, 1, 37⟩,
  ⟨2824, true, 2830, false, 28, 3, 35⟩,
  ⟨2825, false, 2826, false, 32, 1, 39⟩,
  ⟨2826, false, 2827, false, 33, 1, 40⟩,
  ⟨2826, true, 2829, false, 31, 3, 38⟩,
  ⟨2827, false, 2828, false, 34, 1, 41⟩]
theorem carryCases29_05_verified : carryCases29_05.all verified = true := by decide

def carryCases29_06 : List Case := [
  ⟨2830, false, 2831, false, 29, 1, 36⟩,
  ⟨2830, true, 2834, false, 26, 4, 33⟩,
  ⟨2831, false, 2832, false, 30, 1, 37⟩,
  ⟨2832, false, 2833, false, 31, 1, 38⟩,
  ⟨2834, false, 2835, false, 22, 5, 29⟩,
  ⟨2835, false, 2836, false, 27, 1, 34⟩,
  ⟨2835, true, 2843, false, 26, 2, 33⟩,
  ⟨2836, false, 2837, false, 29, 1, 36⟩]
theorem carryCases29_06_verified : carryCases29_06.all verified = true := by decide

def carryCases29_07 : List Case := [
  ⟨2837, false, 2838, false, 31, 1, 38⟩,
  ⟨2837, true, 2839, false, 30, 2, 37⟩,
  ⟨2839, false, 2840, false, 31, 1, 38⟩,
  ⟨2839, true, 2842, false, 28, 4, 35⟩,
  ⟨2840, false, 2841, false, 32, 1, 39⟩,
  ⟨2843, false, 2844, false, 27, 1, 34⟩,
  ⟨2843, true, 2846, false, 25, 3, 32⟩,
  ⟨2844, false, 2845, false, 28, 1, 35⟩]
theorem carryCases29_07_verified : carryCases29_07.all verified = true := by decide

def carryCases29_08 : List Case := [
  ⟨2846, false, 2847, false, 28, 1, 35⟩,
  ⟨2846, true, 2850, false, 27, 2, 34⟩,
  ⟨2847, false, 2848, false, 29, 1, 36⟩,
  ⟨2848, false, 2849, false, 30, 1, 37⟩,
  ⟨2850, false, 2851, false, 28, 1, 35⟩,
  ⟨2850, true, 2856, false, 26, 3, 33⟩,
  ⟨2851, false, 2852, false, 30, 1, 37⟩,
  ⟨2852, false, 2853, false, 31, 1, 38⟩]
theorem carryCases29_08_verified : carryCases29_08.all verified = true := by decide

def carryCases29_09 : List Case := [
  ⟨2852, true, 2855, false, 29, 3, 36⟩,
  ⟨2853, false, 2854, false, 32, 1, 39⟩,
  ⟨2856, false, 2857, false, 27, 1, 34⟩,
  ⟨2856, true, 2860, false, 24, 4, 31⟩,
  ⟨2857, false, 2858, false, 28, 1, 35⟩,
  ⟨2858, false, 2859, false, 29, 1, 36⟩,
  ⟨2860, false, 2861, false, 23, 2, 30⟩,
  ⟨2861, false, 2862, false, 28, 1, 35⟩]
theorem carryCases29_09_verified : carryCases29_09.all verified = true := by decide

def carryCases29_10 : List Case := [
  ⟨2861, true, 2864, false, 27, 2, 34⟩,
  ⟨2862, false, 2863, false, 29, 1, 36⟩,
  ⟨2864, false, 2865, false, 29, 1, 36⟩,
  ⟨2864, true, 2867, false, 28, 2, 35⟩,
  ⟨2865, false, 2866, false, 30, 1, 37⟩,
  ⟨2867, false, 2868, false, 31, 1, 38⟩,
  ⟨2867, true, 2871, false, 30, 2, 37⟩,
  ⟨2868, false, 2869, false, 32, 1, 39⟩]
theorem carryCases29_10_verified : carryCases29_10.all verified = true := by decide

def carryCases29_11 : List Case := [
  ⟨2869, false, 2870, false, 33, 1, 40⟩,
  ⟨2871, false, 2872, false, 31, 1, 38⟩,
  ⟨2871, true, 2877, false, 29, 3, 36⟩,
  ⟨2872, false, 2873, false, 33, 1, 40⟩,
  ⟨2873, false, 2874, false, 34, 1, 41⟩,
  ⟨2873, true, 2876, false, 32, 3, 39⟩,
  ⟨2874, false, 2875, false, 35, 1, 42⟩,
  ⟨2877, false, 2878, false, 30, 1, 37⟩]
theorem carryCases29_11_verified : carryCases29_11.all verified = true := by decide

def carryCases29 : List Case := carryCases29_00 ++ carryCases29_01 ++ carryCases29_02 ++ carryCases29_03 ++ carryCases29_04 ++ carryCases29_05 ++ carryCases29_06 ++ carryCases29_07 ++ carryCases29_08 ++ carryCases29_09 ++ carryCases29_10 ++ carryCases29_11
theorem carryCases29_verified : carryCases29.all verified = true := by
  simp only [carryCases29, List.all_append, carryCases29_00_verified, carryCases29_01_verified, carryCases29_02_verified, carryCases29_03_verified, carryCases29_04_verified, carryCases29_05_verified, carryCases29_06_verified, carryCases29_07_verified, carryCases29_08_verified, carryCases29_09_verified, carryCases29_10_verified, carryCases29_11_verified, Bool.and_self]
theorem carryCases29_covered : carryCases29.map (fun c => key c.pc c.zero) = keysBetween 5564 191 := by decide
theorem carryCases29_count : carryCases29.length = 96 := by decide
end NF192.Carry
