module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases11_00 : List Case := [
  ⟨2276, false, 4219292416, 461196032, 62, 0, 0⟩,
  ⟨2280, false, 821906176, 16599808, 56, 0, 0⟩,
  ⟨2283, false, 1761430272, 150817536, 60, 0, 0⟩,
  ⟨2287, false, 15451638528, 419252992, 66, 0, 0⟩,
  ⟨2292, false, 63770020608, 12230413056, 70, 0, 0⟩,
  ⟨2293, false, 7935445760, 419252992, 62, 0, 0⟩,
  ⟨2296, false, 4177349376, 956123904, 64, 0, 0⟩,
  ⟨2300, false, 1023232768, 83708672, 56, 0, 0⟩
]

theorem cases11_00_verified : cases11_00.all verified = true := by decide

def cases11_01 : List Case := [
  ⟨2303, false, 251480832, 50154240, 52, 0, 0⟩,
  ⟨2307, true, 5670521600, 838683392, 31, 29, 36⟩,
  ⟨2310, false, 16407939840, 3523037952, 68, 0, 0⟩,
  ⟨2311, false, 838683392, 33377024, 60, 0, 0⟩,
  ⟨2314, false, 972901120, 167594752, 60, 0, 0⟩,
  ⟨2318, false, 3858582272, 100485888, 62, 0, 0⟩,
  ⟨2323, false, 15938177792, 3053275904, 66, 0, 0⟩,
  ⟨2324, false, 1979534080, 100485888, 58, 0, 0⟩
]

theorem cases11_01_verified : cases11_01.all verified = true := by decide

def cases11_02 : List Case := [
  ⟨2328, false, 2113751808, 234703616, 60, 0, 0⟩,
  ⟨2332, false, 12798720, 215808, 44, 0, 0⟩,
  ⟨2335, false, 27478784, 2312960, 48, 0, 0⟩,
  ⟨2339, false, 241388288, 6507264, 54, 0, 0⟩,
  ⟨2344, false, 996363008, 191056640, 58, 0, 0⟩,
  ⟨2345, false, 123947776, 6507264, 50, 0, 0⟩,
  ⟨2348, false, 65227520, 14895872, 52, 0, 0⟩,
  ⟨2355, true, 176900864, 25905920, 26, 24, 31⟩
]

theorem cases11_02_verified : cases11_02.all verified = true := by decide

def cases11_03 : List Case := [
  ⟨2358, false, 512445184, 109792000, 58, 0, 0⟩,
  ⟨2359, false, 25905920, 740096, 50, 0, 0⟩,
  ⟨2362, false, 30100224, 4934400, 50, 0, 0⟩,
  ⟨2366, false, 120277760, 2837248, 52, 0, 0⟩,
  ⟨2371, false, 497765120, 95111936, 56, 0, 0⟩,
  ⟨2372, false, 61557504, 2837248, 48, 0, 0⟩,
  ⟨2376, false, 65751808, 7031552, 50, 0, 0⟩,
  ⟨2379, false, 102451968, 1788672, 50, 0, 0⟩
]

theorem cases11_03_verified : cases11_03.all verified = true := by decide

def cases11_04 : List Case := [
  ⟨2382, false, 219892480, 18565888, 54, 0, 0⟩,
  ⟨2386, false, 1931168512, 52120320, 60, 0, 0⟩,
  ⟨2391, false, 7970966272, 1528515328, 64, 0, 0⟩,
  ⟨2392, false, 991644416, 52120320, 56, 0, 0⟩,
  ⟨2395, false, 521882368, 119229184, 58, 0, 0⟩,
  ⟨2401, false, 408636160, 5982976, 56, 0, 0⟩,
  ⟨2404, false, 878398208, 73091840, 60, 0, 0⟩,
  ⟨2408, false, 7723502336, 207309568, 66, 0, 0⟩
]

theorem cases11_04_verified : cases11_04.all verified = true := by decide

def cases11_05 : List Case := [
  ⟨2413, false, 31882693376, 6112889600, 70, 0, 0⟩,
  ⟨2414, false, 3965405952, 207309568, 62, 0, 0⟩,
  ⟨2417, false, 2086357760, 475745024, 64, 0, 0⟩,
  ⟨2420, false, 3260762880, 39537408, 64, 0, 0⟩,
  ⟨2423, false, 7018859264, 576408320, 68, 0, 0⟩,
  ⟨2427, false, 61779692288, 1650150144, 74, 0, 0⟩,
  ⟨2432, false, 255053220608, 48894790400, 78, 0, 0⟩,
  ⟨2433, false, 31714921216, 1650150144, 70, 0, 0⟩
]

theorem cases11_05_verified : cases11_05.all verified = true := by decide

def cases11_06 : List Case := [
  ⟨2436, false, 16682535680, 3797633792, 72, 0, 0⟩,
  ⟨2440, false, 7824165632, 307972864, 66, 0, 0⟩,
  ⟨2443, false, 4066069248, 844843776, 70, 0, 0⟩,
  ⟨2447, true, 45270911744, 6616206080, 36, 32, 39⟩,
  ⟨2450, false, 131170257664, 28091042560, 76, 0, 0⟩,
  ⟨2451, false, 6616206080, 173755136, 68, 0, 0⟩,
  ⟨2454, false, 7689947904, 1247496960, 68, 0, 0⟩,
  ⟨2458, false, 30775397120, 710626048, 70, 0, 0⟩
]

theorem cases11_06_verified : cases11_06.all verified = true := by decide

def cases11_07 : List Case := [
  ⟨2463, false, 127412161280, 24332946176, 74, 0, 0⟩,
  ⟨2464, false, 15743011584, 710626048, 66, 0, 0⟩,
  ⟨2468, false, 16816753408, 1784367872, 68, 0, 0⟩,
  ⟨2472, false, 6549097216, 106646272, 64, 0, 0⟩,
  ⟨2475, false, 14065289984, 1180388096, 68, 0, 0⟩,
  ⟨2479, false, 123586956032, 3327871744, 74, 0, 0⟩,
  ⟨2484, false, 510134012672, 97817152256, 78, 0, 0⟩,
  ⟨2485, false, 63457413888, 3327871744, 70, 0, 0⟩
]

theorem cases11_07_verified : cases11_07.all verified = true := by decide

def cases11 : List Case := cases11_00 ++ cases11_01 ++ cases11_02 ++ cases11_03 ++ cases11_04 ++ cases11_05 ++ cases11_06 ++ cases11_07

theorem cases11_verified : cases11.all verified = true := by
  simp only [cases11, List.all_append, cases11_00_verified, cases11_01_verified, cases11_02_verified, cases11_03_verified, cases11_04_verified, cases11_05_verified, cases11_06_verified, cases11_07_verified, Bool.and_self]

end NF192.Control
