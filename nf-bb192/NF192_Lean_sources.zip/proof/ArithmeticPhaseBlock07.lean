module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block1792 : checkRange 1792 32 = true := by decide +kernel
theorem block1824 : checkRange 1824 32 = true := by decide +kernel
theorem block1856 : checkRange 1856 32 = true := by decide +kernel
theorem block1888 : checkRange 1888 32 = true := by decide +kernel
theorem block1920 : checkRange 1920 32 = true := by decide +kernel
theorem block1952 : checkRange 1952 32 = true := by decide +kernel
theorem block1984 : checkRange 1984 32 = true := by decide +kernel
theorem block2016 : checkRange 2016 32 = true := by decide +kernel

end NF192.Phase
