module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases01_00 : List Case := [
  ⟨201, false, 219826944, 18500352, 54, 0, 0⟩,
  ⟨205, false, 1931102976, 52054784, 60, 0, 0⟩,
  ⟨210, false, 7970900736, 1528449792, 64, 0, 0⟩,
  ⟨211, false, 991578880, 52054784, 56, 0, 0⟩,
  ⟨214, false, 521816832, 119163648, 58, 0, 0⟩,
  ⟨218, false, 244992768, 10111744, 52, 0, 0⟩,
  ⟨221, false, 127552256, 26888960, 56, 0, 0⟩,
  ⟨224, false, 408570624, 5917440, 54, 0, 0⟩
]

theorem cases01_00_verified : cases01_00.all verified = true := by decide

def cases01_01 : List Case := [
  ⟨227, false, 878332672, 73026304, 58, 0, 0⟩,
  ⟨231, false, 7723436800, 207244032, 64, 0, 0⟩,
  ⟨236, false, 31882627840, 6112824064, 68, 0, 0⟩,
  ⟨237, false, 3965340416, 207244032, 60, 0, 0⟩,
  ⟨240, false, 2086292224, 475679488, 62, 0, 0⟩,
  ⟨244, false, 978995968, 39471872, 56, 0, 0⟩,
  ⟨247, false, 509233920, 106580736, 54, 0, 0⟩,
  ⟨251, true, 2841266944, 425347840, 30, 28, 35⟩
]

theorem cases01_01_verified : cases01_01.all verified = true := by decide

def cases01_02 : List Case := [
  ⟨254, false, 8209976064, 1767525120, 66, 0, 0⟩,
  ⟨255, false, 425347840, 22694656, 58, 0, 0⟩,
  ⟨258, false, 492456704, 89803520, 58, 0, 0⟩,
  ⟨262, false, 1935297280, 56249088, 60, 0, 0⟩,
  ⟨267, false, 7975095040, 1532644096, 64, 0, 0⟩,
  ⟨268, false, 995773184, 56249088, 56, 0, 0⟩,
  ⟨272, false, 1062882048, 123357952, 58, 0, 0⟩,
  ⟨275, false, 416959232, 14306048, 54, 0, 0⟩
]

theorem cases01_02_verified : cases01_02.all verified = true := by decide

def cases01_03 : List Case := [
  ⟨278, false, 886721280, 81414912, 58, 0, 0⟩,
  ⟨282, false, 7731825408, 215632640, 64, 0, 0⟩,
  ⟨287, false, 31891016448, 6121212672, 68, 0, 0⟩,
  ⟨288, false, 3973729024, 215632640, 60, 0, 0⟩,
  ⟨291, false, 2094680832, 484068096, 62, 0, 0⟩,
  ⟨295, false, 517622528, 47860480, 54, 0, 0⟩,
  ⟨298, false, 131746560, 31083264, 50, 0, 0⟩,
  ⟨301, false, 104483584, 3820288, 50, 0, 0⟩
]

theorem cases01_03_verified : cases01_03.all verified = true := by decide

def cases01_04 : List Case := [
  ⟨304, false, 221924096, 20597504, 54, 0, 0⟩,
  ⟨308, false, 1933200128, 54151936, 60, 0, 0⟩,
  ⟨313, false, 7972997888, 1530546944, 64, 0, 0⟩,
  ⟨314, false, 993676032, 54151936, 56, 0, 0⟩,
  ⟨317, false, 523913984, 121260800, 58, 0, 0⟩,
  ⟨321, false, 247089920, 12208896, 52, 0, 0⟩,
  ⟨324, false, 129649408, 28986112, 50, 0, 0⟩,
  ⟨328, true, 712657664, 108677888, 28, 26, 33⟩
]

theorem cases01_04_verified : cases01_04.all verified = true := by decide

def cases01_05 : List Case := [
  ⟨331, false, 2054834944, 444222208, 62, 0, 0⟩,
  ⟨332, false, 108677888, 8014592, 54, 0, 0⟩,
  ⟨335, false, 125455104, 24791808, 54, 0, 0⟩,
  ⟨339, false, 486165248, 16403200, 56, 0, 0⟩,
  ⟨344, false, 1996114688, 385501952, 60, 0, 0⟩,
  ⟨345, false, 251284224, 16403200, 52, 0, 0⟩,
  ⟨349, false, 268061440, 33180416, 54, 0, 0⟩,
  ⟨353, true, 176573184, 25578240, 28, 24, 31⟩
]

theorem cases01_05_verified : cases01_05.all verified = true := by decide

def cases01_06 : List Case := [
  ⟨356, false, 512117504, 109464320, 60, 0, 0⟩,
  ⟨357, false, 25578240, 412416, 52, 0, 0⟩,
  ⟨360, false, 29772544, 4606720, 52, 0, 0⟩,
  ⟨364, false, 119950080, 2509568, 54, 0, 0⟩,
  ⟨369, false, 497437440, 94784256, 58, 0, 0⟩,
  ⟨370, false, 61229824, 2509568, 50, 0, 0⟩,
  ⟨374, false, 65424128, 6703872, 52, 0, 0⟩,
  ⟨378, true, 177621760, 26626816, 28, 24, 31⟩
]

theorem cases01_06_verified : cases01_06.all verified = true := by decide

def cases01_07 : List Case := [
  ⟨381, false, 513166080, 110512896, 60, 0, 0⟩,
  ⟨382, false, 26626816, 1460992, 52, 0, 0⟩,
  ⟨385, false, 30821120, 5655296, 52, 0, 0⟩,
  ⟨389, false, 120998656, 3558144, 54, 0, 0⟩,
  ⟨394, false, 498486016, 95832832, 58, 0, 0⟩,
  ⟨395, false, 62278400, 3558144, 50, 0, 0⟩,
  ⟨399, false, 66472704, 7752448, 52, 0, 0⟩,
  ⟨402, false, 51268352, 936704, 50, 0, 0⟩
]

theorem cases01_07_verified : cases01_07.all verified = true := by decide

def cases01 : List Case := cases01_00 ++ cases01_01 ++ cases01_02 ++ cases01_03 ++ cases01_04 ++ cases01_05 ++ cases01_06 ++ cases01_07

theorem cases01_verified : cases01.all verified = true := by
  simp only [cases01, List.all_append, cases01_00_verified, cases01_01_verified, cases01_02_verified, cases01_03_verified, cases01_04_verified, cases01_05_verified, cases01_06_verified, cases01_07_verified, Bool.and_self]

end NF192.Control
