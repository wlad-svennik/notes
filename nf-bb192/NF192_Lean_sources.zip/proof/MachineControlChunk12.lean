module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases12_00 : List Case := [
  ⟨2488, false, 33392642816, 7622839040, 72, 0, 0⟩,
  ⟨2492, false, 8159709952, 643517184, 64, 0, 0⟩,
  ⟨2495, false, 1985694464, 375081728, 60, 0, 0⟩,
  ⟨2499, true, 45338020608, 6683314944, 36, 32, 39⟩,
  ⟨2502, false, 131237366528, 28158151424, 76, 0, 0⟩,
  ⟨2503, false, 6683314944, 240864000, 68, 0, 0⟩,
  ⟨2506, false, 7757056768, 1314605824, 68, 0, 0⟩,
  ⟨2510, false, 30842505984, 777734912, 70, 0, 0⟩
]

theorem cases12_00_verified : cases12_00.all verified = true := by decide

def cases12_01 : List Case := [
  ⟨2515, false, 127479270144, 24400055040, 74, 0, 0⟩,
  ⟨2516, false, 15810120448, 777734912, 66, 0, 0⟩,
  ⟨2520, false, 16883862272, 1851476736, 68, 0, 0⟩,
  ⟨2525, true, 11297049344, 1633372928, 32, 30, 37⟩,
  ⟨2528, false, 32771885824, 7002082048, 70, 0, 0⟩,
  ⟨2529, false, 1633372928, 22760192, 62, 0, 0⟩,
  ⟨2532, false, 1901808384, 291195648, 62, 0, 0⟩,
  ⟨2536, false, 7673170688, 156977920, 64, 0, 0⟩
]

theorem cases12_01_verified : cases12_01.all verified = true := by decide

def cases12_02 : List Case := [
  ⟨2541, false, 31832361728, 6062557952, 68, 0, 0⟩,
  ⟨2542, false, 3915074304, 156977920, 60, 0, 0⟩,
  ⟨2546, false, 4183509760, 425413376, 62, 0, 0⟩,
  ⟨2551, true, 5693459200, 861620992, 31, 29, 36⟩,
  ⟨2554, false, 16430877440, 3545975552, 68, 0, 0⟩,
  ⟨2555, false, 861620992, 56314624, 60, 0, 0⟩,
  ⟨2558, false, 995838720, 190532352, 60, 0, 0⟩,
  ⟨2562, false, 3881519872, 123423488, 62, 0, 0⟩
]

theorem cases12_02_verified : cases12_02.all verified = true := by decide

def cases12_03 : List Case := [
  ⟨2567, false, 15961115392, 3076213504, 66, 0, 0⟩,
  ⟨2568, false, 2002471680, 123423488, 58, 0, 0⟩,
  ⟨2572, false, 2136689408, 257641216, 60, 0, 0⟩,
  ⟨2575, false, 819677952, 14371584, 58, 0, 0⟩,
  ⟨2578, false, 1759202048, 148589312, 62, 0, 0⟩,
  ⟨2582, false, 15449410304, 417024768, 68, 0, 0⟩,
  ⟨2587, false, 63767792384, 12228184832, 72, 0, 0⟩,
  ⟨2588, false, 7933217536, 417024768, 64, 0, 0⟩
]

theorem cases12_03_verified : cases12_03.all verified = true := by decide

def cases12_04 : List Case := [
  ⟨2591, false, 4175121152, 953895680, 66, 0, 0⟩,
  ⟨2595, false, 1021004544, 81480448, 58, 0, 0⟩,
  ⟨2598, false, 249252608, 47926016, 54, 0, 0⟩,
  ⟨2601, false, 1641761536, 31148800, 60, 0, 0⟩,
  ⟨2604, false, 3520809728, 299584256, 64, 0, 0⟩,
  ⟨2608, false, 30901226240, 836455168, 70, 0, 0⟩,
  ⟨2613, false, 127537990400, 24458775296, 74, 0, 0⟩,
  ⟨2614, false, 15868840704, 836455168, 66, 0, 0⟩
]

theorem cases12_04_verified : cases12_04.all verified = true := by decide

def cases12_05 : List Case := [
  ⟨2617, false, 8352647936, 1910196992, 68, 0, 0⟩,
  ⟨2621, false, 3923462912, 165366528, 62, 0, 0⟩,
  ⟨2624, false, 2044414720, 433801984, 66, 0, 0⟩,
  ⟨2627, false, 6540708608, 98257664, 62, 0, 0⟩,
  ⟨2630, false, 14056901376, 1171999488, 66, 0, 0⟩,
  ⟨2634, false, 123578567424, 3319483136, 72, 0, 0⟩,
  ⟨2639, false, 510125624064, 97808763648, 76, 0, 0⟩,
  ⟨2640, false, 63449025280, 3319483136, 68, 0, 0⟩
]

theorem cases12_05_verified : cases12_05.all verified = true := by decide

def cases12_06 : List Case := [
  ⟨2643, false, 33384254208, 7614450432, 70, 0, 0⟩,
  ⟨2647, false, 8151321344, 635128576, 62, 0, 0⟩,
  ⟨2650, false, 1977305856, 366693120, 58, 0, 0⟩,
  ⟨2654, true, 45329632000, 6674926336, 34, 32, 39⟩,
  ⟨2657, false, 131228977920, 28149762816, 74, 0, 0⟩,
  ⟨2658, false, 6674926336, 232475392, 66, 0, 0⟩,
  ⟨2661, false, 7748668160, 1306217216, 66, 0, 0⟩,
  ⟨2665, false, 30834117376, 769346304, 68, 0, 0⟩
]

theorem cases12_06_verified : cases12_06.all verified = true := by decide

def cases12_07 : List Case := [
  ⟨2670, false, 127470881536, 24391666432, 72, 0, 0⟩,
  ⟨2671, false, 15801731840, 769346304, 64, 0, 0⟩,
  ⟨2675, false, 16875473664, 1843088128, 66, 0, 0⟩,
  ⟨2681, true, 22680390400, 3353037568, 33, 31, 38⟩,
  ⟨2684, false, 65630063360, 14090455808, 72, 0, 0⟩,
  ⟨2685, false, 3353037568, 131812096, 64, 0, 0⟩,
  ⟨2688, false, 3889908480, 668683008, 64, 0, 0⟩,
  ⟨2692, false, 15432633088, 400247552, 66, 0, 0⟩
]

theorem cases12_07_verified : cases12_07.all verified = true := by decide

def cases12 : List Case := cases12_00 ++ cases12_01 ++ cases12_02 ++ cases12_03 ++ cases12_04 ++ cases12_05 ++ cases12_06 ++ cases12_07

theorem cases12_verified : cases12.all verified = true := by
  simp only [cases12, List.all_append, cases12_00_verified, cases12_01_verified, cases12_02_verified, cases12_03_verified, cases12_04_verified, cases12_05_verified, cases12_06_verified, cases12_07_verified, Bool.and_self]

end NF192.Control
