module
public import CommandBlocks
public import SourceEnumeration

@[expose] public section

/-! A positive-time simulation at command boundaries reflects literal source
halting at *any* instruction time, including times between the boundaries.
The cofinal command enumeration starts at the next counter value. -/

namespace NF192.SourceSimulation

open CommandBlocks ProofSearch

/-- Physical counter R0 contains the candidate immediately before the next refill. -/
def boundary (s : StreamState) : Source.Config :=
  frame 0 (s.next-1) s.proof.top (pack s.proof.stack) 0 s.proof.param s.proof.cache 0 0 s.cursor

def embed : Option StreamState → Source.Config
  | none => Source.Config.halted
  | some s => boundary s

def Valid : Option StreamState → Prop
  | none => True
  | some s => 0 < s.next

theorem valid_step {s : StreamState} (hs : 0 < s.next) : Valid (streamStep s) := by
  simp only [streamStep]
  generalize one _ s.proof = out
  cases out with
  | none => trivial
  | some t =>
    change 0 < (if s.cursor = 0 then s.next + 1 else s.next)
    split <;> omega

theorem halted_absorbing (ticks : Nat) : Source.advance ticks Source.Config.halted = Source.Config.halted := by
  induction ticks with
  | zero => rfl
  | succ k ih => exact ih

/-- Every source command has positive duration on both checked outcomes. -/
def StepSimulation : Prop :=
  ∀ s : StreamState, 0 < s.next → Visits (boundary s) (embed (streamStep s))

theorem realize_run (oneCmd : StepSimulation) (k : Nat) (s : StreamState) (hs : 0 < s.next) :
    ∃ ticks, k ≤ ticks ∧ Source.advance ticks (boundary s) = embed (streamRun k s) := by
  induction k generalizing s with
  | zero => exact ⟨0,Nat.le_refl 0,rfl⟩
  | succ k ih =>
    obtain ⟨ticks,pos,hr⟩ := oneCmd s hs
    cases he : streamStep s with
    | none =>
      rw [he] at hr
      refine ⟨ticks+k, by omega, ?_⟩
      rw [Source.advance_add, hr]
      exact halted_absorbing k
        |>.trans (by simp only [streamRun, he, Option.bind_none]; rfl)
    | some t =>
      have ht : 0 < t.next := by
        have := valid_step hs
        simpa only [he, Valid] using this
      obtain ⟨tail, htail, hres⟩ := ih t ht
      refine ⟨ticks+tail, by omega, ?_⟩
      rw [Source.advance_add, hr, he]
      simpa only [streamRun, he, Option.bind_some, embed] using hres

/-- The converse covers a halt at an arbitrary instruction tick. Reaching at
least that many literal ticks forces the abstract command execution to have
observed the absorbing halt too. -/
theorem source_halts_iff_stream (oneCmd : StepSimulation) (s : StreamState) (hs : 0 < s.next) :
    (∃ ticks, Source.advance ticks (boundary s) = Source.Config.halted) ↔
    (∃ k, streamRun k s = none) := by
  constructor
  · rintro ⟨ticks,halt⟩
    obtain ⟨dt,hle,hr⟩ := realize_run oneCmd ticks s hs
    have large : Source.advance dt (boundary s) = Source.Config.halted := by
      rw [show dt = ticks+(dt-ticks) by omega, Source.advance_add, halt, halted_absorbing]
    rw [large] at hr
    refine ⟨ticks,?_⟩
    cases he : streamRun ticks s with
    | none => rfl
    | some out =>
      rw [he] at hr
      cases hr
  · rintro ⟨k,hk⟩
    obtain ⟨ticks,_,hr⟩ := realize_run oneCmd k s hs
    exact ⟨ticks,by simpa only [hk,embed] using hr⟩

theorem source_halts_iff_goal (oneCmd : StepSimulation) (n : Nat) (s : State) (hs : s.Sound) :
    (∃ ticks, Source.advance ticks (boundary ⟨n+1,0,s⟩) = Source.Config.halted) ↔
    Numerical.Deriv Numerical.goal :=
  (source_halts_iff_stream oneCmd ⟨n+1,0,s⟩ (Nat.zero_lt_succ n)).trans
    (stream_halting_iff_goal (n+1) s hs)

end NF192.SourceSimulation
