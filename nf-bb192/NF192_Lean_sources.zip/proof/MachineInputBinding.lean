module
public import MachineInputRows00
public import MachineInputRows01
public import MachineInputRows02
public import MachineInputRows03
public import MachineInputRows04
public import MachineInputRows05
public import MachineInputRows06
public import MachineInputRows07
public import MachineInputRows08
@[expose] public section
namespace NF192.Input
set_option maxHeartbeats 0
theorem all_blocks (i : Nat) (hi : i < 97) : computedBlock i = literalBlock i := by
  by_cases h48 : i < 48
  ·
    by_cases h24 : i < 24
    ·
      by_cases h12 : i < 12
      ·
        by_cases h6 : i < 6
        ·
          by_cases h3 : i < 3
          ·
            by_cases h1 : i < 1
            ·
              have eq : i = 0 := by omega
              exact eq ▸ rowBlock00
            ·
              by_cases h2 : i < 2
              ·
                have eq : i = 1 := by omega
                exact eq ▸ rowBlock01
              ·
                have eq : i = 2 := by omega
                exact eq ▸ rowBlock02
          ·
            by_cases h4 : i < 4
            ·
              have eq : i = 3 := by omega
              exact eq ▸ rowBlock03
            ·
              by_cases h5 : i < 5
              ·
                have eq : i = 4 := by omega
                exact eq ▸ rowBlock04
              ·
                have eq : i = 5 := by omega
                exact eq ▸ rowBlock05
        ·
          by_cases h9 : i < 9
          ·
            by_cases h7 : i < 7
            ·
              have eq : i = 6 := by omega
              exact eq ▸ rowBlock06
            ·
              by_cases h8 : i < 8
              ·
                have eq : i = 7 := by omega
                exact eq ▸ rowBlock07
              ·
                have eq : i = 8 := by omega
                exact eq ▸ rowBlock08
          ·
            by_cases h10 : i < 10
            ·
              have eq : i = 9 := by omega
              exact eq ▸ rowBlock09
            ·
              by_cases h11 : i < 11
              ·
                have eq : i = 10 := by omega
                exact eq ▸ rowBlock10
              ·
                have eq : i = 11 := by omega
                exact eq ▸ rowBlock11
      ·
        by_cases h18 : i < 18
        ·
          by_cases h15 : i < 15
          ·
            by_cases h13 : i < 13
            ·
              have eq : i = 12 := by omega
              exact eq ▸ rowBlock12
            ·
              by_cases h14 : i < 14
              ·
                have eq : i = 13 := by omega
                exact eq ▸ rowBlock13
              ·
                have eq : i = 14 := by omega
                exact eq ▸ rowBlock14
          ·
            by_cases h16 : i < 16
            ·
              have eq : i = 15 := by omega
              exact eq ▸ rowBlock15
            ·
              by_cases h17 : i < 17
              ·
                have eq : i = 16 := by omega
                exact eq ▸ rowBlock16
              ·
                have eq : i = 17 := by omega
                exact eq ▸ rowBlock17
        ·
          by_cases h21 : i < 21
          ·
            by_cases h19 : i < 19
            ·
              have eq : i = 18 := by omega
              exact eq ▸ rowBlock18
            ·
              by_cases h20 : i < 20
              ·
                have eq : i = 19 := by omega
                exact eq ▸ rowBlock19
              ·
                have eq : i = 20 := by omega
                exact eq ▸ rowBlock20
          ·
            by_cases h22 : i < 22
            ·
              have eq : i = 21 := by omega
              exact eq ▸ rowBlock21
            ·
              by_cases h23 : i < 23
              ·
                have eq : i = 22 := by omega
                exact eq ▸ rowBlock22
              ·
                have eq : i = 23 := by omega
                exact eq ▸ rowBlock23
    ·
      by_cases h36 : i < 36
      ·
        by_cases h30 : i < 30
        ·
          by_cases h27 : i < 27
          ·
            by_cases h25 : i < 25
            ·
              have eq : i = 24 := by omega
              exact eq ▸ rowBlock24
            ·
              by_cases h26 : i < 26
              ·
                have eq : i = 25 := by omega
                exact eq ▸ rowBlock25
              ·
                have eq : i = 26 := by omega
                exact eq ▸ rowBlock26
          ·
            by_cases h28 : i < 28
            ·
              have eq : i = 27 := by omega
              exact eq ▸ rowBlock27
            ·
              by_cases h29 : i < 29
              ·
                have eq : i = 28 := by omega
                exact eq ▸ rowBlock28
              ·
                have eq : i = 29 := by omega
                exact eq ▸ rowBlock29
        ·
          by_cases h33 : i < 33
          ·
            by_cases h31 : i < 31
            ·
              have eq : i = 30 := by omega
              exact eq ▸ rowBlock30
            ·
              by_cases h32 : i < 32
              ·
                have eq : i = 31 := by omega
                exact eq ▸ rowBlock31
              ·
                have eq : i = 32 := by omega
                exact eq ▸ rowBlock32
          ·
            by_cases h34 : i < 34
            ·
              have eq : i = 33 := by omega
              exact eq ▸ rowBlock33
            ·
              by_cases h35 : i < 35
              ·
                have eq : i = 34 := by omega
                exact eq ▸ rowBlock34
              ·
                have eq : i = 35 := by omega
                exact eq ▸ rowBlock35
      ·
        by_cases h42 : i < 42
        ·
          by_cases h39 : i < 39
          ·
            by_cases h37 : i < 37
            ·
              have eq : i = 36 := by omega
              exact eq ▸ rowBlock36
            ·
              by_cases h38 : i < 38
              ·
                have eq : i = 37 := by omega
                exact eq ▸ rowBlock37
              ·
                have eq : i = 38 := by omega
                exact eq ▸ rowBlock38
          ·
            by_cases h40 : i < 40
            ·
              have eq : i = 39 := by omega
              exact eq ▸ rowBlock39
            ·
              by_cases h41 : i < 41
              ·
                have eq : i = 40 := by omega
                exact eq ▸ rowBlock40
              ·
                have eq : i = 41 := by omega
                exact eq ▸ rowBlock41
        ·
          by_cases h45 : i < 45
          ·
            by_cases h43 : i < 43
            ·
              have eq : i = 42 := by omega
              exact eq ▸ rowBlock42
            ·
              by_cases h44 : i < 44
              ·
                have eq : i = 43 := by omega
                exact eq ▸ rowBlock43
              ·
                have eq : i = 44 := by omega
                exact eq ▸ rowBlock44
          ·
            by_cases h46 : i < 46
            ·
              have eq : i = 45 := by omega
              exact eq ▸ rowBlock45
            ·
              by_cases h47 : i < 47
              ·
                have eq : i = 46 := by omega
                exact eq ▸ rowBlock46
              ·
                have eq : i = 47 := by omega
                exact eq ▸ rowBlock47
  ·
    by_cases h72 : i < 72
    ·
      by_cases h60 : i < 60
      ·
        by_cases h54 : i < 54
        ·
          by_cases h51 : i < 51
          ·
            by_cases h49 : i < 49
            ·
              have eq : i = 48 := by omega
              exact eq ▸ rowBlock48
            ·
              by_cases h50 : i < 50
              ·
                have eq : i = 49 := by omega
                exact eq ▸ rowBlock49
              ·
                have eq : i = 50 := by omega
                exact eq ▸ rowBlock50
          ·
            by_cases h52 : i < 52
            ·
              have eq : i = 51 := by omega
              exact eq ▸ rowBlock51
            ·
              by_cases h53 : i < 53
              ·
                have eq : i = 52 := by omega
                exact eq ▸ rowBlock52
              ·
                have eq : i = 53 := by omega
                exact eq ▸ rowBlock53
        ·
          by_cases h57 : i < 57
          ·
            by_cases h55 : i < 55
            ·
              have eq : i = 54 := by omega
              exact eq ▸ rowBlock54
            ·
              by_cases h56 : i < 56
              ·
                have eq : i = 55 := by omega
                exact eq ▸ rowBlock55
              ·
                have eq : i = 56 := by omega
                exact eq ▸ rowBlock56
          ·
            by_cases h58 : i < 58
            ·
              have eq : i = 57 := by omega
              exact eq ▸ rowBlock57
            ·
              by_cases h59 : i < 59
              ·
                have eq : i = 58 := by omega
                exact eq ▸ rowBlock58
              ·
                have eq : i = 59 := by omega
                exact eq ▸ rowBlock59
      ·
        by_cases h66 : i < 66
        ·
          by_cases h63 : i < 63
          ·
            by_cases h61 : i < 61
            ·
              have eq : i = 60 := by omega
              exact eq ▸ rowBlock60
            ·
              by_cases h62 : i < 62
              ·
                have eq : i = 61 := by omega
                exact eq ▸ rowBlock61
              ·
                have eq : i = 62 := by omega
                exact eq ▸ rowBlock62
          ·
            by_cases h64 : i < 64
            ·
              have eq : i = 63 := by omega
              exact eq ▸ rowBlock63
            ·
              by_cases h65 : i < 65
              ·
                have eq : i = 64 := by omega
                exact eq ▸ rowBlock64
              ·
                have eq : i = 65 := by omega
                exact eq ▸ rowBlock65
        ·
          by_cases h69 : i < 69
          ·
            by_cases h67 : i < 67
            ·
              have eq : i = 66 := by omega
              exact eq ▸ rowBlock66
            ·
              by_cases h68 : i < 68
              ·
                have eq : i = 67 := by omega
                exact eq ▸ rowBlock67
              ·
                have eq : i = 68 := by omega
                exact eq ▸ rowBlock68
          ·
            by_cases h70 : i < 70
            ·
              have eq : i = 69 := by omega
              exact eq ▸ rowBlock69
            ·
              by_cases h71 : i < 71
              ·
                have eq : i = 70 := by omega
                exact eq ▸ rowBlock70
              ·
                have eq : i = 71 := by omega
                exact eq ▸ rowBlock71
    ·
      by_cases h84 : i < 84
      ·
        by_cases h78 : i < 78
        ·
          by_cases h75 : i < 75
          ·
            by_cases h73 : i < 73
            ·
              have eq : i = 72 := by omega
              exact eq ▸ rowBlock72
            ·
              by_cases h74 : i < 74
              ·
                have eq : i = 73 := by omega
                exact eq ▸ rowBlock73
              ·
                have eq : i = 74 := by omega
                exact eq ▸ rowBlock74
          ·
            by_cases h76 : i < 76
            ·
              have eq : i = 75 := by omega
              exact eq ▸ rowBlock75
            ·
              by_cases h77 : i < 77
              ·
                have eq : i = 76 := by omega
                exact eq ▸ rowBlock76
              ·
                have eq : i = 77 := by omega
                exact eq ▸ rowBlock77
        ·
          by_cases h81 : i < 81
          ·
            by_cases h79 : i < 79
            ·
              have eq : i = 78 := by omega
              exact eq ▸ rowBlock78
            ·
              by_cases h80 : i < 80
              ·
                have eq : i = 79 := by omega
                exact eq ▸ rowBlock79
              ·
                have eq : i = 80 := by omega
                exact eq ▸ rowBlock80
          ·
            by_cases h82 : i < 82
            ·
              have eq : i = 81 := by omega
              exact eq ▸ rowBlock81
            ·
              by_cases h83 : i < 83
              ·
                have eq : i = 82 := by omega
                exact eq ▸ rowBlock82
              ·
                have eq : i = 83 := by omega
                exact eq ▸ rowBlock83
      ·
        by_cases h90 : i < 90
        ·
          by_cases h87 : i < 87
          ·
            by_cases h85 : i < 85
            ·
              have eq : i = 84 := by omega
              exact eq ▸ rowBlock84
            ·
              by_cases h86 : i < 86
              ·
                have eq : i = 85 := by omega
                exact eq ▸ rowBlock85
              ·
                have eq : i = 86 := by omega
                exact eq ▸ rowBlock86
          ·
            by_cases h88 : i < 88
            ·
              have eq : i = 87 := by omega
              exact eq ▸ rowBlock87
            ·
              by_cases h89 : i < 89
              ·
                have eq : i = 88 := by omega
                exact eq ▸ rowBlock88
              ·
                have eq : i = 89 := by omega
                exact eq ▸ rowBlock89
        ·
          by_cases h93 : i < 93
          ·
            by_cases h91 : i < 91
            ·
              have eq : i = 90 := by omega
              exact eq ▸ rowBlock90
            ·
              by_cases h92 : i < 92
              ·
                have eq : i = 91 := by omega
                exact eq ▸ rowBlock91
              ·
                have eq : i = 92 := by omega
                exact eq ▸ rowBlock92
          ·
            by_cases h95 : i < 95
            ·
              by_cases h94 : i < 94
              ·
                have eq : i = 93 := by omega
                exact eq ▸ rowBlock93
              ·
                have eq : i = 94 := by omega
                exact eq ▸ rowBlock94
            ·
              by_cases h96 : i < 96
              ·
                have eq : i = 95 := by omega
                exact eq ▸ rowBlock95
              ·
                have eq : i = 96 := by omega
                exact eq ▸ rowBlock96

def serializedSourceBlocks : List (List String) := (List.range 97).map computedBlock

theorem source_fragments : serializedSourceBlocks = sourceFragments := by
  apply List.ext_getElem
  · simp [serializedSourceBlocks,original_block_count]
  · intro i left right
    have bound : i < 97 := by simpa [original_block_count] using right
    simpa [serializedSourceBlocks,literalBlock,List.getElem?_eq_getElem right] using all_blocks i bound

/-- Reconstruct every source byte from the 3,089 packed semantic entries,
including the original punctuation and final line feed. -/
theorem exact_countdown_source :
    String.join serializedSourceBlocks.flatten = String.join sourceFragments.flatten := by
  rw [source_fragments]

#print axioms exact_transition_table
#print axioms exact_countdown_source
end NF192.Input
