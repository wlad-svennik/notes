module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases21_00 : List Case := [
  ⟨2013, true, 2017, false, 27, 2, 34⟩,
  ⟨2014, false, 2015, false, 29, 1, 36⟩,
  ⟨2015, false, 2016, false, 30, 1, 37⟩,
  ⟨2017, false, 2018, false, 28, 1, 35⟩,
  ⟨2017, true, 2020, false, 25, 4, 32⟩,
  ⟨2018, false, 2019, false, 29, 1, 36⟩,
  ⟨2020, false, 2021, false, 29, 1, 36⟩,
  ⟨2020, true, 2023, false, 28, 2, 35⟩]
theorem carryCases21_00_verified : carryCases21_00.all verified = true := by decide

def carryCases21_01 : List Case := [
  ⟨2021, false, 2022, false, 30, 1, 37⟩,
  ⟨2023, false, 2024, false, 30, 1, 37⟩,
  ⟨2023, true, 2026, false, 29, 2, 36⟩,
  ⟨2024, false, 2025, false, 31, 1, 38⟩,
  ⟨2026, false, 2027, false, 32, 1, 39⟩,
  ⟨2026, true, 2030, false, 31, 2, 38⟩,
  ⟨2027, false, 2028, false, 33, 1, 40⟩,
  ⟨2028, false, 2029, false, 34, 1, 41⟩]
theorem carryCases21_01_verified : carryCases21_01.all verified = true := by decide

def carryCases21_02 : List Case := [
  ⟨2030, false, 2031, false, 32, 1, 39⟩,
  ⟨2030, true, 2036, false, 30, 3, 37⟩,
  ⟨2031, false, 2032, false, 34, 1, 41⟩,
  ⟨2032, false, 2033, false, 35, 1, 42⟩,
  ⟨2032, true, 2035, false, 33, 3, 40⟩,
  ⟨2033, false, 2034, false, 36, 1, 43⟩,
  ⟨2036, false, 2037, false, 31, 1, 38⟩,
  ⟨2036, true, 2039, false, 27, 5, 34⟩]
theorem carryCases21_02_verified : carryCases21_02.all verified = true := by decide

def carryCases21_03 : List Case := [
  ⟨2037, false, 2038, false, 32, 1, 39⟩,
  ⟨2039, false, 2040, false, 29, 1, 36⟩,
  ⟨2039, true, 2043, false, 28, 2, 35⟩,
  ⟨2040, false, 2041, false, 30, 1, 37⟩,
  ⟨2041, false, 2042, false, 31, 1, 38⟩,
  ⟨2043, false, 2044, false, 29, 1, 36⟩,
  ⟨2043, true, 2046, false, 26, 4, 33⟩,
  ⟨2044, false, 2045, false, 30, 1, 37⟩]
theorem carryCases21_03_verified : carryCases21_03.all verified = true := by decide

def carryCases21_04 : List Case := [
  ⟨2046, false, 2047, false, 30, 1, 37⟩,
  ⟨2046, true, 2054, false, 29, 2, 36⟩,
  ⟨2047, false, 2048, false, 32, 1, 39⟩,
  ⟨2048, false, 2049, false, 34, 1, 41⟩,
  ⟨2048, true, 2050, false, 33, 2, 40⟩,
  ⟨2050, false, 2051, false, 34, 1, 41⟩,
  ⟨2050, true, 2053, false, 31, 4, 38⟩,
  ⟨2051, false, 2052, false, 35, 1, 42⟩]
theorem carryCases21_04_verified : carryCases21_04.all verified = true := by decide

def carryCases21_05 : List Case := [
  ⟨2054, false, 2055, false, 30, 1, 37⟩,
  ⟨2054, true, 2057, false, 28, 3, 35⟩,
  ⟨2055, false, 2056, false, 31, 1, 38⟩,
  ⟨2057, false, 2058, false, 31, 1, 38⟩,
  ⟨2057, true, 2061, false, 30, 2, 37⟩,
  ⟨2058, false, 2059, false, 32, 1, 39⟩,
  ⟨2059, false, 2060, false, 33, 1, 40⟩,
  ⟨2061, false, 2062, false, 31, 1, 38⟩]
theorem carryCases21_05_verified : carryCases21_05.all verified = true := by decide

def carryCases21_06 : List Case := [
  ⟨2061, true, 2067, false, 29, 3, 36⟩,
  ⟨2062, false, 2063, false, 33, 1, 40⟩,
  ⟨2063, false, 2064, false, 34, 1, 41⟩,
  ⟨2063, true, 2066, false, 32, 3, 39⟩,
  ⟨2064, false, 2065, false, 35, 1, 42⟩,
  ⟨2067, false, 2068, false, 30, 1, 37⟩,
  ⟨2067, true, 2071, false, 27, 4, 34⟩,
  ⟨2068, false, 2069, false, 31, 1, 38⟩]
theorem carryCases21_06_verified : carryCases21_06.all verified = true := by decide

def carryCases21_07 : List Case := [
  ⟨2069, false, 2070, false, 32, 1, 39⟩,
  ⟨2071, false, 2072, false, 24, 4, 31⟩,
  ⟨2072, false, 2073, false, 28, 1, 35⟩,
  ⟨2072, true, 2075, false, 27, 2, 34⟩,
  ⟨2073, false, 2074, false, 29, 1, 36⟩,
  ⟨2075, false, 2076, false, 29, 1, 36⟩,
  ⟨2075, true, 2078, false, 28, 2, 35⟩,
  ⟨2076, false, 2077, false, 30, 1, 37⟩]
theorem carryCases21_07_verified : carryCases21_07.all verified = true := by decide

def carryCases21_08 : List Case := [
  ⟨2078, false, 2079, false, 31, 1, 38⟩,
  ⟨2078, true, 2082, false, 30, 2, 37⟩,
  ⟨2079, false, 2080, false, 32, 1, 39⟩,
  ⟨2080, false, 2081, false, 33, 1, 40⟩,
  ⟨2082, false, 2083, false, 31, 1, 38⟩,
  ⟨2082, true, 2088, false, 29, 3, 36⟩,
  ⟨2083, false, 2084, false, 33, 1, 40⟩,
  ⟨2084, false, 2085, false, 34, 1, 41⟩]
theorem carryCases21_08_verified : carryCases21_08.all verified = true := by decide

def carryCases21_09 : List Case := [
  ⟨2084, true, 2087, false, 32, 3, 39⟩,
  ⟨2085, false, 2086, false, 35, 1, 42⟩,
  ⟨2088, false, 2089, false, 30, 1, 37⟩,
  ⟨2088, true, 2091, false, 26, 5, 33⟩,
  ⟨2089, false, 2090, false, 31, 1, 38⟩,
  ⟨2091, false, 2092, false, 28, 1, 35⟩,
  ⟨2091, true, 2095, false, 27, 2, 34⟩,
  ⟨2092, false, 2093, false, 29, 1, 36⟩]
theorem carryCases21_09_verified : carryCases21_09.all verified = true := by decide

def carryCases21_10 : List Case := [
  ⟨2093, false, 2094, false, 30, 1, 37⟩,
  ⟨2095, false, 2096, false, 28, 1, 35⟩,
  ⟨2095, true, 2098, false, 25, 4, 32⟩,
  ⟨2096, false, 2097, false, 29, 1, 36⟩,
  ⟨2098, false, 2099, false, 30, 1, 37⟩,
  ⟨2098, true, 2101, false, 29, 2, 36⟩,
  ⟨2099, false, 2100, false, 31, 1, 38⟩,
  ⟨2101, false, 2102, false, 31, 1, 38⟩]
theorem carryCases21_10_verified : carryCases21_10.all verified = true := by decide

def carryCases21_11 : List Case := [
  ⟨2101, true, 2104, false, 30, 2, 37⟩,
  ⟨2102, false, 2103, false, 32, 1, 39⟩,
  ⟨2104, false, 2105, false, 33, 1, 40⟩,
  ⟨2104, true, 2108, false, 32, 2, 39⟩,
  ⟨2105, false, 2106, false, 34, 1, 41⟩,
  ⟨2106, false, 2107, false, 35, 1, 42⟩,
  ⟨2108, false, 2109, false, 33, 1, 40⟩,
  ⟨2108, true, 2114, false, 31, 3, 38⟩]
theorem carryCases21_11_verified : carryCases21_11.all verified = true := by decide

def carryCases21 : List Case := carryCases21_00 ++ carryCases21_01 ++ carryCases21_02 ++ carryCases21_03 ++ carryCases21_04 ++ carryCases21_05 ++ carryCases21_06 ++ carryCases21_07 ++ carryCases21_08 ++ carryCases21_09 ++ carryCases21_10 ++ carryCases21_11
theorem carryCases21_verified : carryCases21.all verified = true := by
  simp only [carryCases21, List.all_append, carryCases21_00_verified, carryCases21_01_verified, carryCases21_02_verified, carryCases21_03_verified, carryCases21_04_verified, carryCases21_05_verified, carryCases21_06_verified, carryCases21_07_verified, carryCases21_08_verified, carryCases21_09_verified, carryCases21_10_verified, carryCases21_11_verified, Bool.and_self]
theorem carryCases21_covered : carryCases21.map (fun c => key c.pc c.zero) = keysBetween 4027 191 := by decide
theorem carryCases21_count : carryCases21.length = 96 := by decide
end NF192.Carry
