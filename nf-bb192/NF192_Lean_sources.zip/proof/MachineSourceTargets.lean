module
public import MachineSource

@[expose] public section

/-! Bounds for the register and every outgoing edge of the literal source program. -/
namespace NF192.Frame
open Source
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def validTargets : Source.Command → Prop
  | .inl (r, d) => r < 9 ∧ d < siteCount
  | .inr (.inl (r, z, p, _)) => r < 9 ∧ z < siteCount ∧ p < siteCount
  | .inr (.inr d) => d < siteCount

instance (c : Source.Command) : Decidable (validTargets c) := by
  rcases c with ⟨r,d⟩ | ⟨r,z,p,b⟩ | d <;> unfold validTargets <;> infer_instance

private def checkTargets (pc : Nat) : Bool := decide (validTargets (program pc))

private def checkRange (lo size : Nat) : Bool :=
  (List.range size).all (fun j => checkTargets (lo + j))

private theorem point {lo count pc : Nat} (ok : checkRange lo count = true)
    (lower : lo ≤ pc) (upper : pc < lo + count) : validTargets (program pc) := by
  have atOffset := List.all_eq_true.mp ok (pc - lo) (List.mem_range.mpr (by omega))
  have equal : lo + (pc - lo) = pc := by omega
  have checked : checkTargets pc = true := by simpa only [equal] using atOffset
  exact of_decide_eq_true (by simpa only [checkTargets] using checked)

private theorem block0000 : checkRange 0 32 = true := by decide +kernel
private theorem block0032 : checkRange 32 32 = true := by decide +kernel
private theorem block0064 : checkRange 64 32 = true := by decide +kernel
private theorem block0096 : checkRange 96 32 = true := by decide +kernel
private theorem block0128 : checkRange 128 32 = true := by decide +kernel
private theorem block0160 : checkRange 160 32 = true := by decide +kernel
private theorem block0192 : checkRange 192 32 = true := by decide +kernel
private theorem block0224 : checkRange 224 32 = true := by decide +kernel
private theorem block0256 : checkRange 256 32 = true := by decide +kernel
private theorem block0288 : checkRange 288 32 = true := by decide +kernel
private theorem block0320 : checkRange 320 32 = true := by decide +kernel
private theorem block0352 : checkRange 352 32 = true := by decide +kernel
private theorem block0384 : checkRange 384 32 = true := by decide +kernel
private theorem block0416 : checkRange 416 32 = true := by decide +kernel
private theorem block0448 : checkRange 448 32 = true := by decide +kernel
private theorem block0480 : checkRange 480 32 = true := by decide +kernel
private theorem block0512 : checkRange 512 32 = true := by decide +kernel
private theorem block0544 : checkRange 544 32 = true := by decide +kernel
private theorem block0576 : checkRange 576 32 = true := by decide +kernel
private theorem block0608 : checkRange 608 32 = true := by decide +kernel
private theorem block0640 : checkRange 640 32 = true := by decide +kernel
private theorem block0672 : checkRange 672 32 = true := by decide +kernel
private theorem block0704 : checkRange 704 32 = true := by decide +kernel
private theorem block0736 : checkRange 736 32 = true := by decide +kernel
private theorem block0768 : checkRange 768 32 = true := by decide +kernel
private theorem block0800 : checkRange 800 32 = true := by decide +kernel
private theorem block0832 : checkRange 832 32 = true := by decide +kernel
private theorem block0864 : checkRange 864 32 = true := by decide +kernel
private theorem block0896 : checkRange 896 32 = true := by decide +kernel
private theorem block0928 : checkRange 928 32 = true := by decide +kernel
private theorem block0960 : checkRange 960 32 = true := by decide +kernel
private theorem block0992 : checkRange 992 32 = true := by decide +kernel
private theorem block1024 : checkRange 1024 32 = true := by decide +kernel
private theorem block1056 : checkRange 1056 32 = true := by decide +kernel
private theorem block1088 : checkRange 1088 32 = true := by decide +kernel
private theorem block1120 : checkRange 1120 32 = true := by decide +kernel
private theorem block1152 : checkRange 1152 32 = true := by decide +kernel
private theorem block1184 : checkRange 1184 32 = true := by decide +kernel
private theorem block1216 : checkRange 1216 32 = true := by decide +kernel
private theorem block1248 : checkRange 1248 32 = true := by decide +kernel
private theorem block1280 : checkRange 1280 32 = true := by decide +kernel
private theorem block1312 : checkRange 1312 32 = true := by decide +kernel
private theorem block1344 : checkRange 1344 32 = true := by decide +kernel
private theorem block1376 : checkRange 1376 32 = true := by decide +kernel
private theorem block1408 : checkRange 1408 32 = true := by decide +kernel
private theorem block1440 : checkRange 1440 32 = true := by decide +kernel
private theorem block1472 : checkRange 1472 32 = true := by decide +kernel
private theorem block1504 : checkRange 1504 32 = true := by decide +kernel
private theorem block1536 : checkRange 1536 32 = true := by decide +kernel
private theorem block1568 : checkRange 1568 32 = true := by decide +kernel
private theorem block1600 : checkRange 1600 32 = true := by decide +kernel
private theorem block1632 : checkRange 1632 32 = true := by decide +kernel
private theorem block1664 : checkRange 1664 32 = true := by decide +kernel
private theorem block1696 : checkRange 1696 32 = true := by decide +kernel
private theorem block1728 : checkRange 1728 32 = true := by decide +kernel
private theorem block1760 : checkRange 1760 32 = true := by decide +kernel
private theorem block1792 : checkRange 1792 32 = true := by decide +kernel
private theorem block1824 : checkRange 1824 32 = true := by decide +kernel
private theorem block1856 : checkRange 1856 32 = true := by decide +kernel
private theorem block1888 : checkRange 1888 32 = true := by decide +kernel
private theorem block1920 : checkRange 1920 32 = true := by decide +kernel
private theorem block1952 : checkRange 1952 32 = true := by decide +kernel
private theorem block1984 : checkRange 1984 32 = true := by decide +kernel
private theorem block2016 : checkRange 2016 32 = true := by decide +kernel
private theorem block2048 : checkRange 2048 32 = true := by decide +kernel
private theorem block2080 : checkRange 2080 32 = true := by decide +kernel
private theorem block2112 : checkRange 2112 32 = true := by decide +kernel
private theorem block2144 : checkRange 2144 32 = true := by decide +kernel
private theorem block2176 : checkRange 2176 32 = true := by decide +kernel
private theorem block2208 : checkRange 2208 32 = true := by decide +kernel
private theorem block2240 : checkRange 2240 32 = true := by decide +kernel
private theorem block2272 : checkRange 2272 32 = true := by decide +kernel
private theorem block2304 : checkRange 2304 32 = true := by decide +kernel
private theorem block2336 : checkRange 2336 32 = true := by decide +kernel
private theorem block2368 : checkRange 2368 32 = true := by decide +kernel
private theorem block2400 : checkRange 2400 32 = true := by decide +kernel
private theorem block2432 : checkRange 2432 32 = true := by decide +kernel
private theorem block2464 : checkRange 2464 32 = true := by decide +kernel
private theorem block2496 : checkRange 2496 32 = true := by decide +kernel
private theorem block2528 : checkRange 2528 32 = true := by decide +kernel
private theorem block2560 : checkRange 2560 32 = true := by decide +kernel
private theorem block2592 : checkRange 2592 32 = true := by decide +kernel
private theorem block2624 : checkRange 2624 32 = true := by decide +kernel
private theorem block2656 : checkRange 2656 32 = true := by decide +kernel
private theorem block2688 : checkRange 2688 32 = true := by decide +kernel
private theorem block2720 : checkRange 2720 32 = true := by decide +kernel
private theorem block2752 : checkRange 2752 32 = true := by decide +kernel
private theorem block2784 : checkRange 2784 32 = true := by decide +kernel
private theorem block2816 : checkRange 2816 32 = true := by decide +kernel
private theorem block2848 : checkRange 2848 32 = true := by decide +kernel
private theorem block2880 : checkRange 2880 32 = true := by decide +kernel
private theorem block2912 : checkRange 2912 32 = true := by decide +kernel
private theorem block2944 : checkRange 2944 32 = true := by decide +kernel
private theorem block2976 : checkRange 2976 32 = true := by decide +kernel
private theorem block3008 : checkRange 3008 32 = true := by decide +kernel
private theorem block3040 : checkRange 3040 32 = true := by decide +kernel
private theorem block3072 : checkRange 3072 17 = true := by decide +kernel

theorem targets_valid (pc : Nat) (h : pc < siteCount) : validTargets (program pc) := by
  change pc < 3089 at h
  by_cases h1536 : pc < 1536
  ·
    by_cases h768 : pc < 768
    ·
      by_cases h384 : pc < 384
      ·
        by_cases h192 : pc < 192
        ·
          by_cases h96 : pc < 96
          ·
            by_cases h32 : pc < 32
            ·
              exact point block0000 (by omega) (by omega)
            ·
              by_cases h64 : pc < 64
              ·
                exact point block0032 (by omega) (by omega)
              ·
                exact point block0064 (by omega) (by omega)
          ·
            by_cases h128 : pc < 128
            ·
              exact point block0096 (by omega) (by omega)
            ·
              by_cases h160 : pc < 160
              ·
                exact point block0128 (by omega) (by omega)
              ·
                exact point block0160 (by omega) (by omega)
        ·
          by_cases h288 : pc < 288
          ·
            by_cases h224 : pc < 224
            ·
              exact point block0192 (by omega) (by omega)
            ·
              by_cases h256 : pc < 256
              ·
                exact point block0224 (by omega) (by omega)
              ·
                exact point block0256 (by omega) (by omega)
          ·
            by_cases h320 : pc < 320
            ·
              exact point block0288 (by omega) (by omega)
            ·
              by_cases h352 : pc < 352
              ·
                exact point block0320 (by omega) (by omega)
              ·
                exact point block0352 (by omega) (by omega)
      ·
        by_cases h576 : pc < 576
        ·
          by_cases h480 : pc < 480
          ·
            by_cases h416 : pc < 416
            ·
              exact point block0384 (by omega) (by omega)
            ·
              by_cases h448 : pc < 448
              ·
                exact point block0416 (by omega) (by omega)
              ·
                exact point block0448 (by omega) (by omega)
          ·
            by_cases h512 : pc < 512
            ·
              exact point block0480 (by omega) (by omega)
            ·
              by_cases h544 : pc < 544
              ·
                exact point block0512 (by omega) (by omega)
              ·
                exact point block0544 (by omega) (by omega)
        ·
          by_cases h672 : pc < 672
          ·
            by_cases h608 : pc < 608
            ·
              exact point block0576 (by omega) (by omega)
            ·
              by_cases h640 : pc < 640
              ·
                exact point block0608 (by omega) (by omega)
              ·
                exact point block0640 (by omega) (by omega)
          ·
            by_cases h704 : pc < 704
            ·
              exact point block0672 (by omega) (by omega)
            ·
              by_cases h736 : pc < 736
              ·
                exact point block0704 (by omega) (by omega)
              ·
                exact point block0736 (by omega) (by omega)
    ·
      by_cases h1152 : pc < 1152
      ·
        by_cases h960 : pc < 960
        ·
          by_cases h864 : pc < 864
          ·
            by_cases h800 : pc < 800
            ·
              exact point block0768 (by omega) (by omega)
            ·
              by_cases h832 : pc < 832
              ·
                exact point block0800 (by omega) (by omega)
              ·
                exact point block0832 (by omega) (by omega)
          ·
            by_cases h896 : pc < 896
            ·
              exact point block0864 (by omega) (by omega)
            ·
              by_cases h928 : pc < 928
              ·
                exact point block0896 (by omega) (by omega)
              ·
                exact point block0928 (by omega) (by omega)
        ·
          by_cases h1056 : pc < 1056
          ·
            by_cases h992 : pc < 992
            ·
              exact point block0960 (by omega) (by omega)
            ·
              by_cases h1024 : pc < 1024
              ·
                exact point block0992 (by omega) (by omega)
              ·
                exact point block1024 (by omega) (by omega)
          ·
            by_cases h1088 : pc < 1088
            ·
              exact point block1056 (by omega) (by omega)
            ·
              by_cases h1120 : pc < 1120
              ·
                exact point block1088 (by omega) (by omega)
              ·
                exact point block1120 (by omega) (by omega)
      ·
        by_cases h1344 : pc < 1344
        ·
          by_cases h1248 : pc < 1248
          ·
            by_cases h1184 : pc < 1184
            ·
              exact point block1152 (by omega) (by omega)
            ·
              by_cases h1216 : pc < 1216
              ·
                exact point block1184 (by omega) (by omega)
              ·
                exact point block1216 (by omega) (by omega)
          ·
            by_cases h1280 : pc < 1280
            ·
              exact point block1248 (by omega) (by omega)
            ·
              by_cases h1312 : pc < 1312
              ·
                exact point block1280 (by omega) (by omega)
              ·
                exact point block1312 (by omega) (by omega)
        ·
          by_cases h1440 : pc < 1440
          ·
            by_cases h1376 : pc < 1376
            ·
              exact point block1344 (by omega) (by omega)
            ·
              by_cases h1408 : pc < 1408
              ·
                exact point block1376 (by omega) (by omega)
              ·
                exact point block1408 (by omega) (by omega)
          ·
            by_cases h1472 : pc < 1472
            ·
              exact point block1440 (by omega) (by omega)
            ·
              by_cases h1504 : pc < 1504
              ·
                exact point block1472 (by omega) (by omega)
              ·
                exact point block1504 (by omega) (by omega)
  ·
    by_cases h2304 : pc < 2304
    ·
      by_cases h1920 : pc < 1920
      ·
        by_cases h1728 : pc < 1728
        ·
          by_cases h1632 : pc < 1632
          ·
            by_cases h1568 : pc < 1568
            ·
              exact point block1536 (by omega) (by omega)
            ·
              by_cases h1600 : pc < 1600
              ·
                exact point block1568 (by omega) (by omega)
              ·
                exact point block1600 (by omega) (by omega)
          ·
            by_cases h1664 : pc < 1664
            ·
              exact point block1632 (by omega) (by omega)
            ·
              by_cases h1696 : pc < 1696
              ·
                exact point block1664 (by omega) (by omega)
              ·
                exact point block1696 (by omega) (by omega)
        ·
          by_cases h1824 : pc < 1824
          ·
            by_cases h1760 : pc < 1760
            ·
              exact point block1728 (by omega) (by omega)
            ·
              by_cases h1792 : pc < 1792
              ·
                exact point block1760 (by omega) (by omega)
              ·
                exact point block1792 (by omega) (by omega)
          ·
            by_cases h1856 : pc < 1856
            ·
              exact point block1824 (by omega) (by omega)
            ·
              by_cases h1888 : pc < 1888
              ·
                exact point block1856 (by omega) (by omega)
              ·
                exact point block1888 (by omega) (by omega)
      ·
        by_cases h2112 : pc < 2112
        ·
          by_cases h2016 : pc < 2016
          ·
            by_cases h1952 : pc < 1952
            ·
              exact point block1920 (by omega) (by omega)
            ·
              by_cases h1984 : pc < 1984
              ·
                exact point block1952 (by omega) (by omega)
              ·
                exact point block1984 (by omega) (by omega)
          ·
            by_cases h2048 : pc < 2048
            ·
              exact point block2016 (by omega) (by omega)
            ·
              by_cases h2080 : pc < 2080
              ·
                exact point block2048 (by omega) (by omega)
              ·
                exact point block2080 (by omega) (by omega)
        ·
          by_cases h2208 : pc < 2208
          ·
            by_cases h2144 : pc < 2144
            ·
              exact point block2112 (by omega) (by omega)
            ·
              by_cases h2176 : pc < 2176
              ·
                exact point block2144 (by omega) (by omega)
              ·
                exact point block2176 (by omega) (by omega)
          ·
            by_cases h2240 : pc < 2240
            ·
              exact point block2208 (by omega) (by omega)
            ·
              by_cases h2272 : pc < 2272
              ·
                exact point block2240 (by omega) (by omega)
              ·
                exact point block2272 (by omega) (by omega)
    ·
      by_cases h2688 : pc < 2688
      ·
        by_cases h2496 : pc < 2496
        ·
          by_cases h2400 : pc < 2400
          ·
            by_cases h2336 : pc < 2336
            ·
              exact point block2304 (by omega) (by omega)
            ·
              by_cases h2368 : pc < 2368
              ·
                exact point block2336 (by omega) (by omega)
              ·
                exact point block2368 (by omega) (by omega)
          ·
            by_cases h2432 : pc < 2432
            ·
              exact point block2400 (by omega) (by omega)
            ·
              by_cases h2464 : pc < 2464
              ·
                exact point block2432 (by omega) (by omega)
              ·
                exact point block2464 (by omega) (by omega)
        ·
          by_cases h2592 : pc < 2592
          ·
            by_cases h2528 : pc < 2528
            ·
              exact point block2496 (by omega) (by omega)
            ·
              by_cases h2560 : pc < 2560
              ·
                exact point block2528 (by omega) (by omega)
              ·
                exact point block2560 (by omega) (by omega)
          ·
            by_cases h2624 : pc < 2624
            ·
              exact point block2592 (by omega) (by omega)
            ·
              by_cases h2656 : pc < 2656
              ·
                exact point block2624 (by omega) (by omega)
              ·
                exact point block2656 (by omega) (by omega)
      ·
        by_cases h2880 : pc < 2880
        ·
          by_cases h2784 : pc < 2784
          ·
            by_cases h2720 : pc < 2720
            ·
              exact point block2688 (by omega) (by omega)
            ·
              by_cases h2752 : pc < 2752
              ·
                exact point block2720 (by omega) (by omega)
              ·
                exact point block2752 (by omega) (by omega)
          ·
            by_cases h2816 : pc < 2816
            ·
              exact point block2784 (by omega) (by omega)
            ·
              by_cases h2848 : pc < 2848
              ·
                exact point block2816 (by omega) (by omega)
              ·
                exact point block2848 (by omega) (by omega)
        ·
          by_cases h2976 : pc < 2976
          ·
            by_cases h2912 : pc < 2912
            ·
              exact point block2880 (by omega) (by omega)
            ·
              by_cases h2944 : pc < 2944
              ·
                exact point block2912 (by omega) (by omega)
              ·
                exact point block2944 (by omega) (by omega)
          ·
            by_cases h3040 : pc < 3040
            ·
              by_cases h3008 : pc < 3008
              ·
                exact point block2976 (by omega) (by omega)
              ·
                exact point block3008 (by omega) (by omega)
            ·
              by_cases h3072 : pc < 3072
              ·
                exact point block3040 (by omega) (by omega)
              ·
                exact point block3072 (by omega) (by omega)

theorem inc_target_valid {pc r d : Nat} (h : pc < siteCount)
    (step : program pc = Command.inc r d) : r < 9 ∧ d < siteCount := by
  have bound := targets_valid pc h
  rw [step] at bound
  exact bound

theorem dec_targets_valid {pc r z p : Nat} {b : Bool} (h : pc < siteCount)
    (step : program pc = Command.dec r z p b) : r < 9 ∧ z < siteCount ∧ p < siteCount := by
  have bound := targets_valid pc h
  rw [step] at bound
  exact bound

theorem jump_target_valid {pc d : Nat} (h : pc < siteCount)
    (step : program pc = Command.jump d) : d < siteCount := by
  have bound := targets_valid pc h
  rw [step] at bound
  exact bound

#print axioms targets_valid
end NF192.Frame
