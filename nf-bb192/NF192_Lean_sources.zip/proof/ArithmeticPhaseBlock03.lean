module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block0768 : checkRange 768 32 = true := by decide +kernel
theorem block0800 : checkRange 800 32 = true := by decide +kernel
theorem block0832 : checkRange 832 32 = true := by decide +kernel
theorem block0864 : checkRange 864 32 = true := by decide +kernel
theorem block0896 : checkRange 896 32 = true := by decide +kernel
theorem block0928 : checkRange 928 32 = true := by decide +kernel
theorem block0960 : checkRange 960 32 = true := by decide +kernel
theorem block0992 : checkRange 992 32 = true := by decide +kernel

end NF192.Phase
