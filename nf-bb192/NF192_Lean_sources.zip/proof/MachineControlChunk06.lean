module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases06_00 : List Case := [
  ⟨1236, false, 8365099776, 1922648832, 70, 0, 0⟩,
  ⟨1240, false, 3935914752, 177818368, 64, 0, 0⟩,
  ⟨1243, false, 2056866560, 446253824, 62, 0, 0⟩,
  ⟨1247, true, 22659287808, 3331934976, 35, 31, 38⟩,
  ⟨1250, false, 65608960768, 14069353216, 74, 0, 0⟩,
  ⟨1251, false, 3331934976, 110709504, 66, 0, 0⟩,
  ⟨1254, false, 3868805888, 647580416, 66, 0, 0⟩,
  ⟨1258, false, 15411530496, 379144960, 68, 0, 0⟩
]

theorem cases06_00_verified : cases06_00.all verified = true := by decide

def cases06_01 : List Case := [
  ⟨1263, false, 63729912576, 12190305024, 72, 0, 0⟩,
  ⟨1264, false, 7895337728, 379144960, 64, 0, 0⟩,
  ⟨1268, false, 8432208640, 916015872, 66, 0, 0⟩,
  ⟨1272, false, 832129792, 26823424, 58, 0, 0⟩,
  ⟨1275, false, 1771653888, 161041152, 62, 0, 0⟩,
  ⟨1279, false, 15461862144, 429476608, 68, 0, 0⟩,
  ⟨1284, false, 63780244224, 12240636672, 72, 0, 0⟩,
  ⟨1285, false, 7945669376, 429476608, 64, 0, 0⟩
]

theorem cases06_01_verified : cases06_01.all verified = true := by decide

def cases06_02 : List Case := [
  ⟨1288, false, 4187572992, 966347520, 66, 0, 0⟩,
  ⟨1292, false, 1972980480, 93932288, 60, 0, 0⟩,
  ⟨1295, false, 1033456384, 228150016, 58, 0, 0⟩,
  ⟨1298, false, 3281603328, 60377856, 60, 0, 0⟩,
  ⟨1301, false, 7039699712, 597248768, 64, 0, 0⟩,
  ⟨1305, false, 61800532736, 1670990592, 70, 0, 0⟩,
  ⟨1310, false, 255074061056, 48915630848, 74, 0, 0⟩,
  ⟨1311, false, 31735761664, 1670990592, 66, 0, 0⟩
]

theorem cases06_02_verified : cases06_02.all verified = true := by decide

def cases06_03 : List Case := [
  ⟨1314, false, 16703376128, 3818474240, 68, 0, 0⟩,
  ⟨1318, false, 4086909696, 328813312, 60, 0, 0⟩,
  ⟨1321, false, 999901952, 194595584, 56, 0, 0⟩,
  ⟨1325, true, 22676065024, 3348712192, 33, 31, 38⟩,
  ⟨1328, false, 65625737984, 14086130432, 72, 0, 0⟩,
  ⟨1329, false, 3348712192, 127486720, 64, 0, 0⟩,
  ⟨1332, false, 3885583104, 664357632, 64, 0, 0⟩,
  ⟨1336, false, 15428307712, 395922176, 66, 0, 0⟩
]

theorem cases06_03_verified : cases06_03.all verified = true := by decide

def cases06_04 : List Case := [
  ⟨1341, false, 63746689792, 12207082240, 70, 0, 0⟩,
  ⟨1342, false, 7912114944, 395922176, 62, 0, 0⟩,
  ⟨1346, false, 8448985856, 932793088, 64, 0, 0⟩,
  ⟨1350, false, 408505088, 5851904, 56, 0, 0⟩,
  ⟨1353, false, 878267136, 72960768, 60, 0, 0⟩,
  ⟨1357, false, 7723371264, 207178496, 66, 0, 0⟩,
  ⟨1362, false, 31882562304, 6112758528, 70, 0, 0⟩,
  ⟨1363, false, 3965274880, 207178496, 62, 0, 0⟩
]

theorem cases06_04_verified : cases06_04.all verified = true := by decide

def cases06_05 : List Case := [
  ⟨1366, false, 2086226688, 475613952, 64, 0, 0⟩,
  ⟨1370, false, 978930432, 39406336, 58, 0, 0⟩,
  ⟨1373, false, 509168384, 106515200, 62, 0, 0⟩,
  ⟨1376, false, 1633241856, 22629120, 58, 0, 0⟩,
  ⟨1379, false, 3512290048, 291064576, 62, 0, 0⟩,
  ⟨1383, false, 30892706560, 827935488, 68, 0, 0⟩,
  ⟨1388, false, 127529470720, 24450255616, 72, 0, 0⟩,
  ⟨1389, false, 15860321024, 827935488, 64, 0, 0⟩
]

theorem cases06_05_verified : cases06_05.all verified = true := by decide

def cases06_06 : List Case := [
  ⟨1392, false, 8344128256, 1901677312, 66, 0, 0⟩,
  ⟨1396, false, 2035895040, 156846848, 58, 0, 0⟩,
  ⟨1399, false, 492391168, 89737984, 54, 0, 0⟩,
  ⟨1403, true, 11330472704, 1666796288, 32, 30, 37⟩,
  ⟨1406, false, 32805309184, 7035505408, 70, 0, 0⟩,
  ⟨1407, false, 1666796288, 56183552, 62, 0, 0⟩,
  ⟨1410, false, 1935231744, 324619008, 62, 0, 0⟩,
  ⟨1414, false, 7706594048, 190401280, 64, 0, 0⟩
]

theorem cases06_06_verified : cases06_06.all verified = true := by decide

def cases06_07 : List Case := [
  ⟨1419, false, 31865785088, 6095981312, 68, 0, 0⟩,
  ⟨1420, false, 3948497664, 190401280, 60, 0, 0⟩,
  ⟨1424, false, 4216933120, 458836736, 62, 0, 0⟩,
  ⟨1429, true, 5651385088, 819546880, 31, 29, 36⟩,
  ⟨1432, false, 16388803328, 3503901440, 68, 0, 0⟩,
  ⟨1433, false, 819546880, 14240512, 60, 0, 0⟩,
  ⟨1436, false, 953764608, 148458240, 60, 0, 0⟩,
  ⟨1440, false, 3839445760, 81349376, 62, 0, 0⟩
]

theorem cases06_07_verified : cases06_07.all verified = true := by decide

def cases06 : List Case := cases06_00 ++ cases06_01 ++ cases06_02 ++ cases06_03 ++ cases06_04 ++ cases06_05 ++ cases06_06 ++ cases06_07

theorem cases06_verified : cases06.all verified = true := by
  simp only [cases06, List.all_append, cases06_00_verified, cases06_01_verified, cases06_02_verified, cases06_03_verified, cases06_04_verified, cases06_05_verified, cases06_06_verified, cases06_07_verified, Bool.and_self]

end NF192.Control
