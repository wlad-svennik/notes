module
public import MachinePhysicalArithmetic
public import PhysicalProtocol

@[expose] public section

namespace NF192

/-- The exact blank-tape table recognizes the numeral 3 of the literal
nine-family numerical calculus, in both directions and at arbitrary times. -/
theorem countdown_halts_iff_goal :
    NF210.TM.Halts Selected.machine Selected.start ↔ Numerical.Deriv Numerical.goal :=
  Physical.blank_iff_goal Physical.arithmetic

end NF192

#print axioms NF192.countdown_halts_iff_goal
