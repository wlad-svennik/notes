module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases17_00 : List Case := [
  ⟨1629, true, 1637, false, 27, 2, 34⟩,
  ⟨1630, false, 1631, false, 30, 1, 37⟩,
  ⟨1631, false, 1632, false, 32, 1, 39⟩,
  ⟨1631, true, 1633, false, 31, 2, 38⟩,
  ⟨1633, false, 1634, false, 32, 1, 39⟩,
  ⟨1633, true, 1636, false, 29, 4, 36⟩,
  ⟨1634, false, 1635, false, 33, 1, 40⟩,
  ⟨1637, false, 1638, false, 28, 1, 35⟩]
theorem carryCases17_00_verified : carryCases17_00.all verified = true := by decide

def carryCases17_01 : List Case := [
  ⟨1637, true, 1640, false, 26, 3, 33⟩,
  ⟨1638, false, 1639, false, 29, 1, 36⟩,
  ⟨1640, false, 1641, false, 29, 1, 36⟩,
  ⟨1640, true, 1644, false, 28, 2, 35⟩,
  ⟨1641, false, 1642, false, 30, 1, 37⟩,
  ⟨1642, false, 1643, false, 31, 1, 38⟩,
  ⟨1644, false, 1645, false, 29, 1, 36⟩,
  ⟨1644, true, 1650, false, 27, 3, 34⟩]
theorem carryCases17_01_verified : carryCases17_01.all verified = true := by decide

def carryCases17_02 : List Case := [
  ⟨1645, false, 1646, false, 31, 1, 38⟩,
  ⟨1646, false, 1647, false, 32, 1, 39⟩,
  ⟨1646, true, 1649, false, 30, 3, 37⟩,
  ⟨1647, false, 1648, false, 33, 1, 40⟩,
  ⟨1650, false, 1651, false, 28, 1, 35⟩,
  ⟨1650, true, 1654, false, 25, 4, 32⟩,
  ⟨1651, false, 1652, false, 29, 1, 36⟩,
  ⟨1652, false, 1653, false, 30, 1, 37⟩]
theorem carryCases17_02_verified : carryCases17_02.all verified = true := by decide

def carryCases17_03 : List Case := [
  ⟨1654, false, 1655, false, 18, 8, 25⟩,
  ⟨1655, false, 1656, false, 23, 1, 30⟩,
  ⟨1655, true, 1658, false, 22, 2, 29⟩,
  ⟨1656, false, 1657, false, 24, 1, 31⟩,
  ⟨1658, false, 1659, false, 24, 1, 31⟩,
  ⟨1658, true, 1661, false, 23, 2, 30⟩,
  ⟨1659, false, 1660, false, 25, 1, 32⟩,
  ⟨1661, false, 1662, false, 26, 1, 33⟩]
theorem carryCases17_03_verified : carryCases17_03.all verified = true := by decide

def carryCases17_04 : List Case := [
  ⟨1661, true, 1665, false, 25, 2, 32⟩,
  ⟨1662, false, 1663, false, 27, 1, 34⟩,
  ⟨1663, false, 1664, false, 28, 1, 35⟩,
  ⟨1665, false, 1666, false, 26, 1, 33⟩,
  ⟨1665, true, 1671, false, 24, 3, 31⟩,
  ⟨1666, false, 1667, false, 28, 1, 35⟩,
  ⟨1667, false, 1668, false, 29, 1, 36⟩,
  ⟨1667, true, 1670, false, 27, 3, 34⟩]
theorem carryCases17_04_verified : carryCases17_04.all verified = true := by decide

def carryCases17_05 : List Case := [
  ⟨1668, false, 1669, false, 30, 1, 37⟩,
  ⟨1671, false, 1672, false, 25, 1, 32⟩,
  ⟨1671, true, 1674, false, 21, 5, 28⟩,
  ⟨1672, false, 1673, false, 26, 1, 33⟩,
  ⟨1674, false, 1675, false, 23, 1, 30⟩,
  ⟨1674, true, 1678, false, 22, 2, 29⟩,
  ⟨1675, false, 1676, false, 24, 1, 31⟩,
  ⟨1676, false, 1677, false, 25, 1, 32⟩]
theorem carryCases17_05_verified : carryCases17_05.all verified = true := by decide

def carryCases17_06 : List Case := [
  ⟨1678, false, 1679, false, 23, 1, 30⟩,
  ⟨1678, true, 1681, false, 20, 4, 27⟩,
  ⟨1679, false, 1680, false, 24, 1, 31⟩,
  ⟨1681, false, 1682, false, 25, 1, 32⟩,
  ⟨1681, true, 1684, false, 24, 2, 31⟩,
  ⟨1682, false, 1683, false, 26, 1, 33⟩,
  ⟨1684, false, 1685, false, 26, 1, 33⟩,
  ⟨1684, true, 1687, false, 25, 2, 32⟩]
theorem carryCases17_06_verified : carryCases17_06.all verified = true := by decide

def carryCases17_07 : List Case := [
  ⟨1685, false, 1686, false, 27, 1, 34⟩,
  ⟨1687, false, 1688, false, 28, 1, 35⟩,
  ⟨1687, true, 1691, false, 27, 2, 34⟩,
  ⟨1688, false, 1689, false, 29, 1, 36⟩,
  ⟨1689, false, 1690, false, 30, 1, 37⟩,
  ⟨1691, false, 1692, false, 28, 1, 35⟩,
  ⟨1691, true, 1697, false, 26, 3, 33⟩,
  ⟨1692, false, 1693, false, 30, 1, 37⟩]
theorem carryCases17_07_verified : carryCases17_07.all verified = true := by decide

def carryCases17_08 : List Case := [
  ⟨1693, false, 1694, false, 31, 1, 38⟩,
  ⟨1693, true, 1696, false, 29, 3, 36⟩,
  ⟨1694, false, 1695, false, 32, 1, 39⟩,
  ⟨1697, false, 1698, false, 27, 1, 34⟩,
  ⟨1697, true, 1700, false, 23, 5, 30⟩,
  ⟨1698, false, 1699, false, 28, 1, 35⟩,
  ⟨1700, false, 1701, false, 24, 1, 31⟩,
  ⟨1700, true, 1704, false, 22, 3, 29⟩]
theorem carryCases17_08_verified : carryCases17_08.all verified = true := by decide

def carryCases17_09 : List Case := [
  ⟨1701, false, 1702, false, 25, 1, 32⟩,
  ⟨1702, false, 1703, false, 26, 1, 33⟩,
  ⟨1704, false, 1705, false, 23, 1, 30⟩,
  ⟨1704, true, 1707, false, 21, 3, 28⟩,
  ⟨1705, false, 1706, false, 24, 1, 31⟩,
  ⟨1707, false, 1708, false, 26, 1, 33⟩,
  ⟨1707, true, 1710, false, 25, 2, 32⟩,
  ⟨1708, false, 1709, false, 27, 1, 34⟩]
theorem carryCases17_09_verified : carryCases17_09.all verified = true := by decide

def carryCases17_10 : List Case := [
  ⟨1710, false, 1711, false, 27, 1, 34⟩,
  ⟨1710, true, 1713, false, 26, 2, 33⟩,
  ⟨1711, false, 1712, false, 28, 1, 35⟩,
  ⟨1713, false, 1714, false, 29, 1, 36⟩,
  ⟨1713, true, 1717, false, 28, 2, 35⟩,
  ⟨1714, false, 1715, false, 30, 1, 37⟩,
  ⟨1715, false, 1716, false, 31, 1, 38⟩,
  ⟨1717, false, 1718, false, 29, 1, 36⟩]
theorem carryCases17_10_verified : carryCases17_10.all verified = true := by decide

def carryCases17_11 : List Case := [
  ⟨1717, true, 1723, false, 27, 3, 34⟩,
  ⟨1718, false, 1719, false, 31, 1, 38⟩,
  ⟨1719, false, 1720, false, 32, 1, 39⟩,
  ⟨1719, true, 1722, false, 30, 3, 37⟩,
  ⟨1720, false, 1721, false, 33, 1, 40⟩,
  ⟨1723, false, 1724, false, 28, 1, 35⟩,
  ⟨1723, true, 1726, false, 24, 5, 31⟩,
  ⟨1724, false, 1725, false, 29, 1, 36⟩]
theorem carryCases17_11_verified : carryCases17_11.all verified = true := by decide

def carryCases17 : List Case := carryCases17_00 ++ carryCases17_01 ++ carryCases17_02 ++ carryCases17_03 ++ carryCases17_04 ++ carryCases17_05 ++ carryCases17_06 ++ carryCases17_07 ++ carryCases17_08 ++ carryCases17_09 ++ carryCases17_10 ++ carryCases17_11
theorem carryCases17_verified : carryCases17.all verified = true := by
  simp only [carryCases17, List.all_append, carryCases17_00_verified, carryCases17_01_verified, carryCases17_02_verified, carryCases17_03_verified, carryCases17_04_verified, carryCases17_05_verified, carryCases17_06_verified, carryCases17_07_verified, carryCases17_08_verified, carryCases17_09_verified, carryCases17_10_verified, carryCases17_11_verified, Bool.and_self]
theorem carryCases17_covered : carryCases17.map (fun c => key c.pc c.zero) = keysBetween 3259 193 := by decide
theorem carryCases17_count : carryCases17.length = 96 := by decide
end NF192.Carry
