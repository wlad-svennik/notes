module
public import MachineArithmeticReturns

@[expose] public section
namespace NF192.ArithmeticReturn
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block3072 : checkRange 3072 17 = true := by decide +kernel

end NF192.ArithmeticReturn
