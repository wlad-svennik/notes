module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases02_00 : List Case := [
  ⟨405, false, 109988608, 9325312, 54, 0, 0⟩,
  ⟨409, false, 965626624, 26102528, 60, 0, 0⟩,
  ⟨414, false, 3985525504, 764300032, 64, 0, 0⟩,
  ⟨415, false, 495864576, 26102528, 56, 0, 0⟩,
  ⟨418, false, 260983552, 59656960, 58, 0, 0⟩,
  ⟨422, false, 122571520, 5131008, 52, 0, 0⟩,
  ⟨425, false, 63851264, 13519616, 56, 0, 0⟩,
  ⟨428, false, 204360448, 3033856, 52, 0, 0⟩
]

theorem cases02_00_verified : cases02_00.all verified = true := by decide

def cases02_01 : List Case := [
  ⟨431, false, 439241472, 36588288, 56, 0, 0⟩,
  ⟨435, false, 3861793536, 103697152, 62, 0, 0⟩,
  ⟨440, false, 15941389056, 3056487168, 66, 0, 0⟩,
  ⟨441, false, 1982745344, 103697152, 58, 0, 0⟩,
  ⟨444, false, 1043221248, 237914880, 60, 0, 0⟩,
  ⟨448, false, 254692096, 19811072, 52, 0, 0⟩,
  ⟨451, false, 61754112, 11422464, 48, 0, 0⟩,
  ⟨455, true, 1416514304, 208554752, 29, 27, 34⟩
]

theorem cases02_01_verified : cases02_01.all verified = true := by decide

def cases02_02 : List Case := [
  ⟨458, false, 4100868864, 879643392, 64, 0, 0⟩,
  ⟨459, false, 208554752, 7228160, 56, 0, 0⟩,
  ⟨462, false, 242109184, 40782592, 56, 0, 0⟩,
  ⟨466, false, 963529472, 24005376, 58, 0, 0⟩,
  ⟨471, false, 3983428352, 762202880, 62, 0, 0⟩,
  ⟨472, false, 493767424, 24005376, 54, 0, 0⟩,
  ⟨476, false, 527321856, 57559808, 56, 0, 0⟩,
  ⟨480, false, 102648576, 1985280, 50, 0, 0⟩
]

theorem cases02_02_verified : cases02_02.all verified = true := by decide

def cases02_03 : List Case := [
  ⟨483, false, 220089088, 18762496, 54, 0, 0⟩,
  ⟨487, false, 1931365120, 52316928, 60, 0, 0⟩,
  ⟨492, false, 7971162880, 1528711936, 64, 0, 0⟩,
  ⟨493, false, 991841024, 52316928, 56, 0, 0⟩,
  ⟨496, false, 522078976, 119425792, 58, 0, 0⟩,
  ⟨500, false, 127814400, 10373888, 50, 0, 0⟩,
  ⟨503, false, 31345408, 6179584, 46, 0, 0⟩,
  ⟨507, true, 708725504, 104745728, 28, 26, 33⟩
]

theorem cases02_03_verified : cases02_03.all verified = true := by decide

def cases02_04 : List Case := [
  ⟨510, false, 2050902784, 440290048, 62, 0, 0⟩,
  ⟨511, false, 104745728, 4082432, 54, 0, 0⟩,
  ⟨514, false, 121522944, 20859648, 54, 0, 0⟩,
  ⟨518, false, 482233088, 12471040, 56, 0, 0⟩,
  ⟨523, false, 1992182528, 381569792, 60, 0, 0⟩,
  ⟨524, false, 247352064, 12471040, 52, 0, 0⟩,
  ⟨528, false, 264129280, 29248256, 54, 0, 0⟩,
  ⟨532, false, 6376192, 84736, 42, 0, 0⟩
]

theorem cases02_04_verified : cases02_04.all verified = true := by decide

def cases02_05 : List Case := [
  ⟨535, false, 13716224, 1133312, 46, 0, 0⟩,
  ⟨539, false, 120670976, 3230464, 52, 0, 0⟩,
  ⟨544, false, 498158336, 95505152, 56, 0, 0⟩,
  ⟨545, false, 61950720, 3230464, 48, 0, 0⟩,
  ⟨548, false, 32590592, 7424768, 50, 0, 0⟩,
  ⟨552, false, 814304000, 8997632, 60, 0, 0⟩,
  ⟨555, false, 1753828096, 143215360, 64, 0, 0⟩,
  ⟨559, false, 15444036352, 411650816, 70, 0, 0⟩
]

theorem cases02_05_verified : cases02_05.all verified = true := by decide

def cases02_06 : List Case := [
  ⟨564, false, 63762418432, 12222810880, 74, 0, 0⟩,
  ⟨565, false, 7927843584, 411650816, 66, 0, 0⟩,
  ⟨568, false, 4169747200, 948521728, 68, 0, 0⟩,
  ⟨571, false, 6518557440, 76106496, 68, 0, 0⟩,
  ⟨574, false, 14034750208, 1149848320, 72, 0, 0⟩,
  ⟨578, false, 123556416256, 3297331968, 78, 0, 0⟩,
  ⟨583, false, 510103472896, 97786612480, 82, 0, 0⟩,
  ⟨584, false, 63426874112, 3297331968, 74, 0, 0⟩
]

theorem cases02_06_verified : cases02_06.all verified = true := by decide

def cases02_07 : List Case := [
  ⟨587, false, 33362103040, 7592299264, 76, 0, 0⟩,
  ⟨591, false, 15645362944, 612977408, 70, 0, 0⟩,
  ⟨594, false, 8129170176, 1686719232, 74, 0, 0⟩,
  ⟨598, true, 90538855168, 13229443840, 39, 33, 40⟩,
  ⟨601, false, 262337547008, 56179116800, 80, 0, 0⟩,
  ⟨602, false, 13229443840, 344541952, 72, 0, 0⟩,
  ⟨605, false, 15376927488, 2492025600, 72, 0, 0⟩,
  ⟨609, false, 61547825920, 1418283776, 74, 0, 0⟩
]

theorem cases02_07_verified : cases02_07.all verified = true := by decide

def cases02 : List Case := cases02_00 ++ cases02_01 ++ cases02_02 ++ cases02_03 ++ cases02_04 ++ cases02_05 ++ cases02_06 ++ cases02_07

theorem cases02_verified : cases02.all verified = true := by
  simp only [cases02, List.all_append, cases02_00_verified, cases02_01_verified, cases02_02_verified, cases02_03_verified, cases02_04_verified, cases02_05_verified, cases02_06_verified, cases02_07_verified, Bool.and_self]

end NF192.Control
