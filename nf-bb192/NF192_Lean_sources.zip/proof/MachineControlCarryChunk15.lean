module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases15_00 : List Case := [
  ⟨1437, true, 1441, false, 28, 2, 35⟩,
  ⟨1438, false, 1439, false, 30, 1, 37⟩,
  ⟨1439, false, 1440, false, 31, 1, 38⟩,
  ⟨1441, false, 1442, false, 29, 1, 36⟩,
  ⟨1441, true, 1447, false, 27, 3, 34⟩,
  ⟨1442, false, 1443, false, 31, 1, 38⟩,
  ⟨1443, false, 1444, false, 32, 1, 39⟩,
  ⟨1443, true, 1446, false, 30, 3, 37⟩]
theorem carryCases15_00_verified : carryCases15_00.all verified = true := by decide

def carryCases15_01 : List Case := [
  ⟨1444, false, 1445, false, 33, 1, 40⟩,
  ⟨1447, false, 1448, false, 28, 1, 35⟩,
  ⟨1447, true, 1451, false, 25, 4, 32⟩,
  ⟨1448, false, 1449, false, 29, 1, 36⟩,
  ⟨1449, false, 1450, false, 30, 1, 37⟩,
  ⟨1451, false, 1452, false, 24, 2, 31⟩,
  ⟨1452, false, 1453, false, 27, 1, 34⟩,
  ⟨1452, true, 1460, false, 26, 2, 33⟩]
theorem carryCases15_01_verified : carryCases15_01.all verified = true := by decide

def carryCases15_02 : List Case := [
  ⟨1453, false, 1454, false, 29, 1, 36⟩,
  ⟨1454, false, 1455, false, 31, 1, 38⟩,
  ⟨1454, true, 1456, false, 30, 2, 37⟩,
  ⟨1456, false, 1457, false, 31, 1, 38⟩,
  ⟨1456, true, 1459, false, 28, 4, 35⟩,
  ⟨1457, false, 1458, false, 32, 1, 39⟩,
  ⟨1460, false, 1461, false, 27, 1, 34⟩,
  ⟨1460, true, 1463, false, 25, 3, 32⟩]
theorem carryCases15_02_verified : carryCases15_02.all verified = true := by decide

def carryCases15_03 : List Case := [
  ⟨1461, false, 1462, false, 28, 1, 35⟩,
  ⟨1463, false, 1464, false, 28, 1, 35⟩,
  ⟨1463, true, 1467, false, 27, 2, 34⟩,
  ⟨1464, false, 1465, false, 29, 1, 36⟩,
  ⟨1465, false, 1466, false, 30, 1, 37⟩,
  ⟨1467, false, 1468, false, 28, 1, 35⟩,
  ⟨1467, true, 1473, false, 26, 3, 33⟩,
  ⟨1468, false, 1469, false, 30, 1, 37⟩]
theorem carryCases15_03_verified : carryCases15_03.all verified = true := by decide

def carryCases15_04 : List Case := [
  ⟨1469, false, 1470, false, 31, 1, 38⟩,
  ⟨1469, true, 1472, false, 29, 3, 36⟩,
  ⟨1470, false, 1471, false, 32, 1, 39⟩,
  ⟨1473, false, 1474, false, 27, 1, 34⟩,
  ⟨1473, true, 1477, false, 21, 7, 28⟩,
  ⟨1474, false, 1475, false, 28, 1, 35⟩,
  ⟨1475, false, 1476, false, 29, 1, 36⟩,
  ⟨1477, false, 1478, false, 26, 1, 33⟩]
theorem carryCases15_04_verified : carryCases15_04.all verified = true := by decide

def carryCases15_05 : List Case := [
  ⟨1477, true, 1480, false, 25, 2, 32⟩,
  ⟨1478, false, 1479, false, 27, 1, 34⟩,
  ⟨1480, false, 1481, false, 27, 1, 34⟩,
  ⟨1480, true, 1483, false, 26, 2, 33⟩,
  ⟨1481, false, 1482, false, 28, 1, 35⟩,
  ⟨1483, false, 1484, false, 29, 1, 36⟩,
  ⟨1483, true, 1487, false, 28, 2, 35⟩,
  ⟨1484, false, 1485, false, 30, 1, 37⟩]
theorem carryCases15_05_verified : carryCases15_05.all verified = true := by decide

def carryCases15_06 : List Case := [
  ⟨1485, false, 1486, false, 31, 1, 38⟩,
  ⟨1487, false, 1488, false, 29, 1, 36⟩,
  ⟨1487, true, 1493, false, 27, 3, 34⟩,
  ⟨1488, false, 1489, false, 31, 1, 38⟩,
  ⟨1489, false, 1490, false, 32, 1, 39⟩,
  ⟨1489, true, 1492, false, 30, 3, 37⟩,
  ⟨1490, false, 1491, false, 33, 1, 40⟩,
  ⟨1493, false, 1494, false, 28, 1, 35⟩]
theorem carryCases15_06_verified : carryCases15_06.all verified = true := by decide

def carryCases15_07 : List Case := [
  ⟨1493, true, 1496, false, 24, 5, 31⟩,
  ⟨1494, false, 1495, false, 29, 1, 36⟩,
  ⟨1496, false, 1497, false, 25, 1, 32⟩,
  ⟨1497, false, 1498, false, 26, 1, 33⟩,
  ⟨1498, false, 1499, false, 23, 4, 30⟩,
  ⟨1499, false, 1500, false, 27, 1, 34⟩,
  ⟨1499, true, 1502, false, 26, 2, 33⟩,
  ⟨1500, false, 1501, false, 28, 1, 35⟩]
theorem carryCases15_07_verified : carryCases15_07.all verified = true := by decide

def carryCases15_08 : List Case := [
  ⟨1502, false, 1503, false, 28, 1, 35⟩,
  ⟨1502, true, 1505, false, 27, 2, 34⟩,
  ⟨1503, false, 1504, false, 29, 1, 36⟩,
  ⟨1505, false, 1506, false, 30, 1, 37⟩,
  ⟨1505, true, 1509, false, 29, 2, 36⟩,
  ⟨1506, false, 1507, false, 31, 1, 38⟩,
  ⟨1507, false, 1508, false, 32, 1, 39⟩,
  ⟨1509, false, 1510, false, 30, 1, 37⟩]
theorem carryCases15_08_verified : carryCases15_08.all verified = true := by decide

def carryCases15_09 : List Case := [
  ⟨1509, true, 1515, false, 28, 3, 35⟩,
  ⟨1510, false, 1511, false, 32, 1, 39⟩,
  ⟨1511, false, 1512, false, 33, 1, 40⟩,
  ⟨1511, true, 1514, false, 31, 3, 38⟩,
  ⟨1512, false, 1513, false, 34, 1, 41⟩,
  ⟨1515, false, 1516, false, 29, 1, 36⟩,
  ⟨1515, true, 1518, false, 25, 5, 32⟩,
  ⟨1516, false, 1517, false, 30, 1, 37⟩]
theorem carryCases15_09_verified : carryCases15_09.all verified = true := by decide

def carryCases15_10 : List Case := [
  ⟨1518, false, 1519, false, 27, 1, 34⟩,
  ⟨1518, true, 1522, false, 26, 2, 33⟩,
  ⟨1519, false, 1520, false, 28, 1, 35⟩,
  ⟨1520, false, 1521, false, 29, 1, 36⟩,
  ⟨1522, false, 1523, false, 27, 1, 34⟩,
  ⟨1522, true, 1525, false, 24, 4, 31⟩,
  ⟨1523, false, 1524, false, 28, 1, 35⟩,
  ⟨1525, false, 1526, false, 28, 1, 35⟩]
theorem carryCases15_10_verified : carryCases15_10.all verified = true := by decide

def carryCases15_11 : List Case := [
  ⟨1525, true, 1533, false, 27, 2, 34⟩,
  ⟨1526, false, 1527, false, 30, 1, 37⟩,
  ⟨1527, false, 1528, false, 32, 1, 39⟩,
  ⟨1527, true, 1529, false, 31, 2, 38⟩,
  ⟨1529, false, 1530, false, 32, 1, 39⟩,
  ⟨1529, true, 1532, false, 29, 4, 36⟩,
  ⟨1530, false, 1531, false, 33, 1, 40⟩,
  ⟨1533, false, 1534, false, 28, 1, 35⟩]
theorem carryCases15_11_verified : carryCases15_11.all verified = true := by decide

def carryCases15 : List Case := carryCases15_00 ++ carryCases15_01 ++ carryCases15_02 ++ carryCases15_03 ++ carryCases15_04 ++ carryCases15_05 ++ carryCases15_06 ++ carryCases15_07 ++ carryCases15_08 ++ carryCases15_09 ++ carryCases15_10 ++ carryCases15_11
theorem carryCases15_verified : carryCases15.all verified = true := by
  simp only [carryCases15, List.all_append, carryCases15_00_verified, carryCases15_01_verified, carryCases15_02_verified, carryCases15_03_verified, carryCases15_04_verified, carryCases15_05_verified, carryCases15_06_verified, carryCases15_07_verified, carryCases15_08_verified, carryCases15_09_verified, carryCases15_10_verified, carryCases15_11_verified, Bool.and_self]
theorem carryCases15_covered : carryCases15.map (fun c => key c.pc c.zero) = keysBetween 2875 192 := by decide
theorem carryCases15_count : carryCases15.length = 96 := by decide
end NF192.Carry
