module
public import MachineControlKernelFiles
public import MachineControlKernelControl
public import MachineControlKernelSelectors
public import MachineControlKernelExecution

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-!
# Execute-phase arithmetic routines

Literal transition proofs for locating the selected register, shifting the
unary file, and taking the increment or decrement endpoint branch. All unary
values and surrounding tape are unbounded.
-/

namespace NF192.KernelArithmetic

open NF210 NF210.TM
open NF192.Selected (State machine)
open NF192.KernelRightShift
open NF192.KernelExecution
open NF192.KernelFiles

def seekState : State := ⟨185, by decide⟩
def seekPairState : State := ⟨187, by decide⟩
def probeState : State := ⟨163, by decide⟩

theorem state_names :
    Selected.name seekState = "k:64" ∧
    Selected.name seekPairState = "k:74" ∧
    Selected.name probeState = "k:198" := by decide

theorem seek_ones (count : Nat) :
    RightRun seekState seekState (List.replicate count true) (List.replicate count true) :=
  (RightRun.one (by decide)).repeat count

theorem seek_zero_one : RightRun seekState seekState [false, true] [false, true] := by
  have first : RightRun seekState seekPairState [false] [false] := RightRun.one (by decide)
  have second : RightRun seekPairState seekState [true] [true] := RightRun.one (by decide)
  exact first.trans second

theorem seek_zero_zero : RightRun seekState shiftState [false, false] [false, true] := by
  have first : RightRun seekState seekPairState [false] [false] := RightRun.one (by decide)
  have second : RightRun seekPairState shiftState [false] [true] := RightRun.one (by decide)
  exact first.trans second

def seekOutput (initialRun : Nat) (earlierValues : List Nat) : List Bool :=
  List.replicate initialRun true ++ blocks earlierValues ++ [false, true]

/-- Locate the first marked register and restore its first one. -/
theorem seek_mark (initialRun : Nat) (earlierValues : List Nat) :
    RightRun seekState shiftState (shiftInput initialRun earlierValues)
      (seekOutput initialRun earlierValues) := by
  induction earlierValues generalizing initialRun with
  | nil =>
    simpa [shiftInput, seekOutput, blocks] using (seek_ones initialRun).trans seek_zero_zero
  | cons value rest ih =>
    have certificate := (seek_ones initialRun).trans (seek_zero_one.trans (ih value))
    simpa [shiftInput, seekOutput, blocks, List.replicate_succ, List.append_assoc]
      using certificate

def markedInput (initialRun value : Nat) (earlier following : List Nat) : List Bool :=
  shiftInput initialRun earlier ++ shiftInput value following

def increasedOutput (initialRun value : Nat) (earlier following : List Nat) : List Bool :=
  List.replicate initialRun true ++ blocks earlier ++
    (false :: List.replicate (value + 2) true) ++ blocks following ++ [false]

/-- The selected value increases by one; following blocks shift without changing their values. -/
theorem increment_shift (initialRun value : Nat) (earlier following : List Nat) :
    RightRun seekState endState (markedInput initialRun value earlier following)
      (increasedOutput initialRun value earlier following) := by
  have certificate := (seek_mark initialRun earlier).trans (right_shift value following)
  simpa [markedInput, increasedOutput, shiftOutput, seekOutput,
    List.replicate_succ, List.append_assoc] using certificate

#print axioms seek_mark
#print axioms increment_shift

end NF192.KernelArithmetic
