module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block0512 : checkRange 512 32 = true := by decide +kernel
theorem block0544 : checkRange 544 32 = true := by decide +kernel
theorem block0576 : checkRange 576 32 = true := by decide +kernel
theorem block0608 : checkRange 608 32 = true := by decide +kernel
theorem block0640 : checkRange 640 32 = true := by decide +kernel
theorem block0672 : checkRange 672 32 = true := by decide +kernel
theorem block0704 : checkRange 704 32 = true := by decide +kernel
theorem block0736 : checkRange 736 32 = true := by decide +kernel

end NF192.Phase
