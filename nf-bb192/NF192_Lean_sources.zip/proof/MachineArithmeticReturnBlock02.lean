module
public import MachineArithmeticReturns

@[expose] public section
namespace NF192.ArithmeticReturn
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block1024 : checkRange 1024 32 = true := by decide +kernel
theorem block1056 : checkRange 1056 32 = true := by decide +kernel
theorem block1088 : checkRange 1088 32 = true := by decide +kernel
theorem block1120 : checkRange 1120 32 = true := by decide +kernel
theorem block1152 : checkRange 1152 32 = true := by decide +kernel
theorem block1184 : checkRange 1184 32 = true := by decide +kernel
theorem block1216 : checkRange 1216 32 = true := by decide +kernel
theorem block1248 : checkRange 1248 32 = true := by decide +kernel
theorem block1280 : checkRange 1280 32 = true := by decide +kernel
theorem block1312 : checkRange 1312 32 = true := by decide +kernel
theorem block1344 : checkRange 1344 32 = true := by decide +kernel
theorem block1376 : checkRange 1376 32 = true := by decide +kernel
theorem block1408 : checkRange 1408 32 = true := by decide +kernel
theorem block1440 : checkRange 1440 32 = true := by decide +kernel
theorem block1472 : checkRange 1472 32 = true := by decide +kernel
theorem block1504 : checkRange 1504 32 = true := by decide +kernel

end NF192.ArithmeticReturn
