module
public import SourceSimulation
public import SourceRoundtrip
public import NumericalOuter

@[expose] public section

/-! Assembly of the decoded register program. Each complete parsed command
starts at ordinal 10, after selecting a fresh or continued outer input, and
ends at the next command boundary or at the unique halt. -/
set_option maxHeartbeats 2000000

namespace NF192.SourceSimulation

open Numerical Emitter CommandBlocks ProofSearch SourceFields

def registers (n cursor : Nat) (s : State) : Frame :=
  ⟨n,s.top,pack s.stack,0,s.param,s.cache,cursor⟩

def after (n cursor : Nat) : Option State → Source.Config
  | none => Source.Config.halted
  | some s => atFrame 0 (registers n cursor s)

theorem selected_mp (n d tail : Nat) (s : State) :
    Moves (atFrame 3017 ⟨n,s.top,pack s.stack,0,s.param+d,s.cache,tail⟩)
      (after n tail (one (.mp d) s)) := by
  exact mp_correct n s.top (pack s.stack) 0 (s.param+d) s.cache tail

theorem selected_mode (n d tail : Nat) (s : State) :
    Moves (atFrame 2969 ⟨n,s.top,pack s.stack,0,s.param+d,s.cache,tail⟩)
      (after n tail (one (.mode d) s)) := by
  have hm := mode_correct n s.top (pack s.stack) 0 (s.param+d) s.cache tail
  rw [pop_pack] at hm
  by_cases hit : s.cache = goal
  · simpa only [hit, one, observes, beq_self_eq_true, ite_true, after, ite_eq_left, atFrame, frame, Frame.regs, Visits] using hm
  · have nohit : (s.cache == goal) = false := beq_eq_false_iff_ne.mpr hit
    cases hn : s.param+d with
    | zero => simpa only [one, observes, nohit, Bool.false_eq_true, ite_false, after, ProofSearch.step, hn,
        ite_eq_right hit, registers, atFrame, frame, Frame.regs] using hm
    | succ k => simpa only [one, observes, nohit, Bool.false_eq_true, ite_false, after, ProofSearch.step, hn,
        ite_eq_right hit, registers, atFrame, frame, Frame.regs] using hm

/-- All the AX batches, their loop branches, and the automatic final NIP. -/
def AxSimulation : Prop := ∀ (n u b d tail : Nat) (rest : List (Nat × Nat)) (s : State),
  Moves (atFrame 40 ⟨n,s.top,pack s.stack,rest.length,s.param+u,s.cache,
              encodeBatch (b,d) (encodeBatches rest tail)⟩)
    (after n tail (one (.ax u b d rest) s))

theorem command_encoded (ax : AxSimulation) (n : Nat) (c : ProofSearch.Command)
    (tail : Nat) (s : State) :
    Moves (atFrame 10 (registers n (assemble c tail) s)) (after n tail (one c s)) := by
  cases c with
  | mp d =>
    have rd := outer_read_fields n s.top (pack s.stack) 0 s.param s.cache 0 d tail
    exact (rd.trans (dispatch_mp _ _ _ _ _ _)).trans (selected_mp n d tail s)
  | mode d =>
    have rd := outer_read_fields n s.top (pack s.stack) 0 s.param s.cache 1 d tail
    exact ((rd.trans (dispatch_positive _ _ _ 0 _ _ _)).trans (mode_entry _ _ _ _ _ _)).trans
      (selected_mode n d tail s)
  | ax u b d rest =>
    have rd := outer_read_fields n s.top (pack s.stack) 0 s.param s.cache (rest.length+2) u
      (encodeBatch (b,d) (encodeBatches rest tail))
    rw [Nat.zero_add] at rd
    exact ((rd.trans (dispatch_positive _ _ _ (rest.length+1) _ _ _)).trans
      (ax_entry _ _ _ rest.length _ _ _)).trans (ax n u b d tail rest s)

theorem command_arbitrary (ax : AxSimulation) (n raw : Nat) (s : State) :
    Moves (atFrame 10 (registers n raw s)) (after n (parse raw).2 (one (parse raw).1 s)) := by
  have h := command_encoded ax n (parse raw).1 (parse raw).2 s
  rwa [assemble_parse] at h

theorem after_embed (n cursor : Nat) (res : Option State) :
    after n cursor res = embed (res.map (fun s => (⟨n+1,cursor,s⟩ : StreamState))) := by
  cases res <;> rfl

theorem step_simulation (ax : AxSimulation) : StepSimulation := by
  rintro ⟨next,cursor,s⟩ hn
  cases next with
  | zero => contradiction
  | succ n =>
    cases cursor with
    | zero =>
      have ref := outer_fresh n s.top (pack s.stack) 0 s.param s.cache
      have act := command_arbitrary ax (n+1) (n+1) s
      rw [after_embed] at act
      exact ref.trans act
    | succ k =>
      have ref := outer_continued n s.top (pack s.stack) 0 s.param s.cache k
      have act := command_arbitrary ax n k s
      rw [after_embed] at act
      exact ref.trans act

end NF192.SourceSimulation
