module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases04_00 : List Case := [
  ⟨380, false, 381, false, 28, 1, 35⟩,
  ⟨383, false, 384, false, 23, 1, 30⟩,
  ⟨383, true, 386, false, 21, 3, 28⟩,
  ⟨384, false, 385, false, 24, 1, 31⟩,
  ⟨386, false, 387, false, 24, 1, 31⟩,
  ⟨386, true, 390, false, 23, 2, 30⟩,
  ⟨387, false, 388, false, 25, 1, 32⟩,
  ⟨388, false, 389, false, 26, 1, 33⟩]
theorem carryCases04_00_verified : carryCases04_00.all verified = true := by decide

def carryCases04_01 : List Case := [
  ⟨390, false, 391, false, 24, 1, 31⟩,
  ⟨390, true, 396, false, 22, 3, 29⟩,
  ⟨391, false, 392, false, 26, 1, 33⟩,
  ⟨392, false, 393, false, 27, 1, 34⟩,
  ⟨392, true, 395, false, 25, 3, 32⟩,
  ⟨393, false, 394, false, 28, 1, 35⟩,
  ⟨396, false, 397, false, 23, 1, 30⟩,
  ⟨396, true, 400, false, 19, 5, 26⟩]
theorem carryCases04_01_verified : carryCases04_01.all verified = true := by decide

def carryCases04_02 : List Case := [
  ⟨397, false, 398, false, 24, 1, 31⟩,
  ⟨398, false, 399, false, 25, 1, 32⟩,
  ⟨400, false, 401, false, 24, 1, 31⟩,
  ⟨400, true, 403, false, 23, 2, 30⟩,
  ⟨401, false, 402, false, 25, 1, 32⟩,
  ⟨403, false, 404, false, 25, 1, 32⟩,
  ⟨403, true, 406, false, 24, 2, 31⟩,
  ⟨404, false, 405, false, 26, 1, 33⟩]
theorem carryCases04_02_verified : carryCases04_02.all verified = true := by decide

def carryCases04_03 : List Case := [
  ⟨406, false, 407, false, 27, 1, 34⟩,
  ⟨406, true, 410, false, 26, 2, 33⟩,
  ⟨407, false, 408, false, 28, 1, 35⟩,
  ⟨408, false, 409, false, 29, 1, 36⟩,
  ⟨410, false, 411, false, 27, 1, 34⟩,
  ⟨410, true, 416, false, 25, 3, 32⟩,
  ⟨411, false, 412, false, 29, 1, 36⟩,
  ⟨412, false, 413, false, 30, 1, 37⟩]
theorem carryCases04_03_verified : carryCases04_03.all verified = true := by decide

def carryCases04_04 : List Case := [
  ⟨412, true, 415, false, 28, 3, 35⟩,
  ⟨413, false, 414, false, 31, 1, 38⟩,
  ⟨416, false, 417, false, 26, 1, 33⟩,
  ⟨416, true, 419, false, 22, 5, 29⟩,
  ⟨417, false, 418, false, 27, 1, 34⟩,
  ⟨419, false, 420, false, 24, 1, 31⟩,
  ⟨419, true, 423, false, 23, 2, 30⟩,
  ⟨420, false, 421, false, 25, 1, 32⟩]
theorem carryCases04_04_verified : carryCases04_04.all verified = true := by decide

def carryCases04_05 : List Case := [
  ⟨421, false, 422, false, 26, 1, 33⟩,
  ⟨423, false, 424, false, 24, 1, 31⟩,
  ⟨423, true, 426, false, 21, 4, 28⟩,
  ⟨424, false, 425, false, 25, 1, 32⟩,
  ⟨426, false, 427, false, 26, 1, 33⟩,
  ⟨426, true, 429, false, 25, 2, 32⟩,
  ⟨427, false, 428, false, 27, 1, 34⟩,
  ⟨429, false, 430, false, 27, 1, 34⟩]
theorem carryCases04_05_verified : carryCases04_05.all verified = true := by decide

def carryCases04_06 : List Case := [
  ⟨429, true, 432, false, 26, 2, 33⟩,
  ⟨430, false, 431, false, 28, 1, 35⟩,
  ⟨432, false, 433, false, 29, 1, 36⟩,
  ⟨432, true, 436, false, 28, 2, 35⟩,
  ⟨433, false, 434, false, 30, 1, 37⟩,
  ⟨434, false, 435, false, 31, 1, 38⟩,
  ⟨436, false, 437, false, 29, 1, 36⟩,
  ⟨436, true, 442, false, 27, 3, 34⟩]
theorem carryCases04_06_verified : carryCases04_06.all verified = true := by decide

def carryCases04_07 : List Case := [
  ⟨437, false, 438, false, 31, 1, 38⟩,
  ⟨438, false, 439, false, 32, 1, 39⟩,
  ⟨438, true, 441, false, 30, 3, 37⟩,
  ⟨439, false, 440, false, 33, 1, 40⟩,
  ⟨442, false, 443, false, 28, 1, 35⟩,
  ⟨442, true, 445, false, 24, 5, 31⟩,
  ⟨443, false, 444, false, 29, 1, 36⟩,
  ⟨445, false, 446, false, 25, 1, 32⟩]
theorem carryCases04_07_verified : carryCases04_07.all verified = true := by decide

def carryCases04_08 : List Case := [
  ⟨445, true, 449, false, 23, 3, 30⟩,
  ⟨446, false, 447, false, 26, 1, 33⟩,
  ⟨447, false, 448, false, 27, 1, 34⟩,
  ⟨449, false, 450, false, 24, 1, 31⟩,
  ⟨449, true, 452, false, 22, 3, 29⟩,
  ⟨450, false, 451, false, 25, 1, 32⟩,
  ⟨452, false, 453, false, 26, 1, 33⟩,
  ⟨452, true, 460, false, 25, 2, 32⟩]
theorem carryCases04_08_verified : carryCases04_08.all verified = true := by decide

def carryCases04_09 : List Case := [
  ⟨453, false, 454, false, 28, 1, 35⟩,
  ⟨454, false, 455, false, 30, 1, 37⟩,
  ⟨454, true, 456, false, 29, 2, 36⟩,
  ⟨456, false, 457, false, 30, 1, 37⟩,
  ⟨456, true, 459, false, 27, 4, 34⟩,
  ⟨457, false, 458, false, 31, 1, 38⟩,
  ⟨460, false, 461, false, 26, 1, 33⟩,
  ⟨460, true, 463, false, 24, 3, 31⟩]
theorem carryCases04_09_verified : carryCases04_09.all verified = true := by decide

def carryCases04_10 : List Case := [
  ⟨461, false, 462, false, 27, 1, 34⟩,
  ⟨463, false, 464, false, 27, 1, 34⟩,
  ⟨463, true, 467, false, 26, 2, 33⟩,
  ⟨464, false, 465, false, 28, 1, 35⟩,
  ⟨465, false, 466, false, 29, 1, 36⟩,
  ⟨467, false, 468, false, 27, 1, 34⟩,
  ⟨467, true, 473, false, 25, 3, 32⟩,
  ⟨468, false, 469, false, 29, 1, 36⟩]
theorem carryCases04_10_verified : carryCases04_10.all verified = true := by decide

def carryCases04_11 : List Case := [
  ⟨469, false, 470, false, 30, 1, 37⟩,
  ⟨469, true, 472, false, 28, 3, 35⟩,
  ⟨470, false, 471, false, 31, 1, 38⟩,
  ⟨473, false, 474, false, 26, 1, 33⟩,
  ⟨473, true, 477, false, 23, 4, 30⟩,
  ⟨474, false, 475, false, 27, 1, 34⟩,
  ⟨475, false, 476, false, 28, 1, 35⟩,
  ⟨477, false, 478, false, 20, 4, 27⟩]
theorem carryCases04_11_verified : carryCases04_11.all verified = true := by decide

def carryCases04 : List Case := carryCases04_00 ++ carryCases04_01 ++ carryCases04_02 ++ carryCases04_03 ++ carryCases04_04 ++ carryCases04_05 ++ carryCases04_06 ++ carryCases04_07 ++ carryCases04_08 ++ carryCases04_09 ++ carryCases04_10 ++ carryCases04_11
theorem carryCases04_verified : carryCases04.all verified = true := by
  simp only [carryCases04, List.all_append, carryCases04_00_verified, carryCases04_01_verified, carryCases04_02_verified, carryCases04_03_verified, carryCases04_04_verified, carryCases04_05_verified, carryCases04_06_verified, carryCases04_07_verified, carryCases04_08_verified, carryCases04_09_verified, carryCases04_10_verified, carryCases04_11_verified, Bool.and_self]
theorem carryCases04_covered : carryCases04.map (fun c => key c.pc c.zero) = keysBetween 760 196 := by decide
theorem carryCases04_count : carryCases04.length = 96 := by decide
end NF192.Carry
