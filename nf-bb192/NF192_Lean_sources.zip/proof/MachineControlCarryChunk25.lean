module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases25_00 : List Case := [
  ⟨2398, false, 2399, false, 22, 4, 29⟩,
  ⟨2399, false, 2400, false, 27, 1, 34⟩,
  ⟨2399, true, 2402, false, 26, 2, 33⟩,
  ⟨2400, false, 2401, false, 28, 1, 35⟩,
  ⟨2402, false, 2403, false, 28, 1, 35⟩,
  ⟨2402, true, 2405, false, 27, 2, 34⟩,
  ⟨2403, false, 2404, false, 29, 1, 36⟩,
  ⟨2405, false, 2406, false, 30, 1, 37⟩]
theorem carryCases25_00_verified : carryCases25_00.all verified = true := by decide

def carryCases25_01 : List Case := [
  ⟨2405, true, 2409, false, 29, 2, 36⟩,
  ⟨2406, false, 2407, false, 31, 1, 38⟩,
  ⟨2407, false, 2408, false, 32, 1, 39⟩,
  ⟨2409, false, 2410, false, 30, 1, 37⟩,
  ⟨2409, true, 2415, false, 28, 3, 35⟩,
  ⟨2410, false, 2411, false, 32, 1, 39⟩,
  ⟨2411, false, 2412, false, 33, 1, 40⟩,
  ⟨2411, true, 2414, false, 31, 3, 38⟩]
theorem carryCases25_01_verified : carryCases25_01.all verified = true := by decide

def carryCases25_02 : List Case := [
  ⟨2412, false, 2413, false, 34, 1, 41⟩,
  ⟨2415, false, 2416, false, 29, 1, 36⟩,
  ⟨2415, true, 2418, false, 25, 5, 32⟩,
  ⟨2416, false, 2417, false, 30, 1, 37⟩,
  ⟨2418, false, 2419, false, 30, 1, 37⟩,
  ⟨2418, true, 2421, false, 29, 2, 36⟩,
  ⟨2419, false, 2420, false, 31, 1, 38⟩,
  ⟨2421, false, 2422, false, 31, 1, 38⟩]
theorem carryCases25_02_verified : carryCases25_02.all verified = true := by decide

def carryCases25_03 : List Case := [
  ⟨2421, true, 2424, false, 30, 2, 37⟩,
  ⟨2422, false, 2423, false, 32, 1, 39⟩,
  ⟨2424, false, 2425, false, 33, 1, 40⟩,
  ⟨2424, true, 2428, false, 32, 2, 39⟩,
  ⟨2425, false, 2426, false, 34, 1, 41⟩,
  ⟨2426, false, 2427, false, 35, 1, 42⟩,
  ⟨2428, false, 2429, false, 33, 1, 40⟩,
  ⟨2428, true, 2434, false, 31, 3, 38⟩]
theorem carryCases25_03_verified : carryCases25_03.all verified = true := by decide

def carryCases25_04 : List Case := [
  ⟨2429, false, 2430, false, 35, 1, 42⟩,
  ⟨2430, false, 2431, false, 36, 1, 43⟩,
  ⟨2430, true, 2433, false, 34, 3, 41⟩,
  ⟨2431, false, 2432, false, 37, 1, 44⟩,
  ⟨2434, false, 2435, false, 32, 1, 39⟩,
  ⟨2434, true, 2437, false, 28, 5, 35⟩,
  ⟨2435, false, 2436, false, 33, 1, 40⟩,
  ⟨2437, false, 2438, false, 30, 1, 37⟩]
theorem carryCases25_04_verified : carryCases25_04.all verified = true := by decide

def carryCases25_05 : List Case := [
  ⟨2437, true, 2441, false, 29, 2, 36⟩,
  ⟨2438, false, 2439, false, 31, 1, 38⟩,
  ⟨2439, false, 2440, false, 32, 1, 39⟩,
  ⟨2441, false, 2442, false, 30, 1, 37⟩,
  ⟨2441, true, 2444, false, 27, 4, 34⟩,
  ⟨2442, false, 2443, false, 31, 1, 38⟩,
  ⟨2444, false, 2445, false, 31, 1, 38⟩,
  ⟨2444, true, 2452, false, 30, 2, 37⟩]
theorem carryCases25_05_verified : carryCases25_05.all verified = true := by decide

def carryCases25_06 : List Case := [
  ⟨2445, false, 2446, false, 33, 1, 40⟩,
  ⟨2446, false, 2447, false, 35, 1, 42⟩,
  ⟨2446, true, 2448, false, 34, 2, 41⟩,
  ⟨2448, false, 2449, false, 35, 1, 42⟩,
  ⟨2448, true, 2451, false, 32, 4, 39⟩,
  ⟨2449, false, 2450, false, 36, 1, 43⟩,
  ⟨2452, false, 2453, false, 31, 1, 38⟩,
  ⟨2452, true, 2455, false, 29, 3, 36⟩]
theorem carryCases25_06_verified : carryCases25_06.all verified = true := by decide

def carryCases25_07 : List Case := [
  ⟨2453, false, 2454, false, 32, 1, 39⟩,
  ⟨2455, false, 2456, false, 32, 1, 39⟩,
  ⟨2455, true, 2459, false, 31, 2, 38⟩,
  ⟨2456, false, 2457, false, 33, 1, 40⟩,
  ⟨2457, false, 2458, false, 34, 1, 41⟩,
  ⟨2459, false, 2460, false, 32, 1, 39⟩,
  ⟨2459, true, 2465, false, 30, 3, 37⟩,
  ⟨2460, false, 2461, false, 34, 1, 41⟩]
theorem carryCases25_07_verified : carryCases25_07.all verified = true := by decide

def carryCases25_08 : List Case := [
  ⟨2461, false, 2462, false, 35, 1, 42⟩,
  ⟨2461, true, 2464, false, 33, 3, 40⟩,
  ⟨2462, false, 2463, false, 36, 1, 43⟩,
  ⟨2465, false, 2466, false, 31, 1, 38⟩,
  ⟨2465, true, 2469, false, 28, 4, 35⟩,
  ⟨2466, false, 2467, false, 32, 1, 39⟩,
  ⟨2467, false, 2468, false, 33, 1, 40⟩,
  ⟨2469, false, 2470, false, 26, 3, 33⟩]
theorem carryCases25_08_verified : carryCases25_08.all verified = true := by decide

def carryCases25_09 : List Case := [
  ⟨2470, false, 2471, false, 31, 1, 38⟩,
  ⟨2470, true, 2473, false, 30, 2, 37⟩,
  ⟨2471, false, 2472, false, 32, 1, 39⟩,
  ⟨2473, false, 2474, false, 32, 1, 39⟩,
  ⟨2473, true, 2476, false, 31, 2, 38⟩,
  ⟨2474, false, 2475, false, 33, 1, 40⟩,
  ⟨2476, false, 2477, false, 34, 1, 41⟩,
  ⟨2476, true, 2480, false, 33, 2, 40⟩]
theorem carryCases25_09_verified : carryCases25_09.all verified = true := by decide

def carryCases25_10 : List Case := [
  ⟨2477, false, 2478, false, 35, 1, 42⟩,
  ⟨2478, false, 2479, false, 36, 1, 43⟩,
  ⟨2480, false, 2481, false, 34, 1, 41⟩,
  ⟨2480, true, 2486, false, 32, 3, 39⟩,
  ⟨2481, false, 2482, false, 36, 1, 43⟩,
  ⟨2482, false, 2483, false, 37, 1, 44⟩,
  ⟨2482, true, 2485, false, 35, 3, 42⟩,
  ⟨2483, false, 2484, false, 38, 1, 45⟩]
theorem carryCases25_10_verified : carryCases25_10.all verified = true := by decide

def carryCases25_11 : List Case := [
  ⟨2486, false, 2487, false, 33, 1, 40⟩,
  ⟨2486, true, 2489, false, 29, 5, 36⟩,
  ⟨2487, false, 2488, false, 34, 1, 41⟩,
  ⟨2489, false, 2490, false, 30, 1, 37⟩,
  ⟨2489, true, 2493, false, 28, 3, 35⟩,
  ⟨2490, false, 2491, false, 31, 1, 38⟩,
  ⟨2491, false, 2492, false, 32, 1, 39⟩,
  ⟨2493, false, 2494, false, 29, 1, 36⟩]
theorem carryCases25_11_verified : carryCases25_11.all verified = true := by decide

def carryCases25 : List Case := carryCases25_00 ++ carryCases25_01 ++ carryCases25_02 ++ carryCases25_03 ++ carryCases25_04 ++ carryCases25_05 ++ carryCases25_06 ++ carryCases25_07 ++ carryCases25_08 ++ carryCases25_09 ++ carryCases25_10 ++ carryCases25_11
theorem carryCases25_verified : carryCases25.all verified = true := by
  simp only [carryCases25, List.all_append, carryCases25_00_verified, carryCases25_01_verified, carryCases25_02_verified, carryCases25_03_verified, carryCases25_04_verified, carryCases25_05_verified, carryCases25_06_verified, carryCases25_07_verified, carryCases25_08_verified, carryCases25_09_verified, carryCases25_10_verified, carryCases25_11_verified, Bool.and_self]
theorem carryCases25_covered : carryCases25.map (fun c => key c.pc c.zero) = keysBetween 4796 191 := by decide
theorem carryCases25_count : carryCases25.length = 96 := by decide
end NF192.Carry
