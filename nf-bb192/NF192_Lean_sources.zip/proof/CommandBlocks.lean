module
public import NumericalOuter
public import MachineCountdown
public import ProofCommands

@[expose] public section

/-! Arithmetic/stack blocks outside the axiom emitter. The checks bind every
instruction of the individual reusable blocks to the decoded, literal 192-state
source layout. Each semantic result below quantifies over unbounded registers. -/

set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace NF192.CommandBlocks

open Emitter Emitter.Registers Numerical

private def embeddedCheck (code : Code) (base finish : Nat) : Bool :=
  matchesCode base (compile code base finish [] [])

private theorem block_run {code : Code} {s t : Registers} {base finish : Nat}
    (hc : embeddedCheck code base finish = true) (he : Eval code s .normal t) :
    Reaches actual ⟨base,s⟩ (some ⟨finish,t⟩) :=
  he.compiled _ _ _ _ _ (embedded_of_matches code base finish hc)

/-- The source actually runs between these two configurations in positive time. -/
abbrev Visits := Emitter.Moves

private theorem toVisits {s t : Config} (h : Reaches actual s (some t)) :
    Visits (liftConfig s) (liftConfig t) := by
  obtain ⟨n,hn,hr⟩ := h
  exact ⟨n,hn,actual_run n hr⟩

/-- Raw source frame, including the counter, arbitrary residual input and all
nine physical register values lifted to the source-step representation. -/
def frame (pc n t sp c d h a b input : Nat) : Source.Config :=
  Source.Config.active pc (liftRegisters (mk9 n t sp c d h a b input))

private theorem push4_checked : embeddedCheck Literal.seq166 3017 3043 = true := by decide
private theorem imp_checked : embeddedCheck Literal.seq119 3043 3068 = true := by decide
private theorem move16_checked : embeddedCheck Literal.seq216 3068 3071 = true := by decide
private theorem move65_checked : embeddedCheck Literal.seq207 3075 3078 = true := by decide
private theorem copy4_checked : embeddedCheck Literal.seq167 3080 3087 = true := by decide
private theorem clear5_checked : embeddedCheck Literal.seq199 3087 0 = true := by decide
private theorem push5_checked : embeddedCheck Literal.seq121 2970 2996 = true := by decide
private theorem unpair2_checked : embeddedCheck Literal.seq160 3002 3013 = true := by decide
private theorem pop5_checked : embeddedCheck Literal.seq207 3013 3016 = true := by decide

private theorem actual_2969 : actual 2969 = .dec 4 2996 2970 :=
  by decide
private theorem actual_3016 : actual 3016 = .jump 0 := by decide
private theorem actual_3071 : actual 3071 = .dec 6 3078 3072 := by decide
private theorem actual_3072 : actual 3072 = .dec 5 3074 3073 := by decide
private theorem actual_3073 : actual 3073 = .jump 3071 := by decide
private theorem actual_3074 : actual 3074 = .inc 5 3075 := by decide
private theorem actual_3078 : actual 3078 = .dec 5 3080 3079 := by decide
private theorem actual_3079 : actual 3079 = .jump 3087 := by decide

/-- This prefix constructs the *numerical implication* from TOP and parameter,
restores the original stack, and moves the implication into register 6. -/
private theorem mp_prefix (n t sp c d h input : Nat) :
    Reaches actual ⟨3017,mk9 n t sp c d h 0 0 input⟩
      (some ⟨3071,mk9 n 0 sp c d h (imp t d) 0 input⟩) := by
  have h1 := block_run push4_checked (seq166_normal n t sp c d h input)
  have h2 := block_run imp_checked (seq119_normal n d (pair t sp) c d h input)
  simp only [Cantor.unpair_pair] at h2
  have h3 := block_run move16_checked (seq216_eval n (imp t d) sp c d h 0 0 input)
  simp only [Nat.zero_add] at h3
  exact (h1.trans h2).trans h3

/-- Absolute difference defined by stripping one unit from both registers. -/
def residual : Nat → Nat → Nat
  | 0, y => y
  | x+1, 0 => x+1
  | x+1, y+1 => residual x y

private theorem residual_zero (a b : Nat) : residual a b = 0 ↔ a = b := by
  induction a generalizing b with
  | zero => simp [residual, eq_comm]
  | succ a ih =>
    cases b with
    | zero => simp [residual]
    | succ b => simp only [residual, Nat.succ.injEq, ih]

/-- The 7-slot comparator runs on all two-register inputs, leaving their
absolute difference in CACHE and clearing scratch 6. -/
private theorem compare_all (n sp c d input a b : Nat) :
    Reaches actual ⟨3071,mk9 n 0 sp c d b a 0 input⟩
      (some ⟨3078,mk9 n 0 sp c d (residual a b) 0 0 input⟩) := by
  induction a generalizing b with
  | zero =>
    apply Reaches.one
    simp [step, actual_3071, residual]
  | succ a ih =>
    have first : Reaches actual ⟨3071,mk9 n 0 sp c d b (a+1) 0 input⟩
        (some ⟨3072,mk9 n 0 sp c d b a 0 input⟩) := by
      apply Reaches.one
      simp [step, actual_3071]
    cases b with
    | zero =>
      have second : Reaches actual ⟨3072,mk9 n 0 sp c d 0 a 0 input⟩
          (some ⟨3074,mk9 n 0 sp c d 0 a 0 input⟩) := by
        apply Reaches.one
        simp [step,actual_3072]
      have third : Reaches actual ⟨3074,mk9 n 0 sp c d 0 a 0 input⟩
          (some ⟨3075,mk9 n 0 sp c d 1 a 0 input⟩) := by
        apply Reaches.one
        simp [step,actual_3074,Registers.add]
      have fourth := block_run move65_checked (seq207_eval n 0 sp c d 1 a 0 input)
      simpa only [residual,Nat.add_comm 1 a] using (((first.trans second).trans third).trans fourth)
    | succ b =>
      have second : Reaches actual ⟨3072,mk9 n 0 sp c d (b+1) a 0 input⟩
          (some ⟨3073,mk9 n 0 sp c d b a 0 input⟩) := by
        apply Reaches.one
        simp [step,actual_3072]
      have third : Reaches actual ⟨3073,mk9 n 0 sp c d b a 0 input⟩
          (some ⟨3071,mk9 n 0 sp c d b a 0 input⟩) := by
        apply Reaches.one
        simp [step,actual_3073]
      exact ((first.trans second).trans third).trans (ih b)

private theorem mp_suffix (n sp c d input h : Nat) :
    Reaches actual ⟨3078,mk9 n 0 sp c d h 0 0 input⟩
      (some ⟨0,mk9 n (if h = 0 then d else 0) sp c d 0 0 0 input⟩) := by
  cases h with
  | zero =>
    have a : Reaches actual ⟨3078,mk9 n 0 sp c d 0 0 0 input⟩
        (some ⟨3080,mk9 n 0 sp c d 0 0 0 input⟩) := by
      apply Reaches.one
      simp [step, actual_3078]
    have b : Eval Literal.seq167 (mk9 n 0 sp c d 0 0 0 input) .normal
        (mk9 n d sp c d 0 0 0 input) := by
      have h1 := seq198_eval n 0 sp c d 0 0 0 input
      have h2 := seq205_eval n d sp c 0 0 d 0 input
      simp only [Nat.zero_add] at h1 h2
      exact Eval.seq_normal h1 h2
    exact (a.trans (block_run copy4_checked b)).trans
      (block_run clear5_checked (seq199_eval n d sp c d 0 0 0 input))
  | succ k =>
    have a : Reaches actual ⟨3078,mk9 n 0 sp c d (k+1) 0 0 input⟩
        (some ⟨3079,mk9 n 0 sp c d k 0 0 input⟩) := by
      apply Reaches.one
      simp [step,actual_3078]
    have b : Reaches actual ⟨3079,mk9 n 0 sp c d k 0 0 input⟩
        (some ⟨3087,mk9 n 0 sp c d k 0 0 input⟩) := by
      apply Reaches.one
      simp [step,actual_3079]
    exact (a.trans b).trans (block_run clear5_checked (seq199_eval n 0 sp c d k 0 0 input))

/-- Literal MP (ordinal 3017) preserves the parameter on both branches,
clears cache, and succeeds exactly on the encoded implication. -/
theorem mp_correct (n t sp c d h input : Nat) :
    Visits (frame 3017 n t sp c d h 0 0 input)
      (frame 0 n (if h = imp t d then d else 0) sp c d 0 0 0 input) := by
  have h₁ := mp_prefix n t sp c d h input
  have h₂ := compare_all n sp c d input (imp t d) h
  have h₃ := mp_suffix n sp c d input (residual (imp t d) h)
  have k := toVisits ((h₁.trans h₂).trans h₃)
  rw [show (if residual (imp t d) h = 0 then d else 0) =
      (if h = imp t d then d else 0) by
        by_cases e : h = imp t d
        · simp only [ite_eq_left e, ite_eq_left ((residual_zero _ _).2 e.symm)]
        · simp only [ite_eq_right e, ite_eq_right (fun hz => e ((residual_zero _ _).1 hz).symm)]] at k
  exact k

private theorem pop_run (n t sp c d input : Nat) :
    Reaches actual ⟨3002,mk9 n t sp c d 0 0 0 input⟩
      (some ⟨0,mk9 n t (Cantor.unpair sp).2 c d (Cantor.unpair sp).1 0 0 input⟩) := by
  have first := block_run unpair2_checked (seq160_normal n t sp c d 0 input)
  have second := block_run pop5_checked
    (seq207_eval n t (Cantor.unpair sp).2 c d 0 (Cantor.unpair sp).1 0 input)
  simp only [Nat.zero_add] at second
  apply (first.trans second).trans
  apply Reaches.one
  simp [step,actual_3016]

private theorem frame_goalConfig (pc n t sp c d h h' input : Nat) :
    Source.goalConfig pc h' (liftRegisters (mk9 n t sp c d h 0 0 input)) =
      frame pc n t sp c d h' 0 0 input := by
  unfold Source.goalConfig frame
  rw [show Source.setReg (liftRegisters (mk9 n t sp c d h 0 0 input)) 5 h' =
      liftRegisters ((mk9 n t sp c d h 0 0 input).set 5 h') from
        liftRegisters_set (mk9 n t sp c d h 0 0 input) 5 h']
  rw [mk9_set_5]

/-- NIP tests the incoming cache and, on survival, pops even an empty
Cantor stack according to its zero convention. -/
theorem nip_correct (n t sp c d h input : Nat) :
    Visits (frame 2996 n t sp c d h 0 0 input)
      (if h = goal then Source.Config.halted
       else frame 0 n t (Cantor.unpair sp).2 c d (Cantor.unpair sp).1 0 0 input) := by
  have count := Source.countdown_correct h (liftRegisters (mk9 n t sp c d h 0 0 input))
  rw [frame_goalConfig, frame_goalConfig] at count
  have pos : 0 < Source.countdownDuration h := by
    cases h with | zero => decide | succ h =>
      cases h with | zero => decide | succ h =>
        cases h with | zero => decide | succ h =>
          cases h <;> simp [Source.countdownDuration] <;> omega
  by_cases hit : h = goal
  · rw [ite_eq_left hit]
    exact ⟨_,pos,by simpa only [ite_eq_left (hit.trans goal_is_three)] using count⟩
  · rw [ite_eq_right hit]
    have hn : h ≠ 3 := fun eq => hit (eq.trans goal_is_three.symm)
    have k : Visits (frame 2996 n t sp c d h 0 0 input) (frame 3002 n t sp c d 0 0 0 input) :=
      ⟨_,pos,by simpa only [ite_eq_right hn] using count⟩
    exact k.trans (toVisits (pop_run n t sp c d input))

/-- MODE has precisely the deterministic NIP/SWAP semantics at *every*
natural parameter, including proposed words with mode values greater than one. -/
theorem mode_correct (n t sp c param cache input : Nat) :
    Visits (frame 2969 n t sp c param cache 0 0 input)
      (if cache = goal then Source.Config.halted else
       match param with
       | 0 => frame 0 n t (Cantor.unpair sp).2 c 0 (Cantor.unpair sp).1 0 0 input
       | p+1 => frame 0 n cache sp c p t 0 0 input) := by
  cases param with
  | zero =>
    have entry : Reaches actual ⟨2969,mk9 n t sp c 0 cache 0 0 input⟩
        (some ⟨2996,mk9 n t sp c 0 cache 0 0 input⟩) := by
      apply Reaches.one
      simp [step,actual_2969]
    exact (toVisits entry).trans (nip_correct n t sp c 0 cache input)
  | succ p =>
    have entry : Reaches actual ⟨2969,mk9 n t sp c (p+1) cache 0 0 input⟩
        (some ⟨2970,mk9 n t sp c p cache 0 0 input⟩) := by
      apply Reaches.one
      simp [step,actual_2969]
    have push := block_run push5_checked (seq121_normal n t sp c p cache input)
    have clear := nip_correct n cache (pair t sp) c p cache input
    rw [Cantor.unpair_pair] at clear
    exact (toVisits (entry.trans push)).trans clear

end NF192.CommandBlocks

#print axioms NF192.CommandBlocks.mp_correct
#print axioms NF192.CommandBlocks.mode_correct
