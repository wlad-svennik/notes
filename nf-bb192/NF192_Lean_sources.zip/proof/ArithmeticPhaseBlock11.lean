module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block2816 : checkRange 2816 32 = true := by decide +kernel
theorem block2848 : checkRange 2848 32 = true := by decide +kernel
theorem block2880 : checkRange 2880 32 = true := by decide +kernel
theorem block2912 : checkRange 2912 32 = true := by decide +kernel
theorem block2944 : checkRange 2944 32 = true := by decide +kernel
theorem block2976 : checkRange 2976 32 = true := by decide +kernel
theorem block3008 : checkRange 3008 32 = true := by decide +kernel
theorem block3040 : checkRange 3040 32 = true := by decide +kernel

end NF192.Phase
