module
public meta import Lean
public import Init
@[expose] public section

/-! File literals with a fragment boundary suitable for kernel reduction.
Every byte and delimiter is preserved. Joining the fragments is checked
against the unmodified input before the literal expression is returned. -/
namespace NF192.Input
open Lean Elab Term

elab "input_fragments% " path:str sep:str : term => do
  let ctx ← readThe Lean.Core.Context
  let source := System.FilePath.mk ctx.fileName
  let parent := source.parent.getD (System.FilePath.mk ".")
  let text ← IO.FS.readFile (parent / path.getString)
  let split := (text.splitOn sep.getString).toArray
  let fragments := split.mapIdx fun n x => if n+1 = split.size then x else x ++ sep.getString
  if String.join fragments.toList != text then
    throwError "input literal did not preserve the original bytes"
  let blocks := (List.range ((fragments.size+31)/32)).map fun n => (fragments.extract (32*n) (32*n+32)).toList
  return toExpr blocks

end NF192.Input
