module
public import MachineSource

@[expose] public section

namespace NF192.Source
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def leavesTile : Bool :=
  lowKey (siteAt 0) == 2^31 &&
  highKey (siteAt (siteCount-1)) == 2^32 &&
  (List.range siteCount).all fun i =>
    let s := siteAt i
    s.address > 0 && s.depth == Nat.log2 s.address && s.depth ≤ 31 &&
      (i+1 == siteCount || highKey s == lowKey (siteAt (i+1)))

theorem complete_ordered_prefix_code : leavesTile = true := by decide


theorem unique_conditional_halt :
    (List.range siteCount).filter (fun i =>
      let s := siteAt i
      s.op == Primitive.dec && s.address % 2 == 1) = [2999] := by decide

#print axioms unique_conditional_halt
end NF192.Source
