module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block1024 : checkRange 1024 32 = true := by decide +kernel
theorem block1056 : checkRange 1056 32 = true := by decide +kernel
theorem block1088 : checkRange 1088 32 = true := by decide +kernel
theorem block1120 : checkRange 1120 32 = true := by decide +kernel
theorem block1152 : checkRange 1152 32 = true := by decide +kernel
theorem block1184 : checkRange 1184 32 = true := by decide +kernel
theorem block1216 : checkRange 1216 32 = true := by decide +kernel
theorem block1248 : checkRange 1248 32 = true := by decide +kernel

end NF192.Phase
