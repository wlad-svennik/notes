module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases28_00 : List Case := [
  ⟨2686, false, 2687, false, 30, 1, 37⟩,
  ⟨2686, true, 2689, false, 28, 3, 35⟩,
  ⟨2687, false, 2688, false, 31, 1, 38⟩,
  ⟨2689, false, 2690, false, 31, 1, 38⟩,
  ⟨2689, true, 2693, false, 30, 2, 37⟩,
  ⟨2690, false, 2691, false, 32, 1, 39⟩,
  ⟨2691, false, 2692, false, 33, 1, 40⟩,
  ⟨2693, false, 2694, false, 31, 1, 38⟩]
theorem carryCases28_00_verified : carryCases28_00.all verified = true := by decide

def carryCases28_01 : List Case := [
  ⟨2693, true, 2699, false, 29, 3, 36⟩,
  ⟨2694, false, 2695, false, 33, 1, 40⟩,
  ⟨2695, false, 2696, false, 34, 1, 41⟩,
  ⟨2695, true, 2698, false, 32, 3, 39⟩,
  ⟨2696, false, 2697, false, 35, 1, 42⟩,
  ⟨2699, false, 2700, false, 30, 1, 37⟩,
  ⟨2699, true, 2703, false, 27, 4, 34⟩,
  ⟨2700, false, 2701, false, 31, 1, 38⟩]
theorem carryCases28_01_verified : carryCases28_01.all verified = true := by decide

def carryCases28_02 : List Case := [
  ⟨2701, false, 2702, false, 32, 1, 39⟩,
  ⟨2703, false, 2704, false, 21, 7, 28⟩,
  ⟨2704, false, 2705, false, 26, 1, 33⟩,
  ⟨2704, true, 2707, false, 25, 2, 32⟩,
  ⟨2705, false, 2706, false, 27, 1, 34⟩,
  ⟨2707, false, 2708, false, 27, 1, 34⟩,
  ⟨2707, true, 2710, false, 26, 2, 33⟩,
  ⟨2708, false, 2709, false, 28, 1, 35⟩]
theorem carryCases28_02_verified : carryCases28_02.all verified = true := by decide

def carryCases28_03 : List Case := [
  ⟨2710, false, 2711, false, 29, 1, 36⟩,
  ⟨2710, true, 2714, false, 28, 2, 35⟩,
  ⟨2711, false, 2712, false, 30, 1, 37⟩,
  ⟨2712, false, 2713, false, 31, 1, 38⟩,
  ⟨2714, false, 2715, false, 29, 1, 36⟩,
  ⟨2714, true, 2720, false, 27, 3, 34⟩,
  ⟨2715, false, 2716, false, 31, 1, 38⟩,
  ⟨2716, false, 2717, false, 32, 1, 39⟩]
theorem carryCases28_03_verified : carryCases28_03.all verified = true := by decide

def carryCases28_04 : List Case := [
  ⟨2716, true, 2719, false, 30, 3, 37⟩,
  ⟨2717, false, 2718, false, 33, 1, 40⟩,
  ⟨2720, false, 2721, false, 28, 1, 35⟩,
  ⟨2720, true, 2723, false, 24, 5, 31⟩,
  ⟨2721, false, 2722, false, 29, 1, 36⟩,
  ⟨2723, false, 2724, false, 26, 1, 33⟩,
  ⟨2723, true, 2727, false, 25, 2, 32⟩,
  ⟨2724, false, 2725, false, 27, 1, 34⟩]
theorem carryCases28_04_verified : carryCases28_04.all verified = true := by decide

def carryCases28_05 : List Case := [
  ⟨2725, false, 2726, false, 28, 1, 35⟩,
  ⟨2727, false, 2728, false, 26, 1, 33⟩,
  ⟨2727, true, 2730, false, 23, 4, 30⟩,
  ⟨2728, false, 2729, false, 27, 1, 34⟩,
  ⟨2730, false, 2731, false, 28, 1, 35⟩,
  ⟨2730, true, 2733, false, 27, 2, 34⟩,
  ⟨2731, false, 2732, false, 29, 1, 36⟩,
  ⟨2733, false, 2734, false, 29, 1, 36⟩]
theorem carryCases28_05_verified : carryCases28_05.all verified = true := by decide

def carryCases28_06 : List Case := [
  ⟨2733, true, 2736, false, 28, 2, 35⟩,
  ⟨2734, false, 2735, false, 30, 1, 37⟩,
  ⟨2736, false, 2737, false, 31, 1, 38⟩,
  ⟨2736, true, 2740, false, 30, 2, 37⟩,
  ⟨2737, false, 2738, false, 32, 1, 39⟩,
  ⟨2738, false, 2739, false, 33, 1, 40⟩,
  ⟨2740, false, 2741, false, 31, 1, 38⟩,
  ⟨2740, true, 2746, false, 29, 3, 36⟩]
theorem carryCases28_06_verified : carryCases28_06.all verified = true := by decide

def carryCases28_07 : List Case := [
  ⟨2741, false, 2742, false, 33, 1, 40⟩,
  ⟨2742, false, 2743, false, 34, 1, 41⟩,
  ⟨2742, true, 2745, false, 32, 3, 39⟩,
  ⟨2743, false, 2744, false, 35, 1, 42⟩,
  ⟨2746, false, 2747, false, 30, 1, 37⟩,
  ⟨2746, true, 2749, false, 26, 5, 33⟩,
  ⟨2747, false, 2748, false, 31, 1, 38⟩,
  ⟨2749, false, 2750, false, 28, 1, 35⟩]
theorem carryCases28_07_verified : carryCases28_07.all verified = true := by decide

def carryCases28_08 : List Case := [
  ⟨2749, true, 2753, false, 27, 2, 34⟩,
  ⟨2750, false, 2751, false, 29, 1, 36⟩,
  ⟨2751, false, 2752, false, 30, 1, 37⟩,
  ⟨2753, false, 2754, false, 28, 1, 35⟩,
  ⟨2753, true, 2756, false, 25, 4, 32⟩,
  ⟨2754, false, 2755, false, 29, 1, 36⟩,
  ⟨2756, false, 2757, false, 30, 1, 37⟩,
  ⟨2756, true, 2759, false, 29, 2, 36⟩]
theorem carryCases28_08_verified : carryCases28_08.all verified = true := by decide

def carryCases28_09 : List Case := [
  ⟨2757, false, 2758, false, 31, 1, 38⟩,
  ⟨2759, false, 2760, false, 31, 1, 38⟩,
  ⟨2759, true, 2762, false, 30, 2, 37⟩,
  ⟨2760, false, 2761, false, 32, 1, 39⟩,
  ⟨2762, false, 2763, false, 33, 1, 40⟩,
  ⟨2762, true, 2766, false, 32, 2, 39⟩,
  ⟨2763, false, 2764, false, 34, 1, 41⟩,
  ⟨2764, false, 2765, false, 35, 1, 42⟩]
theorem carryCases28_09_verified : carryCases28_09.all verified = true := by decide

def carryCases28_10 : List Case := [
  ⟨2766, false, 2767, false, 33, 1, 40⟩,
  ⟨2766, true, 2772, false, 31, 3, 38⟩,
  ⟨2767, false, 2768, false, 35, 1, 42⟩,
  ⟨2768, false, 2769, false, 36, 1, 43⟩,
  ⟨2768, true, 2771, false, 34, 3, 41⟩,
  ⟨2769, false, 2770, false, 37, 1, 44⟩,
  ⟨2772, false, 2773, false, 32, 1, 39⟩,
  ⟨2772, true, 2775, false, 28, 5, 35⟩]
theorem carryCases28_10_verified : carryCases28_10.all verified = true := by decide

def carryCases28_11 : List Case := [
  ⟨2773, false, 2774, false, 33, 1, 40⟩,
  ⟨2775, false, 2776, false, 29, 1, 36⟩,
  ⟨2775, true, 2779, false, 27, 3, 34⟩,
  ⟨2776, false, 2777, false, 30, 1, 37⟩,
  ⟨2777, false, 2778, false, 31, 1, 38⟩,
  ⟨2779, false, 2780, false, 28, 1, 35⟩,
  ⟨2779, true, 2782, false, 26, 3, 33⟩,
  ⟨2780, false, 2781, false, 29, 1, 36⟩]
theorem carryCases28_11_verified : carryCases28_11.all verified = true := by decide

def carryCases28 : List Case := carryCases28_00 ++ carryCases28_01 ++ carryCases28_02 ++ carryCases28_03 ++ carryCases28_04 ++ carryCases28_05 ++ carryCases28_06 ++ carryCases28_07 ++ carryCases28_08 ++ carryCases28_09 ++ carryCases28_10 ++ carryCases28_11
theorem carryCases28_verified : carryCases28.all verified = true := by
  simp only [carryCases28, List.all_append, carryCases28_00_verified, carryCases28_01_verified, carryCases28_02_verified, carryCases28_03_verified, carryCases28_04_verified, carryCases28_05_verified, carryCases28_06_verified, carryCases28_07_verified, carryCases28_08_verified, carryCases28_09_verified, carryCases28_10_verified, carryCases28_11_verified, Bool.and_self]
theorem carryCases28_covered : carryCases28.map (fun c => key c.pc c.zero) = keysBetween 5372 192 := by decide
theorem carryCases28_count : carryCases28.length = 96 := by decide
end NF192.Carry
