module
public import MachineInputData
@[expose] public section
namespace NF192.Input
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem rowBlock96 : computedBlock 96 = literalBlock 96 := by decide
end NF192.Input
