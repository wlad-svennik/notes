module
public import MachineFrameCarry
public import MachineDecrementWords
public import MachineIngress

@[expose] public section

namespace NF192.Frame

open NF210 NF210.TM NF192.KernelRightShift
set_option maxHeartbeats 0

private theorem exec_to_carry (f : Layout) (r : Fin 9) (zero : Bool) (v : Nat)
    (vals : List Nat) (room : 2 ≤ f.gapWidth) (op : (Source.siteAt f.pc).op = Source.Primitive.dec)
    (value : f.storedAt r.val = v)
    (run : WordRun shiftState (Carry.entryState zero)
      (Decrement.operative f.pc (f.gapWidth-2) v (f.beforeReg r) (f.afterReg r))
      (Decrement.carryInput f.pc zero (f.gapWidth-2) vals) (Decrement.execHead f.pc)
      (Carry.startHead f.pc : Int) (Decrement.executeTime (f.gapWidth-2) (f.beforeReg r))) :
    TM.run Selected.machine (Decrement.executeTime (f.gapWidth-2) (f.beforeReg r))
      (Ingress.execConfig f r 1) = f.carryConfig zero (f.gapWidth-1) vals 1 := by
  have gap : f.gapWidth-2+1 = f.gapWidth-1 := by omega
  have gap' : f.gapWidth-2+2 = f.gapWidth-1+1 := by omega
  have ne : ((1 : Nat) == 0) = false := by decide
  have h := run.exact_run (f.head-9) blankOutside
  simpa only [Ingress.execConfig,Ingress.execState,op,Source.Primitive.dec,Source.Primitive.inc,
    ne,beq_self_eq_true,Bool.false_eq_true,ite_false,Ingress.execWord,Decrement.operative,
    shiftInput,Layout.carryConfig,Decrement.carryInput,Decrement.execHead,gap,gap',
    List.replicate_one,value,List.append_assoc,Int.add_assoc] using h

/-- One actual positive decrement, from canonical decoder entry to the canonical
positive source successor. Every cell of the two-sided output tape is specified. -/
theorem Layout.decrement_positive_step (f : Layout) (r : Fin 9) (k : Nat)
    (inside : f.pc < 3089) (op : (Source.siteAt f.pc).op = Source.Primitive.dec)
    (room : 2 ≤ f.gapWidth) (margin : 31 ≤ f.gap) (reg : r.val = (Source.siteAt f.pc).argument)
    (size : f.stored.size = 9) (value : f.storedAt r.val = k+2) :
    ∃ t, 0 < t ∧ TM.run Selected.machine t f.config =
      (f.afterCarry false 1 (f.stored.setIfInBounds r.val (k+1)) f.spares).config := by
  have active : Phase.enabled (Source.siteAt f.pc) 0 = true := by simp [Phase.enabled,op]
  have selected : Carry.selected f.pc false = true := by simp [Carry.selected,op]
  obtain ⟨entry, pos, ingress⟩ := Ingress.from_canonical f r 1 inside active room reg
  have exec := exec_to_carry f r false (k+2) _ room op value
    (Decrement.positive f.pc (f.gapWidth-2) k (f.beforeReg r) (f.afterReg r))
  have height := f.carry_geometry_pos room
  obtain ⟨exitT, exitRun⟩ := f.carry_restore false (f.gapWidth-1) 1
    (f.stored.setIfInBounds r.val (k+1)) f.spares inside selected (by omega) height 1
  have vals : (f.afterCarry false 1 (f.stored.setIfInBounds r.val (k+1)) f.spares).values =
      f.beforeReg r ++ (k+1) :: f.afterReg r := by
    have moved : (f.afterCarry false 1 (f.stored.setIfInBounds r.val (k+1)) f.spares).values =
        (f.updateStored r (k+1) []).values := by
      unfold Layout.values
      rw [show (f.afterCarry false 1 (f.stored.setIfInBounds r.val (k+1)) f.spares).storedAt =
        (f.updateStored r (k+1) []).storedAt from funext fun _ => rfl]
      simp [Layout.afterCarry,Layout.updateStored]
    exact moved.trans (by simpa using f.updateValues r (k+1) [] size)
  rw [vals] at exitRun
  refine ⟨entry+Decrement.executeTime (f.gapWidth-2) (f.beforeReg r)+exitT,by omega,?_⟩
  rw [TM.run_add,TM.run_add,ingress,exec,exitRun]

/-- When the logical register is zero and the source address is even, the machine
leaves every stored value and spare intact and resumes at the zero successor. -/
theorem Layout.decrement_zero_step (f : Layout) (r : Fin 9)
    (inside : f.pc < 3089) (op : (Source.siteAt f.pc).op = Source.Primitive.dec)
    (room : 2 ≤ f.gapWidth) (margin : 31 ≤ f.gap) (reg : r.val = (Source.siteAt f.pc).argument)
    (value : f.storedAt r.val = 1) (even : (Source.siteAt f.pc).address % 2 = 0) :
    ∃ t, 0 < t ∧ TM.run Selected.machine t f.config =
      (f.afterCarry true 0 f.stored f.spares).config := by
  have active : Phase.enabled (Source.siteAt f.pc) 0 = true := by simp [Phase.enabled,op]
  have selected : Carry.selected f.pc true = true := by simp [Carry.selected,op,even]
  obtain ⟨entry, pos, ingress⟩ := Ingress.from_canonical f r 1 inside active room reg
  have exec := exec_to_carry f r true 1 _ room op value
    (Decrement.zero f.pc (f.gapWidth-2) (f.beforeReg r) (f.afterReg r))
  have height := f.carry_geometry_zero room
  obtain ⟨exitT, exitRun⟩ := f.carry_restore true (f.gapWidth-1) 0
    f.stored f.spares inside selected (by omega) height 1
  have vals : (f.afterCarry true 0 f.stored f.spares).values = f.beforeReg r ++ 1 :: f.afterReg r := by
    change f.values = _
    rw [f.values_split r,value]
  rw [vals] at exitRun
  refine ⟨entry+Decrement.executeTime (f.gapWidth-2) (f.beforeReg r)+exitT,by omega,?_⟩
  rw [TM.run_add,TM.run_add,ingress,exec,exitRun]

#print axioms Layout.decrement_positive_step
#print axioms Layout.decrement_zero_step

end NF192.Frame
