module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases18_00 : List Case := [
  ⟨1726, false, 1727, false, 25, 1, 32⟩,
  ⟨1726, true, 1730, false, 23, 3, 30⟩,
  ⟨1727, false, 1728, false, 26, 1, 33⟩,
  ⟨1728, false, 1729, false, 27, 1, 34⟩,
  ⟨1730, false, 1731, false, 24, 1, 31⟩,
  ⟨1730, true, 1733, false, 22, 3, 29⟩,
  ⟨1731, false, 1732, false, 25, 1, 32⟩,
  ⟨1733, false, 1734, false, 26, 1, 33⟩]
theorem carryCases18_00_verified : carryCases18_00.all verified = true := by decide

def carryCases18_01 : List Case := [
  ⟨1733, true, 1741, false, 25, 2, 32⟩,
  ⟨1734, false, 1735, false, 28, 1, 35⟩,
  ⟨1735, false, 1736, false, 30, 1, 37⟩,
  ⟨1735, true, 1737, false, 29, 2, 36⟩,
  ⟨1737, false, 1738, false, 30, 1, 37⟩,
  ⟨1737, true, 1740, false, 27, 4, 34⟩,
  ⟨1738, false, 1739, false, 31, 1, 38⟩,
  ⟨1741, false, 1742, false, 26, 1, 33⟩]
theorem carryCases18_01_verified : carryCases18_01.all verified = true := by decide

def carryCases18_02 : List Case := [
  ⟨1741, true, 1744, false, 24, 3, 31⟩,
  ⟨1742, false, 1743, false, 27, 1, 34⟩,
  ⟨1744, false, 1745, false, 27, 1, 34⟩,
  ⟨1744, true, 1748, false, 26, 2, 33⟩,
  ⟨1745, false, 1746, false, 28, 1, 35⟩,
  ⟨1746, false, 1747, false, 29, 1, 36⟩,
  ⟨1748, false, 1749, false, 27, 1, 34⟩,
  ⟨1748, true, 1754, false, 25, 3, 32⟩]
theorem carryCases18_02_verified : carryCases18_02.all verified = true := by decide

def carryCases18_03 : List Case := [
  ⟨1749, false, 1750, false, 29, 1, 36⟩,
  ⟨1750, false, 1751, false, 30, 1, 37⟩,
  ⟨1750, true, 1753, false, 28, 3, 35⟩,
  ⟨1751, false, 1752, false, 31, 1, 38⟩,
  ⟨1754, false, 1755, false, 26, 1, 33⟩,
  ⟨1754, true, 1758, false, 23, 4, 30⟩,
  ⟨1755, false, 1756, false, 27, 1, 34⟩,
  ⟨1756, false, 1757, false, 28, 1, 35⟩]
theorem carryCases18_03_verified : carryCases18_03.all verified = true := by decide

def carryCases18_04 : List Case := [
  ⟨1758, false, 1759, false, 19, 5, 26⟩,
  ⟨1759, false, 1760, false, 22, 1, 29⟩,
  ⟨1760, false, 1761, false, 26, 1, 33⟩,
  ⟨1760, true, 1768, false, 25, 2, 32⟩,
  ⟨1761, false, 1762, false, 28, 1, 35⟩,
  ⟨1762, false, 1763, false, 30, 1, 37⟩,
  ⟨1762, true, 1764, false, 29, 2, 36⟩,
  ⟨1764, false, 1765, false, 30, 1, 37⟩]
theorem carryCases18_04_verified : carryCases18_04.all verified = true := by decide

def carryCases18_05 : List Case := [
  ⟨1764, true, 1767, false, 27, 4, 34⟩,
  ⟨1765, false, 1766, false, 31, 1, 38⟩,
  ⟨1768, false, 1769, false, 26, 1, 33⟩,
  ⟨1768, true, 1771, false, 24, 3, 31⟩,
  ⟨1769, false, 1770, false, 27, 1, 34⟩,
  ⟨1771, false, 1772, false, 27, 1, 34⟩,
  ⟨1771, true, 1775, false, 26, 2, 33⟩,
  ⟨1772, false, 1773, false, 28, 1, 35⟩]
theorem carryCases18_05_verified : carryCases18_05.all verified = true := by decide

def carryCases18_06 : List Case := [
  ⟨1773, false, 1774, false, 29, 1, 36⟩,
  ⟨1775, false, 1776, false, 27, 1, 34⟩,
  ⟨1775, true, 1781, false, 25, 3, 32⟩,
  ⟨1776, false, 1777, false, 29, 1, 36⟩,
  ⟨1777, false, 1778, false, 30, 1, 37⟩,
  ⟨1777, true, 1780, false, 28, 3, 35⟩,
  ⟨1778, false, 1779, false, 31, 1, 38⟩,
  ⟨1781, false, 1782, false, 26, 1, 33⟩]
theorem carryCases18_06_verified : carryCases18_06.all verified = true := by decide

def carryCases18_07 : List Case := [
  ⟨1781, true, 1785, false, 23, 4, 30⟩,
  ⟨1782, false, 1783, false, 27, 1, 34⟩,
  ⟨1783, false, 1784, false, 28, 1, 35⟩,
  ⟨1785, false, 1786, false, 21, 3, 28⟩,
  ⟨1786, false, 1787, false, 26, 1, 33⟩,
  ⟨1786, true, 1789, false, 25, 2, 32⟩,
  ⟨1787, false, 1788, false, 27, 1, 34⟩,
  ⟨1789, false, 1790, false, 27, 1, 34⟩]
theorem carryCases18_07_verified : carryCases18_07.all verified = true := by decide

def carryCases18_08 : List Case := [
  ⟨1789, true, 1792, false, 26, 2, 33⟩,
  ⟨1790, false, 1791, false, 28, 1, 35⟩,
  ⟨1792, false, 1793, false, 29, 1, 36⟩,
  ⟨1792, true, 1796, false, 28, 2, 35⟩,
  ⟨1793, false, 1794, false, 30, 1, 37⟩,
  ⟨1794, false, 1795, false, 31, 1, 38⟩,
  ⟨1796, false, 1797, false, 29, 1, 36⟩,
  ⟨1796, true, 1802, false, 27, 3, 34⟩]
theorem carryCases18_08_verified : carryCases18_08.all verified = true := by decide

def carryCases18_09 : List Case := [
  ⟨1797, false, 1798, false, 31, 1, 38⟩,
  ⟨1798, false, 1799, false, 32, 1, 39⟩,
  ⟨1798, true, 1801, false, 30, 3, 37⟩,
  ⟨1799, false, 1800, false, 33, 1, 40⟩,
  ⟨1802, false, 1803, false, 28, 1, 35⟩,
  ⟨1802, true, 1805, false, 24, 5, 31⟩,
  ⟨1803, false, 1804, false, 29, 1, 36⟩,
  ⟨1805, false, 1806, false, 26, 1, 33⟩]
theorem carryCases18_09_verified : carryCases18_09.all verified = true := by decide

def carryCases18_10 : List Case := [
  ⟨1805, true, 1809, false, 25, 2, 32⟩,
  ⟨1806, false, 1807, false, 27, 1, 34⟩,
  ⟨1807, false, 1808, false, 28, 1, 35⟩,
  ⟨1809, false, 1810, false, 26, 1, 33⟩,
  ⟨1809, true, 1812, false, 23, 4, 30⟩,
  ⟨1810, false, 1811, false, 27, 1, 34⟩,
  ⟨1812, false, 1813, false, 28, 1, 35⟩,
  ⟨1812, true, 1815, false, 27, 2, 34⟩]
theorem carryCases18_10_verified : carryCases18_10.all verified = true := by decide

def carryCases18_11 : List Case := [
  ⟨1813, false, 1814, false, 29, 1, 36⟩,
  ⟨1815, false, 1816, false, 29, 1, 36⟩,
  ⟨1815, true, 1818, false, 28, 2, 35⟩,
  ⟨1816, false, 1817, false, 30, 1, 37⟩,
  ⟨1818, false, 1819, false, 31, 1, 38⟩,
  ⟨1818, true, 1822, false, 30, 2, 37⟩,
  ⟨1819, false, 1820, false, 32, 1, 39⟩,
  ⟨1820, false, 1821, false, 33, 1, 40⟩]
theorem carryCases18_11_verified : carryCases18_11.all verified = true := by decide

def carryCases18 : List Case := carryCases18_00 ++ carryCases18_01 ++ carryCases18_02 ++ carryCases18_03 ++ carryCases18_04 ++ carryCases18_05 ++ carryCases18_06 ++ carryCases18_07 ++ carryCases18_08 ++ carryCases18_09 ++ carryCases18_10 ++ carryCases18_11
theorem carryCases18_verified : carryCases18.all verified = true := by
  simp only [carryCases18, List.all_append, carryCases18_00_verified, carryCases18_01_verified, carryCases18_02_verified, carryCases18_03_verified, carryCases18_04_verified, carryCases18_05_verified, carryCases18_06_verified, carryCases18_07_verified, carryCases18_08_verified, carryCases18_09_verified, carryCases18_10_verified, carryCases18_11_verified, Bool.and_self]
theorem carryCases18_covered : carryCases18.map (fun c => key c.pc c.zero) = keysBetween 3452 192 := by decide
theorem carryCases18_count : carryCases18.length = 96 := by decide
end NF192.Carry
