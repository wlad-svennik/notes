module
public import MachineControlChunk00
public import MachineControlChunk01
public import MachineControlChunk02
public import MachineControlChunk03
public import MachineControlChunk04
public import MachineControlChunk05
public import MachineControlChunk06
public import MachineControlChunk07
public import MachineControlChunk08
public import MachineControlChunk09
public import MachineControlChunk10
public import MachineControlChunk11
public import MachineControlChunk12
public import MachineControlChunk13
public import MachineControlChunk14


@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control
open NF210 NF210.TM

def controlCases : List Case := cases00 ++ cases01 ++ cases02 ++ cases03 ++ cases04 ++ cases05 ++ cases06 ++ cases07 ++ cases08 ++ cases09 ++ cases10 ++ cases11 ++ cases12 ++ cases13 ++ cases14

theorem cases_verified : controlCases.all verified = true := by
  simp only [controlCases, List.all_append, cases00_verified, cases01_verified, cases02_verified, cases03_verified, cases04_verified, cases05_verified, cases06_verified, cases07_verified, cases08_verified, cases09_verified, cases10_verified, cases11_verified, cases12_verified, cases13_verified, cases14_verified, Bool.and_self]

theorem coverage : controlCases.map Case.pc =
    (List.range 3089).filter (fun i => isControl (Source.siteAt i)) := by decide

theorem control_sites_count : controlCases.length = 956 := by decide
theorem continue_sites_count : (controlCases.filter (fun c => !c.isBranch)).length = 896 := by decide
theorem branch_sites_count : (controlCases.filter Case.isBranch).length = 60 := by decide

/-- Every source CC/CB, on all tapes with the encoded source address, the
stated gap, and header 10, returns to the decoder at the address dictated by
the register program. The rest of the tape is completely arbitrary. -/
theorem all_control_sites (pc : Nat) (hi : pc < 3089)
    (isCtr : isControl (Source.siteAt pc) = true)
    (anchor header : Int) (outside : Tape)
    (space : anchor + (width:Int) < header) (head1 : outside header = true)
    (head0 : outside (header+1) = false)
    (gap : ∀ p, anchor + (width:Int) ≤ p → p < header → outside p = false) :
    ∃ duration, run Selected.machine duration
      (rootWindow anchor outside (pathMask (Source.siteAt pc).address)) =
      rootWindow anchor outside (pathMask (targetAddress (Source.siteAt pc))) := by
  have mem : pc ∈ controlCases.map Case.pc := by
    rw [coverage]
    exact List.mem_filter.mpr ⟨List.mem_range.mpr hi, isCtr⟩
  obtain ⟨c, inCases, eq⟩ := List.mem_map.mp mem
  rw [← eq]
  exact case_correct (List.all_eq_true.mp cases_verified _ inCases) anchor header outside space head1 head0 gap

/-- The same return theorem in terms of the source instruction and its
actual destination leaf. Hence the source-register state is unchanged. -/
theorem all_control_source_steps (pc : Nat) (hi : pc < 3089)
    (isCtr : isControl (Source.siteAt pc) = true)
    (anchor header : Int) (outside : Tape)
    (space : anchor + (width:Int) < header) (head1 : outside header = true)
    (head0 : outside (header+1) = false)
    (gap : ∀ p, anchor + (width:Int) ≤ p → p < header → outside p = false) :
    ∃ next duration, Source.program pc = Source.Command.jump next ∧
      run Selected.machine duration (rootWindow anchor outside (pathMask (Source.siteAt pc).address)) =
        rootWindow anchor outside (pathMask (Source.siteAt next).address) := by
  have mem : pc ∈ controlCases.map Case.pc := by
    rw [coverage]
    exact List.mem_filter.mpr ⟨List.mem_range.mpr hi, isCtr⟩
  obtain ⟨c, inCases, eq⟩ := List.mem_map.mp mem
  rw [← eq] at hi ⊢
  exact case_source_step hi (List.all_eq_true.mp cases_verified _ inCases)
    anchor header outside space head1 head0 gap

end NF192.Control
