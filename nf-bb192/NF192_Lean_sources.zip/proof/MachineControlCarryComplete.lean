module
public import MachineControlCarryChunk00
public import MachineControlCarryChunk01
public import MachineControlCarryChunk02
public import MachineControlCarryChunk03
public import MachineControlCarryChunk04
public import MachineControlCarryChunk05
public import MachineControlCarryChunk06
public import MachineControlCarryChunk07
public import MachineControlCarryChunk08
public import MachineControlCarryChunk09
public import MachineControlCarryChunk10
public import MachineControlCarryChunk11
public import MachineControlCarryChunk12
public import MachineControlCarryChunk13
public import MachineControlCarryChunk14
public import MachineControlCarryChunk15
public import MachineControlCarryChunk16
public import MachineControlCarryChunk17
public import MachineControlCarryChunk18
public import MachineControlCarryChunk19
public import MachineControlCarryChunk20
public import MachineControlCarryChunk21
public import MachineControlCarryChunk22
public import MachineControlCarryChunk23
public import MachineControlCarryChunk24
public import MachineControlCarryChunk25
public import MachineControlCarryChunk26
public import MachineControlCarryChunk27
public import MachineControlCarryChunk28
public import MachineControlCarryChunk29
public import MachineControlCarryChunk30
public import MachineControlCarryChunk31
public import MachineControlCarryChunk32

@[expose] public section
namespace NF192.Carry
open KernelRightShift
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases : List Case := carryCases00 ++ carryCases01 ++ carryCases02 ++ carryCases03 ++ carryCases04 ++ carryCases05 ++ carryCases06 ++ carryCases07 ++ carryCases08 ++ carryCases09 ++ carryCases10 ++ carryCases11 ++ carryCases12 ++ carryCases13 ++ carryCases14 ++ carryCases15 ++ carryCases16 ++ carryCases17 ++ carryCases18 ++ carryCases19 ++ carryCases20 ++ carryCases21 ++ carryCases22 ++ carryCases23 ++ carryCases24 ++ carryCases25 ++ carryCases26 ++ carryCases27 ++ carryCases28 ++ carryCases29 ++ carryCases30 ++ carryCases31 ++ carryCases32
theorem carryCases_verified : carryCases.all verified = true := by
  simp only [carryCases, List.all_append, carryCases00_verified, carryCases01_verified, carryCases02_verified, carryCases03_verified, carryCases04_verified, carryCases05_verified, carryCases06_verified, carryCases07_verified, carryCases08_verified, carryCases09_verified, carryCases10_verified, carryCases11_verified, carryCases12_verified, carryCases13_verified, carryCases14_verified, carryCases15_verified, carryCases16_verified, carryCases17_verified, carryCases18_verified, carryCases19_verified, carryCases20_verified, carryCases21_verified, carryCases22_verified, carryCases23_verified, carryCases24_verified, carryCases25_verified, carryCases26_verified, carryCases27_verified, carryCases28_verified, carryCases29_verified, carryCases30_verified, carryCases31_verified, carryCases32_verified, Bool.and_self]
theorem carry_count : carryCases.length = 3094 := by
  simp only [carryCases,List.length_append,carryCases00_count, carryCases01_count, carryCases02_count, carryCases03_count, carryCases04_count, carryCases05_count, carryCases06_count, carryCases07_count, carryCases08_count, carryCases09_count, carryCases10_count, carryCases11_count, carryCases12_count, carryCases13_count, carryCases14_count, carryCases15_count, carryCases16_count, carryCases17_count, carryCases18_count, carryCases19_count, carryCases20_count, carryCases21_count, carryCases22_count, carryCases23_count, carryCases24_count, carryCases25_count, carryCases26_count, carryCases27_count, carryCases28_count, carryCases29_count, carryCases30_count, carryCases31_count, carryCases32_count]
/-- Every nonhalting arithmetic return on every full unary register file. -/
theorem all_arithmetic_returns (pc : Nat) (hi : pc < 3089) (zero : Bool)
    (hs : selected pc zero = true) (extra : Nat)
    (space : 40 ≤ (initialWord pc zero).length+extra) :
    ∃ t, WordRun (entryState zero) 13 (ready pc zero extra) (restored pc zero extra)
      (startHead pc) (before (shifted pc zero)+1 : Nat) t := by
  have bound : key pc zero < 6178 := by cases zero <;> simp [key] <;> omega
  by_cases h3067 : key pc zero < 3067
  · by_cases h1532 : key pc zero < 1532
    · by_cases h760 : key pc zero < 760
      · by_cases h377 : key pc zero < 377
        · by_cases h185 : key pc zero < 185
          · exact from_block carryCases00 0 185 carryCases00_verified carryCases00_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases01 185 192 carryCases01_verified carryCases01_covered pc zero hs (by omega) (by omega) extra space
        · by_cases h570 : key pc zero < 570
          · exact from_block carryCases02 377 193 carryCases02_verified carryCases02_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases03 570 190 carryCases03_verified carryCases03_covered pc zero hs (by omega) (by omega) extra space
      · by_cases h1146 : key pc zero < 1146
        · by_cases h956 : key pc zero < 956
          · exact from_block carryCases04 760 196 carryCases04_verified carryCases04_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases05 956 190 carryCases05_verified carryCases05_covered pc zero hs (by omega) (by omega) extra space
        · by_cases h1338 : key pc zero < 1338
          · exact from_block carryCases06 1146 192 carryCases06_verified carryCases06_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases07 1338 194 carryCases07_verified carryCases07_covered pc zero hs (by omega) (by omega) extra space
    · by_cases h2300 : key pc zero < 2300
      · by_cases h1916 : key pc zero < 1916
        · by_cases h1724 : key pc zero < 1724
          · exact from_block carryCases08 1532 192 carryCases08_verified carryCases08_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases09 1724 192 carryCases09_verified carryCases09_covered pc zero hs (by omega) (by omega) extra space
        · by_cases h2108 : key pc zero < 2108
          · exact from_block carryCases10 1916 192 carryCases10_verified carryCases10_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases11 2108 192 carryCases11_verified carryCases11_covered pc zero hs (by omega) (by omega) extra space
      · by_cases h2680 : key pc zero < 2680
        · by_cases h2490 : key pc zero < 2490
          · exact from_block carryCases12 2300 190 carryCases12_verified carryCases12_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases13 2490 190 carryCases13_verified carryCases13_covered pc zero hs (by omega) (by omega) extra space
        · by_cases h2875 : key pc zero < 2875
          · exact from_block carryCases14 2680 195 carryCases14_verified carryCases14_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases15 2875 192 carryCases15_verified carryCases15_covered pc zero hs (by omega) (by omega) extra space
  · by_cases h4603 : key pc zero < 4603
    · by_cases h3834 : key pc zero < 3834
      · by_cases h3452 : key pc zero < 3452
        · by_cases h3259 : key pc zero < 3259
          · exact from_block carryCases16 3067 192 carryCases16_verified carryCases16_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases17 3259 193 carryCases17_verified carryCases17_covered pc zero hs (by omega) (by omega) extra space
        · by_cases h3644 : key pc zero < 3644
          · exact from_block carryCases18 3452 192 carryCases18_verified carryCases18_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases19 3644 190 carryCases19_verified carryCases19_covered pc zero hs (by omega) (by omega) extra space
      · by_cases h4218 : key pc zero < 4218
        · by_cases h4027 : key pc zero < 4027
          · exact from_block carryCases20 3834 193 carryCases20_verified carryCases20_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases21 4027 191 carryCases21_verified carryCases21_covered pc zero hs (by omega) (by omega) extra space
        · by_cases h4412 : key pc zero < 4412
          · exact from_block carryCases22 4218 194 carryCases22_verified carryCases22_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases23 4412 191 carryCases23_verified carryCases23_covered pc zero hs (by omega) (by omega) extra space
    · by_cases h5372 : key pc zero < 5372
      · by_cases h4987 : key pc zero < 4987
        · by_cases h4796 : key pc zero < 4796
          · exact from_block carryCases24 4603 193 carryCases24_verified carryCases24_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases25 4796 191 carryCases25_verified carryCases25_covered pc zero hs (by omega) (by omega) extra space
        · by_cases h5179 : key pc zero < 5179
          · exact from_block carryCases26 4987 192 carryCases26_verified carryCases26_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases27 5179 193 carryCases27_verified carryCases27_covered pc zero hs (by omega) (by omega) extra space
      · by_cases h5755 : key pc zero < 5755
        · by_cases h5564 : key pc zero < 5564
          · exact from_block carryCases28 5372 192 carryCases28_verified carryCases28_covered pc zero hs (by omega) (by omega) extra space
          · exact from_block carryCases29 5564 191 carryCases29_verified carryCases29_covered pc zero hs (by omega) (by omega) extra space
        · by_cases h5947 : key pc zero < 5947
          · exact from_block carryCases30 5755 192 carryCases30_verified carryCases30_covered pc zero hs (by omega) (by omega) extra space
          · by_cases h6136 : key pc zero < 6136
            · exact from_block carryCases31 5947 189 carryCases31_verified carryCases31_covered pc zero hs (by omega) (by omega) extra space
            · exact from_block carryCases32 6136 42 carryCases32_verified carryCases32_covered pc zero hs (by omega) (by omega) extra space

#print axioms all_arithmetic_returns
end NF192.Carry
