module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases07_00 : List Case := [
  ⟨669, false, 670, false, 33, 1, 40⟩,
  ⟨670, false, 671, false, 34, 1, 41⟩,
  ⟨672, false, 673, false, 25, 5, 32⟩,
  ⟨673, false, 674, false, 30, 1, 37⟩,
  ⟨673, true, 681, false, 29, 2, 36⟩,
  ⟨674, false, 675, false, 32, 1, 39⟩,
  ⟨675, false, 676, false, 34, 1, 41⟩,
  ⟨675, true, 677, false, 33, 2, 40⟩]
theorem carryCases07_00_verified : carryCases07_00.all verified = true := by decide

def carryCases07_01 : List Case := [
  ⟨677, false, 678, false, 34, 1, 41⟩,
  ⟨677, true, 680, false, 31, 4, 38⟩,
  ⟨678, false, 679, false, 35, 1, 42⟩,
  ⟨681, false, 682, false, 30, 1, 37⟩,
  ⟨681, true, 684, false, 28, 3, 35⟩,
  ⟨682, false, 683, false, 31, 1, 38⟩,
  ⟨684, false, 685, false, 31, 1, 38⟩,
  ⟨684, true, 688, false, 30, 2, 37⟩]
theorem carryCases07_01_verified : carryCases07_01.all verified = true := by decide

def carryCases07_02 : List Case := [
  ⟨685, false, 686, false, 32, 1, 39⟩,
  ⟨686, false, 687, false, 33, 1, 40⟩,
  ⟨688, false, 689, false, 31, 1, 38⟩,
  ⟨688, true, 694, false, 29, 3, 36⟩,
  ⟨689, false, 690, false, 33, 1, 40⟩,
  ⟨690, false, 691, false, 34, 1, 41⟩,
  ⟨690, true, 693, false, 32, 3, 39⟩,
  ⟨691, false, 692, false, 35, 1, 42⟩]
theorem carryCases07_02_verified : carryCases07_02.all verified = true := by decide

def carryCases07_03 : List Case := [
  ⟨694, false, 695, false, 30, 1, 37⟩,
  ⟨694, true, 698, false, 27, 4, 34⟩,
  ⟨695, false, 696, false, 31, 1, 38⟩,
  ⟨696, false, 697, false, 32, 1, 39⟩,
  ⟨698, false, 699, false, 26, 2, 33⟩,
  ⟨699, false, 700, false, 29, 1, 36⟩,
  ⟨699, true, 707, false, 28, 2, 35⟩,
  ⟨700, false, 701, false, 31, 1, 38⟩]
theorem carryCases07_03_verified : carryCases07_03.all verified = true := by decide

def carryCases07_04 : List Case := [
  ⟨701, false, 702, false, 33, 1, 40⟩,
  ⟨701, true, 703, false, 32, 2, 39⟩,
  ⟨703, false, 704, false, 33, 1, 40⟩,
  ⟨703, true, 706, false, 30, 4, 37⟩,
  ⟨704, false, 705, false, 34, 1, 41⟩,
  ⟨707, false, 708, false, 29, 1, 36⟩,
  ⟨707, true, 710, false, 27, 3, 34⟩,
  ⟨708, false, 709, false, 30, 1, 37⟩]
theorem carryCases07_04_verified : carryCases07_04.all verified = true := by decide

def carryCases07_05 : List Case := [
  ⟨710, false, 711, false, 30, 1, 37⟩,
  ⟨710, true, 714, false, 29, 2, 36⟩,
  ⟨711, false, 712, false, 31, 1, 38⟩,
  ⟨712, false, 713, false, 32, 1, 39⟩,
  ⟨714, false, 715, false, 30, 1, 37⟩,
  ⟨714, true, 720, false, 28, 3, 35⟩,
  ⟨715, false, 716, false, 32, 1, 39⟩,
  ⟨716, false, 717, false, 33, 1, 40⟩]
theorem carryCases07_05_verified : carryCases07_05.all verified = true := by decide

def carryCases07_06 : List Case := [
  ⟨716, true, 719, false, 31, 3, 38⟩,
  ⟨717, false, 718, false, 34, 1, 41⟩,
  ⟨720, false, 721, false, 29, 1, 36⟩,
  ⟨720, true, 724, false, 24, 6, 31⟩,
  ⟨721, false, 722, false, 30, 1, 37⟩,
  ⟨722, false, 723, false, 31, 1, 38⟩,
  ⟨724, false, 725, false, 28, 1, 35⟩,
  ⟨724, true, 727, false, 27, 2, 34⟩]
theorem carryCases07_06_verified : carryCases07_06.all verified = true := by decide

def carryCases07_07 : List Case := [
  ⟨725, false, 726, false, 29, 1, 36⟩,
  ⟨727, false, 728, false, 29, 1, 36⟩,
  ⟨727, true, 730, false, 28, 2, 35⟩,
  ⟨728, false, 729, false, 30, 1, 37⟩,
  ⟨730, false, 731, false, 31, 1, 38⟩,
  ⟨730, true, 734, false, 30, 2, 37⟩,
  ⟨731, false, 732, false, 32, 1, 39⟩,
  ⟨732, false, 733, false, 33, 1, 40⟩]
theorem carryCases07_07_verified : carryCases07_07.all verified = true := by decide

def carryCases07_08 : List Case := [
  ⟨734, false, 735, false, 31, 1, 38⟩,
  ⟨734, true, 740, false, 29, 3, 36⟩,
  ⟨735, false, 736, false, 33, 1, 40⟩,
  ⟨736, false, 737, false, 34, 1, 41⟩,
  ⟨736, true, 739, false, 32, 3, 39⟩,
  ⟨737, false, 738, false, 35, 1, 42⟩,
  ⟨740, false, 741, false, 30, 1, 37⟩,
  ⟨740, true, 743, false, 26, 5, 33⟩]
theorem carryCases07_08_verified : carryCases07_08.all verified = true := by decide

def carryCases07_09 : List Case := [
  ⟨741, false, 742, false, 31, 1, 38⟩,
  ⟨743, false, 744, false, 28, 1, 35⟩,
  ⟨743, true, 747, false, 27, 2, 34⟩,
  ⟨744, false, 745, false, 29, 1, 36⟩,
  ⟨745, false, 746, false, 30, 1, 37⟩,
  ⟨747, false, 748, false, 28, 1, 35⟩,
  ⟨747, true, 750, false, 25, 4, 32⟩,
  ⟨748, false, 749, false, 29, 1, 36⟩]
theorem carryCases07_09_verified : carryCases07_09.all verified = true := by decide

def carryCases07_10 : List Case := [
  ⟨750, false, 751, false, 30, 1, 37⟩,
  ⟨750, true, 753, false, 29, 2, 36⟩,
  ⟨751, false, 752, false, 31, 1, 38⟩,
  ⟨753, false, 754, false, 31, 1, 38⟩,
  ⟨753, true, 756, false, 30, 2, 37⟩,
  ⟨754, false, 755, false, 32, 1, 39⟩,
  ⟨756, false, 757, false, 33, 1, 40⟩,
  ⟨756, true, 760, false, 32, 2, 39⟩]
theorem carryCases07_10_verified : carryCases07_10.all verified = true := by decide

def carryCases07_11 : List Case := [
  ⟨757, false, 758, false, 34, 1, 41⟩,
  ⟨758, false, 759, false, 35, 1, 42⟩,
  ⟨760, false, 761, false, 33, 1, 40⟩,
  ⟨760, true, 766, false, 31, 3, 38⟩,
  ⟨761, false, 762, false, 35, 1, 42⟩,
  ⟨762, false, 763, false, 36, 1, 43⟩,
  ⟨762, true, 765, false, 34, 3, 41⟩,
  ⟨763, false, 764, false, 37, 1, 44⟩]
theorem carryCases07_11_verified : carryCases07_11.all verified = true := by decide

def carryCases07 : List Case := carryCases07_00 ++ carryCases07_01 ++ carryCases07_02 ++ carryCases07_03 ++ carryCases07_04 ++ carryCases07_05 ++ carryCases07_06 ++ carryCases07_07 ++ carryCases07_08 ++ carryCases07_09 ++ carryCases07_10 ++ carryCases07_11
theorem carryCases07_verified : carryCases07.all verified = true := by
  simp only [carryCases07, List.all_append, carryCases07_00_verified, carryCases07_01_verified, carryCases07_02_verified, carryCases07_03_verified, carryCases07_04_verified, carryCases07_05_verified, carryCases07_06_verified, carryCases07_07_verified, carryCases07_08_verified, carryCases07_09_verified, carryCases07_10_verified, carryCases07_11_verified, Bool.and_self]
theorem carryCases07_covered : carryCases07.map (fun c => key c.pc c.zero) = keysBetween 1338 194 := by decide
theorem carryCases07_count : carryCases07.length = 96 := by decide
end NF192.Carry
