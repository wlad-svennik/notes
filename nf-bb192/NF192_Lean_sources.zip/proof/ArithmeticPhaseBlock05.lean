module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block1280 : checkRange 1280 32 = true := by decide +kernel
theorem block1312 : checkRange 1312 32 = true := by decide +kernel
theorem block1344 : checkRange 1344 32 = true := by decide +kernel
theorem block1376 : checkRange 1376 32 = true := by decide +kernel
theorem block1408 : checkRange 1408 32 = true := by decide +kernel
theorem block1440 : checkRange 1440 32 = true := by decide +kernel
theorem block1472 : checkRange 1472 32 = true := by decide +kernel
theorem block1504 : checkRange 1504 32 = true := by decide +kernel

end NF192.Phase
