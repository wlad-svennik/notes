module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases02_00 : List Case := [
  ⟨188, true, 191, false, 26, 3, 33⟩,
  ⟨189, false, 190, false, 29, 1, 36⟩,
  ⟨192, false, 193, false, 24, 1, 31⟩,
  ⟨192, true, 196, false, 20, 5, 27⟩,
  ⟨193, false, 194, false, 25, 1, 32⟩,
  ⟨194, false, 195, false, 26, 1, 33⟩,
  ⟨196, false, 197, false, 25, 1, 32⟩,
  ⟨196, true, 199, false, 24, 2, 31⟩]
theorem carryCases02_00_verified : carryCases02_00.all verified = true := by decide

def carryCases02_01 : List Case := [
  ⟨197, false, 198, false, 26, 1, 33⟩,
  ⟨199, false, 200, false, 26, 1, 33⟩,
  ⟨199, true, 202, false, 25, 2, 32⟩,
  ⟨200, false, 201, false, 27, 1, 34⟩,
  ⟨202, false, 203, false, 28, 1, 35⟩,
  ⟨202, true, 206, false, 27, 2, 34⟩,
  ⟨203, false, 204, false, 29, 1, 36⟩,
  ⟨204, false, 205, false, 30, 1, 37⟩]
theorem carryCases02_01_verified : carryCases02_01.all verified = true := by decide

def carryCases02_02 : List Case := [
  ⟨206, false, 207, false, 28, 1, 35⟩,
  ⟨206, true, 212, false, 26, 3, 33⟩,
  ⟨207, false, 208, false, 30, 1, 37⟩,
  ⟨208, false, 209, false, 31, 1, 38⟩,
  ⟨208, true, 211, false, 29, 3, 36⟩,
  ⟨209, false, 210, false, 32, 1, 39⟩,
  ⟨212, false, 213, false, 27, 1, 34⟩,
  ⟨212, true, 215, false, 23, 5, 30⟩]
theorem carryCases02_02_verified : carryCases02_02.all verified = true := by decide

def carryCases02_03 : List Case := [
  ⟨213, false, 214, false, 28, 1, 35⟩,
  ⟨215, false, 216, false, 25, 1, 32⟩,
  ⟨215, true, 219, false, 24, 2, 31⟩,
  ⟨216, false, 217, false, 26, 1, 33⟩,
  ⟨217, false, 218, false, 27, 1, 34⟩,
  ⟨219, false, 220, false, 25, 1, 32⟩,
  ⟨219, true, 222, false, 22, 4, 29⟩,
  ⟨220, false, 221, false, 26, 1, 33⟩]
theorem carryCases02_03_verified : carryCases02_03.all verified = true := by decide

def carryCases02_04 : List Case := [
  ⟨222, false, 223, false, 27, 1, 34⟩,
  ⟨222, true, 225, false, 26, 2, 33⟩,
  ⟨223, false, 224, false, 28, 1, 35⟩,
  ⟨225, false, 226, false, 28, 1, 35⟩,
  ⟨225, true, 228, false, 27, 2, 34⟩,
  ⟨226, false, 227, false, 29, 1, 36⟩,
  ⟨228, false, 229, false, 30, 1, 37⟩,
  ⟨228, true, 232, false, 29, 2, 36⟩]
theorem carryCases02_04_verified : carryCases02_04.all verified = true := by decide

def carryCases02_05 : List Case := [
  ⟨229, false, 230, false, 31, 1, 38⟩,
  ⟨230, false, 231, false, 32, 1, 39⟩,
  ⟨232, false, 233, false, 30, 1, 37⟩,
  ⟨232, true, 238, false, 28, 3, 35⟩,
  ⟨233, false, 234, false, 32, 1, 39⟩,
  ⟨234, false, 235, false, 33, 1, 40⟩,
  ⟨234, true, 237, false, 31, 3, 38⟩,
  ⟨235, false, 236, false, 34, 1, 41⟩]
theorem carryCases02_05_verified : carryCases02_05.all verified = true := by decide

def carryCases02_06 : List Case := [
  ⟨238, false, 239, false, 29, 1, 36⟩,
  ⟨238, true, 241, false, 25, 5, 32⟩,
  ⟨239, false, 240, false, 30, 1, 37⟩,
  ⟨241, false, 242, false, 27, 1, 34⟩,
  ⟨241, true, 245, false, 26, 2, 33⟩,
  ⟨242, false, 243, false, 28, 1, 35⟩,
  ⟨243, false, 244, false, 29, 1, 36⟩,
  ⟨245, false, 246, false, 27, 1, 34⟩]
theorem carryCases02_06_verified : carryCases02_06.all verified = true := by decide

def carryCases02_07 : List Case := [
  ⟨245, true, 248, false, 24, 4, 31⟩,
  ⟨246, false, 247, false, 28, 1, 35⟩,
  ⟨248, false, 249, false, 27, 1, 34⟩,
  ⟨248, true, 256, false, 26, 2, 33⟩,
  ⟨249, false, 250, false, 29, 1, 36⟩,
  ⟨250, false, 251, false, 31, 1, 38⟩,
  ⟨250, true, 252, false, 30, 2, 37⟩,
  ⟨252, false, 253, false, 31, 1, 38⟩]
theorem carryCases02_07_verified : carryCases02_07.all verified = true := by decide

def carryCases02_08 : List Case := [
  ⟨252, true, 255, false, 28, 4, 35⟩,
  ⟨253, false, 254, false, 32, 1, 39⟩,
  ⟨256, false, 257, false, 27, 1, 34⟩,
  ⟨256, true, 259, false, 25, 3, 32⟩,
  ⟨257, false, 258, false, 28, 1, 35⟩,
  ⟨259, false, 260, false, 28, 1, 35⟩,
  ⟨259, true, 263, false, 27, 2, 34⟩,
  ⟨260, false, 261, false, 29, 1, 36⟩]
theorem carryCases02_08_verified : carryCases02_08.all verified = true := by decide

def carryCases02_09 : List Case := [
  ⟨261, false, 262, false, 30, 1, 37⟩,
  ⟨263, false, 264, false, 28, 1, 35⟩,
  ⟨263, true, 269, false, 26, 3, 33⟩,
  ⟨264, false, 265, false, 30, 1, 37⟩,
  ⟨265, false, 266, false, 31, 1, 38⟩,
  ⟨265, true, 268, false, 29, 3, 36⟩,
  ⟨266, false, 267, false, 32, 1, 39⟩,
  ⟨269, false, 270, false, 27, 1, 34⟩]
theorem carryCases02_09_verified : carryCases02_09.all verified = true := by decide

def carryCases02_10 : List Case := [
  ⟨269, true, 273, false, 23, 5, 30⟩,
  ⟨270, false, 271, false, 28, 1, 35⟩,
  ⟨271, false, 272, false, 29, 1, 36⟩,
  ⟨273, false, 274, false, 27, 1, 34⟩,
  ⟨273, true, 276, false, 26, 2, 33⟩,
  ⟨274, false, 275, false, 28, 1, 35⟩,
  ⟨276, false, 277, false, 28, 1, 35⟩,
  ⟨276, true, 279, false, 27, 2, 34⟩]
theorem carryCases02_10_verified : carryCases02_10.all verified = true := by decide

def carryCases02_11 : List Case := [
  ⟨277, false, 278, false, 29, 1, 36⟩,
  ⟨279, false, 280, false, 30, 1, 37⟩,
  ⟨279, true, 283, false, 29, 2, 36⟩,
  ⟨280, false, 281, false, 31, 1, 38⟩,
  ⟨281, false, 282, false, 32, 1, 39⟩,
  ⟨283, false, 284, false, 30, 1, 37⟩,
  ⟨283, true, 289, false, 28, 3, 35⟩,
  ⟨284, false, 285, false, 32, 1, 39⟩]
theorem carryCases02_11_verified : carryCases02_11.all verified = true := by decide

def carryCases02 : List Case := carryCases02_00 ++ carryCases02_01 ++ carryCases02_02 ++ carryCases02_03 ++ carryCases02_04 ++ carryCases02_05 ++ carryCases02_06 ++ carryCases02_07 ++ carryCases02_08 ++ carryCases02_09 ++ carryCases02_10 ++ carryCases02_11
theorem carryCases02_verified : carryCases02.all verified = true := by
  simp only [carryCases02, List.all_append, carryCases02_00_verified, carryCases02_01_verified, carryCases02_02_verified, carryCases02_03_verified, carryCases02_04_verified, carryCases02_05_verified, carryCases02_06_verified, carryCases02_07_verified, carryCases02_08_verified, carryCases02_09_verified, carryCases02_10_verified, carryCases02_11_verified, Bool.and_self]
theorem carryCases02_covered : carryCases02.map (fun c => key c.pc c.zero) = keysBetween 377 193 := by decide
theorem carryCases02_count : carryCases02.length = 96 := by decide
end NF192.Carry
