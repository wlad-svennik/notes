module
public import MachineCanonicalControlMasks

@[expose] public section
namespace NF192.CanonicalControl
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem mask3072 : checkRange 3072 17 = true := by decide +kernel
end NF192.CanonicalControl
