module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block3072 : checkRange 3072 17 = true := by decide +kernel

end NF192.Phase
