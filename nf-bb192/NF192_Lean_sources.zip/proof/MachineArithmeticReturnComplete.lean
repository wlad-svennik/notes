module
public import MachineArithmeticReturnBlock00
public import MachineArithmeticReturnBlock01
public import MachineArithmeticReturnBlock02
public import MachineArithmeticReturnBlock03
public import MachineArithmeticReturnBlock04
public import MachineArithmeticReturnBlock05
public import MachineArithmeticReturnBlock06

@[expose] public section
namespace NF192.ArithmeticReturn
set_option maxHeartbeats 0
theorem all_checked (i : Nat) (hi : i < 3089) : check i = true := by
  by_cases h1536 : i < 1536
  ·
    by_cases h768 : i < 768
    ·
      by_cases h384 : i < 384
      ·
        by_cases h192 : i < 192
        ·
          by_cases h96 : i < 96
          ·
            by_cases h32 : i < 32
            ·
              exact checked_in_range block0000 (by omega) (by omega)
            ·
              by_cases h64 : i < 64
              ·
                exact checked_in_range block0032 (by omega) (by omega)
              ·
                exact checked_in_range block0064 (by omega) (by omega)
          ·
            by_cases h128 : i < 128
            ·
              exact checked_in_range block0096 (by omega) (by omega)
            ·
              by_cases h160 : i < 160
              ·
                exact checked_in_range block0128 (by omega) (by omega)
              ·
                exact checked_in_range block0160 (by omega) (by omega)
        ·
          by_cases h288 : i < 288
          ·
            by_cases h224 : i < 224
            ·
              exact checked_in_range block0192 (by omega) (by omega)
            ·
              by_cases h256 : i < 256
              ·
                exact checked_in_range block0224 (by omega) (by omega)
              ·
                exact checked_in_range block0256 (by omega) (by omega)
          ·
            by_cases h320 : i < 320
            ·
              exact checked_in_range block0288 (by omega) (by omega)
            ·
              by_cases h352 : i < 352
              ·
                exact checked_in_range block0320 (by omega) (by omega)
              ·
                exact checked_in_range block0352 (by omega) (by omega)
      ·
        by_cases h576 : i < 576
        ·
          by_cases h480 : i < 480
          ·
            by_cases h416 : i < 416
            ·
              exact checked_in_range block0384 (by omega) (by omega)
            ·
              by_cases h448 : i < 448
              ·
                exact checked_in_range block0416 (by omega) (by omega)
              ·
                exact checked_in_range block0448 (by omega) (by omega)
          ·
            by_cases h512 : i < 512
            ·
              exact checked_in_range block0480 (by omega) (by omega)
            ·
              by_cases h544 : i < 544
              ·
                exact checked_in_range block0512 (by omega) (by omega)
              ·
                exact checked_in_range block0544 (by omega) (by omega)
        ·
          by_cases h672 : i < 672
          ·
            by_cases h608 : i < 608
            ·
              exact checked_in_range block0576 (by omega) (by omega)
            ·
              by_cases h640 : i < 640
              ·
                exact checked_in_range block0608 (by omega) (by omega)
              ·
                exact checked_in_range block0640 (by omega) (by omega)
          ·
            by_cases h704 : i < 704
            ·
              exact checked_in_range block0672 (by omega) (by omega)
            ·
              by_cases h736 : i < 736
              ·
                exact checked_in_range block0704 (by omega) (by omega)
              ·
                exact checked_in_range block0736 (by omega) (by omega)
    ·
      by_cases h1152 : i < 1152
      ·
        by_cases h960 : i < 960
        ·
          by_cases h864 : i < 864
          ·
            by_cases h800 : i < 800
            ·
              exact checked_in_range block0768 (by omega) (by omega)
            ·
              by_cases h832 : i < 832
              ·
                exact checked_in_range block0800 (by omega) (by omega)
              ·
                exact checked_in_range block0832 (by omega) (by omega)
          ·
            by_cases h896 : i < 896
            ·
              exact checked_in_range block0864 (by omega) (by omega)
            ·
              by_cases h928 : i < 928
              ·
                exact checked_in_range block0896 (by omega) (by omega)
              ·
                exact checked_in_range block0928 (by omega) (by omega)
        ·
          by_cases h1056 : i < 1056
          ·
            by_cases h992 : i < 992
            ·
              exact checked_in_range block0960 (by omega) (by omega)
            ·
              by_cases h1024 : i < 1024
              ·
                exact checked_in_range block0992 (by omega) (by omega)
              ·
                exact checked_in_range block1024 (by omega) (by omega)
          ·
            by_cases h1088 : i < 1088
            ·
              exact checked_in_range block1056 (by omega) (by omega)
            ·
              by_cases h1120 : i < 1120
              ·
                exact checked_in_range block1088 (by omega) (by omega)
              ·
                exact checked_in_range block1120 (by omega) (by omega)
      ·
        by_cases h1344 : i < 1344
        ·
          by_cases h1248 : i < 1248
          ·
            by_cases h1184 : i < 1184
            ·
              exact checked_in_range block1152 (by omega) (by omega)
            ·
              by_cases h1216 : i < 1216
              ·
                exact checked_in_range block1184 (by omega) (by omega)
              ·
                exact checked_in_range block1216 (by omega) (by omega)
          ·
            by_cases h1280 : i < 1280
            ·
              exact checked_in_range block1248 (by omega) (by omega)
            ·
              by_cases h1312 : i < 1312
              ·
                exact checked_in_range block1280 (by omega) (by omega)
              ·
                exact checked_in_range block1312 (by omega) (by omega)
        ·
          by_cases h1440 : i < 1440
          ·
            by_cases h1376 : i < 1376
            ·
              exact checked_in_range block1344 (by omega) (by omega)
            ·
              by_cases h1408 : i < 1408
              ·
                exact checked_in_range block1376 (by omega) (by omega)
              ·
                exact checked_in_range block1408 (by omega) (by omega)
          ·
            by_cases h1472 : i < 1472
            ·
              exact checked_in_range block1440 (by omega) (by omega)
            ·
              by_cases h1504 : i < 1504
              ·
                exact checked_in_range block1472 (by omega) (by omega)
              ·
                exact checked_in_range block1504 (by omega) (by omega)
  ·
    by_cases h2304 : i < 2304
    ·
      by_cases h1920 : i < 1920
      ·
        by_cases h1728 : i < 1728
        ·
          by_cases h1632 : i < 1632
          ·
            by_cases h1568 : i < 1568
            ·
              exact checked_in_range block1536 (by omega) (by omega)
            ·
              by_cases h1600 : i < 1600
              ·
                exact checked_in_range block1568 (by omega) (by omega)
              ·
                exact checked_in_range block1600 (by omega) (by omega)
          ·
            by_cases h1664 : i < 1664
            ·
              exact checked_in_range block1632 (by omega) (by omega)
            ·
              by_cases h1696 : i < 1696
              ·
                exact checked_in_range block1664 (by omega) (by omega)
              ·
                exact checked_in_range block1696 (by omega) (by omega)
        ·
          by_cases h1824 : i < 1824
          ·
            by_cases h1760 : i < 1760
            ·
              exact checked_in_range block1728 (by omega) (by omega)
            ·
              by_cases h1792 : i < 1792
              ·
                exact checked_in_range block1760 (by omega) (by omega)
              ·
                exact checked_in_range block1792 (by omega) (by omega)
          ·
            by_cases h1856 : i < 1856
            ·
              exact checked_in_range block1824 (by omega) (by omega)
            ·
              by_cases h1888 : i < 1888
              ·
                exact checked_in_range block1856 (by omega) (by omega)
              ·
                exact checked_in_range block1888 (by omega) (by omega)
      ·
        by_cases h2112 : i < 2112
        ·
          by_cases h2016 : i < 2016
          ·
            by_cases h1952 : i < 1952
            ·
              exact checked_in_range block1920 (by omega) (by omega)
            ·
              by_cases h1984 : i < 1984
              ·
                exact checked_in_range block1952 (by omega) (by omega)
              ·
                exact checked_in_range block1984 (by omega) (by omega)
          ·
            by_cases h2048 : i < 2048
            ·
              exact checked_in_range block2016 (by omega) (by omega)
            ·
              by_cases h2080 : i < 2080
              ·
                exact checked_in_range block2048 (by omega) (by omega)
              ·
                exact checked_in_range block2080 (by omega) (by omega)
        ·
          by_cases h2208 : i < 2208
          ·
            by_cases h2144 : i < 2144
            ·
              exact checked_in_range block2112 (by omega) (by omega)
            ·
              by_cases h2176 : i < 2176
              ·
                exact checked_in_range block2144 (by omega) (by omega)
              ·
                exact checked_in_range block2176 (by omega) (by omega)
          ·
            by_cases h2240 : i < 2240
            ·
              exact checked_in_range block2208 (by omega) (by omega)
            ·
              by_cases h2272 : i < 2272
              ·
                exact checked_in_range block2240 (by omega) (by omega)
              ·
                exact checked_in_range block2272 (by omega) (by omega)
    ·
      by_cases h2688 : i < 2688
      ·
        by_cases h2496 : i < 2496
        ·
          by_cases h2400 : i < 2400
          ·
            by_cases h2336 : i < 2336
            ·
              exact checked_in_range block2304 (by omega) (by omega)
            ·
              by_cases h2368 : i < 2368
              ·
                exact checked_in_range block2336 (by omega) (by omega)
              ·
                exact checked_in_range block2368 (by omega) (by omega)
          ·
            by_cases h2432 : i < 2432
            ·
              exact checked_in_range block2400 (by omega) (by omega)
            ·
              by_cases h2464 : i < 2464
              ·
                exact checked_in_range block2432 (by omega) (by omega)
              ·
                exact checked_in_range block2464 (by omega) (by omega)
        ·
          by_cases h2592 : i < 2592
          ·
            by_cases h2528 : i < 2528
            ·
              exact checked_in_range block2496 (by omega) (by omega)
            ·
              by_cases h2560 : i < 2560
              ·
                exact checked_in_range block2528 (by omega) (by omega)
              ·
                exact checked_in_range block2560 (by omega) (by omega)
          ·
            by_cases h2624 : i < 2624
            ·
              exact checked_in_range block2592 (by omega) (by omega)
            ·
              by_cases h2656 : i < 2656
              ·
                exact checked_in_range block2624 (by omega) (by omega)
              ·
                exact checked_in_range block2656 (by omega) (by omega)
      ·
        by_cases h2880 : i < 2880
        ·
          by_cases h2784 : i < 2784
          ·
            by_cases h2720 : i < 2720
            ·
              exact checked_in_range block2688 (by omega) (by omega)
            ·
              by_cases h2752 : i < 2752
              ·
                exact checked_in_range block2720 (by omega) (by omega)
              ·
                exact checked_in_range block2752 (by omega) (by omega)
          ·
            by_cases h2816 : i < 2816
            ·
              exact checked_in_range block2784 (by omega) (by omega)
            ·
              by_cases h2848 : i < 2848
              ·
                exact checked_in_range block2816 (by omega) (by omega)
              ·
                exact checked_in_range block2848 (by omega) (by omega)
        ·
          by_cases h2976 : i < 2976
          ·
            by_cases h2912 : i < 2912
            ·
              exact checked_in_range block2880 (by omega) (by omega)
            ·
              by_cases h2944 : i < 2944
              ·
                exact checked_in_range block2912 (by omega) (by omega)
              ·
                exact checked_in_range block2944 (by omega) (by omega)
          ·
            by_cases h3040 : i < 3040
            ·
              by_cases h3008 : i < 3008
              ·
                exact checked_in_range block2976 (by omega) (by omega)
              ·
                exact checked_in_range block3008 (by omega) (by omega)
            ·
              by_cases h3072 : i < 3072
              ·
                exact checked_in_range block3040 (by omega) (by omega)
              ·
                exact checked_in_range block3072 (by omega) (by omega)

theorem all_returns (i : Nat) (inside : i < 3089)
    (active : Phase.enabled (Source.siteAt i) 0 = true) (selected : Bool) :
    let s := Source.siteAt i
    let w := stageWord s selected
    KernelRightShift.WordRun KernelSelectors.returnState Selected.decoderRoot w w
      (initialHead s selected : Int) (finalHead s selected : Int) (duration s selected) := by
  apply checked_return
  have ok := things_checked active (all_checked i inside)
  cases selected
  · exact ok.2.1
  · exact ok.2.2

#print axioms all_returns

end NF192.ArithmeticReturn
