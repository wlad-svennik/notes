module
public import MachineCanonicalControlMasks

@[expose] public section
namespace NF192.CanonicalControl
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem mask1536 : checkRange 1536 32 = true := by decide +kernel
theorem mask1568 : checkRange 1568 32 = true := by decide +kernel
theorem mask1600 : checkRange 1600 32 = true := by decide +kernel
theorem mask1632 : checkRange 1632 32 = true := by decide +kernel
theorem mask1664 : checkRange 1664 32 = true := by decide +kernel
theorem mask1696 : checkRange 1696 32 = true := by decide +kernel
theorem mask1728 : checkRange 1728 32 = true := by decide +kernel
theorem mask1760 : checkRange 1760 32 = true := by decide +kernel
theorem mask1792 : checkRange 1792 32 = true := by decide +kernel
theorem mask1824 : checkRange 1824 32 = true := by decide +kernel
theorem mask1856 : checkRange 1856 32 = true := by decide +kernel
theorem mask1888 : checkRange 1888 32 = true := by decide +kernel
theorem mask1920 : checkRange 1920 32 = true := by decide +kernel
theorem mask1952 : checkRange 1952 32 = true := by decide +kernel
theorem mask1984 : checkRange 1984 32 = true := by decide +kernel
theorem mask2016 : checkRange 2016 32 = true := by decide +kernel
end NF192.CanonicalControl
