module
public import MachineInputData
@[expose] public section
namespace NF192.Input
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem rowBlock84 : computedBlock 84 = literalBlock 84 := by decide
theorem rowBlock85 : computedBlock 85 = literalBlock 85 := by decide
theorem rowBlock86 : computedBlock 86 = literalBlock 86 := by decide
theorem rowBlock87 : computedBlock 87 = literalBlock 87 := by decide
theorem rowBlock88 : computedBlock 88 = literalBlock 88 := by decide
theorem rowBlock89 : computedBlock 89 = literalBlock 89 := by decide
theorem rowBlock90 : computedBlock 90 = literalBlock 90 := by decide
theorem rowBlock91 : computedBlock 91 = literalBlock 91 := by decide
theorem rowBlock92 : computedBlock 92 = literalBlock 92 := by decide
theorem rowBlock93 : computedBlock 93 = literalBlock 93 := by decide
theorem rowBlock94 : computedBlock 94 = literalBlock 94 := by decide
theorem rowBlock95 : computedBlock 95 = literalBlock 95 := by decide
end NF192.Input
