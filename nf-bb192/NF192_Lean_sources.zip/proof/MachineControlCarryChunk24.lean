module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases24_00 : List Case := [
  ⟨2301, true, 2304, false, 24, 3, 31⟩,
  ⟨2302, false, 2303, false, 27, 1, 34⟩,
  ⟨2304, false, 2305, false, 28, 1, 35⟩,
  ⟨2304, true, 2312, false, 27, 2, 34⟩,
  ⟨2305, false, 2306, false, 30, 1, 37⟩,
  ⟨2306, false, 2307, false, 32, 1, 39⟩,
  ⟨2306, true, 2308, false, 31, 2, 38⟩,
  ⟨2308, false, 2309, false, 32, 1, 39⟩]
theorem carryCases24_00_verified : carryCases24_00.all verified = true := by decide

def carryCases24_01 : List Case := [
  ⟨2308, true, 2311, false, 29, 4, 36⟩,
  ⟨2309, false, 2310, false, 33, 1, 40⟩,
  ⟨2312, false, 2313, false, 28, 1, 35⟩,
  ⟨2312, true, 2315, false, 26, 3, 33⟩,
  ⟨2313, false, 2314, false, 29, 1, 36⟩,
  ⟨2315, false, 2316, false, 29, 1, 36⟩,
  ⟨2315, true, 2319, false, 28, 2, 35⟩,
  ⟨2316, false, 2317, false, 30, 1, 37⟩]
theorem carryCases24_01_verified : carryCases24_01.all verified = true := by decide

def carryCases24_02 : List Case := [
  ⟨2317, false, 2318, false, 31, 1, 38⟩,
  ⟨2319, false, 2320, false, 29, 1, 36⟩,
  ⟨2319, true, 2325, false, 27, 3, 34⟩,
  ⟨2320, false, 2321, false, 31, 1, 38⟩,
  ⟨2321, false, 2322, false, 32, 1, 39⟩,
  ⟨2321, true, 2324, false, 30, 3, 37⟩,
  ⟨2322, false, 2323, false, 33, 1, 40⟩,
  ⟨2325, false, 2326, false, 28, 1, 35⟩]
theorem carryCases24_02_verified : carryCases24_02.all verified = true := by decide

def carryCases24_03 : List Case := [
  ⟨2325, true, 2329, false, 25, 4, 32⟩,
  ⟨2326, false, 2327, false, 29, 1, 36⟩,
  ⟨2327, false, 2328, false, 30, 1, 37⟩,
  ⟨2329, false, 2330, false, 17, 9, 24⟩,
  ⟨2330, false, 2331, false, 22, 1, 29⟩,
  ⟨2330, true, 2333, false, 21, 2, 28⟩,
  ⟨2331, false, 2332, false, 23, 1, 30⟩,
  ⟨2333, false, 2334, false, 23, 1, 30⟩]
theorem carryCases24_03_verified : carryCases24_03.all verified = true := by decide

def carryCases24_04 : List Case := [
  ⟨2333, true, 2336, false, 22, 2, 29⟩,
  ⟨2334, false, 2335, false, 24, 1, 31⟩,
  ⟨2336, false, 2337, false, 25, 1, 32⟩,
  ⟨2336, true, 2340, false, 24, 2, 31⟩,
  ⟨2337, false, 2338, false, 26, 1, 33⟩,
  ⟨2338, false, 2339, false, 27, 1, 34⟩,
  ⟨2340, false, 2341, false, 25, 1, 32⟩,
  ⟨2340, true, 2346, false, 23, 3, 30⟩]
theorem carryCases24_04_verified : carryCases24_04.all verified = true := by decide

def carryCases24_05 : List Case := [
  ⟨2341, false, 2342, false, 27, 1, 34⟩,
  ⟨2342, false, 2343, false, 28, 1, 35⟩,
  ⟨2342, true, 2345, false, 26, 3, 33⟩,
  ⟨2343, false, 2344, false, 29, 1, 36⟩,
  ⟨2346, false, 2347, false, 24, 1, 31⟩,
  ⟨2346, true, 2349, false, 20, 5, 27⟩,
  ⟨2347, false, 2348, false, 25, 1, 32⟩,
  ⟨2349, false, 2350, false, 21, 1, 28⟩]
theorem carryCases24_05_verified : carryCases24_05.all verified = true := by decide

def carryCases24_06 : List Case := [
  ⟨2350, false, 2351, false, 22, 1, 29⟩,
  ⟨2351, false, 2352, false, 19, 4, 26⟩,
  ⟨2352, false, 2353, false, 23, 1, 30⟩,
  ⟨2352, true, 2360, false, 22, 2, 29⟩,
  ⟨2353, false, 2354, false, 25, 1, 32⟩,
  ⟨2354, false, 2355, false, 27, 1, 34⟩,
  ⟨2354, true, 2356, false, 26, 2, 33⟩,
  ⟨2356, false, 2357, false, 27, 1, 34⟩]
theorem carryCases24_06_verified : carryCases24_06.all verified = true := by decide

def carryCases24_07 : List Case := [
  ⟨2356, true, 2359, false, 24, 4, 31⟩,
  ⟨2357, false, 2358, false, 28, 1, 35⟩,
  ⟨2360, false, 2361, false, 23, 1, 30⟩,
  ⟨2360, true, 2363, false, 21, 3, 28⟩,
  ⟨2361, false, 2362, false, 24, 1, 31⟩,
  ⟨2363, false, 2364, false, 24, 1, 31⟩,
  ⟨2363, true, 2367, false, 23, 2, 30⟩,
  ⟨2364, false, 2365, false, 25, 1, 32⟩]
theorem carryCases24_07_verified : carryCases24_07.all verified = true := by decide

def carryCases24_08 : List Case := [
  ⟨2365, false, 2366, false, 26, 1, 33⟩,
  ⟨2367, false, 2368, false, 24, 1, 31⟩,
  ⟨2367, true, 2373, false, 22, 3, 29⟩,
  ⟨2368, false, 2369, false, 26, 1, 33⟩,
  ⟨2369, false, 2370, false, 27, 1, 34⟩,
  ⟨2369, true, 2372, false, 25, 3, 32⟩,
  ⟨2370, false, 2371, false, 28, 1, 35⟩,
  ⟨2373, false, 2374, false, 23, 1, 30⟩]
theorem carryCases24_08_verified : carryCases24_08.all verified = true := by decide

def carryCases24_09 : List Case := [
  ⟨2373, true, 2377, false, 20, 4, 27⟩,
  ⟨2374, false, 2375, false, 24, 1, 31⟩,
  ⟨2375, false, 2376, false, 25, 1, 32⟩,
  ⟨2377, false, 2378, false, 25, 1, 32⟩,
  ⟨2377, true, 2380, false, 24, 2, 31⟩,
  ⟨2378, false, 2379, false, 26, 1, 33⟩,
  ⟨2380, false, 2381, false, 26, 1, 33⟩,
  ⟨2380, true, 2383, false, 25, 2, 32⟩]
theorem carryCases24_09_verified : carryCases24_09.all verified = true := by decide

def carryCases24_10 : List Case := [
  ⟨2381, false, 2382, false, 27, 1, 34⟩,
  ⟨2383, false, 2384, false, 28, 1, 35⟩,
  ⟨2383, true, 2387, false, 27, 2, 34⟩,
  ⟨2384, false, 2385, false, 29, 1, 36⟩,
  ⟨2385, false, 2386, false, 30, 1, 37⟩,
  ⟨2387, false, 2388, false, 28, 1, 35⟩,
  ⟨2387, true, 2393, false, 26, 3, 33⟩,
  ⟨2388, false, 2389, false, 30, 1, 37⟩]
theorem carryCases24_10_verified : carryCases24_10.all verified = true := by decide

def carryCases24_11 : List Case := [
  ⟨2389, false, 2390, false, 31, 1, 38⟩,
  ⟨2389, true, 2392, false, 29, 3, 36⟩,
  ⟨2390, false, 2391, false, 32, 1, 39⟩,
  ⟨2393, false, 2394, false, 27, 1, 34⟩,
  ⟨2393, true, 2396, false, 23, 5, 30⟩,
  ⟨2394, false, 2395, false, 28, 1, 35⟩,
  ⟨2396, false, 2397, false, 24, 1, 31⟩,
  ⟨2397, false, 2398, false, 25, 1, 32⟩]
theorem carryCases24_11_verified : carryCases24_11.all verified = true := by decide

def carryCases24 : List Case := carryCases24_00 ++ carryCases24_01 ++ carryCases24_02 ++ carryCases24_03 ++ carryCases24_04 ++ carryCases24_05 ++ carryCases24_06 ++ carryCases24_07 ++ carryCases24_08 ++ carryCases24_09 ++ carryCases24_10 ++ carryCases24_11
theorem carryCases24_verified : carryCases24.all verified = true := by
  simp only [carryCases24, List.all_append, carryCases24_00_verified, carryCases24_01_verified, carryCases24_02_verified, carryCases24_03_verified, carryCases24_04_verified, carryCases24_05_verified, carryCases24_06_verified, carryCases24_07_verified, carryCases24_08_verified, carryCases24_09_verified, carryCases24_10_verified, carryCases24_11_verified, Bool.and_self]
theorem carryCases24_covered : carryCases24.map (fun c => key c.pc c.zero) = keysBetween 4603 193 := by decide
theorem carryCases24_count : carryCases24.length = 96 := by decide
end NF192.Carry
