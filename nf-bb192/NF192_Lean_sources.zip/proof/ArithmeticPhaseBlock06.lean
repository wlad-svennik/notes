module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block1536 : checkRange 1536 32 = true := by decide +kernel
theorem block1568 : checkRange 1568 32 = true := by decide +kernel
theorem block1600 : checkRange 1600 32 = true := by decide +kernel
theorem block1632 : checkRange 1632 32 = true := by decide +kernel
theorem block1664 : checkRange 1664 32 = true := by decide +kernel
theorem block1696 : checkRange 1696 32 = true := by decide +kernel
theorem block1728 : checkRange 1728 32 = true := by decide +kernel
theorem block1760 : checkRange 1760 32 = true := by decide +kernel

end NF192.Phase
