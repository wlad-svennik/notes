module
public import MachineFrameIncrementWord
public import MachineFrameCarry
public import MachineIngress

@[expose] public section
namespace NF192.Frame

open NF210 NF210.TM KernelRightShift

/-- Physical successor of literal CI, including increment of a cold raw-zero register. -/
def Layout.afterIncrement (f : Layout) (r : Fin 9) : Layout :=
  f.afterCarry false 0 (f.stored.setIfInBounds r.val (f.storedAt r.val+1)) (f.spares++[0])

theorem Layout.increment_step (f : Layout) (r : Fin 9)
    (inside : f.pc < 3089) (room : 2 ≤ f.gapWidth) (margin : 31 ≤ f.gap)
    (nine : f.stored.size = 9) (reg : r.val = (Source.siteAt f.pc).argument)
    (op : (Source.siteAt f.pc).op = Source.Primitive.inc) :
    ∃ t, 0 < t ∧ TM.run Selected.machine t f.config = (f.afterIncrement r).config := by
  let value := f.storedAt r.val
  let extra := f.gapWidth-2
  let earlier := f.beforeReg r
  let following := f.afterReg r
  let dest := f.afterIncrement r
  have active : Phase.enabled (Source.siteAt f.pc) 0 = true := by simp [Phase.enabled,op]
  have selected : Carry.selected f.pc false = true := by simp [Carry.selected,op,Source.Primitive.inc]
  have width : extra+1 = f.gapWidth-1 := by dsimp [extra]; omega
  have values : dest.values = earlier ++ (value+1) :: (following ++ [0]) :=
    f.updateValues r (value+1) [0] nine
  obtain ⟨t,pt,prep⟩ := Ingress.from_canonical f r 4 inside active room reg
  obtain ⟨u,wu⟩ := increment_word f.pc extra value earlier following
  have oper : TM.run Selected.machine u (Ingress.execConfig f r 4) =
      f.carryConfig false extra dest.values 1 := by
    have core := wu.exact_run (f.head-9) blankOutside
    rw [values]
    simpa only [Ingress.execConfig,Ingress.execState,op,beq_self_eq_true,ite_true,Ingress.execWord,
      Layout.carryConfig,value,earlier,following,width,Int.add_assoc] using core
  have height := f.carry_geometry_inc room
  obtain ⟨v,cleanup⟩ := f.carry_restore false extra 0
    (f.stored.setIfInBounds r.val (value+1)) (f.spares++[0]) inside selected
    (by change 40 ≤ (Carry.initialWord f.pc false).length+(f.gapWidth-2); omega) height
  refine ⟨(t+u)+v,by omega,?_⟩
  rw [TM.run_add,TM.run_add,prep,oper]
  exact cleanup

#print axioms Layout.increment_step
end NF192.Frame
