module
public import ArithmeticPhaseComplete

@[expose] public section

namespace NF192.Phase

set_option maxRecDepth 100000
set_option maxHeartbeats 0

/-- The count includes every literal site and keeps the displaced entries distinct. -/
def siteCountFor (ph : Nat) : Nat :=
  ((List.range Source.siteCount).filter (fun i => enabled (Source.siteAt i) ph)).length

theorem arithmetic_phase_counts :
    siteCountFor 0 = 2133 ∧ siteCountFor 1 = 2133 ∧
    siteCountFor 2 = 2133 ∧ siteCountFor 3 = 61 := by decide +kernel

/-- Verify the numeric state indices used by the decoder against literal names. -/
theorem decoder_target_names :
    Selected.name Selected.decoderRoot = "d:0" ∧
    Selected.name 178 = "k:49" ∧ Selected.name 167 = "k:24" ∧
    Selected.name 185 = "k:64" ∧ Selected.name 159 = "k:0" ∧
    (List.range 9).map (fun r => Selected.name (selector r)) =
      ["k:22", "k:25", "k:51", "k:32", "k:48", "k:55", "k:60", "k:33", "k:36"] := by decide +kernel

end NF192.Phase
