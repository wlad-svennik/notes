module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases00_00 : List Case := [
  ⟨0, false, 1, false, 13, 1, 20⟩,
  ⟨0, true, 2, false, 12, 2, 19⟩,
  ⟨2, false, 3, false, 13, 1, 20⟩,
  ⟨3, false, 4, false, 15, 1, 22⟩,
  ⟨3, true, 7, false, 14, 2, 21⟩,
  ⟨4, false, 5, false, 16, 1, 23⟩,
  ⟨5, false, 6, false, 17, 1, 24⟩,
  ⟨7, false, 8, false, 15, 1, 22⟩]
theorem carryCases00_00_verified : carryCases00_00.all verified = true := by decide

def carryCases00_01 : List Case := [
  ⟨7, true, 10, false, 11, 5, 18⟩,
  ⟨8, false, 9, false, 16, 1, 23⟩,
  ⟨10, false, 11, false, 13, 1, 20⟩,
  ⟨10, true, 18, false, 12, 2, 19⟩,
  ⟨11, false, 12, false, 15, 1, 22⟩,
  ⟨12, false, 13, false, 17, 1, 24⟩,
  ⟨12, true, 14, false, 16, 2, 23⟩,
  ⟨14, false, 15, false, 17, 1, 24⟩]
theorem carryCases00_01_verified : carryCases00_01.all verified = true := by decide

def carryCases00_02 : List Case := [
  ⟨14, true, 17, false, 14, 4, 21⟩,
  ⟨15, false, 16, false, 18, 1, 25⟩,
  ⟨18, false, 19, false, 13, 1, 20⟩,
  ⟨18, true, 21, false, 10, 4, 17⟩,
  ⟨19, false, 20, false, 14, 1, 21⟩,
  ⟨21, false, 22, false, 12, 1, 19⟩,
  ⟨21, true, 24, false, 11, 2, 18⟩,
  ⟨22, false, 23, false, 13, 1, 20⟩]
theorem carryCases00_02_verified : carryCases00_02.all verified = true := by decide

def carryCases00_03 : List Case := [
  ⟨24, false, 25, false, 14, 1, 21⟩,
  ⟨24, true, 32, false, 13, 2, 20⟩,
  ⟨25, false, 26, false, 16, 1, 23⟩,
  ⟨26, false, 27, false, 18, 1, 25⟩,
  ⟨26, true, 28, false, 17, 2, 24⟩,
  ⟨28, false, 29, false, 18, 1, 25⟩,
  ⟨28, true, 31, false, 15, 4, 22⟩,
  ⟨29, false, 30, false, 19, 1, 26⟩]
theorem carryCases00_03_verified : carryCases00_03.all verified = true := by decide

def carryCases00_04 : List Case := [
  ⟨32, false, 33, false, 14, 1, 21⟩,
  ⟨32, true, 35, false, 12, 3, 19⟩,
  ⟨33, false, 34, false, 15, 1, 22⟩,
  ⟨35, false, 36, false, 13, 1, 20⟩,
  ⟨35, true, 38, false, 9, 5, 16⟩,
  ⟨36, false, 37, false, 14, 1, 21⟩,
  ⟨38, false, 39, false, 11, 1, 18⟩,
  ⟨38, true, 3017, false, 10, 2, 17⟩]
theorem carryCases00_04_verified : carryCases00_04.all verified = true := by decide

def carryCases00_05 : List Case := [
  ⟨39, false, 40, false, 14, 1, 21⟩,
  ⟨39, true, 2969, false, 13, 2, 20⟩,
  ⟨40, false, 41, false, 19, 1, 26⟩,
  ⟨40, true, 48, false, 18, 2, 25⟩,
  ⟨41, false, 42, false, 21, 1, 28⟩,
  ⟨42, false, 43, false, 23, 1, 30⟩,
  ⟨42, true, 44, false, 22, 2, 29⟩,
  ⟨44, false, 45, false, 23, 1, 30⟩]
theorem carryCases00_05_verified : carryCases00_05.all verified = true := by decide

def carryCases00_06 : List Case := [
  ⟨44, true, 47, false, 20, 4, 27⟩,
  ⟨45, false, 46, false, 24, 1, 31⟩,
  ⟨48, false, 49, false, 19, 1, 26⟩,
  ⟨48, true, 51, false, 17, 3, 24⟩,
  ⟨49, false, 50, false, 20, 1, 27⟩,
  ⟨51, false, 52, false, 21, 1, 28⟩,
  ⟨51, true, 54, false, 20, 2, 27⟩,
  ⟨52, false, 53, false, 22, 1, 29⟩]
theorem carryCases00_06_verified : carryCases00_06.all verified = true := by decide

def carryCases00_07 : List Case := [
  ⟨54, false, 55, false, 25, 1, 32⟩,
  ⟨54, true, 57, false, 24, 2, 31⟩,
  ⟨55, false, 56, false, 26, 1, 33⟩,
  ⟨57, false, 58, false, 26, 1, 33⟩,
  ⟨57, true, 60, false, 25, 2, 32⟩,
  ⟨58, false, 59, false, 27, 1, 34⟩,
  ⟨60, false, 61, false, 28, 1, 35⟩,
  ⟨60, true, 64, false, 27, 2, 34⟩]
theorem carryCases00_07_verified : carryCases00_07.all verified = true := by decide

def carryCases00_08 : List Case := [
  ⟨61, false, 62, false, 29, 1, 36⟩,
  ⟨62, false, 63, false, 30, 1, 37⟩,
  ⟨64, false, 65, false, 28, 1, 35⟩,
  ⟨64, true, 70, false, 26, 3, 33⟩,
  ⟨65, false, 66, false, 30, 1, 37⟩,
  ⟨66, false, 67, false, 31, 1, 38⟩,
  ⟨66, true, 69, false, 29, 3, 36⟩,
  ⟨67, false, 68, false, 32, 1, 39⟩]
theorem carryCases00_08_verified : carryCases00_08.all verified = true := by decide

def carryCases00_09 : List Case := [
  ⟨70, false, 71, false, 27, 1, 34⟩,
  ⟨70, true, 73, false, 23, 5, 30⟩,
  ⟨71, false, 72, false, 28, 1, 35⟩,
  ⟨73, false, 74, false, 25, 1, 32⟩,
  ⟨73, true, 77, false, 24, 2, 31⟩,
  ⟨74, false, 75, false, 26, 1, 33⟩,
  ⟨75, false, 76, false, 27, 1, 34⟩,
  ⟨77, false, 78, false, 25, 1, 32⟩]
theorem carryCases00_09_verified : carryCases00_09.all verified = true := by decide

def carryCases00_10 : List Case := [
  ⟨77, true, 80, false, 22, 4, 29⟩,
  ⟨78, false, 79, false, 26, 1, 33⟩,
  ⟨80, false, 81, false, 25, 1, 32⟩,
  ⟨80, true, 83, false, 24, 2, 31⟩,
  ⟨81, false, 82, false, 26, 1, 33⟩,
  ⟨83, false, 84, false, 26, 1, 33⟩,
  ⟨83, true, 86, false, 25, 2, 32⟩,
  ⟨84, false, 85, false, 27, 1, 34⟩]
theorem carryCases00_10_verified : carryCases00_10.all verified = true := by decide

def carryCases00_11 : List Case := [
  ⟨86, false, 87, false, 28, 1, 35⟩,
  ⟨86, true, 90, false, 27, 2, 34⟩,
  ⟨87, false, 88, false, 29, 1, 36⟩,
  ⟨88, false, 89, false, 30, 1, 37⟩,
  ⟨90, false, 91, false, 28, 1, 35⟩,
  ⟨90, true, 96, false, 26, 3, 33⟩,
  ⟨91, false, 92, false, 30, 1, 37⟩,
  ⟨92, false, 93, false, 31, 1, 38⟩]
theorem carryCases00_11_verified : carryCases00_11.all verified = true := by decide

def carryCases00 : List Case := carryCases00_00 ++ carryCases00_01 ++ carryCases00_02 ++ carryCases00_03 ++ carryCases00_04 ++ carryCases00_05 ++ carryCases00_06 ++ carryCases00_07 ++ carryCases00_08 ++ carryCases00_09 ++ carryCases00_10 ++ carryCases00_11
theorem carryCases00_verified : carryCases00.all verified = true := by
  simp only [carryCases00, List.all_append, carryCases00_00_verified, carryCases00_01_verified, carryCases00_02_verified, carryCases00_03_verified, carryCases00_04_verified, carryCases00_05_verified, carryCases00_06_verified, carryCases00_07_verified, carryCases00_08_verified, carryCases00_09_verified, carryCases00_10_verified, carryCases00_11_verified, Bool.and_self]
theorem carryCases00_covered : carryCases00.map (fun c => key c.pc c.zero) = keysBetween 0 185 := by decide
theorem carryCases00_count : carryCases00.length = 96 := by decide
end NF192.Carry
