module
public import NumericalCold

@[expose] public section

/-! The initially signed countdown source reaches its first ordinary command
boundary, carrying three correctly generated AX batches and a sound proof
stack. The first 16,813 binary transitions reaching this source phase are
certified separately in MachineBoot. -/

set_option maxHeartbeats 0
set_option maxRecDepth 50000

namespace NF192.Emitter

open Numerical Registers ProofSearch

theorem frozenDecZero (pc yes no : Nat) (r : Register) (rs : Registers)
    (op : frozen pc = .dec r yes no) (hz : rs r = 0) :
    Reaches frozen ⟨pc,rs⟩ (some ⟨yes,rs⟩) := by
  apply Reaches.one
  simp [step, op, hz]

def popCache : Code := .seq Literal.seq160 Literal.seq207

theorem frozen_pop_embedded : Embedded frozen popCache 3002 3016 [] [] :=
  frozen_placement (embedded_of_matches _ _ _ (by decide)) (by decide)

theorem popCache_eval (top stack : Nat) :
    Eval popCache (mk9 0 top stack 0 0 0 0 0 0) .normal
      (mk9 0 top (Cantor.unpair stack).2 0 0 (Cantor.unpair stack).1 0 0 0) := by
  apply Eval.seq_normal (seq160_normal 0 top stack 0 0 0 0)
  simpa only [Nat.zero_add] using seq207_eval 0 top (Cantor.unpair stack).2 0 0 0 (Cantor.unpair stack).1 0 0

theorem frozen_nip_to_refill (ts : Nat×Nat) :
    Reaches frozen (coldFrame 2969 0 ts)
      (some ⟨2,mk9 0 ts.1 (Cantor.unpair ts.2).2 0 0 (Cantor.unpair ts.2).1 0 0 0⟩) := by
  apply (frozenDecZero 2969 2996 2970 4 _ (by decide) rfl).trans
  apply (frozenDecZero 2996 3000 2997 5 _ (by decide) rfl).trans
  apply (frozenDecZero 3000 3002 3001 5 _ (by decide) rfl).trans
  apply ((popCache_eval ts.1 ts.2).compiled frozen 3002 3016 [] [] frozen_pop_embedded).trans
  apply (frozenJump 3016 0 _ (by decide)).trans
  exact frozenDecZero 0 2 1 8 _ (by decide) rfl

def startProof : ProofSearch.State := ⟨0,[],0,0⟩

def startupProof : ProofSearch.State :=
  afterAX startProof (rows 0 0 0 [(0,0),(0,0)] startProof)

theorem startupPayload_matches : startupPayload =
    (startupProof.top, pair startupProof.cache (ProofSearch.pack startupProof.stack)) := by
  let xs := rows 0 0 0 [(0,0),(0,0)] startProof
  calc
    startupPayload = pushRows (startProof.top,ProofSearch.pack startProof.stack) xs := by
      simp only [startupPayload, coldPayload, xs, rows, tailRows, startProof, List.length_cons,
        List.length_nil, Nat.zero_add, List.append_nil, ProofSearch.pack, pushRows_append]
    _ = _ := payload_afterAX startProof xs (by dsimp only [xs]; rw [rows_length]; omega)

theorem startupProof_sound : startupProof.Sound := by
  apply step_sound (.ax 0 0 0 [(0,0),(0,0)]) startProof
  exact ⟨deriv_zero, by simp [startProof], deriv_zero⟩

theorem frozen_prefix :
    Reaches frozen (coldFrame 40 2 (0,0))
      (some ⟨2,mk9 0 startupProof.top (ProofSearch.pack startupProof.stack) 0 0 startupProof.cache 0 0 0⟩) := by
  have h := frozen_three_batches.trans (frozen_nip_to_refill startupPayload)
  rw [startupPayload_matches, Cantor.unpair_pair] at h
  exact h

theorem first_increment (top stack cache : Nat) :
    bootstrapStep (true,atFrame 2 ⟨0,top,stack,0,0,cache,0⟩) =
      (false,atFrame 3 ⟨0,top,stack,0,0,cache,0⟩) := by
  have inst : Source.program 2 = Source.Command.inc 0 3 := by decide
  have finst : actual 2 = .inc 0 3 := by decide
  have same : Source.setReg (liftRegisters (mk9 0 top stack 0 0 cache 0 0 0)) 0 0 =
      liftRegisters (mk9 0 top stack 0 0 cache 0 0 0) :=
    (liftRegisters_set _ (0 : Register) 0).trans (congrArg liftRegisters (mk9_set_0 _ _ _ _ _ _ _ _ _ _))
  simp only [bootstrapStep, atFrame, Frame.regs, Source.Config.active, finst, inst, usesCounter,
    Bool.true_eq, if_true, same] <;> rfl

theorem warm_skip (top stack cache : Nat) :
    bootstrapAdvance 3 (true,atFrame 2 ⟨0,top,stack,0,0,cache,0⟩) =
      (false,atFrame 10 ⟨0,top,stack,0,0,cache,0⟩) := by
  let f : Frame := ⟨0,top,stack,0,0,cache,0⟩
  have three : Source.program 3 = Source.Command.dec 0 7 4 false := by decide
  have seven : Source.program 7 = Source.Command.dec 6 10 8 false := by decide
  have c₃ : Source.step (atFrame 3 f) = atFrame 7 f := by
    simp only [atFrame, Source.step, three]
    rfl
  have c₇ : Source.step (atFrame 7 f) = atFrame 10 f := by
    simp only [atFrame, Source.step, seven]
    rfl
  have h := first_increment top stack cache
  change bootstrapStep (bootstrapStep (bootstrapStep (true,atFrame 2 f))) = _
  rw [show bootstrapStep (true,atFrame 2 f) = (false,atFrame 3 f) from h]
  change (false, Source.step (Source.step (atFrame 3 f))) = _
  rw [c₃,c₇]

/-- From the first AX, with logical R0=-1, to a natural-register state at
ordinal 10 with logical R0=0. -/
theorem signed_startup :
    ∃ n, 0 < n ∧ bootstrapAdvance n (true,atFrame 40 ⟨0,0,0,2,0,0,0⟩) =
      (false,atFrame 10 ⟨0,startupProof.top,ProofSearch.pack startupProof.stack,0,0,startupProof.cache,0⟩) := by
  obtain ⟨n, hn, h⟩ := frozen_prefix
  have left := frozen_run n h
  change bootstrapAdvance n (true,atFrame 40 ⟨0,0,0,2,0,0,0⟩) =
    (true,atFrame 2 ⟨0,startupProof.top,ProofSearch.pack startupProof.stack,0,0,startupProof.cache,0⟩) at left
  exact ⟨n+3, by omega, by rw [bootstrapAdvance_add,left,warm_skip]⟩

#print axioms signed_startup
end NF192.Emitter
