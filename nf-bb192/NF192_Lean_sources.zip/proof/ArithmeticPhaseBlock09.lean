module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block2304 : checkRange 2304 32 = true := by decide +kernel
theorem block2336 : checkRange 2336 32 = true := by decide +kernel
theorem block2368 : checkRange 2368 32 = true := by decide +kernel
theorem block2400 : checkRange 2400 32 = true := by decide +kernel
theorem block2432 : checkRange 2432 32 = true := by decide +kernel
theorem block2464 : checkRange 2464 32 = true := by decide +kernel
theorem block2496 : checkRange 2496 32 = true := by decide +kernel
theorem block2528 : checkRange 2528 32 = true := by decide +kernel

end NF192.Phase
