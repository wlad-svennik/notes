module
public import MachineArithmeticReturns

@[expose] public section
namespace NF192.ArithmeticReturn
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block2560 : checkRange 2560 32 = true := by decide +kernel
theorem block2592 : checkRange 2592 32 = true := by decide +kernel
theorem block2624 : checkRange 2624 32 = true := by decide +kernel
theorem block2656 : checkRange 2656 32 = true := by decide +kernel
theorem block2688 : checkRange 2688 32 = true := by decide +kernel
theorem block2720 : checkRange 2720 32 = true := by decide +kernel
theorem block2752 : checkRange 2752 32 = true := by decide +kernel
theorem block2784 : checkRange 2784 32 = true := by decide +kernel
theorem block2816 : checkRange 2816 32 = true := by decide +kernel
theorem block2848 : checkRange 2848 32 = true := by decide +kernel
theorem block2880 : checkRange 2880 32 = true := by decide +kernel
theorem block2912 : checkRange 2912 32 = true := by decide +kernel
theorem block2944 : checkRange 2944 32 = true := by decide +kernel
theorem block2976 : checkRange 2976 32 = true := by decide +kernel
theorem block3008 : checkRange 3008 32 = true := by decide +kernel
theorem block3040 : checkRange 3040 32 = true := by decide +kernel

end NF192.ArithmeticReturn
