module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases32_00 : List Case := [
  ⟨3068, false, 3069, false, 14, 1, 21⟩,
  ⟨3068, true, 3071, false, 13, 2, 20⟩,
  ⟨3069, false, 3070, false, 15, 1, 22⟩,
  ⟨3071, false, 3072, false, 14, 1, 21⟩,
  ⟨3071, true, 3078, false, 12, 3, 19⟩,
  ⟨3072, false, 3073, false, 16, 1, 23⟩,
  ⟨3072, true, 3074, false, 15, 2, 22⟩,
  ⟨3074, false, 3075, false, 16, 1, 23⟩]
theorem carryCases32_00_verified : carryCases32_00.all verified = true := by decide

def carryCases32_01 : List Case := [
  ⟨3075, false, 3076, false, 17, 1, 24⟩,
  ⟨3075, true, 3078, false, 12, 6, 19⟩,
  ⟨3076, false, 3077, false, 18, 1, 25⟩,
  ⟨3078, false, 3079, false, 15, 1, 22⟩,
  ⟨3078, true, 3080, false, 14, 2, 21⟩,
  ⟨3080, false, 3081, false, 16, 1, 23⟩,
  ⟨3080, true, 3084, false, 15, 2, 22⟩,
  ⟨3081, false, 3082, false, 17, 1, 24⟩]
theorem carryCases32_01_verified : carryCases32_01.all verified = true := by decide

def carryCases32_02 : List Case := [
  ⟨3082, false, 3083, false, 18, 1, 25⟩,
  ⟨3084, false, 3085, false, 16, 1, 23⟩,
  ⟨3084, true, 3087, false, 13, 4, 20⟩,
  ⟨3085, false, 3086, false, 17, 1, 24⟩,
  ⟨3087, false, 3088, false, 14, 1, 21⟩,
  ⟨3087, true, 0, true, 7, 8, 15⟩]
theorem carryCases32_02_verified : carryCases32_02.all verified = true := by decide

def carryCases32 : List Case := carryCases32_00 ++ carryCases32_01 ++ carryCases32_02
theorem carryCases32_verified : carryCases32.all verified = true := by
  simp only [carryCases32, List.all_append, carryCases32_00_verified, carryCases32_01_verified, carryCases32_02_verified, Bool.and_self]
theorem carryCases32_covered : carryCases32.map (fun c => key c.pc c.zero) = keysBetween 6136 42 := by decide
theorem carryCases32_count : carryCases32.length = 22 := by decide
end NF192.Carry
