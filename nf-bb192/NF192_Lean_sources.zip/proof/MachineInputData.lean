module
public import MachineInputFragments
public import MachineSourceData
public import MachineTable
@[expose] public section

namespace NF192.Input

set_option maxRecDepth 100000
set_option maxHeartbeats 0

def tmFragments : List (List String) := input_fragments% "../machine/NF_192_countdown.tm" "\n"
def sourceFragments : List (List String) := input_fragments% "../machine/countdown.sites.json" "],"

theorem table_fragments :
    tmFragments.flatten = "#! start k:64\n" :: Selected.literalRows ++ [""] := by decide

theorem exact_transition_table :
    Selected.serializedTable = String.join tmFragments.flatten := by
  rw [Selected.table_matches_literal,table_fragments]
  simp [Selected.literalTable,String.join_cons,String.join_append]

def addressChars : Nat → Nat → List Char
  | 0, _ => []
  | n+1, a => addressChars n (a/2) ++ [if a%2=1 then '1' else '0']

def renderSourceRow (s : Source.Site) : String :=
  let op := if s.op == Source.Primitive.inc then "CI" else if s.op == Source.Primitive.dec then "CD"
            else if s.op == Source.Primitive.brk then "CB" else "CC"
  "[\"" ++ String.ofList (addressChars s.depth s.address) ++ "\",\"" ++ op ++ "\"," ++
    (#["0","1","2","3","4","5","6","7","8"][s.argument]?.getD "?") ++ "]"

def sourceFragment (i : Nat) : String :=
  (if i = 0 then "[" else "") ++ renderSourceRow (Source.siteAt i) ++
    (if i+1 = Source.siteCount then "]\n" else ",")

def computedBlock (i : Nat) : List String :=
  (List.range (min 32 (Source.siteCount-i*32))).map (fun j => sourceFragment (i*32+j))

def literalBlock (i : Nat) : List String := sourceFragments[i]?.getD []

theorem original_block_count : sourceFragments.length = 97 := by decide

end NF192.Input
