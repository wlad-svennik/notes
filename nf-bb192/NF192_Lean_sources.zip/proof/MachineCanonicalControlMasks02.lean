module
public import MachineCanonicalControlMasks

@[expose] public section
namespace NF192.CanonicalControl
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem mask1024 : checkRange 1024 32 = true := by decide +kernel
theorem mask1056 : checkRange 1056 32 = true := by decide +kernel
theorem mask1088 : checkRange 1088 32 = true := by decide +kernel
theorem mask1120 : checkRange 1120 32 = true := by decide +kernel
theorem mask1152 : checkRange 1152 32 = true := by decide +kernel
theorem mask1184 : checkRange 1184 32 = true := by decide +kernel
theorem mask1216 : checkRange 1216 32 = true := by decide +kernel
theorem mask1248 : checkRange 1248 32 = true := by decide +kernel
theorem mask1280 : checkRange 1280 32 = true := by decide +kernel
theorem mask1312 : checkRange 1312 32 = true := by decide +kernel
theorem mask1344 : checkRange 1344 32 = true := by decide +kernel
theorem mask1376 : checkRange 1376 32 = true := by decide +kernel
theorem mask1408 : checkRange 1408 32 = true := by decide +kernel
theorem mask1440 : checkRange 1440 32 = true := by decide +kernel
theorem mask1472 : checkRange 1472 32 = true := by decide +kernel
theorem mask1504 : checkRange 1504 32 = true := by decide +kernel
end NF192.CanonicalControl
