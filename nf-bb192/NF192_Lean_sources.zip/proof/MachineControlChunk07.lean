module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases07_00 : List Case := [
  ⟨1445, false, 15919041280, 3034139392, 66, 0, 0⟩,
  ⟨1446, false, 1960397568, 81349376, 58, 0, 0⟩,
  ⟨1450, false, 2094615296, 215567104, 60, 0, 0⟩,
  ⟨1455, true, 2849590016, 433670912, 30, 28, 35⟩,
  ⟨1458, false, 8218299136, 1775848192, 66, 0, 0⟩,
  ⟨1459, false, 433670912, 31017728, 58, 0, 0⟩,
  ⟨1462, false, 500779776, 98126592, 58, 0, 0⟩,
  ⟨1466, false, 1943620352, 64572160, 60, 0, 0⟩
]

theorem cases07_00_verified : cases07_00.all verified = true := by decide

def cases07_01 : List Case := [
  ⟨1471, false, 7983418112, 1540967168, 64, 0, 0⟩,
  ⟨1472, false, 1004096256, 64572160, 56, 0, 0⟩,
  ⟨1476, false, 1071205120, 131681024, 58, 0, 0⟩,
  ⟨1479, false, 205081344, 3754752, 52, 0, 0⟩,
  ⟨1482, false, 439962368, 37309184, 56, 0, 0⟩,
  ⟨1486, false, 3862514432, 104418048, 62, 0, 0⟩,
  ⟨1491, false, 15942109952, 3057208064, 66, 0, 0⟩,
  ⟨1492, false, 1983466240, 104418048, 58, 0, 0⟩
]

theorem cases07_01_verified : cases07_01.all verified = true := by decide

def cases07_02 : List Case := [
  ⟨1495, false, 1043942144, 238635776, 60, 0, 0⟩,
  ⟨1501, false, 414796544, 12143360, 56, 0, 0⟩,
  ⟨1504, false, 884558592, 79252224, 60, 0, 0⟩,
  ⟨1508, false, 7729662720, 213469952, 66, 0, 0⟩,
  ⟨1513, false, 31888853760, 6119049984, 70, 0, 0⟩,
  ⟨1514, false, 3971566336, 213469952, 62, 0, 0⟩,
  ⟨1517, false, 2092518144, 481905408, 64, 0, 0⟩,
  ⟨1521, false, 985221888, 45697792, 58, 0, 0⟩
]

theorem cases07_02_verified : cases07_02.all verified = true := by decide

def cases07_03 : List Case := [
  ⟨1524, false, 515459840, 112806656, 56, 0, 0⟩,
  ⟨1528, true, 5666065152, 834226944, 31, 29, 36⟩,
  ⟨1531, false, 16403483392, 3518581504, 68, 0, 0⟩,
  ⟨1532, false, 834226944, 28920576, 60, 0, 0⟩,
  ⟨1535, false, 968444672, 163138304, 60, 0, 0⟩,
  ⟨1539, false, 3854125824, 96029440, 62, 0, 0⟩,
  ⟨1544, false, 15933721344, 3048819456, 66, 0, 0⟩,
  ⟨1545, false, 1975077632, 96029440, 58, 0, 0⟩
]

theorem cases07_03_verified : cases07_03.all verified = true := by decide

def cases07_04 : List Case := [
  ⟨1549, false, 2109295360, 230247168, 60, 0, 0⟩,
  ⟨1553, false, 410602240, 7949056, 56, 0, 0⟩,
  ⟨1556, false, 880364288, 75057920, 60, 0, 0⟩,
  ⟨1560, false, 7725468416, 209275648, 66, 0, 0⟩,
  ⟨1565, false, 31884659456, 6114855680, 70, 0, 0⟩,
  ⟨1566, false, 3967372032, 209275648, 62, 0, 0⟩,
  ⟨1569, false, 2088323840, 477711104, 64, 0, 0⟩,
  ⟨1573, false, 981027584, 41503488, 58, 0, 0⟩
]

theorem cases07_04_verified : cases07_04.all verified = true := by decide

def cases07_05 : List Case := [
  ⟨1576, false, 511265536, 108612352, 62, 0, 0⟩,
  ⟨1580, true, 5661870848, 830032640, 31, 29, 36⟩,
  ⟨1583, false, 16399289088, 3514387200, 68, 0, 0⟩,
  ⟨1584, false, 830032640, 24726272, 60, 0, 0⟩,
  ⟨1587, false, 964250368, 158944000, 60, 0, 0⟩,
  ⟨1591, false, 3849931520, 91835136, 62, 0, 0⟩,
  ⟨1596, false, 15929527040, 3044625152, 66, 0, 0⟩,
  ⟨1597, false, 1970883328, 91835136, 58, 0, 0⟩
]

theorem cases07_05_verified : cases07_05.all verified = true := by decide

def cases07_06 : List Case := [
  ⟨1601, false, 2105101056, 226052864, 60, 0, 0⟩,
  ⟨1605, false, 821644032, 16337664, 56, 0, 0⟩,
  ⟨1608, false, 1761168128, 150555392, 60, 0, 0⟩,
  ⟨1612, false, 15451376384, 418990848, 66, 0, 0⟩,
  ⟨1617, false, 63769758464, 12230150912, 70, 0, 0⟩,
  ⟨1618, false, 7935183616, 418990848, 62, 0, 0⟩,
  ⟨1621, false, 4177087232, 955861760, 64, 0, 0⟩,
  ⟨1625, false, 1022970624, 83446528, 56, 0, 0⟩
]

theorem cases07_06_verified : cases07_06.all verified = true := by decide

def cases07_07 : List Case := [
  ⟨1628, false, 251218688, 49892096, 52, 0, 0⟩,
  ⟨1632, true, 5670259456, 838421248, 31, 29, 36⟩,
  ⟨1635, false, 16407677696, 3522775808, 68, 0, 0⟩,
  ⟨1636, false, 838421248, 33114880, 60, 0, 0⟩,
  ⟨1639, false, 972638976, 167332608, 60, 0, 0⟩,
  ⟨1643, false, 3858320128, 100223744, 62, 0, 0⟩,
  ⟨1648, false, 15937915648, 3053013760, 66, 0, 0⟩,
  ⟨1649, false, 1979271936, 100223744, 58, 0, 0⟩
]

theorem cases07_07_verified : cases07_07.all verified = true := by decide

def cases07 : List Case := cases07_00 ++ cases07_01 ++ cases07_02 ++ cases07_03 ++ cases07_04 ++ cases07_05 ++ cases07_06 ++ cases07_07

theorem cases07_verified : cases07.all verified = true := by
  simp only [cases07, List.all_append, cases07_00_verified, cases07_01_verified, cases07_02_verified, cases07_03_verified, cases07_04_verified, cases07_05_verified, cases07_06_verified, cases07_07_verified, Bool.and_self]

end NF192.Control
