module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases06_00 : List Case := [
  ⟨573, false, 574, false, 33, 1, 40⟩,
  ⟨575, false, 576, false, 34, 1, 41⟩,
  ⟨575, true, 579, false, 33, 2, 40⟩,
  ⟨576, false, 577, false, 35, 1, 42⟩,
  ⟨577, false, 578, false, 36, 1, 43⟩,
  ⟨579, false, 580, false, 34, 1, 41⟩,
  ⟨579, true, 585, false, 32, 3, 39⟩,
  ⟨580, false, 581, false, 36, 1, 43⟩]
theorem carryCases06_00_verified : carryCases06_00.all verified = true := by decide

def carryCases06_01 : List Case := [
  ⟨581, false, 582, false, 37, 1, 44⟩,
  ⟨581, true, 584, false, 35, 3, 42⟩,
  ⟨582, false, 583, false, 38, 1, 45⟩,
  ⟨585, false, 586, false, 33, 1, 40⟩,
  ⟨585, true, 588, false, 29, 5, 36⟩,
  ⟨586, false, 587, false, 34, 1, 41⟩,
  ⟨588, false, 589, false, 31, 1, 38⟩,
  ⟨588, true, 592, false, 30, 2, 37⟩]
theorem carryCases06_01_verified : carryCases06_01.all verified = true := by decide

def carryCases06_02 : List Case := [
  ⟨589, false, 590, false, 32, 1, 39⟩,
  ⟨590, false, 591, false, 33, 1, 40⟩,
  ⟨592, false, 593, false, 31, 1, 38⟩,
  ⟨592, true, 595, false, 28, 4, 35⟩,
  ⟨593, false, 594, false, 32, 1, 39⟩,
  ⟨595, false, 596, false, 32, 1, 39⟩,
  ⟨595, true, 603, false, 31, 2, 38⟩,
  ⟨596, false, 597, false, 34, 1, 41⟩]
theorem carryCases06_02_verified : carryCases06_02.all verified = true := by decide

def carryCases06_03 : List Case := [
  ⟨597, false, 598, false, 36, 1, 43⟩,
  ⟨597, true, 599, false, 35, 2, 42⟩,
  ⟨599, false, 600, false, 36, 1, 43⟩,
  ⟨599, true, 602, false, 33, 4, 40⟩,
  ⟨600, false, 601, false, 37, 1, 44⟩,
  ⟨603, false, 604, false, 32, 1, 39⟩,
  ⟨603, true, 606, false, 30, 3, 37⟩,
  ⟨604, false, 605, false, 33, 1, 40⟩]
theorem carryCases06_03_verified : carryCases06_03.all verified = true := by decide

def carryCases06_04 : List Case := [
  ⟨606, false, 607, false, 33, 1, 40⟩,
  ⟨606, true, 610, false, 32, 2, 39⟩,
  ⟨607, false, 608, false, 34, 1, 41⟩,
  ⟨608, false, 609, false, 35, 1, 42⟩,
  ⟨610, false, 611, false, 33, 1, 40⟩,
  ⟨610, true, 616, false, 31, 3, 38⟩,
  ⟨611, false, 612, false, 35, 1, 42⟩,
  ⟨612, false, 613, false, 36, 1, 43⟩]
theorem carryCases06_04_verified : carryCases06_04.all verified = true := by decide

def carryCases06_05 : List Case := [
  ⟨612, true, 615, false, 34, 3, 41⟩,
  ⟨613, false, 614, false, 37, 1, 44⟩,
  ⟨616, false, 617, false, 32, 1, 39⟩,
  ⟨616, true, 620, false, 29, 4, 36⟩,
  ⟨617, false, 618, false, 33, 1, 40⟩,
  ⟨618, false, 619, false, 34, 1, 41⟩,
  ⟨620, false, 621, false, 27, 3, 34⟩,
  ⟨621, false, 622, false, 32, 1, 39⟩]
theorem carryCases06_05_verified : carryCases06_05.all verified = true := by decide

def carryCases06_06 : List Case := [
  ⟨621, true, 624, false, 31, 2, 38⟩,
  ⟨622, false, 623, false, 33, 1, 40⟩,
  ⟨624, false, 625, false, 33, 1, 40⟩,
  ⟨624, true, 627, false, 32, 2, 39⟩,
  ⟨625, false, 626, false, 34, 1, 41⟩,
  ⟨627, false, 628, false, 35, 1, 42⟩,
  ⟨627, true, 631, false, 34, 2, 41⟩,
  ⟨628, false, 629, false, 36, 1, 43⟩]
theorem carryCases06_06_verified : carryCases06_06.all verified = true := by decide

def carryCases06_07 : List Case := [
  ⟨629, false, 630, false, 37, 1, 44⟩,
  ⟨631, false, 632, false, 35, 1, 42⟩,
  ⟨631, true, 637, false, 33, 3, 40⟩,
  ⟨632, false, 633, false, 37, 1, 44⟩,
  ⟨633, false, 634, false, 38, 1, 45⟩,
  ⟨633, true, 636, false, 36, 3, 43⟩,
  ⟨634, false, 635, false, 39, 1, 46⟩,
  ⟨637, false, 638, false, 34, 1, 41⟩]
theorem carryCases06_07_verified : carryCases06_07.all verified = true := by decide

def carryCases06_08 : List Case := [
  ⟨637, true, 640, false, 30, 5, 37⟩,
  ⟨638, false, 639, false, 35, 1, 42⟩,
  ⟨640, false, 641, false, 31, 1, 38⟩,
  ⟨640, true, 644, false, 29, 3, 36⟩,
  ⟨641, false, 642, false, 32, 1, 39⟩,
  ⟨642, false, 643, false, 33, 1, 40⟩,
  ⟨644, false, 645, false, 30, 1, 37⟩,
  ⟨644, true, 647, false, 28, 3, 35⟩]
theorem carryCases06_08_verified : carryCases06_08.all verified = true := by decide

def carryCases06_09 : List Case := [
  ⟨645, false, 646, false, 31, 1, 38⟩,
  ⟨647, false, 648, false, 32, 1, 39⟩,
  ⟨647, true, 655, false, 31, 2, 38⟩,
  ⟨648, false, 649, false, 34, 1, 41⟩,
  ⟨649, false, 650, false, 36, 1, 43⟩,
  ⟨649, true, 651, false, 35, 2, 42⟩,
  ⟨651, false, 652, false, 36, 1, 43⟩,
  ⟨651, true, 654, false, 33, 4, 40⟩]
theorem carryCases06_09_verified : carryCases06_09.all verified = true := by decide

def carryCases06_10 : List Case := [
  ⟨652, false, 653, false, 37, 1, 44⟩,
  ⟨655, false, 656, false, 32, 1, 39⟩,
  ⟨655, true, 658, false, 30, 3, 37⟩,
  ⟨656, false, 657, false, 33, 1, 40⟩,
  ⟨658, false, 659, false, 33, 1, 40⟩,
  ⟨658, true, 662, false, 32, 2, 39⟩,
  ⟨659, false, 660, false, 34, 1, 41⟩,
  ⟨660, false, 661, false, 35, 1, 42⟩]
theorem carryCases06_10_verified : carryCases06_10.all verified = true := by decide

def carryCases06_11 : List Case := [
  ⟨662, false, 663, false, 33, 1, 40⟩,
  ⟨662, true, 668, false, 31, 3, 38⟩,
  ⟨663, false, 664, false, 35, 1, 42⟩,
  ⟨664, false, 665, false, 36, 1, 43⟩,
  ⟨664, true, 667, false, 34, 3, 41⟩,
  ⟨665, false, 666, false, 37, 1, 44⟩,
  ⟨668, false, 669, false, 32, 1, 39⟩,
  ⟨668, true, 672, false, 29, 4, 36⟩]
theorem carryCases06_11_verified : carryCases06_11.all verified = true := by decide

def carryCases06 : List Case := carryCases06_00 ++ carryCases06_01 ++ carryCases06_02 ++ carryCases06_03 ++ carryCases06_04 ++ carryCases06_05 ++ carryCases06_06 ++ carryCases06_07 ++ carryCases06_08 ++ carryCases06_09 ++ carryCases06_10 ++ carryCases06_11
theorem carryCases06_verified : carryCases06.all verified = true := by
  simp only [carryCases06, List.all_append, carryCases06_00_verified, carryCases06_01_verified, carryCases06_02_verified, carryCases06_03_verified, carryCases06_04_verified, carryCases06_05_verified, carryCases06_06_verified, carryCases06_07_verified, carryCases06_08_verified, carryCases06_09_verified, carryCases06_10_verified, carryCases06_11_verified, Bool.and_self]
theorem carryCases06_covered : carryCases06.map (fun c => key c.pc c.zero) = keysBetween 1146 192 := by decide
theorem carryCases06_count : carryCases06.length = 96 := by decide
end NF192.Carry
