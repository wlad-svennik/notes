module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases00_00 : List Case := [
  ⟨1, true, 8448, 2304, 7, 11, 18⟩,
  ⟨6, false, 241920, 12544, 34, 0, 0⟩,
  ⟨9, false, 127232, 28928, 30, 0, 0⟩,
  ⟨13, true, 174336, 26880, 12, 14, 21⟩,
  ⟨16, false, 502016, 108800, 34, 0, 0⟩,
  ⟨17, false, 26880, 2304, 26, 0, 0⟩,
  ⟨20, false, 30976, 6400, 26, 0, 0⟩,
  ⟨23, false, 13568, 1280, 24, 0, 0⟩
]

theorem cases00_00_verified : cases00_00.all verified = true := by decide

def cases00_01 : List Case := [
  ⟨27, true, 347392, 52480, 13, 15, 22⟩,
  ⟨30, false, 1002752, 216320, 36, 0, 0⟩,
  ⟨31, false, 52480, 3328, 28, 0, 0⟩,
  ⟨34, false, 60672, 11520, 28, 0, 0⟩,
  ⟨37, false, 32000, 7424, 32, 0, 0⟩,
  ⟨43, true, 11029248, 1592064, 18, 20, 27⟩,
  ⟨46, false, 32000768, 6834944, 46, 0, 0⟩,
  ⟨47, false, 1592064, 19200, 38, 0, 0⟩
]

theorem cases00_01_verified : cases00_01.all verified = true := by decide

def cases00_02 : List Case := [
  ⟨50, false, 1854208, 281344, 38, 0, 0⟩,
  ⟨53, false, 6441728, 150272, 42, 0, 0⟩,
  ⟨56, false, 101862144, 1198848, 50, 0, 0⟩,
  ⟨59, false, 219302656, 17976064, 54, 0, 0⟩,
  ⟨63, false, 1930578688, 51530496, 60, 0, 0⟩,
  ⟨68, false, 7970376448, 1527925504, 64, 0, 0⟩,
  ⟨69, false, 991054592, 51530496, 56, 0, 0⟩,
  ⟨72, false, 521292544, 118639360, 58, 0, 0⟩
]

theorem cases00_02_verified : cases00_02.all verified = true := by decide

def cases00_03 : List Case := [
  ⟨76, false, 244468480, 9587456, 52, 0, 0⟩,
  ⟨79, false, 127027968, 26364672, 50, 0, 0⟩,
  ⟨82, false, 106056448, 5393152, 50, 0, 0⟩,
  ⟨85, false, 223496960, 22170368, 54, 0, 0⟩,
  ⟨89, false, 1934772992, 55724800, 60, 0, 0⟩,
  ⟨94, false, 7974570752, 1532119808, 64, 0, 0⟩,
  ⟨95, false, 995248896, 55724800, 56, 0, 0⟩,
  ⟨98, false, 525486848, 122833664, 58, 0, 0⟩
]

theorem cases00_03_verified : cases00_03.all verified = true := by decide

def cases00_04 : List Case := [
  ⟨102, false, 248662784, 13781760, 52, 0, 0⟩,
  ⟨105, false, 131222272, 30558976, 56, 0, 0⟩,
  ⟨109, true, 707939072, 103959296, 24, 26, 33⟩,
  ⟨112, false, 2050116352, 439503616, 58, 0, 0⟩,
  ⟨113, false, 103959296, 3296000, 50, 0, 0⟩,
  ⟨116, false, 120736512, 20073216, 50, 0, 0⟩,
  ⟨119, false, 62016256, 11684608, 54, 0, 0⟩,
  ⟨123, true, 712133376, 108153600, 28, 26, 33⟩
]

theorem cases00_04_verified : cases00_04.all verified = true := by decide

def cases00_05 : List Case := [
  ⟨126, false, 2054310656, 443697920, 62, 0, 0⟩,
  ⟨127, false, 108153600, 7490304, 54, 0, 0⟩,
  ⟨130, false, 124930816, 24267520, 54, 0, 0⟩,
  ⟨134, false, 485640960, 15878912, 56, 0, 0⟩,
  ⟨139, false, 1995590400, 384977664, 60, 0, 0⟩,
  ⟨140, false, 250759936, 15878912, 52, 0, 0⟩,
  ⟨144, false, 267537152, 32656128, 54, 0, 0⟩,
  ⟨147, false, 51006208, 674560, 54, 0, 0⟩
]

theorem cases00_05_verified : cases00_05.all verified = true := by decide

def cases00_06 : List Case := [
  ⟨150, false, 109726464, 9063168, 58, 0, 0⟩,
  ⟨154, false, 965364480, 25840384, 64, 0, 0⟩,
  ⟨159, false, 3985263360, 764037888, 68, 0, 0⟩,
  ⟨160, false, 495602432, 25840384, 60, 0, 0⟩,
  ⟨163, false, 260721408, 59394816, 62, 0, 0⟩,
  ⟨167, false, 122309376, 4868864, 56, 0, 0⟩,
  ⟨170, false, 63589120, 13257472, 60, 0, 0⟩,
  ⟨174, true, 355093248, 53103360, 27, 25, 32⟩
]

theorem cases00_06_verified : cases00_06.all verified = true := by decide

def cases00_07 : List Case := [
  ⟨177, false, 1026181888, 220875520, 60, 0, 0⟩,
  ⟨178, false, 53103360, 2771712, 52, 0, 0⟩,
  ⟨181, false, 61491968, 11160320, 52, 0, 0⟩,
  ⟨185, false, 241847040, 6966016, 54, 0, 0⟩,
  ⟨190, false, 996821760, 191515392, 58, 0, 0⟩,
  ⟨191, false, 124406528, 6966016, 50, 0, 0⟩,
  ⟨195, false, 132795136, 15354624, 52, 0, 0⟩,
  ⟨198, false, 102386432, 1723136, 50, 0, 0⟩
]

theorem cases00_07_verified : cases00_07.all verified = true := by decide

def cases00 : List Case := cases00_00 ++ cases00_01 ++ cases00_02 ++ cases00_03 ++ cases00_04 ++ cases00_05 ++ cases00_06 ++ cases00_07

theorem cases00_verified : cases00.all verified = true := by
  simp only [cases00, List.all_append, cases00_00_verified, cases00_01_verified, cases00_02_verified, cases00_03_verified, cases00_04_verified, cases00_05_verified, cases00_06_verified, cases00_07_verified, Bool.and_self]

end NF192.Control
