module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block2048 : checkRange 2048 32 = true := by decide +kernel
theorem block2080 : checkRange 2080 32 = true := by decide +kernel
theorem block2112 : checkRange 2112 32 = true := by decide +kernel
theorem block2144 : checkRange 2144 32 = true := by decide +kernel
theorem block2176 : checkRange 2176 32 = true := by decide +kernel
theorem block2208 : checkRange 2208 32 = true := by decide +kernel
theorem block2240 : checkRange 2240 32 = true := by decide +kernel
theorem block2272 : checkRange 2272 32 = true := by decide +kernel

end NF192.Phase
