module
public import MachineControlKernelWord

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-!
# Unbounded preparation and register selection

These are the exact preparation and selection routines of the frozen machine.
The preparation gap, every earlier register value, and the surrounding tape
are unrestricted. The selector chain has the literal nine physical positions;
the proofs do not bound the magnitudes of the values in those positions.

The endpoints are the entry into `k:2` for the return routine. Returning to the
decoder root is proved separately, including the shortened zero-run detector.
-/

namespace NF192.KernelSelectors

open NF210 NF210.TM
open NF192.Selected (State machine)
open NF192.KernelRightShift

def prepareState : State := ⟨173, by decide⟩
def returnState : State := ⟨164, by decide⟩
def markState : State := ⟨157, by decide⟩

def selectorStates : Array State := #[
  ⟨180, by decide⟩, ⟨174, by decide⟩, ⟨168, by decide⟩,
  ⟨177, by decide⟩, ⟨171, by decide⟩, ⟨172, by decide⟩,
  ⟨165, by decide⟩, ⟨182, by decide⟩, ⟨184, by decide⟩]

def selectorState (index : Nat) : State := selectorStates[index]?.getD markState

theorem state_names :
    Selected.name prepareState = "k:35" ∧
    Selected.name returnState = "k:2" ∧
    Selected.name markState = "k16share:0" ∧
    selectorStates.toList.map Selected.name =
      ["k:51", "k:36", "k:25", "k:48", "k:32", "k:33", "k:22", "k:55", "k:60"] := by
  decide

theorem prepare_zero : machine prepareState false = ⟨true, .right, some prepareState⟩ := by
  decide

theorem prepare_header : machine prepareState true = ⟨true, .left, some returnState⟩ := by
  decide

theorem mark_one : machine markState true = ⟨false, .left, some returnState⟩ := by
  decide

theorem selector_one (index : Nat) (inside : index < 9) :
    machine (selectorState index) true = ⟨true, .right, some (selectorState index)⟩ := by
  have checked : ∀ i : Fin 9,
      machine (selectorState i.val) true = ⟨true, .right, some (selectorState i.val)⟩ := by
    decide
  exact checked ⟨index, inside⟩

theorem selector_zero : machine (selectorState 0) false = ⟨false, .right, some markState⟩ := by
  decide

theorem selector_zero_succ (index : Nat) (inside : index < 8) :
    machine (selectorState (index + 1)) false =
      ⟨false, .right, some (selectorState index)⟩ := by
  have checked : ∀ i : Fin 8,
      machine (selectorState (i.val + 1)) false =
        ⟨false, .right, some (selectorState i.val)⟩ := by
    decide
  exact checked ⟨index, inside⟩

theorem fill_gap (length : Nat) :
    RightRun prepareState prepareState
      (List.replicate length false) (List.replicate length true) :=
  (RightRun.one prepare_zero).repeat length

/-- Fill an arbitrary zero gap and enter the return routine just left of its header. -/
theorem prepare_exact (gap : Nat) (anchor : Int) (outside : Tape) :
    TM.run machine (gap + 1)
      (configuration prepareState anchor
        (wordTape anchor (List.replicate gap false ++ [true]) outside)) =
      configuration returnState (anchor + (gap : Int) - 1)
        (wordTape anchor (List.replicate gap true ++ [true]) outside) := by
  rw [TM.run_succ]
  have filled := (fill_gap gap).with_suffix anchor [true] outside
  simp only [List.length_replicate] at filled
  rw [filled]
  have header := wordTape_append_head anchor (List.replicate gap true) [] true outside
  simp only [List.length_replicate] at header
  rw [step_preserve prepare_header _ _ header]
  rfl

theorem scan_selector (index : Nat) (inside : index < 9) (length : Nat) :
    RightRun (selectorState index) (selectorState index)
      (List.replicate length true) (List.replicate length true) :=
  (RightRun.one (selector_one index inside)).repeat length

theorem first_separator (length : Nat) :
    RightRun (selectorState 0) markState
      (List.replicate length true ++ [false]) (List.replicate length true ++ [false]) :=
  (scan_selector 0 (by decide) length).trans (RightRun.one selector_zero)

theorem next_separator (index : Nat) (inside : index < 8) (length : Nat) :
    RightRun (selectorState (index + 1)) (selectorState index)
      (List.replicate length true ++ [false]) (List.replicate length true ++ [false]) :=
  (scan_selector (index + 1) (by omega) length).trans
    (RightRun.one (selector_zero_succ index inside))

/-- The initial ones pass through the prepared header; the last zero precedes the target. -/
def selectionInput (initialRun : Nat) (earlierValues : List Nat) : List Bool :=
  List.replicate initialRun true ++ blocks earlierValues ++ [false]

theorem select_prefix (initialRun : Nat) (earlierValues : List Nat)
    (physicalPosition : earlierValues.length < 9) :
    RightRun (selectorState earlierValues.length) markState
      (selectionInput initialRun earlierValues) (selectionInput initialRun earlierValues) := by
  induction earlierValues generalizing initialRun with
  | nil => simpa [selectionInput, blocks] using first_separator initialRun
  | cons value rest ih =>
    have bounded : rest.length < 8 := by
      simp only [List.length_cons] at physicalPosition
      omega
    have tail := ih (value + 1) (by omega)
    have certificate := (next_separator rest.length bounded initialRun).trans tail
    simpa [selectionInput, blocks, List.append_assoc] using certificate

/-- Select and erase precisely the first one of the target unary register. -/
theorem select_and_mark_exact (initialRun : Nat) (earlierValues : List Nat)
    (physicalPosition : earlierValues.length < 9)
    (anchor : Int) (targetTail : List Bool) (outside : Tape) :
    TM.run machine ((selectionInput initialRun earlierValues).length + 1)
      (configuration (selectorState earlierValues.length) anchor
        (wordTape anchor (selectionInput initialRun earlierValues ++ true :: targetTail) outside)) =
      configuration returnState
        (anchor + ((selectionInput initialRun earlierValues).length : Int) - 1)
        (wordTape anchor (selectionInput initialRun earlierValues ++ false :: targetTail) outside) := by
  rw [TM.run_succ, (select_prefix initialRun earlierValues physicalPosition).with_suffix]
  rw [step_read mark_one _ _
    (wordTape_append_head anchor (selectionInput initialRun earlierValues) targetTail true outside)]
  rw [writeTape_append_head]
  rfl

#print axioms prepare_exact
#print axioms select_and_mark_exact

end NF192.KernelSelectors
