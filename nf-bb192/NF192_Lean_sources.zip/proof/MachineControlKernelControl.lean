module
public import MachineControlKernelLeft

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-!
# Carry, break, and workspace cleanup

The carry lemma also covers overflow through the old marker: its leading
zero may be the blank cell immediately left of that marker. Cleanup retains
exactly the last one of an arbitrary positive run and erases all earlier ones.
The return routine beginning at `k16share:1` is a separate composition step.
-/

namespace NF192.KernelControl

open NF210 NF210.TM
open NF192.Selected (State machine)
open NF192.KernelRightShift

def carryState : State := ⟨175, by decide⟩
def breakState : State := ⟨170, by decide⟩
def zeroScanState : State := ⟨183, by decide⟩
def eraseState : State := ⟨160, by decide⟩
def restoreState : State := ⟨157, by decide⟩
def returnState : State := ⟨158, by decide⟩

theorem state_names :
    Selected.name carryState = "k:4" ∧
    Selected.name breakState = "k:302" ∧
    Selected.name zeroScanState = "k:6" ∧
    Selected.name eraseState = "k:10" ∧
    Selected.name restoreState = "k16share:0" ∧
    Selected.name returnState = "k16share:1" := by decide

theorem carry_ones (count : Nat) :
    LeftRun carryState carryState (List.replicate count true) (List.replicate count false) :=
  (LeftRun.one (by decide)).repeat count

theorem carry_zero : machine carryState false = ⟨true, .right, some zeroScanState⟩ := by
  decide

/-- Carry across every trailing one, including across the old marker on overflow. -/
theorem carry_exact (count : Nat) (anchor : Int) (outside : Tape) :
    TM.run machine (count + 1)
      (configuration carryState (anchor + (count : Int))
        (wordTape anchor (false :: List.replicate count true) outside)) =
      configuration zeroScanState (anchor + 1)
        (wordTape anchor (true :: List.replicate count false) outside) := by
  have erased := (carry_ones count).context anchor [false] [] outside
  simp only [List.length_replicate, List.length_singleton, List.append_nil,
    List.singleton_append, Int.natCast_one] at erased
  have startPosition : anchor + 1 + (count : Int) - 1 = anchor + (count : Int) := by omega
  have endPosition : anchor + 1 - 1 = anchor := by omega
  rw [startPosition, endPosition] at erased
  rw [TM.run_succ, erased, step_read carry_zero _ _ (by simp)]
  simp [moveHead, writeTape_overwrite]

theorem cleanup_prefix (zeros extraOnes : Nat) :
    RightRun zeroScanState eraseState
      (List.replicate zeros false ++ List.replicate (extraOnes + 1) true)
      (List.replicate (zeros + extraOnes + 1) false) := by
  have skip : RightRun zeroScanState zeroScanState
      (List.replicate zeros false) (List.replicate zeros false) :=
    (RightRun.one (by decide)).repeat zeros
  have first : RightRun zeroScanState eraseState [true] [false] :=
    RightRun.one (by decide)
  have rest : RightRun eraseState eraseState
      (List.replicate extraOnes true) (List.replicate extraOnes false) :=
    (RightRun.one (by decide)).repeat extraOnes
  have certificate := skip.trans (first.trans rest)
  simpa [List.replicate_succ, ← List.replicate_succ, List.replicate_append_replicate, Nat.add_assoc]
    using certificate

theorem cleanup_restore : LeftRun eraseState returnState [false, false] [true, false] := by
  have right : LeftRun eraseState restoreState [false] [false] := LeftRun.one (by decide)
  have left : LeftRun restoreState returnState [false] [true] := LeftRun.one (by decide)
  exact right.trans left

/-- Retain exactly the last one, restoring the intended header and clearing the workspace. -/
theorem cleanup_exact (zeros extraOnes : Nat) (anchor : Int) (outside : Tape) :
    TM.run machine (zeros + extraOnes + 3)
      (configuration zeroScanState anchor
        (wordTape anchor
          (List.replicate zeros false ++ List.replicate (extraOnes + 1) true ++ [false]) outside)) =
      configuration returnState (anchor + ((zeros + extraOnes : Nat) : Int) - 1)
        (wordTape anchor (List.replicate (zeros + extraOnes) false ++ [true, false]) outside) := by
  have erased := (cleanup_prefix zeros extraOnes).with_suffix anchor [false] outside
  simp only [List.length_append, List.length_replicate] at erased
  have sameWord : List.replicate (zeros + extraOnes + 1) false ++ [false] =
      List.replicate (zeros + extraOnes) false ++ [false, false] := by
    rw [List.replicate_succ']
    simp only [List.append_assoc, List.singleton_append]
  rw [sameWord] at erased
  have restored := cleanup_restore.context anchor (List.replicate (zeros + extraOnes) false) [] outside
  simp only [List.length_replicate, List.length_cons, List.length_nil, List.append_nil] at restored
  have sameHead : anchor + ((zeros + extraOnes : Nat) : Int) + ((0 + 1 + 1 : Nat) : Int) - 1 =
      anchor + ((zeros + (extraOnes + 1) : Nat) : Int) := by omega
  rw [sameHead] at restored
  have duration : zeros + extraOnes + 3 = zeros + (extraOnes + 1) + 2 := by omega
  rw [duration, TM.run_add, erased]
  exact restored

#print axioms carry_exact
#print axioms cleanup_exact

end NF192.KernelControl
