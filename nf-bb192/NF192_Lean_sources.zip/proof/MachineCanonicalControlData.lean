module
public import MachineCanonicalControlMasks00
public import MachineCanonicalControlMasks01
public import MachineCanonicalControlMasks02
public import MachineCanonicalControlMasks03
public import MachineCanonicalControlMasks04
public import MachineCanonicalControlMasks05
public import MachineCanonicalControlMasks06

@[expose] public section
namespace NF192.CanonicalControl
open Control Frame
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem checked (pc : Nat) (hi : pc < 3089) : maskCheck pc = true := by
  by_cases h1536 : pc < 1536
  ·
    by_cases h768 : pc < 768
    ·
      by_cases h384 : pc < 384
      ·
        by_cases h192 : pc < 192
        ·
          by_cases h96 : pc < 96
          ·
            by_cases h32 : pc < 32
            ·
              exact checked_in_range mask0000 (by omega) (by omega)
            ·
              by_cases h64 : pc < 64
              ·
                exact checked_in_range mask0032 (by omega) (by omega)
              ·
                exact checked_in_range mask0064 (by omega) (by omega)
          ·
            by_cases h128 : pc < 128
            ·
              exact checked_in_range mask0096 (by omega) (by omega)
            ·
              by_cases h160 : pc < 160
              ·
                exact checked_in_range mask0128 (by omega) (by omega)
              ·
                exact checked_in_range mask0160 (by omega) (by omega)
        ·
          by_cases h288 : pc < 288
          ·
            by_cases h224 : pc < 224
            ·
              exact checked_in_range mask0192 (by omega) (by omega)
            ·
              by_cases h256 : pc < 256
              ·
                exact checked_in_range mask0224 (by omega) (by omega)
              ·
                exact checked_in_range mask0256 (by omega) (by omega)
          ·
            by_cases h320 : pc < 320
            ·
              exact checked_in_range mask0288 (by omega) (by omega)
            ·
              by_cases h352 : pc < 352
              ·
                exact checked_in_range mask0320 (by omega) (by omega)
              ·
                exact checked_in_range mask0352 (by omega) (by omega)
      ·
        by_cases h576 : pc < 576
        ·
          by_cases h480 : pc < 480
          ·
            by_cases h416 : pc < 416
            ·
              exact checked_in_range mask0384 (by omega) (by omega)
            ·
              by_cases h448 : pc < 448
              ·
                exact checked_in_range mask0416 (by omega) (by omega)
              ·
                exact checked_in_range mask0448 (by omega) (by omega)
          ·
            by_cases h512 : pc < 512
            ·
              exact checked_in_range mask0480 (by omega) (by omega)
            ·
              by_cases h544 : pc < 544
              ·
                exact checked_in_range mask0512 (by omega) (by omega)
              ·
                exact checked_in_range mask0544 (by omega) (by omega)
        ·
          by_cases h672 : pc < 672
          ·
            by_cases h608 : pc < 608
            ·
              exact checked_in_range mask0576 (by omega) (by omega)
            ·
              by_cases h640 : pc < 640
              ·
                exact checked_in_range mask0608 (by omega) (by omega)
              ·
                exact checked_in_range mask0640 (by omega) (by omega)
          ·
            by_cases h704 : pc < 704
            ·
              exact checked_in_range mask0672 (by omega) (by omega)
            ·
              by_cases h736 : pc < 736
              ·
                exact checked_in_range mask0704 (by omega) (by omega)
              ·
                exact checked_in_range mask0736 (by omega) (by omega)
    ·
      by_cases h1152 : pc < 1152
      ·
        by_cases h960 : pc < 960
        ·
          by_cases h864 : pc < 864
          ·
            by_cases h800 : pc < 800
            ·
              exact checked_in_range mask0768 (by omega) (by omega)
            ·
              by_cases h832 : pc < 832
              ·
                exact checked_in_range mask0800 (by omega) (by omega)
              ·
                exact checked_in_range mask0832 (by omega) (by omega)
          ·
            by_cases h896 : pc < 896
            ·
              exact checked_in_range mask0864 (by omega) (by omega)
            ·
              by_cases h928 : pc < 928
              ·
                exact checked_in_range mask0896 (by omega) (by omega)
              ·
                exact checked_in_range mask0928 (by omega) (by omega)
        ·
          by_cases h1056 : pc < 1056
          ·
            by_cases h992 : pc < 992
            ·
              exact checked_in_range mask0960 (by omega) (by omega)
            ·
              by_cases h1024 : pc < 1024
              ·
                exact checked_in_range mask0992 (by omega) (by omega)
              ·
                exact checked_in_range mask1024 (by omega) (by omega)
          ·
            by_cases h1088 : pc < 1088
            ·
              exact checked_in_range mask1056 (by omega) (by omega)
            ·
              by_cases h1120 : pc < 1120
              ·
                exact checked_in_range mask1088 (by omega) (by omega)
              ·
                exact checked_in_range mask1120 (by omega) (by omega)
      ·
        by_cases h1344 : pc < 1344
        ·
          by_cases h1248 : pc < 1248
          ·
            by_cases h1184 : pc < 1184
            ·
              exact checked_in_range mask1152 (by omega) (by omega)
            ·
              by_cases h1216 : pc < 1216
              ·
                exact checked_in_range mask1184 (by omega) (by omega)
              ·
                exact checked_in_range mask1216 (by omega) (by omega)
          ·
            by_cases h1280 : pc < 1280
            ·
              exact checked_in_range mask1248 (by omega) (by omega)
            ·
              by_cases h1312 : pc < 1312
              ·
                exact checked_in_range mask1280 (by omega) (by omega)
              ·
                exact checked_in_range mask1312 (by omega) (by omega)
        ·
          by_cases h1440 : pc < 1440
          ·
            by_cases h1376 : pc < 1376
            ·
              exact checked_in_range mask1344 (by omega) (by omega)
            ·
              by_cases h1408 : pc < 1408
              ·
                exact checked_in_range mask1376 (by omega) (by omega)
              ·
                exact checked_in_range mask1408 (by omega) (by omega)
          ·
            by_cases h1472 : pc < 1472
            ·
              exact checked_in_range mask1440 (by omega) (by omega)
            ·
              by_cases h1504 : pc < 1504
              ·
                exact checked_in_range mask1472 (by omega) (by omega)
              ·
                exact checked_in_range mask1504 (by omega) (by omega)
  ·
    by_cases h2304 : pc < 2304
    ·
      by_cases h1920 : pc < 1920
      ·
        by_cases h1728 : pc < 1728
        ·
          by_cases h1632 : pc < 1632
          ·
            by_cases h1568 : pc < 1568
            ·
              exact checked_in_range mask1536 (by omega) (by omega)
            ·
              by_cases h1600 : pc < 1600
              ·
                exact checked_in_range mask1568 (by omega) (by omega)
              ·
                exact checked_in_range mask1600 (by omega) (by omega)
          ·
            by_cases h1664 : pc < 1664
            ·
              exact checked_in_range mask1632 (by omega) (by omega)
            ·
              by_cases h1696 : pc < 1696
              ·
                exact checked_in_range mask1664 (by omega) (by omega)
              ·
                exact checked_in_range mask1696 (by omega) (by omega)
        ·
          by_cases h1824 : pc < 1824
          ·
            by_cases h1760 : pc < 1760
            ·
              exact checked_in_range mask1728 (by omega) (by omega)
            ·
              by_cases h1792 : pc < 1792
              ·
                exact checked_in_range mask1760 (by omega) (by omega)
              ·
                exact checked_in_range mask1792 (by omega) (by omega)
          ·
            by_cases h1856 : pc < 1856
            ·
              exact checked_in_range mask1824 (by omega) (by omega)
            ·
              by_cases h1888 : pc < 1888
              ·
                exact checked_in_range mask1856 (by omega) (by omega)
              ·
                exact checked_in_range mask1888 (by omega) (by omega)
      ·
        by_cases h2112 : pc < 2112
        ·
          by_cases h2016 : pc < 2016
          ·
            by_cases h1952 : pc < 1952
            ·
              exact checked_in_range mask1920 (by omega) (by omega)
            ·
              by_cases h1984 : pc < 1984
              ·
                exact checked_in_range mask1952 (by omega) (by omega)
              ·
                exact checked_in_range mask1984 (by omega) (by omega)
          ·
            by_cases h2048 : pc < 2048
            ·
              exact checked_in_range mask2016 (by omega) (by omega)
            ·
              by_cases h2080 : pc < 2080
              ·
                exact checked_in_range mask2048 (by omega) (by omega)
              ·
                exact checked_in_range mask2080 (by omega) (by omega)
        ·
          by_cases h2208 : pc < 2208
          ·
            by_cases h2144 : pc < 2144
            ·
              exact checked_in_range mask2112 (by omega) (by omega)
            ·
              by_cases h2176 : pc < 2176
              ·
                exact checked_in_range mask2144 (by omega) (by omega)
              ·
                exact checked_in_range mask2176 (by omega) (by omega)
          ·
            by_cases h2240 : pc < 2240
            ·
              exact checked_in_range mask2208 (by omega) (by omega)
            ·
              by_cases h2272 : pc < 2272
              ·
                exact checked_in_range mask2240 (by omega) (by omega)
              ·
                exact checked_in_range mask2272 (by omega) (by omega)
    ·
      by_cases h2688 : pc < 2688
      ·
        by_cases h2496 : pc < 2496
        ·
          by_cases h2400 : pc < 2400
          ·
            by_cases h2336 : pc < 2336
            ·
              exact checked_in_range mask2304 (by omega) (by omega)
            ·
              by_cases h2368 : pc < 2368
              ·
                exact checked_in_range mask2336 (by omega) (by omega)
              ·
                exact checked_in_range mask2368 (by omega) (by omega)
          ·
            by_cases h2432 : pc < 2432
            ·
              exact checked_in_range mask2400 (by omega) (by omega)
            ·
              by_cases h2464 : pc < 2464
              ·
                exact checked_in_range mask2432 (by omega) (by omega)
              ·
                exact checked_in_range mask2464 (by omega) (by omega)
        ·
          by_cases h2592 : pc < 2592
          ·
            by_cases h2528 : pc < 2528
            ·
              exact checked_in_range mask2496 (by omega) (by omega)
            ·
              by_cases h2560 : pc < 2560
              ·
                exact checked_in_range mask2528 (by omega) (by omega)
              ·
                exact checked_in_range mask2560 (by omega) (by omega)
          ·
            by_cases h2624 : pc < 2624
            ·
              exact checked_in_range mask2592 (by omega) (by omega)
            ·
              by_cases h2656 : pc < 2656
              ·
                exact checked_in_range mask2624 (by omega) (by omega)
              ·
                exact checked_in_range mask2656 (by omega) (by omega)
      ·
        by_cases h2880 : pc < 2880
        ·
          by_cases h2784 : pc < 2784
          ·
            by_cases h2720 : pc < 2720
            ·
              exact checked_in_range mask2688 (by omega) (by omega)
            ·
              by_cases h2752 : pc < 2752
              ·
                exact checked_in_range mask2720 (by omega) (by omega)
              ·
                exact checked_in_range mask2752 (by omega) (by omega)
          ·
            by_cases h2816 : pc < 2816
            ·
              exact checked_in_range mask2784 (by omega) (by omega)
            ·
              by_cases h2848 : pc < 2848
              ·
                exact checked_in_range mask2816 (by omega) (by omega)
              ·
                exact checked_in_range mask2848 (by omega) (by omega)
        ·
          by_cases h2976 : pc < 2976
          ·
            by_cases h2912 : pc < 2912
            ·
              exact checked_in_range mask2880 (by omega) (by omega)
            ·
              by_cases h2944 : pc < 2944
              ·
                exact checked_in_range mask2912 (by omega) (by omega)
              ·
                exact checked_in_range mask2944 (by omega) (by omega)
          ·
            by_cases h3040 : pc < 3040
            ·
              by_cases h3008 : pc < 3008
              ·
                exact checked_in_range mask2976 (by omega) (by omega)
              ·
                exact checked_in_range mask3008 (by omega) (by omega)
            ·
              by_cases h3072 : pc < 3072
              ·
                exact checked_in_range mask3040 (by omega) (by omega)
              ·
                exact checked_in_range mask3072 (by omega) (by omega)

theorem data_for (pc : Nat) (hi : pc < 3089) :
    (addressBits pc).length ≤ 31 ∧
    BitsWord.encode (windowWord pc) = pathMask (Source.siteAt pc).address ∧
    (isControl (Source.siteAt pc) = true → Source.destination (targetAddress (Source.siteAt pc)) < 3089) :=
  of_decide_eq_true (checked pc hi)

theorem positive_prefixes : controlCases.all (fun c => decide (0 < c.prefixSteps)) = true := by decide +kernel

end NF192.CanonicalControl
