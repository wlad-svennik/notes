module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases08_00 : List Case := [
  ⟨766, false, 767, false, 32, 1, 39⟩,
  ⟨766, true, 769, false, 28, 5, 35⟩,
  ⟨767, false, 768, false, 33, 1, 40⟩,
  ⟨769, false, 770, false, 29, 1, 36⟩,
  ⟨769, true, 773, false, 27, 3, 34⟩,
  ⟨770, false, 771, false, 30, 1, 37⟩,
  ⟨771, false, 772, false, 31, 1, 38⟩,
  ⟨773, false, 774, false, 28, 1, 35⟩]
theorem carryCases08_00_verified : carryCases08_00.all verified = true := by decide

def carryCases08_01 : List Case := [
  ⟨773, true, 776, false, 26, 3, 33⟩,
  ⟨774, false, 775, false, 29, 1, 36⟩,
  ⟨776, false, 777, false, 30, 1, 37⟩,
  ⟨776, true, 784, false, 29, 2, 36⟩,
  ⟨777, false, 778, false, 32, 1, 39⟩,
  ⟨778, false, 779, false, 34, 1, 41⟩,
  ⟨778, true, 780, false, 33, 2, 40⟩,
  ⟨780, false, 781, false, 34, 1, 41⟩]
theorem carryCases08_01_verified : carryCases08_01.all verified = true := by decide

def carryCases08_02 : List Case := [
  ⟨780, true, 783, false, 31, 4, 38⟩,
  ⟨781, false, 782, false, 35, 1, 42⟩,
  ⟨784, false, 785, false, 30, 1, 37⟩,
  ⟨784, true, 787, false, 28, 3, 35⟩,
  ⟨785, false, 786, false, 31, 1, 38⟩,
  ⟨787, false, 788, false, 31, 1, 38⟩,
  ⟨787, true, 791, false, 30, 2, 37⟩,
  ⟨788, false, 789, false, 32, 1, 39⟩]
theorem carryCases08_02_verified : carryCases08_02.all verified = true := by decide

def carryCases08_03 : List Case := [
  ⟨789, false, 790, false, 33, 1, 40⟩,
  ⟨791, false, 792, false, 31, 1, 38⟩,
  ⟨791, true, 797, false, 29, 3, 36⟩,
  ⟨792, false, 793, false, 33, 1, 40⟩,
  ⟨793, false, 794, false, 34, 1, 41⟩,
  ⟨793, true, 796, false, 32, 3, 39⟩,
  ⟨794, false, 795, false, 35, 1, 42⟩,
  ⟨797, false, 798, false, 30, 1, 37⟩]
theorem carryCases08_03_verified : carryCases08_03.all verified = true := by decide

def carryCases08_04 : List Case := [
  ⟨797, true, 801, false, 27, 4, 34⟩,
  ⟨798, false, 799, false, 31, 1, 38⟩,
  ⟨799, false, 800, false, 32, 1, 39⟩,
  ⟨801, false, 802, false, 22, 6, 29⟩,
  ⟨802, false, 803, false, 27, 1, 34⟩,
  ⟨802, true, 805, false, 26, 2, 33⟩,
  ⟨803, false, 804, false, 28, 1, 35⟩,
  ⟨805, false, 806, false, 28, 1, 35⟩]
theorem carryCases08_04_verified : carryCases08_04.all verified = true := by decide

def carryCases08_05 : List Case := [
  ⟨805, true, 808, false, 27, 2, 34⟩,
  ⟨806, false, 807, false, 29, 1, 36⟩,
  ⟨808, false, 809, false, 30, 1, 37⟩,
  ⟨808, true, 812, false, 29, 2, 36⟩,
  ⟨809, false, 810, false, 31, 1, 38⟩,
  ⟨810, false, 811, false, 32, 1, 39⟩,
  ⟨812, false, 813, false, 30, 1, 37⟩,
  ⟨812, true, 818, false, 28, 3, 35⟩]
theorem carryCases08_05_verified : carryCases08_05.all verified = true := by decide

def carryCases08_06 : List Case := [
  ⟨813, false, 814, false, 32, 1, 39⟩,
  ⟨814, false, 815, false, 33, 1, 40⟩,
  ⟨814, true, 817, false, 31, 3, 38⟩,
  ⟨815, false, 816, false, 34, 1, 41⟩,
  ⟨818, false, 819, false, 29, 1, 36⟩,
  ⟨818, true, 821, false, 25, 5, 32⟩,
  ⟨819, false, 820, false, 30, 1, 37⟩,
  ⟨821, false, 822, false, 27, 1, 34⟩]
theorem carryCases08_06_verified : carryCases08_06.all verified = true := by decide

def carryCases08_07 : List Case := [
  ⟨821, true, 825, false, 26, 2, 33⟩,
  ⟨822, false, 823, false, 28, 1, 35⟩,
  ⟨823, false, 824, false, 29, 1, 36⟩,
  ⟨825, false, 826, false, 27, 1, 34⟩,
  ⟨825, true, 828, false, 24, 4, 31⟩,
  ⟨826, false, 827, false, 28, 1, 35⟩,
  ⟨828, false, 829, false, 28, 1, 35⟩,
  ⟨828, true, 831, false, 27, 2, 34⟩]
theorem carryCases08_07_verified : carryCases08_07.all verified = true := by decide

def carryCases08_08 : List Case := [
  ⟨829, false, 830, false, 29, 1, 36⟩,
  ⟨831, false, 832, false, 29, 1, 36⟩,
  ⟨831, true, 834, false, 28, 2, 35⟩,
  ⟨832, false, 833, false, 30, 1, 37⟩,
  ⟨834, false, 835, false, 31, 1, 38⟩,
  ⟨834, true, 838, false, 30, 2, 37⟩,
  ⟨835, false, 836, false, 32, 1, 39⟩,
  ⟨836, false, 837, false, 33, 1, 40⟩]
theorem carryCases08_08_verified : carryCases08_08.all verified = true := by decide

def carryCases08_09 : List Case := [
  ⟨838, false, 839, false, 31, 1, 38⟩,
  ⟨838, true, 844, false, 29, 3, 36⟩,
  ⟨839, false, 840, false, 33, 1, 40⟩,
  ⟨840, false, 841, false, 34, 1, 41⟩,
  ⟨840, true, 843, false, 32, 3, 39⟩,
  ⟨841, false, 842, false, 35, 1, 42⟩,
  ⟨844, false, 845, false, 30, 1, 37⟩,
  ⟨844, true, 847, false, 26, 5, 33⟩]
theorem carryCases08_09_verified : carryCases08_09.all verified = true := by decide

def carryCases08_10 : List Case := [
  ⟨845, false, 846, false, 31, 1, 38⟩,
  ⟨847, false, 848, false, 28, 1, 35⟩,
  ⟨847, true, 851, false, 27, 2, 34⟩,
  ⟨848, false, 849, false, 29, 1, 36⟩,
  ⟨849, false, 850, false, 30, 1, 37⟩,
  ⟨851, false, 852, false, 28, 1, 35⟩,
  ⟨851, true, 854, false, 25, 4, 32⟩,
  ⟨852, false, 853, false, 29, 1, 36⟩]
theorem carryCases08_10_verified : carryCases08_10.all verified = true := by decide

def carryCases08_11 : List Case := [
  ⟨854, false, 855, false, 29, 1, 36⟩,
  ⟨854, true, 862, false, 28, 2, 35⟩,
  ⟨855, false, 856, false, 31, 1, 38⟩,
  ⟨856, false, 857, false, 33, 1, 40⟩,
  ⟨856, true, 858, false, 32, 2, 39⟩,
  ⟨858, false, 859, false, 33, 1, 40⟩,
  ⟨858, true, 861, false, 30, 4, 37⟩,
  ⟨859, false, 860, false, 34, 1, 41⟩]
theorem carryCases08_11_verified : carryCases08_11.all verified = true := by decide

def carryCases08 : List Case := carryCases08_00 ++ carryCases08_01 ++ carryCases08_02 ++ carryCases08_03 ++ carryCases08_04 ++ carryCases08_05 ++ carryCases08_06 ++ carryCases08_07 ++ carryCases08_08 ++ carryCases08_09 ++ carryCases08_10 ++ carryCases08_11
theorem carryCases08_verified : carryCases08.all verified = true := by
  simp only [carryCases08, List.all_append, carryCases08_00_verified, carryCases08_01_verified, carryCases08_02_verified, carryCases08_03_verified, carryCases08_04_verified, carryCases08_05_verified, carryCases08_06_verified, carryCases08_07_verified, carryCases08_08_verified, carryCases08_09_verified, carryCases08_10_verified, carryCases08_11_verified, Bool.and_self]
theorem carryCases08_covered : carryCases08.map (fun c => key c.pc c.zero) = keysBetween 1532 192 := by decide
theorem carryCases08_count : carryCases08.length = 96 := by decide
end NF192.Carry
