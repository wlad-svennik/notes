module
public import MachinePhysicalInterface
public import SignedSimulation
public import NumericalStartupComplete

@[expose] public section

namespace NF192.Physical

open NF210 NF210.TM NF192.Frame NF192.Emitter

/-- The checked signed startup reaches a warm boundary. This permits exactly
the exceptional initial increment and rules out a decrement at minus one. -/
def CanWarm (s : SignedSimulation.Signed) : Prop :=
  ∃ k t, bootstrapAdvance k s = (false,t)

theorem CanWarm.step {s : SignedSimulation.Signed} (h : CanWarm s) : CanWarm (bootstrapStep s) := by
  rcases s with ⟨cold,c⟩
  cases cold with
  | false => exact ⟨0,Source.step c,rfl⟩
  | true =>
    obtain ⟨k,t,ht⟩ := h
    cases k with
    | zero => cases ht
    | succ k => exact ⟨k,t,ht⟩

theorem cold_halt_never_warms : ¬ CanWarm (true,Source.Config.halted) := by
  rintro ⟨k,t,h⟩
  rw [bootstrap_absorbing] at h
  cases h

def rawValue (cold : Bool) (rs : Source.Registers) (r : Nat) : Nat :=
  if cold && (r == 0) then 0 else rs r+1

/-- Register semantics only depends on the nine physical selectors. -/
def Rep (cold : Bool) (s : BinarySimulation.Running) (f : Layout) : Prop :=
  Good f ∧ f.pc = s.1 ∧ (∀ j : Fin 9, f.storedAt j.val = rawValue cold s.2 j.val) ∧
    CanWarm (cold,some s)

def Rel (cold : Bool) (s : BinarySimulation.Running) (b : Configuration 192) : Prop :=
  ∃ f, Rep cold s f ∧ b = f.config

theorem margin_entry : SignedSimulation.Related Rel (true,liftConfig StartupCalibration.margin)
    Frame.firstMargin.config := by
  obtain ⟨t,warm⟩ := StartupCalibration.margin_reaches_warm
  refine ⟨Frame.firstMargin,⟨?_,rfl,?_,⟨t,_,warm⟩⟩,rfl⟩
  · exact ⟨by decide,by decide,by decide⟩
  · change ∀ j : Fin 9, Frame.firstMargin.storedAt j.val =
      rawValue true (liftRegisters StartupCalibration.margin.registers) j.val
    decide +kernel

theorem inc_step (c : Bool) (pc n : Nat) (r : Fin 9) (rs : Source.Registers)
    (op : Source.program pc = Source.Command.inc r.val n) :
    bootstrapStep (c,Source.Config.active pc rs) =
      (c && !(r.val == 0),Source.Config.active n
        (Source.setReg rs r.val (if c && (r.val == 0) then 0 else rs r.val+1))) := by
  cases c <;> by_cases h : r.val = 0 <;>
    simp [bootstrapStep,actual,readCommand,usesCounter,Source.step,Source.execute,op,r.isLt,h]

theorem inc_values (c : Bool) (r : Fin 9) (rs : Source.Registers) (f : Layout)
    (h : ∀ j : Fin 9, f.storedAt j.val = rawValue c rs j.val) (j : Fin 9) :
    Source.setReg f.storedAt r.val (f.storedAt r.val+1) j.val =
      rawValue (c && !(r.val == 0)) (Source.setReg rs r.val
        (if c && (r.val == 0) then 0 else rs r.val+1)) j.val := by
  by_cases e : j.val = r.val
  · have eq : j = r := Fin.ext e
    subst j
    simp only [Source.setReg,ite_true, h r]
    cases c <;> by_cases z : r.val = 0 <;> simp [Source.setReg,rawValue,z]
  · cases c <;> by_cases z : r.val = 0 <;>
      simp [Source.setReg,h,rawValue,z,e] <;> grind

theorem dec_cold_impossible (pc z n : Nat) (r : Fin 9) (halt : Bool)
    (rs : Source.Registers) (op : Source.program pc = Source.Command.dec r.val z n halt)
    (warm : CanWarm (true,Source.Config.active pc rs)) : r.val ≠ 0 := by
  intro zero
  have fix : bootstrapStep (true,Source.Config.active pc rs) = (true,Source.Config.halted) := by
    cases halt <;> simp [bootstrapStep,actual,readCommand,usesCounter,op,r.isLt,zero]
  have bad := warm.step
  rw [fix] at bad
  exact cold_halt_never_warms bad

theorem dec_step (c : Bool) (pc z n : Nat) (r : Fin 9) (halt : Bool) (rs : Source.Registers)
    (op : Source.program pc = Source.Command.dec r.val z n halt)
    (allowed : c = true → r.val ≠ 0) :
    bootstrapStep (c,Source.Config.active pc rs) =
      (c,Source.execute (Source.Command.dec r.val z n halt) rs) := by
  cases c with
  | false => simp [bootstrapStep,Source.step,op]
  | true =>
    have hr := allowed rfl
    cases halt <;> simp [bootstrapStep,actual,readCommand,usesCounter,op,r.isLt,hr,Source.step]

theorem dec_values (c : Bool) (r : Fin 9) (rs : Source.Registers) (f : Layout) (k : Nat)
    (pos : rs r.val = k+1) (allowed : c = true → r.val ≠ 0)
    (h : ∀ j : Fin 9, f.storedAt j.val = rawValue c rs j.val) (j : Fin 9) :
    Source.setReg f.storedAt r.val (f.storedAt r.val-1) j.val =
      rawValue c (Source.setReg rs r.val k) j.val := by
  by_cases e : j.val = r.val
  · have eq : j = r := Fin.ext e
    subst j
    cases c with
    | false => simp [Source.setReg,rawValue,h,pos]
    | true => simp [Source.setReg,rawValue,h,pos,allowed rfl]
  · simp only [Source.setReg,if_neg e,h]
    unfold rawValue
    simp [Source.setReg,e]

theorem jump_step (c : Bool) (pc n : Nat) (rs : Source.Registers)
    (op : Source.program pc = Source.Command.jump n) :
    bootstrapStep (c,Source.Config.active pc rs) = (c,Source.Config.active n rs) := by
  cases c <;> simp [bootstrapStep,actual,readCommand,usesCounter,Source.step,Source.execute,op]

end NF192.Physical
