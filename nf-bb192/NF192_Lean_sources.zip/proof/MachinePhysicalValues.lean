module
public import MachinePhysicalInterface
public import MachineFrameCarryGeometry
public import MachineSourceBounds

@[expose] public section
namespace NF192.Physical
open NF210 NF210.TM Frame

theorem Good.room {f : Layout} (h : Good f) : 2 ≤ f.gapWidth := by
  have tile := Source.complete_ordered_prefix_code
  have check := (Bool.and_eq_true_iff.mp tile).2
  have bound := (Bool.and_eq_true_iff.mp (List.all_eq_true.mp check f.pc (List.mem_range.mpr h.inRange))).1
  have depth : (Source.siteAt f.pc).depth ≤ 31 := of_decide_eq_true (Bool.and_eq_true_iff.mp bound).2
  have len : (addressBits f.pc).length = (Source.siteAt f.pc).depth := by simp [addressBits]
  unfold Layout.gapWidth
  rw [len]
  exact Nat.le_sub_of_add_le (by have := h.margin; omega)

theorem update_effect (f : Layout) (r : Fin 9) (v : Nat) (more : List Nat)
    (zero : Bool) (bump : Nat) (h : Good f) (target : Carry.nextPc f.pc zero < 3089) :
    Effect (f.afterCarry zero bump (f.stored.setIfInBounds r.val v) (f.spares++more))
      (Carry.nextPc f.pc zero) (Source.setReg f.storedAt r.val v) := by
  refine ⟨⟨target,?_,?_⟩,rfl,?_⟩
  · change 42 ≤ f.gap+bump+(Carry.shifted f.pc zero).toNat
    have := h.margin; omega
  · exact (f.updated_size r v more).trans h.nine
  · intro j
    change (f.updateStored r v more).storedAt j.val = _
    by_cases same : j.val = r.val
    · rw [same,f.updated_self r v more h.nine]
      simp [Source.setReg]
    · rw [f.updated_other r v more j.val (Ne.symm same)]
      simp [Source.setReg,same]

theorem zero_effect (f : Layout) (h : Good f) (target : Carry.nextPc f.pc true < 3089) :
    Effect (f.afterCarry true 0 f.stored f.spares) (Carry.nextPc f.pc true) f.storedAt := by
  refine ⟨⟨target,?_,h.nine⟩,rfl,fun _ => rfl⟩
  change 42 ≤ f.gap + 0 + (Carry.shifted f.pc true).toNat
  have := h.margin; omega

end NF192.Physical
