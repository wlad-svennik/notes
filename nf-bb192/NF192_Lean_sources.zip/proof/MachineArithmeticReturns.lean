module
public import ArithmeticPhases
public import MachineBitsWord
public import MachineSelectorRoundtrip

@[expose] public section

namespace NF192.ArithmeticReturn
open NF210 NF210.TM NF192.KernelRightShift
open NF192.KernelSelectors (returnState)
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def guard : List Bool := List.replicate 8 false

/-- A completed selection returns to phase 01, possibly at its displaced CD ingress.
Gap preparation returns to the ordinary decoder root for phase 11. -/
def nextPhase (s : Source.Site) (selected : Bool) : Nat :=
  if selected then (if Phase.enabled s 3 then 3 else 2) else 1

def stageWord (s : Source.Site) (selected : Bool) : List Bool :=
  guard ++ Phase.inputWord s (if selected then 2 else 1)

def initialHead (s : Source.Site) (selected : Bool) : Nat := 8 + s.depth + selected.toNat

def finalHead (s : Source.Site) (selected : Bool) : Nat := 8 + Phase.initialHead s (nextPhase s selected)

def duration (s : Source.Site) (selected : Bool) : Nat :=
  if selected then (if Phase.enabled s 3 then 7 else s.depth + 16) else s.depth + 15

abbrev Spec (s : Source.Site) (selected : Bool) : Prop :=
  let word := stageWord s selected
  let bits := BitsWord.encode word
  initialHead s selected < word.length ∧
    KernelBits.run Selected.machine word.length (duration s selected)
      ⟨some returnState, initialHead s selected, bits⟩ =
        some ⟨some Selected.decoderRoot, finalHead s selected, bits⟩

def check (i : Nat) : Bool :=
  let s := Source.siteAt i
  if Phase.enabled s 0 then decide (s.argument < 9 ∧ Spec s false ∧ Spec s true) else true

def checkRange (lo size : Nat) : Bool := (List.range size).all fun j => check (lo+j)

theorem checked_in_range {lo size i : Nat} (ok : checkRange lo size = true)
    (lower : lo ≤ i) (upper : i < lo+size) : check i = true := by
  have h := List.all_eq_true.mp ok (i-lo) (List.mem_range.mpr (by omega))
  simpa only [show lo+(i-lo) = i by omega] using h

theorem things_checked {i : Nat} (active : Phase.enabled (Source.siteAt i) 0 = true)
    (ok : check i = true) : let s := Source.siteAt i
    s.argument < 9 ∧ Spec s false ∧ Spec s true :=
  of_decide_eq_true (by simpa only [check, active, ite_true] using ok)

theorem checked_return {s : Source.Site} {selected : Bool} (h : Spec s selected) :
    let word := stageWord s selected
    WordRun returnState Selected.decoderRoot word word (initialHead s selected : Int)
      (finalHead s selected : Int) (duration s selected) := by
  dsimp only
  constructor
  · rfl
  · intro anchor outside
    have run := (KernelBits.run_sound Selected.machine _ anchor outside _ _ _ h.1 h.2).2
    simpa only [KernelBits.embed, BitsWord.tape_encode, configuration] using run

end NF192.ArithmeticReturn
