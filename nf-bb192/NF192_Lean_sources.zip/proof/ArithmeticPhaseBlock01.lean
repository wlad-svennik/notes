module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block0256 : checkRange 256 32 = true := by decide +kernel
theorem block0288 : checkRange 288 32 = true := by decide +kernel
theorem block0320 : checkRange 320 32 = true := by decide +kernel
theorem block0352 : checkRange 352 32 = true := by decide +kernel
theorem block0384 : checkRange 384 32 = true := by decide +kernel
theorem block0416 : checkRange 416 32 = true := by decide +kernel
theorem block0448 : checkRange 448 32 = true := by decide +kernel
theorem block0480 : checkRange 480 32 = true := by decide +kernel

end NF192.Phase
