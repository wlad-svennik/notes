module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases13_00 : List Case := [
  ⟨2697, false, 63751015168, 12211407616, 70, 0, 0⟩,
  ⟨2698, false, 7916440320, 400247552, 62, 0, 0⟩,
  ⟨2702, false, 8453311232, 937118464, 64, 0, 0⟩,
  ⟨2706, false, 205212416, 3885824, 56, 0, 0⟩,
  ⟨2709, false, 440093440, 37440256, 60, 0, 0⟩,
  ⟨2713, false, 3862645504, 104549120, 66, 0, 0⟩,
  ⟨2718, false, 15942241024, 3057339136, 70, 0, 0⟩,
  ⟨2719, false, 1983597312, 104549120, 62, 0, 0⟩
]

theorem cases13_00_verified : cases13_00.all verified = true := by decide

def cases13_01 : List Case := [
  ⟨2722, false, 1044073216, 238766848, 64, 0, 0⟩,
  ⟨2726, false, 490425088, 20663040, 58, 0, 0⟩,
  ⟨2729, false, 255544064, 54217472, 62, 0, 0⟩,
  ⟨2732, false, 817580800, 12274432, 58, 0, 0⟩,
  ⟨2735, false, 1757104896, 146492160, 62, 0, 0⟩,
  ⟨2739, false, 15447313152, 414927616, 68, 0, 0⟩,
  ⟨2744, false, 63765695232, 12226087680, 72, 0, 0⟩,
  ⟨2745, false, 7931120384, 414927616, 64, 0, 0⟩
]

theorem cases13_01_verified : cases13_01.all verified = true := by decide

def cases13_02 : List Case := [
  ⟨2748, false, 4173024000, 951798528, 66, 0, 0⟩,
  ⟨2752, false, 1958431488, 79383296, 60, 0, 0⟩,
  ⟨2755, false, 1018907392, 213601024, 64, 0, 0⟩,
  ⟨2758, false, 3267054336, 45828864, 60, 0, 0⟩,
  ⟨2761, false, 7025150720, 582699776, 64, 0, 0⟩,
  ⟨2765, false, 61785983744, 1656441600, 70, 0, 0⟩,
  ⟨2770, false, 255059512064, 48901081856, 74, 0, 0⟩,
  ⟨2771, false, 31721212672, 1656441600, 66, 0, 0⟩
]

theorem cases13_02_verified : cases13_02.all verified = true := by decide

def cases13_03 : List Case := [
  ⟨2774, false, 16688827136, 3803925248, 68, 0, 0⟩,
  ⟨2778, false, 4072360704, 314264320, 60, 0, 0⟩,
  ⟨2781, false, 985352960, 180046592, 56, 0, 0⟩,
  ⟨2785, true, 22661516032, 3334163200, 33, 31, 38⟩,
  ⟨2788, false, 65611188992, 14071581440, 72, 0, 0⟩,
  ⟨2789, false, 3334163200, 112937728, 64, 0, 0⟩,
  ⟨2792, false, 3871034112, 649808640, 64, 0, 0⟩,
  ⟨2796, false, 15413758720, 381373184, 66, 0, 0⟩
]

theorem cases13_03_verified : cases13_03.all verified = true := by decide

def cases13_04 : List Case := [
  ⟨2801, false, 63732140800, 12192533248, 70, 0, 0⟩,
  ⟨2802, false, 7897565952, 381373184, 62, 0, 0⟩,
  ⟨2806, false, 8434436864, 918244096, 64, 0, 0⟩,
  ⟨2812, true, 11336895232, 1673218816, 32, 30, 37⟩,
  ⟨2815, false, 32811731712, 7041927936, 70, 0, 0⟩,
  ⟨2816, false, 1673218816, 62606080, 62, 0, 0⟩,
  ⟨2819, false, 1941654272, 331041536, 62, 0, 0⟩,
  ⟨2823, false, 7713016576, 196823808, 64, 0, 0⟩
]

theorem cases13_04_verified : cases13_04.all verified = true := by decide

def cases13_05 : List Case := [
  ⟨2828, false, 31872207616, 6102403840, 68, 0, 0⟩,
  ⟨2829, false, 3954920192, 196823808, 60, 0, 0⟩,
  ⟨2833, false, 4223355648, 465259264, 62, 0, 0⟩,
  ⟨2838, true, 2826652416, 410733312, 30, 28, 35⟩,
  ⟨2841, false, 8195361536, 1752910592, 66, 0, 0⟩,
  ⟨2842, false, 410733312, 8080128, 58, 0, 0⟩,
  ⟨2845, false, 477842176, 75188992, 58, 0, 0⟩,
  ⟨2849, false, 1920682752, 41634560, 60, 0, 0⟩
]

theorem cases13_05_verified : cases13_05.all verified = true := by decide

def cases13_06 : List Case := [
  ⟨2854, false, 7960480512, 1518029568, 64, 0, 0⟩,
  ⟨2855, false, 981158656, 41634560, 56, 0, 0⟩,
  ⟨2859, false, 1048267520, 108743424, 58, 0, 0⟩,
  ⟨2863, false, 821775104, 16468736, 60, 0, 0⟩,
  ⟨2866, false, 1761299200, 150686464, 64, 0, 0⟩,
  ⟨2870, false, 15451507456, 419121920, 70, 0, 0⟩,
  ⟨2875, false, 63769889536, 12230281984, 74, 0, 0⟩,
  ⟨2876, false, 7935314688, 419121920, 66, 0, 0⟩
]

theorem cases13_06_verified : cases13_06.all verified = true := by decide

def cases13_07 : List Case := [
  ⟨2879, false, 4177218304, 955992832, 68, 0, 0⟩,
  ⟨2883, false, 1962625792, 83577600, 62, 0, 0⟩,
  ⟨2886, false, 1023101696, 217795328, 66, 0, 0⟩,
  ⟨2889, false, 3271248640, 50023168, 62, 0, 0⟩,
  ⟨2892, false, 7029345024, 586894080, 66, 0, 0⟩,
  ⟨2896, false, 61790178048, 1660635904, 72, 0, 0⟩,
  ⟨2901, false, 255063706368, 48905276160, 76, 0, 0⟩,
  ⟨2902, false, 31725406976, 1660635904, 68, 0, 0⟩
]

theorem cases13_07_verified : cases13_07.all verified = true := by decide

def cases13 : List Case := cases13_00 ++ cases13_01 ++ cases13_02 ++ cases13_03 ++ cases13_04 ++ cases13_05 ++ cases13_06 ++ cases13_07

theorem cases13_verified : cases13.all verified = true := by
  simp only [cases13, List.all_append, cases13_00_verified, cases13_01_verified, cases13_02_verified, cases13_03_verified, cases13_04_verified, cases13_05_verified, cases13_06_verified, cases13_07_verified, Bool.and_self]

end NF192.Control
