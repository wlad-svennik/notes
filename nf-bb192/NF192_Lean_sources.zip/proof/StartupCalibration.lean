module
public import NumericalStartupComplete
public import SourceComplete
public import MachineFrame

@[expose] public section

/-! Reconcile the two concrete signed startup configurations with the
ordinary, sound command boundary from the literal source theorem. -/
namespace NF192.StartupCalibration

open NF210 NF192.Emitter NF192.Numerical NF192.ProofSearch NF192.Emitter.Registers
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def origin : Emitter.Config := ⟨40,mk9 0 0 0 2 0 0 0 0 0⟩
def margin : Emitter.Config := ⟨91,mk9 0 0 0 2 0 0 0 2 0⟩
def warm : Source.Config := atFrame 10
  ⟨0,startupProof.top,ProofSearch.pack startupProof.stack,0,0,startupProof.cache,0⟩

/-- Values are read off the binary frame using the one-unit offset; the
cold flag represents precisely the exceptional logical value −1 at R0. -/
def represents (f : Frame.Layout) (c : Emitter.Config) (cold : Bool) : Prop :=
  f.pc = c.pc ∧ f.stored.size = 9 ∧ ∀ r : Fin 9,
    f.logical r.val = if cold && r.val == 0 then -1 else (c.registers r : Int)

theorem represents_first : represents Frame.firstAX origin true := by unfold represents; decide +kernel
theorem represents_margin : represents Frame.firstMargin margin true := by unfold represents; decide +kernel

def first46 := Emitter.run frozen 46 origin

theorem frozen_46 : first46 = some margin := by
  have hp : first46.map Emitter.Config.pc = some margin.pc := by decide +kernel
  have hr : ∀ i : Fin 9, first46.map (fun c => c.registers i) = some (margin.registers i) := by
    decide +kernel
  cases h : first46 with
  | none => simp [h] at hp
  | some c =>
    rw [h] at hp
    have reg : c.registers = margin.registers := by
      funext i
      simpa only [h,Option.map_some,Option.some.injEq] using hr i
    have pc : c.pc = margin.pc := by simpa only [Option.map_some,Option.some.injEq] using hp
    apply congrArg some
    cases c with
    | mk p rs =>
      change p = 91 at pc
      change rs = _ at reg
      cases pc
      cases reg
      rfl

theorem advance_46 : bootstrapAdvance 46 (true,liftConfig origin) = (true,liftConfig margin) :=
  frozen_run 46 frozen_46

/-- The checked finite prefix cancels out of the signed source startup. -/
theorem margin_reaches_warm :
    ∃ ticks, bootstrapAdvance ticks (true,liftConfig margin) = (false,warm) := by
  obtain ⟨n,_,finish⟩ := signed_startup
  change bootstrapAdvance n (true,liftConfig origin) = (false,warm) at finish
  have past : 46 ≤ n := by
    by_cases hn : 46 ≤ n
    · exact hn
    have hle : n ≤ 46 := by omega
    have eq := bootstrapAdvance_add n (46-n) (true,liftConfig origin)
    rw [show n+(46-n)=46 by omega,advance_46,finish,bootstrap_warm] at eq
    exact False.elim (Bool.noConfusion (congrArg Prod.fst eq))
  refine ⟨n-46,?_⟩
  have he := bootstrapAdvance_add 46 (n-46) (true,liftConfig origin)
  rw [show 46+(n-46)=n by omega,finish,advance_46] at he
  exact he.symm

/-- The complete calibration of the signed source at the literal binary margin. -/
theorem signed_margin_halts_iff_goal :
    BootstrapHalts (true,liftConfig margin) ↔ Deriv goal :=
  (bootstrap_halts_at advance_46).symm.trans signed_source_halts_iff_goal

end NF192.StartupCalibration

#print axioms NF192.StartupCalibration.advance_46
#print axioms NF192.StartupCalibration.margin_reaches_warm
#print axioms NF192.StartupCalibration.signed_margin_halts_iff_goal
