module
public import ArithmeticPhases

@[expose] public section
namespace NF192.Phase
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block2560 : checkRange 2560 32 = true := by decide +kernel
theorem block2592 : checkRange 2592 32 = true := by decide +kernel
theorem block2624 : checkRange 2624 32 = true := by decide +kernel
theorem block2656 : checkRange 2656 32 = true := by decide +kernel
theorem block2688 : checkRange 2688 32 = true := by decide +kernel
theorem block2720 : checkRange 2720 32 = true := by decide +kernel
theorem block2752 : checkRange 2752 32 = true := by decide +kernel
theorem block2784 : checkRange 2784 32 = true := by decide +kernel

end NF192.Phase
