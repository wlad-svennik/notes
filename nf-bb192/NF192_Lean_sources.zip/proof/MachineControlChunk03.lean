module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases03_00 : List Case := [
  ⟨614, false, 254821354240, 48662924032, 78, 0, 0⟩,
  ⟨615, false, 31483054848, 1418283776, 70, 0, 0⟩,
  ⟨619, false, 33630538496, 3565767424, 72, 0, 0⟩,
  ⟨623, false, 13095226112, 210324224, 68, 0, 0⟩,
  ⟨626, false, 28127611648, 2357807872, 72, 0, 0⟩,
  ⟨630, false, 247170943744, 6652775168, 78, 0, 0⟩,
  ⟨635, false, 1020265057024, 195631336192, 82, 0, 0⟩,
  ⟨636, false, 126911859456, 6652775168, 74, 0, 0⟩
]

theorem cases03_00_verified : cases03_00.all verified = true := by decide

def cases03_01 : List Case := [
  ⟨639, false, 66782317312, 15242709760, 76, 0, 0⟩,
  ⟨643, false, 16316451584, 1284066048, 68, 0, 0⟩,
  ⟨646, false, 3968420608, 747195136, 64, 0, 0⟩,
  ⟨650, true, 90673072896, 13363661568, 39, 33, 40⟩,
  ⟨653, false, 262471764736, 56313334528, 80, 0, 0⟩,
  ⟨654, false, 13363661568, 478759680, 72, 0, 0⟩,
  ⟨657, false, 15511145216, 2626243328, 72, 0, 0⟩,
  ⟨661, false, 61682043648, 1552501504, 74, 0, 0⟩
]

theorem cases03_01_verified : cases03_01.all verified = true := by decide

def cases03_02 : List Case := [
  ⟨666, false, 254955571968, 48797141760, 78, 0, 0⟩,
  ⟨667, false, 31617272576, 1552501504, 70, 0, 0⟩,
  ⟨671, false, 33764756224, 3699985152, 72, 0, 0⟩,
  ⟨676, true, 22591130368, 3263777536, 35, 31, 38⟩,
  ⟨679, false, 65540803328, 14001195776, 74, 0, 0⟩,
  ⟨680, false, 3263777536, 42552064, 66, 0, 0⟩,
  ⟨683, false, 3800648448, 579422976, 66, 0, 0⟩,
  ⟨687, false, 15343373056, 310987520, 68, 0, 0⟩
]

theorem cases03_02_verified : cases03_02.all verified = true := by decide

def cases03_03 : List Case := [
  ⟨692, false, 63661755136, 12122147584, 72, 0, 0⟩,
  ⟨693, false, 7827180288, 310987520, 64, 0, 0⟩,
  ⟨697, false, 8364051200, 847858432, 66, 0, 0⟩,
  ⟨702, true, 11383950080, 1720273664, 34, 30, 37⟩,
  ⟨705, false, 32858786560, 7088982784, 72, 0, 0⟩,
  ⟨706, false, 1720273664, 109660928, 64, 0, 0⟩,
  ⟨709, false, 1988709120, 378096384, 64, 0, 0⟩,
  ⟨713, false, 7760071424, 243878656, 66, 0, 0⟩
]

theorem cases03_03_verified : cases03_03.all verified = true := by decide

def cases03_04 : List Case := [
  ⟨718, false, 31919262464, 6149458688, 70, 0, 0⟩,
  ⟨719, false, 4001975040, 243878656, 62, 0, 0⟩,
  ⟨723, false, 4270410496, 512314112, 64, 0, 0⟩,
  ⟨726, false, 831081216, 25774848, 60, 0, 0⟩,
  ⟨729, false, 1770605312, 159992576, 64, 0, 0⟩,
  ⟨733, false, 15460813568, 428428032, 70, 0, 0⟩,
  ⟨738, false, 63779195648, 12239588096, 74, 0, 0⟩,
  ⟨739, false, 7944620800, 428428032, 66, 0, 0⟩
]

theorem cases03_04_verified : cases03_04.all verified = true := by decide

def cases03_05 : List Case := [
  ⟨742, false, 4186524416, 965298944, 68, 0, 0⟩,
  ⟨746, false, 1971931904, 92883712, 62, 0, 0⟩,
  ⟨749, false, 1032407808, 227101440, 60, 0, 0⟩,
  ⟨752, false, 3280554752, 59329280, 62, 0, 0⟩,
  ⟨755, false, 7038651136, 596200192, 66, 0, 0⟩,
  ⟨759, false, 61799484160, 1669942016, 72, 0, 0⟩,
  ⟨764, false, 255073012480, 48914582272, 76, 0, 0⟩,
  ⟨765, false, 31734713088, 1669942016, 68, 0, 0⟩
]

theorem cases03_05_verified : cases03_05.all verified = true := by decide

def cases03_06 : List Case := [
  ⟨768, false, 16702327552, 3817425664, 70, 0, 0⟩,
  ⟨772, false, 4085861120, 327764736, 62, 0, 0⟩,
  ⟨775, false, 998853376, 193547008, 58, 0, 0⟩,
  ⟨779, true, 22675016448, 3347663616, 35, 31, 38⟩,
  ⟨782, false, 65624689408, 14085081856, 74, 0, 0⟩,
  ⟨783, false, 3347663616, 126438144, 66, 0, 0⟩,
  ⟨786, false, 3884534528, 663309056, 66, 0, 0⟩,
  ⟨790, false, 15427259136, 394873600, 68, 0, 0⟩
]

theorem cases03_06_verified : cases03_06.all verified = true := by decide

def cases03_07 : List Case := [
  ⟨795, false, 63745641216, 12206033664, 72, 0, 0⟩,
  ⟨796, false, 7911066368, 394873600, 64, 0, 0⟩,
  ⟨800, false, 8447937280, 931744512, 66, 0, 0⟩,
  ⟨804, false, 407456512, 4803328, 58, 0, 0⟩,
  ⟨807, false, 877218560, 71912192, 62, 0, 0⟩,
  ⟨811, false, 7722322688, 206129920, 68, 0, 0⟩,
  ⟨816, false, 31881513728, 6111709952, 72, 0, 0⟩,
  ⟨817, false, 3964226304, 206129920, 64, 0, 0⟩
]

theorem cases03_07_verified : cases03_07.all verified = true := by decide

def cases03 : List Case := cases03_00 ++ cases03_01 ++ cases03_02 ++ cases03_03 ++ cases03_04 ++ cases03_05 ++ cases03_06 ++ cases03_07

theorem cases03_verified : cases03.all verified = true := by
  simp only [cases03, List.all_append, cases03_00_verified, cases03_01_verified, cases03_02_verified, cases03_03_verified, cases03_04_verified, cases03_05_verified, cases03_06_verified, cases03_07_verified, Bool.and_self]

end NF192.Control
