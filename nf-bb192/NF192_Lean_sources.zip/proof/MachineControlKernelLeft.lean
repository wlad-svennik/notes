module
public import MachineControlKernelWord

@[expose] public section
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-!
# Exact leftward word transformations

The leftward counterpart of `RightRun`, with the initial head on the last
cell of the displayed word and the final head one cell before its first.
All statements preserve arbitrary tape on both sides.
-/

namespace NF192.KernelRightShift

open NF210 NF210.TM
open NF192.Selected (State machine)

structure LeftRun (first last : State) (input output : List Bool) : Prop where
  same_length : input.length = output.length
  exact_run : ∀ (anchor : Int) (outside : Tape),
    TM.run machine input.length
      (configuration first (anchor + (input.length : Int) - 1) (wordTape anchor input outside)) =
      configuration last (anchor - 1) (wordTape anchor output outside)

theorem LeftRun.nil (state : State) : LeftRun state state [] [] := by
  constructor
  · rfl
  · intros; simp

/-- Execution first crosses the right word and then the adjacent left word. -/
theorem LeftRun.trans {first middle last : State}
    {input₁ output₁ input₂ output₂ : List Bool}
    (right : LeftRun first middle input₁ output₁)
    (left : LeftRun middle last input₂ output₂) :
    LeftRun first last (input₂ ++ input₁) (output₂ ++ output₁) := by
  constructor
  · simp only [List.length_append, right.same_length, left.same_length]
  · intro anchor outside
    rw [List.length_append]
    have time : input₂.length + input₁.length = input₁.length + input₂.length := by omega
    rw [time, TM.run_add]
    have position : anchor + ((input₁.length + input₂.length : Nat) : Int) - 1 =
        anchor + (input₂.length : Int) + (input₁.length : Int) - 1 := by omega
    rw [position, wordTape_append]
    rw [wordTape_commute anchor (anchor + (input₂.length : Int)) input₂ input₁ outside
      (Int.le_refl _)]
    rw [right.exact_run]
    rw [← wordTape_commute anchor (anchor + (input₂.length : Int)) input₂ output₁ outside
      (Int.le_refl _)]
    rw [left.exact_run, wordTape_append, ← left.same_length]

theorem LeftRun.one {first last : State} {read write : Bool}
    (row : machine first read = ⟨write, .left, some last⟩) :
    LeftRun first last [read] [write] := by
  constructor
  · rfl
  · intro anchor outside
    simp only [List.length_singleton]
    have position : anchor + ((1 : Nat) : Int) - 1 = anchor := by omega
    rw [position]
    change TM.step machine (configuration first anchor (wordTape anchor [read] outside)) = _
    rw [step_read row anchor _ (by simp)]
    simp [moveHead, writeTape_overwrite]

theorem LeftRun.repeat {state : State} {read write : Bool}
    (one : LeftRun state state [read] [write]) (count : Nat) :
    LeftRun state state (List.replicate count read) (List.replicate count write) := by
  induction count with
  | zero => exact LeftRun.nil state
  | succ count ih => exact ih.trans one

theorem LeftRun.with_suffix {first last : State} {input output : List Bool}
    (certificate : LeftRun first last input output)
    (anchor : Int) (suffix : List Bool) (outside : Tape) :
    TM.run machine input.length
      (configuration first (anchor + (input.length : Int) - 1)
        (wordTape anchor (input ++ suffix) outside)) =
      configuration last (anchor - 1) (wordTape anchor (output ++ suffix) outside) := by
  rw [wordTape_append, certificate.exact_run, wordTape_append, ← certificate.same_length]

theorem LeftRun.context {first last : State} {input output : List Bool}
    (certificate : LeftRun first last input output)
    (anchor : Int) (front suffix : List Bool) (outside : Tape) :
    TM.run machine input.length
      (configuration first (anchor + (front.length : Int) + (input.length : Int) - 1)
        (wordTape anchor (front ++ input ++ suffix) outside)) =
      configuration last (anchor + (front.length : Int) - 1)
        (wordTape anchor (front ++ output ++ suffix) outside) := by
  rw [List.append_assoc, wordTape_append]
  rw [wordTape_commute anchor (anchor + (front.length : Int)) front (input ++ suffix) outside
    (Int.le_refl _)]
  rw [certificate.with_suffix]
  rw [← wordTape_commute anchor (anchor + (front.length : Int)) front (output ++ suffix) outside
    (Int.le_refl _)]
  rw [← wordTape_append, ← List.append_assoc]

#print axioms LeftRun.trans

end NF192.KernelRightShift
