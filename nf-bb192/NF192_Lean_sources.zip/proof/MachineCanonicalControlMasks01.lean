module
public import MachineCanonicalControlMasks

@[expose] public section
namespace NF192.CanonicalControl
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem mask0512 : checkRange 512 32 = true := by decide +kernel
theorem mask0544 : checkRange 544 32 = true := by decide +kernel
theorem mask0576 : checkRange 576 32 = true := by decide +kernel
theorem mask0608 : checkRange 608 32 = true := by decide +kernel
theorem mask0640 : checkRange 640 32 = true := by decide +kernel
theorem mask0672 : checkRange 672 32 = true := by decide +kernel
theorem mask0704 : checkRange 704 32 = true := by decide +kernel
theorem mask0736 : checkRange 736 32 = true := by decide +kernel
theorem mask0768 : checkRange 768 32 = true := by decide +kernel
theorem mask0800 : checkRange 800 32 = true := by decide +kernel
theorem mask0832 : checkRange 832 32 = true := by decide +kernel
theorem mask0864 : checkRange 864 32 = true := by decide +kernel
theorem mask0896 : checkRange 896 32 = true := by decide +kernel
theorem mask0928 : checkRange 928 32 = true := by decide +kernel
theorem mask0960 : checkRange 960 32 = true := by decide +kernel
theorem mask0992 : checkRange 992 32 = true := by decide +kernel
end NF192.CanonicalControl
