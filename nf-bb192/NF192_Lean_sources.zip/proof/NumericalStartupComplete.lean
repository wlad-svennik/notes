module
public import NumericalStartup
public import SourceComplete

@[expose] public section

/-! The real signed first AX reaches a sound ordinary boundary. Combining
that prefix with the complete post-refill source proof proves the halting
equivalence at the source phase that the blank binary table actually enters. -/

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Emitter

open Numerical ProofSearch SourceSimulation

theorem bootstrap_warm (n : Nat) (c : Source.Config) :
    bootstrapAdvance n (false,c) = (false,Source.advance n c) := by
  induction n generalizing c with
  | zero => rfl
  | succ n ih => exact ih (Source.step c)

theorem from_warm_zero_read (s : State) :
    Moves (atFrame 10 (registers 0 0 s)) (atFrame 0 (registers 0 0 (ProofSearch.step (.mp 0) s))) :=
  command_encoded selected_ax 0 (.mp 0) 0 s

def firstBoundaryProof : State := ProofSearch.step (.mp 0) startupProof

theorem firstBoundaryProof_sound : firstBoundaryProof.Sound :=
  step_sound _ _ startupProof_sound

theorem signed_startup_boundary :
    ∃ n, 0 < n ∧ bootstrapAdvance n (true,atFrame 40 ⟨0,0,0,2,0,0,0⟩) =
      (false,atFrame 0 (registers 0 0 firstBoundaryProof)) := by
  obtain ⟨n, hn, before⟩ := signed_startup
  obtain ⟨m, hm, afterRead⟩ := from_warm_zero_read startupProof
  change bootstrapAdvance n (true,atFrame 40 ⟨0,0,0,2,0,0,0⟩) =
    (false,atFrame 10 (registers 0 0 startupProof)) at before
  exact ⟨n+m, by omega, by rw [bootstrapAdvance_add,before,bootstrap_warm,afterRead]; rfl⟩

def BootstrapHalts (s : Bool × Source.Config) : Prop :=
  ∃ n, (bootstrapAdvance n s).2 = Source.Config.halted

theorem bootstrap_absorbing (b : Bool) (n : Nat) :
    bootstrapAdvance n (b,Source.Config.halted) = (b,Source.Config.halted) := by
  induction n with
  | zero => rfl
  | succ n ih =>
      have one : bootstrapStep (b,Source.Config.halted) = (b,Source.Config.halted) := by
        cases b <;> rfl
      rw [bootstrapAdvance,one,ih]

theorem bootstrap_halts_at {s t : Bool × Source.Config} {k : Nat}
    (h : bootstrapAdvance k s = t) : BootstrapHalts s ↔ BootstrapHalts t := by
  constructor
  · rintro ⟨n,hn⟩
    refine ⟨n,?_⟩
    rw [←h,←bootstrapAdvance_add,Nat.add_comm,bootstrapAdvance_add]
    obtain ⟨b,hs⟩ : ∃ b, bootstrapAdvance n s = (b,Source.Config.halted) :=
      ⟨(bootstrapAdvance n s).1, Prod.ext rfl hn⟩
    rw [hs,bootstrap_absorbing]
  · rintro ⟨n,hn⟩
    exact ⟨k+n,by rw [bootstrapAdvance_add,h,hn]⟩

theorem bootstrap_warm_halts (c : Source.Config) : BootstrapHalts (false,c) ↔
    ∃ n, Source.advance n c = Source.Config.halted := by
  simp only [BootstrapHalts, bootstrap_warm]

/-- Starting at the actual first AX with the negative logical register. -/
theorem signed_source_halts_iff_goal :
    BootstrapHalts (true,atFrame 40 ⟨0,0,0,2,0,0,0⟩) ↔ Deriv goal := by
  obtain ⟨_,_,h⟩ := signed_startup_boundary
  exact (bootstrap_halts_at h).trans ((bootstrap_warm_halts _).trans
    (literal_source_iff_goal 0 0 firstBoundaryProof firstBoundaryProof_sound))

#print axioms signed_source_halts_iff_goal
end NF192.Emitter
