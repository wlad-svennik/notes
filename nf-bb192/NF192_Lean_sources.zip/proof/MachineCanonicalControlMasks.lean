module
public import MachineControlComplete
public import MachineFrame
public import MachineWordEncoding

@[expose] public section

namespace NF192.CanonicalControl

open NF210 NF210.TM NF192.Control NF192.Frame

set_option maxHeartbeats 0
set_option maxRecDepth 100000

def windowWord (pc : Nat) : List Bool :=
  List.replicate 8 false ++ (true :: addressBits pc) ++
    List.replicate (32-(addressBits pc).length) false

def maskCheck (pc : Nat) : Bool :=
  let s := Source.siteAt pc
  decide ((addressBits pc).length ≤ 31 ∧
    BitsWord.encode (windowWord pc) = pathMask s.address ∧
    (isControl s = true → Source.destination (targetAddress s) < 3089))

def checkRange (lo size : Nat) := (List.range size).all fun j => maskCheck (lo+j)

theorem checked_in_range {lo size i : Nat} (ok : checkRange lo size = true)
    (lower : lo ≤ i) (upper : i < lo+size) : maskCheck i = true := by
  have h := List.all_eq_true.mp ok (i-lo) (List.mem_range.mpr (by omega))
  simpa only [show lo+(i-lo) = i by omega] using h

end NF192.CanonicalControl
