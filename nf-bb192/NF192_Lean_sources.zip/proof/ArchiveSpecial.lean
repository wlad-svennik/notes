module
public import ArchiveTerms

@[expose] public section

/-! Some archived algebras do admit a direct term. When R is chosen as
B B, the two output objects have distinct fixed reduction laws and a
three-argument context switches them to K(B) and B respectively. -/

namespace NF192.ArchiveTerms
namespace Term

local infixl:70 " ◁ᵗ " => Term.app
def I : Term := .B ◁ᵗ (.B ◁ᵗ .B ◁ᵗ .B) ◁ᵗ .B

/-- Simultaneously lift the tested function and argument, then apply the
old tester's result to one additional closed argument. -/
def applyOutput (t d : Term) : Term :=
  let j := .B ◁ᵗ .konst (.B ◁ᵗ .konst .B) ◁ᵗ I
  let l := .B ◁ᵗ .konst (.B ◁ᵗ .konst t) ◁ᵗ j
  let m := .B ◁ᵗ (.B ◁ᵗ .konst .B ◁ᵗ l) ◁ᵗ .konst I
  .B ◁ᵗ (.B ◁ᵗ .konst .B ◁ᵗ m) ◁ᵗ .konst (.konst d)

def bbNormalized : Term :=
  ((Term.Q.applyOutput (.konst (.konst (.konst .B)))).applyOutput (.konst .B)).applyOutput .B

end Term
namespace Model
variable {A : Type u} (M : Model A)
local infixl:70 " ⬝ " => M.app
set_option maxHeartbeats 1000000

def liftFun (f : A) := M.B ⬝ M.K f

private theorem liftFun_apply (f x : A) : M.liftFun f ⬝ M.K x = M.K (f ⬝ x) := by
  apply M.ext
  intro z
  simp only [liftFun,M.b,M.k]

private theorem liftFun_fixed (f x : A) : M.liftFun f ⬝ M.K x = M.K x ↔ f ⬝ x = x := by
  rw [M.liftFun_apply]
  constructor
  · intro eq
    have h := congrArg (fun u => u ⬝ M.B) eq
    simpa only [M.k] using h
  · exact congrArg M.K

theorem applyOutput_spec (t d : Term) (f x : A) :
    M.eval M.Q (t.applyOutput d) ⬝ f ⬝ x =
      M.eval M.Q t ⬝ M.liftFun f ⬝ M.K x ⬝ M.eval M.Q d := by
  simp only [Term.applyOutput, Term.I, eval, liftFun, M.b, M.k]

private theorem bb_app (a c d : A) :
    (M.B ⬝ M.B) ⬝ a ⬝ c ⬝ d = c ⬝ ((a ⬝ c) ⬝ d) := by simp only [M.b,M.k]

/-- The reverse Boolean conversion is a pure CombNF term when the false
output is B B. The hypothesis specifies the archived truth-value convention. -/
theorem bb_normalized_term (hR : M.R = M.B ⬝ M.B) (f x : A) :
    (f ⬝ x = x → M.eval M.Q Term.bbNormalized ⬝ f ⬝ x = M.K M.B) ∧
    (f ⬝ x ≠ x → M.eval M.Q Term.bbNormalized ⬝ f ⬝ x = M.B) := by
  simp only [Term.bbNormalized, M.applyOutput_spec, eval]
  constructor
  · intro fixed
    rw [M.success _ _ ((M.liftFun_fixed _ _).2 ((M.liftFun_fixed _ _).2
      ((M.liftFun_fixed _ _).2 fixed)))]
    simp only [M.b,M.k]
  · intro notfixed
    rw [M.failure _ _ (fun h => notfixed ((M.liftFun_fixed _ _).1
      ((M.liftFun_fixed _ _).1 ((M.liftFun_fixed _ _).1 h)))),hR,M.bb_app,M.k]

#print axioms bb_normalized_term
end Model
end NF192.ArchiveTerms
