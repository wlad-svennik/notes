module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases20_00 : List Case := [
  ⟨1917, false, 1918, false, 28, 1, 35⟩,
  ⟨1919, false, 1920, false, 28, 1, 35⟩,
  ⟨1919, true, 1922, false, 27, 2, 34⟩,
  ⟨1920, false, 1921, false, 29, 1, 36⟩,
  ⟨1922, false, 1923, false, 30, 1, 37⟩,
  ⟨1922, true, 1926, false, 29, 2, 36⟩,
  ⟨1923, false, 1924, false, 31, 1, 38⟩,
  ⟨1924, false, 1925, false, 32, 1, 39⟩]
theorem carryCases20_00_verified : carryCases20_00.all verified = true := by decide

def carryCases20_01 : List Case := [
  ⟨1926, false, 1927, false, 30, 1, 37⟩,
  ⟨1926, true, 1932, false, 28, 3, 35⟩,
  ⟨1927, false, 1928, false, 32, 1, 39⟩,
  ⟨1928, false, 1929, false, 33, 1, 40⟩,
  ⟨1928, true, 1931, false, 31, 3, 38⟩,
  ⟨1929, false, 1930, false, 34, 1, 41⟩,
  ⟨1932, false, 1933, false, 29, 1, 36⟩,
  ⟨1932, true, 1935, false, 25, 5, 32⟩]
theorem carryCases20_01_verified : carryCases20_01.all verified = true := by decide

def carryCases20_02 : List Case := [
  ⟨1933, false, 1934, false, 30, 1, 37⟩,
  ⟨1935, false, 1936, false, 27, 1, 34⟩,
  ⟨1935, true, 1939, false, 26, 2, 33⟩,
  ⟨1936, false, 1937, false, 28, 1, 35⟩,
  ⟨1937, false, 1938, false, 29, 1, 36⟩,
  ⟨1939, false, 1940, false, 27, 1, 34⟩,
  ⟨1939, true, 1942, false, 24, 4, 31⟩,
  ⟨1940, false, 1941, false, 28, 1, 35⟩]
theorem carryCases20_02_verified : carryCases20_02.all verified = true := by decide

def carryCases20_03 : List Case := [
  ⟨1942, false, 1943, false, 29, 1, 36⟩,
  ⟨1942, true, 1945, false, 28, 2, 35⟩,
  ⟨1943, false, 1944, false, 30, 1, 37⟩,
  ⟨1945, false, 1946, false, 30, 1, 37⟩,
  ⟨1945, true, 1948, false, 29, 2, 36⟩,
  ⟨1946, false, 1947, false, 31, 1, 38⟩,
  ⟨1948, false, 1949, false, 32, 1, 39⟩,
  ⟨1948, true, 1952, false, 31, 2, 38⟩]
theorem carryCases20_03_verified : carryCases20_03.all verified = true := by decide

def carryCases20_04 : List Case := [
  ⟨1949, false, 1950, false, 33, 1, 40⟩,
  ⟨1950, false, 1951, false, 34, 1, 41⟩,
  ⟨1952, false, 1953, false, 32, 1, 39⟩,
  ⟨1952, true, 1958, false, 30, 3, 37⟩,
  ⟨1953, false, 1954, false, 34, 1, 41⟩,
  ⟨1954, false, 1955, false, 35, 1, 42⟩,
  ⟨1954, true, 1957, false, 33, 3, 40⟩,
  ⟨1955, false, 1956, false, 36, 1, 43⟩]
theorem carryCases20_04_verified : carryCases20_04.all verified = true := by decide

def carryCases20_05 : List Case := [
  ⟨1958, false, 1959, false, 31, 1, 38⟩,
  ⟨1958, true, 1961, false, 27, 5, 34⟩,
  ⟨1959, false, 1960, false, 32, 1, 39⟩,
  ⟨1961, false, 1962, false, 28, 1, 35⟩,
  ⟨1961, true, 1965, false, 26, 3, 33⟩,
  ⟨1962, false, 1963, false, 29, 1, 36⟩,
  ⟨1963, false, 1964, false, 30, 1, 37⟩,
  ⟨1965, false, 1966, false, 27, 1, 34⟩]
theorem carryCases20_05_verified : carryCases20_05.all verified = true := by decide

def carryCases20_06 : List Case := [
  ⟨1965, true, 1968, false, 25, 3, 32⟩,
  ⟨1966, false, 1967, false, 28, 1, 35⟩,
  ⟨1968, false, 1969, false, 29, 1, 36⟩,
  ⟨1968, true, 1976, false, 28, 2, 35⟩,
  ⟨1969, false, 1970, false, 31, 1, 38⟩,
  ⟨1970, false, 1971, false, 33, 1, 40⟩,
  ⟨1970, true, 1972, false, 32, 2, 39⟩,
  ⟨1972, false, 1973, false, 33, 1, 40⟩]
theorem carryCases20_06_verified : carryCases20_06.all verified = true := by decide

def carryCases20_07 : List Case := [
  ⟨1972, true, 1975, false, 30, 4, 37⟩,
  ⟨1973, false, 1974, false, 34, 1, 41⟩,
  ⟨1976, false, 1977, false, 29, 1, 36⟩,
  ⟨1976, true, 1979, false, 27, 3, 34⟩,
  ⟨1977, false, 1978, false, 30, 1, 37⟩,
  ⟨1979, false, 1980, false, 30, 1, 37⟩,
  ⟨1979, true, 1983, false, 29, 2, 36⟩,
  ⟨1980, false, 1981, false, 31, 1, 38⟩]
theorem carryCases20_07_verified : carryCases20_07.all verified = true := by decide

def carryCases20_08 : List Case := [
  ⟨1981, false, 1982, false, 32, 1, 39⟩,
  ⟨1983, false, 1984, false, 30, 1, 37⟩,
  ⟨1983, true, 1989, false, 28, 3, 35⟩,
  ⟨1984, false, 1985, false, 32, 1, 39⟩,
  ⟨1985, false, 1986, false, 33, 1, 40⟩,
  ⟨1985, true, 1988, false, 31, 3, 38⟩,
  ⟨1986, false, 1987, false, 34, 1, 41⟩,
  ⟨1989, false, 1990, false, 29, 1, 36⟩]
theorem carryCases20_08_verified : carryCases20_08.all verified = true := by decide

def carryCases20_09 : List Case := [
  ⟨1989, true, 1993, false, 26, 4, 33⟩,
  ⟨1990, false, 1991, false, 30, 1, 37⟩,
  ⟨1991, false, 1992, false, 31, 1, 38⟩,
  ⟨1993, false, 1994, false, 23, 4, 30⟩,
  ⟨1994, false, 1995, false, 28, 1, 35⟩,
  ⟨1994, true, 1997, false, 27, 2, 34⟩,
  ⟨1995, false, 1996, false, 29, 1, 36⟩,
  ⟨1997, false, 1998, false, 29, 1, 36⟩]
theorem carryCases20_09_verified : carryCases20_09.all verified = true := by decide

def carryCases20_10 : List Case := [
  ⟨1997, true, 2000, false, 28, 2, 35⟩,
  ⟨1998, false, 1999, false, 30, 1, 37⟩,
  ⟨2000, false, 2001, false, 31, 1, 38⟩,
  ⟨2000, true, 2004, false, 30, 2, 37⟩,
  ⟨2001, false, 2002, false, 32, 1, 39⟩,
  ⟨2002, false, 2003, false, 33, 1, 40⟩,
  ⟨2004, false, 2005, false, 31, 1, 38⟩,
  ⟨2004, true, 2010, false, 29, 3, 36⟩]
theorem carryCases20_10_verified : carryCases20_10.all verified = true := by decide

def carryCases20_11 : List Case := [
  ⟨2005, false, 2006, false, 33, 1, 40⟩,
  ⟨2006, false, 2007, false, 34, 1, 41⟩,
  ⟨2006, true, 2009, false, 32, 3, 39⟩,
  ⟨2007, false, 2008, false, 35, 1, 42⟩,
  ⟨2010, false, 2011, false, 30, 1, 37⟩,
  ⟨2010, true, 2013, false, 26, 5, 33⟩,
  ⟨2011, false, 2012, false, 31, 1, 38⟩,
  ⟨2013, false, 2014, false, 28, 1, 35⟩]
theorem carryCases20_11_verified : carryCases20_11.all verified = true := by decide

def carryCases20 : List Case := carryCases20_00 ++ carryCases20_01 ++ carryCases20_02 ++ carryCases20_03 ++ carryCases20_04 ++ carryCases20_05 ++ carryCases20_06 ++ carryCases20_07 ++ carryCases20_08 ++ carryCases20_09 ++ carryCases20_10 ++ carryCases20_11
theorem carryCases20_verified : carryCases20.all verified = true := by
  simp only [carryCases20, List.all_append, carryCases20_00_verified, carryCases20_01_verified, carryCases20_02_verified, carryCases20_03_verified, carryCases20_04_verified, carryCases20_05_verified, carryCases20_06_verified, carryCases20_07_verified, carryCases20_08_verified, carryCases20_09_verified, carryCases20_10_verified, carryCases20_11_verified, Bool.and_self]
theorem carryCases20_covered : carryCases20.map (fun c => key c.pc c.zero) = keysBetween 3834 193 := by decide
theorem carryCases20_count : carryCases20.length = 96 := by decide
end NF192.Carry
