module
public import MachineBitsWord
public import MachineControlKernelContracts

@[expose] public section

namespace NF192.BitsWord

open NF210 NF210.TM NF192.KernelRightShift

/-- Padding a finite word with the symbol already present leaves its tape unchanged. -/
theorem word_with_boundary (xs : List Bool) (a : Int) (t : Tape) :
    wordTape a (xs ++ [t (a + (xs.length : Int))]) t = wordTape a xs t := by
  rw [wordTape_append]
  congr 1
  funext p
  change (if p = a + (xs.length : Int) then t (a + (xs.length : Int)) else t p) = t p
  split <;> simp_all

/-- One scratch bit at the right of a calculation can be taken from any outside
tape when both starting values give the same finite-word transformation. -/
theorem padded_word_run (q q' : Selected.State) (xs ys : List Bool)
    (h h' duration : Nat) (same : xs.length = ys.length) (inside : h < xs.length + 1)
    (check : ∀ b : Bool, KernelBits.run Selected.machine (xs.length + 1) duration
      ⟨some q,h,encode (xs ++ [b])⟩ = some ⟨some q',h',encode (ys ++ [b])⟩) :
    WordRun q q' xs ys (h : Int) (h' : Int) duration := by
  refine ⟨same, ?_⟩
  intro anchor outside
  let b := outside (anchor + (xs.length : Int))
  have applyRun := (KernelBits.run_sound Selected.machine _ anchor outside _ _ _ inside (check b)).2
  have left : KernelBits.tape (xs.length + 1) anchor outside (encode (xs ++ [b])) =
      wordTape anchor xs outside := by
    rw [show xs.length + 1 = (xs ++ [b]).length by simp, tape_encode]
    exact word_with_boundary xs anchor outside
  have right : KernelBits.tape (xs.length + 1) anchor outside (encode (ys ++ [b])) =
      wordTape anchor ys outside := by
    rw [show xs.length + 1 = (ys ++ [b]).length by simp [same], tape_encode]
    simpa only [b,same] using word_with_boundary ys anchor outside
  simpa only [KernelBits.embed, configuration, left, right] using applyRun

end NF192.BitsWord
