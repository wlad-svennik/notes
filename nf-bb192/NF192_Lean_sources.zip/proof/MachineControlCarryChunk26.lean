module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases26_00 : List Case := [
  ⟨2493, true, 2496, false, 27, 3, 34⟩,
  ⟨2494, false, 2495, false, 30, 1, 37⟩,
  ⟨2496, false, 2497, false, 31, 1, 38⟩,
  ⟨2496, true, 2504, false, 30, 2, 37⟩,
  ⟨2497, false, 2498, false, 33, 1, 40⟩,
  ⟨2498, false, 2499, false, 35, 1, 42⟩,
  ⟨2498, true, 2500, false, 34, 2, 41⟩,
  ⟨2500, false, 2501, false, 35, 1, 42⟩]
theorem carryCases26_00_verified : carryCases26_00.all verified = true := by decide

def carryCases26_01 : List Case := [
  ⟨2500, true, 2503, false, 32, 4, 39⟩,
  ⟨2501, false, 2502, false, 36, 1, 43⟩,
  ⟨2504, false, 2505, false, 31, 1, 38⟩,
  ⟨2504, true, 2507, false, 29, 3, 36⟩,
  ⟨2505, false, 2506, false, 32, 1, 39⟩,
  ⟨2507, false, 2508, false, 32, 1, 39⟩,
  ⟨2507, true, 2511, false, 31, 2, 38⟩,
  ⟨2508, false, 2509, false, 33, 1, 40⟩]
theorem carryCases26_01_verified : carryCases26_01.all verified = true := by decide

def carryCases26_02 : List Case := [
  ⟨2509, false, 2510, false, 34, 1, 41⟩,
  ⟨2511, false, 2512, false, 32, 1, 39⟩,
  ⟨2511, true, 2517, false, 30, 3, 37⟩,
  ⟨2512, false, 2513, false, 34, 1, 41⟩,
  ⟨2513, false, 2514, false, 35, 1, 42⟩,
  ⟨2513, true, 2516, false, 33, 3, 40⟩,
  ⟨2514, false, 2515, false, 36, 1, 43⟩,
  ⟨2517, false, 2518, false, 31, 1, 38⟩]
theorem carryCases26_02_verified : carryCases26_02.all verified = true := by decide

def carryCases26_03 : List Case := [
  ⟨2517, true, 2521, false, 28, 4, 35⟩,
  ⟨2518, false, 2519, false, 32, 1, 39⟩,
  ⟨2519, false, 2520, false, 33, 1, 40⟩,
  ⟨2521, false, 2522, false, 24, 5, 31⟩,
  ⟨2522, false, 2523, false, 29, 1, 36⟩,
  ⟨2522, true, 2530, false, 28, 2, 35⟩,
  ⟨2523, false, 2524, false, 31, 1, 38⟩,
  ⟨2524, false, 2525, false, 33, 1, 40⟩]
theorem carryCases26_03_verified : carryCases26_03.all verified = true := by decide

def carryCases26_04 : List Case := [
  ⟨2524, true, 2526, false, 32, 2, 39⟩,
  ⟨2526, false, 2527, false, 33, 1, 40⟩,
  ⟨2526, true, 2529, false, 30, 4, 37⟩,
  ⟨2527, false, 2528, false, 34, 1, 41⟩,
  ⟨2530, false, 2531, false, 29, 1, 36⟩,
  ⟨2530, true, 2533, false, 27, 3, 34⟩,
  ⟨2531, false, 2532, false, 30, 1, 37⟩,
  ⟨2533, false, 2534, false, 30, 1, 37⟩]
theorem carryCases26_04_verified : carryCases26_04.all verified = true := by decide

def carryCases26_05 : List Case := [
  ⟨2533, true, 2537, false, 29, 2, 36⟩,
  ⟨2534, false, 2535, false, 31, 1, 38⟩,
  ⟨2535, false, 2536, false, 32, 1, 39⟩,
  ⟨2537, false, 2538, false, 30, 1, 37⟩,
  ⟨2537, true, 2543, false, 28, 3, 35⟩,
  ⟨2538, false, 2539, false, 32, 1, 39⟩,
  ⟨2539, false, 2540, false, 33, 1, 40⟩,
  ⟨2539, true, 2542, false, 31, 3, 38⟩]
theorem carryCases26_05_verified : carryCases26_05.all verified = true := by decide

def carryCases26_06 : List Case := [
  ⟨2540, false, 2541, false, 34, 1, 41⟩,
  ⟨2543, false, 2544, false, 29, 1, 36⟩,
  ⟨2543, true, 2547, false, 26, 4, 33⟩,
  ⟨2544, false, 2545, false, 30, 1, 37⟩,
  ⟨2545, false, 2546, false, 31, 1, 38⟩,
  ⟨2547, false, 2548, false, 25, 2, 32⟩,
  ⟨2548, false, 2549, false, 28, 1, 35⟩,
  ⟨2548, true, 2556, false, 27, 2, 34⟩]
theorem carryCases26_06_verified : carryCases26_06.all verified = true := by decide

def carryCases26_07 : List Case := [
  ⟨2549, false, 2550, false, 30, 1, 37⟩,
  ⟨2550, false, 2551, false, 32, 1, 39⟩,
  ⟨2550, true, 2552, false, 31, 2, 38⟩,
  ⟨2552, false, 2553, false, 32, 1, 39⟩,
  ⟨2552, true, 2555, false, 29, 4, 36⟩,
  ⟨2553, false, 2554, false, 33, 1, 40⟩,
  ⟨2556, false, 2557, false, 28, 1, 35⟩,
  ⟨2556, true, 2559, false, 26, 3, 33⟩]
theorem carryCases26_07_verified : carryCases26_07.all verified = true := by decide

def carryCases26_08 : List Case := [
  ⟨2557, false, 2558, false, 29, 1, 36⟩,
  ⟨2559, false, 2560, false, 29, 1, 36⟩,
  ⟨2559, true, 2563, false, 28, 2, 35⟩,
  ⟨2560, false, 2561, false, 30, 1, 37⟩,
  ⟨2561, false, 2562, false, 31, 1, 38⟩,
  ⟨2563, false, 2564, false, 29, 1, 36⟩,
  ⟨2563, true, 2569, false, 27, 3, 34⟩,
  ⟨2564, false, 2565, false, 31, 1, 38⟩]
theorem carryCases26_08_verified : carryCases26_08.all verified = true := by decide

def carryCases26_09 : List Case := [
  ⟨2565, false, 2566, false, 32, 1, 39⟩,
  ⟨2565, true, 2568, false, 30, 3, 37⟩,
  ⟨2566, false, 2567, false, 33, 1, 40⟩,
  ⟨2569, false, 2570, false, 28, 1, 35⟩,
  ⟨2569, true, 2573, false, 23, 6, 30⟩,
  ⟨2570, false, 2571, false, 29, 1, 36⟩,
  ⟨2571, false, 2572, false, 30, 1, 37⟩,
  ⟨2573, false, 2574, false, 28, 1, 35⟩]
theorem carryCases26_09_verified : carryCases26_09.all verified = true := by decide

def carryCases26_10 : List Case := [
  ⟨2573, true, 2576, false, 27, 2, 34⟩,
  ⟨2574, false, 2575, false, 29, 1, 36⟩,
  ⟨2576, false, 2577, false, 29, 1, 36⟩,
  ⟨2576, true, 2579, false, 28, 2, 35⟩,
  ⟨2577, false, 2578, false, 30, 1, 37⟩,
  ⟨2579, false, 2580, false, 31, 1, 38⟩,
  ⟨2579, true, 2583, false, 30, 2, 37⟩,
  ⟨2580, false, 2581, false, 32, 1, 39⟩]
theorem carryCases26_10_verified : carryCases26_10.all verified = true := by decide

def carryCases26_11 : List Case := [
  ⟨2581, false, 2582, false, 33, 1, 40⟩,
  ⟨2583, false, 2584, false, 31, 1, 38⟩,
  ⟨2583, true, 2589, false, 29, 3, 36⟩,
  ⟨2584, false, 2585, false, 33, 1, 40⟩,
  ⟨2585, false, 2586, false, 34, 1, 41⟩,
  ⟨2585, true, 2588, false, 32, 3, 39⟩,
  ⟨2586, false, 2587, false, 35, 1, 42⟩,
  ⟨2589, false, 2590, false, 30, 1, 37⟩]
theorem carryCases26_11_verified : carryCases26_11.all verified = true := by decide

def carryCases26 : List Case := carryCases26_00 ++ carryCases26_01 ++ carryCases26_02 ++ carryCases26_03 ++ carryCases26_04 ++ carryCases26_05 ++ carryCases26_06 ++ carryCases26_07 ++ carryCases26_08 ++ carryCases26_09 ++ carryCases26_10 ++ carryCases26_11
theorem carryCases26_verified : carryCases26.all verified = true := by
  simp only [carryCases26, List.all_append, carryCases26_00_verified, carryCases26_01_verified, carryCases26_02_verified, carryCases26_03_verified, carryCases26_04_verified, carryCases26_05_verified, carryCases26_06_verified, carryCases26_07_verified, carryCases26_08_verified, carryCases26_09_verified, carryCases26_10_verified, carryCases26_11_verified, Bool.and_self]
theorem carryCases26_covered : carryCases26.map (fun c => key c.pc c.zero) = keysBetween 4987 192 := by decide
theorem carryCases26_count : carryCases26.length = 96 := by decide
end NF192.Carry
