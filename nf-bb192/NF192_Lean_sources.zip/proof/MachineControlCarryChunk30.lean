module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases30_00 : List Case := [
  ⟨2877, true, 2880, false, 26, 5, 33⟩,
  ⟨2878, false, 2879, false, 31, 1, 38⟩,
  ⟨2880, false, 2881, false, 28, 1, 35⟩,
  ⟨2880, true, 2884, false, 27, 2, 34⟩,
  ⟨2881, false, 2882, false, 29, 1, 36⟩,
  ⟨2882, false, 2883, false, 30, 1, 37⟩,
  ⟨2884, false, 2885, false, 28, 1, 35⟩,
  ⟨2884, true, 2887, false, 25, 4, 32⟩]
theorem carryCases30_00_verified : carryCases30_00.all verified = true := by decide

def carryCases30_01 : List Case := [
  ⟨2885, false, 2886, false, 29, 1, 36⟩,
  ⟨2887, false, 2888, false, 30, 1, 37⟩,
  ⟨2887, true, 2890, false, 29, 2, 36⟩,
  ⟨2888, false, 2889, false, 31, 1, 38⟩,
  ⟨2890, false, 2891, false, 31, 1, 38⟩,
  ⟨2890, true, 2893, false, 30, 2, 37⟩,
  ⟨2891, false, 2892, false, 32, 1, 39⟩,
  ⟨2893, false, 2894, false, 33, 1, 40⟩]
theorem carryCases30_01_verified : carryCases30_01.all verified = true := by decide

def carryCases30_02 : List Case := [
  ⟨2893, true, 2897, false, 32, 2, 39⟩,
  ⟨2894, false, 2895, false, 34, 1, 41⟩,
  ⟨2895, false, 2896, false, 35, 1, 42⟩,
  ⟨2897, false, 2898, false, 33, 1, 40⟩,
  ⟨2897, true, 2903, false, 31, 3, 38⟩,
  ⟨2898, false, 2899, false, 35, 1, 42⟩,
  ⟨2899, false, 2900, false, 36, 1, 43⟩,
  ⟨2899, true, 2902, false, 34, 3, 41⟩]
theorem carryCases30_02_verified : carryCases30_02.all verified = true := by decide

def carryCases30_03 : List Case := [
  ⟨2900, false, 2901, false, 37, 1, 44⟩,
  ⟨2903, false, 2904, false, 32, 1, 39⟩,
  ⟨2903, true, 2906, false, 28, 5, 35⟩,
  ⟨2904, false, 2905, false, 33, 1, 40⟩,
  ⟨2906, false, 2907, false, 29, 1, 36⟩,
  ⟨2906, true, 2910, false, 27, 3, 34⟩,
  ⟨2907, false, 2908, false, 30, 1, 37⟩,
  ⟨2908, false, 2909, false, 31, 1, 38⟩]
theorem carryCases30_03_verified : carryCases30_03.all verified = true := by decide

def carryCases30_04 : List Case := [
  ⟨2910, false, 2911, false, 28, 1, 35⟩,
  ⟨2910, true, 2913, false, 26, 3, 33⟩,
  ⟨2911, false, 2912, false, 29, 1, 36⟩,
  ⟨2913, false, 2914, false, 30, 1, 37⟩,
  ⟨2913, true, 2921, false, 29, 2, 36⟩,
  ⟨2914, false, 2915, false, 32, 1, 39⟩,
  ⟨2915, false, 2916, false, 34, 1, 41⟩,
  ⟨2915, true, 2917, false, 33, 2, 40⟩]
theorem carryCases30_04_verified : carryCases30_04.all verified = true := by decide

def carryCases30_05 : List Case := [
  ⟨2917, false, 2918, false, 34, 1, 41⟩,
  ⟨2917, true, 2920, false, 31, 4, 38⟩,
  ⟨2918, false, 2919, false, 35, 1, 42⟩,
  ⟨2921, false, 2922, false, 30, 1, 37⟩,
  ⟨2921, true, 2924, false, 28, 3, 35⟩,
  ⟨2922, false, 2923, false, 31, 1, 38⟩,
  ⟨2924, false, 2925, false, 31, 1, 38⟩,
  ⟨2924, true, 2928, false, 30, 2, 37⟩]
theorem carryCases30_05_verified : carryCases30_05.all verified = true := by decide

def carryCases30_06 : List Case := [
  ⟨2925, false, 2926, false, 32, 1, 39⟩,
  ⟨2926, false, 2927, false, 33, 1, 40⟩,
  ⟨2928, false, 2929, false, 31, 1, 38⟩,
  ⟨2928, true, 2934, false, 29, 3, 36⟩,
  ⟨2929, false, 2930, false, 33, 1, 40⟩,
  ⟨2930, false, 2931, false, 34, 1, 41⟩,
  ⟨2930, true, 2933, false, 32, 3, 39⟩,
  ⟨2931, false, 2932, false, 35, 1, 42⟩]
theorem carryCases30_06_verified : carryCases30_06.all verified = true := by decide

def carryCases30_07 : List Case := [
  ⟨2934, false, 2935, false, 30, 1, 37⟩,
  ⟨2934, true, 2938, false, 27, 4, 34⟩,
  ⟨2935, false, 2936, false, 31, 1, 38⟩,
  ⟨2936, false, 2937, false, 32, 1, 39⟩,
  ⟨2938, false, 2939, false, 24, 4, 31⟩,
  ⟨2939, false, 2940, false, 27, 1, 34⟩,
  ⟨2939, true, 2947, false, 26, 2, 33⟩,
  ⟨2940, false, 2941, false, 29, 1, 36⟩]
theorem carryCases30_07_verified : carryCases30_07.all verified = true := by decide

def carryCases30_08 : List Case := [
  ⟨2941, false, 2942, false, 31, 1, 38⟩,
  ⟨2941, true, 2943, false, 30, 2, 37⟩,
  ⟨2943, false, 2944, false, 31, 1, 38⟩,
  ⟨2943, true, 2946, false, 28, 4, 35⟩,
  ⟨2944, false, 2945, false, 32, 1, 39⟩,
  ⟨2947, false, 2948, false, 27, 1, 34⟩,
  ⟨2947, true, 2950, false, 25, 3, 32⟩,
  ⟨2948, false, 2949, false, 28, 1, 35⟩]
theorem carryCases30_08_verified : carryCases30_08.all verified = true := by decide

def carryCases30_09 : List Case := [
  ⟨2950, false, 2951, false, 28, 1, 35⟩,
  ⟨2950, true, 2954, false, 27, 2, 34⟩,
  ⟨2951, false, 2952, false, 29, 1, 36⟩,
  ⟨2952, false, 2953, false, 30, 1, 37⟩,
  ⟨2954, false, 2955, false, 28, 1, 35⟩,
  ⟨2954, true, 2960, false, 26, 3, 33⟩,
  ⟨2955, false, 2956, false, 30, 1, 37⟩,
  ⟨2956, false, 2957, false, 31, 1, 38⟩]
theorem carryCases30_09_verified : carryCases30_09.all verified = true := by decide

def carryCases30_10 : List Case := [
  ⟨2956, true, 2959, false, 29, 3, 36⟩,
  ⟨2957, false, 2958, false, 32, 1, 39⟩,
  ⟨2960, false, 2961, false, 27, 1, 34⟩,
  ⟨2960, true, 2964, false, 18, 10, 25⟩,
  ⟨2961, false, 2962, false, 28, 1, 35⟩,
  ⟨2962, false, 2963, false, 29, 1, 36⟩,
  ⟨2964, false, 2965, false, 20, 1, 27⟩,
  ⟨2964, true, 2966, false, 19, 2, 26⟩]
theorem carryCases30_10_verified : carryCases30_10.all verified = true := by decide

def carryCases30_11 : List Case := [
  ⟨2966, false, 2967, false, 20, 1, 27⟩,
  ⟨2966, true, 2968, false, 15, 6, 22⟩,
  ⟨2969, false, 2970, false, 15, 1, 22⟩,
  ⟨2969, true, 2996, false, 14, 2, 21⟩,
  ⟨2970, false, 2971, false, 19, 1, 26⟩,
  ⟨2970, true, 2973, false, 18, 2, 25⟩,
  ⟨2971, false, 2972, false, 20, 1, 27⟩,
  ⟨2973, false, 2974, false, 20, 1, 27⟩]
theorem carryCases30_11_verified : carryCases30_11.all verified = true := by decide

def carryCases30 : List Case := carryCases30_00 ++ carryCases30_01 ++ carryCases30_02 ++ carryCases30_03 ++ carryCases30_04 ++ carryCases30_05 ++ carryCases30_06 ++ carryCases30_07 ++ carryCases30_08 ++ carryCases30_09 ++ carryCases30_10 ++ carryCases30_11
theorem carryCases30_verified : carryCases30.all verified = true := by
  simp only [carryCases30, List.all_append, carryCases30_00_verified, carryCases30_01_verified, carryCases30_02_verified, carryCases30_03_verified, carryCases30_04_verified, carryCases30_05_verified, carryCases30_06_verified, carryCases30_07_verified, carryCases30_08_verified, carryCases30_09_verified, carryCases30_10_verified, carryCases30_11_verified, Bool.and_self]
theorem carryCases30_covered : carryCases30.map (fun c => key c.pc c.zero) = keysBetween 5755 192 := by decide
theorem carryCases30_count : carryCases30.length = 96 := by decide
end NF192.Carry
