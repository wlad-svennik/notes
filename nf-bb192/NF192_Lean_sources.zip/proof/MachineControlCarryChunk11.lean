module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases11_00 : List Case := [
  ⟨1054, false, 1055, false, 26, 1, 33⟩,
  ⟨1054, true, 1058, false, 24, 3, 31⟩,
  ⟨1055, false, 1056, false, 27, 1, 34⟩,
  ⟨1056, false, 1057, false, 28, 1, 35⟩,
  ⟨1058, false, 1059, false, 25, 1, 32⟩,
  ⟨1058, true, 1061, false, 23, 3, 30⟩,
  ⟨1059, false, 1060, false, 26, 1, 33⟩,
  ⟨1061, false, 1062, false, 27, 1, 34⟩]
theorem carryCases11_00_verified : carryCases11_00.all verified = true := by decide

def carryCases11_01 : List Case := [
  ⟨1061, true, 1069, false, 26, 2, 33⟩,
  ⟨1062, false, 1063, false, 29, 1, 36⟩,
  ⟨1063, false, 1064, false, 31, 1, 38⟩,
  ⟨1063, true, 1065, false, 30, 2, 37⟩,
  ⟨1065, false, 1066, false, 31, 1, 38⟩,
  ⟨1065, true, 1068, false, 28, 4, 35⟩,
  ⟨1066, false, 1067, false, 32, 1, 39⟩,
  ⟨1069, false, 1070, false, 27, 1, 34⟩]
theorem carryCases11_01_verified : carryCases11_01.all verified = true := by decide

def carryCases11_02 : List Case := [
  ⟨1069, true, 1072, false, 25, 3, 32⟩,
  ⟨1070, false, 1071, false, 28, 1, 35⟩,
  ⟨1072, false, 1073, false, 28, 1, 35⟩,
  ⟨1072, true, 1076, false, 27, 2, 34⟩,
  ⟨1073, false, 1074, false, 29, 1, 36⟩,
  ⟨1074, false, 1075, false, 30, 1, 37⟩,
  ⟨1076, false, 1077, false, 28, 1, 35⟩,
  ⟨1076, true, 1082, false, 26, 3, 33⟩]
theorem carryCases11_02_verified : carryCases11_02.all verified = true := by decide

def carryCases11_03 : List Case := [
  ⟨1077, false, 1078, false, 30, 1, 37⟩,
  ⟨1078, false, 1079, false, 31, 1, 38⟩,
  ⟨1078, true, 1081, false, 29, 3, 36⟩,
  ⟨1079, false, 1080, false, 32, 1, 39⟩,
  ⟨1082, false, 1083, false, 27, 1, 34⟩,
  ⟨1082, true, 1086, false, 24, 4, 31⟩,
  ⟨1083, false, 1084, false, 28, 1, 35⟩,
  ⟨1084, false, 1085, false, 29, 1, 36⟩]
theorem carryCases11_03_verified : carryCases11_03.all verified = true := by decide

def carryCases11_04 : List Case := [
  ⟨1086, false, 1087, false, 20, 5, 27⟩,
  ⟨1087, false, 1088, false, 24, 1, 31⟩,
  ⟨1088, false, 1089, false, 29, 1, 36⟩,
  ⟨1088, true, 1091, false, 28, 2, 35⟩,
  ⟨1089, false, 1090, false, 30, 1, 37⟩,
  ⟨1091, false, 1092, false, 30, 1, 37⟩,
  ⟨1091, true, 1094, false, 29, 2, 36⟩,
  ⟨1092, false, 1093, false, 31, 1, 38⟩]
theorem carryCases11_04_verified : carryCases11_04.all verified = true := by decide

def carryCases11_05 : List Case := [
  ⟨1094, false, 1095, false, 32, 1, 39⟩,
  ⟨1094, true, 1098, false, 31, 2, 38⟩,
  ⟨1095, false, 1096, false, 33, 1, 40⟩,
  ⟨1096, false, 1097, false, 34, 1, 41⟩,
  ⟨1098, false, 1099, false, 32, 1, 39⟩,
  ⟨1098, true, 1104, false, 30, 3, 37⟩,
  ⟨1099, false, 1100, false, 34, 1, 41⟩,
  ⟨1100, false, 1101, false, 35, 1, 42⟩]
theorem carryCases11_05_verified : carryCases11_05.all verified = true := by decide

def carryCases11_06 : List Case := [
  ⟨1100, true, 1103, false, 33, 3, 40⟩,
  ⟨1101, false, 1102, false, 36, 1, 43⟩,
  ⟨1104, false, 1105, false, 31, 1, 38⟩,
  ⟨1104, true, 1107, false, 27, 5, 34⟩,
  ⟨1105, false, 1106, false, 32, 1, 39⟩,
  ⟨1107, false, 1108, false, 29, 1, 36⟩,
  ⟨1107, true, 1111, false, 28, 2, 35⟩,
  ⟨1108, false, 1109, false, 30, 1, 37⟩]
theorem carryCases11_06_verified : carryCases11_06.all verified = true := by decide

def carryCases11_07 : List Case := [
  ⟨1109, false, 1110, false, 31, 1, 38⟩,
  ⟨1111, false, 1112, false, 29, 1, 36⟩,
  ⟨1111, true, 1114, false, 26, 4, 33⟩,
  ⟨1112, false, 1113, false, 30, 1, 37⟩,
  ⟨1114, false, 1115, false, 30, 1, 37⟩,
  ⟨1114, true, 1122, false, 29, 2, 36⟩,
  ⟨1115, false, 1116, false, 32, 1, 39⟩,
  ⟨1116, false, 1117, false, 34, 1, 41⟩]
theorem carryCases11_07_verified : carryCases11_07.all verified = true := by decide

def carryCases11_08 : List Case := [
  ⟨1116, true, 1118, false, 33, 2, 40⟩,
  ⟨1118, false, 1119, false, 34, 1, 41⟩,
  ⟨1118, true, 1121, false, 31, 4, 38⟩,
  ⟨1119, false, 1120, false, 35, 1, 42⟩,
  ⟨1122, false, 1123, false, 30, 1, 37⟩,
  ⟨1122, true, 1125, false, 28, 3, 35⟩,
  ⟨1123, false, 1124, false, 31, 1, 38⟩,
  ⟨1125, false, 1126, false, 31, 1, 38⟩]
theorem carryCases11_08_verified : carryCases11_08.all verified = true := by decide

def carryCases11_09 : List Case := [
  ⟨1125, true, 1129, false, 30, 2, 37⟩,
  ⟨1126, false, 1127, false, 32, 1, 39⟩,
  ⟨1127, false, 1128, false, 33, 1, 40⟩,
  ⟨1129, false, 1130, false, 31, 1, 38⟩,
  ⟨1129, true, 1135, false, 29, 3, 36⟩,
  ⟨1130, false, 1131, false, 33, 1, 40⟩,
  ⟨1131, false, 1132, false, 34, 1, 41⟩,
  ⟨1131, true, 1134, false, 32, 3, 39⟩]
theorem carryCases11_09_verified : carryCases11_09.all verified = true := by decide

def carryCases11_10 : List Case := [
  ⟨1132, false, 1133, false, 35, 1, 42⟩,
  ⟨1135, false, 1136, false, 30, 1, 37⟩,
  ⟨1135, true, 1139, false, 27, 4, 34⟩,
  ⟨1136, false, 1137, false, 31, 1, 38⟩,
  ⟨1137, false, 1138, false, 32, 1, 39⟩,
  ⟨1139, false, 1140, false, 25, 3, 32⟩,
  ⟨1140, false, 1141, false, 30, 1, 37⟩,
  ⟨1140, true, 1143, false, 29, 2, 36⟩]
theorem carryCases11_10_verified : carryCases11_10.all verified = true := by decide

def carryCases11_11 : List Case := [
  ⟨1141, false, 1142, false, 31, 1, 38⟩,
  ⟨1143, false, 1144, false, 31, 1, 38⟩,
  ⟨1143, true, 1146, false, 30, 2, 37⟩,
  ⟨1144, false, 1145, false, 32, 1, 39⟩,
  ⟨1146, false, 1147, false, 33, 1, 40⟩,
  ⟨1146, true, 1150, false, 32, 2, 39⟩,
  ⟨1147, false, 1148, false, 34, 1, 41⟩,
  ⟨1148, false, 1149, false, 35, 1, 42⟩]
theorem carryCases11_11_verified : carryCases11_11.all verified = true := by decide

def carryCases11 : List Case := carryCases11_00 ++ carryCases11_01 ++ carryCases11_02 ++ carryCases11_03 ++ carryCases11_04 ++ carryCases11_05 ++ carryCases11_06 ++ carryCases11_07 ++ carryCases11_08 ++ carryCases11_09 ++ carryCases11_10 ++ carryCases11_11
theorem carryCases11_verified : carryCases11.all verified = true := by
  simp only [carryCases11, List.all_append, carryCases11_00_verified, carryCases11_01_verified, carryCases11_02_verified, carryCases11_03_verified, carryCases11_04_verified, carryCases11_05_verified, carryCases11_06_verified, carryCases11_07_verified, carryCases11_08_verified, carryCases11_09_verified, carryCases11_10_verified, carryCases11_11_verified, Bool.and_self]
theorem carryCases11_covered : carryCases11.map (fun c => key c.pc c.zero) = keysBetween 2108 192 := by decide
theorem carryCases11_count : carryCases11.length = 96 := by decide
end NF192.Carry
