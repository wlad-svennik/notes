module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases01_00 : List Case := [
  ⟨92, true, 95, false, 29, 3, 36⟩,
  ⟨93, false, 94, false, 32, 1, 39⟩,
  ⟨96, false, 97, false, 27, 1, 34⟩,
  ⟨96, true, 99, false, 23, 5, 30⟩,
  ⟨97, false, 98, false, 28, 1, 35⟩,
  ⟨99, false, 100, false, 25, 1, 32⟩,
  ⟨99, true, 103, false, 24, 2, 31⟩,
  ⟨100, false, 101, false, 26, 1, 33⟩]
theorem carryCases01_00_verified : carryCases01_00.all verified = true := by decide

def carryCases01_01 : List Case := [
  ⟨101, false, 102, false, 27, 1, 34⟩,
  ⟨103, false, 104, false, 25, 1, 32⟩,
  ⟨103, true, 106, false, 21, 5, 28⟩,
  ⟨104, false, 105, false, 26, 1, 33⟩,
  ⟨106, false, 107, false, 25, 1, 32⟩,
  ⟨106, true, 114, false, 24, 2, 31⟩,
  ⟨107, false, 108, false, 27, 1, 34⟩,
  ⟨108, false, 109, false, 29, 1, 36⟩]
theorem carryCases01_01_verified : carryCases01_01.all verified = true := by decide

def carryCases01_02 : List Case := [
  ⟨108, true, 110, false, 28, 2, 35⟩,
  ⟨110, false, 111, false, 29, 1, 36⟩,
  ⟨110, true, 113, false, 26, 4, 33⟩,
  ⟨111, false, 112, false, 30, 1, 37⟩,
  ⟨114, false, 115, false, 25, 1, 32⟩,
  ⟨114, true, 117, false, 23, 3, 30⟩,
  ⟨115, false, 116, false, 26, 1, 33⟩,
  ⟨117, false, 118, false, 24, 1, 31⟩]
theorem carryCases01_02_verified : carryCases01_02.all verified = true := by decide

def carryCases01_03 : List Case := [
  ⟨117, true, 120, false, 22, 3, 29⟩,
  ⟨118, false, 119, false, 25, 1, 32⟩,
  ⟨120, false, 121, false, 25, 1, 32⟩,
  ⟨120, true, 128, false, 24, 2, 31⟩,
  ⟨121, false, 122, false, 27, 1, 34⟩,
  ⟨122, false, 123, false, 29, 1, 36⟩,
  ⟨122, true, 124, false, 28, 2, 35⟩,
  ⟨124, false, 125, false, 29, 1, 36⟩]
theorem carryCases01_03_verified : carryCases01_03.all verified = true := by decide

def carryCases01_04 : List Case := [
  ⟨124, true, 127, false, 26, 4, 33⟩,
  ⟨125, false, 126, false, 30, 1, 37⟩,
  ⟨128, false, 129, false, 25, 1, 32⟩,
  ⟨128, true, 131, false, 23, 3, 30⟩,
  ⟨129, false, 130, false, 26, 1, 33⟩,
  ⟨131, false, 132, false, 26, 1, 33⟩,
  ⟨131, true, 135, false, 25, 2, 32⟩,
  ⟨132, false, 133, false, 27, 1, 34⟩]
theorem carryCases01_04_verified : carryCases01_04.all verified = true := by decide

def carryCases01_05 : List Case := [
  ⟨133, false, 134, false, 28, 1, 35⟩,
  ⟨135, false, 136, false, 26, 1, 33⟩,
  ⟨135, true, 141, false, 24, 3, 31⟩,
  ⟨136, false, 137, false, 28, 1, 35⟩,
  ⟨137, false, 138, false, 29, 1, 36⟩,
  ⟨137, true, 140, false, 27, 3, 34⟩,
  ⟨138, false, 139, false, 30, 1, 37⟩,
  ⟨141, false, 142, false, 25, 1, 32⟩]
theorem carryCases01_05_verified : carryCases01_05.all verified = true := by decide

def carryCases01_06 : List Case := [
  ⟨141, true, 145, false, 19, 7, 26⟩,
  ⟨142, false, 143, false, 26, 1, 33⟩,
  ⟨143, false, 144, false, 27, 1, 34⟩,
  ⟨145, false, 146, false, 24, 1, 31⟩,
  ⟨145, true, 148, false, 23, 2, 30⟩,
  ⟨146, false, 147, false, 25, 1, 32⟩,
  ⟨148, false, 149, false, 25, 1, 32⟩,
  ⟨148, true, 151, false, 24, 2, 31⟩]
theorem carryCases01_06_verified : carryCases01_06.all verified = true := by decide

def carryCases01_07 : List Case := [
  ⟨149, false, 150, false, 26, 1, 33⟩,
  ⟨151, false, 152, false, 27, 1, 34⟩,
  ⟨151, true, 155, false, 26, 2, 33⟩,
  ⟨152, false, 153, false, 28, 1, 35⟩,
  ⟨153, false, 154, false, 29, 1, 36⟩,
  ⟨155, false, 156, false, 27, 1, 34⟩,
  ⟨155, true, 161, false, 25, 3, 32⟩,
  ⟨156, false, 157, false, 29, 1, 36⟩]
theorem carryCases01_07_verified : carryCases01_07.all verified = true := by decide

def carryCases01_08 : List Case := [
  ⟨157, false, 158, false, 30, 1, 37⟩,
  ⟨157, true, 160, false, 28, 3, 35⟩,
  ⟨158, false, 159, false, 31, 1, 38⟩,
  ⟨161, false, 162, false, 26, 1, 33⟩,
  ⟨161, true, 164, false, 22, 5, 29⟩,
  ⟨162, false, 163, false, 27, 1, 34⟩,
  ⟨164, false, 165, false, 24, 1, 31⟩,
  ⟨164, true, 168, false, 23, 2, 30⟩]
theorem carryCases01_08_verified : carryCases01_08.all verified = true := by decide

def carryCases01_09 : List Case := [
  ⟨165, false, 166, false, 25, 1, 32⟩,
  ⟨166, false, 167, false, 26, 1, 33⟩,
  ⟨168, false, 169, false, 24, 1, 31⟩,
  ⟨168, true, 171, false, 21, 4, 28⟩,
  ⟨169, false, 170, false, 25, 1, 32⟩,
  ⟨171, false, 172, false, 24, 1, 31⟩,
  ⟨171, true, 179, false, 23, 2, 30⟩,
  ⟨172, false, 173, false, 26, 1, 33⟩]
theorem carryCases01_09_verified : carryCases01_09.all verified = true := by decide

def carryCases01_10 : List Case := [
  ⟨173, false, 174, false, 28, 1, 35⟩,
  ⟨173, true, 175, false, 27, 2, 34⟩,
  ⟨175, false, 176, false, 28, 1, 35⟩,
  ⟨175, true, 178, false, 25, 4, 32⟩,
  ⟨176, false, 177, false, 29, 1, 36⟩,
  ⟨179, false, 180, false, 24, 1, 31⟩,
  ⟨179, true, 182, false, 22, 3, 29⟩,
  ⟨180, false, 181, false, 25, 1, 32⟩]
theorem carryCases01_10_verified : carryCases01_10.all verified = true := by decide

def carryCases01_11 : List Case := [
  ⟨182, false, 183, false, 25, 1, 32⟩,
  ⟨182, true, 186, false, 24, 2, 31⟩,
  ⟨183, false, 184, false, 26, 1, 33⟩,
  ⟨184, false, 185, false, 27, 1, 34⟩,
  ⟨186, false, 187, false, 25, 1, 32⟩,
  ⟨186, true, 192, false, 23, 3, 30⟩,
  ⟨187, false, 188, false, 27, 1, 34⟩,
  ⟨188, false, 189, false, 28, 1, 35⟩]
theorem carryCases01_11_verified : carryCases01_11.all verified = true := by decide

def carryCases01 : List Case := carryCases01_00 ++ carryCases01_01 ++ carryCases01_02 ++ carryCases01_03 ++ carryCases01_04 ++ carryCases01_05 ++ carryCases01_06 ++ carryCases01_07 ++ carryCases01_08 ++ carryCases01_09 ++ carryCases01_10 ++ carryCases01_11
theorem carryCases01_verified : carryCases01.all verified = true := by
  simp only [carryCases01, List.all_append, carryCases01_00_verified, carryCases01_01_verified, carryCases01_02_verified, carryCases01_03_verified, carryCases01_04_verified, carryCases01_05_verified, carryCases01_06_verified, carryCases01_07_verified, carryCases01_08_verified, carryCases01_09_verified, carryCases01_10_verified, carryCases01_11_verified, Bool.and_self]
theorem carryCases01_covered : carryCases01.map (fun c => key c.pc c.zero) = keysBetween 185 192 := by decide
theorem carryCases01_count : carryCases01.length = 96 := by decide
end NF192.Carry
