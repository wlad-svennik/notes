module
public import MachineCanonicalControlMasks

@[expose] public section
namespace NF192.CanonicalControl
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem mask0000 : checkRange 0 32 = true := by decide +kernel
theorem mask0032 : checkRange 32 32 = true := by decide +kernel
theorem mask0064 : checkRange 64 32 = true := by decide +kernel
theorem mask0096 : checkRange 96 32 = true := by decide +kernel
theorem mask0128 : checkRange 128 32 = true := by decide +kernel
theorem mask0160 : checkRange 160 32 = true := by decide +kernel
theorem mask0192 : checkRange 192 32 = true := by decide +kernel
theorem mask0224 : checkRange 224 32 = true := by decide +kernel
theorem mask0256 : checkRange 256 32 = true := by decide +kernel
theorem mask0288 : checkRange 288 32 = true := by decide +kernel
theorem mask0320 : checkRange 320 32 = true := by decide +kernel
theorem mask0352 : checkRange 352 32 = true := by decide +kernel
theorem mask0384 : checkRange 384 32 = true := by decide +kernel
theorem mask0416 : checkRange 416 32 = true := by decide +kernel
theorem mask0448 : checkRange 448 32 = true := by decide +kernel
theorem mask0480 : checkRange 480 32 = true := by decide +kernel
end NF192.CanonicalControl
