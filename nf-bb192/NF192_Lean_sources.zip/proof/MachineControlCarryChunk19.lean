module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases19_00 : List Case := [
  ⟨1822, false, 1823, false, 31, 1, 38⟩,
  ⟨1822, true, 1828, false, 29, 3, 36⟩,
  ⟨1823, false, 1824, false, 33, 1, 40⟩,
  ⟨1824, false, 1825, false, 34, 1, 41⟩,
  ⟨1824, true, 1827, false, 32, 3, 39⟩,
  ⟨1825, false, 1826, false, 35, 1, 42⟩,
  ⟨1828, false, 1829, false, 30, 1, 37⟩,
  ⟨1828, true, 1831, false, 26, 5, 33⟩]
theorem carryCases19_00_verified : carryCases19_00.all verified = true := by decide

def carryCases19_01 : List Case := [
  ⟨1829, false, 1830, false, 31, 1, 38⟩,
  ⟨1831, false, 1832, false, 27, 1, 34⟩,
  ⟨1831, true, 1835, false, 25, 3, 32⟩,
  ⟨1832, false, 1833, false, 28, 1, 35⟩,
  ⟨1833, false, 1834, false, 29, 1, 36⟩,
  ⟨1835, false, 1836, false, 26, 1, 33⟩,
  ⟨1835, true, 1838, false, 24, 3, 31⟩,
  ⟨1836, false, 1837, false, 27, 1, 34⟩]
theorem carryCases19_01_verified : carryCases19_01.all verified = true := by decide

def carryCases19_02 : List Case := [
  ⟨1838, false, 1839, false, 28, 1, 35⟩,
  ⟨1838, true, 1846, false, 27, 2, 34⟩,
  ⟨1839, false, 1840, false, 30, 1, 37⟩,
  ⟨1840, false, 1841, false, 32, 1, 39⟩,
  ⟨1840, true, 1842, false, 31, 2, 38⟩,
  ⟨1842, false, 1843, false, 32, 1, 39⟩,
  ⟨1842, true, 1845, false, 29, 4, 36⟩,
  ⟨1843, false, 1844, false, 33, 1, 40⟩]
theorem carryCases19_02_verified : carryCases19_02.all verified = true := by decide

def carryCases19_03 : List Case := [
  ⟨1846, false, 1847, false, 28, 1, 35⟩,
  ⟨1846, true, 1849, false, 26, 3, 33⟩,
  ⟨1847, false, 1848, false, 29, 1, 36⟩,
  ⟨1849, false, 1850, false, 29, 1, 36⟩,
  ⟨1849, true, 1853, false, 28, 2, 35⟩,
  ⟨1850, false, 1851, false, 30, 1, 37⟩,
  ⟨1851, false, 1852, false, 31, 1, 38⟩,
  ⟨1853, false, 1854, false, 29, 1, 36⟩]
theorem carryCases19_03_verified : carryCases19_03.all verified = true := by decide

def carryCases19_04 : List Case := [
  ⟨1853, true, 1859, false, 27, 3, 34⟩,
  ⟨1854, false, 1855, false, 31, 1, 38⟩,
  ⟨1855, false, 1856, false, 32, 1, 39⟩,
  ⟨1855, true, 1858, false, 30, 3, 37⟩,
  ⟨1856, false, 1857, false, 33, 1, 40⟩,
  ⟨1859, false, 1860, false, 28, 1, 35⟩,
  ⟨1859, true, 1863, false, 25, 4, 32⟩,
  ⟨1860, false, 1861, false, 29, 1, 36⟩]
theorem carryCases19_04_verified : carryCases19_04.all verified = true := by decide

def carryCases19_05 : List Case := [
  ⟨1861, false, 1862, false, 30, 1, 37⟩,
  ⟨1863, false, 1864, false, 22, 4, 29⟩,
  ⟨1864, false, 1865, false, 25, 1, 32⟩,
  ⟨1864, true, 1872, false, 24, 2, 31⟩,
  ⟨1865, false, 1866, false, 27, 1, 34⟩,
  ⟨1866, false, 1867, false, 29, 1, 36⟩,
  ⟨1866, true, 1868, false, 28, 2, 35⟩,
  ⟨1868, false, 1869, false, 29, 1, 36⟩]
theorem carryCases19_05_verified : carryCases19_05.all verified = true := by decide

def carryCases19_06 : List Case := [
  ⟨1868, true, 1871, false, 26, 4, 33⟩,
  ⟨1869, false, 1870, false, 30, 1, 37⟩,
  ⟨1872, false, 1873, false, 25, 1, 32⟩,
  ⟨1872, true, 1875, false, 23, 3, 30⟩,
  ⟨1873, false, 1874, false, 26, 1, 33⟩,
  ⟨1875, false, 1876, false, 26, 1, 33⟩,
  ⟨1875, true, 1879, false, 25, 2, 32⟩,
  ⟨1876, false, 1877, false, 27, 1, 34⟩]
theorem carryCases19_06_verified : carryCases19_06.all verified = true := by decide

def carryCases19_07 : List Case := [
  ⟨1877, false, 1878, false, 28, 1, 35⟩,
  ⟨1879, false, 1880, false, 26, 1, 33⟩,
  ⟨1879, true, 1885, false, 24, 3, 31⟩,
  ⟨1880, false, 1881, false, 28, 1, 35⟩,
  ⟨1881, false, 1882, false, 29, 1, 36⟩,
  ⟨1881, true, 1884, false, 27, 3, 34⟩,
  ⟨1882, false, 1883, false, 30, 1, 37⟩,
  ⟨1885, false, 1886, false, 25, 1, 32⟩]
theorem carryCases19_07_verified : carryCases19_07.all verified = true := by decide

def carryCases19_08 : List Case := [
  ⟨1885, true, 1889, false, 20, 6, 27⟩,
  ⟨1886, false, 1887, false, 26, 1, 33⟩,
  ⟨1887, false, 1888, false, 27, 1, 34⟩,
  ⟨1889, false, 1890, false, 23, 1, 30⟩,
  ⟨1890, false, 1891, false, 27, 1, 34⟩,
  ⟨1890, true, 1898, false, 26, 2, 33⟩,
  ⟨1891, false, 1892, false, 29, 1, 36⟩,
  ⟨1892, false, 1893, false, 31, 1, 38⟩]
theorem carryCases19_08_verified : carryCases19_08.all verified = true := by decide

def carryCases19_09 : List Case := [
  ⟨1892, true, 1894, false, 30, 2, 37⟩,
  ⟨1894, false, 1895, false, 31, 1, 38⟩,
  ⟨1894, true, 1897, false, 28, 4, 35⟩,
  ⟨1895, false, 1896, false, 32, 1, 39⟩,
  ⟨1898, false, 1899, false, 27, 1, 34⟩,
  ⟨1898, true, 1901, false, 25, 3, 32⟩,
  ⟨1899, false, 1900, false, 28, 1, 35⟩,
  ⟨1901, false, 1902, false, 28, 1, 35⟩]
theorem carryCases19_09_verified : carryCases19_09.all verified = true := by decide

def carryCases19_10 : List Case := [
  ⟨1901, true, 1905, false, 27, 2, 34⟩,
  ⟨1902, false, 1903, false, 29, 1, 36⟩,
  ⟨1903, false, 1904, false, 30, 1, 37⟩,
  ⟨1905, false, 1906, false, 28, 1, 35⟩,
  ⟨1905, true, 1911, false, 26, 3, 33⟩,
  ⟨1906, false, 1907, false, 30, 1, 37⟩,
  ⟨1907, false, 1908, false, 31, 1, 38⟩,
  ⟨1907, true, 1910, false, 29, 3, 36⟩]
theorem carryCases19_10_verified : carryCases19_10.all verified = true := by decide

def carryCases19_11 : List Case := [
  ⟨1908, false, 1909, false, 32, 1, 39⟩,
  ⟨1911, false, 1912, false, 27, 1, 34⟩,
  ⟨1911, true, 1915, false, 24, 4, 31⟩,
  ⟨1912, false, 1913, false, 28, 1, 35⟩,
  ⟨1913, false, 1914, false, 29, 1, 36⟩,
  ⟨1915, false, 1916, false, 22, 3, 29⟩,
  ⟨1916, false, 1917, false, 27, 1, 34⟩,
  ⟨1916, true, 1919, false, 26, 2, 33⟩]
theorem carryCases19_11_verified : carryCases19_11.all verified = true := by decide

def carryCases19 : List Case := carryCases19_00 ++ carryCases19_01 ++ carryCases19_02 ++ carryCases19_03 ++ carryCases19_04 ++ carryCases19_05 ++ carryCases19_06 ++ carryCases19_07 ++ carryCases19_08 ++ carryCases19_09 ++ carryCases19_10 ++ carryCases19_11
theorem carryCases19_verified : carryCases19.all verified = true := by
  simp only [carryCases19, List.all_append, carryCases19_00_verified, carryCases19_01_verified, carryCases19_02_verified, carryCases19_03_verified, carryCases19_04_verified, carryCases19_05_verified, carryCases19_06_verified, carryCases19_07_verified, carryCases19_08_verified, carryCases19_09_verified, carryCases19_10_verified, carryCases19_11_verified, Bool.and_self]
theorem carryCases19_covered : carryCases19.map (fun c => key c.pc c.zero) = keysBetween 3644 190 := by decide
theorem carryCases19_count : carryCases19.length = 96 := by decide
end NF192.Carry
