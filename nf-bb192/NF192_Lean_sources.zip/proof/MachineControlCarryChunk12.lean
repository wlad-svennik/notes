module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases12_00 : List Case := [
  ⟨1150, false, 1151, false, 33, 1, 40⟩,
  ⟨1150, true, 1156, false, 31, 3, 38⟩,
  ⟨1151, false, 1152, false, 35, 1, 42⟩,
  ⟨1152, false, 1153, false, 36, 1, 43⟩,
  ⟨1152, true, 1155, false, 34, 3, 41⟩,
  ⟨1153, false, 1154, false, 37, 1, 44⟩,
  ⟨1156, false, 1157, false, 32, 1, 39⟩,
  ⟨1156, true, 1159, false, 28, 5, 35⟩]
theorem carryCases12_00_verified : carryCases12_00.all verified = true := by decide

def carryCases12_01 : List Case := [
  ⟨1157, false, 1158, false, 33, 1, 40⟩,
  ⟨1159, false, 1160, false, 29, 1, 36⟩,
  ⟨1159, true, 1163, false, 27, 3, 34⟩,
  ⟨1160, false, 1161, false, 30, 1, 37⟩,
  ⟨1161, false, 1162, false, 31, 1, 38⟩,
  ⟨1163, false, 1164, false, 28, 1, 35⟩,
  ⟨1163, true, 1166, false, 26, 3, 33⟩,
  ⟨1164, false, 1165, false, 29, 1, 36⟩]
theorem carryCases12_01_verified : carryCases12_01.all verified = true := by decide

def carryCases12_02 : List Case := [
  ⟨1166, false, 1167, false, 30, 1, 37⟩,
  ⟨1166, true, 1174, false, 29, 2, 36⟩,
  ⟨1167, false, 1168, false, 32, 1, 39⟩,
  ⟨1168, false, 1169, false, 34, 1, 41⟩,
  ⟨1168, true, 1170, false, 33, 2, 40⟩,
  ⟨1170, false, 1171, false, 34, 1, 41⟩,
  ⟨1170, true, 1173, false, 31, 4, 38⟩,
  ⟨1171, false, 1172, false, 35, 1, 42⟩]
theorem carryCases12_02_verified : carryCases12_02.all verified = true := by decide

def carryCases12_03 : List Case := [
  ⟨1174, false, 1175, false, 30, 1, 37⟩,
  ⟨1174, true, 1177, false, 28, 3, 35⟩,
  ⟨1175, false, 1176, false, 31, 1, 38⟩,
  ⟨1177, false, 1178, false, 31, 1, 38⟩,
  ⟨1177, true, 1181, false, 30, 2, 37⟩,
  ⟨1178, false, 1179, false, 32, 1, 39⟩,
  ⟨1179, false, 1180, false, 33, 1, 40⟩,
  ⟨1181, false, 1182, false, 31, 1, 38⟩]
theorem carryCases12_03_verified : carryCases12_03.all verified = true := by decide

def carryCases12_04 : List Case := [
  ⟨1181, true, 1187, false, 29, 3, 36⟩,
  ⟨1182, false, 1183, false, 33, 1, 40⟩,
  ⟨1183, false, 1184, false, 34, 1, 41⟩,
  ⟨1183, true, 1186, false, 32, 3, 39⟩,
  ⟨1184, false, 1185, false, 35, 1, 42⟩,
  ⟨1187, false, 1188, false, 30, 1, 37⟩,
  ⟨1187, true, 1191, false, 27, 4, 34⟩,
  ⟨1188, false, 1189, false, 31, 1, 38⟩]
theorem carryCases12_04_verified : carryCases12_04.all verified = true := by decide

def carryCases12_05 : List Case := [
  ⟨1189, false, 1190, false, 32, 1, 39⟩,
  ⟨1191, false, 1192, false, 23, 5, 30⟩,
  ⟨1192, false, 1193, false, 28, 1, 35⟩,
  ⟨1192, true, 1195, false, 27, 2, 34⟩,
  ⟨1193, false, 1194, false, 29, 1, 36⟩,
  ⟨1195, false, 1196, false, 29, 1, 36⟩,
  ⟨1195, true, 1198, false, 28, 2, 35⟩,
  ⟨1196, false, 1197, false, 30, 1, 37⟩]
theorem carryCases12_05_verified : carryCases12_05.all verified = true := by decide

def carryCases12_06 : List Case := [
  ⟨1198, false, 1199, false, 31, 1, 38⟩,
  ⟨1198, true, 1202, false, 30, 2, 37⟩,
  ⟨1199, false, 1200, false, 32, 1, 39⟩,
  ⟨1200, false, 1201, false, 33, 1, 40⟩,
  ⟨1202, false, 1203, false, 31, 1, 38⟩,
  ⟨1202, true, 1208, false, 29, 3, 36⟩,
  ⟨1203, false, 1204, false, 33, 1, 40⟩,
  ⟨1204, false, 1205, false, 34, 1, 41⟩]
theorem carryCases12_06_verified : carryCases12_06.all verified = true := by decide

def carryCases12_07 : List Case := [
  ⟨1204, true, 1207, false, 32, 3, 39⟩,
  ⟨1205, false, 1206, false, 35, 1, 42⟩,
  ⟨1208, false, 1209, false, 30, 1, 37⟩,
  ⟨1208, true, 1211, false, 26, 5, 33⟩,
  ⟨1209, false, 1210, false, 31, 1, 38⟩,
  ⟨1211, false, 1212, false, 28, 1, 35⟩,
  ⟨1211, true, 1215, false, 27, 2, 34⟩,
  ⟨1212, false, 1213, false, 29, 1, 36⟩]
theorem carryCases12_07_verified : carryCases12_07.all verified = true := by decide

def carryCases12_08 : List Case := [
  ⟨1213, false, 1214, false, 30, 1, 37⟩,
  ⟨1215, false, 1216, false, 28, 1, 35⟩,
  ⟨1215, true, 1218, false, 25, 4, 32⟩,
  ⟨1216, false, 1217, false, 29, 1, 36⟩,
  ⟨1218, false, 1219, false, 29, 1, 36⟩,
  ⟨1218, true, 1221, false, 28, 2, 35⟩,
  ⟨1219, false, 1220, false, 30, 1, 37⟩,
  ⟨1221, false, 1222, false, 30, 1, 37⟩]
theorem carryCases12_08_verified : carryCases12_08.all verified = true := by decide

def carryCases12_09 : List Case := [
  ⟨1221, true, 1224, false, 29, 2, 36⟩,
  ⟨1222, false, 1223, false, 31, 1, 38⟩,
  ⟨1224, false, 1225, false, 32, 1, 39⟩,
  ⟨1224, true, 1228, false, 31, 2, 38⟩,
  ⟨1225, false, 1226, false, 33, 1, 40⟩,
  ⟨1226, false, 1227, false, 34, 1, 41⟩,
  ⟨1228, false, 1229, false, 32, 1, 39⟩,
  ⟨1228, true, 1234, false, 30, 3, 37⟩]
theorem carryCases12_09_verified : carryCases12_09.all verified = true := by decide

def carryCases12_10 : List Case := [
  ⟨1229, false, 1230, false, 34, 1, 41⟩,
  ⟨1230, false, 1231, false, 35, 1, 42⟩,
  ⟨1230, true, 1233, false, 33, 3, 40⟩,
  ⟨1231, false, 1232, false, 36, 1, 43⟩,
  ⟨1234, false, 1235, false, 31, 1, 38⟩,
  ⟨1234, true, 1237, false, 27, 5, 34⟩,
  ⟨1235, false, 1236, false, 32, 1, 39⟩,
  ⟨1237, false, 1238, false, 29, 1, 36⟩]
theorem carryCases12_10_verified : carryCases12_10.all verified = true := by decide

def carryCases12_11 : List Case := [
  ⟨1237, true, 1241, false, 28, 2, 35⟩,
  ⟨1238, false, 1239, false, 30, 1, 37⟩,
  ⟨1239, false, 1240, false, 31, 1, 38⟩,
  ⟨1241, false, 1242, false, 29, 1, 36⟩,
  ⟨1241, true, 1244, false, 26, 4, 33⟩,
  ⟨1242, false, 1243, false, 30, 1, 37⟩,
  ⟨1244, false, 1245, false, 30, 1, 37⟩,
  ⟨1244, true, 1252, false, 29, 2, 36⟩]
theorem carryCases12_11_verified : carryCases12_11.all verified = true := by decide

def carryCases12 : List Case := carryCases12_00 ++ carryCases12_01 ++ carryCases12_02 ++ carryCases12_03 ++ carryCases12_04 ++ carryCases12_05 ++ carryCases12_06 ++ carryCases12_07 ++ carryCases12_08 ++ carryCases12_09 ++ carryCases12_10 ++ carryCases12_11
theorem carryCases12_verified : carryCases12.all verified = true := by
  simp only [carryCases12, List.all_append, carryCases12_00_verified, carryCases12_01_verified, carryCases12_02_verified, carryCases12_03_verified, carryCases12_04_verified, carryCases12_05_verified, carryCases12_06_verified, carryCases12_07_verified, carryCases12_08_verified, carryCases12_09_verified, carryCases12_10_verified, carryCases12_11_verified, Bool.and_self]
theorem carryCases12_covered : carryCases12.map (fun c => key c.pc c.zero) = keysBetween 2300 190 := by decide
theorem carryCases12_count : carryCases12.length = 96 := by decide
end NF192.Carry
