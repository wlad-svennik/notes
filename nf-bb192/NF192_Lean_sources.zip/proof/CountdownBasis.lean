module
public import CountdownSearch
public import NumericalModel

@[expose] public section
namespace NF192

/-- A model-theoretic characterization of the exact blank-tape table.
The right side uses only the selected 192-state contender's algebra. -/
theorem countdown_nonhalting_iff_model :
    (¬ NF210.TM.Halts Selected.machine Selected.start) ↔
      ∃ A : Type, Nonempty (NormalizedBasis A) :=
  (not_congr countdown_halts_iff_goal).trans Numerical.not_deriv_goal_iff_basis

end NF192

#print axioms NF192.countdown_nonhalting_iff_model
