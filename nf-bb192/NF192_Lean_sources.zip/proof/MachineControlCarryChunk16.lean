module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases16_00 : List Case := [
  ⟨1533, true, 1536, false, 26, 3, 33⟩,
  ⟨1534, false, 1535, false, 29, 1, 36⟩,
  ⟨1536, false, 1537, false, 29, 1, 36⟩,
  ⟨1536, true, 1540, false, 28, 2, 35⟩,
  ⟨1537, false, 1538, false, 30, 1, 37⟩,
  ⟨1538, false, 1539, false, 31, 1, 38⟩,
  ⟨1540, false, 1541, false, 29, 1, 36⟩,
  ⟨1540, true, 1546, false, 27, 3, 34⟩]
theorem carryCases16_00_verified : carryCases16_00.all verified = true := by decide

def carryCases16_01 : List Case := [
  ⟨1541, false, 1542, false, 31, 1, 38⟩,
  ⟨1542, false, 1543, false, 32, 1, 39⟩,
  ⟨1542, true, 1545, false, 30, 3, 37⟩,
  ⟨1543, false, 1544, false, 33, 1, 40⟩,
  ⟨1546, false, 1547, false, 28, 1, 35⟩,
  ⟨1546, true, 1550, false, 25, 4, 32⟩,
  ⟨1547, false, 1548, false, 29, 1, 36⟩,
  ⟨1548, false, 1549, false, 30, 1, 37⟩]
theorem carryCases16_01_verified : carryCases16_01.all verified = true := by decide

def carryCases16_02 : List Case := [
  ⟨1550, false, 1551, false, 22, 4, 29⟩,
  ⟨1551, false, 1552, false, 27, 1, 34⟩,
  ⟨1551, true, 1554, false, 26, 2, 33⟩,
  ⟨1552, false, 1553, false, 28, 1, 35⟩,
  ⟨1554, false, 1555, false, 28, 1, 35⟩,
  ⟨1554, true, 1557, false, 27, 2, 34⟩,
  ⟨1555, false, 1556, false, 29, 1, 36⟩,
  ⟨1557, false, 1558, false, 30, 1, 37⟩]
theorem carryCases16_02_verified : carryCases16_02.all verified = true := by decide

def carryCases16_03 : List Case := [
  ⟨1557, true, 1561, false, 29, 2, 36⟩,
  ⟨1558, false, 1559, false, 31, 1, 38⟩,
  ⟨1559, false, 1560, false, 32, 1, 39⟩,
  ⟨1561, false, 1562, false, 30, 1, 37⟩,
  ⟨1561, true, 1567, false, 28, 3, 35⟩,
  ⟨1562, false, 1563, false, 32, 1, 39⟩,
  ⟨1563, false, 1564, false, 33, 1, 40⟩,
  ⟨1563, true, 1566, false, 31, 3, 38⟩]
theorem carryCases16_03_verified : carryCases16_03.all verified = true := by decide

def carryCases16_04 : List Case := [
  ⟨1564, false, 1565, false, 34, 1, 41⟩,
  ⟨1567, false, 1568, false, 29, 1, 36⟩,
  ⟨1567, true, 1570, false, 25, 5, 32⟩,
  ⟨1568, false, 1569, false, 30, 1, 37⟩,
  ⟨1570, false, 1571, false, 27, 1, 34⟩,
  ⟨1570, true, 1574, false, 26, 2, 33⟩,
  ⟨1571, false, 1572, false, 28, 1, 35⟩,
  ⟨1572, false, 1573, false, 29, 1, 36⟩]
theorem carryCases16_04_verified : carryCases16_04.all verified = true := by decide

def carryCases16_05 : List Case := [
  ⟨1574, false, 1575, false, 27, 1, 34⟩,
  ⟨1574, true, 1577, false, 24, 4, 31⟩,
  ⟨1575, false, 1576, false, 28, 1, 35⟩,
  ⟨1577, false, 1578, false, 28, 1, 35⟩,
  ⟨1577, true, 1585, false, 27, 2, 34⟩,
  ⟨1578, false, 1579, false, 30, 1, 37⟩,
  ⟨1579, false, 1580, false, 32, 1, 39⟩,
  ⟨1579, true, 1581, false, 31, 2, 38⟩]
theorem carryCases16_05_verified : carryCases16_05.all verified = true := by decide

def carryCases16_06 : List Case := [
  ⟨1581, false, 1582, false, 32, 1, 39⟩,
  ⟨1581, true, 1584, false, 29, 4, 36⟩,
  ⟨1582, false, 1583, false, 33, 1, 40⟩,
  ⟨1585, false, 1586, false, 28, 1, 35⟩,
  ⟨1585, true, 1588, false, 26, 3, 33⟩,
  ⟨1586, false, 1587, false, 29, 1, 36⟩,
  ⟨1588, false, 1589, false, 29, 1, 36⟩,
  ⟨1588, true, 1592, false, 28, 2, 35⟩]
theorem carryCases16_06_verified : carryCases16_06.all verified = true := by decide

def carryCases16_07 : List Case := [
  ⟨1589, false, 1590, false, 30, 1, 37⟩,
  ⟨1590, false, 1591, false, 31, 1, 38⟩,
  ⟨1592, false, 1593, false, 29, 1, 36⟩,
  ⟨1592, true, 1598, false, 27, 3, 34⟩,
  ⟨1593, false, 1594, false, 31, 1, 38⟩,
  ⟨1594, false, 1595, false, 32, 1, 39⟩,
  ⟨1594, true, 1597, false, 30, 3, 37⟩,
  ⟨1595, false, 1596, false, 33, 1, 40⟩]
theorem carryCases16_07_verified : carryCases16_07.all verified = true := by decide

def carryCases16_08 : List Case := [
  ⟨1598, false, 1599, false, 28, 1, 35⟩,
  ⟨1598, true, 1602, false, 25, 4, 32⟩,
  ⟨1599, false, 1600, false, 29, 1, 36⟩,
  ⟨1600, false, 1601, false, 30, 1, 37⟩,
  ⟨1602, false, 1603, false, 23, 3, 30⟩,
  ⟨1603, false, 1604, false, 28, 1, 35⟩,
  ⟨1603, true, 1606, false, 27, 2, 34⟩,
  ⟨1604, false, 1605, false, 29, 1, 36⟩]
theorem carryCases16_08_verified : carryCases16_08.all verified = true := by decide

def carryCases16_09 : List Case := [
  ⟨1606, false, 1607, false, 29, 1, 36⟩,
  ⟨1606, true, 1609, false, 28, 2, 35⟩,
  ⟨1607, false, 1608, false, 30, 1, 37⟩,
  ⟨1609, false, 1610, false, 31, 1, 38⟩,
  ⟨1609, true, 1613, false, 30, 2, 37⟩,
  ⟨1610, false, 1611, false, 32, 1, 39⟩,
  ⟨1611, false, 1612, false, 33, 1, 40⟩,
  ⟨1613, false, 1614, false, 31, 1, 38⟩]
theorem carryCases16_09_verified : carryCases16_09.all verified = true := by decide

def carryCases16_10 : List Case := [
  ⟨1613, true, 1619, false, 29, 3, 36⟩,
  ⟨1614, false, 1615, false, 33, 1, 40⟩,
  ⟨1615, false, 1616, false, 34, 1, 41⟩,
  ⟨1615, true, 1618, false, 32, 3, 39⟩,
  ⟨1616, false, 1617, false, 35, 1, 42⟩,
  ⟨1619, false, 1620, false, 30, 1, 37⟩,
  ⟨1619, true, 1622, false, 26, 5, 33⟩,
  ⟨1620, false, 1621, false, 31, 1, 38⟩]
theorem carryCases16_10_verified : carryCases16_10.all verified = true := by decide

def carryCases16_11 : List Case := [
  ⟨1622, false, 1623, false, 27, 1, 34⟩,
  ⟨1622, true, 1626, false, 25, 3, 32⟩,
  ⟨1623, false, 1624, false, 28, 1, 35⟩,
  ⟨1624, false, 1625, false, 29, 1, 36⟩,
  ⟨1626, false, 1627, false, 26, 1, 33⟩,
  ⟨1626, true, 1629, false, 24, 3, 31⟩,
  ⟨1627, false, 1628, false, 27, 1, 34⟩,
  ⟨1629, false, 1630, false, 28, 1, 35⟩]
theorem carryCases16_11_verified : carryCases16_11.all verified = true := by decide

def carryCases16 : List Case := carryCases16_00 ++ carryCases16_01 ++ carryCases16_02 ++ carryCases16_03 ++ carryCases16_04 ++ carryCases16_05 ++ carryCases16_06 ++ carryCases16_07 ++ carryCases16_08 ++ carryCases16_09 ++ carryCases16_10 ++ carryCases16_11
theorem carryCases16_verified : carryCases16.all verified = true := by
  simp only [carryCases16, List.all_append, carryCases16_00_verified, carryCases16_01_verified, carryCases16_02_verified, carryCases16_03_verified, carryCases16_04_verified, carryCases16_05_verified, carryCases16_06_verified, carryCases16_07_verified, carryCases16_08_verified, carryCases16_09_verified, carryCases16_10_verified, carryCases16_11_verified, Bool.and_self]
theorem carryCases16_covered : carryCases16.map (fun c => key c.pc c.zero) = keysBetween 3067 192 := by decide
theorem carryCases16_count : carryCases16.length = 96 := by decide
end NF192.Carry
