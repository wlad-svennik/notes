module
public import MachineFrameCarryGeometry
public import MachineControlCarryComplete

@[expose] public section
namespace NF192.Frame
open NF210 NF210.TM KernelRightShift

/-- Convert the actual bounded carry and unbounded cleanup into the exact infinite-tape
successor frame, including every stored register, every spare, and blank exterior. -/
theorem Layout.carry_restore (f : Layout) (zero : Bool) (extra bump : Nat)
    (regs : Array Nat) (spares : List Nat)
    (inside : f.pc < 3089) (selected : Carry.selected f.pc zero = true)
    (space : 40 ≤ (Carry.initialWord f.pc zero).length+extra)
    (height : (Carry.initialWord f.pc zero).length+extra = 9 + f.gap + bump)
    (pad : Nat := 1) :
    ∃ t, TM.run Selected.machine t
      (f.carryConfig zero extra (f.afterCarry zero bump regs spares).values pad) =
      (f.afterCarry zero bump regs spares).config := by
  obtain ⟨t,h⟩ := Carry.all_arithmetic_returns f.pc inside zero selected extra space
  exact ⟨t,f.carry_restore_of_run zero extra bump regs spares height h pad⟩

end NF192.Frame
