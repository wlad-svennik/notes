module
public import Init
@[expose] public section

/-! Pure term definability for the archived fixed-point tester. This theorem
applies to models whose false result is an absorbing element. No full
set-theoretic or arithmetic dependency is used. -/
namespace NF192.ArchiveTerms

universe u
structure Model (A : Type u) where
  app : A → A → A
  K : A → A
  B : A
  R : A
  Q : A
  k : ∀ x y, app (K x) y = x
  b : ∀ x y z, app (app (app B x) y) z = app (app x (K z)) (app y z)
  ext : ∀ {f g}, (∀ x, app f x = app g x) → f = g
  success : ∀ f x, app f x = x → app (app Q f) x = B
  failure : ∀ f x, app f x ≠ x → app (app Q f) x = R
  distinct : B ≠ R

inductive Term where
  | B | R | Q
  | konst : Term → Term
  | app : Term → Term → Term

namespace Model
variable {A : Type u} (M : Model A)
local infixl:70 " ⬝ " => M.app
set_option autoImplicit false
set_option maxHeartbeats 3000000

def eval (q : A) : Term → A
  | .B => M.B
  | .R => M.R
  | .Q => q
  | .konst x => M.K (eval q x)
  | .app f x => eval q f ⬝ eval q x

/-- At level zero only the absorbing false value may approximate any
output. Each next level compares functions on previously related inputs. -/
def approx : Nat → A → A → Prop
  | 0, x, y => x = M.R ∨ x = y
  | n+1, f, g => ∀ x y, approx n x y → approx n (f ⬝ x) (g ⬝ y)

private theorem approx_R (absorbs : ∀ x, M.R ⬝ x = M.R) (n : Nat) (y : A) :
    M.approx n M.R y := by
  induction n generalizing y with
  | zero => exact Or.inl rfl
  | succ n ih =>
    intro x z _
    rw [absorbs]
    exact ih _

private theorem approx_K {n : Nat} {x y : A} (h : M.approx n x y) :
    M.approx (n+1) (M.K x) (M.K y) := by
  intro a b _
  simpa only [M.k] using h

private theorem approx_B (n : Nat) : M.approx (n+3) M.B M.B := by
  intro f g hf p q hp x y hx
  rw [M.b,M.b]
  exact hf _ _ (M.approx_K hx) _ _ (hp _ _ hx)

def height : Term → Nat
  | .B => 3
  | .R => 0
  | .Q => 5
  | .konst t => height t + 1
  | .app f x => max (height f) (height x)

private theorem approximation (absorbs : ∀ x, M.R ⬝ x = M.R) (t : Term) (n : Nat)
    (bound : height t ≤ n) : M.approx n (M.eval M.Q t) (M.eval (M.K (M.K M.B)) t) := by
  induction t generalizing n with
  | B =>
    change 3 ≤ n at bound
    obtain ⟨k,rfl⟩ : ∃ k, n = k+3 := ⟨n-3,by omega⟩
    exact M.approx_B k
  | R => exact M.approx_R absorbs _ _
  | Q =>
    change 5 ≤ n at bound
    obtain ⟨k,rfl⟩ : ∃ k, n = k+5 := ⟨n-5,by omega⟩
    intro f g _ x y _
    change M.approx (k+3) (M.Q ⬝ f ⬝ x) (M.K (M.K M.B) ⬝ g ⬝ y)
    rw [M.k,M.k]
    by_cases fixed : f ⬝ x = x
    · rw [M.success _ _ fixed]; exact M.approx_B k
    · rw [M.failure _ _ fixed]; exact M.approx_R absorbs _ _
  | konst x ih =>
    change height x+1 ≤ n at bound
    cases n with
    | zero => omega
    | succ n => exact M.approx_K (ih n (by omega))
  | app f x hf hx =>
    change max (height f) (height x) ≤ n at bound
    exact hf (n+1) (by omega) _ _ (hx n (by omega))

def ident : A := M.B ⬝ (M.B ⬝ M.B ⬝ M.B) ⬝ M.B
private theorem id_app (x : A) : M.ident ⬝ x = x := by simp only [ident,M.b,M.k]

private theorem id_approx (n : Nat) : M.approx n M.ident M.ident := by
  cases n with
  | zero => exact Or.inr rfl
  | succ n => intro x y h; simpa only [M.id_app] using h

private theorem kB_ne_R (absorbs : ∀ x, M.R ⬝ x = M.R) : M.K M.B ≠ M.R := by
  intro eq
  have h := congrArg (fun z => z ⬝ M.B) eq
  exact M.distinct (by simpa only [M.k,absorbs] using h)

private theorem kB_ne_B : M.K M.B ≠ M.B := by
  intro eq
  have constant (x : A) : M.B ⬝ x = M.B :=
    (congrArg (fun f => f ⬝ x) eq.symm).trans (M.k M.B x)
  have h := M.b (M.K (M.K M.R)) M.B M.B
  rw [constant,constant,constant,M.k,M.k] at h
  exact M.distinct h

/-- Repeated constant-function lifting, used to carry a level-zero
distinction to any prescribed function level. -/
def lift : Nat → A → A
  | 0, x => x
  | n+1, x => M.K (lift n x)

private theorem lift_approx (n : Nat) (x : A) : M.approx n (M.lift n x) (M.lift n x) := by
  induction n with
  | zero => exact Or.inr rfl
  | succ n ih => exact M.approx_K ih

private theorem common_lifts (n : Nat) {x y : A} (xR : x ≠ M.R) (yR : y ≠ M.R) (u : A)
    (hx : M.approx n (M.lift n x) u) (hy : M.approx n (M.lift n y) u) : x = y := by
  induction n generalizing u with
  | zero =>
    exact (hx.resolve_left xR).trans (hy.resolve_left yR).symm
  | succ n ih =>
    have xx := hx _ _ (M.id_approx n)
    have yy := hy _ _ (M.id_approx n)
    simp only [lift,M.k] at xx yy
    exact ih _ xx yy

private theorem incompatible (absorbs : ∀ x, M.R ⬝ x = M.R) (n : Nat) (u : A)
    (hk : M.approx (n+4) (M.K M.B) u) (hb : M.approx (n+4) M.B u) : False := by
  let x := M.lift n (M.K M.B)
  let y := M.lift n M.B
  have xx : M.approx n x x := M.lift_approx _ _
  have yy : M.approx n y y := M.lift_approx _ _
  have kkk := M.approx_K (M.approx_K (M.approx_K yy))
  have kk := M.approx_K (M.approx_K xx)
  have lhs := hk _ _ kkk _ _ kk _ _ (M.id_approx (n+1)) _ _ (M.id_approx n)
  have rhs := hb _ _ kkk _ _ kk _ _ (M.id_approx (n+1)) _ _ (M.id_approx n)
  simp only [M.k,M.b] at lhs rhs
  exact M.kB_ne_B (M.common_lifts n (M.kB_ne_R absorbs) M.distinct _ lhs rhs)

/-- In every archived algebra with absorbing false, no closed term in
B, R, Q, K and application returns K(B) on fixed points and B off them.
This concerns terms in the given constants, with its given application. -/
theorem no_uniform_normalized_term (absorbs : ∀ x, M.R ⬝ x = M.R) (t : Term) :
    ¬ ((∀ f x, f ⬝ x = x → M.eval M.Q t ⬝ f ⬝ x = M.K M.B) ∧
        (∀ f x, f ⬝ x ≠ x → M.eval M.Q t ⬝ f ⬝ x = M.B)) := by
  rintro ⟨yes,no⟩
  let n := height t
  have h := M.approximation absorbs t (n+6) (by dsimp [n]; omega)
  have input := M.approx_B (n+1)
  have left := h _ _ (M.id_approx (n+5)) _ _ input
  have right := h _ _ (M.approx_R absorbs (n+5) M.ident) _ _ input
  rw [yes _ _ (M.id_app _)] at left
  rw [no _ _ (by rw [absorbs]; exact Ne.symm M.distinct)] at right
  exact M.incompatible absorbs n _ left right

#print axioms no_uniform_normalized_term
end Model
end NF192.ArchiveTerms
