module
public import MachineArithmeticReturns

@[expose] public section
namespace NF192.ArithmeticReturn
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem block1536 : checkRange 1536 32 = true := by decide +kernel
theorem block1568 : checkRange 1568 32 = true := by decide +kernel
theorem block1600 : checkRange 1600 32 = true := by decide +kernel
theorem block1632 : checkRange 1632 32 = true := by decide +kernel
theorem block1664 : checkRange 1664 32 = true := by decide +kernel
theorem block1696 : checkRange 1696 32 = true := by decide +kernel
theorem block1728 : checkRange 1728 32 = true := by decide +kernel
theorem block1760 : checkRange 1760 32 = true := by decide +kernel
theorem block1792 : checkRange 1792 32 = true := by decide +kernel
theorem block1824 : checkRange 1824 32 = true := by decide +kernel
theorem block1856 : checkRange 1856 32 = true := by decide +kernel
theorem block1888 : checkRange 1888 32 = true := by decide +kernel
theorem block1920 : checkRange 1920 32 = true := by decide +kernel
theorem block1952 : checkRange 1952 32 = true := by decide +kernel
theorem block1984 : checkRange 1984 32 = true := by decide +kernel
theorem block2016 : checkRange 2016 32 = true := by decide +kernel

end NF192.ArithmeticReturn
