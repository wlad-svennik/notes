module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases23_00 : List Case := [
  ⟨2206, false, 2207, false, 30, 1, 37⟩,
  ⟨2206, true, 2210, false, 29, 2, 36⟩,
  ⟨2207, false, 2208, false, 31, 1, 38⟩,
  ⟨2208, false, 2209, false, 32, 1, 39⟩,
  ⟨2210, false, 2211, false, 30, 1, 37⟩,
  ⟨2210, true, 2216, false, 28, 3, 35⟩,
  ⟨2211, false, 2212, false, 32, 1, 39⟩,
  ⟨2212, false, 2213, false, 33, 1, 40⟩]
theorem carryCases23_00_verified : carryCases23_00.all verified = true := by decide

def carryCases23_01 : List Case := [
  ⟨2212, true, 2215, false, 31, 3, 38⟩,
  ⟨2213, false, 2214, false, 34, 1, 41⟩,
  ⟨2216, false, 2217, false, 29, 1, 36⟩,
  ⟨2216, true, 2219, false, 25, 5, 32⟩,
  ⟨2217, false, 2218, false, 30, 1, 37⟩,
  ⟨2219, false, 2220, false, 27, 1, 34⟩,
  ⟨2219, true, 2223, false, 26, 2, 33⟩,
  ⟨2220, false, 2221, false, 28, 1, 35⟩]
theorem carryCases23_01_verified : carryCases23_01.all verified = true := by decide

def carryCases23_02 : List Case := [
  ⟨2221, false, 2222, false, 29, 1, 36⟩,
  ⟨2223, false, 2224, false, 27, 1, 34⟩,
  ⟨2223, true, 2226, false, 24, 4, 31⟩,
  ⟨2224, false, 2225, false, 28, 1, 35⟩,
  ⟨2226, false, 2227, false, 29, 1, 36⟩,
  ⟨2226, true, 2229, false, 28, 2, 35⟩,
  ⟨2227, false, 2228, false, 30, 1, 37⟩,
  ⟨2229, false, 2230, false, 30, 1, 37⟩]
theorem carryCases23_02_verified : carryCases23_02.all verified = true := by decide

def carryCases23_03 : List Case := [
  ⟨2229, true, 2232, false, 29, 2, 36⟩,
  ⟨2230, false, 2231, false, 31, 1, 38⟩,
  ⟨2232, false, 2233, false, 32, 1, 39⟩,
  ⟨2232, true, 2236, false, 31, 2, 38⟩,
  ⟨2233, false, 2234, false, 33, 1, 40⟩,
  ⟨2234, false, 2235, false, 34, 1, 41⟩,
  ⟨2236, false, 2237, false, 32, 1, 39⟩,
  ⟨2236, true, 2242, false, 30, 3, 37⟩]
theorem carryCases23_03_verified : carryCases23_03.all verified = true := by decide

def carryCases23_04 : List Case := [
  ⟨2237, false, 2238, false, 34, 1, 41⟩,
  ⟨2238, false, 2239, false, 35, 1, 42⟩,
  ⟨2238, true, 2241, false, 33, 3, 40⟩,
  ⟨2239, false, 2240, false, 36, 1, 43⟩,
  ⟨2242, false, 2243, false, 31, 1, 38⟩,
  ⟨2242, true, 2245, false, 27, 5, 34⟩,
  ⟨2243, false, 2244, false, 32, 1, 39⟩,
  ⟨2245, false, 2246, false, 28, 1, 35⟩]
theorem carryCases23_04_verified : carryCases23_04.all verified = true := by decide

def carryCases23_05 : List Case := [
  ⟨2245, true, 2249, false, 26, 3, 33⟩,
  ⟨2246, false, 2247, false, 29, 1, 36⟩,
  ⟨2247, false, 2248, false, 30, 1, 37⟩,
  ⟨2249, false, 2250, false, 27, 1, 34⟩,
  ⟨2249, true, 2252, false, 25, 3, 32⟩,
  ⟨2250, false, 2251, false, 28, 1, 35⟩,
  ⟨2252, false, 2253, false, 29, 1, 36⟩,
  ⟨2252, true, 2260, false, 28, 2, 35⟩]
theorem carryCases23_05_verified : carryCases23_05.all verified = true := by decide

def carryCases23_06 : List Case := [
  ⟨2253, false, 2254, false, 31, 1, 38⟩,
  ⟨2254, false, 2255, false, 33, 1, 40⟩,
  ⟨2254, true, 2256, false, 32, 2, 39⟩,
  ⟨2256, false, 2257, false, 33, 1, 40⟩,
  ⟨2256, true, 2259, false, 30, 4, 37⟩,
  ⟨2257, false, 2258, false, 34, 1, 41⟩,
  ⟨2260, false, 2261, false, 29, 1, 36⟩,
  ⟨2260, true, 2263, false, 27, 3, 34⟩]
theorem carryCases23_06_verified : carryCases23_06.all verified = true := by decide

def carryCases23_07 : List Case := [
  ⟨2261, false, 2262, false, 30, 1, 37⟩,
  ⟨2263, false, 2264, false, 30, 1, 37⟩,
  ⟨2263, true, 2267, false, 29, 2, 36⟩,
  ⟨2264, false, 2265, false, 31, 1, 38⟩,
  ⟨2265, false, 2266, false, 32, 1, 39⟩,
  ⟨2267, false, 2268, false, 30, 1, 37⟩,
  ⟨2267, true, 2273, false, 28, 3, 35⟩,
  ⟨2268, false, 2269, false, 32, 1, 39⟩]
theorem carryCases23_07_verified : carryCases23_07.all verified = true := by decide

def carryCases23_08 : List Case := [
  ⟨2269, false, 2270, false, 33, 1, 40⟩,
  ⟨2269, true, 2272, false, 31, 3, 38⟩,
  ⟨2270, false, 2271, false, 34, 1, 41⟩,
  ⟨2273, false, 2274, false, 29, 1, 36⟩,
  ⟨2273, true, 2277, false, 26, 4, 33⟩,
  ⟨2274, false, 2275, false, 30, 1, 37⟩,
  ⟨2275, false, 2276, false, 31, 1, 38⟩,
  ⟨2277, false, 2278, false, 23, 4, 30⟩]
theorem carryCases23_08_verified : carryCases23_08.all verified = true := by decide

def carryCases23_09 : List Case := [
  ⟨2278, false, 2279, false, 28, 1, 35⟩,
  ⟨2278, true, 2281, false, 27, 2, 34⟩,
  ⟨2279, false, 2280, false, 29, 1, 36⟩,
  ⟨2281, false, 2282, false, 29, 1, 36⟩,
  ⟨2281, true, 2284, false, 28, 2, 35⟩,
  ⟨2282, false, 2283, false, 30, 1, 37⟩,
  ⟨2284, false, 2285, false, 31, 1, 38⟩,
  ⟨2284, true, 2288, false, 30, 2, 37⟩]
theorem carryCases23_09_verified : carryCases23_09.all verified = true := by decide

def carryCases23_10 : List Case := [
  ⟨2285, false, 2286, false, 32, 1, 39⟩,
  ⟨2286, false, 2287, false, 33, 1, 40⟩,
  ⟨2288, false, 2289, false, 31, 1, 38⟩,
  ⟨2288, true, 2294, false, 29, 3, 36⟩,
  ⟨2289, false, 2290, false, 33, 1, 40⟩,
  ⟨2290, false, 2291, false, 34, 1, 41⟩,
  ⟨2290, true, 2293, false, 32, 3, 39⟩,
  ⟨2291, false, 2292, false, 35, 1, 42⟩]
theorem carryCases23_10_verified : carryCases23_10.all verified = true := by decide

def carryCases23_11 : List Case := [
  ⟨2294, false, 2295, false, 30, 1, 37⟩,
  ⟨2294, true, 2297, false, 26, 5, 33⟩,
  ⟨2295, false, 2296, false, 31, 1, 38⟩,
  ⟨2297, false, 2298, false, 27, 1, 34⟩,
  ⟨2297, true, 2301, false, 25, 3, 32⟩,
  ⟨2298, false, 2299, false, 28, 1, 35⟩,
  ⟨2299, false, 2300, false, 29, 1, 36⟩,
  ⟨2301, false, 2302, false, 26, 1, 33⟩]
theorem carryCases23_11_verified : carryCases23_11.all verified = true := by decide

def carryCases23 : List Case := carryCases23_00 ++ carryCases23_01 ++ carryCases23_02 ++ carryCases23_03 ++ carryCases23_04 ++ carryCases23_05 ++ carryCases23_06 ++ carryCases23_07 ++ carryCases23_08 ++ carryCases23_09 ++ carryCases23_10 ++ carryCases23_11
theorem carryCases23_verified : carryCases23.all verified = true := by
  simp only [carryCases23, List.all_append, carryCases23_00_verified, carryCases23_01_verified, carryCases23_02_verified, carryCases23_03_verified, carryCases23_04_verified, carryCases23_05_verified, carryCases23_06_verified, carryCases23_07_verified, carryCases23_08_verified, carryCases23_09_verified, carryCases23_10_verified, carryCases23_11_verified, Bool.and_self]
theorem carryCases23_covered : carryCases23.map (fun c => key c.pc c.zero) = keysBetween 4412 191 := by decide
theorem carryCases23_count : carryCases23.length = 96 := by decide
end NF192.Carry
