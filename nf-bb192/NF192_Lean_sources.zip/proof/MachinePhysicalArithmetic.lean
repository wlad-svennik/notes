module
public import MachinePhysicalValues
public import MachineOpcode
public import MachineSourceTargets
public import MachineFrameIncrement
public import MachineFrameDecrement
public import MachineCanonicalHalt

@[expose] public section
namespace NF192.Physical
open NF210 NF210.TM Frame

/-- All four physical arithmetic cases for the exact frozen table and source. -/
theorem arithmetic : Arithmetic where
  inc f r n good instruction := by
    obtain ⟨reg,_,opcode,dest⟩ := Opcode.inc good.inRange instruction
    have bound := (Frame.inc_target_valid good.inRange instruction).2
    have margin := good.margin
    obtain ⟨t, positive, run⟩ :=
      f.increment_step r good.inRange good.room (by omega) good.nine reg opcode
    rw [dest] at bound ⊢
    exact ⟨f.afterIncrement r,t,positive,run,update_effect f r _ [0] false 0 good bound⟩
  positive f r z n flag good instruction positive := by
    obtain ⟨reg,_,opcode,dest,_,_⟩ := Opcode.dec good.inRange instruction
    have bound := (Frame.dec_targets_valid good.inRange instruction).2.2
    have margin := good.margin
    let k := f.storedAt r.val-2
    have raw : f.storedAt r.val = k+2 := by dsimp [k]; omega
    have reduced : f.storedAt r.val-1 = k+1 := by omega
    obtain ⟨t,progress,run⟩ := f.decrement_positive_step r k good.inRange opcode good.room
      (by omega) reg good.nine raw
    rw [dest] at bound ⊢
    rw [reduced]
    have effect := update_effect f r (k+1) [] false 1 good bound
    simp only [List.append_nil] at effect
    exact ⟨_,t,progress,run,effect⟩
  zero f r z n good instruction raw := by
    obtain ⟨reg,_,opcode,_,dest,flag⟩ := Opcode.dec good.inRange instruction
    have bound := (Frame.dec_targets_valid good.inRange instruction).2.1
    have margin := good.margin
    have even : (Source.siteAt f.pc).address % 2 = 0 := by
      have ne : (Source.siteAt f.pc).address % 2 ≠ 1 := by
        intro odd
        simp [odd] at flag
      omega
    obtain ⟨t,progress,run⟩ := f.decrement_zero_step r good.inRange opcode good.room
      (by omega) reg raw even
    rw [dest] at bound ⊢
    exact ⟨_,t,progress,run,zero_effect f good bound⟩
  halt f r z n good instruction raw := by
    obtain ⟨reg,_,opcode,_,_,flag⟩ := Opcode.dec good.inRange instruction
    exact f.decrement_halt_step r good.inRange opcode reg (by simpa using flag.symm) raw good.room

#print axioms arithmetic
end NF192.Physical
