module
public import MachineCanonicalControlMasks

@[expose] public section
namespace NF192.CanonicalControl
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem mask2560 : checkRange 2560 32 = true := by decide +kernel
theorem mask2592 : checkRange 2592 32 = true := by decide +kernel
theorem mask2624 : checkRange 2624 32 = true := by decide +kernel
theorem mask2656 : checkRange 2656 32 = true := by decide +kernel
theorem mask2688 : checkRange 2688 32 = true := by decide +kernel
theorem mask2720 : checkRange 2720 32 = true := by decide +kernel
theorem mask2752 : checkRange 2752 32 = true := by decide +kernel
theorem mask2784 : checkRange 2784 32 = true := by decide +kernel
theorem mask2816 : checkRange 2816 32 = true := by decide +kernel
theorem mask2848 : checkRange 2848 32 = true := by decide +kernel
theorem mask2880 : checkRange 2880 32 = true := by decide +kernel
theorem mask2912 : checkRange 2912 32 = true := by decide +kernel
theorem mask2944 : checkRange 2944 32 = true := by decide +kernel
theorem mask2976 : checkRange 2976 32 = true := by decide +kernel
theorem mask3008 : checkRange 3008 32 = true := by decide +kernel
theorem mask3040 : checkRange 3040 32 = true := by decide +kernel
end NF192.CanonicalControl
