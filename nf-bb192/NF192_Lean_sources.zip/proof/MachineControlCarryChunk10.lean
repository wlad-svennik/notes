module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases10_00 : List Case := [
  ⟨958, false, 959, false, 29, 1, 36⟩,
  ⟨958, true, 966, false, 28, 2, 35⟩,
  ⟨959, false, 960, false, 31, 1, 38⟩,
  ⟨960, false, 961, false, 33, 1, 40⟩,
  ⟨960, true, 962, false, 32, 2, 39⟩,
  ⟨962, false, 963, false, 33, 1, 40⟩,
  ⟨962, true, 965, false, 30, 4, 37⟩,
  ⟨963, false, 964, false, 34, 1, 41⟩]
theorem carryCases10_00_verified : carryCases10_00.all verified = true := by decide

def carryCases10_01 : List Case := [
  ⟨966, false, 967, false, 29, 1, 36⟩,
  ⟨966, true, 969, false, 27, 3, 34⟩,
  ⟨967, false, 968, false, 30, 1, 37⟩,
  ⟨969, false, 970, false, 30, 1, 37⟩,
  ⟨969, true, 973, false, 29, 2, 36⟩,
  ⟨970, false, 971, false, 31, 1, 38⟩,
  ⟨971, false, 972, false, 32, 1, 39⟩,
  ⟨973, false, 974, false, 30, 1, 37⟩]
theorem carryCases10_01_verified : carryCases10_01.all verified = true := by decide

def carryCases10_02 : List Case := [
  ⟨973, true, 979, false, 28, 3, 35⟩,
  ⟨974, false, 975, false, 32, 1, 39⟩,
  ⟨975, false, 976, false, 33, 1, 40⟩,
  ⟨975, true, 978, false, 31, 3, 38⟩,
  ⟨976, false, 977, false, 34, 1, 41⟩,
  ⟨979, false, 980, false, 29, 1, 36⟩,
  ⟨979, true, 983, false, 26, 4, 33⟩,
  ⟨980, false, 981, false, 30, 1, 37⟩]
theorem carryCases10_02_verified : carryCases10_02.all verified = true := by decide

def carryCases10_03 : List Case := [
  ⟨981, false, 982, false, 31, 1, 38⟩,
  ⟨983, false, 984, false, 25, 2, 32⟩,
  ⟨984, false, 985, false, 28, 1, 35⟩,
  ⟨984, true, 992, false, 27, 2, 34⟩,
  ⟨985, false, 986, false, 30, 1, 37⟩,
  ⟨986, false, 987, false, 32, 1, 39⟩,
  ⟨986, true, 988, false, 31, 2, 38⟩,
  ⟨988, false, 989, false, 32, 1, 39⟩]
theorem carryCases10_03_verified : carryCases10_03.all verified = true := by decide

def carryCases10_04 : List Case := [
  ⟨988, true, 991, false, 29, 4, 36⟩,
  ⟨989, false, 990, false, 33, 1, 40⟩,
  ⟨992, false, 993, false, 28, 1, 35⟩,
  ⟨992, true, 995, false, 26, 3, 33⟩,
  ⟨993, false, 994, false, 29, 1, 36⟩,
  ⟨995, false, 996, false, 29, 1, 36⟩,
  ⟨995, true, 999, false, 28, 2, 35⟩,
  ⟨996, false, 997, false, 30, 1, 37⟩]
theorem carryCases10_04_verified : carryCases10_04.all verified = true := by decide

def carryCases10_05 : List Case := [
  ⟨997, false, 998, false, 31, 1, 38⟩,
  ⟨999, false, 1000, false, 29, 1, 36⟩,
  ⟨999, true, 1005, false, 27, 3, 34⟩,
  ⟨1000, false, 1001, false, 31, 1, 38⟩,
  ⟨1001, false, 1002, false, 32, 1, 39⟩,
  ⟨1001, true, 1004, false, 30, 3, 37⟩,
  ⟨1002, false, 1003, false, 33, 1, 40⟩,
  ⟨1005, false, 1006, false, 28, 1, 35⟩]
theorem carryCases10_05_verified : carryCases10_05.all verified = true := by decide

def carryCases10_06 : List Case := [
  ⟨1005, true, 1009, false, 21, 8, 28⟩,
  ⟨1006, false, 1007, false, 29, 1, 36⟩,
  ⟨1007, false, 1008, false, 30, 1, 37⟩,
  ⟨1009, false, 1010, false, 26, 1, 33⟩,
  ⟨1009, true, 1012, false, 25, 2, 32⟩,
  ⟨1010, false, 1011, false, 27, 1, 34⟩,
  ⟨1012, false, 1013, false, 27, 1, 34⟩,
  ⟨1012, true, 1015, false, 26, 2, 33⟩]
theorem carryCases10_06_verified : carryCases10_06.all verified = true := by decide

def carryCases10_07 : List Case := [
  ⟨1013, false, 1014, false, 28, 1, 35⟩,
  ⟨1015, false, 1016, false, 29, 1, 36⟩,
  ⟨1015, true, 1019, false, 28, 2, 35⟩,
  ⟨1016, false, 1017, false, 30, 1, 37⟩,
  ⟨1017, false, 1018, false, 31, 1, 38⟩,
  ⟨1019, false, 1020, false, 29, 1, 36⟩,
  ⟨1019, true, 1025, false, 27, 3, 34⟩,
  ⟨1020, false, 1021, false, 31, 1, 38⟩]
theorem carryCases10_07_verified : carryCases10_07.all verified = true := by decide

def carryCases10_08 : List Case := [
  ⟨1021, false, 1022, false, 32, 1, 39⟩,
  ⟨1021, true, 1024, false, 30, 3, 37⟩,
  ⟨1022, false, 1023, false, 33, 1, 40⟩,
  ⟨1025, false, 1026, false, 28, 1, 35⟩,
  ⟨1025, true, 1028, false, 24, 5, 31⟩,
  ⟨1026, false, 1027, false, 29, 1, 36⟩,
  ⟨1028, false, 1029, false, 25, 1, 32⟩,
  ⟨1028, true, 1032, false, 23, 3, 30⟩]
theorem carryCases10_08_verified : carryCases10_08.all verified = true := by decide

def carryCases10_09 : List Case := [
  ⟨1029, false, 1030, false, 26, 1, 33⟩,
  ⟨1030, false, 1031, false, 27, 1, 34⟩,
  ⟨1032, false, 1033, false, 24, 1, 31⟩,
  ⟨1032, true, 1035, false, 22, 3, 29⟩,
  ⟨1033, false, 1034, false, 25, 1, 32⟩,
  ⟨1035, false, 1036, false, 27, 1, 34⟩,
  ⟨1035, true, 1038, false, 26, 2, 33⟩,
  ⟨1036, false, 1037, false, 28, 1, 35⟩]
theorem carryCases10_09_verified : carryCases10_09.all verified = true := by decide

def carryCases10_10 : List Case := [
  ⟨1038, false, 1039, false, 28, 1, 35⟩,
  ⟨1038, true, 1041, false, 27, 2, 34⟩,
  ⟨1039, false, 1040, false, 29, 1, 36⟩,
  ⟨1041, false, 1042, false, 30, 1, 37⟩,
  ⟨1041, true, 1045, false, 29, 2, 36⟩,
  ⟨1042, false, 1043, false, 31, 1, 38⟩,
  ⟨1043, false, 1044, false, 32, 1, 39⟩,
  ⟨1045, false, 1046, false, 30, 1, 37⟩]
theorem carryCases10_10_verified : carryCases10_10.all verified = true := by decide

def carryCases10_11 : List Case := [
  ⟨1045, true, 1051, false, 28, 3, 35⟩,
  ⟨1046, false, 1047, false, 32, 1, 39⟩,
  ⟨1047, false, 1048, false, 33, 1, 40⟩,
  ⟨1047, true, 1050, false, 31, 3, 38⟩,
  ⟨1048, false, 1049, false, 34, 1, 41⟩,
  ⟨1051, false, 1052, false, 29, 1, 36⟩,
  ⟨1051, true, 1054, false, 25, 5, 32⟩,
  ⟨1052, false, 1053, false, 30, 1, 37⟩]
theorem carryCases10_11_verified : carryCases10_11.all verified = true := by decide

def carryCases10 : List Case := carryCases10_00 ++ carryCases10_01 ++ carryCases10_02 ++ carryCases10_03 ++ carryCases10_04 ++ carryCases10_05 ++ carryCases10_06 ++ carryCases10_07 ++ carryCases10_08 ++ carryCases10_09 ++ carryCases10_10 ++ carryCases10_11
theorem carryCases10_verified : carryCases10.all verified = true := by
  simp only [carryCases10, List.all_append, carryCases10_00_verified, carryCases10_01_verified, carryCases10_02_verified, carryCases10_03_verified, carryCases10_04_verified, carryCases10_05_verified, carryCases10_06_verified, carryCases10_07_verified, carryCases10_08_verified, carryCases10_09_verified, carryCases10_10_verified, carryCases10_11_verified, Bool.and_self]
theorem carryCases10_covered : carryCases10.map (fun c => key c.pc c.zero) = keysBetween 1916 192 := by decide
theorem carryCases10_count : carryCases10.length = 96 := by decide
end NF192.Carry
