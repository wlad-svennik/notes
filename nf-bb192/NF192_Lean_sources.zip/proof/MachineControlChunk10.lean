module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases10_00 : List Case := [
  ⟨2070, false, 8436665088, 920472320, 66, 0, 0⟩,
  ⟨2074, false, 836586240, 31279872, 58, 0, 0⟩,
  ⟨2077, false, 1776110336, 165497600, 62, 0, 0⟩,
  ⟨2081, false, 15466318592, 433933056, 68, 0, 0⟩,
  ⟨2086, false, 63784700672, 12245093120, 72, 0, 0⟩,
  ⟨2087, false, 7950125824, 433933056, 64, 0, 0⟩,
  ⟨2090, false, 4192029440, 970803968, 66, 0, 0⟩,
  ⟨2094, false, 1977436928, 98388736, 60, 0, 0⟩
]

theorem cases10_00_verified : cases10_00.all verified = true := by decide

def cases10_01 : List Case := [
  ⟨2097, false, 1037912832, 232606464, 58, 0, 0⟩,
  ⟨2100, false, 3286059776, 64834304, 60, 0, 0⟩,
  ⟨2103, false, 7044156160, 601705216, 64, 0, 0⟩,
  ⟨2107, false, 61804989184, 1675447040, 70, 0, 0⟩,
  ⟨2112, false, 255078517504, 48920087296, 74, 0, 0⟩,
  ⟨2113, false, 31740218112, 1675447040, 66, 0, 0⟩,
  ⟨2116, false, 16707832576, 3822930688, 68, 0, 0⟩,
  ⟨2120, false, 4091366144, 333269760, 60, 0, 0⟩
]

theorem cases10_01_verified : cases10_01.all verified = true := by decide

def cases10_02 : List Case := [
  ⟨2123, false, 1004358400, 199052032, 56, 0, 0⟩,
  ⟨2127, true, 22680521472, 3353168640, 33, 31, 38⟩,
  ⟨2130, false, 65630194432, 14090586880, 72, 0, 0⟩,
  ⟨2131, false, 3353168640, 131943168, 64, 0, 0⟩,
  ⟨2134, false, 3890039552, 668814080, 64, 0, 0⟩,
  ⟨2138, false, 15432764160, 400378624, 66, 0, 0⟩,
  ⟨2143, false, 63751146240, 12211538688, 70, 0, 0⟩,
  ⟨2144, false, 7916571392, 400378624, 62, 0, 0⟩
]

theorem cases10_02_verified : cases10_02.all verified = true := by decide

def cases10_03 : List Case := [
  ⟨2148, false, 8453442304, 937249536, 64, 0, 0⟩,
  ⟨2153, true, 1413303040, 205343488, 31, 27, 34⟩,
  ⟨2156, false, 4097657600, 876432128, 66, 0, 0⟩,
  ⟨2157, false, 205343488, 4016896, 58, 0, 0⟩,
  ⟨2160, false, 238897920, 37571328, 58, 0, 0⟩,
  ⟨2164, false, 960318208, 20794112, 60, 0, 0⟩,
  ⟨2169, false, 3980217088, 758991616, 64, 0, 0⟩,
  ⟨2170, false, 490556160, 20794112, 56, 0, 0⟩
]

theorem cases10_03_verified : cases10_03.all verified = true := by decide

def cases10_04 : List Case := [
  ⟨2174, false, 524110592, 54348544, 58, 0, 0⟩,
  ⟨2178, true, 1421691648, 213732096, 31, 27, 34⟩,
  ⟨2181, false, 4106046208, 884820736, 66, 0, 0⟩,
  ⟨2182, false, 213732096, 12405504, 58, 0, 0⟩,
  ⟨2185, false, 247286528, 45959936, 58, 0, 0⟩,
  ⟨2189, false, 968706816, 29182720, 60, 0, 0⟩,
  ⟨2194, false, 3988605696, 767380224, 64, 0, 0⟩,
  ⟨2195, false, 498944768, 29182720, 56, 0, 0⟩
]

theorem cases10_04_verified : cases10_04.all verified = true := by decide

def cases10_05 : List Case := [
  ⟨2199, false, 532499200, 62737152, 58, 0, 0⟩,
  ⟨2202, false, 410864384, 8211200, 56, 0, 0⟩,
  ⟨2205, false, 880626432, 75320064, 60, 0, 0⟩,
  ⟨2209, false, 7725730560, 209537792, 66, 0, 0⟩,
  ⟨2214, false, 31884921600, 6115117824, 70, 0, 0⟩,
  ⟨2215, false, 3967634176, 209537792, 62, 0, 0⟩,
  ⟨2218, false, 2088585984, 477973248, 64, 0, 0⟩,
  ⟨2222, false, 981289728, 41765632, 58, 0, 0⟩
]

theorem cases10_05_verified : cases10_05.all verified = true := by decide

def cases10_06 : List Case := [
  ⟨2225, false, 511527680, 108874496, 62, 0, 0⟩,
  ⟨2228, false, 1635601152, 24988416, 58, 0, 0⟩,
  ⟨2231, false, 3514649344, 293423872, 62, 0, 0⟩,
  ⟨2235, false, 30895065856, 830294784, 68, 0, 0⟩,
  ⟨2240, false, 127531830016, 24452614912, 72, 0, 0⟩,
  ⟨2241, false, 15862680320, 830294784, 64, 0, 0⟩,
  ⟨2244, false, 8346487552, 1904036608, 66, 0, 0⟩,
  ⟨2248, false, 2038254336, 159206144, 58, 0, 0⟩
]

theorem cases10_06_verified : cases10_06.all verified = true := by decide

def cases10_07 : List Case := [
  ⟨2251, false, 494750464, 92097280, 54, 0, 0⟩,
  ⟨2255, true, 11332832000, 1669155584, 32, 30, 37⟩,
  ⟨2258, false, 32807668480, 7037864704, 70, 0, 0⟩,
  ⟨2259, false, 1669155584, 58542848, 62, 0, 0⟩,
  ⟨2262, false, 1937591040, 326978304, 62, 0, 0⟩,
  ⟨2266, false, 7708953344, 192760576, 64, 0, 0⟩,
  ⟨2271, false, 31868144384, 6098340608, 68, 0, 0⟩,
  ⟨2272, false, 3950856960, 192760576, 60, 0, 0⟩
]

theorem cases10_07_verified : cases10_07.all verified = true := by decide

def cases10 : List Case := cases10_00 ++ cases10_01 ++ cases10_02 ++ cases10_03 ++ cases10_04 ++ cases10_05 ++ cases10_06 ++ cases10_07

theorem cases10_verified : cases10.all verified = true := by
  simp only [cases10, List.all_append, cases10_00_verified, cases10_01_verified, cases10_02_verified, cases10_03_verified, cases10_04_verified, cases10_05_verified, cases10_06_verified, cases10_07_verified, Bool.and_self]

end NF192.Control
