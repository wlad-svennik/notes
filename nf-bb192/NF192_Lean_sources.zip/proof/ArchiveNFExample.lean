import DirectNFToNormalized
import ArchiveTerms

/-! The archive's own CombNF interpretation inside a model of NF has absorbing
false. Its empty-set code is a self-constant for the characteristic-function
application. The B combinator cannot be a self-constant in any nontrivial
model. The obstruction for closed terms therefore applies to this particular
existing interpretation, whose carrier also admits an externally constructed
tester via NF graph comprehension. -/

set_option autoImplicit false
namespace FFL.FirstOrder.SetTheory.NFFn
open NF192.ArchiveTerms

variable {V : Type} [SetStructure V] [Nonempty V] [hT : V↓[ℒₛₑₜ] ⊧* 𝗡𝗙]

private theorem empty_self_application {e : V} (he : IsFF e) (x : V) : AppR e x e := by
  have notFunction : ¬ Fn e := by
    intro h
    obtain ⟨y,p,hp,_⟩ := h.2.1 e
    exact he p hp
  obtain ⟨g,hg⟩ := exists_chi e
  exact ⟨g, Or.inl ⟨inC_of_not_fn notFunction,hg⟩,
    ((chi_spec hg).2 x e).2 (Or.inr ⟨he x,he⟩)⟩

namespace ArchiveComparison
local notation "A" => Comb.combTranslation.Model V

noncomputable def algebra : _root_.NF192.ArchiveTerms.Model A := by
  let hm := Comb.combModel_models (M := V)
  exact {
    app := CNF.App
    K := CNF.Kf
    B := CNF.Bc
    R := CNF.Rc
    Q := CNF.Qc
    k := CNF.k_app hm
    b := CNF.b_app hm
    ext := fun h => CNF.c_ext hm h
    success := fun _ _ h => CNF.q_true hm h
    failure := fun _ _ h => CNF.q_false hm h
    distinct := CNF.b_ne_r hm
  }

theorem canonical_false_absorbs (x : A) : CNF.App (CNF.Rc : A) x = CNF.Rc := by
  have hr := (Comb.r_iff (CNF.Rc : A)).mp rfl
  obtain ⟨b,hb,empty_or⟩ := hr
  have eqB : b = ((CNF.Bc : A) : V) := b_unique hb ((Comb.b_iff (CNF.Bc : A)).mp rfl)
  rcases empty_or with ⟨bEmpty,_⟩ | ⟨_,rEmpty⟩
  · have impossible (y : A) : CNF.App (CNF.Bc : A) y = CNF.Bc :=
      ((Comb.app_iff (CNF.Bc : A) y CNF.Bc).2 (empty_self_application (eqB ▸ bEmpty) (y : V))).symm
    have hm := Comb.combModel_models (M := V)
    have law := CNF.b_app hm (CNF.Kf (CNF.Kf (CNF.Rc : A))) CNF.Bc CNF.Bc
    rw [impossible,impossible,impossible,CNF.k_app hm,CNF.k_app hm] at law
    exact False.elim ((CNF.b_ne_r hm) law)
  · exact ((Comb.app_iff (CNF.Rc : A) x CNF.Rc).2 (empty_self_application rEmpty (x : V))).symm

/-- In the original archive's canonical CombNF model, no pure closed
term of its language gives the countdown tester with the same application. -/
theorem no_closed_term (t : _root_.NF192.ArchiveTerms.Term) :
    let M := algebra (V := V)
    ¬ ((∀ f x, M.app f x = x → M.app (M.app (M.eval M.Q t) f) x = M.K M.B) ∧
       (∀ f x, M.app f x ≠ x → M.app (M.app (M.eval M.Q t) f) x = M.B)) :=
  (algebra (V := V)).no_uniform_normalized_term canonical_false_absorbs t

/-- The graph-comprehension tester already constructed on this very carrier
cannot be named by any pure closed term of the archived combinatory basis. -/
theorem graph_tester_outside_closed_terms (t : _root_.NF192.ArchiveTerms.Term) :
    (algebra (V := V)).eval (algebra (V := V)).Q t ≠ (Normalized.ofNF (V := V)).q := by
  intro eq
  apply no_closed_term (V := V) t
  constructor
  · intro f x fixed
    rw [eq]
    exact (Normalized.ofNF (V := V)).q_true f x fixed
  · intro f x nonfixed
    rw [eq]
    exact (Normalized.ofNF (V := V)).q_false f x nonfixed

end ArchiveComparison
end FFL.FirstOrder.SetTheory.NFFn

#print axioms FFL.FirstOrder.SetTheory.NFFn.ArchiveComparison.no_closed_term
#print axioms FFL.FirstOrder.SetTheory.NFFn.ArchiveComparison.graph_tester_outside_closed_terms
