module
public import MachineControlFrame

@[expose] public section

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Control

def cases09_00 : List Case := [
  ⟨1862, false, 2108508928, 229460736, 62, 0, 0⟩,
  ⟨1867, true, 711805696, 107825920, 28, 26, 33⟩,
  ⟨1870, false, 2053982976, 443370240, 62, 0, 0⟩,
  ⟨1871, false, 107825920, 7162624, 54, 0, 0⟩,
  ⟨1874, false, 124603136, 23939840, 54, 0, 0⟩,
  ⟨1878, false, 485313280, 15551232, 56, 0, 0⟩,
  ⟨1883, false, 1995262720, 384649984, 60, 0, 0⟩,
  ⟨1884, false, 250432256, 15551232, 52, 0, 0⟩
]

theorem cases09_00_verified : cases09_00.all verified = true := by decide

def cases09_01 : List Case := [
  ⟨1888, false, 267209472, 32328448, 54, 0, 0⟩,
  ⟨1893, true, 2828880640, 412961536, 30, 28, 35⟩,
  ⟨1896, false, 8197589760, 1755138816, 66, 0, 0⟩,
  ⟨1897, false, 412961536, 10308352, 58, 0, 0⟩,
  ⟨1900, false, 480070400, 77417216, 58, 0, 0⟩,
  ⟨1904, false, 1922910976, 43862784, 60, 0, 0⟩,
  ⟨1909, false, 7962708736, 1520257792, 64, 0, 0⟩,
  ⟨1910, false, 983386880, 43862784, 56, 0, 0⟩
]

theorem cases09_01_verified : cases09_01.all verified = true := by decide

def cases09_02 : List Case := [
  ⟨1914, false, 1050495744, 110971648, 58, 0, 0⟩,
  ⟨1918, false, 408767232, 6114048, 56, 0, 0⟩,
  ⟨1921, false, 878529280, 73222912, 60, 0, 0⟩,
  ⟨1925, false, 7723633408, 207440640, 66, 0, 0⟩,
  ⟨1930, false, 31882824448, 6113020672, 70, 0, 0⟩,
  ⟨1931, false, 3965537024, 207440640, 62, 0, 0⟩,
  ⟨1934, false, 2086488832, 475876096, 64, 0, 0⟩,
  ⟨1938, false, 979192576, 39668480, 58, 0, 0⟩
]

theorem cases09_02_verified : cases09_02.all verified = true := by decide

def cases09_03 : List Case := [
  ⟨1941, false, 509430528, 106777344, 62, 0, 0⟩,
  ⟨1944, false, 1633504000, 22891264, 58, 0, 0⟩,
  ⟨1947, false, 3512552192, 291326720, 62, 0, 0⟩,
  ⟨1951, false, 30892968704, 828197632, 68, 0, 0⟩,
  ⟨1956, false, 127529732864, 24450517760, 72, 0, 0⟩,
  ⟨1957, false, 15860583168, 828197632, 64, 0, 0⟩,
  ⟨1960, false, 8344390400, 1901939456, 66, 0, 0⟩,
  ⟨1964, false, 2036157184, 157108992, 58, 0, 0⟩
]

theorem cases09_03_verified : cases09_03.all verified = true := by decide

def cases09_04 : List Case := [
  ⟨1967, false, 492653312, 90000128, 54, 0, 0⟩,
  ⟨1971, true, 11330734848, 1667058432, 32, 30, 37⟩,
  ⟨1974, false, 32805571328, 7035767552, 70, 0, 0⟩,
  ⟨1975, false, 1667058432, 56445696, 62, 0, 0⟩,
  ⟨1978, false, 1935493888, 324881152, 62, 0, 0⟩,
  ⟨1982, false, 7706856192, 190663424, 64, 0, 0⟩,
  ⟨1987, false, 31866047232, 6096243456, 68, 0, 0⟩,
  ⟨1988, false, 3948759808, 190663424, 60, 0, 0⟩
]

theorem cases09_04_verified : cases09_04.all verified = true := by decide

def cases09_05 : List Case := [
  ⟨1992, false, 4217195264, 459098880, 62, 0, 0⟩,
  ⟨1996, false, 819809024, 14502656, 60, 0, 0⟩,
  ⟨1999, false, 1759333120, 148720384, 64, 0, 0⟩,
  ⟨2003, false, 15449541376, 417155840, 70, 0, 0⟩,
  ⟨2008, false, 63767923456, 12228315904, 74, 0, 0⟩,
  ⟨2009, false, 7933348608, 417155840, 66, 0, 0⟩,
  ⟨2012, false, 4175252224, 954026752, 68, 0, 0⟩,
  ⟨2016, false, 1960659712, 81611520, 62, 0, 0⟩
]

theorem cases09_05_verified : cases09_05.all verified = true := by decide

def cases09_06 : List Case := [
  ⟨2019, false, 1021135616, 215829248, 66, 0, 0⟩,
  ⟨2022, false, 1658669824, 48057088, 62, 0, 0⟩,
  ⟨2025, false, 3537718016, 316492544, 66, 0, 0⟩,
  ⟨2029, false, 30918134528, 853363456, 72, 0, 0⟩,
  ⟨2034, false, 127554898688, 24475683584, 76, 0, 0⟩,
  ⟨2035, false, 15885748992, 853363456, 68, 0, 0⟩,
  ⟨2038, false, 8369556224, 1927105280, 70, 0, 0⟩,
  ⟨2042, false, 3940371200, 182274816, 64, 0, 0⟩
]

theorem cases09_06_verified : cases09_06.all verified = true := by decide

def cases09_07 : List Case := [
  ⟨2045, false, 2061323008, 450710272, 62, 0, 0⟩,
  ⟨2049, true, 22663744256, 3336391424, 35, 31, 38⟩,
  ⟨2052, false, 65613417216, 14073809664, 74, 0, 0⟩,
  ⟨2053, false, 3336391424, 115165952, 66, 0, 0⟩,
  ⟨2056, false, 3873262336, 652036864, 66, 0, 0⟩,
  ⟨2060, false, 15415986944, 383601408, 68, 0, 0⟩,
  ⟨2065, false, 63734369024, 12194761472, 72, 0, 0⟩,
  ⟨2066, false, 7899794176, 383601408, 64, 0, 0⟩
]

theorem cases09_07_verified : cases09_07.all verified = true := by decide

def cases09 : List Case := cases09_00 ++ cases09_01 ++ cases09_02 ++ cases09_03 ++ cases09_04 ++ cases09_05 ++ cases09_06 ++ cases09_07

theorem cases09_verified : cases09.all verified = true := by
  simp only [cases09, List.all_append, cases09_00_verified, cases09_01_verified, cases09_02_verified, cases09_03_verified, cases09_04_verified, cases09_05_verified, cases09_06_verified, cases09_07_verified, Bool.and_self]

end NF192.Control
