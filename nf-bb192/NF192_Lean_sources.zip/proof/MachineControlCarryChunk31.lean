module
public import MachineControlCarryCoverage

@[expose] public section
namespace NF192.Carry
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def carryCases31_00 : List Case := [
  ⟨2973, true, 2976, false, 19, 2, 26⟩,
  ⟨2974, false, 2975, false, 21, 1, 28⟩,
  ⟨2976, false, 2977, false, 22, 1, 29⟩,
  ⟨2976, true, 2980, false, 21, 2, 28⟩,
  ⟨2977, false, 2978, false, 23, 1, 30⟩,
  ⟨2978, false, 2979, false, 24, 1, 31⟩,
  ⟨2980, false, 2981, false, 22, 1, 29⟩,
  ⟨2980, true, 2986, false, 20, 3, 27⟩]
theorem carryCases31_00_verified : carryCases31_00.all verified = true := by decide

def carryCases31_01 : List Case := [
  ⟨2981, false, 2982, false, 24, 1, 31⟩,
  ⟨2982, false, 2983, false, 25, 1, 32⟩,
  ⟨2982, true, 2985, false, 23, 3, 30⟩,
  ⟨2983, false, 2984, false, 26, 1, 33⟩,
  ⟨2986, false, 2987, false, 21, 1, 28⟩,
  ⟨2986, true, 2989, false, 17, 5, 24⟩,
  ⟨2987, false, 2988, false, 22, 1, 29⟩,
  ⟨2989, false, 2990, false, 18, 1, 25⟩]
theorem carryCases31_01_verified : carryCases31_01.all verified = true := by decide

def carryCases31_02 : List Case := [
  ⟨2989, true, 2993, false, 16, 3, 23⟩,
  ⟨2990, false, 2991, false, 19, 1, 26⟩,
  ⟨2991, false, 2992, false, 20, 1, 27⟩,
  ⟨2993, false, 2994, false, 17, 1, 24⟩,
  ⟨2993, true, 2996, false, 14, 4, 21⟩,
  ⟨2994, false, 2995, false, 18, 1, 25⟩,
  ⟨2996, false, 2997, false, 17, 1, 24⟩,
  ⟨2996, true, 3000, false, 16, 2, 23⟩]
theorem carryCases31_02_verified : carryCases31_02.all verified = true := by decide

def carryCases31_03 : List Case := [
  ⟨2997, false, 2998, false, 18, 1, 25⟩,
  ⟨2997, true, 3000, false, 16, 3, 23⟩,
  ⟨2998, false, 2999, false, 19, 1, 26⟩,
  ⟨2998, true, 3000, false, 16, 4, 23⟩,
  ⟨2999, false, 3000, false, 16, 4, 23⟩,
  ⟨3000, false, 3001, false, 17, 1, 24⟩,
  ⟨3000, true, 3002, false, 15, 3, 22⟩,
  ⟨3002, false, 3003, false, 18, 1, 25⟩]
theorem carryCases31_03_verified : carryCases31_03.all verified = true := by decide

def carryCases31_04 : List Case := [
  ⟨3002, true, 3010, false, 17, 2, 24⟩,
  ⟨3003, false, 3004, false, 20, 1, 27⟩,
  ⟨3004, false, 3005, false, 22, 1, 29⟩,
  ⟨3004, true, 3006, false, 21, 2, 28⟩,
  ⟨3006, false, 3007, false, 22, 1, 29⟩,
  ⟨3006, true, 3009, false, 19, 4, 26⟩,
  ⟨3007, false, 3008, false, 23, 1, 30⟩,
  ⟨3010, false, 3011, false, 18, 1, 25⟩]
theorem carryCases31_04_verified : carryCases31_04.all verified = true := by decide

def carryCases31_05 : List Case := [
  ⟨3010, true, 3013, false, 16, 3, 23⟩,
  ⟨3011, false, 3012, false, 19, 1, 26⟩,
  ⟨3013, false, 3014, false, 17, 1, 24⟩,
  ⟨3013, true, 3016, false, 12, 6, 19⟩,
  ⟨3014, false, 3015, false, 18, 1, 25⟩,
  ⟨3017, false, 3018, false, 15, 1, 22⟩,
  ⟨3017, true, 3020, false, 14, 2, 21⟩,
  ⟨3018, false, 3019, false, 16, 1, 23⟩]
theorem carryCases31_05_verified : carryCases31_05.all verified = true := by decide

def carryCases31_06 : List Case := [
  ⟨3020, false, 3021, false, 16, 1, 23⟩,
  ⟨3020, true, 3023, false, 15, 2, 22⟩,
  ⟨3021, false, 3022, false, 17, 1, 24⟩,
  ⟨3023, false, 3024, false, 18, 1, 25⟩,
  ⟨3023, true, 3027, false, 17, 2, 24⟩,
  ⟨3024, false, 3025, false, 19, 1, 26⟩,
  ⟨3025, false, 3026, false, 20, 1, 27⟩,
  ⟨3027, false, 3028, false, 18, 1, 25⟩]
theorem carryCases31_06_verified : carryCases31_06.all verified = true := by decide

def carryCases31_07 : List Case := [
  ⟨3027, true, 3033, false, 16, 3, 23⟩,
  ⟨3028, false, 3029, false, 20, 1, 27⟩,
  ⟨3029, false, 3030, false, 21, 1, 28⟩,
  ⟨3029, true, 3032, false, 19, 3, 26⟩,
  ⟨3030, false, 3031, false, 22, 1, 29⟩,
  ⟨3033, false, 3034, false, 17, 1, 24⟩,
  ⟨3033, true, 3036, false, 13, 5, 20⟩,
  ⟨3034, false, 3035, false, 18, 1, 25⟩]
theorem carryCases31_07_verified : carryCases31_07.all verified = true := by decide

def carryCases31_08 : List Case := [
  ⟨3036, false, 3037, false, 15, 1, 22⟩,
  ⟨3036, true, 3040, false, 14, 2, 21⟩,
  ⟨3037, false, 3038, false, 16, 1, 23⟩,
  ⟨3038, false, 3039, false, 17, 1, 24⟩,
  ⟨3040, false, 3041, false, 15, 1, 22⟩,
  ⟨3040, true, 3043, false, 12, 4, 19⟩,
  ⟨3041, false, 3042, false, 16, 1, 23⟩,
  ⟨3043, false, 3044, false, 15, 1, 22⟩]
theorem carryCases31_08_verified : carryCases31_08.all verified = true := by decide

def carryCases31_09 : List Case := [
  ⟨3043, true, 3051, false, 14, 2, 21⟩,
  ⟨3044, false, 3045, false, 17, 1, 24⟩,
  ⟨3045, false, 3046, false, 19, 1, 26⟩,
  ⟨3045, true, 3047, false, 18, 2, 25⟩,
  ⟨3047, false, 3048, false, 19, 1, 26⟩,
  ⟨3047, true, 3050, false, 16, 4, 23⟩,
  ⟨3048, false, 3049, false, 20, 1, 27⟩,
  ⟨3051, false, 3052, false, 15, 1, 22⟩]
theorem carryCases31_09_verified : carryCases31_09.all verified = true := by decide

def carryCases31_10 : List Case := [
  ⟨3051, true, 3054, false, 13, 3, 20⟩,
  ⟨3052, false, 3053, false, 16, 1, 23⟩,
  ⟨3054, false, 3055, false, 16, 1, 23⟩,
  ⟨3054, true, 3058, false, 15, 2, 22⟩,
  ⟨3055, false, 3056, false, 17, 1, 24⟩,
  ⟨3056, false, 3057, false, 18, 1, 25⟩,
  ⟨3058, false, 3059, false, 16, 1, 23⟩,
  ⟨3058, true, 3064, false, 14, 3, 21⟩]
theorem carryCases31_10_verified : carryCases31_10.all verified = true := by decide

def carryCases31_11 : List Case := [
  ⟨3059, false, 3060, false, 18, 1, 25⟩,
  ⟨3060, false, 3061, false, 19, 1, 26⟩,
  ⟨3060, true, 3063, false, 17, 3, 24⟩,
  ⟨3061, false, 3062, false, 20, 1, 27⟩,
  ⟨3064, false, 3065, false, 15, 1, 22⟩,
  ⟨3064, true, 3068, false, 11, 5, 18⟩,
  ⟨3065, false, 3066, false, 16, 1, 23⟩,
  ⟨3066, false, 3067, false, 17, 1, 24⟩]
theorem carryCases31_11_verified : carryCases31_11.all verified = true := by decide

def carryCases31 : List Case := carryCases31_00 ++ carryCases31_01 ++ carryCases31_02 ++ carryCases31_03 ++ carryCases31_04 ++ carryCases31_05 ++ carryCases31_06 ++ carryCases31_07 ++ carryCases31_08 ++ carryCases31_09 ++ carryCases31_10 ++ carryCases31_11
theorem carryCases31_verified : carryCases31.all verified = true := by
  simp only [carryCases31, List.all_append, carryCases31_00_verified, carryCases31_01_verified, carryCases31_02_verified, carryCases31_03_verified, carryCases31_04_verified, carryCases31_05_verified, carryCases31_06_verified, carryCases31_07_verified, carryCases31_08_verified, carryCases31_09_verified, carryCases31_10_verified, carryCases31_11_verified, Bool.and_self]
theorem carryCases31_covered : carryCases31.map (fun c => key c.pc c.zero) = keysBetween 5947 189 := by decide
theorem carryCases31_count : carryCases31.length = 96 := by decide
end NF192.Carry
