# Reproduce the countdown proof on Linux

Run these commands from the unpacked proof directory.

## Offline certificate replay

On x86-64 Linux, Python 3.11 and `zstd` are sufficient for the bundled checkers. Allow 250 MB of temporary disk space for decompression. The full certificate is 235,338,402 bytes. The theory and stream scopes select exact dependency-first prefixes of that export. The boot and source scopes each use a separately compressed export with a pinned SHA-256. The script checks the SHA-256 of the chosen proof bytes before running the checker.

| Command | Checker and coverage |
| --- | --- |
| `python3 scripts/check_certificate.py --scope boot` | Independent Rust kernel. Checks `NF192.Frame.blank_margin_frame`, the exact frame after 33,911 binary steps from the blank tape. Recorded time 10.54 seconds across 2,294 declarations, peak resident memory approximately 70 MiB. |
| `python3 scripts/check_certificate.py --scope source` | Independent Rust kernel. Checks the entire literal register source against numerical derivability from a sound command boundary. Recorded time 66.62 seconds across 2,911 declarations, peak resident memory approximately 193 MiB. |
| `python3 scripts/check_certificate.py --checker paranoid --scope full` | Lean 4.35.0 reference kernel. Replays the complete machine certificate in an empty environment and checks its primitive quotient declarations. This is the default command. |
| `python3 scripts/check_certificate.py --checker nanoda --scope theory` | Independent Rust kernel. Checks the numerical theory against first-order NF. Recorded time 65 seconds, peak resident memory approximately 542 MiB. |
| `python3 scripts/check_certificate.py --checker nanoda --scope stream` | Independent Rust kernel. Includes the proof-command enumerator. Recorded time 66 seconds, peak resident memory approximately 546 MiB. |

The recorded full reference-kernel run stopped at the experiment's 2.20 GiB memory cap after 1,151.24 seconds. Its sampled peak was 2,308,728 KiB, and the checker had yet to return a verdict. A full Rust attempt reached 6.94 GiB. For a machine with limited memory, the boot scope checks physical startup with the smallest footprint. Boot, source, theory and stream all have completed independent Rust receipts. The full theorem also passed the native Lean source build and per-module kernel checking. The packaged script leaves the memory limit to the host. Use `--checker paranoid` or `--checker nanoda` to select either implementation at any scope. The script accepts a custom executable through `--paranoid PATH` or `--nanoda PATH`. The default `--checker auto` chooses the reference kernel for the full machine and Rust for boot, source, theory and stream.

The source certificate proves `NF192.SourceSimulation.literal_source_iff_goal` using alternate proof bodies. Its theorem statement and literal program data match the originals. [Changes to the proof implementation](alternatives/low-memory-v3/README.md).

The full reference-kernel command invokes `leanchecker-paranoid --silent --from-export FILE`. Its success signal is exit code zero. The script publishes the local elapsed checker time and theorem names only after that signal. Completed release runs are recorded in `verification/independent/`.

## Rebuild from source

Use Python 3.11 or newer, Git, curl, GNU tar and zstd. The default toolchain download is the official x86-64 Linux release. Allow about 20 GB of available disk space for the toolchain, dependency caches and compilation products. The recorded compilation of the final module used 5.4 GiB of resident memory. Building upstream dependencies can use additional memory when several jobs run together. Use `--jobs 1` for a serial dependency build.

```bash
python3 scripts/reproduce.py --nf-archive inputs/nf-interp.zip
```

The included `inputs/nf-interp.zip` contains the NF, FNF and CombNF development. The script checks its SHA-256, extracts the uploaded standalone project and Foundation wrapper, fetches their exact source revisions, and installs Lean 4.35.0. It retrieves the matching mathlib compiled-module cache and builds the uploaded `CombAll` module. It then compiles the local proof in dependency order, checks each local module with Lean’s `leanchecker`, and audits the named theorem declarations.

The result is `.reproduce/receipts/reproduction.summary.json`. It records the Lean version, checked module order, source hashes, per-module receipt hashes and the axioms reported for each endpoint. Rerunning the same command resumes the verified local outputs. The theorem audits accept only `propext`, `Classical.choice` and `Quot.sound`. A failed command exits with an error.

## What the command checks

| Declaration | Verified statement |
| --- | --- |
| `NF192.countdown_halts_iff_nf_inconsistent` | The exact transition table halts on the blank tape if and only if first-order NF is inconsistent. |
| `NF192.countdown_halts_iff_nf_proves_bot` | The exact table halts if and only if NF has a finite first-order derivation of falsity. |
| `NF192.countdown_never_halts` | The uploaded consistency development implies that the table runs forever on the blank tape. |
| `NF192.literal_source_halts_iff_nf_inconsistent` | The 3,089-instruction register source halts from any sound command boundary if and only if NF is inconsistent. |
| `NF192.command_stream_halts_iff_nf_inconsistent` | The abstract proof-search stream has the same property at a sound refill boundary. |
| `NF192.Input.exact_transition_table` | The transition table in the theorem serializes to the supplied machine file, including the start state and final newline. |
| `NF192.Input.exact_countdown_source` | The Lean source-program data serializes to the supplied register-program JSON byte for byte. |

The statement audit accompanies the proof as `STATEMENT-AUDIT.md`. The input conventions and exact byte provenance are in `machine/INPUTS.md`. The four additional named audits in `NF192Countdown.lean` check both existence of a normalized-basis model and blank-tape halting against the archived CombNF and FunctionNF theories. The byte checks compare against fragments read from the supplied files during elaboration. The raw file hashes can be checked independently.

```bash
(cd machine && sha256sum -c SHA256SUMS)
```

## Pinned inputs

| Input | Revision or SHA-256 |
| --- | --- |
| Included `nf-interp.zip` | `52e0fc8a41c9eb4ba170d712697e0fdb69a8662b04e186f248b317913752e3e8` |
| Originally verified `nf-interp.zip` | `0d840316c347b659bcd20008450387e0f5d0191ff0ebd5bb700a6f04f2363a90` |
| Official Lean 4.35.0 source commit | `eb6cafb7290e8bd5f2937522d8d804f58f02bafc` |
| Official Linux x86-64 release archive | `7289597a44543246c9227b8cae501767e095ce17f6d448b95fc4a8dc97268f6d` |
| Formalized Formal Logic, Foundation | `fbcfee52cb4a892087fa978366282a9ebd844f29` |
| Mathlib | `56a005855ea17e0b0958f73ec801ae140b0a1679` |
| `machine/NF_192_countdown.tm` | `ee1391964b35c7ad2f0db90305a84e09c6523f73f3dce6c4f31a182aa270d565` |
| `machine/countdown.sites.json` | `b991565b82033c133e1f2b4618dfe32d1e7ff1ef02e8e18620a2dfdccb5307aa` |

The 14 Git dependencies of the standalone project are pinned by its original Lake manifest. Their repository URLs and commit hashes are listed in `provenance/reproduction-inputs.json`. The Foundation source revision is taken from the archive's README. Its Lake wrapper and wrapper manifest come directly from the archive. Prior proof sources and their licenses are documented in `provenance/README.md`.

## Reuse an installation or a cache

An existing official Lean installation can be supplied explicitly. The script checks the compiler's Git commit. A local `.tar.zst` can instead be passed with `--toolchain-archive`. In that case the script checks the release archive SHA-256 before extraction.

```bash
python3 scripts/reproduce.py \
  --nf-archive /path/to/nf-interp.zip \
  --lean-bin /path/to/lean-4.35.0-linux/bin \
  --work /path/to/build \
  --mathlib-cache /path/to/mathlib-cache \
  --jobs 3
```

To reuse local Git objects, add `--git-mirror DIR`. The script looks for repositories named after the manifest packages, for example `DIR/mathlib`, and `DIR/Foundation-src`. Missing local repositories are fetched from their upstream URLs. It checks out each specified commit into the build directory and verifies the commit and tracked source files.

For a separate transitive replay from a fresh kernel environment, add `--fresh-kernel NF192Countdown`. This option also replays the imported upstream declarations and may use substantially more resources than per-module checking. To compile a smaller local proof closure, specify one or more `--module` options, followed by any named `--audit` declarations that should be checked. For a target such as `MachineInputBinding` whose imports all come from this project and Lean itself, the script checks the inputs and replays just that closure.
