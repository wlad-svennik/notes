# The 192-state NF countdown machine — source edition

The main theorem is `NF192.countdown_halts_iff_nf_proves_bot` in `proof/NF192Countdown.lean`. It states that the supplied machine halts on a blank tape exactly when ordinary first-order New Foundations proves a contradiction.

Read `PROOF.md` for the informal proof. To rebuild the full theorem, follow `REPRODUCE.md` and run `python3 scripts/reproduce.py --nf-archive inputs/nf-interp.zip`. The original seven-theory development is included unchanged. The `provenance/` directory identifies the origins and licensing of reused code.

The complete verification package on the repository’s NF192 release also includes offline proof certificates and their Linux checkers. The prebuilt offline certificate commands in `REPRODUCE.md` require that complete package.
