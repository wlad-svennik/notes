# What the countdown theorem says

The machine starts in `k:64`, with its head at cell zero on the all-zero,
two-sided binary tape. Its halting condition is equivalent to the existence
of a finite classical first-order derivation of falsity from Quine's New
Foundations. The formal statement is
`NF192.countdown_halts_iff_nf_inconsistent` in `proof/NF192Countdown.lean`.

## The first-order theory

The notation `𝗡𝗙` expands to
`FFL.FirstOrder.SetTheory.NewFoundations`. It is defined in the supplied
`standalone/NFTheories.lean`, lines 185–207. The theory has the following
axioms.

| Axiom family | Content |
| --- | --- |
| Equality | Reflexivity, symmetry, transitivity and compatibility with the relation symbols. The language has two binary relations, equality and membership, and no function symbols. |
| Extensionality | For every pair of objects, having the same members implies equality. This includes pairs of objects with no members. |
| Stratified comprehension | For every stratified formula $\varphi(x,\vec p)$, the universal closure of $\exists y\,\forall x\,(x\in y\leftrightarrow\varphi(x,\vec p))$ is an axiom. The bound variable $y$ is fresh. |

The type assignment in an atom $x=y$ requires equal types. In $x\in y$ it
requires $\operatorname{type}(y)=\operatorname{type}(x)+1$. A conjunction
or disjunction uses the same assignment in both subformulas. Each quantifier
chooses the type of its bound variable. Negative atoms obey the same
constraints. The types are used to select comprehension axioms and do not
occur in the language of the resulting first-order sentences.
See `Language.Stratification`, `Semiformula.Stratified` and
`Semiformula.IsStratified` in `NFTheories.lean`, lines 79–88 and 125–177.

Comprehension allows parameters. The type `SetTheorySemiproposition 1`
has one distinguished argument and natural-number-indexed free variables.
Each finite formula mentions only finitely many of them. The operation
`Semiformula.univCl` closes over those parameters. The pinned Foundation
sources are `Foundation/FirstOrder/Syntax/Classical/Formula.lean`,
`Foundation/FirstOrder/Syntax/Classical/Rew.lean` and
`Foundation/FirstOrder/SetTheory/Basic/Misc.lean`. The equality axioms
are `Theory.eqAxiom` in `Foundation/FirstOrder/Syntax/Classical/Eq.lean`.

## The meaning of inconsistency

The right side in Lean is `¬ Entailment.Consistent 𝗡𝗙`. Foundation proves
`not_consistent_iff_inconsistent` and `inconsistent_iff_provable_bot`,
so this is equivalent to `𝗡𝗙 ⊢ ⊥`. Here provability means that a
`Theory.Proof` exists. It contains a finite multiset of axioms, a proof
that each belongs to NF and a classical one-sided sequent derivation.
The definitions are in `Foundation/Logic/Entailment.lean`, lines 210–229
and 264–271, and `Foundation/FirstOrder/LK/Basic.lean`, lines 361–371.

`NF192.countdown_halts_iff_goal` identifies the exact machine's halting
condition with derivability of the numerical goal. The theorem
`NF192.derives_goal_iff_nf_inconsistent` identifies that derivability
with first-order NF inconsistency by constructing models for the normalized
basis and using the uploaded CombNF and FunctionNF interpretations.
The separate corollary `NF192.countdown_never_halts` invokes the uploaded
development's independent proof of NF consistency in Lean's metatheory.

## The machine and its archived program

The byte sizes, archive paths and execution conventions for both inputs
appear in `machine/INPUTS.md`. From the `machine` directory,
`sha256sum -c SHA256SUMS` identifies the table and source program.
The table contains two rows per working state and a single transition into
halt, `k:302 1 0 L halt`. The terminal state is outside the 192 working
states. The relevant declarations are `NF210.TM.blank`, `NF210.TM.Halts`,
`NF192.Selected.unique_halt`, `NF192.Input.exact_transition_table` and
`NF192.Input.exact_countdown_source`.
