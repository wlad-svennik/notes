# Changing the two return values

The countdown tester returns `K(B)` when `f x = x` and `B` otherwise. The archived CombNF tester `Q` returns `B` and `R`, with `B ≠ R`. Keep the carrier, application, `K` and `B` fixed. A *closed term* uses only `B, R, Q`, unary `K` and application.

## A direct conversion when R is B B

Set `a = K(K(K B))`, `c = K B`, and apply the returned value `v` to three arguments as `C(v) = v a c B`. Application associates to the left.

- On success, `C(B) = a (K B) (c B) = K B`.
- On failure, the combinator law gives `(B B) a c d = c ((a c) d)`, so `C(B B) = c ((a c) B) = B`.

To express all three applications inside the stratified calculus, lift the test three times. Each lift uses the fact that `B (K f)` fixes `K x` exactly when `f` fixes `x`. Lean checked both outputs of the resulting finite term in `NF192.ArchiveTerms.Model.bb_normalized_term`. [ArchiveSpecial.lean](proof/ArchiveSpecial.lean)

## The archived NF interpretation

When `R x = R` for every `x`, **no closed term in the archived basis implements the countdown tester**. The proof compares the identity function and `R` at the argument `B`. The required outputs are `K B` and `B`. A relation on successive function levels shows that replacing `Q` by the constant-success tester gives a common approximation for the two outputs of any closed term. Four successive arguments separate `K B` from `B` and rule out that common approximation. [ArchiveTerms.lean](proof/ArchiveTerms.lean)

The uploaded archive’s own CombNF interpretation inside any NF model satisfies this hypothesis. Its `R` is the empty-set code, whose characteristic function always returns the empty set. Its `B` cannot be self-constant, by the combinator law and `B ≠ R`.

The desired relation has the first-order definition `(f x = x ∧ y = K(B)) ∨ (f x ≠ x ∧ y = B)`. NF represents it using two stratified graph comprehensions. Lean checked that **on this same carrier** the resulting tester differs from the value of every closed archived term. The theorem is `FFL.FirstOrder.SetTheory.NFFn.ArchiveComparison.graph_tester_outside_closed_terms`. [Graph construction](proof/DirectNFToNormalized.lean) · [Separation proof](proof/ArchiveNFExample.lean)
