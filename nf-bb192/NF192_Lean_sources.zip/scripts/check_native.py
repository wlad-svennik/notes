#!/usr/bin/env python3
"""Build a local Lean module closure and replay its declarations with the pinned kernel."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time

PROJECT = Path(__file__).resolve().parents[1]
PIN = 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
DEFAULT_ROOTS = ['GroundAlgebra', 'StratifiedTester', 'NumericalModel',
                 'NumericalAxioms', 'SourceFields', 'ProofWords', 'SourceEnumeration']
IMPORT = re.compile(r'^\s*(?:(?:public|private|meta)\s+)*import\s+(?:all\s+)?([\w.]+)', re.M)
INCLUDE = re.compile(r'(?<!["\w])(?:include_(?:str|bytes)|input_fragments%)[ \t]+"([^"\\\r\n]+)"')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def json_write(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
    tmp.replace(path)

def locate(name, directory, suffix):
    return directory.joinpath(*name.split('.')).with_suffix(suffix)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('modules', nargs='*', default=DEFAULT_ROOTS)
    parser.add_argument('--lean-bin', type=Path, help='bin directory of the official Lean 4.35.0 release')
    parser.add_argument('--source-dir', type=Path, default=PROJECT/'proof')
    parser.add_argument('--out-dir', type=Path, default=PROJECT/'native-olean')
    parser.add_argument('--receipt-dir', type=Path, default=PROJECT/'native-receipts')
    parser.add_argument('--search-path', type=Path, action='append', default=[],
                        help='additional compiled dependency root, repeatable')
    parser.add_argument('--fresh', action='append', default=[], metavar='MODULE',
                        help='also replay the entire transitive import closure starting from an empty environment')
    parser.add_argument('--audit', action='append',default=[],metavar='DECLARATION',
                        help='print the named declaration and require only the three standard axioms')
    parser.add_argument('--summary', default='core', help='name of the resulting JSON receipt')
    args = parser.parse_args()
    source, out, receipts = [v.resolve() for v in (args.source_dir, args.out_dir, args.receipt_dir)]
    for d in [out, receipts]:
        d.mkdir(parents=True, exist_ok=True)
    if args.lean_bin:
        bindir = args.lean_bin.resolve()
    else:
        bundled = PROJECT/'env/lean-4.35.0-linux/bin'
        located = shutil.which('lean')
        if not bundled.is_dir() and not located:
            parser.error('Supply --lean-bin for the pinned Lean release.')
        bindir = bundled if bundled.is_dir() else Path(located).resolve().parent
    lean, checker = [str(bindir/name) for name in ('lean', 'leanchecker')]
    env = os.environ.copy()
    env['PATH'] = str(bindir) + os.pathsep + env['PATH']
    search = [out, *(d.resolve() for d in args.search_path)]
    env['LEAN_PATH'] = os.pathsep.join(map(str,search))
    if subprocess.check_output([lean, '--githash'], env=env, text=True).strip() != PIN:
        parser.error('This proof is pinned to the official Lean v4.35.0 commit '+PIN)
    version = subprocess.check_output([lean, '--version'], env=env, text=True).strip()
    syslib = Path(subprocess.check_output([lean, '--print-libdir'], env=env, text=True).strip())
    # Inspect local module imports before calling the compiler. External imports
    # remain visible only through the explicit search paths and pinned Lean.
    order, local_imports, external, visiting = [], {}, {}, set()
    def visit(m):
        if m in order:
            return
        if m in visiting:
            raise SystemExit('local import cycle at '+m)
        f = locate(m,source,'.lean')
        if not f.is_file():
            raise SystemExit('Cannot find local source '+str(f))
        visiting.add(m)
        names = list(dict.fromkeys(IMPORT.findall(f.read_text())))
        local_imports[m] = []
        external[m] = {}
        for dep in names:
            if locate(dep, source, '.lean').is_file():
                visit(dep)
                local_imports[m].append(dep)
                continue
            fdep = next((p for d in [*search,syslib] if (p:=locate(dep,d,'.olean')).is_file()),None)
            if not fdep:
                raise SystemExit('Missing compiled external module '+dep+' imported by '+m)
            external[m][dep] = sha(fdep)
        visiting.remove(m)
        order.append(m)
    for m in args.modules:
        visit(m)
    def run(cmd, logfile):
        tick = time.monotonic()
        with logfile.open('wb') as log:
            result = subprocess.run(cmd, env=env, cwd=source, stdout=log,stderr=subprocess.STDOUT)
        if result.returncode:
            raise SystemExit(logfile.read_text(errors='replace')[-10000:]+
                             '\nFailed '+cmd[0]+'; log '+str(logfile))
        if re.search(r"declaration uses '(sorry|admit)'", logfile.read_text(errors='replace')):
            raise SystemExit('Incomplete proof reported in '+str(logfile))
        return round(time.monotonic()-tick,3)
    records = {}
    for m in order:
        src = locate(m,source,'.lean')
        target = locate(m,out,'.olean')
        target.parent.mkdir(parents=True,exist_ok=True)
        slog = receipts/(m+'.build.log')
        klog = receipts/(m+'.kernel.log')
        cached = receipts/(m+'.json')
        identity = dict(lean_commit=PIN, source_sha256=sha(src),
                        direct_project_imports={d:records[d]['outputs'] for d in local_imports[m]},
                        direct_external_imports=external[m])
        included = sorted(set(INCLUDE.findall(src.read_text())))
        if included:
            identity['included_files'] = {name:sha(src.parent/name) for name in included}
        prev = json.loads(cached.read_text()) if cached.is_file() else {}
        if (prev.get('identity') == identity and
                all((target.parent/k).is_file() and sha(target.parent/k)==h for k,h in prev['outputs'].items()) and
                slog.is_file() and klog.is_file() and
                prev.get('build_log_sha256')==sha(slog) and prev.get('kernel_log_sha256')==sha(klog)):
            records[m] = prev
            print('cached',m,flush=True)
            continue
        with tempfile.TemporaryDirectory(dir=out,prefix='.compile-') as t:
            t = Path(t)
            o = t/target.name
            before=sha(src)
            seconds = run([lean,'-j1','-R',str(source),'-o',str(o),str(src)],slog)
            if sha(src)!=before:
                raise SystemExit('Source changed during compilation; rerun for '+m)
            if included and identity['included_files'] != {name:sha(src.parent/name) for name in included}:
                raise SystemExit('Embedded input changed during compilation; rerun for '+m)
            if not o.is_file():
                raise SystemExit('Missing olean from compilation of '+m)
            products = {}
            for artifact in sorted(t.iterdir()):
                products[artifact.name]=sha(artifact)
                artifact.replace(target.parent/artifact.name)
        kernel_time=run([checker,'-v',m],klog)
        record=dict(module=m,identity=identity,outputs=products,compile_seconds=seconds,
                    kernel_seconds=kernel_time,build_log_sha256=sha(slog),kernel_log_sha256=sha(klog))
        json_write(cached,record)
        records[m]=record
        print('checked',m,seconds,kernel_time,flush=True)
    fresh = {}
    for m in args.fresh:
        if m not in records:
            raise SystemExit('Fresh replay target is outside the source closure: '+m)
        logfile = receipts/(m+'.fresh.log')
        sec = run([checker,'--fresh','-v',m],logfile)
        fresh[m] = {'seconds':sec, 'log_sha256':sha(logfile)}
        print('fresh',m,sec,flush=True)
    audited = {}
    if args.audit:
        for name in args.audit:
            if not all(part.isidentifier() for part in name.split('.')):
                raise SystemExit('Invalid Lean declaration name '+name)
        with tempfile.TemporaryDirectory() as t:
            t=Path(t)
            probe=t/'NamedAxiomAudit.lean'
            lines=['import '+mod for mod in args.modules]
            for name in args.audit:
                lines.extend(['#check @'+name,'#print axioms '+name])
            probe.write_text('\n'.join(lines)+'\n')
            log=receipts/(args.summary+'.axioms.log')
            run([lean,'-j1','-R',str(t),str(probe)],log)
            messages=log.read_text()
            for name in args.audit:
                found=re.search(r"'"+re.escape(name)+r"' depends on axioms:\s*\[([^\]]*)\]",messages)
                if found:
                    names=[v.strip() for v in found.group(1).split(',') if v.strip()]
                elif "'"+name+"' does not depend on any axioms" in messages:
                    names=[]
                else:
                    raise SystemExit('Missing axiom report for '+name)
                if set(names)-{'Classical.choice','propext','Quot.sound'}:
                    raise SystemExit('Unexpected axiom in '+name+': '+str(names))
                audited[name]=names
    summary = dict(lean_version=version,roots=args.modules,order=order,fresh=fresh,audited_axioms=audited,
                   source_sha256={m:records[m]['identity']['source_sha256'] for m in order},
                   module_receipts={m:sha(receipts/(m+'.json')) for m in order})
    json_write(receipts/(args.summary+'.summary.json'),summary)

if __name__=='__main__':
    main()
