#!/usr/bin/env python3
"""Check the exported NF countdown proof without building NF or Mathlib."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
FULL = 'nf-countdown-complete'
SCOPES = {
    'boot': ('physical-blank-margin', 'NF192.Frame.blank_margin_frame',
             '0e9b59f6b440bf7e6779258e342acc2bc18ea30ac52ccd31dcc9d9f32ea9bc17'),
    'source': ('bounded-mode-literal', 'NF192.SourceSimulation.literal_source_iff_goal',
               '30ebe82ce17d6e9bbdd3640f0692f030b17d725d005f42ee7ece2c9058a8838b'),
    'full': (FULL, 'NF192.countdown_halts_iff_nf_proves_bot',
             'c89f1125e8ee9803a9dee95805cec3227931a807f0dfead776c8f9b842607ee5'),
    'theory': ('nf-theory', 'NF192.derives_goal_iff_nf_inconsistent',
               'eaf11197f2977c9bad5339ebf4dae13db4a61f85ca56837cb8146c6ad1d5b17c'),
    'stream': ('nf-stream', 'NF192.command_stream_halts_iff_nf_inconsistent',
               '8ccd563ab812f1468e830e26542e61a4f6a5141299789a9b9110a2619ace0305'),
}
FULL_THEOREMS = {
    'NF192.command_stream_halts_iff_nf_inconsistent',
    'NF192.countdown_halts_iff_combnf_inconsistent',
    'NF192.countdown_halts_iff_functionnf_inconsistent',
    'NF192.countdown_halts_iff_nf_inconsistent',
    'NF192.countdown_halts_iff_nf_proves_bot',
    'NF192.derives_goal_iff_nf_inconsistent',
    'NF192.literal_source_halts_iff_nf_inconsistent',
}
STANDARD_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}
BINARIES = {'paranoid': 'leanchecker-paranoid', 'nanoda': 'nanoda_bin'}
LABELS = {'paranoid': 'Lean 4.35.0 reference kernel', 'nanoda': 'nanoda independent Rust checker'}


def select_checker(parser, args):
    overrides = {key: getattr(args, key) for key in BINARIES if getattr(args, key)}
    if args.checker == 'auto':
        default = 'paranoid' if args.scope == 'full' else 'nanoda'
        which = next(iter(overrides), default)
    else:
        which = args.checker
    if overrides and which not in overrides:
        parser.error(f'Use --{which} to override the executable for --checker {which}.')
    if overrides:
        binary = overrides[which].expanduser().resolve()
    else:
        name = BINARIES[which]
        bundled = ROOT / 'tools' / 'linux-x86_64' / name
        if (platform.system() == 'Linux' and platform.machine().lower() in ('x86_64', 'amd64')
                and bundled.is_file()):
            binary = bundled
        else:
            installed = shutil.which(name)
            if not installed:
                parser.error(f'Supply --{which} PATH from the Lean 4.35.0 distribution for this platform.')
            binary = Path(installed).resolve()
    if not binary.is_file() or not os.access(binary, os.X_OK):
        parser.error(f'Check that {binary} exists and has execute permission.')
    return which, binary


def run_checker(which, binary, proof, config, work):
    if which == 'paranoid':
        command = [str(binary), '--silent', '--from-export', str(proof)]
    else:
        command = [str(binary), str(config)]
    env = os.environ.copy()
    env['PATH'] = str(binary.parent) + os.pathsep + env.get('PATH', '')
    elapsed_start = time.monotonic()
    result = subprocess.run(command, cwd=work, env=env)
    elapsed = time.monotonic() - elapsed_start
    if result.returncode != 0:
        raise SystemExit(f'{LABELS[which]} exited with code {result.returncode} after {elapsed:.1f} seconds.')
    return elapsed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', choices=['auto', *BINARIES], default='auto',
                        help='auto uses paranoid for full and nanoda for boot, source, theory or stream')
    override = parser.add_mutually_exclusive_group()
    override.add_argument('--paranoid', type=Path, help='use this leanchecker-paranoid executable')
    override.add_argument('--nanoda', type=Path, help='use this nanoda_bin executable')
    parser.add_argument('--scope', choices=SCOPES, default='full',
                        help='check blank-tape startup, the full machine, the literal source, the numerical theory, or the proof-command stream')
    args = parser.parse_args()
    which, binary = select_checker(parser, args)
    stem, theorem, expected_hash = SCOPES[args.scope]
    artifact = ROOT / 'verification' / 'independent'
    archive_stem = stem if args.scope in ('boot', 'source') else FULL
    certificate = artifact / (archive_stem + '.ndjson.zst')
    closure = json.loads((artifact / (stem + '.closure.json')).read_text())
    theorems = sorted(FULL_THEOREMS) if args.scope == 'full' else [theorem]
    if (set(closure['explicit_axioms']) != STANDARD_AXIOMS or closure['found_theorems'] != theorems
            or closure['export_sha256'] != expected_hash):
        parser.error('The closure must identify the expected proof bytes, theorem and axioms.')
    if not shutil.which('zstd'):
        parser.error('Install the zstd command to decompress the certificate.')
    with tempfile.TemporaryDirectory(prefix='nf192-certificate-') as workdir:
        work = Path(workdir)
        proof = work / (stem + '.ndjson')
        with proof.open('wb') as target:
            subprocess.run(['zstd', '-qdc', str(certificate)], stdout=target, check=True)
        if args.scope in ('theory', 'stream'):
            if proof.stat().st_size < closure['export_bytes']:
                raise SystemExit('Incomplete canonical export.')
            # Earlier endpoints are complete dependency-first prefixes of the same export.
            with proof.open('r+b') as source:
                source.truncate(closure['export_bytes'])
        with proof.open('rb') as source:
            digest = hashlib.file_digest(source, 'sha256').hexdigest()
        if digest != expected_hash or proof.stat().st_size != closure['export_bytes']:
            raise SystemExit('The proof bytes do not match the verified export.')
        cfg = work / 'nanoda.json'
        if which == 'nanoda':
            settings = json.loads((artifact / (stem + '.nanoda.json')).read_text())
            if (set(settings['permitted_axioms']) != STANDARD_AXIOMS
                    or not settings['unpermitted_axiom_hard_error']):
                parser.error('The nanoda configuration must restrict axioms to the three standard ones.')
            if set(theorems) != set(settings['pp_declars']) or not settings['print_success_message']:
                parser.error('The nanoda configuration must display the certified theorems and result.')
            settings['export_file_path'] = proof.name
            cfg.write_text(json.dumps(settings))
        print(f'Checking {proof.stat().st_size:,} proof bytes with the {LABELS[which]}.', flush=True)
        elapsed = run_checker(which, binary, proof, cfg, work)
        print(f'{LABELS[which]} accepted the {args.scope} certificate in {elapsed:.1f} seconds.', flush=True)
        for name in theorems:
            print(f'  {name}')


if __name__ == '__main__':
    main()
