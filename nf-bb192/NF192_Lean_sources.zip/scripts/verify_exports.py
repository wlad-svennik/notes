#!/usr/bin/env python3
"""Export the dependency closures of named Lean theorems and check them with nanoda."""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import shutil
import subprocess
import time

PROJECT=Path(__file__).resolve().parents[1]
PIN='eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
AXIOMS=['propext','Classical.choice','Quot.sound']

def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def inspect_closure(export, declarations):
    names = {0: ''}
    found, axioms, counts = set(), [], Counter()
    wanted = set(declarations)
    with export.open('rb') as source:
        meta = json.loads(next(source))['meta']
        if meta['lean']['githash'] != PIN:
            raise SystemExit('Canonical export was not made by the pinned Lean release.')
        for line in source:
            item = json.loads(line)
            if 'in' in item:
                component = item['str'] if 'str' in item else item['num']
                prefix = names[component['pre']]
                suffix = component['str'] if 'str' in component else str(component['i'])
                names[item['in']] = prefix+'.'+suffix if prefix else suffix
                continue
            for kind in ('axiom', 'thm', 'def', 'opaque', 'inductive', 'quot'):
                if kind not in item:
                    continue
                counts[kind] += 1
                if kind == 'axiom':
                    axioms.append(names[item[kind]['name']])
                if kind == 'thm' and names[item[kind]['name']] in wanted:
                    found.add(names[item[kind]['name']])
                break
    if set(axioms)-set(AXIOMS):
        raise SystemExit('Unexpected explicit axiom in the dependency closure: '+str(axioms))
    if found != wanted:
        raise SystemExit('Missing target theorems in the dependency closure: '+str(wanted-found))
    return dict(export_metadata=meta, found_theorems=sorted(found), explicit_axioms=sorted(axioms),
                declaration_records=dict(counts), export_bytes=export.stat().st_size,
                export_sha256=digest(export))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--module',action='append',default=[])
    ap.add_argument('--declaration',action='append',required=True)
    ap.add_argument('--name',required=True,help='output receipt stem')
    ap.add_argument('--lean-bin',type=Path)
    ap.add_argument('--search-path',action='append',type=Path,default=[])
    ap.add_argument('--project-olean',type=Path,default=PROJECT/'native-olean')
    ap.add_argument('--receipt-dir',type=Path,default=PROJECT/'native-receipts/exports')
    ap.add_argument('--memory-mib',type=int,default=4096)
    ap.add_argument('--timeout',type=int,default=1200)
    ap.add_argument('--workers',type=int,default=1,help='independent Rust checker workers')
    ap.add_argument('--backend',choices=['nanoda','lean4lean'],default='nanoda')
    ap.add_argument('--skip-pretty-print',action='store_true',help='verify roots in the canonical input without pretty-printing after checking')
    ap.add_argument('--keep-export',action='store_true',help='retain the uncompressed canonical ndjson')
    ap.add_argument('--export-only',action='store_true',help='emit and inspect the canonical closure without running Rust')
    ap.add_argument('--replay-existing',action='store_true',help='check the named .ndjson already in the receipt directory')
    ap.add_argument('--expected-sha256',help='require this digest for the canonical input')
    args=ap.parse_args()
    if not re.fullmatch(r'[\w.-]+',args.name):ap.error('invalid receipt stem')
    if not args.replay_existing and not args.module:ap.error('specify the Lean module to export')
    if args.workers < 1:ap.error('provide at least one checker worker')
    receipt=args.receipt_dir.resolve();receipt.mkdir(parents=True,exist_ok=True)
    bindir=args.lean_bin or PROJECT/'env/lean-4.35.0-linux/bin'
    if not bindir.is_dir():
        path=shutil.which('lean')
        if not path:ap.error('pass --lean-bin or put Lean 4.35.0 on PATH')
        bindir=Path(path).resolve().parent
    bindir=bindir.resolve()
    env=os.environ.copy()
    env['LEAN_NUM_THREADS']='2'
    env['RAYON_NUM_THREADS']='2'
    env['PATH']=str(bindir)+os.pathsep+env['PATH']
    search=[args.project_olean.resolve(),*(p.resolve() for p in args.search_path)]
    env['LEAN_PATH']=os.pathsep.join(map(str,search))
    def module_hashes():
        inputs={}
        for m in args.module:
            relative=Path(*m.split('.')).with_suffix('.olean')
            located=next((d/relative for d in search if (d/relative).is_file()),None)
            if located is None:raise SystemExit('Missing module input '+m)
            inputs[m]=digest(located)
        return inputs
    initial_modules=module_hashes()
    if subprocess.check_output([str(bindir/'lean'),'--githash'],env=env,text=True).strip()!=PIN:
        ap.error('Lean compiler commit does not match v4.35.0')
    namespace=args.name
    export=receipt/(namespace+'.ndjson')
    exportlog=receipt/(namespace+'.export.log')
    nanolog=receipt/(namespace+'.nanoda.log')
    configp=receipt/(namespace+'.nanoda.json')
    peaks={}
    def run(cmd,stdout,stderr):
        t=time.monotonic()
        proc=subprocess.Popen(cmd,cwd=receipt,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        peak=0
        checkpoint=receipt/(namespace+'.progress.json')
        next_update=0
        try:
            while proc.poll() is None:
                resident=0
                for p in Path('/proc').iterdir():
                    if not p.name.isdecimal():continue
                    try:
                        if os.getpgid(int(p.name))==proc.pid:
                            data=(p/'status').read_text()
                            match=re.search(r'^VmRSS:\s+(\d+) kB',data,re.M)
                            if match:resident+=int(match[1])
                    except (FileNotFoundError, ProcessLookupError,PermissionError):pass
                peak=max(peak,resident)
                elapsed=time.monotonic()-t
                if elapsed>=next_update:
                    tmp=checkpoint.with_suffix('.tmp')
                    tmp.write_text(json.dumps(dict(stage=Path(cmd[0]).name,seconds=round(elapsed,2),
                                                   rss_kib=resident,peak_rss_kib=peak))+'\n')
                    tmp.replace(checkpoint)
                    next_update=elapsed+2
                if resident>args.memory_mib*1024 or elapsed>args.timeout:
                    raise SystemExit('Checker resource limit exceeded; peak RSS KiB '+str(peak))
                time.sleep(.1)
        finally:
            if proc.poll() is None:
                try:os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                proc.wait()
        if proc.returncode:raise SystemExit(f'{Path(cmd[0]).name} failed ({proc.returncode}); inspect {receipt}')
        peaks[Path(cmd[0]).name]=peak
        return round(time.monotonic()-t,3)
    exportsecs=None
    if not args.replay_existing:
        with export.open('wb')as outf,exportlog.open('wb')as log:
            exportsecs=run([str(bindir/'leanexport'),*args.module,'--',*args.declaration],outf,log)
    # Persist the portable, relative path accepted by nanoda when run from this directory.
    config=dict(export_file_path=export.name,use_stdin=False,num_threads=args.workers,permitted_axioms=AXIOMS,
                unpermitted_axiom_hard_error=True,nat_extension=True,string_extension=True,
                pp_declars=[] if args.skip_pretty_print else args.declaration,
                pp_to_stdout=True,print_success_message=True)
    configp.write_text(json.dumps(config,indent=2)+'\n')
    closure = inspect_closure(export, args.declaration)
    if args.expected_sha256 and closure['export_sha256'] != args.expected_sha256:
        raise SystemExit('Canonical export digest mismatch.')
    if initial_modules != module_hashes():
        raise SystemExit('Imported module changed during export; rerun with a frozen build.')
    closure['modules'] = initial_modules
    (receipt/(namespace+'.closure.json')).write_text(json.dumps(closure,indent=2)+'\n')
    if args.export_only:
        (receipt/(namespace+'.progress.json')).unlink(missing_ok=True)
        print(json.dumps(closure,indent=2))
        return
    if args.backend == 'lean4lean':
        alternate_log=receipt/(namespace+'.lean4lean.log')
        with alternate_log.open('wb') as log:
            seconds=run([str(bindir/'lean4lean'),'--import',str(export)],log,subprocess.STDOUT)
        messages=alternate_log.read_text(errors='replace').strip()
        success=re.search(r'checked (\d+) declarations',messages,re.I)
        if not success:raise SystemExit('Missing lean4lean checker success message.')
        detail=dict(declarations=args.declaration,allowed_axioms=AXIOMS,**closure,backend='lean4lean',
                    peak_process_group_rss_kib=peaks,export_seconds=exportsecs,checker_seconds=seconds,
                    checker_exit=0,checker_log_sha256=digest(alternate_log),
                    checker_binary_sha256=digest(bindir/'lean4lean'),summary=success.group(0))
        (receipt/(namespace+'.receipt.json')).write_text(json.dumps(detail,indent=2)+'\n')
        (receipt/(namespace+'.progress.json')).unlink(missing_ok=True)
        if not args.keep_export and not args.replay_existing:export.unlink()
        print(json.dumps(detail,indent=2))
        return
    with nanolog.open('wb')as log:
        nanosecs=run([str(bindir/'nanoda_bin'),str(configp)],log,subprocess.STDOUT)
    content=nanolog.read_text()
    if ' no errors' not in content.lower() and 'success' not in content.lower():
        raise SystemExit('Missing independent checker success message: '+content[-1500:])
    for d in ([] if args.skip_pretty_print else args.declaration):
        if d not in content:
            raise SystemExit('Independent checker did not print target '+d)
    detail=dict(declarations=args.declaration,allowed_axioms=AXIOMS,
                peak_process_group_rss_kib=peaks,**closure,export_seconds=exportsecs,
                nanoda_seconds=nanosecs,nanoda_exit=0,config_sha256=digest(configp),
                nanoda_log_sha256=digest(nanolog),nanoda_binary_sha256=digest(bindir/'nanoda_bin'),
                summary=content.strip().splitlines()[-1])
    (receipt/(namespace+'.receipt.json')).write_text(json.dumps(detail,indent=2)+'\n')
    (receipt/(namespace+'.progress.json')).unlink(missing_ok=True)
    if not args.keep_export and not args.replay_existing:export.unlink()
    print(json.dumps(detail,indent=2))
if __name__=='__main__':main()
