#!/usr/bin/env python3
"""Rebuild the frozen 192-state NF proof with its exact Linux dependencies."""
import argparse
import concurrent.futures
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import subprocess
import sys
import zipfile

from check_native import IMPORT

ROOT = Path(__file__).resolve().parents[1]
LEAN = "4.35.0"
LEAN_COMMIT = "eb6cafb7290e8bd5f2937522d8d804f58f02bafc"
LEAN_ASSET = f"lean-{LEAN}-linux.tar.zst"
LEAN_SHA = "7289597a44543246c9227b8cae501767e095ce17f6d448b95fc4a8dc97268f6d"
ARCHIVE_SHA = "0d840316c347b659bcd20008450387e0f5d0191ff0ebd5bb700a6f04f2363a90"
FFL_REV = "fbcfee52cb4a892087fa978366282a9ebd844f29"
FFL_URL = "https://github.com/FormalizedFormalLogic/Foundation.git"
MACHINE_HASHES = {
    "NF_192_countdown.tm": "ee1391964b35c7ad2f0db90305a84e09c6523f73f3dce6c4f31a182aa270d565",
    "countdown.sites.json": "b991565b82033c133e1f2b4618dfe32d1e7ff1ef02e8e18620a2dfdccb5307aa",
}
DEFAULT_MODULES = ["NF192Countdown", "MachineInputBinding"]
DEFAULT_AUDITS = [
    "NF192.countdown_halts_iff_nf_inconsistent", "NF192.countdown_halts_iff_nf_proves_bot",
    "NF192.countdown_never_halts",
    "NF192.literal_source_halts_iff_nf_inconsistent", "NF192.command_stream_halts_iff_nf_inconsistent",
    "NF192.Input.exact_countdown_source", "NF192.Input.exact_transition_table",
    "NF192.basis_iff_consistent_combnf", "NF192.basis_iff_consistent_functionnf",
    "NF192.countdown_halts_iff_combnf_inconsistent", "NF192.countdown_halts_iff_functionnf_inconsistent",
]


def run(argv, cwd=None, env=None, capture=False):
    args = [str(a) for a in argv]
    if capture:
        return subprocess.check_output(args, cwd=cwd, env=env, text=True).strip()
    subprocess.run(args, cwd=cwd, env=env, check=True)


def digest(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()


def check_sha(path, expected):
    actual = digest(path)
    if actual != expected:
        sys.exit(f"SHA-256 mismatch for {path}\nExpected {expected}\nReceived {actual}")


def install_lean(args, work):
    if args.lean_bin:
        bindir = args.lean_bin.resolve()
    else:
        tools = work / "toolchains"
        tools.mkdir(exist_ok=True)
        home = tools / f"lean-{LEAN}-linux"
        if not home.exists():
            if platform.system() != "Linux" or platform.machine() not in ("x86_64", "amd64"):
                sys.exit("Supply the official Lean 4.35.0 bin directory using --lean-bin on this platform.")
            archive = args.toolchain_archive or tools / LEAN_ASSET
            if not archive.exists():
                if args.toolchain_archive:
                    sys.exit(f"Toolchain archive missing: {archive}")
                tmp = tools / (LEAN_ASSET + ".part")
                url = f"https://github.com/leanprover/lean4/releases/download/v{LEAN}/{LEAN_ASSET}"
                run(["curl", "--fail", "--location", "--retry", "3", "--output", tmp, url])
                check_sha(tmp, LEAN_SHA)
                tmp.replace(archive)
            check_sha(archive, LEAN_SHA)
            staging = tools / "extract"
            staging.mkdir(exist_ok=True)
            run(["tar", "--zstd", "-xf", archive.resolve(), "-C", staging])
            (staging / home.name).replace(home)
        bindir = home / "bin"
    if not (bindir / "lean").is_file():
        sys.exit(f"Lean executable missing in {bindir}")
    env = dict(os.environ, PATH=str(bindir) + os.pathsep + os.environ.get("PATH", ""))
    for name in ("LEAN_PATH", "LEAN_SRC_PATH", "LEAN_SYSROOT"):
        env.pop(name, None)
    if run([bindir / "lean", "--githash"], env=env, capture=True) != LEAN_COMMIT:
        sys.exit(f"The compiler must be official Lean {LEAN} at {LEAN_COMMIT}")
    return bindir, env


def stage_sources(archive, work):
    check_sha(archive, ARCHIVE_SHA)
    with zipfile.ZipFile(archive) as src:
        for entry in src.infolist():
            path = PurePosixPath(entry.filename)
            if entry.is_dir() or len(path.parts) < 3 or path.parts[0] != "nf-interp":
                continue
            if ".." in path.parts or path.is_absolute():
                sys.exit(f"Invalid archive member {entry.filename}")
            if path.parts[1] == "standalone":
                dest = work.joinpath(*path.parts)
            elif path.parts[1] == "foundation-wrapper":
                dest = work.joinpath(*path.parts[1:])
            else:
                continue
            data = src.read(entry)
            if dest.exists():
                if dest.read_bytes() != data:
                    sys.exit(f"Staged source differs from the supplied archive: {dest}")
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
    return work / "nf-interp" / "standalone"


def checkout(package, url, revision, target, mirror):
    target.mkdir(parents=True, exist_ok=True)
    def git(*cmd, capture=False):
        return run(["git", "-C", target, *cmd], capture=capture)
    if not (target / ".git").exists():
        if any(target.iterdir()):
            sys.exit(f"Expected empty checkout at {target}")
        git("init", "--quiet")
        git("remote", "add", "origin", url)
    head = subprocess.run(["git", "-C", target, "rev-parse", "--verify", "HEAD"],
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    if head.returncode:
        source = url
        if mirror and (mirror / package).exists():
            source = (mirror / package).resolve().as_uri()
        git("fetch", "--depth=1", "--no-tags", source, revision)
        git("checkout", "--quiet", "--detach", revision)
    elif head.stdout.strip() != revision:
        sys.exit(f"Checkout at {target} has a different revision. Choose an empty --work directory.")
    if git("rev-parse", "HEAD", capture=True) != revision:
        sys.exit(f"Pin verification failed for {package}")
    git("diff", "--quiet", "HEAD", "--")


def needs_archive(roots, builtin):
    pending = list(roots)
    seen = set()
    while pending:
        module = pending.pop()
        if module in seen:
            continue
        seen.add(module)
        name = Path(*module.split("."))
        source = (ROOT / "proof" / name).with_suffix(".lean")
        if source.is_file():
            pending.extend(IMPORT.findall(source.read_text()))
        elif not (builtin / name).with_suffix(".olean").is_file():
            return True
    return False


def archive_search_path(project, work, bindir, env, args):
    packages = project / ".lake" / "packages"
    manifest = json.loads((project / "lake-manifest.json").read_text())
    jobs = [("Foundation-src", FFL_URL, FFL_REV, work / "Foundation-src")]
    for package in manifest["packages"]:
        if package["type"] == "git":
            name = package["name"].strip("«»")
            jobs.append((name, package["url"], package["rev"], packages / name))
        elif package["name"] != "ffl" or package["type"] != "path" or package["dir"] != "../../foundation-wrapper":
            sys.exit(f"Unrecognized path dependency {package}")
    with concurrent.futures.ThreadPoolExecutor(args.jobs) as pool:
        futures = [pool.submit(checkout, *job, args.git_mirror) for job in jobs]
        for result in futures:
            result.result()
    link = work / "foundation-wrapper" / "Foundation"
    if not link.exists():
        link.symlink_to(Path("..") / "Foundation-src" / "Foundation", target_is_directory=True)
    if link.resolve() != (work / "Foundation-src" / "Foundation").resolve():
        sys.exit(f"Foundation sources at {link} do not match the pinned checkout")
    cache = args.mathlib_cache.resolve() if args.mathlib_cache else work / "mathlib-cache"
    cache.mkdir(parents=True, exist_ok=True)
    env.update(MATHLIB_CACHE_DIR=str(cache), LEAN_NUM_THREADS=str(args.jobs))
    lake = bindir / "lake"
    built = project / ".lake" / "build" / "lib" / "lean" / "CombAll.olean"
    mathlib = packages / "mathlib" / ".lake" / "build" / "lib" / "lean" / "Mathlib.olean"
    if not built.is_file() or not mathlib.is_file():
        run([lake, "exe", "cache", "get", "Mathlib"], cwd=project, env=env)
    run([lake, "--fail-fast", "build", "+CombAll:olean"], cwd=project, env=env)
    return run([lake, "env", "printenv", "LEAN_PATH"], cwd=project, env=env, capture=True).split(os.pathsep)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nf-archive", type=Path, required=True, metavar="ZIP")
    parser.add_argument("--work", type=Path, default=ROOT / ".reproduce", help="separate resumable build directory")
    compiler = parser.add_mutually_exclusive_group()
    compiler.add_argument("--lean-bin", type=Path, help="existing pinned toolchain bin directory")
    compiler.add_argument("--toolchain-archive", type=Path, help="local official Linux .tar.zst")
    parser.add_argument("--git-mirror", type=Path, help="local Git repositories named by manifest package or Foundation-src")
    parser.add_argument("--mathlib-cache", type=Path, help="existing or new mathlib cache directory")
    parser.add_argument("--jobs", type=int, default=3, help="concurrent Git fetches and Lean worker threads")
    parser.add_argument("--module", action="append", help="replace the default final modules, repeatable")
    parser.add_argument("--audit", action="append", help="audit this theorem in the specified modules, repeatable")
    parser.add_argument("--fresh-kernel", action="append", default=[], metavar="MODULE",
                        help="add an independent full transitive kernel replay for the named module")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    if not args.nf_archive.is_file():
        parser.error(f"NF archive missing: {args.nf_archive}")
    work = args.work.resolve()
    work.mkdir(parents=True, exist_ok=True)
    lock = (work / ".reproduce.lock").open("a")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        parser.error(f"A reproduction process is already using {work}")
    for name, sha in MACHINE_HASHES.items():
        check_sha(ROOT / "machine" / name, sha)
    project = stage_sources(args.nf_archive, work)
    bindir, env = install_lean(args, work)
    roots = args.module or DEFAULT_MODULES
    builtin = Path(run([bindir / "lean", "--print-libdir"], env=env, capture=True))
    paths = archive_search_path(project, work, bindir, env, args) if needs_archive(roots, builtin) else []
    audits = args.audit if args.audit is not None else ([] if args.module else DEFAULT_AUDITS)
    command = [sys.executable, ROOT / "scripts" / "check_native.py", *roots, "--lean-bin", bindir,
               "--source-dir", ROOT / "proof", "--out-dir", work / "olean", "--receipt-dir", work / "receipts",
               "--summary", "reproduction"]
    for entry in paths:
        if entry:
            command.extend(["--search-path", (project / entry).resolve()])
    for name in audits:
        command.extend(["--audit", name])
    for module in args.fresh_kernel:
        command.extend(["--fresh", module])
    run(command, env=env)
    print(f"Reproduction receipt: {work / 'receipts' / 'reproduction.summary.json'}")


if __name__ == "__main__":
    main()
