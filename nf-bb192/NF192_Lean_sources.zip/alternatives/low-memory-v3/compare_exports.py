"""Compare Lean export declarations after reindexing the expression and name DAGs."""
import argparse
import hashlib
import json
from pathlib import Path


def fingerprint(value):
    serialized = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(serialized.encode()).hexdigest()


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


class Export:
    def __init__(self, source):
        self.names = [(fingerprint(["anonymous"]), "")]
        self.levels = [fingerprint(["zero"])]
        self.exprs = []
        self.declarations = {}
        with source.open("rb") as stream:
            for line in stream:
                self.read(json.loads(line))

    def read(self, record):
        if "meta" in record:
            return
        for index_key, values, decode in (
            ("in", self.names, self.read_name),
            ("il", self.levels, self.read_level),
            ("ie", self.exprs, self.read_expr),
        ):
            if index_key in record:
                index = record.pop(index_key)
                if index != len(values) or len(record) != 1:
                    raise ValueError(f"Unexpected {index_key} index {index}")
                kind, fields = next(iter(record.items()))
                values.append(decode(kind, fields))
                return
        if len(record) != 1:
            raise ValueError("Unexpected declaration shape")
        kind, fields = next(iter(record.items()))
        if kind == "inductive":
            if set(fields) != {"types", "ctors", "recs"}:
                raise ValueError("Unexpected inductive declaration fields")
            for group, rows in fields.items():
                for row in rows:
                    self.read_declaration("inductive." + group, row)
        elif kind in ("thm", "def", "quot", "opaque", "axiom"):
            self.read_declaration(kind, fields)
        else:
            raise ValueError(f"Unexpected declaration kind {kind}")

    def read_name(self, kind, fields):
        previous, text = self.names[fields["pre"]]
        if kind == "str":
            component = fields["str"]
        elif kind == "num":
            component = fields["i"]
        else:
            raise ValueError(f"Unexpected name kind {kind}")
        label = text + "." + str(component) if text else str(component)
        return fingerprint([kind, previous, component]), label

    def read_level(self, kind, fields):
        if kind == "param":
            arguments = self.names[fields][0]
        elif kind == "succ":
            arguments = self.levels[fields]
        elif kind in ("max", "imax"):
            arguments = [self.levels[index] for index in fields]
        else:
            raise ValueError(f"Unexpected universe level kind {kind}")
        return fingerprint([kind, arguments])

    def read_expr(self, kind, fields):
        if kind in ("bvar", "natVal", "strVal"):
            arguments = fields
        elif kind == "sort":
            arguments = self.levels[fields]
        elif kind == "const":
            arguments = [self.names[fields["name"]][0], [self.levels[i] for i in fields["us"]]]
        elif kind == "app":
            arguments = [self.exprs[fields["fn"]], self.exprs[fields["arg"]]]
        elif kind in ("lam", "forallE"):
            # Bound occurrences use de Bruijn indices. The optional displayed name has no binding effect.
            arguments = [None, self.exprs[fields["type"]], self.exprs[fields["body"]], fields["binderInfo"]]
        elif kind == "letE":
            arguments = [None, self.exprs[fields["type"]], self.exprs[fields["value"]],
                         self.exprs[fields["body"]], fields["nondep"]]
        elif kind == "proj":
            arguments = [self.names[fields["typeName"]][0], fields["idx"], self.exprs[fields["struct"]]]
        else:
            raise ValueError(f"Unexpected expression kind {kind}")
        return fingerprint([kind, arguments])

    def decl_field(self, key, value):
        if key in ("type", "value", "rhs"):
            return self.exprs[value]
        if key in ("name", "induct", "ctor"):
            return self.names[value][0]
        if key in ("levelParams", "all", "ctors"):
            return [self.names[index][0] for index in value]
        if key == "rules":
            return [{k: self.decl_field(k, v) for k, v in rule.items()} for rule in value]
        return value

    def read_declaration(self, kind, fields):
        name = self.names[fields["name"]][1]
        if name in self.declarations:
            raise ValueError(f"Duplicate declaration {name}")
        record = {key: self.decl_field(key, value) for key, value in fields.items()}
        signature = {key: value for key, value in record.items() if key != "value"}
        self.declarations[name] = (kind, fingerprint([kind, signature]), fingerprint([kind, record]))


EXPECTED_PROOFS = {
    "NF192.Emitter.check_all_slots",
    "NF192.Emitter.frozen_guard",
    "NF192.Emitter.frozen_guard_zero",
    "_private.CommandBlocks.0.NF192.CommandBlocks.compare_all",
    "_private.CommandBlocks.0.NF192.CommandBlocks.mp_suffix",
    "_private.CommandBlocks.0.NF192.CommandBlocks.pop_run",
    "NF192.CommandBlocks.mode_correct",
}
REMOVED_HELPER = "_private.NumericalCold.0.NF192.Emitter.frozen_guard._simp_1_2"


def compare(original_file, alternative_file):
    original = Export(original_file).declarations
    alternative = Export(alternative_file).declarations
    common = sorted(original.keys() & alternative.keys())
    added = sorted(alternative.keys() - original.keys())
    removed = sorted(original.keys() - alternative.keys())
    changed_signatures = [n for n in common if original[n][1] != alternative[n][1]]
    changed_records = [n for n in common if original[n][2] != alternative[n][2]]
    added_axioms = [n for n in added if alternative[n][0] == "axiom"]
    if changed_signatures or set(changed_records) != EXPECTED_PROOFS:
        raise ValueError(f"Unexpected changes: {changed_signatures}, {changed_records}")
    if removed != [REMOVED_HELPER] or any(original[n][0] != "thm" for n in removed + changed_records):
        raise ValueError(f"Unexpected removed or modified non-theorem: {removed}, {changed_records}")
    if added_axioms:
        raise ValueError(f"Unexpected additional axioms: {added_axioms}")
    return {
        "original_export_sha256": file_hash(original_file),
        "alternative_export_sha256": file_hash(alternative_file),
        "original_declarations": len(original),
        "alternative_declarations": len(alternative),
        "shared_declarations": len(common),
        "added_declarations": len(added),
        "added_declarations_inventory_sha256": fingerprint([[n, alternative[n][2]] for n in added]),
        "added_axioms": added_axioms,
        "removed_declarations": removed,
        "changed_signatures": changed_signatures,
        "changed_proof_bodies": changed_records,
        "common_signature_inventory_sha256": fingerprint([[n, original[n][1]] for n in common]),
        "unchanged_body_inventory_sha256":
            fingerprint([[n, original[n][2]] for n in common if n not in EXPECTED_PROOFS]),
        "changed_proof_body_sha256": {
            n: {"original": original[n][2], "alternative": alternative[n][2]} for n in changed_records
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original", type=Path)
    parser.add_argument("alternative", type=Path)
    args = parser.parse_args()
    print(json.dumps(compare(args.original, args.alternative), indent=2))


if __name__ == "__main__":
    main()
