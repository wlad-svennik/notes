# Smaller replay proofs for three source modules

The original Lean proof and this alternative use the same 192-state transition table. This directory contains three optional source files for a separate build. They change seven proof bodies in the dependency closure of `NF192.countdown_halts_iff_goal`.

| Module | Proof | Independent Rust replay of the indicated component |
|---|---|---|
| `NumericalEmitterBinding` | Checks 2,928 slots in 46 consecutive windows of at most 64 instructions. | 3,235 declarations in 68.001 s, 195 MiB peak |
| `NumericalCold` | Proves the two startup guard actions for an arbitrary source program, then specializes to this program. | 1,713 declarations in 0.305 s, 7.5 MiB peak |
| `CommandBlocks` | Proves the register comparison loop and its final branches for an arbitrary source program, then applies them to the literal source. The two further changes specialize the pop jump and mode-entry branch. | Modus ponens: 2,084 declarations in 1.917 s, 46 MiB peak. Mode: 2,100 declarations in 2.157 s, 68 MiB peak |

The pinned Lean compiler accepted the combined machine theorem. Its exported dependency closure contains 7,514 declarations and three explicit axioms, `propext`, `Classical.choice`, and `Quot.sound`. All 7,423 signatures shared with the original export agree. The original has one additional private simplifier proof generated inside the former startup guard. The alternative introduces 91 declarations. The Rust checker also verified the complete register-source equivalence `NF192.SourceSimulation.literal_source_iff_goal`, checking 2,911 declarations in 66.624 seconds with 193 MiB peak resident memory. The exact same exported proof bytes were reproduced from this combined alternative. The component results and hashes appear in `component-receipts.json`.

## Rebuild

Start in the package root and set `LEAN_BIN` to the directory containing the official Lean 4.35.0 executables. A separate directory keeps the original source available for comparison.

```sh
mkdir -p build-alternative/src
cp -R proof/. build-alternative/src/
cp alternatives/low-memory-v3/*.lean build-alternative/src/
python3 scripts/check_native.py CountdownSearch \
  --lean-bin "$LEAN_BIN" \
  --source-dir build-alternative/src \
  --out-dir build-alternative/olean \
  --receipt-dir build-alternative/receipts \
  --audit NF192.countdown_halts_iff_goal
python3 scripts/verify_exports.py --export-only --keep-export \
  --lean-bin "$LEAN_BIN" --project-olean build-alternative/olean \
  --module CountdownSearch --declaration NF192.countdown_halts_iff_goal \
  --name machine-goal --receipt-dir build-alternative/exports
```

## Compare the two machine exports

`compare_exports.py` compares declaration signatures and proof or definition bodies after reindexing every name, universe level, and expression. It ignores bound-variable display names, retains binder information and checks the expected changes by name. The receipt `machine-goal-preservation.json` gives the two export hashes and the resulting inventories.

```sh
python3 alternatives/low-memory-v3/compare_exports.py \
  original-machine-goal.ndjson build-alternative/exports/machine-goal.ndjson
```
