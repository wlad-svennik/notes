module
public import NumericalEmitterChecking

@[expose] public section

/-!
# Finite binding to the actual decoded countdown CFG

The reflexive checks compare the compiler's expected instructions against
the address decoder for the exact 3,089 uploaded primitive rows. Every field
of every instruction, including the conditional halt bit, enters the key.
-/

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace NF192.Emitter

open NF192.Numerical

theorem batch_size : batchCode.size = 2928 := by decide

private def batchCompiled : List Instruction := compile batchCode 40 2968 [] []

private def window (i : Nat) : Bool :=
  let lo := i*64
  matchesCode (40+lo) ((batchCompiled.drop lo).take 64)

private theorem matchesCode_iff (pc : Nat) (xs : List Instruction) :
    matchesCode pc xs = true ↔ ∀ (i : Nat) (hi : i < xs.length), actual (pc+i) = xs[i] := by
  refine ⟨matchesCode_spec pc xs,?_⟩
  intro agree
  induction xs generalizing pc with
  | nil => rfl
  | cons x xs ih =>
    have first : actual pc = x := by exact agree 0 (by simp)
    simp only [matchesCode,first,decide_true,Bool.true_and]
    apply ih
    intro i hi
    have h := agree (i+1) (by simpa using hi)
    simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using h

private theorem window_at (w i : Nat) (ok : window w = true) (lo : 64*w ≤ i)
    (hi : i < 64*w+64) (valid : i < batchCompiled.length) : actual (40+i) = batchCompiled[i] := by
  have le : w*64 ≤ i := by omega
  have index : w*64+(i-w*64) = i := by omega
  have inSlice : i-w*64 < ((batchCompiled.drop (w*64)).take 64).length := by
    simp only [List.length_take,List.length_drop]
    omega
  have h := matchesCode_spec (40+w*64) _ ok (i-w*64) inSlice
  simpa only [List.getElem_take,List.getElem_drop,Nat.add_assoc,index] using h

private theorem all_slots_of_windows (len : batchCompiled.length = 2928)
    (windows : (List.range 46).all window = true) : matchesCode 40 batchCompiled = true := by
  apply (matchesCode_iff _ _).2
  intro i hi
  have inside : i / 64 < 46 := by omega
  apply window_at (i/64) i (List.all_eq_true.mp windows _ (List.mem_range.mpr inside)) _ _ hi <;> omega

private theorem window_00 : window 0 = true := by decide
private theorem window_01 : window 1 = true := by decide
private theorem window_02 : window 2 = true := by decide
private theorem window_03 : window 3 = true := by decide
private theorem window_04 : window 4 = true := by decide
private theorem window_05 : window 5 = true := by decide
private theorem window_06 : window 6 = true := by decide
private theorem window_07 : window 7 = true := by decide
private theorem window_08 : window 8 = true := by decide
private theorem window_09 : window 9 = true := by decide
private theorem window_10 : window 10 = true := by decide
private theorem window_11 : window 11 = true := by decide
private theorem window_12 : window 12 = true := by decide
private theorem window_13 : window 13 = true := by decide
private theorem window_14 : window 14 = true := by decide
private theorem window_15 : window 15 = true := by decide
private theorem window_16 : window 16 = true := by decide
private theorem window_17 : window 17 = true := by decide
private theorem window_18 : window 18 = true := by decide
private theorem window_19 : window 19 = true := by decide
private theorem window_20 : window 20 = true := by decide
private theorem window_21 : window 21 = true := by decide
private theorem window_22 : window 22 = true := by decide
private theorem window_23 : window 23 = true := by decide
private theorem window_24 : window 24 = true := by decide
private theorem window_25 : window 25 = true := by decide
private theorem window_26 : window 26 = true := by decide
private theorem window_27 : window 27 = true := by decide
private theorem window_28 : window 28 = true := by decide
private theorem window_29 : window 29 = true := by decide
private theorem window_30 : window 30 = true := by decide
private theorem window_31 : window 31 = true := by decide
private theorem window_32 : window 32 = true := by decide
private theorem window_33 : window 33 = true := by decide
private theorem window_34 : window 34 = true := by decide
private theorem window_35 : window 35 = true := by decide
private theorem window_36 : window 36 = true := by decide
private theorem window_37 : window 37 = true := by decide
private theorem window_38 : window 38 = true := by decide
private theorem window_39 : window 39 = true := by decide
private theorem window_40 : window 40 = true := by decide
private theorem window_41 : window 41 = true := by decide
private theorem window_42 : window 42 = true := by decide
private theorem window_43 : window 43 = true := by decide
private theorem window_44 : window 44 = true := by decide
private theorem window_45 : window 45 = true := by decide

private theorem all_windows : (List.range 46).all window = true := by
  rw [show List.range 46 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45] from rfl]
  simp only [List.all_cons, List.all_nil, Bool.true_and,
    window_00, window_01, window_02, window_03, window_04, window_05, window_06, window_07,
    window_08, window_09, window_10, window_11, window_12, window_13, window_14, window_15,
    window_16, window_17, window_18, window_19, window_20, window_21, window_22, window_23,
    window_24, window_25, window_26, window_27, window_28, window_29, window_30, window_31,
    window_32, window_33, window_34, window_35, window_36, window_37, window_38, window_39,
    window_40, window_41, window_42, window_43, window_44, window_45]


theorem check_all_slots : matchesCode 40 (compile batchCode 40 2968 [] []) = true :=
  all_slots_of_windows ((compile_length _ _ _ _ _).trans batch_size) all_windows

theorem batch_embedded : Embedded actual batchCode 40 2968 [] [] :=
  embedded_of_matches _ _ _ check_all_slots

/-- For arbitrary Cantor fields, old top and old stack, the literal source
takes a positive finite number of steps from ordinal 40 to ordinal 2968.
It has emitted exactly the nine rows and cleared registers 4 and 5. -/
theorem selected_ax_batch (n t stack c u v y delta tail : Nat) :
    ∃ ticks, 0 < ticks ∧
      Source.advance ticks
        (Source.Config.active 40 (liftRegisters (Frame.regs ⟨n,t,stack,c,u,v,pair y (pair delta tail)⟩))) =
        Source.Config.active 2968 (liftRegisters ((save ⟨n,t,stack,c,0,0,tail⟩
          (rowList (u+delta) (v+y) c u)).regs)) :=
  ax_program_of_embedding batch_embedded n t stack c u v y delta tail

#print axioms selected_ax_batch

end NF192.Emitter
