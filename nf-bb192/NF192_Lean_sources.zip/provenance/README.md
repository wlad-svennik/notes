# Sources and attributions

The literal transition table and 3,089 source instructions in this project come from the supplied 192-state countdown candidate. The separate user-supplied archive `nf-interp.zip` contains the FNF, CombNF and NF developments used in the consistency equivalence. Its SHA-256 and the hashes of the two mathematical proof inputs below are in `inputs.json`.

## Dominated implication

`proof/DominatedImplication.lean` comes from Vladimir Reshetnikov's ProveIt repository, commit `5b5d7083500e7628e08107f4a827b76c551f279f`. The three changes are the Lean 4.35 module declaration, a public import of Init and an exposed public section. The mathematical declarations are unchanged. ProveIt's MIT-0 license is included in `ProveIt-MIT-0.txt`.

[Upstream Lean source](https://github.com/VladimirReshetnikov/ProveIt/blob/5b5d7083500e7628e08107f4a827b76c551f279f/Computability/BusyBeaver/Lean/BusyBeaver/ZFC/DominatedImplication.lean)

## The 210-state development

The project reuses the user-supplied file `NF210_independence_proof_only_2026-11-05.zip`. Its public source tree is pinned in `inputs.json`. The following files identify the main points of reuse.

| Project code | Earlier proof |
| --- | --- |
| `proof/NF210/MachineSemantics.lean` | Binary-Turing-machine semantics |
| `proof/MachineBits.lean` | Generic part of KernelBitPacked |
| `proof/MachineControlKernel*.lean` | Shift, scan, register selection, execute and carry contracts ported to the 192-state table. The transformation is recorded in `machine/port_control_kernel.py` |
| `proof/NumericalCodes.lean` | Cantor pairing and code arithmetic adapted from Propositional and Cantor |
| `proof/NumericalLogic.lean` | Deduction and NumericCompleteness |
| `proof/NumericalEmitterCode.lean` | SourceSemantics and SourceCompilation |
| `proof/NumericalEmitterMacros.lean` | Reusable register-program arithmetic contracts adapted to this machine's increment order |
| `proof/SourceEnumeration.lean` | SearchEnumeration |

[Earlier source tree](https://github.com/wlad-svennik/notes/tree/0a0c8fa5992dfdee35f18fcb718ec278378b2740/nf-bb210)

## Reproduction dependencies

Lean 4.35.0 is pinned to `eb6cafb7290e8bd5f2937522d8d804f58f02bafc`. The SHA-256 of its official Linux x86-64 release archive is `7289597a44543246c9227b8cae501767e095ce17f6d448b95fc4a8dc97268f6d`. The user-supplied archive pins Foundation at `fbcfee52cb4a892087fa978366282a9ebd844f29` and mathlib at `56a005855ea17e0b0958f73ec801ae140b0a1679`. Each dependency retains its upstream licensing and attribution.

[Lean 4.35.0 release](https://github.com/leanprover/lean4/releases/tag/v4.35.0)
