# Countdown machine inputs

Both files are byte-for-byte copies from the restored Round 44 checkpoint.
The common directory in that checkpoint is
`nf44_work/redesign/direct_from187/source_b991565b82033c13/`.

| Packaged file | Original file below the common directory | Bytes |
| --- | --- | ---: |
| `NF_192_countdown.tm` | `candidate_192_0/candidate.tm` | 6,544 |
| `countdown.sites.json` | `source.sites.json` | 103,434 |

From this directory, run `sha256sum -c SHA256SUMS` to check both files.
The two SHA-256 values also appear in the original Round 44 binding receipt
`nf44_work/root/COUNTDOWN192_BINDING44.json`.

## Binary conventions

The table header declares `k:64` as the initial state. The Round 44
independent checker `nf44_work/independent/audit_countdown192_44.py` starts
the head at integer position zero with an empty set of marked cells. Each
instruction reads the head cell, writes its new symbol, moves one position
left or right and enters the target state. The sole transition into the
terminal state is `k:302 1 0 L halt`. The 192 working states each have two
transitions. Formal executions use the same two-sided tape and take an
additional step from a halted configuration to itself, so finite runs of
all lengths remain defined.

## Lean input binding

`NF192.Input.exact_transition_table` checks the serialized transition
function against the literal bytes of the supplied table.
`NF192.Input.exact_countdown_source` reconstructs the original JSON from
all 3,089 address, operation and operand entries of the source semantics.
The Lean input elaborator reads the packaged files directly, splits them
at convenient boundaries while retaining each delimiter, and checks that
joining its fragments recreates the entire input. The proof kernel checks
the semantic output against every fragment, including punctuation,
whitespace and the final line feeds. The SHA-256 checks above independently
identify the original files.

The 3,089-row input is the low-level program. The proof expands each
high-level proof-search routine, checks its placement against the actual
decoded instructions, and proves its effect on arbitrary registers.
The finite instruction-placement checks and the uniform binary
instruction proofs therefore share the same source data.
