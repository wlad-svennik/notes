#!/usr/bin/env python3
"""Instantiate immutable 210-state word proofs at the selected countdown table.

All state-name remaps and all updated local transition obligations are
rechecked by Lean. The two new offset probes and their compositions are in
MachineControlKernelEndpoint and MachineControlKernelExecute.
"""
from pathlib import Path
import json,re,zipfile

ROOT=Path(__file__).resolve().parents[1]
source=ROOT.parent/'prior_formal'/'NF210_independence_proof_only_2026-11-05.zip'
archive=zipfile.ZipFile(source)
def read(name):
    return archive.read('nf210_formal/NF210/'+name+'.lean').decode()

oldNames=re.findall(r'"([^"\n]+)"',read('Machine').split('def stateNames')[1].split(']')[0])
t=(ROOT/'machine/NF_192_countdown.tm').read_text()
newNames=sorted({l.split()[0] for l in t.splitlines() if l and not l.startswith('#')})
assert len(oldNames)==210 and len(newNames)==192
modules=['RightShift','Word','Left','Execution','Contracts','Reverse','Files','Selectors','Control','Arithmetic']
for m in modules:
    # The current arithmetic program branches on the next two bits; only the
    # inherited shift and seek part of KernelArithmetic applies unchanged.
    s=read('Kernel'+m)
    if m=='Arithmetic':
        s=s[:s.index('/-- On an actual positive decrement')]+'''#print axioms seek_mark
#print axioms increment_shift

end NF210.KernelArithmetic
'''
    if m=='Control':
        a=s.index('/-- Erase a trailing run')
        b=s.index('theorem cleanup_prefix',a)
        s=s[:a]+s[b:]
        s=s.replace('#print axioms break_prefix\n','')
    s=re.sub(r'import NF210.Kernel(\w+)',r'public import MachineControlKernel\1',s)
    s=s.replace('import NF210.Machine','public import MachineTable')
    endimport=s.index('\n\n')
    s='module\n'+s[:endimport]+'\n\n@[expose] public section\nset_option maxHeartbeats 0\nset_option maxRecDepth 100000'+s[endimport:]
    s=s.replace('NF210.Kernel','NF192.Kernel').replace('NF210.Selected','NF192.Selected')
    s=s.replace('open NF210.TM','open NF210 NF210.TM')
    s=s.replace('Selected.stateName','Selected.name').replace('Configuration 210','Configuration 192')
    s=s.replace('selected210','selected 192-state').replace('decide +kernel','decide')
    alias={'k:16':'k16share:0','k:1':'k16share:1' if m=='Control' else 'k:2'}
    def rep(match):
        old=oldNames[int(match[1])]
        return '⟨'+str(newNames.index(alias.get(old,old)))+', by decide⟩'
    s=re.sub(r'⟨(\d+), by decide⟩',rep,s)
    for old,new in alias.items(): s=s.replace('"'+old+'"','"'+new+'"').replace('`'+old+'`','`'+new+'`')
    if m=='Selectors': 
        s=s.replace('shortened seven-zero detector','shortened zero-run detector')
    path=ROOT/'proof'/('MachineControlKernel'+m+'.lean')
    path.write_text(s)

s=read('KernelExecute')
start=s.index('theorem increased_file')
s=s[start:]
i=s.index('/-- Increment includes')
j=s.index('/-- A positive target')
k=s.index('/-- The zero branch')
inc=s[i:j].replace('new value-one spare','new physical-zero spare').replace('[true, true]','[true, false]').replace('length + 3 +','length + 1 +').replace('- 1) 3 :=','- 1) 1 :=')
positive=s[j:k].replace('true :: tail','true :: true :: tail').replace('length + 1 +','length + 3 +').replace('- 1) 1 :=','- 1) 3 :=').replace('positive_probe_contract.asWordRun.context','positive_probe_contract.context')
zero=s[k:].replace('[false, true] ++ tail','[true, false] ++ tail').replace('restored zero register itself','physical-one register itself')
s=s[:i]+inc+positive+zero
s=s.replace('NF210.Kernel','NF192.Kernel')
head='''module
public import MachineControlKernelEndpoint
@[expose] public section

/-! Full execute phase of all three offset-one operations in the selected
192-state table. The input file has any number of preceding/following unary
blocks of arbitrary lengths. The conclusions identify the precise tape and
head at the normal carry (k:4) or zero-return (k:302) continuation. -/

namespace NF192.KernelExecute
open NF210 NF210.TM
open NF192.Selected (State machine)
open NF192.KernelRightShift NF192.KernelFiles NF192.KernelArithmetic
set_option maxHeartbeats 0
'''
(ROOT/'proof/MachineControlKernelExecute.lean').write_text(head+s)
