# NFU + Infinity interprets NF, NF is consistent, NF interprets Mac Lane set theory with Choice, Mac Lane set theory without choice gives NFU + Infinity, and NF, FunctionNF, CombNF and NFU + Infinity interpret each other: the files that do not need con-nf

A lake project with 63 Lean files, 65,280 lines. It requires Mathlib and the library Foundation
(through `../../foundation-wrapper`; see the README one directory up for how to set that up). It
does not require the con-nf repository.

```bash
lake build
```

Built from an empty build directory on 15 November 2026: 9,142 jobs, no errors. Built again with
the six files on Mac Lane set theory on 17 November 2026: 9,149 jobs, no errors; and with the
seven files on type theory the same day: 9,156 jobs, no errors; and with the eight files on
FunctionNF the same day: 9,164 jobs, no errors. With the four files on CombNF on 18 November
2026: 9,168 jobs, no errors. With the thirteen files on Mac Lane set theory with Choice the same
day: 9,182 jobs, no errors.

## Main statements

| Statement | File |
|---|---|
| `nfuInterpretsNF : 𝗡𝗙𝗨𝗜 ⊳ 𝗡𝗙` | `NFUJensen.lean` |
| `nfInterpretsNFU : 𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜`, `nfuMutualNF : 𝗡𝗙𝗨𝗜 ⋈ 𝗡𝗙` | `NFUJensen.lean` |
| `consistent_nfuInfinity_iff_consistent_nf` | `NFUJensen.lean` |
| `Jensen.consistent_nfuInfinity : Consistent 𝗡𝗙𝗨𝗜` | `NFUConsistent.lean` |
| `consistent_nf_of_jensen : Consistent 𝗡𝗙` | `NFConsistentViaNFU.lean` |
| `nf_provable_not_choice`, `nf_provable_universeInfinite` | `NFInterpretations.lean` |
| `interpretsM : 𝗡𝗙 ⊳ 𝗠`, `nfuInterpretsM : 𝗡𝗙𝗨𝗜 ⊳ 𝗠` | `NFInterpretsMac.lean` |
| `mInterpretsTSTI : 𝗠 ⊳ 𝗧𝗦𝗧𝗜` | `MInterpretsTST.lean` |
| `TST.exists_nfui_model`: every model of `𝗧𝗦𝗧𝗜` gives a model of `𝗡𝗙𝗨𝗜` | `TSTJensen.lean` |
| `exists_nfui_model_of_m`, `consistent_m_iff_consistent_nfui`, `consistent_m_iff_consistent_nf` | `MacNFU.lean` |
| `nfInterpretsFn : 𝗡𝗙 ⊳ 𝗙𝗡𝗙` | `NFInterpretsFn.lean` |
| `fnInterpretsNFUI : 𝗙𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜`, `fnInterpretsNF : 𝗙𝗡𝗙 ⊳ 𝗡𝗙` | `FnInterpretsNFU.lean` |
| `univInfinite`: in a model of `𝗙𝗡𝗙` the universe is not finite | `FnInfinity.lean` |
| `nfuiInterpretsFn : 𝗡𝗙𝗨𝗜 ⊳ 𝗙𝗡𝗙`, `nfInterpretsNFUIviaFn : 𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜`, `consistent_fn` | `FnNF.lean` |
| `nfInterpretsComb : 𝗡𝗙 ⊳ 𝗖𝗡𝗙` | `NFInterpretsComb.lean` |
| `combInterpretsFn : 𝗖𝗡𝗙 ⊳ 𝗙𝗡𝗙`, `combInterpretsNFUI : 𝗖𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜`, `combInterpretsNF : 𝗖𝗡𝗙 ⊳ 𝗡𝗙` | `CombFn.lean` |
| `nfuiInterpretsComb : 𝗡𝗙𝗨𝗜 ⊳ 𝗖𝗡𝗙`, `fnInterpretsComb : 𝗙𝗡𝗙 ⊳ 𝗖𝗡𝗙`, `consistent_comb` | `CombAll.lean` |
| `nfInterpretsMH : 𝗡𝗙 ⊳ 𝗠𝗛` | `NFInterpretsMH.lean` |
| `mhInterpretsMAC : 𝗠𝗛 ⊳ 𝗠𝗔𝗖`, `nfInterpretsMAC : 𝗡𝗙 ⊳ 𝗠𝗔𝗖`, `nfuInterpretsMAC : 𝗡𝗙𝗨𝗜 ⊳ 𝗠𝗔𝗖` | `MHInterpretsMAC.lean` |
| `MH.wol`, `MH.sep_good`, `MH.bound_exists`: the levels are well-ordered, definable subsets are constructible, the bound for the subsets of a level | `MHOrder.lean`, `MHSep.lean`, `MHCond.lean` |
| `consistent_mh`, `consistent_mac` | `MacChoiceAll.lean` |

The theories `𝗡𝗙`, `𝗡𝗙𝗨`, `𝗡𝗙𝗨𝗜` are defined in `NFTheories.lean` (315 lines). The theories `𝗠` and `𝗠𝗔𝗖` are defined in `MacTheories.lean` (96 lines); `𝗠` has no axiom of choice, and `𝗠𝗔𝗖` is `𝗠` with the axiom of choice `𝗔𝗖` of the library (a choice set for every family of pairwise disjoint sets with members). The theory `𝗠𝗛`, which is `𝗠` with the collapse axiom, is defined in `MHTheory.lean` (204 lines). The theory `𝗧𝗦𝗧𝗜` is defined in `TSTTheories.lean`, with its typed formulas in `NFUJensenModel.lean` (`TFm`) and `TFmExtra.lean`. FunctionNF, `𝗙𝗡𝗙`, is defined in `FnTheory.lean` (the first 200 lines), and CombNF, `𝗖𝗡𝗙`, in `CombTheory.lean` (the first 165 lines). These files are the ones to
read first: the theorems say what they appear to say only if their definitions are right.

## Files

- `ConNF/NF/`: `Generic` (the shift-invariant ultrafilter), `NFModel` and `Hailperin` (the finite
  axiomatisation of NF), `NFUCut`, `NFUArith`, `NFULadder`, `NFUSat`, `NFUSound`, `NFUHartogs`,
  `NFUConstr` (arithmetic, ladders, satisfaction and the constructible hierarchy inside a model
  of NFU + Infinity). The directory name is historical. None of these files imports con-nf.
- `Host`, `HostTerm`: the tower of types and the evaluation of terms inside an abstract host.
- `NFUTerm`, `NFUInterpretsNF`, `NFUInterpretsNFEq`: truth assignments and the term model on a cut.
- `NFSpecker`, `NFChoiceForms`, `MutualInterpretability`: NF proves Infinity and refutes Choice.
- `NFTheories`, `NFInterpretations`, `NFUShift`, `NFUJensen`: the theories and the
  interpretations as statements about derivations.
- `MacTheories`, `MacModel`, `NFStrat`, `NFRel`, `NFMac`, `NFInterpretsMac` (added 17 November
  2026): Mac Lane set theory without choice and its interpretation in NF. See
  `../docs/nf_interprets_mac_2026-11-17.md`.
- `TFmExtra`, `TSTTheories`, `JensenGeneric`, `TSTJensen`, `MDefs`, `MInterpretsTST`, `MacNFU`
  (added 17 November 2026): type theory with infinity, its interpretation in Mac Lane set theory
  without choice, and Jensen's step from a model of type theory to a model of NFU + Infinity.
  See `../docs/m_tsti_nfui_2026-11-17.md`. The consistency statements in `MacNFU.lean` are true
  in Lean for a trivial reason as well (Lean proves `Consistent 𝗡𝗙𝗨𝗜` outright); §1 of that note
  says what carries the content.
- `FnTheory`, `FnBool`, `FnSets`, `FnInfinity`, `FnInterpretsNFU`, `NFFn`, `NFInterpretsFn`, `FnNF`
  (added 17 November 2026): FunctionNF, the stratified λ-calculus with full extensionality and
  without pairing; it interprets NFU + Infinity and is interpreted in NF. See
  `../docs/function_nf_2026-11-17.md`. `FnBool`, `FnSets`, `FnInfinity` use no other file of the
  project except `FnTheory` and the definitions of `IsNFU` and `UnivInfinite`.
- `CombTheory`, `CombFn`, `NFInterpretsComb`, `CombAll` (added 18 November 2026): CombNF, the
  combinatory form of FunctionNF; it interprets FunctionNF by bracket abstraction and is
  interpreted in NF. See `../docs/comb_nf_2026-11-18.md`.
- `MHTheory`, `NFInterpretsMH`, `MHBasics`, `MHRec`, `MHLevels`, `MHCodes`, `MHExist`, `MHOrder`,
  `MHSep`, `MHHull`, `MHCond`, `MHInterpretsMAC`, `MacChoiceAll` (added 18 November 2026): NF
  interprets Mac Lane set theory with Choice. NF interprets `𝗠𝗛` (`𝗠` with a collapse axiom) by
  the model of `NFInterpretsMac`; `𝗠𝗛` interprets `𝗠𝗔𝗖` by the constructible sets, where the
  collapse axiom gives power set. See `../docs/mac_choice_2026-11-18.md`. The collapse axiom is
  not proved equivalent to Mathias's axiom H, and the hierarchy is not proved to be Gödel's `L`.
- `NFUJensenModel`, `NFUConsistent`, `NFConsistentViaNFU`: the model of NFU + Infinity and the
  two consistency theorems.

The proofs are described in `../docs/`; start with
`../docs/nf_syntactic_interpretation_2026-11-15.md`.
