#!/bin/bash
# usage: runcheck2.sh <project dir> <logfile> <modules...>   (leanchecker, one module per call)
export PATH="$HOME/.elan/toolchains/leanprover--lean4---v4.35.0/bin:$HOME/.elan/bin:$PATH"
proj=$1; log=$2; shift; shift
cd "$proj" || exit 1
: > "$log"
for m in "$@"; do
  s=$(date +%s)
  out=$(timeout 900 lake env leanchecker "$m" 2>&1); rc=$?
  echo "$m exit=$rc secs=$(( $(date +%s) - s )) out_bytes=${#out}" >> "$log"
done
echo DONE >> "$log"
