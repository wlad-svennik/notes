#!/bin/bash
# usage: runcheck.sh <tool> <logfile> <modules...>
export PATH="$HOME/.elan/toolchains/leanprover--lean4---v4.35.0/bin:$HOME/.elan/bin:$PATH"
cd /tmp/nfproj
tool=$1; log=$2; shift; shift
: > $log
for m in "$@"; do
  s=$(date +%s)
  timeout 900 lake env $tool $m > /tmp/nfproj/chk_$m.out 2>&1
  rc=$?
  echo "$m exit=$rc secs=$(( $(date +%s) - s )) out_bytes=$(stat -c %s /tmp/nfproj/chk_$m.out)" >> $log
done
echo DONE >> $log
