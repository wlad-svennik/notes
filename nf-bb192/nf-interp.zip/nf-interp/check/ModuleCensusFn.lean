import FnNF
open Lean Elab Command

/-- For the constants a declaration depends on: count them by defining module, and say whether
the constants of the proof of `Consistent 𝗡𝗙𝗨𝗜` from the iterated power sets of `ℕ`, Specker's
theorem for `𝗡𝗙`, the Infinity theorem for FunctionNF and `𝗡𝗙𝗨𝗜 ⊳ 𝗡𝗙` are among them. -/
elab "#modclosure " id:ident : command => do
  let env ← getEnv
  let n ← liftCoreM <| realizeGlobalConstNoOverload id
  let mut seen : NameSet := {}
  let mut todo : Array Name := #[n]
  while !todo.isEmpty do
    let c := todo.back!
    todo := todo.pop
    if seen.contains c then continue
    seen := seen.insert c
    if let some ci := env.find? c then
      for d in ci.getUsedConstantsAsSet do
        if !seen.contains d then todo := todo.push d
      match ci with
      | .inductInfo v =>
        for d in v.ctors do if !seen.contains d then todo := todo.push d
        let r := c ++ `rec
        if (env.find? r).isSome && !seen.contains r then todo := todo.push r
      | _ => pure ()
  let mut mods : Std.HashMap Name Nat := {}
  for c in seen do
    let m := match env.getModuleIdxFor? c with
      | some i => env.header.moduleNames[i.toNat]!
      | none => `_current
    mods := mods.insert m (mods.getD m 0 + 1)
  logInfo m!"{n}: {seen.size} constants"
  let std : List Name := [`Init, `Std, `Lean, `Batteries, `Mathlib, `Aesop, `Qq, `Plausible, `Foundation]
  let ours := (mods.toArray.filter fun x => !std.contains x.1.getRoot).qsort (fun a b => a.1.toString < b.1.toString)
  logInfo m!"modules outside Lean core, Batteries, Mathlib, Foundation: {ours}"
  let probes : List Name := [`FFL.FirstOrder.SetTheory.Jensen.consistent_nfuInfinity,
    `JensenNFU.exists_model, `JensenNFU.Lvl, `JensenNFU.C, `JensenNFU.V, `JensenNFU.inf_V,
    `FFL.FirstOrder.SetTheory.consistent_nf_of_jensen,
    `FFL.FirstOrder.SetTheory.nf_provable_universeInfinite, `FFL.FirstOrder.FNF.univInfinite,
    `FFL.FirstOrder.SetTheory.nfuInterpretsNF]
  logInfo m!"uses: {probes.map fun p => (p, seen.contains p)}"


#modclosure FFL.FirstOrder.SetTheory.NFFn.nfInterpretsFn
#modclosure FFL.FirstOrder.FNF.fnInterpretsNFUI
#modclosure FFL.FirstOrder.FNF.fnInterpretsNF
#modclosure FFL.FirstOrder.nfuiInterpretsFn
#modclosure FFL.FirstOrder.nfInterpretsNFUIviaFn
#modclosure FFL.FirstOrder.FNF.univInfinite
#modclosure FFL.FirstOrder.FNF.isNFU
#modclosure FFL.FirstOrder.consistent_fn
