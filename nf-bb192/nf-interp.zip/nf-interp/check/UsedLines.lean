import NFConsistentViaNFU
open Lean Elab Command

/-- For the constants a declaration depends on that are defined outside Lean core, Batteries,
Mathlib and Foundation: the number of source lines of their declarations, by module. -/
elab "#usedlines " id:ident : command => do
  let env ← getEnv
  let n ← liftCoreM <| realizeGlobalConstNoOverload id
  let mut seen : NameSet := {}
  let mut todo : Array Name := #[n]
  while !todo.isEmpty do
    let c := todo.back!
    todo := todo.pop
    if seen.contains c then continue
    seen := seen.insert c
    if let some ci := env.find? c then
      for d in ci.getUsedConstantsAsSet do
        if !seen.contains d then todo := todo.push d
      match ci with
      | .inductInfo v =>
        for d in v.ctors do if !seen.contains d then todo := todo.push d
      | _ => pure ()
  let std : List Name := [`Init, `Std, `Lean, `Batteries, `Mathlib, `Aesop, `Qq, `Plausible, `Foundation]
  -- distinct (module, first line, last line)
  let mut ranges : Std.HashSet (Name × Nat × Nat) := {}
  let mut noRange : Nat := 0
  let mut cnt : Nat := 0
  for c in seen do
    let some i := env.getModuleIdxFor? c | continue
    let m := env.header.moduleNames[i.toNat]!
    if std.contains m.getRoot then continue
    cnt := cnt + 1
    match ← liftCoreM <| findDeclarationRanges? c with
    | some r => ranges := ranges.insert (m, r.range.pos.line, r.range.endPos.line)
    | none => noRange := noRange + 1
  -- merge overlapping ranges per module
  let mut perMod : Std.HashMap Name (Array (Nat × Nat)) := {}
  for (m, a, b) in ranges do
    perMod := perMod.insert m ((perMod.getD m #[]).push (a, b))
  let mut out : Array (String × Nat × Nat) := #[]
  let mut total := 0
  for (m, rs) in perMod do
    let rs := rs.qsort (fun x y => x.1 < y.1)
    let mut lines := 0
    let mut hi := 0
    let mut decls := 0
    for (a, b) in rs do
      if a > hi then
        lines := lines + (b - a + 1); hi := b; decls := decls + 1
      else if b > hi then
        lines := lines + (b - hi); hi := b
    out := out.push (m.toString, decls, lines)
    total := total + lines
  let sorted := out.qsort (fun x y => x.1 < y.1)
  logInfo m!"{n}: {cnt} constants of ours, {noRange} without a source range; {total} lines in used declarations\n{sorted}"

#usedlines FFL.FirstOrder.SetTheory.consistent_nf_of_jensen
#usedlines FFL.FirstOrder.SetTheory.Jensen.consistent_nfuInfinity
#usedlines FFL.FirstOrder.SetTheory.nfuInterpretsNF
