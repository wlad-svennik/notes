import NFConsistentViaNFU
open Lean Elab Command

/-- For the constants a declaration depends on, count them by defining module. -/
elab "#modclosure " id:ident : command => do
  let env ← getEnv
  let n ← liftCoreM <| realizeGlobalConstNoOverload id
  let mut seen : NameSet := {}
  let mut todo : Array Name := #[n]
  while !todo.isEmpty do
    let c := todo.back!
    todo := todo.pop
    if seen.contains c then continue
    seen := seen.insert c
    if let some ci := env.find? c then
      for d in ci.getUsedConstantsAsSet do
        if !seen.contains d then todo := todo.push d
      match ci with
      | .inductInfo v =>
        for d in v.ctors do if !seen.contains d then todo := todo.push d
        let r := c ++ `rec
        if (env.find? r).isSome && !seen.contains r then todo := todo.push r
      | _ => pure ()
  let mut mods : Std.HashMap Name Nat := {}
  let mut roots : Std.HashMap Name Nat := {}
  for c in seen do
    let m := match env.getModuleIdxFor? c with
      | some i => env.header.moduleNames[i.toNat]!
      | none => `_current
    mods := mods.insert m (mods.getD m 0 + 1)
    let r := m.getRoot
    roots := roots.insert r (roots.getD r 0 + 1)
  IO.FS.writeFile s!"names_{n}.txt" (String.intercalate "\n" (seen.toList.map toString))
  logInfo m!"{n}: {seen.size} constants"
  let rs := roots.toArray.qsort (fun a b => a.1.toString < b.1.toString)
  logInfo m!"by root: {rs}"
  let std : List Name := [`Init, `Std, `Lean, `Batteries, `Mathlib, `Aesop, `Qq, `Plausible, `Foundation]
  let ours := (mods.toArray.filter fun x => !std.contains x.1.getRoot).qsort (fun a b => a.1.toString < b.1.toString)
  logInfo m!"modules outside Lean core, Batteries, Mathlib, Foundation: {ours}"

#modclosure FFL.FirstOrder.SetTheory.Jensen.consistent_nfuInfinity
#modclosure FFL.FirstOrder.SetTheory.consistent_nf_of_jensen
#modclosure FFL.FirstOrder.SetTheory.consistent_nf
