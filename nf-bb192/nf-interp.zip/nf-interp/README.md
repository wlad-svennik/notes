# NFU + Infinity, NF, Mac Lane set theory, FunctionNF and CombNF: Lean project

15 November 2026; the files on Mac Lane set theory and on FunctionNF were added on 17 November 2026, and those on CombNF and on Mac Lane set theory with Choice on 18 November. Lean 4.35.0, Mathlib `56a005855ea17e0b0958f73ec801ae140b0a1679`.

## Contents

| Path | What it is |
|---|---|
| `Host.lean`, `HostTerm.lean`, `NFUTerm.lean`, `NFUInterpretsNF.lean` | NFU + Infinity interprets NF, as a theorem about models (`NFUCut.nfu_inf_interprets_nf`) |
| `NFSpecker.lean`, `MutualInterpretability.lean` | NF proves Infinity and refutes Choice; NF interprets NFU + Infinity |
| `NFChoiceForms.lean` | Zorn's lemma and choice functions imply the form of Choice refuted in `NFSpecker.lean` |
| `NFTheories.lean` | The theories `𝗡𝗙`, `𝗡𝗙𝗨`, `𝗜𝗡𝗙`, `𝗡𝗙𝗨𝗜` (and the versions with a sethood predicate) in the formula type of the library Foundation. Imports only Foundation. |
| `NFUInterpretsNFEq.lean` | The interpretation of NF with equality interpreted by equality |
| `NFInterpretations.lean` | `𝗡𝗙𝗨𝗜ₛ ⊳ 𝗡𝗙`, `𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜ₛ`, `𝗡𝗙 ⊢ ∼Axiom.choice`, `𝗡𝗙 ⊢ ∼Axiom.zorn` |
| `NFUShift.lean`, `NFUJensen.lean` | Jensen's NFU in the language of ∈ and =: `𝗡𝗙𝗨𝗜 ⊳ 𝗡𝗙`, `𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜`, `𝗡𝗙𝗨𝗜 ⋈ 𝗡𝗙`, equiconsistency |
| `NFUJensenModel.lean` | A model of NFU in which the universe is not finite, built from the iterated power sets of ℕ. Imports Mathlib and `ConNF.NF.Generic` only. |
| `NFUConsistent.lean` | `Jensen.consistent_nfuInfinity : Consistent 𝗡𝗙𝗨𝗜`, from that model. Imports `NFTheories` and `NFUJensenModel` only. |
| `NFConsistentViaNFU.lean` | `consistent_nf_of_jensen : Consistent 𝗡𝗙`, from the line above and `𝗡𝗙𝗨𝗜 ⊳ 𝗡𝗙`. Does not use con-nf's model. |
| `NFConsistentViaConNF.lean` | `consistent_nf`, `consistent_nfui`, `consistent_nfuInfinity`: the earlier consistency proofs, from con-nf's model. The only file here that needs con-nf. |
| `MacTheories.lean` | Mathias's theories `𝗠` (Mac Lane set theory with transitive containment, without choice) and `𝗠𝗔𝗖` (`𝗠` with choice), with bounded separation `𝗦𝗘𝗣₀`. Imports only Foundation. |
| `MacModel.lean` | A condition for a structure to be a model of `𝗠` (`IsMacBase.models`); bounded formulas are absolute for transitive sets. No NF. |
| `NFStrat.lean` | Stratified definitions (`SDef`) and comprehension in a model of `𝗡𝗙` |
| `NFRel.lean`, `NFMac.lean` | Inside a model of `𝗡𝗙`: types of well-founded pointed graphs up to bisimulation, their membership relation, the type-raising map, stable sets, finite ordinals |
| `NFInterpretsMac.lean` | `interpretsM : 𝗡𝗙 ⊳ 𝗠` and `nfuInterpretsM : 𝗡𝗙𝗨𝗜 ⊳ 𝗠` |
| `TFmExtra.lean`, `TSTTheories.lean` | The simple theory of types with infinity, `𝗧𝗦𝗧𝗜`, in a language with a predicate "has type n" for each n; typed formulas and their satisfaction |
| `JensenGeneric.lean` | Jensen's model of NFU + Infinity over an arbitrary base (the construction of `NFUJensenModel.lean` with the base as a parameter). Mathlib only. |
| `TSTJensen.lean` | `TST.exists_nfui_model`: every model of `𝗧𝗦𝗧𝗜` gives a model of `𝗡𝗙𝗨𝗜`, tied to the given model |
| `MDefs.lean`, `MInterpretsTST.lean` | `mInterpretsTSTI : 𝗠 ⊳ 𝗧𝗦𝗧𝗜`, with type n interpreted as Pⁿ(ω) |
| `MacNFU.lean` | `exists_nfui_model_of_m`: every model of `𝗠` gives a model of `𝗡𝗙𝗨𝗜`; the consistency statements for `𝗠`, `𝗡𝗙𝗨𝗜`, `𝗡𝗙` |
| `FnTheory.lean` | FunctionNF (`𝗙𝗡𝗙`): the stratified λ-calculus with full extensionality and without pairing, in a language with application, the equality test, `⊤` and `⊥`. Imports `NFTheories` and `TFmExtra`. |
| `FnBool.lean`, `FnSets.lean`, `FnInfinity.lean` | Inside a model of `𝗙𝗡𝗙`: truth-value terms, sets, comprehension and extensionality (NFU); injections and Cantor's theorem; the universe is not finite |
| `FnInterpretsNFU.lean` | `fnInterpretsNFUI : 𝗙𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜` and `fnInterpretsNF : 𝗙𝗡𝗙 ⊳ 𝗡𝗙` |
| `NFFn.lean`, `NFInterpretsFn.lean` | Inside a model of `𝗡𝗙`: a pair that preserves types, the bijection between the universe and the functions, application; `nfInterpretsFn : 𝗡𝗙 ⊳ 𝗙𝗡𝗙` |
| `FnNF.lean` | The compositions `𝗡𝗙𝗨𝗜 ⊳ 𝗙𝗡𝗙` and `𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜` through FunctionNF; the consistency statements for `𝗙𝗡𝗙` |
| `CombTheory.lean` | CombNF (`𝗖𝗡𝗙`): the combinatory form of FunctionNF, with application, a function symbol `K` and constants `B`, `R`, `q` |
| `CombFn.lean` | Inside a model of `𝗖𝗡𝗙`: the identity, bracket abstraction for stratified terms; `combInterpretsFn : 𝗖𝗡𝗙 ⊳ 𝗙𝗡𝗙`, `combInterpretsNFUI`, `combInterpretsNF` |
| `NFInterpretsComb.lean` | Inside a model of `𝗡𝗙`: `K`, `B`, `R`, `q` as objects; `nfInterpretsComb : 𝗡𝗙 ⊳ 𝗖𝗡𝗙` |
| `CombAll.lean` | The compositions `𝗡𝗙𝗨𝗜 ⊳ 𝗖𝗡𝗙` and `𝗙𝗡𝗙 ⊳ 𝗖𝗡𝗙`; the consistency statements for `𝗖𝗡𝗙` |
| `MHTheory.lean` | The collapse axiom and the theory `𝗠𝗛`: `𝗠` with the collapse axiom, without choice |
| `NFInterpretsMH.lean` | The model of `𝗠` inside a model of `𝗡𝗙` satisfies the collapse axiom; `nfInterpretsMH : 𝗡𝗙 ⊳ 𝗠𝗛` |
| `MHBasics.lean`, `MHRec.lean` | Inside a model of `𝗠`: pairs, relations as sets, ordinals, `ω`; recursion along an ordinal; limit ordinals |
| `MHLevels.lean`, `MHCodes.lean`, `MHExist.lean` | The constructible levels, generated by eight bounded operations, with their order; tree codes; the levels exist along every ordinal (`Lev`, `LtS`) |
| `MHOrder.lean` | Every level is well-ordered (`wol`) |
| `MHSep.lean` | Every subset of a constructible set that is definable over it is constructible (`sep_good`) |
| `MHHull.lean`, `MHCond.lean` | Hulls and their collapse; condensation; a bound for the constructible subsets of a level (`bound_exists`) |
| `MHInterpretsMAC.lean` | The constructible sets form a model of `𝗠𝗔𝗖`; `mhInterpretsMAC : 𝗠𝗛 ⊳ 𝗠𝗔𝗖`, `nfInterpretsMAC : 𝗡𝗙 ⊳ 𝗠𝗔𝗖`, `nfuInterpretsMAC : 𝗡𝗙𝗨𝗜 ⊳ 𝗠𝗔𝗖` |
| `MacChoiceAll.lean` | The consistency statements for `𝗠𝗛` and `𝗠𝗔𝗖` |
| `standalone/` | A lake project of its own with copies of every file that does not need con-nf: 63 files, 65,280 lines, Mathlib and Foundation only. Proves everything except the three theorems of `NFConsistentViaConNF.lean`. |
| `nfu-consistent/` | A lake project of its own for `Consistent 𝗡𝗙𝗨𝗜`: four files, 1,601 lines, Mathlib and Foundation, no con-nf |
| `con-nf.patch` | Our changes to con-nf: 16 new files `ConNF/NF/*.lean`, 2 new files in `ConNF/Model/`, 13 modified files |
| `foundation-wrapper/` | A lakefile for building the `Foundation/` source directory of the library Foundation |
| `docs/` | The written proofs and notes (Markdown); `docs/README.md` says what each one is and the order to read them in |
| `check/` | Configuration files and outputs for the external type checker nanoda; a census of the modules each consistency theorem depends on |

## Layout expected by `lakefile.toml`

```
con-nf/               upstream con-nf with con-nf.patch applied
foundation-wrapper/   the three files of foundation-wrapper/ here, plus Foundation's source directory
nf-interp/            this directory
```

## Steps

```bash
git clone https://github.com/leanprover-community/con-nf.git
cd con-nf && git checkout edbce7eb98351870f553cfab6ccb7cab327e4259
git apply ../nf-interp/con-nf.patch && cd ..

git clone https://github.com/FormalizedFormalLogic/Foundation.git
cd Foundation && git checkout fbcfee52cb4a892087fa978366282a9ebd844f29 && cd ..
cp -r nf-interp/foundation-wrapper . && cp -r Foundation/Foundation foundation-wrapper/

cd nf-interp && lake build
```

`lake build` compiles con-nf, the Foundation modules that our files import, and the sixteen files
here. Fetching Mathlib's compiled files first (`lake exe cache get`) saves several hours.

## Without con-nf

```bash
cd nf-interp/standalone && lake build
```

`standalone/` requires only `foundation-wrapper` (and through it Mathlib). Neither the con-nf
repository nor `con-nf.patch` is needed. It contains

- ten files under `ConNF/NF/`: `Generic`, `NFModel`, `Hailperin`, `NFUCut`, `NFUArith`,
  `NFULadder`, `NFUSat`, `NFUSound`, `NFUHartogs`, `NFUConstr`. They are copies of the files of
  the same names in `con-nf.patch`. The directory name is kept so that module names are the same
  in both projects; none of these files imports con-nf.
- the twenty-eight files of this directory other than `NFConsistentViaConNF.lean`.

It proves `𝗡𝗙𝗨𝗜 ⊳ 𝗡𝗙`, `𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜`, `𝗡𝗙 ⊢ ∼Axiom.choice`, `𝗡𝗙 ⊢ Axiom.universeInfinite`,
`Jensen.consistent_nfuInfinity` and `consistent_nf_of_jensen`. It was built in this layout from
an empty build directory on 15 November 2026 (9,142 jobs, no errors, about 7 minutes with Mathlib
and Foundation already compiled). The build directory then held the 25 compiled modules and
nothing else of ours.

With the six files of 17 November 2026 it also proves `𝗡𝗙 ⊳ 𝗠` and `𝗡𝗙𝗨𝗜 ⊳ 𝗠`
(`NFInterpretsMac.lean`). It was built again in this layout from an empty build directory on
17 November 2026: 9,149 jobs, no errors, 31 compiled modules. The main project with con-nf was
not built again; the six files are in its `lakefile.toml` and import nothing from con-nf.

With the seven further files of 17 November 2026 it also proves `𝗠 ⊳ 𝗧𝗦𝗧𝗜`
(`MInterpretsTST.lean`), that every model of `𝗧𝗦𝗧𝗜` gives a model of `𝗡𝗙𝗨𝗜`
(`TST.exists_nfui_model` in `TSTJensen.lean`), and their composition (`MacNFU.lean`). It was
built again in this layout from an empty build directory: 9,156 jobs, no errors, 38 compiled
modules. Again the main project with con-nf was not built; the seven files are in its
`lakefile.toml` and import nothing from con-nf. See `docs/m_tsti_nfui_2026-11-17.md`, and its
§1 for what the consistency statements in `MacNFU.lean` do and do not say.

With the eight files on FunctionNF of 17 November 2026 it also proves `𝗡𝗙 ⊳ 𝗙𝗡𝗙`
(`NFInterpretsFn.lean`) and `𝗙𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜` (`FnInterpretsNFU.lean`), so NF, FunctionNF and
NFU + Infinity interpret each other. It was built again in this layout from an empty build
directory: 9,164 jobs, no errors, 46 compiled modules. Again the main project with con-nf was
not built; the eight files are in its `lakefile.toml` and import nothing from con-nf. See
`docs/function_nf_2026-11-17.md`.

With the four files on CombNF of 18 November 2026 it also proves `𝗡𝗙 ⊳ 𝗖𝗡𝗙`
(`NFInterpretsComb.lean`) and `𝗖𝗡𝗙 ⊳ 𝗙𝗡𝗙` (`CombFn.lean`). It was built again in this layout
from an empty build directory: 9,168 jobs, no errors, 50 compiled modules. The main project
with con-nf was not built; the four files are in its `lakefile.toml` and import nothing from
con-nf. See `docs/comb_nf_2026-11-18.md`.

With the thirteen files on Mac Lane set theory with Choice of 18 November 2026 it also proves
`𝗡𝗙 ⊳ 𝗠𝗛` (`NFInterpretsMH.lean`), `𝗠𝗛 ⊳ 𝗠𝗔𝗖` and `𝗡𝗙 ⊳ 𝗠𝗔𝗖` (`MHInterpretsMAC.lean`). Here `𝗠𝗛` is
`𝗠` with a collapse axiom and `𝗠𝗔𝗖` is `𝗠` with the axiom of choice. It was built again in this
layout from an empty build directory: 9,182 jobs, no errors, 63 compiled modules. The main
project with con-nf was not built; the thirteen files are in its `lakefile.toml` and import
nothing from con-nf. See `docs/mac_choice_2026-11-18.md`.

The files under `ConNF/NF/` that need con-nf are `Flat`, `Model`, `ExistsNF` and `Tangle`.
`Crabbe` and `MainLemma` import only Mathlib, but no theorem listed here uses them (they belong
to the original plan), so they are not in `standalone/`. These six are only in `con-nf.patch`.

## The consistency of NFU + Infinity alone

```bash
cd nf-interp/nfu-consistent && lake build
```

This project requires only `foundation-wrapper` (and through it Mathlib). Its four files are
`ConNF/NF/Generic.lean` (a copy of the file of that name in `con-nf.patch`; it imports only
Mathlib), `NFTheories.lean`, `NFUJensenModel.lean` and `NFUConsistent.lean` (copies of the files
one directory up). It was built in this layout on 15 November 2026: 9,118 jobs, no errors.

## What was run, and what was not

- Run: `lake build` in this layout, with `con-nf` and `foundation-wrapper` pointing at builds that
  already existed on the machine. It rebuilt our files and reported the rest up to date
  (9,211 jobs after the changes of 15 November at 23:00 and 23:40; 3,299 before, because
  `NFUJensenModel.lean` imports all of Mathlib).
- Run: `con-nf.patch` applied to a fresh clone of con-nf at the commit above; the resulting
  `ConNF/` directory is identical to the one that was built.
- Not run: the whole sequence above from empty directories, which includes a full build of con-nf.

`foundation-wrapper/lakefile.toml` is not Foundation's own lakefile. Foundation's lakefile also
requires a package (`Forgive`) and builds executables that the modules used here do not need.

## Checking

```bash
lake env leanchecker NFUJensen          # replay one module in Lean's kernel; one module per call
lake env leanexport NFUJensen NFChoiceForms -- <declarations> > export_main.ndjson
nanoda_bin check/nanoda_main.json       # after editing the path in the json file
```

Give `leanchecker` one module at a time. With 26 modules in one call it ran out of memory on a
machine with 8 GB.

## Which modules each consistency theorem depends on

`check/ModuleCensus.lean` follows the constants that a theorem depends on and counts them by the
module that defines them (`lake env lean check/ModuleCensus.lean`; output in
`check/module_census_output.txt`).

| Theorem | Constants | From `ConNF` modules outside `ConNF/NF/` | From `ConNF/NF/*.lean` (ours) |
|---|---|---|---|
| `Jensen.consistent_nfuInfinity` | 8,504 | 0 | 78, all in `Generic` |
| `consistent_nf_of_jensen` | 15,980 | 0 | 1,842, in `Generic`, `Hailperin`, `NFModel`, `NFUArith`, `NFUConstr`, `NFUCut`, `NFUHartogs`, `NFULadder`, `NFUSat`, `NFUSound` |
| `consistent_nf` (the earlier proof) | 14,822 | 2,683, in 61 modules | 590, in `ExistsNF`, `Flat`, `Generic`, `Hailperin`, `Model`, `NFModel` |

The modules outside `ConNF/NF/` are con-nf's construction of the model of tangled type theory,
including the files that `con-nf.patch` modifies or adds in `ConNF/Model/`.

nanoda checked the first two closures as well: 8,506 and 15,982 declarations, no errors, axioms
`propext`, `Quot.sound`, `Classical.choice` (`check/nanoda_jensen_output.txt`,
`check/nanoda_nfviajensen_output.txt`). Its counts are higher by two because the export includes
two auxiliary recursors of `Lean.Syntax`.

The same census run inside `standalone/` gives the same counts for the first two rows
(`check/module_census_standalone_output.txt`). nanoda on an export made from `standalone/` of
`consistent_nf_of_jensen`, `nfuMutualNF`, `nfu_provable_translate_of_nf`, `nf_provable_not_choice`,
`nf_provable_universeInfinite` and `Jensen.consistent_nfuInfinity`: 16,093 declarations, no errors
(`check/nanoda_standalone_output.txt`). `leanchecker` on each of the 25 modules of `standalone/`
and on the 16 modules of the main project that were recompiled: exit status 0
(`check/leanchecker_results.txt`). For the six files of 17 November 2026: `leanchecker` on each,
exit status 0 (`check/leanchecker_results_2026-11-17.txt`); nanoda on an export made from
`standalone/` of `interpretsM`, `nfuInterpretsM`, `IsMacBase.models`, `eval_submodel_iff`,
`nf_provable_translate_of_m` and `consistent_m_of_consistent_nf`: 15,704 declarations, no errors
(`check/nanoda_mac_output.txt`). For the seven further files: `leanchecker` on each, exit status 0
(same file); nanoda on an export of `mInterpretsTSTI`, `TST.exists_nfui_model`,
`exists_nfui_model_of_m` and the consistency statements of `MacNFU.lean`: 17,111 declarations,
no errors (`check/nanoda_mac_nfu_output.txt`); and a census showing that none of them depends on
the outright proof `Jensen.consistent_nfuInfinity` (`check/module_census_mac_output.txt`). For the
eight files on FunctionNF: `leanchecker` on each, exit status 0
(`check/leanchecker_results_fn_2026-11-17.txt`); nanoda on an export of `nfInterpretsFn`,
`fnInterpretsNFUI`, `fnInterpretsNF`, `nfuiInterpretsFn`, `nfInterpretsNFUIviaFn`, `univInfinite`,
`isNFU` and `consistent_fn`: 17,026 declarations, no errors (`check/nanoda_fn_output.txt`); and a
census by module (`check/module_census_fn_output.txt`). For the four files on CombNF:
`leanchecker` on each, exit status 0 (`check/leanchecker_results_comb_2026-11-18.txt`); nanoda on
an export of `nfInterpretsComb`, `combInterpretsFn`, `combInterpretsNFUI`, `combInterpretsNF`,
`nfuiInterpretsComb`, `fnInterpretsComb` and `consistent_comb`: 17,295 declarations, no errors
(`check/nanoda_comb_output.txt`). For the thirteen files on Mac Lane set theory with Choice:
`leanchecker` on each, exit status 0 (`check/leanchecker_results_mac_choice_2026-11-18.txt`);
nanoda on an export of `nfInterpretsMH`, `mhInterpretsMAC`, `nfInterpretsMAC`, `nfuInterpretsMAC`,
`consistent_mh` and `consistent_mac`: 17,763 declarations, no errors
(`check/nanoda_mac_choice_output.txt`). The two older exports (`nanoda_main`, `nanoda_con`) were not
made again after the move.
