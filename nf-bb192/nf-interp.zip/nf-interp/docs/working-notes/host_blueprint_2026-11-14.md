# Blueprint: the overlapping construction inside a host (Phase 1)

Written 14 Nov 2026, during the block that started 13:50 UTC. Source: the exposition
(`/mnt/user-data/uploads/11fe60f5-nf_consistency_exposition__1_.tex`, lemma names below refer to
it) and PDF App. C. This file is the design that the Lean files `/tmp/connf/host/H*.lean` follow.
Nothing here is proved unless the Lean file compiles it.

## 0. Tools (Lean, compiled)
- `H1.lean`: `Form` (named variables, extra ternary symbols `rel k`), `Holds`, `Host` (axioms for
  pure formulas: ext, pair, union, inf, sep, coll, global well-order `lt` with least elements for
  definable predicates, `mem_lt : x ∈ y → x <* y`), `Def1/2/3`, elimination of definable extra
  symbols, tactic `hdef`.
- `hdef` proves `Def1 H P`, `Def2 H R`, `Def3 H R` for P written in Lean over `H.W`: connectives,
  quantifiers over `H.W`, `∈`, `H.lt`, `=`, `≠`, definitions (unfolded automatically), abstract
  relations with a `Def` hypothesis in context, and terms `f t..` under binders when `f.graph`,
  `f.flat` are declared (done: up, sg, op, un, bun, suc). Terms not depending on bound variables
  are parameters. NOT supported under binders: choice-defined sets with proof arguments
  (`sepS`, `img`, `mkFun`): use the relational description.
- `H2.lean`, `H2b.lean`, `H3.lean`: basic sets, replacement, products, functions, om, induction.
- Build: `/tmp/connf/host/hc.sh H1 H2 H2b H3 ...` (concatenates, compiles with Mathlib).

## 1. Interface: closed levels
A closed level M of a host: transitive, and
- C1: x ⊆ y ∈ M ⇒ x ∈ M;
- C2: f a function, dom f ∈ M, all values in M ⇒ ∃ y ∈ M containing all values (then ran f ∈ M);
- C3: for a ∈ M, {y ∈ M : y <* a} ∈ M. (x ∈ y ⇒ x <* y is a host axiom.)
- om ∈ M.
Consequences: closed under pairs, op, union, finite subsets, finite sequences, products of
elements; bounded subsets are elements; back-and-forth unions stay in M.
Ladder: levels L(1) ∈ L(2) ∈ ... ∈ L(d+1). Pool level M = L(d). Objects live in M⁺ = L(d+1).
Stage α uses the sub-pool of vertices that are elements of L(α). Names of codes of stage α are
elements of L(α+1).
In 𝔏 (NFU side): C1 is `next_absorb` [Lean, C20]. C2 to prove (adapt `next_coll`, C21). C3 from
`pr_iff`. Levels as elements + internal sequence: as `exists_inner_seq`.

## 2. Levels, pool, tokens
- Levels are host numbers 0..d. Level 0 is the atoms ("−1" of the exposition); proper 1..d.
- atom X η := op ∅ (op X η); label r ξ X η := op 1 (op r (op ξ (op X η))); all components in M.
- Adj a b :⇔ b ∈ X_a ∨ a ∈ X_b. Position = the global order <* (no position map).
- Genericity (no recursion): for P, N, Z ∈ M with P ∩ N = ∅: a := atom P (op N Z) is adjacent to
  every label in P, to none in N, and a ∉ Z. Same for labels with any r, ξ. Reason: N, Z are in
  the transitive closure of a, so their members precede a, and X_b ∋ a forces a <* b.
- Fibre of the descriptor (c, S) with source γ and target δ: labels with r = op γ δ, ξ = op c S.
  Other labels are flexible. Parent edges decrease <* automatically (S is inside the label).
- Path: a subset p of {1..d} (level 0 is implicit). Type of p: max p, or 0 if p = ∅.
  δ = min p, P = p \ {δ}. Raising: p ∪ {α}.
- Token at level β: op t p, p of type β, t an atom, or a label if p ≠ ∅.
- Tuple: a function on a number with tokens as values. Supports are finite SETS of tokens;
  tuples are used only in descriptors.

## 3. State and stages
State = five sets of tagged entries, defined level by level by Separation (existence of a good
state needs no mathematics):
- T: op β x for x ∈ τ_β.   Gp: op β π for π ∈ G_β.   Ac: op β (op π (op x y)) for π·x = y.
- Nm: op β c for code names.   Dc: op β (op c (op S x)) for dec_β(c, S) = x.
Definitions at level α ≥ 1 (they mention only slices below α, plus Gp, Ac at α for τ_α):
- Desc γ c S: γ = 0: c = op k i, i < k, S an atom tuple of length k (raw codes = projections);
  γ ≥ 1: op γ c ∈ Nm, c = op S₀ pat, S a tuple at γ with the signature of S₀.
- Col v γ δ c S P: v = op b p, b = label (op γ δ) (op c S) X η, δ = min p, P = p \ {δ} ≠ ∅,
  γ ≠ δ, γ < min P, Desc γ c S. Coordinates of v: the entries of S raised by P.
- IsAut α π: bijection of Tok_α, preserves paths, kinds, Adj on each path, colours with
  S' = π(S↑P)↓P, and reflects colours.
- Derivative: π_β(op t u) = op t' u iff π(op t (u ∪ {α})) = op t' (u ∪ {α}), u of type β.
- τ_0 = A. Object at α: the empty object, or op β D with β < α, ∅ ≠ D ⊆ τ_β, retained, with a
  finite support. Action: π·(op β D) = op β (π_β[D]).
- ext_β(op β D) = D; ext_δ(op β D) = A_δ(D) = {lit b : b in a fibre (β, δ, c, S), dec(c,S) ∈ D},
  lit b = op 0 L_b, L_b = atoms adjacent to b (no level tag on objects).
- Inverse, chains, retained: via a finite chain with a set of kept indices (no arithmetic).
- Name at α: c = op S₀ pat, S₀ ∈ L(α) a tuple, x supported by ran S₀, pat = pattern of x:
  op β {op c' U : U ∈ L(α), Desc β c' U, dec_β(c', U) ∈ D}. ALL such pairs are names (no orbit
  representatives; redundant names are harmless). dec_α(c, S) = g·x if S = g S₀, else empty.

## 4. Lemmas at level α (by internal induction on α; statements must be reifiable)
- one-step extension (genericity) and finite closures (induction on <*);
- foa: closed partial isomorphisms that are elements of M extend to automorphisms (recursion
  along Tok_α ordered by <*; needs C2, C3);
- fixed tokens = closure; derivative is allowable;
- injectivity of A_δ, lit injective; transport; literal litters; depth finite (labels decrease);
  extensionality; symmetric comprehension;
- (K): every finite closed set is conjugate into the sub-pool L(α) over a given finite closed
  subset of the sub-pool. Replaces the orbit count of the exposition's §7:
  x ↦ pattern is injective on objects supported by S₀ ⊆ L(α); names ⊆ L(α+1); τ_α ∈ M⁺ by C2.
- lowering (Lemma 8.1).
- Flat axioms: 11 of the 12 by symmetric comprehension directly (parameters at the level of the
  new set are allowed); only typeLower needs lowering (three times, inside its own 5 levels).

## 5. Route H (Phase 2), decided 14 Nov
Term model on a cut; see plan file §2 Decision 4. Flat models should be "exact" (the defined
set is exactly the stated set) so witnesses are unique; a well-order of the carrier is needed
only for the extensionality witness.
