# Plan for the rest of "NFU + Infinity interprets NF"

14 November 2026. This is a plan. Nothing in it is proved unless it is marked **[Lean]**. Section numbers "§n" refer to `nfu_inf_interprets_nf_proof_2026-11-13.md`; "PDF" is `NF_choice_principles_v15_3.pdf` (version 15, 30 October 2026); "the exposition" is the paper *A model of tangled type theory from overlapping generic litters* from the chat "NF consistency proof".

## 0. Where things stand

**[Lean]**, kernel-checked, 30,711 lines in `ConNF/NF`: §2 (arithmetic of U, calm numbers), §3 (satisfaction, soundness, ladders, Lemma 3.2), Hailperin's theorem, and the external forms of §4.4, §5, §6 (`Tangle`, `Flat`, `Crabbe`, `MainLemma`, `Generic`, `Model`).

Not Lean:

1. the Transfer Lemma (§4.3), marked "inspection": the only step that is not a proof;
2. the Main Lemma inside U at a possibly nonstandard size (§5, §6): paper proof, Lean only for actual finite objects;
3. §7: Lemma 7.1 is cited (Visser, Pudlák), Lemma 7.2 is a paper proof that cites cut elimination with bounds (Gerhardy);
4. three small items around Lemma 3.2 (a single sentence "every set has a well-ordering"; one coded sentence for the power-set sequence; renaming the comprehension variable in Separation).

## 1. What the two sources are used for

| Source | What it supplies | Where it goes |
|---|---|---|
| Exposition: raw structure, extension lemma, parity and extensionality, counting, type lowering | The construction to put inside 𝔏. "Allowable permutation" is "automorphism of one homogeneous structure with unary parent functions", so there are no near-litters and no strong supports | Phase 1, mathematical content |
| Exposition discussion: the two places where the simplification is bought (the stage-dependent partial inverse against the derivative action; atom-only raw signatures in type lowering) and the two corrections made on 1 November | Which lemmas to formalise first | Phase 1, order of milestones 1.3–1.5 |
| The Mathlib-free screening project from that chat (`Parity`, `Paths`), written before Lean was installed | The abstract parity device with its five properties | Milestone 1.4, after compiling it |
| PDF §8 and Lemmas C.5–C.9, C.13 | The same construction at a fixed finite height, one lemma per step, each with its hypotheses stated as "given the lower stages" | Statements of 1.2–1.8 and the invariant of 1.7 |
| PDF Lemma 9.5 (i)–(v) | Each selection predicate (rich, closed, supports, inverse depth, correct history) is first-order with set parameters | The definability goals of the host (Decision 2) |
| PDF Lemmas 9.2, 9.3, C.11 | The construction needs a regular μ with μ^{<μ} = μ, obtained from condensation | Phase 0.2 (closed levels) |
| PDF Lemma C.10 | Recursion along a set well-order | Milestone 1.1 |
| PDF §6.3 and Lemma 7.7 | The term model: witness operations indexed by type placements, closed terms identified with their uniform shifts, and the remark that the atomic diagram suffices | Phase 2 |
| PDF Lemmas C.1–C.3 | Crabbé's conversion with bounds and the Ramsey relation q → (r+1)^r | Route S only (Decision 4); a different form of it is already Lean externally |
| PDF §1.2 and §22 | Status: the support constructions are a research draft, not formalised and not refereed | Risk R1 |
| PDF §9 (orders, invariant ultrafilters, BPI) | — | Not planned. The same pipeline would give NF + BPI + a linear order of the universe if the ordered construction were put through Phase 1 |

## 2. Four decisions

**Decision 1. The Transfer Lemma is proved for the overlapping construction, not for con-nf.** What must be redone inside 𝔏 is then about six pages of mathematics instead of about two thousand Lean lemmas and the parts of Mathlib under them.

**Decision 2. It is written once, against an abstract host.** A *host* is a Lean structure 𝕎 = (W, ∈, <*) with extensionality, foundation, pairing, union, ω, a global well-ordering <*, and Separation and Collection for every first-order formula of {∈, <*} (as a statement about `Holds` for every `Form`). The theorem is "in every host with enough closed levels, for every number d *of the host*, there is an element that is a flat model of height d". Because d ranges over the host's own numbers, this is the Transfer Lemma in the form §6 needs. The structure 𝔏 of Lemma 3.2 is a host after passing to the quotient by equality of names.

Each use of Separation needs a formula. That is handled by a predicate `Def P` ("P is given by some `Form`") with closure lemmas for ∈, <*, =, connectives, quantifiers and substitution, discharged by automation, so that inside the host one writes ordinary Lean quantifiers over W.

**Decision 3. "c·(D+1) iterated power sets" is replaced by "about d+3 closed levels".** A *closed level* of a host is a transitive set M such that

- (C1) every subset (in 𝕎) of an element of M is an element of M;
- (C2) if f ∈ 𝕎 is a function with domain in M and values in M, its range is an element of M;
- (C3) for a ∈ M the set {y ∈ M : y <* a} is an element of M, and x ∈ y implies x <* y.

From C1–C3: every bounded subset of (M, <*) is an element of M, and every function from a proper initial segment into M is bounded (its range b is in M and bounds itself). So (M, <*) is a regular well-order with "μ^{<μ} = μ" in the form the pool construction uses, and the power set of an element of one level is an element of the next. A *ladder of closed levels* is an internal finite sequence M₀ ∈ M₁ ∈ … ∈ M_K with ω ⊆ M₀. The pool is built on M_d, the types are subsets of M_{d+1}, and the code family of stage n is an element of M_{n+1}; the exact K is fixed when the count (1.6) is written.

In 𝔏 the closed levels are the levels at the stages ν₁ < ν₂ < … that the proof of Lemma 3.2 already constructs (each the least stage that is not small over the previous one). They are not exposed by `Lemma32`, and C2 is not yet proved; see 0.2.

**Decision 4 (proposed; needs your agreement). §5 and §7 are replaced by a term model on a cut.** The document's route needs the syntactic conversion inside U at nonstandard size, cut elimination with bounds inside U, and the interpretation existence lemma. The last two are cited, and a complete Lean theorem would need both formalised. The proposed route builds the interpretation directly and uses no proof calculus:

- `Model.lean` **[Lean]** already builds a model of NF from flat models of all heights: elements are functions of a generic placement of levels, an ultrafilter decides membership and equality, and the shift collapses the levels. Phase 2 is the same construction inside U with two substitutions. Elements are *closed terms* in `sing`, `up` and one witness operation for extensionality and for each of the twelve existence statements (finite objects, so they can be coded). The ultrafilter is replaced by a *decision sequence along a cut*.
- A closed term has a value in a flat model once its levels are placed on sorts; the witness operations take the least witness in a well-order of the carrier. A finite set Φ of decided atoms (t ∈ t′, t = t′, each with a sign) is *good* if for every calm q there are a flat model with a well-ordered carrier and a set X of at least q sorts such that every member of Φ has its sign at every placement into X.
- **Dichotomy.** If Φ is good and a is an atom, then Φ + a is good or Φ + ¬a is good. Proof sketch: for calm q take X′ with |X′| → (q)^r₂, r the number of levels of a; a homogeneous subset shows that one of the two is q-good. The sets {q : Φ + a is q-good} and {q : Φ + ¬a is q-good} are initial segments of the calm numbers whose union is all of them, so one of them is all of them.
- The numbers k for which a correct decision sequence of length k exists form a cut; shorten it so that it is closed under forming terms. The model is the set of closed terms in the cut, with ∈ and = read off the decisions.
- Each axiom of `NFModel` (extensionality, `mem_sing`, `mem_up`, the twelve existence statements with their witness operations) is a Boolean combination of atoms between closed terms. It holds in every flat model at every placement, so the decisions satisfy it. Then `NFModel.comprehension` **[Lean]** gives every instance of stratified comprehension.
- "The empty set of atoms is good" is where Lemma 3.2 and the Transfer Lemma enter: flat models with well-ordered carriers exist at every calm height. The definition of the interpretation itself mentions only: calm, flat model with a well-order, values of terms, decision sequences. So its defining formulas are short enough to write out as `Fml`.

This is my proposal, not something already checked. It has to be written out (two or three pages) and checked before any Lean. If it fails or you prefer the document's route, Route S is: internal Crabbé conversion and internal Ramsey in Lean (about 17k lines by my estimate), with Lemma 7.1 and cut elimination staying cited.

## 3. Work packages

Sizes are estimates in lines of Lean, calibrated on §3 (16.2k lines for `NFUHartogs` + `NFUConstr`).

### Phase 0. Interface on the NFU side (about 4k)

- 0.1 Compile the screening project (`Parity`, `Paths`) under the name `Overlap` (the name `NFModel` is taken by the structure in `Model.lean`). Write the blueprint: one numbered statement per lemma of Phase 1, taken from the corrected exposition and PDF C.5–C.9, C.13, with one fixed wording of what relations exist between different paths. Vocabulary: labels and neighbourhoods as in the exposition; "descriptor" (PDF) for a pair of a code and a support, because "name" already means an element of 𝔏 in §3.
- 0.2 **Lemma 3.2⁺.** Expose the stage sequence of Lemma 3.2 and prove for each ν_{i+1}: C1 (generalise `pow_of_next` from subsets of the level ν to subsets of any element of the level ν_{i+1}; same hull and condensation lemmas, C19–C20); C2 (new: the hull of the level ν_i, f and a generator for the domain contains the range, so an unbounded range would make ν_{i+1} small); C3 (from the definition of the order of names); the levels as elements, with their internal finite sequence (as `exists_inner_seq` does for power sets).
- 0.3 The host instance: quotient of the names by equality, Separation and Collection for every `Form` with an arbitrary comprehension variable (from `l32_sep_holds`, `l32_coll_holds` plus a renaming lemma). This absorbs the three small items of §0.4: the well-ordering sentence is one line in a host, the power-set sequence is replaced by the level sequence, and the renaming is this lemma.

### Phase 1. The Transfer Lemma in a host (about 20–25k)

- 1.1 Host library: pairs, functions, finite sequences, induction on the host's ω, recursion along a set well-order (PDF C.10, easier with Collection), finiteness, the `Def` automation.
- 1.2 The pool on a closed level: the generic bipartite graph (every bounded prescription has unboundedly many realisations), rich reservoirs, the rank map. PDF §8.1, C.5, without the orders.
- 1.3 **First risk lemma.** The stage structure with paths, colours and coordinate functions; finite parent closures; every isomorphism between closed substructures that are elements of the level extends to an automorphism. Exposition's extension lemma, PDF 8.1/C.6.
- 1.4 **Second risk lemma.** Alternate extension maps, inverse depth, the parity presentations, the action, extensionality, symmetric comprehension. Exposition §7, PDF 4.1–4.2, C.9. The point to settle is that parity is computed at the stage of the new object and commutes with derivatives.
- 1.5 **Third risk lemma.** Projection and type lowering. PDF C.7. The point to settle is the closure of a raised support containing no label on the direct path.
- 1.6 Codes, the count, descriptors, positions, fibres. PDF C.8 and the allocation paragraph after C.9.
- 1.7 The induction on stages n < d inside the host. The invariant is the hypothesis list of C.9 in the order of the "no circular use" paragraph after it.
- 1.8 Comprehension for every typed formula (induction on the formula outside, one host argument per step; PDF C.13), hence the twelve existence statements for every descending chain: an internal `FlatTTT` of height d − 2.
- 1.9 For 𝔏: the element given by 1.8, read in U, is a flat model with a well-ordered carrier. This replaces §4.3.

Order: 1.1, then 1.3–1.5 with the pool and the lower stages as hypotheses, then 1.2, 1.6–1.9. A mathematical error in the construction would show in 1.3–1.5, before the bulk is written.

Sanity check on the interface: instantiate the host with Mathlib's `ZFSet` and check that the hypotheses of 1.3–1.8 are not contradictory there (closed levels themselves need GCH and cannot be instantiated in Lean's logic alone).

### Phase 2. From flat models to the interpretation (about 10k, Route H)

- 2.0 The paper proof of Decision 4.
- 2.1 Closed terms in U, their levels, the value of a term at a placement (a least relation closed under tagged rules, as in the term evaluation of §3.3).
- 2.2 Ramsey's theorem inside U for colourings that are sets, with the exponent a variable; the cut of exponents r for which the Ramsey numbers of calm numbers are calm (closed under successor because calm numbers are closed under exponentiation, Lemma 2.2 **[Lean]**).
- 2.3 Good sets of atoms, the dichotomy, the cut of decision sequences and its shortening.
- 2.4 The term model, the congruence, each `NFModel` axiom, then `NFModel.comprehension`.

### Phase 3. The final statement (about 3k)

- 3.1 The defining formulas δ, ε, η of the domain, membership and equality as `Fml`, with their `Sat` lemmas.
- 3.2 `∃ δ ε η, ∀ V (M : NFUCut.Model V)`, the structure defined by δ, ε, η in M satisfies extensionality and every instance of stratified comprehension. The step from "holds in every model of U" to "U proves" is the completeness theorem; I would leave that cited unless you want the custom syntax connected to a formalised completeness proof.
- 3.3 Rewrite §4.3 and §§5–7 of the document, and the ledger. `Crabbe` and `MainLemma` stay as an independent result (an explicit height excluding cut-free refutations of a given size); they are no longer on the path to the theorem.

Total: about 35–40k lines, a little more than everything written for this theorem so far, two thirds of it in Phase 1. In working terms, on the order of a dozen blocks like the one that produced C22–C36.

## 4. Checkpoints

After each of 0.2, 0.3, 1.1, 1.3, 1.4, 1.5, 1.7, 1.9, 2.2, 2.3, 2.4, 3.2: build, kernel replay, axiom check, a timestamped line in `NOTES.md`, and the changed files sent. After 1.5 I report whether the three risk lemmas went through as stated or needed changes; that is the point to decide whether to continue or switch to a fallback.

## 5. Risks and fallbacks

- R1. The overlapping construction has not been formalised or refereed. Mitigation: 1.3–1.5 first. Fallback: the finite-support version of the disjoint-litter construction in PDF §§5–6, which takes μ = ℶ_{d+2} and needs no closed levels, but leans on the Holmes–Wilshaw counting of coding functions; the last resort is a port of con-nf.
- R2. C2 for the levels of 𝔏 is expected from the existing hull lemmas but not proved. If it fails as stated, the fallback is to prove inside 𝔏 that every element of ν_{i+1} is the range of a function on the level ν_i, which needs the term evaluation of §3.3 redone inside 𝔏.
- R3. The cost of definability goals in the host. It will be measured on 1.1 and 1.3; if the overhead is far above a factor of two, the `Def` automation gets more work before continuing.
- R4. Decision 4 is new. Step 2.0 is cheap and comes before any Lean for Phase 2; Route S is the fallback.
- R5. The exposition and PDF §8 word the "relations between different paths" differently (parent functions do relate paths; orders and incidence do not). The blueprint fixes one statement before 1.5.

## 6. What I need

- The current TeX or PDF of the exposition (after the 1 November corrections). It is not in this workspace; PDF §8 and Appendix C cover the same lemmas and are enough for 0.2, 0.3, 1.1 and 1.2, but 1.4 and 1.5 should follow the corrected text.
- Your decision on Decision 4 (term model on a cut, or the document's route with §7 cited).
