# Documents

Read in this order.

| File | What it is |
|---|---|
| `nfu_inf_interprets_nf_selfcontained_2026-11-16.md` | The proof that NFU + Infinity interprets NF, written to be read on its own, from the definitions of the theories to the interpretation. Each step names the Lean statement it corresponds to. If you read one document, read this one. |
| `nf_syntactic_interpretation_2026-11-15.md` | For the Lean side, start here. The theorems as Lean states them (`𝗡𝗙𝗨𝗜 ⊳ 𝗡𝗙`, `𝗡𝗙 ⊳ 𝗡𝗙𝗨𝗜`, the consistency theorems), the definitions of the theories, what was checked and how, and what was not. §11 is the model of NFU + Infinity; §12 is the build without con-nf. |
| `nfu_inf_interprets_nf_term_model_2026-11-15.md` | The proof that NFU + Infinity interprets NF, as it is in Lean: steps T0–T12, each with the names of the Lean statements. |
| `nfu_inf_interprets_nf_proof_2026-11-13.md` | The main document. §2 and §3 (arithmetic, ladders, satisfaction, the constructible hierarchy inside NFU + Infinity) are what the Lean files `ConNF/NF/NFU*.lean` formalise. §5–§7 describe the original plan, which the final theorem does not use; the term-model note replaces them. §9 is a ledger of what is in Lean. |
| `nfu_inf_interprets_nf_phase2_2026-11-15.md` | The paper proof of the term model on a cut, written before it was formalised. The term-model note refers to it. Where the two differ, the term-model note describes the Lean. |
| `comb_nf_2026-11-18.md` | CombNF, the combinatory form of FunctionNF (application, `K`, `B`, `R`, `q`): its statement in Lean, the proof that it interprets FunctionNF (bracket abstraction for stratified terms), the proof that NF interprets it, and what was and was not checked. Continues `function_nf_2026-11-17.md`. |
| `function_nf_2026-11-17.md` | FunctionNF, the stratified λ-calculus with full extensionality and without pairing: its statement in Lean, the proof that it interprets NFU + Infinity (truth-value terms, comprehension, and Infinity by a Specker-style argument modulo 5), the proof that NF interprets it (a pair that preserves types, the Cantor–Schröder–Bernstein bijection between the universe and the functions), and what was and was not checked. Independent of the notes above except for Specker's theorem and `𝗡𝗙𝗨𝗜 ⊳ 𝗡𝗙`. |
| `m_tsti_nfui_2026-11-17.md` | Mac Lane set theory without choice interprets type theory with infinity (`𝗠 ⊳ 𝗧𝗦𝗧𝗜`), and every model of type theory with infinity gives a model of NFU + Infinity (Jensen's step): the statement of `𝗧𝗦𝗧𝗜`, both proofs with the Lean name of each step, what the consistency statements do and do not say, and what was checked. |
| `mac_choice_2026-11-18.md` | NF interprets Mac Lane set theory with Choice (`𝗡𝗙 ⊳ 𝗠𝗔𝗖`), through `𝗠𝗛`, which is `𝗠` with a collapse axiom: the axiom, why the model of the note below satisfies it, the constructible levels inside a model of `𝗠𝗛` (eight operations, the well-order, separation, the hull and its collapse for power set, choice), with the Lean name of each step; what is not established; what was checked. Continues `nf_interprets_mac_2026-11-17.md`. |
| `nf_interprets_mac_2026-11-17.md` | NF interprets Mac Lane set theory without choice (`𝗡𝗙 ⊳ 𝗠`): the model, the proof with the Lean name of each step, and what was and was not checked. Independent of the notes above except for Specker's theorem. |
| `nf_infinity_not_choice_2026-11-15.md` | NF proves Infinity and refutes Choice (Specker), as formalised in `NFSpecker.lean` and `NFChoiceForms.lean`. |
| `working-notes/plan_rest_of_proof_2026-11-14.md`, `working-notes/host_blueprint_2026-11-14.md` | Plans written on 14 November, before `Host.lean` existed. They are kept as a record. They are not descriptions of the final Lean files. |

These notes cite two documents that are not included: `nf_consistency_exposition.tex` and
`NF_choice_principles_v15_3.pdf`.
