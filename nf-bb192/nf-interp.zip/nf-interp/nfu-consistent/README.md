# NFU + Infinity is consistent

A lake project with four Lean files, 1,601 lines. It requires Mathlib and the library Foundation
(through `../../foundation-wrapper`; see the README one directory up). It does not require con-nf
and uses nothing about NF.

```bash
lake build
```

Built on 15 November 2026: 9,118 jobs, no errors.

| File | Lines | Content |
|---|---|---|
| `ConNF/NF/Generic.lean` | 384 | an ultrafilter on sequences of levels that is invariant under shifting; Mathlib only |
| `NFTheories.lean` | 315 | the theories `𝗡𝗙`, `𝗡𝗙𝗨`, `𝗡𝗙𝗨𝗜` and stratification |
| `NFUJensenModel.lean` | 673 | `JensenNFU.exists_model`: a structure with extensionality for objects with members, stratified comprehension, and a universe that is not finite |
| `NFUConsistent.lean` | 229 | `Jensen.consistent_nfuInfinity : Entailment.Consistent 𝗡𝗙𝗨𝗜` |

The construction is written out in §11 of `../docs/nf_syntactic_interpretation_2026-11-15.md`.
